start_time|end_time|text
0.16|5.52|sorry for the delay um thanks coming
3.6|3.679|and um sorry i had some technical
5.68|4.08|difficulties
7.279|4.641|really neat ai for this
9.76|5.2|so uh what we want to
11.92|4.96|show today is that tesla is
14.96|5.6|much more than an electric car company
16.88|4.96|that we have uh deep ai activity uh in
20.56|3.6|um
21.84|3.519|hardware on the inference level on the
24.16|3.199|training level
25.359|3.201|um and uh
27.359|4.561|basically we
28.56|5.28|i think i think arguably the leaders in
31.92|3.92|real world ai as it applies to the real
33.84|3.68|world
35.84|2.96|and those of you who have seen the full
37.52|4.24|self-driving
38.8|4.32|beta i can appreciate the rate at which
41.76|3.92|the tesla
43.12|3.919|neural net is learning to drive
45.68|3.44|and
47.039|4.0|so this is a particular application of
49.12|3.759|ai but i think there's there's more
51.039|4.081|there are more applications uh down the
52.879|4.721|road that will make sense and we'll talk
55.12|4.0|about that later in the presentation
57.6|3.119|but um
59.12|3.36|yeah we basically want to encourage
60.719|4.321|anyone who is interested in
62.48|3.999|solving real world ai problems uh at
65.04|3.6|either the hardware or the software
66.479|3.281|level to join tesla or consider joining
68.64|3.04|tesla
69.76|4.32|so let's see we'll start off with uh
71.68|2.4|andre
80.0|2.24|great
82.479|2.241|i think
84.799|3.441|okay hi everyone uh here's my con i hope
87.439|3.121|so
88.24|3.28|if not i'll give you mine
90.56|2.08|i like it
91.52|1.919|okay hello
92.64|3.28|great
93.439|5.441|okay hi everyone um welcome
95.92|4.879|my name is andre and um i am
98.88|3.519|i lead the vision team here at tesla
100.799|4.161|autopilot and i'm incredibly excited to
102.399|4.641|be here uh to kick off this section
104.96|4.479|giving you a technical deep dive into
107.04|3.84|the autopilot stack and showing you all
109.439|3.401|the under the hood components that go
110.88|3.599|into making the car drive all by
112.84|2.84|itself
114.479|2.801|so we're going to start off with the
115.68|2.799|vision component here
117.28|2.72|now in division component what we're
118.479|3.521|trying to do is we're trying to design a
120.0|3.439|neural network that processes the raw
122.0|3.2|information
123.439|3.68|which in our case is the eight cameras
125.2|3.44|that are positioned around the vehicle
127.119|3.441|and they send us images and we need to
128.64|3.76|process that in real time into what we
130.56|3.12|call the vector space and this is a
132.4|3.199|three-dimensional representation of
133.68|3.199|everything you need for driving so this
135.599|3.521|is the three-dimensional positions of
136.879|4.321|lines edges curbs
139.12|4.96|traffic signs traffic lights
141.2|5.92|cars their positions orientations depth
144.08|3.04|velocities and so on
148.72|5.44|so here i'm showing a video of
151.44|2.72|actually hold on
155.44|4.0|apologies
157.2|4.88|so here i'm showing the video of the raw
159.44|4.64|inputs that come into the stack and then
162.08|3.76|neural processes that into the vector
164.08|3.519|space and you are seeing parts of that
165.84|5.24|vector space rendered in the instrument
167.599|3.481|cluster on the car
179.44|2.879|now
181.04|2.8|what i find kind of fascinating about
182.319|4.241|this is that we are effectively building
183.84|4.24|a synthetic animal from the ground up so
186.56|2.8|the car can be thought of as an animal
188.08|3.36|it moves around it senses the
189.36|4.72|environment and uh you know acts
191.44|3.92|autonomously and intelligently and
194.08|3.04|we are building all the components from
195.36|3.28|scratch in-house so we are building of
197.12|3.68|course all the mechanical components of
198.64|3.679|the body the nervous system which is all
200.8|3.68|the electrical components and for our
202.319|4.161|purposes the brain of the autopilot and
204.48|3.92|specifically for this section the
206.48|3.44|synthetic visual cortex
208.4|2.96|now the biological visual cortex
209.92|3.12|actually has quite intricate structure
211.36|4.0|and a number of areas
213.04|4.479|that organize the information flow of
215.36|5.12|this brain and so in particular in our
217.519|5.041|in your visual cortexes
220.48|3.36|the information hits the
222.56|2.64|light hits the retina it goes through
223.84|3.6|the lgn all the way to the back of your
225.2|4.319|visual cortex goes through areas v1 v2
227.44|4.079|v4 the it the venture on the dorsal
229.519|4.64|streams and the information is organized
231.519|5.44|in a certain layout and so when we are
234.159|4.16|designing the visual cortex of the car
236.959|2.721|we also want to design the neural
238.319|4.721|network architecture of how the
239.68|3.36|information flows in the system
243.12|4.0|so the processing starts in the
244.959|4.241|beginning when light hits our artificial
247.12|3.759|retina and we are going to process this
249.2|4.56|information with neural networks now i'm
250.879|4.64|going to roughly organize this section
253.76|2.719|chronologically so starting off with
255.519|2.24|some of the neural networks and what
256.479|2.801|they looked like roughly four years ago
257.759|3.2|when i joined the team and how they have
259.28|2.96|developed over time
260.959|2.561|so
262.24|2.959|roughly um
263.52|3.36|four years ago the car was mostly
265.199|3.841|driving in a single lane going forward
266.88|3.599|on the highway and so it had to keep
269.04|3.12|lane and it had to keep distance away
270.479|4.081|from the car in front of us and at that
272.16|4.56|time all of processing was only on
274.56|3.76|individual image level so a single image
276.72|3.759|has to be analyzed by a neural net and
278.32|3.439|make little pieces of the vector space
280.479|4.641|process that into little pieces of the
281.759|5.521|vector space so this processing um
285.12|4.799|took the following shape we take a 1280
287.28|4.96|by 960 input and this is 12 bit integers
289.919|3.521|streaming in at roughly 36 hertz now
292.24|3.28|we're going to process that with the
293.44|4.4|neural network so instantiate a feature
295.52|4.08|extractor backbone in this case we use
297.84|3.359|residual neural networks so we have a
299.6|3.2|stem and a number of residual blocks
301.199|3.201|connected in series
302.8|4.32|now the specific class of resnets that
304.4|4.639|we use are regnets uh because we like
307.12|3.359|this is like a very rec nets offer a
309.039|3.041|very nice design space for neural
310.479|5.28|networks because they allow you to very
312.08|6.88|nicely trade off latency and accuracy
315.759|4.801|now these rig nets give us as an output
318.96|3.519|a number of features at different
320.56|3.199|resolutions in different scales so in
322.479|2.881|particular on the very bottom of this
323.759|3.121|feature hierarchy we have very high
325.36|3.76|resolution information with very low
326.88|4.96|channel counts and all the way at the
329.12|5.2|top we have low spatial low resolution
331.84|3.84|especially but high channel counts so on
334.32|2.56|the bottom we have a lot of neurons that
335.68|3.28|are really scrutinizing the detail of
336.88|3.52|the image and on the top we have neurons
338.96|3.12|that can see most of the image and a lot
340.4|3.68|of that context have a lot of that same
342.08|3.679|context
344.08|3.28|we then like to process this with
345.759|3.681|feature pyramid networks in our case we
347.36|4.32|like to use by fbn's and they get the
349.44|3.68|most they get to multiple scales to talk
351.68|3.12|to each other effectively and share a
353.12|2.96|lot of a lot of information so for
354.8|3.04|example if you're a neuron all the way
356.08|2.959|down in the network and you're looking
357.84|2.96|at a small patch and you're not sure
359.039|4.0|this is a car or not it definitely helps
360.8|3.679|to know from the top players that hey
363.039|3.201|you are actually in the vanishing point
364.479|5.041|of this highway and so that helps you
366.24|4.959|disambiguate that this is probably a car
369.52|4.16|after a buy fbn and a feature fusion
371.199|4.481|across scales we then go into task
373.68|3.92|specific heads so for example if you are
375.68|4.4|doing object detection we have a one
377.6|4.879|stage yolo like object detector here
380.08|4.399|where we initialize a raster and there's
382.479|3.44|a binary bit per position telling you
384.479|3.44|whether or not there's a car there and
385.919|3.28|then in addition to that if there is
387.919|2.961|here's a bunch of other attributes you
389.199|3.12|might be interested in so the x y with
390.88|2.8|height offset or any of the other
392.319|2.801|attributes like what type of a car is
393.68|3.68|this and so on
395.12|3.919|so this is for the detection by itself
397.36|3.279|now very quickly we discovered that we
399.039|4.561|don't just want to detect cars we want
400.639|4.161|to do a large number of tasks so for
403.6|2.719|example we want to do traffic light
404.8|3.76|recognition and detection a lane
406.319|3.761|prediction and so on so very quickly we
408.56|3.28|conversion this kind of architectural
410.08|3.679|layout where there's a common shared
411.84|3.759|backbone and then branches off into a
413.759|3.84|number of heads so
415.599|4.801|we call these uh therefore hydronets and
417.599|4.0|these are the heads of the hydra
420.4|2.88|now
421.599|4.0|this architectural layout has a number
423.28|4.639|of benefits so number one
425.599|4.401|uh because of the feature sharing we can
427.919|3.761|amortize the forward pass inference uh
430.0|3.84|in the car at test time and so this is
431.68|3.6|very efficient to run um because if we
433.84|3.759|had to have a backbone for every single
435.28|3.28|task that would be a lot of backbones in
437.599|2.72|the car
438.56|3.44|number two this decouples all of the
440.319|3.521|tasks so we can individually work on
442.0|3.84|every one task in isolation and for
443.84|3.12|example we can we can upgrade any of the
445.84|2.639|data sets or change some of the
446.96|2.959|architecture of the head and so on and
448.479|3.521|you are not impacting any of the other
449.919|3.201|tasks and so we don't have to revalidate
452.0|2.479|all the other tasks which can be
453.12|3.04|expensive
454.479|4.321|and number three because there's this
456.16|4.159|bottleneck here and features
458.8|3.519|what we do fairly often is that we
460.319|3.44|actually cache these features to disk
462.319|4.0|and when we are doing these fine tuning
463.759|4.241|uh workflows we only fine-tune from from
466.319|3.761|the cached features up and only find you
468.0|4.08|in the heads so most often in terms of
470.08|3.839|our training workflows we will do an
472.08|4.08|end-to-end training run once in a while
473.919|4.641|where we train everything jointly then
476.16|4.24|we cache the features um
478.56|3.6|at the multi-scale feature level and
480.4|4.079|then we fine-tune off of that for a
482.16|4.4|while and then end-to-end train once
484.479|3.921|again and so on
486.56|3.6|so here's the kinds of predictions that
488.4|3.44|we were obtaining i would say several
490.16|3.599|years ago now
491.84|5.039|from one of these hydro nets so again we
493.759|4.801|are processing individual images
496.879|3.121|there we go we are processing just
498.56|2.72|individual image and we're making a
500.0|3.12|large number of predictions about these
501.28|4.08|images so for example here you can see
503.12|5.519|predictions of the stop signs the stop
505.36|6.08|lines the lines the edges the cars
508.639|4.721|the traffic lights the curbs here
511.44|3.519|whether or not the car is sparked
513.36|3.599|all of the static objects like trash
514.959|3.52|cans cones and so on and everything here
516.959|3.76|is coming out of the net
518.479|4.0|here in this case out of the hydra net
520.719|3.761|so that was all fine and great but as we
522.479|4.48|worked towards fsd we quickly found that
524.48|4.64|this is not enough so where this first
526.959|4.721|started to break was when we started to
529.12|3.839|work on smart summon here i am showing
531.68|2.88|some of the predictions of only the
532.959|3.841|curve detection task and i'm showing it
534.56|3.68|now for every one of the cameras
536.8|2.96|so we'd like to wind our way around the
538.24|3.44|parking lot to find the person who is
539.76|3.759|summoning the car now the problem is
541.68|3.599|that you can't just directly drive on
543.519|3.201|image space predictions you actually
545.279|4.0|need to cast them out and form some kind
546.72|4.88|of a vector space around you
549.279|4.401|so we attempted to do this using c plus
551.6|5.6|and developed what we call
553.68|3.52|the occupancy tracker at the time
557.6|3.44|so here we see that the curve detections
559.519|3.76|from the images are being stitched up
561.04|3.76|across camera scenes camera boundaries
563.279|3.201|and over time
564.8|3.2|now there are two pro two major problems
566.48|3.12|i would say with the setup number one we
568.0|3.12|very quickly discovered that tuning the
569.6|3.52|occupancy tracker and all of its hyper
571.12|3.76|parameters was extremely complicated you
573.12|3.68|don't want to do this explicitly by hand
574.88|4.16|in c plus you want this to be inside the
576.8|4.0|neural network and train that end to end
579.04|3.6|number two we very quickly discovered
580.8|3.52|that the image space is not the correct
582.64|2.96|output space you don't want to make
584.32|2.639|predictions in image space you really
585.6|3.919|want to make it directly in the vector
586.959|4.081|space so here's a way of illustrating
589.519|3.201|the issue
591.04|4.0|so here i'm showing on the first row the
592.72|4.72|predictions of our curves and our lines
595.04|4.479|in red and blue and
597.44|4.079|they look great in the image but once
599.519|4.161|you cast them out into the vector space
601.519|3.681|things start to look really terrible and
603.68|3.12|we are not going to be able to drive on
605.2|2.879|this so
606.8|3.68|you see how the predictions are quite
608.079|3.841|bad in vector space and the reason for
610.48|3.52|this fundamentally is because you need
611.92|3.68|to have an extremely accurate depth per
614.0|3.839|pixel in order to actually do this
615.6|4.0|projection and so you can imagine just
617.839|4.801|how high of the bar it is to predict
619.6|4.88|that depth so accurately in these tiny
622.64|3.28|in every single pixel of the image and
624.48|2.88|also if there's any occluded area where
625.92|4.24|you'd like to make predictions you will
627.36|4.08|not be able to because it's not an image
630.16|3.2|space
631.44|3.6|concept in that case
633.36|2.96|so we very quickly
635.04|2.64|real of
636.32|3.44|the other problems with this by the way
637.68|4.88|is also for object detection if you are
639.76|4.639|only making predictions per camera then
642.56|3.519|sometimes you will encounter cases like
644.399|3.68|this where a single car actually spans
646.079|3.76|five of the eight cameras
648.079|4.0|and so if you are making individual
649.839|4.401|predictions then no single camera since
652.079|3.281|sees all of the car and so obviously
654.24|2.96|you're not going to be able to do a very
655.36|2.8|good job of predicting that whole car
657.2|3.199|and it's going to be incredibly
658.16|3.76|difficult to fuse these measurements
660.399|3.12|so we have this intuition that what we'd
661.92|3.2|like to do instead is we'd like to take
663.519|3.44|all of the images and simultaneously
665.12|4.159|feed them into a single neural net and
666.959|5.041|directly output in vector space now this
669.279|5.281|is very easily said much more difficult
672.0|4.48|to actually achieve but roughly we want
674.56|3.6|to lay out a neural net in this way
676.48|3.12|where we process every single image with
678.16|3.6|a backbone
679.6|4.88|and then we want to somehow fuse them
681.76|4.639|and we want to re-represent it the the
684.48|3.28|features from image space features to
686.399|2.88|directly some kind of vector space
687.76|3.199|features and then go into the decoding
689.279|3.441|of the head
690.959|3.281|now
692.72|2.96|so there are two problems with this
694.24|3.36|problem number one
695.68|3.04|how do you actually create the neural
697.6|3.28|network components that do this
698.72|3.76|transformation
700.88|3.6|and you have to make it differentiable
702.48|4.24|so that end-to-end training is possible
704.48|4.0|and number two uh
706.72|3.04|the if you want vector space predictions
708.48|3.68|from your neural net you need vector
709.76|4.0|specif based data sets so just labeling
712.16|3.44|images and so on is not going to get you
713.76|3.519|there you need vector space labels we're
715.6|3.679|going to talk a lot more about problem
717.279|3.201|number two later in the talk for now i
719.279|3.041|want to focus on the neural network
720.48|4.4|architecture so i'm going to deep dive
722.32|4.319|into problem number one
724.88|3.36|so here's the rough problem right we're
726.639|2.961|trying to have this bird's eye view
728.24|3.039|prediction instead of image space
729.6|3.2|predictions so for example let's focus
731.279|3.201|on a single pixel in the output space in
732.8|4.08|yellow and this pixel is trying to
734.48|3.44|decide am i part of a curb or not as an
736.88|3.44|example
737.92|3.919|and now where should the support for
740.32|2.8|this kind of a prediction come from in
741.839|2.881|the image space
743.12|2.959|well we know roughly how the cameras are
744.72|3.84|positioned and their extrinsics and
746.079|4.721|intrinsics so we can roughly project
748.56|3.6|this point into the camera images and
750.8|2.8|you know the evidence for whether or not
752.16|2.72|this is a curve may come from somewhere
753.6|2.72|here in the images
754.88|2.639|the problem is that this projection is
756.32|3.04|really hard to actually get correct
757.519|2.961|because it is a function of the road
759.36|3.36|surface the road surface could be
760.48|4.0|sloping up or sloping down or also there
762.72|3.119|could be other data dependent issues for
764.48|3.76|example there could be occlusion due to
765.839|4.881|a car so if there's a car occluding this
768.24|4.0|this viewport this this part of the
770.72|2.64|image then actually you may want to pay
772.24|2.0|attention to a different part of the
773.36|2.96|image
774.24|3.44|not the part where it projects and so
776.32|2.079|because this is data dependent it's
777.68|3.04|really hard to have a fixed
778.399|4.961|transformation for this component
780.72|5.04|so in order to solve this issue
783.36|5.039|we use a transformer to represent this
785.76|4.56|space and this transformer
788.399|4.321|uses multi-headed self-attention and
790.32|4.639|blocks off it um in this case actually
792.72|3.76|we can get away with even a single block
794.959|2.32|doing a lot of this work
796.48|2.64|and
797.279|4.24|effectively what this does is you
799.12|4.0|initialize a raster of the size of the
801.519|3.201|output space that you would like and you
803.12|3.6|tile it with positional encodings with
804.72|4.0|size and coses in the output space and
806.72|3.679|then these get encoded with an mlp into
808.72|3.04|a set of query vectors
810.399|3.44|and then all of the images and their
811.76|3.92|features also emit their own keys and
813.839|3.521|values and then the queries keys and
815.68|3.519|values feed into the multi-headed
817.36|3.12|self-attention and so effectively what's
819.199|4.32|happening is that every single image
820.48|5.28|piece is broadcasting in its key
823.519|3.76|what it is what is it a part of so hey
825.76|2.96|i'm part of a pillar in roughly this
827.279|3.281|location and i'm seeing this kind of
828.72|3.28|stuff and that's in the key and then
830.56|3.36|every query is something along the lines
832.0|3.76|of hey i'm a pixel in the output space
833.92|3.359|at this position and i'm looking for
835.76|3.04|features of this type
837.279|3.441|then the keys and the queries interact
838.8|4.24|multiplicatively and then the values get
840.72|4.16|pulled accordingly
843.04|3.52|and so this re-represents the space and
844.88|4.319|we find this to be very effective for
846.56|4.16|this transformation so if you do all of
849.199|2.88|the engineering correctly this again is
850.72|3.04|very easily said
852.079|4.961|difficult to do you do all of the
853.76|4.639|engineering correctly um
857.04|3.359|there's one more there's no problem
858.399|3.841|actually before
860.399|3.601|i'm not sure what's up with the slides
862.24|2.959|so one more thing you have to be careful
864.0|2.399|with some of the details here when you
865.199|4.0|are trying to get this to work so in
866.399|4.401|particular all of our cars
869.199|3.281|are slightly cockeyed in a slightly
870.8|3.039|different way and so if you're doing
872.48|2.56|this transformation from image space to
873.839|3.281|the output space you really need to know
875.04|3.52|what your camera calibration is and you
877.12|3.519|need to feed that in somehow into the
878.56|3.68|neural net and so you could definitely
880.639|3.681|just like concatenate the camera
882.24|4.08|calibrations of all of the images and
884.32|3.68|somehow feed them in with an mlp
886.32|3.28|but actually we found that we can do
888.0|4.0|much better by transforming all of the
889.6|4.799|images into a synthetic virtual camera
892.0|4.959|using a special rectification transform
894.399|4.961|so this is what that would look like
896.959|4.081|we insert a new layer right above the
899.36|3.52|image rectification layer it's a
901.04|3.44|function of camera calibration and it
902.88|4.399|translates all of the images into a
904.48|4.56|virtual common camera so if you were to
907.279|3.521|average up a lot of repeater images for
909.04|3.12|example which faced at the back
910.8|3.52|you would without doing this you would
912.16|3.76|get a kind of a blur but after doing the
914.32|5.6|rectification transformation you see
915.92|6.56|that the back mirror gets really crisp
919.92|4.64|so once you do this uh this improves the
922.48|4.08|performance quite a bit
924.56|3.44|so here are some of the results so on
926.56|3.12|the left we are seeing what we had
928.0|2.959|before and on the right we're now seeing
929.68|2.88|significantly improved predictions
930.959|3.201|coming directly out of the neural net
932.56|3.519|this is a multi-camera network
934.16|3.599|predicting directly in vector space and
936.079|3.361|you can see that it's basically night
937.759|3.921|and day
939.44|4.319|you can actually drive on this and uh
941.68|4.24|this took some time and some engineering
943.759|3.681|and incredible work from the ai team to
945.92|4.64|actually get this to work and deploy and
947.44|3.12|make it efficient in the car
951.36|3.599|this also improved a lot of our object
952.88|3.6|detection so for example here in this
954.959|3.68|video i'm showing single camera
956.48|4.64|predictions in orange and multi-camera
958.639|4.56|predictions in blue and basically if you
961.12|3.76|if you can't predict these cars if you
963.199|3.121|are only seeing a tiny sliver of a car
964.88|2.879|so your detections are not going to be
966.32|2.639|very good and their positions are not
967.759|2.88|going to be good but a multi-camera
968.959|3.761|network does not have an issue
970.639|3.921|here's another video from a more nominal
972.72|4.559|sort of situation and we see that as
974.56|4.719|these cars in this tight space cross
977.279|3.601|camera boundaries there's a lot of jank
979.279|2.961|that enters into the predictions and
980.88|2.8|basically the whole setup just doesn't
982.24|2.88|make sense especially for very large
983.68|2.959|vehicles like this one and we can see
985.12|3.12|that the multi-camera networks struggle
986.639|3.841|significantly less with these kinds of
988.24|3.44|predictions
990.48|2.56|okay so at this point we have
991.68|3.44|multi-camera networks and they're giving
993.04|3.84|predictions directly in vector space but
995.12|4.399|we are still operating at every single
996.88|3.92|instant in time completely independently
999.519|2.56|so very quickly we discovered that
1000.8|3.039|there's a large number of predictions we
1002.079|3.281|want to make that actually require the
1003.839|3.36|video context and we need to somehow
1005.36|3.839|figure out how to feed this into the net
1007.199|4.241|so in particular is this car parked or
1009.199|3.521|not is it moving how fast is it moving
1011.44|3.44|is it still there even though it's
1012.72|3.52|temporarily occluded or for example if
1014.88|2.399|i'm trying to predict the road geometry
1016.24|2.8|ahead
1017.279|3.601|it's very helpful to know of the signs
1019.04|3.359|or the road markings that i saw 50
1020.88|2.319|meters ago
1022.399|2.481|so
1023.199|3.36|we try to develop
1024.88|2.959|we try to insert video modules into our
1026.559|2.321|neural network architecture and this is
1027.839|2.321|kind of one of the solutions that we've
1028.88|2.559|converged on
1030.16|3.12|so we have the multi-scale features as
1031.439|3.681|we had them from before and what we are
1033.28|3.679|going to now insert is a feature queue
1035.12|3.52|module that is going to cache some of
1036.959|3.36|these features over time
1038.64|4.24|and then a video module that is going to
1040.319|4.401|fuse this information temporally and
1042.88|3.679|then we're going to continue into the
1044.72|3.52|heads that do the decoding
1046.559|3.441|now i'm going to go into both of these
1048.24|3.2|blocks one by one
1050.0|3.28|also in addition notice here that we are
1051.44|2.96|also feeding in the kinematics uh this
1053.28|2.639|is basically the velocity and the
1054.4|3.84|acceleration that's telling us about how
1055.919|3.841|the car is moving so not only are not
1058.24|3.36|only are we going to keep track of what
1059.76|4.72|we're seeing from all the cameras but
1061.6|4.0|also how the car has traveled
1064.48|2.8|so here's the feature queue and the
1065.6|4.24|rough layout of it we are basically
1067.28|4.56|concatenating these features um
1069.84|3.199|over time and the kinematics of how the
1071.84|2.959|car has moved
1073.039|3.921|and the positional encodings and that's
1074.799|3.361|being concatenated encoded and stored in
1076.96|2.32|a feature queue
1078.16|2.879|and that's going to be consumed by a
1079.28|3.759|video module now there's a few details
1081.039|3.361|here again to get right so in particular
1083.039|3.76|with respect to the pop and push
1084.4|3.279|mechanisms and when do you push and how
1086.799|3.12|and
1087.679|4.401|especially when do you push basically so
1089.919|4.64|here's a cartoon diagram illustrating
1092.08|4.16|some of the challenges here there's
1094.559|2.881|going to be the ego cars coming from the
1096.24|3.28|bottom and coming up to this
1097.44|3.92|intersection here and then traffic is
1099.52|2.96|going to start crossing in front of us
1101.36|3.12|and it's going to temporarily start
1102.48|3.04|occluding some of the cars ahead and
1104.48|2.24|then we're going to be stuck at this
1105.52|2.72|intersection for a while and just
1106.72|3.28|waiting our turn this is something that
1108.24|3.36|happens all the time and is a cartoon
1110.0|2.4|representation of some of the challenges
1111.6|2.8|here
1112.4|3.36|so number one with respect to
1114.4|3.36|the feature queue and when we want to
1115.76|3.52|push into a queue obviously we'd like to
1117.76|3.36|have some kind of a time-based queue
1119.28|4.399|where for example we entered features
1121.12|4.16|into the queue say every 27 milliseconds
1123.679|3.441|and so if a car gets temporarily
1125.28|4.16|occluded then the neural network now has
1127.12|4.88|the power to be able to look and
1129.44|3.92|reference the memory in time and and
1132.0|2.799|learn the association that hey even
1133.36|3.52|though this thing looks occluded right
1134.799|3.841|now there's a record of it in my
1136.88|3.36|previous features and i can use this to
1138.64|2.88|still make a detection
1140.24|2.64|so that's kind of like the more obvious
1141.52|4.399|one but the one that we also discovered
1142.88|3.919|is necessary in our case is for example
1145.919|3.681|suppose you're trying to make
1146.799|4.481|predictions about the road surface and
1149.6|3.36|the road geometry ahead and you're
1151.28|3.84|trying to predict that i'm in a turning
1152.96|3.68|lane and the lane next to us is going
1155.12|2.64|straight
1156.64|2.64|then
1157.76|2.96|it's really necessary to know about the
1159.28|3.92|line markings and the signs and
1160.72|4.079|sometimes they occur a long time ago and
1163.2|3.92|so if you only have a time-based queue
1164.799|4.321|you may forget the features while you're
1167.12|3.439|waiting at your red light so in addition
1169.12|3.6|to a time-based q we also have a
1170.559|4.721|space-based queue so we push every time
1172.72|4.319|the car travels a certain fixed distance
1175.28|3.279|so some of these details actually can
1177.039|2.64|matter quite a bit and so in this case
1178.559|3.281|we have a time-based queue and a
1179.679|4.481|space-based queue to cache our features
1181.84|4.0|and that continues into the video module
1184.16|3.92|now for the video module we looked at a
1185.84|4.24|number of possibilities of how to fuse
1188.08|3.44|this information temporally so we looked
1190.08|3.68|at three-dimensional convolutions
1191.52|3.279|transformers axial transformers in an
1193.76|2.88|effort to try to make them more
1194.799|3.281|efficient recurrent neural networks of a
1196.64|3.12|large number of flavors
1198.08|2.88|but the one that we actually like quite
1199.76|3.68|a bit as well and i want to spend some
1200.96|4.56|time on is a spatial recurrent neural
1203.44|4.08|network video module and so what we're
1205.52|3.6|doing here is
1207.52|2.72|because of the structure of the problem
1209.12|2.88|we're driving on two-dimensional
1210.24|3.36|surfaces we can actually organize the
1212.0|3.52|hidden state into a two-dimensional
1213.6|3.76|lattice and then as the car is driving
1215.52|3.6|around we update only the parts that are
1217.36|4.0|near the car and where the car has
1219.12|4.24|visibility so as the car is driving
1221.36|4.16|around we are using the kinematics to
1223.36|3.52|integrate the position of the car in the
1225.52|4.88|hidden features
1226.88|5.12|grid and we are only updating the rnn at
1230.4|5.12|the points where we visit where we have
1232.0|5.36|uh that are nearby us sort of
1235.52|4.08|so here's an example of what that looks
1237.36|2.24|like
1240.08|2.719|here what i'm going to show you is the
1241.36|2.319|car driving around
1242.799|3.12|and
1243.679|5.041|we're looking at the hidden state of
1245.919|2.801|this rnn
1249.039|3.841|and these are different channels in the
1250.559|3.761|hidden state so you can see that this is
1252.88|2.88|after optimization and training this
1254.32|3.12|neural net you can see that some of the
1255.76|3.44|channels are keeping track of different
1257.44|4.16|aspects of the road like for example the
1259.2|4.56|centers of the road the edges the lines
1261.6|4.4|the road surface and so on
1263.76|4.24|here's another cool video of this so
1266.0|3.679|this is looking at the mean of the first
1268.0|4.4|10 channels in the hidden state for
1269.679|4.721|different uh traversals of different
1272.4|4.159|intersections and all i want you to see
1274.4|3.279|basically is that there's cool activity
1276.559|2.721|as the recurrent neural network is
1277.679|3.281|keeping track of what's happening at any
1279.28|3.12|point in time and you can imagine that
1280.96|3.44|we've now given the power to the neural
1282.4|3.68|network to actually selectively read and
1284.4|3.12|write to this memory so for example if
1286.08|3.2|there's a car right next to us and is
1287.52|3.76|occluding some parts of the road then
1289.28|3.92|now the network has a has the ability to
1291.28|3.279|not write to those locations but when
1293.2|3.2|the car goes away and we have a really
1294.559|3.201|good view then the recurring neural net
1296.4|3.04|can say okay we have very clear
1297.76|3.039|visibility we definitely want to write
1299.44|3.44|information about what's in that part of
1300.799|5.041|space
1302.88|4.96|here's a few predictions that show
1305.84|3.36|what this looks like
1307.84|3.12|so here we are making predictions about
1309.2|3.44|the road boundaries in red intersection
1310.96|3.599|areas in blue
1312.64|3.36|road centers and so on so we're only
1314.559|3.921|showing a few of the predictions here
1316.0|4.24|just to keep the visualization clean
1318.48|3.36|um
1320.24|4.559|and yeah this is this is done by the
1321.84|4.959|spatial rnn and this is only showing a
1324.799|4.081|single clip a single traversal but you
1326.799|3.76|can imagine there could be multiple
1328.88|2.88|trips through here and basically number
1330.559|2.801|of cars a number of clips could be
1331.76|3.52|collaborating to build this map
1333.36|4.559|basically an effectively an hd map
1335.28|5.12|except it's not in the space of explicit
1337.919|3.76|items it's in a space of features of a
1340.4|4.48|recurring neural network which is kind
1341.679|3.201|of cool i haven't seen that before
1345.2|4.24|the video networks also improved our
1347.76|3.68|object detection quite a bit so in this
1349.44|3.52|example i want to show you a case where
1351.44|3.52|there are two cars
1352.96|3.92|over there and one car is going to drive
1354.96|3.04|by and occlude them briefly so look at
1356.88|3.52|what's happening with the single frame
1358.0|5.36|and the video predictions as the cars
1360.4|2.96|pass in front of us
1365.679|3.681|yeah so that makes a lot of sense so a
1367.76|3.039|quick
1369.36|3.04|playthrough through what's happening
1370.799|3.681|when both of them are in view the
1372.4|3.92|predictions are roughly equivalent and
1374.48|2.72|you are seeing multiple orange boxes
1376.32|2.239|because they're coming from different
1377.2|2.64|cameras
1378.559|3.36|um
1379.84|3.76|when they are occluded the single frame
1381.919|3.681|networks drop the detection but the
1383.6|4.079|video module remembers it and we can
1385.6|4.079|persist the cars and then when they are
1387.679|4.401|only partially occluded the single frame
1389.679|3.841|network is forced to make its best guess
1392.08|2.8|about what it's seeing and it's forced
1393.52|3.039|to make a prediction and it makes a
1394.88|3.679|really terrible prediction but the video
1396.559|2.881|module knows that there's only a partial
1398.559|2.961|uh
1399.44|3.599|that you know it has the information and
1401.52|3.76|knows that this is not a very easily
1403.039|4.161|visible uh part right now and doesn't
1405.28|3.6|actually take that into account
1407.2|3.12|we also saw significant improvements in
1408.88|3.6|our ability to estimate depth and of
1410.32|4.239|course especially velocity so here i am
1412.48|4.48|showing a clip from our remove the radar
1414.559|4.881|push where we are seeing the radar depth
1416.96|3.599|and velocity in green and we were trying
1419.44|2.64|to
1420.559|3.761|match or even surpass of course the
1422.08|5.28|signal just from video networks alone
1424.32|4.64|and what you're seeing here is in
1427.36|4.0|orange we are seeing a single frame
1428.96|4.24|performance and in blue we are seeing
1431.36|3.6|again video modules and so you see that
1433.2|3.76|the quality of depth is much higher and
1434.96|3.36|for velocity the orange signal of course
1436.96|2.959|you can't get velocity out of a single
1438.32|3.52|frame network so we use we just
1439.919|3.521|differentiate depth to get that but the
1441.84|4.4|video module actually is basically right
1443.44|4.4|on top of the radar signal and so we
1446.24|3.52|found that this worked extremely well
1447.84|3.92|for us
1449.76|3.279|so here's putting everything together
1451.76|3.6|this is what our architectural roughly
1453.039|4.88|looks like today so
1455.36|4.08|we have raw images feeding on the bottom
1457.919|3.521|they go through a rectification layer to
1459.44|4.0|correct for camera calibration and put
1461.44|4.239|everything into a common uh virtual
1463.44|4.4|camera we pass them through
1465.679|3.521|regnets residual networks to process
1467.84|3.36|them into a number of features at
1469.2|3.839|different scales we fuse the multi-scale
1471.2|2.959|information with by-fpn this goes
1473.039|2.88|through a transformer module to
1474.159|3.361|re-represent it into the vector space in
1475.919|3.921|the output space this feeds into a
1477.52|3.84|feature queue in time or space that gets
1479.84|3.76|processed by a video module like the
1481.36|3.84|spatial rnn and then continues into the
1483.6|3.12|branching structure of the hydra net
1485.2|2.88|with trunks and heads for all the
1486.72|3.52|different tasks
1488.08|3.28|and so that's the architecture roughly
1490.24|2.08|what it looks like today and on the
1491.36|3.199|right you are seeing some of its
1492.32|4.16|predictions uh sort of visualize both in
1494.559|3.281|a top-down vector space and also in
1496.48|4.079|images
1497.84|4.319|so definitely uh this architecture has
1500.559|3.761|definitely complexified from just a very
1502.159|3.681|simple image based single network about
1504.32|3.52|three or four years ago and continues to
1505.84|2.88|evolve um it's definitely quite
1507.84|2.24|impressive now there's still
1508.72|3.199|opportunities for improvements that the
1510.08|3.52|team is actively working on for example
1511.919|3.76|you'll notice that our fusion of time
1513.6|3.84|and space is fairly late in neural
1515.679|3.681|network terms so maybe we can actually
1517.44|3.68|do earlier fusion of space or time and
1519.36|4.0|do for example cost volumes or optical
1521.12|4.159|flow-like networks on the bottom
1523.36|3.36|or for example our outputs are dense
1525.279|2.88|rasters and it's actually pretty
1526.72|3.439|expensive to post-process some of these
1528.159|3.281|dense rasters in the car and of course
1530.159|3.041|we are under very strict latency
1531.44|3.2|requirements so this is not ideal we
1533.2|2.8|actually are looking into all kinds of
1534.64|3.44|ways of predicting just the sparse
1536.0|3.76|structure of the road maybe like you
1538.08|3.199|know point by point or in some other
1539.76|2.64|fashion that is
1541.279|3.441|that doesn't require expensive
1542.4|4.159|post-processing
1544.72|3.92|but this basically is how you achieve a
1546.559|4.321|very nice vector space and now i believe
1548.64|5.36|ashok is going to talk about how we can
1550.88|5.949|run playing control on top of it
1554.0|2.829|[Applause]