start_time|end_time|text
4.339|6.76|okay hello everyone I am Andre I am the
8.79|3.479|director of AI at Tesla and I'm very
11.099|3.75|excited to be here to tell you a little
12.269|3.78|bit about PI torch and how we use PI
14.849|3.69|tours to train your all networks for the
16.049|3.871|auto pilot now I'm Pierce to do a bit of
18.539|5.791|a show of hands how many of you actually
19.92|6.06|own the Tesla okay a few and how many of
24.33|5.099|you have used or experienced the
25.98|9.0|autopilot the product okay thank you
29.429|8.601|yeah so let's see so for those of you
34.98|5.19|who may not be familiar with autopilot
38.03|5.02|the basic functionality of the autopilot
40.17|5.909|is that it keeps the car in the lane and
43.05|6.39|it keeps the car also away from the
46.079|4.561|vehicle wait ahead of you and then some
49.44|2.25|of the more advanced functionality that
50.64|3.239|we've been building for the autopilot
51.69|3.779|includes navigating on a pilot which
53.879|3.511|allows you to set down a pin somewhere
55.469|4.171|on the map and then as long as you stick
57.39|3.78|to highway the car will do all of the
59.64|2.849|lane changes automatically and it will
61.17|3.36|take all the right Forks to get you
62.489|4.621|there so that's what navigating
64.53|4.35|autopilot with smart summon which we
67.11|3.299|only released about two weeks ago you
68.88|3.66|can summon the car to you in the parking
70.409|3.96|lot so you hold down come to me and the
72.54|3.119|car comes out of its parking spot and it
74.369|3.93|will come find you in the parking lot
75.659|5.521|you get in like royalty and it's an
78.299|5.07|amazing magical feature more broadly the
81.18|3.96|team is very interested in pursuing kind
83.369|3.091|of developing fulsol driving capability
85.14|6.36|so that's what everyone is focused on in
86.46|6.69|the team now famously perhaps we don't
91.5|3.45|use lidar and we don't use high division
93.15|3.359|high-definition maps so everything that
94.95|2.64|we built for the autopilot is basically
96.509|2.851|based on computer vision machine
97.59|3.029|learning on the raw video streams that
99.36|2.64|come from the eight cameras that
100.619|3.481|surround the vehicle so this is an
102.0|4.049|example of what we might see in one
104.1|2.82|single instant and we process this as
106.049|5.011|you might imagine with a lot of
106.92|6.6|convolutional networks now tesla is a
111.06|3.78|fairly vertically integrated company and
113.52|2.55|that's also true when it comes to the
114.84|2.79|intelligence of the auto pilot
116.07|4.53|so in particular of course we build our
117.63|4.529|own cars and we arrange the sensors
120.6|3.059|around the vehicle but then also we
122.159|3.631|collect all of our data we label all of
123.659|4.44|the data we train it on on premise GPU
125.79|4.65|clusters and then of course we take it
128.099|4.11|through the entire stack we run these
130.44|2.879|networks on our own custom hardware that
132.209|3.181|we develop in how
133.319|3.54|and then of course we are in charge of
135.39|4.29|the full lifecycle of these features so
136.859|6.091|we deploy them to our fleet of almost
139.68|4.709|3/4 million cars right now and we look
142.95|3.959|at telemetry and try to improve the
144.389|5.55|feature over time so we kind of close
146.909|4.2|the loop on on this so I would like to
149.939|3.27|slightly dive into some of the
151.109|4.11|distribution that we employ in the team
153.209|3.75|so the bread and butter for us is of
155.219|2.91|course analyzing images so here's an
156.959|2.041|image in order to drive in this
158.129|2.28|environment you actually have to
159.0|3.81|understand a lot about this environment
160.409|3.901|so perhaps we have to understand the
162.81|3.329|traffic lights the lane line markings
164.31|3.75|cars and so on so you end up in this
166.139|3.361|very massively multitask setting very
168.06|3.84|quickly where you just have to know a
169.5|6.03|lot about the scene so all over a lot of
171.9|5.369|our networks take on this outline here
175.53|4.049|where you have kind of a shared backbone
177.269|3.81|that has a number of tasks hanging off
179.579|2.821|of it and just to give you an idea of
181.079|3.3|the workflows in the kinds of networks
182.4|4.049|these are typically a ResNet 50 like
184.379|3.661|backbones running on roughly a thousand
186.449|3.481|five thousand images and then they have
188.04|2.729|these heads of these structures that
189.93|2.22|that makes sense
190.769|2.731|and of course we're doing this partly
192.15|2.94|because we can't afford to have neural
193.5|4.379|networks for every single task because
195.09|4.53|there's many many tasks almost almost
197.879|3.211|100 tasks and so we have to amortize
199.62|3.299|some of that computation so we put the
201.09|4.259|most shared backbones so here's some
202.919|4.141|examples of what these networks that we
205.349|3.63|call Hydra Nets because of their shared
207.06|4.199|backbone and multiple heads what these
208.979|6.5|Hydra Nets might look like is this video
211.259|4.22|playing it's not
219.38|3.15|okay I'm just going to go to the next
221.18|3.06|video that was going to show you some
222.53|3.24|lane line markings and so on this is a
224.24|2.79|video showing you some road edges that
225.77|2.58|we are interested in for the purposes of
227.03|3.48|smart summon because we have to
228.35|3.81|understand where we can be in in this
230.51|3.72|environment so we want to avoid the
232.16|3.93|curbs in this case now here we are
234.23|3.18|making predictions in the image and then
236.09|3.09|we are of course casting them out and
237.41|3.78|stitching them up across space and time
239.18|2.94|to understand a sort of the layout of
241.19|2.94|the scene around us
242.12|4.47|so here's an example of this occupancy
244.13|4.2|grid we're showing just the road edges
246.59|3.33|and how they get projected and the car
248.33|3.24|winds its path around this parking lot
249.92|3.75|while the person is summoning it and
251.57|5.94|it's just trying to find its way towards
253.67|7.08|the goal through this parking lot so
257.51|4.92|here's how things get stitched up now so
260.75|3.12|far if I've only talked about in your
262.43|3.45|networks that run on independent images
263.87|3.99|but of course very quickly you run
265.88|3.6|across tasks that actually have to be a
267.86|3.18|function of multiple images at the same
269.48|3.51|time so for example if you're trying to
271.04|3.15|estimate depth of any of these images it
272.99|3.33|might actually be very helpful to have
274.19|3.78|access to the other views of that same
276.32|3.51|scene in order to predict the depth at
277.97|3.36|every individual pixel or if you're
279.83|2.55|trying to predict the road layout or if
281.33|2.31|you're trying to steer the wheel or
282.38|2.88|something like that you might actually
283.64|3.51|need to borrow features from multiple
285.26|3.06|other hydro Nets so what this looks like
287.15|2.82|is we have all of these different hydro
288.32|2.85|Nets for different cameras but then you
289.97|2.91|might want to pull in some of the
291.17|3.63|features from these hydro Nets and go to
292.88|3.99|a second round of processing optionally
294.8|3.96|recurrent and actually produce something
296.87|2.88|like a road layout prediction so this is
298.76|2.46|an example of what a road layout
299.75|4.83|prediction might look like for the
301.22|5.22|autopilot here we are plugging in three
304.58|3.51|cameras simultaneously into a neural
306.44|3.93|network and the network's predictions
308.09|4.02|are not anymore in the image space they
310.37|3.12|are in the top-down space so we're
312.11|2.97|looking at the predictions of this
313.49|2.88|network in particular here we are
315.08|3.3|showing some of the predictions related
316.37|3.72|to the corridors that are available in
318.38|2.91|this parking lot where the intersections
320.09|3.06|are and what the orientations of all of
321.29|3.9|these things are and so the stitching up
323.15|3.75|now doesn't happen sort of in a C++ code
325.19|3.6|base the stitching up across space and
326.9|4.08|time happens inside the recurrent neural
328.79|4.32|network so more generally what our
330.98|3.27|networks start to look like for all of
333.11|2.79|these different tasks and what we're
334.25|3.54|converging on is it looks something like
335.9|3.63|this we have eight Hydra nets for the
337.79|3.57|Aged tasks and they all produce all
339.53|3.36|kinds of intermediate predictions but in
341.36|3.39|addition to that the features from these
342.89|3.27|Hydra nets go into a second round of
344.75|2.79|processing there's potentially recurrent
346.16|3.66|and then we have more outputs that are
347.54|3.54|sort of in a top-down view and then
349.82|3.09|what's special about this is that this
351.08|3.75|is of course like a pretty large single
352.91|3.6|network and every single task
354.83|3.72|sub-samples parts of this network and
356.51|3.42|trains just that small piece so for
358.55|3.09|example we can be training object
359.93|3.54|detector online with cameras or we can
361.64|3.48|be training a depth network or we can be
363.47|4.05|training or layout network all these
365.12|4.59|tasks subsample the graph and train only
367.52|3.72|that portion and then if you've trained
369.71|4.02|Ricola neural network some videos you'll
371.24|4.41|quickly kind of notice that these are
373.73|4.68|not trivial training we're closed so as
375.65|4.38|an example if I want to back unroll this
378.41|3.48|graph in time and back propagate through
380.03|3.96|time maybe we have eight cameras we
381.89|4.35|unroll for 16 time steps use a bad-sized
383.99|4.92|of say 32 then we are going to be
386.24|4.47|holding in memory 4096 images and all of
388.91|4.2|their activations in a single forward
390.71|4.53|pass so very quickly your typical
393.11|3.54|distributed data parallel will will
395.24|4.26|break because you can't hold this amount
396.65|4.26|of memory this amount of activations in
399.5|3.18|memory of a single GP or even a single
400.91|4.26|node so a lot of our training
402.68|4.26|potentially has to combine some elements
405.17|3.57|of data distribute this this real data
406.94|4.47|parallel but also model parallelism and
408.74|4.77|so on it also gets kind of tricky in
411.41|3.9|terms of training these networks because
413.51|3.27|the typical simplest case might be a
415.31|3.39|round-robin training of different tasks
416.78|3.21|so your training task one then ever all
418.7|4.65|the workers in the pool or training task
419.99|5.34|1 then task 2 3 etc that gets out of
423.35|3.87|hand when you have a hundred tasks so
425.33|3.96|instead what might make a sense is to
427.22|3.6|actually have a pool of tasks and some
429.29|3.45|of the tasks are doing objects some of
430.82|3.24|the tasks are doing road layout sorry
432.74|2.91|some of the workers might be doing depth
434.06|3.51|and so on and these are all very
435.65|3.42|heterogeneous workflows but they coexist
437.57|2.849|and they're they're training different
439.07|2.76|pieces of the network at the same time
440.419|3.0|and then you can arrange them in
441.83|3.48|synchronous asynchronous way or play
443.419|4.021|with this to really get squeezed out all
445.31|3.72|the juice out of it but all in all if
447.44|3.78|you're trying to train all of the neural
449.03|4.23|networks for the autopilot is actually a
451.22|3.69|fairly expensive task in particular
453.26|3.84|today we would train 48 different
454.91|3.78|networks that make 1,000 different
457.1|4.05|predictions is just if you count the
458.69|4.86|number of output tensors and it takes
461.15|3.72|70,000 GPU hours to train to compile the
463.55|3.72|autopilot it leaves the neural network
464.87|4.98|stack so if you had a single node with 8
467.27|4.5|GPUs you would be training for a year so
469.85|3.36|it's a lot of networks and a lot of
471.77|3.45|predictions and a lot of them must work
473.21|3.78|and none of them can regress ever and
475.22|3.84|then you're not just training this once
476.99|3.69|you are you have to iterate on this so
479.06|2.85|of course there are researchers and
480.68|2.94|engineers in the team that actually have
481.91|3.569|to improve on this and so as you can
483.62|2.5|imagine we do a lot of neural hour
485.479|3.421|training
486.12|5.19|at scale to get this to actually work
488.9|3.64|and then we are automating a lot of the
491.31|2.63|workflows it's not just about the neural
492.54|2.73|network training itself but everything
493.94|2.8|surrounding that
495.27|2.85|so in particular we have to calibrate
496.74|3.54|all the different thresholds we have a
498.12|4.08|process for that we have a lot of in the
500.28|3.9|loop valve from our loop validation
502.2|3.42|other type of validation and evaluation
504.18|3.06|to make sure that none of these 1,000
505.62|4.35|different predictions that we make can
507.24|4.859|regress and so on and so the North Star
509.97|4.77|for the team though is all of this can
512.099|4.801|actually be automated quite well so
514.74|3.479|starting with the data set you can train
516.9|3.21|all the neural nets you can do all the
518.219|3.031|calibration the evaluation and you can
520.11|2.79|really start to see the continuous
521.25|2.76|integration of this and so the North
522.9|2.82|Star for the team is something we
524.01|3.87|internally somewhat jokingly refer to as
525.72|3.869|operation vacation and the idea is that
527.88|3.09|as long as the data labeling team is
529.589|2.94|around and they're curating and
530.97|2.97|improving our data sets then everything
532.529|2.611|else can in principle be automated and
533.94|3.57|so we could actually go on a vacation
535.14|3.449|and the autopilot improves by default so
537.51|4.38|that's something that we really try to
538.589|5.311|try to go towards in the team I would
541.89|5.13|like to also talk a little bit about the
543.9|5.1|inference aspect of this so because I
547.02|3.12|talked quite a bit about training as I
549.0|2.79|mentioned we have sort of our own
550.14|3.72|back-end that our Hardware team has
551.79|4.799|developed we call this the FST computer
553.86|5.16|it offers about 144 in Tate Terra ops
556.589|5.131|off capability compared to the GPUs that
559.02|4.23|we were using before we introduced this
561.72|4.2|chip this is roughly an order of
563.25|4.62|magnitude improvement with lower cost so
565.92|3.03|we use this in all the latest cars that
567.87|2.969|are now coming out of the production
568.95|4.98|line and we target all the neural
570.839|4.471|networks to these chips and the last
573.93|2.76|thing I wanted to also briefly allude to
575.31|3.06|as you'll notice here on the bottom we
576.69|3.6|have a GPU cluster the hardware team is
578.37|4.83|also working on a project we call dojo
580.29|5.13|and a dojo is a neural network training
583.2|3.99|computer and a chip and so we hope to do
585.42|4.95|the exact same thing for training as we
587.19|4.86|did for inference improve basically the
590.37|4.5|efficiency by roughly in order magnitude
592.05|4.05|at a lower cost but I'm not ready to
594.87|4.05|talk about more details in that project
596.1|4.56|just yet so in summary I talked about
598.92|3.419|the full lifecycle of developing these
600.66|3.54|neural hours for the autopilot and how
602.339|3.181|we own everything in-house the neural
604.2|3.75|network is actually fairly complicated
605.52|4.29|and large and we deal with a lot of
607.95|6.06|problems if we actually want to train
609.81|6.51|the beast but it's giving us some very
614.01|3.6|interesting results and the nice thing
616.32|3.09|about this is not only do we get to
617.61|2.159|train really awesome large networks but
619.41|2.399|we also
619.769|3.961|to ship them and so for example
621.809|5.161|navigating autopilot has now accumulated
623.73|5.279|1 billion miles it we've confirmed
626.97|4.229|200,000 lane changes and this is a
629.009|3.87|global product product across 50
631.199|3.81|countries or more now and so that's a
632.879|4.851|lot of forward passes out there of
635.009|4.8|neural networks and with smart summon
637.73|5.529|this is actually a bit of an outdated
639.809|4.89|number we now had 800,000 sessions of
643.259|4.02|people trying to call their car to them
644.699|5.221|and so it's incredible to work on such a
647.279|3.99|such an interesting product finally I
649.92|3.389|would like to thank the patrasche team
651.269|4.021|for being incredibly responsive and
653.309|3.361|helpful and sort of allowing us to
655.29|3.0|develop all these networks and really
656.67|3.209|train them at scale and then deployed in
658.29|4.63|the real world has been really an
659.879|4.991|interesting collaboration thank you
662.92|7.959|[Applause]
664.87|6.009|[Music]