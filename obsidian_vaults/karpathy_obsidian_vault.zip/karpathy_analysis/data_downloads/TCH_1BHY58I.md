start_time|end_time|text
0.64|2.64|hi everyone
1.92|3.28|today we are continuing our
3.28|3.599|implementation of makemore
5.2|3.359|now in the last lecture we implemented
6.879|4.001|the bigram language model and we
8.559|4.321|implemented it both using counts and
10.88|4.719|also using a super simple neural network
12.88|4.64|that had a single linear layer
15.599|3.68|now this is the
17.52|2.88|jupyter notebook that we built out last
19.279|2.401|lecture
20.4|2.879|and we saw that the way we approached
21.68|3.2|this is that we looked at only the
23.279|3.201|single previous character and we
24.88|3.36|predicted the distribution for the
26.48|3.84|character that would go next in the
28.24|3.999|sequence and we did that by taking
30.32|3.36|counts and normalizing them into
32.239|4.48|probabilities
33.68|4.879|so that each row here sums to one
36.719|3.68|now this is all well and good if you
38.559|2.961|only have one character of previous
40.399|3.441|context
41.52|3.76|and this works and it's approachable the
43.84|2.96|problem with this model of course is
45.28|3.04|that
46.8|3.279|the predictions from this model are not
48.32|4.48|very good because you only take one
50.079|6.0|character of context so the model didn't
52.8|5.12|produce very name like sounding things
56.079|3.841|now the problem with this approach
57.92|3.92|though is that if we are to take more
59.92|3.76|context into account when predicting the
61.84|4.24|next character in a sequence things
63.68|4.64|quickly blow up and this table the size
66.08|3.92|of this table grows and in fact it grows
68.32|2.799|exponentially with the length of the
70.0|2.24|context
71.119|2.801|because if we only take a single
72.24|3.6|character at a time that's 27
73.92|3.839|possibilities of context
75.84|3.919|but if we take two characters in the
77.759|3.841|past and try to predict the third one
79.759|4.0|suddenly the number of rows in this
81.6|5.04|matrix you can look at it that way
83.759|4.961|is 27 times 27 so there's 729
86.64|3.519|possibilities for what could have come
88.72|3.039|in the context
90.159|4.241|if we take three characters as the
91.759|5.761|context suddenly we have
94.4|5.679|20 000 possibilities of context
97.52|6.239|and so there's just way too many rows of
100.079|5.441|this matrix it's way too few counts
103.759|3.601|for each possibility and the whole thing
105.52|3.44|just kind of explodes and doesn't work
107.36|3.119|very well
108.96|3.439|so that's why today we're going to move
110.479|3.28|on to this bullet point here and we're
112.399|4.321|going to implement a multi-layer
113.759|4.481|perceptron model to predict the next uh
116.72|3.359|character in a sequence
118.24|3.6|and this modeling approach that we're
120.079|4.241|going to adopt follows this paper
121.84|4.559|benguetal 2003
124.32|3.76|so i have the paper pulled up here
126.399|3.601|now this isn't the very first paper that
128.08|3.519|proposed the use of multiglio
130.0|3.68|perceptrons or neural networks to
131.599|4.241|predict the next character or token in a
133.68|4.32|sequence but it's definitely one that is
135.84|4.16|uh was very influential around that time
138.0|4.0|it is very often cited to stand in for
140.0|3.76|this idea and i think it's a very nice
142.0|3.84|write-up and so this is the paper that
143.76|4.64|we're going to first look at and then
145.84|4.32|implement now this paper has 19 pages so
148.4|3.28|we don't have time to go into
150.16|3.04|the full detail of this paper but i
151.68|2.96|invite you to read it
153.2|3.84|it's very readable interesting and has a
154.64|3.76|lot of interesting ideas in it as well
157.04|3.52|in the introduction they describe the
158.4|3.919|exact same problem i just described and
160.56|3.36|then to address it they propose the
162.319|4.241|following model
163.92|4.24|now keep in mind that we are building a
166.56|3.52|character level language model so we're
168.16|4.48|working on the level of characters in
170.08|4.72|this paper they have a vocabulary of 17
172.64|4.319|000 possible words and they instead
174.8|3.28|build a word level language model but
176.959|2.481|we're going to still stick with the
178.08|3.2|characters but we'll take the same
179.44|4.079|modeling approach
181.28|4.0|now what they do is basically they
183.519|3.521|propose to take every one of these words
185.28|4.8|seventeen thousand words and they're
187.04|5.68|going to associate to each word a say
190.08|5.04|thirty dimensional feature vector
192.72|4.96|so every word is now
195.12|4.72|embedded into a thirty dimensional space
197.68|4.8|you can think of it that way so we have
199.84|4.0|17 000 points or vectors in a 30
202.48|3.28|dimensional space
203.84|3.36|and that's um you might imagine that's
205.76|3.119|very crowded that's a lot of points for
207.2|2.88|a very small space
208.879|2.321|now
210.08|2.56|in the beginning these words are
211.2|3.52|initialized completely randomly so
212.64|3.92|they're spread out at random
214.72|3.84|but then we're going to tune these
216.56|3.12|embeddings of these words using back
218.56|2.64|propagation
219.68|3.52|so during the course of training of this
221.2|3.52|neural network these points or vectors
223.2|3.44|are going to basically move around in
224.72|4.159|this space and you might imagine that
226.64|4.319|for example words that have very similar
228.879|3.601|meanings or that are indeed synonyms of
230.959|3.84|each other might end up in a very
232.48|3.92|similar part of the space and conversely
234.799|4.481|words that mean very different things
236.4|4.8|would go somewhere else in a space
239.28|4.08|now their modeling approach otherwise is
241.2|3.599|identical to ours they are using a
243.36|3.92|multi-layer neural network to predict
244.799|4.16|the next word given the previous words
247.28|3.36|and to train the neural network they are
248.959|3.84|maximizing the log likelihood of the
250.64|4.08|training data just like we did
252.799|3.921|so the modeling approach itself is
254.72|4.079|identical now here they have a concrete
256.72|3.519|example of this intuition
258.799|3.041|why does it work
260.239|3.52|basically suppose that for example you
261.84|3.76|are trying to predict a dog was running
263.759|4.321|in a blank
265.6|4.0|now suppose that the exact phrase a dog
268.08|3.679|was running in a
269.6|4.319|has never occurred in a training data
271.759|3.601|and here you are at sort of test time
273.919|2.401|later when the model is deployed
275.36|3.119|somewhere
276.32|5.04|and it's trying to make a sentence and
278.479|4.561|it's saying a dog was running in a blank
281.36|4.0|and because it's never encountered this
283.04|4.64|exact phrase in the training set you're
285.36|4.24|out of distribution as we say like you
287.68|4.56|don't have fundamentally any
289.6|4.4|reason to suspect
292.24|3.519|what might come next
294.0|3.52|but this approach actually allows you to
295.759|3.521|get around that because maybe you didn't
297.52|3.84|see the exact phrase a dog was running
299.28|3.76|in a something but maybe you've seen
301.36|4.8|similar phrases maybe you've seen the
303.04|4.64|phrase the dog was running in a blank
306.16|2.8|and maybe your network has learned that
307.68|3.28|a and the
308.96|4.239|are like frequently are interchangeable
310.96|4.079|with each other and so maybe it took the
313.199|3.84|embedding for a and the embedding for
315.039|3.841|the and it actually put them like nearby
317.039|3.6|each other in the space and so you can
318.88|3.599|transfer knowledge through that
320.639|2.641|embedding and you can generalize in that
322.479|2.56|way
323.28|3.68|similarly the network could know that
325.039|3.6|cats and dogs are animals and they
326.96|3.76|co-occur in lots of very similar
328.639|3.84|contexts and so even though you haven't
330.72|3.44|seen this exact phrase
332.479|2.72|or if you haven't seen exactly walking
334.16|3.36|or running
335.199|3.921|you can through the embedding space
337.52|4.56|transfer knowledge and you can
339.12|4.48|generalize to novel scenarios
342.08|2.88|so let's now scroll down to the diagram
343.6|3.76|of the neural network
344.96|4.959|they have a nice diagram here
347.36|4.399|and in this example we are taking three
349.919|3.28|previous words
351.759|2.241|and we are trying to predict the fourth
353.199|2.72|word
354.0|3.68|in a sequence
355.919|4.481|now these three previous words as i
357.68|5.2|mentioned uh we have a vocabulary of 17
360.4|4.4|000 um possible words
362.88|3.039|so every one of these
364.8|4.48|basically basically
365.919|5.84|are the index of the incoming word
369.28|7.56|and because there are 17 000 words this
371.759|5.081|is an integer between 0 and 16999
377.199|3.681|now there's also a lookup table that
379.36|4.0|they call c
380.88|5.039|this lookup table is a matrix that is 17
383.36|3.92|000 by say 30.
385.919|3.681|and basically what we're doing here is
387.28|4.4|we're treating this as a lookup table
389.6|4.64|and so every index is
391.68|3.6|plucking out a row of this embedding
394.24|3.2|matrix
395.28|4.479|so that each index is converted to the
397.44|5.44|30 dimensional vector that corresponds
399.759|5.841|to the embedding vector for that word
402.88|5.92|so here we have the input layer of 30
405.6|5.039|neurons for three words making up 90
408.8|3.36|neurons in total
410.639|4.241|and here they're saying that this matrix
412.16|4.08|c is shared across all the words so
414.88|4.48|we're always indexing into the same
416.24|4.6|matrix c over and over um
419.36|3.92|for each one of these
420.84|4.359|words next up is the hidden layer of
423.28|4.4|this neural network the size of this
425.199|4.641|hidden neural layer of this neural net
427.68|3.519|is a hoppy parameter so we use the word
429.84|2.96|hyperparameter when it's kind of like a
431.199|4.081|design choice up to the designer of the
432.8|4.0|neural net and this can be as large as
435.28|3.919|you'd like or as small as you'd like so
436.8|3.839|for example the size could be a hundred
439.199|4.0|and we are going to go over multiple
440.639|3.921|choices of the size of this hidden layer
443.199|2.801|and we're going to evaluate how well
444.56|3.759|they work
446.0|4.0|so say there were 100 neurons here all
448.319|4.641|of them would be fully connected to the
450.0|5.759|90 words or 90 um
452.96|4.88|numbers that make up these three words
455.759|4.321|so this is a fully connected layer
457.84|4.24|then there's a 10 inch long linearity
460.08|4.32|and then there's this output layer and
462.08|3.76|because there are 17 000 possible words
464.4|4.239|that could come next
465.84|5.44|this layer has 17 000 neurons
468.639|6.081|and all of them are fully connected to
471.28|4.8|all of these neurons in the hidden layer
474.72|3.84|so there's a lot of parameters here
476.08|3.76|because there's a lot of words so most
478.56|3.12|computation is here this is the
479.84|4.88|expensive layer
481.68|5.199|now there are 17 000 logits here so on
484.72|3.759|top of there we have the softmax layer
486.879|3.961|which we've seen in our previous video
488.479|4.241|as well so every one of these logits is
490.84|4.28|exponentiated and then everything is
492.72|4.56|normalized to sum to 1 so that we have a
495.12|4.72|nice probability distribution for the
497.28|4.16|next word in the sequence
499.84|3.12|now of course during training we
501.44|4.24|actually have the label we have the
502.96|4.0|identity of the next word in a sequence
505.68|5.04|that word
506.96|5.759|or its index is used to pluck out the
510.72|4.08|probability of that word
512.719|4.32|and then we are maximizing the
514.8|3.84|probability of that word
517.039|2.721|with respect to the parameters of this
518.64|2.72|neural net
519.76|4.32|so the parameters are the weights and
521.36|4.479|biases of this output layer
524.08|5.04|the weights and biases of the hidden
525.839|4.961|layer and the embedding lookup table c
529.12|3.2|and all of that is optimized using back
530.8|4.479|propagation
532.32|4.72|and these uh dashed arrows ignore those
535.279|3.041|uh that represents a variation of a
537.04|2.799|neural nut that we are not going to
538.32|2.88|explore in this video
539.839|2.641|so that's the setup and now let's
541.2|2.96|implement it
542.48|3.039|okay so i started a brand new notebook
544.16|3.6|for this lecture
545.519|3.921|we are importing pytorch and we are
547.76|2.96|importing matplotlib so we can create
549.44|3.68|figures
550.72|4.48|then i am reading all the names into a
553.12|4.96|list of words like i did before and i'm
555.2|5.12|showing the first eight right here
558.08|4.72|keep in mind that we have a 32 000 in
560.32|3.68|total these are just the first eight
562.8|2.88|and then here i'm building out the
564.0|4.24|vocabulary of characters and all the
565.68|5.599|mappings from the characters as strings
568.24|4.48|to integers and vice versa
571.279|3.041|now the first thing we want to do is we
572.72|2.799|want to compile the data set for the
574.32|3.519|neural network
575.519|5.601|and i had to rewrite this code um i'll
577.839|5.201|show you in a second what it looks like
581.12|3.839|so this is the code that i created for
583.04|3.6|the dataset creation so let me first run
584.959|3.521|it and then i'll briefly explain how
586.64|3.44|this works
588.48|3.919|so first we're going to define something
590.08|4.08|called block size and this is basically
592.399|3.601|the context length of how many
594.16|3.84|characters do we take to predict the
596.0|3.92|next one so here in this example we're
598.0|4.0|taking three characters to predict the
599.92|4.4|fourth one so we have a block size of
602.0|4.56|three that's the size of the block that
604.32|5.6|supports the prediction
606.56|5.839|then here i'm building out the x and y
609.92|5.2|the x are the input to the neural net
612.399|5.12|and the y are the labels for each
615.12|4.24|example inside x
617.519|3.76|then i'm airing over the first five
619.36|3.76|words i'm doing first five just for
621.279|3.601|efficiency while we are developing all
623.12|3.68|the code but then later we're going to
624.88|4.16|come here and erase this so that we use
626.8|4.039|the entire training set
629.04|4.88|so here i'm printing the word
630.839|5.161|emma and here i'm basically showing the
633.92|3.599|examples that we can generate the five
636.0|2.399|examples that we can generate out of the
637.519|3.601|single
638.399|3.68|um sort of word emma
641.12|2.959|so
642.079|3.841|when we are given the context of just uh
644.079|3.521|dot dot the first character in a
645.92|4.4|sequence is e
647.6|5.679|in this context the label is m
650.32|5.04|when the context is this the label is m
653.279|3.68|and so forth and so the way i build this
655.36|4.4|out is first i start with a padded
656.959|4.961|context of just zero tokens
659.76|5.04|then i iterate over all the characters i
661.92|5.28|get the character in the sequence and i
664.8|4.719|basically build out the array y of this
667.2|4.639|current character and the array x which
669.519|4.56|stores the current running context
671.839|5.44|and then here see i print everything and
674.079|4.88|here i um crop the context and enter the
677.279|5.361|new character in a sequence so this is
678.959|5.201|kind of like a rolling window of context
682.64|3.12|now we can change the block size here to
684.16|3.679|for example four
685.76|4.48|and in that case we'll be predicting the
687.839|3.921|fifth character given the previous four
690.24|3.68|or it can be five
691.76|4.8|and then it would look like this
693.92|3.68|or it can be say ten
696.56|2.48|and then it would look something like
697.6|3.359|this we're taking ten characters to
699.04|4.16|predict the eleventh one
700.959|4.56|and we're always padding with dots
703.2|4.72|so let me bring this back to three
705.519|4.481|just so that we have what we have here
707.92|3.68|in the paper
710.0|3.44|and finally the data set right now looks
711.6|3.84|as follows
713.44|4.48|from these five words we have created a
715.44|4.32|data set of 32 examples
717.92|4.08|and each input of the neural net is
719.76|3.92|three integers and we have a label that
722.0|2.56|is also an integer
723.68|2.959|y
724.56|4.24|so x looks like this
726.639|5.76|these are the individual examples
728.8|4.88|and then y are the labels
732.399|2.961|so
733.68|3.36|given this
735.36|3.84|let's now write a neural network that
737.04|4.16|takes these axes and predicts the y's
739.2|3.92|first let's build the embedding lookup
741.2|4.079|table c
743.12|3.76|so we have 27 possible characters and
745.279|3.041|we're going to embed them in a lower
746.88|4.48|dimensional space
748.32|5.6|in the paper they have 17 000 words and
751.36|7.12|they bet them in uh spaces as small
753.92|6.8|dimensional as 30. so they cram 17 000
758.48|4.88|words into 30 dimensional space in our
760.72|4.48|case we have only 27 possible characters
763.36|3.44|so let's grab them in something as small
765.2|3.28|as to start with for example a
766.8|3.279|two-dimensional space
768.48|2.72|so this lookup table will be random
770.079|4.081|numbers
771.2|4.879|and we'll have 27 rows and we'll have
774.16|4.32|two columns
776.079|4.161|right so each 20 each one of 27
778.48|3.52|characters will have a two-dimensional
780.24|5.279|embedding
782.0|5.839|so that's our matrix c of embeddings in
785.519|4.641|the beginning initialized randomly
787.839|4.641|now before we embed all of the integers
790.16|4.0|inside the input x using this lookup
792.48|3.44|table c
794.16|5.44|let me actually just try to embed a
795.92|5.919|single individual integer like say five
799.6|3.12|so we get a sense of how this works
801.839|2.401|now
802.72|3.679|one way this works of course is we can
804.24|3.599|just take the c and we can index into
806.399|4.0|row five
807.839|3.761|and that gives us a vector the fifth row
810.399|2.641|of c
811.6|3.12|and um
813.04|3.039|this is one way to do it
814.72|3.919|the other way that i presented in the
816.079|4.88|previous lecture is actually seemingly
818.639|3.681|different but actually identical so in
820.959|3.281|the previous lecture what we did is we
822.32|5.28|took these integers and we used the one
824.24|4.48|hot encoding to first encode them so f.1
827.6|3.6|hot
828.72|4.16|we want to encode integer 5 and we want
831.2|4.639|to tell it that the number of classes is
832.88|5.04|27 so that's the 26 dimensional vector
835.839|4.081|of all zeros except the fifth bit is
837.92|5.2|turned on
839.92|4.719|now this actually doesn't work
843.12|2.88|the reason is that
844.639|3.281|this input actually must be a doorstop
846.0|3.199|tensor
847.92|2.64|and i'm making some of these errors
849.199|3.521|intentionally just so you get to see
850.56|3.76|some errors and how to fix them
852.72|3.84|so this must be a tester not an int
854.32|4.639|fairly straightforward to fix we get a
856.56|5.68|one hot vector the fifth dimension is
858.959|5.68|one and the shape of this is 27.
862.24|4.24|and now notice that just as i briefly
864.639|4.481|alluded to in the previous video if we
866.48|5.359|take this one hot vector and we multiply
869.12|2.719|it by c
873.76|3.6|then
875.68|3.519|what would you expect
877.36|4.4|well number one
879.199|4.401|first you'd expect an error
881.76|3.6|because
883.6|2.72|expected scalar type long but found
885.36|3.2|float
886.32|3.84|so a little bit confusing but
888.56|3.6|the problem here is that one hot the
890.16|2.96|data type of it
892.16|4.4|is
893.12|5.92|long it's a 64-bit integer but this is a
896.56|5.04|float tensor and so pytorch doesn't know
899.04|4.479|how to multiply an int with a float and
901.6|4.72|that's why we had to explicitly cast
903.519|5.841|this to a float so that we can multiply
906.32|4.959|now the output actually here
909.36|3.36|is identical
911.279|3.761|and that it's identical because of the
912.72|4.559|way the matrix multiplication here works
915.04|4.799|we have the one hot um vector
917.279|4.401|multiplying columns of c
919.839|3.68|and because of all the zeros they
921.68|3.92|actually end up masking out everything
923.519|3.68|in c except for the fifth row which is
925.6|3.2|plucked out
927.199|2.64|and so we actually arrive at the same
928.8|2.56|result
929.839|3.68|and that tells you that
931.36|4.24|here we can interpret this first
933.519|4.081|piece here this embedding of the integer
935.6|4.479|we can either think of it as the integer
937.6|4.479|indexing into a lookup table c but
940.079|4.32|equivalently we can also think of this
942.079|4.32|little piece here as a first layer of
944.399|4.56|this bigger neural net
946.399|4.321|this layer here has neurons that have no
948.959|3.841|non-linearity there's no 10h they're
950.72|4.72|just linear neurons and their weight
952.8|4.959|matrix is c
955.44|4.079|and then we are encoding integers into
957.759|3.681|one hot and feeding those into a neural
959.519|3.12|net and this first layer basically
961.44|2.959|embeds them
962.639|3.521|so those are two equivalent ways of
964.399|3.841|doing the same thing we're just going to
966.16|3.119|index because it's much much faster and
968.24|4.159|we're going to discard this
969.279|4.881|interpretation of one hot inputs into
972.399|3.841|neural nets and we're just going to
974.16|4.16|index integers and create and use
976.24|4.64|embedding tables now embedding a single
978.32|4.959|integer like 5 is easy enough we can
980.88|3.6|simply ask pytorch to retrieve the fifth
983.279|4.401|row of c
984.48|5.599|or the row index five of c
987.68|5.2|but how do we simultaneously embed all
990.079|4.56|of these 32 by three integers stored in
992.88|3.44|array x
994.639|3.521|luckily pytorch indexing is fairly
996.32|4.8|flexible and quite powerful
998.16|6.239|so it doesn't just work to
1001.12|5.279|ask for a single element five like this
1004.399|4.081|you can actually index using lists so
1006.399|3.041|for example we can get the rows five six
1008.48|3.359|and seven
1009.44|4.319|and this will just work like this we can
1011.839|3.36|index with a list
1013.759|4.721|it doesn't just have to be a list it can
1015.199|5.361|also be a actually a tensor of integers
1018.48|5.12|and we can index with that
1020.56|5.359|so this is a integer tensor 567 and this
1023.6|4.8|will just work as well
1025.919|5.04|in fact we can also for example repeat
1028.4|3.76|row 7 and retrieve it multiple times
1030.959|3.201|and
1032.16|3.919|that same index will just get embedded
1034.16|3.279|multiple times here
1036.079|2.801|so here we are indexing with a
1037.439|4.0|one-dimensional
1038.88|3.959|tensor of integers but it turns out that
1041.439|3.681|you can also index with
1042.839|4.681|multi-dimensional tensors of integers
1045.12|5.36|here we have a two-dimensional in tensor
1047.52|7.12|of integers so we can simply just do c
1050.48|5.68|at x and this just works
1054.64|2.56|and the shape of this
1056.16|4.0|is
1057.2|4.479|32 by 3 which is the original shape and
1060.16|3.6|now for every one of those 32 by 3
1061.679|3.161|integers we've retrieved the embedding
1063.76|4.799|vector
1064.84|4.92|here so basically we have that as an
1068.559|5.761|example
1069.76|7.44|the 13th or example index 13
1074.32|4.4|the second dimension is the integer 1 as
1077.2|2.479|an example
1078.72|4.079|and so
1079.679|6.161|here if we do c of x which gives us that
1082.799|4.321|array and then we index into 13 by two
1085.84|3.76|of that array
1087.12|3.36|then we we get the embedding
1089.6|2.48|here
1090.48|2.319|and you can verify that
1092.08|3.52|c
1092.799|7.041|at one which is the integer at that
1095.6|6.079|location is indeed equal to this
1099.84|3.68|you see they're equal
1101.679|4.88|so basically long story short pytorch
1103.52|5.92|indexing is awesome and to embed
1106.559|4.721|simultaneously all of the integers in x
1109.44|3.68|we can simply do c of x
1111.28|3.759|and that is our embedding
1113.12|4.0|and that just works
1115.039|3.76|now let's construct this layer here the
1117.12|5.439|hidden layer
1118.799|6.0|so we have that w1 as i'll call it are
1122.559|3.441|these weights which we will initialize
1124.799|3.601|randomly
1126.0|3.6|now the number of inputs to this layer
1128.4|2.88|is going to be
1129.6|3.04|three times two right because we have
1131.28|2.399|two dimensional embeddings and we have
1132.64|3.52|three of them
1133.679|4.721|so the number of inputs is 6
1136.16|4.08|and the number of neurons in this layer
1138.4|4.48|is a variable up to us
1140.24|4.4|let's use 100 neurons as an example
1142.88|3.679|and then biases
1144.64|2.88|will be also initialized randomly as an
1146.559|4.641|example
1147.52|5.84|and let's and we just need 100 of them
1151.2|4.4|now the problem with this is we can't
1153.36|4.16|simply normally we would take the input
1155.6|4.959|in this case that's embedding and we'd
1157.52|4.72|like to multiply it with these weights
1160.559|3.841|and then we would like to add the bias
1162.24|3.679|this is roughly what we want to do
1164.4|3.36|but the problem here is that these
1165.919|4.0|embeddings are stacked up in the
1167.76|3.6|dimensions of this input tensor
1169.919|2.961|so this will not work this matrix
1171.36|4.0|multiplication because this is a shape
1172.88|4.24|32 by 3 by 2 and i can't multiply that
1175.36|4.64|by 6 by 100
1177.12|4.799|so somehow we need to concatenate these
1180.0|3.12|inputs here together so that we can do
1181.919|3.12|something along these lines which
1183.12|4.799|currently does not work
1185.039|5.681|so how do we transform this 32 by 3 by 2
1187.919|3.921|into a 32 by 6 so that we can actually
1190.72|2.079|perform
1191.84|2.8|this
1192.799|3.361|multiplication over here i'd like to
1194.64|2.8|show you that there are usually many
1196.16|3.519|ways of
1197.44|4.4|implementing what you'd like to do in
1199.679|4.081|torch and some of them will be faster
1201.84|4.4|better shorter etc
1203.76|4.159|and that's because torch is a very large
1206.24|3.2|library and it's got lots and lots of
1207.919|3.441|functions so if you just go to the
1209.44|4.72|documentation and click on torch you'll
1211.36|3.92|see that my slider here is very tiny and
1214.16|2.48|that's because there are so many
1215.28|2.48|functions that you can call on these
1216.64|3.44|tensors
1217.76|4.24|to transform them create them multiply
1220.08|4.8|them add them perform all kinds of
1222.0|6.48|different operations on them
1224.88|6.24|and so this is kind of like
1228.48|4.0|the space of possibility if you will
1231.12|3.52|now one of the things that you can do is
1232.48|4.079|if we can control here ctrl f for
1234.64|2.8|concatenate and we see that there's a
1236.559|3.921|function
1237.44|4.56|torque.cat short for concatenate
1240.48|4.64|and this concatenates the given sequence
1242.0|4.72|of tensors in a given dimension
1245.12|4.08|and these sensors must have the same
1246.72|5.52|shape etc so we can use the concatenate
1249.2|6.8|operation to in a naive way concatenate
1252.24|6.559|these three embeddings for each input
1256.0|5.039|so in this case we have m of
1258.799|4.321|amp of the shape and really what we want
1261.039|3.921|to do is we want to retrieve these three
1263.12|5.36|parts and concatenate them
1264.96|5.28|so we want to grab all the examples
1268.48|4.96|we want to grab
1270.24|4.319|first the zeroth
1273.44|3.119|index
1274.559|3.201|and then all of
1276.559|3.841|this
1277.76|6.56|so this plucks out
1280.4|6.0|the 32 by 2 embeddings of just the first
1284.32|4.239|word here
1286.4|4.48|and so basically we want this guy
1288.559|4.0|we want the first dimension and we want
1290.88|3.76|the second dimension
1292.559|3.841|and these are the three pieces
1294.64|3.36|individually
1296.4|4.159|and then we want to treat this as a
1298.0|5.6|sequence and we want to torch that cat
1300.559|5.041|on that sequence so this is the list
1303.6|3.12|tor.cat takes a
1305.6|2.88|sequence
1306.72|4.48|of tensors and then we have to tell it
1308.48|5.12|along which dimension to concatenate
1311.2|4.08|so in this case all these are 32 by 2
1313.6|4.559|and we want to concatenate not across
1315.28|4.72|dimension 0 by the cross dimension one
1318.159|3.76|so passing in one
1320.0|4.24|gives us a result
1321.919|3.441|the shape of this is 32 by 6 exactly as
1324.24|4.08|we'd like
1325.36|5.199|so that basically took 32 and squashed
1328.32|3.2|these by concatenating them into 32 by
1330.559|2.881|6.
1331.52|4.08|now this is kind of ugly because this
1333.44|4.239|code would not generalize if we want to
1335.6|4.079|later change the block size right now we
1337.679|4.561|have three inputs
1339.679|3.841|three words but what if we had five
1342.24|3.84|then here we would have to change the
1343.52|4.639|code because i'm indexing directly well
1346.08|5.599|torch comes to rescue again because that
1348.159|6.961|turns out to be a function called unbind
1351.679|3.441|and it removes a tensor dimension
1355.28|3.759|so it removes the tensor dimension
1356.72|3.68|returns a tuple of all slices along a
1359.039|2.64|given dimension
1360.4|3.44|without it
1361.679|4.0|so this is exactly what we need
1363.84|4.16|and basically when we call torch dot
1365.679|4.641|unbind
1368.0|3.679|torch dot unbind
1370.32|4.4|of m
1371.679|4.801|and pass in dimension
1374.72|4.56|1 index 1
1376.48|5.12|this gives us a list of
1379.28|3.2|a list of tensors exactly equivalent to
1381.6|2.559|this
1382.48|3.92|so running this
1384.159|3.361|gives us a line
1386.4|3.04|3
1387.52|5.039|and it's exactly this list and so we can
1389.44|5.52|call torch.cat on it
1392.559|4.321|and along the first dimension
1394.96|4.16|and this works
1396.88|4.24|and this shape is the same
1399.12|4.24|but now this is uh it doesn't matter if
1401.12|3.679|we have block size 3 or 5 or 10 this
1403.36|3.6|will just work
1404.799|4.161|so this is one way to do it but it turns
1406.96|3.76|out that in this case there's actually a
1408.96|3.92|significantly better and more efficient
1410.72|4.0|way and this gives me an opportunity to
1412.88|3.52|hint at some of the internals of
1414.72|3.199|torch.tensor
1416.4|3.759|so let's create
1417.919|4.64|an array here
1420.159|4.081|of elements from 0 to 17
1422.559|3.921|and the shape of this
1424.24|3.679|is just 18. it's a single picture of 18
1426.48|3.439|numbers
1427.919|5.041|it turns out that we can very quickly
1429.919|4.561|re-represent this as different sized and
1432.96|4.48|dimensional tensors
1434.48|4.8|we do this by calling a view
1437.44|4.719|and we can say that actually this is not
1439.28|6.32|a single vector of 18 this is a two by
1442.159|5.841|nine tensor or alternatively this is a
1445.6|4.559|nine by two tensor
1448.0|3.84|or this is actually a three by three by
1450.159|3.601|two tensor
1451.84|4.64|as long as the total number of elements
1453.76|5.2|here multiply to be the same
1456.48|5.04|this will just work and
1458.96|5.04|in pytorch this operation calling that
1461.52|4.48|view is extremely efficient
1464.0|3.84|and the reason for that is that
1466.0|4.48|in each tensor there's something called
1467.84|4.959|the underlying storage
1470.48|4.4|and the storage is just the numbers
1472.799|4.321|always as a one-dimensional vector and
1474.88|3.76|this is how this tensor is represented
1477.12|4.559|in the computer memory it's always a
1478.64|5.36|one-dimensional vector
1481.679|4.561|but when we call that view we are
1484.0|4.64|manipulating some of attributes of that
1486.24|4.72|tensor that dictate how this
1488.64|4.96|one-dimensional sequence is interpreted
1490.96|4.4|to be an n-dimensional tensor
1493.6|3.76|and so what's happening here is that no
1495.36|4.08|memory is being changed copied moved or
1497.36|3.199|created when we call that view the
1499.44|3.68|storage
1500.559|4.561|is identical but when you call that view
1503.12|4.72|some of the internal
1505.12|4.4|attributes of the view of the sensor are
1507.84|2.719|being manipulated and changed in
1509.52|2.8|particular that's something there's
1510.559|3.6|something called a storage offset
1512.32|3.68|strides and shapes and those are
1514.159|4.4|manipulated so that this one-dimensional
1516.0|4.559|sequence of bytes is seen as different
1518.559|4.161|and dimensional arrays
1520.559|4.72|there's a blog post here from eric
1522.72|4.8|called pi torch internals where he goes
1525.279|3.841|into some of this with respect to tensor
1527.52|2.8|and how the view of the tensor is
1529.12|3.28|represented
1530.32|4.0|and this is really just like a logical
1532.4|3.36|construct of representing the physical
1534.32|3.92|memory
1535.76|4.24|and so this is a pretty good um blog
1538.24|3.6|post that you can go into i might also
1540.0|4.4|create an entire video on the internals
1541.84|4.319|of torch tensor and how this works
1544.4|3.68|for here we just note that this is an
1546.159|4.4|extremely efficient operation
1548.08|5.04|and if i delete this and come back to
1550.559|4.801|our end
1553.12|4.96|we see that the shape of our end is 32
1555.36|5.199|by three by two but we can simply
1558.08|4.88|ask for pytorch to view this instead as
1560.559|4.801|a 32 by six
1562.96|4.64|and the way this gets flattened into a
1565.36|4.0|32 by six array
1567.6|3.28|just happens that
1569.36|3.12|these two
1570.88|3.52|get stacked up
1572.48|3.36|in a single row and so that's basically
1574.4|2.8|the concatenation operation that we're
1575.84|2.8|after
1577.2|3.2|and you can verify that this actually
1578.64|3.519|gives the exact same result as what we
1580.4|3.36|had before
1582.159|3.041|so this is an element y equals and you
1583.76|3.919|can see that all the elements of these
1585.2|5.599|two tensors are the same
1587.679|5.36|and so we get the exact same result
1590.799|3.36|so long story short we can actually just
1593.039|5.721|come here
1594.159|4.601|and if we just view this as a 32x6
1598.88|4.24|instead then this multiplication will
1600.799|3.441|work and give us the hidden states that
1603.12|2.799|we're after
1604.24|4.16|so if this is h
1605.919|5.12|then h shape is now
1608.4|5.04|the 100 dimensional activations for
1611.039|4.561|every one of our 32 examples
1613.44|4.479|and this gives the desired result let me
1615.6|4.88|do two things here number one let's not
1617.919|4.801|use 32 we can for example do something
1620.48|2.24|like
1623.0|4.44|m.shape at 0
1625.44|3.92|so that we don't hard code these numbers
1627.44|2.88|and this would work for any size of this
1629.36|2.559|amp
1630.32|3.839|or alternatively we can also do negative
1631.919|4.801|one when we do negative one pi torch
1634.159|3.76|will infer what this should be
1636.72|3.6|because the number of elements must be
1637.919|4.0|the same and we're saying that this is 6
1640.32|4.479|by church will derive that this must be
1641.919|4.88|32 or whatever else it is if m is of
1644.799|4.721|different size
1646.799|6.24|the other thing is here um
1649.52|5.68|one more thing i'd like to point out is
1653.039|4.561|here when we do the concatenation
1655.2|4.719|this actually is much less efficient
1657.6|3.76|because um this concatenation would
1659.919|3.36|create a whole new tensor with a whole
1661.36|3.52|new storage so new memory is being
1663.279|3.681|created because there's no way to
1664.88|3.6|concatenate tensors just by manipulating
1666.96|3.12|the view attributes
1668.48|3.84|so this is inefficient and creates all
1670.08|5.44|kinds of new memory
1672.32|4.88|uh so let me delete this now
1675.52|4.08|we don't need this
1677.2|4.24|and here to calculate h we want to also
1679.6|2.88|dot 10h
1681.44|2.959|of this
1682.48|4.559|to get our
1684.399|3.841|oops to get our h
1687.039|3.441|so these are now numbers between
1688.24|3.439|negative one and one because of the 10h
1690.48|3.52|and we have
1691.679|4.24|that the shape is 32 by 100
1694.0|3.6|and that is basically this hidden layer
1695.919|4.321|of activations here
1697.6|3.92|for every one of our 32 examples
1700.24|2.799|now there's one more thing i've lost
1701.52|2.879|over that we have to be very careful
1703.039|3.12|with and that this
1704.399|3.121|and that's this plus here
1706.159|4.561|in particular we want to make sure that
1707.52|5.84|the broadcasting will do what we like
1710.72|4.959|the shape of this is 32 by 100 and the
1713.36|4.24|ones shape is 100.
1715.679|4.321|so we see that the addition here will
1717.6|6.64|broadcast these two and in particular we
1720.0|7.2|have 32 by 100 broadcasting to 100.
1724.24|5.039|so broadcasting will align on the right
1727.2|4.719|create a fake dimension here so this
1729.279|5.441|will become a 1 by 100 row vector and
1731.919|5.281|then it will copy vertically
1734.72|4.16|for every one of these rows of 32 and do
1737.2|3.28|an element wise addition
1738.88|3.6|so in this case the correct thing will
1740.48|5.36|be happening because the same bias
1742.48|4.16|vector will be added to all the rows
1745.84|3.12|of
1746.64|4.639|this matrix so that is correct that's
1748.96|3.92|what we'd like and it's always good
1751.279|2.801|practice you just make sure
1752.88|3.279|so that you don't shoot yourself in the
1754.08|3.52|foot and finally let's create the final
1756.159|3.681|layer here
1757.6|5.04|so let's create
1759.84|5.04|w2 and v2
1762.64|4.32|the input now is 100
1764.88|4.88|and the output number of neurons will be
1766.96|4.8|for us 27 because we have 27 possible
1769.76|5.12|characters that come next
1771.76|4.88|so the biases will be 27 as well
1774.88|3.679|so therefore the logits which are the
1776.64|4.8|outputs of this neural net
1778.559|3.84|are going to be um
1781.44|5.68|h
1782.399|8.081|multiplied by w2 plus b2
1787.12|5.12|logistic shape is 32 by 27
1790.48|3.679|and the logits look
1792.24|3.439|good now exactly as we saw in the
1794.159|3.841|previous video we want to take these
1795.679|4.321|logits and we want to first exponentiate
1798.0|3.36|them to get our fake counts
1800.0|2.96|and then we want to normalize them into
1801.36|4.24|a probability
1802.96|3.92|so prob is counts divide
1805.6|4.959|and now
1806.88|5.6|counts dot sum along the first dimension
1810.559|3.84|and keep them as true exactly as in the
1812.48|3.52|previous video
1814.399|5.681|and so
1816.0|7.52|prob that shape now is 32 by 27
1820.08|6.4|and you'll see that every row of prob
1823.52|5.039|sums to one so it's normalized
1826.48|3.76|so that gives us the probabilities now
1828.559|3.681|of course we have the actual letter that
1830.24|4.0|comes next and that comes from this
1832.24|4.08|array y
1834.24|4.799|which we which we created during the
1836.32|4.56|dataset creation so why is this last
1839.039|3.281|piece here which is the identity of the
1840.88|3.919|next character in the sequence that we'd
1842.32|4.32|like to now predict
1844.799|3.681|so what we'd like to do now is just as
1846.64|4.639|in the previous video we'd like to index
1848.48|4.48|into the rows of prob and in each row
1851.279|3.841|we'd like to pluck out the probability
1852.96|4.0|assigned to the correct character
1855.12|5.36|as given here
1856.96|6.64|so first we have torch.range of 32 which
1860.48|5.28|is kind of like a iterator over
1863.6|3.92|numbers from 0 to 31
1865.76|3.279|and then we can index into prob in the
1867.52|2.68|following way
1869.039|3.76|prop in
1870.2|5.479|torch.range of 32 which iterates the
1872.799|6.48|roads and in each row we'd like to grab
1875.679|5.6|this column as given by y
1879.279|3.841|so this gives the current probabilities
1881.279|3.601|as assigned by this neural network with
1883.12|4.64|this setting of its weights
1884.88|4.64|to the correct character in the sequence
1887.76|3.2|and you can see here that this looks
1889.52|3.44|okay for some of these characters like
1890.96|3.52|this is basically 0.2
1892.96|4.68|but it doesn't look very good at all for
1894.48|6.0|many other characters like this is
1897.64|4.44|0.0701 probability and so the network
1900.48|3.199|thinks that some of these are extremely
1902.08|5.04|unlikely but of course we haven't
1903.679|5.281|trained the neural network yet so
1907.12|3.76|this will improve and ideally all of
1908.96|3.36|these numbers here of course are one
1910.88|2.96|because then we are correctly predicting
1912.32|3.199|the next character
1913.84|3.6|now just as in the previous video we
1915.519|3.841|want to take these probabilities we want
1917.44|3.52|to look at the lock probability
1919.36|2.72|and then we want to look at the average
1920.96|3.52|probability
1922.08|5.439|and the negative of it to create the
1924.48|5.76|negative log likelihood loss
1927.519|4.241|so the loss here is 17
1930.24|3.919|and this is the loss that we'd like to
1931.76|4.88|minimize to get the network to predict
1934.159|4.561|the correct character in the sequence
1936.64|4.159|okay so i rewrote everything here and
1938.72|4.24|made it a bit more respectable so here's
1940.799|3.76|our data set here's all the parameters
1942.96|3.36|that we defined
1944.559|3.12|i'm now using a generator to make it
1946.32|3.04|reproducible
1947.679|3.761|i clustered all the parameters into a
1949.36|4.159|single list of parameters so that for
1951.44|3.359|example it's easy to count them and see
1953.519|3.601|that in total we currently have about
1954.799|3.6|3400 parameters
1957.12|2.48|and this is the forward pass as we
1958.399|3.52|developed it
1959.6|4.4|and we arrive at a single number here
1961.919|3.12|the loss that is currently expressing
1964.0|2.96|how well
1965.039|3.681|this neural network works with the
1966.96|3.12|current setting of parameters
1968.72|3.6|now i would like to make it even more
1970.08|4.56|respectable so in particular see these
1972.32|5.12|lines here where we take the logits and
1974.64|4.8|we calculate the loss
1977.44|4.0|we're not actually reinventing the wheel
1979.44|3.92|here this is just um
1981.44|4.239|classification and many people use
1983.36|4.08|classification and that's why there is a
1985.679|3.921|functional.cross entropy function in
1987.44|3.28|pytorch to calculate this much more
1989.6|2.799|efficiently
1990.72|2.64|so we can just simply call f.cross
1992.399|2.481|entropy
1993.36|2.96|and we can pass in the logits and we can
1994.88|3.2|pass in the
1996.32|5.52|array of targets y
1998.08|3.76|and this calculates the exact same loss
2002.24|5.12|so in fact we can simply put this here
2005.279|4.64|and erase these three lines and we're
2007.36|4.08|going to get the exact same result now
2009.919|4.321|there are actually many good reasons to
2011.44|4.8|prefer f.cross entropy over rolling your
2014.24|3.679|own implementation like this i did this
2016.24|4.319|for educational reasons but you'd never
2017.919|4.961|use this in practice why is that
2020.559|4.401|number one when you use f.cross entropy
2022.88|4.0|by torch will not actually create all
2024.96|4.16|these intermediate tensors because these
2026.88|4.48|are all new tensors in memory and all
2029.12|4.88|this is fairly inefficient to run like
2031.36|5.6|this instead pytorch will cluster up all
2034.0|5.519|these operations and very often create
2036.96|4.319|have fused kernels that very efficiently
2039.519|3.601|evaluate these expressions that are sort
2041.279|3.361|of like clustered mathematical
2043.12|3.2|operations
2044.64|3.68|number two the backward pass can be made
2046.32|4.079|much more efficient and not just because
2048.32|4.16|it's a fused kernel but also
2050.399|4.96|analytically and mathematically it's
2052.48|4.96|much it's often a very much simpler
2055.359|4.24|backward pass to implement
2057.44|4.56|we actually sell this with micrograd
2059.599|4.32|you see here when we implemented 10h the
2062.0|3.76|forward pass of this operation to
2063.919|4.321|calculate the 10h was actually a fairly
2065.76|3.599|complicated mathematical expression
2068.24|3.28|but because it's a clustered
2069.359|4.081|mathematical expression when we did the
2071.52|4.399|backward pass we didn't individually
2073.44|4.719|backward through the x and the two times
2075.919|4.321|and the minus one in division etc we
2078.159|3.92|just said it's one minus t squared and
2080.24|2.96|that's a much simpler mathematical
2082.079|2.641|expression
2083.2|3.28|and we were able to do this because
2084.72|3.359|we're able to reuse calculations and
2086.48|3.76|because we are able to mathematically
2088.079|4.241|and analytically derive the derivative
2090.24|4.56|and often that expression simplifies
2092.32|3.759|mathematically and so there's much less
2094.8|2.96|to implement
2096.079|3.441|so not only can can it be made more
2097.76|3.92|efficient because it runs in a fused
2099.52|3.76|kernel but also because the expressions
2101.68|4.24|can take a much simpler form
2103.28|5.28|mathematically
2105.92|4.56|so that's number one number two
2108.56|5.039|under the hood f that cross entropy can
2110.48|4.96|also be significantly more um
2113.599|5.041|numerically well behaved let me show you
2115.44|3.2|an example of how this works
2119.2|4.8|suppose we have a logits of negative 2 3
2121.52|3.92|negative 3 0 and 5
2124.0|3.599|and then we are taking the exponent of
2125.44|2.88|it and normalizing it to sum to 1.
2127.599|2.48|so
2128.32|3.12|when logits take on this values
2130.079|3.681|everything is well and good and we get a
2131.44|3.76|nice probability distribution
2133.76|3.68|now consider what happens when some of
2135.2|3.76|these logits take on more extreme values
2137.44|3.28|and that can happen during optimization
2138.96|3.52|of the neural network
2140.72|4.48|suppose that some of these numbers grow
2142.48|4.639|very negative like say negative 100
2145.2|4.08|then actually everything will come out
2147.119|2.96|fine we still get the probabilities that
2149.28|3.04|um
2150.079|4.321|you know are well behaved and they sum
2152.32|4.32|to one and everything is great
2154.4|4.24|but because of the way the x works if
2156.64|4.08|you have very positive logits let's say
2158.64|3.6|positive 100 in here
2160.72|3.76|you actually start to run into trouble
2162.24|4.08|and we get not a number here
2164.48|4.24|and the reason for that is that these
2166.32|2.4|counts
2168.8|3.68|have an if here
2170.4|5.04|so if you pass in a very negative number
2172.48|5.119|to x you just get a very negative sorry
2175.44|4.399|not negative but very small number very
2177.599|3.52|very near zero and that's fine
2179.839|3.841|but if you pass in a very positive
2181.119|4.401|number suddenly we run out of range in
2183.68|4.48|our floating point number that
2185.52|4.24|represents these counts
2188.16|3.76|so basically we're taking e and we're
2189.76|4.24|raising it to the power of 100 and that
2191.92|3.919|gives us if because we run out of
2194.0|3.839|dynamic range on this floating point
2195.839|5.28|number that is count
2197.839|6.0|and so we cannot pass very large logits
2201.119|4.161|through this expression
2203.839|3.441|now let me reset these numbers to
2205.28|3.92|something reasonable
2207.28|2.96|the way pi torch solved this
2209.2|3.04|is that
2210.24|3.28|you see how we have a well-behaved
2212.24|2.48|result here
2213.52|3.12|it turns out that because of the
2214.72|4.879|normalization here you can actually
2216.64|6.08|offset logits by any arbitrary constant
2219.599|5.121|value that you want so if i add 1 here
2222.72|3.6|you actually get the exact same result
2224.72|4.08|or if i add 2
2226.32|4.48|or if i subtract three
2228.8|3.92|any offset will produce the exact same
2230.8|4.319|probabilities
2232.72|4.24|so because negative numbers are okay but
2235.119|4.401|positive numbers can actually overflow
2236.96|4.639|this x what patrick does is it
2239.52|3.839|internally calculates the maximum value
2241.599|3.681|that occurs in the logits and it
2243.359|3.601|subtracts it so in this case it would
2245.28|3.36|subtract five
2246.96|3.68|and so therefore the greatest number in
2248.64|3.439|logits will become zero and all the
2250.64|2.479|other numbers will become some negative
2252.079|3.04|numbers
2253.119|4.801|and then the result of this is always
2255.119|4.0|well behaved so even if we have 100 here
2257.92|3.199|previously
2259.119|5.201|not good but because pytorch will
2261.119|5.841|subtract 100 this will work
2264.32|4.88|and so there's many good reasons to call
2266.96|3.84|cross-entropy number one the forward
2269.2|3.84|pass can be much more efficient the
2270.8|4.16|backward pass can be much more efficient
2273.04|4.0|and also things can be much more
2274.96|3.28|numerically well behaved okay so let's
2277.04|2.24|now set up the training of this neural
2278.24|4.16|net
2279.28|3.12|we have the forward pass
2282.48|4.32|uh we don't need these
2284.64|5.12|is that we have the losses equal to the
2286.8|5.279|f.cross entropy that's the forward pass
2289.76|4.88|then we need the backward pass first we
2292.079|4.161|want to set the gradients to be zero so
2294.64|3.439|for p in parameters
2296.24|3.2|we want to make sure that p dot grad is
2298.079|2.801|none which is the same as setting it to
2299.44|3.6|zero in pi torch
2300.88|3.52|and then lost that backward to populate
2303.04|2.72|those gradients
2304.4|3.84|once we have the gradients we can do the
2305.76|4.24|parameter update so for p in parameters
2308.24|4.16|we want to take all the
2310.0|6.48|data and we want to nudge it
2312.4|4.08|learning rate times p dot grad
2316.88|5.52|and then we want to repeat this
2319.76|2.64|a few times
2323.92|4.4|and let's print the loss here as well
2328.8|3.12|now this won't suffice and it will
2330.079|3.841|create an error because we also have to
2331.92|3.679|go for pn parameters
2333.92|5.84|and we have to make sure that p dot
2335.599|8.161|requires grad is set to true in pi torch
2339.76|6.0|and this should just work
2343.76|4.319|okay so we started off with loss of 17
2345.76|4.319|and we're decreasing it
2348.079|4.801|let's run longer
2350.079|5.76|and you see how the loss decreases
2352.88|2.959|a lot here so
2357.2|4.32|if we just run for a thousand times
2359.599|2.881|we get a very very low loss and that
2361.52|3.76|means that we're making very good
2362.48|4.56|predictions now the reason that this is
2365.28|4.079|so straightforward right now
2367.04|5.28|is because we're only um
2369.359|5.281|overfitting 32 examples
2372.32|4.08|so we only have 32 examples uh of the
2374.64|3.28|first five words
2376.4|4.4|and therefore it's very easy to make
2377.92|5.199|this neural net fit only these two 32
2380.8|5.52|examples because we have 3 400
2383.119|5.041|parameters and only 32 examples so we're
2386.32|3.84|doing what's called overfitting a single
2388.16|4.16|batch of the data
2390.16|3.28|and getting a very low loss and good
2392.32|2.72|predictions
2393.44|3.44|um but that's just because we have so
2395.04|2.96|many parameters for so few examples so
2396.88|3.199|it's easy to
2398.0|3.76|uh make this be very low
2400.079|2.561|now we're not able to achieve exactly
2401.76|2.72|zero
2402.64|3.68|and the reason for that is we can for
2404.48|3.92|example look at logits which are being
2406.32|5.12|predicted
2408.4|5.12|and we can look at the max along the
2411.44|4.08|first dimension
2413.52|4.0|and in pi torch
2415.52|4.72|max reports both the actual values that
2417.52|4.559|take on the maximum number but also the
2420.24|3.28|indices of piece
2422.079|4.241|and you'll see that the indices are very
2423.52|5.12|close to the labels
2426.32|4.88|but in some cases they differ
2428.64|4.88|for example in this very first example
2431.2|3.84|the predicted index is 19 but the label
2433.52|3.44|is five
2435.04|5.52|and we're not able to make loss be zero
2436.96|6.0|and fundamentally that's because here
2440.56|3.84|the very first or the zeroth index is
2442.96|3.2|the example where dot dot dot is
2444.4|3.679|supposed to predict e but you see how
2446.16|4.32|dot dot dot is also supposed to predict
2448.079|5.201|an o and dot dot is also supposed to
2450.48|6.72|predict an i and then s as well and so
2453.28|5.92|basically e o a or s are all possible
2457.2|3.84|outcomes in a training set for the exact
2459.2|4.32|same input so we're not able to
2461.04|5.44|completely over fit and um
2463.52|5.36|and make the loss be exactly zero so but
2466.48|3.359|we're getting very close in the cases
2468.88|2.88|where
2469.839|3.681|there's a unique input for a unique
2471.76|3.92|output in those cases we do what's
2473.52|5.52|called overfit and we basically get the
2475.68|5.439|exact same and the exact correct result
2479.04|3.68|so now all we have to do
2481.119|3.041|is we just need to make sure that we
2482.72|2.72|read in the full data set and optimize
2484.16|3.04|the neural net
2485.44|3.679|okay so let's swing back up
2487.2|3.44|where we created the dataset
2489.119|3.521|and we see that here we only use the
2490.64|2.959|first five words so let me now erase
2492.64|2.479|this
2493.599|4.401|and let me erase the print statements
2495.119|4.641|otherwise we'd be printing way too much
2498.0|4.96|and so when we processed the full data
2499.76|5.44|set of all the words we now had 228 000
2502.96|4.56|examples instead of just 32.
2505.2|4.8|so let's now scroll back down
2507.52|4.799|to this is much larger reinitialize the
2510.0|4.319|weights the same number of parameters
2512.319|4.081|they all require gradients
2514.319|4.321|and then let's push this print out
2516.4|3.52|lost.item to be here
2518.64|5.08|and let's just see how the optimization
2519.92|3.8|goes if we run this
2524.4|3.36|okay so we started with a fairly high
2525.839|4.801|loss and then as we're optimizing the
2527.76|2.88|loss is coming down
2532.0|3.839|but you'll notice that it takes quite a
2533.599|4.24|bit of time for every single iteration
2535.839|3.681|so let's actually address that because
2537.839|4.721|we're doing way too much work forwarding
2539.52|4.799|and backwarding 220 000 examples
2542.56|4.24|in practice what people usually do is
2544.319|5.28|they perform forward and backward pass
2546.8|4.88|and update on many batches of the data
2549.599|4.081|so what we will want to do is we want to
2551.68|4.0|randomly select some portion of the data
2553.68|3.84|set and that's a mini batch and then
2555.68|4.399|only forward backward and update on that
2557.52|4.48|little mini batch and then
2560.079|3.52|we iterate on those many batches
2562.0|3.119|so in pytorch we can for example use
2563.599|4.0|storage.randint
2565.119|5.521|we can generate numbers between 0 and 5
2567.599|3.041|and make 32 of them
2572.16|4.24|i believe the size has to be a
2574.319|3.441|tuple
2576.4|4.16|in my torch
2577.76|4.8|so we can have a tuple 32 of numbers
2580.56|4.88|between zero and five but actually we
2582.56|5.6|want x dot shape of zero here
2585.44|4.72|and so this creates uh integers that
2588.16|5.04|index into our data set and there's 32
2590.16|4.8|of them so if our mini batch size is 32
2593.2|4.8|then we can come here and we can first
2594.96|5.28|do a mini batch
2598.0|4.0|construct
2600.24|4.0|so in the integers that we want to
2602.0|3.68|optimize in this
2604.24|3.44|single iteration
2605.68|4.24|are in the ix
2607.68|3.12|and then we want to index into
2609.92|4.24|x
2610.8|6.0|with ix to only grab those rows
2614.16|4.24|so we're only getting 32 rows of x
2616.8|4.08|and therefore embeddings will again be
2618.4|4.88|32 by three by two not two hundred
2620.88|4.4|thousand by three by two
2623.28|3.68|and then this ix has to be used not just
2625.28|5.28|to index into x
2626.96|5.68|but also to index into y
2630.56|4.88|and now this should be many batches and
2632.64|5.28|this should be much much faster so
2635.44|4.639|okay so it's instant almost
2637.92|3.6|so this way we can run many many
2640.079|3.76|examples
2641.52|4.079|nearly instantly and decrease the loss
2643.839|3.201|much much faster
2645.599|3.921|now because we're only dealing with mini
2647.04|4.48|batches the quality of our gradient is
2649.52|3.92|lower so the direction is not as
2651.52|3.12|reliable it's not the actual gradient
2653.44|3.04|direction
2654.64|4.0|but the gradient direction is good
2656.48|5.76|enough even when it's estimating on only
2658.64|5.92|32 examples that it is useful and so
2662.24|4.48|it's much better to have an approximate
2664.56|4.48|gradient and just make more steps than
2666.72|4.639|it is to evaluate the exact gradient and
2669.04|5.36|take fewer steps so that's why in
2671.359|6.48|practice uh this works quite well
2674.4|3.439|so let's now continue the optimization
2678.319|4.561|let me take out this lost item from here
2681.68|4.159|and uh
2682.88|7.199|place it over here at the end
2685.839|5.681|okay so we're hovering around 2.5 or so
2690.079|3.28|however this is only the loss for that
2691.52|3.44|mini batch so let's actually evaluate
2693.359|3.121|the loss
2694.96|3.28|here
2696.48|4.48|for all of x
2698.24|4.8|and for all of y just so we have a
2700.96|4.56|full sense of exactly how all the model
2703.04|4.16|is doing right now
2705.52|3.599|so right now we're at about 2.7 on the
2707.2|2.96|entire training set
2709.119|3.441|so let's
2710.16|5.12|run the optimization for a while
2712.56|4.96|okay right 2.6
2715.28|5.12|2.57
2717.52|2.88|2.53
2721.92|3.12|okay
2722.8|5.84|so one issue of course is we don't know
2725.04|5.76|if we're stepping too slow or too fast
2728.64|4.56|so this point one i just guessed it
2730.8|4.08|so one question is how do you determine
2733.2|4.159|this learning rate
2734.88|4.56|and how do we gain confidence that we're
2737.359|3.841|stepping in the right
2739.44|4.08|sort of speed so i'll show you one way
2741.2|4.879|to determine a reasonable learning rate
2743.52|4.0|it works as follows let's reset our
2746.079|3.681|parameters
2747.52|3.52|to the initial
2749.76|2.96|settings
2751.04|3.92|and now let's
2752.72|6.0|print in every step
2754.96|6.0|but let's only do 10 steps or so
2758.72|4.0|or maybe maybe 100 steps
2760.96|2.879|we want to find like a very reasonable
2762.72|3.119|set
2763.839|4.081|search range if you will so for example
2765.839|4.0|if this is like very low
2767.92|3.439|then
2769.839|3.441|we see that the loss is barely
2771.359|4.24|decreasing so that's not
2773.28|3.28|that's like too low basically so let's
2775.599|3.121|try
2776.56|3.6|this one
2778.72|3.04|okay so we're decreasing the loss but
2780.16|3.36|like not very quickly so that's a pretty
2781.76|4.079|good low range
2783.52|3.76|now let's reset it again
2785.839|3.601|and now let's try to find the place at
2787.28|5.6|which the loss kind of explodes
2789.44|3.44|uh so maybe at negative one
2793.119|3.761|okay we see that we're minimizing the
2794.96|4.399|loss but you see how uh it's kind of
2796.88|4.32|unstable it goes up and down quite a bit
2799.359|4.96|um so negative one is probably like a
2801.2|4.56|fast learning rate let's try negative
2804.319|2.641|10.
2805.76|3.12|okay so this
2806.96|4.0|isn't optimizing this is not working
2808.88|4.239|very well so negative 10 is way too big
2810.96|3.84|negative one was already kind of big
2813.119|3.281|um
2814.8|2.799|so therefore
2816.4|4.0|negative one was like somewhat
2817.599|4.0|reasonable if i reset
2820.4|2.959|so i'm thinking that the right learning
2821.599|4.321|rate is somewhere between
2823.359|3.601|uh negative zero point zero zero one and
2825.92|2.32|um
2826.96|3.04|negative one
2828.24|4.879|so the way we can do this here is we can
2830.0|4.319|use uh torch shot lens space
2833.119|4.641|and we want to basically do something
2834.319|4.8|like this between zero and one but
2837.76|3.2|um
2839.119|3.361|those number of steps is one more
2840.96|5.359|parameter that's required let's do a
2842.48|7.28|thousand steps this creates 1000
2846.319|5.121|numbers between 0.01 and 1
2849.76|3.839|but it doesn't really make sense to step
2851.44|5.04|between these linearly so instead let me
2853.599|5.601|create learning rate exponent
2856.48|5.2|and instead of 0.001 this will be a
2859.2|4.48|negative 3 and this will be a zero
2861.68|3.76|and then the actual lrs that we want to
2863.68|4.639|search over are going to be 10 to the
2865.44|3.919|power of lre
2868.319|3.04|so now what we're doing is we're
2869.359|4.801|stepping linearly between the exponents
2871.359|5.76|of these learning rates this is 0.001
2874.16|4.4|and this is 1 because 10 to the power of
2877.119|2.96|0 is 1.
2878.56|3.519|and therefore we are spaced
2880.079|3.361|exponentially in this interval
2882.079|2.641|so these are the candidate learning
2883.44|3.04|rates
2884.72|3.04|that we want to sort of like search over
2886.48|4.4|roughly
2887.76|4.72|so now what we're going to do is
2890.88|3.76|here we are going to run the
2892.48|4.24|optimization for 1000 steps
2894.64|4.88|and instead of using a fixed number
2896.72|5.76|we are going to use learning rate
2899.52|5.92|indexing into here lrs of i
2902.48|2.96|and make this i
2905.68|4.8|so basically let me reset this to be
2908.24|3.839|again starting from random
2910.48|2.8|creating these learning rates between
2912.079|4.801|negative
2913.28|6.24|zero points between 0.001 and um
2916.88|4.56|one but exponentially stopped
2919.52|3.76|and here what we're doing is we're
2921.44|4.159|iterating a thousand times
2923.28|4.799|we're going to use the learning rate
2925.599|4.881|um that's in the beginning very very low
2928.079|4.161|in the beginning is going to be 0.001
2930.48|2.96|but by the end it's going to be
2932.24|2.8|1.
2933.44|3.679|and then we're going to step with that
2935.04|3.68|learning rate
2937.119|5.44|and now what we want to do is we want to
2938.72|3.839|keep track of the uh
2944.24|3.68|learning rates that we used and we want
2945.92|3.919|to look at the losses
2947.92|4.399|that resulted
2949.839|4.321|and so here let me
2952.319|4.641|track stats
2954.16|6.08|so lri.append lr
2956.96|5.44|and um lost side that append
2960.24|3.44|loss that item
2962.4|4.8|okay
2963.68|6.72|so again reset everything
2967.2|4.56|and then run
2970.4|2.64|and so basically we started with a very
2971.76|3.359|low learning rate and we went all the
2973.04|2.88|way up to a learning rate of negative
2975.119|2.561|one
2975.92|3.04|and now what we can do is we can plt
2977.68|3.6|that plot
2978.96|4.56|and we can plot the two so we can plot
2981.28|4.88|the learning rates on the x-axis and the
2983.52|4.48|losses we saw on the y-axis
2986.16|4.0|and often you're going to find that your
2988.0|4.0|plot looks something like this
2990.16|3.28|where in the beginning
2992.0|2.96|you had very low learning rates so
2993.44|3.6|basically anything
2994.96|5.119|barely anything happened
2997.04|4.4|then we got to like a nice spot here
3000.079|2.881|and then as we increase the learning
3001.44|2.879|rate enough
3002.96|2.96|we basically started to be kind of
3004.319|3.361|unstable here
3005.92|4.159|so a good learning rate turns out to be
3007.68|5.679|somewhere around here
3010.079|4.641|um and because we have lri here
3013.359|3.281|um
3014.72|4.24|we actually may want to
3016.64|2.32|um
3019.119|3.521|do not lr
3020.96|4.399|not the learning rate but the exponent
3022.64|5.199|so that would be the lre at i is maybe
3025.359|4.72|what we want to log so let me reset this
3027.839|4.321|and redo that calculation
3030.079|4.0|but now on the x axis we have the
3032.16|3.919|[Music]
3034.079|3.361|exponent of the learning rate and so we
3036.079|2.721|can see the exponent of the learning
3037.44|3.919|rate that is good to use it would be
3038.8|3.84|sort of like roughly in the valley here
3041.359|3.521|because here the learning rates are just
3042.64|3.6|way too low and then here where we
3044.88|3.04|expect relatively good learning rates
3046.24|4.24|somewhere here and then here things are
3047.92|4.0|starting to explode so somewhere around
3050.48|3.68|negative one x the exponent of the
3051.92|6.159|learning rate is a pretty good setting
3054.16|5.679|and 10 to the negative one is 0.1 so 0.1
3058.079|4.081|is actually 0.1 was actually a fairly
3059.839|4.0|good learning rate around here
3062.16|3.199|and that's what we had in the initial
3063.839|2.72|setting
3065.359|4.161|but that's roughly how you would
3066.559|6.241|determine it and so here now we can take
3069.52|6.079|out the tracking of these
3072.8|5.2|and we can just simply set lr to be 10
3075.599|5.201|to the negative one or
3078.0|3.92|basically otherwise 0.1 as it was before
3080.8|2.64|and now we have some confidence that
3081.92|2.48|this is actually a fairly good learning
3083.44|2.72|rate
3084.4|3.36|and so now we can do is we can crank up
3086.16|4.56|the iterations
3087.76|4.319|we can reset our optimization
3090.72|3.92|and
3092.079|4.401|we can run for a pretty long time using
3094.64|3.919|this learning rate
3096.48|3.599|oops and we don't want to print that's
3098.559|3.52|way too much printing
3100.079|5.28|so let me again reset
3102.079|3.28|and run ten thousand stops
3108.48|6.8|okay so we're 0.2 2.48 roughly let's run
3112.079|3.201|another 10 000 steps
3118.64|3.76|2.46
3120.24|3.44|and now let's do one learning rate decay
3122.4|3.52|what this means is we're going to take
3123.68|4.8|our learning rate and we're going to 10x
3125.92|4.48|lower it and so we're at the late stages
3128.48|4.4|of training potentially and we may want
3130.4|6.4|to go a bit slower let's do one more
3132.88|3.92|actually at 0.1 just to see if
3136.96|3.68|we're making a dent here
3138.88|2.8|okay we're still making dent and by the
3140.64|3.6|way the
3141.68|5.439|bi-gram loss that we achieved last video
3144.24|4.96|was 2.45 so we've already surpassed the
3147.119|3.281|bi-gram model
3149.2|3.28|and once i get a sense that this is
3150.4|3.84|actually kind of starting to plateau off
3152.48|3.76|people like to do as i mentioned this
3154.24|3.44|learning rate decay so let's try to
3156.24|4.319|decay the loss
3157.68|2.879|the learning rate i mean
3162.16|5.919|and we achieve it about 2.3 now
3166.4|3.6|obviously this is janky and not exactly
3168.079|3.121|how you would train it in production but
3170.0|3.359|this is roughly what you're going
3171.2|3.6|through you first find a decent learning
3173.359|2.321|rate using the approach that i showed
3174.8|2.4|you
3175.68|3.04|then you start with that learning rate
3177.2|3.04|and you train for a while
3178.72|3.52|and then at the end people like to do a
3180.24|3.68|learning rate decay where you decay the
3182.24|4.0|learning rate by say a factor of 10 and
3183.92|4.72|you do a few more steps and then you get
3186.24|5.359|a trained network roughly speaking
3188.64|4.88|so we've achieved 2.3 and dramatically
3191.599|3.76|improved on the bi-gram language model
3193.52|3.599|using this simple neural net as
3195.359|5.041|described here
3197.119|5.361|using these 3 400 parameters now there's
3200.4|3.679|something we have to be careful with
3202.48|3.839|i said that we have a better model
3204.079|4.801|because we are achieving a lower loss
3206.319|4.321|2.3 much lower than 2.45 with the
3208.88|3.679|bi-gram model previously
3210.64|5.84|now that's not exactly true and the
3212.559|3.921|reason that's not true is that
3217.2|3.84|this is actually fairly small model but
3219.359|2.96|these models can get larger and larger
3221.04|3.44|if you keep adding neurons and
3222.319|3.52|parameters so you can imagine that we
3224.48|3.28|don't potentially have a thousand
3225.839|4.0|parameters we could have 10 000 or 100
3227.76|3.44|000 or millions of parameters
3229.839|2.961|and as the capacity of the neural
3231.2|3.76|network grows
3232.8|4.08|it becomes more and more capable of
3234.96|4.08|overfitting your training set
3236.88|3.92|what that means is that the loss on the
3239.04|4.4|training set on the data that you're
3240.8|4.0|training on will become very very low as
3243.44|2.8|low as zero
3244.8|4.24|but all that the model is doing is
3246.24|4.4|memorizing your training set verbatim so
3249.04|3.36|if you take that model and it looks like
3250.64|3.679|it's working really well but you try to
3252.4|4.0|sample from it you will basically only
3254.319|4.721|get examples exactly as they are in the
3256.4|4.08|training set you won't get any new data
3259.04|4.48|in addition to that if you try to
3260.48|4.4|evaluate the loss on some withheld names
3263.52|2.88|or other words
3264.88|4.16|you will actually see that the loss on
3266.4|4.4|those can be very high and so basically
3269.04|3.84|it's not a good model
3270.8|4.48|so the standard in the field is to split
3272.88|4.8|up your data set into three splits as we
3275.28|4.799|call them we have the training split the
3277.68|4.639|dev split or the validation split
3280.079|3.121|and the test split
3282.319|3.201|so
3283.2|6.72|training split
3285.52|7.599|test or um sorry dev or validation split
3289.92|4.96|and test split and typically this would
3293.119|3.281|be say eighty percent of your data set
3294.88|3.439|this could be ten percent and this ten
3296.4|3.6|percent roughly
3298.319|3.04|so you have these three splits of the
3300.0|2.8|data
3301.359|3.281|now these eighty percent of your
3302.8|4.08|trainings of the data set the training
3304.64|4.0|set is used to optimize the parameters
3306.88|3.84|of the model just like we're doing here
3308.64|3.84|using gradient descent
3310.72|4.0|these 10 percent of the
3312.48|4.32|examples the dev or validation split
3314.72|4.399|they're used for development over all
3316.8|4.24|the hyper parameters of your model so
3319.119|3.521|hyper parameters are for example the
3321.04|3.68|size of this hidden layer
3322.64|3.84|the size of the embedding so this is a
3324.72|3.28|hundred or a two for us but we could try
3326.48|3.44|different things
3328.0|3.92|the strength of the regularization which
3329.92|3.199|we aren't using yet so far
3331.92|2.8|so there's lots of different hybrid
3333.119|3.681|parameters and settings that go into
3334.72|4.08|defining your neural net and you can try
3336.8|4.319|many different variations of them and
3338.8|4.319|see whichever one works best on your
3341.119|4.641|validation split
3343.119|5.521|so this is used to train the parameters
3345.76|5.92|this is used to train the hyperprimers
3348.64|4.4|and test split is used to evaluate
3351.68|2.399|basically the performance of the model
3353.04|2.88|at the end
3354.079|3.76|so we're only evaluating the loss on the
3355.92|4.48|test plate very very sparingly and very
3357.839|4.72|few times because every single time you
3360.4|3.439|evaluate your test loss and you learn
3362.559|3.921|something from it
3363.839|4.161|you are basically starting to also train
3366.48|4.0|on the test split
3368.0|3.599|so you are only allowed to test the loss
3370.48|2.639|on a test
3371.599|4.081|set
3373.119|4.48|very very few times otherwise you risk
3375.68|3.84|overfitting to it as well as you
3377.599|4.401|experiment on your model
3379.52|5.52|so let's also split up our training data
3382.0|4.559|into train dev and test and then we are
3385.04|3.2|going to train on train
3386.559|4.56|and only evaluate on tests very very
3388.24|5.2|sparingly okay so here we go
3391.119|5.041|here is where we took all the words and
3393.44|4.8|put them into x and y tensors
3396.16|3.76|so instead let me create a new cell here
3398.24|2.559|and let me just copy paste some code
3399.92|3.12|here
3400.799|4.56|because i don't think it's that
3403.04|3.44|complex but
3405.359|2.24|we're going to try to save a little bit
3406.48|3.119|of time
3407.599|3.921|i'm converting this to be a function now
3409.599|4.72|and this function takes some list of
3411.52|5.039|words and builds the arrays x and y for
3414.319|4.961|those words only
3416.559|4.8|and then here i am shuffling up all the
3419.28|2.96|words so these are the input words that
3421.359|3.521|we get
3422.24|4.4|we are randomly shuffling them all up
3424.88|3.28|and then um
3426.64|3.28|we're going to
3428.16|3.52|set n1 to be
3429.92|3.84|the number of examples that there's 80
3431.68|2.879|of the words and n2 to be
3433.76|3.2|90
3434.559|7.04|of the way of the words so basically if
3436.96|7.359|len of words is 32 000 n1 is
3441.599|6.561|well sorry i should probably run this
3444.319|5.52|n1 is 25 000 and n2 is 28 000.
3448.16|3.84|and so here we see that
3449.839|4.081|i'm calling build data set to build the
3452.0|4.72|training set x and y
3453.92|5.76|by indexing into up to and one so we're
3456.72|5.76|going to have only 25 000 training words
3459.68|4.56|and then we're going to have
3462.48|3.599|roughly
3464.24|5.28|n2 minus n1
3466.079|7.28|3 3 000 validation examples or dev
3469.52|3.839|examples and we're going to have
3473.52|4.64|when of words basically minus and two
3477.28|3.68|or
3478.16|5.52|3 204 examples
3480.96|3.839|here for the test set
3483.68|3.439|so
3484.799|5.681|now we have x's and y's
3487.119|3.361|for all those three splits
3493.359|4.161|oh yeah i'm printing their size here
3494.559|2.961|inside the function as well
3498.88|3.679|but here we don't have words but these
3500.559|4.641|are already the individual examples made
3502.559|5.04|from those words
3505.2|6.0|so let's now scroll down here
3507.599|5.601|and the data set now for training is
3511.2|6.639|more like this
3513.2|4.639|and then when we reset the network
3518.319|5.601|when we're training we're only going to
3520.079|7.681|be training using x train
3523.92|5.36|x train and y train
3527.76|4.079|so that's the only thing we're training
3529.28|2.559|on
3537.68|4.48|let's see where we are on the
3540.16|6.08|single batch
3542.16|4.08|let's now train maybe a few more steps
3548.0|3.2|training neural networks can take a
3549.359|3.361|while usually you don't do it inline you
3551.2|4.08|launch a bunch of jobs and you wait for
3552.72|3.92|them to finish um can take in multiple
3555.28|4.559|days and so on
3556.64|3.199|luckily this is a very small network
3560.96|4.72|okay so the loss is pretty good
3563.28|4.24|oh we accidentally used a learning rate
3565.68|4.08|that is way too low
3567.52|6.839|so let me actually come back
3569.76|4.599|we use the decay learning rate of 0.01
3575.119|4.161|so this will train much faster
3577.119|5.2|and then here when we evaluate
3579.28|4.319|let's use the dep set here
3582.319|4.8|xdev
3583.599|5.121|and ydev to evaluate the loss
3587.119|3.521|okay
3588.72|5.92|and let's now decay the learning rate
3590.64|4.0|and only do say 10 000 examples
3595.44|3.76|and let's evaluate the dev loss
3597.68|3.76|ones here
3599.2|3.44|okay so we're getting about 2.3 on dev
3601.44|4.0|and so the neural network when it was
3602.64|5.36|training did not see these dev examples
3605.44|4.72|it hasn't optimized on them and yet
3608.0|4.319|when we evaluate the loss on these dev
3610.16|5.919|we actually get a pretty decent loss
3612.319|6.641|and so we can also look at what the
3616.079|4.48|loss is on all of training set
3618.96|3.359|oops
3620.559|4.081|and so we see that the training and the
3622.319|3.441|dev loss are about equal so we're not
3624.64|3.679|over fitting
3625.76|5.359|um this model is not powerful enough to
3628.319|5.52|just be purely memorizing the data and
3631.119|4.801|so far we are what's called underfitting
3633.839|4.321|because the training loss and the dev or
3635.92|4.399|test losses are roughly equal so what
3638.16|5.28|that typically means is that our network
3640.319|5.76|is very tiny very small and we expect to
3643.44|4.48|make performance improvements by scaling
3646.079|4.081|up the size of this neural net so let's
3647.92|3.679|do that now so let's come over here
3650.16|3.679|and let's increase the size of the
3651.599|3.601|neural net the easiest way to do this is
3653.839|3.121|we can come here to the hidden layer
3655.2|3.76|which currently has 100 neurons and
3656.96|3.68|let's just bump this up so let's do 300
3658.96|4.48|neurons
3660.64|5.28|and then this is also 300 biases and
3663.44|3.84|here we have 300 inputs into the final
3665.92|2.72|layer
3667.28|3.6|so
3668.64|3.6|let's initialize our neural net we now
3670.88|2.64|have ten thousand ex ten thousand
3672.24|3.599|parameters instead of three thousand
3673.52|4.72|parameters
3675.839|3.76|and then we're not using this
3678.24|5.04|and then here what i'd like to do is i'd
3679.599|5.041|like to actually uh keep track of uh
3683.28|3.6|tap
3684.64|2.24|um
3687.599|3.281|okay let's just do this let's keep stats
3689.839|4.801|again
3690.88|3.76|and here when we're keeping track of the
3694.88|6.0|loss let's just also keep track of the
3697.839|6.321|steps and let's just have i here
3700.88|5.199|and let's train on thirty thousand
3704.16|4.0|or rather say
3706.079|5.121|okay let's try thirty thousand
3708.16|4.32|and we are at point one
3711.2|3.68|and
3712.48|4.8|we should be able to run this
3714.88|4.52|and optimize the neural net
3717.28|3.68|and then here basically i want to
3719.4|3.0|plt.plot
3720.96|5.24|the steps
3722.4|3.8|against the loss
3729.04|4.48|so these are the x's and y's
3731.52|3.839|and this is
3733.52|3.039|the loss function and how it's being
3735.359|2.801|optimized
3736.559|3.28|now you see that there's quite a bit of
3738.16|3.6|thickness to this and that's because we
3739.839|3.601|are optimizing over these mini batches
3741.76|2.72|and the mini batches create a little bit
3743.44|2.399|of noise
3744.48|3.599|in this
3745.839|4.72|uh where are we in the def set we are at
3748.079|4.0|2.5 so we still haven't optimized this
3750.559|2.721|neural net very well
3752.079|2.72|and that's probably because we made it
3753.28|3.12|bigger it might take longer for this
3754.799|2.721|neural net to converge
3756.4|4.399|um
3757.52|5.279|and so let's continue training
3760.799|5.201|um
3762.799|3.201|yeah let's just continue training
3766.559|2.721|one possibility is that the batch size
3768.0|3.68|is so low
3769.28|4.079|that uh we just have way too much noise
3771.68|3.04|in the training and we may want to
3773.359|4.0|increase the batch size so that we have
3774.72|4.96|a bit more um correct gradient and we're
3777.359|6.48|not thrashing too much and we can
3779.68|4.159|actually like optimize more properly
3787.92|2.56|okay
3788.799|4.401|this will now become meaningless because
3790.48|4.4|we've reinitialized these so
3793.2|3.76|yeah this looks not
3794.88|3.679|pleasing right now but there probably is
3796.96|3.359|like a tiny improvement but it's so hard
3798.559|4.0|to tell
3800.319|5.121|let's go again
3802.559|2.881|2.52
3805.52|5.079|let's try to decrease the learning rate
3807.039|3.56|by factor two
3830.0|5.88|okay we're at 2.32
3832.24|3.64|let's continue training
3845.68|3.28|we basically expect to see a lower loss
3847.52|3.36|than what we had before because now we
3848.96|3.839|have a much much bigger model and we
3850.88|3.199|were under fitting so we'd expect that
3852.799|3.28|increasing the size of the model should
3854.079|4.321|help the neural net
3856.079|3.361|2.32 okay so that's not happening too
3858.4|2.8|well
3859.44|4.159|now one other concern is that even
3861.2|4.32|though we've made the 10h layer here or
3863.599|3.121|the hidden layer much much bigger it
3865.52|3.279|could be that the bottleneck of the
3866.72|4.079|network right now are these embeddings
3868.799|3.28|that are two dimensional it can be that
3870.799|3.28|we're just cramming way too many
3872.079|4.401|characters into just two dimensions and
3874.079|4.641|the neural net is not able to really use
3876.48|3.44|that space effectively and that that is
3878.72|3.599|sort of like the bottleneck to our
3879.92|5.119|network's performance
3882.319|4.081|okay 2.23 so just by decreasing the
3885.039|3.121|learning rate i was able to make quite a
3886.4|4.0|bit of progress let's run this one more
3888.16|2.24|time
3891.599|4.24|and then evaluate the training and the
3893.28|2.559|dev loss
3896.64|4.24|now one more thing after training that
3898.16|4.56|i'd like to do is i'd like to visualize
3900.88|4.719|the um
3902.72|5.2|embedding vectors for these
3905.599|4.321|characters before we scale up the
3907.92|3.36|embedding size from two
3909.92|3.6|because we'd like to make uh this
3911.28|4.0|bottleneck potentially go away
3913.52|3.76|but once i make this greater than two we
3915.28|2.96|won't be able to visualize them
3917.28|4.24|so here
3918.24|5.92|okay we're at 2.23 and 2.24
3921.52|4.0|so um we're not improving much more and
3924.16|4.32|maybe the bottleneck now is the
3925.52|4.4|character embedding size which is two
3928.48|2.559|so here i have a bunch of code that will
3929.92|4.08|create a figure
3931.039|4.481|and then we're going to visualize
3934.0|2.72|the embeddings that were trained by the
3935.52|2.96|neural net
3936.72|3.68|on these characters because right now
3938.48|3.76|the embedding has just two so we can
3940.4|3.52|visualize all the characters with the x
3942.24|3.839|and the y coordinates as the two
3943.92|3.84|embedding locations for each of these
3946.079|3.921|characters
3947.76|4.0|and so here are the x coordinates and
3950.0|2.799|the y coordinates which are the columns
3951.76|3.68|of c
3952.799|5.52|and then for each one i also include the
3955.44|4.399|text of the little character
3958.319|3.921|so here what we see is actually kind of
3959.839|2.401|interesting
3962.4|3.76|the network has basically learned to
3964.48|3.839|separate out the characters and cluster
3966.16|3.679|them a little bit uh so for example you
3968.319|4.48|see how the vowels
3969.839|4.401|a e i o u are clustered up here
3972.799|3.361|so that's telling us that is that the
3974.24|3.2|neural net treats these is very similar
3976.16|2.399|right because when they feed into the
3977.44|3.28|neural net
3978.559|4.081|the embedding uh for all these
3980.72|3.119|characters is very similar and so the
3982.64|3.12|neural net thinks that they're very
3983.839|3.52|similar and kind of like interchangeable
3985.76|3.44|if that makes sense
3987.359|3.76|um
3989.2|4.24|then the the points that are like really
3991.119|4.561|far away are for example q q is kind of
3993.44|3.2|treated as an exception and q has a very
3995.68|3.04|special
3996.64|3.76|embedding vector so to speak
3998.72|3.76|similarly dot which is a special
4000.4|3.84|character is all the way out here
4002.48|4.16|and a lot of the other letters are sort
4004.24|3.76|of like clustered up here and so it's
4006.64|3.439|kind of interesting that there's a
4008.0|3.599|little bit of structure here
4010.079|3.601|after the training
4011.599|4.321|and it's not definitely not random and
4013.68|4.08|these embeddings make sense
4015.92|3.119|so we're now going to scale up the
4017.76|3.92|embedding size and won't be able to
4019.039|4.641|visualize it directly but we expect that
4021.68|4.399|because we're under fitting
4023.68|4.48|and we made this layer much bigger and
4026.079|4.72|did not sufficiently improve the loss
4028.16|4.399|we're thinking that the um
4030.799|4.32|constraint to better performance right
4032.559|4.081|now could be these embedding pictures so
4035.119|2.72|let's make them bigger okay so let's
4036.64|2.399|scroll up here
4037.839|3.76|and now we don't have two dimensional
4039.039|4.401|embeddings we are going to have
4041.599|3.52|say 10 dimensional embeddings for each
4043.44|2.72|word
4045.119|5.361|then
4046.16|5.36|this layer will receive 3 times 10 so 30
4050.48|3.28|inputs
4051.52|4.24|will go into
4053.76|3.279|the hidden layer
4055.76|3.12|let's also make the hidden layer a bit
4057.039|4.56|smaller so instead of 300 let's just do
4058.88|4.64|200 neurons in that hidden layer
4061.599|5.601|so now the total number of elements will
4063.52|4.88|be slightly bigger at 11 000
4067.2|3.359|and then here we have to be a bit
4068.4|4.8|careful because um
4070.559|5.441|okay the learning rate we set to 0.1
4073.2|3.68|here we are hardcoded in six and
4076.0|1.76|obviously if you're working in
4076.88|3.12|production you don't wanna be
4077.76|4.559|hard-coding magic numbers but instead of
4080.0|4.079|six this should now be thirty
4082.319|3.361|um
4084.079|3.841|and let's run for fifty thousand
4085.68|5.119|iterations and let me split out the
4087.92|4.72|initialization here outside
4090.799|3.601|so that when we run this cell multiple
4092.64|4.24|times it's not going to wipe out
4094.4|2.48|our loss
4097.52|3.12|in addition to that
4099.44|3.2|here
4100.64|2.8|let's instead of logging lost.item let's
4102.64|2.88|actually
4103.44|3.12|log the
4105.52|3.04|let's
4106.56|6.159|do log 10
4108.56|5.759|i believe that's a function of the loss
4112.719|4.321|and i'll show you why in a second let's
4114.319|2.721|optimize this
4117.12|3.76|basically i'd like to plot the log loss
4119.279|2.96|instead of the loss because when you
4120.88|4.08|plot the loss many times it can have
4122.239|4.56|this hockey stick appearance and log
4124.96|4.0|squashes it in
4126.799|4.88|uh so it just kind of like looks nicer
4128.96|6.48|so the x-axis is step i
4131.679|3.761|and the y-axis will be the loss i
4140.799|6.92|and then here this is 30.
4143.12|4.599|ideally we wouldn't be hard-coding these
4148.719|4.721|okay so let's look at the loss
4151.44|4.08|okay it's again very thick because the
4153.44|4.56|mini batch size is very small but the
4155.52|5.36|total loss over the training set is 2.3
4158.0|3.92|and the the tests or the def set is 2.38
4160.88|3.2|as well
4161.92|3.759|so so far so good uh let's try to now
4164.08|4.719|decrease the learning rate
4165.679|3.12|by a factor of 10
4169.12|4.44|and train for another 50 000 iterations
4175.279|5.321|we'd hope that we would be able to beat
4177.279|3.321|uh 2.32
4183.279|3.52|but again we're just kind of like doing
4184.719|3.761|this very haphazardly so i don't
4186.799|3.681|actually have confidence that our
4188.48|4.319|learning rate is set very well that our
4190.48|4.719|learning rate decay which we just do
4192.799|4.721|at random is set very well
4195.199|4.081|and um so the optimization here is kind
4197.52|2.719|of suspect to be honest and this is not
4199.28|2.72|how you would do it typically in
4200.239|3.841|production in production you would
4202.0|3.679|create parameters or hyper parameters
4204.08|3.28|out of all these settings and then you
4205.679|5.601|would run lots of experiments and see
4207.36|5.28|whichever ones are working well for you
4211.28|5.52|okay
4212.64|6.8|so we have 2.17 now and 2.2 okay so you
4216.8|4.8|see how the training and the validation
4219.44|3.68|performance are starting to slightly
4221.6|3.2|slowly depart
4223.12|2.96|so maybe we're getting the sense that
4224.8|3.6|the neural net
4226.08|4.24|is getting good enough or
4228.4|3.92|that number of parameters is large
4230.32|3.839|enough that we are slowly starting to
4232.32|4.08|overfit
4234.159|3.761|let's maybe run one more iteration of
4236.4|4.319|this
4237.92|2.799|and see where we get
4241.52|3.28|but yeah basically you would be running
4243.28|3.12|lots of experiments and then you are
4244.8|3.76|slowly scrutinizing whichever ones give
4246.4|3.6|you the best depth performance and then
4248.56|3.2|once you find all the
4250.0|4.0|hyper parameters that make your dev
4251.76|4.08|performance good you take that model and
4254.0|3.679|you evaluate the test set performance a
4255.84|3.839|single time and that's the number that
4257.679|3.52|you report in your paper or wherever
4259.679|4.721|else you want to talk about and brag
4261.199|3.201|about your model
4265.52|5.44|so let's then rerun the plot and rerun
4268.159|2.801|the train and death
4271.12|4.079|and because we're getting lower loss now
4272.8|6.64|it is the case that the embedding size
4275.199|4.241|of these was holding us back very likely
4280.08|4.4|okay so 2.162.19 is what we're roughly
4282.88|3.6|getting
4284.48|3.759|so there's many ways to go from many
4286.48|3.759|ways to go from here we can continue
4288.239|3.841|tuning the optimization
4290.239|3.841|we can continue for example playing with
4292.08|4.079|the sizes of the neural net or we can
4294.08|4.24|increase the number of uh
4296.159|3.681|words or characters in our case that we
4298.32|3.12|are taking as an input so instead of
4299.84|3.76|just three characters we could be taking
4301.44|5.04|more characters as an input and that
4303.6|4.559|could further improve the loss
4306.48|4.0|okay so i changed the code slightly so
4308.159|4.641|we have here 200 000 steps of the
4310.48|4.08|optimization and in the first 100 000
4312.8|3.52|we're using a learning rate of 0.1 and
4314.56|3.92|then in the next 100 000 we're using a
4316.32|4.08|learning rate of 0.01
4318.48|3.44|this is the loss that i achieve
4320.4|3.52|and these are the performance on the
4321.92|3.84|training and validation loss
4323.92|3.12|and in particular the best validation
4325.76|4.8|loss i've been able to obtain in the
4327.04|5.76|last 30 minutes or so is 2.17
4330.56|3.84|so now i invite you to beat this number
4332.8|4.24|and you have quite a few knobs available
4334.4|4.319|to you to i think surpass this number
4337.04|3.28|so number one you can of course change
4338.719|3.52|the number of neurons in the hidden
4340.32|3.919|layer of this model you can change the
4342.239|3.201|dimensionality of the embedding
4344.239|2.561|lookup table
4345.44|4.32|you can change the number of characters
4346.8|5.6|that are feeding in as an input
4349.76|3.76|as the context into this model
4352.4|3.12|and then of course you can change the
4353.52|4.0|details of the optimization how long are
4355.52|3.84|we running what is the learning rate how
4357.52|3.6|does it change over time
4359.36|3.28|how does it decay
4361.12|3.2|you can change the batch size and you
4362.64|3.76|may be able to actually achieve a much
4364.32|3.2|better convergence speed
4366.4|2.64|in terms of
4367.52|4.0|how many seconds or minutes it takes to
4369.04|4.96|train the model and get
4371.52|4.159|your result in terms of really good
4374.0|3.12|loss
4375.679|3.921|and then of course i actually invite you
4377.12|3.84|to read this paper it is 19 pages but at
4379.6|3.52|this point you should actually be able
4380.96|3.92|to read a good chunk of this paper and
4383.12|3.36|understand
4384.88|3.2|pretty good chunks of it
4386.48|3.36|and this paper also has quite a few
4388.08|2.96|ideas for improvements that you can play
4389.84|3.28|with
4391.04|3.52|so all of those are not available to you
4393.12|3.28|and you should be able to beat this
4394.56|4.32|number i'm leaving that as an exercise
4396.4|5.2|to the reader and that's it for now and
4398.88|2.72|i'll see you next time
4404.239|3.92|before we wrap up i also wanted to show
4405.76|5.28|how you would sample from the model
4408.159|5.601|so we're going to generate 20 samples
4411.04|4.32|at first we begin with all dots so
4413.76|3.68|that's the context
4415.36|4.64|and then until we generate
4417.44|6.239|the zeroth character again
4420.0|7.199|we're going to embed the current context
4423.679|5.761|using the embedding table c now usually
4427.199|3.921|uh here the first dimension was the size
4429.44|2.96|of the training set but here we're only
4431.12|3.92|working with a single example that we're
4432.4|6.08|generating so this is just the mission
4435.04|3.44|one just for simplicity
4438.56|3.92|and so this embedding then gets
4440.64|2.96|projected into the end state you get the
4442.48|3.199|logits
4443.6|5.52|now we calculate the probabilities for
4445.679|5.201|that you can use f.softmax
4449.12|3.2|of logits and that just basically
4450.88|4.24|exponentiates the logits and makes them
4452.32|6.32|sum to one and similar to cross entropy
4455.12|5.039|it is careful that there's no overflows
4458.64|3.36|once we have the probabilities we sample
4460.159|4.321|from them using torture multinomial to
4462.0|4.8|get our next index and then we shift the
4464.48|5.199|context window to append the index and
4466.8|5.12|record it and then we can just
4469.679|3.681|decode all the integers to strings
4471.92|3.04|and print them out
4473.36|3.52|and so these are some example samples
4474.96|4.0|and you can see that the model now works
4476.88|4.64|much better so the words here are much
4478.96|5.44|more word like or name like so we have
4481.52|5.28|things like ham
4484.4|2.4|joes
4488.08|3.2|you know it's starting to sound a little
4489.52|3.92|bit more name-like so we're definitely
4491.28|4.16|making progress but we can still improve
4493.44|4.08|on this model quite a lot
4495.44|4.0|okay sorry there's some bonus content i
4497.52|4.32|wanted to mention that i want to make
4499.44|3.92|these notebooks more accessible and so i
4501.84|2.879|don't want you to have to like install
4503.36|3.359|jupyter notebooks and torch and
4504.719|4.241|everything else so i will be sharing a
4506.719|4.0|link to a google colab
4508.96|4.16|and google collab will look like a
4510.719|4.641|notebook in your browser and you can
4513.12|4.64|just go to the url and you'll be able to
4515.36|4.64|execute all of the code that you saw in
4517.76|4.56|the google collab and so this is me
4520.0|4.719|executing the code in this lecture and i
4522.32|3.6|shortened it a little bit but basically
4524.719|3.761|you're able to train the exact same
4525.92|4.08|network and then plot and sample from
4528.48|3.199|the model and everything is ready for
4530.0|3.12|you to like tinker with the numbers
4531.679|3.841|right there in your browser no
4533.12|3.599|installation necessary
4535.52|2.639|so i just wanted to point that out and
4536.719|4.081|the link to this will be in the video
4538.159|2.641|description