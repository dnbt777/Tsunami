start_time|end_time|text
0.0|5.4|via clocks let's let's get started so
2.929|3.571|I'm going to lecture today give Andre a
5.4|4.199|little bit of a break
6.5|4.809|so today we're so last time we talked
9.599|3.08|about sort of we saw all the parts of
11.309|3.21|continents we put everything together
12.679|4.211|today we're going to see some
14.519|4.291|applications of commnets to speak to
16.89|4.309|actually dive inside images and talk
18.81|4.86|about spatial localization and detection
21.199|4.511|we were we actually moved this lecture
23.67|3.57|up a little bit we had it later on the
25.71|2.76|schedule but we saw a lot of you guys
27.24|2.789|were interested in this stuff for
28.47|2.94|projects so we wanted to move it earlier
30.029|4.53|to kind of give you an idea of what
31.41|6.45|what's feasible so first couple
34.559|5.16|administrative things are the project
37.86|3.48|proposals we're due on Saturday my inbox
39.719|3.421|kind of exploded over the weekend so I
41.34|3.09|think most of you submitted it but if
43.14|3.36|you didn't you should probably get on
44.43|3.69|that we're in the process of looking
46.5|2.969|through those so we'll go to make sure
48.12|2.64|that the project proposals are
49.469|2.91|reasonable then everyone submitted one
50.76|5.04|so we'll hopefully get back to you on
52.379|8.0|your projects this week also homework 2
55.8|4.579|is due on Friday so who's who's done
61.19|7.84|who's stuck on batch norm okay good good
66.84|4.95|that's fewer hands than we saw last week
69.03|4.14|so we're making progress also keep in
71.79|3.329|mind that we're asking you to actually
73.17|4.199|train a pretty big comp net on CFR for
75.119|4.261|this homework so if you're starting to
77.369|3.75|train on Thursday night that might be
79.38|2.94|tough so maybe start early on that last
81.119|2.971|part
82.32|3.27|also homework 1 we're in the process of
84.09|3.33|grading hopefully we'll have those back
85.59|4.56|to you this week so you can get feedback
87.42|4.379|before homework 2 is due also keep in
90.15|4.8|mind though we actually have an in-class
91.799|5.521|midterm next week on Wednesday so that's
94.95|3.959|a week from Wednesday so be ready
97.32|3.86|that'll be in class it should be a lot
98.909|2.271|of fun
101.729|4.361|all right so last lecture we were
104.109|4.531|talking about convolutional networks we
106.09|4.229|kind of saw the pieces we spent a long
108.64|3.089|time understanding how this convolution
110.319|3.36|operator works how we're sort of
111.729|3.121|transforming feature Maps from one to
113.679|3.0|another
114.85|3.449|by running inner products over by
116.679|3.39|sliding this window over our feature map
118.299|3.511|computing inner products and actually
120.069|4.14|transforming our representation through
121.81|3.869|many layers of processing and if you
124.209|2.94|remember if you remember these lower
125.679|3.571|layers of convolutions tend to learn
127.149|4.95|things like edges and colors and higher
129.25|5.519|layers tend to learn more complex object
132.099|4.621|parts we talked about pooling which is
134.769|3.891|used to sub sample and downsize our
136.72|4.23|feature representations inside networks
138.66|5.109|so that's a common ingredient that we
140.95|4.83|saw we also did case studies on
143.769|3.3|particular convent architectures so you
145.78|3.36|could see how these things tend to get
147.069|3.931|hooked up in practice so we talked about
149.14|3.12|Linette which is something from 98 it's
151.0|3.36|a little five layer confident that was
152.26|3.539|used for digit recognition we talked
154.36|3.18|about Alex Matt that kind of kicked off
155.799|3.901|the big deep learner deep learning boom
157.54|4.41|in 2012 by winning imagenet there was an
159.7|4.83|eight layer comp net we talked about ZF
161.95|4.8|net that one image net classification in
164.53|6.0|2013 it was pretty similar to alex net
166.75|5.97|and then we saw that deeper is often
170.53|4.32|better for classification we looked at
172.72|4.59|Google net & vgg that did really well in
174.85|4.41|2014 competitions that were much much
177.31|4.59|deeper than Alex net and ZF net and did
179.26|4.74|a lot better and we also saw this new
181.9|4.709|fancy crazy thing from Microsoft called
184.0|6.75|the res net that one just in December in
186.609|5.88|2015 with 150 layer architecture and as
190.75|3.0|you'll recall just the over the last
192.489|2.4|couple years these different
193.75|3.66|architectures have been getting deeper
194.889|5.28|and getting a lot better but this is
197.41|4.229|just for classification so now in this
200.169|3.93|lecture we're going to talk about
201.639|4.231|localization and detection which is
204.099|4.411|actually another really big important
205.87|4.89|problem in computer vision and this idea
208.51|4.11|of deeper networks doing better hint
210.76|5.849|that'll kind of we'll revisit that a lot
212.62|5.25|in these new tasks as well so so far in
216.609|3.931|the class we've really been talking
217.87|4.53|about classification which is sort of
220.54|3.809|given an image we want to classify which
222.4|4.649|of some number of object categories it
224.349|4.2|is that's not a nice basic problem in
227.049|3.3|computer vision that we've using that
228.549|3.66|we're using to understand commnets and
230.349|3.931|such but there's actually a lot of other
232.209|5.041|tasks that people work on too
234.28|4.97|so some of these are classification and
237.25|4.65|localization so now instead of just
239.25|4.45|classifying an image as one as some
241.9|3.6|category labels we also want to draw a
243.7|4.92|bounding box in the image to say where
245.5|5.46|that class occurs another problem people
248.62|3.93|work on is detection so here there's
250.96|3.66|again some fixed number of object
252.55|4.26|categories but we actually want to find
254.62|4.31|all instances of those categories inside
256.81|4.2|the image and draw a box around them
258.93|3.85|another more recent task that people
261.01|3.87|have started to work on a bit is this
262.78|4.2|crazy thing called instance segmentation
264.88|3.54|where again you want you have some fixed
266.98|3.39|number of object categories you want to
268.42|3.99|find all instances of those categories
270.37|3.06|in your image but instead of using a box
272.41|4.08|you actually want to draw a little
273.43|5.45|contour around and kind of identify all
276.49|4.44|the pixels belonging to each instance
278.88|3.37|instance segmentation is kind of crazy
280.93|2.91|so we're not going to talk about that
282.25|3.36|today just thought you should be aware
283.84|3.93|of it and we're going to really focus on
285.61|3.93|these localization and detection tasks
287.77|3.81|today and the big difference between
289.54|4.17|these is the number of objects that
291.58|4.38|we're finding so in localization there's
293.71|3.99|sort of one object or in general a fixed
295.96|3.78|number of objects whereas in detection
297.7|4.35|we might have a multiple objects or a
299.74|3.81|variable number of objects and this
302.05|4.02|seems like a small difference but it'll
303.55|4.73|turn out to actually make a big be
306.07|4.44|pretty important for our architectures
308.28|4.54|so we're going to first talk about
310.51|4.77|classification and localization because
312.82|4.26|it's kind of the simplest so just to
315.28|3.98|recap what I just said classification
317.08|4.49|one image to a category label
319.26|4.45|localization is image to a box and
321.57|4.96|classification localization means we're
323.71|4.32|going to do both at the same time just
326.53|4.11|to give you an idea of the kinds of
328.03|3.45|datasets people use for this we've
330.64|3.15|talked about the image net
331.48|3.9|classification challenge image net also
333.79|4.05|has run a classification plus
335.38|3.99|localization challenge so here I'm
337.84|4.35|similar to the classification task
339.37|4.32|there's a thousand classes and each
342.19|3.99|training instance in those classes
343.69|4.47|actually has one class and several
346.18|4.44|bounding boxes for that class inside the
348.16|4.8|image and now at test time your
350.62|4.08|algorithm again makes five guesses where
352.96|3.78|instead of your guess is just being
354.7|4.14|class labels it's a class label together
356.74|3.42|with a bounding box and to get it right
358.84|3.78|you need to get the class label right
360.16|3.87|and the bounding box right we're getting
362.62|3.57|a bounding box right just means you're
364.03|3.66|close in some thing called intersection
366.19|1.83|over Union that you don't need to care
367.69|3.629|about
368.02|4.739|much right now so again you get it for
371.319|3.181|imagenet at least you get it right if
372.759|3.571|you one of your five guesses is correct
374.5|3.09|and this is kind of the main data set
376.33|6.57|that people work on for classification
377.59|6.9|plus localization so a one really
382.9|3.12|fundamental paradigm that's really
384.49|3.989|useful when thinking about localization
386.02|3.75|is this idea of regression so I don't
388.479|2.581|know thinking back to a machine learning
389.77|3.239|class you kind of saw like
391.06|3.81|classification like maybe with an SVM
393.009|4.261|and regression maybe with linear
394.87|3.84|regression or something fancier and when
397.27|2.91|we're talking about localization it's
398.71|3.51|really a like we can really just frame
400.18|3.81|this as a regression problem where we
402.22|3.33|have an image that's coming in that
403.99|3.269|image is going to go through some some
405.55|3.75|processing and we're eventually going to
407.259|4.65|produce for real valued numbers that
409.3|4.47|parameterize this box there's different
411.909|4.081|parameters Asians people use common is
413.77|3.989|XY coordinates of the upper left-hand
415.99|3.269|corner and the width and height of the
417.759|3.241|box but you'll see some other variants
419.259|3.78|as well but always for numbers for a
421.0|3.719|bounding box and then there's some
423.039|3.961|ground truth bounding box which again is
424.719|4.38|just for numbers and now we have we can
427.0|3.539|compute a loss like maybe Euclidean loss
429.099|3.57|is a pretty pretty standard choice
430.539|4.231|between the numbers that we produced and
432.669|3.571|the correct numbers and now we can just
434.77|4.019|train this thing just like we did our
436.24|4.109|classification networks where we sample
438.789|4.171|some mini batch of data with some ground
440.349|4.261|truth boxes we propagate forward compute
442.96|4.259|a loss between our predictions and the
444.61|5.25|correct predictions back propagate and
447.219|4.92|just update the network so this paradigm
449.86|4.47|is really easy this actually makes this
452.139|4.14|localization task actually pretty easy
454.33|3.48|to implement so here's a really simple
456.279|3.841|recipe for how you could implement
457.81|4.199|classification plus localization so
460.12|3.599|first you just download up some existing
462.009|3.63|pre-trained model or you train it
463.719|3.81|yourself if you're ambitious something
465.639|4.53|like Alec's net vgg Google net all these
467.529|4.14|things we talked about last lecture now
470.169|3.961|we're going to take those fully
471.669|3.87|connected layers that were producing our
474.13|3.089|class scores we're going to set those
475.539|3.66|aside for the moment and we're going to
477.219|4.051|attach a couple new fully connected
479.199|3.15|layers to some point in the network this
481.27|3.03|will be called we'll call this a
482.349|3.6|regression head but I mean it's
484.3|2.94|basically the same thing it's a couple
485.949|5.701|fully connected layers and then it
487.24|6.51|outputs some real valued numbers now we
491.65|3.87|train this thing just like we trained
493.75|3.389|our classification network the only
495.52|5.679|difference is that now instead of class
497.139|6.64|scores and ground truth classes we use a
501.199|4.171|loss and ground treat boxes other than
503.779|4.17|that we train this network exactly the
505.37|4.44|same way now a test time we just use
507.949|3.81|both heads to do classification and
509.81|3.719|localization we have an image we've
511.759|4.47|trained the classification heads we've
513.529|4.68|trained the localization heads we pass
516.229|3.87|it through we get class scores we get
518.209|3.81|boxes and when we're done like really
520.099|3.75|that's that's all you need to do so this
522.019|2.94|is kind of a really nice simple recipe
523.849|3.031|that you guys could use for
524.959|4.351|classification plus localization on your
526.88|4.889|projects
529.31|5.13|so one slight detail with this approach
531.769|5.701|there's sort of two main ways that
534.44|5.519|people do this regression task you could
537.47|5.01|imagine a class agnostic regressor or
539.959|4.201|class specific regressor you could
542.48|3.69|imagine that no matter what class I'm
544.16|3.57|going to use the same architecture the
546.17|4.05|same weights in those fully connected
547.73|3.84|layers to produce my bounding box so
550.22|2.91|that would be in your sort of outputting
551.57|1.92|always for numbers which are just the
553.13|2.67|box
553.49|4.26|no matter the class an alternative
555.8|3.659|you'll see sometimes is class specific
557.75|4.26|regression where now you're going to
559.459|5.221|output C times four numbers that's sort
562.01|4.41|of like one bounding box per class and
564.68|2.969|different people have found that
566.42|4.02|sometimes these work better in different
567.649|4.8|cases but I mean intuitively it kind of
570.44|4.68|makes sense that some that the way you
572.449|3.75|might think about localizing a cat could
575.12|2.85|be a little bit different than the way
576.199|2.82|you localize a train so maybe you want
577.97|2.25|to have different parts of your network
579.019|4.141|that are responsible for those things
580.22|4.59|but so then it's it's pretty easy then
583.16|2.91|you just it changes your back the way
584.81|3.6|you compute loss a little bit you
586.07|4.019|compute loss only using the UM the
588.41|2.97|ground truth clap the the box for the
590.089|3.74|ground truth class but other than that
591.38|4.68|still basically the same idea
593.829|3.851|another design choice here is where
596.06|3.779|exactly you attach the regression head
597.68|3.75|again this isn't too important different
599.839|3.451|people you'll see different people do it
601.43|3.69|in different ways some common choices
603.29|5.1|would be to attach it right after the
605.12|4.43|last convolutional layer that would just
608.39|3.21|sort of mean like your real
609.55|4.599|reinitializing new fully connected
611.6|4.71|layers you'll see things like over feet
614.149|4.44|and bgg localization work this way
616.31|4.56|another common choice is to just attach
618.589|4.171|your regression head actually after the
620.87|4.23|last fully connected layers from the
622.76|4.29|classification network and you'll see
625.1|4.2|some other things like deep pose and our
627.05|4.08|CNN kind of work in this flavor but
629.3|3.12|either one works fine they'll probably
631.13|4.249|you could attach it just about anywhere
632.42|6.06|and it would do something
635.379|4.601|so as an aside you this is we can
638.48|3.69|actually generalize this framework to
639.98|4.74|multiple localizing more than one object
642.17|4.859|so normally with this classification
644.72|4.109|localization tasks that we sort of set
647.029|4.321|up on imagenet we care about producing
648.829|4.68|exactly one object bounding box for the
651.35|4.229|input image but in some cases you might
653.509|4.13|know ahead of time that you always want
655.579|4.081|to localize some fixed number of objects
657.639|4.12|so here this is really easy to
659.66|4.44|generalize now your regression head it
661.759|4.2|just outputs a box for each of those
664.1|3.949|objects that you care about and again
665.959|4.891|you train the network in the same way
668.049|4.811|and this idea of actually localizing
670.85|4.049|multiple objects the same time is pretty
672.86|3.87|general and pretty powerful so for
674.899|4.321|example this kind of approach has been
676.73|5.819|used for human pose estimation so the
679.22|5.039|idea is we want to input a close-up view
682.549|3.931|of a person and then we want to figure
684.259|3.901|out what's the pose of that person so
686.48|3.75|well people sort of generally have a
688.16|3.69|fixed number of joints like their wrists
690.23|4.5|and their neck and their elbows and that
691.85|6.089|sort of stuff so we just know that we
694.73|4.319|need to find all the joints so we input
697.939|3.661|our image we run it through a
699.049|4.32|convolutional net work and we regress XY
701.6|4.139|coordinates for each joint location and
703.369|3.69|that gives us our AR action that
705.739|3.21|actually lets you predict a whole human
707.059|4.89|pose using this sort of localization
708.949|5.07|framework I mean this paper and there's
711.949|3.57|a paper from Google from a year or two
714.019|2.67|ago that does this sort of approach they
715.519|3.03|had a couple other bells and whistles
716.689|4.61|but the basic idea was just regressing
718.549|6.12|for using a CNN - these joint positions
721.299|5.26|so overall this idea of localization and
724.669|3.48|treating it as regression for a fixed
726.559|3.72|number of objects is really really
728.149|3.451|simple so I know some of you guys on
730.279|2.941|your projects have been thinking that
731.6|3.299|you want to actually run detection
733.22|3.929|because you want to understand like in
734.899|4.711|parts of your images or find parts
737.149|4.56|inside the image and if you're thinking
739.61|3.389|a lot of a project along those lines I'd
741.709|3.36|really encourage you to think about this
742.999|3.39|localization framework instead that if
745.069|2.67|there's actually a fixed number of
746.389|3.75|objects that you know you want to
747.739|4.35|localize in every image you should try
750.139|2.91|to frame it as a localization problem
752.089|5.49|because that's tends to be a lot easier
753.049|6.66|to setup alright so actually the simple
757.579|3.6|idea of localization via regression
759.709|3.33|actually is really simple it'll actually
761.179|3.69|work I would really encourage you to try
763.039|3.51|it for your projects but if you're wanna
764.869|3.811|win competitions like imagenet you need
766.549|4.71|to add a little bit of other fancy stuff
768.68|4.469|so another thing that people do for
771.259|3.87|localization is this idea of sliding
773.149|4.951|window so we'll step through this in
775.129|4.161|more detail but the idea is that you you
778.1|3.81|still have your classification
779.29|4.089|localization dual-headed Network but
781.91|3.599|you're actually going to run it not once
783.379|3.361|on the image but at multiple positions
785.509|2.58|on the image and you're going to
786.74|3.449|aggregate across those different
788.089|5.22|positions and you can actually do this
790.189|5.12|in an efficient way so to sort of see
793.309|4.111|more concretely how this sliding-window
795.309|4.57|localization works we're going to look
797.42|4.56|at the overfeed architecture so over
799.879|4.83|feet was actually the winner of the
801.98|5.849|imagenet localization challenge in 2013
804.709|4.951|it this this architect this this sort of
807.829|4.831|setup looks basically like what we saw a
809.66|4.109|couple slides ago we have an Alex net at
812.66|2.88|the beginning then we have a
813.769|4.081|classification head we have a regression
815.54|4.109|head classification head is spitting out
817.85|4.769|class scores regression head is spitting
819.649|5.04|out bounding boxes and this thing
822.619|4.14|because it's in Alec's net type
824.689|6.601|architecture is expecting an input of
826.759|6.661|221 by 221 but actually we can run this
831.29|4.95|on larger images and this can help
833.42|7.109|sometimes so suppose we have a larger
836.24|6.5|image of what would I say to 57 by 257
840.529|4.53|now we could imagine taking our
842.74|3.789|classification plus localization Network
845.059|3.72|and running it just on the upper corner
846.529|5.131|of this image and that'll give us some
848.779|5.011|some class score and also some some
851.66|4.32|regrets bounding box and we're going to
853.79|4.799|repeat this take our same classification
855.98|5.82|plus localization network and run it on
858.589|5.701|all four corners of this image and after
861.8|4.44|doing so we'll end up with four regress
864.29|4.62|bounding boxes one from each of those
866.24|4.73|four locations together with a Class A
868.91|4.32|classification score from each location
870.97|4.719|but we actually want just a single
873.23|4.14|bounding box so then they use some
875.689|3.661|heuristics to merge these bounding boxes
877.37|3.269|and scores and that parts a little bit
879.35|2.489|ugly I don't want to go into the details
880.639|4.14|here they have it in the paper
881.839|4.68|but the idea is that probably combining
884.779|3.75|aggregating these boxes across multiple
886.519|3.93|locations can help can help the model
888.529|3.75|sort of correct its own errors and this
890.449|4.83|tends to work really well and they mean
892.279|4.41|it won them the challenge that year but
895.279|2.4|in practice they actually use many more
896.689|3.781|than four locations
897.679|5.221|oh yeah question
900.47|4.44|being slide so each of those meant boxes
902.9|3.63|they weren't always within the slice
904.91|3.15|being looked at is that just a design of
906.53|4.11|the slide like normally they possibly
908.06|3.69|fully would well I mean bear yeah that's
910.64|2.64|actually a good point so once you're
911.75|3.06|doing regression you're just predicting
913.28|2.85|four numbers you could impact you could
914.81|4.29|in theory predict anywhere it doesn't
916.13|4.2|have to be inside the image although and
919.1|2.79|although that that brings up a good
920.33|4.02|point when you're doing this especially
921.89|4.35|when they when you're training this
924.35|3.18|network in this sliding-window way you
926.24|3.33|actually need to ship the ground truth
927.53|3.21|box in a little leadership ship the
929.57|2.76|coordinate frame for those different
930.74|5.25|slices that's kind of an ugly detail
932.33|5.19|that you have to worry about yeah but in
935.99|3.42|practice they use many more than for
937.52|4.65|image locations and they actually do
939.41|3.96|multiple scales as well so you can see
942.17|3.03|this is actually a figure from their
943.37|3.12|paper on the left you see all the
945.2|3.69|different positions where they kind of
946.49|4.32|evaluated this network on there in the
948.89|4.11|middle you see those output regressed
950.81|4.11|boxes one for each of those positions on
953.0|4.62|the bottom you see a score map for each
954.92|4.26|of those positions and then I mean
957.62|3.21|they're pretty noisy but it's kind of
959.18|3.51|convert they're kind of generally over
960.83|3.81|the bear so they draw on this fancy
962.69|3.51|aggregation method and they get a final
964.64|3.33|box for the bear and they decide that
966.2|5.07|this image is a bear and they actually
967.97|5.16|won the challenge with this but one
971.27|3.36|problem you might anticipate is it could
973.13|3.66|be pretty expensive to actually run the
974.63|3.6|network on every one of those crops but
976.79|3.81|there's actually a more efficient way
978.23|3.81|thing we could do so we normally think
980.6|3.09|of these networks as having
982.04|3.6|convolutional layers and then fully
983.69|3.78|connected layers but when you think
985.64|4.49|about it a fully connected layer is just
987.47|4.8|4096 numbers right it's just a vector
990.13|4.45|but instead of thinking of it as a
992.27|4.23|vector we could think of it as just
994.58|2.55|another convolutional feature map it's
996.5|2.82|kind of crazy
997.13|4.71|we've just transposed it and added two
999.32|5.64|one-by-one dimensions so now the idea is
1001.84|4.5|that we can now treat our our fully
1004.96|3.69|connected layers and convert them into
1006.34|4.26|convolutional layers because if you
1008.65|4.53|imagine in our fully connected network
1010.6|5.04|we had this convolutional feature map
1013.18|4.23|and we had one weight from each element
1015.64|3.45|of that convolutional feature map to
1017.41|4.02|produce each element of our 4096
1019.09|4.2|dimensional vector but we instead of
1021.43|3.87|thinking about reshaping and having an
1023.29|4.71|affine layer that's sort of equivalent
1025.3|3.75|to just having a 5x5 convolution it's a
1028.0|4.16|little bit weird but if you think about
1029.05|5.07|it it should make sense eventually but
1032.16|3.31|right so then then our
1034.12|4.319|so then we take this fully connected
1035.47|6.089|layer turns into a 5x5 convolution then
1038.439|5.221|this then we previously had another
1041.559|3.091|fully connected layer going from 40s 96
1043.66|2.97|to 4096
1044.65|4.17|this is actually a one-by-one
1046.63|3.96|convolution right that's that's kind of
1048.82|3.51|weird but if you if you think hard and
1050.59|3.03|sort of work out the math on paper and
1052.33|4.47|go sit in a quiet room you'll figure it
1053.62|4.86|out and so we basically can turn each of
1056.8|3.75|these fully connected layers in our
1058.48|4.829|network into a convolutional layer and
1060.55|4.77|now now this is pretty cool because now
1063.309|3.541|our network is composed entirely of just
1065.32|4.14|convolutions and pooling and
1066.85|4.38|element-wise operations so now we can
1069.46|4.44|actually run the network on images of
1071.23|4.199|different sizes and this sort of will
1073.9|3.779|give us very cheaply
1075.429|4.231|Equipe the equivalent of operating the
1077.679|4.321|network independently on different
1079.66|4.649|locations so to kind of see how that
1082.0|5.01|works you imagine a training time you're
1084.309|5.311|maybe working over a 14 by 14 input you
1087.01|4.799|run some convolutions and then here are
1089.62|4.41|our fully connected layers that we're
1091.809|5.791|now reimagining as convolutional layers
1094.03|5.24|so then we had this 5x5 con block that
1097.6|4.98|gets turned into these one-by-one
1099.27|4.659|spatially sized elements so we were sort
1102.58|3.81|of eliminating not showing the depth
1103.929|5.851|dimension here but these like this one
1106.39|4.44|by one would be one by one by 4096 right
1109.78|3.99|so we're just converting these layers
1110.83|4.41|into convolutional nares now that we
1113.77|3.09|know that they're convolutions we could
1115.24|4.11|actually run on an input of a larger
1116.86|4.29|size and you can see that now we've at
1119.35|3.87|we've added a couple extra pixels to the
1121.15|3.9|input and now we actually run all these
1123.22|4.56|things as convolutions and get a 2x2
1125.05|4.379|output but what's really cool here is
1127.78|3.899|that we're able to share computation to
1129.429|4.261|make this really efficient so now our
1131.679|3.481|output is four times as big but we've
1133.69|3.48|done much less than four times the
1135.16|3.69|compute because if you think about the
1137.17|3.6|difference between where we're doing
1138.85|3.36|computation here the only extra
1140.77|3.36|computation happened in these yellow
1142.21|3.81|parts so now we're actually very
1144.13|4.44|efficiently evaluating the network at
1146.02|4.62|many many different positions without
1148.57|3.3|actually spending much computation so
1150.64|3.03|this is how they are able to evaluate
1151.87|3.33|that network in that very very dense
1153.67|4.38|multi scale way that you saw a couple
1155.2|5.78|slides ago does that make sense any
1158.05|5.04|questions on this ok good
1160.98|4.42|right so actually we can look at the
1163.09|4.44|classification plus localization results
1165.4|5.43|on image net over the last couple years
1167.53|5.1|so in 2012 Alex Alex Tkachev ski geoff
1170.83|4.71|hinton Ilya sutskever they won not only
1172.63|4.53|classification but also localization but
1175.54|4.02|I wasn't able to find any published
1177.16|4.8|details of exactly how they did that in
1179.56|4.92|2013 it was the over feet method that we
1181.96|5.07|just saw actually improved on Alex's
1184.48|4.83|results a little bit the year after we
1187.03|4.32|talked about vgg and their sort of
1189.31|3.9|really deep nineteen layer network they
1191.35|3.5|got second place on classification but
1193.21|4.8|they actually won on localization and
1194.85|4.96|the vgg actually used basically exactly
1198.01|4.26|the same strategy that over feet did
1199.81|5.1|they just use the deeper network and
1202.27|4.68|actually interestingly vgg used fewer
1204.91|4.5|scales they stamped that network out in
1206.95|3.93|fewer places and used fewer scales but
1209.41|3.9|they actually decrease the error quite a
1210.88|4.68|bit so basically the only difference
1213.31|4.68|between over feet and bgg here is that
1215.56|3.81|vgg use the deeper network so here we
1217.99|2.88|could see that these really powerful
1219.37|3.72|image features actually improve the
1220.87|3.33|localization performance quite a bit we
1223.09|2.85|didn't have to change the localization
1224.2|4.2|architecture at all we just swapped out
1225.94|5.37|a better CNN and it improved results a
1228.4|4.98|lot and then this year in 2015
1231.31|3.6|I mean Microsoft swept everything as
1233.38|5.28|that'll be a theme in this lecture as
1234.91|6.33|well this this 150 layer ResNet from
1238.66|4.95|Microsoft crushed localization here and
1241.24|5.22|drops performance from 25 all the way
1243.61|5.04|down to 9 but I mean this this is a
1246.46|4.11|little bit fan this is tough to really
1248.65|3.87|isolate the deep features so yes they
1250.57|3.63|did have deeper features but Microsoft
1252.52|3.87|actually use a different localization
1254.2|3.75|method called RPMs region proposal
1256.39|4.29|networks so it's not really clear
1257.95|4.2|whether this which part whether it's the
1260.68|4.23|better localization strategy or whether
1262.15|6.33|the better features but at any rate they
1264.91|4.92|did really well so that's pretty much
1268.48|3.72|all I want to say about classification
1269.83|3.57|localization just consider doing it for
1272.2|3.33|your projects and if there's any
1273.4|3.83|questions about this task up we should
1275.53|4.7|talk about that now before moving on
1277.23|3.0|yeah
1284.23|5.67|places yeah that can always hurt
1288.17|4.71|performance especially with an l2 loss
1289.9|5.08|right so then l2 loss when having
1292.88|4.05|outliers is actually really bad so
1294.98|4.5|sometimes people don't use an l2 loss
1296.93|4.2|instead you can try an l1 loss that can
1299.48|4.2|help with outliers a little bit people
1301.13|4.59|also will do sometimes a smooth l1 loss
1303.68|3.66|where it looks like l1 sort of at the
1305.72|2.22|tails but then near zero it'll be
1307.34|2.46|quadratic
1307.94|3.15|so actually swapping out that regression
1309.8|3.75|loss function can help a bit with
1311.09|3.78|outliers sometimes but also if you have
1313.55|2.64|a little bit of noise sometimes
1314.87|2.67|hopefully your network will just figure
1316.19|3.47|it out cross your fingers don't think
1317.54|2.12|too hard
1320.26|15.31|any other questions yeah yeah yeah good
1333.23|4.68|question so people do both actually so
1335.57|3.93|for over feet actually I don't remember
1337.91|3.75|I don't remember exactly which over feet
1339.5|4.62|did but vgg actually back props into the
1341.66|4.5|entire network so it'll be it'll be
1344.12|3.69|faster to just it'll actually work fine
1346.16|3.39|if you just trained in the regression
1347.81|3.12|head but you'll tend to get a little bit
1349.55|3.3|better results if you back pop into the
1350.93|3.48|whole network and bgg did this
1352.85|3.09|experiment and they got maybe one or two
1354.41|3.57|points extra buy back propping through
1355.94|3.33|the whole thing but it at the expense of
1357.98|4.17|a lot more computation and training time
1359.27|5.01|so if so I was I would say like as a
1362.15|12.06|first thing don't just try not back
1364.28|11.13|propping into the network well yet
1374.21|2.55|generally not right because you're
1375.41|2.97|testing them on the same classes that
1376.76|3.42|you saw at training time so you're going
1378.38|3.72|to see different instances obviously but
1380.18|2.94|I mean you're still you saw bears a test
1382.1|2.61|time you're going to see bears at
1383.12|3.12|training time we're not expecting you to
1384.71|7.52|generalize across classes that would be
1386.24|5.99|pretty hard yeah
1396.649|4.12|good question yeah so sometimes people
1399.48|2.159|will do that they'll train with both
1400.769|3.12|simultaneously
1401.639|3.78|also sometimes people will just end up
1403.889|3.03|with separate networks one that's sort
1405.419|2.311|of only responsible for regression one
1406.919|10.59|that's only responsible for
1407.73|11.279|classification those both work well glad
1417.509|2.37|you asked that's that's actually the
1419.009|2.221|next thing we're going to talk about
1419.879|13.611|that's that's a different task called
1421.23|14.61|object detection so yeah well yeah well
1433.49|4.059|so it I mean it kind of depends on the
1435.84|3.209|training strategy if you're like if you
1437.549|3.21|it also kind of goes back to this idea
1439.049|3.061|of class agnostic versus class specific
1440.759|2.76|regression so if you're doing class
1442.11|2.939|agnostic regression it doesn't matter
1443.519|3.39|you just regress to the boxes no matter
1445.049|3.09|the class class specific you're sort of
1446.909|7.02|training separate regressors for each
1448.139|9.0|class all right let's talk about object
1453.929|5.281|detection so object detection is is like
1457.139|4.23|much fancier much cooler but also a lot
1459.21|3.63|hairier so the idea is that again we
1461.369|3.39|have an input image we have some set of
1462.84|3.659|classes we want to find all instances of
1464.759|5.101|those classes in that in that input
1466.499|5.13|image so I mean you know regression
1469.86|5.309|works pretty well for a localization why
1471.629|5.191|don't we try it for for detection - well
1475.169|3.541|because in this image we have these
1476.82|3.689|these dogs and cats and we have four
1478.71|3.329|things we have sixteen numbers that
1480.509|4.38|looks like that looks like regression
1482.039|4.681|right image in numbers out but if we
1484.889|4.051|look at another image then you know this
1486.72|4.439|one only has two things coming out so it
1488.94|3.9|has eight numbers if we look at this one
1491.159|4.081|there's a whole bunch of cats so we need
1492.84|3.87|a bunch of numbers so I mean it's it's
1495.24|3.33|kind of hard to treat detection as
1496.71|4.23|straight-up regression because we have
1498.57|3.089|this problem of variable size outputs so
1500.94|2.64|we're going to have to do something
1501.659|3.661|fancier although actually there is a
1503.58|4.439|method we'll talk about later that sort
1505.32|4.77|of does this anyway and does treat it as
1508.019|3.571|regression but we'll get to that we'll
1510.09|3.209|get to that later but in general you
1511.59|3.709|want to not treat this as regression
1513.299|5.791|because you have variable sized outputs
1515.299|5.47|so a really easy problem a really easy
1519.09|3.779|way to solve this is to think of
1520.769|4.081|detection not as regression but as
1522.869|3.391|classification right in machine learning
1524.85|3.09|regression and classification
1526.26|3.78|or your two hammers you just want to use
1527.94|4.26|those to beat all your problems right
1530.04|4.17|so we regression didn't work so we'll do
1532.2|3.96|classification instead we know how to
1534.21|3.84|classify image regions we just run it
1536.16|3.45|through a CNN right so we're going to do
1538.05|3.75|is we're going to take many of these
1539.61|4.2|input regions of the image put a
1541.8|3.9|classifier there and say like oh right
1543.81|4.35|this region of the image is it a cat no
1545.7|4.86|is it a dog no move it over a little bit
1548.16|3.81|oh we found a cat that's great move it
1550.56|3.36|over a little bit that's that's not
1551.97|3.3|anything so then we can actually just
1553.92|3.6|try out a whole bunch of different image
1555.27|4.77|regions run a classifier in each one and
1557.52|7.44|this will basically solve our variable
1560.04|9.78|size output problem so there's there's
1564.96|6.63|oh yeah question so the question of how
1569.82|2.28|to size how to decide what the window
1571.59|2.43|size
1572.1|4.41|the answer is we just try them all right
1574.02|4.05|just literally try them all so that's
1576.51|3.42|that's that's actually a big problem
1578.07|3.09|right because we need to try windows of
1579.93|2.85|different sizes of different positions
1581.16|3.3|of different scales when you do this
1582.78|2.97|robbery test image this is going to be
1584.46|5.36|really expensive right there's a whole
1585.75|4.07|lot of places we need to look yeah oh
1595.49|3.61|yeah so yeah so in practice you usually
1597.9|4.11|also when you're doing this
1599.1|5.1|classification you add an extra two
1602.01|3.72|things one you can add an extra class to
1604.2|3.78|say background and say like oh there's
1605.73|4.5|nothing here another thing you can do is
1607.98|3.9|not is do actually multi-label
1610.23|4.05|classification so you could output
1611.88|3.54|multiple positive things right that's
1614.28|2.61|actually pretty easy to do it's just
1615.42|3.33|instead of a soft max loss you have
1616.89|3.44|independent regression loss or
1618.75|4.17|independent logistic regression
1620.33|4.81|so that can actually let you say yes on
1622.92|3.84|multiple classes at one point but that's
1625.14|4.98|just swapping out a loss function so
1626.76|5.31|that's that's pretty easy to do right so
1630.12|3.06|actually like like we set a problem with
1632.07|2.52|this approach is that there's a whole
1633.18|4.5|bunch of different positions we need to
1634.59|4.47|evaluate the solution sort of a couple
1637.68|3.54|you as of a couple years ago was just
1639.06|3.8|use really class fat use really fast
1641.22|4.59|classifiers and try them all
1642.86|4.81|so actually detection is this really old
1645.81|2.85|problem in computer vision so you should
1647.67|3.24|probably have a little bit more
1648.66|4.74|historical perspective so starting in
1650.91|4.14|about 2005 there was this really
1653.4|3.45|successful approach to at the time
1655.05|3.42|really successful for pedestrian
1656.85|3.06|detection that use this feature
1658.47|3.57|representation called history
1659.91|3.69|orient ingredients so if you were called
1662.04|3.87|back to homework one you actually use
1663.6|4.53|this feature on the last part to
1665.91|4.56|actually do classification as well so
1668.13|3.57|this was actually a sort of the best
1670.47|4.26|feature that we had in computer vision
1671.7|4.71|circle around 2005 so the idea is we're
1674.73|2.97|just going to do linear classifiers on
1676.41|3.99|top of this feature and that's going to
1677.7|4.77|be our classifier so linear classifiers
1680.4|3.6|are really fast so the way this works is
1682.47|3.24|that we compute our histogram of
1684.0|4.23|oriented gradient feature for the whole
1685.71|4.68|image at multiple scales and we run this
1688.23|4.41|linear classifier at every scale every
1690.39|3.12|position just do it really fast just do
1692.64|3.57|it everywhere because it's a linear
1693.51|6.09|classifier and it's fast to evaluate and
1696.21|5.07|this worked really well in 2005 sort of
1699.6|2.85|people took this idea and worked on it a
1701.28|3.66|little bit more for the next couple
1702.45|5.25|years so sort of the one of the most
1704.94|4.43|important detection paradigms pre deep
1707.7|4.89|learning was this thing called the
1709.37|4.9|deformable parts model so I don't want
1712.59|4.29|to go too much into the details of this
1714.27|4.65|but I mean the basic idea is that we're
1716.88|4.11|still working on these histogram of
1718.92|3.72|Orion gradient features but now our
1720.99|4.05|model rather than just being a linear
1722.64|4.38|classifier we have this linear Club this
1725.04|4.41|linear sort of template for the pretty
1727.02|4.35|object and we also have these templates
1729.45|4.23|for parts that are allowed to sort of
1731.37|5.73|vary over spatial positions and deform a
1733.68|5.67|little bit and they have some some fancy
1737.1|4.65|for some fancy thing called a latent SVM
1739.35|5.31|to learn these things and a really fancy
1741.75|5.04|a dynamic programming algorithm to
1744.66|4.11|actually evaluate this thing really fast
1746.79|3.84|at test time this is actually kind of
1748.77|3.33|fun if you enjoy algorithms this this
1750.63|3.84|thing that this part is kind of fun to
1752.1|4.35|think about but the end result is that
1754.47|3.39|it's it's a mock it's a more powerful
1756.45|2.97|classifier because it allows a little
1757.86|3.51|bit of deform ability in your in your
1759.42|3.6|model and you can still evaluate it
1761.37|3.42|really fast so we're still just going to
1763.02|3.45|evaluate it everywhere every scale every
1764.79|4.05|position every aspect ratio just do it
1766.47|5.39|everywhere because it's fast and this
1768.84|5.49|actually worked really well in 2010
1771.86|3.58|around there so that was sort of state
1774.33|3.78|of the art and detection for many
1775.44|4.02|problems at that time so this is I don't
1778.11|2.88|want to spend too much time on this but
1779.46|3.9|there was a really cool paper last year
1780.99|4.14|that argued that these DPM models are
1783.36|4.26|actually just a certain type of
1785.13|4.44|continent right so right because these
1787.62|3.63|these histograms Borean gradients are
1789.57|3.489|like little edges we can compute engines
1791.25|3.039|with convolutions and then the history
1793.059|3.21|was kind of like pooling that sort of
1794.289|3.031|thing so if you're interested check out
1796.269|5.431|this paper it's kind of fun to think
1797.32|6.39|about right but we really want to work
1801.7|4.5|on make this thing work on classifiers
1803.71|5.91|that are not fast to evaluate like maybe
1806.2|5.579|a CNN so here this we this problem is
1809.62|3.75|still hard right we have many different
1811.779|3.12|positions we want to try when we
1813.37|3.899|probably can't actually afford to try
1814.899|4.321|them all so the solution is that we
1817.269|4.201|don't try them all we have some other
1819.22|4.14|thing that sort of guesses where we want
1821.47|3.899|to look and then we only apply our
1823.36|5.25|expensive classifier at those smaller
1825.369|8.13|number of locations so that idea is
1828.61|7.38|called region proposals so we a region
1833.499|4.68|proposal method is this thing that takes
1835.99|5.069|in an image and then outputs a whole
1838.179|5.88|bunch of regions where maybe possibly an
1841.059|5.281|object might be located so one way you
1844.059|4.11|can think about region proposals is that
1846.34|5.01|they're kind of like a really fast a
1848.169|4.86|class agnostic object detector right
1851.35|2.85|they don't care about the class they're
1853.029|2.97|not very accurate but they're pretty
1854.2|4.26|fast to run and they give us a whole
1855.999|4.77|bunch of boxes and the general intuition
1858.46|3.719|behind behind these region proposal
1860.769|3.451|methods is that they're kind of looking
1862.179|5.13|for blob like structures in the image
1864.22|4.98|right so like objects are generally like
1867.309|3.96|the dog I mean if you kind of squint it
1869.2|3.39|looks kind of like a white blob the cat
1871.269|3.211|looks kind of like a white blob these
1872.59|3.809|flowers are kind of blobby the eyes and
1874.48|3.569|the nose are kind of blobby so when you
1876.399|3.331|run these region proposal methods a lot
1878.049|3.6|of times what you'll see is they'll kind
1879.73|5.549|of put boxes around a lot of these
1881.649|5.791|blobby regions in the in the image so
1885.279|4.62|probably the most famous region proposal
1887.44|3.929|method is called selective search you
1889.899|3.75|don't really need to know exact into
1891.369|5.221|much detail how this works but the idea
1893.649|4.801|is that you start from your pixels and
1896.59|3.659|you kind of merge adjacent pixels
1898.45|4.799|together if they have similar color and
1900.249|4.951|texture and form these connected read
1903.249|3.87|these connected blob like regions and
1905.2|3.449|then you merge up these blob like
1907.119|4.5|regions to get bigger and bigger blobby
1908.649|4.291|parts and then for each of these
1911.619|2.94|different scales you could actually
1912.94|3.42|convert each of these blobby regions
1914.559|4.681|into a box by just drawing a box around
1916.36|4.5|it so then by doing this over multiple
1919.24|3.779|scales you end up with a whole bunch of
1920.86|4.259|boxes around sort of a lot of blobby
1923.019|3.601|stuff in the image and it's a reasonably
1925.119|4.401|fast to compute and actually
1926.62|5.16|cuts down the search space quite a lot
1929.52|3.61|but selective search really isn't the
1931.78|1.86|only game in town it's just maybe the
1933.13|1.92|most famous
1933.64|3.6|there's a whole bunch of different
1935.05|3.87|region proposal methods that people have
1937.24|3.39|developed so there was this paper last
1938.92|3.63|year that actually did a really cool
1940.63|3.33|thorough scientific evaluation of all
1942.55|3.93|these different region proposal methods
1943.96|4.92|and sort of gave you the pros and the
1946.48|4.29|cons of each and all that kind of stuff
1948.88|3.72|but I mean my takeaway from this paper
1950.77|3.96|was just use edge boxes if you have to
1952.6|4.14|pick one so it's because it's it's
1954.73|4.32|really fast it you can run it in about a
1956.74|3.81|third of a second per image compared to
1959.05|4.62|about 10 seconds for selective search
1960.55|8.4|but the more stars is better and it gets
1963.67|6.509|a lot of stars so it's good right so now
1968.95|3.0|that we have this idea of reagent
1970.179|3.541|proposals and we have this idea of a CNN
1971.95|4.77|classifier let's just put everything all
1973.72|5.82|together so that's then so this this
1976.72|6.06|idea was sort of first put together in a
1979.54|6.24|really nice way in 2014 in this method
1982.78|6.0|called our CNN the idea is it's a region
1985.78|4.35|based CNN method so it's I mean it's
1988.78|3.39|it's pretty simple now that we've seen
1990.13|4.2|all the pieces we have an input image
1992.17|4.11|we're going to run a region proposal
1994.33|4.8|method like selective search to get
1996.28|3.899|about maybe 2,000 boxes of different
1999.13|3.03|scales and positions
2000.179|3.901|I mean 2,000 is still a lot but it's a
2002.16|4.8|lot less than all possible boxes in the
2004.08|4.92|image now for each of those boxes we're
2006.96|4.86|going to crop and warp that image region
2009.0|5.52|to some fixed size and then run it
2011.82|3.96|forward through a CNN to classify and
2014.52|4.35|then this CNN is going to have a
2015.78|5.37|regression head and a regression head
2018.87|5.7|here and a classification head they used
2021.15|5.31|SVM's here so the idea is that this this
2024.57|3.239|regression head can sort of correct for
2026.46|3.87|region proposals that were a little bit
2027.809|4.861|off right so this this actually works
2030.33|4.92|really well it's really simple yeah it's
2032.67|4.44|pretty cool but unfortunately that so
2035.25|4.05|unfortunately the training pipeline is a
2037.11|4.44|little bit complicated so the way that
2039.3|4.44|you end up train training this our CNN
2041.55|4.05|model is you know like many like many
2043.74|3.18|models you first start by downloading a
2045.6|3.84|model from the internet that works well
2046.92|6.3|for classification it originally they
2049.44|5.13|were using an Alex nut then then next we
2053.22|3.72|actually want to fine-tune this model
2054.57|3.69|for detection right because this this
2056.94|3.219|classification model was probably
2058.26|3.819|trained on imagenet for a thousand
2060.159|3.48|classes but your detection data set has
2062.079|2.79|a different number of classes and the
2063.639|3.48|image statistics are a little bit
2064.869|3.661|different so you still run this you
2067.119|2.97|still train this network for
2068.53|3.359|classification but you have to add a
2070.089|3.84|couple new layers at the ends to deal
2071.889|3.78|with your classes and to help you deal
2073.929|4.74|with the slightly different statistics
2075.669|4.68|of your image data so here you're just
2078.669|3.031|doing classification still but you're
2080.349|3.03|not running it on whole images you're
2081.7|3.209|running it on positive and negative
2083.379|4.98|regions of your images from your
2084.909|5.041|detection data set right so you
2088.359|5.18|initialize a new layer and you and you
2089.95|6.27|train this thing again for your data set
2093.539|4.901|next we actually want to cache all these
2096.22|4.2|features to disk so for every image in
2098.44|4.26|your in your data set you run selective
2100.42|3.869|search you run that image you extract
2102.7|3.93|those regions you warp them you run it
2104.289|5.28|through the CNN and you cache those
2106.63|4.409|features to disk and something important
2109.569|4.381|for this step is to have a large hard
2111.039|4.861|drive the Pascal data set is not too big
2113.95|3.899|maybe order of a couple tens of
2115.9|3.449|thousands of images but extracting these
2117.849|4.71|features actually takes hundreds of
2119.349|6.091|gigabytes so that's not so great and
2122.559|5.671|then next we have this we want to train
2125.44|4.29|our s VMs to actually be able to
2128.23|2.7|classify in it will different are
2129.73|4.44|different classes based on these
2130.93|5.07|features so here we want to run a bunch
2134.17|5.07|of we want to train a bunch of different
2136.0|5.52|binary s VMs to classify image regions
2139.24|4.92|as to whether or not they contain or
2141.52|3.779|don't contain that that one object so
2144.16|2.459|this goes back to a question a little
2145.299|3.691|bit ago that sometimes you actually
2146.619|5.22|might want to have one region have
2148.99|4.44|multiple positive be able to output YES
2151.839|3.571|on multiple classes for the same image
2153.43|3.81|region and one way that they do that is
2155.41|4.169|just by training separate binary SPMS
2157.24|4.109|for each class right so then this is
2159.579|4.77|sort of an offline process they just use
2161.349|6.661|libous vm so you have these features
2164.349|5.551|these are maybe those aren't positive
2168.01|3.839|samples for a caddis vm that doesn't
2169.9|3.449|make any sense right but you get the
2171.849|2.821|idea right you have these different
2173.349|3.27|imagery you have these different image
2174.67|3.81|regions you have these features that you
2176.619|3.331|save to disk for those regions and then
2178.48|3.54|you divide them into positive and
2179.95|3.81|negative samples for each for each class
2182.02|4.86|and you just train these these binary
2183.76|5.76|SPMS so you do this for cat you do this
2186.88|4.729|the same thing for dog and you just do
2189.52|4.62|this for every class in your data set
2191.609|4.121|right and then there's another step
2194.14|3.869|so then there's this idea of box
2195.73|4.049|regression so sometimes your agent
2198.009|3.211|proposals aren't perfect so what we
2199.779|4.23|actually want to do is be able to
2201.22|4.589|regress from from these cached features
2204.009|4.921|to a correction on to the region
2205.809|4.95|proposal and that correction has this
2208.93|3.659|kind of funny parameterize normalized
2210.759|3.631|representation you can read details
2212.589|3.571|about in the paper but kind of the
2214.39|3.899|intuition is that maybe for this for
2216.16|3.57|this for this region proposal it was
2218.289|3.72|pretty good we don't really need to make
2219.73|4.44|any any Corrections but maybe this one
2222.009|3.81|in the middle the proposal was too far
2224.17|3.51|to the left it should have like the
2225.819|3.661|correct ground truth is a little bit to
2227.68|3.659|the right so we want to regress to this
2229.48|2.97|correction vector that actually tells
2231.339|3.631|that we need to shift a little bit to
2232.45|4.289|the right or maybe this guy is a little
2234.97|3.569|bit too wide it includes too much of the
2236.739|3.991|stuff outside the cat so we want to
2238.539|3.841|regress to this correction vector that
2240.73|3.96|tells us we need to shrink the region
2242.38|4.139|proposal a little bit so again this is
2244.69|3.599|just a linear they just do linear
2246.519|3.72|regression which you could you know from
2248.289|4.141|229 you have these these features you
2250.239|5.52|have these targets you just train linear
2252.43|5.55|regression as that so before we look at
2255.759|3.451|the results we should talk I want to
2257.98|2.519|talk a little bit about the different
2259.21|3.539|data sets that people use for detection
2260.499|5.79|there's kind of three that you'll see in
2262.749|6.27|practice one is the Pascal vo C data set
2266.289|4.681|it was pretty important I think in the
2269.019|3.871|earlier 2000s but now it's a little bit
2270.97|4.17|small so this one's all about it this
2272.89|4.619|one's 20 classes and about 20,000 images
2275.14|4.53|and tends to have about two objects per
2277.509|3.99|image so because this is a relatively
2279.67|3.149|small ish data set you'll see a lot of
2281.499|3.721|detection papers work on this just
2282.819|4.26|because it's easier to handle but
2285.22|4.079|there's also an image net detection data
2287.079|3.601|set image net runs a whole bunch of
2289.299|3.391|challenges as you've probably seen by
2290.68|3.869|now we saw classification we saw
2292.69|4.349|localization there's also an image net
2294.549|4.591|detection challenge but for detection
2297.039|4.23|there's only 200 classes not the
2299.14|4.08|thousand from classification but it's
2301.269|3.691|it's very big almost half a million
2303.22|2.879|images so you don't see as many papers
2304.96|3.059|work on it just because it's kind of
2306.099|3.781|annoying to handle but there's only
2308.019|3.48|about one object per image and then
2309.88|3.629|Maurice more recently there's this one
2311.499|3.901|from Microsoft called cocoa which has
2313.509|3.691|fewer classes fewer images but actually
2315.4|3.54|has a lot more objects per image so
2317.2|5.73|people like to work on that now because
2318.94|5.639|it's more interesting right there's also
2322.93|3.21|this this when you're talking about
2324.579|3.301|detection there's this funny evaluation
2326.14|3.6|metric we use called mean average
2327.88|3.39|I don't want to get too much into the
2329.74|3.18|details like what you really need to
2331.27|5.88|know is that it's a number between 0 and
2332.92|5.94|100 and 100 is good and it and also I
2337.15|3.42|mean kind of the intuition is that it's
2338.86|4.17|you want to have the right you want to
2340.57|4.29|have true positives get high scores and
2343.03|4.17|you also have one I have some threshold
2344.86|4.2|on that your boxes you produce need to
2347.2|3.99|be within some threshold of the correct
2349.06|4.11|box and you can usually this that
2351.19|3.24|threshold is 0.5 on intersection over
2353.17|2.64|Union but you'll see different
2354.43|4.59|challenges use slightly different things
2355.81|4.56|for that right so let's now that we
2359.02|3.69|understand the data sets and the
2360.37|4.74|evaluation let's cor CNN did right so
2362.71|4.08|this is on the past on two versions of
2365.11|3.03|the Pascale dataset like I said it's
2366.79|3.57|smaller's you'll see a lot of results on
2368.14|4.98|this the there's different versions one
2370.36|4.02|in 2007 2010 you'll often see people use
2373.12|2.79|those just because the test data is
2374.38|5.19|publicly available so it's easy to
2375.91|5.52|evaluate yeah but so in this this
2379.57|4.2|deformable parts model that we saw from
2381.43|5.16|2011 from a couple slides ago it's
2383.77|5.01|getting about 20 about 30 on mean
2386.59|4.5|average precision there's this other
2388.78|3.51|method called region let's from 2013
2391.09|2.49|that was sort of the state of the art
2392.29|3.18|that I could find right before deep
2393.58|3.33|learning but it's it's sort of a similar
2395.47|3.69|flavor you have these features and it's
2396.91|4.32|classifiers on top of features and our
2399.16|3.9|CNN is this pretty simple thing we just
2401.23|3.81|saw and actually jump it actually
2403.06|3.72|improves the performance quite a lot so
2405.04|3.48|the first thing to see is that we had a
2406.78|5.04|big improvement when we just switch this
2408.52|5.07|pretty simple framework using CNN's and
2411.82|3.24|actually this this result here is
2413.59|3.45|without the bounding box regressions
2415.06|3.84|this is only using the region proposals
2417.04|3.27|and the SPMS actually if you include
2418.9|3.32|this additional bounding box or puzzle
2420.31|4.35|step it actually helps quite a bit
2422.22|4.45|another fun thing to note is that if you
2424.66|4.29|take our CNN and you do everything the
2426.67|4.05|same except you use vgg 16 instead of
2428.95|3.72|alex net you get another pretty big
2430.72|3.24|boost in performance so this is kind of
2432.67|2.61|similar to what we've seen before that
2433.96|3.03|just using these more powerful image
2435.28|4.89|features tends to help a lot of
2436.99|5.19|different tasks right this is really
2440.17|3.72|good right we've we've done like a huge
2442.18|5.04|improvement on detection compared to
2443.89|5.67|2013 that's amazing but our CNN is not
2447.22|5.04|perfect it has some problems right so
2449.56|5.22|it's pretty slow at test time right we
2452.26|4.26|saw that we have maybe 2000 regions we
2454.78|4.83|need to evaluate our CNN for each region
2456.52|4.89|that's kind of slow we also had this
2459.61|4.71|this slightly subtle problem where
2461.41|4.98|our SVM and our regression those were
2464.32|4.44|sort of trained offline using like Lib
2466.39|4.35|SVM and linear regression so actually
2468.76|3.45|the weights of our of our CNN didn't
2470.74|3.27|really have the chance to update in
2472.21|4.41|response to what those parts of the
2474.01|4.71|other network of those objectives wanted
2476.62|3.84|to do and we also have this kind of
2478.72|5.28|complicated training pipeline that was a
2480.46|5.88|bit of a mess so to fix these problems a
2484.0|5.67|year later we had this thing called fast
2486.34|6.24|our CNN so fast our CNN it was presented
2489.67|5.07|pretty recently at in ICCB just in
2492.58|4.52|december but the idea is really simple
2494.74|5.04|we're just going to swap the order of
2497.1|4.87|extracting regions and running the CNN
2499.78|3.75|so this is kind of kind of related to
2501.97|4.32|this sliding-window idea we saw with
2503.53|5.04|over feet so here the pipeline at test
2506.29|4.23|time looks kind of similar we have this
2508.57|3.69|input image we're going to not we're
2510.52|3.18|going to take this high-resolution input
2512.26|3.12|image and run it through the
2513.7|3.36|convolutional layers of our network and
2515.38|3.78|now we're going to get this high
2517.06|4.41|resolution convolutional feature map and
2519.16|4.38|now our region proposals we're going to
2521.47|3.93|extract directly features for those
2523.54|3.96|region proposals from this convolutional
2525.4|5.37|feature map using this thing called roi
2527.5|4.65|pooling and then the regions the the
2530.77|3.39|features for these the convolutional
2532.15|4.02|features for those regions will be fed
2534.16|3.72|into our fully connected layers and will
2536.17|4.71|again have a classification head and a
2537.88|4.86|regression head like we saw before so
2540.88|3.45|this is really cool it's it's pretty
2542.74|4.14|great it solves a lot of the problems
2544.33|4.68|that we just saw with our CNN so our CNN
2546.88|4.14|is really slow at test time we solve
2549.01|3.69|this problem by just sharing this this
2551.02|5.33|computation of convolutional features
2552.7|6.09|across different region proposals our
2556.35|3.79|CRS CNN also had these problems at
2558.79|4.62|training time where we had this this
2560.14|4.59|messy training pipeline we had this this
2563.41|3.3|problem where we were training different
2564.73|3.99|parts of the network separately and the
2566.71|3.42|solution is pretty simple we just you
2568.72|3.03|know train it all together all at once
2570.13|3.63|don't don't have this complicated
2571.75|3.33|pipeline which we can actually do now
2573.76|4.38|that we have this this pretty nice
2575.08|4.92|function from inputs to outputs right so
2578.14|3.15|you can see that our that fast our CNN
2580.0|3.09|actually solves quite a lot of the
2581.29|4.8|problems that we saw with vanilla our
2583.09|5.61|CNN sort of the really interesting
2586.09|4.53|technical bit in fast our CNN was this
2588.7|4.74|problem of ROI region of interest
2590.62|4.02|pooling so the idea is that we have this
2593.44|3.3|input image
2594.64|3.9|that's probably high resolution and we
2596.74|3.21|have this region proposal that's maybe
2598.54|3.99|coming out of selective search or edge
2599.95|4.59|boxes or something like that and we can
2602.53|3.96|put this region this high resolution
2604.54|3.48|image through our convolutional and
2606.49|4.14|pooling layers just fine because those
2608.02|4.74|are sort of scale invariant they scale
2610.63|3.69|up to different sizes of inputs but now
2612.76|3.84|the problem is that the fully connected
2614.32|5.25|layers from the are pre-trained network
2616.6|5.49|are expecting these pretty low res con
2619.57|6.42|features whereas these features from the
2622.09|5.31|whole image are high res so now we solve
2625.99|2.01|this problem in a pretty straightforward
2627.4|2.61|way
2628.0|3.93|so given this region proposal we're
2630.01|3.84|going to project it on to sort of the
2631.93|4.53|the spatial part of that comm feature
2633.85|4.53|volume now we're going to divide that
2636.46|3.15|con feature volume into a little grid
2638.38|3.63|right
2639.61|4.47|divide that thing into this H by W grid
2642.01|4.71|that the downstream layers are expecting
2644.08|5.37|and we do max pooling within each of
2646.72|4.08|those grid cells so now we've so now
2649.45|3.15|we've through this pretty simple
2650.8|4.14|strategy we've taken this region
2652.6|4.62|proposal and we've shared convolutional
2654.94|4.44|features now we've extracted this fixed
2657.22|4.5|size output for that region but for that
2659.38|4.2|for that region proposal right so this
2661.72|3.87|is basically just swapping the order of
2663.58|3.83|convolution and warping and cropping
2665.59|4.11|that's one way to think about it and
2667.41|3.91|also this is a pretty nice operation
2669.7|3.51|because since this thing is basically
2671.32|3.9|just max pooling and we know how to back
2673.21|3.45|propagate through max pooling you can
2675.22|3.15|back propagate through these these
2676.66|4.44|region of interest pooling layers just
2678.37|4.73|fine and that's what really allows us to
2681.1|4.23|Train this whole thing in a joint way
2683.1|3.64|right so let's see some results and
2685.33|3.69|these are actually pretty cool pretty
2686.74|4.2|amazing right so for training time our
2689.02|3.36|CNN it had this complicated pipeline we
2690.94|2.73|had save all this stuff to disk we have
2692.38|3.42|to do all this stuff independently and
2693.67|4.95|even on that pretty small Pascal data
2695.8|5.58|set it took 84 hours to train fast our
2698.62|6.96|CNM is much faster you can train in a
2701.38|6.06|day at far as test time vanilla our CNN
2705.58|3.78|is pretty slow because again we're
2707.44|4.59|running these independent forward passes
2709.36|5.1|of the CNN for each region proposal
2712.03|4.05|whereas for fast our CNN where we can
2714.46|3.54|sort of share the computation between
2716.08|4.38|different region proposals and get this
2718.0|5.97|gigantic speed-up at test time 146
2720.46|5.25|that's great amazing and in far in terms
2723.97|3.45|of performance I mean it does a little
2725.71|2.73|bit better it's not a drastic difference
2727.42|2.64|in performance
2728.44|3.78|but this could probably be attributed to
2730.06|3.75|this fine-tuning property that with fast
2732.22|3.18|our CNN you can actually find two in all
2733.81|3.63|parts of the convolutional net work
2735.4|3.75|jointly to help with these output tasks
2737.44|4.32|and that's probably why you see a bit of
2739.15|4.14|an increase here right so this is great
2741.76|4.89|right what's what could possibly be
2743.29|6.299|wrong with fast our CNN it looks amazing
2746.65|4.949|the big problem is that these test time
2749.589|4.53|speeds don't include region proposals
2751.599|4.051|right so now fast our CNN is so good
2754.119|3.421|that actually the bottleneck is
2755.65|2.28|computing region proposals that's pretty
2757.54|3.18|cool
2757.93|4.62|so once you factor in the the speed of
2760.72|4.349|compute a computing these region
2762.55|4.289|proposals on CPU you can see that a lot
2765.069|4.02|of our speed benefits disappear right
2766.839|4.581|we're only 25 X faster and we kind of
2769.089|5.131|lost that beautiful hundred X speed-up
2771.42|4.3|also now because it takes maybe two
2774.22|3.21|seconds to run actually per image
2775.72|3.21|end-to-end you can't really use this
2777.43|5.04|real time it's still kind of an offline
2778.93|5.46|processing thing right so the solution
2782.47|4.349|of this should be pretty obvious right
2784.39|3.75|we were already using a convolutional
2786.819|4.351|network for regression we're already
2788.14|5.58|using it for classification why not use
2791.17|5.79|it for region proposals too right this
2793.72|5.82|should work maybe kind of crazy so
2796.96|8.28|that's that's a paper anyone want to
2799.54|9.059|guess the name yeah so it's faster are
2805.24|5.129|CNN yes they were they were really
2808.599|3.871|creative here right but the idea is
2810.369|4.051|pretty simple right we're something from
2812.47|4.05|fast our CNN we're already taking our
2814.42|4.08|input image and we're computing these
2816.52|5.25|big convolutional feature maps over the
2818.5|5.19|entire input image so then instead of
2821.77|3.9|using some external method to compute
2823.69|3.81|region proposals they add this little
2825.67|3.99|thing called a region proposal network
2827.5|4.079|that looks directly at these combat
2829.66|4.11|looks at these last their convolutional
2831.579|3.721|features and is able to produce region
2833.77|4.41|proposals directly from that
2835.3|4.44|convolutional feature map and then once
2838.18|3.81|you have region proposals you just do
2839.74|4.44|the same thing as fast our CNN you use
2841.99|5.55|this roi pooling and all the upstream
2844.18|5.22|stuff is the same as fast our CNN so
2847.54|3.72|really the the novel bit here is this
2849.4|2.969|region proposal network it's it's really
2851.26|3.14|cool right we're doing the whole thing
2852.369|3.871|and one giant convolutional network
2854.4|5.62|right so the way that this region
2856.24|6.059|proposal network works is that were sort
2860.02|3.87|of we receive as input this convolution
2862.299|3.361|feature map this may be coming out of
2863.89|3.839|the last layer of our convolutional
2865.66|4.439|features and we're going to add like
2867.729|4.77|like most things our region proposal
2870.099|4.561|network is a convolutional network right
2872.499|5.28|so actually this is a typo this is a 3x3
2874.66|4.98|convicts that right so we have a sort of
2877.779|4.59|a sliding window approach over our
2879.64|4.77|convolutional feature map but sliding we
2882.369|5.4|sliding window is just a convolution
2884.41|5.609|right so we just have a 3x3 convolution
2887.769|4.651|on top of this feature map and then we
2890.019|4.05|have this this familiar this familiar to
2892.42|4.169|head structure inside the region
2894.069|5.01|proposal Network where we're doing
2896.589|4.68|classification where here we just want
2899.079|5.76|to say whether or not it's an object and
2901.269|6.03|also regression to regress from this
2904.839|5.01|sort of position on to an actual region
2907.299|4.74|proposal so the idea is that the
2909.849|3.99|position of the sliding window relative
2912.039|3.841|to the feature map sort of tells us
2913.839|4.38|where we are in the image and then these
2915.88|4.709|regression outputs sort of give us
2918.219|5.37|Corrections on top of this this position
2920.589|3.96|in the feature map but actually they
2923.589|3.63|make it a little bit more complicated
2924.549|4.71|than that so instead of regressing
2927.219|3.96|directly from this position in the
2929.259|4.141|convolutional feature map they have this
2931.179|4.11|notion of these different anchor boxes
2933.4|3.959|so you could imagine taking these
2935.289|4.26|different size and shape anchor boxes
2937.359|4.32|and sort of pasting them in the original
2939.549|3.93|image at the point of the image
2941.679|4.05|corresponding to this point in the
2943.479|3.84|feature map right like in fast our
2945.729|3.96|sienna we were projecting forward from
2947.319|4.14|the image into the feature map now we're
2949.689|3.63|doing the opposite we're projecting from
2951.459|5.431|the feature map back into the image for
2953.319|6.12|these for these anchor boxes so then for
2956.89|4.649|each of these anchor boxes they use sort
2959.439|3.84|of n convolutional anchor boxes they use
2961.539|5.46|the same ones at every position in the
2963.279|6.78|image and they for each of these anchor
2966.999|4.921|boxes they produce a score as to whether
2970.059|4.02|or not that anchor box corresponds to an
2971.92|4.079|object and they also produce for
2974.079|3.841|regression coordinates that couldn't
2975.999|4.98|correct that anchor box in similar ways
2977.92|4.829|that we saw before and now this region
2980.979|3.75|proposal Network you can just train to
2982.749|6.45|try to predict sort of as a class
2984.729|6.84|agnostic object detector so faster our
2989.199|3.99|CN n in the original paper they trained
2991.569|3.061|this thing in kind of a funny way where
2993.189|2.311|first they trained the region proposal
2994.63|2.88|network then
2995.5|4.05|train fast our CNN then they do some
2997.51|3.33|magic to merge together and at the end
2999.55|3.96|of the day they have one network that
3000.84|4.62|produces everything so this this is a
3003.51|4.26|little bit messy but in original paper
3005.46|4.05|they describe this thing but since then
3007.77|2.58|they've had some unpublished work where
3009.51|3.03|they actually just chained the whole
3010.35|4.26|thing jointly where they're sort of they
3012.54|4.77|have one big network where you have an
3014.61|4.86|image coming in you have this written
3017.31|4.11|inside the region proposal network you
3019.47|3.81|have a classification loss to classify
3021.42|3.99|whether each region proposal is or is
3023.28|3.81|not an object you have these bounding
3025.41|3.93|box regressions inside the region
3027.09|4.98|proposal network to regress on top of
3029.34|5.34|your convolutional anchors and then from
3032.07|4.83|fast then we do ROI pooling and do this
3034.68|3.42|fast our CNN trick and then at the end
3036.9|3.18|of the network we have this
3038.1|4.02|classification loss to say which class
3040.08|5.04|it is and this regression loss to
3042.12|5.91|correct to have a correction on top of
3045.12|4.68|the region proposal so this is this big
3048.03|11.91|thing that's just one big network with
3049.8|12.06|four losses yeah 3x3 convolution so the
3059.94|4.83|proposal scores and regression
3061.86|5.07|coordinates are produced by a 3 by 3 3
3064.77|4.89|by 3 and then a pair of 1x1 convolutions
3066.93|4.59|off the feature map right so the idea is
3069.66|3.63|that um we're looking at these different
3071.52|4.5|anchor boxes of different positions and
3073.29|4.56|scales and but we're actually looking at
3076.02|3.33|the same position in the feature map to
3077.85|2.97|classify those different anchor boxes
3079.35|2.4|but you'd have different you learn
3080.82|6.39|different weights for the different
3081.75|7.8|anchors I think it's mostly empirical
3087.21|3.3|right so the three by the idea is just
3089.55|3.03|you want to have a little bit of
3090.51|3.81|non-linearity you could imagine just
3092.58|3.21|doing sort of a direct one-by-one
3094.32|4.41|convolution directly off the feature
3095.79|4.86|maps but I think they don't discuss this
3098.73|3.54|in the paper but I'm guessing just a 3x3
3100.65|3.75|tends to work a bit better but there's
3102.27|3.54|no like really deep reason why you why
3104.4|2.88|you do that you could be more it could
3105.81|2.67|be less it could be a bigger kernel it's
3107.28|2.67|just sort of you have this little
3108.48|4.68|convolutional network with two heads
3109.95|3.63|that's the main point any other
3113.16|2.69|questions
3113.58|2.27|yeah
3116.589|4.831|have the like after doing all the fun
3118.839|5.28|solution there's right yeah so what
3121.42|5.819|happens if we just prune the image just
3124.119|4.94|to that particular length area before we
3127.239|4.8|start like doing all different
3129.059|6.69|convolution and just keep like all the
3132.039|6.03|neighboring pixels wouldn't it be like
3135.749|3.73|sorry I don't quite understand because
3138.069|4.95|your convolutional feature map
3139.479|5.401|corresponds to the whole image the point
3143.019|3.21|is that we don't actually want to
3144.88|3.119|process the whole image we want to pick
3146.229|3.661|out some regions of the image to do more
3147.999|11.73|processing on but we need to choose
3149.89|11.579|those regions somehow yes that's
3159.729|3.691|basically the that's basically this idea
3161.469|4.23|of using external region proposals right
3163.42|3.99|so the eat when you do external region
3165.699|4.5|proposals you're sort of picking it
3167.41|4.349|first before you do the convolutions but
3170.199|3.721|it's just sort of a nice thing if you
3171.759|3.6|can do it all at once so it's like
3173.92|3.019|convolutions are kind of this general
3175.359|3.571|like really general processing
3176.939|3.34|processing that you can do to the image
3178.93|2.7|so you're kind of hoping that
3180.279|2.371|convolutions are good enough for
3181.63|2.76|classification I got enough for
3182.65|3.029|regression the types of information that
3184.39|2.459|you have in those convolutions is
3185.679|3.481|probably good enough for classifying
3186.849|4.26|regions as well so it's actually it's
3189.16|3.839|actually a computational savings because
3191.109|4.11|at the end of the day you end up using
3192.999|4.35|the same convolutional feature map for
3195.219|3.57|everything for the region proposals for
3197.349|3.18|the downstream classification for the
3198.789|4.8|downstream regression so that's actually
3200.529|6.78|why you get the speed-up here yeah but
3203.589|5.28|good question yeah so then we have this
3207.309|3.361|big Network we train it with four losses
3208.869|4.56|and now we can do object detection sort
3210.67|5.519|of all at once that's pretty cool so if
3213.429|6.18|we look at results comparing the three
3216.189|6.211|our cnn's of various velocities then we
3219.609|4.95|for original our CNN it took about 50
3222.4|3.869|seconds at test time per image this is
3224.559|3.69|counting the region proposals this is
3226.269|3.871|counting running the CNN separately for
3228.249|4.95|each region proposal that's pretty slow
3230.14|4.829|now fast our CNN we saw was sort of
3233.199|5.58|bottlenecked by the region proposal time
3234.969|5.941|but once we move to faster our CNN then
3238.779|4.32|those region proposals are basically
3240.91|4.049|coming for free since they're just the
3243.099|4.65|way we compute region proposals is just
3244.959|4.62|a tiny 3x3 convolution and a couple 1x1
3247.749|2.551|convolutions so those are very cheap to
3249.579|3.211|evaluate
3250.3|4.26|so in a test time faster our CNN runs in
3252.79|6.29|the fifth of a second on a pretty high
3254.56|4.52|resolution image so that's actually yeah
3269.64|4.75|well I mean all your convolutions always
3272.23|3.93|have zero padding so you're not like one
3274.39|2.73|of the ideas behind zero padding is
3276.16|3.12|you're hoping not to throw away
3277.12|5.31|information from the edges so I think
3279.28|4.56|maybe you might have a problem with if
3282.43|3.27|you didn't do the zero padding it might
3283.84|3.81|be more of a problem but I mean as we
3285.7|3.39|sort of discussed before the fact that
3287.65|2.88|you're adding that zero padding might
3289.09|3.96|affect the statistics of those features
3290.53|4.41|so it could maybe be a bit of a problem
3293.05|4.68|but in practice it seems to work just
3294.94|4.56|fine but actually that yeah that type of
3297.73|3.63|analysis of where do we have failure
3299.5|3.0|cases where do we get things wrong is a
3301.36|2.46|really important process when you're
3302.5|2.76|developing new algorithms and that can
3303.82|5.31|give you insight onto what might make
3305.26|26.94|things better yeah any other questions
3309.13|24.96|yeah so I mean I have it I have the
3332.2|3.36|intuition that maybe it might help but
3334.09|3.3|it's actually kind of hard to that X to
3335.56|3.93|do that experiment because the data sets
3337.39|3.54|are different right because when you
3339.49|3.93|work when you work on a classification
3340.93|4.02|data set like imagenet that's one thing
3343.42|3.6|but then when you work on detection it's
3344.95|4.02|this other data set and I haven't like
3347.02|3.96|you could imagine trying to classify the
3348.97|3.66|detection images based on what objects
3350.98|3.51|are present but I haven't really seen
3352.63|4.11|any really good comparisons that try to
3354.49|3.21|study that empirically but I mean that'd
3356.74|6.89|be a cool experiment tapping your
3357.7|5.93|project yeah
3363.71|11.79|your bounty bosses so that they also so
3374.089|3.331|that's that's actually a very good
3375.5|4.74|question so then you have this problem
3377.42|4.679|with ROI pooling right because the way
3380.24|3.84|that the ROI pooling work is was by
3382.099|3.601|dividing that thing into this fixed grid
3384.08|3.45|and doing max pooling once you do
3385.7|4.139|rotations it's actually kind of
3387.53|4.14|difficult there's this really cool paper
3389.839|3.331|from deep mind in the lab over the
3391.67|4.86|summer called spatial transformer
3393.17|4.949|networks that actually introduces a a
3396.53|3.99|really cool way to solve this problem
3398.119|3.961|and the idea is that instead of doing
3400.52|3.66|ROI pooling we're going to do bilinear
3402.08|4.74|interpolation kind of like you might use
3404.18|4.14|for textures and graphics so once you do
3406.82|3.68|bilinear interpolation then you actually
3408.32|4.17|can do maybe these these crazy regions
3410.5|3.849|so yeah that's definitely something
3412.49|3.33|people are thinking about but it hasn't
3414.349|14.191|been incorporated into the into the
3415.82|14.01|whole pipeline yet yeah you could that
3428.54|3.51|would be slow then you're back in this
3429.83|4.23|sort of our CNN regime right and look at
3432.05|4.799|that 250 times slower do you really want
3434.06|4.83|to pay that price I mean I think another
3436.849|3.75|practical concern with rotated objects
3438.89|4.44|is that we don't really have that ground
3440.599|4.201|truth in our datasets so for most for
3443.33|3.12|these most of these detection datasets
3444.8|3.33|the only ground truth information we
3446.45|3.75|have are these access aligned bounding
3448.13|4.5|boxes so it's hard you don't really have
3450.2|3.63|a ground truth position so that's kind
3452.63|2.67|of a practical concern why I think
3453.83|5.82|people haven't really explored this so
3455.3|6.39|much yeah so the end end story with
3459.65|4.56|faster are CN n is it super fast and it
3461.69|6.27|does about the same right that's good it
3464.21|5.879|works so actually really interesting is
3467.96|3.54|now at this point I you egg you can
3470.089|3.331|actually understand the state of the art
3471.5|3.24|in object detection so this is this is
3473.42|3.15|sort of the best object detector in the
3474.74|4.619|world it crushed everyone at the image
3476.57|5.94|net challenge in image net and cocoa
3479.359|5.01|challenges in December and like most
3482.51|4.349|other things it's this deep residual
3484.369|4.98|network so the best object sector in the
3486.859|6.211|world right now is 101 layer residual
3489.349|6.99|network plus faster RC n n plus a couple
3493.07|4.2|other goodies here right so we talked
3496.339|2.671|about we talked
3497.27|5.43|Oh pastor our CNN we thought we saw
3499.01|5.64|ResNet last year they have to get a next
3502.7|3.54|day always for competitions you need to
3504.65|3.63|add a couple crazy things to just get a
3506.24|3.99|little bit boost in performance right so
3508.28|3.87|here this box refinement they actually
3510.23|4.35|do multiple steps of refining the
3512.15|4.83|bounding box because you you sort of saw
3514.58|4.53|that in the fast our CNN framework
3516.98|3.6|you're doing this correction on top of
3519.11|2.76|your region proposal so and you could
3520.58|3.24|actually feed that back into the network
3521.87|4.41|and reclassify and reget another
3523.82|3.63|prediction so that's this box refinement
3526.28|4.59|step it gives you a little bit of boost
3527.45|5.85|they add context so in addition to
3530.87|4.89|classifying just the just the region
3533.3|5.64|they get a vector that gives you the
3535.76|4.86|whole features for the entire image that
3538.94|3.12|sort of gives you more context than just
3540.62|3.18|that little crop and that gives you a
3542.06|3.72|little bit more performance and they
3543.8|3.93|also do multi scale testing kind of like
3545.78|3.57|we saw in over feet how they're so they
3547.73|3.09|actually run the thing on images at
3549.35|3.06|different sizes a test time and then
3550.82|3.39|aggregate or those different sizes and
3552.41|5.91|when you put all those things together
3554.21|7.44|you win a lot of competitions so this
3558.32|4.92|thing one on so KOCO actually Microsoft
3561.65|3.75|Coco actually runs a detection challenge
3563.24|4.92|and they won the detection challenge on
3565.4|4.32|cocoa we can also look at the rapid
3568.16|3.75|progress on the image net detection
3569.72|4.68|challenges over the last couple years so
3571.91|4.11|you can see in 2013 was sort of the
3574.4|5.28|first time that we had these deep
3576.02|5.43|learning detection models so over feet
3579.68|4.02|that we saw for localization they
3581.45|3.72|actually submitted they had a version of
3583.7|4.08|their system that works on detection as
3585.17|5.13|well by sort of changing the logic whit
3587.78|3.84|by which they merge bounding boxes and
3590.3|4.14|they did pretty good but they were
3591.62|4.64|actually outperformed by this other this
3594.44|4.02|other group called you vision that was
3596.26|4.87|sort of not a deep learning approach
3598.46|4.92|they used a lot of features but and then
3601.13|3.69|in 2014 we actually saw both of these
3603.38|4.17|where deep learning approaches and
3604.82|4.2|Google actually won that one by using a
3607.55|3.99|Google net plus some other detection
3609.02|4.65|stuff on top of Google net and then in
3611.54|4.41|2015 things went crazy and these
3613.67|4.32|residual networks plus faster are CNN
3615.95|3.51|just crushed everything so I think
3617.99|2.82|detection especially over the last
3619.46|3.24|couple years has been a really exciting
3620.81|3.27|thing because we've seen this really
3622.7|2.85|rapid progress over the last couple
3624.08|4.14|years in detection like most other
3625.55|5.31|things and another point I think is kind
3628.22|4.59|of fun to make is that actually um
3630.86|3.66|for all like again to win competitions
3632.81|3.12|you know Andre said you ensemble and get
3634.52|3.27|two percent so you always win
3635.93|4.8|competitions with an ensemble but
3637.79|5.43|actually sort of for fun microsoft also
3640.73|4.77|submitted their best single ResNet model
3643.22|4.08|this was not an ensemble and just a
3645.5|3.63|single ResNet model actually beat all
3647.3|4.07|the other things from all the other
3649.13|4.62|years so that's actually pretty cool
3651.37|6.01|yeah that's that's the best detector out
3653.75|7.14|there so this is kind of a fun thing
3657.38|5.61|right so this is a really so we talked
3660.89|4.29|about this idea of localization as
3662.99|5.4|regression so this funny thing called
3665.18|5.31|Yolo you only look once actually tries
3668.39|5.16|to pose the detection problem directly
3670.49|5.91|as a regression problem so the idea is
3673.55|4.59|that we actually are going to take our
3676.4|3.6|input image and we're going to divide it
3678.14|4.11|into some spatial grid they use the
3680.0|4.5|seven by seven and then within each
3682.25|4.14|element of that spatial grid we're going
3684.5|4.23|to make a fixed number of bounding box
3686.39|4.38|predictions they use be equals to I
3688.73|3.99|think in most of their experiments so
3690.77|5.34|then within each grid you're going to
3692.72|5.1|predict maybe to be bounding boxes so
3696.11|4.77|that's four numbers you're also going to
3697.82|4.77|predict a single score for how much you
3700.88|3.18|believe that bounding box and you're
3702.59|4.14|also going to predict a classification
3704.06|4.26|score for each class in your data set so
3706.73|3.54|then you can sort of take this this
3708.32|3.84|detection problem and it ends up being
3710.27|4.26|regression where your input is an image
3712.16|6.12|and your output is this maybe seven by
3714.53|5.34|seven by five B plus C tensor right so
3718.28|3.9|just a regression problem and just train
3719.87|4.02|it end to end with a CNN so that's
3722.18|2.82|pretty cool and then it's it's sort of a
3723.89|2.52|neat approach it's a little bit
3725.0|3.93|different than these region proposal
3726.41|4.32|things that we've seen before of course
3728.93|3.78|sort of a problem with this is that it
3730.73|4.26|there's a upper bound in the number of
3732.71|3.72|outputs that your model can have so that
3734.99|4.14|might be a problem if you're testing
3736.43|6.09|data has many many more ground truth
3739.13|6.54|boxes than your training data so this
3742.52|5.49|this yellow detector actually is really
3745.67|5.07|fast it's actually faster than faster
3748.01|4.68|our CN n which is pretty crazy but
3750.74|4.59|unfortunately it tends to work a little
3752.69|4.23|bit worse so they have this other thing
3755.33|4.1|called fast yellow that I don't want to
3756.92|4.949|talk about but
3759.43|5.56|right but just so these are number these
3761.869|5.101|are mean ap numbers on the tasks on one
3764.99|4.32|of the Pascal data sets that we saw so
3766.97|4.59|you can see Yolo actually gets 64 that's
3769.31|3.96|pretty good and runs at 45 frames per
3771.56|3.57|second so that this is obviously on a
3773.27|4.67|powerful GPU but still that's that's
3775.13|4.8|pretty much real-time that's amazing
3777.94|5.29|there's also that I don't want to talk
3779.93|4.98|about that right so then there's these
3783.23|4.05|different versions of fast and faster
3784.91|4.89|are cnn's you can see that these
3787.28|4.14|actually pretty much all beat Yolo in
3789.8|4.26|terms of performance but are quite a bit
3791.42|4.29|slower yeah so that's that's actually
3794.06|5.88|kind of a neat twist on the detection
3795.71|5.58|problem yeah so actually all these all
3799.94|2.82|these different detection metric all
3801.29|3.12|these different detection models that we
3802.76|3.99|talked about today they all pretty much
3804.41|3.57|have code up there released you should
3806.75|3.45|maybe consider using them for your
3807.98|4.41|projects probably don't use our CNN it's
3810.2|5.25|too slow fast are seen on is pretty good
3812.39|5.04|but requires MATLAB faster our CNN
3815.45|3.93|there's actually a version of faster our
3817.43|4.14|CNN that doesn't require MATLAB is just
3819.38|4.14|Python and Cafe I haven't personally
3821.57|3.75|used it but it's something you might
3823.52|3.15|want to try to use for your projects I'm
3825.32|4.26|not sure how difficult it is to get
3826.67|4.59|running and Yolo as actually I think may
3829.58|3.69|be a good choice for some of you for
3831.26|3.45|projects because it's so fast that it
3833.27|3.51|might be easier to work with if you have
3834.71|5.85|not these really big powerful GPUs and
3836.78|5.19|they actually have code up as well yeah
3840.56|2.58|so that's actually I got through things
3841.97|8.37|a little bit faster than I expected so
3843.14|10.04|is there any questions on detection nope
3850.34|2.84|Pro yeah question
3858.11|4.48|yeah so in terms of like model size it's
3861.06|4.08|pretty much it's about the same as a
3862.59|3.27|classification model because when you're
3865.14|2.55|running on bigger
3865.86|3.09|especially for faster are CNN right
3867.69|3.06|because you're convolutions you don't
3868.95|3.27|really introduce any more parameters the
3870.75|3.6|fully connected layers are not really
3872.22|3.6|any more parameters you have a couple
3874.35|3.24|extra parameters for the region proposal
3875.82|3.0|network but it's basically the same
3877.59|7.5|number of parameters as a classification
3878.82|8.81|model alright I guess I guess we're done
3885.09|2.54|a little early today