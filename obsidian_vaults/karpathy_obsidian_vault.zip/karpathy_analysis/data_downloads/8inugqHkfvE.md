start_time|end_time|text
1.0|3.759|and we're recording as well okay great
2.52|3.6|just to remind you again hello uh we're
4.759|3.281|recording the classes so if you're
6.12|3.92|uncomfortable speaking in in the camera
8.04|6.04|you're not in the picture but your voice
10.04|6.36|might be uh on the on the uh recording
14.08|4.72|okay great uh as you can see also the
16.4|3.879|screen is uh wider than it should be and
18.8|4.12|I'm not sure how to fix it so we'll have
20.279|4.201|to live with it luckily your visual
22.92|4.24|cortex is very good it's very invariant
24.48|3.639|to stretching so this is not a problem
27.16|2.32|okay so we'll start out with some
28.119|3.0|administrative things before we dive
29.48|3.88|into the class
31.119|4.76|um the first assignment will come out
33.36|4.12|tonight or early tomorrow uh it is due
35.879|4.16|on January 20 so you have exactly two
37.48|4.04|weeks you will be writing a kous neigh
40.039|2.801|classifier a linear classifier and a
41.52|2.84|small two layer neural network and
42.84|3.199|you'll be writing the entirety of back
44.36|3.56|propagation algorithm for a two two
46.039|5.52|layer neural network we'll cover all
47.92|5.76|that material in the next two weeks and
51.559|3.401|um Warning by the way there are
53.68|2.679|assignments from last year as well and
54.96|3.72|we're changing the assignments so they
56.359|4.72|will please do not complete a 2015
58.68|4.839|assignment that's something to be aware
61.079|5.08|of and uh for your computation by the
63.519|4.201|way we'll be using Python and numpy uh
66.159|4.081|and we'll also be offering terminal.com
67.72|3.719|which is uh which is basically these
70.24|2.8|virtual machines in the cloud that you
71.439|3.401|can use if you don't have a very good
73.04|3.8|laptop and so on I'll go into detail of
74.84|3.959|that in a bit I just like to point out
76.84|3.68|that for the first assignment we assume
78.799|3.201|that you'll be relatively familiar with
80.52|3.84|python and you'll be writing these
82.0|3.96|optimized numpy Expressions where you're
84.36|3.799|manipulating these matrices and vectors
85.96|3.96|in very efficient forms so for example
88.159|3.521|if you're seeing this code and it's
89.92|3.44|doesn't mean anything to you then please
91.68|3.52|have a look at our python NPI tutorial
93.36|3.96|that is up on the website as well it's
95.2|3.64|written by Justin and it's very good and
97.32|2.839|uh so go through that and familiarize
98.84|2.72|yourself with the notation because
100.159|3.681|you'll be seeing you'll be writing a lot
101.56|3.72|of code that looks like this uh where
103.84|3.239|we're doing all these optimized
105.28|4.92|operations so they're fast enough to run
107.079|4.601|on a CPU now in terms of terminal
110.2|3.12|basically what this amounts to is that
111.68|3.039|we'll give you a link to the assignment
113.32|3.439|you'll go to a web page and you'll see
114.719|3.561|something like this this is a virtual
116.759|3.36|machine in the cloud that has been set
118.28|3.32|up with all the dependencies off the
120.119|3.441|assignment they're all installed already
121.6|4.08|all the data is already there and so you
123.56|3.8|click on launch a machine and this will
125.68|3.919|basically bring you to something like
127.36|4.64|this this is running in your browser and
129.599|5.92|this is basically a a thin layer on top
132.0|4.959|of an AWS uh machine a UI layer here and
135.519|2.921|so you have an iPad to notebook and a
136.959|2.761|little terminal and you can go around
138.44|3.439|and this is just like a machine in the
139.72|3.84|cloud and so they have some CPU
141.879|3.64|offerings and they also have some GPU
143.56|3.28|machines that you can use and so on uh
145.519|3.36|you normally have to pay for terminal
146.84|4.36|but we'll be Distributing credits to you
148.879|4.281|so you just uh email us to a specific ta
151.2|3.56|that will decide in a bit you email to a
153.16|3.12|TA and you ask for money we'll send you
154.76|2.64|money and we keep track of how much
156.28|2.92|money we've sent to all the people so
157.4|4.24|you have to be responsible with the
159.2|5.2|funds uh so this is also an option for
161.64|2.76|you to use if you
164.48|5.08|like uh okay any details about this y go
168.239|3.321|a quick question you said that they have
169.56|4.679|GP units does that mean we can write
171.56|4.759|Huda code or is that not acceptable uh
174.239|3.64|you can you can write it if you like
176.319|5.521|it's not required for the assignment but
177.879|5.761|you can probably get that to run yeah
181.84|3.16|okay great so I'm just going to dive
183.64|3.239|into the lecture now today we'll be
185.0|3.4|talking about uh image classification
186.879|3.72|and especially uh we'll start off on
188.4|5.04|linear classifiers so when we talk about
190.599|4.401|image classification um the basic task
193.44|3.96|is that we have some number of fixed
195.0|4.319|categories say a dog cat truck plane or
197.4|3.199|so on we get to decide what these are
199.319|3.84|and then the task really is to take an
200.599|4.2|image which is a giant grid of numbers
203.159|3.041|and we have to transform it to one of
204.799|3.201|these labels we have to bin it into one
206.2|3.08|of the categories this is the image
208.0|2.799|classification problem we'll spend most
209.28|3.239|of our time talking about this one
210.799|3.281|specifically but if you'd like to do any
212.519|3.161|other task in computer vision such as
214.08|3.4|object detection image captioning
215.68|3.559|segmentation or whatever else you'll
217.48|3.52|find that once you know about image
219.239|3.36|classification and how that's done
221.0|2.84|everything else is just a tiny Delta on
222.599|3.241|top of it so you'll be in a great
223.84|3.399|position to do any of the other tasks so
225.84|2.84|it's really good for conceptual
227.239|3.2|understanding and we'll work through
228.68|4.08|that as a specific example uh to
230.439|3.72|simplify things in the beginning now why
232.76|3.24|is this problem hard just to give you an
234.159|4.041|idea the problem is what we refer to as
236.0|4.2|a semantic Gap this image here is a
238.2|3.52|giant grid of numbers the way images are
240.2|4.92|represented in the computer is that this
241.72|5.48|is basically say roughly a 300X 100x 3
245.12|3.319|pixel array so threedimensional array
247.2|3.36|and the three is for the three color
248.439|3.841|channels red green and blue and so when
250.56|3.399|you zoom in on a part of that image it's
252.28|5.32|basically a giant grid of numbers
253.959|5.081|between 0 and 255 uh so that's what we
257.6|2.639|have to work with these numbers indicate
259.04|2.64|the amount of brightness in all the
260.239|4.361|three color channels at every single
261.68|4.28|position in the image and so the reason
264.6|3.12|that image classification is difficult
265.96|3.92|is when you think about what we have to
267.72|4.479|work with these like millions of numbers
269.88|4.28|of that form and having to classify
272.199|3.921|things like cats it quickly becomes
274.16|5.039|apparent the complexity of the task so
276.12|4.48|for example the camera can be rotated
279.199|3.801|around this cat and it can be Zoomed In
280.6|4.159|and Out and rotated shifted the focal
283.0|3.96|properties intrinsics of that camera can
284.759|3.761|be different and think about what
286.96|2.92|happens to the brightness values in this
288.52|2.88|grid as you actually do all these
289.88|2.92|Transformations with a camera they'll
291.4|3.239|completely shift all the patterns are
292.8|3.839|changing and we have to be robust to all
294.639|3.641|of this there's also many other
296.639|3.84|challenges for example challenges of
298.28|5.44|Illumination here we have have a long
300.479|4.681|cat uh long cat we actually have two of
303.72|4.24|them but you almost even can't see the
305.16|4.599|other one um and so one cat is basically
307.96|4.32|illuminated quite a bit and the other is
309.759|3.921|not but you can still recognize two cats
312.28|3.16|and so think about again the brightness
313.68|3.16|valys on the level of the grid and what
315.44|3.36|happens to them as you change all the
316.84|3.16|different lightings and all the possible
318.8|2.92|lighting schemes that we can have in the
320.0|5.039|world we have to be robust to all of
321.72|4.4|that there's issues of um deformation
325.039|4.681|many
326.12|5.199|classes lots of uh strange uh
329.72|4.039|Arrangements of all these objects we'd
331.319|4.641|like to recognize so cats coming in very
333.759|3.44|different uh poses by the way the slides
335.96|2.48|when I create them they're quite dry
337.199|3.921|there's a lot of math and so on so this
338.44|4.199|is the only time I get to have fun so uh
341.12|3.96|that's why I just pile everything with
342.639|3.601|cat pictures uh so we have to be robust
345.08|2.44|to all of these deformations you can
346.24|2.6|still recognize that there's a cat in
347.52|3.0|all of these images despite its
348.84|3.88|Arrangement there's problems of
350.52|3.48|occlusion so sometimes we might not see
352.72|3.4|the full object but you still recognize
354.0|3.8|that that's a cat behind a curtain
356.12|3.96|that's a cat behind a water bottle and
357.8|3.36|there's a also a cat there inside a
360.08|4.839|couch even though you're seeing just
361.16|5.759|tiny pieces pieces of this uh class
364.919|4.84|basically there's problems of background
366.919|5.0|clutter so things can blend into the
369.759|3.481|environment we have to be robust to that
371.919|3.4|and there's also what we refer to as
373.24|4.48|intraclass variation so cat actually
375.319|4.121|there's a huge amount of cats uh just
377.72|2.879|species uh and so they can look
379.44|3.12|different ways we have to be robust to
380.599|3.641|all of that so I just like you to
382.56|2.96|appreciate the complexity of the task
384.24|3.0|when you consider any one of these
385.52|3.519|independently is difficult but when you
387.24|3.84|consider the full cross product of all
389.039|4.321|these different things and the fact that
391.08|3.88|our algorithms have to work across all
393.36|3.679|of that it's actually quite amazing that
394.96|3.4|anything works at all uh in fact not
397.039|3.081|only does it work but it works really
398.36|3.239|really well almost at human accuracy we
400.12|2.919|can recognize thousands of categories
401.599|3.481|like this and we can do that in a few
403.039|3.041|dozen milliseconds uh with the current
405.08|3.92|technology and so that's what you'll
406.08|4.16|learn about in this class um so what
409.0|4.12|does an image classifier look like
410.24|4.64|basically we're taking this 3D array of
413.12|3.479|pixel values we'd like to produce a
414.88|3.84|class label and what I'd like you to
416.599|4.16|notice is that there's no obvious way of
418.72|3.64|actually encoding any of this of these
420.759|2.72|classifiers right there's no simple
422.36|2.72|algorithm like say you're taking an
423.479|3.641|algorithm class in your early computer
425.08|3.48|science curriculum you're writing bubble
427.12|3.799|swort or you're writing something else
428.56|3.44|to do any particular task you can Intuit
430.919|2.521|all the possible steps and you can
432.0|3.44|enumerate them and list them and play
433.44|3.92|with it and analyze it but here there's
435.44|4.0|no algorithm for detecting a cat under
437.36|3.04|all these variations or it's extremely
439.44|2.08|difficult to think about how you'd
440.4|2.96|actually write that up what is the
441.52|4.32|sequence of operations you would do or
443.36|3.48|an arbitrary image to detect a cat
445.84|2.32|that's not to say that people haven't
446.84|3.0|tried especially in the early days of
448.16|3.24|computer vision uh there were these
449.84|3.759|explicit approaches as I'd like to call
451.4|5.32|them where you think about okay a cat
453.599|4.761|say is a we' like to maybe look for um
456.72|3.44|little earpieces so what we'll do is
458.36|3.64|we'll detect all the edges we'll Trace
460.16|4.08|out edges we'll classify the different
462.0|4.199|shapes of edges and their Junctions
464.24|3.359|we'll create you know libraries of these
466.199|3.12|and we'll try to find their arrangements
467.599|3.521|and if we ever see anything earlike then
469.319|3.201|we'll detect a cat or if we see any
471.12|3.639|particular texture of some particular
472.52|3.72|frequencies we'll detect a cat and so
474.759|3.56|you can come up with some
476.24|3.239|rules but the problem is that once I
478.319|3.361|tell you okay I'd like to actually
479.479|3.321|recognize a boat now or a person then
481.68|2.16|you have to go back to the drawing board
482.8|2.799|and you have to be like okay what makes
483.84|3.639|a boat exactly what's the arrangement of
485.599|4.641|edges right it's completely unscalable
487.479|3.72|approach to the to classification and so
490.24|2.12|the approach we're adopting in this
491.199|4.68|class and the approach that works much
492.36|5.08|better is uh the data driven approach
495.879|3.641|that we like in the framework of machine
497.44|3.52|learning and uh just to point out that
499.52|3.239|in these days actually in the early days
500.96|3.639|they did not have the luxury of using
502.759|3.041|data because at this point in time
504.599|2.88|you're taking you know great scale
505.8|2.679|images of very low resolution you have
507.479|2.481|five images and you're trying to
508.479|3.241|recognize things it's obvious not going
509.96|3.4|to work but with the availability of
511.72|4.36|Internet huge amount of data I can
513.36|4.76|search for example for cat on uh Google
516.08|3.319|and I get lots of cats everywhere and we
518.12|4.2|know that these are cats based on the
519.399|4.401|surrounding text in the web pages and so
522.32|3.0|that gives us lots of data so the way
523.8|3.4|that this now looks like is that we have
525.32|4.48|a training phase where you give me lots
527.2|4.04|of training examples of cats and you
529.8|3.32|tell me that they're cats and you give
531.24|4.36|me lots of examples of any type of other
533.12|4.959|category you're interested in I do I go
535.6|4.84|away and I train a Model A model is a
538.079|4.561|class and I can then use that model to
540.44|3.959|actually classify new test data so when
542.64|3.68|I'm given a new image I can look at my
544.399|3.321|training data and I can do something
546.32|4.759|with this based on just a pattern
547.72|5.64|matching um and statistics and so on so
551.079|3.88|as a simple uh first example we'll work
553.36|3.56|with in this framework consider the
554.959|3.361|nearest neighbor classifier the way
556.92|2.8|nearest neighbor classifier works is
558.32|3.079|that effectively we're given this giant
559.72|3.119|training set what we'll do at training
561.399|2.801|time is we'll just remember all of the
562.839|3.401|training data so I have all the train
564.2|4.079|data I just put it here and I remember
566.24|4.4|it now when you give me a test image
568.279|4.161|what we'll do is we'll compare that test
570.64|3.439|image to every single one of the images
572.44|4.36|we saw in the training data and we'll
574.079|5.361|just transfer the label over so I'll
576.8|4.24|just look through all the images um
579.44|2.76|we'll work with specific case as I go
581.04|2.52|through this I'd like to be as concrete
582.2|2.72|as possible so we'll work with a
583.56|4.24|specific case of something called cart
584.92|5.32|10 data set the C4 10 data set has 10
587.8|4.4|labels these are the labels there are
590.24|3.68|50,000 training images that you have
592.2|4.28|access to and then there's a test set of
593.92|3.84|10 10,000 images where we're going to
596.48|3.2|evaluate how well the classifier is
597.76|3.28|working and these images are quite tiny
599.68|4.76|they're just little toy data set of
601.04|4.799|32x32 little thumbnail images so the way
604.44|2.92|nearest neighbor classifier would work
605.839|3.881|is we take all this training data that's
607.36|4.76|given to us 50,000 images now at test
609.72|3.96|time suppose we have these 10 different
612.12|3.24|examples here these are test images
613.68|3.52|along the First Column here what we'll
615.36|4.039|do is we'll look up nearest Neighbors in
617.2|3.8|the training set of things that are most
619.399|3.641|similar to every one of those images
621.0|5.839|independently so there you see a ranked
623.04|5.44|list of images that are most similar to
626.839|3.761|uh in the training data to any one of
628.48|3.72|those 10 uh to every one of those test
630.6|3.4|images over there so in the first row we
632.2|3.48|see that there's a truck I think as a
634.0|3.88|test image and there's quite a few
635.68|3.88|images that look similar to it uh we'll
637.88|3.04|see how exactly we Define similarity in
639.56|3.88|a bit but you can see that the first
640.92|4.12|Retreat result is in fact a horse uh not
643.44|3.32|a truck and that's because of just the
645.04|3.64|arrangement of the blue sky that was
646.76|4.6|throwing that off so you can see that
648.68|4.04|this will not probably work very well
651.36|2.88|now how do we Define the distance metric
652.72|3.119|how do we actually do the comparison
654.24|4.279|there's several ways one of the simplest
655.839|4.401|ways might be uh a Manhattan distance so
658.519|4.201|an L1 distance or Manhattan distance
660.24|3.8|I'll use the two terms interchangeably
662.72|2.919|simply what it does is you have a test
664.04|3.12|image you're interested in classifying
665.639|3.801|and consider one single training image
667.16|3.56|that we want to compare this image too
669.44|3.56|basically what we'll do is we'll
670.72|3.96|elementwise compare all the pixel values
673.0|3.6|so we'll form the absolute value
674.68|3.399|differences and then we just add all of
676.6|3.359|it up so we're just looking at every
678.079|3.641|single Pixel position we're subtracting
679.959|3.081|it off uh and seeing what the
681.72|3.44|differences are at every single spatial
683.04|4.44|position adding it all up and that's our
685.16|5.6|similarity so these two images are
687.48|5.799|456 different okay so we'll get a zero
690.76|4.199|if we have identical images here just to
693.279|2.881|show you code specifically uh the way
694.959|2.88|this would look like this is a full
696.16|3.359|implementation of a nearest neighbor
697.839|4.24|classifier in numpy and
699.519|3.921|python um where I filled in the actual
702.079|3.601|body of the two methods that I talked
703.44|3.639|about and basically what we do here at
705.68|4.12|training time is we're given this data
707.079|4.601|set X the images and Y which usually
709.8|3.88|denote the labels so we're giving images
711.68|3.92|and labels all we do is just just
713.68|4.2|assigned to the class instance methods
715.6|4.88|so we just remember the data nothing is
717.88|4.199|being done at predict time though uh
720.48|4.56|what we're doing here is uh we're
722.079|4.401|getting new um test set of images X and
725.04|2.599|I'm not going to go through full details
726.48|2.96|but you can see that there's a for Loop
727.639|3.361|over every single test image
729.44|4.32|independently we're getting the
731.0|4.399|distances to every single training image
733.76|4.68|and notice that that's only a single
735.399|4.641|line of vectorized python code so in a
738.44|3.28|single line of code we're comparing that
740.04|2.68|test image to every single training
741.72|3.28|image in the database and we're
742.72|5.119|Computing this distance in a previous
745.0|4.68|slide in a single line okay so that's
747.839|3.0|vectorized code we didn't have to expand
749.68|3.44|out all those four Loops that are
750.839|5.44|involved in processing this distance and
753.12|5.159|then we compute the instance that is
756.279|3.36|closest so we're getting the Min index
758.279|4.0|so that's the index of the training
759.639|4.32|example that is has the lowest distance
762.279|5.68|and then we're just predicting for this
763.959|6.041|image the label of whatever was nearest
767.959|4.0|okay so here's a question for you in
770.0|4.519|terms of the nearest neighbor classifier
771.959|4.68|How does its speed depend on the
774.519|3.601|training data size what happens is I
776.639|4.281|scale up the training
778.12|4.519|data
780.92|4.08|it's slower
782.639|4.721|okay yes it's actually it's in fact
785.0|3.68|linearly slower right because if I have
787.36|2.4|I just have to I have to compare to
788.68|4.2|every single training example
789.76|4.639|independently so it's a linear slowdown
792.88|2.8|and you'll notice actually as you go as
794.399|2.8|we go through the class is that this is
795.68|2.8|actually backwards because what we
797.199|2.841|really care about in most practical
798.48|3.56|applications is we care about the test
800.04|3.64|time performance of these classifiers
802.04|3.84|that means that we want this classifier
803.68|3.599|to be very efficient at test time and so
805.88|2.56|there's this tradeoff between really how
807.279|2.68|much compute do we put in the train
808.44|3.88|method and how much Compu do we put in a
809.959|4.161|test method a nearest neighbor is
812.32|3.759|instant at train but then it's expensive
814.12|3.48|at test and as we'll see soon comets
816.079|3.241|actually flip this completely the other
817.6|3.479|way around we'll see that we do a huge
819.32|3.44|amount of compute at train time we'll be
821.079|2.921|training a convolutional neural network
822.76|2.84|but the test Time Performance will be
824.0|4.12|super efficient in fact it will be
825.6|4.12|constant amount of compute uh for every
828.12|3.639|single test image we do constant amount
829.72|4.359|of computation no matter if you have a
831.759|4.401|million billion or trillion training
834.079|4.361|images i' I'd like to have a trillion
836.16|4.039|tril trillion training images no matter
838.44|3.68|how large your training data set is we
840.199|3.801|do a constant compute to classify any
842.12|4.2|single testing example so that's very
844.0|5.199|nice uh practically speaking now I'll
846.32|4.04|just like to point out that uh there are
849.199|2.681|ways of speeding up nearest neighbor
850.36|3.279|classifiers there's these approximate
851.88|3.36|nearest neighbor methods flan is an
853.639|4.241|example library that people use often in
855.24|3.88|practice that allows you to speed up uh
857.88|5.199|this process of nearest neighbor
859.12|6.399|matching but uh that's just a side note
863.079|3.961|okay so let's go back to the design of
865.519|3.961|the nearest neb classifier we saw that
867.04|3.799|we've defined this uh distance and I've
869.48|3.56|arbitrarily chosen to show you the
870.839|3.721|Manhattan distance which compares the
873.04|2.68|difference of the absolute values
874.56|3.0|there's in fact many ways you can
875.72|3.4|formulate a distance metric and so
877.56|3.68|there's many different choices of
879.12|3.639|exactly how we do this comparison
881.24|2.88|another simp another choice that people
882.759|3.64|like to use in practice is what we call
884.12|3.959|the ukian or L2 distance which instead
886.399|3.721|sums up the differences in the sums of
888.079|5.44|squares of these differences between
890.12|6.32|images and so this
893.519|4.521|Choice what happened there did someone
896.44|4.6|push a button over there in the
898.04|3.0|back
902.92|4.4|okay thank you so this choice of what
905.839|3.281|how exactly we compute a distance it's a
907.32|3.199|discrete choice that we have control
909.12|2.92|over that's something we call the
910.519|3.56|hyperparameter it's not really obvious
912.04|3.68|how you set it it's a hyperparameter we
914.079|4.281|have to decide later on exactly how to
915.72|3.799|set this somehow another sort of hyper
918.36|2.919|parameter that I'll talk about in
919.519|3.041|context of nearest neighbor classifier
921.279|2.881|is when we generalize nearest neighbor
922.56|3.56|to what we call a canor neighbor
924.16|3.32|classifier so in a canor neighbor
926.12|3.199|classifier instead of retrieving for
927.48|3.599|every test image the single nearest
929.319|4.32|Training example will in fact retrieve
931.079|4.32|several nearest examples and we'll have
933.639|4.12|them do a majority vote over the classes
935.399|4.0|to actually classify every test instance
937.759|3.52|so say a five nearest neighbor we would
939.399|3.761|be retrieving the five most similar
941.279|4.04|images in the training data and doing a
943.16|3.44|majority vote of the labels here's a
945.319|3.161|simple two-dimensional data set to
946.6|4.599|illustrate the point so here we have a
948.48|4.839|three class data set in 2D and here I'm
951.199|4.161|drawing what we call decision regions of
953.319|3.721|this nearest neighbor classifier here
955.36|3.039|what this refers to is we're showing the
957.04|4.68|training data over there and we're
958.399|5.041|coloring the entire 2D plane by what uh
961.72|3.16|class this nearest neighbor classifier
963.44|2.8|would assign at every single point
964.88|2.92|suppose you suppose you had a test
966.24|2.64|example somewhere here then this is just
967.8|3.24|saying that that this would have been
968.88|3.84|classified as blue class based on the
971.04|3.599|nearest neighbor you can for example
972.72|3.96|note that here is a point that is a
974.639|3.281|Green Point inside the blue cluster and
976.68|2.599|it has its own little region of
977.92|3.76|influence where it would have classified
979.279|4.321|a lot of test points around it as green
981.68|2.959|because if any point fell there then
983.6|3.039|that Green Point would have been the
984.639|3.76|nearest neighbor now when you move to
986.639|3.041|higher numbers for K such as five
988.399|2.721|nearest neighbor class classifier what
989.68|4.56|you find is that the boundaries start to
991.12|5.56|smooth out it's kind of this uh nice uh
994.24|5.2|effect where even if there's this one
996.68|4.48|point um kind of randomly as a noise and
999.44|3.0|outlier in the blue cluster it's
1001.16|3.08|actually not influencing the predictions
1002.44|3.56|too much because we're always retrieving
1004.24|5.279|five nearest neighbors and so they get
1006.0|5.0|to overwhelm the green point so uh in
1009.519|3.361|practice you'll find that usually kers
1011.0|4.36|neighbor classifiers offer better uh
1012.88|4.879|better performance at test time now but
1015.36|4.24|again the choice of K is again a hyper
1017.759|4.361|parameter right so I'll come back to
1019.6|3.88|this in a bit just to show you an
1022.12|2.839|example of what this would look like
1023.48|2.68|here I'm retrieving 10 most similar
1024.959|2.6|examples they're ranked by their
1026.16|2.759|distance and I would actually do a
1027.559|3.321|majority vote over these training
1028.919|3.681|examples here to classify every Test
1030.88|3.319|example
1032.6|4.359|here
1034.199|5.84|okay so let's do a bit of uh questions
1036.959|5.401|here just for fun uh consider what is
1040.039|4.4|the accuracy of the neural classifier on
1042.36|4.12|the training data when we're using ukian
1044.439|5.24|distance so suppose our test set is
1046.48|4.6|exactly the training data and we're
1049.679|2.88|trying to find the accuracy in other
1051.08|7.44|words how many how often would we get
1052.559|5.961|the correct answer 100% 100% good
1060.24|5.24|why okay among the murmur um yeah that's
1063.0|4.32|correct so we're always find a training
1065.48|3.4|example exactly on top of that test
1067.32|4.44|which has zero distance and then it St
1068.88|6.28|will be transferred over good uh What if
1071.76|3.4|we're using the Manhattan distance
1077.84|3.0|instead
1081.64|3.039|so Manhattan distance doesn't use sum of
1083.24|4.16|squares it uses sum of absolute values
1084.679|3.961|of differences would it be the same it
1087.4|3.2|would it's just a trick question it
1088.64|5.36|would be
1090.6|5.959|so okay good uh so we're we're keeping
1094.0|3.799|paying attention here uh okay what is
1096.559|2.921|the accuracy of the K nearest neighbor
1097.799|5.601|classifier in a training data then it
1099.48|6.64|say k was 5 is it 100% no not
1103.4|4.12|necessarily right good because basically
1106.12|4.039|the points around you could overwhelm
1107.52|4.88|you even if you're uh best example is
1110.159|4.481|actually of the of a different class
1112.4|4.48|okay good so we've discussed two choices
1114.64|3.6|of different uh here hyper parameters we
1116.88|2.799|have the distance metric it's a hyper
1118.24|4.96|parameter and this K we're not sure how
1119.679|5.36|to set it should be 1 2 3 10 and so on
1123.2|3.56|so we're not exactly sure how to set
1125.039|3.12|these in fact they're problem dependent
1126.76|2.96|you'll find that you can't find a
1128.159|3.481|consistently best choice for these hyper
1129.72|3.56|parameters in some applications some
1131.64|3.76|case might look might work better than
1133.28|4.56|other applications so we're not really
1135.4|4.08|sure how to set this so here's an idea
1137.84|2.92|uh we have to basically try out lots of
1139.48|3.92|different type parameters so what I'm
1140.76|4.32|going to do is I'm going to take my um
1143.4|2.639|train data and then I'm just going to
1145.08|2.92|try out lots of different type
1146.039|5.64|parameters so I have my test data and I
1148.0|5.24|try out k equal 1 2 3 4 5 6 20 100 I try
1151.679|2.841|out all the different distance metrics
1153.24|3.88|and whatever works best that's what I'll
1154.52|6.0|take so that will work very well right
1157.12|5.6|no it won't work very well why is it not
1160.52|4.519|going to why is this not a good idea uh
1162.72|7.52|because you will fail to generalize on
1165.039|9.401|on unseen data okay so basically correct
1170.24|6.84|so basically um yes so test data is your
1174.44|5.16|proxy for your generalization of your
1177.08|3.959|algorithm you should not touch the test
1179.6|3.6|data in fact you should forget that you
1181.039|3.801|ever have test data so when once you're
1183.2|3.4|given your data set always set aside the
1184.84|2.8|test data pretend you don't have it
1186.6|2.88|that's telling you how well your
1187.64|3.159|algorithm is generalizing to unseen data
1189.48|2.84|points and this is important because
1190.799|2.641|you're trying to develop your algorithm
1192.32|2.92|and then you're hoping to eventually
1193.44|2.96|deploy it in in some setting and you'd
1195.24|2.88|like to have an understanding of exactly
1196.4|2.96|how well do I expect this to work in
1198.12|3.32|practice
1199.36|3.439|right and so uh you'll see that for
1201.44|2.52|example sometimes you can perform very
1202.799|2.681|very well on train data but not
1203.96|3.12|generalize very well to test data when
1205.48|3.199|you're overfitting and so on a lot of
1207.08|3.32|this by the way 229 is a requirement for
1208.679|3.041|this class so you should be quite
1210.4|3.759|familiar with this this is to most
1211.72|4.8|extent a um this is kind of more more of
1214.159|4.921|r view for you but basically this test
1216.52|4.32|data is use it very sparingly forget
1219.08|3.36|that you have it instead what we do is
1220.84|4.8|we separate our training data into what
1222.44|6.599|we call folds so uh we separate say we
1225.64|5.84|use a fivefold validation so we use % of
1229.039|4.321|the training data as a imagine test set
1231.48|4.16|data and then we only train on part of
1233.36|4.04|it and we test on we test out the
1235.64|4.32|choices of hyp parameters on this
1237.4|3.84|validation set so I'm going to train on
1239.96|2.28|my fourfolds and try out all the
1241.24|2.4|different case and all the different
1242.24|2.439|zance metrics and whatever else if
1243.64|2.88|you're using approximate nearest
1244.679|3.401|neighbor you have many other choices you
1246.52|3.039|try it out see what works best on that
1248.08|2.88|validation data if you're feeling
1249.559|3.201|uncomfortable because you have very few
1250.96|3.48|training data points people also
1252.76|3.88|sometimes use cross validation where you
1254.44|4.32|actually iterate the choice of your test
1256.64|4.88|or validation fold across these choice
1258.76|4.799|es so I'll first use four one to four
1261.52|3.24|for my training and try out on five and
1263.559|2.801|then I cycle the choice of the
1264.76|3.88|validation fold across all the five
1266.36|3.96|choices and I look at what works best
1268.64|3.96|across all the possible choices of my
1270.32|3.599|test fold and then I just take whatever
1272.6|3.24|works best across all the possible
1273.919|4.401|scenarios okay that's referred to as a
1275.84|3.68|cross validation set as cross validation
1278.32|2.8|so in practice the way this would look
1279.52|3.88|like say we're cross validating for k
1281.12|4.439|for a nearest neighbor classifier is we
1283.4|5.6|are trying out different values of K and
1285.559|5.681|this is our performance um across five
1289.0|4.159|choices of a fold so you can see that
1291.24|3.72|for every single K we have five data
1293.159|3.681|points there and then this is the
1294.96|3.8|accuracy so high is good and I'm
1296.84|3.719|plotting a line through the mean and I'm
1298.76|3.519|also showing the bars for the standard
1300.559|4.0|deviations so what we see here is that
1302.279|4.88|the performance goes up on the across
1304.559|4.321|these validation folds um as you go up
1307.159|3.241|but at some point it starts to Decay so
1308.88|4.24|for this particular data set it seems
1310.4|4.639|that k equal to 7 is the best choice so
1313.12|3.88|that's what I'll use I'll do this for
1315.039|3.64|all my hyper parameters also for thism
1317.0|2.72|metric and so on I do my cross
1318.679|3.48|validation I find the best high
1319.72|4.68|parameters I set them I fix them then I
1322.159|3.88|evaluate a single time on the test set
1324.4|4.639|and whatever number I get that's what I
1326.039|4.921|report as a accuracy of a K classifier
1329.039|3.361|on this data set that's what goes into a
1330.96|3.4|paper that's what goes into a final
1332.4|4.159|report and so on that's the final
1334.36|5.679|generalization result of what you've
1336.559|7.161|done um okay any questions about this
1340.039|5.88|yep so the reason that happens with K is
1343.72|3.319|that is that because large K gives you
1345.919|4.441|high
1347.039|4.601|bias um
1350.36|2.319|I would be careful with that terminology
1351.64|3.639|but
1352.679|4.48|basically it's about the statistics of
1355.279|5.121|the distribution of these data points in
1357.159|5.241|your label in your data space and so
1360.4|4.92|sometimes it's it's basically hard to
1362.4|5.08|say like you get where is this
1365.32|4.88|picture you see roughly what's happening
1367.48|4.48|is you get more clunkiness in more case
1370.2|3.12|and it just depends on how clunky your
1371.96|4.4|data set is that's really what it comes
1373.32|6.2|down to is uh how how Blobby is it or
1376.36|5.0|how specific is it
1379.52|3.08|I know that's a very handwavy answer but
1381.36|3.08|that's roughly what what that comes down
1382.6|3.4|to uh so different data sets will have
1384.44|4.2|different
1386.0|6.12|clunkiness Y how do you deal with skewed
1388.64|5.44|data sets skewed data sets uh so what is
1392.12|3.919|that a lot more of one class than other
1394.08|3.92|class uh so that's a technical question
1396.039|3.281|that I maybe want to get into right now
1398.0|2.4|but we will address that later in the
1399.32|4.359|class
1400.4|6.0|probably oh yeah go ahead shoulding
1403.679|3.761|hyper parameters uh data specifically
1406.4|4.0|consider
1407.44|4.64|aching uh no not at all because your
1410.4|4.24|hyper parameters are just choices you're
1412.08|4.32|not sure how to set them and different
1414.64|2.84|uh different data sets will require
1416.4|2.96|different choices and you need to see
1417.48|3.36|what works best in fact when you try out
1419.36|2.6|different algorithms because you're not
1420.84|3.199|sure what's going to work best on your
1421.96|4.079|data the choice of your algorithm is
1424.039|3.721|also kind of like a hyper parameter so
1426.039|3.0|you're just not sure what works you're
1427.76|3.72|not
1429.039|4.681|different um approaches will give you
1431.48|3.679|different generalization boundaries they
1433.72|3.439|look different and some data sets have
1435.159|3.601|different structure than others so some
1437.159|4.12|things work better than others and you
1438.76|5.64|have to just train try it
1441.279|5.201|out okay cool I just like to point out
1444.4|3.519|that K neighbors is no one basically
1446.48|3.64|uses this so I'm just going through this
1447.919|3.76|just to get you uh used to this approach
1450.12|4.76|of really how this works with training
1451.679|4.721|test splits and so on um the reason this
1454.88|3.96|is never used is because first of all
1456.4|3.96|it's very inefficient but second of all
1458.84|4.48|distance metrics on images which are
1460.36|6.0|very high dimensional objects they act
1463.32|4.8|in very unnatural unintuitive ways so
1466.36|3.799|here what I've done is we're taking an
1468.12|4.279|or image and I change it in three
1470.159|4.281|different ways but all these three
1472.399|4.921|different images here have actually the
1474.44|5.28|exact same distance to this one in an L2
1477.32|4.76|ukian sense and so just think about it
1479.72|4.959|this one here is slightly shifted to the
1482.08|3.88|left it's basically cropped slightly and
1484.679|2.6|its distances here are completely
1485.96|2.56|different because these pixels are not
1487.279|2.801|matching up exactly and it's all
1488.52|3.399|introducing all these errors and you're
1490.08|3.68|getting a distance this one is slightly
1491.919|3.721|darkened so you get a small Delta across
1493.76|3.44|all spatial locations and this one is
1495.64|3.72|untouched so you get zero distance
1497.2|4.12|errors across everywhere except for in
1499.36|3.919|those positions over there and that is
1501.32|3.88|taking out critical pieces of the image
1503.279|3.28|and it doesn't the nearest the nearest
1505.2|2.479|nebor classifier would not be able to
1506.559|2.761|really tell a difference between these
1507.679|3.12|settings because it's based on these
1509.32|4.04|distances that don't really work very
1510.799|4.281|well in this case so uh very unintuitive
1513.36|3.24|things happen when you try to throw
1515.08|3.04|distances on very high dimensional
1516.6|6.16|objects that's partly why we don't use
1518.12|5.919|this okay so in summary so far uh we're
1522.76|3.159|looking at image classification as a
1524.039|3.64|specific case and we'll go into
1525.919|3.321|different settings later in the class
1527.679|2.961|I've introduced enable classifier and
1529.24|3.12|the idea of having different splits of
1530.64|4.039|your data and we have these
1532.36|3.76|hyperparameters that we need to pick uh
1534.679|3.0|and we use cross validation for this
1536.12|3.039|usually most of the time people don't
1537.679|3.281|actually use entire cross validation
1539.159|3.201|they just have a single validation set
1540.96|2.64|and they try out on the validation set
1542.36|4.319|whatever works best in terms of the
1543.6|4.24|hyper parameters and once youve get the
1546.679|4.801|best high parameters you evalate the
1547.84|5.079|single time on a test set okay so I'm
1551.48|4.16|going to go into linear classification
1552.919|6.601|bit any questions at this point
1555.64|5.519|otherwise great okay
1559.52|5.159|so we're going to look at linear
1561.159|4.921|classification um this is a point where
1564.679|2.801|we are starting to work towards
1566.08|2.839|convolutional Lal networks so there will
1567.48|3.36|be a series of lectures we'll start with
1568.919|3.321|linear classification that will build up
1570.84|2.439|to an entire convolutional network
1572.24|3.159|analyzing an
1573.279|3.76|image now I just like to say that we've
1575.399|3.841|motivated the class yesterday from a
1577.039|3.801|task specific uh view so this class is
1579.24|4.88|computer vision class we're interested
1580.84|4.52|in you know uh giving machines site
1584.12|3.4|another way to motivate this class would
1585.36|5.16|be from a modelbased point of view in a
1587.52|4.08|sense that we're um giving you guys uh
1590.52|2.6|we're teaching you guys about deep
1591.6|3.199|learning and neural networks these are
1593.12|3.4|wonderful algorithms that you can apply
1594.799|3.641|to many different data domains not just
1596.52|4.24|Vision so in particular over the last
1598.44|4.16|few years we saw that neural networks
1600.76|3.639|can not only see that's what you'll
1602.6|3.4|learn a lot about in this class but they
1604.399|3.721|can also hear they're used quite a bit
1606.0|3.32|in uh speech recognition now so when you
1608.12|3.439|talk to your phone that's now a deep
1609.32|4.64|neural network they can also uh do
1611.559|5.641|machine translation so here you're
1613.96|5.12|feeding um a neural network a set of
1617.2|3.479|words one by one in English and the
1619.08|3.199|neural network produces the translation
1620.679|3.681|in French or whatever else target
1622.279|3.961|language you have they can also perform
1624.36|4.28|control so we've seen neural network
1626.24|4.559|applications in um manipul in robots
1628.64|3.48|manipulation in playing of Atari games
1630.799|3.521|so these neural networks learn how to
1632.12|4.32|play Atari games uh just by seeing the
1634.32|3.76|raw pixels of the screen and we've seen
1636.44|5.32|neur networks be very successful in a
1638.08|6.0|variety of domains and even more than uh
1641.76|4.159|I put here and we're uncertain exactly
1644.08|4.12|where this will take us and then I'd
1645.919|3.801|like to also say that we're exploring
1648.2|2.839|ways for neural networks to think but
1649.72|3.72|this is very handwavy it's just a
1651.039|4.0|wishful thinking but uh there's some
1653.44|3.68|hints that maybe uh they can do that as
1655.039|3.961|well now neural networks are very nice
1657.12|3.399|because they're just a fun modular
1659.0|3.039|things to play with when I think about
1660.519|3.64|working with neural networks I kind of
1662.039|4.0|this picture comes to mind for me here
1664.159|3.921|we have a neural networks practitioner
1666.039|3.64|and she's building what looks to be a
1668.08|3.959|roughly 10 layer convolutional neural
1669.679|4.681|network at this point and so these are
1672.039|3.52|very fun really the best way to think
1674.36|2.76|about playing with neural networks is
1675.559|3.6|like Lego blocks you'll see that we're
1677.12|3.36|building these little function pieces
1679.159|3.081|these Lego blocks that we can stack
1680.48|3.88|together to create entire architectures
1682.24|3.84|and they very easily talk to each other
1684.36|3.36|and so we can just create these modules
1686.08|5.199|and stack them together and play with
1687.72|5.64|this very easily um one work that I
1691.279|3.561|think exemplifies this is uh my own work
1693.36|4.559|on image captioning from roughly a year
1694.84|4.679|ago uh so here the task was you take an
1697.919|3.281|image and you're trying to get the
1699.519|3.321|neural network to produce a sentence
1701.2|3.079|description of the image so for example
1702.84|3.04|in the top left these are test set
1704.279|3.12|results the neural network would say
1705.88|3.2|that this is a man in black shirt is
1707.399|3.361|playing a guitar or a constructure
1709.08|3.599|worker in Orange safety West is working
1710.76|4.36|on the road and so on so the neural
1712.679|4.72|network can look at the image and create
1715.12|3.679|this description of every single image
1717.399|3.64|and when you go to the details of this
1718.799|4.081|model the way this works is we're taking
1721.039|4.561|a convolutional neural network which we
1722.88|4.96|know so there's two modules here in this
1725.6|3.679|uh system diagram for image captioning
1727.84|3.48|model we're taking a convolutional
1729.279|3.441|neural network which we know can see and
1731.32|3.079|we're taking a recurrent neural network
1732.72|3.48|which we know is very good at modeling
1734.399|4.041|sequences in this case sequences of
1736.2|3.479|words that will be describing the image
1738.44|2.8|and then just as if we were playing with
1739.679|3.12|Legos we take those two pieces and we
1741.24|3.24|stick them together that's corresponding
1742.799|3.961|to this Arrow here in between the two
1744.48|4.28|modules and these networks learn to talk
1746.76|3.96|to each other and in the process of
1748.76|3.279|trying to describe the images these
1750.72|2.36|gradients will be flowing through the
1752.039|3.0|convolutional network and the full
1753.08|3.56|system will be adjusting itself to
1755.039|3.321|better see the images in order to
1756.64|3.68|describe them at the end and so this
1758.36|4.52|whole system will work uh together as
1760.32|4.28|one uh so we'll be working towards this
1762.88|2.799|model we'll actually cover this in class
1764.6|3.679|so you'll have full understanding
1765.679|4.161|exactly of both this part and this part
1768.279|3.0|about half halfway through the course
1769.84|3.199|roughly and you'll see how that image
1771.279|2.841|captioning model works but that's just a
1773.039|2.601|motivation for really what we're
1774.12|4.36|building up to and these are like really
1775.64|5.519|nice models to work with Okay but for
1778.48|5.12|now back to uh c41 and linear
1781.159|3.561|classification um so again just to
1783.6|4.12|remind you we're working with this data
1784.72|3.88|set 50,000 images 10 labels and the way
1787.72|2.6|we're going to approach linear
1788.6|4.199|classification is from what we call a
1790.32|3.92|parametric approach K neighbor that we
1792.799|2.961|just discussed now is something an
1794.24|2.76|instance of what we call non-parametric
1795.76|2.919|approach there's no parameters that
1797.0|4.2|we're going to be optimizing over this
1798.679|4.6|distinction will become clear in a few
1801.2|4.079|minutes uh so in the parametric approach
1803.279|3.841|what we're doing is we're thinking about
1805.279|4.64|constructing a function that takes an
1807.12|4.439|image and produces the scores for your
1809.919|3.401|classes right this is what we want to do
1811.559|3.441|we want to take an image and we'd like
1813.32|3.92|to figure out which one of the 10
1815.0|4.64|classes it is so we'd like to write down
1817.24|4.88|a function an expression that takes an
1819.64|3.84|image and gives your do 10 numbers but
1822.12|2.76|the expression is not only a function of
1823.48|3.319|that image but critically it will be
1824.88|3.96|also a function of these parameters that
1826.799|4.6|I'll call W sence also called the
1828.84|5.16|weights and so really it's a function
1831.399|4.88|that goes from 372 numbers which make up
1834.0|3.88|this image to 10 numbers that's what
1836.279|3.561|we're doing we're defining a
1837.88|4.08|function and we'll go through several
1839.84|3.52|choices of this function in this in the
1841.96|2.839|first case we'll look at linear
1843.36|2.64|functions and then we'll extend that to
1844.799|3.161|get neural networks and then we'll
1846.0|3.64|extend that to get convolutional neural
1847.96|4.0|networks but intuitively what we're
1849.64|4.24|building up to is that what we'd like is
1851.96|4.4|when we pipe this image through our
1853.88|3.72|function we'd like the 10 numbers that
1856.36|2.88|correspond to the scores of the 10
1857.6|3.919|classes we'd like the number that
1859.24|4.52|corresponds to the cat class to be high
1861.519|5.04|and all the other numbers to be low and
1863.76|4.879|we'll have we don't have a choice over X
1866.559|4.12|that X is our image that's given but
1868.639|4.361|we'll have Choice over W so we'll be
1870.679|4.0|free to set this in whatever way we want
1873.0|3.039|and we want we'll want to set it so that
1874.679|3.161|this function gives us the correct
1876.039|3.36|answers for every single image in our
1877.84|3.6|training data okay that's roughly the
1879.399|4.4|approach we're building up towards so
1881.44|4.4|suppose that we use the simplest uh
1883.799|5.12|function arguably the simplest just a
1885.84|4.839|linear classification here so X is our
1888.919|3.76|image in this case what I'm doing is I'm
1890.679|5.921|taking this array this image that makes
1892.679|5.321|up uh the cat and I'm stretching out um
1896.6|4.16|all the pixels in that image into a
1898.0|5.48|giant column Vector so that X there is a
1900.76|6.159|column Vector of 372
1903.48|5.48|numbers okay and so um if you know your
1906.919|4.0|Matrix uh
1908.96|3.839|Vector operations which you should
1910.919|2.961|that's a prerequisite for this class
1912.799|2.161|that there is just a matrix
1913.88|2.96|multiplication which you should be
1914.96|4.199|familiar with and basically we're taking
1916.84|4.16|X which is a 300 72 dimensional column
1919.159|3.721|Vector we're trying to get 10 numbers
1921.0|3.24|out and it's a linear function so you
1922.88|4.08|can go backwards and figure out that the
1924.24|6.679|dimensions of this W are basically 10 by
1926.96|6.64|372 so there are 30,7
1930.919|4.201|7200 numbers that goes into W and that's
1933.6|3.079|what we have control over that's what we
1935.12|3.679|have to tweak and find what works best
1936.679|4.201|on our data so those are the parameters
1938.799|4.441|in this particular case uh what I'm
1940.88|5.159|leaving out is there's also an appended
1943.24|5.559|plus b sometimes so you have a bias
1946.039|5.041|these biases are again 10 more par
1948.799|3.88|and um we have to also find those so
1951.08|3.559|usually in your linear classifier you
1952.679|4.0|have a w and a b we have to find exactly
1954.639|3.241|what works best and this B is not a
1956.679|4.36|function of the image that's just
1957.88|6.039|independent weights on the on How likely
1961.039|4.0|any one of those um images might be so
1963.919|3.841|to go back to your question if you have
1965.039|5.12|a very unbalanced data set for uh so
1967.76|4.759|maybe you have mostly cats but some dogs
1970.159|4.841|or something like that then you might
1972.519|4.081|expect that the cat the bias for the cat
1975.0|4.159|class might be slightly higher because
1976.6|4.0|by default the classifier wants uh to
1979.159|3.321|predict the cat class unless something
1980.6|3.72|convinces it
1982.48|3.96|otherwise something in the image would
1984.32|3.719|convince it otherwise okay so to make
1986.44|2.959|this more concrete uh I just like to
1988.039|3.52|break it down but of course I can't
1989.399|4.52|visualize it very explicitly with 372
1991.559|5.641|numbers so imagine that our input image
1993.919|5.681|only had four pixels and imagine so four
1997.2|4.0|pixels are stretched out in the column X
1999.6|4.199|and imagine that we have three classes
2001.2|5.88|so red green and blue class or a cat dog
2003.799|6.081|ship class okay so in this case W will
2007.08|4.079|be only a 3x4 Matrix and what we're
2009.88|5.0|doing here is we're trying to compute
2011.159|5.36|the score of this um image X so this is
2014.88|3.88|matrix multiplication going on here to
2016.519|4.601|give us the output of f which is the
2018.76|4.6|scores we get the three scores for three
2021.12|4.72|different classes so this is an random
2023.36|3.439|setting of w just random weights here
2025.84|2.959|and we're carrying out the matrix
2026.799|3.72|multiplication to get some scores so in
2028.799|4.681|particular you can see that with this
2030.519|5.16|this setting of w is not very good right
2033.48|5.199|because with this setting of w our cat
2035.679|4.72|score 96 is much less than any of the
2038.679|3.201|other classes right so this was not
2040.399|4.361|correctly classified for this training
2041.88|4.6|image so that's not it's not a very good
2044.76|3.72|classifier so we want to change a
2046.48|3.48|different we want to use a different W
2048.48|3.159|so that that score comes out higher than
2049.96|3.04|the other ones okay but we have to do
2051.639|5.96|that consistently across the entire
2053.0|6.079|training set of examples but uh but one
2057.599|5.24|thing to notice here as well is that
2059.079|6.0|basically W it's um this function is in
2062.839|3.881|parallel evaluating all the 10
2065.079|4.241|classifiers but really there are 10
2066.72|4.199|independent classif iers uh to some
2069.32|3.68|extent here and every one of these
2070.919|4.521|classifiers like say the cat classifier
2073.0|4.48|is just the first row of w here right so
2075.44|4.88|the first row and the first bias gives
2077.48|4.52|you the cat score and the dog classifier
2080.32|3.599|is the second row of w and the ship
2082.0|3.96|score the ship classifier the third row
2083.919|3.521|W so basically this W Matrix has all
2085.96|4.199|these different classifiers stacked in
2087.44|5.199|rows and they're all being dot producted
2090.159|5.321|with the image to give you the scores
2092.639|6.081|okay so here's a question for you uh
2095.48|5.72|what does a linear classifier do in
2098.72|3.879|English uh we saw the functional form
2101.2|3.36|it's taking these images it's doing this
2102.599|2.721|funny operation there but what how do we
2104.56|3.0|really
2105.32|4.6|interpret in English somehow what this
2107.56|2.36|is
2110.4|2.84|doing what is this functional form
2112.44|3.48|really
2113.24|5.52|doing yeah good Ahad if you just think
2115.92|4.88|of it as a a single binary classifier
2118.76|4.359|it's basically drawing a line that will
2120.8|4.84|tell you based on the um obser
2123.119|6.521|observations in your data if the point
2125.64|4.0|is below the line and it's not class
2130.76|4.2|Dimensions okay good so you're thinking
2132.8|3.6|about it uh in a spatial domain of X
2134.96|4.08|being a high dimensional data point and
2136.4|3.76|W is really putting uh planes through
2139.04|2.4|this High dimensional data point I'll
2140.16|3.32|come back to that interpretation in a
2141.44|4.12|bit uh what other way can we think about
2143.48|4.32|this uh for each class it has like sort
2145.56|4.559|of a template image that it basically
2147.8|5.0|multiplies with every image in which
2150.119|5.041|everyone comes through the brightest
2152.8|4.64|that's okay so you're thinking about it
2155.16|3.88|more in kind of like a template way
2157.44|4.08|where every single one of these rows of
2159.04|4.559|w effectively is like this template that
2161.52|3.559|we're do producting with the image and a
2163.599|4.881|do product is really a way of like
2165.079|7.401|matching up seeing what what aligns uh
2168.48|6.0|good um what otherwis yeah I guess it's
2172.48|4.599|same as what you said but putting a
2174.48|5.359|different words uh it's just saying that
2177.079|5.801|this part of the image is important
2179.839|6.52|attribute to be a cat this part of the
2182.88|5.32|image uh is not an important not an
2186.359|5.48|important part as
2188.2|5.08|to things like those those kind of yep
2191.839|4.201|so what you're referring to is that W
2193.28|4.079|basically has the capacity to to care or
2196.04|2.6|not care about different spatial
2197.359|3.561|positions in the image right because
2198.64|4.52|what we can do is some of the spatial
2200.92|4.56|positions in X if we have zero weights
2203.16|4.159|then the classifier would be doesn't
2205.48|3.92|care what's in part of image so if I
2207.319|4.241|have zero weights for this part here
2209.4|3.36|then nothing affects it but for some
2211.56|3.12|other parts of the image if you have
2212.76|3.2|positive or negative weights something's
2214.68|3.52|going to happen there and this is going
2215.96|5.359|to contribute to the score any other
2218.2|5.08|ways of describing it yeah it's taking
2221.319|4.601|something that exists in image space and
2223.28|5.16|projecting it into a space of
2225.92|4.12|labels uh yeah so taking yeah so you can
2228.44|3.28|think about it that also is like a nice
2230.04|5.319|interpretation it's like a mapping from
2231.72|5.68|image space to a label space yep good
2235.359|4.96|how do you come up with the with each of
2237.4|5.56|the numbers in the column Vector oh I
2240.319|5.201|made that up sorry how do you get them
2242.96|3.8|from the red and blue values sorry how
2245.52|2.52|do you get them from the red green and
2246.76|3.76|blue Valu
2248.04|4.2|uh yeah thank you so uh good question so
2250.52|3.4|this image is a threedimensional uh
2252.24|4.119|array where we have all these channels
2253.92|4.04|you just uh stretch it out so all the
2256.359|4.121|you just stretch it out in whatever way
2257.96|4.28|you like say you stack the red green and
2260.48|3.8|blue portions side by side that's one
2262.24|3.599|way you just stretch it out in whatever
2264.28|3.28|way you like but in a consistent way
2265.839|3.681|across all the images you figure out a
2267.56|3.32|way to serialize in which way you want
2269.52|2.799|to read off the pixels and you stretch
2270.88|2.719|them out into a column so then when you
2272.319|4.961|have 12
2273.599|8.76|values uh for four pixel image yeah okay
2277.28|6.799|good Point um okay yeah so let's say we
2282.359|4.521|have a four pixel grayscale image which
2284.079|4.0|is this is a terrible example thank you
2286.88|2.52|you're right thank you I didn't want to
2288.079|2.76|confuse people especially because
2289.4|3.12|someone pointed out to me later after I
2290.839|3.081|made this figure that red green and blue
2292.52|2.96|are the color channels but here the red
2293.92|3.56|green and blue correspond to classes so
2295.48|4.8|this is a complete uh screw up on my
2297.48|4.16|part so I apologize not color channels
2300.28|3.36|nothing to do with color channels just
2301.64|6.64|three different colored classes sorry
2303.64|7.8|about that okay go ahead so uh we have a
2308.28|4.799|different size of image like 40 * 600
2311.44|4.36|time something like that do you put a
2313.079|5.401|sort of zero inside
2315.8|4.72|or yeah thank you so your question is
2318.48|3.56|what if my images have different sizes
2320.52|3.12|in my data set some could be small some
2322.04|5.079|could be large exactly how do we make
2323.64|6.08|this all be a single sized column Vector
2327.119|4.401|uh the answer is you always we always
2329.72|4.24|resize images to be basically the same
2331.52|4.4|size we can't easily deal with different
2333.96|3.72|sized images uh or we can and we might
2335.92|3.08|go into that in a in later but but the
2337.68|3.08|simplest thing to think of is just
2339.0|4.359|resize every single image to the exact
2340.76|3.8|same uh size is the simplest thing
2343.359|3.801|because we want to ensure that all of
2344.56|3.96|them are kind of uh comparable of the
2347.16|3.04|same stuff so that we can make these
2348.52|3.559|columns and we can analyze statistical
2350.2|5.879|patterns that are aligned in the image
2352.079|5.361|space um yeah uh in fact
2356.079|2.481|state-of-the-art methods the way they
2357.44|2.639|actually work on this is they always
2358.56|3.08|work on Square images so if you have a
2360.079|3.321|very long image these methods will
2361.64|3.679|actually work worse because many of them
2363.4|4.56|what they do is just squash it that's
2365.319|4.361|what we do still works fairly well
2367.96|3.08|uh so yeah if you have very long like
2369.68|3.12|panr images and you try to put that
2371.04|3.52|somewhere on like some online service
2372.8|2.64|chances are it might work worse because
2374.56|2.12|they'll probably when they put it
2375.44|2.8|through a compet they will make it a
2376.68|2.52|square because these componets always
2378.24|2.96|work on
2379.2|3.119|squares uh you can make them work on
2381.2|2.04|anything but that's just in practice
2382.319|4.201|what happens
2383.24|5.28|usually uh any other questions or yeah
2386.52|5.76|it's like assigning a score to each test
2388.52|6.68|image for each class uh yep so you're
2392.28|4.6|interpreting the W the classifier yeah
2395.2|4.04|yeah so each image gets mapped through
2396.88|4.16|this uh setting okay anyone anyone else
2399.24|4.68|would like to interpret this or okay
2401.04|4.52|great so another way to actually put it
2403.92|3.04|one way that I didn't hear but it's also
2405.56|4.16|a relatively nice way of looking at it
2406.96|5.2|is that basically every single score is
2409.72|4.32|just a weighted sum of all the pixel
2412.16|3.76|values in the image and these weights
2414.04|3.799|are we get to choose those eventually
2415.92|3.199|but it's just a giant weighted sum it's
2417.839|4.201|really all it's doing is it's counting
2419.119|5.841|up colors right it's counting up colors
2422.04|4.36|at different spatial positions so uh one
2424.96|2.72|way to one way that was brought up in
2426.4|3.679|terms of how we can inter interpret this
2427.68|3.8|W classifier to make it concrete is that
2430.079|4.161|it's kind of like a bit like a template
2431.48|4.4|matching thing so here what I've done is
2434.24|2.839|I've trained a classifier and I haven't
2435.88|3.84|shown you how to do that yet but I
2437.079|4.321|trained my weight Matrix W and then I'll
2439.72|3.24|come back to this in a second I'm taking
2441.4|3.28|out every single one of those rows that
2442.96|3.84|we've learned every single classifier
2444.68|4.28|and I'm reshaping it back to an image so
2446.8|4.2|that I can visualize it okay so I'm
2448.96|4.159|taking it originally just a giant row of
2451.0|4.48|372 numbers I reshape it back to the
2453.119|4.921|image to undo the Distortion I've done
2455.48|4.08|and then I have all these templates
2458.04|4.16|and so for example what you see here is
2459.56|4.96|that plane it's like a blue blob here
2462.2|4.08|the reason you see blue blob is that if
2464.52|3.76|you looked at the color channels of this
2466.28|3.319|plain template you'll see that in the
2468.28|2.88|blue Channel you'll have lots of
2469.599|4.361|positive weights because those positive
2471.16|4.199|weights if they see blue values then
2473.96|3.639|they interact with those and they get a
2475.359|3.881|little contribution to the score so this
2477.599|3.281|PL classifier is really just counting up
2479.24|3.64|the amount of blue stuff in the image
2480.88|3.28|across all these spatial locations and
2482.88|2.84|if you look at the red and the green
2484.16|3.6|channel for the plane classifier you
2485.72|4.119|might find zero values or even negative
2487.76|3.44|values right so that's the plain
2489.839|4.081|classifier and then we have classifiers
2491.2|4.08|for all these other images so say a frog
2493.92|3.399|you can almost see the template of the
2495.28|3.92|Frog there right we're looking for some
2497.319|3.681|green stuff is green stuff has positive
2499.2|4.6|weights in here and then we see some
2501.0|4.839|brown stuff is things on the side right
2503.8|3.88|so if that gets put over an image and do
2505.839|4.961|producted you'll get a high
2507.68|5.32|score um one thing to note here is that
2510.8|5.36|look at this the car classifier that's
2513.0|5.599|not a very like nice template of a car
2516.16|4.76|also here the horse look looks a bit
2518.599|3.361|weird what's up with that why is the car
2520.92|2.0|looking weird and why is the horse
2521.96|3.24|looking
2522.92|3.76|weird yeah some horses are facing left
2525.2|2.84|and some are facing right we end up with
2526.68|3.6|this where it looks like a horse is two
2528.04|4.88|heads both basically that's what's going
2530.28|4.12|on in the data the horses some are
2532.92|3.0|facing left somewh right and this
2534.4|3.84|classifier really it's not very powerful
2535.92|3.84|classifier and it has to combine the two
2538.24|2.92|modes it has to do both things at the
2539.76|3.52|same time so you end up with this
2541.16|4.0|two-headed horse in there and you can in
2543.28|3.48|fact say that just from this result
2545.16|3.72|there's probably more left facing horses
2546.76|5.04|in far than right because it's stronger
2548.88|5.92|there uh also for car right we can have
2551.8|5.2|a car like 45° tilted left or right or
2554.8|5.08|front and this classifier here is the
2557.0|5.0|optimal way of mixing across like
2559.88|3.0|merging all those modes into a single
2562.0|2.559|template because that's what we're
2562.88|3.4|forcing it to do once we're actually
2564.559|3.161|doing com nuts and neural networks they
2566.28|3.4|don't have this downside they can
2567.72|3.32|actually have in principle they can have
2569.68|2.879|a template for this car or that car or
2571.04|3.2|that car and combine across them we're
2572.559|3.441|giving them more power to actually carry
2574.24|3.92|out this classification more properly
2576.0|4.359|but for now we're constrained by this
2578.16|4.959|question if you only have one image of a
2580.359|5.681|horse or only a couple you rotate it
2583.119|6.081|yourself bu different ways and in
2586.04|3.92|certain ways so thatass would over to
2589.2|2.84|one
2589.96|3.72|orientation uh yes what you're referring
2592.04|3.6|to I think is something we call data
2593.68|4.28|augmentation so at training time we
2595.64|3.679|would not be taking just uh exact images
2597.96|3.04|but we'll be jittering them stretching
2599.319|2.921|them spewing them and we'll be piping
2601.0|3.119|all of that in that's going to become a
2602.24|4.24|huge part of getting comat to work very
2604.119|4.041|well uh so yeah so we'll be doing a huge
2606.48|3.32|amount of that stuff
2608.16|3.12|uh for every single training example
2609.8|3.44|we're going to hallucinate many other
2611.28|4.039|training examples of shifts and rotates
2613.24|4.92|and SKS and that works much better go
2615.319|6.321|ahead uh how do these templates differ
2618.16|5.04|from just taking the average pixel value
2621.64|4.08|for each
2623.2|4.6|class uh how do these templates uh
2625.72|4.92|change taking the average pixel value
2627.8|6.799|took all the images for a plane took the
2630.64|5.8|average all the I see so you want to uh
2634.599|3.201|explicitly set a template and the way
2636.44|3.0|you'll set the temp is you'll take the
2637.8|4.08|average across all the images and that
2639.44|4.36|becomes your template sure I'm just
2641.88|5.679|wondering
2643.8|8.799|yeah how those two approaches would
2647.559|6.321|differ um so this classifier it finds it
2652.599|3.601|would do something similar I would guess
2653.88|4.12|it would work worse uh because the
2656.2|3.0|linear classifier when you look at its
2658.0|2.92|mathematical form and really what it
2659.2|3.6|optimizes for I don't think it would
2660.92|3.88|have a minimum at what you described and
2662.8|4.6|just the mean of the images uh but that
2664.8|4.16|would be like a intuitively decent
2667.4|2.64|heuristic to perhaps set the weights in
2668.96|3.48|the initialization or something like
2670.04|3.64|that classier that does that like
2672.44|4.56|something yeah there's something related
2673.68|5.08|to it uh yeah yeah but we might even go
2677.0|5.0|into that LDA probably is what you're
2678.76|6.0|referring to there's several several
2682.0|4.76|things okay yeah uh don't you think it
2684.76|4.559|would be much better if we do it with
2686.76|6.559|gray scale images because let's say we
2689.319|6.841|got a car that was like yellowish right
2693.319|5.561|but our template image highlights red
2696.16|4.56|right so wouldn't it be better if you
2698.88|3.0|race yeah so that's a good point so
2700.72|2.76|there are cars have many different
2701.88|3.4|colors and here this happened to pick up
2703.48|4.28|on red which is saying that there's
2705.28|4.0|probably more red cars in the data set
2707.76|4.0|and uh it might not work for yellow in
2709.28|5.44|fact yellow cars might be frog for this
2711.76|4.839|classifier right um so this thing just
2714.72|3.119|does not have capacity to do all of that
2716.599|2.48|which is why it's not powerful enough it
2717.839|3.76|can't capture all these different modes
2719.079|4.321|correctly and so this will just go after
2721.599|2.801|the numbers there's more red cars that's
2723.4|3.959|where it will
2724.4|4.159|go uh if this was grayscale I'm not sure
2727.359|3.0|if that would work better I'll come back
2728.559|3.081|to that actually in a bit go ahead if
2730.359|3.48|you have a training set with more
2731.64|3.919|examples for cash would that affect the
2733.839|3.161|buyas higher and if so would that affect
2735.559|3.8|the the
2737.0|3.839|test uh yeah so you might expect as I
2739.359|5.081|mentioned for unbalanced data sets what
2740.839|5.961|you might expect um not
2744.44|4.399|exactly you what you might expect if you
2746.8|4.24|have lots of cats is that the cat bias
2748.839|4.401|would be higher because this class this
2751.04|4.72|this classifier is just used to spewing
2753.24|4.0|out large numbers uh based on the loss
2755.76|3.359|but uh we have to go into loss fun to
2757.24|6.04|exactly see how that will play out uh so
2759.119|5.2|it's hard to say right now um okay uh
2763.28|2.2|another interpretation of the linear
2764.319|2.561|classifier that also someone else
2765.48|3.839|pointed out that I'd like to point out
2766.88|5.479|is uh you can think of these images as
2769.319|5.841|very high dimensional points in a 372
2772.359|4.921|dimensional space right in the 372 pixel
2775.16|4.52|space dimensional pixel space every
2777.28|4.2|image is a point and these linear
2779.68|3.96|classifiers are describing these
2781.48|4.359|gradients across the 372 dimensional
2783.64|3.56|space these scores are this uh gradient
2785.839|3.801|of negative to positive along some
2787.2|4.6|linear Direction across the space and so
2789.64|3.959|for example here for a car classifier
2791.8|4.16|I'm taking the first row of w which is
2793.599|4.161|the car class and the line here is
2795.96|4.52|indicating the zero level set of that
2797.76|4.76|classifier in other words that along
2800.48|4.28|that line the car classifier has zero
2802.52|4.16|score so the car classifier there has
2804.76|4.359|zero and then the arrow is indicating
2806.68|5.96|the direction along which it will color
2809.119|5.841|the space uh with more and more carness
2812.64|3.76|of score similar we have these three
2814.96|3.48|different classifiers in this example
2816.4|3.52|they will correspond to these gradients
2818.44|4.0|with a particular level set and they're
2819.92|5.72|basically trying to go in you have all
2822.44|4.76|these points they are in the space and
2825.64|3.12|these linear classifiers we initialize
2827.2|3.359|them randomly so this car classifier
2828.76|3.2|would have its level set at random and
2830.559|3.8|then you'll see when we actually do the
2831.96|4.52|optimization as we optimize this will
2834.359|4.641|start to shift turn and it will try to
2836.48|3.76|isolate the car class and we like it's
2839.0|3.52|really fun to watch these classifiers
2840.24|3.76|train because it will it will rotate it
2842.52|3.079|will snap in for the car class and it'll
2844.0|2.88|start to jiggle and it will try to like
2845.599|3.041|separate out all the cars from all the
2846.88|4.199|we got all the non cars it's really
2848.64|4.0|amusing to watch so that's another way
2851.079|3.48|of interpreting that someone has brought
2852.64|3.919|up okay so here's a question for you
2854.559|4.681|given all these interpretations what
2856.559|3.921|would be a very hard test set given how
2859.24|3.64|the linear classifier Works what would
2860.48|5.599|you expect to work really just really
2862.88|3.199|not well with a linear
2869.24|5.24|classifier concurrent circles sorry
2872.24|4.599|concurrent circles concurrent circles so
2874.48|4.359|your classes are what are your CL
2876.839|4.081|classes exactly so you have a red class
2878.839|4.041|in the middle that's like Circle or like
2880.92|4.0|a blob of red classes and then around it
2882.88|3.719|you have a blob of blue classes oh I see
2884.92|3.72|so you're in okay so what you're
2886.599|4.921|describing is in this interpretation of
2888.64|5.12|space if your images in one class would
2891.52|4.319|be in a blob and then your other class
2893.76|3.48|is like around it so I'm not sure
2895.839|2.841|exactly what that would look like if you
2897.24|3.319|actually visualize it in in a pixel
2898.68|3.399|space uh but yes you're right in that
2900.559|3.481|case linear classifier would not be able
2902.079|3.48|to separate out those but what about in
2904.04|3.64|terms of like uh what would the images
2905.559|4.321|look like you would look at this data
2907.68|3.879|set of images and you clearly say that
2909.88|2.84|linear classifier will probably not do
2911.559|3.481|very well
2912.72|4.24|here yeah go ahead you want to separate
2915.04|3.88|like scooters for
2916.96|4.32|motorcycles basically or something like
2918.92|3.48|that because I think somebody else was
2921.28|3.16|asking about the averaging of the
2922.4|3.8|pictures and that that made me think if
2924.44|3.28|you're doing like ordinary Le squares
2926.2|4.2|what you're basically doing is
2927.72|5.839|maximizing projections of of all the X's
2930.4|4.919|onto your row space so if you look at
2933.559|4.081|training X's of scooters and training
2935.319|4.76|X's of motorcycles they're going to
2937.64|4.679|effectively yield the same like centroid
2940.079|4.121|for the template and then you're going
2942.319|3.641|to get the same situation describing
2944.2|4.56|where you have concentric circles in
2945.96|4.359|yourens space mhm yep yep so that's a
2948.76|6.28|pretty good one yeah good maybe the
2950.319|7.201|negative images like uh CH you know
2955.04|5.2|subtracting 255 whatever the color is
2957.52|4.92|you know
2960.24|3.599|like so you want one Clause to be say
2962.44|2.919|you take all the airplanes and then you
2963.839|3.52|you want to switch like an airplane to a
2965.359|4.881|human if it were the negative like film
2967.359|5.281|negative image of a oh I see it would it
2970.24|3.68|would be actually the lowest scoring oh
2972.64|2.4|I see I see so you're you're pointing
2973.92|2.28|out that if I took that image of an
2975.04|2.92|airplane class and I have a trained
2976.2|3.8|classifier and then I do a negative of
2977.96|3.68|it negative image of that classifier
2980.0|3.119|you'd still see the edges and you you'll
2981.64|3.24|say okay that's an airplane obviously by
2983.119|4.401|the shape but for linear classifier all
2984.88|3.919|the colors would be exactly wrong and so
2987.52|4.44|the linear classifier would hate that
2988.799|5.481|airplane so yeah good example good you
2991.96|4.24|take the same exact image and you
2994.28|3.2|translate it or scale it differently and
2996.2|2.96|you move it to different places are
2997.48|5.16|rotated for each class you have several
2999.16|5.36|of these I'd expect that to perform I
3002.64|4.199|see so uh you're saying that we take one
3004.52|3.64|thing say like dogs but then so what
3006.839|3.0|you're referring to is say you have dogs
3008.16|3.76|one class is dogs in the center and one
3009.839|4.041|class is dogs in the on the right and
3011.92|3.159|you think that that would be uh yeah I'm
3013.88|3.479|saying even if it's a picture of the
3015.079|4.121|same exact dog same pose and everything
3017.359|3.401|you just move it to the right up down or
3019.2|4.32|you scale it to different sizes and move
3020.76|4.599|it around so would that be a problem if
3023.52|3.559|so one class is dogs in the center and
3025.359|3.0|one class is dogs in the right but
3027.079|3.52|otherwise white background or something
3028.359|4.44|like that would that be a
3030.599|4.921|problem it wouldn't be a problem why
3032.799|4.641|wouldn't it be a problem
3035.52|4.16|transformation uh it's an aine
3037.44|4.52|transformation a linear transformation
3039.68|5.639|what you areel I guess that the problem
3041.96|6.8|would be if you work an image you have a
3045.319|6.28|set of images like dogs and dogs work or
3048.76|5.599|ex skewed in some nonlinear way I
3051.599|3.76|see right so you're saying that maybe a
3054.359|2.96|more difficult thing would be if you
3055.359|3.76|have dogs that are warped in some funny
3057.319|3.961|ways according to class why wouldn't it
3059.119|3.401|be a problem if you actually could a
3061.28|2.4|linear classifier do something in the
3062.52|2.4|center and something on the right does
3063.68|4.08|it actually have an understanding of a
3064.92|4.6|spatial layout that' actually be fine
3067.76|3.44|right that would be relatively easy
3069.52|6.16|because you would have positive weights
3071.2|6.2|in the middle oh Sor suggesting oh sorry
3075.68|3.879|okay maybe I'm misunderstood I'm sorry
3077.4|4.84|okay another one classifying different
3079.559|4.361|types of P names the author be hard
3082.24|4.04|because they use Bunch different colors
3083.92|3.679|and different Set uh yeah possibly yeah
3086.28|3.88|so I think many of you are kind of
3087.599|4.121|understanding the the main point is uh
3090.16|3.32|yeah so this is really really what it's
3091.72|2.839|doing well I'm skipping ahead here
3093.48|3.28|really what this is doing is it's
3094.559|4.161|counting up uh counting up colors in
3096.76|3.799|spatial positions anything that messes
3098.72|3.04|with this will be really hard actually
3100.559|3.081|to go back to your point if you had a
3101.76|4.12|grayscale data set by the way that would
3103.64|3.8|work not very well with L linear
3105.88|3.36|classifiers would probably not work if
3107.44|4.72|you took CFR 10 and you make it all
3109.24|4.24|grayscale then doing the exact cartan
3112.16|3.0|classification but on grayscale images
3113.48|3.24|would probably work really terribly
3115.16|3.12|because you can't pick up on the colors
3116.72|4.52|you have to pick up on these textures
3118.28|4.36|and fine details now and you just can't
3121.24|2.879|localize them because they could be at
3122.64|4.08|arbitrary positions you can't
3124.119|4.361|consistently count across it um so yeah
3126.72|2.839|that would be kind of a disaster uh
3128.48|3.16|another example would be different
3129.559|4.401|textures if you have say all of your
3131.64|4.88|textures are blue but these textures
3133.96|4.599|could be uh different types then this
3136.52|3.2|doesn't really like say these textures
3138.559|2.52|could be different types but they can be
3139.72|2.52|spatially invariant and that would be
3141.079|4.441|terrible terrible for all your
3142.24|6.96|classifier as well okay
3145.52|6.68|good uh so just to remind you I think uh
3149.2|5.599|nearly there um we defin this linear
3152.2|4.08|function so with a specific case of w
3154.799|3.481|we're looking at some test images we're
3156.28|4.559|getting some scores out and just looking
3158.28|3.96|forward where we're headed now is with
3160.839|3.641|some setting of W's we're getting some
3162.24|4.079|scores for all these images and so for
3164.48|4.28|example with this setting of w in this
3166.319|4.561|image we're seeing that the cat score is
3168.76|3.72|2.9 but there are some classes that got
3170.88|3.12|a higher score like dog so that's not
3172.48|3.52|very good right but some classes have
3174.0|3.319|negative scores which is uh good for
3176.0|3.359|this image
3177.319|4.361|so this is a kind of a medium result for
3179.359|3.881|this weights for this image and here we
3181.68|3.439|see that the car class which is correct
3183.24|4.4|for there has the highest score which is
3185.119|4.96|good right so this setting of w worked
3187.64|5.12|well on this image here we see that the
3190.079|4.76|for class is a very low score so w
3192.76|4.28|worked terribly on that image so where
3194.839|4.72|we're headed now is we're going to
3197.04|4.44|Define what we call a loss function and
3199.559|3.681|this loss function will quantify this
3201.48|3.24|intuition of what we consider good or
3203.24|2.76|bad right now we're just eye boiling
3204.72|2.639|these numbers and saying what's good
3206.0|3.16|what's bad we have to actually write
3207.359|4.601|down a mathematical expression that
3209.16|6.439|tells us exactly like this setting of w
3211.96|6.399|across our test set is 12.5 bad or 12
3215.599|4.321|whatever bad or 1.0 bad because then
3218.359|3.121|once we have it defined specifically
3219.92|3.76|we're going to be looking for W's that
3221.48|4.24|minimize the loss and it will be set up
3223.68|4.439|in such a way that when you have a loss
3225.72|4.16|of very low numbers like say even zero
3228.119|2.601|then you're correctly classifying all
3229.88|3.32|your
3230.72|4.119|images um but if you have a very high
3233.2|3.32|loss then everything is messed up and W
3234.839|3.041|is not good at all so we're going to
3236.52|3.079|Define a loss function and then we're
3237.88|4.36|going to look for different W's that
3239.599|4.2|actually do very well across all of it
3242.24|3.559|so that's roughly what's coming up we'll
3243.799|5.481|Define loss function which is a quantify
3245.799|5.52|a way to quantify how bad each W is on
3249.28|4.319|our data set the loss function is a
3251.319|5.8|function of your entire training set and
3253.599|4.52|your weights we don't have um control
3257.119|2.801|over the training set but we have
3258.119|2.761|control over the weights then we're
3259.92|2.879|going to look at the process of
3260.88|4.8|optimization how do we efficiently find
3262.799|4.76|the set of Weights W that works across
3265.68|3.84|all the images and gives us a very low
3267.559|3.401|loss and then eventually what we'll do
3269.52|2.92|is we'll go back and we'll look at this
3270.96|3.0|expression the linear classifier that we
3272.44|3.84|saw and we're going to start meddling
3273.96|4.119|with the function f here so we're going
3276.28|2.88|to extend F to not be that simple in
3278.079|2.52|your expression but we're going to make
3279.16|3.28|it slightly more complex we'll get a
3280.599|3.121|neural network out and then we'll make
3282.44|3.04|it slightly more complex and we'll get a
3283.72|4.24|convolutional network out but otherwise
3285.48|3.76|the entire framework will stay unchanged
3287.96|3.159|all the time we'll be Computing these
3289.24|3.64|scores this functional form will be
3291.119|4.161|changing but we're going from image to
3292.88|3.679|some set of scores uh through some
3295.28|3.6|function and we'll make it more
3296.559|3.961|elaborate over time and then we're
3298.88|3.199|identifying some loss function and we're
3300.52|3.319|looking at what weights what parameters
3302.079|3.681|are giving us very low loss and that's
3303.839|4.041|the setup will we working with uh going
3305.76|4.359|forward so next class we'll look into
3307.88|4.959|loss functions and then we'll go towards
3310.119|4.761|neural networks and comets so um I guess
3312.839|5.28|this is my last slide so I can take uh
3314.88|6.76|any last questions and then can you
3318.119|3.521|explain the advantage of this itative
3323.119|8.96|approach uh sorry sorry uh sorry I
3327.319|4.76|didn't hear so I was saying why are we
3336.079|2.921|doing why are we doing alterative
3337.96|2.68|approach in the
3339.0|3.24|optimization so sometimes in
3340.64|3.56|optimization settings you can have for
3342.24|3.4|um these iterative approaches are
3344.2|4.159|basically the way this will work we'll
3345.64|4.56|we'll always start off with a random W
3348.359|3.281|uh so that will give us some loss and
3350.2|3.04|then we we don't have a process of
3351.64|4.199|finding right away the best set of
3353.24|5.24|Weights what we do have a process for is
3355.839|4.2|iterative slightly improving the weights
3358.48|3.28|so what we'll see is we'll look at the L
3360.039|3.601|function and we'll find the gradient in
3361.76|3.96|in the parameter space and we'll March
3363.64|4.04|down so what we do know how to do is how
3365.72|3.52|do we slightly improve a set of Weights
3367.68|3.08|we don't know how to do the problem of
3369.24|3.24|just find the best set of weights right
3370.76|2.799|away we don't know how to do that
3372.48|3.119|because especially when these functions
3373.559|4.881|are very complex like say entire comets
3375.599|5.2|it's a huge landscape of it's just a
3378.44|6.8|very uh intractable problem is that your
3380.799|6.32|question I'm not sure I okay thank you
3385.24|4.119|um
3387.119|4.401|yeah so how do you deal with that uh
3389.359|3.641|color problem how do we deal with the
3391.52|4.599|color problem
3393.0|6.68|yeah since we had a high bias of red
3396.119|5.2|cars oh so okay so uh so here we saw
3399.68|3.8|that the linear classifier for a car was
3401.319|4.201|this red template for a car a neural
3403.48|3.76|network basically what we'll do is we'll
3405.52|3.599|be will you can look at it as stacking
3407.24|3.4|linear classifiers to some degree so
3409.119|3.24|what it'll end up doing is it will have
3410.64|3.719|all these little templates really for
3412.359|3.76|red cars yellow cars green cars whatever
3414.359|3.081|cars going this way or that way or that
3416.119|2.48|way there will be a neuron assigned to
3417.44|3.0|detecting every one of these different
3418.599|4.0|modes and then they will be combined
3420.44|3.159|across them on a second layer so
3422.599|2.44|basically you'll have these neurons
3423.599|3.44|looking for different types of cars and
3425.039|3.441|then the next neuron will be just like
3427.039|3.28|okay I just take a wait at some of you
3428.48|4.28|guys and I'm just doing an or operation
3430.319|4.081|over you and then we can detect cars in
3432.76|3.799|all of their modes and all of their
3434.4|3.959|positions if that makes sense uh so
3436.559|6.361|that's roughly how it will
3438.359|4.561|work makes sense okay awesome
3445.16|4.76|okay
3447.359|2.561|this