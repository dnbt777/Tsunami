start_time|end_time|text
1.52|5.279|so our administrative uh points for
3.6|4.84|today U assignment three is due tonight
6.799|3.96|so who's
8.44|3.48|done that's good uh was it easier than
10.759|3.88|assignment
11.92|5.119|two okay that's good um hopefully gives
14.639|4.841|you more time to work on your projects
17.039|4.681|um so also remember your Milestones were
19.48|3.68|were uh turned in were turned in last
21.72|2.639|week so we're in the process of looking
23.16|3.119|through the Milestones to make sure
24.359|3.881|those are okay and also we're working on
26.279|3.76|assignment two grading so we should have
28.24|3.12|that done sometime this week or early
30.039|3.801|next
31.36|4.719|week uh last time we had a whirlwind
33.84|3.84|tour of uh all the soft all the common
36.079|3.601|software packages that people use for
37.68|3.52|deep learning um and we saw a lot of
39.68|3.32|code on slides and a lot of stepping
41.2|4.8|through code and hopefully that you
43.0|5.12|found that useful for your
46.0|4.0|projects today we're going to talk about
48.12|3.88|two other topics uh we're going to talk
50.0|4.44|about segmentation um within
52.0|4.8|segmentation there are two sub problems
54.44|3.799|semantic and instance segmentation um
56.8|3.759|we're also going to talk about soft
58.239|3.8|attention um and within soft attention
60.559|2.841|again there's sort of two buckets that
62.039|4.961|we've divided things
63.4|6.48|into uh but first before we go into all
67.0|5.439|these details um I there's something
69.88|4.12|else I want to bring up briefly so uh
72.439|3.521|this is the imag net classification
74.0|3.52|errors um I think at this point in the
75.96|5.4|class you've seen this type of figure
77.52|7.0|many times right so in 2012 um alexnet
81.36|6.24|uh 2013 ZF crushed it um recently Googl
84.52|5.88|net uh and later resnet is sort of held
87.6|4.04|the won the classification challenge um
90.4|4.759|in
91.64|6.32|2015 but um turns out uh as of today
95.159|6.521|there's a new image net result so this
97.96|6.92|paper came out last night
101.68|6.399|um um so Google actually has now
104.88|5.519|state-of-the-art on imet with 3.08% top
108.079|5.08|five error which is
110.399|5.04|crazy um and the way that they do this
113.159|5.0|is with um this thing that they call
115.439|4.521|Inception V4 um this is a little bit of
118.159|4.841|a monster so I don't want to go into too
119.96|5.119|much detail um but you can see that it's
123.0|4.32|this really deep Network um that has
125.079|4.841|these repeated modules so here there's
127.32|4.96|the stem um the stem is this guy over
129.92|4.44|here um a couple interesting things to
132.28|3.2|point out about this architecture are
134.36|2.76|actually they use some valid
135.48|4.36|convolutions which means they have no
137.12|4.36|padding so that makes every all the math
139.84|4.96|more complicated but they're smart and
141.48|4.68|they figured things out um they also an
144.8|2.96|interesting feature here is they
146.16|4.079|actually have in parallel strided
147.76|3.839|convolution and also Max pooling so they
150.239|3.201|kind of do these two operations in
151.599|4.64|parallel to down sample images and then
153.44|4.72|concatenate again at the end um another
156.239|4.161|thing is they they're really going all
158.16|3.56|out on these um efficient convolution
160.4|3.52|tricks that we talked about a couple
161.72|3.92|lectures ago so as you can see they've
163.92|5.36|actually have um these asymmetric
165.64|5.28|filters like 1x7 and 7x1 convolutions um
169.28|3.56|they also make heavy use of these 1ex
170.92|4.88|one convolutional bottlenecks to reduce
172.84|5.08|computational costs um so this is just
175.8|4.079|the stem of the network and actually
177.92|4.12|each of these parts is um sort of
179.879|4.72|different so uh they've got four of
182.04|5.52|these Inception modules uh then this
184.599|4.56|down sampling module then uh what seven
187.56|4.08|of these guys and then another down
189.159|4.881|sampling module and then three more of
191.64|5.0|these guys and then finally they have
194.04|4.8|Dropout and um and a fully connected
196.64|3.92|layer for the class labels so another
198.84|3.479|thing to point out is again there's no
200.56|3.16|sort of fully connected hidden layers
202.319|3.401|here they just have this Global
203.72|4.599|averaging to compute the final feature
205.72|6.04|Vector um and another cool thing they
208.319|5.761|did in this paper was Inception resnets
211.76|4.24|so they proposed this uh residual
214.08|4.2|version of the Inception architecture
216.0|4.68|which is also pretty big and scary um
218.28|5.0|the stem is the same as before and now
220.68|4.44|these these repeated um Inception blocks
223.28|3.44|that they repeat throughout the network
225.12|4.0|they actually have these residual
226.72|3.64|connections um so that's that's kind of
229.12|3.119|cool they're kind of jumping on this
230.36|4.28|residual idea and now improved
232.239|4.521|state-of-the-art on imag net so again
234.64|4.0|they have many repeated modules and when
236.76|4.72|you add this thing all up it's um about
238.64|5.0|7 it's 75 layers assuming I did the math
241.48|4.92|right last
243.64|5.08|night so uh they also show that um
246.4|4.679|between their sort of new Inception
248.72|4.92|their new uh version four of inception
251.079|4.281|googlet and their residual version of uh
253.64|5.48|googlet that actually both of them
255.36|6.76|perform about the same so this is a top
259.12|5.799|five error as a function of epo on imet
262.12|4.84|so you can see that the the um Inception
264.919|4.961|Network in red actually is converging a
266.96|4.56|bit faster but um over time both of of
269.88|3.92|them sort of converge to about the same
271.52|5.399|value um so that that's kind of
273.8|5.119|interesting um that's kind of cool um
276.919|3.84|another thing that's kind of interesting
278.919|4.161|to point out is this this there's the
280.759|4.081|raw numbers on the x-axis here uh these
283.08|4.959|are epochs on imag net so these things
284.84|5.72|are being trained for 160 Epoch on imet
288.039|4.841|so that's that's a lot of training
290.56|4.12|time um but that's that's enough of
292.88|3.56|current events and let's go back to our
294.68|4.079|regularly scheduled
296.44|3.84|programming so today oh yeah question
298.759|3.841|you know how many parment they add in
300.28|5.32|that I don't know I think it might be in
302.6|5.8|the paper but I didn't read too
305.6|5.439|carefully any other questions on uh yeah
308.4|4.2|so only do drop out in the last layer uh
311.039|3.841|the question is about Dropout um whether
312.6|4.52|it's only in the last layer I'm I'm not
314.88|4.8|sure again I didn't read the paper too
317.12|5.44|too carefully yet um but but it's the
319.68|6.72|link is here you should check it
322.56|6.24|out okay um so today we're going to talk
326.4|3.88|about uh two other sort of two other
328.8|3.04|topics that are
330.28|3.759|uh sort of common things in research
331.84|3.68|these days so those are segmentation
334.039|3.44|which is this sort of classic computer
335.52|4.399|vision topic and also this idea of
337.479|4.041|attention which I think is a really has
339.919|4.201|been a really popular thing to work on
341.52|4.6|in deep learning over the past year
344.12|2.96|especially so first we're going to talk
346.12|3.44|about
347.08|4.36|segmentation so you may have remembered
349.56|3.479|this slide from a couple lectures ago
351.44|3.12|when we talked about object detection
353.039|3.72|that was talking about different tasks
354.56|3.88|that people work on in computer vision
356.759|3.921|um and we spent a lot of time in the
358.44|4.24|class talking about classification
360.68|4.0|um and back in lecture we talked about
362.68|4.68|different models for localization and
364.68|4.48|for object detection um but today we're
367.36|3.959|actually going to focus on this idea of
369.16|3.96|segmentation that we skipped over last
371.319|4.641|time in this previous
373.12|5.04|lecture so within segmentation there's
375.96|4.48|sort of two different subtasks that we
378.16|3.68|need to make that we need to Define and
380.44|4.4|people actually work on these things a
381.84|5.759|little bit separately the first task is
384.84|5.4|this idea called semantic segmentation
387.599|4.801|so here we take an in we have an input
390.24|4.44|image and we have some fixed number of
392.4|5.32|classes um things like buildings and
394.68|4.68|tree and ground and cow and whatever
397.72|3.28|kind of semantic labels you want usually
399.36|4.2|you have some small fixed number of
401.0|4.68|classes um also typically you'll have
403.56|4.479|some a background class for for things
405.68|4.2|that don't fit into these classes and
408.039|4.44|then the task is that we want to take as
409.88|4.56|input um an image and then we want to
412.479|4.681|label every pixel in that image with one
414.44|4.72|of these semantic classes so here we've
417.16|4.759|taken this input image of these three
419.16|5.439|cows in a field and the ideal output is
421.919|4.801|this image where instead of being RGB
424.599|5.0|values we actually have one class label
426.72|5.44|per pixel um so we can do this on other
429.599|5.561|images and maybe segment out the trees
432.16|5.319|and the sky and the road the grass so
435.16|4.12|this type of task is pretty cool I think
437.479|2.881|it gives you sort of a higher level
439.28|3.0|understanding of what's going on in
440.36|4.8|images compared to just putting a single
442.28|4.359|label on the whole image um and this is
445.16|4.52|actually a very old problem in computer
446.639|5.041|vision so this uh that predat sort of of
449.68|3.639|the deep learning Revolution so this
451.68|4.799|figure actually comes from a computer
453.319|4.921|vision paper back in 2007 um that didn't
456.479|5.201|use any deep learning at all people had
458.24|6.28|other methods for this uh a couple years
461.68|5.639|ago the other task that people work on
464.52|4.92|is this thing oh right so the the thing
467.319|5.44|to point out here is that this thing is
469.44|6.0|not aware of instances so here this this
472.759|4.28|image actually has well four cows um
475.44|3.199|there's actually three cows standing up
477.039|4.12|and one cow kind of laying on the grass
478.639|4.12|taking a nap but here in this output
481.159|3.841|it's not really clear how many cows
482.759|4.72|there are um these different cows
485.0|4.84|actually their pixels overlap so here in
487.479|4.641|the output there's no notion that there
489.84|4.72|are different cows um in this output
492.12|3.96|we're just labeling every pixel um so
494.56|3.759|it's maybe not as informative as you
496.08|3.88|might like um and that could actually
498.319|2.961|lead to some problems for some
499.96|3.76|Downstream
501.28|4.599|applications so to overcome this people
503.72|3.919|have um also separately worked on this
505.879|4.16|newer problem called instance
507.639|4.64|segmentation um this also sometimes gets
510.039|5.0|called simultaneous detection and
512.279|4.841|segmentation so here the problem is um
515.039|3.521|again similar to before we have some set
517.12|4.279|of classes that we're trying to
518.56|5.959|recognize and given an input image we
521.399|5.801|want to Output um all instances of those
524.519|4.44|classes and for each instance we want to
527.2|4.84|segment out the pixels that belong to
528.959|4.641|that instance so here in this in this
532.04|3.44|input image there are actually three
533.6|3.96|different people um there's the two
535.48|4.2|parents and the kid and now in the
537.56|3.64|output we actually distinguish between
539.68|4.32|those different people in the input
541.2|4.199|image um which which those three people
544.0|3.72|are now shown in different colors to
545.399|3.841|indicate different instances and again
547.72|3.4|for each of those instances we're going
549.24|3.599|to label all of the pixels in the input
551.12|4.399|image that belong to that
552.839|5.041|instance so these two tasks of semantic
555.519|3.801|segmentation and instance segmentation
557.88|2.48|um people actually have worked on them a
559.32|3.199|little bit
560.36|4.919|separately so first we're going to talk
562.519|4.841|about some uh models for semantic
565.279|3.56|segmentation so remember this is the
567.36|2.919|task where you want to just label all
568.839|4.041|the pixels in the image and you don't
570.279|5.401|care about the
572.88|4.959|instances um so here the idea is
575.68|4.04|actually pretty simple uh given some
577.839|4.641|input image this is the the fun one with
579.72|4.48|the cows um we are going to take some
582.48|4.56|little patch of the input image and
584.2|6.319|extract this patch um that sort of gives
587.04|5.08|local information uh in the image then
590.519|2.841|we're going to take this patch and we're
592.12|3.36|going to feed it through some
593.36|3.64|convolutional neural network um this
595.48|4.359|could be any of the architectures that
597.0|5.12|we've talked about so far in the class
599.839|4.12|and now this uh convolutional neural
602.12|5.04|network will actually classify the
603.959|5.361|center pixel of the patch so this neural
607.16|3.96|network um is just doing classification
609.32|3.68|that's something we know how to do so
611.12|5.04|this thing is just going to say that the
613.0|5.6|center pixel of this patch actually is a
616.16|4.88|cow then we can imagine taking this
618.6|4.919|network that works on patches and labels
621.04|5.479|the center pixel and we just run it over
623.519|6.921|the entire image um and that will give
626.519|6.721|us a label for each pixel in the image
630.44|4.56|so um so this actually is a very
633.24|3.52|expensive operation right because now
635.0|3.48|there's many many patches in the image
636.76|3.319|and it would be super super expensive to
638.48|4.44|run this network independently for all
640.079|4.161|of them so in practice people um use the
642.92|3.039|same trick that we saw in object
644.24|4.399|detection where you'll run this thing
645.959|5.241|fully convolution and get all the
648.639|5.32|outputs uh for the whole image all at
651.2|4.96|once um but the problem here is that if
653.959|4.161|your convolutional network uh contains
656.16|4.88|any kind of down sampling either through
658.12|4.76|pooling or through convolutions then now
661.04|3.28|your output your output image will
662.88|4.12|actually have a smaller spatial size
664.32|4.04|than your input image um so that's
667.0|2.839|that's something that people need to
668.36|2.479|work around when they're using this type
669.839|3.281|of
670.839|3.761|approach so any any questions on this
673.12|3.48|kind of basic setup for semantic
674.6|4.96|segmentation
676.6|5.72|yeah like isn't there cases when the
679.56|5.0|batch of a cow doesn't allow to classify
682.32|5.4|as a cow for example and you have to
684.56|5.04|like take close like close patches to
687.72|4.28|region or something yeah the question is
689.6|3.52|whether whether that patch P patchwise
692.0|3.32|thing just doesn't give you enough
693.12|4.719|information in some cases um and that's
695.32|3.92|true so sometimes for these uh for these
697.839|3.521|networks people will actually have a
699.24|3.44|separate offline refinement stage where
701.36|2.88|they take this output and then feed it
702.68|3.2|to some kind of graphical model to clean
704.24|3.68|up the to clean up the output a little
705.88|4.12|bit so sometimes that can help boost
707.92|4.2|your performance a little bit but um
710.0|4.12|just this raw input output modal uh
712.12|4.399|setup tends to work pretty well just to
714.12|6.0|as something easy to
716.519|5.361|implement uh yeah um in practice uh what
720.12|5.6|is the receptive field that you need in
721.88|5.079|order to get decent results uh I'm not
725.72|3.799|in the question is how big of a
726.959|4.12|receptive field do you need um I'm not
729.519|3.521|sure I'm not sure exactly probably
731.079|4.961|pretty big maybe a couple hundred maybe
733.04|3.0|100 pixels that order of
736.44|4.6|magnitude so one extension that people
739.12|3.8|have used to this basic approach is this
741.04|4.4|idea of multiscale testing so actually
742.92|4.84|sometimes a single scale isn't enough so
745.44|4.24|here we're going to take our input image
747.76|4.639|and we'll actually resize it to multiple
749.68|4.44|different sizes um so this is sort of a
752.399|3.321|common trick that people use in computer
754.12|3.32|vision a lot it's called an image
755.72|5.2|pyramid you just take the same image and
757.44|5.04|you resize it to many different scales
760.92|2.919|and now for each of these scales we're
762.48|3.719|going to run it through a convolutional
763.839|4.841|neural network that is going to um
766.199|3.601|predict these pixel-wise labels for
768.68|3.32|these different images at these
769.8|3.56|different resolutions so another thing
772.0|3.079|to point out here along the lines of
773.36|2.839|your question that if each of these
775.079|3.281|networks actually has the same
776.199|3.401|architecture then each of these outputs
778.36|2.919|will have a different effective
779.6|3.039|receptive field in the input due to the
781.279|3.641|due to the image
782.639|4.2|pyramid so now that we've gotten these
784.92|4.32|differently sized pixel labels for the
786.839|4.881|image then we can take all of them and
789.24|4.599|res and just do some offline upsampling
791.72|4.84|to upsample those uh responses to the
793.839|4.36|same size as the input image so now
796.56|3.24|we've gotten our three outputs of
798.199|2.921|different sizes and we'll just upsample
799.8|4.159|them and stack
801.12|6.56|them and this paper um this is actually
803.959|5.161|a paper from Yan laon back in 2013 um so
807.68|4.0|they actually also have this separate
809.12|4.68|offline processing step where they uh do
811.68|5.44|this idea of a bottom up segmentation
813.8|5.36|using um right using these super pixel
817.12|3.959|methods so these are these sort of more
819.16|4.32|classic computer vision image processing
821.079|4.161|type methods that um actually look at
823.48|3.68|the differences between adjacent pixels
825.24|3.279|in images and then try to merge them
827.16|3.2|together to give you these coherent
828.519|4.361|regions where there are not much change
830.36|4.839|in image so then this method actually
832.88|3.959|takes uh sort of runs the image offline
835.199|3.481|through these other more traditional
836.839|5.641|image processing techniques to get
838.68|5.599|either set of super pixels or um a tree
842.48|4.24|saying which pixels ought to be merged
844.279|4.281|together in the image and they have this
846.72|3.44|somewhat complicated process for merging
848.56|2.88|all these different things together
850.16|2.88|because now we've gotten this sort of
851.44|3.639|low-level information saying which
853.04|3.88|pixels in the image um actually are
855.079|4.68|similar to each other based on sort of
856.92|4.039|color and and Edge information and we've
859.759|2.601|got these outputs of different
860.959|3.44|resolutions from the convolutional
862.36|3.52|neural networks telling us semantically
864.399|4.0|what the labels are at different points
865.88|4.0|in the image and they use they actually
868.399|3.161|explore a couple different ideas for
869.88|3.92|merging these things together to give
871.56|4.24|you your final output um so this
873.8|3.64|actually also answers one of addresses
875.8|3.36|one of the earlier questions about um
877.44|4.68|maybe the comp not being enough on its
879.16|5.239|own so using these external re uh super
882.12|4.24|pixel methods or um these segmentation
884.399|4.081|trees is another thing that sort of
886.36|5.96|gives you additional information about
888.48|3.84|um maybe larger context in the input
893.279|4.401|images so any any questions about this
897.839|4.36|model okay
900.0|3.88|so another another sort of cool idea
902.199|3.601|that people have used for semantic
903.88|4.519|segmentation and this is this idea of
905.8|4.279|iterative refinement so we actually saw
908.399|4.081|this um a few lectures ago when we
910.079|4.081|talked when we mentioned pose estimation
912.48|4.0|um but the idea is that we're going to
914.16|4.4|have an input image um here they've
916.48|3.24|separated out the three channels and
918.56|2.88|we're going to run that thing through
919.72|3.28|our favorite uh sort of convolutional
921.44|4.079|neural network to predict these low
923.0|4.88|resolution patches uh or rather to
925.519|4.281|predict this low resolution uh SE uh
927.88|3.8|segmentation of the image
929.8|4.2|and now we're going to take that output
931.68|4.279|from the CNN together with a down
934.0|4.0|sampled version of the original image
935.959|4.721|and we'll just repeat the process again
938.0|5.0|so this allows the network to sort of uh
940.68|4.44|in one increase its effective receptive
943.0|3.88|field of the output and also to perform
945.12|3.76|more processing on the on the input
946.88|6.439|image and then we can repeat this
948.88|6.319|process again so this is kind of cool so
953.319|3.76|if these three convolutional networks
955.199|4.241|actually share weights then this becomes
957.079|4.56|a recurrent convolutional Network where
959.44|4.44|it's sort of operating on the same input
961.639|3.921|over over through time but actually each
963.88|3.72|of these update steps is a whole
965.56|3.399|convolutional network um so it's
967.6|4.039|actually a very similar idea to
968.959|5.24|recurrent networks that we saw
971.639|6.32|previously um and the idea behind this
974.199|5.32|paper which uh was in I think icml 2014
977.959|3.401|is that if you actually do more
979.519|3.56|iterations of this same type of thing
981.36|4.479|then hopefully it allows the network to
983.079|5.56|sort of iter itera iteratively refine
985.839|5.401|its outputs so here if we have this raw
988.639|3.961|input image then after one iteration you
991.24|2.68|can see that actually there's quite a
992.6|3.64|bit of noise especially around the
993.92|4.039|boundaries of the objects but as we run
996.24|4.039|for two and three iterations through
997.959|3.961|this recurrent convolutional Network it
1000.279|3.68|actually allows the network to clean up
1001.92|4.12|a lot of that sort of low-level noise
1003.959|4.601|and produce much cleaner um much cleaner
1006.04|4.0|and nicer results so I thought that was
1008.56|3.519|quite quite a cool idea that sort of
1010.04|4.479|merging together these idea of recurrent
1012.079|4.041|networks and sharing weights over time
1014.519|5.12|with this idea of convolutional networks
1016.12|3.519|to process images
1020.639|4.2|so another um another very widely very
1023.319|3.681|well very very well-known paper for
1024.839|4.441|semantic segmentation is this one from
1027.0|4.919|Berkeley that was published at cvpr last
1029.28|4.159|year so here it's it's a very similar
1031.919|4.28|model as before where we're going to
1033.439|4.441|take an input image and run it through
1036.199|4.0|some number of convolutions and
1037.88|5.4|eventually extract some um some feature
1040.199|4.961|map for the pixels but in contrast uh
1043.28|4.32|the previous methods all relied on this
1045.16|4.28|sort of hardcoded upsampling to actually
1047.6|4.68|produce the final segmentation
1049.44|4.56|for theage but in thiser they proposed
1052.28|3.44|that well we're we're deep learning
1054.0|3.16|people we want to learn everything so
1055.72|4.0|we're going to learn the upsampling as
1057.16|4.84|part of the network um so their Network
1059.72|5.079|includes this uh at the last layer uh
1062.0|4.6|this learnable upsampling layer that um
1064.799|4.281|actually upsamples the feature map in a
1066.6|2.48|learnable
1069.2|5.2|way so yeah so they have this learnable
1071.44|4.88|upsampling map at the end and the way
1074.4|4.56|their model kind of looks is that they
1076.32|4.64|have this at the time it was an alexnet
1078.96|4.12|so they have their input image running
1080.96|4.52|through many phases of convolution and
1083.08|4.8|pooling and eventually they produce um
1085.48|4.4|at this pool five output they have quite
1087.88|3.6|a downsampled image uh quite a down
1089.88|3.799|sampled spatial size compared to the
1091.48|5.28|input image and then their learnable
1093.679|5.521|upsampling uh reup upsamples that back
1096.76|4.96|to the original size of the input
1099.2|4.0|image another cool feature of this paper
1101.72|5.24|was this idea of skip
1103.2|6.52|connections so um they actually don't
1106.96|4.599|use only just these pool 5 features they
1109.72|4.36|actually use the convolutional features
1111.559|4.961|from different layers in the network um
1114.08|4.32|which sort of exist at different scales
1116.52|4.08|so you can imagine that uh once you're
1118.4|3.639|in the pool four layer of alexnet that's
1120.6|4.16|actually a bigger feature map than the
1122.039|5.64|pool 5 and pool 3 is even bigger than
1124.76|4.96|pool 4 so the intuition is that these
1127.679|3.721|lower convolutional layers might
1129.72|3.439|actually help you capture finer grain
1131.4|4.159|structure in the input image since they
1133.159|3.721|have a smaller receptive field so they
1135.559|3.48|actually in practice take these
1136.88|4.12|different convolutional feature Maps and
1139.039|3.721|apply a separate learned upsampling to
1141.0|4.64|each of these feature maps and then
1142.76|5.24|combine them all to produce the final
1145.64|3.68|output and in their results they show
1148.0|2.84|that actually adding these skip
1149.32|4.839|connections tends to help a lot with
1150.84|5.839|these low-l details so
1154.159|5.321|um over here on the left these are the
1156.679|5.36|results that only use um these pool five
1159.48|4.679|outputs and you can see that uh it's
1162.039|3.961|sort of gotten the rough idea of a
1164.159|3.321|person on a bicycle but it's kind of
1166.0|3.24|Blobby and missing a lot of the fine
1167.48|3.12|details around the edges
1169.24|2.559|but then when you add in these skip
1170.6|3.12|connections from these lower
1171.799|3.721|convolutional layers that gives you a
1173.72|3.64|lot more fine grained information about
1175.52|4.8|the spatial locations of things in the
1177.36|5.04|image so that so adding those skip
1180.32|3.719|connections from the lower layers um
1182.4|3.84|really helps you clean up the boundaries
1184.039|3.681|in some cases for these these outputs
1186.24|4.72|question how do they classify like
1187.72|5.959|accuracy like so the question is how do
1190.96|4.199|I classify accuracy um I think the two
1193.679|3.161|metrics people typically use for this
1195.159|3.0|are either just classification um
1196.84|3.28|because you're classifying every pixel
1198.159|3.64|so you can use classification metrics
1200.12|4.559|also sometimes people use intersection
1201.799|5.601|over Union um so for each class you
1204.679|4.88|compute what is uh the region of the
1207.4|3.759|image that I predicted as that class and
1209.559|3.401|what was the re the ground truth region
1211.159|3.361|of the image that had that class and
1212.96|4.24|then compute an intersection of a union
1214.52|6.24|metric between those two um I'm not sure
1217.2|3.56|which which metric this paper used in
1220.799|4.681|particular so this idea of learnable
1223.2|4.12|upsampling is actually really cool and
1225.48|4.079|since uh since this paper has been
1227.32|5.28|applied in a lot of other contexts
1229.559|4.961|um CU we we've seen that we can down
1232.6|3.439|sample our feature maps in a variety of
1234.52|4.08|different ways but being able to
1236.039|4.441|upsample them inside the network um
1238.6|4.88|could actually be very useful and a very
1240.48|5.559|valuable thing to do so this sometimes
1243.48|4.48|gets called a deconvolution that's not a
1246.039|3.321|very good term so we we talk about that
1247.96|4.719|in a couple minutes but it's a very
1249.36|4.88|common term so just to just to recap um
1252.679|4.0|sort of when you're doing a normal sort
1254.24|5.12|of stride it uh stride one 3x3
1256.679|4.041|convolution um we we have this we have
1259.36|4.92|this picture that should be pretty
1260.72|6.48|familiar by now that given our 4x4 input
1264.28|5.56|we have some 3x3 filter and we plop that
1267.2|4.44|3x3 filter over part of the input
1269.84|4.04|compute a DOT product and that gives us
1271.64|4.56|one element of the output and now
1273.88|4.0|because this thing is stride one um to
1276.2|4.04|compute the next elements of the output
1277.88|4.159|we we move the filter over one slot in
1280.24|4.16|the input again compute a DOT product
1282.039|5.681|and that gives us our one element in the
1284.4|5.399|output um and now for stride two
1287.72|5.28|convolution uh it's it's a very similar
1289.799|5.281|type of idea where um now our output is
1293.0|5.039|going to be a down sampled version a 2X
1295.08|5.04|two output for our 4x4 input and again
1298.039|3.721|it's the same idea we take our filter we
1300.12|3.0|plop it down on the image compute a do
1301.76|3.44|product and that gives us one element of
1303.12|4.28|the output the only difference is that
1305.2|4.2|now um we Slide the convolutional filter
1307.4|3.84|over two slots in the input to compute
1309.4|4.24|one element to the
1311.24|3.64|output the deconvolutional layer
1313.64|3.84|actually does something a little bit
1314.88|4.679|different so here we want to take a low
1317.48|4.76|resolution input and produce a higher
1319.559|5.281|resolution output so this would be um
1322.24|4.28|maybe a 3X3 deconvolution with a stride
1324.84|4.88|of Two and a pad of
1326.52|5.279|one so here this is a little bit weird
1329.72|4.4|um you know in a normal convolution you
1331.799|4.561|imagine take you have your 3x3 filter
1334.12|4.08|and you take dot products on the input
1336.36|4.559|but here you want to imagine taking your
1338.2|5.359|3x3 filter and just copying it over to
1340.919|4.961|the output the only difference is that
1343.559|4.321|um the weights like this one scalar
1345.88|3.88|value of the weight in your input gives
1347.88|3.56|you a weight for that the you're going
1349.76|3.279|to reweight that filter when you stamp
1351.44|4.4|it down into the
1353.039|5.681|output and now when we stride this thing
1355.84|5.04|along we're going to step one step over
1358.72|4.28|in the input and two steps over in the
1360.88|4.679|output so now we're going to take the
1363.0|4.52|same the same uh learned convolutional
1365.559|5.521|filter and we're going to plop it down
1367.52|5.039|in the output um but now in the blue now
1371.08|3.479|so we're taking the same convolutional
1372.559|4.201|filter and we're popping it down twice
1374.559|4.72|in the output the difference being that
1376.76|5.12|the red box uh that that convolutional
1379.279|5.081|filter is weighted by this scalar value
1381.88|4.2|in the input and for the blue box that
1384.36|4.6|convolutional filter is weighted by the
1386.08|4.76|blue scaler value in the input um and
1388.96|2.839|where these where these regions overlap
1390.84|3.88|you just
1391.799|6.561|add so this kind of allows you to learn
1394.72|3.64|an upsampling um inside the
1398.64|4.44|network so if you remember from your
1401.48|4.88|from implementing convolutions on the
1403.08|4.839|assignment this idea of sort of um
1406.36|3.559|especially striding and adding on
1407.919|3.481|overlapping regions that should remind
1409.919|3.721|you of the backward pass for a normal
1411.4|5.399|convolution and it turns out that these
1413.64|5.279|are completely equivalent that um this
1416.799|3.641|deconvolution forward pass is exactly
1418.919|4.081|the same as the normal convolution
1420.44|4.64|backward pass and the normal and the
1423.0|5.039|deconvolution backward pass is the same
1425.08|5.12|as the normal convolution forward pass
1428.039|5.161|um so because of that actually the term
1430.2|4.88|deconvolution is maybe not not so great
1433.2|3.599|um and if you have a signal processing
1435.08|3.8|background you may have seen that
1436.799|4.48|deconvolution already has a very well-
1438.88|5.159|defined meaning and that is the inverse
1441.279|5.121|of convolution um so a deconvolution
1444.039|3.76|should undo a convolution operation
1446.4|4.2|which is quite different from what this
1447.799|5.0|is actually doing um so probably better
1450.6|4.439|names for this instead of deconvolution
1452.799|5.281|that you'll sometimes see would be um
1455.039|5.441|convolution transpose or I or backward
1458.08|5.599|strided convolution or fractionally
1460.48|4.96|strided convolution or or up convolution
1463.679|3.521|so I think um those are all kind of
1465.44|4.16|weird names I think deconvolution is
1467.2|3.76|popular just cuz it's easiest to say um
1469.6|2.4|even though it's maybe less Tech
1470.96|3.36|technically
1472.0|3.72|correct um although actually if you read
1474.32|5.359|papers you'll see that some people get
1475.72|6.16|angry about this um so uh it's more
1479.679|4.161|proper to say convolution transpose
1481.88|4.159|instead of deconvolution and this other
1483.84|4.0|paper um really wants it to be call it
1486.039|3.801|fractionally strided
1487.84|3.52|convolution so I think the I think the
1489.84|3.52|community is still deciding on the right
1491.36|3.559|terminology here but I I kind of agree
1493.36|4.24|with them that deconvolution is probably
1494.919|4.841|not very technically correct um and this
1497.6|4.079|this paper in particular has a whole
1499.76|3.84|they felt very strongly about this issue
1501.679|4.321|and they had a one-page index appendix
1503.6|4.24|to the paper actually explaining why why
1506.0|3.84|uh convolution transpose is the proper
1507.84|3.4|term so if you're interested then I
1509.84|3.68|would really recommend checking out that
1511.24|4.6|it's a pretty good explanation
1513.52|5.32|actually um so any any questions about
1515.84|5.24|this yeah idea how faster is
1518.84|5.199|this work is going to be Rel to the
1521.08|4.68|patch Bas uh the I think so the question
1524.039|3.561|is how much faster is this relative to a
1525.76|3.6|patch based thing um the answer is that
1527.6|3.76|in practice nobody even thinks to run
1529.36|4.199|this thing in a fully patch based mode
1531.36|4.039|cuz that would just be way way too slow
1533.559|3.24|so um actually all of the papers that
1535.399|3.88|I've seen do some kind of fully
1536.799|5.321|convolutional thing in one way or
1539.279|4.921|another um actually there there is sort
1542.12|4.439|of another trick instead of upsampling
1544.2|4.64|that people sometimes use and that is
1546.559|3.641|that um so suppose that your network um
1548.84|3.28|is actually going to down sample by a
1550.2|4.24|factor of four then one thing you can do
1552.12|4.159|is take your input image shift it by one
1554.44|4.239|pixel and now run it through the network
1556.279|3.88|again and now you get another output and
1558.679|3.841|you repeat this for sort of four
1560.159|4.201|different one pixel shifts of the input
1562.52|3.399|and now you've gotten four output maps
1564.36|3.64|and you can sort of interleave those to
1565.919|3.441|reconstruct an original input map so
1568.0|3.279|that's that's another trick that people
1569.36|3.96|sometimes use to get around that problem
1571.279|5.041|um but I think that this learnable
1573.32|3.0|upsampling is quite a bit
1576.919|4.64|cleaner Yeah question What alternative
1579.64|5.279|name for Decon volution do you
1581.559|5.36|prefer um so I think deconvolution is
1584.919|4.041|really nice it just rolls off the tongue
1586.919|3.76|um I think backwards stri I think um
1588.96|4.719|fractionally strided convolution is
1590.679|4.281|actually pretty cool um right I think
1593.679|3.24|it's the longest name but it's really
1594.96|4.0|descriptive right cuz normal with a
1596.919|3.76|normally with a strided convolution u
1598.96|3.68|you move X elements in the input and you
1600.679|4.0|move like you move one in the input and
1602.64|4.159|you move X in the output and here you're
1604.679|3.48|moving one half in the input you move
1606.799|3.081|one in the input which corresponds to
1608.159|5.321|moving one half in the output so that
1609.88|5.279|that captures this idea quite nicely um
1613.48|3.439|so I'm I'm not sure what I'll call it
1615.159|5.081|when when I use it in a paper um we'll
1616.919|3.321|have to see about that
1621.08|3.88|um but so despite the despite the the
1623.76|2.88|concerns about people calling it
1624.96|4.24|deconvolution like people just call it
1626.64|6.2|that anyway so there was this paper from
1629.2|6.16|iccv that takes this idea of um of this
1632.84|4.079|of this convolutional SL fractionally
1635.36|4.36|strided convolutional idea and sort of
1636.919|5.161|pushes it to the extreme so here they
1639.72|5.959|they um took what amounts to two entire
1642.08|5.16|vgg networks um flipped on their head so
1645.679|3.12|this is again the exact same model as
1647.24|4.039|before we want to input an image and
1648.799|5.321|output our pixelwise predictions uh for
1651.279|5.481|the semantic segmentation task but here
1654.12|5.559|we initialize with a vgg and over here
1656.76|5.36|is an upside down vgg um and it trains
1659.679|4.24|for 6 days on a Titan X so this thing is
1662.12|3.919|pretty slow um but they actually got
1663.919|5.281|really really good results and I think
1666.039|5.64|it's also a very beautiful
1669.2|3.92|figure so that's that's pretty much all
1671.679|3.041|that I have to say about semantic
1673.12|3.6|segmentation if there's any questions
1674.72|5.0|about that yeah is there a latch package
1676.72|5.12|for making no network figes how is that
1679.72|4.64|done uh the question is how how is this
1681.84|4.16|figure made um the answer is I I took a
1684.36|4.199|screenshot from their paper so I don't
1686.0|3.679|know um but you could try tensor flow we
1688.559|2.441|we saw in the last lecture that that
1689.679|3.961|lets you make make figures but they're
1691.0|2.64|not as nice as
1694.0|5.32|this yeah yeah how do I get a training
1696.84|4.88|data of this uh question is training
1699.32|5.56|data yeah so there exist data sets with
1701.72|4.88|this kind of thing where um uh I think
1704.88|3.919|like there's a common one is the Pascal
1706.6|3.919|segmentation data set so it just has
1708.799|3.081|ground truth um you have an image you
1710.519|3.321|have an image and they have every pixel
1711.88|4.24|labeled in the
1713.84|4.439|output yeah it's it's kind of expensive
1716.12|3.12|to get that data so the data sets tend
1718.279|3.601|to be a little
1719.24|4.72|smaller um but in practice um there's a
1721.88|3.36|famous uh interface called label me
1723.96|3.24|where you could upload an image and then
1725.24|3.439|sort of draw a contour around the image
1727.2|3.4|or around different regions of the image
1728.679|4.201|and then that you can convert those um
1730.6|4.12|Contours into sort of these segmentation
1732.88|7.12|masks so that's how you tend to label
1734.72|5.28|these things in a UI in a UI way
1740.159|3.841|um if no other questions then I think
1741.88|4.36|we'll move on to instance
1744.0|4.159|segmentation so just to recap instance
1746.24|3.4|segmentation is this generalization
1748.159|3.281|where where we not only want to label
1749.64|3.68|the pixels of the image but we also want
1751.44|4.28|to distinguish inst uh distinguish
1753.32|4.16|instances so we're going to detect the
1755.72|3.439|different instances of our classes and
1757.48|3.28|for each one we want to label the pixels
1759.159|4.561|of that
1760.76|4.88|instance so you'll these this um
1763.72|3.4|actually these models end up looking a
1765.64|4.32|lot like the detection models that we
1767.12|4.439|talked about a few lectures ago so um
1769.96|4.04|one of the earliest papers that I know
1771.559|3.801|of that so this is actually um I should
1774.0|3.919|also point out that this is I think a
1775.36|4.559|much more recent task that um this idea
1777.919|4.281|of semantic segmentation has been used
1779.919|3.76|in computer vision for a long long time
1782.2|3.319|but I think this idea of instance
1783.679|3.761|segmentation has gotten a lot more
1785.519|5.441|popular especially in the last couple
1787.44|5.68|years so this paper from 2014 um sort of
1790.96|4.76|took this they they call it simultaneous
1793.12|5.159|detection and segmentation or SDS that's
1795.72|4.319|kind of a nice name um and this is
1798.279|4.041|actually very similar to the rcnn model
1800.039|5.081|that we saw for detection so here we're
1802.32|5.0|going to take an input image um and if
1805.12|4.799|you'll remember in R CNN we relied on
1807.32|4.28|these external region proposals that can
1809.919|4.281|are these sort of offline computer
1811.6|4.28|vision low-level thing that uh compute
1814.2|3.68|predictions of where it thinks objects
1815.88|4.279|in the image might be located well it
1817.88|4.639|turns out that there's other methods for
1820.159|3.721|um proposing segments instead of boxes
1822.519|2.961|so we just download one of those
1823.88|4.32|existing segment proposal methods and
1825.48|4.799|use that instead
1828.2|4.12|now for each of these segments we can
1830.279|3.961|for each of these proposed segments we
1832.32|4.12|can extract a bounding Box by just
1834.24|4.36|fitting a tight box to the segment and
1836.44|5.0|then run crop out that chunk of the
1838.6|5.12|input image and run it through a box CNN
1841.44|5.64|to extract features for that
1843.72|6.12|box then in parallel we'll um run
1847.08|4.76|through a region CNN so here again we
1849.84|4.64|take that relevant uh that Chunk from
1851.84|4.799|the input image um and crop it out but
1854.48|4.12|here because we actually have this
1856.639|3.841|proposal for the segment then we're
1858.6|4.799|going to mask out the background region
1860.48|4.559|using the mean color of the data set um
1863.399|3.361|so this is kind of a hack that lets you
1865.039|4.12|take these kind of weird shaped inputs
1866.76|4.039|and feed it into a CNN you just mask out
1869.159|3.88|the the background part with a with a
1870.799|3.961|flat color so then they take these
1873.039|4.041|masked inputs and run them through a
1874.76|4.279|separate region CNN so now we've gotten
1877.08|4.36|two different feature vectors one sort
1879.039|4.081|of incorporating the whole box and one
1881.44|4.0|incorporating only the the proposed
1883.12|4.159|foreground pixels we concatenate these
1885.44|4.199|things and then just like an rcnn we
1887.279|5.24|make a classific a to decide um what
1889.639|5.081|class actually should this segment be um
1892.519|5.12|and then they also have this uh region
1894.72|4.88|refinement step where um we want to
1897.639|4.561|refine the proposed region just a little
1899.6|4.199|bit so if you I don't know how well you
1902.2|3.359|remember the rcnn framework but this is
1903.799|4.321|actually very similar to rcnn just
1905.559|5.681|applied to this uh instance simultaneous
1908.12|5.96|detection and segmentation
1911.24|4.76|task so for this idea for this region
1914.08|3.559|refinement step um there's actually a
1916.0|5.399|follow-up paper that proposes a pretty
1917.639|5.441|nice way to do it so here um this is you
1921.399|4.0|know follow-up paper from the same Folks
1923.08|4.24|at Berkeley the the following conference
1925.399|5.0|um and here we want to take this this
1927.32|5.12|input which is um this proposed segment
1930.399|4.841|M this proposed uh segment and we want
1932.44|4.479|to clean it up somehow so we're actually
1935.24|3.64|going to take a very similar approach a
1936.919|4.521|very similar type multiscale approach
1938.88|5.36|that we saw in the um in the semantic
1941.44|5.119|segmentation model a while ago so here
1944.24|4.12|we're going to take out our image um
1946.559|3.761|crop out the crop out the box
1948.36|4.679|corresponding to that segment and then
1950.32|4.599|pass it through an alexnet and we're
1953.039|3.161|going to extract convolutional features
1954.919|3.64|from several different layers of that
1956.2|4.04|alexnet for each of those feature Maps
1958.559|5.201|we'll upsample them and combine them
1960.24|6.399|together and now we'll produce uh this
1963.76|4.96|this figure this proposed figure ground
1966.639|4.0|segmentation so this this is actually
1968.72|4.4|kind of a funny output but it's it's
1970.639|4.241|really easy to predict the idea is that
1973.12|4.039|this this output image we're just going
1974.88|4.039|to do a logistic classifier inside each
1977.159|3.721|independent pixel
1978.919|3.48|um so given these features we just have
1980.88|3.799|a whole bunch of independent logistic
1982.399|4.52|classifiers that are predicting how much
1984.679|3.921|each pixel of this output is likely to
1986.919|4.521|be in the foreground or in the
1988.6|5.16|background um and they show that this
1991.44|3.959|this type of multiscale refinement Step
1993.76|3.159|actually cleans up the outputs of the
1995.399|2.321|previous system and gives quite quite
1996.919|2.64|nice
1997.72|5.959|results
1999.559|5.72|question yes in the upsample Box are you
2003.679|3.201|deconvolution I mean what are you doing
2005.279|3.24|there you're just copying the values or
2006.88|3.88|you're applying a
2008.519|4.4|um I think in this paper this was not a
2010.76|3.879|fractionally strided convolution I think
2012.919|3.48|it was instead some kind of a fixed
2014.639|3.441|upsampling like a bilinear interpolation
2016.399|3.321|or something like that um or maybe even
2018.08|3.959|a nearest neighbor just something fixed
2019.72|3.28|not learnable but I could be wrong um
2022.039|4.561|but you could definitely imagine
2023.0|3.6|swapping in some learnable thing there
2027.279|5.4|too okay so this this um this actually
2030.08|5.079|is very similar to to rcnn but in the
2032.679|4.24|detection lecture we saw that rcnn was
2035.159|5.161|just the start of the story there's all
2036.919|5.801|these faster versions right so it turns
2040.32|4.839|out that um a similar intuition from
2042.72|4.28|faster rcnn has actually been applied to
2045.159|4.561|this instant segmentation problem as
2047.0|5.079|well so this is work from Microsoft that
2049.72|4.08|act and this model actually won the Coco
2052.079|4.681|instance segmentation challenge this
2053.8|4.92|year um so they they took their Giant
2056.76|3.52|resnet and they stuck this model on top
2058.72|4.04|of it and they and they crushed everyone
2060.28|5.599|else in the Coco instance segmentation
2062.76|5.319|challenge um so this this actually is
2065.879|4.52|very similar to faster rcnn so we're
2068.079|5.28|going to take our input image and just
2070.399|4.321|like in Fast and faster rcnn um our
2073.359|3.201|input image will now be pretty high
2074.72|3.76|resolution and we'll get this giant
2076.56|6.44|convolutional feature map over our high
2078.48|6.56|resolution image um then from this high
2083.0|4.639|resolution image we're actually going to
2085.04|4.44|propose our own region proposals um in
2087.639|4.2|the previous method we relied on these
2089.48|3.639|external segment proposals but here
2091.839|4.361|we're just going to learn our own region
2093.119|4.881|proposals just like faster rcnn so here
2096.2|3.6|we just stick a couple a couple extra
2098.0|3.68|convolutional layers on top of our
2099.8|3.96|convolutional feature map and each one
2101.68|4.36|of those is going to predict um several
2103.76|4.04|regions of interest in the image that um
2106.04|4.12|using this idea of anchor boxes that we
2107.8|4.96|saw in the detection
2110.16|4.08|work um the difference is that now once
2112.76|3.28|we have this region these region
2114.24|3.48|proposals we're going to segment them
2116.04|4.079|out using a very similar approach that
2117.72|4.6|we just saw on the last slide so for
2120.119|4.48|each of these proposed regions we're
2122.32|4.799|going to use this Roi what do they call
2124.599|5.0|it Roi warping or pooling and squish
2127.119|3.881|them all down to a fixed Square size and
2129.599|3.401|then run each of them through a
2131.0|3.839|convolutional neural network to produce
2133.0|4.16|these coarse figure ground segmentation
2134.839|5.441|masks like we just saw in the previous
2137.16|4.48|uh in the previous slide so now at this
2140.28|3.16|point we've gotten our image we've
2141.64|3.959|gotten a bunch of region proposals and
2143.44|4.28|now for each region proposal we have a
2145.599|4.361|rough idea of which part of that box is
2147.72|4.2|foreground and which part is
2149.96|4.0|background now we're going to take this
2151.92|3.56|idea of masking so now that we've
2153.96|3.159|predicted the foreground background for
2155.48|3.72|each of these segments we're going to
2157.119|3.881|mask out the the predicted background um
2159.2|4.28|and only keep the pixels from the
2161.0|4.079|predicted foreground um and pass those
2163.48|3.879|through another couple layers to
2165.079|4.361|actually classify that classify that
2167.359|5.48|segment as our different object
2169.44|5.12|categories so this is um and then this
2172.839|4.441|entire thing can just be learned jointly
2174.56|4.68|end to end um with the idea that we've
2177.28|3.88|sort of got these three semantically
2179.24|3.72|interpretable outputs in intermediate
2181.16|3.28|layers of our Network and each of them
2182.96|4.119|we can just supervise with ground truth
2184.44|4.28|data so for these regions of Interest we
2187.079|3.601|know where the ground truth SE objects
2188.72|4.119|are in the object in the image so we can
2190.68|4.24|provide supervision on those outputs for
2192.839|4.0|these segmentation masks we know what
2194.92|4.6|the true foreground and background are
2196.839|4.48|so we can give supervision there and um
2199.52|3.4|we we obviously know the classes of
2201.319|3.04|those different segments so we just
2202.92|3.96|provide supervision at different layers
2204.359|3.921|of these Network um and try to trade off
2206.88|3.52|all of those different loss terms and
2208.28|3.64|hopefully get the thing to converge but
2210.4|3.48|this actually was trained end to end and
2211.92|5.439|they fine-tune into resnet and it works
2213.88|4.479|really really well so here is the the
2217.359|3.161|the
2218.359|4.0|the results figure that we have to show
2220.52|4.28|um so these results are at least to me
2222.359|4.081|really really impressive so for example
2224.8|4.279|this input image has all these different
2226.44|4.679|people um sitting in this room and the
2229.079|3.481|predicted outputs do a really good job
2231.119|3.041|of separating out all those different
2232.56|3.039|people even though they overlap and
2234.16|4.04|there's a lot of them and they're very
2235.599|4.401|close um same with these cars maybe that
2238.2|3.0|one's a little easier but especially
2240.0|3.079|this this people one I was pretty
2241.2|4.159|impressed by but you can see it's not
2243.079|4.441|perfect so this potted plant it thought
2245.359|4.041|was blob than it really was and it conf
2247.52|3.96|fused this chair on the right for a
2249.4|3.6|person and it missed a person there um
2251.48|3.2|but overall these results are are very
2253.0|3.24|very impressive and like I said this
2254.68|4.159|model won the Coco segmentation
2256.24|2.599|challenge this
2259.079|4.721|year so the the overview of segmentation
2262.4|3.88|um is that we've got these these two
2263.8|4.559|different tasks um semantic segmentation
2266.28|3.799|and instance segmentation um for
2268.359|4.76|semantic segmentation it's very common
2270.079|5.321|to use this um con this Con Decon
2273.119|3.841|approach um oh and then for instance
2275.4|3.32|segmentation you end up with these
2276.96|2.68|Pipelines that look more similar to
2278.72|3.8|object
2279.64|4.439|detection so if there's any uh any last
2282.52|4.16|minute questions about segmentation I
2284.079|6.361|can try to answer those
2286.68|6.88|now nope super clear I guess so we're
2290.44|4.879|going to move on to another another um
2293.56|3.84|another pretty cool exciting topic and
2295.319|3.321|that's attention models so this is
2297.4|4.199|something that I think has gotten a lot
2298.64|5.959|of attention in the last year in the
2301.599|4.48|community um so uh as a kind of a case
2304.599|4.081|study we're going to talk about the
2306.079|5.28|model from I don't the citation here
2308.68|4.12|okay but we're as a as a as a as a sort
2311.359|3.041|of a case study we're going to talk
2312.8|3.4|about the idea of attention as applied
2314.4|3.439|to image captioning so I think this
2316.2|3.8|model was previewed uh in the recurrent
2317.839|4.721|networks lecture but we want to I want
2320.0|4.4|to step into a lot more detail here but
2322.56|3.4|first as a recap just so we're on the
2324.4|3.6|same page um hopefully you know how
2325.96|4.639|image captioning works by now since the
2328.0|4.28|homework is due in a few hours um but
2330.599|3.641|we're going to take our input image and
2332.28|4.2|run it through a convolutional net and
2334.24|3.879|get some features those features will be
2336.48|4.0|used maybe to initial ize the first
2338.119|4.48|hidden state of our recurrent Network
2340.48|3.839|then our our start token or our first
2342.599|3.321|word together with that hidden State
2344.319|4.401|we're going to produce this distribution
2345.92|4.199|over words in our vocabulary then um to
2348.72|3.399|generate a word we'll just sample from
2350.119|3.441|that distribution um and we'll just sort
2352.119|3.0|of repeat this process over time to
2353.56|4.24|generate
2355.119|4.281|captions um the problem here is that
2357.8|3.6|this network only sort of gets one
2359.4|3.56|chance to look at the input image and
2361.4|4.8|when it does it's looking at the entire
2362.96|5.44|input image all at once um and it might
2366.2|4.32|be cooler if it actually had the ability
2368.4|4.24|to one um look at the input image
2370.52|3.68|multiple times and also if it could
2372.64|3.84|focus on different parts of the input
2374.2|6.399|image as it
2376.48|6.04|ran so um one a pretty cool paper that
2380.599|4.161|came out last year was this one called
2382.52|4.319|show attendant tell um the original was
2384.76|4.72|show and tell so they added the attend
2386.839|4.401|part um and the idea is is pretty
2389.48|3.639|straightforward so we're going to take
2391.24|3.92|our input image and we're still going to
2393.119|3.681|run it through a convolutional network
2395.16|4.0|but instead of extracting the features
2396.8|3.84|from the fully connected layer instead
2399.16|4.0|we're going to pull features from one of
2400.64|4.04|the convol earlier convolutional layers
2403.16|3.52|and that's going to give us this grid of
2404.68|4.52|features um rather than a single feature
2406.68|4.6|Vector so because these are coming from
2409.2|4.2|convolutional layers you can imagine
2411.28|3.88|that maybe the upper left hand this you
2413.4|4.28|can think of this as a 2d spatial grid
2415.16|4.52|of features and inside each grid each
2417.68|4.399|point in the grid gives you features
2419.68|5.76|corresponding to some part of the input
2422.079|5.0|image so now again we'll use these uh
2425.44|3.919|these features to initialize the hidden
2427.079|4.681|state of our Network in some way and now
2429.359|4.201|here's where things get different um now
2431.76|4.2|we're going to use our hidden state to
2433.56|4.48|compute not a distribution over words
2435.96|4.0|but instead a distribution over these
2438.04|4.64|different positions in in our
2439.96|4.639|convolutional feature map so again this
2442.68|3.8|is this would probably be implemented
2444.599|3.76|with maybe a fully connect with maybe um
2446.48|4.2|an apine layer or two and then some
2448.359|3.72|softmax to give you a distribution but
2450.68|3.159|we just end up with this um
2452.079|3.681|l-dimensional Vector giving us a
2453.839|5.401|probability distribution over these
2455.76|3.48|different locations in our inputs
2459.64|3.52|and now we take this probability
2461.119|4.521|distribution and actually use it to re
2463.16|4.0|to weight to give a weighted sum of
2465.64|4.8|those feature vectors at the different
2467.16|4.64|points in our in our grid so once we
2470.44|4.159|take this weighted combination of
2471.8|6.4|features that takes our grid and
2474.599|6.121|summarizes it down to a single Vector um
2478.2|5.72|they and this this sort of Z Vector um
2480.72|5.76|summarizes the input image in some way
2483.92|4.56|and due to the different types uh due to
2486.48|3.96|due to this probability distribution it
2488.48|4.0|gives the network the capacity to focus
2490.44|4.679|on different parts of the image as it
2492.48|4.68|goes so now this this weighted Vector
2495.119|4.321|that's produced from the input features
2497.16|4.48|gets fed together with the first word
2499.44|3.639|and now um when we make our recurrence
2501.64|3.52|in our recurrent Network we actually
2503.079|4.641|have three inputs we have our previous
2505.16|4.88|hidden State we have this um attended
2507.72|4.359|feature vector and we have this first
2510.04|4.88|word and now all of these together are
2512.079|4.28|used to produce our new hidden State um
2514.92|3.36|and now from this hidden State we're
2516.359|4.161|actually going to produce two outputs
2518.28|4.12|we're going to produce another uh a new
2520.52|3.64|distribution over the locations in our
2522.4|3.4|input image and we're also going to
2524.16|3.36|produce our standard distribution over
2525.8|3.16|words so these would probably be
2527.52|3.16|implemented as just a couple of fully
2528.96|4.76|connected layers on top of the Hidden
2530.68|4.919|State and now this process repeats so
2533.72|4.119|given this new probability distribution
2535.599|4.401|we go back to the input feature grid and
2537.839|5.24|compute a new uh summarization Vector
2540.0|4.28|for the image take the take that Vector
2543.079|3.401|together with the next word in the
2544.28|4.839|sentence to compute the new hidden State
2546.48|2.639|um produce
2550.4|4.28|okay so that that spoiled it a little
2551.72|4.68|bit but um but then we'll then we'll
2554.68|3.879|actually repeat this process over time
2556.4|3.959|to generate our captions Yeah question
2558.559|4.161|can you explain one more time how the
2560.359|5.801|features the L
2562.72|5.24|features take aition networ and then you
2566.16|4.04|just take the out
2567.96|4.359|filter so the the question is how where
2570.2|3.919|does this feature grid come from um and
2572.319|3.8|the answer is um when you're when you're
2574.119|4.841|doing an alexnet for example you have uh
2576.119|4.921|com one com 2 3 con 4 con 5 and by the
2578.96|5.0|time you get to con 5 the shape of that
2581.04|6.68|tensor is now something like 7x 7 by
2583.96|6.56|512 um so that corresponds to a 7x7
2587.72|5.08|spatial grid over the input and in each
2590.52|4.44|uh grid position that's a 512
2592.8|3.08|dimensional feature Vector so those are
2594.96|3.399|just pulled out of one of the
2595.88|5.84|convolutional layers in the
2598.359|5.681|network Yeah question so the probability
2601.72|5.52|distribution U is for the distribution
2604.04|4.799|of classes or um
2607.24|3.76|like the distrib of
2608.839|4.24|words so the question is about these
2611.0|3.76|probability distributions so we're
2613.079|3.52|actually um producing two different
2614.76|4.48|probability distributions at every time
2616.599|5.081|step um the first one are these D
2619.24|3.839|vectors in blue so those are probability
2621.68|3.32|distribution over words in your
2623.079|4.52|vocabulary like we did in normal image
2625.0|4.28|captioning and also at every time step
2627.599|4.161|we'll produce a second probability
2629.28|4.92|distribution over these locations in the
2631.76|4.12|in the input image um that are telling
2634.2|4.32|us where we want to look on the next
2635.88|4.36|time step um this is actually quite uh
2638.52|4.559|right so it's you're just tting two
2640.24|4.56|outputs and then as a quiz I wanted to
2643.079|3.921|see like what framework you wanted to
2644.8|3.96|use to implement this um and we talked
2647.0|3.839|about maybe how rnns would be a good
2648.76|5.359|choice for Theo or tensor flow and I
2650.839|3.28|think this qualifies as a crazy
2654.359|4.601|RNN so um I wanted to maybe talk in a
2657.64|2.84|little bit more detail how these
2658.96|4.28|attention Vector how these um
2660.48|4.599|summarization vectors get produced so
2663.24|3.48|this paper actually talks about uh two
2665.079|3.04|different methods for generating these
2666.72|4.0|vectors
2668.119|4.48|so the idea as we saw on the last slide
2670.72|3.92|is that um our we'll take our input
2672.599|3.441|image and get this grid of features um
2674.64|3.8|coming from one of the convolutional
2676.04|4.44|layers in our Network um and then for
2678.44|3.76|each time step our network will produce
2680.48|3.56|this probability distribution over
2682.2|3.52|locations so this would be a fully
2684.04|4.2|connected layer and then a softmax to to
2685.72|4.28|normalize it and now the idea is that we
2688.24|3.68|want to take these um this grid of
2690.0|4.0|feature vectors together with these
2691.92|3.88|probability distributions and produce a
2694.0|5.4|single d-dimensional Vector that
2695.8|4.96|summarizes that input image and there's
2699.4|3.6|the paper actually explores two
2700.76|4.48|different ways of solving this problem
2703.0|5.24|so the easy way is to use what's what
2705.24|5.319|they call soft attention so here um our
2708.24|4.4|D dimensional Vector Z will just be a
2710.559|4.441|weighted sum of all the elements in the
2712.64|5.199|grid where each Vector is just weighted
2715.0|5.079|by its prob by um its predicted
2717.839|4.48|probability um this is actually very
2720.079|3.641|easy to implement um it's sort of a nice
2722.319|4.961|uh it's just another layer in a neural
2723.72|5.48|network um and these gradients like D
2727.28|3.079|the derivative of this context Vector
2729.2|3.399|with respect to our predicted
2730.359|4.801|probabilities p is quite nice and easy
2732.599|4.161|to compute so we can actually train this
2735.16|4.28|thing um just using normal gradient
2736.76|2.68|descent and back
2739.64|4.76|propagation um but they actually explore
2742.48|3.32|another another option for computing
2744.4|3.84|this feature vector and that's something
2745.8|4.6|called heart attention so instead of
2748.24|4.359|having this weighted sum um we might
2750.4|5.32|want to select just a single element of
2752.599|5.361|that of that grid to attend to um so you
2755.72|4.879|might imag so once simple thing to do is
2757.96|4.44|just to um pick the element of the grid
2760.599|4.361|with the highest probability and just
2762.4|5.88|pull out the the feature Vector uh
2764.96|5.68|corresponding to that argmax uh position
2768.28|4.799|um the problem is now if you think about
2770.64|4.52|in this argmax in this argmax case if
2773.079|3.801|you think about this derivative um the
2775.16|4.52|derivative of Z with respect to our
2776.88|4.199|distribution P um it turns out that this
2779.68|4.36|is not very friendly for back
2781.079|6.961|propagation anymore so imagine um in an
2784.04|5.64|argmax case um if suppos that a that PA
2788.04|4.2|were actually the largest element in our
2789.68|5.439|input and now what happens if we change
2792.24|2.879|PA just a little
2795.2|5.159|bit so if right so if PA is the argmax
2798.599|3.881|and then we just jiggle the probability
2800.359|4.48|distribution just a little bit then PA
2802.48|4.8|will still be the argmax so we'll still
2804.839|4.041|select the same Vector from the input
2807.28|4.079|which means that actually um the
2808.88|4.32|derivative of this Vector Z with respect
2811.359|4.76|to our predicted probabilities is going
2813.2|5.0|to be zero almost everywhere so that's
2816.119|3.72|that's very bad um we now we can't
2818.2|4.159|really use back propagation anymore to
2819.839|4.121|train this thing so it turns out that
2822.359|3.521|they propose another method based on
2823.96|3.8|reinforcement learning to actually train
2825.88|4.92|the model in this context where you want
2827.76|5.68|to select a single element of the input
2830.8|3.96|um but that's a little bit more complex
2833.44|3.36|so we're not going to talk about that in
2834.76|3.2|this lecture but just be aware that that
2836.8|3.24|is something that you'll see this
2837.96|5.48|difference between soft attention um and
2840.04|3.4|hard attention where you actually pick
2844.0|5.24|one so now we can look at some some
2846.599|4.48|pretty results from this model so since
2849.24|3.599|we're actually generating a probability
2851.079|4.24|distribution over grid locations at
2852.839|4.48|every time step um we can visualize that
2855.319|3.841|probability distribution as we generate
2857.319|4.201|each word of our of our generated
2859.16|5.36|caption so then for this input image
2861.52|4.72|that shows a bird um both they they both
2864.52|3.799|their heart attention model and their
2866.24|4.079|soft attention model in this case both
2868.319|5.161|produce the caption a bird flying over a
2870.319|5.441|body of water period um and for these
2873.48|4.0|two models they've visualized what that
2875.76|3.72|probability distribution looks like for
2877.48|4.2|these two different models so the top
2879.48|3.96|shows the soft attention um so you can
2881.68|3.2|see that it's sort of diffuse since it's
2883.44|3.8|averaging probabilities from every
2884.88|3.959|location in the image and in the bottom
2887.24|4.44|um it's just showing the one single
2888.839|5.201|element that it pulled out and it's this
2891.68|4.6|these actually have um quite nice
2894.04|4.24|semantic interpretable meanings so you
2896.28|3.48|can see that when the model is um
2898.28|3.4|especially the soft attention on the top
2899.76|3.28|I think gives very nice results that
2901.68|3.0|when it's talking about the bird and
2903.04|3.279|talking about flying it sort of focuses
2904.68|3.36|right on the bird and then when it's
2906.319|4.361|talking about water it kind of focuses
2908.04|4.16|on everything else so um another thing
2910.68|3.399|to point out is that it didn't receive
2912.2|3.399|any supervision at training time for
2914.079|4.081|which parts of the image it should be
2915.599|5.081|attending to um it just made up its own
2918.16|4.28|mind to attend to those parts based on
2920.68|3.6|whatever would um help it caption things
2922.44|3.56|better and it's pretty cool that we
2924.28|4.44|actually get these interpretable results
2926.0|5.119|just out of this captioning
2928.72|4.52|task um we can look at a couple a couple
2931.119|3.921|other results cuz they're fun so we can
2933.24|3.839|see that when we have the dog throwing
2935.04|4.279|what a woman throwing a frisbee in park
2937.079|4.04|it focuses on the Frisbee um talking
2939.319|4.081|about the dog it learns to recognize the
2941.119|4.121|dog um and especially interesting is
2943.4|3.8|this guy in the bottom right when it
2945.24|3.44|generates the word trees um it's
2947.2|4.159|actually focusing on all the stuff in
2948.68|4.439|the background and not just the giraffe
2951.359|3.44|um and again these are just coming out
2953.119|5.081|with no supervision all just based on
2954.799|3.401|the captioning task
2960.799|3.601|question yeah so the question is what
2962.839|5.081|are the when would you prefer hard
2964.4|5.12|versus soft attention so um there's I
2967.92|3.32|think sort of two motivations that
2969.52|4.039|people usually give for wanting to even
2971.24|4.24|do attention at all in the first place
2973.559|3.8|um one of those is just to give nice
2975.48|3.92|interpretable outputs and I think you
2977.359|4.76|get nice interpretable outputs in in
2979.4|4.08|either case um at least theoretically um
2982.119|3.281|maybe they're hard attention figure
2983.48|3.599|wasn't quite as pretty but the other
2985.4|3.919|motivation for using attention is to
2987.079|3.441|relieve computational burden um
2989.319|3.561|especially when you have a very very
2990.52|4.48|large input um it might be
2992.88|3.919|computationally uh expensive to actually
2995.0|3.76|process that whole input on every time
2996.799|4.04|step and it might be more efficient
2998.76|3.92|computationally if we can just focus on
3000.839|4.0|one part of the input at each time step
3002.68|4.8|and only process a small subset per time
3004.839|4.24|step so with soft attention because
3007.48|3.28|we're doing this sort of averaging over
3009.079|3.401|all positions we don't get any
3010.76|3.64|computational savings we're still
3012.48|3.839|processing the whole input on every time
3014.4|3.919|step but with heart attention we
3016.319|4.361|actually do get a computational savings
3018.319|4.52|since we're explicitly picking out some
3020.68|3.96|small subset of the input so I think
3022.839|3.321|that's the that's the big uh benefit
3024.64|2.8|also heart attention takes reinforcement
3026.16|3.88|learning and that's fancier and makes
3027.44|5.44|you look smarter so that's kind of cool
3030.04|6.039|um question can you give some intuition
3032.88|5.08|for how the network is learning these
3036.079|3.641|when it never knows like which there's
3037.96|3.76|no techn it doesn't know which pixels
3039.72|4.92|are ref first or whatever yeah so the
3041.72|4.56|question is how does this work at all um
3044.64|3.28|and I think the answer is it's really
3046.28|4.0|learning sort of correlation structures
3047.92|4.52|in the input um right that it's seen
3050.28|4.6|many examples of images with dogs and
3052.44|3.84|it's SE many sentences with dogs but for
3054.88|2.719|those different images with dogs the
3056.28|3.64|dogs tend to appear in different
3057.599|4.081|positions in the input um and I guess it
3059.92|4.0|turns out through the optimization Pro
3061.68|4.04|procedure that actually um putting more
3063.92|3.72|weight on the places where the dog
3065.72|4.56|actually exists uh actually helps the
3067.64|4.199|captioning task in some way so I don't
3070.28|4.079|think there's a very a very good answer
3071.839|4.681|it just it just happens to work um also
3074.359|4.0|I'm not so obviously these are pictures
3076.52|4.68|from a figure or these are figures from
3078.359|4.681|a paper um not like random results so
3081.2|4.84|I'm not sure how good it works on random
3083.04|3.0|images
3087.4|4.159|um but another thing to to Really point
3089.839|4.041|out about this especially this model of
3091.559|4.121|soft attention is that um it's sort of
3093.88|5.56|constrained to this fixed grid from the
3095.68|5.48|convolutional feature map um that these
3099.44|3.28|like we we're getting these nice diffuse
3101.16|3.32|looking things but those are just sort
3102.72|3.8|of like blurring out this um this
3104.48|3.639|distribution and the model does not
3106.52|3.76|really have the capacity to look at
3108.119|3.841|arbitrary regions of the input it it's
3110.28|3.92|only allowed to look at these uh fixed
3111.96|2.24|grid
3115.16|4.24|regions um I should also point out that
3117.76|4.2|this idea of soft attention was not
3119.4|4.84|really introduced in this paper um I I
3121.96|4.56|think the first paper that really had
3124.24|4.559|this notion of soft attention um came
3126.52|4.52|from machine translation so here it's a
3128.799|4.32|similar motivation that we want to take
3131.04|3.759|some input sentence here in Spanish and
3133.119|4.321|then produce an output sentence in
3134.799|4.081|English and this would be done with a
3137.44|3.8|recurrent neural network sequence to
3138.88|4.4|sequence model where we would first um
3141.24|4.24|read in our input sentence with a
3143.28|4.4|recurrent Network and then generate an
3145.48|5.24|output sequence very similar that as we
3147.68|4.639|would in captioning but um in this paper
3150.72|3.359|they wanted to actually have attention
3152.319|4.48|over the input sentence as they
3154.079|4.52|generated their output sentence so the
3156.799|4.32|me the exact mechanism is a little bit
3158.599|4.401|different but the intuition is the same
3161.119|4.601|that now when we've generate this first
3163.0|5.04|word my we want to compute a probability
3165.72|4.04|distribution not over regions in an
3168.04|4.079|image but instead over words in the
3169.76|3.88|input sentence so here we're going to
3172.119|3.361|get a distribution that hopefully will
3173.64|3.679|focus on this first word in the Spanish
3175.48|3.24|sentence and then we'll take some
3177.319|2.881|features from each word and then
3178.72|4.04|reweight them and feed them back into
3180.2|4.28|the RNN at the next time step um and
3182.76|4.48|this process would repeat at every time
3184.48|4.56|step of the of the network so this idea
3187.24|4.079|of soft attention um is very easily
3189.04|4.039|applicable not only to image captioning
3191.319|3.8|but also to machine
3193.079|4.321|translation question how do you do it
3195.119|3.401|for variable link sentences uh the
3197.4|2.84|question is how do you do this for
3198.52|3.839|variable length sentences and that's
3200.24|3.839|something I gloss over a little bit um
3202.359|3.841|but the idea is you use what's called
3204.079|4.601|content based addressing so for the
3206.2|4.599|image captioning um we know ahead of
3208.68|4.2|time that there's this fixed maybe 7 by7
3210.799|4.8|grid so we just produce a probability
3212.88|5.36|distribution directly um instead in this
3215.599|5.041|model um as the encoder reads the input
3218.24|4.44|sentence it's producing some Vector that
3220.64|4.6|um encodes that each word in the input
3222.68|4.159|sentence so now in the decoder instead
3225.24|3.839|of directly producing a probability
3226.839|4.401|Vector um a probability distribution
3229.079|3.841|it's going to spit out sort of a vector
3231.24|3.96|that will get do producted with each of
3232.92|3.919|those encoded vectors in the input and
3235.2|5.2|then those dot products get used used to
3236.839|3.561|get renormalized and converted to a
3241.68|4.399|distribution um so this idea of soft
3244.0|4.599|attention um is actually pretty easy to
3246.079|4.361|implement and uh pretty easy to train so
3248.599|3.081|it's been very popular in the last year
3250.44|3.159|or so and there's a whole bunch of
3251.68|3.52|papers that apply this idea of soft
3253.599|4.121|attention to a whole bunch of different
3255.2|4.0|problems so there have been um a couple
3257.72|4.28|papers looking at soft attention for
3259.2|4.32|machine translation as we saw um there
3262.0|3.64|have been a couple papers that actually
3263.52|4.12|want to do speech transcription where
3265.64|4.439|they read in and audio signal and then
3267.64|4.439|output the words um in English so there
3270.079|3.881|have been a couple papers that use soft
3272.079|4.681|attention over the input audio sequence
3273.96|4.44|to help with that task um we've there's
3276.76|3.88|been at least one paper on using soft
3278.4|4.48|attention for video captioning so here
3280.64|4.32|you read in some sequence of frames and
3282.88|3.76|then you output some sequence of words
3284.96|3.879|and you want to have attention over over
3286.64|4.679|the frames of the input sequence as
3288.839|3.96|you're generating your caption so you
3291.319|3.401|could see that maybe for this little
3292.799|4.04|video sequence they output someone is
3294.72|4.119|frying a fish in a pot and when they
3296.839|3.96|generate the word someone they actually
3298.839|3.641|attend much more to this second frame in
3300.799|3.961|the video sequence and when they
3302.48|4.639|generate the word frying it attends much
3304.76|4.64|more to this last uh element in the in
3307.119|4.68|the video sequence um there have also
3309.4|5.199|been a couple papers um for this task of
3311.799|4.601|question answering so here the setup is
3314.599|4.161|that you read in a natural language
3316.4|4.52|question and you also read in an image
3318.76|4.44|an image and the model needs to produce
3320.92|4.199|an answer about that question or produce
3323.2|4.919|the answer to that question in natural
3325.119|4.761|language um so and there have been a
3328.119|3.641|couple papers that explore the idea of
3329.88|3.36|spatial attention over the image in
3331.76|3.64|order to help with this problem of
3333.24|3.48|question answering um another thing to
3335.4|3.84|point out is that some of these papers
3336.72|5.079|have great names so there was show in
3339.24|4.96|tell there was show attend in tell there
3341.799|5.481|was listen attend and
3344.2|5.8|spell and this one is ask attend and
3347.28|4.559|answer so I I I really enjoy the
3350.0|3.799|creativity with naming on this on this
3351.839|5.321|line of
3353.799|5.081|work um and this IDE of soft detention
3357.16|4.639|is pretty easy to implement so a lot of
3358.88|5.6|people have just applied it to tons of
3361.799|4.441|tasks but remember we saw this problem
3364.48|3.52|with this sort of implementation of soft
3366.24|4.359|attention and that's that we cannot
3368.0|4.4|attend to arbitrary regions in the input
3370.599|3.641|instead we're constrained and can only
3372.4|4.159|attends to this fixed grid given by the
3374.24|4.52|convolutional feature map um so the
3376.559|4.921|question is whether we can overcome this
3378.76|4.76|restriction and still attend and attends
3381.48|3.319|to arbitrary input regions somehow in a
3383.52|5.72|differentiable
3384.799|6.0|way and think um a a a precursor to this
3389.24|4.799|type of work is this paper from Alex
3390.799|5.8|Graves back in 2013 so here he wanted to
3394.039|5.201|read as input um a natural language
3396.599|4.281|sentence and then generate as output uh
3399.24|4.76|actually an image that would be
3400.88|5.88|handwriting gen U like writing out that
3404.0|4.68|that sentence in handwriting and the way
3406.76|4.24|that he and this actually has attention
3408.68|4.24|over this output image um in kind of a
3411.0|3.48|cool way where now he's actually
3412.92|3.679|predicting the parameters of some
3414.48|4.72|gausian mixture model over the output
3416.599|4.881|image and then uses that to um actually
3419.2|4.56|attend to arbitrary parts of the output
3421.48|5.079|image and this actually works really
3423.76|5.68|really well so on on the right some of
3426.559|5.48|these are um actually written by people
3429.44|3.52|and the rest of them were written by by
3432.039|3.0|his
3432.96|5.28|Network so can you tell the difference
3435.039|3.201|between the generated and the real
3440.119|4.24|handwriting I couldn't so it turns out
3443.039|2.681|that the top one is real and these
3444.359|2.521|bottom four are all generated by the
3445.72|3.119|network
3446.88|5.88|you can see the B
3448.839|5.401|is kind of unique B in the real one yeah
3452.76|2.76|so then maybe maybe the real ones have
3454.24|3.079|more variance between the letters or
3455.52|3.68|something like that but these results
3457.319|3.441|work really well um and actually he has
3459.2|3.399|an online demo that you can go on and
3460.76|3.12|try that runs on in your browser you can
3462.599|2.601|just type in words and it'll generate
3463.88|2.0|the handwriting for you so that's kind
3465.2|4.119|of
3465.88|6.679|fun um another another paper that we saw
3469.319|5.24|already is draw that um that sort of
3472.559|3.76|takes this idea of arbitrary attention
3474.559|3.161|over and then extends it to a couple
3476.319|4.161|more real world problems not just
3477.72|5.04|handwriting generation so one task they
3480.48|5.119|consider is image classification here we
3482.76|4.599|want to classify these digits um but in
3485.599|3.321|the process of classifying we're
3487.359|3.601|actually going to attend to arbitrary
3488.92|4.919|regions of the input image um in order
3490.96|4.72|to help with this classification task so
3493.839|3.441|um this is this is kind of cool it sort
3495.68|3.2|of learns on its own that it needs to
3497.28|3.079|attend to these digits in order to help
3498.88|3.64|with image
3500.359|5.041|classification um and with draw they
3502.52|4.92|also uh consider the idea of generating
3505.4|3.399|arbitrary out outut images with a
3507.44|3.56|similar sort of motivation as the
3508.799|4.32|handwriting Generation Um where we're
3511.0|4.119|going to have arbitrary attention over
3513.119|3.68|the output image and just generate this
3515.119|4.641|output um bit by
3516.799|6.32|bit and I think we saw this video before
3519.76|5.76|but it's really cool so this is the the
3523.119|3.841|draw network from from Deep Mind so you
3525.52|3.48|can see that here we're going to do
3526.96|3.76|we're doing a classification task so it
3529.0|3.68|sort of learns to attend to arbitrary
3530.72|3.72|regions in the input and when we
3532.68|3.48|generate we're going to attend to
3534.44|4.399|arbitrary regions in the output to
3536.16|5.159|actually generate these digits um so it
3538.839|4.121|can generate multiple digits at a time
3541.319|5.321|um and it can actually generate these
3542.96|6.04|these house view number these uh house
3546.64|4.04|numbers so this is really cool and as
3549.0|3.16|you could see like the region it was
3550.68|3.6|attending to was actually growing and
3552.16|4.04|shrinking over time and sort of moving
3554.28|3.44|continuously over the image and it was
3556.2|4.359|definitely not constrained to a fixed
3557.72|5.319|grid like we saw with show attend Intel
3560.559|5.0|so the way that this paper works is a
3563.039|5.241|little bit uh a little bit weird and
3565.559|6.841|some follow work from Deep Mind I think
3568.28|7.039|um actually was more clear and why is
3572.4|4.76|this guy oh my focus is all off okay
3575.319|3.401|right so there's this follow-up paper
3577.16|3.72|that t that uses a very similar
3578.72|4.24|mechanism for arbitrary attention um
3580.88|3.88|called spatial Transformer networks but
3582.96|4.04|I think is much easier to understand and
3584.76|4.319|present it in a very clean way so the
3587.0|4.599|idea is that we want to have um this
3589.079|4.361|input image this our favorite bird and
3591.599|4.081|then we want to have this sort of
3593.44|4.159|continuous set of variables telling us
3595.68|3.919|where we want to attend so you might
3597.599|4.281|imagine that we have the coord the
3599.599|4.72|center and width and height of some box
3601.88|4.32|of the region we want to attend to and
3604.319|3.76|then we want to have some function that
3606.2|4.0|takes our input image and these
3608.079|5.201|continuous attention coordinates and
3610.2|4.72|then produces some fixed size output and
3613.28|3.519|we want to be able to do this in a
3614.92|4.879|differentiable
3616.799|5.24|way um so this this seems kind of hard
3619.799|4.721|right cuz you imagine that um at least
3622.039|4.641|with the idea of cropping then these
3624.52|4.24|inputs cannot really be Contin they need
3626.68|3.879|to be sort of pixel values so we're
3628.76|3.359|constrained to integers and it's not
3630.559|3.841|really clear exactly how we can make
3632.119|4.081|this function continuous or uh
3634.4|3.959|differentiable and they actually came up
3636.2|3.8|with a very nice solution um and the
3638.359|4.401|idea is that we're going to write down a
3640.0|5.599|parameterized function that will um map
3642.76|5.96|from coordinates of pixels in the output
3645.599|5.801|to coordinates of pixels in the input so
3648.72|4.639|here um we're going to say that this
3651.4|4.0|this upper left upper right hand pixel
3653.359|5.68|in the output image has the coordinates
3655.4|6.639|XT YT in the output and we're going to
3659.039|5.32|compute these coordinates Xs and Ys in
3662.039|5.241|the input image using this parameterized
3664.359|4.521|apine function um so that's that's a
3667.28|3.319|nice differentiable function that we can
3668.88|2.76|differentiate with respect to these aine
3670.599|3.281|transform
3671.64|4.159|coordinates um then we can repeat this
3673.88|3.52|process and again for maybe the upper
3675.799|3.681|upper left hand pixel in the output
3677.4|3.84|image we again use this parameterized
3679.48|3.4|function to map to the coordinates of
3681.24|4.119|the pixel in the
3682.88|4.679|input now we can repeat this for all
3685.359|4.96|pixels in our output which gives us
3687.559|4.321|something called a sampling grid um so
3690.319|3.76|the idea is that this would be our
3691.88|4.679|output image and then for each pixel in
3694.079|4.121|the output um the sampling grid tells us
3696.559|2.48|where in the input that pixel should
3698.2|3.24|come
3699.039|4.08|from and now have any of you guys taken
3701.44|5.359|a computer Graphics
3703.119|6.48|course not many so this looks list looks
3706.799|4.841|kind of like texture mapping doesn't it
3709.599|3.96|so they take this idea from texture
3711.64|3.84|mapping in computer graphics and just
3713.559|3.76|use bilinear interpolation to compute
3715.48|5.48|the output once we have this sampling
3717.319|5.28|grid so now now that we have now this um
3720.96|3.56|now this allows our Network to actually
3722.599|4.641|attend to arbitrary parts of the input
3724.52|4.92|in a nice differentiable way um where
3727.24|4.48|our network will now just predict these
3729.44|3.879|transform coordinates Theta and that
3731.72|3.72|will allow the whole thing to attend to
3733.319|4.441|arbitrary regions of the input
3735.44|3.52|image so they put this thing all
3737.76|2.88|together into a nice little
3738.96|3.8|self-contained module that they call a
3740.64|4.28|spatial Transformer so the spatial
3742.76|4.4|Transformer receives some input which
3744.92|4.96|you can think of as an as um our raw
3747.16|4.919|input image and then actually runs this
3749.88|4.08|small localization Network which could
3752.079|4.2|be a small fully connected Network or a
3753.96|4.48|very shallow convolutional Network and
3756.279|4.52|this this localization network will
3758.44|4.72|actually um produce as output these
3760.799|4.76|apine transform coordinates
3763.16|3.879|Theta now these apine transform
3765.559|3.601|coordinates will be used to compute a
3767.039|4.161|sampling grid so now that we've
3769.16|4.28|predicted these this apine transform
3771.2|4.24|from the localization Network we map
3773.44|4.08|each pixel in the output the coordinates
3775.44|4.44|of each pixel in the output back to the
3777.52|3.64|input um and this is a nice smooth
3779.88|3.52|differentiable
3781.16|3.959|function now once we have the sampling
3783.4|4.04|grid we can just apply bilinear
3785.119|5.401|interpolation to compute the values in
3787.44|4.44|the pixels of the output um and they if
3790.52|3.36|you if you think about what this thing
3791.88|4.76|is doing it's clear that every single
3793.88|5.159|part of this network is one continuous
3796.64|4.88|and two differentiable so this thing can
3799.039|4.681|be learned jointly um without any crazy
3801.52|5.0|reinforcement learning stuff um which is
3803.72|5.44|quite nice um although one one sort of
3806.52|5.079|caveat to note about bilinear sampling
3809.16|4.6|if you know how bilinear sampling works
3811.599|4.44|it means that every pixel in the output
3813.76|4.839|is going to be um a weighted average of
3816.039|5.201|four pixels in the input so those
3818.599|4.601|gradients are actually very local so um
3821.24|3.839|this is continuous and differentiable
3823.2|3.44|and nice but I don't think you get a
3825.079|3.24|whole lot of gradient signal through the
3826.64|4.28|through the bilinear
3828.319|4.96|sampling but once you have this spatial
3830.92|3.879|this nice spatial Transformer module we
3833.279|3.28|can just insert it into existing
3834.799|4.8|networks to sort of let them learn to
3836.559|5.56|attend to things so they consider um
3839.599|4.48|this classification task very similar to
3842.119|4.281|um the draw paper where they want to
3844.079|4.641|classify these warped versions of mist
3846.4|3.76|digits um so they actually consider
3848.72|3.52|several other more complicated
3850.16|4.439|transforms not just these apine
3852.24|3.76|transforms you could also imagine that
3854.599|3.561|so that's the mapping from your output
3856.0|3.559|pixels back to your input pixels um on
3858.16|3.28|the previous slide we showed an apine
3859.559|3.52|transform but they also consider
3861.44|3.879|projective transforms and also thin
3863.079|4.121|Place blinds but the idea is you just
3865.319|3.52|want some some parameterized and
3867.2|3.079|differentiable function um and you could
3868.839|4.681|go crazy with that
3870.279|5.161|part so here on the left um the network
3873.52|4.039|is just trying to classify these digits
3875.44|5.0|that are warped so on the left we have
3877.559|4.56|different versions of warped digits um
3880.44|3.48|on on this middle column is showing
3882.119|3.761|these different thin plate splines that
3883.92|4.08|it's using to attend to a part of the
3885.88|4.52|image and then on the right it shows the
3888.0|4.279|output of the spatial Transformer module
3890.4|3.56|which has um not only attended to that
3892.279|4.121|region but also unwarped it
3893.96|5.159|corresponding to ex um those
3896.4|4.959|splines um and on the right um they're
3899.119|3.92|using an apine trans or on the right is
3901.359|3.44|using an apine transform not these thin
3903.039|3.401|plate splines so you can see that this
3904.799|3.24|is actually doing more than just
3906.44|3.96|attending to the input we're actually
3908.039|4.52|transforming the input as well so for
3910.4|5.04|example in this middle column this is a
3912.559|6.0|four um but it's actually rotated by
3915.44|5.119|some by something like 90° so by using
3918.559|4.24|this apine transform the network can not
3920.559|3.961|only attend to the four but also rotate
3922.799|4.441|it into the proper position for the
3924.52|5.16|downstream classification Network um and
3927.24|4.28|this is all very cool and again um sort
3929.68|3.72|of similar to the soft attention we
3931.52|3.839|don't need explicit supervision it can
3933.4|4.84|just decide for itself where it wants to
3935.359|5.24|attend in order to solve the
3938.24|5.52|problem um so these guys have a fancy
3940.599|3.161|video as well which is very
3946.44|5.04|impressive so this is the the
3948.24|3.24|Transformer module that we just
3952.319|4.04|unpacked and here we're actually showing
3955.359|2.401|um
3956.359|3.561|right so this is actually running a
3957.76|4.359|classification task but we're varying
3959.92|3.879|the input continuously so you can see
3962.119|4.16|that for these different inputs the
3963.799|4.681|network learns to attend to to to the
3966.279|4.961|digit and then actually canonizes that
3968.48|4.799|digit to sort of a fixed known pose and
3971.24|3.92|as we vary that input and move it around
3973.279|3.84|the image the network still does a good
3975.16|4.399|job of locking on to the
3977.119|4.881|digit and on the right you can see that
3979.559|4.641|um sometimes it can fix rotations as
3982.0|4.039|well right so here on the left we're
3984.2|3.72|actually rotating that digit and the
3986.039|4.961|network actually learns to un rotate the
3987.92|5.0|digit and canonicalize the pose um and
3991.0|4.96|again both with apine transforms or thin
3992.92|4.919|Place blinds um so this is using even
3995.96|4.0|crazier warping with projective
3997.839|3.921|transforms so you can see that it does a
3999.96|4.319|really good job of learning to attend
4001.76|2.519|and also to
4006.0|3.16|unwarp um and they do quite a lot of
4008.0|3.96|other experiments instead of
4009.16|4.48|classification they learn to um add
4011.96|5.0|together two warped digits which is kind
4013.64|5.0|of a weird task but it works
4016.96|3.879|um so the network is receiving two
4018.64|4.32|inputs as uh two input images and it
4020.839|4.601|needs to Output the
4022.96|4.04|sum and it learns and even though this
4025.44|4.04|is kind of a weird task it learns that
4027.0|6.72|it needs to attend and unwarp those
4029.48|6.119|images um so this is during
4033.72|4.079|optimization right so this is a task
4035.599|3.801|called co-localization so the idea is
4037.799|4.081|that the in the the network is going to
4039.4|5.08|receive two images of uh as input that
4041.88|4.12|are maybe two different images of fours
4044.48|4.0|and the task is to say whether or not
4046.0|6.039|those images are the same um are the
4048.48|5.079|same or different and then also Lo using
4052.039|3.721|spatial Transformers it ends up learning
4053.559|3.641|to localize those things as well so you
4055.76|3.039|can see that over the course of training
4057.2|4.2|it learns to actually localize these
4058.799|4.681|things very very precisely um even when
4061.4|4.679|we add clutter to the image then these
4063.48|4.839|networks still learn to localize uh very
4066.079|2.24|very
4069.039|6.721|precisely so that's a recent paper from
4071.119|4.641|Deep Mind that um is pretty cool
4080.319|2.841|so any other last minute questions about
4082.16|4.36|spatial
4083.16|5.84|Transformers yeah it just what exactly
4086.52|5.519|is the Y variable in this content y
4089.0|4.4|variable is L uh yeah so the simp so the
4092.039|2.8|question is what is the what is the task
4093.4|2.68|that these things are doing and at least
4094.839|3.48|in the vanilla version It's just
4096.08|4.04|classification so it receives this um
4098.319|3.681|sort of input digit which could be
4100.12|4.4|warped or cluttered or whatnot and all
4102.0|4.48|it it needs to do is classify the digit
4104.52|3.799|um and sort of in process of learning to
4106.48|3.839|classify it also learns to attend to the
4108.319|6.48|correct part so that's that's a really
4110.319|4.48|cool um feature of this of this of this
4116.96|5.52|work all right so then the sort of my
4119.719|4.841|overview of attention um is that we have
4122.48|4.199|soft attention which is really easy to
4124.56|4.52|implement especially in this context of
4126.679|4.401|fixed input positions that um we just
4129.08|3.92|produce distributions over our input and
4131.08|4.119|then reweight and refeed those those
4133.0|3.6|vectors back to the network somehow um
4135.199|3.201|and this is really easy to implement in
4136.6|4.199|many different contexts and has been
4138.4|4.16|implemented for a lot of different tasks
4140.799|3.96|um when you want to attend to arbitrary
4142.56|4.239|regions um then you need to get a little
4144.759|4.04|bit fancier um and I think spatial
4146.799|3.52|Transformers is a very a very nice
4148.799|4.721|elegant way of attending to arbitrary
4150.319|4.681|regions in input images um there are a
4153.52|3.6|lot of papers that actually work on hard
4155.0|3.92|attention and this is quite a bit more
4157.12|3.92|challenging due to this problem with the
4158.92|4.04|gradients so heart attention papers
4161.04|4.119|typically use reinforcement learning and
4162.96|4.719|we didn't really talk about that today
4165.159|5.241|so so any any other questions about um
4167.679|4.401|attention or okay sure a quick question
4170.4|3.56|about your presentation so before you
4172.08|3.56|introduce the concept of space Ro
4173.96|5.879|Transformer networks you gave us some
4175.64|6.36|examples of uh captured images um using
4179.839|4.84|sort of the fixed input location were
4182.0|5.12|those results produced using only the
4184.679|4.56|grid based um yeah so the question is
4187.12|4.32|about the um the the captioning before
4189.239|3.801|we got to spatial Transformers and yeah
4191.44|4.52|those those captions were produced using
4193.04|4.36|this this grid based um thing but in in
4195.96|4.759|that Network in particular I think it
4197.4|5.6|was a 14x14 grid so it's actually it has
4200.719|3.44|quite a lot of locations but it it's it
4203.0|3.56|still is constrains to where it's
4204.159|2.401|allowed to
4207.6|8.4|look question so is there any
4211.48|6.6|interpretation interation between s sof
4216.0|3.96|and in the question is about
4218.08|2.96|interpolating between soft attention and
4219.96|3.6|heart
4221.04|4.08|attention um so yeah one one thing you
4223.56|3.36|might imagine is you train the network
4225.12|3.24|in a soft way and then during training
4226.92|2.92|you kind of penalize it to make that
4228.36|3.319|distribution sharper and sharper and
4229.84|3.16|sharper and then at test time you just
4231.679|3.921|switch over and use heart attention
4233.0|4.48|instead and I think um I'm I can't
4235.6|3.2|remember which paper did that but I'm
4237.48|4.92|I'm pretty sure I've seen that idea
4238.8|5.08|somewhere um but in practice I think uh
4242.4|2.6|training with hard attention tends to
4243.88|2.52|work better than this sharpening
4245.0|3.719|approach but it's definitely something
4246.4|2.319|you could
4248.92|3.44|try okay if no other questions then I
4251.199|5.96|think we're done a couple minutes early
4252.36|4.799|today so get your homework done
4258.52|2.719|that's