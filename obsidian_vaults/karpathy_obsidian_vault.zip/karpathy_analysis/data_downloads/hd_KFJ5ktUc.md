start_time|end_time|text
1.429|4.511|okay so let's die first
4.2|3.48|today we'll talk about training neural
5.94|2.97|networks again and then I'll give you a
7.68|4.35|bit of an intro to convolutional neural
8.91|5.639|networks before we dive into that the
12.03|4.169|material just some administrative things
14.549|3.511|first first I didn't get a chance to
16.199|4.17|actually introduce Justin last lecture
18.06|3.389|justin is your instructor also for this
20.369|3.511|class and he was missing for the first
21.449|3.99|two weeks and so you can you can ask him
23.88|4.83|anything about anything he's very
25.439|7.081|knowledgeable maybe that's an
28.71|6.27|overstatement I don't know okay
32.52|5.1|and the simon too is out as a reminder
34.98|5.97|it's quite long so I encourage you to
37.62|6.27|start earlier and it's do basically next
40.95|4.56|Friday so get started on that as soon as
43.89|3.81|possible and you'll implement neural
45.51|3.479|networks with the proper API of forward
47.7|3.47|backward passes and you'll see the
48.989|4.441|abstraction of a computational graph and
51.17|3.19|you'll implement also Bachelor Malaysian
53.43|2.82|dropout and then you'll actually
54.36|3.06|implement convolutional networks so by
56.25|1.98|the end of this assignment you'll
57.42|2.069|actually have a fairly good
58.23|2.969|understanding of all the low-level
59.489|5.791|details of how combos on your network
61.199|5.67|classifies images okay so where we are
65.28|3.36|in this class just as a reminder again
66.869|3.121|we're training neural networks and it
68.64|4.74|turns out that training neural networks
69.99|5.129|is really a four-step process you have
73.38|3.809|an entire data set of images and labels
75.119|3.811|we sample a small batch of that data set
77.189|4.351|we forward propagate it through the
78.93|4.11|network to get the loss which is telling
81.54|3.18|us how well we're currently classifying
83.04|3.119|this batch of data and then we back
84.72|3.21|propagate to compute the gradient and
86.159|3.301|all the weights and this gradient is
87.93|3.18|telling us how we should nudge every
89.46|3.33|single weight in the network so that
91.11|3.42|we're better classifying these images
92.79|3.18|and then once we have the gradient we
94.53|4.86|can use it for a parameter update where
95.97|5.009|we actually do that small nudge we last
99.39|2.85|class we looked into activation
100.979|2.701|functions and an entire zoo of
102.24|2.94|activation functions and some pros and
103.68|3.24|cons of using any of these inside your
105.18|3.84|neural network a good question came up
106.92|4.11|in Piazza so when asked why would you
109.02|4.77|even use in your activation function why
111.03|4.949|not just skip it and question was posted
113.79|3.929|and I forgot to really address this very
115.979|2.791|nicely in the last lecture but basically
117.719|3.121|if you don't use an activation function
118.77|4.44|then your entire neural network ends up
120.84|4.709|being one single linear sandwich and so
123.21|5.04|your capacity is equal to that of just a
125.549|4.471|linear classifier so those activation
128.25|3.45|functions are really critical to have in
130.02|3.16|between and they they are the ones that
131.7|2.83|give you all this wiggle
133.18|3.69|that you can use to actually fit your
134.53|3.81|data we talked briefly about data
136.87|4.47|pre-processing techniques but very
138.34|4.14|briefly we also looked at the activation
141.34|2.819|functions and their distributions
142.48|4.47|throughout the neural network and so the
144.159|5.341|problem here I see you recall is we have
146.95|4.14|to choose this initial initialization
149.5|3.689|for our weights and in particular
151.09|3.66|there's the scale of how large we want
153.189|3.061|those ways to be in the beginning and we
154.75|3.299|saw that if that if those weights are
156.25|2.819|too small then your activation in a
158.049|3.151|neural network as you have a deep
159.069|3.601|network goes all toward zero and if you
161.2|3.42|set that scale slightly too high then
162.67|3.42|all of them will explode instead and so
164.62|3.539|you end up with either supersaturated
166.09|4.11|networks or you end up with networks
168.159|3.78|that just up at all zeros and so that
170.2|4.92|scale is very very tricky thing to set
171.939|5.36|we looked into the Xavier initialization
175.12|5.31|which gives you a reasonable kind of
177.299|4.81|thing to use in that form and that gives
180.43|3.779|you basically roughly good active
182.109|3.421|activations or distributions of
184.209|3.42|activations throughout the network in
185.53|4.079|the beginning of training and then we
187.629|3.48|went into batch normalization which is
189.609|2.761|this thing that alleviates a lot of
191.109|3.03|these headaches were actually setting
192.37|3.0|that scale properly and so Bachelor
194.139|2.52|realization makes this a much more
195.37|3.0|robust choice so you don't have to
196.659|3.66|precisely get that initial scale correct
198.37|3.329|and we went to all of its pros and cons
200.319|3.301|and we talked about that for a while
201.699|3.75|and then we talked about the learning
203.62|2.88|process and so I try to show you kind of
205.449|2.4|tips and tricks for how you actually
206.5|3.239|baby set these neural networks how you
207.849|3.121|get them to train properly and also how
209.739|2.851|you run cross validations and how you
210.97|4.109|could slowly converge over time into
212.59|4.2|good hyper parameter ranges so we talked
215.079|2.731|about all of that last time so this time
216.79|2.339|we're going to go into some of the
217.81|3.09|remaining items for training in neural
219.129|3.54|networks in particular parameter update
220.9|3.299|schemes I think for the most part and
222.669|4.35|then we'll talk a bit about model
224.199|4.051|ensembles dropout and so on okay so
227.019|2.46|before I dive into that any
228.25|4.739|administrator things by the way that I'm
229.479|6.6|forgetting not necessarily okay so
232.989|4.441|parameter updates so recall that there's
236.079|2.671|this four-step process to training a
237.43|2.82|neural network and this is a pseudo code
238.75|3.09|really in what it looks like we get a
240.25|2.819|data batch evaluate the loss evaluate
241.84|3.0|the gradient and perform a parameter
243.069|3.151|update when I talk about parameter
244.84|3.479|updates we're specifically looking at
246.22|4.68|this last line in here where we are
248.319|4.051|trying to make that more complex where
250.9|3.449|so right now what we're doing is called
252.37|4.619|just gradient descent where we take that
254.349|4.86|gradient and we that we've computed and
256.989|3.87|we just multiply it scaled by the
259.209|3.39|learning rate onto our parameter vector
260.859|4.05|we can be much more elaborate with how
262.599|4.021|we perform that update and so I flashed
264.909|3.57|this image briefly in the last few
266.62|3.45|lectures where you can see different
268.479|3.811|parameter update schemes and how quickly
270.07|4.26|they actually optimize this simple loss
272.29|3.96|function here and so in particular we
274.33|3.36|can see that SPD which is what we're
276.25|3.36|using right now in the fourth line here
277.69|3.33|that's SGD in red you can see that
279.61|2.91|that's actually the slowest one of all
281.02|3.36|of them so in practice you rarely ever
282.52|3.57|use just basic STD and there are better
284.38|3.93|schemes that we can use and we're going
286.09|3.57|to go into those in this lecture so
288.31|5.37|let's look at what the problem is with
289.66|5.55|SGD why is it so slow so consider this
293.68|3.12|particular slightly contrived example
295.21|3.269|here where we have a loss function
296.8|3.63|surface so these are the level sets of
298.479|3.361|our loss and suppose that it's elongated
300.43|3.63|along one direction much more than
301.84|3.48|another direction so basically this loss
304.06|3.06|function here is very shallow
305.32|4.11|horizontally but it's very steep
307.12|3.99|vertically and we want to of course
309.43|2.82|minimize this and right now we're at the
311.11|3.029|red spot and we're trying to get to the
312.25|4.65|minimum denoted by the smiley face
314.139|7.201|that's where we're happy but think about
316.9|7.32|what the trajectory of this is in both x
321.34|4.68|and y directions of SGD if we try to
324.22|6.9|optimize this landscape what would that
326.02|8.88|look like so what would it look like
331.12|4.919|horizontally and vertically I see
334.9|7.32|someone's butt so what are you plotting
336.039|7.56|out there okay and why is it okay so why
342.22|2.79|is it going to bounce up and down like
343.599|7.141|that and why is it not making a large
345.01|8.1|progress right so the local gradient is
350.74|5.25|is basically has this form where when we
353.11|4.5|look at the gradient horizontally we see
355.99|3.33|that the gradient is very small because
357.61|3.63|this is a shallow function horizontally
359.32|3.15|but vertically we have a large gradient
361.24|2.82|because it's a very steep function and
362.47|3.24|so what's going to happen when you roll
364.06|3.45|out SGD in these kinds of cases and you
365.71|3.69|end up with this kind of pattern where
367.51|3.48|you're going way too slow in horizontal
369.4|3.51|direction but you're going way too fast
370.99|4.23|in the vertical direction okay so you
372.91|3.96|end up at this ugly juror so one way of
375.22|4.56|remedying this kind of situation is what
376.87|4.47|we call an momentum update so the
379.78|4.08|momentum update will change our update
381.34|4.02|in the following way so right now we're
383.86|2.7|just incrementing the gradient we're
385.36|3.15|taking the gradient and we're
386.56|4.609|integrating our current position by that
388.51|4.589|gradient in a momentum update instead
391.169|3.521|we're going to take the gradient that
393.099|3.421|we've computed and instead of
394.69|4.2|integrating the position directly we're
396.52|3.84|going to increment this variable V which
398.89|2.79|I call V for velocity
400.36|3.72|so we're going to and we'll see why that
401.68|4.65|is in a bit so we increment this
404.08|3.929|velocity variable B and instead instead
406.33|4.25|we're basically building up this
408.009|4.861|exponential sum of gradients in the past
410.58|4.48|and that that's what's integrating the
412.87|4.859|position this mu here is a happy
415.06|4.05|parameter and mu is kind of a number
417.729|3.171|between zero and one and what it's doing
419.11|4.519|is its decaying the previous V and
420.9|4.81|adding on this current gradient so
423.629|3.34|what's nice about the momentum update is
425.71|4.25|that you can interpret it in a very
426.969|6.781|physical terms and in the following way
429.96|5.709|basically Optima using momentum update
433.75|4.44|corresponds to interpreting this func
435.669|4.411|this as really a ball rolling allows
438.19|3.569|this round this landscape and the
440.08|4.019|gradient in this case is your force that
441.759|3.81|the particle is feeling so this particle
444.099|3.331|is feeling some force due to gradient
445.569|3.72|but instead of directly integrating the
447.43|3.81|position this force F equals MA in
449.289|4.771|physics so force is equivalent to
451.24|5.22|acceleration there and so acceleration
454.06|3.63|is what we're computing and so the
456.46|3.389|velocity gets integrated by the
457.69|3.839|acceleration here and then the MU times
459.849|3.18|V has the interpretation of friction in
461.529|3.5|that case because at every single
463.029|4.681|iteration were slightly slowing down and
465.029|4.721|intuitively if this new times V was not
467.71|3.6|there then this ball would never come to
469.75|2.849|a rest because it was just Jigar around
471.31|2.579|the last surface forever and there would
472.599|3.331|be no loss of energy where it would
473.889|4.171|settle at the end of a loss function and
475.93|3.18|so that the momentum update is taking
478.06|2.46|this physical interpretation of
479.11|4.589|optimization where we have a ball
480.52|5.549|rolling around around and it's slowing
483.699|5.31|down over time and so the way this works
486.069|4.741|is what's very nice about this update is
489.009|3.451|you end up building up this velocity and
490.81|3.69|in particular in the shallow directions
492.46|3.81|it's very easy to see that if you have a
494.5|3.389|shallow but consistent direction then
496.27|2.819|the momentum update will slowly build up
497.889|3.03|the velocity vector in that direction
499.089|3.75|you'll end up speeding up and up across
500.919|3.271|the shallow direction but in a very
502.839|3.931|steep directions what's going to happen
504.19|4.529|as you start of course during around but
506.77|3.329|then you're always being pulled up the
508.719|2.88|other direction towards the center and
510.099|3.541|with the damping you end up kind of
511.599|4.021|oscillating to the middle and so it's
513.64|3.24|kind of damping these oscillations in
515.62|3.539|the steep directions and it's kind of
516.88|4.17|encouraging these oscillate it's
519.159|3.87|encouraging process in these consistent
521.05|3.81|shallow directions and that's why it
523.029|4.161|ends up improving the convergence in
524.86|4.62|many cases so for example here in this
527.19|4.899|visualization we see the SGD update in
529.48|3.75|red momentum update as in green and so
532.089|1.861|you can see what happens with the green
533.23|2.52|one
533.95|3.84|it overshoots because it's built up all
535.75|3.78|this velocity so it overshoots the
537.79|3.78|minimum but then it eventually ends up
539.53|4.08|converging down and of course it's
541.57|3.27|overshot but once it converges there you
543.61|3.78|can see that it's converging there much
544.84|4.41|quicker than just basic STD update so
547.39|3.09|you end up building up too much velocity
549.25|2.58|but then you eventually get there
550.48|4.05|quicker than if you did not have
551.83|5.82|velocity okay so that's the momentum
554.53|4.68|update I'll go into a particular
557.65|3.63|variation of the momentum update in a
559.21|3.36|bit I just wanted to ask ours any
561.28|8.58|questions about the momentum update this
562.57|9.36|point I'll go ahead oh yeah thank you
569.86|3.33|for asking so do we use a single meu and
571.93|3.87|usually we do that's a single hyper
573.19|5.55|parameter and usually it takes some
575.8|4.65|values of roughly point five or 0.9 and
578.74|3.06|usually people sometimes this is not
580.45|3.81|super common but people sometimes and
581.8|4.64|they'll eat from point 52.99 slowly over
584.26|11.58|time but it's just a single number
586.44|10.75|good yes so you could avoid this with a
595.84|4.8|smaller learning rate but then the issue
597.19|4.77|is if you had a slower learning rate
600.64|3.42|this learning rate is applied globally
601.96|3.72|to all directions in the gradient and so
604.06|3.57|then you would basically do no progress
605.68|3.36|in the horizontal direction right you
607.63|2.25|wouldn't jitter as much but then it
609.04|2.19|would take you forever to go
609.88|3.68|horizontally if you had a small learning
611.23|5.72|rate so is this kind of trade-off there
613.56|9.43|okay so I'd like to describe a
616.95|8.14|modification on the oh sorry oh thank
622.99|3.42|you so V here the question is how do you
625.09|3.24|initialize velocity you're usually in a
626.41|3.06|slot with zero and it doesn't matter too
628.33|3.21|much because you end up building it up
629.47|3.75|in the first few steps and then you end
631.54|2.94|up with this if you expand out this
633.22|3.0|recurrence you'll see that basically
634.48|3.81|it's a exponentially decaying some of
636.22|3.6|your previous gradients and so once
638.29|4.92|you've built it up you you have certain
639.82|5.58|bandwidth so initialize at zero okay so
643.21|3.18|a particular variation of momentum is
645.4|3.57|called something called Nesterov
646.39|6.72|momentum and or Nesterov accelerated
648.97|5.97|gradient descent and the idea here is we
653.11|3.72|have the ordinary momentum equation here
654.94|4.02|and the way to think about it is that
656.83|4.41|your x is incremented by really two
658.96|3.45|parts there's a part that you've built
661.24|3.78|up some momentum in a particular
662.41|4.29|direction so that's the momentum step in
665.02|2.49|green that's the Mutants V that's where
666.7|2.67|your momentum is
667.51|2.97|currently trying to carry you and then
669.37|2.61|you have the second contribution from
670.48|4.02|the gradient so the gradient is pulling
671.98|4.68|you this way towards the decrease of a
674.5|3.81|loss function and the actual step ends
676.66|3.66|up being the vector sum of the two so
678.31|4.35|the blue is what you end up with is just
680.32|3.66|the green plus the red and the idea with
682.66|2.7|Nesterov momentum and this ends up
683.98|3.24|working better in practice is the
685.36|4.17|following we know at this point
687.22|3.78|regardless of what the current input was
689.53|3.33|to us so we haven't computed the
691.0|3.33|gradient step yet but we know that we've
692.86|2.94|built up some momentum and we know we
694.33|3.81|were definitely going to take this green
695.8|4.02|direction okay so we're definitely going
698.14|3.06|to take this green so instead of
699.82|3.6|evaluating the gradient here at our
701.2|4.05|current spot néstor of momentum does
703.42|3.81|this one step look ahead and instead
705.25|4.08|evaluates the gradient at this point at
707.23|3.9|this point at the top of the arrow so
709.33|4.35|what you end up with is the following
711.13|4.44|difference here we know we're going to
713.68|3.39|go this way anyway so why not just like
715.57|3.06|look ahead a bit to that part of the
717.07|3.15|objective and evaluate the gradient at
718.63|2.61|that point and at that point of course
720.22|2.16|your gradient is going to be slightly
721.24|2.7|different because you're in a different
722.38|2.91|position and loss function and this
723.94|4.29|one-step look-ahead gives you a slightly
725.29|4.89|better direction over there and you get
728.23|3.75|a slightly different update now you can
730.18|3.39|do you can theoretically show that this
731.98|4.11|actually enjoys better theoretical
733.57|4.05|guarantees on convergence rates but not
736.09|3.24|only is it true in theory but also in
737.62|2.99|practice Nesterov omentum almost always
739.33|4.14|works better than just standard momentum
740.61|5.59|okay so the difference roughly is the
743.47|4.53|following here I've written it in light
746.2|3.21|tech notation instead of code but we
748.0|3.0|still have this velocity vector time
749.41|3.51|equals mu times the previous velocity
751.0|3.78|vector and the gradient that you're
752.92|4.29|currently evaluating and then we do an
754.78|3.75|update here and so the Nesterov update
757.21|3.78|the only difference is we're appending
758.53|4.2|here this new plus mu times VT minus 1
760.99|3.0|when we're evaluating the gradient we
762.73|3.33|have to evaluate at a slightly different
763.99|3.96|position in this look-ahead position and
766.06|3.9|so that's really a necessarily momentum
767.95|3.51|it almost always works better and now
769.96|3.0|there's a slight technicality here which
771.46|5.28|I don't think I'm going to go into too
772.96|5.46|much but it's slightly inconvenient the
776.74|2.94|fact that normally we think about just
778.42|2.64|doing a forward pass and backward pass
779.68|3.18|so what we end up with is we have a
781.06|3.81|parameter vector theta and the gradient
782.86|3.9|at that point but here necessary off
784.87|4.2|wants us to have a gradient parameter
786.76|3.84|theta theta and a gradient at a
789.07|3.21|different point so it doesn't quite fit
790.6|3.54|in with like a simple API that you
792.28|3.12|normally have in your code and so it
794.14|3.12|turns out that there's a way and I don't
795.4|3.27|want to really probably spend too much
797.26|3.27|time on this but there's a way to
798.67|2.52|basically do a variable transform where
800.53|2.67|you denote this
801.19|3.09|beefy you do some rearrangement and then
803.2|2.82|you get something that looks much more
804.28|3.63|like a vanilla update that you can just
806.02|3.81|swap in for momentum or you can swap it
807.91|4.44|in for SGD because you end up with only
809.83|4.53|needing gradient at fee and you do
812.35|3.54|updates on fee and this fee has really
814.36|3.18|looked ahead version of the parameters
815.89|3.39|instead of just the raw parameter vector
817.54|5.1|so that's just a technicality you can go
819.28|5.52|into notes to check this out okay so
822.64|4.2|here Nestor of accelerated gradient is
824.8|3.81|in magenta and you can see the original
826.84|3.3|momentum here overshot by quite a lot
828.61|3.09|but because Nestor of accelerate
830.14|3.6|momentum has this one step look ahead
831.7|4.08|you'll see that it curls around much
833.74|3.66|more quickly and that's because all
835.78|3.39|these tiny contributions of a slightly
837.4|4.05|better gradient at where you're about to
839.17|4.59|be end up adding up and you almost
841.45|5.19|always converge faster okay so that's
843.76|4.86|necessary of accelerated momentum so
846.64|3.48|until recently SGD momentum was the
848.62|2.85|standard default way of training
850.12|3.09|convolutional networks and many people
851.47|3.18|still train using just momentum update
853.21|3.15|so this is a common thing to see in
854.65|3.81|practice and even better if you can use
856.36|4.7|necessarily accelerated momentum so mag
858.46|15.6|here stands for slurry glint okay
861.06|14.11|question you're asking about the
874.06|3.03|optimization landscape and you're
875.17|3.3|thinking about minima and whether or not
877.09|4.65|you can maybe overshoot to like a wrong
878.47|5.91|minimum or something like that so I
881.74|3.81|think it's slightly incorrect to what so
884.38|2.37|when you think about the loss functions
885.55|2.88|for neural networks usually you think
886.75|3.36|about these crazy ravines and lots of
888.43|3.66|local minima everywhere that's actually
890.11|3.54|not a correct way to look at it that's a
892.09|2.73|correct approximation to have conceptual
893.65|2.73|in your mind when you have very small
894.82|2.91|neural networks and people used to think
896.38|3.18|that local minima are an issue and
897.73|3.12|optimizing heel networks but actually it
899.56|4.2|turns out with a lot of recent even
900.85|4.53|theoretical work that as you scale up
903.76|5.57|your models these local men images
905.38|6.18|become less and less of an issue so the
909.33|3.97|the picture to have in mind is there are
911.56|4.41|lots of local minima but they're all
913.3|4.77|about the same actually loss that's a
915.97|3.66|better way to look at it so these
918.07|3.06|functions neural networks actually in
919.63|3.81|practice end up looking much more like a
921.13|4.14|like a bowl instead of the crazy ravine
923.44|2.91|landscape and you can show that as you
925.27|2.88|scale up the neural network the
926.35|3.33|difference between like the worst and
928.15|3.75|your best local minimum it actually kind
929.68|3.6|of like shrinks down over time with some
931.9|2.67|recent results so basically there's no
933.28|4.05|bad local minima
934.57|5.58|only happens in very small networks so
937.33|4.26|and in fact in practice what you find is
940.15|3.06|if you initialize with different random
941.59|3.0|initialization you almost always end up
943.21|3.06|getting the same answer like the same
944.59|3.39|loss in the end so you don't end up
946.27|3.15|there's no like bad local minima you
947.98|3.42|sometimes converge to especially when
949.42|2.54|you have bigger networks thanks for the
951.4|4.67|question
951.96|4.11|okay what's your question over there
959.22|13.12|Nesterov as an oscillating feature which
964.45|9.66|part is oscillating okay I think you're
972.34|2.85|jumping ahead maybe by by several slides
974.11|4.17|we're going to go into second-order
975.19|4.95|methods in a bit okay so let me jump
978.28|3.81|into another update that is very common
980.14|3.27|to see in practice it's called a de grad
982.09|2.82|and it was originally developed in a
983.41|2.82|convex optimization literature and then
984.91|3.66|it was kind of ported over to neural
986.23|3.95|networks and people sometimes use it so
988.57|5.22|the other grad update looks as follows
990.18|4.96|we have this update as we normally see
993.79|3.0|so this is just basic stochastic
995.14|4.11|gradient descent here learning rate
996.79|4.62|times your gradient but now we're
999.25|4.38|scaling this gradient by this additional
1001.41|5.34|variable that we keep accumulating okay
1003.63|4.98|note here that this cache which we're
1006.75|4.32|building up and is the sum of gradients
1008.61|4.41|squared this cache contains positive
1011.07|3.72|numbers only and note that the cache
1013.02|3.42|variable here is a giant vector of the
1014.79|4.35|same size as your parameter vector and
1016.44|4.29|so this cache ends up building up the
1019.14|2.97|demand in every single dimension we're
1020.73|2.97|keeping track of the sum of squares of
1022.11|3.06|the gradients or as we like to sometimes
1023.7|3.72|call it the second moment although it's
1025.17|3.84|the uncentered second moment and so we
1027.42|4.23|keep building up this cache and then we
1029.01|6.24|divide element wise this step function
1031.65|9.179|by the square root of cache and so what
1035.25|7.17|ends up happening here let's see so so
1040.829|4.26|that's the reason that people call it a
1042.42|5.43|/ / parameter adaptive learning rate
1045.089|4.261|method because every single product
1047.85|4.14|every single low dimension of your
1049.35|3.96|parameter space now has its own kind of
1051.99|3.06|like learning rate that is scaled
1053.31|3.51|dynamically based on what kinds of
1055.05|4.5|ingredients you're seeing in terms of
1056.82|4.59|their scale so with this interpretation
1059.55|3.87|what happens with a degrade in this
1061.41|3.41|particular case if we do this what
1063.42|3.32|happens in the horizontal and vertical
1064.82|14.97|direction
1066.74|15.0|kind of dynamics okay that's correct so
1079.79|3.93|what you'll see is we have a large
1081.74|3.81|gradient vertically and that large
1083.72|3.54|gradient will be added up to cache and
1085.55|3.36|then we end up dividing by larger and
1087.26|4.08|larger numbers so we'll get smaller and
1088.91|3.57|smaller updates in the vertical step so
1091.34|3.18|since we're seeing lots of large
1092.48|3.78|gradients vertically this will decay the
1094.52|3.51|learning rate and we'll make smaller and
1096.26|3.72|smaller steps in the vertical direction
1098.03|4.02|but in the horizontal direction it's a
1099.98|3.66|very shallow direction so we end up with
1102.05|3.629|smaller numbers in the denominator and
1103.64|3.12|you'll see that relative to the Y
1105.679|2.88|dimension we're going to end up making
1106.76|5.15|faster progress so we have this
1108.559|6.331|equalizing effect of accounting for this
1111.91|4.54|the steepness and in shallow directions
1114.89|4.34|you can actually have much larger
1116.45|7.89|learning rate then instead of the
1119.23|7.44|vertical directions and but so that's at
1124.34|5.01|a grad one problem with a degrade is
1126.67|5.1|think about what happens to this step
1129.35|4.8|size as we're updating this position if
1131.77|3.97|we want to train an entire deep neural
1134.15|2.7|network this takes for a long time and
1135.74|4.95|we're training this over a long time
1136.85|6.329|what's going to happen in a de grad okay
1140.69|3.869|of course so your cache ends up building
1143.179|2.401|up all the time you add all these
1144.559|2.461|positive numbers goes into your
1145.58|3.15|denominator you're learning they just
1147.02|4.11|decays towards zero and you end up
1148.73|5.49|stopping learning at like completely and
1151.13|4.14|so that's not so that's okay in convex
1154.22|2.79|problems perhaps when you just have a
1155.27|3.81|bowl and you just kind of decay down to
1157.01|3.21|the optimum and you're done but in a
1159.08|3.06|neural network this stuff is kind of
1160.22|3.089|like shuffling around and it's trying to
1162.14|2.58|pick your data and that's like a better
1163.309|3.661|way to think of it and so this thing
1164.72|3.6|needs continuous kind of energy to thick
1166.97|3.87|your data and so you don't want it to
1168.32|4.68|just decay to a halt so there's a very
1170.84|4.65|simple change to an autograph that was
1173.0|4.86|proposed by Geoff Hinton recently and
1175.49|4.98|the idea here is that instead of keeping
1177.86|4.319|it completely just the sum of squares in
1180.47|4.47|every single dimension we end we make
1182.179|4.051|that counter a leaky counter so instead
1184.94|2.67|we end up with this decay rate hyper
1186.23|3.78|parameter which we set to something like
1187.61|3.84|0.99 usually and then what you're doing
1190.01|3.299|is you're accumulating sum of squares
1191.45|4.53|but the sum of squares is leaking slowly
1193.309|4.951|but this decay rate okay so we we still
1195.98|4.39|maintain this nice equalizing effect of
1198.26|4.299|equalizing the step sizes in steep or
1200.37|4.89|directions but we're not going to just
1202.559|3.631|converge completely to zero updates so
1205.26|3.24|that's called rmsprop
1206.19|4.08|one nice historical fun fact about
1208.5|3.96|rmsprop by the way is the way it was
1210.27|3.63|introduced was you think that it would
1212.46|3.15|be a paper that proposed this method but
1213.9|3.63|in fact it was a slide in Jeff Hinton's
1215.61|3.6|Coursera class just a few years ago and
1217.53|3.18|so Jeff Fenton just was giving this
1219.21|3.33|Coursera class and who flashed the slide
1220.71|3.27|of life oh there's this is unpublished
1222.54|3.57|but this usually works well in practice
1223.98|4.68|and do this and it's basically RMS
1226.11|4.5|problem and so I implemented it then I
1228.66|3.75|saw like better results on my
1230.61|4.02|optimization right away and I thought
1232.41|3.96|that was really funny and so in fact in
1234.63|3.84|my in paper it's not only my papers but
1236.37|6.0|many other papers people have cited this
1238.47|6.15|slide from Coursera you just slide a
1242.37|4.26|lecture six this slide just there's
1244.62|3.72|rmsprop since then this is actually now
1246.63|3.63|an actual paper and there's more results
1248.34|3.9|on exactly what it's doing and and so on
1250.26|4.5|but for a while this was really funny
1252.24|4.71|and so in this optimization perspective
1254.76|5.46|we can see a degrade here is blue and
1256.95|4.41|rmsprop is this in black and we can see
1260.22|3.839|that both of them converge quite quickly
1261.36|4.29|down here this way in this particular
1264.059|5.281|case at a grad ends up converging
1265.65|4.59|slightly faster than our miss prop but
1269.34|2.46|that's not always the case
1270.24|2.91|some usually what you see in practice
1271.8|4.23|when you train deep neural networks is
1273.15|6.27|at a grad stops too early and rmsprop
1276.03|5.37|will end up usually winning out in these
1279.42|5.21|in these methods any questions about
1281.4|3.23|that aggressor miss prop go ahead oh
1290.57|4.739|sorry where's this image
1296.21|7.71|smiley face don't you want it to just go
1298.91|6.51|quickly down this keep the 30 so you're
1303.92|2.91|saying that in some cases you might want
1305.42|4.74|to actually make faster progress in
1306.83|4.77|steeper direction the issue is in this
1310.16|2.43|particular case maybe that's true but in
1311.6|2.22|general and there are very steep
1312.59|3.36|directions you probably don't want to
1313.82|3.66|this method is saying don't make very
1315.95|2.91|fast updates in that direction slow
1317.48|3.78|yourself down so maybe in this
1318.86|3.42|particular case you'd like to go faster
1321.26|2.58|but you're kind of reading into this
1322.28|3.27|particular example and that's not true
1323.84|2.97|kind of in general in these optimization
1325.55|3.0|landscapes that neural networks are made
1326.81|3.86|up of so this ends up being a good
1328.55|14.58|strategy kind of to apply in those cases
1330.67|13.51|good yeah but so in the beginning oh by
1343.13|2.67|the way I skipped over this explanation
1344.18|4.08|of 1e negative seven but you guys can
1345.8|3.99|hopefully see that 1e negative seven is
1348.26|2.7|there just to prevent a division by zero
1349.79|2.91|it's a smoothing factor it's a hyper
1350.96|3.6|parameter usually we set it to one a
1352.7|3.3|negative five or six or seven or
1354.56|4.35|something like that in the beginning
1356.0|5.49|your cash is zero so then you increment
1358.91|5.15|you're like you still need a learning
1361.49|5.37|rate to you what you get is this
1364.06|5.56|adaptive behavior but the scale of it is
1366.86|4.17|still in your control the absolute scale
1369.62|5.52|that is still in your control you still
1371.03|5.52|need a learning rate for this good like
1375.14|3.27|what it's doing sorry just interrupt
1376.55|3.66|it's kind of doing you can look at more
1378.41|3.27|like a relative thing with respect to
1380.21|4.08|different parameters how are you causing
1381.68|11.31|the steps but the absolute global step
1384.29|10.02|is still up to you good why do we cash
1392.99|2.43|from the very beginning instead of the
1394.31|3.12|last hundred thank you
1395.42|3.78|so our mess prop is effectively doing
1397.43|4.05|what you're describing right because it
1399.2|4.26|ends up for getting sort of gradients
1401.48|5.13|from very long time ago and it's only
1403.46|5.25|really its expression at time T is only
1406.61|4.05|a function of the last few gradients but
1408.71|6.87|in an exponentially decaying weighted
1410.66|6.75|sum okay cool so that's our miss prop
1415.58|3.95|we're going to go into last update go
1417.41|2.12|ahead
1419.97|6.9|using like a window with the last let's
1421.86|8.52|say an x-squared values that are some of
1426.87|5.04|the other so you want to have a finite
1430.38|3.33|window over which you're summing up
1431.91|6.33|these gradients so would it be similar
1433.71|6.06|to our mess prop except uh so Armas prop
1438.24|2.94|is already adding up your gradients from
1439.77|3.48|the past and an exponentially weighted
1441.18|3.66|way and so you want to have a finite
1443.25|6.75|window on this or I don't think people
1444.84|12.09|have really tried you can yeah it takes
1450.0|8.01|too much memory yeah so when you once
1456.93|3.99|you're optimizing neural networks you'll
1458.01|4.53|see that X for example I 140 million
1460.92|3.48|parameters so that's taking up quite a
1462.54|3.63|lot of memory and so you don't want to
1464.4|3.47|keep track of ten previous gradients and
1466.17|3.78|so on
1467.87|4.8|okay so last update we're going to go
1469.95|2.72|into oh sure
1474.71|3.43|could you combine a degrade with
1476.67|6.42|momentum thank you for the question yes
1478.14|7.11|you could and that's this slide so so
1483.09|4.47|roughly what's happening is Adam is this
1485.25|4.32|last update that was only proposed very
1487.56|4.59|recently and it kind of has elements of
1489.57|4.05|both as you'll notice momentum is kind
1492.15|3.84|of keeping track of the first order
1493.62|3.99|moment of your of your gradient it's
1495.99|4.11|summing up the raw gradients and it's
1497.61|4.41|keeping this exponential sum and at a
1500.1|3.69|grad and so on are keeping track of the
1502.02|3.84|second moment of the gradient and it's
1503.79|4.14|exponential sum and what you end up with
1505.86|3.45|is an Adam and Adam update as you end up
1507.93|4.44|with the step that's basically take it
1509.31|4.65|it's kind of like let's see what yeah
1512.37|3.72|it's kind of like our mess property
1513.96|4.23|momentum a bit so you end up with this
1516.09|4.08|thing that looks like it's basically
1518.19|4.26|keep track of this velocity in a
1520.17|3.66|decaying way and that's your step but
1522.45|4.02|then you're also scaling it down by this
1523.83|4.68|exponentially adding up a leaky counter
1526.47|3.9|of your square gradients and so you end
1528.51|4.49|up with both in the same formula and
1530.37|5.64|that's Adam update combining those two
1533.0|5.56|okay so you're doing both momentum and
1536.01|5.7|you're also doing this adaptive scaling
1538.56|4.56|and let's see so here's the Armas prop
1541.71|3.09|actually I should have flashed this
1543.12|4.38|earlier so when you compare this
1544.8|6.27|basically rmsprop in red is the same
1547.5|5.43|thing as here except we've replaced DX
1551.07|2.19|which there was just the previous just
1552.93|2.61|agree
1553.26|4.32|currently right now we're replacing this
1555.54|4.86|gradient DX with M which is this running
1557.58|4.32|counter of our DX so if you imagine for
1560.4|2.88|example one way to look at it also is
1561.9|2.67|you're in a stochastic setting you're
1563.28|2.73|sampling mini-batches there's going to
1564.57|3.36|be lots of randomness in a forward pass
1566.01|3.78|and you get all these noisy gradients so
1567.93|3.51|instead of using any gradient at every
1569.79|3.78|single time step we're actually going to
1571.44|3.57|be using this decaying sum of previous
1573.57|3.42|gradients and it kind of stabilizes your
1575.01|5.13|gradient direction a bit and that's the
1576.99|4.56|function of the momentum here and the
1580.14|3.75|scaling here is to make sure that the
1581.55|5.93|step sizes work out relative to each
1583.89|4.86|other and steep in shell directions good
1587.48|3.07|thank you
1588.75|4.82|beta-1 and beta-2 our hyper parameters
1590.55|9.36|beta 1 usually point-9 beta 2 usually
1593.57|7.48|0.995 somewhere there so it's a hyper
1599.91|3.15|parameter you have to cross validate
1601.05|4.02|over it in my own work I found that this
1603.06|3.18|is a relatively robust settings across I
1605.07|2.43|don't actually usually end up cross
1606.24|4.44|validating these I just set them to
1607.5|4.38|fixed values usually but you can play
1610.68|8.67|with those a bit and sometimes it can
1611.88|8.61|help you a tiny bit okay cool good thank
1619.35|2.79|you so the question is can you combine
1620.49|3.48|necessary of momentum with a degrade so
1622.14|3.06|here this is like a vanilla momentum we
1623.97|3.99|saw the Nostromo momentum works better
1625.2|4.05|can you do that yes you can actually
1627.96|3.6|just read the paper about this yesterday
1629.25|4.53|and actually wasn't a paper it was a
1631.56|3.81|project report from 229 someone actually
1633.78|3.84|did that I'm not sure if there's a paper
1635.37|5.07|about it but yeah you can play with that
1637.62|5.61|certainly that's not being done here ok
1640.44|5.46|now one more thing that I so I have to
1643.23|4.5|make Adam slightly more complex here as
1645.9|4.92|you see it's incomplete so let me just
1647.73|4.29|put in the for complete version in Adam
1650.82|2.73|there's one more thing where you might
1652.02|3.21|be confused when you see it there's a
1653.55|3.87|this thing called bias correction that
1655.23|3.33|they insert there and this bias
1657.42|2.52|correction the way the reason I'm
1658.56|3.3|expanding out the loop is that the bias
1659.94|5.37|correction depends on your absolute time
1661.86|5.58|step T so T is used here and the reason
1665.31|3.36|for that is what this is doing is kind
1667.44|2.43|of like a minor point and I don't want
1668.67|3.21|anyone to be confused about this too
1669.87|4.32|much but basically it's compensated for
1671.88|4.05|compensating for the fact that mmv are
1674.19|3.0|initialized at zero so your statistics
1675.93|3.24|are kind of incorrect in the beginning
1677.19|4.53|and so what it's doing is really it's
1679.17|4.05|scaling up your mmv at the first few
1681.72|3.15|iterations so you don't end up with a
1683.22|3.36|very kind of biased estimate of the
1684.87|1.98|first and a second moment so don't worry
1686.58|3.03|about
1686.85|4.32|that too much this is only this is only
1689.61|4.05|changing your update at the very first
1691.17|5.04|few time steps as as the atom is warming
1693.66|4.83|up and so it's done in the proper way in
1696.21|5.19|terms of the statistics of mmv okay I
1698.49|4.38|don't want to go too much into that okay
1701.4|3.18|so we talked about several different
1702.87|2.97|updates and we saw that all these
1704.58|4.02|updates have this learning rate
1705.84|4.26|parameter still there and so I just
1708.6|3.0|wanted to briefly talk about the fact
1710.1|2.91|that all we still require a learning
1711.6|2.61|rate and we saw what happens with
1713.01|3.21|different traces of learning rates for
1714.21|3.42|all of these methods the question I'd
1716.22|13.5|like to pose is which one of these
1717.63|13.35|learning rates is best to use maybe not
1729.72|3.12|a well form question I'm trying to trick
1730.98|3.57|you it's a trick question so when you're
1732.84|3.72|running neural networks this is a slide
1734.55|3.9|about learning rate decay the trick
1736.56|3.6|answer is that none of those are good
1738.45|3.27|learning rates to use what you should do
1740.16|4.8|is you should use the high learning rate
1741.72|5.07|first because it amaz is faster than the
1744.96|3.42|good learning rate you see you make very
1746.79|3.42|fast progress but at some point you're
1748.38|3.24|going to be too stochastic and you can't
1750.21|3.21|converge into your main very nicely
1751.62|3.15|because you have too much energy in your
1753.42|3.72|system and you can't settle down into
1754.77|4.56|like nice parts of your loss function
1757.14|3.57|and so what you do then is you decay
1759.33|3.81|your learning rate and then you can kind
1760.71|4.62|of ride this wagon of decreasing
1763.14|3.45|learning rates and do best in all of
1765.33|2.46|them so there are many different ways
1766.59|2.73|that people decayed the learning rates
1767.79|3.66|over time and you should also decay them
1769.32|3.6|in your assignment there's step decay
1771.45|3.21|which is kind of like the simplest one
1772.92|3.63|perhaps where after one epoch of
1774.66|3.21|training data epoch is referring to
1776.55|4.74|you've seen every single training
1777.87|5.25|example one time so after say one epoxy
1781.29|3.51|decay the learning rate to by factor of
1783.12|3.6|point nine or something like that you
1784.8|4.02|can also use exponential decay or one
1786.72|4.2|number ttk there's several several of
1788.82|4.47|them are going to notes slightly
1790.92|3.69|expanding on some of the theoretical
1793.29|3.75|properties that have been proven about
1794.61|3.51|these different decays unfortunately not
1797.04|2.19|many of them applied because I think
1798.12|2.88|they're mostly from convex optimization
1799.23|3.78|literature and we're dealing with very
1801.0|3.66|different objectives but usually in
1803.01|3.15|practice I just use exponential decay or
1804.66|3.86|something like that was there a question
1806.16|2.36|good
1814.39|6.94|I see so you're asking about not
1819.559|3.62|committing to any one of these but you
1821.33|4.41|want to also like shift between them
1823.179|5.47|during training yeah I don't think
1825.74|5.25|that's a standard at all that's an
1828.649|4.471|interesting point I'm not sure I'm not
1830.99|3.419|sure when you'd want to use yeah it's
1833.12|2.7|not clear to me you could try there in
1834.409|3.63|your assignment that's a fun thing to
1835.82|4.77|try in practice I'd like to make the
1838.039|3.961|point that you almost always I find at
1840.59|3.0|least in practice right now Adam is
1842.0|3.27|usually the nice default choice to go
1843.59|4.29|with so I use Adam for everything now
1845.27|4.17|and it seems to work quite well better
1847.88|4.07|than momentum or rmsprop
1849.44|5.82|or a degrade or anything like that okay
1851.95|4.66|cool so these are all first order
1855.26|3.51|methods as we call them because they
1856.61|4.289|only use your gradient information at at
1858.77|3.69|your loss function so we evaluating the
1860.899|3.0|gradient and we basically know the slope
1862.46|3.719|in every single direction and that's the
1863.899|3.991|only thing that we use there's an entire
1866.179|3.691|set of second-order methods for
1867.89|4.289|optimization that you should be aware of
1869.87|3.36|the second-order optimization methods I
1872.179|4.201|don't want to go into too much detail
1873.23|4.679|but they end up forming a larger
1876.38|2.789|approximation to your loss function so
1877.909|2.791|they don't only approximate it with this
1879.169|3.63|basically hyperplane of like which way
1880.7|4.859|are we sloping but you also approximated
1882.799|5.071|by this Hessian which is telling you how
1885.559|3.84|your surface is curving so you don't
1887.87|3.689|only need the gradient you also need the
1889.399|6.51|Hessian and you need to compute that as
1891.559|7.051|well and you may have seen a Newton
1895.909|4.14|method say for example in 229 so in
1898.61|4.949|Newton method it's basically giving you
1900.049|5.88|an update that once you've formed your
1903.559|4.021|bowl-like Hessian approximation to your
1905.929|3.931|objective you can use this update to
1907.58|5.04|dump to jump directly to the minimum of
1909.86|5.549|that of that approximation and then you
1912.62|4.5|can rate the scheme so what's nice about
1915.409|4.831|second order methods why do people like
1917.12|4.559|these or use them especially the Newton
1920.24|5.95|method as presented here what's nice
1921.679|6.741|about this update faster convergence
1926.19|4.57|Thank You let's Hyper parameters you'll
1928.42|4.95|notice no learning rate no hyper
1930.76|4.89|parameter in this update okay and that's
1933.37|3.84|because if you see your gradient in this
1935.65|2.94|loss function in this loss function but
1937.21|3.27|you also know the curvature in that
1938.59|3.24|place and so if you approximate it with
1940.48|3.39|this bowl you know exactly where to go
1941.83|3.27|to the minimum of your approximation so
1943.87|2.82|there's no need for a learning where you
1945.1|3.69|can jump directly to that minimum of
1946.69|3.66|that approximating Bowl so that's a very
1948.79|2.88|nice feature I think those are the two
1950.35|2.58|that I had in mind you have a faster
1951.67|4.95|convergence because you're using second
1952.93|5.58|order information as well why is it kind
1956.62|8.13|of impractical to use this step update
1958.51|8.34|in training neural networks yeah so the
1964.75|3.33|issue of course is hashing say you have
1966.85|3.0|a hundred million parameter network
1968.08|3.69|you're Hessian is 100 million by 100
1969.85|6.99|million matrix and then you want to
1971.77|7.23|invert it so good luck with that so this
1976.84|3.839|is not going to happen so there are
1979.0|3.0|several kind of algorithms that I just
1980.679|2.851|like you to be aware of we're not going
1982.0|2.94|to use them in this class but just be
1983.53|2.94|aware that there's something called BFGS
1984.94|3.3|which basically lets you get away with
1986.47|3.089|not inverting the Hessian it builds up
1988.24|3.66|an approximation of the Hessian through
1989.559|3.541|successive updates that are all Rank 1
1991.9|3.12|and it kind of builds up this Hessian
1993.1|3.57|but you still need to store the Hessian
1995.02|3.18|in memory so still no good for large
1996.67|3.69|networks and then there's something
1998.2|4.26|called l-bfgs short for limited memory
2000.36|4.38|BFGS which does not actually store the
2002.46|4.17|full Hessian or its approximated in
2004.74|4.5|inverse and that's what people use in
2006.63|5.67|practice sometimes now l-bfgs
2009.24|5.7|you'll see sometimes mentioned in
2012.3|4.56|optimization literature especially what
2014.94|3.93|it works really really well for is if
2016.86|4.14|you have a single small deterministic
2018.87|3.72|function like f of X there's no
2021.0|4.08|stochastic noise like there's no
2022.59|4.44|stochasticity in F and everything fits
2025.08|3.57|in your memory then l-bfgs can usually
2027.03|4.8|crush these loss functions very easily
2028.65|5.37|but what's tricky is to extend l-bfgs to
2031.83|3.87|basically very very large data sets and
2034.02|3.21|the reason is that we're subsample in
2035.7|3.359|these mini-batches because we can't fit
2037.23|3.84|all the training data into memory so we
2039.059|3.691|sub sample mini batches and then l-bfgs
2041.07|2.88|kind of works on these mini batches and
2042.75|2.82|it's approximations end up being
2043.95|4.83|incorrect as you swap different mini
2045.57|4.589|batches and and also the stochastic see
2048.78|2.52|you have to be careful with it then you
2050.159|5.341|have to make sure that you fix this
2051.3|6.359|dropout you have to make sure that your
2055.5|3.78|function so internally l-bfgs calls your
2057.659|3.0|function many many different times is
2059.28|2.73|doing all these approximations and line
2060.659|3.841|search and stuff like that it's a very
2062.01|3.93|heavy function and so you have to make
2064.5|2.94|sure that when you use this you disable
2065.94|3.239|all sources of randomness because it's
2067.44|3.84|really not going to like it so basically
2069.179|4.051|in practice we don't use l-bfgs because
2071.28|3.36|it seems to not very not work really
2073.23|3.3|well right now compared to first urban
2074.64|3.51|methods it's basically too heavy too
2076.53|4.11|much stuff is happening and you it's
2078.15|5.22|better to just do this noisy er stuff
2080.64|5.88|but do more of it that's the trade-off
2083.37|6.15|so in summary use Adam as a good default
2086.52|4.35|choice and if you can afford to you just
2089.52|2.85|have you can afford full batch so maybe
2090.87|2.94|your data set is not very large you can
2092.37|2.94|afford to have it all in memory and do
2093.81|5.37|all the forward and negative passes in
2095.31|5.25|memory then you can look into l-bfgs but
2099.18|2.76|you won't see it in practice used in any
2100.56|3.62|large-scale setting right now although
2101.94|5.91|it's research direction right now
2104.18|5.68|alright so that concludes my discussion
2107.85|4.68|of different parameter updates decay
2109.86|4.44|your learning rates we're not going to
2112.53|5.0|look into all BFGS in this class yeah
2114.3|3.23|there's a question in the very back
2126.25|6.4|um so I'm not sure if I fully understood
2130.64|3.78|your question you're asking about so a
2132.65|3.03|dad for example it automatically decays
2134.42|3.81|your learning rate over time so would
2135.68|4.68|you use also learning rate decay if
2138.23|3.51|you're using at a grad so usually you
2140.36|3.66|see learning rate decay very common when
2141.74|3.75|you do STD or SUV momentum I actually
2144.02|5.16|I'm not sure if you'd use it with at a
2145.49|5.19|grad or or Adam I've used well your
2149.18|3.12|learning rate to eat with Adam before it
2150.68|4.05|tends to help a little bit but it kind
2152.3|8.16|of breaks some of the theory but yeah
2154.73|6.84|it's it's not yet yeah ah not not a very
2160.46|5.55|good answer there you can certainly do
2161.57|5.91|it but maybe Adam is not like Adam will
2166.01|2.7|not just monotonically make your
2167.48|3.03|learning rate zero at the end right
2168.71|3.18|because it's a leaky gradient but if you
2170.51|2.61|use data grab then certainly decaying
2171.89|2.67|the learning rate probably does not make
2173.12|6.24|sense because it's decayed automatically
2174.56|6.57|to zero in the end all right cool okay
2179.36|3.36|so we're going to go into a model
2181.13|3.06|ensembles I just very briefly like to
2182.72|4.44|talk about it because it's quite simple
2184.19|4.5|turns out that if you train multiple
2187.16|3.63|independent models on your training data
2188.69|3.51|instead of just a single one and then
2190.79|3.36|you average their results at test time
2192.2|7.26|you always get two percent extra
2194.15|6.63|performance okay so this is a not really
2199.46|3.29|a theoretical result here it's kind of
2200.78|4.08|like an object but just like in practice
2202.75|3.85|basically this is like a good thing to
2204.86|2.97|do almost always works better the
2206.6|2.22|downside of course is now you have to
2207.83|2.49|have all these different independent
2208.82|3.24|models and you need to do forward and
2210.32|3.24|forward passes of all of them and you
2212.06|4.74|have trained all of them so that's not
2213.56|5.43|ideal because you have a linear slowdown
2216.8|4.14|test time with the number of models in
2218.99|5.07|your ensemble and so there are some tips
2220.94|4.59|and tricks for using ensembles but kind
2224.06|2.88|of faking it a bit so one approach for
2225.53|2.85|example is as you're training your
2226.94|2.58|neural network you have all these
2228.38|2.73|different checkpoints usually you're
2229.52|2.91|saving them every single Epoque you save
2231.11|3.27|a checkpoint and you figure out what
2232.43|3.21|your was your validation performance so
2234.38|2.52|one thing you can do for example it
2235.64|4.41|turns out to actually give slight boost
2236.9|4.59|sometimes is you just take some
2240.05|3.36|different check points of your model and
2241.49|3.3|you do an ensemble over those that
2243.41|2.82|actually turns out to sometimes improve
2244.79|2.91|things a bit and so that way you don't
2246.23|3.3|have to train seven independent models
2247.7|3.84|you just trained one but you ensemble
2249.53|7.59|some different check points related to
2251.54|6.39|that there's a trick of four tests ok so
2257.12|2.01|what's happening here this
2257.93|3.27|is your four steps that we've seen
2259.13|4.979|before I'm keeping another set of
2261.2|4.919|parameters here X test and this X test
2264.109|5.191|is a running sum exponentially decaying
2266.119|5.131|of my actual parameter vector X and when
2269.3|3.33|I use X test and validation or test data
2271.25|3.15|it turns out that this almost always
2272.63|4.29|perform slightly better than using X
2274.4|4.59|alone okay and so this is kind of doing
2276.92|3.81|like a small like weighted ensemble of
2278.99|3.54|last previous few parameter vectors it's
2280.73|4.41|kind of a it's kind of difficult to
2282.53|4.289|interpret actually but basically one way
2285.14|3.03|to interpret it one way I can hand wave
2286.819|3.961|about why this is actually a good thing
2288.17|4.53|to do is think about optimizing your
2290.78|4.02|bowl function and you're stepping too
2292.7|3.629|much around your minimum then actually
2294.8|3.48|taking the average of all those steps
2296.329|3.451|gets you closer to the minimum okay so
2298.28|2.7|that's the hand waving I can do for y
2299.78|2.069|this actually ends up working slightly
2300.98|3.15|better
2301.849|3.541|so that's model ensembles I had to
2304.13|3.84|discuss model ensembles because we're
2305.39|4.199|going to look into dropout and this is a
2307.97|4.29|very important technique that you will
2309.589|5.421|be using and implementing and so on so
2312.26|5.22|the idea for dropout is very interesting
2315.01|3.76|what you do with dropout is you as
2317.48|3.54|you're doing a forward pass of your
2318.77|4.86|neural network you will randomly set
2321.02|6.12|some neurons to zero in the forward pass
2323.63|5.04|okay so just to clarify what you will do
2327.14|3.81|is as you're doing a forward pass of
2328.67|5.639|your data X you're computing say in this
2330.95|6.06|function your first hidden layer is the
2334.309|3.841|non-linearity of w1 times X plus b1 so
2337.01|3.93|that's the activations of the first
2338.15|5.58|inner layer and then I will compute here
2340.94|4.679|a mask of binary numbers either 0 or 1
2343.73|4.05|based on whether or not numbers between
2345.619|4.95|0 & 1 are smaller than P which we here
2347.78|5.039|see is point 5 so this u1 is a binary
2350.569|4.111|mask of zeros and ones half in half and
2352.819|3.601|then we multiply that onto our hidden
2354.68|3.419|activations effectively dropping half of
2356.42|4.139|them so we've computed all the
2358.099|4.2|activations h1 the hidden layer and then
2360.559|4.681|we drop half the units at random and
2362.299|6.241|then we do 2nd and then we drop half of
2365.24|4.319|them at random okay and of course this
2368.54|2.13|is only the forward pass
2369.559|3.211|the backward pass has to be
2370.67|4.949|appropriately adjusted as well so these
2372.77|4.589|drops have to be also back propagated
2375.619|3.661|through so remember to do that when you
2377.359|3.271|implement dropout so it's not only in
2379.28|2.549|the forward pass you drop but in the
2380.63|3.3|backward pass you have to back propagate
2381.829|3.931|through multiplying by u2 and by u 1 so
2383.93|3.12|you kill gradients basically in places
2385.76|3.36|where you've dropped a unit
2387.05|5.1|okay so you might be thinking when I
2389.12|4.62|showed you this for the first time how
2392.15|4.53|how does this make any sense at all and
2393.74|4.65|how is this good idea why would you want
2396.68|3.03|to compute your neurons and then set
2398.39|5.19|them at random to zero how does that
2399.71|7.37|make any sense whatsoever so I don't
2403.58|3.5|know let's let's what you guys think
2407.56|18.22|go ahead would it prevent overfitting in
2412.37|14.7|what sense okay you're roughly getting
2425.78|3.45|the right intuition so you're saying it
2427.07|3.6|will prevent overfitting because if I'm
2429.23|3.45|only using half of my network then
2430.67|3.51|roughly I have like smaller capacity I'm
2432.68|3.12|only using half of my network any one
2434.18|3.54|time and with smaller networks there's
2435.8|3.18|only like basically there's only so much
2437.72|2.67|I can do with half a network then as a
2438.98|4.53|full network so it's kind of like a
2440.39|10.11|control of your of your variance in
2443.51|9.15|terms of what you can represent good yep
2450.5|3.24|yep okay I would like to be slightly
2452.66|2.7|careful with the terms that I like
2453.74|3.15|bias-variance tradeoff and so on I
2455.36|3.06|haven't really we're not going to do
2456.89|3.44|that too much but yeah basically have a
2458.42|7.89|smaller model it's harder to overfit
2460.33|7.54|good okay you're saying it's like having
2466.31|2.73|many ensembles of different neural
2467.87|15.99|networks we're going to go into that
2469.04|18.9|point in a bit okay so you're saying
2483.86|6.15|that it's forcing all the neurons to be
2487.94|4.56|useful because if one of them gets
2490.01|5.52|dropped out then if that if that one was
2492.5|4.77|the only one that was used upstairs
2495.53|3.81|okay I have a better way of rephrasing
2497.27|3.66|that point in my next slide let's look
2499.34|3.63|at a particular example instead of hand
2500.93|3.36|waving okay suppose that we are trying
2502.97|3.75|to compute the cat score in the neural
2504.29|4.43|network okay and the idea here is that
2506.72|4.2|you have all these different units and
2508.72|3.58|what dropout is doing is it's forcing
2510.92|3.6|there many ways to look at dropout but
2512.3|4.02|one of them is it's forcing your code
2514.52|4.83|your representation for what the image
2516.32|4.59|was about to be redundant because you
2519.35|3.03|need that redundancy because your
2520.91|3.6|about to in a way that you can't control
2522.38|3.9|get half of your network dropped off and
2524.51|3.69|so you need to base your cat score on
2526.28|3.69|many more features if you're going to
2528.2|3.75|correctly compute the cat score because
2529.97|3.96|any any one of them you can't rely on it
2531.95|3.69|because it might be dropped and so
2533.93|3.12|that's one way to look at it so in this
2535.64|2.97|case we can still classify cat score
2537.05|3.27|properly even if we don't have access to
2538.61|5.28|whether or not it's very or mischievous
2540.32|5.52|and so so that's one interpretation of
2543.89|3.69|drop out ok another interpretation of
2545.84|4.35|drop out is as was mentioned in terms of
2547.58|4.56|an ensemble so drop out is effectively
2550.19|5.01|can be looked at as training a large
2552.14|6.98|ensemble of models that are basically
2555.2|6.09|sub networks of this one large network
2559.12|4.69|but they kind of share parameters in a
2561.29|4.56|weird way so to understand this you have
2563.81|3.6|to notice the following if we do a
2565.85|3.54|forward pass and we randomly drop off
2567.41|3.12|some of the units then in backward pass
2569.39|3.18|think about what happens with the
2570.53|4.23|gradient right so suppose we've branded
2572.57|3.57|randomly dropped off these units in a
2574.76|3.12|backward pass we're back propagating
2576.14|5.16|through the masks that were induced by
2577.88|4.77|the drop out so in particular only the
2581.3|3.21|neurons that were used in the forward
2582.65|3.0|pass will actually be updated or have
2584.51|2.97|any gradients flowing through them
2585.65|4.32|because any neuron that was shut off to
2587.48|4.38|zero no gradient will flow through it
2589.97|2.94|and it's weights to its previous layer
2591.86|3.21|will not be updated
2592.91|5.1|so effectively any neuron that was
2595.07|4.62|dropped out its connections to the
2598.01|4.2|previous layer will not be updated and
2599.69|4.29|it'll just it's as if it wasn't there so
2602.21|3.87|really with the drop out masks your sub
2603.98|4.59|sampling a part of your neural network
2606.08|4.17|and your only training that neural
2608.57|3.93|network on that single example that you
2610.25|3.81|have at that point in time so each
2612.5|4.79|binary mask is one model and gets
2614.06|3.23|trained on only one data point
2624.8|9.45|okay I can try to repeat that it came
2631.83|9.54|from somewhere here I'm onto you guys
2634.25|13.3|okay but do people actually understand
2641.37|8.61|this or not spur okay so when you drop a
2647.55|3.84|unit you drop you drop a neuron I wish I
2649.98|2.91|had the example of the neuron right but
2651.39|3.15|if I drop its value I multiply its
2652.89|3.18|output by zero then its effect on the
2654.54|3.33|last function there's no effect right so
2656.07|3.36|it's gradient will be zero because it's
2657.87|3.78|Valley was not used in computing the
2659.43|4.53|loss and so its weights will not get an
2661.65|3.96|update and so it's as if we've sampled a
2663.96|3.54|part of the network and we only trained
2665.61|3.15|that single data point that currently
2667.5|3.12|came to the network we only trained on
2668.76|3.33|it and every time we do a forward pass
2670.62|3.26|we subsampled a different part of your
2672.09|3.69|neural network but they all share
2673.88|4.0|parameters so it's kind of like a weird
2675.78|3.96|ensemble of lots of different models
2677.88|4.05|altering the one data point but they all
2679.74|5.13|share parameters so that's kind of
2681.93|10.25|roughly the the idea here does that make
2684.87|7.31|sense okay cool go ahead question
2693.62|6.42|usually say 50% is a very rough
2696.59|3.45|approximation you can use
2702.89|4.8|yeah the weight array is the same size
2704.6|4.35|so in this in this forward pass you'll
2707.69|3.6|notice we actually compute all the
2708.95|4.59|neurons H we compute them just as we did
2711.29|3.72|before all the neurons get computed but
2713.54|8.18|then half of the values will get drops
2715.01|16.35|to zero so nothing changes there oops oh
2721.72|11.62|yes I will see that in a bit good would
2731.36|3.3|you be making the matrix sparse so can
2733.34|3.6|you take advantage of some sparse matrix
2734.66|3.39|computations so instead of computing all
2736.94|2.25|the HS you want to only compute the
2738.05|2.34|neurons that are not being dropped and
2739.19|4.05|in that case you want to do sparse
2740.39|3.81|updates so you could in theory but I
2743.24|4.01|don't think that's done usually in
2744.2|3.05|practice we don't worry too much
2759.25|5.59|oh I see so in every single forward pass
2763.01|3.3|we sample these right we sample the
2764.84|3.42|masks at every single forward pass and
2766.31|5.1|so you always get a different like sub
2768.26|4.98|network that you're training so every
2771.41|3.57|single iteration we get a mini batch we
2773.24|2.88|sample our noise pattern for what we're
2774.98|2.64|going to drop out and we do a forward
2776.12|3.3|and backward pass and update the
2777.62|10.71|gradient and we keep iterating this over
2779.42|10.38|and over again oh I see so your question
2788.33|3.57|is can we add like some how cleverly
2789.8|3.96|choose the binary mask in like a way
2791.9|3.81|that best optimizes the model or
2793.76|3.24|something like that not really I don't
2795.71|7.43|think that's done or anyone has looked
2797.0|8.329|into it too much good sorry
2803.14|4.53|oh yes so I'm going to get into that in
2805.329|3.93|one slide in next slide we're going to
2807.67|13.829|look at this time I'll take up one last
2809.259|13.951|question good so two questions one is
2821.499|2.76|can you use drop out to different
2823.21|3.079|amounts in different layers you can
2824.259|4.171|there's nothing stopping you I it's
2826.289|3.371|intuitively you want to apply stronger
2828.43|3.179|drop out if you need more regularization
2829.66|3.179|so there's a layer that has a huge
2831.609|2.88|amount of parameters will see that
2832.839|3.091|income that's in one example you want to
2834.489|2.911|apply stronger drop out there
2835.93|3.899|conversely there might be some layers
2837.4|4.32|that we'll see what convolution networks
2839.829|3.96|early on the convolutional layers are
2841.72|3.69|very small you don't we usually apply as
2843.789|2.671|much drop out there so it's quite common
2845.41|2.49|for example in the commercial Network
2846.46|2.819|and I'll go into this in a bit you start
2847.9|2.639|off with low dropout and then you scale
2849.279|3.121|that up over time so the answer to that
2850.539|7.77|is yes and I forgot your second question
2852.4|7.859|was it oh can you instead of units drop
2858.309|2.851|out just individual weights you can and
2860.259|2.401|that's called something called drop
2861.16|3.629|connect we won't go into too much in
2862.66|8.07|this class but there's a way to do that
2864.789|7.141|as well okay now at test time a test
2870.73|2.7|time ideally what you want to do is
2871.93|3.75|we've introduced all this noise right
2873.43|3.659|into the forward pass and so what we'd
2875.68|3.689|like to do now at test time is we'd like
2877.089|3.811|to integrate out all that noise and a
2879.369|2.94|Monte Carlo approximation to that would
2880.9|3.209|be something like you have a test image
2882.309|3.151|that you'd like to classify you can do
2884.109|3.24|many forward passes with many different
2885.46|4.109|settings of your binary masks and you're
2887.349|4.02|only using the sub networks and then you
2889.569|4.02|can average across all those probability
2891.369|4.261|distributions so that would be great but
2893.589|3.091|unfortunately it's not very efficient so
2895.63|2.609|it turns out that you can actually
2896.68|3.629|approximate this process to some degree
2898.239|4.08|as Jeff Fenton pointed out and when they
2900.309|3.81|first introduced dropout and the way
2902.319|3.811|we'll do this intuitively you want to
2904.119|3.21|take advantage of all your neurons you
2906.13|2.699|don't want to be dropping them out at
2907.329|2.97|random so we're going to try to come up
2908.829|3.75|with a way where we can leave all the
2910.299|4.98|neurons turned on so do no dropout in a
2912.579|4.2|forward pass on a test image but we have
2915.279|5.58|to actually be careful with how we do
2916.779|5.82|this so we can so in a for pass for test
2920.859|4.25|images we're not going to drop any units
2922.599|5.4|but we have to be careful with something
2925.109|5.95|and basically one way to get at what the
2927.999|5.84|issue is is suppose that this was a
2931.059|5.761|neuron and it's got two inputs and
2933.839|5.111|suppose that with all these inputs press
2936.82|3.84|at test time so we're not dropping unit
2938.95|3.39|so we're a test time these two have some
2940.66|3.15|activations and the output of this
2942.34|5.88|neuron gets computed to be some value of
2943.81|7.89|x you have to compare this value of x to
2948.22|5.94|what the neurons output would be during
2951.7|4.86|training time in expectation okay
2954.16|4.59|because in in training time this dropout
2956.56|3.18|masks vary randomly and so there's many
2958.75|3.57|different cases that could have happened
2959.74|4.68|and in different in those cases the
2962.32|3.78|outputs of this neuron would be possibly
2964.42|2.85|in a different scale and you have to
2966.1|4.95|worry about this so let me show you
2967.27|6.0|exactly what this means I think so
2971.05|3.39|during test this neuron computes say
2973.27|3.42|there's no non-linearity we're only
2974.44|4.86|looking at a linear neuron during Tres
2976.69|4.62|test this activation becomes w0 which is
2979.3|4.41|the weight here times X plus W 1 times y
2981.31|3.99|ok so that's what we want to compute at
2983.71|3.84|test time and the reason we have to be
2985.3|4.11|careful is that during training time the
2987.55|3.69|expected output of a in this particular
2989.41|3.27|case would have been quite different so
2991.24|2.91|we have four possibilities we could have
2992.68|4.17|dropped one or the other or both or none
2994.15|4.38|so in those four possibilities we would
2996.85|2.76|have computed different values and if
2998.53|3.21|you actually crunch through this math
2999.61|5.4|you'll see that when you reduce it you
3001.74|7.23|end up with 1/2 of w0 X plus w1 times y
3005.01|5.97|so in expectation at training time the
3008.97|5.04|output of this neuron was actually a
3010.98|5.58|half of what it is at test time okay and
3014.01|4.59|so when you want to use all the neurons
3016.56|3.51|at test time you have to compensate for
3018.6|2.55|this additional half and that's half by
3020.07|2.73|the way is coming from the fact that
3021.15|3.87|we've dropped units with probability of
3022.8|7.26|1/2 and so that's why this ends up being
3025.02|8.13|1/2 and so with probability point 5 all
3030.06|5.46|inputs in a forward pass so basically if
3033.15|4.68|we did not do this then we end up having
3035.52|3.78|too large of an output compared to what
3037.83|3.96|we had in expectation during training
3039.3|4.11|time and your output distribution would
3041.79|2.7|change and basically things in the
3043.41|2.52|neural network would break because
3044.49|3.3|they're not used to seeing such large
3045.93|3.15|outputs from all the neurons and so you
3047.79|4.56|have to compensate for that and you have
3049.08|4.62|to squish down so now you're using all
3052.35|2.91|your things instead of just half of the
3053.7|3.6|things but you have to squash down the
3055.26|5.4|activations to get back the to recover
3057.3|5.55|your expected output ok this is actually
3060.66|3.36|a tricky point but I think I was told
3062.85|3.69|once the story that when Geoff Hinton
3064.02|4.95|came up with dropout in the beginning he
3066.54|3.87|actually didn't fully come up with this
3068.97|3.48|part so we tried dropout
3070.41|4.47|it didn't work and actually the reason
3072.45|4.56|it didn't work is he he missed out on
3074.88|3.659|this tricky point actually admittedly
3077.01|4.02|and so you have to scale your
3078.539|3.78|activations at test time down because of
3081.03|1.95|this effect and then everything works
3082.319|3.27|much better
3082.98|3.27|so at test time just to show you what
3085.589|3.48|this looks like
3086.25|5.13|we basically compute these neural nets
3089.069|4.351|as normal so we compute the first layer
3091.38|4.83|second layer but now at test time we
3093.42|4.23|have to multiply by P so for example at
3096.21|3.48|P is 1/2 we're dropping out with 1/2
3097.65|3.929|probability that were scaling down the
3099.69|3.84|activation so that the expectation the
3101.579|3.421|expected output now is the same as
3103.53|3.839|expected output in the training time and
3105.0|5.94|so at this time you actually recover
3107.369|5.041|full dropout and the expected outputs
3110.94|16.59|are matching and this actually works
3112.41|17.129|really well good so in training we're
3127.53|4.35|half the time dropping these inputs and
3129.539|4.951|so you end up with some some expected
3131.88|3.719|output from this neuron I don't think
3134.49|3.42|there's an issue at train time basically
3135.599|3.541|it's just the discrepancy between train
3137.91|2.61|and test like if you're using all your
3139.14|3.51|neurons instead of dropping them there's
3140.52|3.75|discrepancy so either you can correct it
3142.65|3.929|at test time or you can use what we call
3144.27|4.259|inverted dropout which I'll show you in
3146.579|2.101|a bit so let me just get to that in a
3148.529|2.671|bit
3148.68|4.349|so dropout summary if you want to use
3151.2|4.44|dropout drop your units with probability
3153.029|4.08|of with keeping the probability of P and
3155.64|3.33|then at test time don't forget to scale
3157.109|4.47|them so if you do this your neural
3158.97|4.559|networks will do will work better ok and
3161.579|3.26|don't forget to also back propagate the
3163.529|4.52|masks which I'm not showing here an
3164.839|5.561|inverted dropout by the way to is to
3168.049|3.671|take care of this discrepancy between
3170.4|3.389|the train and test distribution in a
3171.72|3.66|slightly different way in particular
3173.789|4.141|what we'll do is we're changing this
3175.38|4.469|step here so before you one was a binary
3177.93|3.33|mask of zeros and ones what we're now
3179.849|3.631|going to do is we're going to do the
3181.26|3.779|scaling here at training time so we're
3183.48|3.0|going to scale down the activations at
3185.039|3.691|training time or rather scale them up
3186.48|3.78|because if P is 0.5 then we're boosting
3188.73|3.299|activations at train time by 1/2 and
3190.26|3.72|then at test time we can leave our code
3192.029|3.78|untouched right so we're doing the
3193.98|3.119|boosting of the activations at train
3195.809|4.681|time we're making everything
3197.099|5.641|artificially greater by 2x and then a
3200.49|3.22|test time we're supposed to have but now
3202.74|2.379|we're just going
3203.71|2.52|recover the clean expressions because
3205.119|3.631|we've done the scaling a training time
3206.23|4.29|so now you'll be you'll be properly
3208.75|3.63|calibrated in expectations between the
3210.52|3.079|train and test of every neuron in the
3212.38|5.55|network
3213.599|5.74|okay so let's wrap it so use inverted
3217.93|2.97|dropout that's the most common one to
3219.339|3.27|use in practice so in fact it really
3220.9|3.81|comes down to a few lines and then the
3222.609|4.711|backward pass changes a bit but the
3224.71|4.44|network's almost always work better with
3227.32|3.019|this good unless you're severely
3229.15|17.699|underfitting
3230.339|18.28|good thank you for the question does
3246.849|3.721|that depend on you having a linear
3248.619|3.931|response activation function it does so
3250.57|3.72|once you have nonlinearities in there
3252.55|3.78|then these expectations aren't actually
3254.29|4.89|exact and that's why this is an as I
3256.33|4.259|mentioned here approximation it's an
3259.18|2.85|approximation to valuing the fallen
3260.589|2.581|sample and one of the reasons in
3262.03|2.28|approximation is because once you
3263.17|2.88|actually have nonlinearities in the
3264.31|3.0|picture then these expected outputs are
3266.05|4.049|all kind of screwed up because of the
3267.31|3.6|nonlinear effects on top of these so
3270.099|4.671|yeah that's a good question thank you
3270.91|3.86|for pointing that I'll go ahead
3277.07|8.64|I see you're saying that the inverted
3283.88|3.27|drop and drop out are not equivalent so
3285.71|3.84|doing a very rapid or not is not
3287.15|9.0|equivalent because of the Denali Ortiz
3289.55|9.84|um I'd have to think about it maybe
3296.15|3.51|maybe you're right ah yeah maybe you're
3299.39|5.66|right
3299.66|5.39|yeah yeah good
3315.05|12.81|so we're P here is 0.5 right so it's
3317.39|11.82|probably a point 5 or dropping I see so
3327.86|2.31|sometimes you have more dropped and less
3329.21|2.55|drop then you have an entire
3330.17|2.97|distribution like in some forward passes
3331.76|3.33|you'll have fewer neurons than half or
3333.14|3.77|more neurons and a half but I think all
3335.09|3.81|of this is just about expectations in
3336.91|4.18|expectation you're dropping a half and
3338.9|3.06|so that's the correct thing to use even
3341.09|2.31|though there's some randomness on
3341.96|4.38|exactly the amount that actually end up
3343.4|5.7|being dropped okay great
3346.34|4.26|oh yeah this is a placeholder slide to
3349.1|3.27|tell you guys a fun story about drop out
3350.6|4.26|so I was in a deep learning summer
3352.37|3.42|school in 2012 and Geoff Hinton was for
3354.86|3.27|the first time or at least the first
3355.79|3.96|time I saw it presenting dropout and so
3358.13|3.84|he's basically just saying okay set your
3359.75|4.2|neurons to zero at random and the test
3361.97|3.57|time just boost the activations and this
3363.95|2.94|always works better better and we're
3365.54|2.64|like wow that's interesting and so a
3366.89|2.91|friend of mine sitting next to me he
3368.18|3.06|just pulled up his laptop right there he
3369.8|3.12|has a station of his university machines
3371.24|3.3|and implemented right there during the
3372.92|3.24|talk and by the time geoff hinton
3374.54|3.03|finished the talk he was getting better
3376.16|2.52|results and getting actually
3377.57|2.85|state-of-the-art report her like
3378.68|4.26|accuracies on his data said that he was
3380.42|4.74|working with so that's the that's the
3382.94|5.1|fastest I've seen someone go like get an
3385.16|4.47|extra few boos percent it was right
3388.04|2.94|there and then horology fintan was
3389.63|3.15|getting to talk so I thought that was
3390.98|2.82|really funny there's very few times that
3392.78|2.97|actually this something like this
3393.8|3.93|happens and so drop out is a great thing
3395.75|4.41|because it's one of those few advances
3397.73|5.04|that is very simple and it always works
3400.16|3.75|just better and there's very few of
3402.77|3.03|those kinds of tips and tricks that
3403.91|3.93|we've picked up and I guess the question
3405.8|4.44|is how many more simple things like
3407.84|3.15|dropout are there that just give you 2%
3410.24|5.34|boost
3410.99|5.82|always so we don't know okay so I was
3415.58|4.91|going to go on at this point into
3416.81|5.61|gradient checking ah but I think I
3420.49|3.85|actually I decided that I'm going to
3422.42|3.15|skip this because I'm tired of all the
3424.34|2.64|neural network like we've been talking
3425.57|2.61|about lots of details of training neural
3426.98|2.76|networks and I think you guys are tired
3428.18|3.21|as well and so I'm going to skip
3429.74|3.36|gradient checking because it's quite
3431.39|2.79|well described here in notes so I
3433.1|2.37|encourage you to go through it
3434.18|4.53|gradient checking is kind of a tricky
3435.47|5.13|process it takes a bit of time to
3438.71|4.47|appreciate all the difficulties with the
3440.6|4.32|process and so just read through it I
3443.18|3.81|don't think there's anything I can hand
3444.92|3.69|wave around to make it more interesting
3446.99|2.4|to you and so I would encourage you to
3448.61|2.43|just check it out
3449.39|3.24|meanwhile we're going to jump right
3451.04|5.79|ahead and going to commercial networks
3452.63|6.69|and look at pictures okay so couple
3456.83|7.5|neural networks look like this this is a
3459.32|6.06|leanette five from 1980 roughly and so
3464.33|2.64|we're going to go into details of how
3465.38|2.73|commercial neural networks work and in
3466.97|2.399|this class we're not actually going to
3468.11|2.52|going to do any of the low-level details
3469.369|3.211|I'm just going to try to give you
3470.63|3.45|intuition about how this field came
3472.58|4.17|about some of the historical context and
3474.08|3.9|just complex all networks in general so
3476.75|2.58|if you'd like to talk about the history
3477.98|4.08|of convolutional networks you have to go
3479.33|4.38|back to roughly 1960s to experiments of
3482.06|4.799|hooble and Wiesel
3483.71|5.58|so in particular they were studying the
3486.859|4.561|prime of the visual cortex in a cat and
3489.29|4.71|they were studying an early visual area
3491.42|5.1|in the cat brain as the cat was looking
3494.0|3.869|at patterns on the screen and they ended
3496.52|4.17|up actually winning a Nobel Prize for
3497.869|4.351|this sometime later for these
3500.69|3.45|experiments and so I'd like to show you
3502.22|4.2|what these experiments look like just so
3504.14|4.65|they're really fun to look at so I
3506.42|4.56|pulled up a YouTube video here and so
3508.79|3.9|what's going on here is the cat is fixed
3510.98|3.21|in position and we're recording from its
3512.69|3.03|cortex somewhere in the first visual
3514.19|3.63|area of processing which is in the back
3515.72|3.57|of your brain called v1 and now we're
3517.82|3.24|showing different light patterns to the
3519.29|3.84|cat and we're recording and hearing the
3521.06|3.36|neurons fire for different stimuli so
3523.13|3.44|let's look at how this experiment looked
3524.42|2.15|like
3528.58|3.38|I don't know if you guys can hear
3543.18|4.23|so nothing happens when it goes this way
3544.86|10.47|and then he's going to make it go that
3547.41|13.41|way okay I don't if you guys can hear it
3555.33|7.17|all the way back okay so this is one
3560.82|2.88|neuron in the v1 cortex and through
3562.5|2.52|experiments like this they basically
3563.7|3.69|figured out that there are these cells
3565.02|3.96|and they seem to turn on four edges in a
3567.39|3.06|particular orientation and they get
3568.98|3.51|excited about edges in one orientation
3570.45|6.72|any other norian tation does not excite
3572.49|5.79|them okay and so like this through a
3577.17|4.83|long process this is like a ten minute
3578.28|5.07|video so we're not gonna go to basically
3582.0|3.03|for a long time they experimented and
3583.35|3.39|they came up with a model of how the
3585.03|5.1|visual cortex processes information in
3586.74|6.06|the brain and so they found several
3590.13|4.62|things the gate that ended up leading to
3592.8|3.75|their nobel prize for example they
3594.75|4.41|figured out that the cortex is arranged
3596.55|5.55|retina topically the visual cortex and
3599.16|4.38|what that means is that let's see
3602.1|3.27|where's my printer basically nearby
3603.54|3.96|cells in the cortex so this is cortical
3605.37|4.11|tissue unfolded nearby cells in your
3607.5|4.29|cortex are actually processing nearby
3609.48|3.99|areas in your visual field so your
3611.79|3.27|whatever is mapping onto your recognized
3613.47|4.02|process nearby in your brain this
3615.06|5.49|locality is preserved in your processing
3617.49|5.04|and they also figured out that there was
3620.55|3.63|an entire hierarchy of these rows what's
3622.53|3.21|called simple cells and they responded
3624.18|3.54|to a particular orientation of an edge
3625.74|3.71|and then there were all these other
3627.72|4.02|cells that had more complex system
3629.45|4.03|responses so for example some cells
3631.74|3.24|would be turning off for a specific
3633.48|3.12|orientation but we're slightly
3634.98|2.97|translationally invariant so they don't
3636.6|3.06|care about the specific position of the
3637.95|3.84|edge but they only cared about the
3639.66|3.36|orientation and so they hypothesized
3641.79|2.31|through all these experiments that the
3643.02|3.69|original cortex has this kind of
3644.1|3.93|hierarchical organization where you end
3646.71|3.93|up with simple cells that are feeding to
3648.03|4.59|other cells called complex cells and etc
3650.64|3.75|and these cells are building on top of
3652.62|3.3|each other and these simple cells in
3654.39|3.42|particular have these relatively local
3655.92|3.39|receptive fields and then we're building
3657.81|3.15|up more more complex kind of
3659.31|3.62|representations in the brain through
3660.96|4.11|successive layers of representation and
3662.93|5.11|so these were experiment by hobo and
3665.07|6.15|easel and of course they some people are
3668.04|5.07|trying to reproduce this in in computers
3671.22|3.93|and try to model the visual cortex with
3673.11|3.39|code and so one of the first examples of
3675.15|4.199|this was the neurocognitive trial
3676.5|5.91|Fukushima and he basically uh ended up
3679.349|5.341|setting up a layered architecture with
3682.41|3.93|these local receptive sales that
3684.69|3.45|basically these are neurons that look at
3686.34|3.3|a small region of the input and then he
3688.14|4.62|stacked up layers and layers of these
3689.64|4.74|and so he had these simple cells and
3692.76|2.91|then complex cells simple cells complex
3694.38|3.0|cells in the sandwich of simple and
3695.67|4.17|complex cells building up into a
3697.38|4.14|hierarchy now back then though in 1980s
3699.84|3.48|back propagation was still not really
3701.52|3.3|around and so Fukushima had an
3703.32|3.42|unsupervised learning procedure for
3704.82|3.81|training these networks with like a
3706.74|4.05|clustering scheme but this was not back
3708.63|4.68|propagate at the time but it had this
3710.79|3.98|idea of successive layers small cells
3713.31|4.49|building up on top of each other and
3714.77|5.2|then Yela come to call this experiments
3717.8|3.819|further and he kind of built on top of
3719.97|4.41|who she must work and he kept the
3721.619|4.051|architecture and layout but what he did
3724.38|3.66|was actually trained these networks with
3725.67|4.439|back propagation and so for example he
3728.04|4.05|trained different classifiers for digits
3730.109|3.871|or letters and so on and so trained all
3732.09|3.6|of it with backdrop and they actually
3733.98|5.97|ended up using this in complex systems
3735.69|6.33|that read check they read off like
3739.95|4.83|digits from postal mail service and so
3742.02|5.31|on and so common let's actually go back
3744.78|4.65|to quite a long time ago to 1990s and so
3747.33|4.23|on when Jana Kuhn was using them back
3749.43|5.82|then but they were quite small okay
3751.56|5.22|and so in 2012 is when the comment
3755.25|2.88|started to get quite a bit bigger so
3756.78|2.88|this was the paper from that I keep
3758.13|3.57|referring to from Alex Khrushchev's key
3759.66|4.08|Ilya sutskever and Jeff Fenton they took
3761.7|3.72|all of image net image net as the data
3763.74|3.629|set that comes actually from a face lab
3765.42|3.72|from our lab so it's a million images
3767.369|3.361|with thousand classes huge amount of
3769.14|3.12|data you take this model which is
3770.73|3.27|roughly 60 million parameters and it's
3772.26|4.02|called an Alex net based on the first
3774.0|3.63|name of Alex Khrushchev ski these
3776.28|2.97|networks were going to see that they
3777.63|5.01|have names so this is Alex net there's a
3779.25|6.06|vgg net a Zenith net Google net
3782.64|4.41|there's several nets so just like this
3785.31|4.26|one is Linnet and so we give them names
3787.05|4.02|so this was Alex net and it was the one
3789.57|3.48|that actually outperformed by quite a
3791.07|4.23|bit all the other algorithms what's
3793.05|4.23|interesting to note historically is the
3795.3|5.16|difference between Alex net in 2012 and
3797.28|4.8|the Linnet in 1990s there's basically
3800.46|3.27|very very little differences when you
3802.08|3.87|look at these two different these two
3803.73|4.619|networks this one used I think sigmoids
3805.95|3.399|or 10 H 10 H probably and this one used
3808.349|3.52|relu
3809.349|4.17|and it was bigger and deeper and he was
3811.869|5.25|training GPU and it had more data and
3813.519|5.49|that's basically it that's the only like
3817.119|3.24|that's roughly the difference and so
3819.009|2.881|really what we've done is we figured out
3820.359|3.11|better ways of course initializing them
3821.89|4.29|and it works better with batch norm and
3823.469|4.3|rel lose work much better but other than
3826.18|4.169|that it was just scaling up both the
3827.769|4.35|data and the compute uh but for the most
3830.349|3.75|part the architecture was quite similar
3832.119|3.66|and we've done a few more tricks like
3834.099|4.051|for example they used big filters we'll
3835.779|4.47|see that we use much smaller filters we
3838.15|4.5|also now this is only a few tens of
3840.249|4.681|layers we now have 150 layer commnets so
3842.65|4.139|we really just scale this up quite a bit
3844.93|3.149|in some respects but otherwise the basic
3846.789|5.19|concept of how you process information
3848.079|6.75|is similar okay so comments are now
3851.979|4.74|basically everywhere ah so they can do
3854.829|3.811|all kinds of things like classify things
3856.719|3.51|of course they're very good at retrieval
3858.64|5.129|so if you show them an image they can
3860.229|6.0|retrieve other images like it they can
3863.769|4.921|also do detection so here they're
3866.229|5.04|detecting dogs or horses or people and
3868.69|4.109|so on you'll this might be used for
3871.269|3.391|example in self-driving cars I'll have
3872.799|3.3|this on the next slide they can also do
3874.66|3.119|semantic segmentation so every single
3876.099|4.591|pixel is labeled for example as a person
3877.779|6.03|or a road or tree or sky or building so
3880.69|5.519|that segmentation so they're used in
3883.809|5.55|cars for example here's an nvidia tegra
3886.209|4.5|which is a small embedded GPU we can run
3889.359|2.7|commnets on these and for example this
3890.709|3.39|might be useful in the self-driving car
3892.059|3.571|where you can identify all the you can
3894.099|4.89|basically do perception of around you of
3895.63|5.55|things around you come that's are
3898.989|3.451|identifying faces probably if you some
3901.18|2.879|of your friends are tagged on facebook
3902.44|3.059|automatically it's almost certainly I
3904.059|3.93|would guess at this point come that
3905.499|4.02|they're used on video classification on
3907.989|4.171|YouTube identifying what's inside
3909.519|3.99|YouTube videos they're used in this is a
3912.16|3.539|project from Google that was very
3913.509|3.661|successful where basically Google is
3915.699|3.211|really interested in taking Street view
3917.17|4.559|images and automatically reading out
3918.91|4.379|house numbers from them okay and turns
3921.729|3.54|out this is a perfect task for a ComNet
3923.289|4.891|so they had lots of human laborers
3925.269|5.04|annotate huge amounts of this data and
3928.18|3.72|then put a giant comment on it and it
3930.309|3.24|ended up working almost as well as a
3931.9|3.24|human and that's a thing that will see
3933.549|4.081|throughout that this this stuff works
3935.14|3.379|really really well they can estimate
3937.63|5.13|poses
3938.519|6.461|they can play computer games they detect
3942.76|5.25|all kinds of cancer or something like
3944.98|6.33|that and bye-bye-bye images they can
3948.01|6.39|read Chinese characters recognize street
3951.31|5.31|size this is I think segmentation of
3954.4|3.87|neural tissue they can also do things
3956.62|3.66|that are not visual so for example they
3958.27|3.87|can recognize speech so contents have
3960.28|4.44|been used for speech processing they've
3962.14|4.61|been used also for text documents so you
3964.72|4.02|can feed text into commnets as well
3966.75|4.24|they've been used for to recognize
3968.74|4.38|different types of galaxies they've been
3970.99|4.53|used to in recent cattle competition to
3973.12|3.96|recognize different whales so this is a
3975.52|2.73|particular whale there was like hundred
3977.08|2.43|whales or something like that and you
3978.25|3.45|have to just use a color to recognize
3979.51|4.44|specific individual whales so this whale
3981.7|3.99|by the pattern of its you know white
3983.95|3.78|spots on its head is a particular whale
3985.69|3.08|that become that has to recognize so
3987.73|3.15|it's amazing that that works at all
3988.77|4.0|they're using satellite images quite a
3990.88|3.12|bit because now there are several
3992.77|3.03|companies that have lots of satellite
3994.0|4.5|data so this is all analyzed with large
3995.8|4.26|commnets in this case it's finding roads
3998.5|4.14|but you can also look at agriculture
4000.06|3.96|applications and so on they can also do
4002.64|3.12|image captioning so you might have seen
4004.02|4.65|some some of these results my work
4005.76|4.2|included as well where you take images
4008.67|3.39|and you caption them with sentences
4009.96|4.26|instead of just a single category and
4012.06|4.71|they can also be used for various
4014.22|4.59|artistic endeavors so this is something
4016.77|3.75|called deep dream and we're going to go
4018.81|2.82|into how this works you'll actually
4020.52|3.93|implement anything in your third
4021.63|3.93|assignment maybe okay maybe you will
4024.45|3.3|implement this on your third assignment
4025.56|7.5|you give it an image and using ComNet
4027.75|6.57|you can make it do weird stuff in
4033.06|3.06|particular you'll notice there are lots
4034.32|3.99|of hallucinations of dogs and we're
4036.12|3.48|going to go into why dogs appear it has
4038.31|2.64|to do with the fact that imagenet which
4039.6|3.45|is where these networks get trained they
4040.95|4.77|end up they have a lot of dogs and so
4043.05|4.23|the so these networks end up
4045.72|3.09|hallucinating dogs it's kind of like
4047.28|2.94|they're used to some patterns and then
4048.81|4.26|when you show them a different image you
4050.22|4.85|can make them put them in the loop of
4053.07|5.85|the image and they'll hallucinate things
4055.07|5.68|so we'll see how this works in a bit I'm
4058.92|4.35|not going to explain the slide but it
4060.75|3.98|looks cool so you can imagine that a
4063.27|5.13|calm that is probably involved somewhere
4064.73|4.93|I also wanted to point out that what's
4068.4|2.55|interesting there's this paper called
4069.66|3.09|Deakin neural networks rival
4070.95|4.32|representation of primate ID cortex call
4072.75|3.989|for a core visual recognition what they
4075.27|3.64|did here is
4076.739|3.55|they are basically looking at I think
4078.91|3.78|this was a macaque monkey and they're
4080.289|4.32|recording from the IT from the from the
4082.69|3.899|iit cortex here and they're recording
4084.609|3.72|neural activations as a monkey is
4086.589|3.091|looking at images and then they fed the
4088.329|3.361|same images to a convolutional neural
4089.68|3.72|network and what they're trying to do is
4091.69|3.21|from the popul from the convolutional
4093.4|3.209|neural network code or from the
4094.9|3.18|population of neurons that are is only a
4096.609|3.15|sparse population of neurons in the IP
4098.08|4.23|cortex they're trying to perform a
4099.759|4.71|classification of some concepts and what
4102.31|4.349|you see is that decoding from the i.t
4104.469|4.02|cortex and classifying images is almost
4106.659|4.41|as good as using this neural network
4108.489|4.44|from 2013 so in terms of the information
4111.069|4.471|that's there about the image you can do
4112.929|5.19|almost equal in performance for
4115.54|4.38|classification perhaps even more
4118.119|3.66|striking results here where they were
4119.92|2.939|comparing they fed a lot of images
4121.779|2.851|through the convolutional Network and
4122.859|3.391|they got this monkey to look at lots of
4124.63|3.33|images and then you look at how these
4126.25|3.929|images are represented in the brain or
4127.96|3.899|in the content so these are two spaces
4130.179|3.721|of representation of how images are
4131.859|4.081|arranged in the space by the comment and
4133.9|4.5|you can compare the similarity matrices
4135.94|4.89|and statistics and you'll see that the
4138.4|4.319|i.t cortex and the cognate commnets are
4140.83|3.21|basically very very similar
4142.719|3.451|representation there's a mapping between
4144.04|4.23|them it almost seems like similar things
4146.17|4.319|are being computed the way they arrange
4148.27|3.869|the visual space of different concepts
4150.489|4.111|and what's close and what's far is very
4152.139|4.591|very remarkably similar to what you see
4154.6|4.59|in the in the brain and so some people
4156.73|3.989|think that this is just some evidence
4159.19|3.419|that comments are doing something brain
4160.719|3.031|like and that is very interesting so the
4162.609|4.01|only question that remains then in that
4163.75|5.609|case is how do you come that's work and
4166.619|5.1|we'll find out in the next class so
4169.359|2.36|that's it