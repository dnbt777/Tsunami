start_time|end_time|text
3.24|9.04|okay so let me dive into some
5.5|8.73|administrative points first so again
12.28|4.589|recall that assignment 1 is due next
14.23|4.77|Wednesday you have about 150 hours left
16.869|4.981|and I use hours because there's a more
19.0|4.199|imminent sense of doom and remember that
21.85|3.689|third of those hours you'll be
23.199|5.151|unconscious so you don't have that much
25.539|4.711|time it's really running out and you
28.35|3.13|know you might think that you have late
30.25|2.76|days and so on but the easiest time is
31.48|6.81|just get harder over time so you want to
33.01|7.35|save those and so on so start now let's
38.29|4.109|see so there's no office hours or
40.36|3.42|anything like that on Monday I'll hold
42.399|2.73|make up office hours on Wednesday
43.78|2.91|because I want you guys to be able to
45.129|3.571|talk to me about especially projects and
46.69|3.959|so on so I'll be moving my office hours
48.7|3.57|from Monday to wednesday usually I have
50.649|3.271|my office hours at 6 p.m. instead I'll
52.27|3.719|have them at 5 p.m. and usually it's in
53.92|6.959|gates to 60 but now I'll be in gates to
55.989|6.421|59 so minus 1 on both and yeah and also
60.879|2.761|to note when you're going to be studying
62.41|3.209|for a midterm that's coming up in a few
63.64|3.119|weeks make sure you go through the
65.619|2.79|lecture notes as well which are really
66.759|2.61|part of this class and I kind of pick
68.409|2.91|and choose some of the things that I
69.369|3.57|think are most valuable to present in a
71.319|2.91|lecture but there's quite a bit of you
72.939|3.0|know more material to be aware of that
74.229|2.88|might pop up in the midterm even though
75.939|3.0|I'm covering some of the most important
77.109|2.94|stuff usually in the lecture so do read
78.939|5.49|through those lecture notes they're
80.049|5.73|complementary to the lectures and so the
84.429|4.311|material for the midterm will be drawn
85.779|6.48|from both the lectures and the notes ok
88.74|5.439|so having said all that we're going to
92.259|4.68|dive into the material so where we are
94.179|4.021|right now just as a reminder we have the
96.939|3.0|score function we've looked at several
98.2|4.229|loss functions such as the SPM loss
99.939|4.35|function last time and we looked at the
102.429|4.411|full loss that you achieve for any
104.289|4.981|particular set of weights on over your
106.84|3.689|training data and this loss is made up
109.27|3.149|of two components there's a data loss
110.529|3.66|and a regularization loss right and
112.419|3.48|really what we want to do is we want to
114.189|3.0|derive now the gradient expression of
115.899|3.39|the loss function with respect to the
117.189|3.901|weights and we want to do this so that
119.289|3.72|we can actually perform the optimization
121.09|4.589|process and in the optimization process
123.009|4.86|we're doing a gradient descent where we
125.679|4.681|iterate evaluating the gradient on your
127.869|3.891|weights doing a parameter update and
130.36|3.3|just repeating this over and over again
131.76|4.03|so that we're converging
133.66|4.17|to the low points of that loss function
135.79|3.54|and when we arrive at a low loss that's
137.83|2.97|equivalent to making good predictions
139.33|3.93|over our training data in terms of the
140.8|3.75|scores that come out now we also saw
143.26|2.55|that there are two kind of ways to
144.55|3.6|evaluate the gradient there's a
145.81|4.08|numerical gradient and this is very easy
148.15|3.72|to write but it's extremely slow to
149.89|3.6|evaluate and there's analytic gradient
151.87|3.45|which is which you obtained by using
153.49|4.5|calculus and we'll be going into that in
155.32|4.74|this lecture quite a bit more and so
157.99|4.02|it's fast exact which is great but it's
160.06|3.78|not you can get it wrong sometimes and
162.01|4.47|so we always perform what we call Radian
163.84|3.99|check where we write all the expressions
166.48|2.46|to compute the analytic gradient and
167.83|3.24|then we double check its correctness
168.94|3.87|with numerical gradient and so I'm not
171.07|2.76|sure if you're going to see that you're
172.81|6.33|going to see that definitely in the
173.83|8.43|assignments okay so now you might be
179.14|5.22|tempted to when you see this set up we
182.26|3.24|just want to derive the gradient of the
184.36|3.75|last function with respect to the
185.5|3.99|weights you might be tempted to just you
188.11|3.06|know write out the full loss and just
189.49|3.99|start to take the gradients as you see
191.17|3.69|in your calculus class but the point I'd
193.48|2.79|like to make is that you should think
194.86|4.56|much more of this in terms of
196.27|5.67|computational graphs instead of instead
199.42|3.75|of just taking thinking of one giant
201.94|3.269|expression that you're going to derive
203.17|3.99|on pen with pen and paper the expression
205.209|4.321|for the gradient and the reason for that
207.16|4.5|so here we're thinking about these
209.53|3.3|values flow flowing through a
211.66|3.0|computational graph where we have these
212.83|3.48|operations along circles and they
214.66|3.78|transfer they're basically function
216.31|3.48|pieces that transform your inputs all
218.44|3.54|the way to the loss function at the end
219.79|4.62|so we start off with our data and our
221.98|3.78|parameters as inputs they feed through
224.41|3.69|this computational graph which is just
225.76|3.84|an oldy series of functions along the
228.1|3.69|way and at the end we get a single
229.6|3.57|number which is the loss and the reason
231.79|3.54|that I'd like you to think about it this
233.17|3.87|way is that these expressions right now
235.33|3.33|look very small and you might be able to
237.04|3.15|derive these gradients but these
238.66|3.99|expressions are and computational graphs
240.19|3.72|are about to get very big and so for
242.65|3.3|example convolutional neural networks
243.91|4.049|will have hundreds maybe or dozens of
245.95|4.259|operations so we'll have all these
247.959|4.141|images flowing through like pretty big
250.209|3.841|computational graph to get our loss and
252.1|4.319|so it becomes impractical to just write
254.05|3.6|out these expressions and convolutional
256.419|2.641|networks are not even the worst of it
257.65|3.12|once you actually start to for example
259.06|3.84|do something called a neural Turing
260.77|3.99|machine which is a paper from deep mind
262.9|4.44|where this is basically a differentiable
264.76|4.8|Turing machine so the whole thing
267.34|3.57|differentiable the whole procedure that
269.56|3.27|the computer is performing on the tape
270.91|4.56|is made smooth and is differentiable
272.83|5.22|computer basically and the computational
275.47|4.68|graph of this is huge and not only is
278.05|3.3|this this is not it because what you end
280.15|3.21|up doing and we're going to recurrent
281.35|3.0|neural networks in a bit but what you
283.36|3.15|end up doing is you end up enrolling
284.35|5.7|this graph so think about this graph
286.51|5.58|copied many hundreds of time steps and
290.05|4.02|so you end up with this giant monster of
292.09|4.62|hundreds of thousands of nodes and
294.07|4.53|little computational units and so it's
296.71|3.33|impossible to write out you know here's
298.6|3.15|the loss for the neural Turing machine
300.04|3.78|it's just impossible it would take like
301.75|3.21|billions of pages and so we have to
303.82|3.18|think about this more in terms of data
304.96|3.69|structures of little functions
307.0|4.59|transforming intermediate variables to
308.65|3.989|gets loss at the variant okay so we're
311.59|2.4|going to be looking specifically at
312.639|4.741|computational graphs and how we can
313.99|4.679|derive the gradient on the inputs with
317.38|4.08|respect to the loss function at the very
318.669|5.281|end okay so let's start off simple and
321.46|4.11|concrete so let's consider a very small
323.95|3.99|computational graph where we have three
325.57|4.05|scalars as an inputs to this graph XY
327.94|3.75|and Z and they take on the specific
329.62|3.96|values in this example of negative 2 5
331.69|4.5|and negative 4 and we have this very
333.58|4.649|small graph or circuit you'll hear me
336.19|4.47|refer to these interchangeably either as
338.229|4.291|a graph or a circuit so we have this
340.66|4.379|graph that at the end gives us this
342.52|4.11|output negative 12 ok so here what I've
345.039|3.181|done is I've already prefilled what
346.63|3.45|we'll call the forward pass of this
348.22|4.71|graph where I set the inputs and then I
350.08|4.05|compute the outputs ok and now we'd like
352.93|3.54|to do is we'd like to derive the
354.13|5.58|gradients of the expression on the
356.47|5.04|inputs and so what we'll do now is I'll
359.71|4.2|introduce this intermediate variable Q
361.51|4.469|after the plus gate so there's a plus
363.91|4.17|gate and a times gate as I'll refer to
365.979|4.141|them and this plus gate is computing
368.08|3.809|this output Q and so Q is this
370.12|3.63|intermediate as a result of X plus y and
371.889|3.511|then F is a multiplication of Q and Z
373.75|3.419|and what I've written out here is
375.4|4.65|basically what we want is the gradients
377.169|6.211|the derivatives DF by DX DF by dy DF by
380.05|6.27|DZ and I've written out the intermediate
383.38|5.67|these little gradients for every one of
386.32|4.29|these two expressions separately so now
389.05|3.0|we've performed the forward paths going
390.61|3.66|from left to right and what we'll do now
392.05|4.23|is we'll derive the backward pass we'll
394.27|3.42|go from the back to the front
396.28|3.15|computing gradients of all the
397.69|3.029|intermediates in our circuit until at
399.43|4.049|the very end we're going to be left
400.719|5.19|the gradients on the inputs and so we
403.479|4.32|start off at the very right and as a
405.909|4.23|base case sort of of this recursive
407.799|4.83|procedure we're considering the gradient
410.139|4.2|of F with respect to F so this is just
412.629|5.54|the identity function so what is the
414.339|8.49|derivative of just it identity mapping
418.169|7.81|where's the gradient of DF by DF it's 1
422.829|5.94|right so the identity has a gradient of
425.979|4.35|1 so that's our base case we start off
428.769|4.86|with 1 and now we're going to go
430.329|7.74|backwards through this graph so we want
433.629|8.45|the gradient of F with respect to Z so
438.069|4.01|what is that in this computational graph
443.579|4.54|ok it's Q so we have that written out
446.86|5.579|right here and what is Q in this
448.119|5.34|particular example it's 3 right so the
452.439|2.97|gradient on Z
453.459|3.12|according to this will become just 3 so
455.409|4.14|I'm going to be writing the gradients
456.579|5.76|under the lines in red and the values
459.549|4.77|are in green above the lines so with the
462.339|4.98|gradient on the in the front is 1 and
464.319|4.41|now the gradient on Z is 3 and what
467.319|2.58|thread 3 is telling you really
468.729|3.24|intuitively keep in mind the
469.899|4.56|interpretation of a gradient is what
471.969|6.69|that's saying is that the influence of Z
474.459|7.23|on the final value is positive and with
478.659|5.76|sort of a force of 3 so if I increment Z
481.689|5.28|by a small amount H then the output of
484.419|5.01|the circuit will react by increasing
486.969|5.79|because it's a positive 3 will increase
489.429|5.7|by 3 H so a small change will result in
492.759|8.61|a positive change on the output now the
495.129|10.85|gradient on Q in this case will be so DF
501.369|7.65|by DQ is said what is that negative 4
505.979|5.89|okay so we get a gradient of negative 4
509.019|4.26|on that part of the circuit and what
511.869|3.21|that's saying is that if Q were to
513.279|4.771|increase then the output of the circuit
515.079|4.8|will decrease ok bye if you increase by
518.05|4.049|H the output of the circuit will
519.879|5.07|decrease by 4 H that's the slope is
522.099|4.68|negative 4 ok now we're going to
524.949|3.33|continue this recursive process through
526.779|3.511|this plus gate and this is where things
528.279|3.78|get slightly interesting I suppose so
530.29|3.38|we'd like to compute the gradient on F
532.059|4.311|on Y
533.67|5.4|with respect to Y and so the gradient on
536.37|8.31|Y with this in this particular graph
539.07|9.59|will become let's just guess and then
544.68|3.98|we'll see how this gets derived properly
551.51|3.58|so I hear some murmurs of the right
553.53|3.18|answer it will be negative four so let's
555.09|2.97|see how so there are many ways to derive
556.71|3.24|it at this point because the expression
558.06|3.51|is very small and you can kind of glance
559.95|3.72|at it but the way I'd like you to think
561.57|4.2|about this is by applying chain rule
563.67|3.69|okay so the chain rule says that if you
565.77|5.25|would like to derive the gradient of F
567.36|6.09|on Y then it's equal to DF by DQ times
571.02|3.96|DQ by dy right and so we've computed
573.45|4.53|both of those expressions in particular
574.98|5.01|DQ by dy we know is negative four so
577.98|4.98|that's the effect of the influence of Q
579.99|5.46|on F is DF by DQ which is negative four
582.96|4.77|and now we know the look we'd like to
585.45|5.46|know the local influence of Y on Q and
587.73|5.61|that local influence of Y on Q is one
590.91|6.48|because that's the local as I'll refer
593.34|5.73|to as the local derivative of Y for the
597.39|3.09|plus skate and so the chain rule tells
599.07|3.3|us that the correct thing to do to chain
600.48|4.26|these two gradients the local gradient
602.37|4.29|of Y on Q and the kind of global
604.74|3.9|gradient of Q on the output of the
606.66|5.31|circuit is to multiply them so we'll get
608.64|5.01|negative 4 times 1 and so this is kind
611.97|3.15|of the the crux of how back propagation
613.65|3.33|works is this is very important to
615.12|4.23|understand here that we have these two
616.98|4.71|pieces that we keep multiplying through
619.35|5.79|when we perform this chain rule we have
621.69|5.37|Q computed X plus y and the derivative
625.14|4.47|on x and y with respect to that single
627.06|3.78|expression is 1 and 1 so keep in mind
629.61|3.09|the interpretation of the gradient what
630.84|4.95|that's saying is that x and y have a
632.7|6.63|positive influence on Q with a slope of
635.79|6.75|1 so increasing X by H will increase Q
639.33|5.25|by H okay and now what we eventually
642.54|4.77|like is we'd like the influence of Y on
644.58|5.4|the final output of the circuit and so
647.31|4.44|the way this ends up working is you take
649.98|3.9|the influence of Y on Q and we know the
651.75|3.63|influence of Q on the final loss which
653.88|3.57|is what we are recursively computing
655.38|3.81|here through this graph and the correct
657.45|3.6|thing to do is to multiply them so we
659.19|3.48|end up with a negative 4 times 1 okay
661.05|4.05|even negative 4 and so the way this
662.67|4.32|works out is basically what this is
665.1|2.34|saying is that the influence of Y on the
666.99|2.19|final
667.44|3.81|but the circuit is negative for so
669.18|4.17|increasing why should decrease the
671.25|4.29|output of the circuit by negative four
673.35|4.38|times the little change that you've made
675.54|3.9|and the way that ends up working out is
677.73|4.32|why has a positive influence on Q so
679.44|5.25|increasing Y slightly increases Q which
682.05|5.16|likely decreases the output of the
684.69|14.34|circuit okay so chain rule is kind of
687.21|13.14|giving us this correspondence good yeah
699.03|3.57|thank you so we're going to get into
700.35|3.06|this you'll see many basically centaur
702.6|2.04|classes about this
703.41|2.88|so you'll see many many instantiations
704.64|2.46|of this and I'll drill this into you by
706.29|2.91|the end of this class and you'll
707.1|3.54|understand it you will not have any
709.2|2.64|symbolic expressions anywhere once we
710.64|2.13|compute this once we're actually
711.84|2.58|implementing this and you'll see
712.77|3.57|implementations of it later in this
714.42|5.1|Innis it will always be just vectors and
716.34|5.31|numbers row vectors numbers okay and
719.52|3.6|looking at X we have a very similar that
721.65|3.9|happens thing that happens we want DF by
723.12|4.08|DX that's our final objective but and we
725.55|3.72|have to combine it we know what the X is
727.2|3.63|what is X's influence on Q and what
729.27|3.66|excuse influence on the end of the
730.83|3.54|circuit and so that ends up being a
732.93|3.96|chain rule so you take a negative 4
734.37|5.01|times 1 and gives you negative 1 okay so
736.89|3.84|the way this works to generalize a bit
739.38|2.46|from this example and the way to think
740.73|3.75|about it is as follows
741.84|4.71|you are a gate embedded in a circuit and
744.48|5.25|this is a very large computational graph
746.55|5.16|or circuit and you receive some inputs
749.73|3.93|some particular numbers X and y come in
751.71|4.92|and you perform some operation on them
753.66|6.51|and compute some output set Z ok
756.63|4.83|and now now this value of Z goes into
760.17|3.09|computational graph and something
761.46|3.06|happens to it but you're just a gate
763.26|3.24|hanging out in a circuit and you're not
764.52|4.08|sure what happens but by the end of the
766.5|4.38|circuit the loss gets computed ok and
768.6|4.11|that's the forward pass and then we're
770.88|5.34|proceeding recursively in the reverse
772.71|4.379|order backwards but before that actually
776.22|3.27|before I get to that part
777.089|3.841|you've really right away when I get x
779.49|3.72|and y the thing I'd like to point out
780.93|3.93|that during the forward pass if you're
783.21|3.69|this gate and you get your values x and
784.86|3.36|y you compute your output Z and there's
786.9|3.689|another thing you can compute right away
788.22|4.47|and that is the local gradients on x and
790.589|4.201|y so I can compute those right away
792.69|3.33|because I'm just a gate and I know what
794.79|3.15|I'm performing like say additional
796.02|4.59|multiplication so I know the influence
797.94|5.069|that x and y i have on my output value
800.61|5.189|can compute those guys right away okay
803.009|4.411|what but then what happens near the end
805.799|3.9|so the loss gets computed and now we're
807.42|5.639|going backwards I'll eventually learn
809.699|5.31|about what is my influence on the final
813.059|4.981|output of the circuit the loss so I'll
815.009|5.19|learn what is DL by DZ in there
818.04|3.419|the gradient will flow into me and what
820.199|3.75|I have to do is I have to chain that
821.459|3.81|gradient through this recursive case so
823.949|2.971|I have to make sure to chain the
825.269|3.151|gradient through my operation that I
826.92|2.789|performed and it turns out that the
828.42|3.18|correct thing to do here by chain rule
829.709|3.24|really what it's saying is the correct
831.6|3.029|thing to do is to multiply your local
832.949|4.95|gradient with that gradient and that
834.629|5.37|actually gives you the DL by DX that
837.899|4.141|gives you the influence of X on the
839.999|4.07|final output of the circuit so really
842.04|4.5|chain rule is just this added
844.069|4.36|multiplication where we take our what
846.54|3.899|I'll called global gradient of this gate
848.429|4.38|on the output and we change it through
850.439|4.14|the local gradient and the same thing
852.809|6.24|goes for Y so it's just a multiplication
854.579|6.93|of that guy the that gradient by your
859.049|4.681|local gradient if you're a gate and then
861.509|4.05|remember that these X's and Y's there
863.73|4.259|are coming from different gates right so
865.559|4.32|you end up with recursing this process
867.989|4.38|through the entire computational circuit
869.879|4.26|and so these gates just basically
872.369|4.71|communicate to each other the influence
874.139|4.35|on the final loss so they tell each
877.079|2.521|other okay if this is a positive
878.489|2.64|gradient that means you're positively
879.6|2.76|influencing Glaus and if it's a negative
881.129|3.42|gradient your negative influence
882.36|3.599|negatively influencing loss and these
884.549|3.96|just gets all multiplied through the
885.959|4.47|circuit by these local gradients and you
888.509|3.57|end up with and this process is called
890.429|3.87|back propagation it's a way of computing
892.079|4.17|through a recursive application of chain
894.299|3.57|rule through computational graph the
896.249|3.601|influence of every single intermediate
897.869|3.75|value in that graph on the final loss
899.85|5.13|function and so we'll see many examples
901.619|5.19|of this throughout this lecture I'll go
904.98|3.659|into a specific example that is slightly
906.809|4.08|larger and we'll work through it in
908.639|3.48|detail but I don't know if there are any
910.889|4.04|questions at this point that anyone
912.119|2.81|would like to ask go ahead
916.16|3.52|if Z is used by multiple notes I'm going
918.9|3.0|to come back to that
919.68|3.3|ul you add the gradients the gradient
921.9|4.44|the correct thing to do is to add them
922.98|4.95|so if Z is being influenced in multiple
926.34|3.99|places in the circuit the backward flows
927.93|10.83|will add but we'll come back to that
930.33|10.32|point and the way you randomly
938.76|4.02|initialize your weights you end up that
940.65|3.54|this is your squashing function the
942.78|3.57|value of that is somewhere on the
944.19|11.13|asymptotes then we are computing the
946.35|10.2|gradient to change so I think I would I
955.32|2.81|would have repeated your question but
956.55|4.17|you're jumping ahead like hundred slides
958.13|4.81|mm-hmm so we're going to get to all of
960.72|3.09|those issues and we're going to see yeah
962.94|2.28|you're going to get what we call
963.81|5.1|vanishing gradient problems and so on
965.22|5.4|we'll see okay let's go through another
968.91|3.42|example to make this more concrete so
970.62|3.39|here we have another circuit it happens
972.33|3.48|to be computing a little two-dimensional
974.01|4.08|signal neuron but for now don't worry
975.81|4.92|about that interpretation just think of
978.09|4.71|this as that's an expression so 1 over 1
980.73|4.86|plus e to the whatever so the number of
982.8|3.93|inputs here is 5 and we're computing
985.59|1.92|that function and we have a single
986.73|3.54|output over there
987.51|4.32|okay and I translated that mathematical
990.27|3.3|expression into this computational graph
991.83|3.39|form so we have to recursively from
993.57|4.38|inside out compute this expression so we
995.22|6.78|first do all the little W x axis and
997.95|5.91|then we add them all up and then we take
1002.0|3.51|a negative of it and then we
1003.86|3.33|exponentiate that and then we add one
1005.51|3.81|and then we finally divide and we get
1007.19|3.12|the result of the expression and so
1009.32|2.55|we're going to do now is we're going to
1010.31|3.18|back propagate through this expression
1011.87|3.54|we're going to compute what the
1013.49|3.9|influence of every single input value is
1015.41|5.3|on the output of this expression what is
1017.39|3.32|the gradient here yeah
1029.77|4.77|so you're so for now so you're concerned
1033.22|3.39|about the interpretation of Plus maybe
1034.54|3.75|in these circles for now let's just
1036.61|4.979|assume that this plus is just a binary
1038.29|4.95|plus is a binary Plus gate and we have
1041.589|4.171|there a plus 1 gate I'm making up these
1043.24|4.38|gates kind of on spot and we'll see that
1045.76|3.15|what is a gator is not a gate is kind of
1047.62|4.71|up to you I'll come back to this point
1048.91|5.67|of it in a bit so for now I just like we
1052.33|4.14|have several more gates that we're using
1054.58|3.03|throughout and so I just like to write
1056.47|3.0|out as we go through this example
1057.61|3.81|several of these derivatives so we have
1059.47|3.72|exponentiation and we know for every
1061.42|3.36|little local gate what these local
1063.19|4.26|gradients are right so we can derive
1064.78|5.94|that using calculus so e to the X
1067.45|4.8|derivative is e to the X and so on so
1070.72|2.88|these are all the operations and also
1072.25|3.0|addition and multiplication which I'm
1073.6|3.6|assuming that you have memorized in
1075.25|3.03|terms of what the gradients look like so
1077.2|2.37|we're going to start off at the end of
1078.28|4.08|the circuit and I've already filled in a
1079.57|4.32|one point zero zero in the in the back
1082.36|5.34|because that's how we always start this
1083.89|5.25|recursion whether 11.0 right because
1087.7|2.88|since that's the gradient on the
1089.14|3.9|identity function now we're going to
1090.58|7.2|back propagate through this 1 over X
1093.04|7.02|operation okay so the derivative of 1
1097.78|4.44|over X the local gradient is negative 1
1100.06|4.08|over x squared so that 1 over X gate
1102.22|5.31|during the forward pass received input
1104.14|4.95|1.37 and right away that 1 over X gate
1107.53|3.18|could have computed what the local
1109.09|3.63|gradient was the local gradient was
1110.71|4.64|negative 1 over x squared and now during
1112.72|5.73|back propagation it has to by chain rule
1115.35|5.29|multiply that local gradient by the
1118.45|3.72|gradient of it on the final output of
1120.64|3.81|the circuit which is easy because it
1122.17|3.99|happens to be at the end so what ends up
1124.45|4.02|being the expression for the back
1126.16|9.57|propagated gradient here from the 1 over
1128.47|9.99|x gate the chain will always has two
1135.73|7.04|pieces local gradient times the gradient
1138.46|4.31|from the top or from above
1148.99|5.189|- yeah okay yes that's correct
1152.35|4.709|so we get minus one over x squared which
1154.179|4.38|is a gradient DF by DX so that that is
1157.059|4.291|the local gradient negative one over
1158.559|4.891|three point seven squared and then
1161.35|4.05|multiplied by one point zero which is
1163.45|3.81|the gradient from above which is really
1165.4|4.44|just one because we just started and so
1167.26|4.56|I'm applying chain rule right away here
1169.84|4.829|and the output is negative zero point
1171.82|5.07|five three so that's the gradient on
1174.669|3.51|that piece of the wire where this Valley
1176.89|2.73|was flowing okay
1178.179|4.411|so it has a negative effect on the
1179.62|4.799|output and you might expect that right
1182.59|3.75|because if you were to increase this
1184.419|4.351|value and then it goes through a gate of
1186.34|4.02|1 over X then if you increase this then
1188.77|3.899|1 over X gets smaller so that's why
1190.36|3.449|you're seeing negative gradient right so
1192.669|3.931|we're going to continue back propagation
1193.809|5.911|here the next gate in the circuit it's
1196.6|5.37|adding a constant of one so the local
1199.72|6.0|gradient if you look at adding a
1201.97|7.29|constant to a value the gradient of X is
1205.72|6.63|just one right for basic calculus and so
1209.26|9.39|the chain gradient here that we continue
1212.35|9.329|along the wire will be we have local
1218.65|5.7|gradient which is one times the gradient
1221.679|3.931|from above the gate which it has just
1224.35|1.98|learned is negative zero point five
1225.61|2.25|three okay
1226.33|5.21|so negative zero point five three
1227.86|5.43|continues along the wire unchanged and
1231.54|3.82|intuitively that makes sense right
1233.29|3.389|because this this value floats and it
1235.36|3.33|has some influence in the final circuit
1236.679|4.62|and now if you're skip if you're adding
1238.69|4.41|one then it's influenced it's rate of
1241.299|3.481|change its slope towards the final value
1243.1|4.17|doesn't change if you increase this by
1244.78|5.16|some amount the effect at the end will
1247.27|4.409|be the same because the rate of change
1249.94|3.93|doesn't change through the plus one gate
1251.679|4.651|it's just a constant offset okay we
1253.87|5.73|continue derivation here so the gradient
1256.33|4.62|of e to the X is e to the X so to
1259.6|4.68|continue back propagation we're going to
1260.95|4.71|perform so this gate saw input of
1264.28|3.3|negative one it right away could have
1265.66|3.54|computed its local gradient and now it
1267.58|4.17|knows that the gradient from above is
1269.2|3.959|negative 0.53 so to continue back
1271.75|3.98|propagation here in applying chain rule
1273.159|2.571|we would receive
1276.94|4.72|okay so these are most of the rhetorical
1279.38|4.71|questions I'm not sure but Mattia
1281.66|4.95|basically e to the negative one which is
1284.09|5.07|e to the X the X input to this X gate
1286.61|3.63|times the chain rule right so the
1289.16|2.67|gradient from above is negative point
1290.24|4.14|five three so we keep multiplying that
1291.83|4.53|on so what is the effect on me and what
1294.38|2.94|do I have an effect on the final end of
1296.36|3.99|the circuit those are being always
1297.32|5.28|multiplied so we get negative point to
1300.35|6.72|this point so now we have a times
1302.6|7.23|negative one gate so what ends up
1307.07|6.06|happening when you do a times negative
1309.83|5.46|one in the computational graph it flips
1313.13|4.77|around right because we have basically a
1315.29|5.28|constant multiplied of input which
1317.9|4.92|happen to be a constant of negative 1 so
1320.57|4.5|negative 1 times 1 times negative 1 gave
1322.82|4.2|us negative 1 in the forward pass and so
1325.07|4.23|now we have to multiply by a that's the
1327.02|4.26|local gradient times the gradient above
1329.3|5.22|which is 0.2 so we end up with just
1331.28|4.8|positive point 2 now so now continuing
1334.52|3.72|back propagation we're back propagating
1336.08|4.95|plus and this plus operation has
1338.24|4.65|multiple inputs here the gradient the
1341.03|4.5|local gradient for the plus gate is 1
1342.89|6.29|and 1 so what ends up happening - what
1345.53|3.65|gradients flow along the output buyers
1361.559|4.691|so the Plaskett has a local gradient on
1364.75|4.74|all of its inputs always will be just
1366.25|7.08|one right because if you just have a
1369.49|5.4|function you know X plus y then for that
1373.33|4.29|function the gradient on either X or Y
1374.89|6.419|is just 1 and so what you end up getting
1377.62|5.64|is just 1 times point 2 and so in fact
1381.309|3.811|for a + gate always you see the same
1383.26|4.11|effect where the local gradient all of
1385.12|4.29|its inputs is 1 and so whatever gradient
1387.37|3.9|it gets from above it just always
1389.41|3.33|distributes gradient equally to all of
1391.27|2.61|its inputs because in a chain rule
1392.74|2.73|they'll get multiplied and when you
1393.88|3.69|multiply by 1 you something remains
1395.47|3.9|unchanged so a plus gate is kind of like
1397.57|3.39|a gradient distributor where if
1399.37|3.63|something flows in from the top it will
1400.96|3.81|just spread out all the all the
1403.0|4.05|gradients equally to all of its children
1404.77|5.909|and so we've already received one of the
1407.05|5.879|inputs is gradient point 2 here on the
1410.679|3.661|very final output of the circuit and so
1412.929|3.361|this influence has been computed through
1414.34|4.11|a series of applications of chain rule
1416.29|4.53|along the way
1418.45|4.29|so now let's there was another + gate
1420.82|3.989|that I've skipped over and so this point
1422.74|4.319|to kind of distributes to both point to
1424.809|4.111|point to equally so we've already done a
1427.059|5.071|+ gate and there's a multiply gate there
1428.92|5.58|and so now we're going to back propagate
1432.13|4.53|through that multiply operation and so
1434.5|4.5|the local grade so the so what will be
1436.66|7.22|the gradients for W 0 and X 0 what will
1439.0|4.88|be the gradient for W 0 specifically
1446.25|7.36|some let's say 0 0 will be wrong it will
1451.51|5.25|be
1453.61|6.03|so the gradient W 1 will be W 0 sorry it
1456.76|6.51|will be negative 1 times point 2 good
1459.64|4.95|and the gradient on X 0 will be there's
1463.27|2.82|a bug by the way in the slide that I
1464.59|4.44|just noticed like few minutes before I
1466.09|6.33|actually create the class so it created
1469.03|5.49|the start in the class so you see 0.39
1472.42|3.54|there it should be point 4 it's because
1474.52|3.24|of a bug in the visualization because
1475.96|3.39|I'm truncating at 2 decimal digits
1477.76|3.45|anyways but basically that should be
1479.35|2.7|point 4 because the way you get that is
1481.21|2.76|two times
1482.05|3.48|point 2 gives you point four just like
1483.97|5.46|I've written out over there so that's
1485.53|5.43|what the output should be there okay so
1489.43|3.72|that's so we've back propagated this
1490.96|3.78|circuit here and we've back propagated
1493.15|3.0|through this expression and so you might
1494.74|3.84|imagine in there are actual downstream
1496.15|4.59|applications we'll have data and all the
1498.58|4.08|parameters as inputs loss functions at
1500.74|3.45|the top at the end so we'll do forward
1502.66|3.33|pass to evaluate the loss function and
1504.19|3.39|then we'll back propagate through every
1505.99|3.18|piece of computation we've done along
1507.58|4.65|the way and we'll back propagate through
1509.17|4.32|every gate to get our inputs and back
1512.23|3.39|propagate just means apply chain rule
1513.49|3.93|many many times and we'll see how that
1515.62|6.06|is implemented in a bit sorry did you
1517.42|6.03|have a question oh yeah so I'm going to
1521.68|4.5|skip that because it's the same so I'm
1523.45|8.6|going to skip the other times gate any
1526.18|5.87|other questions it's point process
1532.83|6.48|that's right so the cost of forward and
1535.93|3.38|backward propagation is roughly equal
1543.69|4.06|well it should be it almost always ends
1545.95|3.21|up being basically equal when you look
1547.75|8.61|at timings usually the backward pass is
1549.16|8.7|slightly slower but yeah ok so let's see
1556.36|3.48|one thing I wanted to point out before
1557.86|3.96|we move on is that the setting of these
1559.84|3.15|gates like these gates are arbitrary so
1561.82|3.75|one thing I could have done for example
1562.99|4.32|is some of you may know this I can
1565.57|3.78|collapse these gates into one gate if I
1567.31|3.42|wanted to for example in there's
1569.35|3.21|something called a sigmoid function
1570.73|3.54|which has that particular form so Sigma
1572.56|3.75|Sigma of X which is the sigmoid function
1574.27|5.25|computes 1 over 1 plus e to the minus X
1576.31|4.62|and so I could have rewritten that
1579.52|2.79|expression and I could have collapsed
1580.93|3.75|all of those gates that made up the
1582.31|4.98|sigmoid gate into a single sigmoid gate
1584.68|3.75|and so there's a sigmoid gate here
1587.29|4.08|and I could have done that in a single
1588.43|4.65|go sort of and what I would have had to
1591.37|4.47|do if I wanted to have that gate is I
1593.08|5.64|need to compute an expression for how
1595.84|4.47|this so what is the local gradient for
1598.72|3.63|the sigmoid gate basically so what is
1600.31|3.45|the gradient on the similar gate on its
1602.35|2.64|input and I have to go through some math
1603.76|2.49|which I'm not going to go into detail
1604.99|3.72|but you end up with that expression over
1606.25|4.2|there it ends up being 1 minus Sigma of
1608.71|3.96|x times sigmoid of X that's the local
1610.45|3.96|gradient and that allows me to now put
1612.67|3.3|this piece into a computational graph
1614.41|3.45|because once I know how to compute the
1615.97|3.42|local gradient everything else is
1617.86|3.63|defined just through chain rule and
1619.39|3.72|multiplying everything together so we
1621.49|3.09|can back propagate through this sigmoid
1623.11|4.08|gate now and the way that would look
1624.58|5.16|like is the input to the sigmoid gate
1627.19|5.91|was 1.0 that's what flu went into the
1629.74|6.9|sigmoid gate and 0.73 went out so 0.73
1633.1|5.67|is Sigma of X ok and now we want the
1636.64|3.99|local gradient which is as we've seen
1638.77|3.6|from the math that I perform there 1
1640.63|3.99|minus Sigma of X times Sigma of X so you
1642.37|4.59|get Sigma of access point 7 3
1644.62|5.58|multiplying 1 minus 0.7 3 that's the
1646.96|4.59|local gradient and then times well we
1650.2|3.51|happen to be at the end of the circuit
1651.55|4.5|so times 1 point 0 which I'm not even
1653.71|4.41|writing so we end up with point 2 and of
1656.05|4.08|course we get the same answer point 2 as
1658.12|4.26|we received before point 2 because
1660.13|3.96|calculus works but basically we could
1662.38|3.6|have broken up this expression down and
1664.09|3.33|did one piece at a time or we could just
1665.98|3.21|have a single sigmoid gate and that's
1667.42|3.3|kind of up to us at what level of
1669.19|3.96|hierarchy do we break these expressions
1670.72|3.96|and so you'd like to intuitively cluster
1673.15|3.3|these expressions into single gates if
1674.68|3.6|it's very efficient or easy to derive
1676.45|4.46|the local gradients because then those
1678.28|2.63|become your pieces
1685.53|4.48|yes so the question is do libraries
1687.94|4.2|typically do that do they worry about
1690.01|3.57|you know what some what's easy to or
1692.14|3.3|convenience to compute and the answer is
1693.58|3.27|yeah I would say so so if you notice
1695.44|2.64|that there's some piece of operation
1696.85|3.3|you'd like to do over and over again and
1698.08|4.02|it has a very simple local gradient then
1700.15|3.45|that's something very appealing to
1702.1|3.0|actually create a single unit out of and
1703.6|4.89|we'll see some of those examples
1705.1|5.31|actually that I think ok I'd like to
1708.49|2.58|also point out that once you the reason
1710.41|2.1|I like to think about these
1711.07|2.76|computational graphs is it really helps
1712.51|3.57|your intuition to think about how
1713.83|4.32|gradients flow in a neural network it's
1716.08|3.57|not just you don't want this to be a
1718.15|4.29|black box to you you want to understand
1719.65|4.35|intuitively how this happens and you
1722.44|2.49|start to develop after a while of
1724.0|2.34|looking at computational graphs
1724.93|3.96|intuitions about how these gradients
1726.34|4.44|flow and this by do a lot so helps you
1728.89|3.63|debug some issues like say we'll go to
1730.78|3.39|vanish and gradient problem it's much
1732.52|3.57|easier to understand exactly what's
1734.17|3.24|going wrong in your optimization if you
1736.09|3.09|understand how gradients flow in
1737.41|3.9|networks it will help you debug these
1739.18|3.54|networks much more efficiently and so
1741.31|4.35|some intuitions for example we already
1742.72|4.83|saw that the 8ab gate it has a local
1745.66|4.08|gradient of 1 to all of its inputs so
1747.55|3.75|it's just a gradient distributor that's
1749.74|2.76|like a nice way to think about it
1751.3|3.21|whenever you have a plus operation
1752.5|3.57|anywhere in your score function or your
1754.51|3.78|ComNet or anywhere else it just
1756.07|4.23|distributes gradients equally the max
1758.29|4.23|gate is instead a gradient router
1760.3|5.73|and the way this works is if you look at
1762.52|7.74|the expression like we have I'll create
1766.03|5.91|these markers don't work so if we have a
1770.26|5.28|very simple binary expression of Max of
1771.94|6.69|X Y so if this is a gate then the
1775.54|4.89|gradient on x and y if you think about
1778.63|3.9|it the gradient on the larger one of
1780.43|4.56|your inputs whichever one is larger the
1782.53|3.81|gradient on that guy is one and all this
1784.99|3.03|and the smaller one has a gradient of
1786.34|3.75|zero and intuitively that's because if
1788.02|3.6|one of these was smaller then wiggling
1790.09|2.91|it has no effect on the output because
1791.62|3.6|the other guy is larger and that's what
1793.0|3.87|ends up propagating through the gate so
1795.22|3.69|you end up with a gradient of 1 on the
1796.87|6.24|larger one of the inputs and so that's
1798.91|6.0|why max gate is a gradient router if I'm
1803.11|3.75|a max gate and I received several inputs
1804.91|3.33|one of them was largest of all of them
1806.86|2.88|and that's the value that I propagated
1808.24|2.7|through the circuit at the back
1809.74|3.12|propagation time I'm just going to
1810.94|3.3|receive my gradient from above and I'm
1812.86|4.35|going to route it to whoever was my
1814.24|5.509|largest input so it's a gradient router
1817.21|4.86|and the multiply gate is a gradient
1819.749|3.88|switcher I'm not actually don't think
1822.07|4.709|that's a very good way to look at it but
1823.629|8.36|I'm referring to the fact that it's not
1826.779|5.21|actually never mind about that part good
1835.919|4.39|so yeah so your question is what happens
1838.599|9.99|if the two inputs are equal when you go
1840.309|12.99|through max gate yeah what happens yeah
1848.589|6.51|you pick one yeah yeah I don't think
1853.299|3.93|it's correct to distribute it to all of
1855.099|4.8|them I think you'd have to you'd have to
1857.229|9.9|pick one yeah but that basically never
1859.899|8.64|happens in actual practice okay so max
1867.129|4.86|gradient here actually have an example
1868.539|4.95|so said here was larger than W so only
1871.989|3.961|zet has an influence on the output of
1873.489|4.11|this max gate right so when two flows
1875.95|3.87|into the max gate it gets routed to Z
1877.599|4.08|and W gets a zero gradient because its
1879.82|3.63|effect on the circuit is nothing there's
1881.679|3.75|zero because when you change it it
1883.45|3.659|doesn't matter when you change it
1885.429|4.261|because that is the larger value going
1887.109|4.65|through the computational graph I have
1889.69|3.719|another note that is related to the back
1891.759|3.3|propagation which we already addressed
1893.409|3.84|through a question I just wanted to
1895.059|4.17|briefly point out with a terribly bad
1897.249|3.48|looking figure that if you have these
1899.229|2.94|circuits and sometimes you have a value
1900.729|2.91|that branches out into a circuit and is
1902.169|3.541|used in multiple parts of the circuit
1903.639|4.08|the correct thing to do by multivariate
1905.71|6.089|chain rule is to actually add up the
1907.719|7.68|contributions at at the operation so
1911.799|4.68|gradients add when they back propagate
1915.399|3.6|backwards through the circuit if they
1916.479|5.49|ever flow they add up in in these in
1918.999|5.4|this backward flow all right we're going
1921.969|6.78|to go into implementation very soon I'll
1924.399|5.7|just take some little questions thank
1928.749|3.03|you for the question the question is is
1930.099|4.17|there ever like loop in these graphs
1931.779|4.2|there will never be loops so there are
1934.269|3.181|never any loops you might think that if
1935.979|2.731|you use a recurrent neural network that
1937.45|2.669|there are loops in there but there's
1938.71|2.879|actually no loops because what we'll do
1940.119|3.87|is we will take a recurrent neural
1941.589|4.621|network and will unfold it through time
1943.989|3.63|steps and this will all become there
1946.21|3.0|will never be a loop in the unfolded
1947.619|2.631|graph where we've copy-pasted that small
1949.21|3.349|recurrent
1950.25|4.019|over time you'll see that more when we
1952.559|2.46|actually get into it but these are
1954.269|4.471|always DAGs
1955.019|4.89|there's no loops okay
1958.74|2.309|awesome so let's look at the
1959.909|2.701|implementation how this is actually
1961.049|5.041|implemented in practice and I think will
1962.61|5.46|help make this more concrete as well so
1966.09|3.63|we always have these graphs
1968.07|3.569|computational graphs these are the best
1969.72|4.77|way to think about structuring neural
1971.639|4.62|networks and so we end up with is all
1974.49|3.36|these gates that we're going to see in a
1976.259|2.581|bit but on top of the gates there's
1977.85|2.819|something that needs to maintain
1978.84|3.329|connectivity structure of this entire
1980.669|3.661|graph what gates are connected to each
1982.169|5.271|other and so usually that's handled by a
1984.33|6.63|graph or a net object usually in net and
1987.44|4.54|the net object has these two main pieces
1990.96|3.179|which has the forward and the backward
1991.98|6.179|piece and this is just pseudocode so
1994.139|5.79|this won't run but basically roughly the
1998.159|3.421|idea is that in the forward pass were
1999.929|3.36|iterating over all the gates in the
2001.58|4.14|circuit that and they're sorted in
2003.289|4.171|topological order what that means is
2005.72|3.419|that all the inputs must come to every
2007.46|3.299|node before the output can be consumed
2009.139|3.691|so these are just ordered from left to
2010.759|3.51|right and we're just forwarding we're
2012.83|3.449|calling a forward on every single gate
2014.269|3.481|along the way so we iterate over that
2016.279|3.301|graph and we just go forward on every
2017.75|3.12|single piece and this net object will
2019.58|3.599|just make sure that that happens in the
2020.87|3.809|proper connectivity pattern and backward
2023.179|3.391|pass we're going in the exact reverse
2024.679|3.6|order and we're calling backward on
2026.57|3.15|every single gate and these gates will
2028.279|2.64|end up communicating gradients to each
2029.72|3.419|other and they all get chained up and
2030.919|4.5|computing the analytic gradient at the
2033.139|4.321|back so really a net object is a very
2035.419|3.51|thin wrapper around all these gates or
2037.46|4.02|as well as well see they're called
2038.929|4.561|layers layers or gates I'm going to use
2041.48|3.569|those interchangeably and they're just
2043.49|3.09|very thin wrappers around connectivity
2045.049|2.76|structure of these gates and calling a
2046.58|2.999|forward and backward function on them
2047.809|3.391|and then let's look at a specific
2049.579|3.871|example of one of the gates and how this
2051.2|4.129|might be implemented and this is not
2053.45|4.169|justice Souter this is actually more
2055.329|5.35|like correct implementation in some
2057.619|4.351|sense like this might run at the end so
2060.679|3.361|let's say they're multiplied gate and
2061.97|3.359|how it could be implemented a multiply
2064.04|4.349|gate in this case is just a binary
2065.329|5.49|multiply so it receives two inputs X and
2068.389|5.421|y it computes their multiplication that
2070.819|5.461|is x times y and inverter instead and
2073.81|4.24|all these gates must basically satisfy
2076.28|3.359|this API of a forward call and a
2078.05|2.91|backward call how do you behave in a
2079.639|3.601|forward pass and how do you behave in a
2080.96|3.0|backward pass and in a forward pass we
2083.24|2.79|just compute whatever
2083.96|5.129|in a backward pass we eventually end up
2086.03|6.72|learning about what is our gradient on
2089.089|5.371|the final loss so DL by D zet is what we
2092.75|3.24|learn that's represented in this
2094.46|4.379|variable DZ and right now everything
2095.99|5.22|here is scalars so X Y Z our numbers
2098.839|3.841|here D Zed is also a number telling the
2101.21|5.07|influence on the end of the circuit and
2102.68|5.73|what this gate is in charge of and in
2106.28|4.23|this backward pass is performing the
2108.41|3.36|little piece of chain rule so what we
2110.51|3.18|have to compute is how do you change
2111.77|3.569|this gradient DZ into your inputs x and
2113.69|3.6|y in other words we have to compute DX
2115.339|3.421|and dy and we have to return those in
2117.29|2.76|the backward pass and then the
2118.76|2.73|computational graph will make sure that
2120.05|5.22|these get routed properly to all the
2121.49|5.069|other gates and if there are any edges
2125.27|3.059|that add up the computational graph
2126.559|5.491|might add might add all those gradients
2128.329|7.921|together ok so how would we implement
2132.05|6.809|the DX and dy so for example what is DX
2136.25|9.74|in this case what would it be equal to
2138.859|10.291|the implementation y times DZ right and
2145.99|4.359|so y times DZ additional point to make
2149.15|3.3|here by the way note that I've added
2150.349|4.77|some lies in the forward pass we have to
2152.45|4.26|remember these values x and y because we
2155.119|2.821|end up using them in a backward pass so
2156.71|3.24|I'm assigning them to a sell stop
2157.94|3.419|because I need to remember what X Y are
2159.95|3.75|because I need access to them in my
2161.359|4.801|backward pass in general in back
2163.7|3.99|propagation and when we build these when
2166.16|3.179|you actually do the forward pass every
2167.69|3.149|single gate must remember the inputs and
2169.339|3.451|any kind of intermediate calculations
2170.839|3.451|that has performed that it needs to do
2172.79|3.6|that needs access to in the backward
2174.29|3.569|pass so basically when we end up running
2176.39|2.55|these networks at runtime just always
2177.859|2.911|keep in mind that as you're doing this
2178.94|3.57|forward pass a huge amount of stuff gets
2180.77|3.21|cached in your memory and that all has
2182.51|2.73|to stick around because during back
2183.98|3.869|propagation you might need access to
2185.24|4.02|some of those variables and so your
2187.849|2.76|memory ends up ballooning up during a
2189.26|3.0|forward pass and then in backward pass
2190.609|2.94|it gets all consumed and you need all
2192.26|9.18|those intermediates to actually compute
2193.549|9.421|the proper backward pass so that's yes
2201.44|2.73|if you don't if you know you don't want
2202.97|2.399|to do backward pass then you can get rid
2204.17|2.58|of many of these things and you don't
2205.369|4.551|have to compute you're going to catch
2206.75|4.98|them so you can save on memory for sure
2209.92|4.33|but I don't think most implementations
2211.73|4.26|actually worry about that I don't think
2214.25|3.03|there's a lot of logic that deals with
2215.99|11.369|that usually we end up remembering it
2217.28|11.64|anyway oh I see yeah so I think if
2227.359|2.851|you're an embedded device for example
2228.92|2.699|and you worry really about your memory
2230.21|2.639|constraints this is something that you
2231.619|2.671|might take advantage of if you know that
2232.849|3.21|a neural network only has to run and
2234.29|3.15|test time then you might want to make
2236.059|2.25|sure to go into the code and make sure
2237.44|3.139|nothing gets cached
2238.309|5.601|in case you want to do a backward pass
2240.579|3.331|questions yes
2250.359|3.821|you're saying if we remember the local
2252.589|3.571|gradients in the in the forward pass
2254.18|4.55|then we don't have to remember the other
2256.16|2.57|intermediates
2258.89|6.209|I think that might only be the case in
2262.869|3.371|some simple expressions like this one
2265.099|3.51|I'm not actually sure that's true in
2266.24|4.2|general but I mean you're in charge of
2268.609|4.021|remember whatever you need to perform
2270.44|6.72|the backward pass they only gate by gate
2272.63|6.51|basis you don't necessarily feel like it
2277.16|5.49|has a lower footprint and so on and you
2279.14|4.949|can be clever with that okay so just to
2282.65|2.909|give you guys example of what this looks
2284.089|3.901|like in practice we're going to look at
2285.559|4.381|specific example say in torch torches a
2287.99|3.39|deep learning framework which we might
2289.94|3.48|go into a bit near the end of the class
2291.38|5.04|that some of you might end up using for
2293.42|5.37|your projects if you go into the github
2296.42|4.26|repo for torch and you look at like
2298.79|3.509|basically it's just giant collection of
2300.68|3.75|these layer objects and these are the
2302.299|3.601|gates layers gates the same thing so
2304.43|2.73|there's all these layers that's really
2305.9|3.179|what a deep learning framework is is
2307.16|4.05|just a whole bunch of layers and a very
2309.079|3.24|thin computational graph thing that
2311.21|4.26|keeps track of all the layer
2312.319|4.441|connectivity and so really the image to
2315.47|3.51|have in mind is all these things are
2316.76|5.849|your Lego blocks and then we're building
2318.98|4.8|up these computational graphs out of
2322.609|2.401|your Lego blocks out of the layers
2323.78|2.25|you're putting them together in various
2325.01|2.52|ways depending on what you want to
2326.03|3.12|achieve and so you end up building all
2327.53|4.11|kinds of stuff so that's how you work
2329.15|3.27|with neural networks so every library is
2331.64|2.19|just a whole set of
2332.42|2.97|layers that you might want to compute
2333.83|3.75|and every layer is just implementing a
2335.39|3.63|small peak function piece and that
2337.58|3.45|function Pease knows how to do a forward
2339.02|3.6|and it knows how to do a backward so
2341.03|6.93|just to be the specific example let's
2342.62|7.65|look at the mall constant layer in torch
2347.96|6.06|the mall constant layer performs just
2350.27|5.7|the scaling by a scalar so it takes some
2354.02|3.09|tensor X so this is not just a scalar
2355.97|3.33|but it's actually like an array of
2357.11|3.33|numbers basically because when we
2359.3|2.73|actually work with these we do a lot of
2360.44|3.0|vectorize operations so we receive a
2362.03|3.54|tensor which is really just a n
2363.44|5.52|dimensional array and we scale it by a
2365.57|5.46|constant and you can see that this layer
2368.96|3.63|actually just has 40 lines there's some
2371.03|3.39|initialization stuff this is low up by
2372.59|4.83|the way if this is looking some foreign
2374.42|4.95|to you but there's initialization where
2377.42|4.89|you actually pass in that a that you
2379.37|4.68|want to use as you're scaling and then
2382.31|3.99|during the forward pass which they call
2384.05|4.26|update output in a forward pass all they
2386.3|3.93|do is they just multiply a X and return
2388.31|5.1|it and in the backward pass which they
2390.23|4.41|call update grad input there's an if
2393.41|2.37|statement here but really when you look
2394.64|2.91|at these three lines that are most
2395.78|3.39|important you can see that all it's
2397.55|3.84|doing is it's copying into a variable
2399.17|4.08|grad input which needs to compute that's
2401.39|4.29|your gradient that you're passing up the
2403.25|4.44|grad input is you're copying grad output
2405.68|4.14|grad output is your your gradient on the
2407.69|3.69|final loss you're copying that over into
2409.82|3.48|grad input and you're multiplying by the
2411.38|3.75|by the scalar which is what you should
2413.3|3.51|be doing because you're your local
2415.13|3.6|gradient is just a and so you take the
2416.81|3.57|output you have you take the gradient
2418.73|3.06|from above and you just scale it by a
2420.38|3.15|which is what these three lines are
2421.79|4.62|doing and that's your grad input and
2423.53|5.07|that's what you return so that's one of
2426.41|4.38|the hundreds of layers that are in torch
2428.6|4.41|we can also look at examples in cafe
2430.79|3.9|cafe is also deep learning framework
2433.01|3.54|specifically for images that you might
2434.69|3.21|be working with again if you go into the
2436.55|3.09|layers directory and github you just see
2437.9|3.96|all these layers all of them implement
2439.64|3.78|the forward backward API so just to give
2441.86|6.42|you an example there's a sigmoid layer
2443.42|6.6|in cafe so sigmoid layer takes a blob so
2448.28|4.02|cafe likes to call these tensors blobs
2450.02|3.69|so it takes a blob is just an N
2452.3|3.06|dimensional array of numbers and it
2453.71|3.6|passes it element-wise through a sigmoid
2455.36|4.35|function and so it's computing in a
2457.31|5.88|forward pass a sigmoid which you can see
2459.71|5.07|there I'll use my pointer okay so there
2463.19|3.03|it's calling so a lot of this stuff is
2464.78|3.21|just boilerplate getting
2466.22|4.23|to all the data and then we have a
2467.99|4.2|bottom blob and we're calling a sigmoid
2470.45|2.909|function on the bottom and that's just
2472.19|2.909|the sigmoid function right there so
2473.359|4.26|that's what we compute and in a backward
2475.099|3.901|pass some boilerplate stuff but really
2477.619|3.99|what's important is we need to compute
2479.0|4.59|the gradient times the chain rule here
2481.609|3.841|so that's what you see in this line
2483.59|4.62|that's where the magic happens where we
2485.45|5.79|take the diff so they call the gradients
2488.21|5.55|diffs and you compute the bottom this is
2491.24|5.34|the top diff times this piece which is
2493.76|4.2|really the that's the local gradient so
2496.58|4.11|this is chain rule happening right here
2497.96|4.59|through that multiplication so and
2500.69|3.72|that's it and so every single layer just
2502.55|3.72|a forward backward API and then you have
2504.41|3.27|a computational graph on top or a net
2506.27|5.76|object that keeps track of all the
2507.68|5.64|connectivity okay any questions about
2512.03|3.62|some of these implementations and so on
2513.32|2.33|go ahead
2520.46|3.67|yes thank you so the question is do you
2522.69|3.09|have to go through forward and backward
2524.13|4.08|for every update the answer is yes
2525.78|4.26|because when you want to do update you
2528.21|3.81|need the gradient and so you need to do
2530.04|3.66|forward on your sample mini-batch you do
2532.02|3.39|it forward you right away do a backward
2533.7|3.39|and now you have your NLE gradient and
2535.41|3.36|now i can do an update where I take my
2537.09|3.72|analytic gradient and I change my
2538.77|4.46|weights a tiny bit in the direction the
2540.81|5.25|negative grid direction of your gradient
2543.23|4.09|so forward computes the loss backward
2546.06|3.24|computes your gradient and then the
2547.32|4.53|update uses the gradient to increment
2549.3|3.51|your weights a bit so that's what keeps
2551.85|1.83|happening in loop when you train a
2552.81|2.55|neural network that's all that's
2553.68|3.18|happening forward backward update
2555.36|10.32|forward backward update we'll see that
2556.86|13.92|in a bit good you're asking about the
2565.68|6.3|for loop oh is there for loop here I
2570.78|4.86|didn't even notice okay
2571.98|4.92|yeah they have a for loop yeah so you'd
2575.64|3.45|like this to be vectorized I'm not
2576.9|5.55|actually sure because this is C++ so I
2579.09|9.51|think yeah they just stuff just do it go
2582.45|7.2|for it yeah yeah so this is a CPU
2588.6|2.61|implementation by the way I should
2589.65|2.7|mention that this is a CPU
2591.21|3.33|implementation of the sigmoid layer
2592.35|4.02|there's a second file that implements
2594.54|4.65|the sigmoid layer on GPU and that's CUDA
2596.37|4.83|code and so that's a separate file it
2599.19|4.71|would be sigmoid Cu or something like
2601.2|5.67|that I'm not showing you that in the
2603.9|5.91|questions okay great so one point I'd
2606.87|4.53|like to make is will be of course
2609.81|3.06|working with vectors so these things
2611.4|2.58|flowing along our graphs are not just
2612.87|5.07|scalars they're going to be entire
2613.98|5.25|vectors and so nothing changes the only
2617.94|3.77|thing that is different now since these
2619.23|4.98|are vectors x y&z are vectors is that
2621.71|5.08|this local gradient which before used to
2624.21|4.23|be just a scalar now they're in general
2626.79|4.23|for general expressions they are full
2628.44|4.02|Jacobian matrices and so Jacobian matrix
2631.02|2.82|is just two-dimensional matrix and
2632.46|3.57|basically tells you what is the
2633.84|5.22|influence of every single element in X
2636.03|4.44|on every single element of Z and that's
2639.06|3.24|what you could be a matrix stores and
2640.47|5.01|the gradient is the same expression as
2642.3|9.06|before but now say here DZ by DX is a
2645.48|8.31|vector and BL by DZ is sorry
2651.36|4.5|DL by DS that is a vector and DZ by DX
2653.79|3.72|is an entire Jacobian matrix so you end
2655.86|3.0|up with an entire matrix vector multiply
2657.51|15.69|to actually change the gradient
2658.86|16.11|backwards no so I'll come I'll come back
2673.2|3.36|to this point in a bit you never
2674.97|2.94|actually end up forming the full
2676.56|3.6|Jacobian you'll never actually do this
2677.91|3.96|matrix multiply most of the time this is
2680.16|3.54|just a general way of looking at you
2681.87|3.24|know arbitrary function and I need to
2683.7|2.55|keep track of this and I think that
2685.11|2.91|these two are actually out of order
2686.25|2.97|because these are by DX is the Jacobian
2688.02|3.3|which should be on the left side so
2689.22|3.27|that's a I think that's a mistake in
2691.32|3.27|slide because this should be a matrix
2692.49|3.48|vector multiply so I'll show you why you
2694.59|3.57|don't actually need to ever form those
2695.97|5.1|jacobians so let's work with a specific
2698.16|5.19|example that is relatively common in
2701.07|4.8|neural networks suppose we have this
2703.35|4.35|non-linearity max of 0 and X so really
2705.87|4.26|what this is operation is doing is it's
2707.7|3.81|receiving a vector say Oh 4096 numbers
2710.13|4.59|which is a typical thing you might want
2711.51|5.43|to do 4096 numbers real-valued come in
2714.72|4.86|and you're computing an element-wise
2716.94|4.2|threshold in a so anything that is lower
2719.58|3.48|than zero gets clamped to zero and
2721.14|4.14|that's your function that you're
2723.06|4.86|computing and so up the vectors are the
2725.28|4.35|same dimension so the question here I'd
2727.92|5.45|like to ask is what is the size of the
2729.63|3.74|Jacobian matrix for this layer
2737.63|5.74|4,096 by 4096 in principle every single
2741.3|3.72|port number in here could have
2743.37|3.9|influenced every single number and there
2745.02|4.41|but that's not the case necessarily
2747.27|4.65|right so the second question is so this
2749.43|3.9|is a huge matrix 16 million numbers but
2751.92|7.53|why would you never form it what does
2753.33|7.98|the Jacobian actually look like no
2759.45|3.48|Jacobian will always be a matrix because
2761.31|6.18|every one of these 4096 could have
2762.93|7.23|influenced every it is so the Jacobian
2767.49|4.26|is still a giant 4096 by 4,000 Isaac's
2770.16|3.87|matrix but it has special structure
2771.75|9.99|right and what is that special structure
2774.03|12.18|good yeah so this Jacobian is a huge so
2781.74|5.94|it's 4096 by 4096 matrix but there's
2786.21|3.59|only elements on the diagonal because
2787.68|6.27|this is an element wise operation and
2789.8|6.52|moreover they're not just once but for
2793.95|4.08|whichever element was less than 0 it was
2796.32|4.92|clamped to 0 so some of these ones
2798.03|4.8|actually are zeros in whichever elements
2801.24|3.6|had a lower than 0 value during the
2802.83|4.62|forward pass and so the Jacobian would
2804.84|6.0|just be almost an identity matrix but
2807.45|4.8|some of them are actually there so you
2810.84|3.06|never actually would want to form the
2812.25|3.32|full Jacobian because that's silly and
2813.9|3.84|so you never actually want to carry out
2815.57|4.93|this operation as a matrix vector
2817.74|3.66|multiply because there's special
2820.5|3.33|structure that we want to take advantage
2821.4|5.19|of and so in particular the gradient the
2823.83|3.78|backward pass for for this operation is
2826.59|3.03|very very easy
2827.61|3.39|because you just want to look at all the
2829.62|4.95|dimensions where your input was less
2831.0|4.89|than 0 and you want to kill the gradient
2834.57|3.39|in those dimension you want to set the
2835.89|4.56|gradient to 0 in those dimensions so you
2837.96|4.53|take the grid output here and whichever
2840.45|4.26|numbers were less than 0 just set them
2842.49|4.41|to 0 set those gradients to 0 and then
2844.71|4.05|you continue backward pass so very
2846.9|9.41|simple operations in the in the end in
2848.76|7.55|terms of efficiency just refer back
2856.5|4.08|that's right that right you could do a
2858.45|5.04|matrix if you needed to in in your
2860.58|6.09|internal state but when you actually
2863.49|5.94|report back you're always just yeah so
2866.67|4.41|the question is the communication
2869.43|4.05|between the gates is always just vectors
2871.08|3.63|that's right so this Jacobian if you
2873.48|3.12|wanted to you can form that but that's
2874.71|3.48|internal to you inside the gate and you
2876.6|3.51|can use that to do backdrop but what's
2878.19|11.7|going back to other gates they only care
2880.11|11.04|about the gradient vector yes so the
2889.89|2.67|question is unless you end up having
2891.15|3.0|multiple outputs because then for each
2892.56|4.02|output we have to do this
2894.15|3.81|and so you yeah so we'll never actually
2896.58|3.42|run into that case because we almost
2897.96|3.24|always have a single output scalar value
2900.0|4.17|at the end because we're interested in
2901.2|4.17|loss functions so we just have a single
2904.17|2.61|number at the end that we're interested
2905.37|3.72|in computing gradients with respect to
2906.78|4.02|if we had multiple outputs then we have
2909.09|4.25|to keep track of all of those as well in
2910.8|4.95|parallel when we do the back propagation
2913.34|3.7|but we just have scalar valued loss
2915.75|9.42|functions so so we don't have to worry
2917.04|9.96|about that okay make sense so I want to
2925.17|4.08|also make the point that actually 4096
2927.0|4.17|dimension is not even crazy usually we
2929.25|3.57|use mini batches so say mini batch of
2931.17|4.86|100 elements going through at the same
2932.82|4.47|time and then you end up with 100 4096
2936.03|3.24|dimensional vectors that are all coming
2937.29|2.94|in in parallel but all the examples in a
2939.27|3.15|mini batch are processed independently
2940.23|5.13|of each other in parallel and so this
2942.42|4.38|Jacobian matrix really ends up being 400
2945.36|3.03|million four hundred thousand by four
2946.8|4.05|hundred thousand so huge so you never
2948.39|4.59|form these basically and you take some
2950.85|3.93|intake care to actually take advantage
2952.98|3.84|of the sparsity structure in that
2954.78|3.03|Jacobian and you hand code operations
2956.82|3.09|you don't actually write the fully
2957.81|8.01|generalized chain rule inside any gate
2959.91|7.44|implementation okay cool so I'd like to
2965.82|4.38|point out that in your assignment you'll
2967.35|4.14|be writing SVM's and softmax and so on
2970.2|2.79|and I just kind of wanted to give you a
2971.49|4.35|hint on the design of how you actually
2972.99|4.46|should approach this problem what you
2975.84|4.23|should do is just think about it as a
2977.45|4.81|back propagation even if you're doing
2980.07|4.41|this linear classification optimization
2982.26|5.64|so roughly your structure should look
2984.48|4.859|something like this where again stage
2987.9|3.929|your computation and units
2989.339|4.051|that you know the local gradient off and
2991.829|2.821|then do backdrop when you actually
2993.39|3.839|evaluate these gradients in your
2994.65|3.659|assignment so in the top your code will
2997.229|2.28|look something like this where we don't
2998.309|3.42|have any graph structure because you're
2999.509|3.661|doing everything in line so no crazy
3001.729|3.6|edges or anything like that that you
3003.17|3.449|have to do you will do that in the
3005.329|2.49|second assignment you'll actually come
3006.619|2.85|up with a graph object and you'll
3007.819|2.881|implement your layers but in the first
3009.469|4.08|assignment you're just doing it in line
3010.7|4.889|just straight up vanilla set up and so
3013.549|4.74|compute your scores based on W and X
3015.589|6.121|compute these margins which are max of
3018.289|6.72|zero and the score differences compute
3021.71|4.529|the loss and then do back drop and in
3025.009|3.57|particular I would really advise you to
3026.239|4.711|have this intermediate scores that you
3028.579|4.26|create as a matrix and then compute the
3030.95|3.809|gradient on scores before you compute
3032.839|3.78|the gradient on your weights and so
3034.759|4.02|chain use chain rule here otherwise
3036.619|4.41|you're like you might be tempted to try
3038.779|4.02|to just derive W the gradient on W
3041.029|3.0|equals and then implement that and
3042.799|3.151|that's an unhealthy way of approaching
3044.029|3.99|the problem so stage your computation
3045.95|6.269|and do back drop through this course and
3048.019|9.3|they will help you out okay
3052.219|6.991|cool so let's see something's in summary
3057.319|2.821|so far neural networks are hopelessly
3059.21|2.309|large so we end up with these
3060.14|3.57|computational structures and these
3061.519|3.99|intermediate nodes forward-backward api
3063.71|3.509|for both the nodes and also for the
3065.509|2.97|graph structure and the graph structure
3067.219|3.12|is usually a very thin wrapper around
3068.479|3.57|all these layers and it can handles all
3070.339|4.081|the communication between them and it's
3072.049|4.56|communication is always along like
3074.42|3.659|vectors being passed around in practice
3076.609|2.46|when we write these implementations what
3078.079|3.51|we're passing around are these
3079.069|4.831|n-dimensional tensors really what that
3081.589|4.23|means is just an N dimensional array so
3083.9|3.54|like a numpy array those are what goes
3085.819|3.3|between the gates and then internally
3087.44|5.669|every single gate knows what to do in
3089.119|5.761|the forward and backward pass ok so at
3093.109|3.541|this point I'm going to end with back
3094.88|3.419|propagation and I'm going to go into
3096.65|4.909|neural networks so any questions before
3098.299|3.26|we move on from background good
3110.79|5.32|the summation inside Li equals blah yeah
3114.85|2.91|so there's a sum there so you'd want
3116.11|3.63|that to be a vectorized operation that
3117.76|4.44|you are yeah so basically the challenge
3119.74|3.51|in your assignment almost is how do you
3122.2|2.67|make sure that you do all of this
3123.25|3.27|efficiently nicely with meters vector
3124.87|2.94|operations in numpy so that's going to
3126.52|8.07|be some of the brainteaser stuff that
3127.81|8.19|you guys are going to have to do yeah so
3134.59|3.84|it's up to you what you want your gates
3136.0|7.74|to be like and what you want them to be
3138.43|9.3|um yeah I don't I don't think you'd want
3143.74|5.7|to do that yeah I'm not sure maybe that
3147.73|4.46|works I don't know but yeah it's up to
3149.44|7.26|you to design this and to backdrop to it
3152.19|6.34|yeah so that's that's fun okay so we're
3156.7|5.55|going to go to neural networks this is
3158.53|5.22|exactly what they look like so you'll be
3162.25|2.82|implementing these and this is just what
3163.75|2.76|happens when you search on google images
3165.07|2.76|for neural networks this is I think the
3166.51|4.05|first results are simple like that
3167.83|4.35|so let's look at neural networks and
3170.56|3.87|before we dive into neural networks
3172.18|4.23|actually I'd like to do it first without
3174.43|3.15|all the brain stuff so forget that their
3176.41|3.48|neural forget that they have any
3177.58|3.84|relation whatsoever to a brain they
3179.89|3.6|don't but forget if you thought that
3181.42|4.44|they did that they do let's just look at
3183.49|4.38|score functions where before we saw that
3185.86|4.38|F equals W X is what we've been working
3187.87|3.87|with so far but now as I said we're
3190.24|3.36|going to start to make that F more
3191.74|3.06|complex and so if you wanted to use a
3193.6|4.32|neural network then you're going to
3194.8|6.24|change that equation to this so this is
3197.92|4.98|a two layer neural network and that's
3201.04|3.95|what it looks like and it's just a more
3202.9|5.73|complex mathematical expression of X and
3204.99|6.31|so what's happening here is you receive
3208.63|3.42|your input X and you make x matrix just
3211.3|3.21|like we did before
3212.05|4.53|now what's come back what comes next is
3214.51|3.09|a non-linearity or activation function
3216.58|2.49|and we're going to go into several
3217.6|3.3|choices that you might make for these in
3219.07|3.63|this case I'm using the threshold again
3220.9|3.75|zero as an activation function
3222.7|3.93|so basically we're doing matrix multiply
3224.65|4.14|we threshold everything negative to zero
3226.63|4.98|and then we do one more matrix multiply
3228.79|5.34|and that gives us our scores and so if I
3231.61|5.49|was to draw this say in case of C for
3234.13|5.19|ten with three solid 3072 numbers going
3237.1|3.21|in those are the pixel values and before
3239.32|2.61|we just went one thing
3240.31|3.96|matrix-multiply to scores we went right
3241.93|3.93|away to ten numbers but now we get to go
3244.27|4.35|through this intermediate representation
3245.86|5.64|of a hidden hidden state we'll call them
3248.62|5.34|hidden players so hidden vector H of
3251.5|3.93|hundred numbers say or whatever you want
3253.96|3.57|your size of their neural network to be
3255.43|4.38|so this is a hyper primer that say that
3257.53|3.72|hundred and we go through this
3259.81|2.67|intermediate representation so matrix
3261.25|3.51|multiply gives us hundred numbers
3262.48|3.74|threshold at zero and then one more
3264.76|4.11|makes multiplied to get this course and
3266.22|5.53|since we have more numbers we have more
3268.87|4.98|wiggle to do more interesting things so
3271.75|3.18|a more one particular example of
3273.85|2.55|something interesting you might want to
3274.93|3.3|what you might think that in your
3276.4|3.81|network could do is going back to this
3278.23|3.96|example of interpreting linear
3280.21|4.32|classifiers on C part N and we saw that
3282.19|4.86|the car class has this red car that
3284.53|4.14|tries to merge all the modes of
3287.05|5.22|different cars facing different
3288.67|7.62|directions and so in this case one
3292.27|5.82|single layer one single linear
3296.29|3.9|classifier had to go across all those
3298.09|3.72|modes and we couldn't deal with for
3300.19|3.84|example the cars of different colors
3301.81|3.33|that wasn't very natural to do but now
3304.03|2.37|we have hundred numbers in this
3305.14|3.12|intermediate and so you might imagine
3306.4|3.45|for example that one of those numbers
3308.26|3.6|could be just picking up on the red car
3309.85|3.9|facing forward it's just classifying is
3311.86|3.39|there a red car facing forward another
3313.75|2.19|one could be a red car facing slightly
3315.25|2.46|to the left
3315.94|4.44|let's car facing slightly to the right
3317.71|5.73|and those elements of H would only
3320.38|4.86|become positive if they find that thing
3323.44|4.26|in the image otherwise they stay at zero
3325.24|4.17|and so another H might look for green
3327.7|3.45|cars or yellow cars or whatever else in
3329.41|3.12|different orientations so now we can
3331.15|4.5|have a template for all these different
3332.53|5.04|modes and so these neurons turn on or
3335.65|5.4|off if they find the thing they're
3337.57|6.12|looking for a car of some specific type
3341.05|5.55|and then this w2 matrix can sum across
3343.69|4.59|all those little car templates so now we
3346.6|4.08|have like say 20 car templates of what
3348.28|4.17|cars could look like and now to compete
3350.68|3.09|the score of car classifier there's an
3352.45|3.45|additional matrix multiply so we have a
3353.77|4.56|choice of doing a weighted sum over them
3355.9|3.87|and so if any one of them turn on then
3358.33|3.51|through my weighted sum with positive
3359.77|4.41|weights presumably I would be adding up
3361.84|4.98|and getting the higher score and so now
3364.18|4.05|I can have a this multi modal car
3366.82|4.23|classifier through this additional
3368.23|5.55|hidden layer in between there so that's
3371.05|2.91|a hand wavy reason for why these would
3373.78|2.339|do
3373.96|14.159|something more interesting was their
3376.119|14.011|question so the question is if H had
3388.119|5.031|less than 10 units would it be inferior
3390.13|5.28|to a linear classifier I think that's a
3393.15|5.56|that's actually not obvious to me it's
3395.41|4.77|an interesting question I think you
3398.71|3.83|could make that work I think it could
3400.18|2.36|make it work
3402.78|3.52|yeah I think that would actually work
3404.53|3.18|someone should try that for extra points
3406.3|2.58|on the assignment so you'll have a
3407.71|3.659|section on the assignment do something
3408.88|3.45|fun or extra and so you get to come up
3411.369|2.281|with whatever you think is interesting
3412.33|2.93|experiment and we'll give you some bonus
3413.65|3.24|points so that's a good candidate for
3415.26|3.45|for something you might want to
3416.89|15.15|investigate whether that works or not
3418.71|21.69|any other questions good that's right
3432.04|17.67|nothing I understood the question yep
3440.4|10.99|yep I think so you're really asking
3449.71|3.12|about the layout of the H vector and how
3451.39|3.39|it gets allocated over the different
3452.83|3.81|modes of the data set and I don't have a
3454.78|3.36|good answer for that this since we're
3456.64|3.93|going to train this fully with back
3458.14|4.05|propagation I think it's likely naive to
3460.57|3.93|think that there will be exact template
3462.19|4.02|for sale left car facing red car facing
3464.5|4.23|left you probably won't find that you'll
3466.21|4.47|find these kind of like mixes and weird
3468.73|3.119|things intermediates and so on so
3470.68|2.76|there's no let work will come in and it
3471.849|3.871|will optimally find a way to truncate
3473.44|3.899|your data with it's linear boundaries
3475.72|3.119|and these weights we're all getting
3477.339|2.971|adjusted just to come to make it come
3478.839|5.871|out right so it's really hard to say
3480.31|4.4|well become tangled up I think good
3486.54|4.89|age was like Jose archer that's right so
3490.29|2.25|that's the size of a head and layer and
3491.43|4.68|that's a hyper parameter we get to
3492.54|5.04|choose that so I chose 100 usually
3496.11|2.64|that's going to be usually you'll see
3497.58|3.33|that with neural networks we'll go into
3498.75|3.99|this a lot but usually you want them to
3500.91|4.38|be as big as possible as it fits in your
3502.74|11.43|computer and so on so more is better but
3505.29|11.19|we'll go into that good so you're asking
3514.17|4.41|do we always take max of 0 and H and we
3516.48|4.77|don't and I'll get it's like 5 slides
3518.58|4.77|that way so I'm going to go into neural
3521.25|4.05|networks I guess maybe I should
3523.35|4.32|preemptively just go ahead and then take
3525.3|3.54|questions near the end if you wanted
3527.67|2.46|this to be a three layer neural network
3528.84|3.03|by the way there's a very simple way in
3530.13|2.97|which we just extend this right so we
3531.87|2.46|just keep continuing the same pattern
3533.1|3.12|where we have all these intermediate
3534.33|3.6|hidden nodes and then we can keep making
3536.22|3.12|our network deeper and deeper and you
3537.93|2.88|can compute more interesting functions
3539.34|3.42|because you're giving yourself more time
3540.81|4.86|to compute something interesting in a
3542.76|6.0|hand wavy way now one other slide I
3545.67|4.74|wanted to flash is that training a two
3548.76|3.09|layer neural network I mean it's
3550.41|2.88|actually quite simple when it comes down
3551.85|3.81|to it so this is a slide borrowed from a
3553.29|4.59|blog post I found and basically it
3555.66|3.93|suffice as roughly 11 lines of Python to
3557.88|4.38|implement a two layer neural network
3559.59|5.1|doing binary classification on what is
3562.26|5.57|this two dimensional data so you have a
3564.69|5.37|two dimensional data matrix X you have
3567.83|5.2|sorry it's three dimensional and you
3570.06|4.74|have binary labels for Y and then sin 0
3573.03|3.72|sin 1 are your weight matrices weight
3574.8|3.89|one way to and so I think they're called
3576.75|4.41|sin for sin apps but I'm not sure and
3578.69|5.32|then this is the optimization loop here
3581.16|5.49|and what you're seeing here I should use
3584.01|3.81|my pointer more what you're seeing here
3586.65|3.87|is we're computing the first layer
3587.82|4.62|activations but this is using a sigmoid
3590.52|3.63|non-linearity not a max of 0 necks and
3592.44|3.9|we're going to a bit of what these
3594.15|4.05|linked nonlinearities might be so
3596.34|3.33|sigmoid is one form is computing the
3598.2|3.15|first layer and then computing the
3599.67|4.11|second layer and then it's computing
3601.35|4.2|here right away the backward pass so
3603.78|4.74|this is the l2 Delta is the gradient on
3605.55|5.73|l2 the gradient on l1 and the gradient
3608.52|4.8|and this is a Maitre is an update here
3611.28|3.48|so right away he's doing an update at
3613.32|3.51|the same time as doing the final piece
3614.76|4.49|of backdrop here where he's formulating
3616.83|5.42|the gradient on the W and right
3619.25|4.71|he's adding to - gradient here and so
3622.25|2.67|really 11 lines suffice to train the
3623.96|3.18|neural network do a binary
3624.92|4.77|classification the reason that this loss
3627.14|4.14|might look slightly different from what
3629.69|3.75|you've seen right now is that this is a
3631.28|3.39|logistic regression loss so you saw a
3633.44|2.61|generalization of it which is the
3634.67|3.42|softmax classifier into multiple
3636.05|3.6|dimensions but this is basically a
3638.09|2.7|logistic loss being updated here and you
3639.65|3.24|can go through this in more detail by
3640.79|4.17|yourself but the logistic regression
3642.89|6.69|loss looks slightly different and that's
3644.96|7.32|being that's inside there but otherwise
3649.58|4.77|yes so this is not too crazy of a
3652.28|3.6|computation and very few lines of code
3654.35|2.97|suffice to actually train these networks
3655.88|4.2|everything else is Plouffe how do you
3657.32|4.44|make it efficient how do you there's a
3660.08|3.36|cross-validation pipeline that you need
3661.76|3.72|to have and all this stuff that goes on
3663.44|3.81|top to actually give these large code
3665.48|3.81|bases but the kernel of it is quite
3667.25|3.66|simple we compute these layers do
3669.29|3.12|forward pass we do backward pass we do
3670.91|5.79|an update which isn't raining this over
3672.41|6.51|and over again good the random function
3676.7|3.93|is creating your first initial random
3678.92|7.74|weights so you need to start somewhere
3680.63|7.26|so you generate a random W ok now I
3686.66|2.55|wanted to mention that you'll also be
3687.89|3.36|training a two layer neural network in
3689.21|3.15|this class so you'll be doing something
3691.25|2.76|very similar to this but you're not
3692.36|3.9|using logistic regression and you might
3694.01|3.99|have different activation functions but
3696.26|3.63|again just my advice to you when you
3698.0|4.26|implement this is stage your computation
3699.89|4.02|into these intermediate results and then
3702.26|3.96|do proper back propagation into every
3703.91|7.26|intermediate result so you might have
3706.22|7.08|you compute your let's see you compute
3711.17|3.6|you receive these weight matrices and
3713.3|3.69|also the biases I don't believe you have
3714.77|4.49|biases actual on your SVM n in your
3716.99|4.44|softmax but here you'll have biases so
3719.26|3.52|take your weight matrices and the biases
3721.43|3.18|compute the first inner layer compete
3722.78|4.14|your scores compete your loss and then
3724.61|5.19|do backward pass so back drop into
3726.92|5.1|scores then back drop into the weights
3729.8|5.28|at the second layer and back drop into
3732.02|5.16|this h1 vector and then through h1 back
3735.08|4.23|drop into the first weight matrices and
3737.18|4.53|the first biases okay so do proper back
3739.31|4.74|propagation here otherwise if you try to
3741.71|4.2|write away just say what is DW 1 what is
3744.05|3.18|the gradient on W 1 if you just try to
3745.91|2.61|make it a single expression for it it
3747.23|3.93|will be way too large and you'll have
3748.52|4.089|headaches so do it through series of
3751.16|6.8|steps in back propagation
3752.609|6.611|no that's just a hint okay so now I'd
3757.96|2.579|like to so that was the presentation of
3759.22|3.389|neural networks without all the brain
3760.539|4.23|stuff and so it looks fairly simple so
3762.609|4.051|now we're going to make it slightly more
3764.769|3.81|insane by folding in all kinds of like
3766.66|3.629|motivations mostly historical about like
3768.579|4.321|how this came about that it's related to
3770.289|4.141|bringing it all and so we have neural
3772.9|3.06|networks and we have neurons inside
3774.43|4.23|these neural networks so this is what
3775.96|3.99|neurons look like this is just what
3778.66|4.109|happens when you search on image search
3779.95|4.23|neurons so there you go now your actual
3782.769|3.06|biological neurons don't look like this
3784.18|5.25|for cuddling they actually look more
3785.829|4.98|like that and so a neuron just very
3789.43|4.109|briefly just to give you an idea about
3790.809|4.56|where this is all coming from you have a
3793.539|3.54|cell body or a soma as people like to
3795.369|3.48|call it and it's got all these dendrites
3797.079|3.811|that are connected to other neurons
3798.849|4.591|there's a cluster of other neurons and
3800.89|4.53|cell bodies over here and dendrites are
3803.44|4.829|really these appendages that listen to
3805.42|5.28|them so this is your inputs to a neuron
3808.269|4.26|and then it's got a single axon that
3810.7|4.829|comes out of a neuron that carries the
3812.529|5.641|the output of the computation that this
3815.529|4.83|neuron performs so usually usually have
3818.17|5.76|this neuron receives inputs if many of
3820.359|5.7|them align then this cell the neuron can
3823.93|4.71|choose to spike it sends an activation
3826.059|5.341|potential down the axon and then this
3828.64|4.26|actually like diverges out to connect to
3831.4|3.54|dendrites of other neurons that are
3832.9|3.719|downstream so there are other neurons
3834.94|3.389|here and their dendrites connect to the
3836.619|3.93|axons of these guys so basically just
3838.329|4.44|neurons connected through these synapses
3840.549|3.72|in between and we have these dendrites
3842.769|3.421|that are the input to neuron and this
3844.269|4.59|axon that actually carries the output of
3846.19|4.409|a neuron and so basically you can come
3848.859|5.19|up with a very crude model of a neuron
3850.599|5.91|and it will look something like this we
3854.049|4.681|have an axon so this is the cell body
3856.509|4.26|here of a neuron and just imagine an
3858.73|4.589|axon coming from a different neuron
3860.769|3.961|somewhere in the network and this neuron
3863.319|4.02|is connected to that neuron through this
3864.73|5.369|synapse and every one of these synapses
3867.339|5.131|has a weight associated with it of how
3870.099|6.121|much this neuron likes that neuron
3872.47|5.01|basically and so axon carries this X it
3876.22|3.629|interacts in the synapse and they
3877.48|4.98|multiply in this crude model so you get
3879.849|5.281|W 0 X 0 floating a flowing to the soma
3882.46|3.69|and then that happens for many neurons
3885.13|3.419|so you have lots of inputs
3886.15|5.31|W times X flowing in and the cell body
3888.549|5.01|here it just performs in some offset by
3891.46|5.49|bias and then if an activation function
3893.559|6.03|is met here so it passes through an
3896.95|5.669|activation function to actually compute
3899.589|4.891|the output of this axon now in
3902.619|3.93|biological models historically people
3904.48|3.299|like to use the sigmoid non-linearity to
3906.549|3.151|actually use for the activation function
3907.779|4.141|the reason for that is because you get a
3909.7|3.839|number between 0 and 1 and you can
3911.92|3.929|interpret that as the rate at which this
3913.539|5.191|neuron is firing for that particular
3915.849|4.321|input so it's a rate between 0 and 1
3918.73|3.42|that's going through the activation
3920.17|3.75|function so if this neuron is seeing
3922.15|3.959|something it likes in the neurons that
3923.92|4.76|connect to it it will start to spike a
3926.109|5.521|lot and the rate is described by F of
3928.68|4.689|the input okay so that's the crude model
3931.63|2.76|of a neuron if I want to implement this
3933.369|4.561|it would look something like this
3934.39|5.429|so a neuron tick function forward pass
3937.93|5.73|it receives some inputs this is a vector
3939.819|5.97|and we form of some at the cell body so
3943.66|3.929|just a linear sum and we put and we
3945.789|4.171|compete the firing rate as a sigmoid of
3947.589|4.23|the cell body sum and return the firing
3949.96|3.599|rate and then this can plug in two
3951.819|3.061|different neurons right so you can
3953.559|3.211|imagine you can actually see that this
3954.88|4.38|looks very similar to a linear
3956.77|5.43|classifier right we're forming a linear
3959.26|4.5|sum here a weighted sum and we're
3962.2|3.659|passing that through a non-linearity so
3963.76|3.75|every single neuron in this model is
3965.859|3.661|really like a small linear classifier
3967.51|4.079|but these linear classifiers plug into
3969.52|4.74|each other and they can work together to
3971.589|4.01|do interesting things now one note to
3974.26|4.22|make about neurons is that they're very
3975.599|5.321|they're not like biological neurons
3978.48|3.7|biological neurons are super complex so
3980.92|3.03|if you go around and you start saying
3982.18|4.53|that neural networks work like brain
3983.95|4.29|people are starting to frown and people
3986.71|4.29|start to frown at you and that's because
3988.24|4.23|neurons are complex dynamical systems
3991.0|3.869|there are many different types of
3992.47|5.73|neurons they function differently these
3994.869|4.651|dendrites there they can perform lots of
3998.2|3.659|interesting computation a good review
3999.52|4.589|article is a dendrite computation which
4001.859|3.96|I really enjoyed these synapses are
4004.109|3.93|complex dynamical systems they're not
4005.819|3.661|just a single weight and we're not
4008.039|3.601|really sure of the brain uses rate code
4009.48|4.319|to communicate so very crude
4011.64|4.56|mathematical model and don't don't push
4013.799|4.621|this analogy too much but it's good for
4016.2|3.93|kind of like media articles and
4018.42|3.84|so I suppose that's why this keeps
4020.13|3.57|coming up again and again as we explain
4022.26|3.14|that this works like your brain but okay
4023.7|3.93|I'm not going to go too deep into this
4025.4|4.33|to go back to a question that was asked
4027.63|5.419|before there's an entire set of
4029.73|3.319|nonlinearities that we can choose from
4033.799|4.841|so historically sigmoid has been used
4037.53|2.7|quite a bit and we're going to go into
4038.64|3.449|much more detail over what these
4040.23|3.51|nonlinearities are what are their trades
4042.089|3.811|trade offs and why you might want to use
4043.74|3.39|one or the other but for now I just like
4045.9|3.149|to flash them and mention that there are
4047.13|5.04|many things to choose from historically
4049.049|4.411|people use sigmoid @nh as of 2012 relu
4052.17|3.78|became quite popular
4053.46|4.95|it makes your networks converge quite a
4055.95|4.53|bit faster so right now if you wanted a
4058.41|3.81|default choice for a non-linearity use
4060.48|3.93|relu that's the current default
4062.22|4.53|recommendation and then there's a few
4064.41|4.38|kind of a hipster activation functions
4066.75|4.74|here and so leaky relatives were
4068.79|4.47|proposed a few years ago max out is
4071.49|3.359|interesting very recently
4073.26|3.539|Allu and so you can come up with
4074.849|3.301|different activation functions and you
4076.799|3.481|can describe why these might work better
4078.15|3.719|or not and so this is an active area of
4080.28|4.079|research is trying to come up with these
4081.869|4.051|activation functions that perform that
4084.359|4.171|had better properties in one way or
4085.92|4.86|another so we're going to go into this
4088.53|3.6|much more detail soon in the class but
4090.78|5.13|for now we have these neurons we have a
4092.13|5.76|choice of activation function and then
4095.91|3.329|we rank these neurons into neural
4097.89|2.61|networks right so we just connect them
4099.239|3.87|together so they can talk to each other
4100.5|4.5|and so here's an example of a what to
4103.109|3.511|layer neural at or 3 layer and all that
4105.0|3.089|when you want to count the number of
4106.62|3.239|layers and their neural net you count
4108.089|3.75|the number of layers that have weights
4109.859|4.98|so here the input layer does not count
4111.839|4.831|as a layer because there's no these
4114.839|3.511|neurons are just single values they
4116.67|3.96|don't actually do any computation so we
4118.35|4.98|have two layers here that that could
4120.63|4.439|have weights so it's a two layer net and
4123.33|4.529|we call these layers fully connected
4125.069|5.46|layers and so remember that I've shown
4127.859|4.71|you that a single neuron computes this
4130.529|3.601|little weighted sum and then passes a
4132.569|3.571|through non-linearity in a neural
4134.13|4.08|network the reason we arrange these into
4136.14|2.4|layers is because arranging them into
4138.21|1.62|layers
4138.54|2.909|allows us to perform the computation
4139.83|3.33|much more efficiently so instead of
4141.449|2.73|having an amorphous blob of neurons and
4143.16|2.789|every one of them has to be computed
4144.179|3.451|independently having them in layers
4145.949|3.961|allows us to use vectorized operations
4147.63|3.01|and so we can compute an entire set of
4149.91|3.04|neurons
4150.64|4.02|single hidden layer as just at a single
4152.95|3.09|time as a matrix multiply and that's why
4154.66|3.18|we arrange them in these layers where
4156.04|3.75|neurons inside a layer can be evaluated
4157.84|3.93|completely in parallel and they all see
4159.79|4.41|the same input so it's a computational
4161.77|5.64|trick to arrange them in layers so this
4164.2|5.49|is a three layer neural net and this is
4167.41|3.63|how you would compute it just a bunch of
4169.69|3.72|matrix multiplies followed by a non
4171.04|5.07|activation followed by a activation
4173.41|5.81|function so now I'd like to show you a
4176.11|5.25|demo of how these neural networks work
4179.22|4.24|so this is JavaScript demo that I'll
4181.36|4.91|show you in a bit but basically this is
4183.46|5.01|an example of a two layer neural network
4186.27|3.79|classifying a doing a binary
4188.47|3.42|classification task so we have two
4190.06|3.72|classes red and green and so we have
4191.89|3.39|these points in two dimensions and I'm
4193.78|3.48|drawing the decision boundaries by the
4195.28|4.17|neural network and so what you can see
4197.26|4.56|is when I train a neural network on this
4199.45|4.47|data the more hidden neurons I have in
4201.82|3.54|my head and layer the more wiggle your
4203.92|4.95|neural network has right the more it can
4205.36|4.86|compute crazy functions and just to show
4208.87|3.75|you effect also of regularization
4210.22|5.52|strength so this is the regularization
4212.62|4.47|of how much you penalize large w's so
4215.74|3.18|you can see that when you insist that
4217.09|5.37|your WS are very small you end up with
4218.92|6.87|very smooth functions so they don't have
4222.46|4.8|as much variance so these neural
4225.79|3.18|networks there's not as much wiggle that
4227.26|3.87|they can give you and then as you
4228.97|3.42|decrease the regularization these neural
4231.13|2.97|networks can do more and more complex
4232.39|3.75|tasks so they can kind of get in and get
4234.1|4.35|these little squeezed out points to
4236.14|7.05|cover them in the training data so let
4238.45|10.41|me show you what this looks like joint
4243.19|7.53|training okay so there's some stuff to
4248.86|4.68|explain here I'll let me first actually
4250.72|5.39|want so you can play with this because
4253.54|6.72|it's all in JavaScript
4256.11|7.48|okay all right so what we're doing here
4260.26|5.34|is we have six neurons and this is a
4263.59|4.83|binary classification data set with with
4265.6|4.92|circle data and so we have a little
4268.42|4.68|cluster of green dot separated by red
4270.52|4.8|dots and we're training a neural network
4273.1|4.08|to classify this data set so if I
4275.32|3.78|restart the neural network it just
4277.18|3.39|started off with a random EE and then it
4279.1|3.15|converges the decision boundary to
4280.57|3.03|actually classify the data what I'm
4282.25|2.22|showing on the right which is the cool
4283.6|3.0|part this is visualized
4284.47|3.54|is one interpretation of the neural
4286.6|4.08|network here is what I'm taking this
4288.01|5.37|grid here and I'm showing how this space
4290.68|4.11|gets warped by the neural network so you
4293.38|3.51|can interpret what the neural network is
4294.79|4.02|doing is its using its hidden layer to
4296.89|3.87|transform your input data in such a way
4298.81|3.63|that the second hidden layer can come in
4300.76|5.85|with a linear classifier and classify
4302.44|6.12|your data so here you see that the
4306.61|4.14|neural network arranges your space it
4308.56|4.2|warps it such that the second layer
4310.75|4.68|which is really a linear classifier on
4312.76|5.25|top of the first layer is again put a
4315.43|3.99|plane through it okay so it's warping
4318.01|3.48|the space so that you can put a plane
4319.42|5.67|through it and separate at the points so
4321.49|5.67|let's look at this again so initial okay
4325.09|3.54|so you can roughly see what how this
4327.16|4.2|gets warped so that you can linearly
4328.63|4.17|classify the data this is something that
4331.36|3.81|people sometimes also refer to as kernel
4332.8|4.05|trick it's changing your data
4335.17|5.73|representation to a space where it's
4336.85|5.4|linearly separable okay now here's a
4340.9|3.39|question if we'd like to separate so
4342.25|3.69|right now we have six neurons here in
4344.29|5.46|the intermediate layer and it allows us
4345.94|5.28|to separate out these data points so you
4349.75|4.08|can see actually those six neurons
4351.22|4.11|roughly you can see these lines here
4353.83|3.0|like they're kind of like these
4355.33|3.15|functions of one of these neurons so
4356.83|3.48|here's a question for you what is the
4358.48|5.13|minimum number of neurons for which this
4360.31|5.04|data set is separable with the neural
4363.61|3.21|network like if I wanted to neural
4365.35|2.7|network to correctly classify this how
4366.82|4.04|many neurons do I need in the hidden
4368.05|2.81|layer as a minimum
4377.31|8.74|for I heard some theories some force and
4383.2|4.41|binary search so intuitively the way
4386.05|8.82|this will work is let's see let's see
4387.61|9.27|for so what happens with for is there's
4394.87|3.84|one neuron here that went from this way
4396.88|3.6|to that way this way to that way this
4398.71|3.99|way to that way there's four neurons
4400.48|3.69|that are cutting up this plane and then
4402.7|4.29|there's an additional layer that's doing
4404.17|5.28|a weighted sum so in fact the lowest
4406.99|6.33|number here with I would be three which
4409.45|6.96|would work so with three neurons oh okay
4413.32|4.74|it's going to happen so one plane second
4416.41|3.63|plane third plane so three linear
4418.06|5.25|functions with a non-linearity and then
4420.04|5.85|you can basically with three lines you
4423.31|4.83|can carve out the space so that the
4425.89|6.63|second layer can just combine them when
4428.14|7.32|their numbers are one and not zero at 2
4432.52|5.55|certainly so at 2 this will break
4435.46|4.05|because two lines are not enough suppose
4438.07|4.05|this work something I'm not going to
4439.51|4.86|look very good here yeah so with two
4442.12|4.32|basically it will find the optimum way
4444.37|5.04|of just using these two lines they're
4446.44|14.01|kind of creating this tunnel and that's
4449.41|13.13|the best you can do ok the curve I think
4460.45|4.68|which shall not only retain my using 10h
4462.54|4.66|yeah I'm not sure exactly how that works
4465.13|5.34|out if I was using relu I think there
4467.2|4.62|would be much Sorrell ooh is the so let
4470.47|7.89|me change to relu and I think you'd see
4471.82|10.94|sharper boundaries yeah yes this is
4478.36|4.4|three oh you can do four so let's do
4487.08|6.22|yeah that's because it's because in some
4491.11|4.53|of these parts there's more than one of
4493.3|5.64|those Ray Lewis are active and so you
4495.64|5.46|end up with there are really 3 lines I
4498.94|4.47|think like 1 2 3 but then in some of the
4501.1|3.93|corners 2 real neurons are active and so
4503.41|2.91|these weights will add up it's kind of
4505.03|6.75|funky you have to think about it a bit
4506.32|7.65|but ok so let's look at say 20 here so
4511.78|4.05|change to 20 so we have lots of space
4513.97|4.56|there and let's look at different data
4515.83|4.65|sets like say spiral so you can see how
4518.53|4.56|this thing just as I'm doing this update
4520.48|6.81|it will just go in there and figure that
4523.09|9.98|out or very simple data set it's not
4527.29|9.42|okay spiral circle yeah and then random
4533.07|5.29|so it's a random data and so it kind of
4536.71|5.96|goes in there and it like covers up the
4538.36|9.06|the green ones from the red ones and
4542.67|5.95|yeah and with fewer say like 5 oh I'm
4547.42|5.91|going to break this now
4548.62|6.27|it's not going to okay so if 5 yeah so
4553.33|2.43|this will start working worse and worse
4554.89|3.87|because you don't have enough capacity
4555.76|7.17|to separate out this data so you can
4558.76|8.22|play with this in your every time okay
4562.93|5.64|and so as a summary we arrange these
4566.98|3.96|neurons into neural in neural networks
4568.57|3.93|into fully connected layers we've looked
4570.94|3.75|at backdrop and how this gets changing
4572.5|4.71|computational graphs and they're not
4574.69|4.53|really neural and as well see soon the
4577.21|4.02|bigger the better and we'll go into that
4579.22|3.6|a lot I want to take questions before I
4581.23|9.739|and just sorry we're not any questions
4582.82|10.879|go ahead we have two more minutes sorry
4590.969|5.52|always better to warn yours or is it
4593.699|4.621|also like over big issues yeah so thank
4596.489|3.811|you so is it always better to have more
4598.32|5.64|neurons in your neural network the
4600.3|7.379|answer to that is yes more it's always
4603.96|5.4|better it's usually computational
4607.679|3.27|constraint so more will always work
4609.36|3.48|better but then you have to be careful
4610.949|3.48|to regularize it properly so the correct
4612.84|3.27|way to constrain your neural networks do
4614.429|3.601|not over fit your data is not by making
4616.11|3.469|the network smaller the correct way to
4618.03|4.109|do it is to increase your regularization
4619.579|3.79|so you always want to use as large of a
4622.139|3.36|network as you want but then you have to
4623.369|3.63|make sure to properly regularize it but
4625.499|2.761|most of the time because computational
4626.999|2.79|reasons you have finite amount of time
4628.26|3.87|you don't want to wait forever to train
4629.789|8.401|your networks you'll use smaller ones
4632.13|8.52|for practical reasons question do you
4638.19|6.48|regularize each layer equally usually
4640.65|5.159|you do as a simplification you yeah most
4644.67|2.13|of the often when you see networks
4645.809|3.33|trained in practice they will be
4646.8|8.85|regularized the same way throughout but
4649.139|7.65|you don't have to necessarily good is
4655.65|2.489|there any value to using second
4656.789|3.27|derivatives using the Hessian in
4658.139|4.23|optimizing neural networks there is
4660.059|4.261|value sometimes when your datasets are
4662.369|3.451|small you can use things like l-bfgs
4664.32|3.12|which I didn't go into too much and
4665.82|3.27|that's a second order method but usually
4667.44|3.299|the datasets are really large and that's
4669.09|2.909|when l-bfgs doesn't work very well so
4670.739|4.13|when you have millions of data points
4671.999|5.461|you can't do l-bfgs for various reasons
4674.869|4.15|yeah and l-bfgs is not very good with
4677.46|6.559|mini-batch you always have to do full
4679.019|5.0|batch by default question
4688.749|4.321|yeah so what is the trade-off between
4690.909|3.991|depth and size roughly like how do you
4693.07|4.649|allocate not a good answer for that
4694.9|5.369|unfortunately so you want depth is good
4697.719|3.9|but maybe after like 10 layers maybe if
4700.269|4.111|you have simple data set it's not really
4701.619|3.991|adding too much we have one more minute
4704.38|8.31|so I can still take some questions you
4705.61|9.96|had a question for awhile yeah so the
4712.69|4.23|the the trade-off between where do I a
4715.57|4.049|locate my capacity do I want this to be
4716.92|8.579|deeper or do I want it to be wider not a
4719.619|7.77|very good answer to that yes usually
4725.499|3.72|especially with images we find that more
4727.389|3.451|layers are critical but sometimes when
4729.219|3.84|you have simple datasets like 2d are
4730.84|4.5|some other things like depth is not as
4733.059|5.64|critical and so it's kind of slightly
4735.34|11.58|data dependent with a question over
4738.699|10.02|there different activation functions for
4746.92|3.779|different layers does that help usually
4748.719|5.911|it's not done usually just kind of pick
4750.699|5.25|one and go with it so say I for comm
4754.63|2.219|that's for example we'll also see that
4755.949|2.79|most of them are trained just with
4756.849|3.27|relatives and so you just use that
4758.739|3.331|throughout and there's no real benefit
4760.119|3.54|to to switching them around people don't
4762.07|4.169|play with that too much but in principle
4763.659|4.23|you there's nothing preventing you so it
4766.239|3.09|is 4/20 so we're going to end here but
4767.889|2.94|we'll see lots of more neural networks
4769.329|3.861|so a lot of these questions will we'll
4770.829|2.361|go through them