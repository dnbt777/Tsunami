start_time|end_time|text
2.0|3.84|There is more seats on the side for people walking in late.
11.06|5.56|So just to make sure you are in CS231n
18.34|4.4|The deep learning on neural network class for visual recognition
23.74|2.64|Anybody in the wrong class? Okay, good.
27.54|6.4|Alright, so welcome and happy new year, happy first day of the winter break
37.829|5.401|the second offering of this class when
we have literally doubled our enrollment
43.23|7.05|and from a hundred eighty people last
time we offered to about 350 of you
50.28|6.99|signed up just a couple of words to do
to make us all legally covered we are
57.27|6.81|video recording this class so um you
know if you're uncomfortable about this
64.08|7.23|for today just go behind the camera or
go to a corner that the camera is not
71.31|7.29|gonna turn but we are going to send out
forms for you to fill out in terms of
78.6|6.629|allowing a video recording so so that's
that's just one bit of housekeeping so
85.229|5.43|um all right um my name is Faye Faye Lee
I'm a professor at the computer science
90.659|6.78|department so this class I'm co-teaching
with two senior graduate students and
97.439|4.761|one of them is here is Andre capaci
and ray can you just say hi to everybody
102.2|4.779|we have well I don't think Andre needs
too much introduction a lot of you
106.979|8.1|probably know his work follow his blog
his Twitter follower Andre has way more
115.079|6.211|followers than I do
he's very popular and also Justin
121.29|3.689|Johnson who is still traveling
internationally but will be back in a
124.979|5.971|few days so Andre and Justin will be
picking up the bulk of the lecture
130.95|4.09|teaching
and today I'll be giving the first
135.04|5.19|lecture but as you probably can see that
I'm expecting a newborn ratio
140.23|8.039|speaking of weeks so you'll see more of
Andra and Justin in lecture time we will
148.269|5.94|also introduce a whole team of TAS
towards the end of this lecture again
154.209|4.621|people who are looking for seats if you
go out of that door and come back there
158.83|7.11|is a whole bunch of seats on this side
okay so let's so this for this lecture
165.94|6.45|we're going to give an introduction of
the class the kind of problems we work
172.39|10.01|on and the tools we'll be learning so
again welcome to CS 231n this is a
182.4|6.25|vision class it's based on a very
specific modeling architecture called
188.65|4.83|neural network and even more
specifically mostly on convolution on
193.48|7.46|your network and a lot of you hear this
term maybe through a popular press an
200.94|8.65|article we or coverage we tend to call
this the deep learning network vision is
209.59|8.549|one of the fastest growing field of
artificial intelligence in fact cisco
218.139|7.951|has estimated and and we are on day four
of this by 2016 which we already have
226.09|9.36|arrived more than 85% of the internet
cyberspace data is in the form of pixels
235.45|9.84|or what they call multimedia so so we
basically have entered an age of vision
245.29|7.319|of images and videos and why why is it
so well partially and to a large extent
252.609|7.91|is because of the explosion of both the
internet as a carrier of data as well as
260.519|5.781|sensors we have more sensors than the
number of people on earth these days
266.3|5.549|every one of you is carrying some kind
of smartphones digital cameras and and
271.849|5.88|and and you know cars are running on the
street with cameras so so the sensors
277.729|7.731|have really enabled the explosion of
visual data in the on the internet but
285.46|8.26|visual data or pixel data is also the
hardest data to harness so if you have
293.72|9.39|heard my previous talks and some other
um talks by computer vision professors
303.11|6.209|we call this the dark matter of the
internet why is this the dark matter
309.319|6.811|just like the universe is consisted of
85% dark matter dark energy is these
316.13|5.61|matters energy that is very hard to
observe we can we can infer it by
321.74|3.479|mathematical models in the universe on
the Internet
325.219|4.891|these are the matters pixel data other
the data that we don't know we have a
330.11|5.85|hard time grasping the contents here's
one very very simple aspects for you to
335.96|6.78|consider
so today YouTube servers every 60
342.74|9.539|seconds we have more than 150 hours of
videos uploaded onto YouTube servers for
352.279|8.851|every 60 seconds think about the amount
of data there's no way that human eyes
361.13|7.349|can sift through this massive amount of
data and and make annotations labeling
368.479|7.201|it and and and and describe the contents
so think from the perspective of the
375.68|8.22|YouTube team or Google company if they
want to help us to search index manage
383.9|4.859|and of course for their purpose put
advertisement or whatever manipulate the
388.759|7.051|content of the data were at loss because
nobody can hand annotate this the only
395.81|5.65|hope we can do this is through vision
technology to be able to label the
401.46|6.12|objects find the things find the frames
you know locate where that basketball
407.58|6.3|video were Kobe Bryant's making like
that awesome shot and so so these are
413.88|5.79|the problems that we are facing today
that the massive amount of data and the
419.67|6.09|the challenges of the dark matter so
computer vision is a field that touches
425.76|6.42|upon many other fields of studies so I'm
sure that even sitting here sitting here
432.18|4.31|many of you come from computer science
but many of you come from
436.49|6.7|biology psychology are specializing
natural language processing or graphics
443.19|6.39|or robotics or you know medical imaging
and so on so as a field computer vision
449.58|6.6|is really a truly interdisciplinary
field what the problems we work on the
456.18|6.36|models we use touches on engineering
physics biology psychology computer
462.54|6.48|science and mathematics so just a little
bit of a more personal touch I am the
469.02|6.51|director of the computer vision lab at
Stanford in our lab we I work with
475.53|4.53|graduate students and postdocs and and
and even undergraduate students on a
480.06|7.38|number of topics and most dear to our
own research who some of them you know
487.44|7.32|that Andre just didn't come from my lab
a number of TAS come from my lab we work
494.76|7.94|on machine learning which is part a
percent of deep learning we work a lot
502.7|5.77|cognitive science and neuroscience as
well as the intersection between NLP and
508.47|6.2|speech so that's that's the kind of
landscape of computer vision research
514.67|7.9|that my lab works in so also to put
things in a little more perspective what
522.57|4.91|are the computer vision classes that we
offer here at Stanford through the
527.48|5.57|computer science department
clearly you're in this class yes 21 n
533.05|8.07|and so you some of you who have never
taken computer vision probably have
541.12|7.23|heard of comparison for the first time I
probably should have already done CS 131
548.35|6.92|that's an intro class of previous
quarter we offered and then and then
555.27|4.66|next quarter which normally is offer
this quarter but this year is a little
559.93|6.02|shifted there's an important graduate
level computer vision class called CS
565.95|6.97|231 a offered by Professor Silvio subber
si who works in robotics and 3d vision
572.92|10.38|and a lot of you asked us the question
that are these you know do these replace
583.3|9.3|each other this class CS 231n vs. CS
231 a and the answer is no and if you're
592.6|9.21|interested in a broader coverage of
tools and topics of computer vision as
601.81|6.24|well as some of the fundamental
fundamental topics that comes that
608.05|5.52|relates you to 3d vision robotic vision
and visual recognition you should
613.57|9.59|consider taking 231 a that is the more
general class 231 n which will go into
623.16|7.24|starting today more deeply focuses on a
specific angle of both problem and model
630.4|7.02|the model is your network and the angle
is visual recognition mostly but of
637.42|7.35|course they have a little bit of overlap
but that's the major difference and next
644.77|7.02|next quarter we also have possibly a
couple of a couple of advanced
651.79|5.58|seven-hour level class but you that's
still in the formation stage so you just
657.37|5.43|have to check the syllabus so that's the
the kind of computer vision curriculum
662.8|6.11|we offer this
you're at Stanford any questions so far
668.91|11.53|yes 131 is not a strict requirement for
this class but you'll soon see that if
680.44|4.71|you've never heard of computer vision
for the first time I suggest you find a
685.15|5.7|way to catch up because this class
assumes a basic level of understanding
690.85|11.49|of of of computer vision you can browse
the notes and so on all right okay so
702.34|6.63|the rest of today is that I will give a
very brief broad stroke history of
708.97|5.52|computer vision and then we'll talk
about 231n a little bit in terms of
714.49|4.86|the organization of the class actually
really care about sharing with you this
719.35|5.97|brief history of computer vision because
you know you might be here primarily
725.32|4.77|because of your interesting this really
interesting tool called deep learning
730.09|5.85|and this is the purpose of this class
we're offering you an in-depth look in
735.94|5.64|them and just journey through the the
what this deep learning model is but
741.58|5.82|without understanding the problem domain
without thinking deeply about what this
747.4|9.84|problem is it's very hard for you to to
go on to be an inventor of the next
757.24|5.13|model that really solves a big problem
in vision or to be you know developing
762.37|8.79|developing making impactful work in
solving a heart problem and also in
771.16|5.91|general problem domain and model the
modeling tools themselves are never
777.07|6.62|never fully decoupled they inform each
other and you see through the history of
783.69|5.17|deep learning a little bit that the
convolutional neural network
788.86|6.899|architecture come from the need to solve
a vision problem and
795.759|7.471|then vision problem helps the the deep
learning algorithm to evolve and back
803.23|4.5|and forth so it's really important to to
you know I want you to finish this
807.73|5.609|course and feel proud that your student
of computer vision and of deep learning
813.339|6.18|so you have this boost tool set and the
in-depth understanding of how to use the
819.519|7.201|tools that to to to to tackle important
problems so it's a brief history but
826.72|4.919|doesn't mean it's a short history so
we're gonna go all the way back to two
831.639|5.97|hundred thirty five hundred forty
million years ago so why why did I pick
837.609|7.97|this you know on the scale of the the
earth history this is a fairly specific
845.579|5.62|range of years well so I don't know if
you have heard of this but this is a
851.199|7.62|very very curious period of the Earth's
history and biologists call this the Big
858.819|7.29|Bang of evolution before five hundred
three four five hundred forty million
866.109|7.29|years ago the earth is a very peaceful
pot of water I mean it's pretty big pot
873.399|6.511|of water so we have very simple
organisms these are like animals that
879.91|9.329|just floats in the water and the way
they eat and now on a daily basis is you
889.239|5.611|know they just float and if some kind of
food comes by near their mouths or
894.85|7.259|whatever they just open the mouth and
grab it and we don't have too many
902.109|7.2|different types of animals but something
really strange happened around five
909.309|6.421|hundred forty million years suddenly
from the fossils we study there's a huge
915.73|8.699|explosion of species the biologists call
speciation like suddenly for some reason
924.429|5.081|something hit the earth that animals
start to diversify
929.51|5.73|get really complex and they they start
to yellow to to you start to have
935.24|5.46|predators and praise and then they have
all kind of tools to to survive and what
940.7|5.43|was the triggering force of this was a
huge question because people were saying
946.13|6.18|oh did you know another set of whatever
a meteoroid hit the earth or or you know
952.31|7.2|the environment change it turned out one
of the most convincing theory is that by
959.51|6.21|this guy called Andrew Parker of his a
modern zoologist in Australia from
965.72|8.43|Australia he studied a lot of fossils
and his theory is that it was the onset
974.15|9.18|of the ice so one one of the first
trilobite developed and I a really
983.33|5.37|really simple I it's almost like a
pinhole camera that just catches light
988.7|5.66|and make some projections and register
some information from the environment
994.36|6.28|suddenly life is no longer so mellow
because once you have the eye the first
1000.64|4.02|thing you can do is you can go catch
food you actually know where food is
1004.66|6.3|you're not just like blind and and
floating the water and once you can go
1010.96|5.42|catch food guess what the food better
develop eyes and to run away from you
1016.38|4.75|otherwise they'll be gone you know
you're you're so the first element we
1021.13|4.53|had had eyes were like in a in a
unlimited buffet it's like working at
1025.66|6.45|Google and it just like it has the best
time you know eating everything they can
1032.11|7.53|but because of this onset of the eyes
what we whether the geologists realized
1039.64|9.66|is that the the biological arms race
began every single animal needs to needs
1049.3|5.4|to learn to develop things to survive or
to you know you you you suddenly have
1054.7|5.67|praise and predators and and all this
and the speciation begin so that's when
1060.37|6.6|vision become 540 million
years and not only vision began vision
1066.97|6.27|was one of the major driving force of
the speciation or the the big ban of
1073.24|5.31|evolution alright so so we're not going
to follow evolution for with too much
1078.55|8.61|detail another big important work that
focus on in engineering of vision
1087.16|6.75|happened around the Renaissance and of
course it's attributed to this amazing
1093.91|5.79|guy
Leonardo da Vinci so before Renaissance
1099.7|5.31|you know throughout human civilization
from Asia to Europe to India to Arabic
1105.01|6.45|world we have seen models of cameras so
Aristotle has proposed the camera
1111.46|6.11|through the leaves Chinese philosopher
Moses have proposed the camera through a
1117.57|8.29|box with a hole but if you look at the
first documentation of really a modern
1125.86|4.31|looking camera
it's called camera obscura obscura and
1130.17|6.61|that is documented by Leonardo da Vinci
I'm not going to get into the details
1136.78|7.56|but this is you know you get the idea
that there is some kind of lens or at
1144.34|7.32|least a hole to capture lights reflected
from the real world and then there is
1151.66|6.18|some kind of projection to capture the
information of the of the of the real
1157.84|9.69|world image so that's the beginning of
the modern you know of engineering of
1167.53|5.07|vision
it started with wanting to copy the
1172.6|6.42|world and wanting to make a copy of the
visual world it hasn't got anywhere
1179.02|5.43|close to wanting to engineer the
understanding of the visual world right
1184.45|5.94|now we're just talking about duplicating
the visual world so that's one important
1190.39|6.81|work to remember and of course after a
camera obscura that we we start to see
1197.2|7.5|a whole series of successful you know
some film gets developed um you know
1204.7|5.52|like kodak was one of the first
companies developing commercial cameras
1210.22|8.569|and then we start to have camcorders and
all this another very important
1218.789|6.451|important piece of work that i want you
to be aware of as vision student is
1225.24|5.799|actually not an engineering work but a
sign science piece of science work that
1231.039|6.331|starting to ask the question is how does
vision work in our biological brain no
1237.37|8.49|we we now know that it took 540 million
years of evolution to get a really
1245.86|7.98|fantastic visual system in mammals in
humans but what did evolution do during
1253.84|5.28|this time what kind of architecture did
it develop from that simple trilobite
1259.12|7.5|eye to today yours and mine well a very
important piece of work happened at
1266.62|6.029|harvard by 2:00 at that time young to
very young ambitious postdoc Cuba and
1272.649|9.361|visa what they did is that they used
awake but Anna sized cats and then there
1282.01|6.269|was enough technology to build this
little needle called electrode to push
1288.279|6.51|the electrode through into the the wall
that the skull is open into the brain of
1294.789|7.711|the cat into an area what we already
know primary visual cortex primary
1302.5|4.919|visual cortex is an area that neurons do
a lot of things for for visual
1307.419|5.37|processing but before you go visa we
don't really know what primary visual
1312.789|5.1|cortex is doing we just know it's one of
the earliest state other than your eyes
1317.889|6.931|of course but earliest stage for visual
processing and there's tons and tons of
1324.82|5.4|neurons working on vision and we really
ought to ought to know what this is
1330.22|2.62|because
that's the beginning of vision visual
1332.84|7.65|process in the brain so they they put
this electrode into the primary visual
1340.49|5.34|cortex and interestingly this is another
interesting fact if I don't drop all my
1345.83|5.36|stuff I'll show you
primary visual cortex the first stage or
1351.19|6.91|second dependent where he come from I'm
being very very rough rough here first
1358.1|5.28|state of your cortical visual processing
stage is in a back of your brain not
1363.38|6.59|near your eye okay it's very interesting
because your olfactory cortical
1369.97|5.95|processing is right behind your nose
your auditory is right behind your a
1375.92|7.95|year but your primary visual cortex is
the farthest from your eye and another
1383.87|4.98|very interesting fact in fact not only
the primary there's a huge area working
1388.85|7.32|on vision almost 50% of your brain is
involved in vision vision is the hardest
1396.17|5.37|and most important sensory perceptual
cognitive system in the brain you know
1401.54|6.03|I'm not saying anything else does it
it's not useful clearly but you know it
1407.57|6.15|takes nature this long to develop this
this sensory system and it takes later
1413.72|6.18|this much real estate space to be used
for this system why because it's so
1419.9|6.69|important and it's so damn hard that's
why we need to use this much place I'll
1426.59|4.92|get back to human reason they were
really ambitious they want to know what
1431.51|4.89|primary visual cortex is doing because
this is the beginning of our knowledge
1436.4|5.97|for deep learning your network ah so
they were showing cats so they put the
1442.37|4.559|cats in this room and they were
recording your activities and when I say
1446.929|4.141|recording your activity they're tall
they're basically trying to see you know
1451.07|6.09|if I put the the neural electrode here
like to the neurons to the neurons fire
1457.16|6.69|when they see something so for example
if they show ah if they show cat
1463.85|5.34|their ideas if I show this kind of fish
you know apparently at that time cats
1469.19|6.63|eat fish rather than these beings um
with the cats new are like yellow you're
1475.82|6.659|happy and start sending spikes and and
the funny thing here is a story of
1482.479|6.241|scientific discovery a scientific
discovery takes both luck and care and
1488.72|6.929|thoughtfulness they were shown as
catfish whatever Mouse flower it just
1495.649|5.49|doesn't work the catch neuron in the
primary visual cortex was silent there
1501.139|7.11|was no spiking are very little spiking
and they were really frustrated but the
1508.249|4.8|good news is that there was no computer
at that time so what they have to do
1513.049|6.141|when they show this cats these stimuli
is they have to use a slight projector
1519.19|6.28|so they put a put a slide of a fish and
then wait till the neuron spike if the
1525.47|4.62|neuron doesn't spike they take the slide
out and put in another slide and then
1530.09|6.659|they notice every time they change slide
like this dislike you know the squarish
1536.749|5.581|film I don't even remember if they use
glass or film but whatever the neural
1542.33|7.26|spikes that's weird you know like the
actual mouse and fish and flower didn't
1549.59|6.86|drive then you're excite the neuron but
the the movement of taking a slide out
1556.45|5.74|or putting a sliding dip excite the nor
I can be the cat is thinking or finally
1562.19|6.569|they're changing the new you know a new
object for me so it turned out there's
1568.759|6.6|an edge that's created by this slide
that they're changing right the slide
1575.359|8.971|whatever it's a square rectangular plate
and that moving edge drove or excited
1584.33|6.179|the neurons so they're really chased
after that observation you know if they
1590.509|5.191|were too frustrated or too careless they
would have missed that but they were not
1595.7|5.64|they really they chase
after that and realize neurons in the
1601.34|6.87|primary visual cortex are organized in
columns and for every column of the
1608.21|9.09|neurons they like to see a specific
orientation of the of the of a stimuli
1617.3|7.59|simple oriented bars rather than the
fish or Mouse you know I'm making this a
1624.89|3.06|little bit of a simple story because
there are still numerous in primary
1627.95|3.57|visual cortex we don't know what they
like they don't like simple oriented
1631.52|7.02|bars but by large we human visual found
that the beginning of visual processing
1638.54|7.44|is not a holistic fish or Mouse the
beginning of visual processing is simple
1645.98|9.44|structures of the world edges oriented
edges and this is a very deep deep
1655.54|6.19|implication to both neurophysiology and
neuroscience as well as engineering
1661.73|6.42|modeling it's if later when we visualize
our deep neural network features will
1668.15|7.74|see that simple simple of edge like
structure emerging from our from our
1675.89|7.67|model and even though the discovery was
in a later 50s and early 60s they won a
1683.56|8.46|Nobel a medical price for this work in
1981 so that was another very important
1692.02|8.89|piece of work related to vision and
visual processing and so when did
1700.91|4.98|computer vision begin that's another
interesting um that's another
1705.89|8.37|interesting story his history the
precursor of computer vision as a modern
1714.26|7.59|field was this particular dissertation
by Larry Roberts in 1963 it's called
1721.85|7.44|block world he just as Hubel and Visa
were discovering that the visual world
1729.29|6.119|in our brain is organized
by simple edge like structures Larry
1735.409|6.811|Roberts as an early piece Commerce
science PhD students were trying to
1742.22|8.64|extract these edge like structures in
images and and and and as a as a piece
1750.86|5.669|of engineering work and in this
particular case his goal is that you
1756.529|5.581|know bow you and I as humans can
recognize blocks no matter how it's
1762.11|5.85|turned right like we know it's the same
block these two are the same block even
1767.96|5.04|though the lighting changed and the
orientation changed and his conjuncture
1773.0|8.309|is that just like people told us it's
the edges that define is the structure
1781.309|6.271|the edges the edges define the shape and
they don't change rather than all these
1787.58|6.809|interior things so Larry Roberts wrote a
PhD dissertation to just extract these
1794.389|6.841|edges it's you know if you work as a PhD
student computer vision this is like you
1801.23|4.439|know this is like undergraduate computer
vision we don't have being a PhD thesis
1805.669|6.181|but that was the first precursor
computer vision PhD thesis on Larry
1811.85|6.03|Roberts is interesting he kind of gave
up he's he's a working computer vision
1817.88|6.99|afterwards and and went to DARPA and was
one of the inventors of the Internet so
1824.87|5.37|you know he didn't do too badly by
giving up computer vision but we always
1830.24|7.02|like to say that the birthday of
computer vision as a modern field is in
1837.26|9.36|the summer of 1966 the summer of 1966
MIT artificial intelligence lab was
1846.62|4.23|established before that actually for one
piece of history you should feel proud
1850.85|8.789|as a Stanford student this there are two
pioneering artificial intelligence lab
1859.639|5.461|established in the world in the early
1960s one by Marvin Minsky
1865.1|6.929|at MIT one by John McCarthy at Stanford
at Stanford the compel the artificial
1872.029|4.61|intelligence lab was established before
the computer science department and
1876.639|5.591|professor John McCarthy who founded AI
lab is the one who is responsible for
1882.23|4.799|the term artificial intelligence so
that's a little bit of a proud stanford
1887.029|4.681|history but anyway we have to give MIT
this credit for starting the field of
1891.71|8.91|computer vision because in the summer of
1966 a professor at MIT AI lab decided
1900.62|6.36|it's time to solve vision you know so AI
was established we start to understand
1906.98|5.159|you know first of all the logic and all
this and I think Lisp was probably
1912.139|5.91|invented at that time but anyway vision
is so easy you open your eyes you see
1918.049|3.51|the world how hard can this be let's
solve it in one summer
1921.559|9.0|so especially MIT students are smart
right so the summer vision project is an
1930.559|4.35|attempt to use our summer workers
effectively in a construction of a
1934.909|6.77|significant part of a visual system this
was the proposal for that summer and
1941.679|5.771|maybe they didn't use their summer work
effectively but in any case Kumbi
1947.45|5.16|computer vision was not solved in that
summer since then they become the
1952.61|6.21|fastest growing field of comparison and
AI if you go to today's premium computer
1958.82|10.199|vision conferences CS call cvpr or icc v
we have like 2,000 to 2,500 researchers
1969.019|8.13|worldwide attending this conference and
a very practical note for for students
1977.149|5.221|if you are a good computer vision slash
machine learning students you will not
1982.37|5.37|worry about jobs in Silicon Valley or
anywhere else so so it's it's actually
1987.74|6.299|one of the most exciting field but that
was the birthday of computer vision
1994.039|6.871|which means this year is the 50th
versary of computer vision that's a very
2000.91|6.96|exciting year in computer vision I we
have come a long long way
2007.87|5.07|okay so continue on the history of
computer vision this is a person to
2012.94|6.15|remember David Marr he he was also at
MIT at that time working with a number
2019.09|7.8|of a very influential computer vision
scientist Shimon Ullman Thomas Tommy
2026.89|8.79|Poggio and David Marr himself died early
in 70s and he wrote a very influential
2035.68|6.29|book called vision it's a very thin book
and David Marsh
2041.97|6.16|thinking about vision he took a lot of
insights from neuroscience we already
2048.13|6.63|said that Hubel and Wiesel give us the
concept of simple structure vision
2054.76|5.61|starts with simple structure it didn't
start with a holistic fish or holistic
2060.37|6.96|Mouse David Marr give us the next
important insight and these two insight
2067.33|6.18|together is the beginning of deep
learning architecture is that vision is
2073.51|6.81|hierarchical you know so human and Visa
said okay we start simple but human visa
2080.32|5.37|didn't say we're any simple this visual
world is extremely complex in fact I
2085.69|6.15|take a picture a regular picture today
with my iPhone there is I don't know my
2091.84|7.32|iPhone's resolution let's suppose it's
like 10 mega megapixels the potential
2099.16|6.3|combination of pixels to form a picture
in that is bigger than the total number
2105.46|5.94|of atoms in the universe that's how
complex vision can be is it's it's
2111.4|7.58|really really complex so human visit
oldest are simple David Marr told us
2118.98|6.1|build a hierarchical model of course
David mark didn't tell us to build it in
2125.08|3.6|a convolution on your network which we
will cover for the rest of the quarter
2128.68|5.629|but his idea is
is this to represent or to think about
2134.309|6.361|an image we think about it in several
layers the first one he thinks we should
2140.67|4.83|think about the edge image which is
clearly an inspiration
2145.5|5.67|it took the inspiration from human visa
and he personally call this the primal
2151.17|7.8|sketch it's you know the name is
self-explanatory and then you think
2158.97|7.2|about two and half D this is where you
start to reconcile your 2d image with a
2166.17|6.09|3d world you recognize there is layers
right on you know I look at you right
2172.26|3.059|now
I don't think half of you only has a
2175.319|5.46|head and a neck even though even though
that's all I see but there is I know
2180.779|5.04|you're included by the row in front of
you and this is the fundamental
2185.819|5.131|challenge of vision we have an ill-posed
problem to solve nature had a ill-posed
2190.95|7.49|problem to solve because the world is 3d
but the imagery on our retina is 2d
2198.44|6.7|Nature solved it by first a hardware
trick which is to ice it did I use one
2205.14|4.229|eye but then there's going to be a whole
bunch of software trick to merge the
2209.369|4.111|information of the two eyes and all this
so the same thing with computer vision
2213.48|5.76|we have to solve that two and half the
problem and then eventually we have to
2219.24|3.839|put everything together so that we
actually have a good 3d model of the
2223.079|5.661|world why do we have to have a 3d model
of the world because we have to survive
2228.74|6.64|navigate manipulate the world when I
shake your hand I really need to know
2235.38|4.949|how to you know extend out my hand and
grab your hand in the right way that is
2240.329|4.681|a 3d modeling of the world otherwise I
won't be able to grab your hand in the
2245.01|7.7|right way when I pick up a mug the same
thing so so that's a that's a that's
2252.71|6.97|David Marsh architecture for visual it's
a very high-level abstract architecture
2259.68|5.97|it doesn't really inform us exactly what
of mathematical modeling we should use
2265.65|5.459|it doesn't inform us of the learning
procedure and it really doesn't inform
2271.109|4.291|as of the the inference procedure which
we were getting to through the deep
2275.4|6.179|learning network architecture but that's
the that's the high-level view and it's
2281.579|6.661|an important it's an important concept
to learn in in vision and we call this
2288.24|7.17|the representation um a couple of really
important work and this is a little bit
2295.41|6.15|Stanford centric to just show you as
soon as David Marr are laid out this
2301.56|6.59|important way of thinking about vision
the first wave of visual recognition
2308.15|6.13|algorithms went after that 3d model
because that's the goal right like no
2314.28|6.48|matter how you represent the the stages
the goal here here is to reconstruct a
2320.76|5.19|3d model so that we can recognize object
and this is really sensible because
2325.95|6.6|that's what we go to the world and do so
both of these two influential work comes
2332.55|6.24|from Palo Alto one is from Stanford one
is from SR I so uh Tom Binford was a
2338.79|6.0|professor at Stanford AI lab and he had
his student Rodney Brooks proposed one
2344.79|4.44|one of the first so-called generalized
cylinder model I'm not going to get into
2349.23|7.25|the details but the idea is that the
world is composed of simple shapes like
2356.48|6.7|cylinders blocks and then any real-world
object is just a combination of these
2363.18|7.13|simple shapes given a particular viewing
angle and that was a very influential
2370.31|7.0|visual recognition model in the 70s and Romney Brook went on to become a
2377.31|8.25|director of MIT's AI lab and he was
also a founding member of the irobot
2385.56|4.35|company and
Roomba and all this so he continued very
2389.91|5.4|influential of AI work
another interesting model coming from
2395.31|7.62|local uh Stanford Research Institute I
think SR I is a across the street from
2402.93|8.16|El Camino is this pictorial structure
model is very similar it focused it has
2411.09|7.32|less of a 3d flavor but more of a
probabilistic flavor is that the objects
2418.41|7.17|are made of still simple parts like a
person's head is made of eyes and nose
2425.58|6.69|and mouth and the parts were connected
by Springs allowing for some deformation
2432.27|4.71|so this is getting a sense of okay we
recognize the world not every one of you
2436.98|4.89|have exactly the same eyes in the
distance between the eyes we allow for
2441.87|6.15|some kind of variability so this concept
of variability start to get introduced
2448.02|6.87|in a model like this and using models
like this you know the the reason I want
2454.89|6.45|to show you this is to see how simple
that the work was in 80s this is one of
2461.34|7.14|the most influential model in the 80s
are recognizing real world object and the
2468.48|6.75|entire paper of real world object is
these shaving razors and but using the
2475.23|8.34|edges and and simple shapes formed by
the edges to to recognize this by by
2483.57|7.14|develop another another Stanford
Graduate so that's that's a that's kind
2490.71|6.12|of the ancient world of computer vision
we have been seen black and white or
2496.83|6.29|even synthetic images starting the 90s
we finally start to move into like
2503.12|8.8|colorful images of real world it was a
big change again a very very influential
2511.92|4.73|work
here it's not particularly about
2516.65|5.269|recognizing an object is about how
only like carve out an image into
2521.919|7.44|sensible parts right so if you enter
this room there's no way your visual
2529.359|5.43|system is telling you oh my god I see so
many pixels right you immediately have
2534.789|7.38|group things you see heads heads heads
chair chair chair a stage platform piece
2542.169|5.07|of furniture and all this this is called
perceptual grouping perceptual grouping
2547.239|7.23|is one of the most important problem in
vision biological or artificial if we
2554.469|4.62|don't know how to how to solve the
perceptual grouping problem we're going
2559.089|6.541|to have a really hard time to deeply
understand the visual world and and you
2565.63|5.909|will learn towards the end of this this
class this course a problem is
2571.539|4.26|fundamental as this it's still not
solved in computer vision even though we
2575.799|4.65|have made a lot of progress before deep
learning and after deep learning we're
2580.449|6.35|still grasping the final solution of a
problem like this so so this is again
2586.799|5.92|why I want to give you this introduction
to for you to be aware of the deep
2592.719|6.84|problems in vision and also the the
current state in the the challenges in
2599.559|4.77|vision we did not solve all the problem
in vision despite whatever the news says
2604.329|6.69|you know like we're far from developing
terminators who can do everything yet so
2611.019|7.04|this piece of work is called normalized
cut is one of the first computer vision
2618.059|6.1|work that takes real-world images and
tries to solve a very fundamental
2624.159|7.08|difficult problem and titania Malick is
a senior computer vision researcher
2631.239|5.94|now professor at Berkeley also Stanford
Graduate and you can see the results are
2637.179|5.13|not that great um are we going to cover
any segmentation in this class for me
2642.309|5.49|when we might right you see we are
making progress but this is the
2647.799|5.881|beginning of that another very
influential work that I want to
2653.68|6.78|I want to bring out and pay tribute so
for even though these work were not
2660.46|4.95|covering them in the rest of the course
but I think it as a vision student it's
2665.41|4.23|really important for you to be aware of
this because not only introduces the
2669.64|4.53|important problem we want to solve it
also gives you a perspective on the
2674.17|6.03|development of the field this work is
called village owns face detector and
2680.2|5.76|it's very dear to my heart because as a
graduate student fresh graduate student
2685.96|5.639|at Cal Tech it's the full of the first
papers I read as a graduate student when
2691.599|4.47|I enter the lab and I didn't know
anything that my advisor said read this
2696.069|5.161|amazing piece of work that you know
we're all trying to understand and then
2701.23|6.839|P by the time I graduated from Cal Tech
this very work is transferred to the
2708.069|8.161|first smart digital camera by Fujifilm
in 2006 as the first digital camera that
2716.23|5.04|has a face detector so from a transfer
point point a technology transfer point
2721.27|6.63|of view it was extremely fast and it was
one of the first successful high-level
2727.9|6.929|visual recognition algorithm that's
being used by consumer product so this
2734.829|6.121|work just learns to detect faces and
faces in a wild it's no longer you know
2740.95|5.839|simulation data or very contrived data
these are any pictures and and again
2746.789|5.56|even though it didn't use a deep
Learning Network it has a lot of the
2752.349|6.51|deep learning flavor the features were
learned you know the algorithm learns to
2758.859|6.391|find features simple features like these
black and white filter features that can
2765.25|7.559|give us the best localization of faces
so this is a very influential piece of
2772.809|9.74|work it's also one of the first computer
vision work that is deployed on a a
2782.549|4.671|computer and can run real time before
that compare vision
2787.22|4.95|algorithms were very slow the paper
actually is called real-time face
2792.17|5.13|detection it was granted
Pentium 2 chips I don't know if anybody
2797.3|5.13|remember that kind of chip but it was on
a slow chip but nevertheless it run real
2802.43|6.63|time so that was another very important
bit of work and also one more thing to
2809.06|6.3|point out around this time this is not
the only work but this is a really good
2815.36|6.71|representation around this time computer
the focus of computer vision is shifting
2822.07|9.1|remember that David Marr and the early
Stanford work was trying to model the 3d
2831.17|9.09|shape of the object now we're shifting
to recognizing what the object is we
2840.26|5.82|lost a little bit about can we really
reconstruct these faces or not there is
2846.08|3.66|a whole branch of computer vision
graphics that continue to work on that
2849.74|6.66|but a big part of computer vision is not
at this time around the turn of the
2856.4|5.94|century is focusing on recognition
that's bringing computer vision back to
2862.34|9.09|AI and today the most important part of
the computer vision work is focused on
2871.43|7.53|these cognitive questions like
recognition and AI questions um another
2878.96|7.62|very important piece of work is starting
to focus on features so around the time
2886.58|6.69|of face recognition people start to
realize it's really really hard to
2893.27|6.15|recognize an object by describing the
whole thing like I just said you know I
2899.42|5.25|see you guys
heavily included I don't see the rest of
2904.67|5.22|your torso I really don't see any of
your legs other than the first row but I
2909.89|8.43|recognize you and I can infer you as an
object so so people start to realize gee
2918.32|4.929|it's not necessarily that global
shape that we have to go after in order
2923.249|4.891|to recognize an object maybe it's the
features if we recognize the important
2928.14|5.07|features on an object we can go a long
way and it makes a lot of sense think
2933.21|4.799|about evolution right if you're out
hunting you don't need to recognize that
2938.009|5.671|Tigers full body and shape to decide you
need to run away you know just a few
2943.68|5.569|patches of the fur of the tiger through
the leaves probably can alarm you enough
2949.249|5.951|so so we need to vision as quick
decision-making based on vision is
2955.2|5.819|really quick a lot of this happens on
important features so this work cost
2961.019|6.5|sift by devil Oh again you saw that name
again is about learning important
2967.519|5.951|important features on an object and once
you learn these important features just
2973.47|4.44|a few of them on an object you can
actually recognize this object in a
2977.91|7.589|totally different angle on a totally
cluttered scene so up to deep learnings
2985.499|9.391|resurrection in that 2010 or 2012 for
about 10 years the entire field of
2994.89|5.34|computer vision was focusing on using
these features to build models to
3000.23|5.299|recognize objects and things and we've
done a great job we've gone a long way
3005.529|7.09|one of the reasons deep learning network
uh was became more more convincing to a
3012.619|5.341|lot of people is we will see that the
features that a deep learning network
3017.96|5.659|learns is very similar to these
engineered features by brilliant
3023.619|6.341|engineers so it's kind of confirmed even
though you know in needed we need a
3029.96|4.92|develope to first tell us this features
work and then we start to develop better
3034.88|3.959|mathematical models to learn these
features by itself but they confirmed
3038.839|7.351|each other so so the historical you know
importance of this work should not be
3046.19|3.48|diminished
they this work is the intellectual
3049.67|3.89|foundation for us one of the
intellectual foundation for us
3053.56|5.91|to realize that how critical or how
useful these deep learning features are
3059.47|7.59|when we learn them uh I'm going to skip
this work and just briefly say because
3067.06|4.71|of the features that they will owe and
meaning other researchers taught us we
3071.77|5.79|can use that to to learn that Scene
Recognition and around that time the
3077.56|6.09|machine learning tools we use mostly is
either graphical models or support
3083.65|4.98|vector machine and this is one
influential work on using support vector
3088.63|8.33|machine and kernel models to recognize
the sink but I'll I'll be brief here and
3096.96|9.1|then one almost one last model before
deep learning model is this feature or
3106.06|6.45|feature based model called deformable
part model is where we learn parts of an
3112.51|6.39|object like parts of a person and we
learn how to configure each other well
3118.9|7.94|they come they configure in space and
use a support vector machine kind of
3126.84|9.19|model to recognize objects like humans
and bottles around this time that's 2009
3136.03|5.25|2010 the field of computer vision is
matured enough that we're working on
3141.28|5.67|these important and hard problem like
recognizing pedestrians and recognizing
3146.95|4.83|cars they're no longer contrived problem
something else was needed its
3151.78|6.3|benchmarking because as a field advanced
enough if we don't have good benchmark
3158.08|4.5|then everybody's just published in
papers on a few set of images and it's
3162.58|5.61|really hard to really set global
standard so one of the most important
3168.19|7.08|benchmark is called Pascal vo C object
recognition benchmark it's by a European
3175.27|6.36|it's a European effort that researchers
put together at tens of thousands of
3181.63|4.969|images from 20 classes of objects and
these are
3186.599|8.45|one example per per object like Cat
Scouts cows maybe no cats dogs cows
3195.049|9.04|airplanes bottles you know horses trains
and all this and then we used and then
3204.089|6.75|annually our computer vision researchers
and labs come to compete on the object
3210.839|6.66|recognition task for a Pascal object
recognition challenge and in over the
3217.499|5.941|past you know like through the years the
the performance just keeps increasing
3223.44|7.2|and that was when we start to feel
excited about the progress of the field
3230.64|8.429|at that time here's a little bit of more
a closer story close to us is that my
3239.069|4.321|lab and my students were thinking you
know the real world is not about twenty
3243.39|6.179|objects the with real world is a little
more than twenty objects so following
3249.569|6.03|the work of Pascal visual object
recognition challenge we put together
3255.599|5.43|this massive massive project or imagenet
some of you might have heard of image
3261.029|6.901|net in this class you will be using a
tiny portion of image that in some of
3267.93|6.21|your assignments that image that is a
data set of 50 million images all
3274.14|9.329|clinged by hands and annotated over
20,000 object classes door it's not
3283.469|5.55|graduate student who cleaned it it's
that that would be very scary it's
3289.019|5.52|Amazon Mechanical Turk platform the
crowdsourcing platform and having said
3294.539|5.04|that graduate student also suffered for
from you know putting together this this
3299.579|7.891|platform but it's a very exciting data
set and we started we started to put
3307.47|6.869|together competitions annually called
image that competition for object
3314.339|6.871|recognition and for example a standard
competition of image classification by
3321.21|5.69|image that is a thousand object classes
over almost 1.5 million images and
3326.9|6.25|algorithms compete on the performance so
actually I just heard somebody was on
3333.15|3.81|the social media was referring image
that challenge as the Olympics of
3336.96|7.44|computer vision I was very flattering
but um but here is something that here's
3344.4|9.149|bringing as close to the history making
of deep learning so in in a so the image
3353.549|5.49|step challenge started in 2010 that's
actually around the time Pascal you know
3359.039|3.871|we're colleagues they told us they're
going to start to phase out their
3362.91|5.129|challenge of twenty objects so we faced
in the thousand object image the
3368.039|7.01|challenge and y-axis is error rate and
we start to we started with very
3375.049|8.74|significant error and of course you know
every year the error decreased but
3383.789|5.76|there's a particular year that error
really decreased it was cutting half or
3389.549|10.53|almost is 2012 2012 is the year that the
winning architecture of image that
3400.079|6.121|challenge was a convolutional neural
network model and we'll talk about it
3406.2|5.879|convolutional neural network was not
invented in 2012 despite how all the
3412.079|4.92|news make it sound like it's the newest
thing around the block it's not it was
3416.999|6.141|invented back in the 70s or 80s
but having a convergence of things we'll
3423.14|5.25|talk about convolutional neural network
showed its massive power as a high
3428.39|5.909|capacity end to end training
architecture and won the image they're
3434.299|6.51|challenged by a huge margin and that was
you know a quite a historical moment
3440.809|4.98|from a math mathematical point of view
nothing it wasn't that new but from an
3445.789|5.37|engineering and an solving real-world
point of view this was a historical
3451.159|4.5|moment that that piece of work was
covered by you know New York Times and
3455.659|6.96|all this this is the onset this is the
beginning of the deep learning
3462.619|5.521|revolution if you call it
and this is the premise of this class so
3468.14|5.759|at this point I'm gonna switch so we
went through a bit of brief history of
3473.899|7.14|computer vision for 540 million years
and now I'm going to switch to the
3481.039|8.55|overview of this class is there any
other questions ok all right so um we've
3489.589|5.34|talked about even though it was kind of
overwhelming we talked a lot about many
3494.929|6.39|different tasks in computer vision CS
231 n is going to focus on the visual
3501.319|6.54|recognition problem also by enlarge
especially through most of the
3507.859|4.23|foundation lecture we're going to talk
about the image classification problem
3512.089|4.59|but now you know everything we talked
about is going to be based on that image
3516.679|5.93|that classification setup we will we
were getting to other visual recognition
3522.609|6.19|scenarios but the image classification
problem is the main problem we will
3528.799|4.44|focus on in this class which means
please keep in mind visual recognition
3533.239|4.29|is not just the image classification
right there was 3d modeling there was
3537.529|4.5|perceptual grouping and segmentation and
all this but that's that's what we'll
3542.029|5.19|focus on and I don't need to convince
you that just even application wise
3547.219|5.171|image classification is extremely useful
problem in
3552.39|6.03|you know big big commercial internet
companies a point of view to start up
3558.42|4.56|ideas you know you want to recognize
objects you want to recognize food you
3562.98|6.059|want to do online shop mobile shopping
you want to sort your albums so image
3569.039|6.601|classification is is is can be a bread
and butter a task for many many
3575.64|7.919|important problems um there is a lot of
problem that's related to image
3583.559|4.95|classification and today I don't expect
you to understand the differences but I
3588.509|5.52|want you to hear that throughout this
class we'll make sure you learn to
3594.029|5.881|understand the neurons in the the
details of different flavours of visual
3599.91|4.5|recognition what is image classification
what's object detection
3604.41|6.74|what's image captioning and these have
different flavors for example you know
3611.15|6.82|while image classification my focus on
the whole big image object detection by
3617.97|5.73|tell you where things exactly are like
where the car is the pedestrian or the
3623.7|6.389|hammer and and where the the
relationship between objects and so on
3630.089|5.01|so there are nuances and and details
that you will be learning about in this
3635.099|7.98|class and I already said CNN or
convolutional neural network is one type
3643.079|6.51|of deep learning architecture but it's
the overwhelmingly successful deep
3649.589|3.811|learning architecture and this is the
architecture we will be focusing on and
3653.4|6.629|to just go back to the image that
challenge ah so I said the historical
3660.029|7.5|year is 2012 this is the year that Alex
Khrushchev ski and his advisor geoff
3667.529|6.931|hinton proposed this this convolutional
neural network I think it's a seven
3674.46|5.369|layer convolutional neural network to
win the image that challenge model
3679.829|6.171|before this year it was a shift feature
plus
3686.0|6.0|a support vector machine architecture
it's still hierarchical but it doesn't
3692.0|7.74|have that flavor of end to end learning
and fast forward to 2015 the winning
3699.74|5.34|architecture is still a convolutional
neural network it's a hundred fifty one
3705.08|12.0|layers by by Microsoft Asia research
researchers and it's covering the
3717.08|5.34|residual net right is that could the
residual net so I'm not so sure if we're
3722.42|4.71|going to cover that definitely don't
expect to know every single layer what
3727.13|7.83|they do actually they repeat so it's not
that hard but but but every year since
3734.96|5.72|2012 the winning architecture of image
net challenge is a deep learning based
3740.68|7.2|architecture so like I said I also want
you to respect history um
3747.88|8.47|CNN is not invented overnight there is a
lot of influential players today but you
3756.35|3.45|know there are a lot of people who build
the foundation I actually I don't have
3759.8|4.8|the slides one important name to
remember is kunihiko fukushima kunihiko
3764.6|7.47|fukushima it was a Japanese computer
scientist who build a model Konya
3772.07|7.94|cognitum and that was the beginning of
the the neural network architecture and
3780.01|6.1|yellow kun is also a very influential
person and he's really his the the
3786.11|5.85|groundbreaking work in my opinion of
young ku was published in the 1990s so
3791.96|6.54|that's when mathematicians and which
geoff hinton Yellen Cruz PhD advisor was
3798.5|6.54|involved worked out the back propagation
learning strategy which if this work
3805.04|3.18|didn't mean anything
Andrei will tell you in a couple of
3808.22|6.45|weeks so but but the the mathematical
model was worked out in the 80s and the
3814.67|4.53|90s and this was a yellow Coon was
working for Bell
3819.2|5.82|laughs at AT&T which is a amazing place
at that time there's no Bell Labs today
3825.02|3.0|anymore
that they were working on really
3828.02|4.47|ambitious projects and he needed to
recognize digits because eventually that
3832.49|6.3|product was shipped to banks in the u.s.
post office to recognize zip codes and
3838.79|6.21|checks and he constructed this
convolutional neural network and this is
3845.0|5.4|where he he's inspired by Hubel and
Wiesel he starts by looking as simple
3850.4|6.03|edge like structures of an image it's
not like the whole letter a it's really
3856.43|6.21|nice just edges and then layer by layer
he he you know he filters these edges
3862.64|6.959|pull them together filters pool and then
the build this architecture 2012 when
3869.599|6.531|Alex Khrushchev ski and geoff hinton
used almost exactly the same
3876.13|8.41|architecture to participate in a in the
in the image net challenge almost there's
3884.54|6.63|very few changes but that become the
winning architecture of this so what I
3891.17|5.159|will tell you more about the detail
changes there is the capacity that the
3896.329|6.361|model did grow a little bit because
Moore's Law helped us there's also a
3902.69|5.58|very a very detailed function that
changed a little bit of a shape from a
3908.27|6.569|sigmoid row to a more rectified linear
shape but whatever there's a couple of
3914.839|6.451|small changes but really by enlarge
nothing had changed mathematically but
3921.29|5.63|two important things did change and that
Grove the deep learning architecture
3926.92|9.419|back into into its Renaissance one is
like I said Moore's law and hardware
3936.339|5.441|hardware made a huge difference because
these are high extremely high capacity
3941.78|6.03|models when Gallagher was doing this
it's just painfully slow because of the
3947.81|4.71|the bottleneck of computation he
couldn't build this model too big
3952.52|4.17|at once you cannot build it too big it
cannot fully realize its potential you
3956.69|4.11|know the from machine learning
standpoint there's overfitting and all
3960.8|6.11|these problems you cannot solve but now
we have a much faster and bigger
3966.91|7.3|transistor not transistors bigger
capacity microchips and GPUs from Nvidia
3974.21|5.88|Nvidia made a huge difference in deep
learning history that we can now train
3980.09|5.07|these models in a reasonable amount of
time even if they're huge another thing
3985.16|6.21|I think we do need to take credit for is
data the availability of data that was
3991.37|8.04|the big data data itself is just you
know it doesn't mean anything if you
3999.41|4.62|don't know how to use it but in this
deep learning architecture data become
4004.03|4.62|the driving force for a high capacity
model to enable the end-to-end training
4008.65|6.96|and to help avoid overfitting when you
have enough data so you know so you if
4015.61|5.88|you look at the number of pixels that
machine learning people had in 2012
4021.49|8.1|versus yellow ku had in 1998 it's a huge
difference orders of magnitude so so
4029.59|7.89|that was that's so this is the focus of
231 n but we'll also go
4037.48|4.89|it's also important one last time I'm
gonna drilling this idea that visual
4042.37|4.77|intelligence does go beyond object
recognition I don't want any of you
4047.14|4.08|coming out of this course thinking we've
done everything you know we've saw
4051.22|6.54|vision and if it's the challenge defined
the entire space of visual recognition
4057.76|5.43|it's not true there are still a lot of
cool problems to solve for example you
4063.19|6.42|know dense labeling of an entire scene
with perceptual groupings I know where
4069.61|7.52|every single pixel belong to that's
still an ongoing problem combining
4077.13|5.76|recognition with 3d is a really there's
a lot of excitement happening at the
4082.89|6.13|intersection of vision and robotics and
this is this is definitely one area of
4089.02|6.18|that and then anything to do with motion
affordance and and and this is another
4095.2|9.059|big open area of research there is a I
put this here because Justin is heavily
4104.259|7.951|involved in this in this work you know
beyond just putting labels on a sink you
4112.21|4.89|actually want to deeply understand a
picture what people are doing what are
4117.1|5.159|the relationship between objects and we
start getting into the the relation
4122.259|4.681|between objects and this is the ongoing
project called visual genome in my lab
4126.94|5.79|that justin and a number of my students
are involved and this goes far beyond
4132.73|8.489|image classification we we talked about
and what is one of our Holy Grails well
4141.219|4.02|one of the Holy Grails of computer
vision is to be able to tell a story of
4145.239|6.661|a scene right so think about you as a
human you open your eyes the moment you
4151.9|7.189|open your eyes you're able to describe
what you see and in fact in psychology
4159.089|7.061|experiments we find that even if you
show people this picture for only 500
4166.15|6.45|milliseconds that's literally half of a
second people can write essays about it
4172.6|6.659|we pay them $10 an hour so they did
every it wasn't that long but you know I
4179.259|4.051|figure if we took a little longer a
little more money they'd probably write
4183.31|7.17|longer essays but the point is that our
visual system is extremely powerful we
4190.48|4.56|can tell stories and I would dream this
is my challenge to undress a
4195.04|8.61|dissertation that can we give you give a
computer one picture and outcomes a
4203.65|5.13|description like this you know and we're
getting there you'll see work that you
4208.78|4.609|give the computer one picture it gives
you one sentence or you give the little
4213.389|4.691|computer one picture it gives you a
bunch of short sentences but we're not
4218.08|3.54|here yet but
that's one of the Holy Grail and another
4221.62|5.91|Holy Grail is continuing this continuing
this Atlas I think is summarized really
4227.53|5.7|well by Audrey's blog is you know take a
picture like this right
4233.23|6.6|there's the stories are so refined
there's so much nuance in this picture
4239.83|4.889|that you get to enjoy not only you
recognize the global sea it would be
4244.719|5.911|very boring if all computer can tell you
is man man man room
4250.63|6.51|you know room scale mirror whatever
cabinet Locker that's it you know here
4257.14|5.13|you recognize who they are you recognize
the trick Obama is doing you recognize
4262.27|5.429|the kind of interaction you recognize
the humor you recognize there's just so
4267.699|5.601|much nuance that this is what visual
world is about we use our ability to of
4273.3|6.73|visual understanding to not only survive
navigate manipulate but we use it to
4280.03|7.169|socialise to entertain to understand to
learn the world and this is where vision
4287.199|7.261|you know the grand goals of vision is so
and and I don't need to convince you
4294.46|5.91|that computer vision technology will
make our world a better place
4300.37|7.92|despite some scary talks out there you
know even going on today in industry as
4308.29|4.07|well as research world we're using
computer vision to build better robots
4312.36|8.17|to save lives to go deep exploring and
all this now ok so I have like what two
4320.53|6.169|minutes three minutes five minutes left
great time let me introduce the team and
4326.699|6.73|Andre and Justin are the co instructors
with me TAS please stand up when to say
4333.429|7.441|hi to everybody can you like to say your
name quickly and you're like what year
4340.92|7.45|and just don't give a speech but yeah
start start with you your name
4348.37|28.73|what so so these are the heroes behind
the thing and so please stay in touch
4377.11|5.15|with us there two really the best way
and almost I almost wanted to say the
4382.27|4.11|only way and I'll tell you what's the
exception is stay in touch through
4386.38|6.69|Piazza as well as the staff meeting list
anything course related please please do
4393.07|4.71|not send any of us personal email
because I'm just gonna say this
4397.78|5.28|if you don't hear replies or your issue
is not taken care of because you send a
4403.06|4.95|personal email I'm really sorry because
this is a 300 plus people class hour
4408.01|6.03|this mailing list actually tags our
email and and and and help us to process
4414.04|6.99|the only time I respect you to send a
personal email mostly to me and Andre
4421.03|5.31|and Justin is confidential personal
issues you know and I understand if you
4426.34|5.22|don't want that to be broadcasted to a
team of 10 TAS that's okay
4431.56|7.23|but that should be really really minimal
at the only time that you send us an
4438.79|6.179|email and also you know just again I'm
going on my turn to leave for a few
4444.969|5.161|weeks starting the end of January so so
please if you decide you just want to
4450.13|5.46|send an email to me and it's my like
due day for her baby
4455.59|6.41|I'm not likely going to reply you
promptly sorry about that
4462.84|10.03|priorities so a couple words about our
philosophy out this is we're not going
4472.87|4.38|to get into the details we really want
this to be a very hands-on project and
4477.25|5.22|this is really I give a lot of credit to
Justin and Andre they are extremely good
4482.47|7.23|at walking through these hands-on
details with you so that when you come
4489.7|3.99|out of this class you not only have a
high level understanding but you have a
4493.69|5.25|thorough you have a really good ability
to to build your own deep learning code
4498.94|4.56|we want you to be exposed to
state-of-the-art material you're going
4503.5|5.91|to be learning things really that's as
fresh as 2015 and it'll be fun
4509.41|5.88|you get to do things like this now not
all the time but you know like turn a
4515.29|8.07|picture into Van Gogh or or this weird
and kin thing so it will be a fun class
4523.36|6.18|in addition to all the important tasks
you are you you learn uh we do have
4529.54|4.83|grading policies these are all on our
website I'm not going to eat to rate
4534.37|6.09|this again one thing I want to be very
clear I'm actually two things what is
4540.46|6.66|late policy you are grownups we treat
you like grown-ups we do not take
4547.12|5.49|anything at the end of the courses who
my professors want me to go to this
4552.61|5.37|conference and I have to have like three
more late days no you are responsible
4557.98|5.97|for using your total late days you have
seven late days you can use them in
4563.95|7.2|whatever way you want with zero penalty
beyond those you have to take a penalty
4571.15|6.63|again if there's like really really
exceptional medical family emergency
4577.78|5.88|talk to us on an individual basis but
anything else conference deadlines other
4583.66|4.22|final exams
you know like missing cat
4587.88|6.69|or whatever is we we we budgeted that
into the seven days
4594.57|4.98|another thing is honor code this is one
thing I have to say with a really
4599.55|6.649|straight face you are enough such a
privileged institution you're you are
4606.199|4.361|grownups
I want you to be responsible for honor
4610.56|4.56|code every single Stanford student
taking this class should know the honor
4615.12|3.03|code if you don't there's no excuse you
should go back
4618.15|5.64|we take collaboration extremely
seriously I almost hate to say that's
4623.79|5.25|statistically given a class this big
we're going to have a few cases but I
4629.04|5.34|also want you to be an exceptional class
even with the size this big we do not
4634.38|5.91|want to see anything that infringes on
academic honor code so read the
4640.29|5.52|collaboration policies and respect that
this this is really respecting yourself
4645.81|8.61|ah I think I'm done with you know these
pre-requisite you can you can read it I'm done
4654.42|5.73|with anything I want to say is there any
burning questions that you feel it's
4660.15|11.009|worth asking yes a good question Andre
do you have
4671.159|7.79|midterm move a bit of everything which
means they haven't figured it out
4682.889|4.57|yeah we will give you sample meters okay
all right
4687.459|3.2|thank you welcome to the class
4696.729|2.631|the water's going