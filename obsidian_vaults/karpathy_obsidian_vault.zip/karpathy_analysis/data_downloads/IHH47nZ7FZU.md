start_time|end_time|text
0.03|3.33|we rely primarily on vision so we do
2.1|2.759|have instead is we have eight cameras
3.36|3.33|that are pointed in the 360 around the
4.859|3.421|car and we obtain video streams from all
6.69|3.27|those cameras and we parse them using
8.28|4.109|neural networks and we stitched it up
9.96|5.339|into a view of what's around us in three
12.389|4.741|dimensions in 360 so this is kind of
15.299|3.48|more of what we see what the car seats
17.13|3.09|at every single frame and we're trying
18.779|2.58|to stitch it up so I'm now going to go
20.22|2.91|into the computer vision problem and
21.359|5.16|what's kind of necessary to cut this to
23.13|4.889|work now we're in a multi task workshop
26.519|3.33|so first I will talk about just a single
28.019|3.51|task and make the point that even for
29.849|3.691|one task this can actually be very
31.529|6.151|difficult problem if you want this to
33.54|5.339|work all the time so 97% accuracy is not
37.68|4.68|good enough you actually really need
38.879|5.52|high 99.9 percent accuracy for this to
42.36|4.469|be a shil to be actually safe to deploy
44.399|3.721|so as an example even the basic visual
46.829|2.91|recognition tasks like object detection
48.12|3.93|we're putting bounding boxes around cars
49.739|3.84|this is very difficult if you actually
52.05|3.21|want to ship this and make it safe
53.579|4.441|because cars don't just look like that
55.26|5.22|they actually have a massive variety to
58.02|5.82|them as there are cars with science cars
60.48|5.69|that look odd cars on cars bikes on cars
63.84|6.0|cement trucks cars with Falcon wings
66.17|6.04|boats and other objects a cars that take
69.84|4.529|up the entire a field of the view of the
72.21|3.799|camera and so even your basic abundant
74.369|5.551|box abstraction actually just breaks
76.009|5.891|cars with appendages and excavators cars
79.92|4.79|upside down cars with trailers trailers
81.9|5.399|and then of course heavily occluded cars
84.71|4.479|so for example in parking lots you you
87.299|3.811|just a very heavy occlusions it's very
89.189|4.021|difficult to deal with front with a very
91.11|3.719|naive approach to object detection so
93.21|3.42|even in the process of getting a single
94.829|3.511|task to work there's a ton that goes
96.63|3.21|into what is the architecture we're
98.34|2.88|already printing or dilations are using
99.84|2.849|a ResNet or dense net or what is the
101.22|3.12|architecture look like what does your
102.689|3.241|last function look like what object
104.34|3.0|detection and technique are using but
105.93|3.6|also not just for the model but the data
107.34|3.51|set itself we have to iterate on the
109.53|2.76|data set and we do that in an iterative
110.85|4.44|fashion and something that I call the
112.29|4.5|data engine so you which is a process by
115.29|3.3|which you iteratively build your data
116.79|4.109|set so you have a network that you've
118.59|4.529|trained on some data set v-0 and then
120.899|4.051|you train your network deploy it and you
123.119|3.121|have mechanisms by which she noticed
124.95|3.539|that the network is misbehaving or
126.24|4.139|previous inaccuracies and you sort
128.489|3.121|source those examples annotate them
130.379|2.701|correctly and incorporate them in the
131.61|2.22|training set and you spin this data
133.08|2.31|engine loop over
133.83|3.57|to actually get this task to work really
135.39|4.65|well and we don't just do this for one
137.4|4.86|task we do this for many tasks so let me
140.04|4.92|try to go into how this gets very crazy
142.26|4.05|very fast and the core issue is that you
144.96|2.31|there's actually like a ton of things
146.31|4.08|you might want to know about the
147.27|4.86|environment if you're trying to drive so
150.39|3.45|as an example in this random image of
152.13|3.06|the residential neighborhood you don't
153.84|2.79|just want to know about the cars but
155.19|2.76|there's of course a ton of things you
156.63|2.58|want to know you want to know about the
157.95|2.73|static objects not just in moving
159.21|3.03|objects you want to know about the road
160.68|2.67|size and what they're telling you you
162.24|2.55|want to know about the overhead signs
163.35|2.58|next to the traffic lights and they tell
164.79|2.79|you about whether or not you can do you
165.93|2.58|turn or anything like that you want to
167.58|2.1|know about the traffic lights in all
168.51|3.0|their state and you have to handle all
169.68|4.32|the variety of those traffic lights the
171.51|4.44|lane lines which at the flow of traffic
174.0|5.07|the road markings that tell you what you
175.95|4.59|can and can't do in any lane the curbs
179.07|3.3|that tell you about where you may or may
180.54|4.2|not want to move if you want to not
182.37|3.93|damage your vehicle the crosswalks that
184.74|3.45|hint at the behavior of pedestrians in
186.3|3.78|the vicinity and lots of environment
188.19|3.6|tags as an example like is it are you in
190.08|3.21|a residential neighborhood are you in a
191.79|3.96|tunnel are you coming up to a tollbooth
193.29|3.75|all those predictions are also kind of
195.75|2.37|binary classification problems for
197.04|2.729|example that we solve for every single
198.12|3.0|image there are a ton of things you
199.769|2.821|might want to know it about every single
201.12|2.88|scenes it is not an exhaustive list it's
202.59|3.48|also a bit of a cartoon these are not
204.0|4.019|exactly our tasks but it just gives you
206.07|3.54|a sense of there's there's about 50
208.019|4.561|volts or so tasks that we simultaneously
209.61|4.92|work on in the team and even though I've
212.58|3.72|put only a single task here says moving
214.53|3.51|objects there's actually lots of sub
216.3|4.05|tasks for moving objects because I want
218.04|3.84|to know a ton about all those objects is
220.35|3.359|it a pedestrian or bicyclists are more
221.88|3.66|cyclists at the cup truck is it a truck
223.709|3.841|is it a bus all those things have
225.54|3.63|repercussions on your driving policy and
227.55|4.439|your expectations about how these things
229.17|4.74|by move is this able is an ambulance a
231.989|2.731|firetruck is it a police car are there
233.91|2.609|sirens on
234.72|3.69|is it a construction vehicle is the left
236.519|5.101|blinker on right blinker on are the rear
238.41|5.4|lights on is the car cutting in it
241.62|3.69|doesn't look like it's parked all those
243.81|2.459|things are subtasks that you might want
245.31|2.49|to know all of these are independent
246.269|3.331|predictions that you must predict on
247.8|4.26|every single car all of them have their
249.6|5.88|own data engine and so the scope of this
252.06|6.06|problem very quickly just becomes quite
255.48|4.499|quite daunting so that's kind of what
258.12|3.989|we're faced with we make about 20 or 30
259.979|4.261|tasks and every one of those has sub
262.109|3.841|tasks so you end up with basically 100
264.24|3.18|sub tasks that we all have to solve
265.95|3.68|simultaneously enough to make work
267.42|4.35|really well to very high accuracy
269.63|3.76|requirements before we can actually
271.77|3.42|deploy it so I'll talk a little bit
273.39|2.7|about some of the struggles and some of
275.19|2.79|the way that we're approaching these
276.09|4.02|problems so from the architectural
277.98|3.63|standpoint first obviously we are
280.11|3.09|putting in some image and we'd like to
281.61|3.03|understand a lot of things about it but
283.2|3.12|there are there's a large design space
284.64|3.75|as to what goes into the black box that
286.32|3.57|makes this network so at one end of the
288.39|2.88|spectrum you might imagine that every
289.89|3.45|single task for example could get its
291.27|3.24|own network an independent network and
293.34|2.79|all these different choices
294.51|3.42|architectural will have their own pros
296.13|3.21|of pros and cons so in this case for
297.93|3.99|example if you separate out every single
299.34|4.2|task to its own network then some of the
301.92|2.91|downsides are that as an example this
303.54|3.12|will be very expensive at test time
304.83|3.51|we've refined that compute budget on the
306.66|3.42|car we want to run this at high frame
308.34|3.51|rates to ensure safety and so of course
310.08|3.77|you might not have the computational
311.85|4.38|budget to actually run 30 different
313.85|4.83|tasks 30 different comments that every
316.23|4.74|single frame for every single camera
318.68|3.88|moreover there's no feature sharing and
320.97|3.24|it's kind of a setup and so if your task
322.56|2.85|one of the tasks as an example might not
324.21|3.6|have enough data then you're going to
325.41|3.63|actually over fit and but what is nice
327.81|2.94|about this and I'm going to go a little
329.04|3.18|bit more into the team workflow of how
330.75|4.92|you actually develop these networks is
332.22|5.13|that the decouples functionality so if
335.67|3.51|you only want to improve on moving
337.35|2.91|objects as an example then you retrain
339.18|2.31|your network of moving objects and
340.26|2.67|someone can iterate on that and try out
341.49|3.12|a different detector since like that and
342.93|3.72|you know that you're not changing or
344.61|3.36|regressing some of the other tasks so
346.65|3.0|you can sort of iterate on one thing
347.97|2.97|holding everything else constant and you
349.65|4.56|don't have to re-evaluate the entire
350.94|4.83|system as much on the other end of the
354.21|3.54|extreme we could try to have all of
355.77|3.36|these tasks be separate heads very
357.75|3.45|lightweight heads on top of a single
359.13|3.87|shared backbone so this is kind of on
361.2|3.15|the other end of a stream in this case
363.0|2.64|this would be significantly cheaper at
364.35|2.52|test time because this backbone is
365.64|4.35|basically multitasking and all those
366.87|4.95|things but there are some downsides so
369.99|4.37|as an example all these tasks will now
371.82|4.41|write for the same shared capacity
374.36|2.77|sometimes they fight sometimes they
376.23|2.34|actually help each other there's
377.13|4.29|complicated binary relationship there
378.57|4.05|that I will go into but the downside is
381.42|2.64|that this fully couples the
382.62|2.91|functionality so if you're just trying
384.06|2.91|to improve your moving objects detector
385.53|3.96|then of course
386.97|4.62|maybe you're just fine-tuning the last
389.49|3.48|piece without touching the backbone but
391.59|2.37|if you if those features are not good
392.97|2.28|enough and you actually have to touch
393.96|2.76|the backbone the sudden you have to
395.25|3.39|continue training all the other tasks
396.72|3.82|it's something yet to revalidate all the
398.64|2.92|other tasks so just couples the
400.54|3.29|problem and makes it much more
401.56|5.4|challenging to actually evaluate so
403.83|4.81|there's a massive kind of space of
406.96|3.18|in-betweens of the architectures in
408.64|3.39|between this one and the first one that
410.14|3.3|I showed and exactly how you lay out the
412.03|3.18|architecture and how you plug everything
413.44|3.96|together is there's a large unknown
415.21|4.23|there so you can try to explore this
417.4|4.08|manually or you can try some approaches
419.44|3.93|that have been developed sort of that
421.48|3.57|are automatic typically these approaches
423.37|3.69|like this paper Auto D plot that has
425.05|3.72|come out recently they're trying to find
427.06|3.81|the optimal architecture in the NASA net
428.77|3.78|kind of style for semantic segmentation
430.87|4.29|problem and so they find where should
432.55|4.11|the different operations be how are they
435.16|3.12|hardly plugging together whereas the
436.66|3.03|encoder decoder have you up sample and
438.28|2.76|all those different things so you can
439.69|2.82|imagine running something like that in
441.04|2.88|our setting but it gets a bit more
442.51|3.6|complicated because we don't just have
443.92|3.69|one task we have multiple tasks so
446.11|3.24|exactly how do you layout this
447.61|3.51|architecture how much feature sharing is
449.35|3.48|there maybe the first three layers are
451.12|3.12|shared but from then on they split off
452.83|2.88|into a different networks how much
454.24|3.93|capacity do you allocate to any single
455.71|4.59|different sub piece of this network it's
458.17|3.9|it's not really obvious how you actually
460.3|4.98|go about exploring all these different
462.07|4.59|choices there are papers that recently
465.28|4.8|have started to come out a row that
466.66|5.34|actually study these multi task settings
470.08|3.87|and all these different tasks they're
472.0|3.09|typically very heterogeneous so some of
473.95|3.45|them will help each other and some of
475.09|3.9|them will hurt each other and so there's
477.4|3.87|complicated binary matrix here in this
478.99|3.54|paper of which tasks seems to be helping
481.27|3.48|each other in which tasks I seem to
482.53|3.96|fight so as an example for us moving
484.75|3.3|objects and traffic lights typically do
486.49|3.12|not share too many features so we see
488.05|2.79|that they fight but some other tasks
489.61|3.66|actually help each other so when you
490.84|5.31|train moving objects with a second task
493.27|5.34|the accuracy on the moving objects could
496.15|4.76|actually improve so what they find in
498.61|4.92|this paper is that they study basically
500.91|4.57|the problem of how many backbones do I
503.53|4.14|have and where do I put the heads and
505.48|3.63|how should I allocate the heads to the
507.67|3.45|backbones to come up with the optimal
509.11|4.38|performance and they study this as a
511.12|3.39|function of your computational budget so
513.49|3.12|if you don't have too many resources
514.51|3.42|computationally then you would have a
516.61|2.76|single backbone and you would hang all
517.93|5.79|the heads on top of that single backbone
519.37|6.78|but then on the very bottom let me try
523.72|4.89|to a point this is kind of ambitious but
526.15|4.11|as I can't see but on the very bottom
528.61|3.33|they find that the optimal assignment if
530.26|3.03|you do have more resources is that you
531.94|2.62|actually have independent backbones and
533.29|3.7|you place some of the heads of
534.56|5.49|Beckham's but there's a discrepancy
536.99|5.13|between a train and a test kind of
540.05|3.66|training and inference there so as an
542.12|4.05|example one of the backbones could be
543.71|4.14|trained on five tasks but then at test
546.17|3.42|time you only intend to run three of
547.85|3.69|those five tasks on that backbone the
549.59|3.87|other two tasks are only there to create
551.54|3.81|better features for that backbone which
553.46|3.54|is really interesting so we also find
555.35|3.45|similar things except we have like 30 or
557.0|3.6|50 tasks and we try to study some of
558.8|3.42|these relationships but it's a very
560.6|3.09|complicated but we do see these
562.22|4.53|complicated interactions it's not
563.69|5.22|obvious how you actually study them in
566.75|4.8|this paper they propose a few few ideas
568.91|3.99|there now where it gets even more
571.55|3.0|complicated for us is that we don't just
572.9|2.85|have a single viewport a viewpoint we
574.55|3.3|actually have eight cameras as I
575.75|4.02|mentioned and all of those cameras as
577.85|3.66|you might imagine are just different
579.77|3.66|viewpoints but they're all made they all
581.51|3.269|have cars they all have potentially
583.43|2.76|other objects like traffic lights and so
584.779|4.171|on and so you might imagine that you
586.19|6.21|actually might want to share features
588.95|5.1|across those different viewpoints so for
592.4|4.26|us it looks a little bit like this
594.05|4.62|potentially where we might have some of
596.66|4.05|the first layers that are shared across
598.67|3.78|all the other viewpoints because all the
600.71|3.48|viewpoints will have edges and piece and
602.45|3.51|little wheel shapes and stuff like that
604.19|3.75|but then they start to split off later
605.96|4.14|in the network and eventually on a per
607.94|4.17|camera you might actually split off all
610.1|3.78|the different tasks and so this is
612.11|3.6|potentially what that network could look
613.88|3.63|like and then the other dimension to all
615.71|4.83|of this of course is that not only do we
617.51|5.22|have tasks that are per camera or per or
620.54|3.96|use multiple cameras but we have tasks
622.73|3.42|that potentially could use context
624.5|4.17|across time so you have to imagine
626.15|5.01|taking this beast of a network stamping
628.67|3.63|it out across time and if you're using
631.16|2.31|something like a recurring all that or
632.3|3.12|something you would be sharing features
633.47|3.54|across the time dimension but
635.42|5.22|effectively your network ends up looking
637.01|6.0|maybe something like this it's a bit of
640.64|3.6|a beast and then what's going on is that
643.01|2.97|you have all these different tasks that
644.24|4.62|this network is simultaneously juggling
645.98|5.04|so as an example maybe I take a batch of
648.86|3.96|static objects on a narrow camera which
651.02|3.66|is one facing forward and then what that
652.82|3.33|does is it subsamples the part of this
654.68|2.49|network and only on that part of the
656.15|3.18|network are we doing a forward backward
657.17|4.62|and an update and the other parts of the
659.33|4.23|network are held still and then maybe we
661.79|3.36|have a different batch and in this case
663.56|3.06|it's a batch of path prediction
665.15|2.67|I'm not going to go into the details of
666.62|3.27|that prediction but this
667.82|3.72|tasks actually could be a prediction
669.89|3.81|that is based on not just one camera but
671.54|4.08|three cameras giving yourself a bit more
673.7|3.36|of a wider field of view and so in this
675.62|4.61|case we subsample a different portion of
677.06|5.52|the network and train that and then we
680.23|4.24|try to train the cutting detector and
682.58|3.63|the cutting detector might benefit from
684.47|3.81|temporal information of how these cars
686.21|3.63|are moving over time and so you might
688.28|4.32|activate again a different part of this
689.84|4.23|network so while you're training you're
692.6|3.6|always sampling these different tasks
694.07|4.77|and sampling this network and training
696.2|3.66|different pieces of it and they're there
698.84|3.06|sharing some of the features in
699.86|4.86|complicated ways that are sometimes
701.9|4.74|difficult to do honestly like derive as
704.72|3.54|to what they should be so there's a lot
706.64|4.2|of intuition that goes into it and a lot
708.26|3.36|of experimentation of course so those
710.84|2.04|are just the architectural
711.62|2.4|considerations and we have a ton of
712.88|2.82|considerations with respect to loss
714.02|3.06|functions so as you might imagine all
715.7|3.21|these different tasks will kind of
717.08|3.27|mathematically plug into the same final
718.91|3.12|loss and that's what's being back
720.35|3.3|propagated now when you actually look
722.03|4.14|into the literature of how people deal
723.65|4.92|with these very large and multi task
726.17|5.16|settings I'm just picking a random paper
728.57|4.46|here this this pen optics imitation
731.33|3.66|paper that I found a few weeks ago maybe
733.03|3.22|so they're doing this simultaneously
734.99|2.61|both something that looks like object
736.25|3.93|detection but also something that looks
737.6|4.71|like semantic segmentation and you see
740.18|3.48|you have these lambdas here and those
742.31|3.36|lambdas are high parameters they are
743.66|3.75|task weights so how much do you weigh
745.67|3.66|the object detection part and the
747.41|3.18|somatic segmentation part and typically
749.33|2.76|what you find in these papers is that
750.59|3.66|there's a large grid search going on
752.09|3.99|over those task weights so it's a brute
754.25|3.75|force solution trying to identify what
756.08|3.42|those whites should be to get the best
758.0|4.32|mean average precision or something like
759.5|4.71|that and this works if you have two of
762.32|4.05|them it does not work if you have say
764.21|4.35|hundred of them which is what we do have
766.37|4.23|and so you have to do something
768.56|3.63|different a lot of it typically relies
770.6|4.29|on intuition I'd love to see other
772.19|4.74|approaches but the difficult aspect of
774.89|4.2|this is that the heterogeneity of these
776.93|3.6|tasks is not just on the architectural
779.09|3.48|level because some tasks might need for
780.53|4.86|example much more dilation than others
782.57|4.83|but this heterogeneity is also on the on
785.39|3.72|the level of losses and that's because
787.4|3.39|some tasks might be in different scales
789.11|3.72|so their losses could be classification
790.79|3.9|or regression so different scales of
792.83|4.11|these loss functions would have
794.69|3.75|different task weights potentially some
796.94|2.94|tasks are much more important so as an
798.44|2.64|example moving objects tasks would be
799.88|4.14|much more important than the road
801.08|4.11|Kings tasks if I don't correctly predict
804.02|2.73|road markings I might take the wrong
805.19|3.78|turn but at least I'm not going to
806.75|3.54|potentially crash into something some
808.97|2.49|tasks are much easier than others so
810.29|2.4|what we see is that some tasks just
811.46|2.88|converged very easily and very
812.69|3.03|immediately but some tasks have a
814.34|3.0|massive amount of variety like moving
815.72|2.9|objects they will take a long time to
817.34|3.78|train
818.62|3.82|conversely say like a road markings task
821.12|3.39|if you're trying to identify a left
822.44|3.39|arrow that left arrow will always take
824.51|3.72|on a very similar appearance so it
825.83|4.35|trains much faster sometimes had much
828.23|3.84|more data than others or have much more
830.18|3.21|noise and so this has repercussions on
832.07|3.3|the regularization strength of the
833.39|4.29|different sub parts of this graph so if
835.37|4.11|I have a some task that has very few
837.68|3.69|examples then of course I can't afford
839.48|4.71|to train a very thick head for it or I
841.37|4.68|can't afford to use too many parameters
844.19|3.29|there or I might want to regularize that
846.05|5.28|piece of the network much more strongly
847.48|5.2|so it's not just about the weights but
851.33|3.35|also the regularization coefficients for
852.68|4.89|all these different tasks and there's no
854.68|6.43|there's no like real language in the
857.57|5.94|community as to how we how we sort of
861.11|3.69|understand or measure all these
863.51|2.19|different components for tasks like what
864.8|3.24|are the things that matter the amount
865.7|3.51|noise the amount of data set some kind
868.04|4.02|of an importance that maybe could be
869.21|4.08|tuned by the person but how you actually
872.06|2.43|come up in a principled way with these
873.29|2.81|task weights I think is like quite
874.49|3.93|unknown based on what I've seen so far
876.1|3.34|so those are sort of the statics of the
878.42|2.91|problem the architecture in the loss
879.44|3.57|function there's a lot that goes also
881.33|4.98|into some of the training dynamics so
883.01|4.58|what makes this hard so as an example we
886.31|4.08|are trying to get a traffic lights to
887.59|4.36|color to work well if you are just
890.39|2.97|naively sampling your datasets from the
891.95|2.94|fleet then you might find that most of
893.36|3.09|the traffic lights will always have red
894.89|3.66|or green color and so it will be very
896.45|5.91|unlikely for you to run into orange or
898.55|5.19|say blue or something like that so you
902.36|3.24|might be in a setting where you have a
903.74|4.68|million red and green and you only have
905.6|4.98|like 50,000 of orange or 10,000 of blue
908.42|4.68|after you've tried really hard and so
910.58|4.11|what you do typically in that case is in
913.1|3.33|academia what you'll see a standard is
914.69|3.39|you might want to start to massage your
916.43|3.99|batches so it's not just about the task
918.08|4.35|weights but you can also massage the
920.42|3.75|batches and make sure that you have some
922.43|3.93|representation of all these rare classes
924.17|5.43|speak due to the label imbalance inside
926.36|5.13|your badge now this oversampling or this
929.6|3.54|tuning of these batches doesn't just
931.49|2.59|happen on a single batch level serve
933.14|2.53|like within attack
934.08|4.05|like traffic lights but it also happens
935.67|4.32|across tasks because some of these tasks
938.13|4.05|that I mentioned are much easier to
939.99|3.69|train and train much faster so as an
942.18|3.15|example the road markings task we might
943.68|4.77|only want to sample a batch of road
945.33|4.47|markings every tenth cycle but moving
948.45|3.45|objects we might want to sample more
949.8|4.26|often to Train and so we have a schedule
951.9|4.35|for batches that is both on the level of
954.06|4.35|tasks but also inside a task we have a
956.25|4.95|schedule of batches and examples that we
958.41|4.71|pick there so here's our data set as an
961.2|4.23|example in a cartoon setting we have
963.12|4.35|rows which are different images columns
965.43|4.32|which are different tasks and then X
967.47|4.71|indicates a presence of a label for that
969.75|4.35|task and that image as you'll note this
972.18|3.36|is a very sparse array typically in
974.1|3.27|academia what I'm seeing is that these
975.54|3.69|are almost always assumed to be dense so
977.37|3.12|each image has all the supervision this
979.23|3.15|is not the case for us because you have
980.49|3.57|to remember there's a data engine for
982.38|4.38|every single tasks so they'll he'll have
984.06|4.38|their own sort of instances as you end
986.76|4.02|up with a very sparse array there's over
988.44|4.32|sampling across both tasks but also
990.78|4.02|within a task there's all kinds of
992.76|4.23|complicated over sampling and what you
994.8|4.2|end up with typically as something along
996.99|4.2|the lines of sample a task from your
999.0|4.11|scheduled sample a batch for that task
1001.19|3.36|do a forward and backward and do an
1003.11|3.03|update and there's some of the issues
1004.55|3.27|that you run into as an example and
1006.14|4.08|these are somewhat subtle is that
1007.82|4.65|suppose I take a batch of moving objects
1010.22|3.78|and I did all this work of the forward
1012.47|3.69|pass and I do the moving objects head
1014.0|3.75|and I'm gonna do the backward pass so
1016.16|3.66|suppose that this example that I just
1017.75|4.5|forwarded also happens to have a label
1019.82|4.2|for static objects so since I've done
1022.25|3.48|all this work of the forward pass I
1024.02|3.569|might as well want to amortize that work
1025.73|4.62|and actually train on the static objects
1027.589|5.311|if I have that label so should I train
1030.35|4.109|that component or not so you'd like to
1032.9|3.6|amortize the computation and train on it
1034.459|4.141|but if you do you're actually messing
1036.5|3.6|with the over sampling ratios that
1038.6|3.72|you've specified per task so that
1040.1|4.32|example you're sort of messing with the
1042.32|4.08|distributions of your matches and some
1044.42|3.029|non-intuitive ways so so what I'm trying
1046.4|3.63|to get at is and I do want to go into
1047.449|4.141|full detail but the scheduling of this
1050.03|4.98|is somewhat complex and there's a lot of
1051.59|5.97|open questions here the other kind of
1055.01|3.75|interesting aspects of this are you will
1057.56|2.16|know about early stopping when you're
1058.76|3.39|trying to get a model to work really
1059.72|4.32|well you monitor the test loss and/or do
1062.15|4.02|validation loss and you take your model
1064.04|3.6|whenever your validation loss is lowest
1066.17|3.39|let's at least
1067.64|5.72|that works well if you have one task
1069.56|3.8|what happens when you have 200 tasks
1073.42|3.13|where do you take your model I don't
1076.07|4.35|know
1076.55|5.1|so your plots will typically look like
1080.42|2.64|this in tensor board and now you're
1081.65|3.03|trying to get your model and obviously
1083.06|3.12|some tasks will over fit much earlier
1084.68|3.39|than others because they are easier or
1086.18|3.45|they have more data or less data and so
1088.07|5.04|this heterogeneity again is pretty
1089.63|5.1|tricky to to deal with and how do you
1093.11|3.12|now manipulate the tasks or the over
1094.73|4.44|sampling rates or the task weights or
1096.23|4.59|the regularization so that ideally these
1099.17|3.87|end up in the same spot so you can just
1100.82|5.76|cut a clean model it's not it's not
1103.04|5.85|obvious the last pieces that I wanted to
1106.58|4.17|go into just mostly for entertainment
1108.89|3.66|actually is with respect to the teamwork
1110.75|4.44|flow around how you actually collaborate
1112.55|4.26|on a network like this as I described
1115.19|3.66|this is kind of a beast of a network it
1116.81|4.86|multitasks so many things and we have a
1118.85|4.47|finite team and this team is dispersed
1121.67|4.26|across the network and collaborating on
1123.32|4.41|this network at the same time so maybe
1125.93|3.45|there's we have this notion of a task
1127.73|3.0|owner so someone's working up on the
1129.38|3.03|moving objects someone is working on
1130.73|2.88|static objects someone is turning on
1132.41|3.24|traffic lights and the architecture
1133.61|3.63|there someone is messing with the lost
1135.65|2.91|function for traffic lights and two
1137.24|5.73|interns are working on the architecture
1138.56|6.09|on the bottom so the tricky thing is
1142.97|3.78|that and I haven't seen this ever before
1144.65|4.2|is you have this large network but you
1146.75|3.75|have say 10 20 people collaborating on
1148.85|3.81|this network and they all own different
1150.5|4.47|sub parts of this network and what does
1152.66|5.19|that look like in practice if you have a
1154.97|4.77|code base of course you have git and you
1157.85|3.75|pull requests and commits and and so on
1159.74|3.24|but these people are collaborating on
1161.6|3.36|the neural network and this is all
1162.98|3.78|coupled functionality and it's really
1164.96|3.21|not obvious how you iterate on networks
1166.76|3.6|where multiple people are simultaneously
1168.17|6.54|changing the tasks the weights the data
1170.36|6.72|itself and everything is is moving so
1174.71|3.9|just a few interesting kind of things
1177.08|3.12|that have happened in a team as an
1178.61|3.6|example I walk around that's me on the
1180.2|4.77|bottom left over there and I say hi
1182.21|3.96|traffic traffic lights task owner if you
1184.97|2.43|could make traffic lights work a bit
1186.17|3.63|better that would be great
1187.4|4.5|and the traffic lights and there are
1189.8|3.69|many tips and tricks to actually getting
1191.9|3.9|your tasks the one that you own and you
1193.49|4.11|want to work very well to work well so
1195.8|3.57|the traffic lights owner has an idea and
1197.6|2.97|they go to the configuration file where
1199.37|2.61|you list all the different tasks
1200.57|3.12|and as I mentioned we have different
1201.98|3.449|oversampling ratios for different tasks
1203.69|3.75|so you just go to the traffic lights and
1205.429|4.441|you see your oversample as just one so
1207.44|4.89|you make that two and that means that
1209.87|3.72|your task will be trained more and that
1212.33|2.91|means your network will work better on
1213.59|3.99|your traffic lights tasks and then you
1215.24|4.59|say hey can you prove my commits and a
1217.58|3.829|random person says ok and moving objects
1219.83|4.02|person gets upset what's going on here
1221.409|4.36|because their tasks will be starved of
1223.85|4.439|resources and the capacity of the
1225.769|4.591|network is finite and so suddenly this
1228.289|3.451|is not okay so this is a very obvious
1230.36|2.819|one the team is caught on we don't try
1231.74|2.819|to manipulate oversampling ratios too
1233.179|3.72|much but there are many more devious
1234.559|3.57|ways of making your tasks work better so
1236.899|2.851|as an example you go to your traffic
1238.129|6.9|light loss and you just multiply your
1239.75|7.86|loss by 10 let's make your tat this
1245.029|5.581|makes your task work better potentially
1247.61|9.149|but it's so it's not illegal but it's
1250.61|7.71|definitely frowned upon ok so I mean the
1256.759|3.571|higher point being that there's finite
1258.32|3.329|capacity to go around and a lot of
1260.33|4.77|people are trying to simultaneously get
1261.649|5.61|their their tasks to work well but there
1265.1|4.35|are many ok ways of doing that and some
1267.259|4.861|of them are caused political drama I
1269.45|4.559|would say in the team that and I have I
1272.12|4.439|have to somehow like allocate capacity
1274.009|3.9|to the tasks but there's no easy ways of
1276.559|4.5|doing that it's not really task awaits
1277.909|4.26|it's not over sampling so I don't really
1281.059|1.881|have language to describe how to
1282.169|3.11|correctly
1282.94|6.04|allocate capacity to tasks and
1285.279|5.221|interesting weights to them another
1288.98|3.449|interesting aspect that we've noticed is
1290.5|2.95|very often it is the case that you have
1292.429|2.551|all these different tasks they
1293.45|2.79|simultaneously coexist in the network
1294.98|3.12|you're pretty happy with everything
1296.24|3.179|except for this one task that needs that
1298.1|3.929|it's kind of misbehaving in a certain
1299.419|4.531|way you want to change that sub task and
1302.029|3.931|so it has some kind of a failure mode
1303.95|2.939|that you want to fix so because you
1305.96|2.339|don't want to touch the full network
1306.889|3.66|because everything is validated and
1308.299|4.651|signed off you might have this idea that
1310.549|3.87|ok I will just what I'll do is I will
1312.95|3.87|just fine-tune this little piece of this
1314.419|3.691|network and I will make this work a bit
1316.82|2.88|better just by fine tuning that small
1318.11|3.72|piece I'm not touching any of the other
1319.7|3.719|tasks nothing has to be revalidated and
1321.83|3.449|so on and I'll just try to improve this
1323.419|3.271|in isolation so basically you find you
1325.279|2.73|never adjust your task and you leave
1326.69|3.449|everything unchanged do you create a new
1328.009|4.38|model and you might want to go with that
1330.139|4.01|so what was the worst that could happen
1332.389|3.44|is the follow
1334.149|4.32|so what happens is you end up with a
1335.829|5.1|very complicated lineage of models where
1338.469|3.87|a person took a base model and
1340.929|2.7|fine-tuned it and then a different
1342.339|2.73|person took their model and fine-tuned
1343.629|2.61|something else and then someone
1345.069|2.43|functions something on top of that and
1346.239|3.03|somehow fine-tuned something on the
1347.499|3.09|wrong base model and now because the
1349.269|3.06|model has changed so now there's a
1350.589|3.96|complicated chain of fine tunings that
1352.329|4.83|people have performed and this this
1354.549|3.81|doesn't work it starts to look something
1357.159|3.72|like that
1358.359|5.7|so you really have to and of course the
1360.879|5.13|worst of it is is that some of these
1364.059|3.48|models then become not reproduce able so
1366.009|3.6|what you can end up with and this has
1367.539|3.42|happened to our team is you end up with
1369.609|3.75|very good models that have gone through
1370.959|3.66|non-intuitive chain of fine tunings you
1373.359|2.64|end up with a very good model that you
1374.619|3.06|can't reproduce and that is the worst
1375.999|4.02|because you retrain from scratch and you
1377.679|3.93|you're regressing some performance that
1380.019|2.97|you've had there so it's very appealing
1381.609|3.33|to want to do this but we found for
1382.989|3.66|example because of the workflow that you
1384.939|3.0|actually just can't you can't get away
1386.649|4.47|with that it's not a good idea
1387.939|5.16|so in summary just some of the things I
1391.119|3.6|talked about of course we have so many
1393.099|3.24|different tasks there are many
1394.719|3.36|considerations to the architecture to
1396.339|4.77|the loss function there train dynamics
1398.079|4.35|and how to deal with all the
1401.109|3.54|regularization and then lock task
1402.429|3.93|weights there's no language that I'm
1404.649|3.42|aware of in academia to talk about the
1406.359|3.81|heterogeneity of these tasks and
1408.069|4.23|different properties thereof and how to
1410.169|5.16|make everything work with early stopping
1412.299|4.92|and stuff like that and also the most
1415.329|2.88|fascinating component to me is when you
1417.219|2.76|have networks that are means
1418.209|2.88|simultaneously worked on by 20 people
1419.979|3.78|what does that look like
1421.089|5.4|where are the what is the etiquette and
1423.759|4.59|then what where are the the tips and
1426.489|3.12|tricks and rules of thumb for how to how
1428.349|4.991|to work with these architectures so that
1429.609|4.241|everything works ok great thank you
1433.34|4.59|[Applause]
1433.85|4.08|[Music]