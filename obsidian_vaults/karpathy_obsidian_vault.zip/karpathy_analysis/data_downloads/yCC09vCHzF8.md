start_time|end_time|text
0.299|11.161|test test okay it works okay good we
6.69|5.88|should get started soon so today we'll
11.46|2.73|be talking about recurrent neural
12.57|3.18|networks which is one of my favorite
14.19|3.39|topics one of my favorite models to play
15.75|3.96|with and put into neural networks just
17.58|4.199|everywhere there are a lot of fun to to
19.71|3.93|play with in terms of administrative
21.779|2.941|items recall that your midterm is on
23.64|2.25|Wednesday
24.72|2.25|this one's day you can tell that I'm
25.89|4.32|really excited I don't know if you guys
26.97|6.39|are excited you don't look very excited
30.21|5.79|to me but the 7/3 will be out do this
33.36|5.16|Wednesday it's sorry will be out in
36.0|3.899|Wednesday it's due two weeks from now on
38.52|2.91|Monday but I think since we're shifting
39.899|3.031|it I think to Wednesday we plan to have
41.43|2.58|released it today but we're going to be
42.93|2.879|shifting it to roughly Wednesday so
44.01|3.93|we'll probably defer the deadline for it
45.809|4.02|by a few days and assignment two if I'm
47.94|3.33|not mistaken was due on Friday so if
49.829|3.48|you're using three late days then you'd
51.27|3.99|be handing it in today hopefully not too
53.309|3.27|many of you are doing that our people
55.26|3.84|done with the seven two or how many
56.579|5.581|people are done okay most of you okay
59.1|4.619|good great okay so we're doing well so
62.16|3.09|currently in the class we're talking
63.719|2.851|about convolutional neural networks last
65.25|2.549|class specifically we looked at
66.57|3.089|visualizing and understanding
67.799|3.271|convolutional neural networks so we
69.659|2.971|looked at a whole bunch of pretty
71.07|3.42|pictures and videos and we had a lot of
72.63|3.059|fun trying to interpret exactly what
74.49|2.46|these convolutional networks are doing
75.689|4.381|what they're learning how they're
76.95|6.75|working and so on and so we debug this
80.07|5.369|through several ways that you maybe can
83.7|3.209|recall from last lecture actually over
85.439|3.93|the weekend I stumbled by some other
86.909|3.78|visualizations that are new I found
89.369|4.591|these on Twitter and they look really
90.689|5.731|cool and I'm not sure how people made
93.96|4.199|these because there's not too much
96.42|5.1|description to it but looks really cool
98.159|5.75|this is turtles in tarantula and then
101.52|4.95|this is chain and some kind of a dog and
103.909|3.701|so the way you do this I think it's
106.47|2.609|something like deep dream that's again
107.61|2.969|optimization into images but they're
109.079|3.0|using a different regularizer on the
110.579|3.061|image so in this case I think they're
112.079|3.36|using a bilateral filter which is this
113.64|3.39|kind of a fancy filter so if you put
115.439|3.0|that regularization on the image then my
117.03|2.519|impression is that these are the kinds
118.439|3.301|of visualizations that you achieve
119.549|3.6|instead so that looks pretty cool but I
121.74|4.79|yeah I'm not sure exactly what's going
123.149|5.461|on I guess we'll find out soon okay
126.53|3.94|so today we're going to be talking about
128.61|2.94|recurrent neural networks what's nice
130.47|2.46|about recurrent neural networks is that
131.55|2.85|they offer a lot of
132.93|3.63|flexibility and how you wire up your
134.4|3.059|neural network architectures so normally
136.56|2.099|when you're working with neural let's
137.459|2.791|here in the case on the very left here
138.659|3.931|where you're given a fixed sized input
140.25|4.14|vector here in red then you process it
142.59|3.269|with some hidden layers in green and
144.39|3.84|then you produce a fixed size output
145.859|4.141|vector in blue so say an image comes in
148.23|3.45|which is a fixed sized image and we're
150.0|3.689|producing a fixed sized vector which is
151.68|3.36|the classes course when the recurrent
153.689|3.121|neural networks we can actually operate
155.04|4.229|over sequences sequences at the
156.81|3.42|input/output or both at the same time so
159.269|2.22|for example in the case of image
160.23|3.27|captioning and we'll see some of it
161.489|3.271|today you're given a fixed sized image
163.5|2.37|and then through a recurrent neural
164.76|3.059|network we're going to produce a
165.87|4.019|sequence of words that describe the
167.819|4.89|content of that image so that's going to
169.889|4.5|be sentence that is the caption for that
172.709|3.271|image in a case of sentiment
174.389|3.871|classification in the NLP for example
175.98|3.569|we're consuming a number of words in
178.26|2.759|sequence and then we're trying to
179.549|3.991|classify whether the sentiment of that
181.019|4.411|sentence is positive or negative in the
183.54|3.809|case of machine translation we can have
185.43|4.44|a recurrent neural network that takes a
187.349|4.23|number of words in say English and then
189.87|4.199|it's asked to produce a number of words
191.579|4.56|in in French for example as a
194.069|3.271|translation so we'd feed this into a
196.139|2.701|recurrent neural network in what we call
197.34|3.09|sequence the sequence kind of set up and
198.84|3.47|so this recurrent network would just
200.43|4.709|perform translation on arbitrary
202.31|4.12|sentences in English into French and in
205.139|2.82|the last case for example we have video
206.43|3.089|classification where you might want to
207.959|4.291|imagine classifying every single frame
209.519|4.83|of video with some number of classes but
212.25|3.389|crucially you don't want the prediction
214.349|3.151|to be only a function of the current
215.639|3.421|time step the current frame of the video
217.5|3.569|but also all the frames that have come
219.06|3.239|before it in the video and so recurrent
221.069|2.88|neural networks allow you to wire up an
222.299|2.97|architecture where the prediction at
223.949|3.06|every single time step is a function of
225.269|4.19|all the frames that have come in up to
227.009|4.62|that point now even if you don't have
229.459|3.52|sequences at input or output you can
231.629|2.97|still use recurrent neural networks even
232.979|3.271|in the case on a very left because you
234.599|5.551|can process your fixed size inputs or
236.25|6.449|outputs sequentially so for example one
240.15|3.839|of my favorite examples of this is from
242.699|2.91|a paper from deep mind from awhile ago
243.989|3.81|where they were trying to transcribe
245.609|5.46|house numbers and instead of just having
247.799|4.41|this big image feed into a comment and
251.069|2.581|try to classify exactly what house
252.209|3.24|numbers are in there they came up with a
253.65|3.329|recurrent neural network policy where
255.449|2.85|there's a small comment and it's steered
256.979|2.76|around the image spatially with a
258.299|2.881|recurrent neural network and so the
259.739|2.701|recurrent network learned to basically
261.18|4.229|read out house numbers from left to
262.44|3.72|right sequentially and so we have fixed
265.409|1.941|sized input
266.16|4.29|we're processing and sequentially
267.35|5.68|conversely we can think about this is a
270.45|3.99|also a well-known paper called draw this
273.03|2.82|is a generative model so what you're
274.44|3.33|seeing here are samples from the model
275.85|3.66|where it's coming up with these digit
277.77|3.33|samples but crucially we're not just
279.51|3.06|predicting these digits at a single time
281.1|3.12|but we have a recurrent neural network
282.57|3.72|and we think of the output as a canvas
284.22|3.93|and the kernel goes in and paints it
286.29|3.06|over time and so you're giving yourself
288.15|2.43|more chance to actually do some
289.35|2.97|computation before you actually produce
290.58|3.99|your output so it's a more powerful kind
292.32|15.96|of a form of processing data
294.57|15.0|what are question over there so every
308.28|3.36|one of these arrows is kind of like a
309.57|4.14|dependency in terms of I guess we'll see
311.64|3.87|specifics of exactly what this means for
313.71|5.28|now arrows just indicate indicate
315.51|4.77|functional dependence so things yeah so
318.99|3.69|things are a function of things before
320.28|11.93|and we'll go into exactly what that
322.68|9.53|looks like in a bit okay so of this one
332.33|5.05|so these are generated house numbers so
335.82|2.67|the network looked at a lot of house
337.38|3.9|numbers and it came up with a way of
338.49|4.17|painting them and so these are not in a
341.28|3.54|training data these are made-up house
342.66|5.07|numbers from the model none of these are
344.82|4.71|actually in the training set these are
347.73|3.53|made up yeah they look quite real but
349.53|3.96|they're actually made up from the model
351.26|4.75|so a recurrent neural network is
353.49|5.34|basically this thing here a box in green
356.01|5.58|and it has a state and it basically
358.83|4.62|receives through time it receives input
361.59|3.36|vectors so at every single time step we
363.45|3.63|can feed in an input vector into the
364.95|4.02|arlynn and it has some state internally
367.08|4.53|and then it can modify that state as a
368.97|4.14|function of what it what it receives at
371.61|3.42|every single time step and so they're
373.11|3.99|all of course being weights inside the
375.03|3.42|RNN and so when we tune those weights
377.1|3.36|the RNN will have different behavior in
378.45|5.01|terms of how its state evolves as it
380.46|4.95|receives these inputs now usually we can
383.46|5.16|also be interested in producing an
385.41|4.41|output based on the RNN state so we can
388.62|3.39|produce these vectors on top of the
389.82|3.63|arlynn but so you'll see show pictures
392.01|3.93|like this but I just like to know that
393.45|4.2|the Arnon is really just the block in
395.94|3.09|the middle where it has a state that it
397.65|1.53|can receive vectors over time and then
399.03|1.62|we
399.18|4.44|can base some prediction on top of its
400.65|4.62|state in some applications okay
403.62|5.49|so concretely the way this will look
405.27|5.67|like is the RNN has some kind of a state
409.11|4.8|where which here I'm denoting as a
410.94|4.44|vector H and but this can be also a
413.91|4.5|collection of vectors or just a more
415.38|5.46|general state and we're going to base it
418.41|4.47|as a function of the previous hidden
420.84|4.049|state at previous iteration time t minus
422.88|3.75|1 and the current input vector x t and
424.889|3.06|this is going to be done through a
426.63|3.569|function which i'll call a recurrence
427.949|4.53|function f and that function will have
430.199|3.211|parameters W and so as we change those
432.479|2.19|WS
433.41|2.4|we're going to see that the ironin will
434.669|2.551|have different behaviors and then of
435.81|2.76|course we want some specific behavior
437.22|3.24|are the Arnon so we're going to be
438.57|3.599|training those weights on data so you'll
440.46|3.57|see examples of that soon for now I'd
442.169|3.901|like you to note that the sinc function
444.03|4.41|is used at every single time step we
446.07|4.08|have a fixed function f of weights W and
448.44|3.69|we applied that single function at every
450.15|4.199|single time step and that allows us to
452.13|4.11|use the or kernel network on sequences
454.349|3.061|of without having to commit to the size
456.24|2.94|of the sequence because we apply the
457.41|3.66|exact same function at every single time
459.18|4.5|step no matter how long the input or
461.07|4.409|output sequences are so in a specific
463.68|2.94|case of a recurrent neural network a
465.479|2.731|vanilla recurrent neural network the
466.62|3.66|simplest way you can set this up in the
468.21|4.139|simplest recurrence you can use is what
470.28|3.33|I'll refer to as a vanilla Arnon in this
472.349|3.69|case the state of a recurrent neural
473.61|4.2|network is just a single hidden state H
476.039|5.221|and then we have a recurrence formula
477.81|5.28|that basically tells you how you should
481.26|3.57|update your hidden state H as a function
483.09|4.109|of the previous hidden state and the
484.83|3.959|current input XT in particular in the
487.199|4.671|simplest case we're going to have these
488.789|5.461|weight matrices wh h and w xh and
491.87|3.82|they're going to basically project both
494.25|3.12|the hidden state from the previous time
495.69|3.06|step and the current input and then
497.37|3.269|those are going to add and then we
498.75|4.169|squish them with a 10 h and that's how
500.639|4.051|we update the hidden state at time T so
502.919|3.511|this recurrence is telling you how H
504.69|3.599|will change as a function of its history
506.43|3.299|and also also the current input at this
508.289|3.391|time step and then we can base
509.729|4.321|prediction we can base predictions on
511.68|3.899|top of H for example using just another
514.05|3.45|matrix projection on top of the hidden
515.579|3.27|state so this is the simplest complete
517.5|4.709|case in which you can wire up a neural
518.849|4.74|network okay so just to give you example
522.209|4.38|of how this will work so right now I've
523.589|4.321|just talked about X H and Y in abstract
526.589|2.671|forms in terms of vectors we can
527.91|3.119|actually endowed these vectors with
529.26|3.94|semantics and so one of the ways in
531.029|3.491|which we can use a recurrent
533.2|3.03|work is in the case of character level
534.52|2.97|language models and this is one of my
536.23|3.48|favorite ways of explaining Arnez
537.49|4.68|because it's intuitive and fun to look
539.71|4.35|at so in this case we have character
542.17|4.08|level language models using ordinance
544.06|3.78|and the way this will work is we will
546.25|3.18|feed a sequence of characters into the
547.84|3.03|recurrent neural network and at every
549.43|2.97|single time step will ask the recurrent
550.87|3.48|neural network to predict the next
552.4|3.3|character in a sequence so a prediction
554.35|2.88|entire distribution for what it thinks
555.7|3.63|should come next in the sequence that it
557.23|4.14|has seen so far so suppose that in this
559.33|4.53|very simple example we have the training
561.37|4.05|sequence hello and so we have a
563.86|4.17|vocabulary of four characters that are
565.42|3.66|in this data set HDL and O and we're
568.03|2.31|going to try to get a recurring neural
569.08|2.79|network to learn to predict the next
570.34|3.42|character in a sequence on this training
571.87|4.17|data and so the way this will work is
573.76|3.75|we'll set up we'll feed in every one of
576.04|3.12|these characters one at a time into a
577.51|3.39|recurrent neural network so you'll see
579.16|5.1|me feed in H at the first time step and
580.9|5.88|here the x axis as the x time so we'll
584.26|4.44|feed an H then we'll feed an e L&L and
586.78|3.72|here I'm encoding characters using what
588.7|3.48|we call a one hot representation where
590.5|2.88|we just turn on the bit that corresponds
592.18|3.45|to that characters order in the
593.38|3.72|vocabulary then we're going to use the
595.63|3.54|recurrence formula that I've shown you
597.1|4.29|where at every single time step suppose
599.17|3.54|we start off with H as all zero and then
601.39|2.76|we apply this recurrence to compute the
602.71|2.97|hidden state vector at every single time
604.15|3.33|step using this fixed recurrence formula
605.68|3.66|so suppose here we have only three
607.48|2.82|numbers in the hidden state we're going
609.34|2.73|to end up with a three dimensional
610.3|3.51|representation that basically at any
612.07|3.8|point in time summarizes all the
613.81|4.71|characters that have come until then and
615.87|4.39|so we have do we apply this recurrence
618.52|3.0|at every single time step and now we're
620.26|3.27|going to predict at every single time
621.52|4.65|step what should be the next character
623.53|4.47|in a sequence so for example since we
626.17|3.78|have four characters in this in this
628.0|4.14|vocabulary we're going to predict four
629.95|4.71|numbers at every single time step so for
632.14|5.1|example in the very first time step we
634.66|4.35|fed in the letter h and the RNN with its
637.24|3.51|current setting of weights computed
639.01|3.39|these unnormalized lock probabilities
640.75|4.44|here for what it thinks should come next
642.4|5.7|so things that H is 1.0 likely to come
645.19|5.07|next it thinks that e is 2.2 likely l is
648.1|4.05|negative three likely and O is 4.1
650.26|3.87|likely right now in terms of unknown
652.15|3.78|wise lock probabilities of course we
654.13|3.69|know that in this training sequence we
655.93|2.64|know that each should follow H so in
657.82|2.64|fact this
658.57|4.05|2.2 which I'm showing in green is the
660.46|3.99|correct answer in this case and so we
662.62|3.85|want that to be high and we want all
664.45|3.16|these other numbers to be low and so
666.47|3.27|every single time step we have basically
667.61|4.56|a target for what next character should
669.74|3.63|come in the sequence and so we just want
672.17|3.3|all those numbers to be high and all the
673.37|3.75|other numbers to be low and so that's of
675.47|3.6|course encoding in the encoded in the
677.12|3.99|gradient signal of the loss function and
679.07|4.05|then that gets back propagated through
681.11|3.42|these connections so another way to
683.12|2.79|think about it is that every single time
684.53|3.69|step we basically have a softmax
685.91|4.56|classifier so every one of these is a
688.22|4.05|softmax classifier over the next
690.47|2.82|character and at every single point we
692.27|2.76|know what the next character should be
693.29|3.63|and so we just get all those losses
695.03|3.87|flowing down from the top and they will
696.92|3.33|all flow through this graph backwards
698.9|2.88|through all the arrows we're going to
700.25|3.21|get gradients on all the weight matrices
701.78|3.03|and then we'll know how to shift the
703.46|4.26|matrices so that the correct
704.81|5.13|probabilities are coming out of the
707.72|4.56|Arnon so we'd be shaping those weights
709.94|3.36|so that the correct behavior the Arlen
712.28|2.58|has the correct behavior as you're
713.3|3.87|feeding characters so you can imagine
714.86|3.3|how we can train this over data are
717.17|7.65|there any questions about this diagram
718.16|8.07|good yeah thank you
724.82|3.69|so at every single time step we're
726.23|5.34|flying as I mentioned a same recurrence
728.51|4.89|the same functions always so we have a
731.57|3.69|single WX agent every time step we have
733.4|3.96|a single wh y at every time step and the
735.26|5.87|same whh applied at every time step here
737.36|6.81|so we've used WX h wh y wh h four times
741.13|4.48|in this diagram and in back propagation
744.17|3.03|when we back propagate through you'll of
745.61|3.03|course have to account for that because
747.2|3.03|we'll have all these gradients adding up
748.64|3.71|to the same weight matrices because it
750.23|5.07|has been used at multiple time steps and
752.35|4.33|this is what allows us to process you
755.3|2.76|know variably sized inputs because
756.68|3.0|that's every time step we're doing the
758.06|4.25|same thing so not a function of the
759.68|9.3|absolute amount of things in your input
762.31|8.86|okay question what are common things for
768.98|3.6|initializing the first h0 I think
771.17|6.47|setting it to zeros is quite quite a
772.58|5.06|common set H in the beginning to 0 good
778.27|4.27|does the order in which we receive the
780.5|3.24|data set matter yes because so are you
782.54|4.04|asking if I plugged in these characters
783.74|2.84|at a different order
789.59|4.51|yeah so if you see if this was a longer
792.27|3.66|sequence the order in this case in this
794.1|3.72|case always doesn't matter because at
795.93|3.78|every single point in time if you think
797.82|3.12|about it functionally like this hidden
799.71|2.43|state vector at this time step is a
800.94|5.13|function of everything that has come
802.14|5.61|before it right and so this order just
806.07|4.47|matters for as long as you're feeding it
807.75|4.38|in we're going to go through some us
810.54|3.53|through some specific examples which I
812.13|4.38|think will clarify some of these points
814.07|4.03|okay so let's look at a specific example
816.51|3.72|in fact if you want to train a character
818.1|4.11|level language model it's quite short so
820.23|3.54|I wrote a gist that you can find on
822.21|3.84|github where this is 100 line
823.77|3.93|implementation in numpy for a character
826.05|2.79|level RNN that you can go through I'd
827.7|2.34|actually like to step through this with
828.84|2.49|you so you can see concretely how we
830.04|3.42|could train a recurrent neural network
831.33|4.86|in practice and so I'm going to step
833.46|4.02|through this code video and so we're
836.19|3.03|going to go through all the blocks in
837.48|3.6|the beginning as you'll see the only
839.22|3.99|dependence here is numpy we're loading
841.08|3.99|in some text data so our input here is
843.21|3.69|just a large collection of a large
845.07|4.95|sequence of characters in this case a
846.9|5.97|text input txt file and then we get all
850.02|4.2|the characters in that file and we find
852.87|2.94|all the unique characters in that file
854.22|3.39|and then we create these mapping
855.81|3.36|dictionaries that map from characters to
857.61|4.62|indices and from indices to characters
859.17|5.79|so we basically order our characters so
862.23|4.77|say we've read in a whole bunch of file
864.96|3.18|and a whole bunch of data and we have
867.0|1.38|hundred characters or something like
868.14|1.83|that
868.38|3.87|and we've ordered them in a in a
869.97|5.01|sequence so we associate indices to
872.25|5.52|every character then here we're going to
874.98|4.41|do some initializations first our hidden
877.77|2.73|size is a hyper parameter as you'll see
879.39|3.18|with recurrent neural networks so here
880.5|4.59|I'm choosing it to be 100 here we have a
882.57|4.2|learning rate sequence length here is
885.09|3.12|set to 25 this is a parameter that
886.77|3.42|you'll be you'll become aware of with
888.21|3.6|our nets basically the problem is if our
890.19|3.18|input data is way too large say like
891.81|3.36|millions of time steps there's no way
893.37|3.12|you can put an RNN on top of all of it
895.17|2.82|because you need to maintain all of this
896.49|3.42|stuff in memory so that you can do back
897.99|3.48|propagation so in fact we won't be able
899.91|3.36|to keep all of it in terment in memory
901.47|3.33|and do backrub through all of it so
903.27|3.15|we'll go in chunks through our EMPA data
904.8|4.02|in this case we're going through chunks
906.42|4.83|of 25 at a time so as you'll see in a
908.82|4.55|bit we have this entire data set but
911.25|5.7|we'll be going in chunks of 25
913.37|4.72|characters at a time and at every time
916.95|2.7|we're just going to back propagate
918.09|2.88|through 25 characters at a time because
919.65|2.85|we can't afford to do back propagate
920.97|3.359|for longer because we'd have to remember
922.5|4.649|all that stuff and so we're going in
924.329|4.11|chunks here of 25 and then we have all
927.149|3.031|these W matrices that here I'm
928.439|4.681|initializing randomly and some biases so
930.18|4.62|WX h HH and hy and those are all of our
933.12|4.98|hi our parameters that we're going to
934.8|4.95|train with background okay now I'm going
938.1|2.849|to skip over the last function here and
939.75|3.3|I'm going to skip to the bottom of the
940.949|3.24|script here we have a main loop and I'm
943.05|3.06|going to go through some of this main
944.189|3.811|loop now so there are some
946.11|3.39|initializations here of various things
948.0|3.449|to 0 in the beginning and then we're
949.5|4.589|looping forever what we're doing here is
951.449|4.95|I'm sampling a batch of data so here is
954.089|4.141|where I actually take a batch of 25
956.399|3.601|characters out of this data set so
958.23|3.93|that's in the list inputs and the list
960.0|4.11|inputs basically just has 25 integers
962.16|3.479|corresponding to the characters the
964.11|3.599|targets as you'll see is just all the
965.639|3.51|same characters but offset by 1 because
967.709|4.041|those are the indices that we're trying
969.149|5.161|to predict at every single time step so
971.75|5.05|so the inputs and targets are just lists
974.31|5.49|of 25 characters targets is offset by 1
976.8|5.37|into the future so that's where we
979.8|5.639|sample basically a batch of data here we
982.17|4.56|this is some sampling code so at every
985.439|3.15|single point in time as we're training
986.73|3.839|this Arnon we can of course try to
988.589|4.201|generate some samples of what it's
990.569|4.74|currently thinks characters should
992.79|4.68|actually what these sequences look like
995.309|5.101|so the way we use character no low-level
997.47|4.589|RNAs and test time is that we're going
1000.41|3.119|to seed it with some characters and then
1002.059|2.64|this RNN basically always gives us the
1003.529|2.821|distribution of it the next character in
1004.699|3.301|a sequence so you can imagine sampling
1006.35|2.94|from it and then you feed in the next
1008.0|3.18|character again and you sample from the
1009.29|3.33|distribution and keep feeding it in so
1011.18|2.579|you keep feeding all the samples into
1012.62|3.42|the Ireland and you can just generate
1013.759|3.87|arbitrary text data so that's what this
1016.04|3.289|code will do and it calls the sample
1017.629|3.69|function so we'll go into that in a bit
1019.329|4.18|then here I'm calling the loss function
1021.319|4.77|the loss function receives the inputs
1023.509|5.341|the targets and it receives also this H
1026.089|4.921|prep H prep is short for hidden state
1028.85|4.8|vector from the previous chunk so we're
1031.01|4.38|going in batches of 25 and we are
1033.65|3.509|keeping track of what is the hidden
1035.39|3.779|state vector at the end of your 25
1037.159|3.78|letters so that we can when we feed in
1039.169|4.74|the next batch we can feed that in as
1040.939|4.531|the initial H at that time step so we're
1043.909|2.91|making sure that the hidden states are
1045.47|2.699|basically correctly propagated from
1046.819|3.84|batch to batch through that H prime
1048.169|5.431|variable but we're only back propagating
1050.659|4.261|those 25 time steps so we feed that into
1053.6|2.49|loss function and we get the law
1054.92|3.6|and the gradients on all the weight
1056.09|4.23|matrices and all the biases and here I'm
1058.52|3.45|just printing the loss and then here's a
1060.32|3.75|parameter update where the last function
1061.97|3.39|told us all the gradients and here we
1064.07|2.85|are actually performing the update which
1065.36|5.91|you should recognize as an ad a grad
1066.92|7.11|update so I have all these cached thing
1071.27|4.71|and all these cached variables for the
1074.03|3.39|gradient squared which I'm accumulating
1075.98|3.81|and then performing the a degrade update
1077.42|3.42|go so I'm going to go into the last
1079.79|4.259|function and what that looks like now
1080.84|5.04|the last function is this block of code
1084.049|3.87|it really consists of forward and a
1085.88|3.27|backward method so we're computing the
1087.919|2.461|forward pass and then the backward pass
1089.15|3.96|in green so I'll go through those two
1090.38|5.07|steps so in the forward pass you should
1093.11|5.28|recognize basically we get those inputs
1095.45|4.74|the targets we're iterating receive
1098.39|4.5|these 25 indices and we're now iterating
1100.19|4.92|through them from 1 to 25 we create this
1102.89|4.56|X input vector which is just zeros and
1105.11|3.78|then we set the one-hot encoding so
1107.45|4.05|whatever the index in the impetus we
1108.89|3.84|turn that bit on for with the one so
1111.5|3.45|we're feeding in the character with a
1112.73|4.11|one hot encoding then here I'm computing
1114.95|5.01|the recurrence formula using this
1116.84|4.29|equation so HSN T here HS and all these
1119.96|2.49|things I'm using dictionaries to keep
1121.13|3.21|track of everything at every single time
1122.45|4.44|step so we compute the hidden state
1124.34|4.02|vector and the output vector using the
1126.89|3.87|recurrence formula and these two lines
1128.36|4.08|and then over there I'm computing the
1130.76|3.6|softmax function so I'm normalizing this
1132.44|3.69|so that we get probabilities and then
1134.36|3.84|your loss is negative log probability of
1136.13|4.86|the correct answer so that's just a
1138.2|4.41|softmax classifier loss over there so
1140.99|2.55|that's the forward pass and now we're
1142.61|3.809|going to back propagate through the
1143.54|4.65|graph so in the backward pass we go
1146.419|3.63|backwards through that sequence from 25
1148.19|3.989|all the back all the way back to 1 and
1150.049|3.661|maybe you'll recognize I don't know how
1152.179|2.641|much detail level to go in here but
1153.71|2.94|you'll recognize that I'm back
1154.82|2.94|propagating through a softmax I'm back
1156.65|2.58|propagating through the activation
1157.76|3.45|functions I'm back propagating through
1159.23|4.41|all of it and I'm just adding up all the
1161.21|3.839|gradients and all the parameters and one
1163.64|4.14|thing to note here especially is that
1165.049|5.191|these gradients on weight matrices like
1167.78|3.42|whh I'm using a plus equals because at
1170.24|2.4|every single time step
1171.2|3.359|all of these weight matrices get a
1172.64|3.029|gradient and we need to accumulate all
1174.559|2.581|of it into all the weight matrices
1175.669|3.5|because we keep using all these weight
1177.14|5.31|matrices at the same at every time step
1179.169|6.25|and so we just back prop into them over
1182.45|5.34|time and that gives us the gradients and
1185.419|3.101|then we can use that in loss function
1187.79|2.92|perform the parameter
1188.52|4.11|date and then here we have finally a
1190.71|3.3|sampling function so here is where we
1192.63|3.33|try to actually get the art and to
1194.01|3.24|generate new text data based on what it
1195.96|3.06|has seen in a trainee dia and based on
1197.25|2.94|the statistics of the characters and how
1199.02|3.06|they follow each other in the training
1200.19|3.989|data so we initialize with some random
1202.08|4.68|character and then we go for until we
1204.179|4.081|get tired and we compute the recurrence
1206.76|4.23|formula get the probability distribution
1208.26|5.16|sample from that distribution re-encoded
1210.99|5.16|in one a hot k-11 heart representation
1213.42|4.65|and then we feed it in the next time
1216.15|6.18|step so we keep iterating this until we
1218.07|6.42|actually get a bunch of text so is there
1222.33|22.11|any question over just like the rough
1224.49|34.5|layout of how this works good that's
1244.44|17.67|right yeah that's right exactly so we
1258.99|5.1|have basically 25 softmax classifiers at
1262.11|3.51|every batch and we back drop all of
1264.09|2.52|those at the same time and they'll all
1265.62|6.8|add up in the connections going
1266.61|5.81|backwards that's right okay good
1274.26|4.65|do we use regularization here you'll see
1276.36|4.949|that I probably do not yeah I guess I
1278.91|4.17|skipped it here but you can in general I
1281.309|3.301|think sometimes I tried regularization
1283.08|3.06|and I don't think it's as common to use
1284.61|4.26|it in recurrent Nets as outside
1286.14|4.59|sometimes it gave me like worst results
1288.87|6.11|so sometimes I skip it but it's kind of
1290.73|4.25|a high parameter good
1298.179|9.851|yeah that's right so yeah that's right
1305.33|4.56|so in the sequence of 25 characters here
1308.03|3.42|we are very low level on character level
1309.89|3.57|and we don't actually care about words
1311.45|4.65|we don't know that words exist as just
1313.46|3.78|characters indices so this RNN in fact
1316.1|2.19|doesn't know anything about characters
1317.24|2.67|or language or anything like that it's
1318.29|3.96|just indices and sequences of indices
1319.91|11.49|and that's what we're modeling
1322.25|11.01|yeah good can we use spaces as the
1331.4|3.96|limiters or something like that instead
1333.26|4.89|of just constant batches of 25 I think
1335.36|4.62|he maybe could but then it kind of just
1338.15|3.81|you have to make assumptions about
1339.98|3.329|language we'll see soon why you wouldn't
1341.96|2.67|actually want to do that because you can
1343.309|2.521|plug anything into this and we'll see
1344.63|4.919|that we can have a lot of fun with that
1345.83|5.49|okay so let me show you now what we can
1349.549|3.031|do we can take a whole bunch of text we
1351.32|2.88|don't care where it came from is just a
1352.58|3.51|sequence of characters and we feed it
1354.2|5.67|into the RNN and we can train the Arnon
1356.09|5.28|to create text like it and so for
1359.87|3.72|example you can take all of William
1361.37|3.99|Shakespeare's works you can calculate
1363.59|3.42|all of it it's just a giant sequence of
1365.36|2.85|characters and you put it into the
1367.01|2.549|recurrent neural network and you try to
1368.21|3.06|predict the next character in a sequence
1369.559|3.511|for William Shakespeare proponents and
1371.27|3.33|so when you do this of course in the
1373.07|3.63|beginning the recurrent neural network
1374.6|3.66|has random random parameters so it's
1376.7|5.04|just producing a garble at the very end
1378.26|4.919|so it's just random characters but that
1381.74|2.85|when you train the RNN we'll start to
1383.179|3.481|understand that okay there are actually
1384.59|5.04|things like spaces there's words it
1386.66|4.32|starts to experiment with quotes it and
1389.63|4.799|it basically learned some of the very
1390.98|5.28|short words like here or on and so on
1394.429|3.24|and then as you train more and more this
1396.26|2.789|just becomes more and more refined and
1397.669|2.76|difficult Network learns that when you
1399.049|4.081|open a quote you should close it later
1400.429|4.62|or that the sentences end with a cut
1403.13|3.539|with a dot it learns all of this stuff
1405.049|3.12|statistically just from the raw patterns
1406.669|3.211|without actually having to hand code
1408.169|3.481|anything and in the end you can sample
1409.88|3.66|entire infinite Shakespeare based on
1411.65|2.909|this on a character level so just to
1413.54|4.019|give you an idea about what kind of
1414.559|4.171|stuff comes out alas I think he shall
1417.559|3.421|become approached and the dameWare
1418.73|3.99|little strain would be attained into
1420.98|3.39|being never fed and who is but the chain
1422.72|3.0|and subject of his death I should not
1424.37|2.88|sleep
1425.72|5.03|this is the kind of stuff that you would
1427.25|3.5|get out of this recurrent Network good
1435.13|3.91|yeah thank you so you are bringing up a
1437.36|5.76|very subtle point which I'd like to get
1439.04|5.49|back to in a bit yeah okay so we can run
1443.12|3.21|this on Shakespeare but we can run this
1444.53|3.15|on basically anything so we were playing
1446.33|3.66|with this with Justin I think like
1447.68|4.08|roughly a year ago and so Justin took he
1449.99|3.93|found this book on algebraic geometry
1451.76|4.98|and this is just a large latex source
1453.92|4.35|file and we took that latex source file
1456.74|3.18|for this algebra geometry and fed it
1458.27|5.25|into the RN N and the RN can learn to
1459.92|5.4|basically generate mathematics so this
1463.52|3.99|is a sample so basically this Ireland
1465.32|3.03|just spits out latex and then we compile
1467.51|3.12|it and of course it doesn't work right
1468.35|4.32|away we had to tune it a tiny bit but
1470.63|3.12|basically the Ireland after we tweaked
1472.67|2.28|some of the mistakes that it has made
1473.75|3.18|you can compile it and you can get
1474.95|3.18|generated mathematics and so you'll see
1476.93|4.28|that it basically creates all these
1478.13|5.3|proofs it puts it learn stupid little
1481.21|7.21|squares at the ends of proofs
1483.43|6.88|it creates lemmas it and so on sometimes
1488.42|6.06|the RN also tries to create diagrams to
1490.31|5.43|varying amounts of success a my best my
1494.48|4.83|favorite part about this is that on the
1495.74|7.56|top left the proof here it's emitted
1499.31|5.7|the Sarna was just lazy but otherwise
1503.3|3.57|this this stuff is quite
1505.01|5.94|indistinguishable I would say from from
1506.87|5.7|actual algebraic geometry so let X be ml
1510.95|4.05|0 scheme of X okay I'm not sure about
1512.57|3.84|that part but otherwise the Gestalt of
1515.0|3.0|this looks very good so you can throw
1516.41|3.27|arbitrary things at it so I try to find
1518.0|3.06|the hardest arbitrary thing that I could
1519.68|2.88|throw at the character level RN I
1521.06|3.78|decided that source code is actually
1522.56|5.22|very difficult so I took all of Linux
1524.84|4.65|source which is just all the like C code
1527.78|3.57|you concatenate it and you end up with I
1529.49|3.66|think 700 megabytes of just C code and
1531.35|3.96|header files and then you just throw it
1533.15|4.44|into the Armen and then it can learn to
1535.31|4.89|generate code and so this is generated
1537.59|3.9|code from the Arnon and you can see that
1540.2|2.67|basically it creates function
1541.49|3.39|declarations it knows about inputs
1542.87|4.44|syntactically it makes very few mistakes
1544.88|4.29|it knows about variables and sort of how
1547.31|5.54|to use them sometimes it indents the
1549.17|3.68|code it creates its own bogus comments
1553.06|4.51|like syntactically it's very rare to
1555.44|3.54|find that it would open a bracket and
1557.57|2.82|not close it and so on this actually is
1558.98|3.39|relatively easy for the Ireland to learn
1560.39|3.39|and so some of the mistakes that it
1562.37|3.06|makes actually is that for example it
1563.78|3.45|declares some variables that it never
1565.43|3.3|ends up using or it uses some variables
1567.23|2.76|that it never declared and so some of
1568.73|3.48|this high-level stuff is still missing
1569.99|5.67|but otherwise it can do code just fine
1572.21|5.88|it also knows how to recite the GNU GPL
1575.66|4.77|license character by character that has
1578.09|4.08|learned from data and it knows that
1580.43|3.6|after the GNU GPL license there are some
1582.17|3.57|include files there's some macros and
1584.03|6.9|then there's some code so that's
1585.74|7.32|basically what it has learned good yeah
1590.93|4.74|so am intended just I shown you is very
1593.06|4.11|small just a toy thing to show you
1595.67|3.12|what's going on then there's a charm and
1597.17|3.72|which is a more kind of a maturing
1598.79|3.87|plantasia and torch which is just mint
1600.89|3.39|charred and scaled up and runs on GPU
1602.66|4.05|and so you can play with that yourself
1604.28|4.17|and so this in particular was a will go
1606.71|3.87|into this by the end lecture it's a
1608.45|3.63|three layer lsdm and so we'll see what
1610.58|3.92|that means it's a more complex kind of
1612.08|4.29|form of a recurrent neural network okay
1614.5|4.33|just to give you an idea about how this
1616.37|3.93|works so this is from a paper that we
1618.83|3.15|play with a lot with this with just in
1620.3|3.9|last year and we were basically trying
1621.98|5.22|to pretend that we're neuro scientists
1624.2|6.18|and we you through a careful level RNN
1627.2|5.39|on some test text and so the arm is
1630.38|3.71|reading this text in the snippet of code
1632.59|3.39|we're looking at a specific cell in the
1634.09|3.209|hidden state of the arlynn or coloring
1635.98|5.01|the text based on whether or not that
1637.299|5.73|cell is excited or not okay so you can
1640.99|4.289|see that many of the hidden state
1643.029|3.811|neurons are not very interpretable they
1645.279|2.791|kind of fire on enough in kind of weird
1646.84|2.67|ways because they have to do some of
1648.07|2.969|them have to do quite low-level
1649.51|3.45|character level stuff like how often
1651.039|3.331|does it come after H and stuff like that
1652.96|3.87|but some of the cells are quite
1654.37|4.71|interpretable so for example we find
1656.83|3.81|cells like a quote detection cell that
1659.08|3.599|this cell just turns on when it sees a
1660.64|4.95|quote and then it stays on until the
1662.679|4.171|quote closes and so this quite reliably
1665.59|4.199|keeps track of this and it just comes
1666.85|4.29|out from backpropagation the Ireland
1669.789|3.571|just decides that the character level
1671.14|3.419|statistics are different inside and
1673.36|3.27|outside of quotes and this is a useful
1674.559|3.391|feature to learn and so it dedicates
1676.63|2.519|some of its hidden states to keeping
1677.95|2.729|track of whether or not you're inside a
1679.149|2.851|quote and this goes back to your
1680.679|4.47|question which I wanted to point out
1682.0|5.37|here that this RNN was trained on I
1685.149|4.14|think a sequence length of 100 but if
1687.37|3.39|you measure the the length of this quote
1689.289|5.701|it's actually much more than 100 I think
1690.76|6.69|it's like 250 and so we worked on we
1694.99|3.9|only back replicated up to 100 and so
1697.45|3.449|that's the only place where this cell
1698.89|3.899|can actually like learn itself because
1700.899|3.721|it wouldn't be able to spot the pendants
1702.789|3.451|ease that are much longer than that but
1704.62|3.689|I think basically this seems to show
1706.24|4.439|that you can train this character level
1708.309|3.961|detection cell as useful on sequences
1710.679|5.191|less than 100 and then it generalizes
1712.27|5.399|properly to longer sequences so this so
1715.87|3.6|this cell seems to work for more than
1717.669|3.781|100 steps even if it was only trained
1719.47|5.37|even if it was only able to spot the
1721.45|4.8|dependencies on less than 100 this is
1724.84|3.9|another data set here this is I think
1726.25|3.84|Leo Tolstoy's war and peace this is in
1728.74|3.63|this data set there's a newline
1730.09|4.11|character at every single at roughly 80
1732.37|3.659|characters in so after every 80
1734.2|4.17|characters roughly there's a newline and
1736.029|4.471|there's a quote there's a line length
1738.37|4.38|tracking cell that we found where it
1740.5|4.919|starts off at like 1 and then it slowly
1742.75|4.08|decays over time and you might imagine
1745.419|2.73|that a cell like this is actually very
1746.83|3.089|useful in predicting that newline
1748.149|3.991|character at the end because this RNN
1749.919|3.75|needs to count 80 time steps so that it
1752.14|2.34|knows when a newline character is likely
1753.669|3.661|to come next
1754.48|4.62|okay so there's lung tracking tells we
1757.33|4.079|found cells that actually respond only
1759.1|4.079|if sight if statements we found cells
1761.409|4.891|that only respond inside quotes and
1763.179|4.831|strings we found cells that get more
1766.3|4.23|cited the deeper you nested expression
1768.01|4.74|and so all kinds of interesting cells
1770.53|3.69|that you can actually find inside these
1772.75|3.6|are ends that completely come out just
1774.22|9.96|from the backpropagation and so that's
1776.35|10.62|quite magical I suppose good yeah so so
1784.18|4.74|there's a sin this lsdm I think there
1786.97|5.31|were 2100 cells so you just kind of like
1788.92|3.81|go through them so most of them look
1792.28|2.13|like this
1792.73|3.03|but I would say roughly five percent of
1794.41|2.61|them you spot something interesting so
1795.76|6.57|you just go through it manually
1797.02|8.25|oh no sorry so we are completely running
1802.33|5.49|the entire RNN intact but we're only
1805.27|4.47|looking at a single hidden state fire
1807.82|4.5|the firing of one single cell in the
1809.74|4.71|Arnon so running the RNN normally but
1812.32|4.02|we're just kind of a recording from one
1814.45|6.63|cell in the hidden state if that makes
1816.34|6.12|sense so this cell just the entire RNN
1821.08|2.82|I'm only visualizing one part of the
1822.46|3.21|hidden state basically there's many
1823.9|3.81|other hidden still hidden cells that
1825.67|3.84|evolved in different ways and they're
1827.71|2.58|all evolving in different times and
1829.51|6.29|they're all doing different things
1830.29|5.51|inside the iron and hidden state good
1841.26|3.91|we'll go into are you asking about
1843.13|3.75|multi-layer RNAs and so on we'll go into
1845.17|3.63|that in a bit this is I think
1846.88|7.29|multi-layer RNN but you can get similar
1848.8|6.99|results with one layer good yes so these
1854.17|2.7|hidden state these hidden cells were
1855.79|4.29|always between negative one and one
1856.87|4.89|they're an output of at NH and this is
1860.08|3.75|from an LS TM which we haven't covered
1861.76|3.18|yet but the firing of these cells is
1863.83|3.51|between negative on and one so that's
1864.94|4.1|the scale that sets this picture okay
1867.34|4.95|cool
1869.04|4.63|okay so our NS are pretty cool and you
1872.29|3.92|can actually train these sequence models
1873.67|4.59|over time about roughly one year ago
1876.21|3.13|several people have kind of realized
1878.26|2.46|that you can actually is this a very
1879.34|2.88|neat application in the context of
1880.72|3.27|computer vision to perform image
1882.22|2.97|captioning so in this context we're
1883.99|2.64|taking a single image and we'd like to
1885.19|2.61|describe it with a sequence of words and
1886.63|3.36|these are nuns are very good at
1887.8|4.62|understanding how sequences develop over
1889.99|3.66|time so in this particular model that
1892.42|3.6|I'm going to describe this is actually
1893.65|5.43|work from roughly a year ago happens to
1896.02|6.03|be my paper I have I have pictures from
1899.08|5.97|my paper so I'm going to use those so
1902.05|4.26|we're feeling accomplished on an image
1905.05|2.64|into a convolutional neural network and
1906.31|2.64|then you'll see that this full model is
1907.69|2.1|actually just made up of two modules
1908.95|1.98|there's the ComNet
1909.79|2.49|that is doing the processing of the
1910.93|3.03|image and there's a recurrent net which
1912.28|3.54|will be very which is very good with
1913.96|3.15|modeling sequences and so if you
1915.82|2.61|remember my analogy from the very
1917.11|2.52|beginning of the course where this is
1918.43|2.58|kind of like playing with Lego blocks
1919.63|3.06|we're going to take those two modules
1921.01|3.48|and stick them together that corresponds
1922.69|2.97|to the arrow in between and so what
1924.49|3.33|we're doing effectively here is we're
1925.66|3.93|conditioning this RNN generated model
1927.82|3.51|we're not just telling it sample text at
1929.59|3.66|random but we're conditioning that
1931.33|3.27|generative process by the output of the
1933.25|4.62|convolutional Network and I'll show you
1934.6|5.73|exactly how that looks like so suppose
1937.87|4.41|I'm just going to show you what the the
1940.33|3.24|forward pass of the neural net is so
1942.28|2.85|suppose we have a test image and we're
1943.57|3.18|trying to describe it with a sequence of
1945.13|3.6|words so the way this model would
1946.75|3.12|process the image is as follows we take
1948.73|2.52|that image and we plug it into a
1949.87|3.6|convolutional neural network in this
1951.25|3.84|case this is a vgg net so we go through
1953.47|4.38|a whole bunch of cough max pool and so
1955.09|3.99|on until we arrive at the end normally
1957.85|2.34|at the end we have this soft mask
1959.08|3.33|classifier which is giving you a
1960.19|4.08|property distribution over say 1,000
1962.41|3.12|categories of imagenet in this case
1964.27|3.09|we're going to actually get rid of that
1965.53|3.36|classifier and instead we're going to
1967.36|3.0|redirect the representation at the top
1968.89|3.51|of the convolutional Network into the
1970.36|3.79|recurrent neural network so we begin to
1972.4|5.59|generation of the Arnon with
1974.15|5.88|special start vector so the input to
1977.99|3.93|this RNN was I think 300 dimensional and
1980.03|3.12|this is a special 300 dimensional vector
1981.92|2.85|that we always plug in at the first
1983.15|3.69|iteration tells the Ireland that this is
1984.77|3.42|the beginning of the sequence and then
1986.84|2.63|we're going to perform the recurrence
1988.19|3.99|formula that I've shown you before for
1989.47|4.27|vanilla recurrent neural network so
1992.18|3.33|normally we compute this recurrence
1993.74|4.8|which we've saw already where we compute
1995.51|4.5|wxh times x plus whh times h and now we
1998.54|4.59|want to additionally condition this
2000.01|5.46|recurrent neural network not only on the
2003.13|3.99|current input and the current hidden
2005.47|3.06|state which we initialize with zero so
2007.12|3.6|that term goes away at the first time
2008.53|6.3|step but we additionally condition just
2010.72|5.79|by adding wi h times V and so this V is
2014.83|3.54|the top of the comment here and we
2016.51|4.77|basically this added interactions added
2018.37|5.19|weight matrix W which tells us how this
2021.28|3.48|image information merges into the very
2023.56|2.76|first time step of the recurrent neural
2024.76|2.82|network now there are many ways to
2026.32|2.58|actually play with this recurrence in
2027.58|2.76|many ways to actually plug in the image
2028.9|2.73|into there are n N and this is only one
2030.34|3.45|of them and one of the simpler ones
2031.63|4.38|perhaps and at the very first time step
2033.79|5.49|here this Y 0 vector is the distribution
2036.01|4.89|over the first word in a sequence so the
2039.28|5.34|way this works you might imagine for
2040.9|5.79|example is you can see that these straw
2044.62|3.72|textures in a mass hat can be recognized
2046.69|3.239|by the convolutional network as a straw
2048.34|3.66|like stuff and then through this
2049.929|3.48|interaction WI H it might condition the
2052.0|3.51|hidden state to go into a particular
2053.409|4.801|state where the probability of the word
2055.51|3.899|straw could be slightly higher right so
2058.21|2.699|you might imagine that the straw like
2059.409|3.301|textures can influence the probability
2060.909|3.451|of straw so one of the numbers inside y
2062.71|3.51|0 to be higher because there are straw
2064.36|3.66|textures in there and so the Ireland
2066.22|3.33|from now on has to kind of juggle two
2068.02|3.75|tasks it has to predict the next
2069.55|3.629|character in the sequence in this case
2071.77|3.36|and it has to remember the image
2073.179|4.5|information so we sample from that
2075.13|4.65|softmax and supposedly that the most
2077.679|3.931|likely word that we sampled from that
2079.78|4.26|distribution was indeed the word straw
2081.61|3.63|we would take straw and we would try to
2084.04|3.0|plug it into the recurrent neural
2085.24|3.419|network on the bottom again and so in
2087.04|4.35|this case I think we were using word
2088.659|4.651|level embeddings so the straw straw word
2091.39|3.39|is associated with a 300 national vector
2093.31|3.21|which we're going to learn we're going
2094.78|3.54|to learn a 300 emotional representation
2096.52|3.87|for every single unique word in the
2098.32|3.42|vocabulary and we plug in those 300
2100.39|2.73|numbers into the RNN and forward it
2101.74|4.29|again to get a distribution over the
2103.12|4.32|second word in the sequence inside y1 so
2106.03|2.04|we get all these probabilities we sample
2107.44|2.58|from it again
2108.07|3.9|suppose that the word hat is likely now
2110.02|4.23|we take hats 300 dimensional
2111.97|4.29|representation plug it in and get the
2114.25|4.17|distribution over there and then we
2116.26|3.99|sample again and we sample until we
2118.42|2.94|sample a special end token which is
2120.25|2.85|really the period at the end of the
2121.36|3.54|sentence and that tells us that the
2123.1|2.97|Arnon is now done generating and at this
2124.9|5.04|point the ironman would have described
2126.07|5.97|this image as a straw hat period okay so
2129.94|4.11|the number of dimensions in this Y
2132.04|4.26|vector is the number of words in your
2134.05|4.98|vocabulary plus one for the special end
2136.3|5.13|token and we are always feeding in these
2139.03|3.66|300 dimensional vectors that correspond
2141.43|3.15|to different words and a special start
2142.69|3.33|token and then we always just back
2144.58|3.12|propagate through the whole thing at a
2146.02|3.27|single time so you initialize this at
2147.7|2.94|random or you can initialize your vgg
2149.29|3.9|net with pre-trained from internet and
2150.64|3.78|then the recurrent neural networks tell
2153.19|2.64|you the distributions and then you
2154.42|3.3|encode the gradient and then you back
2155.83|2.85|drop through the whole thing as a single
2157.72|3.21|model and you just train that all
2158.68|8.88|jointly and you get a captioner image
2160.93|7.73|capture lots of questions okay good yes
2167.56|3.99|these three hundred dimensional
2168.66|4.51|embeddings are they're just independent
2171.55|5.43|of the image so every word has 300
2173.17|5.31|numbers associated with it so we're
2176.98|3.21|going to back propagate into it so you
2178.48|3.18|initialize it random and then you can
2180.19|2.91|back propagate into these vectors X
2181.66|3.66|right so those embeddings will shift
2183.1|4.02|around they're just a parameter another
2185.32|3.84|way to think about it is it's in fact
2187.12|3.84|equivalent to having a one hot
2189.16|4.2|representation for all the words and
2190.96|5.13|then you have a giant W matrix where
2193.36|4.98|every single you multiply W with that
2196.09|4.92|one hot representation and if that W has
2198.34|4.74|300 output size then it's effectively
2201.01|3.48|plucking out a single row of W which
2203.08|3.66|ends up being your embedding so it's
2204.49|3.54|kind of equivalent so just think of it
2206.74|2.7|if you don't like those embeddings just
2208.03|3.21|think of it as a one hot representation
2209.44|5.88|and you can think of it that way go
2211.24|7.83|ahead yes the model learns to up at the
2215.32|6.03|end token yes so in the training data
2219.07|4.02|the correct sequence that we expect from
2221.35|4.05|the RN is the first word second or third
2223.09|5.07|word end so every single training
2225.4|6.25|example will sort of have a special n
2228.16|5.89|token in it go ahead
2231.65|5.1|h2r you again receiving the same output
2234.05|4.56|from the ABG net or are you asking like
2236.75|3.99|it twice yeah thank you so the question
2238.61|3.45|is like where so in this example we're
2240.74|2.13|only plugging in the image at the very
2242.06|2.79|first time step
2242.87|3.6|we're not plugging it in the other time
2244.85|3.0|steps you can wire this up differently
2246.47|2.76|where you plug it into every single
2247.85|4.32|state it turns out that that actually
2249.23|4.17|works worse so it actually works better
2252.17|2.94|if you just plug it in the very first
2253.4|3.42|time step and then the Arnon has to
2255.11|3.33|juggle these both tasks it has to
2256.82|4.14|remember about the image what it needs
2258.44|3.84|to remember through the RNN and it also
2260.96|4.35|has to produce all these outputs and
2262.28|4.23|somehow it wants to do that there's some
2265.31|4.53|hand waving reasons I can give you after
2266.51|5.48|class for what that's true you just have
2269.84|4.41|to basically be careful enjoy the
2271.99|3.97|confident output when you give it the
2274.25|4.14|start okay and then give it the
2275.96|4.08|subsequent tokens in the labels and in
2278.39|3.48|the end token into the next generation
2280.04|5.85|the next current event I think you're
2281.87|6.06|kind of not quite so at training time a
2285.89|4.32|single instance will correspond to an
2287.93|4.26|image and a sequence of words and so we
2290.21|5.97|would plug in those words here and we
2292.19|8.19|will plug in that image and we yes so
2296.18|5.52|like um so you see it training time you
2300.38|2.37|have all those words plugged in on the
2301.7|3.09|bottom and you have the image plugged in
2302.75|3.39|and then you unroll this graph and you
2304.79|3.36|have your losses and your backdrop and
2306.14|3.78|then you can do batches of images if
2308.15|3.36|you're careful and so if you have
2309.92|3.21|batches of images they sometimes have
2311.51|2.79|different length sequences in the
2313.13|2.73|training data you have to be careful
2314.3|3.18|with that because you have to say that
2315.86|4.89|okay I'm willing to process batches of
2317.48|4.65|up to you know 20 words maybe and then
2320.75|2.7|some of those sentences will be shorter
2322.13|3.84|and longer and you need to in your code
2323.45|4.26|you know worry about that because some
2325.97|5.07|some some sentences are longer than
2327.71|13.17|others we have way too many questions I
2331.04|11.34|have stuff too good yeah thank you so we
2340.88|3.96|back propagate everything completely
2342.38|4.71|jointly end-to-end training so you can
2344.84|3.54|pre train with a imagenet and then you
2347.09|2.67|put those ways there but then you just
2348.38|4.95|want to train everything jointly and
2349.76|4.89|that's a big advantage actually because
2353.33|2.82|we can we can figure out what features
2354.65|5.22|to look for in order to better describe
2356.15|5.61|the images at the end okay so when you
2359.87|3.48|train this in practice we train this on
2361.76|3.28|image sentence datasets one of the more
2363.35|3.46|common ones is called Microsoft cocoa
2365.04|2.73|so just to give you an idea of what it
2366.81|2.52|looks like it's roughly a hundred
2367.77|3.72|thousand images and five sentence
2369.33|4.02|descriptions for each image these were
2371.49|3.81|obtained using Amazon Mechanical Turk so
2373.35|3.66|you just ask people please give us a
2375.3|3.15|census description for an image and you
2377.01|3.51|record all of it and then that's your
2378.45|3.78|data set and so when you train this
2380.52|5.01|model the kinds of results that you can
2382.23|6.03|expect or roughly what is kind of like
2385.53|4.53|this so this is our end describing these
2388.26|3.21|images so this it says that this is a
2390.06|3.21|man in black shirt playing guitar or
2391.47|3.75|construction worker in orange safety
2393.27|3.93|west working on the road or two young
2395.22|4.32|girls are playing with Lego toy or boy
2397.2|4.05|is doing backflip on the wakeboard and
2399.54|3.48|of course that's not a wakeboard but
2401.25|3.9|it's close there are also some very
2403.02|3.81|funny failure cases which I also like to
2405.15|4.44|show this is a young boy holding a
2406.83|4.95|baseball bat this is a cat staying on
2409.59|3.81|the couch with the remote control that's
2411.78|8.31|a woman holding a teddy bear in front of
2413.4|8.37|a mirror I'm pretty sure that the
2420.09|2.91|texture here probably is what what
2421.77|3.99|happened made it think that it's a teddy
2423.0|3.99|bear and the last one is a horse
2425.76|3.45|standing in the middle of a street
2426.99|3.66|there's Road so there's no horse
2429.21|5.01|obviously so I'm not sure what happened
2430.65|5.04|there so this is just a simplest kind of
2434.22|2.85|model that came out last year there were
2435.69|2.55|many people who try to work on top of
2437.07|2.7|these kinds of models and make them more
2438.24|3.72|complex I just like to give you an idea
2439.77|4.14|of one one model that is interesting
2441.96|4.08|just to get an idea of how people play
2443.91|6.09|with this basic architecture so this is
2446.04|5.43|a paper from last year where if you
2450.0|3.48|noticed in the current model we only
2451.47|4.5|feed in the image a single x time at the
2453.48|3.75|beginning and one way you can play with
2455.97|3.48|this is that you can actually around the
2457.23|4.05|recurrent neural network to look back to
2459.45|4.2|the image and reference parts of the
2461.28|4.26|image while it's describing the words
2463.65|3.87|so as you're generating every single
2465.54|3.9|word you allow the arlynn to actually
2467.52|3.27|make a lookup back to the image and look
2469.44|3.12|for different features of what it might
2470.79|3.06|want to describe next and you can
2472.56|3.48|actually do this in a fully trainable
2473.85|4.47|way so the RNN not only creates these
2476.04|4.08|words but also decides where to look
2478.32|3.81|next in the image and so the way this
2480.12|3.66|works is not only does the RNN output
2482.13|3.69|your property distribution of the next
2483.78|4.62|word in a sequence but this comb that
2485.82|4.2|gives you this volume so say in this
2488.4|7.47|case we forwarded the ComNet and got a
2490.02|8.25|14 by 14 by 512 by 512 activation volume
2495.87|2.97|and at every single time step you don't
2498.27|2.97|just omit that
2498.84|4.86|distribution but you also emit a 512
2501.24|4.35|dimensional vector that is kind of like
2503.7|3.99|a lookup key of what you want to look
2505.59|3.15|for next in the image and so actually I
2507.69|2.91|don't think this is what they did in the
2508.74|2.97|in this particular paper but this is one
2510.6|2.88|way you could wire something like this
2511.71|3.69|up and so this vector is emitted from
2513.48|3.78|the RNN just like a rip it's just
2515.4|3.6|predicted using some weights and then
2517.26|5.4|this vector can be dot producted with
2519.0|5.46|all these 14 by 14 locations so we do
2522.66|4.19|all these dot products and we achieve or
2524.46|5.13|we compute basically a 14 by 14
2526.85|5.44|compatibility map and then we put a soft
2529.59|4.62|max on this so basically we normalize
2532.29|3.66|all this so that it's all you get this
2534.21|4.17|what we call an attention over the image
2535.95|3.99|so it's a 14 by 14 probability map over
2538.38|3.66|what's interesting for the Arnon right
2539.94|4.2|now in the image and then we use this
2542.04|5.46|probability mask to do a weighted sum of
2544.14|4.74|these guys with this saliency and so
2547.5|3.39|this ironin can basically emit these
2548.88|4.71|vectors of what it thinks is currently
2550.89|4.74|interesting for it and it goes back and
2553.59|3.63|you end up doing a weighted sum of
2555.63|3.33|different kinds of features that the
2557.22|4.11|lsdm wants to or the RNN wants to look
2558.96|5.16|at at this point in time and so for
2561.33|4.2|example the ireland's generating stuff
2564.12|3.99|and it might decide that ok i'd like to
2565.53|4.8|look for something object like now it
2568.11|4.29|emits a vector of 512 numbers of object
2570.33|3.99|like stuff it interacts with commnets
2572.4|4.59|with the cognate activation volume and
2574.32|4.26|maybe some of the object like regions of
2576.99|4.02|that combat of that activation volume
2578.58|5.31|like light up in the saline c map in
2581.01|3.99|this 14 by 14 array and then you just
2583.89|3.15|end up basically focusing your attention
2585.0|4.23|on that part of the image through this
2587.04|4.23|interaction and so you can basically
2589.23|4.32|just do lookups into the image while
2591.27|3.78|you're describing the sentence and so
2593.55|2.97|this is something we refer to as soft
2595.05|3.15|attention and will actually go into this
2596.52|3.45|in a few lectures so we'll go into a
2598.2|3.21|couple of cover things like this where
2599.97|2.82|the RNN can actually have selective
2601.41|5.43|attention over its inputs as its
2602.79|5.7|processing the input and so that's so I
2606.84|3.12|just wanted to bring it up roughly now
2608.49|4.56|just to give you a preview of what that
2609.96|4.74|looks like okay now if we want to make
2613.05|3.33|our lens more complex one of the ways we
2614.7|4.5|can do that is to stack them up in
2616.38|5.55|layers so this gives you you know more
2619.2|4.35|deep stuff usually works better so the
2621.93|2.76|way we stack this up one of the ways at
2623.55|3.21|least you can stack recurrent neural
2624.69|3.72|networks and there's many ways but this
2626.76|3.18|is just one of them that people use in
2628.41|3.6|practice is you can straight up just
2629.94|4.26|plug RNs in to each other
2632.01|4.89|so the input for one Arnon is the hidden
2634.2|4.74|is the vector of the hidden state vector
2636.9|3.69|of the previous Arnon so in this image
2638.94|3.78|we have the time axis going horizontally
2640.59|3.9|and then going upwards we have different
2642.72|3.21|Arlen's and so in this particular image
2644.49|3.09|there are three separate recurrent
2645.93|3.81|neural networks each with their own set
2647.58|3.72|of weights and these your current neural
2649.74|5.88|networks are just feed into each other
2651.3|5.61|okay and so this is all always trained
2655.62|2.46|jointly there's no train first one
2656.91|2.43|second third one that's all just a
2658.08|3.15|single computational graph that way back
2659.34|4.23|propagate through now this recurrence
2661.23|3.99|formula at the top it I've rewritten it
2663.57|3.06|slightly to make it more general well
2665.22|2.7|still we're still doing the exact same
2666.63|3.83|thing as we did before this is the same
2667.92|5.58|formula we're taking a vector from below
2670.46|5.74|in below in depth and a vector from
2673.5|4.2|before in time we're concatenating them
2676.2|3.63|and putting them putting them through
2677.7|4.11|this W transformation and it's washing
2679.83|3.75|them at the 10 H so if you remember if
2681.81|5.1|you are slightly confused about this
2683.58|6.99|there's there was a WX h times x plus w
2686.91|5.73|h h times H you can rewrite this as a
2690.57|4.53|concatenation of X and H multiplied by a
2692.64|5.28|single matrix right so it's as if I
2695.1|6.08|stacked X and H into a single column
2697.92|5.85|vector and then I have this W matrix
2701.18|4.78|where basically what ends up happening
2703.77|4.74|is that your WX H is the first part of
2705.96|5.82|this matrix and wh h is the second part
2708.51|5.31|of your matrix and so this kind of
2711.78|3.54|formula can be rewritten into a formula
2713.82|4.05|where you stack all your inputs and you
2715.32|8.67|have a single W transformation so the
2717.87|8.58|same formula ok so that's how we can
2723.99|4.83|stack these our nets and then they're
2726.45|5.19|now indexed by both time and by lawyer
2728.82|4.26|at which they occur now one way we can
2731.64|2.97|also make these more complex is not just
2733.08|3.54|by stacking them but by actually using a
2734.61|3.6|slightly better recurrence formula so
2736.62|2.73|right now so far we've seen this very
2738.21|2.58|simple recurrence formula for the
2739.35|3.39|vanilla recurrent neural network in
2740.79|4.17|practice you will actually rarely ever
2742.74|3.93|use formula like this a basic recurrent
2744.96|3.96|network is very rarely used instead
2746.67|3.96|you'll use what we call an LS TM or a
2748.92|4.11|long short term memory so this is
2750.63|4.56|basically used in all the papers now so
2753.03|3.6|this is the the formula you'd be using
2755.19|3.21|also in your projects if you were to use
2756.63|3.15|your curt neural networks what I'd like
2758.4|3.78|you to notice at this point is it's
2759.78|4.41|everything is exactly the same as with a
2762.18|3.48|narnun it's just that the recurrence
2764.19|3.45|formula is a slightly more complex
2765.66|4.56|function okay we're still taking the
2767.64|4.74|hidden vector from below in depth like
2770.22|3.569|your input and from before in time the
2772.38|2.489|previous sentence Tate we're
2773.789|4.5|concatenating them putting them through
2774.869|5.22|aw transform but now we have this more
2778.289|3.57|complexity in how we actually achieve
2780.089|3.96|the new hidden state at this point in
2781.859|3.571|time so we're just being a slightly more
2784.049|2.611|complex in how we combine the vector
2785.43|2.7|from below and before to actually
2786.66|3.54|perform the update of the hidden state
2788.13|3.659|it's just a more complex formula so
2790.2|3.359|we'll go into some of the details of
2791.789|3.3|exactly what motivates this formula and
2793.559|2.821|why it might be a better idea to
2795.089|7.681|actually use an awesome instead of
2796.38|8.52|narnun good yeah you'll see Sigma's and
2802.77|3.36|ten age and it makes sense trust me
2804.9|7.01|we'll go through it just click right now
2806.13|7.949|mm-hmm so if you look for lsdm online
2811.91|3.52|you can look for lsdm when you go in
2814.079|3.301|Wikipedia or you go to Google Images
2815.43|4.679|you'll find diagrams like this which is
2817.38|4.05|really not helping I think anyone the
2820.109|2.76|first time I saw a Les Dames day really
2821.43|3.71|scared me like this one really scared me
2822.869|4.081|I wasn't really sure what's going on I
2825.14|3.01|understand Ellis themes and I still
2826.95|5.55|don't know what these two diagrams are
2828.15|6.3|so okay so I'm going to try to break
2832.5|3.599|down lsdm it's kind of a tricky thing to
2834.45|3.78|put into a diagram you really have to
2836.099|4.46|kind of step through it so lecture
2838.23|5.339|format is perfect for analysts in okay
2840.559|4.691|so here we have the ellis team equations
2843.569|3.631|and I'm going to first focus on the
2845.25|3.75|first part here on the top where we take
2847.2|4.47|these two vectors from below and from
2849.0|4.89|before so x and h HS are previous in a
2851.67|4.71|state and X is Dean but we map them
2853.89|4.53|through that transformation W and now if
2856.38|3.57|both X and H are of size n so there's n
2858.42|3.659|numbers in them we're going to end up
2859.95|5.849|producing for n numbers okay through
2862.079|6.091|this W matrix which is for n by 2n so we
2865.799|4.951|have these four n dimensional vectors i
2868.17|4.859|F oMG they're short for input forget
2870.75|5.97|output and gee I'm not sure what that's
2873.029|5.55|short for it's just G and so the ifnl go
2876.72|7.859|through sigmoid gates and G goes through
2878.579|7.47|a 10 h gate now the way this let's see
2884.579|2.371|so the way this actually works the ellis
2886.049|2.581|tiem basically the best way to think
2886.95|2.909|about it is one thing I forgot to
2888.63|5.01|mention actually in the previous slide
2889.859|4.561|is normally recurrent neural network
2893.64|2.25|just has the single
2894.42|3.57|H vector at every single time step and
2895.89|3.06|lsdm actually has two vectors at every
2897.99|2.25|single time step
2898.95|4.29|the hiddenvector and this is what we
2900.24|4.44|call see the cell state vector so at
2903.24|5.55|every single time step we have both H
2904.68|5.64|and C in parallel and and the C vector
2908.79|3.24|here shown in yellow so we basically
2910.32|3.96|have two vectors every single point in
2912.03|4.02|space here and what else teams are doing
2914.28|4.62|is they're basically operating over this
2916.05|4.319|cell state so depending on what's before
2918.9|3.6|you and below you and that is your
2920.369|6.331|context you end up operating over the
2922.5|6.69|cell state with these I F + o + g
2926.7|4.139|elements and the way to think about it
2929.19|2.82|is I'm going to go through a lot of this
2930.839|2.431|ok
2932.01|4.5|so basically the way to think about this
2933.27|6.03|is think of I and O as just binary
2936.51|4.109|either 0 or 1 we want them to be we want
2939.3|3.21|them to have an interpretation of a gate
2940.619|4.321|like think of it as either zeros or ones
2942.51|3.18|we of course make them later sigmoids
2944.94|2.04|because we want this to be
2945.69|2.79|differentiable so that we can back
2946.98|3.69|propagate through everything but just
2948.48|3.92|think of ifnl as just binary things that
2950.67|4.199|we're computing based on our context and
2952.4|5.679|then what this formula is doing here see
2954.869|5.611|you can see that based on what these
2958.079|5.191|gates are and what G is we're going to
2960.48|4.53|end up updating this C value and in
2963.27|5.7|particular this F is called the forget
2965.01|6.839|gate that will be used to to shut a to
2968.97|5.01|reset some of the cells to zero so the
2971.849|4.321|cells are best thought of as counters
2973.98|4.26|and these counters basically we can
2976.17|3.57|either reset them to 0 with this F
2978.24|3.359|interaction this is a element-wise
2979.74|3.06|multiplication there I think my laser
2981.599|4.621|pointer is running out of battery
2982.8|5.25|that's unfortunate so with this F
2986.22|3.51|interaction if F is zero then you can
2988.05|3.72|see that will zero out a cell so we can
2989.73|4.08|reset the counter and then we can also
2991.77|5.19|add to a counter so we can add through
2993.81|3.96|this interaction I times G and since is
2996.96|4.23|between 0 & 1
2997.77|5.339|and G is between negative 1 and 1 we're
3001.19|4.5|basically adding a number between
3003.109|3.901|negative 1 and 1 to every cell so at
3005.69|3.48|every single time step we have these
3007.01|3.9|counters in all the cells we can reset
3009.17|3.81|these counters to 0 with the forget gate
3010.91|4.86|or we can choose to add a number between
3012.98|4.23|negative 1 and 1 to every single cell ok
3015.77|3.45|so that's how we perform the cell update
3017.21|5.79|and then the hidden update ends up being
3019.22|6.03|a squashed cell so 10 H of C squashed
3023.0|4.829|cell that is modulated by this output
3025.25|4.26|gate so only some of the cell state ends
3027.829|4.621|up leaking into the hidden state as
3029.51|3.3|modulated by this vector o so we only
3032.45|1.71|choose
3032.81|6.21|to reveal some of the cells into the
3034.16|6.18|hidden state in a learnable way there so
3039.02|3.33|there are several things to to kind of
3040.34|4.05|highlight here one maybe most confusing
3042.35|3.9|part here is that we're adding a number
3044.39|3.3|between negative 1 and 1 with I times G
3046.25|4.41|here but that's kind of confusing
3047.69|4.65|because if we only had a G there instead
3050.66|4.23|then G is already between negative 1 and
3052.34|4.5|1 so why do we need I times G what is
3054.89|3.57|that actually giving us when all we want
3056.84|4.17|is to increment a seed by a number
3058.46|4.2|between negative 1 and 1 and so that's
3061.01|5.52|kind of like a subtle part about an LCM
3062.66|8.01|I think one answer is that if you think
3066.53|7.62|about G it's a function of it's a linear
3070.67|5.1|function of your context no one has to
3074.15|2.1|it has layers a laser pointer by any
3075.77|5.79|chance right
3076.25|8.94|ok oh man ok so G is a function of your
3081.56|5.1|G goes through a 10 H okay
3085.19|3.42|so G is a linear function of your
3086.66|4.05|previous contacts squashed by 10 H and
3088.61|4.11|so if we were adding just G instead of I
3090.71|4.89|times G then that would be kind of like
3092.72|4.47|a very simple function so by adding this
3095.6|3.24|I and there and having multiplicative
3097.19|4.17|interaction you're actually getting more
3098.84|3.99|richer function that you can actually
3101.36|2.64|express in terms of what we're adding to
3102.83|4.26|our cell state as a function of the
3104.0|4.23|previous HS and another way to think
3107.09|3.51|about this is that we're basically
3108.23|3.96|decoupling these two concepts of how
3110.6|3.9|much do we want to add to a cell state
3112.19|4.86|which is G and then do we want to add to
3114.5|3.81|a cell state which is I so I is like do
3117.05|3.72|we actually want this operation to go
3118.31|4.53|through and G is what do we want to add
3120.77|3.81|and by decoupling these two that also
3122.84|3.39|may be dynamically has some nice
3124.58|5.76|properties in terms of how this lsdm
3126.23|5.43|trains but we just end up that's like
3130.34|2.64|the ostian formulas and I'm going to
3131.66|2.91|actually go through this in more detail
3132.98|5.46|as well but maybe I should go through it
3134.57|6.45|now okay so think about this as cells
3138.44|5.58|flowing through and now the first
3141.02|5.97|interaction here is the F dot C so F is
3144.02|5.4|an output of a sigmoid off of that and
3146.99|4.35|so F is basically gating your cells with
3149.42|4.35|a multiplicative interaction so if F is
3151.34|5.63|a zero you will shut off the cell and
3153.77|6.48|reset the counter this i times g part is
3156.97|5.58|basically giving you a camper as
3160.25|4.83|basically adding to the cell state and
3162.55|3.64|then the cell state leaks into the
3165.08|3.57|hidden state
3166.19|5.79|but it only leaks through 8nh and then
3168.65|5.31|that gets gated by oh so the oh oh
3171.98|3.48|vector can decide which parts of the
3173.96|3.599|cell state to actually reveal into the
3175.46|3.899|hidden hidden cell and then you'll
3177.559|3.691|notice that this hidden state not only
3179.359|4.111|goes to the next iteration of the lsdm
3181.25|4.769|but it also actually would flows up to
3183.47|3.72|higher layers because this is the hidden
3186.019|2.971|state vector that we actually end up
3187.19|4.379|plugging into further esteems above us
3188.99|4.049|or that goes into a prediction and so
3191.569|3.831|when you unroll this basically the way
3193.039|4.891|it looks like it's kind of like this
3195.4|3.909|which now I have a confusing diagram of
3197.93|4.8|my own that's I guess where we ended up
3199.309|5.22|with but you get your input vectors from
3202.73|4.5|below you have your hidden state from
3204.529|5.01|before the eight the xnh determine your
3207.23|4.559|gates fi GN oh they're all n dimensional
3209.539|4.141|vectors and then they end up modulating
3211.789|3.99|how you operate over the cell state and
3213.68|3.899|this self state can once you actually
3215.779|3.06|reset some counters and once you add
3217.579|3.361|numbers between negative one and one to
3218.839|3.99|your country's the cell state leaks out
3220.94|3.419|some of it leaks out in a learnable way
3222.829|3.091|and then it can either go up to the
3224.359|3.45|prediction or it can go to the next
3225.92|6.3|iteration of the LSD M going forward and
3227.809|9.03|so that's the so this looks ugly so
3232.22|5.97|we're going to so basically the question
3236.839|2.881|that's probably on your mind is why did
3238.19|3.569|we go through all of this there's
3239.72|3.629|something why does this look at this
3241.759|3.27|particular way I should like to note at
3243.349|3.541|this point that there are many variants
3245.029|3.631|to an LSD M and I'll make this point by
3246.89|3.119|the end of lecture people play a lot
3248.66|3.0|with these equations and we've kind of
3250.009|3.421|converged on this as being like a
3251.66|3.3|reasonable thing but there's many little
3253.43|2.76|tweaks you can make to this that
3254.96|3.27|actually don't deteriorate your
3256.19|3.51|performance by a lot you can remove some
3258.23|4.95|of those gates like maybe the input gate
3259.7|5.369|and so on you can turns out that this 10
3263.18|3.72|H of C that can be a C and it works just
3265.069|3.54|fine normally but with a 10 H of C its
3266.9|2.969|works slightly better sometimes and I
3268.609|5.16|don't think we have very good reasons
3269.869|5.131|for why and so you end up with a bit of
3273.769|2.85|a monster but I think it actually kind
3275.0|3.329|of makes sense in terms of just these
3276.619|2.67|counters that can be reset to zero or
3278.329|3.061|you can add small numbers between
3279.289|4.111|between negative 1 and 1 to them and so
3281.39|4.8|it's kind of like a nice it's actually
3283.4|4.32|relatively simple now to understand
3286.19|3.03|exactly why this is much better than an
3287.72|5.879|RN and we have to go to a slightly
3289.22|6.059|different picture to draw the
3293.599|3.72|distinction so the recurrent neural
3295.279|3.931|network it has some state vector right
3297.319|2.251|and you're operating over it and you're
3299.21|1.89|complete
3299.57|3.24|transforming it through this recurrence
3301.1|3.15|formula and so you end up changing your
3302.81|3.66|hidden state vector from time step to
3304.25|4.38|time stuff you'll notice that the LST M
3306.47|4.65|instead has these cell states flowing
3308.63|4.68|through and what we're doing effectively
3311.12|3.81|is we're looking at the cells and some
3313.31|2.76|of it leaks into the hidden state based
3314.93|3.24|on the hidden state we're deciding how
3316.07|3.54|to operate over the cell and if you
3318.17|4.29|ignore the forget gates then we end up
3319.61|6.72|basically just tweaking the cell by
3322.46|6.03|additive interaction here so so there's
3326.33|4.02|some stuff that look that is a function
3328.49|4.11|of the cell state and then whatever it
3330.35|3.81|is we end up additively changing the
3332.6|2.27|cell state instead of just transforming
3334.16|3.06|it right away
3334.87|5.38|so it's an additive instead of a
3337.22|4.32|transformative interaction or something
3340.25|3.18|like that now this should actually
3341.54|3.03|remind you of something that we've
3343.43|5.88|already covered in the class what does
3344.57|6.42|it remind you of resonance right yeah so
3349.31|3.93|in fact like this is basically the same
3350.99|3.21|thing as we saw with resonance so
3353.24|3.03|normally with the ComNet were
3354.2|3.45|transforming representation ResNet has
3356.27|3.6|these skipped connections here and
3357.65|4.2|you'll see that basically residents have
3359.87|4.53|this additive interaction so we have
3361.85|4.38|this X here now we do some computation
3364.4|5.85|based on X and then we have an additive
3366.23|5.46|interaction with X and so that's the
3370.25|2.85|basic block of a resonant and that's in
3371.69|3.17|fact what happens with an LS TM as well
3373.1|4.35|we have these additive interactions
3374.86|4.63|where here the X is basically your cell
3377.45|4.44|and we go off we do some function and
3379.49|4.65|then we choose to add to this cell state
3381.89|4.68|but the lsdm is unlike resonance have
3384.14|2.76|also these forget gates that we're
3386.57|2.07|adding
3386.9|3.27|and these forget gates can choose to
3388.64|3.72|shut off some parts of the signal as
3390.17|3.54|well but otherwise it looks very much
3392.36|2.64|like a resonance so I think it's kind of
3393.71|2.52|interesting that we're converging on
3395.0|2.55|very similar kind of looking
3396.23|3.24|architecture that works both in comm
3397.55|3.81|dots and in recurrent neural networks
3399.47|3.33|where it seems like dynamically somehow
3401.36|3.48|it's much nicer to actually have these
3402.8|4.92|additive interactions that allow you to
3404.84|5.88|actually back propagate much more
3407.72|5.37|effectively so to that point think about
3410.72|5.19|the back propagation dynamics between R
3413.09|4.17|and L SCM especially in the LS TM it's
3415.91|2.61|very clear that if i inject some
3417.26|3.24|gradient signal that sometimes that's
3418.52|3.9|here so if I inject gradient signal at
3420.5|3.33|the end of this diagram then these plus
3422.42|3.48|interactions are just like a gradient
3423.83|3.42|superhighway here right like these
3425.9|3.39|radians will just flow through all the
3427.25|3.48|adit ABS addition interactions right
3429.29|3.66|because addition distributes gradients
3430.73|3.48|equally so if I plug in gradient ne
3432.95|3.12|point in time here it's just going to
3434.21|3.27|flow all the way back and then of course
3436.07|3.9|the gradient also flows through these
3437.48|4.859|F's and they end up contributing their
3439.97|4.56|ingredients into the gradient flow but
3442.339|3.75|you'll never end up with what we
3444.53|3.12|referred to with our n ends problem
3446.089|4.351|called vanish ingredients where these
3447.65|4.41|gradients just die off go to zero as you
3450.44|2.28|back propagate through and I'll show you
3452.06|3.299|an example
3452.72|3.899|concretely of why this happens in vit so
3455.359|2.851|in an RNN we have this vanishing
3456.619|4.431|gradient problem I'll show you why that
3458.21|5.55|happens in an lsdm because of this
3461.05|4.12|superhighway of just additions these
3463.76|3.0|gradients at every single time step that
3465.17|4.08|we inject into the Alice team from above
3466.76|8.099|just flow through the cells and your
3469.25|7.05|gradients don't end up vanishing at this
3474.859|2.281|point maybe I take some questions are
3476.3|3.51|there any questions about what's
3477.14|4.38|confusing here about LST m and then
3479.81|7.14|after that I'll go into why RNs have
3481.52|7.2|vanish ingredients problem good yeah so
3486.95|3.87|this oh you're acting by the Oh vector
3488.72|3.57|is that important turns out that I think
3490.82|3.45|that one specifically is not super
3492.29|3.45|important so there's a paper I'm going
3494.27|3.65|to show you is called an LSD Emser space
3495.74|5.49|odyssey they really played with this
3497.92|4.929|take stuff out put stuff in they there's
3501.23|3.389|also like these people connections you
3502.849|4.051|can you can add so this cell state here
3504.619|4.2|that can be actually put in with the
3506.9|2.79|hidden state vector as an input so
3508.819|1.981|people really play with this
3509.69|2.76|architecture and they've tried lots of
3510.8|3.18|iterations of exactly these equations
3512.45|4.95|and what you end up with this almost
3513.98|5.22|everything works about equal some of it
3517.4|3.15|works slightly worse sometimes so it's
3519.2|4.83|very kind of confusing in this in this
3520.55|5.91|way I also show you a paper where they
3524.03|4.44|took they treated these update equations
3526.46|3.18|as just a they built trees over the
3528.47|3.21|update equations and then they did this
3529.64|3.27|like random mutation stuff and they try
3531.68|3.3|all kinds of different graphs and
3532.91|3.929|updates you can have and not most of
3534.98|3.18|them work about some of them break and
3536.839|2.76|some of them work about the same but
3538.16|4.169|nothing like really that's much better
3539.599|6.691|than an Ellis team
3542.329|5.76|any other questions well Elson let's go
3546.29|4.04|into why recurrent neural networks have
3548.089|11.541|terrible backward flow
3550.33|10.44|I'll show you a cute video also so this
3559.63|2.28|is showing the vanishing gradients
3560.77|3.39|problem in recurrent neural networks
3561.91|6.18|with respect to LS DMS so what we're
3564.16|5.46|showing here is we're looking at we're
3568.09|3.51|unrolling a recurrent neural network
3569.62|3.9|over many periods many time steps and
3571.6|4.8|then we're injecting gradient and say at
3573.52|4.02|say 128 time step and we're back
3576.4|3.09|wrapping in the gradient through the
3577.54|4.83|network and we're looking at what is the
3579.49|4.83|gradient for I think the inputs to hit
3582.37|4.38|in matrix one of the weight matrices at
3584.32|4.59|every single time step so remember that
3586.75|3.48|to actually get the full update through
3588.91|3.03|the batch we actually end up adding all
3590.23|3.96|those gradients here and so what's
3591.94|4.29|what's what's being shown here is that
3594.19|3.45|as you backtrack we've only injected
3596.23|2.94|gradient at one twentieth time steps
3597.64|3.27|everything we do back drop back through
3599.17|3.45|time and this is showing the slices of
3600.91|3.18|that back propagation what you're seeing
3602.62|2.73|is that the LS TM gives you lots of
3604.09|2.61|gradients throughout this back
3605.35|2.79|propagation so there's lots of
3606.7|4.23|information that is flowing through and
3608.14|4.68|this RN I'm just instantly dies off that
3610.93|4.26|just the gradient we say vanishes just
3612.82|4.14|just becomes tiny numbers there's no
3615.19|3.54|gradient so in this case I think in the
3616.96|3.42|case in about eight time steps or so
3618.73|3.36|like ten time steps and so all this
3620.38|3.75|gradient information that we've injected
3622.09|3.6|did not flow through the network and you
3624.13|2.76|can't learn very long dependencies
3625.69|3.78|because all the correlation structure
3626.89|6.71|has been just died down and so we'll see
3629.47|5.94|why this happens dynamically in a bit
3633.6|6.43|there's some comments here which are
3635.41|12.45|also funny this is like YouTube or
3640.03|11.94|something again okay anyways okay so
3647.86|5.22|let's look at a very simple example here
3651.97|2.91|where we have a recurrent neural network
3653.08|3.18|that I'm going to unroll for you in this
3654.88|3.63|recurrent neural network I'm not showing
3656.26|4.71|any inputs we're only have hidden state
3658.51|5.04|updates so here I'm initializing a
3660.97|4.74|weight wh H which is the hidden state
3663.55|3.3|hidden to hit an interaction and then
3665.71|2.25|I'm going to basically forward a
3666.85|3.36|recurrent neural network this is a
3667.96|4.77|vanilla recurrent net for some tea time
3670.21|4.29|steps here I'm using T 50 so what I'm
3672.73|3.57|doing is wh h times the previous hidden
3674.5|3.72|time step and then relu on top of that
3676.3|3.72|so this is just a forward pass for an RN
3678.22|5.28|and ignoring any input vectors coming in
3680.02|4.13|is just wh h times h threshold wh h
3683.5|2.24|times h
3684.15|3.75|threshold and so on so that's the
3685.74|3.75|forward pass and then I'm going to do
3687.9|4.56|backward pass here we're objecting a
3689.49|4.74|random gradient here at the last time
3692.46|3.569|step so the 50th time step I inject some
3694.23|3.9|gradient which is random and then I go
3696.029|3.241|backwards and I back drop so when you
3698.13|2.76|back drop through this right you have to
3699.27|3.059|back wrap through a rail here I'm using
3700.89|4.59|a rail you have to back drop throughout
3702.329|6.51|the whh multiply then through relu whh
3705.48|5.309|multiply and so on and so the thing to
3708.839|3.331|note here is so here I'm undoing the
3710.789|2.25|relu here's where I'm back propagating
3712.17|2.79|through the rail oh I'm just fresh
3713.039|5.58|holding anything that where the inputs
3714.96|7.44|were less than zero and Here I am back
3718.619|5.311|dropping the WH H times H operation
3722.4|3.149|where we actually multiply it by the WH
3723.93|3.96|H matrix before we do to non-linearity
3725.549|3.601|and so there's something very funky
3727.89|3.0|going on when you actually look at what
3729.15|3.51|happens to these DHS which is the
3730.89|3.449|gradient on the HS as you go backwards
3732.66|5.1|through time it has a very kind of funny
3734.339|5.401|structure that is very worrying as you
3737.76|4.17|look at like how this gets chained up in
3739.74|5.299|the in the loop like what are we doing
3741.93|3.109|here with these two time steps
3758.01|4.51|taking that product of all zeros yeah so
3761.17|2.94|I think that sometimes steps maybe the
3762.52|3.72|outputs the railways were all dead and
3764.11|4.23|so you may have killed it but that's not
3766.24|3.9|really the issue the more worrying issue
3768.34|3.54|is well that would be an issue as well
3770.14|4.74|but I think one worrying issue that
3771.88|5.31|people definitely spot as well as you'll
3774.88|4.41|see that we're multiplying by this whh
3777.19|4.35|matrix over and over and over again
3779.29|5.67|because in the forward pass we multiply
3781.54|4.77|by whh at every single iteration when we
3784.96|4.71|back propagate through all the hidden
3786.31|6.24|states we end up back propagating this
3789.67|4.38|formula whe H times HS and the back rub
3792.55|2.73|turns out to actually be that you take
3794.05|5.24|your gradient signal and you multiply it
3795.28|6.69|by the whh matrix and so we end up
3799.29|5.2|multiplying by whh the gradient gets
3801.97|4.86|multiplied by whh then thresholded then
3804.49|4.85|multiplied by whh thresholded and so we
3806.83|5.789|end up multiplying by this matrix whh
3809.34|6.25|fifty times and so the issue with this
3812.619|4.951|is that the gradient signal basically
3815.59|3.93|okay two things can happen like if you
3817.57|3.15|think about working with scalar value
3819.52|3.48|suppose that these were scalars not
3820.72|4.32|matrices if I take a number that's
3823.0|3.42|random and then I have a second number
3825.04|3.329|and I keep multiplying the first number
3826.42|5.57|by the second number so again and again
3828.369|3.621|and again what does that sequence go to
3832.859|3.491|there's two cases right if I keep
3835.33|5.279|multiplying with the same number either
3836.35|6.39|I die or just goes completely yes so if
3840.609|3.481|your second number was exactly one yeah
3842.74|2.67|so that's the only case where you don't
3844.09|2.82|actually explode but otherwise really
3845.41|4.41|bad things are happening either we die
3846.91|4.59|or we explode and here we have matrices
3849.82|2.85|we don't have a single number but in
3851.5|2.91|fact it's the same thing happens the
3852.67|3.9|generalization of it happens if the
3854.41|4.35|spectral radius of this whh matrix is
3856.57|4.08|which is the hutt than the largest eigen
3858.76|3.78|value of that matrix if it's greater
3860.65|3.36|than one then this gradient signal will
3862.54|2.91|explode if it's lower than one the
3864.01|3.99|gradient signal will completely die and
3865.45|5.1|so basically since the Arlen has this
3868.0|4.68|very weird because of this recurrence
3870.55|4.02|formula we end up with this very just
3872.68|5.189|terrible dynamics and it's very unstable
3874.57|6.69|and it just dies or explodes and so in
3877.869|5.311|practice the way this was handled was we
3881.26|3.24|can control the exploding gradient one
3883.18|3.34|simple hack as if you're grained is
3884.5|3.64|exploding you clip it
3886.52|2.79|because people actually do this in
3888.14|4.229|practice it's like a very patchy
3889.31|4.8|solution but if your gradient is above 5
3892.369|3.811|in norm then you clamp it to 5
3894.11|3.12|element-wise or something like that so
3896.18|2.34|you can do that it's called gradient
3897.23|2.82|clipping that's how you address the
3898.52|3.599|exploding gradient problem and then your
3900.05|4.02|conduct your recurrence don't explode
3902.119|3.361|anymore but the gradients can still
3904.07|2.79|vanish in a recurrent neural network and
3905.48|2.639|Alice team is very good with the
3906.86|3.78|vanishing gradient problem because of
3908.119|4.231|these highways of cells that are only
3910.64|3.57|changed with additive interactions where
3912.35|4.92|the gradients just flow they never die
3914.21|4.409|down if you're if you because you're
3917.27|2.91|multiplying by the same matrix again and
3918.619|2.701|again or something like that so that's
3920.18|4.65|roughly why these are just better
3921.32|5.91|dynamically so we always use alice teams
3924.83|4.289|and we do do gradient clipping usually
3927.23|4.08|so because the gradients in analyst team
3929.119|11.25|can potentially explode still but they
3931.31|10.8|they don't usually vanish good thank you
3940.369|3.301|so here I'm using relu people you
3942.11|5.49|sometimes use 10h in Velen are recurrent
3943.67|7.74|neural networks as well for LS DMS it's
3947.6|5.4|not clear where you would plug in it's
3951.41|3.38|not clear in this equation like exactly
3953.0|6.109|how you would plug in a rail and where
3954.79|6.67|maybe instead of the may 4G I'm not sure
3959.109|5.771|so instead of 10 H we would use G here
3961.46|7.2|really but then so these cells would
3964.88|5.34|only grow in a single direction right so
3968.66|3.39|maybe then you can't actually end up
3970.22|6.45|making it smaller so that's not a great
3972.05|6.45|idea I suppose yeah so there is
3976.67|6.57|basically there's no clear way to plug
3978.5|6.45|in a rail here so yeah one thing I'll
3983.24|3.99|note is that in terms of these super
3984.95|4.08|highways of gradients this this
3987.23|3.27|viewpoint actually breaks down when you
3989.03|3.66|have 4 get gates because when you have
3990.5|3.45|four get gates where we can forget some
3992.69|3.36|of these apps with a multiplicative
3993.95|3.99|interaction then whenever a per gate
3996.05|3.6|gate turns on and it kills the gradient
3997.94|4.32|then of course the backward flow will
3999.65|4.709|stop so these super highways are only
4002.26|3.39|kind of true if you don't have any
4004.359|3.631|forget gates but if you have a forget
4005.65|5.34|gate there then it can kill the gradient
4007.99|4.619|and so in practice when we play with
4010.99|3.81|Alice TMS where we use all stems I
4012.609|3.481|suppose sometimes people when they
4014.8|2.61|initialize the for gate gate they
4016.09|3.479|initialize it with a positive bias
4017.41|5.819|because that biases that forget gate
4019.569|6.48|to turn on to be always kind of turned
4023.229|4.08|off I suppose in the beginning so in the
4026.049|2.73|beginning the gradients flow very well
4027.309|3.75|and then the Ellis team can learn how to
4028.779|3.99|shut them off at once to the later on so
4031.059|4.74|people play with that bias on that four
4032.769|4.05|gate gate sometimes and so the last
4035.799|3.391|night here I wanted to mention that
4036.819|3.48|Ellis TMS media many people have
4039.19|2.879|basically played with this quite a bit
4040.299|3.93|so there's a search space odyssey' paper
4042.069|6.121|where they try various changes to the
4044.229|6.24|architecture there's a paper here that
4048.19|5.22|tries to do this search over a huge
4050.469|5.79|number of potential changes to the lsdm
4053.41|4.079|equations and they did a large search
4056.259|3.06|and they didn't find anything that works
4057.489|5.46|substantially better than just an Ellis
4059.319|5.371|TM so yeah and then there's this gru
4062.949|2.971|which also is relatively actually
4064.69|3.539|popular and I would actually recommend
4065.92|4.949|that you might want to use this a GRU is
4068.229|4.08|a change on the nellis TM it also has
4070.869|3.571|these additive interactions but what's
4072.309|4.74|nice about it is that it's a shorter
4074.44|4.349|smaller formula and it only has the
4077.049|4.17|single H vector it doesn't have an H and
4078.789|3.93|a C it only has an H so implementation
4081.219|2.701|wise is just nicer to remember just a
4082.719|3.51|single hidden state vector in your
4083.92|4.199|forward pass not two vectors and so it's
4086.229|3.06|just a smaller simpler thing that seems
4088.119|4.051|to have most of the benefits of an
4089.289|4.26|ostium but so it's called gru and it
4092.17|4.529|almost always works about equal width
4093.549|4.29|lsdm in my experience and so you might
4096.699|3.06|want to use it or you can use the new
4097.839|6.51|ostium they both kind of do about the
4099.759|8.161|same and so summary is that our nets are
4104.349|5.281|very nice ah but the raw RNN does not
4107.92|3.12|actually work very well so you zealous
4109.63|2.91|teams or gr use instead what's nice
4111.04|3.389|about them is that we're having these
4112.54|3.239|additive interactions that allow
4114.429|2.73|gradients to flow much better and you
4115.779|3.42|don't get a vanishing gradient problem
4117.159|3.45|we still have to worry a bit about the
4119.199|2.73|exploding gradient problem so it's
4120.609|4.05|common to see people clip these
4121.929|4.44|gradients sometimes and I would say that
4124.659|3.39|better simpler architectures are really
4126.369|2.97|trying to understand how come like
4128.049|3.78|there's something deeper going on with
4129.339|4.32|the connection between resonance and LSD
4131.829|3.361|m/s and there's something deeper about
4133.659|2.91|these additive interactions that I think
4135.19|4.23|we're not fully understanding yet and
4136.569|5.4|exactly why that works so well in which
4139.42|3.96|parts of it work well and so I think we
4141.969|2.761|need a much better understanding both
4143.38|2.699|theoretical and empirical in the space
4144.73|6.9|and it's a very wide open area of
4146.079|6.72|research and so yeah so it's a it's for
4151.63|6.12|10
4152.799|6.991|that's the end of a classroom with an
4157.75|5.73|LST M people still clip gradients that
4159.79|5.489|can I suppose still explode so it's not
4163.48|3.449|as clear why they would but you keep
4165.279|3.21|injecting gradient into the cell state
4166.929|4.44|and so maybe that gradient can sometimes
4168.489|4.891|get larger so it's common to clip them
4171.369|3.631|but I think not as may be important
4173.38|6.929|maybe as an RN and a lot hundred percent
4175.0|7.859|sure about that one good your logical
4180.309|5.401|basis I have no idea how being it's
4182.859|4.141|interesting yeah okay I think we should
4185.71|3.92|end the class here but I'm happy to take
4187.0|2.63|more questions here