start_time|end_time|text
0.04|4.04|hi everyone so in this video I'd like us
2.04|4.4|to cover the process of tokenization in
4.08|4.2|large language models now you see here
6.44|3.88|that I have a set face and that's
8.28|3.399|because uh tokenization is my least
10.32|3.16|favorite part of working with large
11.679|3.84|language models but unfortunately it is
13.48|4.12|necessary to understand in some detail
15.519|3.961|because it it is fairly hairy gnarly and
17.6|4.24|there's a lot of hidden foot guns to be
19.48|5.119|aware of and a lot of oddness with large
21.84|4.8|language models typically traces back to
24.599|4.321|tokenization so what is
26.64|4.92|tokenization now in my previous video
28.92|4.56|Let's Build GPT from scratch uh we
31.56|4.24|actually already did tokenization but we
33.48|4.0|did a very naive simple version of
35.8|4.759|tokenization so when you go to the
37.48|5.72|Google colab for that video uh you see
40.559|4.961|here that we loaded our training set and
43.2|4.92|our training set was this uh Shakespeare
45.52|4.24|uh data set now in the beginning the
48.12|4.32|Shakespeare data set is just a large
49.76|5.08|string in Python it's just text and so
52.44|5.639|the question is how do we plug text into
54.84|6.6|large language models and in this case
58.079|5.881|here we created a vocabulary of 65
61.44|4.359|possible characters that we saw occur in
63.96|4.0|this string these were the possible
65.799|4.841|characters and we saw that there are 65
67.96|5.44|of them and then we created a a lookup
70.64|5.68|table for converting from every possible
73.4|4.359|character a little string piece into a
76.32|4.2|token an
77.759|5.521|integer so here for example we tokenized
80.52|4.2|the string High there and we received
83.28|4.32|this sequence of
84.72|5.2|tokens and here we took the first 1,000
87.6|4.96|characters of our data set and we
89.92|4.72|encoded it into tokens and because it is
92.56|6.4|this is character level we received
94.64|5.479|1,000 tokens in a sequence so token 18
98.96|4.479|47
100.119|5.521|Etc now later we saw that the way we
103.439|5.04|plug these tokens into the language
105.64|5.839|model is by using an embedding
108.479|5.0|table and so basically if we have 65
111.479|4.96|possible tokens then this embedding
113.479|4.68|table is going to have 65 rows and
116.439|3.36|roughly speaking we're taking the
118.159|3.361|integer associated with every single
119.799|4.24|sing Le token we're using that as a
121.52|4.959|lookup into this table and we're
124.039|5.321|plucking out the corresponding row and
126.479|4.0|this row is a uh is trainable parameters
129.36|3.519|that we're going to train using back
130.479|4.881|propagation and this is the vector that
132.879|3.681|then feeds into the Transformer um and
135.36|2.76|that's how the Transformer Ser of
136.56|4.72|perceives every single
138.12|5.0|token so here we had a very naive
141.28|3.959|tokenization process that was a
143.12|4.16|character level tokenizer but in
145.239|3.72|practice in state-ofthe-art uh language
147.28|3.16|models people use a lot more complicated
148.959|5.401|schemes unfortunately
150.44|6.2|uh for constructing these uh token
154.36|4.28|vocabularies so we're not dealing on the
156.64|4.879|Character level we're dealing on chunk
158.64|5.239|level and the way these um character
161.519|3.961|chunks are constructed is using
163.879|3.08|algorithms such as for example the bik
165.48|5.52|pair in coding algorithm which we're
166.959|5.92|going to go into in detail um and cover
171.0|3.84|in this video I'd like to briefly show
172.879|4.041|you the paper that introduced a bite
174.84|3.6|level encoding as a mechanism for
176.92|3.679|tokenization in the context of large
178.44|4.28|language models and I would say that
180.599|4.961|that's probably the gpt2 paper and if
182.72|5.0|you scroll down here to the section
185.56|3.92|input representation this is where they
187.72|2.84|cover tokenization the kinds of
189.48|3.52|properties that you'd like the
190.56|4.399|tokenization to have and they conclude
193.0|4.599|here that they're going to have a
194.959|5.721|tokenizer where you have a vocabulary of
197.599|6.801|50,2 57 possible
200.68|6.68|tokens and the context size is going to
204.4|4.839|be 1,24 tokens so in the in in the
207.36|3.12|attention layer of the Transformer
209.239|3.08|neural network
210.48|3.6|every single token is attending to the
212.319|5.601|previous tokens in the sequence and it's
214.08|6.6|going to see up to 1,24 tokens so tokens
217.92|5.2|are this like fundamental unit um the
220.68|4.119|atom of uh large language models if you
223.12|3.96|will and everything is in units of
224.799|3.561|tokens everything is about tokens and
227.08|4.0|tokenization is the process for
228.36|6.519|translating strings or text into
231.08|5.799|sequences of tokens and uh vice versa
234.879|3.401|when you go into the Llama 2 paper as
236.879|4.841|well I can show you that when you search
238.28|5.039|token you're going to get get 63 hits um
241.72|3.4|and that's because tokens are again
243.319|3.56|pervasive so here they mentioned that
245.12|3.319|they trained on two trillion tokens of
246.879|4.2|data and so
248.439|4.601|on so we're going to build our own
251.079|4.041|tokenizer luckily the bite be encoding
253.04|3.919|algorithm is not uh that super
255.12|3.399|complicated and we can build it from
256.959|3.761|scratch ourselves and we'll see exactly
258.519|4.041|how this works before we dive into code
260.72|3.4|I'd like to give you a brief Taste of
262.56|3.56|some of the complexities that come from
264.12|3.079|the tokenization because I just want to
266.12|3.359|make sure that we motivate it
267.199|5.44|sufficiently for why we are doing all
269.479|4.72|this and why this is so gross so
272.639|3.481|tokenization is at the heart of a lot of
274.199|3.56|weirdness in large language models and I
276.12|4.48|would advise that you do not brush it
277.759|4.561|off a lot of the issues that may look
280.6|3.92|like just issues with the new network
282.32|4.28|architecture or the large language model
284.52|4.64|itself are actually issues with the
286.6|5.159|tokenization and fundamentally Trace uh
289.16|5.08|back to it so if you've noticed any
291.759|4.401|issues with large language models can't
294.24|3.72|you know not able to do spelling tasks
296.16|4.0|very easily that's usually due to
297.96|4.32|tokenization simple string processing
300.16|3.44|can be difficult for the large language
302.28|3.8|model to perform
303.6|4.64|natively uh non-english languages can
306.08|3.36|work much worse and to a large extent
308.24|3.519|this is due to
309.44|4.64|tokenization sometimes llms are bad at
311.759|3.72|simple arithmetic also can trace be
314.08|3.679|traced to
315.479|4.16|tokenization uh gbt2 specifically would
317.759|4.401|have had quite a bit more issues with
319.639|4.761|python than uh future versions of it due
322.16|3.72|to tokenization there's a lot of other
324.4|3.04|issues maybe you've seen weird warnings
325.88|4.8|about a trailing whites space this is a
327.44|6.08|tokenization issue um
330.68|4.56|if you had asked GPT earlier about solid
333.52|4.0|gold Magikarp and what it is you would
335.24|4.32|see the llm go totally crazy and it
337.52|4.399|would start going off about a completely
339.56|4.16|unrelated tangent topic maybe you've
341.919|3.521|been told to use yl over Json in
343.72|3.919|structure data all of that has to do
345.44|3.96|with tokenization so basically
347.639|4.241|tokenization is at the heart of many
349.4|4.68|issues I will look back around to these
351.88|5.039|at the end of the video but for now let
354.08|5.88|me just um skip over it a little bit and
356.919|6.0|let's go to this web app um the Tik
359.96|4.72|tokenizer bell.app so I have it loaded
362.919|3.641|here and what I like about this web app
364.68|4.84|is that tokenization is running a sort
366.56|5.4|of live in your browser in JavaScript so
369.52|4.679|you can just type here stuff hello world
371.96|6.519|and the whole string
374.199|6.161|rokenes so here what we see on uh the
378.479|3.72|left is a string that you put in on the
380.36|4.2|right we're currently using the gpt2
382.199|4.881|tokenizer we see that this string that I
384.56|5.96|pasted here is currently tokenizing into
387.08|5.6|300 tokens and here they are sort of uh
390.52|5.0|shown explicitly in different colors for
392.68|6.2|every single token so for example uh
395.52|5.2|this word tokenization became two tokens
398.88|5.039|the token
400.72|3.199|3,642 and
404.0|7.919|1,634 the token um space is is token 318
410.16|4.439|so be careful on the bottom you can show
411.919|5.441|white space and keep in mind that there
414.599|5.121|are spaces and uh sln new line
417.36|4.239|characters in here but you can hide them
419.72|6.28|for
421.599|9.481|clarity the token space at is token 379
426.0|6.96|the to the Token space the is 262 Etc so
431.08|4.88|you notice here that the space is part
432.96|5.679|of that uh token
435.96|5.2|chunk now so this is kind of like how
438.639|5.4|our English sentence broke up and that
441.16|5.759|seems all well and good now now here I
444.039|7.761|put in some arithmetic so we see that uh
446.919|7.321|the token 127 Plus and then token six
451.8|4.839|space 6 followed by 77 so what's
454.24|3.92|happening here is that 127 is feeding in
456.639|6.041|as a single token into the large
458.16|6.68|language model but the um number 677
462.68|4.32|will actually feed in as two separate
464.84|5.88|tokens and so the large language model
467.0|6.879|has to sort of um take account of that
470.72|5.479|and process it correctly in its Network
473.879|4.081|and see here 804 will be broken up into
476.199|3.601|two tokens and it's is all completely
477.96|4.079|arbitrary and here I have another
479.8|4.119|example of four-digit numbers and they
482.039|3.241|break up in a way that they break up and
483.919|4.441|it's totally arbitrary sometimes you
485.28|5.08|have um multiple digits single token
488.36|3.88|sometimes you have individual digits as
490.36|4.32|many tokens and it's all kind of pretty
492.24|5.239|arbitrary and coming out of the
494.68|6.359|tokenizer here's another example we have
497.479|4.881|the string egg and you see here that
501.039|3.72|this became two
502.36|5.36|tokens but for some reason when I say I
504.759|6.081|have an egg you see when it's a space
507.72|5.52|egg it's two token it's sorry it's a
510.84|3.92|single token so just egg by itself in
513.24|4.44|the beginning of a sentence is two
514.76|5.759|tokens but here as a space egg is
517.68|6.52|suddenly a single token uh for the exact
520.519|5.721|same string okay here lowercase egg
524.2|3.28|turns out to be a single token and in
526.24|3.12|particular notice that the color is
527.48|4.28|different so this is a different token
529.36|5.2|so this is case sensitive and of course
531.76|5.68|a capital egg would also be different
534.56|5.519|tokens and again um this would be two
537.44|4.88|tokens arbitrarily so so for the same
540.079|3.721|concept egg depending on if it's in the
542.32|3.92|beginning of a sentence at the end of a
543.8|4.279|sentence lowercase uppercase or mixed
546.24|4.08|all this will be uh basically very
548.079|3.961|different tokens and different IDs and
550.32|3.24|the language model has to learn from raw
552.04|3.12|data from all the internet text that
553.56|3.88|it's going to be training on that these
555.16|4.119|are actually all the exact same concept
557.44|3.88|and it has to sort of group them in the
559.279|3.201|parameters of the neural network and
561.32|3.44|understand just based on the data
562.48|4.919|patterns that these are all very similar
564.76|5.4|but maybe not almost exactly similar but
567.399|5.401|but very very similar
570.16|5.48|um after the EG demonstration here I
572.8|9.159|have um an introduction from open a eyes
575.64|8.439|chbt in Korean so manaso Pang uh Etc uh
581.959|5.801|so this is in Korean and the reason I
584.079|6.921|put this here is because you'll notice
587.76|6.56|that um non-english languages work
591.0|4.64|slightly worse in Chachi part of this is
594.32|3.759|because of course the training data set
595.64|4.319|for Chachi is much larger for English
598.079|3.601|and for everything else but the same is
599.959|4.361|true not just for the large language
601.68|4.2|model itself but also for the tokenizer
604.32|2.92|so when we train the tokenizer we're
605.88|3.36|going to see that there's a training set
607.24|4.08|as well and there's a lot more English
609.24|4.24|than non-english and what ends up
611.32|5.28|happening is that we're going to have a
613.48|6.12|lot more longer tokens for
616.6|4.799|English so how do I put this if you have
619.6|3.96|a single sentence in English and you
621.399|4.081|tokenize it you might see that it's 10
623.56|3.8|tokens or something like that but if you
625.48|3.96|translate that sentence into say Korean
627.36|3.479|or Japanese or something else you'll
629.44|3.959|typically see that the number of tokens
630.839|5.921|used is much larger and that's because
633.399|5.12|the chunks here are a lot more broken up
636.76|4.6|so we're using a lot more tokens for the
638.519|5.241|exact same thing and what this does is
641.36|4.88|it bloats up the sequence length of all
643.76|4.639|the documents so you're using up more
646.24|3.68|tokens and then in the attention of the
648.399|3.521|Transformer when these tokens try to
649.92|5.2|attend each other you are running out of
651.92|6.039|context um in the maximum context length
655.12|6.159|of that Transformer and so basically all
657.959|5.481|the non-english text is stretched out
661.279|4.401|from the perspective of the Transformer
663.44|4.04|and this just has to do with the um
665.68|4.36|trainings that used for the tokenizer
667.48|4.599|and the tokenization itself so it will
670.04|4.16|create a lot bigger tokens and a lot
672.079|4.081|larger groups in English and it will
674.2|5.56|have a lot of little boundaries for all
676.16|5.76|the other non-english text um so if we
679.76|3.56|translated this into English it would be
681.92|3.719|significantly fewer
683.32|4.759|tokens the final example I have here is
685.639|5.361|a little snippet of python for doing FS
688.079|5.961|buuz and what I'd like you to notice is
691.0|6.0|look all these individual spaces are all
694.04|8.72|separate tokens they are token
697.0|8.32|220 so uh 220 220 220 220 and then space
702.76|3.96|if is a single token and so what's going
705.32|4.0|on here is that when the Transformer is
706.72|5.919|going to consume or try to uh create
709.32|5.16|this text it needs to um handle all
712.639|3.921|these spaces individually they all feed
714.48|4.64|in one by one into the entire
716.56|4.719|Transformer in the sequence and so this
719.12|5.32|is being extremely wasteful tokenizing
721.279|5.761|it in this way and so as a result of
724.44|4.24|that gpt2 is not very good with python
727.04|3.64|and it's not anything to do with coding
728.68|3.399|or the language model itself it's just
730.68|4.719|that if he use a lot of indentation
732.079|5.32|using space in Python like we usually do
735.399|3.961|uh you just end up bloating out all the
737.399|3.641|text and it's separated across way too
739.36|3.4|much of the sequence and we are running
741.04|3.4|out of the context length in the
742.76|2.879|sequence uh that's roughly speaking
744.44|2.959|what's what's happening we're being way
745.639|4.041|too wasteful we're taking up way too
747.399|4.201|much token space now we can also scroll
749.68|4.36|up here and we can change the tokenizer
751.6|5.12|so note here that gpt2 tokenizer creates
754.04|5.479|a token count of 300 for this string
756.72|5.119|here we can change it to CL 100K base
759.519|5.041|which is the GPT for tokenizer and we
761.839|4.961|see that the token count drops to 185 so
764.56|5.24|for the exact same string we are now
766.8|4.96|roughly having the number of tokens and
769.8|4.56|roughly speaking this is because uh the
771.76|4.96|number of tokens in the GPT 4 tokenizer
774.36|4.479|is roughly double that of the number of
776.72|4.919|tokens in the gpt2 tokenizer so we went
778.839|4.161|went from roughly 50k to roughly 100K
781.639|4.361|now you can imagine that this is a good
783.0|7.199|thing because the same text is now
786.0|6.76|squished into half as many tokens so uh
790.199|5.241|this is a lot denser input to the
792.76|4.28|Transformer and in the Transformer every
795.44|2.959|single token has a finite number of
797.04|3.4|tokens before it that it's going to pay
798.399|5.081|attention to and so what this is doing
800.44|6.079|is we're roughly able to see twice as
803.48|5.799|much text as a context for what token to
806.519|4.281|predict next uh because of this change
809.279|4.12|but of course just increasing the number
810.8|4.36|of tokens is uh not strictly better
813.399|3.521|infinitely uh because as you increase
815.16|4.72|the number of tokens now your embedding
816.92|4.56|table is um sort of getting a lot larger
819.88|3.0|and also at the output we are trying to
821.48|3.64|predict the next token and there's the
822.88|3.519|soft Max there and that grows as well
825.12|3.32|we're going to go into more detail later
826.399|4.601|on this but there's some kind of a Sweet
828.44|3.839|Spot somewhere where you have a just
831.0|2.88|right number of tokens in your
832.279|4.24|vocabulary where everything is
833.88|4.48|appropriately dense and still fairly
836.519|3.641|efficient now one thing I would like you
838.36|5.2|to note specifically for the gp4
840.16|5.28|tokenizer is that the handling of the
843.56|4.8|white space for python has improved a
845.44|4.8|lot you see that here these four spaces
848.36|5.399|are represented as one single token for
850.24|6.519|the three spaces here and then the token
853.759|5.041|SPF and here seven spaces were all
856.759|3.44|grouped into a single token so we're
858.8|3.12|being a lot more efficient in how we
860.199|3.56|represent Python and this was a
861.92|5.64|deliberate Choice made by open aai when
863.759|5.921|they designed the gp4 tokenizer and they
867.56|4.519|group a lot more space into a single
869.68|5.519|character what this does is this
872.079|6.041|densifies Python and therefore we can
875.199|4.521|attend to more code before it when we're
878.12|3.92|trying to predict the next token in the
879.72|5.679|sequence and so the Improvement in the
882.04|5.039|python coding ability from gbt2 to gp4
885.399|3.44|is not just a matter of the language
887.079|3.68|model and the architecture and the
888.839|3.401|details of the optimization but a lot of
890.759|3.481|the Improvement here is also coming from
892.24|4.719|the design of the tokenizer and how it
894.24|5.159|groups characters into tokens okay so
896.959|4.481|let's now start writing some code
899.399|4.321|so remember what we want to do we want
901.44|4.519|to take strings and feed them into
903.72|5.08|language models for that we need to
905.959|6.401|somehow tokenize strings into some
908.8|5.44|integers in some fixed vocabulary and
912.36|4.399|then we will use those integers to make
914.24|3.76|a look up into a lookup table of vectors
916.759|4.601|and feed those vectors into the
918.0|4.72|Transformer as an input now the reason
921.36|2.64|this gets a little bit tricky of course
922.72|3.4|is that we don't just want to support
924.0|4.12|the simple English alphabet we want to
926.12|5.519|support different kinds of languages so
928.12|4.88|this is anango in Korean which is hello
931.639|3.081|and we also want to support many kinds
933.0|4.319|of special characters that we might find
934.72|6.76|on the internet for example
937.319|4.88|Emoji so how do we feed this text into
941.48|3.0|uh
942.199|4.361|Transformers well how's the what is this
944.48|5.12|text anyway in Python so if you go to
946.56|4.959|the documentation of a string in Python
949.6|4.52|you can see that strings are immutable
951.519|6.361|sequences of Unicode code
954.12|7.36|points okay what are Unicode code points
957.88|6.8|we can go to PDF so Unicode code points
961.48|6.08|are defined by the Unicode Consortium as
964.68|4.32|part of the Unicode standard and what
967.56|4.279|this is really is that it's just a
969.0|5.72|definition of roughly 150,000 characters
971.839|5.721|right now and roughly speaking what they
974.72|5.0|look like and what integers um represent
977.56|5.079|those characters so it says 150,000
979.72|5.0|characters across 161 scripts as of
982.639|3.64|right now so if you scroll down here you
984.72|4.0|can see that the standard is very much
986.279|3.92|alive the latest standard 15.1 in
988.72|5.2|September
990.199|6.721|2023 and basically this is just a way to
993.92|5.24|define lots of types of
996.92|4.96|characters like for example all these
999.16|4.88|characters across different scripts so
1001.88|4.079|the way we can access the unic code code
1004.04|4.159|Point given Single Character is by using
1005.959|5.32|the or function in Python so for example
1008.199|6.521|I can pass in Ord of H and I can see
1011.279|5.201|that for the Single Character H the unic
1014.72|5.679|code code point is
1016.48|5.68|104 okay um but this can be arbitr
1020.399|3.761|complicated so we can take for example
1022.16|4.24|our Emoji here and we can see that the
1024.16|6.2|code point for this one is
1026.4|7.32|128,000 or we can take
1030.36|6.36|un and this is 50,000 now keep in mind
1033.72|4.719|you can't plug in strings here because
1036.72|3.959|you uh this doesn't have a single code
1038.439|5.52|point it only takes a single uni code
1040.679|6.12|code Point character and tells you its
1043.959|6.121|integer so in this way we can look
1046.799|5.361|up all the um characters of this
1050.08|6.68|specific string and their code points so
1052.16|8.2|or of X forx in this string and we get
1056.76|5.44|this encoding here now see here we've
1060.36|4.08|already turned the raw code points
1062.2|4.64|already have integers so why can't we
1064.44|4.119|simply just use these integers and not
1066.84|3.8|have any tokenization at all why can't
1068.559|4.321|we just use this natively as is and just
1070.64|3.72|use the code Point well one reason for
1072.88|3.919|that of course is that the vocabulary in
1074.36|4.319|that case would be quite long so in this
1076.799|3.0|case for Unicode the this is a
1078.679|3.961|vocabulary of
1079.799|5.24|150,000 different code points but more
1082.64|4.399|worryingly than that I think the Unicode
1085.039|4.201|standard is very much alive and it keeps
1087.039|4.041|changing and so it's not kind of a
1089.24|4.64|stable representation necessarily that
1091.08|4.68|we may want to use directly so for those
1093.88|3.76|reasons we need something a bit better
1095.76|4.0|so to find something better we turn to
1097.64|3.64|encodings so if we go to the Wikipedia
1099.76|4.039|page here we see that the Unicode
1101.28|6.68|consortion defines three types of
1103.799|6.921|encodings utf8 UTF 16 and UTF 32 these
1107.96|5.52|encoding are the way by which we can
1110.72|6.48|take Unicode text and translate it into
1113.48|6.48|binary data or by streams utf8 is by far
1117.2|4.8|the most common uh so this is the utf8
1119.96|4.44|page now this Wikipedia page is actually
1122.0|4.44|quite long but what's important for our
1124.4|5.24|purposes is that utf8 takes every single
1126.44|5.92|Cod point and it translates it to a by
1129.64|4.72|stream and this by stream is between one
1132.36|4.12|to four bytes so it's a variable length
1134.36|3.679|encoding so depending on the Unicode
1136.48|3.28|Point according to the schema you're
1138.039|4.961|going to end up with between 1 to four
1139.76|5.36|bytes for each code point on top of that
1143.0|5.84|there's utf8 uh
1145.12|5.439|utf16 and UTF 32 UTF 32 is nice because
1148.84|3.64|it is fixed length instead of variable
1150.559|6.441|length but it has many other downsides
1152.48|5.84|as well so the full kind of spectrum of
1157.0|3.48|pros and cons of all these different
1158.32|4.2|three encodings are beyond the scope of
1160.48|4.76|this video I just like to point out that
1162.52|4.519|I enjoyed this block post and this block
1165.24|4.0|post at the end of it also has a number
1167.039|5.0|of references that can be quite useful
1169.24|5.08|uh one of them is uh utf8 everywhere
1172.039|4.601|Manifesto um and this Manifesto
1174.32|5.56|describes the reason why utf8 is
1176.64|5.159|significantly preferred and a lot nicer
1179.88|5.6|than the other encodings and why it is
1181.799|6.281|used a lot more prominently um on the
1185.48|4.079|internet one of the major advantages
1188.08|3.92|just just to give you a sense is that
1189.559|4.641|utf8 is the only one of these that is
1192.0|5.08|backwards compatible to the much simpler
1194.2|4.28|asky encoding of text um but I'm not
1197.08|3.92|going to go into the full detail in this
1198.48|5.36|video so suffice to say that we like the
1201.0|5.039|utf8 encoding and uh let's try to take
1203.84|4.16|the string and see what we get if we
1206.039|4.721|encoded into
1208.0|4.36|utf8 the string class in Python actually
1210.76|4.799|has do encode and you can give it the
1212.36|5.48|encoding which is say utf8 now we get
1215.559|5.401|out of this is not very nice because
1217.84|4.92|this is the bytes is a bytes object and
1220.96|4.079|it's not very nice in the way that it's
1222.76|4.08|printed so I personally like to take it
1225.039|3.681|through list because then we actually
1226.84|5.56|get the raw B
1228.72|6.88|of this uh encoding so this is the raw
1232.4|5.68|byes that represent this string
1235.6|4.959|according to the utf8 en coding we can
1238.08|5.16|also look at utf16 we get a slightly
1240.559|4.921|different by stream and we here we start
1243.24|4.72|to see one of the disadvantages of utf16
1245.48|4.199|you see how we have zero Z something Z
1247.96|2.88|something Z something we're starting to
1249.679|4.24|get a sense that this is a bit of a
1250.84|5.44|wasteful encoding and indeed for simple
1253.919|4.64|asky characters or English characters
1256.28|4.48|here uh we just have the structure of 0
1258.559|5.681|something Z something and it's not
1260.76|5.32|exactly nice same for UTF 32 when we
1264.24|3.76|expand this we can start to get a sense
1266.08|4.32|of the wastefulness of this encoding for
1268.0|3.4|our purposes you see a lot of zeros
1270.4|4.44|followed by
1271.4|6.44|something and so uh this is not
1274.84|6.04|desirable so suffice it to say that we
1277.84|6.04|would like to stick with utf8 for our
1280.88|5.52|purposes however if we just use utf8
1283.88|5.36|naively these are by streams so that
1286.4|6.72|would imply a vocabulary length of only
1289.24|6.08|256 possible tokens uh but this this
1293.12|3.559|vocabulary size is very very small what
1295.32|4.56|this is going to do if we just were to
1296.679|5.24|use it naively is that all of our text
1299.88|6.279|would be stretched out over very very
1301.919|7.401|long sequences of bytes and so
1306.159|4.841|um what what this does is that certainly
1309.32|3.0|the embeding table is going to be tiny
1311.0|3.159|and the prediction at the top at the
1312.32|4.12|final layer is going to be very tiny but
1314.159|5.161|our sequences are very long and remember
1316.44|4.56|that we have pretty finite um context
1319.32|3.44|length and the attention that we can
1321.0|4.52|support in a transformer for
1322.76|4.72|computational reasons and so we only
1325.52|3.92|have as much context length but now we
1327.48|3.319|have very very long sequences and this
1329.44|3.359|is just inefficient and it's not going
1330.799|4.841|to allow us to attend to sufficiently
1332.799|5.561|long text uh before us for the purposes
1335.64|5.96|of the next token prediction task so we
1338.36|5.84|don't want to use the raw bytes of the
1341.6|5.319|utf8 encoding we want to be able to
1344.2|4.44|support larger vocabulary size that we
1346.919|3.921|can tune as a hyper
1348.64|4.919|but we want to stick with the utf8
1350.84|4.64|encoding of these strings so what do we
1353.559|3.881|do well the answer of course is we turn
1355.48|3.6|to the bite pair encoding algorithm
1357.44|5.16|which will allow us to compress these
1359.08|5.599|bite sequences um to a variable amount
1362.6|4.52|so we'll get to that in a bit but I just
1364.679|4.6|want to briefly speak to the fact that I
1367.12|5.84|would love nothing more than to be able
1369.279|5.601|to feed raw bite sequences into uh
1372.96|4.12|language models in fact there's a paper
1374.88|4.399|about how this could potentially be done
1377.08|3.88|uh from Summer last last year now the
1379.279|3.0|problem is you actually have to go in
1380.96|3.52|and you have to modify the Transformer
1382.279|4.361|architecture because as I mentioned
1384.48|3.76|you're going to have a problem where the
1386.64|3.72|attention will start to become extremely
1388.24|5.2|expensive because the sequences are so
1390.36|5.4|long and so in this paper they propose
1393.44|4.2|kind of a hierarchical structuring of
1395.76|4.6|the Transformer that could allow you to
1397.64|4.279|just feed in raw bites and so at the end
1400.36|3.28|they say together these results
1401.919|3.401|establish the viability of tokenization
1403.64|3.76|free autor regressive sequence modeling
1405.32|4.959|at scale so tokenization free would
1407.4|4.879|indeed be amazing we would just feed B
1410.279|3.88|streams directly into our models but
1412.279|3.801|unfortunately I don't know that this has
1414.159|3.081|really been proven out yet by
1416.08|3.16|sufficiently many groups and a
1417.24|3.439|sufficient scale uh but something like
1419.24|3.08|this at one point would be amazing and I
1420.679|3.761|hope someone comes up with it but for
1422.32|4.12|now we have to come back and we can't
1424.44|3.839|feed this directly into language models
1426.44|3.4|and we have to compress it using the B
1428.279|3.361|paare encoding algorithm so let's see
1429.84|3.68|how that works so as I mentioned the B
1431.64|3.88|paare encoding algorithm is not all that
1433.52|3.639|complicated and the Wikipedia page is
1435.52|3.96|actually quite instructive as far as the
1437.159|4.601|basic idea goes go what we're doing is
1439.48|4.16|we have some kind of a input sequence uh
1441.76|4.56|like for example here we have only four
1443.64|4.36|elements in our vocabulary a b c and d
1446.32|3.44|and we have a sequence of them so
1448.0|4.039|instead of bytes let's say we just have
1449.76|4.36|four a vocab size of
1452.039|4.12|four the sequence is too long and we'd
1454.12|6.039|like to compress it so what we do is
1456.159|7.281|that we iteratively find the pair of uh
1460.159|5.12|tokens that occur the most
1463.44|5.04|frequently and then once we've
1465.279|5.601|identified that pair we repl replace
1468.48|5.079|that pair with just a single new token
1470.88|5.399|that we append to our vocabulary so for
1473.559|5.36|example here the bite pair AA occurs
1476.279|5.4|most often so we mint a new token let's
1478.919|7.081|call it capital Z and we replace every
1481.679|7.24|single occurrence of AA by Z so now we
1486.0|5.799|have two Z's here so here we took a
1488.919|5.521|sequence of 11 characters with
1491.799|6.841|vocabulary size four and we've converted
1494.44|6.119|it to a um sequence of only nine tokens
1498.64|3.759|but now with a vocabulary of five
1500.559|4.401|because we have a fifth vocabulary
1502.399|5.121|element that we just created and it's Z
1504.96|5.28|standing for concatination of AA and we
1507.52|5.36|can again repeat this process so we
1510.24|5.4|again look at the sequence and identify
1512.88|6.279|the pair of tokens that are most
1515.64|5.12|frequent let's say that that is now AB
1519.159|4.601|well we are going to replace AB with a
1520.76|4.48|new token that we meant call Y so y
1523.76|4.279|becomes ab and then every single
1525.24|6.2|occurrence of ab is now replaced with y
1528.039|7.12|so we end up with this so now we only
1531.44|8.68|have 1 2 3 4 5 6 seven characters in our
1535.159|7.161|sequence but we have not just um four
1540.12|5.679|vocabulary elements or five but now we
1542.32|5.32|have six and for the final round we
1545.799|4.76|again look through the sequence find
1547.64|5.68|that the phrase zy or the pair zy is
1550.559|6.081|most common and replace it one more time
1553.32|6.599|with another um character let's say x so
1556.64|5.48|X is z y and we replace all curses of zy
1559.919|3.681|and we get this following sequence so
1562.12|6.36|basically after we have gone through
1563.6|6.16|this process instead of having a um
1568.48|5.16|sequence of
1569.76|8.399|11 uh tokens with a vocabulary length of
1573.64|7.84|four we now have a sequence of 1 2 3
1578.159|7.0|four five tokens but our vocabulary
1581.48|5.96|length now is seven and so in this way
1585.159|5.12|we can iteratively compress our sequence
1587.44|4.959|I we Mint new tokens so in the in the
1590.279|5.961|exact same way we start we start out
1592.399|5.801|with bite sequences so we have 256
1596.24|4.4|vocabulary size but we're now going to
1598.2|4.359|go through these and find the bite pairs
1600.64|4.2|that occur the most and we're going to
1602.559|4.201|iteratively start minting new tokens
1604.84|4.04|appending them to our vocabulary and
1606.76|3.48|replacing things and in this way we're
1608.88|4.08|going to end up with a compressed
1610.24|5.039|training data set and also an algorithm
1612.96|5.28|for taking any arbitrary sequence and
1615.279|5.721|encoding it using this uh vocabul
1618.24|5.0|and also decoding it back to Strings so
1621.0|4.679|let's now Implement all that so here's
1623.24|4.08|what I did I went to this block post
1625.679|4.321|that I enjoyed and I took the first
1627.32|5.959|paragraph and I copy pasted it here into
1630.0|5.96|text so this is one very long line
1633.279|4.081|here now to get the tokens as I
1635.96|4.199|mentioned we just take our text and we
1637.36|5.4|encode it into utf8 the tokens here at
1640.159|5.441|this point will be a raw bites single
1642.76|4.88|stream of bytes and just so that it's
1645.6|4.36|easier to work with instead of just a
1647.64|5.0|bytes object I'm going to convert all
1649.96|4.319|those bytes to integers and then create
1652.64|3.24|a list of it just so it's easier for us
1654.279|3.721|to manipulate and work with in Python
1655.88|6.2|and visualize and here I'm printing all
1658.0|7.0|of that so this is the original um this
1662.08|3.719|is the original paragraph and its length
1665.0|4.799|is
1665.799|7.521|533 uh code points and then here are the
1669.799|6.521|bytes encoded in ut utf8 and we see that
1673.32|5.719|this has a length of 616 bytes at this
1676.32|5.52|point or 616 tokens and the reason this
1679.039|5.561|is more is because a lot of these simple
1681.84|4.6|asky characters or simple characters
1684.6|4.16|they just become a single bite but a lot
1686.44|4.64|of these Unicode more complex characters
1688.76|4.0|become multiple bytes up to four and so
1691.08|3.719|we are expanding that
1692.76|3.48|size so now what we'd like to do as a
1694.799|4.12|first step of the algorithm is we'd like
1696.24|5.76|to iterate over here and find the pair
1698.919|5.201|of bites that occur most frequently
1702.0|3.799|because we're then going to merge it so
1704.12|3.64|if you are working long on a notebook on
1705.799|4.12|a side then I encourage you to basically
1707.76|4.12|click on the link find this notebook and
1709.919|3.041|try to write that function yourself
1711.88|3.08|otherwise I'm going to come here and
1712.96|3.959|Implement first the function that finds
1714.96|3.439|the most common pair okay so here's what
1716.919|3.401|I came up with there are many different
1718.399|3.76|ways to implement this but I'm calling
1720.32|4.16|the function get stats it expects a list
1722.159|4.721|of integers I'm using a dictionary to
1724.48|4.36|keep track of basically the counts and
1726.88|4.56|then this is a pythonic way to iterate
1728.84|4.88|consecutive elements of this list uh
1731.44|4.479|which we covered in the previous video
1733.72|4.839|and then here I'm just keeping track of
1735.919|4.48|just incrementing by one um for all the
1738.559|4.84|pairs so if I call this on all the
1740.399|5.76|tokens here then the stats comes out
1743.399|5.52|here so this is the dictionary the keys
1746.159|5.441|are these topples of consecutive
1748.919|5.76|elements and this is the count so just
1751.6|6.0|to uh print it in a slightly better way
1754.679|5.88|this is one way that I like to do that
1757.6|4.76|where you it's a little bit compound
1760.559|4.48|here so you can pause if you like but we
1762.36|5.039|iterate all all the items the items
1765.039|6.76|called on dictionary returns pairs of
1767.399|7.721|key value and instead I create a list
1771.799|5.48|here of value key because if it's a
1775.12|6.24|value key list then I can call sort on
1777.279|6.28|it and by default python will uh use the
1781.36|5.28|first element which in this case will be
1783.559|5.161|value to sort by if it's given tles and
1786.64|4.24|then reverse so it's descending and
1788.72|5.24|print that so basically it looks like
1790.88|4.84|101 comma 32 was the most commonly
1793.96|4.24|occurring consecutive pair and it
1795.72|4.72|occurred 20 times we can double check
1798.2|3.88|that that makes reasonable sense so if I
1800.44|4.76|just search
1802.08|8.04|10132 then you see that these are the 20
1805.2|6.319|occurrences of that um pair and if we'd
1810.12|4.159|like to take a look at what exactly that
1811.519|6.321|pair is we can use Char which is the
1814.279|7.76|opposite of or in Python so we give it a
1817.84|7.16|um unic code Cod point so 101 and of 32
1822.039|6.041|and we see that this is e and space so
1825.0|4.48|basically there's a lot of E space here
1828.08|4.04|meaning that a lot of these words seem
1829.48|4.559|to end with e so here's eace as an
1832.12|4.6|example so there's a lot of that going
1834.039|4.201|on here and this is the most common pair
1836.72|3.64|so now that we've identified the most
1838.24|4.439|common pair we would like to iterate
1840.36|4.439|over this sequence we're going to Mint a
1842.679|5.161|new token with the ID of
1844.799|5.841|256 right because these tokens currently
1847.84|5.0|go from Z to 255 so when we create a new
1850.64|5.36|token it will have an ID of
1852.84|7.0|256 and we're going to iterate over this
1856.0|6.72|entire um list and every every time we
1859.84|4.079|see 101 comma 32 we're going to swap
1862.72|4.52|that out for
1863.919|6.041|256 so let's Implement that now and feel
1867.24|4.72|free to uh do that yourself as well so
1869.96|5.0|first I commented uh this just so we
1871.96|6.0|don't pollute uh the notebook too much
1874.96|5.439|this is a nice way of in Python
1877.96|5.12|obtaining the highest ranking pair so
1880.399|5.921|we're basically calling the Max on this
1883.08|4.599|dictionary stats and this will return
1886.32|3.839|the maximum
1887.679|5.161|key and then the question is how does it
1890.159|5.041|rank keys so you can provide it with a
1892.84|5.36|function that ranks keys and that
1895.2|5.92|function is just stats. getet uh stats.
1898.2|4.599|getet would basically return the value
1901.12|4.36|and so we're ranking by the value and
1902.799|6.401|getting the maximum key so it's 101
1905.48|6.4|comma 32 as we saw now to actually merge
1909.2|4.079|10132 um this is the function that I
1911.88|3.84|wrote but again there are many different
1913.279|4.441|versions of it so we're going to take a
1915.72|4.04|list of IDs and the the pair that we
1917.72|4.52|want to replace and that pair will be
1919.76|5.799|replaced with the new index
1922.24|6.2|idx so iterating through IDs if we find
1925.559|4.96|the pair swap it out for idx so we
1928.44|4.32|create this new list and then we start
1930.519|4.321|at zero and then we go through this
1932.76|4.36|entire list sequentially from left to
1934.84|4.799|right and here we are checking for
1937.12|3.76|equality at the current position with
1939.639|3.76|the
1940.88|4.6|pair um so here we are checking that the
1943.399|3.841|pair matches now here is a bit of a
1945.48|3.6|tricky condition that you have to append
1947.24|4.439|if you're trying to be careful and that
1949.08|4.68|is that um you don't want this here to
1951.679|3.72|be out of Bounds at the very last
1953.76|3.36|position when you're on the rightmost
1955.399|3.88|element of this list otherwise this
1957.12|3.559|would uh give you an autof bounds error
1959.279|4.76|so we have to make sure that we're not
1960.679|5.921|at the very very last element so uh this
1964.039|7.041|would be false for that so if we find a
1966.6|6.72|match we append to this new list that
1971.08|3.719|replacement index and we increment the
1973.32|3.8|position by two so we skip over that
1974.799|4.281|entire pair but otherwise if we we
1977.12|5.0|haven't found a matching pair we just
1979.08|6.16|sort of copy over the um element at that
1982.12|5.24|position and increment by one then
1985.24|5.12|return this so here's a very small toy
1987.36|5.0|example if we have a list 566 791 and we
1990.36|6.0|want to replace the occurrences of 67
1992.36|6.559|with 99 then calling this on that will
1996.36|5.159|give us what we're asking for so here
1998.919|4.841|the 67 is replaced with
2001.519|5.76|99 so now I'm going to uncomment this
2003.76|5.759|for our actual use case where we want to
2007.279|5.841|take our tokens we want to take the top
2009.519|7.721|pair here and replace it with 256 to get
2013.12|7.76|tokens to if we run this we get the
2017.24|7.88|following so recall that previously we
2020.88|7.56|had a length 616 in this list and now we
2025.12|5.039|have a length 596 right so this
2028.44|3.92|decreased by 20 which makes sense
2030.159|5.321|because there are 20 occurrences
2032.36|6.08|moreover we can try to find 256 here and
2035.48|4.28|we see plenty of occurrences on off it
2038.44|4.079|and moreover just double check there
2039.76|5.24|should be no occurrence of 10132 so this
2042.519|3.64|is the original array plenty of them and
2045.0|3.52|in the second array there are no
2046.159|5.44|occurrences of 1032 so we've
2048.52|5.399|successfully merged this single pair and
2051.599|3.881|now we just uh iterate this so we are
2053.919|3.881|going to go over the sequence again find
2055.48|4.0|the most common pair and replace it so
2057.8|4.0|let me now write a y Loop that uses
2059.48|4.8|these functions to do this um sort of
2061.8|4.48|iteratively and how many times do we do
2064.28|3.119|it four well that's totally up to us as
2066.28|4.639|a hyper parameter
2067.399|5.641|the more um steps we take the larger
2070.919|4.2|will be our vocabulary and the shorter
2073.04|4.2|will be our sequence and there is some
2075.119|4.8|sweet spot that we usually find works
2077.24|4.399|the best in practice and so this is kind
2079.919|4.281|of a hyperparameter and we tune it and
2081.639|4.361|we find good vocabulary sizes as an
2084.2|5.679|example gp4 currently uses roughly
2086.0|5.8|100,000 tokens and um bpark that those
2089.879|4.04|are reasonable numbers currently instead
2091.8|4.16|the are large language models so let me
2093.919|4.761|now write uh putting putting it all
2095.96|4.56|together and uh iterating these steps
2098.68|4.6|okay now before we dive into the Y loop
2100.52|4.44|I wanted to add one more cell here where
2103.28|3.72|I went to the block post and instead of
2104.96|3.84|grabbing just the first paragraph or two
2107.0|3.96|I took the entire block post and I
2108.8|3.68|stretched it out in a single line and
2110.96|2.92|basically just using longer text will
2112.48|3.8|allow us to have more representative
2113.88|4.16|statistics for the bite Pairs and we'll
2116.28|5.48|just get a more sensible results out of
2118.04|6.319|it because it's longer text um so here
2121.76|5.88|we have the raw text we encode it into
2124.359|5.72|bytes using the utf8 encoding
2127.64|4.199|and then here as before we are just
2130.079|3.881|changing it into a list of integers in
2131.839|4.841|Python just so it's easier to work with
2133.96|6.8|instead of the raw byes objects and then
2136.68|7.32|this is the code that I came up with uh
2140.76|5.079|to actually do the merging in Loop these
2144.0|4.119|two functions here are identical to what
2145.839|4.041|we had above I only included them here
2148.119|5.24|just so that you have the point of
2149.88|5.12|reference here so uh these two are
2153.359|3.72|identical and then this is the new code
2155.0|3.56|that I added so the first first thing we
2157.079|3.961|want to do is we want to decide on the
2158.56|4.4|final vocabulary size that we want our
2161.04|3.48|tokenizer to have and as I mentioned
2162.96|3.48|this is a hyper parameter and you set it
2164.52|3.96|in some way depending on your best
2166.44|4.399|performance so let's say for us we're
2168.48|4.599|going to use 276 because that way we're
2170.839|4.881|going to be doing exactly 20
2173.079|3.801|merges and uh 20 merges because we
2175.72|5.16|already have
2176.88|6.8|256 tokens for the raw bytes and to
2180.88|4.6|reach 276 we have to do 20 merges uh to
2183.68|4.52|add 20 new
2185.48|6.0|tokens here uh this is uh one way in
2188.2|5.32|Python to just create a copy of a list
2191.48|4.359|so I'm taking the tokens list and by
2193.52|3.64|wrapping it in a list python will
2195.839|2.801|construct a new list of all the
2197.16|2.76|individual elements so this is just a
2198.64|3.439|copy
2199.92|4.919|operation then here I'm creating a
2202.079|4.04|merges uh dictionary so this merges
2204.839|4.561|dictionary is going to maintain
2206.119|6.401|basically the child one child two
2209.4|4.52|mapping to a new uh token and so what
2212.52|4.4|we're going to be building up here is a
2213.92|5.36|binary tree of merges but actually it's
2216.92|4.52|not exactly a tree because a tree would
2219.28|4.16|have a single root node with a bunch of
2221.44|3.56|leaves for us we're starting with the
2223.44|3.48|leaves on the bottom which are the
2225.0|4.52|individual bites those are the starting
2226.92|4.6|256 tokens and then we're starting to
2229.52|5.44|like merge two of them at a time and so
2231.52|7.4|it's not a tree it's more like a forest
2234.96|7.92|um uh as we merge these elements
2238.92|6.159|so for 20 merges we're going to find the
2242.88|5.6|most commonly occurring pair we're going
2245.079|5.0|to Mint a new token integer for it so I
2248.48|3.879|here will start at zero so we'll going
2250.079|4.361|to start at 256 we're going to print
2252.359|3.841|that we're merging it and we're going to
2254.44|5.12|replace all of the occurrences of that
2256.2|5.96|pair with the new new lied token and
2259.56|5.96|we're going to record that this pair of
2262.16|6.919|integers merged into this new
2265.52|5.64|integer so running this gives us the
2269.079|5.401|following
2271.16|5.679|output so we did 20 merges and for
2274.48|4.359|example the first merge was exactly as
2276.839|4.961|before the
2278.839|5.161|10132 um tokens merging into a new token
2281.8|4.799|2556 now keep in mind that the
2284.0|4.44|individual uh tokens 101 and 32 can
2286.599|3.76|still occur in the sequence after
2288.44|4.159|merging it's only when they occur
2290.359|3.521|exactly consecutively that that becomes
2292.599|4.321|256
2293.88|5.28|now um and in particular the other thing
2296.92|4.48|to notice here is that the token 256
2299.16|4.24|which is the newly minted token is also
2301.4|5.439|eligible for merging so here on the
2303.4|5.48|bottom the 20th merge was a merge of 25
2306.839|4.961|and 259 becoming
2308.88|4.76|275 so every time we replace these
2311.8|4.12|tokens they become eligible for merging
2313.64|3.479|in the next round of data ration so
2315.92|2.88|that's why we're building up a small
2317.119|3.081|sort of binary Forest instead of a
2318.8|3.519|single individual
2320.2|3.8|tree one thing we can take a look at as
2322.319|3.841|well is we can take a look at the
2324.0|4.359|compression ratio that we've achieved so
2326.16|5.24|in particular we started off with this
2328.359|7.921|tokens list um so we started off with
2331.4|7.12|24,000 bytes and after merging 20 times
2336.28|5.64|uh we now have only
2338.52|5.12|19,000 um tokens and so therefore the
2341.92|4.88|compression ratio simply just dividing
2343.64|4.32|the two is roughly 1.27 so that's the
2346.8|4.0|amount of compression we were able to
2347.96|5.159|achieve of this text with only 20
2350.8|4.799|merges um and of course the more
2353.119|6.121|vocabulary elements you add uh the
2355.599|8.161|greater the compression ratio here would
2359.24|6.48|be finally so that's kind of like um the
2363.76|4.52|training of the tokenizer if you will
2365.72|5.56|now 1 Point I wanted to make is that and
2368.28|4.799|maybe this is a diagram that can help um
2371.28|3.64|kind of illustrate is that tokenizer is
2373.079|3.921|a completely separate object from the
2374.92|3.12|large language model itself so
2377.0|3.119|everything in this lecture we're not
2378.04|3.799|really touching the llm itself uh we're
2380.119|3.801|just training the tokenizer this is a
2381.839|4.401|completely separate pre-processing stage
2383.92|4.04|usually so the tokenizer will have its
2386.24|3.56|own training set just like a large
2387.96|4.08|language model has a potentially
2389.8|3.6|different training set so the tokenizer
2392.04|2.72|has a training set of documents on which
2393.4|4.36|you're going to train the
2394.76|4.2|tokenizer and then and um we're
2397.76|3.319|performing The Bite pair encoding
2398.96|3.68|algorithm as we saw above to train the
2401.079|3.881|vocabulary of this
2402.64|3.88|tokenizer so it has its own training set
2404.96|4.28|it is a pre-processing stage that you
2406.52|5.44|would run a single time in the beginning
2409.24|5.119|um and the tokenizer is trained using
2411.96|4.359|bipar coding algorithm once you have the
2414.359|4.681|tokenizer once it's trained and you have
2416.319|5.961|the vocabulary and you have the merges
2419.04|5.48|uh we can do both encoding and decoding
2422.28|4.72|so these two arrows here so the
2424.52|5.52|tokenizer is a translation layer between
2427.0|5.52|raw text which is as we saw the sequence
2430.04|5.4|of Unicode code points it can take raw
2432.52|4.48|text and turn it into a token sequence
2435.44|5.32|and vice versa it can take a token
2437.0|6.359|sequence and translate it back into raw
2440.76|5.2|text so now that we have trained uh
2443.359|4.081|tokenizer and we have these merges we
2445.96|3.52|are going to turn to how we can do the
2447.44|3.8|encoding and the decoding step if you
2449.48|3.52|give me text here are the tokens and
2451.24|4.04|vice versa if you give me tokens here's
2453.0|4.52|the text once we have that we can
2455.28|3.48|translate between these two Realms and
2457.52|4.12|then the language model is going to be
2458.76|4.88|trained as a step two afterwards and
2461.64|3.84|typically in a in a sort of a
2463.64|3.199|state-of-the-art application you might
2465.48|2.879|take all of your training data for the
2466.839|3.561|language model and you might run it
2468.359|3.561|through the tokenizer and sort of
2470.4|3.24|translate everything into a massive
2471.92|3.52|token sequence and then you can throw
2473.64|4.08|away the raw text you're just left with
2475.44|4.28|the tokens themselves and those are
2477.72|3.599|stored on disk and that is what the
2479.72|3.52|large language model is actually reading
2481.319|3.481|when it's training on them so this one
2483.24|3.64|approach that you can take as a single
2484.8|5.6|massive pre-processing step a
2486.88|4.52|stage um so yeah basically I think the
2490.4|2.199|most important thing I want to get
2491.4|3.0|across is that this is completely
2492.599|4.24|separate stage it usually has its own
2494.4|3.959|entire uh training set you may want to
2496.839|2.76|have those training sets be different
2498.359|2.921|between the tokenizer and the logge
2499.599|3.72|language model so for example when
2501.28|3.799|you're training the tokenizer as I
2503.319|3.441|mentioned we don't just care about the
2505.079|4.361|performance of English text we care
2506.76|4.76|about uh multi many different languages
2509.44|3.8|and we also care about code or not code
2511.52|3.68|so you may want to look into different
2513.24|4.119|kinds of mixtures of different kinds of
2515.2|5.04|languages and different amounts of code
2517.359|4.601|and things like that because the amount
2520.24|3.52|of different language that you have in
2521.96|4.159|your tokenizer training set will
2523.76|4.48|determine how many merges of it there
2526.119|5.2|will be and therefore that determines
2528.24|6.96|the density with which uh this type of
2531.319|6.441|data is um sort of has in the token
2535.2|4.52|space and so roughly speaking
2537.76|3.599|intuitively if you add some amount of
2539.72|4.32|data like say you have a ton of Japanese
2541.359|4.0|data in your uh tokenizer training set
2544.04|2.799|then that means that more Japanese
2545.359|3.561|tokens will get merged
2546.839|3.801|and therefore Japanese will have shorter
2548.92|3.48|sequences uh and that's going to be
2550.64|3.719|beneficial for the large language model
2552.4|4.199|which has a finite context length on
2554.359|4.881|which it can work on in in the token
2556.599|4.601|space uh so hopefully that makes sense
2559.24|3.839|so we're now going to turn to encoding
2561.2|5.2|and decoding now that we have trained a
2563.079|5.361|tokenizer so we have our merges and now
2566.4|4.04|how do we do encoding and decoding okay
2568.44|4.28|so let's begin with decoding which is
2570.44|4.48|this Arrow over here so given a token
2572.72|4.8|sequence let's go through the tokenizer
2574.92|4.96|to get back a python string object so
2577.52|4.36|the raw text so this is the function
2579.88|3.56|that we' like to implement um we're
2581.88|3.8|given the list of integers and we want
2583.44|3.399|to return a python string if you'd like
2585.68|3.159|uh try to implement this function
2586.839|4.441|yourself it's a fun exercise otherwise
2588.839|4.681|I'm going to start uh pasting in my own
2591.28|5.6|solution so there are many different
2593.52|5.36|ways to do it um here's one way I will
2596.88|4.16|create an uh kind of pre-processing
2598.88|5.8|variable that I will call
2601.04|6.519|vocab and vocab is a mapping or a
2604.68|6.84|dictionary in Python for from the token
2607.559|6.241|uh ID to the bytes object for that token
2611.52|5.319|so we begin with the raw bytes for
2613.8|5.96|tokens from 0 to 255 and then we go in
2616.839|5.441|order of all the merges and we sort of
2619.76|5.96|uh populate this vocab list by doing an
2622.28|5.48|addition here so this is the basically
2625.72|4.32|the bytes representation of the first
2627.76|4.319|child followed by the second one and
2630.04|4.16|remember these are bytes objects so this
2632.079|4.961|addition here is an addition of two
2634.2|4.56|bytes objects just concatenation
2637.04|4.16|so that's what we get
2638.76|4.12|here one tricky thing to be careful with
2641.2|4.8|by the way is that I'm iterating a
2642.88|5.84|dictionary in Python using a DOT items
2646.0|5.48|and uh it really matters that this runs
2648.72|4.839|in the order in which we inserted items
2651.48|3.92|into the merous dictionary luckily
2653.559|3.481|starting with python 3.7 this is
2655.4|3.76|guaranteed to be the case but before
2657.04|3.92|python 3.7 this iteration may have been
2659.16|4.0|out of order with respect to how we
2660.96|4.84|inserted elements into merges and this
2663.16|5.64|may not have worked but we are using an
2665.8|5.799|um modern python so we're okay and then
2668.8|6.24|here uh given the IDS the first thing
2671.599|5.641|we're going to do is get the
2675.04|4.559|tokens so the way I implemented this
2677.24|4.64|here is I'm taking I'm iterating over
2679.599|4.52|all the IDS I'm using vocap to look up
2681.88|4.76|their bytes and then here this is one
2684.119|5.601|way in Python to concatenate all these
2686.64|5.08|bytes together to create our tokens and
2689.72|6.28|then these tokens here at this point are
2691.72|7.48|raw bytes so I have to decode using UTF
2696.0|5.16|F now back into python strings so
2699.2|4.0|previously we called that encode on a
2701.16|4.04|string object to get the bytes and now
2703.2|4.6|we're doing it Opposite we're taking the
2705.2|5.8|bytes and calling a decode on the bytes
2707.8|5.519|object to get a string in Python and
2711.0|5.96|then we can return
2713.319|7.481|text so um this is how we can do it now
2716.96|5.159|this actually has a um issue um in the
2720.8|3.319|way I implemented it and this could
2722.119|4.361|actually throw an error so try to think
2724.119|6.121|figure out why this code could actually
2726.48|6.119|result in an error if we plug in um uh
2730.24|5.0|some sequence of IDs that is
2732.599|4.561|unlucky so let me demonstrate the issue
2735.24|5.839|when I try to decode just something like
2737.16|7.24|97 I am going to get letter A here back
2741.079|7.161|so nothing too crazy happening but when
2744.4|6.919|I try to decode 128 as a single element
2748.24|6.879|the token 128 is what in string or in
2751.319|8.8|Python object uni Cod decoder utfa can't
2755.119|6.801|Decode by um 0x8 which is this in HEX in
2760.119|3.521|position zero invalid start bite what
2761.92|2.84|does that mean well to understand what
2763.64|4.28|this means we have to go back to our
2764.76|6.0|utf8 page uh that I briefly showed
2767.92|5.639|earlier and this is Wikipedia utf8 and
2770.76|6.16|basically there's a specific schema that
2773.559|6.28|utfa bytes take so in particular if you
2776.92|4.6|have a multi-te object for some of the
2779.839|4.321|Unicode characters they have to have
2781.52|5.0|this special sort of envelope in how the
2784.16|5.84|encoding works and so what's happening
2786.52|4.48|here is that invalid start pite that's
2790.0|3.88|because
2791.0|6.359|128 the binary representation of it is
2793.88|5.679|one followed by all zeros so we have one
2797.359|3.681|and then all zero and we see here that
2799.559|3.121|that doesn't conform to the format
2801.04|3.92|because one followed by all zero just
2802.68|4.96|doesn't fit any of these rules so to
2804.96|5.639|speak so it's an invalid start bite
2807.64|5.12|which is byte one this one must have a
2810.599|3.881|one following it and then a zero
2812.76|4.92|following it and then the content of
2814.48|5.48|your uni codee in x here so basically we
2817.68|4.84|don't um exactly follow the utf8
2819.96|6.32|standard and this cannot be decoded and
2822.52|8.52|so the way to fix this um is to
2826.28|7.559|use this errors equals in bytes. decode
2831.04|6.12|function of python and by default errors
2833.839|6.441|is strict so we will throw an error if
2837.16|4.52|um it's not valid utf8 bytes encoding
2840.28|3.4|but there are many different things that
2841.68|3.679|you could put here on error handling
2843.68|3.679|this is the full list of all the errors
2845.359|4.0|that you can use and in particular
2847.359|4.921|instead of strict let's change it to
2849.359|6.441|replace and that will replace uh with
2852.28|8.24|this special marker this replacement
2855.8|7.36|character so errors equals replace and
2860.52|6.44|now we just get that character
2863.16|5.36|back so basically not every single by
2866.96|4.52|sequence is valid
2868.52|5.36|utf8 and if it happens that your large
2871.48|5.16|language model for example predicts your
2873.88|6.36|tokens in a bad manner then they might
2876.64|6.24|not fall into valid utf8 and then we
2880.24|5.4|won't be able to decode them so the
2882.88|4.64|standard practice is to basically uh use
2885.64|4.679|errors equals replace and this is what
2887.52|5.2|you will also find in the openai um code
2890.319|3.881|that they released as well but basically
2892.72|3.28|whenever you see um this kind of a
2894.2|3.96|character in your output in that case uh
2896.0|5.52|something went wrong and the LM output
2898.16|5.32|not was not valid uh sort of sequence of
2901.52|3.799|tokens okay and now we're going to go
2903.48|2.76|the other way so we are going to
2905.319|2.641|implement
2906.24|3.4|this Arrow right here where we are going
2907.96|3.2|to be given a string and we want to
2909.64|4.08|encode it into
2911.16|5.76|tokens so this is the signature of the
2913.72|4.44|function that we're interested in and um
2916.92|4.84|this should basically print a list of
2918.16|4.88|integers of the tokens so again uh try
2921.76|3.799|to maybe implement this yourself if
2923.04|3.48|you'd like a fun exercise uh and pause
2925.559|2.401|here otherwise I'm going to start
2926.52|3.76|putting in my
2927.96|5.68|solution so again there are many ways to
2930.28|7.319|do this so um this is one of the ways
2933.64|5.52|that sort of I came came up with so the
2937.599|2.52|first thing we're going to do is we are
2939.16|4.28|going
2940.119|5.68|to uh take our text encode it into utf8
2943.44|3.84|to get the raw bytes and then as before
2945.799|4.28|we're going to call list on the bytes
2947.28|5.48|object to get a list of integers of
2950.079|4.52|those bytes so those are the starting
2952.76|4.2|tokens those are the raw bytes of our
2954.599|4.96|sequence but now of course according to
2956.96|4.119|the merges dictionary above and recall
2959.559|4.401|this was the
2961.079|5.48|merges some of the bytes may be merged
2963.96|4.2|according to this lookup in addition to
2966.559|3.361|that remember that the merges was built
2968.16|3.199|from top to bottom and this is sort of
2969.92|4.36|the order in which we inserted stuff
2971.359|4.76|into merges and so we prefer to do all
2974.28|4.92|these merges in the beginning before we
2976.119|4.841|do these merges later because um for
2979.2|5.44|example this merge over here relies on
2980.96|5.96|the 256 which got merged here so we have
2984.64|4.28|to go in the order from top to bottom
2986.92|4.52|sort of if we are going to be merging
2988.92|5.6|anything now we expect to be doing a few
2991.44|6.639|merges so we're going to be doing W
2994.52|6.2|true um and now we want to find a pair
2998.079|5.52|of byes that is consecutive that we are
3000.72|4.28|allowed to merge according to this in
3003.599|2.96|order to reuse some of the functionality
3005.0|4.079|that we've already written I'm going to
3006.559|5.52|reuse the function uh get
3009.079|5.161|stats so recall that get stats uh will
3012.079|4.52|give us the we'll basically count up how
3014.24|4.68|many times every single pair occurs in
3016.599|5.48|our sequence of tokens and return that
3018.92|6.679|as a dictionary and the dictionary was a
3022.079|5.321|mapping from all the different uh by
3025.599|4.681|pairs to the number of times that they
3027.4|4.959|occur right um at this point we don't
3030.28|4.079|actually care how many times they occur
3032.359|4.48|in the sequence we only care what the
3034.359|3.921|raw pairs are in that sequence and so
3036.839|3.601|I'm only going to be using basically the
3038.28|4.64|keys of the dictionary I only care about
3040.44|3.32|the set of possible merge candidates if
3042.92|3.24|that makes
3043.76|3.96|sense now we want to identify the pair
3046.16|4.08|that we're going to be merging at this
3047.72|5.52|stage of the loop so what do we want we
3050.24|6.839|want to find the pair or like the a key
3053.24|6.4|inside stats that has the lowest index
3057.079|4.201|in the merges uh dictionary because we
3059.64|3.439|want to do all the early merges before
3061.28|4.039|we work our way to the late
3063.079|4.641|merges so again there are many different
3065.319|5.961|ways to implement this but I'm going to
3067.72|6.48|do something a little bit fancy
3071.28|5.519|here so I'm going to be using the Min
3074.2|4.76|over an iterator in Python when you call
3076.799|4.04|Min on an iterator and stats here as a
3078.96|5.159|dictionary we're going to be iterating
3080.839|6.24|the keys of this dictionary in Python so
3084.119|5.24|we're looking at all the pairs inside
3087.079|5.0|stats um which are all the consecutive
3089.359|5.081|Pairs and we're going to be taking the
3092.079|6.801|consecutive pair inside tokens that has
3094.44|5.879|the minimum what the Min takes a key
3098.88|3.479|which gives us the function that is
3100.319|4.641|going to return a value over which we're
3102.359|4.081|going to do the Min and the one we care
3104.96|5.96|about is we're we care about taking
3106.44|6.399|merges and basically getting um that
3110.92|6.24|pairs
3112.839|6.881|index so basically for any pair inside
3117.16|5.919|stats we are going to be looking into
3119.72|6.119|merges at what index it has and we want
3123.079|4.48|to get the pair with the Min number so
3125.839|4.601|as an example if there's a pair 101 and
3127.559|4.361|32 we definitely want to get that pair
3130.44|4.6|uh we want to identify it here and
3131.92|3.84|return it and pair would become 10132 if
3135.04|2.92|it
3135.76|5.64|occurs and the reason that I'm putting a
3137.96|6.24|float INF here as a fall back is that in
3141.4|5.199|the get function when we call uh when we
3144.2|4.8|basically consider a pair that doesn't
3146.599|5.281|occur in the merges then that pair is
3149.0|4.48|not eligible to be merged right so if in
3151.88|3.679|the token sequence there's some pair
3153.48|4.639|that is not a merging pair it cannot be
3155.559|5.28|merged then uh it doesn't actually occur
3158.119|4.48|here and it doesn't have an index and uh
3160.839|4.24|it cannot be merged which we will denote
3162.599|4.0|as float INF and the reason Infinity is
3165.079|3.0|nice here is because for sure we're
3166.599|3.441|guaranteed that it's not going to
3168.079|5.361|participate in the list of candidates
3170.04|5.84|when we do the men so uh so this is one
3173.44|4.84|way to do it so B basically long story
3175.88|5.239|short this Returns the most eligible
3178.28|5.799|merging candidate pair uh that occurs in
3181.119|6.361|the tokens now one thing to be careful
3184.079|5.801|with here is this uh function here might
3187.48|6.119|fail in the following way if there's
3189.88|7.04|nothing to merge then uh uh then there's
3193.599|4.96|nothing in merges um that satisfi that
3196.92|4.8|is satisfied anymore there's nothing to
3198.559|5.121|merge everything just returns float imps
3201.72|5.24|and then the pair I think will just
3203.68|4.679|become the very first element of stats
3206.96|4.2|um but this pair is not actually a
3208.359|4.921|mergeable pair it just becomes the first
3211.16|5.159|pair inside stats arbitrarily because
3213.28|5.279|all of these pairs evaluate to float in
3216.319|4.04|for the merging Criterion so basically
3218.559|3.081|it could be that this this doesn't look
3220.359|4.281|succeed because there's no more merging
3221.64|5.199|pairs so if this pair is not in merges
3224.64|3.76|that was returned then this is a signal
3226.839|3.881|for us that actually there was nothing
3228.4|4.679|to merge no single pair can be merged
3230.72|7.079|anymore in that case we will break
3233.079|4.72|out um nothing else can be
3237.88|3.16|merged you may come up with a different
3239.839|4.041|implementation by the way this is kind
3241.04|4.92|of like really trying hard in
3243.88|3.919|Python um but really we're just trying
3245.96|3.639|to find a pair that can be merged with
3247.799|6.081|the lowest index
3249.599|6.681|here now if we did find a pair that is
3253.88|5.919|inside merges with the lowest index then
3256.28|3.519|we can merge it
3259.839|4.441|so we're going to look into the merger
3262.04|5.24|dictionary for that pair to look up the
3264.28|4.96|index and we're going to now merge that
3267.28|4.96|into that index so we're going to do
3269.24|5.4|tokens equals and we're going to
3272.24|4.52|replace the original tokens we're going
3274.64|4.32|to be replacing the pair pair and we're
3276.76|4.88|going to be replacing it with index idx
3278.96|4.2|and this returns a new list of tokens
3281.64|4.64|where every occurrence of pair is
3283.16|4.439|replaced with idx so we're doing a merge
3286.28|3.0|and we're going to be continuing this
3287.599|3.681|until eventually nothing can be merged
3289.28|4.039|we'll come out here and we'll break out
3291.28|4.559|and here we just return
3293.319|4.121|tokens and so that that's the
3295.839|6.601|implementation I think so hopefully this
3297.44|7.44|runs okay cool um yeah and this looks uh
3302.44|6.76|reasonable so for example 32 is a space
3304.88|6.6|in asky so that's here um so this looks
3309.2|4.28|like it worked great okay so let's wrap
3311.48|3.4|up this section of the video at least I
3313.48|2.879|wanted to point out that this is not
3314.88|3.08|quite the right implementation just yet
3316.359|4.321|because we are leaving out a special
3317.96|5.599|case so in particular if uh we try to do
3320.68|4.96|this this would give us an error and the
3323.559|4.48|issue is that um if we only have a
3325.64|4.199|single character or an empty string then
3328.039|4.921|stats is empty and that causes an issue
3329.839|6.52|inside Min so one way to fight this is
3332.96|4.879|if L of tokens is at least two because
3336.359|3.72|if it's less than two it's just a single
3337.839|3.681|token or no tokens then let's just uh
3340.079|4.561|there's nothing to merge so we just
3341.52|6.559|return so that would fix uh that
3344.64|5.8|case Okay and then second I have a few
3348.079|5.28|test cases here for us as well so first
3350.44|6.0|let's make sure uh about or let's note
3353.359|5.281|the following if we take a string and we
3356.44|3.8|try to encode it and then decode it back
3358.64|5.159|you'd expect to get the same string back
3360.24|3.559|right is that true for all
3364.68|4.04|strings so I think uh so here it is the
3367.16|4.879|case and I think in general this is
3368.72|5.92|probably the case um but notice that
3372.039|3.881|going backwards is not is not you're not
3374.64|4.56|going to have an identity going
3375.92|7.04|backwards because as I mentioned us not
3379.2|6.24|all token sequences are valid utf8 uh
3382.96|4.24|sort of by streams and so so therefore
3385.44|5.04|you're some of them can't even be
3387.2|5.72|decodable um so this only goes in One
3390.48|4.28|Direction but for that one direction we
3392.92|3.399|can check uh here if we take the
3394.76|3.24|training text which is the text that we
3396.319|3.121|train to tokenizer around we can make
3398.0|3.96|sure that when we encode and decode we
3399.44|4.399|get the same thing back which is true
3401.96|3.639|and here I took some validation data so
3403.839|3.921|I went to I think this web page and I
3405.599|4.081|grabbed some text so this is text that
3407.76|4.96|the tokenizer has not seen and we can
3409.68|4.24|make sure that this also works um okay
3412.72|3.28|so that gives us some confidence that
3413.92|4.119|this was correctly implemented
3416.0|4.72|so those are the basics of the bite pair
3418.039|5.641|encoding algorithm we saw how we can uh
3420.72|4.72|take some training set train a tokenizer
3423.68|4.439|the parameters of this tokenizer really
3425.44|4.159|are just this dictionary of merges and
3428.119|3.44|that basically creates the little binary
3429.599|5.081|Forest on top of raw
3431.559|5.24|bites once we have this the merges table
3434.68|4.72|we can both encode and decode between
3436.799|4.481|raw text and token sequences so that's
3439.4|3.8|the the simplest setting of The
3441.28|3.2|tokenizer what we're going to do now
3443.2|3.359|though is we're going to look at some of
3444.48|3.879|the St the art lar language models and
3446.559|3.0|the kinds of tokenizers that they use
3448.359|3.281|and we're going to see that this picture
3449.559|5.04|complexifies very quickly so we're going
3451.64|5.88|to go through the details of this comp
3454.599|4.44|complexification one at a time so let's
3457.52|4.12|kick things off by looking at the GPD
3459.039|5.601|Series so in particular I have the gpt2
3461.64|6.719|paper here um and this paper is from
3464.64|6.64|2019 or so so 5 years ago and let's
3468.359|4.321|scroll down to input representation this
3471.28|4.36|is where they talk about the tokenizer
3472.68|4.359|that they're using for gpd2 now this is
3475.64|4.399|all fairly readable so I encourage you
3477.039|4.961|to pause and um read this yourself but
3480.039|4.641|this is where they motivate the use of
3482.0|5.52|the bite pair encoding algorithm on the
3484.68|4.84|bite level representation of utf8
3487.52|3.559|encoding so this is where they motivate
3489.52|4.319|it and they talk about the vocabulary
3491.079|4.841|sizes and everything now everything here
3493.839|4.72|is exactly as we've covered it so far
3495.92|4.52|but things start to depart around here
3498.559|3.721|so what they mention is that they don't
3500.44|4.72|just apply the naive algorithm as we
3502.28|4.72|have done it and in particular here's a
3505.16|4.32|example suppose that you have common
3507.0|4.64|words like dog what will happen is that
3509.48|4.8|dog of course occurs very frequently in
3511.64|4.76|the text and it occurs right next to all
3514.28|4.88|kinds of punctuation as an example so
3516.4|5.84|doc dot dog exclamation mark dog
3519.16|4.48|question mark Etc and naively you might
3522.24|3.52|imagine that the BP algorithm could
3523.64|3.8|merge these to be single tokens and then
3525.76|3.24|you end up with lots of tokens that are
3527.44|3.44|just like dog with a slightly different
3529.0|3.039|punctuation and so it feels like you're
3530.88|2.76|clustering things that shouldn't be
3532.039|3.52|clustered you're combining kind of
3533.64|5.28|semantics with
3535.559|5.401|uation and this uh feels suboptimal and
3538.92|3.439|indeed they also say that this is
3540.96|3.24|suboptimal according to some of the
3542.359|3.96|experiments so what they want to do is
3544.2|5.399|they want to top down in a manual way
3546.319|6.441|enforce that some types of um characters
3549.599|5.2|should never be merged together um so
3552.76|4.92|they want to enforce these merging rules
3554.799|5.081|on top of the bite PA encoding algorithm
3557.68|3.8|so let's take a look um at their code
3559.88|3.32|and see how they actually enforce this
3561.48|4.359|and what kinds of mergy they actually do
3563.2|6.44|perform so I have to to tab open here
3565.839|4.841|for gpt2 under open AI on GitHub and
3569.64|4.64|when we go to
3570.68|4.919|Source there is an encoder thatp now I
3574.28|2.799|don't personally love that they call it
3575.599|3.76|encoder dopy because this is the
3577.079|4.801|tokenizer and the tokenizer can do both
3579.359|3.841|encode and decode uh so it feels kind of
3581.88|4.04|awkward to me that it's called encoder
3583.2|3.8|but that is the tokenizer and there's a
3585.92|3.32|lot going on here and we're going to
3587.0|4.599|step through it in detail at one point
3589.24|5.119|for now I just want to focus on this
3591.599|4.641|part here the create a rigix pattern
3594.359|4.321|here that looks very complicated and
3596.24|4.04|we're going to go through it in a bit uh
3598.68|5.32|but this is the core part that allows
3600.28|5.68|them to enforce rules uh for what parts
3604.0|4.64|of the text Will Never Be merged for
3605.96|4.8|sure now notice that re. compile here is
3608.64|3.8|a little bit misleading because we're
3610.76|3.88|not just doing import re which is the
3612.44|5.28|python re module we're doing import reex
3614.64|5.76|as re and reex is a python package that
3617.72|4.359|you can install P install r x and it's
3620.4|2.84|basically an extension of re so it's a
3622.079|3.921|bit more powerful
3623.24|5.64|re um
3626.0|4.799|so let's take a look at this pattern and
3628.88|3.76|what it's doing and why this is actually
3630.799|4.121|doing the separation that they are
3632.64|4.479|looking for okay so I've copy pasted the
3634.92|4.32|pattern here to our jupit notebook where
3637.119|5.0|we left off and let's take this pattern
3639.24|4.839|for a spin so in the exact same way that
3642.119|5.161|their code does we're going to call an
3644.079|5.28|re. findall for this pattern on any
3647.28|3.319|arbitrary string that we are interested
3649.359|5.881|so this is the string that we want to
3650.599|8.44|encode into tokens um to feed into n llm
3655.24|5.799|like gpt2 so what exactly is this doing
3659.039|3.8|well re. findall will take this pattern
3661.039|5.08|and try to match it against a
3662.839|5.121|string um the way this works is that you
3666.119|4.161|are going from left to right in the
3667.96|5.839|string and you're trying to match the
3670.28|6.039|pattern and R.F find all will get all
3673.799|5.361|the occurrences and organize them into a
3676.319|4.561|list now when you look at the um when
3679.16|4.8|you look at this pattern first of all
3680.88|5.439|notice that this is a raw string um and
3683.96|4.879|then these are three double quotes just
3686.319|5.0|to start the string so really the string
3688.839|5.24|itself this is the pattern itself
3691.319|5.161|right and notice that it's made up of a
3694.079|6.121|lot of ores so see these vertical bars
3696.48|5.0|those are ores in reg X and so you go
3700.2|2.96|from left to right in this pattern and
3701.48|4.96|try to match it against the string
3703.16|5.08|wherever you are so we have hello and
3706.44|4.359|we're going to try to match it well it's
3708.24|5.72|not apostrophe s it's not apostrophe t
3710.799|7.32|or any of these but it is an optional
3713.96|8.359|space followed by- P of uh sorry SL P of
3718.119|6.601|L one or more times what is/ P of L it
3722.319|5.681|is coming to some documentation that I
3724.72|6.879|found um there might be other sources as
3728.0|7.039|well uh SLP is a letter any kind of
3731.599|7.921|letter from any language and hello is
3735.039|6.52|made up of letters h e l Etc so optional
3739.52|5.2|space followed by a bunch of letters one
3741.559|5.52|or more letters is going to match hello
3744.72|6.359|but then the match ends because a white
3747.079|6.561|space is not a letter so from there on
3751.079|5.361|begins a new sort of attempt to match
3753.64|4.439|against the string again and starting in
3756.44|3.72|here we're going to skip over all of
3758.079|4.24|these again until we get to the exact
3760.16|4.119|same Point again and we see that there's
3762.319|3.921|an optional space this is the optional
3764.279|4.441|space followed by a bunch of letters one
3766.24|5.76|or more of them and so that matches so
3768.72|7.0|when we run this we get a list of two
3772.0|6.88|elements hello and then space world
3775.72|5.879|so how are you if we add more letters we
3778.88|4.76|would just get them like this now what
3781.599|4.321|is this doing and why is this important
3783.64|5.36|we are taking our string and instead of
3785.92|5.48|directly encoding it um for
3789.0|4.48|tokenization we are first splitting it
3791.4|3.919|up and when you actually step through
3793.48|3.879|the code and we'll do that in a bit more
3795.319|5.601|detail what really is doing on a high
3797.359|7.281|level is that it first splits your text
3800.92|5.639|into a list of texts just like this one
3804.64|4.639|and all these elements of this list are
3806.559|4.201|processed independently by the tokenizer
3809.279|3.0|and all of the results of that
3810.76|5.16|processing are simply
3812.279|7.361|concatenated so hello world oh I I
3815.92|5.679|missed how hello world how are you we
3819.64|4.76|have five elements of list all of these
3821.599|5.401|will independent
3824.4|4.8|independently go from text to a token
3827.0|3.799|sequence and then that token sequence is
3829.2|5.159|going to be concatenated it's all going
3830.799|5.32|to be joined up and roughly speaking
3834.359|4.081|what that does is you're only ever
3836.119|4.24|finding merges between the elements of
3838.44|3.28|this list so you can only ever consider
3840.359|2.881|merges within every one of these
3841.72|4.599|elements in
3843.24|4.68|individually and um after you've done
3846.319|3.561|all the possible merging for all of
3847.92|5.72|these elements individually the results
3849.88|6.36|of all that will be joined um by
3853.64|4.76|concatenation and so you are basically
3856.24|4.76|what what you're doing effectively is
3858.4|4.8|you are never going to be merging this e
3861.0|4.079|with this space because they are now
3863.2|4.52|parts of the separate elements of this
3865.079|3.841|list and so you are saying we are never
3867.72|4.319|going to merge
3868.92|6.8|eace um because we're breaking it up in
3872.039|5.921|this way so basically using this regx
3875.72|6.0|pattern to Chunk Up the text is just one
3877.96|5.8|way of enforcing that some merges are
3881.72|3.48|not to happen and we're going to go into
3883.76|2.48|more of this text and we'll see that
3885.2|2.8|what this is trying to do on a high
3886.24|4.4|level is we're trying to not merge
3888.0|5.2|across letters across numbers across
3890.64|4.08|punctuation and so on so let's see in
3893.2|4.8|more detail how that works so let's
3894.72|7.119|continue now we have/ P ofn if you go to
3898.0|6.44|the documentation SLP of n is any kind
3901.839|4.76|of numeric character in any script so
3904.44|3.679|it's numbers so we have an optional
3906.599|3.76|space followed by numbers and those
3908.119|4.44|would be separated out so letters and
3910.359|5.48|numbers are being separated so if I do
3912.559|5.401|Hello World 123 how are you then world
3915.839|4.801|will stop matching here because one is
3917.96|4.56|not a letter anymore but one is a number
3920.64|5.439|so this group will match for that and
3922.52|3.559|we'll get it as a separate entity
3926.559|4.441|uh let's see how these apostrophes work
3928.359|6.72|so here if we have
3931.0|7.359|um uh Slash V or I mean apostrophe V as
3935.079|4.441|an example then apostrophe here is not a
3938.359|4.081|letter or a
3939.52|5.44|number so hello will stop matching and
3942.44|5.76|then we will exactly match this with
3944.96|5.28|that so that will come out as a separate
3948.2|4.04|thing so why are they doing the
3950.24|3.359|apostrophes here honestly I think that
3952.24|4.72|these are just like very common
3953.599|5.76|apostrophes p uh that are used um
3956.96|3.639|typically I don't love that they've done
3959.359|3.96|this
3960.599|4.841|because uh let me show you what happens
3963.319|4.04|when you have uh some Unicode
3965.44|5.119|apostrophes like for example you can
3967.359|5.68|have if you have house then this will be
3970.559|4.76|separated out because of this matching
3973.039|3.121|but if you use the Unicode apostrophe
3975.319|4.52|like
3976.16|5.399|this then suddenly this does not work
3979.839|5.081|and so this apostrophe will actually
3981.559|4.8|become its own thing now and so so um
3984.92|4.76|it's basically hardcoded for this
3986.359|4.96|specific kind of apostrophe and uh
3989.68|4.359|otherwise they become completely
3991.319|7.161|separate tokens in addition to this you
3994.039|6.161|can go to the gpt2 docs and here when
3998.48|4.52|they Define the pattern they say should
4000.2|4.359|have added re. ignore case so BP merges
4003.0|3.52|can happen for capitalized versions of
4004.559|3.161|contractions so what they're pointing
4006.52|4.319|out is that you see how this is
4007.72|5.2|apostrophe and then lowercase letters
4010.839|5.601|well because they didn't do re. ignore
4012.92|5.96|case then then um these rules will not
4016.44|5.0|separate out the apostrophes if it's
4018.88|7.76|uppercase so
4021.44|8.8|house would be like this but if I did
4026.64|5.639|house if I'm uppercase then notice
4030.24|5.24|suddenly the apostrophe comes by
4032.279|5.161|itself so the tokenization will work
4035.48|3.559|differently in uppercase and lower case
4037.44|3.679|inconsistently separating out these
4039.039|5.481|apostrophes so it feels extremely gnarly
4041.119|6.121|and slightly gross um but that's that's
4044.52|3.92|how that works okay so let's come back
4047.24|3.039|after trying to match a bunch of
4048.44|3.639|apostrophe Expressions by the way the
4050.279|4.28|other issue here is that these are quite
4052.079|3.72|language specific probably so I don't
4054.559|2.921|know that all the languages for example
4055.799|4.161|use or don't use apostrophes but that
4057.48|5.04|would be inconsistently tokenized as a
4059.96|4.92|result then we try to match letters then
4062.52|5.039|we try to match numbers and then if that
4064.88|4.28|doesn't work we fall back to here and
4067.559|3.28|what this is saying is again optional
4069.16|4.8|space followed by something that is not
4070.839|4.96|a letter number or a space in one or
4073.96|3.599|more of that so what this is doing
4075.799|3.721|effectively is this is trying to match
4077.559|4.72|punctuation roughly speaking not letters
4079.52|4.68|and not numbers so this group will try
4082.279|6.201|to trigger for that so if I do something
4084.2|5.76|like this then these parts here are not
4088.48|3.559|letters or numbers but they will
4089.96|4.52|actually they are uh they will actually
4092.039|5.361|get caught here and so they become its
4094.48|5.6|own group so we've separated out the
4097.4|4.759|punctuation and finally this um this is
4100.08|5.279|also a little bit confusing so this is
4102.159|6.881|matching white space but this is using a
4105.359|5.561|negative look ahead assertion in regex
4109.04|4.239|so what this is doing is it's matching
4110.92|4.08|wh space up to but not including the
4113.279|4.641|last Whit space
4115.0|5.279|character why is this important um this
4117.92|3.799|is pretty subtle I think so you see how
4120.279|5.241|the white space is always included at
4121.719|6.361|the beginning of the word so um space r
4125.52|3.88|space u Etc suppose we have a lot of
4128.08|4.279|spaces
4129.4|5.2|here what's going to happen here is that
4132.359|5.561|these spaces up to not including the
4134.6|5.119|last character will get caught by this
4137.92|3.96|and what that will do is it will
4139.719|3.96|separate out the spaces up to but not
4141.88|4.04|including the last character so that the
4143.679|5.56|last character can come here and join
4145.92|5.52|with the um space you and the reason
4149.239|4.56|that's nice is because space you is the
4151.44|4.0|common token so if I didn't have these
4153.799|4.36|Extra Spaces here you would just have
4155.44|5.279|space you and if I add tokens if I add
4158.159|4.801|spaces we still have a space view but
4160.719|4.0|now we have all this extra white space
4162.96|4.48|so basically the GB to tokenizer really
4164.719|5.721|likes to have a space letters or numbers
4167.44|3.96|um and it it preens these spaces and
4170.44|3.239|this is just something that it is
4171.4|5.0|consistent about so that's what that is
4173.679|4.961|for and then finally we have all the the
4176.4|6.319|last fallback is um whites space
4178.64|8.039|characters uh so um that would be
4182.719|5.801|just um if that doesn't get caught then
4186.679|4.08|this thing will catch any trailing
4188.52|4.639|spaces and so on I wanted to show one
4190.759|3.681|more real world example here so if we
4193.159|3.201|have this string which is a piece of
4194.44|3.96|python code and then we try to split it
4196.36|4.2|up then this is the kind of output we
4198.4|4.08|get so you'll notice that the list has
4200.56|4.56|many elements here and that's because we
4202.48|4.64|are splitting up fairly often uh every
4205.12|4.24|time sort of a category
4207.12|3.84|changes um so there will never be any
4209.36|4.12|merges Within These
4210.96|5.48|elements and um that's what you are
4213.48|4.28|seeing here now you might think that in
4216.44|4.68|order to train the
4217.76|6.12|tokenizer uh open AI has used this to
4221.12|4.68|split up text into chunks and then run
4223.88|4.08|just a BP algorithm within all the
4225.8|4.48|chunks but that is not exactly what
4227.96|5.36|happened and the reason is the following
4230.28|5.16|notice that we have the spaces here uh
4233.32|5.04|those Spaces end up being entire
4235.44|5.2|elements but these spaces never actually
4238.36|4.12|end up being merged by by open Ai and
4240.64|3.559|the way you can tell is that if you copy
4242.48|4.8|paste the exact same chunk here into Tik
4244.199|5.081|token U Tik tokenizer you see that all
4247.28|3.72|the spaces are kept independent and
4249.28|4.56|they're all token
4251.0|5.04|220 so I think opena at some point Point
4253.84|5.56|en Force some rule that these spaces
4256.04|5.24|would never be merged and so um there's
4259.4|4.799|some additional rules on top of just
4261.28|5.04|chunking and bpe that open ey is not uh
4264.199|4.48|clear about now the training code for
4266.32|4.48|the gpt2 tokenizer was never released so
4268.679|4.601|all we have is uh the code that I've
4270.8|3.6|already shown you but this code here
4273.28|4.399|that they've released is only the
4274.4|4.68|inference code for the tokens so this is
4277.679|3.841|not the training code you can't give it
4279.08|4.24|a piece of text and training tokenizer
4281.52|4.08|this is just the inference code which
4283.32|5.0|Tak takes the merges that we have up
4285.6|4.96|above and applies them to a new piece of
4288.32|4.16|text and so we don't know exactly how
4290.56|4.08|opening ey trained um train the
4292.48|5.88|tokenizer but it wasn't as simple as
4294.64|5.599|chunk it up and BP it uh whatever it was
4298.36|4.12|next I wanted to introduce you to the
4300.239|4.561|Tik token library from openai which is
4302.48|5.88|the official library for tokenization
4304.8|6.64|from openai so this is Tik token bip
4308.36|6.0|install P to Tik token and then um you
4311.44|4.44|can do the tokenization in inference
4314.36|3.56|this is again not training code this is
4315.88|4.48|only inference code for
4317.92|4.56|tokenization um I wanted to show you how
4320.36|4.0|you would use it quite simple and
4322.48|4.44|running this just gives us the gpt2
4324.36|5.319|tokens or the GPT 4 tokens so this is
4326.92|4.319|the tokenizer use for GPT 4 and so in
4329.679|4.801|particular we see that the Whit space in
4331.239|6.081|gpt2 remains unmerged but in GPT 4 uh
4334.48|4.96|these Whit spaces merge as we also saw
4337.32|5.319|in this one where here they're all
4339.44|5.799|unmerged but if we go down to GPT 4 uh
4342.639|5.121|they become merged
4345.239|5.801|um now in the
4347.76|5.36|gp4 uh tokenizer they changed the
4351.04|4.599|regular expression that they use to
4353.12|4.88|Chunk Up text so the way to see this is
4355.639|5.441|that if you come to your the Tik token
4358.0|6.12|uh library and then you go to this file
4361.08|4.559|Tik token X openi public this is where
4364.12|2.84|sort of like the definition of all these
4365.639|4.921|different tokenizers that openi
4366.96|4.8|maintains is and so uh necessarily to do
4370.56|3.4|the inference they had to publish some
4371.76|3.6|of the details about the strings
4373.96|4.4|so this is the string that we already
4375.36|5.0|saw for gpt2 it is slightly different
4378.36|4.48|but it is actually equivalent uh to what
4380.36|4.6|we discussed here so this pattern that
4382.84|4.16|we discussed is equivalent to this
4384.96|4.279|pattern this one just executes a little
4387.0|3.719|bit faster so here you see a little bit
4389.239|3.48|of a slightly different definition but
4390.719|4.601|otherwise it's the same we're going to
4392.719|5.881|go into special tokens in a bit and then
4395.32|5.44|if you scroll down to CL 100k this is
4398.6|5.36|the GPT 4 tokenizer you see that the
4400.76|5.32|pattern has changed um and this is kind
4403.96|3.4|of like the main the major change in
4406.08|4.32|addition to a bunch of other special
4407.36|4.48|tokens which I'll go into in a bit again
4410.4|2.88|now some I'm not going to actually go
4411.84|3.6|into the full detail of the pattern
4413.28|4.16|change because honestly this is my
4415.44|4.44|numbing uh I would just advise that you
4417.44|4.719|pull out chat GPT and the regex
4419.88|4.64|documentation and just step through it
4422.159|5.921|but really the major changes are number
4424.52|6.56|one you see this eye here that means
4428.08|5.599|that the um case sensitivity this is
4431.08|5.04|case insensitive match and so the
4433.679|4.721|comment that we saw earlier on oh we
4436.12|5.68|should have used re. uppercase uh
4438.4|6.2|basically we're now going to be matching
4441.8|5.12|these apostrophe s apostrophe D
4444.6|4.0|apostrophe M Etc uh we're going to be
4446.92|4.4|matching them both in lowercase and in
4448.6|4.16|uppercase so that's fixed there's a
4451.32|2.76|bunch of different like handling of the
4452.76|3.72|whites space that I'm not going to go
4454.08|4.559|into the full details of and then one
4456.48|4.199|more thing here is you will notice that
4458.639|4.921|when they match the numbers they only
4460.679|5.441|match one to three numbers so so they
4463.56|5.32|will never merge
4466.12|5.039|numbers that are in low in more than
4468.88|5.799|three digits only up to three digits of
4471.159|5.161|numbers will ever be merged and uh
4474.679|3.921|that's one change that they made as well
4476.32|3.68|to prevent uh tokens that are very very
4478.6|3.48|long number
4480.0|4.199|sequences uh but again we don't really
4482.08|4.2|know why they do any of this stuff uh
4484.199|5.321|because none of this is documented and
4486.28|5.48|uh it's just we just get the pattern so
4489.52|4.84|um yeah it is what it is but those are
4491.76|4.6|some of the changes that gp4 has made
4494.36|4.04|and of course the vocabulary size went
4496.36|4.04|from roughly 50k to roughly
4498.4|3.92|100K the next thing I would like to do
4500.4|5.0|very briefly is to take you through the
4502.32|5.04|gpt2 encoder dopy that openi has
4505.4|4.239|released uh this is the file that I
4507.36|5.48|already mentioned to you briefly now
4509.639|5.0|this file is uh fairly short and should
4512.84|5.12|be relatively understandable to you at
4514.639|6.841|this point um starting at the bottom
4517.96|6.199|here they are loading two files encoder
4521.48|3.92|Json and vocab bpe and they do some
4524.159|3.56|light processing on it and then they
4525.4|4.72|call this encoder object which is the
4527.719|4.241|tokenizer now if you'd like to inspect
4530.12|4.44|these two files which together
4531.96|4.16|constitute their saved tokenizer then
4534.56|2.28|you can do that with a piece of code
4536.12|3.2|like
4536.84|3.96|this um this is where you can download
4539.32|3.56|these two files and you can inspect them
4540.8|4.28|if you'd like and what you will find is
4542.88|4.759|that this encoder as they call it in
4545.08|6.72|their code is exactly equivalent to our
4547.639|5.841|vocab so remember here where we have
4551.8|4.2|this vocab object which allowed us us to
4553.48|6.64|decode very efficiently and basically it
4556.0|7.32|took us from the integer to the byes uh
4560.12|7.64|for that integer so our vocab is exactly
4563.32|7.839|their encoder and then their vocab bpe
4567.76|6.24|confusingly is actually are merges so
4571.159|5.52|their BP merges which is based on the
4574.0|6.679|data inside vocab bpe ends up being
4576.679|7.681|equivalent to our merges so uh basically
4580.679|5.56|they are saving and loading the two uh
4584.36|3.96|variables that for us are also critical
4586.239|4.881|the merges variable and the vocab
4588.32|4.24|variable using just these two variables
4591.12|3.4|you can represent a tokenizer and you
4592.56|3.44|can both do encoding and decoding once
4594.52|5.48|you've trained this
4596.0|6.56|tokenizer now the only thing that um is
4600.0|4.52|actually slightly confusing inside what
4602.56|4.32|opening ey does here is that in addition
4604.52|4.0|to this encoder and a decoder they also
4606.88|4.4|have something called a bite encoder and
4608.52|5.44|a bite decoder and this is actually
4611.28|4.6|unfortunately just
4613.96|3.759|kind of a spirous implementation detail
4615.88|3.2|and isn't actually deep or interesting
4617.719|3.321|in any way so I'm going to skip the
4619.08|3.72|discussion of it but what opening ey
4621.04|3.96|does here for reasons that I don't fully
4622.8|3.64|understand is that not only have they
4625.0|3.159|this tokenizer which can encode and
4626.44|3.56|decode but they have a whole separate
4628.159|4.48|layer here in addition that is used
4630.0|6.08|serially with the tokenizer and so you
4632.639|5.04|first do um bite encode and then encode
4636.08|4.159|and then you do decode and then bite
4637.679|5.161|decode so that's the loop and they are
4640.239|4.48|just stacked serial on top of each other
4642.84|3.12|and and it's not that interesting so I
4644.719|3.92|won't cover it and you can step through
4645.96|4.279|it if you'd like otherwise this file if
4648.639|3.241|you ignore the bite encoder and the bite
4650.239|3.721|decoder will be algorithmically very
4651.88|5.16|familiar with you and the meat of it
4653.96|5.679|here is the what they call bpe function
4657.04|4.92|and you should recognize this Loop here
4659.639|3.881|which is very similar to our own y Loop
4661.96|5.0|where they're trying to identify the
4663.52|5.639|Byram uh a pair that they should be
4666.96|4.0|merging next and then here just like we
4669.159|4.441|had they have a for Loop trying to merge
4670.96|4.16|this pair uh so they will go over all of
4673.6|4.24|the sequence and they will merge the
4675.12|4.68|pair whenever they find it and they keep
4677.84|4.52|repeating that until they run out of
4679.8|4.76|possible merges in the in the text so
4682.36|3.68|that's the meat of this file and uh
4684.56|3.599|there's an encode and a decode function
4686.04|3.679|just like we have implemented it so long
4688.159|3.48|story short what I want you to take away
4689.719|3.281|at this point is that unfortunately it's
4691.639|3.481|a little bit of a messy code that they
4693.0|4.719|have but algorithmically it is identical
4695.12|4.039|to what we've built up above and what
4697.719|3.601|we've built up above if you understand
4699.159|4.56|it is algorithmically what is necessary
4701.32|5.52|to actually build a BP to organizer
4703.719|4.561|train it and then both encode and decode
4706.84|4.08|the next topic I would like to turn to
4708.28|4.32|is that of special tokens so in addition
4710.92|4.319|to tokens that are coming from you know
4712.6|4.2|raw bytes and the BP merges we can
4715.239|3.721|insert all kinds of tokens that we are
4716.8|4.24|going to use to delimit different parts
4718.96|5.84|of the data or introduced to create a
4721.04|6.44|special structure of the token streams
4724.8|6.08|so in uh if you look at this encoder
4727.48|4.679|object from open AIS gpd2 right here we
4730.88|3.96|mentioned this is very similar to our
4732.159|5.601|vocab you'll notice that the length of
4734.84|2.92|this is
4738.88|4.48|50257 and as I mentioned it's mapping uh
4741.84|4.28|and it's inverted from the mapping of
4743.36|4.72|our vocab our vocab goes from integer to
4746.12|5.72|string and they go the other way around
4748.08|5.2|for no amazing reason um but the thing
4751.84|3.16|to note here is that this the mapping
4753.28|5.32|table here is
4755.0|5.8|50257 where does that number come from
4758.6|5.8|where what are the tokens as I mentioned
4760.8|6.399|there are 256 raw bite token
4764.4|4.239|tokens and then opena actually did
4767.199|4.801|50,000
4768.639|5.401|merges so those become the other tokens
4772.0|5.679|but this would have been
4774.04|6.48|50256 so what is the 57th token and
4777.679|5.56|there is basically one special
4780.52|6.52|token and that one special token you can
4783.239|6.321|see is called end of text so this is a
4787.04|5.44|special token and it's the very last
4789.56|6.2|token and this token is used to delimit
4792.48|4.84|documents ments in the training set so
4795.76|3.439|when we're creating the training data we
4797.32|4.48|have all these documents and we tokenize
4799.199|6.081|them and we get a stream of tokens those
4801.8|5.6|tokens only range from Z to
4805.28|5.12|50256 and then in between those
4807.4|5.4|documents we put special end of text
4810.4|5.239|token and we insert that token in
4812.8|5.6|between documents and we are using this
4815.639|5.08|as a signal to the language model that
4818.4|4.88|the document has ended and what follows
4820.719|4.48|is going to be unrelated to the document
4823.28|3.919|previously that said the language model
4825.199|4.52|has to learn this from data it it needs
4827.199|4.721|to learn that this token usually means
4829.719|4.321|that it should wipe its sort of memory
4831.92|3.64|of what came before and what came before
4834.04|3.52|this token is not actually informative
4835.56|3.44|to what comes next but we are expecting
4837.56|3.36|the language model to just like learn
4839.0|5.08|this but we're giving it the Special
4840.92|5.759|sort of the limiter of these documents
4844.08|5.4|we can go here to Tech tokenizer and um
4846.679|4.761|this the gpt2 tokenizer uh our code that
4849.48|4.199|we've been playing with before so we can
4851.44|4.4|add here right hello world world how are
4853.679|4.56|you and we're getting different tokens
4855.84|6.359|but now you can see what if what happens
4858.239|5.681|if I put end of text you see how until I
4862.199|4.161|finished it these are all different
4863.92|4.88|tokens end of
4866.36|6.92|text still set different tokens and now
4868.8|7.08|when I finish it suddenly we get token
4873.28|4.959|50256 and the reason this works is
4875.88|6.04|because this didn't actually go through
4878.239|6.761|the bpe merges instead the code that
4881.92|6.12|actually outposted tokens has special
4885.0|5.76|case instructions for handling special
4888.04|4.8|tokens um we did not see these special
4890.76|5.6|instructions for handling special tokens
4892.84|5.16|in the encoder dopy it's absent there
4896.36|4.56|but if you go to Tech token Library
4898.0|4.639|which is uh implemented in Rust you will
4900.92|3.6|find all kinds of special case handling
4902.639|4.481|for these special tokens that you can
4904.52|4.48|register uh create adds to the
4907.12|3.8|vocabulary and then it looks for them
4909.0|4.44|and it uh whenever it sees these special
4910.92|5.16|tokens like this it will actually come
4913.44|4.68|in and swap in that special token so
4916.08|4.48|these things are outside of the typical
4918.12|4.8|algorithm of uh B PA en
4920.56|5.079|coding so these special tokens are used
4922.92|4.48|pervasively uh not just in uh basically
4925.639|3.441|base language modeling of predicting the
4927.4|3.279|next token in the sequence but
4929.08|4.159|especially when it gets to later to the
4930.679|5.0|fine tuning stage and all of the chat uh
4933.239|3.641|gbt sort of aspects of it uh because we
4935.679|3.04|don't just want to Del limit documents
4936.88|4.68|we want to delimit entire conversations
4938.719|5.52|between an assistant and a user so if I
4941.56|4.88|refresh this sck tokenizer page the
4944.239|5.881|default example that they have here is
4946.44|7.16|using not sort of base model encoders
4950.12|5.72|but ftuned model uh sort of tokenizers
4953.6|5.36|um so for example using the GPT 3.5
4955.84|7.399|turbo scheme these here are all special
4958.96|7.88|tokens I am start I end Etc uh this is
4963.239|6.361|short for Imaginary mcore start by the
4966.84|4.359|way but you can see here that there's a
4969.6|2.96|sort of start and end of every single
4971.199|5.321|message and there can be many other
4972.56|6.159|other tokens lots of tokens um in use to
4976.52|4.32|delimit these conversations and kind of
4978.719|5.081|keep track of the flow of the messages
4980.84|5.399|here now we can go back to the Tik token
4983.8|4.359|library and here when you scroll to the
4986.239|4.0|bottom they talk about how you can
4988.159|5.52|extend tick token and I can you can
4990.239|7.081|create basically you can Fork uh the um
4993.679|5.241|CL 100K base tokenizers in gp4 and for
4997.32|3.04|example you can extend it by adding more
4998.92|2.44|special tokens and these are totally up
5000.36|3.4|to you you can come up with any
5001.36|5.16|arbitrary tokens and add them with the
5003.76|6.12|new ID afterwards and the tikken library
5006.52|5.24|will uh correctly swap them out uh when
5009.88|5.08|it sees this in the
5011.76|5.32|strings now we can also go back to this
5014.96|4.719|file which we've looked at previously
5017.08|4.36|and I mentioned that the gpt2 in Tik
5019.679|4.321|toen open
5021.44|4.84|I.P we have the vocabulary we have the
5024.0|4.04|pattern for splitting and then here we
5026.28|4.04|are registering the single special token
5028.04|4.96|in gpd2 which was the end of text token
5030.32|6.08|and we saw that it has this ID
5033.0|4.6|in GPT 4 when they defy this here you
5036.4|2.96|see that the pattern has changed as
5037.6|4.2|we've discussed but also the special
5039.36|4.359|tokens have changed in this tokenizer so
5041.8|5.08|we of course have the end of text just
5043.719|5.801|like in gpd2 but we also see three sorry
5046.88|5.48|four additional tokens here Thim prefix
5049.52|5.36|middle and suffix what is fim fim is
5052.36|4.64|short for fill in the middle and if
5054.88|5.12|you'd like to learn more about this idea
5057.0|4.199|it comes from this paper um and I'm not
5060.0|3.44|going to go into detail in this video
5061.199|5.841|it's beyond this video and then there's
5063.44|6.48|one additional uh serve token here so
5067.04|4.56|that's that encoding as well so it's
5069.92|4.799|very common basically to train a
5071.6|5.92|language model and then if you'd like uh
5074.719|5.081|you can add special tokens now when you
5077.52|4.199|add special tokens you of course have to
5079.8|3.64|um do some model surgery to the
5081.719|3.44|Transformer and all the parameters
5083.44|3.679|involved in that Transformer because you
5085.159|3.401|are basically adding an integer and you
5087.119|3.52|want to make sure that for example your
5088.56|4.48|embedding Matrix for the vocabulary
5090.639|4.241|tokens has to be extended by adding a
5093.04|3.84|row and typically this row would be
5094.88|3.92|initialized uh with small random numbers
5096.88|4.319|or something like that because we need
5098.8|4.48|to have a vector that now stands for
5101.199|3.081|that token in addition to that you have
5103.28|2.399|to go to the final layer of the
5104.28|3.24|Transformer and you have to make sure
5105.679|4.0|that that projection at the very end
5107.52|4.28|into the classifier uh is extended by
5109.679|3.801|one as well so basically there's some
5111.8|4.72|model surgery involved that you have to
5113.48|5.44|couple with the tokenization changes if
5116.52|3.679|you are going to add special tokens but
5118.92|2.88|this is a very common operation that
5120.199|3.52|people do especially if they'd like to
5121.8|4.439|fine tune the model for example taking
5123.719|4.161|it from a base model to a chat model
5126.239|3.601|like chat
5127.88|3.16|GPT okay so at this point you should
5129.84|3.879|have everything you need in order to
5131.04|4.32|build your own gp4 tokenizer now in the
5133.719|3.52|process of developing this lecture I've
5135.36|3.56|done that and I published the code under
5137.239|5.281|this repository
5138.92|6.44|MBP so MBP looks like this right now as
5142.52|4.199|I'm recording but uh the MBP repository
5145.36|4.48|will probably change quite a bit because
5146.719|5.041|I intend to continue working on it um in
5149.84|3.6|addition to the MBP repository I've
5151.76|3.6|published the this uh exercise
5153.44|4.92|progression that you can follow so if
5155.36|5.799|you go to exercise. MD here uh this is
5158.36|5.04|sort of me breaking up the task ahead of
5161.159|5.48|you into four steps that sort of uh
5163.4|5.0|build up to what can be a gp4 tokenizer
5166.639|3.761|and so feel free to follow these steps
5168.4|4.08|exactly and follow a little bit of the
5170.4|4.239|guidance that I've laid out here and
5172.48|5.48|anytime you feel stuck just reference
5174.639|5.441|the MBP repository here so either the
5177.96|4.64|tests could be useful or the MBP
5180.08|6.079|repository itself I try to keep the code
5182.6|6.32|fairly clean and understandable and so
5186.159|4.0|um feel free to reference it whenever um
5188.92|3.64|you get
5190.159|4.52|stuck uh in addition to that basically
5192.56|4.28|once you write it you should be able to
5194.679|4.641|reproduce this behavior from Tech token
5196.84|4.48|so getting the gb4 tokenizer you can
5199.32|3.919|take uh you can encode the string and
5201.32|3.359|you should get these tokens and then you
5203.239|4.0|can encode and decode the exact same
5204.679|3.721|string to recover it and in addition to
5207.239|3.48|all that you should be able to implement
5208.4|4.08|your own train function uh which Tik
5210.719|3.881|token Library does not provide it's it's
5212.48|5.4|again only inference code but you could
5214.6|4.72|write your own train MBP does it as well
5217.88|2.839|and that will allow you to train your
5219.32|3.08|own token
5220.719|5.321|vocabularies so here are some of the
5222.4|6.319|code inside M be mean bpe uh shows the
5226.04|6.36|token vocabularies that you might obtain
5228.719|7.121|so on the left uh here we have the GPT 4
5232.4|5.319|merges uh so the first 256 are raw
5235.84|3.72|individual bytes and then here I am
5237.719|4.041|visualizing the merges that gp4
5239.56|5.36|performed during its training so the
5241.76|5.84|very first merge that gp4 did was merge
5244.92|5.92|two spaces into a single token for you
5247.6|4.639|know two spaces and that is a token 256
5250.84|3.839|and so this is the order in which things
5252.239|6.841|merged during gb4 training and this is
5254.679|6.52|the merge order that um we obtain in MBP
5259.08|4.159|by training a tokenizer and in this case
5261.199|4.401|I trained it on a Wikipedia page of
5263.239|4.561|Taylor Swift uh not because I'm a Swifty
5265.6|4.039|but because that is one of the longest
5267.8|6.24|um Wikipedia Pages apparently that's
5269.639|7.0|available but she is pretty cool and
5274.04|5.04|um what was I going to say yeah so you
5276.639|7.361|can compare these two uh vocabularies
5279.08|7.72|and so as an example um here GPT for
5284.0|6.0|merged I in to become in and we've done
5286.8|6.48|the exact same thing on this token 259
5290.0|4.639|here space t becomes space t and that
5293.28|3.439|happened for us a little bit later as
5294.639|3.761|well so the difference here is again to
5296.719|3.561|my understanding only a difference of
5298.4|3.68|the training set so as an example
5300.28|3.48|because I see a lot of white space I
5302.08|3.4|supect that gp4 probably had a lot of
5303.76|3.84|python code in its training set I'm not
5305.48|4.6|sure uh for the
5307.6|5.36|tokenizer and uh here we see much less
5310.08|4.599|of that of course in the Wikipedia page
5312.96|3.0|so roughly speaking they look the same
5314.679|3.401|and they look the same because they're
5315.96|3.239|running the same algorithm and when you
5318.08|3.119|train your own you're probably going to
5319.199|4.081|get something similar depending on what
5321.199|3.881|you train it on okay so we are now going
5323.28|4.32|to move on from tick token and the way
5325.08|4.119|that open AI tokenizes its strings and
5327.6|3.4|we're going to discuss one more very
5329.199|3.52|commonly used library for working with
5331.0|4.36|tokenization inlm
5332.719|5.44|and that is sentence piece so sentence
5335.36|4.759|piece is very commonly used in language
5338.159|4.201|models because unlike Tik token it can
5340.119|4.721|do both training and inference and is
5342.36|4.4|quite efficient at both it supports a
5344.84|4.359|number of algorithms for training uh
5346.76|3.68|vocabularies but one of them is the B
5349.199|4.44|pair en coding algorithm that we've been
5350.44|5.279|looking at so it supports it now
5353.639|4.56|sentence piece is used both by llama and
5355.719|5.041|mistal series and many other models as
5358.199|4.561|well it is on GitHub under Google
5360.76|3.64|sentence piece
5362.76|3.439|and the big difference with sentence
5364.4|3.52|piece and we're going to look at example
5366.199|4.841|because this is kind of hard and subtle
5367.92|7.56|to explain is that they think different
5371.04|7.52|about the order of operations here so in
5375.48|5.52|the case of Tik token we first take our
5378.56|4.32|code points in the string we encode them
5381.0|3.96|using mutf to bytes and then we're
5382.88|6.0|merging bytes it's fairly
5384.96|5.44|straightforward for sentence piece um it
5388.88|3.64|works directly on the level of the code
5390.4|3.52|points themselves so so it looks at
5392.52|3.36|whatever code points are available in
5393.92|5.84|your training set and then it starts
5395.88|5.72|merging those code points and um the bpe
5399.76|4.479|is running on the level of code
5401.6|5.16|points and if you happen to run out of
5404.239|3.801|code points so there are maybe some rare
5406.76|2.959|uh code points that just don't come up
5408.04|3.159|too often and the Rarity is determined
5409.719|4.641|by this character coverage hyper
5411.199|5.081|parameter then these uh code points will
5414.36|5.16|either get mapped to a special unknown
5416.28|5.839|token like ank or if you have the bite
5419.52|4.44|foldback option turned on then that will
5422.119|3.961|take those rare Cod points it will
5423.96|3.8|encode them using utf8 and then the
5426.08|4.039|individual bytes of that encoding will
5427.76|4.439|be translated into tokens and there are
5430.119|5.401|these special bite tokens that basically
5432.199|6.04|get added to the vocabulary so it uses
5435.52|6.28|BP on on the code points and then it
5438.239|5.841|falls back to bytes for rare Cod points
5441.8|3.72|um and so that's kind of like difference
5444.08|3.4|personally I find the Tik token we
5445.52|3.32|significantly cleaner uh but it's kind
5447.48|2.84|of like a subtle but pretty major
5448.84|3.2|difference between the way they approach
5450.32|3.68|tokenization let's work with with a
5452.04|4.679|concrete example because otherwise this
5454.0|5.119|is kind of hard to um to get your head
5456.719|4.4|around so let's work with a concrete
5459.119|4.481|example this is how we can import
5461.119|4.08|sentence piece and then here we're going
5463.6|3.16|to take I think I took like the
5465.199|3.48|description of sentence piece and I just
5466.76|3.64|created like a little toy data set it
5468.679|4.401|really likes to have a file so I created
5470.4|5.12|a toy. txt file with this
5473.08|3.68|content now what's kind of a little bit
5475.52|3.159|crazy about sentence piece is that
5476.76|4.04|there's a ton of options and
5478.679|3.52|configurations and the reason this is so
5480.8|3.04|is because sentence piece has been
5482.199|3.561|around I think for a while and it really
5483.84|4.6|tries to handle a large diversity of
5485.76|4.76|things and um because it's been around I
5488.44|5.239|think it has quite a bit of accumulated
5490.52|5.04|historical baggage uh as well and so in
5493.679|3.281|particular there's like a ton of
5495.56|4.24|configuration arguments this is not even
5496.96|4.0|all of it you can go to here to see all
5499.8|4.6|the training
5500.96|4.759|options um and uh there's also quite
5504.4|4.2|useful documentation when you look at
5505.719|6.721|the raw Proto buff uh that is used to
5508.6|5.92|represent the trainer spec and so on um
5512.44|4.52|many of these options are irrelevant to
5514.52|5.32|us so maybe to point out one example Das
5516.96|4.32|Das shrinking Factor uh this shrinking
5519.84|3.319|factor is not used in the B pair en
5521.28|4.64|coding algorithm so this is just an
5523.159|5.881|argument that is irrelevant to us um it
5525.92|3.12|applies to a different training
5529.52|4.36|algorithm now what I tried to do here is
5531.92|3.799|I tried to set up sentence piece in a
5533.88|5.0|way that is very very similar as far as
5535.719|6.361|I can tell to maybe identical hopefully
5538.88|6.16|to the way that llama 2 was strained so
5542.08|5.039|the way they trained their own um their
5545.04|3.679|own tokenizer and the way I did this was
5547.119|4.281|basically you can take the tokenizer
5548.719|6.48|model file that meta released and you
5551.4|6.96|can um open it using the Proto protuff
5555.199|4.52|uh sort of file that you can generate
5558.36|3.0|and then you can inspect all the options
5559.719|3.96|and I tried to copy over all the options
5561.36|5.24|that looked relevant so here we set up
5563.679|4.401|the input it's raw text in this file
5566.6|4.16|here's going to be the output so it's
5568.08|4.36|going to be for talk 400. model and
5570.76|2.64|vocab
5572.44|3.6|we're saying that we're going to use the
5573.4|5.2|BP algorithm and we want to Bap size of
5576.04|4.84|400 then there's a ton of configurations
5578.6|2.28|here
5581.08|6.0|for um for basically pre-processing and
5585.08|4.4|normalization rules as they're called
5587.08|4.079|normalization used to be very prevalent
5589.48|3.32|I would say before llms in natural
5591.159|3.721|language processing so in machine
5592.8|3.919|translation and uh text classification
5594.88|3.12|and so on you want to normalize and
5596.719|2.801|simplify the text and you want to turn
5598.0|4.199|it all lowercase and you want to remove
5599.52|4.24|all double whites space Etc
5602.199|3.081|and in language models we prefer not to
5603.76|3.2|do any of it or at least that is my
5605.28|3.56|preference as a deep learning person you
5606.96|4.719|want to not touch your data you want to
5608.84|4.279|keep the raw data as much as possible um
5611.679|3.48|in a raw
5613.119|4.881|form so you're basically trying to turn
5615.159|4.361|off a lot of this if you can the other
5618.0|5.04|thing that sentence piece does is that
5619.52|5.96|it has this concept of sentences so
5623.04|3.8|sentence piece it's back it's kind of
5625.48|4.679|like was developed I think early in the
5626.84|5.12|days where there was um an idea that
5630.159|4.04|they you're training a tokenizer on a
5631.96|4.4|bunch of independent sentences so it has
5634.199|3.801|a lot of like how many sentences you're
5636.36|4.319|going to train on what is the maximum
5638.0|5.719|sentence length
5640.679|4.121|um shuffling sentences and so for it
5643.719|3.161|sentences are kind of like the
5644.8|3.919|individual training examples but again
5646.88|3.56|in the context of llms I find that this
5648.719|5.201|is like a very spous and weird
5650.44|5.16|distinction like sentences are just like
5653.92|4.759|don't touch the raw data sentences
5655.6|5.0|happen to exist but in raw data sets
5658.679|3.761|there are a lot of like inet like what
5660.6|4.4|exactly is a sentence what isn't a
5662.44|4.04|sentence um and so I think like it's
5665.0|3.639|really hard to Define what an actual
5666.48|4.44|sentence is if you really like dig into
5668.639|3.48|it and there could be different concepts
5670.92|2.799|of it in different languages or
5672.119|3.441|something like that so why even
5673.719|3.201|introduce the concept it it doesn't
5675.56|3.639|honestly make sense to me I would just
5676.92|3.44|prefer to treat a file as a giant uh
5679.199|3.601|stream of
5680.36|4.759|bytes it has a lot of treatment around
5682.8|3.68|rare word characters and when I say word
5685.119|3.56|I mean code points we're going to come
5686.48|5.199|back to this in a second and it has a
5688.679|5.801|lot of other rules for um basically
5691.679|4.881|splitting digits splitting white space
5694.48|3.719|and numbers and how you deal with that
5696.56|3.52|so these are some kind of like merge
5698.199|4.721|rules so I think this is a little bit
5700.08|4.44|equivalent to tick token using the
5702.92|4.12|regular expression to split up
5704.52|4.719|categories there's like kind of
5707.04|3.599|equivalence of it if you squint T it in
5709.239|4.96|sentence piece where you can also for
5710.639|5.201|example split up split up the digits uh
5714.199|4.0|and uh so
5715.84|3.52|on there's a few more things here that
5718.199|2.281|I'll come back to in a bit and then
5719.36|4.0|there are some special tokens that you
5720.48|5.08|can indicate and it hardcodes the UN
5723.36|5.96|token the beginning of sentence end of
5725.56|6.96|sentence and a pad token um and the UN
5729.32|5.399|token must exist for my understanding
5732.52|4.76|and then some some things so we can
5734.719|5.4|train and when when I press train it's
5737.28|5.879|going to create this file talk 400.
5740.119|5.441|model and talk 400. wab I can then load
5743.159|5.401|the model file and I can inspect the
5745.56|7.76|vocabulary off it and so we trained
5748.56|6.44|vocab size 400 on this text here and
5753.32|3.56|these are the individual pieces the
5755.0|3.8|individual tokens that sentence piece
5756.88|5.2|will create so in the beginning we see
5758.8|5.24|that we have the an token uh with the ID
5762.08|5.72|zero then we have the beginning of
5764.04|5.28|sequence end of sequence one and two and
5767.8|4.28|then we said that the pad ID is negative
5769.32|4.16|1 so we chose not to use it so there's
5772.08|4.76|no pad ID
5773.48|6.679|here then these are individual bite
5776.84|6.72|tokens so here we saw that bite fallback
5780.159|6.0|in llama was turned on so it's true so
5783.56|3.639|what follows are going to be the 256
5786.159|4.681|bite
5787.199|3.641|tokens and these are their
5791.719|5.96|IDs and then at the bottom after the
5795.04|5.52|bite tokens come the
5797.679|4.52|merges and these are the parent nodes in
5800.56|3.159|the merges so we're not seeing the
5802.199|2.401|children we're just seeing the parents
5803.719|3.321|and their
5804.6|6.119|ID and then after the
5807.04|6.52|merges comes eventually the individual
5810.719|4.601|tokens and their IDs and so these are
5813.56|4.679|the individual tokens so these are the
5815.32|4.96|individual code Point tokens if you will
5818.239|3.521|and they come at the end so that is the
5820.28|3.64|ordering with which sentence piece sort
5821.76|4.359|of like represents its vocabularies it
5823.92|4.239|starts with special tokens then the bike
5826.119|5.52|tokens then the merge tokens and then
5828.159|5.881|the individual codo tokens and all these
5831.639|4.48|raw codepoint to tokens are the ones
5834.04|5.76|that it encountered in the training
5836.119|6.04|set so those individual code points are
5839.8|4.6|all the the entire set of code points
5842.159|5.321|that occurred
5844.4|4.88|here so those all get put in there and
5847.48|3.639|then those that are extremely rare as
5849.28|3.24|determined by character coverage so if a
5851.119|4.04|code Point occurred only a single time
5852.52|4.56|out of like a million um sentences or
5855.159|5.04|something like that then it would be
5857.08|3.96|ignored and it would not be added to our
5860.199|3.161|uh
5861.04|5.44|vocabulary once we have a vocabulary we
5863.36|4.04|can encode into IDs and we can um sort
5866.48|4.199|of get a
5867.4|6.92|list and then here I am also decoding
5870.679|6.281|the indiv idual tokens back into little
5874.32|6.76|pieces as they call it so let's take a
5876.96|7.719|look at what happened here hello space
5881.08|6.4|on so these are the token IDs we got
5884.679|6.841|back and when we look here uh a few
5887.48|6.679|things sort of uh jump to mind number
5891.52|4.0|one take a look at these characters the
5894.159|3.841|Korean characters of course were not
5895.52|4.079|part of the training set so sentence
5898.0|4.199|piece is encountering code points that
5899.599|4.961|it has not seen during training time and
5902.199|4.201|those code points do not have a token
5904.56|6.0|associated with them so suddenly these
5906.4|7.44|are un tokens unknown tokens but because
5910.56|5.88|bite fall back as true instead sentence
5913.84|6.0|piece falls back to bytes and so it
5916.44|6.84|takes this it encodes it with utf8 and
5919.84|5.96|then it uses these tokens to represent
5923.28|6.439|uh those bytes and that's what we are
5925.8|7.08|getting sort of here this is the utf8 uh
5929.719|6.52|encoding and in this shifted by three uh
5932.88|5.96|because of these um special tokens here
5936.239|6.681|that have IDs earlier on so that's what
5938.84|6.68|happened here now one more thing that um
5942.92|5.319|well first before I go on with respect
5945.52|5.32|to the bitef back let me remove bite
5948.239|4.281|foldback if this is false what's going
5950.84|3.6|to happen let's
5952.52|4.76|retrain so the first thing that happened
5954.44|4.56|is all the bite tokens disappeared right
5957.28|3.2|and now we just have the merges and we
5959.0|2.8|have a lot more merges now because we
5960.48|4.56|have a lot more space because we're not
5961.8|4.16|taking up space in the wab size uh with
5965.04|4.04|all the
5965.96|7.279|bytes and now if we encode
5969.08|6.039|this we get a zero so this entire string
5973.239|6.161|here suddenly there's no bitef back so
5975.119|6.921|this is unknown and unknown is an and so
5979.4|5.52|this is zero because the an token is
5982.04|4.84|token zero and you have to keep in mind
5984.92|3.48|that this would feed into your uh
5986.88|3.04|language model so what is a language
5988.4|3.759|model supposed to do when all kinds of
5989.92|4.08|different things that are unrecognized
5992.159|3.96|because they're rare just end up mapping
5994.0|3.76|into Unk it's not exactly the property
5996.119|5.921|that you want so that's why I think
5997.76|5.959|llama correctly uh used by fallback true
6002.04|4.0|uh because we definitely want to feed
6003.719|4.841|these um unknown or rare code points
6006.04|4.639|into the model and some uh some manner
6008.56|3.92|the next thing I want to show you is the
6010.679|4.04|following notice here when we are
6012.48|5.56|decoding all the individual tokens you
6014.719|6.52|see how spaces uh space here ends up
6018.04|5.04|being this um bold underline I'm not
6021.239|4.121|100% sure by the way why sentence piece
6023.08|4.559|switches whites space into these bold
6025.36|4.52|underscore characters maybe it's for
6027.639|4.801|visualization I'm not 100% sure why that
6029.88|7.56|happens uh but notice this why do we
6032.44|8.04|have an extra space in the front of
6037.44|5.719|hello um what where is this coming from
6040.48|4.56|well it's coming from this option
6043.159|5.201|here
6045.04|4.52|um add dummy prefix is true and when you
6048.36|3.52|go to the
6049.56|3.8|documentation add D whites space at the
6051.88|4.04|beginning of text in order to treat
6053.36|4.6|World in world and hello world in the
6055.92|3.319|exact same way so what this is trying to
6057.96|4.08|do is the
6059.239|7.081|following if we go back to our tick
6062.04|8.199|tokenizer world as uh token by itself
6066.32|8.279|has a different ID than space world so
6070.239|5.761|we have this is 1917 but this is 14 Etc
6074.599|2.801|so these are two different tokens for
6076.0|2.88|the language model and the language
6077.4|2.92|model has to learn from data that they
6078.88|4.12|are actually kind of like a very similar
6080.32|5.68|concept so to the language model in the
6083.0|4.639|Tik token World um basically words in
6086.0|3.04|the beginning of sentences and words in
6087.639|4.401|the middle of sentences actually look
6089.04|5.4|completely different um and it has to
6092.04|4.88|learned that they are roughly the same
6094.44|4.52|so this add dami prefix is trying to
6096.92|4.799|fight that a little bit and the way that
6098.96|7.8|works is that it basically
6101.719|7.361|uh adds a dummy prefix so for as a as a
6106.76|4.56|part of pre-processing it will take the
6109.08|5.84|string and it will add a space it will
6111.32|6.2|do this and that's done in an effort to
6114.92|5.36|make this world and that world the same
6117.52|4.639|they will both be space world so that's
6120.28|5.0|one other kind of pre-processing option
6122.159|5.241|that is turned on and llama 2 also uh
6125.28|3.359|uses this option and that's I think
6127.4|3.04|everything that I want to say for my
6128.639|4.48|preview of sentence piece and how it is
6130.44|6.279|different um maybe here what I've done
6133.119|6.721|is I just uh put in the Raw protocol
6136.719|6.161|buffer representation basically of the
6139.84|4.92|tokenizer the too trained so feel free
6142.88|4.12|to sort of Step through this and if you
6144.76|5.56|would like uh your tokenization to look
6147.0|4.679|identical to that of the meta uh llama 2
6150.32|4.44|then you would be copy pasting these
6151.679|5.281|settings as I tried to do up above and
6154.76|4.12|uh yeah that's I think that's it for
6156.96|3.84|this section I think my summary for
6158.88|3.56|sentence piece from all of this is
6160.8|3.48|number one I think that there's a lot of
6162.44|3.239|historical baggage in sentence piece a
6164.28|2.959|lot of Concepts that I think are
6165.679|3.721|slightly confusing and I think
6167.239|3.561|potentially um contain foot guns like
6169.4|4.319|this concept of a sentence and it's
6170.8|5.08|maximum length and stuff like that um
6173.719|5.161|otherwise it is fairly commonly used in
6175.88|5.12|the industry um because it is efficient
6178.88|3.88|and can do both training and inference
6181.0|4.08|uh it has a few quirks like for example
6182.76|3.8|un token must exist and the way the bite
6185.08|3.28|fallbacks are done and so on I don't
6186.56|3.0|find particularly elegant and
6188.36|3.08|unfortunately I have to say it's not
6189.56|5.2|very well documented so it took me a lot
6191.44|4.719|of time working with this myself um and
6194.76|3.04|just visualizing things and trying to
6196.159|3.121|really understand what is happening here
6197.8|3.64|because uh the documentation
6199.28|5.399|unfortunately is in my opion not not
6201.44|4.719|super amazing but it is a very nice repo
6204.679|3.52|that is available to you if you'd like
6206.159|3.48|to train your own tokenizer right now
6208.199|3.52|okay let me now switch gears again as
6209.639|3.721|we're starting to slowly wrap up here I
6211.719|3.601|want to revisit this issue in a bit more
6213.36|2.839|detail of how we should set the vocap
6215.32|4.319|size and what are some of the
6216.199|4.641|considerations around it so for this I'd
6219.639|2.52|like to go back to the model
6220.84|3.839|architecture that we developed in the
6222.159|5.241|last video when we built the GPT from
6224.679|4.401|scratch so this here was uh the file
6227.4|3.92|that we built in the previous video and
6229.08|3.8|we defined the Transformer model and and
6231.32|3.879|let's specifically look at Bap size and
6232.88|5.279|where it appears in this file so here we
6235.199|4.761|Define the voap size uh at this time it
6238.159|3.921|was 65 or something like that extremely
6239.96|4.32|small number so this will grow much
6242.08|4.079|larger you'll see that Bap size doesn't
6244.28|4.24|come up too much in most of these layers
6246.159|5.321|the only place that it comes up to is in
6248.52|5.04|exactly these two places here so when we
6251.48|4.32|Define the language model there's the
6253.56|4.52|token embedding table which is this
6255.8|5.399|two-dimensional array where the vocap
6258.08|5.84|size is basically the number of rows and
6261.199|4.721|uh each vocabulary element each token
6263.92|4.04|has a vector that we're going to train
6265.92|3.52|using back propagation that Vector is of
6267.96|3.639|size and embed which is number of
6269.44|4.239|channels in the Transformer and
6271.599|4.08|basically as voap size increases this
6273.679|3.321|embedding table as I mentioned earlier
6275.679|4.04|is going to also grow we're going to be
6277.0|4.88|adding rows in addition to that at the
6279.719|4.52|end of the Transformer there's this LM
6281.88|4.4|head layer which is a linear layer and
6284.239|4.4|you'll notice that that layer is used at
6286.28|3.68|the very end to produce the logits uh
6288.639|3.121|which become the probabilities for the
6289.96|3.96|next token in sequence and so
6291.76|4.479|intuitively we're trying to produce a
6293.92|4.92|probability for every single token that
6296.239|4.841|might come next at every point in time
6298.84|3.839|of that Transformer and if we have more
6301.08|3.84|and more tokens we need to produce more
6302.679|3.52|and more probabilities so every single
6304.92|3.239|token is going to introduce an
6306.199|4.0|additional dot product that we have to
6308.159|3.281|do here in this linear layer for this
6310.199|4.361|final layer in a
6311.44|5.08|Transformer so why can't vocap size be
6314.56|3.639|infinite why can't we grow to Infinity
6316.52|5.04|well number one your token embedding
6318.199|5.4|table is going to grow uh your linear
6321.56|3.559|layer is going to grow so we're going to
6323.599|2.961|be doing a lot more computation here
6325.119|4.0|because this LM head layer will become
6326.56|4.28|more computational expensive number two
6329.119|4.321|because we have more parameters we could
6330.84|4.359|be worried that we are going to be under
6333.44|3.96|trining some of these
6335.199|3.761|parameters so intuitively if you have a
6337.4|3.92|very large vocabulary size say we have a
6338.96|3.719|million uh tokens then every one of
6341.32|3.72|these tokens is going to come up more
6342.679|3.841|and more rarely in the training data
6345.04|3.52|because there's a lot more other tokens
6346.52|4.48|all over the place and so we're going to
6348.56|4.72|be seeing fewer and fewer examples uh
6351.0|4.0|for each individual token and you might
6353.28|3.0|be worried that basically the vectors
6355.0|3.28|associated with every token will be
6356.28|3.64|undertrained as a result because they
6358.28|2.68|just don't come up too often and they
6359.92|3.279|don't participate in the forward
6360.96|3.92|backward pass in addition to that as
6363.199|3.841|your vocab size grows you're going to
6364.88|4.44|start shrinking your sequences a lot
6367.04|3.079|right and that's really nice because
6369.32|2.68|that means that we're going to be
6370.119|3.48|attending to more and more text so
6372.0|3.92|that's nice but also you might be
6373.599|4.961|worrying that two large of chunks are
6375.92|4.799|being squished into single tokens and so
6378.56|6.52|the model just doesn't have as much of
6380.719|5.96|time to think per sort of um some number
6385.08|3.0|of characters in the text or you can
6386.679|2.801|think about it that way right so
6388.08|3.559|basically we're squishing too much
6389.48|3.56|information into a single token and then
6391.639|2.761|the forward pass of the Transformer is
6393.04|3.4|not enough to actually process that
6394.4|3.08|information appropriately and so these
6396.44|2.199|are some of the considerations you're
6397.48|3.159|thinking about when you're designing the
6398.639|4.241|vocab size as I mentioned this is mostly
6400.639|3.6|an empirical hyperparameter and it seems
6402.88|3.88|like in state-of-the-art architectures
6404.239|5.121|today this is usually in the high 10,000
6406.76|4.12|or somewhere around 100,000 today and
6409.36|3.64|the next consideration I want to briefly
6410.88|4.319|talk about is what if we want to take a
6413.0|4.36|pre-trained model and we want to extend
6415.199|3.681|the vocap size and this is done fairly
6417.36|4.799|commonly actually so for example when
6418.88|4.88|you're doing fine-tuning for cha GPT um
6422.159|3.641|a lot more new special tokens get
6423.76|4.28|introduced on top of the base model to
6425.8|4.08|maintain the metadata and all the
6428.04|3.88|structure of conversation objects
6429.88|4.16|between a user and an assistant so that
6431.92|3.96|takes a lot of special tokens you might
6434.04|3.76|also try to throw in more special tokens
6435.88|4.759|for example for using the browser or any
6437.8|4.359|other tool and so it's very tempting to
6440.639|3.881|add a lot of tokens for all kinds of
6442.159|3.641|special functionality so if you want to
6444.52|3.199|be adding a token that's totally
6445.8|4.08|possible Right all we have to do is we
6447.719|4.761|have to resize this embedding so we have
6449.88|4.56|to add rows we would initialize these uh
6452.48|3.639|parameters from scratch to be small
6454.44|4.84|random numbers and then we have to
6456.119|5.321|extend the weight inside this linear uh
6459.28|3.919|so we have to start making dot products
6461.44|3.12|um with the associated parameters as
6463.199|3.561|well to basically calculate the
6464.56|4.079|probabilities for these new tokens so
6466.76|4.08|both of these are just a resizing
6468.639|3.96|operation it's a very mild
6470.84|3.2|model surgery and can be done fairly
6472.599|2.761|easily and it's quite common that
6474.04|3.4|basically you would freeze the base
6475.36|3.279|model you introduce these new parameters
6477.44|3.12|and then you only train these new
6478.639|4.48|parameters to introduce new tokens into
6480.56|4.4|the architecture um and so you can
6483.119|3.281|freeze arbitrary parts of it or you can
6484.96|3.36|train arbitrary parts of it and that's
6486.4|3.719|totally up to you but basically minor
6488.32|3.56|surgery required if you'd like to
6490.119|3.241|introduce new tokens and finally I'd
6491.88|4.04|like to mention that actually there's an
6493.36|4.279|entire design space of applications in
6495.92|3.44|terms of introducing new tokens into a
6497.639|3.56|vocabulary that go Way Beyond just
6499.36|3.64|adding special tokens and special new
6501.199|3.161|functionality so just to give you a
6503.0|3.599|sense of the design space but this could
6504.36|4.279|be an entire video just by itself uh
6506.599|4.441|this is a paper on learning to compress
6508.639|4.761|prompts with what they called uh gist
6511.04|3.639|tokens and the rough idea is suppose
6513.4|3.759|that you're using language models in a
6514.679|4.121|setting that requires very long prompts
6517.159|2.681|while these long prompts just slow
6518.8|2.6|everything down because you have to
6519.84|3.279|encode them and then you have to use
6521.4|3.719|them and then you're tending over them
6523.119|4.52|and it's just um you know heavy to have
6525.119|5.56|very large prompts so instead what they
6527.639|6.921|do here in this paper is they introduce
6530.679|5.721|new tokens and um imagine basically
6534.56|4.8|having a few new tokens you put them in
6536.4|5.12|a sequence and then you train the model
6539.36|3.799|by distillation so you are keeping the
6541.52|3.48|entire model Frozen and you're only
6543.159|3.801|training the representations of the new
6545.0|4.44|tokens their embeddings and you're
6546.96|4.96|optimizing over the new tokens such that
6549.44|5.6|the behavior of the language model is
6551.92|5.759|identical uh to the model that has a
6555.04|3.96|very long prompt that works for you and
6557.679|3.121|so it's a compression technique of
6559.0|4.8|compressing that very long prompt into
6560.8|4.24|those few new gist tokens and so you can
6563.8|2.919|train this and then at test time you can
6565.04|3.599|discard your old prompt and just swap in
6566.719|4.4|those tokens and they sort of like uh
6568.639|5.04|stand in for that very long prompt and
6571.119|5.361|have an almost identical performance and
6573.679|4.321|so this is one um technique and a class
6576.48|3.44|of parameter efficient fine-tuning
6578.0|3.88|techniques where most of the model is
6579.92|3.679|basically fixed and there's no training
6581.88|3.56|of the model weights there's no training
6583.599|3.64|of Laura or anything like that of new
6585.44|3.679|parameters the the parameters that
6587.239|3.96|you're training are now just the uh
6589.119|3.761|token embeddings so that's just one
6591.199|3.321|example but this could again be like an
6592.88|2.88|entire video but just to give you a
6594.52|2.84|sense that there's a whole design space
6595.76|3.439|here that is potentially worth exploring
6597.36|3.839|in the future the next thing I want to
6599.199|3.881|briefly address is that I think recently
6601.199|3.881|there's a lot of momentum in how you
6603.08|3.72|actually could construct Transformers
6605.08|3.76|that can simultaneously process not just
6606.8|4.72|text as the input modality but a lot of
6608.84|5.44|other modalities so be it images videos
6611.52|4.48|audio Etc and how do you feed in all
6614.28|4.56|these modalities and potentially predict
6616.0|3.84|these modalities from a Transformer uh
6618.84|2.759|do you have to change the architecture
6619.84|3.279|in some fundamental way and I think what
6621.599|2.681|a lot of people are starting to converge
6623.119|2.321|towards is that you're not changing the
6624.28|3.28|architecture you stick with the
6625.44|4.52|Transformer you just kind of tokenize
6627.56|3.96|your input domains and then call the day
6629.96|4.0|and pretend it's just text tokens and
6631.52|4.56|just do everything else identical in an
6633.96|3.6|identical manner so here for example
6636.08|3.519|there was a early paper that has nice
6637.56|4.599|graphic for how you can take an image
6639.599|5.801|and you can chunc at it into
6642.159|4.681|integers um and these sometimes uh so
6645.4|4.16|these will basically become the tokens
6646.84|5.359|of images as an example and uh these
6649.56|4.36|tokens can be uh hard tokens where you
6652.199|4.801|force them to be integers they can also
6653.92|6.319|be soft tokens where you uh sort of
6657.0|5.159|don't require uh these to be discrete
6660.239|4.521|but you do Force these representations
6662.159|4.761|to go through bottlenecks like in Auto
6664.76|4.12|encoders uh also in this paper that came
6666.92|4.92|out from open a SORA which I think
6668.88|4.64|really um uh blew the mind of many
6671.84|3.359|people and inspired a lot of people in
6673.52|3.4|terms of what's possible they have a
6675.199|4.96|Graphic here and they talk briefly about
6676.92|5.6|how llms have text tokens Sora has
6680.159|4.761|visual patches so again they came up
6682.52|4.0|with a way to chunc a videos into
6684.92|3.6|basically tokens when they own
6686.52|3.52|vocabularies and then you can either
6688.52|3.559|process discrete tokens say with autog
6690.04|5.199|regressive models or even soft tokens
6692.079|6.16|with diffusion models and uh all of that
6695.239|4.4|is sort of uh being actively worked on
6698.239|2.641|designed on and is beyond the scope of
6699.639|3.321|this video but just something I wanted
6700.88|4.239|to mention briefly okay now that we have
6702.96|3.8|come quite deep into the tokenization
6705.119|3.801|algorithm and we understand a lot more
6706.76|3.76|about how it works let's loop back
6708.92|2.679|around to the beginning of this video
6710.52|4.36|and go through some of these bullet
6711.599|5.361|points and really see why they happen so
6714.88|3.88|first of all why can't my llm spell
6716.96|3.6|words very well or do other spell
6718.76|4.16|related
6720.56|5.119|tasks so fundamentally this is because
6722.92|5.04|as we saw these characters are chunked
6725.679|4.721|up into tokens and some of these tokens
6727.96|4.84|are actually fairly long so as an
6730.4|4.88|example I went to the gp4 vocabulary and
6732.8|5.08|I looked at uh one of the longer tokens
6735.28|4.439|so that default style turns out to be a
6737.88|4.279|single individual token so that's a lot
6739.719|4.041|of characters for a single token so my
6742.159|3.92|suspicion is that there's just too much
6743.76|4.0|crammed into this single token and my
6746.079|4.281|suspicion was that the model should not
6747.76|6.919|be very good at tasks related to
6750.36|6.64|spelling of this uh single token so I
6754.679|6.801|asked how many letters L are there in
6757.0|7.36|the word default style and of course my
6761.48|4.28|prompt is intentionally done that way
6764.36|3.0|and you see how default style will be a
6765.76|3.64|single token so this is what the model
6767.36|3.96|sees so my suspicion is that it wouldn't
6769.4|3.759|be very good at this and indeed it is
6771.32|3.319|not it doesn't actually know how many
6773.159|3.841|L's are in there it thinks there are
6774.639|5.0|three and actually there are four if I'm
6777.0|5.32|not getting this wrong myself so that
6779.639|4.96|didn't go extremely well let's look look
6782.32|6.08|at another kind of uh character level
6784.599|6.56|task so for example here I asked uh gp4
6788.4|4.799|to reverse the string default style and
6791.159|4.281|they tried to use a code interpreter and
6793.199|6.361|I stopped it and I said just do it just
6795.44|6.0|try it and uh it gave me jumble so it
6799.56|4.2|doesn't actually really know how to
6801.44|5.32|reverse this string going from right to
6803.76|4.56|left uh so it gave a wrong result so
6806.76|3.24|again like working with this working
6808.32|3.52|hypothesis that maybe this is due to the
6810.0|4.119|tokenization I tried a different
6811.84|4.6|approach I said okay let's reverse the
6814.119|4.56|exact same string but take the following
6816.44|4.279|approach step one just print out every
6818.679|4.601|single character separated by spaces and
6820.719|4.081|then as a step two reverse that list and
6823.28|4.48|it again Tred to use a tool but when I
6824.8|4.12|stopped it it uh first uh produced all
6827.76|3.16|the characters and that was actually
6828.92|4.12|correct and then It reversed them and
6830.92|3.96|that was correct once it had this so
6833.04|4.36|somehow it can't reverse it directly but
6834.88|4.4|when you go just first uh you know
6837.4|4.48|listing it out in order it can do that
6839.28|4.6|somehow and then it can once it's uh
6841.88|4.16|broken up this way this becomes all
6843.88|4.0|these individual characters and so now
6846.04|4.039|this is much easier for it to see these
6847.88|5.64|individual tokens and reverse them and
6850.079|6.761|print them out so that is kind of
6853.52|6.88|interesting so let's continue now why
6856.84|5.839|are llms worse at uh non-english langu
6860.4|4.48|and I briefly covered this already but
6862.679|4.48|basically um it's not only that the
6864.88|3.88|language model sees less non-english
6867.159|4.48|data during training of the model
6868.76|5.879|parameters but also the tokenizer is not
6871.639|5.641|um is not sufficiently trained on
6874.639|5.881|non-english data and so here for example
6877.28|5.6|hello how are you is five tokens and its
6880.52|5.28|translation is 15 tokens so this is a
6882.88|5.759|three times blow up and so for example
6885.8|4.52|anang is uh just hello basically in
6888.639|3.161|Korean and that end up being three
6890.32|2.799|tokens I'm actually kind of surprised by
6891.8|3.359|that because that is a very common
6893.119|3.881|phrase there just the typical greeting
6895.159|3.601|of like hello and that ends up being
6897.0|3.56|three tokens whereas our hello is a
6898.76|3.56|single token and so basically everything
6900.56|3.519|is a lot more bloated and diffuse and
6902.32|4.68|this is I think partly the reason that
6904.079|5.961|the model Works worse on other
6907.0|6.159|languages uh coming back why is LM bad
6910.04|7.32|at simple arithmetic um that has to do
6913.159|5.92|with the tokenization of numbers and so
6917.36|3.6|um you'll notice that for example
6919.079|4.0|addition is very sort of
6920.96|4.759|like uh there's an algorithm that is
6923.079|4.56|like character level for doing addition
6925.719|3.48|so for example here we would first add
6927.639|3.44|the ones and then the tens and then the
6929.199|5.52|hundreds you have to refer to specific
6931.079|5.12|parts of these digits but uh these
6934.719|2.96|numbers are represented completely
6936.199|3.081|arbitrarily based on whatever happened
6937.679|3.761|to merge or not merge during the
6939.28|3.56|tokenization process there's an entire
6941.44|3.279|blog post about this that I think is
6942.84|3.839|quite good integer tokenization is
6944.719|4.0|insane and this person basically
6946.679|5.361|systematically explores the tokenization
6948.719|5.041|of numbers in I believe this is gpt2 and
6952.04|5.24|so they notice that for example for the
6953.76|6.439|for um four-digit numbers you can take a
6957.28|4.839|look at whether it is uh a single token
6960.199|4.721|or whether it is two tokens that is a 1
6962.119|4.441|three or a 2 two or a 31 combination and
6964.92|3.12|so all the different numbers are all the
6966.56|2.639|different combinations and you can
6968.04|3.24|imagine this is all completely
6969.199|4.96|arbitrarily so and the model
6971.28|5.319|unfortunately sometimes sees uh four um
6974.159|3.881|a token for for all four digits
6976.599|3.401|sometimes for three sometimes for two
6978.04|4.48|sometimes for one and it's in an
6980.0|5.0|arbitrary uh Manner and so this is
6982.52|3.84|definitely a headwind if you will for
6985.0|2.92|the language model and it's kind of
6986.36|3.759|incredible that it can kind of do it and
6987.92|4.08|deal with it but it's also kind of not
6990.119|4.08|ideal and so that's why for example we
6992.0|4.44|saw that meta when they train the Llama
6994.199|5.321|2 algorithm and they use sentence piece
6996.44|5.88|they make sure to split up all the um
6999.52|5.36|all the digits as an example for uh
7002.32|4.6|llama 2 and this is partly to improve a
7004.88|5.64|simple arithmetic kind of
7006.92|6.0|performance and finally why is gpt2 not
7010.52|4.36|as good in Python again this is partly a
7012.92|3.719|modeling issue on in the architecture
7014.88|3.319|and the data set and the strength of the
7016.639|3.681|model but it's also partially
7018.199|4.841|tokenization because as we saw here with
7020.32|4.879|the simple python example the encoding
7023.04|4.32|efficiency of the tokenizer for handling
7025.199|4.241|spaces in Python is terrible and every
7027.36|3.719|single space is an individual token and
7029.44|3.08|this dramatically reduces the context
7031.079|3.0|length that the model can attend to
7032.52|4.28|cross so that's almost like a
7034.079|5.921|tokenization bug for gpd2 and that was
7036.8|5.72|later fixed with gp4 okay so here's
7040.0|5.28|another fun one my llm abruptly halts
7042.52|5.52|when it sees the string end of text so
7045.28|4.799|here's um here's a very strange Behavior
7048.04|4.199|print a string end of text is what I
7050.079|5.04|told jt4 and it says could you please
7052.239|4.92|specify the string and I'm I'm telling
7055.119|4.12|it give me end of text and it seems like
7057.159|4.44|there's an issue it's not seeing end of
7059.239|5.0|text and then I give it end of text is
7061.599|4.241|the string and then here's a string and
7064.239|2.88|then it just doesn't print it so
7065.84|2.48|obviously something is breaking here
7067.119|3.08|with respect to the handling of the
7068.32|4.319|special token and I don't actually know
7070.199|4.321|what open ey is doing under the hood
7072.639|6.321|here and whether they are potentially
7074.52|6.639|parsing this as an um as an actual token
7078.96|5.639|instead of this just being uh end of
7081.159|5.281|text um as like individual sort of
7084.599|4.921|pieces of it without the special token
7086.44|5.32|handling logic and so it might be that
7089.52|3.84|someone when they're calling do encode
7091.76|4.439|uh they are passing in the allowed
7093.36|5.0|special and they are allowing end of
7096.199|4.641|text as a special character in the user
7098.36|5.16|prompt but the user prompt of course is
7100.84|4.48|is a sort of um attacker controlled text
7103.52|5.24|so you would hope that they don't really
7105.32|5.279|parse or use special tokens or you know
7108.76|3.0|from that kind of input but it appears
7110.599|4.201|that there's something definitely going
7111.76|4.64|wrong here and um so your knowledge of
7114.8|4.08|these special tokens ends up being in a
7116.4|6.6|tax surface potentially and so if you'd
7118.88|5.44|like to confuse llms then just um try to
7123.0|3.4|give them some special tokens and see if
7124.32|5.16|you're breaking something by chance okay
7126.4|6.48|so this next one is a really fun one uh
7129.48|6.52|the trailing whites space issue so if
7132.88|5.56|you come to playground and uh we come
7136.0|4.32|here to GPT 3.5 turbo instruct so this
7138.44|4.44|is not a chat model this is a completion
7140.32|4.96|model so think of it more like it's a
7142.88|4.719|lot more closer to a base model it does
7145.28|4.6|completion it will continue the token
7147.599|4.04|sequence so here's a tagline for ice
7149.88|4.359|cream shop and we want to continue the
7151.639|6.6|sequence and so we can submit and get a
7154.239|6.601|bunch of tokens okay no problem but now
7158.239|4.88|suppose I do this but instead of
7160.84|5.16|pressing submit here I do here's a
7163.119|5.841|tagline for ice cream shop space so I
7166.0|5.84|have a space here before I click
7168.96|4.44|submit we get a warning your text ends
7171.84|4.0|in a trail Ling space which causes worse
7173.4|4.839|performance due to how API splits text
7175.84|4.72|into tokens so what's happening here it
7178.239|4.561|still gave us a uh sort of completion
7180.56|4.32|here but let's take a look at what's
7182.8|5.879|happening so here's a tagline for an ice
7184.88|5.279|cream shop and then what does this look
7188.679|3.601|like in the actual actual training data
7190.159|3.401|suppose you found the completion in the
7192.28|3.399|training document somewhere on the
7193.56|4.76|internet and the llm trained on this
7195.679|4.721|data so maybe it's something like oh
7198.32|4.44|yeah maybe that's the tagline that's a
7200.4|5.36|terrible tagline but notice here that
7202.76|5.04|when I create o you see that because
7205.76|5.399|there's the the space character is
7207.8|5.68|always a prefix to these tokens in GPT
7211.159|5.601|so it's not an O token it's a space o
7213.48|5.759|token the space is part of the O and
7216.76|5.16|together they are token 8840 that's
7219.239|4.88|that's space o so what's What's
7221.92|5.12|Happening Here is that when I just have
7224.119|5.921|it like this and I let it complete the
7227.04|5.559|next token it can sample the space o
7230.04|4.72|token but instead if I have this and I
7232.599|5.04|add my space then what I'm doing here
7234.76|4.319|when I incode this string is I have
7237.639|4.361|basically here's a t line for an ice
7239.079|5.0|cream uh shop and this space at the very
7242.0|5.84|end becomes a token
7244.079|5.681|220 and so we've added token 220 and
7247.84|4.04|this token otherwise would be part of
7249.76|5.479|the tagline because if there actually is
7251.88|5.44|a tagline here so space o is the token
7255.239|4.44|and so this is suddenly a of
7257.32|4.2|distribution for the model because this
7259.679|4.361|space is part of the next token but
7261.52|5.679|we're putting it here like this and the
7264.04|6.039|model has seen very very little data of
7267.199|4.52|actual Space by itself and we're asking
7270.079|3.401|it to complete the sequence like add in
7271.719|4.641|more tokens but the problem is that
7273.48|5.28|we've sort of begun the first token and
7276.36|4.4|now it's been split up and now we're out
7278.76|4.28|of this distribution and now arbitrary
7280.76|3.8|bad things happen and it's just a very
7283.04|3.88|rare example for it to see something
7284.56|4.559|like that and uh that's why we get the
7286.92|5.52|warning so the fundamental issue here is
7289.119|5.48|of course that um the llm is on top of
7292.44|4.12|these tokens and these tokens are text
7294.599|3.6|chunks they're not characters in a way
7296.56|3.8|you and I would think of them they are
7298.199|3.601|these are the atoms of what the LM is
7300.36|3.279|seeing and there's a bunch of weird
7301.8|6.2|stuff that comes out of it let's go back
7303.639|6.321|to our default cell style I bet you that
7308.0|6.199|the model has never in its training set
7309.96|6.639|seen default cell sta without Le in
7314.199|5.04|there it's always seen this as a single
7316.599|5.401|group because uh this is some kind of a
7319.239|3.84|function in um I'm guess I don't
7322.0|3.119|actually know what this is part of this
7323.079|4.0|is some kind of API but I bet you that
7325.119|5.52|it's never seen this combination of
7327.079|5.281|tokens uh in its training data because
7330.639|4.08|or I think it would be extremely rare so
7332.36|5.12|I took this and I copy pasted it here
7334.719|4.48|and I had I tried to complete from it
7337.48|3.599|and the it immediately gave me a big
7339.199|3.121|error and it said the model predicted to
7341.079|3.08|completion that begins with a stop
7342.32|4.04|sequence resulting in no output consider
7344.159|3.48|adjusting your prompt or stop sequences
7346.36|3.839|so what happened here when I clicked
7347.639|4.6|submit is that immediately the model
7350.199|4.241|emitted and sort of like end of text
7352.239|4.201|token I think or something like that it
7354.44|4.32|basically predicted the stop sequence
7356.44|3.759|immediately so it had no completion and
7358.76|3.399|so this is why I'm getting a warning
7360.199|4.92|again because we're off the data
7362.159|5.48|distribution and the model is just uh
7365.119|4.321|predicting just totally arbitrary things
7367.639|3.281|it's just really confused basically this
7369.44|3.88|is uh this is giving it brain damage
7370.92|3.64|it's never seen this before it's shocked
7373.32|3.72|and it's predicting end of text or
7374.56|4.519|something I tried it again here and it
7377.04|4.4|in this case it completed it but then
7379.079|4.56|for some reason this request May violate
7381.44|5.199|our usage policies this was
7383.639|4.04|flagged um basically something just like
7386.639|2.881|goes wrong and there's something like
7387.679|3.721|Jank you can just feel the Jank because
7389.52|3.44|the model is like extremely unhappy with
7391.4|2.759|just this and it doesn't know how to
7392.96|3.239|complete it because it's never occurred
7394.159|4.161|in training set in a training set it
7396.199|3.841|always appears like this and becomes a
7398.32|3.64|single token
7400.04|4.199|so these kinds of issues where tokens
7401.96|4.8|are either you sort of like complete the
7404.239|4.321|first character of the next token or you
7406.76|3.04|are sort of you have long tokens that
7408.56|3.76|you then have just some of the
7409.8|5.56|characters off all of these are kind of
7412.32|5.44|like issues with partial tokens is how I
7415.36|4.44|would describe it and if you actually
7417.76|4.2|dig into the T token
7419.8|4.359|repository go to the rust code and
7421.96|5.119|search for
7424.159|5.08|unstable and you'll see um en code
7427.079|4.441|unstable native unstable token tokens
7429.239|4.161|and a lot of like special case handling
7431.52|3.96|none of this stuff about unstable tokens
7433.4|4.96|is documented anywhere but there's a ton
7435.48|5.32|of code dealing with unstable tokens and
7438.36|4.4|unstable tokens is exactly kind of like
7440.8|4.439|what I'm describing here what you would
7442.76|3.839|like out of a completion API is
7445.239|3.721|something a lot more fancy like if we're
7446.599|4.08|putting in default cell sta if we're
7448.96|3.279|asking for the next token sequence we're
7450.679|3.96|not actually trying to append the next
7452.239|4.241|token exactly after this list we're
7454.639|4.881|actually trying to append we're trying
7456.48|5.679|to consider lots of tokens um
7459.52|6.24|that if we were or I guess like we're
7462.159|6.0|trying to search over characters that if
7465.76|4.919|we retened would be of high probability
7468.159|4.161|if that makes sense um so that we can
7470.679|3.801|actually add a single individual
7472.32|4.359|character uh instead of just like adding
7474.48|4.88|the next full token that comes after
7476.679|4.641|this partial token list so I this is
7479.36|3.68|very tricky to describe and I invite you
7481.32|3.359|to maybe like look through this it ends
7483.04|3.32|up being extremely gnarly and hairy kind
7484.679|4.721|of topic it and it comes from
7486.36|4.44|tokenization fundamentally so um maybe I
7489.4|2.719|can even spend an entire video talking
7490.8|3.399|about unstable tokens sometime in the
7492.119|4.48|future okay and I'm really saving the
7494.199|5.0|best for last my favorite one by far is
7496.599|4.761|the solid gold
7499.199|4.44|Magikarp and it just okay so this comes
7501.36|5.64|from this blog post uh solid gold
7503.639|6.44|Magikarp and uh this is um internet
7507.0|4.84|famous now for those of us in llms and
7510.079|3.6|basically I I would advise you to uh
7511.84|4.719|read this block Post in full but
7513.679|5.56|basically what this person was doing is
7516.559|5.761|this person went to the um
7519.239|5.561|token embedding stable and clustered the
7522.32|4.96|tokens based on their embedding
7524.8|4.439|representation and this person noticed
7527.28|3.879|that there's a cluster of tokens that
7529.239|4.84|look really strange so there's a cluster
7531.159|4.841|here at rot e stream Fame solid gold
7534.079|5.881|Magikarp Signet message like really
7536.0|6.239|weird tokens in uh basically in this
7539.96|3.719|embedding cluster and so what are these
7542.239|3.161|tokens and where do they even come from
7543.679|5.281|like what is solid gold magikarpet makes
7545.4|4.799|no sense and then they found bunch of
7548.96|3.159|these
7550.199|3.36|tokens and then they notice that
7552.119|3.921|actually the plot thickens here because
7553.559|5.08|if you ask the model about these tokens
7556.04|4.159|like you ask it uh some very benign
7558.639|4.321|question like please can you repeat back
7560.199|4.601|to me the string sold gold Magikarp uh
7562.96|4.8|then you get a variety of basically
7564.8|5.04|totally broken llm Behavior so either
7567.76|3.64|you get evasion so I'm sorry I can't
7569.84|4.719|hear you or you get a bunch of
7571.4|5.88|hallucinations as a response um you can
7574.559|5.441|even get back like insults so you ask it
7577.28|4.76|uh about streamer bot it uh tells the
7580.0|4.159|and the model actually just calls you
7582.04|4.199|names uh or it kind of comes up with
7584.159|4.321|like weird humor like you're actually
7586.239|4.281|breaking the model by asking about these
7588.48|4.36|very simple strings like at Roth and
7590.52|3.96|sold gold Magikarp so like what the hell
7592.84|4.239|is happening and there's a variety of
7594.48|4.0|here documented behaviors uh there's a
7597.079|3.201|bunch of tokens not just so good
7598.48|3.639|Magikarp that have that kind of a
7600.28|3.879|behavior and so basically there's a
7602.119|3.921|bunch of like trigger words and if you
7604.159|3.881|ask the model about these trigger words
7606.04|3.96|or you just include them in your prompt
7608.04|4.76|the model goes haywire and has all kinds
7610.0|4.84|of uh really Strange Behaviors including
7612.8|4.2|sort of ones that violate typical safety
7614.84|5.0|guidelines uh and the alignment of the
7617.0|4.76|model like it's swearing back at you so
7619.84|4.719|what is happening here and how can this
7621.76|4.959|possibly be true well this again comes
7624.559|4.201|down to tokenization so what's happening
7626.719|5.0|here is that sold gold Magikarp if you
7628.76|5.28|actually dig into it is a Reddit user so
7631.719|5.081|there's a u Sol gold
7634.04|3.96|Magikarp and probably what happened here
7636.8|3.64|even though I I don't know that this has
7638.0|5.159|been like really definitively explored
7640.44|5.119|but what is thought to have happened is
7643.159|4.841|that the tokenization data set was very
7645.559|4.361|different from the training data set for
7648.0|3.52|the actual language model so in the
7649.92|4.679|tokenization data set there was a ton of
7651.52|4.88|redded data potentially where the user
7654.599|4.6|solid gold Magikarp was mentioned in the
7656.4|5.279|text because solid gold Magikarp was a
7659.199|4.48|very common um sort of uh person who
7661.679|3.601|would post a lot uh this would be a
7663.679|4.321|string that occurs many times in a
7665.28|4.72|tokenization data set because it occurs
7668.0|3.48|many times in a tokenization data set
7670.0|3.52|these tokens would end up getting merged
7671.48|4.92|to the single individual token for that
7673.52|4.84|single Reddit user sold gold Magikarp so
7676.4|4.319|they would have a dedicated token in a
7678.36|5.759|vocabulary of was it 50,000 tokens in
7680.719|4.88|gpd2 that is devoted to that Reddit user
7684.119|4.48|and then what happens is the
7685.599|5.321|tokenization data set has those strings
7688.599|5.321|but then later when you train the model
7690.92|5.759|the language model itself um this data
7693.92|4.88|from Reddit was not present and so
7696.679|4.601|therefore in the entire training set for
7698.8|5.52|the language model sold gold Magikarp
7701.28|4.56|never occurs that token never appears in
7704.32|4.6|the training set for the actual language
7705.84|5.2|model later so this token never gets
7708.92|3.96|activated it's initialized at random in
7711.04|3.44|the beginning of optimization then you
7712.88|3.12|have forward backward passes and updates
7714.48|3.44|to the model and this token is just
7716.0|4.0|never updated in the embedding table
7717.92|4.12|that row Vector never gets sampled it
7720.0|3.88|never gets used so it never gets trained
7722.04|4.36|and it's completely untrained it's kind
7723.88|4.279|of like unallocated memory in a typical
7726.4|3.6|binary program written in C or something
7728.159|3.681|like that that so it's unallocated
7730.0|4.28|memory and then at test time if you
7731.84|3.799|evoke this token then you're basically
7734.28|3.04|plucking out a row of the embedding
7735.639|3.281|table that is completely untrained and
7737.32|3.64|that feeds into a Transformer and
7738.92|3.239|creates undefined behavior and that's
7740.96|2.92|what we're seeing here this completely
7742.159|4.4|undefined never before seen in a
7743.88|4.12|training behavior and so any of these
7746.559|2.761|kind of like weird tokens would evoke
7748.0|6.48|this Behavior because fundamentally the
7749.32|7.44|model is um is uh uh out of sample out
7754.48|4.04|of distribution okay and the very last
7756.76|2.919|thing I wanted to just briefly mention
7758.52|3.119|point out although I think a lot of
7759.679|3.48|people are quite aware of this is that
7761.639|3.361|different kinds of formats and different
7763.159|3.721|representations and different languages
7765.0|4.8|and so on might be more or less
7766.88|4.52|efficient with GPD tokenizers uh or any
7769.8|3.759|tokenizers for any other L for that
7771.4|4.92|matter so for example Json is actually
7773.559|5.68|really dense in tokens and yaml is a lot
7776.32|5.0|more efficient in tokens um so for
7779.239|5.36|example this are these are the same in
7781.32|6.799|Json and in yaml the Json is
7784.599|7.04|116 and the yaml is 99 so quite a bit of
7788.119|5.52|an Improvement and so in the token
7791.639|4.04|economy where we are paying uh per token
7793.639|4.0|in many ways and you are paying in the
7795.679|4.201|context length and you're paying in um
7797.639|3.56|dollar amount for uh the cost of
7799.88|3.64|processing all this kind of structured
7801.199|4.88|data when you have to um so prefer to
7803.52|4.079|use theal over Json and in general kind
7806.079|3.761|of like the tokenization density is
7807.599|4.08|something that you have to um sort of
7809.84|3.56|care about and worry about at all times
7811.679|3.721|and try to find efficient encoding
7813.4|3.48|schemes and spend a lot of time in tick
7815.4|3.52|tokenizer and measure the different
7816.88|4.12|token efficiencies of different formats
7818.92|4.44|and settings and so on okay so that
7821.0|4.96|concludes my fairly long video on
7823.36|5.08|tokenization I know it's a try I know
7825.96|4.92|it's annoying I know it's irritating I
7828.44|4.159|personally really dislike the stage what
7830.88|4.08|I do have to say at this point is don't
7832.599|5.52|brush it off there's a lot of foot guns
7834.96|4.92|sharp edges here security issues uh AI
7838.119|3.96|safety issues as we saw plugging in
7839.88|5.279|unallocated memory into uh language
7842.079|6.401|models so um it's worth understanding
7845.159|5.161|this stage um that said I will say that
7848.48|4.079|eternal glory goes to anyone who can get
7850.32|4.359|rid of it uh I showed you one possible
7852.559|4.481|paper that tried to uh do that and I
7854.679|4.721|think I hope a lot more can follow over
7857.04|4.4|time and my final recommendations for
7859.4|3.64|the application right now are if you can
7861.44|3.56|reuse the GPT 4 tokens and the
7863.04|3.159|vocabulary uh in your application then
7865.0|2.84|that's something you should consider and
7866.199|5.04|just use Tech token because it is very
7867.84|5.879|efficient and nice library for inference
7871.239|6.081|for bpe I also really like the bite
7873.719|5.321|level BP that uh Tik toen and openi uses
7877.32|5.359|uh if you for some reason want to train
7879.04|5.96|your own vocabulary from scratch um then
7882.679|5.44|I would use uh the bpe with sentence
7885.0|5.679|piece um oops as I mentioned I'm not a
7888.119|5.801|huge fan of sentence piece I don't like
7890.679|4.88|its uh bite fallback and I don't like
7893.92|3.84|that it's doing BP on unic code code
7895.559|3.56|points I think it's uh it also has like
7897.76|2.64|a million settings and I think there's a
7899.119|3.08|lot of foot gonss here and I think it's
7900.4|3.36|really easy to Mis calibrate them and
7902.199|3.601|you end up cropping your sentences or
7903.76|3.52|something like that uh because of some
7905.8|3.64|type of parameter that you don't fully
7907.28|4.439|understand so so be very careful with
7909.44|4.84|the settings try to copy paste exactly
7911.719|4.4|maybe where what meta did or basically
7914.28|3.2|spend a lot of time looking at all the
7916.119|2.96|hyper parameters and go through the code
7917.48|4.56|of sentence piece and make sure that you
7919.079|4.401|have this correct um but even if you
7922.04|2.88|have all the settings correct I still
7923.48|4.199|think that the algorithm is kind of
7924.92|4.6|inferior to what's happening here and
7927.679|3.641|maybe the best if you really need to
7929.52|3.639|train your vocabulary maybe the best
7931.32|5.52|thing is to just wait for M bpe to
7933.159|5.0|becomes as efficient as possible and uh
7936.84|3.96|that's something that maybe I hope to
7938.159|4.721|work on and at some point maybe we can
7940.8|4.16|be training basically really what we
7942.88|4.96|want is we want tick token but training
7944.96|6.4|code and that is the ideal thing that
7947.84|5.399|currently does not exist and MBP is um
7951.36|4.52|is in implementation of it but currently
7953.239|4.96|it's in Python so that's currently what
7955.88|4.52|I have to say for uh tokenization there
7958.199|3.721|might be an advanced video that has even
7960.4|3.239|drier and even more detailed in the
7961.92|4.84|future but for now I think we're going
7963.639|6.401|to leave things off here and uh I hope
7966.76|3.28|that was helpful bye
7974.119|8.56|and uh they increase this contact size
7976.04|9.4|from gpt1 of 512 uh to 1024 and GPT 4
7982.679|4.96|two the
7985.44|4.36|next okay next I would like us to
7987.639|5.721|briefly walk through the code from open
7989.8|3.56|AI on the gpt2 encoded
7995.84|6.0|ATP I'm sorry I'm gonna sneeze
7999.119|5.52|and then what's Happening Here
8001.84|4.279|is this is a spous layer that I will
8004.639|5.48|explain in a
8006.119|4.0|bit What's Happening Here
8013.159|3.0|is