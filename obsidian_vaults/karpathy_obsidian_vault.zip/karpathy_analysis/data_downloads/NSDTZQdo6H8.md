start_time|end_time|text
0.16|4.88|i can see andre is the screen sharing
3.84|4.08|working
5.04|2.88|i hope so let's try
9.44|5.279|i'm embarrassed to say that i barely use
11.04|3.679|zoom i know this is shocking
14.92|6.28|yes
17.9|3.3|[Music]
26.8|7.599|okay yeah seems still to work
31.279|6.161|even with limited experience okay so
34.399|4.881|uh it's a pleasure to introduce andre
37.44|3.76|uh i have to say i think he doesn't
39.28|4.799|really need a lot of introduction
41.2|4.48|uh but yeah um he is the senior director
44.079|4.721|of ai at tesla
45.68|3.84|and he basically supervises uh and leads
48.8|3.759|the team
49.52|7.519|responsible for all the neural networks
52.559|4.48|uh in the autopilot so
57.28|3.279|with this uh it's a pleasure to have you
59.76|2.4|here
60.559|3.121|and i'm really looking forward to your
62.16|2.8|talk
63.68|3.119|uh yeah great thank you for the
64.96|3.04|introduction and i'm very happy that i
66.799|4.041|was able to display some
68.0|4.0|impressive zero shot learning on zoom
70.84|2.76|okay
72.0|3.119|uh yes i'm very excited to be here thank
73.6|3.04|you for the introduction um
75.119|2.961|i would like to talk a bit more about
76.64|2.32|what tesla has been up for the last few
78.08|4.0|months
78.96|5.04|um so first to start uh
82.08|3.359|i guess we are here at the cbpr uh
84.0|2.88|workshop on autonomous driving so i
85.439|1.921|think i'm preaching to the core a little
86.88|1.84|bit
87.36|3.119|i'd like to start with some slides on
88.72|2.079|like why we're doing all of this and i
90.479|1.68|think
90.799|2.481|unfortunately we're kind of like in a
92.159|2.801|bad shape when it comes to
93.28|3.519|transportation in society
94.96|3.68|and uh basically the issue is that we
96.799|3.761|have these metallic objects traveling
98.64|3.519|incredibly quickly
100.56|4.32|and with very high kinetic energy and we
102.159|4.32|are putting meat in the control loop
104.88|3.04|into the system and so this is quite
106.479|2.801|undesirable and really fundamentally
107.92|2.72|what it comes down to is
109.28|3.04|people are not very good at driving they
110.64|2.32|get into a lot of trouble uh in
112.32|3.92|accidents
112.96|5.28|uh they don't want to drive and also
116.24|3.519|in terms of economics we are involving
118.24|2.879|people in transportation and of course
119.759|2.0|we'd like to automate transportation and
121.119|2.081|really
121.759|3.441|reap the benefits of that automation in
123.2|3.44|society so we all
125.2|2.96|i think are on the same page that it
126.64|3.28|should be possible to replace the meat
128.16|3.6|computer with a silicone computer
129.92|3.12|and get a lot of benefits out of it in
131.76|4.08|terms of
133.04|3.52|safety and convenience and economics so
135.84|2.72|in particular
136.56|3.039|silicon computers have significantly low
138.56|3.759|latencies they
139.599|4.241|have 360 degree situational awareness
142.319|2.881|they are fully attentive and never check
143.84|3.36|their instagram
145.2|4.0|and uh alleviate all of the issues that
147.2|3.84|are presented and so i think
149.2|3.52|uh this is not super shocking and a lot
151.04|2.88|of people have been kind of
152.72|3.92|really looking forward to this kind of
153.92|4.24|feature this is a frame from irobot
156.64|3.84|a really good movie if you haven't seen
158.16|4.4|it and here will smith is about to drive
160.48|3.44|the car manually and uh this other
162.56|2.72|person here is shocked that this is
163.92|2.48|going to happen this is ridiculous like
165.28|2.16|why would you actually have a huge
166.4|3.68|driving cars
167.44|3.04|um and so i think this is not very far
170.08|2.08|from
170.48|4.08|truth and this movie is taking place in
172.16|4.48|2035 uh so i think by then
174.56|3.599|um actually i think this is a pretty uh
176.64|2.879|present prediction
178.159|3.521|uh so what i think is kind of unique
179.519|4.321|about tesla and uh
181.68|3.919|in our approach to autonomy is that we
183.84|2.479|take a very incremental approach towards
185.599|1.92|this problem
186.319|3.041|so in particular we already have
187.519|2.961|customers with the autopilot package and
189.36|3.599|we have millions of cars
190.48|3.839|and uh the the autopilot software is
192.959|2.721|always running and providing active
194.319|2.801|safety features and of course the
195.68|3.44|autopilot functionality
197.12|3.839|so we provide additional safety and
199.12|3.199|convenience to our customers today
200.959|3.521|and also the team is working on full
202.319|4.241|self-driving ability
204.48|3.2|uh so i would really like to very
206.56|2.72|quickly speak to
207.68|2.8|uh the value day that we provide just to
209.28|1.76|give you some examples of what the team
210.48|3.28|is up to
211.04|4.8|over uh sort of doing today uh so here's
213.76|3.839|an automatic emergency braking scenario
215.84|3.28|uh so the driver here is proceeding
217.599|3.92|through an intersection and you can see
219.12|4.32|trouble coming here
221.519|4.161|so the person kind of crept up from here
223.44|4.24|and the car sees the pedestrian
225.68|4.16|object detection kicks in and we slam on
227.68|3.839|the brakes and we avert the coalition
229.84|3.44|here's an example of a traffic control
231.519|3.041|warning so this person is probably not
233.28|1.84|paying attention potentially on the
234.56|2.16|phone
235.12|3.52|is not breaking for the traffic lights
236.72|3.28|ahead but we see that these are relevant
238.64|2.879|traffic lights they are red
240.0|4.08|and we beat and the person immediately
241.519|3.761|starts slowing and probably
244.08|3.84|you know does not actually enter the
245.28|6.239|intersection uh these are examples from
247.92|5.28|uh pedal misapplication mitigation pmm
251.519|3.201|here a person is unparking from their
253.2|2.96|driving spot and
254.72|5.12|they are trying to turn and then they
256.16|5.199|mess up and they accidentally floor it
259.84|3.04|so they floor it right there and the
261.359|2.4|system kicks in it sees pedestrians
262.88|3.12|ahead of us and it
263.759|3.921|slams on the brakes and converts what
266.0|2.479|would be a very gnarly situation in this
267.68|3.36|case
268.479|3.361|um here's another last scenario i can
271.04|3.36|show briefly
271.84|4.079|so this person is trying to park and
274.4|3.359|they turn to the right here
275.919|3.84|and they intend to press the brake but
277.759|3.361|they actually floor it and
279.759|3.121|the system again sees that there's no
281.12|2.96|driving path forward and actually slams
282.88|2.879|and breaks and inverts
284.08|3.119|you know in this case this person is not
285.759|3.521|going to be swimming in this river
287.199|3.601|imminently uh so these are some examples
289.28|1.919|of the value that we are providing today
290.8|2.56|in this
291.199|5.921|incremental autonomy fashion but of
293.36|6.32|course the team is actually also tonight
297.12|3.76|sorry about that uh the team is um
299.68|3.76|working primarily on
300.88|4.0|the fsd functionality which is our
303.44|4.0|wholesale dragon suite
304.88|3.759|so here we have about fs we have the ssd
307.44|2.56|beta product and it's in the hands of
308.639|2.961|about 2000 customers
310.0|3.68|and this is an example from one of the
311.6|4.08|customers driving around san francisco
313.68|3.359|and uh these people are posting videos
315.68|2.959|on youtube so you can check out a lot of
317.039|2.641|videos but we're showing here on the
318.639|2.481|instrument cluster
319.68|3.12|is we're showing all of our predictions
321.12|4.799|so you're seeing some road edges
322.8|4.72|some lines some objects and the car of
325.919|4.72|course is navigating around autonomously
327.52|3.119|here in san francisco environment
330.88|3.28|now we of course drive this extensively
332.96|3.04|as engineers
334.16|3.28|and so it's actually fairly routine for
336.0|2.96|us to have zero intervention drives i
337.44|3.12|would say in like sparsely populated
338.96|3.6|areas like palo alto and so on i would
340.56|3.76|say we definitely struggle a lot more in
342.56|3.6|uh very adversarial environments like
344.32|3.599|san francisco a lot of people
346.16|3.28|working in autonomy of course know all
347.919|3.201|about that as well
349.44|3.92|so this drive ends up being a fairly
351.12|6.0|long drive and it's zero interventions
353.36|5.04|in this case now one thing i'd like to
357.12|2.48|point out always whenever i showed the
358.4|1.919|video of tesla driving around
359.6|3.599|autonomously
360.319|4.241|in these city environments is you've
363.199|2.081|seen this before and you've seen it for
364.56|2.96|a decade
365.28|3.919|so or more so here's a waymo taking a
367.52|3.36|left at an intersection
369.199|3.44|and uh this is actually a pretty old
370.88|2.72|video i believe and so you've been
372.639|2.4|seeing stuff like this
373.6|3.76|for a very long time so what is the big
375.039|3.521|deal why is this impressive and so on
377.36|2.8|and i think the important thing to
378.56|3.28|realize and that i like to always stress
380.16|3.28|is that even though these two scenarios
381.84|2.96|look the same so there's a car taking a
383.44|3.039|left at an intersection
384.8|3.28|under the hood and in terms of the
386.479|2.961|scalability of the system things are
388.08|3.679|incredibly different
389.44|4.0|so in particular a lot of the competing
391.759|4.0|approaches in the in the industry
393.44|3.92|uh take this lidar plus hd map approach
395.759|2.88|and so the idea is that you take an
397.36|3.839|expensive sensor a lidar
398.639|3.921|on the top of the car and um it
401.199|3.201|basically gives you rangefinding
402.56|3.359|around around the vehicle in 360 and
404.4|2.639|gives you a point cloud and what you
405.919|2.161|have to do is you have to pre-map the
407.039|2.801|environment
408.08|3.28|with the lidar sensor and you have to
409.84|3.12|create a high definition map
411.36|2.959|and then you have to insert all of the
412.96|2.639|lanes and how they connect and all the
414.319|2.241|traffic lights and where they are and
415.599|1.841|you basically have to create a high
416.56|2.24|definition map
417.44|4.08|and then a test time you are simply
418.8|5.119|localizing to that map to drive around
421.52|3.76|and so the approach we take is vision
423.919|3.441|based primarily
425.28|3.52|so everything that happens uh happens
427.36|2.559|for the first time there in the car
428.8|2.64|based on the videos
429.919|3.601|from the eight cameras that surround the
431.44|3.36|car and so we come to an intersection
433.52|2.56|for the very first time and we have to
434.8|2.72|figure out where are the lanes how do
436.08|2.559|they connect what are the traffic lights
437.52|2.64|which ones are relevant
438.639|3.041|what what traffic lights control what
440.16|2.159|lanes everything is happening at that
441.68|2.72|time
442.319|3.6|um on that car and we don't have too
444.4|2.4|much high definition sort of information
445.919|2.72|at all
446.8|3.519|and this is actually a significantly
448.639|3.84|more scalable approach because
450.319|3.121|if our product is on a scale of millions
452.479|2.961|of customers
453.44|3.039|on earth and so it's actually quite
455.44|3.599|unscalable to
456.479|3.12|uh to actually collect build and
459.039|2.961|maintain
459.599|3.841|these high definition lidar amounts it
462.0|3.199|would be incredibly expensive to keep
463.44|3.52|this infrastructure up to date
465.199|3.361|and so we take the vision-based approach
466.96|2.88|which of course is much more difficult
468.56|3.359|because you actually have to get to
469.84|3.44|get neural networks that uh function
471.919|3.761|incredibly well based on the
473.28|4.16|videos uh but once you actually get that
475.68|3.519|to work it's a general vision system
477.44|3.12|and can in principle be deployed
479.199|2.881|anywhere on earth
480.56|3.28|so that's really the the problem that we
482.08|3.519|are solving now
483.84|3.6|in terms of the cartoon diagram of the
485.599|3.44|typical sensing suite of an autonomous
487.44|2.64|vehicle
489.039|2.72|these are kind of like the typical
490.08|2.559|sensors you would see and as i mentioned
491.759|2.401|we do not use
492.639|4.481|high-definition maps and we do not use
494.16|6.56|lidar we only use uh video cameras
497.12|4.88|and in fact um the um vision system that
500.72|1.68|we have been building over the last few
502.0|2.8|years
502.4|3.68|has been getting so incredibly good that
504.8|2.88|it's kind of leaving a lot of the other
506.08|4.88|sensors in the dust
507.68|4.56|and so actually um the
510.96|2.8|cameras are doing most of the heavy
512.24|2.719|lifting in terms of the perception that
513.76|2.32|you've seen in the car
514.959|2.56|and actually it's gotten to the point
516.08|3.28|that we are able to start removing some
517.519|3.2|of the other sensors because they are
519.36|3.28|just becoming these crushes that you
520.719|3.281|start to not really need at all
522.64|3.759|so actually three weeks ago we started
524.0|4.56|to ship cars that have no radar at all
526.399|3.841|so we deleted the radar and we are
528.56|3.76|driving on vision alone
530.24|3.039|in these cars and the reason we are
532.32|3.12|doing this i think is
533.279|3.921|well expressed by elon and suite he's
535.44|3.12|saying uh when radar and vision disagree
537.2|2.96|which one do you believe
538.56|3.2|vision has much more precision so better
540.16|2.56|to double down vision than do sensor
541.76|2.639|fusion
542.72|2.799|and what he's referring to is basically
544.399|1.841|like vision is getting to the point
545.519|3.44|where
546.24|3.599|the sensor is like 100x better than say
548.959|2.401|radar
549.839|3.521|then if you have a sensor that is
551.36|3.28|dominating the other sensor and so much
553.36|2.64|better then the other sensor is actually
554.64|2.4|starting to like really contribute it's
556.0|2.399|actually holding back
557.04|3.44|and it's really starting to attribute
558.399|4.481|noise uh to the former system
560.48|3.76|and so we are really doubling down uh on
562.88|3.519|the vision only approach
564.24|3.44|and um actually in this talk what i
566.399|2.481|would like to primarily talk about is
567.68|3.2|how we have achieved
568.88|3.519|vision only control without radar and
570.88|3.84|how we have released this
572.399|3.921|quite successfully so far to defeat and
574.72|4.64|what it has sort of um
576.32|5.68|taken for us to for us to do that so
579.36|4.08|here i wanted to show a video um
582.0|2.959|basically showing what the input of the
583.44|2.32|system is so we have eight cameras
584.959|2.481|around
585.76|4.079|and these are fairly high definition
587.44|3.6|cameras and we have 36 frames a second
589.839|2.801|and you can see that basically you can
591.04|2.799|actually understand a lot about this
592.64|3.6|environment from this input
593.839|3.761|it's extremely information rich you're
596.24|2.56|getting a huge amount of constraints
597.6|3.359|eight million bits roughly of
598.8|3.279|constraints per second on the state of
600.959|2.88|the surroundings
602.079|3.121|and so it's incredibly information rich
603.839|2.321|compared to any other sensor you may
605.2|1.84|want to have in the car
606.16|2.16|and so this is the one that we're
607.04|2.72|doubling down on because this is
608.32|3.28|ultimately where all the
609.76|3.44|difficult um sort of scene
611.6|3.919|interpretation challenges lie
613.2|3.92|so we prefer to just focus all of our
615.519|2.961|infrastructure and development on this
617.12|3.12|and we're not wasting people working on
618.48|2.24|the radar stack and the sensor fusion
620.24|3.92|stack
620.72|4.799|we only have one team division team
624.16|2.88|now typically when we talk about vision
625.519|2.721|but the reason people are squeamish
627.04|3.28|about using vision
628.24|3.839|is and the sort of challenge that almost
630.32|4.56|always is pointed out is people are not
632.079|3.521|certain if um neural networks are able
634.88|2.959|to
635.6|3.44|do range finding or depth estimation of
637.839|2.881|these objects
639.04|3.76|so obviously humans drive around with
640.72|3.84|vision so obviously where our neural net
642.8|2.88|is able to process visual input to
644.56|2.16|understand the depth and velocity of all
645.68|2.56|the objects around us
646.72|3.04|but the big question is can our
648.24|2.24|synthetic neural networks also do the
649.76|2.319|same
650.48|2.72|and i think the answer to us internally
652.079|3.361|over the last few months that we've
653.2|3.92|worked on this is an unequivocal yes
655.44|4.16|and i'd like to sort of talk about that
657.12|4.399|so in particular the radar api
659.6|3.679|or like what the radar really gives you
661.519|3.281|is it gives you a quite accurate
663.279|2.881|depth and velocity measurement it's a
664.8|2.0|pretty direct measurement of the car
666.16|3.119|ahead of you
666.8|3.039|in very nominal situations so here i'm
669.279|2.481|showing
669.839|2.881|a random image on the left and you are
671.76|2.72|seeing the depth velocity and
672.72|2.559|acceleration recorded by the radar stack
674.48|2.0|for this car
675.279|2.641|and you can see that it's a bit wiggly
676.48|3.44|on the velocity so this is some kind of
677.92|4.08|a stop and go scenario
679.92|3.52|now when radar has a good lock on the
682.0|3.279|car in front of you it's given
683.44|3.28|incredibly good depth and velocity but
685.279|3.521|the problem with radar is like
686.72|3.44|once in a while at random it will give
688.8|3.84|you a dumb measurement
690.16|3.919|and you will not know when that is and
692.64|3.6|so it's incredibly hard to fuse
694.079|4.161|with vision in our experience so it
696.24|4.0|might suddenly see a spurious
698.24|3.36|stationary object because of the manhole
700.24|3.36|or because of the bridge
701.6|3.44|or crossing objects are not very well
703.6|2.32|tracked or oncoming objects are not very
705.04|3.039|well tracked
705.92|3.039|and it ends up contributing noise i'll
708.079|2.481|go into
708.959|3.281|more detail in a bit but for our
710.56|3.76|purposes what we want to do right now
712.24|3.92|is we want to match the quality of these
714.32|3.04|predictions using vision alone
716.16|2.56|so the question is how can you get a
717.36|2.08|neural net to predict depth velocity
718.72|3.04|acceleration
719.44|4.56|directly and do it with a very high
721.76|3.519|fidelity matching that of radar
724.0|2.56|so the approach we're going to take of
725.279|2.401|course is we're going to treat this as a
726.56|2.959|surprise learning problem
727.68|3.839|and we need a massive data set of depth
729.519|3.281|velocity acceleration on a lot of cars
731.519|2.721|and we're going to train a large enough
732.8|2.24|neural network and do a very good job at
734.24|2.64|that that's the
735.04|3.44|standard vanilla approach and that
736.88|2.16|actually works really well if you do it
738.48|3.68|properly
739.04|4.799|so here's what it took um
742.16|3.119|so the first component that you need is
743.839|3.761|an incredibly good data set
745.279|3.601|so when i talk about a good data set i
747.6|2.0|believe it has to have three properties
748.88|2.72|that are critical
749.6|3.12|it has to be large and millions of
751.6|2.72|examples
752.72|3.28|it needs to be clean so in this case we
754.32|3.36|have to have a very clean uh source of
756.0|2.639|depth velocity and acceleration for all
757.68|3.04|these cars
758.639|3.681|and it must be diverse so we're not just
760.72|3.679|talking about a single
762.32|3.84|you know driving club of going forward
764.399|3.12|on a highway we really have to get into
766.16|2.72|the edge cases and mine all the
767.519|2.481|difficult scenarios and i'm going to
768.88|3.28|show you some examples
770.0|3.04|and when you have a large clean diverse
772.16|3.2|data set
773.04|3.84|um and you train a large enough neural
775.36|3.84|network on it what i've seen
776.88|4.24|in practice uh is in the words of ilya
779.2|4.079|saskar saskar
781.12|3.76|success is guaranteed and so let me show
783.279|3.281|you some examples of that
784.88|2.88|so how are we going to so first of all
786.56|1.76|how are we going to achieve this data
787.76|3.04|set
788.32|3.12|so of course we need to collect training
790.8|2.159|data
791.44|3.04|the typical approach might be to use
792.959|4.161|humans to annotate
794.48|4.4|cars around us in three dimensions um
797.12|4.32|what we found actually works really well
798.88|4.32|is an auto labeling approach so it's not
801.44|4.0|pure humans just like annotating cars
803.2|4.16|it's it's an offline tracker as we call
805.44|4.56|it and it's an auto labeling process
807.36|3.68|for uh collecting data at the scale that
810.0|2.8|is necessary
811.04|3.2|uh so we need again millions of hard
812.8|3.039|examples so this is where the scale
814.24|3.279|comes from is that it's not labeled
815.839|2.481|purely by humans although humans are
817.519|2.961|involved
818.32|3.759|it's labeled automatically so here's an
820.48|2.32|example of some automatic labels we were
822.079|3.601|able to derive
822.8|3.44|four cars on the highway and the way you
825.68|2.719|do this
826.24|3.68|is because you're offline and you're
828.399|3.921|trying to just annotate a clip
829.92|3.68|you have a large number of benefits that
832.32|2.0|you don't typically have if you're at
833.6|2.96|test time
834.32|3.04|under strict latency requirements in the
836.56|2.56|car
837.36|3.2|so you can take your time to fully
839.12|2.079|figure out exactly all the objects and
840.56|1.76|where they are
841.199|3.121|you can use neural networks that are
842.32|4.16|extremely heavy they are not deployable
844.32|3.68|for various reasons you can use benefit
846.48|2.56|of hindsight because you know the future
848.0|2.24|not just the past
849.04|2.479|you can use all kinds of expensive
850.24|2.32|offline optimization and tracking
851.519|3.361|techniques
852.56|3.839|you can use extra sensors in this case
854.88|2.88|for example actually radar was one of
856.399|2.0|the sensors that we used for the auto
857.76|1.6|labeling
858.399|2.481|but there's actually a massive
859.36|2.64|difference between using radar at test
860.88|3.199|time and using it
862.0|4.0|in the offline tracker and that is that
864.079|3.601|at test time a radar can just report
866.0|3.44|a stationary track immediately in front
867.68|3.36|of you and you have 20 milliseconds to
869.44|3.519|decide if you're gonna break or not
871.04|3.599|if you're offline you have the benefit
872.959|2.721|of hindsight and so you can do a much
874.639|3.44|better job of
875.68|4.159|calmly fusing if you really want to and
878.079|2.88|so there is a massive difference there
879.839|2.641|and in addition you can of course
880.959|4.24|involve humans and they can do cleaning
882.48|4.96|verification editing and so on
885.199|4.0|um and so we basically found that this
887.44|2.32|was a massive lever to allow us to reach
889.199|3.121|the
889.76|3.84|scale and the label and quality and then
892.32|3.6|to get the diversity
893.6|3.679|uh that was also a massive fight so
895.92|4.0|here's some examples of
897.279|3.201|really tricky scenarios so here there's
899.92|1.84|some
900.48|4.0|i don't actually know exactly what this
901.76|5.199|is but basically this car um
904.48|4.0|drops a bunch of debris on us and we
906.959|3.68|maintain a consistent track
908.48|3.52|for the label and of course if you have
910.639|3.521|millions of labels like this
912.0|3.76|the neural net if it's a powerful enough
914.16|3.119|neural net uh will actually end up
915.76|3.04|learning to persist these tracks in
917.279|3.441|these kinds of scenarios
918.8|3.2|here's another example there's a car in
920.72|3.119|front of us
922.0|3.44|and i actually am not 100 sure what
923.839|2.961|happens in this case but
925.44|2.88|as you'll see there's some kind of a
926.8|3.36|dust cloud that develops here and
928.32|4.0|briefly occludes the car
930.16|3.599|but in the auto labeling tool we are
932.32|2.079|able to persist this track because we
933.759|2.161|saw it before
934.399|3.521|and we saw it after so we can actually
935.92|3.76|stitch it up and use it as a training
937.92|2.8|set for the neural net
939.68|4.079|here's one more example of an
940.72|6.16|adversarial scenario from heavy snow
943.759|6.0|again we can auto label this fine and
946.88|4.24|create a large collection of samples now
949.759|3.121|as we were working on this over a
951.12|3.519|duration of i want to say roughly four
952.88|3.519|months of really just focusing a lot of
954.639|3.12|the team on this problem of achieving
956.399|2.481|really good depth velocity and
957.759|3.921|acceleration
958.88|4.079|we've ended up developing 221 triggers
961.68|3.76|manually
962.959|3.761|that we were using to source data from
965.44|4.0|our customer fleet
966.72|5.28|and this is just an example um some
969.44|4.24|examples of the 221 triggers that were
972.0|5.279|used to collect all of these uh
973.68|6.56|diverse scenarios so for example we have
977.279|4.401|um shadow mode where we deploy a neural
980.24|3.279|network that is pretty good at
981.68|4.0|predicting depth and velocity and what
983.519|4.081|we do is we run it silently in the cars
985.68|3.519|of our customers but it's not actually
987.6|3.84|connected to control
989.199|3.2|what's driving is the legacy stack but
991.44|2.079|we're
992.399|2.321|we're basically running the new
993.519|2.401|measurements of depth and velocity and
994.72|2.479|we're for example looking at whether or
995.92|3.039|not they agree or disagree with the
997.199|3.521|legacy stack or with the radar
998.959|3.12|we're looking for other sources of gen
1000.72|1.919|like for example if there's bombing box
1002.079|2.32|jitter
1002.639|3.76|detection jitter the main and the narrow
1004.399|3.281|camera disagree
1006.399|2.88|we predict that there's a harshly
1007.68|2.719|decelerating object but the person seems
1009.279|3.201|to not mind
1010.399|3.36|um all kinds of disagreements between
1012.48|4.08|different neural network
1013.759|4.241|signals and you know there's a there's a
1016.56|3.04|long list here
1018.0|3.04|it took us a while to actually perfect
1019.6|2.799|these triggers and all of them are
1021.04|2.08|iteration and you're looking at what's
1022.399|3.201|coming back
1023.12|4.88|you're tuning your trigger and uh you're
1025.6|4.719|sourcing data from all these scenarios
1028.0|4.0|so basically over the last four months
1030.319|3.841|we've done quite extensive data engine
1032.0|3.199|we've ended up doing seven shadow modes
1034.16|3.12|and seven loops
1035.199|3.441|around this data engine here where on
1037.28|2.159|the top right is where you begin you
1038.64|2.799|have some seed
1039.439|3.041|data set you train your neural network
1041.439|2.961|on your data set
1042.48|3.439|and you deploy the neural network in the
1044.4|2.799|customer cars in shadow mode
1045.919|2.961|and the network is silently making
1047.199|2.961|predictions and then you have to have
1048.88|3.039|some mechanisms for sourcing
1050.16|3.519|inaccuracies of the neural net so you're
1051.919|3.201|just looking at its predictions
1053.679|3.36|um and then you're using one of these
1055.12|3.439|triggers like i described you're getting
1057.039|3.121|these scenarios where the network is
1058.559|3.36|probably misbehaving
1060.16|3.12|some of those clips end up going to unit
1061.919|2.88|tests to make sure that we
1063.28|3.759|even if we're failing right now we make
1064.799|3.601|sure we pass later and in addition those
1067.039|3.441|examples are being auto labeled
1068.4|4.0|and incorporated into a training set and
1070.48|3.439|then as a asynchronous process we're
1072.4|2.8|also always data cleaning the current
1073.919|3.041|training set
1075.2|3.28|and so we spin this loop over and over
1076.96|3.04|again until the network basically
1078.48|4.079|becomes incredibly good
1080.0|4.08|so in total we've done seven rounds of
1082.559|3.441|shadow mode for this release
1084.08|4.4|um we've accumulated one million
1086.0|4.72|extremely hard diverse clips
1088.48|3.92|and these are videos so these are you
1090.72|2.16|should roughly think about say 10 second
1092.4|2.96|clips
1092.88|3.52|36 fps something like that in total we
1095.36|2.96|have about six billion
1096.4|4.24|objects labeled cleanly for depth and
1098.32|3.12|velocity and this takes up roughly 1.5
1100.64|3.919|megabytes
1101.44|4.16|of storage uh so that gives us a really
1104.559|2.24|good data set
1105.6|3.52|of course that by itself does not
1106.799|5.281|suffice so we have an incredibly good
1109.12|4.16|ai team of uh that is designing the
1112.08|2.479|neural network architecture
1113.28|3.36|there's basically the layout of the
1114.559|4.561|synthetic visual cortex in order to
1116.64|4.399|efficiently process this information so
1119.12|3.12|our architecture roughly looks like this
1121.039|3.041|we have these images coming from
1122.24|3.679|multiple cameras on the top all of them
1124.08|2.8|are processed by an image extractor like
1125.919|4.161|a backbone like
1126.88|4.4|think resnet kind of style then there's
1130.08|2.88|a multicam fusion
1131.28|3.68|that fuses the information from all the
1132.96|4.32|eight views um
1134.96|4.24|and this is a kind of a transformer that
1137.28|3.519|we use uh to fuse this information
1139.2|3.839|and then we fuse information first
1140.799|4.721|across all the cameras and then across
1143.039|3.361|all of time and that is also done either
1145.52|2.64|by transformer
1146.4|3.2|by the current neural network or just by
1148.16|3.519|three-dimensional convolutions we've
1149.6|3.92|experimented with a lot of
1151.679|3.281|kind of fusion strategies here to get
1153.52|3.039|this to work really well
1154.96|3.04|and then what we have afterwards after
1156.559|3.12|the fusion is done is we have this
1158.0|2.799|branching structure that doesn't just
1159.679|2.721|consist of heads
1160.799|3.841|but actually we've expanded this over
1162.4|3.92|the last few last year or so
1164.64|3.919|where you now have heads that branch
1166.32|4.56|into trunks that branch into terminals
1168.559|3.601|so there's a lot of branching structure
1170.88|1.76|and the reason you want this branching
1172.16|1.68|structure
1172.64|2.8|is because there's a huge amount of
1173.84|2.959|outputs that you're interested in and
1175.44|2.64|you can't afford to have a single neural
1176.799|3.361|network for every one of the individual
1178.08|3.599|outputs you have to of course amortize
1180.16|3.759|the forward pass
1181.679|3.36|for efficient inference at this time and
1183.919|3.041|so there's a lot of
1185.039|3.281|feature sharing here the other nice
1186.96|2.48|benefit of the branching structure is
1188.32|3.2|that it decouples
1189.44|4.32|at the terminals it decouples all these
1191.52|4.0|signals so if i am someone working on
1193.76|2.64|velocity for a particular object type or
1195.52|2.399|something like that
1196.4|3.12|i have a small piece of neural network
1197.919|3.201|that i can actually fine-tune without
1199.52|3.84|touching any of the other signals
1201.12|3.679|and so i can work in isolation to some
1203.36|2.319|extent and actually get something to
1204.799|2.641|work pretty well
1205.679|3.041|and then once in a while so basically
1207.44|3.28|the iteration scheme is that
1208.72|3.199|a lot of people are fine-tuning and once
1210.72|3.76|in a while we do an upper
1211.919|3.921|of all of the backbone end-to-end and so
1214.48|3.6|it's a very interesting
1215.84|3.92|uh sort of mechanism because we have uh
1218.08|2.079|you know a team of roughly 20 people who
1219.76|1.68|are
1220.159|3.041|i would say training neural works full
1221.44|2.8|time and they're all cooperating on the
1223.2|2.56|single neural net
1224.24|3.36|and so what if the workflow by which you
1225.76|3.36|do that is pretty fascinating
1227.6|3.68|and continues to be a challenge to
1229.12|3.679|actually design efficiently
1231.28|3.2|so we have a neural network architecture
1232.799|2.88|we have a data set now training these
1234.48|3.28|neural networks like i mentioned this is
1235.679|3.921|a 1.5 petabyte data set
1237.76|3.84|requires a huge amount of compute so i
1239.6|3.6|wanted to briefly give a plug to
1241.6|3.04|this insane supercomputer that we are
1243.2|4.4|building and using now
1244.64|4.399|um and uh you know for us computer
1247.6|3.12|vision is the brand and part of what we
1249.039|3.601|do and what enables the autopilot
1250.72|3.36|and uh for that to work really well you
1252.64|2.88|need a massive data set we get that from
1254.08|3.2|the fleet but you also need to train
1255.52|4.0|massive neural nets and experiment a lot
1257.28|4.639|so we've invested a lot into the compute
1259.52|3.36|in this case we have here a data center
1261.919|1.441|we have a cluster that we're just
1262.88|3.52|building
1263.36|5.36|that is 720 nodes of atx a100
1266.4|3.04|of the 80 gigabyte version so this is a
1268.72|3.36|massive
1269.44|4.56|supercomputer i actually believe that in
1272.08|4.8|terms of flops this is roughly
1274.0|3.36|uh number five supercomputer uh in the
1276.88|2.08|world
1277.36|3.28|so there's actually a fairly significant
1278.96|3.76|uh computer here um
1280.64|3.2|we have 10 petabytes of hot or nvme
1282.72|3.28|storage and
1283.84|3.12|uh it's also an incredibly fast uh
1286.0|3.2|storage so
1286.96|3.04|i believe 1.6 terabytes per second this
1289.2|3.839|is one of the world's
1290.0|4.559|fastest file systems and we have a 60 we
1293.039|4.241|have also a very uh efficient
1294.559|3.681|fabric um that connects all of this
1297.28|2.48|because of course if you're doing
1298.24|3.04|distributed training across your nodes
1299.76|2.96|you need your gradients to to be
1301.28|2.639|synchronized very efficiently and of
1302.72|1.92|course we are reading all of these
1303.919|2.801|videos from
1304.64|3.6|the file system and that requires uh
1306.72|3.199|really fat bite as well
1308.24|3.679|so uh this is a pretty incredible
1309.919|4.401|supercomputer um
1311.919|4.801|and uh so this is a gpu cluster uh next
1314.32|4.16|up we're really hoping that
1316.72|3.439|we're currently working on project dojo
1318.48|3.28|which will take this to next level
1320.159|2.801|uh but i'm not ready to sort of reveal
1321.76|1.76|any more details about that at this
1322.96|1.68|point
1323.52|2.56|what i would like to do is i would like
1324.64|1.919|to just briefly plug the supercomputing
1326.08|3.36|team
1326.559|3.281|uh they've been uh growing a lot um and
1329.44|2.479|so
1329.84|3.76|uh if if high performance computing for
1331.919|2.0|this application and for training these
1333.6|2.319|uh
1333.919|3.681|crazy neural networks excites you then
1335.919|2.961|we definitely appreciate more help
1337.6|3.12|so please contact the super computing
1338.88|3.84|team at supercomputing and tesla
1340.72|3.439|to help us build these clusters on the
1342.72|2.72|left here we have the compute nodes and
1344.159|3.841|on the right this is a
1345.44|3.04|network switch actually so the wires
1348.0|2.159|here
1348.48|4.72|is kind of like the white matter of this
1350.159|4.4|uh synthetic cortex i guess
1353.2|3.44|uh the other thing i wanted to briefly
1354.559|6.0|talk about is um
1356.64|5.76|i wanted to also mention briefly that um
1360.559|3.12|this effort basically is incredibly
1362.4|4.08|vertically integrated
1363.679|3.441|uh in the ai team so as i showed you we
1366.48|2.72|own
1367.12|3.439|the vehicle in the sensing and we source
1369.2|1.839|our own data and we annotate our own
1370.559|2.961|data
1371.039|3.76|and we train our on-prem cluster and
1373.52|2.8|then we deploy all of the neural
1374.799|2.481|networks that we train on our in-house
1376.32|4.16|developed chip
1377.28|5.92|so we have the fsd computer uh here that
1380.48|4.559|has two socs fse chips here and they
1383.2|3.12|have our own custom npu neural
1385.039|4.88|processing unit here
1386.32|5.28|at roughly 36 tops each and uh so
1389.919|3.281|these chips are specifically designed
1391.6|4.48|for the neural networks that
1393.2|3.2|we want to run for fsd applications and
1396.08|1.68|so
1396.4|2.8|everything is very vertically integrated
1397.76|3.039|in the team and i think that's pretty
1399.2|4.24|incredible because
1400.799|3.521|you get to really co-design an engineer
1403.44|3.28|at all the
1404.32|3.68|layers of that stack and uh there's no
1406.72|2.079|third party that is holding you back
1408.0|2.0|you're
1408.799|2.88|fully in charge of your own destiny
1410.0|2.96|which i think is incredibly unique and
1411.679|2.721|very exciting
1412.96|2.88|and then we have a deployment a pipeline
1414.4|2.32|here where we take these neural networks
1415.84|2.56|and we do a lot of
1416.72|3.6|typical graph optimization fusion
1418.4|4.159|quantization threshold calibration and
1420.32|4.64|so on and deploy it on our chip
1422.559|3.521|and uh we and this is in the customer's
1424.96|3.839|cars and
1426.08|3.68|these neural networks are under so now
1428.799|2.561|what i'd like to show is
1429.76|2.96|i first would like to show some
1431.36|2.08|qualitative examples of some of our
1432.72|2.0|results
1433.44|2.64|in terms of the depth and velocity
1434.72|3.12|predictions that we're able to achieve
1436.08|3.599|by putting all these pieces together and
1437.84|3.6|training these networks at scale
1439.679|3.841|so the first example here i have a video
1441.44|3.28|where this is on track testing so this
1443.52|3.12|is an engineering car
1444.72|3.12|and we asked it to slam on the brakes as
1446.64|2.88|hard as it possibly can
1447.84|3.199|so this is a very harsh braking here in
1449.52|2.0|front of us even though it doesn't look
1451.039|2.481|like that
1451.52|4.159|in the videos this is very heartbreaking
1453.52|3.519|um so what you can see on the right here
1455.679|2.801|is you can see the outputs from the
1457.039|3.441|legacy stack which had
1458.48|3.76|radar vision fusion and from the new
1460.48|4.64|stack which is vision alone
1462.24|5.039|in blue so in the orange legacy stack
1465.12|3.919|you can actually see these uh
1467.279|3.041|track drops here when the car was
1469.039|2.721|breaking really harshly
1470.32|3.599|and basically the issue is that the
1471.76|3.36|braking was so harsh that the radar
1473.919|3.441|stack that we have
1475.12|3.919|actually ended up uh not associating the
1477.36|3.52|car and dropping the track and then
1479.039|3.361|reinitializing it all the time
1480.88|3.279|and so it's as if the vehicle
1482.4|3.759|disappeared and reappeared like
1484.159|3.921|six times during the period of this
1486.159|2.721|breaking and so this created a bunch of
1488.08|2.719|artifacts here
1488.88|3.76|but we see that the new stack in blue is
1490.799|3.201|actually not subject to this
1492.64|3.519|behavior at all it just gives a clean
1494.0|3.36|signal in fact here there's no smoothing
1496.159|3.041|i believe on the blue
1497.36|3.36|signal here this is the raw depth and
1499.2|1.92|velocity that comes out from the neural
1500.72|2.64|net
1501.12|3.919|the final neuron uh that we released
1503.36|3.36|with about three weeks ago and you can
1505.039|3.921|see that it's fairly smooth here
1506.72|3.839|and of course you could go into the
1508.96|3.36|radar stack and you could
1510.559|3.36|um you know adjust the height parameters
1512.32|2.8|of the tracker like why is it dropping
1513.919|2.401|tracks and so on
1515.12|3.2|but then you are spending engineering
1516.32|4.479|efforts and focus on a stack
1518.32|3.2|that is like not really barking up the
1520.799|2.321|right tree
1521.52|2.72|and so it's better to again just focus
1523.12|1.52|on the vision and make it work really
1524.24|2.08|well
1524.64|3.44|and we see that it is much more robust
1526.32|4.4|when you train it at scale
1528.08|3.199|then something like this here's another
1530.72|3.839|example
1531.279|4.801|um fairly infamous example of slowdowns
1534.559|3.441|when there are cars
1536.08|3.52|going below a bridge the issue here
1538.0|3.12|again is that the radar does not have
1539.6|4.4|too much vertical resolution
1541.12|3.84|so radar reports a stationary object in
1544.0|2.48|front of you
1544.96|3.04|it's as it like the radar doesn't know
1546.48|2.799|that there's if it's there's like a
1548.0|2.08|stationary car in front of you or if
1549.279|2.64|it's the bridge but
1550.08|2.88|it cannot differentiate those two so
1551.919|2.24|radar thinks that there might be
1552.96|2.719|something stationary in front
1554.159|3.201|and it's just like looking for something
1555.679|2.961|in vision to tell it that it might be
1557.36|2.4|correct and then we create a stationary
1558.64|3.2|target and break
1559.76|3.039|and so in this case in the legacy vision
1561.84|2.24|uh predictions
1562.799|3.201|which were already producing depth and
1564.08|4.8|velocity but
1566.0|4.0|because we were using radar the vision
1568.88|4.159|inaccuracies were being
1570.0|5.6|masked because um your bar
1573.039|3.12|is only at radar association your bar is
1575.6|2.24|not at
1576.159|3.441|actual driving and so the depth and
1577.84|2.48|velocity were not held up to high enough
1579.6|2.8|bar
1580.32|3.12|and so basically what happens is vision
1582.4|3.12|reports a slightly
1583.44|3.839|for a few frames reports a slightly too
1585.52|3.2|negative velocity for the car
1587.279|3.121|and then it associates to the stationary
1588.72|2.88|object and the stack is like oh that
1590.4|2.48|must be the stationary thing and then
1591.6|4.48|you break
1592.88|4.72|and so um this of course is much cleaner
1596.08|2.959|and you see that the new stack
1597.6|3.6|does not see this at all and there's no
1599.039|3.12|track there's no uh slowdowns in this
1601.2|2.88|case
1602.159|3.601|um because we just get the correct depth
1604.08|3.199|and velocity and vision obviously has
1605.76|3.039|the vertical resolution to differentiate
1607.279|3.361|a bridge from a car and whether or not
1608.799|3.521|the car is slowing or not
1610.64|3.76|so again you could go into the vision
1612.32|2.88|step the radar stack or the sensor
1614.4|1.92|fusion stack
1615.2|2.56|and if you have an improved depth and
1616.32|2.239|velocity you could change the fusion
1617.76|2.08|strategy
1618.559|2.881|uh but again you're just kind of like
1619.84|2.8|doing dead work like this signal is so
1621.44|4.16|good by itself
1622.64|3.44|why would you why would you do that um
1625.6|2.48|so
1626.08|4.16|in this in this setting now we've we've
1628.08|4.719|improved the situation quite a lot
1630.24|3.52|here's another last example um we have a
1632.799|2.401|stationary approach
1633.76|3.039|again this is in track testing
1635.2|3.04|environment uh this is an example of a
1636.799|2.88|test that we would run
1638.24|3.28|and we are just approaching this vehicle
1639.679|3.521|i'm hoping to stop what you see in
1641.52|2.879|orange in the legacy stack is that it
1643.2|2.479|actually takes us
1644.399|2.961|quite a bit of time for us to start
1645.679|2.321|slowing and basically what's happening
1647.36|2.16|here is that
1648.0|3.6|the radar is very trigger happy and it
1649.52|2.639|sees all these false stationary objects
1651.6|2.24|everywhere
1652.159|3.041|like everything that like sticks out is
1653.84|2.88|a is a stationary target
1655.2|3.12|and radar by itself doesn't know what
1656.72|3.36|actually is a stationary car and what
1658.32|3.92|isn't so it's waiting for vision to
1660.08|3.599|associate with it and vision if it's not
1662.24|4.319|held up to a high enough bar
1663.679|3.281|is noisy and contributes um sort of
1666.559|1.84|error
1666.96|3.28|and the sensor fusion stack just kind of
1668.399|2.801|like picks it up too late and so again
1670.24|2.72|you could fix all that
1671.2|3.44|even though it's a very gross system
1672.96|2.8|with a lot of if statements and so on
1674.64|2.72|uh because the sensor fusion is
1675.76|2.799|complicated because the error modes for
1677.36|3.52|vision and radar
1678.559|4.0|are slightly are quite different but
1680.88|3.44|here when we just work with vision alone
1682.559|3.441|and we take out the radar uh vision
1684.32|2.8|recognizes this object very early gives
1686.0|2.159|the correct depth and velocity and
1687.12|2.4|there's no issues
1688.159|3.441|so we actually get an initial slow down
1689.52|5.32|much earlier and we've really
1691.6|4.88|like simplified the stack a lot and as
1694.84|2.92|well
1696.48|4.319|so just speaking very briefly to the
1697.76|4.639|release and validation um
1700.799|3.76|we've extensively validated this before
1702.399|4.721|we of course uh ship this to customers
1704.559|3.6|uh just some example uh numbers for the
1707.12|2.799|validation itself
1708.159|3.681|uh we've hand picked six thousand clips
1709.919|3.601|in about 70 categories of scenarios like
1711.84|3.28|harsh breaking crossing vehicles
1713.52|4.24|uh different vehicle types environments
1715.12|4.799|and so on and we run these uh
1717.76|3.36|tests on all the commits of the build
1719.919|2.64|and we run them also every day
1721.12|3.36|periodically as we were trying to drive
1722.559|3.521|up the performance on these clips
1724.48|3.52|we also use simulation extensively for
1726.08|3.12|validation we've also used simulation
1728.0|2.0|for training although i haven't gotten
1729.2|2.64|into that
1730.0|3.36|but we've had some successes there but
1731.84|2.0|we used primarily for validation at this
1733.36|2.08|stage
1733.84|2.959|and that's again like diversity of
1735.44|3.599|scenarios trying to make sure that the
1736.799|3.521|stack is performing correctly
1739.039|3.041|we've done a lot of track testing and
1740.32|3.359|i've shown you some examples of that
1742.08|3.92|we've driven this extensively in the qa
1743.679|3.281|fleet and we've also deployed this in
1746.0|3.36|shadow modes
1746.96|4.079|and seen that this stack performs fairly
1749.36|2.08|well so in particular for example for
1751.039|2.081|the
1751.44|3.76|automatic emergency braking we actually
1753.12|3.679|see a higher precision and recall
1755.2|4.0|compared to the legacy stack that is a
1756.799|3.681|fusion stack and so having seen all this
1759.2|3.04|we've actually released this we've
1760.48|4.799|accumulated about 15 million miles
1762.24|4.559|so far and 1.7 million
1765.279|3.201|of those have been on autopilot and so
1766.799|2.961|far there have been no crashes now of
1768.48|3.84|course we're running at
1769.76|3.84|a massive scale here and so we do expect
1772.32|3.359|some crashes at some point
1773.6|4.4|uh the legacy stack uh has a crash
1775.679|2.961|roughly every five million miles or so i
1778.0|2.72|believe
1778.64|3.519|and so we do expect some some ascendance
1780.72|3.92|uh um
1782.159|3.601|at some point but this uh the
1784.64|2.639|improvements for the vision stack are
1785.76|2.639|not sort of stopping so i think we're
1787.279|2.88|very confident that
1788.399|3.201|uh we're barking up the right tree here
1790.159|4.561|and that we can actually get this work
1791.6|4.799|really incredibly well
1794.72|3.36|um i also want to briefly give a shout
1796.399|2.481|out to other labeling as an incredibly
1798.08|3.839|powerful
1798.88|4.399|method for sourcing training data so
1801.919|2.961|we're applying auto labeling to all of
1803.279|2.961|the fsd tasks not just the depth and
1804.88|4.88|velocity of the car in front of us
1806.24|5.52|here's an auto labeler for pedestrians
1809.76|3.919|and you can see that the tracks are very
1811.76|2.96|smooth and this is again a completely
1813.679|2.72|offline process
1814.72|3.52|that we are applying not just to objects
1816.399|4.801|but also to
1818.24|4.319|a lot of static environments so this is
1821.2|3.76|some example of a
1822.559|3.921|3d reconstruction so here we see a clip
1824.96|4.64|and this is a vision only
1826.48|4.72|estimate of the depths of all the points
1829.6|3.199|and of course you don't actually want to
1831.2|3.599|really deploy
1832.799|3.441|these measurements directly into a car
1834.799|2.48|because they are too raw
1836.24|2.799|so what you actually want to do is you
1837.279|3.041|want to again auto label and you want to
1839.039|2.721|really think about what is it what is
1840.32|2.8|the information i really need at test
1841.76|3.76|time in the car
1843.12|3.439|and what is like as close as possible to
1845.52|2.159|action right
1846.559|2.48|so you want to do all this work at
1847.679|2.24|training time figure out exactly what
1849.039|2.561|happened in the club
1849.919|2.64|reconstruct the entire environment and
1851.6|2.319|then you want to actually like
1852.559|3.36|post-process the curb
1853.919|3.76|at training time so you want to do as
1855.919|2.64|much a training time and labeling time
1857.679|2.24|as possible
1858.559|3.201|and then you want to figure out what are
1859.919|4.081|the tasks i really need at test time
1861.76|3.36|and that's the thing that happens in the
1864.0|2.799|car
1865.12|2.96|you know subject to very strict latency
1866.799|4.0|requirements you want to do as little
1868.08|4.959|processing there as possible
1870.799|3.681|so we see that this is a very powerful
1873.039|4.48|lever on occurring
1874.48|4.4|dss so in summary what i try to argue
1877.519|3.441|and give you a sense of is
1878.88|3.679|vision alone is actually in our is our
1880.96|2.719|finding that this is perfectly capable
1882.559|3.441|of death sensing
1883.679|3.6|um it is an incredibly rich sensor in
1886.0|4.32|terms of bandwidth
1887.279|4.561|of information and doing this and
1890.32|3.28|matching radar performance and depth and
1891.84|3.679|velocity is incredibly hard
1893.6|3.04|i believe it requires the fleet because
1895.519|2.561|the data set that we were able to
1896.64|2.32|achieve was critical in all these
1898.08|2.719|performance
1898.96|3.599|uh improvements and if you do not have
1900.799|2.24|the fleet i'm not 100 sure how you can
1902.559|1.761|source
1903.039|3.12|all the difficult and diversity
1904.32|3.599|scenarios that we did source
1906.159|3.36|um because i believe that was critical
1907.919|3.521|to getting this to work so
1909.519|3.28|it's hard requires massive networks a
1911.44|4.56|super computer and
1912.799|5.12|a data engine and the fleet but all
1916.0|4.799|these components are coming together
1917.919|3.201|in um in a vertical integrated fashion
1920.799|2.72|at
1921.12|3.12|tesla ai and i believe that this makes
1923.519|2.0|us uh
1924.24|3.36|sort of uniquely positioned in the
1925.519|3.76|industry where um we are
1927.6|3.199|barking up the right tree and we have
1929.279|3.841|all the puzzle pieces to make
1930.799|3.041|to make this work and so if you are
1933.12|2.88|excited about the
1933.84|3.679|leapers that we're taking and uh the
1936.0|2.96|networks and the work that we're doing
1937.519|3.361|then i would encourage you to please
1938.96|3.68|apply uh and join the team
1940.88|3.76|and help us make this a reality so you
1942.64|3.919|can go to tesla.com autopilot ai
1944.64|3.039|it's a very simple process uh you upload
1946.559|2.72|a resume and you
1947.679|2.88|you have a blurb about some of the
1949.279|2.0|things that you've done that are
1950.559|2.561|impressive
1951.279|3.201|and then that comes directly to us and
1953.12|2.399|uh we'd love to work with you to make
1954.48|3.36|this reality
1955.519|2.321|thank you
1959.679|3.521|thanks for this very very interesting
1962.32|4.079|talk
1963.2|6.56|uh we actually got quite some questions
1966.399|6.4|uh since we are already over time
1969.76|5.6|i will limit it to a few we are at the
1972.799|4.88|you know the kind of nice point at the
1975.36|5.199|end of the workshop so
1977.679|4.72|you are a bit of a rough spot that you
1980.559|3.041|have to answer more questions than maybe
1982.399|4.481|other
1983.6|3.679|speakers um and kind of i would like to
1986.88|3.44|go
1987.279|5.28|as a first one into the you know
1990.32|3.44|kind of the auto lay maybe bit to auto
1992.559|3.12|labeling but actually
1993.76|3.36|the thing which really is necessary for
1995.679|4.48|the auto labeling and this is
1997.12|5.279|these um you know this definition of
2000.159|4.961|these triggers
2002.399|3.201|uh did you ever try to investigate if
2005.12|3.76|you can
2005.6|4.72|automatically automatically uh generate
2008.88|4.88|those triggers
2010.32|7.359|um that's an interesting question
2013.76|5.84|um so the triggers are kind of like
2017.679|3.041|they're designed based on what we're
2019.6|2.559|seeing and what's coming back in the
2020.72|4.0|telemetry from the cars
2022.159|3.441|so we are seeing clips where maybe we we
2024.72|2.48|didn't break
2025.6|2.88|what the person did or vice versa
2027.2|3.44|there's all kinds of disagreements with
2028.48|3.6|like human driving and the legacy stack
2030.64|3.12|and we're looking at this and typically
2032.08|4.479|we try to have signals of
2033.76|3.68|various um generality so for example
2036.559|3.441|like a vision
2037.44|4.16|radar uh disagreement is a very general
2040.0|3.519|trigger it can source
2041.6|3.36|all the disagreements um and then there
2043.519|2.961|are very specific ones like maybe we
2044.96|2.8|struggled actually for a while when we
2046.48|2.399|were entering tunnels and exiting
2047.76|2.319|tunnels because there was a lot of
2048.879|2.48|brightness variation
2050.079|3.04|so we struggled a lot there as an
2051.359|3.361|example and we had to
2053.119|3.441|specifically design some triggers for
2054.72|5.119|that because we were not catching it
2056.56|4.72|uh with a high enough frequency um
2059.839|2.481|for any of these situations you actually
2061.28|2.24|need to make sure they're represented
2062.32|3.519|well in the training step
2063.52|3.92|so for us this was a fairly manual
2065.839|3.52|process but we do have a team
2067.44|3.36|basically dedicated to doing this
2069.359|3.76|full-time and they did this for four
2070.8|2.319|months
2073.359|4.56|so i don't like how do you automate this
2076.159|3.041|i think is a very tricky scenario
2077.919|2.401|because
2079.2|3.199|again you can have these general
2080.32|5.2|triggers but i think they will not
2082.399|4.24|correctly represent uh the error modes
2085.52|2.559|and i think it would be really hard to
2086.639|2.24|for example automatically somehow have a
2088.079|3.76|trigger
2088.879|3.841|um that triggers for entering and
2091.839|1.921|exiting tunnels that's something
2092.72|3.119|semantic that
2093.76|3.04|you as a person have to like intuit that
2095.839|2.401|this is a
2096.8|3.2|challenge for whatever reason and
2098.24|4.879|actually go after it specifically
2100.0|4.079|so um yeah it's not it's not clear how
2103.119|2.881|that would work but i think it's a
2104.079|5.921|really interesting idea
2106.0|5.28|yeah uh so i thought it sounded the very
2110.0|2.24|interest the question sounded very
2111.28|4.16|interesting and
2112.24|5.76|not easy to answer yeah uh
2115.44|3.52|maybe another one which actually in
2118.0|5.359|somehow let's say
2118.96|8.159|two version uh showed up a bit was
2123.359|6.961|kind of in your vision only approach
2127.119|5.281|um kind of
2130.32|3.039|could there be other sensor like you
2132.4|4.4|know for example
2133.359|6.801|thermal uh thermal imaging you know
2136.8|5.44|kind of thermal cameras uh which could
2140.16|4.16|help you in low light situation or
2142.24|4.64|actually even the radar which could
2144.32|4.56|kind of give you some very specific
2146.88|2.719|information i think there was an example
2148.88|4.08|of
2149.599|5.681|radar signals bouncing through basically
2152.96|4.0|the car before you and then you still
2155.28|5.36|get somehow a signal of the
2156.96|6.72|car you know one what a head
2160.64|5.76|things like that you think really vision
2163.68|4.96|vision is enough or
2166.4|3.92|kind of you know maybe some special
2168.64|2.88|sensors which could give you a certain
2170.32|2.72|edge
2171.52|3.68|yeah i think it's an interesting idea i
2173.04|4.72|would say
2175.2|3.6|um like clearly people people use vision
2177.76|3.839|and visual spectrum
2178.8|3.84|and they make it work and so there's an
2181.599|3.121|infinity sensors
2182.64|4.08|of varying economic costs actually
2184.72|3.52|vision and uh in the visible
2186.72|3.44|light spectrum is incredibly cheap
2188.24|2.48|sensor right so the economics of this
2190.16|2.56|are very
2190.72|3.68|uh appealing and you can actually uh
2192.72|4.639|manufacture and include this at scale
2194.4|4.32|so it's a very cheap and uh nice sensor
2197.359|3.281|and
2198.72|3.119|i would say that basically we have proof
2200.64|3.84|from humans that it is
2201.839|3.441|um sufficient and i would say also that
2204.48|2.72|um
2205.28|3.52|vision has all the information uh for
2207.2|3.84|driving so i would say that
2208.8|3.76|basically vision is necessary and
2211.04|4.4|sufficient in my mind
2212.56|4.4|and um so we're primarily focusing on
2215.44|2.639|that and you could go crazy with a lot
2216.96|2.96|of sensors but
2218.079|5.201|uh i think we're definitely currently
2219.92|3.36|just doubling down on that alone
2223.76|4.88|yeah thanks a lot um i think
2227.04|3.2|we are now already more than five
2228.64|4.24|minutes overtime
2230.24|2.64|uh so
2233.359|7.361|i let you go and don't ask other evil
2236.88|6.56|lidar versus camera questions
2240.72|3.84|and um with this i would actually like
2243.44|4.48|to give some
2244.56|5.12|uh kind of concluding remarks on the
2247.92|5.84|workshop uh or better
2249.68|8.88|uh you know move over to the last part
2253.76|4.8|so uh before
2258.72|4.08|yeah i would really like to thank the
2261.04|4.12|whole team
2262.8|5.36|without them this would have never been
2265.16|3.0|possible