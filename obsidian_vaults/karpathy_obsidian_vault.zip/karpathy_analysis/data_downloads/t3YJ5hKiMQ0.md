start_time|end_time|text
0.0|4.5|hi everyone today we are continuing our
2.58|3.84|implementation of make more our favorite
4.5|3.48|character level language model
6.42|3.3|now you'll notice that the background
7.98|4.02|behind me is different that's because I
9.72|3.72|am in Kyoto and it is awesome so I'm in
12.0|3.059|a hotel room here
13.44|4.32|now over the last few lectures we've
15.059|4.681|built up to this architecture that is a
17.76|3.72|multi-layer perceptron character level
19.74|3.299|language model so we see that it
21.48|3.12|receives three previous characters and
23.039|3.721|tries to predict the fourth character in
24.6|4.32|a sequence using a very simple multi
26.76|4.679|perceptron using one hidden layer of
28.92|4.38|neurons with 10ational neuralities
31.439|3.181|so we'd like to do now in this lecture
33.3|3.419|is I'd like to complexify this
34.62|4.2|architecture in particular we would like
36.719|4.381|to take more characters in a sequence as
38.82|4.14|an input not just three and in addition
41.1|3.9|to that we don't just want to feed them
42.96|3.84|all into a single hidden layer because
45.0|4.079|that squashes too much information too
46.8|4.739|quickly instead we would like to make a
49.079|4.5|deeper model that progressively fuses
51.539|4.02|this information to make its guess about
53.579|3.96|the next character in a sequence
55.559|4.32|and so we'll see that as we make this
57.539|4.081|architecture more complex we're actually
59.879|3.84|going to arrive at something that looks
61.62|3.899|very much like a wavenet
63.719|5.881|the witness is this paper published by
65.519|6.42|the point in 2016 and it is also a
69.6|4.019|language model basically but it tries to
71.939|3.901|predict audio sequences instead of
73.619|5.341|character level sequences or Word level
75.84|4.98|sequences but fundamentally the modeling
78.96|4.44|setup is identical it is an auto
80.82|4.619|aggressive model and it tries to predict
83.4|3.42|next character in a sequence and the
85.439|4.141|architecture actually takes this
86.82|4.38|interesting hierarchical sort of
89.58|3.66|approach to predicting the next
91.2|4.62|character in a sequence uh with the
93.24|3.66|street-like structure and this is the
95.82|3.0|architecture and we're going to
96.9|4.74|implement it in the course of this video
98.82|4.979|so let's get started so the starter code
101.64|4.799|for part five is very similar to where
103.799|4.14|we ended up in in part three recall that
106.439|3.121|part four was the manual black
107.939|3.661|replication exercise that is kind of an
109.56|4.199|aside so we are coming back to part
111.6|3.6|three copy pasting chunks out of it and
113.759|3.301|that is our starter code for part five
115.2|3.84|I've changed very few things otherwise
117.06|4.14|so a lot of this should look familiar to
119.04|4.079|if you've gone through part three so in
121.2|4.199|particular very briefly we are doing
123.119|5.941|Imports we are reading our our data set
125.399|6.121|of words and we are processing their set
129.06|4.259|of words into individual examples and
131.52|3.719|none of this data generation code has
133.319|4.381|changed and basically we have lots and
135.239|6.301|lots of examples in particular we have
137.7|6.36|182 000 examples of three characters try
141.54|4.26|to predict the fourth one and we've
144.06|3.72|broken up every one of these words into
145.8|3.84|little problems of given three
147.78|3.06|characters predict the fourth one so
149.64|3.3|this is our data set and this is what
150.84|4.32|we're trying to get the neural lot to do
152.94|6.6|now in part three we started to develop
155.16|5.82|our code around these layer modules
159.54|3.36|um that are for example like class
160.98|3.72|linear and we're doing this because we
162.9|4.559|want to think of these modules as
164.7|4.44|building blocks and like a Lego building
167.459|4.441|block bricks that we can sort of like
169.14|4.319|stack up into neural networks and we can
171.9|4.74|feed data between these layers and stack
173.459|5.581|them up into a sort of graphs
176.64|5.04|now we also developed these layers to
179.04|5.1|have apis and signatures very similar to
181.68|4.26|those that are found in pytorch so we
184.14|3.179|have torch.nn and it's got all these
185.94|3.36|layer building blocks that you would use
187.319|4.441|in practice and we were developing all
189.3|4.5|of these to mimic the apis of these so
191.76|5.52|for example we have linear so there will
193.8|4.92|also be a torch.nn.linear and its
197.28|3.3|signature will be very similar to our
198.72|3.72|signature and the functionality will be
200.58|4.019|also quite identical as far as I'm aware
202.44|4.74|so we have the linear layer with the
204.599|4.5|Bass from 1D layer and the 10h layer
207.18|4.86|that we developed previously
209.099|6.0|and linear just as a matrix multiply in
212.04|4.5|the forward pass of this module batch
215.099|2.341|number of course is this crazy layer
216.54|3.779|that we developed in the previous
217.44|5.519|lecture and what's crazy about it is
220.319|4.441|well there's many things number one it
222.959|3.541|has these running mean and variances
224.76|4.399|that are trained outside of back
226.5|5.819|propagation they are trained using
229.159|5.261|exponential moving average inside this
232.319|4.381|layer when we call the forward pass
234.42|4.2|in addition to that
236.7|3.179|there's this training plug because the
238.62|3.72|behavior of bathroom is different during
239.879|3.661|train time and evaluation time and so
242.34|3.24|suddenly we have to be very careful that
243.54|3.779|bash form is in its correct state that
245.58|3.239|it's in the evaluation state or training
247.319|2.881|state so that's something to now keep
248.819|2.761|track of something that sometimes
250.2|3.48|introduces bugs
251.58|4.079|uh because you forget to put it into the
253.68|4.38|right mode and finally we saw that
255.659|4.98|Bachelor couples the statistics or the
258.06|4.859|the activations across the examples in
260.639|4.941|the batch so normally we thought of the
262.919|5.641|bat as just an efficiency thing but now
265.58|5.08|we are coupling the computation across
268.56|3.48|batch elements and it's done for the
270.66|3.24|purposes of controlling the automation
272.04|2.939|statistics as we saw in the previous
273.9|3.06|video
274.979|3.381|so it's a very weird layer at least a
276.96|3.48|lot of bugs
278.36|3.94|partly for example because you have to
280.44|4.14|modulate the training in eval phase and
282.3|4.14|so on
284.58|4.619|um in addition for example you have to
286.44|4.8|wait for uh the mean and the variance to
289.199|4.621|settle and to actually reach a steady
291.24|4.44|state and so um you have to make sure
293.82|6.0|that you basically there's state in this
295.68|7.019|layer and state is harmful uh usually
299.82|4.98|now I brought out the generator object
302.699|4.321|previously we had a generator equals g
304.8|3.72|and so on inside these layers I've
307.02|5.94|discarded that in favor of just
308.52|7.02|initializing the torch RNG outside here
312.96|3.78|use it just once globally just for
315.54|2.7|Simplicity
316.74|3.179|and then here we are starting to build
318.24|4.5|out some of the neural network elements
319.919|4.741|this should look very familiar we are we
322.74|4.32|have our embedding table C and then we
324.66|4.52|have a list of players and uh it's a
327.06|5.34|linear feeds to Bachelor feeds to 10h
329.18|4.66|and then a linear output layer and its
332.4|4.139|weights are scaled down so we are not
333.84|4.26|confidently wrong at the initialization
336.539|3.961|we see that this is about 12 000
338.1|4.56|parameters we're telling pytorch that
340.5|4.44|the parameters require gradients
342.66|3.96|the optimization is as far as I'm aware
344.94|2.819|identical and should look very very
346.62|2.82|familiar
347.759|5.16|nothing changed here
349.44|4.979|uh loss function looks very crazy we
352.919|3.901|should probably fix this and that's
354.419|4.921|because 32 batch elements are too few
356.82|4.56|and so you can get very lucky lucky or
359.34|4.919|unlucky in any one of these batches and
361.38|4.92|it creates a very thick loss function
364.259|4.261|um so we're going to fix that soon
366.3|3.6|now once we want to evaluate the trained
368.52|3.36|neural network we need to remember
369.9|3.78|because of the bathroom layers to set
371.88|3.48|all the layers to be training equals
373.68|3.42|false so this only matters for the
375.36|4.339|bathroom layer so far
377.1|5.039|and then we evaluate
379.699|5.681|we see that currently we have validation
382.139|6.0|loss of 2.10 which is fairly good but
385.38|5.039|there's still ways to go but even at
388.139|3.541|2.10 we see that when we sample from the
390.419|4.021|model we actually get relatively
391.68|6.0|name-like results that do not exist in a
394.44|5.58|training set so for example Yvonne kilo
397.68|5.78|Pros
400.02|6.299|Alaia Etc so certainly not
403.46|5.079|reasonable not unreasonable I would say
406.319|3.781|but not amazing and we can still push
408.539|3.66|this validation loss even lower and get
410.1|3.24|much better samples that are even more
412.199|4.261|name-like
413.34|5.16|so let's improve this model
416.46|3.72|okay first let's fix this graph because
418.5|3.479|it is daggers in my eyes and I just
420.18|5.28|can't take it anymore
421.979|5.94|um so last I if you recall is a python
425.46|5.239|list of floats so for example the first
427.919|2.78|10 elements
430.86|3.36|now what we'd like to do basically is we
432.6|3.599|need to average up
434.22|4.8|um some of these values to get a more
436.199|4.62|sort of Representative uh value along
439.02|2.82|the way so one way to do this is the
440.819|4.081|following
441.84|5.52|in part torch if I create for example
444.9|4.139|a tensor of the first 10 numbers
447.36|4.02|then this is currently a one-dimensional
449.039|4.44|array but recall that I can view this
451.38|4.68|array as two-dimensional so for example
453.479|5.761|I can use it as a two by five array and
456.06|4.68|this is a 2d tensor now two by five and
459.24|3.6|you see what petroch has done is that
460.74|3.959|the first row of this tensor is the
462.84|3.9|first five elements and the second row
464.699|4.261|is the second five elements
466.74|3.299|I can also view it as a five by two as
468.96|3.26|an example
470.039|5.041|and then recall that I can also
472.22|3.759|use negative one in place of one of
475.08|3.059|these numbers
475.979|3.66|and pytorch will calculate what that
478.139|3.84|number must be in order to make the
479.639|3.481|number of elements work out so this can
481.979|4.021|be
483.12|5.9|this or like that but it will work of
486.0|3.02|course this would not work
489.24|4.32|okay so this allows it to spread out
491.52|3.959|some of the consecutive values into rows
493.56|4.02|so that's very helpful because what we
495.479|5.701|can do now is first of all we're going
497.58|5.1|to create a torshot tensor out of the a
501.18|3.12|list of floats
502.68|4.199|and then we're going to view it as
504.3|4.86|whatever it is but we're going to
506.879|4.5|stretch it out into rows of 1000
509.16|6.059|consecutive elements so the shape of
511.379|6.6|this now becomes 200 by 1000. and each
515.219|4.44|row is one thousand um consecutive
517.979|3.06|elements in this list
519.659|4.201|so that's very helpful because now we
521.039|6.061|can do a mean along the rows
523.86|5.039|and the shape of this will just be 200.
527.1|4.799|and so we've taken basically the mean on
528.899|4.681|every row so plt.plot of that should be
531.899|3.12|something nicer
533.58|3.24|much better
535.019|4.021|so we see that we basically made a lot
536.82|4.92|of progress and then here this is the
539.04|4.5|learning rate Decay so here we see that
541.74|3.84|the learning rate Decay subtracted a ton
543.54|3.72|of energy out of the system and allowed
545.58|3.78|us to settle into sort of the local
547.26|4.98|minimum in this optimization
549.36|5.76|so this is a much nicer plot let me come
552.24|4.74|up and delete the monster and we're
555.12|4.56|going to be using this going forward now
556.98|5.22|next up what I'm bothered by is that you
559.68|4.32|see our forward pass is a little bit
562.2|2.52|gnarly and takes way too many lines of
564.0|2.1|code
564.72|3.54|so in particular we see that we've
566.1|4.799|organized some of the layers inside the
568.26|4.68|layers list but not all of them uh for
570.899|3.601|no reason so in particular we see that
572.94|4.32|we still have the embedding table a
574.5|4.68|special case outside of the layers and
577.26|3.54|in addition to that the viewing
579.18|4.02|operation here is also outside of our
580.8|4.26|layers so let's create layers for these
583.2|3.06|and then we can add those layers to just
585.06|3.3|our list
586.26|4.44|so in particular the two things that we
588.36|4.68|need is here we have this embedding
590.7|6.06|table and we are indexing at the
593.04|5.28|integers inside uh the batch XB uh
596.76|4.139|inside the tensor xB
598.32|5.1|so that's an embedding table lookup just
600.899|4.021|done with indexing and then here we see
603.42|2.82|that we have this view operation which
604.92|4.859|if you recall from the previous video
606.24|6.3|Simply rearranges the character
609.779|5.041|embeddings and stretches them out into a
612.54|4.44|row and effectively what print that does
614.82|4.74|is the concatenation operation basically
616.98|5.76|except it's free because viewing is very
619.56|5.219|cheap in pytorch no no memory is being
622.74|4.8|copied we're just re-representing how we
624.779|3.541|view that tensor so let's create
627.54|3.6|um
628.32|4.26|modules for both of these operations the
631.14|2.759|embedding operation and flattening
632.58|4.5|operation
633.899|4.741|so I actually wrote the code in just to
637.08|3.6|save some time
638.64|4.86|so we have a module embedding and a
640.68|4.62|module pattern and both of them simply
643.5|6.0|do the indexing operation in the forward
645.3|8.58|pass and the flattening operation here
649.5|6.959|and this C now will just become a salt
653.88|4.56|dot weight inside an embedding module
656.459|3.421|and I'm calling these layers
658.44|2.7|specifically embedding a platinum
659.88|3.72|because it turns out that both of them
661.14|4.86|actually exist in pi torch so in
663.6|3.84|phytorch we have n and Dot embedding and
666.0|3.24|it also takes the number of embeddings
667.44|3.839|and the dimensionality of the bedding
669.24|3.779|just like we have here but in addition
671.279|4.441|python takes in a lot of other keyword
673.019|4.741|arguments that we are not using for our
675.72|3.96|purposes yet
677.76|4.199|and for flatten that also exists in
679.68|4.02|pytorch and it also takes additional
681.959|4.38|keyword arguments that we are not using
683.7|4.5|so we have a very simple platform
686.339|4.381|but both of them exist in pytorch
688.2|5.52|they're just a bit more simpler and now
690.72|6.119|that we have these we can simply take
693.72|6.299|out some of these special cased
696.839|4.74|um things so instead of C we're just
700.019|5.581|going to have an embedding
701.579|5.581|and of a cup size and N embed
705.6|3.179|and then after the embedding we are
707.16|3.84|going to flatten
708.779|4.381|so let's construct those modules and now
711.0|3.779|I can take out this the
713.16|4.679|and here I don't have to special case
714.779|7.141|anymore because now C is the embeddings
717.839|6.12|weight and it's inside layers
721.92|4.38|so this should just work
723.959|4.261|and then here our forward pass
726.3|3.719|simplifies substantially because we
728.22|4.799|don't need to do these now outside of
730.019|5.101|these layer outside and explicitly
733.019|4.081|they're now inside layers
735.12|4.68|so we can delete those
737.1|4.679|but now to to kick things off we want
739.8|4.38|this little X which in the beginning is
741.779|4.261|just XB uh the tensor of integers
744.18|3.42|specifying the identities of these
746.04|3.539|characters at the input
747.6|3.72|and so these characters can now directly
749.579|3.0|feed into the first layer and this
751.32|3.72|should just work
752.579|4.141|so let me come here and insert a break
755.04|3.06|because I just want to make sure that
756.72|3.72|the first iteration of this runs and
758.1|4.739|then there's no mistake so that ran
760.44|4.98|properly and basically we substantially
762.839|4.081|simplified the forward pass here okay
765.42|3.0|I'm sorry I changed my microphone so
766.92|2.58|hopefully the audio is a little bit
768.42|3.24|better
769.5|3.959|now one more thing that I would like to
771.66|3.299|do in order to pytortify our code even
773.459|3.361|further is that right now we are
774.959|4.201|maintaining all of our modules in a
776.82|4.199|naked list of layers and we can also
779.16|3.9|simplify this uh because we can
781.019|4.741|introduce the concept of Pi torch
783.06|3.959|containers so in tors.nn which we are
785.76|3.36|basically rebuilding from scratch here
787.019|3.721|there's a concept of containers
789.12|4.08|and these containers are basically a way
790.74|5.339|of organizing layers into
793.2|5.04|lists or dicts and so on so in
796.079|4.56|particular there's a sequential which
798.24|5.46|maintains a list of layers and is a
800.639|4.741|module class in pytorch and it basically
803.7|3.66|just passes a given input through all
805.38|3.36|the layers sequentially exactly as we
807.36|3.719|are doing here
808.74|5.219|so let's write our own sequential
811.079|4.021|I've written a code here and basically
813.959|3.12|the code for sequential is quite
815.1|4.44|straightforward we pass in a list of
817.079|4.621|layers which we keep here and then given
819.54|3.84|any input in a forward pass we just call
821.7|3.72|all the layers sequentially and return
823.38|3.3|the result in terms of the parameters
825.42|2.7|it's just all the parameters of the
826.68|4.02|child modules
828.12|4.74|so we can run this and we can again
830.7|3.66|simplify this substantially because we
832.86|4.14|don't maintain this naked list of layers
834.36|6.0|we now have a notion of a model which is
837.0|7.639|a module and in particular is a
840.36|4.279|sequential of all these layers
844.74|4.74|and now parameters are simply just a
847.74|4.08|model about parameters
849.48|4.32|and so that list comprehension now lives
851.82|4.079|here
853.8|4.08|and then here we are press here we are
855.899|4.081|doing all the things we used to do
857.88|4.139|now here the code again simplifies
859.98|4.44|substantially because we don't have to
862.019|4.38|do this forwarding here instead of just
864.42|3.659|call the model on the input data and the
866.399|5.221|input data here are the integers inside
868.079|5.7|xB so we can simply do logits which are
871.62|5.04|the outputs of our model are simply the
873.779|5.101|model called on xB
876.66|4.619|and then the cross entropy here takes
878.88|4.86|the logits and the targets
881.279|4.981|so this simplifies substantially
883.74|5.52|and then this looks good so let's just
886.26|5.16|make sure this runs that looks good
889.26|3.54|now here we actually have some work to
891.42|3.539|do still here but I'm going to come back
892.8|4.74|later for now there's no more layers
894.959|5.281|there's a model that layers but it's not
897.54|4.38|a to access attributes of these classes
900.24|2.88|directly so we'll come back and fix this
901.92|3.18|later
903.12|4.5|and then here of course this simplifies
905.1|5.4|substantially as well because logits are
907.62|6.48|the model called on x
910.5|5.399|and then these low Jets come here
914.1|3.299|so we can evaluate the train and
915.899|3.3|validation loss which currently is
917.399|3.781|terrible because we just initialized the
919.199|3.481|neural net and then we can also sample
921.18|2.94|from the model and this simplifies
922.68|2.94|dramatically as well
924.12|6.12|because we just want to call the model
925.62|7.32|onto the context and outcome logits
930.24|4.98|and these logits go into softmax and get
932.94|4.68|the probabilities Etc so we can sample
935.22|5.9|from this model
937.62|3.5|what did I screw up
942.3|3.839|okay so I fixed the issue and we now get
944.22|3.9|the result that we expect which is
946.139|3.721|gibberish because the model is not
948.12|2.519|trained because we re-initialize it from
949.86|2.82|scratch
950.639|3.841|the problem was that when I fixed this
952.68|3.959|cell to be modeled out layers instead of
954.48|4.44|just layers I did not actually run the
956.639|4.801|cell and so our neural net was in a
958.92|4.08|training mode and what caused the issue
961.44|3.839|here is the bathroom layer as bathroom
963.0|4.56|layer of the likes to do because
965.279|4.56|Bachelor was in a training mode and here
967.56|4.079|we are passing in an input which is a
969.839|3.06|batch of just a single example made up
971.639|3.361|of the context
972.899|3.721|and so if you are trying to pass in a
975.0|3.06|single example into a bash Norm that is
976.62|3.54|in the training mode you're going to end
978.06|3.839|up estimating the variance using the
980.16|4.38|input and the variance of a single
981.899|4.981|number is is not a number because it is
984.54|4.08|a measure of a spread so for example the
986.88|4.259|variance of just the single number five
988.62|4.8|you can see is not a number and so
991.139|4.38|that's what happened in the master
993.42|4.38|basically caused an issue and then that
995.519|4.32|polluted all of the further processing
997.8|5.459|so all that we have to do was make sure
999.839|5.281|that this runs and we basically made the
1003.259|3.421|issue of
1005.12|3.3|again we didn't actually see the issue
1006.68|3.12|with the loss we could have evaluated
1008.42|3.659|the loss but we got the wrong result
1009.8|4.8|because basharm was in the training mode
1012.079|4.141|and uh and so we still get a result it's
1014.6|4.62|just the wrong result because it's using
1016.22|4.44|the uh sample statistics of the batch
1019.22|3.72|whereas we want to use the running mean
1020.66|3.84|and running variants inside the bachelor
1022.94|3.259|and so
1024.5|4.86|again an example of introducing a bug
1026.199|4.72|inline because we did not properly
1029.36|3.599|maintain the state of what is training
1030.919|4.5|or not okay so I Rewritten everything
1032.959|4.081|and here's where we are as a reminder we
1035.419|3.301|have the training loss of 2.05 and
1037.04|4.019|validation 2.10
1038.72|3.839|now because these losses are very
1041.059|3.36|similar to each other we have a sense
1042.559|3.481|that we are not overfitting too much on
1044.419|3.961|this task and we can make additional
1046.04|3.72|progress in our performance by scaling
1048.38|3.96|up the size of the neural network and
1049.76|4.2|making everything bigger and deeper
1052.34|3.6|now currently we are using this
1053.96|3.66|architecture here where we are taking in
1055.94|3.42|some number of characters going into a
1057.62|3.66|single hidden layer and then going to
1059.36|3.78|the prediction of the next character
1061.28|4.92|the problem here is we don't have a
1063.14|5.64|naive way of making this bigger in a
1066.2|4.859|productive way we could of course use
1068.78|4.5|our layers sort of building blocks and
1071.059|4.441|materials to introduce additional layers
1073.28|3.6|here and make the network deeper but it
1075.5|3.0|is still the case that we are crushing
1076.88|4.02|all of the characters into a single
1078.5|4.38|layer all the way at the beginning
1080.9|3.96|and even if we make this a bigger layer
1082.88|4.5|and add neurons it's still kind of like
1084.86|4.98|silly to squash all that information so
1087.38|4.26|fast in a single step
1089.84|3.6|so we'd like to do instead is we'd like
1091.64|4.02|our Network to look a lot more like this
1093.44|3.9|in the wavenet case so you see in the
1095.66|3.0|wavenet when we are trying to make the
1097.34|3.48|prediction for the next character in the
1098.66|3.66|sequence it is a function of the
1100.82|4.32|previous characters that are feeding
1102.32|4.14|that feed in but not all of these
1105.14|3.18|different characters are not just
1106.46|5.18|crushed to a single layer and then you
1108.32|5.76|have a sandwich they are crushed slowly
1111.64|4.48|so in particular we take two characters
1114.08|4.26|and we fuse them into sort of like a
1116.12|3.96|diagram representation and we do that
1118.34|4.5|for all these characters consecutively
1120.08|6.599|and then we take the bigrams and we fuse
1122.84|6.3|those into four character level chunks
1126.679|4.321|and then we fuse that again and so we do
1129.14|4.38|that in this like tree-like hierarchical
1131.0|5.4|manner so we fuse the information from
1133.52|5.22|the previous context slowly into the
1136.4|3.54|network as it gets deeper and so this is
1138.74|2.04|the kind of architecture that we want to
1139.94|2.94|implement
1140.78|3.66|now in the wave Nets case this is a
1142.88|4.32|visualization of a stack of dilated
1144.44|4.38|causal convolution layers and this makes
1147.2|3.719|it sound very scary but actually the
1148.82|3.96|idea is very simple and the fact that
1150.919|3.481|it's a dilated causal convolution layer
1152.78|3.24|is really just an implementation detail
1154.4|3.84|to make everything fast we're going to
1156.02|4.38|see that later but for now let's just
1158.24|4.14|keep the basic idea of it which is this
1160.4|4.139|Progressive Fusion so we want to make
1162.38|3.96|the network deeper and at each level we
1164.539|4.681|want to fuse only two consecutive
1166.34|5.76|elements two characters then two bigrams
1169.22|4.86|then two four grams and so on so let's
1172.1|3.42|unplant this okay so first up let me
1174.08|3.12|scroll to where we built the data set
1175.52|4.32|and let's change the block size from 3
1177.2|4.92|to 8. so we're going to be taking eight
1179.84|4.26|characters of context to predict the
1182.12|3.72|ninth character so the data set now
1184.1|3.72|looks like this we have a lot more
1185.84|4.14|context feeding in to predict any next
1187.82|3.66|character in a sequence and these eight
1189.98|3.48|characters are going to be processed in
1191.48|4.559|this tree like structure
1193.46|4.68|now if we scroll here everything here
1196.039|3.601|should just be able to work so we should
1198.14|3.12|be able to redefine the network
1199.64|3.98|you see the number of parameters has
1201.26|4.86|increased by 10 000 and that's because
1203.62|4.6|the block size has grown so this first
1206.12|4.38|linear layer is much much bigger our
1208.22|4.98|linear layer now takes eight characters
1210.5|4.98|into this middle layer so there's a lot
1213.2|5.04|more parameters there but this should
1215.48|4.98|just run let me just break right after
1218.24|4.2|the very first iteration so you see that
1220.46|3.06|this runs just fine it's just that this
1222.44|2.64|network doesn't make too much sense
1223.52|3.42|we're crushing way too much information
1225.08|3.959|way too fast
1226.94|4.02|so let's now come in and see how we
1229.039|4.201|could try to implement the hierarchical
1230.96|4.38|scheme now before we dive into the
1233.24|4.319|detail of the re-implementation here I
1235.34|3.18|was just curious to actually run it and
1237.559|2.701|see where we are in terms of the
1238.52|4.32|Baseline performance of just lazily
1240.26|4.86|scaling up the context length so I'll
1242.84|3.959|let it run we get a nice loss curve and
1245.12|3.36|then evaluating the loss we actually see
1246.799|4.441|quite a bit of improvement just from
1248.48|3.84|increasing the context line length so I
1251.24|3.54|started a little bit of a performance
1252.32|5.52|log here and previously where we were is
1254.78|4.98|we were getting a performance of 2.10 on
1257.84|3.54|the validation loss and now simply
1259.76|5.64|scaling up the contact length from 3 to
1261.38|5.88|8 gives us a performance of 2.02 so
1265.4|3.42|quite a bit of an improvement here and
1267.26|2.94|also when you sample from the model you
1268.82|4.2|see that the names are definitely
1270.2|4.38|improving qualitatively as well
1273.02|3.06|so we could of course spend a lot of
1274.58|3.42|time here tuning
1276.08|3.18|um uh tuning things and making it even
1278.0|3.6|bigger and scaling up the network
1279.26|5.1|further even with the simple
1281.6|5.579|um sort of setup here but let's continue
1284.36|4.319|and let's Implement here model and treat
1287.179|3.541|this as just a rough Baseline
1288.679|4.261|performance but there's a lot of
1290.72|3.54|optimization like left on the table in
1292.94|2.88|terms of some of the hyper parameters
1294.26|4.14|that you're hopefully getting a sense of
1295.82|5.28|now okay so let's scroll up now
1298.4|4.38|and come back up and what I've done here
1301.1|4.439|is I've created a bit of a scratch space
1302.78|5.1|for us to just like look at the forward
1305.539|4.26|pass of the neural net and inspect the
1307.88|5.4|shape of the tensor along the way as the
1309.799|6.0|neural net uh forwards so here I'm just
1313.28|4.74|temporarily for debugging creating a
1315.799|4.321|batch of just say four examples so four
1318.02|4.2|random integers then I'm plucking out
1320.12|4.559|those rows from our training set
1322.22|4.26|and then I'm passing into the model the
1324.679|3.961|input xB
1326.48|4.8|now the shape of XB here because we have
1328.64|5.64|only four examples is four by eight and
1331.28|6.72|this eight is now the current block size
1334.28|5.58|so uh inspecting XP we just see that we
1338.0|3.299|have four examples each one of them is a
1339.86|4.86|row of xB
1341.299|5.041|and we have eight characters here and
1344.72|4.579|this integer tensor just contains the
1346.34|2.959|identities of those characters
1349.46|4.5|so the first layer of our neural net is
1351.2|4.44|the embedding layer so passing XB this
1353.96|3.719|integer tensor through the embedding
1355.64|3.419|layer creates an output that is four by
1357.679|5.041|eight by ten
1359.059|5.701|so our embedding table has for each
1362.72|3.3|character a 10-dimensional vector that
1364.76|3.299|we are trying to learn
1366.02|4.86|and so what the embedding layer does
1368.059|5.461|here is it plucks out the embedding
1370.88|5.159|Vector for each one of these integers
1373.52|4.74|and organizes it all in a four by eight
1376.039|4.26|by ten tensor now
1378.26|4.2|so all of these integers are translated
1380.299|4.441|into 10 dimensional vectors inside this
1382.46|4.079|three-dimensional tensor now
1384.74|4.679|passing that through the flattened layer
1386.539|6.181|as you recall what this does is it views
1389.419|5.701|this tensor as just a 4 by 80 tensor and
1392.72|4.14|what that effectively does is that all
1395.12|3.66|these 10 dimensional embeddings for all
1396.86|4.679|these eight characters just end up being
1398.78|4.08|stretched out into a long row
1401.539|4.081|and that looks kind of like a
1402.86|4.74|concatenation operation basically so by
1405.62|4.32|viewing the tensor differently we now
1407.6|4.98|have a four by eighty and inside this 80
1409.94|5.4|it's all the 10 dimensional uh
1412.58|3.54|vectors just uh concatenate next to each
1415.34|2.16|other
1416.12|4.5|and then the linear layer of course
1417.5|5.76|takes uh 80 and creates 200 channels
1420.62|4.799|just via matrix multiplication
1423.26|4.02|so so far so good now I'd like to show
1425.419|4.921|you something surprising
1427.28|5.22|let's look at the insides of the linear
1430.34|3.78|layer and remind ourselves how it works
1432.5|4.32|the linear layer here in the forward
1434.12|4.62|pass takes the input X multiplies it
1436.82|3.66|with a weight and then optionally adds
1438.74|3.419|bias and the weight here is
1440.48|3.84|two-dimensional as defined here and the
1442.159|4.201|bias is one dimensional here
1444.32|3.9|so effectively in terms of the shapes
1446.36|4.62|involved what's happening inside this
1448.22|4.68|linear layer looks like this right now
1450.98|4.02|and I'm using random numbers here but
1452.9|3.24|I'm just illustrating the shapes and
1455.0|3.96|what happens
1456.14|4.68|basically a 4 by 80 input comes into the
1458.96|4.199|linear layer that's multiplied by this
1460.82|4.62|80 by 200 weight Matrix inside and
1463.159|3.481|there's a plus 200 bias and the shape of
1465.44|3.54|the whole thing that comes out of the
1466.64|3.899|linear layer is four by two hundred as
1468.98|3.84|we see here
1470.539|5.821|now notice here by the way that this
1472.82|5.339|here will create a 4x200 tensor and then
1476.36|4.679|plus 200 there's a broadcasting
1478.159|6.421|happening here about 4 by 200 broadcasts
1481.039|4.981|with 200 uh so everything works here
1484.58|2.94|so now the surprising thing that I'd
1486.02|3.96|like to show you that you may not expect
1487.52|4.5|is that this input here that is being
1489.98|5.16|multiplied uh doesn't actually have to
1492.02|4.86|be two-dimensional this Matrix multiply
1495.14|3.539|operator in pytorch is quite powerful
1496.88|3.96|and in fact you can actually pass in
1498.679|3.781|higher dimensional arrays or tensors and
1500.84|3.54|everything works fine so for example
1502.46|3.78|this could be four by five by eighty and
1504.38|3.779|the result in that case will become four
1506.24|3.66|by five by two hundred
1508.159|3.361|you can add as many dimensions as you
1509.9|3.779|like on the left here
1511.52|3.72|and so effectively what's happening is
1513.679|4.081|that the matrix multiplication only
1515.24|4.5|works on the last Dimension and the
1517.76|5.299|dimensions before it in the input tensor
1519.74|3.319|are left unchanged
1524.539|4.681|so that is basically these um these
1527.72|4.74|dimensions on the left are all treated
1529.22|5.52|as just a batch Dimension so we can have
1532.46|4.199|multiple batch dimensions and then in
1534.74|3.299|parallel over all those Dimensions we
1536.659|2.701|are doing the matrix multiplication on
1538.039|3.841|the last dimension
1539.36|4.86|so this is quite convenient because we
1541.88|4.38|can use that in our Network now
1544.22|4.86|because remember that we have these
1546.26|5.58|eight characters coming in
1549.08|4.68|and we don't want to now uh flatten all
1551.84|3.12|of it out into a large eight-dimensional
1553.76|3.48|vector
1554.96|4.5|because we don't want to Matrix multiply
1557.24|4.02|80.
1559.46|4.26|into a weight Matrix multiply
1561.26|3.48|immediately instead we want to group
1563.72|3.18|these
1564.74|4.919|like this
1566.9|4.44|so every consecutive two elements
1569.659|3.181|one two and three and four and five and
1571.34|3.24|six and seven and eight all of these
1572.84|4.319|should be now
1574.58|4.74|basically flattened out and multiplied
1577.159|4.321|by weight Matrix but all of these four
1579.32|4.32|groups here we'd like to process in
1581.48|4.38|parallel so it's kind of like a batch
1583.64|5.159|Dimension that we can introduce
1585.86|7.14|and then we can in parallel basically
1588.799|6.12|process all of these uh bigram groups in
1593.0|4.2|the four batch dimensions of an
1594.919|4.62|individual example and also over the
1597.2|4.859|actual batch dimension of the you know
1599.539|4.441|four examples in our example here so
1602.059|4.801|let's see how that works effectively
1603.98|3.66|what we want is right now we take a 4 by
1606.86|3.84|80
1607.64|4.62|and multiply it by 80 by 200
1610.7|3.06|to in the linear layer this is what
1612.26|3.899|happens
1613.76|4.86|but instead what we want is we don't
1616.159|4.741|want 80 characters or 80 numbers to come
1618.62|4.02|in we only want two characters to come
1620.9|3.899|in on the very first layer and those two
1622.64|4.86|characters should be fused
1624.799|6.24|so in other words we just want 20 to
1627.5|5.94|come in right 20 numbers would come in
1631.039|4.38|and here we don't want a 4 by 80 to feed
1633.44|4.32|into the linear layer we actually want
1635.419|3.841|these groups of two to feed in so
1637.76|5.64|instead of four by eighty we want this
1639.26|7.74|to be a 4 by 4 by 20.
1643.4|5.1|so these are the four groups of two and
1647.0|2.58|each one of them is ten dimensional
1648.5|3.059|vector
1649.58|3.599|so what we want is now is we need to
1651.559|3.841|change the flattened layer so it doesn't
1653.179|4.921|output a four by eighty but it outputs a
1655.4|4.44|four by four by Twenty where basically
1658.1|5.459|these um
1659.84|6.66|every two consecutive characters are uh
1663.559|4.561|packed in on the very last Dimension and
1666.5|3.9|then these four is the first batch
1668.12|4.5|Dimension and this four is the second
1670.4|3.84|batch Dimension referring to the four
1672.62|2.7|groups inside every one of these
1674.24|3.36|examples
1675.32|4.2|and then this will just multiply like
1677.6|3.48|this so this is what we want to get to
1679.52|3.42|so we're going to have to change the
1681.08|4.68|linear layer in terms of how many inputs
1682.94|4.8|it expects it shouldn't expect 80 it
1685.76|3.72|should just expect 20 numbers and we
1687.74|3.66|have to change our flattened layer so it
1689.48|4.86|doesn't just fully flatten out this
1691.4|6.24|entire example it needs to create a 4x4
1694.34|5.04|by 20 instead of four by eighty so let's
1697.64|3.659|see how this could be implemented
1699.38|4.26|basically right now we have an input
1701.299|4.38|that is a four by eight by ten that
1703.64|3.539|feeds into the flattened layer and
1705.679|3.961|currently the flattened layer just
1707.179|4.321|stretches it out so if you remember the
1709.64|4.5|implementation of flatten
1711.5|4.32|it takes RX and it just views it as
1714.14|3.0|whatever the batch Dimension is and then
1715.82|3.719|negative one
1717.14|5.399|so effectively what it does right now is
1719.539|6.24|it does e dot view of 4 negative one and
1722.539|5.461|the shape of this of course is 4 by 80.
1725.779|4.081|so that's what currently happens and we
1728.0|3.72|instead want this to be a four by four
1729.86|4.319|by Twenty where these consecutive
1731.72|5.88|ten-dimensional vectors get concatenated
1734.179|5.88|so you know how in Python you can take a
1737.6|5.76|list of range of 10
1740.059|5.1|so we have numbers from zero to nine and
1743.36|3.12|we can index like this to get all the
1745.159|3.601|even parts
1746.48|4.62|and we can also index like starting at
1748.76|4.5|one and going in steps up two to get all
1751.1|4.38|the odd parts
1753.26|5.519|so one way to implement this it would be
1755.48|5.88|as follows we can take e and we can
1758.779|5.4|index into it for all the batch elements
1761.36|7.74|and then just even elements in this
1764.179|7.561|Dimension so at indexes 0 2 4 and 8.
1769.1|4.319|and then all the parts here from this
1771.74|5.76|last dimension
1773.419|5.76|and this gives us the even characters
1777.5|4.62|and then here
1779.179|4.021|this gives us all the odd characters and
1782.12|2.34|basically what we want to do is we make
1783.2|4.14|sure we want to make sure that these get
1784.46|5.04|concatenated in pi torch and then we
1787.34|5.819|want to concatenate these two tensors
1789.5|6.0|along the second dimension
1793.159|3.841|so this and the shape of it would be
1795.5|3.36|four by four by Twenty this is
1797.0|4.559|definitely the result we want we are
1798.86|4.799|explicitly grabbing the even parts and
1801.559|4.921|the odd parts and we're arranging those
1803.659|4.74|four by four by ten right next to each
1806.48|4.199|other and concatenate
1808.399|4.981|so this works but it turns out that what
1810.679|5.581|also works is you can simply use a view
1813.38|4.679|again and just request the right shape
1816.26|4.98|and it just so happens that in this case
1818.059|5.401|those vectors will again end up being
1821.24|4.08|arranged in exactly the way we want so
1823.46|3.66|in particular if we take e and we just
1825.32|3.359|view it as a four by four by Twenty
1827.12|3.539|which is what we want
1828.679|4.5|we can check that this is exactly equal
1830.659|5.64|to but let me call this this is the
1833.179|3.72|explicit concatenation I suppose
1836.299|4.38|um
1836.899|5.88|so explosives dot shape is 4x4 by 20. if
1840.679|5.341|you just view it as 4x4 by 20 you can
1842.779|5.52|check that when you compare to explicit
1846.02|3.899|uh you got a big this is element wise
1848.299|4.74|operation so making sure that all of
1849.919|4.86|them are true that is the truth so
1853.039|3.841|basically long story short we don't need
1854.779|6.181|to make an explicit call to concatenate
1856.88|6.539|Etc we can simply take this input tensor
1860.96|3.78|to flatten and we can just view it in
1863.419|3.661|whatever way we want
1864.74|4.62|and in particular you don't want to
1867.08|3.24|stretch things out with negative one we
1869.36|3.12|want to actually create a
1870.32|5.28|three-dimensional array and depending on
1872.48|4.199|how many vectors that are consecutive we
1875.6|4.799|want to
1876.679|5.1|um fuse like for example two then we can
1880.399|3.78|just simply ask for this Dimension to be
1881.779|4.681|20. and um
1884.179|3.661|use a negative 1 here and python will
1886.46|2.88|figure out how many groups it needs to
1887.84|2.76|pack into this additional batch
1889.34|3.3|dimension
1890.6|3.84|so let's now go into flatten and
1892.64|3.779|implement this okay so I scroll up here
1894.44|4.14|to flatten and what we'd like to do is
1896.419|3.901|we'd like to change it now so let me
1898.58|4.079|create a Constructor and take the number
1900.32|4.26|of elements that are consecutive that we
1902.659|4.14|would like to concatenate now in the
1904.58|3.74|last dimension of the output
1906.799|3.661|so here we're just going to remember
1908.32|3.94|solve.n equals n
1910.46|3.9|and then I want to be careful here
1912.26|3.84|because pipe pytorch actually has a
1914.36|3.84|torch to flatten and its keyword
1916.1|4.14|arguments are different and they kind of
1918.2|3.9|like function differently so R flatten
1920.24|4.14|is going to start to depart from patreon
1922.1|4.38|flatten so let me call it flat flatten
1924.38|4.32|consecutive or something like that just
1926.48|3.299|to make sure that our apis are about
1928.7|4.979|equal
1929.779|5.821|so this uh basically flattens only some
1933.679|3.901|n consecutive elements and puts them
1935.6|5.88|into the last dimension
1937.58|5.88|now here the shape of X is B by T by C
1941.48|4.799|so let me
1943.46|5.52|pop those out into variables and recall
1946.279|6.561|that in our example down below B was 4 T
1948.98|3.86|was 8 and C was 10.
1953.539|6.0|now instead of doing x dot view of B by
1957.08|5.54|negative one
1959.539|3.081|right this is what we had before
1964.22|5.459|we want this to be B by
1967.1|5.16|um negative 1 by
1969.679|5.941|and basically here we want c times n
1972.26|4.62|that's how many consecutive elements we
1975.62|3.059|want
1976.88|3.24|and here instead of negative one I don't
1978.679|3.6|super love the use of negative one
1980.12|3.48|because I like to be very explicit so
1982.279|2.701|that you get error messages when things
1983.6|4.079|don't go according to your expectation
1984.98|4.079|so what do we expect here we expect this
1987.679|4.681|to become t
1989.059|5.46|divide n using integer division here
1992.36|3.539|so that's what I expect to happen
1994.519|3.78|and then one more thing I want to do
1995.899|5.701|here is remember previously all the way
1998.299|4.98|in the beginning n was three and uh
2001.6|3.72|basically we're concatenating
2003.279|3.0|um all the three characters that existed
2005.32|3.12|there
2006.279|3.541|so we basically are concatenated
2008.44|3.3|everything
2009.82|4.38|and so sometimes I can create a spurious
2011.74|5.46|dimension of one here so if it is the
2014.2|5.64|case that x dot shape at one is one then
2017.2|4.5|it's kind of like a spurious dimension
2019.84|4.38|um so we don't want to return a
2021.7|4.38|three-dimensional tensor with a one here
2024.22|4.14|we just want to return a two-dimensional
2026.08|4.62|tensor exactly as we did before
2028.36|5.88|so in this case basically we will just
2030.7|6.26|say x equals x dot squeeze that is a
2034.24|6.779|pytorch function
2036.96|5.86|and squeeze takes a dimension that it
2041.019|4.38|either squeezes out all the dimensions
2042.82|5.4|of a tensor that are one or you can
2045.399|5.101|specify the exact Dimension that you
2048.22|4.5|want to be squeezed and again I like to
2050.5|3.48|be as explicit as possible always so I
2052.72|2.76|expect to squeeze out the First
2053.98|3.659|Dimension only
2055.48|4.02|of this tensor
2057.639|3.48|this three-dimensional tensor and if
2059.5|4.74|this Dimension here is one then I just
2061.119|5.581|want to return B by c times n
2064.24|4.379|and so self dot out will be X and then
2066.7|4.26|we return salt dot out
2068.619|4.441|so that's the candidate implementation
2070.96|4.02|and of course this should be self.n
2073.06|3.9|instead of just n
2074.98|4.08|so let's run
2076.96|4.439|and let's come here now
2079.06|5.059|and take it for a spin so flatten
2081.399|2.72|consecutive
2084.22|4.8|and in the beginning let's just use
2087.04|4.079|eight so this should recover the
2089.02|4.2|previous Behavior so flagging
2091.119|4.5|consecutive of eight uh which is the
2093.22|4.68|current block size
2095.619|3.781|we can do this uh that should recover
2097.9|4.74|the previous Behavior
2099.4|6.66|so we should be able to run the model
2102.64|5.4|and here we can inspect I have a little
2106.06|5.46|code snippet here where I iterate over
2108.04|6.72|all the layers I print the name of this
2111.52|6.12|class and the shape
2114.76|5.22|and so we see the shapes as we expect
2117.64|5.219|them after every single layer in the top
2119.98|5.4|bit so now let's try to restructure it
2122.859|5.461|using our flattened consecutive and do
2125.38|5.04|it hierarchically so in particular
2128.32|4.74|we want to flatten consecutive not just
2130.42|4.38|not block size but just two
2133.06|4.08|and then we want to process this with
2134.8|4.14|linear now then the number of inputs to
2137.14|3.9|this linear will not be an embed times
2138.94|3.72|block size it will now only be n embed
2141.04|3.24|times two
2142.66|3.959|20.
2144.28|4.2|this goes through the first layer and
2146.619|3.181|now we can in principle just copy paste
2148.48|3.06|this
2149.8|4.14|now the next linear layer should expect
2151.54|7.14|and hidden times two
2153.94|7.56|and the last piece of it should expect
2158.68|4.56|and it enters 2 again
2161.5|3.0|so this is sort of like the naive
2163.24|2.099|version of it
2164.5|3.24|um
2165.339|3.721|so running this we now have a much much
2167.74|3.0|bigger model
2169.06|4.38|and we should be able to basically just
2170.74|5.76|forward the model
2173.44|4.26|and now we can inspect uh the numbers in
2176.5|3.119|between
2177.7|3.72|so four byte by 20
2179.619|3.48|was Platinum consecutively into four by
2181.42|3.54|four by Twenty
2183.099|3.421|this was projected into four by four by
2184.96|4.98|two hundred
2186.52|4.98|and then bash storm just worked out of
2189.94|3.06|the box we have to verify that bastron
2191.5|2.82|does the correct thing even though it
2193.0|3.06|takes a three-dimensional impedance that
2194.32|4.2|are two dimensional input
2196.06|5.4|then we have 10h which is element wise
2198.52|4.38|then we crushed it again so if we
2201.46|3.659|flatten consecutively and ended up with
2202.9|4.26|a four by two by 400 now
2205.119|5.281|then linear brought it back down to 200
2207.16|5.1|batch room 10h and lastly we get a 4 by
2210.4|4.32|400 and we see that the flattened
2212.26|5.099|consecutive for the last flatten here uh
2214.72|4.08|it squeezed out that dimension of one so
2217.359|3.621|we only ended up with four by four
2218.8|5.279|hundred and then linear Bachelor on 10h
2220.98|5.56|and uh the last linear layer to get our
2224.079|4.621|logents and so The Lodges end up in the
2226.54|3.9|same shape as they were before but now
2228.7|4.2|we actually have a nice three layer
2230.44|5.22|neural nut and it basically corresponds
2232.9|5.82|to whoops sorry it basically corresponds
2235.66|4.439|exactly to this network now except only
2238.72|3.42|this piece here because we only have
2240.099|5.161|three layers whereas here in this
2242.14|5.939|example there's uh four layers with the
2245.26|4.26|total receptive field size of 16
2248.079|4.5|characters instead of just eight
2249.52|5.22|characters so the block size here is 16.
2252.579|4.081|so this piece of it's basically
2254.74|3.78|implemented here
2256.66|4.14|um now we just have to kind of figure
2258.52|4.26|out some good Channel numbers to use
2260.8|4.92|here now in particular I changed the
2262.78|4.98|number of hidden units to be 68 in this
2265.72|4.02|architecture because when I use 68 the
2267.76|4.26|number of parameters comes out to be 22
2269.74|4.379|000 so that's exactly the same that we
2272.02|4.14|had before and we have the same amount
2274.119|3.661|of capacity at this neural net in terms
2276.16|3.0|of the number of parameters but the
2277.78|2.64|question is whether we are utilizing
2279.16|4.439|those parameters in a more efficient
2280.42|5.159|architecture so what I did then is I got
2283.599|4.081|rid of a lot of the debugging cells here
2285.579|4.26|and I rerun the optimization and
2287.68|4.74|scrolling down to the result we see that
2289.839|6.061|we get the identical performance roughly
2292.42|6.12|so our validation loss now is 2.029 and
2295.9|4.199|previously it was 2.027 so controlling
2298.54|3.0|for the number of parameters changing
2300.099|3.301|from the flat to hierarchical is not
2301.54|3.96|giving us anything yet
2303.4|4.26|that said there are two things
2305.5|4.38|um to point out number one we didn't
2307.66|3.54|really torture the um architecture here
2309.88|3.239|very much this is just my first guess
2311.2|3.84|and there's a bunch of hyper parameters
2313.119|4.021|search that we could do in order in
2315.04|4.74|terms of how we allocate uh our budget
2317.14|5.64|of parameters to what layers number two
2319.78|4.92|we still may have a bug inside the
2322.78|2.64|bachelor 1D layer so let's take a look
2324.7|4.86|at
2325.42|5.4|um uh that because it runs but does it
2329.56|4.2|do the right thing
2330.82|4.74|so I pulled up the layer inspector sort
2333.76|3.42|of that we have here and printed out the
2335.56|3.18|shape along the way and currently it
2337.18|5.88|looks like the batch form is receiving
2338.74|5.64|an input that is 32 by 4 by 68 right and
2343.06|2.76|here on the right I have the current
2344.38|2.28|implementation of Bachelor that we have
2345.82|3.6|right now
2346.66|4.679|now this bachelor assumed in the way we
2349.42|5.76|wrote it and at the time that X is
2351.339|5.76|two-dimensional so it was n by D where n
2355.18|3.84|was the batch size so that's why we only
2357.099|4.561|reduced uh the mean and the variance
2359.02|4.5|over the zeroth dimension but now X will
2361.66|2.88|basically become three-dimensional so
2363.52|2.94|what's happening inside the bachelor
2364.54|4.2|right now and how come it's working at
2366.46|3.54|all and not giving any errors the reason
2368.74|4.08|for that is basically because everything
2370.0|4.98|broadcasts properly but the bachelor is
2372.82|2.82|not doing what we need what we wanted to
2374.98|2.7|do
2375.64|3.24|so in particular let's basically think
2377.68|3.72|through what's happening inside the
2378.88|4.8|bathroom uh looking at what's what's do
2381.4|3.959|What's Happening Here
2383.68|4.26|I have the code here
2385.359|6.901|so we're receiving an input of 32 by 4
2387.94|6.899|by 68 and then we are doing uh here x
2392.26|5.16|dot mean here I have e instead of X but
2394.839|4.801|we're doing the mean over zero and
2397.42|3.9|that's actually giving us 1 by 4 by 68.
2399.64|3.66|so we're doing the mean only over the
2401.32|3.72|very first Dimension and it's giving us
2403.3|4.5|a mean and a variance that still
2405.04|5.28|maintain this Dimension here
2407.8|4.74|so these means are only taking over 32
2410.32|4.259|numbers in the First Dimension and then
2412.54|4.44|when we perform this everything
2414.579|6.121|broadcasts correctly still
2416.98|7.34|but basically what ends up happening is
2420.7|3.62|when we also look at the running mean
2426.16|2.82|the shape of it so I'm looking at the
2427.66|2.76|model that layers at three which is the
2428.98|3.78|first bathroom layer and they're looking
2430.42|3.72|at whatever the running mean became and
2432.76|3.18|its shape
2434.14|3.9|the shape of this running mean now is 1
2435.94|4.02|by 4 by 68.
2438.04|5.16|right instead of it being
2439.96|5.34|um you know just a size of dimension
2443.2|4.68|because we have 68 channels we expect to
2445.3|4.14|have 68 means and variances that we're
2447.88|4.02|maintaining but actually we have an
2449.44|4.679|array of 4 by 68 and so basically what
2451.9|3.42|this is telling us is this bash Norm is
2454.119|3.061|only
2455.32|2.82|this bachelor is currently working in
2457.18|3.62|parallel
2458.14|2.66|over
2461.26|7.2|4 times 68 instead of just 68 channels
2466.24|4.5|so basically we are maintaining
2468.46|5.159|statistics for every one of these four
2470.74|4.5|positions individually and independently
2473.619|3.361|and instead what we want to do is we
2475.24|4.2|want to treat this four as a batch
2476.98|5.639|Dimension just like the zeroth dimension
2479.44|5.399|so as far as the bachelor is concerned
2482.619|4.261|it doesn't want to average we don't want
2484.839|4.381|to average over 32 numbers we want to
2486.88|4.38|now average over 32 times four numbers
2489.22|3.359|for every single one of these 68
2491.26|3.66|channels
2492.579|4.381|and uh so let me now
2494.92|3.6|remove this
2496.96|5.1|it turns out that when you look at the
2498.52|7.22|documentation of torch.mean
2502.06|3.68|so let's go to torch.me
2509.26|3.9|in one of its signatures when we specify
2511.66|3.179|the dimension
2513.16|3.72|we see that the dimension here is not
2514.839|5.041|just it can be in or it can also be a
2516.88|5.219|tuple of ins so we can reduce over
2519.88|4.199|multiple integers at the same time over
2522.099|3.781|multiple Dimensions at the same time so
2524.079|4.441|instead of just reducing over zero we
2525.88|4.92|can pass in a tuple 0 1.
2528.52|3.839|and here zero one as well and then
2530.8|3.0|what's going to happen is the output of
2532.359|2.641|course is going to be the same
2533.8|3.84|but now what's going to happen is
2535.0|5.16|because we reduce over 0 and 1 if we
2537.64|5.219|look at immin.shape
2540.16|5.1|we see that now we've reduced we took
2542.859|3.961|the mean over both the zeroth and the
2545.26|3.48|First Dimension
2546.82|4.08|so we're just getting 68 numbers and a
2548.74|5.339|bunch of spurious Dimensions here
2550.9|4.86|so now this becomes 1 by 1 by 68 and the
2554.079|3.841|running mean and the running variance
2555.76|3.96|analogously will become one by one by
2557.92|3.9|68. so even though there are the
2559.72|3.899|spurious Dimensions uh the current the
2561.82|3.779|current the correct thing will happen in
2563.619|5.641|that we are only maintaining means and
2565.599|5.341|variances for 64 sorry for 68 channels
2569.26|5.16|and we're not calculating the mean
2570.94|5.88|variance across 32 times 4 dimensions so
2574.42|4.14|that's exactly what we want and let's
2576.82|4.86|change the implementation of bash term
2578.56|4.38|1D that we have so that it can take in
2581.68|4.2|two-dimensional or three-dimensional
2582.94|4.08|inputs and perform accordingly so at the
2585.88|3.3|end of the day the fix is relatively
2587.02|5.46|straightforward basically the dimension
2589.18|4.98|we want to reduce over is either 0 or
2592.48|4.44|the Tuple zero and one depending on the
2594.16|4.8|dimensionality of X so if x dot and dim
2596.92|3.899|is two so it's a two dimensional tensor
2598.96|3.42|then Dimension we want to reduce over is
2600.819|3.961|just the integer zero
2602.38|4.26|L if x dot ending is three so it's a
2604.78|4.5|three-dimensional tensor then the dims
2606.64|5.219|we're going to assume are zero and one
2609.28|4.5|that we want to reduce over and then
2611.859|3.24|here we just pass in dim
2613.78|2.64|and if the dimensionality of X is
2615.099|3.601|anything else we'll now get an error
2616.42|4.74|which is good
2618.7|4.02|um so that should be the fix now I want
2621.16|3.24|to point out one more thing we're
2622.72|3.599|actually departing from the API of Pi
2624.4|4.56|torch here a little bit because when you
2626.319|4.26|come to batch room 1D and pytorch you
2628.96|4.32|can scroll down and you can see that the
2630.579|4.801|input to this layer can either be n by C
2633.28|4.38|where n is the batch size and C is the
2635.38|3.719|number of features or channels or it
2637.66|4.02|actually does accept three-dimensional
2639.099|3.601|inputs but it expects it to be n by C by
2641.68|3.06|L
2642.7|3.24|where LSA like the sequence length or
2644.74|3.0|something like that
2645.94|3.899|so um
2647.74|4.92|this is problem because you see how C is
2649.839|4.98|nested here in the middle and so when it
2652.66|4.679|gets three-dimensional inputs this bash
2654.819|5.581|term layer will reduce over zero and two
2657.339|5.161|instead of zero and one so it basically
2660.4|5.58|Pi torch batch number one D layer
2662.5|5.579|assumes that c will always be the First
2665.98|4.92|Dimension whereas we'll we assume here
2668.079|3.961|that c is the last Dimension and there
2670.9|3.3|are some number of batch Dimensions
2672.04|2.819|beforehand
2674.2|2.46|um
2674.859|4.561|and so
2676.66|6.12|it expects n by C or M by C by all we
2679.42|5.939|expect and by C or n by L by C
2682.78|3.9|and so it's a deviation
2685.359|3.661|um
2686.68|3.96|I think it's okay I prefer it this way
2689.02|3.059|honestly so this is the way that we will
2690.64|3.36|keep it for our purposes
2692.079|3.361|so I redefined the layers re-initialize
2694.0|3.78|the neural net and did a single forward
2695.44|4.5|pass with a break just for one step
2697.78|3.72|looking at the shapes along the way
2699.94|3.36|they're of course identical all the
2701.5|3.599|shapes are the same but the way we see
2703.3|3.72|that things are actually working as we
2705.099|3.48|want them to now is that when we look at
2707.02|4.14|the bathroom layer the running mean
2708.579|5.04|shape is now one by one by 68. so we're
2711.16|4.5|only maintaining 68 means for every one
2713.619|4.2|of our channels and we're treating both
2715.66|4.08|the zeroth and the First Dimension as a
2717.819|3.601|batch Dimension which is exactly what we
2719.74|3.119|want so let me retrain the neural lot
2721.42|3.72|now okay so I retrained the neural net
2722.859|3.121|with the bug fix we get a nice curve and
2725.14|2.4|when we look at the validation
2725.98|4.22|performance we do actually see a slight
2727.54|5.4|Improvement so we went from 2.029 to
2730.2|5.08|2.022 so basically the bug inside the
2732.94|4.62|bathroom was holding up us back like a
2735.28|3.78|little bit it looks like and we are
2737.56|2.519|getting a tiny Improvement now but it's
2739.06|2.519|not clear if this is statistical
2740.079|2.461|significant
2741.579|2.941|um
2742.54|3.539|and the reason we slightly expect an
2744.52|3.059|improvement is because we're not
2746.079|3.361|maintaining so many different means and
2747.579|4.801|variances that are only estimated using
2749.44|5.22|using 32 numbers effectively now we are
2752.38|4.32|estimating them using 32 times 4 numbers
2754.66|3.9|so you just have a lot more numbers that
2756.7|4.74|go into any one estimate of the mean and
2758.56|4.62|variance and it allows things to be a
2761.44|5.58|bit more stable and less Wiggly inside
2763.18|5.34|those estimates of those statistics so
2767.02|3.299|pretty nice with this more General
2768.52|3.9|architecture in place we are now set up
2770.319|4.141|to push the performance further by
2772.42|3.78|increasing the size of the network so
2774.46|4.859|for example I bumped up the number of
2776.2|4.86|embeddings to 24 instead of 10 and also
2779.319|3.721|increased number of hidden units but
2781.06|4.92|using the exact same architecture we now
2783.04|5.279|have 76 000 parameters and the training
2785.98|3.72|takes a lot longer but we do get a nice
2788.319|3.121|curve and then when you actually
2789.7|3.78|evaluate the performance we are now
2791.44|5.52|getting validation performance of 1.993
2793.48|6.3|so we've crossed over the 2.0 sort of
2796.96|5.22|territory and right about 1.99 but we
2799.78|4.38|are starting to have to wait quite a bit
2802.18|3.84|longer and we're a little bit in the
2804.16|3.179|dark with respect to the correct setting
2806.02|2.7|of the hyper parameters here and the
2807.339|2.76|learning rates and so on because the
2808.72|3.48|experiments are starting to take longer
2810.099|4.561|to train and so we are missing sort of
2812.2|4.44|like an experimental harness on which we
2814.66|3.419|could run a number of experiments and
2816.64|3.24|really tune this architecture very well
2818.079|4.02|so I'd like to conclude now with a few
2819.88|4.68|notes we basically improved our
2822.099|4.801|performance from a starting of 2.1 down
2824.56|4.019|to 1.9 but I don't want that to be the
2826.9|3.3|focus because honestly we're kind of in
2828.579|3.721|the dark we have no experimental harness
2830.2|3.659|we're just guessing and checking and
2832.3|3.18|this whole thing is terrible we're just
2833.859|3.361|looking at the training loss normally
2835.48|4.379|you want to look at both the training
2837.22|3.72|and the validation loss together and the
2839.859|3.48|whole thing looks different if you're
2840.94|4.98|actually trying to squeeze out numbers
2843.339|4.801|that said we did implement this
2845.92|5.52|architecture from the wavenet paper but
2848.14|5.16|we did not implement this specific uh
2851.44|4.379|forward pass of it where you have a more
2853.3|5.279|complicated a linear layer sort of that
2855.819|4.741|is this gated linear layer kind of and
2858.579|3.54|there's residual connections and Skip
2860.56|3.48|connections and so on so we did not
2862.119|4.381|Implement that we just implemented this
2864.04|4.319|structure I would like to briefly hint
2866.5|3.839|or preview how what we've done here
2868.359|4.441|relates to convolutional neural networks
2870.339|3.961|as used in the wavenet paper and
2872.8|3.539|basically the use of convolutions is
2874.3|3.12|strictly for efficiency it doesn't
2876.339|2.101|actually change the model we've
2877.42|3.36|implemented
2878.44|4.32|so here for example
2880.78|4.559|let me look at a specific name to work
2882.76|5.28|with an example so there's a name in our
2885.339|4.861|training set and it's DeAndre and it has
2888.04|4.799|seven letters so that is eight
2890.2|4.5|independent examples in our model so all
2892.839|3.601|these rows here are independent examples
2894.7|4.02|of the Android
2896.44|4.32|now you can forward of course any one of
2898.72|5.82|these rows independently so I can take
2900.76|5.94|my model and call call it on any
2904.54|3.84|individual index notice by the way here
2906.7|3.6|I'm being a little bit tricky
2908.38|4.8|the reason for this is that extra at
2910.3|6.12|seven that shape is just
2913.18|4.8|um one dimensional array of eight so you
2916.42|3.36|can't actually call the model on it
2917.98|3.72|you're going to get an error because
2919.78|5.28|there's no batch dimension
2921.7|6.18|so when you do extra at
2925.06|4.68|a list of seven then the shape of this
2927.88|4.14|becomes one by eight so I get an extra
2929.74|3.72|batch dimension of one and then we can
2932.02|3.18|forward the model
2933.46|4.32|so
2935.2|3.84|that forwards a single example and you
2937.78|3.9|might imagine that you actually may want
2939.04|4.2|to forward all of these eight
2941.68|4.02|um at the same time
2943.24|4.32|so pre-allocating some memory and then
2945.7|4.56|doing a for Loop eight times and
2947.56|4.259|forwarding all of those eight here will
2950.26|2.88|give us all the logits in all these
2951.819|3.0|different cases
2953.14|3.36|now for us with the model as we've
2954.819|3.54|implemented it right now this is eight
2956.5|4.26|independent calls to our model
2958.359|4.381|but what convolutions allow you to do is
2960.76|4.02|it allow you to basically slide this
2962.74|5.04|model efficiently over the input
2964.78|6.299|sequence and so this for Loop can be
2967.78|5.94|done not outside in Python but inside of
2971.079|4.621|kernels in Cuda and so this for Loop
2973.72|3.78|gets hidden into the convolution
2975.7|4.44|so the convolution basically you can
2977.5|5.579|cover this it's a for Loop applying a
2980.14|5.16|little linear filter over space of some
2983.079|3.481|input sequence and in our case the space
2985.3|2.88|we're interested in is one dimensional
2986.56|4.519|and we're interested in sliding these
2988.18|6.179|filters over the input data
2991.079|4.361|so this diagram actually is fairly good
2994.359|2.821|as well
2995.44|3.84|basically what we've done is here they
2997.18|4.26|are highlighting in Black one individ
2999.28|4.38|one single sort of like tree of this
3001.44|4.56|calculation so just calculating the
3003.66|3.48|single output example here
3006.0|2.819|um
3007.14|3.78|and so this is basically what we've
3008.819|4.681|implemented here we've implemented a
3010.92|4.56|single this black structure we've
3013.5|4.079|implemented that and calculated a single
3015.48|3.66|output like a single example
3017.579|3.24|but what collusions allow you to do is
3019.14|4.439|it allows you to take this black
3020.819|5.461|structure and kind of like slide it over
3023.579|6.0|the input sequence here and calculate
3026.28|5.46|all of these orange outputs at the same
3029.579|5.28|time or here that corresponds to
3031.74|5.46|calculating all of these outputs of
3034.859|3.72|um at all the positions of DeAndre at
3037.2|3.84|the same time
3038.579|4.621|and the reason that this is much more
3041.04|3.96|efficient is because number one as I
3043.2|5.1|mentioned the for Loop is inside the
3045.0|5.4|Cuda kernels in the sliding so that
3048.3|4.14|makes it efficient but number two notice
3050.4|3.659|the variable reuse here for example if
3052.44|4.379|we look at this circle this node here
3054.059|5.641|this node here is the right child of
3056.819|4.26|this node but is also the left child of
3059.7|3.659|the node here
3061.079|4.441|and so basically this node and its value
3063.359|5.22|is used twice
3065.52|5.64|and so right now in this naive way we'd
3068.579|4.081|have to recalculate it but here we are
3071.16|2.939|allowed to reuse it
3072.66|3.54|so in the convolutional neural network
3074.099|5.22|you think of these linear layers that we
3076.2|5.1|have up above as filters and we take
3079.319|3.78|these filters and they're linear filters
3081.3|4.019|and you slide them over input sequence
3083.099|3.841|and we calculate the first layer and
3085.319|3.3|then the second layer and then the third
3086.94|3.3|layer and then the output layer of the
3088.619|4.081|sandwich and it's all done very
3090.24|3.9|efficiently using these convolutions
3092.7|3.119|so we're going to cover that in a future
3094.14|3.66|video the second thing I hope you took
3095.819|4.561|away from this video is you've seen me
3097.8|5.039|basically Implement all of these layer
3100.38|4.8|Lego building blocks or module building
3102.839|3.961|blocks and I'm implementing them over
3105.18|3.24|here and we've implemented a number of
3106.8|4.259|layers together and we've also
3108.42|5.04|implemented these these containers and
3111.059|3.78|we've overall pytorchified our code
3113.46|3.42|quite a bit more
3114.839|4.381|now basically what we're doing here is
3116.88|5.479|we're re-implementing torch.nn which is
3119.22|5.399|the neural networks library on top of
3122.359|4.661|torch.tensor and it looks very much like
3124.619|4.321|this except it is much better because
3127.02|4.559|because it's in pi torch instead of
3128.94|4.379|jingling my Jupiter notebook so I think
3131.579|4.081|going forward I will probably have
3133.319|4.74|considered us having unlocked
3135.66|4.08|um torch.nn we understand roughly what's
3138.059|3.901|in there how these modules work how
3139.74|4.26|they're nested and what they're doing on
3141.96|4.02|top of torture tensor so hopefully we'll
3144.0|3.66|just uh we'll just switch over and
3145.98|3.42|continue and start using torch.net
3147.66|3.6|directly the next thing I hope you got a
3149.4|3.84|bit of a sense of is what the
3151.26|3.839|development process of building deep
3153.24|3.54|neural networks looks like which I think
3155.099|4.561|was relatively representative to some
3156.78|4.74|extent so number one we are spending a
3159.66|4.38|lot of time in the documentation page of
3161.52|3.98|pytorch and we're reading through all
3164.04|4.2|the layers looking at documentations
3165.5|5.819|where the shapes of the inputs what can
3168.24|4.8|they be what does the layer do and so on
3171.319|4.24|unfortunately I have to say the
3173.04|4.92|patreon's documentation is not are very
3175.559|4.02|good they spend a ton of time on
3177.96|3.72|Hardcore engineering of all kinds of
3179.579|3.78|distributed Primitives Etc but as far as
3181.68|4.74|I can tell no one is maintaining any
3183.359|5.581|documentation it will lie to you it will
3186.42|5.58|be wrong it will be incomplete it will
3188.94|5.76|be unclear so unfortunately it is what
3192.0|6.0|it is and you just kind of do your best
3194.7|6.0|um with what they've given us
3198.0|4.38|um number two
3200.7|3.899|uh the other thing that I hope you got a
3202.38|4.14|sense of is there's a ton of trying to
3204.599|3.061|make the shapes work and there's a lot
3206.52|2.7|of gymnastics around these
3207.66|2.76|multi-dimensional arrays and are they
3209.22|3.3|two-dimensional three-dimensional
3210.42|5.76|four-dimensional uh what layers take
3212.52|6.48|what shapes is it NCL or NLC and you're
3216.18|4.8|promoting and viewing and it just can
3219.0|4.559|get pretty messy and so that brings me
3220.98|3.96|to number three I very often prototype
3223.559|3.0|these layers and implementations in
3224.94|3.78|jupyter notebooks and make sure that all
3226.559|4.26|the shapes work out and I'm spending a
3228.72|3.42|lot of time basically babysitting the
3230.819|3.481|shapes and making sure everything is
3232.14|3.24|correct and then once I'm satisfied with
3234.3|3.0|the functionality in the Jupiter
3235.38|4.199|notebook I will take that code and copy
3237.3|5.1|paste it into my repository of actual
3239.579|4.98|code that I'm training with and so then
3242.4|3.659|I'm working with vs code on the side so
3244.559|3.3|I usually have jupyter notebook and vs
3246.059|3.601|code I develop in Jupiter notebook I
3247.859|3.781|paste into vs code and then I kick off
3249.66|4.919|experiments from from the reaper of
3251.64|4.56|course from the code repository so
3254.579|2.881|that's roughly some notes on the
3256.2|3.18|development process of working with
3257.46|4.08|neurons lastly I think this lecture
3259.38|4.26|unlocks a lot of potential further
3261.54|3.539|lectures because number one we have to
3263.64|3.479|convert our neural network to actually
3265.079|5.701|use these dilated causal convolutional
3267.119|5.661|layers so implementing the comnet number
3270.78|4.14|two potentially starting to get into
3272.78|3.52|what this means whatever residual
3274.92|3.0|connections and Skip connections and why
3276.3|4.5|are they useful
3277.92|4.98|number three we as I mentioned we don't
3280.8|3.24|have any experimental harness so right
3282.9|2.82|now I'm just guessing checking
3284.04|3.66|everything this is not representative of
3285.72|4.2|typical deep learning workflows you have
3287.7|3.96|to set up your evaluation harness you
3289.92|3.179|can kick off experiments you have lots
3291.66|3.179|of arguments that your script can take
3293.099|3.24|you're you're kicking off a lot of
3294.839|2.881|experimentation you're looking at a lot
3296.339|3.301|of plots of training and validation
3297.72|3.48|losses and you're looking at what is
3299.64|2.699|working and what is not working and
3301.2|3.119|you're working on this like population
3302.339|4.02|level and you're doing all these hyper
3304.319|5.28|parameter searches and so we've done
3306.359|5.581|none of that so far so how to set that
3309.599|5.281|up and how to make it good I think as a
3311.94|4.32|whole another topic number three we
3314.88|4.199|should probably cover recurring neural
3316.26|6.42|networks RNs lstm's grooves and of
3319.079|5.821|course Transformers so many uh places to
3322.68|5.159|go and we'll cover that in the future
3324.9|5.219|for now bye sorry I forgot to say that
3327.839|3.78|if you are interested I think it is kind
3330.119|4.2|of interesting to try to beat this
3331.619|4.621|number 1.993 because I really haven't
3334.319|3.601|tried a lot of experimentation here and
3336.24|4.379|there's quite a bit of fruit potentially
3337.92|4.98|to still purchase further so I haven't
3340.619|4.321|tried any other ways of allocating these
3342.9|4.439|channels in this neural net maybe the
3344.94|4.619|number of dimensions for the embedding
3347.339|3.601|is all wrong maybe it's possible to
3349.559|3.601|actually take the original network with
3350.94|3.72|just one hidden layer and make it big
3353.16|3.74|enough and actually beat my fancy
3354.66|4.8|hierarchical Network it's not obvious
3356.9|4.419|that would be kind of embarrassing if
3359.46|4.02|this did not do better even once you
3361.319|3.421|torture it a little bit maybe you can
3363.48|2.579|read the weight net paper and try to
3364.74|3.0|figure out how some of these layers work
3366.059|2.821|and Implement them yourselves using what
3367.74|2.879|we have
3368.88|3.719|and of course you can always tune some
3370.619|4.44|of the initialization or some of the
3372.599|4.26|optimization and see if you can improve
3375.059|3.8|it that way so I'd be curious if people
3376.859|6.021|can come up with some ways to beat this
3378.859|4.021|and yeah that's it for now bye