start_time|end_time|text
0.08|3.04|just so if can you please to talk about
2.24|4.48|your background
3.12|5.36|uh in in a way that is not
6.72|3.2|bashful just tell you to tell me about
8.48|2.8|the stuff you've done yeah and then sure
9.92|2.719|yeah uh so yeah i think i've been
11.28|1.84|training neural networks basically for
12.639|2.321|what
13.12|3.04|is now a decade and these neural
14.96|2.8|networks were not actually uh really
16.16|3.039|used in the industry until maybe five or
17.76|2.16|six years ago so it's been some time
19.199|1.84|that i've been training these neural
19.92|3.599|networks and that included
21.039|3.201|you know institutions at stanford at uh
23.519|2.641|at openi
24.24|3.199|at google and uh really just training a
26.16|2.959|lot of neural networks not just for
27.439|3.521|images but also for natural language
29.119|3.681|and designing architectures that couple
30.96|5.119|those two modalities for
32.8|4.4|for my phd um so in the computer
36.079|2.881|computer science class
37.2|3.039|oh yeah and uh at stanford actually
38.96|2.08|taught the convolutional neural networks
40.239|2.081|class
41.04|3.199|and so i was the primary instructor for
42.32|2.16|that class i actually started the course
44.239|1.84|and
44.48|3.36|designed the entire curriculum so in the
46.079|3.201|beginning it was about 150 students and
47.84|2.719|then it grew to 700 students over the
49.28|2.4|next two or three years so it's a very
50.559|2.16|popular class it's one of the largest
51.68|2.48|classes at stanford right now
52.719|2.801|so that was also really successful i
54.16|2.879|mean andre is like really one of the
55.52|4.879|best computer vision people in the world
57.039|6.561|arguably the best okay thank you
60.399|4.561|um yeah so uh hello everyone uh so pete
63.6|1.839|told you all about the chip that we've
64.96|2.479|designed
65.439|3.601|that runs neural networks in the car my
67.439|3.36|team is responsible for training of
69.04|3.119|these neural networks and that includes
70.799|2.801|all of data collection from the fleet
72.159|3.361|neural network training and then some of
73.6|5.44|the deployment onto that chip
75.52|5.52|um so what do the neural networks do
79.04|4.24|exactly in the car so what we are seeing
81.04|3.52|here is a stream of videos from across
83.28|2.879|the vehicle across the car
84.56|3.04|these are eight cameras that uh send us
86.159|2.481|videos and then these neural networks
87.6|2.8|are looking at those videos
88.64|3.119|and are processing them and making
90.4|2.48|predictions about what they're seeing
91.759|2.081|and so some of the things that we're
92.88|2.32|interested in some of the things you're
93.84|3.52|seeing on this visualization here
95.2|3.44|are lane line markings other objects the
97.36|2.96|distances to those objects
98.64|2.88|what we call drivable space shown in
100.32|1.759|blue which is where the car is allowed
101.52|1.599|to go
102.079|4.561|and a lot of other predictions like
103.119|3.521|traffic lights traffic signs and so on
109.119|4.401|now for my talk i will talk roughly into
112.079|2.641|in three stages so first i'm going to
113.52|2.16|give you a short primer on neural
114.72|1.679|networks and how they work and how
115.68|2.16|they're trained
116.399|3.04|and i need to do this because i need to
117.84|3.12|explain in the second part
119.439|3.04|why it is such a big deal that we have
120.96|2.0|the fleet and why it's so important and
122.479|1.841|why
122.96|2.479|it's a key enabling factor to really
124.32|2.24|training these neural networks and
125.439|2.561|making them work effectively
126.56|2.72|on the roads and in the third stage i'll
128.0|2.319|talk about the vision and lidar and how
129.28|3.76|we can estimate depth
130.319|3.841|just from vision alone so the core
133.04|1.76|problem that these networks are solving
134.16|2.56|in the car
134.8|3.12|is that of visual recognition so for uni
136.72|2.0|these are very this is a very simple
137.92|1.92|problem uh
138.72|2.239|you can look at all these four images
139.84|2.72|and you can see that they contain a
140.959|4.081|cello about an iguana
142.56|3.52|or scissors so this is very simple and
145.04|2.96|effortless for us
146.08|3.68|this is not the case for computers and
148.0|4.48|the reason for that is that these images
149.76|3.04|are to a computer really just a massive
152.48|2.56|grid
152.8|3.439|of pixels and at each pixel you have the
155.04|3.44|brightness value uh
156.239|3.921|at that point and so instead of just
158.48|3.6|seeing an image a computer really gets a
160.16|2.88|million numbers in a grid that tells you
162.08|1.439|the brightness values at all the
163.04|2.88|positions
163.519|3.281|the matrix if you will it really is the
165.92|3.12|matrix
166.8|3.76|yeah and so we have to go from that grid
169.04|3.12|of pixels and brightness values into
170.56|2.24|high-level concepts like iguana and so
172.16|2.48|on
172.8|3.519|and as you might imagine this iguana has
174.64|3.44|a certain pattern of brightness values
176.319|3.2|but iguanas actually can take on many
178.08|2.96|appearances so they can be in many
179.519|2.881|different appearances different poses
181.04|2.88|and different brightness conditions
182.4|3.28|against different backgrounds you can
183.92|3.36|have different crops of that iguana and
185.68|2.72|so we have to be robust across all those
187.28|2.64|conditions and we have to understand
188.4|3.839|that all those different brightness
189.92|3.599|patterns actually correspond to iguanas
192.239|2.881|now the reason you and i are very good
193.519|2.401|at this is because we have a massive
195.12|2.479|neural network
195.92|3.12|inside our heads that's processing those
197.599|2.801|images so
199.04|2.72|light hits the retina travels to the
200.4|1.68|back of your brain to the visual cortex
201.76|1.68|and
202.08|3.28|the visual cortex consists of many
203.44|3.28|neurons that are wired together and that
205.36|3.28|are doing all the pattern recognition on
206.72|4.4|top of those images
208.64|3.44|and really over the last i would say
211.12|3.28|about five years
212.08|4.079|um the state-of-the-art approaches to
214.4|2.24|processing images using computers have
216.159|2.961|also
216.64|4.239|um started to use neural networks but in
219.12|3.6|this case artificial neural networks
220.879|4.161|but these artificial neural networks and
222.72|3.519|this is just a cartoon diagram of it
225.04|3.119|are a very rough mathematical
226.239|3.601|approximation to your visual cortex
228.159|3.36|we really do have neurons and they are
229.84|3.039|connected together and here i'm only
231.519|2.72|showing three or four neurons in three
232.879|2.72|or four in four layers
234.239|3.121|but atypical neural network will have
235.599|3.041|tens to hundreds of millions of neurons
237.36|3.2|and each neuron will have a thousand
238.64|4.56|connections so these are really large
240.56|3.679|pieces of almost simulated tissue um and
243.2|2.08|then what we can do is we can take those
244.239|2.56|neural networks and we can show them
245.28|3.599|images so for example i can feed my
246.799|3.36|iguana into this neural network
248.879|2.801|and the network will make predictions
250.159|2.8|about what it's seen now in the
251.68|2.88|beginning these neural networks are
252.959|2.961|initialized completely randomly so the
254.56|2.959|connection strengths between all those
255.92|2.96|different neurons are completely random
257.519|2.641|and therefore the predictions of that
258.88|1.84|network are also going to be completely
260.16|2.24|random
260.72|2.8|so it might think that you're actually
262.4|2.32|looking at a boat right now and it's
263.52|2.08|very unlikely that this is actually an
264.72|2.56|iguana
265.6|2.8|and during the training during the
267.28|1.44|training process really what we're doing
268.4|1.76|is
268.72|3.039|we know that that's actually an iguana
270.16|3.599|we have a label so what we're doing is
271.759|4.16|we're basically saying we'd like the
273.759|3.44|probability of iguana to be larger for
275.919|2.641|this image and the probability of all
277.199|2.801|the other things to go down
278.56|2.56|and then there's a mathematical process
280.0|2.72|called back propagation as the cast a
281.12|2.88|gradient descent that allows us to
282.72|2.24|backpropagate that signal through those
284.0|2.16|connections
284.96|3.36|and update every one of those
286.16|3.12|connections sorry
288.32|2.96|and update every one of those
289.28|3.359|connections just a little amount and
291.28|2.88|once the update is complete the
292.639|3.041|probability of iguana for this image
294.16|2.319|will go up a little bit so it might
295.68|1.76|become 14
296.479|2.641|and the probability of the other things
297.44|3.039|will go down and of course we don't just
299.12|3.12|do this for this single image we
300.479|3.361|actually have entire large data sets
302.24|3.04|that are labeled so we have lots of
303.84|2.24|images typically you might have millions
305.28|2.0|of images
306.08|2.64|thousands of labels or something like
307.28|2.56|that and you are doing forward backward
308.72|2.64|passes over and over again so you're
309.84|2.799|showing the computer here's an image it
311.36|2.32|has an opinion and then you're saying
312.639|2.801|this is the correct answer
313.68|3.28|and it tunes itself a little bit you
315.44|3.039|repeat this millions of times
316.96|3.12|and sometimes you show images the same
318.479|2.641|image to the computer you know hundreds
320.08|2.8|of times as well
321.12|3.04|so the network training typically will
322.88|2.879|take on the order a few hours
324.16|3.759|or a few days depending on how big of a
325.759|3.44|network you're training and
327.919|2.641|that's the process of training a neural
329.199|2.401|network now there's something very
330.56|2.4|unintuitive about the way neural
331.6|1.84|networks work that i have to really get
332.96|2.88|into
333.44|3.68|and that is that they really do require
335.84|2.16|a lot of these examples and they really
337.12|2.079|do start from scratch
338.0|3.12|they know nothing and it's really hard
339.199|3.761|to wrap your head around around this
341.12|3.04|so as an example here's a cute dog and
342.96|2.0|you probably may not know the breed of
344.16|1.84|this dog but
344.96|2.799|the correct answer is that this is a
346.0|2.96|japanese spaniel now all of us are
347.759|2.561|looking at this and we're seeing
348.96|2.959|japanese spanish we're like okay i got
350.32|2.719|it i understand kind of what this
351.919|3.441|japanese spaniel looks like
353.039|3.681|and if i show you a few more images of
355.36|2.959|other dogs you can probably pick out
356.72|2.72|other japanese spaniels here so in
358.319|3.121|particular those three look like a
359.44|3.52|japanese panel and the other ones do not
361.44|3.199|so you can do this very quickly and you
362.96|3.04|need one example but computers do not
364.639|3.601|work like this they actually need
366.0|3.84|a ton of data of japanese panels so this
368.24|2.88|is a grid of japanese panels
369.84|3.04|showing them you need thousands of
371.12|2.799|examples showing them in different poses
372.88|2.0|different brightness conditions
373.919|2.641|different backgrounds
374.88|2.879|different crops you really need to teach
376.56|2.56|the computer from all the different
377.759|2.641|angles what this japanese spanish looks
379.12|2.56|like and it really requires all that
380.4|2.32|data to get that to work otherwise the
381.68|3.28|computer can't pick up
382.72|3.759|on that pattern automatically so what
384.96|2.64|does all this imply about the setting of
386.479|2.401|self-driving of course we don't care
387.6|2.8|about dog breeds too much
388.88|3.28|maybe we will at some point but for now
390.4|3.28|we really care about land line markings
392.16|3.759|objects where they are where we can
393.68|3.6|drive and so on so the way we do this is
395.919|2.961|we don't have labels like iguana for
397.28|2.8|images but we do have images from the
398.88|2.64|fleet like this and we're interested in
400.08|3.76|for example layla markings
401.52|3.119|so we a human typically goes into an
403.84|2.56|image and
404.639|3.041|using a mouse annotates the lane line
406.4|2.799|markings so here's an example of an
407.68|2.72|annotation that a human could create a
409.199|2.72|label for this image
410.4|2.56|and it's saying that that's what you
411.919|2.081|should be seeing in this image these are
412.96|2.16|the line markings
414.0|2.72|and then what we can do is we can go to
415.12|2.4|the fleet and we can ask for more images
416.72|2.479|from the fleet
417.52|3.119|and uh if you ask the fleet if you just
419.199|2.801|do a nave job of this and you just ask
420.639|3.521|for images at random the fleet
422.0|4.0|might respond with images like this uh
424.16|4.319|typically going forward on some highway
426.0|3.44|this is what um you might just get like
428.479|2.72|a random collection like this
429.44|2.8|and we would annotate all that data now
431.199|2.4|if you're not careful and you only
432.24|2.079|annotate a random distribution of this
433.599|1.921|data
434.319|2.801|your network will kind of pick up on
435.52|2.959|this this random distribution on data
437.12|2.639|and work only in that regime
438.479|4.881|so if you show a slightly different
439.759|5.921|example for example here is an image
443.36|3.679|that actually the road is curving and
445.68|2.239|it's a bit of a more residential
447.039|2.801|neighborhood
447.919|3.201|then if you show the neural network this
449.84|2.72|image that network might make a
451.12|2.88|prediction that is incorrect it might
452.56|2.56|say that okay well i've seen lots of
454.0|2.639|times on highways
455.12|3.12|lanes just go forward so here's a
456.639|2.56|possible prediction and of course this
458.24|2.799|is very incorrect
459.199|3.201|but the neural network really can't be
461.039|2.0|blamed it does not know that the train
462.4|2.16|on the
463.039|2.88|the tree on the left whether or not it
464.56|2.88|matters or not it does not know if the
465.919|3.361|car on the right matters or not towards
467.44|3.52|the lane line it does not know that the
469.28|3.12|uh that the um buildings in the
470.96|2.72|background matter or not it really
472.4|2.639|starts completely from scratch
473.68|2.88|and you and i know that the truth is
475.039|2.88|that none of those things matter what
476.56|2.72|actually matters is there are a few
477.919|2.481|white lane line markings over there in
479.28|2.72|the in a vanishing point
480.4|3.359|and the fact that they curl a little bit
482.0|3.68|should pull the prediction
483.759|3.041|except there's no mechanism by which we
485.68|2.639|can just tell the neural network hey
486.8|2.079|those line markings actually matter the
488.319|2.0|only
488.879|3.121|tool in the toolbox that we have is
490.319|3.041|labeled data so what we do is we need to
492.0|1.84|take images like this when the network
493.36|2.32|fails
493.84|3.28|and we need to label them correctly so
495.68|3.199|in this case we will turn
497.12|3.199|the lane to the right and then we need
498.879|2.16|to feed lots of images of this to the
500.319|2.72|neural net
501.039|3.6|and neural net over time will accumulate
503.039|3.041|will basically pick up on this pattern
504.639|2.96|that those things there don't matter
506.08|2.959|what those lane line markings do and we
507.599|3.761|learn to predict the correct
509.039|3.601|lane so what's really critical is not
511.36|2.64|just the scale of the data set we don't
512.64|2.72|just want millions of images we actually
514.0|2.64|need to do a really good job of covering
515.36|2.72|the possible space
516.64|3.199|of things that the car might encounter
518.08|3.12|on the roads so we need to teach the
519.839|3.2|computer how to handle
521.2|2.8|scenarios where it's night and wet you
523.039|2.401|have all these different specular
524.0|2.72|reflections and as you might imagine
525.44|2.8|the brightness patterns and these images
526.72|2.559|will look very different we have to
528.24|1.68|teach a computer how to deal with
529.279|3.041|shadows
529.92|3.84|how to deal with forks in the road how
532.32|2.639|to deal with large objects that might be
533.76|2.72|taking up most of that image
534.959|3.121|how to deal with tunnels or how to deal
536.48|2.08|with construction sites and in all these
538.08|2.08|cases
538.56|3.2|there's no again explicit mechanism to
540.16|2.799|tell the network what to do we only have
541.76|2.32|massive amounts of data we want to
542.959|2.721|source all those images
544.08|2.96|and we want to annotate the correct
545.68|3.44|lines and the network will pick up on
547.04|4.239|the patterns of those
549.12|3.36|now large and very data sets make
551.279|1.521|basically make these networks work very
552.48|1.76|well
552.8|3.28|this is not just defining for us here at
554.24|3.12|tesla this is a ubiquitous finding
556.08|4.48|across the entire industry
557.36|4.0|so experiments and research from google
560.56|3.92|from facebook
561.36|5.2|from baidu from um alphabets deepmind
564.48|3.12|all show similar plots where neural
566.56|3.36|networks really love
567.6|3.12|data and loft scale and variety as you
569.92|2.0|add more data
570.72|2.96|these neural networks start to work
571.92|2.4|better and get higher accuracies for
573.68|3.599|free
574.32|3.92|so more data just makes them work better
577.279|2.401|now
578.24|2.4|a number of companies have a number of
579.68|2.24|people have kind of pointed out that
580.64|2.08|potentially we could use simulation to
581.92|2.24|actually achieve
582.72|2.48|the scale of the data sets and we're in
584.16|2.32|charge of a lot of the conditions here
585.2|2.079|maybe we can achieve some variety in the
586.48|2.799|simulator
587.279|3.361|now at tesla and that was also kind of
589.279|3.441|brought up in the question uh
590.64|3.36|questions uh just just before this now a
592.72|3.44|tesla this is actually
594.0|3.2|uh a screenshot of our own simulator we
596.16|2.56|use simulation
597.2|3.28|uh extensively we use it to develop and
598.72|2.48|evaluate the software we also even use
600.48|3.52|it for training
601.2|3.84|quite successfully so but really when it
604.0|2.399|comes to training data for neural
605.04|2.4|networks there really is no substitute
606.399|3.68|for real data
607.44|3.12|the simulator simulations have a lot of
610.079|3.041|trouble
610.56|4.56|with modeling appearance physics and the
613.12|4.0|behaviors of all the agents around you
615.12|3.04|so there are some examples to really
617.12|2.399|drive that point across
618.16|3.2|the real world really throws a lot of
619.519|2.88|crazy stuff at you uh so in this case
621.36|2.8|for example we have very complicated
622.399|2.481|environments with snow with trees with
624.16|2.72|wind
624.88|3.36|we have various visual artifacts that
626.88|3.36|are hard to simulate potentially
628.24|3.2|we have complicated construction sites
630.24|3.2|bushes and
631.44|3.12|uh plastic bags that can go in that can
633.44|3.12|uh kind of
634.56|3.12|go around with the wind a complicated
636.56|2.0|construction size that might feature
637.68|3.2|lots of people
638.56|3.68|kids animals all mixed in and simulating
640.88|2.48|how those things interact and flow
642.24|1.92|through this construction zone might
643.36|2.32|actually be completely
644.16|3.04|completely intractable it's not about
645.68|2.8|the movement of any one pedestrian in
647.2|2.879|there it's about how they respond to
648.48|2.799|each other and how those cars
650.079|3.44|respond to each other and how they
651.279|4.321|respond to you driving in that setting
653.519|3.201|uh and all of those are actually really
655.6|2.08|tricky to simulate
656.72|2.799|it's almost like you have to solve the
657.68|2.399|self-driving problem to just simulate
659.519|2.481|other cars
660.079|3.2|in your simulation so it's really
662.0|3.76|complicated so we have
663.279|3.201|dogs exotic animals and in some cases
665.76|1.92|it's not even
666.48|2.88|that you can't simulate it is that you
667.68|2.32|can't even come up with it so for
669.36|1.84|example
670.0|3.2|i didn't know that you can have truck on
671.2|2.8|truck on truck like that but in the real
673.2|2.639|world you find this
674.0|3.44|and you find lots of other things that
675.839|2.161|are very hard to really even come up
677.44|2.16|with
678.0|3.92|so really the variety that i'm seeing in
679.6|3.6|the data coming from the fleet is just
681.92|2.24|crazy with respect to what we have in
683.2|1.759|simulator we have a really good
684.16|2.88|simulator
684.959|3.681|yeah it's i mean simulation you're
687.04|2.799|fundamentally grading you're creating
688.64|3.28|your own homework
689.839|3.761|so you you know you if you know that
691.92|3.52|you're going to simulate it
693.6|3.679|okay you can definitely solve for it but
695.44|4.639|as andre is saying you don't know what
697.279|4.481|you don't know the world is very weird
700.079|4.88|and has
701.76|5.199|millions of corner cases uh and if
704.959|3.761|if somebody can produce a self-driving
706.959|2.801|simulation that accurately matches
708.72|3.44|reality
709.76|3.04|that in itself would be in a monumental
712.16|3.359|achievement
712.8|3.2|of of human capability they can't
715.519|5.201|there's no
716.0|6.0|way yeah yeah uh so
720.72|3.2|i think the three points that i really
722.0|3.279|try to drive home until now are
723.92|2.719|to get neural networks to work well you
725.279|2.56|require these three essentials you
726.639|4.241|require a large data set
727.839|4.56|a varied data set and a real data set
730.88|2.48|and if you have those capabilities you
732.399|2.081|can actually train your networks and
733.36|3.12|make them work very well
734.48|3.359|and so why is tesla is such a unique and
736.48|2.799|interesting position to really get all
737.839|2.721|these three essentials right
739.279|4.0|and the answer to that of course is the
740.56|4.079|fleet we can really source data from it
743.279|2.481|and make our neural network systems work
744.639|2.32|extremely well
745.76|3.28|so let me take you through a concrete
746.959|3.521|example of for example um
749.04|2.479|making the object detector work better
750.48|2.32|to give you a sense of how we develop
751.519|2.32|these networks how we iterate on them
752.8|1.76|and how we actually get them to work
753.839|2.0|over time
754.56|2.56|so object detection is something we care
755.839|2.161|a lot about we'd like to put bounding
757.12|2.56|boxes around
758.0|2.639|say the cars and the the objects here
759.68|1.92|because we need to track them and we
760.639|1.76|need to understand how they might move
761.6|2.96|around
762.399|3.68|so again we might ask human annotators
764.56|3.04|to give us some annotations for these
766.079|3.041|and humans might go in and might tell
767.6|3.679|you that okay those patterns over there
769.12|3.44|are cars and bicycles and so on and you
771.279|2.641|can train your neural network on this
772.56|2.8|but if you're not careful the neural
773.92|2.8|network will make mis-predictions in
775.36|2.8|some cases so as an example if we
776.72|2.64|stumble by a car like this that has a
778.16|2.88|bike on the back of it
779.36|3.76|then the neural network actually when i
781.04|2.799|joined would actually create two
783.12|2.399|detections
783.839|3.201|it would create a car detection and a
785.519|3.041|bicycle detection and that's actually
787.04|2.239|kind of correct because i guess both of
788.56|2.16|those objects
789.279|2.56|actually exist but for the purposes of
790.72|2.799|the controller and the planner
791.839|3.12|downstream you really don't want to
793.519|3.521|deal with the fact that this bicycle can
794.959|3.68|go with the car the truth is that that
797.04|3.039|bike is attached to that car so in terms
798.639|2.32|of like just objects on the road there's
800.079|2.721|a single object
800.959|3.361|a single car and so what you'd like to
802.8|2.24|do now is you'd like to just potentially
804.32|2.24|annotate
805.04|3.919|lots of those images as this is just a
806.56|4.32|single car so the process that we that
808.959|3.601|we go through internally in the team
810.88|3.12|is that we take this image or a few
812.56|2.8|images that show this pattern
814.0|2.639|and we have a mechanism a machine
815.36|2.0|learning mechanism by which we can ask
816.639|2.64|the fleet
817.36|4.159|to source us examples that look like
819.279|3.841|that and the fleet might respond with
821.519|2.88|images that contains those patterns so
823.12|2.88|as an example these six images might
824.399|4.56|come from the fleet they all contain
826.0|4.56|bikes on backs of cars and uh we would
828.959|2.801|go in and we would annotate all those as
830.56|2.56|just a single car
831.76|3.04|and then the the performance of that
833.12|3.44|detector actually improves and the
834.8|3.039|network internally understands that hey
836.56|2.639|when the bike is just attached to the
837.839|2.641|car that's actually just a single car
839.199|2.64|and it can learn that given enough
840.48|2.799|examples and that's how we've sort of
841.839|2.8|fixed that problem
843.279|2.8|i will mention that i talk quite a bit
844.639|2.401|about sourcing data from the fleet i
846.079|1.76|just want to make a quick point that
847.04|2.239|we've designed this
847.839|2.721|from the beginning with privacy in mind
849.279|1.761|and all the data that we use for
850.56|2.8|training
851.04|4.08|is anonymized now the fleet doesn't just
853.36|3.279|respond with bicycles and backs of cars
855.12|2.64|we look for all the things we look for
856.639|2.88|lots of things all the time
857.76|3.36|so for example we look for boats and the
859.519|2.56|fleet can respond with boats we look for
861.12|2.0|construction sites
862.079|2.721|and the fleet can send us lots of
863.12|3.36|construction sites from across the world
864.8|2.8|we look for even slightly more rare
866.48|2.719|cases so for example
867.6|3.44|finding debris on the road is pretty
869.199|3.281|important to us so these are examples of
871.04|2.4|images that have streams to us from the
872.48|3.76|fleet that show
873.44|3.199|tires cones plastic bags and things like
876.24|1.76|that
876.639|2.64|if we can source these at scale we can
878.0|2.56|annotate them correctly and the neural
879.279|2.401|network will learn how to deal with them
880.56|3.04|in the world
881.68|4.0|here's another example animals of course
883.6|3.12|also a very rare occurrence an event but
885.68|2.08|we want the neural network to really
886.72|2.08|understand what's going on here that
887.76|2.56|these are animals and we want to deal
888.8|4.479|with that correctly
890.32|4.4|so to summarize the process by which we
893.279|2.481|iterate on neural network predictions
894.72|2.479|looks something like this
895.76|3.04|we start with a c data set that was
897.199|2.801|potentially sourced at random we
898.8|2.24|annotate that data set
900.0|3.279|and then we train neural networks on
901.04|4.0|that data set and put that in the car
903.279|3.521|and then we have mechanisms by which we
905.04|3.68|notice inaccuracies in the car
906.8|3.839|when this detector may be misbehaving so
908.72|3.52|for example if we detect that the neural
910.639|2.32|network might be uncertain or if we
912.24|3.599|detect
912.959|4.0|that or if there's a driver intervention
915.839|2.56|or any of those settings we can create
916.959|2.88|this trigger infrastructure that sends
918.399|3.12|us data of those inaccuracies
919.839|2.881|and so for example if we don't perform
921.519|2.801|very well on lane line detection on
922.72|2.72|tunnels then we can notice that there's
924.32|3.04|a problem in tunnels
925.44|3.519|that image would enter our unit test so
927.36|2.64|we can verify that we're actually fixing
928.959|2.961|the problem over time
930.0|3.6|but now what you do is to fix this uh
931.92|3.039|inaccuracy you need to source many more
933.6|2.64|examples that look like that
934.959|2.961|so we asked the fleet to please send us
936.24|2.719|many more tunnels and then we label all
937.92|2.24|those tunnels correctly
938.959|3.601|we incorporate that into the training
940.16|4.0|set and we retrain the network redeploy
942.56|3.92|and iterate the cycle over and over
944.16|3.919|again and so we refer to this
946.48|3.76|iterative process by which we improve
948.079|4.161|these predictions as the data engine
950.24|3.68|so iteratively deploying something
952.24|3.36|potentially in shadow mode uh
953.92|3.12|sourcing inaccuracies and incorporating
955.6|2.4|the training set over and over again
957.04|3.12|we do this basically for all the
958.0|4.639|predictions of these neural networks
960.16|3.84|now so far i've talked about a lot of
962.639|3.76|explicit labeling
964.0|3.519|so like i mentioned we ask people to
966.399|3.281|annotate data
967.519|3.601|this is an expensive process in time and
969.68|3.04|also
971.12|3.12|with respect to yeah it's just an
972.72|4.0|expensive process and so
974.24|3.68|these annotations of course can be very
976.72|2.96|expensive to achieve
977.92|3.279|so what i want to talk about also is
979.68|2.399|really to utilize the power of the fleet
981.199|1.841|you don't want to go through the human
982.079|2.32|annotation model like
983.04|2.799|you want to just stream in data and
984.399|2.88|automate it automatically and we have
985.839|2.081|multiple mechanisms by which we can do
987.279|2.721|this
987.92|3.2|so as one example of a project that we
990.0|3.44|recently
991.12|3.68|um worked on is the detection of
993.44|1.92|currents so you're driving down the
994.8|2.0|highway
995.36|3.279|someone is on the left or on the right
996.8|4.08|and they cut in front of you into your
998.639|3.681|lane so here's a video showing the
1000.88|4.56|autopilot detecting that this
1002.32|4.56|car is intruding into our lane now
1005.44|3.04|of course we'd like to detect a current
1006.88|3.04|as fast as possible so
1008.48|3.599|the way we approach this problem is we
1009.92|3.44|don't write explicit code for
1012.079|3.281|is the left blinker on is the right
1013.36|3.599|blinker on track the keyboard over time
1015.36|3.039|and see if it's moving horizontally
1016.959|3.68|we actually use a fleet learning
1018.399|4.56|approach so the way this works is
1020.639|3.521|we ask the fleet to please send us data
1022.959|2.641|whenever they see a car
1024.16|3.36|transition from a right lane to the
1025.6|3.839|center lane or from left to center
1027.52|3.6|and then what we do is we rewind time
1029.439|2.961|backwards and we automatically can
1031.12|3.6|annotate that hey that car
1032.4|3.679|will turn will in 1.3 seconds cut in
1034.72|2.88|front of the in front of you and then we
1036.079|2.72|can use that for training the neural net
1037.6|2.8|and so the neural net will automatically
1038.799|2.88|pick up on a lot of these patterns so
1040.4|2.96|for example the cars are typically
1041.679|3.12|odd they're moving this way maybe the
1043.36|2.88|blinker is on all that stuff happens
1044.799|3.681|internally inside the neural net
1046.24|3.28|just from these examples so we asked the
1048.48|2.8|fleet to automatically send out all
1049.52|2.8|these data we can get half a million or
1051.28|2.72|so images
1052.32|3.84|and all of these would be annotated for
1054.0|4.48|cuttings and then we train the network
1056.16|3.6|um and then we took this cutting network
1058.48|2.88|and we deployed it to the fleet but we
1059.76|2.24|don't turn it on yet we run it in shadow
1061.36|2.0|mode
1062.0|2.72|and in shadow mode the network is always
1063.36|2.72|making predictions hey i think this this
1064.72|1.839|vehicle is going to cut in from the way
1066.08|2.0|it looks
1066.559|3.36|this vehicle is going to cut in and then
1068.08|2.8|we look for mispredictions so as an
1069.919|3.041|example
1070.88|3.52|this is a clip that we had from shadow
1072.96|2.88|mode of the cutting network
1074.4|2.48|and it's kind of hard to see but the
1075.84|2.48|network thought that the vehicle right
1076.88|2.0|ahead of us and on the right is going to
1078.32|1.76|cut in
1078.88|2.48|and you can sort of see that it's it's
1080.08|2.719|slightly flirting with the lane line
1081.36|2.72|it's trying to it's sort of encroaching
1082.799|2.24|a little bit and the network got excited
1084.08|2.32|and it thought that that was going to be
1085.039|2.721|cut in that vehicle will actually end up
1086.4|2.48|in our center lane that turns out to be
1087.76|2.0|incorrect and the vehicle did not
1088.88|2.72|actually do that
1089.76|3.76|so what we do now is we just churned the
1091.6|3.439|data engine we source
1093.52|2.72|that ran in the shadow mode it's making
1095.039|2.161|predictions it makes some false
1096.24|1.84|positives and there are some false
1097.2|2.64|negative detections
1098.08|3.12|so we got over excited and sometimes and
1099.84|2.32|sometimes we missed a cut in when it
1101.2|2.88|actually happened
1102.16|3.12|all those create a trigger that streams
1104.08|2.88|to us and that
1105.28|3.12|gets incorporated now for free there's
1106.96|2.4|no humans harmed in the process of
1108.4|2.24|labeling this data
1109.36|2.72|incorporate it for free into our
1110.64|2.64|training set we retrain the network and
1112.08|3.28|we deploy the shadow mode
1113.28|3.279|and so we can spin this a few times and
1115.36|2.4|we always look at the false positives
1116.559|2.401|and negatives coming from the fleet
1117.76|2.64|and once we're happy with the false
1118.96|2.4|positive false negative ratio we
1120.4|3.92|actually flip a bit
1121.36|3.76|and actually uh let the car control to
1124.32|2.08|that network
1125.12|2.32|and so you may have noticed we actually
1126.4|2.24|shipped one of our first versions of a
1127.44|2.72|cutting extractor
1128.64|2.88|um approximately i think three months
1130.16|2.56|ago so if you've noticed that the car is
1131.52|4.32|much better detecting cottons
1132.72|3.52|that's fleet learning operating at scale
1135.84|3.04|yes
1136.24|3.92|it actually works quite nicely so that's
1138.88|2.48|quite learning no humans were harmed in
1140.16|2.48|the process it's just a lot of neural
1141.36|2.08|network training based on data and a lot
1142.64|3.36|of shadow mode
1143.44|4.239|and looking at those results another
1146.0|4.0|essentially like
1147.679|3.761|um everyone's training the network all
1150.0|2.08|the time is what it amounts to whether
1151.44|2.72|that whether
1152.08|3.44|to water polish on or off uh the network
1154.16|4.24|is being trained
1155.52|4.32|every mile that's driven uh for the car
1158.4|4.32|that's harder to or above
1159.84|3.52|is training the network yeah another
1162.72|2.16|interesting
1163.36|2.64|way that we use this in the scheme of
1164.88|2.159|fleet learning and the other project
1166.0|3.679|that i will talk about is
1167.039|3.361|a path prediction so while you are
1169.679|2.081|driving the car
1170.4|2.48|what you're actually doing is you are
1171.76|2.0|annotating the data because you are
1172.88|2.08|steering the wheel
1173.76|2.72|you're telling us how to traverse
1174.96|2.48|different environments so what we're
1176.48|2.96|looking at here
1177.44|3.68|is a some person in the fleet who took a
1179.44|3.28|left through an intersection
1181.12|3.28|and what we do here is we we have the
1182.72|2.319|full video of all the cameras and we
1184.4|2.08|know that
1185.039|3.041|the path that this person took because
1186.48|3.6|of the gps the initial measurement unit
1188.08|3.28|the wheel angle the wheel ticks so we
1190.08|2.56|put all that together and we understand
1191.36|2.319|the path that this person took through
1192.64|2.64|this environment
1193.679|3.201|and then of course this uh this we can
1195.28|3.04|use this for uh supervision for the
1196.88|2.32|network so we just source a lot of this
1198.32|2.8|from the fleet
1199.2|3.12|we train a neural network on the on
1201.12|2.559|those trajectories
1202.32|3.28|and then the neural network predicts
1203.679|2.88|paths uh just from that data
1205.6|2.559|so really what this is referred to
1206.559|2.881|typically is called imitation learning
1208.159|2.4|we're taking human trajectories from the
1209.44|2.56|real world i'm just trying to imitate
1210.559|2.801|how people drive in real worlds
1212.0|2.799|and we can also apply the same data
1213.36|2.0|engine crank to all of this and make
1214.799|3.76|this work
1215.36|5.36|over time um so here's an example of
1218.559|4.321|path prediction
1220.72|3.36|going through a kind of a complicated
1222.88|2.08|environment so what you're seeing here
1224.08|3.04|is a video
1224.96|3.599|and we are overlaying the predictions of
1227.12|2.64|the network so this is a path that the
1228.559|4.801|network would follow
1229.76|5.12|um in green and
1233.36|3.12|yeah i mean the crazy thing is the
1234.88|2.88|network is predicting paths it can't
1236.48|3.92|even see
1237.76|4.08|with incredibly high accuracy they can't
1240.4|3.12|see around the corner but
1241.84|3.199|but it's saying the probability of that
1243.52|5.44|curve is extremely high
1245.039|6.0|so that's the path and it nails it
1248.96|3.68|you will see that in the cars today uh
1251.039|3.681|we're going to turn on augmented vision
1252.64|3.279|so you can see the the the the lane
1254.72|2.0|lines and the path predictions of the
1255.919|3.281|cars
1256.72|3.68|uh over later on the video yeah there's
1259.2|1.76|actually more going on under hood that
1260.4|3.6|you can even tell
1260.96|4.0|it's kind of scary to be honest yeah and
1264.0|1.84|of course there's a lot of details i'm
1264.96|2.32|skipping over you might not want to
1265.84|2.56|annotate all the drivers you might
1267.28|2.399|annotate just you might want to just
1268.4|2.48|imitate the better drivers and there's
1269.679|2.401|many technical ways that we actually
1270.88|3.279|slice nice that data
1272.08|3.52|um but the interesting thing here is
1274.159|2.0|that this prediction is actually a 3d
1275.6|2.4|prediction
1276.159|3.281|that we project back to the image here
1278.0|2.799|so the path here forward is a
1279.44|2.32|three-dimensional thing that we're just
1280.799|2.24|rendering in 2d
1281.76|2.56|but we know about the slope of the
1283.039|2.961|ground from all this and that's actually
1284.32|3.44|extremely valuable for driving
1286.0|2.88|uh so that prediction actually is live
1287.76|2.56|in the fleet today by the way so if
1288.88|2.48|you're driving clover leafs if you're in
1290.32|2.56|a cloverleaf on the highway
1291.36|2.799|until maybe five months ago or so your
1292.88|2.0|car would not be able to do cloverleaf
1294.159|2.561|now it can
1294.88|3.919|that's pat prediction running live on
1296.72|3.199|your cars we've shipped this a while ago
1298.799|2.161|and today you are going to get to
1299.919|2.801|experience this for traversing
1300.96|3.12|intersections a large component of how
1302.72|2.16|we go through intersections in your
1304.08|2.32|drives today
1304.88|4.24|is all sourced from path prediction from
1306.4|2.72|automatic labels
1309.76|3.76|so i talked about so far is really the
1311.919|2.561|three key components of how we iterate
1313.52|2.399|on the predictions of the network and
1314.48|3.36|how we make it work over time
1315.919|3.601|you require large varied and real data
1317.84|2.64|set we can really achieve that here at
1319.52|2.639|tesla
1320.48|3.199|and uh we do that through the scale of
1322.159|3.041|the fleet the data engine
1323.679|3.201|shipping things in shadow mode iterating
1325.2|3.2|that cycle and potentially even using
1326.88|2.56|fleet learning where no human annotators
1328.4|2.639|are harmed in the process
1329.44|4.4|and just using data automatically and we
1331.039|2.801|can really do that at scale
1334.72|2.8|so in the next section of my talk i'm
1336.0|3.28|going to especially talk about depth
1337.52|3.6|perception using vision only
1339.28|3.279|so you might be familiar that there are
1341.12|3.2|at least two sensors
1342.559|3.36|in a car one is vision cameras just
1344.32|2.32|getting pixels and the other is lidar
1345.919|3.12|that a lot of
1346.64|3.76|uh a lot of companies also use and lidar
1349.039|2.0|gives you these point measurements of
1350.4|3.84|distance
1351.039|4.88|around you um now one one thing i'd like
1354.24|3.36|to point out first of all is
1355.919|4.161|you all came here you drove here many of
1357.6|4.64|you and you used your
1360.08|3.839|your neural net and vision you were not
1362.24|2.48|shooting lasers out of your eyes and you
1363.919|4.081|still ended up here
1364.72|5.36|we might have it so
1368.0|3.44|clearly the human neural net derives
1370.08|2.8|distance and all the measurements in the
1371.44|2.0|3d understanding of the world just from
1372.88|2.0|vision
1373.44|2.8|it actually uses multiple cues to do so
1374.88|2.4|i'll just briefly go over some of them
1376.24|2.0|just to give you a sense of roughly
1377.28|3.2|what's going on in
1378.24|3.52|inside um as an example we have two eyes
1380.48|2.64|pointed out so you get two independent
1381.76|2.48|measurements at every single time step
1383.12|2.799|of the world ahead of you
1384.24|2.799|and your brain stitches this information
1385.919|2.401|together to arrive at some depth
1387.039|2.481|estimation because you can triangulate
1388.32|3.28|any points
1389.52|3.279|across those two viewpoints a lot of
1391.6|3.36|animals instead
1392.799|4.081|have eyes that are positioned on the
1394.96|3.28|sides so they have very little overlap
1396.88|2.799|in their visual fields so they will
1398.24|3.2|typically use structure from motion and
1399.679|3.201|the idea is that they bob their heads
1401.44|2.64|and because of the movement they
1402.88|2.56|actually get multiple observations of
1404.08|4.0|the world and you can triangulate again
1405.44|4.239|depths and even with one eye closed and
1408.08|3.04|completely motionless you can still have
1409.679|2.961|some sense of depth perception
1411.12|3.039|if you did this i don't think you would
1412.64|2.64|notice me coming two meters towards you
1414.159|2.161|or 100 meters back
1415.28|2.72|and that's because there are a lot of
1416.32|3.12|very strong monocular cues that your
1418.0|2.72|brain also takes into account
1419.44|3.2|this is an example of a pretty common
1420.72|3.6|visual illusion where you have you know
1422.64|3.2|these two blue bars are identical but
1424.32|2.0|your brain the way it stitches up the
1425.84|1.76|scene
1426.32|2.479|is it just expects one of them to be
1427.6|2.64|larger than the other because of the
1428.799|2.961|vanishing lines of this image
1430.24|3.679|so your brain does a lot of this
1431.76|3.68|automatically and uh and neural nets
1433.919|3.36|artificial neural nets can as well
1435.44|3.599|so let me give you three examples of how
1437.279|3.121|you can arrive at depth perception from
1439.039|2.801|vision alone
1440.4|4.0|a classical approach and two that rely
1441.84|4.8|on neural networks so here's a video
1444.4|3.519|going down i think this is san francisco
1446.64|2.88|of a tesla so this is the
1447.919|3.12|our cameras are sensing and we're
1449.52|3.039|looking at all i'm only showing the main
1451.039|2.88|camera but all the cameras are turned on
1452.559|3.12|the eight cameras of the autopilot
1453.919|3.441|and if you just have the six second clip
1455.679|3.521|what you can do is you can stitch up
1457.36|3.679|this environment in 3d using multi-use
1459.2|4.959|stereo techniques so
1461.039|3.12|this oops
1464.64|3.12|this is supposed to be a video
1469.12|3.439|is not a video oh i know it's on there
1471.2|2.8|we go
1472.559|3.201|so this is the 3d reconstruction of
1474.0|2.88|those six seconds of that car driving
1475.76|2.799|through that path
1476.88|3.84|and you can see that this information is
1478.559|5.041|purely is it's very well recoverable
1480.72|4.319|uh from just videos and roughly that's
1483.6|2.72|through process of triangulation and as
1485.039|3.12|i mentioned multivisteria
1486.32|3.599|and we've applied similar techniques on
1488.159|4.4|slightly more sparse and approximate
1489.919|2.64|also in the car
1493.6|3.04|so it's remarkable all that information
1494.799|4.081|is really there in the sensor and just a
1496.64|3.519|matter of extracting it
1498.88|2.96|the other project that i want to briefly
1500.159|2.64|talk about is as i mentioned there's
1501.84|2.48|nothing about neural network
1502.799|3.041|neural networks are very powerful visual
1504.32|3.28|recognition engines and
1505.84|3.439|if you want them to predict depth then
1507.6|2.88|you need to for example look for labels
1509.279|2.561|of depth and then they can actually do
1510.48|2.799|that extremely well so there's nothing
1511.84|2.319|limiting networks from predicting this
1513.279|2.64|molecular depth
1514.159|3.041|except for labeled data so one example
1515.919|3.36|project that we've actually
1517.2|3.599|looked at internally is we use the
1519.279|2.0|forward-facing radar which is shown in
1520.799|1.521|blue
1521.279|2.801|and that radar is looking out and
1522.32|2.56|measuring depths of objects and we use
1524.08|3.76|that radar
1524.88|4.24|to annotate the uh what vision is seeing
1527.84|2.64|the bounding boxes that come out of the
1529.12|2.4|neural networks so instead of human
1530.48|2.72|annotators telling you
1531.52|3.2|okay this this car and this bounding box
1533.2|2.959|is roughly 25 meters away
1534.72|3.12|you can annotate that data much better
1536.159|3.361|using sensors so you use sensor
1537.84|2.959|annotation so as an example radar is
1539.52|2.48|quite good at that distance you can
1540.799|2.48|annotate that and then you can train
1542.0|2.72|your network on it and if you just have
1543.279|1.921|enough data of it this neural network is
1544.72|2.24|very good
1545.2|3.599|at predicting those patterns so here's
1546.96|4.0|an example of predictions
1548.799|3.041|of that so in circles i'm showing radar
1550.96|3.04|objects
1551.84|4.64|and in and the cuboids that are coming
1554.0|4.0|out here are purely from vision
1556.48|3.28|so the keyboards here are just coming
1558.0|3.12|out of vision and the depth of those
1559.76|3.68|cuboids is learned
1561.12|3.6|by a sensor annotation from the radar so
1563.44|2.16|if this is working very well then you
1564.72|2.48|would see that the
1565.6|3.199|circles in the top down view would agree
1567.2|2.56|with the cuboids and they do and that's
1568.799|2.401|because neural networks are very
1569.76|3.2|competent at predicting depths
1571.2|3.2|uh they can learn the different sizes of
1572.96|2.64|vehicles internally and they know how
1574.4|2.399|big those vehicles are and you can
1575.6|2.88|actually derive depth from that quite
1576.799|2.961|accurately
1578.48|3.28|the last mechanism i will talk about
1579.76|3.279|very briefly is slightly more fancy and
1581.76|1.919|gets a bit more technical but it is a
1583.039|4.24|mechanism
1583.679|4.88|that has recently there's a few papers
1587.279|2.161|basically over the last year or two
1588.559|2.641|on this approach it's called
1589.44|2.4|self-supervision so what you do in a lot
1591.2|3.52|of these papers
1591.84|4.56|is you only feed raw videos into neural
1594.72|2.959|networks with no labels whatsoever
1596.4|3.04|and you can still learn you can still
1597.679|2.961|get neural networks to learn depth and
1599.44|2.32|it's a little bit technical so i can't
1600.64|2.8|go into the full details but
1601.76|3.039|the idea is that the neural network
1603.44|2.16|predicts depth at every single frame of
1604.799|2.161|that video
1605.6|2.64|and then there are no explicit targets
1606.96|2.719|that the neural network is supposed to
1608.24|2.96|regress to with the labels
1609.679|3.201|but instead the objective for the
1611.2|3.52|network is to be consistent over time
1612.88|3.2|so whatever depth you predict should be
1614.72|1.839|consistent over the duration of that
1616.08|2.32|video
1616.559|3.281|and the only way to be consistent is to
1618.4|2.8|be right as the neural network
1619.84|2.319|automatically predicts the correct depth
1621.2|2.24|for all the pixels
1622.159|4.241|and we reproduce some of these results
1623.44|4.64|internally so this also works quite well
1626.4|3.2|so in summary people drive with vision
1628.08|2.959|only no no
1629.6|2.959|lasers are involved this seems to work
1631.039|1.841|quite well the point that i'd like to
1632.559|1.761|make
1632.88|3.52|is that visual recognition and very
1634.32|3.76|powerful recognition is absolutely
1636.4|2.08|necessary for autonomy it's not nice to
1638.08|2.64|have
1638.48|3.12|like we must have neural networks that
1640.72|2.0|actually really understand the
1641.6|3.92|environment around you
1642.72|3.6|and uh and lidar points are a much less
1645.52|2.399|information
1646.32|3.12|rich environment so vision really
1647.919|2.401|understands the full details just a few
1649.44|2.959|points around
1650.32|3.839|are much there's much less information
1652.399|2.241|in those so as an example on the left
1654.159|2.88|here
1654.64|3.279|um is that a plastic bag or is that a
1657.039|2.801|tire
1657.919|3.441|a light arm i just give you a few points
1659.84|2.959|on that but vision can tell you
1661.36|3.28|which one of those two is true and that
1662.799|3.12|impacts your control is that person who
1664.64|2.72|is slightly looking backwards
1665.919|3.041|are they trying to merge in into your
1667.36|3.199|lane on the bike or
1668.96|3.68|are they just or are they just going
1670.559|3.521|forward in the construction sites what
1672.64|2.96|do those signs say how should i behave
1674.08|2.8|in this world the entire
1675.6|3.679|infrastructure that we have built up for
1676.88|3.919|roads is all designed for human visual
1679.279|2.241|consumption so all the size all the
1680.799|2.801|traffic lights
1681.52|3.519|everything is designed for vision and so
1683.6|2.72|that's where all that information is and
1685.039|2.801|so you need that ability
1686.32|3.04|is that person distracted and on their
1687.84|2.24|phone are they going to work walk into
1689.36|2.799|your lane
1690.08|3.36|those answers to all these questions are
1692.159|3.361|only found in vision
1693.44|3.04|and are necessary for level 4 level five
1695.52|2.8|autonomy
1696.48|3.04|and that is the capability that we are
1698.32|2.56|developing at tesla
1699.52|2.48|and through this is done through
1700.88|1.919|combination of large scale neural
1702.0|2.32|network training
1702.799|3.6|through data engine and getting that to
1704.32|2.959|work over time and using the power of
1706.399|3.921|the fleet
1707.279|3.76|and so in this sense lidar is really a
1710.32|2.56|shortcut
1711.039|3.201|it sidesteps the fundamental problems
1712.88|2.799|the important problem visual recognition
1714.24|3.2|that is necessary for autonomy
1715.679|4.321|and so it gives a full sense of progress
1717.44|5.92|and is ultimately ultimately crutch
1720.0|5.76|it does give like really fast demos
1723.36|3.6|uh so if i was to summarize the entire
1725.76|2.799|um
1726.96|3.839|my entire talk in one slide it would be
1728.559|4.081|this
1730.799|3.201|every all of autonomy because you want
1732.64|2.96|level four level five systems that can
1734.0|4.799|handle all the possible situations
1735.6|4.4|in 99.99 of the cases and chasing some
1738.799|2.721|of the last few nights is going to be
1740.0|3.12|very tricky and very difficult and is
1741.52|2.32|going to require a very powerful visual
1743.12|2.96|system
1743.84|3.76|so i'm showing you some images of what
1746.08|2.719|you might encounter in any one slice of
1747.6|2.72|that nine so in the beginning you just
1748.799|2.561|have very simple cars going forward
1750.32|2.4|then those cars start to look a little
1751.36|2.799|bit funny then maybe you have bikes on
1752.72|2.8|cars then maybe you have cars on cars
1754.159|2.4|but maybe you start to get into really
1755.52|2.879|rare events like
1756.559|3.12|cars turned over or even cars airborne
1758.399|1.921|we see a lot of things coming from the
1759.679|3.281|fleet
1760.32|3.839|and we see them at some rate at like a
1762.96|3.12|really good rate compared to all of our
1764.159|3.361|competitors and so the rate of progress
1766.08|3.04|at which you can actually address these
1767.52|2.72|problems iterate on the software and
1769.12|1.76|really feed the neural networks with the
1770.24|1.76|right data
1770.88|3.12|that rate of progress is really just
1772.0|3.2|proportional to how often
1774.0|2.96|you encounter these situations in the
1775.2|3.12|wild and we encounter them significantly
1776.96|3.439|more frequently than anyone else which
1778.32|11.12|is why we're going to do extremely well
1780.399|9.041|thank you