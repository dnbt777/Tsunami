start_time|end_time|text
3.76|2.66|Welcome Andrej, I'm really glad you could join me today
6.46|0.88|Yeah, thank you for having me
7.74|6.08|So a lot of people already know your work in deep learning, but not everyone knows your personal story
14.28|5.24|So let us instead start by you know telling us. How did you end up doing all this work in deep learning?
20.34|0.84|Yeah, absolutely
21.42|4.56|So I think my first exposure to deep learning was when I was an undergraduate at the University of Toronto
26.5|2.6|And so Geoff Hinton was there and he was teaching a class on deep learning
29.6|2.82|And at the time it was restricted boltzmann machines trained on MNIST digits
33.02|1.6|And I just really like the way
34.8|4.44|Kind of Geoff talked about training the network like the mind of the network and he was using these terms
39.24|3.58|and I just thought it was a kind of a flavour of
43.08|3.24|something magical happening when when this was training on those digits and
47.769|2.33|And so that's kind of like my first exposure to it although
50.1|2.64|I didn't get into it in a lot of detail at that time
52.74|3.06|And then when I was doing my master's degree at the University of British Columbia
56.58|2.94|I took a class with Nando de Freitas, and that was again on machine learning
59.52|5.06|and that's the first time I kind of dealt kind of deeper into these networks and so on and
64.68|4.94|Kind of what was interesting is that I was very interested in artificial intelligence, and so I took classes in artificial intelligence
69.94|3.619|but a lot of what I was seeing there was just very not satisfying like it was a lot of kind of a
73.76|4.66|depth first search breadth first search or alpha-beta pruning all these things I was not understanding how
78.7|3.34|like I was not satisfied and so when I was seeing neural networks for the first time
82.04|5.18|like in machine learning which is kind of this term that I think is more technical and not as well known in kind of
87.52|3.02|you know most people talk about artificial intelligence machine learning was more kind of a
90.54|1.62|technical term I would almost say.
92.16|3.84|And so I was dissatisfied with artificial intelligence when I saw machine learning
96.0|3.18|I was like this is the AI that I want to kind of spend time on.
99.18|4.92|This is what's really interesting and that's kind of what took me down those directions.
104.1|2.88|Is that this is kind of almost a new computing paradigm I would say
107.88|4.28|Because normally humans write code, but here in this case
112.5|3.66|the optimization writes code and so you're creating input/output specification
116.16|2.94|and then you have a lot of examples of it and then the optimization writes code
119.1|1.62|and sometimes it can write code better than you
120.72|4.94|and so I thought that was just a very new kind of way of thinking about programming and
126.01|1.68|That's what kind of intrigued me about it
127.69|3.65|Then through your work one of the things you've come to be known for
131.36|5.74|is that you are now the human benchmark for the ImageNet image classification competition
137.1|2.02|How did that come about?
139.12|2.6|So basically the ImageNet challenge is kind of a
142.28|2.16|It's sometimes compared to kind of the world cup of computer vision
144.92|4.1|So a lot of people kind of care about this benchmark and number— our error rate kind of goes down over time
149.02|3.39|And it was not obvious to me kind of where a human would be on the scale
152.41|4.15|And I've done a similar smaller scale experiment on CIFAR-10 dataset earlier
156.58|3.84|So what I did in CIFAR-10 is I just was looking at these 32 by 32 images
160.42|2.97|And I was trying to classify them myself at the time this was only 10 categories
163.39|2.279|So it's fairly simple to create an interface for it
165.67|2.88|And I think I had an error rate of about 6% on that
168.55|5.25|And so that was and then based on what I was seeing and how hard task was I think I predicted that
173.8|2.58|the lowest error Rate we've achieved would be like
177.64|1.42|Okay, I can't remember the exact numbers.
179.06|3.8|I think I guess like 10% and we're now down to like 3 or 2% or something crazy
183.0|3.82|So that was my first kind of a fun experiment of like human
187.64|6.259|baseline and and I thought it was really important for the same purposes that you kind of point out in some of your lectures
193.9|2.0|I mean you really want that number to understand
196.4|5.66|You know it, how well humans are doing so we could compare machine learning algorithms to it and for Imagenet
202.06|2.98|It seemed that there was a discrepancy between how important this benchmark was
205.04|4.3|and how much focus there was on getting a lower number and us not understanding even how humans
209.66|3.5|Are doing on this benchmark, and so I created this Javascript interface
213.16|2.92|And I was showing myself the images and then
216.08|2.88|the problem with ImageNet is you don't have just ten categories you have a thousand
218.96|4.3|And so it almost like a UI challenge of obviously I can't remember a thousand categories
223.269|2.58|So how do I make it so that it's something fair?
225.85|4.169|And so I listed out all the categories, and I gave myself examples of them and so for each image
230.019|3.09|I was crawling through a thousand categories and just trying to kind of a
233.81|1.08|You know see?
234.89|3.37|Based on the example I was seeing for each category what this image might be and
238.26|4.18|I thought it was a just an extremely instructed exercise by itself
242.44|4.02|I mean I was not I did not understand that like a third of imageNet was dogs and like dog species
246.54|2.76|And so that was kind of interesting to see that
249.88|4.46|networks spend on unique amount of time caring about dogs. I think a third of its performance comes from dogs
257.299|3.8|Yeah, so this was kind of something that I did for maybe a week or two
261.1|2.429|I put everything else on hold. I thought it was kind of a very fun exercise
263.53|3.449|I got a number in the end, and then I thought that one person is not enough
266.979|2.49|I wanted to multiple other people and so I was trying to organize
269.84|5.569|Within a lab to get other people to kind of do the same thing, and I think people are not as willing to contribute
276.14|3.8|Say like a week or two of like pretty painstaking work
280.6|3.64|You know just like yeah sitting down for like five hours and trying to figure out which dog breed
284.46|5.16|This is as I was not able to get like enough data in that respect, but we got at least like some
290.15|4.94|Approximate performance which I thought was was fun, and then this was kind of picked up
295.09|4.649|And it's uh it wasn't obvious to me at the time. I just watched know the number, but this became like a thing
300.409|2.39|And people really like the fact that that this happened
302.8|2.88|And I'm referred to jokingly as what the reference human
305.68|5.22|and of course that's kind of a hilarious to me. huh, yeah
312.05|2.0|Well you were you surprised when?
314.419|4.25|You know software deep nets finally surpass your performance?
319.849|7.07|Absolutely, so yeah, absolutely. I mean especially I mean sometimes. It's really hard to see in the image where it is
326.919|5.16|It's just like a tiny blob of like the black black dog is obviously somewhere there, and I'm not seeing like you know
332.08|4.47|I'm guessing between like 20 categories and the network just gets it and I don't understand how that comes about
337.34|1.699|So there's some super humanist to it
339.039|1.75|but also for the
340.789|3.98|I think the network is extremely good at these kind of like statistics of like four types and textures
344.77|7.98|I just I think in that respect. I was not surprised that the network could better measure those fine statistics across lots of images
353.389|1.4|in many cases
354.789|4.739|I was surprised because some of the images required you to read like it's just a bottle and you can't see what it is
359.529|3.51|But actually tells you what it is in text and so as a human I can read it and fine
363.04|4.56|But the network would have to learn to read to identify the object because it wasn't obvious just from from it.
368.48|2.84|You know one of the things you become well-known for
371.66|4.74|in the deep learning community has been grateful to you for has been your teaching the [inaudible] and put that online
377.18|2.0|Tell me about how that came about
379.669|3.17|Yeah, absolutely so I think I felt very strongly that
385.49|3.919|Basically this technology was transformative and that a lot of people want to use it
389.409|1.921|It's somewhat like a hammer and what I wanted to do
391.33|5.88|I was in a position to randomly kind of hand out this hammer to a lot of people and I just found that very compelling
397.55|4.739|It's not like necessarily advisable from the perspective a phd students because you're putting a research on hold
402.289|4.11|I mean this became like hundred and twenty percent of my time and I had to put all of research on hold
406.4|3.299|Maybe I mean I talked to class twice on each time. It's maybe four months and so
410.22|3.679|That time is basically spent entirely on the class so it's not super advisable from that perspective
413.9|3.779|But it was basically the highlight of my phd is not even like related to research
417.68|2.16|I think teaching the class was definitely the highlight of my phd
420.36|5.0|Just just seeing the students just the fact that they were really excited. It was a very different class
426.09|3.41|Normally, you're being taught things that were discovered in 1800 or something like that
429.5|1.77|But we were able to come to class and say look
431.27|3.57|There's this paper from like a week ago or even like yesterday, and there's new results
434.84|2.339|And I think the undergraduate students and the other students
437.58|4.339|They just really enjoyed that aspect of the class and the fact that they actually understood so there's not
442.83|3.41|You know so you don't have to this is not nuclear physics or rocket science?
446.33|1.95|This is like you need to know calculus and linear algebra
448.28|5.04|And you can actually kind of understand everything that happens under the hood and so I think just the fact that it's so powerful
453.66|1.62|the fact that it's
455.28|2.1|that it keeps changing on a daily basis
457.38|2.72|as people kind of felt like they're on the forefront of something big and I think that's why
460.82|2.42|people like really enjoyed that class a lot yeah
463.48|4.9|And you've really helped a lot of people and handed a lot of hammers
468.38|5.62|You know as someone there's been in doing deep learning for quite some time now um
474.08|4.86|The field is evolving rapidly. I'd be curious to hear. How is your own thinking?
478.94|3.92|How does your understanding of deep learning change over these you know many years?
483.08|4.34|Yeah, it's basically like when I was seeing restricted boltzmann machines for the first time on digits
488.07|2.75|It wasn't obvious to me how this technology was going to be used
490.82|3.359|And how big of a deal it would be and also when I was starting to work on computer vision
494.37|5.539|Convolutional networks they were around but they were not something that a lot of the computer vision community kind of participated using
500.849|5.75|Anytime soon the I think the perception was that this works for small cases, but would never scale for large images
506.599|3.99|And that was just extremely incorrect and so
511.74|6.02|Basically I'm just surprised by how general technology is and how good the results are that was my largest surprise
517.76|2.0|I would say and it's not only that
520.11|4.16|So that's one thing that it worked so well and say like ImageNet but the other thing that I think no one saw coming
524.27|5.009|Or at least for sure I did not see coming is that you can take these pre train networks and that you can transfer
529.279|4.32|You can fine-tune them on arbitrary other tasks because now you're not just solving Imagenet and need millions of examples
534.14|2.639|This also happens to be very general feature extractor
536.78|4.88|and I think that's kind of a second insight that I think fewer people saw coming and
541.8|2.18|You know there were there were these papers that are just like
543.98|2.72|here are all the things that people have been working on in computer vision
546.7|4.6|scene classification, action recognition, object recognition
551.31|3.289|You know place attributes and so on and people are just kind of crushing each
554.6|3.72|Task just by fine-tuning the network and so that to me was
560.4|1.14|Very surprising
562.18|1.42|Yeah and somehow I guess
563.84|5.1|Supervised learning gets most of the press and even though featuring fine-tuning their transfer learning
570.06|4.4|is actually working very well people seem to talk less about that for some reason.
574.46|1.26|Right, yeah exactly
576.02|5.04|Yeah, I think what what has not worked as much are some of these hopes are on unsupervised learning which I think has kind of
581.58|3.02|Been really why a lot of researchers have gotten into the field and around
584.64|3.26|2007 and so on
588.24|2.39|And I think the promise of that has still not been delivered
590.63|3.359|And I think I found that I find that also surprising is that the supervised learning
594.089|4.04|part worked so well and the unsupervised learning is still kind of
598.199|3.53|in a state of uh yeah it's still a lot obvious how it's going to be used
602.459|4.52|or how that's going to work even though a lot of people are still deep believers. I would say to use the term
607.829|1.461|in this area
609.29|4.45|So I know that you know one of the persons who has been thinking a lot about the long-term future of AI
614.04|1.74|Do you want to share your thoughts on that?
615.78|2.96|So I spent the last maybe year and a half at OpenAI
618.74|2.82|I kind of thinking a lot about these topics and
623.6|1.68|It seems to me like
625.29|1.95|the Field will kind of
627.24|1.709|split into two trajectories
628.949|4.85|One will be kind of a kind of applied AI which is kind of just making these neural networks training them
634.44|6.919|Mostly with supervised learning potentially unsupervised learning and getting better say image recognizers or something like that, and I think
641.94|3.919|The other will be kind of the artificial general intelligence directions. Which is kind of how do you get?
646.829|5.99|Neural networks that are entire kind of dynamical system that thinks and speaks and can do everything that a human can do and is
652.89|1.8|intelligent in that way and
654.69|4.789|I think that what's been interesting is that for example in computer vision the way we approach it in the beginning
659.48|3.39|I think was wrong in that we tried to break it down by different parts
662.87|4.41|So we were like okay humans recognize people humans recognize scenes you recognize objects
667.28|2.609|so we're just going to do everything that humans do and
670.2|4.25|Then once we have all those things and now we have what different areas and once we have all those things we're going to figure
674.45|3.75|Out how to put them together, and I think that was kind of a wrong approach and we've seen that
678.2|3.12|How that kind of played out historically and so I think
681.74|5.34|There's something similar that's going on likely on the higher level of with AI so kind of people are asking well
687.08|0.91|Okay
people plan
687.99|1.14|people do
689.13|5.15|Experiments to figure out how the world works or people talk to other people so we need language and we are trying to decompose it
694.28|3.599|By function accomplish each piece and then put it together into some kind of brain
697.88|5.85|And I just think it's kind of a just incorrect approach and so what I've been a much bigger fan of is having
706.08|2.479|not decomposing that way, but having a single kind of
709.08|4.099|Neural Network there is a complete dynamical system that you're always working with a full agent and
713.4|4.339|Then the question is how do you actually create objectives such that when you optimize
718.02|4.48|over the weights to make up that brain you get intelligent behaviour out and so
723.02|2.52|That's kind of been something that I've been thinking about a lot at OpenAI
725.54|4.68|I think there are a lot of kind of different area ways that people have thought about approaching this problem
730.89|5.059|So for example going in a supervised learning direction. I have this essay online. It's not an essay
735.95|4.679|It's kind of a short story that I wrote and the short story kind of tries to cover the hypothetical world of what it might?
740.63|5.76|look like if the way we approach this AGI is just by scaling up supervised learning which we know works and
747.18|7.7|and so that gets into something that looks like Amazon mechanical turk where people ssh into lots of robot bodies and they perform tasks and
754.88|5.489|Then we train on that as a supervise learning data set to imitate humans and what that might look like and so on and so
760.37|1.78|Then there are other directions
762.15|1.92|Like I'm surprised learning
764.07|2.63|From algorithmic information theory things like AIXI
767.25|6.05|Or from artificial life things that look more like artificial evolution and so that's kind of where I spend my time
773.48|4.56|I think a lot about and I think I had a correct answer, but I'm not going to reveal it here
778.92|2.9|At least I can learn more but reading your blog post
781.82|1.4|Oh yeah, absolutely
783.22|3.9|So you've already given out a lot of hammers
787.68|5.0|And today there are a lot of people still wanting to enter the field of AI, the deep learning
792.84|8.36|So for people in that position. What advice. Do you have for them? Yeah absolutely so I think when people talk to me about CS231
801.2|3.85|And why they thought it was a very useful course what people what I keep hearing again
805.05|0.57|and again is
805.629|0.93|Just people
806.559|5.06|appreciate the fact that we got all the way to the low level details and they were not working with a library they saw the
811.62|6.899|raw code and they saw how everything was implemented and implemented chunks of it themselves, and so just going all the way down to the
819.16|2.029|understanding everything under you and never
821.62|4.489|It's really important to not abstract away things like you need to have a full understanding of the whole stack
826.11|3.119|And that's where I learned the most myself as well when I was learning this stuff
829.23|2.609|It's just implementing it myself from scratch was the most important
832.839|2.75|It was the piece that that I felt gave me
836.529|4.94|The best kind of a bang for buck in terms of understanding, so I wrote my own library it's called convnet js
841.47|4.349|it was written in Javascript and implements convolutional neural networks that was my way of learning about back propagation and
847.059|2.9|So that's something that I keep advising people is that that you
850.749|4.16|Not work with tensorflow or something else you can work with it once you have written it something
855.0|4.6|Something yourself on the lowest detail you understand everything under you and now you are comfortable to you now
859.64|3.0|It's possible to use some of these frameworks that abstract some of it away from you
862.649|1.81|but you know what's under the hood and
864.459|1.891|So that's been something that helped me the most
866.35|4.579|That's something that people appreciate the most when they take 231N and that's when I would advise a lot of people
871.059|2.78|Rather than you [           ]
874.42|4.399|Yeah, yeah, and it's some kind of a sequence of layers, and I know that when I add some drop out layers
878.819|2.88|It makes it work better, but that's not what you want in that
881.699|5.85|Case you're you're not going to be able to debug effectively you're not going to be able to improve a models effectively
888.1|1.579|with that answer
889.68|5.46|I'm really glad that the deep learning dot AI course started off with many weeks of python programming first
895.7|1.64|Yeah good good
898.18|6.4|Thank you very much for sharing your insights and advice you're already a hero to many people in the deep learning world
904.589|4.5|So really glad really grateful. You could join us here today. Yes. Thank you for having me.