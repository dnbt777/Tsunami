start_time|end_time|text
12.33|0.93|Thank you for the introduction.
13.26|3.9|So I'll be talking about Recurrent Neural 
Network (RNN) Language models especially in  
17.16|3.24|the context of Dense Image Captioning and I'll 
show you what that means by the end of the talk.
20.4|7.02|Now Recurrent Neural Networks (RNN) are 
wonderful models to work with because they  
27.42|4.35|offer a lot of flexibility in how you can design 
your Recurrent Neural Network architectures. So,  
31.77|2.79|normally when you're working with neural 
networks you're in the case in the very left  
34.56|4.41|where you have at some kind of a fixed sized 
input vector shown in red then you process it  
38.97|4.65|with some hidden layers shown in green and 
then you predict a fixed size output vector  
43.62|4.92|in blue and so an example of this setting is 
say image classification. So with Recurrent  
48.54|4.71|Neural Networks you can set up other kinds of 
architectures for example you can operate over  
53.25|9.63|sequences in input/output or both. So in a case 
of image captioning we're taking a single fixed  
62.88|4.23|sized image and we're producing a sequence of 
words that are part of the caption of that image.
67.11|4.59|In a setting of Sentiment Classification we 
are taking a sequence of words and we're trying  
71.7|3.72|to predict whether or not the sentiment 
is positive or negative. In the case of  
75.42|4.92|image in Machine Translation we can take 
a sequence of words in English and we can  
80.34|3.87|produce a sequence of words in French that 
consists of the translation, or we can be  
84.21|4.5|in the setting of video classification where 
we have a sequence of video frames and we'll  
88.71|3.81|try to classify every one of them but crucially 
we want every single frames predictions to not  
92.52|3.81|be just a function of that frame but every 
frame that has come before it in the video.
96.33|6.81|Now, it turns out that recurrent neural networks 
actually have a very simple API they basically  
103.14|4.44|consist of a single step function and the step 
function takes a vector X and it produces a  
107.58|5.31|vector Y but crucially the RNN has a state that 
it gets to update every time it sees a vector X  
112.89|6.09|come in and so one specific implementation of this 
in a vanilla Recurrent Neural Network (RNN) might  
118.98|5.04|look as follows. In this case the Recurrent Neural 
Network (RNN) state is made up of a single hidden  
124.02|5.58|state vector and the step function takes a vector 
X and then it gets to update its state vector  
129.6|5.8|according to the recurrence formula shown in both 
code, tech form and in mathematical form below. 
135.4|3.3|So we get to update our head and state based 
on the previous hidden state and based on the  
138.7|4.56|current input X that has fed into the RNN and 
then we get to predict the vector Y based on  
143.26|6.93|the hidden state age and so these matrices here 
w, w_hh, w_xh & w_hy those are the parameters  
150.19|3.36|of a recurrent neural network and as you change 
these parameters of course you're going to get  
153.55|3.36|a different behavior of the recurrent neural 
network and now we'd like some specific kind  
156.91|3.78|of behavior from the RN and so we feed it a lot 
of data and we tune these parameters over time.
160.69|6.66|So for example one way to endow semantics on top 
of the vectors x and y is to work in the context  
167.35|3.51|of character level language models and before I 
dive into the example I'd just like to point out  
170.86|5.43|that in my own work on these models I've worked 
on top of a lot of previous work from Alex Graves,  
176.29|4.92|Ilya Sutskever, Tomáš Mikolov and Yoshua Bengio 
and the way this will work is in a character level  
181.21|4.56|RNN model we are going to consume a sequence 
of characters and then we're trying to predict  
185.77|4.71|the next character in the sequence. So, suppose 
we're working with this simple example of a string  
190.48|5.34|[h,e,l,o] that we'd like to train on what we're 
going to do is we're going to feed the characters  
195.82|5.13|[h,e,l,l] into the RNN one step at a time so 
we have four distinct time steps here and we're  
200.95|5.28|feeding the characters into the RNN and the RNN 
can only process vectors so we have to encode them  
206.23|4.62|in some ways such as for example one of K encoding 
and at every single time step the RNN will update  
210.85|6.63|its hidden state based on the recurrence formula 
that I've shown you so we have three numbers in  
217.48|4.47|hidden state in this case and we're using that 
formula to compute the hints the hidden vector at  
221.95|4.92|every single time step and now the RN is trying to 
predict the next character in a sequence at every  
226.87|4.86|single time step since we have four characters 
in our example vocabulary here the RNN has to  
231.73|6.21|produce at every time step four numbers that gives 
scores or log probabilities for every single next  
237.94|3.9|character in a sequence so for example in the 
very first time step we fed in the letter H and  
241.84|6.54|with the current setting of weights in the RNN and 
right now the RNN assigns the letters [h-e-l & o]  
250.09|5.73|log probabilities 1, 2.2, -3 and 4.1 respectively. 
In particular we know that in this training  
255.82|5.94|sequence the letter [e] should follow [h] and so 
we know that the score 2.2 we'd like that to be  
261.76|5.23|higher and the scores of all the other characters 
in red should be lower and so every single time  
266.99|3.48|step what this amounts to is we want the green 
numbers to be higher and the red numbers to be  
270.47|3.48|lower that's what you encode in your gradient 
signal and back propagate through the network  
273.95|4.26|and the back propagation signal then tells you the 
gradients on the weights and that tells you how  
278.21|3.42|to adjust your weights so that the predictions 
are more consistent with your training data.
283.07|5.61|What we can do now is we can take an entire 
set of documents and we can feed it into the  
288.68|3.93|recurrent neural network and it will learn how 
to predict these sequences so for example as  
292.61|4.53|a specific example we can feed in a poem of 
William Shakespeare and for our purposes is  
297.14|3.99|just a giant string of characters that we plug 
into the RNN one at a time and that we train  
301.13|4.32|on. Then we train the recurrent network on 
this and what we can do then is use the RNN  
305.45|4.47|to generate or sample or hallucinate these kinds 
of sequences that it has seen in training data  
309.92|4.2|one character at a time. Now when you train the 
RNN what you'll see is that in the beginning we  
314.12|3.45|just start off with random weights right so 
the predictions that it produces are just  
317.57|4.38|complete gibberish in the very first box there 
but then when you train a bit the RNN starts to  
321.95|5.13|discover that okay this input data is actually 
made up of words - it starts to use spaces,  
327.08|4.56|it starts to use quotes and periods at the 
end of sentences and so on and as you train  
331.64|3.27|more and more it discovers more and more long 
term statistical structure in your data and  
334.91|5.28|eventually it's producing samples of poems 
that are nearly indistinguishable at least  
340.19|4.98|on a low-level statistical level to two points 
from Shakespeare and so you can generate entire  
345.17|4.29|poetry infinite poetry from Shakespeare so 
I'll just read one paragraph for example:
349.46|4.29|'Alas I think he shall become approached and 
the day when little strain would be attained  
353.75|4.17|into being never fed and who is but a chain 
and subject of his death I should not sleep'  
357.92|6.48|and so you can generate infinite poetry like 
this. Of course we can feed in any kind of  
364.4|4.14|character sequence that we like, and we have. 
So for example we found this open source book  
368.54|5.1|on algebraic geometry so we just take all source 
code for this book and we feed it one character  
373.64|8.16|at a time into the RNN and then the RNN learns to 
generate mathematics that almost compiles (we have  
381.8|5.04|to fix it a tiny bit) but what it comes up with 
is basically it starts to create its own lemmas,  
386.84|6.23|it starts to prove them, it puts little rectangles 
at the ends of its proofs and just kind of samples  
393.07|6.99|all of this. I can barely distinguish it from 
the actual data, sometimes it tries to create  
400.06|5.97|diagrams so in this case it has almost succeeded. 
My favorite part is on the top left the proof is  
406.03|8.04|omitted for some lemma so you can feed in any 
kind of character data we also tried feeding  
414.07|4.5|in a code so I went on the Linux repository 
and I downloaded all source code of Linux,  
418.57|5.04|this turns out to be about 16 megabytes (or 
was it 600?) a lot of megabytes of text and  
423.61|6.0|it's a C code and then you feed it into the RNN 
and then it can just create code and so this is  
429.61|3.99|a function that was generated by the RNN and you 
can see that it takes some arguments it has some  
433.6|6.21|variables it creates loops, if statements, it 
creates its own bogus comments and syntactically  
442.33|6.0|there's very few mistakes in tactically in what 
the RNN does some of the mistakes you'll notice  
448.33|5.76|by the way is that it uses variables that were not 
declared or it declares variables and never uses  
454.09|4.41|them those are the kinds of mistakes you'll see. 
Sometimes the RNN decides that it's time to start  
458.5|6.12|a new c file and what it does then is it recites 
character by character the blue gpl-licensed (it  
464.62|4.89|has learned it by heart) and then it creates 
some includes and then sample some macros and  
469.51|4.74|then dives into code and so it has a very good 
idea of these statistical patterns in the data  
474.25|4.26|and how they should just be created there. 
Everything I've described so far by the way  
478.51|4.62|can be implemented in about 200 lines of Python 
code with the only dependency is numpy and so  
483.13|5.31|this is a gist that you can look up on github 
and this is an entire character level language  
488.44|3.75|RNN model in these hundred lines. Now of course 
if you'd like to actually be more serious and  
492.19|4.95|you'd like to use GPUs and so on then you might 
be interested in my other project called char-RNN  
497.14|3.6|and this is a more serious implementation 
but it's basically the exact same thing.
500.74|5.76|Now many people have taken this code and 
they've kind of run it on very different  
506.5|3.45|things so we can sample cooking recipes, 
this one is for a basic cheese wings,  
509.95|5.16|and you know there's a whole bunch of ingredients 
you preheat the oven to 350 degrees Fahrenheit  
515.11|5.67|and so on and so forth so you can look at these 
people have also created all kinds of twitter  
520.78|7.21|BOTS so this char 9 was in the Bible and now it's 
sampling verses, you can feed it music, it can  
527.99|5.82|generate magic cards and so on so basically it's 
quite powerful and it's very simple code base.
533.81|4.83|Now in my own work at Stanford with my equal 
co-author on this paper Justin Johnson my adviser  
538.64|4.59|Fei-Fei Li we were more interested in kind 
of studying exactly how this works so we went  
543.23|3.72|through character level RNNs and we're studying 
the statistical patterns how this works where  
546.95|4.44|the kinds of errors that it's still making and 
how they change as you scale up the model and so  
551.39|4.23|one of the experiments I'd like to highlight for 
you is we were looking at interpretable cells in  
555.62|4.62|the RNNs and so in these experiments we get to 
pretend that we are neuroscientists and we get  
560.24|6.42|the RNN to read some text in this case some piece 
of code and we're looking at a particular cell in  
566.66|4.26|the RNN a particular hidden state vector and we're 
looking at what excites it as it's reading this  
570.92|5.58|text and so this hidden state neuron does not 
really have an interpretable sequence that it  
576.5|4.2|responds to but as you go through many neurons 
you find several that are quite interpretable  
580.7|6.12|so for example we found a quote detection cell in 
the RNN it basically is off but then when it sees  
586.82|5.25|a quote it turns on and then it stays on until 
the quote ends and so what's remarkable about  
592.07|4.59|this is that we of course didn't specify this but 
in the process of the RNN trying to predict the  
596.66|4.77|next character it has decided that it's useful to 
allocate some space in its hidden state to keeping  
601.43|4.38|track of the quotes and so it just developed this 
little algorithm internally you know through back  
605.81|4.44|propagation. We also found some cells that 
keep track of line lengths so in this data  
610.25|5.07|set here there's a newline character after roughly 
every 80 characters there's a newline character  
615.32|4.23|that starts a new line and the RNN has therefore 
decided that it's a good idea to actually create  
619.55|4.32|a small counter for how far along you are in the 
sequence and so there's a cell that basically  
623.87|4.56|turns on and then slowly decays over time and this 
might help you predict the next newline character.
628.43|6.45|There are these cells that only respond in F 
statements in code or cells that only respond  
634.88|4.71|inside comments or strings or cells that 
get more excited as you indent your code  
639.59|3.72|and you're deeper in the nested expression 
and so basically the RNN just truncates  
643.31|3.3|your data in all these different patterns 
so that it can perform this prediction.
646.61|5.52|Now in my own work roughly a year ago I realized 
that these RNN models were extremely powerful and  
652.13|5.31|I was specifically interested in applying them 
in a case of visual recognition and so we're  
657.44|4.26|going to look at image captioning where we take 
an image and then were using an RNN to predict  
661.7|4.08|a sentence for it and this model is made up of 
two components: there's a convolutional neural  
665.78|4.02|network which we know is very good at seeing 
images and then there's a recurrent neural  
669.8|3.84|network which we know is very good at modelling 
sequences in this case sequences of words that  
673.64|4.71|make up a sentence and then I like to use the 
analogy of playing with neural networks is kind  
678.35|3.09|of playing with Lego blocks and so what we do 
is we just kind of stick these two components  
681.44|3.96|together that corresponds to the arrow in between 
the two modules so just to give you an idea about  
685.4|4.92|how this would work and how we could caption a 
test image, we take a test image and we feed it  
690.32|3.57|through a Convolutional Neural Network (CNN) now 
normally at the end of a Convolutional Network  
693.89|5.22|you have a classifier that would predict one 
of 1,000 categories for this image but in this  
699.11|4.56|case we're going to get rid of that classifier and 
instead we're going to redirect the representation  
703.67|3.93|on the top layer of the Convolutional Network 
into the Recurrent Neural Network so we begin  
707.6|4.53|the generation with a special start token and 
we forward the Recurrent Neural Network to give  
712.13|6.42|us the probability distribution over the first 
word in the description in y0 and critically  
718.55|6.39|this prediction is also a function of the image 
through that added interaction into the RNN and so  
724.94|3.72|you might imagine for example that the presence 
of the straw textures in this man's hat can  
728.66|5.46|positively influence the probability of sampling 
the word straw in this context at the first time  
734.12|3.81|stem. So we sample from that distribution at 
the very first time step suppose that the word  
737.93|4.95|that was sampled is indeed straw and we feed it 
back into the RNN and we forward again to get a  
742.88|4.44|parallel distribution over the second word in a 
sequence and we sample from it again and suppose  
747.32|3.96|that it gives us the word hat and we continue 
in this fashion just plugging in the words and  
751.28|4.86|it's generating a new word for this image until 
it samples a special end token and that's the  
756.14|4.02|period I did that the sentence and at this point 
the RNN would have described that image as a straw  
760.16|7.17|hat period, one word at a time. So we train these 
data we train these models and to end on image  
767.33|4.59|sentence data sets one popular example right now 
that people are using often is Microsoft cocoa it  
771.92|4.56|consists of roughly hundred thousand images and 
they are described with five sentences each and  
776.48|3.96|this is data from Amazon Mechanical Turk and so 
there's an example of a training image with some  
780.44|5.04|of its captions and when we train this the RNN 
learns to describe these images and so here are  
785.48|4.63|some examples: so in the top row for example we 
have a man in a black shirt playing guitar or a  
790.11|3.48|construction worker in an orange safety vest 
working on the road and so on. On the bottom  
793.59|6.03|row I have some of my favorite failure cases we 
have a young boy holding a baseball bat or a cat  
799.62|4.41|sitting on the couch with the remote control or 
a woman holding a teddy bear in front of a mirror  
804.03|6.69|I'm guessing that these lock texture on the man's 
sweater or we have just a complete failure case  
810.72|4.59|of a horse in the middle of a road but I can't 
see any horse so not sure what happened there.
815.31|5.46|Now in my most recent work again was Justin 
Johnson my eco caught on this paper and my advisor  
820.77|5.28|Fei-Fei Li we've extended this basic model into 
this monster on the bottom and effectively what  
826.05|4.41|this amounts to is what we had right now the image 
sentence captioning model is it takes a full image  
830.46|4.89|and it describes of the single sentence what we're 
doing now in this new model is we're tackling the  
835.35|5.19|joint task of both detection and description so 
we can take an image and forward it through this  
840.54|5.16|model and in a single forward pass of a network 
we can both detect and describe everything in  
845.7|5.97|the image and so here in this example you have 
detected a trunk of an elephant, or that whole  
851.67|3.84|elephant, or the ball is white, or there are 
large green trees in the background, or the  
855.51|4.38|roof of the building, the leg of an elephant and 
so on. So everything is described in the image.  
859.89|5.25|Here's another example; we have light on a wall 
or sign on the wall, a man sitting on a table,  
865.14|5.94|you know, white laptop on the table and so on. 
And so there are hundreds of descriptions that  
871.08|4.53|this RNN produces for this image but I'm only 
showing some of the top 20 because it's way  
875.61|4.05|too dense otherwise. The model also has a very 
good idea of object parts for example it knows  
879.66|4.02|that there's a tail of a plane or an engine 
of a plane or the nose of a plane and so on.
883.68|5.22|We can also run this task conversely and what we 
can do is we can query with a small piece of text  
888.9|5.22|and then we can get the model to look through 
a database of images for regions in your images  
894.12|3.81|that are compatible with that text snippet. 
So, for example, when the query is 'head of  
897.93|4.23|a giraffe' we go off and we find all these 
little heads of giraffes, or legs of zebra,  
902.16|4.59|or red and white signs, or white tennis shoes 
and so on so we can search for arbitrary little  
906.75|3.27|text snippets in large collections of 
datasets and it's relatively efficient.
910.02|5.28|Now if you'd like to learn much more 
about these topics we are teaching  
915.3|4.17|currently a class at Stanford called 
CS231n and Justin and Fei-Fei are my co  
919.47|4.98|instructors and lecture video slides notes 
and assignments everything is available so  
924.45|3.78|you can learn much more about the topic and 
I think this is the last slide so I'm done.
928.23|0.54|Thank you.