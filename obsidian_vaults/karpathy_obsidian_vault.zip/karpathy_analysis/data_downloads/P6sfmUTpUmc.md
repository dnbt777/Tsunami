start_time|end_time|text
0.0|4.74|hi everyone today we are continuing our
2.52|3.299|implementation of makemore now in the
4.74|2.639|last lecture we implemented the
5.819|3.78|multi-layer perceptron along the lines
7.379|4.14|of benjiotyle 2003 for character level
9.599|4.021|language modeling so we followed this
11.519|4.08|paper took in a few characters in the
13.62|3.659|past and used an MLP to predict the next
15.599|3.18|character in a sequence
17.279|3.361|so what we'd like to do now is we'd like
18.779|3.66|to move on to more complex and larger
20.64|3.479|neural networks like recurrent neural
22.439|3.84|networks and their variations like the
24.119|4.141|Gru lstm and so on
26.279|3.541|now before we do that though we have to
28.26|3.9|stick around the level of multilia
29.82|3.72|perceptron for a bit longer and I'd like
32.16|3.059|to do this because I would like us to
33.54|3.72|have a very good intuitive understanding
35.219|4.02|of the activations in the neural net
37.26|3.84|during training and especially the
39.239|3.66|gradients that are flowing backwards and
41.1|3.72|how they behave and what they look like
42.899|3.241|and this is going to be very important
44.82|3.18|to understand the history of the
46.14|3.419|development of these architectures
48.0|3.78|because we'll see that recurrent neural
49.559|3.721|networks while they are very expressive
51.78|2.88|in that they are a universal
53.28|4.919|approximator and can in principle
54.66|4.8|Implement uh all the algorithms we'll
58.199|2.941|see that they are not very easily
59.46|3.0|optimizable with the first order
61.14|2.759|ingredient-based techniques that we have
62.46|2.099|available to us and that we use all the
63.899|2.881|time
64.559|4.621|and the key to understanding why they
66.78|4.08|are not optimizable easily is to
69.18|2.82|understand the the activations and the
70.86|2.939|gradients and how they behave during
72.0|4.02|training and we'll see that a lot of the
73.799|5.761|variants since recurring neural networks
76.02|5.459|have tried to improve that situation and
79.56|3.9|so that's the path that we have to take
81.479|4.32|and let's get started so the starting
83.46|4.019|code for this lecture is largely the
85.799|2.46|code from four but I've cleaned it up a
87.479|3.661|little bit
88.259|5.581|so you'll see that we are importing all
91.14|4.019|the torch and matplotlab utilities we're
93.84|3.84|reading in the words just like before
95.159|4.621|these are eight example words there's a
97.68|4.079|total of 32 000 of them here's a
99.78|4.5|vocabulary of all the lowercase letters
101.759|5.04|and the special dot token
104.28|6.299|here we are reading in the data set and
106.799|6.78|processing it and creating three splits
110.579|5.161|the train Dev and the test split
113.579|4.5|now in MLP this is the identical same
115.74|3.839|MLP except you see that I removed a
118.079|3.601|bunch of magic numbers that we had here
119.579|3.54|and instead we have the dimensionality
121.68|3.719|of the embedding space of the characters
123.119|3.841|and the number of hidden units in the
125.399|3.901|hidden layer and so I've pulled them
126.96|3.719|outside here so that we don't have to go
129.3|2.28|and change all these magic numbers all
130.679|2.821|the time
131.58|4.5|with the same neural net with 11 000
133.5|5.099|parameters that we optimize now over 200
136.08|4.86|000 steps with a batch size of 32 and
138.599|4.14|you'll see that I refactor I refactored
140.94|3.6|the code here a little bit but there are
142.739|4.021|no functional changes I just created a
144.54|5.16|few extra variables a few more comments
146.76|5.16|and I removed all the magic numbers and
149.7|4.44|otherwise is the exact same thing
151.92|4.56|then when we optimize we saw that our
154.14|4.94|loss looked something like this we saw
156.48|5.16|that the train and Val loss were about
159.08|5.379|2.16 and so on
161.64|5.22|here I refactored the code a little bit
164.459|4.441|for the evaluation of arbitrary splits
166.86|4.019|so you pass in a string of which split
168.9|4.919|you'd like to evaluate and then here
170.879|5.041|depending on train Val or test I index
173.819|3.301|in and I get the correct split and then
175.92|3.3|this is the forward pass of the network
177.12|2.82|and evaluation of the loss and printing
179.22|4.5|it
179.94|5.28|so just making it nicer one thing that
183.72|4.2|you'll notice here is
185.22|5.099|I'm using a decorator torch.nograd which
187.92|4.319|you can also look up and read the
190.319|4.381|documentation of basically what this
192.239|5.22|decorator does on top of a function is
194.7|6.3|that whatever happens in this function
197.459|5.941|is assumed by torch to never require any
201.0|4.86|gradients so it will not do any of the
203.4|4.32|bookkeeping that it does to keep track
205.86|3.659|of all the gradients in anticipation of
207.72|3.599|an eventual backward pass
209.519|4.021|it's almost as if all the tensors that
211.319|4.381|get created here have a requires grad of
213.54|3.36|false and so it just makes everything
215.7|3.119|much more efficient because you're
216.9|3.96|telling torch that I will not call that
218.819|3.181|backward on any of this computation and
220.86|2.76|you don't need to maintain the graph
222.0|4.2|under the hood
223.62|5.479|so that's what this does and you can
226.2|6.72|also use a context manager with
229.099|5.381|torch.nograd and you can look those up
232.92|2.7|then here we have the sampling from a
234.48|3.3|model
235.62|3.539|um just as before just a poor passive
237.78|3.78|and neural net getting the distribution
239.159|4.381|sampling from it adjusting the context
241.56|4.38|window and repeating until we get the
243.54|4.8|special and token and we see that we are
245.94|4.68|starting to get much nicer looking words
248.34|3.959|sample from the model but still not
250.62|3.78|amazing and they're still not fully
252.299|5.28|named like but it's much better than
254.4|5.339|when we had them with the byground model
257.579|3.181|so that's our starting point now the
259.739|2.761|first thing I would like to scrutinize
260.76|4.379|is the initialization
262.5|4.56|I can tell that our network is very
265.139|3.84|improperly configured at initialization
267.06|3.12|and there's multiple things wrong with
268.979|2.101|it but let's just start with the first
270.18|3.0|one
271.08|3.66|look here on the zeroth iteration the
273.18|4.38|very first iteration
274.74|4.679|we are recording a loss of 27 and this
277.56|4.02|rapidly comes down to roughly one or two
279.419|3.84|or so I can tell that the initialization
281.58|2.7|is all messed up because this is way too
283.259|3.181|high
284.28|3.419|in training of neural Nets it is almost
286.44|3.24|always the case that you will have a
287.699|4.621|rough idea for what loss to expect at
289.68|4.92|initialization and that just depends on
292.32|5.04|the loss function and the problem set up
294.6|4.2|in this case I do not expect 27. I
297.36|3.119|expect a much lower number and we can
298.8|4.02|calculate it together
300.479|5.881|basically at initialization what we'd
302.82|5.34|like is that there's 27 characters that
306.36|4.32|could come next for any one training
308.16|3.96|example at initialization we have no
310.68|3.78|reason to believe any characterist to be
312.12|3.6|much more likely than others and so we'd
314.46|3.959|expect that the probability distribution
315.72|4.5|that comes out initially is a uniform
318.419|4.981|distribution assigning about equal
320.22|5.22|probability to all the 27 characters
323.4|4.739|so basically what we like is the
325.44|6.42|probability for any character would be
328.139|5.101|roughly 1 over 27.
331.86|3.66|that is the probability we should record
333.24|4.62|and then the loss is the negative log
335.52|3.959|probability so let's wrap this in a
337.86|3.72|tensor
339.479|4.741|and then that one can take the log of it
341.58|4.26|and then the negative log probability is
344.22|5.58|the loss we would expect
345.84|5.76|which is 3.29 much much lower than 27.
349.8|3.899|and so what's happening right now is
351.6|3.78|that at initialization the neural net is
353.699|3.78|creating probability distributions that
355.38|3.659|are all messed up some characters are
357.479|3.0|very confident and some characters are
359.039|3.121|very not confident
360.479|3.66|and then basically what's happening is
362.16|2.94|that the network is very confidently
364.139|4.801|wrong
365.1|6.24|and uh that make that's what makes it um
368.94|3.84|record very high loss so here's a
371.34|3.48|smaller four-dimensional example of the
372.78|5.04|issue let's say we only have four
374.82|4.319|characters and then we have Logics that
377.82|3.0|come out of the neural land and they are
379.139|3.78|very very close to zero
380.82|4.8|then when we take the soft Max of all
382.919|4.081|zeros we get probabilities there are a
385.62|5.34|diffuse distribution
387.0|6.06|so sums to one and is exactly uniform
390.96|4.799|and then in this case if the label is
393.06|5.46|say 2 it doesn't actually matter if this
395.759|4.38|if the label is 2 or 3 or 1 or 0 because
398.52|3.179|it's a uniform distribution we're
400.139|4.021|recording the exact same loss in this
401.699|4.5|case 1.38 so this is the loss we would
404.16|4.02|expect for a four-dimensional example
406.199|4.741|and I can see of course that as we start
408.18|4.859|to manipulate these logits we're going
410.94|5.099|to be changing the loss here so it could
413.039|4.801|be that we lock out and by chance this
416.039|3.6|could be a very high number like you
417.84|3.24|know five or something like that then in
419.639|2.581|that case we'll record a very low loss
421.08|2.88|because we're assigning the correct
422.22|4.319|probability at the initialization by
423.96|5.28|chance to the correct label
426.539|7.801|much more likely it is that some other
429.24|6.12|dimension will have a high uh logit and
434.34|3.419|then what will happen is we start to
435.36|3.899|record much higher loss and what can
437.759|3.481|come what can happen is basically The
439.259|4.681|Lodges come out like something like this
441.24|5.94|you know and they take on Extreme values
443.94|4.5|and we record really high loss
447.18|3.84|um
448.44|6.18|for example if we have torch.randen of
451.02|6.959|four so these are uniform sorry these
454.62|5.639|are normally distributed numbers
457.979|5.521|uh forum
460.259|4.981|and here we can also print the logits
463.5|5.16|the probabilities that come out of it
465.24|6.12|and the loss and so because these logits
468.66|4.86|are near zero for the most part the loss
471.36|6.739|that comes out is is okay
473.52|4.579|but suppose this is like times 10 now
478.74|4.2|you see how because these are more
480.479|4.381|extreme values it's very unlikely that
482.94|4.5|you're going to be guessing the correct
484.86|4.679|bucket and then you're confidently wrong
487.44|3.9|and recording very high loss
489.539|3.06|if your lodges are coming out even more
491.34|4.32|extreme
492.599|6.121|you might get extremely insane losses
495.66|4.74|like infinity even at initialization
498.72|3.24|um
500.4|4.26|so basically this is not good and we
501.96|6.06|want the load just to be roughly zero
504.66|4.92|um when the network is initialized in
508.02|3.48|fact the logits can don't have to be
509.58|4.44|just zero they just have to be equal so
511.5|3.959|for example if all the objects are one
514.02|3.6|then because of the normalization inside
515.459|3.0|the softmax this will actually come out
517.62|2.58|okay
518.459|3.301|but by symmetry we don't want it to be
520.2|3.36|any arbitrary positive or negative
521.76|3.84|number we just want it to be all zeros
523.56|4.08|and record the loss that we expect at
525.6|4.08|initialization so let's Now quickly see
527.64|3.84|where things go wrong in our example
529.68|4.2|here we have the initialization
531.48|4.14|let me reinitialize the neural net and
533.88|3.48|here let me break after the very first
535.62|4.5|iteration so we only see the initial
537.36|4.74|loss which is 27.
540.12|3.719|so that's way too high and intuitively
542.1|4.32|now we can expect the variables involved
543.839|5.701|and we see that the logits here if we
546.42|4.919|just print some of these
549.54|3.18|if we just print the first row we see
551.339|2.401|that the load just take on quite extreme
552.72|3.059|values
553.74|4.44|and that's what's creating the fake
555.779|4.74|confidence and incorrect answers and
558.18|4.92|makes the loss
560.519|5.401|get very very high so these Lotus should
563.1|5.1|be much much closer to zero so now let's
565.92|4.74|think through how we can achieve logits
568.2|4.259|coming out of this neural net to be more
570.66|3.48|closer to zero
572.459|3.601|you see here that lodges are calculated
574.14|3.48|as the hidden States multiplied by W2
576.06|3.12|plus B2
577.62|5.339|so first of all currently we're
579.18|4.92|initializing B2 as random values of the
582.959|3.961|right size
584.1|4.2|but because we want roughly zero we
586.92|3.24|don't actually want to be adding a bias
588.3|4.02|of random numbers so in fact I'm going
590.16|5.88|to add a times a zero here to make sure
592.32|4.98|that B2 is just basically zero at the
596.04|4.56|initialization
597.3|5.58|and second this is H multiplied by W2 so
600.6|4.38|if we want logits to be very very small
602.88|4.079|then we would be multiplying W2 and
604.98|4.38|making that smaller
606.959|5.521|so for example if we scale down W2 by
609.36|4.8|0.1 all the elements then if I
612.48|3.539|do again just the very first iteration
614.16|4.14|you see that we are getting much closer
616.019|6.241|to what we expect so the rough roughly
618.3|7.26|what we want is about 3.29 this is 4.2
622.26|5.639|I can make this maybe even smaller
625.56|5.64|3.32 okay so we're getting closer and
627.899|5.161|closer now you're probably wondering can
631.2|3.72|we just set this to zero
633.06|4.92|then we get of course exactly what we're
634.92|5.34|looking for at initialization
637.98|4.799|and the reason I don't usually do this
640.26|4.5|is because I'm I'm very nervous and I'll
642.779|4.381|show you in a second why you don't want
644.76|5.28|to be setting W's or weights of a neural
647.16|4.5|net exactly to zero um you usually want
650.04|4.68|it to be small numbers instead of
651.66|4.859|exactly zero for this output layer in
654.72|3.78|this specific case I think it would be
656.519|3.781|fine but I'll show you in a second where
658.5|4.26|things go wrong very quickly if you do
660.3|4.5|that so let's just go with 0.01
662.76|4.98|in that case our loss is close enough
664.8|5.82|but has some entropy it's not exactly
667.74|4.32|zero it's got some low entropy and
670.62|2.88|that's used for symmetry breaking as
672.06|3.0|we'll see in a second
673.5|3.72|the logits are now coming out much
675.06|3.06|closer to zero and everything is well
677.22|5.16|and good
678.12|6.719|so if I just erase these and I now take
682.38|4.74|away the break statement
684.839|4.761|we can run the optimization with this
687.12|6.36|new initialization and let's just see
689.6|5.859|what losses we record okay so I let it
693.48|4.099|run and you see that we started off good
695.459|5.161|and then we came down a bit
697.579|5.44|the plot of the loss now doesn't have
700.62|4.38|this hockey shape appearance
703.019|4.021|um because basically what's happening in
705.0|3.66|the hockey stick the very first few
707.04|3.78|iterations of the loss what's happening
708.66|3.9|during the optimization is the
710.82|3.36|optimization is just squashing down the
712.56|4.32|logits and then it's rearranging the
714.18|4.92|logits so basically we took away this
716.88|3.66|easy part of the loss function where
719.1|2.58|just the the weights were just being
720.54|3.72|shrunk down
721.68|4.38|and so therefore we don't we don't get
724.26|2.819|these easy gains in the beginning and
726.06|2.7|we're just getting some of the hard
727.079|3.061|gains of training the actual neural nut
728.76|2.639|and so there's no hockey stick
730.14|3.48|appearance
731.399|4.141|so good things are happening in that
733.62|3.24|both number one lawsuit initialization
735.54|4.2|is what we expect
736.86|5.159|and the the loss doesn't look like a
739.74|4.2|hockey stick and this is true for any
742.019|3.421|neuron that you might train and
743.94|4.26|something to look out for
745.44|3.899|and second the last that came out is
748.2|3.18|actually quite a bit improved
749.339|4.461|unfortunately I erased what we had here
751.38|6.12|before I believe this was
753.8|6.46|2.12 and this is what this was 2.16 so
757.5|4.56|we get a slightly improved result and
760.26|3.68|the reason for that is uh because we're
762.06|3.92|spending more Cycles more time
763.94|4.78|optimizing the neural net actually
765.98|4.419|instead of just spending the first
768.72|4.32|several thousand iterations probably
770.399|4.74|just squashing down the weights
773.04|3.66|because they are so way too high in the
775.139|3.901|beginning in the initialization
776.7|4.199|so something to look out for and uh
779.04|3.84|that's number one now let's look at the
780.899|3.901|second problem let me re-initialize our
782.88|3.18|neural net and let me reintroduce the
784.8|4.02|break statement
786.06|3.899|so we have a reasonable initial loss so
788.82|2.519|even though everything is looking good
789.959|3.601|on the level of the loss and we get
791.339|3.781|something that we expect there's still a
793.56|3.839|deeper problem working inside this
795.12|5.159|neural net and its initialization
797.399|5.461|so the logits are now okay the problem
800.279|5.341|now is with the values of H
802.86|4.979|the activations of the Hidden States now
805.62|4.38|if we just visualize this Vector sorry
807.839|4.081|this tensor H it's kind of hard to see
810.0|4.2|but the problem here roughly speaking is
811.92|3.96|you see how many of the elements are one
814.2|4.5|or negative one
815.88|4.98|now recall that torch.nh the 10h
818.7|4.02|function is a squashing function it
820.86|3.24|takes arbitrary numbers and it squashes
822.72|3.419|them into a range of negative one and
824.1|4.08|one and it does so smoothly
826.139|4.081|so let's look at the histogram of H to
828.18|4.08|get a better idea of the distribution of
830.22|4.679|the values inside this tensor
832.26|5.699|we can do this first
834.899|6.18|well we can see that H is 32 examples
837.959|5.101|and 200 activations in each example we
841.079|5.161|can view it as negative one to stretch
843.06|6.42|it out into one large vector
846.24|6.18|and we can then call to list to convert
849.48|4.08|this into one large python list of
852.42|3.659|floats
853.56|5.94|and then we can pass this into plt.hist
856.079|5.94|for histogram and we say we want 50 bins
859.5|4.74|and a semicolon to suppress a bunch of
862.019|4.081|output we don't want
864.24|4.56|so we see this histogram and we see that
866.1|5.4|most the values by far take on the value
868.8|4.2|of negative one and one so this 10h is
871.5|4.26|very very active
873.0|4.74|and we can also look at
875.76|3.78|basically why that is
877.74|4.82|we can look at the pre-activations that
879.54|3.02|feed into the 10h
882.66|4.2|and we can see that the distribution of
884.459|4.141|the pre-activations are is very very
886.86|4.5|broad these take numbers between
888.6|4.679|negative 15 and 15 and that's why in the
891.36|3.24|torture 10h everything is being squashed
893.279|3.18|and capped to be in the range of
894.6|4.38|negative one and one and lots of numbers
896.459|4.62|here take on very extreme values
898.98|3.9|now if you are new to neural networks
901.079|3.781|you might not actually see this as an
902.88|3.959|issue but if you're well burst in the
904.86|3.779|dark arts back propagation and then have
906.839|3.721|an intuitive sense of how these
908.639|3.781|gradients flow through a neural net you
910.56|4.32|are looking at your distribution of 10h
912.42|4.68|activations here and you are sweating
914.88|3.42|so let me show you why we have to keep
917.1|3.299|in mind that during that propagation
918.3|3.899|just like we saw in micrograd we are
920.399|3.0|doing backward pass starting at the loss
922.199|3.481|and flowing through the network
923.399|5.161|backwards in particular we're going to
925.68|5.459|back propagate through this tors.10h
928.56|5.04|and this layer here is made up of 200
931.139|5.041|neurons for each one of these examples
933.6|4.979|and it implements an element twice 10 H
936.18|3.54|so let's look at what happens in 10h in
938.579|2.901|the backward pass
939.72|4.38|we can actually go back to our previous
941.48|5.26|micrograd code in the very first lecture
944.1|5.46|and see how we implement the 10h
946.74|4.92|we saw that the input here was X and
949.56|2.76|then we calculate T which is the 10h of
951.66|2.82|x
952.32|4.379|so that's T and T is between negative 1
954.48|3.599|and 1. it's the output of the 10h and
956.699|3.241|then in the backward pass how do we back
958.079|4.081|propagate through a 10 h
959.94|4.44|we take out that grad
962.16|4.2|and then we multiply it this is the
964.38|4.62|chain rule with the local gradient which
966.36|4.62|took the form of 1 minus t squared
969.0|4.32|so what happens if the outputs of your
970.98|4.68|10h are very close to negative one or
973.32|4.92|one if you plug in t equals one here
975.66|5.4|you're going to get a zero multiplying
978.24|5.339|out that grad no matter what up.grad is
981.06|4.139|we are killing the gradient and we're
983.579|3.781|stopping effectively the back
985.199|4.32|propagation through this 10h unit
987.36|4.26|similarly when T is negative one this
989.519|3.421|will again become zero and out that grad
991.62|3.18|just stops
992.94|4.5|and intuitively this makes sense because
994.8|5.279|this is a 10 H neuron
997.44|4.56|and what's happening is if its output is
1000.079|3.721|very close to one then we are in the
1002.0|6.959|tail of this 10 h
1003.8|7.26|and so changing basically the input
1008.959|4.8|is not going to impact the output of the
1011.06|5.04|10h too much because it's it's so it's
1013.759|4.26|in a flat region of the 10h and so
1016.1|6.06|therefore there's no impact on the loss
1018.019|6.241|and so indeed the the weights and the
1022.16|4.2|biases along with this tan H neuron do
1024.26|3.539|not impact the loss because the output
1026.36|2.939|of the standard unit is in the flat
1027.799|3.301|region in the 10h and there's no
1029.299|4.081|influence we can we can be changing them
1031.1|3.959|whatever we want however we want and the
1033.38|4.079|loss is not impacted that's that's
1035.059|4.321|another way to justify that indeed the
1037.459|3.301|gradient would be basically zero it
1039.38|4.919|vanishes
1040.76|7.86|indeed when T equals zero
1044.299|7.521|we get 1 times at that grad so when the
1048.62|6.24|10h takes on exactly value of zero then
1051.82|4.84|out.grad is just passed through
1054.86|4.74|so basically what this is doing right is
1056.66|5.58|if T is equal to zero then this the 10h
1059.6|5.52|unit is uh sort of inactive
1062.24|5.28|and uh gradient just passes through but
1065.12|4.32|the more you are in the flat tails the
1067.52|3.659|more the gradient is squashed
1069.44|4.02|so in fact you'll see that the the
1071.179|4.561|gradient flowing through 10 H can only
1073.46|6.18|ever decrease in the amount that it
1075.74|5.12|decreases is proportional through a
1079.64|3.419|square here
1080.86|4.059|depending on how far you are in the flat
1083.059|3.541|tails of this 10 age
1084.919|5.161|and so that's kind of what's Happening
1086.6|6.72|Here and through this the concern here
1090.08|4.74|is that if all of these outputs H are in
1093.32|3.54|the flat regions of negative one and one
1094.82|3.18|then the gradients that are flowing
1096.86|4.08|through the network will just get
1098.0|5.7|destroyed at this layer
1100.94|4.739|now there is some redeeming quality here
1103.7|3.96|and that we can actually get a sense of
1105.679|4.081|the problem here as follows
1107.66|3.66|I've wrote some code here and basically
1109.76|4.56|what we want to do here is we want to
1111.32|6.3|take a look at H take the absolute value
1114.32|7.92|and see how often it is in the in a flat
1117.62|7.14|region so say greater than 0.99
1122.24|5.22|and what you get is the following and
1124.76|4.98|this is a Boolean tensor so uh in the
1127.46|4.98|Boolean tensor you get a white if this
1129.74|4.08|is true and a black and this is false
1132.44|3.96|and so basically what we have here is
1133.82|5.46|the 32 examples and then 200 hidden
1136.4|5.399|neurons and we see that a lot of this is
1139.28|5.94|white and what that's telling us is that
1141.799|7.081|all these 10h neurons were very very
1145.22|7.319|active and uh they're in a flat tail
1148.88|5.039|and so in all these cases uh the back
1152.539|3.781|the backward gradient would get
1153.919|5.581|destroyed
1156.32|5.28|now we would be in a lot of trouble if
1159.5|4.919|for ever for any one of these 200
1161.6|5.34|neurons if it was the case that the
1164.419|4.021|entire column is white because in that
1166.94|3.359|case we have what's called a dead neuron
1168.44|3.06|and this could be a tannage neuron where
1170.299|3.481|the initialization of the weights and
1171.5|6.24|the biases could be such that no single
1173.78|6.6|example ever activates this 10h in the
1177.74|5.7|sort of active part of the 10h if all
1180.38|5.039|the examples land in the tail then this
1183.44|3.119|neuron will never learn it is a dead
1185.419|3.601|neuron
1186.559|4.921|and so just scrutinizing this and
1189.02|6.72|looking for Columns of completely white
1191.48|6.3|we see that this is not the case so I
1195.74|3.6|don't see a single neuron that is all of
1197.78|3.36|uh you know white
1199.34|4.5|and so therefore it is the case that for
1201.14|4.86|every one of these 10h neurons
1203.84|5.459|we do have some examples that activate
1206.0|4.86|them in the active part of the 10h and
1209.299|3.901|so some gradients will flow through and
1210.86|4.02|this neuron will learn and the neuron
1213.2|3.12|will change and it will move and it will
1214.88|3.48|do something
1216.32|4.26|but you can sometimes get yourself in
1218.36|4.8|cases where you have dead neurons and
1220.58|4.86|the way this manifests is that for 10
1223.16|3.899|inch neuron this would be when no matter
1225.44|3.54|what inputs you plug in from your data
1227.059|3.901|set this 10 inch neuron always fires
1228.98|3.74|completely one or completely negative
1230.96|4.02|one and then it will just not learn
1232.72|3.699|because all the gradients will be just
1234.98|3.3|zeroed out
1236.419|3.661|uh this is true not just percentage but
1238.28|3.42|for a lot of other non-linearities that
1240.08|4.02|people use in neural networks so we
1241.7|4.32|certainly use 10h a lot but sigmoid will
1244.1|4.319|have the exact same issue because it is
1246.02|5.039|a squashing neuron and so the same will
1248.419|5.76|be true for sigmoid but
1251.059|4.801|um but um you know
1254.179|3.721|um basically the same will actually
1255.86|4.679|applied to sigmoid the same will also
1257.9|5.519|reply to a relu so relu has a completely
1260.539|5.041|flat region here below zero
1263.419|3.721|so if you have a relative neuron then it
1265.58|4.44|is a pass-through
1267.14|4.56|um if it is positive and if it's if the
1270.02|3.96|pre-activation is negative it will just
1271.7|4.08|shut it off since the region here is
1273.98|4.74|completely flat then during back
1275.78|4.62|propagation uh this would be exactly
1278.72|3.54|zeroing out the gradient
1280.4|3.48|um like all of the gradient would be set
1282.26|3.299|exactly to zero instead of just like a
1283.88|4.5|very very small number depending on how
1285.559|4.74|positive or negative T is
1288.38|5.22|and so you can get for example a dead
1290.299|4.921|relu neuron and a dead relinuron would
1293.6|4.26|basically look like
1295.22|5.819|basically what it is is if a neuron with
1297.86|5.46|a relu nonlinearity never activates
1301.039|4.5|so for any examples that you plug in in
1303.32|4.5|the data set it never turns on it's
1305.539|4.201|always in this flat region then this
1307.82|4.5|reli neuron is a dead neuron it's
1309.74|3.96|weights and bias will never learn they
1312.32|3.3|will never get a gradient because the
1313.7|3.24|neuron never activated
1315.62|3.299|and this can sometimes happen at
1316.94|3.479|initialization because the weights and
1318.919|3.0|the biases just make it so that by
1320.419|2.281|chance some neurons are just forever
1321.919|2.041|dead
1322.7|3.54|but it can also happen during
1323.96|3.36|optimization if you have like a too high
1326.24|2.939|of the learning rate for example
1327.32|3.66|sometimes you have these neurons that
1329.179|4.441|gets too much of a gradient and they get
1330.98|5.1|knocked out off the data manifold
1333.62|4.439|and what happens is that from then on no
1336.08|3.78|example ever activates this neuron so
1338.059|3.36|this neuron remains that forever so it's
1339.86|3.9|kind of like a permanent brain damage in
1341.419|4.201|a in a mind of a network
1343.76|3.18|and so sometimes what can happen is if
1345.62|2.88|your learning rate is very high for
1346.94|3.719|example and you have a neural net with
1348.5|4.5|regular neurons you train the neural net
1350.659|4.321|and you get some last loss but then
1353.0|4.7|actually what you do is you go through
1354.98|5.579|the entire training set and you forward
1357.7|4.959|your examples and you can find neurons
1360.559|4.201|that never activate they are dead
1362.659|4.081|neurons in your network and so those
1364.76|3.06|neurons will will never turn on and
1366.74|2.7|usually what happens is that during
1367.82|3.54|training these relative neurons are
1369.44|3.9|changing moving Etc and then because of
1371.36|3.059|a high gradient somewhere by chance they
1373.34|3.36|get knocked off
1374.419|4.201|and then nothing ever activates them and
1376.7|3.54|from then on they are just dead
1378.62|3.24|uh so that's kind of like a permanent
1380.24|2.7|brain damage that can happen to some of
1381.86|3.36|these neurons
1382.94|3.96|these other nonlinearities like leaky
1385.22|3.18|relu will not suffer from this issue as
1386.9|4.68|much because you can see that it doesn't
1388.4|4.38|have flat tails you almost always get
1391.58|4.219|gradients
1392.78|5.22|and elu is also fairly frequently used
1395.799|4.36|it also might suffer from this issue
1398.0|4.38|because it has flat parts
1400.159|4.321|so that's just something to be aware of
1402.38|5.1|and something to be concerned about and
1404.48|5.16|in this case we have way too many
1407.48|4.98|um activations H that take on Extreme
1409.64|5.159|values and because there's no column of
1412.46|3.9|white I think we will be okay and indeed
1414.799|3.721|the network optimizes and gives us a
1416.36|3.78|pretty decent loss but it's just not
1418.52|3.18|optimal and this is not something you
1420.14|4.14|want especially during initialization
1421.7|5.16|and so basically what's happening is
1424.28|4.2|that this H pre-activation that's
1426.86|3.96|flowing to 10h
1428.48|4.679|it's it's too extreme it's too large
1430.82|4.26|it's creating very
1433.159|3.9|um it's creating a distribution that is
1435.08|3.719|too saturated in both sides of the 10h
1437.059|4.381|and it's not something you want because
1438.799|5.701|it means that there's less training uh
1441.44|5.28|for these neurons because they update
1444.5|5.34|um less frequently so how do we fix this
1446.72|6.66|well HP activation is
1449.84|5.699|MCAT which comes from C so these are
1453.38|5.52|uniform gaussian but then it's
1455.539|5.341|multiplied by W1 plus B1 and H preact is
1458.9|4.62|too far off from zero and that's causing
1460.88|4.56|the issue so we want this reactivation
1463.52|3.779|to be closer to zero very similar to
1465.44|4.619|what we have with lodges
1467.299|3.961|so here we want actually something very
1470.059|4.561|very similar
1471.26|4.86|now it's okay to set the biases to very
1474.62|3.0|small number we can either multiply it
1476.12|3.12|by zero zero one to get like a little
1477.62|3.84|bit of entropy
1479.24|4.14|um I sometimes like to do that
1481.46|3.48|um just so that
1483.38|3.679|there's like a little bit of variation
1484.94|4.859|and diversity in the original
1487.059|4.36|initialization of these 10h neurons and
1489.799|3.781|I find in practice that that can help
1491.419|4.321|optimization a little bit
1493.58|3.78|and then the weights we can also just
1495.74|3.36|like squash so let's multiply everything
1497.36|4.14|by 0.1
1499.1|5.16|let's rerun the first batch
1501.5|5.46|and now let's look at this and well
1504.26|4.5|first let's look here
1506.96|3.9|you see now because we multiply doubly
1508.76|3.659|by 0.1 we have a much better histogram
1510.86|4.319|and that's because the pre-activations
1512.419|6.061|are now between negative 1.5 and 1.5 and
1515.179|5.641|this we expect much much less white
1518.48|4.86|okay there's no white
1520.82|5.88|so basically that's because there are no
1523.34|5.339|neurons that's saturated above 0.99 in
1526.7|4.14|either direction this is actually a
1528.679|3.0|pretty decent place to be
1530.84|5.6|um
1531.679|4.761|maybe we can go up a little bit
1536.659|5.461|it's very much am I changing W1 here so
1539.48|5.52|maybe we can go to point two
1542.12|5.1|okay so maybe something like this is is
1545.0|4.5|a nice distribution so maybe this is
1547.22|4.199|what our initialization should be so let
1549.5|3.779|me now erase
1551.419|4.64|these
1553.279|5.821|and let me starting with initialization
1556.059|6.761|let me run the full optimization without
1559.1|6.059|the break and uh let's see what we got
1562.82|4.14|okay so the optimization finished and I
1565.159|3.9|Rebrand the loss and this is the result
1566.96|3.78|that we get and then just as a reminder
1569.059|3.301|I put down all the losses that we saw
1570.74|3.78|previously in this lecture
1572.36|3.72|so we see that we actually do get an
1574.52|3.6|improvement here and just as a reminder
1576.08|4.74|we started off with a validation loss of
1578.12|4.74|2.17 when we started by fixing the
1580.82|4.62|softmax being confidently wrong we came
1582.86|4.5|down to 2.13 and by fixing the 10h layer
1585.44|3.359|being way too saturated we came down to
1587.36|2.88|2.10
1588.799|2.76|and the reason this is happening of
1590.24|2.939|course is because our initialization is
1591.559|4.261|better and so we're spending more time
1593.179|3.36|doing productive training instead of
1595.82|2.76|um
1596.539|4.801|not very productive training because our
1598.58|4.86|gradients are set to zero and we have to
1601.34|3.66|learn very simple things like the
1603.44|3.18|overconfidence of the softmax in the
1605.0|3.9|beginning and we're spending Cycles just
1606.62|5.28|like squashing down the weight Matrix
1608.9|4.86|so this is illustrating
1611.9|4.68|um basically initialization and its
1613.76|4.56|impacts on performance just by being
1616.58|2.94|aware of the internals of these neural
1618.32|4.02|Nets and their activations their
1619.52|4.44|gradients now we're working with a very
1622.34|4.319|small Network this is just one layer
1623.96|4.5|multiplayer perceptron so because the
1626.659|3.9|network is so shallow the optimization
1628.46|3.839|problem is actually quite easy and very
1630.559|3.36|forgiving so even though our
1632.299|3.901|initialization was terrible the network
1633.919|4.981|still learned eventually it just got a
1636.2|4.339|bit worse result this is not the case in
1638.9|4.139|general though once we actually start
1640.539|5.5|working with much deeper networks that
1643.039|5.821|have say 50 layers things can get much
1646.039|4.26|more complicated and these problems
1648.86|4.26|Stack Up
1650.299|4.26|and so you can actually get into a place
1653.12|2.88|where the network is basically not
1654.559|4.141|training at all if your initialization
1656.0|3.96|is bad enough and the deeper your
1658.7|3.359|network is and the more complex it is
1659.96|4.5|the less forgiving it is to some of
1662.059|3.901|these errors and so
1664.46|3.9|um something that we definitely be aware
1665.96|4.319|of and uh something to scrutinize
1668.36|4.319|something to plot and something to be
1670.279|4.38|careful with and um
1672.679|4.261|yeah okay so that's great that that
1674.659|4.081|worked for us but what we have here now
1676.94|3.42|is all these metric numbers like point
1678.74|3.66|two like where do I come up with this
1680.36|3.419|and how am I supposed to set these if I
1682.4|2.7|have a large neural left with lots and
1683.779|3.421|lots of layers
1685.1|3.84|and so obviously no one does this by
1687.2|4.68|hand there's actually some relatively
1688.94|4.2|principled ways of setting these scales
1691.88|2.1|um that I would like to introduce to you
1693.14|2.82|now
1693.98|3.72|so let me paste some code here that I
1695.96|3.48|prepared just to motivate the discussion
1697.7|3.839|of this
1699.44|4.859|so what I'm doing here is we have some
1701.539|5.88|random input here x that is drawn from a
1704.299|5.161|gaussian and there's 1000 examples that
1707.419|4.5|are 10 dimensional and then we have a
1709.46|4.199|weight and layer here that is also
1711.919|2.701|initialized using gaussian just like we
1713.659|3.661|did here
1714.62|5.1|and we these neurons in the hidden layer
1717.32|4.979|look at 10 inputs and there are 200
1719.72|4.68|neurons in this hidden layer and then we
1722.299|4.141|have here just like here
1724.4|3.48|um in this case the multiplication X
1726.44|4.26|multiplied by W to get the
1727.88|4.919|pre-activations of these neurons
1730.7|4.2|and basically the analysis here looks at
1732.799|3.961|okay suppose these are uniform gaussian
1734.9|5.279|and these weights are uniform gaussian
1736.76|6.36|if I do x times W and we forget for now
1740.179|4.681|the bias and the non-linearity
1743.12|3.78|then what is the mean and the standard
1744.86|4.679|deviation of these gaussians
1746.9|4.44|so in the beginning here the input is uh
1749.539|3.781|just a normal gaussian distribution mean
1751.34|3.839|zero and the standard deviation is one
1753.32|5.099|and the standard deviation again is just
1755.179|5.1|a measure of a spread of discussion
1758.419|5.701|but then once we multiply here and we
1760.279|5.64|look at the histogram of Y we see that
1764.12|4.02|the mean of course stays the same it's
1765.919|3.901|about zero because this is a symmetric
1768.14|3.779|operation but we see here that the
1769.82|4.32|standard deviation has expanded to three
1771.919|4.921|so the input standard deviation was one
1774.14|3.899|but now we've grown to three and so what
1776.84|4.079|you're seeing in the histogram is that
1778.039|4.38|this gaussian is expanding
1780.919|4.081|and so
1782.419|4.62|um we're expanding this gaussian from
1785.0|3.419|the input and we don't want that we want
1787.039|4.201|most of the neural Nets to have
1788.419|4.801|relatively similar activations so unit
1791.24|4.02|gaussian roughly throughout the neural
1793.22|6.179|net and so the question is how do we
1795.26|7.2|scale these wfs to preserve the um to
1799.399|4.201|preserve this distribution to remain a
1802.46|4.38|gaussian
1803.6|5.76|and so intuitively if I multiply here uh
1806.84|4.86|these elements of w by a large number
1809.36|5.46|let's say by five
1811.7|5.459|then this gaussian grows and grows in
1814.82|4.38|standard deviation so now we're at 15.
1817.159|4.201|so basically these numbers here in the
1819.2|3.3|output y take on more and more extreme
1821.36|3.439|values
1822.5|5.46|but if we scale it down well I say 0.2
1824.799|6.041|then conversely this gaussian is getting
1827.96|4.319|smaller and smaller and it's shrinking
1830.84|4.02|and you can see that the standard
1832.279|5.341|deviation is 0.6 and so the question is
1834.86|4.98|what do I multiply by here to exactly
1837.62|3.24|preserve the standard deviation to be
1839.84|2.459|one
1840.86|3.0|and it turns out that the correct answer
1842.299|5.041|mathematically when you work out through
1843.86|6.24|the variance of this multiplication here
1847.34|6.24|is that you are supposed to divide by
1850.1|6.54|the square root of the fan in the fan in
1853.58|5.219|is the basically the uh number of input
1856.64|4.919|elements here 10. so we are supposed to
1858.799|4.26|divide by 10 square root and this is one
1861.559|4.081|way to do the square root you raise it
1863.059|4.081|to a power of 0.5 that's the same as
1865.64|4.38|doing a square root
1867.14|5.159|so when you divide by the square root of
1870.02|5.34|10 then we see that
1872.299|5.581|the output gaussian it has exactly
1875.36|4.38|standard deviation of one now
1877.88|4.38|unsurprisingly a number of papers have
1879.74|4.74|looked into how but to best initialize
1882.26|3.539|neural networks and in the case of
1884.48|3.0|multiplayer perceptions we can have
1885.799|4.141|fairly deep networks that have these
1887.48|3.96|nonlinearities in between and we want to
1889.94|3.119|make sure that the activations are well
1891.44|3.599|behaved and they don't expand to
1893.059|3.6|infinity or Shrink all the way to zero
1895.039|3.12|and the question is how do we initialize
1896.659|3.181|the weights so that these activations
1898.159|2.701|take on reasonable values throughout the
1899.84|3.24|network
1900.86|3.6|now one paper that has stuck this in
1903.08|3.3|quite a bit of detail that is often
1904.46|3.66|referenced is this paper by coming here
1906.38|3.899|at all called the delving deep into
1908.12|3.9|rectifiers now in this case they
1910.279|4.38|actually study convolutional neural
1912.02|5.1|networks and they studied especially the
1914.659|4.201|relu nonlinearity and the p-valued
1917.12|3.84|nonlinearity instead of a 10 H
1918.86|3.9|nonlinearity but the analysis is very
1920.96|4.56|similar and
1922.76|5.34|um basically what happens here is for
1925.52|4.74|them the the relation that they care
1928.1|4.92|about quite a bit here is a squashing
1930.26|6.06|function where all the negative numbers
1933.02|4.98|are simply clamped to zero so the
1936.32|4.14|positive numbers are passed through but
1938.0|4.44|everything negative is just set to zero
1940.46|3.599|and because uh you are basically
1942.44|4.14|throwing away half of the distribution
1944.059|4.141|they find in their analysis of the
1946.58|3.24|forward activations in the neural net
1948.2|3.78|that you have to compensate for that
1949.82|3.9|with a gain
1951.98|4.319|and so here
1953.72|4.02|they find that basically when they
1956.299|3.36|initialize their weights they have to do
1957.74|3.9|it with a zero mean gaussian whose
1959.659|3.661|standard deviation is square root of 2
1961.64|3.72|over the fan in
1963.32|4.5|what we have here is we are initializing
1965.36|3.48|a concussion with the square root of
1967.82|4.2|fanin
1968.84|5.52|this NL here is the Fanon so what we
1972.02|3.3|have is square root of one over the fan
1974.36|3.6|in
1975.32|4.62|because we have the division here
1977.96|4.02|now they have to add this factor of 2
1979.94|4.2|because of the relu which basically
1981.98|4.199|discards half of the distribution and
1984.14|3.72|clamps it at zero and so that's where
1986.179|4.021|you get an initial Factor
1987.86|4.919|now in addition to that this paper also
1990.2|4.079|studies not just the uh sort of behavior
1992.779|3.661|of the activations in the forward pass
1994.279|4.14|of the neural net but it also studies
1996.44|3.78|the back propagation and we have to make
1998.419|3.961|sure that the gradients also are well
2000.22|3.78|behaved and so
2002.38|3.299|um because ultimately they end up
2004.0|3.84|updating our parameters
2005.679|3.661|and what they find here through a lot of
2007.84|2.88|the analysis that I invite you to read
2009.34|4.38|through but it's not exactly
2010.72|4.92|approachable what they find is basically
2013.72|3.839|if you properly initialize the forward
2015.64|4.62|pass the backward pass is also
2017.559|4.921|approximately initialized up to a
2020.26|5.22|constant factor that has to do with the
2022.48|6.299|size of the number of hidden neurons in
2025.48|5.28|an early and uh late layer
2028.779|3.541|and uh but basically they find
2030.76|3.18|empirically that this is not a choice
2032.32|4.44|that matters too much
2033.94|5.119|now this timing initialization is also
2036.76|4.32|implemented in pytorch so if you go to
2039.059|3.34|torch.nn.net documentation you'll find
2041.08|3.12|timing normal
2042.399|3.541|and in my opinion this is probably the
2044.2|3.18|most common way of initializing neural
2045.94|3.179|networks now
2047.38|4.86|and it takes a few keyword arguments
2049.119|5.04|here so number one it wants to know the
2052.24|3.24|mode would you like to normalize the
2054.159|3.861|activations or would you like to
2055.48|5.399|normalize the gradients to to be always
2058.02|5.319|gaussian with zero mean and a unit or
2060.879|3.72|one standard deviation and because they
2063.339|2.82|find the paper that this doesn't matter
2064.599|4.02|too much most of the people just leave
2066.159|4.2|it as the default which is Fan in and
2068.619|3.78|then second passing the nonlinearity
2070.359|4.381|that you are using because depending on
2072.399|4.2|the nonlinearity we need to calculate a
2074.74|4.98|slightly different gain and so if your
2076.599|5.101|nonlinearity is just linear so there's
2079.72|4.32|no nonlinearity then the gain here will
2081.7|4.56|be one and we have the exact same uh
2084.04|3.54|kind of formula that we've got here
2086.26|2.52|but if the nonlinearity is something
2087.58|3.36|else we're going to get a slightly
2088.78|3.24|different gain and so if we come up here
2090.94|2.76|to the top
2092.02|4.079|we see that for example in the case of
2093.7|3.84|relu this gain is a square root of 2.
2096.099|4.701|and the reason it's a square root
2097.54|3.26|because in this paper
2102.82|5.16|you see how the two is inside of the
2105.58|3.36|square root so the gain is a square root
2107.98|4.32|of 2.
2108.94|5.399|in the case of linear or identity we
2112.3|4.08|just get a gain of one in the case of
2114.339|4.441|10h which is what we're using here the
2116.38|4.86|advised gain is a 5 over 3.
2118.78|4.799|and intuitively why do we need a gain on
2121.24|4.68|top of the initialization is because 10h
2123.579|4.741|just like relu is a contractive
2125.92|3.9|transformation so what that means is
2128.32|3.6|you're taking the output distribution
2129.82|4.019|from this matrix multiplication and then
2131.92|3.54|you are squashing it in some way now
2133.839|4.381|relu squashes it by taking everything
2135.46|4.26|below zero and clamping it to zero tan H
2138.22|3.06|also squashes it because it's a
2139.72|3.02|contractual operation it will take the
2141.28|4.26|Tails and it will
2142.74|5.5|squeeze them in and so in order to fight
2145.54|4.02|the squeezing in we need to boost the
2148.24|3.42|weights a little bit so that we
2149.56|3.84|renormalize everything back to standard
2151.66|3.66|unit standard deviation
2153.4|3.06|so that's why there's a little bit of a
2155.32|2.88|gain that comes out
2156.46|3.06|now I'm skipping through this section A
2158.2|3.18|little bit quickly and I'm doing that
2159.52|3.54|actually intentionally and the reason
2161.38|3.54|for that is because
2163.06|4.019|about seven years ago when this paper
2164.92|3.72|was written you had to actually be
2167.079|3.721|extremely careful with the activations
2168.64|3.9|and ingredients and their ranges and
2170.8|3.12|their histograms and you have to be very
2172.54|2.819|careful with the precise setting of
2173.92|3.48|gains and the scrutinizing of the
2175.359|3.781|nonlinearities used and so on and
2177.4|4.08|everything was very finicky and very
2179.14|4.02|fragile and very properly arranged for
2181.48|3.3|the neural not to train especially if
2183.16|2.699|your neural network was very deep
2184.78|2.28|but there are a number of modern
2185.859|3.0|innovations that have made everything
2187.06|3.539|significantly more stable and more
2188.859|3.421|well-behaved and has become less
2190.599|3.181|important to initialize these networks
2192.28|3.24|exactly right
2193.78|3.839|and some of those modern Innovations for
2195.52|4.62|example are residual connections which
2197.619|5.641|we will cover in the future the use of a
2200.14|5.16|number of normalization layers like for
2203.26|4.02|example batch normalization layer
2205.3|3.24|normalization group normalization we're
2207.28|3.36|going to go into a lot of these as well
2208.54|4.2|and number three much better optimizers
2210.64|3.84|not just stochastic gradient descent the
2212.74|3.66|simple Optimizer we're basically using
2214.48|4.26|here but a slightly more complex
2216.4|4.14|optimizers like RMS prop and especially
2218.74|4.14|Adam and so all of these modern
2220.54|3.66|Innovations make it less important for
2222.88|3.6|you to precisely calibrate the
2224.2|4.44|initialization of the neural net all
2226.48|4.139|that being said in practice uh what
2228.64|3.84|should we do in practice when I
2230.619|3.841|initialize these neural Nets I basically
2232.48|5.58|just normalize my weights by the square
2234.46|6.24|root of the fan in uh so basically uh
2238.06|4.38|roughly what we did here is what I do
2240.7|6.6|now if we want to be exactly accurate
2242.44|7.62|here we and go by init of coming normal
2247.3|4.2|this is how a good implemented we want
2250.06|3.9|to set the standard deviation to be
2251.5|5.88|gained over the square root of fan n
2253.96|5.879|right so to set the standard deviation
2257.38|3.78|of our weights we will proceed as
2259.839|3.361|follows
2261.16|3.84|basically when we have a torch that
2263.2|3.419|renin and let's say I just create a
2265.0|2.94|thousand numbers we can look at the
2266.619|3.24|standard deviation of this and of course
2267.94|3.3|that's one that's the amount of spread
2269.859|2.521|let's make this a bit bigger so it's
2271.24|4.08|closer to one
2272.38|5.64|so that's the spread of the gaussian of
2275.32|4.62|zero mean and unit standard deviation
2278.02|4.26|now basically when you take these and
2279.94|4.26|you multiply by say 0.2
2282.28|3.72|that basically scales down the gaussian
2284.2|4.08|and that makes its standard deviation
2286.0|3.78|0.2 so basically the number that you
2288.28|3.839|multiply by here ends up being the
2289.78|6.18|standard deviation of this caution
2292.119|7.081|so here this is a standard deviation 0.2
2295.96|4.619|gaussian here when we sample rw1
2299.2|4.379|but we want to set the standard
2300.579|5.461|deviation to gain over square root of
2303.579|4.941|fan mode which is valid
2306.04|8.28|so in other words we want to multiply by
2308.52|8.079|gain which for 10 H is 5 over 3.
2314.32|5.1|5 over 3 is the gain
2316.599|4.881|and then times
2319.42|2.06|um
2324.28|7.86|I guess sorry divide
2327.4|6.78|uh square root of the fan in and in this
2332.14|4.14|example here the fan in was 10 and I
2334.18|4.56|just noticed that actually here the fan
2336.28|4.5|in for W1 is actually an embed times
2338.74|4.14|block size which as you all recall is
2340.78|3.54|actually 30 and that's because each
2342.88|2.82|character is 10 dimensional but then we
2344.32|3.48|have three of them and we concatenate
2345.7|3.84|them so actually the fan in here was 30
2347.8|5.76|and I should have used 30 here probably
2349.54|5.94|but basically we want 30 square root so
2353.56|3.84|this is the number this is what our
2355.48|3.96|standard deviation we want to be and
2357.4|4.14|this number turns out to be 0.3
2359.44|3.3|whereas here just by fiddling with it
2361.54|3.24|and looking at the distribution and
2362.74|3.119|making sure it looks okay we came up
2364.78|2.88|with 0.2
2365.859|3.72|and so instead what we want to do here
2367.66|4.02|is we want to make the standard
2369.579|3.661|deviation B
2371.68|5.22|um
2373.24|5.82|5 over 3 which is our gain divide
2376.9|5.459|this amount
2379.06|5.58|times 0.2 square root and these brackets
2382.359|4.201|here are not that necessary but I'll
2384.64|3.479|just put them here for clarity this is
2386.56|4.44|basically what we want this is the
2388.119|5.101|chiming in it in our case for a 10h
2391.0|4.5|nonlinearity and this is how we would
2393.22|5.399|initialize the neural net and so we're
2395.5|5.4|multiplying by 0.3 instead of
2398.619|4.321|multiplying by 0.2
2400.9|4.8|and so we can
2402.94|4.44|we can initialize this way and then we
2405.7|2.34|can train the neural net and see what we
2407.38|2.4|got
2408.04|4.44|okay so I trained the neural net and we
2409.78|4.14|end up in roughly the same spot so
2412.48|4.44|looking at the validation loss we now
2413.92|4.679|get 2.10 and previously we also had 2.10
2416.92|3.179|and there's a little bit of a difference
2418.599|2.821|but that's just the randomness of the
2420.099|3.061|process I suspect
2421.42|4.32|but the big deal of course is we get to
2423.16|6.48|the same spot but we did not have to
2425.74|5.7|introduce any magic numbers that we got
2429.64|3.6|from just looking at histograms and
2431.44|4.2|guessing checking we have something that
2433.24|4.8|is semi-principled and will scale us to
2435.64|4.86|much bigger networks and uh something
2438.04|3.84|that we can sort of use as a guide so I
2440.5|3.48|mentioned that the precise setting of
2441.88|3.36|these initializations is not as
2443.98|3.06|important today due to some Modern
2445.24|3.0|Innovations and I think now is a pretty
2447.04|2.88|good time to introduce one of those
2448.24|2.879|modern Innovations and that is best
2449.92|4.26|normalization
2451.119|5.701|so batch normalization came out in 2015
2454.18|4.74|from a team at Google and it was an
2456.82|3.779|extremely impactful paper because it
2458.92|4.98|made it possible to train very deep
2460.599|5.041|neural Nets quite reliably and uh it
2463.9|2.88|basically just worked so here's what
2465.64|3.0|nationalization does and what's
2466.78|3.0|implemented
2468.64|4.02|um
2469.78|5.1|basically we have these hidden States HP
2472.66|4.58|act right and we were talking about how
2474.88|5.219|we don't want these uh these
2477.24|5.92|pre-activation states to be way too
2480.099|4.74|small because then the 10h is not doing
2483.16|3.24|anything but we don't want them to be
2484.839|2.581|too large because then the 10h is
2486.4|2.88|saturated
2487.42|4.56|in fact we want them to be roughly
2489.28|5.4|roughly gaussian so zero mean and a unit
2491.98|4.02|or one standard deviation at least at
2494.68|3.54|initialization
2496.0|4.079|so the Insight from The Bachelor
2498.22|4.02|normalization paper is okay you have
2500.079|4.561|these hidden States and you'd like them
2502.24|4.74|to be roughly gaussian then why not take
2504.64|5.04|the hidden States and just normalize
2506.98|4.26|them to be gaussian and it sounds kind
2509.68|5.34|of crazy but you can just do that
2511.24|6.0|because uh standardizing hidden States
2515.02|3.66|so that their unit caution is a
2517.24|3.24|perfectly differentiable operation as
2518.68|3.84|we'll soon see and so that was kind of
2520.48|3.78|like the big Insight in this paper and
2522.52|3.3|when I first read it my mind was blown
2524.26|3.3|because you can just normalize these
2525.82|4.62|hidden States and if you'd like unit
2527.56|4.799|gaussian States in your network at least
2530.44|5.04|initialization you can just normalize
2532.359|5.161|them to be in gaussian so let's see how
2535.48|3.72|that works so we're going to scroll to
2537.52|3.839|our pre-activations here just before
2539.2|3.72|they enter into the 10 age
2541.359|3.121|now the idea again is remember we're
2542.92|3.659|trying to make these roughly gaussian
2544.48|4.74|and that's because if these are way too
2546.579|5.101|small numbers then the 10h here is kind
2549.22|5.22|of connective but if these are very
2551.68|4.98|large numbers then the 10h is way too
2554.44|4.62|saturated and grade is in the flow so
2556.66|4.86|we'd like this to be roughly caution
2559.06|4.5|so the Insight in bathroomization again
2561.52|5.28|is that we can just standardize these
2563.56|6.24|activations so they are exactly gaussian
2566.8|6.42|so here hpact
2569.8|6.18|has a shape of 32 by 200 32 examples by
2573.22|4.26|200 neurons in the hidden layer
2575.98|3.72|so basically what we can do is we can
2577.48|3.139|take hpact and we can just calculate the
2579.7|3.78|mean
2580.619|4.661|and the mean we want to calculate across
2583.48|4.859|the zeroth dimension
2585.28|6.36|and we want to also keep them as true so
2588.339|5.161|that we can easily broadcast this
2591.64|4.74|so the shape of this
2593.5|5.94|is 1 by 200 in other words we are doing
2596.38|4.32|the mean over all the uh elements in the
2599.44|3.48|batch
2600.7|6.2|and similarly we can calculate the
2602.92|3.98|standard deviation of these activations
2606.94|5.22|and that will also be one by 200.
2609.339|6.121|now in this paper they have the
2612.16|5.1|uh sort of prescription here and see
2615.46|5.52|here we are calculating the mean which
2617.26|7.079|is just taking the average value
2620.98|5.099|of any neurons activation and then the
2624.339|2.48|standard deviation is basically kind of
2626.079|3.121|like
2626.819|4.601|this the measure of the spread that
2629.2|5.1|we've been using which is the distance
2631.42|7.199|of every one of these values away from
2634.3|7.74|the mean and that squared and averaged
2638.619|4.381|that's the that's the variance and then
2642.04|2.76|if you want to take the standard
2643.0|4.68|deviation you would square root the
2644.8|4.559|variance to get the standard deviation
2647.68|3.24|so these are the two that we're
2649.359|4.081|calculating and now we're going to
2650.92|4.439|normalize or standardize these X's by
2653.44|4.379|subtracting the mean and
2655.359|5.22|um dividing by the standard deviation
2657.819|5.28|so basically we're taking Edge preact
2660.579|5.061|and we subtract
2663.099|2.541|the mean
2669.46|4.8|and then we divide by the standard
2672.04|4.62|deviation
2674.26|4.079|this is exactly what these two STD and
2676.66|3.72|mean are calculating
2678.339|4.141|oops
2680.38|4.199|sorry this is the mean and this is the
2682.48|3.42|variance you see how the sigma is the
2684.579|3.301|standard deviation usually so this is
2685.9|4.98|Sigma Square which is variance is the
2687.88|4.62|square of the standard deviation
2690.88|3.54|so this is how you standardize these
2692.5|4.14|values and what this will do is that
2694.42|4.86|every single neuron now and its firing
2696.64|4.979|rate will be exactly unit gaussian on
2699.28|3.18|these 32 examples at least of this batch
2701.619|3.121|that's why it's called batch
2702.46|4.08|normalization we are normalizing these
2704.74|4.379|batches
2706.54|4.559|and then we could in principle train
2709.119|3.661|this notice that calculating the mean
2711.099|2.941|and the standard deviation these are
2712.78|3.059|just mathematical formulas they're
2714.04|3.36|perfectly differentiable all this is
2715.839|2.821|perfectly differentiable and we can just
2717.4|2.76|strain this
2718.66|4.679|the problem is you actually won't
2720.16|5.58|achieve a very good result with this and
2723.339|4.5|the reason for that is
2725.74|4.98|we want these to be roughly gaussian but
2727.839|4.921|only at initialization but we don't want
2730.72|4.619|these to be to be forced to be gaussian
2732.76|5.04|always we would actually We'll add the
2735.339|4.321|neural nuts to move this around to
2737.8|4.14|potentially make it more diffuse to make
2739.66|4.08|it more sharp to make some 10 H neurons
2741.94|4.08|maybe mean more trigger more trigger
2743.74|4.02|happy or less trigger happy so we'd like
2746.02|3.24|this distribution to move around and
2747.76|3.42|we'd like the back propagation to tell
2749.26|5.04|us how that distribution should move
2751.18|6.06|around and so in addition to this idea
2754.3|4.62|of standardizing the activations at any
2757.24|3.72|point in the network
2758.92|3.899|uh we have to also introduce this
2760.96|4.8|additional component in the paper
2762.819|4.201|here describe the scale and shift
2765.76|3.72|and so basically what we're doing is
2767.02|4.5|we're taking these normalized inputs and
2769.48|5.04|we are additionally scaling them by some
2771.52|6.18|gain and offsetting them by some bias to
2774.52|4.86|get our final output from this layer
2777.7|2.639|and so what that amounts to is the
2779.38|2.52|following
2780.339|3.541|we are going to allow a batch
2781.9|5.52|normalization gain
2783.88|6.0|to be initialized at just a once
2787.42|4.8|and the ones will be in the shape of 1
2789.88|5.34|by n hidden
2792.22|5.46|and then we also will have a b and bias
2795.22|5.22|which will be torched at zeros
2797.68|4.439|and it will also be of the shape n by 1
2800.44|3.06|by and hidden
2802.119|5.101|and then here
2803.5|7.619|the B and gain will multiply this
2807.22|5.7|and the BN bias will offset it here
2811.119|3.661|so because this is initialized to one
2812.92|5.28|and this to zero
2814.78|6.12|at initialization each neuron's firing
2818.2|4.56|values in this batch will be exactly
2820.9|3.84|unit gaussian and we'll have nice
2822.76|5.099|numbers no matter what the distribution
2824.74|5.22|of the hpact is coming in coming out it
2827.859|3.541|will be in gaussian for each neuron and
2829.96|3.659|that's roughly what we want at least at
2831.4|4.439|initialization
2833.619|4.081|um and then during optimization we'll be
2835.839|4.081|able to back propagate to be in game and
2837.7|4.44|being biased and change them so the
2839.92|4.32|network is given the full ability to do
2842.14|3.42|with this whatever it wants uh
2844.24|4.5|internally
2845.56|6.059|here we just have to make sure that we
2848.74|4.14|um include these in the parameters of
2851.619|4.081|the neural nut because they will be
2852.88|4.5|trained with back propagation
2855.7|5.6|so let's initialize this
2857.38|3.92|and then we should be able to train
2865.599|4.02|and then we're going to also
2867.64|4.199|copy this line
2869.619|4.441|which is the best normalization layer
2871.839|3.721|here on a single line of code and we're
2874.06|3.84|going to swing down here and we're also
2875.56|4.759|going to do the exact same thing at test
2877.9|2.419|time here
2881.5|5.4|so similar to training time we're going
2883.72|4.68|to normalize and then scale and that's
2886.9|3.78|going to give us our train and
2888.4|3.48|validation loss
2890.68|2.28|and we'll see in a second that we're
2891.88|2.459|actually going to change this a little
2892.96|2.58|bit but for now I'm going to keep it
2894.339|2.52|this way
2895.54|3.42|so I'm just going to wait for this to
2896.859|3.841|converge okay so I'll add the neural
2898.96|3.54|nuts to converge here and when we scroll
2900.7|4.919|down we see that our validation loss
2902.5|5.04|here is 2.10 roughly which I wrote down
2905.619|3.181|here and we see that this is actually
2907.54|3.539|kind of comparable to some of the
2908.8|4.44|results that we've achieved previously
2911.079|4.201|now I'm not actually expecting an
2913.24|3.24|improvement in this case and that's
2915.28|2.94|because we are dealing with a very
2916.48|4.98|simple neural nut that has just a single
2918.22|5.04|hidden layer so in fact in this very
2921.46|3.359|simple case of just one hidden layer we
2923.26|4.38|were able to actually calculate what the
2924.819|4.561|scale of w should be to make these
2927.64|3.66|pre-activations already have a roughly
2929.38|3.78|gaussian shape so the best normalization
2931.3|3.539|is not doing much here
2933.16|3.72|but you might imagine that once you have
2934.839|4.621|a much deeper neural nut that has lots
2936.88|3.84|of different types of operations and
2939.46|2.94|there's also for example residual
2940.72|4.08|connections which we'll cover and so on
2942.4|5.219|it will become basically very very
2944.8|4.86|difficult to tune those scales of your
2947.619|3.541|weight matrices such that all the
2949.66|3.06|activations throughout the neural Nets
2951.16|3.54|are roughly gaussian
2952.72|4.56|and so that's going to become very
2954.7|4.44|quickly intractable but compared to that
2957.28|3.36|it's going to be much much easier to
2959.14|2.939|sprinkle batch normalization layers
2960.64|4.32|throughout the neural net
2962.079|4.74|so in particular it's common to to look
2964.96|3.48|at every single linear layer like this
2966.819|3.901|one this is a linear layer multiplying
2968.44|4.32|by a weight Matrix and adding the bias
2970.72|4.74|or for example convolutions which we'll
2972.76|4.38|cover later and also perform basically a
2975.46|3.48|multiplication with the weight Matrix
2977.14|4.679|but in a more spatially structured
2978.94|4.379|format it's custom it's customary to
2981.819|4.681|take these linear layer or convolutional
2983.319|6.121|layer and append a bachelorization layer
2986.5|4.44|right after it to control the scale of
2989.44|3.419|these activations at every point in the
2990.94|3.48|neural net so we'd be adding these
2992.859|3.661|bathroom layers throughout the neural
2994.42|3.6|net and then this controls the scale of
2996.52|3.9|these activations throughout the neural
2998.02|4.68|net it doesn't require us to do a
3000.42|4.32|perfect mathematics and care about the
3002.7|3.96|activation distributions for all these
3004.74|3.18|different types of neural network Lego
3006.66|3.36|building blocks that you might want to
3007.92|4.32|introduce into your neural net and it
3010.02|4.2|significantly stabilizes uh the training
3012.24|3.96|and that's why these layers are quite
3014.22|3.66|popular now the stability offered by
3016.2|4.379|batch normalization actually comes at a
3017.88|3.84|terrible cost and that cost is that if
3020.579|3.901|you think about what's Happening Here
3021.72|4.619|something something terribly strange and
3024.48|4.26|unnatural is happening
3026.339|4.621|it used to be that we have a single
3028.74|4.5|example feeding into a neural net and
3030.96|5.159|then we calculate this activations and
3033.24|5.16|it's logits and this is a deterministic
3036.119|4.801|sort of process so you arrive at some
3038.4|4.679|Logics for this example and then because
3040.92|4.14|of efficiency of training we suddenly
3043.079|3.661|started to use batches of examples but
3045.06|3.299|those batches of examples were processed
3046.74|3.0|independently and it was just an
3048.359|3.24|efficiency thing
3049.74|3.359|but now suddenly in bash normalization
3051.599|3.621|because of the normalization through the
3053.099|4.441|batch we are coupling these examples
3055.22|4.24|mathematically and in the forward pass
3057.54|4.44|and the backward pass of the neural land
3059.46|5.52|so now the hidden State activations
3061.98|4.92|hpact and your logits for any one input
3064.98|4.379|example are not just a function of that
3066.9|4.38|example and its input but they're also a
3069.359|4.401|function of all the other examples that
3071.28|4.86|happen to come for a ride in that batch
3073.76|4.059|and these examples are sampled randomly
3076.14|3.06|and so what's happening is for example
3077.819|3.481|when you look at each preact that's
3079.2|4.619|going to feed into H the hidden State
3081.3|4.68|activations for for example for for any
3083.819|4.5|one of these input examples is going to
3085.98|4.26|actually change slightly depending on
3088.319|4.081|what other examples there are in a batch
3090.24|3.78|and and depending on what other examples
3092.4|4.32|happen to come for a ride
3094.02|4.02|H is going to change subtly and it's
3096.72|3.48|going to like Jitter if you imagine
3098.04|3.9|sampling different examples because the
3100.2|3.72|statistics of the mean and the standard
3101.94|3.96|deviation are going to be impacted
3103.92|4.62|and so you'll get a Jitter for H and
3105.9|4.38|you'll get a Jitter for logits
3108.54|4.86|and you think that this would be a bug
3110.28|5.339|or something undesirable but in a very
3113.4|5.159|strange way this actually turns out to
3115.619|4.98|be good in neural network training and
3118.559|3.78|as a side effect and the reason for that
3120.599|3.96|is that you can think of this as kind of
3122.339|3.541|like a regularizer because what's
3124.559|2.941|happening is you have your input and you
3125.88|4.02|get your age and then depending on the
3127.5|3.839|other examples this is generating a bit
3129.9|3.659|and so what that does is that it's
3131.339|3.901|effectively padding out any one of these
3133.559|3.901|input examples and it's introducing a
3135.24|3.66|little bit of entropy and
3137.46|3.24|um because of the padding out it's
3138.9|3.48|actually kind of like a form of data
3140.7|3.72|augmentation which we'll cover in the
3142.38|3.78|future and it's kind of like augmenting
3144.42|3.48|the input a little bit and it's
3146.16|3.899|jittering it and that makes it harder
3147.9|4.5|for the neural nuts to overfit to these
3150.059|4.141|concrete specific examples so by
3152.4|3.9|introducing all this noise it actually
3154.2|3.96|like Pats out the examples and it
3156.3|3.5|regularizes the neural net and that's
3158.16|3.6|one of the reasons why
3159.8|4.36|deceivingly as a second order effect
3161.76|5.04|this is actually a regularizer and that
3164.16|4.26|has made it harder for us to remove the
3166.8|3.36|use of batch normalization
3168.42|4.32|because basically no one likes this
3170.16|4.56|property that the the examples in the
3172.74|4.26|batch are coupled mathematically and in
3174.72|4.56|the forward pass and at least all kinds
3177.0|4.559|of like strange results uh we'll go into
3179.28|4.68|some of that in a second as well
3181.559|4.381|um and it leads to a lot of bugs and
3183.96|5.18|um and so on and so no one likes this
3185.94|5.399|property uh and so people have tried to
3189.14|3.76|deprecate the use of astronomization and
3191.339|3.121|move to other normalization techniques
3192.9|3.78|that do not couple the examples of a
3194.46|3.96|batch examples are layer normalization
3196.68|3.96|instance normalization group
3198.42|5.399|normalization and so on and we'll cover
3200.64|5.219|we'll cover some of these later
3203.819|3.841|um but basically long story short bash
3205.859|3.72|formalization was the first kind of
3207.66|4.26|normalization layer to be introduced it
3209.579|4.98|worked extremely well it happens to have
3211.92|3.899|this regularizing effect it stabilized
3214.559|3.241|training
3215.819|3.3|and people have been trying to remove it
3217.8|3.9|and move to some of the other
3219.119|4.921|normalization techniques but it's been
3221.7|4.139|hard because it just works quite well
3224.04|3.12|and some of the reason that it works
3225.839|3.24|quite well is again because of this
3227.16|3.899|regularizing effect and because of the
3229.079|3.961|because it is quite effective at
3231.059|3.121|controlling the activations and their
3233.04|2.88|distributions
3234.18|4.139|uh so that's kind of like the brief
3235.92|5.34|story of nationalization and I'd like to
3238.319|5.341|show you one of the other weird sort of
3241.26|3.839|outcomes of this coupling
3243.66|3.899|so here's one of the strange outcomes
3245.099|4.26|that I only glossed over previously
3247.559|3.181|when I was evaluating the loss on the
3249.359|3.121|validation side
3250.74|4.379|basically once we've trained a neural
3252.48|4.32|net we'd like to deploy it in some kind
3255.119|3.72|of a setting and we'd like to be able to
3256.8|4.5|feed in a single individual example and
3258.839|4.441|get a prediction out from our neural net
3261.3|3.96|but how do we do that when our neural
3263.28|3.6|net now in a forward pass estimates the
3265.26|3.299|statistics of the mean energy standard
3266.88|4.199|deviation of a batch the neural net
3268.559|3.961|expects badges as an input now so how do
3271.079|3.301|we feed in a single example and get
3272.52|3.9|sensible results out
3274.38|4.439|and so the proposal in the batch
3276.42|4.38|normalization paper is the following
3278.819|3.841|what we would like to do here is we
3280.8|6.299|would like to basically have a step
3282.66|6.84|after training that calculates and sets
3287.099|5.041|the bathroom mean and standard deviation
3289.5|4.619|a single time over the training set
3292.14|4.26|and so I wrote this code here in
3294.119|3.72|interest of time and we're going to call
3296.4|2.64|what's called calibrate the Bachelor of
3297.839|4.74|statistics
3299.04|5.88|and basically what we do is not no grad
3302.579|4.5|telling pytorch that none of this we
3304.92|3.84|will call the dot backward on and it's
3307.079|4.02|going to be a bit more efficient
3308.76|3.78|we're going to take the training set get
3311.099|3.601|the pre-activations for every single
3312.54|3.36|training example and then one single
3314.7|3.419|time estimate the mean and standard
3315.9|3.659|deviation over the entire training set
3318.119|3.24|and then we're going to get B and mean
3319.559|3.78|and be in standard deviation and now
3321.359|3.781|these are fixed numbers as the meaning
3323.339|4.441|of the entire training set
3325.14|4.62|and here instead of estimating it
3327.78|5.22|dynamically
3329.76|4.44|we are going to instead here use B and
3333.0|3.059|mean
3334.2|3.78|and here we're just going to use B and
3336.059|4.321|standard deviation
3337.98|4.26|and so at this time we are going to fix
3340.38|5.04|these clamp them and use them during
3342.24|5.28|inference and now
3345.42|3.179|you see that we get basically identical
3347.52|3.539|result
3348.599|4.081|but the benefit that we've gained is
3351.059|3.181|that we can now also forward a single
3352.68|3.54|example because the mean and standard
3354.24|3.06|deviation are now fixed uh sort of
3356.22|2.82|tensors
3357.3|3.059|that said nobody actually wants to
3359.04|4.38|estimate this mean and standard
3360.359|4.681|deviation as a second stage after neural
3363.42|4.199|network training because everyone is
3365.04|4.14|lazy and so this batch normalization
3367.619|3.901|paper actually introduced one more idea
3369.18|4.08|which is that we can we can estimate the
3371.52|4.5|mean and standard deviation in a running
3373.26|5.339|matter running manner during training of
3376.02|4.44|the neural net and then we can simply
3378.599|3.541|just have a single stage of training and
3380.46|3.42|on the side of that training we are
3382.14|3.24|estimating the running mean and standard
3383.88|2.699|deviation so let's see what that would
3385.38|3.54|look like
3386.579|3.901|let me basically take the mean here that
3388.92|3.54|we are estimating on the batch and let
3390.48|4.5|me call this B and mean on the I
3392.46|7.399|iteration
3394.98|4.879|um and then here this is B and sdd
3400.38|4.82|um bnstd at I okay
3406.4|7.719|uh and the mean comes here and the STD
3411.42|4.5|comes here so so far I've done nothing
3414.119|3.301|I've just moved around and I created
3415.92|3.419|these extra variables for the mean and
3417.42|4.439|standard deviation and I've put them
3419.339|3.661|here so so far nothing has changed but
3421.859|3.0|what we're going to do now is we're
3423.0|4.14|going to keep a running mean of both of
3424.859|4.321|these values during training so let me
3427.14|4.62|swing up here and let me create a BN
3429.18|6.72|mean underscore running
3431.76|6.839|and I'm going to initialize it at zeros
3435.9|6.98|and then be an STD running
3438.599|4.281|which I'll initialize at once
3443.04|3.12|because
3444.72|5.46|in the beginning because of the way we
3446.16|5.76|initialized W1 and B1 each react will be
3450.18|3.0|roughly unit gaussian so the mean will
3451.92|3.48|be roughly zero and the standard
3453.18|3.84|deviation roughly one so I'm going to
3455.4|3.959|initialize these that way
3457.02|4.7|but then here I'm going to update these
3459.359|5.101|and in pytorch
3461.72|4.72|these mean and standard deviation that
3464.46|3.48|are running they're not actually part of
3466.44|2.76|the gradient based optimization we're
3467.94|3.36|never going to derive gradients with
3469.2|4.26|respect to them they're they're updated
3471.3|3.779|on the side of training
3473.46|3.78|and so what we're going to do here is
3475.079|5.341|we're going to say with torch top no
3477.24|5.339|grad telling pytorch that the update
3480.42|3.54|here is not supposed to be building out
3482.579|2.701|a graph because there will be no doubt
3483.96|3.899|backward
3485.28|4.88|but this running is basically going to
3487.859|5.641|be 0.99
3490.16|8.14|times the current value
3493.5|6.72|plus 0.001 times the this value
3498.3|4.62|this new mean
3500.22|4.139|and in the same way be an STD running
3502.92|5.0|will be
3504.359|3.561|mostly what it used to be
3508.5|3.839|but it will receive a small update in
3510.66|4.32|the direction of what the current
3512.339|4.801|standard deviation is
3514.98|4.859|and as you're seeing here this update is
3517.14|5.1|outside and on the side of the gradient
3519.839|4.321|based optimization and it's simply being
3522.24|4.619|updated not using gradient descent it's
3524.16|4.159|just being updated using a gen key like
3526.859|3.421|Smooth
3528.319|4.841|sort of
3530.28|5.579|running mean manner
3533.16|4.38|and so while the network is training and
3535.859|3.661|these pre-activations are sort of
3537.54|4.5|changing and shifting around during back
3539.52|4.38|propagation we are keeping track of the
3542.04|4.319|typical mean and standard deviation and
3543.9|4.88|we're estimating them once and when I
3546.359|2.421|run this
3549.18|3.84|now I'm keeping track of this in a
3550.859|3.72|running manner and what we're hoping for
3553.02|3.059|of course is that the meat being mean
3554.579|3.78|underscore running and B and mean
3556.079|4.681|underscore STD are going to be very
3558.359|3.841|similar to the ones that we calculated
3560.76|3.24|here before
3562.2|3.96|and that way we don't need a second
3564.0|3.9|stage because we've sort of combined the
3566.16|3.179|two stages and we've put them on the
3567.9|2.58|side of each other if you want to look
3569.339|3.0|at it that way
3570.48|4.02|and this is how this is also implemented
3572.339|4.681|in the batch normalization layer in pi
3574.5|4.799|torch so during training
3577.02|3.66|um the exact same thing will happen and
3579.299|4.141|then later when you're using inference
3580.68|5.46|it will use the estimated running mean
3583.44|4.32|of both the mean estimate deviation of
3586.14|3.6|those hidden States
3587.76|3.839|so let's wait for the optimization to
3589.74|3.3|converge and hopefully the running mean
3591.599|3.181|and standard deviation are roughly equal
3593.04|4.559|to these two and then we can simply use
3594.78|4.86|it here and we don't need this stage of
3597.599|3.661|explicit calibration at the end okay so
3599.64|4.56|the optimization finished
3601.26|4.799|I'll rerun the explicit estimation and
3604.2|3.48|then the B and mean from the explicit
3606.059|3.54|estimation is here
3607.68|3.24|and B and mean from the running
3609.599|4.441|estimation
3610.92|5.28|during the during the optimization you
3614.04|5.4|can see it's very very similar
3616.2|6.84|it's not identical but it's pretty close
3619.44|6.84|in the same way be an STD is this and be
3623.04|5.22|an STD running is this
3626.28|4.26|as you can see that once again they are
3628.26|3.48|fairly similar values not identical but
3630.54|3.24|pretty close
3631.74|4.079|and so then here instead of being mean
3633.78|4.2|we can use the B and mean running
3635.819|3.901|instead of being STD we can use bnstd
3637.98|4.139|running
3639.72|4.619|and uh hopefully the validation loss
3642.119|4.98|will not be impacted too much
3644.339|5.341|okay so it's basically identical and
3647.099|4.141|this way we've eliminated the need for
3649.68|3.72|this explicit stage of calibration
3651.24|4.079|because we are doing it in line over
3653.4|3.6|here okay so we're almost done with
3655.319|3.421|batch normalization there are only two
3657.0|3.48|more notes that I'd like to make number
3658.74|3.72|one I've skipped a discussion over what
3660.48|4.26|is this plus Epsilon doing here this
3662.46|3.72|Epsilon is usually like some small fixed
3664.74|3.48|number for example one a negative five
3666.18|3.6|by default and what it's doing is that
3668.22|4.92|it's basically preventing a division by
3669.78|4.5|zero in the case that the variance over
3673.14|4.5|your batch
3674.28|4.98|is exactly zero in that case uh here we
3677.64|3.6|normally have a division by zero but
3679.26|3.359|because of the plus Epsilon this is
3681.24|3.119|going to become a small number in the
3682.619|4.261|denominator instead and things will be
3684.359|4.321|more well behaved so feel free to also
3686.88|3.419|add a plus Epsilon here of a very small
3688.68|3.36|number it doesn't actually substantially
3690.299|3.241|change the result I'm going to skip it
3692.04|2.88|in our case just because this is
3693.54|3.66|unlikely to happen in our very simple
3694.92|3.899|example here and the second thing I want
3697.2|4.44|you to notice is that we're being
3698.819|4.561|wasteful here and it's very subtle but
3701.64|3.719|right here where we are adding the bias
3703.38|4.26|into hpact
3705.359|4.621|these biases now are actually useless
3707.64|5.1|because we're adding them to the hpact
3709.98|4.8|but then we are calculating the mean
3712.74|4.74|for every one of these neurons and
3714.78|5.039|subtracting it so whatever bias you add
3717.48|3.18|here is going to get subtracted right
3719.819|2.641|here
3720.66|3.3|and so these biases are not doing
3722.46|3.48|anything in fact they're being
3723.96|3.78|subtracted out and they don't impact the
3725.94|3.6|rest of the calculation so if you look
3727.74|3.78|at b1.grad it's actually going to be
3729.54|4.14|zero because it's being subtracted out
3731.52|3.299|and doesn't actually have any effect
3733.68|3.06|and so whenever you're using batch
3734.819|4.081|normalization layers then if you have
3736.74|4.26|any weight layers before like a linear
3738.9|4.14|or a comma or something like that you're
3741.0|4.98|better off coming here and just like not
3743.04|5.94|using bias so you don't want to use bias
3745.98|5.52|and then here you don't want to add it
3748.98|4.379|because it's that spurious instead we
3751.5|4.559|have this vast normalization bias here
3753.359|4.74|and that bastionalization bias is now in
3756.059|4.621|charge of the biasing of this
3758.099|3.96|distribution instead of this B1 that we
3760.68|4.02|had here originally
3762.059|4.381|and so basically the rationalization
3764.7|4.08|layer has its own bias and there's no
3766.44|4.08|need to have a bias in the layer before
3768.78|3.12|it because that bias is going to be
3770.52|3.059|extracted up anyway
3771.9|3.3|so that's the other small detail to be
3773.579|3.901|careful with sometimes it's not going to
3775.2|4.26|do anything catastrophic this B1 will
3777.48|4.139|just be useless it will never get any
3779.46|4.02|gradient it will not learn it will stay
3781.619|4.44|constant and it's just wasteful but it
3783.48|4.859|doesn't actually really impact anything
3786.059|4.26|otherwise okay so I rearranged the code
3788.339|3.48|a little bit with comments and I just
3790.319|3.3|wanted to give a very quick summary of
3791.819|3.841|the bachelorization layer
3793.619|4.921|we are using batch normalization to
3795.66|3.899|control the statistics of activations in
3798.54|2.4|the neural net
3799.559|3.361|it is common to sprinkle batch
3800.94|4.2|normalization layer across the neural
3802.92|5.04|net and usually we will place it after
3805.14|4.74|layers that have multiplications like
3807.96|3.54|for example a linear layer or a
3809.88|3.179|convolutional layer which we may cover
3811.5|3.619|in the future
3813.059|6.181|now the batch normalization internally
3815.119|5.321|has parameters for the gain and the bias
3819.24|2.4|and these are trained using back
3820.44|4.98|propagation
3821.64|5.699|it also has two buffers the buffers are
3825.42|4.08|the mean and the standard deviation the
3827.339|3.48|running mean and the running mean of the
3829.5|2.88|standard deviation
3830.819|3.661|and these are not trained using back
3832.38|4.8|propagation these are trained using this
3834.48|4.379|janky update of kind of like a running
3837.18|2.879|mean update
3838.859|2.281|so
3840.059|3.3|um
3841.14|4.8|these are sort of the parameters and the
3843.359|4.5|buffers of bashram layer and then really
3845.94|3.419|what it's doing is it's calculating the
3847.859|3.72|mean and the standard deviation of the
3849.359|3.48|activations uh that are feeding into the
3851.579|3.181|bathroom layer
3852.839|4.26|over that batch
3854.76|4.98|then it's centering that batch to be
3857.099|5.46|unit gaussian and then it's offsetting
3859.74|4.26|and scaling it by the Learned bias and
3862.559|3.421|Gain
3864.0|3.42|and then on top of that it's keeping
3865.98|2.879|track of the mean and standard deviation
3867.42|3.84|of the inputs
3868.859|3.781|and it's maintaining this running mean
3871.26|3.359|and standard deviation
3872.64|4.26|and this will later be used at inference
3874.619|4.2|so that we don't have to re-estimate the
3876.9|3.899|meanest standard deviation all the time
3878.819|4.141|and in addition that allows us to
3880.799|3.481|basically forward individual examples at
3882.96|2.76|test time
3884.28|3.9|so that's the batch normalization layer
3885.72|3.839|it's a fairly complicated layer
3888.18|3.419|um but this is what it's doing
3889.559|3.661|internally now I wanted to show you a
3891.599|4.74|little bit of a real example
3893.22|5.52|so you can search resnet which is a
3896.339|4.02|residual neural network and these are
3898.74|3.24|context of neural networks used for
3900.359|3.781|image classification
3901.98|4.44|and of course we haven't come dresnets
3904.14|4.38|in detail so I'm not going to explain
3906.42|4.919|all the pieces of it but for now just
3908.52|4.5|note that the image feeds into a resnet
3911.339|4.201|on the top here and there's many many
3913.02|4.2|layers with repeating structure all the
3915.54|2.7|way to predictions of what's inside that
3917.22|2.82|image
3918.24|3.72|this repeating structure is made up of
3920.04|4.019|these blocks and these blocks are just
3921.96|3.54|sequentially stacked up in this deep
3924.059|4.56|neural network
3925.5|4.859|now the code for this the block
3928.619|4.561|basically that's used and repeated
3930.359|5.641|sequentially in series is called this
3933.18|4.74|bottleneck block bottleneck block
3936.0|4.02|and there's a lot here this is all
3937.92|3.54|pytorch and of course we haven't covered
3940.02|3.059|all of it but I want to point out some
3941.46|3.659|small pieces of it
3943.079|4.02|here in the init is where we initialize
3945.119|3.361|the neural net so this coded block here
3947.099|2.881|is basically the kind of stuff we're
3948.48|2.46|doing here we're initializing all the
3949.98|3.24|layers
3950.94|3.84|and in the forward we are specifying how
3953.22|4.2|the neural lot acts once you actually
3954.78|6.38|have the input so this code here is
3957.42|3.74|along the lines of what we're doing here
3961.559|5.341|and now these blocks are replicated and
3964.26|4.559|stacked up serially and that's what a
3966.9|5.3|residual Network would be
3968.819|6.0|and so notice what's happening here com1
3972.2|4.48|these are convolutional layers
3974.819|4.561|and these convolutional layers basically
3976.68|5.879|they're the same thing as a linear layer
3979.38|4.8|except convolutional layers don't apply
3982.559|3.24|um convolutional layers are used for
3984.18|3.72|images and so they have spatial
3985.799|4.56|structure and basically this linear
3987.9|3.78|multiplication and bias offset are done
3990.359|3.541|on patches
3991.68|4.56|instead of a math instead of the full
3993.9|4.679|input so because these images have
3996.24|5.22|structure spatial structure convolutions
3998.579|5.22|just basically do WX plus b but they do
4001.46|5.159|it on overlapping patches of the input
4003.799|4.861|but otherwise it's WX plus b
4006.619|3.48|then we have the norm layer which by
4008.66|3.48|default here is initialized to be a
4010.099|4.02|batch Norm in 2D so two-dimensional
4012.14|3.899|batch normalization layer
4014.119|5.341|and then we have a nonlinearity like
4016.039|6.481|relu so instead of uh here they use relu
4019.46|5.04|we are using 10h in this case
4022.52|3.9|but both both are just nonlinearities
4024.5|3.9|and you can just use them relatively
4026.42|4.08|interchangeably from very deep networks
4028.4|3.24|relu is typically empirically work a bit
4030.5|3.24|better
4031.64|3.78|so see the motif that's being repeated
4033.74|3.839|here we have convolution batch
4035.42|4.5|normalization convolution patch
4037.579|3.901|normalization early Etc and then here
4039.92|3.0|this is residual connection that we
4041.48|2.879|haven't covered yet
4042.92|4.379|but basically that's the exact same
4044.359|5.101|pattern we have here we have a weight
4047.299|5.641|layer like a convolution or like a
4049.46|6.48|linear layer batch normalization and
4052.94|5.04|then 10h which is a nonlinearity but
4055.94|4.2|basically a weight layer a normalization
4057.98|3.9|layer and a nonlinearity and that's the
4060.14|3.36|motif that you would be stacking up when
4061.88|4.32|you create these deep neural networks
4063.5|4.02|exactly as it's done here and one more
4066.2|3.419|thing I'd like you to notice is that
4067.52|5.039|here when they are initializing the comp
4069.619|4.74|layers like comp one by one the depth
4072.559|4.321|for that is right here
4074.359|3.901|and so it's initializing an nn.cap2d
4076.88|3.12|which is a convolutional layer in
4078.26|3.18|pytorch and there's a bunch of keyword
4080.0|3.66|arguments here that I'm not going to
4081.44|4.44|explain yet but you see how there's bias
4083.66|4.8|equals false the bicycles fall is
4085.88|5.34|exactly for the same reason as bias is
4088.46|5.099|not used in our case the CRI race to use
4091.22|4.2|a bias and these are bias is spurious
4093.559|3.78|because after this weight layer there's
4095.42|4.02|a bachelorization and the bachelor
4097.339|4.02|normalization subtracts that bias and
4099.44|3.48|then has its own bias so there's no need
4101.359|3.36|to introduce these spurious parameters
4102.92|2.759|it wouldn't hurt performance it's just
4104.719|3.661|useless
4105.679|4.801|and so because they have this motif of
4108.38|3.66|calf pasture and relu they don't need to
4110.48|3.0|buy us here because there's a bias
4112.04|2.58|inside here
4113.48|3.0|so
4114.62|4.559|by the way this example here is very
4116.48|5.759|easy to find just do resnet pie torch
4119.179|4.801|and uh it's this example here so this is
4122.239|4.5|kind of like the stock implementation of
4123.98|4.799|a residual neural network in pytorch and
4126.739|3.841|you can find that here but of course I
4128.779|3.661|haven't covered many of these parts yet
4130.58|4.32|and I would also like to briefly descend
4132.44|4.14|into the definitions of these pytorch
4134.9|3.48|layers and the parameters that they take
4136.58|4.38|now instead of a convolutional layer
4138.38|4.08|we're going to look at a linear layer
4140.96|3.359|uh because that's the one that we're
4142.46|4.14|using here this is a linear layer and I
4144.319|3.661|haven't covered convolutions yet but as
4146.6|4.619|I mentioned convolutions are basically
4147.98|6.359|linear layers except on patches
4151.219|4.98|so a linear layer performs a w x plus b
4154.339|3.84|except here they're calling the W A
4156.199|4.201|transpose
4158.179|4.14|um since is WX plus b very much
4160.4|4.02|like we did here to initialize this
4162.319|3.241|layer you need to know the fan in the
4164.42|3.72|fan out
4165.56|5.639|and that's so that they can initialize
4168.14|5.579|this W this is the fan in and the fan
4171.199|4.201|out so they know how how big the weight
4173.719|3.241|Matrix should be
4175.4|4.26|you need to also pass in whether you
4176.96|4.62|whether or not you want a bias and if
4179.66|4.44|you set it to false then no bias will be
4181.58|4.56|inside this layer
4184.1|3.96|um and you may want to do that exactly
4186.14|3.659|like in our case if your layer is
4188.06|3.659|followed by a normalization layer such
4189.799|3.54|as Bachelor
4191.719|2.761|so this allows you to basically disable
4193.339|2.701|bias
4194.48|3.54|now in terms of the initialization if we
4196.04|4.62|swing down here this is reporting the
4198.02|5.46|variables used inside this linear layer
4200.66|5.46|and our linear layer here has two
4203.48|4.02|parameters the weight and the bias in
4206.12|2.34|the same way they have a weight and a
4207.5|2.46|bias
4208.46|4.08|and they're talking about how they
4209.96|4.92|initialize it by default so by default
4212.54|3.78|python initialize your weights by taking
4214.88|4.74|the fan in
4216.32|4.44|and then doing one over Fannin square
4219.62|2.94|root
4220.76|3.84|and then instead of a normal
4222.56|3.179|distribution they are using a uniform
4224.6|3.72|distribution
4225.739|4.261|so it's very much the same thing but
4228.32|3.359|they are using a one instead of five
4230.0|4.02|over three so there's no gain being
4231.679|4.921|calculated here the gain is just one but
4234.02|4.74|otherwise it's exactly one over the
4236.6|3.72|square root of fan in exactly as we have
4238.76|4.56|here
4240.32|5.7|so 1 over the square root of K is the is
4243.32|3.839|the scale of the weights but when they
4246.02|3.06|are drawing the numbers they're not
4247.159|4.02|using a gaussian by default they're
4249.08|4.32|using a uniform distribution by default
4251.179|4.921|and so they draw uniformly from negative
4253.4|4.68|square root of K to square root of K
4256.1|4.74|but it's the exact same thing and the
4258.08|5.46|same motivation from for with respect to
4260.84|4.319|what we've seen in this lecture and the
4263.54|3.659|reason they're doing this is if you have
4265.159|4.741|a roughly gaussian input this will
4267.199|5.341|ensure that out of this layer you will
4269.9|5.04|have a roughly gaussian output and you
4272.54|5.159|you basically achieve that by scaling
4274.94|4.92|the weights by 100 square root of fan in
4277.699|4.5|so that's what this is doing
4279.86|4.02|and then the second thing is the battery
4282.199|3.96|normalization layer so let's look at
4283.88|4.02|what that looks like in pytorch
4286.159|3.481|so here we have a one-dimensional mesh
4287.9|2.88|normalization layer exactly as we are
4289.64|2.22|using here
4290.78|2.76|and there are a number of keyword
4291.86|2.819|arguments going into it as well
4293.54|4.199|so we need to know the number of
4294.679|4.5|features uh for us that is 200 and that
4297.739|4.44|is needed so that we can initialize
4299.179|5.881|these parameters here the gain the bias
4302.179|4.801|and the buffers for the running mean and
4305.06|3.48|standard deviation
4306.98|4.199|then they need to know the value of
4308.54|4.26|Epsilon here and by default this is one
4311.179|3.781|negative five you don't typically change
4312.8|4.8|this too much then they need to know the
4314.96|5.52|momentum and the momentum here as they
4317.6|4.2|explain is basically used for these uh
4320.48|2.28|running mean and running standard
4321.8|2.879|deviation
4322.76|4.02|so by default the momentum here is 0.1
4324.679|4.741|the momentum we are using here in this
4326.78|5.52|example is 0.001
4329.42|4.86|and basically rough you may want to
4332.3|3.899|change this sometimes and roughly
4334.28|2.879|speaking if you have a very large batch
4336.199|3.0|size
4337.159|3.06|then typically what you'll see is that
4339.199|2.221|when you estimate the mean and the
4340.219|2.94|standard deviation
4341.42|3.36|for every single batch size if it's
4343.159|2.821|large enough you're going to get roughly
4344.78|4.14|the same result
4345.98|4.98|and so therefore you can use slightly
4348.92|6.06|higher momentum like 0.1
4350.96|5.4|but for a batch size as small as 32 the
4354.98|2.759|mean understand deviation here might
4356.36|3.18|take on slightly different numbers
4357.739|3.42|because there's only 32 examples we are
4359.54|3.6|using to estimate the mean of standard
4361.159|4.681|deviation so the value is changing
4363.14|4.86|around a lot and if your momentum is 0.1
4365.84|3.72|that that might not be good enough for
4368.0|4.56|this value to settle
4369.56|4.38|and converge to the actual mean and
4372.56|2.52|standard deviation over the entire
4373.94|2.759|training set
4375.08|3.78|and so basically if your batch size is
4376.699|3.901|very small momentum of 0.1 is
4378.86|3.9|potentially dangerous and it might make
4380.6|4.079|it so that the running mean and standard
4382.76|3.3|deviation is thrashing too much during
4384.679|4.321|training and it's not actually
4386.06|5.099|converging properly
4389.0|4.44|uh Alpha and equals true determines
4391.159|5.52|whether dispatch normalization layer has
4393.44|6.18|these learnable affine parameters the uh
4396.679|4.681|the gain and the bias and this is almost
4399.62|3.66|always kept it true I'm not actually
4401.36|3.54|sure why you would want to change this
4403.28|3.12|to false
4404.9|3.72|um
4406.4|4.08|then track running stats is determining
4408.62|4.02|whether or not bachelorization layer of
4410.48|5.219|pytorch will be doing this
4412.64|5.76|and one reason you may you may want to
4415.699|4.621|skip the running stats is because you
4418.4|5.22|may want to for example estimate them at
4420.32|4.32|the end as a stage two like this and in
4423.62|2.4|that case you don't want the batch
4424.64|2.7|normalization layer to be doing all this
4426.02|2.699|extra compute that you're not going to
4427.34|3.899|use
4428.719|3.901|and finally we need to know which device
4431.239|4.261|we're going to run this batch
4432.62|4.559|normalization on a CPU or a GPU and what
4435.5|3.0|the data type should be uh half
4437.179|3.781|Precision single Precision double
4438.5|4.08|precision and so on
4440.96|3.3|so that's the batch normalization layer
4442.58|3.96|otherwise the link to the paper is the
4444.26|4.56|same formula we've implement it and
4446.54|4.26|everything is the same exactly as we've
4448.82|3.3|done here
4450.8|3.6|okay so that's everything that I wanted
4452.12|3.66|to cover for this lecture really what I
4454.4|3.24|wanted to talk about is the importance
4455.78|4.2|of understanding the activations and the
4457.64|4.079|gradients and their statistics in neural
4459.98|3.12|networks and this becomes increasingly
4461.719|4.02|important especially as you make your
4463.1|4.32|neural networks bigger larger and deeper
4465.739|3.841|we looked at the distributions basically
4467.42|4.259|at the output layer and we saw that if
4469.58|4.38|you have two confident mispredictions
4471.679|4.201|because the activations are too messed
4473.96|4.5|up at the last layer you can end up with
4475.88|4.2|these hockey stick losses and if you fix
4478.46|3.54|this you get a better loss at the end of
4480.08|3.78|training because your training is not
4482.0|3.36|doing wasteful work
4483.86|3.12|then we also saw that we need to control
4485.36|4.62|the activations we don't want them to
4486.98|5.04|you know squash to zero or explode to
4489.98|3.9|infinity and because that you can run
4492.02|4.139|into a lot of trouble with all of these
4493.88|3.359|non-linearities in these neural nuts and
4496.159|2.701|basically you want everything to be
4497.239|2.821|fairly homogeneous throughout the neural
4498.86|3.54|net you want roughly gaussian
4500.06|4.679|activations throughout the neural net
4502.4|5.04|let me talk about okay if we would
4504.739|4.801|roughly gaussian activations how do we
4507.44|3.66|scale these weight matrices and biases
4509.54|4.08|during initialization of the neural net
4511.1|5.94|so that we don't get um you know so
4513.62|5.52|everything is as controlled as possible
4517.04|4.38|um so that gave us a large boost in
4519.14|5.64|Improvement and then I talked about how
4521.42|5.4|that strategy is not actually uh
4524.78|5.16|possible for much much deeper neural
4526.82|4.62|Nets because when you have much deeper
4529.94|3.9|neural nuts with lots of different types
4531.44|4.739|of layers it becomes really really hard
4533.84|4.02|to precisely set the weights and the
4536.179|3.48|biases in such a way that the
4537.86|3.359|activations are roughly uniform
4539.659|3.601|throughout the neural net
4541.219|3.96|so then I introduced the notion of the
4543.26|4.14|normalization layer now there are many
4545.179|4.201|normalization layers that people use in
4547.4|3.839|practice batch normalization layer
4549.38|4.02|normalization constant normalization
4551.239|3.661|group normalization we haven't covered
4553.4|3.6|most of them but I've introduced the
4554.9|3.839|first one and also the one that I
4557.0|3.6|believe came out first and that's called
4558.739|3.601|batch normalization
4560.6|4.02|and we saw how batch normalization works
4562.34|4.8|this is a layer that you can sprinkle
4564.62|4.38|throughout your deep neural nut and the
4567.14|4.079|basic idea is if you want roughly
4569.0|4.98|gaussian activations well then take your
4571.219|5.94|activations and take the mean understand
4573.98|4.739|deviation and Center your data and you
4577.159|4.141|can do that because the centering
4578.719|4.5|operation is differentiable
4581.3|4.2|but and on top of that we actually had
4583.219|3.301|to add a lot of bells and whistles and
4585.5|2.46|that gave you a sense of the
4586.52|3.54|complexities of the patch normalization
4587.96|3.9|layer because now we're centering the
4590.06|4.08|data that's great but suddenly we need
4591.86|3.78|the gain and the bias and now those are
4594.14|3.48|trainable
4595.64|3.72|and then because we are coupling all the
4597.62|3.0|training examples now suddenly the
4599.36|4.02|question is how do you do the inference
4600.62|5.94|or to do to do the inference we need to
4603.38|6.18|now estimate these mean and standard
4606.56|5.639|deviation once or the entire training
4609.56|4.56|set and then use those at inference but
4612.199|3.901|then no one likes to do stage two so
4614.12|3.119|instead we fold everything into the
4616.1|3.599|batch normalization layer during
4617.239|3.901|training and try to estimate these in
4619.699|2.881|the running manner so that everything is
4621.14|2.76|a bit simpler
4622.58|3.119|and that gives us the batch
4623.9|4.74|normalization layer
4625.699|6.421|um and as I mentioned no one likes this
4628.64|6.0|layer it causes a huge amount of bugs
4632.12|5.7|um and intuitively it's because it is
4634.64|6.96|coupling examples in the forward pass of
4637.82|6.24|a neural net and I've shot myself in the
4641.6|4.38|foot with this layer over and over again
4644.06|3.96|in my life and I don't want you to
4645.98|4.259|suffer the same
4648.02|4.74|uh so basically try to avoid it as much
4650.239|3.96|as possible uh some of the other
4652.76|3.06|alternatives to these layers are for
4654.199|3.601|example group normalization or layer
4655.82|4.62|normalization and those have become more
4657.8|5.7|common uh in more recent deep learning
4660.44|4.56|but we haven't covered those yet but
4663.5|3.36|definitely batch normalization was very
4665.0|4.86|influential at the time when it came out
4666.86|4.5|in roughly 2015 because it was kind of
4669.86|5.819|the first time that you could train
4671.36|5.58|reliably uh much deeper neural nuts and
4675.679|3.661|fundamentally the reason for that is
4676.94|4.259|because this layer was very effective at
4679.34|3.72|controlling the statistics of the
4681.199|5.761|activations in a neural net
4683.06|5.639|so that's the story so far and um that's
4686.96|3.12|all I wanted to cover and in the future
4688.699|4.681|lectures hopefully we can start going
4690.08|4.8|into recurring neural Nets and recurring
4693.38|4.2|neural Nets as we'll see are just very
4694.88|4.98|very deep networks because you uh you
4697.58|4.619|unroll the loop and uh when you actually
4699.86|3.6|optimize these neurons and that's where
4702.199|2.281|a lot of this
4703.46|2.82|um
4704.48|4.259|analysis around the activation
4706.28|4.379|statistics and all these normalization
4708.739|4.621|layers will become very very important
4710.659|4.5|for a good performance so we'll see that
4713.36|4.2|next time
4715.159|4.861|okay so I lied I would like us to do one
4717.56|4.38|more summary here as a bonus and I think
4720.02|3.36|it's useful as to have one more summary
4721.94|3.239|of everything I've presented in this
4723.38|3.779|lecture but also I would like us to
4725.179|3.421|start by tortifying our code a little
4727.159|3.54|bit so it looks much more like what you
4728.6|3.9|would encounter in pi torch so you'll
4730.699|6.661|see that I will structure our code into
4732.5|7.32|these modules like a linear module and a
4737.36|4.56|bachelor module and I'm putting the code
4739.82|3.6|inside these modules so that we can
4741.92|3.18|construct neural networks very much like
4743.42|3.779|we would construct them in pytorch and I
4745.1|3.54|will go through this in detail so we'll
4747.199|4.141|create our neural net
4748.64|3.84|then we will do the optimization loop as
4751.34|2.64|we did before
4752.48|2.699|and then the one more thing that I want
4753.98|2.82|to do here is I want to look at the
4755.179|3.601|activation statistics both in the
4756.8|4.26|forward pass and in the backward pass
4758.78|4.14|and then here we have the evaluation and
4761.06|3.9|sampling just like before
4762.92|3.9|so let me rewind all the way up here and
4764.96|3.9|go a little bit slower
4766.82|4.8|so here I'm creating a linear layer
4768.86|4.379|you'll notice that torch.nn has lots of
4771.62|3.68|different types of layers and one of
4773.239|4.201|those layers is the linear layer
4775.3|3.82|linear takes a number of input features
4777.44|3.719|output features whether or not we should
4779.12|4.14|have bias and then the device that we
4781.159|4.981|want to place this layer on and the data
4783.26|4.68|type so I will omit these two but
4786.14|4.079|otherwise we have the exact same thing
4787.94|5.7|we have the fan in which is number of
4790.219|5.401|inputs fan out the number of outputs and
4793.64|3.72|whether or not we want to use a bias and
4795.62|4.14|internally inside this layer there's a
4797.36|4.799|weight and a bias if you like it
4799.76|5.58|it is typical to initialize the weight
4802.159|4.741|using say random numbers drawn from a
4805.34|4.08|gaussian and then here's the coming
4806.9|4.56|initialization that we've discussed
4809.42|3.84|already in this lecture and that's a
4811.46|4.08|good default and also the default that I
4813.26|5.04|believe python trees is and by default
4815.54|5.639|the bias is usually initialized to zeros
4818.3|5.22|now when you call this module this will
4821.179|3.601|basically calculate W Times X plus b if
4823.52|2.52|you have NB
4824.78|3.24|and then when you also call that
4826.04|4.98|parameters on this module it will return
4828.02|4.08|the tensors that are the parameters of
4831.02|2.94|this layer
4832.1|6.3|now next we have the bachelorization
4833.96|7.38|layer so I've written that here and this
4838.4|6.0|is very similar to Pi torch NN dot bash
4841.34|5.76|Norm 1D layer as shown here
4844.4|5.16|so I'm kind of taking these three
4847.1|4.02|parameters here the dimensionality the
4849.56|4.02|Epsilon that we'll use in the division
4851.12|4.2|and the momentum that we will use in
4853.58|4.68|keeping track of these running stats the
4855.32|4.56|running mean and the running variance
4858.26|3.419|um now pack torch actually takes quite a
4859.88|3.839|few more things but I'm assuming some of
4861.679|3.781|their settings so for us I find will be
4863.719|4.201|true that means that we will be using a
4865.46|4.38|gamma and beta after the normalization
4867.92|3.239|the track running stats will be true so
4869.84|3.359|we will be keeping track of the running
4871.159|3.301|mean and the running variance in the in
4873.199|4.321|the pattern
4874.46|5.64|our device by default is the CPU and the
4877.52|4.679|data type by default is a float
4880.1|4.68|float32.
4882.199|4.141|so those are the defaults otherwise we
4884.78|3.54|are taking all the same parameters in
4886.34|3.48|this bathroom layer so first I'm just
4888.32|3.54|saving them
4889.82|4.02|now here's something new there's a DOT
4891.86|3.48|training which by default is true in
4893.84|3.66|packtorch and then modules also have
4895.34|4.98|this attribute that training and that's
4897.5|4.679|because many modules and batch Norm is
4900.32|3.839|included in that have a different
4902.179|3.661|behavior of whether you are training
4904.159|3.721|your own lot and or whether you are
4905.84|3.96|running it in an evaluation mode and
4907.88|3.6|calculating your evaluation loss or
4909.8|2.939|using it for inference on some test
4911.48|3.36|examples
4912.739|3.661|and masterm is an example of this
4914.84|2.76|because when we are training we are
4916.4|2.4|going to be using the mean and the
4917.6|4.26|variance estimated from the current
4918.8|5.1|batch but during inference we are using
4921.86|4.62|the running mean and running variants
4923.9|4.62|and so also if we are training we are
4926.48|3.54|updating mean and variants but if we are
4928.52|3.12|testing then these are not being updated
4930.02|3.659|they're kept fixed
4931.64|4.559|and so this flag is necessary and by
4933.679|4.621|default true just like impact torch
4936.199|5.46|now the parameters investment 1D are the
4938.3|4.919|gamma and the beta here
4941.659|4.56|and then the running mean and running
4943.219|6.301|variants are called buffers in pytorch
4946.219|5.641|nomenclature and these buffers are
4949.52|5.1|trained using exponential moving average
4951.86|4.26|here explicitly and they are not part of
4954.62|3.24|the back propagation and stochastic
4956.12|4.079|gradient descent so they are not sort of
4957.86|4.08|like parameters of this layer and that's
4960.199|3.901|why when we calculate when we have a
4961.94|4.14|parameters here we only return gamma and
4964.1|3.66|beta we do not return the mean and the
4966.08|5.82|variance this is trained sort of like
4967.76|6.72|internally here every forward pass using
4971.9|4.92|exponential moving average
4974.48|4.92|so that's the initialization
4976.82|4.5|now in a forward pass if we are training
4979.4|4.68|then we use the mean and the variance
4981.32|4.44|estimated by the batch let me plot the
4984.08|4.2|paper here
4985.76|5.459|we calculate the mean and the variance
4988.28|4.74|now up above I was estimating the
4991.219|4.081|standard deviation and keeping track of
4993.02|3.9|the standard deviation here in the
4995.3|3.6|running standard deviation instead of
4996.92|4.44|running variance but let's follow the
4998.9|4.319|paper exactly here they calculate the
5001.36|3.72|variance which is the standard deviation
5003.219|4.02|squared and that's what's kept track of
5005.08|4.26|in the running variance instead of a
5007.239|4.081|running standard deviation
5009.34|3.96|uh but those two would be very very
5011.32|3.96|similar I believe
5013.3|5.58|if we are not training then we use
5015.28|5.939|running mean in various we normalize
5018.88|4.319|and then here I'm calculating the output
5021.219|4.141|of this layer and I'm also assigning it
5023.199|4.5|to an attribute called dot out
5025.36|5.22|now dot out is something that I'm using
5027.699|4.321|in our modules here this is not what you
5030.58|3.84|would find in pytorch we are slightly
5032.02|4.82|deviating from it I'm creating a DOT out
5034.42|4.799|because I would like to very easily
5036.84|4.06|maintain all those variables so that we
5039.219|4.141|can create statistics of them and plot
5040.9|4.319|them but Pi torch and modules will not
5043.36|3.48|have a data attribute
5045.219|3.541|then finally here we are updating the
5046.84|3.3|buffers using again as I mentioned
5048.76|3.84|exponential moving average
5050.14|4.62|uh provide given the provided momentum
5052.6|3.84|and importantly you'll notice that I'm
5054.76|4.2|using the torstart no grad context
5056.44|4.5|manager and I'm doing this because if we
5058.96|3.719|don't use this then pytorch will start
5060.94|4.32|building out an entire computational
5062.679|4.02|graph out of these tensors because it is
5065.26|3.54|expecting that we will eventually call
5066.699|3.601|it that backward but we are never going
5068.8|2.939|to be calling that backward on anything
5070.3|3.66|that includes running mean and running
5071.739|4.321|variance so that's why we need to use
5073.96|4.8|this contact manager so that we are not
5076.06|5.22|sort of maintaining them using all this
5078.76|3.84|additional memory so this will make it
5081.28|3.12|more efficient and it's just telling
5082.6|3.24|factors that will only know backward we
5084.4|3.299|just have a bunch of tensors we want to
5085.84|4.379|update them that's it
5087.699|4.681|and then we return
5090.219|4.46|okay now scrolling down we have the 10h
5092.38|5.7|layer this is very very similar to
5094.679|5.341|torch.10h and it doesn't do too much it
5098.08|5.46|just calculates 10h as you might expect
5100.02|5.139|so that's torch.nh and there's no
5103.54|3.78|parameters in this layer
5105.159|3.961|but because these are layers
5107.32|4.32|um it now becomes very easy to sort of
5109.12|3.74|like stack them up into basically just a
5111.64|4.019|list
5112.86|4.42|and we can do all the initializations
5115.659|4.201|that we're used to so we have the
5117.28|3.6|initial sort of embedding Matrix we have
5119.86|2.28|our layers and we can call them
5120.88|3.779|sequentially
5122.14|4.5|and then again with Trump shot no grad
5124.659|3.841|there's some initializations here so we
5126.64|4.2|want to make the output softmax a bit
5128.5|4.32|less confident like we saw and in
5130.84|4.26|addition to that because we are using a
5132.82|4.2|six layer multi-layer perceptron here so
5135.1|3.72|you see how I'm stacking linear 10 age
5137.02|4.62|linear 10h Etc
5138.82|4.02|I'm going to be using the game here and
5141.64|3.42|I'm going to play with this in a second
5142.84|4.379|so you'll see how when we change this
5145.06|4.08|what happens to the statistics
5147.219|4.201|finally the primers are basically the
5149.14|4.2|embedding Matrix and all the parameters
5151.42|4.259|in all the layers and notice here I'm
5153.34|4.2|using a double list comprehension if you
5155.679|4.141|want to call it that but for every layer
5157.54|3.78|in layers and for every parameter in
5159.82|3.96|each of those layers we are just
5161.32|3.6|stacking up all those piece all those
5163.78|5.64|parameters
5164.92|6.12|now in total we have 46 000 parameters
5169.42|4.819|and I'm telling by George that all of
5171.04|3.199|them require gradient
5175.96|5.46|then here we have everything here we are
5179.199|4.5|actually mostly used to we are sampling
5181.42|3.779|batch we are doing forward pass the
5183.699|3.661|forward pass now is just a linear
5185.199|4.141|application of all the layers in order
5187.36|3.359|followed by the cross entropy
5189.34|3.24|and then in the backward path you'll
5190.719|3.781|notice that for every single layer I now
5192.58|3.659|iterate over all the outputs and I'm
5194.5|2.82|telling pytorch to retain the gradient
5196.239|3.9|of them
5197.32|4.859|and then here we are already used to all
5200.139|4.201|the all the gradients set To None do the
5202.179|4.621|backward to fill in the gradients do an
5204.34|5.22|update using the caskaranian scent and
5206.8|4.68|then track some statistics and then I am
5209.56|4.2|going to break after a single iteration
5211.48|4.739|now here in this cell in this diagram
5213.76|3.84|I'm visualizing the histogram the
5216.219|3.541|histograms of the forward pass
5217.6|4.2|activations and I'm specifically doing
5219.76|4.979|it at the 10 inch layers
5221.8|4.439|so iterating over all the layers except
5224.739|5.281|for the very last one which is basically
5226.239|6.0|just the soft Max layer
5230.02|3.78|um if it is a 10 inch layer and I'm
5232.239|3.241|using a 10 inch layer just because they
5233.8|3.48|have a finite output negative one to one
5235.48|3.719|and so it's very easy to visualize here
5237.28|4.379|so you see negative one to one and it's
5239.199|5.04|a finite range and easy to work with
5241.659|5.161|I take the out tensor from that layer
5244.239|4.44|into T and then I'm calculating the mean
5246.82|3.72|the standard deviation and the percent
5248.679|3.06|saturation of t
5250.54|3.36|and the way I Define the percent
5251.739|4.5|saturation is that t dot absolute value
5253.9|5.04|is greater than 0.97 so that means we
5256.239|4.021|are here at the Tails of the 10h and
5258.94|2.94|remember that when we are in the Tails
5260.26|3.78|of the 10h that will actually stop
5261.88|3.54|gradients so we don't want this to be
5264.04|2.82|too high
5265.42|4.02|now
5266.86|4.62|here I'm calling torch.histogram and
5269.44|3.299|then I am plotting this histogram so
5271.48|2.82|basically what this is doing is that
5272.739|3.121|every different type of layer and they
5274.3|3.54|all have a different color we are
5275.86|4.98|looking at how many
5277.84|6.299|um values in these tensors take on any
5280.84|5.28|of the values Below on this axis here
5284.139|5.221|so the first layer is fairly saturated
5286.12|5.4|here at 20 so you can see that it's got
5289.36|4.26|Tails here but then everything sort of
5291.52|3.719|stabilizes and if we had more layers
5293.62|2.88|here it would actually just stabilize at
5295.239|4.201|around the standard deviation of about
5296.5|4.08|0.65 and the saturation would be roughly
5299.44|3.18|five percent
5300.58|4.139|and the reason that this stabilizes and
5302.62|4.98|gives us a nice distribution here is
5304.719|7.081|because gain is set to 5 over 3.
5307.6|6.36|now here this gain you see that by
5311.8|4.14|default we initialize with one over
5313.96|3.779|square root of fan in but then here
5315.94|3.36|during initialization I come in and I
5317.739|4.561|iterate all the layers and if it's a
5319.3|6.06|linear layer I boost that by the gain
5322.3|6.48|now we saw that one so basically if we
5325.36|6.72|just do not use a gain then what happens
5328.78|6.06|if I redraw this you will see that
5332.08|5.34|the standard deviation is shrinking and
5334.84|3.72|the saturation is coming to zero and
5337.42|4.08|basically what's happening is the first
5338.56|4.5|layer is you know pretty decent but then
5341.5|3.78|further layers are just kind of like
5343.06|3.78|shrinking down to zero and it's
5345.28|4.74|happening slowly but it's shrinking to
5346.84|5.339|zero and the reason for that is when you
5350.02|6.179|just have a sandwich of linear layers
5352.179|6.661|alone then a then initializing our
5356.199|4.561|weights in this manner we saw previously
5358.84|3.18|would have conserved the standard
5360.76|3.3|deviation of one
5362.02|4.44|but because we have this interspersed
5364.06|4.8|10h layers in there
5366.46|4.14|the Stanley layers are squashing
5368.86|3.779|functions and so they take your
5370.6|5.4|distribution and they slightly squash it
5372.639|6.801|and so some gain is necessary to keep
5376.0|6.659|expanding it to fight the squashing
5379.44|5.199|so it just turns out that 5 over 3 is a
5382.659|4.98|good value so if we have something too
5384.639|5.1|small like one we saw that things will
5387.639|4.681|come towards zero but if it's something
5389.739|4.561|too high let's do two
5392.32|3.98|then here we see that
5394.3|2.0|um
5396.52|3.6|well let me do something a bit more
5398.44|3.96|extreme because so it's a bit more
5400.12|3.9|visible let's try three
5402.4|3.779|okay so we see here that the saturations
5404.02|4.679|are trying to be way too large
5406.179|4.681|okay so three would create way too
5408.699|5.46|saturated activations
5410.86|6.12|so five over three is a good setting for
5414.159|5.161|a sandwich of linear layers with 10 inch
5416.98|4.5|activations and it roughly stabilizes
5419.32|3.12|the standard deviation at a reasonable
5421.48|3.179|point
5422.44|5.279|now honestly I have no idea where five
5424.659|3.661|over three came from in pytorch when we
5427.719|3.601|were looking at the coming
5428.32|5.76|initialization I see empirically that it
5431.32|4.44|stabilizes this sandwich of linear n10h
5434.08|3.96|and that the saturation is in a good
5435.76|4.26|range but I don't actually know this
5438.04|4.08|came out of some math formula I tried
5440.02|4.08|searching briefly for where this comes
5442.12|4.019|from but I wasn't able to find anything
5444.1|3.539|but certainly we see that empirically
5446.139|3.6|these are very nice ranges our
5447.639|4.801|saturation is roughly five percent which
5449.739|5.0|is a pretty good number and uh this is a
5452.44|4.68|good setting of The gain in this context
5454.739|4.781|similarly we can do the exact same thing
5457.12|4.92|with the gradients so here is a very
5459.52|3.84|same Loop if it's a 10h but instead of
5462.04|3.42|taking the layered that out I'm taking
5463.36|4.26|the grad and then I'm also showing the
5465.46|4.38|mean on the standard deviation and I'm
5467.62|3.599|plotting the histogram of these values
5469.84|4.26|and so you'll see that the gradient
5471.219|3.96|distribution is fairly reasonable and in
5474.1|2.76|particular what we're looking for is
5475.179|4.201|that all the different layers in this
5476.86|5.04|sandwich has roughly the same gradient
5479.38|4.859|things are not shrinking or exploding
5481.9|3.9|so we can for example come here and we
5484.239|6.081|can take a look at what happens if this
5485.8|4.52|gain was way too small so this was 0.5
5490.42|2.94|then you see the
5492.1|3.24|first of all the activations are
5493.36|3.6|shrinking to zero but also the gradients
5495.34|3.66|are doing something weird the gradient
5496.96|4.08|started out here and then now they're
5499.0|4.98|like expanding out
5501.04|5.34|and similarly if we for example have a
5503.98|4.38|too high again so like three
5506.38|3.66|then we see that also the gradients have
5508.36|3.96|there's some asymmetry going on where as
5510.04|4.44|you go into deeper and deeper layers the
5512.32|3.72|activations are also changing and so
5514.48|3.84|that's not what we want and in this case
5516.04|4.56|we saw that without the use of Bachelor
5518.32|4.56|as we are going through right now we
5520.6|5.16|have to very carefully set those gains
5522.88|4.92|to get nice activations in both the
5525.76|3.36|forward pass and the backward pass now
5527.8|3.419|before we move on to pasture
5529.12|3.48|normalization I would also like to take
5531.219|4.02|a look at what happens when we have no
5532.6|4.079|10h units here so erasing all the 10
5535.239|4.621|inch nonlinearities
5536.679|5.581|but keeping the gain at 5 over 3. we now
5539.86|3.24|have just a giant linear sandwich so
5542.26|1.919|let's see what happens to the
5543.1|3.66|activations
5544.179|4.441|as we saw before the correct gain here
5546.76|3.8|is one that is the standard deviation
5548.62|5.82|preserving gain so
5550.56|6.34|1.667 is too high and so what's going to
5554.44|5.04|happen now is the following
5556.9|4.68|I have to change this to be linear so we
5559.48|3.36|are because there's no more 10 inch
5561.58|4.44|layers
5562.84|5.52|and let me change this to linear as well
5566.02|4.74|so what we're seeing is
5568.36|6.12|um the activations started out on the
5570.76|5.22|blue and have by layer 4 become very
5574.48|3.179|diffuse so what's happening to the
5575.98|4.5|activations is this
5577.659|5.401|and with the gradients on the top layer
5580.48|5.4|the activation the gradient statistics
5583.06|4.98|are the purple and then they diminish as
5585.88|4.02|you go down deeper in the layers and so
5588.04|3.48|basically you have an asymmetry like in
5589.9|2.94|the neural net and you might imagine
5591.52|2.82|that if you have very deep neural
5592.84|4.62|networks say like 50 layers or something
5594.34|6.359|like that this just this is not a good
5597.46|5.34|place to be so that's why before bash
5600.699|5.46|normalization this was incredibly tricky
5602.8|4.919|to to set in particular if this is too
5606.159|3.241|large of a game this happens and if it's
5607.719|4.621|too little it can gain
5609.4|6.66|then this happens also the opposite of
5612.34|7.799|that basically happens here we have a um
5616.06|6.24|shrinking and a diffusion depending on
5620.139|3.781|which direction you look at it from
5622.3|3.0|and so certainly this is not what you
5623.92|4.5|want and in this case the correct
5625.3|4.5|setting of The gain is exactly one
5628.42|3.299|just like we're doing at initialization
5629.8|4.62|and then we see that
5631.719|5.281|the statistics for the forward and the
5634.42|4.92|backward pass are well behaved and so
5637.0|5.46|the reason I want to show you this is
5639.34|4.859|the basically like getting neuralness to
5642.46|3.54|train before these normalization layers
5644.199|3.54|and before the use of advanced
5646.0|3.78|optimizers like atom which we still have
5647.739|4.561|to cover and residual connections and so
5649.78|5.399|on training neurons basically look like
5652.3|4.14|this it's like a total Balancing Act you
5655.179|3.661|have to make sure that everything is
5656.44|3.48|precisely orchestrated and you have to
5658.84|3.06|care about the activations and the
5659.92|4.08|gradients and their statistics and then
5661.9|3.48|maybe you can train something but it was
5664.0|2.94|basically impossible to train very deep
5665.38|3.779|networks and this is fundamentally the
5666.94|5.16|reason for that you'd have to be very
5669.159|5.821|very careful with your initialization
5672.1|4.02|um the other point here is you might be
5674.98|3.3|asking yourself by the way I'm not sure
5676.12|5.579|if I covered this why do we need these
5678.28|5.16|10h layers at all why do we include them
5681.699|3.48|and then have to worry about the gain
5683.44|3.299|and uh the reason for that of course is
5685.179|2.46|that if you just have a stack of linear
5686.739|3.0|layers
5687.639|5.58|then certainly we're getting very easily
5689.739|5.161|nice activations and so on but this is
5693.219|3.48|just a massive linear sandwich and it
5694.9|3.36|turns out that it collapses to a single
5696.699|4.02|linear layer in terms of its
5698.26|4.26|representation power so if you were to
5700.719|3.181|plot the output as a function of the
5702.52|3.0|input you're just getting a linear
5703.9|3.42|function no matter how many linear
5705.52|4.02|layers you stack up you still just end
5707.32|5.1|up with a linear transformation all the
5709.54|5.82|W X Plus B's just collapse into a large
5712.42|4.98|WX plus b with slightly different W's as
5715.36|3.6|likely different B
5717.4|3.239|um but interestingly even though the
5718.96|4.32|forward pass collapses to just a linear
5720.639|5.701|layer because of back propagation and
5723.28|5.1|the Dynamics of the backward pass the
5726.34|4.14|optimization is really is not identical
5728.38|3.12|you actually end up with all kinds of
5730.48|1.739|interesting
5731.5|3.78|um
5732.219|4.561|Dynamics in the backward pass because of
5735.28|4.14|the uh the way the chain rule is
5736.78|5.22|calculating it and so optimizing a
5739.42|4.68|linear layer by itself and optimizing a
5742.0|3.36|sandwich of 10 millionaire layers in
5744.1|2.94|both cases those are just a linear
5745.36|2.879|transformation in the forward pass but
5747.04|3.3|the training Dynamics would be different
5748.239|5.161|and there's entire papers that analyze
5750.34|5.46|in fact like infinitely layered linear
5753.4|4.98|layers and so on and so there's a lot of
5755.8|4.02|things too that you can play with there
5758.38|3.72|uh but basically the technical
5759.82|3.72|linearities allow us to
5762.1|5.84|um
5763.54|8.159|turn this sandwich from just a linear
5767.94|6.279|function into a neural network that can
5771.699|3.901|in principle approximate any arbitrary
5774.219|3.181|function
5775.6|5.16|okay so now I've reset the code to use
5777.4|5.52|the linear 10h sandwich like before and
5780.76|4.5|I reset everything so the gains five
5782.92|4.319|over three we can run a single step of
5785.26|3.419|optimization and we can look at the
5787.239|3.241|activation statistics of the forward
5788.679|3.721|pass and the backward pass
5790.48|3.36|but I've added one more plot here that I
5792.4|2.7|think is really important to look at
5793.84|3.42|when you're training your neural nuts
5795.1|3.66|and to consider and ultimately what
5797.26|3.3|we're doing is we're updating the
5798.76|4.14|parameters of the neural net so we care
5800.56|3.84|about the parameters and their values
5802.9|2.88|and their gradients
5804.4|2.759|so here what I'm doing is I'm actually
5805.78|3.72|iterating over all the parameters
5807.159|4.801|available and then I'm only
5809.5|3.6|um restricting it to the two-dimensional
5811.96|3.12|parameters which are basically the
5813.1|4.8|weights of these linear layers and I'm
5815.08|5.159|skipping the biases and I'm skipping the
5817.9|4.44|um Gammas and the betas in the bathroom
5820.239|3.781|just for Simplicity
5822.34|3.18|but you can also take a look at those as
5824.02|4.86|well but what's happening with the
5825.52|4.98|weights is um instructive by itself
5828.88|4.62|so here we have all the different
5830.5|4.98|weights their shapes so this is the
5833.5|3.48|embedding layer the first linear layer
5835.48|3.3|all the way to the very last linear
5836.98|3.3|layer and then we have the mean the
5838.78|3.12|standard deviation of all these
5840.28|3.359|parameters
5841.9|3.18|the histogram and you can see that it
5843.639|3.301|actually doesn't look that amazing so
5845.08|3.24|there's some trouble in Paradise even
5846.94|3.12|though these gradients looked okay
5848.32|4.2|there's something weird going on here
5850.06|4.86|I'll get to that in a second and the
5852.52|4.679|last thing here is the gradient to data
5854.92|4.44|ratio so sometimes I like to visualize
5857.199|4.861|this as well because what this gives you
5859.36|4.98|a sense of is what is the scale of the
5862.06|4.5|gradient compared to the scale of the
5864.34|4.14|actual values and this is important
5866.56|3.38|because we're going to end up taking a
5868.48|3.54|step update
5869.94|4.779|that is the learning rate times the
5872.02|4.92|gradient onto the data and so the
5874.719|3.42|gradient has two large of magnitude if
5876.94|3.42|the numbers in there are too large
5878.139|3.481|compared to the numbers in data then
5880.36|3.839|you'd be in trouble
5881.62|5.22|but in this case the gradient to data is
5884.199|5.52|our loan numbers so the values inside
5886.84|5.879|grad are 1000 times smaller than the
5889.719|4.02|values inside data in these weights most
5892.719|3.48|of them
5893.739|4.381|now notably that is not true about the
5896.199|3.601|last layer and so the last layer
5898.12|3.36|actually here the output layer is a bit
5899.8|3.359|of a troublemaker in the way that this
5901.48|3.719|is currently arranged because you can
5903.159|5.941|see that the um
5905.199|6.061|the last layer here in pink takes on
5909.1|5.16|values that are much larger than some of
5911.26|5.399|the values inside
5914.26|3.899|um inside the neural net so the standard
5916.659|3.421|deviations are roughly 1 and negative
5918.159|4.621|three throughout except for the last
5920.08|4.74|last layer which actually has roughly
5922.78|4.439|one e negative two a standard deviation
5924.82|4.919|of gradients and so the gradients on the
5927.219|5.701|last layer are currently about 100 times
5929.739|6.121|greater sorry 10 times greater than all
5932.92|5.4|the other weights inside the neural nut
5935.86|4.2|and so that's problematic because in the
5938.32|3.96|simple stochastically in the sun setup
5940.06|4.38|you would be training this last layer
5942.28|3.48|about 10 times faster than you would be
5944.44|2.58|training the other layers at
5945.76|3.419|initialization
5947.02|3.9|now this actually like kind of fixes
5949.179|3.601|itself a little bit if you train for a
5950.92|5.219|bit longer so for example if I greater
5952.78|5.399|than 1000 only then do a break
5956.139|5.281|let me reinitialize and then let me do
5958.179|5.821|it 1000 steps and after 1000 steps we
5961.42|4.739|can look at the forward pass
5964.0|4.5|okay so you see how the neurons are a
5966.159|4.441|bit are saturating a bit and we can also
5968.5|4.26|look at the backward pass but otherwise
5970.6|3.66|they look good they're about equal and
5972.76|3.3|there's no shrinking to zero or
5974.26|4.08|exploding to infinities
5976.06|4.32|and you can see that here in the weights
5978.34|4.799|things are also stabilizing a little bit
5980.38|4.56|so the Tails of the last pink layer are
5983.139|3.121|actually coming down coming in during
5984.94|3.0|the optimization
5986.26|3.84|but certainly this is like a little bit
5987.94|3.42|of troubling especially if you are using
5990.1|3.18|a very simple update rule like
5991.36|3.779|stochastic gradient descent instead of a
5993.28|3.48|modern Optimizer like Adam
5995.139|2.821|now I'd like to show you one more plot
5996.76|3.84|that I usually look at when I train
5997.96|4.32|neural networks and basically the
6000.6|3.72|gradient to data ratio is not actually
6002.28|3.359|that informative because what matters at
6004.32|4.02|the end is not the gradient to date
6005.639|4.321|ratio but the update to the data ratio
6008.34|3.24|because that is the amount by which we
6009.96|2.88|will actually change the data in these
6011.58|3.599|tensors
6012.84|4.56|so coming up here what I'd like to do is
6015.179|4.56|I'd like to introduce a new update to
6017.4|3.6|data ratio
6019.739|3.301|it's going to be less than we're going
6021.0|3.719|to build it out every single iteration
6023.04|2.639|and here I'd like to keep track of
6024.719|2.881|basically
6025.679|4.381|the ratio
6027.6|3.84|every single iteration
6030.06|4.38|so
6031.44|4.98|without any gradients I'm comparing the
6034.44|4.38|update which is learning rate times the
6036.42|3.719|times the gradient
6038.82|3.359|that is the update that we're going to
6040.139|3.661|apply to every parameter
6042.179|3.121|social Mediterranean or all the
6043.8|2.82|parameters and then I'm taking the
6045.3|3.78|basically standard deviation of the
6046.62|6.84|update we're going to apply and divide
6049.08|5.76|it by the actual content the data of
6053.46|2.58|that parameter and its standard
6054.84|3.78|deviation
6056.04|5.099|so this is the ratio of basically how
6058.62|3.66|great are the updates to the values in
6061.139|2.641|these tensors
6062.28|4.26|then we're going to take a log of it and
6063.78|3.6|actually I'd like to take a log 10.
6066.54|4.08|um
6067.38|4.2|just so it's a nicer visualization so
6070.62|4.039|we're going to be basically looking at
6071.58|6.119|the exponents of the
6074.659|5.321|of this division here and then that item
6077.699|3.54|to pop out the float and we're going to
6079.98|3.06|be keeping track of this for all the
6081.239|2.94|parameters and adding it to this UD
6083.04|3.24|tensor
6084.179|3.361|so now let me reinitialize and run a
6086.28|4.74|thousand iterations
6087.54|5.639|we can look at the activations the
6091.02|4.26|gradients and the parameter gradients as
6093.179|4.261|we did before but now I have one more
6095.28|3.6|plot here to introduce
6097.44|3.42|now what's happening here is where every
6098.88|3.839|interval go to parameters and I'm
6100.86|3.779|constraining it again like I did here to
6102.719|3.96|just the weights
6104.639|3.901|so the number of dimensions in these
6106.679|5.761|sensors is two and then I'm basically
6108.54|5.88|plotting all of these update ratios over
6112.44|4.14|time
6114.42|3.9|so when I plot this
6116.58|3.119|I plot those ratios and you can see that
6118.32|3.24|they evolve over time during
6119.699|3.54|initialization to take on certain values
6121.56|3.179|and then these updates sort of like
6123.239|2.521|start stabilizing usually during
6124.739|2.521|training
6125.76|2.879|then the other thing that I'm plotting
6127.26|3.479|here is I'm plotting here like an
6128.639|4.621|approximate value that is a Rough Guide
6130.739|3.9|for what it roughly should be and it
6133.26|2.1|should be like roughly one in negative
6134.639|3.0|three
6135.36|4.799|and so that means that basically there's
6137.639|4.5|some values in this tensor
6140.159|3.301|um and they take on certain values and
6142.139|4.5|the updates to them at every single
6143.46|5.94|iteration are no more than roughly 1 000
6146.639|5.821|of the actual like magnitude in those
6149.4|5.339|tensors uh if this was much larger like
6152.46|2.94|for example if this was
6154.739|2.521|um
6155.4|3.54|if the log of this was like say negative
6157.26|3.6|one this is actually updating those
6158.94|3.12|values quite a lot they're undergoing a
6160.86|3.6|lot of change
6162.06|4.92|but the reason that the final rate the
6164.46|4.62|final layer here is an outlier is
6166.98|5.4|because this layer was artificially
6169.08|5.28|shrunk down to keep the soft max income
6172.38|3.779|unconfident
6174.36|3.359|so here
6176.159|2.821|you see how we multiply The Weight by
6177.719|3.241|point one
6178.98|4.98|uh in the initialization to make the
6180.96|5.94|last layer prediction less confident
6183.96|4.98|that made that artificially made the
6186.9|4.02|values inside that tensor way too low
6188.94|3.96|and that's why we're getting temporarily
6190.92|4.86|a very high ratio but you see that that
6192.9|4.98|stabilizes over time once that weight
6195.78|3.6|starts to learn starts to learn
6197.88|4.02|but basically I like to look at the
6199.38|4.56|evolution of this update ratio for all
6201.9|4.98|my parameters usually and I like to make
6203.94|5.34|sure that it's not too much above
6206.88|5.1|wanting negative three roughly
6209.28|3.66|uh so around negative three on this log
6211.98|2.58|plot
6212.94|3.0|if it's below negative three usually
6214.56|2.76|that means that the parameters are not
6215.94|2.94|training fast enough
6217.32|4.02|so if our learning rate was very low
6218.88|5.04|let's do that experiment
6221.34|4.799|let's initialize and then let's actually
6223.92|3.6|do a learning rate of say y negative
6226.139|3.361|three here
6227.52|5.599|so 0.001
6229.5|3.619|if you're learning rate is way too low
6233.699|5.581|this plot will typically reveal it
6236.4|5.16|so you see how all of these updates are
6239.28|6.379|way too small so the size of the update
6241.56|7.38|is basically uh 10 000 times
6245.659|5.321|in magnitude to the size of the numbers
6248.94|3.84|in that tensor in the first place so
6250.98|3.48|this is a symptom of training way too
6252.78|3.54|slow
6254.46|3.179|so this is another way to sometimes set
6256.32|3.12|the learning rate and to get a sense of
6257.639|3.0|what that learning rate should be and
6259.44|4.16|ultimately this is something that you
6260.639|2.961|would keep track of
6264.9|5.04|if anything the learning rate here is a
6268.02|3.42|little bit on the higher side because
6269.94|3.66|you see that
6271.44|3.239|um we're above the black line of
6273.6|4.5|negative three we're somewhere around
6274.679|4.921|negative 2.5 it's like okay and uh but
6278.1|3.119|everything is like somewhat stabilizing
6279.6|2.94|and so this looks like a pretty decent
6281.219|3.301|setting of of
6282.54|3.54|um learning rates and so on but this is
6284.52|3.3|something to look at and when things are
6286.08|4.26|miscalibrated you will you will see very
6287.82|4.02|quickly so for example
6290.34|3.48|everything looks pretty well behaved
6291.84|3.48|right but just as a comparison when
6293.82|3.6|things are not properly calibrated what
6295.32|5.339|does that look like let me come up here
6297.42|4.14|and let's say that for example uh what
6300.659|3.48|do we do
6301.56|4.92|let's say that we forgot to apply this
6304.139|3.721|fan in normalization so the weights
6306.48|2.94|inside the linear layers are just a
6307.86|2.7|sample for my gaussian in all those
6309.42|3.42|stages
6310.56|3.72|what happens to our how do we notice
6312.84|3.359|that something's off
6314.28|3.8|well the activation plot will tell you
6316.199|4.081|whoa your neurons are way too saturated
6318.08|2.92|the gradients are going to be all messed
6320.28|2.459|up
6321.0|4.5|the histogram for these weights are
6322.739|4.92|going to be all messed up as well and
6325.5|3.78|there's a lot of asymmetry and then if
6327.659|4.441|we look here I suspect it's all going to
6329.28|5.459|be also pretty messed up so you see
6332.1|4.8|there's a lot of discrepancy in how fast
6334.739|4.38|these layers are learning and some of
6336.9|4.92|them are learning way too fast so
6339.119|4.201|negative one negative 1.5 those aren't
6341.82|3.48|very large numbers in terms of this
6343.32|3.54|ratio again you should be somewhere
6345.3|5.46|around negative three and not much more
6346.86|5.22|about that so this is how miscalibration
6350.76|3.419|so if your neural nuts are going to
6352.08|3.84|manifest and these kinds of plots here
6354.179|4.5|are a good way of
6355.92|5.759|um sort of bringing those
6358.679|4.98|miscalibrations sort of uh
6361.679|4.321|to your attention and so you can address
6363.659|4.98|them okay so so far we've seen that when
6366.0|4.26|we have this linear 10h sandwich we can
6368.639|3.721|actually precisely calibrate the gains
6370.26|4.2|and make the activations the gradients
6372.36|4.02|and the parameters and the updates all
6374.46|4.44|look pretty decent but it definitely
6376.38|5.22|feels a little bit like balancing
6378.9|4.58|of a pencil on your finger and that's
6381.6|4.26|because this gain has to be very
6383.48|3.46|precisely calibrated
6385.86|2.7|so now let's introduce batch
6386.94|4.38|normalization layers into the fix into
6388.56|5.28|the mix and let's let's see how that
6391.32|4.62|helps fix the problem
6393.84|3.48|so here
6395.94|2.279|I'm going to take the bachelor Monday
6397.32|3.6|class
6398.219|5.52|and I'm going to start placing it inside
6400.92|4.62|and as I mentioned before the standard
6403.739|3.781|typical place you would place it is
6405.54|3.84|between the linear layer so right after
6407.52|3.3|it but before the nonlinearity but
6409.38|4.14|people have definitely played with that
6410.82|4.68|and uh in fact you can get very similar
6413.52|3.619|results even if you place it after the
6415.5|3.6|nonlinearity
6417.139|3.221|and the other thing that I wanted to
6419.1|3.36|mention is it's totally fine to also
6420.36|3.839|place it at the end after the last
6422.46|4.56|linear layer and before the loss
6424.199|3.92|function so this is potentially fine as
6427.02|3.96|well
6428.119|6.04|and in this case this would be output
6430.98|4.86|would be world cup size
6434.159|4.261|um now because the last layer is
6435.84|4.14|mushroom we would not be changing the
6438.42|4.56|weight to make the softmax less
6439.98|4.94|confident we'd be changing the gamma
6442.98|4.86|because gamma remember in the bathroom
6444.92|4.36|is the variable that multiplicatively
6447.84|4.04|interacts with the output of that
6449.28|2.6|normalization
6452.58|5.52|so we can initialize this sandwich now
6455.4|5.04|and we can train and we can see that the
6458.1|4.98|activations are going to of course look
6460.44|4.32|very good and they are going to
6463.08|4.32|necessarily look good because now before
6464.76|5.64|every single 10 H layer there is a
6467.4|5.58|normalization in The Bachelor so this is
6470.4|4.02|unsurprisingly all looks pretty good
6472.98|4.199|it's going to be standard deviation of
6474.42|4.739|roughly 0.65 two percent and roughly
6477.179|3.54|equal standard deviation throughout the
6479.159|3.421|entire layers so everything looks very
6480.719|5.4|homogeneous
6482.58|6.539|the gradients look good the weights look
6486.119|5.04|good and they're distributions
6489.119|5.701|and then the updates
6491.159|5.401|also look pretty reasonable we're going
6494.82|4.44|above negative three a little bit but
6496.56|4.559|not by too much so all the parameters
6499.26|4.859|are training in roughly the same rate
6501.119|3.0|here
6504.659|4.02|but now what we've gained is we are
6507.0|3.8|going to be slightly less
6508.679|2.121|um
6511.199|4.381|brittle with respect to the gain of
6513.719|4.5|these so for example I can make the gain
6515.58|3.539|be say 0.2 here
6518.219|2.821|um
6519.119|3.721|which was much much slower than what we
6521.04|3.659|had with the 10h
6522.84|4.319|but as we'll see the activations will
6524.699|3.96|actually be exactly unaffected and
6527.159|3.601|that's because of again this explicit
6528.659|3.901|normalization the gradients are going to
6530.76|4.379|look okay the weight gradients are going
6532.56|4.26|to look okay but actually the updates
6535.139|3.301|will change
6536.82|2.94|and so
6538.44|3.12|even though the forward and backward
6539.76|3.359|pass to a very large extent look okay
6541.56|3.54|because of the backward pass of the
6543.119|4.441|batch form and how the scale of the
6545.1|5.579|incoming activations interacts in the
6547.56|5.88|basharm and its backward pass this is
6550.679|4.681|actually changing the um
6553.44|4.259|the scale of the updates on these
6555.36|4.259|parameters so the grades and ingredients
6557.699|4.081|of these weights are affected
6559.619|4.941|so we still don't get a completely free
6561.78|5.7|pass to pass an arbitrary weights here
6564.56|5.619|but it everything else is significantly
6567.48|5.82|more robust in terms of the forward
6570.179|4.5|backward and the weight gradients it's
6573.3|3.3|just that you may have to retune your
6574.679|4.5|learning rate if you are changing
6576.6|3.84|sufficiently the the scale of the
6579.179|4.741|activations that are coming into the
6580.44|5.759|bachelor's so here for example this we
6583.92|4.08|changed the gains of these linear layers
6586.199|5.401|to be greater and we're seeing that the
6588.0|5.699|updates are coming out lower as a result
6591.6|4.26|and then finally we can also if we are
6593.699|4.381|using basharms we don't actually need to
6595.86|4.259|necessarily let me reset this to one so
6598.08|3.48|there's no gain we don't necessarily
6600.119|3.961|even have to
6601.56|4.079|um normalize by fan in sometimes so if I
6604.08|4.079|take out the fan in so these are just
6605.639|3.961|now uh random gaussian
6608.159|2.641|we'll see that because of batch drum
6609.6|4.76|this will actually be relatively well
6610.8|3.56|behaved so
6614.82|3.66|this this is look of course in the
6616.38|3.359|forward pass look good the gradients
6618.48|4.32|look good
6619.739|5.521|the backward the weight updates look
6622.8|3.66|okay A little bit of fat tails in some
6625.26|4.62|of the layers
6626.46|6.42|and this looks okay as well but as you
6629.88|4.319|as you can see uh we're significantly
6632.88|2.759|below negative three so we'd have to
6634.199|4.201|bump up the learning rate of this
6635.639|4.5|bachelor so that we are training more
6638.4|4.02|properly and in particular looking at
6640.139|4.201|this roughly looks like we have to 10x
6642.42|4.199|the learning rate to get to about 20
6644.34|4.2|negative three
6646.619|4.681|so we come here and we would change this
6648.54|6.38|to be update of 1.0
6651.3|3.62|and if when I reinitialize
6659.04|3.179|then we'll see that everything still of
6660.54|4.139|course looks good
6662.219|4.92|and now we are roughly here and we
6664.679|4.261|expect this to be an okay training run
6667.139|4.02|so long story short we are significantly
6668.94|4.08|more robust to the gain of these linear
6671.159|4.261|layers whether or not we have to apply
6673.02|5.219|the fan in and then we can change the
6675.42|4.44|gain but we actually do have to worry a
6678.239|3.9|little bit about the update
6679.86|3.6|um scales and making sure that the
6682.139|3.901|learning rate is properly calibrated
6683.46|3.96|here but thus the activations of the
6686.04|3.54|forward backward pass and the updates
6687.42|4.199|are all are looking significantly more
6689.58|4.98|well-behaved except for the global scale
6691.619|5.401|that is potentially being adjusted here
6694.56|3.96|okay so now let me summarize there are
6697.02|3.599|three things I was hoping to achieve
6698.52|3.659|with this section number one I wanted to
6700.619|3.181|introduce you to batch normalization
6702.179|3.48|which is one of the first modern
6703.8|4.2|innovations that we're looking into that
6705.659|4.861|helped stabilize very deep neural
6708.0|3.9|networks and their training and I hope
6710.52|4.38|you understand how the bachelorization
6711.9|4.08|works and how it would be used in a
6714.9|3.12|neural network
6715.98|4.38|number two I was hoping to pie tortify
6718.02|5.639|some of our code and wrap it up into
6720.36|6.779|these modules so like linear Bachelor 1D
6723.659|5.52|10h Etc these are layers or modules and
6727.139|5.221|they can be stacked up into neural Nets
6729.179|6.121|like Lego building blocks and these
6732.36|5.04|layers actually exist in pie torch and
6735.3|4.379|if you import torch and then you can
6737.4|3.9|actually the way I've constructed it you
6739.679|3.96|can simply just use pytorch by
6741.3|3.78|prepending and then dot to all these
6743.639|3.781|different layers
6745.08|4.619|and actually everything will just work
6747.42|4.44|because the API that I've developed here
6749.699|4.681|is identical to the API that pytorch
6751.86|4.859|uses and the implementation also is
6754.38|3.839|basically as far as I'm aware identical
6756.719|3.361|to the one in pi torch
6758.219|3.48|and number three I try to introduce you
6760.08|3.9|to the diagnostic tools that you would
6761.699|4.261|use to understand whether your neural
6763.98|4.44|network is in a good State dynamically
6765.96|4.32|so we are looking at the statistics and
6768.42|4.02|histograms and activation of the forward
6770.28|4.5|pass application activations the
6772.44|3.719|backward pass gradients and then also
6774.78|2.76|we're looking at the weights that are
6776.159|3.181|going to be updated as part of
6777.54|3.0|stochastic already in ascent and we're
6779.34|3.72|looking at their means standard
6780.54|5.4|deviations and also the ratio of
6783.06|6.0|gradients to data or even better the
6785.94|4.5|updates to data and we saw that
6789.06|3.36|typically we don't actually look at it
6790.44|3.779|as a single snapshot Frozen in time at
6792.42|4.319|some particular iteration typically
6794.219|4.201|people look at this as uh over time just
6796.739|3.361|like I've done here and they look at
6798.42|3.48|these updated data ratios and they make
6800.1|3.66|sure everything looks okay and in
6801.9|4.2|particular I said that
6803.76|4.56|um running negative 3 or basically
6806.1|4.68|negative 3 on the log scale is a good
6808.32|4.56|rough heuristic for what you want this
6810.78|4.08|ratio to be and if it's way too high
6812.88|3.96|then probably the learning rate or the
6814.86|3.12|updates are a little too too big and if
6816.84|2.819|it's way too small that the learning
6817.98|3.239|rate is probably too small
6819.659|3.361|so that's just some of the things that
6821.219|3.9|you may want to play with when you try
6823.02|3.719|to get your neural network to work with
6825.119|3.06|very well
6826.739|3.9|now there's a number of things I did not
6828.179|4.081|try to achieve I did not try to beat our
6830.639|3.661|previous performance as an example by
6832.26|3.3|introducing the bathroom layer actually
6834.3|3.12|I did try
6835.56|3.36|um and I found the new I used the
6837.42|3.18|learning rate finding mechanism that
6838.92|3.9|I've described before I tried to train
6840.6|4.74|the bathroom layer a bachelor neural nut
6842.82|3.96|and I actually ended up with results
6845.34|2.76|that are very very similar to what we've
6846.78|3.359|obtained before
6848.1|4.619|and that's because our performance now
6850.139|4.56|is not bottlenecked by the optimization
6852.719|3.9|which is what bass Norm is helping with
6854.699|4.141|the performance at this stage is
6856.619|5.281|bottlenecked by what I suspect is the
6858.84|4.62|context length of our context
6861.9|3.12|So currently we are taking three
6863.46|3.12|characters to predict the fourth one and
6865.02|2.639|I think we need to go beyond that and we
6866.58|3.0|need to look at more powerful
6867.659|3.54|architectures that are like recurrent
6869.58|3.36|neural networks and Transformers in
6871.199|3.0|order to further push
6872.94|3.42|um the log probabilities that we're
6874.199|5.341|achieving on this data set
6876.36|5.46|and I also did not try to have a full
6879.54|4.26|explanation of all of these activations
6881.82|3.419|the gradients and the backward paths and
6883.8|3.12|the statistics of all these gradients
6885.239|3.241|and so you may have found some of the
6886.92|3.6|parts here unintuitive and maybe you're
6888.48|4.739|slightly confused about okay if I change
6890.52|4.44|the gain here how come that we need a
6893.219|3.121|different learning rate and I didn't go
6894.96|2.759|into the full detail because you'd have
6896.34|2.94|to actually look at the backward pass of
6897.719|3.061|all these different layers and get an
6899.28|4.08|intuitive understanding of how that
6900.78|4.68|works and I did not go into that in this
6903.36|3.839|lecture the purpose really was just to
6905.46|3.36|introduce you to the diagnostic tools
6907.199|3.121|and what they look like but there's
6908.82|3.359|still a lot of work remaining on the
6910.32|3.419|intuitive level to understand the
6912.179|4.381|initialization the backward pass and how
6913.739|5.101|all of that interacts but you shouldn't
6916.56|5.4|feel too bad because honestly we are
6918.84|5.16|getting to The Cutting Edge of where the
6921.96|4.14|field is we certainly haven't I would
6924.0|4.739|say solved initialization and we haven't
6926.1|4.2|solved back propagation and these are
6928.739|2.94|still very much an active area of
6930.3|2.399|research people are still trying to
6931.679|2.701|figure out what's the best way to
6932.699|3.661|initialize these networks what is the
6934.38|4.14|best update rule to use
6936.36|3.839|um and so on so none of this is really
6938.52|4.5|solved and we don't really have all the
6940.199|5.46|answers to all the uh to you know all
6943.02|4.08|these cases but at least you know we're
6945.659|3.301|making progress at least we have some
6947.1|4.5|tools to tell us whether or not things
6948.96|3.96|are on the right track for now
6951.6|3.059|so
6952.92|3.12|I think we've made positive progress in
6954.659|4.341|this lecture and I hope you enjoyed that
6956.04|2.96|and I will see you next time