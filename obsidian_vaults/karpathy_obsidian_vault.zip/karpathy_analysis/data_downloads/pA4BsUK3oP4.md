start_time|end_time|text
0.0|3.27|all right so I we have a lot of stuff to
1.68|4.65|get through today so I'd like to get
3.27|5.19|started so today we're going to talk
6.33|3.45|about CN NS in practice and talk about a
8.46|3.059|lot of really low level sort of
9.78|3.66|implementation details that are really
11.519|3.961|common to get these things to work when
13.44|3.509|you're actually training things but
15.48|2.87|first as usual we have some
16.949|3.691|administrative stuff to talk about
18.35|4.24|number one is that through a really
20.64|4.139|heroic effort by all the TAS all the
22.59|3.66|midterms are already graded so you guys
24.779|3.361|should definitely thank them for that
26.25|2.58|and you can either pick them up after
28.14|3.36|class today
28.83|6.69|or in any of these office hours that are
31.5|5.61|up here also keep in mind that your
35.52|4.17|project milestones are going to be due
37.11|3.57|tonight at midnight so make sure that I
39.69|2.79|hope you've been working on your
40.68|3.33|projects for the last couple but for the
42.48|3.419|last week or so and have made some
44.01|4.2|really exciting progress so make sure to
45.899|5.25|write that up and put it in the
48.21|4.919|assignments tab on the on Dropbox no no
51.149|4.23|not on Dropbox put it on the assignments
53.129|3.36|tab on coursework sorry that I know this
55.379|2.971|has been really confusing but
56.489|5.16|assignments tab just like yeah just like
58.35|4.68|assignment to assignment to we're
61.649|4.26|working on grading hopefully we'll have
63.03|5.879|that done sometime this week ish and
65.909|4.5|remember that assignment three is out so
68.909|5.581|how's that been going
70.409|6.331|anyone anyone done okay that's good one
74.49|4.43|person's done so the rest of you should
76.74|4.68|get started because it's due in a week
78.92|5.589|so we have some fun stats from the
81.42|4.41|midterm so don't freak out and you see
84.509|3.061|your grade because we actually had this
85.83|3.78|really nice beautiful Gaussian
87.57|3.54|distribution with a beautiful standard
89.61|2.88|deviation we don't need to batch
91.11|3.78|normalize this thing it's already
92.49|5.16|perfect I'd also like to point out that
94.89|3.96|someone got a max score of 103 which
97.65|3.359|means they got everything right and the
98.85|6.9|bonus so that's means it wasn't hard
101.009|6.991|enough to maybe we also have some per
105.75|4.35|question stats like per question
108.0|3.869|breakdown on average score per every
110.1|3.15|single question in the midterm so if you
111.869|2.46|want if you got something wrong and you
113.25|2.46|want to see if everyone else got it
114.329|4.08|wrong too you can go check on these
115.71|4.08|stats later at your on your own time we
118.409|3.871|have stats for the true/false and the
119.79|4.439|multiple-choice keep in mind so actually
122.28|3.089|for two of the true/false we decided
124.229|2.611|during grading that they were a little
125.369|3.48|bit unfair we throw it out and just gave
126.84|5.789|you all the points which is why two of
128.849|4.751|those are at 100% we have these stats
132.629|3.191|for all
133.6|6.84|the individual questions so go ahead and
135.82|5.97|have fun with those later let's so last
140.44|3.96|time I know it's been a while that we
141.79|4.53|had a midterm and we had a holiday but
144.4|3.9|if you can remember like over a week ago
146.32|3.96|we were talking about recurrent networks
148.3|3.15|so we talked about how recurrent
150.28|3.12|networks can be used for modeling
151.45|3.87|sequences you know normally with these
153.4|3.72|feed-forward networks they take in if
155.32|3.54|they model this feed-forward function
157.12|3.54|but these recurrent networks we talked
158.86|4.32|about how they can model different kinds
160.66|4.35|of sequence problems we talked about two
163.18|4.53|particular implementations of recurrent
165.01|4.83|networks vanilla RN ends and LS TMS and
167.71|3.66|but you'll implement both of those on
169.84|3.84|the assignment so you should know what
171.37|4.44|they are we talked about how these
173.68|4.8|recurrent not recurrent neural networks
175.81|4.98|can be used for language models and had
178.48|4.62|some fun showing some sample generated
180.79|4.95|texts on what is the Shakespeare and
183.1|4.08|algebraic geometry so that's one we
185.74|3.0|talked about how we can combine
187.18|3.78|recurrent networks with convolutional
188.74|4.08|networks to do image captioning and we
190.96|4.5|played a little bit this game of being
192.82|4.14|RNN neuroscientists and diving into the
195.46|3.45|cells of the rnns and trying to
196.96|3.75|interpret what they're doing and we saw
198.91|3.83|that sometimes we have these
200.71|4.62|interpretable cells that are for example
202.74|4.9|activating insight if statements which
205.33|3.38|is pretty cool but today we're going to
207.64|3.3|talk about something fully different
208.71|4.93|there are three we're going to talk
210.94|5.64|about really the things that you need to
213.64|4.65|know to get CN NS working in practice so
216.58|2.97|there's three major themes it's a little
218.29|3.84|bit of a potpourri but we're going to
219.55|4.17|try to tie it together so the first is
222.13|3.57|really squeezing all the juice that you
223.72|3.39|can out of your data so I know a lot of
225.7|3.21|you especially for your projects you
227.11|3.24|don't have large data sets so we're
228.91|3.24|going to talk about data augmentation
230.35|3.78|and transfer learning which are two
232.15|3.21|really powerful useful techniques
234.13|3.69|especially when you're working with
235.36|5.01|small datasets we're going to really
237.82|5.25|dive deep into convolutions and talk a
240.37|4.41|lot more about those both how you can
243.07|4.02|design efficient architecture is using
244.78|4.02|convolutions and also how convolutions
247.09|3.81|are efficiently implemented in practice
248.8|3.99|and then finally we're going to talk
250.9|3.72|about something that usually gets lumped
252.79|3.66|under implementation details and doesn't
254.62|4.92|even make it into papers but that stuff
256.45|4.44|like what as a cpu what is a GPU what
259.54|2.61|kind of bottlenecks do you experience in
260.89|3.12|training how might you distribute
262.15|4.56|training over multiple over multiple
264.01|2.86|devices so that's a lot of stuff we
266.71|2.739|should
266.87|3.93|get started so first let's talk about
269.449|3.061|data augmentation
270.8|3.63|I think we've sort of mentioned this
272.51|3.36|maybe in passing so far in the lectures
274.43|1.85|but never really talked formally about
275.87|3.09|it
276.28|4.33|so normally when you're training CN NS
278.96|4.38|you're really familiar with this type of
280.61|4.68|pipeline when during training you're
283.34|3.6|going to load images and labels up off
285.29|3.24|the disk you're going to pipe the image
286.94|3.27|through to your CN n then you're going
288.53|3.48|to use the image together with the label
290.21|3.66|to compute some loss function then back
292.01|3.99|propagate and update the CN N and repeat
293.87|4.98|forever so that you should be really
296.0|5.19|familiar with that by now with the the
298.85|4.22|thing about data augmentation is we just
301.19|5.16|add one little step to this pipeline
303.07|5.23|which is here so after we load the image
306.35|3.96|up off disk we're going to transform it
308.3|4.35|in some way before passing it to the CN
310.31|3.81|n and this transformation should
312.65|3.45|preserve the label so we're going to
314.12|4.23|compute loss back propagate and update
316.1|4.17|the CN n so it's really simple and the
318.35|4.68|trick is just what kinds of transforms
320.27|4.05|you should be using right so data
323.03|3.09|augmentation the idea is really simple
324.32|3.569|it's sort of this way that lets you
326.12|3.66|artificially expand your training set
327.889|4.321|through clever usage of different kinds
329.78|4.199|of transformations so if you remember
332.21|3.57|the computer is really seeing these
333.979|3.901|images as these giant grids of pixels
335.78|3.99|and there are these different kinds of
337.88|3.719|transformations we can make that should
339.77|3.899|preserve the label but which will change
341.599|3.871|all of the pixels if you imagine like
343.669|3.541|shifting that cat one pixel to the left
345.47|4.199|it's still a cat but all the pixels are
347.21|4.38|going to change so that so when you talk
349.669|3.481|about data augmentation you're sort of
351.59|3.78|imagine that you're expanding your
353.15|3.989|training set these trainings ant these
355.37|3.6|new fake training examples will be
357.139|3.78|correlated but it'll still help you
358.97|4.56|train models with with bigger models
360.919|4.321|with less overfitting and this is very
363.53|3.27|very widely used in practice pretty much
365.24|3.899|any CNN you see that's winning
366.8|4.489|competitions or doing well on benchmarks
369.139|5.131|is using some form of data augmentation
371.289|4.931|so the easiest form of data augmentation
374.27|3.72|is horizontal flipping if we take this
376.22|3.24|cat and we look at the mirror image the
377.99|3.51|mirror image should still be a cat and
379.46|3.78|this is really really easy to implement
381.5|3.62|in numpy you can just do it with a
383.24|3.87|single call a single line of code
385.12|3.609|similarly easy and torch other
387.11|4.71|frameworks this is really easy very
388.729|5.581|widely used something else that's very
391.82|5.19|widely used is to take random crops from
394.31|4.05|the training images so at training time
397.01|2.99|we're going to load up our image and
398.36|3.35|we're going to take a patch
400.0|4.53|that image at a random scale and
401.71|4.8|location resize it to our fixed whatever
404.53|3.57|size our Sienna is expecting and then
406.51|4.35|use that as our training example and
408.1|4.98|again this is very very widely used just
410.86|4.68|to give you a flavor of how exactly this
413.08|4.68|is used I looked up the details for res
415.54|4.59|nets so they actually a training time
417.76|4.44|each training image they resize they
420.13|3.81|first pick a random number resize the
422.2|4.59|whole image so that the shorter side is
423.94|5.34|that number then sample a random 224 by
426.79|4.41|224 crop from the resized image and then
429.28|3.84|use that as their training example so
431.2|6.3|that's pretty easy to implement and
433.12|6.09|usually helps quite a bit so when you're
437.5|3.99|using this form of data augmentation
439.21|5.25|usually things change a little bit at
441.49|3.929|test time so at training time when
444.46|3.03|you're using this form of data
445.419|3.781|augmentation the network is not really
447.49|4.11|trained on full images it's trained on
449.2|5.01|these crops so it doesn't really make
451.6|4.83|sense or seem fair to try to force the
454.21|4.77|network to look at whole images at test
456.43|4.71|time so usually in practice when you're
458.98|4.53|doing this kind of random cropping for
461.14|4.95|data augmentation at test time you'll
463.51|5.25|have some fixed set of crops and use
466.09|4.77|these for testing so very commonly
468.76|3.42|you'll see that you'll see ten crops
470.86|3.33|you'll take the upper left-hand corner
472.18|3.9|the upper right-hand corner the two
474.19|3.45|bottom corners and the center that gives
476.08|3.839|you five together if they're horizontal
477.64|4.65|flips gives you ten so you'll take those
479.919|3.901|ten crops at test time pass them through
482.29|5.28|the network and average the scores of
483.82|5.07|those ten crops so ResNet actually takes
487.57|3.15|this a little bit one step further and
488.89|5.01|they actually do multi scale multiple
490.72|4.71|scales at test time as well so this is
493.9|3.72|something that tends to help performance
495.43|6.239|in practice and again very easy to
497.62|6.54|implement very widely used another thing
501.669|5.161|that we usually do for data augmentation
504.16|4.38|is color jittering so if you take this
506.83|3.06|picture of a cat maybe maybe it was a
508.54|3.27|little bit cloudy or that day or a
509.89|3.54|little bit sunnier that day and if we
511.81|2.58|would have taken a picture then a lot of
513.43|3.479|the colors would have been quite
514.39|4.35|different so one thing that's very
516.909|3.57|common to do is just change the color a
518.74|4.349|little bit of our training images before
520.479|4.771|we feed it to the CNN so a very simple
523.089|4.051|way is just to change the contrast this
525.25|4.65|is again very easy to implement very
527.14|5.16|simple to do but actually in practice
529.9|3.86|you'll see that this contrast jittering
532.3|3.68|is a little bit less common
533.76|5.88|and what instead you see is this
535.98|5.46|slightly more complex pipeline using
539.64|4.47|principal component analysis over all
541.44|5.01|the pixels of the training data the idea
544.11|4.17|is that we for each pixel in the
546.45|4.59|training data is this vector of length
548.28|4.65|three an RGB and if we collect those
551.04|3.96|pixels over the entire training data set
552.93|3.72|you get a sense of what kinds of colors
555.0|4.38|generally exist in the training data
556.65|5.25|then using principal component analysis
559.38|4.53|gives us three principal component
561.9|3.78|directions in color space that kind of
563.91|3.66|tell us what are the directions along
565.68|5.37|which color tends to vary in the data
567.57|5.52|set so then a test a training time for
571.05|3.87|color augmentation we can actually use
573.09|4.02|these principal components of the color
574.92|5.0|of the training set to choose exactly
577.11|4.62|how to jitter the color at training time
579.92|4.15|this is again a little bit more
581.73|6.0|complicated but it is pretty widely used
584.07|6.21|so this type of PCA driven data
587.73|4.26|augmentation for color I think was
590.28|4.47|introduced with the Alex net paper in
591.99|7.23|2012 and it's also used in ResNet for
594.75|6.48|example so data augmentation is is
599.22|3.81|really this very general thing right you
601.23|4.02|just want to think about for your data
603.03|3.9|set what kinds of transformations do you
605.25|3.9|want your classifier to be invariant to
606.93|4.59|and then you want to introduce those
609.15|4.92|types of variations to your training
611.52|4.32|data at training time and you can really
614.07|3.72|go crazy here and get creative and
615.84|3.78|really think about your data and what
617.79|5.34|types of invariances make sense for your
619.62|5.79|data so you might want to try like maybe
623.13|2.61|random rotations um depending on your
625.41|2.01|data
625.74|3.9|maybe rotations of a couple degrees make
627.42|3.72|sense you could try like different kinds
629.64|3.27|of stretching and shearing to simulate
631.14|4.29|maybe affine transformations of your
632.91|4.05|data and you could really go crazy here
635.43|5.75|and try to get creative and think of
636.96|6.9|interesting ways to augment your data
641.18|5.47|another thing that I'd like to point out
643.86|4.83|is this idea of data augmentation really
646.65|3.48|fits into kind of a larger theme that
648.69|4.41|now we've seen repeated many times
650.13|5.67|throughout the course and this theme is
653.1|4.92|that one way that's really useful in
655.8|2.91|practice for preventing overfitting as a
658.02|3.03|regularizer
658.71|3.78|is that during the forward pass during
661.05|3.21|training when we're training our network
662.49|3.31|we add some kind of weird stochastic
664.26|4.36|noise to kind of match
665.8|3.69|with the network for example with data
668.62|2.399|augmentation
669.49|3.63|we're actually modifying the training
671.019|3.75|data that we put into the network with
673.12|4.62|things like drop out or drop connect
674.769|4.171|you're taking random parts of the
677.74|2.789|network and either setting the
678.94|5.94|activations or the weights to zero
680.529|6.261|randomly that this also has this also
684.88|4.44|appears kind of with batch normalization
686.79|4.539|since with batch normalization your
689.32|4.079|normalization contents depend on the
691.329|3.901|other things in the mini batch so your
693.399|4.471|normal and during training the same
695.23|4.799|image might end up appearing in mini
697.87|3.45|batches with different other images so
700.029|3.81|it actually introduces this type of
701.32|4.56|noise a training time but for in all of
703.839|4.291|these examples at test time we average
705.88|4.26|out this noise so for data augmentation
708.13|4.53|we'll take averages over many different
710.14|4.17|samples of the training data for dropout
712.66|3.989|and drop connect you can sort of
714.31|4.92|evaluate and marginalize this out more
716.649|4.111|analyze more analytically and for batch
719.23|3.27|normalization we keep to keep these
720.76|3.66|running means so I just think that's
722.5|4.14|kind of a nice way to unify a lot of
724.42|3.9|these ideas for regularization is that
726.64|3.72|when you can add noise at the forward
728.32|4.47|pass and then marginalize over it at
730.36|3.36|test time so maybe keep that in mind if
732.79|2.4|you're trying to come up with other
733.72|6.42|creative ways to regularize your
735.19|7.26|networks so that's so the main takeaway
740.14|4.189|is for data augmentation are that one
742.45|4.259|it's usually really simple to implement
744.329|4.021|so you should almost always be using it
746.709|4.201|there's not really any excuse not to
748.35|4.27|it's very very useful especially for
750.91|3.9|small data sets which I think many of
752.62|3.839|you are using for your projects and it
754.81|3.96|also fits in nicely with this framework
756.459|4.891|of noise at training and marginalization
758.77|4.41|at test time so I think that's that's
761.35|3.6|pretty much all there is to say about
763.18|4.44|data augmentation so if there's any
764.95|6.86|questions about that I'm happy to talk
767.62|6.159|about it now yeah
771.81|5.61|you.your are meant to jettison or do you
773.779|5.261|resample yeah that's a good question so
777.42|4.2|a lot of times you'll actually resample
779.04|4.11|it live at training time because it
781.62|3.36|would take a lot of disk space to try to
783.15|3.33|dump these things to disk so a lot of
784.98|3.18|times so sometimes people get creative
786.48|2.97|and even have like background threads
788.16|6.03|that are fetching data and performing
789.45|7.38|documentation all right so if I think
794.19|5.25|that's if that's clear we can talk about
796.83|4.17|the next idea so there's this myth
799.44|4.77|floating around that when you work with
801.0|5.04|CNN's you really need a lot of data but
804.21|3.26|it turns out that with transfer learning
806.04|6.299|this myth is busted
807.47|6.4|so there's this really simple recipe
812.339|5.041|that you can use for transfer learning
813.87|6.0|and that's first you take whatever your
817.38|4.26|favorite CNN architecture is be it Alex
819.87|3.99|net or vgg or what have you and you
821.64|4.53|either train it on imagenet yourself or
823.86|4.86|you down or more commonly you download a
826.17|3.87|pre train model from the internet that's
828.72|3.33|easy to do just takes a couple minutes
830.04|5.64|to download many hours to train but you
832.05|6.21|probably won't do that part next there's
835.68|4.53|sort of two general cases one if your
838.26|4.26|data set is really small and you really
840.21|4.17|don't have any images whatsoever then
842.52|4.62|you can just treat this classifier as a
844.38|5.01|fixed feature extractor so one way to
847.14|4.23|look at this is that you'll take the
849.39|4.199|last layer of the network the softmax
851.37|4.17|you if it's an image net classification
853.589|3.301|model you'll take it away and you'll
855.54|2.79|replace it with some kind of linear
856.89|3.27|classifier for the tasks that you
858.33|3.27|actually care about and now you'll
860.16|4.83|freeze the rest of the network and
861.6|5.37|retrain only that top layer so this is
864.99|3.69|sort of equivalent to just training a
866.97|3.68|linear classifier directly on top of
868.68|3.99|features extracted from the network so
870.65|4.51|what you'll see a lot of times in
872.67|4.14|practice for this case is that sort of
875.16|3.24|as a pre-processing step you'll just
876.81|3.39|dump features to disk for all of your
878.4|3.689|training images and then work entirely
880.2|4.65|on top of those cached features so that
882.089|5.821|can help speed things up quite a bit and
884.85|4.89|and that's quite easy to use it's very
887.91|3.51|very common it's usually provides a very
889.74|4.65|strong baseline for a lot of problems
891.42|4.8|that you might encounter in practice and
894.39|3.63|if you have a little bit more data then
896.22|4.14|then you can actually afford to train
898.02|4.65|more complex models so depending on the
900.36|4.2|size of your data set usually you'll
902.67|2.92|freeze some parts some of the lower
904.56|3.1|layers of the network
905.59|4.38|and then instead of retraining only the
907.66|4.08|last layer you'll pick some number of
909.97|4.41|the last layers to Train depending on
911.74|4.05|how large your data set is and generally
914.38|3.51|when you have a larger data set
915.79|4.77|available for training you can afford to
917.89|5.07|train more of these final layers and
920.56|4.59|again if you're similar to the similar
922.96|3.6|to the trick over here what you'll see
925.15|3.24|very commonly is that instead of
926.56|4.02|actually explicitly computing this part
928.39|4.77|you'll just dump these last layer
930.58|5.22|features to disk and then work on this
933.16|7.17|part in memory so that can speed things
935.8|12.09|up quite a lot and sometimes oh yeah
940.33|10.05|question that you you basically have to
947.89|4.14|try it and see but especially for this
950.38|3.87|type of small data set will work on
952.03|3.72|instances so if you have like if you
954.25|3.54|want to just do image retrieval a pretty
955.75|5.25|strong baseline is just to use l2
957.79|4.98|distance on CNN features so maybe so
961.0|3.66|this type of approach I mean however
962.77|3.69|many however many samples you expect to
964.66|4.47|need to train a saw like an SVM or
966.46|5.4|something and for these if you have more
969.13|4.92|than if you have more data than you
971.86|2.55|would expect to need for an SVM then try
974.05|2.13|that
974.41|4.74|so it's does a little hand maybe I'm
976.18|5.52|sorry yeah so you still need all the
979.15|4.68|weights for each layer you still like
981.7|5.25|run running through the forecast you
983.83|5.01|just don't do the back propagation um it
986.95|3.39|depends sometimes you you actually will
988.84|3.24|run through the forward pass but
990.34|4.83|sometimes you'll just run the forward
992.08|4.74|pass once and dump these two discs both
995.17|7.16|it's kind of that's that's pretty common
996.82|5.51|actually cuz in that saves compute yeah
1010.62|4.779|yeah yeah so then it's been typically
1013.69|3.54|this this final layer you'll always need
1015.399|2.821|to swap in and reinitialize from random
1017.23|2.88|because you'll probably have different
1018.22|3.72|classes or you're doing aggression
1020.11|3.39|problem or something but then these
1021.94|3.06|these other intermediate layers you'll
1023.5|5.669|initialize from whatever was in the pre
1025.0|7.86|trained model and actually in practice
1029.169|5.581|when you're fine-tuning a nice tip it to
1032.86|3.719|actually do this is that they're
1034.75|3.27|literally be two types of layers when
1036.579|3.51|you well I guess three types of layers
1038.02|3.99|when you're fine-tuning there'll be the
1040.089|4.171|frozen layers which you can think of as
1042.01|4.77|having a learning rate of zero there are
1044.26|4.68|these these new layers that you've
1046.78|4.769|reinitialize from scratch and typically
1048.94|5.04|those have maybe a higher learning rate
1051.549|3.87|but not too high maybe one tenth of what
1053.98|3.9|your network was originally trained with
1055.419|4.62|and then you'll have these intermediate
1057.88|3.659|layers that you are initializing from
1060.039|3.451|the pre trained network but you're
1061.539|4.321|planning to modify during optimization
1063.49|3.929|and fine-tuning so these intermediate
1065.86|3.33|layers you'll tend have a very small
1067.419|12.571|learning rate maybe 1/100 of the
1069.19|12.359|original yeah that's a that's a good
1079.99|3.12|question some people have tried to
1081.549|4.231|investigate that and found that
1083.11|4.199|generally fine-tuning this type of
1085.78|3.69|transfer learning fine-tuning approach
1087.309|4.201|works better when the network was
1089.47|4.74|originally trained with similar types of
1091.51|4.68|data whatever that means but in fact
1094.21|4.26|these these very low-level features are
1096.19|3.869|things like edges and colors and Gabor
1098.47|2.819|filters which are probably going to be
1100.059|3.331|applicable to just about any type of
1101.289|3.781|visual data so especially these lower
1103.39|4.74|level features I think are generally
1105.07|5.25|pretty applicable to almost anything and
1108.13|3.6|by the way another tip that use that you
1110.32|3.9|sometimes see in practice for fine
1111.73|5.22|tuning is that um you might actually
1114.22|4.68|have a multi-stage approach where first
1116.95|4.17|you freeze the entire network and then
1118.9|4.2|only train this last layer and then
1121.12|3.72|after this last layer it seems to be
1123.1|4.35|converging then go back and actually
1124.84|5.579|fine-tune these you can sometimes have
1127.45|4.979|this problem that these because this
1130.419|3.301|last layer is initialized randomly you
1132.429|3.571|might have very large gradients that
1133.72|4.079|kind of mess up this initialization so
1136.0|3.63|that the two ways that we get around
1137.799|3.36|that are either freezing this at first
1139.63|3.119|and letting this converge
1141.159|5.031|or by having this varying learning rate
1142.749|3.441|between the two regimes of the network
1146.609|4.721|so this idea of transfer learning
1148.629|5.51|actually works really well so there was
1151.33|5.399|a couple pretty early papers from
1154.139|4.99|2013-2014 when CN NS first started
1156.729|5.19|getting popular this one in particular
1159.129|4.35|the astounding baseline paper was was
1161.919|3.87|pretty cool what they did is they took
1163.479|4.8|the what at the time was one of the best
1165.789|4.23|CN NS out there was over feet so they
1168.279|3.57|just extracted features from over feet
1170.019|3.27|and applied these features to a bunch of
1171.849|3.121|different standard data sets and
1173.289|5.34|standard problems in computer vision and
1174.97|5.399|they compared these rights then the idea
1178.629|3.54|is that they compare it against what was
1180.369|3.27|at the time these very specialized
1182.169|3.09|pipelines and very specialized
1183.639|3.96|architectures for each individual
1185.259|4.11|problem and data set and for each
1187.599|4.111|problem they just replace this very
1189.369|4.92|specialized pipeline with very simple
1191.71|4.86|linear models on top of features from
1194.289|4.11|overfeed and they did this for a whole
1196.57|4.14|bunch of different datasets and found
1198.399|3.75|that in general over all these over feet
1200.71|4.079|features were a very very strong
1202.149|4.23|baseline and for some problems they were
1204.789|3.24|actually better than the existing
1206.379|2.97|methods and for some problems they were
1208.029|3.9|a little bit worse but still quite
1209.349|4.29|competitive so this this was I think a
1211.929|3.33|really cool paper they just demonstrated
1213.639|2.821|that these are really strong features
1215.259|2.931|that can be used in a lot of different
1216.46|4.38|tasks and tend to work quite well
1218.19|6.13|another paper along those lines was from
1220.84|5.579|Berkeley the decaf paper and decaf later
1224.32|5.729|became became caffeinated and became
1226.419|8.521|cafe so that's that's kind of a lineage
1230.049|6.99|there so kind of the recipe for transfer
1234.94|4.229|learning is that there you should kind
1237.039|5.52|of think about to this little two-by-two
1239.169|5.46|matrix how similar is your dataset to
1242.559|4.68|what the pre train model was and how
1244.629|5.0|much data do you have and what should
1247.239|4.86|you do in those four different columns
1249.629|4.72|so generally if you have a very similar
1252.099|4.71|data set and very little data just using
1254.349|4.621|the network as a fixed feature extractor
1256.809|3.84|and training simple maybe linear models
1258.97|4.679|on top of those features tends to work
1260.649|5.25|very well if you have a little bit more
1263.649|3.931|data then you can try to try fine-tuning
1265.899|3.48|and try actually initializing the
1267.58|3.809|network from fine tune from pre train
1269.379|3.481|weights and running optimization from
1271.389|3.271|there
1272.86|4.83|this other column is little trickier in
1274.66|4.95|this box you might be in trouble
1277.69|3.989|you can try to get creative and maybe
1279.61|3.99|instead of extracting features from the
1281.679|3.061|very last layer you might try extracting
1283.6|2.61|features from different layers of the
1284.74|4.77|continent and that can sometimes
1286.21|5.73|sometimes help the intuition there is
1289.51|4.53|that maybe for something like MRI data
1291.94|3.869|probably these very top level features
1294.04|3.84|are very specific to image net
1295.809|4.381|categories but these very low-level
1297.88|4.41|features are things like edges and and
1300.19|5.34|stuff like that that might be more
1302.29|5.97|transferable to tune on into non image
1305.53|4.44|net type datasets and obviously in this
1308.26|3.0|box you're in better shape and again you
1309.97|5.43|can just sort of initialize and
1311.26|6.57|fine-tune so another thing I'd like to
1315.4|4.23|point out is this idea of initializing
1317.83|3.75|with pre trained models and fine tuning
1319.63|3.81|is actually not the exception this is
1321.58|3.81|pretty much standard practice in almost
1323.44|4.17|any larger system that you'll see in
1325.39|3.66|computer vision these days and we've
1327.61|4.11|actually seen two examples of this
1329.05|4.44|already in the course so for example if
1331.72|3.57|you remember from a few lectures ago we
1333.49|3.569|talked about object detection where we
1335.29|4.019|had a CNN looking at the image and
1337.059|4.471|region proposals and this other all this
1339.309|4.291|and all this crazy stuff but this part
1341.53|3.899|was a CNN looking at the image and for
1343.6|3.6|image captioning we had a CNN looking at
1345.429|3.901|the image so in both of those cases
1347.2|4.62|those CN NS were initialized from image
1349.33|4.2|map models and that really helps to
1351.82|3.63|solve these other more specialized
1353.53|5.19|problems even without gigantic data sets
1355.45|5.13|and also for the image captioning model
1358.72|3.81|in particular part of this model
1360.58|3.57|includes these word embeddings that you
1362.53|4.47|should have seen by now on the homework
1364.15|4.74|if you started on it but those word
1367.0|3.39|vectors you can actually initialize from
1368.89|3.48|something else that was maybe pre
1370.39|3.72|trained on a bunch of text and that can
1372.37|3.84|sometimes help maybe in some search in
1374.11|6.65|some situations where you might not have
1376.21|4.55|a lot of captioning data available yeah
1386.13|4.9|that was like I'm here or maybe here
1389.74|3.45|yeah yeah people have definitely tried
1391.03|3.93|that and that that tends to help
1393.19|2.91|sometimes it depends on the problem
1394.96|2.31|depends on the network but it's
1396.1|3.329|definitely something you can try and
1397.27|6.71|that especially might help when you're
1399.429|4.551|in this box but yeah that's a good trick
1405.82|4.359|all right so the takeaway about fine
1407.96|4.339|tuning is that um you should really use
1410.179|4.561|it it's a really good idea
1412.299|3.641|yeah so that it works really well in
1414.74|3.96|practice you should probably almost
1415.94|3.869|always be using it to some extent you
1418.7|2.49|generally don't want to be training
1419.809|2.641|these things from scratch unless you
1421.19|2.91|have really really large data sets
1422.45|3.599|available in almost all of our
1424.1|5.76|circumstances it's much more convenient
1426.049|5.941|to fine tune in a sustained model and by
1429.86|4.769|the way cafe has this existing model
1431.99|7.049|view you can download many exist many
1434.629|6.27|famous image net models actually the
1439.039|3.211|residual networks the official model got
1440.899|2.791|released recently so you can even
1442.25|2.73|download that and play with it that'd be
1443.69|3.75|pretty cool
1444.98|3.929|and these cafe model zoo models are sort
1447.44|4.14|of like a little bit of a standard in
1448.909|4.921|the community so you can even load cafe
1451.58|4.319|models into other other frameworks like
1453.83|3.78|torch so that's that's something to keep
1455.899|6.061|in mind that these cafe models are quite
1457.61|6.269|useful all right any any further
1461.96|7.429|questions on on fine tuning or transfer
1463.879|5.51|learning yeah
1478.25|5.56|yeah that's true yeah so that's that's
1482.49|3.15|true the feature dimension is quite
1483.81|4.05|large at lower dimensions so you might
1485.64|4.05|try a highly regularize linear model on
1487.86|3.36|top of that or you might try putting a
1489.69|2.97|small ComNet on top of that to maybe
1491.22|3.24|reduce the dimensionality you can get
1492.66|3.42|creative here but I think that there
1494.46|5.03|there are there things you can try that
1496.08|3.41|might work for your data depending on it
1499.79|6.46|all right so I think we should talk more
1503.49|4.26|about convolutions so for for all these
1506.25|3.48|networks we've talked about really the
1507.75|4.17|convolutions are the computational
1509.73|4.77|workhorse that's doing a lot of the work
1511.92|6.06|in the network so we need to talk about
1514.5|6.36|two things about convolutions the first
1517.98|4.62|is how to stack them so how can we
1520.86|3.84|design efficient network architectures
1522.6|5.79|that combine many layers of convolution
1524.7|5.88|to achieve some some nice results so
1528.39|5.01|here's a question suppose that we have a
1530.58|5.25|network that has two layers of 3x3
1533.4|4.02|convolutions so this would be the input
1535.83|3.15|this would be the activation map in the
1537.42|4.68|first layer this would be the activation
1538.98|5.31|map after two layers of convolution so
1542.1|4.02|the question is for a neuron on this
1544.29|3.42|second layer how big of a region on the
1546.12|3.57|input does it see this was on your
1547.71|6.63|midterm so I hope I hope you guys all
1549.69|9.99|know the answer to this remember murmur
1554.34|8.52|is anyone ok guess maybe that was a hard
1559.68|5.37|midterm question but this is this is a
1562.86|4.38|5x5 and it's pretty easy to see from
1565.05|3.81|this diagram why so that this neuron
1567.24|3.39|after the second layer is looking at
1568.86|4.8|this entire volume in the intermediate
1570.63|4.56|layer so in particular this pixel in the
1573.66|4.44|intermediate layer is looking at this
1575.19|5.4|3x3 region in the input so when you
1578.1|5.25|averaged across when you look at all of
1580.59|4.59|all three of these then this layer this
1583.35|3.12|neuron in the in the second the third
1585.18|6.3|layer is actually looking at this entire
1586.47|7.35|5x5 volume in the input ok so now the
1591.48|4.65|question is if we had three 3x3
1593.82|5.57|convolutions stacked in a row how big of
1596.13|6.299|a region in the input would they see
1599.39|4.66|yeah good so the same kind of reason is
1602.429|5.091|that these receptive field just kind of
1604.05|3.47|build up with successive convolute
1607.62|5.91|so the point here to make is that you
1610.8|4.26|know three 3x3 convolutions actually
1613.53|4.23|give you a very similar representational
1615.06|5.64|power is my claim to a single 7 by 7
1617.76|4.68|convolution so it you you might debate
1620.7|3.33|on the exact semantics of this and you
1622.44|3.09|could try to prove theorems about it and
1624.03|3.57|things like that but just from an
1625.53|4.02|intuitive sense they can three three by
1627.6|4.26|three convolutions can represent similar
1629.55|4.2|types of functions as a similar seven by
1631.86|7.29|seven convolution since it's looking at
1633.75|8.25|the same input region um in the input so
1639.15|4.44|now the idea now actually we can dig
1642.0|4.5|further into this idea and we can
1643.59|5.1|compare more concretely between a single
1646.5|3.78|seven by seven convolution versus a
1648.69|4.14|stack of three three by three
1650.28|5.3|convolutions so let's suppose that we
1652.83|6.66|have an input image that's H by W by C
1655.58|6.01|and we want to have convolutions that
1659.49|4.53|preserve the depth so we have C filters
1661.59|3.99|and we want to have them preserve hype
1664.02|4.02|and width so we just set padding
1665.58|4.62|appropriately and then we want to
1668.04|3.48|compare concretely what is the
1670.2|3.42|difference between a single seven by
1671.52|5.04|seven versus a stack of three by three
1673.62|5.67|so first how many weights to each of
1676.56|4.62|these two things have anyone have a
1679.29|6.99|guess on how many weights the the single
1681.18|6.27|seven by seven convolution has you can
1686.28|9.36|forget about biases schools are
1687.45|11.97|confusing I heard I heard some some
1695.64|6.42|rumors but so my answer I hope I got it
1699.42|4.38|right was 49 C squared because you've
1702.06|3.36|got this seven by seven convolution each
1703.8|3.96|one is looking at a depth of C and
1705.42|5.01|you've got C such filters so 49 C
1707.76|5.22|squared but now for the three by three
1710.43|5.04|convolutions we have three layers of
1712.98|4.89|convolutions each one each filter is
1715.47|4.38|three by three by C and each layer has C
1717.87|3.84|filters when you multiply that all out
1719.85|4.17|we see that three three by three
1721.71|5.91|convolutions only has 27 C squared
1724.02|5.07|parameters and assuming that we have Rea
1727.62|3.45|lose after between each of these
1729.09|3.8|convolutions we see that the stack of
1731.07|4.05|three three by three convolutions
1732.89|4.42|actually has fewer parameters which is
1735.12|4.25|good and more non-linearity which is
1737.31|4.49|good so this kind of gives you a sum
1739.37|4.98|intuition for why a stack of three bite
1741.8|4.44|of multiple 3x3 convolutions might
1744.35|5.34|actually be preferable to a single 7 by
1746.24|5.43|7 convolution and we can actually take
1749.69|3.39|this one step further and think about
1751.67|2.61|not just the number of learn normal
1753.08|2.64|parameters but actually how many
1754.28|4.41|floating-point operations do these
1755.72|4.68|things take so anyone have a guess for
1758.69|7.619|how many how many operations these these
1760.4|9.18|to take guess not
1766.309|5.341|sounds hard right so actually this is
1769.58|3.99|pretty easy because for each of these
1771.65|4.11|filters we're going to be using it at
1773.57|4.14|every position in the in the image so
1775.76|3.66|actually the number of multiply adds is
1777.71|3.29|just going to be height times width
1779.42|3.889|times the number of learn about filters
1781.0|6.55|so you can see that actually over here
1783.309|6.461|again not only do we have so between
1787.55|3.06|collec comparing between these two the
1789.77|2.67|7x7
1790.61|3.78|actually not only has more learn about
1792.44|4.92|parameters but it actually costs a lot
1794.39|5.73|more to compute as well so the stack of
1797.36|5.76|three 3x3 convolutions again gives us
1800.12|4.14|more non-linearity for less compute so
1803.12|2.88|that kind of gives you some intuition
1804.26|4.2|for why actually having multiple layers
1806.0|6.27|of 3x3 convolutions but is actually
1808.46|5.849|preferable to large filters but then you
1812.27|3.48|can think of another question you know
1814.309|3.631|we've been pushing towards smaller and
1815.75|4.29|smaller filters but why stop at three by
1817.94|3.54|three right we can actually go smaller
1820.04|3.09|than that maybe the same logic would
1821.48|4.07|extend you're shaking your head you
1823.13|4.56|don't believe it
1825.55|4.6|that's true that's true you don't get
1827.69|4.82|the receptive field so actually what
1830.15|6.05|we're going to do here is compare a
1832.51|5.919|single 3x3 convolution versus a slightly
1836.2|4.479|fancier architecture called a bottleneck
1838.429|4.38|architecture so here we're going to
1840.679|5.13|assume but again an input of
1842.809|5.401|hwc and here we can actually do all this
1845.809|5.221|is a cool trick we do a single 1x1
1848.21|4.349|convolution with C over 2 filters to
1851.03|4.02|actually reduce the dimensionality of
1852.559|4.591|the volume so now this thing is going to
1855.05|5.28|have the same spatial extent but half
1857.15|5.58|the number of features in depth now
1860.33|4.74|after we do this bottleneck we're going
1862.73|6.39|to do a 3x3 convolution at this reduced
1865.07|6.57|dimensionality so now this this 3x3
1869.12|3.779|convolution takes C over 2 input
1871.64|4.499|features and produces
1872.899|5.07|to output features and now we restore
1876.139|4.5|the dimensionality with another 1x1
1877.969|5.58|convolution to go from C over 2 back to
1880.639|5.64|C so this is kind of a kind of a funky
1883.549|4.68|architecture this idea of using 1x1
1886.279|4.2|convolutions everywhere is sometimes
1888.229|4.83|called network and network because it
1890.479|4.2|has this intuition that you're a 1 by 1
1893.059|3.57|convolution is kind of similar to
1894.679|4.44|sliding a fully connected network over
1896.629|5.79|each part of your of your of your input
1899.119|5.4|volume and this idea also appears in
1902.419|3.781|google matt and in ResNet this idea of
1904.519|6.21|using these one-by-one bottleneck
1906.2|7.139|convolutions so we can compare this this
1910.729|5.07|bottleneck sandwich to a single 3x3
1913.339|5.7|convolution with C filters and run
1915.799|4.59|through the same logic so I won't I
1919.039|2.85|won't force you to compute this in your
1920.389|5.01|heads but you'll have to trust me on
1921.889|5.78|this that this bottleneck stack has
1925.399|4.62|three and a quarter C squared parameters
1927.669|4.39|whereas this one over here has 9 C
1930.019|3.421|squared parameters and again if we're
1932.059|3.78|sticking R a lose in between each of
1933.44|5.159|these convolutions then this bottleneck
1935.839|4.65|sandwich is giving us more more
1938.599|7.38|non-linearity for a fewer number of
1940.489|7.86|parameters and actually so we saw as we
1945.979|4.2|similar to we saw on the on the three by
1948.349|3.3|three versus seven by seven the number
1950.179|3.84|of parameters is tied directly to the
1951.649|4.77|amount of computation so this bottleneck
1954.019|4.89|sandwich is also much faster to compute
1956.419|4.2|so this to this idea of one by one
1958.909|3.72|bottlenecks has received quite a lot of
1960.619|10.74|usage recently in google met and ResNet
1962.629|10.41|especially yeah well those those
1971.359|3.3|convolutions are learned so you might
1973.039|3.781|think of it as you sometimes you think
1974.659|3.51|of it as as a projection from like a
1976.82|3.569|lower dimensional feature back to a
1978.169|3.63|higher dimensional space and then if you
1980.389|3.42|think about stacking many of these
1981.799|6.33|things on top of each other as happens
1983.809|5.94|in ResNet then then you then coming
1988.129|3.3|immediately after this one is going to
1989.749|3.81|be another one by one so you're kind of
1991.429|3.781|stacking many many want multiple one by
1993.559|4.05|one convolutions on top of each other
1995.21|4.169|and a one by one convolution is a little
1997.609|3.601|bit like sliding a fully a multi-layer
1999.379|3.99|fully connected network over each depth
2001.21|4.76|channel you'll have to think maybe think
2003.369|3.831|about that one a little bit but it's
2005.97|3.21|turns out that actually you don't really
2007.2|4.32|need the spatial extent and even just
2009.18|4.56|comparing this sandwich to a single 3x3
2011.52|4.5|con you're sort of having the same
2013.74|4.82|input-output eise's but with more
2016.02|5.19|non-linearity and cheaper to compute and
2018.56|5.92|you're fewer learn about parameters so
2021.21|4.77|those are all kind of nice features but
2024.48|3.48|there's there's one problem with this is
2025.98|3.87|that and that's we're still using a 3x3
2027.96|3.54|convolution in there somewhere and you
2029.85|4.89|might wonder if we if we really need
2031.5|6.18|this and the answer is no it turns out
2034.74|5.79|so one crazy thing that I've seen
2037.68|5.66|recently is that you can factor this 3x3
2040.53|6.06|convolution into a 3 by 1 and a 1 by 3
2043.34|5.86|and compared with a single 3x3
2046.59|5.52|convolution this ends up saving you some
2049.2|4.59|parameters as well so then you might you
2052.11|4.11|if you really go crazy you can combine
2053.79|4.11|this 1 by 3 and 3 by 1 together with
2056.22|4.17|this bottlenecking idea and and things
2057.9|4.23|just get really cheap and that's
2060.39|4.02|basically what Google has done in their
2062.13|3.77|most recent version of Inception so
2064.41|3.63|there's this kind of crazy paper
2065.9|4.03|rethinking the inception architecture
2068.04|3.33|for computer vision where they play a
2069.93|3.51|lot of these crazy tricks about
2071.37|3.96|factoring convolutions in weird ways and
2073.44|3.33|having a lot of one by one bottlenecks
2075.33|3.51|and then projections back up to
2076.77|3.45|different dimensions and and if you
2078.84|3.06|thought the original Google met with
2080.22|4.23|what their inception module was was
2081.9|4.2|crazy this ones these are the inception
2084.45|3.81|modules that Google is now using in
2086.1|3.72|their newest inception net and the
2088.26|2.64|interesting features here are that they
2089.82|3.21|have these one by one
2090.9|4.8|bottlenecks everywhere and actually you
2093.03|5.64|have these asymmetric filters to again
2095.7|5.76|save on computation so this stuff is not
2098.67|4.98|super widely used yet but it's it's it's
2101.46|5.06|out there and it's in Google net so I
2103.65|6.6|thought it's something cool to mention
2106.52|7.69|so the the quick recap from convolutions
2110.25|5.49|and and how to stack them is that it's
2114.21|3.63|usually better instead of having a
2115.74|4.23|single large convolution with a large
2117.84|3.72|filter size it's usually better to break
2119.97|4.02|that up into multiple smaller filters
2121.56|4.35|and that even maybe helps explain the
2123.99|4.23|difference between something like vgg
2125.91|4.05|which has many many 3x3 filters with
2128.22|4.92|something like alex net that had fewer
2129.96|4.77|smaller filters some another thing
2133.14|2.97|that's actually become pretty common I
2134.73|2.04|think is this idea of one-by-one
2136.11|2.7|bottlenecking
2136.77|2.73|you see that in both versions of Google
2138.81|2.67|net and also in
2139.5|3.6|ResNet and that actually helps you save
2141.48|3.0|a lot on parameters so I think that's a
2143.1|4.23|useful trick to keep in mind and this
2144.48|4.47|idea of factoring convolutions into
2147.33|4.44|these asymmetric filters I think is
2148.95|4.92|maybe not so widely used right now but
2151.77|5.13|it may become more commonly used in the
2153.87|4.62|future I'm not sure and the the basic
2156.9|3.45|overall overarching theme for all of
2158.49|4.5|these tricks is that it lets you have
2160.35|4.59|fewer learn about parameters and few and
2162.99|3.78|less compute and more non-linearity
2164.94|5.76|which are all sort of nice features to
2166.77|5.94|have in your architectures so if there's
2170.7|8.04|any questions about these these
2172.71|10.53|convolution architecture designs too
2178.74|6.06|boring or too obvious ok so then the
2183.24|3.78|next thing is that once you've actually
2184.8|4.05|decided on how you want to wire up your
2187.02|4.44|stack up convolutions you actually need
2188.85|4.14|to compute them and this this there's
2191.46|4.14|actually been a lot of work on different
2192.99|4.08|ways to implement convolutions we asked
2195.6|3.24|you to implement it on the assignments
2197.07|6.33|using for loops and that as you may have
2198.84|6.03|guessed doesn't scale too well so this a
2203.4|3.63|pretty a pretty easy approach that's
2204.87|4.95|pretty easy to implement is this idea of
2207.03|4.92|an m2 call method so the intuition here
2209.82|4.47|is that we know matrix multiplication is
2211.95|3.96|really fast and pretty much for any are
2214.29|3.96|any computing architecture out there
2215.91|4.38|someone has written a really really well
2218.25|4.77|optimized matrix multiplication routine
2220.29|5.16|or library so the idea of m2 call is
2223.02|4.62|thinking well given that matrix
2225.45|3.36|multiplication is really fast is there
2227.64|3.72|some way that we can take this
2228.81|6.09|convolution operation and recast it as a
2231.36|6.42|matrix multiply and it turns out that
2234.9|5.46|this is actually pretty somewhat easy to
2237.78|5.37|do once you think about it so the idea
2240.36|5.7|is that we have an input volume that's H
2243.15|5.28|by W by C and we have a filter Bank of
2246.06|4.59|convolutions of convolutional filters
2248.43|4.68|each one of these is going to be a K by
2250.65|4.83|K by C volume so it has a K by K
2253.11|4.14|receptive field and a depth of C to
2255.48|3.3|match the to match the input over here
2257.25|3.15|and we're going to have D of these
2258.78|5.37|filters and then we want to turn this
2260.4|5.04|into a into a matrix multiply problem so
2264.15|3.42|the idea is that we're going to take
2265.44|4.44|each one of the we're going to take the
2267.57|5.2|first receptive field of the image which
2269.88|5.05|is going to be this K by K by C
2272.77|4.02|in the input region in the end the input
2274.93|3.81|volume and we're going to reshape it
2276.79|4.17|into this column of K squared by C
2278.74|3.99|elements and then we're going to repeat
2280.96|4.2|this for every possible receptive field
2282.73|3.57|in the image so we're going to take this
2285.16|2.58|little guy and we're going to shift him
2286.3|3.27|over all possible regions in the image
2287.74|4.32|and here I'm just saying that there's
2289.57|5.61|going to be maybe n region and different
2292.06|4.77|receptive field locations so now we've
2295.18|3.9|taken our our image and we've taken
2296.83|7.23|reshaped it into this giant matrix of N
2299.08|6.99|by I mean n by K squared by C anyone see
2304.06|9.69|what a potential problem with this might
2306.07|10.14|be yeah yeah that's true so this this
2313.75|4.95|tends to use a lot of memory right so
2316.21|4.23|any elements in this input volume if it
2318.7|3.66|appears in multiple receptive fields
2320.44|4.35|then it's going to be duplicated in
2322.36|3.99|multiple of these columns so and this is
2324.79|3.32|going to get worse the more overlap
2326.35|4.019|there is between your receptive fields
2328.11|4.72|but it turns out that in practice that's
2330.369|5.911|actually not too big of a deal and it
2332.83|5.07|works fine so then we're going to run a
2336.28|3.63|similar trick on these convolutional
2337.9|3.81|filters so if you remember what a
2339.91|4.199|convolution is doing we want to take
2341.71|4.29|each of these convolutional weights and
2344.109|3.661|take inner products with each
2346.0|4.83|convolutional wait against each
2347.77|4.97|receptive field location in the image so
2350.83|5.67|each of these convolutional weights is
2352.74|5.71|is this K by K by C tensor so we're
2356.5|4.56|going to reshape each of those to be a K
2358.45|5.22|squared by C row and now we have D
2361.06|6.33|filters so we get a D by K squared by C
2363.67|6.84|matrix so now this is great now this guy
2367.39|5.19|contains all the resep each each column
2370.51|4.26|is a receptive field we have one column
2372.58|5.46|per receptive field in the image and now
2374.77|6.24|this matrix has one has one each row is
2378.04|5.43|a different weight so now we can easily
2381.01|4.23|compute all of these inner products all
2383.47|5.85|at once with this single matrix multiply
2385.24|6.119|and this I apologize for these
2389.32|3.06|dimensions not working out these I
2391.359|2.431|probably should have swapped these two
2392.38|4.86|to make it more obvious but I think you
2393.79|7.23|get the idea so this this gives you a D
2397.24|5.97|by end result so that D is our number of
2401.02|3.78|output filters and that n is for all the
2403.21|3.3|receptive field locations in the image
2404.8|3.6|so then you play a similar
2406.51|5.76|- take this and reshape it into your
2408.4|5.16|into your into your 3d output tensor you
2412.27|3.51|can actually extend this to mini-batches
2413.56|4.5|quite easily if you have a mini batch of
2415.78|5.28|n of these elements you just add more
2418.06|6.9|rows and have one set of rows per mini
2421.06|6.03|batch element so this actually is pretty
2424.96|4.37|easy to implement so Allah oh yeah
2427.09|2.24|question
2430.54|4.44|it depends that that's then it depends
2433.78|2.07|on your implementation right but then
2434.98|2.49|you have to worry about things like
2435.85|4.59|memory layout and stuff like that to
2437.47|4.83|make it best but sometimes you'll even
2440.44|5.34|do that reshape operation on the GPU so
2442.3|5.4|you can do it in parallel but as a case
2445.78|4.89|study so this is really easy to
2447.7|4.62|implement so a lot of if you're don't
2450.67|3.48|have a convolution technique available
2452.32|3.93|and you need to implement one fast this
2454.15|4.26|is probably the one to choose and if you
2456.25|4.23|look at actually cafe in early versions
2458.41|4.92|of cafe this is the method that they
2460.48|5.73|used for doing convolutions so this is
2463.33|5.01|the convolution forward code for like
2466.21|4.68|for the GPU like the native GPU
2468.34|4.32|convolution in cafe so you can see in
2470.89|3.75|this red chunk they're calling it - this
2472.66|5.4|em--to call method is taking their input
2474.64|6.12|image right so this is taking their
2478.06|4.47|input image somewhere this is right so
2480.76|3.24|this is their input image and then
2482.53|3.66|they're going to reshape this calling
2484.0|4.31|this em--to call method and then store
2486.19|5.46|it in this in this column GPU tensor
2488.31|5.5|then they're going to take do a matrix
2491.65|3.66|do a matrix multiply calling it - coup
2493.81|4.62|blast through the matrix multiply and
2495.31|5.37|then add the bias so that's that's how
2498.43|4.77|that's I mean these things tend to work
2500.68|3.93|quite well in practice and also as
2503.2|2.64|another case study if you remember the
2504.61|3.06|fast layers we gave you in the
2505.84|5.49|assignments actually uses this exact
2507.67|5.67|same strategy so here we actually do an
2511.33|4.74|M - call operation with some crazy numpy
2513.34|4.62|tricks and then now we can actually do
2516.07|4.14|the convolution inside the fast layers
2517.96|4.35|with a single call to the numpy matrix
2520.21|3.42|multiplication and you saw in your
2522.31|3.24|homeworks this usually gives maybe a
2523.63|3.96|couple hundred times faster than using
2525.55|3.3|for loops so this actually works pretty
2527.59|7.19|well and it's it's pretty easy to
2528.85|5.93|implement any questions about em to call
2536.31|7.59|yeah yes then you have to think about it
2541.56|3.75|a little bit but if you think if you
2543.9|3.72|think really hard you'll realize that
2545.31|6.03|the backward pass on a convolution is
2547.62|5.1|actually also a convolution which you
2551.34|2.73|may have figured out if you if you were
2552.72|3.3|thinking about it on your homework but
2554.07|4.14|the backward pass of a convolution is
2556.02|4.26|actually also a type of convolution over
2558.21|3.42|the over the upstream gradients so you
2560.28|3.03|can actually use a similar type of image
2561.63|4.14|at all method for the for the backward
2563.31|5.91|pass as well the only trick there is
2565.77|5.22|that one what once you do in the
2569.22|3.96|backward pass you need to some gradients
2570.99|3.81|from across overlapping receptive fields
2573.18|5.07|in the upstream so you need to be
2574.8|5.04|careful about the call to em you need to
2578.25|5.55|some in the call to em in the backward
2579.84|5.79|pass and you can actually check out in
2583.8|3.96|in the fast layers in the homework it
2585.63|4.32|implements that too although actually
2587.76|5.34|for the in the fast layers on the
2589.95|4.41|homework the call to M is in siphon I
2593.1|5.79|couldn't find a way to get it fast
2594.36|6.39|enough in Rondon pi so there's actually
2598.89|3.84|another way that sometimes people use
2600.75|5.28|for convolutions and that's this idea of
2602.73|4.68|a fast Fourier transform so if you have
2606.03|2.73|some memories from like a signal
2607.41|3.33|processing class or something like that
2608.76|4.17|you might remember this thing called the
2610.74|3.93|convolution theorem that says that you
2612.93|4.5|if you have two signals and you want to
2614.67|5.01|convey the discrete lis or continuously
2617.43|4.62|with an integral then taking a
2619.68|5.4|convolution of these two signals is the
2622.05|4.65|same as rather the Fourier transform of
2625.08|2.94|the convolution x' is the same as the
2626.7|3.99|element-wise product of the Fourier
2628.02|4.14|transforms so if you if you unpack that
2630.69|4.77|and stare at the symbols I think it'll
2632.16|4.95|make sense and if also you might
2635.46|3.78|remember from again a signal processing
2637.11|3.33|class or an algorithms class but there's
2639.24|3.6|this amazing thing called the fast
2640.44|4.95|Fourier transform that actually lets us
2642.84|4.79|compute Fourier transforms and inverse
2645.39|4.65|Fourier transforms really really fast
2647.63|4.15|you may have seen it there's versions of
2650.04|5.22|this in 1d and 2d and they're all really
2651.78|5.34|fast so we can actually apply this trick
2655.26|3.45|to convolutions so the way that this
2657.12|3.48|works is that first we're going to
2658.71|3.93|compute use the fast Fourier transform
2660.6|4.2|to compute the Fourier transform of the
2662.64|5.16|weights also compute the Fourier
2664.8|4.56|transform of our activation map and now
2667.8|2.45|in Fourier space we just do an
2669.36|2.7|element-wise
2670.25|4.78|multiplication which is really really
2672.06|5.79|fast and efficient and then we just come
2675.03|5.16|again use the fast Fourier transform to
2677.85|4.68|do the inverse transform on the output
2680.19|4.26|of that elemental s product and that
2682.53|6.48|implements convolutions for us in this
2684.45|7.62|kind of cool fancy clever way and this
2689.01|4.98|has actually been used and faced some
2692.07|3.87|folks at Facebook had a paper about this
2693.99|4.23|last year and they actually release the
2695.94|5.85|GPU library to do this to compute these
2698.22|6.15|things but the the sad thing about these
2701.79|4.02|Fourier transforms is that they actually
2704.37|3.96|give you really really big speed ups
2705.81|5.19|over other methods but really only for
2708.33|5.13|large filters and when you're working on
2711.0|4.08|these small 3x3 filters the overhead of
2713.46|3.54|computing the Fourier transform just
2715.08|4.77|Dwarfs the the computation of doing the
2717.0|5.55|computation directly in the in the input
2719.85|4.8|pixel space and as we just talked about
2722.55|3.99|earlier in the lecture those small
2724.65|4.38|convolutions are really really nice and
2726.54|4.47|appealing and great for for lots of
2729.03|3.66|reasons so it's a little bit of a shame
2731.01|3.99|that this fourier trick doesn't work out
2732.69|4.2|too well in practice but if for some
2735.0|3.81|reason you do want to compute really
2736.89|5.27|large convolutions then this is
2738.81|3.35|something you can try yeah
2755.54|4.96|I'm not entirely sure I'm actually not
2758.04|4.11|too involved in Fourier stuff but I
2760.5|9.24|imagine if you think it's a problem it's
2762.15|9.69|probably a problem yeah although another
2769.74|3.69|thing to point out is that one kind of
2771.84|3.6|downside about Fourier transforms
2773.43|4.35|convolutions is that they don't handle
2775.44|4.41|striding too well so for a normal
2777.78|3.72|computer when you're computing strided
2779.85|3.69|convolutions in sort of normal input
2781.5|4.17|space you only compute a small subset of
2783.54|3.51|those inner products so you actually
2785.67|2.94|save a lot of computation when you do
2787.05|3.75|striated convolutions on there like
2788.61|3.69|directly on the input space but the way
2790.8|3.42|you tend to implement strategy own
2792.3|4.35|volition x' in fourier transform space
2794.22|4.29|is you just compute the whole thing and
2796.65|6.45|then you throw out part of the data so
2798.51|6.87|that ends up not being very efficient so
2803.1|4.89|there's another trick that has not
2805.38|4.56|really become too I think too widely
2807.99|4.65|known yet but I really like it so I
2809.94|3.9|thought I wanted to talk about it so you
2812.64|3.03|may remember from an algorithms class
2813.84|4.65|something called strassens algorithm
2815.67|4.98|right there's this idea that when you do
2818.49|4.41|a naive matrix multiplication of two n
2820.65|4.29|by n matrices kind of if you count up
2822.9|4.26|all the all the all the multiplications
2824.94|3.72|and additions that you need to do it's
2827.16|3.9|going to take about it's going to take n
2828.66|4.23|cubed operations and strassens algorithm
2831.06|3.06|is this like really crazy thing where
2832.89|2.79|you compute all these crazy
2834.12|3.18|intermediates and it somehow magically
2835.68|3.48|works out to compute the output
2837.3|5.97|asymptotically faster than the naive
2839.16|7.23|method and you know from m2 call we know
2843.27|5.16|that matrix multiplication is this we
2846.39|4.08|can implement convolution as matrix
2848.43|3.72|multiplication so intuitively you might
2850.47|4.08|expect that these similar types of
2852.15|5.19|tricks might theoretically maybe be
2854.55|5.76|applicable to convolution and it turns
2857.34|4.71|out they are so there's this really cool
2860.31|4.17|paper that just came out over the summer
2862.05|5.64|where these two guys worked out very
2864.48|6.56|explicitly some very special cases for
2867.69|4.98|3x3 convolutions and it involves this
2871.04|3.43|obviously I'm not going to go into
2872.67|3.69|details here but it's a similar flavor
2874.47|4.14|to strassens algorithm where you're
2876.36|4.23|computing very clever intermediates and
2878.61|2.94|then recombining them to actually save a
2880.59|4.11|lot on
2881.55|5.19|mutation and these guys are actually
2884.7|3.9|really really intense and they are not
2886.74|3.9|just mathematicians they actually wrote
2888.6|4.16|also highly highly optimized CUDA
2890.64|4.95|kernels to compute these things and
2892.76|4.87|we're able to speed up vgg by a factor
2895.59|4.53|of two so that's really really
2897.63|4.2|impressive so I think that these these
2900.12|4.23|type this type of trick might become
2901.83|4.08|pretty popular in the future but for the
2904.35|4.5|time being I think it's not very widely
2905.91|4.74|used but these numbers are crazy and
2908.85|4.83|especially for small batch sizes they're
2910.65|4.35|getting a 6x speed up on vgg so that's
2913.68|3.54|that's really really impressive and I
2915.0|3.57|think it's a really cool method the
2917.22|2.94|downside is that you kind of have to
2918.57|3.18|work out these explicit special cases
2920.16|4.17|for each different size of convolution
2921.75|6.05|but maybe if we only care about 3x3
2924.33|3.47|convolutions that's not such a big deal
2927.95|5.68|so the the recap on computing
2931.11|5.07|convolutions in practice is that though
2933.63|4.17|sort of the really fast easy quick and
2936.18|4.44|dirty way to implement these things is
2937.8|4.8|into call matrix multiplication is fast
2940.62|3.9|it does it's usually not too hard to
2942.6|3.27|implement these things so if for some
2944.52|2.91|reason you really need to implement
2945.87|4.71|convolutions yourself I'd really
2947.43|5.01|recommend inter call FFT is something
2950.58|3.18|that coming from signal processing you
2952.44|3.72|might think would be really cool and
2953.76|5.01|really useful but it turns out that it's
2956.16|4.56|it does give speed ups but only for big
2958.77|4.14|filters so it's not as useful as you
2960.72|4.29|might have hoped but there is hope
2962.91|4.35|because these fast algorithms are really
2965.01|3.87|good at small filters and there already
2967.26|3.75|exists code somewhere in the world to do
2968.88|6.87|it so hopefully these these things will
2971.01|6.69|catch on and become more widely used so
2975.75|9.42|if there's any questions about computing
2977.7|10.17|convolutions no okay so next we're going
2985.17|6.33|to talk about some implementation
2987.87|4.8|details so first I have a question how
2991.5|6.09|many you guys have ever built your own
2992.67|6.93|computer some okay so you guys are
2997.59|8.04|prevented from this answering on this
2999.6|8.9|next slide so who can spot the CPU and
3005.63|2.87|you want to want to point it out
3010.94|5.919|yeah so the cpu is this little guy right
3014.49|4.829|so actually this this thing is actually
3016.859|5.311|a lot of it is the cooler so the CPU
3019.319|3.961|itself is a little tiny part inside of
3022.17|4.619|here a lot of this is actually the
3023.28|9.69|heatsink and the cooling so next who can
3026.789|7.731|spot the GPU yeah it's the thing this is
3032.97|5.31|geforce on it
3034.52|6.19|so this GPU is um for one thing it's
3038.28|4.86|it's much larger than the cpu so you
3040.71|6.06|might so it maybe is more powerful I
3043.14|5.28|don't know but at least it's taking up
3046.77|2.94|more space in the case so that's that's
3048.42|4.98|kind of an indication that something
3049.71|5.28|exciting is happening so um I have
3053.4|5.1|another question and you guys you know
3054.99|9.45|play video games okay then you probably
3058.5|7.89|have opinions about this so it turns out
3064.44|3.3|a lot of people in machine learning and
3066.39|3.959|deep learning have really strong
3067.74|6.75|opinions too and most people are on this
3070.349|7.2|side so Nvidia is actually much much
3074.49|4.98|more widely used than AMD for using GPUs
3077.549|4.76|in practice
3079.47|5.04|and the reason is that NVIDIA has really
3082.309|4.691|done a lot in the last couple years to
3084.51|5.069|really dive into deep learning and make
3087.0|5.4|it a really core part of their focus so
3089.579|6.661|as a cool example of that last year at
3092.4|5.879|GT C which is an Nvidia's sort of yearly
3096.24|4.829|big gigantic conference where they
3098.279|5.191|announced new products jensen hong who's
3101.069|5.371|the CEO of nvidia and actually also a
3103.47|4.74|Stanford alum introduced this latest and
3106.44|3.72|greatest amazing new GPU called the
3108.21|4.68|Titan X like their flagship thing and
3110.16|6.09|the benchmark he used to sell it was how
3112.89|5.55|fast it can train alex net so this was
3116.25|3.869|crazy um this was a gigantic room with
3118.44|3.119|like hundreds and hundreds of people and
3120.119|4.111|journalists and like this gigantic
3121.559|4.56|highly polished presentation and the CEO
3124.23|3.69|of nvidia was talking about alex net and
3126.119|4.111|convolutions and i thought that was
3127.92|3.689|really exciting and it kind of shows you
3130.23|2.819|that nvidia really cares a lot about
3131.609|3.601|getting these things to work and they
3133.049|6.03|pushed a lot of of their efforts into
3135.21|6.69|getting thing into making it work so
3139.079|4.081|just to give you an idea a cpu as you
3141.9|2.85|probably know is
3143.16|3.72|really good at fast sequential
3144.75|4.23|processing and they tend to have a small
3146.88|3.84|number of cores ones in your laptop
3148.98|4.11|probably have like maybe between one and
3150.72|5.85|four cores and big things on a server
3153.09|5.07|might have up to 16 cores ish and these
3156.57|3.54|things are really good at computing
3158.16|4.92|things really really fast and in
3160.11|5.4|sequence GPU is on the other hands tend
3163.08|4.17|to have many many many cores for a big
3165.51|4.11|guy like a tight necks it can have up to
3167.25|4.35|thousands of cores but they tend each
3169.62|3.63|core can do less they tend to run a
3171.6|4.76|lower clock speed and be able to do less
3173.25|5.28|per instruction cycle so these GPUs
3176.36|4.75|again were actually were originally
3178.53|5.94|developed for processing graphics grasp
3181.11|5.37|graphics processing units so they're
3184.47|4.17|really good at doing sort of highly
3186.48|3.51|paralyzed operations where you want to
3188.64|5.01|do many many things in parallel
3189.99|5.46|independently and since they were
3193.65|4.5|originally designed for computer
3195.45|4.17|graphics but since then they've sort of
3198.15|3.66|evolved as a more general computing
3199.62|3.39|platform so there are different
3201.81|3.69|frameworks that allow you to write
3203.01|5.82|generic code to run directly on the GPU
3205.5|5.01|so from Nvidia we have this framework
3208.83|4.14|called CUDA that lets you write a
3210.51|5.1|variant of C to actually write code that
3212.97|4.65|runs directly on the GPU and there's a
3215.61|3.51|similar framework called OpenCL that
3217.62|5.31|works on pretty much any any
3219.12|6.15|computational platform but I mean open
3222.93|4.5|standards are nice and it's quite nice
3225.27|5.07|that OpenCL works everywhere but in
3227.43|4.29|practice opens CUDA tends to be a lot
3230.34|3.81|more performance and have a little bit
3231.72|2.91|nicer library support so at least for
3234.15|3.24|deep learning
3234.63|4.38|most people use CUDA instead and if
3237.39|4.44|you're interested in actually learning
3239.01|5.04|how to write GPGPU code yourself there's
3241.83|3.48|a really cool audacity course I would
3244.05|2.85|it's it's pretty cool they have fun
3245.31|3.96|assignments all that but lets you write
3246.9|3.78|code to run things on the GPU although
3249.27|3.27|in practice if all you want to do is
3250.68|3.99|train commnets and do research and that
3252.54|3.33|sort of thing you end up usually not
3254.67|2.73|having to write any of this code
3255.87|4.57|yourself you just rely on external
3257.4|5.11|libraries yeah
3260.44|6.12|kind of like half a torch or does it
3262.51|5.15|provide yeah so cou DNN is I'll talk
3266.56|5.04|about that in a minute
3267.66|5.74|right so CUDA is like this this raw soku
3271.6|5.34|DNN is a higher higher level library
3273.4|5.16|kind of like ku blast right so one thing
3276.94|4.98|that GPUs are really really good at is
3278.56|4.83|matrix multiplication so here's here's a
3281.92|5.22|benchmark I mean this is from Nvidia's
3283.39|5.49|website so it's a little bit biased but
3287.14|4.74|this is showing a matrix multiplication
3288.88|5.91|of time as a function of matrix size a
3291.88|4.92|pretty beefy CPU this is a 12 core guy
3294.79|4.86|that would live in a server so that's
3296.8|4.56|like quite a quite a healthy CPU and
3299.65|3.69|this is running the same Nate size
3301.36|4.47|matrix multiply on a test like a 40
3303.34|5.1|which is a pretty beefy GPU and it's
3305.83|3.5|much faster I mean that's no big
3308.44|3.72|surprise right
3309.33|5.47|and GPUs are also really good at
3312.16|4.86|convolutions so as you mentioned NVIDIA
3314.8|5.1|has a library called ku DNN that is
3317.02|5.91|specifically optimized optimized CUDA
3319.9|6.18|kernels for convolution so compared to
3322.93|4.8|CPU I mean it's it's way faster and this
3326.08|4.71|is actually comparing the em to call
3327.73|6.0|convolutions from Caffe with the KU DNN
3330.79|4.65|convolutions I think these graphs are
3333.73|5.16|actually from the first version of ku
3335.44|5.88|DNN version 4 just came out maybe a week
3338.89|4.2|ago and but this is the only version
3341.32|3.51|where they actually had a CPU benchmark
3343.09|5.07|since then the benchmarks have only been
3344.83|6.21|against previous versions so it's gotten
3348.16|4.47|a lot faster since then since here but
3351.04|4.08|the way this the way this fits in is
3352.63|5.19|that something like Kubb laughs or qdn n
3355.12|5.7|is a C library so it provides functions
3357.82|5.82|in C that just sort of abstract away to
3360.82|5.88|GPU as a C library so if you have a
3363.64|4.59|tensor sort of in in memory in C you can
3366.7|3.57|just pass a pointer to the Kuti and on
3368.23|3.18|library and it'll return the complet
3370.27|4.2|will run it on the GPU maybe
3371.41|5.34|asynchronously and return the result
3374.47|5.55|so frameworks like cafe and torch all
3376.75|5.07|have now integrated the KU DNN stuff
3380.02|3.54|into their own frameworks so you can
3381.82|6.15|utilize these efficient convolutions in
3383.56|6.6|any of these frameworks now but the
3387.97|4.44|problem is that even when once we have
3390.16|4.41|these really powerful GPUs training big
3392.41|5.01|models is still kind of slow
3394.57|4.74|so vgg net was famously trained for
3397.42|3.99|something like two to few weeks on for
3399.31|4.44|Titan what was it Titan blacks and those
3401.41|4.08|aren't cheap and it was actually a
3403.75|3.36|reimplementation of ResNet recently
3405.49|3.12|there's a really cool write-up
3407.11|4.35|there's really cool blog post describing
3408.61|5.64|it here and they actually retrained the
3411.46|6.45|ResNet 101 layer model and it also took
3414.25|7.61|about two weeks to train on four GPUs so
3417.91|6.42|that's not good and one way that people
3421.86|5.17|the way that the easy way to split up
3424.33|5.61|training across multiple GPUs is just to
3427.03|5.49|split your mini batch across the GPUs so
3429.94|4.5|normally you might have you especially
3432.52|3.81|for something like vgg it takes a lot of
3434.44|3.87|memory so you can't compute with very
3436.33|4.32|large mini batch sizes on a single GPU
3438.31|5.34|so what you'll do is you'll have a mini
3440.65|4.44|batch of images maybe of six 128 or
3443.65|3.27|something like that you'll split the
3445.09|4.35|mini batch into four equal chunks on
3446.92|3.93|each on each GPU you'll compute a
3449.44|3.63|forward and a backward pass for that
3450.85|4.32|mini batch um and you'll compute
3453.07|4.86|parameter aadience on the weights you'll
3455.17|4.62|sum those weights inside you'll sum
3457.93|4.83|those weights after all four GPUs finish
3459.79|5.25|and make a update to your model so this
3462.76|5.19|is a really simple way that people tend
3465.04|10.59|to implement a distribution and GPUs
3467.95|9.09|yeah yeah yeah yeah so that's one of the
3475.63|2.85|cool pictures of tensorflow is they
3477.04|2.94|claim that they can automate this
3478.48|3.18|process and really really efficiently
3479.98|3.54|distribute it which is really exciting I
3481.66|4.44|think but um I haven't played around
3483.52|4.56|with it too much myself yet and also at
3486.1|3.51|least in torch there's a data parallel
3488.08|3.09|layer that you can just drop in and use
3489.61|4.62|that'll sort of automatically do this
3491.17|5.76|type of parallelism very easily a
3494.23|4.62|slightly more complex idea for multi-gpu
3496.93|5.19|training actually comes from Alex
3498.85|5.49|Krakowski of Alex net Fame he has that's
3502.12|5.1|kind of a cool kind of a funny title but
3504.34|5.49|the idea but the idea is that we want to
3507.22|4.77|actually do data parallelism on the
3509.83|4.35|lower layers so on the lower layers
3511.99|5.46|we'll take our image mini-batch split it
3514.18|6.6|up across two GPUs and eat and GPU one
3517.45|5.16|will compute the convolutions for the
3520.78|4.89|first part first part of the mini batch
3522.61|4.56|and just at least just this convolution
3525.67|2.49|part will be distributed equally across
3527.17|2.79|the G
3528.16|4.08|but once you get to the fully connected
3529.96|3.96|layers he found it's actually more
3532.24|3.84|efficient if you because those are just
3533.92|4.08|really big matrix multiplies then it's
3536.08|3.48|more efficient to actually have the GPUs
3538.0|4.349|work together to compute this matrix
3539.56|4.77|multiply so this is kind of a cool trick
3542.349|5.611|it's not very commonly used but I
3544.33|7.32|thought it's it's fun to mention another
3547.96|5.67|idea from Google is before before there
3551.65|3.6|was tensor flow they had this thing
3553.63|4.59|called disbelief which was their their
3555.25|5.82|previous system which was entirely CPU
3558.22|4.32|based which from the benchmarks a few
3561.07|3.539|slides ago you can imagine was going to
3562.54|3.78|be really slow but actually the first
3564.609|4.74|version of Google net was all trained in
3566.32|4.5|disbelief on CPU so they actually so
3569.349|3.211|they had to do massive amounts of
3570.82|4.83|distribution on CPU to get these things
3572.56|4.86|to Train so here there's this cool paper
3575.65|3.87|from Jeff Dean a couple years ago that
3577.42|4.02|describes this in a lot more detail but
3579.52|4.11|you use data parallelism or you have
3581.44|5.19|each machine have an independent copy of
3583.63|4.38|the model and you each machine is
3586.63|3.33|computing forward and backward on
3588.01|3.48|batches of data but now it actually you
3589.96|3.3|actually have this parameter server
3591.49|4.109|that's storing the parameters of the
3593.26|4.2|model and these independent workers are
3595.599|5.401|making communication with the parameter
3597.46|4.889|server to make updates on the model and
3601.0|4.53|they contrast this with model
3602.349|5.061|parallelism which is where you have one
3605.53|3.96|big model and you have different
3607.41|4.51|different workers computing different
3609.49|4.859|parts of the model so in in disbelief
3611.92|4.11|they really did a really good job
3614.349|3.75|optimizing this to work really well
3616.03|5.67|across many many CPUs and many many
3618.099|5.161|machines but now they have tensorflow
3621.7|3.899|which hopefully should do these things
3623.26|5.37|more automatically and once you're doing
3625.599|5.551|these these these updates there's this
3628.63|6.15|idea between asynchronous SGD and
3631.15|5.939|synchronous SGD so synchronous SGD is
3634.78|4.11|kind of the thing like the naive thing
3637.089|3.51|you might expect you have a mini batch
3638.89|3.9|you split it up across multiple workers
3640.599|4.621|each worker does forward and backward
3642.79|3.87|computes gradients then you add up all
3645.22|4.59|the gradients and make a single model
3646.66|5.64|update this will this will sort of
3649.81|4.71|exactly simulate just computing that
3652.3|3.51|mini batch on a larger machine but it
3654.52|3.839|could be kind of slow since you have to
3655.81|4.47|synchronize across machines this tends
3658.359|3.101|to not be too much of a big deal when
3660.28|3.45|you're working with multiple
3661.46|4.77|on a single node but once you're
3663.73|4.81|distributing this across many many CPUs
3666.23|4.71|that district that synchronization can
3668.54|4.65|actually be quite expensive so instead
3670.94|5.01|at least they also have this concept of
3673.19|4.649|asynchronous SGD where each model is
3675.95|4.05|just sort of making updates to the to
3677.839|4.5|its own copy of the parameters and those
3680.0|3.96|have some notion event of eventual
3682.339|3.451|consistency where they sometimes
3683.96|4.56|periodically synchronize with each other
3685.79|6.41|and it's seems really complicated and
3688.52|3.68|hard to debug but they got it to work so
3692.319|4.51|that's that's pretty cool and one of the
3694.849|3.601|really cool pitches so these two figures
3696.829|4.081|are both from the tensorflow paper and
3698.45|3.99|one of the pitches of tensorflow is that
3700.91|3.449|it should really make this type of
3702.44|3.96|distribution much more transparent to
3704.359|4.621|the user that if you do happen to have
3706.4|5.189|access to a big cluster of GPUs and CPUs
3708.98|4.53|and and whatnot tensorflow should
3711.589|3.24|automatically be able to figure out the
3713.51|3.63|best way to do these kinds of
3714.829|4.881|distributions combining data and model
3717.14|4.65|parallelism and just do it all for you
3719.71|3.52|so that's that's really cool and I think
3721.79|3.95|that's that's the really exciting part
3723.23|4.71|about tensorflow
3725.74|9.069|any any questions about distributed
3727.94|11.46|training yeah on C n TK I haven't I
3734.809|6.661|haven't taken a look at it yet okay so
3739.4|5.54|next there's a couple bottlenecks you
3741.47|5.28|should be aware of in practice so
3744.94|3.49|especially when you're training these
3746.75|3.27|things like this distributed stuff is
3748.43|3.21|nice and great but you can actually go a
3750.02|4.079|long way with just a single GPU on a
3751.64|4.169|single machine and there there's a lot
3754.099|4.561|of bottlenecks that can get in the way
3755.809|6.391|one is the communication between the CPU
3758.66|5.85|and the GPU actually in a lot of cases
3762.2|3.84|especially when the data is small the
3764.51|3.45|most expensive part of the pipeline is
3766.04|4.14|copying the data on to the GPU and then
3767.96|4.44|copying it back once you get things onto
3770.18|4.619|the GPU you can do computation really
3772.4|5.37|really fast and efficiently but the
3774.799|5.371|copying is the really slow part so one
3777.77|4.89|one idea is you want to make sure to
3780.17|5.25|avoid the memory copy like one thing
3782.66|4.53|that sometimes you see is like you'll at
3785.42|4.05|each layer the network is copying back
3787.19|3.48|and forth from CPU to GPU and that'll be
3789.47|3.119|really inefficient and slow everything
3790.67|3.3|down so ideally you want the whole
3792.589|5.161|forward and backward pass to
3793.97|5.67|run all on the GPU at once another thing
3797.75|4.23|you'll sometimes see is a multi-threaded
3799.64|5.52|approach where you'll have a CPU thread
3801.98|5.85|that is a prefetching data off disk or
3805.16|4.59|off menu off memory in one thread in the
3807.83|5.1|background possibly also applying data
3809.75|5.13|augmentations online and then this this
3812.93|3.9|background CPU thread will be sort of
3814.88|4.05|preparing mini batches and possibly also
3816.83|3.81|shipping them over to GPU so you can
3818.93|3.72|kind of coordinate this loading of data
3820.64|4.83|and computing pre processing and
3822.65|4.56|shipping memory shipping the mini batch
3825.47|3.84|data to the GPU and actually doing the
3827.21|3.81|computations and actually you can get
3829.31|3.03|pretty involved with coordinating all
3831.02|2.76|the all these things in a multi-threaded
3832.34|5.91|way and that can give you some good
3833.78|6.329|speed ups so cafe in particular I think
3838.25|3.24|already implements this pre fetching
3840.109|3.51|data layer for certain types of data
3841.49|5.4|storages and in other frameworks you
3843.619|5.581|just have to roll your own another
3846.89|5.1|problem is the the CPU disk bottleneck
3849.2|5.25|so these these things are kind of slow
3851.99|5.82|they're cheap and they're big but they
3854.45|5.37|actually are not the best so as a so
3857.81|3.72|these are hard disks that
3859.82|3.42|now these solid-state drives are much
3861.53|3.27|more common but the problem is that
3863.24|4.14|solid-state drives are you know smaller
3864.8|3.96|and more expensive but they're a lot
3867.38|4.229|faster so they get used a lot in
3868.76|5.19|practice so what's really although one
3871.609|4.441|one common feature to both hard disks
3873.95|3.21|and solid-state drives is that they work
3876.05|3.87|best when you're reading data
3877.16|4.83|sequentially off the disk so a lot of
3879.92|3.81|times what you'll write so one thing
3881.99|4.19|that would be really bad for example is
3883.73|4.8|to have a big folder full of JPEG images
3886.18|4.12|because now each of these images could
3888.53|3.63|be located in different parts on the
3890.3|3.69|disk so it could be really you'd up to
3892.16|4.35|do a random seek to read any individual
3893.99|3.96|JPEG image and now also once you read
3896.51|3.23|the JPEG you'd have to decompress it
3897.95|4.2|into pixels so that's quite inefficient
3899.74|4.54|so what you'll see a lot of times in
3902.15|4.53|practice is that you'll actually pre
3904.28|4.17|process your data by decompressing it
3906.68|3.659|and just writing out the raw pixels for
3908.45|5.13|your entire data set in one giant
3910.339|5.701|contiguous file to disk so that that
3913.58|3.99|takes a lot of disk space but we do it
3916.04|4.04|anyway because it's all for the good of
3917.57|2.51|the calmness
3920.9|5.879|right so this is so in cafe we do this
3923.42|5.73|with a couple with like a leveldb is one
3926.779|3.661|commonly used format I've also used I
3929.15|4.35|also use hdf5
3930.44|5.099|files a lot for this but the idea is
3933.5|5.73|that you want to just get your data all
3935.539|5.851|sequentially on disk and already turned
3939.23|3.75|into pixels so in a training when you're
3941.39|2.969|training you can't store all your data
3942.98|3.089|in memory you have to read it off disk
3944.359|4.321|then you want to make that read as fast
3946.069|3.75|as possible and again you with clever
3948.68|3.96|amounts of prefetching and
3949.819|4.2|multi-threaded stuff you might have you
3952.64|2.82|might have one thread fetching data off
3954.019|4.681|disk while other computation is
3955.46|5.49|happening in the background another
3958.7|6.24|thing to keep in mind is GPU memory
3960.95|6.869|bottlenecks so GPUs um big ones have
3964.94|5.429|whoa big ones have a lot of memory but
3967.819|4.891|not that much so the biggest GPUs you
3970.369|3.92|can buy right now are the Titan X and
3972.71|3.899|the K forty have twelve gigs of memory
3974.289|4.631|and that's pretty much as big as you're
3976.609|5.25|going to get right now next gen should
3978.92|4.349|be bigger but you can actually bump up
3981.859|2.67|against this limit without too much
3983.269|3.81|trouble especially if you're training
3984.529|4.53|something like a res net or a bgg or if
3987.079|4.47|you're having recurrent networks for a
3989.059|4.081|very very very long time steps it's
3991.549|3.181|actually not too hard to bump up against
3993.14|2.85|this memory limit so that's something
3994.73|3.299|you need to keep in mind when you're
3995.99|4.17|training these things and some of these
3998.029|4.111|points about you know these efficient
4000.16|3.959|convolutions and cleverly creating
4002.14|3.929|architectures actually helps with this
4004.119|4.74|memory as well if you can have a bigger
4006.069|5.611|more powerful model with smaller amounts
4008.859|4.531|of width in use less memory then you'll
4011.68|3.21|be able to train things faster and use
4013.39|5.07|bigger mini-batches and everything is
4014.89|5.399|good and even just just for a sense of
4018.46|3.27|scale ALX net is pretty small with
4020.289|3.51|compared to a lot of the models that are
4021.73|4.2|state-of-the-art now but Alex net with a
4023.799|4.381|256 batch size already takes about three
4025.93|3.81|gigabytes of GPU memory so once you move
4028.18|3.329|to these bigger networks it's actually
4029.74|6.0|not too hard to bump up against the 12
4031.509|6.02|gig limit so another thing we should
4035.74|5.309|talk about is floating-point precision
4037.529|5.77|so we when I'm writing code a lot of
4041.049|3.72|times I like to imagine that you know
4043.299|3.091|these things are just real numbers and
4044.769|3.181|they just work but in practice that's
4046.39|3.09|not true and you need to think about
4047.95|4.379|things like how many bits of
4049.48|4.05|floating-point are you using so most
4052.329|3.001|types of
4053.53|3.93|types of numeric code that you might
4055.33|5.55|write sort of is with a double precision
4057.46|6.42|by default so this is using 64 bits and
4060.88|5.07|a lot of also very calm or commonly used
4063.88|5.52|for deep learning is this idea of single
4065.95|5.76|precision so this is only 32 bits so the
4069.4|3.96|idea is that if each number takes fewer
4071.71|3.06|bits then you can store more of those
4073.36|4.35|numbers within the same amount of memory
4074.77|4.62|so that's good and also with fewer bits
4077.71|3.39|you need less compute to operate on
4079.39|3.9|those numbers so that's also good
4081.1|4.11|so in general we would like to have
4083.29|3.18|smaller data types because they're
4085.21|5.91|faster to compute and they use less
4086.47|6.0|memory and as a case study this was
4091.12|4.17|actually even an issue on the homework
4092.47|5.34|so you may have noticed that in numpy
4095.29|4.56|the default data type is this 64-bit
4097.81|3.54|double-precision but for all of these
4099.85|4.41|models that we provided you on the
4101.35|4.5|homework we had this cast to a 32-bit
4104.26|2.91|floating-point number and you can
4105.85|2.79|actually go back on the homework and try
4107.17|3.6|switching between these two and you'll
4108.64|4.26|see that switching to the 32-bit
4110.77|6.33|actually gives you some decent some
4112.9|6.689|decent speed ups so then the obvious
4117.1|5.37|question is that if 32 bits are better
4119.589|12.631|than 64 bits then maybe we can use less
4122.47|13.23|than that right so there's this right so
4132.22|6.21|there's this idea of using 16 bits hmm
4135.7|5.13|what's the best order to do these right
4138.43|4.74|okay so in addition to 32-bit
4140.83|4.62|floating-point there's also a standard
4143.17|4.649|for a 16-bit floating-point which is
4145.45|4.23|sometimes called 1/2 precision and
4147.819|3.601|actually recent versions of cout DNN do
4149.68|4.83|support computing things in half
4151.42|6.54|precision so that's cool and actually
4154.51|5.46|there there are some other other
4157.96|4.379|existing implementations from a company
4159.97|4.38|called Nirvana who also has these 16-bit
4162.339|3.451|implementations so these are the fastest
4164.35|4.469|convolutions out there right now
4165.79|5.1|so these there's this nice github repo
4168.819|3.211|that has different kinds of ComNet
4170.89|2.4|benchmarks for different types of
4172.03|3.09|convolutions and frameworks and
4173.29|3.39|everything and pretty much everything
4175.12|3.179|winning all these benchmarks right now
4176.68|3.69|are these 16-bit floating-point
4178.299|3.871|operations from Nirvana which is not
4180.37|3.929|surprising right because again you have
4182.17|4.71|fewer bits so it's faster to compete
4184.299|3.091|with them but right now there's actually
4186.88|2.76|not
4187.39|3.99|framework support in things like cafe or
4189.64|3.81|torch for utilizing the 16-bit
4191.38|5.88|computation but it should be coming very
4193.45|6.45|soon but the problem is that even if we
4197.26|4.38|can compute oh it's it's pretty obvious
4199.9|4.14|that if you have 16-bit numbers you can
4201.64|4.56|compete with them very fast but once you
4204.04|5.01|get to 16 bit then you might actually be
4206.2|4.83|worried about numeric precision because
4209.05|2.7|2 to the 16 is not that big of a number
4211.03|2.04|anymore
4211.75|4.17|so there's actually not too many real
4213.07|4.17|numbers you can even represent so there
4215.92|6.51|was this paper from a couple years ago
4217.24|7.05|that um it did some experiments on a low
4222.43|3.81|precision floating point and they found
4224.29|3.39|that actually just using so the
4226.24|2.43|experiment they actually use a fixed
4227.68|3.39|width rather than a floating-point
4228.67|6.15|implementation and they found that
4231.07|5.58|actually with these very with with this
4234.82|3.42|sort of naive implementation of this low
4236.65|3.11|of these low precision methods the
4238.24|3.81|networks had a hard time converging
4239.76|4.69|they'd probably due to these low
4242.05|3.87|precision numeric numeric issues that
4244.45|3.75|kind of accumulate over multiple rounds
4245.92|4.02|of multiplication and whatnot but they
4248.2|4.29|found a simple trick was actually this
4249.94|4.62|idea of stochastic rounding so some of
4252.49|3.75|their multiplications would so all their
4254.56|3.51|parameters and activations are stored in
4256.24|3.9|16-bit but when they perform a
4258.07|3.81|multiplication they up convert to a
4260.14|3.99|slightly higher precision floating point
4261.88|3.54|value and then they still cast they
4264.13|3.63|round that back down to a lower
4265.42|5.16|precision and actually doing that
4267.76|4.26|rounding in a stochastic way that is not
4270.58|3.99|rounding to the nearest number but
4272.02|4.59|probabilistically rounding to I to
4274.57|4.37|different numbers depending on how close
4276.61|5.1|you are tends to work better in practice
4278.94|5.05|so they found that for example when
4281.71|4.38|you're using a so these were 16-bit
4283.99|5.43|fixed point numbers with two bits for
4286.09|5.1|integers and between 12 and 14 bits for
4289.42|3.78|the floating point for the for the
4291.19|4.05|fractional part that when you use this
4293.2|4.23|idea of always rounding to the nearest
4295.24|4.44|number these networks tend to diverge
4297.43|4.17|but when you use these stochastic
4299.68|3.27|rounding techniques then you can
4301.6|3.42|actually get these networks to converge
4302.95|3.84|quite nicely even with these very low
4305.02|5.52|precision floating point technique low
4306.79|5.94|precision floating point numbers but you
4310.54|4.889|might want to ask well 16-bit is great
4312.73|5.94|but can we go even lower than that
4315.429|6.601|there was another paper in 2015 that got
4318.67|5.4|down to ten and twelve bits so here that
4322.03|4.109|the I mean from the previous paper we
4324.07|3.48|already had this intuition that maybe
4326.139|3.181|when you're using very low precision
4327.55|3.659|floating point numbers you actually need
4329.32|3.6|to use more precision in some parts of
4331.209|3.93|the network and lower precision in other
4332.92|4.17|parts of the network so in this paper
4335.139|5.73|they were able to get away with using
4337.09|7.02|storing the activations in ten bit ten
4340.869|6.15|bit values and doing computing gradients
4344.11|6.96|using twelve bits and they got this to
4347.019|5.37|work which is pretty amazing but anyone
4351.07|5.149|think that that's the limit can we go
4352.389|6.96|further yes
4356.219|7.75|there was actually a paper just last
4359.349|6.69|week so this is actually the from the
4363.969|4.201|same author as the previous paper and
4366.039|4.551|this is crazy I was I was amazed about
4368.17|4.38|this and here the idea is that all
4370.59|4.33|activations and weights of the network
4372.55|5.1|use only one bit there either one or
4374.92|4.44|negative one so that's pretty fast to
4377.65|3.21|compute now you don't even really have
4379.36|3.739|to do multiplication you can just do
4380.86|5.25|like bitwise X nor to multiply those
4383.099|5.11|that's pretty cool but the trick is that
4386.11|4.079|on the forward pass all of the gradients
4388.209|4.171|and activations are either one or minus
4390.189|4.441|one so it's super the forward pass is
4392.38|4.079|super super fast and efficient but now
4394.63|3.089|on the backward pass they actually
4396.459|3.66|compute gradients using a higher
4397.719|4.201|precision and then these higher
4400.119|3.96|precision gradients are used to actually
4401.92|4.65|make updates to these single bit
4404.079|3.931|parameters so it's it's it's actually a
4406.57|3.6|really cool paper and I'd encourage you
4408.01|5.009|to check it out but the pitch is that um
4410.17|4.289|it may be a training time you can afford
4413.019|3.45|to use maybe a more floating-point
4414.459|3.72|precision but then at test time you want
4416.469|4.8|your network to be super super fast and
4418.179|5.34|all binary so I think this is a really
4421.269|3.901|really cool idea that I mean the paper
4423.519|3.06|just came out two weeks ago so I don't
4425.17|5.369|know but I think it's a pretty cool
4426.579|6.36|thing so the the recap from
4430.539|4.91|implementation details is that overall
4432.939|4.47|GPUs are much much faster than CPUs
4435.449|3.79|sometimes people use distributed
4437.409|4.83|training distributing over multiple GPUs
4439.239|4.621|in one system is pretty common if you're
4442.239|4.021|Google and using tensorflow then
4443.86|5.009|distributing over multiple nodes is
4446.26|3.03|maybe more common be aware of different
4448.869|2.011|kinds
4449.29|3.72|bottlenecks between the CPU and the GPU
4450.88|5.28|between the GPU in the disk and between
4453.01|5.67|the GPU memory and also pay attention to
4456.16|4.02|floating-point precision it might not be
4458.68|2.85|the most glamorous thing but it actually
4460.18|3.6|I think makes huge differences in
4461.53|3.69|practice and maybe binary nuts will be
4463.78|4.8|the next big thing that'd be pretty
4465.22|5.37|exciting so yeah just to recap
4468.58|3.72|everything we talked about today that we
4470.59|4.47|talked about data augmentation as a
4472.3|5.13|trick for improving when you have small
4475.06|3.87|datasets and help prevent overfitting we
4477.43|3.33|talked about transfer learning as a way
4478.93|3.17|to initialize from existing models to
4480.76|3.48|help with your help with your training
4482.1|4.81|we talked in a lot of detail about
4484.24|4.14|convolutions both how to combine them to
4486.91|2.82|make efficient models and how to compute
4488.38|4.56|them and we talked about all these
4489.73|5.25|implementation details so I think that's
4492.94|4.73|that's all we have for today so if
4494.98|2.69|there's any last-minute questions
4498.84|3.91|alright so I guess we're done a couple
4501.13|3.8|minutes early and our mid the midterms
4502.75|2.18|are