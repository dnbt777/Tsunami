start_time|end_time|text
0.03|4.559|terms of administrative items everyone
2.7|3.929|should be done with 7/3 now if you're
4.589|3.51|not done I think you're late and you're
6.629|3.3|in trouble
8.099|3.031|milestone grades will be out very soon
9.929|2.611|we're still getting through them and
11.13|2.4|they're basically I think done but we
12.54|3.389|have to double-check a few things and
13.53|3.78|we'll send them out okay so in terms of
15.929|3.36|reminding you where we are in the class
17.31|3.69|last class we looked very briefly at
19.289|3.601|segmentation we looked at some soft
21.0|3.72|attention models soft attention models
22.89|3.0|are a way for selectively paying
24.72|2.43|attention to different parts of the
25.89|2.1|image as you're processing it with
27.15|2.91|something like a recurrent neural
27.99|3.9|network so it allows you to selectively
30.06|3.929|pay attention to some parts of the scene
31.89|3.329|and enhance those features and we also
33.989|3.211|talked about spatial transformer which
35.219|3.691|is this very nice way of basically in a
37.2|4.35|differentiable way cropping parts of an
38.91|4.2|image or some features either in an
41.55|3.48|affine region or in any kind of warped
43.11|4.289|shape or anything like that so very
45.03|3.57|interesting kind of piece eek that you
47.399|3.061|can slot into your neural network
48.6|5.849|architectures so today we will talk
50.46|5.4|about videos specifically now in image
54.449|2.761|classification you should be familiar by
55.86|2.699|now with the basic column that set up
57.21|2.79|you have an image that comes in and
58.559|3.871|we're processing it to for example
60.0|3.809|classified in a case of videos we want
62.43|3.93|to have just a single image but we'll
63.809|4.021|have multiple frames so this is an image
66.36|3.72|of 32 by 32 we'll actually have an
67.83|6.0|entire video of frames so 32 by 32 by T
70.08|5.1|where T is some time extent okay so
73.83|2.49|before I dive into how we approach these
75.18|2.549|problems with convolutional neural
76.32|3.63|networks I'd like to talk very briefly
77.729|3.93|about how we used to address them before
79.95|4.2|combats came about using feature based
81.659|4.14|methods so some of the most popular
84.15|4.44|features are right before convolutional
85.799|4.621|networks and I became very popular where
88.59|4.23|these dense trajectory features are
90.42|3.75|developed by Heng Weng at all and I just
92.82|2.58|like to give you a brief taste of
94.17|2.879|exactly how these features worked
95.4|2.91|because it's kind of interesting and
97.049|2.28|they inspire some of the later
98.31|2.4|developments in terms of how
99.329|3.961|convolutional networks actually operate
100.71|4.019|over videos so in this trajectory is
103.29|3.3|what we do is we have this video that's
104.729|3.811|playing and we're going to be detecting
106.59|3.569|these key points that are good to track
108.54|3.149|in a video and then we're going to be
110.159|3.6|tracking them and you end up with all
111.689|4.71|these little track Lots that we actually
113.759|4.021|track across the video and then lots of
116.399|2.881|features about those track lots and
117.78|2.82|about the surrounding features that
119.28|3.39|accumulated in that histograms
120.6|3.809|so just to give you an idea about how
122.67|5.28|this worked there's basically three
124.409|5.88|steps roughly we detect feature points
127.95|3.75|at different scales in the image I'll
130.289|2.081|tell you briefly about how that's done
131.7|2.289|in a bit
132.37|3.509|then we're going to track those features
133.989|3.541|over time using optical flow methods
135.879|3.36|optical flow methods
137.53|3.48|I'll explain very briefly they basically
139.239|3.091|give you a motion field from one frame
141.01|3.479|to another and they tell you how the
142.33|3.96|seam moved from one frame to a next to
144.489|3.601|next frame and then we're going to
146.29|3.029|extract a whole bunch of features but
148.09|2.72|importantly we're not just going to
149.319|3.541|extract those features at fixed
150.81|3.16|positions in the image but we're
152.86|2.31|actually going to be extracting these
153.97|3.989|features in the local coordinate system
155.17|4.379|of every single track ilat and so these
157.959|3.991|histogram of gradients histogram of
159.549|3.841|flows and MBH features we're going to be
161.95|4.53|extracting them in the coordinate system
163.39|4.17|of a track lit and so Hogg here we saw
166.48|2.399|histograms of gradients and
167.56|3.81|two-dimensional images there are
168.879|4.381|basically generalizations of that to
171.37|3.81|videos and so that's the kind of things
173.26|4.47|that people use to encode little spatial
175.18|6.179|temporal volumes so in terms of the key
177.73|5.069|point detection part there's been quite
181.359|3.061|a lot of work on exactly how to detect
182.799|3.06|good features and videos to track and
184.42|3.09|intuitively you don't want to track
185.859|3.391|regions in the video that are too smooth
187.51|3.119|because you can't lock onto any visual
189.25|3.359|feature and so there are ways for
190.629|5.101|basically getting a set of points that
192.609|4.921|are easy to track in a video so there
195.73|4.05|are some papers on this so you detect a
197.53|5.429|bunch of features like this then you run
199.78|5.069|optical flow algorithms on these videos
202.959|3.601|so an optical flow algorithm will take a
204.849|3.661|frame and a second frame and it will
206.56|4.709|solve for a motion field a displacement
208.51|4.47|vector at every single position into
211.269|3.961|where it traveled or how the frame moved
212.98|5.28|and so here are some examples of optical
215.23|6.33|flow results basically here every single
218.26|5.339|pixel is colored by a direction in which
221.56|4.2|that part of the image is currently
223.599|4.11|moving in the video so for example this
225.76|3.9|girl has all yellow meaning that she's
227.709|3.84|probably translating horizontally or
229.66|3.509|something like that the two most common
231.549|4.05|methods for using optical flow or for
233.169|3.991|computing it at least maybe one of the
235.599|3.0|most common ones here is Brocks from
237.16|3.329|Brock's and Malik that's the one that is
238.599|3.42|kind of like a default thing to use so
240.489|2.761|if you are computing optical flow in
242.019|3.211|your own project I would encourage you
243.25|3.629|to use this large displacement optical
245.23|3.93|flow method
246.879|3.841|so using this optical flow we have all
249.16|3.21|these key points using optical flow we
250.72|3.659|know also how they move and so we end up
252.37|4.679|tracking these load track lots of maybe
254.379|4.32|roughly 15 frames at a time so we end up
257.049|3.69|with these half a second roughly track
258.699|5.041|Lots through the video and then we
260.739|4.891|encode regions around these track Lots
263.74|3.06|with all these descriptors
265.63|2.82|and then we need to accumulate all these
266.8|3.78|visual features into histograms and
268.45|4.11|people used to play with different kinds
270.58|4.47|of like how do you exactly truncate
272.56|3.72|video spatially because we're going to
275.05|2.67|have a histogram and independent
276.28|3.39|histogram and every one of these bins
277.72|4.08|and then we're going to basically create
279.67|3.81|all these histograms per bin with all
281.8|3.72|these visual features and all of this
283.48|3.48|then goes into an SVM and that was kind
285.52|2.58|of the rough layout in terms of how
286.96|5.55|people address these problems in the
288.1|6.36|past question yes sir track let's just
292.51|5.79|think of it as it's going to be 15
294.46|6.24|frames and it's just XY positions so a
298.3|4.98|15 XY coordinates that's a track load
300.7|5.7|and then we extract features in the
303.28|4.8|local coordinate system now in terms of
306.4|5.19|how we actually approach these problems
308.08|5.31|with convolutional neural networks so
311.59|3.3|you may recall alex net on the very
313.39|3.78|first layer will receive an image that
314.89|4.23|is for example 227 by 2 2 + 7 by 3 and
317.17|5.1|we're processing it with 96 filters that
319.12|4.32|are 11 by 11 applied it's tried 4 and so
322.27|5.16|we saw that with an Alex net this
323.44|5.58|results in the 55 by 55 by 96 volume in
327.43|3.03|which we actually have all these
329.02|3.93|responses of all the filters at every
330.46|4.23|single spatial position so now what
332.95|3.33|would be a reasonable approach if you
334.69|3.21|wanted to generalize a convolutional
336.28|4.29|network into a case where you don't just
337.9|4.59|have a 227 by 2 10 27 by 3 but you maybe
340.57|4.17|have 15 frames that you'd like to encode
342.49|4.8|so you have an entire block of 227 by 2
344.74|4.05|27 by 3 by 15 that's coming in to a
347.29|3.0|convolutional network and you're trying
348.79|3.6|to encode both the spatial and temporal
350.29|4.65|patterns and inside this little block of
352.39|4.71|volume so it would be like one idea for
354.94|9.23|how to change a convolutional net work
357.1|7.07|or generalize it to this case oh god
368.3|6.36|they made and create a food by food
371.82|6.03|critic and placing me this side-by-side
374.66|5.26|okay it's interesting so you're saying
377.85|3.99|that you you basically took four frames
379.92|6.96|and you arranged them as like two blocks
381.84|6.9|right okay that's interesting okay I
386.88|5.66|would expect that to not work very very
388.74|5.79|well okay so the problem with that is
392.54|3.28|that's kind of interesting basically all
394.53|2.67|these neurons they're looking at only a
395.82|3.09|single frame and then by the end of the
397.2|3.06|con that you end up with neurons that
398.91|2.88|are looking at larger and larger regions
400.26|3.24|in the original image so eventually
401.79|3.54|these neurons would see all of your
403.5|5.64|input but they would not be able to very
405.33|6.93|easily relate the little spatial
409.14|6.74|temporal patch in this image so I'm not
412.26|3.62|sure actually that's a real good idea
416.69|7.51|okay good could you tie an LSD em into
422.52|11.16|it I think so we'll get to some methods
424.2|10.83|that do something like that good okay so
433.68|3.3|that's maybe a good idea so maybe you
435.03|3.42|would take so right now we have three
436.98|2.79|channels and maybe you will take these
438.45|2.88|frames and you'll actually just stack
439.77|3.63|them across channels so you'll end up
441.33|3.93|with 45 channels effectively and you
443.4|4.02|could put a comm that on that so that's
445.26|3.45|something that I'll get to I think in
447.42|13.47|the end you could do that I don't think
448.71|14.4|it's the best idea as well yes so you're
460.89|4.23|saying that things in one slice of this
463.11|4.56|time are you want to extract similar
465.12|5.1|kinds of features in one time then a
467.67|4.47|different time similar to the motivation
470.22|3.51|of doing it sharing weight spatially
472.14|3.21|because features here are useful down
473.73|2.76|there as well so you have the same kind
475.35|4.53|of property where you'd like to share
476.49|5.13|weights in time not only in space okay
479.88|3.78|so building on top of that idea the
481.62|3.3|basic thing that people usually do when
483.66|3.12|they want to apply complement networks
484.92|3.93|on videos is they extend these filters
486.78|3.72|not only so you don't only have filters
488.85|4.74|in space but you also have these filters
490.5|5.37|and extend them small amounts in time so
493.59|3.72|before we have 11 by 11 filters so now
495.87|4.23|we're just going to have 11 by 11 by T
497.31|4.379|filters where T is some small temporal
500.1|3.839|extent so say for example
501.689|4.65|can use a 2 up to 15 in this particular
503.939|5.46|case so for example if T was 3 then we
506.339|5.37|have 11 by 11 by 3 filters and then by 3
509.399|4.92|because we have RGB and so basically
511.709|4.44|these filters are now you're thinking of
514.319|3.96|sliding filters not only in space and
516.149|3.841|carving out an entire activation map but
518.279|3.51|you're actually sliding filters not only
519.99|3.75|in space but also in time and they have
521.789|3.631|a small finite temporal extent in time
523.74|3.779|and you end up carving out an entire
525.42|3.959|activation volume okay so you're
527.519|3.841|introducing this time dimension into all
529.379|3.121|your kernels and to all your volumes
531.36|2.669|they just have an additional time
532.5|4.019|dimension along which we're performing
534.029|4.951|the convolutions so that's usually how
536.519|5.041|people extract the features and then you
538.98|5.01|get this property where say T is 3 here
541.56|3.629|and so then when we do the spatial
543.99|3.149|temporal convolution we end up with this
545.189|4.741|parameter sharing scheme going in time
547.139|4.411|as well as you mentioned so basically we
549.93|3.12|just extend all the filters in time and
551.55|3.18|then we do convolutions not only in
553.05|3.42|space but also in time we end up with
554.73|4.469|activation volumes instead of activation
556.47|5.4|maps okay so some of these approaches
559.199|4.351|were proposed quite early on for example
561.87|3.6|one of the earlier ones for in a context
563.55|4.68|of activity recognition is maybe from
565.47|4.469|2010 so the idea here was that this is
568.23|3.27|just a convolutional Network but instead
569.939|4.02|of getting a single input of 60 by 40
571.5|4.62|pixels we are getting in fact seven
573.959|4.261|frames of 60 by 40 and then there
576.12|3.959|convolutions our 3d convolutions as we
578.22|3.75|refer to them so these filters for
580.079|4.021|example might be seven by seven but now
581.97|5.909|by three as well as we end up with a 3d
584.1|6.229|comm and these three conditions are
587.879|5.101|applied at every single stage here
590.329|4.75|similar paper also in from 2011 with the
592.98|3.93|same idea we have a block of frames
595.079|3.45|coming in and you process them with 3d
596.91|2.909|convolutions we have three dimensional
598.529|3.42|convolutional filters at every single
599.819|6.181|point in this convolutional network so
601.949|6.36|this is in 2011 a very similar idea also
606.0|3.809|so these are from before actually Alec's
608.309|3.181|net these approaches are kind of like
609.809|3.811|smaller neural network and convolutional
611.49|5.339|network so the first kind of large-scale
613.62|6.439|application of this was from this
616.829|7.95|awesome paper in 2014 by carpaccio tall
620.059|7.421|so this is for processing videos so the
624.779|4.86|model here on the very right that week
627.48|3.57|we called slow fusion that is the same
629.639|3.45|idea that I presented so far these are
631.05|4.8|three-dimensional convolutions happening
633.089|4.5|in both space and time and so that's
635.85|3.03|slow fusion as we refer to it because
637.589|2.641|you're slowly fusing this temporal
638.88|3.68|information just as before we were
640.23|4.5|slowly fusing the spatial information
642.56|4.089|now there are other ways that you could
644.73|3.06|also wire up convolutional networks and
646.649|3.42|just to give you some context
647.79|4.529|historically this is I was in Google
650.069|3.661|research and Aleks Nets just came out
652.319|4.08|and everyone was super excited because
653.73|4.469|they were extremely well on images and I
656.399|4.261|was in the video analysis team at Google
658.199|4.38|and we wanted to run commnets on the
660.66|4.38|YouTube videos and but it was not quite
662.579|4.231|clear exactly how to generalize you know
665.04|3.18|commercial networks and images to videos
666.81|2.61|and so we explored several kinds of
668.22|3.66|architectures of how you could actually
669.42|5.31|wire this up so float slow Fusion is a
671.88|6.389|3d column kind of approach early fusion
674.73|5.49|is this idea that someone described
678.269|3.12|earlier where you take a chunk of frames
680.22|2.76|and you just concatenate them along
681.389|4.411|channels so you might end up with a to
682.98|4.589|27 by to 27 by like 45 well everything
685.8|4.68|is just stacked up and you do a single
687.569|4.921|comp over it so it's kind of like your
690.48|4.89|filters on the very first comp lawyer
692.49|3.81|have a large temporal extent but from
695.37|2.07|then on everything else is
696.3|3.209|two-dimensional composition
697.44|3.54|so in fact we call it early fusion
699.509|3.241|because if used the temporal information
700.98|3.299|very early on in the very first layer
702.75|3.839|and from then on everything's just 2d
704.279|4.351|calm you can imagine architectures like
706.589|3.87|LED convolution so here the idea is we
708.63|3.66|take two alex nets we place them say ten
710.459|4.23|frames apart so they both compute
712.29|4.44|independently on these ten frames apart
714.689|4.14|and then we merge them much later in the
716.73|3.51|fully connected layers and then we had a
718.829|3.06|single flame baseline that is only
720.24|3.39|looking at a single frame of a video so
721.889|5.13|you can play with exactly how your wire
723.63|4.62|up these models for this low fusion
727.019|4.17|model you can imagine that if you have
728.25|4.5|three-dimensional kernels now on the
731.189|2.58|first layer you can actually visualize
732.75|3.3|them and these are the kinds of features
733.769|3.361|you end up learning on videos so these
736.05|2.399|are basically the features that we're
737.13|3.329|familiar with except they're moving
738.449|3.841|because now these filters are also
740.459|3.69|extended a small amount in time so you
742.29|3.06|have these little moving blobs and some
744.149|2.701|of them are static and some of them are
745.35|4.62|moving and they're basically detecting
746.85|4.799|motion on the very first layer and so
749.97|3.799|you end up with nice moving volumes go
751.649|2.12|ahead
757.12|6.07|so I thought we should try to make a
759.74|5.37|small yeah so your question is how much
763.19|3.69|do we extend this in temporal length for
765.11|3.24|the filters we'll get to that and I
766.88|4.41|think the answer is probably yes
768.35|4.049|just as in spatial it works better if
771.29|3.359|you have smaller filters and you have
772.399|3.451|more depth at the same applies I think
774.649|9.271|in time and we'll see an architecture
775.85|9.51|that does that in a bit good I say so in
783.92|3.96|these cases oops
785.36|5.55|in these cases we're expecting the same
787.88|4.44|we're just classifying every single so
790.91|2.85|we have a video and we're still
792.32|3.269|classifying fixed number of categories
793.76|3.18|at every single frame but now your
795.589|3.031|prediction is not only a function of
796.94|4.769|that single frame but also a small
798.62|5.13|number of frames a lot a lot on both
801.709|3.511|sides so maybe your prediction is
803.75|4.44|actually a function of say 15 frames
805.22|5.609|half a second of video so we end up with
808.19|4.889|fun moving filters in this paper also
810.829|4.591|released a video data set of 1 million
813.079|3.75|videos in 500 classes just to give you a
815.42|4.37|context for why this is actually it's
816.829|6.061|kind of difficult to work with videos in
819.79|4.989|right now I think because problem right
822.89|3.96|now I think is that there's not too many
824.779|3.781|very large-scale data sets like on the
826.85|3.12|order of millions of very varied images
828.56|2.94|that you see an image net there are no
829.97|3.359|really good equivalents of that in the
831.5|3.75|video domain and so we tried with this
833.329|3.63|sports data set back in 2013 but I don't
835.25|3.72|think it actually we fully achieved that
836.959|3.541|and I think we're still not seeing very
838.97|3.119|good really large-scale data sets and
840.5|3.029|videos and that's partly why we're also
842.089|4.321|slightly discouraging some of you from
843.529|4.291|working on this on projects because you
846.41|3.119|can't pre train these very powerful
847.82|5.13|features because the data sets are just
849.529|5.041|not right there another kind of
852.95|3.09|interesting things that you see and this
854.57|4.829|is why we also sometimes caution people
856.04|4.919|from working on videos and getting very
859.399|3.391|elaborate very quickly with them is
860.959|2.791|because sometimes people they think they
862.79|2.549|have videos and they get very excited
863.75|3.029|they want to do 3d convolution cell
865.339|3.271|STM's and they just think about all the
866.779|3.571|possibilities that open up before them
868.61|3.63|but actually it turns out that single
870.35|3.179|frame methods are a very strong baseline
872.24|3.15|and I would always encourage you to run
873.529|3.391|that first so don't worry about the
875.39|3.509|motion in your video and just try single
876.92|3.27|frame networks first so for example in
878.899|4.44|this paper we found that a single frame
880.19|4.86|baseline was about 59.3% classification
883.339|3.301|accuracy in our data set and then we
885.05|3.63|tried our best to actually take into
886.64|5.37|account small local motion but
888.68|5.31|we ended up only bumping that by 1.6% so
892.01|3.18|all this extra work all the extra
893.99|2.88|compute and then you ended up with
895.19|3.27|relatively small gains and I'm going to
896.87|4.17|try to tell you why that might be
898.46|4.35|but basically video is not always as
901.04|5.489|useful as you might intuitively think
902.81|5.85|and so here are some examples of kind of
906.529|3.631|predictions that we these are different
908.66|3.48|datasets of sports and our predictions
910.16|4.32|and I think this kind of highlights
912.14|4.44|slightly why adding video might not be
914.48|3.359|as helpful in some settings so in
916.58|2.85|particular here if you're trying to
917.839|3.841|distinguish sports and think about
919.43|4.56|trying to distinguish say tennis from
921.68|3.45|swimming or something like that it turns
923.99|2.7|out that you actually don't need very
925.13|2.519|fine local motion information if you're
926.69|2.94|trying to distinguish tennis from
927.649|3.961|swimming right lots of blue stuff lots
929.63|3.72|of red stuff like the images actually
931.61|2.94|have a huge amount of information and so
933.35|2.91|you're putting in a lot of additional
934.55|4.289|parameters and trying to go after these
936.26|4.71|local motions but in most in most
938.839|3.75|classes actually these local motions are
940.97|3.42|not very important they're only
942.589|3.181|important if you have very fine-grained
944.39|3.33|categories where the small motion
945.77|3.36|actually really matters a lot and so a
947.72|4.59|lot of you if you have videos you'll be
949.13|5.19|inclined to use a spatio-temporal crazy
952.31|4.98|video networks but think very hard about
954.32|4.769|is that local motion extremely important
957.29|2.97|in your setting because if it isn't you
959.089|2.311|might end up with results like this
960.26|3.72|where you put in a lot of work and it
961.4|5.09|might not work extremely well let's look
963.98|5.01|at some other video classification
966.49|4.96|convolutional networks so this is babe
968.99|4.77|from 2015 it's relatively popular it's
971.45|4.41|called c3d and the idea here was
973.76|3.9|basically vgg network has this very nice
975.86|3.27|architecture where it's three by three
977.66|3.51|columns and two by two pool throughout
979.13|3.3|so the idea here is that basically let's
981.17|2.85|do the exact same thing but extend
982.43|3.69|everything in time so going back to your
984.02|4.14|point you want very small filters so
986.12|3.99|this is everything is 3 by 3 by 3 column
988.16|3.84|2 by 2 by 2 pool throughout the
990.11|4.44|architecture so it's a very simple kind
992.0|4.23|of vgg net in 3d kind of approach and
994.55|4.2|that works reasonably well and you can
996.23|3.84|look at this paper for reference another
998.75|3.779|form of approaches actually that works
1000.07|5.55|quite well is from Karen Simonian in
1002.529|4.831|2014 Karen Simonian by the way is of vgg
1005.62|3.36|net fame he's a person who came up with
1007.36|3.81|the vgg net he also has a very nice
1008.98|3.599|paper on video classification and the
1011.17|2.82|idea here is that he didn't want to do
1012.579|2.461|three-dimensional convolutions because
1013.99|3.66|it's kind of painful to have it
1015.04|4.26|implemented or find it and so on so he
1017.65|4.119|only used two-dimensional convolutions
1019.3|5.349|but the idea here is that we
1021.769|4.621|to commnets looking at an image and the
1024.649|4.5|other one is looking at optical flow of
1026.39|5.039|the video so both of these are just
1029.149|4.471|images but the optical flow basically it
1031.429|4.74|tells you how things are moving in in
1033.62|4.74|the image and so both of these are just
1036.169|4.26|kind of like a navvy Ginette like or
1038.36|3.449|Alex net like ComNet one of them on
1040.429|3.72|optical flow one of them on the image
1041.809|3.36|and you extract optical flow we say the
1044.149|3.871|Brock's method that I've shown you
1045.169|4.801|before and then you let you fuse that
1048.02|3.69|information very late in the end so both
1049.97|3.24|of these come up with some idea about
1051.71|3.06|what they are seeing in terms of the
1053.21|2.76|classes in the video and then you fuse
1054.77|3.06|them and there are different ways of
1055.97|4.92|using them and so they found for example
1057.83|5.16|that if you just use a spatial combat so
1060.89|4.47|it's only looking at images you get some
1062.99|3.9|performance if you use ComNet on just
1065.36|2.85|the optical flow it actually performs
1066.89|3.18|even slightly better than just looking
1068.21|3.99|at the raw images so optical flow
1070.07|4.469|actually here in this case contains a
1072.2|3.81|lot of information and then if you fuse
1074.539|3.451|them you actually end up performing even
1076.01|4.11|better now an interesting point to make
1077.99|3.65|here by the way is that if you have this
1080.12|3.84|kind of architecture especially here
1081.64|3.909|complex this three by three by three
1083.96|3.87|filters you might imagine that actually
1085.549|4.411|would think that I mean why does it help
1087.83|3.36|to actually put an optical flow you'd
1089.96|2.76|imagine that in this end-to-end
1091.19|3.03|framework we're hoping that these come
1092.72|2.91|let's learn everything from scratch in
1094.22|3.179|particular they should be able to learn
1095.63|4.86|something that simulates the computation
1097.399|4.74|of computing optical flow and it turns
1100.49|3.659|out that that might not be the case
1102.139|4.681|because sometimes when you compare video
1104.149|4.291|networks on only the raw pixels and then
1106.82|4.069|you add optical flow it works better and
1108.44|4.709|so I think the reason for that is
1110.889|4.39|probably comes back to actually data
1113.149|3.66|since we don't have enough data we have
1115.279|2.971|small amount of data I think you
1116.809|2.941|actually probably don't have enough data
1118.25|4.799|to actually learn very good optical flow
1119.75|4.649|like features and so that would be my
1123.049|2.551|particular answer why actually
1124.399|2.731|hard-coding optical flow into the
1125.6|3.209|network is probably helping out in many
1127.13|3.24|cases so if you guys are working on your
1128.809|3.031|projects with videos I would encourage
1130.37|3.24|you to actually try maybe this kind of
1131.84|2.88|architecture where you extract optical
1133.61|2.789|flow and then you pretend that it's an
1134.72|3.179|image and you put comments on it and you
1136.399|4.351|merge it and so that seems like a
1137.899|4.5|relatively reasonable approach okay so
1140.75|4.799|so far we've only talked about little
1142.399|4.711|local information in time right so we
1145.549|3.12|have these little piece of like
1147.11|2.64|movements say of like half a second and
1148.669|3.12|we're trying to take advantage of it to
1149.75|3.69|do better classification but what
1151.789|3.681|happens if you have videos that actually
1153.44|4.13|have much longer temporal
1155.47|4.23|temporal kind of dependencies that you'd
1157.57|3.359|like to model so it's not only that the
1159.7|2.55|local motion is important but actually
1160.929|3.181|there are some events throughout the
1162.25|3.27|video that are much larger in timescale
1164.11|3.809|than your network and they actually
1165.52|3.87|matter so event to happening after event
1167.919|3.211|one could be very indicative of some
1169.39|4.14|class and you'd like to actually model
1171.13|3.299|that weather with a neural network so
1173.53|3.29|what are the kinds of approaches that
1174.429|5.671|you might think for trying to actually
1176.82|4.42|you know how would you modify the
1180.1|6.59|architecture to actually model these
1181.24|5.45|kinds of much longer-term events good
1187.44|6.52|okay so tension model perhaps so you may
1191.26|3.99|be like to have an attention over you're
1193.96|2.25|trying to classify this entire chunk of
1195.25|2.309|video and maybe you'd like to have
1196.21|12.449|attention over different parts of the
1197.559|12.75|video yeah accessible idea good I see
1208.659|3.931|yeah that's a good idea so you're saying
1210.309|4.11|that we have these multi scale
1212.59|3.839|approaches where we process images on
1214.419|3.51|very low detail level but also sometimes
1216.429|3.781|we resize the images and process them on
1217.929|3.63|the global level and so maybe the frames
1220.21|3.48|we can actually like speed up the video
1221.559|3.901|and put a comment on that I don't think
1223.69|4.349|that's very common but it's a sensible
1225.46|4.5|idea I think yeah it's good so the
1228.039|5.101|problem roughly is that basically this
1229.96|4.98|temporal extent is maybe sometimes too
1233.14|3.63|short it doesn't span entire as many
1234.94|3.03|seconds so how do we make architectures
1236.77|7.68|that are function of much longer
1237.97|8.61|timescales in their prediction good ok
1244.45|3.839|yeah so one idea here is we have this
1246.58|2.61|video and we have different classes that
1248.289|2.281|we'd like to predict at every single
1249.19|2.94|point in time but we want that
1250.57|3.51|prediction to be a function not only
1252.13|4.08|after the low like chunk of 0.5 seconds
1254.08|4.29|but actually a much longer time extents
1256.21|3.329|and so the idea that is accessible is
1258.37|2.49|you actually use recurrent neural
1259.539|2.851|networks somewhere in the architecture
1260.86|3.78|because recurrent networks allow you to
1262.39|3.539|have infinite context and principle over
1264.64|3.63|everything that has happened before you
1265.929|3.48|up till that time so actually if you go
1268.27|3.659|back to this paper that I've already
1269.409|4.081|shown you in 2011 it turns out that they
1271.929|4.201|have an entire section where they take
1273.49|4.35|this and they actually have an LS DM
1276.13|4.35|that does exactly that so this is a
1277.84|5.459|paper from 2011 using 3d column and LS
1280.48|5.04|DMS way before they well cool in 2011
1283.299|4.681|and so this paper basically has it all
1285.52|3.28|they model little local motion with 3d
1287.98|3.88|calm and
1288.8|4.83|model global motion with LS DMS and so
1291.86|3.39|they put Alice teams on a say the full
1293.63|2.79|connected layers so they strength
1295.25|2.85|together fully connected layers with
1296.42|3.09|this recurrence and then when you're
1298.1|3.78|predicting classes every single frame
1299.51|5.13|you have infinite context and so this
1301.88|4.86|paper is is I think quite ahead of its
1304.64|3.45|time and it basically has it all except
1306.74|2.67|it's only cited sixty five times I'm not
1308.09|3.57|sure why it's not more popular I think
1309.41|3.92|people I don't know but basically this
1311.66|3.27|is a way ahead of its time paper that
1313.33|3.28|recognizes both of these and actually
1314.93|4.38|use ostians wait before I even knew
1316.61|4.26|about them so since then there are
1319.31|3.66|several more recent papers that actually
1320.87|4.53|kind of take this similar approach so in
1322.97|4.11|2015 by Jeff Donohue a'tall from
1325.4|3.6|Berkeley the idea here is that you have
1327.08|3.84|video and you'd like to again classify
1329.0|3.48|every single frame but they have these
1330.92|3.72|comments that look at individual frames
1332.48|4.74|but then they have also lsdm that string
1334.64|4.47|this together temporarily a similar idea
1337.22|4.35|also from a paper from I think this is
1339.11|4.59|Google and so the idea here is that they
1341.57|3.75|have optical flow and images both are
1343.7|3.42|processed by commnets and then again you
1345.32|5.97|have an LS DM that merges that over time
1347.12|7.29|so again this this combination of local
1351.29|4.59|and global so so far we've looked at
1354.41|3.42|kind of two architectural patterns in
1355.88|3.33|accomplishing video classification that
1357.83|5.28|actually takes into account temporal
1359.21|5.46|information modeling local motion which
1363.11|4.29|for example we extend 3d cover we use
1364.67|4.02|optical flow or look more global motion
1367.4|2.79|where we have lsdm that string together
1368.69|4.59|sequences of learning time steps or
1370.19|5.22|fusions of the two now actually I like
1373.28|4.71|to make the point that there's another
1375.41|5.19|cleaner very nice interesting idea that
1377.99|4.47|I saw in the recent paper and that I
1380.6|3.6|like much more and so here's basically
1382.46|4.32|the rough picture of what things look
1384.2|4.59|like right now we have some video and we
1386.78|3.78|have a 3d ComNet say that is using
1388.79|6.42|optical flow maybe or it's using 3d comm
1390.56|6.3|or both on a chunk of frame chunk of
1395.21|2.91|your data and then you have RNs on the
1396.86|2.34|top on the fully connected layer or
1398.12|3.54|something like that that are doing the
1399.2|4.2|long term modeling and so kind of what's
1401.66|3.27|kind of not very nice or unsettling
1403.4|4.17|about this is that there's kind of this
1404.93|4.08|ugly asymmetry about these components so
1407.57|3.24|you have these part these neurons inside
1409.01|3.96|the 3d comm that are only a function of
1410.81|3.36|some small local chunk of video and then
1412.97|2.61|you have these neurons on the very top
1414.17|4.23|that are function of everything in the
1415.58|4.44|video because they're recurrent units
1418.4|3.81|that are a function of everything has
1420.02|2.94|become come before it and so it's kind
1422.21|3.93|of like an
1422.96|4.71|a symmetry or something like that so
1426.14|3.45|there's a paper that has a very clever a
1427.67|3.69|neat idea from a few weeks ago that is
1429.59|4.44|much more nice and homogeneous in a VG
1431.36|4.53|net-like style where everything is very
1434.03|3.72|nice in the modulus and simple and so I
1435.89|5.97|don't know if anyone can think of how we
1437.75|8.43|could what we could do to to make
1441.86|5.4|everything much more cleaner and I
1446.18|2.46|couldn't because I didn't come up with
1447.26|7.8|this idea but I thought it was cool once
1448.64|8.85|I read it good interesting
1455.06|4.02|you want to do the Ireland before the
1457.49|5.22|calm that actually starts processing the
1459.08|4.95|images I'm not sure what that would give
1462.71|2.61|you so you would have our NS on the raw
1464.03|3.96|pixel information and then come that's
1465.32|4.26|on top of it somehow
1467.99|4.32|you would certainly have neurons that
1469.58|3.72|are a function of everything but it's
1472.31|2.16|not clear what the Ellis team would be
1473.3|2.97|doing in that case like would it be
1474.47|3.87|blurring the pixels it's too low level
1476.27|4.8|probably processing at that point good
1478.34|5.07|so it seems like one of the problems is
1481.07|4.53|that in video there's so much duplicate
1483.41|4.17|information between two frames that like
1485.6|3.21|it there's a lot of redundancy if you're
1487.58|3.03|only looking at a few frames so you
1488.81|4.11|could have maybe like an in Samba love
1490.61|4.32|confidence that looks at different like
1492.92|3.6|temporal resolutions so this comment is
1494.93|3.21|looking every frame right but you could
1496.52|3.15|have another confident that's looking
1498.14|3.18|like every two frames every four frames
1499.67|4.2|every eight frames and then you can feed
1501.32|3.81|all of those things are in it I see so
1503.87|2.85|your idea is that I think it's similar
1505.13|2.73|to what someone pointed out where you
1506.72|3.06|take this video and you work on multiple
1507.86|3.27|scales of that video so you speed up the
1509.78|4.07|video and you slow down the video and
1511.13|5.31|then you have 3d commnets on different
1513.85|9.67|temporal like speeds or something like
1516.44|8.49|that I think it's a sensible idea could
1523.52|2.52|you do background subtraction only look
1524.93|2.85|at things that are interesting to look
1526.04|3.96|at I think that's a reasonable idea I
1527.78|3.51|think it kind of goes against this idea
1530.0|2.79|of having end-to-end learning because
1531.29|4.13|you're introducing like this explicit
1532.79|6.98|computation that you think is useful I
1535.42|4.35|see yeah good
1541.32|6.88|can we have weight sharing between the
1543.67|6.81|3d ComNet and the RN that's interesting
1548.2|3.75|I'm not 100% sure because the RNN is
1550.48|2.7|just a hidden state vector and you're
1551.95|3.09|doing matrix multiplies and things like
1553.18|3.3|that but in the conv layers we have this
1555.04|5.87|like spatial structure so I'm not
1556.48|4.43|actually sure how the sharing would work
1561.66|8.08|but yeah maybe okay so the idea is that
1566.11|5.43|we're going to let's see we're going to
1569.74|3.33|get rid of the RNN we're going to
1571.54|2.97|basically take a con that and we're
1573.07|3.24|going to make every single neuron in
1574.51|3.42|that ComNet be a small recurrent neural
1576.31|3.09|network like every single neuron becomes
1577.93|4.32|recurrent in the ComNet
1579.4|4.86|okay so the way this will work and I
1582.25|4.98|think this is beautiful but their
1584.26|4.44|picture is kind of kind of ugly so I'm
1587.23|2.49|not sure this mix makes sense so let me
1588.7|4.58|try to explain this in a slightly
1589.72|5.91|different way what we'll do instead is
1593.28|3.58|so in a normal comment we have a convoy
1595.63|3.78|or somewhere in the neural network and
1596.86|3.75|it takes input from below the output of
1599.41|2.76|a previous comp layer something like
1600.61|3.03|that and we're doing convolutions over
1602.17|4.23|this to compute the output at this layer
1603.64|4.53|right so the idea here is we're going to
1606.4|4.71|make every single convolutional layer a
1608.17|5.31|kind of a recurrent layer and so the way
1611.11|4.44|we do that is we just as before we take
1613.48|4.02|the input from below us and we do
1615.55|3.48|columns over it but we also take our
1617.5|4.83|previous output from the previous time
1619.03|4.95|time step of this complex output so
1622.33|3.63|that's this comp lawyer from previous
1623.98|4.05|time step in addition to the current
1625.96|4.08|input that this time step and we do
1628.03|4.89|convolutions over both this one and that
1630.04|3.9|one and then we kind of have you know we
1632.92|3.75|don't call then we have these
1633.94|3.93|activations from current input and we
1636.67|4.2|have activations from our previous
1637.87|4.32|output and we add them up or something
1640.87|3.87|like that we do a recurrent like
1642.19|5.22|recurrent neural network like merge of
1644.74|3.96|those two to produce our output and so
1647.41|2.61|we're a function of the current input
1648.7|4.22|but we're also a function of our
1650.02|5.7|previous activations if that makes sense
1652.92|4.0|and so what's very nice about this is
1655.72|2.4|that we're in fact only using
1656.92|3.84|two-dimensional convolutions here
1658.12|4.02|there's no 3d comp anywhere because both
1660.76|3.27|of these are width by height by depth
1662.14|3.27|right so the previous column volume is
1664.03|3.12|just width height depth from the
1665.41|4.2|previous layer and we are with high
1667.15|3.72|depth from previous time and so both of
1669.61|2.89|these are two-dimensional convolutions
1670.87|5.71|but we end up with kind of
1672.5|5.25|recurrent process in here and so one way
1676.58|2.49|to see this also with recurrent neural
1677.75|3.39|networks which we've looked at is that
1679.07|3.42|you have this recurrence where you're
1681.14|2.49|trying to compute your hidden state and
1682.49|3.96|it's a function of your previous hidden
1683.63|4.08|state and the current input X and so we
1686.45|3.0|looked at many different ways of
1687.71|3.81|actually wiring up that recurrence so
1689.45|5.25|there's a vanilla RN n or an LSD M or
1691.52|5.22|there's a GRU which GRU is a simpler
1694.7|3.72|version of an LSD M if you recall but it
1696.74|3.99|almost always has similar performance to
1698.42|3.78|an LSD M so GRU has slightly different
1700.73|3.15|update formulas for actually performing
1702.2|3.45|that recurrence and so what they do in
1703.88|3.48|this paper is basically they take the
1705.65|3.3|GRU because it's a simpler version of an
1707.36|3.42|Alice TM that works almost just as well
1708.95|3.57|but instead of every single matrix
1710.78|4.74|multiply it's kind of like replaced with
1712.52|4.62|a comm if you can if you can imagine
1715.52|4.83|that so every single matrix multiplied
1717.14|5.22|here just becomes a comm so we convolve
1720.35|3.93|over our input and we convolve our
1722.36|3.72|output and that's the before and the
1724.28|3.78|below and then we combine them with the
1726.08|4.01|recurrence just as in the GRU to
1728.06|5.1|actually get our occupations and so
1730.09|6.7|before it looked like this and now it
1733.16|5.67|basically just looks like that so we
1736.79|3.87|don't have some parts being infinite in
1738.83|3.81|extent and some parts finite we just
1740.66|4.41|have this RNN ComNet where every single
1742.64|3.78|layer is recurrent it's computing what
1745.07|3.57|it did before but also it's a function
1746.42|3.98|of its previous outputs and so this RN
1748.64|4.32|income that is a function of everything
1750.4|3.88|and it's very kind of uniform it's kind
1752.96|2.7|of like a VG net you just do three by
1754.28|3.66|three comma two by two Macs bowl and
1755.66|3.15|your recurrent and that's it maybe
1757.94|3.42|that's just the answer
1758.81|6.48|nicest simplest thing so in summary
1761.36|5.25|whoops where's my summary so if you'd
1765.29|2.94|like to use spatial temporal
1766.61|3.18|convolutional networks in your project
1768.23|2.85|and you're very excited because you have
1769.79|3.69|videos the first thing you should do is
1771.08|3.93|stop and you should think about whether
1773.48|3.45|or not you really need to process local
1775.01|3.36|motion or global motion or if motion is
1776.93|3.45|really important to your classification
1778.37|3.6|task if you really think motion is
1780.38|3.12|important to you then think about
1781.97|3.27|whether or not you need to model local
1783.5|3.54|motions are those are important or all
1785.24|3.27|the global motions very important based
1787.04|3.3|on that you get a hint of what you
1788.51|3.39|should try but you always have to
1790.34|3.36|compare that to a single frame baseline
1791.9|3.36|I would say and then you should try
1793.7|3.12|using optical flow because it seems that
1795.26|4.41|if you especially have smaller amount of
1796.82|4.02|data it actually is very important it's
1799.67|3.48|like a very nice signal to actually
1800.84|3.72|encode that and explicitly specify that
1803.15|2.2|optical flow is a useful feature to look
1804.56|3.219|at
1805.35|4.14|and you can try this GRU RCN network
1807.779|3.451|that I've shown you just now but I think
1809.49|3.149|this is too recent and experimental so
1811.23|3.0|I'm actually not sure if I can fully
1812.639|3.12|endorse this or if it works it seems
1814.23|4.76|like it's a very nice idea but it hasn't
1815.759|5.371|kind of been proven yet and so that's
1818.99|3.49|that's kind of like the rough layout of
1821.13|3.509|how people process videos in the field
1822.48|6.079|so and if there's any questions because
1824.639|3.92|justin is going to come next good
1833.269|9.37|architecture like GRU are seeing so this
1835.679|8.161|one hasn't been used for a LP that's a
1842.639|3.42|good question I don't think so I'm not
1843.84|4.26|super duper expert on NLP but I haven't
1846.059|3.75|seen this idea before so I would I would
1848.1|18.51|guess that I haven't seen yeah I'm not
1849.809|21.921|sure I don't think so good so does it
1866.61|6.36|look more like this then yeah okay yeah
1871.73|7.929|okay
1872.97|8.64|question do people take into account
1879.659|3.781|networks that also taken audio and
1881.61|3.449|somehow consider it in on the side with
1883.44|3.449|a video I would say that that's
1885.059|4.62|definitely something people would want
1886.889|5.101|to do you don't see too many papers that
1889.679|3.571|do both of them just because people like
1891.99|3.569|to kind of isolate these problems and
1893.25|3.299|tackle them maybe not jointly but
1895.559|2.431|certainly if you're in a company or in
1896.549|2.61|trying to get something working in a
1897.99|3.72|real system you would do something like
1899.159|4.11|that but I don't think that there's
1901.71|2.969|anything that you would do you'd
1903.269|3.15|probably do this with a late fusion
1904.679|3.181|approach where you have a whatever works
1906.419|2.911|best on videos whatever works best on
1907.86|3.21|audio and then you merge that somewhere
1909.33|3.449|later somehow but that's certainly
1911.07|4.29|something you can do yeah so good idea
1912.779|3.691|and with Clinton with the neural
1915.36|2.1|networks right it's very simple because
1916.47|2.339|you just have a fully connected layer
1917.46|2.73|that's looking at the output of both at
1918.809|4.5|some point and then you're classifying
1920.19|3.599|as a function of both yeah all right
1923.309|2.791|cool
1923.789|5.88|so we're going to go into unsurprised
1926.1|4.74|learning all right I guess we have to
1929.669|2.97|get you this
1930.84|11.73|yeah our first tag-team lecture
1932.639|17.37|hopefully it works alright can you hear
1942.57|9.329|me is that is that hooked up okay okay
1950.009|2.851|so I guess for the rest of the lecture
1951.899|2.821|we're going to switch gears completely
1952.86|4.5|and entirely and talk about unsupervised
1954.72|5.61|learning so I'd like to make a little
1957.36|4.409|bit of a contrast here that first we're
1960.33|2.819|going to talk about some sort of basic
1961.769|3.091|definitions around unsupervised learning
1963.149|3.51|then we're going to talk about two
1964.86|3.899|different sort of ways that unsupervised
1966.659|4.291|learning has recently been attacked it
1968.759|3.66|by deep learning people so in particular
1970.95|3.0|we're going to talk about autoencoders
1972.419|4.551|and then this idea of adversarial
1973.95|5.37|networks and I guess I need my clicker
1976.97|4.539|right so pretty much everything we've
1979.32|4.589|seen in this class so far is supervised
1981.509|3.66|learning so the basic set up behind
1983.909|3.6|pretty much all supervised learning
1985.169|4.74|problems is that we assume that our data
1987.509|5.13|set has sort of each data point has sort
1989.909|4.831|of two distinct parts we have our data X
1992.639|4.14|and then we have some label or output Y
1994.74|4.319|that we want to produce from that from
1996.779|3.811|that input and our whole goal in
1999.059|4.021|supervised learning is to learn some
2000.59|5.459|function that takes in our input X and
2003.08|5.669|then produces this output or label Y and
2006.049|4.141|if you really think about it pretty much
2008.749|3.54|almost everything we've seen in this
2010.19|4.229|class is some instance of this
2012.289|4.38|supervised learning setup so for
2014.419|4.47|something like image classification X is
2016.669|4.561|an image and then Y is a label for
2018.889|4.081|something like object detection X is an
2021.23|3.21|image and then Y is maybe a set of
2022.97|3.99|objects in the image that you want to
2024.44|4.53|find Y it could be a caption and then we
2026.96|4.289|look at captioning X could be a video
2028.97|4.589|and now Y could be either a label or a
2031.249|5.071|caption or pretty much anything anything
2033.559|4.62|so I just want to make the point that
2036.32|3.839|supervised learning is this very very
2038.179|4.11|very powerful powerful and generic
2040.159|4.051|framework that incumbent encompasses
2042.289|4.681|everything we've done in the class so
2044.21|4.409|far and the other point is that
2046.97|3.0|supervised learning actually makes
2048.619|3.421|system that work systems that work
2049.97|4.31|really well in practice and is very
2052.04|4.23|useful for practical applications
2054.28|3.67|unsupervised learning I think is a
2056.27|3.96|little bit more of an open research
2057.95|4.32|question at this point in time so it's
2060.23|4.199|really cool I think it's really
2062.27|3.899|important for solving AI and Jenner
2064.429|3.42|but at this point it's maybe a little
2066.169|4.111|bit more of a research focused type of
2067.849|4.921|area it's also a little bit less well
2070.28|4.92|defined so if in unsupervised learning
2072.77|4.77|we generally assume that we have just
2075.2|5.699|data we only have X we don't have any Y
2077.54|4.95|and the the goal of unsupervised
2080.899|3.841|learning is to do something with that
2082.49|3.81|data X and the something that we're
2084.74|2.099|trying to do really depends on the
2086.3|3.21|problem
2086.839|4.381|so some so in general we hope that we
2089.51|3.659|can discover some type of latent
2091.22|3.75|structure in the data X without
2093.169|4.801|explicitly knowing anything about the
2094.97|4.29|labels so some classical examples that
2097.97|2.76|you might have seen in previous machine
2099.26|3.51|learning classes would be things like
2100.73|4.139|clustering so something like k-means
2102.77|4.71|where x is just a bunch of points and we
2104.869|6.331|discover structure by classifying them
2107.48|5.67|into clusters some other classical
2111.2|3.659|examples of unsupervised learning would
2113.15|5.159|be something like principal component
2114.859|5.881|analysis where X is just this some punch
2118.309|4.141|of data and we want to discover some low
2120.74|4.65|dimensional representation of that input
2122.45|4.889|data so unsupervised learning is this
2125.39|4.11|really sort of cool area but a little
2127.339|3.571|bit more problem specific and a little
2129.5|5.839|bit less well defined in supervised
2130.91|6.689|learning so two things that two
2135.339|4.24|architectures in particular that people
2137.599|4.591|in deep learning have done for
2139.579|5.04|unsupervised learning are these ideas as
2142.19|4.169|this idea of an autoencoder we'll talk
2144.619|3.511|about sort of traditional autoencoders
2146.359|2.94|that have a very very long history we'll
2148.13|3.06|also talk about variational
2149.299|4.8|auto-encoders which are this sort of
2151.19|4.32|news cool bayesian twist on them we'll
2154.099|3.091|also talk about some generative
2155.51|3.089|adversarial networks that actually are
2157.19|4.23|this really nice idea that let you
2158.599|8.76|generate images and model a sample from
2161.42|7.71|natural images so the idea with an
2167.359|4.771|autoencoder is is pretty simple
2169.13|5.07|we have our inputs X which is some data
2172.13|5.52|and we're going to pass this input data
2174.2|5.76|through some kind of encoder network to
2177.65|5.07|to produce some features some latent
2179.96|4.68|features Z so this you could think this
2182.72|3.69|stage you could think of a little bit
2184.64|3.3|like a learner in suppo component
2186.41|3.63|analysis where we're going to take our
2187.94|4.619|input data and then convert it into some
2190.04|4.86|other feature representation so those
2192.559|5.25|many times these X's will be images like
2194.9|5.59|these CF are 10 images shown here
2197.809|4.721|so this this encoder network could be
2200.49|3.93|something very complicated so for
2202.53|3.839|something like PCA it's just a simple
2204.42|3.8|linear transform but in general this
2206.369|4.651|might be a fully connected Network
2208.22|4.42|originally sort of maybe five or ten
2211.02|3.779|years ago this was often a single layer
2212.64|5.459|fully connected network with sigmoid
2214.799|5.131|units now it's often a deep deep network
2218.099|5.45|with raela units and this could also be
2219.93|3.619|something like a convolutional Network
2225.079|6.071|right so we also have this idea that Z
2228.93|4.139|the the features that we are that we
2231.15|4.98|learn are usually smaller in size than X
2233.069|5.821|so we want Z to be some kind of useful
2236.13|5.1|features about the data X so we we don't
2238.89|3.929|want the network to just transform then
2241.23|3.69|transform the data into some useless
2242.819|3.51|representation we want to force it to
2244.92|3.24|actually crush the data down and
2246.329|3.691|summarize its statistics in some useful
2248.16|4.8|way that could hopefully be useful for
2250.02|4.62|some downstream processing but the
2252.96|4.02|problem is that we don't really have any
2254.64|4.5|explicit labels to use for this
2256.98|3.78|downstream processing so instead we need
2259.14|3.78|to invent some kind of a surrogate task
2260.76|6.329|that we can use using just the just the
2262.92|6.54|data itself so the the surrogate task
2267.089|5.371|that we often use for auto-encoders is
2269.46|5.22|this idea of reconstruction so since we
2272.46|3.99|don't have any wise to learn on mapping
2274.68|4.05|instead we're just going to try to
2276.45|5.73|reproduce the data X from those features
2278.73|5.94|Z and especially if those features Z are
2282.18|4.56|smaller in size then hopefully that will
2284.67|4.439|force the network to act to summarize
2286.74|4.41|the to summarize the useful statistics
2289.109|5.071|of the input data and hopefully discover
2291.15|5.1|some useful features that could be one
2294.18|3.78|useful for reconstruction but more
2296.25|3.839|generally maybe those features might be
2297.96|6.99|useful for some other tasks if we later
2300.089|6.301|get some supervised data so again this
2304.95|4.349|decoder network could be pretty
2306.39|4.919|complicated when auto-encoders so first
2309.299|3.78|came about oftentimes these were just
2311.309|4.081|simple either a simple linear network or
2313.079|4.111|a small sigmoid Network but now they can
2315.39|4.02|be deep reloj networks and oftentimes
2317.19|4.139|these will be um I decided up
2319.41|3.78|convolutional as a good term so it's
2321.329|3.78|nice and small and fits on the slides so
2323.19|3.51|oftentimes this decoder nowadays will be
2325.109|3.69|one of these up convolutional networks
2326.7|3.72|that takes your features that are again
2328.799|2.371|are smaller in size and your input data
2330.42|3.03|and kind
2331.17|5.909|blows it back up in size to reproduce
2333.45|4.83|your your original data and I'd like to
2337.079|3.51|make the point that these things are
2338.28|3.75|actually pretty easy to train so on the
2340.589|3.48|right here is a like a quick example
2342.03|3.95|that I just cooked up in torch so this
2344.069|3.721|is a four layer encoder which is a
2345.98|3.19|convolutional network and then a four
2347.79|3.09|layer decoder which is an up
2349.17|3.179|convolutional network and you can see
2350.88|6.179|that it's actually learns to reconstruct
2352.349|6.091|the data pretty well another thing that
2357.059|3.211|you'll sometimes see is that these
2358.44|5.129|encoder and decoder networks will
2360.27|5.16|sometimes share weights with just sort
2363.569|4.141|of as a regularization strategy and with
2365.43|4.35|this intuition that these are opposite
2367.71|3.599|operations so maybe it might make sense
2369.78|5.069|to try to use the same weights for both
2371.309|5.431|so just as a concrete example if you're
2374.849|3.99|in if you think about a fully connected
2376.74|4.23|Network then maybe your input data has
2378.839|4.051|some dimension D and then your latent
2380.97|4.47|data Z will have some smaller dimension
2382.89|4.59|H and if this encoder was just a fully
2385.44|4.379|connected network then the weight would
2387.48|4.05|just be this matrix of D by H and now
2389.819|3.571|when we want to do the decoding and try
2391.53|4.769|to reconstruct the original data then
2393.39|5.58|that we're mapping back from H back to D
2396.299|3.871|so we can just reuse the same weights in
2398.97|6.78|these two layers if we just take a
2400.17|7.02|transpose of the matrix so when we're
2405.75|3.42|training this thing we need some kind of
2407.19|4.5|a loss function that we can use to
2409.17|5.159|compare our reconstructed data with our
2411.69|4.919|original data and then once and
2414.329|4.651|oftentimes we'll see L to a simple like
2416.609|4.831|L to Euclidian loss to train this thing
2418.98|3.75|so once we've chosen our encoder Network
2421.44|3.659|and once we've chosen our decoder
2422.73|3.96|network and chosen a loss function then
2425.099|3.331|we can train this thing just like any
2426.69|3.96|other normal neural network where we get
2428.43|3.99|some data we pass it through to encode
2430.65|3.39|it we pass it through to decode it we
2432.42|5.52|compute our loss we back propagate and
2434.04|6.09|everything's good so once we train this
2437.94|3.929|thing then oftentimes we'll take this
2440.13|3.15|decoder network that we spent so much
2441.869|4.801|time learning and we'll just throw it
2443.28|5.97|away which seems kind of weird but the
2446.67|5.49|reason is that reconstruction on its own
2449.25|4.77|is not such a useful task so instead we
2452.16|4.02|want to apply these networks to some
2454.02|3.18|kind of actually useful task problem
2456.18|4.379|which is probably a supervised learning
2457.2|5.28|task so here the setup is that we've
2460.559|3.661|learned this encoder network which
2462.48|2.52|hopefully from all this unsupervised
2464.22|2.7|data
2465.0|3.42|has learned too has learned to compress
2466.92|3.18|the data and extract some useful
2468.42|4.17|features and then we're going to use
2470.1|4.8|this encoder network to initialize part
2472.59|4.38|of a larger supervised Network and now
2474.9|3.99|if we actually do have access to maybe
2476.97|4.8|some smaller data set that have some
2478.89|4.26|labels then hopefully this most of the
2481.77|2.79|work here could have been done by this
2483.15|3.57|unsupervised training at the beginning
2484.56|4.11|and then we can just use that to
2486.72|3.66|initialize this this bigger Network and
2488.67|2.94|then fine tune the whole thing with
2490.38|5.13|hopefully a very small amount of
2491.61|5.64|supervised data so this is kind of the
2495.51|3.84|dream of one of the dreams of
2497.25|4.05|unsupervised feature learning that you
2499.35|3.78|have this really really large data set
2501.3|3.51|of with no labels you can just go on
2503.13|2.73|Google and download images forever and
2504.81|3.63|you it's really easy to get a lot of
2505.86|5.1|images the problem is that labels are
2508.44|4.35|expensive to collect so you'd want some
2510.96|4.05|system that could take advantage of both
2512.79|4.14|a large huge amount of unsupervised data
2515.01|4.53|and also just a small amount of
2516.93|4.74|supervised data so auto-encoders are at
2519.54|4.38|least one thing that has been proposed
2521.67|3.54|that has this nice property but in
2523.92|3.69|practice I think it tends not to work
2525.21|3.51|too well which is a little bit
2527.61|4.29|unfortunate because it's such a
2528.72|5.1|beautiful idea another thing that I
2531.9|3.9|should point out almost a bit of as a
2533.82|4.08|side note that if you go back and read
2535.8|4.44|the literature on these things from
2537.9|4.68|maybe the mid-2000s in the last ten
2540.24|4.65|years then people had this funny thing
2542.58|3.42|called greedy lair wise pre-training
2544.89|3.9|that they used for training
2546.0|4.8|auto-encoders and here the idea was that
2548.79|3.78|at the time in 2006
2550.8|4.56|training very deep networks was was
2552.57|4.26|challenging and if you you can find
2555.36|3.21|quotes in papers like this
2556.83|3.15|that say that even when you have maybe
2558.57|3.03|four or five hidden layers it was
2559.98|5.1|extremely challenging for people in
2561.6|5.37|those days to train deep networks so to
2565.08|4.02|get around that problem they instead had
2566.97|4.65|this paradigm where they would try to
2569.1|4.77|Train just one layer at a time and they
2571.62|3.9|used this this thing that I don't want
2573.87|3.48|to get too much into called a restricted
2575.52|3.99|Boltzmann machine which is a type of
2577.35|4.14|graphical model and they would use these
2579.51|3.93|restricted Boltzmann machines to kind of
2581.49|4.38|train these to these little layers one
2583.44|5.1|at a time so first we would have our
2585.87|6.18|input image of maybe size double of size
2588.54|5.37|W one and this would be maybe something
2592.05|4.2|like PCA or some some other kind of
2593.91|3.72|fixed transform and then we would
2596.25|2.79|hopefully learn
2597.63|3.21|using a restricted Boltzmann machine
2599.04|4.05|some kind of relationship between those
2600.84|4.95|first layer features and some higher
2603.09|4.35|layer features when once we once we
2605.79|3.57|learn this layer we would then freeze it
2607.44|3.12|and learn another restricted Boltzmann
2609.36|2.79|machine on top of those features
2610.56|4.56|connecting it to the next layer of
2612.15|4.83|features so by using this type of
2615.12|3.63|approach it let them train just one
2616.98|4.23|layer at a time in this sort of greedy
2618.75|4.56|way and that let them hopefully find a
2621.21|2.88|really good initialization for this
2623.31|3.66|larger Network
2624.09|4.11|so after this greedy pre training stage
2626.97|3.21|they would stick the whole thing
2628.2|3.66|together into this giant auto encoder
2630.18|7.53|and then fine-tune the auto encoder
2631.86|8.49|jointly so nowadays we don't really need
2637.71|4.59|to do this with things like Rae Lou and
2640.35|4.26|proper initialization and Bachelor
2642.3|4.02|Malaysian and slightly fancy our fancier
2644.61|4.11|optimizers this type of thing is not
2646.32|4.8|really necessary anymore so as an
2648.72|3.93|example on the previous slide we saw
2651.12|3.15|this four layer convolutional
2652.65|4.11|deconvolution alauda encoder that i
2654.27|4.44|trained on c far and this is just fine
2656.76|3.06|to do using all these modern neural
2658.71|3.06|network techniques you don't have to
2659.82|4.14|mess around with this greedy layer wise
2661.77|4.29|training so this is not something that
2663.96|3.33|really gets done anymore but I thought
2666.06|2.85|we should at least mention it since
2667.29|3.39|you'll probably encounter this idea if
2668.91|8.16|you read back in the literature about
2670.68|8.49|these things so the basic idea around
2677.07|4.26|autoencoders is I think pretty simple
2679.17|4.14|it's this beautiful idea where we can
2681.33|3.89|just use a lot of unsupervised data to
2683.31|3.72|hopefully learn some nice features
2685.22|5.08|unfortunately that doesn't work but
2687.03|5.43|that's ok but there's maybe some other
2690.3|6.35|nice type of tasks we would want to do
2692.46|4.19|with unsupervised data question first
2704.04|4.32|yeah so the question is what's going on
2706.54|4.83|here
2708.36|4.36|right so this is this is um this is
2711.37|3.66|maybe you could think about a three
2712.72|4.05|layer neural network so our input is
2715.03|3.36|going to be the same as the output so
2716.77|2.79|we're just hoping that this is a neural
2718.39|4.35|network that will learn the identity
2719.56|4.59|function but that's a really and in
2722.74|2.93|order to learn the identity function we
2724.15|3.84|have some loss function at the end
2725.67|4.0|something like an l2 loss that is
2727.99|4.56|encouraging our to our input and our
2729.67|5.31|output to be the same and learning the
2732.55|4.59|identity function is probably a really
2734.98|3.96|easy thing to do but instead we're going
2737.14|3.99|to force the network to not take the
2738.94|4.05|easy route and instead hopefully rather
2741.13|3.18|than just regurgitating the data and
2742.99|3.0|learning the identity function in the
2744.31|3.6|easy way instead we're going to
2745.99|4.08|bottleneck the representation through
2747.91|3.81|this hidden layer in the middle so then
2750.07|3.51|it's going to learn the identity
2751.72|3.15|function but in the middle if the
2753.58|3.63|network is going to have to squeeze down
2754.87|4.92|and summarize and compress the data and
2757.21|4.38|hopefully that that compression will
2759.79|4.53|give rise to features that are useful
2761.59|10.98|for other tasks is that maybe a little
2764.32|10.17|bit more clear okay question so the
2772.57|2.61|claim was that PCA is just the answer
2774.49|3.3|for this problem
2775.18|4.32|so it's true that PCA is optimal in
2777.79|4.25|certain senses if you're only allowed to
2779.5|5.13|do maybe a one layer a one layer type of
2782.04|4.42|if your encoder and your decoder are
2784.63|4.83|just a single linear transform then
2786.46|4.86|indeed PCA is optimal in some sense but
2789.46|3.6|if your encoder and decoder are
2791.32|3.75|potentially larger more complicated
2793.06|5.67|functions that are maybe multi-layer
2795.07|5.64|neural networks then yet then maybe PCA
2798.73|3.81|is no longer the right solution another
2800.71|4.38|point to make is that PCA is only
2802.54|5.16|optimal in certain senses particularly
2805.09|4.02|talking about l2 reconstruction but in
2807.7|2.97|practice we don't actually care about
2809.11|3.27|reconstruction we're just hoping that
2810.67|5.07|this thing will learn useful features
2812.38|5.13|for other tasks so in practice and we'll
2815.74|4.23|see this a bit later that people don't
2817.51|4.14|always use l2 anymore because l2 is
2819.97|6.29|maybe not quite the right loss for
2821.65|4.61|actually learning features yeah
2827.56|7.06|so the RBM lair is this is this kind of
2832.7|3.81|generative model of the data of data
2834.62|4.05|where you imagine that you have sort of
2836.51|2.52|two sequences of bits and you want to do
2838.67|2.28|this
2839.03|4.59|generative modeling of the of the two
2840.95|4.29|things so then you need to get into
2843.62|2.64|quite a lot of Bayesian statistics to
2845.24|2.4|figure out exactly what the loss
2846.26|2.79|function is but it ends up being
2847.64|4.38|something like log likelihood of the
2849.05|5.1|data with these latent states that you
2852.02|5.07|don't observe and that's actually a cool
2854.15|6.18|idea that we will sort of revisit in the
2857.09|4.56|variational auto encoder so one of the
2860.33|3.57|one of the problems with this
2861.65|4.35|traditional auto encoder is that it's
2863.9|4.08|hoping to it can learn features that's
2866.0|4.41|that's a cool thing but there's this
2867.98|4.32|other thing that we would like to not
2870.41|5.31|just learn features but also be able to
2872.3|4.62|generate new data a cool task that we
2875.72|3.84|could potentially learn from
2876.92|4.29|unsupervised data is that hopefully our
2879.56|3.75|model could slurp in a bunch of images
2881.21|4.38|and after it does that it sort of learns
2883.31|4.41|what natural images look like and then
2885.59|3.87|after its learned this distribution then
2887.72|3.72|it could hopefully spit out sort of fake
2889.46|6.03|images that look like the original
2891.44|6.81|images but are fake and this is maybe
2895.49|5.16|not a task which is directly applicable
2898.25|4.29|to things like classification but it
2900.65|4.56|seems like an important thing for AI
2902.54|4.2|that humans are pretty good at looking
2905.21|2.94|at data and summarizing it and kind of
2906.74|3.6|getting the idea of what a data set
2908.15|4.41|looks like so hopefully if our models
2910.34|4.26|could also do this sort of task then
2912.56|3.72|hopefully they'll have learned some some
2914.6|5.79|useful summarization or some useful
2916.28|6.42|statistics of the data so the
2920.39|4.14|variational auto encoder is this kind of
2922.7|4.53|neat twist on the original auto encoder
2924.53|5.4|that lets us hopefully actually generate
2927.23|4.44|novel images from our learns data so
2929.93|4.38|here we need to dive into a little bit
2931.67|4.11|of Bayesian statistics so this is
2934.31|3.06|something that we haven't really talked
2935.78|3.57|about at all in this class anymore but
2937.37|3.12|are up to this point but there's this
2939.35|3.72|whole other side of machine learning
2940.49|3.96|that doesn't do neural networks and deep
2943.07|3.41|learning but thinks really hard about
2944.45|4.02|probability distributions and how
2946.48|4.21|probability distributions can fit
2948.47|3.81|together to generate data sets and then
2950.69|3.87|reason probabilistically about your data
2952.28|4.29|and this type of paradigm is really nice
2954.56|4.3|because it lets you sort of state
2956.57|3.67|explicit probabilistic assumptions about
2958.86|3.51|how you think your data was generated
2960.24|3.9|and then given those probabilistic
2962.37|4.22|assumptions you try to fit your model to
2964.14|4.65|the data that follows your assumptions
2966.59|4.63|so with the variational auto encoder
2968.79|4.74|we're assuming this this particular type
2971.22|4.86|of method by which our data was
2973.53|4.38|generated so we assume that we there
2976.08|3.75|exists out the out there in the world
2977.91|5.01|some prior distribution which is
2979.83|4.59|generating these latent States Z and we
2982.92|4.08|then we assume some conditional
2984.42|5.37|distribution that once we have the
2987.0|4.62|latent States we can generate a sample
2989.79|4.35|from some other distribution to generate
2991.62|4.59|the data so the variational auto encoder
2994.14|3.78|it really imagines that our data was
2996.21|4.2|generated by this pretty simple process
2997.92|4.62|that first we sample from some prior
3000.41|4.5|distribution to get sucked to get our Z
3002.54|8.43|then we sample from this conditional to
3004.91|8.1|get our X so the intuition is that X is
3010.97|4.2|something like an image and Z maybe
3013.01|4.35|summarizes some useful stuff about that
3015.17|4.56|image so if these receive our images
3017.36|3.78|then maybe that latent state Z could be
3019.73|3.33|something like the class of the image
3021.14|4.26|whether it's a frog or a deer or a cat
3023.06|4.41|and also might contain variables about
3025.4|4.62|how that cat is oriented or what color
3027.47|4.8|it is or something like that so this is
3030.02|3.69|kind of a nice sort of I think a pretty
3032.27|3.57|simple it's a pretty simple idea but
3033.71|7.8|makes a lot of sense for how you might
3035.84|7.02|imagine imaged images to be generated so
3041.51|3.21|the problem now is that we want to
3042.86|4.35|estimate these parameters theta of both
3044.72|4.5|the prior and the conditional without
3047.21|4.95|actually access having access to these
3049.22|6.06|latent States Z and that's that's that's
3052.16|4.65|a challenging problem so to make it
3055.28|3.27|simpler we're going to do something that
3056.81|3.15|you see a lot in Bayesian statistics and
3058.55|3.29|we'll just assume that the prior is
3059.96|5.43|Gaussian because that's easy to handle
3061.84|5.44|and the conditional will be will also be
3065.39|4.35|Gaussian but it's going to be a little
3067.28|4.68|bit fancier so we'll assume that it's a
3069.74|4.86|Gaussian with diagonal mean and unit and
3071.96|4.8|with sorry diagonal covariance and some
3074.6|3.66|mean but instead we're just going to
3076.76|2.85|print but the way that we're going to
3078.26|4.62|get those is we're going to compute them
3079.61|5.13|with a neural network so it suppose that
3082.88|4.41|we had the latent state Z for some piece
3084.74|4.98|of data then we assume that that latent
3087.29|4.37|state will go into some decoder network
3089.72|3.71|which could be some big
3091.66|3.24|located neural network and now that
3093.43|3.51|neural network is going to spit out two
3094.9|4.23|things it's going to spit out the mean
3096.94|4.76|of the data it's going to spit out the
3099.13|5.669|mean of the data X and also the the
3101.7|4.78|variance of the data X so you should
3104.799|3.99|think that this looks very much like the
3106.48|3.99|top half of a normal autoencoder that we
3108.789|2.911|have this latent state we have some
3110.47|2.879|neural net that's operating on the
3111.7|4.379|latent state but now instead of just
3113.349|5.52|directly spitting out the the data
3116.079|4.201|instead its spitting out the the mean of
3118.869|3.24|the data and the variance of the data
3120.28|3.21|but other than that this looks very much
3122.109|5.821|like the decoder of the normal auto
3123.49|6.66|encoder so this this decoder network
3127.93|3.78|sort of thinking back to the normal auto
3130.15|3.09|encoder might be a simple fully
3131.71|3.75|connected thing or it might be this very
3133.24|6.629|big powerful D convolutional network and
3135.46|7.829|and both of those are pretty common so
3139.869|5.25|now the problem is that by Bayes rule if
3143.289|3.391|given the prior and given the
3145.119|4.891|conditional Bayes rule tells us the
3146.68|4.889|posterior that given so if we want to
3150.01|3.299|actually use this model we need to be
3151.569|3.631|able to estimate the latent state from
3153.309|3.691|the input data and the way that we
3155.2|3.93|estimate the latent state from the input
3157.0|3.93|data is by writing down this posterior
3159.13|4.14|distribution which is the probability of
3160.93|4.919|the latent state z given our observed
3163.27|4.2|data X and using Bayes rule we can
3165.849|3.93|easily flip this around and write it in
3167.47|6.569|terms of our prior over Z and in terms
3169.779|5.671|of our conditional xqz the prop and so
3174.039|3.091|we can use Bayes rule to actually flip
3175.45|5.28|this thing around and write it in terms
3177.13|5.13|of these three things so the after we
3180.73|3.0|look at Bayes rule we can break down
3182.26|4.17|these three terms and we can see that
3183.73|4.079|the the conditional we just use our
3186.43|4.53|decoder Network and we easily have
3187.809|4.47|access to that and this prior again we
3190.96|3.389|have access to the prior because we
3192.279|4.351|assumed its unit Gaussian so that's easy
3194.349|4.651|to handle but this denominator this
3196.63|3.659|probability of X it turns out if you if
3199.0|2.94|you work out the math and write it out
3200.289|2.941|this ends up being this giant
3201.94|3.54|intractable integral over the entire
3203.23|3.78|latent state space so that's completely
3205.48|2.94|intractable there's no way you could
3207.01|2.609|ever perform that integral and even
3208.42|3.929|approximating it would be a giant
3209.619|6.331|disaster so instead we will not even try
3212.349|5.49|to evaluate that integral instead we're
3215.95|4.23|going to introduce some encoder network
3217.839|5.041|that will try to directly perform this
3220.18|4.76|inference step for us so this encoder
3222.88|4.13|network is going to take in a
3224.94|3.87|get a point and it's going to spit out a
3227.01|4.95|distribution over the latent state space
3228.81|5.22|so again this looks very much looking
3231.96|3.84|back at the original auto-encoder from a
3234.03|4.049|few slides ago this looks very much the
3235.8|4.17|same as sort of the bottom half of a
3238.079|3.901|traditional auto encoder where we're
3239.97|3.48|taking in data and now instead of
3241.98|3.0|directly spitting out the latent state
3243.45|4.05|we're going to spit out a mean and a
3244.98|5.22|covariance of the latent state and again
3247.5|4.859|this encoder network might be something
3250.2|3.36|might be some fully convolutional
3252.359|6.871|network or it might be some deep
3253.56|7.5|convolutional network so the sort of the
3259.23|3.599|intuition is that this encoder network
3261.06|4.62|will be this separate totally different
3262.829|4.141|disjoint function but we're going to try
3265.68|3.45|to train it in a way so that it
3266.97|5.119|approximates this posterior distribution
3269.13|6.36|that we don't actually have access to
3272.089|6.52|and yes so once we put all these pieces
3275.49|5.099|together then then we can setup stitch
3278.609|4.561|this all together and get give rise to
3280.589|4.081|this variational auto encoder so once we
3283.17|3.81|put these things together then we have
3284.67|4.38|this input data point X we're going to
3286.98|4.139|pass it through our encoder network and
3289.05|4.68|the encoder network will spit out a
3291.119|4.531|distribution over the latent States once
3293.73|4.26|we have this this distribution over the
3295.65|3.84|latent States you can imagine you can
3297.99|4.98|imagine sampling from that distribution
3299.49|6.66|to get some somehow some latent state of
3302.97|5.49|high probability for that input then
3306.15|4.8|once we have then once we have some
3308.46|3.869|concrete example of a latent state then
3310.95|3.149|we can pass it through this decoder
3312.329|4.351|network which will spit out the
3314.099|4.52|probability of which you then spit out
3316.68|4.59|the probability of the data again and
3318.619|4.901|then once we have this this distribution
3321.27|3.63|over the data we could sample from it to
3323.52|4.65|actually get something that hopefully
3324.9|5.669|looks like the original data point so
3328.17|4.83|this this ends up looking very much like
3330.569|4.111|a normal auto encoder where we're taking
3333.0|3.78|our input data we're running it through
3334.68|3.87|this encoder to get some latent State
3336.78|3.27|we're passing it through this decoder to
3338.55|3.63|hopefully reconstruct the original data
3340.05|4.049|and when you go about training this
3342.18|3.689|thing it's actually trained in a very
3344.099|3.811|similar method as a normal auto encoder
3345.869|4.081|where we have this forward pass and this
3347.91|5.459|backward pass the only difference is in
3349.95|5.34|the loss function so at the top we have
3353.369|4.5|this reconstruction loss rather than
3355.29|2.98|being this point wise l2 instead we want
3357.869|3.101|the
3358.27|6.48|distribution to be close to the true
3360.97|6.27|input data and we also have this lost
3364.75|4.44|term coming in the middle that we want
3367.24|3.81|this generated distribution over the
3369.19|4.17|latent states to hopefully be very
3371.05|4.2|similar to our stated prior distribution
3373.36|3.84|that we wrote down at the very beginning
3375.25|3.48|so once you put all these pieces
3377.2|3.6|together you can just train this thing
3378.73|3.96|like a normal auto encoder with normal
3380.8|3.6|soared forward forward pass and backward
3382.69|4.02|pass the only difference is where you
3384.4|5.82|put the loss and how you interpret the
3386.71|5.49|loss so any any questions about this
3390.22|7.17|setup it's kind of a wet we went through
3392.2|6.69|it kind of fast yeah the question is why
3397.39|2.67|do you choose a diagonal covariance and
3398.89|2.18|answer is because it's really easy to
3400.06|3.63|work with
3401.07|4.39|there's but actually people have tried I
3403.69|2.67|think slightly fancier things too but
3405.46|5.88|that's something you can play around
3406.36|6.87|with okay so once we've actually trained
3411.34|3.81|this once we've actually trained this
3413.23|3.63|kind of variation auto encoder we can
3415.15|3.42|actually use it to generate new data
3416.86|4.38|that looks kind of like our original
3418.57|4.68|data set so here the idea is that
3421.24|3.45|remember we wrote down this prior that
3423.25|3.27|might be a unit Gaussian or maybe
3424.69|3.48|something a little bit fancier but in
3426.52|3.48|any rate this prior is something some
3428.17|3.99|distribution that we can easily sample
3430.0|3.57|from so a eunuch Gao in it's very easy
3432.16|3.78|to draw random samples from that
3433.57|4.29|distribution so to generate new data
3435.94|4.47|we'll start by just sort of following
3437.86|4.14|this data this data generation process
3440.41|3.84|that we had imagined for our data
3442.0|3.96|so first we'll sample from our from our
3444.25|3.6|prior distribution over the Leighton
3445.96|3.69|States and then we'll pass it through
3447.85|4.02|our decoder network that we have learned
3449.65|4.14|during training and this decoder network
3451.87|4.23|will now spit out a distribution over
3453.79|4.83|our data points in the train in terms of
3456.1|4.29|both a mean and a covariance and once we
3458.62|3.18|have a mean and covariance this is just
3460.39|3.57|a diagonal Gaussian so we can easily
3461.8|5.55|sample from this thing again to generate
3463.96|5.49|some data point so now one once you
3467.35|4.47|train this thing then another thing you
3469.45|4.41|can do is sort of scan out the latent
3471.82|3.93|space and a mat and rather than sampling
3473.86|4.08|from the latent distribution instead you
3475.75|4.11|just densely sample all the latent from
3477.94|3.57|the latent space to kind of get an idea
3479.86|5.01|for what type of structure structure the
3481.51|7.17|network had learned so this is doing
3484.87|5.34|exactly that on the unnecessary R we we
3488.68|3.16|trained this variational auto encoder
3490.21|2.77|with where
3491.84|3.6|the latent state is just a
3492.98|4.56|two-dimensional thing and now we can
3495.44|4.5|actually scan out this latent space this
3497.54|4.29|lick we can explore densely this
3499.94|3.87|two-dimensional latent space and for
3501.83|3.27|each point in the latent space pass it
3503.81|3.18|through the decoder and use it to
3505.1|3.18|generate some image so you can see that
3506.99|2.85|it's actually discovered this very
3508.28|3.51|beautiful structure on eminence digits
3509.84|4.11|that sort of smoothly interpolates
3511.79|3.6|between the different digit classes so
3513.95|3.6|I'll be up here at the left you see
3515.39|4.29|sixes that kind of morph into zeros as
3517.55|5.13|you go down you see sixes that turn into
3519.68|4.2|sub into maybe 9s and 7s the eights are
3522.68|3.45|hanging out in the middle somewhere and
3523.88|3.75|the ones are down here so this latent
3526.13|3.96|space actually learned this beautiful
3527.63|6.48|disentanglement of the data in this very
3530.09|5.76|nice unsupervised way we can also train
3534.11|3.45|this thing on a faces data set and it's
3535.85|2.61|the same sort of story where we're just
3537.56|3.15|training this two dimensional
3538.46|3.99|variational auto encoder and then once
3540.71|3.6|we train it we densely sample from that
3542.45|14.01|latent space to try to see what has what
3544.31|13.83|it has learned question yeah so the
3556.46|3.51|question is whether people ever try to
3558.14|3.96|force the late specific latent variables
3559.97|3.69|to have some some some exact meaning and
3562.1|3.63|yeah there has been some follow-up work
3563.66|4.17|that does exactly that there's a paper
3565.73|4.89|called deep inverse graphics networks
3567.83|5.34|from MIT that has that does exactly this
3570.62|4.32|setup where they try to force where they
3573.17|3.36|want to learn sort of a renderer in it
3574.94|5.13|as a neural network so they want to
3576.53|5.52|learn to like render 3d images of things
3580.07|3.51|so they want to force some of the latent
3582.05|4.11|space some of the variables in the
3583.58|5.1|latent space to corresponds to the 3d
3586.16|4.86|angles of the object and maybe the class
3588.68|3.96|and the 3d pose of the object and the
3591.02|3.36|rest of them it lets it learn forever
3592.64|3.21|whatever at once and they actually have
3594.38|3.78|some cool experiments where now they can
3595.85|4.56|do exactly as you said and by setting
3598.16|3.84|those those specific values of latent
3600.41|3.18|variables they can render and actually
3602.0|4.68|rotate the object and those are those
3603.59|4.23|are pretty cool but that's a little
3606.68|3.3|that's that's a little bit fancier than
3607.82|3.36|these faces but these faces are still
3609.98|3.06|pretty cool you can see it's sort of
3611.18|4.53|interpolating between different faces in
3613.04|4.59|this very nice way and I think that
3615.71|4.13|there's actually a very nice motivation
3617.63|5.13|here and one of the reasons we pick
3619.84|4.93|diagonal Gaussian is that that has the
3622.76|2.32|probabilistic interpretation of having
3624.77|2.68|in
3625.08|4.38|pendant that the very that the different
3627.45|4.38|variables in our late in space actually
3629.46|4.89|should be independent so I think that
3631.83|4.08|helps to explain why there actually is
3634.35|3.45|this very nice separation between the
3635.91|3.45|axes when you end up sampling from the
3637.8|3.48|latent space it's due to this
3639.36|4.77|probabilistic independence assumption
3641.28|4.56|embedded in a prior so this idea of
3644.13|3.0|priors is very powerful and lets you
3645.84|5.46|sort of bake those types of things
3647.13|5.94|directly into your model so I I wrote
3651.3|3.63|down a bunch of math and I don't think
3653.07|4.29|we really have time to go through it but
3654.93|3.63|the idea is that sort of classically
3657.36|2.58|when you're training generative models
3658.56|3.06|there's this thing called maximum
3659.94|3.0|likelihood where you want to maximize
3661.62|3.69|the likelihood of your data under the
3662.94|4.98|model and then pick the model where that
3665.31|4.38|makes your data most likely but it turns
3667.92|3.96|out that if you just try to run maximum
3669.69|3.93|likelihood using a normal using this
3671.88|3.84|generative process that we had imagined
3673.62|4.2|for the variation auto-encoder then you
3675.72|3.33|run into this giant you end up needing
3677.82|3.45|to marginalize this Joint Distribution
3679.05|3.87|which becomes this giant intractable
3681.27|3.3|integral over the entire latent state
3682.92|4.95|space so that's not something that we
3684.57|5.01|can do so instead the variational auto
3687.87|4.02|encoder encoder does this thing called
3689.58|4.68|variational inference which is a pretty
3691.89|4.11|cool idea and the math is here in case
3694.26|3.81|you want to go through it but the idea
3696.0|3.9|is that instead of maximizing the log
3698.07|4.02|probability of the data we're going to
3699.9|3.99|cleverly insert this extra constant and
3702.09|5.25|break it up into these two different
3703.89|4.92|terms so we're right this is an exact
3707.34|3.06|equivalence that you can maybe work
3708.81|3.54|through on your own but this log
3710.4|4.29|likelihood we can write in terms of this
3712.35|3.99|term that we call an elbow and this
3714.69|4.17|other term which is a KL divergence
3716.34|5.67|between two distributions and we know
3718.86|4.32|that KL divergence is always zero so we
3722.01|3.87|know that KL divergence between
3723.18|5.4|distributions is nonzero so we know that
3725.88|5.4|this term has to be nonzero which means
3728.58|4.5|that this this elbo term actually is a
3731.28|4.59|lower bound on the log likelihood of our
3733.08|4.68|data and notice that in the process of
3735.87|4.23|writing down this elbow we introduced
3737.76|4.23|this additional parameter fee that we
3740.1|4.77|can interpret as the parameters of this
3741.99|5.34|of this encoder network that is sort of
3744.87|5.13|approximating this hard posterior
3747.33|4.35|distribution so now instead of trying to
3750.0|3.72|directly maximize the log likelihood of
3751.68|3.78|our data instead we'll try to maximize
3753.72|4.65|this variational lower bound of the data
3755.46|3.26|and because the this elbow is built as a
3758.37|2.09|low
3758.72|3.899|bound of the log-likelihood then
3760.46|3.57|maximizing the elbow will also have the
3762.619|5.73|effect of raising up the log-likelihood
3764.03|5.37|instead and these these two terms of the
3768.349|3.901|elbow actually have this beautiful
3769.4|5.219|interpretation that this one at the
3772.25|4.53|front is the expectation over the latent
3774.619|5.281|state speak over the latent state space
3776.78|4.77|of the probability of x given the latent
3779.9|3.209|state space so if you think about that
3781.55|3.809|that's actually a data reconstruction
3783.109|4.291|term that's saying that if we averaged
3785.359|3.24|over all possible latent states then we
3787.4|4.32|should end up with something that is
3788.599|5.01|similar to our original data and this is
3791.72|4.05|that this this other term is actually a
3793.609|4.291|regularization term this is the KL
3795.77|4.77|divergence between our approximate
3797.9|4.26|posterior and between the prior so this
3800.54|4.38|is a regularization is trying to force
3802.16|4.8|those two things together so in practice
3804.92|3.78|this this first term you can approximate
3806.96|4.11|with something called the width
3808.7|3.78|approximate by sampling using this trick
3811.07|4.11|in the paper that I won't get into and
3812.48|4.02|this other term again because everything
3815.18|5.82|is Gaussian here you can just evaluate
3816.5|6.06|this KL divergence explicitly so I think
3821.0|4.68|this is the most math heavy slide in the
3822.56|6.09|class so that's that's kind of fun but
3825.68|4.32|actually it's so but it's actually less
3828.65|3.57|this looks scary but it's actually just
3830.0|3.839|the exactly just this auto-encoder idea
3832.22|4.02|or you have a reconstruction and then
3833.839|4.741|you have this penalty penalizing to go
3836.24|3.72|back towards the prior so any any
3838.58|6.84|questions on the variational auto
3839.96|7.77|encoder okay so the the overview of
3845.42|3.9|autoencoders is that in general the idea
3847.73|3.03|of an auto encoder is that we want to
3849.32|3.36|force a network to try to reconstruct
3850.76|3.75|our data and hopefully this will learn
3852.68|4.169|sort of useful representations of the
3854.51|4.23|data for traditional autoencoders this
3856.849|3.721|is used for feature learning but once we
3858.74|3.3|move to variational auto-encoders we
3860.57|3.09|make this thing Bayesian so we can
3862.04|5.67|actually generate samples that are
3863.66|5.699|similar to our data so with then this
3867.71|3.12|idea of generating samples for my data
3869.359|2.76|is really cool and everyone loves
3870.83|4.5|looking at these kinds of pictures so
3872.119|4.98|there's another idea that may be can we
3875.33|4.17|generate really cool samples without all
3877.099|3.99|this scary Bayesian math and it turns
3879.5|3.599|out that there's this idea called a
3881.089|4.201|generative adversarial network that is a
3883.099|4.171|sort of different idea a different twist
3885.29|4.44|that lets you still generate samples
3887.27|3.96|that look like your data but sort of a
3889.73|2.27|little bit more explicitly without
3891.23|2.45|having to worry about
3892.0|4.14|divergences and priors and the sort of
3893.68|5.1|stuff so the idea is that we're going to
3896.14|3.72|have a generator network that well first
3898.78|3.27|we're going to start with some random
3899.86|3.89|noise that probably is drawn from like a
3902.05|3.63|unit gouge in or something like that and
3903.75|4.06|then we're going to have a generator
3905.68|4.17|network and this generator network
3907.81|3.6|actually looks very much like the
3909.85|4.47|decoder in the variational auto encoder
3911.41|5.22|or like the second half of a normal auto
3914.32|3.87|encoder in that we're taking this random
3916.63|4.83|noise and we're going to spit out an
3918.19|4.86|image that is going to be some fake non
3921.46|5.22|real image that we're just generating
3923.05|5.37|using this train network then we're also
3926.68|3.81|going to hook up a discriminator network
3928.42|3.81|that is going to look at this fake image
3930.49|3.69|and try to decide whether it's whether
3932.23|4.5|or not that generated image is real or
3934.18|3.93|fake so this is this so this second
3936.73|4.17|network is just doing this binary
3938.11|4.38|classification task where it receives an
3940.9|3.66|input and it just needs to say whether
3942.49|3.78|or not it's true or it's whether or not
3944.56|3.9|it's real image or not so that's just
3946.27|5.82|sort of a classification task that you
3948.46|6.63|can hook up like anything else so then
3952.09|5.73|we can train this thing all jointly all
3955.09|5.37|together where our generator network
3957.82|4.62|will receive mini batches of random
3960.46|4.23|noise and it'll spit out real and it
3962.44|4.17|will spit out fake images and our
3964.69|4.86|discriminator network will receive mini
3966.61|4.89|batches of partially these fake images
3969.55|4.32|and partially real images from our data
3971.5|4.32|set and it will have to just it'll try
3973.87|5.31|to make this classification task to say
3975.82|5.43|which are real and which are fake and so
3979.18|3.51|this is sort of now another way that we
3981.25|3.45|can hook up this kind of supervised
3982.69|4.26|learning problem ish without any real
3984.7|5.25|data so we hook this thing up and we
3986.95|4.77|train the whole thing jointly so we can
3989.95|3.66|look at some examples from the original
3991.72|4.2|generative adversarial networks paper
3993.61|4.74|and so these are fake images that are
3995.92|3.54|generated by the network on amnesty so
3998.35|2.76|you can see that it's done a very good
3999.46|3.96|job of actually generating fake digits
4001.11|4.38|they look like real digits and here I'm
4003.42|3.78|here this this middle column is showing
4005.49|3.36|actually the nearest neighbor in the
4007.2|3.54|training set of those digits to
4008.85|3.9|hopefully let you know that it hasn't
4010.74|3.48|just memorized the training set so for
4012.75|3.3|example this two has a little dot and
4014.22|3.12|the nearest me then this guy doesn't
4016.05|3.6|have a dot so it's not just memorizing
4017.34|3.72|training data and it also does a pretty
4019.65|4.86|good job of recognizing face of
4021.06|4.69|generating faces so but you know as
4024.51|4.18|people who've worked on machine
4025.75|4.53|learning no these undies digit and face
4028.69|4.29|datasets tend to be pretty easy to
4030.28|5.19|generate samples from and when we apply
4032.98|5.16|this this task to see far then our
4035.47|5.13|jarred samples don't quite look as nice
4038.14|4.83|and clean so here it's clearly got some
4040.6|4.14|idea about CFR data worth making blue
4042.97|4.89|stuff and green stuff but they don't
4044.74|4.19|really look like real objects so that's
4047.86|4.92|that's a problem
4048.93|5.59|so some follow-up work actually try some
4052.78|2.94|follow-up work on generative adversarial
4054.52|2.64|networks has tried to make these
4055.72|3.42|architectures bigger and more powerful
4057.16|4.76|to hopefully be able to generate better
4059.14|6.48|samples on these more complex data sets
4061.92|6.16|so one idea is this idea is multi scale
4065.62|4.08|processing so rather than generating the
4068.08|3.42|image all at once we're actually going
4069.7|4.32|to generate our image at multiple scales
4071.5|4.56|in this iterative way so first we're
4074.02|4.23|going to have a generator that feeds in
4076.06|4.32|that receives noise and then generates a
4078.25|4.95|low resolution input then we'll up
4080.38|5.01|sample that low res guy and apply a
4083.2|4.14|second generator that receives a new
4085.39|4.98|batch of random noise and computes some
4087.34|4.56|Delta on top of the low res image then
4090.37|3.54|we'll up sample that again and repeat
4091.9|4.8|the process several times until we've
4093.91|5.97|actually finally generated our generated
4096.7|5.52|our final result so this is again a very
4099.88|3.93|similar idea as the previous as the
4102.22|3.18|original generator a serial network
4103.81|4.71|we're just generating at multiple scales
4105.4|4.08|simultaneously and the training here is
4108.52|2.4|a little bit more complex
4109.48|3.779|you actually have a discriminator at
4110.92|4.95|each scale and that hopefully it
4113.259|3.901|hopefully it does something so when we
4115.87|3.179|look at the train samples from this guy
4117.16|4.11|they're actually a lot better so here
4119.049|4.651|are here they actually train a separate
4121.27|3.989|model per class on CFR ten so here
4123.7|4.59|they've trained this adversarial network
4125.259|4.08|on just on just planes from CFR and you
4128.29|2.819|can see that they're starting to look
4129.339|4.291|like real planes so that's that's
4131.109|5.19|getting somewhere these look almost like
4133.63|7.74|real cars and these maybe look kind of
4136.299|7.141|like real birds so in in the following
4141.37|4.59|year people actually threw away this
4143.44|5.399|multi scale idea and just used a simpler
4145.96|4.83|better more principled component so here
4148.839|4.681|the idea is forget about this multi
4150.79|4.29|scale stuff and just use a use batch
4153.52|2.85|norm don't use fully connected layers
4155.08|3.39|sort of all these architectural
4156.37|2.409|constraints that we've had become best
4158.47|2.47|pack
4158.779|4.8|in the last couple years just use those
4160.94|6.029|and it turns out that your adversarial
4163.579|5.25|Nets then work really well so here
4166.969|4.261|they're generator is this pretty pretty
4168.829|4.95|simple pretty simple pretty small up
4171.23|4.4|convolutional network and the the
4173.779|3.451|discriminator is again just a simple
4175.63|3.37|convolutional network with batch
4177.23|4.109|normalization and all these other bells
4179.0|4.02|and whistles and once you hook up this
4181.339|4.26|thing they get some amazing samples in
4183.02|5.849|this paper so these are generated
4185.599|5.94|bedrooms from the network so these
4188.869|5.911|actually are a pretty impressive results
4191.539|4.89|these look like real data almost so you
4194.78|3.689|can see that it's done a really good job
4196.429|3.54|of capturing the like really detailed
4198.469|3.061|structure about bedrooms like there's a
4199.969|3.96|bed there's a window there's a light
4201.53|7.339|switch so these are these are really
4203.929|7.92|amazing samples but it turns out that
4208.869|4.301|rather than just generating samples we
4211.849|3.181|can play the same trick as the
4213.17|3.54|variational auto encoder and actually
4215.03|5.009|try to try to play around with that
4216.71|5.04|latent space because this because these
4220.039|3.81|adversarial networks are receiving this
4221.75|3.989|noise input and we can cleverly try to
4223.849|3.6|move around that noise input and try to
4225.739|4.471|change the type of things that these
4227.449|4.561|networks generate so one example that we
4230.21|5.579|can try is interpolating between
4232.01|5.879|bedrooms so here on the left hand so
4235.789|3.961|here the idea is that on the left for
4237.889|3.9|these images on the left hand side we've
4239.75|3.57|drawn a random point from our noise
4241.789|3.511|distribution and then used it to
4243.32|3.87|generate an image and now on the right
4245.3|4.109|hand side we've done the same and we
4247.19|3.63|generate another random point from our
4249.409|4.051|noise distribution and use it to
4250.82|5.91|generate an image so now these these two
4253.46|5.699|guys on the opposite sides are generated
4256.73|4.259|are sort of two points on a line and now
4259.159|4.741|we want to interpolate in the latent
4260.989|5.13|space between those two latent z vectors
4263.9|5.04|and along that line we're going to
4266.119|5.011|generate use the use the generator to
4268.94|4.199|generate images and hopefully this will
4271.13|4.589|interpolate between the latent states of
4273.139|5.071|those two guys and you can see that this
4275.719|5.641|is pretty crazy that these bedrooms are
4278.21|5.279|morphing sort of in a very nice smooth
4281.36|5.94|continuous way from one bedroom to
4283.489|5.851|another and if one thing to point out is
4287.3|4.41|that this morphing is actually happening
4289.34|3.06|in kind of a nice semantic way if you
4291.71|2.58|imagine what
4292.4|3.45|this would look like in pixel space then
4294.29|3.27|it would just be kind of this fading
4295.85|2.16|effect and it would not look very good
4297.56|1.95|at all
4298.01|3.72|but here you can see that actually the
4299.51|4.05|shapes of these things and colors are
4301.73|7.29|sort of continuously deforming from one
4303.56|7.05|side to the other which is quite fun so
4309.02|3.36|another cool experiment they have in
4310.61|4.17|this paper is actually using vector math
4312.38|4.71|to play around the type of things that
4314.78|4.89|these networks generate so here the idea
4317.09|3.87|is that they generated a whole bunch of
4319.67|3.239|random samples from the noise
4320.96|3.54|distribution then push them all through
4322.909|4.891|the generator to generate a whole bunch
4324.5|4.65|of samples and then they as using their
4327.8|3.87|own human intelligence they tried to
4329.15|4.08|make some semantic judgments about what
4331.67|4.08|those random samples looked like and
4333.23|5.009|then group them into a couple meaningful
4335.75|4.83|semantic categories so here this would
4338.239|4.111|be three things that three images that
4340.58|3.51|were generated from the network that all
4342.35|4.92|kind of look like a smiling woman and
4344.09|4.649|those are human provided labels here in
4347.27|3.15|the middle are three samples from the
4348.739|3.69|network of a neutral woman that art
4350.42|4.739|that's not smiling and here on the right
4352.429|5.821|is three three samples of a man that is
4355.159|5.131|not smiling so each of these guys was
4358.25|5.01|produced from some latent state vector
4360.29|5.4|so we'll just average those latent state
4363.26|5.37|vectors to compute this sort of average
4365.69|5.52|average latent state of smiling women
4368.63|4.319|neutral women and neutral men now once
4371.21|3.989|we have this latent state vector we can
4372.949|4.561|do some vector math so we can take a
4375.199|5.851|smiling woman subtract a neutral woman
4377.51|6.899|and add a neutral man so what would that
4381.05|5.1|give you so you hope that would give you
4384.409|6.781|a smiling man and this is what it
4386.15|6.75|generates so this actually it does kind
4391.19|5.73|of look like a smiling man that's that's
4392.9|6.15|pretty amazing we can do another
4396.92|5.06|experiment so we can take a man with
4399.05|6.06|glasses and a man without glasses and
4401.98|6.63|man with glasses subtract the man with
4405.11|5.76|glasses and add a woman with glasses
4408.61|6.46|with no glasses sorry this this is
4410.87|6.829|confusing stuff so then what would this
4415.07|7.8|what would this little equation give us
4417.699|12.341|look at that so that's that's pretty
4422.87|9.329|crazy so it deficit prior on this latent
4430.04|3.929|state space these adversarial networks
4432.199|4.131|have somehow still managed to learn some
4433.969|5.371|really nice useful representation there
4436.33|5.32|so also very quickly I think there's a
4439.34|4.68|pretty cool paper that just came out a
4441.65|4.35|week or two ago that puts all of these
4444.02|3.54|ideas together like we covered a lot of
4446.0|3.69|different ideas in this lecture and
4447.56|3.63|let's just stick them all together so
4449.69|3.54|first we're going to take a variational
4451.19|4.56|auto-encoder as our starting point and
4453.23|3.75|this will have sort of the normal pixel
4455.75|3.719|wise loss from a variational auto
4456.98|4.5|encoder but we saw that these
4459.469|3.781|adversarial networks give really amazing
4461.48|3.69|samples so why don't we add an
4463.25|5.4|adversarial network to the variational
4465.17|5.069|auto encoder so we do that so now in
4468.65|3.569|addition to having our variational auto
4470.239|3.811|encoder we also have this this
4472.219|3.781|discriminator network that's trying to
4474.05|3.81|tell the difference between the real
4476.0|4.679|data and between the samples from the
4477.86|5.19|variational auto encoder but that's not
4480.679|6.421|cool enough so why don't we also
4483.05|6.32|download Alec's net and then pass these
4487.1|4.92|two images through Alec's net and
4489.37|4.78|extract Alec's net features for both the
4492.02|4.77|original image and for our generated
4494.15|5.19|image and now in addition to having a
4496.79|4.349|similar pixel loss and have an fooling
4499.34|3.75|the discriminator we're also hoping to
4501.139|4.981|generate samples that have similar Alex
4503.09|4.22|net features as measured by l2 and once
4506.12|2.94|you stick all these things together
4507.31|4.51|hopefully you'll get some really
4509.06|5.82|beautiful samples right so here are the
4511.82|5.64|examples from the paper so these are
4514.88|5.339|they just train the entire thing on
4517.46|4.259|image net so you should I think this is
4520.219|4.321|these are actually quite nice samples
4521.719|4.621|and if you contrast this with the multi
4524.54|4.02|scale samples on CFR that we saw before
4526.34|3.81|for those samples remember they were
4528.56|4.77|actually training a separate model per
4530.15|5.37|class in C far and these those beautiful
4533.33|4.17|bedroom samples that you saw was again
4535.52|4.65|training one model that's specific to
4537.5|5.67|bedrooms but here they actually trained
4540.17|4.71|one model on all of image net and still
4543.17|3.36|like these aren't real images but
4544.88|5.04|they're definitely getting tour
4546.53|5.58|real issue 'king images so that's I
4549.92|3.9|think these are pretty cool I also think
4552.11|2.94|it's kind of fun to just take all these
4553.82|4.58|things and stick them together and
4555.05|5.609|hopefully get some really nice samples
4558.4|3.4|so that's I think that's pretty much all
4560.659|3.891|we have to say about unsupervised
4561.8|15.21|learning so if there's any any questions
4564.55|17.049|yeah what does what what is going on
4577.01|6.12|here yeah so the question is are you may
4581.599|3.421|be literate linearizing the bedroom
4583.13|4.83|space and that's maybe one way to think
4585.02|4.53|about it that here remember we're just
4587.96|2.759|sampling front we're just sampling from
4589.55|3.0|noise and passing that through the
4590.719|4.561|discriminator or rather through the
4592.55|4.83|generator and then the generator has
4595.28|5.459|just decided to use these different
4597.38|5.069|noise channels in nice ways such that if
4600.739|3.721|you interpolate between the noise you
4602.449|4.141|end up interpolating between the images
4604.46|4.65|in a sort of a nice smooth way so
4606.59|4.08|hopefully that lets you know that it's
4609.11|2.67|not just sort of memorizing training
4610.67|4.4|examples it's actually learning to
4611.78|3.29|generalize from them in a nice way
4617.619|4.33|alright so just to recap everything we
4620.09|3.48|talked about today we well andre gave
4621.949|3.84|you a lot of really useful practical
4623.57|4.08|tips for working with videos and then i
4625.789|5.221|gave you a lot of very non practical
4627.65|5.04|tips for generating beautiful images so
4631.01|5.129|I think this unsupervised stuff is
4632.69|5.07|really cool but um I'm not sure what the
4636.139|3.631|uses other than generating images but
4637.76|3.87|it's cool so it's fun and definitely
4639.77|4.469|stick around next time because we'll
4641.63|4.17|have a guest lecture from Jeff Dean so
4644.239|3.061|if you're watching on the internet maybe
4645.8|4.589|you might want to come to class for that
4647.3|6.109|one so I think that's everything we have
4650.389|3.02|today and see you guys later
4654.269|3.0|it