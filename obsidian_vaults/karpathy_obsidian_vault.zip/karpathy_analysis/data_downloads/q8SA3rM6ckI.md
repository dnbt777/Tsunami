start_time|end_time|text
0.0|4.2|hi everyone so today we are once again
2.399|4.621|continuing our implementation of make
4.2|5.64|more now so far we've come up to here
7.02|4.38|montalia perceptrons and our neural net
9.84|2.64|looked like this and we were
11.4|1.98|implementing this over the last few
12.48|2.76|lectures
13.38|3.3|now I'm sure everyone is very excited to
15.24|3.119|go into recurring neural networks and
16.68|3.66|all of their variants and how they work
18.359|3.18|and the diagrams look cool and it's very
20.34|3.12|exciting and interesting and we're going
21.539|3.541|to get a better result but unfortunately
23.46|5.159|I think we have to remain here for one
25.08|5.459|more lecture and the reason for that is
28.619|3.24|we've already trained this multilio
30.539|3.061|perceptron right and we are getting
31.859|2.941|pretty good loss and I think we have a
33.6|4.08|pretty decent understanding of the
34.8|4.32|architecture and how it works but the
37.68|4.62|line of code here that I take an issue
39.12|6.0|with is here lost up backward that is we
42.3|4.62|are taking a pytorch auto grad and using
45.12|3.779|it to calculate all of our gradients
46.92|3.959|along the way and I would like to remove
48.899|3.301|the use of lost at backward and I would
50.879|4.261|like us to write our backward pass
52.2|4.26|manually on the level of tensors and I
55.14|3.72|think that this is a very useful
56.46|3.9|exercise for the following reasons
58.86|3.66|I actually have an entire blog post on
60.36|5.1|this topic but I'd like to call back
62.52|4.8|propagation a leaky abstraction
65.46|3.6|and what I mean by that is back
67.32|4.14|propagation does doesn't just make your
69.06|3.599|neural networks just work magically it's
71.46|2.699|not the case they can just Stack Up
72.659|3.601|arbitrary Lego blocks of differentiable
74.159|3.541|functions and just cross your fingers
76.26|3.48|and back propagate and everything is
77.7|4.32|great things don't just work
79.74|4.019|automatically it is a leaky abstraction
82.02|3.419|in the sense that you can shoot yourself
83.759|4.741|in the foot if you do not understanding
85.439|6.121|its internals it will magically not work
88.5|4.32|or not work optimally and you will need
91.56|3.419|to understand how it works under the
92.82|3.42|hood if you're hoping to debug it and if
94.979|2.82|you are hoping to address it in your
96.24|3.72|neural nut
97.799|4.561|um so this blog post here from a while
99.96|3.9|ago goes into some of those examples so
102.36|3.66|for example we've already covered them
103.86|5.04|some of them already for example the
106.02|5.459|flat tails of these functions and how
108.9|4.62|you do not want to saturate them too
111.479|3.661|much because your gradients will die the
113.52|2.879|case of dead neurons which I've already
115.14|3.479|covered as well
116.399|4.141|the case of exploding or Vanishing
118.619|4.201|gradients in the case of repair neural
120.54|5.039|networks which we are about to cover
122.82|4.74|and then also you will often come across
125.579|4.501|some examples in the wild
127.56|4.2|this is a snippet that I found uh in a
130.08|3.36|random code base on the internet where
131.76|3.72|they actually have like a very subtle
133.44|4.68|but pretty major bug in their
135.48|4.619|implementation and the bug points at the
138.12|3.18|fact that the author of this code does
140.099|3.061|not actually understand by propagation
141.3|3.96|so they're trying to do here is they're
143.16|4.26|trying to clip the loss at a certain
145.26|3.3|maximum value but actually what they're
147.42|2.76|trying to do is they're trying to
148.56|3.48|collect the gradients to have a maximum
150.18|4.02|value instead of trying to clip the loss
152.04|4.14|at a maximum value and
154.2|4.08|um indirectly they're basically causing
156.18|5.58|some of the outliers to be actually
158.28|5.52|ignored because when you clip a loss of
161.76|5.1|an outlier you are setting its gradient
163.8|5.159|to zero and so have a look through this
166.86|3.42|and read through it but there's
168.959|2.521|basically a bunch of subtle issues that
170.28|3.239|you're going to avoid if you actually
171.48|3.78|know what you're doing and that's why I
173.519|3.421|don't think it's the case that because
175.26|3.78|pytorch or other Frameworks offer
176.94|3.659|autograd it is okay for us to ignore how
179.04|3.6|it works
180.599|4.201|now we've actually already covered
182.64|4.679|covered autograd and we wrote micrograd
184.8|4.38|but micrograd was an autograd engine
187.319|3.78|only on the level of individual scalars
189.18|4.44|so the atoms were single individual
191.099|3.841|numbers and uh you know I don't think
193.62|3.0|it's enough and I'd like us to basically
194.94|4.2|think about back propagation on level of
196.62|5.039|tensors as well and so in a summary I
199.14|4.08|think it's a good exercise I think it is
201.659|3.421|very very valuable you're going to
203.22|3.84|become better at debugging neural
205.08|3.78|networks and making sure that you
207.06|3.179|understand what you're doing it is going
208.86|2.4|to make everything fully explicit so
210.239|3.121|you're not going to be nervous about
211.26|3.42|what is hidden away from you and
213.36|4.2|basically in general we're going to
214.68|5.4|emerge stronger and so let's get into it
217.56|4.56|a bit of a fun historical note here is
220.08|3.84|that today writing your backward pass by
222.12|3.6|hand and manually is not recommended and
223.92|4.379|no one does it except for the purposes
225.72|4.14|of exercise but about 10 years ago in
228.299|3.961|deep learning this was fairly standard
229.86|3.599|and in fact pervasive so at the time
232.26|3.0|everyone used to write their own
233.459|4.021|backward pass by hand manually including
235.26|4.32|myself and it's just what you would do
237.48|4.2|so we used to ride backward pass by hand
239.58|4.86|and now everyone just calls lost that
241.68|5.46|backward uh we've lost something I want
244.44|6.659|to give you a few examples of this so
247.14|6.48|here's a 2006 paper from Jeff Hinton and
251.099|4.321|Russell selectinov in science that was
253.62|4.32|influential at the time and this was
255.42|4.379|training some architectures called
257.94|4.079|restricted bolstery machines and
259.799|6.361|basically it's an auto encoder trained
262.019|5.521|here and this is from roughly 2010 I had
266.16|4.14|a library for training researchable
267.54|4.86|machines and this was at the time
270.3|3.899|written in Matlab so python was not used
272.4|4.26|for deep learning pervasively it was all
274.199|5.161|Matlab and Matlab was this a scientific
276.66|4.92|Computing package that everyone would
279.36|4.86|use so we would write Matlab which is
281.58|4.619|barely a programming language as well
284.22|3.9|but I've had a very convenient tensor
286.199|3.301|class and was this a Computing
288.12|3.48|environment and you would run here it
289.5|3.66|would all run on a CPU of course but you
291.6|3.3|would have very nice plots to go with it
293.16|4.68|and a built-in debugger and it was
294.9|5.82|pretty nice now the code in this package
297.84|5.16|in 2010 that I wrote for fitting
300.72|4.32|research multiple machines to a large
303.0|4.02|extent is recognizable but I wanted to
305.04|4.2|show you how you would well I'm creating
307.02|4.8|the data in the XY batches I'm
309.24|4.019|initializing the neural nut so it's got
311.82|3.42|weights and biases just like we're used
313.259|3.961|to and then this is the training Loop
315.24|4.739|where we actually do the forward pass
317.22|4.32|and then here at this time they didn't
319.979|3.541|even necessarily use back propagation to
321.54|3.719|train neural networks so this in
323.52|4.619|particular implements contrastive
325.259|5.28|Divergence which estimates a gradient
328.139|4.441|and then here we take that gradient and
330.539|4.021|use it for a parameter update along the
332.58|4.02|lines that we're used to
334.56|3.479|um yeah here
336.6|3.0|but you can see that basically people
338.039|3.901|are meddling with these gradients uh
339.6|3.78|directly and inline and themselves uh it
341.94|3.36|wasn't that common to use an auto grad
343.38|4.44|engine here's one more example from a
345.3|4.619|paper of mine from 2014
347.82|3.54|um called the fragmented embeddings
349.919|3.421|and here what I was doing is I was
351.36|3.839|aligning images and text
353.34|3.54|um and so it's kind of like a clip if
355.199|3.06|you're familiar with it but instead of
356.88|3.3|working on the level of entire images
358.259|3.541|and entire sentences it was working on
360.18|3.54|the level of individual objects and
361.8|3.72|little pieces of sentences and I was
363.72|4.319|embedding them and then calculating very
365.52|4.86|much like a clip-like loss and I dig up
368.039|5.22|the code from 2014 of how I implemented
370.38|4.14|this and it was already in numpy and
373.259|3.241|python
374.52|4.679|and here I'm planting the cost function
376.5|4.44|and it was standard to implement not
379.199|4.5|just the cost but also the backward pass
380.94|5.099|manually so here I'm calculating the
383.699|4.921|image embeddings sentence embeddings the
386.039|5.22|loss function I calculate this course
388.62|3.96|this is the loss function and then once
391.259|3.361|I have the loss function I do the
392.58|3.959|backward pass right here so I backward
394.62|3.6|through the loss function and through
396.539|4.741|the neural nut and I append
398.22|4.56|regularization so everything was done by
401.28|3.18|hand manually and you were just right
402.78|3.72|out the backward pass and then you would
404.46|3.48|use a gradient Checker to make sure that
406.5|2.94|your numerical estimate of the gradient
407.94|3.96|agrees with the one you calculated
409.44|4.08|during back propagation so this was very
411.9|3.239|standard for a long time but today of
413.52|3.299|course it is standard to use an auto
415.139|3.421|grad engine
416.819|3.0|um but it was definitely useful and I
418.56|2.579|think people sort of understood how
419.819|3.301|these neural networks work on a very
421.139|3.541|intuitive level and so I think it's a
423.12|3.359|good exercise again and this is where we
424.68|3.54|want to be okay so just as a reminder
426.479|3.361|from our previous lecture this is The
428.22|3.539|jupyter Notebook that we implemented at
429.84|3.54|the time and
431.759|3.241|we're going to keep everything the same
433.38|3.24|so we're still going to have a two layer
435.0|3.66|multiplayer perceptron with a batch
436.62|3.66|normalization layer so the forward pass
438.66|3.36|will be basically identical to this
440.28|3.359|lecture but here we're going to get rid
442.02|2.64|of lost and backward and instead we're
443.639|2.4|going to write the backward pass
444.66|3.0|manually
446.039|3.481|now here's the starter code for this
447.66|3.84|lecture we are becoming a back prop
449.52|4.5|ninja in this notebook
451.5|4.5|and the first few cells here are
454.02|3.959|identical to what we are used to so we
456.0|4.139|are doing some imports loading the data
457.979|3.601|set and processing the data set none of
460.139|3.18|this changed
461.58|3.119|now here I'm introducing a utility
463.319|3.301|function that we're going to use later
464.699|3.0|to compare the gradients so in
466.62|2.519|particular we are going to have the
467.699|3.06|gradients that we estimate manually
469.139|4.141|ourselves and we're going to have
470.759|3.72|gradients that Pi torch calculates and
473.28|2.639|we're going to be checking for
474.479|4.44|correctness assuming of course that
475.919|4.381|pytorch is correct
478.919|4.081|um then here we have the initialization
480.3|4.86|that we are quite used to so we have our
483.0|3.78|embedding table for the characters the
485.16|3.18|first layer second layer and the batch
486.78|3.0|normalization in between
488.34|3.54|and here's where we create all the
489.78|3.72|parameters now you will note that I
491.88|4.2|changed the initialization a little bit
493.5|4.74|uh to be small numbers so normally you
496.08|4.019|would set the biases to be all zero here
498.24|4.56|I am setting them to be small random
500.099|4.44|numbers and I'm doing this because
502.8|3.42|if your variables are initialized to
504.539|3.541|exactly zero sometimes what can happen
506.22|4.14|is that can mask an incorrect
508.08|4.44|implementation of a gradient
510.36|3.66|um because uh when everything is zero it
512.52|2.759|sort of like simplifies and gives you a
514.02|3.42|much simpler expression of the gradient
515.279|3.961|than you would otherwise get and so by
517.44|4.32|making it small numbers I'm trying to
519.24|3.9|unmask those potential errors in these
521.76|4.74|calculations
523.14|5.28|you also notice that I'm using uh B1 in
526.5|4.44|the first layer I'm using a bias despite
528.42|4.38|batch normalization right afterwards
530.94|3.24|um so this would typically not be what
532.8|3.12|you do because we talked about the fact
534.18|3.719|that you don't need the bias but I'm
535.92|3.06|doing this here just for fun
537.899|2.461|um because we're going to have a
538.98|2.82|gradient with respect to it and we can
540.36|3.18|check that we are still calculating it
541.8|3.36|correctly even though this bias is
543.54|3.72|asparious
545.16|5.16|so here I'm calculating a single batch
547.26|4.44|and then here I'm doing a forward pass
550.32|3.36|now you'll notice that the forward pass
551.7|3.9|is significantly expanded from what we
553.68|2.94|are used to here the forward pass was
555.6|2.28|just
556.62|3.0|um here
557.88|4.2|now the reason that the forward pass is
559.62|4.38|longer is for two reasons number one
562.08|4.439|here we just had an F dot cross entropy
564.0|4.38|but here I am bringing back a explicit
566.519|3.301|implementation of the loss function
568.38|3.66|and number two
569.82|5.519|I've broken up the implementation into
572.04|5.04|manageable chunks so we have a lot a lot
575.339|3.481|more intermediate tensors along the way
577.08|3.42|in the forward pass and that's because
578.82|4.019|we are about to go backwards and
580.5|5.22|calculate the gradients in this back
582.839|5.581|propagation from the bottom to the top
585.72|4.2|so we're going to go upwards and just
588.42|3.539|like we have for example the lock props
589.92|3.78|tensor in a forward pass in the backward
591.959|3.241|pass we're going to have a d-lock probes
593.7|2.819|which is going to store the derivative
595.2|3.48|of the loss with respect to the lock
596.519|4.38|props tensor and so we're going to be
598.68|4.26|prepending D to every one of these
600.899|4.021|tensors and calculating it along the way
602.94|4.38|of this back propagation
604.92|4.2|so as an example we have a b and raw
607.32|5.28|here we're going to be calculating a DB
609.12|5.52|in raw so here I'm telling pytorch that
612.6|4.14|we want to retain the grad of all these
614.64|3.84|intermediate values because here in
616.74|3.539|exercise one we're going to calculate
618.48|4.08|the backward pass so we're going to
620.279|4.801|calculate all these D values D variables
622.56|4.2|and use the CNP function I've introduced
625.08|4.319|above to check our correctness with
626.76|4.68|respect to what pi torch is telling us
629.399|3.421|this is going to be exercise one uh
631.44|3.24|where we sort of back propagate through
632.82|3.42|this entire graph
634.68|2.82|now just to give you a very quick
636.24|4.14|preview of what's going to happen in
637.5|5.82|exercise two and below here we have
640.38|5.22|fully broken up the loss and back
643.32|4.5|propagated through it manually in all
645.6|3.54|the little Atomic pieces that make it up
647.82|3.079|but here we're going to collapse the
649.14|4.199|laws into a single cross-entropy call
650.899|6.041|and instead we're going to analytically
653.339|6.18|derive using math and paper and pencil
656.94|4.2|the gradient of the loss with respect to
659.519|2.82|the logits and instead of back
661.14|3.3|propagating through all of its little
662.339|3.541|chunks one at a time we're just going to
664.44|3.0|analytically derive what that gradient
665.88|3.3|is and we're going to implement that
667.44|3.24|which is much more efficient as we'll
669.18|3.48|see in the in a bit
670.68|3.96|then we're going to do the exact same
672.66|3.48|thing for patch normalization so instead
674.64|3.96|of breaking up bass drum into all the
676.14|4.68|old tiny components we're going to use
678.6|4.32|uh pen and paper and Mathematics and
680.82|4.56|calculus to derive the gradient through
682.92|4.08|the bachelor Bachelor layer so we're
685.38|3.12|going to calculate the backward
687.0|3.24|passthrough bathroom layer in a much
688.5|3.12|more efficient expression instead of
690.24|3.36|backward propagating through all of its
691.62|4.86|little pieces independently
693.6|4.44|so there's going to be exercise three
696.48|3.539|and then in exercise four we're going to
698.04|4.68|put it all together and this is the full
700.019|4.38|code of training this two layer MLP and
702.72|3.42|we're going to basically insert our
704.399|4.081|manual back prop and we're going to take
706.14|4.62|out lost it backward and you will
708.48|5.099|basically see that you can get all the
710.76|5.22|same results using fully your own code
713.579|5.7|and the only thing we're using from
715.98|5.7|pytorch is the torch.tensor to make the
719.279|4.021|calculations efficient but otherwise you
721.68|3.06|will understand fully what it means to
723.3|3.12|forward and backward and neural net and
724.74|3.36|train it and I think that'll be awesome
726.42|3.599|so let's get to it
728.1|5.04|okay so I read all the cells of this
730.019|4.681|notebook all the way up to here and I'm
733.14|2.759|going to erase this and I'm going to
734.7|4.02|start implementing backward pass
735.899|4.56|starting with d lock problems so we want
738.72|3.359|to understand what should go here to
740.459|3.301|calculate the gradient of the loss with
742.079|3.0|respect to all the elements of the log
743.76|3.12|props tensor
745.079|3.301|now I'm going to give away the answer
746.88|3.36|here but I wanted to put a quick note
748.38|4.079|here that I think would be most
750.24|4.26|pedagogically useful for you is to
752.459|4.201|actually go into the description of this
754.5|3.899|video and find the link to this Jupiter
756.66|3.48|notebook you can find it both on GitHub
758.399|2.94|but you can also find Google collab with
760.14|2.999|it so you don't have to install anything
761.339|3.841|you'll just go to a website on Google
763.139|4.82|collab and you can try to implement
765.18|5.339|these derivatives or gradients yourself
767.959|5.32|and then if you are not able to come to
770.519|4.921|my video and see me do it and so work in
773.279|4.68|Tandem and try it first yourself and
775.44|3.66|then see me give away the answer and I
777.959|2.281|think that'll be most valuable to you
779.1|2.34|and that's how I recommend you go
780.24|3.3|through this lecture
781.44|5.519|so we are starting here with d-log props
783.54|5.099|now d-lock props will hold the
786.959|4.38|derivative of the loss with respect to
788.639|5.041|all the elements of log props
791.339|6.841|what is inside log blobs the shape of
793.68|5.94|this is 32 by 27. so it's not going to
798.18|3.719|surprise you that D log props should
799.62|4.14|also be an array of size 32 by 27
801.899|4.141|because we want the derivative loss with
803.76|3.78|respect to all of its elements so the
806.04|3.479|sizes of those are always going to be
807.54|5.58|equal
809.519|7.38|now how how does log props influence the
813.12|7.56|loss okay loss is negative block probes
816.899|5.961|indexed with range of N and YB and then
820.68|7.14|the mean of that now just as a reminder
822.86|8.68|YB is just a basically an array of all
827.82|5.16|the correct indices
831.54|3.18|um so what we're doing here is we're
832.98|4.32|taking the lock props array of size 32
834.72|4.2|by 27.
837.3|3.659|right
838.92|4.2|and then we are going in every single
840.959|5.341|row and in each row we are plugging
843.12|4.86|plucking out the index eight and then 14
846.3|4.62|and 15 and so on so we're going down the
847.98|4.919|rows that's the iterator range of N and
850.92|4.32|then we are always plucking out the
852.899|4.861|index of the column specified by this
855.24|4.92|tensor YB so in the zeroth row we are
857.76|5.579|taking the eighth column in the first
860.16|6.359|row we're taking the 14th column Etc and
863.339|5.12|so log props at this plugs out
866.519|4.38|all those
868.459|4.301|log probabilities of the correct next
870.899|3.841|character in a sequence
872.76|3.78|so that's what that does and the shape
874.74|5.76|of this or the size of it is of course
876.54|6.72|32 because our batch size is 32.
880.5|5.1|so these elements get plugged out and
883.26|3.96|then their mean and the negative of that
885.6|4.14|becomes loss
887.22|5.1|so I always like to work with simpler
889.74|5.459|examples to understand the numerical
892.32|6.48|form of derivative what's going on here
895.199|5.521|is once we've plucked out these examples
898.8|4.02|um we're taking the mean and then the
900.72|4.2|negative so the loss basically
902.82|5.04|I can write it this way is the negative
904.92|4.44|of say a plus b plus c
907.86|3.419|and the mean of those three numbers
909.36|3.839|would be say negative would divide three
911.279|3.961|that would be how we achieve the mean of
913.199|3.781|three numbers ABC although we actually
915.24|5.099|have 32 numbers here
916.98|5.46|and so what is basically the loss by say
920.339|4.321|like d a right
922.44|3.72|well if we simplify this expression
924.66|3.66|mathematically this is negative one over
926.16|4.22|three of A and negative plus negative
928.32|5.459|one over three of B
930.38|5.319|plus negative 1 over 3 of c and so what
933.779|3.0|is D loss by D A it's just negative one
935.699|2.82|over three
936.779|3.92|and so you can see that if we don't just
938.519|5.281|have a b and c but we have 32 numbers
940.699|4.541|then D loss by D
943.8|3.599|um you know every one of those numbers
945.24|5.58|is going to be one over N More generally
947.399|5.641|because n is the um the size of the
950.82|4.98|batch 32 in this case
953.04|6.78|so D loss by
955.8|6.3|um D Lock probs is negative 1 over n
959.82|4.259|in all these places
962.1|3.84|now what about the other elements inside
964.079|3.721|lock problems because lock props is
965.94|5.22|large array you see that lock problems
967.8|5.94|at shape is 32 by 27. but only 32 of
971.16|4.799|them participate in the loss calculation
973.74|4.74|so what's the derivative of all the
975.959|4.38|other most of the elements that do not
978.48|3.599|get plucked out here
980.339|3.961|while their loss intuitively is zero
982.079|3.721|sorry they're gradient intuitively is
984.3|3.12|zero and that's because they did not
985.8|3.839|participate in the loss
987.42|4.8|so most of these numbers inside this
989.639|3.961|tensor does not feed into the loss and
992.22|3.9|so if we were to change these numbers
993.6|5.159|then the loss doesn't change which is
996.12|3.719|the equivalent of way of saying that the
998.759|4.561|derivative of the loss with respect to
999.839|5.521|them is zero they don't impact it
1003.32|4.199|so here's a way to implement this
1005.36|5.46|derivative then we start out with
1007.519|5.221|torch.zeros of shape 32 by 27 or let's
1010.82|3.6|just say instead of doing this because
1012.74|4.26|we don't want to hard code numbers let's
1014.42|4.62|do torch.zeros like
1017.0|3.66|block probs so basically this is going
1019.04|3.539|to create an array of zeros exactly in
1020.66|4.44|the shape of log probs
1022.579|4.561|and then we need to set the derivative
1025.1|4.859|of negative 1 over n inside exactly
1027.14|5.699|these locations so here's what we can do
1029.959|4.321|the lock props indexed in The Identical
1032.839|3.6|way
1034.28|5.519|will be just set to negative one over
1036.439|6.12|zero divide n
1039.799|6.061|right just like we derived here
1042.559|4.561|so now let me erase all this reasoning
1045.86|4.08|and then this is the candidate
1047.12|4.679|derivative for D log props let's
1049.94|4.32|uncomment the first line and check that
1051.799|7.921|this is correct
1054.26|6.96|okay so CMP ran and let's go back to CMP
1059.72|3.12|and you see that what it's doing is it's
1061.22|4.86|calculating if
1062.84|5.339|the calculated value by us which is DT
1066.08|4.979|is exactly equal to T dot grad as
1068.179|4.5|calculated by pi torch and then this is
1071.059|3.901|making sure that all the elements are
1072.679|4.5|exactly equal and then converting this
1074.96|3.48|to a single Boolean value because we
1077.179|2.88|don't want the Boolean tensor we just
1078.44|4.32|want to Boolean value
1080.059|4.261|and then here we are making sure that
1082.76|3.24|okay if they're not exactly equal maybe
1084.32|3.239|they are approximately equal because of
1086.0|3.12|some floating Point issues but they're
1087.559|3.36|very very close
1089.12|3.9|so here we are using torch.allclose
1090.919|4.38|which has a little bit of a wiggle
1093.02|4.74|available because sometimes you can get
1095.299|4.081|very very close but if you use a
1097.76|4.799|slightly different calculation because a
1099.38|5.039|floating Point arithmetic you can get a
1102.559|3.301|slightly different result so this is
1104.419|2.88|checking if you get an approximately
1105.86|2.939|close result
1107.299|4.321|and then here we are checking the
1108.799|5.401|maximum uh basically the value that has
1111.62|4.26|the highest difference and what is the
1114.2|3.66|difference in the absolute value
1115.88|3.48|difference between those two and so we
1117.86|4.199|are printing whether we have an exact
1119.36|5.64|equality an approximate equality and
1122.059|4.801|what is the largest difference
1125.0|3.36|and so here
1126.86|3.42|we see that we actually have exact
1128.36|4.08|equality and so therefore of course we
1130.28|4.32|also have an approximate equality and
1132.44|5.22|the maximum difference is exactly zero
1134.6|6.26|so basically our d-log props is exactly
1137.66|6.12|equal to what pytors calculated to be
1140.86|5.679|lockprops.grad in its back propagation
1143.78|3.84|so so far we're working pretty well okay
1146.539|2.161|so let's now continue our back
1147.62|2.939|propagation
1148.7|3.78|we have that lock props depends on
1150.559|3.721|probes through a log
1152.48|5.1|so all the elements of probes are being
1154.28|5.46|element wise applied log to
1157.58|4.56|now if we want deep props then then
1159.74|4.799|remember your micrograph training
1162.14|5.64|we have like a log node it takes in
1164.539|5.461|probs and creates log probs and the
1167.78|5.639|props will be the local derivative of
1170.0|4.86|that individual Operation Log times the
1173.419|4.14|derivative loss with respect to its
1174.86|4.74|output which in this case is D log props
1177.559|3.961|so what is the local derivative of this
1179.6|4.199|operation well we are taking log element
1181.52|4.32|wise and we can come here and we can see
1183.799|4.141|well from alpha is your friend that d by
1185.84|3.12|DX of log of x is just simply one of our
1187.94|3.72|X
1188.96|5.94|so therefore in this case X is problems
1191.66|5.28|so we have d by DX is one over X which
1194.9|4.08|is one of our probes and then this is
1196.94|3.239|the local derivative and then times we
1198.98|2.699|want to chain it
1200.179|3.36|so this is chain rule
1201.679|4.561|times do log props
1203.539|5.341|let me uncomment this and let me run the
1206.24|4.08|cell in place and we see that the
1208.88|4.02|derivative of props as we calculated
1210.32|5.4|here is exactly correct
1212.9|5.399|and so notice here how this works probes
1215.72|5.04|that are props is going to be inverted
1218.299|4.801|and then element was multiplied here
1220.76|4.26|so if your probes is very very close to
1223.1|3.0|one that means you are your network is
1225.02|3.18|currently predicting the character
1226.1|4.62|correctly then this will become one over
1228.2|3.42|one and D log probes just gets passed
1230.72|2.339|through
1231.62|3.78|but if your probabilities are
1233.059|4.321|incorrectly assigned so if the correct
1235.4|6.24|character here is getting a very low
1237.38|5.88|probability then 1.0 dividing by it will
1241.64|4.02|boost this
1243.26|3.539|and then multiply by the log props so
1245.66|3.72|basically what this line is doing
1246.799|4.141|intuitively is it's taking the examples
1249.38|3.48|that have a very low probability
1250.94|4.08|currently assigned and it's boosting
1252.86|6.42|their gradient uh you can you can look
1255.02|7.74|at it that way next up is Count some imp
1259.28|5.82|so we want the river of this now let me
1262.76|4.08|just pause here and kind of introduce
1265.1|3.54|What's Happening Here in general because
1266.84|3.0|I know it's a little bit confusing we
1268.64|3.3|have the locusts that come out of the
1269.84|5.16|neural nut here what I'm doing is I'm
1271.94|4.56|finding the maximum in each row and I'm
1275.0|3.24|subtracting it for the purposes of
1276.5|4.02|numerical stability and we talked about
1278.24|4.02|how if you do not do this you run
1280.52|4.019|numerical issues if some of the logits
1282.26|4.08|take on two large values because we end
1284.539|3.721|up exponentiating them
1286.34|4.319|so this is done just for safety
1288.26|4.34|numerically then here's the
1290.659|5.161|exponentiation of all the sort of like
1292.6|5.439|logits to create our accounts and then
1295.82|4.44|we want to take the some of these counts
1298.039|3.601|and normalize so that all of the probes
1300.26|3.299|sum to one
1301.64|4.38|now here instead of using one over count
1303.559|4.081|sum I use uh raised to the power of
1306.02|3.3|negative one mathematically they are
1307.64|2.82|identical I just found that there's
1309.32|2.7|something wrong with the pytorch
1310.46|3.0|implementation of the backward pass of
1312.02|3.96|division
1313.46|4.68|um and it gives like a real result but
1315.98|3.84|that doesn't happen for star star native
1318.14|3.779|one that's why I'm using this formula
1319.82|4.32|instead but basically all that's
1321.919|3.541|happening here is we got the logits
1324.14|3.539|we're going to exponentiate all of them
1325.46|4.26|and want to normalize the counts to
1327.679|4.86|create our probabilities it's just that
1329.72|4.5|it's happening across multiple lines
1332.539|4.681|so now
1334.22|3.0|here
1337.7|4.14|we want to First Take the derivative we
1340.7|3.719|want to back propagate into account
1341.84|6.719|sumiv and then into counts as well
1344.419|5.521|so what should be the count sum M now we
1348.559|3.661|actually have to be careful here because
1349.94|6.0|we have to scrutinize and be careful
1352.22|7.02|with the shapes so counts that shape and
1355.94|4.68|then count some inverse shape
1359.24|4.2|are different
1360.62|6.539|so in particular counts as 32 by 27 but
1363.44|5.7|this count sum m is 32 by 1. and so in
1367.159|4.861|this multiplication here we also have an
1369.14|4.62|implicit broadcasting that pytorch will
1372.02|3.659|do because it needs to take this column
1373.76|4.74|tensor of 32 numbers and replicate it
1375.679|4.74|horizontally 27 times to align these two
1378.5|3.12|tensors so it can do an element twice
1380.419|3.12|multiply
1381.62|4.679|so really what this looks like is the
1383.539|4.741|following using a toy example again
1386.299|3.961|what we really have here is just props
1388.28|3.48|is counts times conservative so it's a C
1390.26|4.799|equals a times B
1391.76|5.82|but a is 3 by 3 and b is just three by
1395.059|4.801|one a column tensor and so pytorch
1397.58|4.86|internally replicated this elements of B
1399.86|4.679|and it did that across all the columns
1402.44|3.96|so for example B1 which is the first
1404.539|3.241|element of B would be replicated here
1406.4|2.88|across all the columns in this
1407.78|3.24|multiplication
1409.28|4.92|and now we're trying to back propagate
1411.02|4.86|through this operation to count some m
1414.2|3.18|so when we're calculating this
1415.88|3.48|derivative
1417.38|4.38|it's important to realize that these two
1419.36|4.679|this looks like a single operation but
1421.76|4.5|actually is two operations applied
1424.039|4.321|sequentially the first operation that
1426.26|5.76|pytorch did is it took this column
1428.36|5.76|tensor and replicated it across all the
1432.02|3.899|um across all the columns basically 27
1434.12|3.419|times so that's the first operation it's
1435.919|3.961|a replication and then the second
1437.539|3.541|operation is the multiplication so let's
1439.88|2.7|first background through the
1441.08|4.56|multiplication
1442.58|5.7|if these two arrays are of the same size
1445.64|5.519|and we just have a and b of both of them
1448.28|3.84|three by three then how do we mult how
1451.159|2.88|do we back propagate through a
1452.12|4.02|multiplication so if we just have
1454.039|5.281|scalars and not tensors then if you have
1456.14|5.399|C equals a times B then what is uh the
1459.32|4.14|order of the of C with respect to B well
1461.539|3.12|it's just a and so that's the local
1463.46|3.599|derivative
1464.659|4.38|so here in our case undoing the
1467.059|3.48|multiplication and back propagating
1469.039|3.961|through just the multiplication itself
1470.539|5.52|which is element wise is going to be the
1473.0|7.26|local derivative which in this case is
1476.059|6.0|simply counts because counts is the a
1480.26|5.88|so this is the local derivative and then
1482.059|6.541|times because the chain rule D props
1486.14|4.62|so this here is the derivative or the
1488.6|3.48|gradient but with respect to replicated
1490.76|3.36|B
1492.08|4.38|but we don't have a replicated B we just
1494.12|5.22|have a single B column so how do we now
1496.46|5.76|back propagate through the replication
1499.34|4.68|and intuitively this B1 is the same
1502.22|2.699|variable and it's just reused multiple
1504.02|3.3|times
1504.919|4.441|and so you can look at it
1507.32|3.66|as being equivalent to a case we've
1509.36|3.36|encountered in micrograd
1510.98|3.96|and so here I'm just pulling out a
1512.72|5.04|random graph we used in micrograd we had
1514.94|4.92|an example where a single node
1517.76|4.98|has its output feeding into two branches
1519.86|5.16|of basically the graph until the last
1522.74|3.539|function and we're talking about how the
1525.02|4.019|correct thing to do in the backward pass
1526.279|5.581|is we need to sum all the gradients that
1529.039|4.38|arrive at any one node so across these
1531.86|2.939|different branches the gradients would
1533.419|3.901|sum
1534.799|4.98|so if a node is used multiple times the
1537.32|4.14|gradients for all of its uses sum during
1539.779|4.26|back propagation
1541.46|4.199|so here B1 is used multiple times in all
1544.039|4.341|these columns and therefore the right
1545.659|5.821|thing to do here is to sum
1548.38|4.36|horizontally across all the rows so I'm
1551.48|4.319|going to sum in
1552.74|5.58|Dimension one but we want to retain this
1555.799|4.5|Dimension so that the uh so that counts
1558.32|4.08|some end and its gradient are going to
1560.299|4.561|be exactly the same shape so we want to
1562.4|4.74|make sure that we keep them as true so
1564.86|4.08|we don't lose this dimension and this
1567.14|4.32|will make the count sum M be exactly
1568.94|5.82|shape 32 by 1.
1571.46|5.819|so revealing this comparison as well and
1574.76|3.6|running this we see that we get an exact
1577.279|4.981|match
1578.36|6.059|so this derivative is exactly correct
1582.26|4.62|and let me erase
1584.419|5.161|this now let's also back propagate into
1586.88|5.279|counts which is the other variable here
1589.58|4.199|to create probes so from props to count
1592.159|3.241|some INF we just did that let's go into
1593.779|5.601|counts as well
1595.4|3.98|so decounts will be
1599.779|7.741|the chances are a so DC by d a is just B
1603.62|7.62|so therefore it's count summative
1607.52|6.96|um and then times chain rule the props
1611.24|6.66|now councilman is three two by One D
1614.48|4.679|probs is 32 by 27.
1617.9|4.44|so
1619.159|5.281|um those will broadcast fine and will
1622.34|4.319|give us decounts there's no additional
1624.44|4.44|summation required here
1626.659|4.441|um there will be a broadcasting that
1628.88|3.84|happens in this multiply here because
1631.1|5.4|count some M needs to be replicated
1632.72|5.939|again to correctly multiply D props but
1636.5|4.38|that's going to give the correct result
1638.659|4.62|so as far as the single operation is
1640.88|4.5|concerned so we back probably go from
1643.279|6.121|props to counts but we can't actually
1645.38|6.06|check the derivative counts uh I have it
1649.4|4.98|much later on and the reason for that is
1651.44|4.739|because count sum in depends on counts
1654.38|3.96|and so there's a second Branch here that
1656.179|4.141|we have to finish because can't summon
1658.34|3.78|back propagates into account sum and
1660.32|4.2|count sum will buy properly into counts
1662.12|4.74|and so counts is a node that is being
1664.52|3.72|used twice it's used right here in two
1666.86|3.48|props and it goes through this other
1668.24|4.38|Branch through count summative
1670.34|3.78|so even though we've calculated the
1672.62|3.12|first contribution of it we still have
1674.12|2.88|to calculate the second contribution of
1675.74|2.88|it later
1677.0|3.6|okay so we're continuing with this
1678.62|3.72|Branch we have the derivative for count
1680.6|5.34|sum if now we want the derivative of
1682.34|4.98|count sum so D count sum equals what is
1685.94|3.78|the local derivative of this operation
1687.32|4.62|so this is basically an element wise one
1689.72|3.9|over counts sum
1691.94|3.479|so count sum raised to the power of
1693.62|4.2|negative one is the same as one over
1695.419|4.86|count sum if we go to all from alpha we
1697.82|5.339|see that x to the negative one D by D by
1700.279|5.701|D by DX of it is basically Negative X to
1703.159|4.38|the negative 2. right one negative one
1705.98|3.24|over squared is the same as Negative X
1707.539|5.101|to the negative two
1709.22|6.42|so D count sum here will be local
1712.64|3.539|derivative is going to be negative
1715.64|3.779|um
1716.179|5.701|counts sum to the negative two that's
1719.419|6.921|the local derivative times chain rule
1721.88|4.46|which is D count sum in
1726.74|4.919|so that's D count sum
1729.26|6.12|let's uncomment this and check that I am
1731.659|6.421|correct okay so we have perfect equality
1735.38|4.38|and there's no sketchiness going on here
1738.08|4.26|with any shapes because these are of the
1739.76|4.38|same shape okay next up we want to back
1742.34|4.98|propagate through this line we have that
1744.14|5.279|count sum it's count.sum along the rows
1747.32|4.44|so I wrote out
1749.419|4.321|um some help here we have to keep in
1751.76|5.519|mind that counts of course is 32 by 27
1753.74|6.179|and count sum is 32 by 1. so in this
1757.279|5.221|back propagation we need to take this
1759.919|4.62|column of derivatives and transform it
1762.5|4.2|into a array of derivatives
1764.539|4.441|two-dimensional array
1766.7|4.32|so what is this operation doing we're
1768.98|3.78|taking in some kind of an input like say
1771.02|4.98|a three by three Matrix a and we are
1772.76|7.139|summing up the rows into a column tells
1776.0|5.88|her B1 b2b3 that is basically this
1779.899|4.38|so now we have the derivatives of the
1781.88|3.24|loss with respect to B all the elements
1784.279|2.76|of B
1785.12|4.62|and now we want to derivative loss with
1787.039|5.76|respect to all these little A's
1789.74|4.38|so how do the B's depend on the ace is
1792.799|3.541|basically what we're after what is the
1794.12|4.08|local derivative of this operation
1796.34|5.28|well we can see here that B1 only
1798.2|5.04|depends on these elements here the
1801.62|4.799|derivative of B1 with respect to all of
1803.24|6.059|these elements down here is zero but for
1806.419|6.721|these elements here like a11 a12 Etc the
1809.299|6.901|local derivative is one right so DB 1 by
1813.14|4.86|D A 1 1 for example is one so it's one
1816.2|3.719|one and one
1818.0|3.48|so when we have the derivative of loss
1819.919|3.601|with respect to B1
1821.48|4.14|did a local derivative of B1 with
1823.52|4.32|respect to these inputs is zeros here
1825.62|4.26|but it's one on these guys
1827.84|4.579|so in the chain rule
1829.88|5.94|we have the local derivative uh times
1832.419|5.441|sort of the derivative of B1 and so
1835.82|4.079|because the local derivative is one on
1837.86|3.84|these three elements the look of them
1839.899|5.701|are multiplying the derivative of B1
1841.7|5.88|will just be the derivative of B1 and so
1845.6|4.799|you can look at it as a router basically
1847.58|4.44|an addition is a router of gradient
1850.399|3.421|whatever gradient comes from above it
1852.02|3.12|just gets routed equally to all the
1853.82|2.28|elements that participate in that
1855.14|3.18|addition
1856.1|4.74|so in this case the derivative of B1
1858.32|4.979|will just flow equally to the derivative
1860.84|4.26|of a11 a12 and a13
1863.299|4.441|. so if we have a derivative of all the
1865.1|5.28|elements of B and in this column tensor
1867.74|4.2|which is D counts sum that we've
1870.38|3.96|calculated just now
1871.94|5.219|we basically see that what that amounts
1874.34|4.98|to is all of these are now flowing to
1877.159|3.841|all these elements of a and they're
1879.32|3.599|doing that horizontally
1881.0|5.039|so basically what we want is we want to
1882.919|5.301|take the decount sum of size 30 by 1 and
1886.039|6.301|we just want to replicate it 27 times
1888.22|5.62|horizontally to create 32 by 27 array
1892.34|2.76|so there's many ways to implement this
1893.84|3.78|operation you could of course just
1895.1|5.28|replicate the tensor but I think maybe
1897.62|6.12|one clean one is that the counts is
1900.38|5.58|simply torch dot once like
1903.74|5.939|so just an two-dimensional arrays of
1905.96|7.68|ones in the shape of counts so 32 by 27
1909.679|6.961|times D counts sum so this way we're
1913.64|4.5|letting the broadcasting here basically
1916.64|2.759|implement the replication you can look
1918.14|4.32|at it that way
1919.399|5.64|but then we have to also be careful
1922.46|5.64|because decounts was already calculated
1925.039|4.5|we calculated earlier here and that was
1928.1|3.059|just the first branch and we're now
1929.539|3.961|finishing the second Branch so we need
1931.159|3.601|to make sure that these gradients add so
1933.5|2.82|plus equals
1934.76|5.76|and then here
1936.32|6.9|um let's comment out the comparison and
1940.52|4.8|let's make sure crossing fingers that we
1943.22|4.8|have the correct result so pytorch
1945.32|4.5|agrees with us on this gradient as well
1948.02|4.92|okay hopefully we're getting a hang of
1949.82|6.839|this now counts as an element-wise X of
1952.94|5.16|Norm legits so now we want D Norm logits
1956.659|3.361|and because it's an element price
1958.1|3.42|operation everything is very simple what
1960.02|5.159|is the local derivative of e to the X
1961.52|6.379|it's famously just e to the x so this is
1965.179|2.72|the local derivative
1968.48|3.179|that is the local derivative now we
1970.279|3.361|already calculated it and it's inside
1971.659|3.661|counts so we may as well potentially
1973.64|2.58|just reuse counts that is the local
1975.32|5.42|derivative
1976.22|4.52|times uh D counts
1981.919|5.101|funny as that looks constant decount is
1984.32|5.76|derivative on the normal objects and now
1987.02|5.36|let's erase this and let's verify and it
1990.08|2.3|looks good
1992.419|5.1|so that's uh normal agents
1994.88|4.019|okay so we are here on this line now the
1997.519|3.0|normal objects
1998.899|3.78|we have that and we're trying to
2000.519|4.861|calculate the logits and deloget Maxes
2002.679|4.081|so back propagating through this line
2005.38|3.72|now we have to be careful here because
2006.76|4.139|the shapes again are not the same and so
2009.1|3.0|there's an implicit broadcasting
2010.899|3.66|Happening Here
2012.1|5.52|so normal jits has this shape 32 by 27
2014.559|5.881|logist does as well but logit Maxis is
2017.62|5.22|only 32 by one so there's a broadcasting
2020.44|5.459|here in the minus
2022.84|5.219|now here I try to sort of write out a
2025.899|4.861|two example again we basically have that
2028.059|4.441|this is our C equals a minus B
2030.76|3.24|and we see that because of the shape
2032.5|2.76|these are three by three but this one is
2034.0|3.72|just a column
2035.26|5.279|and so for example every element of C we
2037.72|4.14|have to look at how it uh came to be and
2040.539|4.321|every element of C is just the
2041.86|6.239|corresponding element of a minus uh
2044.86|5.64|basically that associated b
2048.099|4.981|so it's very clear now that the
2050.5|6.06|derivatives of every one of these c's
2053.08|5.22|with respect to their inputs are one for
2056.56|4.079|the corresponding a
2058.3|3.839|and it's a negative one for the
2060.639|3.361|corresponding B
2062.139|2.881|and so therefore
2064.0|3.8|um
2065.02|5.879|the derivatives on the C will flow
2067.8|5.319|equally to the corresponding Ace and
2070.899|4.141|then also to the corresponding base but
2073.119|3.361|then in addition to that the B's are
2075.04|4.379|broadcast so we'll have to do the
2076.48|4.619|additional sum just like we did before
2079.419|4.081|and of course the derivatives for B's
2081.099|5.161|will undergo a minus because the local
2083.5|6.96|derivative here is uh negative one
2086.26|6.119|so DC three two by D B3 is negative one
2090.46|5.639|so let's just Implement that basically
2092.379|6.121|delugits will be uh exactly copying the
2096.099|3.621|derivative on normal objects
2098.5|4.74|so
2099.72|5.5|delugits equals the norm logits and I'll
2103.24|3.48|do a DOT clone for safety so we're just
2105.22|4.379|making a copy
2106.72|7.2|and then we have that the loaded Maxis
2109.599|6.061|will be the negative of the non-legits
2113.92|3.86|because of the negative sign
2115.66|5.22|and then we have to be careful because
2117.78|5.92|logic Maxis is a column
2120.88|5.94|and so just like we saw before because
2123.7|5.28|we keep replicating the same elements
2126.82|4.259|across all the columns
2128.98|4.02|then in the backward pass because we
2131.079|4.141|keep reusing this these are all just
2133.0|4.38|like separate branches of use of that
2135.22|4.56|one variable and so therefore we have to
2137.38|4.68|do a Sum along one would keep them
2139.78|3.6|equals true so that we don't destroy
2142.06|3.12|this dimension
2143.38|4.02|and then the logic Maxes will be the
2145.18|4.08|same shape now we have to be careful
2147.4|5.28|because this deloaches is not the final
2149.26|5.339|deloaches and that's because not only do
2152.68|4.2|we get gradient signal into logits
2154.599|4.321|through here but the logic Maxes as a
2156.88|4.38|function of logits and that's a second
2158.92|4.439|Branch into logits so this is not yet
2161.26|4.319|our final derivative for logits we will
2163.359|4.201|come back later for the second branch
2165.579|4.741|for now the logic Maxis is the final
2167.56|4.799|derivative so let me uncomment this CMP
2170.32|5.519|here and let's just run this
2172.359|4.201|and logit Maxes hit by torch agrees with
2175.839|3.481|us
2176.56|4.5|so that was the derivative into through
2179.32|3.6|this line
2181.06|3.36|now before we move on I want to pause
2182.92|3.179|here briefly and I want to look at these
2184.42|2.939|logic Maxes and especially their
2186.099|2.701|gradients
2187.359|3.781|we've talked previously in the previous
2188.8|4.319|lecture that the only reason we're doing
2191.14|3.6|this is for the numerical stability of
2193.119|4.5|the softmax that we are implementing
2194.74|4.44|here and we talked about how if you take
2197.619|3.661|these logents for any one of these
2199.18|4.98|examples so one row of this logit's
2201.28|6.0|tensor if you add or subtract any value
2204.16|5.16|equally to all the elements then the
2207.28|4.02|value of the probes will be unchanged
2209.32|3.72|you're not changing soft Max the only
2211.3|4.38|thing that this is doing is it's making
2213.04|4.319|sure that X doesn't overflow and the
2215.68|3.24|reason we're using a Max is because then
2217.359|4.621|we are guaranteed that each row of
2218.92|4.8|logits the highest number is zero and so
2221.98|3.3|this will be safe
2223.72|2.34|and so
2225.28|4.02|um
2226.06|5.519|basically what that has repercussions
2229.3|4.68|if it is the case that changing logit
2231.579|3.841|Maxis does not change the props and
2233.98|3.599|therefore there's not change the loss
2235.42|4.679|then the gradient on logic masses should
2237.579|4.201|be zero right because saying those two
2240.099|3.721|things is the same
2241.78|3.42|so indeed we hope that this is very very
2243.82|4.5|small numbers so indeed we hope this is
2245.2|4.919|zero now because of floating Point uh
2248.32|3.36|sort of wonkiness
2250.119|3.841|um this doesn't come out exactly zero
2251.68|3.899|only in some of the rows it does but we
2253.96|3.659|get extremely small values like one e
2255.579|4.141|negative nine or ten and so this is
2257.619|4.441|telling us that the values of loaded
2259.72|3.48|Maxes are not impacting the loss as they
2262.06|2.76|shouldn't
2263.2|4.8|it feels kind of weird to back propagate
2264.82|5.58|through this branch honestly because
2268.0|4.2|if you have any implementation of like f
2270.4|3.719|dot cross entropy and pytorch and you
2272.2|2.76|you block together all these elements
2274.119|3.24|and you're not doing the back
2274.96|4.32|propagation piece by piece then you
2277.359|3.841|would probably assume that the
2279.28|4.68|derivative through here is exactly zero
2281.2|6.3|uh so you would be sort of
2283.96|5.639|um skipping this branch because it's
2287.5|3.42|only done for numerical stability but
2289.599|3.661|it's interesting to see that even if you
2290.92|3.9|break up everything into the full atoms
2293.26|2.76|and you still do the computation as
2294.82|3.12|you'd like with respect to numerical
2296.02|4.079|stability uh the correct thing happens
2297.94|3.78|and you still get a very very small
2300.099|3.301|gradients here
2301.72|4.379|um basically reflecting the fact that
2303.4|4.5|the values of these do not matter with
2306.099|3.121|respect to the final loss
2307.9|3.719|okay so let's now continue back
2309.22|4.08|propagation through this line here we've
2311.619|3.541|just calculated the logit Maxis and now
2313.3|3.36|we want to back prop into logits through
2315.16|3.78|this second branch
2316.66|4.8|now here of course we took legits and we
2318.94|4.98|took the max along all the rows and then
2321.46|5.84|we looked at its values here now the way
2323.92|5.64|this works is that in pytorch
2327.3|4.779|this thing here
2329.56|3.84|the max returns both the values and it
2332.079|3.601|Returns the indices at which those
2333.4|4.32|values to count the maximum value
2335.68|4.5|now in the forward pass we only used
2337.72|3.78|values because that's all we needed but
2340.18|3.84|in the backward pass it's extremely
2341.5|5.099|useful to know about where those maximum
2344.02|4.62|values occurred and we have the indices
2346.599|3.601|at which they occurred and this will of
2348.64|3.6|course helps us to help us do the back
2350.2|4.5|propagation because what should the
2352.24|4.02|backward pass be here in this case we
2354.7|3.84|have the largest tensor which is 32 by
2356.26|4.2|27 and in each row we find the maximum
2358.54|6.0|value and then that value gets plucked
2360.46|7.44|out into loaded Maxis and so intuitively
2364.54|6.559|um basically the derivative flowing
2367.9|6.12|through here then should be one
2371.099|4.421|times the look of derivatives is 1 for
2374.02|2.339|the appropriate entry that was plucked
2375.52|3.9|out
2376.359|4.5|and then times the global derivative of
2379.42|3.3|the logic axis
2380.859|3.301|so really what we're doing here if you
2382.72|3.78|think through it is we need to take the
2384.16|5.939|deloachet Maxis and we need to scatter
2386.5|6.119|it to the correct positions in these
2390.099|3.361|logits from where the maximum values
2392.619|2.341|came
2393.46|2.7|and so
2394.96|3.3|um
2396.16|3.78|I came up with one line of code sort of
2398.26|4.02|that does that let me just erase a bunch
2399.94|3.659|of stuff here so the line of uh you
2402.28|3.18|could do it kind of very similar to what
2403.599|3.961|we've done here where we create a zeros
2405.46|4.86|and then we populate uh the correct
2407.56|5.519|elements uh so we use the indices here
2410.32|5.039|and we would set them to be one but you
2413.079|5.401|can also use one hot
2415.359|5.641|so F dot one hot and then I'm taking the
2418.48|5.76|lowest of Max over the First Dimension
2421.0|6.599|dot indices and I'm telling uh pytorch
2424.24|4.859|that the dimension of every one of these
2427.599|2.221|tensors should be
2429.099|4.74|um
2429.82|7.799|27 and so what this is going to do
2433.839|5.701|is okay I apologize this is crazy filthy
2437.619|4.021|that I am sure of this
2439.54|4.86|it's really just a an array of where the
2441.64|4.32|Maxes came from in each row and that
2444.4|3.48|element is one and the all the other
2445.96|4.68|elements are zero so it's a one-half
2447.88|5.16|Vector in each row and these indices are
2450.64|3.84|now populating a single one in the
2453.04|3.0|proper place
2454.48|4.139|and then what I'm doing here is I'm
2456.04|5.16|multiplying by the logit Maxis and keep
2458.619|7.081|in mind that this is a column
2461.2|7.26|of 32 by 1. and so when I'm doing this
2465.7|5.1|times the logic Maxis the logic Maxes
2468.46|3.659|will broadcast and that column will you
2470.8|4.2|know get replicated and in an element
2472.119|5.22|wise multiply will ensure that each of
2475.0|4.26|these just gets routed to whichever one
2477.339|3.901|of these bits is turned on
2479.26|4.2|and so that's another way to implement
2481.24|5.46|uh this kind of a this kind of a
2483.46|4.56|operation and both of these can be used
2486.7|3.659|I just thought I would show an
2488.02|3.48|equivalent way to do it and I'm using
2490.359|3.421|plus equals because we already
2491.5|3.66|calculated the logits here and this is
2493.78|3.48|not the second branch
2495.16|4.26|so let's
2497.26|3.42|look at logits and make sure that this
2499.42|3.24|is correct
2500.68|3.84|and we see that we have exactly the
2502.66|4.32|correct answer
2504.52|4.62|next up we want to continue with logits
2506.98|4.56|here that is an outcome of a matrix
2509.14|3.959|multiplication and a bias offset in this
2511.54|4.799|linear layer
2513.099|5.52|so I've printed out the shapes of all
2516.339|4.621|these intermediate tensors we see that
2518.619|3.301|logits is of course 32 by 27 as we've
2520.96|4.86|just seen
2521.92|6.419|then the H here is 32 by 64. so these
2525.82|4.92|are 64 dimensional hidden States and
2528.339|4.5|then this W Matrix projects those 64
2530.74|5.099|dimensional vectors into 27 dimensions
2532.839|5.701|and then there's a 27 dimensional offset
2535.839|4.5|which is a one-dimensional vector
2538.54|4.68|now we should note that this plus here
2540.339|7.201|actually broadcasts because H multiplied
2543.22|7.92|by by W2 will give us a 32 by 27. and so
2547.54|4.68|then this plus B2 is a 27 dimensional
2551.14|2.699|lecture here
2552.22|3.66|now in the rules of broadcasting what's
2553.839|4.081|going to happen with this bias Vector is
2555.88|5.28|that this one-dimensional Vector of 27
2557.92|5.76|will get aligned with a padded dimension
2561.16|4.679|of one on the left and it will basically
2563.68|5.159|become a row vector and then it will get
2565.839|4.801|replicated vertically 32 times to make
2568.839|4.081|it 32 by 27 and then there's an
2570.64|3.959|element-wise multiply
2572.92|3.54|now
2574.599|4.621|the question is how do we back propagate
2576.46|5.639|from logits to the hidden States the
2579.22|4.619|weight Matrix W2 and the bias B2
2582.099|5.581|and you might think that we need to go
2583.839|5.881|to some Matrix calculus and then we have
2587.68|3.96|to look up the derivative for a matrix
2589.72|3.18|multiplication but actually you don't
2591.64|3.0|have to do any of that and you can go
2592.9|4.14|back to First principles and derive this
2594.64|4.08|yourself on a piece of paper and
2597.04|3.72|specifically what I like to do and I
2598.72|4.56|what I find works well for me is you
2600.76|4.44|find a specific small example that you
2603.28|3.78|then fully write out and then in the
2605.2|3.6|process of analyzing how that individual
2607.06|3.48|small example works you will understand
2608.8|3.559|the broader pattern and you'll be able
2610.54|4.98|to generalize and write out the full
2612.359|5.021|general formula for what how these
2615.52|3.72|derivatives flow in an expression like
2617.38|3.9|this so let's try that out
2619.24|4.32|so pardon the low budget production here
2621.28|4.02|but what I've done here is I'm writing
2623.56|3.36|it out on a piece of paper really what
2625.3|5.4|we are interested in is we have a
2626.92|6.3|multiply B plus C and that creates a d
2630.7|4.139|and we have the derivative of the loss
2633.22|2.76|with respect to D and we'd like to know
2634.839|3.061|what the derivative of the losses with
2635.98|4.02|respect to a b and c
2637.9|3.48|now these here are little
2640.0|3.96|two-dimensional examples of a matrix
2641.38|3.479|multiplication Two by Two Times a two by
2643.96|4.02|two
2644.859|6.0|plus a 2 a vector of just two elements
2647.98|6.24|C1 and C2 gives me a two by two
2650.859|6.181|now notice here that I have a bias
2654.22|5.099|Vector here called C and the bisex
2657.04|4.5|vector is C1 and C2 but as I described
2659.319|3.961|over here that bias Vector will become a
2661.54|3.42|row Vector in the broadcasting and will
2663.28|4.02|replicate vertically so that's what's
2664.96|4.74|happening here as well C1 C2 is
2667.3|5.88|replicated vertically and we see how we
2669.7|5.52|have two rows of C1 C2 as a result
2673.18|4.56|so now when I say write it out I just
2675.22|4.859|mean like this basically break up this
2677.74|3.72|matrix multiplication into the actual
2680.079|4.02|thing that that's going on under the
2681.46|5.399|hood so as a result of matrix
2684.099|4.561|multiplication and how it works d11 is
2686.859|4.141|the result of a DOT product between the
2688.66|9.06|first row of a and the First Column of B
2691.0|8.94|so a11 b11 plus a12 B21 plus C1
2697.72|4.5|and so on so forth for all the other
2699.94|4.02|elements of D and once you actually
2702.22|3.899|write it out it becomes obvious this is
2703.96|5.1|just a bunch of multipliers and
2706.119|5.581|um adds and we know from micrograd how
2709.06|3.96|to differentiate multiplies and adds and
2711.7|3.72|so this is not scary anymore it's not
2713.02|4.38|just matrix multiplication it's just uh
2715.42|4.98|tedious unfortunately but this is
2717.4|6.0|completely tractable we have DL by D for
2720.4|5.1|all of these and we want DL by uh all
2723.4|3.3|these little other variables so how do
2725.5|3.66|we achieve that and how do we actually
2726.7|4.08|get the gradients okay so the low budget
2729.16|3.78|production continues here
2730.78|3.48|so let's for example derive the
2732.94|3.12|derivative of the loss with respect to
2734.26|4.62|a11
2736.06|4.44|we see here that a11 occurs twice in our
2738.88|4.38|simple expression right here right here
2740.5|5.64|and influences d11 and D12
2743.26|8.04|. so this is so what is DL by d a one
2746.14|7.679|one well it's DL by d11 times the local
2751.3|4.319|derivative of d11 which in this case is
2753.819|4.081|just b11 because that's what's
2755.619|4.861|multiplying a11 here
2757.9|4.98|so uh and likewise here the local
2760.48|5.099|derivative of D12 with respect to a11 is
2762.88|5.88|just B12 and so B12 well in the chain
2765.579|6.24|rule therefore multiply the L by d 1 2.
2768.76|6.3|and then because a11 is used both to
2771.819|6.421|produce d11 and D12 we need to add up
2775.06|5.039|the contributions of both of those sort
2778.24|4.5|of chains that are running in parallel
2780.099|4.141|and that's why we get a plus just adding
2782.74|3.48|up those two
2784.24|4.92|um those two contributions and that
2786.22|4.859|gives us DL by d a one one we can do the
2789.16|5.1|exact same analysis for the other one
2791.079|4.981|for all the other elements of a and when
2794.26|3.0|you simply write it out it's just super
2796.06|4.08|simple
2797.26|4.8|um taking of gradients on you know
2800.14|4.199|expressions like this
2802.06|4.98|you find that
2804.339|5.52|this Matrix DL by D A that we're after
2807.04|5.46|right if we just arrange all the all of
2809.859|5.341|them in the same shape as a takes so a
2812.5|7.46|is just too much Matrix so d l by D A
2815.2|8.1|here will be also just the same shape
2819.96|5.139|tester with the derivatives now so deal
2823.3|3.42|by D a11 Etc
2825.099|4.621|and we see that actually we can express
2826.72|3.96|what we've written out here as a matrix
2829.72|3.84|multiplied
2830.68|4.86|and so it just so happens that D all by
2833.56|4.32|that all of these formulas that we've
2835.54|3.6|derived here by taking gradients can
2837.88|3.42|actually be expressed as a matrix
2839.14|3.78|multiplication and in particular we see
2841.3|4.26|that it is the matrix multiplication of
2842.92|7.26|these two array matrices
2845.56|7.38|so it is the um DL by D and then Matrix
2850.18|7.26|multiplying B but B transpose actually
2852.94|5.639|so you see that B21 and b12 have changed
2857.44|3.72|place
2858.579|6.481|whereas before we had of course b11 B12
2861.16|6.3|B2 on B22 so you see that this other
2865.06|4.2|Matrix B is transposed
2867.46|3.18|and so basically what we have long story
2869.26|3.599|short just by doing very simple
2870.64|3.719|reasoning here by breaking up the
2872.859|6.121|expression in the case of a very simple
2874.359|7.681|example is that DL by d a is which is
2878.98|6.68|this is simply equal to DL by DD Matrix
2882.04|3.62|multiplied with B transpose
2885.819|4.921|so that is what we have so far now we
2888.4|5.16|also want the derivative with respect to
2890.74|4.8|um B and C now
2893.56|4.799|for B I'm not actually doing the full
2895.54|5.1|derivation because honestly it's um it's
2898.359|4.081|not deep it's just uh annoying it's
2900.64|3.959|exhausting you can actually do this
2902.44|3.78|analysis yourself you'll also find that
2904.599|3.24|if you take this these expressions and
2906.22|4.74|you differentiate with respect to b
2907.839|5.52|instead of a you will find that DL by DB
2910.96|4.44|is also a matrix multiplication in this
2913.359|4.321|case you have to take the Matrix a and
2915.4|4.26|transpose it and Matrix multiply that
2917.68|4.74|with bl by DD
2919.66|6.6|and that's what gives you a deal by DB
2922.42|5.52|and then here for the offsets C1 and C2
2926.26|4.319|if you again just differentiate with
2927.94|4.139|respect to C1 you will find an
2930.579|4.561|expression like this
2932.079|5.04|and C2 an expression like this
2935.14|4.199|and basically you'll find the DL by DC
2937.119|4.321|is simply because they're just
2939.339|5.52|offsetting these Expressions you just
2941.44|6.12|have to take the deal by DD Matrix
2944.859|6.24|of the derivatives of D and you just
2947.56|5.88|have to sum across the columns and that
2951.099|4.74|gives you the derivatives for C
2953.44|4.86|so long story short
2955.839|4.201|the backward Paths of a matrix multiply
2958.3|3.96|is a matrix multiply
2960.04|5.7|and instead of just like we had D equals
2962.26|5.04|a times B plus C in the scalar case uh
2965.74|3.66|we sort of like arrive at something very
2967.3|3.96|very similar but now uh with a matrix
2969.4|3.179|multiplication instead of a scalar
2971.26|4.8|multiplication
2972.579|5.24|so the derivative of D with respect to a
2976.06|5.16|is
2977.819|6.641|DL by DD Matrix multiplied B trespose
2981.22|5.22|and here it's a transpose multiply deal
2984.46|5.1|by DD but in both cases it's a matrix
2986.44|6.72|multiplication with the derivative and
2989.56|6.299|the other term in the multiplication
2993.16|5.699|and for C it is a sum
2995.859|4.381|now I'll tell you a secret I can never
2998.859|2.76|remember the formulas that we just
3000.24|3.599|arrived for back proper gain information
3001.619|4.2|multiplication and I can back propagate
3003.839|3.601|through these Expressions just fine and
3005.819|3.181|the reason this works is because the
3007.44|4.2|dimensions have to work out
3009.0|4.68|uh so let me give you an example say I
3011.64|5.34|want to create DH
3013.68|5.52|then what should the H be number one I
3016.98|4.379|have to know that the shape of DH must
3019.2|5.1|be the same as the shape of H
3021.359|4.921|and the shape of H is 32 by 64. and then
3024.3|4.5|the other piece of information I know is
3026.28|6.24|that DH must be some kind of matrix
3028.8|8.819|multiplication of the logits with W2
3032.52|7.86|and delojits is 32 by 27 and W2 is a 64
3037.619|6.361|by 27. there is only a single way to
3040.38|5.58|make the shape work out in this case and
3043.98|4.859|it is indeed the correct result in
3045.96|4.92|particular here H needs to be 32 by 64.
3048.839|4.141|the only way to achieve that is to take
3050.88|5.04|a deluges
3052.98|4.5|and Matrix multiply it with you see how
3055.92|3.0|I have to take W2 but I have to
3057.48|2.24|transpose it to make the dimensions work
3058.92|3.899|out
3059.72|5.02|so w to transpose and it's the only way
3062.819|3.841|to make these to Matrix multiply those
3064.74|3.359|two pieces to make the shapes work out
3066.66|5.159|and that turns out to be the correct
3068.099|7.26|formula so if we come here we want DH
3071.819|6.181|which is d a and we see that d a is DL
3075.359|6.0|by DD Matrix multiply B transpose
3078.0|6.0|so that's Delo just multiply and B is W2
3081.359|4.921|so W2 transpose which is exactly what we
3084.0|6.079|have here so there's no need to remember
3086.28|7.2|these formulas similarly now if I want
3090.079|7.361|dw2 well I know that it must be a matrix
3093.48|5.82|multiplication of D logits and H
3097.44|3.24|and maybe there's a few transpose like
3099.3|3.059|there's one transpose in there as well
3100.68|4.139|and I don't know which way it is so I
3102.359|4.921|have to come to W2 and I see that its
3104.819|4.321|shape is 64 by 27
3107.28|3.839|and that has to come from some interest
3109.14|6.719|multiplication of these two
3111.119|5.7|and so to get a 64 by 27 I need to take
3115.859|3.421|um
3116.819|4.921|H I need to transpose it
3119.28|4.86|and then I need to Matrix multiply it
3121.74|3.54|um so that will become 64 by 32 and then
3124.14|3.419|I need to make sure to multiply with the
3125.28|4.44|32 by 27 and that's going to give me a
3127.559|3.721|64 by 27. so I need to make sure it's
3129.72|3.54|multiplied this with the logist that
3131.28|4.38|shape just like that that's the only way
3133.26|4.68|to make the dimensions work out and just
3135.66|4.32|use matrix multiplication and if we come
3137.94|5.06|here we see that that's exactly what's
3139.98|6.0|here so a transpose a for us is H
3143.0|7.359|multiplied with deloaches
3145.98|7.5|so that's W2 and then db2
3150.359|5.521|is just the um
3153.48|3.839|vertical sum and actually in the same
3155.88|3.06|way there's only one way to make the
3157.319|3.661|shapes work out I don't have to remember
3158.94|3.78|that it's a vertical Sum along the zero
3160.98|4.32|axis because that's the only way that
3162.72|7.74|this makes sense because B2 shape is 27
3165.3|9.18|so in order to get a um delugits
3170.46|5.76|here is 30 by 27 so knowing that it's
3174.48|3.98|just sum over deloaches in some
3176.22|2.24|Direction
3179.819|4.861|that direction must be zero because I
3182.099|3.901|need to eliminate this Dimension so it's
3184.68|3.84|this
3186.0|4.559|so this is so let's kind of like the
3188.52|5.099|hacky way let me copy paste and delete
3190.559|4.381|that and let me swing over here and this
3193.619|3.601|is our backward pass for the linear
3194.94|4.44|layer uh hopefully
3197.22|4.52|so now let's uncomment
3199.38|4.92|these three and we're checking that we
3201.74|5.14|got all the three derivatives correct
3204.3|6.059|and run
3206.88|6.12|and we see that h wh and B2 are all
3210.359|5.841|exactly correct so we back propagated
3213.0|3.2|through a linear layer
3216.26|5.2|now next up we have derivative for the h
3219.359|4.5|already and we need to back propagate
3221.46|5.7|through 10h into h preact
3223.859|4.681|so we want to derive DH preact
3227.16|3.12|and here we have to back propagate
3228.54|3.72|through a 10 H and we've already done
3230.28|3.96|this in micrograd and we remember that
3232.26|4.44|10h has a very simple backward formula
3234.24|4.859|now unfortunately if I just put in D by
3236.7|4.2|DX of 10 h of X into both from alpha it
3239.099|4.201|lets us down it tells us that it's a
3240.9|5.52|hyperbolic secant function squared of X
3243.3|4.98|it's not exactly helpful but luckily
3246.42|4.32|Google image search does not let us down
3248.28|4.14|and it gives us the simpler formula and
3250.74|5.28|in particular if you have that a is
3252.42|5.52|equal to 10 h of Z then d a by DZ by
3256.02|5.099|propagating through 10 H is just one
3257.94|5.7|minus a square and take note that 1
3261.119|5.94|minus a square a here is the output of
3263.64|6.179|the 10h not the input to the 10h Z so
3267.059|4.921|the D A by DZ is here formulated in
3269.819|4.201|terms of the output of that 10h
3271.98|3.96|and here also in Google image search we
3274.02|4.079|have the full derivation if you want to
3275.94|4.02|actually take the actual definition of
3278.099|4.441|10h and work through the math to figure
3279.96|5.34|out 1 minus standard square of Z
3282.54|6.66|so 1 minus a square is the local
3285.3|7.019|derivative in our case that is 1 minus
3289.2|4.379|uh the output of 10 H squared which here
3292.319|3.901|is H
3293.579|5.401|so it's h squared and that is the local
3296.22|4.56|derivative and then times the chain rule
3298.98|3.48|DH
3300.78|4.68|so that is going to be our candidate
3302.46|6.24|implementation so if we come here
3305.46|4.32|and then uncomment this let's hope for
3308.7|3.659|the best
3309.78|5.339|and we have the right answer
3312.359|4.74|okay next up we have DH preact and we
3315.119|4.021|want to back propagate into the gain the
3317.099|4.561|B and raw and the B and bias
3319.14|4.14|so here this is the bathroom parameters
3321.66|3.959|being gained in bias inside the bash
3323.28|4.92|term that take the B and raw that is
3325.619|3.781|exact unit caution and then scale it and
3328.2|2.76|shift it
3329.4|4.38|and these are the parameters of The
3330.96|4.56|Bachelor now here we have a
3333.78|2.94|multiplication but it's worth noting
3335.52|3.18|that this multiply is very very
3336.72|4.74|different from this Matrix multiply here
3338.7|4.56|Matrix multiply are DOT products between
3341.46|4.02|rows and Columns of these matrices
3343.26|3.66|involved this is an element twice
3345.48|2.46|multiply so things are quite a bit
3346.92|2.639|simpler
3347.94|3.3|now we do have to be careful with some
3349.559|4.081|of the broadcasting happening in this
3351.24|6.96|line of code though so you see how BN
3353.64|8.699|gain and B and bias are 1 by 64. but H
3358.2|5.82|preact and B and raw are 32 by 64.
3362.339|3.181|so we have to be careful with that and
3364.02|2.88|make sure that all the shapes work out
3365.52|3.0|fine and that the broadcasting is
3366.9|3.36|correctly back propagated
3368.52|6.42|so in particular let's start with the B
3370.26|6.78|and Gain so DB and gain should be
3374.94|4.26|and here this is again elementorized
3377.04|4.319|multiply and whenever we have a times b
3379.2|4.32|equals c we saw that the local
3381.359|4.5|derivative here is just if this is a the
3383.52|4.38|local derivative is just the B the other
3385.859|5.7|one so the local derivative is just B
3387.9|6.24|and raw and then times chain rule
3391.559|7.321|so DH preact
3394.14|6.54|so this is the candidate gradient now
3398.88|5.82|again we have to be careful because B
3400.68|7.62|and Gain Is of size 1 by 64. but this
3404.7|4.919|here would be 32 by 64.
3408.3|3.0|and so
3409.619|4.2|um the correct thing to do in this case
3411.3|4.44|of course is that b and gain here is a
3413.819|4.221|rule Vector of 64 numbers it gets
3415.74|4.619|replicated vertically in this operation
3418.04|5.46|and so therefore the correct thing to do
3420.359|5.7|is to sum because it's being replicated
3423.5|4.48|and therefore all the gradients in each
3426.059|4.201|of the rows that are now flowing
3427.98|5.28|backwards need to sum up to that same
3430.26|6.599|tensor DB and Gain so we have to sum
3433.26|4.559|across all the zero all the examples
3436.859|2.341|basically
3437.819|2.581|which is the direction in which this
3439.2|2.58|gets replicated
3440.4|3.3|and now we have to be also careful
3441.78|4.86|because we
3443.7|5.34|um being gain is of shape 1 by 64. so in
3446.64|5.34|fact I need to keep them as true
3449.04|5.34|otherwise I would just get 64.
3451.98|4.859|now I don't actually really remember why
3454.38|5.64|the being gain and the BN bias I made
3456.839|4.441|them be 1 by 64.
3460.02|4.02|um
3461.28|4.5|but the biases B1 and B2 I just made
3464.04|3.66|them be one-dimensional vectors they're
3465.78|5.52|not two-dimensional tensors so I can't
3467.7|5.58|recall exactly why I left the gain and
3471.3|3.36|the bias as two-dimensional but it
3473.28|2.64|doesn't really matter as long as you are
3474.66|1.919|consistent and you're keeping it the
3475.92|2.1|same
3476.579|4.681|so in this case we want to keep the
3478.02|7.74|dimension so that the tensor shapes work
3481.26|8.4|next up we have B and raw so DB and raw
3485.76|5.78|will be BN gain
3489.66|5.82|multiplying
3491.54|5.68|dhreact that's our chain rule now what
3495.48|2.52|about the
3497.22|2.94|um
3498.0|6.48|dimensions of this we have to be careful
3500.16|7.14|right so DH preact is 32 by 64. B and
3504.48|5.119|gain is 1 by 64. so it will just get
3507.3|4.559|replicated and to create this
3509.599|4.181|multiplication which is the correct
3511.859|3.96|thing because in a forward pass it also
3513.78|3.539|gets replicated in just the same way
3515.819|2.641|so in fact we don't need the brackets
3517.319|3.601|here we're done
3518.46|4.92|and the shapes are already correct
3520.92|5.159|and finally for the bias
3523.38|4.14|very similar this bias here is very very
3526.079|3.361|similar to the bias we saw when you
3527.52|4.44|layer in the linear layer and we see
3529.44|4.619|that the gradients from each preact will
3531.96|3.96|simply flow into the biases and add up
3534.059|2.941|because these are just these are just
3535.92|3.3|offsets
3537.0|4.859|and so basically we want this to be DH
3539.22|5.16|preact but it needs to Sum along the
3541.859|4.381|right Dimension and in this case similar
3544.38|4.62|to the gain we need to sum across the
3546.24|4.2|zeroth dimension the examples because of
3549.0|2.7|the way that the bias gets replicated
3550.44|4.02|vertically
3551.7|3.659|and we also want to have keep them as
3554.46|3.18|true
3555.359|5.281|and so this will basically take this and
3557.64|5.4|sum it up and give us a 1 by 64.
3560.64|4.679|so this is the candidate implementation
3563.04|5.94|it makes all the shapes work
3565.319|6.721|let me bring it up down here and then
3568.98|4.56|let me uncomment these three lines
3572.04|4.38|to check that we are getting the correct
3573.54|4.799|result for all the three tensors and
3576.42|4.139|indeed we see that all of that got back
3578.339|4.621|propagated correctly so now we get to
3580.559|4.081|the batch Norm layer we see how here
3582.96|3.659|being gay and being bias are the
3584.64|5.52|parameters so the back propagation ends
3586.619|5.161|but B and raw now is the output of the
3590.16|3.3|standardization
3591.78|2.76|so here what I'm doing of course is I'm
3593.46|2.52|breaking up the batch form into
3594.54|3.12|manageable pieces so we can back
3595.98|4.56|propagate through each line individually
3597.66|6.06|but basically what's happening is BN
3600.54|6.42|mean I is the sum
3603.72|6.42|so this is the B and mean I I apologize
3606.96|4.5|for the variable naming B and diff is x
3610.14|4.86|minus mu
3611.46|5.159|B and div 2 is x minus mu squared here
3615.0|5.52|inside the variance
3616.619|6.18|B and VAR is the variance so uh Sigma
3620.52|4.74|Square this is B and bar and it's
3622.799|5.76|basically the sum of squares
3625.26|5.46|so this is the x minus mu squared and
3628.559|3.54|then the sum now you'll notice one
3630.72|4.26|departure here
3632.099|5.76|here it is normalized as 1 over m
3634.98|4.859|uh which is number of examples here I'm
3637.859|4.141|normalizing as one over n minus 1
3639.839|3.78|instead of N and this is deliberate and
3642.0|3.599|I'll come back to that in a bit when we
3643.619|4.2|are at this line it is something called
3645.599|5.48|the bezels correction
3647.819|5.821|but this is how I want it in our case
3651.079|5.621|bienvar inv then becomes basically
3653.64|5.159|bienvar plus Epsilon Epsilon is one
3656.7|3.24|negative five and then it's one over
3658.799|3.601|square root
3659.94|5.7|is the same as raising to the power of
3662.4|5.399|negative 0.5 right because 0.5 is square
3665.64|3.24|root and then negative makes it one over
3667.799|4.441|square root
3668.88|5.459|so BM Bar M is a one over this uh
3672.24|4.26|denominator here and then we can see
3674.339|5.361|that b and raw which is the X hat here
3676.5|5.76|is equal to the BN diff the numerator
3679.7|5.08|multiplied by the
3682.26|5.039|um BN bar in
3684.78|4.26|and this line here that creates pre-h
3687.299|4.26|pre-act was the last piece we've already
3689.04|4.98|back propagated through it
3691.559|4.321|so now what we want to do is we are here
3694.02|4.799|and we have B and raw and we have to
3695.88|4.8|first back propagate into B and diff and
3698.819|4.681|B and Bar M
3700.68|4.56|so now we're here and we have DB and raw
3703.5|2.839|and we need to back propagate through
3705.24|4.02|this line
3706.339|6.881|now I've written out the shapes here and
3709.26|6.18|indeed bien VAR m is a shape 1 by 64. so
3713.22|4.32|there is a broadcasting happening here
3715.44|3.359|that we have to be careful with but it
3717.54|2.88|is just an element-wise simple
3718.799|3.78|multiplication by now we should be
3720.42|5.04|pretty comfortable with that to get DB
3722.579|3.961|and diff we know that this is just B and
3725.46|2.7|varm
3726.54|4.759|multiplied with
3728.16|3.139|DP and raw
3731.579|6.24|and conversely to get dbmring
3735.0|6.799|we need to take the end if
3737.819|3.98|and multiply that by DB and raw
3742.38|4.14|so this is the candidate but of course
3744.66|5.1|we need to make sure that broadcasting
3746.52|5.22|is obeyed so in particular B and VAR M
3749.76|5.88|multiplying with DB and raw
3751.74|5.04|will be okay and give us 32 by 64 as we
3755.64|5.04|expect
3756.78|5.579|but dbm VAR inv would be taking a 32 by
3760.68|4.74|64.
3762.359|7.321|multiplying it by 32 by 64. so this is a
3765.42|7.32|32 by 64. but of course DB this uh B and
3769.68|5.939|VAR in is only 1 by 64. so the second
3772.74|5.099|line here needs a sum across the
3775.619|4.381|examples and because there's this
3777.839|4.321|Dimension here we need to make sure that
3780.0|4.92|keep them is true
3782.16|5.34|so this is the candidate
3784.92|4.139|let's erase this and let's swing down
3787.5|4.079|here
3789.059|7.141|and implement it and then let's comment
3791.579|7.26|out dbm barif and DB and diff
3796.2|6.0|now we'll actually notice that DB and
3798.839|5.541|diff by the way is going to be incorrect
3802.2|5.639|so when I run this
3804.38|5.739|BMR m is correct B and diff is not
3807.839|6.301|correct and this is actually expected
3810.119|5.881|because we're not done with b and diff
3814.14|3.6|so in particular when we slide here we
3816.0|4.98|see here that b and raw as a function of
3817.74|4.8|B and diff but actually B and far of is
3820.98|3.54|a function of B of R which is a function
3822.54|2.819|of B and df2 which is a function of B
3824.52|4.26|and diff
3825.359|5.401|so it comes here so bdn diff
3828.78|4.62|um these variable names are crazy I'm
3830.76|4.92|sorry it branches out into two branches
3833.4|3.6|and we've only done one branch of it we
3835.68|2.879|have to continue our back propagation
3837.0|3.119|and eventually come back to B and diff
3838.559|4.02|and then we'll be able to do a plus
3840.119|5.041|equals and get the actual card gradient
3842.579|4.681|for now it is good to verify that CMP
3845.16|3.419|also works it doesn't just lie to us and
3847.26|4.14|tell us that everything is always
3848.579|5.28|correct it can in fact detect when your
3851.4|4.38|gradient is not correct so it's that's
3853.859|3.48|good to see as well okay so now we have
3855.78|3.18|the derivative here and we're trying to
3857.339|3.841|back propagate through this line
3858.96|4.44|and because we're raising to a power of
3861.18|4.08|negative 0.5 I brought up the power rule
3863.4|4.919|and we see that basically we have that
3865.26|6.299|the BM bar will now be we bring down the
3868.319|6.48|exponent so negative 0.5 times
3871.559|5.101|uh X which is this
3874.799|4.861|and now raised to the power of negative
3876.66|5.939|0.5 minus 1 which is negative 1.5
3879.66|5.58|now we would have to also apply a small
3882.599|5.401|chain rule here in our head because we
3885.24|4.559|need to take further the derivative of B
3888.0|3.9|and VAR with respect to this expression
3889.799|3.661|here inside the bracket but because this
3891.9|3.06|is an elementalized operation and
3893.46|4.26|everything is fairly simple that's just
3894.96|5.339|one and so there's nothing to do there
3897.72|4.2|so this is the local derivative and then
3900.299|4.02|times the global derivative to create
3901.92|3.6|the chain rule this is just times the BM
3904.319|4.081|bar have
3905.52|4.92|so this is our candidate let me bring
3908.4|5.6|this down
3910.44|3.56|and uncommon to the check
3914.46|2.94|and we see that we have the correct
3916.26|2.88|result
3917.4|3.48|now before we propagate through the next
3919.14|3.179|line I want to briefly talk about the
3920.88|3.719|note here where I'm using the bezels
3922.319|4.861|correction dividing by n minus 1 instead
3924.599|5.101|of dividing by n when I normalize here
3927.18|4.139|the sum of squares
3929.7|3.78|now you'll notice that this is departure
3931.319|5.28|from the paper which uses one over n
3933.48|4.619|instead not one over n minus one their m
3936.599|2.52|is RN
3938.099|2.52|and
3939.119|4.261|um so it turns out that there are two
3940.619|6.18|ways of estimating variance of an array
3943.38|5.64|one is the biased estimate which is one
3946.799|4.5|over n and the other one is the unbiased
3949.02|5.039|estimate which is one over n minus one
3951.299|5.101|now confusingly in the paper this is uh
3954.059|4.74|not very clearly described and also it's
3956.4|4.02|a detail that kind of matters I think
3958.799|3.841|um they are using the biased version
3960.42|4.32|training time but later when they are
3962.64|3.36|talking about the inference they are
3964.74|3.78|mentioning that when they do the
3966.0|4.5|inference they are using the unbiased
3968.52|3.9|estimate which is the n minus one
3970.5|2.46|version in
3972.42|3.12|um
3972.96|5.399|basically for inference
3975.54|5.16|and to calibrate the running mean and
3978.359|4.2|the running variance basically and so
3980.7|3.78|they they actually introduce a trained
3982.559|3.78|test mismatch where in training they use
3984.48|4.079|the biased version and in the in test
3986.339|4.2|time they use the unbiased version I
3988.559|3.601|find this extremely confusing you can
3990.539|4.861|read more about the bezels correction
3992.16|5.1|and why uh dividing by n minus one gives
3995.4|4.08|you a better estimate of the variance in
3997.26|3.74|a case where you have population size or
3999.48|4.8|samples for the population
4001.0|5.2|that are very small and that is indeed
4004.28|3.779|the case for us because we are dealing
4006.2|4.139|with many patches and these mini matches
4008.059|3.961|are a small sample of a larger
4010.339|4.921|population which is the entire training
4012.02|5.16|set and so it just turns out that if you
4015.26|3.66|just estimate it using one over n that
4017.18|3.78|actually almost always underestimates
4018.92|3.899|the variance and it is a biased
4020.96|3.659|estimator and it is advised that you use
4022.819|3.48|the unbiased version and divide by n
4024.619|3.661|minus one and you can go through this
4026.299|3.661|article here that I liked that actually
4028.28|3.96|describes the full reasoning and I'll
4029.96|3.899|link it in the video description
4032.24|3.059|now when you calculate the torture
4033.859|2.641|variance
4035.299|3.06|you'll notice that they take the
4036.5|4.68|unbiased flag whether or not you want to
4038.359|6.121|divide by n or n minus one confusingly
4041.18|5.76|they do not mention what the default is
4044.48|4.92|for unbiased but I believe unbiased by
4046.94|4.379|default is true I'm not sure why the
4049.4|4.02|docs here don't cite that
4051.319|4.561|now in The Bachelor
4053.42|4.919|1D the documentation again is kind of
4055.88|4.02|wrong and confusing it says that the
4058.339|3.061|standard deviation is calculated via the
4059.9|3.24|biased estimator
4061.4|3.24|but this is actually not exactly right
4063.14|3.659|and people have pointed out that it is
4064.64|4.74|not right in a number of issues since
4066.799|5.221|then because actually the rabbit hole is
4069.38|4.919|deeper and they follow the paper exactly
4072.02|4.14|and they use the biased version for
4074.299|4.02|training but when they're estimating the
4076.16|4.199|running standard deviation we are using
4078.319|4.381|the unbiased version so again there's
4080.359|4.801|the train test mismatch so long story
4082.7|4.74|short I'm not a fan of trained test
4085.16|3.379|discrepancies I basically kind of
4087.44|3.54|consider
4088.539|4.481|the fact that we use the bias version
4090.98|3.599|the training time and the unbiased test
4093.02|3.299|time I basically consider this to be a
4094.579|3.66|bug and I don't think that there's a
4096.319|3.601|good reason for that it's not really
4098.239|4.08|they don't really go into the detail of
4099.92|4.56|the reasoning behind it in this paper so
4102.319|3.98|that's why I basically prefer to use the
4104.48|4.739|bestless correction in my own work
4106.299|4.241|unfortunately Bastion does not take a
4109.219|3.96|keyword argument that tells you whether
4110.54|4.139|or not you want to use the unbiased
4113.179|3.421|version of the bias version in both
4114.679|4.02|train and test and so therefore anyone
4116.6|4.619|using batch normalization basically in
4118.699|3.301|my view has a bit of a bug in the code
4121.219|3.241|um
4122.0|4.799|and this turns out to be much less of a
4124.46|4.2|problem if your batch mini batch sizes
4126.799|4.56|are a bit larger but still I just might
4128.66|4.98|kind of uh unpardable so maybe someone
4131.359|3.9|can explain why this is okay but for now
4133.64|4.199|I prefer to use the unbiased version
4135.259|4.92|consistently both during training and at
4137.839|4.02|this time and that's why I'm using one
4140.179|2.881|over n minus one here
4141.859|3.781|okay so let's now actually back
4143.06|4.259|propagate through this line
4145.64|3.0|so
4147.319|3.181|the first thing that I always like to do
4148.64|4.26|is I like to scrutinize the shapes first
4150.5|4.44|so in particular here looking at the
4152.9|6.06|shapes of what's involved I see that b
4154.94|6.66|and VAR shape is 1 by 64. so it's a row
4158.96|3.779|vector and BND if two dot shape is 32 by
4161.6|3.48|64.
4162.739|6.12|so clearly here we're doing a sum over
4165.08|7.619|the zeroth axis to squash the first
4168.859|6.181|dimension of of the shapes here using a
4172.699|4.08|sum so that right away actually hints to
4175.04|3.719|me that there will be some kind of a
4176.779|4.02|replication or broadcasting in the
4178.759|3.901|backward pass and maybe you're noticing
4180.799|4.621|the pattern here but basically anytime
4182.66|5.099|you have a sum in the forward pass that
4185.42|3.72|turns into a replication or broadcasting
4187.759|4.381|in the backward pass along the same
4189.14|5.7|Dimension and conversely when we have a
4192.14|4.98|replication or a broadcasting in the
4194.84|5.1|forward pass that indicates a variable
4197.12|4.68|reuse and so in the backward pass that
4199.94|2.88|turns into a sum over the exact same
4201.8|2.64|dimension
4202.82|3.24|and so hopefully you're noticing that
4204.44|3.0|Duality that those two are kind of like
4206.06|3.06|the opposite of each other in the
4207.44|4.08|forward and backward pass
4209.12|3.78|now once we understand the shapes the
4211.52|3.48|next thing I like to do always is I like
4212.9|3.779|to look at a toy example in my head to
4215.0|3.36|sort of just like understand roughly how
4216.679|3.301|uh the variable the variable
4218.36|3.06|dependencies go in the mathematical
4219.98|4.32|formula
4221.42|5.279|so here we have a two-dimensional array
4224.3|5.58|of the end of two which we are scaling
4226.699|5.52|by a constant and then we are summing uh
4229.88|4.08|vertically over the columns so if we
4232.219|3.96|have a two by two Matrix a and then we
4233.96|5.82|sum over the columns and scale we would
4236.179|6.181|get a row Vector B1 B2 and B1 depends on
4239.78|5.879|a in this way whereas just sum they're
4242.36|6.54|scaled of a and B2 in this way where
4245.659|6.421|it's the second column sump and scale
4248.9|4.62|and so looking at this basically
4252.08|3.599|what we want to do now is we have the
4253.52|4.74|derivatives on B1 and B2 and we want to
4255.679|3.961|back propagate them into Ace and so it's
4258.26|3.66|clear that just differentiating in your
4259.64|5.7|head the local derivative here is one
4261.92|7.44|over n minus 1 times uh one
4265.34|6.12|uh for each one of these A's and um
4269.36|4.56|basically the derivative of B1 has to
4271.46|5.1|flow through The Columns of a
4273.92|4.68|scaled by one over n minus one
4276.56|4.92|and that's roughly What's Happening Here
4278.6|6.24|so intuitively the derivative flow tells
4281.48|6.3|us that DB and diff2
4284.84|4.98|will be the local derivative of this
4287.78|3.3|operation and there are many ways to do
4289.82|4.02|this by the way but I like to do
4291.08|6.24|something like this torch dot once like
4293.84|5.819|of bndf2 so I'll create a large array
4297.32|4.859|two-dimensional of ones
4299.659|5.04|and then I will scale it so 1.0 divided
4302.179|4.741|by n minus 1.
4304.699|4.561|so this is a array of
4306.92|3.779|um one over n minus one and that's sort
4309.26|4.14|of like the local derivative
4310.699|7.341|and now for the chain rule I will simply
4313.4|4.64|just multiply it by dbm bar
4318.38|4.56|and notice here what's going to happen
4320.0|6.12|this is 32 by 64 and this is just 1 by
4322.94|5.52|64. so I'm letting the broadcasting do
4326.12|5.4|the replication because internally in
4328.46|4.62|pytorch basically dbnbar which is 1 by
4331.52|3.9|64 row vector
4333.08|5.099|well in this multiplication get
4335.42|4.14|um copied vertically until the two are
4338.179|3.841|of the same shape and then there will be
4339.56|4.139|an element wise multiply and so that uh
4342.02|3.12|so that the broadcasting is basically
4343.699|3.421|doing the replication
4345.14|4.92|and I will end up with the derivatives
4347.12|5.34|of DB and diff2 here
4350.06|3.9|so this is the candidate solution let's
4352.46|4.32|bring it down here
4353.96|5.52|let's uncomment this line where we check
4356.78|4.62|it and let's hope for the best
4359.48|3.9|and indeed we see that this is the
4361.4|4.2|correct formula next up let's
4363.38|4.62|differentiate here and to be in this
4365.6|5.34|so here we have that b and diff is
4368.0|4.739|element y squared to create B and F2
4370.94|3.66|so this is a relatively simple
4372.739|3.541|derivative because it's a simple element
4374.6|4.8|wise operation so it's kind of like the
4376.28|6.0|scalar case and we have that DB and div
4379.4|5.279|should be if this is x squared then the
4382.28|5.34|derivative of this is 2x right so it's
4384.679|4.201|simply 2 times B and if that's the local
4387.62|3.599|derivative
4388.88|4.2|and then times chain Rule and the shape
4391.219|4.621|of these is the same they are of the
4393.08|4.619|same shape so times this
4395.84|4.74|so that's the backward pass for this
4397.699|4.381|variable let me bring that down here
4400.58|3.9|and now we have to be careful because we
4402.08|5.82|already calculated dbm depth right so
4404.48|5.64|this is just the end of the other uh you
4407.9|3.0|know other Branch coming back to B and
4410.12|2.579|diff
4410.9|3.96|because B and diff was already back
4412.699|5.161|propagated to way over here
4414.86|4.859|from being raw so we now completed the
4417.86|4.68|second branch and so that's why I have
4419.719|4.261|to do plus equals and if you recall we
4422.54|3.72|had an incorrect derivative for being
4423.98|4.92|diff before and I'm hoping that once we
4426.26|5.36|append this last missing piece we have
4428.9|6.299|the exact correctness so let's run
4431.62|6.22|ambient to be in div now actually shows
4435.199|4.801|the exact correct derivative
4437.84|3.54|um so that's comforting okay so let's
4440.0|3.12|now back propagate through this line
4441.38|3.54|here
4443.12|3.9|um the first thing we do of course is we
4444.92|3.9|check the shapes and I wrote them out
4447.02|5.46|here and basically the shape of this is
4448.82|6.6|32 by 64. hpbn is the same shape
4452.48|5.34|but B and mean I is a row Vector 1 by
4455.42|4.2|64. so this minus here will actually do
4457.82|4.08|broadcasting and so we have to be
4459.62|4.14|careful with that and as a hint to us
4461.9|4.02|again because of The Duality a
4463.76|3.899|broadcasting and the forward pass means
4465.92|4.2|a variable reuse and therefore there
4467.659|3.841|will be a sum in the backward pass
4470.12|3.0|so let's write out the backward pass
4471.5|2.82|here now
4473.12|4.079|um
4474.32|4.74|back propagate into the hpbn
4477.199|3.841|because this is these are the same shape
4479.06|4.08|then the local derivative for each one
4481.04|4.08|of the elements here is just one for the
4483.14|4.559|corresponding element in here
4485.12|5.579|so basically what this means is that the
4487.699|5.101|gradient just simply copies it's just a
4490.699|4.201|variable assignment it's quality so I'm
4492.8|5.939|just going to clone this tensor just for
4494.9|5.339|safety to create an exact copy of DB and
4498.739|3.061|div
4500.239|6.261|and then here to back propagate into
4501.8|4.7|this one what I'm inclined to do here is
4507.219|5.081|will basically be
4509.84|6.54|uh what is the local derivative well
4512.3|7.02|it's negative torch.1's like
4516.38|5.359|of the shape of uh B and diff
4519.32|2.419|right
4522.199|5.161|and then times
4524.9|6.36|the um
4527.36|3.9|the derivative here dbf
4532.88|4.92|and this here is the back propagation
4534.739|4.92|for the replicated B and mean I
4537.8|4.26|so I still have to back propagate
4539.659|4.141|through the uh replication in the
4542.06|3.54|broadcasting and I do that by doing a
4543.8|4.14|sum so I'm going to take this whole
4545.6|4.139|thing and I'm going to do a sum over the
4547.94|4.4|zeroth dimension which was the
4549.739|2.601|replication
4553.52|4.139|so if you scrutinize this by the way
4555.92|4.08|you'll notice that this is the same
4557.659|3.661|shape as that and so what I'm doing uh
4560.0|3.44|what I'm doing here doesn't actually
4561.32|5.16|make that much sense because it's just a
4563.44|6.759|array of ones multiplying DP and diff so
4566.48|5.699|in fact I can just do this
4570.199|4.98|um and that is equivalent
4572.179|5.821|so this is the candidate backward pass
4575.179|7.321|let me copy it here and then let me
4578.0|6.06|comment out this one and this one
4582.5|4.64|enter
4584.06|3.08|and it's wrong
4587.239|3.96|damn
4589.46|3.9|actually sorry this is supposed to be
4591.199|3.421|wrong and it's supposed to be wrong
4593.36|3.299|because
4594.62|5.22|we are back propagating from a b and
4596.659|6.721|diff into hpbn and but we're not done
4599.84|5.04|because B and mean I depends on hpbn and
4603.38|2.88|there will be a second portion of that
4604.88|3.54|derivative coming from this second
4606.26|3.78|Branch so we're not done yet and we
4608.42|2.34|expect it to be incorrect so there you
4610.04|3.06|go
4610.76|5.58|uh so let's now back propagate from uh B
4613.1|4.2|and mean I into hpbn
4616.34|2.52|um
4617.3|4.08|and so here again we have to be careful
4618.86|4.379|because there's a broadcasting along
4621.38|3.18|um or there's a Sum along the zeroth
4623.239|3.301|dimension so this will turn into
4624.56|4.08|broadcasting in the backward pass now
4626.54|3.78|and I'm going to go a little bit faster
4628.64|3.78|on this line because it is very similar
4630.32|4.5|to the line that we had before and
4632.42|6.12|multiplies in the past in fact
4634.82|5.24|so the hpbn
4638.54|4.08|will be
4640.06|5.38|the gradient will be scaled by 1 over n
4642.62|4.68|and then basically this gradient here on
4645.44|4.799|dbn mean I
4647.3|4.8|is going to be scaled by 1 over n and
4650.239|5.46|then it's going to flow across all the
4652.1|6.36|columns and deposit itself into the hpvn
4655.699|3.901|so what we want is this thing scaled by
4658.46|4.759|1 over n
4659.6|3.619|only put the constant up front here
4663.98|3.54|um
4665.3|6.18|so scale down the gradient and now we
4667.52|7.62|need to replicate it across all the um
4671.48|9.36|across all the rows here so we I like to
4675.14|8.7|do that by torch.lunslike of basically
4680.84|4.98|um hpbn
4683.84|5.46|and I will let the broadcasting do the
4685.82|6.02|work of replication
4689.3|2.54|so
4694.94|6.36|like that
4696.32|8.419|so this is uh the hppn and hopefully
4701.3|3.439|we can plus equals that
4707.12|5.16|so this here is broadcasting
4710.12|3.42|um and then this is the scaling so this
4712.28|2.78|should be current
4713.54|3.6|okay
4715.06|3.88|so that completes the back propagation
4717.14|3.42|of the bathroom layer and we are now
4718.94|4.32|here let's back propagate through the
4720.56|3.78|linear layer one here now because
4723.26|3.72|everything is getting a little
4724.34|4.02|vertically crazy I copy pasted the line
4726.98|3.179|here and let's just back properly
4728.36|3.839|through this one line
4730.159|6.121|so first of course we inspect the shapes
4732.199|6.661|and we see that this is 32 by 64. MCAT
4736.28|8.34|is 32 by 30.
4738.86|7.799|W1 is 30 30 by 64 and B1 is just 64. so
4744.62|3.78|as I mentioned back propagating through
4746.659|4.441|linear layers is fairly easy just by
4748.4|5.7|matching the shapes so let's do that we
4751.1|4.5|have that dmcat
4754.1|4.38|should be
4755.6|6.059|um some matrix multiplication of dhbn
4758.48|9.719|with uh W1 and one transpose thrown in
4761.659|10.5|there so to make uh MCAT be 32 by 30
4768.199|8.101|I need to take dhpn
4772.159|6.621|32 by 64 and multiply it by w1.
4776.3|2.48|transpose
4779.9|5.7|to get the only one I need to end up
4783.38|5.4|with 30 by 64.
4785.6|5.7|so to get that I need to take uh MCAT
4788.78|4.56|transpose
4791.3|6.0|and multiply that by
4793.34|3.96|uh dhpion
4798.38|6.42|and finally to get DB1
4801.5|5.46|this is a addition and we saw that
4804.8|4.76|basically I need to just sum the
4806.96|5.1|elements in dhpbn along some Dimension
4809.56|4.659|and to make the dimensions work out I
4812.06|5.46|need to Sum along the zeroth axis here
4814.219|4.861|to eliminate this Dimension and we do
4817.52|3.54|not keep dims
4819.08|4.139|uh so that we want to just get a single
4821.06|6.3|one-dimensional lecture of 64.
4823.219|6.321|so these are the claimed derivatives
4827.36|5.16|let me put that here and let me
4829.54|4.54|uncomment three lines and cross our
4832.52|3.54|fingers
4834.08|3.9|everything is great okay so we now
4836.06|3.72|continue almost there we have the
4837.98|3.6|derivative of MCAT and we want to
4839.78|3.419|derivative we want to back propagate
4841.58|4.68|into m
4843.199|5.46|so I again copied this line over here
4846.26|5.04|so this is the forward pass and then
4848.659|4.741|this is the shapes so remember that the
4851.3|5.82|shape here was 32 by 30 and the original
4853.4|5.22|shape of M plus 32 by 3 by 10. so this
4857.12|4.16|layer in the forward pass as you recall
4858.62|5.579|did the concatenation of these three
4861.28|5.439|10-dimensional character vectors
4864.199|4.321|and so now we just want to undo that
4866.719|4.321|so this is actually relatively
4868.52|4.08|straightforward operation because uh the
4871.04|4.08|backward pass of the what is the view
4872.6|4.8|view is just a representation of the
4875.12|3.84|array it's just a logical form of how
4877.4|4.5|you interpret the array so let's just
4878.96|6.66|reinterpret it to be what it was before
4881.9|7.56|so in other words the end is not uh 32
4885.62|8.579|by 30. it is basically dmcat
4889.46|7.739|but if you view it as the original shape
4894.199|5.341|so just m dot shape
4897.199|3.301|uh you can you can pass in tuples into
4899.54|5.0|view
4900.5|4.04|and so this should just be okay
4904.64|5.34|we just re-represent that view and then
4907.1|3.96|we uncomment this line here and
4909.98|5.16|hopefully
4911.06|5.099|yeah so the derivative of M is correct
4915.14|2.22|so in this case we just have to
4916.159|3.721|re-represent the shape of those
4917.36|4.379|derivatives into the original View
4919.88|3.06|so now we are at the final line and the
4921.739|3.801|only thing that's left to back propagate
4922.94|6.54|through is this indexing operation here
4925.54|6.04|MSC at xB so as I did before I copy
4929.48|3.36|pasted this line here and let's look at
4931.58|3.659|the shapes of everything that's involved
4932.84|6.78|and remind ourselves how this worked
4935.239|7.021|so m.shape was 32 by 3 by 10.
4939.62|4.86|it says 32 examples and then we have
4942.26|4.38|three characters each one of them has a
4944.48|4.44|10 dimensional embedding
4946.64|4.74|and this was achieved by taking the
4948.92|3.72|lookup table C which have 27 possible
4951.38|3.48|characters
4952.64|3.26|each of them 10 dimensional and we
4954.86|4.14|looked up
4955.9|5.14|at the rows that were specified inside
4959.0|4.739|this tensor xB
4961.04|4.619|so XB is 32 by 3 and it's basically
4963.739|5.46|giving us for each example the Identity
4965.659|5.161|or the index of which character is part
4969.199|3.721|of that example
4970.82|6.3|and so here I'm showing the first five
4972.92|5.88|rows of three of this tensor xB
4977.12|3.539|and so we can see that for example here
4978.8|4.08|it was the first example in this batch
4980.659|3.54|is that the first character and the
4982.88|3.42|first character and the fourth character
4984.199|4.201|comes into the neural net
4986.3|3.84|and then we want to predict the next
4988.4|3.9|character in a sequence after the
4990.14|4.44|character is one one four
4992.3|5.7|so basically What's Happening Here is
4994.58|4.98|there are integers inside XB and each
4998.0|4.5|one of these integers is specifying
4999.56|6.0|which row of C we want to pluck out
5002.5|6.179|right and then we arrange those rows
5005.56|5.34|that we've plucked out into 32 by 3 by
5008.679|4.98|10 tensor and we just package them in we
5010.9|4.2|just package them into the sensor
5013.659|2.641|and now what's happening is that we have
5015.1|3.9|D amp
5016.3|5.34|so for every one of these uh basically
5019.0|3.96|plucked out rows we have their gradients
5021.64|3.599|now
5022.96|5.1|but they're arranged inside this 32 by 3
5025.239|4.521|by 10 tensor so all we have to do now is
5028.06|4.2|we just need to Route this gradient
5029.76|5.2|backwards through this assignment so we
5032.26|3.84|need to find which row of C that every
5034.96|4.08|one of these
5036.1|7.02|um 10 dimensional embeddings come from
5039.04|7.02|and then we need to deposit them into DC
5043.12|5.34|so we just need to undo the indexing and
5046.06|4.08|of course if any of these rows of C was
5048.46|3.36|used multiple times which almost
5050.14|3.66|certainly is the case like the row one
5051.82|3.78|and one was used multiple times then we
5053.8|4.26|have to remember that the gradients that
5055.6|4.139|arrive there have to add
5058.06|3.3|so for each occurrence we have to have
5059.739|3.781|an addition
5061.36|3.48|so let's now write this out and I don't
5063.52|2.94|actually know if like a much better way
5064.84|3.18|to do this than a for Loop unfortunately
5066.46|3.3|in Python
5068.02|4.199|um so maybe someone can come up with a
5069.76|4.919|vectorized efficient operation but for
5072.219|4.921|now let's just use for loops so let me
5074.679|6.301|create a torch.zeros like
5077.14|6.0|C to initialize uh just uh 27 by 10
5080.98|6.0|tensor of all zeros
5083.14|6.3|and then honestly 4K in range XB dot
5086.98|4.08|shape at zero
5089.44|3.779|maybe someone has a better way to do
5091.06|4.679|this but for J and range
5093.219|5.101|be that shape at one
5095.739|6.061|this is going to iterate over all the
5098.32|4.859|um all the elements of XB all these
5101.8|3.54|integers
5103.179|3.661|and then let's get the index at this
5105.34|6.3|position
5106.84|7.5|so the index is basically x b at KJ
5111.64|4.38|so that an example of that like is 11 or
5114.34|5.1|14 and so on
5116.02|7.699|and now in the forward pass we took
5119.44|4.279|and we basically took um
5124.239|6.48|the row of C at index and we deposited
5127.96|4.44|it into M at K of J
5130.719|3.421|that's what happened that's where they
5132.4|4.16|are packaged so now we need to go
5134.14|5.76|backwards and we just need to route
5136.56|6.099|DM at the position KJ
5139.9|4.86|we now have these derivatives
5142.659|3.181|for each position and it's 10
5144.76|2.52|dimensional
5145.84|3.3|and you just need to go into the correct
5147.28|7.2|row of C
5149.14|6.539|so DC rather at IX is this but plus
5154.48|2.4|equals
5155.679|3.301|because there could be multiple
5156.88|4.08|occurrences uh like the same row could
5158.98|5.58|have been used many many times and so
5160.96|5.219|all of those derivatives will just go
5164.56|3.42|backwards through the indexing and they
5166.179|6.361|will add
5167.98|4.56|so this is my candidate solution
5172.659|3.5|let's copy it here
5176.38|4.56|let's uncomment this and cross our
5179.38|2.6|fingers
5180.94|3.36|hey
5181.98|3.699|so that's it we've back propagated
5184.3|3.72|through
5185.679|5.401|this entire Beast
5188.02|5.58|so there we go totally makes sense
5191.08|3.9|so now we come to exercise two it
5193.6|3.18|basically turns out that in this first
5194.98|4.02|exercise we were doing way too much work
5196.78|3.959|uh we were back propagating way too much
5199.0|3.239|and it was all good practice and so on
5200.739|3.601|but it's not what you would do in
5202.239|4.92|practice and the reason for that is for
5204.34|4.92|example here I separated out this loss
5207.159|4.56|calculation over multiple lines and I
5209.26|4.08|broke it up all all to like its smallest
5211.719|3.48|atomic pieces and we back propagated
5213.34|3.42|through all of those individually
5215.199|3.181|but it turns out that if you just look
5216.76|3.24|at the mathematical expression for the
5218.38|3.779|loss
5220.0|4.32|um then actually you can do the
5222.159|4.321|differentiation on pen and paper and a
5224.32|3.359|lot of terms cancel and simplify and the
5226.48|3.6|mathematical expression you end up with
5227.679|3.96|can be significantly shorter and easier
5230.08|2.639|to implement than back propagating
5231.639|2.341|through all the little pieces of
5232.719|3.42|everything you've done
5233.98|4.44|so before we had this complicated
5236.139|3.121|forward paths going from logits to the
5238.42|2.7|loss
5239.26|3.72|but in pytorch everything can just be
5241.12|3.599|glued together into a single call at
5242.98|3.42|that cross entropy you just pass in
5244.719|4.261|logits and the labels and you get the
5246.4|4.92|exact same loss as I verify here so our
5248.98|4.5|previous loss and the fast loss coming
5251.32|5.399|from the chunk of operations as a single
5253.48|5.1|mathematical expression is the same but
5256.719|3.841|it's much much faster in a forward pass
5258.58|3.9|it's also much much faster in backward
5260.56|3.179|pass and the reason for that is if you
5262.48|3.06|just look at the mathematical form of
5263.739|3.121|this and differentiate again you will
5265.54|3.42|end up with a very small and short
5266.86|4.74|expression so that's what we want to do
5268.96|5.46|here we want to in a single operation or
5271.6|4.86|in a single go or like very quickly go
5274.42|4.739|directly to delojits
5276.46|5.94|and we need to implement the logits as a
5279.159|5.04|function of logits and yb's
5282.4|4.38|but it will be significantly shorter
5284.199|4.5|than whatever we did here where to get
5286.78|3.24|to deluggets we had to go all the way
5288.699|3.781|here
5290.02|3.84|so all of this work can be skipped in a
5292.48|3.84|much much simpler mathematical
5293.86|4.799|expression that you can Implement here
5296.32|5.52|so you can give it a shot yourself
5298.659|4.861|basically look at what exactly is the
5301.84|4.44|mathematical expression of loss and
5303.52|6.179|differentiate with respect to the logits
5306.28|5.7|so let me show you a hint you can of
5309.699|3.841|course try it fully yourself but if not
5311.98|4.46|I can give you some hint of how to get
5313.54|2.9|started mathematically
5316.6|4.44|so basically What's Happening Here is we
5318.699|3.361|have logits then there's a softmax that
5321.04|3.84|takes the logits and gives you
5322.06|4.679|probabilities then we are using the
5324.88|5.16|identity of the correct next character
5326.739|5.041|to pluck out a row of probabilities take
5330.04|4.02|the negative log of it to get our
5331.78|5.1|negative block probability and then we
5334.06|4.079|average up all the log probabilities or
5336.88|2.94|negative block probabilities to get our
5338.139|3.481|loss
5339.82|4.2|so basically what we have is for a
5341.62|4.44|single individual example rather we have
5344.02|5.4|that loss is equal to negative log
5346.06|5.04|probability uh where P here is kind of
5349.42|4.739|like thought of as a vector of all the
5351.1|5.4|probabilities so at the Y position where
5354.159|5.461|Y is the label
5356.5|6.96|and we have that P here of course is the
5359.62|5.76|softmax so the ith component of P of
5363.46|4.86|this probability Vector is just the
5365.38|6.54|softmax function so raising all the
5368.32|6.0|logits uh basically to the power of E
5371.92|3.48|and normalizing so everything comes to
5374.32|4.02|1.
5375.4|4.86|now if you write out P of Y here you can
5378.34|3.0|just write out the soft Max and then
5380.26|2.82|basically what we're interested in is
5381.34|6.48|we're interested in the derivative of
5383.08|7.98|the loss with respect to the I logit
5387.82|4.919|and so basically it's a d by DLI of this
5391.06|3.24|expression here
5392.739|3.841|where we have L indexed with the
5394.3|4.56|specific label Y and on the bottom we
5396.58|4.38|have a sum over J of e to the L J and
5398.86|3.779|the negative block of all that so
5400.96|3.179|potentially give it a shot pen and paper
5402.639|4.56|and see if you can actually derive the
5404.139|5.401|expression for the loss by DLI and then
5407.199|4.5|we're going to implement it here okay so
5409.54|3.84|I'm going to give away the result here
5411.699|5.701|so this is some of the math I did to
5413.38|5.64|derive the gradients analytically and so
5417.4|3.12|we see here that I'm just applying the
5419.02|3.119|rules of calculus from your first or
5420.52|4.139|second year of bachelor's degree if you
5422.139|4.201|took it and we see that the expression
5424.659|3.301|is actually simplify quite a bit you
5426.34|3.839|have to separate out the analysis in the
5427.96|4.199|case where the ith index that you're
5430.179|4.081|interested in inside logits is either
5432.159|3.54|equal to the label or it's not equal to
5434.26|3.3|the label and then the expression
5435.699|4.02|simplify and cancel in a slightly
5437.56|3.599|different way and what we end up with is
5439.719|3.301|something very very simple
5441.159|5.06|and we either end up with basically
5443.02|6.36|pirai where p is again this Vector of
5446.219|5.381|probabilities after a soft Max or P at I
5449.38|4.319|minus 1 where we just simply subtract a
5451.6|4.74|one but in any case we just need to
5453.699|4.5|calculate the soft Max p e and then in
5456.34|4.14|the correct Dimension we need to
5458.199|4.801|subtract one and that's the gradient the
5460.48|4.199|form that it takes analytically so let's
5463.0|3.0|implement this basically and we have to
5464.679|3.54|keep in mind that this is only done for
5466.0|3.78|a single example but here we are working
5468.219|4.141|with batches of examples
5469.78|5.04|so we have to be careful of that and
5472.36|4.74|then the loss for a batch is the average
5474.82|3.66|loss over all the examples so in other
5477.1|3.539|words is the example for all the
5478.48|4.259|individual examples is the loss for each
5480.639|4.02|individual example summed up and then
5482.739|3.541|divided by n and we have to back
5484.659|3.361|propagate through that as well and be
5486.28|4.32|careful with it
5488.02|4.679|so deluggets is going to be of that soft
5490.6|4.44|Max
5492.699|4.201|uh pytorch has a softmax function that
5495.04|4.38|you can call and we want to apply the
5496.9|5.7|softmax on the logits and we want to go
5499.42|4.62|in the dimension that is one so
5502.6|4.86|basically we want to do the softmax
5504.04|5.34|along the rows of these logits
5507.46|5.46|then at the correct positions we need to
5509.38|5.1|subtract a 1. so delugits at iterating
5512.92|4.08|over all the rows
5514.48|5.52|and indexing into the columns
5517.0|6.06|provided by the correct labels inside YB
5520.0|5.52|we need to subtract one
5523.06|4.079|and then finally it's the average loss
5525.52|3.96|that is the loss and in the average
5527.139|4.861|there's a one over n of all the losses
5529.48|4.92|added up and so we need to also
5532.0|4.5|propagate through that division
5534.4|5.46|so the gradient has to be scaled down by
5536.5|5.699|by n as well because of the mean
5539.86|4.92|but this otherwise should be the result
5542.199|4.681|so now if we verify this
5544.78|5.22|we see that we don't get an exact match
5546.88|6.72|but at the same time the maximum
5550.0|7.32|difference from logits from pytorch and
5553.6|5.46|RD logits here is uh on the order of 5e
5557.32|4.26|negative 9. so it's a tiny tiny number
5559.06|5.099|so because of floating point wantiness
5561.58|5.94|we don't get the exact bitwise result
5564.159|4.921|but we basically get the correct answer
5567.52|3.54|approximately
5569.08|3.36|now I'd like to pause here briefly
5571.06|3.42|before we move on to the next exercise
5572.44|4.32|because I'd like us to get an intuitive
5574.48|3.8|sense of what the logits is because it
5576.76|3.84|has a beautiful and very simple
5578.28|5.02|explanation honestly
5580.6|4.619|um so here I'm taking the logits and I'm
5583.3|4.08|visualizing it and we can see that we
5585.219|3.241|have a batch of 32 examples of 27
5587.38|3.42|characters
5588.46|5.4|and what is the logits intuitively right
5590.8|4.74|the logits is the probabilities that the
5593.86|3.779|properties Matrix in the forward pass
5595.54|3.54|but then here these black squares are
5597.639|4.08|the positions of the correct indices
5599.08|5.46|where we subtracted a one
5601.719|6.121|and so uh what is this doing right these
5604.54|7.199|are the derivatives on the logits and so
5607.84|5.46|let's look at just the first row here
5611.739|2.881|so that's what I'm doing here I'm
5613.3|2.82|clocking the probabilities of these
5614.62|3.66|logits and then I'm taking just the
5616.12|5.22|first row and this is the probability
5618.28|5.64|row and then the logits of the first row
5621.34|4.98|and multiplying by n just for us so that
5623.92|4.62|we don't have the scaling by n in here
5626.32|3.72|and everything is more interpretable we
5628.54|3.72|see that it's exactly equal to the
5630.04|3.599|probability of course but then the
5632.26|4.14|position of the correct index has a
5633.639|3.721|minus equals one so minus one on that
5636.4|2.819|position
5637.36|4.319|and so notice that
5639.219|4.201|um if you take Delo Jets at zero and you
5641.679|4.621|sum it
5643.42|5.46|it actually sums to zero and so you
5646.3|6.24|should think of these uh gradients here
5648.88|6.6|at each cell as like a force
5652.54|5.28|um we are going to be basically pulling
5655.48|4.08|down on the probabilities of the
5657.82|4.859|incorrect characters and we're going to
5659.56|5.04|be pulling up on the probability at the
5662.679|6.421|correct index and that's what's
5664.6|7.079|basically happening in each row and thus
5669.1|5.579|the amount of push and pull is exactly
5671.679|4.5|equalized because the sum is zero so the
5674.679|2.881|amount to which we pull down in the
5676.179|3.301|probabilities and the demand that we
5677.56|3.659|push up on the probability of the
5679.48|3.719|correct character is equal
5681.219|4.44|so sort of the the repulsion and the
5683.199|5.0|attraction are equal and think of the
5685.659|4.681|neural app now as a like a massive uh
5688.199|4.121|pulley system or something like that
5690.34|4.02|we're up here on top of the logits and
5692.32|3.48|we're pulling up we're pulling down the
5694.36|3.6|properties of Incorrect and pulling up
5695.8|3.54|the property of the correct and in this
5697.96|3.36|complicated pulley system because
5699.34|3.96|everything is mathematically uh just
5701.32|4.08|determined just think of it as sort of
5703.3|4.02|like this tension translating to this
5705.4|4.14|complicating pulling mechanism and then
5707.32|4.14|eventually we get a tug on the weights
5709.54|3.96|and the biases and basically in each
5711.46|3.66|update we just kind of like tug in the
5713.5|3.78|direction that we like for each of these
5715.12|4.019|elements and the parameters are slowly
5717.28|3.359|given in to the tug and that's what
5719.139|2.941|training in neural net kind of like
5720.639|4.02|looks like on a high level
5722.08|4.8|and so I think the the forces of push
5724.659|4.801|and pull in these gradients are actually
5726.88|4.14|uh very intuitive here we're pushing and
5729.46|3.779|pulling on the correct answer and the
5731.02|3.54|incorrect answers and the amount of
5733.239|3.9|force that we're applying is actually
5734.56|4.98|proportional to uh the probabilities
5737.139|4.08|that came out in the forward pass
5739.54|4.02|and so for example if our probabilities
5741.219|4.381|came out exactly correct so they would
5743.56|5.04|have had zero everywhere except for one
5745.6|5.7|at the correct uh position then the the
5748.6|4.32|logits would be all a row of zeros for
5751.3|4.32|that example there would be no push and
5752.92|5.219|pull so the amount to which your
5755.62|3.78|prediction is incorrect is exactly the
5758.139|3.781|amount by which you're going to get a
5759.4|4.68|pull or a push in that dimension
5761.92|3.84|so if you have for example a very
5764.08|3.24|confidently mispredicted element here
5765.76|2.52|then
5767.32|3.3|um what's going to happen is that
5768.28|4.379|element is going to be pulled down very
5770.62|4.32|heavily and the correct answer is going
5772.659|3.961|to be pulled up to the same amount
5774.94|4.38|and the other characters are not going
5776.62|4.44|to be influenced too much
5779.32|4.02|so the amounts to which you mispredict
5781.06|4.5|is then proportional to the strength of
5783.34|3.839|the pole and that's happening
5785.56|3.96|independently in all the dimensions of
5787.179|3.721|this of this tensor and it's sort of
5789.52|3.42|very intuitive and varies to think
5790.9|3.72|through and that's basically the magic
5792.94|3.66|of the cross-entropy loss and what it's
5794.62|4.019|doing dynamically in the backward pass
5796.6|4.559|of the neural net so now we get to
5798.639|3.901|exercise number three which is a very
5801.159|2.701|fun exercise
5802.54|2.94|um depending on your definition of fun
5803.86|3.359|and we are going to do for batch
5805.48|3.6|normalization exactly what we did for
5807.219|3.96|cross entropy loss in exercise number
5809.08|3.72|two that is we are going to consider it
5811.179|3.601|as a glued single mathematical
5812.8|3.78|expression and back propagate through it
5814.78|3.419|in a very efficient manner because we
5816.58|3.3|are going to derive a much simpler
5818.199|2.821|formula for the backward path of batch
5819.88|2.759|normalization
5821.02|2.46|and we're going to do that using pen and
5822.639|2.58|paper
5823.48|3.3|so previously we've broken up
5825.219|3.241|bastionalization into all of the little
5826.78|3.6|intermediate pieces and all the atomic
5828.46|4.98|operations inside it and then we back
5830.38|5.4|propagate it through it one by one
5833.44|5.34|now we just have a single sort of
5835.78|4.32|forward pass of a batch form and it's
5838.78|3.0|all glued together
5840.1|2.94|and we see that we get the exact same
5841.78|3.48|result as before
5843.04|4.44|now for the backward pass we'd like to
5845.26|4.26|also Implement a single formula
5847.48|3.36|basically for back propagating through
5849.52|2.699|this entire operation that is the
5850.84|3.42|bachelorization
5852.219|5.221|so in the forward pass previously we
5854.26|5.64|took hpvn the hidden states of the
5857.44|4.92|pre-batch realization and created H
5859.9|4.14|preact which is the hidden States just
5862.36|4.26|before the activation
5864.04|5.58|in the bachelorization paper each pbn is
5866.62|4.5|X and each preact is y
5869.62|4.5|so in the backward pass what we'd like
5871.12|5.46|to do now is we have DH preact and we'd
5874.12|3.84|like to produce d h previous
5876.58|3.48|and we'd like to do that in a very
5877.96|4.62|efficient manner so that's the name of
5880.06|5.159|the game calculate the H previan given
5882.58|4.68|DH preact and for the purposes of this
5885.219|4.44|exercise we're going to ignore gamma and
5887.26|4.32|beta and their derivatives because they
5889.659|4.621|take on a very simple form in a very
5891.58|6.42|similar way to what we did up above
5894.28|4.68|so let's calculate this given that right
5898.0|2.699|here
5898.96|4.62|so to help you a little bit like I did
5900.699|6.061|before I started off the implementation
5903.58|4.44|here on pen and paper and I took two
5906.76|3.0|sheets of paper to derive the
5908.02|2.46|mathematical formulas for the backward
5909.76|3.36|pass
5910.48|4.92|and basically to set up the problem uh
5913.12|6.18|just write out the MU Sigma Square
5915.4|5.279|variance x i hat and Y I exactly as in
5919.3|2.52|the paper except for the bezel
5920.679|2.281|correction
5921.82|3.0|and then
5922.96|3.12|in a backward pass we have the
5924.82|3.839|derivative of the loss with respect to
5926.08|4.559|all the elements of Y and remember that
5928.659|3.421|Y is a vector there's there's multiple
5930.639|3.961|numbers here
5932.08|4.86|so we have all the derivatives with
5934.6|4.68|respect to all the Y's
5936.94|4.08|and then there's a demo and a beta and
5939.28|3.899|this is kind of like the compute graph
5941.02|5.52|the gamma and the beta there's the X hat
5943.179|7.321|and then the MU and the sigma squared
5946.54|6.9|and the X so we have DL by DYI and we
5950.5|4.739|won't DL by d x i for all the I's in
5953.44|4.14|these vectors
5955.239|4.741|so this is the compute graph and you
5957.58|4.74|have to be careful because I'm trying to
5959.98|5.46|note here that these are vectors so
5962.32|6.72|there's many nodes here inside x x hat
5965.44|5.4|and Y but mu and sigma sorry Sigma
5969.04|4.26|Square are just individual scalars
5970.84|3.66|single numbers so you have to be careful
5973.3|2.58|with that you have to imagine there's
5974.5|3.96|multiple nodes here or you're going to
5975.88|4.98|get your math wrong
5978.46|4.739|um so as an example I would suggest that
5980.86|3.9|you go in the following order one two
5983.199|3.661|three four in terms of the back
5984.76|4.919|propagation so back propagating to X hat
5986.86|5.22|then into Sigma Square then into mu and
5989.679|4.381|then into X
5992.08|3.78|um just like in a topological sort in
5994.06|3.599|micrograd we would go from right to left
5995.86|3.9|you're doing the exact same thing except
5997.659|3.901|you're doing it with symbols and on a
5999.76|5.52|piece of paper
6001.56|8.4|so for number one uh I'm not giving away
6005.28|7.439|too much if you want DL of d x i hat
6009.96|5.219|then we just take DL by DYI and multiply
6012.719|5.041|it by gamma because of this expression
6015.179|6.421|here where any individual Yi is just
6017.76|6.12|gamma times x i hat plus beta so it
6021.6|3.78|doesn't help you too much there but this
6023.88|5.04|gives you basically the derivatives for
6025.38|5.819|all the X hats and so now try to go
6028.92|6.42|through this computational graph and
6031.199|6.901|derive what is DL by D Sigma Square
6035.34|4.5|and then what is DL by B mu and then one
6038.1|4.2|is D L by DX
6039.84|4.26|eventually so give it a go and I'm going
6042.3|4.5|to be revealing the answer one piece at
6044.1|4.619|a time okay so to get DL by D Sigma
6046.8|4.32|Square we have to remember again like I
6048.719|3.601|mentioned that there are many excess X
6051.12|3.119|hats here
6052.32|3.54|and remember that Sigma square is just a
6054.239|5.341|single individual number here
6055.86|5.94|so when we look at the expression
6059.58|3.48|for the L by D Sigma Square
6061.8|6.3|we have that we have to actually
6063.06|7.619|consider all the possible paths that um
6068.1|4.98|we basically have that there's many X
6070.679|4.741|hats and they all feed off from they all
6073.08|4.139|depend on Sigma Square so Sigma square
6075.42|3.6|has a large fan out there's lots of
6077.219|3.361|arrows coming out from Sigma square into
6079.02|3.36|all the X hats
6080.58|4.26|and then there's a back propagating
6082.38|4.44|signal from each X hat into Sigma square
6084.84|5.1|and that's why we actually need to sum
6086.82|4.02|over all those I's from I equal to 1 to
6089.94|5.64|m
6090.84|6.12|of the DL by d x i hat which is the
6095.58|4.5|global gradient
6096.96|5.159|times the x i Hat by D Sigma Square
6100.08|4.5|which is the local gradient
6102.119|4.321|of this operation here
6104.58|3.84|and then mathematically I'm just working
6106.44|4.56|it out here and I'm simplifying and you
6108.42|4.199|get a certain expression for DL by D
6111.0|2.94|Sigma square and we're going to be using
6112.619|4.141|this expression when we back propagate
6113.94|4.14|into mu and then eventually into X so
6116.76|5.04|now let's continue our back propagation
6118.08|6.659|into mu so what is D L by D mu now again
6121.8|5.399|be careful that mu influences X hat and
6124.739|4.681|X hat is actually lots of values so for
6127.199|3.601|example if our mini batch size is 32 as
6129.42|4.02|it is in our example that we were
6130.8|5.76|working on then this is 32 numbers and
6133.44|4.62|32 arrows going back to mu and then mu
6136.56|3.059|going to Sigma square is just a single
6138.06|4.32|Arrow because Sigma square is a scalar
6139.619|5.58|so in total there are 33 arrows
6142.38|5.1|emanating from you and then all of them
6145.199|4.141|have gradients coming into mu and they
6147.48|4.259|all need to be summed up
6149.34|5.04|and so that's why when we look at the
6151.739|5.701|expression for DL by D mu I am summing
6154.38|5.94|up over all the gradients of DL by d x i
6157.44|5.58|hat times the x i Hat by being mu
6160.32|5.04|uh so that's the that's this arrow and
6163.02|4.199|that's 32 arrows here and then plus the
6165.36|4.2|one Arrow from here which is the L by
6167.219|3.301|the sigma Square Times the sigma squared
6169.56|2.76|by D mu
6170.52|3.48|so now we have to work out that
6172.32|2.94|expression and let me just reveal the
6174.0|4.139|rest of it
6175.26|4.8|uh simplifying here is not complicated
6178.139|3.06|the first term and you just get an
6180.06|2.34|expression here
6181.199|2.161|for the second term though there's
6182.4|1.98|something really interesting that
6183.36|3.0|happens
6184.38|4.04|when we look at the sigma squared by D
6186.36|5.4|mu and we simplify
6188.42|5.92|at one point if we assume that in a
6191.76|5.359|special case where mu is actually the
6194.34|6.0|average of X I's as it is in this case
6197.119|4.961|then if we plug that in then actually
6200.34|4.44|the gradient vanishes and becomes
6202.08|4.38|exactly zero and that makes the entire
6204.78|4.62|second term cancel
6206.46|4.199|and so these uh if you just have a
6209.4|3.6|mathematical expression like this and
6210.659|5.04|you look at D Sigma Square by D mu you
6213.0|4.679|would get some mathematical formula for
6215.699|4.201|how mu impacts Sigma Square
6217.679|4.321|but if it is the special case that Nu is
6219.9|3.9|actually equal to the average as it is
6222.0|3.3|in the case of pastoralization that
6223.8|4.2|gradient will actually vanish and become
6225.3|3.98|zero so the whole term cancels and we
6228.0|4.86|just get a fairly straightforward
6229.28|5.439|expression here for DL by D mu okay and
6232.86|4.799|now we get to the craziest part which is
6234.719|4.381|uh deriving DL by dxi which is
6237.659|3.301|ultimately what we're after
6239.1|4.26|now let's count
6240.96|4.32|first of all how many numbers are there
6243.36|4.799|inside X as I mentioned there are 32
6245.28|3.899|numbers there are 32 Little X I's and
6248.159|2.881|let's count the number of arrows
6249.179|4.141|emanating from each x i
6251.04|3.72|there's an arrow going to Mu an arrow
6253.32|3.299|going to Sigma Square
6254.76|4.439|and then there's an arrow going to X hat
6256.619|3.661|but this Arrow here let's scrutinize
6259.199|4.261|that a little bit
6260.28|7.02|each x i hat is just a function of x i
6263.46|5.699|and all the other scalars so x i hat
6267.3|3.0|only depends on x i and none of the
6269.159|3.48|other X's
6270.3|4.439|and so therefore there are actually in
6272.639|4.56|this single Arrow there are 32 arrows
6274.739|4.261|but those 32 arrows are going exactly
6277.199|3.721|parallel they don't interfere and
6279.0|3.96|they're just going parallel between x
6280.92|3.54|and x hat you can look at it that way
6282.96|4.199|and so how many arrows are emanating
6284.46|6.48|from each x i there are three arrows mu
6287.159|6.0|Sigma squared and the associated X hat
6290.94|4.62|and so in back propagation we now need
6293.159|4.801|to apply the chain rule and we need to
6295.56|4.26|add up those three contributions
6297.96|4.14|so here's what that looks like if I just
6299.82|4.859|write that out
6302.1|4.68|we have uh we're going through we're
6304.679|4.5|chaining through mu Sigma square and
6306.78|3.6|through X hat and those three terms are
6309.179|4.201|just here
6310.38|5.1|now we already have three of these we
6313.38|4.5|have d l by d x i hat
6315.48|4.44|we have DL by D mu which we derived here
6317.88|4.56|and we have DL by D Sigma Square which
6319.92|3.719|we derived here but we need three other
6322.44|4.38|terms here
6323.639|4.801|the this one this one and this one so I
6326.82|3.06|invite you to try to derive them it's
6328.44|3.12|not that complicated you're just looking
6329.88|5.1|at these Expressions here and
6331.56|7.34|differentiating with respect to x i
6334.98|3.92|so give it a shot but here's the result
6339.42|3.42|or at least what I got
6341.699|2.401|um
6342.84|2.7|yeah I'm just I'm just differentiating
6344.1|3.0|with respect to x i for all these
6345.54|2.88|expressions and honestly I don't think
6347.1|3.42|there's anything too tricky here it's
6348.42|3.84|basic calculus
6350.52|3.179|now it gets a little bit more tricky is
6352.26|3.54|we are now going to plug everything
6353.699|3.721|together so all of these terms
6355.8|3.78|multiplied with all of these terms and
6357.42|4.08|add it up according to this formula and
6359.58|4.5|that gets a little bit hairy so what
6361.5|3.78|ends up happening is
6364.08|4.38|uh
6365.28|4.62|you get a large expression and the thing
6368.46|4.02|to be very careful with here of course
6369.9|5.819|is we are working with a DL by dxi for
6372.48|4.679|specific I here but when we are plugging
6375.719|3.121|in some of these terms
6377.159|2.341|like say
6378.84|3.42|um
6379.5|5.28|this term here deal by D signal squared
6382.26|4.02|you see how the L by D Sigma squared I
6384.78|4.439|end up with an expression and I'm
6386.28|5.58|iterating over little I's here but I
6389.219|4.681|can't use I as the variable when I plug
6391.86|3.299|in here because this is a different I
6393.9|3.48|from this eye
6395.159|4.261|this I here is just a place or like a
6397.38|4.5|local variable for for a for Loop in
6399.42|4.5|here so here when I plug that in you
6401.88|3.779|notice that I rename the I to a j
6403.92|4.799|because I need to make sure that this J
6405.659|4.741|is not that this J is not this I this J
6408.719|4.561|is like like a little local iterator
6410.4|3.96|over 32 terms and so you have to be
6413.28|2.82|careful with that when you're plugging
6414.36|4.08|in the expressions from here to here you
6416.1|4.019|may have to rename eyes into J's and you
6418.44|5.759|have to be very careful what is actually
6420.119|7.08|an I with respect to the L by t x i
6424.199|4.5|so some of these are J's some of these
6427.199|4.261|are I's
6428.699|5.101|and then we simplify this expression
6431.46|4.38|and I guess like the big thing to notice
6433.8|3.06|here is a bunch of terms just kind of
6435.84|2.879|come out to the front and you can
6436.86|3.06|refactor them there's a sigma squared
6438.719|3.241|plus Epsilon raised to the power of
6439.92|3.84|negative three over two uh this Sigma
6441.96|3.96|squared plus Epsilon can be actually
6443.76|4.62|separated out into three terms each of
6445.92|4.38|them are Sigma squared plus Epsilon to
6448.38|5.279|the negative one over two so the three
6450.3|4.859|of them multiplied is equal to this and
6453.659|4.08|then those three terms can go different
6455.159|3.901|places because of the multiplication so
6457.739|4.861|one of them actually comes out to the
6459.06|6.36|front and will end up here outside one
6462.6|5.099|of them joins up with this term and one
6465.42|3.66|of them joins up with this other term
6467.699|3.361|and then when you simplify the
6469.08|3.3|expression you'll notice that some of
6471.06|2.94|these terms that are coming out are just
6472.38|3.839|the x i hats
6474.0|3.119|so you can simplify just by rewriting
6476.219|2.761|that
6477.119|3.241|and what we end up with at the end is a
6478.98|3.3|fairly simple mathematical expression
6480.36|4.74|over here that I cannot simplify further
6482.28|4.68|but basically you'll notice that it only
6485.1|5.28|uses the stuff we have and it derives
6486.96|6.06|the thing we need so we have the L by d
6490.38|5.339|y for all the I's and those are used
6493.02|4.32|plenty of times here and also in
6495.719|3.541|addition what we're using is these x i
6497.34|3.6|hats and XJ hats and they just come from
6499.26|3.66|the forward pass
6500.94|4.799|and otherwise this is a simple
6502.92|5.04|expression and it gives us DL by d x i
6505.739|3.541|for all the I's and that's ultimately
6507.96|4.86|what we're interested in
6509.28|5.7|so that's the end of Bachelor backward
6512.82|4.02|pass analytically let's now implement
6514.98|3.48|this final result
6516.84|4.74|okay so I implemented the expression
6518.46|5.1|into a single line of code here and you
6521.58|3.36|can see that the max diff is Tiny so
6523.56|4.92|this is the correct implementation of
6524.94|5.699|this formula now I'll just uh
6528.48|3.9|basically tell you that getting this
6530.639|4.02|formula here from this mathematical
6532.38|3.839|expression was not trivial and there's a
6534.659|3.721|lot going on packed into this one
6536.219|4.561|formula and this is a whole exercise by
6538.38|4.68|itself because you have to consider the
6540.78|4.439|fact that this formula here is just for
6543.06|4.38|a single neuron and a batch of 32
6545.219|4.92|examples but what I'm doing here is I'm
6547.44|4.44|actually we actually have 64 neurons and
6550.139|4.141|so this expression has to in parallel
6551.88|4.259|evaluate the bathroom backward pass for
6554.28|4.14|all of those 64 neurons in parallel
6556.139|4.141|independently so this has to happen
6558.42|2.4|basically in every single
6560.28|4.14|um
6560.82|5.64|column of the inputs here
6564.42|3.779|and in addition to that you see how
6566.46|2.94|there are a bunch of sums here and we
6568.199|3.42|need to make sure that when I do those
6569.4|3.96|sums that they broadcast correctly onto
6571.619|3.661|everything else that's here
6573.36|3.42|and so getting this expression is just
6575.28|2.7|like highly non-trivial and I invite you
6576.78|2.58|to basically look through it and step
6577.98|5.12|through it and it's a whole exercise to
6579.36|6.0|make sure that this this checks out but
6583.1|3.46|once all the shapes are green and once
6585.36|3.42|you convince yourself that it's correct
6586.56|4.02|you can also verify that Patrick's gets
6588.78|3.12|the exact same answer as well and so
6590.58|3.3|that gives you a lot of peace of mind
6591.9|3.96|that this mathematical formula is
6593.88|4.08|correctly implemented here and
6595.86|4.64|broadcasted correctly and replicated in
6597.96|5.58|parallel for all of the 64 neurons
6600.5|5.26|inside this bastrum layer okay and
6603.54|4.74|finally exercise number four asks you to
6605.76|4.56|put it all together and uh here we have
6608.28|3.6|a redefinition of the entire problem so
6610.32|3.6|you see that we reinitialize the neural
6611.88|4.08|nut from scratch and everything and then
6613.92|4.319|here instead of calling loss that
6615.96|4.14|backward we want to have the manual back
6618.239|4.861|propagation here as we derived It Up
6620.1|4.98|Above so go up copy paste all the chunks
6623.1|3.84|of code that we've already derived put
6625.08|3.72|them here and drive your own gradients
6626.94|4.199|and then optimize this neural nut
6628.8|4.26|basically using your own gradients all
6631.139|3.841|the way to the calibration of The
6633.06|3.78|Bachelor and the evaluation of the loss
6634.98|3.42|and I was able to achieve quite a good
6636.84|3.72|loss basically the same loss you would
6638.4|3.54|achieve before and that shouldn't be
6640.56|3.78|surprising because all we've done is
6641.94|3.9|we've really gotten to Lost That
6644.34|2.339|backward and we've pulled out all the
6645.84|3.299|code
6646.679|3.781|and inserted it here but those gradients
6649.139|3.181|are identical and everything is
6650.46|4.02|identical and the results are identical
6652.32|4.14|it's just that we have full visibility
6654.48|4.02|on exactly what goes on under the hood
6656.46|5.58|I'll plot that backward in this specific
6658.5|5.82|case and this is all of our code this is
6662.04|4.079|the full backward pass using basically
6664.32|3.899|the simplified backward pass for the
6666.119|4.261|cross entropy loss and the mass
6668.219|4.98|generalization so back propagating
6670.38|5.22|through cross entropy the second layer
6673.199|3.781|the 10 H nonlinearity the batch
6675.6|3.599|normalization
6676.98|4.199|uh through the first layer and through
6679.199|4.02|the embedding and so you see that this
6681.179|3.96|is only maybe what is this 20 lines of
6683.219|4.261|code or something like that and that's
6685.139|4.921|what gives us gradients and now we can
6687.48|4.5|potentially erase losses backward so the
6690.06|3.78|way I have the code set up is you should
6691.98|4.08|be able to run this entire cell once you
6693.84|4.14|fill this in and this will run for only
6696.06|3.48|100 iterations and then break
6697.98|3.12|and it breaks because it gives you an
6699.54|3.54|opportunity to check your gradients
6701.1|5.22|against pytorch
6703.08|5.88|so here our gradients we see are not
6706.32|4.68|exactly equal they are approximately
6708.96|4.02|equal and the differences are tiny
6711.0|3.239|wanting negative 9 or so and I don't
6712.98|3.06|exactly know where they're coming from
6714.239|3.061|to be honest
6716.04|3.42|um so once we have some confidence that
6717.3|4.02|the gradients are basically correct we
6719.46|6.3|can take out the gradient tracking
6721.32|6.419|we can disable this breaking statement
6725.76|4.859|and then we can
6727.739|5.46|basically disable lost of backward we
6730.619|3.841|don't need it anymore it feels amazing
6733.199|3.48|to say that
6734.46|3.96|and then here when we are doing the
6736.679|5.101|update we're not going to use P dot grad
6738.42|4.5|this is the old way of pytorch we don't
6741.78|3.66|have that anymore because we're not
6742.92|4.739|doing backward we are going to use this
6745.44|3.66|update where we you see that I'm
6747.659|3.241|iterating over
6749.1|3.48|I've arranged the grads to be in the
6750.9|3.779|same order as the parameters and I'm
6752.58|4.559|zipping them up the gradients and the
6754.679|4.141|parameters into p and grad and then here
6757.139|3.721|I'm going to step with just the grad
6758.82|4.919|that we derived manually
6760.86|5.7|so the last piece
6763.739|5.94|um is that none of this now requires
6766.56|4.86|gradients from pytorch and so one thing
6769.679|2.641|you can do here
6771.42|4.799|um
6772.32|5.819|is you can do with no grad and offset
6776.219|3.181|this whole code block
6778.139|2.461|and really what you're saying is you're
6779.4|2.64|telling Pat George that hey I'm not
6780.6|3.36|going to call backward on any of this
6782.04|3.42|and this allows pytorch to be a bit more
6783.96|3.84|efficient with all of it
6785.46|4.44|and then we should be able to just uh
6787.8|4.08|run this
6789.9|4.08|and
6791.88|4.98|it's running
6793.98|4.02|and you see that losses backward is
6796.86|3.299|commented out
6798.0|5.52|and we're optimizing
6800.159|5.161|so we're going to leave this run and uh
6803.52|3.54|hopefully we get a good result
6805.32|3.359|okay so I allowed the neural net to
6807.06|4.139|finish optimization
6808.679|4.56|then here I calibrate the bachelor
6811.199|4.741|parameters because I did not keep track
6813.239|4.021|of the running mean and very variants in
6815.94|3.9|their training Loop
6817.26|3.72|then here I ran the loss and you see
6819.84|2.94|that we actually obtained a pretty good
6820.98|3.0|loss very similar to what we've achieved
6822.78|2.7|before
6823.98|3.659|and then here I'm sampling from the
6825.48|4.259|model and we see some of the name like
6827.639|4.681|gibberish that we're sort of used to so
6829.739|5.041|basically the model worked and samples
6832.32|4.02|uh pretty decent results compared to
6834.78|3.66|what we were used to so everything is
6836.34|4.08|the same but of course the big deal is
6838.44|3.779|that we did not use lots of backward we
6840.42|3.9|did not use package Auto grad and we
6842.219|2.881|estimated our gradients ourselves by
6844.32|2.339|hand
6845.1|3.599|and so hopefully you're looking at this
6846.659|3.48|the backward pass of this neural net and
6848.699|3.781|you're thinking to yourself actually
6850.139|2.941|that's not too complicated
6852.48|2.699|um
6853.08|4.2|each one of these layers is like three
6855.179|3.54|lines of code or something like that and
6857.28|3.359|most of it is fairly straightforward
6858.719|4.081|potentially with the notable exception
6860.639|4.681|of the batch normalization backward pass
6862.8|3.899|otherwise it's pretty good okay and
6865.32|3.839|that's everything I wanted to cover for
6866.699|4.381|this lecture so hopefully you found this
6869.159|3.841|interesting and what I liked about it
6871.08|3.78|honestly is that it gave us a very nice
6873.0|3.6|diversity of layers to back propagate
6874.86|3.48|through and
6876.6|3.18|um I think it gives a pretty nice and
6878.34|3.24|comprehensive sense of how these
6879.78|4.08|backward passes are implemented and how
6881.58|3.599|they work and you'd be able to derive
6883.86|2.94|them yourself but of course in practice
6885.179|3.96|you probably don't want to and you want
6886.8|4.2|to use the pythonograd but hopefully you
6889.139|3.54|have some intuition about how gradients
6891.0|4.139|flow backwards through the neural net
6892.679|3.841|starting at the loss and how they flow
6895.139|3.06|through all the variables and all the
6896.52|4.199|intermediate results
6898.199|4.081|and if you understood a good chunk of it
6900.719|3.0|and if you have a sense of that then you
6902.28|3.78|can count yourself as one of these buff
6903.719|5.4|doji's on the left instead of the uh
6906.06|4.5|those on the right here now in the next
6909.119|4.321|lecture we're actually going to go to
6910.56|5.7|recurrent neural nuts lstms and all the
6913.44|4.38|other variants of RNs and we're going to
6916.26|3.419|start to complexify the architecture and
6917.82|3.72|start to achieve better uh log
6919.679|5.601|likelihoods and so I'm really looking
6921.54|3.74|forward to that and I'll see you then