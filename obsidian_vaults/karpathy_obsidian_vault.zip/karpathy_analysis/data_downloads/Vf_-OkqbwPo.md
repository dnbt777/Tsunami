start_time|end_time|text
0.0|2.85|today we're going to go over these four
1.56|5.04|major software packages that people
2.85|6.99|commonly use for deep learning as usual
6.6|5.82|a couple administrative things the
9.84|4.469|milestones were actually due last week
12.42|3.17|so hopefully you turn them in and we'll
14.309|4.021|try to take a look at those this week
15.59|3.97|also remember that assignment three the
18.33|5.84|final assignment is going to be due on
19.56|6.99|Wednesday so and you guys done already
24.17|6.81|okay that's that's good
26.55|4.43|you have late days so you should be fine
31.14|3.18|another another thing that I should
32.88|3.12|point out is that if you're actually
34.32|3.239|planning on using terminal for your
36.0|3.45|projects which I think a lot of you are
37.559|4.741|then make sure you you're backing up
39.45|4.429|your code and data and things off of the
42.3|4.32|terminal instances every once in a while
43.879|4.84|we've had some problems where the
46.62|3.84|instances will crash randomly and in
48.719|3.331|most cases the the terminal folks have
50.46|3.509|been able to get the data back but it
52.05|3.329|sometimes takes a couple days and
53.969|3.57|there's been a couple of cases where
55.379|4.441|actually people lost data because it was
57.539|3.991|just on terminal and it crashed so I
59.82|3.18|think if you are planning to use
61.53|3.029|terminal then make sure that you have
63.0|4.92|some alternative backup strategy for
64.559|5.641|your code and your data so like I said
67.92|4.98|today we're talking about these four
70.2|5.88|software packages that are commonly used
72.9|3.69|for deep learning cafe Torche Theano and
76.08|2.76|tensorflow
76.59|4.349|and as a little bit of disclaimer at the
78.84|4.38|beginning i've mode like personally I've
80.939|3.451|mostly worked with cafe and torch so
83.22|3.329|those are the ones that I know the most
84.39|5.43|about I'll do my best to give you a good
86.549|6.451|flavor for the others as well but just
89.82|6.299|throwing that disclaimer out there so
93.0|5.189|the first one is cafe we saw in the last
96.119|3.57|lecture that really cafe sprung out of
98.189|3.601|this paper at Berkeley that was trying
99.689|4.261|to re-implement Aleks net and use Aleks
101.79|4.56|nut features for other things and since
103.95|4.199|then cafe has really grown into a really
106.35|3.799|really popular widely used package for
108.149|6.54|especially convolutional neural networks
110.149|7.091|so cafe is from Berkeley that I think a
114.689|5.371|lot of you people have know and it's
117.24|4.89|mostly written in C++ and there's
120.06|3.629|actually bindings for cafes you can
122.13|4.379|access the Nets and whatnot in python
123.689|5.04|and matlab that are super useful and in
126.509|3.511|general cafe is really widely used and
128.729|2.941|its really really good if you just want
130.02|3.14|to train sort of standard feed-forward
131.67|4.73|vanilla convolutional now
133.16|4.38|works and actually cafe is somewhat
136.4|2.94|different than the others other
137.54|4.02|frameworks in this respect you can
139.34|4.13|actually train big powerful models in
141.56|4.71|cafe without writing any code yourself
143.47|4.84|so for example the the ResNet image and
146.27|3.45|classification model that one image that
148.31|2.97|one everything last year you can
149.72|3.42|actually train a ResNet using cafe
151.28|4.83|without writing any code which is pretty
153.14|4.38|amazing so the Morse but the most
156.11|4.29|important tip when you're working with
157.52|4.41|cafe is that the documentation is not is
160.4|3.78|sometimes out of date and not always
161.93|3.99|perfect so you need to not be afraid to
164.18|5.91|just dive in there and read the source
165.92|6.42|code yourself if C++ so hopefully you
170.09|4.44|can read that and understand it but in
172.34|4.2|general the the C++ code that they have
174.53|3.24|in cafe is pretty well structured pretty
176.54|3.75|well organized and pretty easy to
177.77|4.83|understand so if you have doubts about
180.29|4.17|how things work in cafe you your best
182.6|6.0|bet is just to go on github and read the
184.46|6.21|source code so the mate so cafe is this
188.6|3.75|huge big project with like probably
190.67|3.0|thousands tens of thousands of lines of
192.35|2.85|code and it's a little bit scary to
193.67|4.5|understand how everything fits together
195.2|5.43|but there's really four major classes in
198.17|4.98|cafe that you need to know about the
200.63|4.59|first one is a blob so blobs
203.15|4.38|store all of your data and your weights
205.22|6.57|and your activations in the network so
207.53|7.38|these blobs are things in the network so
211.79|5.31|your weights are have block your weights
214.91|3.75|are stored in a blob your data which
217.1|3.75|would be like your pixel values are
218.66|4.41|stored in a blob and your labels your
220.85|3.81|Y's are stored in a blob and also all of
223.07|4.65|your intermediate activations will also
224.66|4.68|be stored in blobs so blobs are these n
227.72|3.51|dimensional tensors sort of like you've
229.34|4.23|seen in numpy except that they actually
231.23|6.54|have four copies of an n-dimensional
233.57|7.26|tensor inside they have data for a data
237.77|5.25|version of the tensor which is storing
240.83|4.95|the actual raw data and they also have a
243.02|4.5|parallel thing that parallel tensor
245.78|4.47|called dips that cafe uses to store
247.52|5.07|gradients with respect to that data and
250.25|4.38|that gives you two and then you actually
252.59|4.44|have four because there's a CPU and a
254.63|4.14|GPU version of each of those things so
257.03|3.51|you have data you have dips you have CPU
258.77|5.16|you have GPU there's actually four
260.54|5.249|n-dimensional tensors per blob the next
263.93|2.81|important class that you need to know
265.789|4.13|about in cafe is
266.74|4.41|lair and a lair is sort of a function
269.919|3.301|so I'm similar to the ones you wrote on
271.15|4.889|the homeworks that receives some input
273.22|5.49|blobs cafe calls inputs bottoms and then
276.039|5.461|produces output blobs that cafe calls
278.71|4.38|top blobs so the idea is that your layer
281.5|3.21|will receive pointers to the bottom
283.09|4.169|blobs with the data already filled in
284.71|4.47|and then it'll also receive a pointer to
287.259|3.571|the top blobs and it will and in forward
289.18|4.5|pass Italy expect it to fill in the
290.83|5.73|values for the data elements of your top
293.68|4.59|blobs then in the backward pass the
296.56|3.96|layers will compute gradients so they
298.27|4.619|will expect to receive a pointer to the
300.52|4.11|top blobs with the gradients and the
302.889|3.84|activations filled in and then they'll
304.63|3.45|also receive a pointer to the bottom
306.729|4.711|blobs and fill in the gradients for the
308.08|5.25|bottoms and Blair is this a pretty well
311.44|4.11|structured abstract class that you can
313.33|3.869|go and I have I have the the links with
315.55|3.03|a source and the header file here and
317.199|3.69|there's a lot of sub classes that
318.58|6.03|implement different types of layers and
320.889|5.881|a like I said a common cafe problem
324.61|4.26|there's no really good list of all the
326.77|3.75|layer types you pretty much just need to
328.87|5.49|look at the code and see what types of
330.52|5.88|CPP files there are the next thing you
334.36|4.619|need to know about is a net so a net
336.4|4.56|just combines a bunch of layers a net is
338.979|3.901|basically a directed acyclic graph of
340.96|3.57|layers and is responsible for running
342.88|4.5|the forward and the backward methods of
344.53|5.009|the layers in the correct order so this
347.38|3.629|is you probably don't need to touch this
349.539|2.97|class ever yourself but it's kind of
351.009|4.081|nice to look at to get a flavor of how
352.509|3.69|everything fits together and the final
355.09|4.259|class that you need to know about is a
356.199|4.44|solver so the solver is you know we had
359.349|3.331|this thing called solver on the homework
360.639|4.381|that was really inspired by cafe so a
362.68|4.489|solver is intended to dip into the net
365.02|4.199|run the net forward and backward on data
367.169|3.611|actually update the parameters of the
369.219|2.94|network and handle checkpointing and
370.78|4.259|resuming from checkpoints and all that
372.159|5.221|sort of stuff and in cafe solver is this
375.039|3.78|abstract class and the different update
377.38|3.779|rules are implemented by different
378.819|3.961|subclasses so there's for example a
381.159|3.121|stochastic gradient descent solver
382.78|3.33|there's an atom solver there's an
384.28|3.93|rmsprop solver all of that sort of stuff
386.11|3.66|and again just to see what kinds of
388.21|4.139|options are available you should look at
389.77|3.929|the source code so this kind of gives
392.349|2.94|you a nice little overview of how these
393.699|3.361|things all fit together that this whole
395.289|4.171|thing on the right would be a net the
397.06|3.2|net contains in the green boxes blobs
399.46|3.08|each
400.26|4.2|bob contains data and dips the red boxes
402.54|3.33|are layers that are connecting blobs
404.46|7.2|together and then the whole thing would
405.87|7.47|get optimized with a solver so Cafe
411.66|3.87|makes heavy use of this funny thing
413.34|3.89|called protocol buffers any of you guys
415.53|3.84|ever intern to Google
417.23|4.48|yeah fair numbers you guys know about
419.37|5.04|this but protocol buffers are this
421.71|4.26|almost like a binary strongly typed JSON
424.41|3.21|I sort of like to think about it that
425.97|3.93|are used very widely inside Google for
427.62|4.71|serializing data to disk and for passing
429.9|5.25|it over the network so protocol buffers
432.33|4.35|there's this dot proto file that defines
435.15|3.54|the different kinds of fields that
436.68|3.54|different types of objects have so in
438.69|3.69|this example there's a person that has a
440.22|5.22|name and an ID and an email and this
442.38|4.01|lives in a dot proto file dot proto
445.44|3.96|files
446.39|5.44|define a type of a class and you can
449.4|6.03|actually serialize instances to human
451.83|5.49|readable dot proto txt files so for
455.43|3.48|example this fills in the name it gives
457.32|3.63|you the ID it gives you the email and
458.91|4.77|this is an instance of a person that can
460.95|4.71|be saved into this text file then
463.68|4.26|protobuf includes this compiler that
465.66|3.9|actually lets you generate classes in
467.94|3.96|various programming languages to access
469.56|4.86|these data types so you can after
471.9|4.86|running the protobuf compiler on this
474.42|4.74|proto file it produces classes that you
476.76|5.91|can then import in Java and C C++ and
479.16|5.52|Python and go and just about everything
482.67|4.2|so actually cafe makes wide use of these
484.68|3.54|protists protocol buffers and they use
486.87|6.81|them to store pretty much everything in
488.22|7.05|cafe so cafe like I said to understand
493.68|4.2|that you need to read the code to
495.27|5.82|understand cafe and Cafe has this one
497.88|5.1|giant file called cafe proto that just
501.09|4.68|defines all of the protocol buffer types
502.98|4.65|that are used in cafe so this is a
505.77|3.48|gigantic file it's it's I think it's a
507.63|3.57|couple thousand lines long but it's
509.25|3.78|actually pretty well documented and is I
511.2|3.81|think the most up-to-date documentation
513.03|3.78|of what all the layer types are what the
515.01|3.51|options for those layers are how you
516.81|3.419|specify every all the options for
518.52|3.81|solvers and layers and nets and all that
520.229|3.391|so I'd really encourage you to check out
522.33|3.84|this file and read through it if you
523.62|5.58|have any questions about how things work
526.17|5.73|in cafe and just to give you a flavor on
529.2|4.95|the left here this shows you this
531.9|5.04|defines the net parameter which is the
534.15|5.1|of protocol buffer that cafe uses to
536.94|4.89|represent nets and on the right is this
539.25|4.71|solver parameter which use which cafe
541.83|4.38|uses to represent solvers so the net
543.96|4.95|parameter or so the solver parameter for
546.21|4.17|example takes a reference to a net and
548.91|3.36|it also includes things like learning
550.38|7.38|rate and how often to check point and
552.27|7.2|other things like that right so when
557.76|3.42|you're working in cafe actually it's
559.47|4.23|pretty cool you don't need to write any
561.18|3.99|code in order to train models so when
563.7|4.17|working with cafe you generally have
565.17|4.98|this four step process so first you'll
567.87|3.66|convert your data and especially if you
570.15|2.64|just have an image classification
571.53|2.61|problem you don't have to write any code
572.79|3.5|for this you just use one of the
574.14|4.86|existing binaries in cafe ships with
576.29|4.42|then you'll define your your net file
579.0|4.68|that you'll do by just writing or
580.71|4.53|editing one of these prototypes T's then
583.68|3.9|you'll define your solver which again
585.24|4.23|will just live via proto txt text file
587.58|3.99|that you can just work with in a text
589.47|4.71|editor and then you'll pass all of these
591.57|4.35|things to this existing binary to train
594.18|3.6|the model and that'll spit out your
595.92|4.83|train cafe model to disk that you can
597.78|4.8|then use for other things so even if you
600.75|3.09|wanted to Train ResNet on imagenet you
602.58|3.0|could just follow this simple procedure
603.84|4.37|and train a giant network without
605.58|5.91|writing any code so that's really cool
608.21|5.98|and so step one generally you'll need to
611.49|4.77|convert your data so cafe uses I know
614.19|4.35|we've talked a little bit about hdf5 as
616.26|3.84|a format for storing pixels on disk
618.54|4.26|contiguously and then reading from them
620.1|5.91|efficiently but by default cafe uses
622.8|5.13|this other file format called LM DB so
626.01|3.51|there's a if you if all you have is a
627.93|4.35|bunch of images each image with a label
629.52|4.74|then you can call L then Cafe just has a
632.28|4.05|script to convert that whole data set
634.26|7.17|into a giant LM DB that you can use for
636.33|6.45|training so just to give you an idea the
641.43|3.75|way it's this is really easy you just
642.78|4.47|create a text file that has the path to
645.18|3.72|your images and separated by the label
647.25|3.96|and you just pass it to your cafe script
648.9|4.14|wait a couple hours if your datasets big
651.21|4.8|and you end up with a giant LM DB file
653.04|5.4|on disk and if you're working with
656.01|5.43|something else like hdf5 then you'll
658.44|4.53|have to create it yourself probably so
661.44|2.88|cafe it does actually have a couple
662.97|3.98|other options for reading data in
664.32|5.06|there's this data layer the
666.95|5.04|no data layer for for detection it
669.38|3.93|actually can read from hdf5 and there's
671.99|2.76|an option for reading stuff directly
673.31|3.87|from memory that's especially useful
674.75|4.35|with a Python interface but at least in
677.18|3.84|my point of view all of these types of
679.1|3.66|other methods of reading and data to
681.02|4.65|cafe are a little bit second-class
682.76|4.23|citizens in the cafe ecosystem and LM DB
685.67|4.47|is really the easiest thing to work with
686.99|4.95|so l if you can you should probably try
690.14|7.11|to convert your data into LM DB format
691.94|8.76|with cafe so step two for cafe is to
697.25|5.49|define your net object so like I said
700.7|4.32|you'll just write a big proto txt to
702.74|4.2|define your net so here this is a this
705.02|3.84|just defines a simple model for logistic
706.94|3.45|regression you can see that I did not
708.86|5.07|follow my own advice and I'm reading
710.39|5.7|data out of an hdf5 file here then I
713.93|6.12|have a fully connected layer which isn't
716.09|5.28|called inner product in cafe then the
720.05|3.51|right so that's fully connected layer
721.37|6.05|tells you the number of classes and how
723.56|6.84|to initialize the values and then I have
727.42|5.38|a soft max loss function that reads the
730.4|3.93|labels and produces loss ingredients
732.8|3.54|from the outputs of the fully connected
734.33|4.44|layer so a couple things to point out
736.34|5.04|about this file are that one every layer
738.77|4.38|you typically include some blobs which
741.38|4.5|to store the data and the gradients and
743.15|4.62|the weights and the layers blobs and the
745.88|3.12|layer itself typically have the same
747.77|5.1|name so that can be a little bit
749.0|6.21|confusing another thing is that a lot of
752.87|4.74|these layers will have two blobs one for
755.21|4.26|weight and one for bias and actually in
757.61|3.59|this net win right in here you'll define
759.47|3.63|the learning rates for those two blobs
761.2|3.46|so that's learning rate and
763.1|4.62|regularization for both the weight and
764.66|5.19|the bias of that layer another thing to
767.72|4.38|note is that to specify the number of
769.85|4.97|output classes is just the num output on
772.1|5.67|this fully connected layer parameter and
774.82|5.02|finally the the quick and dirty way to
777.77|3.81|freeze layers in cafe is just to set the
779.84|4.35|learning rate to zero for that for the
781.58|6.9|blobs associated to that layers weights
784.19|6.84|or biases another thing to point out is
788.48|4.11|that um for ResNet and other large
791.03|3.6|models like google net this can get
792.59|4.44|really out of hand really quickly so
794.63|4.95|cafe doesn't really let you define like
797.03|3.69|compositionality so for ResNet they just
799.58|2.79|repeat the same pattern
800.72|4.799|over and over and over in the proto txt
802.37|6.54|file so the ResNet proto txt is almost
805.519|5.49|7,000 lines long so you could write that
808.91|3.539|by hand but in practice people tend to
811.009|4.051|write little Python scripts to generate
812.449|7.111|these things automatically so that's
815.06|6.24|that's a little bit gross if you add if
819.56|3.75|you want to fine tune a network rather
821.3|4.349|than starting from scratch then you'll
823.31|4.44|typically download some existing proto
825.649|4.351|txt and some existing weights file and
827.75|3.99|work from there so the way you should
830.0|3.899|think about it is that the proto txt
831.74|4.32|file that we've seen here before defines
833.899|4.74|the architecture of the network and then
836.06|5.069|the pre-trained weights live in this dot
838.639|4.56|Cafe model file that's a binary thing
841.129|3.661|and you can't really inspect it but the
843.199|4.5|way that it works is it's basically key
844.79|5.279|value pairs where it matches Nate where
847.699|4.62|the in the inside the cafe model it
850.069|5.31|matches these names that are scoped to
852.319|6.39|layers so this fc7 dot weight would be
855.379|4.861|the would be the weight corresponding to
858.709|4.891|this a final fully connected layer in
860.24|5.909|alex net so then when you want to fine
863.6|4.89|tune on your own data when you start up
866.149|4.68|cafe and you load a cafe model and a
868.49|4.349|proto txt it just tries to match the key
870.829|5.13|value pairs of names and weights between
872.839|4.86|the cafe model and the prototype tea so
875.959|3.57|if the names are the same then your new
877.699|3.99|network gets initialized from the values
879.529|4.341|in the proto txt which is really really
881.689|4.801|useful and convenient for fine tuning
883.87|5.409|but if the layers if the names don't
886.49|4.74|match then it those layers actually get
889.279|3.691|initialized from scratch so this is how
891.23|4.77|for example you can reinitialize the
892.97|5.28|output layer in cafe so to be a little
896.0|5.04|bit more concrete if you maybe download
898.25|4.319|an image net model then this layer is
901.04|2.94|going to this final fully connected
902.569|3.81|layer that's outputting class scores
903.98|4.02|will have a thousand outputs but now
906.379|3.63|maybe for some problem you care about
908.0|2.97|you only want to have ten outputs so
910.009|3.18|you're going to need to reinitialize
910.97|4.44|that final layer and reinitialize it
913.189|4.111|randomly and fine-tune the network so
915.41|4.109|the way that you do that is you need to
917.3|4.62|change the name of the layer in the
919.519|3.87|prototype aisle to make sure that it's
921.92|3.659|actually initialized randomly and not
923.389|4.981|reading from the from the from the cafe
925.579|4.74|model and if you forget to do this then
928.37|3.449|it'll actually crash and it'll give you
930.319|3.901|a weird error message about the shapes
931.819|5.07|not aligning because it'll be trying to
934.22|4.559|store this thousand dimensional weight
936.889|6.541|matrix into this ten dimensional thing
938.779|6.841|from your new file and it won't work so
943.43|4.86|the next step when working with Cafe is
945.62|4.649|to define the solver the solver is also
948.29|4.109|just a prototype T file you can see all
950.269|5.19|the options for it in that giant proto
952.399|4.05|file that I gave a link to but it'll
955.459|3.151|look something like this
956.449|3.57|for Alex net maybe so that will define
958.61|3.75|your learning rate and your learning
960.019|3.781|rate decay and your regularization how
962.36|4.38|often to checkpoint everything like that
963.8|6.12|but these end up being less much less
966.74|5.339|complex than than these prototypes T's
969.92|5.01|for the networks this Alex nut guy is
972.079|4.411|just maybe 14 lines although what you
974.93|3.48|will see sometimes in practice is that
976.49|4.05|if people want to have sort of complex
978.41|3.539|training pipelines where they first want
980.54|2.64|to train with the one learning rate in
981.949|2.521|certain parts of the network then they
983.18|2.909|want to train with another learning rate
984.47|3.179|certain parts of the network that you
986.089|2.971|might end up with a cascade of different
987.649|3.511|solver files and actually run them all
989.06|3.779|independently we are sort of fine-tuning
991.16|6.599|your own model in separate stages using
992.839|6.541|different solvers so once you've done
997.759|4.83|all that then you just train your model
999.38|5.49|so if you if you followed my advice and
1002.589|4.461|just use LM DB and written all these
1004.87|5.1|things then you just call this binary
1007.05|5.889|that is it that exists in cafe already
1009.97|6.57|so here you just pass it your solver and
1012.939|4.95|your prototypes T and your pre trained
1016.54|3.75|weights file if you're fine-tuning and
1017.889|4.111|it'll run maybe for a day maybe for a
1020.29|4.529|long time and just check point and save
1022.0|4.11|things to disk and you'll be happy one
1024.819|3.691|thing to point out here is that you
1026.11|4.469|specify which GPU it runs on this is
1028.51|3.929|zero indexed but you can actually run in
1030.579|4.891|CPU only mode by setting this flag to
1032.439|5.461|mine to negative one and actually
1035.47|4.589|recently some time in the last year cafe
1037.9|3.96|added data parallelism to let you split
1040.059|4.1|up mini batches across multiple GPUs in
1041.86|4.77|your system so you can actually add
1044.159|4.15|multiple GPUs on this flag and if you
1046.63|3.029|just say all then cafe will
1048.309|3.691|automatically split up mini batches
1049.659|3.961|across all the GPUs on your machine so
1052.0|3.09|that's really cool you've done multi-gpu
1053.62|5.49|training without writing a single line
1055.09|6.74|of code pretty cool cafe
1059.11|2.72|oh yeah question
1070.9|5.38|mmm yeah I think I think that'll be kind
1074.78|2.82|of so the question is how would you go
1076.28|3.269|about in doing some more complex
1077.6|3.87|initialization strategy where you maybe
1079.549|3.331|want to initialize the weights from a
1081.47|2.52|pre train model and use those same
1082.88|3.57|weights in multiple parts of your
1083.99|3.689|network and then the answer is that you
1086.45|3.51|probably can't do that with a simple
1087.679|3.421|mechanism you can kind of munge around
1089.96|3.26|the weights in python and that's
1091.1|5.939|probably how you'd go about doing it
1093.22|5.62|right so I think we've mentioned this
1097.039|4.231|before that cafe has this really great
1098.84|3.99|model zoo you can download lots of
1101.27|4.019|different types of pre train models on
1102.83|3.99|imagenet and other data sets so this
1105.289|3.421|this model zoo is really top-notch
1106.82|4.14|you've got Alex net and B Gigi you've
1108.71|4.38|got rez nets up there already pretty
1110.96|3.54|much lots and lots of really good models
1113.09|3.329|are up there so that's that's a really
1114.5|3.6|really strong part point about cafe that
1116.419|3.24|it's really easy to download someone
1118.1|5.459|else's model and run it on your data or
1119.659|5.931|fine-tune it on your data Cafe has a
1123.559|4.081|Python interface like I mentioned I
1125.59|3.79|since there's so many things to cover I
1127.64|4.14|don't think I can dive into detail here
1129.38|4.08|but as is kind of par for the course in
1131.78|3.24|cafe there's not really really great
1133.46|4.5|documentation about the Python interface
1135.02|5.279|so you need to read the code and the
1137.96|4.56|whole the the Python interface for cafe
1140.299|5.341|is mostly defined in these two in these
1142.52|4.74|two files this CPP file uses boost
1145.64|4.98|Python if you've ever used that before
1147.26|6.12|to wrap up some of the C++ classes and
1150.62|5.16|expose them to Python and then in this
1153.38|4.049|dot py file it actually attaches
1155.78|4.35|additional methods and gives you a more
1157.429|4.5|pythonic interface so if you want to
1160.13|3.96|know what kinds of methods and data
1161.929|4.081|types are available in the cafe Python
1164.09|4.44|interface your best bet is just just
1166.01|4.169|read through these two files and they're
1168.53|5.82|not too long so it's it's pretty easy to
1170.179|6.271|do yeah so the Python interface in
1174.35|4.199|general is pretty useful it lets you do
1176.45|3.599|maybe crazy weight initialization
1178.549|2.971|strategies if you need to do something
1180.049|3.63|more complex than just copy from a
1181.52|3.96|pre-trained model it also makes it
1183.679|4.051|really easy to just get a network and
1185.48|5.01|then run it forward and backward on with
1187.73|4.77|numb from numpy arrays so for example
1190.49|4.53|you can implement things like deep dream
1192.5|4.14|and class visualizations similar to that
1195.02|3.21|you did on the homework you can also do
1196.64|4.23|that quite easily using the Python
1198.23|4.079|interface on cafe where you just need to
1200.87|2.669|take data and then run it forward and
1202.309|4.381|backward through different parts of
1203.539|4.86|Network the Python interface is also
1206.69|3.9|quite nice if if you just want to
1208.399|3.72|extract features like you have some data
1210.59|2.85|set you have some pre trained model and
1212.119|3.211|you want to extract features from some
1213.44|4.65|part of the network and then maybe save
1215.33|4.74|them to disk maybe to an hdf5 file for
1218.09|5.429|some downstream processing that's quite
1220.07|5.429|easy to do with a Python interface you
1223.519|2.941|can also actually Cafe has a kind of a
1225.499|3.93|new feature where you can actually
1226.46|4.86|define layers entirely in Python but
1229.429|3.63|this is I've never done it myself but it
1231.32|3.27|seems cool it seems nice
1233.059|4.08|but the downside is that then those
1234.59|4.139|layers will be CPU only so we talked
1237.139|4.23|about communication bottlenecks between
1238.729|4.44|the CPU and the GPU that if you write
1241.369|3.8|layers in Python then every forward and
1243.169|5.82|backward pass you'll be incurring a
1245.169|5.651|overhead on that transfer although one
1248.989|3.87|nice place where Python layers could be
1250.82|3.689|useful is custom loss functions so
1252.859|6.361|that's maybe something that you could
1254.509|7.321|keep in mind so the quick overview of
1259.22|4.169|cafe cook pros and cons is that really
1261.83|3.299|from my point of view if all you want to
1263.389|3.181|do is kind of train a simple basic
1265.129|3.39|feed-forward network especially for
1266.57|3.299|classification then Cafe is really
1268.519|2.311|really easy to get things up and running
1269.869|2.73|you don't have to write any code
1270.83|3.689|yourself you just use all these
1272.599|5.07|pre-built tools and it's quite easy to
1274.519|5.431|run it has a Python interface which is
1277.669|4.68|quite nice for using a little bit more a
1279.95|3.959|little bit more complex use cases but it
1282.349|3.3|can be cumbersome when things get really
1283.909|3.27|crazy when you have these really big
1285.649|3.27|networks like ResNet or Google net
1287.179|4.23|especially with repeated module patterns
1288.919|4.291|it can be tedious and for things like
1291.409|3.12|RNA like recurrent networks where you
1293.21|4.079|want to share weights between different
1294.529|4.95|parts of the network can be kind of kind
1297.289|3.661|of kind of cumbersome in cafe it is
1299.479|4.53|possible but it's probably not the best
1300.95|4.919|thing to use for that and the other
1304.009|3.39|downside the other big downside from my
1305.869|3.48|point of view is that when you want to
1307.399|4.291|define your own type of layer in cafe
1309.349|4.65|you end up having to write C++ and CUDA
1311.69|4.02|code so that's not doesn't give you a
1313.999|3.39|very quick development cycle so it's
1315.71|4.62|kind of a lot of kind of painful to
1317.389|5.46|write new layers in cafe so that's
1320.33|7.429|that's our world whirlwind tour of cafe
1322.849|8.94|so if there's any quick questions yeah
1327.759|6.1|cross-validation and cafe I so in the
1331.789|4.71|Train Val proto txt you can actually
1333.859|3.091|define a training phase and a testing
1336.499|2.521|phase
1336.95|4.5|so generally you'll write like a train
1339.02|4.47|Bell proto txt and a deploy proto txt
1341.45|4.29|and the deploy will be used at on the
1343.49|3.689|test set and the test phase of the train
1345.74|7.77|val proto txt will be used for
1347.179|10.141|validation okay that's that's all there
1353.51|6.72|is to know about cafe so the next one is
1357.32|4.44|torch so torch is really my personal
1360.23|2.79|favorite so I have a little bit of bias
1361.76|3.09|here just to get that out in the open
1363.02|3.81|that I pretty much been using torch
1364.85|4.11|almost exclusively my own projects in
1366.83|4.83|the last year or so
1368.96|5.73|so torch is originally from NYU it's
1371.66|5.22|written in C and in Lua and it's used a
1374.69|4.29|lot at Facebook and deepmind especially
1376.88|5.88|I think also a lot of folks at Twitter
1378.98|5.46|use torch so one of the big things that
1382.76|4.53|freaks people out about torch is that
1384.44|4.77|you have to write in Lua which I had
1387.29|3.69|never learned I had never heard of or
1389.21|4.53|used before starting to work with torch
1390.98|5.699|but it actually isn't too bad that Lua
1393.74|5.43|is this highly this high level scripting
1396.679|4.201|language that is really intended for
1399.17|4.47|embedded devices so it can run very
1400.88|5.36|efficiently and it's a lot very similar
1403.64|4.74|to JavaScript in a lot of ways so
1406.24|3.49|another cool thing about Lua is that
1408.38|3.15|because it's meant to be run on embedded
1409.73|3.84|devices that you can actually do for
1411.53|3.6|loops are really fast in torch
1413.57|2.64|you know how in Python if you write a
1415.13|3.09|for loop it's going to be really slow
1416.21|4.26|that's actually totally fine to do in
1418.22|3.87|torch because it actually um uses
1420.47|5.459|just-in-time compilation to make these
1422.09|5.94|things really fast and torch is Lua is
1425.929|4.261|most similar to JavaScript in that it is
1428.03|3.45|a functional language functions are
1430.19|3.66|first class citizens and it's very
1431.48|5.97|common to pass callbacks around to
1433.85|5.579|different parts of your code Lua also is
1437.45|4.38|has this idea of prototypical
1439.429|4.621|inheritance where there's sort of one
1441.83|3.81|data structure which in Lua is a table
1444.05|4.11|which you can think of as being very
1445.64|4.77|similar to an object in JavaScript and
1448.16|3.99|you can implement things like object
1450.41|3.39|oriented programming using prototypical
1452.15|5.61|inheritance in a similar way as you
1453.8|5.19|would in JavaScript and one of the Downs
1457.76|3.51|one of the downsides is actually the
1458.99|3.78|standard library in Lua is kind of
1461.27|3.72|annoying sometimes and things like
1462.77|4.68|handling strings and whatnot can be kind
1464.99|4.14|of cumbersome and maybe most annoying is
1467.45|3.03|that it's one indexed so all of your
1469.13|3.69|intuition about for loops will
1470.48|3.54|be a little bit off for a while but
1472.82|3.68|other than that it's pretty easy to pick
1474.02|4.5|up and I gave a link here to this
1476.5|4.87|website claiming that you can learn Lua
1478.52|5.19|in 15 minutes it might be a little bit
1481.37|3.78|of an oversight be over selling it a
1483.71|3.15|little bit but I think it is pretty easy
1485.15|5.1|to pick up Lua and start writing code in
1486.86|6.93|it pretty fast so the main idea behind
1490.25|5.19|torch is this tensor class so you guys
1493.79|3.24|have been working in numpy a lot on your
1495.44|4.08|assignments and the way the assignments
1497.03|4.35|are kind of structured is that the numpy
1499.52|3.899|array gives you this really easy way to
1501.38|3.9|an emulator in whatever way you want and
1503.419|3.63|then you can use that numpy array to
1505.28|3.84|build up other abstractions like neural
1507.049|4.531|net libraries and whatnot but really the
1509.12|4.32|numpy array just lets you manipulate
1511.58|6.06|data numerically in whatever way you
1513.44|5.85|want in complete flexibility so if
1517.64|3.21|you'll recall then maybe here's a look
1519.29|3.12|here's an example of some numpy code
1520.85|3.42|that should be very familiar by now
1522.41|4.11|where we're just computing a simple
1524.27|5.73|forward pass of a two-layer rayleigh
1526.52|6.93|network so maybe black wasn't the best
1530.0|4.95|choice here but where we are we were
1533.45|3.33|doing we're computing some some
1534.95|3.84|constants we're computing some weights
1536.78|3.66|we're getting some random data and we're
1538.79|4.23|doing a matrix multiply array Lu and
1540.44|4.83|another matrix multiply so that's very
1543.02|4.38|easy to write in numpy and actually this
1545.27|4.89|has almost a one-to-one translation into
1547.4|4.769|torch tensors so now on the right this
1550.16|4.259|is the exact same code but using torch
1552.169|4.231|tensors in lua so here we're defining
1554.419|4.5|our batch size input size and all that
1556.4|4.83|we're defining our weights which are
1558.919|4.26|just torch tensors we're getting a
1561.23|4.23|random input vector we're doing a
1563.179|5.641|forward pass this is doing a matrix
1565.46|5.339|multiply of torch tensors um this c-max
1568.82|4.17|is a element-wise maximum so that's a
1570.799|4.321|ray loop and then we can compute scores
1572.99|3.689|using another matrix multiply so in
1575.12|2.88|general pretty much any kind of code
1576.679|3.601|you're used to writing in numpy is
1578.0|4.44|pretty easy pretty much has almost a 1x1
1580.28|5.79|line by line translation into using
1582.44|5.22|torch tensors instead so you also
1586.07|4.26|remember in numpy that it's really easy
1587.66|4.259|to swap and use different data types we
1590.33|4.89|talked about this ad nauseam in the last
1591.919|5.161|lecture but at least in numpy all to
1595.22|4.5|switch to maybe a 32-bit floating-point
1597.08|4.95|all you need to do is cast your data to
1599.72|3.959|this other data type and it turns out
1602.03|2.22|that that's very very easy to do in
1603.679|2.821|torches
1604.25|4.65|well that our data type is now this this
1606.5|6.03|string and then we can easily cast our
1608.9|5.01|data to another data type but here's
1612.53|3.06|where - here's the row so this next
1613.91|4.32|slide is the real reason why torch is
1615.59|4.94|infinitely better than numpy and that's
1618.23|4.86|that the GPU is just another data type
1620.53|5.71|so when you want to write when you want
1623.09|6.33|to run code on the GPU in torch you use
1626.24|4.83|this you import another package and you
1629.42|4.68|have another - another data type which
1631.07|5.04|is torch CUDA tenser and now you cast
1634.1|4.92|your tensors to this other data type and
1636.11|4.95|now they live on the GPU and running any
1639.02|4.62|kind of numerical operations on CUDA
1641.06|4.38|tensors just runs on the GPU so it's
1643.64|3.96|really really easy in torch to just
1645.44|4.41|write generic tensor scientific
1647.6|7.02|computing code to run on a GPU and be
1649.85|6.45|really fast so this like I said these
1654.62|4.23|tensors are really you should think of
1656.3|4.05|them as similar to numpy arrays and
1658.85|2.97|there's a lot of documentation on the
1660.35|3.78|different kinds of methods that you can
1661.82|4.77|work with in tensors up here on github
1664.13|4.17|this documentation isn't super complete
1666.59|7.86|but it's it's not bad so you should take
1668.3|8.22|a look at it so the next but in practice
1674.45|4.17|you end up not really using the tensors
1676.52|4.46|too much in torch instead you use this
1678.62|5.19|other package called nn4 neural networks
1680.98|4.42|so n n is this pretty thin wrapper that
1683.81|4.2|actually defines a neural network
1685.4|5.16|package just in terms of these tensor in
1688.01|4.11|terms of these tensor objects so you
1690.56|3.51|should think of this as being like a
1692.12|4.05|beefier more industrial-strength version
1694.07|5.25|of the homework codebase where you have
1696.17|4.92|this this tenth this nd array this
1699.32|3.81|tensor abstraction and then you
1701.09|5.1|implement a neural net library on top of
1703.13|5.22|it in a nice clean interface so here's
1706.19|4.95|this same two layer network using
1708.35|4.17|the NN package so we define our network
1711.14|4.44|as a sequential so it's going to be a
1712.52|4.59|stack of sequential operations it's
1715.58|3.06|gonna we're going to first have a linear
1717.11|2.76|which is a fully connected layer from
1718.64|2.88|our input dimension to our hidden
1719.87|4.5|dimension we're going to have a rail ooh
1721.52|6.87|and another linear now we can actually
1724.37|5.43|get the weights and gradients in one
1728.39|3.63|tensor for each using this gate
1729.8|4.05|parameters method so now weights will be
1732.02|3.36|a single torch tensor that will have all
1733.85|3.03|the weights of the network and grad
1735.38|2.02|weights will be a single torch tensor
1736.88|3.31|for
1737.4|4.8|all of the all of the gradients we can
1740.19|4.53|generate some random data now to do a
1742.2|4.74|forward pass we just call net the
1744.72|3.9|forward method on the on the net object
1746.94|4.65|using our data and this gives us our
1748.62|5.61|scores to compute our loss we have a
1751.59|5.16|separate criterion object that is our
1754.23|3.9|loss function so we compute our loss by
1756.75|4.2|calling the forward method of the
1758.13|5.04|criterion now we've done our forward
1760.95|5.13|pass very easy and for our backward pass
1763.17|4.65|we first set our gradients to zero call
1766.08|4.17|a backward on the loss function and then
1767.82|3.78|a backward on the network now this has
1770.25|3.3|updated all of the gradients for the
1771.6|4.56|network in the Grad params so we can
1773.55|5.13|just make a gradient step very easily so
1776.16|4.26|this would be multiplying the grad
1778.68|3.15|weights by the opposite of the learning
1780.42|3.33|rate and then adding it to the weights
1781.83|6.51|that's a simple a gradient descent
1783.75|6.15|update right that's that's all of the
1788.34|3.06|right so that would have been maybe a
1789.9|3.27|little bit more clear but we have a net
1791.4|4.56|we have weights grad weights we have our
1793.17|6.63|loss function we get Branum data run
1795.96|5.97|forward run backward make an update and
1799.8|3.54|as you might expect from looking at the
1801.93|4.26|tensor it's quite easy to make this
1803.34|5.55|thing run on GPU so to run one of these
1806.19|4.89|networks on the GPU we import a couple
1808.89|5.37|new packages cout torch and QN n which
1811.08|5.04|are CUDA versions of everything and then
1814.26|4.37|we just need to cast our network and our
1816.12|5.52|loss function to this other data type
1818.63|4.78|and we also need to cast our data and
1821.64|4.56|labels and now this whole network will
1823.41|4.74|run and train on the GPU so it's it's
1826.2|3.51|pretty easy now in what what is that
1828.15|3.0|like forty lines of code we've written a
1829.71|5.55|fully connected Network and we can train
1831.15|5.91|on the GPU but one problem here is that
1835.26|4.35|we're just using vanilla gradient
1837.06|3.93|descent which is not so great and as you
1839.61|3.15|saw in the assignments other things like
1840.99|2.72|a demand rmsprop tend to work much
1842.76|3.84|better in practice
1843.71|7.27|so to solve that torch gives us the opt
1846.6|8.34|in package so optimism port a new
1850.98|6.48|package up here and now what changes is
1854.94|4.98|that we actually need to define this
1857.46|4.26|callback function so before we were just
1859.92|4.23|calling forward and backward exclude
1861.72|4.41|explicitly ourselves instead we're going
1864.15|3.6|to define this callback function that
1866.13|3.69|will run the network forward and
1867.75|3.08|backward on data and then return the
1869.82|3.11|loss and the gray
1870.83|4.5|and now to make an update step on our
1872.93|5.16|network will actually pass this callback
1875.33|5.91|function to this atom method from the
1878.09|5.73|opt-in package so this this is maybe a
1881.24|5.58|little bit awkward but we you now we can
1883.82|4.83|use any kind of update rule using just a
1886.82|4.68|couple lines of change from what we had
1888.65|5.01|before and again this is very easy to
1891.5|7.44|add to run on a GPU by just casting
1893.66|7.95|everything to CUDA right so as we saw in
1898.94|5.22|cafe cafe sort of implements everything
1901.61|4.11|in terms of nets and layers and Cafe has
1904.16|4.56|this really hard distinction between a
1905.72|4.02|net and the layer in torch they don't we
1908.72|3.54|don't really draw this distinction
1909.74|4.38|everything is just a module so the
1912.26|7.35|entire network is a module and also each
1914.12|7.56|individual layer is a module so modules
1919.61|4.14|are just classes that are defined in lua
1921.68|5.7|that wrote that are implemented using
1923.75|4.89|the the tensor API so these modules are
1927.38|3.72|since they're written in Lua they're
1928.64|4.59|quite easy to understand so linear is
1931.1|4.53|the fully connected now is the the fully
1933.23|3.78|connected layer in Lua and this is the
1935.63|3.45|constructor you can see it's just
1937.01|6.15|setting up tensors for the weight and
1939.08|6.15|the bias and because this tensor API in
1943.16|4.71|torch lets us easily run the same code
1945.23|4.62|on GPU and CPU then all of these layers
1947.87|4.47|will just be written in terms of the
1949.85|3.5|tensor API and then easily run on both
1952.34|3.66|devices
1953.35|5.02|so these modules need to implement a
1956.0|5.16|forward and backward so for forward they
1958.37|5.22|decided to call it update output so
1961.16|4.53|here's the example of the update output
1963.59|3.9|for the fully connected layer there's
1965.69|3.24|actually a couple cases they need to
1967.49|2.79|deal with a couple different cases here
1968.93|3.24|to deal with mini-batch versus non
1970.28|5.04|mini-batch inputs but other than that
1972.17|5.25|this should be quite easy to read for
1975.32|5.4|for the backward pass there's a pair of
1977.42|5.28|methods update Grad input which receives
1980.72|3.63|the upstream gradients and computes the
1982.7|3.9|gradients with respect to the input and
1984.35|4.89|again this is just implemented in the
1986.6|5.22|tensor API so it's very easy to
1989.24|5.01|understand it's just a just the same
1991.82|4.14|type of thing you saw in homework and we
1994.25|3.69|also implement and accumulate grad
1995.96|3.03|parameters which computes the gradients
1997.94|3.51|with respect to the weights of the
1998.99|4.17|network as you saw in the constructor
2001.45|2.73|the weights and the biases are held in
2003.16|3.0|instance variable
2004.18|4.56|of this module and accumulate grad
2006.16|4.89|parameters will receive gradients from
2008.74|4.11|upstream and accumulate gradients of the
2011.05|4.71|parameters with respect to the upstream
2012.85|7.32|gradients and again this is very simple
2015.76|5.73|just using the tensor API so torch
2020.17|4.26|actually has a ton of different modules
2021.49|4.26|available the documentation here can be
2024.43|3.12|a little bit out of date but if you just
2025.75|3.15|go on github you can see all the dalawa
2027.55|4.2|files that give you all the goodies to
2028.9|4.47|play with and these actually get updated
2031.75|4.17|a lot so just to point out a couple
2033.37|5.04|these these three were just added in
2035.92|4.32|last week so torch is always adding new
2038.41|5.94|modules to that you can add to your
2040.24|5.64|networks which is pretty fun but when
2044.35|3.0|these existing modules aren't good
2045.88|4.17|enough it's actually very easy to write
2047.35|4.049|your own so because you can just
2050.05|3.48|implement these things using these
2051.399|3.721|tensor using the tensor API and just
2053.53|3.48|implement the forward and backward it's
2055.12|4.11|not much harder than implementing layers
2057.01|4.53|on the homeworks so here's just a small
2059.23|3.84|example this is a stupid module that
2061.54|4.29|just takes its input and multiplies that
2063.07|5.49|by two and you can see we implement the
2065.83|4.95|update output and the update grad input
2068.56|4.41|and now we've implemented a new layer in
2070.78|3.6|torch in just 20 lines of code and then
2072.97|4.05|that's really easy and then it's very
2074.38|4.26|easy to use in other code just import it
2077.02|3.93|and I you can add it to networks and and
2078.64|4.56|so on and the really cool thing about
2080.95|3.99|this is because this is just the tensor
2083.2|3.57|API you can do whatever kind of
2084.94|3.78|arbitrary thing you want inside of these
2086.77|4.379|forward and backward if you need to do
2088.72|5.07|for loops or complicated imperative code
2091.149|4.831|or any or maybe stochastic things for
2093.79|3.93|dropout or Bachelor normalization then
2095.98|2.94|any kind of any whatever kind of code
2097.72|2.7|you want on the forward and backward
2098.92|3.87|pass you just implement it yourself
2100.42|4.89|inside these modules so it's usually
2102.79|8.52|very very easy to implement your own new
2105.31|7.8|types of layers in torch so torch but of
2111.31|3.3|course using individual layers on their
2113.11|2.7|own isn't so useful we need to be able
2114.61|3.66|to stitch them together into larger
2115.81|4.95|networks so for this torch uses
2118.27|3.78|containers we already saw one in the
2120.76|3.78|previous example which was this
2122.05|5.07|sequential container so sequential
2124.54|4.83|container is just a stack of modules
2127.12|3.72|that all where one receives the output
2129.37|3.21|from the previous one and just goes in a
2130.84|5.04|linear stack so that's probably the most
2132.58|5.01|commonly used another one you might see
2135.88|4.32|is this peril is of the
2137.59|4.08|concat table so maybe if you have an
2140.2|3.15|input and you want to apply different
2141.67|3.72|two different modules to the same input
2143.35|4.55|then the concat table lets you do that
2145.39|4.83|and you receive the output as a list
2147.9|4.99|another one you might see is a parallel
2150.22|5.13|table if you have a list of inputs and
2152.89|4.59|you want to apply different modules to
2155.35|3.93|each element of the list then you can
2157.48|7.11|use a parallel table table for that sort
2159.28|7.38|of a construction but when things get
2164.59|4.41|really complicated so actually those
2166.66|5.16|those containers that I just told you
2169.0|4.47|should in theory be easy to be possible
2171.82|3.57|to implement just about any topology you
2173.47|3.54|want but it can be really hairy in
2175.39|4.44|practice to wire up really complicated
2177.01|4.62|things using those containers so torch
2179.83|4.56|provides another package called NN graph
2181.63|4.62|that lets you hook up contain hook up
2184.39|4.92|things in more complicated topologies
2186.25|5.34|pretty easily so here's an example if we
2189.31|4.23|have maybe if we have three inputs and
2191.59|3.21|we want to produce one output and we
2193.54|4.02|want to produce them with this pretty
2194.8|4.65|simple update rule that corresponds to
2197.56|4.23|this type of computational graph that
2199.45|4.74|we've seen many times in lecture for
2201.79|4.16|different types of problems so you could
2204.19|4.68|actually implement this just fine using
2205.95|5.65|parallel and sequential and concat table
2208.87|3.96|but it could be kind of a mess so when
2211.6|3.78|you want to do things like this it's
2212.83|5.52|very common to use n n graph instead so
2215.38|4.68|this MN graph code is quite easy so here
2218.35|4.35|this function is going to build a module
2220.06|6.44|using n n graph and then return it so
2222.7|6.45|here we import the N n graph package and
2226.5|5.8|then inside here this is a bit of funny
2229.15|5.88|syntax so this is actually not a tensor
2232.3|4.83|this is defining a symbolic variable so
2235.03|4.41|this is saying that our our tensor
2237.13|5.37|object is going to receive x y&z as
2239.44|5.79|inputs and now here we're actually doing
2242.5|5.43|symbolic operations on those inputs so
2245.23|4.58|here we're saying that a we we want to
2247.93|4.56|have a point wise addition of x and y
2249.81|5.11|store that in a we want to have point
2252.49|4.86|wise multiplication of a and Z and store
2254.92|4.98|that in B and now point wise addition of
2257.35|4.32|a and B and store that in C and again
2259.9|2.97|these are not actual tensor objects
2261.67|3.12|these are now sort of symbolic
2262.87|3.63|references that are being used to build
2264.79|5.49|up this computational graph in the back
2266.5|4.98|end and now we can actually return a
2270.28|2.67|module here
2271.48|5.19|where we say that our module will have
2272.95|6.87|inputs XY and Z and outputs C and this
2276.67|5.64|nNG module will actually give us an
2279.82|4.68|object conforming to the module API that
2282.31|4.049|implements this computation so then
2284.5|4.56|after we build the module we can
2286.359|4.981|construct concrete torch tensors and
2289.06|8.61|then feed them into the module that will
2291.34|8.46|actually compute the function so torch
2297.67|3.99|actually is quite good at pre train
2299.8|3.93|models there's a package called load
2301.66|4.23|Cafe that lets you load up many
2303.73|4.59|different types of pre train models from
2305.89|5.37|cafe and it'll convert them into their
2308.32|5.07|torch equivalents so you can load up the
2311.26|4.109|cafe proto txt and the cafe model file
2313.39|5.07|and it'll turn into a giant stack of
2315.369|4.411|sequential layers load cafe is not super
2318.46|4.17|general though it only works for certain
2319.78|4.74|types of networks but in particular load
2322.63|4.32|cafe will let you load up Aleks net and
2324.52|5.04|cafe net and vgg so they're probably the
2326.95|4.62|some of the most commonly used there are
2329.56|3.87|also a couple different implementations
2331.57|3.66|that let you load up Google net into
2333.43|3.56|into torch to let you load up
2335.23|4.44|pre-trained Google net models into torch
2336.99|4.42|and actually very recently Facebook went
2339.67|4.439|ahead and re implemented the residual
2341.41|4.98|networks straight up in torch and they
2344.109|5.551|released pre-trained models for that so
2346.39|5.01|between Alex net cafe net vgg Google net
2349.66|3.39|and ResNet I think that's probably
2351.4|4.76|everything you need all the pre train
2353.05|5.67|models that most people want to use
2356.16|4.54|another point is that because torches
2358.72|3.3|using Lua we can't use pip to install
2360.7|3.45|packages and there's another very
2362.02|3.78|similar idea called lure ox lets you
2364.15|2.73|easily install new packages and update
2365.8|4.86|packages
2366.88|5.7|that's quite very very easy to use and
2370.66|3.39|this is kind of just a list of some
2372.58|3.93|packages that I find very useful in
2374.05|5.43|torch so there are COO DNN bindings you
2376.51|5.88|can read and write to hdf5 files you can
2379.48|4.68|read and write json there's this funny
2382.39|3.15|one from Twitter called Auto grab that
2384.16|3.27|is a little bit like Theano
2385.54|3.78|which we'll talk about in a bit but I
2387.43|4.26|haven't used it but it's kind of cool to
2389.32|4.77|look at and actually Facebook has a
2391.69|5.429|pretty useful library for torch as well
2394.09|5.37|that implements fft convolutions and
2397.119|5.941|also implements data parallel and model
2399.46|5.22|parallelism you eat so that's pretty a
2403.06|4.57|pretty nice thing to have
2404.68|4.6|so a very typical workflow in torch is
2407.63|3.09|that you'll have some pre-processing
2409.28|3.24|script often in Python
2410.72|3.44|that'll pre process your data and dump
2412.52|4.89|it on to some nice format and disk
2414.16|5.29|usually hdf5 for big things and json for
2417.41|4.17|little things then you will I'll
2419.45|4.08|typically write a train you WA that'll
2421.58|4.44|read from the hdf5 and train the model
2423.53|4.95|and optimize the model and save
2426.02|4.53|checkpoints to disk and then usually
2428.48|3.45|I'll have some evaluate script that
2430.55|4.59|loads up the train model and then does
2431.93|4.83|it for something useful so a case study
2435.14|3.72|for this type of workflow is this
2436.76|4.92|project I put up on github like a week
2438.86|5.04|ago that implements character level
2441.68|3.9|language models in torch so here there's
2443.9|4.32|a pre-processing script that converts
2445.58|5.43|text files into hdf5 files there's a
2448.22|4.65|training script that loads from hdf5 and
2451.01|3.45|trains these recurrent networks and then
2452.87|2.58|there's a sampling script that loads up
2454.46|3.96|the checkpoints and lets you generate
2455.45|7.29|text so that's that's kind of like my
2458.42|6.06|typical work flow in torch so the quick
2462.74|3.36|pros and cons I would say about torch
2464.48|2.91|are that it's Lua this is a big turn-off
2466.1|3.63|for people but I don't think it's
2467.39|4.59|actually that big a deal it's definitely
2469.73|3.48|less plug-and-play than cafe so you'll
2471.98|4.05|end up writing a lot of your own code
2473.21|4.14|typically which maybe is a little bit
2476.03|3.99|more overhead but also gives you a lot
2477.35|4.28|more flexibility it has a lot of modular
2480.02|4.53|pieces that are easy to plug and play
2481.63|4.36|and the let the standard library because
2484.55|2.85|it's all written in Lua is quite easy to
2485.99|3.36|read and quite easy to understand
2487.4|4.92|there's a lot of pre trained models
2489.35|4.23|which is quite nice but unfortunately
2492.32|3.81|it's it's a little bit awkward to use
2493.58|4.2|for recurrent networks in general so
2496.13|3.15|when you want to have one when you want
2497.78|2.97|to have multiple modules that share
2499.28|3.21|weights with each other you can actually
2500.75|3.33|do this in torch but it's it's kind of
2502.49|4.71|brittle and you can run into subtle bugs
2504.08|4.47|there so that's that's probably the
2507.2|5.16|biggest caveat is that recurrent
2508.55|7.07|networks can be tricky any any quick
2512.36|3.26|questions about torch yeah
2519.579|4.95|accepting our resolution that layer we
2522.489|5.191|reduced to have four layers in the ninth
2524.529|7.411|version the fast one you just uncheck
2527.68|5.789|all so do you say okay yeah yeah you
2531.94|3.149|definitely still gained benefit from
2533.469|4.08|writing more efficient code but it's not
2535.089|4.89|oh so the question was about how how bad
2537.549|4.2|are four loops in Lua and Python is
2539.979|3.451|interpreted right so that that's really
2541.749|3.21|why four loops are really bad in Python
2543.43|2.7|because it's interpreted and every four
2544.959|2.37|loop is actually doing quite a lot of
2546.13|3.599|memory allocation and other things
2547.329|5.101|behind the scenes but if you've ever
2549.729|4.38|used JavaScript then loops in JavaScript
2552.43|3.75|tend to be pretty fast because the
2554.109|4.41|runtime actually Jets the compiles the
2556.18|4.25|code on the fly down to native code so
2558.519|4.35|loops in JavaScript are really fast and
2560.43|4.179|Lua and Lua actually has a similar
2562.869|4.59|mechanism where it'll sort of
2564.609|4.74|automatically and magically compile the
2567.459|3.87|code for you into native code so your
2569.349|4.23|loops can be really fast but definitely
2571.329|8.04|writing custom vectorized code still can
2573.579|8.04|give you a lot of speed up all right so
2579.369|3.69|we've got now maybe half an hour lap to
2581.619|4.71|cover two more frameworks so we're
2583.059|6.331|running out of time so next up is Theon
2586.329|5.851|Oh Sophie ah no is from yoshua bengio
2589.39|5.189|group at university of montreal and it's
2592.18|4.139|really all about computational graphs so
2594.579|3.811|we saw a little bit in NN graph from
2596.319|3.69|torch that computational graphs are this
2598.39|3.929|pretty nice way to stitch together big
2600.009|4.11|complicated architectures and Fionna
2602.319|3.65|really takes this idea of computational
2604.119|4.59|graphs and runs with it to the extreme
2605.969|4.81|and it also has some high-level
2608.709|4.89|libraries Kerris and lasagna that we'll
2610.779|4.381|touch on as well so here's the same
2613.599|4.23|computational graph we saw in the
2615.16|3.689|context of n n graph before and we can
2617.829|4.2|actually walk through an implementation
2618.849|5.281|of this into in Theano so you can see
2622.029|5.371|that in here we're importing Theano and
2624.13|6.359|the theano tensor object and now here
2627.4|4.889|we're defining x y&z as symbolic as
2630.489|3.6|symbolic variables this is actually very
2632.289|4.23|similar to the N in graph example we saw
2634.089|4.321|just a few slides ago so that these are
2636.519|4.02|actually not numpy arrays these are sort
2638.41|5.76|of symbolic objects in the in the
2640.539|6.99|computation graph then we can actually
2644.17|6.389|compute to these outputs symbolically so
2647.529|5.25|x y&z are these symbolic things and we
2650.559|2.731|can compute a B and C just using these
2652.779|2.791|overload
2653.29|4.64|operators and that'll be building up
2655.57|5.01|this computational graph in the backend
2657.93|4.54|then once we built up our computational
2660.58|3.63|graph we actually will want to be able
2662.47|4.89|to run certain parts of it on real data
2664.21|5.76|so we call this the anode function thing
2667.36|4.89|so this is saying that we want to take
2669.97|5.49|our function we'll take inputs XY and Z
2672.25|5.04|and it'll produce outputs C and this
2675.46|3.65|will return an actual Python function
2677.29|3.93|that we can evaluate on real data and
2679.11|3.58|I'd like to point out that this is
2681.22|3.36|really where all the magic in Theano is
2682.69|4.35|happening that when you call to function
2684.58|4.5|it can be doing crazy crazy things it
2687.04|3.95|can simplify your computational graph to
2689.08|4.05|make it more efficient it can actually
2690.99|3.73|symbolically divide derived gradients
2693.13|4.2|and other things and it can actually
2694.72|3.9|generate native code so when you call
2697.33|2.97|function it connect it actually
2698.62|4.35|sometimes compiles code on the fly to
2700.3|4.56|run officially on the GPU so all the
2702.97|3.42|magic in Theano is really coming from
2704.86|3.42|this from this little innocent-looking
2706.39|5.43|statement in Python but there's a lot
2708.28|5.25|going on under the hood here and now
2711.82|3.93|once we've gotten this magic function
2713.53|4.2|through all this crazy stuff then we can
2715.75|5.49|just run it on actual numpy arrays so
2717.73|5.61|here we're instantiating xx YY and Z Z
2721.24|4.71|as actually as actual numpy arrays and
2723.34|5.04|then we can just evaluate our function
2725.95|5.49|and pass in these actual numpy arrays to
2728.38|5.04|get the values out and this is doing the
2731.44|4.74|same thing as we were doing these
2733.42|4.56|computations explicitly in python except
2736.18|3.21|that the Theano version could be much
2737.98|3.39|more efficient due to all the magic
2739.39|3.42|under the hood and the fee on o virgin
2741.37|4.56|actually could be running on the GPU if
2742.81|4.53|you have that configured but
2745.93|2.88|unfortunately we don't really care about
2747.34|4.23|computing things like this we want to do
2748.81|5.78|neural nets so here's an example of a
2751.57|5.97|simple two-layer ray lunette in theano
2754.59|5.68|so the idea is the same that we're going
2757.54|6.36|to declare our inputs but now instead of
2760.27|6.33|just x y&z we have our inputs in X our
2763.9|5.94|labels in Y which are a vector and our
2766.6|4.41|two weight matrices W 1 and W 2 so we're
2769.84|3.63|just sort of setting up these symbolic
2771.01|5.19|variables that will be elements in our
2773.47|4.98|computational graph now for our forward
2776.2|4.38|pass we it looks kind of like known pi
2778.45|3.6|but it's not these are operations on
2780.58|3.57|these symbolic objects that are building
2782.05|4.05|up the graph in the backend so here
2784.15|2.54|we're computing activations with this
2786.1|2.36|dot
2786.69|4.2|that is matrix-multiply between these
2788.46|4.32|symbolic objects we're doing a rail ooh
2790.89|4.04|using this this library function and
2792.78|4.289|we're doing another matrix multiply and
2794.93|4.27|then we can actually compute the loss
2797.069|3.991|the probabilities and the loss using a
2799.2|3.18|couple other library functions and again
2801.06|2.85|these are all operations on these
2802.38|5.13|symbolic objects that are building up
2803.91|6.09|the computational graph so then we can
2807.51|4.14|just compile this function so our
2810.0|3.839|function is going to take our data our
2811.65|4.439|labels and our two weight vector and our
2813.839|3.871|two weight matrices as inputs and as
2816.089|4.111|outputs that will return the loss in a
2817.71|5.73|scalar and our classification scores in
2820.2|4.889|a vector and now we can run this thing
2823.44|3.12|on real data just like we saw on the
2825.089|3.301|previous slide where we can instantiate
2826.56|6.029|some actual numpy arrays and then pass
2828.39|6.179|them into the function so this is great
2832.589|2.971|but this is only the forward pass we
2834.569|4.591|actually need to be able to train this
2835.56|5.07|network and compute gradients so here we
2839.16|4.35|just need to add a couple lines of code
2840.63|5.31|to do that so this is the same as before
2843.51|4.38|we're defining our symbolic variables
2845.94|4.11|for our inputs and our weights and so
2847.89|4.11|forth and we're combining running the
2850.05|3.96|same forward passes before to compute
2852.0|4.619|the loss to the computer loss
2854.01|4.44|symbolically now the difference is that
2856.619|5.791|we actually can do symbolic
2858.45|6.21|differentiation here so this DW 1 + DW 2
2862.41|4.32|we're telling Theano that we want those
2864.66|4.11|to be the gradient of the gradients of
2866.73|5.4|the loss with respect to those other
2868.77|5.43|symbolic variables W 1 and W 2 so this
2872.13|3.81|is really cool Theano just lets you take
2874.2|3.419|arbitrary gradients of any part of the
2875.94|3.36|graph with respect to any other part of
2877.619|3.811|the graph and now introduce introduce
2879.3|4.44|those as new symbolic variables in the
2881.43|5.31|graph so that you can really go crazy
2883.74|4.5|with that but here in this case we're
2886.74|3.69|just going to return those gradients as
2888.24|4.53|outputs so now we're going to compile a
2890.43|5.7|new function that again is going to take
2892.77|5.22|our inputs our input our input pixels x
2896.13|3.989|and our labels Y along with the two
2897.99|4.02|weight matrices and now it's going to
2900.119|3.21|return our loss the classification
2902.01|4.44|scores and then also these two
2903.329|4.951|ingredients so now we can actually use
2906.45|4.47|this set up to train a very simple
2908.28|4.289|neural network so we can actually just
2910.92|3.449|use gradient descent implement gradient
2912.569|4.321|descent in just a couple lines using
2914.369|6.031|using this this using this computational
2916.89|5.669|graph so here we're instantiating actual
2920.4|4.169|pi arrays for the data set and the
2922.559|4.8|vectors and some random weight matrices
2924.569|5.161|as again actual numpy arrays and now
2927.359|4.801|every time we make this call to F then
2929.73|4.2|we get back numpy arrays containing the
2932.16|3.599|loss and the scores and the gradients so
2933.93|3.3|now that we have the gradients we can
2935.759|3.451|just make a simple gradient update on
2937.23|4.41|our weights and then run this in a loop
2939.21|4.049|to train our network but there's
2941.64|2.969|actually a big a big problem with this
2943.259|8.431|especially if you're running on a GPU
2944.609|9.841|can and what can anyone spot it totally
2951.69|4.169|lost so the problem is that this is
2954.45|3.419|actually incurring a lot of over
2955.859|5.371|communication overhead between the CPU
2957.869|5.13|and the GPU because every time we call
2961.23|3.99|this F function and we get back these
2962.999|4.381|gradients that's copying the gradients
2965.22|4.589|from the GPU back to the CPU and that
2967.38|4.679|can be an expensive operation and now
2969.809|5.401|we're actually making our gradient step
2972.059|4.381|this is CPU computation in numpy so it
2975.21|3.21|would be really nice if we can make
2976.44|7.2|those gradient updates to our parameters
2978.42|6.929|actually directly on the GPU and the way
2983.64|3.24|that we do that in Theano is this with
2985.349|5.19|with this cool thing called a shared
2986.88|5.609|variable so a shared variable is another
2990.539|3.3|a part of the network that actually is a
2992.489|2.941|value that lives inside the
2993.839|4.5|computational graph and actually
2995.43|4.379|persists from call to call so here this
2998.339|4.381|is this is actually quite similar to
2999.809|4.921|before that now we're defining that our
3002.72|4.17|same symbolic variables x and y for the
3004.73|4.019|data and the labels and now we're
3006.89|4.169|defining a couple of these new funky
3008.749|4.471|things funky shared variables for our
3011.059|3.96|two weight matrices and the N were
3013.22|5.549|initializing these weight matrices with
3015.019|5.1|numpy arrays and now this is the same as
3018.769|4.05|this is the exact same code as before
3020.119|4.291|we're computing the forward pass using
3022.819|4.95|these library functions all symbolically
3024.41|5.099|then we're computing the gradients but
3027.769|3.6|now the difference is in how we define
3029.509|5.221|our function so now this compiled
3031.369|4.801|function only receives does not receive
3034.73|3.0|the weights as inputs because those
3036.17|3.839|actually live inside the computational
3037.73|5.369|graph instead we just received the data
3040.009|4.951|and the data and the labels and now we
3043.099|3.48|are going to output the loss rather than
3044.96|4.079|outputting the gradients explicitly and
3046.579|4.17|instead we actually provide these update
3049.039|2.55|rules that should be run every time the
3050.749|3.511|function is called
3051.589|4.351|so these update rules notice our
3054.26|3.78|little functions that operate on these
3055.94|3.39|symbolic variables so this is just
3058.04|3.54|saying that we should make these
3059.33|4.74|gradient descent steps to update W 1 and
3061.58|6.15|W 2 every time we run this computational
3064.07|6.12|graph so right so we clean through this
3067.73|3.99|update and now to train this network all
3070.19|3.48|we need to do is call this function
3071.72|3.48|repeatedly and every time we call the
3073.67|4.08|function those we will make a gradient
3075.2|3.87|step on the weights so we can just train
3077.75|4.05|this network by just calling this thing
3079.07|3.72|repeatedly and in practice when you're
3081.8|1.68|make when you're doing this kind of
3082.79|2.43|thing in Theano
3083.48|3.0|you'll often define a training function
3085.22|2.88|that you'll call that'll update the
3086.48|3.54|weights and then also an evaluate
3088.1|3.66|function that'll just output the scores
3090.02|3.3|and not make any updates so you can
3091.76|3.24|actually have multiple of these compiled
3093.32|12.51|functions that evaluate different parts
3095.0|12.33|of the same graph yeah yeah yes the
3105.83|3.9|question is how we compute gradients and
3107.33|4.14|it actually does it symbolically sort of
3109.73|3.87|parsing out the s well it's not actually
3111.47|3.75|parsing out the ast because every time
3113.6|3.0|you make these calls it's a sort of
3115.22|3.45|building up this computational graph
3116.6|4.02|object and then you can compute
3118.67|7.89|gradients by just adding nodes onto the
3120.62|7.11|computational graph object yeah yeah so
3126.56|2.79|it needs to know for every of these
3127.73|2.91|basic operators it knows what the
3129.35|3.09|derivative are what the derivative is
3130.64|3.15|and it's still the Nayla normal type of
3132.44|3.66|back propagation that you'll see in
3133.79|5.19|other frameworks but some of it but um
3136.1|4.59|the pitch with V on o is that it works
3138.98|3.09|on these very very low-level basic
3140.69|3.51|operations like these element wise
3142.07|3.99|things and matrix multiplies and then it
3144.2|3.48|is hoping that it can compile efficient
3146.06|4.95|code that combine those and simplify it
3147.68|4.5|symbolically and that I'm not sure how
3151.01|4.38|well it works but that's at least what
3152.18|4.89|they claimed to do so there's a lot of a
3155.39|3.03|lot of other advanced things that you
3157.07|3.51|can do in Theano that we just don't have
3158.42|3.84|time to talk about so you can actually
3160.58|3.39|include conditionals directly inside
3162.26|4.59|your computational graph using these
3163.97|4.41|if-else and switch commands you can
3166.85|3.57|actually include loops inside your
3168.38|3.84|computational graph using this this
3170.42|5.31|funny scan function that I don't really
3172.22|5.16|understand but theoretically it lets you
3175.73|4.71|implement recurrent networks quite
3177.38|4.44|easily because you can imagine a for to
3180.44|3.15|implement a recurrent Network in one of
3181.82|3.36|these computational graphs all you're
3183.59|4.06|doing is passing the same weight matrix
3185.18|4.15|into multiple nodes and scan
3187.65|3.45|actually lets you sort of do that in a
3189.33|4.68|loop and have the loop be part of an
3191.1|4.35|explicit part of the graph and we can
3194.01|2.55|actually go crazy with derivatives we
3195.45|3.21|can compute derivatives with respect
3196.56|3.81|with out of any part of the graph with
3198.66|2.73|respect to any other part we can also
3200.37|2.58|compute jacobians
3201.39|3.54|by computing derivatives of derivatives
3202.95|4.32|we can use l and r operators to
3204.93|4.32|efficiently do make um big matrix matrix
3207.27|2.58|vector multiplies of vectors and
3209.25|2.03|jacobians
3209.85|3.54|so you can do about a pretty cool
3211.28|4.75|derivative type stuff in Theano that's
3213.39|4.14|maybe tough and other frameworks and it
3216.03|3.48|also has some support for sparse
3217.53|4.52|matrices it tries to optimize your code
3219.51|5.0|on the fly and do some other cool things
3222.05|4.72|Theano does have multi GPU support
3224.51|5.5|there's this package that I have not
3226.77|4.92|used but that claims that you can get
3230.01|3.03|data parallelism so distribute a
3231.69|3.54|mini-batch split it up over multiple
3233.04|3.93|GPUs and there's experimental support
3235.23|3.27|for model parallelism where this
3236.97|3.72|computational graph will be divided
3238.5|3.93|among the different devices but the
3240.69|5.31|documentation says it's experimental so
3242.43|6.12|it's probably really experimental so a
3246.0|4.98|lot of so you saw in when working with
3248.55|4.14|fian oh that the api is a little bit low
3250.98|2.94|level and we need to sort of implement
3252.69|1.68|the update rules and everything
3253.92|2.7|ourselves
3254.37|3.36|so lasagna is this high level wrapper
3256.62|3.36|around Theano
3257.73|5.01|that sort of abstract away some of those
3259.98|5.43|details for you so again we're sort of
3262.74|4.83|defining symbolic matrices and lasagna
3265.41|3.48|now has these layer functions that will
3267.57|3.87|automatically set up the shared
3268.89|3.78|variables and that sort of thing we can
3271.44|3.63|compute the probability in the loss
3272.67|5.79|using these convenient things from the
3275.07|4.86|lasagna library and lasagna can actually
3278.46|3.54|write these update rules for us to
3279.93|4.23|implement Adam and Nesterov momentum and
3282.0|5.22|other fancy things and now when we
3284.16|4.35|compile our function we actually just
3287.22|3.24|pass in these update rules that were
3288.51|3.84|already written for us bye-bye lasagna
3290.46|4.23|and all of the weight objects were
3292.35|5.07|taking care of us taken care of for us
3294.69|3.99|by lasagna as well and then at the end
3297.42|2.91|of the day we just end up with one of
3298.68|4.68|these compiled piano functions and we
3300.33|4.77|use it the same way as before there's
3303.36|3.12|another live there's another wrapper for
3305.1|5.34|Theon oh that's pretty popular called
3306.48|6.39|Kerris which is a little bit is even
3310.44|4.8|more high-level so here we're having
3312.87|4.44|making a sequential container and we're
3315.24|4.52|adding a stack of layers to it so this
3317.31|4.79|is kind of like torch and
3319.76|4.17|we're having this making this SGD object
3322.1|4.56|that is going to actually do updates for
3323.93|5.01|us and now we can train our network by
3326.66|4.41|just using the model dot fit method so
3328.94|5.39|this is super high level and you can't
3331.07|5.52|even tell that using theano and in fact
3334.33|3.7|Kerris will actually use tensorflow as a
3336.59|3.39|back-end as well so you don't have to
3338.03|3.329|use Theano with it
3339.98|3.93|but there's actually one big problem
3341.359|3.691|with this piece of code and I don't know
3343.91|3.53|if you've if you're experienced with
3345.05|5.85|Yano but this code actually crashes and
3347.44|5.919|it crashes in a really bad way this is
3350.9|4.62|the error message so we get this giant
3353.359|3.901|stack trace none of which is through any
3355.52|3.48|of the code that we wrote and we get
3357.26|4.8|this giant value error that doesn't make
3359.0|4.77|any sense to me so I'm not really an
3362.06|3.9|expert in Theano so this was really
3363.77|3.96|confusing to me so we wrote this kind of
3365.96|3.3|simple looking code and care us but
3367.73|3.66|because it's using theano as a back-end
3369.26|4.26|it crapped out and gave us this really
3371.39|3.75|confusing error message so that's I
3373.52|3.21|think one of the common pain points and
3375.14|3.54|failure cases with anything that uses
3376.73|4.35|theano as a back-end that debugging can
3378.68|4.92|be kind of hard so like any good
3381.08|5.4|developer I googled the error and I
3383.6|5.04|found out that I found out that I was
3386.48|3.84|encoding the y-variable wrong and I was
3388.64|3.87|supposed to use this other this other
3390.32|4.35|function to convert my Y variable and
3392.51|3.359|that made the problem go away but that
3394.67|2.97|was not obvious from the error message
3395.869|5.581|so that's something to be worried about
3397.64|5.58|when you're using theano Yano actually
3401.45|4.05|has pre trained models so we talked
3403.22|4.08|about lasagna lasagna actually has a
3405.5|3.57|pretty good model zoo of a lot of
3407.3|2.52|different popular model architectures
3409.07|3.48|that you might want
3409.82|4.47|so in lasagna you can use alex net and
3412.55|3.42|google net and bgg i don't think they
3414.29|4.02|have ResNet yet but they have quite a
3415.97|3.93|lot of useful things there and there are
3418.31|3.6|a couple other packages I found that
3419.9|4.32|davi that don't really seem as good
3421.91|3.84|except I mean this one's clearly awesome
3424.22|4.08|because it was a cs2 3 one end project
3425.75|4.02|from last year but if you're going to
3428.3|6.21|pick one I think probably the lasagna
3429.77|6.27|models do is really good so from my one
3434.51|3.84|day experience of playing with fian oh
3436.04|4.02|the pros and cons that I could see or
3438.35|3.45|that it's it's Python and numpy so
3440.06|2.88|that's great this computational graph
3441.8|2.97|seems like really powerful idea
3442.94|2.94|especially around computing gradients
3444.77|4.23|symbolically and all these cool
3445.88|4.5|optimizations it especially with RN ends
3449.0|4.14|I think could be much easier to
3450.38|4.77|implement using this computational graph
3453.14|4.23|rafi ah know is kind of ugly and gross
3455.15|3.84|but especially lasagna looks pretty good
3457.37|4.29|to me and sort of takes away some of the
3458.99|6.3|pain the errormsgs can be pretty painful
3461.66|5.25|as we saw and big models from what I've
3465.29|4.08|heard can have really long compile times
3466.91|4.8|so that that when we're compiling that
3469.37|3.51|function on the fly for all these simple
3471.71|3.09|examples that pretty much runs
3472.88|3.39|instantaneously but when you're doing
3474.8|3.33|big complicated things like neural
3476.27|3.24|Turing machines I've heard stories that
3478.13|3.9|that could actually take maybe half an
3479.51|3.99|hour to compile so that's that's not
3482.03|4.2|good and that's not good for iterating
3483.5|4.62|quickly on your models and another sort
3486.23|4.26|of pain point is that the API is much
3488.12|3.87|fatter than torch that it's doing all
3490.49|3.0|this complicated stuff in the background
3491.99|3.03|so it's kind of hard to understand and
3493.49|4.05|debug that's actually happening to your
3495.02|4.59|code and then pre-trained models are
3497.54|5.6|maybe not quite as good as cafe or torch
3499.61|6.27|but it looks like lasagna is pretty good
3503.14|7.15|okay so we've got 15 minutes now to talk
3505.88|5.79|about tensorflow although first if
3510.29|6.44|there's any questions about fian oh I
3511.67|8.52|can try okay guess not
3516.73|5.74|so tensorflow tensorflow is from google
3520.19|4.89|it's really cool and shiny and new and
3522.47|4.38|everyone's excited about it and it's
3525.08|3.54|actually very similar to Fionna in a lot
3526.85|3.87|of ways that they're really taking this
3528.62|3.78|idea of a computational graph and sort
3530.72|4.14|of building on that for everything so
3532.4|4.77|tensorflow and Theano actually very very
3534.86|3.9|closely linked in my mind and that sort
3537.17|4.44|of wide Kerris can get away with using
3538.76|4.59|either one as a back-end and also kind
3541.61|2.43|of a one maybe point to make about
3543.35|2.46|tensorflow
3544.04|3.03|is that it's sort of the first one of
3545.81|4.19|these frameworks that was designed from
3547.07|5.13|the ground up by professional engineers
3550.0|3.67|so a lot of these other frameworks sort
3552.2|3.06|of spun out of academic research labs
3553.67|3.36|and they're really great and they let
3555.26|3.8|you do things really well but they were
3557.03|5.4|sort of maintained by grad students
3559.06|5.14|especially so torch especially is
3562.43|3.6|maintained by some engineers at Twitter
3564.2|3.93|and Facebook now but it was originally
3566.03|3.66|an academic project and for all of these
3568.13|3.5|I think tensorflow was the first one
3569.69|3.45|that was from the ground up from an echo
3571.63|3.94|stree Elise
3573.14|3.93|so maybe theoretically that could lead
3575.57|4.76|to better code quality or test coverage
3577.07|5.48|or something I don't know I'm not sure
3580.33|3.72|once they're closed for the super-super
3582.55|3.45|debts we're asking on this code is
3584.05|4.08|pretty able so betters the downside like
3586.0|10.86|dig into tens of those journals it's a
3588.13|10.17|lot scarier yeah so I didn't I didn't
3596.86|5.73|try to look into the codebase I thought
3598.3|6.39|they both seemed pretty scary so here's
3602.59|3.45|so here's our favorite um to layer a
3604.69|2.46|lunette we're going to we did it and all
3606.04|3.54|the other frameworks let's do it in
3607.15|4.95|tensor flow so this is actually really
3609.58|5.34|similar to Theano so you can see that
3612.1|3.3|we're importing tensor flow and in
3614.92|2.37|theano
3615.4|4.08|remember we had these matrix and vector
3617.29|3.72|symbolic variables in tensor flow
3619.48|4.05|they're called placeholders but it's the
3621.01|5.34|same idea these are just creating input
3623.53|5.4|nodes in our computational graph we're
3626.35|4.41|also going to define weight matrices in
3628.93|3.15|Theano we have these shared things that
3630.76|3.57|lived inside the computational graph
3632.08|5.85|same idea and tensor flow except they're
3634.33|5.49|called variables we just like just like
3637.93|3.9|in Theano we computed our forward pass
3639.82|4.62|using these library methods that operate
3641.83|4.08|operate symbolically on these on these
3644.44|3.84|things and build up a computational
3645.91|3.66|graph so that lets us easily compute the
3648.28|3.9|probabilities and the loss and
3649.57|4.35|everything like that symbolically this
3652.18|3.96|part actually I think to me looks more
3653.92|3.99|like chaos or rather looks a little bit
3656.14|4.77|more like Kerris or lasagna than Rafi ah
3657.91|4.38|no but we're using this gradient descent
3660.91|3.66|optimizer and we're telling it to
3662.29|5.31|minimize the loss so here we're not
3664.57|4.92|explicitly spitting out gradients and
3667.6|3.78|we're not explicitly writing out writing
3669.49|3.93|update rules we're instead using this
3671.38|3.84|pre-built thing that just sort of adds
3673.42|5.85|whatever it needs to into the graph in
3675.22|5.7|order to minimize that loss and now just
3679.27|3.99|like in Theano work we can actually
3680.92|5.28|instantiate using actual numpy arrays
3683.26|4.38|are some some small data set and then we
3686.2|3.84|can run in a loop
3687.64|4.89|so in tensor flow when you actually want
3690.04|5.16|to run your code you need to use you
3692.53|4.35|need to wrap it in this session code I
3695.2|3.96|don't really understand what's doing but
3696.88|3.9|it's you got to do it although actually
3699.16|3.24|what it's doing although actually what
3700.78|2.94|it's doing is that all this stuff is
3702.4|3.0|sort of setting up your computational
3703.72|3.45|graph and then the session is actually
3705.4|5.66|doing whatever optimization it needs to
3707.17|3.89|to actually allow you to run it yeah
3711.49|6.54|oh yeah so if your so the question is
3715.96|3.84|what is one hot so if you remember in
3718.03|4.05|your assignments when you did like a
3719.8|4.35|softmax loss function but Y was always
3722.08|4.35|an integer telling you which thing you
3724.15|5.63|wanted but in some of these frameworks
3726.43|5.76|instead of an integer it should be a
3729.78|3.64|vector where everything is zero except
3732.19|3.24|for the one that was the correct class
3733.42|5.91|so that was actually the bug that
3735.43|5.22|tripped me up on on chaos back there was
3739.33|3.66|the difference between one hot and not
3740.65|7.65|one hot and it turns out tensorflow
3742.99|6.48|wants one hot whatever right so then
3748.3|4.92|when we actually want to train this
3749.47|4.2|network then we call take-in so in in
3753.22|1.98|theano
3753.67|3.06|remember we actually compiled this
3755.2|3.12|function object and then call the
3756.73|3.69|function over and over again the
3758.32|4.02|equivalent in tensorflow is that we use
3760.42|3.9|call the run method on the session
3762.34|4.32|object and we tell it watch which
3764.32|4.23|outputs we want it to compute so here
3766.66|3.87|we're telling it that we want to compute
3768.55|3.96|the trained step output and the loss
3770.53|4.35|output and we're going to feed it these
3772.51|3.66|numpy arrays into these inputs so this
3774.88|2.79|is kind of the same idea as Theano
3776.17|3.03|except we're just calling the run method
3777.67|4.71|rather than explicitly compiling
3779.2|5.22|compiling a function and in the process
3782.38|3.51|of evaluating this train step object
3784.42|3.99|it'll actually make a gradient descent
3785.89|4.229|on the weights so then we just run this
3788.41|6.24|thing in the loop and it'll the loss
3790.119|5.701|goes down and everything is beautiful so
3794.65|3.63|one of the really cool things about
3795.82|3.9|tensor flow is this thing called tensor
3798.28|2.76|board that lets you easily easily
3799.72|4.38|visualize what's going on in your
3801.04|5.37|network so here it is pretty much the
3804.1|3.42|same code that we had before except
3806.41|3.209|we've added these three little lines
3807.52|5.52|hopefully you can see it if not you'll
3809.619|5.431|have to trust me so here we're computing
3813.04|4.11|a scalar summary of the loss and that's
3815.05|3.99|giving us a new symbolic variable called
3817.15|3.84|loss summary and we're computing a
3819.04|4.62|histogram summary of the weight matrices
3820.99|6.44|w1 and w2 and those are getting us new
3823.66|6.3|symbolic variables w1 hist and w2 hist
3827.43|4.24|now we're getting another symbolic
3829.96|3.21|variable called merged that kind of
3831.67|3.38|merges all those summaries together
3833.17|4.56|using some magic I don't understand and
3835.05|4.48|we're getting this summary writer object
3837.73|4.5|that we can use to actually dump out
3839.53|4.079|those summaries to disk and now in our
3842.23|2.0|loop when we're actually running the
3843.609|2.841|network
3844.23|3.629|then we tell it to evaluate to evaluate
3846.45|3.51|the training step and the loss like
3847.859|4.351|before and also this merge summary
3849.96|3.84|object so in the process of evaluating
3852.21|2.85|this merge summary object it will
3853.8|3.03|compute gradient it will compute
3855.06|4.83|histograms of the weights and dump those
3856.83|4.71|summaries to disk and then we tell our
3859.89|2.67|writer to actually add the summary so I
3861.54|4.05|guess that's where the writing to disk
3862.56|4.47|happens so once you run this thing then
3865.59|2.55|you get the one while this thing is
3867.03|2.64|running it's sort of constantly
3868.14|3.03|streaming all this information about
3869.67|4.68|what's going on in your network to disk
3871.17|4.439|and then you just start up this this web
3874.35|3.21|server that ships with tensor flow
3875.609|3.811|called tensor board and we get these
3877.56|4.23|beautiful beautiful visualizations about
3879.42|4.29|what's going on in your network so here
3881.79|3.27|on the left remember we were telling we
3883.71|3.48|were getting a scalar summary of the
3885.06|3.96|loss so this actually shows that loss
3887.19|3.24|was going down I mean it was a small it
3889.02|2.91|was a big network and a small data set
3890.43|3.9|but that means everything is working and
3891.93|4.679|this over here on the right hand side is
3894.33|3.9|showing you histograms over time showing
3896.609|4.021|you the distributions of the values in
3898.23|3.99|your weight matrices so this is this
3900.63|2.97|stuff is really really cool and I think
3902.22|5.13|this is a really really beautiful
3903.6|5.34|debugging tool so when I've when I've
3907.35|3.06|been working on projects in torch I've
3908.94|3.54|written this kind of stuff myself by
3910.41|3.93|hand where I'm just kind of dumping JSON
3912.48|4.74|blobs out of torch and then writing my
3914.34|4.17|own custom visual is to view these kind
3917.22|3.24|of statistics because they're really
3918.51|3.24|useful and with tensor flow you don't
3920.46|2.97|have to write any of that yourself you
3921.75|3.359|just add a couple lines of code to your
3923.43|2.49|training script run their thing and you
3925.109|4.311|can get all these beautiful
3925.92|3.5|visualizations to help your debugging
3929.54|4.03|tensorflow
3930.75|4.65|or tensor board can also help you even
3933.57|5.22|visualize what your network structure
3935.4|5.76|looks like so here we've annotated our
3938.79|3.78|variables with these names and now when
3941.16|3.0|we're doing the forward pass we can
3942.57|4.11|actually scope some of the computations
3944.16|4.23|under a namespace and that sort of just
3946.68|4.47|lets us group together computations that
3948.39|4.14|should belong together semantically now
3951.15|3.9|other than that it's the same it's the
3952.53|4.38|same thing that we saw before and now if
3955.05|3.69|we run this Network and load up tensor
3956.91|4.38|board we can actually get this beautiful
3958.74|4.44|visualization for how like what our
3961.29|3.66|network actually looks like and we can
3963.18|3.24|actually click in and look and see what
3964.95|2.82|those gradients and the scores and
3966.42|4.59|really help debug what's going on inside
3967.77|5.13|this network and each you see these loss
3971.01|3.45|and scores these are the semantic
3972.9|3.39|namespaces that we defined it during the
3974.46|3.569|forward pass and if we click on the
3976.29|2.999|scores for example it opens
3978.029|3.33|and lets us see all of the sub
3979.289|4.56|operations that have that appear inside
3981.359|5.01|the computational graph for that node so
3983.849|4.41|I thought this was really cool right it
3986.369|3.36|lets you like really easily debug what's
3988.259|2.73|going on inside your networks while it's
3989.729|5.91|running and you don't have to write any
3990.989|7.05|of that visualization code yourself so
3995.639|5.46|tensorflow does have support for multi
3998.039|4.56|GPU so it has data parallelism like you
4001.099|3.0|might expect so I'd like to point out
4002.599|3.18|that actually this distribute this
4004.099|3.09|distribution part is probably one of the
4005.779|4.77|other major selling points of tensor
4007.189|4.86|flow that it can try to actually
4010.549|2.91|distribute the computational graph in
4012.049|3.81|different ways across different devices
4013.459|4.32|and actually place the distribute that
4015.859|5.04|graph smartly to minimize communication
4017.779|5.04|overhead and so on so one thing that you
4020.899|3.21|can do is data parallelism where you
4022.819|2.7|just split your mini batch across
4024.109|2.94|different devices and run each one
4025.519|3.3|forward and backward and then either
4027.049|3.84|some the gradients to do synchronous
4028.819|3.63|distributed training or just make
4030.889|3.36|asynchronous updates to your parameters
4032.449|4.35|and do asynchronous training so you can
4034.249|4.17|the the white paper claims you can do
4036.799|4.62|both of these things in tensorflow but I
4038.419|4.86|didn't I didn't try it out you can also
4041.419|3.81|actually do model parallelism in in
4043.279|3.3|tensorflow as well but let's you split
4045.229|2.88|up the same model and compute different
4046.579|3.96|parts of the same model on different
4048.109|4.05|devices so here's an example so one
4050.539|4.26|place where that might be useful is a
4052.159|4.32|multi-layer recurrent Network there it
4054.799|3.09|might actually be a good idea to run
4056.479|3.39|different layers of the network on
4057.889|3.72|different GPUs because those things can
4059.869|2.94|actually take a lot of memory so that's
4061.609|2.82|the type of thing that you can actually
4062.809|4.58|do about theoretically you can do that
4064.429|5.34|in tensorflow without too much pain
4067.389|4.42|tensorflow is also the only of the
4069.769|3.96|frameworks that can run in distributed
4071.809|4.17|mode not just distribute across one
4073.729|3.54|machine and multiple GPUs but actually
4075.979|4.53|distribute them training the model
4077.269|4.89|across many machines so the the caveat
4080.509|3.36|here is that that part is not open
4082.159|3.75|source yet right
4083.869|3.75|as of today the open source release of
4085.909|5.04|tensorflow can only do single machine
4087.619|5.04|multi-gpu training but I think but
4090.949|2.85|hopefully soon that part will be
4092.659|5.04|released too because that'd be really
4093.799|6.72|cool right so here the idea is we can
4097.699|5.13|just it and tensorflow is aware of
4100.519|4.74|communication costs both between GPU and
4102.829|4.41|CPU but also between different machines
4105.259|3.57|on the network so then it can try to
4107.239|3.54|smartly distribute the computational
4108.829|3.361|graph across different machines and then
4110.779|3.361|across different GPUs within the
4112.19|4.35|machines to compute everything as
4114.14|3.57|efficiently as possible so that's I
4116.54|2.489|think that's really cool and that's
4117.71|2.87|something that the other frameworks just
4119.029|4.02|can't do right now
4120.58|5.469|one pain point with tensorflow is
4123.049|5.851|pre-trained models so I looked I did a
4126.049|4.17|thorough Google search and the only
4128.9|3.39|thing I could come up with was an
4130.219|3.81|inception module a pre trained inception
4132.29|5.52|model but it's only accessible through
4134.029|5.551|this Android this Android demo so that's
4137.81|3.21|something I would have expected to be
4139.58|3.989|more clear from the documentation but
4141.02|5.73|that's at least that you have that one
4143.569|4.831|pre train level other other than that
4146.75|3.509|I'm not I'm not really aware of other
4148.4|3.39|pre train models in tensorflow but maybe
4150.259|2.551|maybe there are out maybe they're out
4151.79|5.549|there and I just don't know about them
4152.81|7.29|brav says No so I googled correctly so
4157.339|5.25|the tensorflow pros and cons from again
4160.1|3.869|my quick one-day experiment it's really
4162.589|2.701|good because it's Python and numpy
4163.969|3.27|that's really cool
4165.29|3.449|similar to fian oh it has this idea of
4167.239|4.62|computational graphs which i think is
4168.739|4.681|super powerful and actually takes this
4171.859|3.21|idea of computational graphs even
4173.42|3.419|farther than than fian oh really and
4175.069|4.111|things like checkpointing and
4176.839|3.781|distributing across devices these all
4179.18|3.45|end up as just nodes inside the
4180.62|5.82|computational graph for tensor flow so
4182.63|5.31|that's really cool it's also claims to
4186.44|3.419|have much faster compile times than
4187.94|3.87|Theon oh I've heard horror stories about
4189.859|4.59|neural Turing machines taking half an
4191.81|4.32|hour to compile maybe there maybe that
4194.449|3.241|should be faster in tensor flow so I've
4196.13|4.26|heard
4197.69|6.15|tensor board looks awesome that looks
4200.39|5.28|amazing I want to use that everywhere it
4203.84|3.39|has really cool data and model model
4205.67|2.52|parallelism I think much more advanced
4207.23|2.85|than the other frameworks
4208.19|3.81|although the distributed stuff is still
4210.08|3.119|secret sauce at Google but hopefully
4212.0|4.26|that will come out to the rest of us
4213.199|5.731|eventually but I guess as broth was
4216.26|4.47|saying it's even maybe the scariest code
4218.93|3.78|base to actually dig into and understand
4220.73|4.259|what's working under the hood so at
4222.71|3.989|least my fear about tensor flow is that
4224.989|4.351|if you want to do some kind of crazy
4226.699|4.77|weird imperative code and you cannot
4229.34|4.02|easily work it into their computational
4231.469|3.781|graph abstraction that seems like you
4233.36|5.28|could be in a lot of trouble we're in
4235.25|4.949|maybe in in in torch you can just write
4238.64|2.88|whatever imperative code you want inside
4240.199|3.781|the forward and backward passes of your
4241.52|4.29|own custom layers but that seems like
4243.98|4.64|the biggest a worrying point for me
4245.81|5.07|working with tensorflow in practice
4248.62|3.82|another another kind of awkward thing is
4250.88|24.24|this lack of pre train models so that's
4252.44|24.57|that's kind of gross oh oh yeah so
4275.12|3.45|actually a point about that um even
4277.01|3.21|installing on a bun to on my own machine
4278.57|2.52|that I had pseudo to was a little bit
4280.22|2.64|painful
4281.09|3.06|they claims to have a Python wheel that
4282.86|3.42|you can just download and install with
4284.15|3.6|pip but it broke and I had to change the
4286.28|3.66|file name manually to get it to install
4287.75|3.87|and then they had a broken dependency
4289.94|3.42|that I had to update manually and like
4291.62|4.86|download some random zip file and unpack
4293.36|4.95|it and copy some random files around but
4296.48|3.6|it eventually worked but installation
4298.31|4.71|was tough even on my own machine that I
4300.08|6.57|have pseudo to on Ubuntu so they should
4303.02|5.64|get their act together on that so I put
4306.65|3.84|together this quick overview table that
4308.66|3.54|kind of covers what I think people would
4310.49|3.6|care about on major points between the
4312.2|3.3|frameworks like what are the languages
4314.09|4.37|what kind of pre train models are
4315.5|2.96|available question
4325.48|4.44|look the question is is which of these
4328.0|7.489|support windows and I'm sorry but I
4329.92|5.569|don't know I think you're on your own
4337.02|10.39|yeah aw you can use AWS from Windows
4341.52|7.84|okay okay so I put together this quick
4347.41|3.39|quick comparison chart between the
4349.36|2.819|frameworks that I think covers some of
4350.8|4.02|the major bullet points that people care
4352.179|4.25|about talking about what language it is
4354.82|3.96|whether they have pre trained models
4356.429|4.391|what kind of parallelism you have and
4358.78|4.86|how readable is the source code and
4360.82|4.53|whether they're good at ardennes so I
4363.64|4.23|had a couple use cases in let's see
4365.35|4.44|we've got holy crap we got through like
4367.87|5.28|150 slides and we still have two minutes
4369.79|5.13|left so let's let's do let's play a
4373.15|3.63|little game suppose that all you wanted
4374.92|5.42|to do was extract Alec's net or vgg
4376.78|3.56|features which framework would you pick
4380.55|5.77|yeah me too Caffe let's say all we
4384.489|8.221|wanted to do was find two an Alex net on
4386.32|7.74|some new data yeah probably cafe let's
4392.71|7.14|say we wanted to do image captioning
4394.06|7.409|with fine-tuning okay I heard a good
4399.85|3.18|distribution so this is my thought
4401.469|1.921|process I'm not saying this is the right
4403.03|2.459|answer
4403.39|3.36|but the way I think about this is that
4405.489|2.94|for this problem we need pre chain
4406.75|3.42|models for pre-trained models we're
4408.429|5.761|looking at cafe or torch or lasagna
4410.17|6.029|we need rnns so cafe is pretty much out
4414.19|3.36|even though people have done have
4416.199|3.151|implemented this stuff there it's just
4417.55|5.16|kind of painful so I'd probably use
4419.35|4.889|torch or maybe lasagna how about how
4422.71|5.07|about semantic segmentation we want to
4424.239|4.98|classify every pixel right so here we
4427.78|2.91|want to read an input image and then
4429.219|3.391|instead of giving a label to the whole
4430.69|8.43|output image we want to label every
4432.61|8.339|pixel independently okay that's good so
4439.12|3.03|again my thought process was that we
4440.949|4.321|need a pre trained model here most
4442.15|4.68|likely and here that we're talking about
4445.27|4.08|kind of a weird use case where we might
4446.83|4.77|need to define some of our own logic so
4449.35|4.17|if this layer happens to exist in cafe
4451.6|3.389|that would be a good fit otherwise we'll
4453.52|3.06|have to write it ourselves and writing
4454.989|2.701|this thing ourselves seems least painful
4456.58|9.9|and torch
4457.69|11.43|how about object detection no idea yeah
4466.48|4.05|so cafe cafe is an idea so my thought
4469.12|5.04|process again we're looking at pre
4470.53|6.72|trained models so we need cafe torch or
4474.16|4.74|lasagna we actually could with detection
4477.25|3.75|you could need a lot of funky imperative
4478.9|3.93|code that it might be possible to put in
4481.0|2.13|a computational graph but seems scary to
4482.83|3.84|me
4483.13|6.12|so cafe plus Python is is one one choice
4486.67|5.22|that some of the frameworks we talked
4489.25|4.05|about actually went this route and I've
4491.89|3.18|actually done a similar project like
4493.3|4.11|this and I chose torch and it worked out
4495.07|3.69|good for me how about if you want to do
4497.41|2.91|language modeling like you want to do
4498.76|5.49|funky Ardennes and you want to play with
4500.32|6.72|the recurrence rule torch what do you
4504.25|4.77|guys sing yeah I would have actually not
4507.04|3.42|used to work for this at all so here if
4509.02|2.55|we just want to do language modeling and
4510.46|3.57|do funky kind of recurrence
4511.57|4.14|relationships then we're not talking
4514.03|3.44|about images at all this is just on text
4515.71|4.92|so we don't need any pre trained models
4517.47|5.05|and we really want to play with this
4520.63|3.45|recurrence relationship and easily work
4522.52|3.0|with our current networks so there I
4524.08|4.26|think that maybe Theano or tensorflow
4525.52|7.92|might be a good choice how about if you
4528.34|7.29|want to implement batch norm oh oops
4533.44|5.58|okay okay bug in the slides sorry about
4535.63|4.8|that right so here if you want if you
4539.02|2.67|want to rely if you don't want to derive
4540.43|2.61|the gradient yourself then you could
4541.69|3.81|rely on one of these computational graph
4543.04|3.93|things like piano or tensorflow but
4545.5|2.97|because of the way that those things
4546.97|3.06|work as you saw in the homework for
4548.47|3.95|batch norm you can actually simplify the
4550.03|4.8|gradient quite a lot and I'm not sure if
4552.42|3.91|these computational graph frameworks
4554.83|2.7|would correctly simplify the gradient
4556.33|4.13|down to this nice efficient form
4557.53|2.93|question
4566.39|6.28|the ways to do I think I so the question
4570.84|3.96|is how easily is it how easy is it to
4572.67|6.03|combine like a torch model with a piano
4574.8|5.58|model and I think it seems painful but
4578.7|4.05|at least in theano you can use lasagna
4580.38|4.11|to take access and pre train models so
4582.75|3.15|they're plugging together a lasagna
4584.49|4.83|model with something else I think
4585.9|5.34|theoretically maybe should be easier so
4589.32|3.6|here if you want if you have some like
4591.24|3.36|really really good knowledge about how
4592.92|3.36|how exactly you want the backward pass
4594.6|3.0|to be computed and you want to implement
4596.28|2.82|it yourself to be efficient then you
4597.6|2.61|probably want to use torch so you can
4599.1|4.23|just implement that backward pass
4600.21|4.71|yourself so my quick recommendations on
4603.33|3.57|frameworks are that if you just want to
4604.92|4.44|do feature feature extraction or maybe
4606.9|4.32|fine tuning up existing models or just
4609.36|3.78|train sort of a vanilla straightforward
4611.22|3.69|task then Cafe is probably the right way
4613.14|3.93|to go it's really easy to use you don't
4614.91|3.69|have to write any code if you want to
4617.07|3.66|work around with pre train models but
4618.6|3.99|maybe do weird stuff with pre train
4620.73|3.93|models and not just fine-tune them then
4622.59|4.35|you might have a better job in lasagna
4624.66|3.75|or torch because there it's easier to
4626.94|4.08|kind of mess with the structure of pre
4628.41|3.6|train models if you want to if you
4631.02|3.42|really really want to write your own
4632.01|3.75|layers for whatever reason and you don't
4634.44|2.79|think it can easily fit into these
4635.76|3.75|computational graphs then probably you
4637.23|5.22|should use torch if you really want to
4639.51|4.5|use rnns and maybe other types of fancy
4642.45|3.81|things that depend on the computational
4644.01|5.22|graph then probably then maybe Theano or
4646.26|4.53|tensorflow also if you have a gigantic
4649.23|3.45|model and you need to distribute across
4650.79|3.66|an entire cluster and you have access to
4652.68|4.65|Google's internal code base then you
4654.45|4.35|should use tensorflow although hopefully
4657.33|3.27|that like I said that part will be
4658.8|3.78|released for the rest of us soon so
4660.6|4.26|that's also if you want to use tensor
4662.58|4.02|board and you got to use tensor flow so
4664.86|3.93|that's that's pretty much my my overview
4666.6|4.83|my quick whirlwind tour of all the
4668.79|9.21|frameworks so any any last-minute
4671.43|8.91|questions question so the question is
4678.0|4.26|about speed so there's actually a really
4680.34|3.75|nice page that compares on speed
4682.26|3.75|benchmark speed of all the different
4684.09|4.47|frameworks and right now the one that
4686.01|4.41|wins is none of these the one that wins
4688.56|4.74|is this thing called neon from Nirvana
4690.42|4.59|systems so these guys have actually
4693.3|3.15|written these guys are crazy they
4695.01|5.07|actually wrote their own custom
4696.45|5.7|assembler for for NVIDIA Hardware they
4700.08|4.38|were not happy with like Nvidia's CUDA
4702.15|3.6|toolchain so they reverse engineer the
4704.46|3.15|hardware and wrote their own assembler
4705.75|5.19|and then implemented all these kernels
4707.61|5.79|in assembly themselves so these guys are
4710.94|4.92|crazy and their stuff is really really
4713.4|3.72|fast so they're actually there their
4715.86|3.36|stuff is actually the fastest right now
4717.12|3.75|but I've never really used there I've
4719.22|3.03|never really used their framework myself
4720.87|4.59|and I think it's a little less common
4722.25|4.71|than these although for the ones that
4725.46|4.11|are using qu DNN the speed is roughly
4726.96|4.8|the same right now I think tensorflow is
4729.57|3.69|quite a bit slower than the others for
4731.76|3.87|some silly reasons that I think will be
4733.26|3.78|cleaned up in subsequent releases but at
4735.63|3.33|least fundamentally there's no reason
4737.04|5.19|tensorflow should be should be slower
4738.96|5.52|than the others just curious about a
4742.23|3.42|show and by the way I'm going to view
4744.48|2.28|people are thinking of using different
4745.65|3.47|libraries so how many of you are
4746.76|7.32|thinking of going with the fate I know
4749.12|8.11|okay or force okay we're also there I
4754.08|5.58|guess piano based cars Lavanya okay or
4757.23|7.5|Tesla float all right all right
4759.66|6.33|or how about assignments code that's
4764.73|2.82|actually not crazy there were quite a
4765.99|2.64|few quite a few teams last year that
4767.55|4.92|actually use assignment code for
4768.63|5.04|projects and it was fine yeah I should
4772.47|3.12|also mention that there are other
4773.67|4.1|frameworks that I just think these are
4775.59|5.18|the these four are the most common
4777.77|3.0|question
4783.4|7.86|oh so that so the question is about
4787.9|5.88|graphing and torch so torch actually has
4791.26|4.62|an i - kernel so you can actually use um
4793.78|4.17|I torch notebooks that's kind of cool
4795.88|4.11|and actually you can actually do some
4797.95|4.44|simple graphing in I torch notebooks but
4799.99|4.77|in practice what I usually do is um dump
4802.39|4.47|my data run my torch model dump the data
4804.76|4.62|either to JSON or hdf5 and then
4806.86|4.02|visualize it in Python which is a little
4809.38|2.64|bit a little bit painful but you just
4810.88|9.99|get the job done
4812.02|10.89|question the question is whether tensor
4820.87|4.14|board lets you dump the raw data so you
4822.91|3.54|can plot it yourself they're actually
4825.01|4.26|plotted they're actually dumping all
4826.45|5.16|this stuff into some log files in the
4829.27|4.56|temp directory I'm not sure how easy
4831.61|3.47|those arts parse but you could try it
4833.83|4.25|could be easy or not I'm not sure
4835.08|3.0|question
4844.77|2.85|the question is whether there are other
4846.09|3.78|third-party tools similar to tensor
4847.62|3.63|board for moderating your networks there
4849.87|3.119|might be some out there but I've never
4851.25|8.01|really used them I've just written my
4852.989|9.381|own in the past any other questions all
4859.26|3.11|right I think I think that's it