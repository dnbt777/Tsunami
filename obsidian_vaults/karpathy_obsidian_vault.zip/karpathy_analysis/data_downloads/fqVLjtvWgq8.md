start_time|end_time|text
0.0|4.58|information from hundred and secretary
12.66|4.379|okay hi everyone
15.179|5.581|the microphone is working right I think
17.039|6.121|yes so I was recruited uh to say some
20.76|3.84|words of inspiration on the topic of AI
23.16|2.699|agents
24.6|3.66|um so I actually wanted to begin with a
25.859|4.321|story I think like AI agents are near
28.26|3.9|and dear to my heart to some extent
30.18|3.36|because this is a story drawing very
32.16|5.28|early open AI back when it was like
33.54|5.94|maybe a dozen people and this was 2016
37.44|4.26|or so and the Zeitgeist of the day
39.48|3.36|actually were RL agents and so
41.7|3.78|everyone's really interested in building
42.84|5.039|agents but very much at the time it was
45.48|5.22|in the context of the games primarily so
47.879|4.981|it was the height of excitement around
50.7|5.4|Atari and all the game playing and so on
52.86|6.66|and so my project at openai was trying
56.1|5.639|to focus the roh notes not on things I
59.52|5.279|want to Zuma's Revenge and so on but on
61.739|4.92|uh you know using computers using
64.799|3.241|keyboard and mouse and so I wanted to
66.659|3.121|make it useful I wanted to make them do
68.04|4.68|a lot of tasks and this project was
69.78|4.86|called world of bits and I I worked on
72.72|4.92|it together with Tennessee and Jim fans
74.64|4.92|there's someone here and so the three of
77.64|4.38|us ended up publishing a paper it's not
79.56|4.68|a super amazing paper because basically
82.02|4.98|at the time all you had was a hammer was
84.24|4.08|uh three percent learning and so we have
87.0|3.96|these very simple web pages that we're
88.32|4.32|trying to like order order a flight or
90.96|4.08|order some something to eat and very
92.64|5.519|simple web pages and we were mashing
95.04|4.32|buttons and mouse clicks and so on and
98.159|3.0|we were trying to like stumble our way
99.36|3.96|into the higher Awards and obviously it
101.159|3.361|didn't work so the technology was just
103.32|3.36|not ready and that was not the right
104.52|4.139|thing to work on at the time and so it
106.68|3.6|turns out that the right thing to do at
108.659|3.841|the time was actually to forget about AI
110.28|4.019|agents altogether and start building
112.5|4.02|language models and then language models
114.299|4.021|now we're back here five years later I
116.52|4.099|got distracted with self-driving for a
118.32|2.299|bit there
121.67|5.17|[Music]
122.47|6.11|[Laughter]
126.84|2.94|and so the way you would approach these
128.58|3.12|problems today is completely different
129.78|3.06|in fact all of you are working on AI
131.7|2.88|agents but you're not using any
132.84|3.06|reinforcement learning probably and so
134.58|3.42|that's so crazy and I don't think we
135.9|3.6|would have anticipated it at the time uh
138.0|4.26|it's just the way this played out it's
139.5|4.56|very it's very interesting
142.26|3.36|so I want to spend a bit of time on like
144.06|2.94|okay what is causing all this hype I
145.62|2.52|think obviously all the reason that all
147.0|3.06|of you are interested in this topic is
148.14|3.66|that I think it's very obvious to a lot
150.06|3.84|of people that AGI will take the form
151.8|3.42|factor of some kind of an AI agent and
153.9|2.58|it's not just going to be a single agent
155.22|2.22|thing there's going to be many agents
156.48|2.7|maybe they're going to be in
157.44|3.54|organizations or civilizations of
159.18|3.3|digital entities and I think it's just
160.98|3.539|extremely inspiring to sort of like
162.48|3.6|think through it's kind of crazy I also
164.519|4.021|want to pour some water on this too
166.08|4.62|though I think there is a large class of
168.54|4.199|problems that I think are very easy to
170.7|4.2|imagine they're very easy to build demos
172.739|4.14|for are actually extremely hard to make
174.9|3.36|products out of and I think many things
176.879|3.0|fall into this category I would tell
178.26|3.6|self-driving is an example of it
179.879|3.72|actually self-driving is very easy to
181.86|3.18|imagine very easy to build a demo of a
183.599|3.78|car driving around the block but making
185.04|4.02|it into a product takes a decade and the
187.379|4.5|same is true I think for for example VR
189.06|4.44|we're used to imaginable demos but uh
191.879|3.241|getting a tour again it takes a decade
193.5|3.9|and I think agents are kind of like that
195.12|4.68|as well very easy to imagine excited to
197.4|4.08|get excited about build demos off but I
199.8|3.24|think if you're in it you should be in
201.48|3.74|it for a decade and actually make it
203.04|2.18|work
205.26|3.059|um one other thing I want to say is that
206.94|2.82|I think it's kind of interesting to go
208.319|3.78|back to Neuroscience now and take
209.76|3.72|inspiration from it again in some ways I
212.099|2.761|think this was true in the early days of
213.48|2.72|deep learning but it's now true also
214.86|3.72|again for United
216.2|3.94|so it's been kind of interesting for me
218.58|3.48|to think about uh sort of all the
220.14|3.72|equivalents so in particular I think a
222.06|3.48|lot of us when we're um it's clear that
223.86|3.54|language models are part of a solution
225.54|3.66|but you know how do you build an entire
227.4|3.6|digital entity that has all the
229.2|3.42|cognitive tools that humans have so
231.0|3.659|obviously we all think we need some kind
232.62|3.839|of a potentially system to uh to
234.659|3.961|actually like plan ahead and think
236.459|3.721|through and reflect on what we're doing
238.62|3.539|and there's a lot more that you can take
240.18|4.26|inspiration from so for example the
242.159|3.601|hippocampus is important what is the
244.44|4.159|importance of the hippocampus for AI
245.76|5.699|agents well well it's uh somehow like
248.599|4.36|recording uh memory traces and maybe
251.459|3.42|indexing them using embeddinance and
252.959|3.06|retrieving from them uh something like
254.879|3.841|that so maybe that's kind of like the
256.019|4.141|retrieval kind of thing in the brain we
258.72|3.84|I think understand how to build visual
260.16|4.38|auditory cortex roughly but there's many
262.56|4.199|still things that like what are The
264.54|4.14|Columns of them in AI agents what is the
266.759|3.841|uh we are doing what does it look like
268.68|4.32|in an AI agent what does the balance
270.6|4.02|doing the sort of integrates all this
273.0|2.94|information together it's kind of like
274.62|2.46|potentially the seat of Consciousness
275.94|3.84|and it's got this very interesting
277.08|3.96|neural circuit where if you think of
279.78|3.54|your brain as sort of like multiple
281.04|3.42|entities fighting for the microphone as
283.32|2.46|to like what you're going to do the
284.46|2.94|following this is probably where that
285.78|3.54|happens it's kind of interesting
287.4|4.019|so I actually brought
289.32|3.599|a book that I like the girl says it's
291.419|3.361|called bringing Behavior by David
292.919|3.121|Eagleman and I found this very
294.78|2.82|interesting and inspirational so I leave
296.04|3.9|it here if you'd like to I'll go through
297.6|3.539|it and paste through it and I just think
299.94|2.28|that there's some interesting
301.139|3.0|inspiration to again draw from
302.22|5.1|neuroscience and just like we did early
304.139|4.981|on in with respect to how we design an
307.32|3.54|individual neuron we can do that again
309.12|3.84|today
310.86|2.76|me
312.96|2.16|um
313.62|4.019|finally I wanted to end with some words
315.12|4.5|of inspiration uh what's interesting and
317.639|4.021|not obvious is that
319.62|4.139|you guys building AI agents are actually
321.66|3.9|at the Forefront of capability of the
323.759|5.301|aisle today
325.56|6.0|um and all the big Labs like llm labs
329.06|3.88|and so on I suspect are not at the edge
331.56|3.419|of the case but look you are at the
332.94|5.58|first benefit uh so opening up for
334.979|5.641|example is very good at training Master
338.52|4.019|Transformer related models so as an
340.62|3.359|example one way to put it is if the
342.539|2.281|paper comes out it proposes some
343.979|3.121|different way of training and
344.82|4.02|Transformer the internal sprocket open
347.1|3.06|AI is something along the rise of oh
348.84|3.0|yeah someone tried that two and a half
350.16|4.08|years ago and here's what happened and
351.84|3.9|here's why it didn't work and it's very
354.24|3.959|well understood and very
355.74|3.899|um very well mapped out but when a new
358.199|2.461|agent paper comes out we're all
359.639|1.921|interested in when we look at it and
360.66|3.66|we're like oh that's really cool that's
361.56|4.68|another one and that's because uh you
364.32|3.84|know a team didn't have like five years
366.24|3.899|to spend on it and it's competing now
368.16|3.66|with all of you and the entrepreneurs
370.139|2.881|and actors and so on it's really hard to
371.82|3.599|do
373.02|3.6|so yeah I think it's really inspiring
375.419|3.481|that you are at the edge of capability
376.62|4.139|and uh on something that is obviously
378.9|3.84|very important in transformational and
380.759|4.88|so with those words I think uh it's
382.74|2.899|great to see what you guys don't
387.16|4.659|[Applause]