start_time|end_time|text
0.0|2.97|so I'm very excited to be here to tell
1.589|3.571|you a bit more about how we're scaling
2.97|4.11|machine learning models data algorithms
5.16|4.8|and infrastructure at Tesla and what
7.08|5.939|that looks like so the outline of my
9.96|4.53|talk is here
13.019|3.12|I'd like to first tell you a little bit
14.49|3.06|about Tesla Tesla autopilot what the
16.139|2.851|feature set is really what the problem
17.55|3.18|statement is what we're trying to
18.99|2.97|address here then I'll tell you a bit
20.73|2.85|about neural networks and what it takes
21.96|3.45|to actually deploy them into production
23.58|3.689|at scale and what that looks like for
25.41|3.42|the team and then I'll tell you a little
27.269|2.731|bit more about some of the more recent
28.83|2.97|neural networks that we have developed
30.0|4.95|for the purposes of full self-driving
31.8|4.47|I'll go into that at the end so first a
34.95|2.91|little bit about Tesla Tesla autopilot
36.27|3.84|so as you may know it has a lot of
37.86|4.74|manufactures and sells electric vehicles
40.11|4.44|and we have an a whole array of electric
42.6|3.66|vehicles some of them are in the hands
44.55|3.06|of customers or imminently to be in the
46.26|2.85|hands of customers and some of them have
47.61|3.57|only been announced so for example we
49.11|3.66|have the Model S the model 3 x and y and
51.18|4.62|then we've also announced the cyber
52.77|6.12|truck the ATV someone jokingly the
55.8|5.399|Roadster and the semi and we have quite
58.89|4.29|a few of these so globally we now have
61.199|3.691|roughly 1 million cars and for the
63.18|3.479|purposes of the team these are not just
64.89|3.63|cars these are computers they're
66.659|3.661|internet accessible and we can both
68.52|3.27|deploy over-the-air updates to them and
70.32|3.089|get a lot of data from them that helps
71.79|4.2|us develop the autopilot and they're
73.409|4.081|also robots so they have sensing they
75.99|4.86|have actuation and we're developing the
77.49|5.73|brains of of that computer now the most
80.85|5.01|basic kind of autopilot functionality is
83.22|4.95|that when you turn it on in your car the
85.86|3.689|car will keep its lane and it will keep
88.17|1.62|distance away from the vehicle ahead of
89.549|2.791|you
89.79|4.74|we've now sort of accumulated almost 3
92.34|4.65|billion miles on the autopilot which
94.53|4.29|sounds like a lot we then have more
96.99|3.059|advanced features like such as for
98.82|3.089|example navigating autopilot
100.049|4.051|this allows you to set a pin somewhere
101.909|3.481|in the world as a destination and then
104.1|3.33|as long as you stick to the highway
105.39|3.659|system the car will automatically reach
107.43|3.149|that destination on the highway system
109.049|3.061|it will do all the correct lane changes
110.579|3.15|it will do it will take all the right
112.11|3.45|Forks that interchanges and it will
113.729|3.6|overtake slow vehicles ahead of you and
115.56|3.93|it's kind of like we think of it as
117.329|3.9|roughly autonomy on the highway and the
119.49|3.69|car now has to monitor its blind spot it
121.229|3.541|has to have intelligence around where it
123.18|4.469|is on the highway it has to localized
124.77|4.59|the correct lane and so on we've also
127.649|3.511|late last year released two smart summon
129.36|3.31|this allows you to with your phone on
131.16|3.189|the mobile app
132.67|3.39|summon the car to you from a parking
134.349|3.961|spot so if your car's parked somewhere
136.06|3.69|you just summon it to you and the car
138.31|3.21|comes out of its parking spot with no
139.75|3.209|one inside and comes wind its way
141.52|5.329|through the parking lot to come find you
142.959|3.89|it's it's quite magical when it works
147.42|4.6|also under the hood we have a lot of
150.61|5.19|active safety features that are always
152.02|6.36|running and available even when our pal
155.8|4.08|is not turned on and we have a lot of
158.38|3.0|statistics available to us because we
159.88|2.82|have 1 million cars in the road and we
161.38|2.82|know how people get into trouble and
162.7|5.4|then we try to implement features that
164.2|5.369|you know help alert or avert an accident
168.1|3.51|so for example automatic emergency
169.569|3.721|braking front collision warning side
171.61|4.08|collision warning blind spot monitoring
173.29|4.169|lane departure avoidance emergency lane
175.69|4.769|departure motions and so on these active
177.459|5.881|safety features help keep customers save
180.459|3.931|in our cars in particular on active
183.34|3.36|safety we're doing extremely well
184.39|3.99|EuroNCAP awarded us with the 5-star
186.7|3.84|rating in particular I believe we had
188.38|4.079|the top scores and safety assist we also
190.54|3.21|did extremely well on a B automatic
192.459|4.141|emergency braking for pedestrians and
193.75|4.56|cyclists now you're seeing here for
196.6|3.449|example a B pedestrian is five point six
198.31|4.17|out of six points I think these numbers
200.049|3.78|are kind of like a slightly abstract so
202.48|2.49|let me actually put that in context like
203.829|2.731|really what are we talking about here
204.97|5.37|pedestrian a B is the following
206.56|7.11|here's a simple here's one example the
210.34|5.61|cars up someone just emerges from in
213.67|3.84|between parked cars and this car may not
215.95|2.7|have even been on the autopilot but we
217.51|2.819|continuously monitor the environment
218.65|2.67|around us we saw there's a person in
220.329|6.69|front and we slam on the brakes
221.32|7.25|automatically here's another example it
227.019|3.421|looks like a pretty benign scene
228.57|3.34|this person is probably not paying
230.44|3.389|attention the pedestrian is not paying
231.91|4.409|attention we slam on the brakes and
233.829|4.551|prevent a collision here's one more
236.319|2.061|example
240.15|3.149|you can see the trouble coming from the
241.89|3.209|right it's really hard to tell because
243.299|3.151|everything is occluded and then suddenly
245.099|3.511|there's a pedestrian we slam on the
246.45|3.3|brakes and a border collision again so
248.61|2.73|you know five point six out of six it's
249.75|3.54|kind of abstract but we see a lot of
251.34|4.289|these we see tens to hundreds of these
253.29|5.759|per day where we actually are averting a
255.629|5.01|collision and not all of them are true
259.049|2.97|positives but a good fraction are and
260.639|2.911|you know this is where you actually make
262.019|4.111|your object detector really count here
263.55|4.08|you're really averting collisions now
266.13|3.42|the gold the team hires to produce full
267.63|3.78|self-driving functionality so here we
269.55|5.3|have a video from the autonomy day that
271.41|7.74|we had like somewhere early last year
274.85|6.819|oops there we go
279.15|4.049|so the ambition of the team is to
281.669|3.151|produce full self-driving meaning that
283.199|3.541|you can just set up in arbitrarily
284.82|3.42|arbitrarily in the world not even on the
286.74|3.179|highway system but everywhere else here
288.24|3.09|you see the car just taking turns from
289.919|4.5|the parking lot it comes to an
291.33|4.76|intersection it waits for a yep green
294.419|4.381|traffic light it turns to the left
296.09|4.27|merges on the highway and no need to
298.8|2.94|touch the wheel these this is not
300.36|3.239|available to customers we only have
301.74|3.6|developer builds that do these turns
303.599|3.241|through intersections and so on but
305.34|3.72|we're trying to get it to the point
306.84|3.48|where we feel that the system is
309.06|4.77|accurate enough to actually release in
310.32|5.19|some form so I'm going to cut this short
313.83|5.76|but this will actually get on the
315.51|5.76|cloverleaf in a bit it will take the
319.59|2.79|cloverleaf it will turn around and come
321.27|5.55|back to our headquarters in Palo Alto
322.38|6.09|where a lot of the team is based now I'm
326.82|3.54|gonna cut through this you may be asking
328.47|3.33|like you saw the car take a left through
330.36|3.179|an intersection when the light was green
331.8|4.32|and you've actually seen a lot of these
333.539|4.981|videos for a like a decade so you know
336.12|5.359|here's a way mo I just took a small clip
338.52|4.8|away mo comes to an intersection and
341.479|3.851|takes a look through the intersection
343.32|3.45|you've seen this for a decade so how is
345.33|3.899|this special why are we so late what's
346.77|6.24|taking so long and you know it looks the
349.229|5.101|same so what's the but I think the
353.01|2.55|critical point to make is that it looks
354.33|2.91|the same but under the hood it's
355.56|3.21|completely different in terms of the
357.24|3.239|approach that we take towards fulsol
358.77|2.91|driving so in particular we take a
360.479|3.571|heavily vision-based
361.68|4.14|approach so everyone else has a lidar on
364.05|4.77|the top of the car the lidar shoots out
365.82|5.49|lasers and creates a lidar point cloud
368.82|3.54|map and then you pre map the environment
371.31|2.06|that you're going to drive so you have a
372.36|2.93|high definition lighter
373.37|3.54|map and you localize to it to ascending
375.29|2.97|your level accuracy and then you know
376.91|2.91|exactly the path you're going to take so
378.26|3.36|you can just steer to keep yourself you
379.82|4.71|know perfectly localized in the correct
381.62|4.14|region so this is quite helpful but this
384.53|2.94|is not the approach that we take we do
385.76|3.3|not have lidar on our cars so we don't
387.47|4.11|shoot our lasers it's all camera based
389.06|4.079|and we do not build high-definition maps
391.58|2.85|so when we come to an intersection we
393.139|3.511|encounter it basically for the first
394.43|3.78|time we'll come to an intersection how
396.65|3.39|many lanes are there left right center
398.21|2.94|which way should I turn what are the
400.04|3.24|traffic lights which means do they
401.15|6.75|control all this has just done just from
403.28|6.419|camera feed a camera vision alone and so
407.9|2.79|this is a bit of a harder problem but of
409.699|2.881|course once you actually get this to
410.69|5.3|work we can also deploy it to the
412.58|5.43|millions of cars that we have globally
415.99|3.31|so let me now tell you a little bit
418.01|3.029|about the neural networks that actually
419.3|3.39|support all of the features that I've
421.039|3.841|shown you that the autopilot is capable
422.69|3.81|of and what it takes to actually keep
424.88|3.87|these neural networks in production at
426.5|5.4|scale in the hands of customers so
428.75|4.53|here's a random scene where we have to
431.9|3.57|potentially drive and wind our way
433.28|3.9|through this scene as a human this is
435.47|3.06|relatively effortless but you're
437.18|3.239|actually doing a lot under the hood and
438.53|3.3|the autopilot has two as well so we
440.419|2.671|understand a lot about what are the
441.83|4.98|static objects what are the dynamic
443.09|5.639|objects what is the road layout what is
446.81|3.72|all of the layer of semantics on top of
448.729|3.511|the road like Lane line markings road
450.53|3.0|markings traffic lights that tell you
452.24|3.33|about how you can actually traverse that
453.53|3.66|scene so once you actually start writing
455.57|3.21|down what's necessary to actually you
457.19|3.06|know perform the driving policy you end
458.78|4.5|up with a long list of tasks all of
460.25|5.28|which we need to actually handle and the
463.28|4.41|detection of these tasks serves two
465.53|3.3|purposes and two customers number one we
467.69|2.88|actually need it for the driving policy
468.83|2.79|and number two we actually want to show
470.57|3.0|a lot of things on the instrument
471.62|5.46|cluster for the human so that they gain
473.57|5.31|sort of confidence in the system here
477.08|3.03|we've produced a video that shows some
478.88|3.45|of the under different predictions for
480.11|3.63|the main camera that is facing forward
482.33|3.3|on the car and you see that we're
483.74|4.109|detecting lanes were detecting stop sign
485.63|3.15|over there stop line road markings we're
487.849|4.531|putting keyboards around the cars
488.78|5.28|traffic lights Road edges and curbs even
492.38|3.84|things like trash bins coming up over
494.06|4.26|there lines that make up the
496.22|4.259|intersection in a bit there's lines that
498.32|3.39|create parking spots we have to have all
500.479|3.06|these attributes for whether or not a
501.71|3.959|line is for a parking spot or not and
503.539|2.881|things like that so these predictions
505.669|2.011|were pretty DS
506.42|3.48|but it's actually a huge amount of work
507.68|4.44|to get them to to actually work at scale
509.9|4.62|and in the full long tail of what you
512.12|4.11|can encounter on the roads so even
514.52|3.54|taking a very simple task like for
516.23|3.39|example stop sign you think that you
518.06|3.24|know neural networks are capable of
519.62|3.33|handling a thousands of categories of
521.3|3.96|imagenet with all of their variations
522.95|4.08|and so on so how difficult is it to just
525.26|3.93|detect a fixed pattern of like red on
527.03|3.48|white stop and it actually gets quite
529.19|2.82|difficult when you get to the long tail
530.51|3.18|of it even to create a simple detector
532.01|3.45|first stop sign so first of all stop
533.69|4.29|signs can of course be in lots of very
535.46|4.14|environmental conditions stop signs can
537.98|3.75|not just be impulse but kind of just
539.6|4.59|like on walls stop signs can be
541.73|4.98|temporary and just hang out in different
544.19|5.4|configurations stop cells can have funny
546.71|4.62|lights on them which are supposed to
549.59|4.02|make it easier to see the stop sign but
551.33|4.14|for our system is the opposite we have
553.61|4.77|to actually explicitly worry about it
555.47|4.92|stop signs can be held by a person that
558.38|4.17|stop sign can be an in an inactive state
560.39|4.38|or an active state stop signs can be on
562.55|4.68|like these cones stop signs can be
564.77|5.67|heavily occluded in lots of ways by
567.23|5.34|foliage by signs stop signs can be
570.44|4.05|occluded by cars stop signs can be part
572.57|5.04|of cars and they can be part of cars in
574.49|6.33|an active or inactive state again stops
577.61|5.82|can be sort of held by person stops come
580.82|5.27|with lots of exotic modifiers to them so
583.43|6.09|this stop only applies except right turn
586.09|7.24|this stop says take your turn through
589.52|6.84|this place this stop is right turn keep
593.33|5.31|moving so do not stop if you're going
596.36|3.48|right so there's a variety of modifiers
598.64|3.0|all of them we have to care about
599.84|2.94|because they actually have impact on on
601.64|2.52|how you should drive through this part
602.78|3.75|of space and as I mentioned everything
604.16|3.99|is a eye vision based at the moment we
606.53|2.91|do have maps of course that we build but
608.15|3.48|they're not high-definition maps but
609.44|3.87|stops can be attached to gates but they
611.63|3.72|only apply when the gate is closed when
613.31|4.26|it's open they do not apply stops can be
615.35|4.2|in arms these arms can lift and then the
617.57|3.75|stop sign does not apply any more stops
619.55|3.87|can only apply when you're taking a left
621.32|3.57|so their action conditional and so
623.42|3.09|basically there's a massive variety of
624.89|3.21|even just for a stop sign to get this to
626.51|3.54|work and what we do day to day in the
628.1|3.51|team is we are going through the long
630.05|3.57|tail and we're building all this
631.61|4.26|infrastructure for sourcing all these
633.62|3.6|additional examples and so I've shown in
635.87|4.29|the autonomy Day presentation earlier
637.22|5.309|last year the data engine the process
640.16|4.44|by which we iterated Li apply active
642.529|4.141|learning to source examples in cases
644.6|4.469|where the detector is misbehaving and
646.67|3.839|then we source examples in those and we
649.069|3.27|label them and incorporate them into a
650.509|3.741|part of a training set so for stop sound
652.339|3.93|detection as an example we have a
654.25|4.06|approximate detector for stop signs
656.269|3.99|based on an initial seed set of data and
658.31|3.719|we run that and deploy that to cars in
660.259|3.601|shadow mode and then you can detect some
662.029|3.6|kind of a lack of health of that
663.86|3.18|detector at test time so for example the
665.629|5.19|stop sign detection is flickering that
667.04|4.89|could be a source of sort of uncertainty
670.819|2.431|you can also detect that the neural
671.93|2.61|network is uncertain in a certain
673.25|4.439|Bayesian way and there's a few ways to
674.54|4.589|model that you can find instances where
677.689|3.061|you get surprised to see a stop sign
679.129|4.471|like why didn't you see it when you were
680.75|5.009|a bit further away you can also source
683.6|3.51|examples when we detect a stop sign but
685.759|2.64|the map thinks that there should be no
687.11|3.089|stop sign or vice versa
688.399|3.721|so if sort of a map vision disagreement
690.199|4.62|so we have lots of different ways of
692.12|4.35|sourcing difficult cases and then we
694.819|2.791|upload images and we look through them
696.47|3.45|we label some of them and incorporate
697.61|4.56|them into your training set as an
699.92|3.81|example we've struggled with these
702.17|3.21|heavily occluded stop signs we found
703.73|2.549|that the detector was not performing
705.38|3.24|very well when they were heavily
706.279|4.23|occluded and that we have a mechanism in
708.62|3.3|this data engine process where we can
710.509|3.69|actually train these kinds of detectors
711.92|4.229|offline so we can train a small detector
714.199|3.961|that detects an occluded stop sign by
716.149|3.36|trees and then what we do with that
718.16|3.029|detector is that we can beam it down to
719.509|3.93|the fleet and we can ask the fleet
721.189|3.63|please apply this detector on top of
723.439|3.541|everything else you're doing and is that
724.819|3.75|this detector scores high then please
726.98|4.169|send us an image and then the fleet
728.569|4.02|responds with somewhat noisy set but
731.149|2.79|they boosted the amount of examples we
732.589|3.36|have of stop signs that are occluded and
733.939|3.361|maybe 10% of them are actual occluded
735.949|2.82|stop signs that we get from that stream
737.3|3.0|and this requires no firmware upgrade
738.769|3.3|this is completely dynamic and can just
740.3|3.0|be done by the team extremely quickly is
742.069|2.76|the bread and butter of how we actually
743.3|3.24|get any of these tasks to work just
744.829|3.781|accumulating these large data sets in
746.54|3.779|the full tail that distribution so we
748.61|3.899|have tens of thousands of occluded stop
750.319|5.611|signs the fleet can send us as many as
752.509|5.901|it takes we have the biggest data set
755.93|5.969|for accept right turn on stops I'm
758.41|5.38|basically certain of that we again
761.899|4.98|create a detector for this and then we
763.79|5.7|get a nosy stream from the fleet of cars
766.879|3.57|encountering except right turn on
769.49|2.339|stopped and we can label that
770.449|2.76|incorporate a new training set we have
771.829|2.43|tens of thousands of these
773.209|2.701|actually hundred percent sure how you
774.259|4.14|built out a data set like this without
775.91|4.349|the fleet so I've talked a lot about
778.399|4.711|massaging and growing the training sets
780.259|4.651|but we place just as much we put just as
783.11|4.529|much work into massaging the test sets
784.91|4.38|as we do into training sets so just
787.639|3.36|reporting your mean average precision or
789.29|3.63|reporting the loss function that you
790.999|4.291|achieve and a test set that just doesn't
792.92|3.959|do it for us so we spend a lot of time
795.29|3.029|inspired by a serve test-driven
796.879|3.3|development to build out very
798.319|3.39|complicated unit tests and predicates
800.179|3.301|for how the detector should behave in
801.709|3.451|different cases so for example we could
803.48|3.449|have a barrage of tests along the lines
805.16|3.659|of in this image you should detect a
806.929|3.96|stop sign right here and the modifier
808.819|3.601|that you for this and that that you
810.889|3.331|predict on the stop sign must be this or
812.42|3.57|that and so we have mechanisms for
814.22|3.419|creating and massaging and these unit
815.99|3.18|tests it's a growing collection as we
817.639|3.18|encounter problems in the fleet and as
819.17|3.24|we notice them and then we certify
820.819|3.21|whether this detector is performing well
822.41|4.169|or not and this is art this is really
824.029|4.56|art doesn't it's curated unit tests if
826.579|3.51|you're in a production setting we
828.589|2.761|actually like break down all this all
830.089|3.151|these different issues and track them
831.35|3.599|individually and then pursue them one by
833.24|4.319|one with data engine to actually make
834.949|4.771|them work so occluded size we would
837.559|3.63|build out a test set first we see that
839.72|2.88|we're failing on occluded signs and then
841.189|3.031|we once we have the test and we're
842.6|3.329|failing them we then spin the data
844.22|3.27|engine on occluded size and then we see
845.929|2.97|that the percent pass goes from 40
847.49|3.209|percent to 99 percent or something like
848.899|4.35|that and then we're confident that this
850.699|5.58|is actually working relatively long now
853.249|4.56|so I've kind of shown you a little bit
856.279|3.511|of the process we take for even a very
857.809|3.72|simple one prediction but as I mentioned
859.79|4.44|there's lots of tasks lots of attributes
861.529|4.98|so the complexity of this is quite
864.23|4.019|staggering we have to know a lot about
866.509|4.2|any scene and each one of those things
868.249|3.51|has their own data engine so what we end
870.709|2.49|up doing is we have these neural
871.759|4.32|networks that have a shared backbone and
873.199|6.48|then they're multitask juggling lots of
876.079|6.6|different tasks and in total the team is
879.679|4.97|currently maintaining 48 networks that
882.679|4.2|make a thousand distinct predictions
884.649|3.55|these are just a raw number of output
886.879|2.43|tensors if you just take all of our
888.199|2.67|networks and you add up the output
889.309|2.58|tensors it's a thousand and those
890.869|2.43|tensors of course can have multiple
891.889|2.82|predictions in them
893.299|3.09|none of these predictions can ever
894.709|4.62|regress and all of them must improve
896.389|5.401|over time and this takes 70,000 GPU
899.329|4.17|hours the Train of the neural Nets if
901.79|3.02|you have a node with a GPUs you will be
903.499|2.931|trained for a year
904.81|3.21|we do quite a bit of training there and
906.43|3.09|all of this is not maintained by
908.02|3.66|hundreds of people all of this is
909.52|3.99|maintained by a small elite team of
911.68|4.17|Tesla AI people basically like a few
913.51|3.69|dozen so how's it even possible to make
915.85|4.14|progress and how's it impossible that
917.2|5.88|just small team can maintain so many
919.99|4.68|tasks and get them to work overtime this
923.08|2.94|is the North Star for actually achieving
924.67|4.05|this for us it's called Operation
926.02|4.47|vacation which I'll describe in a second
928.72|4.92|but basically the idea is that for any
930.49|4.83|new task you have a latency to actually
933.64|3.6|the task working and there's a process
935.32|3.959|and we understand how to the process for
937.24|3.599|getting a task to work and we're trying
939.279|2.761|to develop as much automation machinery
940.839|3.0|to actually support the development of
942.04|3.87|these new features and new tasks and
943.839|3.541|we're removing engineers from that from
945.91|2.73|that loop so they're not involved we're
947.38|2.7|just building out infrastructure and
948.64|3.74|then we have a data labeling team and a
950.08|4.5|you know PMS and so on that can actually
952.38|5.2|use that infrastructure to create new
954.58|4.38|new detectors so as an example we're
957.58|2.88|working with caution lights recently
958.96|3.54|we're trying to detect when the police
960.46|3.39|car lights are turned on this is an
962.5|3.54|example of a new task that we'd like to
963.85|4.35|know about and we sort of have a cookie
966.04|3.72|cutter we know exactly what's a kind of
968.2|3.21|approach to you we know exactly what it
969.76|3.57|takes to get a task to work all the
971.41|3.51|infrastructure is in place so this task
973.33|3.75|we're going to treat it as a landmark
974.92|4.02|task landmark is an example of a
977.08|3.06|prototype survival detection prototype a
978.94|3.12|segmentation prototype a landmark
980.14|5.07|prototype and these are just classes of
982.06|5.55|tasks and if your new task is a member
985.21|4.08|of any of these or an instance of any of
987.61|2.7|these prototype classes then all of the
989.29|3.24|infrastructure is used to plug-and-play
990.31|3.96|and go through the full data engine you
992.53|3.45|can collect the seen data set you label
994.27|3.39|your examples your source nor examples
995.98|4.14|in the cases where you're failing you
997.66|4.2|deployed a shadow in shadow mode you
1000.12|3.39|source examples and you grind up metrics
1001.86|3.27|you create all the unit test predicates
1003.51|3.39|all this is completely automated and
1005.13|3.6|this we're mostly developing the
1006.9|3.3|automation infrastructure and then it's
1008.73|5.76|easy to develop any new task and that's
1010.2|5.61|kind of how we get this to work okay
1014.49|2.61|so now I'd like to talk a little bit
1015.81|2.49|about the neural networks and how they
1017.1|3.78|have they have to change to actually
1018.3|3.87|support full self-driving so what I've
1020.88|3.09|explained so far as you take an image
1022.17|2.97|from one of the cameras you run it
1023.97|3.03|through this shared backbone and you
1025.14|4.35|make lots of predictions about it in the
1027.0|4.319|image pixel space so we can potentially
1029.49|4.199|predict objects lies or edges and so on
1031.319|4.531|taking the example of edges where does
1033.689|4.911|this go afterwards right so here's a
1035.85|4.52|video and I'm showing the predictions of
1038.6|3.719|the road edge tasks on all of the
1040.37|3.36|different cameras and you can see that
1042.319|4.77|this is basically a binary segmentation
1043.73|5.4|problem for us and we detect those edges
1047.089|3.661|here and we use this to wind our way
1049.13|3.299|through a parking lot because we'd like
1050.75|4.32|to go to a certain destination but avoid
1052.429|4.531|all the raw edges now you can't just
1055.07|6.63|drive on the raw predictions of these
1056.96|6.089|edges in these two-dimensional pixel you
1061.7|3.27|know pixel coordinate systems so you
1063.049|4.561|have to somehow project this out into a
1064.97|5.31|bird's eye view sort of in order to make
1067.61|4.89|this make sense so the raw detections we
1070.28|4.23|project them out into 3d and we stitch
1072.5|2.46|them up into what we call a occupancy
1074.51|3.36|tracker
1074.96|4.709|so this occupancy tracker takes all the
1077.87|3.78|raw measurements from the 2d images we
1079.669|3.721|project them out into the world and we
1081.65|3.06|stitch them up across cameras and we
1083.39|3.09|stitch them up across time
1084.71|3.51|so the occupancy tracker is keeping the
1086.48|4.14|temporal context of that and it creates
1088.22|4.079|a small local map and then it winds its
1090.62|2.91|way through this parking lot to can get
1092.299|4.711|to the person who is summoning the car
1093.53|4.83|at this time so this is all fine but
1097.01|3.659|there's a lot of problems with actually
1098.36|3.51|doing the stitching as I'm describing it
1100.669|2.731|I'm making it sound very easy the
1101.87|3.03|problem is these cameras are pointed in
1103.4|3.18|arbitrary directions they make these
1104.9|3.21|measurements in this pixel frames you
1106.58|3.99|might not your road edges might not even
1108.11|4.98|align across camera scenes and writing
1110.57|4.109|the tracker for these edges over time is
1113.09|3.93|actually highly non-trivial lots of high
1114.679|4.681|parameters error-prone code very
1117.02|4.59|difficult to develop so I've shown this
1119.36|4.23|example or this visualization a few
1121.61|3.449|times in many of my previous talks where
1123.59|3.3|this is sort of the autopilot software
1125.059|3.781|stack on the bottom you have inputs to
1126.89|4.279|the stack a primarily vision and on the
1128.84|5.01|output we have steering acceleration and
1131.169|4.601|roughly you can think of two code bases
1133.85|3.66|hidden inside the software stack we have
1135.77|3.409|what I refer to as a software 1.0 code
1137.51|4.62|which has good old fashioned C++
1139.179|4.961|explicitly designed engineered by person
1142.13|3.39|person writes the code and then you have
1144.14|3.419|what I call software 2.0 code where the
1145.52|4.139|the code is an outcome of an
1147.559|4.35|optimization it's a it's the compilation
1149.659|3.9|it's a compiler takes your data set and
1151.909|3.541|creates neural network code that runs in
1153.559|3.301|the car and so it's roughly speaking
1155.45|3.359|your own that the reason I refer to it
1156.86|4.77|as software 2.0 is that you can take
1158.809|4.651|functionality from 1.0 code base and put
1161.63|3.57|it into 2.0 code base so this boundary
1163.46|4.08|is fluid and you can actually engulf
1165.2|3.9|more and more software 1.0 stack so over
1167.54|2.75|time since I joined about two and a half
1169.1|3.41|years ago the neural net
1170.29|4.02|have expanded in how much of software
1172.51|3.15|one panel and they've taken over and so
1174.31|3.78|the trend is upwards
1175.66|5.34|so in particular in the case of these
1178.09|3.99|road edges as I described who are now
1181.0|1.98|working towards is that we don't
1182.08|2.31|actually want to go through this
1182.98|3.18|explicit occupancy tracker software
1184.39|3.96|bumping a code we'd like to engulf it
1186.16|3.84|into neural net code and we see that
1188.35|3.18|typically that works really well so a
1190.0|2.88|lot of our networks have been moving
1191.53|3.78|towards these bird's-eye view Network
1192.88|4.02|predictions where you take all these
1195.31|3.9|cameras and you feed them through
1196.9|5.58|backbones and then you have neural net
1199.21|5.31|fusion layer that stitches up the
1202.48|4.17|feature maps across the different views
1204.52|4.23|and also does the projection from image
1206.65|3.69|space to bird's eye view and then we
1208.75|2.64|have a temporal module potentially that
1210.34|3.42|actually smooths out these predictions
1211.39|4.14|and this is all neural net components
1213.76|4.29|and then we have a bed net decoder that
1215.53|4.5|actually creates the top-down space and
1218.05|3.39|so then we can directly potentially
1220.03|3.87|predict these red edges in a top-down
1221.44|4.71|view now this makes a huge difference in
1223.9|5.01|practice so here's an example in top row
1226.15|4.56|I'm showing the camera Center right and
1228.91|4.26|I'm showing Road edge detection in red
1230.71|4.14|on the bottom row on the left you see
1233.17|3.69|the ground truth of what this
1234.85|4.2|intersection looks like and you see that
1236.86|3.33|the cars position on the dot and so
1239.05|2.55|that's the ground truth on the very
1240.19|3.42|right you see what happens when you take
1241.6|3.96|2d predictions in the images and you
1243.61|3.75|cast them out you basically get garbage
1245.56|3.57|like it somewhat works around the car
1247.36|3.54|there the projection is easy but far
1249.13|3.9|away especially near the horizon line a
1250.9|4.47|few pixels of error means lots of meters
1253.03|3.63|of the error and so this projection
1255.37|2.79|based techniques are extremely hard to
1256.66|3.75|get to work you'd have to know extremely
1258.16|3.54|accurate depth per pixel to do that
1260.41|3.36|projection it's a very hard problem and
1261.7|3.27|in the in the middle you are seeing some
1263.77|3.42|of our predictions from the recent
1264.97|3.33|bird's eye view networks that just kind
1267.19|3.12|of make these predictions and talk to
1268.3|3.45|you directly so let me show you a video
1270.31|3.96|here of what this looks like in practice
1271.75|4.71|on the top we will have a video of an
1274.27|3.9|intersection on the bottom I'm showing
1276.46|3.87|some of the predictions achieved by the
1278.17|3.69|Tesla AI team that has produced these
1280.33|3.81|bird's-eye view networks we have rode
1281.86|4.95|edges in red we have dividers in green
1284.14|3.93|on the very left then we have attributes
1286.81|2.91|for these dividers so we want to know if
1288.07|3.69|it's an actual core or if it's just like
1289.72|3.42|a logical curb so like a yellow line or
1291.76|2.94|something like that then we have a
1293.14|3.09|traffic flow direction and a few other
1294.7|4.62|things like that I'm only showing some
1296.23|5.71|examples but the car is on the bottom
1299.32|3.939|center of these images and as well
1301.94|2.88|finding is returning through this
1303.259|3.75|intersection these birds that be Network
1304.82|3.989|just predict pretty far away the full
1307.009|4.53|structure of this intersection and what
1308.809|4.83|it looks like so this is this is
1311.539|4.38|extremely powerful for us here's another
1313.639|3.961|example in the case of smart summon the
1315.919|3.061|car is driving around parking lots and
1317.6|3.209|we have to understand the corridors of
1318.98|3.21|this parking lot and so here we are
1320.809|2.671|predicting the corridors in bird's-eye
1322.19|2.939|view we're predicting where the
1323.48|3.27|corridors meet at intersection points in
1325.129|3.331|red and we're predicting tiny arrows
1326.75|3.299|that tell us the traffic flow and this
1328.46|3.469|all comes up the net directly there's no
1330.049|4.651|occupancy tracker kind of necessary
1331.929|5.59|here's an example of using this for
1334.7|5.52|objects so on the top we have our camera
1337.519|5.28|feeds on the middle I'm showing our per
1340.22|4.679|pixel depth predictions achieved by our
1342.799|3.811|self supervised learning we need those
1344.899|4.201|depth predictions because we take as
1346.61|4.5|many others do in little lurch right now
1349.1|4.529|we take a pseudo lidar approach where
1351.11|4.169|you basically a predict the depth for
1353.629|3.93|every single pixel and you can cast out
1355.279|4.291|your pixels and you basically simulate
1357.559|4.141|polite our input that way but it's
1359.57|2.91|purely from vision and then you can use
1361.7|2.49|a lot of techniques that have been
1362.48|3.84|developed and also for lidar
1364.19|6.209|processing to actually achieve 3d object
1366.32|5.819|detection so on the on the bottom you
1370.399|5.701|have them predictions of our detector
1372.139|5.37|directly in the bird's eye view yeah
1376.1|3.24|here I have one more slide showing just
1377.509|4.321|our depth predictions for some of some
1379.34|3.569|other videos this is not very exotic for
1381.83|2.64|any of you who are in computer vision
1382.909|3.211|because there are entire workshops and
1384.47|3.569|particularly on creating videos like
1386.12|4.98|these where we are basically achieving
1388.039|4.531|depth directly from images and this is
1391.1|3.12|done of course no human can annotate
1392.57|2.459|depth so this is done using social
1394.22|2.429|supervised techniques
1395.029|3.961|so in particular we take an image we
1396.649|3.66|predict a depth then one you have when
1398.99|3.09|you have a depth for an image you can
1400.309|3.87|cast out all the pixels into 3d and you
1402.08|3.599|can we project them either in two camera
1404.179|3.901|views at that same time but different
1405.679|4.141|cameras or you can report them into the
1408.08|3.42|future frames of that single camera and
1409.82|3.87|then you have a photometric loss that's
1411.5|4.86|an enforcement consistency and so the
1413.69|4.14|only way to predict to make everything
1416.36|3.48|consistent in reproductions
1417.83|3.63|is to predict the correct depth and so
1419.84|3.179|this learns in this all surprise fashion
1421.46|3.299|to predict up and then we can simulate a
1423.019|4.351|lot of our inputs directly from vision
1424.759|4.41|and use this down stream to make these
1427.37|4.32|bird's eye-view predictions and as if
1429.169|3.84|you as you might be familiar the gap is
1431.69|2.79|quickly closing instead of the art
1433.009|2.681|approaches if you have if you give
1434.48|3.62|yourself wider and how
1435.69|3.61|versus if you do not have lidar but you
1438.1|2.91|just use vision techniques and you
1439.3|3.87|pseudo lidar approaches and that gap is
1441.01|7.61|quickly shrinking in academia and we see
1443.17|7.98|a lot of this as well internally finally
1448.62|4.03|I've shown you sort of how this software
1451.15|3.3|2.0 stack is expanding through the code
1452.65|4.38|it's eating some of the you know
1454.45|4.05|occupancy tracker like techniques the
1457.03|3.9|logical conclusion of that of course is
1458.5|4.32|there's still a perception system that
1460.93|3.75|creates explicit predictions and those
1462.82|3.78|explicit predictions are one shown in
1464.68|4.14|the ice the instrument cluster and two
1466.6|4.64|they are used for a policy and this
1468.82|5.13|policy is still in the land of 1.0 where
1471.24|4.15|for us and for many others as well where
1473.95|3.75|you have explicit planner that takes all
1475.39|3.84|the predictions and drives on that the
1477.7|3.81|problem with that is your explicit
1479.23|3.72|predictions will are basically doomed to
1481.51|3.6|never be good enough and never be
1482.95|3.93|complete and so writing these planners
1485.11|3.54|is extremely difficult error-prone lots
1486.88|3.45|of hyper parameters very tricky and so
1488.65|3.78|the logical conclusion of this of course
1490.33|3.78|is that we'd like to train your networks
1492.43|4.02|to actually do a lot of this planning
1494.11|4.74|inside the network in particular we have
1496.45|3.57|huge data sets of people driving cars so
1498.85|2.76|when people drive cars and they steer
1500.02|3.06|the wheel they're actually data labeling
1501.61|3.18|for you they're showing you how to drive
1503.08|6.24|through any into any intersection or any
1504.79|5.61|other kind of place and the other thing
1509.32|3.51|I'll say is like most of what I've
1510.4|4.53|described so far this relies primarily
1512.83|3.6|on self super part on the supervised
1514.93|3.63|learning with the exception of depth
1516.43|4.59|where we massage and create massive data
1518.56|4.23|set but but we've seen recently with the
1521.02|2.82|use of for example contrasted losses and
1522.79|2.58|things like that there's a lot of
1523.84|3.21|progress today in cell supervised
1525.37|3.57|learning and so we'd like to leverage
1527.05|4.8|some of that in a team here's an example
1528.94|5.19|of just some videos we have probably the
1531.85|3.9|most interesting largest data set of
1534.13|3.39|videos these are coming from cameras and
1535.75|3.27|so we've been really looking into some
1537.52|4.83|of these cell surprise techniques to
1539.02|5.07|speed up the process and to speed up the
1542.35|3.03|rate at which we learn from very little
1544.09|2.94|supervised data so we don't have to
1545.38|5.19|collect like tens hundreds of thousands
1547.03|11.28|of examples of except right turn we can
1550.57|8.94|do it we prefer not to okay so I showed
1558.31|3.06|you basically how we are improving the
1559.51|3.33|safety and convenience of driving today
1561.37|4.02|and how we deploy deep learning into
1562.84|4.08|production and support all the features
1565.39|2.399|of the auto pal today and then I also
1566.92|1.979|showed you all the
1567.789|2.791|we are doing to develop full
1568.899|3.39|self-driving how the neural net is
1570.58|4.14|eating through the software stack and
1572.289|5.401|how we are putting a vision and AI at
1574.72|5.399|the front and center of this effort so
1577.69|4.89|if you'd like to make your AI expertise
1580.119|5.071|count I think there is basically no more
1582.58|4.169|impactful or better place to apply some
1585.19|3.03|of that expertise then at Tesla today
1586.749|3.24|and if you'd like to be a part of what
1588.22|3.87|I've shown you then come to Tesla
1589.989|3.331|dot-com / autopilot ai and you can just
1592.09|2.85|directly apply them the page is
1593.32|3.989|extremely painless and that just comes
1594.94|4.5|directly to us and you can help work
1597.309|5.48|with us too you know and make this all
1599.44|3.349|work so thank you
1604.79|4.86|[Applause]
1607.16|5.64|Thank You Andre that was that was
1609.65|5.97|awesome so so we have time for a couple
1612.8|6.77|of questions while while Ilya is setting
1615.62|3.95|up hi
1619.6|5.91|so when you do these estimations let's
1622.55|5.13|say of a stop sign and other cars other
1625.51|3.13|vehicles in your fleet have driven by it
1627.68|2.73|before do you have a way of
1628.64|3.36|incorporating the prior from their
1630.41|3.48|estimation or you have to reassume eight
1632.0|3.81|from scratch yep
1633.89|3.81|so we do collect maps we just don't
1635.81|3.33|collect high-definition maps like when a
1637.7|2.76|way mow or some plant that is driving
1639.14|5.97|through an environment they know that
1640.46|6.33|the leaf on that tree is 15.5 three
1645.11|3.21|meters away like two centimeter level
1646.79|3.03|accuracy we don't know about the leaf of
1648.32|3.21|that tree but we do know that there's a
1649.82|3.6|stop sign somewhere in the vicinity here
1651.53|4.41|and so we do build low definition Maps
1653.42|3.96|we do map stop signs traffic lights and
1655.94|3.57|things like that because it provides a
1657.38|3.99|second layer and then also that helps us
1659.51|2.91|again like a mission it helps us with
1661.37|3.03|all the trigger infrastructure for
1662.42|3.6|sourcing examples because we can look
1664.4|2.94|for discrepancies between map and vision
1666.02|2.7|and that's a really good signal for us
1667.34|3.84|for getting lots of more images of
1668.72|4.77|really tricky cases so like I drove by
1671.18|3.81|the stop sign yesterday yes I asked
1673.49|4.97|tomato does a stop sign yes drive by it
1674.99|3.47|today yes thank you so much okay
1679.24|4.78|hi under thank you for the great talk
1681.83|4.35|I'm very interested in the software 2-0
1684.02|6.06|part and I follow progress I think you
1686.18|5.61|mentioned it at scaled Emmaus I wonder
1690.08|3.09|what's your overall vision for this
1691.79|3.36|what's on the main findings this is
1693.17|4.26|something that will supplant programming
1695.15|3.69|languages will be kind of changed the
1697.43|3.39|way that the science is done what they
1698.84|4.41|are visual for this and can the
1700.82|4.83|community help you know is it something
1703.25|4.32|that you know everybody can use to
1705.65|4.08|improve rapidly the whole progress with
1707.57|3.99|the designs yeah so thank you that's a
1709.73|4.65|very broad question I think what I what
1711.56|5.01|I've seen so far is just porting
1714.38|4.38|functionality from software 1.0 2.0 is
1716.57|4.56|not always a good idea it's good idea
1718.76|3.78|sometimes you're actually it's a
1721.13|3.42|different way of programming but you're
1722.54|4.17|you're placing yourself in a very
1724.55|4.11|indirect control of the final of the
1726.71|4.59|final function so sometimes you just
1728.66|4.14|want to like write a rule if you're
1731.3|3.09|doing it in a software 2.0 stack
1732.8|2.82|everything is so indirect because you're
1734.39|2.37|massaging the data set and you're going
1735.62|3.45|through a training process that takes
1736.76|3.22|days the iteration is slower you have to
1739.07|2.5|do all of this data
1739.98|3.42|engine stuff so anything that's in the
1741.57|4.77|software to pronunce tactic has a cost
1743.4|5.13|to it it you're committing to a lots of
1746.34|4.32|data engine costs and any new problem
1748.53|4.5|that you find suddenly requires a whole
1750.66|3.72|data engine passing curation and so
1753.03|3.269|that's not always a win it's just
1754.38|3.33|sometimes a win and so what we see
1756.299|3.75|actually is we kind of like combine
1757.71|4.14|software 1.0 and 2.0 so the old older
1760.049|3.301|systems as I would describe them in the
1761.85|3.329|software on panel stack they don't
1763.35|3.54|always go away you almost think of it as
1765.179|3.151|like sedimentary layers where you have
1766.89|3.09|the new functionality but the software
1768.33|3.75|monpa notice is used for example to keep
1769.98|4.86|sort of guarding rails a lot around the
1772.08|5.07|software 2.0 part so we almost see them
1774.84|4.35|as you do a bit of both and they all
1777.15|4.26|they both have pros and cons but I do
1779.19|3.96|think that the trend to large extent has
1781.41|6.509|been towards the software 2.0 it is a
1783.15|6.75|more powerful sort of is a more powerful
1787.919|3.451|way of addressing a lot of problems that
1789.9|3.63|are very messy and really hard to code
1791.37|4.83|and which is a lot of problems in the
1793.53|7.019|world but we definitely see that they
1796.2|6.96|come with their own pros and cons thank
1800.549|6.301|you drea we should move on I really
1803.16|6.91|appreciate your time and thanks again
1806.85|3.22|[Applause]