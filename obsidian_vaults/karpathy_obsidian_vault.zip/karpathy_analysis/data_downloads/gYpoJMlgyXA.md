start_time|end_time|text
0.0|3.899|um how are you guys doing by the way
2.76|2.7|with the assignment our most have you
3.899|3.63|finished anyone finished put up your
5.46|5.07|hands okay good so we're doing decent
7.529|4.52|okay good I'll be holding up make up
10.53|3.84|office hours right after this class
12.049|4.451|assignment two will be released tomorrow
14.37|3.749|or day after tomorrow we haven't fully
16.5|3.72|finalized the date we're still working
18.119|3.901|on it and we're changing it from last
20.22|3.21|year and so we're in process of
22.02|3.749|developing it and we are hope to have it
23.43|6.749|as soon as possible it's meaty but
25.769|6.781|educational so you do want to get
30.179|4.861|started on it ASAP once it's released
32.55|4.23|we might be adjusting the due date for
35.04|5.82|some into because it is slightly larger
36.78|6.029|and yeah so so we'll be shuffling some
40.86|3.719|of the these things around and also the
42.809|3.421|grading scheme all this stuff is kind of
44.579|2.82|just tentative and subject to change
46.23|2.55|because we're still trying to figure out
47.399|3.601|the course it's still relatively new and
48.78|4.07|a lot of it is changing so those are
51.0|4.17|just some heads-up items before we start
52.85|3.88|now in terms of your project proposal by
55.17|4.68|the way which is due in roughly ten days
56.73|4.11|I wanted to just bring up a few points
59.85|4.589|because you'll be thinking about your
60.84|5.099|project and some of you might have some
64.439|4.321|misconceptions about what makes a good
65.939|4.801|or bad project so just to point out a
68.76|3.359|few of them the most common one probably
70.74|3.15|is that people are hesitant to work with
72.119|3.061|datasets that are small because they
73.89|3.21|think that commnets require a huge
75.18|2.88|amount of data to Train and this is true
77.1|2.25|there's hundreds of millions of
78.06|3.989|parameters in a continent and they need
79.35|4.379|training but actually for your purposes
82.049|3.39|in the project this is kind of a myth
83.729|2.941|this is not something you have to worry
85.439|3.301|about a lot you can work with smaller
86.67|3.659|datasets and it's okay the reason it's
88.74|3.18|okay is that we have this process that
90.329|3.33|we'll go into much more detail down the
91.92|3.839|later in the class called fine-tuning
93.659|3.991|and the thing is that in practice you
95.759|3.631|rarely ever train these giant
97.65|3.719|convolutional networks from scratch you
99.39|3.99|almost always do this pre training and
101.369|4.29|fine-tuning process so the way this will
103.38|3.96|look like is you almost always take a
105.659|3.691|convolutional network you trained on
107.34|3.63|some large data set of say images like
109.35|3.0|say on image net huge amount of data and
110.97|3.179|then you're interested in some other
112.35|3.33|data set right there and you can't train
114.149|3.631|your comment on your small data set so
115.68|4.14|we'll train it here and then we'll
117.78|4.29|transfer it over there and the way this
119.82|3.75|transfer works like is so here's a
122.07|3.18|schematic of a convolutional neural
123.57|3.149|network we start with the image on top
125.25|3.69|and we'll go through a series of layers
126.719|3.57|down to a classifier so you're used to
128.94|3.18|this but we haven't of course talked
130.289|3.241|about the specific layers here but we
132.12|3.0|take that image net
133.53|3.15|pre-trained network we trained on
135.12|3.54|imagenet and then we chop off the top
136.68|4.26|layer the classifier we chop that off
138.66|3.87|take it away and we train the entire
140.94|3.81|convolutional network is a fixed feature
142.53|3.48|extractor and so you can put that
144.75|2.82|feature extractor on top of your new
146.01|2.97|data set and you're just going to swap
147.57|3.48|in a different layer that performs the
148.98|4.26|classification on top and so depending
151.05|3.84|on how much data you have you're only
153.24|3.36|going to train the last layer of your
154.89|3.24|convolutional network or you can do fine
156.6|2.97|tuning where we actually back propagate
158.13|3.0|through some portions of the comment and
159.57|2.82|if you have more data you're going to do
161.13|5.43|back propagation deeper through the
162.39|6.96|network and in particular this
166.56|4.56|pre-training step on image net people do
169.35|3.06|this for you so there's a huge amount of
171.12|3.03|people who've trained convolutional
172.41|4.079|networks over long periods of time weeks
174.15|4.11|on different data sets and then they
176.489|3.451|upload the weights of the ComNet online
178.26|3.75|so there's something called the cafe
179.94|3.269|model Zoo for example and these are all
182.01|3.12|these convolutional net works that have
183.209|3.721|been pre trained on large data sets they
185.13|3.48|already have lots of the parameters
186.93|3.029|learned and so you just take this around
188.61|3.03|then you swap in your data set and you
189.959|2.941|fine-tune through the network so
191.64|3.51|basically if you don't have a lot of
192.9|3.72|data that's okay and you just take a
195.15|3.899|preacher in combat and you just
196.62|3.57|fine-tune it and so don't be afraid to
199.049|5.581|work with smaller data set that's going
200.19|6.06|to work out ok the second thing that we
204.63|3.93|solve some problems with last time is
206.25|4.709|that people think they have infinite
208.56|4.02|compute and this is also a myth I just
210.959|3.271|like to point out don't be overly
212.58|3.689|ambitious in what you propose these
214.23|3.3|things take a while to train you don't
216.269|3.061|have too many GPUs you're going to have
217.53|3.209|to do hyper air optimization there's a
219.33|3.3|few things you have to worry about here
220.739|4.381|so we had some projects last year where
222.63|4.5|people proposed projects of training on
225.12|5.149|very large data sets and you just won't
227.13|5.52|have the time so be mindful of that and
230.269|3.581|yeah you'll get a better sense as we go
232.65|3.71|through the class and what is or is not
233.85|5.609|possible given your computer constraints
236.36|4.57|ok so we're going to dive into lectures
239.459|2.791|are there any administrative things that
240.93|4.2|I may be left out that you'd like to ask
242.25|4.56|about ok good so we're going to dive
245.13|4.59|into the material we have quite a bit of
246.81|4.53|it today so just a reminder we're
249.72|3.15|working in this framework of many bad
251.34|3.209|stochastic gradient descent for training
252.87|3.089|of neural networks and basically it's a
254.549|3.451|four-step process training a neural
255.959|5.161|network is as simple as 1 2 3 4 you
258.0|4.56|sample your data so a batch of your data
261.12|3.96|from a data set you forward it through
262.56|4.44|your network to compute the loss you
265.08|3.15|back propagate to compute your grade
267.0|3.15|ian's and then you do a parameter update
268.23|3.95|where you tweak your weights slightly in
270.15|3.96|the direction of the gradient and so
272.18|3.61|when you end up repeating this process
274.11|3.39|then really what this comes down to is
275.79|3.45|an optimization problem where in the
277.5|2.88|weight space we're converging into areas
279.24|2.55|of the weight space where you have low
280.38|3.99|loss and that means you're correctly
281.79|4.32|classifying your training center and we
284.37|3.45|saw that these neural networks can get
286.11|3.42|very large and I flash this image of a
287.82|3.15|neural Turing machine basically these
289.53|2.85|are huge computational graphs and we
290.97|3.54|need to do back propagation through them
292.38|3.51|and so we talked about intuitions of
294.51|2.76|back propagation and the fact that it's
295.89|3.27|really just a recursive application of
297.27|3.93|chain rule from back of the circuit to
299.16|4.2|the front where we're changing gradients
301.2|4.31|through all the local operations we
303.36|4.26|looked at some implementations of this
305.51|4.06|concretely with the forward-backward api
307.62|4.38|on both a copy to a computational graph
309.57|4.5|and also in terms of its nodes which
312.0|3.56|also implement the same api and do
314.07|4.47|forward propagation and back propagation
315.56|5.23|we looked at specific examples in torch
318.54|3.24|and cafe and I drew this analogy that
320.79|3.57|these are kind of like your little
321.78|4.05|blocks these layers or gates are your
324.36|4.17|little blocks from which you build out
325.83|4.29|the entire combinational networks then
328.53|3.389|we talked about neural networks first
330.12|3.18|without the brain stuff and basically
331.919|3.451|what that amounts to as we're making
333.3|4.56|this F which goes from your image to
335.37|4.29|class course more complex and then we
337.86|3.69|looked at neural networks from the brain
339.66|3.569|stuff perspective where this is a crude
341.55|4.46|analogy of a neuron and what we're doing
343.229|4.891|is we're stacking these URLs in layers
346.01|3.25|okay so that's roughly what we're doing
348.12|2.67|right now and we're going to talk in
349.26|3.23|this class about this process of
350.79|4.74|training neural networks effectively
352.49|4.929|okay so we're going to go into that
355.53|3.33|before I dive into the details of it I
357.419|4.261|just wanted to kind of pull out and give
358.86|5.01|you a zoomed out view of a bit of a
361.68|4.47|history of how this field evolved over
363.87|4.38|time so if you try to find where this
366.15|3.87|field where it comes from when were the
368.25|4.16|personal networks proposed and so on you
370.02|5.25|probably will go back to roughly 1960
372.41|3.759|where Frank Rosenblatt in 1957 was
375.27|3.66|playing around with something called
376.169|5.881|perceptron and the perceptron basically
378.93|6.239|it ended up being this implementation in
382.05|4.38|hardware so they all had to like they
385.169|3.091|didn't just write code right they
386.43|5.37|actually had to build these things out
388.26|8.7|from circuits and electronics in these
391.8|7.91|times for the most part and so basically
396.96|5.42|the perceptron roughly was this funk
399.71|4.65|here and it looks very similar to what
402.38|4.35|we're familiar with it's just a W X plus
404.36|4.41|B but then the activation function which
406.73|3.39|were used to as a sigmoid that
408.77|3.6|activation function was actually a step
410.12|4.32|function it was either 1 or 0 it was a
412.37|4.05|binary step function and so since this
414.44|3.06|is a binary step function you'll notice
416.42|3.63|that this is non differentiable
417.5|3.9|operation so they were not able to back
420.05|2.85|propagate through this in fact the
421.4|2.64|concept of back propagation for training
422.9|3.21|neural networks had to come much later
424.04|4.11|and so they came up with these binary
426.11|4.17|stepwise functions perceptron and they
428.15|4.23|came up with these learning rules and so
430.28|4.02|this is an kind of an ad hoc specified
432.38|4.71|learning rule that tweaked the weights
434.3|5.07|to make the desired outcome from the
437.09|5.52|perceptron match the true of the true
439.37|4.56|desired values but there was no concept
442.61|2.85|of a loss function there was no concept
443.93|3.45|of back propagation is these ad hoc
445.46|3.6|rules which when you look at them they
447.38|3.09|kind of almost do background but it's
449.06|3.36|kind of funny because of the step
450.47|4.02|function which is not differentiable and
452.42|4.41|then people started to stack these so in
454.49|4.47|roughly 1960 with the advent of Adeline
456.83|4.56|and Madeline by Woodrow and Huff they
458.96|4.26|started to take these perceptron like
461.39|4.59|things and stack them into the first
463.22|5.46|multi-layer perceptron networks and this
465.98|4.29|was still all done in this electronics
468.68|4.8|analogy and actually building out from
470.27|4.89|hardware and but still there's no back
473.48|3.24|propagation at this time this was all
475.16|3.33|these rules that they've come up with in
476.72|3.27|terms of like thinking about trying to
478.49|3.9|flip bits and seeing if it works better
479.99|3.96|or not and it was kind of a there was no
482.39|3.84|view of back propagation at this time
483.95|3.81|and so roughly in 1960 people got very
486.23|3.06|excited and building out these circuits
487.76|2.73|and they thought that you know this
489.29|3.48|could go really far we can have these
490.49|4.41|circuits that learn you have to remember
492.77|4.44|that back then the concept of
494.9|4.08|programming was very explicit you write
497.21|3.15|a series of instructions for a computer
498.98|2.79|and this is the first time that people
500.36|2.91|who are thinking about this kind of
501.77|3.78|data-driven approach where you have some
503.27|3.87|kind of a circuit that can learn and so
505.55|4.41|this was at the time a huge conceptual
507.14|4.59|leap that people are very excited about
509.96|4.2|unfortunately these networks would not
511.73|2.79|actually end up working very well right
514.16|2.43|away
514.52|3.06|so in terms of 1960 for example they got
516.59|2.58|slightly overexcited
517.58|3.36|and over-promised and then slightly
519.17|4.47|under delivered and so throughout the
520.94|4.53|period of 1970s actually the field of
523.64|5.13|neural networks was very quiet and not
525.47|5.46|much research has been done the next
528.77|4.89|boost actually came about roughly in
530.93|4.529|1986 and in 1980
533.66|3.9|people there was this influential paper
535.459|5.521|that basically is the first time that
537.56|5.94|you see back propagation like rules in a
540.98|6.029|nicely presented format and so this is
543.5|4.319|real hard Hinton and Wilson and they
547.009|2.7|were playing with multi-layer
547.819|2.76|perceptrons and this is the first time
549.709|2.011|when you go to the paper where you
550.579|3.18|actually see something that looks like
551.72|4.229|back propagation and so at this point
553.759|4.051|they already discarded this idea of ad
555.949|2.94|hoc rules and they formulate the lochs
557.81|2.579|function and talked about back
558.889|3.541|replication and gradient descent and so
560.389|5.01|on and so this time people got excited
562.43|4.589|again in 1986 because they felt that
565.399|5.401|they now had a principled nice credit
567.019|4.831|assignment kind of scheme by back
570.8|3.45|propagation and they could train
571.85|3.719|multi-layer networks the problem
574.25|2.639|unfortunately was that when they tried
575.569|3.301|to scale up these networks to make them
576.889|3.541|deeper or larger they didn't work very
578.87|2.55|well compared to some of the other
580.43|3.12|things that might be in your machine
581.42|4.169|learning toolkits and so they just did
583.55|5.13|not give very good results at this time
585.589|4.56|and training would get stuck and that
588.68|2.909|propagation was basically not working
590.149|3.99|very well especially if you wanted to
591.589|4.29|have large deep networks and this was
594.139|3.481|the case for actually roughly 20 years
595.879|2.791|where again there was less research on
597.62|2.88|your own networks because somehow it
598.67|4.859|wasn't working very well enough and you
600.5|4.529|couldn't train deep nets and in 2006 the
603.529|3.48|research was research was again
605.029|4.86|reinvigorated with a paper in science by
607.009|6.18|Hinton and Ann Russell ocarina select
609.889|5.01|enough I can't say his name sorry but
613.189|2.941|basically what they found here was this
614.899|2.821|was roughly the first time where you can
616.13|4.019|actually have like say a 10 layer neural
617.72|5.07|network that trains properly and what
620.149|3.841|they did was instead of training all the
622.79|3.33|layers like ten layers by
623.99|3.599|backpropagation at a single pass they
626.12|2.55|came up with this unsupervised pre
627.589|2.971|training scheme using what's called
628.67|3.21|restricted Boltzmann machine and so what
630.56|2.969|this amounts to is you train your first
631.88|3.449|layer using an unsupervised objective
633.529|3.571|and then you train your second layer on
635.329|3.391|top of it and then third and fourth and
637.1|3.03|so on and then once all of these are
638.72|3.809|trained then you put them all together
640.13|4.23|and then you start back propagation then
642.529|3.48|you start the fine-tuning step so it was
644.36|3.18|a two step process of first we do the
646.009|3.421|Spree training stepwise through the
647.54|4.38|layers and then we plug them in and then
649.43|3.959|back propagation works and so this was
651.92|2.909|the first time where back propagation it
653.389|2.851|needed basically this initialization
654.829|2.671|from the unsupervised retraining
656.24|3.24|otherwise they would not work out of
657.5|4.23|like from scratch and we're going to see
659.48|4.32|why in this lecture it's kind of tricky
661.73|3.779|to get these deep networks to train from
663.8|3.33|scratch using just back wrap and you
665.509|3.691|have to really think about it
667.13|3.09|and so it turned out later that you
669.2|2.52|actually don't need this a surprise
670.22|3.36|process you can just train with backdrop
671.72|4.26|right away but you have to be very
673.58|4.05|careful with initialization and they
675.98|3.81|used sigmoid networks at this point and
677.63|4.08|sigmoid are just not a great activation
679.79|3.69|function to use and so basically
681.71|4.8|backdrop works but you have to be
683.48|5.73|careful in how you use it and so this
686.51|4.5|was in 2006 so a bit more researchers
689.21|3.36|kind of came back to the area and it was
691.01|4.17|rebranded as deep learning but really
692.57|8.25|it's still neural networks synonymous
695.18|7.05|but it's a better word for uh PR and so
700.82|3.18|basically at this point things started
702.23|3.57|to work relatively well and people could
704.0|3.63|actually train these deeper networks now
705.8|4.02|still not too many people paid attention
707.63|3.45|and when people started to really pay
709.82|4.56|attention was roughly I think around
711.08|4.95|2010 and 2012 so specifically in 2010
714.38|3.3|there were the first really big results
716.03|3.24|where neural networks really worked
717.68|2.64|really well compared to everything else
719.27|5.1|that you had in your machine learning
720.32|7.08|toolkit like say uh kernels or SVM's and
724.37|4.74|so on and this was specifically in the
727.4|4.62|speech recognition area where they took
729.11|4.53|this on G mm-hmm framework and they
732.02|3.45|swapped at one part and subbed in the
733.64|3.87|neural network and that neural network
735.47|4.53|gave them huge improvements in 2010 and
737.51|3.57|this was worked on Microsoft and so
740.0|2.37|people start to pay attention because
741.08|5.22|this was the first time neural networks
742.37|6.24|really gave a large improvements and
746.3|5.52|then we saw that again in 2012 where it
748.61|4.56|played out even more dramatically in in
751.82|4.31|the domain of visual recognition in
753.17|7.55|computer vision where basically we took
756.13|6.7|this 2012 Network by Alice kuchizuke
760.72|4.15|Ilya sutskever and Geoff Hinton and
762.83|3.06|basically it crushed all the competition
764.87|4.23|from all the features and there was a
765.89|6.27|really large improvement from these
769.1|4.17|neural networks that we witnessed and
772.16|2.82|that's when people really start to pay
773.27|3.54|attention and that's since then the
774.98|3.39|field has kind of exploded and there's a
776.81|4.8|lot of area done in this field now and
778.37|4.86|so we'll go into details I think a bit
781.61|3.45|later in a classroom why it started to
783.23|5.16|work really in 2010 it's a combination
785.06|4.65|of things but I think it's we got we
788.39|3.32|figured out better ways of initializing
789.71|4.98|of getting these things to work of
791.71|4.63|activation functions and we had GPUs and
794.69|3.57|we had much more data and so really a
796.34|3.24|lot of the stuff before didn't quite
798.26|2.639|work because it was just not there in
799.58|2.729|terms of compute data
800.899|3.841|and some of the ideas just needed a
802.309|4.741|tweaking okay
804.74|4.129|and so that's rough a historical setting
807.05|3.42|so we basically went through
808.869|2.94|over-promising under the luring
810.47|3.659|over-promising under the reloading and
811.809|3.911|now it seems like things are actually
814.129|4.041|starting to work really well and so
815.72|4.44|that's where we are at this point okay
818.17|3.82|so I'm going to no doubt into the
820.16|2.969|specifics and we'll see exactly we'll
821.99|3.06|actually dive into neural networks and
823.129|3.15|how you train them properly so the
825.05|3.269|overview of what we're going to cover
826.279|4.47|over the course of next two lectures is
828.319|4.291|a whole bunch of independent things so
830.749|3.18|I'll just be kind of peppering you with
832.61|3.269|all these little areas that we have to
833.929|4.051|understand and see what people do in
835.879|3.45|each case and we'll go through them the
837.98|2.699|pros and cons of all choice is how you
839.329|6.24|actually properly train these neural
840.679|5.64|networks in our real-world data sets so
845.569|3.06|the first thing we're going to talk
846.319|6.531|about is activation functions as I
848.629|6.361|promised I think a lecture so ago so
852.85|5.649|activation function is this function f
854.99|5.25|at the top of the neuron and we saw that
858.499|3.78|it can have many different forms so
860.24|4.98|sigmoid 10h relu these are all different
862.279|4.23|proposals for what these activation
865.22|2.459|functions can look like we're going
866.509|2.731|through go through some pros and cons
867.679|3.15|and how you think about what an
869.24|3.87|activation what are good desirable
870.829|3.781|properties of an activation function so
873.11|3.05|historically the one that has been used
874.61|3.419|the most is the sigmoid non-linearity
876.16|3.25|which looks like this
878.029|3.06|so it's basically squashing function it
879.41|4.289|takes a real-valued number squashes it
881.089|5.16|to be between 0 & 1 and so the first
883.699|5.7|problem with the sigmoid is that as was
886.249|5.64|pointed out a few lectures ago there's a
889.399|4.141|problem that saturated neurons which are
891.889|5.31|neurons that output either very close to
893.54|5.82|0 or very close to 1 those neurons kill
897.199|3.39|gradients during back propagation and so
899.36|3.209|I'd like to expand on this and show you
900.589|3.151|exactly what this means and this
902.569|2.13|contributes to something that will go
903.74|4.409|into called the vanishing gradient
904.699|5.76|problem so let's look at a sigmoid gate
908.149|4.471|in the back in the circuit it received
910.459|4.531|some value X and Sigma of X comes out
912.62|4.23|and then in backprop we have DL by D
914.99|3.839|Sigma and we'd like to back drop it
916.85|4.289|through the sigmoid gate to using chain
918.829|4.74|rule so that we have DL by DX at the end
921.139|3.841|and you can see that through chain rule
923.569|3.3|basically tells us to multiply those two
924.98|3.99|quantities and so think about what
926.869|4.351|happens when this sigmoid gate receives
928.97|4.58|input of either negative 10 or 0 or 10
931.22|3.53|it computes some value and
933.55|3.33|and it's getting some gradient from the
934.75|4.14|top and what happens to that gradient as
936.88|4.649|you backdrop through the circuit in any
938.89|15.78|of these cases what is the possible
941.529|14.701|problem in some of these cases so okay
954.67|3.81|so you're saying that the gradient is
956.23|5.669|very low when X is negative 10 or 10 and
958.48|4.859|the way to see this is basically we have
961.899|3.721|this local gradient here that we'll be
963.339|5.401|multiplying with this gradient there's
965.62|4.469|local gradient defy the Sigma by DX when
968.74|3.18|you're at negative 10 you can see that
970.089|3.651|the gradient is basically zero because
971.92|4.349|the slope at this point is zero and
973.74|4.719|gradient at 10 will also be near zero
976.269|3.781|and so the issue is that your gradient
978.459|2.971|will drop in from here but if your
980.05|4.469|neuron is saturated so it basically
981.43|5.67|either output it zero or I'd put it 1
984.519|4.26|then the gradient will be killed it'll
987.1|4.29|just be multiplied by a very tiny number
988.779|4.591|and gradient flow will stop through them
991.39|5.04|through the sigmoid neuron so you can
993.37|4.74|imagine if you have a large network of
996.43|3.33|sigmoid neurons and many of them are in
998.11|3.63|a saturated regime where they're either
999.76|3.3|0 or 1 then gradients can't back
1001.74|3.99|propagate through the network because
1003.06|4.769|they'll be stopped if your Sigma neurons
1005.73|3.9|are in these saturated regimes the
1007.829|3.421|gradients only flow if you're kind of in
1009.63|3.99|a safer zone and what we call an active
1011.25|5.31|region of a sigmoid and so that's kind
1013.62|6.24|of a problem we'll see a bit more about
1016.56|5.55|this soon another problem with sigmoids
1019.86|4.17|is that their outputs are not 0 centered
1022.11|4.62|so we'll talk about data pre-processing
1024.03|3.929|soon but you always want to when you pre
1026.73|3.449|process your data you want to make sure
1027.959|3.931|that it's 0 centered right and in this
1030.179|3.331|cases suppose you have a big network of
1031.89|3.39|several layers of Sigma your neurons
1033.51|4.559|they're outputting these non zero
1035.28|4.71|centered values between 0 & 1 and we're
1038.069|3.24|putting more basically linear
1039.99|3.329|classifiers that we're stacking on top
1041.309|4.38|of each other and the problem roughly
1043.319|3.901|with non 0 centered outputs I'll just
1045.689|4.431|try to give you a bit of an intuition on
1047.22|2.9|what goes wrong
1050.179|4.24|so consider a neuron that computes this
1052.919|4.441|function right so it's a sigmoid neuron
1054.419|5.611|looking at its just computing WX plus B
1057.36|3.99|and what can we say about think about
1060.03|3.75|what you can say about the gradients on
1061.35|5.36|W during back propagation if your axis
1063.78|4.399|are all positive in this
1066.71|2.91|between zero and one so maybe you're a
1068.179|3.151|neuron somewhere deep in the network
1069.62|11.549|what can you say about the weights if
1071.33|14.839|all the XS are positive numbers they're
1081.169|5.0|kind of constrained in a way go ahead
1087.94|4.03|right so what you said is all the
1090.049|4.5|gradients with W are either all positive
1091.97|5.22|or all negative and that is because
1094.549|3.691|gradient flows in from the top and if
1097.19|2.64|you think about the expression for all
1098.24|4.26|the W gradients
1099.83|5.25|they're basically x times the gradient
1102.5|4.529|on F and so the gradient of on at the
1105.08|4.229|output of the neuron is positive then
1107.029|4.741|all your W gradients will be positive
1109.309|4.021|and vice versa so basically you end up
1111.77|3.48|with this case where it's suppose you
1113.33|3.63|have just two weights so you have the
1115.25|3.12|first weight in a second weight what
1116.96|4.29|ends up happening is either all your
1118.37|4.559|gradient for that for that as this as
1121.25|2.82|this input goes through and you compute
1122.929|2.551|your radiant in the weights they're
1124.07|3.78|either all positive or they're all
1125.48|3.99|negative and so the issue is that you're
1127.85|3.299|constrained in the kind of update you
1129.47|4.11|can make and you end up with this
1131.149|4.591|undesirable zigzagging path if you want
1133.58|4.17|to get to some parts that are outside of
1135.74|5.159|these regions so it's kind of like a
1137.75|4.32|slightly hand wavy reason here but just
1140.899|2.491|to give you intuition and you can see
1142.07|2.7|this empirically when you train with
1143.39|3.72|things that are not zero centered you'll
1144.77|4.71|observe slower convergence and this is a
1147.11|4.89|bit of a hand wavy reason for why that
1149.48|3.99|might happen but I think if you actually
1152.0|2.82|wanted to go much deeper into that you
1153.47|2.88|can and there are papers written about
1154.82|3.12|this but you have to then reason about
1156.35|3.09|mathematics of Fisher matrices and
1157.94|2.28|natural gradients and it gets a bit more
1159.44|2.4|complex than this
1160.22|3.42|but I just wanted to give you intuition
1161.84|3.51|for you want to have zero centered
1163.64|3.149|things in the input you want to have
1165.35|3.0|zero central things throughout other Y
1166.789|4.051|thinks things don't converge as nicely
1168.35|5.28|and so that is a downside of a sigma on
1170.84|5.579|your own and the last one is that X
1173.63|4.44|function inside this expression is kind
1176.419|3.38|of expensive to compute compared to some
1178.07|5.01|of the alternatives of other
1179.799|5.711|nonlinearities and so it's just a small
1183.08|3.93|detail I suppose when you actually train
1185.51|3.06|these large convolutional networks most
1187.01|4.11|of the compute time is in convolutions
1188.57|4.589|and these dot products it's not in this
1191.12|3.45|X operation and so it's kind of
1193.159|2.341|vanishingly small contribution but it's
1194.57|3.479|still something that is a bit of a
1195.5|4.799|downside compared to the other parts so
1198.049|4.32|I'll go into 10h and I'll ask a few
1200.299|3.51|I'll take a few questions then so 10h is
1202.369|3.18|an attempt to fix one of these problems
1203.809|5.79|in particular the fact that it's non
1205.549|6.75|zero centered sigmoid so yell Hakuna in
1209.599|3.96|1991 right I wrote a very nice paper on
1212.299|2.73|how you optimize neural networks and
1213.559|4.71|I've linked to it from the syllabus and
1215.029|5.46|he recommended that people use a 10 H of
1218.269|3.75|X instead of sigmoid and 10 H of X
1220.489|4.22|basically is kind of like two signals
1222.019|5.37|put together you end up with being
1224.709|5.68|between negative 1 and 1 and so your
1227.389|4.23|outputs are 0 centered but otherwise you
1230.389|2.64|have still some some of the other
1231.619|3.331|problems like for example you have these
1233.029|4.05|regions where if your neurons get
1234.95|4.189|saturated no gradients flow and so we
1237.079|5.52|haven't really fixed that at this point
1239.139|5.98|but so 10 ages I think strictly prefer
1242.599|6.98|to sigmoid because it has all the same
1245.119|4.46|problems except for one ok
1250.879|6.21|I'll continue and then maybe we can take
1252.649|6.6|more questions so around 2012 in the
1257.089|3.57|paper by oskar jerski this is the first
1259.249|3.06|convolutional net worths paper they
1260.659|4.05|proposed that actually they noticed that
1262.309|5.58|this non-linearity where you use max of
1264.709|4.38|0 and X instead of sigmoid or 10h just
1267.889|2.73|makes your networks converge much
1269.089|4.8|quicker and in their experiments almost
1270.619|6.15|by a factor of 6 and so we can go back
1273.889|4.86|and try to think about why is this and
1276.769|3.24|we're kind of reading into it like you
1278.749|3.96|can see that it works better in practice
1280.009|4.86|but explaining it is not always as easy
1282.709|4.35|so here's some hand wavy reasons I think
1284.869|4.321|for why people are thinking that this
1287.059|5.7|works much better so one thing is that
1289.19|5.13|this this railway neuron it does not
1292.759|4.29|saturate at least in a positive region
1294.32|4.229|so at least in this region you don't
1297.049|2.61|have this vanishing gradient problem
1298.549|3.151|where your gradients will just kind of
1299.659|3.99|die and you have this issue where the
1301.7|5.069|neurons are only active in a small area
1303.649|4.71|that is bounded from both sides but
1306.769|3.6|these neurons are actually active in a
1308.359|3.36|sense of a back propagate correctly or
1310.369|4.05|not correctly but at least they don't
1311.719|5.221|not back propagate all zeroes at least
1314.419|3.72|in half of their regions there are much
1316.94|2.579|more computationally efficient because
1318.139|4.23|doing you're just being Thresh holding
1319.519|5.49|and experimental you can see that this
1322.369|4.17|converge is much much faster so this is
1325.009|3.3|called the rel-nei on or the rectified
1326.539|3.661|linear unit and it was pointed out in
1328.309|3.45|this paper for the first time that this
1330.2|2.879|works much better and this is kind of
1331.759|1.871|like the default recommendation of what
1333.079|2.351|you should use
1333.63|3.45|this point at the same time there are
1335.43|3.69|several problems with this rail in Iran
1337.08|4.65|so one thing again notice that it's not
1339.12|5.67|zero centered outputs so not completely
1341.73|6.48|ideal perhaps and a slight annoyance of
1344.79|5.7|the rail in Iran that we can talk about
1348.21|6.06|and think about is what happens when
1350.49|4.98|this rail in rural outputs are zero what
1354.27|3.33|happens during back propagation if
1355.47|3.99|irelia neuron does not become active so
1357.6|5.55|in the forecast area URL stays inactive
1359.46|6.51|then during backdrop what does it do it
1363.15|4.26|kills right it kills the gradient and so
1365.97|3.69|the way to see this of course is that
1367.41|4.35|with the same picture and if you're at
1369.66|3.72|negative site 10 then your local
1371.76|3.24|gradient here will just be zero because
1373.38|3.84|there's no there's just 0 gradient
1375.0|3.57|identically it's not just you squish the
1377.22|3.12|gradient down you actually kill it
1378.57|3.09|completely so any neuron that does not
1380.34|3.06|activate will not back propagate
1381.66|4.29|downwards its weights will not be
1383.4|6.96|updated and nothing happens below it at
1385.95|7.07|least for its contribution and at x
1390.36|5.88|equals 10 what is the local gradient
1393.02|6.49|it's just one so a relativist passes
1396.24|5.07|through gradients just a gate if if if
1399.51|3.78|it's if during the forward pass its
1401.31|4.08|output was positive then it just passes
1403.29|6.18|gradient through otherwise it kills it
1405.39|5.52|it's kind of like a gradient gate and by
1409.47|7.98|the way what happens when x is zero what
1410.91|7.89|is your gradient at that point it's
1417.45|3.45|actually undefined that's right the
1418.8|3.69|gradient does not exist at that point we
1420.9|3.87|only talk about whenever I talk about
1422.49|3.75|gradient just assume that I always mean
1424.77|2.91|sub gradient which is a generalization
1426.24|3.12|of gradients to functions that are
1427.68|3.72|sometimes non differentiable so here the
1429.36|4.92|limit does not exist but there's a whole
1431.4|5.6|bunch of sub gradients that could be 0
1434.28|5.04|or 1 and so that's what we use usually
1437.0|4.03|in practice this this distinction
1439.32|2.85|doesn't really matter too much but I
1441.03|3.96|wanted to also point this out in the
1442.17|4.32|case of the binary max gate max of X and
1444.99|3.57|Y and someone asked the question what
1446.49|4.8|happens if x and y are equal then in
1448.56|4.41|that case you you kind of also have a
1451.29|3.36|kink in the function and makes it not
1452.97|3.12|differentiable but in practice these
1454.65|3.48|things don't really matter just pick one
1456.09|3.51|so you can have a gradient of 0 or 1
1458.13|3.36|there and things will work just fine and
1459.6|3.87|that's roughly because these are very
1461.49|5.16|unlikely cases that you end up right
1463.47|3.929|there ok so the issue with relu roughly
1466.65|2.43|here's the problem
1467.399|2.97|happens in practice you try to Israel
1469.08|4.769|units and one thing that you have to be
1470.369|5.85|aware of is you have these neurons that
1473.849|4.2|if they don't output anything they won't
1476.219|8.101|get any gradient they'll kill it and
1478.049|8.391|they won't update and so let's see so
1484.32|3.959|the issue is suppose you have a
1486.44|3.339|sometimes what can happen is when you
1488.279|4.5|initialize your rail in your owns you
1489.779|5.69|can initialize them in a not very lucky
1492.779|4.74|way and what ends up happening is
1495.469|4.601|suppose this is your data cloud of
1497.519|4.59|inputs to your revenue rounds but you
1500.07|4.559|can end up with is a what we call it
1502.109|4.94|dead rail a dead rail in your own so if
1504.629|4.92|this neuron only activates in the region
1507.049|4.48|outside of your data cloud then this
1509.549|3.99|dead rail you will never become
1511.529|3.96|activated and then it will never update
1513.539|3.48|and so this can happen in one of two
1515.489|3.06|ways either during initialization you
1517.019|3.36|are really really unlucky and you happen
1518.549|3.81|to sample weights for the rail in Iran
1520.379|3.331|in such a way that that neuron will
1522.359|4.2|never turn on in that case the neuron
1523.71|4.98|will not train but more often what
1526.559|4.021|happens is during training if your
1528.69|3.299|learning rate is high then think about
1530.58|2.969|these neurons it's kind of like
1531.989|2.79|jittering around and what can happen
1533.549|3.0|sometimes by chances they just get
1534.779|3.9|knocked off the data manifold and when
1536.549|4.05|that happens then they will never get
1538.679|4.2|activated again and they they will not
1540.599|3.45|come back to the data manifold and you
1542.879|4.41|can see this actually in practice like
1544.049|5.58|sometimes you can train a big neural net
1547.289|3.99|with rail units and you train it and it
1549.629|3.18|seems to work fine and then what you do
1551.279|2.88|you stop the training and you pass your
1552.809|3.271|entire training data set through your
1554.159|4.83|network and you look at the statistics
1556.08|4.919|of every single neuron and what what can
1558.989|3.9|happen is that as much as like 10 or 20
1560.999|3.331|percent of your network is dead these
1562.889|3.36|are neurons that never turn down for
1564.33|4.38|anything in the training data and this
1566.249|4.47|can actually happen usually it's because
1568.71|3.48|your learning rate was high and so those
1570.719|3.78|are just like dead parts of your network
1572.19|3.809|and you can come up with hacky schemes
1574.499|4.38|for reinitializing these things and so
1575.999|4.49|on people don't usually do it as much
1578.879|4.14|but that's something to be aware of and
1580.489|5.44|it's a problem with this non-linearity
1583.019|4.89|and so especially for initialization
1585.929|3.6|because of this dead rail loop problem
1587.909|3.69|what people like to do is normally
1589.529|3.6|initialize the biases with 0 instead
1591.599|3.87|people initialize with slightly positive
1593.129|4.831|numbers like say 0.01 because that makes
1595.469|4.471|it more likely that initialization these
1597.96|3.03|Relan neurons will output positive
1599.94|3.089|numbers and they'll get
1600.99|3.569|dates so it makes it less likely that
1603.029|4.38|the neuron will just never become
1604.559|4.321|activated ever throughout training but I
1607.409|3.15|don't actually I think this is slightly
1608.88|3.0|of a controversial point I've seen
1610.559|2.641|people claim that it helps I've seen
1611.88|1.95|some people say that it actually doesn't
1613.2|4.19|help at all
1613.83|3.56|and so just something to think about
1617.929|4.031|okay any questions at this point we had
1620.34|5.339|sigmoid 10h and relu I'm going to go
1621.96|5.88|into some other ones okay good so let's
1625.679|4.74|look at things like people trying to fix
1627.84|4.469|Rea loose so one issue with Ray loose as
1630.419|4.711|these dead neurons are not ideal so
1632.309|5.881|here's one proposal which is called the
1635.13|5.159|leaky relu and the idea with leaky relu
1638.19|4.109|is basically we want this kink and we
1640.289|4.77|want this piecewise linear T and we want
1642.299|5.431|this efficiency of relu but the issue is
1645.059|4.771|that in these this region your
1647.73|4.29|ingredients die so instead let's make
1649.83|4.62|this slightly negatively sloped here or
1652.02|4.409|slightly positively sloped I suppose in
1654.45|3.959|this region and so you end up with this
1656.429|4.051|function and that's called a leaky relu
1658.409|3.801|and so some people there are papers
1660.48|4.14|showing that this works slightly better
1662.21|5.74|you don't have this issue of neurons
1664.62|5.34|dying but I think it's not completely
1667.95|4.26|established that this works always
1669.96|4.38|better and then some people play with
1672.21|3.54|this even more so right now this is 0.01
1674.34|3.18|but that can actually be an arbitrary
1675.75|3.179|parameter and then you get something
1677.52|3.659|that's called a parametric rectifier or
1678.929|5.011|P relu and basically the idea here is to
1681.179|4.411|introduce this is 0.01 that can be an
1683.94|3.66|arbitrary alpha which is a parameter in
1685.59|2.4|your network and this alpha can be
1687.6|2.22|learned
1687.99|3.51|you can back propagate into it and so
1689.82|3.41|these neurons basically can choose what
1691.5|6.84|slope to have in this negative region
1693.23|6.91|okay and so they can become a rail if
1698.34|4.11|they want to or they can become a leaky
1700.14|4.44|rail or they can be they have the choice
1702.45|3.15|roughly for every neuron and so this is
1704.58|2.04|the kinds of things that people play
1705.6|9.36|with when they try to design better
1706.62|11.07|nonlinearities good so alpha here would
1714.96|5.939|be a parameter that you back propagate
1717.69|4.65|to in just a very normal way in your
1720.899|3.211|computational graph there's every neuron
1722.34|7.13|will have its alpha just like it has its
1724.11|5.36|own bias okay go ahead
1732.68|3.7|yeah I'm not sure if they worry about
1734.64|5.34|this lots of alpha is one then you're
1736.38|4.62|going to get an identity so that's
1739.98|3.03|probably not something that that
1741.0|3.51|propagation will want in a sense that if
1743.01|3.0|that was an identity then that shouldn't
1744.51|2.79|be very computationally useful so you
1746.01|2.58|might expect that maybe back propagation
1747.3|3.63|should not actually get you to those
1748.59|4.26|regions of the space and wavy reason
1750.93|3.48|perhaps I don't actually think if I
1752.85|2.91|remember correctly there's no specific
1754.41|3.18|things where people really worry about
1755.76|3.39|that too much but I could be wrong I had
1757.59|4.1|I read the paper a while ago now and I
1759.15|6.09|don't use these too much in my own work
1761.69|5.41|okay and then so one issue still is as
1765.24|3.9|we saw so these are different schemes
1767.1|3.69|for fixing the the dead relevant ons
1769.14|3.24|there's another people that only came
1770.79|3.9|out for example roughly two months ago
1772.38|4.38|so this just gives you a sense of how
1774.69|3.51|new this field is there are papers
1776.76|3.99|coming out just two months ago trying to
1778.2|4.62|propose new activation functions one of
1780.75|3.81|them is exponential in your units or
1782.82|3.84|Allu so just give you an idea about what
1784.56|4.23|people play with it tries to have all
1786.66|4.17|the benefits of relu but it tries to get
1788.79|4.11|rid of this downside of being nonzero
1790.83|3.99|centered and so they end up with is this
1792.9|3.72|blue function here that looks like a
1794.82|3.12|reloj but in the negative region it
1796.62|3.51|doesn't just go to zero or it doesn't
1797.94|4.14|just go down as a leaky relu but it has
1800.13|4.83|this funny shape and there are two pages
1802.08|5.37|of math in that paper justifying partly
1804.96|3.93|why you want that and roughly when you
1807.45|3.9|do this then you end up with 0 mean
1808.89|4.05|outputs and they claim that this trains
1811.35|4.65|better and I think there's some
1812.94|4.83|controversy about this and and and so
1816.0|3.45|we're basically trying to figure all of
1817.77|3.69|this out active area of research and
1819.45|3.15|we're not sure what to do yet but Ray
1821.46|3.33|Lewis right now are like a safe
1822.6|6.15|recommendation if you if you're careful
1824.79|5.79|with it ok so that's a loose and one
1828.75|2.97|more I would like to note mention
1830.58|3.21|because it's relatively common and
1831.72|4.26|you'll see it if you read about neural
1833.79|6.33|networks is this max at neuron from
1835.98|5.73|Inglot fellow at all and basically it's
1840.12|3.06|a very different form of a neuron it's
1841.71|3.18|not just an activation function that
1843.18|3.63|looks different it actually changes what
1844.89|3.63|a neuron computes or how it computes so
1846.81|4.35|it doesn't just have this form of F of W
1848.52|5.67|transpose X it actually has two weights
1851.16|5.07|and then it computes max of W transpose
1854.19|3.81|X plus B and another set of W transpose
1856.23|3.51|X plus B so you end up with these like
1858.0|3.6|two hyperplanes that you take a max over
1859.74|2.819|and that's what the neuron computes so
1861.6|2.669|you can see that there are many way
1862.559|3.48|playing with these activation functions
1864.269|2.551|so this doesn't have some of the
1866.039|3.51|downsides of
1866.82|4.26|relu this won't die and it's still
1869.549|4.38|piecewise-linear it's still efficient
1871.08|4.589|but now every single neuron has two
1873.929|3.72|weights and so you've kind of double the
1875.669|4.561|number of parameters per neuron and so
1877.649|5.431|maybe that's not as ideal so some people
1880.23|4.38|use this but I think it's it's not super
1883.08|16.01|common I would say that robots are still
1884.61|18.23|most common good at the end of the
1899.09|3.75|that's right so what's your question
1909.23|3.49|that's right so the weights will end up
1911.369|3.51|yeah based on what the activation
1912.72|3.12|functions are the dynamics of the back
1914.879|1.951|drop into those weights will be
1915.84|10.86|different and so you end up with
1916.83|11.9|different weights for sure yeah I think
1926.7|5.579|it's it's complicated
1928.73|5.62|the reason it's complicated is a lot of
1932.279|3.75|the optimization process is not just
1934.35|3.209|about the loss function but just like
1936.029|3.301|about the dynamics of the backward flow
1937.559|3.06|of gradients and we'll see a bit about
1939.33|3.929|that in the next few slides you have to
1940.619|5.91|really think about it dynamically more
1943.259|7.11|than just a lost landscape and how it's
1946.529|5.25|so it's a complex and also we use
1950.369|3.211|specifically stochastic gradient descent
1951.779|3.87|and it has a particular form and some
1953.58|3.959|things play nicer some nonlinearities
1955.649|4.41|play nicer with the fact like the
1957.539|3.84|optimization is tied the update is tied
1960.059|3.21|into all of this as well and it's kind
1961.379|4.29|of all interacting together and the
1963.269|4.38|choice of these activation functions and
1965.669|3.75|the choice of your updates are kind of
1967.649|3.181|coupled and it's kind of very unclear
1969.419|6.0|when you actually optimize this kind of
1970.83|8.969|a complex thing okay
1975.419|6.99|so TL DR here is that use relu you can
1979.799|3.6|try out these guys you can try out ten
1982.409|2.13|eight but you shouldn't expect too much
1983.399|3.03|I don't think people use it too much
1984.539|3.39|right now and don't use sigmoid because
1986.429|3.69|basically 10 H is strictly better and
1987.929|4.291|you won't see people use sigmoid now
1990.119|4.17|anymore of course we use it in things
1992.22|3.19|like long short-term memory units LS DMS
1994.289|2.351|and so on and we'll go into the
1995.41|3.63|in a bit in recurrent neural networks
1996.64|3.78|but there are specific reasons why we
1999.04|5.16|use them there and that we'll see later
2000.42|5.4|in the class and they are they're used
2004.2|3.84|differently than what we have covered so
2005.82|5.31|far and like this just a fully connected
2008.04|4.62|sandwich of matrix multiply
2011.13|3.18|non-linearity and so on just having a
2012.66|2.91|basic neural network okay
2014.31|2.55|so that's everything I wanted to say
2015.57|2.58|about activation functions it's
2016.86|2.58|basically this one hyper parameter in
2018.15|3.3|our functions that we worry about
2019.44|3.63|there's research about it and we haven't
2021.45|3.3|fully figured it out and there's some
2023.07|3.81|pros and cons and many of them come down
2024.75|4.11|to thinking about how the gradient flows
2026.88|3.78|through your network and these these
2028.86|3.99|issues like dead ray loose and you have
2030.66|4.56|to really know about the gradient flow
2032.85|5.7|if you try to debug your networks and to
2035.22|4.89|understand what's going on okay so let's
2038.55|5.25|look at data pros be processing very
2040.11|5.28|briefly how many time okay so data
2043.8|3.39|pre-processing just very briefly
2045.39|3.45|normally suppose you just have a cloud
2047.19|4.56|of original data in two dimensions here
2048.84|4.53|very common to 0 Center your data so
2051.75|3.54|that just means that along every single
2053.37|3.36|feature we subtract the mean people
2055.29|3.54|sometimes also when you go through
2056.73|3.899|machine learning literature try to
2058.83|3.87|normalize the data so in every single
2060.629|4.411|dimension you normalize say by standard
2062.7|3.66|deviation call standardizing or you can
2065.04|3.81|make sure that the min and the max are
2066.36|4.019|within say negative 1 or 1 and so on
2068.85|4.2|there are several schemes for doing so
2070.379|4.231|in images it's not as common because you
2073.05|2.73|don't have separate different features
2074.61|2.67|that could be at different units
2075.78|3.51|everything is just pixels and they're
2077.28|4.02|all bounded between 0 and 255 so it's
2079.29|3.69|not as common to normalize the data but
2081.3|3.15|it's very common to 0 Center your data
2082.98|3.84|you can go further
2084.45|4.26|normally in machine learning you can go
2086.82|3.72|ahead and your data has some covariance
2088.71|3.36|structure by default you can go ahead
2090.54|3.24|and make that covariance structure be
2092.07|3.66|diagonal say for example by applying PCA
2093.78|4.11|or you can go even further and you can
2095.73|3.93|whiten your data and what that means is
2097.89|4.35|you kind of even squish after you
2099.66|4.59|performed PCA you also squish your data
2102.24|4.02|so that your covariance matrix becomes
2104.25|3.24|just a diagonal and so that's another
2106.26|3.96|form of pre-processing you might see
2107.49|4.82|people talk about and these are both I
2110.22|4.68|go much more detail in the class notes
2112.31|4.06|on these I don't want to go into too
2114.9|2.97|many details on them because it turns
2116.37|2.79|out that in images we don't actually end
2117.87|3.78|up using these even though there are
2119.16|4.92|common in machine learning so in images
2121.65|4.38|specifically what's common is just a
2124.08|3.15|mean centering and then a particular
2126.03|2.58|variant of mean centering that is
2127.23|4.29|slightly more convenient in practice
2128.61|6.09|so in means centering we say have a 32
2131.52|4.62|by 32 by three images of CFR if you want
2134.7|2.76|to Center your data then for every
2136.14|2.61|single pixel you compute that's mean
2137.46|3.09|value over the training set and you
2138.75|4.26|subtract that out so what you end up
2140.55|5.01|with is this mean image that has
2143.01|4.17|basically dimension of 32 by 32 by 3 so
2145.56|3.78|I think the mean image for example for
2147.18|3.36|image net is just this orange blob so
2149.34|3.3|you end up subtracting that from every
2150.54|5.01|single image to Center your data to have
2152.64|4.73|better training dynamics and one other
2155.55|4.56|form that is likely more convenient is
2157.37|4.66|subtracting just a per channel mean so
2160.11|4.02|you go in red green and blue channel and
2162.03|3.93|you compute to the mean across all of
2164.13|3.87|space so you just end up with basically
2165.96|3.36|three numbers of the means in red green
2168.0|3.72|and blue channel and just subtract those
2169.32|3.75|out and so some networks use that
2171.72|3.18|instead so those are the two common
2173.07|3.0|schemes this one is likely more
2174.9|2.28|convenient because you only have to
2176.07|2.31|worry about those three numbers you
2177.18|2.73|don't have to worry about a giant array
2178.38|2.97|of mean image that you have to ship
2179.91|5.91|around everywhere when you're actually
2181.35|6.87|coding this up okay so not too much more
2185.82|3.9|I want to say about this just basically
2188.22|3.03|subtract the mean in computer vision
2189.72|3.48|applications things don't get much more
2191.25|4.08|complex than that in particular doing
2193.2|4.23|PCA and so on this used to be slightly
2195.33|3.69|common the issues you can't apply it on
2197.43|3.12|full images because your images are very
2199.02|4.11|high dimensional objects with lots of
2200.55|4.71|pixels and so these various matrices
2203.13|4.05|would be huge and people try to do
2205.26|4.44|things like only doing whitening locally
2207.18|5.61|so you would slide a whitening filter
2209.7|4.65|through your images spatially and that
2212.79|3.39|used to be done several years ago but
2214.35|5.91|it's not as common now it doesn't seem
2216.18|7.17|to matter too much okay good so we will
2220.26|4.62|dive into weight initialization a very
2223.35|3.45|very important topic one of the reasons
2224.88|3.15|that I think early neural networks
2226.8|2.79|didn't quite work but as well is because
2228.03|4.41|people are just not careful enough with
2229.59|4.38|this so one of the first things will we
2232.44|4.08|can look at is first of all how not to
2233.97|4.2|do weight initialization so in
2236.52|3.54|particular you might be tempted to just
2238.17|5.04|say okay let's start off at all the
2240.06|4.35|weights are equal to zero and you use
2243.21|2.49|that in your neural network so suppose
2244.41|3.24|you have like a ten layer neural network
2245.7|3.99|and you set all the ways to zero why
2247.65|4.13|doesn't that work why isn't that a good
2249.69|2.09|idea
2252.09|8.1|I sorry go ahead yeah so basically just
2258.39|3.45|all your neurons output the same thing
2260.19|3.6|in backdrop they will behave the same
2261.84|4.2|way and so there's nothing as we call
2263.79|3.96|now as well actually call it symmetry
2266.04|4.08|breaking so all the neurons are
2267.75|3.36|computing same stuff and so in backdrop
2270.12|2.88|they will all look the same they will
2271.11|2.82|compute the same gradients and so on so
2273.0|2.76|not the best thing
2273.93|3.99|so instead people use small numbers
2275.76|3.45|small random numbers so one way you can
2277.92|4.02|do that for example that is a relatively
2279.21|4.77|common thing to do is you sample from a
2281.94|4.8|unit Gaussian with 0.01 standard
2283.98|4.74|deviation so small random numbers
2286.74|5.19|so that's your W matrix how you would
2288.72|5.85|initialize it now the issue with this
2291.93|4.56|initialization is that it works ok but
2294.57|4.26|you'll find that it only works ok if you
2296.49|4.53|have small networks but as you start to
2298.83|3.12|go deeper and deeper with neural
2301.02|3.18|networks you have to be much more
2301.95|4.29|careful about the initialization and I'd
2304.2|4.32|like to go into exactly what breaks and
2306.24|4.2|how it breaks and why it breaks when you
2308.52|3.48|try to do these naive initialization
2310.44|5.1|strategies and try to have deep networks
2312.0|5.22|so let's look at what goes wrong so what
2315.54|4.98|I've written here is a small ipython
2317.22|4.49|notebook so what we're doing here is I'm
2320.52|4.83|going to step through this just briefly
2321.71|6.28|I'm sampling a data set of 1,000 points
2325.35|3.75|that are 500 dimensional and then I'm
2327.99|3.9|creating a whole bunch of hidden layers
2329.1|5.49|and nonlinearities so say right now we
2331.89|6.3|have 10 layers of 500 units and we're
2334.59|6.72|using 10 H and then what I'm doing here
2338.19|5.1|is I'm just basically taking unit
2341.31|3.87|Gaussian data and I'm forwarding it
2343.29|3.63|through the network and with this
2345.18|3.33|particular initialization strategy we're
2346.92|2.76|right now that initialization strategy
2348.51|3.27|is what I described in the previous
2349.68|4.68|slide so example from unit Gaussian and
2351.78|3.9|scale it by 0.01 so what I'm doing here
2354.36|2.94|in this for loop is I'm forward
2355.68|3.9|propagating this network which is right
2357.3|4.56|now made up of just a series of layers
2359.58|4.59|of the same size so with 10 layers of
2361.86|3.45|500 neurons on each layer and I'm
2364.17|3.0|forward propagating with this
2365.31|4.29|initialization strategy for a unit
2367.17|4.41|Gaussian data and what I want to look at
2369.6|5.1|is what happens to the statistics of the
2371.58|4.59|hidden of the neurons activations
2374.7|3.18|throughout the network with this
2376.17|2.91|initialization so we're going to look
2377.88|3.3|specifically at the mean and a standard
2379.08|3.63|deviation and we're going to plot the
2381.18|4.08|mean standard deviation and we're going
2382.71|3.09|to plot the histograms so we take all
2385.26|2.67|this data
2385.8|4.05|and then say at the fifth player we're
2387.93|3.81|going to look at what the what value is
2389.85|3.21|the neurons take on and say the fifth or
2391.74|3.69|sixth or seventh layer and we're going
2393.06|3.51|to make histograms of those so with this
2395.43|3.36|initialization if you run this
2396.57|5.1|experiment you end up it ends up looking
2398.79|4.95|as follows so here I'm printing it out
2401.67|3.42|we start off with a mean of zero and
2403.74|3.6|standard deviation of one that's our
2405.09|4.47|data and now I'm forward propagating and
2407.34|4.77|as I go to tenth player look at it what
2409.56|4.23|happens to the mean we're using ten H so
2412.11|4.38|10 H is symmetric so as you might expect
2413.79|3.99|the mean stays around zero but the
2416.49|3.03|standard deviation look at what happens
2417.78|2.97|to it it started off at one and some of
2419.52|3.87|the standard deviation goes to point two
2420.75|5.07|then point zero four and it just
2423.39|4.5|plummets down to zero so the standard
2425.82|2.82|deviation of these neurons just goes
2427.89|2.67|down to zero
2428.64|3.66|looking at the histograms here at every
2430.56|3.24|single layer at the first layer the
2432.3|3.12|histogram is reasonable so we have a
2433.8|3.96|spread of numbers between negative 1 and
2435.42|4.2|1 and then what ends up happening to it
2437.76|5.07|this just collapses to a tight
2439.62|4.26|distribution at exactly zero so it ends
2442.83|3.48|up happening with this initialization
2443.88|4.29|for this ten layer Network is all the 10
2446.31|4.59|H neurons just end up outputting just
2448.17|7.25|zero so at the last layer these are tiny
2450.9|7.02|numbers of like near zero values and so
2455.42|6.13|all activations basically become zero
2457.92|5.52|and why is this an issue okay so think
2461.55|6.15|about what happens to the dynamics of
2463.44|6.09|the backward pass to the gradients when
2467.7|3.66|you have tiny numbers in the activations
2469.53|4.47|your X's are tiny numbers on the last
2471.36|5.1|few layers what what do these gradients
2474.0|10.23|look like on the weights in these layers
2476.46|10.74|and what happens to the backward pass so
2484.23|5.49|first of all suppose my so there is a
2487.2|4.56|layer here that looks at some layer
2489.72|5.19|before it and almost all the inputs are
2491.76|5.34|tiny numbers that's the X X is a tiny
2494.91|4.02|number what is the gradient what do you
2497.1|4.2|what might you expect the gradients for
2498.93|8.19|the W to be in that case for those
2501.3|8.66|layers sorry you said very small so why
2507.12|2.84|would they be very small
2510.51|5.08|that's right so the gradient for W will
2513.37|5.01|be equal to x times the gradient from
2515.59|4.29|the top okay and so if X are tiny
2518.38|3.96|numbers then your gradients for W are
2519.88|4.83|tiny numbers as well and so these guys
2522.34|4.92|will basically have almost no gradient
2524.71|7.08|accumulated now we can also look at what
2527.26|6.93|happens with these matrices again we we
2531.79|4.56|took data that was distributed as a unit
2534.19|3.78|Gaussian at the beginning and then we
2536.35|3.69|ended up multiplying it by W and
2537.97|3.39|activation function and we saw that
2540.04|4.59|basically everything goes to zero this
2541.36|5.16|just collapses over time and think about
2544.63|3.39|the backward pass as we change the
2546.52|3.0|gradient through these layers and back
2548.02|3.36|propagation what we were doing
2549.52|4.08|effectively is some of the gradient kind
2551.38|3.99|of Forks off and to our gradient W and
2553.6|2.97|we saw that those are tiny numbers but
2555.37|3.45|then throwing back propagation we're
2556.57|3.93|going through gradients of X and so we
2558.82|4.35|end up doing when we back drop through
2560.5|4.71|here is we again end up multiplying by W
2563.17|5.1|again and again at every single layer
2565.21|5.55|and if you take unit Gaussian data and
2568.27|4.02|you multiply it by W at this scale you
2570.76|3.42|can see that everything goes to zero and
2572.29|4.44|the same thing will happen in backward
2574.18|4.53|pass we're successively multiplying by W
2576.73|4.41|as we've back propagated into X on every
2578.71|3.9|single layer and we're as we do that
2581.14|2.64|this gradient which started off with
2582.61|2.97|reasonable numbers from your loss
2583.78|4.05|function will end up just going towards
2585.58|4.02|zero as you keep doing this process and
2587.83|5.54|you end up with gradients here that are
2589.6|6.9|basically just tiny tiny numbers and so
2593.37|4.86|you basically end up with very very low
2596.5|3.66|gradients throughout this network
2598.23|3.37|because of this reason and this is
2600.16|2.76|something that we refer to as vanishing
2601.6|2.67|gradient as this gradient travels
2602.92|3.12|through with this particular
2604.27|3.03|initialization you can see that the grip
2606.04|3.69|the magnitude of the gradient will just
2607.3|6.09|go down when we used this initialization
2609.73|5.19|for W of 1e negative 2 okay so we can
2613.39|3.69|try a different extreme instead of
2614.92|3.84|scaling here as we scaled with one
2617.08|4.41|negative two we can try a different
2618.76|6.09|scale of the W matrix at initialization
2621.49|4.14|so suppose I try one point zero instead
2624.85|3.24|of 0.01
2625.63|4.68|we'll see another funny thing happen
2628.09|5.64|because now we've overshot the other way
2630.31|5.31|in a sense that you can see that well
2633.73|3.21|maybe it's best to look at the
2635.62|3.3|distributions here you can see that
2636.94|3.9|everything is completely saturated these
2638.92|2.84|ten H neurons are either all negative
2640.84|3.529|one or all
2641.76|4.349|one I mean the distribution is really
2644.369|3.361|just everything is supersaturated your
2646.109|2.521|entire network all the neurons
2647.73|2.73|throughout the network are either
2648.63|3.239|negative one or one because the weights
2650.46|3.57|are too large and they keep over
2651.869|3.301|saturating 10h neurons because this
2654.03|2.46|course that end up going through the
2655.17|3.78|non-linearity are just very large
2656.49|4.71|because the weights are large and so
2658.95|3.36|everything is supersaturated so what are
2661.2|5.19|the gradients flowing through your
2662.31|6.18|network it's just terrible it's complete
2666.39|5.729|disaster right it's just zeros forever
2668.49|5.55|just exponentially zero and you die so
2672.119|3.661|you can train for a very long time at
2674.04|3.48|what you'll see when this happens is
2675.78|3.18|your loss is just not moving at all
2677.52|2.82|because nothing is back propagate in
2678.96|5.13|because all the neurons are saturated
2680.34|5.19|and nothing is being updated okay so
2684.09|3.269|this initialization as you might expect
2685.53|3.81|actually is like super tricky to set and
2687.359|3.421|it needs to be kind of in this
2689.34|3.21|particular case it needs to be somewhere
2690.78|5.37|between one and zero point zero one okay
2692.55|5.37|and so you can be slightly more
2696.15|3.45|principled instead of trying different
2697.92|5.01|values and there are some papers written
2699.6|4.74|on this so for example in 2010 there was
2702.93|3.66|a proposal for what we now call the
2704.34|5.04|Xavier initialization from Glu out at
2706.59|3.9|hall and they kind of went through and
2709.38|3.36|they looked at the expression for the
2710.49|3.9|variance of your neurons and you can
2712.74|3.96|write this out and you can basically
2714.39|4.11|propose a specific initialization
2716.7|3.81|strategy for how you scale your
2718.5|3.78|gradients so I don't have to try a 0.01
2720.51|3.599|I don't have to try one or whatever else
2722.28|3.12|so they recommend this kind of
2724.109|3.361|initialization where you divide by the
2725.4|3.84|square root of the number of inputs for
2727.47|3.69|every single neuron so if you have lots
2729.24|4.5|of inputs then you end up with lower
2731.16|4.05|weights and intuitively that makes sense
2733.74|2.76|because you're doing more weight you
2735.21|2.85|have more stuff that goes into your
2736.5|3.15|weighted sum so you want less of an
2738.06|3.39|interaction to all of them and if you
2739.65|3.63|have smaller number of units that are
2741.45|3.87|feeding into your lair then you want
2743.28|3.15|larger weights because then there's only
2745.32|5.45|a few of them and you want to have a
2746.43|6.72|variance of one so just to back up a bit
2750.77|4.33|the idea here is they were looking at a
2753.15|3.42|single neuron no activation functions
2755.1|3.42|included it's just a linear neuron and
2756.57|3.33|all they're saying is if you want if
2758.52|3.42|you're getting unit Gaussian data as
2759.9|4.05|input and you'd like this linear neuron
2761.94|3.96|to have a variance of 1 then you should
2763.95|4.2|initialize your weights with this amount
2765.9|4.5|and in the notes I go into exactly how
2768.15|4.77|this is derived is just some math with
2770.4|5.04|standard deviations and basically this
2772.92|2.9|is a reasonable initialization so I can
2775.44|2.27|use that
2775.82|3.05|instead and you can see that if I use it
2777.71|3.24|here
2778.87|3.52|the distributions end up being more
2780.95|2.58|sensible so we're again looking at the
2782.39|3.27|histogram between negative one and one
2783.53|4.71|of these 10h units and you get a more
2785.66|5.34|sensible number here and you actually
2788.24|4.47|have your within the active region of
2791.0|2.82|all these ten HS and so you can expect
2792.71|4.44|that this will be a much better
2793.82|4.62|initialization because things are in the
2797.15|2.64|active regions and things will train
2798.44|3.81|from the start nothing is super
2799.79|4.23|saturated in the beginning the reason
2802.25|2.91|that this doesn't just end up being very
2804.02|2.67|nice and the reason we still have
2805.16|3.0|conversions down here is because this
2806.69|3.63|paper doesn't take into account the
2808.16|4.26|nonlinearities in this case the 10 H and
2810.32|5.25|so the 10 H non-linearity ends up like
2812.42|5.52|kind of deforming your statistics of the
2815.57|5.31|variance throughout and so if you stack
2817.94|4.29|this up it ends up still you know doing
2820.88|2.67|something to distribution in this case
2822.23|3.15|it seems that the standard deviation
2823.55|4.38|goes down but it's not as dramatic as if
2825.38|3.99|you were to set this by by just trial
2827.93|4.11|and error and so this is like a
2829.37|3.99|reasonable initialization to use in your
2832.04|3.72|neural networks compared to just setting
2833.36|5.85|it to 0.01 and so people end up using
2835.76|5.64|this in practice sometimes but so this
2839.21|3.78|works in the case of 10 H does something
2841.4|3.54|reasonable it turns out if you try to
2842.99|5.04|put it into a rectified linear unit
2844.94|4.95|Network it doesn't work as well and the
2848.03|4.35|decrease in the standard deviations will
2849.89|4.8|be much more rapid so looking at irelia
2852.38|4.14|on and the first layer it has some
2854.69|3.03|distribution and then this distribution
2856.52|3.81|as you can see just gets more and more
2857.72|5.4|peaky at 0 so more and more neurons are
2860.33|5.13|not activating with this initialization
2863.12|4.92|so using the Xavier initialization in a
2865.46|4.98|rectified layer layer net does not do
2868.04|4.53|good things and so again thinking about
2870.44|3.69|this paper they don't actually talk
2872.57|4.86|about nonlinearities and the relevant
2874.13|5.37|ons they compute this weighted sum which
2877.43|4.56|is within their domain here but now
2879.5|4.11|after the weighted sum you do a relly so
2881.99|3.63|you kill half of the distribution you
2883.61|3.09|set it to zero and intuitively what that
2885.62|2.82|does to your distribution of your
2886.7|5.28|outputs is it basically halves your
2888.44|5.07|variance and so it turns out as was
2891.98|4.59|proposed in this paper just last year in
2893.51|4.35|fact someone said basically look there's
2896.57|3.93|a factor of two you're not accounting
2897.86|4.86|for because these relevant neurons they
2900.5|4.14|effectively have your variance each time
2902.72|3.66|because you take everything like say you
2904.64|3.18|have unit Gaussian inputs you take them
2906.38|2.83|through your non-linearity you have unit
2907.82|2.98|Gaussian stuff out
2909.21|3.119|now you relieve that and so you end up
2910.8|3.96|having the variance so you need to
2912.329|4.621|account for it with an extra two and
2914.76|3.78|when you do that then you get proper
2916.95|4.2|distributions specifically for the
2918.54|3.87|relevant on and so in this
2921.15|2.55|initialization where if you're using
2922.41|3.72|relative Nets you have to worry about
2923.7|4.859|that extra factor of two and everything
2926.13|3.989|will come out nicely and you won't get
2928.559|3.75|this factor of two that keeps building
2930.119|5.22|up and it screws up your activations
2932.309|4.29|exponentially okay so basically this is
2935.339|3.571|tricky tricky stuff and it really
2936.599|4.47|matters in practice in practice in their
2938.91|3.39|paper for example they compare having
2941.069|2.851|the factor of two or not having that
2942.3|3.059|factor of two and it matters when you
2943.92|3.78|have really deep networks in this case I
2945.359|3.571|think they had a few dozen layers if you
2947.7|2.94|account for the factor of two you
2948.93|3.72|converge if you don't account for that
2950.64|5.699|factor of two you there's nothing it's
2952.65|6.15|just zero lots okay so very important
2956.339|3.48|stuff you need really need to think it
2958.8|2.67|through you have to be careful with the
2959.819|4.471|initialization if it's incorrectly set
2961.47|4.109|are bad things happen and so
2964.29|3.12|specifically in the case if you have
2965.579|4.141|neural networks with railway units
2967.41|4.08|there's a correct answer to use and
2969.72|6.599|that's the this initialization from
2971.49|7.079|coming coming okay so tricky stuff this
2976.319|3.3|is partly this is partly why you let
2978.569|4.591|worse even work for a long time as we
2979.619|5.791|just I think people didn't then fully
2983.16|5.55|maybe appreciate just how how difficult
2985.41|4.949|this was to get right and tricky and so
2988.71|3.27|I just like to point out that proper
2990.359|3.0|neutralization basically active area of
2991.98|3.389|research you can see that papers are
2993.359|4.111|still being published on this a large
2995.369|3.45|number of papers just proposing
2997.47|4.379|different ways of initializing your
2998.819|4.171|networks these last few are interesting
3001.849|3.391|as well because they don't give you a
3002.99|3.599|formula for initializing they have these
3005.24|3.18|data-driven ways of initializing
3006.589|3.27|networks and so you take a batch of data
3008.42|3.03|you forward the through your network
3009.859|3.151|which is now an arbitrary network and
3011.45|2.669|you look at the variances at every
3013.01|2.46|single point in your network and
3014.119|2.881|intuitively you don't want your
3015.47|3.27|variances to go to zero you don't want
3017.0|3.839|them to explode you want everything to
3018.74|4.349|have roughly say like be a unit Gaussian
3020.839|4.201|throughout your network and so they
3023.089|3.421|iteratively scale these weights in your
3025.04|3.269|network so that you have roughly unit
3026.51|4.14|Gaussian activations everywhere or on
3028.309|4.681|the order of that basically and so there
3030.65|3.78|are some data-driven techniques and a
3032.99|4.77|line of work on how to properly
3034.43|5.55|initialize okay so I'm going to go into
3037.76|3.599|some I'm going to go into a technique
3039.98|2.13|that alleviates a lot of these problems
3041.359|3.301|but
3042.11|10.11|right now I could take some questions if
3044.66|8.61|there are any at this point good would
3052.22|3.15|it make sense to standardize the
3053.27|5.07|gradient coming in by dividing by the
3055.37|4.41|variance possibly but then you're not
3058.34|2.82|doing back propagation because if you
3059.78|2.73|meddle with the gradient then it's not
3061.16|2.88|clear what your objective is anymore and
3062.51|3.81|so you're not getting necessarily
3064.04|3.51|gradient so that's maybe the only
3066.32|2.82|concern I'm not sure what would happen
3067.55|4.56|you can you can try to normalize the
3069.14|5.19|gradient I think the method I'm going to
3072.11|4.17|propose in a bit is actually doing
3074.33|5.82|something to the effect of that but in a
3076.28|5.49|clean way okay cool so let's go into
3080.15|3.54|something that actually fixes a lot of
3081.77|3.12|these problems in practice it's called
3083.69|2.82|batch normalization and it was only
3084.89|3.27|proposed last year and so I couldn't
3086.51|3.9|even cover this last year in this class
3088.16|6.15|but now I can and so this actually helps
3090.41|5.82|a lot okay and the basic idea in bash
3094.31|3.54|normalization paper is okay you want
3096.23|4.41|roughly unit Gaussian activations in
3097.85|4.95|every single part of your network and so
3100.64|4.02|just just do that just just make them
3102.8|4.29|unit Gaussian okay you can do that
3104.66|4.08|because making something unit Gaussian
3107.09|4.17|is a completely differentiable function
3108.74|4.98|and so it's okay you can back propagate
3111.26|3.84|through it and so what they do is you're
3113.72|2.28|taking a mini batch of your data and
3115.1|3.39|you're taking it through your network
3116.0|4.08|we're going to be inserting these batch
3118.49|4.05|normalization layers into your network
3120.08|5.79|and the batch normalization layers they
3122.54|4.86|take your input X and they make sure
3125.87|3.96|then every single feature dimension
3127.4|5.94|across the batch you have unit Gaussian
3129.83|4.71|activations so say you have a batch of
3133.34|4.17|100 examples going through the network
3134.54|4.41|maybe this is a good example here so
3137.51|3.15|your batch of activations so you have n
3138.95|3.93|things in your mini batch and you have D
3140.66|5.37|features or D activations of neurons
3142.88|4.92|that are at some point some part and
3146.03|4.26|this is an inputs to your Bachelor
3147.8|4.74|Malaysian layer so this is a matrix of X
3150.29|5.85|of activations and bash normalization
3152.54|5.79|effectively it evaluates the empirical
3156.14|5.49|mean and variance along every single
3158.33|6.12|feature and it just divides by it so
3161.63|4.89|whatever your X was it just makes sure
3164.45|4.29|that every single column here has unit
3166.52|4.26|as a unit Gaussian and so that's a
3168.74|4.59|perfectly differentiable function and it
3170.78|5.3|just applies it at every single feature
3173.33|8.64|or activation independently across the
3176.08|9.76|okay so you can do that and that's it
3181.97|5.58|turns out to be a very good idea now one
3185.84|2.91|problem with this scheme so this is the
3187.55|2.34|way this will work is we'll have
3188.75|2.37|normally we have fully connected
3189.89|2.82|followed by non-linearity fully
3191.12|3.33|connected how about non-linearity and we
3192.71|2.79|have a deep network of this now we're
3194.45|2.49|going to be inserting these batch
3195.5|3.39|normalization layers right after fuller
3196.94|3.72|connected layers or equivalently after
3198.89|3.41|convolutional layers as well see soon in
3200.66|4.62|with convolutional networks and
3202.3|4.36|basically we insert them there and they
3205.28|2.79|make sure that everything is roughly
3206.66|3.21|unit gaussian at every single step of
3208.07|5.82|the network because we just make it so
3209.87|6.03|and one problem you might think of with
3213.89|3.87|this with this is that that seems like a
3215.9|3.27|unnecessary constraint so when you put a
3217.76|3.42|Bachelor normalization here after fuller
3219.17|3.87|connected the outputs will definitely be
3221.18|4.2|unit gushin because you normalize them
3223.04|5.46|but it's not clear that 10h actually
3225.38|4.89|wants to receive unit gaussian inputs so
3228.5|4.11|if you think about the form of 10h it
3230.27|4.17|has a specific scale to it it's not
3232.61|4.5|clear that a neural network wants to
3234.44|4.95|have this hard constraint of making sure
3237.11|4.83|that Batchelor outputs are exactly unit
3239.39|5.55|Gaussian before the 10h because you if
3241.94|5.19|you'd like the network to pick if it
3244.94|4.56|wants your 10h outputs to be more or
3247.13|4.71|less diffuse more or less saturated and
3249.5|4.23|right now it wouldn't be able to that so
3251.84|3.3|a small patch on top of it this is the
3253.73|4.41|second part of batch normalization is
3255.14|4.38|not only do you normalize X but after
3258.14|4.53|normalization you allow the network to
3259.52|5.28|shift by gamma and add a B for every
3262.67|3.42|single feature input and so what this
3264.8|3.54|allows the network to do and these are
3266.09|3.48|all parameters so gamma and B here are
3268.34|5.49|parameters that we're going to back drop
3269.57|6.33|back wrap into and they just allow the
3273.83|3.48|network to to shift after you've
3275.9|3.75|normalized to unit Gaussian they allow
3277.31|4.92|this bump to shift and scale if the
3279.65|4.47|network won't stick and so we initialize
3282.23|3.75|though presumably with 1 and 0 or
3284.12|4.08|something like that and then we can the
3285.98|3.69|network can choose to adjust them and by
3288.2|3.72|adjusting these you can imagine that
3289.67|4.02|once we feed into 10h the network can
3291.92|3.33|choose through the backdrop signal to
3293.69|3.99|make the 10 age more or less picky or
3295.25|3.57|saturate it in whatever way it wants but
3297.68|3.36|you're not going to get into this
3298.82|3.57|trouble where things just completely die
3301.04|3.93|or explode in the beginning of
3302.39|4.47|optimization and so things will train
3304.97|3.26|right away and then back propagation can
3306.86|4.04|take over and can find
3308.23|5.76|over time and note one more important
3310.9|4.74|feature by the way is that if you set
3313.99|4.2|these gamma and B if you train them if
3315.64|4.5|my back propagation it happens that they
3318.19|3.45|end up taking the empirical variance and
3320.14|4.68|the mean then you can see that basically
3321.64|5.94|the network has the capacity to undo the
3324.82|5.37|batch normalization so this part can
3327.58|4.83|learn to undo that part and so that's
3330.19|3.78|why back normalization and can act as an
3332.41|3.42|identity function or it can learn to be
3333.97|3.69|an identity whereas before it couldn't
3335.83|3.779|and so when you have these bachelor
3337.66|4.44|layers in there the network can through
3339.609|4.231|back propagation learn to take it out or
3342.1|3.48|it can learn to take advantage of it if
3343.84|5.79|it finds it helpful through the back
3345.58|6.66|prop this will kind of work out so
3349.63|5.1|that's just a nice point to have and so
3352.24|5.94|basically there are several nice
3354.73|6.72|properties to bachelor so this is the
3358.18|5.37|algorithm as I described nice properties
3361.45|5.28|are that it improves the gradient flow
3363.55|5.49|through the network it allows for higher
3366.73|4.8|learning rates so your network can learn
3369.04|4.02|faster it reduces this is an important
3371.53|3.21|one it reduces the strong dependence on
3373.06|3.059|initialization as you sweep through
3374.74|3.75|different choices of your initialization
3376.119|3.811|scale you'll see that with and without
3378.49|3.119|batch norm you'll see a huge difference
3379.93|3.83|with batch norm you'll see a much more
3381.609|4.561|things will just work for much larger
3383.76|3.73|settings of the initial scale and so you
3386.17|5.91|don't have to worry about it as much it
3387.49|6.45|really helps out with this point and one
3392.08|4.59|kind of more subtle thing to point out
3393.94|5.16|here is it kind of acts as a funny form
3396.67|3.84|of regularization and it reduces need
3399.1|4.53|for dropout which we'll go into in a bit
3400.51|6.599|later in the class but the way it acts
3403.63|6.54|as a funny regularization is with batch
3407.109|5.431|norm when you have some kind of an input
3410.17|4.5|X and it goes through the network then
3412.54|4.17|it's representation at some layer in the
3414.67|4.08|network is basically not only a function
3416.71|3.69|of it but it's also a function of
3418.75|4.23|whatever other examples happen to be in
3420.4|3.87|your batch so because whatever other
3422.98|2.61|examples are with you in that batch
3424.27|3.089|normally these are processed completely
3425.59|4.2|independently in peril but Batchelor
3427.359|3.871|actually ties them together and so your
3429.79|2.91|representation that say like the fifth
3431.23|3.12|layer of network is actually a function
3432.7|3.27|of whatever back you happen to be
3434.35|3.09|sampled in and what this does is it
3435.97|3.48|jitters your place in the representation
3437.44|3.5|space on that layer and this actually
3439.45|4.34|has a nice regularizing effect
3440.94|5.61|and so this jittering sarcastically
3443.79|6.15|through this batch that you happen to be
3446.55|5.16|in has this effect and so I realize it's
3449.94|6.32|hand wavy but actually seems to actually
3451.71|6.54|help out a bit okay and that test time
3456.26|3.579|bachelor layer by the way functions a
3458.25|3.06|bit differently you don't want that test
3459.839|3.661|time you want this to be a deterministic
3461.31|3.48|function so just a quick point that at
3463.5|2.7|test time when you're using a bachelor
3464.79|2.88|layer it functions differently in
3466.2|5.46|particularly you have this mu and a
3467.67|6.06|Sigma that you keep normalizing by so at
3471.66|3.81|test time you just remember your mu and
3473.73|3.69|Sigma across the data set you can either
3475.47|3.75|compute it like what is the mean and
3477.42|3.3|Sigma at every single point in the
3479.22|3.24|network you can compute that once over
3480.72|3.45|your entire training set or you can just
3482.46|3.45|have a running sum of news and Sigma's
3484.17|3.179|while you're training and then make sure
3485.91|3.12|to remember that in the bachelor layer
3487.349|3.361|because that test time you don't want to
3489.03|3.66|actually estimate the empirical mean and
3490.71|5.28|variance across your batch you want to
3492.69|4.8|just use those directly okay so because
3495.99|3.57|this gives you an idea terminus function
3497.49|5.97|forward at test time so there's just a
3499.56|7.2|small detail okay and so that's a batch
3503.46|5.85|norm any any questions about fashion by
3506.76|4.77|the way so this is a good thing use it
3509.31|7.59|and you'll implement it actually in your
3511.53|7.38|assignment good thank you so the
3516.9|4.439|question is does it slow down things at
3518.91|3.63|all it does so there is a runtime
3521.339|2.941|penalty that you have to pay for it
3522.54|3.66|unfortunately I don't know exactly how
3524.28|4.71|expensive it is I heard someone say
3526.2|5.399|value of like 30% even and so I don't
3528.99|4.339|know actually I haven't fully checked
3531.599|3.541|this but basically there is a penalty
3533.329|3.911|because you have to do this at every
3535.14|3.39|normally you it's very common to
3537.24|2.67|basically have a bachelor after every
3538.53|2.94|convolution layer and when you have to
3539.91|3.51|say hundred and fifty calm like layers
3541.47|6.27|you end up having all this stuff build
3543.42|7.28|up any other questions that's the price
3547.74|2.96|we pay I suppose good
3551.08|6.76|your day is not going so well so yeah so
3556.4|3.21|when can you tell that you maybe need
3557.84|4.35|Bosch norm I think I'll come back to
3559.61|4.14|that in a few slides we'll see like how
3562.19|3.78|can you detect that your network is not
3563.75|5.3|healthy and then maybe you want to try
3565.97|6.35|bathroom okay so the learning process I
3569.05|5.62|have 20 minutes I think I can do this
3572.32|3.85|yeah where it's like 70 out of 100 so I
3574.67|4.05|think we're fine okay so we've
3576.17|4.68|pre-processed our data we've decided
3578.72|3.84|let's try let's decide on some for these
3580.85|3.42|purposes of these experiments I'm going
3582.56|3.45|to work with C for 10 and I'm going to
3584.27|4.17|use a two layer neural network with say
3586.01|3.69|50 hit in neurons and I'd like to give
3588.44|2.28|you an idea about like how this looks
3589.7|2.4|like in practice when you're training
3590.72|3.54|neural networks like how do you play
3592.1|3.12|with it where some of the how do you
3594.26|3.09|actually converge to good hyper
3595.22|3.21|parameters what does this process of
3597.35|3.33|playing with the data and getting things
3598.43|3.84|to work look like in practice and so I
3600.68|2.04|decided to try out a small neural
3602.27|3.03|network
3602.72|4.08|I've pre-processed my data and so the
3605.3|3.78|first kinds of things that I would look
3606.8|3.78|at if I want to make sure that my
3609.08|4.11|implementation is correct and things are
3610.58|5.34|working first of all um so I'm going to
3613.19|4.44|be initializing here a two layer neural
3615.92|4.31|network so weights and biases
3617.63|4.71|initialized with just naive
3620.23|3.76|initialization here because this is just
3622.34|3.96|a very small network so I can afford to
3623.99|4.08|maybe do just a naive sample from a
3626.3|2.97|Gaussian and then this is a function
3628.07|3.15|that basically is going to train a
3629.27|3.99|neural network and I'm not showing you
3631.22|4.59|the implementation obviously but just
3633.26|4.11|one thing basically it returns your loss
3635.81|3.48|and returns your gradients on your model
3637.37|3.66|parameters and so the first thing I
3639.29|3.87|might try for example is I disable the
3641.03|4.32|regularization that's passed in the and
3643.16|4.02|and I make sure that my loss comes out
3645.35|2.61|correct right so I've mentioned this in
3647.18|2.55|previous slides
3647.96|4.14|so say I have ten classes in C for 10
3649.73|3.99|I'm using softmax classifier so I know
3652.1|5.28|that I'm expecting a loss of negative
3653.72|5.31|log of one over ten because that's the
3657.38|3.63|that's just the expression for the loss
3659.03|4.08|and that turns out to be 2.3 and so I
3661.01|3.57|put this in I get a loss of 2.3 so I
3663.11|2.58|know that basically the neural network
3664.58|2.73|is currently giving you a diffuse
3665.69|2.28|distribution over the classes because it
3667.31|2.67|doesn't know anything
3667.97|4.05|we've just initialized it so that checks
3669.98|2.85|out the next thing that my check is that
3672.02|3.03|for example I cranked up the
3672.83|4.56|regularization and I of course expect my
3675.05|3.27|loss to go up right because now we have
3677.39|3.57|this additional term in the objective
3678.32|5.97|and so that checks out so that's nice
3680.96|4.56|the next thing I would usually try to do
3684.29|2.22|it's a very good sanity check when
3685.52|2.94|you're working with neural networks is
3686.51|3.84|try to take a small piece of your data
3688.46|3.87|and try to make sure you can over fit
3690.35|4.32|your training data just that small piece
3692.33|4.65|so I'm going to take like say a sample
3694.67|4.71|of like 20 training examples and 28
3696.98|5.13|labels and I just make sure that I train
3699.38|4.32|on that small piece and I just make sure
3702.11|3.78|that I can get a loss of basically near
3703.7|3.84|zero I can fully over fit that because
3705.89|3.3|if I can't over fit a tiny piece of my
3707.54|6.24|data then things are definitely broken
3709.19|7.71|and so here I'm starting the training
3713.78|5.07|and I'm starting with a random number of
3716.9|3.57|parameters here I'm not going to go into
3718.85|4.2|full details there but basically I make
3720.47|5.94|sure that my cost can go down to zero
3723.05|5.25|and that I'm getting accuracy of 100% on
3726.41|3.03|this tiny piece of data and so that
3728.3|3.81|gives me confidence that probably
3729.44|4.74|backprop is working probably the update
3732.11|4.47|is working the learning rate is set
3734.18|3.78|somehow reasonably and so I can over fit
3736.58|3.51|a small data set and I'm happy at this
3737.96|9.12|point and I maybe I'm thinking about now
3740.09|11.61|scaling up to larger a data good then
3747.08|6.3|sometime ie so you should be able to
3751.7|3.36|overfit sometimes I even try like say
3753.38|3.54|like one or two or three examples you
3755.06|3.0|can really crank this down and you
3756.92|2.73|should be able to over fit even with
3758.06|2.73|smaller networks and so that's a very
3759.65|3.24|good sanity check because you can afford
3760.79|3.57|to have small networks and you just make
3762.89|3.33|sure you can over fit if you can't over
3764.36|3.45|fit your implementation is probably
3766.22|3.75|incorrect something is very funky is
3767.81|3.78|wrong so you should not be scaling up to
3769.97|8.36|your full data set before you can pass
3771.59|6.74|the sanity check um so let's see so so
3778.9|4.42|basically the way I try to approach this
3781.16|3.75|is take your small piece of data and now
3783.32|2.82|we're scaling it up we've over fitted so
3784.91|2.61|now I'm scaling up to like the bigger
3786.14|3.9|data set and I'm trying to find the
3787.52|3.66|learning rate that works and you have to
3790.04|2.7|really play with this right you can't
3791.18|3.99|just eyeball the learning rate you have
3792.74|4.47|to find the scale roughly so I'm trying
3795.17|4.17|first a small learning rate like one e-
3797.21|5.13|six and i see that the loss is bate
3799.34|4.83|barely barely going down so this lost
3802.34|5.13|this learning rate of 1 e negative 6 is
3804.17|4.95|probably aa too small right nothing is
3807.47|2.79|changing of course there could be many
3809.12|2.37|other things wrong because your loss
3810.26|3.78|could be constant for like a million
3811.49|3.9|reasons but we've passed a small sanity
3814.04|3.36|check so I'm thinking that this is proud
3815.39|4.469|the loss is too low and I need you to
3817.4|5.34|knit by the way this is a fun example
3819.859|4.621|here of something funky going on that is
3822.74|4.65|fun to think about my loss
3824.48|4.5|just barely went down but actually my
3827.39|5.01|training accuracy shot up to 20 percent
3828.98|4.23|from the default 10 percent how does
3832.4|3.0|that make any sense
3833.21|4.92|how can I be by loss just barely change
3835.4|4.889|but my costs my accuracy is so good well
3838.13|4.399|much much better than 10% how's that
3840.289|2.24|even possible
3857.18|9.119|the regularization term is still yeah
3862.579|9.801|yeah maybe not quote me either not quite
3866.299|6.081|I think my mother per good okay
3878.53|6.69|on okay a bit maybe not quite so think
3883.42|5.93|about how accuracy is computed and how
3885.22|4.13|this cost is computed right go ahead
3895.08|6.88|right right so you you start out with a
3898.03|5.64|fuse losses the diffuse sorry scores and
3901.96|4.17|now what's happening is your training so
3903.67|4.17|these scores are tiny shifting your loss
3906.13|3.42|is still roughly diffused so you end up
3907.84|3.81|at the same loss but now your correct
3909.55|3.48|answers are now tiny bit more probable
3911.65|3.42|and so when you're actually computing
3913.03|3.15|the accuracy the art maxy class is
3915.07|2.7|actually ends up being the correct one
3916.18|3.39|so these are some of the fun things you
3917.77|2.94|run into when you actually train some of
3919.57|4.86|this stuff you have to you have to think
3920.71|5.16|about the expressions okay so now I
3924.43|2.73|start I tried very low learning rate
3925.87|2.55|things are barely happening so now I'm
3927.16|2.4|going to go to the other extreme and I'm
3928.42|3.24|going to try out a learning rate of a
3929.56|5.01|million what could possibly go wrong
3931.66|5.49|so what happens in that case you get
3934.57|3.18|some weird errors and things explode you
3937.15|3.18|get Nan's
3937.75|4.29|really fun stuff happens so okay 1 1
3940.33|4.41|million is probably too high is what I'm
3942.04|4.56|thinking at this point so then I try to
3944.74|3.57|narrow in on rough region that actually
3946.6|2.67|gives me a decrease in my costs right
3948.31|3.18|that's what I'm trying to do with my
3949.27|4.68|binary search here and so at some point
3951.49|4.65|I get some idea about you know roughly
3953.95|4.74|where should I be cross validating ok
3956.14|3.66|like the hyper arm optimization at this
3958.69|3.15|point I'm trying to find the best high
3959.8|3.63|parameters for my network what I really
3961.84|3.9|like to do in practice is go from course
3963.43|4.26|to find strategy so first I just have a
3965.74|3.63|rough idea by playing with it where the
3967.69|3.45|learning rate should be then I do a
3969.37|3.96|course search our learning rates of like
3971.14|4.2|a bigger segment and then I repeat this
3973.33|3.69|process so I look at what works and then
3975.34|4.38|I narrow in on the regions that work
3977.02|4.5|well ok do this here are quickly and in
3979.72|3.27|your code for example detect explosions
3981.52|4.26|and break out early that's like a nice
3982.99|4.26|tip in terms of the implementation so
3985.78|3.72|what I'm doing effectively here is I
3987.25|3.36|have a loop where I sample my hyper
3989.5|2.43|parameters say in this case the
3990.61|4.5|regularization and the learning rate I
3991.93|5.16|sample them I train I get some results
3995.11|3.6|here so these are the accuracies in the
3997.09|3.27|validation data and these are the hyper
3998.71|3.15|parameters that produce them and some of
4000.36|3.12|the accuracies you can see that they
4001.86|3.36|work quite well so fifty percent forty
4003.48|3.54|percent some of them don't work well at
4005.22|3.03|all so this gives me an idea about what
4007.02|2.91|range of learning rates and
4008.25|4.06|regularization are working relatively
4009.93|4.0|well and when you do this type RAM
4012.31|3.81|my zation you can start out first with
4013.93|3.84|just a small number of epochs you don't
4016.12|3.18|to run for a very long time just run for
4017.77|4.62|a few minutes you can already get a
4019.3|6.54|sense of what's working better than than
4022.39|5.55|some other things and also one note when
4025.84|3.84|you're optimizing over regularization of
4027.94|3.45|the learning rate it's best to sample
4029.68|2.85|flow malach space you don't just want to
4031.39|3.81|sample from a uniform distribution
4032.53|4.8|because these are learning rates and
4035.2|4.08|regularization they act multiplicatively
4037.33|3.54|on the dynamics of your back propagation
4039.28|3.87|and so that's why you want to do this in
4040.87|4.38|locked space so you can see that I'm
4043.15|3.45|sampling from negative 3 to negative 6
4045.25|3.06|the exponent for the learning rate and
4046.6|3.36|then I'm raising it to the power of 10
4048.31|4.77|I'm raising ten to the power of it and
4049.96|6.75|so you don't want to just be sampling
4053.08|5.13|from a uniform of 0.01 to like 100
4056.71|3.39|because then most of your samples are
4058.21|3.36|kind of in a bad region right because
4060.1|5.36|the learning rate is a multiplicative
4061.57|6.24|interaction so something to be aware of
4065.46|4.75|now once I found what works relatively
4067.81|3.75|well of course doing a second pass where
4070.21|3.0|I'm kind of going in and I'm changing
4071.56|4.86|these again a bit and I'm looking at
4073.21|5.27|what works so I find that I can now get
4076.42|4.32|to 53 so some of these work really well
4078.48|5.05|one thing to be aware of sometimes you
4080.74|5.25|get a result like this so 53 is working
4083.53|4.26|quite well and this is actually where if
4085.99|4.86|I see this I'm actually worried at this
4087.79|4.62|point because I'm so through this
4090.85|2.73|cross-validation here I have a result
4092.41|2.94|here and there's something actually
4093.58|9.779|wrong about this result that hints at
4095.35|10.43|some issue there's an unsettling problem
4103.359|2.421|with this result
4111.13|5.62|looks like necessarily Baltimore a local
4115.279|6.571|Optima is not necessarily global optimum
4116.75|6.63|so what makes you say that exactly oh I
4121.85|3.21|see so you're saying that actually
4123.38|3.81|they're quite a defuse in a sense like
4125.06|6.15|there's not they're not consistent too
4127.19|5.94|much yeah perhaps okay so an interest of
4131.21|3.299|time what's happening here look I'm
4133.13|2.97|optimizing learning rate between
4134.509|3.96|negative three negative four ten to the
4136.1|4.139|and I end up with a very good result
4138.469|4.08|that is just at the boundary of what I'm
4140.239|4.321|hiper I'm optimizing over so this is
4142.549|4.23|almost 1 a negative 3 it's almost zero
4144.56|4.049|point zero zero one which ends which is
4146.779|3.661|really a boundary of what I'm searching
4148.609|3.63|over so I'm getting a really good result
4150.44|3.93|at an edge of what I'm looking for and
4152.239|3.87|that's not good because maybe this edge
4154.37|4.05|here the way I've defined it is not
4156.109|3.48|actually optimal and so I want to make
4158.42|2.7|sure that I spot these things and I
4159.589|4.23|adjust my ranges because there might be
4161.12|4.17|even better results going slightly this
4163.819|4.531|way so maybe I want to change negative 3
4165.29|4.799|to negative 2 or 2.5 and but for
4168.35|4.259|regularization I see that a 1 a negative
4170.089|4.02|4 is working quite well so maybe I'm in
4172.609|5.701|a slightly better spot and so on so
4174.109|5.281|worried about this one thing also I'd
4178.31|3.84|like to point out is you'll see me
4179.39|4.619|sample these randomly so 10 to the
4182.15|3.029|uniform of this so I'm sampling random
4184.009|2.94|regularization and learning rates when
4185.179|3.151|I'm doing this what you might see
4186.949|3.361|sometimes people do is what's called a
4188.33|3.63|grid search so really the difference
4190.31|4.56|here is instead of sampling randomly
4191.96|4.529|people like to go in steps of fixed
4194.87|4.349|amounts in both the learning rate and
4196.489|4.98|the regularization and so you hand up
4199.219|3.301|with this double loop here over some
4201.469|2.371|settings of learning rate and some
4202.52|3.449|settings of regularization because
4203.84|3.629|you're trying to be exhaustive and this
4205.969|3.391|is actually a bad idea it doesn't
4207.469|4.651|actually work as well as if you sample
4209.36|4.41|randomly and it's unintuitive but you
4212.12|3.24|actually always want to sample randomly
4213.77|3.54|you don't want to go in fixed steps and
4215.36|4.379|here's the reason for that it's kind of
4217.31|6.599|you think about it a bit but this is the
4219.739|5.761|grid search way so I've sampled at set
4223.909|4.981|intervals and I kind of have confidence
4225.5|6.21|that I've you know sweep out this this
4228.89|4.079|entire space and as opposed to random
4231.71|3.36|sampling where I've just randomly
4232.969|3.601|sampled from the to the issue is that in
4235.07|3.149|hyper parameter optimization in training
4236.57|3.96|neural networks what often happens is
4238.219|3.541|that one of the parameters can be much
4240.53|2.139|much more important than the other
4241.76|2.709|parameter
4242.669|3.3|okay so say that this is an unimportant
4244.469|3.24|parameter it's performance the
4245.969|3.9|performance of your loss function is not
4247.709|3.21|really a function of the Y dimension but
4249.869|2.641|it's really a function of the X
4250.919|4.29|dimension you get much better result in
4252.51|6.12|a specific range along the x axis and if
4255.209|5.7|this is true then which is often the
4258.63|3.509|case then in this case you're actually
4260.909|2.94|going to end up sampling lots of
4262.139|4.11|different X's and you end up with a
4263.849|4.59|better spot then here where you've
4266.249|3.66|sampled at exact spots and you're not
4268.439|4.02|getting any kind of information across
4269.909|5.01|the X if that makes sense so always use
4272.459|5.49|random because in these cases which are
4274.919|8.52|common the random will actually give you
4277.949|6.57|more bang for the buck okay so there are
4283.439|2.79|several high programs you want to play
4284.519|5.69|with the most common ones are probably
4286.229|6.06|the learning rate the update type maybe
4290.209|3.94|we're going to we're going to go into
4292.289|3.42|this in a bit the regularization and the
4294.149|4.05|dropout amounts which we're going to go
4295.709|6.39|into so this is really a it's so much
4298.199|5.34|fun so in practice the way what this
4302.099|3.09|looks like as we have it for example a
4303.539|3.81|computer vision cluster we have 70
4305.189|3.93|machines so I can just distribute my
4307.349|3.06|training across 70 machines and I've
4309.119|3.21|written myself for example a command
4310.409|2.94|center interface where these are all the
4312.329|2.46|loss functions on all the different
4313.349|3.511|machines in our computer vision cluster
4314.789|5.071|these are all here hyper parameters I'm
4316.86|4.259|searching over and I can see basically
4319.86|2.639|what's working well and what isn't and I
4321.119|2.79|can send commands to my workers and I
4322.499|3.301|can say okay this isn't working at all
4323.909|3.3|so just resample you're not doing well
4325.8|3.06|at all and some of these are doing very
4327.209|2.97|well and I look at what's exactly
4328.86|3.389|working well and I'm adjusting it's a
4330.179|3.48|dynamic process that I have to go
4332.249|3.0|through to actually get this stuff to
4333.659|3.451|work well because you just have too much
4335.249|4.23|stuff to optimize over and you can't
4337.11|5.609|afford to just a spray and pray you have
4339.479|4.62|to work with it okay so you're
4342.719|4.23|optimizing and you're looking at loss
4344.099|5.011|functions these loss functions can take
4346.949|4.351|various different forms and you need to
4349.11|4.799|be able to read into what that means so
4351.3|4.319|you'll be you'll get quite good at
4353.909|4.23|looking at loss functions and intuiting
4355.619|4.201|what happens so this one for example I
4358.139|3.991|was pointing out in the previous lecture
4359.82|4.589|it's not as exponential as I may be used
4362.13|5.009|to my loss functions I'd like it to you
4364.409|4.23|know it looks a little too linear and so
4367.139|3.391|that maybe tells me that the learning
4368.639|3.0|rate is maybe slightly too low so that
4370.53|2.399|doesn't mean the learning rate is too
4371.639|2.981|low it just means that I might want to
4372.929|3.851|consider trying a higher learning
4374.62|3.78|right sometimes you get all kinds of
4376.78|3.12|funny things so you can have a plateau
4378.4|4.73|where at some point the network decides
4379.9|5.73|that it's now ready to optimize usually
4383.13|9.54|so what is the prime suspect in these
4385.63|7.04|kinds of cases just a guess maybe sorry
4393.21|4.18|yeah sure so weights initialization I
4395.56|3.03|think is the prime suspect you've
4397.39|2.76|initialized them incorrectly the
4398.59|3.45|gradients are barely flowing but at some
4400.15|4.71|point they add up and it just suddenly
4402.04|4.17|starts training so lots of fun in fact
4404.86|3.06|it's so much fun that I've started an
4406.21|7.05|entire tumblr a while ago on loss
4407.92|7.17|functions so you can go through these so
4413.26|3.9|people contribute these which is nice
4415.09|3.48|and so this is I think someone training
4417.16|4.26|a spatial transformer network we're
4418.57|3.93|going to go into that this is a all
4421.42|3.21|kinds of exotic shapes
4422.5|4.05|I'm not even you know at some point
4424.63|2.99|you're not really sure how what any of
4426.55|4.64|this means
4427.62|3.57|it's going so well
4434.44|7.509|yeah so here this this is again like
4440.54|4.32|several tasks that are training at the
4441.949|5.52|same time and just this by the way I
4444.86|3.66|know what happened here it's this is
4447.469|2.52|actually training a reinforcement
4448.52|2.67|learning agent the problem in
4449.989|2.73|reinforcement learning is you don't have
4451.19|3.239|a stationary data distribution you don't
4452.719|2.881|have a fixed data set in reinforcement
4454.429|2.401|learning you're an agent interacting
4455.6|2.7|with the environment if your policy
4456.83|3.36|changes and you end up like staring at
4458.3|3.66|the wall or you end up looking at
4460.19|3.299|different parts of your space you end up
4461.96|3.36|with different data distributions and so
4463.489|3.031|suddenly I'm looking at something very
4465.32|2.64|different than what I used to be looking
4466.52|2.67|at and I'm training my agent and the
4467.96|3.06|loss goes up because the agent is
4469.19|3.72|unfamiliar with that kind of inputs and
4471.02|6.87|so you have all kinds of fun stuff
4472.91|7.23|happening there and then so this one is
4477.89|4.05|one of my favorites I have no idea what
4480.14|4.53|basically happened here this loss
4481.94|3.9|oscillates but roughly does and then it
4484.67|3.81|kind of just explodes
4485.84|6.089|I clearly something was not fully right
4488.48|5.699|in this case and also here it just kind
4491.929|5.341|of some point decides to converge I have
4494.179|4.471|no idea what was wrong so you get all
4497.27|3.3|kinds of funny things if you end up with
4498.65|3.27|funny plots in your assignments and
4500.57|5.22|please do send them to loss functions
4501.92|5.13|that some will post them so during
4505.79|2.82|training don't only look at the loss
4507.05|5.399|function another thing to look at is
4508.61|5.76|your accuracy especially accuracies for
4512.449|3.241|example so you sometimes prefer looking
4514.37|3.0|at accuracies over loss functions
4515.69|3.18|because accuracies are interpretable i
4517.37|3.93|know what these classification
4518.87|3.99|accuracies mean in absolute terms
4521.3|3.99|whereas for loss function is maybe not
4522.86|4.379|as interpretable and so in particular I
4525.29|4.08|have a loss I have an accuracy curve for
4527.239|3.96|my validation data and my training data
4529.37|3.48|and so for example in this case I'm
4531.199|3.301|saying that my training data accuracy is
4532.85|2.79|getting much much better and my
4534.5|3.21|validation accuracy has stopped
4535.64|3.66|improving and so based on this gap that
4537.71|3.06|can give you hints on what might be
4539.3|3.09|going on under the hood in this
4540.77|3.24|particular case there's a huge gap here
4542.39|3.12|so maybe I'm thinking I'm overfitting
4544.01|3.24|I'm not a hundred percent sure but I
4545.51|4.68|might be overfitting I might want to try
4547.25|3.9|to regularize strongly more strongly one
4550.19|6.33|of the things you might also be looking
4551.15|8.22|at is tracking the difference between
4556.52|4.29|the scale of your parameters and the
4559.37|4.86|scale of your updates to those
4560.81|5.04|parameters so say your your suppose that
4564.23|4.47|your weights are on the order of unit
4565.85|4.11|in distributed then intuitively the
4568.7|3.18|updates that you're incrementing your
4569.96|3.99|weights by in backpropagation you don't
4571.88|3.84|want those updates to be much larger
4573.95|3.09|than the weights obviously or you don't
4575.72|2.82|want them to be tiny like you don't want
4577.04|3.06|your updates to be on the order of one
4578.54|4.07|in negative seven when your weights are
4580.1|4.74|on the order of one negative two and so
4582.61|3.49|look at the update that you're about to
4584.84|3.36|increment onto your weights
4586.1|4.11|and just look at its norm for example
4588.2|4.46|the sum of squares and compare it to the
4590.21|4.35|update the scale of your parameters and
4592.66|3.25|usually a good rule of thumb is this
4594.56|3.99|should be roughly one in negative three
4595.91|4.14|so basically every single update you're
4598.55|2.88|modifying on the order of like a third
4600.05|2.82|significant digit for every single
4601.43|2.58|parameter right you're not making huge
4602.87|3.35|updates you're not making very small
4604.01|4.26|updates so that's one thing to look at
4606.22|4.36|roughly one a negative three usually
4608.27|3.9|works okay if this is too high I want to
4610.58|3.03|maybe decrease my learning rate if it's
4612.17|2.85|way too low like say it's money negative
4613.61|6.45|seven maybe I want to increase my
4615.02|7.59|learning rate and so in summary today we
4620.06|5.61|looked at a whole bunch of things to do
4622.61|4.68|with training neural networks the TLDR s
4625.67|4.71|of all of them are basically use values
4627.29|6.42|for images subtract mean use the heavier
4630.38|4.86|initialization or if you think you have
4633.71|4.62|a smaller network you can maybe get away
4635.24|4.14|with just choosing your scale to be 0.01
4638.33|3.15|or maybe you want to play with that a
4639.38|4.89|bit there's no strong recommendation
4641.48|5.16|here I think a batch normalization just
4644.27|4.98|use and when you're doing high parameter
4646.64|4.83|optimization make sure to sample your
4649.25|5.97|head REMS and do it in lock space when
4651.47|7.05|appropriate and that's something to be
4655.22|6.21|aware of and this is what we still have
4658.52|4.47|to cover and that will be next class we
4661.43|7.33|do have two more minutes so I will take
4662.99|13.85|questions if there are any but
4668.76|9.61|the way to like know how they're gonna
4676.84|5.88|like poorly with each other's reunited
4678.37|6.03|like randomly yes oh you're asking about
4682.72|3.48|the correlation between regularization
4684.4|2.91|and the learning rate you you optimize
4686.2|2.94|over both of them during half the
4687.31|3.84|parameter optimization right and you try
4689.14|4.11|to decouple them but maybe the yeah I
4691.15|4.5|don't think there's any obvious thing I
4693.25|3.45|can recommend there you have to guess
4695.65|3.06|and check a bit I don't think that
4696.7|7.47|anything jumps out at me that's obvious
4698.71|8.39|or not to decouple them okay great no
4704.17|2.93|more questions or them
4714.369|4.551|have a quick question regarding sign