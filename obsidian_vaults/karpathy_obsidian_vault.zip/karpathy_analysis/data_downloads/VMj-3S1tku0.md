start_time|end_time|text
0.08|2.88|hello my name is andre
1.839|3.041|and i've been training deep neural
2.96|3.839|networks for a bit more than a decade
4.88|3.759|and in this lecture i'd like to show you
6.799|4.081|what neural network training looks like
8.639|3.601|under the hood so in particular we are
10.88|3.44|going to start with a blank jupiter
12.24|4.4|notebook and by the end of this lecture
14.32|3.84|we will define and train in neural net
16.64|3.6|and you'll get to see everything that
18.16|3.52|goes on under the hood and exactly
20.24|2.4|sort of how that works on an intuitive
21.68|2.48|level
22.64|3.92|now specifically what i would like to do
24.16|5.199|is i would like to take you through
26.56|4.32|building of micrograd now micrograd is
29.359|3.521|this library that i released on github
30.88|4.0|about two years ago but at the time i
32.88|4.4|only uploaded the source code and you'd
34.88|4.4|have to go in by yourself and really
37.28|3.36|figure out how it works
39.28|3.119|so in this lecture i will take you
40.64|3.759|through it step by step and kind of
42.399|5.041|comment on all the pieces of it so what
44.399|4.561|is micrograd and why is it interesting
47.44|2.4|good
48.96|2.56|um
49.84|4.0|micrograd is basically an autograd
51.52|4.16|engine autograd is short for automatic
53.84|3.84|gradient and really what it does is it
55.68|3.679|implements backpropagation now
57.68|3.6|backpropagation is this algorithm that
59.359|4.161|allows you to efficiently evaluate the
61.28|3.919|gradient of
63.52|3.68|some kind of a loss function with
65.199|3.92|respect to the weights of a neural
67.2|3.84|network and what that allows us to do
69.119|3.441|then is we can iteratively tune the
71.04|3.28|weights of that neural network to
72.56|3.919|minimize the loss function and therefore
74.32|4.0|improve the accuracy of the network so
76.479|4.0|back propagation would be at the
78.32|4.24|mathematical core of any modern deep
80.479|3.521|neural network library like say pytorch
82.56|3.04|or jaxx
84.0|3.6|so the functionality of microgrant is i
85.6|4.24|think best illustrated by an example so
87.6|3.6|if we just scroll down here
89.84|3.12|you'll see that micrograph basically
91.2|3.04|allows you to build out mathematical
92.96|3.6|expressions
94.24|3.6|and um here what we are doing is we have
96.56|4.32|an expression that we're building out
97.84|5.44|where you have two inputs a and b
100.88|5.279|and you'll see that a and b are negative
103.28|5.36|four and two but we are wrapping those
106.159|3.761|values into this value object that we
108.64|2.4|are going to build out as part of
109.92|3.6|micrograd
111.04|3.92|so this value object will wrap the
113.52|2.72|numbers themselves
114.96|3.519|and then we are going to build out a
116.24|5.68|mathematical expression here where a and
118.479|5.441|b are transformed into c d and
121.92|3.68|eventually e f and g
123.92|3.12|and i'm showing some of the functions
125.6|3.359|some of the functionality of micrograph
127.04|3.999|and the operations that it supports so
128.959|4.401|you can add two value objects you can
131.039|4.721|multiply them you can raise them to a
133.36|5.28|constant power you can offset by one
135.76|5.76|negate squash at zero
138.64|4.0|square divide by constant divide by it
141.52|2.799|etc
142.64|4.72|and so we're building out an expression
144.319|6.0|graph with with these two inputs a and b
147.36|5.28|and we're creating an output value of g
150.319|3.841|and micrograd will in the background
152.64|3.76|build out this entire mathematical
154.16|4.56|expression so it will for example know
156.4|4.96|that c is also a value
158.72|4.08|c was a result of an addition operation
161.36|5.28|and the
162.8|6.079|child nodes of c are a and b because the
166.64|4.16|and will maintain pointers to a and b
168.879|4.481|value objects so we'll basically know
170.8|4.64|exactly how all of this is laid out
173.36|3.68|and then not only can we do what we call
175.44|3.2|the forward pass where we actually look
177.04|3.52|at the value of g of course that's
178.64|4.959|pretty straightforward we will access
180.56|5.52|that using the dot data attribute and so
183.599|5.761|the output of the forward pass the value
186.08|5.84|of g is 24.7 it turns out but the big
189.36|4.48|deal is that we can also take this g
191.92|2.959|value object and we can call that
193.84|2.88|backward
194.879|4.961|and this will basically uh initialize
196.72|4.64|back propagation at the node g
199.84|3.36|and what backpropagation is going to do
201.36|3.84|is it's going to start at g and it's
203.2|3.52|going to go backwards through that
205.2|3.599|expression graph and it's going to
206.72|3.36|recursively apply the chain rule from
208.799|3.44|calculus
210.08|4.159|and what that allows us to do then is
212.239|4.321|we're going to evaluate basically the
214.239|3.92|derivative of g with respect to all the
216.56|4.399|internal nodes
218.159|5.041|like e d and c but also with respect to
220.959|4.401|the inputs a and b
223.2|4.72|and then we can actually query this
225.36|4.799|derivative of g with respect to a for
227.92|4.56|example that's a dot grad in this case
230.159|4.08|it happens to be 138 and the derivative
232.48|4.959|of g with respect to b
234.239|5.2|which also happens to be here 645
237.439|3.921|and this derivative we'll see soon is
239.439|5.44|very important information because it's
241.36|5.519|telling us how a and b are affecting g
244.879|3.201|through this mathematical expression so
246.879|4.961|in particular
248.08|6.719|a dot grad is 138 so if we slightly
251.84|6.16|nudge a and make it slightly larger
254.799|4.641|138 is telling us that g will grow and
258.0|2.72|the slope of that growth is going to be
259.44|3.52|138
260.72|4.88|and the slope of growth of b is going to
262.96|4.88|be 645. so that's going to tell us about
265.6|4.159|how g will respond if a and b get
267.84|3.28|tweaked a tiny amount in a positive
269.759|3.601|direction
271.12|2.24|okay
273.44|3.36|now you might be confused about what
274.88|3.68|this expression is that we built out
276.8|3.92|here and this expression by the way is
278.56|3.68|completely meaningless i just made it up
280.72|3.039|i'm just flexing about the kinds of
282.24|2.64|operations that are supported by
283.759|2.561|micrograd
284.88|3.2|what we actually really care about are
286.32|3.52|neural networks but it turns out that
288.08|3.839|neural networks are just mathematical
289.84|5.04|expressions just like this one but
291.919|4.401|actually slightly bit less crazy even
294.88|4.16|neural networks are just a mathematical
296.32|4.4|expression they take the input data as
299.04|3.439|an input and they take the weights of a
300.72|3.84|neural network as an input and it's a
302.479|3.841|mathematical expression and the output
304.56|3.6|are your predictions of your neural net
306.32|4.24|or the loss function we'll see this in a
308.16|3.92|bit but basically neural networks just
310.56|3.199|happen to be a certain class of
312.08|3.119|mathematical expressions
313.759|3.361|but back propagation is actually
315.199|3.601|significantly more general it doesn't
317.12|3.519|actually care about neural networks at
318.8|3.6|all it only tells us about arbitrary
320.639|3.84|mathematical expressions and then we
322.4|4.4|happen to use that machinery for
324.479|3.921|training of neural networks now one more
326.8|3.44|note i would like to make at this stage
328.4|4.239|is that as you see here micrograd is a
330.24|4.0|scalar valued auto grant engine so it's
332.639|3.361|working on the you know level of
334.24|3.519|individual scalars like negative four
336.0|3.28|and two and we're taking neural nets and
337.759|3.601|we're breaking them down all the way to
339.28|3.84|these atoms of individual scalars and
341.36|4.24|all the little pluses and times and it's
343.12|4.0|just excessive and so obviously you
345.6|3.2|would never be doing any of this in
347.12|3.68|production it's really just put down for
348.8|3.52|pedagogical reasons because it allows us
350.8|3.76|to not have to deal with these
352.32|4.64|n-dimensional tensors that you would use
354.56|4.4|in modern deep neural network library so
356.96|3.76|this is really done so that you
358.96|3.76|understand and refactor out back
360.72|4.24|propagation and chain rule and
362.72|4.0|understanding of neurologic training
364.96|3.12|and then if you actually want to train
366.72|3.12|bigger networks you have to be using
368.08|3.2|these tensors but none of the math
369.84|3.6|changes this is done purely for
371.28|2.96|efficiency we are basically taking scale
373.44|2.56|value
374.24|3.519|all the scale values we're packaging
376.0|4.08|them up into tensors which are just
377.759|4.641|arrays of these scalars and then because
380.08|4.32|we have these large arrays we're making
382.4|3.68|operations on those large arrays that
384.4|4.239|allows us to take advantage of the
386.08|4.399|parallelism in a computer and all those
388.639|3.761|operations can be done in parallel and
390.479|3.201|then the whole thing runs faster but
392.4|3.28|really none of the math changes and
393.68|3.2|that's done purely for efficiency so i
395.68|2.959|don't think that it's pedagogically
396.88|3.84|useful to be dealing with tensors from
398.639|3.921|scratch uh and i think and that's why i
400.72|3.759|fundamentally wrote micrograd because
402.56|3.84|you can understand how things work uh at
404.479|4.401|the fundamental level and then you can
406.4|4.799|speed it up later okay so here's the fun
408.88|3.92|part my claim is that micrograd is what
411.199|3.761|you need to train your networks and
412.8|3.519|everything else is just efficiency so
414.96|3.6|you'd think that micrograd would be a
416.319|4.72|very complex piece of code and that
418.56|4.639|turns out to not be the case
421.039|4.0|so if we just go to micrograd
423.199|4.161|and you'll see that there's only two
425.039|4.081|files here in micrograd this is the
427.36|3.52|actual engine it doesn't know anything
429.12|3.6|about neural nuts and this is the entire
430.88|6.319|neural nets library
432.72|7.12|on top of micrograd so engine and nn.pi
437.199|4.0|so the actual backpropagation autograd
439.84|2.56|engine
441.199|4.881|that gives you the power of neural
442.4|6.0|networks is literally
446.08|3.92|100 lines of code of like very simple
448.4|2.72|python
450.0|2.08|which we'll understand by the end of
451.12|2.72|this lecture
452.08|3.6|and then nn.pi
453.84|3.919|this neural network library built on top
455.68|4.88|of the autograd engine
457.759|4.961|um is like a joke it's like
460.56|3.44|we have to define what is a neuron and
462.72|3.36|then we have to define what is the layer
464.0|3.84|of neurons and then we define what is a
466.08|4.32|multi-layer perceptron which is just a
467.84|4.16|sequence of layers of neurons and so
470.4|3.04|it's just a total joke
472.0|3.68|so basically
473.44|4.159|there's a lot of power that comes from
475.68|3.44|only 150 lines of code
477.599|3.28|and that's all you need to understand to
479.12|3.6|understand neural network training and
480.879|4.801|everything else is just efficiency and
482.72|4.4|of course there's a lot to efficiency
485.68|3.44|but fundamentally that's all that's
487.12|4.16|happening okay so now let's dive right
489.12|3.28|in and implement micrograph step by step
491.28|2.479|the first thing i'd like to do is i'd
492.4|3.84|like to make sure that you have a very
493.759|4.481|good understanding intuitively of what a
496.24|4.32|derivative is and exactly what
498.24|4.079|information it gives you so let's start
500.56|4.72|with some basic imports that i copy
502.319|5.041|paste in every jupiter notebook always
505.28|3.68|and let's define a function a scalar
507.36|2.88|valued function
508.96|2.4|f of x
510.24|2.96|as follows
511.36|3.2|so i just make this up randomly i just
513.2|3.519|want to scale a valid function that
514.56|4.0|takes a single scalar x and returns a
516.719|3.361|single scalar y
518.56|4.24|and we can call this function of course
520.08|3.839|so we can pass in say 3.0 and get 20
522.8|2.8|back
523.919|3.521|now we can also plot this function to
525.6|3.28|get a sense of its shape you can tell
527.44|3.28|from the mathematical expression that
528.88|2.959|this is probably a parabola it's a
530.72|5.679|quadratic
531.839|5.841|and so if we just uh create a set of um
536.399|3.12|um
537.68|3.44|scale values that we can feed in using
539.519|4.401|for example a range from negative five
541.12|5.52|to five in steps of 0.25
543.92|7.44|so this is so axis is just from negative
546.64|6.08|5 to 5 not including 5 in steps of 0.25
551.36|3.28|and we can actually call this function
552.72|4.96|on this numpy array as well so we get a
554.64|5.759|set of y's if we call f on axis
557.68|5.839|and these y's are basically
560.399|4.961|also applying a function on every one of
563.519|4.481|these elements independently
565.36|5.84|and we can plot this using matplotlib so
568.0|5.76|plt.plot x's and y's and we get a nice
571.2|5.36|parabola so previously here we fed in
573.76|5.28|3.0 somewhere here and we received 20
576.56|4.08|back which is here the y coordinate so
579.04|3.359|now i'd like to think through
580.64|3.68|what is the derivative
582.399|3.12|of this function at any single input
584.32|2.72|point x
585.519|4.32|right so what is the derivative at
587.04|4.16|different points x of this function now
589.839|2.401|if you remember back to your calculus
591.2|3.44|class you've probably derived
592.24|4.96|derivatives so we take this mathematical
594.64|3.759|expression 3x squared minus 4x plus 5
597.2|2.72|and you would write out on a piece of
598.399|2.961|paper and you would you know apply the
599.92|3.52|product rule and all the other rules and
601.36|4.08|derive the mathematical expression of
603.44|3.28|the great derivative of the original
605.44|2.56|function and then you could plug in
606.72|3.04|different texts and see what the
608.0|3.519|derivative is
609.76|3.92|we're not going to actually do that
611.519|3.841|because no one in neural networks
613.68|2.96|actually writes out the expression for
615.36|3.52|the neural net it would be a massive
616.64|3.84|expression um it would be you know
618.88|3.76|thousands tens of thousands of terms no
620.48|3.919|one actually derives the derivative of
622.64|3.52|course and so we're not going to take
624.399|2.961|this kind of like a symbolic approach
626.16|3.119|instead what i'd like to do is i'd like
627.36|3.039|to look at the definition of derivative
629.279|3.041|and just make sure that we really
630.399|4.401|understand what derivative is measuring
632.32|6.32|what it's telling you about the function
634.8|3.84|and so if we just look up derivative
642.32|2.32|we see that
643.519|2.56|okay so this is not a very good
644.64|2.639|definition of derivative this is a
646.079|2.401|definition of what it means to be
647.279|2.881|differentiable
648.48|4.08|but if you remember from your calculus
650.16|5.76|it is the limit as h goes to zero of f
652.56|5.839|of x plus h minus f of x over h so
655.92|5.039|basically what it's saying is if you
658.399|4.481|slightly bump up you're at some point x
660.959|3.601|that you're interested in or a and if
662.88|3.199|you slightly bump up
664.56|3.519|you know you slightly increase it by
666.079|3.681|small number h
668.079|3.361|how does the function respond with what
669.76|3.84|sensitivity does it respond what is the
671.44|4.88|slope at that point does the function go
673.6|4.4|up or does it go down and by how much
676.32|2.4|and that's the slope of that function
678.0|3.76|the
678.72|5.2|the slope of that response at that point
681.76|4.56|and so we can basically evaluate
683.92|4.08|the derivative here numerically by
686.32|3.84|taking a very small h of course the
688.0|3.76|definition would ask us to take h to
690.16|3.84|zero we're just going to pick a very
691.76|3.36|small h 0.001
694.0|3.76|and let's say we're interested in point
695.12|3.839|3.0 so we can look at f of x of course
697.76|3.199|as 20
698.959|3.841|and now f of x plus h
700.959|3.601|so if we slightly nudge x in a positive
702.8|2.8|direction how is the function going to
704.56|3.12|respond
705.6|3.6|and just looking at this do you expect
707.68|4.24|do you expect f of x plus h to be
709.2|5.439|slightly greater than 20 or do you
711.92|5.12|expect to be slightly lower than 20
714.639|4.401|and since this 3 is here and this is 20
717.04|4.32|if we slightly go positively the
719.04|4.0|function will respond positively so
721.36|4.0|you'd expect this to be slightly greater
723.04|3.44|than 20. and now by how much it's
725.36|2.479|telling you the
726.48|3.44|sort of the
727.839|4.961|the strength of that slope right the the
729.92|4.88|size of the slope so f of x plus h minus
732.8|3.2|f of x this is how much the function
734.8|3.12|responded
736.0|3.92|in the positive direction and we have to
737.92|4.4|normalize by the
739.92|4.88|run so we have the rise over run to get
742.32|4.48|the slope so this of course is just a
744.8|4.08|numerical approximation of the slope
746.8|6.0|because we have to make age very very
748.88|6.639|small to converge to the exact amount
752.8|4.0|now if i'm doing too many zeros
755.519|2.801|at some point
756.8|2.8|i'm gonna get an incorrect answer
758.32|3.519|because we're using floating point
759.6|4.16|arithmetic and the representations of
761.839|3.761|all these numbers in computer memory is
763.76|2.639|finite and at some point we get into
765.6|2.16|trouble
766.399|4.0|so we can converse towards the right
767.76|6.8|answer with this approach
770.399|5.68|but basically um at 3 the slope is 14.
774.56|3.76|and you can see that by taking 3x
776.079|4.401|squared minus 4x plus 5 and
778.32|4.319|differentiating it in our head
780.48|4.4|so 3x squared would be
782.639|4.64|6 x minus 4
784.88|6.0|and then we plug in x equals 3 so that's
787.279|4.8|18 minus 4 is 14. so this is correct
790.88|4.88|so that's
792.079|5.281|at 3. now how about the slope at say
795.76|3.759|negative 3
797.36|3.12|would you expect would you expect for
799.519|2.801|the slope
800.48|4.479|now telling the exact value is really
802.32|4.48|hard but what is the sign of that slope
804.959|3.44|so at negative three
806.8|3.92|if we slightly go in the positive
808.399|4.161|direction at x the function would
810.72|3.2|actually go down and so that tells you
812.56|4.16|that the slope would be negative so
813.92|5.2|we'll get a slight number below
816.72|4.16|below 20. and so if we take the slope we
819.12|4.719|expect something negative
820.88|4.639|negative 22. okay
823.839|3.761|and at some point here of course the
825.519|3.361|slope would be zero now for this
827.6|3.679|specific function i looked it up
828.88|3.28|previously and it's at point two over
831.279|3.041|three
832.16|3.76|so at roughly two over three
834.32|2.8|uh that's somewhere here
835.92|3.279|um
837.12|6.32|this derivative be zero
839.199|5.041|so basically at that precise point
843.44|2.88|yeah
844.24|3.52|at that precise point if we nudge in a
846.32|3.519|positive direction the function doesn't
847.76|4.079|respond this stays the same almost and
849.839|4.481|so that's why the slope is zero okay now
851.839|4.0|let's look at a bit more complex case
854.32|3.68|so we're going to start you know
855.839|3.841|complexifying a bit so now we have a
858.0|2.959|function
859.68|2.959|here
860.959|3.201|with output variable d
862.639|3.521|that is a function of three scalar
864.16|4.32|inputs a b and c
866.16|4.479|so a b and c are some specific values
868.48|4.32|three inputs into our expression graph
870.639|5.681|and a single output d
872.8|5.36|and so if we just print d we get four
876.32|3.92|and now what i have to do is i'd like to
878.16|4.32|again look at the derivatives of d with
880.24|4.64|respect to a b and c
882.48|3.76|and uh think through uh again just the
884.88|2.639|intuition of what this derivative is
886.24|3.599|telling us
887.519|4.56|so in order to evaluate this derivative
889.839|4.081|we're going to get a bit hacky here
892.079|3.281|we're going to again have a very small
893.92|3.44|value of h
895.36|3.2|and then we're going to fix the inputs
897.36|2.96|at some
898.56|4.399|values that we're interested in
900.32|3.92|so these are the this is the point abc
902.959|2.481|at which we're going to be evaluating
904.24|3.52|the the
905.44|4.32|derivative of d with respect to all a b
907.76|3.6|and c at that point
909.76|4.0|so there are the inputs and now we have
911.36|3.68|d1 is that expression
913.76|3.36|and then we're going to for example look
915.04|4.88|at the derivative of d with respect to a
917.12|4.88|so we'll take a and we'll bump it by h
919.92|3.919|and then we'll get d2 to be the exact
922.0|4.8|same function
923.839|4.881|and now we're going to print um
926.8|4.32|you know f1
928.72|4.16|d1 is d1
931.12|4.079|d2 is d2
932.88|4.8|and print slope
935.199|4.481|so the derivative or slope
937.68|3.519|here will be um
939.68|2.399|of course
941.199|3.2|d2
942.079|5.361|minus d1 divide h
944.399|4.321|so d2 minus d1 is how much the function
947.44|3.28|increased
948.72|3.2|uh when we bumped
950.72|2.72|the uh
951.92|3.919|the specific input that we're interested
953.44|3.28|in by a tiny amount
955.839|3.36|and
956.72|5.359|this is then normalized by h
959.199|2.88|to get the slope
962.8|2.32|so
963.6|2.72|um
965.12|3.76|yeah
966.32|4.079|so this so if i just run this we're
968.88|3.36|going to print
970.399|5.041|d1
972.24|6.24|which we know is four
975.44|4.88|now d2 will be bumped a will be bumped
978.48|4.0|by h
980.32|5.84|so let's just think through
982.48|5.12|a little bit uh what d2 will be uh
986.16|3.119|printed out here
987.6|3.52|in particular
989.279|4.24|d1 will be four
991.12|4.56|will d2 be a number slightly greater
993.519|4.081|than four or slightly lower than four
995.68|4.48|and that's going to tell us the sl the
997.6|4.799|the sign of the derivative
1000.16|2.239|so
1002.56|6.0|we're bumping a by h
1005.44|4.48|b as minus three c is ten
1008.56|2.56|so you can just intuitively think
1009.92|4.88|through this derivative and what it's
1011.12|6.399|doing a will be slightly more positive
1014.8|5.599|and but b is a negative number
1017.519|5.68|so if a is slightly more positive
1020.399|5.68|because b is negative three
1023.199|4.961|we're actually going to be adding less
1026.079|4.561|to d
1028.16|5.6|so you'd actually expect that the value
1030.64|5.84|of the function will go down
1033.76|4.64|so let's just see this
1036.48|4.319|yeah and so we went from 4
1038.4|3.76|to 3.9996
1040.799|2.481|and that tells you that the slope will
1042.16|2.32|be negative
1043.28|3.12|and then
1044.48|3.439|uh will be a negative number
1046.4|2.639|because we went down
1047.919|3.12|and then
1049.039|4.721|the exact number of slope will be
1051.039|4.081|exact amount of slope is negative 3.
1053.76|3.2|and you can also convince yourself that
1055.12|3.919|negative 3 is the right answer
1056.96|4.64|mathematically and analytically because
1059.039|4.801|if you have a times b plus c and you are
1061.6|4.4|you know you have calculus then
1063.84|4.64|differentiating a times b plus c with
1066.0|4.799|respect to a gives you just b
1068.48|4.319|and indeed the value of b is negative 3
1070.799|4.161|which is the derivative that we have so
1072.799|4.961|you can tell that that's correct
1074.96|4.88|so now if we do this with b
1077.76|4.48|so if we bump b by a little bit in a
1079.84|4.719|positive direction we'd get different
1082.24|4.08|slopes so what is the influence of b on
1084.559|3.681|the output d
1086.32|3.84|so if we bump b by a tiny amount in a
1088.24|3.36|positive direction then because a is
1090.16|3.6|positive
1091.6|3.12|we'll be adding more to d
1093.76|3.279|right
1094.72|4.079|so um and now what is the what is the
1097.039|2.801|sensitivity what is the slope of that
1098.799|2.721|addition
1099.84|3.12|and it might not surprise you that this
1101.52|2.72|should be
1102.96|4.719|2
1104.24|5.92|and y is a 2 because d of d
1107.679|4.24|by db differentiating with respect to b
1110.16|3.92|would be would give us a
1111.919|3.521|and the value of a is two so that's also
1114.08|3.36|working well
1115.44|3.119|and then if c gets bumped a tiny amount
1117.44|2.479|in h
1118.559|3.281|by h
1119.919|4.321|then of course a times b is unaffected
1121.84|4.079|and now c becomes slightly bit higher
1124.24|3.04|what does that do to the function it
1125.919|2.88|makes it slightly bit higher because
1127.28|3.2|we're simply adding c
1128.799|4.321|and it makes it slightly bit higher by
1130.48|4.72|the exact same amount that we added to c
1133.12|3.439|and so that tells you that the slope is
1135.2|4.0|one
1136.559|4.48|that will be the
1139.2|4.96|the rate at which
1141.039|4.081|d will increase as we scale
1144.16|2.639|c
1145.12|3.12|okay so we now have some intuitive sense
1146.799|3.201|of what this derivative is telling you
1148.24|3.36|about the function and we'd like to move
1150.0|3.12|to neural networks now as i mentioned
1151.6|3.6|neural networks will be pretty massive
1153.12|3.36|expressions mathematical expressions so
1155.2|2.719|we need some data structures that
1156.48|2.88|maintain these expressions and that's
1157.919|2.561|what we're going to start to build out
1159.36|2.88|now
1160.48|3.6|so we're going to
1162.24|4.0|build out this value object that i
1164.08|3.44|showed you in the readme page of
1166.24|4.48|micrograd
1167.52|6.0|so let me copy paste a skeleton of the
1170.72|5.68|first very simple value object
1173.52|4.8|so class value takes a single
1176.4|2.88|scalar value that it wraps and keeps
1178.32|3.12|track of
1179.28|4.32|and that's it so
1181.44|4.0|we can for example do value of 2.0 and
1183.6|4.959|then we can
1185.44|4.96|get we can look at its content and
1188.559|3.921|python will internally
1190.4|3.92|use the wrapper function
1192.48|4.4|to uh return
1194.32|4.32|uh this string oops
1196.88|3.919|like that
1198.64|4.56|so this is a value object with data
1200.799|4.161|equals two that we're creating here
1203.2|4.24|now we'd like to do is like we'd like to
1204.96|5.12|be able to
1207.44|4.56|have not just like two values
1210.08|3.599|but we'd like to do a bluffy right we'd
1212.0|3.44|like to add them
1213.679|4.081|so currently you would get an error
1215.44|6.0|because python doesn't know how to add
1217.76|4.72|two value objects so we have to tell it
1221.44|3.44|so here's
1222.48|2.4|addition
1226.32|3.2|so you have to basically use these
1227.6|4.24|special double underscore methods in
1229.52|5.92|python to define these operators for
1231.84|7.28|these objects so if we call um
1235.44|7.599|the uh if we use this plus operator
1239.12|4.64|python will internally call a dot add of
1243.039|2.88|b
1243.76|5.2|that's what will happen internally and
1245.919|5.041|so b will be the other and
1248.96|3.199|self will be a
1250.96|3.52|and so we see that what we're going to
1252.159|4.561|return is a new value object and it's
1254.48|4.079|just it's going to be wrapping
1256.72|3.04|the plus of
1258.559|3.441|their data
1259.76|4.56|but remember now because data is the
1262.0|4.88|actual like numbered python number so
1264.32|4.8|this operator here is just the typical
1266.88|4.72|floating point plus addition now it's
1269.12|5.12|not an addition of value objects
1271.6|4.4|and will return a new value so now a
1274.24|2.96|plus b should work and it should print
1276.0|2.4|value of
1277.2|3.04|negative one
1278.4|3.279|because that's two plus minus three
1280.24|4.0|there we go
1281.679|4.24|okay let's now implement multiply
1284.24|2.559|just so we can recreate this expression
1285.919|2.64|here
1286.799|4.801|so multiply i think it won't surprise
1288.559|4.641|you will be fairly similar
1291.6|2.72|so instead of add we're going to be
1293.2|2.8|using mul
1294.32|2.56|and then here of course we want to do
1296.0|2.64|times
1296.88|4.159|and so now we can create a c value
1298.64|5.519|object which will be 10.0 and now we
1301.039|5.681|should be able to do a times b well
1304.159|2.901|let's just do a times b first
1306.72|1.76|um
1307.06|3.66|[Music]
1308.48|3.52|that's value of negative six now
1310.72|2.8|and by the way i skipped over this a
1312.0|3.52|little bit suppose that i didn't have
1313.52|3.92|the wrapper function here
1315.52|4.159|then it's just that you'll get some kind
1317.44|4.64|of an ugly expression so what wrapper is
1319.679|3.761|doing is it's providing us a way to
1322.08|3.04|print out like a nicer looking
1323.44|3.76|expression in python
1325.12|4.16|uh so we don't just have something
1327.2|3.28|cryptic we actually are you know it's
1329.28|4.72|value of
1330.48|5.84|negative six so this gives us a times
1334.0|4.08|and then this we should now be able to
1336.32|4.239|add c to it because we've defined and
1338.08|4.32|told the python how to do mul and add
1340.559|4.321|and so this will call this will
1342.4|4.48|basically be equivalent to a dot
1344.88|3.039|small
1346.88|2.799|of b
1347.919|3.361|and then this new value object will be
1349.679|2.88|dot add
1351.28|3.519|of c
1352.559|3.841|and so let's see if that worked
1354.799|4.401|yep so that worked well that gave us
1356.4|4.56|four which is what we expect from before
1359.2|5.12|and i believe we can just call them
1360.96|4.16|manually as well there we go so
1364.32|2.56|yeah
1365.12|3.919|okay so now what we are missing is the
1366.88|3.36|connective tissue of this expression as
1369.039|3.52|i mentioned we want to keep these
1370.24|4.72|expression graphs so we need to know and
1372.559|4.321|keep pointers about what values produce
1374.96|3.68|what other values
1376.88|3.2|so here for example we are going to
1378.64|3.44|introduce a new variable which we'll
1380.08|3.44|call children and by default it will be
1382.08|2.719|an empty tuple
1383.52|2.88|and then we're actually going to keep a
1384.799|3.76|slightly different variable in the class
1386.4|5.12|which we'll call underscore prev which
1388.559|4.721|will be the set of children
1391.52|3.6|this is how i done i did it in the
1393.28|3.84|original micrograd looking at my code
1395.12|4.0|here i can't remember exactly the reason
1397.12|3.84|i believe it was efficiency but this
1399.12|3.28|underscore children will be a tuple for
1400.96|2.959|convenience but then when we actually
1402.4|5.2|maintain it in the class it will be just
1403.919|4.961|this set yeah i believe for efficiency
1407.6|2.319|um
1408.88|2.88|so now
1409.919|3.521|when we are creating a value like this
1411.76|4.32|with a constructor children will be
1413.44|3.92|empty and prep will be the empty set but
1416.08|3.28|when we're creating a value through
1417.36|5.28|addition or multiplication we're going
1419.36|7.04|to feed in the children of this value
1422.64|5.44|which in this case is self and other
1426.4|4.24|so those are the children
1428.08|4.88|here
1430.64|5.279|so now we can do d dot prev
1432.96|5.92|and we'll see that the children of the
1435.919|5.041|we now know are this value of negative 6
1438.88|4.88|and value of 10 and this of course is
1440.96|5.599|the value resulting from a times b and
1443.76|4.799|the c value which is 10.
1446.559|4.081|now the last piece of information we
1448.559|3.6|don't know so we know that the children
1450.64|4.08|of every single value but we don't know
1452.159|4.4|what operation created this value
1454.72|4.4|so we need one more element here let's
1456.559|4.641|call it underscore pop
1459.12|3.2|and by default this is the empty set for
1461.2|4.4|leaves
1462.32|5.04|and then we'll just maintain it here
1465.6|3.92|and now the operation will be just a
1467.36|3.919|simple string and in the case of
1469.52|4.32|addition it's plus in the case of
1471.279|3.921|multiplication is times
1473.84|3.199|so now we
1475.2|3.44|not just have d dot pref we also have a
1477.039|3.201|d dot up
1478.64|4.159|and we know that d was produced by an
1480.24|3.76|addition of those two values and so now
1482.799|3.281|we have the full
1484.0|3.52|mathematical expression uh and we're
1486.08|3.839|building out this data structure and we
1487.52|4.08|know exactly how each value came to be
1489.919|4.081|by word expression and from what other
1491.6|2.4|values
1494.72|3.36|now because these expressions are about
1496.159|4.241|to get quite a bit larger we'd like a
1498.08|4.16|way to nicely visualize these
1500.4|3.44|expressions that we're building out so
1502.24|4.24|for that i'm going to copy paste a bunch
1503.84|4.8|of slightly scary code that's going to
1506.48|3.12|visualize this these expression graphs
1508.64|2.399|for us
1509.6|3.76|so here's the code and i'll explain it
1511.039|3.841|in a bit but first let me just show you
1513.36|3.36|what this code does
1514.88|4.24|basically what it does is it creates a
1516.72|4.0|new function drawdot that we can call on
1519.12|3.6|some root node
1520.72|4.0|and then it's going to visualize it so
1522.72|4.319|if we call drawdot on d
1524.72|5.04|which is this final value here that is a
1527.039|4.401|times b plus c
1529.76|2.48|it creates something like this so this
1531.44|3.2|is d
1532.24|4.72|and you see that this is a times b
1534.64|5.76|creating an integrated value plus c
1536.96|5.44|gives us this output node d
1540.4|3.92|so that's dried out of d
1542.4|3.759|and i'm not going to go through this in
1544.32|4.64|complete detail you can take a look at
1546.159|5.201|graphless and its api uh graphis is a
1548.96|3.52|open source graph visualization software
1551.36|3.48|and what we're doing here is we're
1552.48|4.48|building out this graph and graphis
1554.84|4.04|api and
1556.96|3.839|you can basically see that trace is this
1558.88|3.919|helper function that enumerates all of
1560.799|3.441|the nodes and edges in the graph
1562.799|3.281|so that just builds a set of all the
1564.24|3.76|nodes and edges and then we iterate for
1566.08|2.8|all the nodes and we create special node
1568.0|3.36|objects
1568.88|4.24|for them in
1571.36|4.319|using dot node
1573.12|3.679|and then we also create edges using dot
1575.679|2.401|dot edge
1576.799|3.601|and the only thing that's like slightly
1578.08|4.32|tricky here is you'll notice that i
1580.4|4.32|basically add these fake nodes which are
1582.4|5.279|these operation nodes so for example
1584.72|4.079|this node here is just like a plus node
1587.679|4.081|and
1588.799|5.601|i create these
1591.76|5.919|special op nodes here
1594.4|5.12|and i connect them accordingly so these
1597.679|4.0|nodes of course are not actual
1599.52|4.399|nodes in the original graph
1601.679|4.48|they're not actually a value object the
1603.919|4.24|only value objects here are the things
1606.159|4.4|in squares those are actual value
1608.159|4.241|objects or representations thereof and
1610.559|4.961|these op nodes are just created in this
1612.4|5.04|drawdot routine so that it looks nice
1615.52|4.399|let's also add labels to these graphs
1617.44|4.32|just so we know what variables are where
1619.919|2.961|so let's create a special underscore
1621.76|2.159|label
1622.88|2.56|um
1623.919|4.481|or let's just do label
1625.44|5.44|equals empty by default and save it in
1628.4|2.48|each node
1631.279|4.081|and then here we're going to do label as
1633.279|4.561|a
1635.36|6.039|label is the
1637.84|3.559|label a c
1642.799|4.88|and then
1644.799|5.921|let's create a special um
1647.679|3.041|e equals a times b
1650.799|4.88|and e dot label will be e
1654.08|4.079|it's kind of naughty
1655.679|5.12|and e will be e plus c
1658.159|4.4|and a d dot label will be
1660.799|3.441|d
1662.559|3.84|okay so nothing really changes i just
1664.24|4.24|added this new e function
1666.399|4.16|a new e variable
1668.48|3.36|and then here when we are
1670.559|3.681|printing this
1671.84|4.24|i'm going to print the label here so
1674.24|2.64|this will be a percent s
1676.08|4.24|bar
1676.88|3.44|and this will be end.label
1681.279|3.921|and so now
1683.44|4.239|we have the label on the left here so it
1685.2|3.52|says a b creating e and then e plus c
1687.679|3.12|creates d
1688.72|3.6|just like we have it here
1690.799|3.521|and finally let's make this expression
1692.32|4.88|just one layer deeper
1694.32|5.68|so d will not be the final output node
1697.2|4.56|instead after d we are going to create a
1700.0|3.679|new value object
1701.76|4.159|called f we're going to start running
1703.679|3.681|out of variables soon f will be negative
1705.919|4.64|2.0
1707.36|6.799|and its label will of course just be f
1710.559|4.881|and then l capital l will be the output
1714.159|3.841|of our graph
1715.44|3.359|and l will be p times f
1718.0|2.32|okay
1718.799|3.921|so l will be negative eight is the
1720.32|2.4|output
1722.84|6.68|so
1724.72|4.8|now we don't just draw a d we draw l
1730.0|4.0|okay
1732.0|4.399|and somehow the label of
1734.0|5.679|l was undefined oops all that label has
1736.399|5.28|to be explicitly sort of given to it
1739.679|3.521|there we go so l is the output
1741.679|2.401|so let's quickly recap what we've done
1743.2|2.479|so far
1744.08|3.92|we are able to build out mathematical
1745.679|3.521|expressions using only plus and times so
1748.0|3.52|far
1749.2|5.04|they are scalar valued along the way
1751.52|4.879|and we can do this forward pass
1754.24|4.4|and build out a mathematical expression
1756.399|3.121|so we have multiple inputs here a b c
1758.64|2.88|and f
1759.52|4.48|going into a mathematical expression
1761.52|4.879|that produces a single output l
1764.0|4.72|and this here is visualizing the forward
1766.399|5.201|pass so the output of the forward pass
1768.72|4.559|is negative eight that's the value
1771.6|3.76|now what we'd like to do next is we'd
1773.279|3.921|like to run back propagation
1775.36|4.24|and in back propagation we are going to
1777.2|3.68|start here at the end and we're going to
1779.6|3.92|reverse
1780.88|4.56|and calculate the gradient along along
1783.52|3.279|all these intermediate values
1785.44|3.44|and really what we're computing for
1786.799|4.161|every single value here
1788.88|6.48|um we're going to compute the derivative
1790.96|5.199|of that node with respect to l
1795.36|3.36|so
1796.159|4.321|the derivative of l with respect to l is
1798.72|3.04|just uh one
1800.48|3.36|and then we're going to derive what is
1801.76|4.56|the derivative of l with respect to f
1803.84|3.76|with respect to d with respect to c with
1806.32|4.0|respect to e
1807.6|4.48|with respect to b and with respect to a
1810.32|3.52|and in the neural network setting you'd
1812.08|4.64|be very interested in the derivative of
1813.84|4.559|basically this loss function l
1816.72|2.64|with respect to the weights of a neural
1818.399|2.321|network
1819.36|3.039|and here of course we have just these
1820.72|3.12|variables a b c and f
1822.399|3.361|but some of these will eventually
1823.84|3.439|represent the weights of a neural net
1825.76|3.36|and so we'll need to know how those
1827.279|3.76|weights are impacting
1829.12|3.12|the loss function so we'll be interested
1831.039|3.601|basically in the derivative of the
1832.24|4.319|output with respect to some of its leaf
1834.64|3.44|nodes and those leaf nodes will be the
1836.559|2.961|weights of the neural net
1838.08|3.599|and the other leaf nodes of course will
1839.52|4.48|be the data itself but usually we will
1841.679|4.081|not want or use the derivative of the
1844.0|3.76|loss function with respect to data
1845.76|4.88|because the data is fixed but the
1847.76|4.799|weights will be iterated on
1850.64|3.6|using the gradient information so next
1852.559|4.48|we are going to create a variable inside
1854.24|5.679|the value class that maintains the
1857.039|3.921|derivative of l with respect to that
1859.919|3.841|value
1860.96|4.88|and we will call this variable grad
1863.76|3.44|so there's a data and there's a
1865.84|3.76|self.grad
1867.2|5.04|and initially it will be zero and
1869.6|4.72|remember that zero is basically means no
1872.24|3.84|effect so at initialization we're
1874.32|4.239|assuming that every value does not
1876.08|3.52|impact does not affect the out the
1878.559|2.801|output
1879.6|3.6|right because if the gradient is zero
1881.36|4.319|that means that changing this variable
1883.2|4.079|is not changing the loss function
1885.679|3.201|so by default we assume that the
1887.279|3.921|gradient is zero
1888.88|7.279|and then
1891.2|4.959|now that we have grad and it's 0.0
1896.559|6.24|we are going to be able to visualize it
1898.24|7.439|here after data so here grad is 0.4 f
1902.799|4.801|and this will be in that graph
1905.679|5.281|and now we are going to be showing both
1907.6|6.079|the data and the grad
1910.96|4.719|initialized at zero
1913.679|3.681|and we are just about getting ready to
1915.679|3.12|calculate the back propagation
1917.36|3.039|and of course this grad again as i
1918.799|3.441|mentioned is representing
1920.399|4.64|the derivative of the output in this
1922.24|4.24|case l with respect to this value so
1925.039|3.52|with respect to so this is the
1926.48|4.88|derivative of l with respect to f with
1928.559|4.401|respect to d and so on so let's now fill
1931.36|3.36|in those gradients and actually do back
1932.96|3.439|propagation manually so let's start
1934.72|3.76|filling in these gradients and start all
1936.399|4.0|the way at the end as i mentioned here
1938.48|4.4|first we are interested to fill in this
1940.399|4.801|gradient here so what is the derivative
1942.88|4.48|of l with respect to l
1945.2|3.839|in other words if i change l by a tiny
1947.36|3.199|amount of h
1949.039|3.281|how much does
1950.559|4.641|l change
1952.32|4.959|it changes by h so it's proportional and
1955.2|4.0|therefore derivative will be one
1957.279|3.681|we can of course measure these or
1959.2|4.0|estimate these numerical gradients
1960.96|4.319|numerically just like we've seen before
1963.2|6.079|so if i take this expression
1965.279|5.921|and i create a def lol function here
1969.279|4.321|and put this here now the reason i'm
1971.2|4.0|creating a gating function hello here is
1973.6|3.6|because i don't want to pollute or mess
1975.2|3.68|up the global scope here this is just
1977.2|3.199|kind of like a little staging area and
1978.88|3.84|as you know in python all of these will
1980.399|4.321|be local variables to this function so
1982.72|3.04|i'm not changing any of the global scope
1984.72|5.28|here
1985.76|7.279|so here l1 will be l
1990.0|6.88|and then copy pasting this expression
1993.039|3.841|we're going to add a small amount h
1997.36|5.28|in for example a
2000.559|4.881|right and this would be measuring the
2002.64|5.519|derivative of l with respect to a
2005.44|4.079|so here this will be l2
2008.159|3.441|and then we want to print this
2009.519|5.681|derivative so print
2011.6|6.079|l2 minus l1 which is how much l changed
2015.2|4.319|and then normalize it by h so this is
2017.679|3.681|the rise over run
2019.519|5.601|and we have to be careful because l is a
2021.36|4.88|value node so we actually want its data
2025.12|3.76|um
2026.24|4.48|so that these are floats dividing by h
2028.88|4.159|and this should print the derivative of
2030.72|4.88|l with respect to a because a is the one
2033.039|4.24|that we bumped a little bit by h
2035.6|3.679|so what is the
2037.279|3.76|derivative of l with respect to a
2039.279|4.321|it's six
2041.039|5.921|okay and obviously
2043.6|6.239|if we change l by h
2046.96|5.439|then that would be
2049.839|4.8|here effectively
2052.399|3.68|this looks really awkward but changing l
2054.639|6.161|by h
2056.079|7.121|you see the derivative here is 1. um
2060.8|3.92|that's kind of like the base case of
2063.2|3.439|what we are doing here
2064.72|5.119|so basically we cannot come up here and
2066.639|5.28|we can manually set l.grad to one this
2069.839|5.76|is our manual back propagation
2071.919|5.76|l dot grad is one and let's redraw
2075.599|3.441|and we'll see that we filled in grad as
2077.679|2.641|1 for l
2079.04|3.119|we're now going to continue the back
2080.32|5.2|propagation so let's here look at the
2082.159|5.52|derivatives of l with respect to d and f
2085.52|3.92|let's do a d first
2087.679|4.16|so what we are interested in if i create
2089.44|4.8|a markdown on here is we'd like to know
2091.839|5.441|basically we have that l is d times f
2094.24|6.0|and we'd like to know what is uh d
2097.28|4.4|l by d d
2100.24|3.44|what is that
2101.68|4.56|and if you know your calculus uh l is d
2103.68|4.399|times f so what is d l by d d it would
2106.24|4.0|be f
2108.079|3.681|and if you don't believe me we can also
2110.24|4.56|just derive it because the proof would
2111.76|3.92|be fairly straightforward uh we go to
2114.8|3.36|the
2115.68|6.399|definition of the derivative which is f
2118.16|6.32|of x plus h minus f of x divide h
2122.079|4.401|as a limit limit of h goes to zero of
2124.48|3.76|this kind of expression so when we have
2126.48|5.119|l is d times f
2128.24|5.68|then increasing d by h
2131.599|4.161|would give us the output of b plus h
2133.92|5.04|times f
2135.76|6.56|that's basically f of x plus h right
2138.96|5.92|minus d times f
2142.32|4.24|and then divide h and symbolically
2144.88|5.12|expanding out here we would have
2146.56|5.68|basically d times f plus h times f minus
2150.0|4.4|t times f divide h
2152.24|5.119|and then you see how the df minus df
2154.4|4.16|cancels so you're left with h times f
2157.359|2.561|divide h
2158.56|4.64|which is f
2159.92|4.56|so in the limit as h goes to zero of
2163.2|3.52|you know
2164.48|5.44|derivative
2166.72|5.6|definition we just get f in the case of
2169.92|3.12|d times f
2172.32|2.0|so
2173.04|2.88|symmetrically
2174.32|4.16|dl by d
2175.92|5.439|f will just be d
2178.48|6.0|so what we have is that f dot grad
2181.359|6.48|we see now is just the value of d
2184.48|3.359|which is 4.
2188.8|2.88|and we see that
2190.16|5.439|d dot grad
2191.68|3.919|is just uh the value of f
2196.88|8.08|and so the value of f is negative two
2201.2|3.76|so we'll set those manually
2205.119|5.281|let me erase this markdown node and then
2207.04|3.36|let's redraw what we have
2210.88|2.32|okay
2211.839|4.561|and let's just make sure that these were
2213.2|6.32|correct so we seem to think that dl by
2216.4|5.92|dd is negative two so let's double check
2219.52|3.839|um let me erase this plus h from before
2222.32|2.799|and now we want the derivative with
2223.359|3.521|respect to f
2225.119|3.841|so let's just come here when i create f
2226.88|3.92|and let's do a plus h here and this
2228.96|5.2|should print the derivative of l with
2230.8|5.52|respect to f so we expect to see four
2234.16|2.959|yeah and this is four up to floating
2236.32|2.64|point
2237.119|4.24|funkiness
2238.96|6.08|and then dl by dd
2241.359|5.281|should be f which is negative two
2245.04|6.48|grad is negative two
2246.64|4.88|so if we again come here and we change d
2251.839|5.681|d dot data plus equals h right here
2255.119|4.96|so we expect so we've added a little h
2257.52|4.8|and then we see how l changed and we
2260.079|4.561|expect to print
2262.32|4.799|uh negative two
2264.64|2.479|there we go
2267.359|3.521|so we've numerically verified what we're
2269.52|3.92|doing here is what kind of like an
2270.88|3.52|inline gradient check gradient check is
2273.44|2.96|when we
2274.4|3.199|are deriving this like back propagation
2276.4|3.92|and getting the derivative with respect
2277.599|5.601|to all the intermediate results and then
2280.32|5.759|numerical gradient is just you know
2283.2|4.8|estimating it using small step size
2286.079|4.321|now we're getting to the crux of
2288.0|4.88|backpropagation so this will be the most
2290.4|3.92|important node to understand because if
2292.88|3.199|you understand the gradient for this
2294.32|3.12|node you understand all of back
2296.079|3.52|propagation and all of training of
2297.44|5.679|neural nets basically
2299.599|5.121|so we need to derive dl by bc
2303.119|3.441|in other words the derivative of l with
2304.72|3.2|respect to c
2306.56|2.88|because we've computed all these other
2307.92|2.72|gradients already
2309.44|4.159|now we're coming here and we're
2310.64|5.52|continuing the back propagation manually
2313.599|4.801|so we want dl by dc and then we'll also
2316.16|3.84|derive dl by de
2318.4|3.52|now here's the problem
2320.0|4.0|how do we derive dl
2321.92|4.24|by dc
2324.0|4.8|we actually know the derivative l with
2326.16|3.919|respect to d so we know how l assessed
2328.8|4.319|it to d
2330.079|5.601|but how is l sensitive to c so if we
2333.119|4.881|wiggle c how does that impact l
2335.68|6.159|through d
2338.0|3.839|so we know dl by dc
2341.92|4.4|and we also here know how c impacts d
2344.64|4.56|and so just very intuitively if you know
2346.32|5.039|the impact that c is having on d and the
2349.2|3.68|impact that d is having on l
2351.359|3.041|then you should be able to somehow put
2352.88|3.6|that information together to figure out
2354.4|4.08|how c impacts l
2356.48|4.4|and indeed this is what we can actually
2358.48|4.48|do so in particular we know just
2360.88|4.0|concentrating on d first let's look at
2362.96|4.08|how what is the derivative basically of
2364.88|5.52|d with respect to c so in other words
2367.04|3.36|what is dd by dc
2371.599|4.0|so here we know that d is c times c plus
2374.72|2.639|e
2375.599|4.0|that's what we know and now we're
2377.359|4.0|interested in dd by dc
2379.599|4.0|if you just know your calculus again and
2381.359|4.161|you remember that differentiating c plus
2383.599|2.881|e with respect to c you know that that
2385.52|2.319|gives you
2386.48|3.28|1.0
2387.839|3.921|and we can also go back to the basics
2389.76|4.88|and derive this because again we can go
2391.76|4.64|to our f of x plus h minus f of x
2394.64|3.84|divide by h
2396.4|3.6|that's the definition of a derivative as
2398.48|2.96|h goes to zero
2400.0|4.4|and so here
2401.44|4.879|focusing on c and its effect on d
2404.4|2.8|we can basically do the f of x plus h
2406.319|4.561|will be
2407.2|4.96|c is incremented by h plus e
2410.88|3.439|that's the first evaluation of our
2412.16|4.32|function minus
2414.319|4.0|c plus e
2416.48|3.359|and then divide h
2418.319|3.52|and so what is this
2419.839|5.601|uh just expanding this out this will be
2421.839|5.841|c plus h plus e minus c minus e
2425.44|4.879|divide h and then you see here how c
2427.68|5.919|minus c cancels e minus e cancels we're
2430.319|4.961|left with h over h which is 1.0
2433.599|5.281|and so
2435.28|4.48|by symmetry also d d by d
2438.88|4.08|e
2439.76|5.04|will be 1.0 as well
2442.96|3.68|so basically the derivative of a sum
2444.8|4.24|expression is very simple and and this
2446.64|4.4|is the local derivative so i call this
2449.04|3.44|the local derivative because we have the
2451.04|3.36|final output value all the way at the
2452.48|3.359|end of this graph and we're now like a
2454.4|3.6|small node here
2455.839|4.24|and this is a little plus node
2458.0|4.079|and it the little plus node doesn't know
2460.079|4.081|anything about the rest of the graph
2462.079|5.04|that it's embedded in all it knows is
2464.16|4.959|that it did a plus it took a c and an e
2467.119|4.081|added them and created d
2469.119|5.281|and this plus note also knows the local
2471.2|5.119|influence of c on d or rather rather the
2474.4|2.64|derivative of d with respect to c and it
2476.319|2.401|also
2477.04|4.24|knows the derivative of d with respect
2478.72|4.639|to e but that's not what we want that's
2481.28|6.4|just a local derivative what we actually
2483.359|7.361|want is d l by d c and l could l is here
2487.68|4.56|just one step away but in a general case
2490.72|3.92|this little plus note is could be
2492.24|3.52|embedded in like a massive graph
2494.64|3.76|so
2495.76|5.52|again we know how l impacts d and now we
2498.4|4.959|know how c and e impact d how do we put
2501.28|4.72|that information together to write dl by
2503.359|4.401|dc and the answer of course is the chain
2506.0|4.079|rule in calculus
2507.76|3.76|and so um
2510.079|2.881|i pulled up a chain rule here from
2511.52|2.4|kapedia
2512.96|1.92|and
2513.92|3.28|i'm going to go through this very
2514.88|3.68|briefly so chain rule
2517.2|3.119|wikipedia sometimes can be very
2518.56|4.0|confusing and calculus can
2520.319|3.28|can be very confusing like this is the
2522.56|2.48|way i
2523.599|2.801|learned
2525.04|3.52|chain rule and it was very confusing
2526.4|4.32|like what is happening it's just
2528.56|4.4|complicated so i like this expression
2530.72|4.399|much better
2532.96|5.119|if a variable z depends on a variable y
2535.119|5.2|which itself depends on the variable x
2538.079|4.321|then z depends on x as well obviously
2540.319|4.0|through the intermediate variable y
2542.4|2.8|in this case the chain rule is expressed
2544.319|3.76|as
2545.2|5.52|if you want dz by dx
2548.079|5.601|then you take the dz by dy and you
2550.72|4.24|multiply it by d y by dx
2553.68|2.48|so the chain rule fundamentally is
2554.96|2.32|telling you
2556.16|3.12|how
2557.28|4.24|we chain these
2559.28|5.039|uh derivatives together
2561.52|4.559|correctly so to differentiate through a
2564.319|4.401|function composition
2566.079|3.52|we have to apply a multiplication
2568.72|2.96|of
2569.599|3.921|those derivatives
2571.68|2.96|so that's really what chain rule is
2573.52|2.96|telling us
2574.64|3.439|and there's a nice little intuitive
2576.48|3.44|explanation here which i also think is
2578.079|3.201|kind of cute the chain rule says that
2579.92|3.84|knowing the instantaneous rate of change
2581.28|3.52|of z with respect to y and y relative to
2583.76|2.64|x allows one to calculate the
2584.8|3.039|instantaneous rate of change of z
2586.4|3.12|relative to x
2587.839|2.561|as a product of those two rates of
2589.52|3.04|change
2590.4|3.919|simply the product of those two
2592.56|3.44|so here's a good one
2594.319|3.841|if a car travels twice as fast as
2596.0|3.92|bicycle and the bicycle is four times as
2598.16|4.159|fast as walking man
2599.92|5.199|then the car travels two times four
2602.319|4.881|eight times as fast as demand
2605.119|4.081|and so this makes it very clear that the
2607.2|3.76|correct thing to do sort of
2609.2|2.72|is to multiply
2610.96|2.879|so
2611.92|4.64|cars twice as fast as bicycle and
2613.839|5.041|bicycle is four times as fast as man
2616.56|5.6|so the car will be eight times as fast
2618.88|5.52|as the man and so we can take these
2622.16|4.159|intermediate rates of change if you will
2624.4|4.16|and multiply them together
2626.319|4.401|and that justifies the
2628.56|4.08|chain rule intuitively so have a look at
2630.72|3.92|chain rule about here really what it
2632.64|4.0|means for us is there's a very simple
2634.64|4.959|recipe for deriving what we want which
2636.64|4.88|is dl by dc
2639.599|4.0|and what we have so far
2641.52|3.68|is we know
2643.599|3.841|want
2645.2|3.68|and we know
2647.44|5.2|what is the
2648.88|5.92|impact of d on l so we know d l by
2652.64|4.8|d d the derivative of l with respect to
2654.8|4.559|d d we know that that's negative two
2657.44|4.0|and now because of this local
2659.359|3.681|reasoning that we've done here we know
2661.44|3.12|dd by d
2663.04|4.48|c
2664.56|5.039|so how does c impact d and in
2667.52|4.48|particular this is a plus node so the
2669.599|3.681|local derivative is simply 1.0 it's very
2672.0|2.319|simple
2673.28|4.079|and so
2674.319|5.841|the chain rule tells us that dl by dc
2677.359|6.641|going through this intermediate variable
2680.16|4.64|will just be simply d l by
2684.0|3.2|d
2684.8|2.4|times
2689.2|4.08|dd by dc
2691.68|4.159|that's chain rule
2693.28|3.44|so this is identical to what's happening
2695.839|2.641|here
2696.72|3.2|except
2698.48|5.28|z is rl
2699.92|5.28|y is our d and x is rc
2703.76|2.88|so we literally just have to multiply
2705.2|4.24|these
2706.64|2.8|and because
2710.319|4.401|these local derivatives like dd by dc
2712.48|4.96|are just one
2714.72|4.72|we basically just copy over dl by dd
2717.44|4.72|because this is just times one
2719.44|6.48|so what does it do so because dl by dd
2722.16|6.88|is negative two what is dl by dc
2725.92|5.52|well it's the local gradient 1.0 times
2729.04|4.72|dl by dd which is negative two
2731.44|4.08|so literally what a plus node does you
2733.76|3.76|can look at it that way is it literally
2735.52|4.16|just routes the gradient
2737.52|4.4|because the plus nodes local derivatives
2739.68|3.84|are just one and so in the chain rule
2741.92|3.76|one times
2743.52|4.0|dl by dd
2745.68|4.72|is um
2747.52|5.76|is uh is just dl by dd and so that
2750.4|5.04|derivative just gets routed to both c
2753.28|6.079|and to e in this case
2755.44|5.6|so basically um we have that that grad
2759.359|3.121|or let's start with c since that's the
2761.04|2.88|one we looked at
2762.48|4.32|is
2763.92|4.56|negative two times one
2766.8|4.319|negative two
2768.48|4.56|and in the same way by symmetry e that
2771.119|5.841|grad will be negative two that's the
2773.04|6.319|claim so we can set those
2776.96|3.92|we can redraw
2779.359|3.841|and you see how we just assign negative
2780.88|4.16|to negative two so this backpropagating
2783.2|3.52|signal which is carrying the information
2785.04|3.84|of like what is the derivative of l with
2786.72|3.92|respect to all the intermediate nodes
2788.88|3.52|we can imagine it almost like flowing
2790.64|3.679|backwards through the graph and a plus
2792.4|4.0|node will simply distribute the
2794.319|4.8|derivative to all the leaf nodes sorry
2796.4|4.08|to all the children nodes of it
2799.119|4.24|so this is the claim and now let's
2800.48|4.639|verify it so let me remove the plus h
2803.359|2.96|here from before
2805.119|3.361|and now instead what we're going to do
2806.319|4.321|is we're going to increment c so c dot
2808.48|3.92|data will be credited by h
2810.64|3.679|and when i run this we expect to see
2812.4|6.48|negative 2
2814.319|6.8|negative 2. and then of course for e
2818.88|4.239|so e dot data plus equals h and we
2821.119|4.321|expect to see negative 2.
2823.119|2.321|simple
2827.28|4.079|so those are the derivatives of these
2829.44|4.32|internal nodes
2831.359|4.161|and now we're going to recurse our way
2833.76|3.44|backwards again
2835.52|3.68|and we're again going to apply the chain
2837.2|3.76|rule so here we go our second
2839.2|3.359|application of chain rule and we will
2840.96|3.04|apply it all the way through the graph
2842.559|2.8|we just happen to only have one more
2844.0|3.2|node remaining
2845.359|3.121|we have that d l
2847.2|3.04|by d e
2848.48|4.079|as we have just calculated is negative
2850.24|3.68|two so we know that
2852.559|3.921|so we know the derivative of l with
2853.92|2.56|respect to e
2856.72|3.839|and now we want dl
2859.44|2.32|by
2860.559|2.241|da
2861.76|2.559|right
2862.8|5.44|and the chain rule is telling us that
2864.319|3.921|that's just dl by de
2868.96|3.76|negative 2
2870.24|5.28|times the local gradient so what is the
2872.72|4.24|local gradient basically d e
2875.52|4.48|by d a
2876.96|5.359|we have to look at that
2880.0|4.319|so i'm a little times node
2882.319|4.561|inside a massive graph
2884.319|4.721|and i only know that i did a times b and
2886.88|5.76|i produced an e
2889.04|5.039|so now what is d e by d a and d e by d b
2892.64|4.479|that's the only thing that i sort of
2894.079|3.76|know about that's my local gradient
2897.119|3.44|so
2897.839|6.24|because we have that e's a times b we're
2900.559|6.081|asking what is d e by d a
2904.079|3.52|and of course we just did that here we
2906.64|3.439|had a
2907.599|4.401|times so i'm not going to rederive it
2910.079|4.48|but if you want to differentiate this
2912.0|4.64|with respect to a you'll just get b
2914.559|6.401|right the value of b
2916.64|4.32|which in this case is negative 3.0
2921.04|4.079|so
2921.92|5.28|basically we have that dl by da
2925.119|4.321|well let me just do it right here we
2927.2|3.6|have that a dot grad and we are applying
2929.44|4.8|chain rule here
2930.8|5.519|is d l by d e which we see here is
2934.24|3.28|negative two
2936.319|3.441|times
2937.52|7.12|what is d e by d a
2939.76|4.88|it's the value of b which is negative 3.
2944.88|2.4|that's it
2947.839|3.601|and then we have b grad is again dl by
2950.559|2.56|de
2951.44|2.96|which is negative 2
2953.119|2.401|just the same way
2954.4|3.6|times
2955.52|4.079|what is d e by d
2958.0|5.52|um db
2959.599|6.081|is the value of a which is 2.2.0
2963.52|5.28|as the value of a
2965.68|4.96|so these are our claimed derivatives
2968.8|3.279|let's
2970.64|3.12|redraw
2972.079|3.921|and we see here that
2973.76|4.64|a dot grad turns out to be 6 because
2976.0|5.119|that is negative 2 times negative 3
2978.4|5.28|and b dot grad is negative 4
2981.119|4.321|times sorry is negative 2 times 2 which
2983.68|3.76|is negative 4.
2985.44|5.04|so those are our claims let's delete
2987.44|5.119|this and let's verify them
2990.48|6.8|we have
2992.559|4.721|a here a dot data plus equals h
2997.52|4.24|so the claim is that
2999.599|3.841|a dot grad is six
3001.76|3.12|let's verify
3003.44|3.84|six
3004.88|3.92|and we have beta data
3007.28|3.839|plus equals h
3008.8|4.24|so nudging b by h
3011.119|4.0|and looking at what happens
3013.04|4.88|we claim it's negative four
3015.119|5.361|and indeed it's negative four plus minus
3017.92|3.919|again float oddness
3020.48|2.8|um
3021.839|2.72|and uh
3023.28|3.44|that's it this
3024.559|3.76|that was the manual
3026.72|3.839|back propagation
3028.319|4.961|uh all the way from here to all the leaf
3030.559|4.721|nodes and we've done it piece by piece
3033.28|4.0|and really all we've done is as you saw
3035.28|4.559|we iterated through all the nodes one by
3037.28|4.48|one and locally applied the chain rule
3039.839|4.401|we always know what is the derivative of
3041.76|3.839|l with respect to this little output and
3044.24|3.359|then we look at how this output was
3045.599|3.921|produced this output was produced
3047.599|3.921|through some operation and we have the
3049.52|3.12|pointers to the children nodes of this
3051.52|3.2|operation
3052.64|4.0|and so in this little operation we know
3054.72|3.839|what the local derivatives are and we
3056.64|2.959|just multiply them onto the derivative
3058.559|3.121|always
3059.599|4.561|so we just go through and recursively
3061.68|4.24|multiply on the local derivatives and
3064.16|4.0|that's what back propagation is is just
3065.92|4.639|a recursive application of chain rule
3068.16|4.56|backwards through the computation graph
3070.559|4.081|let's see this power in action just very
3072.72|2.96|briefly what we're going to do is we're
3074.64|5.04|going to
3075.68|5.919|nudge our inputs to try to make l go up
3079.68|4.48|so in particular what we're doing is we
3081.599|4.96|want a.data we're going to change it
3084.16|3.679|and if we want l to go up that means we
3086.559|3.28|just have to go in the direction of the
3087.839|3.121|gradient so
3089.839|2.401|a
3090.96|3.84|should increase in the direction of
3092.24|4.24|gradient by like some small step amount
3094.8|3.36|this is the step size
3096.48|4.32|and we don't just want this for ba but
3098.16|2.64|also for b
3101.44|4.639|also for c
3104.48|2.72|also for f
3106.079|3.601|those are
3107.2|3.44|leaf nodes which we usually have control
3109.68|2.879|over
3110.64|4.16|and if we nudge in direction of the
3112.559|3.121|gradient we expect a positive influence
3114.8|3.68|on l
3115.68|4.159|so we expect l to go up
3118.48|3.28|positively
3119.839|3.841|so it should become less negative it
3121.76|4.16|should go up to say negative you know
3123.68|4.399|six or something like that
3125.92|3.679|uh it's hard to tell exactly and we'd
3128.079|4.24|have to rewrite the forward pass so let
3129.599|4.321|me just um
3132.319|3.841|do that here
3133.92|2.24|um
3136.559|4.241|this would be the forward pass f would
3138.64|6.08|be unchanged this is effectively the
3140.8|6.4|forward pass and now if we print l.data
3144.72|4.08|we expect because we nudged all the
3147.2|3.76|values all the inputs in the rational
3148.8|4.08|gradient we expected a less negative l
3150.96|3.92|we expect it to go up
3152.88|3.76|so maybe it's negative six or so let's
3154.88|3.439|see what happens
3156.64|5.199|okay negative seven
3158.319|5.52|and uh this is basically one step of an
3161.839|4.321|optimization that we'll end up running
3163.839|3.841|and really does gradient just give us
3166.16|3.36|some power because we know how to
3167.68|3.12|influence the final outcome and this
3169.52|3.36|will be extremely useful for training
3170.8|4.64|knowledge as well as you'll see
3172.88|5.199|so now i would like to do one more uh
3175.44|6.879|example of manual backpropagation using
3178.079|6.0|a bit more complex and uh useful example
3182.319|3.04|we are going to back propagate through a
3184.079|3.361|neuron
3185.359|3.521|so
3187.44|3.44|we want to eventually build up neural
3188.88|3.679|networks and in the simplest case these
3190.88|4.719|are multilateral perceptrons as they're
3192.559|4.481|called so this is a two layer neural net
3195.599|3.041|and it's got these hidden layers made up
3197.04|2.96|of neurons and these neurons are fully
3198.64|2.959|connected to each other
3200.0|3.599|now biologically neurons are very
3201.599|4.48|complicated devices but we have very
3203.599|3.921|simple mathematical models of them
3206.079|3.601|and so this is a very simple
3207.52|4.24|mathematical model of a neuron you have
3209.68|4.0|some inputs axis
3211.76|4.88|and then you have these synapses that
3213.68|5.919|have weights on them so
3216.64|4.16|the w's are weights
3219.599|3.041|and then
3220.8|4.08|the synapse interacts with the input to
3222.64|4.56|this neuron multiplicatively so what
3224.88|5.04|flows to the cell body
3227.2|4.159|of this neuron is w times x
3229.92|4.0|but there's multiple inputs so there's
3231.359|3.601|many w times x's flowing into the cell
3233.92|3.04|body
3234.96|2.96|the cell body then has also like some
3236.96|2.72|bias
3237.92|4.48|so this is kind of like the
3239.68|4.96|inert innate sort of trigger happiness
3242.4|3.679|of this neuron so this bias can make it
3244.64|3.76|a bit more trigger happy or a bit less
3246.079|4.161|trigger happy regardless of the input
3248.4|2.959|but basically we're taking all the w
3250.24|3.599|times x
3251.359|4.24|of all the inputs adding the bias and
3253.839|3.121|then we take it through an activation
3255.599|2.801|function
3256.96|3.359|and this activation function is usually
3258.4|4.08|some kind of a squashing function
3260.319|4.401|like a sigmoid or 10h or something like
3262.48|3.839|that so as an example
3264.72|3.44|we're going to use the 10h in this
3266.319|3.361|example
3268.16|3.12|numpy has a
3269.68|2.8|np.10h
3271.28|3.68|so
3272.48|4.079|we can call it on a range
3274.96|3.52|and we can plot it
3276.559|4.56|this is the 10h function and you see
3278.48|5.839|that the inputs as they come in
3281.119|4.161|get squashed on the y coordinate here so
3284.319|3.04|um
3285.28|4.319|right at zero we're going to get exactly
3287.359|3.44|zero and then as you go more positive in
3289.599|2.801|the input
3290.799|4.961|then you'll see that the function will
3292.4|5.439|only go up to one and then plateau out
3295.76|4.4|and so if you pass in very positive
3297.839|4.321|inputs we're gonna cap it smoothly at
3300.16|4.32|one and on the negative side we're gonna
3302.16|4.24|cap it smoothly to negative one
3304.48|4.079|so that's 10h
3306.4|4.32|and that's the squashing function or an
3308.559|4.081|activation function and what comes out
3310.72|4.24|of this neuron is just the activation
3312.64|4.08|function applied to the dot product of
3314.96|3.119|the weights and the
3316.72|2.639|inputs
3318.079|2.961|so let's
3319.359|3.2|write one out
3321.04|5.44|um
3322.559|3.921|i'm going to copy paste because
3327.359|4.161|i don't want to type too much
3328.96|4.399|but okay so here we have the inputs
3331.52|3.279|x1 x2 so this is a two-dimensional
3333.359|2.561|neuron so two inputs are going to come
3334.799|2.641|in
3335.92|2.879|these are thought out as the weights of
3337.44|4.159|this neuron
3338.799|5.121|weights w1 w2 and these weights again
3341.599|3.52|are the synaptic strengths for each
3343.92|3.52|input
3345.119|4.0|and this is the bias of the neuron
3347.44|3.84|b
3349.119|5.041|and now we want to do is according to
3351.28|4.24|this model we need to multiply x1 times
3354.16|3.6|w1
3355.52|4.88|and x2 times w2
3357.76|3.68|and then we need to add bias on top of
3360.4|2.88|it
3361.44|5.52|and it gets a little messy here but all
3363.28|4.64|we are trying to do is x1 w1 plus x2 w2
3366.96|2.879|plus b
3367.92|4.24|and these are multiply here
3369.839|3.841|except i'm doing it in small steps so
3372.16|3.6|that we actually have pointers to all
3373.68|5.76|these intermediate nodes so we have x1
3375.76|5.92|w1 variable x times x2 w2 variable and
3379.44|4.32|i'm also labeling them
3381.68|3.76|so n is now
3383.76|2.88|the cell body raw
3385.44|2.96|raw
3386.64|3.84|activation without
3388.4|4.48|the activation function for now
3390.48|6.079|and this should be enough to basically
3392.88|3.679|plot it so draw dot of n
3397.839|5.361|gives us x1 times w1 x2 times w2
3401.92|3.679|being added
3403.2|4.08|then the bias gets added on top of this
3405.599|3.76|and this n
3407.28|3.6|is this sum
3409.359|3.2|so we're now going to take it through an
3410.88|3.84|activation function
3412.559|3.921|and let's say we use the 10h
3414.72|3.28|so that we produce the output
3416.48|4.96|so what we'd like to do here is we'd
3418.0|5.119|like to do the output and i'll call it o
3421.44|3.76|is um
3423.119|5.2|n dot 10h
3425.2|4.639|okay but we haven't yet written the 10h
3428.319|4.561|now the reason that we need to implement
3429.839|4.801|another 10h function here is that
3432.88|3.84|tanh is a
3434.64|3.84|hyperbolic function and we've only so
3436.72|4.079|far implemented a plus and the times and
3438.48|3.52|you can't make a 10h out of just pluses
3440.799|4.32|and times
3442.0|5.2|you also need exponentiation so 10h is
3445.119|3.601|this kind of a formula here
3447.2|3.2|you can use either one of these and you
3448.72|3.92|see that there's exponentiation involved
3450.4|4.32|which we have not implemented yet for
3452.64|3.52|our low value node here so we're not
3454.72|2.8|going to be able to produce 10h yet and
3456.16|2.88|we have to go back up and implement
3457.52|5.12|something like it
3459.04|5.84|now one option here
3462.64|3.919|is we could actually implement um
3464.88|4.88|exponentiation
3466.559|5.841|right and we could return the x of a
3469.76|4.559|value instead of a 10h of a value
3472.4|4.56|because if we had x then we have
3474.319|4.641|everything else that we need so um
3476.96|3.04|because we know how to add and we know
3478.96|2.32|how to
3480.0|2.64|um
3481.28|3.68|we know how to add and we know how to
3482.64|4.24|multiply so we'd be able to create 10h
3484.96|3.359|if we knew how to x
3486.88|3.12|but for the purposes of this example i
3488.319|2.721|specifically wanted to
3490.0|3.04|show you
3491.04|4.16|that we don't necessarily need to have
3493.04|2.96|the most atomic pieces
3495.2|1.68|in
3496.0|3.28|um
3496.88|6.239|in this value object we can actually
3499.28|5.44|like create functions at arbitrary
3503.119|3.281|points of abstraction they can be
3504.72|3.2|complicated functions but they can be
3506.4|3.919|also very very simple functions like a
3507.92|4.0|plus and it's totally up to us the only
3510.319|3.121|thing that matters is that we know how
3511.92|3.84|to differentiate through any one
3513.44|3.76|function so we take some inputs and we
3515.76|3.12|make an output the only thing that
3517.2|4.159|matters it can be arbitrarily complex
3518.88|4.4|function as long as you know how to
3521.359|3.521|create the local derivative if you know
3523.28|3.279|the local derivative of how the inputs
3524.88|4.64|impact the output then that's all you
3526.559|4.881|need so we're going to cluster up
3529.52|3.12|all of this expression and we're not
3531.44|2.72|going to break it down to its atomic
3532.64|2.88|pieces we're just going to directly
3534.16|3.12|implement tanh
3535.52|3.68|so let's do that
3537.28|5.12|depth nh
3539.2|4.399|and then out will be a value
3542.4|3.52|of
3543.599|4.641|and we need this expression here so
3545.92|2.32|um
3548.48|4.639|let me actually
3550.319|2.8|copy paste
3554.16|4.56|let's grab n which is a cell.theta
3557.2|4.24|and then this
3558.72|5.839|i believe is the tan h
3561.44|4.48|math.x of
3564.559|2.641|two
3565.92|2.96|no n
3567.2|3.359|n minus one over
3568.88|4.16|two n plus one
3570.559|5.121|maybe i can call this x
3573.04|4.48|just so that it matches exactly
3575.68|4.639|okay and now
3577.52|5.039|this will be t
3580.319|3.681|and uh children of this node there's
3582.559|3.441|just one child
3584.0|4.559|and i'm wrapping it in a tuple so this
3586.0|4.799|is a tuple of one object just self
3588.559|3.681|and here the name of this operation will
3590.799|4.721|be 10h
3592.24|3.28|and we're going to return that
3596.319|5.681|okay
3598.559|4.721|so now valley should be implementing 10h
3602.0|2.559|and now we can scroll all the way down
3603.28|3.6|here
3604.559|4.641|and we can actually do n.10 h and that's
3606.88|4.4|going to return the tanhd
3609.2|3.44|output of n
3611.28|3.44|and now we should be able to draw it out
3612.64|5.199|of o not of n
3614.72|3.119|so let's see how that worked
3618.64|3.12|there we go
3619.68|4.56|n went through 10 h
3621.76|4.4|to produce this output
3624.24|3.52|so now tan h is a
3626.16|3.84|sort of
3627.76|5.359|our little micro grad supported node
3630.0|5.2|here as an operation
3633.119|3.041|and as long as we know the derivative of
3635.2|2.32|10h
3636.16|3.36|then we'll be able to back propagate
3637.52|4.079|through it now let's see this 10h in
3639.52|4.4|action currently it's not squashing too
3641.599|5.361|much because the input to it is pretty
3643.92|5.199|low so if the bias was increased to say
3646.96|4.24|eight
3649.119|3.921|then we'll see that what's flowing into
3651.2|3.119|the 10h now is
3653.04|4.24|two
3654.319|5.601|and 10h is squashing it to 0.96 so we're
3657.28|4.319|already hitting the tail of this 10h and
3659.92|3.439|it will sort of smoothly go up to 1 and
3661.599|3.041|then plateau out over there
3663.359|3.2|okay so now i'm going to do something
3664.64|5.12|slightly strange i'm going to change
3666.559|5.28|this bias from 8 to this number
3669.76|3.599|6.88 etc
3671.839|3.681|and i'm going to do this for specific
3673.359|3.601|reasons because we're about to start
3675.52|3.52|back propagation
3676.96|4.08|and i want to make sure that our numbers
3679.04|3.519|come out nice they're not like very
3681.04|3.68|crazy numbers they're nice numbers that
3682.559|4.401|we can sort of understand in our head
3684.72|5.28|let me also add a pose label
3686.96|4.56|o is short for output here
3690.0|2.64|so that's zero
3691.52|4.559|okay so
3692.64|4.479|0.88 flows into 10 h comes out 0.7 so on
3696.079|2.641|so now we're going to do back
3697.119|3.121|propagation and we're going to fill in
3698.72|4.48|all the gradients
3700.24|3.76|so what is the derivative o with respect
3703.2|1.84|to
3704.0|3.119|all the
3705.04|3.519|inputs here and of course in the typical
3707.119|4.24|neural network setting what we really
3708.559|4.721|care about the most is the derivative of
3711.359|4.96|these neurons on the weights
3713.28|4.079|specifically the w2 and w1 because those
3716.319|3.361|are the weights that we're going to be
3717.359|3.281|changing part of the optimization
3719.68|2.56|and the other thing that we have to
3720.64|3.12|remember is here we have only a single
3722.24|2.72|neuron but in the neural natives
3723.76|3.359|typically have many neurons and they're
3724.96|4.159|connected
3727.119|3.521|so this is only like a one small neuron
3729.119|3.361|a piece of a much bigger puzzle and
3730.64|3.199|eventually there's a loss function that
3732.48|2.8|sort of measures the accuracy of the
3733.839|3.041|neural net and we're back propagating
3735.28|3.92|with respect to that accuracy and trying
3736.88|4.239|to increase it
3739.2|3.28|so let's start off by propagation here
3741.119|3.2|in the end
3742.48|4.48|what is the derivative of o with respect
3744.319|6.161|to o the base case sort of we know
3746.96|5.44|always is that the gradient is just 1.0
3750.48|4.639|so let me fill it in
3752.4|4.719|and then let me
3755.119|4.96|split out
3757.119|5.2|the drawing function
3760.079|2.24|here
3763.68|3.28|and then here cell
3767.28|5.2|clear this output here okay
3770.079|3.841|so now when we draw o we'll see that oh
3772.48|2.639|that grad is one
3773.92|2.72|so now we're going to back propagate
3775.119|3.521|through the tan h
3776.64|4.56|so to back propagate through 10h we need
3778.64|5.04|to know the local derivative of 10h
3781.2|5.839|so if we have that
3783.68|4.72|o is 10 h of
3787.039|4.961|n
3788.4|5.199|then what is d o by d n
3792.0|3.28|now what you could do is you could come
3793.599|2.801|here and you could take this expression
3795.28|3.839|and you could
3796.4|4.959|do your calculus derivative taking
3799.119|4.641|um and that would work but we can also
3801.359|5.44|just scroll down wikipedia here
3803.76|5.2|into a section that hopefully tells us
3806.799|4.881|that derivative uh
3808.96|4.8|d by dx of 10 h of x is
3811.68|3.52|any of these i like this one 1 minus 10
3813.76|3.68|h square of x
3815.2|4.159|so this is 1 minus 10 h
3817.44|4.32|of x squared
3819.359|4.321|so basically what this is saying is that
3821.76|2.799|d o by d n
3823.68|3.76|is
3824.559|4.321|1 minus 10 h
3827.44|3.599|of n
3828.88|4.0|squared
3831.039|3.441|and we already have 10 h of n that's
3832.88|3.6|just o
3834.48|5.359|so it's one minus o squared
3836.48|5.68|so o is the output here so the output is
3839.839|4.401|this number
3842.16|4.32|data
3844.24|3.839|is this number
3846.48|3.92|and then
3848.079|3.601|what this is saying is that do by dn is
3850.4|2.88|1 minus
3851.68|4.8|this squared so
3853.28|5.68|one minus of that data squared
3856.48|5.119|is 0.5 conveniently
3858.96|5.28|so the local derivative of this 10 h
3861.599|3.601|operation here is 0.5
3864.24|3.2|and
3865.2|3.359|so that would be d o by d n
3867.44|5.2|so
3868.559|4.081|we can fill in that in that grad
3873.28|4.68|is 0.5 we'll just fill in
3882.48|4.639|so this is exactly 0.5 one half
3885.2|4.08|so now we're going to continue the back
3887.119|5.041|propagation
3889.28|6.0|this is 0.5 and this is a plus node
3892.16|4.48|so how is backprop going to what is that
3895.28|3.12|going to do here
3896.64|5.04|and if you remember our previous example
3898.4|5.199|a plus is just a distributor of gradient
3901.68|4.08|so this gradient will simply flow to
3903.599|3.841|both of these equally and that's because
3905.76|4.96|the local derivative of this operation
3907.44|5.44|is one for every one of its nodes so 1
3910.72|4.24|times 0.5 is 0.5
3912.88|5.76|so therefore we know that
3914.96|6.079|this node here which we called this
3918.64|6.159|its grad is just 0.5
3921.039|7.361|and we know that b dot grad is also 0.5
3924.799|3.601|so let's set those and let's draw
3928.88|3.76|so 0.5
3930.48|4.48|continuing we have another plus
3932.64|4.64|0.5 again we'll just distribute it so
3934.96|4.24|0.5 will flow to both of these
3937.28|4.24|so we can set
3939.2|2.32|theirs
3943.799|6.441|x2w2 as well that grad is 0.5
3947.92|4.0|and let's redraw pluses are my favorite
3950.24|2.96|uh operations to back propagate through
3951.92|3.119|because
3953.2|3.119|it's very simple
3955.039|3.441|so now it's flowing into these
3956.319|3.28|expressions is 0.5 and so really again
3958.48|3.2|keep in mind what the derivative is
3959.599|4.881|telling us at every point in time along
3961.68|4.399|here this is saying that
3964.48|3.599|if we want the output of this neuron to
3966.079|2.801|increase
3968.079|2.801|then
3968.88|4.479|the influence on these expressions is
3970.88|4.88|positive on the output both of them are
3973.359|2.401|positive
3976.96|3.119|contribution to the output
3980.48|3.68|so now back propagating to x2 and w2
3983.2|3.119|first
3984.16|3.919|this is a times node so we know that the
3986.319|2.641|local derivative is you know the other
3988.079|4.72|term
3988.96|4.639|so if we want to calculate x2.grad
3992.799|2.161|then
3993.599|3.601|can you think through what it's going to
3994.96|2.24|be
4000.88|3.959|so x2.grad will be
4002.799|5.441|w2.data
4004.839|6.28|times this x2w2
4008.24|3.879|by grad right
4011.119|4.561|and
4012.119|8.48|w2.grad will be
4015.68|4.919|x2 that data times x2w2.grad
4021.359|4.881|right so that's the local piece of chain
4023.92|2.32|rule
4027.039|4.241|let's set them and let's redraw
4029.76|5.92|so here we see that the gradient on our
4031.28|7.36|weight 2 is 0 because x2 data was 0
4035.68|4.879|right but x2 will have the gradient 0.5
4038.64|3.919|because data here was 1.
4040.559|5.28|and so what's interesting here right is
4042.559|5.921|because the input x2 was 0 then because
4045.839|4.48|of the way the times works
4048.48|4.72|of course this gradient will be zero and
4050.319|4.961|think about intuitively why that is
4053.2|2.879|derivative always tells us the influence
4055.28|4.48|of
4056.079|5.441|this on the final output if i wiggle w2
4059.76|2.96|how is the output changing
4061.52|2.799|it's not changing because we're
4062.72|3.28|multiplying by zero
4064.319|3.28|so because it's not changing there's no
4066.0|2.799|derivative and zero is the correct
4067.599|2.161|answer
4068.799|3.361|because we're
4069.76|4.799|squashing it at zero
4072.16|5.52|and let's do it here point five should
4074.559|7.361|come here and flow through this times
4077.68|6.0|and so we'll have that x1.grad is
4081.92|2.639|can you think through a little bit what
4083.68|3.359|what
4084.559|2.48|this should be
4087.28|5.279|the local derivative of times
4089.44|5.919|with respect to x1 is going to be w1
4092.559|6.24|so w1 is data times
4095.359|8.241|x1 w1 dot grad
4098.799|8.4|and w1.grad will be x1.data times
4103.6|5.679|x1 w2 w1 with graph
4107.199|4.48|let's see what those came out to be
4109.279|5.361|so this is 0.5 so this would be negative
4111.679|4.801|1.5 and this would be 1.
4114.64|3.519|and we've back propagated through this
4116.48|4.4|expression these are the actual final
4118.159|5.68|derivatives so if we want this neuron's
4120.88|6.24|output to increase
4123.839|5.761|we know that what's necessary is that
4127.12|4.32|w2 we have no gradient w2 doesn't
4129.6|4.719|actually matter to this neuron right now
4131.44|3.68|but this neuron this weight should uh go
4134.319|2.96|up
4135.12|4.559|so if this weight goes up then this
4137.279|3.92|neuron's output would have gone up and
4139.679|3.761|proportionally because the gradient is
4141.199|4.16|one okay so doing the back propagation
4143.44|3.44|manually is obviously ridiculous so we
4145.359|3.521|are now going to put an end to this
4146.88|4.16|suffering and we're going to see how we
4148.88|3.839|can implement uh the backward pass a bit
4151.04|3.84|more automatically we're not going to be
4152.719|4.321|doing all of it manually out here
4154.88|3.68|it's now pretty obvious to us by example
4157.04|3.92|how these pluses and times are back
4158.56|3.599|property ingredients so let's go up to
4160.96|3.52|the value
4162.159|4.961|object and we're going to start
4164.48|5.04|codifying what we've seen
4167.12|4.159|in the examples below
4169.52|5.279|so we're going to do this by storing a
4171.279|5.841|special cell dot backward
4174.799|4.721|and underscore backward and this will be
4177.12|4.32|a function which is going to do that
4179.52|3.679|little piece of chain rule at each
4181.44|4.0|little node that compute that took
4183.199|3.52|inputs and produced output uh we're
4185.44|3.6|going to store
4186.719|4.321|how we are going to chain the the
4189.04|3.199|outputs gradient into the inputs
4191.04|2.96|gradients
4192.239|3.361|so by default
4194.0|4.159|this will be a function
4195.6|4.32|that uh doesn't do anything
4198.159|3.04|so um
4199.92|3.279|and you can also see that here in the
4201.199|2.801|value in micrograb
4203.199|3.361|so
4204.0|4.4|with this backward function by default
4206.56|3.599|doesn't do anything
4208.4|2.96|this is an empty function
4210.159|3.04|and that would be sort of the case for
4211.36|4.4|example for a leaf node for leaf node
4213.199|5.121|there's nothing to do
4215.76|5.919|but now if when we're creating these out
4218.32|5.839|values these out values are an addition
4221.679|5.441|of self and other
4224.159|5.201|and so we will want to sell set
4227.12|4.16|outs backward to be
4229.36|4.319|the function that propagates the
4231.28|2.399|gradient
4234.159|5.04|so
4235.36|3.839|let's define what should happen
4240.48|3.6|and we're going to store it in a closure
4242.159|2.881|let's define what should happen when we
4244.08|3.599|call
4245.04|2.639|outs grad
4247.76|4.24|for in addition
4250.0|5.04|our job is to take
4252.0|5.679|outs grad and propagate it into self's
4255.04|5.52|grad and other grad so basically we want
4257.679|5.281|to sell self.grad to something
4260.56|3.84|and we want to set others.grad to
4262.96|2.8|something
4264.4|3.92|okay
4265.76|4.24|and the way we saw below how chain rule
4268.32|3.359|works we want to take the local
4270.0|2.719|derivative times
4271.679|2.721|the
4272.719|3.44|sort of global derivative i should call
4274.4|4.4|it which is the derivative of the final
4276.159|4.881|output of the expression with respect to
4278.8|4.16|out's data
4281.04|3.679|with respect to out
4282.96|4.32|so
4284.719|4.881|the local derivative of self in an
4287.28|4.48|addition is 1.0
4289.6|4.8|so it's just 1.0 times
4291.76|4.16|outs grad
4294.4|3.68|that's the chain rule
4295.92|3.279|and others.grad will be 1.0 times
4298.08|2.4|outgrad
4299.199|3.52|and what you basically what you're
4300.48|5.04|seeing here is that outscrad
4302.719|5.44|will simply be copied onto selfs grad
4305.52|4.4|and others grad as we saw happens for an
4308.159|3.361|addition operation
4309.92|3.52|so we're going to later call this
4311.52|4.24|function to propagate the gradient
4313.44|4.32|having done an addition
4315.76|5.6|let's now do multiplication we're going
4317.76|3.6|to also define that backward
4322.32|4.96|and we're going to set its backward to
4324.64|2.64|be backward
4327.679|6.161|and we want to chain outgrad into
4331.12|2.72|self.grad
4334.32|4.16|and others.grad
4337.12|3.2|and this will be a little piece of chain
4338.48|3.199|rule for multiplication
4340.32|2.96|so we'll have
4341.679|4.321|so what should this be
4343.28|2.72|can you think through
4348.64|3.68|so what is the local derivative
4350.8|4.399|here the local derivative was
4352.32|2.879|others.data
4355.44|4.16|and then
4356.56|6.0|oops others.data and the times of that
4359.6|5.2|grad that's channel
4362.56|3.04|and here we have self.data times of that
4364.8|3.6|grad
4365.6|2.8|that's what we've been doing
4369.6|4.8|and finally here for 10 h
4371.679|2.721|left backward
4374.8|5.439|and then we want to set out backwards to
4377.36|2.879|be just backward
4380.48|4.48|and here we need to
4382.56|6.88|back propagate we have out that grad and
4384.96|4.48|we want to chain it into self.grad
4389.679|4.081|and salt.grad will be
4391.76|4.399|the local derivative of this operation
4393.76|3.76|that we've done here which is 10h
4396.159|4.401|and so we saw that the local the
4397.52|6.08|gradient is 1 minus the tan h of x
4400.56|4.88|squared which here is t
4403.6|4.079|that's the local derivative because
4405.44|4.56|that's t is the output of this 10 h so 1
4407.679|4.801|minus t squared is the local derivative
4410.0|3.84|and then gradient um
4412.48|2.4|has to be multiplied because of the
4413.84|2.8|chain rule
4414.88|4.48|so outgrad is chained through the local
4416.64|5.2|gradient into salt.grad
4419.36|5.52|and that should be basically it so we're
4421.84|4.399|going to redefine our value node
4424.88|3.2|we're going to swing all the way down
4426.239|3.681|here
4428.08|3.119|and we're going to
4429.92|2.64|redefine
4431.199|4.081|our expression
4432.56|3.679|make sure that all the grads are zero
4435.28|2.32|okay
4436.239|3.521|but now we don't have to do this
4437.6|3.68|manually anymore
4439.76|4.24|we are going to basically be calling the
4441.28|3.76|dot backward in the right order
4444.0|3.84|so
4445.04|6.6|first we want to call os
4447.84|3.8|dot backwards
4454.0|6.48|so o was the outcome of 10h
4457.92|4.239|right so calling all that those who's
4460.48|2.64|backward
4462.159|3.841|will be
4463.12|6.0|this function this is what it will do
4466.0|5.76|now we have to be careful because
4469.12|5.119|there's a times out.grad
4471.76|4.88|and out.grad remember is initialized to
4474.239|2.401|zero
4478.88|7.76|so here we see grad zero so as a base
4481.36|8.72|case we need to set both.grad to 1.0
4486.64|3.44|to initialize this with 1
4493.52|3.679|and then once this is 1 we can call oda
4496.08|2.88|backward
4497.199|4.96|and what that should do is it should
4498.96|5.279|propagate this grad through 10h
4502.159|3.761|so the local derivative times
4504.239|4.0|the global derivative which is
4505.92|5.2|initialized at one so
4508.239|5.121|this should
4511.12|2.24|um
4515.679|3.441|a dope
4517.04|3.52|so i thought about redoing it but i
4519.12|3.36|figured i should just leave the error in
4520.56|3.84|here because it's pretty funny why is
4522.48|4.56|anti-object not callable
4524.4|4.88|uh it's because
4527.04|4.88|i screwed up we're trying to save these
4529.28|4.0|functions so this is correct
4531.92|2.72|this here
4533.28|2.8|we don't want to call the function
4534.64|3.44|because that returns none these
4536.08|3.52|functions return none we just want to
4538.08|4.079|store the function
4539.6|4.16|so let me redefine the value object
4542.159|4.481|and then we're going to come back in
4543.76|6.32|redefine the expression draw a dot
4546.64|6.48|everything is great o dot grad is one
4550.08|5.599|o dot grad is one and now
4553.12|5.44|now this should work of course
4555.679|4.881|okay so all that backward should
4558.56|4.639|this grant should now be 0.5 if we
4560.56|4.72|redraw and if everything went correctly
4563.199|6.561|0.5 yay
4565.28|4.48|okay so now we need to call ns.grad
4570.159|4.401|and it's not awkward sorry
4573.04|4.56|ends backward
4574.56|3.04|so that seems to have worked
4577.84|4.96|so instead backward routed the gradient
4581.12|3.44|to both of these so this is looking
4582.8|3.439|great
4584.56|2.96|now we could of course called uh called
4586.239|3.92|b grad
4587.52|4.48|beat up backwards sorry
4590.159|4.321|what's gonna happen
4592.0|3.6|well b doesn't have it backward b is
4594.48|3.12|backward
4595.6|4.559|because b is a leaf node
4597.6|4.0|b's backward is by initialization the
4600.159|4.08|empty function
4601.6|4.24|so nothing would happen but we can call
4604.239|4.161|call it on it
4605.84|4.24|but when we call
4608.4|4.4|this one
4610.08|2.72|it's backward
4613.44|4.08|then we expect this 0.5 to get further
4616.239|4.721|routed
4617.52|5.199|right so there we go 0.5.5
4620.96|4.239|and then finally
4622.719|6.321|we want to call
4625.199|3.841|it here on x2 w2
4630.32|3.96|and on x1 w1
4636.0|3.679|do both of those
4637.76|6.0|and there we go
4639.679|6.801|so we get 0 0.5 negative 1.5 and 1
4643.76|4.64|exactly as we did before but now
4646.48|4.48|we've done it through
4648.4|4.0|calling that backward um
4650.96|3.36|sort of manually
4652.4|4.0|so we have the lamp one last piece to
4654.32|4.08|get rid of which is us calling
4656.4|4.0|underscore backward manually so let's
4658.4|3.04|think through what we are actually doing
4660.4|2.799|um
4661.44|3.44|we've laid out a mathematical expression
4663.199|3.281|and now we're trying to go backwards
4664.88|3.92|through that expression
4666.48|4.0|um so going backwards through the
4668.8|5.28|expression just means that we never want
4670.48|4.8|to call a dot backward for any node
4674.08|4.639|before
4675.28|4.399|we've done a sort of um everything after
4678.719|2.561|it
4679.679|3.121|so we have to do everything after it
4681.28|3.04|before we're ever going to call that
4682.8|3.2|backward on any one node we have to get
4684.32|4.24|all of its full dependencies everything
4686.0|4.48|that it depends on has to
4688.56|5.599|propagate to it before we can continue
4690.48|5.52|back propagation so this ordering of
4694.159|3.601|graphs can be achieved using something
4696.0|4.08|called topological sort
4697.76|5.36|so topological sort
4700.08|4.8|is basically a laying out of a graph
4703.12|3.52|such that all the edges go only from
4704.88|4.48|left to right basically
4706.64|4.88|so here we have a graph it's a directory
4709.36|4.64|a cyclic graph a dag
4711.52|4.719|and this is two different topological
4714.0|3.52|orders of it i believe where basically
4716.239|3.121|you'll see that it's laying out of the
4717.52|4.4|notes such that all the edges go only
4719.36|4.879|one way from left to right
4721.92|4.319|and implementing topological sort you
4724.239|4.561|can look in wikipedia and so on i'm not
4726.239|5.281|going to go through it in detail
4728.8|5.359|but basically this is what builds a
4731.52|5.44|topological graph
4734.159|5.361|we maintain a set of visited nodes and
4736.96|5.04|then we are
4739.52|4.159|going through starting at some root node
4742.0|3.679|which for us is o that's where we want
4743.679|4.321|to start the topological sort
4745.679|4.801|and starting at o we go through all of
4748.0|4.64|its children and we need to lay them out
4750.48|4.48|from left to right
4752.64|4.559|and basically this starts at o
4754.96|4.16|if it's not visited then it marks it as
4757.199|3.52|visited and then it iterates through all
4759.12|5.119|of its children
4760.719|5.44|and calls build topological on them
4764.239|4.161|and then uh after it's gone through all
4766.159|3.761|the children it adds itself
4768.4|3.52|so basically
4769.92|4.64|this node that we're going to call it on
4771.92|5.68|like say o is only going to add itself
4774.56|4.8|to the topo list after all of the
4777.6|4.16|children have been processed and that's
4779.36|4.16|how this function is guaranteeing
4781.76|3.919|that you're only going to be in the list
4783.52|3.44|once all your children are in the list
4785.679|3.761|and that's the invariant that is being
4786.96|5.199|maintained so if we built upon o and
4789.44|5.44|then inspect this list
4792.159|4.321|we're going to see that it ordered our
4794.88|3.52|value objects
4796.48|4.0|and the last one
4798.4|3.36|is the value of 0.707 which is the
4800.48|4.4|output
4801.76|5.36|so this is o and then this is n
4804.88|4.88|and then all the other nodes get laid
4807.12|4.88|out before it
4809.76|4.16|so that builds the topological graph and
4812.0|4.639|really what we're doing now is we're
4813.92|5.92|just calling dot underscore backward on
4816.639|5.361|all of the nodes in a topological order
4819.84|3.6|so if we just reset the gradients
4822.0|2.719|they're all zero
4823.44|4.239|what did we do
4824.719|5.121|we started by
4827.679|3.761|setting o dot grad
4829.84|3.76|to b1
4831.44|6.48|that's the base case
4833.6|4.32|then we built the topological order
4838.48|4.159|and then we went for node
4841.84|2.16|in
4842.639|3.761|reversed
4844.0|3.6|of topo
4846.4|2.96|now
4847.6|3.2|in in the reverse order because this
4849.36|3.04|list goes from
4850.8|3.12|you know we need to go through it in
4852.4|3.68|reversed order
4853.92|4.719|so starting at o
4856.08|5.28|note that backward
4858.639|4.721|and this should be
4861.36|4.16|it
4863.36|3.76|there we go
4865.52|3.36|those are the correct derivatives
4867.12|3.039|finally we are going to hide this
4868.88|2.799|functionality
4870.159|3.601|so i'm going to
4871.679|3.761|copy this and we're going to hide it
4873.76|4.479|inside the valley class because we don't
4875.44|4.4|want to have all that code lying around
4878.239|3.201|so instead of an underscore backward
4879.84|4.0|we're now going to define an actual
4881.44|4.799|backward so that's backward without the
4883.84|3.68|underscore
4886.239|2.801|and that's going to do all the stuff
4887.52|2.88|that we just arrived
4889.04|3.44|so let me just clean this up a little
4890.4|4.96|bit so
4892.48|2.88|we're first going to
4897.04|4.24|build a topological graph
4898.96|5.199|starting at self
4901.28|5.28|so build topo of self
4904.159|5.121|will populate the topological order into
4906.56|6.4|the topo list which is a local variable
4909.28|6.08|then we set self.grad to be one
4912.96|4.719|and then for each node in the reversed
4915.36|4.64|list so starting at us and going to all
4917.679|4.721|the children
4920.0|3.28|underscore backward
4922.4|3.68|and
4923.28|4.72|that should be it so
4926.08|3.119|save
4928.0|1.91|come down here
4929.199|1.921|redefine
4929.91|3.69|[Music]
4931.12|4.079|okay all the grands are zero
4933.6|3.52|and now what we can do is oh that
4935.199|4.161|backward without the underscore
4937.12|2.24|and
4941.44|5.199|there we go
4942.88|5.52|and that's uh that's back propagation
4946.639|3.281|place for one neuron
4948.4|3.92|now we shouldn't be too happy with
4949.92|5.12|ourselves actually because we have a bad
4952.32|4.48|bug um and we have not surfaced the bug
4955.04|4.88|because of some specific conditions that
4956.8|5.2|we are we have to think about right now
4959.92|4.0|so here's the simplest case that shows
4962.0|5.76|the bug
4963.92|3.84|say i create a single node a
4968.0|6.56|and then i create a b that is a plus a
4971.6|2.96|and then i called backward
4974.8|5.2|so what's going to happen is a is 3
4977.28|6.32|and then a b is a plus a so there's two
4980.0|3.6|arrows on top of each other here
4983.76|3.12|then we can see that b is of course the
4985.44|2.64|forward pass works
4986.88|3.12|b is just
4988.08|3.599|a plus a which is six
4990.0|2.639|but the gradient here is not actually
4991.679|4.241|correct
4992.639|4.801|that we calculate it automatically
4995.92|3.279|and that's because
4997.44|3.04|um
4999.199|3.281|of course uh
5000.48|4.08|just doing calculus in your head the
5002.48|5.12|derivative of b with respect to a
5004.56|4.24|should be uh two
5007.6|3.119|one plus one
5008.8|3.439|it's not one
5010.719|3.92|intuitively what's happening here right
5012.239|4.4|so b is the result of a plus a and then
5014.639|6.401|we call backward on it
5016.639|4.401|so let's go up and see what that does
5022.08|3.44|um
5023.6|3.24|b is a result of addition
5025.52|4.0|so out as
5026.84|3.96|b and then when we called backward what
5029.52|3.679|happened is
5030.8|3.6|self.grad was set
5033.199|4.0|to one
5034.4|5.44|and then other that grad was set to one
5037.199|4.801|but because we're doing a plus a
5039.84|3.52|self and other are actually the exact
5042.0|4.0|same object
5043.36|4.24|so we are overriding the gradient we are
5046.0|4.0|setting it to one and then we are
5047.6|3.599|setting it again to one and that's why
5050.0|3.04|it stays
5051.199|3.44|at one
5053.04|3.36|so that's a problem
5054.639|5.361|there's another way to see this in a
5056.4|3.6|little bit more complicated expression
5061.52|4.4|so here we have
5063.52|5.36|a and b
5065.92|4.88|and then uh d will be the multiplication
5068.88|3.12|of the two and e will be the addition of
5070.8|2.24|the two
5072.0|3.28|and
5073.04|4.639|then we multiply e times d to get f and
5075.28|4.32|then we called fda backward
5077.679|3.121|and these gradients if you check will be
5079.6|2.88|incorrect
5080.8|4.24|so fundamentally what's happening here
5082.48|3.92|again is
5085.04|4.159|basically we're going to see an issue
5086.4|4.64|anytime we use a variable more than once
5089.199|4.0|until now in these expressions above
5091.04|3.92|every variable is used exactly once so
5093.199|3.44|we didn't see the issue
5094.96|2.96|but here if a variable is used more than
5096.639|3.6|once what's going to happen during
5097.92|5.36|backward pass we're backpropagating from
5100.239|5.601|f to e to d so far so good but now
5103.28|4.72|equals it backward and it deposits its
5105.84|3.28|gradients to a and b but then we come
5108.0|3.44|back to d
5109.12|5.36|and call backward and it overwrites
5111.44|5.68|those gradients at a and b
5114.48|5.44|so that's obviously a problem
5117.12|5.119|and the solution here if you look at
5119.92|4.0|the multivariate case of the chain rule
5122.239|4.081|and its generalization there
5123.92|4.16|the solution there is basically that we
5126.32|3.76|have to accumulate these gradients these
5128.08|4.159|gradients add
5130.08|4.559|and so instead of setting those
5132.239|4.881|gradients
5134.639|4.481|we can simply do plus equals we need to
5137.12|4.8|accumulate those gradients
5139.12|5.44|plus equals plus equals
5141.92|2.64|plus equals
5144.639|3.52|plus equals
5146.48|3.759|and this will be okay remember because
5148.159|3.281|we are initializing them at zero so they
5150.239|3.121|start at zero
5151.44|3.44|and then any
5153.36|3.839|contribution
5154.88|3.92|that flows backwards
5157.199|4.081|will simply add
5158.8|4.96|so now if we redefine
5161.28|4.72|this one
5163.76|4.479|because the plus equals this now works
5166.0|5.12|because a.grad started at zero and we
5168.239|4.881|called beta backward we deposit one and
5171.12|3.84|then we deposit one again and now this
5173.12|3.84|is two which is correct
5174.96|3.44|and here this will also work and we'll
5176.96|3.199|get correct gradients
5178.4|3.2|because when we call eta backward we
5180.159|3.601|will deposit the gradients from this
5181.6|4.4|branch and then we get to back into
5183.76|4.399|detail backward it will deposit its own
5186.0|4.56|gradients and then those gradients
5188.159|3.761|simply add on top of each other and so
5190.56|3.52|we just accumulate those gradients and
5191.92|3.759|that fixes the issue okay now before we
5194.08|4.72|move on let me actually do a bit of
5195.679|5.52|cleanup here and delete some of these
5198.8|3.919|some of this intermediate work so
5201.199|3.601|we're not gonna need any of this now
5202.719|2.96|that we've derived all of it
5204.8|3.2|um
5205.679|4.0|we are going to keep this because i want
5208.0|3.28|to come back to it
5209.679|4.161|delete the 10h
5211.28|4.56|delete our morning example
5213.84|5.839|delete the step
5215.84|6.24|delete this keep the code that draws
5219.679|4.161|and then delete this example
5222.08|3.2|and leave behind only the definition of
5223.84|2.72|value
5225.28|2.879|and now let's come back to this
5226.56|4.159|non-linearity here that we implemented
5228.159|5.601|the tanh now i told you that we could
5230.719|5.281|have broken down 10h into its explicit
5233.76|4.56|atoms in terms of other expressions if
5236.0|4.56|we had the x function so if you remember
5238.32|4.56|tan h is defined like this and we chose
5240.56|4.079|to develop tan h as a single function
5242.88|3.12|and we can do that because we know its
5244.639|2.321|derivative and we can back propagate
5246.0|3.199|through it
5246.96|4.48|but we can also break down tan h into
5249.199|3.921|and express it as a function of x and i
5251.44|2.88|would like to do that now because i want
5253.12|3.68|to prove to you that you get all the
5254.32|3.919|same results and all those ingredients
5256.8|3.2|but also because it forces us to
5258.239|4.721|implement a few more expressions it
5260.0|4.8|forces us to do exponentiation addition
5262.96|3.279|subtraction division and things like
5264.8|3.28|that and i think it's a good exercise to
5266.239|3.841|go through a few more of these
5268.08|4.079|okay so let's scroll up
5270.08|3.76|to the definition of value
5272.159|4.48|and here one thing that we currently
5273.84|4.56|can't do is we can do like a value of
5276.639|3.761|say 2.0
5278.4|4.16|but we can't do you know here for
5280.4|4.72|example we want to add constant one and
5282.56|4.4|we can't do something like this
5285.12|3.599|and we can't do it because it says
5286.96|4.16|object has no attribute data that's
5288.719|3.361|because a plus one comes right here to
5291.12|3.76|add
5292.08|4.48|and then other is the integer one and
5294.88|3.839|then here python is trying to access
5296.56|3.92|one.data and that's not a thing and
5298.719|3.52|that's because basically one is not a
5300.48|4.32|value object and we only have addition
5302.239|4.561|for value objects so as a matter of
5304.8|3.439|convenience so that we can create
5306.8|2.32|expressions like this and make them make
5308.239|4.081|sense
5309.12|4.559|we can simply do something like this
5312.32|3.6|basically
5313.679|4.081|we let other alone if other is an
5315.92|3.12|instance of value but if it's not an
5317.76|3.12|instance of value we're going to assume
5319.04|4.32|that it's a number like an integer float
5320.88|4.319|and we're going to simply wrap it in in
5323.36|3.52|value and then other will just become
5325.199|4.081|value of other and then other will have
5326.88|4.96|a data attribute and this should work so
5329.28|3.919|if i just say this predefined value then
5331.84|3.44|this should work
5333.199|4.0|there we go okay now let's do the exact
5335.28|3.6|same thing for multiply because we can't
5337.199|2.561|do something like this
5338.88|2.799|again
5339.76|5.2|for the exact same reason so we just
5341.679|5.841|have to go to mole and if other is
5344.96|5.52|not a value then let's wrap it in value
5347.52|5.28|let's redefine value and now this works
5350.48|4.8|now here's a kind of unfortunate and not
5352.8|6.8|obvious part a times two works we saw
5355.28|6.64|that but two times a is that gonna work
5359.6|3.36|you'd expect it to right but actually it
5361.92|2.319|will not
5362.96|3.12|and the reason it won't is because
5364.239|4.241|python doesn't know
5366.08|5.36|like when when you do a times two
5368.48|4.4|basically um so a times two python will
5371.44|3.279|go and it will basically do something
5372.88|3.68|like a dot mul
5374.719|4.96|of two that's basically what it will
5376.56|5.28|call but to it 2 times a is the same as
5379.679|5.281|2 dot mol of a
5381.84|4.799|and it doesn't 2 can't multiply
5384.96|2.4|value and so it's really confused about
5386.639|2.56|that
5387.36|4.4|so instead what happens is in python the
5389.199|5.121|way this works is you are free to define
5391.76|4.08|something called the r mold
5394.32|4.0|and our mole
5395.84|6.56|is kind of like a fallback so if python
5398.32|6.72|can't do 2 times a it will check if um
5402.4|4.799|if by any chance a knows how to multiply
5405.04|3.76|two and that will be called into our
5407.199|4.0|mole
5408.8|4.0|so because python can't do two times a
5411.199|4.161|it will check is there an our mole in
5412.8|4.0|value and because there is it will now
5415.36|3.6|call that
5416.8|4.56|and what we'll do here is we will swap
5418.96|4.56|the order of the operands so basically
5421.36|4.72|two times a will redirect to armel and
5423.52|4.8|our mole will basically call a times two
5426.08|2.96|and that's how that will work
5428.32|2.879|so
5429.04|4.48|redefining now with armor two times a
5431.199|3.681|becomes four okay now looking at the
5433.52|2.719|other elements that we still need we
5434.88|3.52|need to know how to exponentiate and how
5436.239|4.241|to divide so let's first the explanation
5438.4|3.36|to the exponentiation part we're going
5440.48|2.48|to introduce
5441.76|3.28|a single
5442.96|4.96|function x here
5445.04|4.639|and x is going to mirror 10h in the
5447.92|3.279|sense that it's a simple single function
5449.679|3.441|that transforms a single scalar value
5451.199|4.801|and outputs a single scalar value
5453.12|4.88|so we pop out the python number we use
5456.0|3.199|math.x to exponentiate it create a new
5458.0|2.88|value object
5459.199|3.04|everything that we've seen before the
5460.88|3.92|tricky part of course is how do you
5462.239|3.681|propagate through e to the x
5464.8|2.879|and
5465.92|3.759|so here you can potentially pause the
5467.679|4.241|video and think about what should go
5469.679|2.241|here
5473.28|5.359|okay so basically we need to know what
5475.84|5.44|is the local derivative of e to the x so
5478.639|4.481|d by d x of e to the x is famously just
5481.28|4.24|e to the x and we've already just
5483.12|4.64|calculated e to the x and it's inside
5485.52|3.44|out that data so we can do up that data
5487.76|2.0|times
5488.96|3.04|and
5489.76|4.08|out that grad that's the chain rule
5492.0|3.28|so we're just chaining on to the current
5493.84|2.879|running grad
5495.28|3.359|and this is what the expression looks
5496.719|3.281|like it looks a little confusing but
5498.639|3.121|this is what it is and that's the
5500.0|3.679|exponentiation
5501.76|3.6|so redefining we should now be able to
5503.679|2.48|call a.x
5505.36|2.48|and
5506.159|3.441|hopefully the backward pass works as
5507.84|3.12|well okay and the last thing we'd like
5509.6|2.639|to do of course is we'd like to be able
5510.96|2.16|to divide
5512.239|2.241|now
5513.12|2.88|i actually will implement something
5514.48|3.36|slightly more powerful than division
5516.0|3.92|because division is just a special case
5517.84|4.799|of something a bit more powerful
5519.92|4.96|so in particular just by rearranging
5522.639|4.961|if we have some kind of a b equals
5524.88|4.319|value of 4.0 here we'd like to basically
5527.6|4.0|be able to do a divide b and we'd like
5529.199|5.04|this to be able to give us 0.5
5531.6|5.44|now division actually can be reshuffled
5534.239|4.48|as follows if we have a divide b that's
5537.04|2.8|actually the same as a multiplying one
5538.719|2.881|over b
5539.84|4.399|and that's the same as a multiplying b
5541.6|4.16|to the power of negative one
5544.239|3.281|and so what i'd like to do instead is i
5545.76|4.0|basically like to implement the
5547.52|5.04|operation of x to the k for some
5549.76|5.52|constant uh k so it's an integer or a
5552.56|4.4|float um and we would like to be able to
5555.28|5.52|differentiate this and then as a special
5556.96|5.52|case uh negative one will be division
5560.8|4.399|and so i'm doing that just because uh
5562.48|4.48|it's more general and um yeah you might
5565.199|4.241|as well do it that way so basically what
5566.96|4.32|i'm saying is we can redefine
5569.44|5.04|uh division
5571.28|5.04|which we will put here somewhere
5574.48|3.6|yeah we can put it here somewhere what
5576.32|4.48|i'm saying is that we can redefine
5578.08|5.04|division so self-divide other
5580.8|4.879|can actually be rewritten as self times
5583.12|4.24|other to the power of negative one
5585.679|3.52|and now
5587.36|4.24|a value raised to the power of negative
5589.199|3.121|one we have now defined that
5591.6|2.0|so
5592.32|3.6|here's
5593.6|3.68|so we need to implement the pow function
5595.92|4.08|where am i going to put the power
5597.28|5.2|function maybe here somewhere
5600.0|4.32|this is the skeleton for it
5602.48|4.239|so this function will be called when we
5604.32|4.319|try to raise a value to some power and
5606.719|3.841|other will be that power
5608.639|4.401|now i'd like to make sure that other is
5610.56|4.8|only an int or a float usually other is
5613.04|4.32|some kind of a different value object
5615.36|5.279|but here other will be forced to be an
5617.36|4.799|end or a float otherwise the math
5620.639|3.201|won't work for
5622.159|3.201|for or try to achieve in the specific
5623.84|4.0|case that would be a different
5625.36|4.24|derivative expression if we wanted other
5627.84|3.68|to be a value
5629.6|4.079|so here we create the output value which
5631.52|3.92|is just uh you know this data raised to
5633.679|3.201|the power of other and other here could
5635.44|3.92|be for example negative one that's what
5636.88|4.96|we are hoping to achieve
5639.36|4.48|and then uh this is the backwards stub
5641.84|5.44|and this is the fun part which is what
5643.84|5.76|is the uh chain rule expression here for
5647.28|4.32|back for um
5649.6|4.32|back propagating through the power
5651.6|4.079|function where the power is to the power
5653.92|3.36|of some kind of a constant
5655.679|2.96|so this is the exercise and maybe pause
5657.28|3.2|the video here and see if you can figure
5658.639|4.08|it out yourself as to what we should put
5660.48|2.239|here
5666.96|3.84|okay so
5669.04|3.76|you can actually go here and look at
5670.8|3.52|derivative rules as an example and we
5672.8|3.2|see lots of derivatives that you can
5674.32|3.44|hopefully know from calculus in
5676.0|3.12|particular what we're looking for is the
5677.76|2.56|power rule
5679.12|3.599|because that's telling us that if we're
5680.32|4.24|trying to take d by dx of x to the n
5682.719|4.241|which is what we're doing here
5684.56|3.84|then that is just n times x to the n
5686.96|2.56|minus 1
5688.4|2.48|right
5689.52|2.08|okay
5690.88|2.4|so
5691.6|4.32|that's telling us about the local
5693.28|5.04|derivative of this power operation
5695.92|4.799|so all we want here
5698.32|5.12|basically n is now other
5700.719|5.361|and self.data is x
5703.44|5.12|and so this now becomes
5706.08|4.159|other which is n times
5708.56|4.48|self.data
5710.239|4.48|which is now a python in torah float
5713.04|3.119|it's not a valley object we're accessing
5714.719|2.561|the data attribute
5716.159|3.601|raised
5717.28|3.839|to the power of other minus one or n
5719.76|2.879|minus one
5721.119|4.161|i can put brackets around this but this
5722.639|4.721|doesn't matter because
5725.28|4.16|power takes precedence over multiply and
5727.36|4.0|python so that would have been okay
5729.44|3.92|and that's the local derivative only but
5731.36|3.52|now we have to chain it and we change
5733.36|3.359|just simply by multiplying by output
5734.88|5.839|grad that's chain rule
5736.719|6.241|and this should technically work
5740.719|3.121|and we're going to find out soon but now
5742.96|3.759|if we
5743.84|5.359|do this this should now work
5746.719|4.721|and we get 0.5 so the forward pass works
5749.199|3.52|but does the backward pass work and i
5751.44|3.279|realize that we actually also have to
5752.719|4.641|know how to subtract so
5754.719|5.361|right now a minus b will not work
5757.36|4.4|to make it work we need one more
5760.08|2.88|piece of code here
5761.76|3.6|and
5762.96|3.84|basically this is the
5765.36|3.44|subtraction and the way we're going to
5766.8|3.919|implement subtraction is we're going to
5768.8|3.359|implement it by addition of a negation
5770.719|3.44|and then to implement negation we're
5772.159|3.361|gonna multiply by negative one so just
5774.159|3.681|again using the stuff we've already
5775.52|4.639|built and just um expressing it in terms
5777.84|4.48|of what we have and a minus b is now
5780.159|5.04|working okay so now let's scroll again
5782.32|4.56|to this expression here for this neuron
5785.199|3.281|and let's just
5786.88|3.12|compute the backward pass here once
5788.48|3.52|we've defined o
5790.0|3.679|and let's draw it
5792.0|3.119|so here's the gradients for all these
5793.679|3.601|leaf nodes for this two-dimensional
5795.119|4.321|neuron that has a 10h that we've seen
5797.28|4.64|before so now what i'd like to do is i'd
5799.44|4.88|like to break up this 10h
5801.92|4.319|into this expression here
5804.32|3.04|so let me copy paste this
5806.239|3.041|here
5807.36|2.879|and now instead of we'll preserve the
5809.28|4.399|label
5810.239|4.801|and we will change how we define o
5813.679|3.04|so in particular we're going to
5815.04|3.52|implement this formula here
5816.719|4.721|so we need e to the 2x
5818.56|6.159|minus 1 over e to the x plus 1. so e to
5821.44|5.679|the 2x we need to take 2 times n and we
5824.719|4.241|need to exponentiate it that's e to the
5827.119|3.681|two x and then because we're using it
5828.96|3.6|twice let's create an intermediate
5830.8|4.16|variable e
5832.56|4.24|and then define o as
5834.96|4.239|e plus one over
5836.8|6.0|e minus one over e plus one
5839.199|5.52|e minus one over e plus one
5842.8|4.16|and that should be it and then we should
5844.719|4.561|be able to draw that of o
5846.96|3.92|so now before i run this what do we
5849.28|3.359|expect to see
5850.88|2.799|number one we're expecting to see a much
5852.639|3.04|longer
5853.679|3.921|graph here because we've broken up 10h
5855.679|3.681|into a bunch of other operations
5857.6|3.44|but those operations are mathematically
5859.36|4.4|equivalent and so what we're expecting
5861.04|4.88|to see is number one the same
5863.76|3.439|result here so the forward pass works
5865.92|3.199|and number two because of that
5867.199|3.841|mathematical equivalence we expect to
5869.119|4.08|see the same backward pass and the same
5871.04|4.159|gradients on these leaf nodes so these
5873.199|4.801|gradients should be identical
5875.199|5.121|so let's run this
5878.0|5.28|so number one let's verify that instead
5880.32|6.56|of a single 10h node we have now x and
5883.28|5.439|we have plus we have times negative one
5886.88|4.0|uh this is the division
5888.719|3.041|and we end up with the same forward pass
5890.88|2.239|here
5891.76|2.479|and then the gradients we have to be
5893.119|3.201|careful because they're in slightly
5894.239|5.201|different order potentially the
5896.32|5.68|gradients for w2x2 should be 0 and 0.5
5899.44|5.759|w2 and x2 are 0 and 0.5
5902.0|5.199|and w1 x1 are 1 and negative 1.5
5905.199|3.681|1 and negative 1.5
5907.199|3.841|so that means that both our forward
5908.88|4.239|passes and backward passes were correct
5911.04|2.96|because this turned out to be equivalent
5913.119|2.641|to
5914.0|3.28|10h before
5915.76|3.439|and so the reason i wanted to go through
5917.28|4.32|this exercise is number one we got to
5919.199|4.241|practice a few more operations and uh
5921.6|3.68|writing more backwards passes and number
5923.44|2.719|two i wanted to illustrate the point
5925.28|2.48|that
5926.159|3.361|the um
5927.76|3.919|the level at which you implement your
5929.52|3.92|operations is totally up to you you can
5931.679|3.201|implement backward passes for tiny
5933.44|3.199|expressions like a single individual
5934.88|4.08|plus or a single times
5936.639|3.361|or you can implement them for say
5938.96|2.719|10h
5940.0|3.199|which is a kind of a potentially you can
5941.679|3.601|see it as a composite operation because
5943.199|3.92|it's made up of all these more atomic
5945.28|3.52|operations but really all of this is
5947.119|3.281|kind of like a fake concept all that
5948.8|2.879|matters is we have some kind of inputs
5950.4|2.64|and some kind of an output and this
5951.679|3.121|output is a function of the inputs in
5953.04|3.599|some way and as long as you can do
5954.8|4.24|forward pass and the backward pass of
5956.639|4.56|that little operation it doesn't matter
5959.04|4.0|what that operation is
5961.199|3.44|and how composite it is
5963.04|2.96|if you can write the local gradients you
5964.639|3.52|can chain the gradient and you can
5966.0|4.08|continue back propagation so the design
5968.159|3.761|of what those functions are is
5970.08|3.2|completely up to you
5971.92|3.36|so now i would like to show you how you
5973.28|3.919|can do the exact same thing by using a
5975.28|4.72|modern deep neural network library like
5977.199|4.561|for example pytorch which i've roughly
5980.0|2.8|modeled micrograd
5981.76|1.919|by
5982.8|2.16|and so
5983.679|2.96|pytorch is something you would use in
5984.96|3.679|production and i'll show you how you can
5986.639|4.241|do the exact same thing but in pytorch
5988.639|3.921|api so i'm just going to copy paste it
5990.88|3.839|in and walk you through it a little bit
5992.56|4.32|this is what it looks like
5994.719|4.881|so we're going to import pi torch and
5996.88|4.799|then we need to define these
5999.6|5.2|value objects like we have here
6001.679|5.761|now micrograd is a scalar valued
6004.8|5.2|engine so we only have scalar values
6007.44|4.32|like 2.0 but in pi torch everything is
6010.0|3.84|based around tensors and like i
6011.76|4.0|mentioned tensors are just n-dimensional
6013.84|3.76|arrays of scalars
6015.76|4.08|so that's why things get a little bit
6017.6|4.16|more complicated here i just need a
6019.84|3.52|scalar value to tensor a tensor with
6021.76|3.52|just a single element
6023.36|5.12|but by default when you work with
6025.28|5.359|pytorch you would use um
6028.48|5.12|more complicated tensors like this so if
6030.639|2.961|i import pytorch
6033.92|4.4|then i can create tensors like this and
6036.239|3.521|this tensor for example is a two by
6038.32|2.799|three array
6039.76|2.72|of scalar
6041.119|4.08|scalars
6042.48|4.08|in a single compact representation so we
6045.199|2.801|can check its shape we see that it's a
6046.56|2.88|two by three array
6048.0|2.8|and so on
6049.44|4.56|so this is usually what you would work
6050.8|4.48|with um in the actual libraries so here
6054.0|4.08|i'm creating
6055.28|5.2|a tensor that has only a single element
6058.08|5.44|2.0
6060.48|5.28|and then i'm casting it to be double
6063.52|3.84|because python is by default using
6065.76|3.2|double precision for its floating point
6067.36|5.04|numbers so i'd like everything to be
6068.96|5.84|identical by default the data type of
6072.4|4.319|these tensors will be float32 so it's
6074.8|4.16|only using a single precision float so
6076.719|4.48|i'm casting it to double
6078.96|3.679|so that we have float64 just like in
6081.199|3.52|python
6082.639|5.441|so i'm casting to double and then we get
6084.719|4.881|something similar to value of two the
6088.08|3.44|next thing i have to do is because these
6089.6|3.36|are leaf nodes by default pytorch
6091.52|3.679|assumes that they do not require
6092.96|3.84|gradients so i need to explicitly say
6095.199|2.721|that all of these nodes require
6096.8|3.04|gradients
6097.92|5.279|okay so this is going to construct
6099.84|4.64|scalar valued one element tensors
6103.199|3.92|make sure that fighters knows that they
6104.48|4.4|require gradients now by default these
6107.119|3.681|are set to false by the way because of
6108.88|4.72|efficiency reasons because usually you
6110.8|4.96|would not want gradients for leaf nodes
6113.6|3.599|like the inputs to the network and this
6115.76|3.439|is just trying to be efficient in the
6117.199|4.241|most common cases
6119.199|4.721|so once we've defined all of our values
6121.44|4.56|in python we can perform arithmetic just
6123.92|3.68|like we can here in microgradlend so
6126.0|3.679|this will just work and then there's a
6127.6|4.88|torch.10h also
6129.679|3.841|and when we get back is a tensor again
6132.48|3.12|and we can
6133.52|4.719|just like in micrograd it's got a data
6135.6|4.32|attribute and it's got grant attributes
6138.239|4.48|so these tensor objects just like in
6139.92|3.52|micrograd have a dot data and a dot grad
6142.719|2.4|and
6143.44|4.64|the only difference here is that we need
6145.119|5.281|to call it that item because otherwise
6148.08|4.079|um pi torch
6150.4|3.68|that item basically takes
6152.159|4.08|a single tensor of one element and it
6154.08|3.68|just returns that element stripping out
6156.239|3.281|the tensor
6157.76|3.52|so let me just run this and hopefully we
6159.52|2.96|are going to get this is going to print
6161.28|3.6|the forward pass
6162.48|4.32|which is 0.707
6164.88|3.44|and this will be the gradients which
6166.8|4.319|hopefully are
6168.32|5.44|0.5 0 negative 1.5 and 1.
6171.119|3.841|so if we just run this
6173.76|3.68|there we go
6174.96|4.4|0.7 so the forward pass agrees and then
6177.44|3.199|point five zero negative one point five
6179.36|3.279|and one
6180.639|4.401|so pi torch agrees with us
6182.639|5.6|and just to show you here basically o
6185.04|4.48|here's a tensor with a single element
6188.239|3.761|and it's a double
6189.52|4.8|and we can call that item on it to just
6192.0|4.88|get the single number out
6194.32|4.64|so that's what item does and o is a
6196.88|3.6|tensor object like i mentioned and it's
6198.96|3.12|got a backward function just like we've
6200.48|3.36|implemented
6202.08|4.0|and then all of these also have a dot
6203.84|4.24|graph so like x2 for example in the grad
6206.08|5.36|and it's a tensor and we can pop out the
6208.08|4.88|individual number with that actin
6211.44|3.6|so basically
6212.96|4.239|torches torch can do what we did in
6215.04|5.36|micrograph is a special case when your
6217.199|4.96|tensors are all single element tensors
6220.4|2.88|but the big deal with pytorch is that
6222.159|2.96|everything is significantly more
6223.28|4.0|efficient because we are working with
6225.119|4.08|these tensor objects and we can do lots
6227.28|4.16|of operations in parallel on all of
6229.199|4.321|these tensors
6231.44|4.16|but otherwise what we've built very much
6233.52|3.679|agrees with the api of pytorch
6235.6|2.72|okay so now that we have some machinery
6237.199|3.281|to build out pretty complicated
6238.32|3.919|mathematical expressions we can also
6240.48|2.96|start building out neural nets and as i
6242.239|3.281|mentioned neural nets are just a
6243.44|3.6|specific class of mathematical
6245.52|2.639|expressions
6247.04|2.8|so we're going to start building out a
6248.159|4.0|neural net piece by piece and eventually
6249.84|4.399|we'll build out a two-layer multi-layer
6252.159|3.761|layer perceptron as it's called and i'll
6254.239|2.88|show you exactly what that means
6255.92|3.759|let's start with a single individual
6257.119|4.241|neuron we've implemented one here but
6259.679|4.48|here i'm going to implement one that
6261.36|4.879|also subscribes to the pytorch api in
6264.159|3.121|how it designs its neural network
6266.239|2.641|modules
6267.28|3.919|so just like we saw that we can like
6268.88|4.72|match the api of pytorch
6271.199|4.641|on the auto grad side we're going to try
6273.6|4.8|to do that on the neural network modules
6275.84|5.12|so here's class neuron
6278.4|4.16|and just for the sake of efficiency i'm
6280.96|4.56|going to copy paste some sections that
6282.56|4.96|are relatively straightforward
6285.52|4.24|so the constructor will take
6287.52|5.199|number of inputs to this neuron which is
6289.76|5.359|how many inputs come to a neuron so this
6292.719|4.48|one for example has three inputs
6295.119|3.281|and then it's going to create a weight
6297.199|2.881|there is some random number between
6298.4|2.799|negative one and one for every one of
6300.08|3.599|those inputs
6301.199|5.281|and a bias that controls the overall
6303.679|4.96|trigger happiness of this neuron
6306.48|4.8|and then we're going to implement a def
6308.639|5.361|underscore underscore call
6311.28|4.56|of self and x some input x
6314.0|3.36|and really what we don't do here is w
6315.84|3.68|times x plus b
6317.36|3.92|where w times x here is a dot product
6319.52|3.28|specifically
6321.28|2.72|now if you haven't seen
6322.8|3.919|call
6324.0|4.32|let me just return 0.0 here for now the
6326.719|4.4|way this works now is we can have an x
6328.32|4.16|which is say like 2.0 3.0 then we can
6331.119|2.801|initialize a neuron that is
6332.48|3.199|two-dimensional
6333.92|3.12|because these are two numbers and then
6335.679|4.081|we can feed those two numbers into that
6337.04|5.599|neuron to get an output
6339.76|5.28|and so when you use this notation n of x
6342.639|6.401|python will use call
6345.04|4.0|so currently call just return 0.0
6350.08|4.8|now we'd like to actually do the forward
6352.08|5.2|pass of this neuron instead
6354.88|4.08|so we're going to do here first is we
6357.28|4.08|need to basically multiply all of the
6358.96|5.279|elements of w with all of the elements
6361.36|4.24|of x pairwise we need to multiply them
6364.239|2.88|so the first thing we're going to do is
6365.6|3.44|we're going to zip up
6367.119|5.441|celta w and x
6369.04|5.44|and in python zip takes two iterators
6372.56|3.599|and it creates a new iterator that
6374.48|3.44|iterates over the tuples of the
6376.159|3.841|corresponding entries
6377.92|4.08|so for example just to show you we can
6380.0|6.6|print this list
6382.0|4.6|and still return 0.0 here
6390.8|2.24|sorry
6394.08|7.0|so we see that these w's are paired up
6396.239|4.841|with the x's w with x
6401.44|3.199|and now what we want to do is
6407.36|5.359|for w i x i in
6410.639|4.241|we want to multiply w times
6412.719|3.841|w wi times x i
6414.88|2.64|and then we want to sum all of that
6416.56|3.04|together
6417.52|4.639|to come up with an activation
6419.6|4.639|and add also subnet b on top
6422.159|3.281|so that's the raw activation and then of
6424.239|3.041|course we need to pass that through a
6425.44|4.4|non-linearity so what we're going to be
6427.28|4.959|returning is act.10h
6429.84|3.279|and here's out
6432.239|2.321|so
6433.119|3.201|now we see that we are getting some
6434.56|3.119|outputs and we get a different output
6436.32|3.12|from a neuron each time because we are
6437.679|3.52|initializing different weights and by
6439.44|3.199|and biases
6441.199|4.241|and then to be a bit more efficient here
6442.639|6.241|actually sum by the way takes a second
6445.44|6.239|optional parameter which is the start
6448.88|5.2|and by default the start is zero so
6451.679|4.081|these elements of this sum will be added
6454.08|3.119|on top of zero to begin with but
6455.76|2.64|actually we can just start with cell dot
6457.199|2.561|b
6458.4|3.6|and then we just have an expression like
6459.76|2.24|this
6465.44|3.92|and then the generator expression here
6467.04|4.8|must be parenthesized in python
6469.36|2.48|there we go
6473.76|4.16|yep so now we can forward a single
6475.679|4.241|neuron next up we're going to define a
6477.92|4.56|layer of neurons so here we have a
6479.92|5.199|schematic for a mlb
6482.48|4.56|so we see that these mlps each layer
6485.119|3.52|this is one layer has actually a number
6487.04|2.72|of neurons and they're not connected to
6488.639|2.641|each other but all of them are fully
6489.76|3.68|connected to the input
6491.28|3.839|so what is a layer of neurons it's just
6493.44|3.279|it's just a set of neurons evaluated
6495.119|2.641|independently
6496.719|3.281|so
6497.76|5.28|in the interest of time i'm going to do
6500.0|5.04|something fairly straightforward here
6503.04|4.639|it's um
6505.04|3.92|literally a layer is just a list of
6507.679|3.121|neurons
6508.96|3.759|and then how many neurons do we have we
6510.8|3.28|take that as an input argument here how
6512.719|3.841|many neurons do you want in your layer
6514.08|4.32|number of outputs in this layer
6516.56|3.679|and so we just initialize completely
6518.4|4.719|independent neurons with this given
6520.239|4.721|dimensionality and when we call on it we
6523.119|4.641|just independently
6524.96|4.88|evaluate them so now instead of a neuron
6527.76|3.439|we can make a layer of neurons they are
6529.84|2.48|two-dimensional neurons and let's have
6531.199|2.641|three of them
6532.32|3.44|and now we see that we have three
6533.84|3.359|independent evaluations of three
6535.76|3.04|different neurons
6537.199|3.681|right
6538.8|3.839|okay finally let's complete this picture
6540.88|3.68|and define an entire multi-layer
6542.639|4.0|perceptron or mlp
6544.56|3.28|and as we can see here in an mlp these
6546.639|2.56|layers just feed into each other
6547.84|3.76|sequentially
6549.199|5.121|so let's come here and i'm just going to
6551.6|5.039|copy the code here in interest of time
6554.32|4.399|so an mlp is very similar
6556.639|4.161|we're taking the number of inputs
6558.719|3.92|as before but now instead of taking a
6560.8|3.919|single n out which is number of neurons
6562.639|4.321|in a single layer we're going to take a
6564.719|4.161|list of an outs and this list defines
6566.96|3.36|the sizes of all the layers that we want
6568.88|3.04|in our mlp
6570.32|4.08|so here we just put them all together
6571.92|4.88|and then iterate over consecutive pairs
6574.4|3.44|of these sizes and create layer objects
6576.8|2.399|for them
6577.84|3.279|and then in the call function we are
6579.199|3.601|just calling them sequentially so that's
6581.119|3.04|an mlp really
6582.8|3.76|and let's actually re-implement this
6584.159|3.841|picture so we want three input neurons
6586.56|3.119|and then two layers of four and an
6588.0|2.56|output unit
6589.679|2.721|so
6590.56|3.76|we want
6592.4|5.12|a three-dimensional input say this is an
6594.32|6.24|example input we want three inputs into
6597.52|6.079|two layers of four and one output
6600.56|4.88|and this of course is an mlp
6603.599|3.12|and there we go that's a forward pass of
6605.44|2.96|an mlp
6606.719|3.201|to make this a little bit nicer you see
6608.4|3.199|how we have just a single element but
6609.92|3.679|it's wrapped in a list because layer
6611.599|4.0|always returns lists
6613.599|5.04|circle for convenience
6615.599|4.961|return outs at zero if len out is
6618.639|3.761|exactly a single element
6620.56|3.039|else return fullest
6622.4|3.52|and this will allow us to just get a
6623.599|4.481|single value out at the last layer that
6625.92|3.679|only has a single neuron
6628.08|3.28|and finally we should be able to draw
6629.599|2.801|dot of n of x
6631.36|2.72|and
6632.4|4.319|as you might imagine
6634.08|4.4|these expressions are now getting
6636.719|3.52|relatively involved
6638.48|4.4|so this is an entire mlp that we're
6640.239|2.641|defining now
6645.28|4.0|all the way until a single output
6648.239|2.561|okay
6649.28|3.439|and so obviously you would never
6650.8|4.399|differentiate on pen and paper these
6652.719|4.081|expressions but with micrograd we will
6655.199|2.881|be able to back propagate all the way
6656.8|2.96|through this
6658.08|2.72|and back propagate
6659.76|3.2|into
6660.8|3.839|these weights of all these neurons so
6662.96|3.84|let's see how that works okay so let's
6664.639|4.0|create ourselves a very simple
6666.8|4.24|example data set here
6668.639|4.881|so this data set has four examples
6671.04|4.32|and so we have four possible
6673.52|4.159|inputs into the neural net
6675.36|5.92|and we have four desired targets so we'd
6677.679|6.48|like the neural net to assign
6681.28|4.16|or output 1.0 when it's fed this example
6684.159|2.801|negative one when it's fed these
6685.44|3.52|examples and one when it's fed this
6686.96|3.84|example so it's a very simple binary
6688.96|3.36|classifier neural net basically that we
6690.8|2.879|would like here
6692.32|2.64|now let's think what the neural net
6693.679|2.881|currently thinks about these four
6694.96|2.88|examples we can just get their
6696.56|3.76|predictions
6697.84|4.16|um basically we can just call n of x for
6700.32|3.12|x in axis
6702.0|3.04|and then we can
6703.44|3.199|print
6705.04|3.76|so these are the outputs of the neural
6706.639|3.6|net on those four examples
6708.8|3.919|so
6710.239|5.041|the first one is 0.91 but we'd like it
6712.719|5.281|to be one so we should push this one
6715.28|5.68|higher this one we want to be higher
6718.0|4.639|this one says 0.88 and we want this to
6720.96|3.36|be negative one
6722.639|2.48|this is 0.8 we want it to be negative
6724.32|3.839|one
6725.119|5.12|and this one is 0.8 we want it to be one
6728.159|4.0|so how do we make the neural net and how
6730.239|2.721|do we tune the weights
6732.159|4.56|to
6732.96|5.52|better predict the desired targets
6736.719|3.761|and the trick used in deep learning to
6738.48|3.759|achieve this is to
6740.48|3.92|calculate a single number that somehow
6742.239|3.681|measures the total performance of your
6744.4|3.6|neural net and we call this single
6745.92|3.84|number the loss
6748.0|3.04|so the loss
6749.76|2.8|first
6751.04|3.36|is is a single number that we're going
6752.56|3.679|to define that basically measures how
6754.4|2.96|well the neural net is performing right
6756.239|2.561|now we have the intuitive sense that
6757.36|3.52|it's not performing very well because
6758.8|4.24|we're not very much close to this
6760.88|3.759|so the loss will be high and we'll want
6763.04|3.04|to minimize the loss
6764.639|3.121|so in particular in this case what we're
6766.08|3.599|going to do is we're going to implement
6767.76|3.6|the mean squared error loss
6769.679|4.401|so this is doing is we're going to
6771.36|5.04|basically iterate um
6774.08|5.84|for y ground truth
6776.4|5.279|and y output in zip of um
6779.92|3.199|wise and white red so we're going to
6781.679|4.401|pair up the
6783.119|4.721|ground truths with the predictions
6786.08|2.8|and this zip iterates over tuples of
6787.84|3.68|them
6788.88|4.64|and for each
6791.52|4.719|y ground truth and y output we're going
6793.52|2.719|to subtract them
6796.96|3.279|and square them
6798.56|4.4|so let's first see what these losses are
6800.239|4.96|these are individual loss components
6802.96|3.44|and so basically for each
6805.199|3.281|one of the four
6806.4|4.4|we are taking the prediction and the
6808.48|4.159|ground truth we are subtracting them and
6810.8|3.04|squaring them
6812.639|4.241|so because
6813.84|4.879|this one is so close to its target 0.91
6816.88|3.52|is almost one
6818.719|3.201|subtracting them gives a very small
6820.4|2.96|number
6821.92|3.84|so here we would get like a negative
6823.36|4.239|point one and then squaring it
6825.76|3.839|just makes sure
6827.599|3.921|that regardless of whether we are more
6829.599|3.241|negative or more positive we always get
6831.52|4.0|a positive
6832.84|4.04|number instead of squaring we should we
6835.52|3.92|could also take for example the absolute
6836.88|4.0|value we need to discard the sign
6839.44|4.08|and so you see that the expression is
6840.88|5.52|ranged so that you only get zero exactly
6843.52|4.24|when y out is equal to y ground truth
6846.4|3.199|when those two are equal so your
6847.76|3.2|prediction is exactly the target you are
6849.599|3.281|going to get zero
6850.96|4.08|and if your prediction is not the target
6852.88|4.239|you are going to get some other number
6855.04|4.8|so here for example we are way off and
6857.119|5.441|so that's why the loss is quite high
6859.84|4.24|and the more off we are the greater the
6862.56|4.24|loss will be
6864.08|3.68|so we don't want high loss we want low
6866.8|3.76|loss
6867.76|4.24|and so the final loss here will be just
6870.56|2.72|the sum
6872.0|2.239|of all of these
6873.28|3.04|numbers
6874.239|4.161|so you see that this should be zero
6876.32|3.359|roughly plus zero roughly
6878.4|2.4|but plus
6879.679|3.92|seven
6880.8|4.0|so loss should be about seven
6883.599|3.681|here
6884.8|4.48|and now we want to minimize the loss we
6887.28|4.24|want the loss to be low
6889.28|4.72|because if loss is low
6891.52|4.8|then every one of the predictions is
6894.0|4.88|equal to its target
6896.32|5.2|so the loss the lowest it can be is zero
6898.88|5.2|and the greater it is the worse off the
6901.52|4.079|neural net is predicting
6904.08|3.84|so now of course if we do lost that
6905.599|3.841|backward
6907.92|2.64|something magical happened when i hit
6909.44|2.719|enter
6910.56|3.559|and the magical thing of course that
6912.159|4.401|happened is that we can look at
6914.119|4.681|end.layers.neuron and that layers at say
6916.56|5.44|like the the first layer
6918.8|3.2|that neurons at zero
6922.4|4.08|because remember that mlp has the layers
6924.88|3.2|which is a list
6926.48|3.28|and each layer has a neurons which is a
6928.08|2.639|list and that gives us an individual
6929.76|3.04|neuron
6930.719|3.761|and then it's got some weights
6932.8|4.72|and so we can for example look at the
6934.48|3.04|weights at zero
6938.239|3.841|um
6940.159|4.08|oops it's not called weights it's called
6942.08|4.32|w
6944.239|4.561|and that's a value but now this value
6946.4|3.68|also has a groud because of the backward
6948.8|4.08|pass
6950.08|4.72|and so we see that because this gradient
6952.88|3.359|here on this particular weight of this
6954.8|3.04|particular neuron of this particular
6956.239|3.841|layer is negative
6957.84|4.64|we see that its influence on the loss is
6960.08|4.559|also negative so slightly increasing
6962.48|6.32|this particular weight of this neuron of
6964.639|5.52|this layer would make the loss go down
6968.8|3.6|and we actually have this information
6970.159|3.601|for every single one of our neurons and
6972.4|4.48|all their parameters actually it's worth
6973.76|4.16|looking at also the draw dot loss by the
6976.88|2.799|way
6977.92|3.84|so previously we looked at the draw dot
6979.679|4.081|of a single neural neuron forward pass
6981.76|4.16|and that was already a large expression
6983.76|3.6|but what is this expression we actually
6985.92|3.199|forwarded
6987.36|3.52|every one of those four examples and
6989.119|3.681|then we have the loss on top of them
6990.88|5.279|with the mean squared error
6992.8|5.439|and so this is a really massive graph
6996.159|3.52|because this graph that we've built up
6998.239|3.44|now
6999.679|3.281|oh my gosh this graph that we've built
7001.679|3.04|up now
7002.96|3.44|which is kind of excessive it's
7004.719|3.52|excessive because it has four forward
7006.4|4.239|passes of a neural net for every one of
7008.239|3.201|the examples and then it has the loss on
7010.639|2.401|top
7011.44|3.759|and it ends with the value of the loss
7013.04|3.599|which was 7.12
7015.199|3.761|and this loss will now back propagate
7016.639|4.321|through all the four forward passes all
7018.96|4.159|the way through just every single
7020.96|4.239|intermediate value of the neural net
7023.119|3.681|all the way back to of course the
7025.199|2.721|parameters of the weights which are the
7026.8|3.52|input
7027.92|4.4|so these weight parameters here are
7030.32|2.96|inputs to this neural net
7032.32|2.799|and
7033.28|3.6|these numbers here these scalars are
7035.119|3.761|inputs to the neural net
7036.88|3.759|so if we went around here
7038.88|4.0|we'll probably find
7040.639|4.641|some of these examples this 1.0
7042.88|4.08|potentially maybe this 1.0 or you know
7045.28|3.52|some of the others and you'll see that
7046.96|3.84|they all have gradients as well
7048.8|4.64|the thing is these gradients on the
7050.8|5.28|input data are not that useful to us
7053.44|5.44|and that's because the input data seems
7056.08|4.8|to be not changeable it's it's a given
7058.88|3.279|to the problem and so it's a fixed input
7060.88|2.799|we're not going to be changing it or
7062.159|3.841|messing with it even though we do have
7063.679|5.361|gradients for it
7066.0|4.32|but some of these gradients here
7069.04|4.24|will be for the neural network
7070.32|5.44|parameters the ws and the bs and those
7073.28|4.8|we of course we want to change
7075.76|4.16|okay so now we're going to want some
7078.08|3.599|convenience code to gather up all of the
7079.92|3.44|parameters of the neural net so that we
7081.679|4.081|can operate on all of them
7083.36|5.359|simultaneously and every one of them we
7085.76|4.879|will nudge a tiny amount
7088.719|3.201|based on the gradient information
7090.639|4.161|so let's collect the parameters of the
7091.92|5.92|neural net all in one array
7094.8|4.04|so let's create a parameters of self
7097.84|4.399|that just
7098.84|5.16|returns celta w which is a list
7102.239|4.88|concatenated with
7104.0|5.44|a list of self.b
7107.119|4.241|so this will just return a list
7109.44|2.719|list plus list just you know gives you a
7111.36|3.68|list
7112.159|4.56|so that's parameters of neuron and i'm
7115.04|3.76|calling it this way because also pi
7116.719|3.361|torch has a parameters on every single
7118.8|3.2|and in module
7120.08|3.92|and uh it does exactly what we're doing
7122.0|4.0|here it just returns the
7124.0|4.4|parameter tensors for us as the
7126.0|4.88|parameter scalars
7128.4|4.08|now layer is also a module so it will
7130.88|3.2|have parameters
7132.48|4.239|itself
7134.08|5.599|and basically what we want to do here is
7136.719|2.96|something like this like
7140.239|7.121|params is here and then for
7143.52|7.04|neuron in salt out neurons
7147.36|6.64|we want to get neuron.parameters
7150.56|5.44|and we want to params.extend
7154.0|3.92|right so these are the parameters of
7156.0|5.44|this neuron and then we want to put them
7157.92|4.64|on top of params so params dot extend
7161.44|3.92|of peace
7162.56|5.52|and then we want to return brands
7165.36|6.239|so this is way too much code so actually
7168.08|5.84|there's a way to simplify this which is
7171.599|3.921|return
7173.92|4.08|p
7175.52|4.32|for neuron in self
7178.0|3.36|neurons
7179.84|5.839|for
7181.36|6.0|p in neuron dot parameters
7185.679|3.601|so it's a single list comprehension in
7187.36|4.239|python you can sort of nest them like
7189.28|3.52|this and you can um
7191.599|3.201|then create
7192.8|4.64|uh the desired
7194.8|5.2|array so this is these are identical
7197.44|5.92|we can take this out
7200.0|3.36|and then let's do the same here
7204.639|3.281|def parameters
7206.639|2.801|self
7207.92|5.679|and return
7209.44|5.679|a parameter for layer in self dot layers
7213.599|5.841|for
7215.119|4.321|p in layer dot parameters
7220.96|5.44|and that should be good
7223.679|5.281|now let me pop out this so
7226.4|4.96|we don't re-initialize our network
7228.96|4.8|because we need to re-initialize
7231.36|2.4|our
7235.599|2.961|okay so unfortunately we will have to
7237.28|4.24|probably re-initialize the network
7238.56|4.559|because we just add functionality
7241.52|4.24|because this class of course we i want
7243.119|4.161|to get all the and that parameters but
7245.76|4.08|that's not going to work because this is
7247.28|3.6|the old class
7249.84|2.16|okay
7250.88|2.64|so unfortunately we do have to
7252.0|3.679|reinitialize the network which will
7253.52|3.679|change some of the numbers
7255.679|3.121|but let me do that so that we pick up
7257.199|2.96|the new api we can now do in the
7258.8|4.16|parameters
7260.159|5.601|and these are all the weights and biases
7262.96|8.32|inside the entire neural net
7265.76|5.52|so in total this mlp has 41 parameters
7271.52|4.079|and
7272.88|5.52|now we'll be able to change them
7275.599|4.241|if we recalculate the loss here we see
7278.4|4.0|that unfortunately we have slightly
7279.84|6.16|different
7282.4|3.6|predictions and slightly different laws
7286.56|4.48|but that's okay
7288.56|4.639|okay so we see that this neurons
7291.04|5.44|gradient is slightly negative we can
7293.199|5.281|also look at its data right now
7296.48|4.159|which is 0.85 so this is the current
7298.48|4.639|value of this neuron and this is its
7300.639|4.401|gradient on the loss
7303.119|4.641|so what we want to do now is we want to
7305.04|4.88|iterate for every p in
7307.76|4.08|n dot parameters so for all the 41
7309.92|5.12|parameters in this neural net
7311.84|4.319|we actually want to change p data
7315.04|4.079|slightly
7316.159|4.161|according to the gradient information
7319.119|3.281|okay so
7320.32|4.879|dot dot to do here
7322.4|5.92|but this will be basically a tiny update
7325.199|5.361|in this gradient descent scheme in
7328.32|4.879|gradient descent we are thinking of the
7330.56|3.76|gradient as a vector pointing in the
7333.199|2.161|direction
7334.32|2.48|of
7335.36|3.759|increased
7336.8|3.28|loss
7339.119|3.6|and so
7340.08|4.24|in gradient descent we are modifying
7342.719|3.841|p data
7344.32|4.08|by a small step size in the direction of
7346.56|3.2|the gradient so the step size as an
7348.4|4.4|example could be like a very small
7349.76|5.28|number like 0.01 is the step size times
7352.8|3.6|p dot grad
7355.04|2.72|right
7356.4|2.48|but we have to think through some of the
7357.76|2.56|signs here
7358.88|4.16|so uh
7360.32|4.24|in particular working with this specific
7363.04|4.0|example here
7364.56|4.72|we see that if we just left it like this
7367.04|4.079|then this neuron's value
7369.28|4.16|would be currently increased by a tiny
7371.119|5.201|amount of the gradient
7373.44|4.64|the grain is negative so this value of
7376.32|4.24|this neuron would go slightly down it
7378.08|4.8|would become like 0.8 you know four or
7380.56|5.92|something like that
7382.88|6.0|but if this neuron's value goes lower
7386.48|4.159|that would actually
7388.88|3.6|increase the loss
7390.639|3.6|that's because
7392.48|4.08|the derivative of this neuron is
7394.239|4.96|negative so increasing
7396.56|4.88|this makes the loss go down so
7399.199|4.081|increasing it is what we want to do
7401.44|2.799|instead of decreasing it so basically
7403.28|3.2|what we're missing here is we're
7404.239|4.801|actually missing a negative sign
7406.48|3.84|and again this other interpretation
7409.04|2.8|and that's because we want to minimize
7410.32|3.44|the loss we don't want to maximize the
7411.84|3.12|loss we want to decrease it
7413.76|2.56|and the other interpretation as i
7414.96|2.8|mentioned is you can think of the
7416.32|2.879|gradient vector
7417.76|2.64|so basically just the vector of all the
7419.199|3.52|gradients
7420.4|3.839|as pointing in the direction of
7422.719|3.681|increasing
7424.239|3.201|the loss but then we want to decrease it
7426.4|2.719|so we actually want to go in the
7427.44|2.88|opposite direction
7429.119|2.801|and so you can convince yourself that
7430.32|2.879|this sort of plug does the right thing
7431.92|3.44|here with the negative because we want
7433.199|3.92|to minimize the loss
7435.36|4.4|so if we nudge all the parameters by
7437.119|2.641|tiny amount
7440.639|3.44|then we'll see that
7442.079|4.0|this data will have changed a little bit
7444.079|4.801|so now this neuron
7446.079|7.761|is a tiny amount greater
7448.88|7.199|value so 0.854 went to 0.857
7453.84|4.239|and that's a good thing because slightly
7456.079|2.801|increasing this neuron
7458.079|3.841|uh
7458.88|4.799|data makes the loss go down according to
7461.92|4.239|the gradient and so the correct thing
7463.679|4.241|has happened sign wise
7466.159|2.96|and so now what we would expect of
7467.92|2.319|course is that
7469.119|3.52|because we've changed all these
7470.239|4.88|parameters we expect that the loss
7472.639|4.401|should have gone down a bit
7475.119|4.721|so we want to re-evaluate the loss let
7477.04|2.8|me basically
7479.92|4.96|this is just a data definition that
7481.52|7.04|hasn't changed but the forward pass here
7484.88|3.68|of the network we can recalculate
7489.679|3.201|and actually let me do it outside here
7491.52|2.88|so that we can compare the two loss
7492.88|5.04|values
7494.4|5.12|so here if i recalculate the loss
7497.92|3.52|we'd expect the new loss now to be
7499.52|3.92|slightly lower than this number so
7501.44|5.12|hopefully what we're getting now is a
7503.44|4.719|tiny bit lower than 4.84
7506.56|3.76|4.36
7508.159|4.801|okay and remember the way we've arranged
7510.32|4.799|this is that low loss means that our
7512.96|4.0|predictions are matching the targets so
7515.119|3.721|our predictions now are probably
7516.96|5.279|slightly closer to the
7518.84|5.239|targets and now all we have to do is we
7522.239|4.161|have to iterate this process
7524.079|3.921|so again um we've done the forward pass
7526.4|3.839|and this is the loss
7528.0|4.239|now we can lost that backward
7530.239|4.161|let me take these out and we can do a
7532.239|3.681|step size
7534.4|5.36|and now we should have a slightly lower
7535.92|5.759|loss 4.36 goes to 3.9
7539.76|3.28|and okay so
7541.679|2.641|we've done the forward pass here's the
7543.04|2.639|backward pass
7544.32|5.399|nudge
7545.679|4.04|and now the loss is 3.66
7550.159|4.08|3.47
7552.4|3.92|and you get the idea we just continue
7554.239|4.0|doing this and this is uh gradient
7556.32|4.879|descent we're just iteratively doing
7558.239|4.641|forward pass backward pass update
7561.199|3.121|forward pass backward pass update and
7562.88|2.799|the neural net is improving its
7564.32|5.279|predictions
7565.679|6.48|so here if we look at why pred now
7569.599|2.56|like red
7572.719|3.281|we see that um
7574.56|2.24|this value should be getting closer to
7576.0|1.92|one
7576.8|2.399|so this value should be getting more
7577.92|2.64|positive these should be getting more
7579.199|3.201|negative and this one should be also
7580.56|3.36|getting more positive so if we just
7582.4|4.239|iterate this
7583.92|2.719|a few more times
7586.719|3.52|actually we may be able to afford go to
7588.239|4.801|go a bit faster let's try a slightly
7590.239|2.801|higher learning rate
7594.239|4.321|oops okay there we go so now we're at
7595.92|2.64|0.31
7599.199|4.081|if you go too fast by the way if you try
7601.28|5.12|to make it too big of a step you may
7603.28|3.12|actually overstep
7607.04|3.039|it's overconfidence because again
7608.639|2.96|remember we don't actually know exactly
7610.079|3.6|about the loss function the loss
7611.599|4.08|function has all kinds of structure and
7613.679|3.52|we only know about the very local
7615.679|3.681|dependence of all these parameters on
7617.199|4.321|the loss but if we step too far
7619.36|4.08|we may step into you know a part of the
7621.52|3.28|loss that is completely different
7623.44|4.719|and that can destabilize training and
7624.8|6.24|make your loss actually blow up even
7628.159|5.281|so the loss is now 0.04 so actually the
7631.04|4.079|predictions should be really quite close
7633.44|3.679|let's take a look
7635.119|4.641|so you see how this is almost one
7637.119|4.161|almost negative one almost one we can
7639.76|2.64|continue going
7641.28|2.799|uh so
7642.4|3.279|yep backward
7644.079|4.08|update
7645.679|4.081|oops there we go so we went way too fast
7648.159|3.281|and um
7649.76|4.959|we actually overstepped
7651.44|4.88|so we got two uh too eager where are we
7654.719|2.48|now oops
7656.32|2.879|okay
7657.199|4.321|seven e negative nine so this is very
7659.199|3.92|very low loss
7661.52|4.0|and the predictions
7663.119|4.321|are basically perfect
7665.52|3.36|so somehow we
7667.44|3.12|basically we were doing way too big
7668.88|3.04|updates and we briefly exploded but then
7670.56|4.24|somehow we ended up getting into a
7671.92|4.96|really good spot so usually this
7674.8|3.839|learning rate and the tuning of it is a
7676.88|3.68|subtle art you want to set your learning
7678.639|3.761|rate if it's too low you're going to
7680.56|3.28|take way too long to converge but if
7682.4|3.199|it's too high the whole thing gets
7683.84|3.2|unstable and you might actually even
7685.599|2.881|explode the loss
7687.04|3.76|depending on your loss function
7688.48|4.159|so finding the step size to be just
7690.8|3.279|right it's it's a pretty subtle art
7692.639|3.281|sometimes when you're using sort of
7694.079|3.761|vanilla gradient descent
7695.92|3.6|but we happen to get into a good spot we
7697.84|4.799|can look at
7699.52|5.92|n-dot parameters
7702.639|3.921|so this is the setting of weights and
7705.44|3.679|biases
7706.56|3.599|that makes our network
7709.119|2.721|predict
7710.159|3.601|the desired targets
7711.84|3.759|very very close
7713.76|3.359|and
7715.599|3.201|basically we've successfully trained
7717.119|3.04|neural net
7718.8|2.799|okay let's make this a tiny bit more
7720.159|3.601|respectable and implement an actual
7721.599|3.6|training loop and what that looks like
7723.76|4.16|so this is the data definition that
7725.199|4.241|stays this is the forward pass
7727.92|4.56|um so
7729.44|4.48|for uh k in range you know we're going
7732.48|4.56|to
7733.92|3.12|take a bunch of steps
7737.599|5.441|first you do the forward pass
7740.079|2.961|we validate the loss
7743.679|2.56|let's re-initialize the neural net from
7745.04|3.52|scratch
7746.239|5.041|and here's the data
7748.56|6.2|and we first do before pass then we do
7751.28|3.48|the backward pass
7759.599|4.08|and then we do an update that's gradient
7761.36|2.319|descent
7766.32|2.72|and then we should be able to iterate
7767.52|2.719|this and we should be able to print the
7769.04|4.8|current step
7770.239|4.721|the current loss um let's just print the
7773.84|3.04|sort of
7774.96|3.279|number of the loss
7776.88|3.68|and
7778.239|4.241|that should be it
7780.56|3.84|and then the learning rate 0.01 is a
7782.48|3.759|little too small 0.1 we saw is like a
7784.4|3.52|little bit dangerously too high let's go
7786.239|3.84|somewhere in between
7787.92|4.319|and we'll optimize this for
7790.079|4.481|not 10 steps but let's go for say 20
7792.239|6.4|steps
7794.56|4.079|let me erase all of this junk
7799.119|3.761|and uh let's run the optimization
7803.119|5.281|and you see how we've actually converged
7805.28|6.16|slower in a more controlled manner and
7808.4|4.08|got to a loss that is very low
7811.44|4.32|so
7812.48|5.759|i expect white bread to be quite good
7815.76|2.479|there we go
7819.679|3.44|um
7822.0|2.32|and
7823.119|2.721|that's it
7824.32|3.919|okay so this is kind of embarrassing but
7825.84|5.2|we actually have a really terrible bug
7828.239|4.96|in here and it's a subtle bug and it's a
7831.04|5.28|very common bug and i can't believe i've
7833.199|4.96|done it for the 20th time in my life
7836.32|3.44|especially on camera and i could have
7838.159|3.681|reshot the whole thing but i think it's
7839.76|4.72|pretty funny and you know you get to
7841.84|3.92|appreciate a bit what um working with
7844.48|3.119|neural nets maybe
7845.76|4.479|is like sometimes
7847.599|5.201|we are guilty of
7850.239|4.4|come bug i've actually tweeted
7852.8|3.839|the most common neural net mistakes a
7854.639|3.281|long time ago now
7856.639|2.881|uh and
7857.92|3.759|i'm not really
7859.52|4.24|gonna explain any of these except for we
7861.679|3.201|are guilty of number three you forgot to
7863.76|5.04|zero grad
7864.88|3.92|before that backward what is that
7869.44|2.56|basically what's happening and it's a
7870.719|2.081|subtle bug and i'm not sure if you saw
7872.0|2.4|it
7872.8|2.879|is that
7874.4|3.36|all of these
7875.679|3.601|weights here have a dot data and a dot
7877.76|4.959|grad
7879.28|5.04|and that grad starts at zero
7882.719|3.201|and then we do backward and we fill in
7884.32|3.44|the gradients
7885.92|3.84|and then we do an update on the data but
7887.76|3.839|we don't flush the grad
7889.76|3.68|it stays there
7891.599|3.841|so when we do the second
7893.44|3.44|forward pass and we do backward again
7895.44|4.0|remember that all the backward
7896.88|4.4|operations do a plus equals on the grad
7899.44|5.44|and so these gradients just
7901.28|6.24|add up and they never get reset to zero
7904.88|5.199|so basically we didn't zero grad so
7907.52|3.599|here's how we zero grad before
7910.079|2.08|backward
7911.119|3.04|we need to iterate over all the
7912.159|4.241|parameters
7914.159|4.48|and we need to make sure that p dot grad
7916.4|4.48|is set to zero
7918.639|4.08|we need to reset it to zero just like it
7920.88|3.52|is in the constructor
7922.719|4.641|so remember all the way here for all
7924.4|4.88|these value nodes grad is reset to zero
7927.36|3.92|and then all these backward passes do a
7929.28|4.08|plus equals from that grad
7931.28|4.64|but we need to make sure that
7933.36|4.0|we reset these graphs to zero so that
7935.92|2.96|when we do backward
7937.36|4.56|all of them start at zero and the actual
7938.88|6.719|backward pass accumulates um
7941.92|6.96|the loss derivatives into the grads
7945.599|4.56|so this is zero grad in pytorch
7948.88|2.719|and uh
7950.159|3.121|we will slightly get we'll get a
7951.599|3.281|slightly different optimization let's
7953.28|4.0|reset the neural net
7954.88|3.6|the data is the same this is now i think
7957.28|2.72|correct
7958.48|3.92|and we get a much more
7960.0|4.079|you know we get a much more
7962.4|3.839|slower descent
7964.079|4.481|we still end up with pretty good results
7966.239|4.0|and we can continue this a bit more
7968.56|2.8|to get down lower
7970.239|3.521|and lower
7971.36|2.4|and lower
7974.159|3.281|yeah
7976.239|3.521|so the only reason that the previous
7977.44|5.759|thing worked it's extremely buggy um the
7979.76|6.0|only reason that worked is that
7983.199|4.561|this is a very very simple problem
7985.76|3.6|and it's very easy for this neural net
7987.76|4.319|to fit this data
7989.36|4.4|and so the grads ended up accumulating
7992.079|4.0|and it effectively gave us a massive
7993.76|5.2|step size and it made us converge
7996.079|2.881|extremely fast
7999.36|4.96|but basically now we have to do more
8000.88|5.839|steps to get to very low values of loss
8004.32|3.6|and get wipe red to be really good we
8006.719|5.0|can try to
8007.92|3.799|step a bit greater
8014.32|4.16|yeah we're gonna get closer and closer
8016.079|3.761|to one minus one and one
8018.48|3.119|so
8019.84|3.44|working with neural nets is sometimes
8021.599|3.361|tricky because
8023.28|3.76|uh
8024.96|4.88|you may have lots of bugs in the code
8027.04|4.24|and uh your network might actually work
8029.84|3.44|just like ours worked
8031.28|4.399|but chances are is that if we had a more
8033.28|4.24|complex problem then actually this bug
8035.679|3.44|would have made us not optimize the loss
8037.52|4.079|very well and we were only able to get
8039.119|4.241|away with it because
8041.599|3.361|the problem is very simple
8043.36|3.52|so let's now bring everything together
8044.96|4.159|and summarize what we learned
8046.88|4.56|what are neural nets neural nets are
8049.119|3.921|these mathematical expressions
8051.44|4.08|fairly simple mathematical expressions
8053.04|3.52|in the case of multi-layer perceptron
8055.52|3.76|that take
8056.56|4.159|input as the data and they take input
8059.28|3.52|the weights and the parameters of the
8060.719|4.121|neural net mathematical expression for
8062.8|4.16|the forward pass followed by a loss
8064.84|4.52|function and the loss function tries to
8066.96|4.719|measure the accuracy of the predictions
8069.36|3.6|and usually the loss will be low when
8071.679|2.801|your predictions are matching your
8072.96|4.32|targets or where the network is
8074.48|4.32|basically behaving well so we we
8077.28|3.439|manipulate the loss function so that
8078.8|3.6|when the loss is low the network is
8080.719|3.281|doing what you want it to do on your
8082.4|4.08|problem
8084.0|4.8|and then we backward the loss
8086.48|3.52|use backpropagation to get the gradient
8088.8|4.0|and then we know how to tune all the
8090.0|4.239|parameters to decrease the loss locally
8092.8|2.879|but then we have to iterate that process
8094.239|2.48|many times in what's called the gradient
8095.679|2.641|descent
8096.719|4.321|so we simply follow the gradient
8098.32|4.0|information and that minimizes the loss
8101.04|3.28|and the loss is arranged so that when
8102.32|4.52|the loss is minimized the network is
8104.32|4.879|doing what you want it to do
8106.84|4.52|and yeah so we just have a blob of
8109.199|4.081|neural stuff and we can make it do
8111.36|3.839|arbitrary things and that's what gives
8113.28|3.439|neural nets their power um
8115.199|3.92|it's you know this is a very tiny
8116.719|4.081|network with 41 parameters
8119.119|4.96|but you can build significantly more
8120.8|4.56|complicated neural nets with billions
8124.079|4.0|at this point almost trillions of
8125.36|5.759|parameters and it's a massive blob of
8128.079|4.481|neural tissue simulated neural tissue
8131.119|3.841|roughly speaking
8132.56|4.8|and you can make it do extremely complex
8134.96|4.08|problems and these neurons then have all
8137.36|2.799|kinds of very fascinating emergent
8139.04|2.48|properties
8140.159|3.281|in
8141.52|4.159|when you try to make them do
8143.44|4.239|significantly hard problems as in the
8145.679|4.161|case of gpt for example
8147.679|3.601|we have massive amounts of text from the
8149.84|3.6|internet and we're trying to get a
8151.28|3.919|neural net to predict to take like a few
8153.44|3.199|words and try to predict the next word
8155.199|2.4|in a sequence that's the learning
8156.639|2.08|problem
8157.599|3.201|and it turns out that when you train
8158.719|3.761|this on all of internet the neural net
8160.8|3.68|actually has like really remarkable
8162.48|3.28|emergent properties but that neural net
8164.48|2.96|would have hundreds of billions of
8165.76|3.6|parameters
8167.44|3.12|but it works on fundamentally the exact
8169.36|2.799|same principles
8170.56|4.559|the neural net of course will be a bit
8172.159|5.361|more complex but otherwise the
8175.119|4.321|value in the gradient is there
8177.52|3.52|and would be identical and the gradient
8179.44|3.679|descent would be there and would be
8181.04|4.079|basically identical but people usually
8183.119|4.08|use slightly different updates this is a
8185.119|3.361|very simple stochastic gradient descent
8187.199|2.241|update
8188.48|2.159|um
8189.44|2.56|and the loss function would not be mean
8190.639|3.361|squared error they would be using
8192.0|4.0|something called the cross-entropy loss
8194.0|3.679|for predicting the next token so there's
8196.0|3.04|a few more details but fundamentally the
8197.679|4.481|neural network setup and neural network
8199.04|5.2|training is identical and pervasive and
8202.16|3.84|now you understand intuitively
8204.24|3.199|how that works under the hood in the
8206.0|2.8|beginning of this video i told you that
8207.439|3.28|by the end of it you would understand
8208.8|3.839|everything in micrograd and then we'd
8210.719|3.281|slowly build it up let me briefly prove
8212.639|2.481|that to you
8214.0|3.519|so i'm going to step through all the
8215.12|3.92|code that is in micrograd as of today
8217.519|2.8|actually potentially some of the code
8219.04|2.72|will change by the time you watch this
8220.319|3.12|video because i intend to continue
8221.76|3.28|developing micrograd
8223.439|4.321|but let's look at what we have so far at
8225.04|5.04|least init.pi is empty when you go to
8227.76|3.44|engine.pi that has the value
8230.08|3.519|everything here you should mostly
8231.2|4.72|recognize so we have the data.grad
8233.599|3.84|attributes we have the backward function
8235.92|3.679|uh we have the previous set of children
8237.439|3.361|and the operation that produced this
8239.599|2.88|value
8240.8|4.4|we have addition multiplication and
8242.479|4.561|raising to a scalar power
8245.2|3.279|we have the relu non-linearity which is
8247.04|3.84|slightly different type of nonlinearity
8248.479|4.24|than 10h that we used in this video
8250.88|3.759|both of them are non-linearities and
8252.719|4.321|notably 10h is not actually present in
8254.639|4.0|micrograd as of right now but i intend
8257.04|3.679|to add it later
8258.639|4.241|with the backward which is identical and
8260.719|4.72|then all of these other operations which
8262.88|4.32|are built up on top of operations here
8265.439|3.12|so values should be very recognizable
8267.2|2.88|except for the non-linearity used in
8268.559|3.601|this video
8270.08|4.08|um there's no massive difference between
8272.16|3.76|relu and 10h and sigmoid and these other
8274.16|4.159|non-linearities they're all roughly
8275.92|4.479|equivalent and can be used in mlps so i
8278.319|2.961|use 10h because it's a bit smoother and
8280.399|2.881|because it's a little bit more
8281.28|4.64|complicated than relu and therefore it's
8283.28|4.399|stressed a little bit more the
8285.92|3.12|local gradients and working with those
8287.679|3.04|derivatives which i thought would be
8289.04|3.279|useful
8290.719|3.521|and then that pi is the neural networks
8292.319|3.841|library as i mentioned so you should
8294.24|4.0|recognize identical implementation of
8296.16|4.479|neuron layer and mlp
8298.24|3.92|notably or not so much
8300.639|3.84|we have a class module here there is a
8302.16|4.96|parent class of all these modules i did
8304.479|4.641|that because there's an nn.module class
8307.12|4.559|in pytorch and so this exactly matches
8309.12|4.559|that api and end.module and pytorch has
8311.679|4.561|also a zero grad which i've refactored
8313.679|2.561|out here
8316.319|3.681|so that's the end of micrograd really
8318.479|2.96|then there's a test
8320.0|2.96|which you'll see
8321.439|4.16|basically creates
8322.96|4.639|two chunks of code one in micrograd and
8325.599|3.681|one in pi torch and we'll make sure that
8327.599|2.8|the forward and the backward pass agree
8329.28|2.64|identically
8330.399|2.96|for a slightly less complicated
8331.92|3.439|expression a slightly more complicated
8333.359|4.0|expression everything
8335.359|3.601|agrees so we agree with pytorch on all
8337.359|4.32|of these operations
8338.96|4.24|and finally there's a demo.ipymb here
8341.679|2.88|and it's a bit more complicated binary
8343.2|3.84|classification demo than the one i
8344.559|5.361|covered in this lecture so we only had a
8347.04|4.639|tiny data set of four examples um here
8349.92|3.759|we have a bit more complicated example
8351.679|3.92|with lots of blue points and lots of red
8353.679|4.321|points and we're trying to again build a
8355.599|4.88|binary classifier to distinguish uh two
8358.0|4.319|dimensional points as red or blue
8360.479|4.24|it's a bit more complicated mlp here
8362.319|3.841|with it's a bigger mlp
8364.719|2.401|the loss is a bit more complicated
8366.16|3.04|because
8367.12|4.08|it supports batches
8369.2|3.6|so because our dataset was so tiny we
8371.2|4.0|always did a forward pass on the entire
8372.8|4.559|data set of four examples but when your
8375.2|4.64|data set is like a million examples what
8377.359|4.481|we usually do in practice is we chair we
8379.84|3.92|basically pick out some random subset we
8381.84|4.08|call that a batch and then we only
8383.76|3.839|process the batch forward backward and
8385.92|3.92|update so we don't have to forward the
8387.599|3.601|entire training set
8389.84|3.68|so this supports batching because
8391.2|4.48|there's a lot more examples here
8393.52|4.08|we do a forward pass the loss is
8395.68|4.32|slightly more different this is a max
8397.6|4.16|margin loss that i implement here
8400.0|3.2|the one that we used was the mean
8401.76|2.88|squared error loss because it's the
8403.2|3.119|simplest one
8404.64|3.44|there's also the binary cross entropy
8406.319|3.841|loss all of them can be used for binary
8408.08|3.52|classification and don't make too much
8410.16|3.36|of a difference in the simple examples
8411.6|3.2|that we looked at so far
8413.52|3.919|there's something called l2
8414.8|4.559|regularization used here this has to do
8417.439|4.401|with generalization of the neural net
8419.359|4.0|and controls the overfitting in machine
8421.84|3.04|learning setting but i did not cover
8423.359|3.521|these concepts and concepts in this
8424.88|3.04|video potentially later
8426.88|4.16|and the training loop you should
8427.92|4.399|recognize so forward backward with zero
8431.04|4.16|grad
8432.319|4.561|and update and so on you'll notice that
8435.2|3.44|in the update here the learning rate is
8436.88|3.68|scaled as a function of number of
8438.64|3.12|iterations and it
8440.56|2.48|shrinks
8441.76|3.04|and this is something called learning
8443.04|4.0|rate decay so in the beginning you have
8444.8|4.559|a high learning rate and as the network
8447.04|3.68|sort of stabilizes near the end you
8449.359|3.761|bring down the learning rate to get some
8450.72|4.16|of the fine details in the end
8453.12|3.52|and in the end we see the decision
8454.88|3.68|surface of the neural net and we see
8456.64|3.92|that it learns to separate out the red
8458.56|3.36|and the blue area based on the data
8460.56|2.799|points
8461.92|3.439|so that's the slightly more complicated
8463.359|4.161|example and then we'll demo that hyper
8465.359|4.881|ymb that you're free to go over
8467.52|3.919|but yeah as of today that is micrograd i
8470.24|2.96|also wanted to show you a little bit of
8471.439|2.96|real stuff so that you get to see how
8473.2|3.44|this is actually implemented in
8474.399|4.08|production grade library like by torch
8476.64|4.0|uh so in particular i wanted to show i
8478.479|5.121|wanted to find and show you the backward
8480.64|4.56|pass for 10h in pytorch so here in
8483.6|4.879|micrograd we see that the backward
8485.2|7.84|password 10h is one minus t square
8488.479|4.561|where t is the output of the tanh of x
8493.2|3.279|times of that grad which is the chain
8494.88|3.2|rule so we're looking for something that
8496.479|2.641|looks like this
8498.08|4.48|now
8499.12|6.0|i went to pytorch um which has an open
8502.56|4.48|source github codebase and uh i looked
8505.12|4.4|through a lot of its code
8507.04|4.88|and honestly i i i spent about 15
8509.52|3.76|minutes and i couldn't find 10h
8511.92|3.2|and that's because these libraries
8513.28|4.64|unfortunately they grow in size and
8515.12|5.92|entropy and if you just search for 10h
8517.92|6.08|you get apparently 2 800 results and 400
8521.04|6.72|and 406 files so i don't know what these
8524.0|5.04|files are doing honestly
8527.76|3.44|and why there are so many mentions of
8529.04|3.52|10h but unfortunately these libraries
8531.2|4.4|are quite complex they're meant to be
8532.56|5.839|used not really inspected um
8535.6|5.52|eventually i did stumble on someone
8538.399|4.241|who tries to change the 10 h backward
8541.12|3.199|code for some reason
8542.64|3.679|and someone here pointed to the cpu
8544.319|3.441|kernel and the kuda kernel for 10 inch
8546.319|3.201|backward
8547.76|3.84|so this so basically depends on if
8549.52|3.76|you're using pi torch on a cpu device or
8551.6|3.6|on a gpu which these are different
8553.28|4.48|devices and i haven't covered this but
8555.2|4.8|this is the 10 h backwards kernel
8557.76|6.16|for uh cpu
8560.0|5.439|and the reason it's so large is that
8563.92|3.04|number one this is like if you're using
8565.439|3.281|a complex type which we haven't even
8566.96|3.76|talked about if you're using a specific
8568.72|3.84|data type of b-float 16 which we haven't
8570.72|4.24|talked about
8572.56|4.799|and then if you're not then this is the
8574.96|5.12|kernel and deep here we see something
8577.359|4.881|that resembles our backward pass so they
8580.08|5.279|have a times one minus
8582.24|5.36|b square uh so this b
8585.359|4.881|b here must be the output of the 10h and
8587.6|3.44|this is the health.grad so here we found
8590.24|3.84|it
8591.04|4.64|uh deep inside
8594.08|4.48|pi torch from this location for some
8595.68|5.52|reason inside binaryops kernel when 10h
8598.56|6.32|is not actually a binary op
8601.2|3.68|and then this is the gpu kernel
8605.04|2.48|we're not complex
8606.64|2.88|we're
8607.52|3.12|here and here we go with one line of
8609.52|3.919|code
8610.64|4.16|so we did find it but basically
8613.439|2.801|unfortunately these codepieces are very
8614.8|3.76|large and
8616.24|4.159|micrograd is very very simple but if you
8618.56|3.36|actually want to use real stuff uh
8620.399|3.521|finding the code for it you'll actually
8621.92|3.92|find that difficult
8623.92|3.84|i also wanted to show you a little
8625.84|3.84|example here where pytorch is showing
8627.76|3.36|you how can you can register a new type
8629.68|3.92|of function that you want to add to
8631.12|4.72|pytorch as a lego building block
8633.6|5.759|so here if you want to for example add a
8635.84|4.8|gender polynomial 3
8639.359|4.241|here's how you could do it you will
8640.64|5.679|register it as a class that
8643.6|4.24|subclasses storage.org that function
8646.319|4.481|and then you have to tell pytorch how to
8647.84|4.8|forward your new function
8650.8|3.28|and how to backward through it
8652.64|2.88|so as long as you can do the forward
8654.08|3.04|pass of this little function piece that
8655.52|3.52|you want to add and as long as you know
8657.12|3.44|the the local derivative the local
8659.04|3.68|gradients which are implemented in the
8660.56|3.839|backward pi torch will be able to back
8662.72|3.679|propagate through your function and then
8664.399|4.0|you can use this as a lego block in a
8666.399|4.641|larger lego castle of all the different
8668.399|3.92|lego blocks that pytorch already has
8671.04|2.64|and so that's the only thing you have to
8672.319|3.441|tell pytorch and everything would just
8673.68|3.12|work and you can register new types of
8675.76|3.2|functions
8676.8|3.28|in this way following this example
8678.96|2.72|and that is everything that i wanted to
8680.08|2.72|cover in this lecture
8681.68|2.719|so i hope you enjoyed building out
8682.8|3.599|micrograd with me i hope you find it
8684.399|3.521|interesting insightful
8686.399|3.681|and
8687.92|3.76|yeah i will post a lot of the links
8690.08|3.84|that are related to this video in the
8691.68|4.0|video description below i will also
8693.92|2.559|probably post a link to a discussion
8695.68|2.48|forum
8696.479|3.92|or discussion group where you can ask
8698.16|4.08|questions related to this video and then
8700.399|4.0|i can answer or someone else can answer
8702.24|3.84|your questions and i may also do a
8704.399|4.08|follow-up video that answers some of the
8706.08|4.319|most common questions
8708.479|3.441|but for now that's it i hope you enjoyed
8710.399|3.201|it if you did then please like and
8711.92|3.6|subscribe so that youtube knows to
8713.6|5.759|feature this video to more people
8715.52|3.839|and that's it for now i'll see you later
8722.399|3.281|now here's the problem
8724.64|3.92|we know
8725.68|5.84|dl by
8728.56|2.96|wait what is the problem
8731.92|2.32|and that's everything i wanted to cover
8733.12|2.72|in this lecture
8734.24|4.239|so i hope
8735.84|5.28|you enjoyed us building up microcraft
8738.479|2.641|micro crab
8742.0|2.8|okay now let's do the exact same thing
8743.359|4.481|for multiply because we can't do
8744.8|5.44|something like a times two
8747.84|2.4|oops
8750.8|2.88|i know what happened there