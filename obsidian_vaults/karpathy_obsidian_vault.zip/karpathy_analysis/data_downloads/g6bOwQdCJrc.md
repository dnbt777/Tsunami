start_time|end_time|text
4.16|2.56|uh yes i'm very excited to be here thank
5.759|3.041|you for the introduction
6.72|3.52|um i would like to talk a bit more about
8.8|2.4|what tesla has been up for the last few
10.24|4.08|months
11.2|4.96|um so first to start uh
14.32|3.28|i guess we are here at the cvpr uh
16.16|2.879|workshop on autonomous driving so i
17.6|1.839|think i'm preaching to the core a little
19.039|1.441|bit
19.439|2.481|uh but i'd like to start with some
20.48|2.48|slides on like why we're doing all of
21.92|2.32|this and i think
22.96|2.479|unfortunately we're kind of like in a
24.24|2.879|bad shape when it comes to
25.439|3.441|transportation in society
27.119|3.681|and uh basically the issue is that we
28.88|4.48|have these metallic objects traveling
30.8|4.4|incredibly quickly and with very high
33.36|4.0|kinetic energy and we are putting meat
35.2|4.08|in the control loop in the into the
37.36|3.12|system and so this is quite undesirable
39.28|2.08|and really fundamentally what it comes
40.48|2.32|down to is
41.36|3.92|people are not very good at driving they
42.8|5.599|get into a lot of trouble in accidents
45.28|5.119|they don't want to drive and also
48.399|3.521|in terms of economics we are involving
50.399|2.881|people in transportation and of course
51.92|2.0|we'd like to automate transportation and
53.28|2.08|really
53.92|4.159|reap the benefits of that automation in
55.36|4.16|society so we all i think are on the
58.079|2.0|same page that it should be possible to
59.52|1.76|replace
60.079|3.521|the meat computer with a silicon
61.28|3.919|computer and get a lot of benefits out
63.6|4.4|of it in terms of um
65.199|4.641|safety and convenience and economics so
68.0|3.439|in particular uh silicon computers have
69.84|3.76|significantly lower latencies
71.439|3.04|they have 360 degree situational
73.6|2.48|awareness
74.479|3.761|they are fully attentive and never check
76.08|3.359|their instagram and uh
78.24|3.12|alleviate all of the issues that are
79.439|3.761|presented and so i think
81.36|3.04|uh this is not super shocking and a lot
83.2|2.64|of people have been
84.4|3.2|kind of really looking forward to this
85.84|2.639|kind of feature this is a frame from
87.6|2.479|irobot
88.479|3.841|uh a really good movie if you haven't
90.079|3.04|seen it and here will smith is about to
92.32|2.96|drive a car
93.119|3.601|manually and uh this other person here
95.28|2.72|is shocked that this is going to happen
96.72|2.88|this is ridiculous like why would you
98.0|4.0|actually have a human driving cars
99.6|3.04|um and so i think this is uh not very
102.0|2.399|far from
102.64|4.159|truth and this movie is taking place in
104.399|4.481|2035 uh so i think by then
106.799|3.6|um i actually think this is a pretty uh
108.88|2.8|present prediction
110.399|4.4|uh so what i think is kind of unique
111.68|3.92|about tesla and uh in our approach to
114.799|2.241|autonomy
115.6|3.199|is that we take a very incremental
117.04|3.119|approach towards this problem so in
118.799|2.64|particular we already have customers
120.159|3.521|with the autopilot package
121.439|4.0|and we have millions of cars and uh the
123.68|3.2|r the our pilot software is always
125.439|2.88|running and providing active safety
126.88|2.48|features and of course the autopilot
128.319|3.041|functionality
129.36|3.84|so we provide additional safety and
131.36|3.2|convenience to our customers today
133.2|3.759|and also the team is working on full
134.56|4.56|self-driving ability
136.959|3.201|so i would briefly like to very quickly
139.12|2.4|speak to
140.16|2.64|the valley day that we provide just to
141.52|2.32|give you some examples of what the team
142.8|3.36|is up to and we're
143.84|4.24|uh sort of doing today uh so here's an
146.16|3.68|automatic emergency braking scenario
148.08|3.28|uh so the driver here is proceeding
149.84|2.64|through an intersection and you can see
151.36|4.08|trouble coming here
152.48|4.0|um so the person kind of crept out from
155.44|3.2|here and the
156.48|4.0|car sees the pedestrian object detection
158.64|4.16|kicks in and we slam on the brakes
160.48|4.08|and we avert collision here's an example
162.8|3.36|of a traffic control warning so this
164.56|2.8|person is probably not paying attention
166.16|2.799|potentially on the phone
167.36|3.599|is not braking for the traffic lights
168.959|3.28|ahead but we see that these are relevant
170.959|2.801|traffic lights they are red
172.239|3.36|and we beep and the person immediately
173.76|3.839|starts slowing and probably
175.599|3.041|uh you know does not actually enter the
177.599|3.521|intersection
178.64|3.76|uh these are examples from uh pedal
181.12|3.52|misapplication
182.4|4.24|mitigation pmm here a person is
184.64|3.679|unparking from their driving spot
186.64|3.44|and they are trying to turn and then
188.319|3.84|they mess up and they accidentally floor
190.08|3.6|it
192.159|3.041|so they floor it right there and the
193.68|2.4|system kicks in it sees pedestrians
195.2|3.119|ahead of us and it
196.08|3.92|slams on the brakes and inverts uh what
198.319|2.481|would be a very gnarly situation in this
200.0|3.28|case
200.8|3.359|um here's another last scenario i can
203.28|3.44|show briefly
204.159|4.08|so this person is trying to park uh and
206.72|3.36|they turn to the right here
208.239|3.841|and they intend to press the brake but
210.08|3.36|they actually floor it and uh
212.08|3.12|the system again sees that there's no
213.44|2.96|driving path forward and actually slams
215.2|2.88|and breaks and inverts
216.4|3.119|you know in this case this person is not
218.08|3.519|going to be swimming in this river
219.519|3.601|imminently uh so these are some examples
221.599|1.92|of the value that we are providing today
223.12|2.56|in this
223.519|4.321|incremental autonomy fashion but of
225.68|6.4|course the team is actually
227.84|6.0|tonight sorry about that the team is
232.08|3.2|working primarily on the fsd
233.84|3.92|functionality which is
235.28|3.2|our wholesale driving suite so here we
237.76|2.8|have about
238.48|3.92|fs we have the fsd beta product and it's
240.56|3.36|in the hands of about 2 000 customers
242.4|3.68|and this is an example from one of the
243.92|4.16|customers driving around san francisco
246.08|3.28|and uh these people are posting videos
248.08|2.799|on youtube so you can check out a lot of
249.36|2.64|videos but what we're showing here on
250.879|2.56|the instrument cluster
252.0|3.36|is we're showing all of our predictions
253.439|2.64|so you're seeing some road edges uh some
255.36|3.279|lines
256.079|4.0|some objects um and the car of course is
258.639|4.401|navigating around autonomously here in
260.079|2.961|san francisco environment
263.28|3.28|now we of course drive this extensively
265.36|2.88|as engineers
266.56|3.199|and uh so it's actually fairly routine
268.24|3.04|for us to have zero intervention drives
269.759|3.201|i would say in like sparsely populated
271.28|3.68|areas like palo alto and so on i would
272.96|3.76|say we definitely struggle a lot more in
274.96|3.519|uh very adversarial environments like
276.72|3.6|san francisco a lot of people
278.479|3.28|working in autonomy of course know all
280.32|3.2|about that as well
281.759|4.0|so this drive ends up being a fairly
283.52|6.0|long drive and it's zero interventions
285.759|5.041|in this case now one thing i'd like to
289.52|2.48|point out always whenever i showed the
290.8|1.92|video of tesla driving around
292.0|3.6|autonomously
292.72|4.24|in these city environments is you've
295.6|2.48|seen this before and you've seen it for
296.96|3.2|a decade uh so
298.08|3.6|or more so here's a waymo taking a left
300.16|3.12|at an intersection
301.68|3.359|and uh this is actually a pretty old
303.28|2.8|video i believe and so you've been
305.039|2.401|seeing stuff like this
306.08|3.679|for a very long time so what is the big
307.44|2.56|deal why is this impressive and so on
309.759|1.521|and
310.0|2.88|i think the important thing to realize
311.28|3.359|and that i like to always stress is that
312.88|3.28|even though these two scenarios look the
314.639|2.56|same so there's a car taking a left at
316.16|2.72|an intersection
317.199|3.28|under the hood and in terms of the
318.88|2.96|scalability of the system things are
320.479|3.28|incredibly different
321.84|3.199|so in particular a lot of the uh
323.759|3.28|competing approaches in the
325.039|3.201|in the industry uh take this lidar plus
327.039|2.72|hd map approach
328.24|3.36|and so the idea is that you take an
329.759|2.641|expensive sensor or lidar on the top of
331.6|2.72|the car
332.4|3.28|and um it basically gives you
334.32|2.879|rangefinding around
335.68|3.04|around the vehicle in 360 and gives you
337.199|3.041|point cloud and what you have to do is
338.72|3.6|you have to pre-map the environment
340.24|3.519|uh with the lidar sensor and you have to
342.32|3.04|create a high-definition map
343.759|3.041|and then you have to insert all of the
345.36|2.72|lanes and how they connect and all the
346.8|2.239|traffic lights and where they are and
348.08|1.839|you basically have to create a high
349.039|2.241|definition map
349.919|4.081|and then a test time you are simply
351.28|5.12|localizing to that map to drive around
354.0|3.759|and so the approach we take is vision
356.4|3.359|based primarily
357.759|3.521|so everything that happens uh happens
359.759|3.121|for the first time there in the car
361.28|3.44|based on the videos from the eight
362.88|3.28|cameras that surround the car
364.72|2.56|and so we come to an intersection for
366.16|2.4|the very first time and we have to
367.28|2.4|figure out where are the lanes how do
368.56|2.56|they connect where are the traffic
369.68|2.959|lights which ones are relevant
371.12|3.04|what what traffic lights control what
372.639|2.161|lanes everything is happening at that
374.16|2.72|time
374.8|3.6|um on that car and we don't have too
376.88|2.4|much high definition sort of information
378.4|2.72|at all
379.28|3.52|and this is actually a significantly
381.12|3.84|more scalable approach because
382.8|3.2|if our product is on a scale of millions
384.96|2.959|of customers
386.0|4.4|on earth and so it's actually quite
387.919|4.56|unscalable to uh to actually
390.4|3.68|collect build and maintain these high
392.479|3.28|definition lidar maps
394.08|3.679|um it would be incredibly expensive to
395.759|3.761|keep this infrastructure up to date
397.759|3.28|and so we take the vision-based approach
399.52|2.799|which of course is much more difficult
401.039|3.44|because you actually have to get to
402.319|4.801|get neural networks that uh function
404.479|4.0|incredibly well based on the videos
407.12|3.359|but once you actually get that to work
408.479|2.641|it's a general vision system and can in
410.479|3.041|principle
411.12|3.6|be deployed anywhere on earth so that's
413.52|2.48|really the the problem that we are
414.72|3.44|solving
416.0|4.0|now in terms of the cartoon diagram of a
418.16|3.439|typical sensing suite of an autonomous
420.0|2.639|vehicle
421.599|2.72|these are kind of like the typical
422.639|2.56|sensors you would see and as i mentioned
424.319|2.401|we do not use
425.199|3.201|high definition maps and we do not use
426.72|5.759|lidar we only use
428.4|5.519|video cameras and in fact the
432.479|3.201|vision system that we have been building
433.919|3.84|over the last few years has been getting
435.68|3.519|so incredibly good that it's kind of
437.759|2.481|leaving a lot of the other sensors in
439.199|4.321|the dust
440.24|4.56|and so actually um the
443.52|2.799|cameras are doing most of the heavy
444.8|2.72|lifting in terms of the perception that
446.319|2.32|you've seen in the car
447.52|2.56|and actually it's gotten to the point
448.639|3.28|that we are able to start removing some
450.08|3.2|of the other sensors because they are
451.919|3.28|just becoming these crushes that you
453.28|3.28|start to not really need at all
455.199|3.761|so actually three weeks ago we started
456.56|4.56|to ship cars that have no radar at all
458.96|3.84|so we've deleted the radar and we are
461.12|3.759|driving on vision alone
462.8|3.04|in these cars and the reason we are
464.879|3.121|doing this i think is
465.84|4.0|well expressed by elon in the suite he's
468.0|2.96|saying uh when radar and vision disagree
469.84|2.72|which one do you believe
470.96|3.12|uh vision has much more precision so
472.56|2.8|better to double down vision than do
474.08|2.88|sensor fusion
475.36|2.8|and what he's referring to is basically
476.96|1.84|like vision is getting to the point
478.16|3.439|where
478.8|3.679|the sensor is like 100 x better than say
481.599|2.401|radar
482.479|3.44|then if you have a sensor that is
484.0|3.28|dominating the other sensor and so much
485.919|2.641|better then the other sensor is actually
487.28|2.4|starting to like really contribute it's
488.56|2.4|actually holding me back
489.68|3.359|and it's really starting to attribute
490.96|4.56|noise to the former system
493.039|3.761|and so we are really doubling down on
495.52|3.6|the vision only approach
496.8|3.76|and actually in this talk what i would
499.12|2.32|like to primarily talk about is how we
500.56|2.96|have achieved
501.44|3.599|vision only control without radar and
503.52|3.84|how we have released this
505.039|3.84|quite successfully so far to defeat and
507.36|4.64|what it has sort of um
508.879|5.761|taken for us to for us to do that so
512.0|4.08|here i wanted to show a video um
514.64|2.959|basically showing what the input of the
516.08|2.319|system is so we have eight cameras
517.599|2.481|around
518.399|4.08|and these are fairly high definition
520.08|3.6|cameras and we have 36 frames a second
522.479|2.8|and you can see that basically you can
523.68|2.96|actually understand a lot about this
525.279|3.601|environment from this input
526.64|3.6|it's extremely information rich you're
528.88|2.56|getting a huge amount of constraints
530.24|3.36|eight million bits roughly of
531.44|3.28|constraints per second on the state of
533.6|2.88|the surroundings
534.72|3.119|and so it's incredibly information rich
536.48|2.32|compared to any other sensor you may
537.839|1.841|want to have in the car
538.8|2.159|and so this is the one that we're
539.68|2.719|doubling down on because this is
540.959|3.361|ultimately where all the
542.399|3.44|difficult um sort of scene
544.32|3.84|interpretation challenges lie
545.839|3.921|so we prefer to just focus all of our
548.16|2.96|infrastructure and development on this
549.76|3.12|and we're not wasting people working on
551.12|2.32|the radar stack and the sensor fusion
552.88|4.0|stack
553.44|4.959|we only have one team division team um
556.88|3.04|now typically when we talk about vision
558.399|2.481|the reason people are squeamish about
559.92|3.12|using vision
560.88|3.92|is and the sort of challenge that almost
563.04|4.56|always is pointed out is people are not
564.8|3.2|certain if um neural networks are able
567.6|2.799|to
568.0|3.76|uh do rangefinding or depth estimation
570.399|2.961|of these objects
571.76|3.68|so obviously humans drive around with
573.36|2.64|vision so obviously where our neural net
575.44|2.16|is able to
576.0|2.8|process visual input to understand the
577.6|1.84|depth and velocity of all the objects
578.8|2.159|around us
579.44|3.04|but the big question is can our
580.959|2.241|synthetic neural networks also do the
582.48|2.24|same
583.2|2.72|and i think the answer to us internally
584.72|3.44|over the last few months that we've
585.92|3.919|worked on this is an unequivocal yes
588.16|4.16|and i'd like to sort of talk about that
589.839|4.401|so in particular the radar api
592.32|3.68|or like what the radar really gives you
594.24|3.279|is it gives you a quite accurate
596.0|2.88|depth and velocity measurement it's a
597.519|2.0|pretty direct measurement of the car
598.88|3.04|ahead of you
599.519|3.041|in very nominal situations so here i'm
601.92|2.56|showing
602.56|2.88|a random image on the left and you are
604.48|2.72|seeing the depth velocity and
605.44|2.56|acceleration reported by the radar stack
607.2|2.0|for this car
608.0|2.64|and you can see that it's a bit wiggly
609.2|3.44|on the velocity so this is some kind of
610.64|4.16|a stop and go scenario
612.64|3.52|now when radar has a good lock on the
614.8|3.279|car in front of you it's given
616.16|3.28|incredibly good depth and velocity but
618.079|3.521|the problem with radar is like
619.44|3.44|once in a while at random it will give
621.6|3.76|you a dumb measurement
622.88|4.0|and you will not know when that is and
625.36|3.599|so it's incredibly hard to fuse
626.88|4.16|with vision in our experience so it
628.959|4.081|might suddenly see a spurious
631.04|3.28|stationary object because of the manhole
633.04|3.359|or because of the bridge
634.32|3.519|or crossing objects are not very well
636.399|2.241|tracked or oncoming objects are not very
637.839|2.961|well tracked
638.64|3.04|and it ends up contributing noise i'll
640.8|2.479|go into
641.68|3.279|more detail in a bit but for our
643.279|3.761|purposes what we want to do right now
644.959|4.0|is we want to match the quality of these
647.04|3.12|predictions using vision alone
648.959|2.481|so the question is how can you get a
650.16|2.0|neural net to predict depth velocity
651.44|3.04|acceleration
652.16|3.04|directly and do it with a very high
654.48|3.039|fidelity
655.2|3.36|matching that of radar so the approach
657.519|2.161|we're going to take of course is we're
658.56|1.44|going to treat this as a surprise
659.68|2.32|learning
660.0|3.44|problem and we need a massive data set
662.0|2.8|of depth velocity acceleration
663.44|2.72|on a lot of cars and we're going to
664.8|3.039|train a large enough neural network and
666.16|3.52|do a very good job at that that's the
667.839|3.44|standard vanilla approach and that
669.68|5.12|actually works really well if you do it
671.279|3.521|properly so here's what it took
674.959|3.12|so the first component that you need is
676.64|3.759|an incredibly good data set
678.079|3.601|so when i talk about a good data set i
680.399|2.0|believe it has to have three properties
681.68|2.719|that are critical
682.399|3.12|it has to be large and millions of
684.399|2.721|examples
685.519|3.281|it needs to be clean so in this case we
687.12|3.44|have to have a very clean uh source of
688.8|2.64|depth velocity and acceleration for all
690.56|2.959|these cars
691.44|3.68|and it must be diverse so we're not just
693.519|3.681|talking about a single
695.12|3.68|you know driving clip of going forward
697.2|3.12|on the highway we really have to get
698.8|2.88|into the edge cases and mine all the
700.32|2.48|difficult scenarios and i'm going to
701.68|3.36|show you some examples
702.8|3.12|and when you have a large clean diverse
705.04|3.12|data set
705.92|3.76|um and you train a large enough neural
708.16|4.0|network on it what i've seen
709.68|4.32|in practice uh is in the words of elias
712.16|4.0|cover sas cover
714.0|3.76|success is guaranteed and so let me show
716.16|3.359|you some examples of that
717.76|3.36|so how are we gonna so first of all how
719.519|3.76|are we going to achieve this data set
721.12|4.0|so of course we need uh to collect
723.279|3.761|training data uh the typical approach
725.12|4.88|might be to use humans to annotate
727.04|4.72|uh cars around us in three dimensions um
730.0|4.32|what we found actually works really well
731.76|4.24|is an auto labeling approach so it's not
734.32|2.079|pure humans just like annotating cars
736.0|2.639|it's
736.399|3.761|it's an offline tracker as we call it
738.639|4.241|and it's an auto labeling process
740.16|4.0|for uh collecting data at the scale that
742.88|2.8|is necessary
744.16|2.96|so we need again millions of hard
745.68|3.04|examples so this is where the scale
747.12|2.56|comes from is that it's not labeled
748.72|2.72|purely by humans
749.68|3.2|although humans are involved it's
751.44|2.959|labeled automatically
752.88|3.12|so here's an example of some automatic
754.399|4.321|labels we were able to derive four
756.0|3.12|cars on the highway and the way you do
758.72|2.559|this
759.12|3.68|is because you're offline and you're
761.279|3.921|trying to just annotate a clip
762.8|3.68|you have a large number of benefits that
765.2|2.0|you don't typically have if you're at
766.48|2.96|test time
767.2|3.04|under strict latency requirements in the
769.44|2.56|car
770.24|3.2|so you can take your time to fully
772.0|2.079|figure out exactly all the objects and
773.44|1.839|where they are
774.079|3.2|you can use neural networks that are
775.279|3.761|extremely heavy they are not deployable
777.279|3.201|for various reasons uh you can use
779.04|2.96|benefit of hindsight because you know
780.48|2.64|the future not just the past
782.0|2.399|you can use all kinds of expensive
783.12|2.32|offline optimization and tracking
784.399|3.361|techniques
785.44|3.92|you can use extra sensors in this case
787.76|2.879|for example actually radar was one of
789.36|1.919|the sensors that we used for the auto
790.639|1.601|labeling
791.279|2.481|but there's actually a massive
792.24|2.719|difference between using radar at test
793.76|3.28|time and using it
794.959|4.0|in the offline tracker and that is that
797.04|3.599|at test time a radar can just report
798.959|3.44|a stationary track immediately in front
800.639|3.281|of you and you have 20 milliseconds to
802.399|3.521|decide if you're going to break or not
803.92|3.68|if you're offline you have the benefit
805.92|2.64|of hindsight and so you can do a much
807.6|3.44|better job of
808.56|4.24|calmly fusing if you really want to and
811.04|2.799|so there is a massive difference there
812.8|2.56|and in addition you can of course
813.839|2.721|involve humans and they can do cleaning
815.36|4.8|verification editing
816.56|5.2|and so on um and so we basically found
820.16|2.56|that this was a massive lever to allow
821.76|3.519|us to reach the
822.72|4.0|scale and the labeling quality and then
825.279|3.841|to get the diversity
826.72|3.52|that was also a massive fight so here's
829.12|3.76|some examples of
830.24|3.2|really tricky scenarios so here there's
832.88|1.84|some
833.44|4.0|i don't actually know exactly what this
834.72|5.119|is but basically this car um
837.44|4.0|drops a bunch of debris on us and we
839.839|3.761|maintain a consistent track
841.44|4.0|for the label and of course if you have
843.6|2.32|millions of labels like this the neural
845.44|2.639|net
845.92|3.599|if it's a powerful enough neural net
848.079|3.681|will actually end up learning to persist
849.519|4.161|these tracks in these kinds of scenarios
851.76|3.199|here's another example there's a car in
853.68|3.12|front of us
854.959|3.44|and i actually am not 100 sure what
856.8|2.96|happens in this case but
858.399|2.88|as you'll see there's some kind of a
859.76|3.36|dust cloud that develops here and
861.279|4.0|briefly occludes the car
863.12|3.6|but in the auto labeling tool we are
865.279|3.281|able to persist this track because we
866.72|3.359|saw it before and we saw it after so we
868.56|2.88|can actually stitch it up
870.079|3.601|and use it as a training set for the
871.44|5.28|neural here's one more example of an
873.68|6.159|adversarial scenario from heavy snow
876.72|5.359|again we can auto label this fine and
879.839|4.24|create a large collection of examples
882.079|3.601|now as we were working on this over a
884.079|3.281|duration of i want to say of roughly
885.68|3.279|four months of really just focusing a
887.36|3.36|lot of the team on this problem of
888.959|2.961|achieving really good depth velocity and
890.72|3.679|acceleration
891.92|3.76|we've ended up developing 221 triggers
894.399|3.761|uh manually
895.68|4.08|uh that we were using to source data
898.16|4.32|from our customer fleet
899.76|5.199|and this is just an example um some
902.48|3.28|examples of the 221 triggers that were
904.959|3.44|used to collect
905.76|3.84|all of these uh diverse scenarios so for
908.399|4.641|example
909.6|5.12|we have um shadow mode where we deploy a
913.04|3.52|neural network that is pretty good at
914.72|4.0|predicting depth and velocity and what
916.56|4.079|we do is we run it silently in the cars
918.72|3.52|of our customers but it's not actually
920.639|3.841|connected to control
922.24|3.2|what's driving is the legacy stack but
924.48|2.08|we're we're
925.44|2.32|we're basically running the new
926.56|2.399|measurements of depth and velocity and
927.76|2.48|we're for example looking at whether or
928.959|3.041|not they agree or disagree with the
930.24|3.519|legacy stack or with the radar
932.0|3.12|we're looking for other sources of jam
933.759|2.0|like for example if there's bounding box
935.12|2.32|jitter
935.759|3.041|detection jitter the main and the narrow
937.44|3.28|camera disagree
938.8|3.52|um we predict that there's a harshly
940.72|2.72|decelerating object but the person seems
942.32|3.199|to not mind
943.44|3.36|um all kinds of disagreements between
945.519|3.921|different neural network
946.8|4.32|signals um and you know there's a
949.44|3.28|there's a long list here
951.12|3.04|it took us a while to actually perfect
952.72|2.799|these triggers and all of them are
954.16|2.0|iteration and you're looking at what's
955.519|3.201|coming back
956.16|4.88|you're tuning your trigger and uh you're
958.72|4.64|sourcing data from all these scenarios
961.04|4.0|so basically over the last four months
963.36|3.919|we've done quite extensive data engine
965.04|3.2|we've ended up doing seven shadow modes
967.279|3.12|and seven loops
968.24|3.519|around this data engine here where on
970.399|2.161|the top right is where you begin you
971.759|2.721|have some seed
972.56|3.04|data set you train your neural network
974.48|3.039|on your data set
975.6|3.44|and you deploy the neural network in the
977.519|2.721|customer cars in shadow mode
979.04|2.96|and the network is silently making
980.24|3.039|predictions and then you have to have
982.0|3.04|some mechanisms for sourcing
983.279|3.841|inaccuracies of the neural net so you're
985.04|3.2|just looking at its predictions
987.12|3.04|and then you're using one of these
988.24|3.44|triggers like i described you're getting
990.16|3.119|these scenarios where the network is
991.68|3.36|probably misbehaving
993.279|3.12|some of those clips end up going to unit
995.04|2.88|tests to make sure that we
996.399|3.761|even if we're failing right now we make
997.92|3.599|sure we pass later and in addition those
1000.16|3.44|examples are being auto labeled
1001.519|4.0|and incorporated into a training set and
1003.6|3.52|then as a asynchronous process we're
1005.519|2.801|also always data cleaning the current
1007.12|3.04|training set
1008.32|3.28|and so we spin this loop over and over
1010.16|2.96|again until the network basically
1011.6|4.08|becomes incredibly good
1013.12|4.079|so in total we've done seven rounds of
1015.68|3.44|shadow mode for this release
1017.199|4.08|um we've accumulated one million
1019.12|4.719|extremely hard diverse clips
1021.279|4.241|uh and these are videos so these are you
1023.839|2.24|should roughly think about say 10 second
1025.52|3.039|eclipse
1026.079|4.401|36 fps something like that in total we
1028.559|3.921|have about 6 billion objects labeled
1030.48|4.64|cleanly for depth and velocity and this
1032.48|5.439|takes up roughly 1.5 metabytes of
1035.12|3.6|storage so that gives us a really good
1037.919|2.081|data set
1038.72|3.599|of course that by itself does not
1040.0|5.199|suffice so we have an incredibly good
1042.319|4.081|ai team of uh that is designing the
1045.199|2.48|neural network architecture
1046.4|3.44|there's basically the layout of the
1047.679|4.641|synthetic visual cortex in order to
1049.84|4.4|efficiently process this information so
1052.32|3.04|our architecture roughly looks like this
1054.24|3.04|we have these images coming from
1055.36|3.12|multiple cameras on the top all of them
1057.28|3.12|are processed by an image
1058.48|3.199|extractor like a backbone like think
1060.4|3.44|resnet
1061.679|4.161|kind of style then there's a multicam
1063.84|2.719|fusion that fuses the information from
1065.84|3.839|all the eight
1066.559|3.841|views um and this is a kind of a
1069.679|2.721|transformer
1070.4|3.36|that we use uh to fuse this information
1072.4|3.279|and then we fuse information
1073.76|3.52|first across all the cameras and then
1075.679|3.281|across all of time
1077.28|3.6|and that is also done either by
1078.96|2.88|transformer by recurring neural network
1080.88|2.64|or just by three-dimensional
1081.84|3.04|convolutions we've experimented with a
1083.52|3.2|lot of um
1084.88|3.28|kind of fusion strategies here to get
1086.72|3.12|this to work really well
1088.16|3.04|and then what we have afterwards after
1089.84|2.32|the fusion is done is we have this
1091.2|3.04|branching structure
1092.16|3.6|that doesn't just consist of heads but
1094.24|2.559|actually we've extended this over the
1095.76|3.279|last few
1096.799|4.161|last year or so where you now have heads
1099.039|2.721|that branch into trunks that branch into
1100.96|3.12|terminals
1101.76|3.6|so there's a lot of branching structure
1104.08|1.839|and the reason you want this branching
1105.36|1.76|structure
1105.919|2.801|is because there's a huge amount of
1107.12|2.96|outputs that you're interested in and
1108.72|2.64|you can't afford to have a single neural
1110.08|1.76|network for every one of the individual
1111.36|2.24|outputs
1111.84|3.04|you have to of course amortize the
1113.6|3.6|forward pass uh
1114.88|3.44|for efficient inference at this time and
1117.2|3.04|so there's a lot of
1118.32|3.2|feature sharing here the other nice
1120.24|2.4|benefit of the branching structure is
1121.52|3.279|that it decouples
1122.64|4.399|at the terminals it decouples all these
1124.799|4.0|signals so if i'm someone working on
1127.039|2.64|velocity for a particular object type or
1128.799|2.321|something like that
1129.679|3.041|i have a small piece of neural network
1131.12|3.28|that i can actually fine-tune without
1132.72|3.76|touching any of the other signals
1134.4|3.519|and so i can work in isolation uh to
1136.48|2.48|some extent and actually get something
1137.919|2.801|to work pretty well
1138.96|3.04|and then once in a while so basically
1140.72|3.28|the iteration scheme is that
1142.0|3.2|a lot of people are fine tuning and once
1144.0|3.76|in a while we do an up
1145.2|4.16|of all of the backbone end-to-end and so
1147.76|3.68|it's a very interesting
1149.36|4.0|sort of mechanism because we have you
1151.44|3.04|know a team of roughly 20 people who are
1153.36|3.04|i would say training neural networks
1154.48|3.04|full-time and they're all cooperating on
1156.4|2.639|the single neural net
1157.52|3.36|and so what is the workflow by which you
1159.039|3.361|do that is pretty fascinating
1160.88|3.679|and continues to be a challenge to
1162.4|3.68|actually design efficiently
1164.559|3.201|so we have a neural network architecture
1166.08|2.88|we have a data set now training these
1167.76|3.279|neural networks like i mentioned this is
1168.96|3.92|a 1.5 petabyte data set
1171.039|3.841|requires a huge amount of compute so i
1172.88|3.6|wanted to briefly give a plug to
1174.88|3.12|this insane supercomputer that we are
1176.48|4.48|building and using now
1178.0|3.52|um and uh you know for us computer
1180.96|1.599|vision is
1181.52|3.36|the bread and butter of what we do and
1182.559|3.601|what enables the autopilot and uh
1184.88|2.64|for that to work really well you need a
1186.16|2.96|massive data set we get that from the
1187.52|3.12|fleet but you also need to train massive
1189.12|3.679|neural nets and experiment a lot
1190.64|4.56|so we've invested a lot into the compute
1192.799|3.361|in this case we have here a data center
1195.2|4.479|we have a cluster that we're just
1196.16|5.92|building that is 720 nodes of atx a100
1199.679|3.041|of the 80 gigabyte version so this is a
1202.08|3.28|massive
1202.72|4.56|super computer i actually believe that
1205.36|4.88|in terms of flops this is roughly
1207.28|3.44|uh number five supercomputer in the
1210.24|2.0|world
1210.72|3.28|so this is actually a fairly significant
1212.24|3.84|uh computer here
1214.0|3.44|we have 10 petabytes of hotie or nvme
1216.08|4.32|storage and
1217.44|5.119|it's also an incredibly fast storage so
1220.4|3.519|i believe 1.6 terabytes per second this
1222.559|2.401|is one of the world's fastest file
1223.919|3.361|systems
1224.96|4.0|and we have a 60 we have also a very
1227.28|3.68|efficient fabric
1228.96|3.04|that connects all of this because of
1230.96|2.16|course if you're doing distributed
1232.0|2.64|training across your nodes
1233.12|2.96|you need your gradients to to be
1234.64|2.64|synchronized very efficiently and of
1236.08|1.92|course we are reading all of these
1237.28|2.8|videos from
1238.0|3.6|the file system and that requires uh
1240.08|3.44|really fat bite as well
1241.6|3.68|so uh this is a pretty incredible super
1243.52|4.399|computer um
1245.28|4.8|and so this is a gpu cluster next up
1247.919|3.921|we're really hoping that
1250.08|3.599|we're currently working on project dojo
1251.84|3.44|which will take this to next level
1253.679|3.201|but i'm not ready to sort of reveal any
1255.28|2.72|more details about that at this point
1256.88|2.56|what i would like to do is i would like
1258.0|1.919|to just briefly plug the super computing
1259.44|3.84|team
1259.919|5.441|uh they've been growing a lot um and so
1263.28|3.68|uh if if high performance computing for
1265.36|3.6|this application and for training these
1266.96|3.52|uh crazy neural networks excites you
1268.96|2.8|uh then we definitely appreciate more
1270.48|2.319|help uh so please contact the
1271.76|3.039|supercomputing team at
1272.799|3.841|supercomputing at tesla to help us build
1274.799|3.201|these uh clusters on the left here we
1276.64|2.159|have the compute nodes and on the right
1278.0|3.44|this is a
1278.799|3.12|network switch actually uh so the wires
1281.44|2.16|here
1281.919|4.721|is kind of like the white matter of this
1283.6|4.4|uh synthetic cortex i guess
1286.64|3.44|uh the other thing i wanted to briefly
1288.0|5.919|talk about is
1290.08|5.76|i wanted to also mention briefly that
1293.919|3.12|this effort basically is incredibly
1295.84|4.0|vertically integrated
1297.039|3.52|uh in the ai team so as i showed you we
1299.84|2.719|own
1300.559|3.36|the vehicle in the sensing and we source
1302.559|1.921|our own data and we annotate our own
1303.919|3.041|data
1304.48|3.679|and we train our on-prem cluster and
1306.96|2.8|then we deploy all of the neural
1308.159|2.561|networks that we train on our in-house
1309.76|4.159|developed chip
1310.72|5.92|so we have the fsd computer uh here that
1313.919|4.561|has two socs fsd chips here and they
1316.64|2.399|have our own custom npu neural
1318.48|4.24|processing
1319.039|6.0|unit here at roughly 36 tops each and
1322.72|3.92|so these chips are specifically designed
1325.039|4.481|for the neural networks that
1326.64|3.2|we want to run for fsd applications and
1329.52|1.68|so
1329.84|2.8|everything is very vertical integrated
1331.2|2.4|in the team and i think that's pretty
1332.64|3.519|incredible because
1333.6|3.28|um you get to really co-design an
1336.159|3.681|engineer
1336.88|4.24|at all the layers of that stack and uh
1339.84|2.4|there's no third party that is holding
1341.12|2.4|you back you're
1342.24|2.96|fully in charge of your own destiny
1343.52|2.96|which i think is incredibly unique and
1345.2|2.64|very exciting
1346.48|2.88|and then we have a deployment a pipeline
1347.84|2.4|here where we take these neural networks
1349.36|2.48|and we do a lot of
1350.24|3.52|typical graph optimization fusion
1351.84|3.36|quantization threshold calibration and
1353.76|4.32|so on and deploy it on our
1355.2|4.4|chip and we and this is in the
1358.08|4.24|customer's cars and
1359.6|3.68|these neural networks run there so now
1362.32|2.56|what i'd like to show is
1363.28|2.96|i first would like to show some
1364.88|2.0|qualitative examples of some of our
1366.24|2.0|results
1366.88|2.72|in terms of the depth and velocity
1368.24|3.04|predictions that we're able to achieve
1369.6|3.6|by putting all these pieces together and
1371.28|3.68|training these networks at scale
1373.2|3.839|so the first example here i have a video
1374.96|3.28|where this is on track testing so this
1377.039|3.12|is an engineering car
1378.24|3.12|and we asked it to slam on the brakes as
1380.159|2.88|hard as it possibly can
1381.36|3.199|so this is a very harsh braking here in
1383.039|2.0|front of us even though it doesn't look
1384.559|3.441|like that
1385.039|4.321|in the videos it's very heartbreaking so
1388.0|3.039|what you can see on the right here is
1389.36|2.64|you can see the outputs from the legacy
1391.039|2.961|stack which had
1392.0|3.28|radar vision fusion and from the new
1394.0|4.159|stack which is vision
1395.28|3.44|alone in blue so in the orange legacy
1398.159|3.361|stack
1398.72|4.48|you can actually see these track drops
1401.52|2.32|here when the car was breaking really
1403.2|2.08|harshly
1403.84|3.6|and basically the issue is that the
1405.28|2.639|braking was so harsh that the radar
1407.44|2.719|stack
1407.919|3.441|that we have actually ended up uh not
1410.159|2.481|associating the car
1411.36|3.04|and dropping the track and then
1412.64|3.36|reinitializing it all the time
1414.4|3.6|and so it's as if the vehicle
1416.0|2.88|disappeared and reappeared like six
1418.0|2.64|times
1418.88|3.2|during the period of this breaking and
1420.64|1.84|so this created a bunch of artifacts
1422.08|2.32|here
1422.48|3.679|but we see that the new stack in blue is
1424.4|3.2|actually not subject to this
1426.159|3.601|behavior at all it just gives a clean
1427.6|3.28|signal in fact here there's no smoothing
1429.76|3.039|i believe on the blue
1430.88|3.36|signal here this is the raw depth and
1432.799|1.921|velocity that comes out from the neural
1434.24|2.96|net
1434.72|3.6|the final neuron that we released with
1437.2|2.4|about three weeks ago
1438.32|3.92|and you can see that it's fairly smooth
1439.6|5.04|here and of course you could go
1442.24|3.679|into the radar stack and you could um
1444.64|2.88|you know adjust the height parameters
1445.919|2.801|into tracker like why is it dropping
1447.52|2.399|tracks and so on
1448.72|3.12|but then you are spending engineering
1449.919|4.481|efforts and focus on a stack
1451.84|3.28|that is like not really barking up the
1454.4|2.32|right tree
1455.12|2.64|and so it's better to again just focus
1456.72|1.52|on the vision and make it work really
1457.76|2.08|well
1458.24|3.039|and we see that it is much more robust
1459.84|4.16|when you train it at scale
1461.279|3.601|uh than than something like this here's
1464.0|4.159|another example
1464.88|4.799|um fairly infamous example of slowdowns
1468.159|3.441|when there are cars
1469.679|3.521|going below a bridge the issue here
1471.6|3.12|again is that the radar does not have
1473.2|4.4|too much vertical resolution
1474.72|3.839|so radar reports a stationary object in
1477.6|2.48|front of you
1478.559|3.12|it's as it like the radar doesn't know
1480.08|2.8|that there's if it's there's like a
1481.679|2.0|stationary car in front of you or if
1482.88|2.64|it's the bridge but
1483.679|2.88|it cannot differentiate those two so
1485.52|2.24|radar thinks that there might be
1486.559|2.72|something stationary in front
1487.76|3.2|and it's just like looking for something
1489.279|2.961|in vision to tell it that it might be
1490.96|2.48|correct and then we create a stationary
1492.24|3.439|target and break
1493.44|3.04|and so in this case in the legacy vision
1495.679|2.081|predictions
1496.48|3.12|which were already producing depth and
1497.76|4.799|velocity but
1499.6|4.88|because we were using radar the vision
1502.559|4.961|inaccuracies were being masked
1504.48|5.28|because um your bar is only at
1507.52|3.2|radar association your bar is not at
1509.76|2.48|actual driving
1510.72|4.079|and so the depth and velocity were not
1512.24|4.16|held up to high enough bar and so
1514.799|3.441|basically what happens is vision reports
1516.4|2.56|a slightly for a few frames reports a
1518.24|2.799|slightly
1518.96|3.44|too negative velocity for the car and
1521.039|1.921|then it associates to the stationary
1522.4|1.92|object
1522.96|3.52|and the stack is like oh that must be
1524.32|5.44|the stationary thing and then you break
1526.48|4.799|and so um this of course is much cleaner
1529.76|2.96|and you see that the new stack
1531.279|3.601|does not see this at all and there's no
1532.72|3.04|track there's no uh slowdowns in this
1534.88|2.88|case
1535.76|3.68|um because we just get the correct depth
1537.76|3.2|and velocity and vision obviously has
1539.44|3.04|the vertical resolution to differentiate
1540.96|3.36|a bridge from a car and whether or not
1542.48|3.52|the car is slowing or not
1544.32|3.76|so again you could go into the vision
1546.0|2.88|step the radar stack or the sensor
1548.08|1.92|fusion stack
1548.88|2.56|and if you have an improved depth and
1550.0|2.32|velocity you could change the fusion
1551.44|2.08|strategy
1552.32|2.8|uh but again you're just kind of like
1553.52|2.8|doing dead work like this signal is so
1555.12|4.159|good by itself
1556.32|3.44|why would you why would you do that um
1559.279|2.481|so
1559.76|4.159|in this in this setting now we've we've
1561.76|4.799|improved the situation a lot
1563.919|3.521|here's another last example we have a
1566.559|2.321|stationary approach
1567.44|3.28|again this is in track testing
1568.88|3.039|environment this is an example of a test
1570.72|2.72|that we would run
1571.919|3.281|and we are just approaching this vehicle
1573.44|3.04|and hoping to stop what you see in
1575.2|3.28|orange in the legacy stack
1576.48|3.679|is that it actually takes us quite a bit
1578.48|2.96|of time for us to start slowing
1580.159|2.961|and basically what's happening here is
1581.44|2.96|that the radar is very trigger happy and
1583.12|3.039|it sees all these false
1584.4|3.519|stationary objects everywhere like
1586.159|2.721|everything that like sticks out is a
1587.919|2.561|stationary target
1588.88|3.2|and radar by itself doesn't know what
1590.48|3.28|actually is a stationary car and what
1592.08|3.92|isn't so it's waiting for vision to
1593.76|3.68|associate with it and vision if it's not
1596.0|4.72|held up to a high enough bar
1597.44|4.64|is noisy and contributes sort of error
1600.72|3.199|and the sensor fusion stack just kind of
1602.08|2.8|like picks it up too late and so again
1603.919|2.801|you could fix all that
1604.88|3.76|even though it's a very gross system
1606.72|3.28|with a lot of if statements and so on
1608.64|2.96|because the sensor fusion is complicated
1610.0|2.32|because the error modes for vision and
1611.6|3.04|radar
1612.32|4.0|are slightly are quite different but
1614.64|3.44|here when we just work with vision alone
1616.32|3.44|and we take out the radar vision
1618.08|2.8|recognizes this object very early gives
1619.76|2.159|the correct depth and velocity and
1620.88|2.399|there's no issues
1621.919|3.601|so we actually get an initial slow down
1623.279|4.0|much earlier and we really like
1625.52|5.84|simplified the stack a lot and
1627.279|5.681|uh as well so just speaking very briefly
1631.36|4.559|to the release and validation
1632.96|3.52|um we've extensively validated this
1635.919|2.88|before we
1636.48|3.84|of course ship this to customers uh just
1638.799|3.521|some example uh
1640.32|3.92|numbers for the validation itself we've
1642.32|3.599|hand-picked about 6000 clips in about 70
1644.24|3.039|categories of scenarios like harsh
1645.919|3.041|breaking crossing vehicles
1647.279|4.241|uh different vehicle types environments
1648.96|4.8|and so on and we run these
1651.52|3.36|tests on all the commits of the build
1653.76|2.639|and we run them also everyday
1654.88|3.36|periodically as we were trying to drive
1656.399|3.441|up the performance on these clips
1658.24|3.52|we also use simulation extensively for
1659.84|3.199|validation we've also used simulation
1661.76|2.08|for training although i haven't gone
1663.039|2.64|into that
1663.84|3.199|but we've had some successes there but
1665.679|2.0|we used it primarily for validation at
1667.039|2.24|this stage
1667.679|2.961|and that's again like diversity of
1669.279|3.12|scenarios trying to make sure that the
1670.64|3.44|stack is performing correctly
1672.399|3.441|um we've done a lot of track testing and
1674.08|3.44|i've shown you some examples of that
1675.84|4.0|we've driven this extensively in the qa
1677.52|3.279|fleet and we've also deployed this in
1679.84|3.36|shadow modes
1680.799|4.081|and seen that this stack performs fairly
1683.2|2.0|well so in particular for example for
1684.88|2.08|the
1685.2|3.839|automatic emergency braking we actually
1686.96|3.599|see a higher precision in recall
1689.039|4.0|compared to the legacy stack that is a
1690.559|3.761|fusion stack and so having seen all this
1693.039|3.041|we've actually released this we've
1694.32|5.2|accumulated about 15 million miles
1696.08|5.04|so far um and 1.7 million of those have
1699.52|2.56|been on autopilot and so far there have
1701.12|3.12|been no crashes
1702.08|3.04|now of course we're running at a massive
1704.24|2.64|scale here
1705.12|3.679|and so we do expect some crashes at some
1706.88|4.24|point the legacy stack
1708.799|3.681|has a crash roughly every five million
1711.12|3.439|miles or so i believe
1712.48|3.52|and so we do expect some some incidents
1714.559|3.921|uh um
1716.0|3.6|at some point but this uh the
1718.48|2.72|improvements for the vision stack are
1719.6|2.64|not sort of stopping so i think we're
1721.2|2.8|very confident that
1722.24|3.2|uh we're barking up the right tree here
1724.0|4.24|and that we can actually get this work
1725.44|2.8|really incredibly well
1728.559|3.441|um i also want to briefly give a shout
1730.24|2.48|out to auto labeling as an incredibly
1732.0|3.76|powerful
1732.72|4.48|method for sourcing training data so
1735.76|2.32|we're applying auto labeling to all of
1737.2|2.079|the fsd tasks
1738.08|2.56|not just the depth and velocity of the
1739.279|4.321|car in front of us here's an auto
1740.64|5.039|labeler for pedestrians
1743.6|3.92|and you can see that the tracks are very
1745.679|2.961|smooth and this is again a completely
1747.52|2.8|offline process
1748.64|3.44|that we are applying not just to objects
1750.32|4.8|but also to
1752.08|5.839|a lot of static environments so this is
1755.12|4.64|some example of the 3d reconstruction so
1757.919|2.48|here we see a clip and this is a vision
1759.76|3.68|only
1760.399|4.721|estimate of the depths of all the points
1763.44|3.28|and of course you don't actually want to
1765.12|3.52|really deploy
1766.72|3.36|these measurements directly into a car
1768.64|2.56|because they are too raw
1770.08|2.88|so what you actually want to do is you
1771.2|3.04|want to again auto label and you want to
1772.96|2.719|really think about what is it what is
1774.24|2.799|the information i really need at test
1775.679|3.761|time in the car
1777.039|3.441|and what is like as close as possible to
1779.44|2.16|action right
1780.48|2.48|so you want to do all this work at
1781.6|2.24|training time figure out exactly what
1782.96|2.56|happened in the club
1783.84|2.64|reconstruct the entire environment and
1785.52|2.32|then you want to actually like
1786.48|3.36|post-process the curb
1787.84|3.76|at training time so you want to do as
1789.84|2.64|much a training time and labeling time
1791.6|2.16|as possible
1792.48|3.199|and then you want to figure out what are
1793.76|4.08|the tasks i really need that test time
1795.679|3.36|and that's the thing that happens um in
1797.84|2.959|the car um
1799.039|3.041|you know subject to very strict latency
1800.799|4.721|requirements you want to do as little
1802.08|4.88|processing there as possible so
1805.52|4.56|we see that this is a very powerful
1806.96|4.56|lever on korean datasets
1810.08|3.52|so in summary what i try to argue and
1811.52|2.56|give you a sense of is vision alone is
1813.6|2.48|actually
1814.08|3.52|in our is our finding that is perfectly
1816.08|3.92|capable of depth sensing
1817.6|3.6|um it is an incredibly rich sensor in
1820.0|4.32|terms of bandwidth
1821.2|4.56|of information and doing this and
1824.32|3.28|matching radar performance and depth and
1825.76|3.68|velocity is incredibly hard
1827.6|3.28|i believe it requires the fleet because
1829.44|3.839|the data set that we're able to achieve
1830.88|3.919|was critical in all these performance
1833.279|3.28|improvements and if you do not have the
1834.799|2.24|fleet i'm not 100 sure how you can
1836.559|2.24|source
1837.039|3.041|all the difficult and diverse scenarios
1838.799|3.12|that we did source
1840.08|3.44|um because i believe that was critical
1841.919|3.521|to getting this to work so
1843.52|3.279|it's hard requires massive networks a
1845.44|4.479|super computer and
1846.799|5.12|a data engine and the fleet um but all
1849.919|4.88|of these components are coming together
1851.919|3.201|in um in a vertically integrated fashion
1854.799|2.72|at
1855.12|3.12|tesla ai and i believe that this makes
1857.519|2.0|us uh
1858.24|3.36|sort of uniquely positioned in the
1859.519|3.76|industry where we are
1861.6|3.199|barking up the right tree and we have
1863.279|3.841|all the puzzle pieces to make this
1864.799|3.041|to make this work and so if you are
1867.12|2.88|excited about the
1867.84|3.679|leverage that we're taking and uh the
1870.0|2.96|networks and the work that we're doing
1871.519|3.361|then i would encourage you to please
1872.96|3.76|apply uh and join the team
1874.88|3.76|and help us make this a reality so you
1876.72|3.839|can go to tesla.com autopilot ai
1878.64|3.039|it's a very simple process uh you upload
1880.559|2.72|a resume and you
1881.679|2.88|you have a blurb about some of the
1883.279|2.0|things that you've done that they're
1884.559|2.561|impressive
1885.279|3.361|and then that comes directly to us and
1887.12|2.399|uh we'd love to work with you to make us
1888.64|4.159|reality
1889.519|3.28|thank you