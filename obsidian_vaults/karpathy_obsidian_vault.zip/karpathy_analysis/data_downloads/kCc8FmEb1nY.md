start_time|end_time|text
0.06|3.06|hi everyone
1.38|4.02|so by now you have probably heard of
3.12|4.86|Chachi PT it has taken the world and the
5.4|5.159|AI Community by storm and it is a system
7.98|5.159|that allows you to interact with an AI
10.559|4.981|and give it text-based tasks so for
13.139|3.9|example we can ask chatgpt to write us a
15.54|3.36|small haiku about how important it is
17.039|3.301|that people understand Ai and then they
18.9|4.74|can use it to improve the world and make
20.34|5.4|it more prosperous so when we run this
23.64|5.399|AI knowledge brings prosperity for all
25.74|5.16|to see Embrace its power okay not bad
29.039|4.261|and so you could see that Chachi PT went
30.9|4.92|from left to right and generated all
33.3|4.8|these words seek sort of sequentially
35.82|4.32|now I asked it already the exact same
38.1|3.779|prompt a little bit earlier and it
40.14|4.439|generated a slightly different outcome
41.879|5.401|AI is power to grow ignorance holds us
44.579|4.741|back learn Prosperity weights
47.28|3.54|so uh pretty good in both cases and
49.32|3.719|slightly different so you can see that
50.82|3.899|chatgpt is a probabilistic system and
53.039|5.101|for any one prompt it can give us
54.719|5.581|multiple answers sort of replying to it
58.14|3.54|now this is just one example of a prompt
60.3|3.419|people have come up with many many
61.68|4.799|examples and there are entire websites
63.719|5.521|that index interactions with charge EBT
66.479|5.941|and so many of them are quite humorous
69.24|6.0|explain HTML to me like I'm a dog write
72.42|4.739|release notes for chess 2. write a note
75.24|3.84|about Elon Musk buying on Twitter
77.159|4.381|and so on
79.08|4.14|so as an example please write a breaking
81.54|2.52|news article about a leaf falling from a
83.22|3.719|tree
84.06|3.96|uh and a shocking turn of events a leaf
86.939|3.061|has fallen from a treat in the local
88.02|3.48|park Witnesses report that the leaf
90.0|3.479|which was previously attached to a
91.5|5.04|branch of a tree detached itself and
93.479|4.5|fell to the ground very dramatic so you
96.54|3.78|can see that this is a pretty remarkable
97.979|6.301|system and it is what we call a language
100.32|7.08|model because it it models the sequence
104.28|5.519|of words or characters or tokens more
107.4|4.56|generally and it knows how sort of words
109.799|4.441|follow each other in English language
111.96|4.74|and so from its perspective what it is
114.24|5.28|doing is it is completing the sequence
116.7|4.86|so I give it the start of a sequence and
119.52|4.139|it completes the sequence with the
121.56|2.94|outcome and so it's a language model in
123.659|2.881|that sense
124.5|3.78|now I would like to focus on the under
126.54|3.48|the hood of
128.28|3.84|um under the hood components of what
130.02|3.78|makes chat GPT work so what is the
132.12|4.199|neural network under the hood that
133.8|5.04|models the sequence of these words
136.319|5.701|and that comes from this paper called
138.84|5.46|attention is all you need in 2017 a
142.02|4.68|landmark paper a landmark paper and AI
144.3|4.439|that produced and proposed the
146.7|5.179|Transformer architecture
148.739|5.821|so GPT is short for generally
151.879|4.241|generatively pre-trained Transformer so
154.56|2.94|Transformer is the neural nut that
156.12|3.54|actually does all the heavy lifting
157.5|5.459|under the hood it comes from this paper
159.66|5.159|in 2017. now if you read this paper this
162.959|3.661|reads like a pretty random machine
164.819|2.821|translation paper and that's because I
166.62|2.58|think the authors didn't fully
167.64|3.72|anticipate the impact that the
169.2|3.899|Transformer would have on the field and
171.36|3.659|this architecture that they produced in
173.099|3.901|the context of machine translation in
175.019|4.8|their case actually ended up taking over
177.0|5.76|the rest of AI in the next five years
179.819|5.821|after and so this architecture with
182.76|5.1|minor changes was copy pasted into a
185.64|4.98|huge amount of applications in AI in
187.86|4.799|more recent years and that includes at
190.62|4.5|the core of chat GPT
192.659|3.72|now we are not going to what I'd like to
195.12|4.259|do now is I'd like to build out
196.379|4.321|something like chatgpt but we're not
199.379|3.181|going to be able to of course reproduce
200.7|4.52|chatgpt this is a very serious
202.56|5.94|production grade system it is trained on
205.22|4.96|a good chunk of internet and then
208.5|3.72|there's a lot of pre-training and
210.18|3.839|fine-tuning stages to it and so it's
212.22|5.34|very complicated what I'd like to focus
214.019|5.58|on is just to train a Transformer based
217.56|3.66|language model and in our case it's
219.599|4.261|going to be a character level
221.22|4.14|a language model I still think that is a
223.86|3.72|very educational with respect to how
225.36|4.14|these systems work so I don't want to
227.58|4.26|train on the chunk of Internet we need a
229.5|4.56|smaller data set in this case I propose
231.84|4.56|that we work with my favorite toy data
234.06|4.14|set it's called tiny Shakespeare and
236.4|3.36|what it is is basically it's a
238.2|3.899|concatenation of all of the works of
239.76|4.559|Shakespeare in my understanding and so
242.099|5.28|this is all of Shakespeare in a single
244.319|5.161|file this file is about one megabyte
247.379|4.14|and it's just all of Shakespeare
249.48|3.839|and what we are going to do now is we're
251.519|4.201|going to basically model how these
253.319|3.721|characters follow each other so for
255.72|2.94|example given a chunk of these
257.04|4.8|characters like this
258.66|5.22|are given some context of characters in
261.84|3.6|the past the Transformer neural network
263.88|3.42|will look at the characters that I've
265.44|4.14|highlighted and is going to predict that
267.3|3.899|g is likely to come next in the sequence
269.58|3.54|and it's going to do that because we're
271.199|3.841|going to train that Transformer on
273.12|4.74|Shakespeare and it's just going to try
275.04|4.26|to produce uh character sequences that
277.86|3.059|look like this
279.3|4.2|and in that process is going to model
280.919|4.5|all the patterns inside this data so
283.5|4.139|once we've trained the system I'd just
285.419|4.5|like to give you a preview we can
287.639|4.5|generate infinite Shakespeare and of
289.919|4.981|course it's a fake thing that looks kind
292.139|4.681|of like Shakespeare
294.9|4.5|um
296.82|6.12|apologies for there's some junk that I'm
299.4|4.44|not able to resolve in in here but
302.94|2.64|um
303.84|3.419|you can see how this is going character
305.58|4.98|by character and it's kind of like
307.259|6.121|predicting Shakespeare like language so
310.56|5.76|verily my Lord the sights have left the
313.38|6.48|again the king coming with my curses
316.32|5.34|with precious pale and then tronio says
319.86|3.66|something else Etc and this is just
321.66|3.9|coming out of the Transformer in a very
323.52|4.2|similar manner as it would come out in
325.56|5.76|Chachi PT in our case character by
327.72|5.64|character in Chachi PT it's coming out
331.32|3.96|on the token by token level and tokens
333.36|3.779|are these a sort of like little sub word
335.28|4.979|pieces so they're not Word level they're
337.139|6.361|kind of like work chunk level
340.259|6.301|um and now the I've already written this
343.5|6.12|entire code to train these Transformers
346.56|6.18|um and it is in a GitHub repository that
349.62|5.04|you can find and it's called a nano GPT
352.74|4.56|so Nano GPT is a repository that you can
354.66|4.5|find on my GitHub and it's a repository
357.3|3.78|for training Transformers
359.16|3.72|um On Any Given text
361.08|2.88|and what I think is interesting about it
362.88|2.879|because there's many ways to train
363.96|4.38|Transformers but this is a very simple
365.759|5.401|implementation so it's just two files of
368.34|5.52|300 lines of code each one file defines
371.16|4.62|the GPT model the Transformer and one
373.86|4.02|file trains it on some given Text data
375.78|4.08|set and here I'm showing that if you
377.88|3.42|train it on a open webtext data set
379.86|4.14|which is a fairly large data set of web
381.3|5.04|pages then I reproduce the the
384.0|5.759|performance of gpt2
386.34|7.56|so gpt2 is an early version of openai's
389.759|5.88|GPT from 2017 if I occur correctly and
393.9|4.56|I've only so far reproduced the the
395.639|4.021|smallest 124 million parameter model but
398.46|3.179|basically this is just proving that the
399.66|5.039|code base is correctly arranged and I'm
401.639|5.34|able to load the neural network weights
404.699|4.5|that open AI has released later
406.979|4.56|so you can take a look at the finished
409.199|3.961|code here in Nano GPT but what I would
411.539|4.801|like to do in this lecture is I would
413.16|4.74|like to basically write this repository
416.34|3.72|from scratch so we're going to begin
417.9|5.519|with an empty file and we're going to
420.06|5.22|define a Transformer piece by piece
423.419|3.961|we're going to train it on the tiny
425.28|4.02|Shakespeare data set and we'll see how
427.38|4.319|we can then generate infinite
429.3|4.08|Shakespeare and of course this can copy
431.699|4.56|paste to any arbitrary Text data set
433.38|4.14|that you like but my goal really here is
436.259|4.081|to just make you understand and
437.52|6.36|appreciate how under the hood chat GPT
440.34|6.96|works and really all that's required is
443.88|5.939|a Proficiency in Python and some basic
447.3|4.98|understanding of calculus and statistics
449.819|4.201|and it would help if you also see my
452.28|3.72|previous videos on the same YouTube
454.02|4.619|channel in particular my make more
456.0|5.58|series where I
458.639|5.161|Define smaller and simpler neural
461.58|4.08|network language models so multilevel
463.8|3.299|perceptrons and so on it really
465.66|3.84|introduces the language modeling
467.099|3.841|framework and then here in this video
469.5|3.12|we're going to focus on the Transformer
470.94|4.56|neural network itself
472.62|5.16|okay so I created a new Google collab uh
475.5|4.139|jupyter notebook here and this will
477.78|2.94|allow me to later easily share this code
479.639|3.481|that we're going to develop together
480.72|4.34|with you so you can follow along so this
483.12|4.5|will be in the video description later
485.06|4.66|now here I've just done some
487.62|3.6|preliminaries I downloaded the data set
489.72|3.24|the tiny Shakespeare data set at this
491.22|3.419|URL and you can see that it's about a
492.96|4.5|one megabyte file
494.639|4.74|then here I open the input.txt file and
497.46|3.9|just read in all the text as a string
499.379|4.021|and we see that we are working with 1
501.36|3.959|million characters roughly
503.4|3.66|and the first 1000 characters if we just
505.319|3.6|print them out are basically what you
507.06|4.199|would expect this is the first 1000
508.919|4.74|characters of the tiny Shakespeare data
511.259|4.861|set roughly up to here
513.659|4.921|so so far so good next we're going to
516.12|4.5|take this text and the text is a
518.58|4.5|sequence of characters in Python so when
520.62|5.04|I call the set Constructor on it I'm
523.08|5.1|just going to get the set of all the
525.66|5.82|characters that occur in this text
528.18|4.62|and then I call list on that to create a
531.48|3.12|list of those characters instead of just
532.8|3.36|a set so that I have an ordering an
534.6|3.6|arbitrary ordering
536.16|3.66|and then I sort that
538.2|3.24|so basically we get just all the
539.82|3.84|characters that occur in the entire data
541.44|3.959|set and they're sorted now the number of
543.66|4.14|them is going to be our vocabulary size
545.399|4.681|these are the possible elements of our
547.8|4.32|sequences and we see that when I print
550.08|4.74|here the characters
552.12|4.44|there's 65 of them in total there's a
554.82|3.3|space character and then all kinds of
556.56|4.62|special characters
558.12|4.98|and then capitals and lowercase letters
561.18|4.56|so that's our vocabulary and that's the
563.1|5.4|sort of like possible characters that
565.74|4.74|the model can see or emit
568.5|5.399|okay so next we would like to develop
570.48|5.94|some strategy to tokenize the input text
573.899|5.461|now when people say tokenize they mean
576.42|5.039|convert the raw text as a string to some
579.36|4.62|sequence of integers According to some
581.459|4.021|notebook According to some vocabulary of
583.98|3.84|possible elements
585.48|3.539|so as an example here we are going to be
587.82|2.699|building a character level language
589.019|3.241|model so we're simply going to be
590.519|2.94|translating individual characters into
592.26|3.42|integers
593.459|3.721|so let me show you a chunk of code that
595.68|3.36|sort of does that for us
597.18|3.96|so we're building both the encoder and
599.04|4.08|the decoder and let me just talk through
601.14|4.74|What's Happening Here
603.12|5.58|when we encode an arbitrary text like hi
605.88|5.94|there we're going to receive a list of
608.7|5.699|integers that represents that string so
611.82|4.26|for example 46 47 Etc
614.399|4.921|and then we also have the reverse
616.08|5.34|mapping so we can take this list and
619.32|3.06|decode it to get back the exact same
621.42|2.46|string
622.38|3.78|so it's really just like a translation
623.88|4.62|two integers and back for arbitrary
626.16|3.84|string and for us it is done on a
628.5|3.66|character level
630.0|4.38|now the way this was achieved is we just
632.16|3.78|iterate over all the characters here and
634.38|4.139|create a lookup table from the character
635.94|4.8|to the integer and vice versa and then
638.519|3.0|to encode some string we simply
640.74|3.42|translate all the characters
641.519|5.041|individually and to decode it back we
644.16|3.359|use the reverse mapping and concatenate
646.56|3.3|all of it
647.519|4.201|now this is only one of many possible
649.86|3.96|encodings or many possible sort of
651.72|4.14|tokenizers and it's a very simple one
653.82|3.9|but there's many other schemas that
655.86|4.74|people have come up with in practice so
657.72|4.98|for example Google uses a sentence piece
660.6|5.34|uh so sentence piece will also encode
662.7|6.18|text into integers but in a different
665.94|6.36|schema and using a different vocabulary
668.88|5.88|and sentence piece is a sub word sort of
672.3|4.8|tokenizer and what that means is that
674.76|3.78|you're not encoding entire words but
677.1|4.32|you're not also encoding individual
678.54|5.039|characters it's it's a sub word unit
681.42|4.56|level and that's usually what's adopted
683.579|4.561|in practice for example also openai has
685.98|5.28|this Library called tick token that uses
688.14|5.1|a pipe pair encoding tokenizer
691.26|4.259|um and that's what GPT uses
693.24|5.52|and you can also just encode words into
695.519|5.041|like hello world into a list of integers
698.76|3.36|so as an example I'm using the tick
700.56|3.779|token Library here
702.12|4.08|I'm getting the encoding for gpt2 or
704.339|3.841|that was used for gpt2
706.2|5.34|instead of just having 65 possible
708.18|4.62|characters or tokens they have 50 000
711.54|3.18|tokens
712.8|4.86|and so when they encode the exact same
714.72|5.22|string High there we only get a list of
717.66|4.98|three integers but those integers are
719.94|6.78|not between 0 and 64. they are between 0
722.64|6.96|and 5000 50 256.
726.72|5.58|so basically you can trade off the code
729.6|4.44|book size and the sequence lengths so
732.3|4.2|you can have a very long sequences of
734.04|4.2|integers with very small vocabularies or
736.5|2.7|you can have a short
738.24|3.659|um
739.2|6.12|sequences of integers with very large
741.899|6.361|vocabularies and so typically people use
745.32|4.74|in practice the sub word encodings but
748.26|3.18|I'd like to keep our tokenizer very
750.06|2.64|simple so we're using character level
751.44|2.82|tokenizer
752.7|3.9|and that means that we have very small
754.26|5.759|code books we have very simple encode
756.6|5.88|and decode functions but we do get very
760.019|3.721|long sequences as a result but that's
762.48|2.46|the level at which we're going to stick
763.74|2.94|with this lecture because it's the
764.94|4.26|simplest thing okay so now that we have
766.68|4.8|an encoder and a decoder effectively a
769.2|4.8|tokenizer we can tokenize the entire
771.48|4.02|training set of Shakespeare so here's a
774.0|2.76|chunk of code that does that
775.5|3.0|and I'm going to start to use the
776.76|4.259|pytorch library and specifically the
778.5|4.079|torch.tensor from the pytorch library
781.019|4.5|so we're going to take all of the text
782.579|5.461|in tiny Shakespeare encode it and then
785.519|4.62|wrap it into a torch.tensor to get the
788.04|3.599|data tensor so here's what the data
790.139|4.14|tensor looks like when I look at just
791.639|3.961|the first 1000 characters or the 1000
794.279|2.641|elements of it
795.6|3.479|so we see that we have a massive
796.92|4.14|sequence of integers and this sequence
799.079|4.021|of integers here is basically an
801.06|4.26|identical translation of the first 1000
803.1|4.38|characters here
805.32|4.56|so I believe for example that zero is a
807.48|5.58|new line character and maybe one is a
809.88|4.32|space not 100 sure but from now on the
813.06|3.36|entire data set of text is
814.2|4.5|re-represented as just it just stretched
816.42|3.84|out as a single very large uh sequence
818.7|3.24|of integers
820.26|3.6|let me do one more thing before we move
821.94|4.26|on here I'd like to separate out our
823.86|4.74|data set into a train and a validation
826.2|5.699|split so in particular we're going to
828.6|4.56|take the first 90 of the data set and
831.899|2.88|consider that to be the training data
833.16|3.78|for the Transformer and we're going to
834.779|4.86|withhold the last 10 percent at the end
836.94|4.32|of it to be the validation data and this
839.639|3.541|will help us understand to what extent
841.26|3.54|our model is overfitting so we're going
843.18|3.779|to basically hide and keep the
844.8|3.539|validation data on the side because we
846.959|4.32|don't want just a perfect memorization
848.339|4.381|of this exact Shakespeare we want a
851.279|4.381|neural network that sort of creates
852.72|5.16|Shakespeare like text and so it should
855.66|6.419|be fairly likely for it to produce
857.88|6.24|the actual like stowed away uh true
862.079|4.141|Shakespeare text
864.12|3.899|um and so we're going to use this to get
866.22|3.72|a sense of the overfitting okay so now
868.019|4.081|we would like to start plugging these
869.94|4.32|text sequences or integer sequences into
872.1|3.72|the Transformer so that it can train and
874.26|3.78|learn those patterns
875.82|3.9|now the important thing to realize is
878.04|3.78|we're never going to actually feed the
879.72|3.96|entire text into Transformer all at once
881.82|4.019|that would be computationally very
883.68|3.779|expensive and prohibitive so when we
885.839|3.901|actually train a Transformer on a lot of
887.459|3.781|these data sets we only work with chunks
889.74|3.599|of the data set and when we train the
891.24|3.599|Transformer we basically sample random
893.339|4.62|little chunks out of the training set
894.839|4.86|and train them just chunks at a time and
897.959|3.24|these chunks have basically some kind of
899.699|4.861|a length
901.199|5.281|and as a maximum length now the maximum
904.56|3.899|length typically at least in the code I
906.48|4.5|usually write is called block size
908.459|4.141|you can you can find it on the different
910.98|3.18|names like context length or something
912.6|3.599|like that let's start with the block
914.16|4.619|size of just eight and let me look at
916.199|4.2|the first train data characters the
918.779|4.981|first block size plus one characters
920.399|5.701|I'll explain why plus one in a second
923.76|5.4|so this is the first nine characters in
926.1|4.56|the sequence in the training set
929.16|3.239|now what I'd like to point out is that
930.66|4.02|when you sample a chunk of data like
932.399|3.781|this so say that these nine characters
934.68|3.54|out of the training set
936.18|3.659|this actually has multiple examples
938.22|3.419|packed into it
939.839|3.661|and that's because all of these
941.639|5.341|characters follow each other
943.5|5.76|and so what this thing is going to say
946.98|3.479|when we plug it into a Transformer is
949.26|3.24|we're going to actually simultaneously
950.459|3.721|train it to make prediction at every one
952.5|4.68|of these positions
954.18|5.099|now in the in a chunk of nine characters
957.18|3.959|there's actually eight individual
959.279|4.92|examples packed in there
961.139|6.361|so there's the example that one 18 when
964.199|6.601|in the context of 18 47 likely comes
967.5|7.44|next in the context of 18 and 47 56
970.8|7.2|comes next in the context of 1847-56 57
974.94|5.28|can come next and so on so that's the
978.0|4.68|eight individual examples let me
980.22|4.799|actually spell it out with code
982.68|4.68|so here's a chunk of code to illustrate
985.019|3.721|X are the inputs to the Transformer it
987.36|2.76|will just be the first block size
988.74|5.219|characters
990.12|5.88|y will be the next block size characters
993.959|4.74|so it's offset by one
996.0|5.399|and that's because y are the targets for
998.699|4.681|each position in the input
1001.399|4.74|and then here I'm iterating over all the
1003.38|5.639|block size of 8. and the context is
1006.139|4.56|always all the characters in X up to T
1009.019|3.721|and including t
1010.699|5.461|and the target is always the teeth
1012.74|5.519|character but in the targets array why
1016.16|3.78|so let me just run this
1018.259|3.901|and basically it spells out what I've
1019.94|4.56|said in words these are the eight
1022.16|6.299|examples hidden in a chunk of nine
1024.5|5.459|characters that we uh sampled from the
1028.459|3.661|training set
1029.959|4.681|I want to mention one more thing we
1032.12|5.1|train on all the eight examples here
1034.64|4.26|with context between one all the way up
1037.22|3.3|to context of block size
1038.9|3.059|and we train on that not just for
1040.52|2.76|computational reasons because we happen
1041.959|2.821|to have the sequence already or
1043.28|4.98|something like that it's not just done
1044.78|5.82|for efficiency it's also done to make
1048.26|4.56|the Transformer Network be used to
1050.6|5.28|seeing contexts all the way from as
1052.82|4.8|little as one all the way to block size
1055.88|3.9|and we'd like the transform to be used
1057.62|3.419|to seeing everything in between and
1059.78|3.24|that's going to be useful later during
1061.039|4.201|inference because while we're sampling
1063.02|3.96|we can start the sampling generation
1065.24|3.72|with as little as one character of
1066.98|3.78|context and the Transformer knows how to
1068.96|4.14|predict the next character with all the
1070.76|3.84|way up to just one context of one and so
1073.1|3.66|then it can predict everything up to
1074.6|3.9|block size and after block size we have
1076.76|4.26|to start truncating because the
1078.5|4.62|Transformer will never receive more than
1081.02|3.6|block size inputs when it's predicting
1083.12|3.48|the next character
1084.62|3.72|Okay so we've looked at the time
1086.6|2.88|dimension of the tensors that are going
1088.34|2.64|to be feeding into the Transformer
1089.48|3.84|there's one more Dimension to care about
1090.98|4.079|and that is the batch dimension and so
1093.32|4.32|as we're sampling these chunks of text
1095.059|3.541|we're going to be actually every time
1097.64|2.58|we're going to feed them into a
1098.6|3.72|Transformer we're going to have many
1100.22|3.6|batches of multiple chunks of text that
1102.32|3.12|are all like stacked up in a single
1103.82|3.3|tensor and that's just done for
1105.44|4.44|efficiency just so that we can keep the
1107.12|4.799|gpus busy because they are very good at
1109.88|4.62|parallel processing of
1111.919|4.561|um of data and so we just want to
1114.5|3.78|process multiple chunks all at the same
1116.48|3.059|time but those chunks are processed
1118.28|3.899|completely independently they don't talk
1119.539|4.14|to each other and so on so let me
1122.179|3.36|basically just generalize this and
1123.679|3.481|introduce a batch Dimension here's a
1125.539|3.421|chunk of code
1127.16|4.519|let me just run it and then I'm going to
1128.96|2.719|explain what it does
1131.78|3.36|so here because we're going to start
1133.28|4.38|sampling random locations in the data
1135.14|4.38|set to pull chunks from I am setting the
1137.66|3.66|seed so that
1139.52|3.3|um in the random number generator so
1141.32|3.3|that the numbers I see here are going to
1142.82|3.479|be the same numbers you see later if you
1144.62|3.24|try to reproduce this
1146.299|3.601|now the back size here is how many
1147.86|4.08|independent sequences we are processing
1149.9|3.72|every forward backward pass of the
1151.94|3.54|Transformer
1153.62|3.78|the block size as I explained is the
1155.48|2.88|maximum context length to make those
1157.4|3.84|predictions
1158.36|4.62|so let's say by size 4 block size 8 and
1161.24|4.319|then here's how we get batch
1162.98|3.9|for any arbitrary split if the split is
1165.559|2.701|a training split then we're going to
1166.88|3.0|look at train data otherwise and
1168.26|5.039|validata
1169.88|6.0|that gets us the data array and then
1173.299|3.901|when I Generate random positions to grab
1175.88|3.6|a chunk out of
1177.2|4.26|I actually grab I actually generate
1179.48|3.72|batch size number of
1181.46|4.62|random offsets
1183.2|5.099|so because this is four we are IX is
1186.08|4.86|going to be a four numbers that are
1188.299|4.681|randomly generated between 0 and Len of
1190.94|4.739|data minus block size so it's just
1192.98|5.699|random offsets into the training set
1195.679|5.701|and then X's as I explained are the
1198.679|3.901|first block size characters starting at
1201.38|4.98|I
1202.58|5.52|the Y's are the offset by one of that so
1206.36|3.9|just add plus one
1208.1|5.76|and then we're going to get those chunks
1210.26|7.159|for every one of integers I in IX and
1213.86|6.48|use a torch.stack to take all those
1217.419|4.541|one-dimensional tensors as we saw here
1220.34|4.62|and we're going to
1221.96|5.7|um stack them up at rows
1224.96|4.62|and so they all become a row in a four
1227.66|4.139|by eight tensor
1229.58|4.979|so here's where I'm printing then
1231.799|5.821|when I sample a batch XP and YB
1234.559|6.541|the input the Transformer now are
1237.62|7.32|the input X is the four by eight tensor
1241.1|6.42|four uh rows of eight columns
1244.94|4.619|and each one of these is a chunk of the
1247.52|4.98|training set
1249.559|4.98|and then the targets here are in the
1252.5|3.419|associated array Y and they will come in
1254.539|5.341|through the Transformer all the way at
1255.919|5.88|the end to create the loss function so
1259.88|4.74|they will give us the correct answer for
1261.799|5.341|every single position inside X
1264.62|4.2|and then these are the four independent
1267.14|4.919|rows
1268.82|6.239|so spelled out as we did before
1272.059|5.521|this four by eight array contains a
1275.059|4.321|total of 32 examples and they're
1277.58|3.599|completely independent as far as the
1279.38|4.86|Transformer is concerned
1281.179|6.12|uh so when the
1284.24|5.76|input is 24 the target is 43 or rather
1287.299|5.461|43 here in the Y array when the input is
1290.0|5.58|2443 the target is 58.
1292.76|6.84|when the input is 24 43.58 the target is
1295.58|6.18|5 Etc or like when it is a 5258 one the
1299.6|4.079|target is 58.
1301.76|4.26|right so you can sort of see this
1303.679|5.161|spelled out these are the 32 independent
1306.02|5.58|examples packed in to a single batch of
1308.84|4.98|the input X and then the desired targets
1311.6|7.92|are in y
1313.82|7.5|and so now this integer tensor of X is
1319.52|3.659|going to feed into the Transformer
1321.32|3.3|and that Transformer is going to
1323.179|3.961|simultaneously process all these
1324.62|4.74|examples and then look up the correct
1327.14|5.279|um integers to predict in every one of
1329.36|5.1|these positions in the tensor y okay so
1332.419|3.301|now that we have our batch of input that
1334.46|3.18|we'd like to feed into a Transformer
1335.72|4.14|let's start basically feeding this into
1337.64|3.96|neural networks now we're going to start
1339.86|2.939|off with the simplest possible neural
1341.6|2.939|network which in the case of language
1342.799|3.36|modeling in my opinion is the bigram
1344.539|3.0|language model and we've covered the
1346.159|4.201|background language model in my make
1347.539|4.861|more series in a lot of depth and so
1350.36|3.66|here I'm going to sort of go faster and
1352.4|3.779|let's just implement the pytorch module
1354.02|3.84|directly that implements the bigram
1356.179|4.441|language model
1357.86|3.96|so I'm importing the pytorch and then
1360.62|3.539|module
1361.82|3.96|uh for reproducibility
1364.159|3.481|and then here I'm constructing a diagram
1365.78|3.24|language model which is a subclass of NN
1367.64|3.84|module
1369.02|4.74|and then I'm calling it and I'm passing
1371.48|4.319|in the inputs and the targets
1373.76|3.96|and I'm just printing now when the
1375.799|4.081|inputs and targets come here you see
1377.72|5.52|that I'm just taking the index the
1379.88|4.679|inputs X here which I rename to idx and
1383.24|2.819|I'm just passing them into this token
1384.559|3.721|embedding table
1386.059|3.421|so what's going on here is that here in
1388.28|3.66|the Constructor
1389.48|5.1|we are creating a token embedding table
1391.94|4.38|and it is of size vocab size by vocab
1394.58|4.32|size
1396.32|4.62|and we're using nn.embedding which is a
1398.9|4.38|very thin wrapper around basically a
1400.94|3.119|tensor of shape both capsized by vocab
1403.28|2.7|size
1404.059|4.74|and what's happening here is that when
1405.98|4.8|we pass idx here every single integer in
1408.799|4.141|our input is going to refer to this
1410.78|3.96|embedding table and is going to pluck
1412.94|5.099|out a row of that embedding table
1414.74|5.1|corresponding to its index so 24 here
1418.039|4.801|we'll go to the embedding table and
1419.84|5.64|we'll pluck out the 24th row and then 43
1422.84|4.68|will go here and block out the 43rd row
1425.48|4.74|Etc and then Pi torch is going to
1427.52|6.42|arrange all of this into a batch by Time
1430.22|8.16|by Channel tensor in this case batch is
1433.94|7.619|4 time is 8 and C which is the channels
1438.38|4.5|is vocab size or 65. and so we're just
1441.559|4.681|going to pluck out all those rows
1442.88|4.62|arrange them in a b by T by C and now
1446.24|3.38|we're going to interpret this as the
1447.5|5.1|logits which are basically the scores
1449.62|5.26|for the next character in the sequence
1452.6|4.8|and so what's happening here is we are
1454.88|4.32|predicting what comes next based on just
1457.4|4.68|the individual identity of a single
1459.2|4.68|token and you can do that because
1462.08|3.3|um I mean currently the tokens are not
1463.88|3.0|talking to each other and they're not
1465.38|4.32|seeing any context except for they're
1466.88|5.4|just seeing themselves so I'm a I'm a
1469.7|4.02|token number five and then I can
1472.28|3.18|actually make pretty decent predictions
1473.72|3.54|about what comes next just by knowing
1475.46|4.62|that I'm token five because some
1477.26|5.88|characters know cert follow other
1480.08|5.099|characters in in typical scenarios so we
1483.14|3.96|saw a lot of this in a lot more depth in
1485.179|4.38|the make more series and here if I just
1487.1|6.24|run this then we currently get the
1489.559|5.641|predictions the scores the logits for
1493.34|3.48|every one of the four by eight positions
1495.2|3.42|now that we've made predictions about
1496.82|3.66|what comes next we'd like to evaluate
1498.62|4.08|the loss function and so in make more
1500.48|4.079|series we saw that a good way to measure
1502.7|4.02|a loss or like a quality of the
1504.559|4.081|predictions is to use the negative log
1506.72|3.42|likelihood loss which is also
1508.64|3.12|implemented in pytorch under the name
1510.14|4.32|cross entropy
1511.76|5.279|so what we'd like to do here is
1514.46|4.74|loss is the cross entropy on the
1517.039|4.321|predictions and the targets and so this
1519.2|4.859|measures the quality of the logits with
1521.36|4.08|respect to the Targets in other words we
1524.059|4.261|have the identity of the next character
1525.44|4.979|so how well are we predicting the next
1528.32|4.2|character based on Illusions and
1530.419|5.821|intuitively the correct
1532.52|5.159|um the correct dimension of logits uh
1536.24|3.24|depending on whatever the target is
1537.679|3.24|should have a very high number and all
1539.48|3.059|the other dimensions should be very low
1540.919|3.24|number right
1542.539|3.721|now the issue is that this won't
1544.159|6.38|actually this is what we want we want to
1546.26|4.279|basically output the logits and the loss
1551.0|4.74|this is what we want but unfortunately
1552.7|5.38|uh this won't actually run
1555.74|5.58|we get an error message but intuitively
1558.08|6.54|we want to measure this now when we go
1561.32|5.64|to the pi torch cross entropy
1564.62|2.88|a documentation here
1566.96|2.52|um
1567.5|4.08|we're trying to call the cross entropy
1569.48|3.72|in its functional form so that means we
1571.58|2.579|don't have to create like a module for
1573.2|3.479|it
1574.159|4.201|but here when we go to the documentation
1576.679|3.901|you have to look into the details of how
1578.36|4.439|pytorch expects these inputs and
1580.58|4.32|basically the issue here is by torch
1582.799|4.081|expects if you have multi-dimensional
1584.9|4.56|input which we do because we have a b by
1586.88|5.82|T by C tensor then it actually really
1589.46|5.219|wants the channels to be the second
1592.7|5.88|dimension here
1594.679|7.321|so if you um so basically it wants a b
1598.58|5.52|by C by T instead of a b by T by C
1602.0|3.9|and so it's just the details of how
1604.1|5.1|pytorch treats
1605.9|5.46|um these kinds of inputs and so we don't
1609.2|3.479|actually want to deal with that so what
1611.36|3.48|we're going to do instead is we need to
1612.679|3.421|basically reshape our logits so here's
1614.84|3.3|what I like to do I like to take
1616.1|4.98|basically give names to the dimensions
1618.14|4.38|so launches.shape is B by T by C and
1621.08|4.38|unpack those numbers
1622.52|4.5|and then let's say that logits equals
1625.46|4.26|logits.view
1627.02|6.6|and we want it to be a b times c b times
1629.72|6.24|T by C so just a two-dimensional array
1633.62|4.32|right so we're going to take all the
1635.96|2.88|we're going to take all of these
1637.94|2.88|um
1638.84|3.36|positions here and we're going to uh
1640.82|2.82|stretch them out in a one-dimensional
1642.2|3.599|sequence
1643.64|4.139|and preserve the channel Dimension as
1645.799|3.24|the second dimension
1647.779|2.701|so we're just kind of like stretching
1649.039|3.0|out the array so it's two-dimensional
1650.48|4.319|and in that case it's going to better
1652.039|4.14|conform to what pi torch sort of expects
1654.799|3.36|in its dimensions
1656.179|4.161|now we have to do the same to targets
1658.159|7.441|because currently targets
1660.34|8.56|are of shape B by T and we want it to be
1665.6|4.74|just B times T so one dimensional now
1668.9|4.32|alternatively you could always still
1670.34|4.319|just do -1 because Pi torch will guess
1673.22|3.42|what this should be if you want to lay
1674.659|3.421|it out but let me just be explicit on
1676.64|3.779|say Q times t
1678.08|4.68|once we've reshaped this it will match
1680.419|3.781|the cross entropy case
1682.76|3.98|and then we should be able to evaluate
1684.2|2.54|our loss
1686.96|5.28|okay so with that right now and we can
1689.779|4.681|do loss and So currently we see that the
1692.24|5.52|loss is 4.87
1694.46|5.219|now because our we have 65 possible
1697.76|4.26|vocabulary elements we can actually
1699.679|3.301|guess at what the loss should be and in
1702.02|3.24|particular
1702.98|5.46|we covered negative log likelihood in a
1705.26|5.159|lot of detail we are expecting log or
1708.44|5.4|long of
1710.419|5.541|um 1 over 65 and negative of that
1713.84|5.699|so we're expecting the loss to be about
1715.96|4.839|4.1217 but we're getting 4.87 and so
1719.539|3.24|that's telling us that the initial
1720.799|4.141|predictions are not super diffuse
1722.779|3.9|they've got a little bit of entropy and
1724.94|5.64|so we're guessing wrong
1726.679|6.541|uh so uh yes but actually we're I able
1730.58|4.62|we are able to evaluate the loss okay so
1733.22|4.68|now that we can evaluate the quality of
1735.2|4.38|the model on some data we'd likely also
1737.9|3.96|be able to generate from the model so
1739.58|3.479|let's do the generation now I'm going to
1741.86|2.939|go again a little bit faster here
1743.059|3.541|because I covered all this already in
1744.799|3.48|previous videos
1746.6|5.42|so
1748.279|3.741|here's a generate function for the model
1752.299|4.98|so we take some uh we take the the same
1755.36|3.96|kind of input idx here
1757.279|5.341|and basically
1759.32|6.359|this is the current context of some
1762.62|5.82|characters in a batch in some batch
1765.679|5.041|so it's also B by T and the job of
1768.44|3.959|generate is to basically take this B by
1770.72|3.6|T and extend it to be B by T plus one
1772.399|3.9|plus two plus three and so it's just
1774.32|3.78|basically it contains the generation in
1776.299|2.88|all the batch dimensions in the time
1778.1|3.299|dimension
1779.179|3.781|So that's its job and we'll do that for
1781.399|2.941|Max new tokens
1782.96|3.18|so you can see here on the bottom
1784.34|4.559|there's going to be some stuff here but
1786.14|5.759|on the bottom whatever is predicted is
1788.899|4.681|concatenated on top of the previous idx
1791.899|3.66|along the First Dimension which is the
1793.58|2.94|time Dimension to create a b by T plus
1795.559|3.24|one
1796.52|4.32|so that becomes the new idx so the job
1798.799|4.74|of generators to take a b by T and make
1800.84|5.1|it a b by T plus one plus two plus three
1803.539|4.62|as many as we want maximum tokens so
1805.94|3.839|this is the generation from the model
1808.159|3.301|now inside the generation what we're
1809.779|3.661|what are we doing we're taking the
1811.46|5.28|current indices we're getting the
1813.44|4.5|predictions so we get those are in the
1816.74|3.0|logits
1817.94|3.0|and then the loss here is going to be
1819.74|2.88|ignored because
1820.94|3.599|um we're not we're not using that and we
1822.62|3.6|have no targets that are sort of ground
1824.539|3.901|truth targets that we're going to be
1826.22|4.439|comparing with
1828.44|5.16|then once we get the logits we are only
1830.659|5.341|focusing on the last step so instead of
1833.6|5.34|a b by T by C we're going to pluck out
1836.0|4.02|the negative one the last element in the
1838.94|2.339|time dimension
1840.02|2.639|because those are the predictions for
1841.279|3.301|what comes next
1842.659|5.101|so that this is the logits which we then
1844.58|4.62|convert to probabilities via softmax and
1847.76|3.299|then we use torch that multinomial to
1849.2|4.56|sample from those probabilities and we
1851.059|5.641|ask by torch to give us one sample
1853.76|5.58|and so idx next will become a b by one
1856.7|4.56|because in each one of the batch
1859.34|3.719|Dimensions we're going to have a single
1861.26|4.32|prediction for what comes next so this
1863.059|4.141|num samples equals one will make this be
1865.58|2.88|a one
1867.2|3.359|and then we're going to take those
1868.46|3.48|integers that come from the sampling
1870.559|2.881|process according to the probability
1871.94|3.54|distribution given here
1873.44|3.599|and those integers got just concatenated
1875.48|4.079|on top of the current sort of like
1877.039|4.561|running stream of integers and this
1879.559|4.62|gives us a p by T plus one
1881.6|4.86|and then we can return that now one
1884.179|5.401|thing here is you see how I'm calling
1886.46|5.339|self of idx which will end up going to
1889.58|4.38|the forward function I'm not providing
1891.799|4.98|any Targets So currently this would give
1893.96|5.339|an error because targets is uh is uh
1896.779|4.62|sort of like not given so target has to
1899.299|5.341|be optional so targets is none by
1901.399|6.181|default and then if targets is none then
1904.64|5.88|there's no loss to create so it's just
1907.58|5.339|loss is none but else all of this
1910.52|4.379|happens and we can create a loss
1912.919|2.581|so this will make it so
1914.899|2.28|um
1915.5|3.24|if we have the targets we provide them
1917.179|4.261|and get a loss if we have no targets
1918.74|4.5|we'll just get the logits
1921.44|3.18|so this here will generate from the
1923.24|6.14|model
1924.62|4.76|um and let's take that for a ride now
1929.419|3.061|oops
1930.679|3.661|so I have another code chunk here which
1932.48|3.9|will generate for the model from the
1934.34|4.92|model and okay this is kind of crazy so
1936.38|6.679|maybe let me let me break this down
1939.26|3.799|so these are the idx right
1944.779|4.861|I'm creating a batch will be just one
1947.36|4.14|time will be just one
1949.64|4.44|so I'm creating a little one by one
1951.5|5.7|tensor and it's holding a zero
1954.08|5.219|and the D type the data type is integer
1957.2|5.64|so 0 is going to be how we kick off the
1959.299|5.821|generation and remember that zero is uh
1962.84|3.66|is the element standing for a new line
1965.12|3.36|character so it's kind of like a
1966.5|4.26|reasonable thing to to feed in as the
1968.48|4.319|very first character in a sequence to be
1970.76|4.5|the new line
1972.799|3.841|um so it's going to be idx which we're
1975.26|3.36|going to feed in here then we're going
1976.64|3.96|to ask for 100 tokens
1978.62|2.939|and then enter generate will continue
1980.6|4.62|that
1981.559|6.12|now because uh generate works on the
1985.22|5.28|level of batches we then have to index
1987.679|4.081|into the zero throw to basically unplug
1990.5|4.44|the um
1991.76|7.019|the single bash Dimension that exists
1994.94|5.88|and then that gives us a um
1998.779|4.14|time steps it's just a one-dimensional
2000.82|4.56|array of all the indices which we will
2002.919|5.341|convert to simple python list
2005.38|5.899|from pytorch tensor so that that can
2008.26|5.7|feed into our decode function and
2011.279|4.721|convert those integers into text
2013.96|4.8|so let me bring this back and we're
2016.0|5.1|generating 100 tokens let's run
2018.76|4.799|and uh here's the generation that we
2021.1|3.959|achieved so obviously it's garbage and
2023.559|3.541|the reason it's garbage is because this
2025.059|4.141|is a totally random model so next up
2027.1|3.48|we're going to want to train this model
2029.2|2.819|now one more thing I wanted to point out
2030.58|3.24|here is
2032.019|4.02|this function is written to be General
2033.82|4.14|but it's kind of like ridiculous right
2036.039|3.721|now because
2037.96|4.199|we're feeding in all this we're building
2039.76|5.039|out this context and we're concatenating
2042.159|4.5|it all and we're always feeding it all
2044.799|3.661|into the model
2046.659|3.24|but that's kind of ridiculous because
2048.46|3.179|this is just a simple background model
2049.899|4.801|so to make for example this prediction
2051.639|4.381|about K we only needed this W but
2054.7|3.659|actually what we fed into the model is
2056.02|4.74|we fed the entire sequence and then we
2058.359|3.78|only looked at the very last piece and
2060.76|3.3|predicted k
2062.139|3.96|so the only reason I'm writing it in
2064.06|4.02|this way is because right now this is a
2066.099|4.28|bygram model but I'd like to keep this
2068.08|5.96|function fixed and I'd like it to work
2070.379|6.22|later when our character is actually
2074.04|4.72|basically look further in the history
2076.599|4.861|and so right now the history is not used
2078.76|5.159|so this looks silly but eventually the
2081.46|4.8|history will be used and so that's why
2083.919|4.98|we want to do it this way so just a
2086.26|5.159|quick comment on that so now we see that
2088.899|4.321|this is um random so let's train the
2091.419|4.26|model so it becomes a bit less random
2093.22|3.659|okay let's Now train the model so first
2095.679|4.021|what I'm going to do is I'm going to
2096.879|5.521|create a pytorch optimization object
2099.7|3.98|so here we are using the optimizer
2102.4|3.6|atom W
2103.68|3.82|now in the make more series we've only
2106.0|3.24|ever used stochastic gradient descent
2107.5|4.5|the simplest possible Optimizer which
2109.24|3.96|you can get using the SGD instead but I
2112.0|3.42|want to use Adam which is a much more
2113.2|5.52|advanced and popular Optimizer and it
2115.42|4.919|works extremely well for a typical good
2118.72|4.56|setting for the learning rate is roughly
2120.339|4.74|3E negative four but for very very small
2123.28|3.299|networks luck is the case here you can
2125.079|3.121|get away with much much higher learning
2126.579|3.061|rates running negative three or even
2128.2|4.08|higher probably
2129.64|4.68|but let me create the optimizer object
2132.28|3.96|which will basically take the gradients
2134.32|3.36|and update the parameters using the
2136.24|3.3|gradients
2137.68|3.96|and then here
2139.54|3.299|our batch size up above was only four so
2141.64|3.54|let me actually use something bigger
2142.839|3.421|let's say 32 and then for some number of
2145.18|3.12|steps
2146.26|5.64|um we are sampling a new batch of data
2148.3|4.74|we're evaluating the loss we're zeroing
2151.9|3.42|out all the gradients from the previous
2153.04|4.02|step getting the gradients for all the
2155.32|3.66|parameters and then using those
2157.06|4.08|gradients to update our parameters so
2158.98|3.54|typical training loop as we saw in the
2161.14|4.32|make more series
2162.52|5.04|so let me now uh run this
2165.46|5.18|for say 100 iterations and let's see
2167.56|3.08|what kind of losses we're gonna get
2170.68|5.04|so we started around 4.7
2173.56|3.36|and now we're going to down to like 4.6
2175.72|3.18|4.5
2176.92|3.72|Etc so the optimization is definitely
2178.9|4.86|happening but
2180.64|4.74|um let's uh sort of try to increase the
2183.76|3.12|number of iterations and only print at
2185.38|2.82|the end
2186.88|3.42|because we probably will not train for
2188.2|6.26|longer
2190.3|4.16|okay so we're down to 3.6 roughly
2195.46|3.26|roughly down to three
2201.52|3.68|this is the most janky optimization
2207.16|4.22|okay it's working let's just do ten
2208.96|2.42|thousand
2211.42|5.76|and then from here we want to copy this
2215.2|3.18|and hopefully we're going to get
2217.18|2.939|something reasonable and of course it's
2218.38|3.36|not going to be Shakespeare from a
2220.119|4.921|background model but at least we see
2221.74|4.44|that the loss is improving and hopefully
2225.04|2.64|we're expecting something a bit more
2226.18|3.78|reasonable
2227.68|3.84|okay so we're down there about 2.5 ish
2229.96|2.639|let's see what we get
2231.52|3.0|okay
2232.599|3.061|dramatic improvements certainly on what
2234.52|3.48|we had here
2235.66|3.36|so let me just increase the number of
2238.0|2.52|tokens
2239.02|3.72|okay so we see that we're starting to
2240.52|4.079|get something at least like
2242.74|3.96|reasonable ish
2244.599|5.101|um
2246.7|4.919|certainly not Shakespeare but the model
2249.7|4.379|is making progress so that is the
2251.619|5.941|simplest possible model
2254.079|5.401|so now what I'd like to do is
2257.56|3.42|obviously that this is a very simple
2259.48|3.18|model because the tokens are not talking
2260.98|4.379|to each other so given the previous
2262.66|4.02|context of whatever was generated we're
2265.359|2.821|only looking at the very last character
2266.68|4.26|to make the predictions about what comes
2268.18|5.04|next so now these uh now these tokens
2270.94|4.56|have to start talking to each other and
2273.22|3.3|figuring out what is in the context so
2275.5|2.64|that they can make better predictions
2276.52|3.66|for what comes next and this is how
2278.14|4.26|we're going to kick off the Transformer
2280.18|3.72|okay so next I took the code that we
2282.4|3.719|developed in this Jupiter notebook and I
2283.9|4.32|converted it to be a script and I'm
2286.119|4.141|doing this because I just want to
2288.22|3.54|simplify our intermediate work into just
2290.26|2.819|the final product that we have at this
2291.76|3.96|point
2293.079|4.02|so in the top here I put all the hyper
2295.72|2.76|parameters that we've defined I
2297.099|3.721|introduced a few and I'm going to speak
2298.48|3.359|to that in a little bit otherwise a lot
2300.82|3.18|of this should be recognizable
2301.839|4.861|reproducibility
2304.0|5.82|read data get the encoder in the decoder
2306.7|6.12|create the training test splits I use
2309.82|5.94|the uh kind of like data loader that
2312.82|5.039|gets a batch of the inputs and targets
2315.76|3.18|this is new and I'll talk about it in a
2317.859|2.401|second
2318.94|3.48|now this is the background language
2320.26|3.96|model that we developed and it can
2322.42|4.199|forward and give us a logits and loss
2324.22|4.2|and it can generate
2326.619|5.22|and then here we are creating the
2328.42|5.22|optimizer and this is the training Loop
2331.839|3.661|so everything here should look pretty
2333.64|4.439|familiar now some of the small things
2335.5|4.92|that I added number one I added the
2338.079|4.861|ability to run on a GPU if you have it
2340.42|4.8|so if you have a GPU then you can this
2342.94|4.679|will use Cuda instead of just CPU and
2345.22|4.74|everything will be a lot more faster now
2347.619|3.781|when device becomes screwed up then we
2349.96|3.96|need to make sure that when we load the
2351.4|5.34|data we move it to device
2353.92|5.1|when we create the model we want to move
2356.74|4.98|the model parameters to device
2359.02|4.38|so as an example here we have the NN
2361.72|4.68|embedding table and it's got a double
2363.4|4.86|weight inside it which stores the sort
2366.4|3.84|of lookup table so that would be moved
2368.26|4.38|to the GPU so that all the calculations
2370.24|3.66|here happen on the GPU and they can be a
2372.64|2.699|lot faster
2373.9|3.9|and then finally here when I'm creating
2375.339|3.841|the context that feeds into generate I
2377.8|2.52|have to make sure that I create on the
2379.18|4.04|device
2380.32|7.2|number two what I introduced is
2383.22|7.6|the fact that here in the training Loop
2387.52|4.2|here I was just printing the Lost dot
2390.82|2.88|item
2391.72|3.18|inside the training Loop but this is a
2393.7|3.6|very noisy measurement of the current
2394.9|3.54|loss because every batch will be more or
2397.3|4.86|less lucky
2398.44|6.48|and so what I want to do usually is I
2402.16|5.64|have an estimate loss function and the
2404.92|3.96|estimated loss basically then goes up
2407.8|4.14|here
2408.88|4.68|and it averages up the loss over
2411.94|3.78|multiple batches
2413.56|4.62|so in particular we're going to iterate
2415.72|4.139|invalider times and we're going to
2418.18|3.48|basically get our loss and then we're
2419.859|3.901|going to get the average loss for both
2421.66|3.36|splits and so this will be a lot less
2423.76|3.24|noisy
2425.02|3.9|so here what we call the estimate loss
2427.0|4.92|we're going to report the pretty
2428.92|5.1|accurate train and validation loss
2431.92|3.96|now when we come back up you'll notice a
2434.02|4.44|few things here I'm setting the model to
2435.88|4.86|evaluation phase and down here I'm
2438.46|4.5|resetting it back to training phase
2440.74|3.06|now right now for our model as is this
2442.96|3.06|this doesn't actually do anything
2443.8|5.819|because the only thing inside this model
2446.02|6.9|is this nn.embedding and
2449.619|4.921|um this this network would behave both
2452.92|3.84|would be have the same in both
2454.54|3.6|evaluation mode and training mode we
2456.76|3.66|have no Dropout layers we have no
2458.14|4.74|bathroom layers Etc but it is a good
2460.42|4.74|practice to Think Through what mode your
2462.88|4.5|neural network is in because some layers
2465.16|4.32|will have different Behavior at
2467.38|3.6|inference time or training time
2469.48|3.24|and
2470.98|3.72|there's also this context manager
2472.72|3.359|torch.nograd and this is just telling
2474.7|3.659|pytorch that everything that happens
2476.079|5.581|inside this function we will not call
2478.359|4.74|that backward on and so Patrick can be a
2481.66|3.6|lot more efficient with its memory use
2483.099|4.081|because it doesn't have to store all the
2485.26|4.14|intermediate variables because we're
2487.18|3.54|never going to call backward and so it
2489.4|3.3|can it can be a lot more memory
2490.72|4.56|efficient in that way so also a good
2492.7|4.8|practice to tell Pi torch when we don't
2495.28|6.24|intend to do back propagation
2497.5|6.18|so right now the script is about 120
2501.52|3.599|lines of code of and that's kind of our
2503.68|3.72|starter code
2505.119|4.381|I'm calling it background.pi and I'm
2507.4|4.86|going to release it later now running
2509.5|4.14|this script gives us output in the
2512.26|2.4|terminal and it looks something like
2513.64|3.959|this
2514.66|4.8|it basically as I ran this code it was
2517.599|3.601|giving me the train loss and Val loss
2519.46|3.3|and we see that we convert to somewhere
2521.2|3.84|around 2.5
2522.76|5.52|with the migrant model and then here's
2525.04|5.16|the sample that we produced at the end
2528.28|3.66|and so we have everything packaged up in
2530.2|3.96|the script and we're in a good position
2531.94|4.38|now to iterate on this okay so we are
2534.16|4.26|almost ready to start writing our very
2536.32|4.68|first self-attention block for
2538.42|5.58|processing these tokens
2541.0|5.099|now before we actually get there I want
2544.0|3.66|to get you used to a mathematical trick
2546.099|3.841|that is used in the self attention
2547.66|4.5|inside a Transformer and is really just
2549.94|5.04|like at the heart of an efficient
2552.16|4.38|implementation of self-attention and so
2554.98|3.72|I want to work with this toy example you
2556.54|3.539|just get used to this operation and then
2558.7|4.98|it's going to make it much more clear
2560.079|5.221|once we actually get to um to it in the
2563.68|4.5|script again
2565.3|4.68|so let's create a b by T by C where B T
2568.18|4.62|and C are just 4 8 and 2 in the story
2569.98|6.18|example and these are basically channels
2572.8|4.799|and we have batches and we have the time
2576.16|5.76|component and we have some information
2577.599|6.121|at each point in the sequence so C
2581.92|4.5|now what we would like to do is we would
2583.72|5.34|like these um tokens so we have up to
2586.42|4.199|eight tokens here in a batch and these
2589.06|3.0|eight tokens are currently not talking
2590.619|2.821|to each other and we would like them to
2592.06|2.64|talk to each other we'd like to couple
2593.44|4.62|them
2594.7|5.639|and in particular we don't we we want to
2598.06|3.96|couple them in a very specific way so
2600.339|4.321|the token for example at the fifth
2602.02|4.62|location it should not communicate with
2604.66|3.0|tokens in the sixth seventh and eighth
2606.64|3.42|location
2607.66|3.24|because those are future tokens in the
2610.06|2.58|sequence
2610.9|3.6|the token on the fifth location should
2612.64|3.36|only talk to the one in the fourth third
2614.5|3.96|second and first
2616.0|4.26|so it's only so information only flows
2618.46|3.78|from previous context to the current
2620.26|3.48|timestamp and we cannot get any
2622.24|4.2|information from the future because we
2623.74|3.96|are about to try to predict the future
2626.44|3.48|so
2627.7|4.98|what is the easiest way for tokens to
2629.92|5.22|communicate okay the easiest way I would
2632.68|4.08|say is okay if we are up to if we're a
2635.14|3.84|fifth token and I'd like to communicate
2636.76|5.04|with my past the simplest way we can do
2638.98|6.0|that is to just do a weight is to just
2641.8|5.22|do an average of all the um of all the
2644.98|4.139|preceding elements so for example if I'm
2647.02|5.22|the fifth token I would like to take the
2649.119|5.581|channels that make up that are
2652.24|4.2|information at my step but then also the
2654.7|3.6|channels from the four step third step
2656.44|4.02|second step in the first step I'd like
2658.3|3.779|to average those up and then that would
2660.46|4.379|become sort of like a feature Vector
2662.079|3.661|that summarizes me in the context of my
2664.839|3.181|history
2665.74|4.32|now of course just doing a sum or like
2668.02|3.72|an average is an extremely weak form of
2670.06|3.72|interaction like this communication is
2671.74|3.06|extremely lossy we've lost a ton of
2673.78|3.66|information about the spatial
2674.8|4.2|Arrangements of all those tokens but
2677.44|3.48|that's okay for now we'll see how we can
2679.0|4.2|bring that information back later
2680.92|3.36|for now what we would like to do is
2683.2|2.76|for every single batch element
2684.28|4.44|independently
2685.96|5.76|for every teeth token in that sequence
2688.72|5.94|we'd like to now calculate the average
2691.72|5.58|of all the vectors in all the previous
2694.66|5.22|tokens and also at this token
2697.3|4.44|so let's write that out
2699.88|4.08|um I have a small snippet here and
2701.74|4.8|instead of just fumbling around let me
2703.96|4.32|just copy paste it and talk to it
2706.54|3.18|so in other words we're going to create
2708.28|3.78|X
2709.72|5.399|and bow is short for backup words
2712.06|4.2|because backup words is um is kind of
2715.119|3.061|like um
2716.26|3.54|a term that people use when you are just
2718.18|4.26|averaging up things so it's just a bag
2719.8|4.44|of words basically there's a word stored
2722.44|3.36|on every one of these eight locations
2724.24|3.119|and we're doing a bag of words such as
2725.8|3.24|averaging
2727.359|3.48|so in the beginning we're going to say
2729.04|3.36|that it's just initialized at Zero and
2730.839|3.061|then I'm doing a for Loop here so we're
2732.4|3.78|not being efficient yet that's coming
2733.9|3.719|but for now we're just iterating over
2736.18|3.84|all the batch Dimensions independently
2737.619|6.421|iterating over time
2740.02|7.5|and then the previous tokens are at this
2744.04|6.9|batch Dimension and then everything up
2747.52|6.78|to and including the teeth token okay
2750.94|5.7|so when we slice out X in this way xrev
2754.3|4.92|Becomes of shape
2756.64|5.58|um how many T elements there were in the
2759.22|4.619|past and then of course C so all the two
2762.22|2.94|dimensional information from these log
2763.839|4.74|tokens
2765.16|6.6|so that's the previous sort of chunk of
2768.579|5.28|um tokens from my current sequence
2771.76|4.14|and then I'm just doing the average or
2773.859|4.561|the mean over the zeroth dimension so
2775.9|4.8|I'm averaging out the time here
2778.42|3.78|and I'm just going to get a little C
2780.7|4.379|one-dimensional Vector which I'm going
2782.2|5.879|to store in X background words
2785.079|6.0|so I can run this and uh this is not
2788.079|5.04|going to be very informative because
2791.079|4.981|let's see so this is x sub 0. so this is
2793.119|5.22|the zeroth batch element and then expo
2796.06|4.799|at zero now
2798.339|5.76|you see how the at the first location
2800.859|4.921|here you see that the two are equal and
2804.099|3.48|that's because it's we're just doing an
2805.78|4.68|average of this one token
2807.579|4.141|but here this one is now an average of
2810.46|3.96|these two
2811.72|4.08|and now this one is an average of these
2814.42|3.36|three
2815.8|4.86|and so on
2817.78|5.28|so uh and this last one is the average
2820.66|4.26|of all of these elements so vertical
2823.06|5.34|average just averaging up all the tokens
2824.92|5.76|now gives this outcome here
2828.4|4.919|so this is all well and good but this is
2830.68|3.96|very inefficient now the trick is that
2833.319|3.901|we can be very very efficient about
2834.64|4.86|doing this using matrix multiplication
2837.22|4.02|so that's the mathematical trick and let
2839.5|3.42|me show you what I mean let's work with
2841.24|4.02|the toy example here
2842.92|5.159|let me run it and I'll explain
2845.26|4.8|I have a simple Matrix here that is a
2848.079|3.961|three by three of all ones
2850.06|3.299|a matrix B of just random numbers and
2852.04|3.12|it's a three by two
2853.359|4.021|and a matrix C which will be three by
2855.16|4.14|three multiply three by two which will
2857.38|3.719|give out a three by two
2859.3|2.4|so here we're just using
2861.099|2.281|um
2861.7|5.159|matrix multiplication
2863.38|7.58|so a multiply B gives us C
2866.859|7.141|okay so how are these numbers in C
2870.96|6.46|achieved right so this number in the top
2874.0|6.0|left is the first row of a DOT product
2877.42|4.98|with the First Column of B
2880.0|3.78|and since all the the row of a right now
2882.4|3.84|is all just once
2883.78|5.1|then the dot product here with with this
2886.24|5.28|column of B is just going to do a sum of
2888.88|4.62|these of this column so 2 plus 6 plus 6
2891.52|4.26|is 14.
2893.5|4.38|the element here and the output of C is
2895.78|4.319|also the first column here the first row
2897.88|5.76|of a multiplied now with the second
2900.099|4.74|column of B so 7 plus 4 plus plus 5 is
2903.64|2.4|16.
2904.839|3.181|now you see that there's repeating
2906.04|3.84|elements here so this 14 again is
2908.02|3.48|because this row is again all once and
2909.88|5.219|it's multiplying the First Column of B
2911.5|6.119|so we get 14. and this one is and so on
2915.099|5.161|so this last number here is the last row
2917.619|5.581|dot product last column
2920.26|5.76|now the trick here is uh the following
2923.2|5.34|this is just a boring number of
2926.02|5.059|um it's just a boring array of all ones
2928.54|6.24|but torch has this function called trell
2931.079|6.101|which is short for a triangular
2934.78|4.02|uh something like that and you can wrap
2937.18|4.26|it in torched at once and it will just
2938.8|3.72|return the lower triangular portion of
2941.44|3.12|this
2942.52|4.319|okay
2944.56|3.9|so now it will basically zero out uh
2946.839|4.681|these guys here so we just get the lower
2948.46|5.42|triangular part well what happens if we
2951.52|2.36|do that
2955.119|4.321|so now we'll have a like this and B like
2957.88|2.34|this and now what are we getting here in
2959.44|2.94|C
2960.22|5.46|well what is this number well this is
2962.38|5.88|the first row times the First Column and
2965.68|4.98|because this is zeros
2968.26|4.02|uh these elements here are now ignored
2970.66|3.72|so we just get a two
2972.28|4.799|and then this number here is the first
2974.38|4.439|row times the second column and because
2977.079|4.02|these are zeros they get ignored and
2978.819|3.54|it's just seven the seven multiplies
2981.099|3.0|this one
2982.359|4.621|but look what happened here because this
2984.099|4.381|is one and then zeros we what ended up
2986.98|3.78|happening is we're just plucking out the
2988.48|3.54|row of this row of B and that's what we
2990.76|6.3|got
2992.02|6.839|now here we have 1 1 0. so here one one
2997.06|3.48|zero dot product with these two columns
2998.859|4.381|will now give us two plus six which is
3000.54|5.279|eight and seven plus four which is 11.
3003.24|5.46|and because this is one one one we ended
3005.819|4.741|up with the addition of all of them
3008.7|4.2|and so basically depending on how many
3010.56|6.36|ones and zeros we have here we are
3012.9|6.12|basically doing a sum currently of a
3016.92|4.74|variable number of these rows and that
3019.02|4.26|gets deposited into C
3021.66|3.54|So currently we're doing sums because
3023.28|4.44|these are ones but we can also do
3025.2|5.36|average right and you can start to see
3027.72|5.7|how we could do average of the rows of B
3030.56|4.779|uh sort of in an incremental fashion
3033.42|4.26|because we don't have to we can
3035.339|3.78|basically normalize these rows so that
3037.68|2.58|they sum to one and then we're going to
3039.119|3.96|get an average
3040.26|5.94|so if we took a and then we did a equals
3043.079|5.461|a divide a torch.sum
3046.2|6.54|in the um
3048.54|7.2|of a in the warmth
3052.74|5.16|Dimension and then let's keep them as
3055.74|3.06|true so therefore the broadcasting will
3057.9|3.36|work out
3058.8|5.819|so if I rerun this you see now that
3061.26|6.299|these rows now sum to one so this row is
3064.619|4.261|one this row is 0.5.50 and here we get
3067.559|3.841|one thirds
3068.88|3.6|and now when we do a multiply B what are
3071.4|2.699|we getting
3072.48|3.18|here we are just getting the first row
3074.099|4.141|first row
3075.66|5.34|here now we are getting the average of
3078.24|5.7|the first two rows
3081.0|4.859|okay so 2 and 6 average is four and four
3083.94|4.08|and seven average is 5.5
3085.859|5.641|and on the bottom here we are now
3088.02|5.819|getting the average of these three rows
3091.5|4.859|so the average of all of elements of B
3093.839|4.881|are now deposited here
3096.359|5.161|and so you can see that by manipulating
3098.72|5.5|these uh elements of this multiplying
3101.52|5.88|Matrix and then multiplying it with any
3104.22|5.399|given Matrix we can do these averages in
3107.4|3.0|this incremental fashion because we just
3109.619|1.74|get
3110.4|3.12|um
3111.359|4.141|and we can manipulate that based on the
3113.52|4.319|elements of a okay so that's very
3115.5|4.079|convenient so let's swing back up here
3117.839|3.361|and see how we can vectorize this and
3119.579|2.641|make it much more efficient using what
3121.2|3.359|we've learned
3122.22|5.099|so in particular
3124.559|4.441|we are going to produce an array a but
3127.319|2.76|here I'm going to call it way short for
3129.0|3.599|weights
3130.079|4.98|but this is r a
3132.599|4.681|and this is how much of every row we
3135.059|3.361|want to average up and it's going to be
3137.28|3.779|an average because you can see it in
3138.42|5.46|these rows sum to 1.
3141.059|4.981|so this is our a and then our B in this
3143.88|3.9|example of course is
3146.04|3.539|X
3147.78|4.98|so it's going to happen here now is that
3149.579|6.121|we are going to have an expo 2.
3152.76|4.74|and this Expo 2 is going to be way
3155.7|3.72|multiplying
3157.5|4.559|RX
3159.42|5.399|so let's think this through way is T by
3162.059|6.06|T and this is Matrix multiplying in pi
3164.819|4.861|torch a b by T by C
3168.119|4.681|and it's giving us
3169.68|4.2|uh the what shape so pytorch will come
3172.8|3.539|here and then we'll see that these
3173.88|4.739|shapes are not the same so it will
3176.339|4.621|create a batch Dimension here and this
3178.619|3.841|is a batched matrix multiply
3180.96|3.599|and so it will apply this matrix
3182.46|4.02|multiplication in all the batch elements
3184.559|4.5|in parallel
3186.48|4.5|and individually and then for each batch
3189.059|4.741|element there will be a t by T
3190.98|5.42|multiplying T by C exactly as we had
3193.8|2.6|below
3196.74|4.619|so this will now create
3198.66|5.76|B by T by C
3201.359|5.161|and X both 2 will now become identical
3204.42|4.52|to Expo
3206.52|2.42|so
3208.98|8.339|we can see that torch.all close
3211.859|7.74|of Expo and Expo 2 should be true now
3217.319|5.401|so this kind of like misses us that uh
3219.599|8.041|these are in fact the same
3222.72|7.2|so Expo and Expo 2 if I just print them
3227.64|4.26|uh okay we're not going to be able to
3229.92|3.96|okay we're not going to be able to just
3231.9|3.179|stare it down but
3233.88|3.06|um
3235.079|3.361|well let me try Expo basically just at
3236.94|3.119|the zeroth element and Expo two at the
3238.44|4.32|zeroth element so just the first batch
3240.059|5.28|and we should see that this and that
3242.76|5.22|should be identical which they are
3245.339|4.681|right so what happened here the trick is
3247.98|3.0|we were able to use batched Matrix
3250.02|4.92|multiply
3250.98|6.599|to do this uh aggregation really and
3254.94|6.36|it's awaited aggregation and the weights
3257.579|6.061|are specified in this T by T array
3261.3|5.7|and we're basically doing weighted sums
3263.64|6.06|and uh these weighted sums are according
3267.0|5.04|to the weights inside here they take on
3269.7|4.379|sort of this triangular form
3272.04|4.86|and so that means that a token at the
3274.079|5.581|teeth Dimension will only get uh sort of
3276.9|4.74|um information from the um tokens
3279.66|3.959|preceding it so that's exactly what we
3281.64|3.719|want and finally I would like to rewrite
3283.619|4.381|it in one more way
3285.359|4.861|and we're going to see why that's useful
3288.0|3.9|so this is the third version and it's
3290.22|4.139|also identical to the first and second
3291.9|3.659|but let me talk through it it uses
3294.359|2.401|softmax
3295.559|5.221|so
3296.76|5.88|Trill here is this Matrix lower
3300.78|5.4|triangular ones
3302.64|5.459|way begins as all zero
3306.18|4.2|okay so if I just print way in the
3308.099|4.441|beginning it's all zero
3310.38|3.719|then I used
3312.54|3.539|masked fill
3314.099|4.441|so what this is doing is
3316.079|4.681|wait that masked fill it's all zeros and
3318.54|5.46|I'm saying for all the elements where
3320.76|4.62|Trill is equals equals zero make them be
3324.0|3.599|negative Infinity
3325.38|4.739|so all the elements where Trill is zero
3327.599|4.5|will become negative Infinity now
3330.119|6.801|so this is what we get
3332.099|4.821|and then the final one here is softmax
3337.2|4.02|so if I take a soft Max along every
3339.24|3.54|single so dim is negative one so along
3341.22|4.02|every single row
3342.78|4.579|if I do a soft Max what is that going to
3345.24|2.119|do
3347.46|5.7|well softmax is um
3350.4|4.14|it's also like a normalization operation
3353.16|3.659|right
3354.54|4.319|and so spoiler alert you get the exact
3356.819|4.381|same Matrix
3358.859|4.321|let me bring back the softmax
3361.2|3.54|and recall that in softmax we're going
3363.18|2.52|to exponentiate every single one of
3364.74|2.46|these
3365.7|2.46|and then we're going to divide by the
3367.2|3.06|sum
3368.16|3.54|and so for if we exponentiate every
3370.26|3.78|single element here we're going to get a
3371.7|4.2|one and here we're going to get uh
3374.04|2.94|basically zero zero zero zero zero
3375.9|3.36|everywhere else
3376.98|5.16|and then when we normalize we just get
3379.26|5.819|one here we're going to get 1 1 and then
3382.14|5.939|zeros and then softmax will again divide
3385.079|6.0|and this will give us 0.5.5 and so on
3388.079|5.221|and so this is also the uh the same way
3391.079|3.841|to produce this mask
3393.3|3.12|now the reason that this is a bit more
3394.92|3.72|interesting and the reason we're going
3396.42|4.02|to end up using it and solve a tension
3398.64|5.34|is that
3400.44|5.04|these weights here begin uh with zero
3403.98|4.26|and you can think of this as like an
3405.48|5.639|interaction strength or like an affinity
3408.24|5.94|so basically it's telling us how much of
3411.119|5.94|each token from the past do we want to
3414.18|6.06|Aggregate and average up
3417.059|5.701|and then this line is saying tokens from
3420.24|4.319|the past cannot communicate by setting
3422.76|3.66|them to negative Infinity we're saying
3424.559|3.601|that we will not aggregate anything from
3426.42|3.6|those tokens
3428.16|3.54|and so basically this then goes through
3430.02|3.12|softmax and through the weighted and
3431.7|3.24|this is the aggregation through matrix
3433.14|4.14|multiplication
3434.94|3.72|and so what this is now is you can think
3437.28|3.9|of these as
3438.66|5.82|um these zeros are currently just set by
3441.18|5.76|us to be zero but a quick preview is
3444.48|4.139|that these affinities between the tokens
3446.94|4.02|are not going to be just constant at
3448.619|4.021|zero they're going to be data dependent
3450.96|3.96|these tokens are going to start looking
3452.64|4.8|at each other and some tokens will find
3454.92|4.5|other tokens more or less interesting
3457.44|3.36|and depending on what their values are
3459.42|3.72|they're going to find each other
3460.8|4.319|interesting to different amounts and I'm
3463.14|4.08|going to call those affinities I think
3465.119|4.2|and then here we are saying the future
3467.22|3.78|cannot communicate with the past we're
3469.319|4.201|going to clamp them
3471.0|4.92|and then when we normalize and sum we're
3473.52|3.96|going to aggregate sort of their values
3475.92|2.46|depending on how interesting they find
3477.48|2.16|each other
3478.38|4.8|and so that's the preview for
3479.64|5.219|self-attention and basically long story
3483.18|4.679|short from this entire section is that
3484.859|4.5|you can do weighted aggregations of your
3487.859|4.561|past elements
3489.359|6.0|by having by using matrix multiplication
3492.42|5.22|of a lower triangular fashion
3495.359|4.2|and then the elements here in the lower
3497.64|5.699|triangular part are telling you how much
3499.559|5.401|of each element fuses into this position
3503.339|3.901|so we're going to use this trick now to
3504.96|3.78|develop the self-attention block so
3507.24|3.119|first let's get some quick preliminaries
3508.74|3.119|out of the way
3510.359|3.061|first the thing I'm kind of bothered by
3511.859|3.361|is that you see how we're passing in
3513.42|3.24|vocab size into the Constructor there's
3515.22|3.78|no need to do that because vocab size
3516.66|4.02|has already defined up top as a global
3519.0|3.48|variable so there's no need to pass this
3520.68|4.379|stuff around
3522.48|4.44|next one I want to do is I don't want to
3525.059|3.421|actually create I want to create like a
3526.92|4.159|level of interaction here where we don't
3528.48|4.92|directly go to the embedding for the um
3531.079|3.881|logits but instead we go through this
3533.4|4.5|intermediate phase because we're going
3534.96|6.24|to start making that bigger so let me
3537.9|4.62|introduce a new variable and embed a
3541.2|2.46|short for a number of embedding
3542.52|2.819|dimensions
3543.66|3.06|so an embed
3545.339|4.621|here
3546.72|6.0|will be say 32. that was a suggestion
3549.96|5.46|from GitHub by the way it also showed us
3552.72|4.26|to 32 which is a good number
3555.42|4.5|so this is an embedding table and only
3556.98|4.68|32 dimensional embeddings
3559.92|4.08|so then here this is not going to give
3561.66|4.32|us logits directly instead this is going
3564.0|3.48|to give us token embeddings
3565.98|3.24|that's what I'm going to call it and
3567.48|3.48|then to go from the token embeddings to
3569.22|4.8|the logits we're going to need a linear
3570.96|5.159|layer so self.lm head let's call it
3574.02|4.74|short for language modeling head
3576.119|3.661|is n linear from an embed up to vocab
3578.76|2.7|size
3579.78|3.26|and then when we swing over here we're
3581.46|4.5|actually going to get the logits by
3583.04|4.299|exactly what the copilot says
3585.96|4.98|now we have to be careful here because
3587.339|6.361|this C and this C are not equal
3590.94|4.02|this is an embedded C and this is vocab
3593.7|3.119|size
3594.96|3.78|so let's just say that an embed is equal
3596.819|4.441|to C
3598.74|4.14|and then this just creates one spurious
3601.26|6.2|layer of interaction through a linear
3602.88|4.58|layer but this should basically run
3612.299|4.5|so we see that this runs and uh this
3615.359|3.72|currently looks kind of spurious but
3616.799|4.741|we're going to build on top of this now
3619.079|4.561|next up so far we've taken these in in
3621.54|6.539|the seas and we've encoded them based on
3623.64|6.12|the identity of the tokens inside idx
3628.079|3.601|the next thing that people very often do
3629.76|4.02|is that we're not just encoding the
3631.68|3.119|identity of these tokens but also their
3633.78|2.519|position
3634.799|4.32|so we're going to have a second position
3636.299|4.681|uh embedding table here so solve that
3639.119|4.141|position embedding table
3640.98|4.92|is an embedding of block size by an
3643.26|4.5|embed and so each position from 0 to
3645.9|3.54|block size minus 1 will also get its own
3647.76|4.5|embedding vector
3649.44|5.879|and then here first let me decode a b by
3652.26|4.559|T from idx.shape
3655.319|3.48|and then here we're also going to have a
3656.819|3.661|positive bedding which is the positional
3658.799|4.381|embedding and these are this is tour
3660.48|5.46|Dutch arrange so this will be basically
3663.18|4.86|just integers from 0 to T minus 1.
3665.94|3.54|and all of those integers from 0 to T
3668.04|4.14|minus 1 get embedded through the table
3669.48|5.639|to create a t by C
3672.18|5.76|and then here this gets renamed to just
3675.119|4.5|say x and x will be
3677.94|3.84|the addition of the token embeddings
3679.619|4.081|with the positional embeddings
3681.78|5.22|and here the broadcasting note will work
3683.7|5.28|out so B by T by C plus T by C this gets
3687.0|3.9|right aligned a new dimension of one
3688.98|3.72|gets added and it gets broadcasted
3690.9|4.38|across batch
3692.7|5.099|so at this point x holds not just the
3695.28|4.14|token identities but the positions at
3697.799|3.481|which these tokens occur
3699.42|3.3|and this is currently not that useful
3701.28|3.0|because of course we just have a simple
3702.72|2.76|migrain model so it doesn't matter if
3704.28|3.24|you're in the fifth position the second
3705.48|4.5|position or wherever it's all
3707.52|3.98|translation invariant at this stage so
3709.98|3.9|this information currently wouldn't help
3711.5|3.88|but as we work on the self potential
3713.88|3.739|block we'll see that this starts to
3715.38|2.239|matter
3719.76|3.48|okay so now we get the Crux of
3721.38|3.419|self-attention so this is probably the
3723.24|3.119|most important part of this video to
3724.799|2.82|understand
3726.359|2.94|we're going to implement a small
3727.619|3.48|self-attention for a single individual
3729.299|4.26|head as they're called
3731.099|4.2|so we start off with where we were so
3733.559|4.081|all of this code is familiar
3735.299|3.54|so right now I'm working with an example
3737.64|4.08|where I change the number of channels
3738.839|6.541|from 2 to 32 so we have a 4x8
3741.72|5.46|arrangement of tokens and each and the
3745.38|3.959|information at each token is currently
3747.18|4.02|32 dimensional but we just are working
3749.339|4.381|with random numbers
3751.2|5.399|now we saw here that
3753.72|5.94|the code as we had it before does a
3756.599|6.181|simple weight a simple average of all
3759.66|4.62|the past tokens and the current token so
3762.78|3.0|it's just the previous information and
3764.28|2.88|current information is just being mixed
3765.78|3.059|together in an average
3767.16|3.72|and that's what this code currently
3768.839|4.201|achieves and it does so by creating this
3770.88|5.88|lower triangular structure which allows
3773.04|4.68|us to mask out this weight Matrix that
3776.76|3.48|we create
3777.72|6.359|so we mask it out and then we normalize
3780.24|5.339|it and currently when we initialize the
3784.079|4.621|affinities between all the different
3785.579|4.98|sort of tokens or nodes I'm going to use
3788.7|3.72|those terms interchangeably
3790.559|3.24|so when we initialize the affinities
3792.42|2.52|between all the different tokens to be
3793.799|3.381|zero
3794.94|4.56|then we see that way gives us this
3797.18|3.82|structure where every single row has
3799.5|4.02|these um
3801.0|4.98|uniform numbers and so that's what
3803.52|4.559|that's what then uh in this Matrix
3805.98|3.48|multiply makes it so that we're doing a
3808.079|2.641|simple average
3809.46|3.839|now
3810.72|5.94|we don't actually want this to be
3813.299|5.82|All Uniform because different uh tokens
3816.66|4.08|will find different other tokens more or
3819.119|3.72|less interesting and we want that to be
3820.74|4.2|data dependent so for example if I'm a
3822.839|4.26|vowel then maybe I'm looking for
3824.94|3.78|consonants in my past and maybe I want
3827.099|4.02|to know what those consonants are and I
3828.72|4.5|want that information to Flow To Me
3831.119|4.321|and so I want to now gather information
3833.22|3.839|from the past but I want to do it in a
3835.44|3.54|data dependent way and this is the
3837.059|3.841|problem that self-attention solves
3838.98|5.099|now the way self-attention solves this
3840.9|6.0|is the following every single node or
3844.079|4.5|every single token at each position will
3846.9|5.04|emit two vectors
3848.579|4.861|it will emit a query and it will emit a
3851.94|4.379|key
3853.44|4.919|now the query Vector roughly speaking is
3856.319|4.141|what am I looking for
3858.359|4.26|and the key Vector roughly speaking is
3860.46|4.26|what do I contain
3862.619|5.821|and then the way we get affinities
3864.72|5.639|between these tokens now in a sequence
3868.44|4.139|is we basically just do a DOT product
3870.359|5.401|between the keys and the queries
3872.579|5.641|so my query dot products with all the
3875.76|6.92|keys of all the other tokens and that
3878.22|4.46|dot product now becomes way
3882.78|5.4|and so um if the key and the query are
3886.02|4.68|sort of aligned they will interact to a
3888.18|5.76|very high amount and then I will get to
3890.7|4.859|learn more about that specific token as
3893.94|5.48|opposed to any other token in the
3895.559|3.861|sequence so let's implement this tab
3901.5|6.42|we're going to implement a single
3904.559|5.701|what's called head of self-attention
3907.92|3.6|so this is just one head there's a hyper
3910.26|3.18|parameter involved with these heads
3911.52|3.66|which is the head size
3913.44|4.379|and then here I'm initializing the
3915.18|4.379|linear modules and I'm using bias equals
3917.819|4.861|false so these are just going to apply a
3919.559|5.401|matrix multiply with some fixed weights
3922.68|5.879|and now let me produce a
3924.96|5.879|key and Q K and Q by forwarding these
3928.559|5.101|modules on x
3930.839|6.301|so the size of this will not become
3933.66|8.659|B by T by 16 because that is the head
3937.14|5.179|size and the same here B by T by 16.
3945.78|3.66|so this being that size
3947.52|5.279|so you see here that when I forward this
3949.44|5.159|linear on top of my X all the tokens in
3952.799|4.26|all the positions in the B by T
3954.599|4.98|Arrangement all of them in parallel and
3957.059|5.401|independently produce a key and a query
3959.579|5.04|so no communication has happened yet
3962.46|4.56|but the communication comes now all the
3964.619|3.901|queries will dot product with all the
3967.02|3.48|keys
3968.52|4.62|so basically what we want is we want way
3970.5|5.88|now or the affinities between these to
3973.14|4.919|be query multiplying key
3976.38|3.12|but we have to be careful with uh we
3978.059|4.681|can't Matrix multiply this we actually
3979.5|6.059|need to transpose uh K but we have to be
3982.74|4.5|also careful because these are when you
3985.559|4.321|have the batch Dimension so in
3987.24|4.92|particular we want to transpose uh the
3989.88|4.02|last two Dimensions Dimension negative
3992.16|5.22|one and dimension negative two
3993.9|6.419|so negative 2 negative 1.
3997.38|7.459|and so this Matrix multiplied now will
4000.319|4.52|basically do the following B by T by 16
4005.18|5.159|Matrix multiplies B by 16 by T to give
4009.38|4.82|us
4010.339|3.861|B by T by T
4014.299|4.621|right
4015.98|5.28|so for every row of B we're not going to
4018.92|4.919|have a t-square matrix giving us the
4021.26|5.279|affinities and these are now the way
4023.839|4.681|so they're not zeros they are now coming
4026.539|3.06|from this dot product between the keys
4028.52|4.62|and the queries
4029.599|5.641|so this can now run I can I can run this
4033.14|4.08|and the weighted aggregation now is a
4035.24|3.96|function in a data dependent manner
4037.22|3.0|between the keys and queries of these
4039.2|4.56|nodes
4040.22|6.119|so just inspecting what happened here
4043.76|5.579|the way takes on this form
4046.339|4.861|and you see that before way was just a
4049.339|4.081|constant so it was applied in the same
4051.2|3.659|way to all the batch elements but now
4053.42|4.56|every single batch elements will have
4054.859|4.381|different sort of way because uh every
4057.98|4.079|single batch element contains different
4059.24|4.68|tokens at different positions and so
4062.059|5.04|this is not data dependent
4063.92|5.82|so when we look at just the zeroth row
4067.099|4.561|for example in the input these are the
4069.74|3.059|weights that came out and so you can see
4071.66|2.6|now that they're not just exactly
4072.799|3.901|uniform
4074.26|4.839|and in particular as an example here for
4076.7|4.5|the last row this was the eighth token
4079.099|3.781|and the eighth token knows what content
4081.2|2.82|it has and it knows at what position
4082.88|4.08|it's in
4084.02|5.519|and now the eighth token based on that
4086.96|5.22|creates a query hey I'm looking for this
4089.539|3.841|kind of stuff I'm a vowel I'm on the
4092.18|4.079|eighth position I'm looking for any
4093.38|6.0|consonants at positions up to four
4096.259|5.221|and then all the nodes get to emit keys
4099.38|4.2|and maybe one of the channels could be I
4101.48|3.54|am a I am a consonant and I am in a
4103.58|4.38|position up to four
4105.02|4.98|and that key would have a high number in
4107.96|3.48|that specific Channel and that's how the
4110.0|3.179|query and the key when they dot product
4111.44|3.18|they can find each other and create a
4113.179|3.0|high affinity
4114.62|4.679|and when they have a high Affinity like
4116.179|6.12|say this token was pretty interesting to
4119.299|4.861|uh to this eighth token
4122.299|3.601|when they have a high Affinity then
4124.16|3.059|through the soft Max I will end up
4125.9|3.24|aggregating a lot of its information
4127.219|5.281|into my position
4129.14|7.139|and so I'll get to learn a lot about it
4132.5|6.06|now just this we're looking at way after
4136.279|2.94|this has already happened
4138.56|2.58|um
4139.219|3.901|let me erase this operation as well so
4141.14|3.42|let me erase the masking and the softmax
4143.12|3.36|just to show you the under the hood
4144.56|4.139|internals and how that works
4146.48|4.859|so without the masking in the softmax
4148.699|4.5|way comes out like this right this is
4151.339|3.96|the outputs of the dot products
4153.199|3.781|and these are the raw outputs and they
4155.299|4.321|take on values from negative you know
4156.98|5.339|two to positive two Etc
4159.62|4.619|so that's the raw interactions and raw
4162.319|4.741|affinities between all the nodes
4164.239|4.741|but now if I'm a if I'm a fifth node I
4167.06|3.779|will not want to aggregate anything from
4168.98|4.02|the six node seventh node and the eighth
4170.839|4.98|node so actually we use the upper
4173.0|5.219|triangular masking so those are not
4175.819|4.92|allowed to communicate
4178.219|5.161|and now we actually want to have a nice
4180.739|4.921|uh distribution so we don't want to
4183.38|4.379|aggregate negative 0.11 of this node
4185.66|4.199|that's crazy so instead we exponentiate
4187.759|3.781|and normalize and now we get a nice
4189.859|3.241|distribution that seems to one
4191.54|3.3|and this is telling us now in the data
4193.1|4.079|dependent manner how much of information
4194.84|4.5|to aggregate from any of these tokens in
4197.179|5.161|the past
4199.34|6.0|so that's way and it's not zeros anymore
4202.34|6.359|but but it's calculated in this way now
4205.34|5.46|there's one more uh part to a single
4208.699|3.721|self-attention head and that is that
4210.8|4.32|when you do the aggregation we don't
4212.42|4.68|actually aggregate the tokens exactly we
4215.12|5.94|aggregate we produce one more value here
4217.1|5.579|and we call that the value
4221.06|3.48|so in the same way that we produced p
4222.679|3.181|and query we're also going to create a
4224.54|3.119|value
4225.86|3.0|and then
4227.659|3.601|here
4228.86|5.76|we don't aggregate
4231.26|6.6|X we calculate a v which is just
4234.62|5.94|achieved by propagating this linear on
4237.86|6.6|top of X again and then we
4240.56|5.94|output way multiplied by V so V is the
4244.46|3.6|elements that we aggregate or the the
4246.5|3.179|vector that we aggregate instead of the
4248.06|3.84|raw X
4249.679|3.961|and now of course this will make it so
4251.9|3.66|that the output here of the single head
4253.64|4.62|will be 16 dimensional because that is
4255.56|4.74|the head size
4258.26|3.899|so you can think of X as kind of like a
4260.3|4.2|private information to this token if you
4262.159|4.321|if you think about it that way so X is
4264.5|3.78|kind of private to this token so I'm a
4266.48|5.4|fifth token at some and I have some
4268.28|4.74|identity and my information is kept in
4271.88|3.299|Vector X
4273.02|4.08|and now for the purposes of the single
4275.179|4.261|head here's what I'm interested in
4277.1|4.619|here's what I have
4279.44|4.08|and if you find me interesting here's
4281.719|3.301|what I will communicate to you and
4283.52|3.0|that's stored in v
4285.02|3.3|and so V is the thing that gets
4286.52|5.1|aggregated for the purposes of this
4288.32|4.98|single head between the different nodes
4291.62|3.599|and that's uh
4293.3|4.74|basically the self attention mechanism
4295.219|4.381|this is this is what it does
4298.04|4.199|there are a few notes that I would make
4299.6|5.22|like to make about attention number one
4302.239|4.5|attention is a communication mechanism
4304.82|3.839|you can really think about it as a
4306.739|3.781|communication mechanism where you have a
4308.659|4.02|number of nodes in a directed graph
4310.52|4.139|where basically you have edges pointing
4312.679|4.5|between those like this
4314.659|4.5|and what happens is every node has some
4317.179|4.56|Vector of information and it gets to
4319.159|5.52|aggregate information via a weighted sum
4321.739|4.621|from all the nodes that point to it
4324.679|3.781|and this is done in a data dependent
4326.36|3.299|manner so depending on whatever data is
4328.46|2.64|actually stored at each node at any
4329.659|2.941|point in time
4331.1|3.119|now
4332.6|3.599|our graph doesn't look like this our
4334.219|3.841|graph has a different structure we have
4336.199|4.921|eight nodes because the block size is
4338.06|5.94|eight and there's always eight tokens
4341.12|5.22|and the first node is only pointed to by
4344.0|4.62|itself the second node is pointed to by
4346.34|4.26|the first node and itself all the way up
4348.62|4.98|to the eighth node which is pointed to
4350.6|4.86|by all the previous nodes and itself
4353.6|4.079|and so that's the structure that our
4355.46|3.84|directed graph has or happens happens to
4357.679|4.02|have in other aggressive sort of
4359.3|3.72|scenario like language modeling but in
4361.699|2.881|principle attention can be applied to
4363.02|3.06|any arbitrary directed graph and it's
4364.58|2.46|just a communication mechanism between
4366.08|3.0|the nodes
4367.04|4.679|the second note is that notice that
4369.08|5.159|there is no notion of space so attention
4371.719|5.101|simply acts over like a set of vectors
4374.239|3.96|in this graph and so by default these
4376.82|3.12|nodes have no idea where they are
4378.199|3.96|positioned in a space and that's why we
4379.94|3.96|need to encode them positionally and
4382.159|3.781|sort of give them some information that
4383.9|4.319|is anchored to a specific position so
4385.94|4.14|that they sort of know where they are
4388.219|3.841|and this is different than for example
4390.08|3.24|from convolution because if you run for
4392.06|4.02|example a convolution operation over
4393.32|5.399|some input there's a very specific sort
4396.08|4.74|of layout of the information in space in
4398.719|5.341|the convolutional filters sort of act in
4400.82|5.399|space and so it's it's not like an
4404.06|3.96|attention in attention is just a set of
4406.219|3.721|vectors out there in space they
4408.02|3.36|communicate and if you want them to have
4409.94|3.48|a notion of space you need to
4411.38|4.62|specifically add it which is what we've
4413.42|5.16|done when we calculated the um relative
4416.0|4.14|the position loan code encodings and
4418.58|3.18|added that information to the vectors
4420.14|3.72|the next thing that I hope is very clear
4421.76|4.08|is that the elements across the batch
4423.86|3.6|Dimension which are independent examples
4425.84|3.54|never talk to each other don't always
4427.46|3.719|processed independently and this is a
4429.38|4.02|bashed Matrix multiply that applies
4431.179|3.301|basically a matrix multiplication kind
4433.4|2.88|of in parallel across the batch
4434.48|3.96|Dimension so maybe it would be more
4436.28|4.56|accurate to say that in this analogy of
4438.44|4.38|a directed graph we really have because
4440.84|5.04|the batch size is four we really have
4442.82|4.32|four separate pools of eight nodes and
4445.88|3.12|those eight nodes only talk to each
4447.14|4.32|other but in total there's like 32 nodes
4449.0|4.86|that are being processed but there's um
4451.46|3.9|sort of four separate pools of eight you
4453.86|4.14|can look at it that way
4455.36|5.339|the next note is that here in the case
4458.0|4.8|of language modeling uh we have this
4460.699|4.141|specific structure of directed graph
4462.8|4.8|where the future tokens will not
4464.84|3.96|communicate to the Past tokens but this
4467.6|3.24|doesn't necessarily have to be the
4468.8|4.02|constraint in the general case and in
4470.84|4.319|fact in many cases you may want to have
4472.82|4.859|all of the nodes talk to each other
4475.159|3.901|fully so as an example if you're doing
4477.679|3.48|sentiment analysis or something like
4479.06|3.84|that with a Transformer you might have a
4481.159|3.601|number of tokens and you may want to
4482.9|3.839|have them all talk to each other fully
4484.76|3.72|because later you are predicting for
4486.739|4.201|example the sentiment of the sentence
4488.48|3.36|and so it's okay for these nodes to talk
4490.94|3.48|to each other
4491.84|6.06|and so in those cases you will use an
4494.42|5.52|encoder block of self-attention and all
4497.9|3.72|it means that it's an encoder block is
4499.94|3.6|that you will delete this line of code
4501.62|3.539|allowing all the nodes to completely
4503.54|3.06|talk to each other what we're
4505.159|4.641|implementing here is sometimes called a
4506.6|7.079|decoder block and it's called a decoder
4509.8|5.56|because it is sort of like a decoding
4513.679|3.901|language and it's got this Auto
4515.36|5.7|aggressive format where you have to mask
4517.58|5.28|with the Triangular Matrix so that nodes
4521.06|4.32|from the future never talk to the Past
4522.86|4.859|because they would give away the answer
4525.38|4.2|and so basically in encoder blocks you
4527.719|3.841|would delete this allow all the nodes to
4529.58|3.96|talk in decoder blocks this will always
4531.56|3.96|be present so that you have this
4533.54|3.3|triangular structure but both are
4535.52|2.76|allowed and attention doesn't care
4536.84|2.94|attention supports arbitrary
4538.28|3.24|connectivity between nodes
4539.78|3.66|the next thing I wanted to comment on is
4541.52|3.9|you keep me you keep hearing me say
4543.44|3.12|attention self-attention Etc there's
4545.42|2.9|actually also something called cross
4546.56|3.5|attention what is the difference
4548.32|4.839|so
4550.06|6.159|basically the reason this attention is
4553.159|5.101|self-attention is because the keys
4556.219|5.46|queries and the values are all coming
4558.26|5.399|from the same Source from X so the same
4561.679|4.801|Source X produces case queries and
4563.659|5.341|values so these nodes are self-attending
4566.48|4.44|but in principle attention is much more
4569.0|4.5|General than that so for example an
4570.92|4.5|encoder decoder Transformers uh you can
4573.5|4.08|have a case where the queries are
4575.42|3.48|produced from X but the keys and the
4577.58|3.599|values come from a whole separate
4578.9|4.98|external source and sometimes from
4581.179|4.741|encoder blocks that encode some context
4583.88|3.24|that we'd like to condition on and so
4585.92|3.36|the keys and the values will actually
4587.12|4.32|come from a whole separate Source those
4589.28|4.2|are nodes on the side and here we're
4591.44|3.779|just producing queries and we're reading
4593.48|4.199|off information from the side
4595.219|5.821|so cross attention is used when there's
4597.679|6.601|a separate source of nodes we'd like to
4601.04|4.5|pull information from into our nodes and
4604.28|2.58|it's self-attention if we just have
4605.54|2.699|nodes that would like to look at each
4606.86|3.54|other and talk to each other
4608.239|4.5|so this attention here happens to be
4610.4|4.02|self-attention
4612.739|2.521|but in principle
4614.42|2.88|um
4615.26|4.08|attention is a lot more General okay in
4617.3|3.18|the last note at this stage is if we
4619.34|3.12|come to the attention is all you need
4620.48|4.28|paper here we've already implemented
4622.46|5.34|attention so given query key and value
4624.76|5.14|we've multiplied the query on the key
4627.8|3.899|we've softmaxed it and then we are
4629.9|2.88|aggregating the values
4631.699|2.46|there's one more thing that we're
4632.78|3.48|missing here which is the dividing by
4634.159|4.921|one over square root of the head size
4636.26|5.04|the DK here is the head size why aren't
4639.08|4.86|they doing this once it's important so
4641.3|4.08|they call it a scaled attention
4643.94|3.84|and it's kind of like an important
4645.38|4.62|normalization to basically have
4647.78|4.74|the problem is if you have unit gaussian
4650.0|4.38|inputs so zero mean unit variance K and
4652.52|4.44|Q are unit caution and if you just do
4654.38|4.68|way naively then you see that your way
4656.96|3.719|actually will be uh the variance will be
4659.06|3.24|on the order of head size which in our
4660.679|3.661|case is 16.
4662.3|4.14|but if you multiply by one over head
4664.34|3.839|size square root so this is square root
4666.44|4.5|and this is one over
4668.179|4.621|then the variance of way will be one so
4670.94|4.259|it will be preserved
4672.8|4.26|now why is this important you'll notice
4675.199|4.381|that way here
4677.06|4.08|will feed into softmax
4679.58|4.02|and so it's really important especially
4681.14|3.539|at initialization that way be fairly
4683.6|3.96|diffuse
4684.679|6.181|so in our case here we sort of lucked
4687.56|5.46|out here and weigh had a fairly diffuse
4690.86|4.62|numbers here so
4693.02|4.44|um like this now the problem is that
4695.48|3.6|because of softmax if weight takes on
4697.46|4.38|very positive and very negative numbers
4699.08|5.94|inside it softmax will actually converge
4701.84|5.399|towards one hot vectors and so I can
4705.02|3.06|illustrate that here
4707.239|3.301|um
4708.08|4.079|say we are applying softmax to a tensor
4710.54|3.3|of values that are very close to zero
4712.159|3.361|then we're going to get a diffuse thing
4713.84|3.12|out of softmax
4715.52|3.36|but the moment I take the exact same
4716.96|3.36|thing and I start sharpening it making
4718.88|3.72|it bigger by multiplying these numbers
4720.32|4.379|by eight for example you'll see that the
4722.6|4.44|soft Max will start to sharpen and in
4724.699|3.781|fact it will sharpen towards the max so
4727.04|3.06|it will sharpen towards whatever number
4728.48|2.94|here is the highest
4730.1|2.579|and so
4731.42|2.58|um basically we don't want these values
4732.679|3.301|to be too extreme especially the
4734.0|4.62|initialization otherwise softmax will be
4735.98|4.02|way too peaky and you're basically
4738.62|3.24|aggregating
4740.0|3.36|um information from like a single node
4741.86|3.359|every node just Aggregates information
4743.36|3.54|from a single other node that's not what
4745.219|4.381|we want especially its initialization
4746.9|4.44|and so the scaling is used just to
4749.6|4.32|control the variance at initialization
4751.34|4.56|okay so having said all that let's now
4753.92|4.14|take our soft retention knowledge and
4755.9|4.5|let's take it for a spin
4758.06|4.74|so here in the code I created this head
4760.4|3.66|module and implements a single head of
4762.8|3.6|self-attention
4764.06|3.96|so you give it a head size and then here
4766.4|3.96|it creates the key query and the value
4768.02|4.139|linear layers typically people don't use
4770.36|3.54|biases in these
4772.159|4.141|so those are the linear projections that
4773.9|4.44|we're going to apply to all of our nodes
4776.3|4.5|now here I'm creating this Trill
4778.34|4.379|variable Trill is not a parameter of the
4780.8|4.26|module so in sort of pythonomic
4782.719|4.261|conventions this is called a buffer it's
4785.06|3.119|not a parameter and you have to call it
4786.98|3.42|you have to assign it to the module
4788.179|3.121|using a register buffer so that creates
4790.4|3.96|the trail
4791.3|4.919|uh the triangle lower triangular Matrix
4794.36|3.299|and when we're given the input X this
4796.219|3.721|should look very familiar now we
4797.659|4.141|calculate the keys the queries we call
4799.94|4.44|it clock in the attentions course inside
4801.8|4.26|way we normalize it so we're using
4804.38|3.9|scaled attention here
4806.06|4.08|then we make sure that a feature doesn't
4808.28|3.66|communicate with the past so this makes
4810.14|4.019|it a decoder block
4811.94|4.5|and then softmax and then aggregate the
4814.159|3.661|value and output
4816.44|4.14|then here in the language model I'm
4817.82|4.98|creating a head in the Constructor and
4820.58|4.38|I'm calling it self attention head and
4822.8|5.58|the head size I'm going to keep as the
4824.96|6.3|same and embed just for now
4828.38|4.74|and then here once we've encoded the
4831.26|3.66|information with the token embeddings
4833.12|2.76|and the position embeddings we're simply
4834.92|3.06|going to feed it into the
4835.88|4.74|self-attentioned head and then the
4837.98|5.4|output of that is going to go into uh
4840.62|4.98|the decoder language modeling head and
4843.38|3.839|create the logits so this is the sort of
4845.6|4.02|the simplest way to plug in a
4847.219|3.721|self-attention component into our
4849.62|3.78|Network right now
4850.94|4.08|I had to make one more change which is
4853.4|4.14|that here
4855.02|5.82|in the generate we have to make sure
4857.54|4.74|that our idx that we feed into the model
4860.84|3.72|because now we're using positional
4862.28|5.399|embeddings we can never have more than
4864.56|4.92|block size coming in because if idx is
4867.679|3.601|more than block size then our position
4869.48|3.3|embedding table is going to run out of
4871.28|3.0|scope because it only has embeddings for
4872.78|3.66|up to block size
4874.28|4.56|and so therefore I added some code here
4876.44|4.58|to crop the context that we're going to
4878.84|5.1|feed into self
4881.02|4.54|so that we never pass in more than block
4883.94|3.239|size elements
4885.56|3.659|so those are the changes and let's Now
4887.179|3.901|train the network okay so I also came up
4889.219|3.781|to the script here and I decreased the
4891.08|3.72|learning rate because the self-attention
4893.0|4.199|can't tolerate very very high learning
4894.8|3.359|rates and then I also increase the
4897.199|2.641|number of iterations because the
4898.159|3.301|learning rate is lower and then I
4899.84|4.02|trained it and previously we were only
4901.46|4.98|able to get to up to 2.5 and now we are
4903.86|4.379|down to 2.4 so we definitely see a
4906.44|4.44|little bit of an improvement from 2.5 to
4908.239|5.401|2.4 roughly but the text is still not
4910.88|4.859|amazing so clearly the self-attention
4913.64|3.9|head is doing some useful communication
4915.739|3.781|but
4917.54|3.119|um we still have a long way to go okay
4919.52|3.42|so now we've implemented the
4920.659|3.721|scale.product attention now next up in
4922.94|3.239|the attention is all you need paper
4924.38|3.54|there's something called multi-head
4926.179|4.141|attention and what is multi-head
4927.92|4.86|attention it's just applying multiple
4930.32|3.6|attentions in parallel and concatenating
4932.78|2.82|the results
4933.92|3.739|so they have a little bit of diagram
4935.6|5.04|here I don't know if this is super clear
4937.659|4.0|it's really just multiple attentions in
4940.64|3.12|parallel
4941.659|3.601|so let's Implement that fairly
4943.76|3.78|straightforward
4945.26|3.72|if we want a multi-head attention then
4947.54|3.3|we want multiple heads of self-attention
4948.98|4.44|running in parallel
4950.84|5.28|so in pytorch we can do this by simply
4953.42|4.98|creating multiple heads
4956.12|3.84|so however heads how many however many
4958.4|3.12|heads you want and then what is the head
4959.96|4.14|size of each
4961.52|5.58|and then we run all of them in parallel
4964.1|5.4|into a list and simply concatenate all
4967.1|4.559|of the outputs and we're concatenating
4969.5|4.199|over the channel dimension
4971.659|4.261|so the way this looks now is we don't
4973.699|5.281|have just a single attention
4975.92|5.58|that has a hit size of 32 because
4978.98|4.739|remember and in bed is 32.
4981.5|4.679|instead of having one Communication
4983.719|5.161|channel we now have four communication
4986.179|4.101|channels in parallel and each one of
4988.88|5.94|these communication channels typically
4990.28|5.74|will be smaller correspondingly so
4994.82|3.12|because we have four communication
4996.02|4.02|channels we want eight dimensional
4997.94|3.48|self-attention and so from each
5000.04|3.6|Communication channel we're going to
5001.42|3.66|gather eight dimensional vectors and
5003.64|3.72|then we have four of them and that
5005.08|3.9|concatenates to give us 32 which is the
5007.36|3.96|original and embed
5008.98|3.6|and so this is kind of similar to um if
5011.32|2.48|you're familiar with convolutions this
5012.58|3.96|is kind of like a group convolution
5013.8|4.48|because basically instead of having one
5016.54|4.32|large convolution we do convolutional
5018.28|4.08|groups and uh that's multi-headed
5020.86|4.62|self-attention
5022.36|5.28|and so then here we just use sa heads
5025.48|5.34|self-attussion Heads instead
5027.64|4.5|now I actually ran it and uh scrolling
5030.82|3.12|down
5032.14|5.88|I ran the same thing and then we now get
5033.94|5.4|this down to 2.28 roughly and the output
5038.02|3.3|is still the generation is still not
5039.34|4.379|amazing but clearly the validation loss
5041.32|3.419|is improving because we were at 2.4 just
5043.719|2.761|now
5044.739|3.42|and so it helps to have multiple
5046.48|3.719|communication channels because obviously
5048.159|4.201|these tokens have a lot to talk about
5050.199|3.901|and they want to find the consonants the
5052.36|4.08|vowels they want to find the vowels just
5054.1|4.92|from certain positions they want to find
5056.44|4.08|any kinds of different things and so it
5059.02|3.36|helps to create multiple independent
5060.52|4.74|channels of communication gather lots of
5062.38|4.74|different types of data and then decode
5065.26|3.54|the output now going back to the paper
5067.12|3.96|for a second of course I didn't explain
5068.8|3.48|this figure in full detail but we are
5071.08|2.76|starting to see some components of what
5072.28|3.3|we've already implemented we have the
5073.84|4.2|positional encodings the token encodings
5075.58|5.579|that add we have the masked multi-headed
5078.04|4.86|attention implemented now here's another
5081.159|3.961|multi-headed tension which is a cross
5082.9|3.779|attention to an encoder which we haven't
5085.12|3.0|we're not going to implement in this
5086.679|2.641|case I'm going to come back to that
5088.12|2.76|later
5089.32|3.6|but I want you to notice that there's a
5090.88|3.72|feed forward part here and then this is
5092.92|2.819|grouped into a block that gets repeated
5094.6|3.059|again and again
5095.739|4.5|now the feed forward part here is just a
5097.659|3.961|simple multi-layer perceptron
5100.239|3.601|um
5101.62|4.74|so the multi-headed so here position
5103.84|4.2|wise feed forward networks is just a
5106.36|3.48|simple little MLP
5108.04|3.78|so I want to start basically in a
5109.84|3.359|similar fashion also adding computation
5111.82|3.54|into the network
5113.199|4.141|and this computation is on the per node
5115.36|3.66|level so
5117.34|3.3|I've already implemented it and you can
5119.02|3.78|see the diff highlighted on the left
5120.64|4.62|here when I've added or changed things
5122.8|3.54|now before we had the multi-headed
5125.26|3.479|self-attention that did the
5126.34|5.52|communication but we went way too fast
5128.739|4.201|to calculate the logits so the tokens
5131.86|3.54|looked at each other but didn't really
5132.94|4.5|have a lot of time to think on what they
5135.4|4.799|found from the other tokens
5137.44|5.219|and so what I've implemented here is a
5140.199|4.201|little feed forward single layer and
5142.659|3.841|this little layer is just a linear
5144.4|3.48|followed by a relative nonlinearity and
5146.5|4.5|that's that's it
5147.88|5.1|so it's just a little layer and then I
5151.0|3.84|call it feed forward
5152.98|3.3|and embed
5154.84|3.0|and then this feed forward is just
5156.28|4.439|called sequentially right after the
5157.84|4.859|self-attention so we self-attend then we
5160.719|3.48|feed forward and you'll notice that the
5162.699|4.081|feet forward here when it's applying
5164.199|5.281|linear this is on a per token level all
5166.78|4.859|the tokens do this independently so the
5169.48|3.6|self-attention is the communication and
5171.639|3.06|then once they've gathered all the data
5173.08|2.94|now they need to think on that data
5174.699|3.0|individually
5176.02|4.619|and so that's what feed forward is doing
5177.699|4.801|and that's why I've added it here now
5180.639|3.54|when I train this the validation loss
5182.5|5.699|actually continues to go down now to
5184.179|6.06|2.24 which is down from 2.28 the output
5188.199|3.781|still look kind of terrible but at least
5190.239|3.841|we've improved the situation
5191.98|4.1|and so as a preview
5194.08|5.159|we're going to now start to intersperse
5196.08|5.38|the communication with the computation
5199.239|4.621|and that's also what the Transformer
5201.46|5.279|does when it has blocks that communicate
5203.86|4.74|and then compute and it groups them and
5206.739|3.96|replicates them
5208.6|3.96|okay so let me show you what we like to
5210.699|3.781|do we'd like to do something like this
5212.56|4.26|we have a block and this block is
5214.48|4.02|basically this part here except for the
5216.82|3.66|cross attention
5218.5|4.38|now the block basically intersperses
5220.48|4.02|communication and then computation the
5222.88|3.839|computation the communication is done
5224.5|3.9|using multi-headed self-attention and
5226.719|3.661|then the computation is done using the
5228.4|3.96|feed forward Network on all the tokens
5230.38|4.74|independently
5232.36|4.799|now what I've added here also is you'll
5235.12|3.72|notice
5237.159|3.0|this takes the number of embeddings in
5238.84|2.76|the embedding Dimension and number of
5240.159|3.261|heads that we would like which is kind
5241.6|4.26|of like group size in group convolution
5243.42|5.799|and I'm saying that number of heads we'd
5245.86|5.16|like is for and so because this is 32 we
5249.219|4.261|calculate that because this 32 the
5251.02|4.26|number of hats should be four
5253.48|3.42|um there's num the head size should be
5255.28|3.66|eight so that everything sort of works
5256.9|3.299|out Channel wise
5258.94|3.9|um so this is how the Transformer
5260.199|4.02|structures uh sort of the uh the sizes
5262.84|3.06|typically
5264.219|3.061|so the head size will become eight and
5265.9|3.6|then this is how we want to intersperse
5267.28|4.26|them and then here I'm trying to create
5269.5|4.739|blocks which is just a sequential
5271.54|4.44|application of block block so that we're
5274.239|3.96|interspersing communication feed forward
5275.98|3.36|many many times and then finally we
5278.199|4.02|decode
5279.34|4.2|now actually try to run this and the
5282.219|4.321|problem is this doesn't actually give a
5283.54|4.679|very good uh answer a very good result
5286.54|3.3|and the reason for that is we're
5288.219|4.261|starting to actually get like a pretty
5289.84|4.26|deep neural net and deep neural Nets uh
5292.48|2.64|suffer from optimization issues and I
5294.1|3.119|think that's where we're kind of like
5295.12|4.2|slightly starting to run into so we need
5297.219|3.0|one more idea that we can borrow from
5299.32|2.64|the
5300.219|3.42|um Transformer paper to resolve those
5301.96|3.66|difficulties now there are two
5303.639|4.02|optimizations that dramatically help
5305.62|3.78|with the depth of these networks and
5307.659|3.421|make sure that the networks remain
5309.4|2.46|optimizable let's talk about the first
5311.08|2.82|one
5311.86|3.359|the first one in this diagram is you see
5313.9|4.02|this Arrow here
5315.219|4.381|and then this arrow and this Arrow those
5317.92|3.48|are skip connections or sometimes called
5319.6|4.139|residual connections
5321.4|3.779|they come from this paper uh the
5323.739|5.041|procedural learning form and recognition
5325.179|4.621|from about 2015. that introduced the
5328.78|4.26|concept
5329.8|5.22|now these are basically what it means is
5333.04|4.38|you transform the data but then you have
5335.02|5.04|a skip connection with addition
5337.42|5.819|from the previous features now the way I
5340.06|4.92|like to visualize it that I prefer is
5343.239|4.801|the following here the computation
5344.98|5.04|happens from the top to bottom and
5348.04|4.44|basically you have this uh residual
5350.02|4.139|pathway and you are free to Fork off
5352.48|3.6|from the residual pathway perform some
5354.159|4.201|computation and then project back to the
5356.08|6.059|residual pathway via addition
5358.36|6.96|and so you go from the the inputs to the
5362.139|4.681|targets only the plus and plus and plus
5365.32|3.54|and the reason this is useful is because
5366.82|4.8|during that propagation remember from
5368.86|4.92|our micrograd video earlier addition
5371.62|5.039|distributes gradients equally to both of
5373.78|6.54|its branches that that fat as the input
5376.659|6.241|and so the supervision or the gradients
5380.32|5.04|from the loss basically hop
5382.9|5.759|through every addition node all the way
5385.36|5.819|to the input and then also Fork off into
5388.659|4.141|the residual blocks
5391.179|3.421|but basically you have this gradient
5392.8|3.899|Super Highway that goes directly from
5394.6|4.86|the supervision all the way to the input
5396.699|4.141|unimpeded and then these virtual blocks
5399.46|3.54|are usually initialized in the beginning
5400.84|4.14|so they contribute very very little if
5403.0|4.38|anything to the residual pathway they
5404.98|3.9|they are initialized that way so in the
5407.38|3.359|beginning they are sort of almost kind
5408.88|4.58|of like not there but then during the
5410.739|6.181|optimization they come online over time
5413.46|5.08|and they start to contribute but at
5416.92|3.48|least at the initialization you can go
5418.54|4.56|from directly supervision to the input
5420.4|5.88|gradient is unimpeded and just close and
5423.1|4.68|then the blocks over time kick in and so
5426.28|3.78|that dramatically helps with the
5427.78|4.14|optimization so let's implement this so
5430.06|4.56|coming back to our block here basically
5431.92|4.62|what we want to do is we want to do x
5434.62|3.9|equals X Plus
5436.54|4.08|solve the tension and x equals X Plus
5438.52|5.52|solve that feed forward
5440.62|5.46|so this is X and then we Fork off and do
5444.04|3.599|some communication and come back and we
5446.08|2.82|Fork off and we do some computation and
5447.639|3.54|come back
5448.9|4.319|so those are residual connections and
5451.179|3.361|then swinging back up here
5453.219|2.761|we also have to introduce this
5454.54|3.84|projection
5455.98|5.94|so nn.linear
5458.38|5.339|and this is going to be from
5461.92|4.02|after we concatenate this this is the
5463.719|4.081|precise and embed so this is the output
5465.94|4.62|of the soft tension itself
5467.8|4.32|but then we actually want the uh to
5470.56|3.72|apply the projection
5472.12|3.539|and that's the result
5474.28|2.82|so the projection is just a linear
5475.659|3.181|transformation of the outcome of this
5477.1|3.36|layer
5478.84|2.94|so that's the projection back into the
5480.46|3.12|residual pathway
5481.78|3.72|and then here in the feed forward it's
5483.58|4.559|going to be the same thing I could have
5485.5|4.08|a soft.projection here as well but let
5488.139|3.261|me just simplify it
5489.58|4.139|and let me
5491.4|3.279|couple it inside the same sequential
5493.719|2.701|container
5494.679|4.381|and so this is the projection layer
5496.42|4.44|going back into the residual pathway
5499.06|4.32|and so
5500.86|4.08|that's uh well that's it so now we can
5503.38|3.96|train this so I implemented one more
5504.94|4.799|small change when you look into the
5507.34|4.26|paper again you see that the
5509.739|3.841|dimensionality of input and output is
5511.6|3.78|512 for them and they're saying that the
5513.58|4.139|inner layer here in the feed forward has
5515.38|3.839|dimensionality of 2048. so there's a
5517.719|3.541|multiplier of four
5519.219|3.42|and so the inner layer of the feed
5521.26|3.0|forward Network
5522.639|3.54|should be multiplied by four in terms of
5524.26|4.32|Channel sizes so I came here and I
5526.179|4.261|multiplied to four times embed here for
5528.58|3.84|the feed forward and then from four
5530.44|3.96|times n embed coming back down to an
5532.42|3.84|embed when we go back to the project to
5534.4|4.08|the projection so adding a bit of
5536.26|4.14|computation here and growing that layer
5538.48|4.44|that is in the residual block on the
5540.4|4.259|side of the residual pathway
5542.92|4.2|and then I trained this and we actually
5544.659|4.621|get down all the way to uh 2.08
5547.12|3.3|validation loss and we also see that the
5549.28|3.12|network is starting to get big enough
5550.42|3.48|that our train loss is getting ahead of
5552.4|3.6|validation loss so we're starting to see
5553.9|5.6|like a little bit of overfitting
5556.0|5.699|and um our our um
5559.5|3.699|Generations here are still not amazing
5561.699|4.681|but at least you see that we can see
5563.199|4.98|like is here this now grieve sank
5566.38|3.54|like this starts to almost look like
5568.179|2.881|English so
5569.92|3.0|um yeah we're starting to really get
5571.06|3.72|there okay and the second Innovation
5572.92|4.44|that is very helpful for optimizing very
5574.78|3.66|deep neural networks is right here so we
5577.36|3.359|have this addition now that's the
5578.44|3.96|residual part but this Norm is referring
5580.719|3.721|to something called layer Norm
5582.4|4.259|so layer Norm is implemented in pi torch
5584.44|4.259|it's a paper that came out a while back
5586.659|3.421|here
5588.699|3.061|um
5590.08|4.8|and layer Norm is very very similar to
5591.76|5.1|Bachelor so remember back to our make
5594.88|3.66|more series part three we implemented
5596.86|3.54|batch normalization
5598.54|4.8|and patch normalization basically just
5600.4|6.68|made sure that across the batch
5603.34|5.54|Dimension any individual neuron had unit
5607.08|4.599|gaussian
5608.88|4.839|distribution so it was zero mean and
5611.679|4.02|unit standard deviation one standard
5613.719|4.201|deviation output
5615.699|3.901|so what I did here is I'm copy pasting
5617.92|2.94|The Bachelor 1D that we developed in our
5619.6|4.079|makemore series
5620.86|4.799|and see here we can initialize for
5623.679|4.441|example this module and we can have a
5625.659|4.5|batch of 32 100 dimensional vectors
5628.12|5.28|feeding through the bathroom layer
5630.159|5.101|so what this does is it guarantees
5633.4|2.94|that when we look at just the zeroth
5635.26|3.959|column
5636.34|5.52|it's a zero mean one standard deviation
5639.219|4.621|so it's normalizing every single column
5641.86|4.62|of this input
5643.84|4.379|now the rows are not going to be
5646.48|3.9|normalized by default because we're just
5648.219|4.381|normalizing columns so let's now
5650.38|5.22|implement the layer Norm uh it's very
5652.6|6.3|complicated look we come here we change
5655.6|6.059|this from 0 to 1. so we don't normalize
5658.9|6.06|The Columns we normalize the rows
5661.659|5.941|and now we've implemented layer Norm
5664.96|4.46|so now the columns are not going to be
5667.6|4.68|normalized
5669.42|4.719|but the rows are going to be normalized
5672.28|4.32|for every individual example it's 100
5674.139|5.281|dimensional Vector is normalized in this
5676.6|5.7|way and because our computation Now does
5679.42|6.54|not span across examples we can delete
5682.3|6.54|all of this buffers stuff because we can
5685.96|5.16|always apply this operation and don't
5688.84|4.14|need to maintain any running buffers so
5691.12|5.22|we don't need the buffers
5692.98|5.9|we don't There's no distinction between
5696.34|4.98|training and test time
5698.88|5.319|and we don't need these running buffers
5701.32|4.44|we do keep gamma and beta we don't need
5704.199|3.061|the momentum we don't care if it's
5705.76|4.86|training or not
5707.26|5.939|and this is now a layer Norm
5710.62|4.92|and it normalizes the rows instead of
5713.199|6.181|the columns and this here
5715.54|6.3|is identical to basically this here
5719.38|4.2|so let's now Implement layer Norm in our
5721.84|3.899|Transformer before I incorporate the
5723.58|3.84|layer Norm I just wanted to note that as
5725.739|2.881|I said very few details about the
5727.42|2.58|Transformer have changed in the last
5728.62|2.88|five years but this is actually
5730.0|3.96|something that slightly departs from the
5731.5|5.58|original paper you see that the ADD and
5733.96|7.08|Norm is applied after the transformation
5737.08|6.42|but um in now it is a bit more basically
5741.04|3.96|common to apply the layer Norm before
5743.5|3.78|the transformation so there's a
5745.0|3.84|reshuffling of the layer Norms uh so
5747.28|2.76|this is called the pre-norm formulation
5748.84|2.7|and that's the one that we're going to
5750.04|3.179|implement as well so slight deviation
5751.54|3.78|from the original paper
5753.219|6.241|basically we need two layer Norms layer
5755.32|5.399|Norm one is an N dot layer norm and we
5759.46|3.179|tell it how many
5760.719|4.381|um what is the embedding dimension
5762.639|4.801|and we need the second layer Norm
5765.1|4.2|and then here the layer rooms are
5767.44|5.4|applied immediately on x
5769.3|5.399|so self.layer number one in applied on x
5772.84|4.319|and salt on layer number two applied on
5774.699|4.141|X before it goes into sulfur tension and
5777.159|4.261|feed forward
5778.84|5.22|and the size of the layer Norm here is
5781.42|6.0|an embeds of 32. so when the layer Norm
5784.06|6.06|is normalizing our features it is the
5787.42|5.16|normalization here
5790.12|4.98|happens the mean and the variance are
5792.58|5.099|taking over 32 numbers so the batch and
5795.1|5.84|the time act as batch Dimensions both of
5797.679|5.46|them so this is kind of like a per token
5800.94|5.739|transformation that just normalizes the
5803.139|6.121|features and makes them a unit mean unit
5806.679|4.321|gaussian at initialization
5809.26|4.2|but of course because these layer Norms
5811.0|3.96|inside it have these gamma and beta
5813.46|5.219|trainable parameters
5814.96|5.64|the layer normal eventually create
5818.679|4.741|outputs that might not be unit gaussian
5820.6|5.099|but the optimization will determine that
5823.42|3.9|so for now this is the uh this is
5825.699|4.321|incorporating the layer norms and let's
5827.32|5.04|train them up okay so I let it run and
5830.02|4.619|we see that we get down to 2.06 which is
5832.36|3.72|better than the previous 2.08 so a
5834.639|3.961|slight Improvement by adding the layer
5836.08|4.86|norms and I'd expect that they help even
5838.6|4.44|more if we had bigger and deeper Network
5840.94|4.08|one more thing I forgot to add is that
5843.04|4.26|there should be a layer Norm here also
5845.02|4.199|typically as at the end of the
5847.3|4.2|Transformer and right before the final
5849.219|5.881|linear layer that decodes into
5851.5|4.8|vocabulary so I added that as well so at
5855.1|3.119|this stage we actually have a pretty
5856.3|4.02|complete Transformer according to the
5858.219|4.201|original paper and it's a decoder only
5860.32|4.68|Transformer I'll I'll talk about that in
5862.42|4.08|a second but at this stage the major
5865.0|3.06|pieces are in place so we can try to
5866.5|2.699|scale this up and see how well we can
5868.06|3.179|push this number
5869.199|3.721|now in order to scale out the model I
5871.239|4.201|had to perform some cosmetic changes
5872.92|4.14|here to make it nicer so I introduced
5875.44|3.96|this variable called end layer which
5877.06|4.8|just specifies how many layers of the
5879.4|3.6|blocks we're going to have I create a
5881.86|3.48|bunch of blocks and we have a new
5883.0|4.86|variable number of heads as well
5885.34|4.799|I pulled out the layer Norm here and so
5887.86|5.279|this is identical now one thing that I
5890.139|5.281|did briefly change is I added a dropout
5893.139|4.5|so Dropout is something that you can add
5895.42|3.36|right before the residual connection
5897.639|2.461|back
5898.78|2.82|or right before the connection back into
5900.1|3.48|the original pathway
5901.6|3.059|so we can drop out that as the last
5903.58|3.72|layer here
5904.659|4.681|we can drop out uh here at the end of
5907.3|5.1|the multi-headed extension as well
5909.34|6.0|and we can also drop out here when we
5912.4|5.16|calculate the um basically affinities
5915.34|4.44|and after the soft Max we can drop out
5917.56|4.38|some of those so we can randomly prevent
5919.78|5.34|some of the nodes from communicating
5921.94|5.4|and so Dropout comes from this paper
5925.12|6.42|from 2014 or so
5927.34|6.42|and basically it takes your neural net
5931.54|6.3|and it randomly every forward backward
5933.76|7.14|pass shuts off some subset of neurons
5937.84|5.399|so randomly drops them to zero and
5940.9|4.739|trains without them and what this does
5943.239|3.781|effectively is because the mask of
5945.639|3.241|what's being dropped out has changed
5947.02|4.8|every single forward backward pass it
5948.88|5.339|ends up kind of training an ensemble of
5951.82|4.08|sub Networks and then at this time
5954.219|3.241|everything is fully enabled and kind of
5955.9|3.6|all of those sub networks are merged
5957.46|3.84|into a single Ensemble if you can if you
5959.5|3.239|want to think about it that way so I
5961.3|3.54|would read the paper to get the full
5962.739|4.021|detail for now we're just going to stay
5964.84|4.319|on the level of this is a regularization
5966.76|3.899|technique and I added it because I'm
5969.159|4.08|about to scale up the model quite a bit
5970.659|5.401|and I was concerned about overfitting
5973.239|4.201|so now when we scroll up to the top uh
5976.06|3.24|we'll see that I changed a number of
5977.44|3.84|hyper parameters here about our neural
5979.3|3.78|net so I made the batch size B much
5981.28|4.56|larger now with 64.
5983.08|4.26|I changed the block size to be 256 so
5985.84|4.02|previously it was just eight eight
5987.34|4.44|characters of context now it is 256
5989.86|3.96|characters of context to predict the
5991.78|4.379|257th
5993.82|3.66|uh I brought down the learning rate a
5996.159|2.821|little bit because the neural net is now
5997.48|2.64|much bigger so I brought down the
5998.98|3.54|learning rate
6000.12|6.0|the embedding Dimension is now 384 and
6002.52|6.24|there are six heads so 384 divide 6
6006.12|4.86|means that every head is 64 dimensional
6008.76|3.959|as it as a standard
6010.98|2.94|and then there are going to be six
6012.719|3.241|layers of that
6013.92|3.96|and the Dropout will be of 0.2 so every
6015.96|3.779|forward backward passed 20 percent of
6017.88|4.319|all of these um
6019.739|4.201|intermediate calculations are disabled
6022.199|3.601|and dropped to zero
6023.94|4.56|and then I already trained this and I
6025.8|3.78|ran it so uh drum roll how well does it
6028.5|3.96|perform
6029.58|6.54|so let me just scroll up here
6032.46|4.739|we get a validation loss of 1.48 which
6036.12|2.46|is actually quite a bit of an
6037.199|4.44|improvement on what we had before which
6038.58|5.22|I think was 2.07 so we went from 2.07
6041.639|3.841|all the way down to 1.48 just by scaling
6043.8|3.96|up this neural nut with the code that we
6045.48|4.38|have and this of course ran for a lot
6047.76|5.28|longer this may be trained for I want to
6049.86|5.22|say about 15 minutes on my a100 GPU so
6053.04|3.179|that's a pretty good GPU and if you
6055.08|3.9|don't have a GPU you're not going to be
6056.219|3.721|able to reproduce this on a CPU this
6058.98|2.759|would be
6059.94|3.239|um I would not run this on the CPU or a
6061.739|3.541|Macbook or something like that you'll
6063.179|4.98|have to break down the number of layers
6065.28|4.859|and the embedding Dimension and so on
6068.159|4.141|but in about 15 minutes we can get this
6070.139|3.721|kind of a result and
6072.3|3.359|um I'm printing
6073.86|3.9|some of the Shakespeare here but what I
6075.659|4.801|did also is I printed 10 000 characters
6077.76|6.379|so a lot more and I wrote them to a file
6080.46|3.679|and so here we see some of the outputs
6084.179|5.101|so it's a lot more recognizable as the
6087.06|4.619|input text file so the input text file
6089.28|4.379|just for reference looked like this
6091.679|4.861|so there's always like someone speaking
6093.659|5.701|in this matter and uh
6096.54|4.38|our predictions now take on that form
6099.36|3.48|except of course they're they're
6100.92|3.6|nonsensical when you actually read them
6102.84|5.1|so
6104.52|7.92|it is every crimpy bee house oh those
6107.94|7.219|preparation we give heed
6112.44|2.719|um you know
6116.04|3.98|Oho sent me you mighty Lord
6120.659|4.201|anyway so you can read through this
6122.699|3.96|um it's nonsensical of course but this
6124.86|3.839|is just a Transformer trained on the
6126.659|4.02|Character level for 1 million characters
6128.699|3.781|that come from Shakespeare so they're
6130.679|4.081|sort of like blabbers on and Shakespeare
6132.48|4.139|like manner but it doesn't of course
6134.76|4.439|make sense at this scale
6136.619|5.04|uh but I think I think still a pretty
6139.199|5.101|good demonstration of what's possible
6141.659|4.681|so now
6144.3|4.56|I think uh that kind of like concludes
6146.34|4.319|the programming section of this video we
6148.86|4.62|basically kind of did a pretty good job
6150.659|5.58|in um of implementing this Transformer
6153.48|4.5|but the picture doesn't exactly match up
6156.239|4.021|to what we've done so what's going on
6157.98|3.659|with all these additional Parts here so
6160.26|3.78|let me finish explaining this
6161.639|4.56|architecture and why it looks so funky
6164.04|4.32|basically what's happening here is what
6166.199|4.98|we implemented here is a decoder only
6168.36|4.92|Transformer so there's no component here
6171.179|4.141|this part is called the encoder and
6173.28|5.04|there's no cross attention block here
6175.32|5.1|our block only has a self-attention and
6178.32|5.16|the feed forward so it is missing this
6180.42|5.04|third in between piece here this piece
6183.48|3.78|does cross attention so we don't have it
6185.46|3.6|and we don't have the encoder we just
6187.26|3.419|have the decoder and the reason we have
6189.06|4.02|a decoder only
6190.679|4.321|is because we are just generating text
6193.08|3.659|and it's unconditioned on anything we're
6195.0|3.239|just we're just blabbering on according
6196.739|3.661|to a given data set
6198.239|4.621|what makes it a decoder is that we are
6200.4|4.38|using the Triangular mask in our
6202.86|4.08|Transformer so it has this Auto
6204.78|3.72|regressive property where we can just go
6206.94|3.0|and sample from it
6208.5|4.08|so the fact that it's using the
6209.94|4.92|Triangular triangular mask to mask out
6212.58|4.559|the attention makes it a decoder and it
6214.86|4.259|can be used for language modeling now
6217.139|4.02|the reason that the original paper had
6219.119|3.301|an encoder decoder architecture is
6221.159|3.421|because it is a machine translation
6222.42|4.319|paper so it is concerned with a
6224.58|5.94|different setting in particular
6226.739|5.221|it expects some tokens that encode say
6230.52|3.659|for example French
6231.96|3.84|and then it is expected to decode the
6234.179|4.02|translation in English
6235.8|4.98|so so you typically these here are
6238.199|5.52|special tokens so you are expected to
6240.78|4.5|read in this and condition on it and
6243.719|3.9|then you start off the generation with a
6245.28|5.339|special token called start so this is a
6247.619|4.681|special new token that you introduce and
6250.619|4.161|always place in the beginning
6252.3|5.52|and then the network is expected to put
6254.78|6.22|neural networks are awesome and then a
6257.82|5.94|special end token to finish a generation
6261.0|4.98|so this part here will be decoded
6263.76|3.899|exactly as we we've done it neural
6265.98|2.88|networks are awesome will be identical
6267.659|3.901|to what we did
6268.86|5.64|but unlike what we did they want to
6271.56|4.86|condition the generation on some
6274.5|3.659|additional information and in that case
6276.42|2.94|this additional information is the
6278.159|2.401|French sentence that they should be
6279.36|3.06|translating
6280.56|4.5|so what they do now
6282.42|5.88|is they bring in the encoder now the
6285.06|4.74|encoder reads this part here so we're
6288.3|4.56|only going to take the part of French
6289.8|5.04|and we're going to create tokens from it
6292.86|4.02|exactly as we've seen in our video and
6294.84|3.839|we're going to put a Transformer on it
6296.88|4.02|but there's going to be no triangular
6298.679|3.54|mask and so all the tokens are allowed
6300.9|3.12|to talk to each other as much as they
6302.219|3.96|want and they're just encoding
6304.02|4.08|whatever's the content of this French
6306.179|4.02|sentence
6308.1|4.32|once they've encoded it
6310.199|3.061|they've they basically come out in the
6312.42|2.64|top here
6313.26|5.04|and then what happens here is in our
6315.06|6.3|decoder which does the language modeling
6318.3|5.04|there's an additional connection here to
6321.36|4.62|the outputs of the encoder
6323.34|3.66|and that is brought in through a cross
6325.98|2.759|attention
6327.0|4.199|so the queries are still generated from
6328.739|4.44|X but now the keys and the values are
6331.199|3.901|coming from the side the keys and the
6333.179|3.96|values are coming from the top
6335.1|3.9|generated by the nodes that came outside
6337.139|4.56|of the encoder
6339.0|4.739|and those tops the keys and the values
6341.699|4.201|there the top of it
6343.739|4.561|feeding on the side into every single
6345.9|3.839|block of the decoder and so that's why
6348.3|3.54|there's an additional cross attention
6349.739|4.681|and really what it's doing is it's
6351.84|5.399|conditioning the decoding not just on
6354.42|6.66|the past of this current decoding but
6357.239|5.541|also on having seen the full fully
6361.08|3.84|encoded French
6362.78|3.82|prompt sort of
6364.92|2.699|and so it's an encoder decoder model
6366.6|3.36|which is why we have those two
6367.619|4.5|Transformers an additional block and so
6369.96|3.96|on so we did not do this because we have
6372.119|3.421|no we have nothing to encode there's no
6373.92|3.18|conditioning we just have a text file
6375.54|3.48|and we just want to imitate it and
6377.1|5.579|that's why we are using a decoder only
6379.02|5.699|Transformer exactly as done in GPT
6382.679|4.02|okay so now I wanted to do a very brief
6384.719|4.861|walkthrough of Nano GPT which you can
6386.699|4.801|find on my GitHub and uh Nano GPT is
6389.58|5.159|basically two files of Interest there's
6391.5|4.92|train.pi and model.pi trained at Pi is
6394.739|3.841|all the boilerplate code for training
6396.42|4.44|the network it is basically all the
6398.58|3.18|stuff that we had here it's the training
6400.86|2.1|Loop
6401.76|2.939|it's just that it's a lot more
6402.96|3.239|complicated because we're saving and
6404.699|4.081|loading checkpoints and pre-trained
6406.199|4.381|weights and we are decaying the learning
6408.78|3.3|rate and compiling the model and using
6410.58|4.26|distributed training across multiple
6412.08|4.74|nodes or gpus so the training that Pi
6414.84|4.62|gets a little bit more hairy complicated
6416.82|5.46|there's more options Etc
6419.46|5.1|but the model.pi should look very very
6422.28|4.919|um similar to what we've done here in
6424.56|5.159|fact the model is is almost identical
6427.199|4.681|so first here we have the causal
6429.719|3.601|self-attention block and all of this
6431.88|3.72|should look very very recognizable to
6433.32|4.859|you we're producing queries Keys values
6435.6|5.34|we're doing Dot products we're masking
6438.179|6.06|applying softmax optionally dropping out
6440.94|5.52|and here we are pooling the values
6444.239|3.181|what is different here is that in our
6446.46|4.32|code
6447.42|5.219|I have separated out the multi-headed
6450.78|2.7|attention into just a single individual
6452.639|3.06|head
6453.48|4.32|and then here I have multiple heads and
6455.699|4.861|I explicitly concatenate them
6457.8|4.919|whereas here all of it is implemented in
6460.56|4.26|a batched manner inside a single causal
6462.719|4.44|self-attention and so we don't just have
6464.82|3.72|a b and a T and A C Dimension we also
6467.159|2.641|end up with a fourth dimension which is
6468.54|3.599|the heads
6469.8|3.66|and so it just gets a lot more sort of
6472.139|5.04|hairy because we have four dimensional
6473.46|5.82|array tensors now but it is equivalent
6477.179|4.081|mathematically so the exact same thing
6479.28|3.66|is happening is what we have it's just
6481.26|3.24|it's a bit more efficient because all
6482.94|3.719|the heads are not treated as a batch
6484.5|4.08|Dimension as well
6486.659|4.261|then we have to multiply perceptron it's
6488.58|5.039|using the gallon nonlinearity which is
6490.92|4.199|defined here except instead of relu and
6493.619|2.701|this is done just because openingi used
6495.119|2.58|it and I want to be able to load their
6496.32|3.419|checkpoints
6497.699|3.721|uh the blocks of the Transformer are
6499.739|3.48|identical the communicate and the
6501.42|3.66|compute phase as we saw
6503.219|3.48|and then the GPT will be identical we
6505.08|4.139|have the position encodings token
6506.699|5.52|encodings the blocks the layer Norm at
6509.219|4.621|the end the final linear layer
6512.219|2.701|and this should look all very
6513.84|2.879|recognizable
6514.92|3.18|and there's a bit more here because I'm
6516.719|3.541|loading checkpoints and stuff like that
6518.1|3.72|I'm separating out the parameters into
6520.26|3.899|building that should be weight decayed
6521.82|3.839|and those that shouldn't
6524.159|3.841|um but the generate function should also
6525.659|3.661|be very very similar so a few details
6528.0|4.139|are different but you should definitely
6529.32|4.08|be able to look at this uh file and be
6532.139|3.301|able to understand a lot of the pieces
6533.4|3.239|now so let's now bring things back to
6535.44|2.82|chat GPT
6536.639|3.6|what would it look like if we wanted to
6538.26|4.14|train chatgpt ourselves and how does it
6540.239|3.781|relate to what we learned today
6542.4|3.6|well to train in chat GPT there are
6544.02|3.78|roughly two stages first is the
6546.0|4.4|pre-training stage and then the fine
6547.8|5.1|tuning stage in the pre-training stage
6550.4|5.02|we are training on a large chunk of
6552.9|5.339|internet and just trying to get a first
6555.42|5.46|decoder only Transformer to Babel text
6558.239|4.021|so it's very very similar to what we've
6560.88|3.42|done ourselves
6562.26|4.04|except we've done like a tiny little
6564.3|5.939|baby pre-training step
6566.3|6.04|and so in our case uh this is how you
6570.239|4.261|print a number of parameters I printed
6572.34|3.899|it and it's about 10 million so this
6574.5|4.02|Transformer that I created here to
6576.239|4.5|create little Shakespeare
6578.52|5.219|um Transformer was about 10 million
6580.739|5.101|parameters our data set is roughly 1
6583.739|3.96|million uh characters so roughly 1
6585.84|3.72|million tokens but you have to remember
6587.699|3.54|that opening uses different vocabulary
6589.56|5.22|they're not on the Character level they
6591.239|5.281|use these um subword chunks of words and
6594.78|4.2|so they have a vocabulary of 50 000
6596.52|4.56|roughly elements and so their sequences
6598.98|4.56|are a bit more condensed
6601.08|5.039|so our data set the Shakespeare data set
6603.54|5.639|would be probably around 300 000 tokens
6606.119|5.58|in the openai vocabulary roughly
6609.179|5.04|so we trained about 10 million parameter
6611.699|5.761|model and roughly 300 000 tokens
6614.219|6.061|now when you go to the gpd3 paper
6617.46|4.259|and you look at the Transformers that
6620.28|2.939|they trained
6621.719|3.661|they trained a number of Transformers of
6623.219|4.201|different sizes but the biggest
6625.38|5.279|Transformer here has 175 billion
6627.42|5.219|parameters so ours is again 10 million
6630.659|4.381|they used this number of layers in the
6632.639|4.801|Transformer This is the End embed
6635.04|4.02|this is the number of heads and this is
6637.44|4.56|the head size
6639.06|4.98|and then this is the batch size so ours
6642.0|4.26|was 65.
6644.04|3.96|and the learning rate is similar now
6646.26|4.2|when they train this Transformer they
6648.0|4.98|trained on 300 billion tokens
6650.46|5.58|so again remember ours is about 300 000
6652.98|4.98|so this is uh about a million fold
6656.04|3.3|increase and this number would not be
6657.96|3.6|even that large by today's standards
6659.34|3.24|you'd be going up uh one trillion and
6661.56|3.96|above
6662.58|4.619|so they are training a significantly
6665.52|4.98|larger model
6667.199|5.401|on a good chunk of the internet and that
6670.5|3.659|is the pre-training stage but otherwise
6672.6|3.539|these hyper parameters should be fairly
6674.159|3.721|recognizable to you and the architecture
6676.139|3.661|is actually like nearly identical to
6677.88|3.359|what we implemented ourselves but of
6679.8|3.72|course it's a massive infrastructure
6681.239|4.801|challenge to train this you're talking
6683.52|4.86|about typically thousands of gpus having
6686.04|4.5|to you know talk to each other to train
6688.38|4.14|models of this size so that's just a
6690.54|4.32|pre-training stage now after you
6692.52|4.199|complete the pre-training stage you
6694.86|3.779|don't get something that responds to
6696.719|4.381|your questions with answers and is not
6698.639|6.121|helpful and Etc you get a document
6701.1|5.4|completer right so it babbles but it
6704.76|3.6|doesn't Babble Shakespeare in Babel's
6706.5|3.78|internet it will create arbitrary news
6708.36|3.299|articles and documents and it will try
6710.28|2.52|to complete documents because that's
6711.659|3.181|what it's trained for it's trying to
6712.8|3.78|complete the sequence so when you give
6714.84|3.899|it a question it would just uh
6716.58|4.02|potentially just give you more questions
6718.739|4.141|it would follow with more questions it
6720.6|4.86|will do whatever it looks like the some
6722.88|4.5|closed document would do in the training
6725.46|3.179|data on the internet and so who knows
6727.38|3.839|you're getting kind of like undefined
6728.639|4.681|Behavior it might basically answer with
6731.219|3.96|two questions with other questions it
6733.32|3.899|might ignore your question it might just
6735.179|4.56|try to complete some news article it's
6737.219|4.741|totally underlined as we say
6739.739|4.98|so the second fine tuning stage is to
6741.96|4.739|actually align it to be an assistant and
6744.719|4.5|this is the second stage
6746.699|4.261|and so this Chachi PT blog post from
6749.219|4.98|open AI talks a little bit about how the
6750.96|4.259|stage is achieved we basically
6754.199|2.701|um
6755.219|3.9|there's roughly three steps to the to
6756.9|4.44|this stage uh so what they do here is
6759.119|3.901|they start to collect training data that
6761.34|3.359|looks specifically like what an
6763.02|3.24|assistant would do so if you have
6764.699|3.301|documents that have the format where the
6766.26|3.959|question is on top and then an answer is
6768.0|4.02|below and they have a large number of
6770.219|3.661|these but probably not on the order of
6772.02|4.86|the internet this is probably on the
6773.88|6.0|order of maybe thousands of examples
6776.88|6.12|and so they they then fine-tuned the
6779.88|5.04|model to basically only focus on
6783.0|3.6|documents that look like that and so
6784.92|3.299|you're starting to slowly align it so
6786.6|3.119|it's going to expect a question at the
6788.219|2.46|top and it's going to expect to complete
6789.719|3.721|the answer
6790.679|4.56|and uh these very very large models are
6793.44|3.84|very sample efficient during their fine
6795.239|4.081|tuning so this actually somehow works
6797.28|3.959|but that's just step one that's just
6799.32|4.44|fine-tuning so then they actually have
6801.239|4.5|more steps where okay the second step is
6803.76|3.479|you let the model respond and then
6805.739|3.781|different Raiders look at the different
6807.239|3.721|responses and rank them for their
6809.52|3.54|preference as to which one is better
6810.96|3.96|than the other they use that to train a
6813.06|4.32|reward model so they can predict
6814.92|6.84|basically using a different network how
6817.38|5.4|much of any candidate response would be
6821.76|2.64|desirable
6822.78|4.62|and then once they have a reward model
6824.4|4.799|they run PPO which is a form of policy
6827.4|3.18|policy gradient um reinforcement
6829.199|5.281|learning optimizer
6830.58|6.539|to fine-tune this sampling policy so
6834.48|6.06|that the answers that the GPT GPT now
6837.119|6.421|generates are expected to score a high
6840.54|4.679|reward according to the reward model
6843.54|3.96|and so basically there's a whole the
6845.219|4.201|lining stage here or fine-tuning stage
6847.5|4.56|it's got multiple steps in between there
6849.42|5.52|as well and it takes the model from
6852.06|5.579|being a document completer to a question
6854.94|4.739|answer and that's like a whole separate
6857.639|4.141|stage a lot of this data is not
6859.679|4.5|available publicly it is internal to
6861.78|4.8|open Ai and it's much harder to
6864.179|4.081|replicate this stage
6866.58|4.68|um and so that's roughly what would give
6868.26|4.74|you a child GPD and Nano GPT focuses on
6871.26|3.2|the pre-training stage okay and that's
6873.0|5.82|everything that I wanted to cover today
6874.46|7.3|so we trained to summarize a decoder
6878.82|4.56|only Transformer following this famous
6881.76|3.06|paper attention is all you need from
6883.38|4.44|2017.
6884.82|5.64|and so that's basically a GPT we trained
6887.82|4.859|it on a tiny Shakespeare and got
6890.46|4.92|sensible results
6892.679|5.641|all of the training code is roughly
6895.38|6.96|200 lines of code I will be releasing
6898.32|6.48|this um code base so also it comes with
6902.34|4.379|all the git log commits along the way as
6904.8|3.48|we built it up
6906.719|4.381|in addition to this code I'm going to
6908.28|4.2|release the notebook of course the
6911.1|3.059|Google collab
6912.48|2.82|and I hope that gave you a sense for how
6914.159|2.04|you can train
6915.3|3.62|um
6916.199|4.861|these models like say gpt3 there will be
6918.92|3.64|architecturally basically identical to
6921.06|3.119|what we have but they are somewhere
6922.56|4.139|between ten thousand and one million
6924.179|6.601|times bigger depending on how you count
6926.699|5.52|and so that's all I have for now we did
6930.78|3.18|not talk about any of the fine tuning
6932.219|3.48|stages that would typically go on top of
6933.96|2.64|this so if you're interested in
6935.699|2.821|something that's not just language
6936.6|4.5|modeling but you actually want to you
6938.52|5.099|know say perform tasks or you want them
6941.1|4.8|to be aligned in a specific way or you
6943.619|3.961|want to detect sentiment or anything
6945.9|3.06|like that basically anytime you don't
6947.58|3.539|want something that's just a document
6948.96|3.9|completer you have to complete further
6951.119|2.701|stages of fine tuning which we did not
6952.86|3.06|cover
6953.82|3.72|uh and that could be simple supervised
6955.92|3.48|fine tuning or it can be something more
6957.54|3.78|fancy like we see in chargept we
6959.4|4.319|actually train a reward model and then
6961.32|4.02|do rounds of PPO to align it with
6963.719|2.94|respect to the reward model
6965.34|3.06|so there's a lot more that can be done
6966.659|3.241|on top of it I think for now we're
6968.4|3.299|starting to get to about two hours Mark
6969.9|4.14|so I'm going to
6971.699|4.98|um kind of finish here
6974.04|4.92|I hope you enjoyed the lecture and uh
6976.679|4.341|yeah go forth and transform see you
6978.96|2.06|later