start_time|end_time|text
0.0|3.06|think it's possible that physics has
1.62|3.24|exploits and we should be trying to find
3.06|3.839|them arranging some kind of a crazy
4.86|4.199|quantum mechanical system that somehow
6.899|3.301|gives you buffer overflow somehow gives
9.059|4.08|you a rounding error in the floating
10.2|4.58|Point synthetic intelligences are kind
13.139|4.381|of like the next stage of development
14.78|5.2|and I don't know where it leads to like
17.52|5.12|at some point I suspect
19.98|5.219|the universe is some kind of a puzzle
22.64|4.18|these synthetic AIS will uncover that
25.199|4.521|puzzle and
26.82|2.9|solve it
29.939|4.501|the following is a conversation with
31.679|6.241|Andre capothy previously the director of
34.44|7.279|AI at Tesla and before that at open Ai
37.92|7.319|and Stanford he is one of the greatest
41.719|5.921|scientists engineers and Educators in
45.239|5.221|the history of artificial intelligence
47.64|4.739|this is the Lex Friedman podcast to
50.46|5.34|support it please check out our sponsors
52.379|5.581|and now dear friends here's Andre
55.8|5.16|capathi
57.96|5.399|what is a neural network and why does it
60.96|4.379|seem to uh do such a surprisingly good
63.359|5.521|job of learning what is a neural network
65.339|5.701|it's a mathematical abstraction of
68.88|3.66|the brain I would say that's how it was
71.04|2.579|originally developed
72.54|2.46|at the end of the day it's a
73.619|2.521|mathematical expression and it's a
75.0|3.96|fairly simple mathematical expression
76.14|5.519|when you get down to it it's basically a
78.96|4.92|sequence of Matrix multiplies which are
81.659|4.14|really dot products mathematically and
83.88|2.94|some nonlinearities thrown in and so
85.799|3.781|it's a very simple mathematical
86.82|4.979|expression and it's got knobs in it many
89.58|3.78|knobs many knobs and these knobs are
91.799|3.0|Loosely related to basically the
93.36|3.299|synapses in your brain they're trainable
94.799|3.301|they're modifiable and so the idea is
96.659|3.96|like we need to find the setting of The
98.1|4.08|Knobs that makes the neural nut do
100.619|4.14|whatever you want it to do like classify
102.18|4.74|images and so on and so there's not too
104.759|4.381|much mystery I would say in it like
106.92|3.36|um you might think that basically don't
109.14|3.18|want to endow it with too much meaning
110.28|3.839|with respect to the brain and how it
112.32|3.42|works it's really just a complicated
114.119|3.721|mathematical expression with knobs and
115.74|4.019|those knobs need a proper setting for it
117.84|4.319|to do something uh desirable yeah but
119.759|4.921|poetry is just the collection of letters
122.159|4.261|with spaces but it can make us feel a
124.68|3.48|certain way and in that same way when
126.42|4.74|you get a large number of knobs together
128.16|5.76|whether it's in a inside the brain or
131.16|4.68|inside a computer they seem to they seem
133.92|4.14|to surprise us with the with their power
135.84|5.16|yeah I think that's fair so basically
138.06|4.98|I'm underselling it by a lot because you
141.0|4.14|definitely do get very surprising
143.04|3.839|emergent behaviors out of these neurons
145.14|4.26|when they're large enough and trained on
146.879|4.86|complicated enough problems like say for
149.4|4.62|example the next uh word prediction in a
151.739|4.14|massive data set from the internet and
154.02|4.14|then these neurons take on a pretty
155.879|3.481|surprising magical properties yeah I
158.16|2.939|think it's kind of interesting how much
159.36|3.72|you can get out of even very simple
161.099|4.201|mathematical formalism when your brain
163.08|4.019|right now I was talking is it doing next
165.3|3.12|word prediction
167.099|3.121|or is it doing something more
168.42|4.14|interesting well definitely some kind of
170.22|4.14|a generative model that's a gpt-like and
172.56|3.42|prompted by you
174.36|3.599|um yeah so you're giving me a prompt and
175.98|4.56|I'm kind of like responding to it in a
177.959|5.161|generative way and by yourself perhaps a
180.54|4.86|little bit like are you adding extra
183.12|3.259|prompts from your own memory inside your
185.4|2.52|head
186.379|3.161|automatically feels like you're
187.92|4.8|referencing some kind of a declarative
189.54|5.1|structure of like memory and so on and
192.72|4.14|then uh you're putting that together
194.64|4.14|with your prompt and giving away some
196.86|4.86|messages like how much of what you just
198.78|6.36|said has been said by you before
201.72|4.62|uh nothing basically right no but if you
205.14|3.3|actually look at all the words you've
206.34|5.16|ever said in your life and you do a
208.44|6.0|search you'll probably said a lot of the
211.5|4.98|same words in the same order before yeah
214.44|4.079|it could be I mean I'm using phrases
216.48|4.92|that are common Etc but I'm remixing it
218.519|4.021|into a pretty uh sort of unique sentence
221.4|2.28|at the end of the day but you're right
222.54|4.259|definitely there's like a ton of
223.68|5.9|remixing what you didn't you it's like
226.799|5.881|Magnus Carlsen said uh I'm I'm rated
229.58|6.159|2900 whatever which is pretty decent I
232.68|4.88|think you're talking very uh you're not
235.739|4.92|giving enough credit to neural Nets here
237.56|5.5|why do they seem to
240.659|5.341|what's your best intuition
243.06|3.84|about this emergent Behavior I mean it's
246.0|3.299|kind of interesting because I'm
246.9|3.419|simultaneously underselling them but I
249.299|3.0|also feel like there's an element to
250.319|3.42|which I'm over like it's actually kind
252.299|2.881|of incredible that you can get so much
253.739|2.701|emergent magical Behavior out of them
255.18|3.239|despite them being so simple
256.44|3.66|mathematically so I think those are kind
258.419|4.141|of like two surprising statements that
260.1|4.26|are kind of just juxtapose together
262.56|3.359|and I think basically what it is is we
264.36|3.779|are actually fairly good at optimizing
265.919|4.861|these neural Nets and when you give them
268.139|4.981|a hard enough problem they are forced to
270.78|4.44|learn very interesting Solutions in the
273.12|4.079|optimization and those solution
275.22|3.12|basically have these immersion
277.199|3.901|properties that are very interesting
278.34|4.94|there's wisdom and knowledge
281.1|5.099|in the knobs
283.28|5.68|and so what's this representation that's
286.199|4.801|in the knobs does it make sense to you
288.96|4.08|intuitively the large number of knobs
291.0|4.86|can hold the representation that
293.04|4.379|captures some deep wisdom about the data
295.86|3.839|it has looked at
297.419|4.921|it's a lot of knobs it's a lot of knobs
299.699|3.661|and somehow you know so speaking
302.34|2.4|concretely
303.36|3.119|um one of the neural Nets that people
304.74|4.2|are very excited about right now are are
306.479|5.28|gpts which are basically just next word
308.94|4.979|prediction networks so you consume a
311.759|5.401|sequence of words from the internet and
313.919|5.28|you try to predict the next word and uh
317.16|3.18|once you train these on a large enough
319.199|4.321|data set
320.34|4.5|um they you can basically uh prompt
323.52|2.459|these neural amounts in arbitrary ways
324.84|3.359|and you can ask them to solve problems
325.979|3.961|and they will so you can just tell them
328.199|3.601|you can you can make it look like you're
329.94|3.24|trying to um
331.8|2.82|solve some kind of a mathematical
333.18|2.7|problem and they will continue what they
334.62|2.94|think is the solution based on what
335.88|3.24|they've seen on the internet and very
337.56|3.84|often those Solutions look very
339.12|3.72|remarkably consistent look correct
341.4|3.72|potentially
342.84|4.32|do you still think about the brain side
345.12|3.48|of it so as neural Nets is an
347.16|5.16|abstraction or mathematical abstraction
348.6|7.56|of the brain you still draw wisdom
352.32|5.939|from from the biological neural networks
356.16|3.96|or even the bigger question so you're a
358.259|3.901|big fan of biology and biological
360.12|4.68|computation
362.16|5.58|what impressive thing is biology do
364.8|5.82|doing to you that computers are not yet
367.74|4.56|that Gap I would say I'm definitely on
370.62|3.419|I'm much more hesitant with the
372.3|3.42|analogies to the brain than I think you
374.039|4.321|would see potentially in the field
375.72|5.039|um and I kind of feel like
378.36|4.74|certainly the way neural network started
380.759|4.321|is everything stemmed from inspiration
383.1|3.42|by the brain but at the end of the day
385.08|3.839|the artifacts that you get after
386.52|3.78|training they are arrived at by a very
388.919|3.0|different optimization process than the
390.3|4.619|optimization process that gave rise to
391.919|4.861|the brain and so I think uh
394.919|3.84|I kind of think of it as a very
396.78|3.479|complicated alien artifact
398.759|2.821|um it's something different I'm not
400.259|3.901|sorry the uh the neuralness that we're
401.58|4.86|training okay they are complicated uh
404.16|3.72|Alien artifact uh I do not make
406.44|3.18|analogies to the brain because I think
407.88|3.36|the optimization process that gave rise
409.62|4.079|to it is very different from the brain
411.24|6.36|so there was no multi-agent self-play
413.699|6.0|kind of uh setup uh and evolution it was
417.6|4.86|an optimization that is basically a what
419.699|4.44|amounts to a compression objective on a
422.46|3.42|massive amount of data okay so
424.139|2.941|artificial neural networks are doing
425.88|4.379|compression
427.08|5.04|and biological neural networks
430.259|3.541|are not to survive and they're not
432.12|4.68|really doing any they're they're an
433.8|5.16|agent in a multi-agent self-place system
436.8|4.799|that's been running for a very very long
438.96|5.88|time that said Evolution has found that
441.599|5.461|it is very useful to to predict and have
444.84|4.079|a predictive model in the brain and so I
447.06|4.68|think our brain utilizes something that
448.919|4.441|looks like that as a part of it but it
451.74|4.38|has a lot more you know gadgets and
453.36|4.86|gizmos and uh value functions and
456.12|3.78|ancient nuclei that are all trying to
458.22|3.539|like make a survive and reproduce and
459.9|4.019|everything else and the whole thing
461.759|4.861|through embryogenesis is built from a
463.919|5.461|single cell I mean it's just the code is
466.62|5.84|inside the DNA and it just builds it up
469.38|3.08|like the entire organism
474.02|5.679|yes and like it does it pretty well
477.539|3.72|it should not be possible so there's
479.699|3.0|some learning going on there's some
481.259|2.821|there's some there's some kind of
482.699|5.22|computation going through that building
484.08|5.88|process I mean I I don't know where
487.919|3.84|if you were just to look at the entirety
489.96|3.9|of history of life on Earth
491.759|4.321|where do you think is the most
493.86|3.66|interesting invention is it the origin
496.08|5.179|of life itself
497.52|6.179|is it just jumping to eukaryotes is it
501.259|5.981|mammals is it humans themselves Homo
503.699|7.22|sapiens the the origin of intelligence
507.24|6.299|or highly complex intelligence
510.919|4.841|or or is it all just in continuation the
513.539|4.021|same kind of process
515.76|4.079|certainly I would say it's an extremely
517.56|4.32|remarkable story that I'm only like
519.839|3.0|briefly learning about recently all the
521.88|2.94|way from
522.839|3.901|um actually like you almost have to
524.82|3.3|start at the formation of Earth and all
526.74|2.64|of its conditions and the entire solar
528.12|3.719|system and how everything is arranged
529.38|4.86|with Jupiter and Moon and the habitable
531.839|3.601|zone and everything and then you have an
534.24|3.18|active Earth
535.44|4.519|that's turning over material
537.42|4.859|and um and then you start with a
539.959|4.241|biogenesis and everything and so it's
542.279|3.18|all like a pretty remarkable story I'm
544.2|4.5|not sure that
545.459|5.641|I can pick like a single Unique Piece of
548.7|3.42|it that I find most interesting
551.1|2.58|um
552.12|2.7|I guess for me as an artificial
553.68|2.76|intelligence researcher it's probably
554.82|4.74|the last piece we have lots of animals
556.44|6.72|that uh you know are are not building
559.56|5.1|technological Society but we do and um
563.16|3.08|it seems to have happened very quickly
564.66|3.48|it seems to have happened very recently
566.24|3.099|and uh
568.14|3.18|something very interesting happened
569.339|3.421|there that I don't fully understand I
571.32|3.78|almost understand everything else kind
572.76|4.32|of I think intuitively uh but I don't
575.1|4.62|understand exactly that part and how
577.08|4.62|quick it was both explanations would be
579.72|3.48|interesting one is that this is just a
581.7|3.12|continuation of the same kind of process
583.2|4.5|there's nothing special about humans
584.82|4.92|that would be deeply understanding that
587.7|4.199|would be very interesting that we think
589.74|5.34|of ourselves as special but it was
591.899|6.56|obvious all it was already written in
595.08|5.34|the in the code that you would have
598.459|5.201|greater and greater intelligence
600.42|4.68|emerging and then the other explanation
603.66|3.859|which is something truly special
605.1|5.34|happened something like a rare event
607.519|5.621|whether it's like crazy rare event like
610.44|5.459|uh Space Odyssey what would it be see if
613.14|4.319|you say like the invention of Fire
615.899|5.94|or
617.459|7.021|the uh as Richard rangham says the beta
621.839|5.401|males deciding a clever way to kill the
624.48|5.039|alpha males by collaborating so just
627.24|4.2|optimizing the collaborations really the
629.519|4.801|multi-agent aspect of the multi-agent
631.44|5.28|and that really being constrained on
634.32|4.74|resources and trying to survive
636.72|4.739|the collaboration aspect is what created
639.06|4.2|the complex intelligence but it seems
641.459|3.601|like it's a natural outgrowth of the
643.26|4.079|evolution process like what could
645.06|4.74|possibly be a magical thing that
647.339|4.861|happened like a rare thing that would
649.8|4.08|say that humans are actually human level
652.2|4.44|intelligence is actually a really rare
653.88|4.5|thing in the universe
656.64|4.199|yeah I'm hesitant to say that it is rare
658.38|3.6|by the way but it definitely seems like
660.839|3.661|it's kind of like a punctuated
661.98|3.78|equilibrium where you have lots of
664.5|3.899|exploration and then you have certain
665.76|4.62|leaps sparse leaps in between so of
668.399|5.461|course like origin of life would be one
670.38|5.459|um you know DNA sex eukaryotic system
673.86|3.9|eukaryotic life
675.839|4.44|um the endosymbiosis event or the
677.76|3.48|archaeon 8 little bacteria you know just
680.279|3.541|the whole thing and then of course
681.24|3.839|emergence of Consciousness and so on so
683.82|2.82|it seems like definitely there are
685.079|3.061|sparse events where mass amount of
686.64|3.66|progress was made but yeah it's kind of
688.14|5.58|hard to pick one so you don't think
690.3|5.279|humans are unique gotta ask you how many
693.72|4.98|intelligent aliens civilizations do you
695.579|4.981|think are out there and uh is there
698.7|5.28|intelligence
700.56|6.779|different or similar to ours
703.98|4.799|yeah I've been preoccupied with this
707.339|3.301|question quite a bit recently uh
708.779|3.541|basically the for me Paradox and just
710.64|4.379|thinking through and and the reason
712.32|3.959|actually that I am very interested in uh
715.019|3.121|the origin of life is fundamentally
716.279|3.18|trying to understand how common it is
718.14|3.72|that there are technological societies
719.459|5.161|out there uh
721.86|5.46|um in space and the more I study it the
724.62|4.68|more I think that um
727.32|3.54|uh there should be quite a few quite a
729.3|3.5|lot why haven't we heard from them
730.86|4.919|because I I agree with you it feels like
732.8|6.4|I just don't see
735.779|5.101|why what we did here on Earth is so
739.2|3.18|difficult to do yeah and especially when
740.88|3.78|you get into the details of it I used to
742.38|3.18|think origin of life was very
744.66|2.94|um
745.56|4.56|it was this magical rare event but then
747.6|5.58|you read books like for example McLean
750.12|5.52|um uh the vital question a life
753.18|4.32|ascending Etc and he really gets in and
755.64|4.62|he really makes you believe that this is
757.5|3.779|not that rare basic chemistry you have
760.26|2.579|an active Earth and you have your
761.279|3.661|alkaline Vents and you have lots of
762.839|3.781|alkaline Waters mixing whether it's a
764.94|3.36|devotion and you have your proton
766.62|3.6|gradients and you have the little porous
768.3|4.92|pockets of these alkaline vents that
770.22|4.44|concentrate chemistry and um basically
773.22|2.88|as he steps through all of these little
774.66|4.44|pieces you start to understand that
776.1|5.28|actually this is not that crazy you
779.1|5.16|could see this happen on other systems
781.38|5.579|um and he really takes you from just a
784.26|4.259|geology to primitive life and he makes
786.959|3.721|it feel like it's actually pretty
788.519|3.0|plausible and also like the origin of
790.68|3.899|life
791.519|4.921|um didn't uh was actually fairly fast
794.579|3.601|after formation of Earth
796.44|2.82|um if I remember correctly just a few
798.18|2.399|hundred million years or something like
799.26|3.66|that after basically when it was
800.579|3.781|possible life actually arose and so that
802.92|3.06|makes me feel like that is not the
804.36|2.76|constraint that is not the limiting
805.98|3.419|variable and that life should actually
807.12|4.08|be fairly common
809.399|4.201|um and then it you know where the
811.2|4.56|drop-offs are is very
813.6|3.6|um is very interesting to think about I
815.76|3.24|currently think that there's no major
817.2|3.84|drop-offs basically and so there should
819.0|4.079|be quite a lot of life and basically
821.04|3.599|what it where that brings me to then is
823.079|3.361|the only way to reconcile the fact that
824.639|4.741|we haven't found anyone and so on is
826.44|5.16|that um we just can't we can't see them
829.38|3.66|we can't observe them just a quick brief
831.6|4.02|comment Nick Lane and a lot of
833.04|5.46|biologists I talked to they really seem
835.62|4.86|to think that the jump from bacteria to
838.5|5.04|more complex organisms is the hardest
840.48|6.24|jump the eukaryotic glyphosis yeah which
843.54|5.88|I don't I get it they're much more
846.72|5.1|knowledgeable uh than me about like the
849.42|5.28|intricacies of biology but that seems
851.82|5.519|like crazy because how much how many
854.7|5.819|single cell organisms are there like and
857.339|5.281|how much time you have surely it's not
860.519|3.901|that difficult like in a billion years
862.62|5.04|it's not even that long
864.42|5.76|of a time really just all these bacteria
867.66|3.78|under constrained resources battling it
870.18|3.24|out I'm sure they can invent more
871.44|3.959|complex again I don't understand it's
873.42|4.859|like how to move from a hello world
875.399|5.601|program to like like invent a function
878.279|5.221|or something like that I don't yeah I I
881.0|4.959|so I don't yeah so I'm with you I just
883.5|4.38|feel like I don't see any if the origin
885.959|3.541|of life that would be my intuition
887.88|2.819|that's the hardest thing but if that's
889.5|3.12|not the hardest thing because it happens
890.699|3.841|so quickly then it's got to be
892.62|3.54|everywhere and yeah maybe we're just too
894.54|3.239|dumb to see it well it's just we don't
896.16|3.96|have really good mechanisms for seeing
897.779|4.56|this life I mean uh by what
900.12|5.82|how um so I'm not an expert just to
902.339|6.0|preface this but just said it was I want
905.94|3.54|to meet an expert on alien intelligence
908.339|2.881|and how to communicate I'm very
909.48|3.299|suspicious of our ability to to find
911.22|3.6|these intelligences out there and to
912.779|4.081|find these Earths like radio waves for
914.82|3.9|example are are terrible uh their power
916.86|4.5|drops off as basically one over R square
918.72|5.16|uh so I remember reading that our
921.36|4.32|current radio waves would not be uh the
923.88|4.199|ones that we we are broadcasting would
925.68|4.62|not be uh measurable by our devices
928.079|3.481|today only like was it like one tenth of
930.3|4.02|a light year away like not even
931.56|4.26|basically tiny distance because you
934.32|4.5|really need like a targeted transmission
935.82|5.22|of massive power directed somewhere for
938.82|4.079|this to be picked up on long distances
941.04|4.32|and so I just think that our ability to
942.899|3.781|measure is um is not amazing I think
945.36|2.88|there's probably other civilizations out
946.68|3.06|there and then the big question is why
948.24|3.12|don't they build binomial probes and why
949.74|3.659|don't they Interstellar travel across
951.36|3.9|the entire galaxy and my current answer
953.399|3.661|is it's probably Interstellar travel is
955.26|3.06|like really hard uh you have the
957.06|2.88|interstellar medium if you want to move
958.32|3.0|at closer speed of light you're going to
959.94|4.68|be encountering bullets along the way
961.32|4.92|because even like tiny hydrogen atoms
964.62|3.54|and little particles of dust are
966.24|3.779|basically have like massive kinetic
968.16|3.66|energy at those speeds and so basically
970.019|3.961|you need some kind of shielding you need
971.82|3.42|you have all the cosmic radiation uh
973.98|3.419|it's just like brutal out there it's
975.24|3.659|really hard and so my thinking is maybe
977.399|3.38|Interstellar travel is just extremely
978.899|4.641|hard
980.779|6.161|to build hard
983.54|5.2|it feels like uh it feels like we're not
986.94|3.72|a billion years away from doing that it
988.74|3.899|just might be that it's very you have to
990.66|3.479|go very slowly potentially as an example
992.639|3.721|through space
994.139|3.601|um right as opposed to close the speed
996.36|2.76|of light so I'm suspicious basically of
997.74|4.08|our ability to measure life and I'm
999.12|4.32|suspicious of the ability to um just
1001.82|3.54|permeate all of space in the Galaxy or
1003.44|3.6|across galaxies and that's the only way
1005.36|3.599|that I can certainly I can currently see
1007.04|4.14|a way around it yeah it's kind of
1008.959|4.38|mind-blowing to think that there's
1011.18|4.74|trillions of intelligent alien
1013.339|4.62|civilizations out there kind of slowly
1015.92|4.02|traveling through space
1017.959|4.021|to meet each other and some of them meet
1019.94|5.58|some of them go to war some of them
1021.98|5.52|collaborate or they're all just uh
1025.52|3.779|independent they are all just like
1027.5|4.319|little pockets I don't know well
1029.299|4.561|statistically if there's like
1031.819|3.781|if it's there's trillions of them surely
1033.86|3.0|some of them some of the pockets are
1035.6|3.479|close enough to get some of them happen
1036.86|3.839|to be close yeah in the close enough to
1039.079|4.281|see each other and then once you see
1040.699|6.12|once you see something that is
1043.36|5.74|definitely complex life like if we see
1046.819|4.921|something yeah we're probably going to
1049.1|4.14|be severe like intensely aggressively
1051.74|3.96|motivated to figure out what the hell
1053.24|5.76|that is and try to meet them what would
1055.7|7.56|be your first instinct to try to like at
1059.0|7.38|a generational level meet them or defend
1063.26|6.0|against them or what would be your uh
1066.38|4.26|Instinct as a president of the United
1069.26|3.299|States
1070.64|3.779|and the scientists
1072.559|2.821|I don't know which hat you prefer in
1074.419|3.12|this question
1075.38|3.659|yeah I think the the question it's
1077.539|2.161|really hard
1079.039|3.301|um
1079.7|4.44|I will say like for example for us
1082.34|2.88|um we have lots of primitive life forms
1084.14|2.88|on Earth
1085.22|3.36|um next to us we have all kinds of ants
1087.02|4.2|and everything else and we share space
1088.58|4.74|with them and we are hesitant to impact
1091.22|4.38|on them and to we are and we're trying
1093.32|3.66|to protect them by default because they
1095.6|3.06|are amazing interesting dynamical
1096.98|3.96|systems that took a long time to evolve
1098.66|4.92|and they are interesting and special and
1100.94|7.2|I don't know that you want to
1103.58|6.719|um destroy that by default and so I like
1108.14|5.399|complex dynamical systems that took a
1110.299|5.701|lot of time to evolve I think
1113.539|4.201|I'd like to I like to preserve it if I
1116.0|3.299|can afford to and I'd like to think that
1117.74|4.02|the same would be true about uh the
1119.299|3.361|galactic resources and that uh they
1121.76|2.88|would think that we're kind of
1122.66|4.139|incredible interesting story that took
1124.64|3.779|time it took a few billion years to
1126.799|3.541|unravel and you don't want to just
1128.419|3.961|destroy it I could see two aliens
1130.34|4.26|talking about Earth right now and saying
1132.38|5.64|uh I'm I'm a big fan of complex
1134.6|5.28|dynamical systems so I think it was a
1138.02|3.84|value to preserve these and who
1139.88|4.14|basically are a video game they watch or
1141.86|4.08|show a TV show that they watch
1144.02|3.48|yeah I think uh you would need like a
1145.94|3.479|very good reason I think to
1147.5|3.299|to destroy it uh like why don't we
1149.419|2.461|destroy these ant farms and so on it's
1150.799|2.941|because we're not actually like really
1151.88|4.2|in direct competition with them right
1153.74|3.54|now uh we do it accidentally and so on
1156.08|1.8|but
1157.28|2.88|um
1157.88|3.48|there's plenty of resources and so why
1160.16|2.94|would you destroy something that is so
1161.36|3.72|interesting and precious well from a
1163.1|4.079|scientific perspective you might probe
1165.08|3.66|it yeah you might interact with it later
1167.179|4.081|you might want to learn something from
1168.74|4.38|it right so I wonder there's could be
1171.26|3.36|certain physical phenomena that we think
1173.12|3.36|is a physical phenomena but it's
1174.62|4.02|actually interacting with us to like
1176.48|3.24|poke the finger and see what happens I
1178.64|2.7|think it should be very interesting to
1179.72|2.64|scientists other alien scientists what
1181.34|3.36|happened here
1182.36|4.08|um and you know it's a what we're seeing
1184.7|4.74|today is a snapshot basically it's a
1186.44|5.28|result of a huge amount of computation
1189.44|3.84|uh of over like billion years or
1191.72|4.079|something like that so it could have
1193.28|4.62|been initiated by aliens this could be a
1195.799|4.021|computer running a program like when
1197.9|4.86|okay if you had the power to do this
1199.82|6.66|when you okay for sure at least I would
1202.76|4.86|I would pick uh a Earth-like planet that
1206.48|2.22|has the conditions based my
1207.62|2.82|understanding of the chemistry
1208.7|4.32|prerequisites for life
1210.44|5.94|and I would see it with life and run it
1213.02|6.0|right like yeah wouldn't you 100 do that
1216.38|4.799|and observe it and then protect
1219.02|4.2|I mean that that's not just a hell of a
1221.179|4.74|good TV show it's it's a good scientific
1223.22|5.28|experiment yeah and
1225.919|7.081|that in his it's physical simulation
1228.5|6.84|right maybe maybe the evolution is the
1233.0|5.22|most like actually running it
1235.34|5.64|uh is the most efficient way to uh
1238.22|4.98|understand computation or to compute
1240.98|4.02|stuff or to understand life or you know
1243.2|3.78|what life looks like and uh what
1245.0|3.48|branches it can take it does make me
1246.98|3.559|kind of feel weird that we're part of a
1248.48|4.38|science experiment but maybe it's
1250.539|4.901|everything's a science experiments how
1252.86|3.96|to does that change anything for us for
1255.44|4.2|a science experiment
1256.82|4.68|um I don't know two descendants of Apes
1259.64|3.48|talking about being inside of a science
1261.5|3.84|experience I'm suspicious of this idea
1263.12|4.14|of like a deliberate Pence Premiere as
1265.34|4.079|you described it service and I don't see
1267.26|4.26|a divine intervention in some way in the
1269.419|3.301|in the historical record right now I do
1271.52|3.539|feel like
1272.72|3.78|um the story in these in these books
1275.059|3.24|like Nick Lane's books and so on sort of
1276.5|5.28|makes sense uh and it makes sense how
1278.299|5.101|life arose on Earth uniquely and uh yeah
1281.78|3.3|I don't need a I need I don't need to
1283.4|4.139|reach for more exotic explanations right
1285.08|3.479|now sure but NPCs inside a video game
1287.539|3.421|don't
1288.559|4.86|don't don't observe any divine
1290.96|4.8|intervention either and we might just be
1293.419|4.021|all NPCs running a kind of code maybe
1295.76|2.82|eventually they will currently NPCs are
1297.44|3.84|really dumb but once they're running
1298.58|5.28|gpts um maybe they will be like hey this
1301.28|5.759|is really suspicious what the hell so
1303.86|5.22|you uh famously tweeted it looks like if
1307.039|4.561|you bombard Earth with photons for a
1309.08|5.28|while you can emit A roadster
1311.6|5.1|so if like an Hitchhiker's Guide to the
1314.36|4.38|Galaxy we would summarize the story of
1316.7|3.06|Earth so in in that book it's mostly
1318.74|3.36|harmless
1319.76|4.68|uh what do you think is all the possible
1322.1|3.54|stories like a paragraph long or a
1324.44|4.619|sentence long
1325.64|6.419|that Earth could be summarized as once
1329.059|5.161|it's done it's computation so like all
1332.059|5.701|the Possible full
1334.22|5.819|if Earth is a book right yeah uh
1337.76|3.659|probably there has to be an ending I
1340.039|3.301|mean there's going to be an end to Earth
1341.419|4.201|and it could end in all kinds of ways it
1343.34|4.319|could end soon it can end later what do
1345.62|4.08|you think are the possible stories well
1347.659|4.14|definitely there seems to be
1349.7|3.54|yeah you're sort of
1351.799|3.781|it's pretty incredible that these
1353.24|4.679|self-replicating systems will basically
1355.58|3.599|arise from the Dynamics and then they
1357.919|3.0|perpetuate themselves and become more
1359.179|4.141|complex and eventually become conscious
1360.919|4.861|and build a society and I kind of feel
1363.32|5.58|like in some sense it's kind of like a
1365.78|5.04|deterministic wave uh that you know that
1368.9|3.54|kind of just like happens on any you
1370.82|3.0|know any sufficiently well arranged
1372.44|2.7|system like Earth
1373.82|4.2|and so I kind of feel like there's a
1375.14|5.46|certain sense of inevitability in it
1378.02|4.62|um and it's really beautiful and it ends
1380.6|4.559|somehow right so it's a it's a
1382.64|5.039|chemically
1385.159|6.14|a diverse environment
1387.679|6.901|where complex dynamical systems can
1391.299|5.5|evolve and become more more further and
1394.58|3.959|further complex but then there's a
1396.799|2.641|certain
1398.539|3.12|um
1399.44|4.92|what is it there's certain terminating
1401.659|3.661|conditions yeah I don't know what the
1404.36|2.46|terminating conditions are but
1405.32|2.64|definitely there's a trend line of
1406.82|3.18|something and we're part of that story
1407.96|4.26|and like where does that where does it
1410.0|4.74|go so you know we're famously described
1412.22|4.02|often as a biological Bootloader for AIS
1414.74|2.88|and that's because humans I mean you
1416.24|3.299|know we're an incredible
1417.62|5.16|uh biological system and we're capable
1419.539|4.801|of computation and uh you know and love
1422.78|3.3|and so on
1424.34|2.88|um but we're extremely inefficient as
1426.08|2.579|well like we're talking to each other
1427.22|3.0|through audio it's just kind of
1428.659|3.9|embarrassing honestly they were
1430.22|5.16|manipulating like seven symbols uh
1432.559|4.261|serially we're using vocal chords it's
1435.38|3.48|all happening over like multiple seconds
1436.82|3.839|yeah it's just like kind of embarrassing
1438.86|4.14|when you step down to the
1440.659|4.801|uh frequencies at which computers
1443.0|4.74|operate or are able to cooperate on and
1445.46|4.8|so basically it does seem like
1447.74|5.58|um synthetic intelligences are kind of
1450.26|4.74|like the next stage of development and
1453.32|4.979|um I don't know where it leads to like
1455.0|5.4|at some point I suspect uh the universe
1458.299|5.101|is some kind of a puzzle
1460.4|6.24|and these synthetic AIS will uncover
1463.4|5.519|that puzzle and um solve it
1466.64|4.08|and then what happens after right like
1468.919|3.841|what because if you just like Fast
1470.72|4.86|Forward Earth many billions of years
1472.76|4.74|it's like uh it's quiet and then it's
1475.58|3.54|like to tourmal you see like city lights
1477.5|3.36|and stuff like that and then what
1479.12|2.76|happens like at the end like is it like
1480.86|3.66|a
1481.88|4.799|is it or is it like a calming is it
1484.52|5.22|explosion is it like Earth like open
1486.679|4.86|like a giant because you said emit
1489.74|5.819|Roasters like well let's start emitting
1491.539|6.301|like like a giant number of Like
1495.559|4.261|Satellites yes it's some kind of a crazy
1497.84|4.5|explosion and we're living we're like
1499.82|3.78|we're stepping through a explosion and
1502.34|2.28|we're like living day to day and it
1503.6|3.24|doesn't look like it but it's actually
1504.62|4.2|if you I saw a very cool animation of
1506.84|3.6|Earth uh and life on Earth and basically
1508.82|3.359|nothing happens for a long time and then
1510.44|4.26|the last like two seconds like basically
1512.179|3.901|cities and everything and just in the
1514.7|2.459|low earth orbit just gets cluttered and
1516.08|2.579|just the whole thing happens in the last
1517.159|3.481|two seconds and you're like this is
1518.659|4.02|exploding this is a statement explosion
1520.64|4.38|so if you play
1522.679|4.921|yeah yeah if you play it at normal speed
1525.02|4.5|yeah it'll just look like an explosion
1527.6|4.079|it's a firecracker we're living in a
1529.52|3.72|firecracker where it's going to start
1531.679|4.86|emitting all kinds of interesting things
1533.24|4.38|yeah and then so explosion doesn't it
1536.539|3.901|might actually look like a little
1537.62|4.38|explosion with with lights and fire and
1540.44|4.38|energy emitted all that kind of stuff
1542.0|4.64|but when you look inside the details of
1544.82|5.58|the explosion there's actual complexity
1546.64|5.8|happening where there's like uh yeah
1550.4|3.6|human life or some kind of life we hope
1552.44|4.16|it's not destructive firecracker it's
1554.0|5.76|kind of like a constructive uh
1556.6|5.02|firecracker all right so given that I
1559.76|2.82|think uh hilarious disgusting it is a
1561.62|2.58|really interesting to think about like
1562.58|3.599|what the puzzle of the universe is that
1564.2|3.359|the creator of the universe uh give us a
1566.179|2.161|message like for example in the book
1567.559|3.061|contact
1568.34|5.64|UM Carl Sagan uh there's a message for
1570.62|6.12|Humanity for any civilization in uh
1573.98|4.679|digits in the expansion of Pi and base
1576.74|4.5|11 eventually which is kind of
1578.659|3.721|interesting thought uh maybe maybe we're
1581.24|3.24|supposed to be giving a message to our
1582.38|4.02|creator maybe we're supposed to somehow
1584.48|4.319|create some kind of a quantum mechanical
1586.4|4.139|system that alerts them to our
1588.799|2.76|intelligent presence here because if you
1590.539|3.12|think about it from their perspective
1591.559|4.201|it's just say like Quantum field Theory
1593.659|4.14|massive like cellular automaton like
1595.76|4.2|thing and like how do you even notice
1597.799|4.74|that we exist you might not even be able
1599.96|4.199|to pick us up in that simulation and so
1602.539|3.361|how do you uh how do you prove that you
1604.159|3.9|exist that you're intelligent and that
1605.9|3.48|you're a part of the universe so this is
1608.059|4.561|like a touring test for intelligence
1609.38|5.279|from Earth yeah the Creator is uh I mean
1612.62|3.72|maybe this is uh like trying to complete
1614.659|3.481|the next word in a sentence this is a
1616.34|4.38|complicated way of that like Earth is
1618.14|4.2|just is basically sending a message back
1620.72|4.14|yeah the puzzle is basically like
1622.34|4.14|alerting the Creator that we exist or
1624.86|3.48|maybe the puzzle is just to just break
1626.48|4.079|out of the system and just uh you know
1628.34|3.719|stick it to the Creator in some way uh
1630.559|3.36|basically like if you're playing a video
1632.059|4.081|game you can um
1633.919|4.681|you can somehow find an exploit and find
1636.14|4.98|a way to execute on the host machine in
1638.6|4.559|the arbitrary code there's some for
1641.12|4.32|example I believe someone got Mario a
1643.159|4.321|game of Mario to play Pong just by uh
1645.44|4.92|exploiting it and then
1647.48|4.74|um creating a basically writing writing
1650.36|4.02|code and being able to execute arbitrary
1652.22|3.959|code in the game and so maybe we should
1654.38|3.419|be maybe that's the puzzle is that we
1656.179|3.901|should be um
1657.799|3.601|uh find a way to exploit it so so I
1660.08|2.76|think like some of these synthetic ads
1661.4|3.06|will eventually find the universe to be
1662.84|3.3|some kind of a puzzle and then solve it
1664.46|3.9|in some way and that's kind of like the
1666.14|7.8|end game somehow do you often think
1668.36|7.08|about it as a as a simulation so as the
1673.94|4.02|universe being a kind of computation
1675.44|4.8|that has might have bugs and exploits
1677.96|4.079|yes yeah I think so is that what physics
1680.24|3.36|is essentially I think it's possible
1682.039|3.541|that physics has exploits and we should
1683.6|3.3|be trying to find them arranging some
1685.58|3.24|kind of a crazy quantum mechanical
1686.9|3.84|system that somehow gives you buffer
1688.82|3.859|overflow somehow gives you a rounding
1690.74|6.36|error and a floating Point
1692.679|6.941|uh yeah that's right and like more and
1697.1|3.9|more sophisticated exploits like those
1699.62|2.88|are jokes but that could be actually
1701.0|3.6|very close yeah we'll find some way to
1702.5|3.419|extract infinite energy for example when
1704.6|3.48|you train a reinforcement learning
1705.919|4.561|agents um and physical simulations and
1708.08|4.199|you ask them to say run quickly on the
1710.48|3.24|flat ground they'll end up doing all
1712.279|3.0|kinds of like weird things
1713.72|3.24|um in part of that optimization right
1715.279|3.841|they'll get on their back leg and they
1716.96|4.199|will slide across the floor and it's
1719.12|3.24|because of the optimization the
1721.159|2.52|enforcement learning optimization on
1722.36|2.46|that agent has figured out a way to
1723.679|4.021|extract infinite energy from the
1724.82|4.859|friction forces and basically their poor
1727.7|3.359|implementation and they found a way to
1729.679|2.761|generate infinite energy and just slide
1731.059|3.901|across the surface and it's not what you
1732.44|4.859|expected it's just a it's sort of like a
1734.96|3.78|perverse solution and so maybe we can
1737.299|2.76|find something like that maybe we can be
1738.74|4.88|that little
1740.059|6.301|dog in this physical simulation the the
1743.62|4.659|cracks or escapes the intended
1746.36|3.84|consequences of the physics that the
1748.279|3.481|Universe came up with we'll figure out
1750.2|3.599|some kind of shortcut to some weirdness
1751.76|4.32|yeah and then oh man but see the problem
1753.799|4.681|with that weirdness is the first person
1756.08|3.78|to discover the weirdness like sliding
1758.48|5.16|in the back legs
1759.86|6.0|that's all we're going to do yeah it's
1763.64|5.399|very quickly because everybody does that
1765.86|5.939|thing so like the the paper clip
1769.039|5.041|maximizer is a ridiculous idea but that
1771.799|5.221|very well you know could be what then
1774.08|4.74|we'll just uh we'll just all switch that
1777.02|3.24|because it's so fun well no person will
1778.82|3.78|Discover it I think by the way I think
1780.26|4.74|it's going to have to be uh some kind of
1782.6|3.84|a super intelligent AGI of a third
1785.0|2.88|generation
1786.44|3.9|like we're building the first generation
1787.88|5.46|AGI you know
1790.34|6.36|third generation yeah so the the
1793.34|6.6|Bootloader for an AI the that AI yeah
1796.7|5.339|will be a Bootloader for another AI yeah
1799.94|4.2|and then there's no way for us to
1802.039|3.181|introspect like what that might even uh
1804.14|2.399|I think it's very likely that these
1805.22|3.36|things for example like say you have
1806.539|4.26|these agis it's very like for example
1808.58|3.599|they will be completely inert I like
1810.799|3.0|these kinds of sci-fi books sometimes
1812.179|2.88|where these things are just completely
1813.799|2.641|inert they don't interact with anything
1815.059|4.201|and I find that kind of beautiful
1816.44|4.44|because uh they probably they've
1819.26|2.82|probably figured out the meta game of
1820.88|2.58|the universe in some way potentially
1822.08|3.42|they're they're doing something
1823.46|4.14|completely beyond our imagination
1825.5|5.1|um and uh they don't interact with
1827.6|5.1|simple chemical life forms like why
1830.6|3.78|would you do that so I find those kinds
1832.7|3.24|of ideas compelling what's their source
1834.38|3.6|of fun what are they what are they doing
1835.94|3.06|what's the source of solving in the
1837.98|4.62|universe
1839.0|6.74|but inert so can you define what it
1842.6|6.559|means inert so they escape
1845.74|3.419|as in um
1850.46|3.839|they will behave in some very like
1852.14|4.32|strange way to us because they're uh
1854.299|3.781|they're beyond they're playing The Meta
1856.46|3.06|game uh and The Meta game is probably
1858.08|3.24|say like arranging quantum mechanical
1859.52|4.32|systems in some very weird ways to
1861.32|4.079|extract Infinite Energy uh solve the
1863.84|4.38|digital expansion of Pi to whatever
1865.399|4.561|amount uh they will build their own like
1868.22|3.059|little Fusion reactors or something
1869.96|3.24|crazy like they're doing something
1871.279|3.841|Beyond Comprehension and uh not
1873.2|4.8|understandable to us and actually
1875.12|5.52|brilliant under the hood what if quantum
1878.0|5.82|mechanics itself is the system and we're
1880.64|6.6|just thinking it's physics
1883.82|4.68|but we're really parasites on on or not
1887.24|3.36|parasite we're not really hurting
1888.5|4.799|physics we're just living on this
1890.6|5.04|organisms this organism and we're like
1893.299|4.321|trying to understand it but really it is
1895.64|6.019|an organism and with a deep deep
1897.62|8.22|intelligence maybe physics itself is
1901.659|5.801|uh the the organism that's doing a super
1905.84|5.1|interesting thing and we're just like
1907.46|5.28|one little thing yeah ant sitting on top
1910.94|3.54|of it trying to get energy from it we're
1912.74|3.12|just kind of like these particles in a
1914.48|3.54|wave that I feel like is mostly
1915.86|4.319|deterministic and takes uh Universe from
1918.02|4.68|some kind of a big bang to some kind of
1920.179|5.161|a super intelligent replicator some kind
1922.7|5.339|of a stable point in the universe given
1925.34|5.04|these laws of physics you don't think uh
1928.039|4.62|as Einstein said God doesn't play dice
1930.38|3.659|so you think it's mostly deterministic
1932.659|2.821|there's no Randomness in the thing I
1934.039|3.661|think it's deterministic oh there's tons
1935.48|4.5|of uh well I'm I want to be careful with
1937.7|4.44|Randomness pseudo random yeah I don't
1939.98|3.9|like random uh I think maybe the laws of
1942.14|3.539|physics are deterministic
1943.88|3.419|um yeah I think they're determinants
1945.679|3.021|just got really uncomfortable with this
1947.299|3.781|question
1948.7|5.099|do you have anxiety about whether the
1951.08|6.0|universe is random or not
1953.799|4.781|what's there's no Randomness uh you say
1957.08|4.199|you like Goodwill Hunting it's not your
1958.58|3.959|fault Andre it's not it's not your fault
1961.279|4.321|man
1962.539|5.161|um so you don't like Randomness uh yeah
1965.6|3.78|I think it's uh unsettling I think it's
1967.7|4.02|a deterministic system I think that
1969.38|4.26|things that look random like say the uh
1971.72|3.059|collapse of the wave function Etc I
1973.64|3.84|think they're actually deterministic
1974.779|3.961|just entanglement uh and so on and uh
1977.48|3.36|some kind of a Multiverse Theory
1978.74|5.159|something something okay so why does it
1980.84|6.36|feel like we have a free will like if I
1983.899|5.66|raise the hand I chose to do this now
1987.2|4.8|um what
1989.559|4.781|that doesn't feel like a deterministic
1992.0|4.559|thing it feels like I'm making a choice
1994.34|5.28|it feels like it okay so it's all
1996.559|7.081|feelings it's just feelings yeah so when
1999.62|4.919|an RL agent is making a choice is that
2003.64|2.519|um
2004.539|3.421|it's not really making a choice the
2006.159|2.941|choices are all already there yeah
2007.96|3.059|you're interpreting the choice and
2009.1|3.84|you're creating a narrative for or
2011.019|3.241|having made it yeah and now we're
2012.94|4.32|talking about the narrative it's very
2014.26|5.1|meta looking back what is the most
2017.26|5.039|beautiful or surprising idea in deep
2019.36|4.919|learning or AI in general that you've
2022.299|3.36|come across you've seen this field
2024.279|4.62|explode
2025.659|5.941|and grow in interesting ways just what
2028.899|6.421|what cool ideas like like we made you
2031.6|4.98|sit back and go hmm small big or small
2035.32|5.16|well the one that I've been thinking
2036.58|6.12|about recently the most probably is the
2040.48|5.22|the Transformer architecture
2042.7|5.219|um so basically uh neural networks have
2045.7|4.56|a lot of architectures that were trendy
2047.919|4.5|have come and gone for different sensory
2050.26|3.48|modalities like for Vision Audio text
2052.419|3.18|you would process them with different
2053.74|3.72|looking neural nuts and recently we've
2055.599|4.441|seen these convergence towards one
2057.46|4.56|architecture the Transformer and you can
2060.04|3.66|feed it video or you can feed it you
2062.02|3.359|know images or speech or text and it
2063.7|4.8|just gobbles it up and it's kind of like
2065.379|4.8|a bit of a general purpose uh computer
2068.5|3.3|that is also trainable and very
2070.179|5.641|efficient to run on our Hardware
2071.8|4.98|and so uh this paper came out in 2016 I
2075.82|2.519|want to say
2076.78|3.66|um attention is all you need attention
2078.339|5.58|is all you need you criticize the paper
2080.44|6.84|title in retrospect that it wasn't
2083.919|4.98|um it didn't foresee the bigness of the
2087.28|2.819|impact yeah that it was going to have
2088.899|2.94|yeah I'm not sure if the authors were
2090.099|3.121|aware of the impact that that paper
2091.839|3.481|would go on to have probably they
2093.22|3.6|weren't but I think they were aware of
2095.32|3.0|some of the motivations and design
2096.82|3.539|decisions beyond the Transformer and
2098.32|4.019|they chose not to I think expand on it
2100.359|4.381|in that way in the paper and so I think
2102.339|4.741|they had an idea that there was more
2104.74|3.54|um than just the surface of just like oh
2107.08|2.46|we're just doing translation and here's
2108.28|2.7|a better architecture you're not just
2109.54|3.24|doing translation this is like a really
2110.98|3.48|cool differentiable optimizable
2112.78|3.66|efficient computer that you've proposed
2114.46|3.18|and maybe they didn't have all of that
2116.44|3.0|foresight but I think is really
2117.64|5.1|interesting isn't it funny sorry to
2119.44|6.24|interrupt that title is memeable that
2122.74|4.92|they went for such a profound idea they
2125.68|3.3|went with the I don't think anyone used
2127.66|3.06|that kind of title before right
2128.98|3.84|protection is all you need yeah it's
2130.72|6.0|like a meme or something exactly it's
2132.82|5.16|not funny that one like uh maybe if it
2136.72|3.359|was a more serious title it wouldn't
2137.98|3.96|have the impact honestly I yeah there is
2140.079|5.061|an element of me that honestly agrees
2141.94|5.46|with you and prefers it this way yes
2145.14|3.459|if it was two grand it would over
2147.4|3.36|promise and then under deliver
2148.599|3.98|potentially so you want to just uh meme
2150.76|4.319|your way to greatness
2152.579|4.661|that should be a t-shirt so you you
2155.079|4.441|tweeted the Transformers the Magnificent
2157.24|3.839|neural network architecture because it
2159.52|4.02|is a general purpose differentiable
2161.079|6.121|computer it is simultaneously expressive
2163.54|5.579|in the forward pass optimizable via back
2167.2|5.1|propagation gradient descent and
2169.119|5.281|efficient High parallelism compute graph
2172.3|4.5|can you discuss some of those details
2174.4|4.86|expressive optimizable efficient
2176.8|4.559|yeah for memory or or in general
2179.26|3.3|whatever comes to your heart you want to
2181.359|3.421|have a general purpose computer that you
2182.56|3.84|can train on arbitrary problems like say
2184.78|3.48|the task of next word prediction or
2186.4|3.179|detecting if there's a cat in the image
2188.26|3.06|or something like that
2189.579|3.661|and you want to train this computer so
2191.32|3.539|you want to set its weights and I think
2193.24|3.66|there's a number of design criteria that
2194.859|3.72|sort of overlap in the Transformer
2196.9|3.179|simultaneously that made it very
2198.579|4.561|successful and I think the authors were
2200.079|6.961|kind of uh deliberately trying to make
2203.14|7.14|this really powerful architecture and um
2207.04|4.38|so basically it's very powerful in the
2210.28|2.1|forward pass because it's able to
2211.42|4.98|express
2212.38|4.8|um very general computation as a sort of
2216.4|2.699|something that looks like message
2217.18|4.32|passing you have nodes and they all
2219.099|4.321|store vectors and these nodes get to
2221.5|3.9|basically look at each other and it's
2223.42|4.26|each other's vectors and they get to
2225.4|4.199|communicate and basically notes get to
2227.68|3.3|broadcast hey I'm looking for certain
2229.599|2.701|things and then other nodes get to
2230.98|2.76|broadcast hey these are the things I
2232.3|3.18|have those are the keys and the values
2233.74|3.0|so it's not just the tension yeah
2235.48|2.7|exactly Transformer is much more than
2236.74|3.18|just the attention component it's got
2238.18|3.179|many pieces architectural that went into
2239.92|3.3|it the residual connection of the way
2241.359|4.141|it's arranged there's a multi-layer
2243.22|3.54|perceptron in there the way it's stacked
2245.5|2.46|and so on
2246.76|2.76|um but basically there's a message
2247.96|2.94|passing scheme where nodes get to look
2249.52|4.2|at each other decide what's interesting
2250.9|4.8|and then update each other and uh so I
2253.72|3.3|think the um when you get to the details
2255.7|3.419|of it I think it's a very expressive
2257.02|3.12|function uh so it can express lots of
2259.119|2.761|different types of algorithms and
2260.14|3.18|forward paths not only that but the way
2261.88|3.0|it's designed with the residual
2263.32|3.36|connections layer normalizations the
2264.88|3.3|softmax attention and everything it's
2266.68|4.02|also optimizable this is a really big
2268.18|3.659|deal because there's lots of computers
2270.7|3.3|that are powerful that you can't
2271.839|3.481|optimize or they're not easy to optimize
2274.0|2.579|using the techniques that we have which
2275.32|2.94|is back propagation and gradient and
2276.579|4.381|send these are first order methods very
2278.26|5.28|simple optimizers really and so
2280.96|4.619|um you also need it to be optimizable
2283.54|3.559|um and then lastly you want it to run
2285.579|4.321|efficiently in the hardware our Hardware
2287.099|6.281|is a massive throughput machine like
2289.9|4.74|gpus they prefer lots of parallelism so
2293.38|2.459|you don't want to do lots of sequential
2294.64|3.06|operations you want to do a lot of
2295.839|3.121|operations serially and the Transformer
2297.7|3.54|is designed with that in mind as well
2298.96|3.84|and so it's designed for our hardware
2301.24|3.24|and it's designed to both be very
2302.8|3.18|expressive in a forward pass but also
2304.48|4.5|very optimizable in the backward pass
2305.98|4.74|and you said that uh the residual
2308.98|4.379|connections support a kind of ability to
2310.72|5.52|learn short algorithms fast them first
2313.359|4.621|and then gradually extend them longer
2316.24|3.72|during training yeah what's what's the
2317.98|3.9|idea of learning short algorithms right
2319.96|5.639|think of it as a so basically a
2321.88|5.1|Transformer is a series of uh blocks
2325.599|3.301|right and these blocks have attention
2326.98|3.84|and a little multi-layer perceptron and
2328.9|3.66|so you you go off into a block and you
2330.82|2.82|come back to this residual pathway and
2332.56|1.98|then you go off and you come back and
2333.64|3.3|then you have a number of layers
2334.54|4.26|arranged sequentially and so the way to
2336.94|3.6|look at it I think is because of the
2338.8|4.26|residual pathway in the backward path
2340.54|4.98|the gradients uh sort of flow along it
2343.06|4.38|uninterrupted because addition
2345.52|3.839|distributes the gradient equally to all
2347.44|4.08|of its branches so the gradient from the
2349.359|5.401|supervision at the top uh just floats
2351.52|5.04|directly to the first layer and the all
2354.76|2.7|the residual connections are arranged so
2356.56|2.4|that in the beginning during
2357.46|3.78|initialization they contribute nothing
2358.96|3.899|to the residual pathway
2361.24|3.119|um so what it kind of looks like is
2362.859|4.98|imagine the Transformer is kind of like
2364.359|6.361|a uh python uh function like a death
2367.839|5.101|and um you get to do various kinds of
2370.72|4.619|like lines of code say you have a
2372.94|3.78|hundred layers deep Transformer
2375.339|3.121|typically they would be much shorter say
2376.72|3.48|20. so if 20 lines of code then you can
2378.46|3.119|do something in them and so think of
2380.2|2.639|during the optimization basically what
2381.579|2.461|it looks like is first you optimize the
2382.839|2.701|first line of code and then the second
2384.04|3.78|line of code can kick in and the third
2385.54|3.72|line of code can and I kind of feel like
2387.82|3.48|because of the residual pathway and the
2389.26|3.78|Dynamics of the optimization you can
2391.3|3.299|sort of learn a very short algorithm
2393.04|3.059|that gets the approximate tensor but
2394.599|2.76|then the other layers can sort of kick
2396.099|3.0|in and start to create a contribution
2397.359|3.661|and at the end of it you're you're
2399.099|3.301|optimizing over an algorithm that is 20
2401.02|2.76|lines of code
2402.4|2.939|except these lines of code are very
2403.78|3.0|complex because it's an entire block of
2405.339|2.701|a transformer you can do a lot in there
2406.78|3.36|what's really interesting is that this
2408.04|4.079|Transformer architecture actually has
2410.14|3.719|been a remarkably resilient basically
2412.119|2.881|the Transformer that came out in 2016 is
2413.859|2.941|the Transformer you would use today
2415.0|4.079|except you reshuffle some of the layer
2416.8|5.279|norms the layer normalizations have been
2419.079|4.741|reshuffled to a pre-norm formulation and
2422.079|3.301|so it's been remarkably stable but
2423.82|3.24|there's a lot of bells and whistles that
2425.38|3.479|people have attached on and try to uh
2427.06|3.84|improve it I do think that basically
2428.859|4.141|it's a it's a big step in simultaneously
2430.9|3.36|optimizing for lots of properties of a
2433.0|2.7|desirable neural network architecture
2434.26|2.819|and I think people have been trying to
2435.7|3.899|change it but it's proven remarkably
2437.079|3.841|resilient but I do think that there
2439.599|4.921|should be even better architectures
2440.92|5.28|potentially but it's uh your you admire
2444.52|2.76|the resilience here yeah there's
2446.2|3.6|something profound about this
2447.28|5.28|architecture that that at least so maybe
2449.8|5.039|we can everything can be turned into a
2452.56|3.779|uh into a problem that Transformers can
2454.839|3.421|solve currently definitely looks like
2456.339|3.481|the Transformers taking over Ai and you
2458.26|3.0|can feed basically arbitrary problems
2459.82|2.88|into it and it's a general
2461.26|4.02|differentiable computer and it's
2462.7|4.44|extremely powerful and uh this
2465.28|3.9|convergence in AI has been really
2467.14|4.02|interesting to watch uh for me
2469.18|3.84|personally what else do you think could
2471.16|4.439|be discovered here about Transformers
2473.02|3.72|like what's surprising thing or or is it
2475.599|1.861|a stable
2476.74|2.4|um
2477.46|2.879|I went to stable place is there
2479.14|3.6|something interesting we might discover
2480.339|5.28|about Transformers like aha moments
2482.74|4.379|maybe has to do with memory uh maybe
2485.619|2.46|knowledge representation that kind of
2487.119|3.48|stuff
2488.079|4.681|definitely the Zeitgeist today is just
2490.599|3.541|pushing like basically right now this ad
2492.76|3.72|guys is do not touch the Transformer
2494.14|3.6|touch everything else yes so people are
2496.48|2.52|scaling up the data sets making them
2497.74|2.76|much much bigger they're working on the
2499.0|4.14|evaluation making the evaluation much
2500.5|4.02|much bigger and uh
2503.14|3.12|um they're basically keeping the
2504.52|3.72|architecture unchanged and that's how
2506.26|4.319|we've um that's the last five years of
2508.24|4.8|progress in AI kind of
2510.579|4.141|what do you think about one flavor of it
2513.04|3.96|which is language models
2514.72|3.72|have you been surprised
2517.0|3.599|uh
2518.44|4.5|has your sort of imagination been
2520.599|3.541|captivated by you mentioned GPT and all
2522.94|2.52|the bigger and bigger and bigger
2524.14|4.56|language models
2525.46|6.84|and uh what are the limits
2528.7|7.08|of those models do you think
2532.3|5.22|so just let the task of natural language
2535.78|3.42|basically the way GPT is trained right
2537.52|4.079|is you just download a mass amount of
2539.2|4.5|text Data from the internet and you try
2541.599|4.081|to predict the next word in a sequence
2543.7|4.379|roughly speaking you're predicting will
2545.68|4.38|work chunks but uh roughly speaking
2548.079|3.601|that's it and what's been really
2550.06|3.0|interesting to watch is
2551.68|2.76|uh basically it's a language model
2553.06|2.88|language models have actually existed
2554.44|3.3|for a very long time
2555.94|4.38|um there's papers on language modeling
2557.74|5.16|from 2003 even earlier can you explain
2560.32|4.32|that case what a language model is uh
2562.9|4.02|yeah so language model just basically
2564.64|4.56|the rough idea is um just predicting the
2566.92|4.199|next word in a sequence roughly speaking
2569.2|5.58|uh so there's a paper from for example
2571.119|5.821|bengio and the team from 2003 where for
2574.78|4.02|the first time they were using a neural
2576.94|3.6|network to take say like three or five
2578.8|3.84|words and predict the
2580.54|3.72|um next word and they're doing this on
2582.64|3.36|much smaller data sets and the neural
2584.26|3.78|net is not a Transformer it's a multiple
2586.0|3.24|error perceptron but but it's the first
2588.04|2.819|time that a neural network has been
2589.24|3.599|applied in that setting but even before
2590.859|5.101|neural networks there were language
2592.839|5.821|models except they were using engram
2595.96|5.04|models so engram models are just a count
2598.66|3.959|based models so
2601.0|4.02|um if you try to if you start to take
2602.619|4.261|two words and predict the third one you
2605.02|4.26|just count up how many times you've seen
2606.88|4.38|any two word combinations and what came
2609.28|3.36|next and what you predict that's coming
2611.26|2.76|next is just what you've seen the most
2612.64|3.36|of in the training set
2614.02|3.48|and so language modeling has been around
2616.0|2.88|for a long time neural networks have
2617.5|3.839|done language modeling for a long time
2618.88|5.52|so really what's new or interesting or
2621.339|4.381|exciting is just realizing that when you
2624.4|3.6|scale it up
2625.72|4.139|with a powerful enough neural net
2628.0|4.619|Transformer you have all these emergent
2629.859|5.46|properties where basically what happens
2632.619|4.321|is if you have a large enough data set
2635.319|4.321|of text
2636.94|5.04|you are in the task of predicting the
2639.64|4.439|next word you are multitasking a huge
2641.98|5.04|amount of different kinds of problems
2644.079|5.28|you are multitasking understanding of
2647.02|4.38|you know chemistry physics human nature
2649.359|3.24|lots of things are sort of clustered in
2651.4|2.52|that objective it's a very simple
2652.599|3.0|objective but actually you have to
2653.92|4.199|understand a lot about the world to make
2655.599|6.301|that prediction you just said the U word
2658.119|6.0|understanding uh are you in terms of
2661.9|3.84|chemistry and physics and so on what do
2664.119|3.24|you feel like it's doing is it searching
2665.74|4.14|for the right context
2667.359|5.22|uh in in like what what is it what is
2669.88|4.739|the actual process Happening Here Yeah
2672.579|3.421|so basically it gets a thousand words
2674.619|3.48|and it's trying to predict a thousand at
2676.0|3.96|first and uh in order to do that very
2678.099|3.421|very well over the entire data set
2679.96|4.32|available on the internet you actually
2681.52|5.04|have to basically kind of understand the
2684.28|3.18|context of of what's going on in there
2686.56|3.42|yeah
2687.46|5.34|um and uh it's a sufficiently hard
2689.98|4.2|problem that you uh if you have a
2692.8|2.94|powerful enough computer like a
2694.18|4.5|Transformer you end up with uh
2695.74|6.06|interesting Solutions and uh you can ask
2698.68|5.76|it uh to all do all kinds of things and
2701.8|4.38|um it it shows a lot of emerging
2704.44|3.84|properties like in context learning that
2706.18|3.72|was the big deal with GPT and the
2708.28|3.66|original paper when they published it is
2709.9|3.6|that you can just sort of uh prompt it
2711.94|2.82|in various ways and ask it to do various
2713.5|2.64|things and it will just kind of complete
2714.76|2.76|the sentence but in the process of just
2716.14|3.12|completing the sentence it's actually
2717.52|3.54|solving all kinds of really uh
2719.26|3.599|interesting problems that we care about
2721.06|3.24|do you think it's doing something like
2722.859|3.48|understanding
2724.3|5.16|like and when we use the word
2726.339|4.801|understanding for us humans
2729.46|4.02|I think it's doing some understanding it
2731.14|4.86|in its weights it understands I think a
2733.48|3.66|lot about the world and it has to in
2736.0|2.4|order to predict the next word in a
2737.14|3.24|sequence
2738.4|3.6|so let's train on the data from the
2740.38|3.719|internet
2742.0|4.319|uh what do you think about this this
2744.099|4.801|approach in terms of data sets of using
2746.319|4.441|data from the internet do you think the
2748.9|4.62|internet has enough structured data to
2750.76|4.8|teach AI about human civilization
2753.52|3.599|yeah so I think the internet has a huge
2755.56|3.84|amount of data I'm not sure if it's a
2757.119|4.921|complete enough set I don't know that uh
2759.4|5.34|text is enough for having a sufficiently
2762.04|4.5|powerful AGI as an outcome
2764.74|3.24|um of course there is audio and video
2766.54|3.42|and images and all that kind of stuff
2767.98|3.42|yeah so text by itself I'm a little bit
2769.96|3.54|suspicious about there's a ton of things
2771.4|3.6|we don't put in text in writing uh just
2773.5|2.76|because they're obvious to us about how
2775.0|2.819|the world works and the physics of it
2776.26|3.0|and the Things fall we don't put that
2777.819|3.0|stuff in text because why would you we
2779.26|3.18|share that understanding
2780.819|3.741|and so Texas communication medium
2782.44|4.08|between humans and it's not a
2784.56|4.059|all-encompassing medium of knowledge
2786.52|4.26|about the world but as you pointed out
2788.619|4.021|we do have video and we have images and
2790.78|3.72|we have audio and so I think that that
2792.64|4.679|definitely helps a lot but we haven't
2794.5|5.28|trained models uh sufficiently uh across
2797.319|3.481|both across all those modalities yet so
2799.78|2.52|I think that's what a lot of people are
2800.8|3.539|interested in but I wonder what that
2802.3|3.72|shared understanding of like well we
2804.339|3.921|might call Common Sense
2806.02|4.319|has to be learned
2808.26|5.319|inferred in order to complete the
2810.339|6.061|sentence correctly so maybe the fact
2813.579|4.921|that it's implied on the internet the
2816.4|5.1|model is going to have to learn that not
2818.5|5.64|by reading about it by inferring it in
2821.5|4.079|the representation so like common sense
2824.14|4.679|just like we I don't think we learn
2825.579|5.581|common sense like nobody says
2828.819|4.141|tells us explicitly we just figure it
2831.16|4.38|all out by interacting with the world
2832.96|4.56|right so here's a model of reading about
2835.54|3.9|the way people interact with the world
2837.52|5.579|it might have to infer that
2839.44|5.82|I wonder yeah uh you you briefly worked
2843.099|4.441|on a project called the world of bits
2845.26|3.92|training in our RL system to take
2847.54|4.079|actions on the internet
2849.18|3.82|versus just consuming the internet like
2851.619|2.421|we talked about do you think there's a
2853.0|2.88|future for that kind of system
2854.04|4.0|interacting with the internet to help
2855.88|4.14|the learning yes I think that's probably
2858.04|4.44|the uh the final frontier for a lot of
2860.02|4.5|these models because
2862.48|3.3|um so as you mentioned I was at open AI
2864.52|2.579|I was working on this project world of
2865.78|2.88|bits and basically it was the idea of
2867.099|4.26|giving neural networks access to a
2868.66|6.12|keyboard and a mouse and the idea could
2871.359|6.301|possibly go wrong so basically you um
2874.78|4.02|you perceive the input of the screen
2877.66|3.6|pixels
2878.8|4.319|and basically the state of the computer
2881.26|4.559|is sort of visualized for human
2883.119|4.321|consumption in images of the web browser
2885.819|2.881|and stuff like that and then you give
2887.44|3.12|the neural network the ability to press
2888.7|3.3|keyboards and use the mouse and we're
2890.56|3.18|trying to get it to for example complete
2892.0|4.38|bookings and you know interact with user
2893.74|4.379|interfaces and um what did you learn
2896.38|4.68|from that experience like what was some
2898.119|4.321|fun stuff this is super cool idea yeah I
2901.06|3.84|mean it's like
2902.44|5.399|uh yeah I mean the the step between
2904.9|5.16|Observer to actor yeah is a super
2907.839|4.201|fascinating step yeah well the universal
2910.06|4.259|interface in the digital realm I would
2912.04|3.84|say and there's a universal interface in
2914.319|3.721|like the Physical Realm which in my mind
2915.88|4.14|is a humanoid form factor kind of thing
2918.04|4.5|we can later talk about Optimus and so
2920.02|4.2|on but I feel like there's a
2922.54|3.299|they're kind of like a similar
2924.22|3.48|philosophy in some way where the human
2925.839|3.721|the world the physical world is designed
2927.7|3.96|for the human form and the digital world
2929.56|4.38|is designed for the human form of seeing
2931.66|4.38|the screen and using keyword keyboard
2933.94|5.04|and mouse and so as the universal
2936.04|4.44|interface that can basically uh command
2938.98|4.26|the digital infrastructure we've built
2940.48|4.74|up for ourselves and so it feels like a
2943.24|4.379|very powerful interface to to command
2945.22|3.54|and to build on top of now to your
2947.619|3.121|question as to like what I learned from
2948.76|4.319|that it's interesting because the world
2950.74|4.28|of bits was basically uh too early I
2953.079|5.821|think at open AI at the time
2955.02|5.38|this is around 2015 or so and the
2958.9|3.6|Zeitgeist at that time was very
2960.4|4.62|different in AI from the Zeitgeist today
2962.5|3.9|at the time everyone was super excited
2965.02|3.839|about reinforcement learning from
2966.4|4.74|scratch this is the time of the Atari
2968.859|4.381|paper where uh neural networks were
2971.14|5.04|playing Atari games and beating humans
2973.24|4.079|in some cases uh alphago and so on so
2976.18|2.399|everyone's very excited about train
2977.319|3.3|training neural networks from scratch
2978.579|3.601|using reinforcement learning
2980.619|3.121|um directly
2982.18|3.12|it turns out that reinforcement learning
2983.74|3.3|is extremely inefficient way of training
2985.3|2.819|neural networks because you're taking
2987.04|2.7|all these actions and all these
2988.119|3.781|observations and you get some sparse
2989.74|4.02|rewards once in a while so you do all
2991.9|3.719|this stuff based on all these inputs and
2993.76|3.839|once in a while you're like told you did
2995.619|3.421|a good thing you did a bad thing and
2997.599|2.941|it's just an extremely hard problem you
2999.04|3.6|can't learn from that you can burn
3000.54|3.42|forest and you can sort of Brute Force
3002.64|3.84|through it and we saw that I think with
3003.96|4.92|uh you know with uh go and DOTA and so
3006.48|4.74|on and it does work but it's extremely
3008.88|3.66|inefficient uh and not how you want to
3011.22|3.119|approach problems uh practically
3012.54|3.6|speaking and so that's the approach that
3014.339|4.441|at the time we also took to World of
3016.14|4.38|bits we would uh have an agent
3018.78|3.48|initialize randomly so with keyboard
3020.52|4.68|mash and mouse mash and try to make a
3022.26|4.62|booking and it's just like revealed the
3025.2|3.96|insanity of that approach very quickly
3026.88|4.08|where you have to stumble by the correct
3029.16|3.3|booking in order to get a reward of you
3030.96|4.2|did it correctly and you're never going
3032.46|4.5|to stumble by it by chance at random
3035.16|3.48|so even with a simple web interface
3036.96|3.899|there's too many options there's just
3038.64|4.08|too many options uh and uh it's two
3040.859|3.48|sparse of reward signal and you're
3042.72|2.82|starting from scratch at the time and so
3044.339|3.061|you don't know how to read you don't
3045.54|2.88|understand pictures images buttons you
3047.4|2.88|don't understand what it means to like
3048.42|4.679|make a booking but now what's happened
3050.28|4.799|is uh it is time to revisit that and
3053.099|3.601|open your eyes interested in this uh
3055.079|4.26|companies like Adept are interested in
3056.7|4.2|this and so on and uh the idea is coming
3059.339|3.121|back because the interface is very
3060.9|3.0|powerful but now you're not training an
3062.46|4.08|agent from scratch you are taking the
3063.9|6.3|GPT as an initialization so GPT is
3066.54|5.1|pre-trained on all of text and it
3070.2|3.3|understands what's a booking it
3071.64|4.56|understands what's a submit it
3073.5|3.9|understands um quite a bit more and so
3076.2|2.94|it already has those representations
3077.4|3.06|they are very powerful and that makes
3079.14|3.54|all the training significantly more
3080.46|4.92|efficient and makes the problem
3082.68|4.439|tractable should the interaction be with
3085.38|3.6|like the way humans see it with the
3087.119|4.141|buttons and the language or it should be
3088.98|4.26|with the HTML JavaScript and this and
3091.26|4.319|the CSS what's what do you think is the
3093.24|4.2|better so today all this interest is
3095.579|3.601|mostly on the level of HTML CSS and so
3097.44|5.04|on that's done because of computational
3099.18|5.159|constraints but I think ultimately
3102.48|3.9|everything is designed for human visual
3104.339|3.121|consumption and so at the end of the day
3106.38|3.9|there's all the additional information
3107.46|4.32|is in the layout of the web page and
3110.28|2.64|what's next to you and what's a red
3111.78|2.88|background and all this kind of stuff
3112.92|3.0|and what it looks like visually so I
3114.66|3.24|think that's the final frontier as we
3115.92|4.26|are taking in pixels and we're giving
3117.9|4.32|out keyboard mouse commands but I think
3120.18|4.439|it's impractical still today do you
3122.22|4.8|worry about bots on the internet
3124.619|3.601|given given these ideas given how
3127.02|3.9|exciting they are do you worry about
3128.22|4.379|bots on Twitter being not the the stupid
3130.92|3.659|boss that we see now with the cryptobots
3132.599|4.381|but the Bots that might be out there
3134.579|4.921|actually that we don't see that they're
3136.98|3.9|interacting in interesting ways so this
3139.5|4.38|kind of system feels like it should be
3140.88|5.28|able to pass the I'm not a robot click
3143.88|3.54|button whatever
3146.16|3.84|um which you actually understand how
3147.42|4.56|that test works I don't quite like
3150.0|4.02|there's there's a there's a check box or
3151.98|5.52|whatever that you click it's presumably
3154.02|7.14|tracking oh I see like Mouse movement
3157.5|4.859|and the timing and so on yeah so exactly
3161.16|3.84|this kind of system we're talking about
3162.359|4.681|should be able to pass that so yeah what
3165.0|5.52|do you feel about
3167.04|6.539|um Bots that are language models Plus
3170.52|4.68|have some interact ability and are able
3173.579|3.181|to tweet and reply and so on do you
3175.2|3.0|worry about that world
3176.76|3.78|uh yeah I think it's always been a bit
3178.2|4.68|of an arms race uh between sort of the
3180.54|3.779|attack and the defense uh so the attack
3182.88|3.6|will get stronger but the defense will
3184.319|4.141|get stronger as well our ability to
3186.48|5.16|detect that how do you defend how do you
3188.46|6.119|detect how do you know that your karpate
3191.64|5.16|account on Twitter is is human
3194.579|5.701|how do you approach that like if people
3196.8|6.0|were claim you know uh how would you
3200.28|4.14|defend yourself in the court of law that
3202.8|3.12|I'm a human
3204.42|4.02|um this account is yeah at some point I
3205.92|4.38|think uh it might be I think the society
3208.44|4.08|Society will evolve a little bit like we
3210.3|4.259|might start signing digitally signing uh
3212.52|4.319|some of our correspondents or you know
3214.559|3.901|things that we create uh right now it's
3216.839|3.961|not necessary but maybe in the future it
3218.46|4.379|might be I do think that we are going
3220.8|5.18|towards the world where we share
3222.839|6.301|we share the digital space with uh AIS
3225.98|4.96|synthetic beings yeah and uh they will
3229.14|3.179|get much better and they will share our
3230.94|2.76|digital realm and they'll eventually
3232.319|3.181|share our Physical Realm as well it's
3233.7|3.48|much harder uh but that's kind of like
3235.5|3.3|the world we're going towards and most
3237.18|3.179|of them will be benign and awful and
3238.8|3.12|some of them will be malicious and it's
3240.359|4.26|going to be an arms race trying to
3241.92|5.1|detect them so I mean the worst isn't
3244.619|5.22|the AI is the worst is the AIS
3247.02|4.86|pretending to be human so mine I don't
3249.839|3.361|know if it's always malicious there's
3251.88|3.54|obviously a lot of malicious
3253.2|5.82|applications but yeah it could also be
3255.42|5.22|you know if I was an AI I would try very
3259.02|3.72|hard to pretend to be human because
3260.64|4.679|we're in a human world yeah I wouldn't
3262.74|4.079|get any respect as an AI yeah I want to
3265.319|3.3|get some love and respect I don't think
3266.819|3.3|the problem is intractable people are
3268.619|3.72|people are thinking about the proof of
3270.119|4.261|personhood yes and uh we might start
3272.339|4.621|digitally signing our stuff and we might
3274.38|4.14|all end up having like uh
3276.96|2.94|yeah basically some some solution for
3278.52|2.88|proof of personhood it doesn't seem to
3279.9|3.659|be intractable it's just something that
3281.4|3.659|we haven't had to do until now but I
3283.559|4.02|think once the need like really starts
3285.059|4.981|to emerge which is soon I think when
3287.579|5.401|people think about it much more so but
3290.04|5.88|that too will be a race because
3292.98|6.139|um obviously you can probably uh spoof
3295.92|5.939|or fake the the the proof of
3299.119|5.621|personhood so you have to try to figure
3301.859|4.321|out how to probably I mean it's weird
3304.74|4.8|that we have like Social Security
3306.18|5.82|numbers and like passports and stuff
3309.54|4.799|it seems like it's harder to fake stuff
3312.0|4.079|in the physical space than the residual
3314.339|5.581|space it just feels like it's going to
3316.079|5.701|be very tricky very tricky to out
3319.92|4.139|um because it seems to be pretty low
3321.78|6.36|cost fake stuff what are you gonna put
3324.059|6.661|an AI in jail for like trying to use a
3328.14|4.26|fake fake personhood proof you can I
3330.72|3.359|mean okay fine you'll put a lot of AIS
3332.4|3.959|in jail but there'll be more ai's
3334.079|5.101|arbitrary like exponentially more the
3336.359|6.061|cost of creating a bot is very low
3339.18|6.179|uh unless there's some kind of way
3342.42|5.58|to track accurately
3345.359|6.301|like you're not allowed to create any
3348.0|7.2|program without showing uh tying
3351.66|5.04|yourself to that program like you any
3355.2|4.74|program that runs on the internet you'll
3356.7|4.74|be able to uh Trace every single human
3359.94|3.36|program that was involved with that
3361.44|3.96|program yeah maybe you have to start
3363.3|3.36|declaring when uh you know we have to
3365.4|3.659|start drawing those boundaries and
3366.66|4.199|keeping track of okay uh what our
3369.059|4.981|digital entities versus
3370.859|4.5|human entities and uh what is the
3374.04|3.059|ownership of human entities and digital
3375.359|3.121|entities and uh
3377.099|1.921|something like that
3378.48|2.7|um
3379.02|5.52|I don't know but I think I'm optimistic
3381.18|4.86|that this is uh this is uh possible and
3384.54|4.14|at some in some sense we're currently in
3386.04|4.2|like the worst time of it because
3388.68|3.72|um all these Bots suddenly have become
3390.24|4.26|very capable but we don't have defenses
3392.4|3.36|yet built up as a society and but I
3394.5|3.0|think uh that doesn't seem to be
3395.76|3.299|intractable it's just something that we
3397.5|3.599|have to deal with it seems weird that
3399.059|5.52|the Twitter but like really crappy
3401.099|6.061|Twitter Bots are so numerous like is it
3404.579|4.201|so I presume that the engineers at
3407.16|4.199|Twitter are very good
3408.78|3.36|so it seems like what I would infer from
3411.359|3.841|that
3412.14|5.04|uh is it seems like a hard problem it
3415.2|4.2|they're probably catching all right if I
3417.18|4.98|were to sort of steal them on the case
3419.4|7.679|it's a hard problem and there's a huge
3422.16|8.82|cost to uh false positive
3427.079|6.421|to to removing a post by somebody that's
3430.98|4.56|not a bot because creates a very bad
3433.5|5.579|user experience so they're very cautious
3435.54|5.1|about removing so maybe it's uh and
3439.079|3.78|maybe the boss are really good at
3440.64|4.14|learning what gets removed and not
3442.859|4.2|such that they can stay ahead of the
3444.78|4.14|removal process very quickly my
3447.059|4.441|impression of it honestly is there's a
3448.92|5.04|lot of blowing for it I mean yeah just
3451.5|4.319|that's what I it's not subtle it's my
3453.96|3.899|impression of it it's not so but you
3455.819|5.101|have to yeah that's my impression as
3457.859|5.941|well but it feels like maybe you're
3460.92|4.56|seeing the the tip of the iceberg maybe
3463.8|4.2|the number of bots is in like the
3465.48|5.22|trillions and you have to like
3468.0|5.22|just it's a constant assault of bots and
3470.7|4.859|yeah you yeah I don't know
3473.22|3.839|um you have to still man the case
3475.559|3.78|because the boss I'm seeing are pretty
3477.059|4.441|like obvious I could write a few lines
3479.339|3.181|of code that catch these Bots I mean
3481.5|3.059|definitely there's a lot of longing
3482.52|3.66|fruit but I will say I agree that if you
3484.559|3.0|are a sophisticated actor you could
3486.18|2.46|probably create a pretty good bot right
3487.559|3.0|now
3488.64|3.84|um you know using tools like gpts
3490.559|3.921|because it's a language model you can
3492.48|5.339|generate faces that look quite good now
3494.48|5.859|uh and you can do this at scale and so I
3497.819|4.441|think um yeah it's quite plausible and
3500.339|4.081|it's going to be hard to defend there
3502.26|5.22|was a Google engineer that claimed that
3504.42|6.96|the Lambda was sentient do you think
3507.48|7.379|there's any inkling of Truth
3511.38|5.82|to what he felt and more importantly to
3514.859|4.2|me at least do you think language models
3517.2|2.82|will achieve sentence or the illusion of
3519.059|3.841|sentience
3520.02|4.74|soonish fish yeah to me it's a little
3522.9|5.159|bit of a canary Nicole mine kind of
3524.76|5.64|moment honestly a little bit because uh
3528.059|5.701|so this engineer spoke to like a chatbot
3530.4|5.64|at Google and uh became convinced that
3533.76|3.96|uh this bot is sentient yeah as there's
3536.04|3.18|some existential philosophical questions
3537.72|4.74|and it gave like reasonable answers and
3539.22|4.98|looked real and uh and so on so to me
3542.46|4.5|it's a uh
3544.2|5.04|he was he was uh he wasn't sufficiently
3546.96|5.339|trying to stress the system I think and
3549.24|4.319|uh exposing the truth of it as it is
3552.299|2.04|today
3553.559|3.361|um
3554.339|6.181|but uh I think this will be increasingly
3556.92|5.22|harder over time uh so uh yeah I think
3560.52|3.36|more and more people will basically uh
3562.14|3.179|become
3563.88|3.0|um
3565.319|3.3|yeah I think more and more there will be
3566.88|3.479|more people like that over time as this
3568.619|4.141|gets better like form an emotional
3570.359|4.681|connection to to an AI yeah perfectly
3572.76|4.44|plausible in my mind I think these AIS
3575.04|4.68|are actually quite good at human human
3577.2|4.74|connection human emotion a ton of text
3579.72|4.379|on the Internet is about humans and
3581.94|3.96|connection and love and so on so I think
3584.099|3.841|they have a very good understanding in
3585.9|4.679|some in some sense of of how people
3587.94|4.5|speak to each other about this and um
3590.579|4.561|they're very capable of creating a lot
3592.44|4.32|of that kind of text the um
3595.14|3.36|there's a lot of like sci-fi from 50s
3596.76|3.359|and 60s that imagined AIS in a very
3598.5|3.599|different way they are calculating cold
3600.119|4.2|vulcan-like machines that's not what
3602.099|5.7|we're getting today we're getting pretty
3604.319|6.421|emotional AIS that actually uh are very
3607.799|4.56|competent and capable of generating
3610.74|3.54|you know possible sounding text with
3612.359|3.841|respect to all of these topics see I'm
3614.28|3.6|really hopeful about AI systems that are
3616.2|4.139|like companions that help you grow
3617.88|4.739|develop as a human being help you
3620.339|4.621|maximize long-term happiness but I'm
3622.619|4.68|also very worried about AI systems that
3624.96|4.619|figure out from the internet the humans
3627.299|3.841|get attracted to drama and so these
3629.579|3.661|would just be like shit talking AIS
3631.14|4.74|that's just constantly did you hear like
3633.24|6.119|they'll do gossip they'll do uh they'll
3635.88|6.66|try to plant seeds of Suspicion to like
3639.359|5.7|other humans that you love and trust and
3642.54|3.84|just kind of mess with people uh in the
3645.059|3.661|you know because because that's going to
3646.38|5.88|get a lot of attention so drama maximize
3648.72|5.76|drama on the path to maximizing uh
3652.26|5.64|engagement and US humans will feed into
3654.48|6.2|that machine yeah and get it'll be a
3657.9|5.52|giant drama shitstorm
3660.68|5.379|so I'm worried about that so it's the
3663.42|5.28|objective function really defines the
3666.059|5.401|way that human civilization progresses
3668.7|4.8|with AIS in it yeah I think right now at
3671.46|3.3|least today they are not sort of it's
3673.5|3.599|not correct to really think of them as
3674.76|4.68|goal seeking agents that want to do
3677.099|4.5|something they have no long-term memory
3679.44|4.139|or anything they it's literally a good
3681.599|2.941|approximation of it is you get a
3683.579|2.461|thousand words and you're trying to
3684.54|3.72|predict a thousand at first and then you
3686.04|4.019|continue feeding it in and you are free
3688.26|4.98|to prompt it in whatever way you want so
3690.059|4.981|in text so you say okay you are a
3693.24|3.78|psychologist and you are very good and
3695.04|3.059|you love humans and here's a
3697.02|4.38|conversation between you and another
3698.099|5.281|human human colon Something you
3701.4|3.12|something and then it just continues the
3703.38|2.219|pattern and suddenly you're having a
3704.52|3.36|conversation with a fake psychologist
3705.599|3.901|who's not trying to help you and so it's
3707.88|3.78|still kind of like in a realm of a tool
3709.5|3.839|it is a um people can prompt their
3711.66|3.6|arbitrary ways and it can create really
3713.339|3.601|incredible text but it doesn't have
3715.26|4.319|long-term goals over long periods of
3716.94|4.56|time it doesn't try to uh so it doesn't
3719.579|3.841|look that way right now yeah but you can
3721.5|5.04|do short-term goals that have long-term
3723.42|5.52|effects so if my prompting
3726.54|4.92|short-term goal is to get Andre capacity
3728.94|5.34|to respond to me on Twitter when I
3731.46|4.619|like I think AI might that's the goal
3734.28|4.019|but he might figure out that talking
3736.079|4.02|shit to you it would be the best in a
3738.299|4.081|highly sophisticating interesting way
3740.099|5.76|and then you build up a relationship
3742.38|7.199|when you respond once and then it
3745.859|6.141|like over time it gets to not be
3749.579|6.141|sophisticated and just
3752.0|6.7|like just talk shit
3755.72|5.44|and okay maybe you won't get to Andre
3758.7|5.28|but it might get to another celebrity it
3761.16|4.98|might get into other big accounts and
3763.98|4.619|then it'll just so with just that simple
3766.14|4.5|goal get them to respond yeah maximize
3768.599|4.02|the probability of actual response yeah
3770.64|3.9|I mean you could prompt a uh powerful
3772.619|4.261|model like this with their its opinion
3774.54|3.66|about how to do any possible thing
3776.88|2.76|you're interested in so they will
3778.2|3.48|discuss they're kind of on track to
3779.64|4.32|become these oracles I could I sort of
3781.68|3.72|think of it that way they are oracles uh
3783.96|2.7|currently is just text but they will
3785.4|3.12|have calculators they will have access
3786.66|3.84|to Google search they will have all
3788.52|3.839|kinds of couches and gizmos they will be
3790.5|4.079|able to operate the internet and find
3792.359|3.421|different information and
3794.579|3.24|um
3795.78|3.48|yeah in some sense
3797.819|2.581|that's kind of like currently what it
3799.26|2.579|looks like in terms of the development
3800.4|5.88|do you think it'll be an improvement
3801.839|6.541|eventually over what Google is for
3806.28|3.72|access to human knowledge like it'll be
3808.38|3.419|a more effective search engine to access
3810.0|3.18|human knowledge I think there's definite
3811.799|3.661|scope in building a better search engine
3813.18|3.72|today and I think Google they have all
3815.46|2.46|the tools all the people they have
3816.9|2.459|everything they need they have all the
3817.92|3.54|puzzle pieces they have people training
3819.359|4.801|Transformers at scale they have all the
3821.46|4.379|data uh it's just not obvious if they
3824.16|3.24|are capable as an organization to
3825.839|3.24|innovate on their search engine right
3827.4|3.48|now and if they don't someone else will
3829.079|3.361|there's absolute scope for building a
3830.88|3.959|significantly better search engine built
3832.44|4.859|on these tools it's so interesting a
3834.839|4.861|large company where the search there's
3837.299|4.56|already an infrastructure it works as it
3839.7|4.8|brings out a lot of money so where
3841.859|4.801|structurally inside a company is their
3844.5|4.14|motivation to Pivot yeah to say we're
3846.66|4.679|going to build a new search engine yep
3848.64|5.219|that's really hard so it's usually going
3851.339|5.341|to come from a startup right that's um
3853.859|4.681|that would be yeah or some other more
3856.68|4.919|competent organization
3858.54|5.22|um so uh I don't know so currently for
3861.599|4.801|example maybe Bing has another shot at
3863.76|4.68|it you know so Microsoft Edge because
3866.4|3.78|we're talking offline
3868.44|3.54|um I mean I definitely it's really
3870.18|3.659|interesting because search engines used
3871.98|5.22|to be about okay here's some query
3873.839|5.041|here's here's here's web pages that look
3877.2|3.359|like the stuff that you have but you
3878.88|3.6|could just directly go to answer and
3880.559|4.201|then have supporting evidence
3882.48|3.96|um and these uh these models basically
3884.76|3.539|they've read all the texts and they've
3886.44|3.119|read all the web pages and so sometimes
3888.299|2.581|when you see yourself going over to
3889.559|3.54|search results and sort of getting like
3890.88|3.719|a sense of like the average answer to
3893.099|2.7|whatever you're interested in uh like
3894.599|3.0|that just directly comes out you don't
3895.799|2.401|have to do that work
3897.599|3.121|um
3898.2|4.139|so they're kind of like uh
3900.72|4.32|yeah I think they have a way to this of
3902.339|4.621|distilling all that knowledge into
3905.04|4.319|like some level of insight basically do
3906.96|4.859|you think of prompting as a kind of
3909.359|5.601|teaching and learning like this whole
3911.819|5.401|process like another layer
3914.96|3.879|you know because maybe that's what
3917.22|4.139|humans are we already have that
3918.839|5.76|background model and then your the world
3921.359|4.801|is prompting you yeah exactly I think
3924.599|4.381|the way we are programming these
3926.16|4.56|computers now like gpts is is converging
3928.98|4.619|to how you program humans I mean how do
3930.72|4.859|I program humans via prompt I go to
3933.599|4.441|people and I I prompt them to do things
3935.579|3.841|I prompt them from information and so uh
3938.04|2.819|natural language prompt is how we
3939.42|2.82|program humans and we're starting to
3940.859|2.821|program computers directly in that
3942.24|3.599|interface it's like pretty remarkable
3943.68|5.899|honestly so you've spoken a lot about
3945.839|3.74|the idea of software 2.0
3949.74|4.44|um all good ideas
3951.54|5.519|become like cliches so quickly like the
3954.18|4.86|terms it's kind of hilarious
3957.059|4.861|um it's like I think Eminem once said
3959.04|5.34|that like if he gets annoyed by a song
3961.92|4.86|He's written very quickly that means
3964.38|5.939|it's going to be a big hit because it's
3966.78|5.16|it's too catchy but uh can you describe
3970.319|3.421|this idea and how you're thinking about
3971.94|5.399|it has evolved over the months and years
3973.74|5.52|since since you coined it yeah
3977.339|4.621|yeah so I had a blog post on software
3979.26|3.299|2.0 I think several years ago now
3981.96|2.7|um
3982.559|4.141|and the reason I wrote that post is
3984.66|4.439|because I kept I kind of saw something
3986.7|4.44|remarkable happening in
3989.099|3.841|like software development and how a lot
3991.14|4.26|of code was being transitioned to be
3992.94|3.84|written not in sort of like C plus and
3995.4|3.48|so on but it's written in the weights of
3996.78|3.779|a neural net basically just saying that
3998.88|4.56|neural Nets are taking over software the
4000.559|5.161|realm of software and uh taking more and
4003.44|4.859|more tasks and at the time I think not
4005.72|3.96|many people understood uh this uh deeply
4008.299|3.54|enough that this is a big deal it's a
4009.68|4.08|big transition uh neural networks were
4011.839|3.901|seen as one of multiple classification
4013.76|4.5|algorithms you might use for your data
4015.74|5.579|set problem on kaggle like this is not
4018.26|4.62|that this is a change in how we program
4021.319|4.74|computers
4022.88|4.979|and I saw neural Nets as uh this is
4026.059|3.24|going to take over the way we program
4027.859|3.361|computers is going to change is not
4029.299|3.3|going to be people writing a software in
4031.22|3.42|C plus or something like that and
4032.599|4.381|directly programming the software it's
4034.64|4.14|going to be accumulating training sets
4036.98|2.879|and data sets and crafting these
4038.78|2.88|objectives by which we train these
4039.859|3.601|neural Nets and at some point there's
4041.66|3.54|going to be a compilation process from
4043.46|4.079|the data sets and the objective and the
4045.2|4.619|architecture specification into the
4047.539|4.56|binary which is really just uh the
4049.819|4.02|neural nut you know weights and the
4052.099|3.601|forward pass of the neural net and then
4053.839|3.321|you can deploy that binary and so I was
4055.7|4.919|talking about that sort of transition
4057.16|5.199|and uh that's what the post is about and
4060.619|5.041|I saw this sort of play out in a lot of
4062.359|5.101|fields uh you know autopilot being one
4065.66|4.32|of them but also just a simple image
4067.46|4.56|classification people thought originally
4069.98|4.2|you know in the 80s and so on that they
4072.02|4.2|would write the algorithm for detecting
4074.18|3.84|a dog in an image and they had all these
4076.22|3.3|ideas about how the brain does it and
4078.02|2.76|first we detected corners and then we
4079.52|2.819|detect lines and then we stitched them
4080.78|2.94|up and they were like really going at it
4082.339|2.881|they were like thinking about how
4083.72|4.099|they're going to write the algorithm and
4085.22|4.859|this is not the way you build it
4087.819|4.361|and there was a smooth transition where
4090.079|4.381|okay first we thought we were going to
4092.18|4.8|build everything then we were building
4094.46|4.56|the features uh so like Hawk features
4096.98|3.239|and things like that that detect these
4099.02|2.88|little statistical patterns from image
4100.219|3.6|patches and then there was a little bit
4101.9|4.74|of learning on top of it like a support
4103.819|4.801|Vector machine or binary classifier for
4106.64|4.139|cat versus dog and images on top of the
4108.62|4.98|features so we wrote the features but we
4110.779|4.44|trained the last layer sort of the the
4113.6|2.759|classifier and then people are like
4115.219|3.06|actually let's not even design the
4116.359|3.781|features because we can't honestly we're
4118.279|3.661|not very good at it so let's also learn
4120.14|3.059|the features and then you end up with
4121.94|3.18|basically a convolutional neural net
4123.199|4.261|where you're learning most of it you're
4125.12|3.96|just specifying the architecture and the
4127.46|3.6|architecture has tons of fill in the
4129.08|3.779|blanks which is all the knobs and you
4131.06|3.779|let the optimization write most of it
4132.859|4.561|and so this transition is happening
4134.839|4.5|across the industry everywhere and uh
4137.42|3.66|suddenly we end up with a ton of code
4139.339|3.36|that is written in neural net weights
4141.08|3.9|and I was just pointing out that the
4142.699|4.02|analogy is actually pretty strong and we
4144.98|4.799|have a lot of developer environments for
4146.719|4.441|software 1.0 like we have Ides
4149.779|3.42|um how you work with code how you debug
4151.16|3.84|code how do you how do you run code how
4153.199|2.941|do you maintain code we have GitHub so I
4155.0|2.94|was trying to make those analogies in
4156.14|3.599|the new realm like what is the GitHub or
4157.94|3.299|software 2.0 it turns out that something
4159.739|4.681|that looks like hugging face right now
4161.239|4.5|uh you know and so I think some people
4164.42|3.899|took it seriously and built cool
4165.739|4.141|companies and uh many people originally
4168.319|3.9|attacked the post it actually was not
4169.88|3.54|well received when I wrote it and I
4172.219|2.881|think maybe it has something to do with
4173.42|3.18|the title but the post was not well
4175.1|3.42|received and I think more people sort of
4176.6|5.699|have been coming around to it over time
4178.52|6.62|yeah so you were the director of AI at
4182.299|6.9|Tesla where I think this idea
4185.14|5.5|was really implemented at scale which is
4189.199|4.261|how you have engineering teams doing
4190.64|6.3|software 2.0 so can you sort of Linger
4193.46|5.04|on that idea of I think we're in the
4196.94|4.32|really early stages of everything you
4198.5|5.4|just said which is like GitHub Ides
4201.26|5.88|like how do we build engineering teams
4203.9|6.36|that that work in software 2.0 systems
4207.14|5.76|and and the the data collection and the
4210.26|5.459|data annotation which is
4212.9|4.56|all part of that software 2.0 like what
4215.719|5.701|do you think is the task of programming
4217.46|6.42|a software 2.0 is it debugging in the
4221.42|5.58|space of hyper parameters or is it also
4223.88|5.58|debugging the space of data yeah the way
4227.0|5.64|by which you program the computer and
4229.46|5.34|influence its algorithm is not by
4232.64|4.68|writing the commands yourself you're
4234.8|5.22|changing mostly the data set uh you're
4237.32|4.379|changing the um loss functions of like
4240.02|2.94|what the neural net is trying to do how
4241.699|2.821|it's trying to predict things but yeah
4242.96|5.0|basically the data sets and the
4244.52|5.82|architectures of the neural net and um
4247.96|3.52|so in the case of the autopilot a lot of
4250.34|2.58|the data sets have to do with for
4251.48|2.94|example detection of objects and Lane
4252.92|3.18|line markings and traffic lights and so
4254.42|4.38|on So You accumulate massive data sets
4256.1|6.18|of here's an example here's the desired
4258.8|4.74|label and then uh here's roughly how the
4262.28|2.459|architect here's roughly what the
4263.54|2.699|algorithm should look like and that's a
4264.739|2.641|conclusional neural net so the
4266.239|3.061|specification of the architecture is
4267.38|3.54|like a hint as to what the algorithm
4269.3|3.6|should roughly look like and then to
4270.92|4.62|fill in the blanks process of
4272.9|4.38|optimization is the training process
4275.54|3.0|and then you take your neural nut that
4277.28|2.82|was trained it gives all the right
4278.54|2.34|answers on your data set and you deploy
4280.1|4.38|it
4280.88|5.64|so there's in that case perhaps it all
4284.48|3.48|machine learning cases there's a lot of
4286.52|6.0|tasks
4287.96|7.199|so is coming up formulating a task like
4292.52|4.08|uh for a multi-headed neural network is
4295.159|4.141|formulating a task part of the
4296.6|5.639|programming yeah very much so how you
4299.3|3.96|break down a problem into a set of tasks
4302.239|2.881|yeah
4303.26|5.22|I'm on a high level I would say if you
4305.12|5.099|look at the software running in in the
4308.48|3.9|autopilot I gave a number of talks on
4310.219|3.781|this topic I would say originally a lot
4312.38|4.319|of it was written in software 1.0
4314.0|5.28|there's imagine lots of C plus plus all
4316.699|3.901|right and then gradually there was a
4319.28|3.6|tiny neural net that was for example
4320.6|3.9|predicting given a single image is there
4322.88|3.299|like a traffic light or not or is there
4324.5|4.02|a landline marking or not and this
4326.179|4.081|neural net didn't have too much to do in
4328.52|3.06|this in the scope of the software it was
4330.26|3.54|making tiny predictions on individual
4331.58|4.56|little image and then the rest of the
4333.8|3.48|system stitched it up so okay we're
4336.14|2.7|actually we don't have just a single
4337.28|3.66|camera with eight cameras we actually
4338.84|3.24|have eight cameras over time and so what
4340.94|2.759|do you do with these predictions how do
4342.08|3.3|you put them together how do you do the
4343.699|3.241|fusion of all that information and how
4345.38|4.2|do you act on it all of that was written
4346.94|4.68|by humans um in C plus
4349.58|4.8|and then we decided okay we don't
4351.62|4.8|actually want uh to do all of that
4354.38|3.24|Fusion in C plus code because we're
4356.42|2.759|actually not good enough to write that
4357.62|3.18|algorithm we want the neural Nets to
4359.179|4.081|write the algorithm and we want to Port
4360.8|3.3|uh all of that software into the 2.0
4363.26|2.58|stack
4364.1|3.599|and so then we actually had neural Nets
4365.84|3.54|that now take all the eight camera
4367.699|3.241|images simultaneously and make
4369.38|3.359|predictions for all of that
4370.94|3.6|so
4372.739|3.601|um and and actually they don't make
4374.54|4.1|predictions in a in the space of images
4376.34|4.62|they now make predictions directly in 3D
4378.64|4.3|and actually they don't in three
4380.96|3.6|dimensions around the car and now
4382.94|4.38|actually we don't
4384.56|4.92|um manually fuse the predictions over in
4387.32|4.14|3D over time we don't trust ourselves to
4389.48|4.44|write that tracker so actually we give
4391.46|4.32|the neural net uh the information over
4393.92|3.72|time so it takes these videos now and
4395.78|3.24|makes those predictions and so your sort
4397.64|3.3|of just like putting more and more power
4399.02|4.56|into the neural network processing and
4400.94|4.08|at the end of it the eventual sort of
4403.58|4.38|goal is to have most of the software
4405.02|4.92|potentially be in the 2.0 land
4407.96|3.96|um because it works significantly better
4409.94|3.48|humans are just not very good at writing
4411.92|4.319|software basically so the prediction is
4413.42|4.86|space happening in this like 4D land
4416.239|4.261|yeah was three-dimensional world over
4418.28|4.919|time yeah how do you
4420.5|5.06|do annotation in that world what what
4423.199|5.161|have you as it's just a data annotation
4425.56|6.94|whether it's self-supervised or manual
4428.36|6.839|by humans is um is a big part of this
4432.5|4.44|software 2.0 world right I would say by
4435.199|3.781|far in the industry if you're like
4436.94|3.239|talking about the industry and how what
4438.98|2.46|is the technology of what we have
4440.179|3.961|available everything is supervised
4441.44|4.98|learning so you need data sets of input
4444.14|5.039|desired output and you need lots of it
4446.42|3.9|and um there are three properties of it
4449.179|3.181|that you need you need it to be very
4450.32|3.96|large you need it to be accurate No
4452.36|5.46|mistakes and you need it to be diverse
4454.28|5.1|you don't want to uh just have a lot of
4457.82|3.0|correct examples of one thing you need
4459.38|3.24|to really cover the space of possibility
4460.82|3.54|as much as you can and the more you can
4462.62|3.119|cover the space of possible inputs the
4464.36|3.48|better the algorithm will work at the
4465.739|4.741|end now once you have really good data
4467.84|4.98|sets that you're collecting curating
4470.48|3.42|um and cleaning you can train uh your
4472.82|3.18|neural net
4473.9|3.72|um on top of that so a lot of the work
4476.0|3.6|goes into cleaning those data sets now
4477.62|3.66|as you pointed out it's probably it
4479.6|4.5|could be the question is how do you
4481.28|5.04|achieve a ton of uh if you want to
4484.1|5.22|basically predict in 3D you need data in
4486.32|4.56|3D to back that up so in this video we
4489.32|4.26|have eight videos coming from all the
4490.88|4.68|cameras of the system and this is what
4493.58|3.42|they saw and this is the truth of what
4495.56|3.179|actually was around there was this car
4497.0|3.06|there was this car this car these are
4498.739|2.581|the lane line markings this is geometry
4500.06|3.0|of the road there's a traffic light in
4501.32|3.18|this three-dimensional position you need
4503.06|3.119|the ground truth
4504.5|3.78|um and so the big question that the team
4506.179|3.121|was solving of course is how do you how
4508.28|2.58|do you arrive at that ground truth
4509.3|3.66|because once you have a million of it
4510.86|3.42|and it's large clean and diverse then
4512.96|2.64|training a neural network on it works
4514.28|2.34|extremely well and you can ship that
4515.6|3.36|into the car
4516.62|3.96|and uh so there's many mechanisms by
4518.96|3.42|which we collected that training data
4520.58|3.96|you can always go for human annotation
4522.38|4.26|you can go for simulation as a source of
4524.54|3.9|ground truth you can also go for what we
4526.64|2.519|call the offline tracker
4528.44|2.46|um
4529.159|3.481|that we've spoken about at the AI day
4530.9|3.72|and so on which is basically an
4532.64|4.26|automatic reconstruction process for
4534.62|4.68|taking those videos and recovering the
4536.9|4.319|three-dimensional sort of reality of
4539.3|3.12|what was around that car so basically
4541.219|3.601|think of doing like a three-dimensional
4542.42|5.1|reconstruction as an offline thing and
4544.82|4.859|then understanding that okay there's 10
4547.52|3.9|seconds of video this is what we saw and
4549.679|3.781|therefore here's all the lane last cars
4551.42|3.239|and so on and then once you have that
4553.46|3.9|annotation you can train your neural
4554.659|4.381|Nets to imitate it and how difficult is
4557.36|4.08|the reconstruct the 3D reconstruction
4559.04|3.9|it's difficult but it can be done so
4561.44|2.7|there's so the there's overlap between
4562.94|4.02|the cameras and you do the
4564.14|5.34|Reconstruction and there's uh
4566.96|4.68|perhaps if there's any inaccuracy so
4569.48|3.84|that's caught in The annotation step
4571.64|3.9|uh yes the nice thing about The
4573.32|4.2|annotation is that it is fully offline
4575.54|3.42|you have infinite time you have a chunk
4577.52|3.36|of one minute and you're trying to just
4578.96|3.96|offline in a super computer somewhere
4580.88|3.779|figure out where were the positions of
4582.92|3.18|all the cars all the people and you have
4584.659|3.121|your full one minute of video from all
4586.1|2.88|the Angles and you can run all the
4587.78|3.84|neural Nets you want and they can be
4588.98|3.9|very efficient massive neural Nets there
4591.62|3.42|can be neural Nets that can't even run
4592.88|3.54|in the car later at this time so they
4595.04|3.24|can be even more powerful neurons than
4596.42|2.7|what you can eventually deploy so you
4598.28|2.459|can do anything you want
4599.12|3.18|three-dimensional reconstruction neural
4600.739|2.821|Nets uh anything you want just to
4602.3|2.76|recover that truth and then you
4603.56|3.36|supervise that truth
4605.06|4.32|what have you learned you said no
4606.92|5.819|mistakes about humans
4609.38|6.0|doing annotation because I assume humans
4612.739|4.381|are uh there's like a range of things
4615.38|4.319|they're good at in terms of clicking
4617.12|5.059|stuff on screen it's not how interesting
4619.699|5.341|is that to you of a problem of designing
4622.179|4.841|an annotator where humans are accurate
4625.04|3.96|enjoy it like what are they even the
4627.02|4.56|metrics are efficient or productive all
4629.0|4.14|that kind of stuff yeah so uh I grew The
4631.58|4.139|annotation team at Tesla from basically
4633.14|5.22|zero to a thousand uh while I was there
4635.719|4.921|that was really interesting you know my
4638.36|4.02|background is a PhD student researcher
4640.64|5.519|so growing that common organization was
4642.38|5.76|pretty crazy uh but uh yeah I think it's
4646.159|3.361|extremely interesting and part of the
4648.14|3.42|design process very much behind the
4649.52|3.719|autopilot as to where you use humans
4651.56|3.119|humans are very good at certain kinds of
4653.239|2.761|annotations they're very good for
4654.679|3.06|example at two-dimensional annotations
4656.0|4.56|of images they're not good at annotating
4657.739|5.281|uh cars over time in three-dimensional
4660.56|4.44|space very very hard and so that's why
4663.02|3.719|we were very careful to design the tasks
4665.0|3.06|that are easy to do for humans versus
4666.739|3.361|things that should be left to the
4668.06|3.3|offline tracker like maybe the maybe the
4670.1|3.119|computer will do all the triangulation
4671.36|3.66|and 3D reconstruction but the human will
4673.219|4.141|say exactly these pixels of the image
4675.02|5.04|are car exactly these pixels are human
4677.36|5.4|and so co-designing the the data
4680.06|4.86|annotation pipeline was very much bread
4682.76|3.3|and butter was what I was doing daily do
4684.92|3.9|you think there's still a lot of open
4686.06|6.179|problems in that space
4688.82|5.22|um just in general annotation where the
4692.239|4.261|stuff the machines are good at machines
4694.04|3.96|do and the humans do what they're good
4696.5|4.08|at and there's maybe some iterative
4698.0|4.08|process right I think to a very large
4700.58|3.3|extent we went through a number of
4702.08|4.619|iterations and we learned a ton about
4703.88|4.859|how to create these data sets I'm not
4706.699|4.081|seeing big open problems like originally
4708.739|4.021|when I joined I was like I was really
4710.78|3.959|not sure how this would turn out yeah
4712.76|3.959|but by the time I left I was much more
4714.739|3.241|secure in actually we sort of understand
4716.719|2.881|the philosophy of how to create these
4717.98|4.56|data sets and I was pretty comfortable
4719.6|6.24|with where that was at the time so what
4722.54|5.159|are strengths and limitations of cameras
4725.84|3.66|for the driving test in your
4727.699|3.96|understanding when you formulate the
4729.5|3.48|driving task as a vision task with eight
4731.659|3.54|cameras
4732.98|3.54|you've seen that the entire you know
4735.199|2.701|most of the history of the computer
4736.52|3.24|vision field when it has to do with
4737.9|3.54|neural networks what just if you step
4739.76|5.04|back what are the strengths and
4741.44|5.88|limitations of pixels of using pixels to
4744.8|4.859|drive yeah pixels I think are a
4747.32|4.2|beautiful sensory beautiful sensor I
4749.659|3.661|would say the thing is like cameras are
4751.52|5.1|very very cheap and they provide a ton
4753.32|5.7|of information ton of bits uh so it's uh
4756.62|3.78|extremely cheap sensor for a ton of bits
4759.02|3.06|and each one of these bits as a
4760.4|4.98|constraint on the state of the world and
4762.08|5.099|so you get lots of megapixel images uh
4765.38|3.18|very cheap and it just gives you all
4767.179|2.461|these constraints for understanding
4768.56|3.72|what's actually out there in the world
4769.64|4.62|so vision is probably the highest
4772.28|5.34|bandwidth sensor
4774.26|8.04|it's a very high bandwidth sensor and um
4777.62|7.26|I love that pixels it is a is a
4782.3|4.02|constraint on the world This is highly
4784.88|3.9|complex
4786.32|3.66|uh high bandwidth constraint in the
4788.78|2.82|world on the stage of the world that's
4789.98|4.08|fascinating it's not just that but again
4791.6|4.079|this real real importance of
4794.06|4.32|it's the sensor that humans use
4795.679|5.461|therefore everything is designed for
4798.38|4.859|that sensor yeah the text the writing
4801.14|5.519|the flashing signs everything is
4803.239|4.681|designed for vision and so and you just
4806.659|3.421|find it everywhere and so that's why
4807.92|3.48|that is the interface you want to be in
4810.08|3.36|um talking again about these Universal
4811.4|3.12|interfaces and uh that's where we
4813.44|3.779|actually want to measure the world as
4814.52|4.26|well and then develop software uh for
4817.219|4.201|that sensor but there's other
4818.78|5.04|constraints on the state of the world
4821.42|6.239|that humans use to understand the world
4823.82|7.02|I mean Vision ultimately is the main one
4827.659|5.341|but we're like we're like referencing
4830.84|3.62|our understanding of human behavior and
4833.0|4.02|some common sense
4834.46|4.42|physics that could be inferred from
4837.02|4.199|vision from from a perception
4838.88|4.799|perspective but it feels like we're
4841.219|5.581|using some kind of reasoning
4843.679|4.681|to predict the world yeah not just the
4846.8|4.56|pixels I mean you have a powerful prior
4848.36|5.04|uh sorry right for how the world evolves
4851.36|4.5|over time Etc so it's not just about the
4853.4|4.08|likelihood term coming up from the data
4855.86|3.54|itself telling you about what you are
4857.48|3.42|observing but also the prior term of
4859.4|3.12|like where where are the likely things
4860.9|5.04|to see and how do they likely move and
4862.52|4.98|so on and the question is how complex is
4865.94|4.62|the uh
4867.5|5.28|the the range of possibilities that
4870.56|4.5|might happen in the driving task right
4872.78|4.26|that's still is is that to you still an
4875.06|4.44|open problem of how difficult is driving
4877.04|6.0|like philosophically speaking
4879.5|5.94|like do you all the time you've worked
4883.04|4.44|on driving do you understand how hard
4885.44|3.66|driving is yeah driving is really hard
4887.48|3.0|because it has to do with the
4889.1|3.0|predictions of all these other agents
4890.48|3.719|and the theory of mind and you know what
4892.1|3.48|they're gonna do and are they looking at
4894.199|3.121|you are they where are they looking what
4895.58|3.84|are they thinking yeah there's a lot
4897.32|4.74|that goes there at the at the full tail
4899.42|3.54|of you know the the expansion of the
4902.06|3.42|nines that we have to be comfortable
4902.96|4.08|with eventually the final problems are
4905.48|3.78|of that form I don't think those are the
4907.04|3.96|problems that are very common uh I think
4909.26|3.54|eventually they're important but it's
4911.0|3.86|like really in the tail end in the tail
4912.8|5.22|and the rare edge cases
4914.86|5.08|from the vision perspective what are the
4918.02|4.159|toughest parts of the vision problem of
4919.94|2.239|driving
4922.52|3.179|um
4923.179|4.141|well basically the sensor is extremely
4925.699|3.661|powerful but you still need to process
4927.32|4.62|that information
4929.36|4.02|um and so going from brightnesses of
4931.94|3.239|these pixel values to hey here the
4933.38|3.359|three-dimensional world is extremely
4935.179|4.441|hard and that's what the neural networks
4936.739|4.861|are fundamentally doing and so
4939.62|3.84|um the difficulty really is in just
4941.6|4.32|doing an extremely good job of
4943.46|5.04|engineering the entire pipeline uh the
4945.92|4.38|entire data engine having the capacity
4948.5|3.659|to train these neural nuts having the
4950.3|4.5|ability to evaluate the system and
4952.159|4.381|iterate on it uh so I would say just
4954.8|3.12|doing this in production at scale is
4956.54|5.58|like the hard part it's an execution
4957.92|7.5|problem so the data engine but also the
4962.12|5.4|um the sort of deployment of the system
4965.42|3.9|such that has low latency performance so
4967.52|3.24|it has to do all these steps yeah for
4969.32|3.3|the neural net specifically just making
4970.76|4.26|sure everything fits into the chip on
4972.62|4.559|the car yeah and uh you have a finite
4975.02|3.719|budget of flops that you can perform and
4977.179|3.48|uh and memory bandwidth and other
4978.739|3.48|constraints and you have to make sure it
4980.659|3.721|flies and you can squeeze in as much
4982.219|3.301|compute as you can into the tiny what
4984.38|2.819|have you learned from that process
4985.52|4.679|because it maybe that's one of the
4987.199|4.381|bigger like new things coming from a
4990.199|3.301|research background
4991.58|3.54|where there's there's a system that has
4993.5|3.48|to run under heavily constrained
4995.12|4.38|resources right has to run really fast
4996.98|3.78|what what kind of insights have you uh
4999.5|3.659|learned from that
5000.76|4.439|yeah I'm not sure if it's if there's too
5003.159|4.261|many insights you're trying to create a
5005.199|3.96|neural net that will fit in what you
5007.42|3.54|have available and you're always trying
5009.159|4.801|to optimize it and we talked a lot about
5010.96|4.86|it on the AI day and uh basically the
5013.96|3.96|the triple backflips that the team is
5015.82|4.2|doing to make sure it all fits and
5017.92|4.14|utilizes the engine uh so I think it's
5020.02|3.84|extremely good engineering
5022.06|3.54|um and then there's also all kinds of
5023.86|3.96|little insights peppered in on how to do
5025.6|3.24|it properly let's actually zoom out
5027.82|3.44|because I don't think we talked about
5028.84|5.64|the data engine the entirety of the
5031.26|6.28|layout of this idea that I think is just
5034.48|4.86|beautiful with humans in the loop can
5037.54|4.139|you describe the data engine
5039.34|5.28|yeah the data engine is what I call the
5041.679|6.301|almost biological feeling like process
5044.62|5.4|by which you uh perfect the training
5047.98|3.9|sets for these neural networks
5050.02|3.48|um so because most of the programming
5051.88|3.0|now is in the level of these data sets
5053.5|4.62|and make sure they're large diverse and
5054.88|4.92|clean oh basically you have a data set
5058.12|4.32|that you think is good you train your
5059.8|4.5|neural net you deploy it and then you
5062.44|4.08|observe how well it's performing and
5064.3|3.6|you're trying to uh always increase the
5066.52|3.24|quality of your data set so you're
5067.9|5.22|trying to catch scenarios basically
5069.76|4.56|there are basically rare and uh it is in
5073.12|2.52|these scenarios that the neural Nets
5074.32|2.76|will typically struggle in because they
5075.64|3.66|weren't told what to do in those rare
5077.08|3.78|cases in the data set but now you can
5079.3|3.84|close the loop because if you can now
5080.86|4.08|collect all those at scale you can then
5083.14|4.38|feed them back into the Reconstruction
5084.94|4.38|process I described and uh reconstruct
5087.52|3.48|the truth in those cases and add it to
5089.32|3.66|the data set and so the whole thing ends
5091.0|4.86|up being like a staircase of improvement
5092.98|4.38|of perfecting your training set and you
5095.86|4.2|have to go through deployments so that
5097.36|5.339|you can mine uh the parts that are not
5100.06|3.9|yet represented well in the data set so
5102.699|3.421|your data set is basically imperfect it
5103.96|4.08|needs to be diverse it has pockets there
5106.12|3.3|are missing and you need to pad out the
5108.04|2.28|pockets you can sort of think of it that
5109.42|3.54|way
5110.32|4.919|in the data what role do humans play in
5112.96|4.92|this so what's the uh this biological
5115.239|6.0|system like a human body is made up of
5117.88|5.94|cells what what role like how do you
5121.239|4.521|optimize the human uh system the the
5123.82|5.94|multiple Engineers collaborating
5125.76|6.76|figuring out what to focus on what to
5129.76|4.58|contribute which which task to optimize
5132.52|4.98|in this neural network
5134.34|5.46|uh who's in charge of figuring out which
5137.5|4.56|task needs more data
5139.8|5.32|can you speak to the hyper parameters
5142.06|4.44|the human uh system right it really just
5145.12|2.76|comes down to extremely good execution
5146.5|2.28|from an engineering team and does what
5147.88|2.94|they're doing they understand
5148.78|3.6|intuitively the philosophical insights
5150.82|3.899|underlying the data engine and the
5152.38|4.92|process by which the system improves and
5154.719|4.261|uh how to again like delegate the
5157.3|3.24|strategy of the data collection and how
5158.98|3.3|that works and then just making sure
5160.54|3.54|it's all extremely well executed and
5162.28|3.6|that's where most of the work is is not
5164.08|3.48|even the philosophizing or the research
5165.88|3.299|or the ideas of it it's just extremely
5167.56|3.78|good execution it's so hard when you're
5169.179|4.201|dealing with data at that scale so your
5171.34|4.56|role in the data engine executing well
5173.38|5.88|on it it is difficult and extremely
5175.9|6.18|important is there a priority of like uh
5179.26|4.86|like a vision board of saying like
5182.08|3.059|we really need to get better at stop
5184.12|3.18|lights
5185.139|4.201|yeah like the the prioritization of
5187.3|5.16|tasks is that essentially and that comes
5189.34|4.56|from the data that comes to um a very
5192.46|2.759|large extent to what we are trying to
5193.9|2.759|achieve in the product for a map where
5195.219|2.701|we're trying to the release we're trying
5196.659|3.0|to get out
5197.92|3.42|um in the feedback from the QA team
5199.659|2.821|worth it where the system is struggling
5201.34|3.18|or not the things we're trying to
5202.48|4.159|improve and the QA team gives some
5204.52|4.98|signal some information
5206.639|4.301|in aggregate about the performance of
5209.5|2.82|the system in various conditions and
5210.94|3.54|then of course all of us drive it and we
5212.32|3.419|can also see it it's really nice to work
5214.48|3.0|with the system that you can also
5215.739|4.681|experience yourself you know it drives
5217.48|4.739|you home it's is there some insight you
5220.42|3.6|can draw from your individual experience
5222.219|4.621|that you just can't quite get from an
5224.02|5.76|aggregate statistical analysis of data
5226.84|5.399|yeah it's so weird right yes it's it's
5229.78|4.68|not scientific in a sense because you're
5232.239|4.801|just one anecdotal sample yeah I think
5234.46|4.02|there's a ton of uh it's a source of
5237.04|3.06|truth it's your interaction with the
5238.48|3.96|system yeah and you can see it you can
5240.1|3.84|play with it you can perturb it you can
5242.44|3.84|get a sense of it you have an intuition
5243.94|4.32|for it I think numbers just like have a
5246.28|4.98|way of numbers and plots and graphs are
5248.26|5.28|you know much harder yeah it hides a lot
5251.26|3.899|of it's like if you train a language
5253.54|4.38|model
5255.159|4.56|it's a really powerful way is by you
5257.92|3.84|interacting with it yeah 100 try to
5259.719|4.141|build up an intuition yeah I think like
5261.76|4.74|Elon also like he always wanted to drive
5263.86|6.18|the system himself he drives a lot and
5266.5|5.58|uh I'm gonna say almost daily so uh he
5270.04|4.679|also sees this as a source of Truth you
5272.08|6.0|driving the system uh and it performing
5274.719|6.48|and yeah so what do you think tough
5278.08|6.599|questions here uh so Tesla last year
5281.199|5.341|removed radar from um from the sensor
5284.679|4.221|suite and now just announced that it's
5286.54|6.179|going to remove all ultrasonic sensors
5288.9|5.92|relying solely on Vision so camera only
5292.719|5.221|does that make the perception problem
5294.82|4.859|harder or easier
5297.94|4.44|I would almost reframe the question in
5299.679|4.201|some way so the thing is basically you
5302.38|3.48|would think that additional sensors by
5303.88|3.779|the way can I just interrupt good I
5305.86|4.2|wonder if a language model will ever do
5307.659|5.281|that if you prompt it let me reframe
5310.06|5.579|your question that would be epic this is
5312.94|3.779|the wrong problem sorry it's like a
5315.639|2.761|little bit of a wrong question because
5316.719|4.801|basically you would think that these
5318.4|5.339|sensors are an asset to you yeah but if
5321.52|3.6|you fully consider the entire product in
5323.739|2.641|its entirety
5325.12|2.28|these sensors are actually potentially
5326.38|3.66|reliability
5327.4|4.38|because these sensors aren't free they
5330.04|3.42|don't just appear on your car you need
5331.78|3.18|something you need to have an entire
5333.46|3.3|supply chain you have people procuring
5334.96|3.36|it there can be problems with them they
5336.76|2.7|may need replacement they are part of
5338.32|3.899|the manufacturing process they can hold
5339.46|3.84|back the line in production you need to
5342.219|2.641|Source them you need to maintain them
5343.3|4.5|you have to have teams that write the
5344.86|4.14|firmware all of it and then you also
5347.8|2.64|have to incorporate and fuse them into
5349.0|4.08|the system in some way and so it
5350.44|5.06|actually like bloats the organ the a lot
5353.08|4.92|of it and I think Elon is really good at
5355.5|4.42|simplify simplified best part is no part
5358.0|3.0|and he always tries to throw away things
5359.92|2.819|that are not essential because he
5361.0|4.86|understands the entropy in organizations
5362.739|4.741|and approach and I think uh in this case
5365.86|2.76|the cost is high and you're not
5367.48|2.759|potentially seeing it if you're just a
5368.62|3.48|computer vision engineer and I'm just
5370.239|3.721|trying to improve my network and you
5372.1|4.079|know is it more useful or less useful
5373.96|3.96|how useful is it and the thing is if
5376.179|3.301|once you consider the full cost of a
5377.92|3.42|sensor it actually is potentially a
5379.48|3.48|liability and you need to be really sure
5381.34|3.839|that it's giving you extremely useful
5382.96|4.14|information in this case we looked at
5385.179|4.081|using it or not using it and the Delta
5387.1|5.82|was not massive and so it's not useful
5389.26|5.24|is it also blow in the data engine like
5392.92|4.08|having more sensors
5394.5|3.52|is a distraction and these sensors you
5397.0|2.4|know they can change over time for
5398.02|2.88|example you can have one type of say
5399.4|3.12|radar you can have other type of radar
5400.9|2.88|they change over time I suddenly need to
5402.52|3.06|worry about it now suddenly you have a
5403.78|3.54|column in your sqlite telling you oh
5405.58|4.2|which sensor type was it and they all
5407.32|4.44|have different distributions and then uh
5409.78|4.379|they can they just they contribute noise
5411.76|4.62|and entropy into everything and they
5414.159|3.841|bloat stuff and also organizationally
5416.38|3.779|has been really fascinating to me that
5418.0|4.5|it can be very distracting
5420.159|4.621|um if you if all if you only want to get
5422.5|3.96|to work is Vision all the resources are
5424.78|3.359|on it and you're building out a data
5426.46|3.679|engine and you're actually making
5428.139|4.381|forward progress because that is the the
5430.139|3.881|sensor with the most bandwidth the most
5432.52|2.82|constraints on the world and you're
5434.02|3.42|investing fully into that and you can
5435.34|3.54|make that extremely good if you're uh
5437.44|4.38|you're only a finite amount of sort of
5438.88|6.359|spend of focus across different facets
5441.82|5.46|of the system and uh this kind of
5445.239|4.381|reminds me of Rich Sutton's a bitter
5447.28|3.78|lesson it just seems like simplifying
5449.62|3.9|the system yeah
5451.06|4.139|in the long run now of course you don't
5453.52|3.9|know what the long run it seems to be
5455.199|3.901|always the right solution yeah yes in
5457.42|3.84|that case it was 4rl but it seems to
5459.1|4.92|apply generally across all systems that
5461.26|4.5|do computation yeah so where uh what do
5464.02|2.82|you think about the lidar as a crutch
5465.76|4.26|debate
5466.84|4.2|uh the battle between point clouds and
5470.02|2.94|pixels
5471.04|3.599|yeah I think this debate is always like
5472.96|3.179|slightly confusing to me because it
5474.639|3.241|seems like the actual debate should be
5476.139|3.241|about like do you have the fleet or not
5477.88|3.54|that's like the really important thing
5479.38|4.259|about whether you can achieve a really
5481.42|4.739|good functioning of an AI system at this
5483.639|3.661|scale so data collection systems yeah do
5486.159|2.701|you have a fleet or not it's
5487.3|3.0|significantly more important whether you
5488.86|2.879|have lidar or not it's just another
5490.3|3.18|sensor
5491.739|4.201|um and uh
5493.48|5.1|yeah I think similar to the radar
5495.94|4.56|discussion basically I um
5498.58|4.92|but yeah I don't think it it um
5500.5|4.8|basically doesn't offer extra extra
5503.5|2.94|information is extremely costly it has
5505.3|2.879|all kinds of problems you have to worry
5506.44|3.239|about it you have to calibrate it Etc it
5508.179|3.901|creates bloat and entropy you have to be
5509.679|4.621|really sure that you need this uh this
5512.08|4.26|um sensor in this case I basically don't
5514.3|3.359|think you need it and I think honestly I
5516.34|3.12|will make a stronger statement I think
5517.659|3.301|the others some of the other uh
5519.46|4.44|companies are using it are probably
5520.96|6.3|going to drop it yeah so you have to
5523.9|6.6|consider the sensor in the full
5527.26|5.64|in considering can you build a big Fleet
5530.5|4.08|that collects a lot of data and can you
5532.9|4.14|integrate that sensor with that that
5534.58|4.38|data and that sensor into a data engine
5537.04|4.8|that's able to quickly find different
5538.96|4.86|parts of the data that then continuously
5541.84|3.54|improves whatever the model that you're
5543.82|4.26|using yeah another way to look at it is
5545.38|5.339|like vision is necessary in a sense that
5548.08|3.84|uh the drive the world is designed for
5550.719|4.201|human visual consumption so you need
5551.92|5.1|vision is necessary and then also it is
5554.92|3.54|sufficient because it has all the
5557.02|3.24|information that you that you need for
5558.46|3.42|driving and humans obviously is a vision
5560.26|2.939|to drive so it's both necessary and
5561.88|2.819|sufficient so you want to focus
5563.199|2.641|resources and you have to be really sure
5564.699|3.121|if you're going to bring in other
5565.84|4.02|sensors you could you could you could
5567.82|4.02|add sensors to Infinity at some point
5569.86|3.12|you need to draw the line and I think in
5571.84|4.14|this case you have to really consider
5572.98|5.04|the full cost of any One sensor that
5575.98|4.259|you're adopting and do you really need
5578.02|3.84|it and I think the answer in this case
5580.239|4.561|is no so what do you think about the
5581.86|5.94|idea of the that the other companies
5584.8|5.16|are forming high resolution maps and
5587.8|4.68|constraining heavily the geographic
5589.96|6.84|regions in which they operate is that
5592.48|6.719|approach not in your in your view
5596.8|4.26|um not going to scale over time to the
5599.199|3.421|entirety of the United States I think
5601.06|3.54|I'll take two as you mentioned like they
5602.62|3.9|pre-map all the environments and they
5604.6|3.96|need to refresh the map and they have a
5606.52|3.48|perfect centimeter level accuracy map of
5608.56|3.36|everywhere they're going to drive it's
5610.0|3.42|crazy how are you going to
5611.92|2.759|when we're talking about autonomy
5613.42|3.0|actually changing the world we're
5614.679|4.261|talking about the deployment
5616.42|4.5|on a on a global scale of autonomous
5618.94|3.719|systems for transportation and if you
5620.92|4.5|need to maintain a centimeter accurate
5622.659|4.261|map for Earth or like for many cities
5625.42|3.299|and keep them updated it's a huge
5626.92|2.819|dependency that you're taking on huge
5628.719|2.94|dependency
5629.739|3.181|it's a massive massive dependency and
5631.659|2.641|now you need to ask yourself do you
5632.92|3.54|really need it
5634.3|4.26|and humans don't need it
5636.46|4.199|um right so it's it's very useful to
5638.56|3.599|have a low-level map of like okay the
5640.659|3.241|connectivity of your road you know that
5642.159|2.821|there's a fork coming up when you drive
5643.9|2.22|an environment you sort of have that
5644.98|3.6|high level understanding it's like a
5646.12|4.92|small Google Map and Tesla uses Google
5648.58|4.98|Map like similar kind of resolution
5651.04|4.44|information in the system but it will
5653.56|3.72|not pre-map environments to send me a
5655.48|4.199|level accuracy it's a crutch it's a
5657.28|4.14|distraction it costs entropy and it
5659.679|3.0|diffuses the team it dilutes the team
5661.42|3.239|and you're not focusing on what's
5662.679|3.601|actually necessary which is the computer
5664.659|3.661|vision problem
5666.28|4.8|what did you learn about machine
5668.32|6.12|learning about engineering about life
5671.08|5.34|about yourself as one human being from
5674.44|3.54|working with Elon Musk
5676.42|3.54|I think the most I've learned is about
5677.98|4.14|how to sort of run organizations
5679.96|4.02|efficiently and how to
5682.12|4.38|create efficient organizations and how
5683.98|4.679|to fight entropy in an organization so
5686.5|4.92|human Engineering in the fight against
5688.659|5.281|entropy yeah there's a there's a I think
5691.42|4.38|Elon is a very efficient warrior in the
5693.94|3.9|fight against entropy in organizations
5695.8|5.48|what is the entropy in an organization
5697.84|7.92|look like exactly it's process it's
5701.28|6.1|it's process and inefficiencies and that
5705.76|3.0|kind of stuff yeah meetings he hates
5707.38|3.42|meetings he keeps telling people to skip
5708.76|3.72|meetings if they're not useful
5710.8|5.1|um he basically runs the world's biggest
5712.48|5.4|uh startups I would say uh Tesla SpaceX
5715.9|4.02|are the world's biggest startups Tesla
5717.88|3.779|actually has multiple startups I think
5719.92|4.02|it's better to look at it that way and
5721.659|5.401|so I think he's he's extremely good at
5723.94|4.92|uh at that and uh yeah he's a very good
5727.06|3.599|intuition for streamline processes
5728.86|4.74|making everything efficient uh best part
5730.659|5.401|is no part uh simplifying focusing
5733.6|4.74|um and just kind of removing barriers uh
5736.06|4.26|moving very quickly making big moves all
5738.34|4.56|this is a very startupy sort of seeming
5740.32|5.1|things but at scale so strong drive to
5742.9|3.9|simplify for me from your perspective I
5745.42|3.0|mean that
5746.8|3.48|um that also probably applies to just
5748.42|3.42|designing systems and machine learning
5750.28|3.0|and otherwise yeah like simplify
5751.84|3.42|simplify yes
5753.28|4.68|what do you think is the secret to
5755.26|5.18|maintaining the startup culture in a
5757.96|5.699|company that grows is there
5760.44|5.32|can you introspect that
5763.659|3.841|I do think you need someone in a
5765.76|4.2|powerful position with a big hammer like
5767.5|4.98|Elon who's like the cheerleader for that
5769.96|4.38|idea and ruthless ruthlessly pursues it
5772.48|4.28|if no one has a big enough Hammer
5774.34|5.52|everything turns into committees
5776.76|5.32|democracy within the company uh process
5779.86|4.68|talking to stakeholders decision making
5782.08|4.32|just everything just crumbles yeah if
5784.54|3.9|you have a big person who's also really
5786.4|4.98|smart and has a big hammer things move
5788.44|5.52|quickly so you said your favorite scene
5791.38|4.319|in interstellar is the intense docking
5793.96|3.98|scene with the AI and Cooper talking
5795.699|5.46|saying uh Cooper what are you doing
5797.94|4.38|docking it's not possible no it's
5801.159|3.781|necessary
5802.32|5.56|such a good line by the way just so many
5804.94|6.6|questions there why in AI
5807.88|4.56|in that scene presumably is supposed to
5811.54|2.639|be
5812.44|4.5|able to compute a lot more than the
5814.179|4.341|human is saying it's not optimal why the
5816.94|4.14|human I mean that's a movie but
5818.52|3.52|shouldn't they AI know much better than
5821.08|3.3|the human
5822.04|5.46|anyway uh what do you think is the value
5824.38|5.0|of setting seemingly impossible goals
5827.5|4.62|so like uh
5829.38|4.18|our initial intuition which seems like
5832.12|5.099|something that
5833.56|6.179|you have taken on that Elon espouses
5837.219|3.661|that where the initial intuition of the
5839.739|3.181|community might say this is very
5840.88|4.799|difficult and then you take it on anyway
5842.92|4.44|with a crazy deadline you're just from a
5845.679|2.421|human engineering perspective
5847.36|4.859|um
5848.1|5.86|uh have you seen the value of that
5852.219|3.781|I wouldn't say that setting impossible
5853.96|3.66|goals exactly is is a good idea but I
5856.0|4.32|think setting very ambitious goals is a
5857.62|4.86|good idea I think there's a what I call
5860.32|4.8|sublinear scaling of difficulty uh which
5862.48|6.239|means that 10x problems are not 10x hard
5865.12|6.42|usually 10x 10x harder problem is like 2
5868.719|4.141|or 3x harder to execute on because if
5871.54|3.599|you want to actually like if you want to
5872.86|3.779|improve the system by 10 it costs some
5875.139|3.901|amount of work and if you want to 10x
5876.639|4.141|improve the system it doesn't cost you
5879.04|2.88|know 100x amount of the work and it's
5880.78|2.82|because you fundamentally change the
5881.92|3.54|approach and it if you start with that
5883.6|3.66|constraint then some approaches are
5885.46|4.08|obviously dumb and not going to work and
5887.26|4.379|it forces you to reevaluate
5889.54|4.679|um and I think it's a very interesting
5891.639|4.621|way of approaching problem solving but
5894.219|3.901|it requires a weird kind of thinking
5896.26|6.0|it's just going back to your like PhD
5898.12|6.48|days it's like how do you think which
5902.26|6.78|ideas in in the machine Learning
5904.6|6.72|Community are solvable yes it's uh it
5909.04|4.02|requires what is that I mean there's the
5911.32|4.14|cliche of first prince people's thinking
5913.06|3.599|but like it requires to basically ignore
5915.46|3.179|what the community is saying because
5916.659|5.341|doesn't the community doesn't a
5918.639|6.54|community in science usually draw lines
5922.0|5.1|of what isn't isn't possible right and
5925.179|4.681|like it's very hard to break out of that
5927.1|4.079|without going crazy yep I mean I think a
5929.86|2.64|good example here is you know the Deep
5931.179|4.02|learning revolution in some sense
5932.5|4.62|because you could be in computer vision
5935.199|4.081|at that time when during the Deep
5937.12|4.079|learning sort of revolution of 2012 and
5939.28|4.26|so on uh you could be improving your
5941.199|4.141|computer vision stack by 10 or we can
5943.54|3.599|just be saying actually all this is
5945.34|3.24|useless and how do I do 10x better
5947.139|4.321|computer vision well it's not probably
5948.58|4.139|by tuning a hog feature detector I need
5951.46|2.4|a different approach
5952.719|4.681|um I need something that is scalable
5953.86|4.379|going back to uh Richard Sutton's um and
5957.4|3.839|understanding sort of like the
5958.239|4.141|philosophy of the uh bitter lesson and
5961.239|2.701|then being like actually I need a much
5962.38|3.6|more scalable system like a neural
5963.94|3.48|network that in principle works and then
5965.98|3.0|having some deep Believers that can
5967.42|6.14|actually execute on that mission and
5968.98|4.58|make it work so that's the 10x solution
5974.02|4.32|what do you think is the timeline to
5976.06|6.36|solve the problem of autonomous driving
5978.34|5.7|this still in part an open question
5982.42|3.42|yeah I think the tough thing with
5984.04|3.599|timelines of self-driving obviously is
5985.84|5.1|that no one has created self-driving
5987.639|4.681|yeah so it's not like what do you think
5990.94|2.759|is a timeline to build this bridge well
5992.32|3.96|we've built million Bridges before
5993.699|4.621|here's how long that takes it's it you
5996.28|5.34|know it's uh no one has built autonomy
5998.32|4.859|it's not obvious uh some parts turn out
6001.62|3.059|to be much easier than others so it's
6003.179|4.081|really hard to forecast you do your best
6004.679|3.96|based on trend lines and so on and based
6007.26|2.76|on intuition but that's why
6008.639|3.481|fundamentally it's just really hard to
6010.02|4.98|forecast this no one has even still like
6012.12|4.38|being inside of it is hard to uh to do
6015.0|2.639|yes some things turn out to be much
6016.5|2.219|harder and some things turn out to be
6017.639|4.261|much easier
6018.719|4.92|do you try to avoid making forecasts
6021.9|4.319|because like Elon doesn't avoid them
6023.639|5.881|right and heads of car companies in the
6026.219|5.281|past have not avoided it either uh Ford
6029.52|4.02|and other places have made predictions
6031.5|5.58|that we're going to solve at level four
6033.54|4.98|driving by 2020 2021 whatever and now
6037.08|2.579|they're all kind of Backtrack on that
6038.52|3.719|prediction
6039.659|5.161|IU as a
6042.239|5.4|as an AI person
6044.82|5.16|do you free yourself privately make
6047.639|5.04|predictions or do they get in the way of
6049.98|3.78|like your actual ability to think about
6052.679|3.301|a thing
6053.76|4.26|yeah I would say like what's easy to say
6055.98|3.239|is that this problem is tractable and
6058.02|3.42|that's an easy prediction to make
6059.219|3.601|extractable it's going to work yes it's
6061.44|2.88|just really hard some things turn out to
6062.82|4.379|be harder than some things turn out to
6064.32|5.399|be easier uh so uh but it definitely
6067.199|3.901|feels tractable and it feels like at
6069.719|3.181|least the team at Tesla which is what I
6071.1|4.2|saw internally is definitely on track to
6072.9|5.339|that how do you form
6075.3|4.08|a uh strong representation that allows
6078.239|3.661|you to make a prediction about
6079.38|5.16|tractability so like you're the leader
6081.9|5.22|of a lot a lot of humans
6084.54|3.78|you have to kind of say this is actually
6087.12|3.599|possible
6088.32|4.319|like how do you build up that intuition
6090.719|4.861|it doesn't have to be even driving it
6092.639|4.861|could be other tasks it could be um and
6095.58|2.82|I wonder what difficult tasks did you
6097.5|2.179|work on in your life I mean
6098.4|3.779|classification
6099.679|4.781|achieving certain just an image that
6102.179|5.52|certain level of superhuman level
6104.46|6.3|performance yeah expert intuition
6107.699|4.92|it's just intuition it's belief
6110.76|3.54|so just like thinking about it long
6112.619|3.661|enough like studying looking at sample
6114.3|4.2|data like you said driving
6116.28|4.02|uh my intuition has really flawed on
6118.5|4.199|this like I don't have a good intuition
6120.3|5.399|about tractability it could be either it
6122.699|6.42|could be anything it could be solvable
6125.699|6.42|like uh you know the driving task could
6129.119|5.701|could be simplified into something quite
6132.119|4.921|trivial like uh the solution to the
6134.82|3.899|problem would be quite trivial and at
6137.04|3.24|scale more and more cars driving
6138.719|3.721|perfectly
6140.28|4.08|might make the problem much easier Yeah
6142.44|4.62|the more cars you have driving like
6144.36|4.74|people learn how to drive correctly not
6147.06|5.46|correctly but in a way that's more
6149.1|5.94|optimal for a heterogeneous system of
6152.52|4.139|autonomous and semi-autonomous and
6155.04|4.5|manually driven cars that could change
6156.659|4.621|stuff then again also I've spent a
6159.54|4.619|ridiculous number of hours just staring
6161.28|6.12|at pedestrians crossing streets thinking
6164.159|6.141|about humans and it feels like the way
6167.4|5.759|we use our eye contact
6170.3|4.72|it sends really strong signals and
6173.159|3.48|there's certain quirks and edge cases of
6175.02|3.54|behavior and of course a lot of the
6176.639|4.5|fatalities that happen have to do with
6178.56|4.38|drunk driving and
6181.139|4.08|um both on The Pedestrian side and the
6182.94|3.66|driver's side so there's that problem of
6185.219|3.541|driving at night and all that kind of
6186.6|3.599|yeah so I wonder you know it's like the
6188.76|3.359|space
6190.199|4.201|of possible solution to autonomous
6192.119|3.481|driving includes so many human factor
6194.4|3.42|issues
6195.6|4.619|that it's almost impossible to predict
6197.82|4.44|there could be super clean nice
6200.219|3.841|Solutions yeah I would say definitely
6202.26|4.32|like to use a game analogy there's some
6204.06|4.98|fog of War but you definitely also see
6206.58|3.84|the frontier of improvement and you can
6209.04|3.599|measure historically how much you've
6210.42|4.44|made progress and I think for example at
6212.639|4.201|least what I've seen in uh roughly five
6214.86|4.68|years at Tesla when I joined it barely
6216.84|4.56|kept laying on the highway I think going
6219.54|3.78|up from Palo Alto to SF was like three
6221.4|3.719|or four interventions anytime the road
6223.32|4.02|would do anything geometrically or turn
6225.119|3.481|too much it would just like not work and
6227.34|3.06|so going from that to like a pretty
6228.6|3.36|competent system in five years and
6230.4|3.54|seeing what happens also under the hood
6231.96|3.179|and what the scale which the team is
6233.94|4.199|operating now with respect to data and
6235.139|4.321|compute and everything else uh is just a
6238.139|4.261|massive progress
6239.46|5.52|so there's a you're climbing a mountain
6242.4|4.259|and it's fog but you're making a lot of
6244.98|3.179|progress fog you're making progress and
6246.659|2.52|you see what the next directions are and
6248.159|3.06|you're looking at some of the remaining
6249.179|3.54|challenges and they're not like uh
6251.219|2.761|they're not perturbing you and they're
6252.719|3.601|not changing your philosophy and you're
6253.98|3.78|not contorting yourself you're like
6256.32|2.7|actually these are the things that we
6257.76|2.879|still need to do yeah the fundamental
6259.02|3.3|components of solving the problems seem
6260.639|3.841|to be there for the data engine to the
6262.32|3.66|compute to the the computer on the car
6264.48|2.699|to the compute for the training all that
6265.98|2.699|kind of stuff
6267.179|3.361|so you've done
6268.679|4.201|uh over the years you've been a test
6270.54|4.86|you've done a lot of amazing uh
6272.88|3.9|breakthrough ideas and Engineering all
6275.4|3.36|of it
6276.78|4.62|um from the data engine to The Human
6278.76|6.06|Side all of it can you speak to why you
6281.4|5.52|chose to leave Tesla basically as I
6284.82|4.14|described that ran I think over time
6286.92|4.199|during those five years I've kind of uh
6288.96|4.44|gotten myself into a little bit of a
6291.119|3.421|managerial position most of my days were
6293.4|3.9|you know meetings and growing the
6294.54|4.8|organization and making decisions about
6297.3|3.96|sort of high level strategic decisions
6299.34|4.62|about the team and what it should be
6301.26|4.439|working on and so on and uh
6303.96|4.199|it's kind of like a corporate executive
6305.699|4.261|role and I can do it I think I'm okay at
6308.159|4.921|it but it's not like fundamentally what
6309.96|4.98|I what I enjoy and so I think uh when I
6313.08|3.48|joined uh there was no computer vision
6314.94|3.36|team because Tesla was just going from
6316.56|2.76|the transition of using mobileye a
6318.3|2.58|third-party vendor for all of its
6319.32|3.18|computer vision to having to build its
6320.88|2.819|computer vision system so when I showed
6322.5|3.239|up there were two people training deep
6323.699|4.261|neural networks and they were training
6325.739|4.341|them at a computer at their at their
6327.96|4.86|legs like uh
6330.08|4.3|kind of basic classification task yeah
6332.82|3.54|and so
6334.38|3.72|I kind of like grew that into what I
6336.36|3.54|think is a fairly respectable deep
6338.1|3.78|learning team a massive compute cluster
6339.9|4.68|a very good um data annotation
6341.88|4.02|organization and uh I was very happy
6344.58|3.539|with where that was it became quite
6345.9|4.56|autonomous and so I kind of stepped away
6348.119|4.08|and I uh you know I'm very excited to do
6350.46|4.08|much more technical things again
6352.199|4.321|yeah and kind of like we focus on AGI
6354.54|3.599|what was this soul searching like
6356.52|3.599|because you took a little time off and
6358.139|4.261|think like what um how many mushrooms
6360.119|3.961|did you take no I'm just uh I mean what
6362.4|4.92|what was going through your mind the
6364.08|5.46|human lifetime is finite yeah he did a
6367.32|3.859|few incredible things you're you're one
6369.54|4.56|of the best teachers of AI in the world
6371.179|4.421|you're one of the best and I don't mean
6374.1|4.619|that I mean that in the best possible
6375.6|5.82|way you're one of the best tinkerers in
6378.719|4.98|the AI world meaning like understanding
6381.42|4.259|the fundamental fundamentals of how
6383.699|4.02|something works by building it from
6385.679|4.381|scratch and playing with it with the
6387.719|3.9|basic intuitions it's like Einstein
6390.06|3.78|feinmen were all really good at this
6391.619|4.201|kind of stuff like a small example of a
6393.84|4.319|thing to to play with it to try to
6395.82|5.339|understand it uh so that and obviously
6398.159|5.46|now with us that you help build a team
6401.159|4.921|of machine learning
6403.619|3.781|um uh like engineers and a system that
6406.08|3.539|actually accomplishes something in the
6407.4|4.14|real world so given all that like what
6409.619|4.08|was the soul searching like
6411.54|4.56|well it was hard because obviously I
6413.699|5.52|love the company a lot and I love I love
6416.1|4.619|Elon I love Tesla I want um
6419.219|2.881|it was hard to leave I love the team
6420.719|3.241|basically
6422.1|3.72|um but
6423.96|3.12|yeah I think actually I would
6425.82|3.06|potentially like interested in
6427.08|4.74|revisiting it maybe coming back at some
6428.88|5.52|point uh working in Optimus working in
6431.82|4.68|AGI at Tesla uh I think Tesla is going
6434.4|3.48|to do incredible things it's basically
6436.5|4.739|like
6437.88|5.46|uh it's a massive large-scale robotics
6441.239|3.361|kind of company with a ton of In-House
6443.34|3.66|talent for doing really incredible
6444.6|5.099|things and I think uh
6447.0|4.5|human robots are going to be amazing I
6449.699|3.0|think autonomous transportation is going
6451.5|3.119|to be amazing all this is happening at
6452.699|3.601|Tesla so I think it's just a really
6454.619|3.241|amazing organization so being part of it
6456.3|3.96|and helping it along I think was very
6457.86|3.359|basically I enjoyed that a lot yeah it
6460.26|3.0|was basically difficult for those
6461.219|3.96|reasons because I love the company uh
6463.26|3.84|but you know I'm happy to potentially at
6465.179|3.421|some point come back for act two but I
6467.1|4.44|felt like at this stage
6468.6|5.34|I built the team it felt autonomous and
6471.54|3.78|uh I became a manager and I wanted to do
6473.94|3.96|a lot more technical stuff I wanted to
6475.32|4.62|learn stuff I wanted to teach stuff and
6477.9|3.66|uh I just kind of felt like it was a
6479.94|4.38|good time for for a change of pace a
6481.56|4.559|little bit what do you think is uh the
6484.32|4.02|best movie sequel of all time speaking
6486.119|5.341|of part two because like because most of
6488.34|5.52|them suck in movie sequels yeah and you
6491.46|4.98|tweet about movies so just in a tiny
6493.86|4.44|tangent is there what's your what was
6496.44|4.199|like a favorite movie sequel
6498.3|3.6|Godfather Part Two
6500.639|2.641|um are you a fan of Godfather because
6501.9|2.94|you didn't even tweet or mention the
6503.28|3.24|Godfather yeah I don't love that movie I
6504.84|3.66|know it hasn't edit that out we're gonna
6506.52|4.02|edit out the hate towards the Godfather
6508.5|3.84|how dare you just I think I will make a
6510.54|3.179|strong statement I don't know why I
6512.34|5.04|don't know why but I basically don't
6513.719|5.161|like any movie before 1995
6517.38|4.14|something like that didn't you mention
6518.88|6.54|Terminator two okay okay that's like uh
6521.52|6.24|Terminator 2 was a little bit later 1990
6525.42|4.02|no I think Terminator 2 was a name I
6527.76|3.78|like Terminator one as well so okay so
6529.44|3.54|like a few exceptions but by and large
6531.54|4.679|for some reason I don't like movies
6532.98|5.34|before 1995 or something they feel very
6536.219|4.321|slow the camera is like zoomed out it's
6538.32|4.62|boring it's kind of naive it's kind of
6540.54|4.679|weird and also Terminator was very much
6542.94|3.96|ahead of its time yes and The Godfather
6545.219|4.341|there's like no AGI
6546.9|5.279|[Laughter]
6549.56|4.599|I mean but you have Good Will Hunting
6552.179|3.901|was one of the movies you mentioned and
6554.159|3.421|that doesn't have any AGI either I guess
6556.08|3.36|that's mathematics yeah I guess
6557.58|4.5|occasionally I do enjoy movies that
6559.44|5.52|don't feature or like Anchorman that has
6562.08|5.159|no that's the increment it's so good I
6564.96|4.5|don't understand
6567.239|4.081|um speaking of AGI because I don't
6569.46|4.32|understand why Will Ferrell is so funny
6571.32|4.379|it doesn't make sense it doesn't compute
6573.78|3.78|there's just something about him and
6575.699|3.54|he's a singular human because you don't
6577.56|3.48|get that many comedies
6579.239|4.201|these days and I wonder if it has to do
6581.04|4.079|about the culture uh or the like the
6583.44|3.42|machine of Hollywood or does it have to
6585.119|3.661|do with just we got lucky with certain
6586.86|5.42|people and comedy it came together
6588.78|6.12|because he is a singular human
6592.28|4.66|that was a ridiculous tangent I
6594.9|4.259|apologize but you mentioned humanoid
6596.94|4.44|robot so what do you think about Optimus
6599.159|4.681|about Tesla bot do you think we'll have
6601.38|5.819|robots in the factory in in the home in
6603.84|4.5|10 20 30 40 50 years yeah I think it's a
6607.199|2.821|very hard project I think it's going to
6608.34|4.14|take a while but who else is going to
6610.02|3.9|build humano robots at scale yeah and I
6612.48|2.759|think it is a very good form factor to
6613.92|3.18|go after because like I mentioned the
6615.239|3.48|the world is designed for humanoid form
6617.1|3.18|factor these things would be able to
6618.719|3.781|operate our machines they would be able
6620.28|4.74|to sit down in chairs uh potentially
6622.5|3.9|even drive cars uh basically the world
6625.02|3.179|is designed for humans that's the form
6626.4|4.08|factor you want to invest into and make
6628.199|3.42|work over time uh I think you know
6630.48|3.179|there's another school of thought which
6631.619|3.661|is okay pick a problem and design a
6633.659|2.821|robot to it but actually designing a
6635.28|2.879|robot and getting a whole data engine
6636.48|3.54|and everything behind it to work is
6638.159|2.821|actually an incredibly hard problem so
6640.02|3.48|it makes sense to go after General
6640.98|4.199|interfaces that uh okay they are not
6643.5|3.78|perfect for any one given task but they
6645.179|4.56|actually have the generality of just
6647.28|4.68|with a prompt with English able to do
6649.739|4.92|something across and so I think it makes
6651.96|4.32|a lot of sense to go after a general uh
6654.659|4.201|interface
6656.28|4.02|um in the physical world and I think
6658.86|4.02|it's a very difficult project I think
6660.3|4.26|it's going to take time but I see no
6662.88|2.759|other no other company that can execute
6664.56|3.84|on that Vision I think it's going to be
6665.639|4.201|amazing like uh basically physical labor
6668.4|5.339|like if you think transportation is a
6669.84|6.06|large Market try physical labor insane
6673.739|4.201|well but it's not just physical labor to
6675.9|4.5|me the thing that's also exciting is the
6677.94|4.14|social robotics so the the relationship
6680.4|4.14|we'll have on different levels with
6682.08|5.94|those robots that's why I was really
6684.54|5.78|excited to see Optimus like um people
6688.02|6.119|have criticized me for the excitement
6690.32|6.339|but I've I've worked with uh uh a lot of
6694.139|5.881|research Labs that do humanoid legged
6696.659|4.56|robots Boston Dynamics unitary a lot
6700.02|5.04|there's a lot of companies that do
6701.219|8.101|legged robots but that's the the
6705.06|7.559|Elegance of the movement is a tiny tiny
6709.32|5.28|part of the big picture so integrating
6712.619|5.1|the two big exciting things to me about
6714.6|4.98|Tesla doing humanoid or any Lego robots
6717.719|4.381|is
6719.58|6.0|clearly integrating it into the data
6722.1|5.22|engine so the the data engine aspect so
6725.58|3.539|the actual intelligence for the
6727.32|3.299|perception and the and the control and
6729.119|3.6|the planning and all that kind of stuff
6730.619|3.841|integrating into this huge the fleet
6732.719|5.221|that you mentioned right
6734.46|5.279|um and then speaking of Fleet the second
6737.94|2.699|thing is the mass manufacturers Just
6739.739|3.681|knowing
6740.639|6.6|uh culturally
6743.42|6.4|uh driving towards a simple robot that's
6747.239|4.021|cheap to produce at scale yeah and doing
6749.82|3.18|that well having experience to do that
6751.26|4.14|well that changes everything that's why
6753.0|4.26|that's a very different culture and
6755.4|4.98|style than Boston Dynamics who by the
6757.26|6.66|way those those robots are just the the
6760.38|4.98|way they move it's uh like it'll be a
6763.92|3.54|very long time before Tesla could
6765.36|4.319|achieve the smoothness of movement but
6767.46|4.679|that's not what it's about it's it's
6769.679|3.901|about uh it's about the entirety of the
6772.139|3.241|system like we talked about the data
6773.58|3.9|engine and the fleet that's super
6775.38|4.739|exciting even the initial sort of models
6777.48|5.28|uh but that too was really surprising
6780.119|4.861|that in a few months you can get a
6782.76|4.2|prototype yep and the reason that
6784.98|3.78|happened very quickly is as you alluded
6786.96|3.48|to there's a ton of copy based from
6788.76|3.359|what's happening in the autopilot yes a
6790.44|3.299|lot the amount of expertise that like
6792.119|3.301|came out of the Woodworks at Tesla for
6793.739|4.681|building the human robot was incredible
6795.42|5.16|to see like basically Elon said at one
6798.42|4.38|point we're doing this and then
6800.58|3.96|next day basically like all these CAD
6802.8|2.939|models started to appear and people talk
6804.54|3.48|about like the supply chain and
6805.739|3.541|Manufacturing and uh people showed up
6808.02|3.24|with like screwdrivers and everything
6809.28|3.359|like the other day and started to like
6811.26|2.76|put together the body and I was like
6812.639|3.181|whoa like all these people exist at
6814.02|2.82|Tesla and fundamentally building a car
6815.82|2.819|is actually not that different from
6816.84|4.319|building a robot the same and that is
6818.639|4.441|true uh not just for uh the hardware
6821.159|4.701|pieces and also let's not forget
6823.08|5.7|Hardware not just for a demo but
6825.86|4.839|manufacturing of that Hardware at scale
6828.78|4.5|is like a whole different thing but for
6830.699|4.94|software as well basically this robot
6833.28|5.339|currently thinks it's a car
6835.639|5.321|uh it's gonna have a midlife crisis at
6838.619|4.02|some point it thinks it's a car
6840.96|2.699|um some of the earlier demos actually we
6842.639|2.401|were talking about potentially doing
6843.659|2.881|them outside in the parking lot because
6845.04|3.56|that's where all of the computer vision
6846.54|5.099|that was like working out of the box
6848.6|4.539|instead of like in inside
6851.639|3.361|um but all the operating system
6853.139|3.6|everything just copy pastes uh computer
6855.0|2.88|vision mostly copy paste I mean you have
6856.739|2.221|to retrain the neural Nets but the
6857.88|3.0|approach and everything in data engine
6858.96|3.42|and offline trackers and the way we go
6860.88|3.18|about the occupancy tracker and so on
6862.38|4.14|everything copy paste you just need to
6864.06|3.84|retrain the neural Lots uh and then the
6866.52|3.48|planning control of course has to change
6867.9|3.839|quite a bit but there's a ton of copy
6870.0|3.78|paste from what's happening at Tesla and
6871.739|3.48|so if you were to if you were to go with
6873.78|3.48|goal of like okay let's build a million
6875.219|4.201|human robots and you're not Tesla that's
6877.26|3.84|that's a lot to ask if you're a Tesla
6879.42|3.96|it's actually like
6881.1|4.139|it's not it's not that crazy and then
6883.38|3.239|the the follow-up question is and how
6885.239|3.96|difficult just like we're driving how
6886.619|4.321|difficult is the manipulation task uh
6889.199|3.061|such that it can have an impact at scale
6890.94|3.48|I think
6892.26|5.939|depending on the context the really nice
6894.42|5.34|thing about robotics is the um unless
6898.199|3.681|you do a manufacturing that kind of
6899.76|4.979|stuff is there's more room for error
6901.88|5.38|driving is so safety critical and so
6904.739|5.581|that and also time critical robot is
6907.26|5.28|allowed to move slower which is nice yes
6910.32|3.78|I think it's going to take a long time
6912.54|3.179|but the way you want to structure the
6914.1|3.3|development is you need to say okay it's
6915.719|5.221|going to take a long time how can I set
6917.4|4.739|up the uh product development roadmap so
6920.94|3.06|that I'm making Revenue along the way
6922.139|3.121|I'm not setting myself up for a zero one
6924.0|2.76|loss function where it doesn't work
6925.26|3.18|until it works you don't want to be in
6926.76|3.54|that position you want to make it useful
6928.44|6.239|almost immediately and then you want to
6930.3|5.64|slowly deploy it uh and uh at scale and
6934.679|3.421|you want to set up your data engine your
6935.94|4.64|improvement Loops the Telemetry the
6938.1|4.619|evaluation the harness and everything
6940.58|3.22|and you want to improve the product over
6942.719|2.641|time incorrectly and you're making
6943.8|3.359|Revenue along the way that's extremely
6945.36|4.2|important because otherwise you cannot
6947.159|3.841|build these these uh large undertakings
6949.56|3.059|just like don't make sense economically
6951.0|2.88|and also from the point of view of the
6952.619|3.12|team working on it they need the
6953.88|4.02|dopamine along the way they're not just
6955.739|3.96|going to make a promise about this being
6957.9|3.6|useful this is going to change the world
6959.699|3.42|in 10 years when it works this is not
6961.5|3.179|where you want to be you want to be in a
6963.119|4.261|place like I think autopilot is today
6964.679|4.98|where it's offering increased safety and
6967.38|4.259|um and uh convenience of driving today
6969.659|4.261|people pay for it people like it people
6971.639|3.301|purchase it and then you also have the
6973.92|2.279|greater mission that you're working
6974.94|3.36|towards
6976.199|4.44|and you see that so the dopamine for the
6978.3|4.859|team that that was a source of Happiness
6980.639|4.441|yes you're deploying this people like it
6983.159|3.241|people drive it people pay for it they
6985.08|3.659|care about it there's all these YouTube
6986.4|3.6|videos your grandma drives it she gives
6988.739|3.42|you feedback people like it people
6990.0|4.26|engage with it you engage with it huge
6992.159|4.321|do uh people that drive Teslas like
6994.26|6.72|recognize you and give you love like uh
6996.48|6.179|like hey thanks for the for the this
7000.98|3.06|nice feature that it's doing yeah I
7002.659|2.52|think the tricky thing is like some
7004.04|2.699|people really love you some people
7005.179|2.581|unfortunately like you're working on
7006.739|3.181|something that you think is extremely
7007.76|4.08|valuable useful Etc some people do hate
7009.92|4.14|you there's a lot of people who like
7011.84|4.379|hate me and the team and whatever the
7014.06|4.8|whole project and I think they have
7016.219|4.621|Tesla drivers uh many cases they're not
7018.86|6.12|actually yeah that's that's actually
7020.84|6.0|makes me sad about humans or the current
7024.98|3.48|the ways that humans interact I think
7026.84|3.06|that's actually fixable I think humans
7028.46|3.48|want to be good to each other I think
7029.9|4.5|Twitter and social media is part of the
7031.94|5.1|mechanism that actually somehow makes
7034.4|5.759|the negativity more viral but it doesn't
7037.04|5.579|deserve like disproportionately uh add
7040.159|4.921|of like a viral viral boost yeah
7042.619|5.341|negativity but like I wish people would
7045.08|5.639|just get excited about uh so suppress
7047.96|4.8|some of the jealousy some of the ego and
7050.719|4.081|just get excited for others and then
7052.76|3.479|there's a Karma aspect to that you get
7054.8|3.72|excited for others they'll get excited
7056.239|4.081|for you same thing in Academia if you're
7058.52|4.5|not careful there's a like a dynamical
7060.32|4.5|system there if you if you think of in
7063.02|4.92|silos and get jealous of somebody else
7064.82|6.0|being successful that actually perhaps
7067.94|4.62|counterintuitively uh leads the less
7070.82|4.2|productivity of you as a community and
7072.56|5.76|you individually I feel like if you keep
7075.02|5.639|celebrating others that actually makes
7078.32|4.2|you more successful yeah I think people
7080.659|3.901|haven't in depending on the industry
7082.52|3.3|haven't quite learned that yet yeah some
7084.56|2.76|people are also very negative and very
7085.82|3.359|vocal so they're very prominently
7087.32|3.72|featured but actually there's a ton of
7089.179|3.901|people who are cheerleaders but they're
7091.04|4.44|silent cheerlead cheerleaders and uh
7093.08|3.72|when you talk to people just in the
7095.48|2.639|world they will all tell you it's
7096.8|2.64|amazing it's great especially like
7098.119|2.701|people who understand how difficult it
7099.44|2.759|is to get this stuff working like people
7100.82|3.48|who have built products and makers
7102.199|4.561|entrepreneur entrepreneurs like make
7104.3|4.98|making this work and changing something
7106.76|5.1|is is incredibly hard those people are
7109.28|4.08|more likely to cheerlead you well one of
7111.86|3.54|the things that makes me sad is some
7113.36|3.359|folks in the robotics Community uh don't
7115.4|3.299|do the cheerleading and they should
7116.719|3.121|there's uh because they know how
7118.699|2.641|difficult it is well they actually
7119.84|3.899|sometimes don't know how difficult it is
7121.34|4.44|to create a product at scale right they
7123.739|3.301|actually deploy in the real world a lot
7125.78|4.5|of the
7127.04|6.84|development of robots and AI systems is
7130.28|4.859|done on very specific small benchmarks
7133.88|2.64|um and as opposed to real world
7135.139|3.421|conditions yes
7136.52|4.199|yeah I think it's really hard to work on
7138.56|3.72|robotics in academic setting or AI
7140.719|6.601|systems that apply in the real world you
7142.28|7.5|you've criticized you uh flourished and
7147.32|4.56|loved for time the imagenet the famed
7149.78|5.899|image in that data set and I've recently
7151.88|7.259|had some words uh of criticism that the
7155.679|5.02|academic research ml Community gives a
7159.139|3.721|little too much love still to the
7160.699|4.141|imagenet or like those kinds of
7162.86|3.779|benchmarks can you speak to the
7164.84|5.399|strengths and weaknesses of data sets
7166.639|5.161|used in machine learning research
7170.239|4.321|actually I don't know that I recall the
7171.8|4.74|specific instance where I was uh unhappy
7174.56|4.86|or criticizing imagenet I think imagenet
7176.54|5.28|has been extremely valuable uh it was
7179.42|4.56|basically a benchmark that allowed the
7181.82|3.66|Deep Learning Community to demonstrate
7183.98|4.679|that deep neural networks actually work
7185.48|5.88|it was uh there's a massive value in
7188.659|4.5|that um so I think imagenet was useful
7191.36|4.14|but um basically it's become a bit of an
7193.159|4.861|eminist at this point so eminist is like
7195.5|3.9|the 228 by 28 grayscale digits there's
7198.02|3.659|kind of a joke data set that everyone
7199.4|4.08|like just crushes if there's no Papers
7201.679|4.081|written on MNS though right maybe they
7203.48|4.679|should have strong papers like papers
7205.76|3.72|that focus on like how do we learn with
7208.159|2.221|a small amount of data that kind of
7209.48|2.4|stuff yeah I could see that being
7210.38|2.88|helpful but not in sort of like Mainline
7211.88|3.359|computer vision research anymore of
7213.26|3.419|course I think the way I've heard you
7215.239|3.541|somewhere maybe I'm just imagining
7216.679|3.48|things but I think you said like image
7218.78|2.819|that was a huge contribution to the
7220.159|3.121|community for a long time and now it's
7221.599|3.301|time to move past those kinds of well
7223.28|3.66|image that has been crushed I mean you
7224.9|3.42|know the error rates are
7226.94|4.14|uh
7228.32|5.76|yeah we're getting like 90 accuracy in
7231.08|5.36|in one thousand classification way uh
7234.08|5.28|prediction and I've seen those images
7236.44|4.239|and it's like really high that's really
7239.36|3.779|that's really good if I remember
7240.679|4.681|correctly the top five error rate is now
7243.139|4.02|like one percent or something given your
7245.36|3.48|experience with a gigantic real world
7247.159|3.301|data set would you like to see
7248.84|3.54|benchmarks move in certain directions
7250.46|3.6|that the research Community uses
7252.38|3.6|unfortunately I don't think academics
7254.06|3.24|currently have the next imagenet uh
7255.98|3.0|We've obviously I think we've crushed
7257.3|4.919|mnist we've basically kind of crushed
7258.98|4.98|imagenet uh and there's no next sort of
7262.219|3.96|big Benchmark that the entire Community
7263.96|2.94|rallies behind and uses
7266.179|2.401|um
7266.9|3.779|you know for further development of
7268.58|4.44|these networks uh yeah what it takes for
7270.679|3.901|data set to Captivate the imagination of
7273.02|4.38|everybody like where they all get behind
7274.58|4.92|it that that could also need like a
7277.4|3.6|viral like a leader right you know
7279.5|4.56|somebody with popularity I mean that
7281.0|5.28|yeah why did image of that take off
7284.06|3.539|is there or is it just the accident of
7286.28|4.08|History it was the right amount of
7287.599|5.161|difficult uh it was the right amount of
7290.36|4.2|difficult and simple and uh interesting
7292.76|3.3|enough it just kind of like it was it
7294.56|2.88|was the right time for that kind of a
7296.06|3.3|data set
7297.44|5.04|question from Reddit
7299.36|5.04|uh what are your thoughts on the role
7302.48|3.42|that synthetic data and game engines
7304.4|3.779|will play in the future of neural net
7305.9|3.42|model development
7308.179|4.861|I think
7309.32|6.359|um as neural Nets converge to humans
7313.04|3.84|uh the value of simulation to neural
7315.679|3.841|Nets will be similar to value of
7316.88|5.4|simulation to humans
7319.52|4.199|so people use simulation for uh
7322.28|3.8|people use simulation because they can
7323.719|4.321|learn something in that kind of a system
7326.08|3.099|and without having to actually
7328.04|2.52|experience it
7329.179|3.96|um but are you referring to the
7330.56|4.86|simulation we're doing our head no sorry
7333.139|5.221|simulation I mean like video games or uh
7335.42|5.219|you know other forms of simulation for
7338.36|3.96|various professionals well so let me
7340.639|3.861|push back on that because maybe their
7342.32|4.919|simulation that we do in our heads like
7344.5|4.78|simulate if I do this
7347.239|3.781|what do I think will happen Okay that's
7349.28|2.939|like internal simulation yeah internal
7351.02|2.88|isn't that what we're doing let's
7352.219|3.0|assuming before we act oh yeah but
7353.9|2.699|that's independent from like the use of
7355.219|3.42|uh simulation in the sense of like
7356.599|4.201|computer games or using simulation for
7358.639|3.721|training set creation or you know is it
7360.8|3.72|independent or is it just Loosely
7362.36|5.299|correlated because like uh
7364.52|5.4|isn't that useful to do like um
7367.659|4.301|counterfactual or like Edge case
7369.92|3.66|simulation to like
7371.96|2.88|you know what happens if there's a
7373.58|3.36|nuclear war
7374.84|4.14|what happens if there's you know like
7376.94|3.179|those kinds of things yeah that's a
7378.98|3.0|different simulation from like Unreal
7380.119|3.661|Engine that's how I interpreted the
7381.98|4.34|question uh so like
7383.78|5.339|simulation of the average case
7386.32|5.2|is that what's Unreal Engine what what
7389.119|4.1|what what what do you mean by Unreal
7391.52|4.199|Engine so
7393.219|4.0|simulating a world yeah physics of that
7395.719|3.48|world
7397.219|4.98|why is that different like because you
7399.199|4.5|also can add Behavior to that world and
7402.199|3.96|you can try all kinds of stuff right
7403.699|4.561|like you could throw all kinds of weird
7406.159|4.44|things into it so Unreal Engine is not
7408.26|3.899|just about similar I mean I guess it is
7410.599|3.781|about submitting the physics of the
7412.159|3.0|world it's also doing something with
7414.38|2.819|that
7415.159|3.54|yeah the graphics the physics and the
7417.199|3.241|Agents that you put into the environment
7418.699|3.42|and stuff like that yeah see I think you
7420.44|4.56|I feel like you said that it's not that
7422.119|5.161|important I guess for the future of AI
7425.0|4.32|development is that is that correct to
7427.28|4.919|interpret you that way uh I think
7429.32|5.279|humans use uh simulators
7432.199|4.02|for um humans use simulators and they
7434.599|4.321|find them useful and so computers will
7436.219|4.681|use simulators and find them useful
7438.92|3.719|okay so you're saying it's not I I don't
7440.9|3.299|use simulators very often I play a video
7442.639|4.02|game every once in a while but I don't
7444.199|4.621|think I derive any wisdom about my own
7446.659|5.04|existence from from those video games
7448.82|5.94|it's a momentary escape from reality
7451.699|4.92|versus a source of wisdom about reality
7454.76|3.899|so I don't so I think that's a very
7456.619|3.421|polite way of saying simulation is not
7458.659|3.121|that useful
7460.04|4.02|yeah maybe maybe not I don't see it as
7461.78|4.26|like a fundamental really important part
7464.06|4.74|of like training neural Nets currently
7466.04|4.74|uh but I think uh as neural Nets become
7468.8|4.56|more and more powerful I think you will
7470.78|5.819|need fewer examples to train additional
7473.36|4.799|behaviors and uh simulation is of course
7476.599|2.761|there's a domain Gap in a simulation
7478.159|3.48|that's not the real world there's
7479.36|4.62|slightly something different but uh with
7481.639|4.08|a powerful enough neural net uh you need
7483.98|3.0|um The Domain Gap can be bigger I think
7485.719|2.581|because neural network will sort of
7486.98|3.0|understand that even though it's not the
7488.3|3.0|real world it like has all this high
7489.98|3.119|level structure that I'm supposed to be
7491.3|2.879|able to learn from so then you'll know
7493.099|4.08|we'll actually
7494.179|6.121|yeah you'll be able to Leverage
7497.179|5.281|the synthetic data better yes by closing
7500.3|5.339|the get better understanding in which
7502.46|5.34|ways this is not real data exactly
7505.639|4.02|uh right to do better questions next
7507.8|5.78|time that was that was a question but
7509.659|3.921|I'm just kidding all right um
7514.159|4.681|so is it possible do you think speaking
7516.679|3.96|of feminist to construct neural Nets and
7518.84|3.799|training processes that require very
7520.639|4.381|little data
7522.639|4.301|so we've been talking about huge data
7525.02|3.36|sets like the internet for training I
7526.94|3.299|mean one way to say that is like you
7528.38|4.14|said like the querying itself is another
7530.239|5.161|level of training I guess and that
7532.52|6.96|requires a little data yeah but do you
7535.4|6.66|see any uh value in doing research and
7539.48|5.04|kind of going down the direction of can
7542.06|4.74|we use very little data to train to
7544.52|3.659|construct a knowledge base 100 I just
7546.8|2.879|think like at some point you need a
7548.179|3.241|massive data set and then when you
7549.679|3.901|pre-train your massive neural nut and
7551.42|3.9|get something that you know is like a
7553.58|4.5|GPT or something then you're able to be
7555.32|6.06|very efficient at training any arbitrary
7558.08|4.98|new task uh so a lot of these gpts you
7561.38|3.839|know you can do tasks like sentiment
7563.06|3.539|analysis or translation or so on just by
7565.219|2.88|being prompted with very few examples
7566.599|3.54|here's the kind of thing I want you to
7568.099|3.481|do like here's an input sentence here's
7570.139|3.06|the translation into German input
7571.58|3.84|sentence translation to German input
7573.199|3.54|sentence blank and the neural network
7575.42|3.719|will complete the translation to German
7576.739|3.96|just by looking at sort of the example
7579.139|4.861|you've provided and so that's an example
7580.699|4.621|of a very few shot uh learning in the
7584.0|2.94|activations of the neural net instead of
7585.32|2.64|the weights of the neural land and so I
7586.94|3.42|think
7587.96|4.08|basically uh just like humans neural
7590.36|4.02|Nets will become very data efficient at
7592.04|3.84|learning any other new task but at some
7594.38|3.06|point you need a massive data set to
7595.88|4.5|pre-train your network
7597.44|4.98|to get that and probably we humans have
7600.38|4.319|something like that do we do we have
7602.42|4.46|something like that do we have a passive
7604.699|6.061|in the background
7606.88|5.14|background model constructing thing that
7610.76|3.0|just runs all the time in a
7612.02|3.54|self-supervised way we're not conscious
7613.76|3.839|of it I think humans definitely I mean
7615.56|5.28|obviously we have uh we learn a lot
7617.599|5.1|during during our life span but also we
7620.84|3.96|have a ton of Hardware that helps us
7622.699|4.261|initialize initialization coming from
7624.8|4.319|sort of evolution and so I think that's
7626.96|3.48|also a really big a big component a lot
7629.119|2.761|of people in the field I think they just
7630.44|3.659|talk about the amounts of like seconds
7631.88|4.2|and the you know that a person has lived
7634.099|3.781|pretending that this is a table arasa
7636.08|4.32|sort of like a zero initialization of a
7637.88|3.6|neural net and it's not like you can
7640.4|4.199|look at a lot of animals like for
7641.48|6.659|example zebras zebras get born and they
7644.599|5.401|see and they can run there's zero train
7648.139|4.441|data in their lifespan they can just do
7650.0|4.32|that so somehow I have no idea how
7652.58|3.3|Evolution has found a way to encode
7654.32|3.72|these algorithms and these neural net
7655.88|4.259|initializations are extremely good to 80
7658.04|3.42|CGS and I have no idea how this works
7660.139|4.621|but apparently it's possible because
7661.46|6.179|here's a proof by existence there's
7664.76|4.979|something magical about going from a
7667.639|4.441|single cell to an organism that is born
7669.739|3.841|to the first few years of life I kind of
7672.08|3.599|like the idea that the reason we don't
7673.58|4.559|remember anything about the first few
7675.679|4.681|years of our life is that it's a really
7678.139|3.781|painful process like it's a very
7680.36|3.92|difficult challenging
7681.92|5.219|training process yeah like
7684.28|5.8|intellectually like
7687.139|5.221|and maybe yeah I mean I don't why don't
7690.08|5.76|we remember any of that there might be
7692.36|6.18|some crazy training going on and the
7695.84|7.56|that maybe that's the background model
7698.54|6.96|training that uh is is very painful and
7703.4|3.48|so it's best for the system once it's
7705.5|3.179|trained not to remember how it's
7706.88|3.719|constructed I think it's just like the
7708.679|3.781|hardware for long-term memory is just
7710.599|4.921|not fully developed sure I kind of feel
7712.46|4.62|like the first few years of uh of
7715.52|3.78|infants is not actually like learning
7717.08|4.26|it's brain maturing yeah
7719.3|3.66|um we're born premature
7721.34|3.0|um and there's a theory along those
7722.96|3.3|lines because of the birth canal and the
7724.34|3.299|swelling of the brain and so we're born
7726.26|3.72|premature and then the first few years
7727.639|4.381|we're just the brains maturing and then
7729.98|2.699|there's some learning eventually
7732.02|2.639|um
7732.679|4.641|it's my current view on it what do you
7734.659|4.98|think do you think neural Nets can have
7737.32|4.06|long-term memory
7739.639|3.54|like that approach is something like
7741.38|3.18|humans do you think you know do you
7743.179|3.0|think there needs to be another meta
7744.56|3.42|architecture on top of it to add
7746.179|3.54|something like a knowledge base that
7747.98|4.02|learns facts about the world and all
7749.719|4.201|that kind of stuff yes but I don't know
7752.0|3.3|to what extent it will be explicitly
7753.92|4.02|constructed
7755.3|5.28|um it might take unintuitive forms where
7757.94|4.62|you are telling the GPT like hey you
7760.58|3.72|have a you have a declarative memory
7762.56|3.72|bank to which you can store and retrieve
7764.3|3.66|data from and whenever you encounter
7766.28|3.78|some information that you find useful
7767.96|3.719|just save it to your memory bank and
7770.06|3.48|here's an example of something you have
7771.679|3.54|retrieved and Heiser how you say it and
7773.54|4.679|here's how you load from it you just say
7775.219|5.581|load whatever you teach it in text in
7778.219|5.821|English and then it might learn to use a
7780.8|5.339|memory bank from from that oh so so the
7784.04|4.44|neural net is the architecture for the
7786.139|3.96|background model the the base thing and
7788.48|3.119|then yeah everything else is just on top
7790.099|3.421|of this it's not just a text right it's
7791.599|3.841|you're giving it gadgets and gizmos so
7793.52|3.719|uh you're teaching in some kind of a
7795.44|3.36|special Language by which we can it can
7797.239|3.541|save arbitrary information and retrieve
7798.8|3.419|it at a later time and you're telling
7800.78|3.6|about these special tokens and how to
7802.219|3.96|arrange them to use these interfaces
7804.38|4.56|it's like hey you can use a calculator
7806.179|5.281|here's how you use it just do five three
7808.94|5.1|plus four one equals and when equals is
7811.46|3.659|there uh a calculator will actually read
7814.04|3.0|out the answer and you don't have to
7815.119|3.06|calculate it yourself and you just like
7817.04|4.44|tell it in English this might actually
7818.179|4.98|work do you think in that sense gato is
7821.48|3.6|interesting the the Deep Mind system
7823.159|3.48|that it's not just new language but
7825.08|6.059|actually throws it all
7826.639|6.301|uh in the same pile images actions all
7831.139|3.841|that kind of stuff that's basically what
7832.94|4.46|we're moving towards yeah I think so so
7834.98|4.92|gato is uh is very much a kitchen sink
7837.4|4.54|approach to like
7839.9|3.239|um reinforcement learning lots of
7841.94|4.259|different environments with a single
7843.139|4.921|fixed Transformer model right
7846.199|4.321|um I think it's a very sort of early
7848.06|3.96|result in that in that realm but I think
7850.52|2.699|uh yeah it's along the lines of what I
7852.02|3.719|think things will eventually look like
7853.219|3.781|right so this is the early days of a
7855.739|3.541|system that eventually will look like
7857.0|4.199|this like from a rigid Rich sudden
7859.28|3.3|perspective yeah I'm not super huge fan
7861.199|3.661|of I think all these interfaces that
7862.58|3.48|like look very different
7864.86|2.94|um I would want everything to be
7866.06|3.659|normalized into the same API so for
7867.8|3.419|example it's green pixels versus same
7869.719|2.821|API instead of having like different
7871.219|3.301|world environments at a very different
7872.54|3.48|physics and Joint configurations and
7874.52|2.94|appearances and whatever and you're
7876.02|4.079|having some kind of special tokens for
7877.46|4.02|different games that you can plug I'd
7880.099|3.361|rather just normalize everything to a
7881.48|3.78|single interface so it looks the same to
7883.46|3.719|the neural net if that makes sense so
7885.26|4.879|it's all going to be pixel based pong in
7887.179|2.96|the end I think so
7890.26|5.439|okay uh let me ask you about your own
7894.02|3.179|personal life
7895.699|2.821|a lot of people want to know you're one
7897.199|3.781|of the most productive and brilliant
7898.52|3.96|people in the history of AI what is a
7900.98|3.36|productive day in the life of Andre
7902.48|5.4|capathi look like
7904.34|5.279|what time do you wake up because imagine
7907.88|3.359|um some kind of dance between the
7909.619|3.421|average productive day and a perfect
7911.239|3.48|productive day so the perfect productive
7913.04|3.96|day is the thing we strive
7914.719|4.141|towards in the average is kind of what
7917.0|4.5|it kind of converges to getting all the
7918.86|4.56|mistakes and human eventualities and so
7921.5|3.659|on yeah so what times you wake up are
7923.42|4.44|you morning person I'm not a morning
7925.159|5.341|person I'm a night owl for sure I think
7927.86|4.14|stable or not that's semi-stable like a
7930.5|4.32|eight or nine or something like that
7932.0|5.699|during my PhD it was even later I used
7934.82|5.46|to go to sleep usually at 3am I think uh
7937.699|3.661|the am hours are are precious and very
7940.28|2.76|interesting time to work because
7941.36|3.9|everyone is asleep
7943.04|4.38|um at 8 AM or 7 A.M the east coast is
7945.26|3.18|awake so there's already activity
7947.42|2.759|there's already some text messages
7948.44|3.84|whatever there's stuff happening you can
7950.179|4.381|go in like some news website and there's
7952.28|4.68|stuff happening it's distracting uh at
7954.56|3.539|3am everything is totally quiet and so
7956.96|2.94|you're not going to be bothered and you
7958.099|3.301|have solid chunks of time to do your
7959.9|4.62|work
7961.4|5.04|um so I like those periods Night Owl by
7964.52|3.659|default and then I think like productive
7966.44|3.239|time basically
7968.179|3.06|um what I like to do is you need you
7969.679|4.801|need to like build some momentum on the
7971.239|7.021|problem without too much distraction and
7974.48|5.759|um you need to load your Ram uh your
7978.26|3.419|working memory with that problem
7980.239|2.701|and then you need to be obsessed with it
7981.679|3.181|when you're taking shower when you're
7982.94|3.179|falling asleep you need to be obsessed
7984.86|3.18|with the problem and it's fully in your
7986.119|3.54|memory and you're ready to wake up and
7988.04|4.32|work on it right there so there's a
7989.659|4.261|scale of uh is this in a scale temporal
7992.36|3.779|scale of a single day or a couple of
7993.92|3.54|days a week a month so I can't talk
7996.139|3.721|about one day basically in isolation
7997.46|3.719|because it's a whole process when I want
7999.86|3.779|to get when I want to get productive in
8001.179|4.321|the problem I feel like I need a span of
8003.639|3.6|a few days where I can really get in on
8005.5|4.02|that problem and I don't want to be
8007.239|3.541|interrupted and I'm going to just uh be
8009.52|3.0|completely obsessed with that problem
8010.78|3.18|and that's where I do most of my good
8012.52|3.3|workouts
8013.96|3.659|you've done a bunch of cool like little
8015.82|3.72|projects in a very short amount of time
8017.619|3.841|very quickly so that that requires you
8019.54|3.3|just focusing on it yeah basically I
8021.46|2.94|need to load my working memory with the
8022.84|3.12|problem and I need to be productive
8024.4|4.86|because there's always like a huge fixed
8025.96|4.619|cost to approaching any problem uh you
8029.26|3.06|know like I was struggling with this for
8030.579|3.6|example at Tesla because I want to work
8032.32|3.359|on like small side projects but okay you
8034.179|3.121|first need to figure out okay I need to
8035.679|3.361|SSH into my cluster I need to bring up a
8037.3|4.319|vs code editor so I can like work on
8039.04|4.5|this I need to I run into some stupid
8041.619|3.0|error because of some reason like you're
8043.54|3.0|not at a point where you can be just
8044.619|5.58|productive right away you are facing
8046.54|5.34|barriers and so it's about uh really
8050.199|3.241|removing all that barrier and you're
8051.88|3.299|able to go into the problem and you have
8053.44|3.96|the full problem loaded in your memory
8055.179|5.661|and somehow avoiding distractions of all
8057.4|6.42|different forms like uh news stories
8060.84|5.02|emails but also distractions from other
8063.82|3.54|interesting projects that you previously
8065.86|3.48|worked on are currently working on and
8067.36|3.779|so on you just want to really focus your
8069.34|4.259|mind and I mean I can take some time off
8071.139|4.321|for distractions and in between but I
8073.599|3.48|think it can't be too much uh you know
8075.46|4.739|most of your day is sort of like spent
8077.079|5.401|on that problem and then you know I
8080.199|4.681|drink coffee I have my morning routine I
8082.48|4.219|look at some news uh Twitter Hacker News
8084.88|4.199|Wall Street Journal Etc
8086.699|4.061|so basically you wake up you have some
8089.079|3.361|coffee are you trying to get to work as
8090.76|4.379|quickly as possible do you do taking
8092.44|5.04|this diet of of like what the hell's
8095.139|4.381|happening in the world first I am I do
8097.48|4.32|find it interesting to know about the
8099.52|3.659|world I don't know that it's useful or
8101.8|3.0|good but it is part of my routine right
8103.179|4.56|now so I do read through a bunch of news
8104.8|5.819|articles and I want to be informed and
8107.739|4.021|um I'm suspicious of it I'm suspicious
8110.619|3.0|of the practice but currently that's
8111.76|4.859|where I am Oh you mean suspicious about
8113.619|5.161|the positive effect yeah of that
8116.619|3.96|practice on your productivity and your
8118.78|4.08|well-being my well-being psychologically
8120.579|4.62|uh and also on your ability to deeply
8122.86|3.9|understand the world because how there's
8125.199|3.301|a bunch of sources of information you're
8126.76|3.419|not really focused on deeply integrating
8128.5|4.199|yeah it's a little bit distracting or
8130.179|6.241|yeah in terms of a perfectly productive
8132.699|6.061|day for how long of a stretch of time
8136.42|4.38|in one session do you try to work and
8138.76|4.379|focus on a thing it's a couple hours is
8140.8|4.5|it one hours or 30 minutes is 10 minutes
8143.139|3.54|I can probably go like a small few hours
8145.3|4.98|and then I need some breaks in between
8146.679|5.341|for like food and stuff and uh
8150.28|3.6|yeah but I think like uh it's still
8152.02|3.54|really hard to accumulate hours I was
8153.88|3.0|using a Tracker that told me exactly how
8155.56|3.42|much time I've spent coding any one day
8156.88|3.66|and even on a very productive day I
8158.98|3.659|still spent only like six or eight hours
8160.54|5.76|yeah and it's just because there's so
8162.639|6.301|much padding commute talking to people
8166.3|5.1|food Etc there's like the cost of life
8168.94|4.56|just living and sustaining and
8171.4|5.1|homeostasis and just maintaining
8173.5|5.88|yourself as a human is very high and and
8176.5|5.099|there seems to be a desire within the
8179.38|4.259|human mind to to uh to participate in
8181.599|4.14|society that creates that padding yeah
8183.639|4.02|because I yeah the most productive days
8185.739|3.301|I've ever had is just completely from
8187.659|3.42|start to finish just tuning out
8189.04|4.019|everything yep and just sitting there
8191.079|3.661|and then and then you could do more than
8193.059|3.721|six and eight hours yeah is there some
8194.74|5.64|wisdom about what gives you strength to
8196.78|5.76|do like uh tough days of long Focus
8200.38|3.54|yeah just like whenever I get obsessed
8202.54|3.12|about a problem something just needs to
8203.92|4.019|work something just needs to exist it
8205.66|4.319|needs to exist and you so you're able to
8207.939|4.441|deal with bugs and programming issues
8209.979|4.08|and technical issues and uh design
8212.38|3.0|decisions that turn out to be the wrong
8214.059|3.061|ones you're able to think through all of
8215.38|3.599|that given given that you want to think
8217.12|3.899|to exist yeah it needs to exist and then
8218.979|3.54|I think to me also a big factor is uh
8221.019|2.88|you know are other humans are going to
8222.519|3.12|appreciate it are they going to like it
8223.899|3.721|that's a big part of my motivation if
8225.639|5.281|I'm helping humans and they seem happy
8227.62|4.979|they say nice things uh they tweet about
8230.92|3.179|it or whatever that gives me pleasure
8232.599|4.021|because I'm doing something useful so
8234.099|4.38|like you do see yourself sharing it with
8236.62|3.599|the world like with yes on GitHub with a
8238.479|3.481|blog post or through videos yeah I was
8240.219|3.0|thinking about it like suppose I did all
8241.96|2.399|these things but did not share them I
8243.219|2.76|don't think I would have the same amount
8244.359|4.521|of motivation that I can build up you
8245.979|6.24|enjoy the feeling of other people
8248.88|5.259|uh gaining value and happiness from the
8252.219|3.781|stuff you've created yeah
8254.139|3.601|uh what about diet
8256.0|3.66|is there I saw you playing with in
8257.74|3.26|intermittent fast do you fast does that
8259.66|3.6|help with everything
8261.0|5.08|well the things you played what's been
8263.26|5.16|most beneficial to the your ability to
8266.08|4.559|mentally focus on a thing and just meant
8268.42|4.679|the mental productivity and happiness
8270.639|4.141|you still fast yeah it's so fast but I
8273.099|3.061|do intermittent fasting but really what
8274.78|4.439|it means at the end of the day is I skip
8276.16|4.559|breakfast yeah so I do uh 18 6 roughly
8279.219|3.241|by default when I'm in my steady state
8280.719|3.601|if I'm traveling or doing something else
8282.46|4.74|I will break the rules but in my steady
8284.32|5.279|state I do 18 6 so I eat only from 12 to
8287.2|4.979|6. not a hard Rule and I break it often
8289.599|4.38|but that's my default and then um yeah
8292.179|3.481|I've done a bunch of random experiments
8293.979|3.301|for the most part right now uh where
8295.66|4.38|I've been for the last year and a half I
8297.28|4.8|want to say is I'm um plant-based or
8300.04|3.42|planned forward I heard plant forward it
8302.08|2.7|sounds better exactly I didn't actually
8303.46|3.12|know the differences but it sounds
8304.78|4.98|better in my mind but it just means I
8306.58|6.0|prefer plant-based food and raw or
8309.76|5.219|cooked or I prefer cooked uh and blunt
8312.58|5.46|paste so plant-based
8314.979|5.641|oh forgive me I don't actually know how
8318.04|5.059|wide the category of plant entails
8320.62|6.059|Wellness just means that you're not uh
8323.099|5.5|and you can flex and uh you just prefer
8326.679|3.481|to eat plants and you know you're not
8328.599|3.54|making you're not trying to influence
8330.16|3.479|other people and if someone is you come
8332.139|2.641|to someone's house party and they serve
8333.639|3.661|you a stake that they're really proud of
8334.78|3.899|you will eat it yes right it's just not
8337.3|2.46|judgment oh that's beautiful I mean
8338.679|2.821|that's
8339.76|3.78|um on the flip side of that but I'm very
8341.5|5.399|sort of flexible have you tried doing
8343.54|5.76|one meal a day uh I have uh accidentally
8346.899|4.08|not consistently but I've accidentally
8349.3|3.9|had that I don't I don't like it I think
8350.979|4.5|it makes me feel uh not good it's too
8353.2|4.019|it's too much too much of a hit yeah and
8355.479|4.561|uh So currently I have about two meals a
8357.219|5.161|day 12 and six I do that non-stop I'm
8360.04|3.96|doing it now I'm doing one meal a day
8362.38|3.24|okay so it's interesting it's a
8364.0|3.54|interesting feeling have you ever fasted
8365.62|3.479|longer than a day yeah I've done a bunch
8367.54|4.08|of water fasts because I was curious
8369.099|4.741|what happens uh anything interesting
8371.62|3.42|yeah I would say so I mean you know
8373.84|3.54|what's interesting is that you're hungry
8375.04|5.22|for two days and then starting day three
8377.38|3.96|or so you're not hungry it's like such a
8380.26|2.28|weird feeling because you haven't eaten
8381.34|3.599|in a few days and you're not hungry
8382.54|5.04|isn't that weird it's really one of the
8384.939|4.801|many weird things about human biology is
8387.58|3.359|figure something out it finds finds
8389.74|4.44|another source of energy or something
8390.939|4.381|like that or uh relaxes the system I
8394.18|2.46|don't know how yeah the body is like
8395.32|2.46|you're hungry you're hungry and then it
8396.64|3.6|just gives up it's like okay I guess
8397.78|3.78|we're fasting now there's nothing and
8400.24|3.78|then it just kind of like focuses on
8401.56|4.44|trying to make you not hungry uh and you
8404.02|3.54|know not feel the the damage of that and
8406.0|3.6|uh trying to give you some space to
8407.56|4.68|figure out the food situation
8409.6|6.18|so are you still to this day most
8412.24|5.82|productive uh at night I would say I am
8415.78|3.6|but it is really hard to maintain my PhD
8418.06|3.12|schedule
8419.38|4.08|um especially when I was say working at
8421.18|3.84|Tesla and so on it's a non-starter so
8423.46|2.88|but even now like you know people want
8425.02|4.14|to meet for
8426.34|4.44|various events they Society lives in a
8429.16|3.84|certain period of time and you sort of
8430.78|4.14|have to like work so that's it's hard to
8433.0|4.32|like do a social thing and then after
8434.92|4.22|that return and do work yeah it's just
8437.32|4.32|really hard
8439.14|4.78|uh that's why I try to do social things
8441.64|6.24|I try not to do too uh too much drinking
8443.92|6.24|so I can return and continue doing work
8447.88|5.82|um but a Tesla is there is there
8450.16|5.1|conversions in Tesla but any any company
8453.7|4.32|is there a convergence towards the
8455.26|4.559|schedule or is there more
8458.02|3.66|is that how humans behave when they
8459.819|4.141|collaborate I need to learn about this
8461.68|3.719|yeah do they try to keep a consistent
8463.96|3.42|schedule you're all awake at the same
8465.399|3.901|time I mean I do try to create a routine
8467.38|4.5|and I try to create a steady state in
8469.3|4.32|which I'm uh comfortable in uh so I have
8471.88|3.3|a morning routine I have a day routine I
8473.62|4.68|try to keep things to do a steady state
8475.18|4.56|and um things are predictable and then
8478.3|3.059|you can sort of just like your body just
8479.74|2.94|sort of like sticks to that and if you
8481.359|2.641|try to stress that a little too much it
8482.68|2.58|will create uh you know when you're
8484.0|3.66|traveling and you're dealing with jet
8485.26|5.4|lag you're not able to really Ascend to
8487.66|5.22|you know where you need to go yeah yeah
8490.66|3.84|that's weird as humans with the habits
8492.88|3.84|and stuff uh what are your thoughts on
8494.5|4.08|work-life balance throughout a human
8496.72|4.62|lifetime
8498.58|5.34|so the testing part was known for sort
8501.34|4.38|of pushing people to their limits
8503.92|4.8|in terms of what they're able to do in
8505.72|4.44|terms of what they're uh trying to do in
8508.72|3.48|terms of how much they work all that
8510.16|4.62|kind of stuff yeah I mean I will say
8512.2|4.14|teslaq is still too much uh bad rep for
8514.78|4.14|this because what's happening is Tesla
8516.34|4.62|is a it's a bursting environment uh so I
8518.92|3.54|would say the Baseline uh my only point
8520.96|3.06|of reference is Google where I've
8522.46|4.08|interned three times and I saw what it's
8524.02|4.2|like inside Google and and deepmind
8526.54|3.42|um I would say the Baseline is higher
8528.22|3.36|than that but then there's a punctuated
8529.96|3.6|equilibrium where once in a while
8531.58|4.08|there's a fire and uh someone like
8533.56|4.02|people work really hard and so it's
8535.66|3.6|spiky and bursty and then all the
8537.58|3.239|stories get collected about the bursts
8539.26|3.36|yeah and then it gives the appearance of
8540.819|4.08|like total insanity but actually it's
8542.62|5.1|just a bit more intense environment and
8544.899|4.681|there are fires and Sprints and so I
8547.72|2.88|think uh you know definitely though I I
8549.58|2.52|would say
8550.6|3.06|um it's a more intense environment than
8552.1|3.42|something you would get but you in your
8553.66|3.96|person forget all of that just in your
8555.52|3.48|own personal life
8557.62|3.9|um what do you think about
8559.0|4.68|the happiness of a human being a
8561.52|5.1|brilliant person like yourself
8563.68|6.12|about finding a balance between work and
8566.62|5.04|life or is it such a thing not a good
8569.8|5.88|thought experiment
8571.66|5.76|yeah I think I think balance is good but
8575.68|3.96|I also love to have Sprints that are out
8577.42|5.399|of distribution and that's what I think
8579.64|6.06|I've been pretty uh creative and
8582.819|5.16|um as well Sprints out of distribution
8585.7|6.239|means that most of the time
8587.979|5.521|you have a yeah quote-unquote balance I
8591.939|3.481|have balance most of the time yes I like
8593.5|3.84|being obsessed with something once in a
8595.42|3.24|while once in a while is what once a
8597.34|2.58|week once a month once a year yeah
8598.66|3.12|probably like say once a month or
8599.92|3.899|something yeah and that's when we get a
8601.78|3.48|new GitHub repo come on yeah that's when
8603.819|3.481|you like really care about a problem it
8605.26|3.84|must exist this will be awesome you're
8607.3|3.3|obsessed with it and now you can't just
8609.1|3.18|do it on that day you need to pay the
8610.6|3.42|fixed cost of getting into the groove
8612.28|3.6|and then you need to stay there for a
8614.02|3.24|while and then Society will come and
8615.88|2.939|they will try to mess with you and they
8617.26|2.82|will try to distract you yeah yeah the
8618.819|2.641|worst thing is like a person who's like
8620.08|4.319|I just need five minutes of your time
8621.46|5.46|yeah this is the cost of that is not
8624.399|4.92|five minutes and Society needs to change
8626.92|5.34|how it thinks about just five minutes of
8629.319|5.04|your time right it's never it's never
8632.26|3.179|just one minute it's just 30 it's just a
8634.359|3.721|quick what's the big deal why are you
8635.439|6.181|being so yeah no
8638.08|5.7|uh what's your computer setup what uh
8641.62|4.52|what's like the perfect are you somebody
8643.78|7.14|that's flexible to no matter what laptop
8646.14|6.339|four screens yeah uh or do you uh prefer
8650.92|3.66|a certain setup that you're most
8652.479|5.041|productive um I guess the one that I'm
8654.58|4.02|familiar with is one large screen uh 27
8657.52|3.12|inch
8658.6|4.2|um and my laptop on the side with
8660.64|5.339|operating system I do Max that's my
8662.8|4.32|primary for all tasks I would say OS X
8665.979|2.88|but when you're working on deep learning
8667.12|4.08|everything as Linux your SSH into a
8668.859|3.661|cluster and you're working remotely but
8671.2|3.9|what about the actual development like
8672.52|4.5|that using the IDE yeah you would use uh
8675.1|3.12|I think a good way is you just run vs
8677.02|2.879|code
8678.22|3.66|um my favorite editor right now on your
8679.899|4.201|Mac but you are actually you have a
8681.88|4.08|remote folder through SSH
8684.1|2.94|um so the actual files that you're
8685.96|4.439|manipulating are on the cluster
8687.04|6.54|somewhere else so what's the best IDE
8690.399|7.801|uh vs code what else do people so I use
8693.58|6.239|emacs still that's cool uh so it may be
8698.2|3.239|cool I don't know if it's maximum
8699.819|3.421|productivity
8701.439|3.901|um so what what do you recommend in
8703.24|4.619|terms of editors you worked with a lot
8705.34|4.92|of software Engineers editors for
8707.859|4.5|python C plus plus machine learning
8710.26|4.32|applications I think the current answer
8712.359|3.241|is vs code currently I believe that's
8714.58|3.18|the best
8715.6|4.74|um IDE it's got a huge amount of
8717.76|5.04|extensions it has a GitHub co-pilot
8720.34|4.139|um uh integration which I think is very
8722.8|4.08|valuable what do you think about the the
8724.479|3.96|co-pilot integration I was actually uh I
8726.88|3.96|got to talk a bunch with Guido and
8728.439|5.401|Rossum who's a creative Python and he
8730.84|5.639|loves Coppola he like he programs a lot
8733.84|5.099|with it yeah uh do you
8736.479|4.441|yeah he's copilot I love it and uh it's
8738.939|3.361|free for me but I would pay for it yeah
8740.92|3.72|I think it's very good and the utility
8742.3|3.66|that I found with it was is in is it I
8744.64|3.839|would say there is a learning curve and
8745.96|4.14|you need to figure out when it's helpful
8748.479|2.761|and when to pay attention to its outputs
8750.1|2.58|and when it's not going to be helpful
8751.24|3.0|where you should not pay attention to it
8752.68|2.82|because if you're just reading its
8754.24|2.88|suggestions all the time it's not a good
8755.5|3.06|way of interacting with it but I think I
8757.12|3.239|was able to sort of like mold myself to
8758.56|4.86|it I find it's very helpful number one
8760.359|5.341|in copy paste and replace some parts so
8763.42|3.54|I don't um when the pattern is clear
8765.7|3.36|it's really good at completing the
8766.96|4.92|pattern and number two sometimes it
8769.06|4.32|suggests apis that I'm not aware of so
8771.88|3.479|it tells you about something that you
8773.38|3.479|didn't know so and that's an opportunity
8775.359|3.721|to discover and you it's an opportunity
8776.859|4.921|to see I would never take copilot code
8779.08|4.02|AS given I almost always uh copy a copy
8781.78|3.0|this into a Google Search and you see
8783.1|2.7|what this function is doing and then
8784.78|3.06|you're like oh it's actually actually
8785.8|3.66|exactly what I need thank you copilot so
8787.84|4.86|you learned something so it's in part a
8789.46|5.46|search engine apart maybe getting the
8792.7|4.739|exact syntax correctly that once you see
8794.92|4.68|it yep it's that NP hard thing it's like
8797.439|4.321|once you see it you know yes exactly
8799.6|4.2|correct exactly you yourself you can
8801.76|4.08|struggle you can verify efficiently but
8803.8|3.24|you you can't generate efficiently and
8805.84|4.08|copilot really I mean it's it's
8807.04|4.62|autopilot for programming right and
8809.92|3.3|currently it's doing the link following
8811.66|3.72|which is like the simple copy paste and
8813.22|3.78|sometimes suggest uh but over time it's
8815.38|4.08|going to become more and more autonomous
8817.0|4.14|and so the same thing will play out in
8819.46|3.18|not just coding but actually across many
8821.14|3.179|many different things probably but
8822.64|4.02|coding is an important one right like
8824.319|4.561|writing programs yeah what how do you
8826.66|4.02|see the future of that developing uh the
8828.88|3.72|program synthesis like being able to
8830.68|4.38|write programs that are more and more
8832.6|6.0|complicated because right now it's human
8835.06|5.4|supervised in interesting ways yes like
8838.6|3.24|what it feels like the transition will
8840.46|3.66|be very painful
8841.84|4.74|my mental model for it is the same thing
8844.12|3.9|will happen as with the autopilot uh So
8846.58|3.6|currently it's doing link following is
8848.02|3.9|doing some simple stuff and eventually
8850.18|3.299|we'll be doing autonomy and people will
8851.92|3.899|have to intervene less and less and
8853.479|3.781|there could be like you like testing
8855.819|3.361|mechanisms
8857.26|4.38|like if it writes a function and that
8859.18|4.08|function looks pretty damn correct but
8861.64|3.54|how do you know it's correct because
8863.26|3.84|you're like getting lazier and lazier as
8865.18|4.08|a programmer like your ability to
8867.1|4.32|because like little bugs but I guess it
8869.26|5.219|won't make a little no it will it
8871.42|4.92|copilot will make uh off by one subtle
8874.479|4.261|bugs it has done that to me but do you
8876.34|4.62|think future systems will or is it
8878.74|4.68|really the off by one is actually a
8880.96|4.08|fundamental challenge of programming in
8883.42|3.899|that case it wasn't fundamental and I
8885.04|3.72|think things can improve but uh yeah I
8887.319|2.881|think humans have to supervise I am
8888.76|3.9|nervous about people not supervising
8890.2|4.08|what comes out and what happens to for
8892.66|3.6|example the proliferation of bugs in all
8894.28|3.78|of our systems I'm nervous about that
8896.26|3.719|but I think and there will probably be
8898.06|3.419|some other copilots for bug finding and
8899.979|2.88|stuff like that at some point because
8901.479|3.621|there will be like a lot more automation
8902.859|6.12|for uh oh man
8905.1|6.759|so it's like a program a co-pilot that
8908.979|5.941|generates a compiler for one that does a
8911.859|5.341|linter yes one that does like a a type
8914.92|5.22|Checker yes
8917.2|4.56|it's a committee of like a GPT sort of
8920.14|3.42|like and then they'll be like a manager
8921.76|3.36|for the committee yeah and then there'll
8923.56|3.36|be somebody that says a new version of
8925.12|3.54|this is needed we need to regenerate it
8926.92|3.059|yeah there were 10 gpts that were
8928.66|3.18|forwarded and gave 50 suggestions
8929.979|4.141|another one looked at it and picked a
8931.84|3.479|few that they like a bug one looked at
8934.12|3.0|it and it was like it's probably a bug
8935.319|4.921|they got re-ranked by some other thing
8937.12|4.38|and then a final Ensemble uh GPT comes
8940.24|2.34|in it's like okay given everything you
8941.5|3.72|guys have told me this is probably the
8942.58|3.96|next token you know the feeling is the
8945.22|3.24|number of programmers in the world has
8946.54|3.24|been growing and growing very quickly do
8948.46|4.14|you think it's possible that it'll
8949.78|4.619|actually level out and drop to like a
8952.6|3.78|very low number with this kind of world
8954.399|4.861|because then you'll be doing software
8956.38|5.059|2.0 programming
8959.26|4.86|um and you'll be doing this kind of
8961.439|4.96|generation of copilot type systems
8964.12|3.38|programming but you won't be doing the
8966.399|4.141|old school
8967.5|4.479|software 1.0 program I don't currently
8970.54|3.12|think that they're just going to replace
8971.979|2.641|human programmers
8973.66|3.06|um
8974.62|4.38|it's I'm so hesitant saying stuff like
8976.72|4.32|this right because this is going to be
8979.0|4.439|replaced in five years I don't know it's
8981.04|5.22|going to show that like this is where we
8983.439|4.861|thought because I I agree with you but I
8986.26|5.46|think we might be very surprised
8988.3|5.82|right like what are the next
8991.72|4.02|I I what's your sense of what we're
8994.12|3.6|seeing with language models like does it
8995.74|4.14|feel like the beginning or the middle or
8997.72|3.78|the end the beginning 100 I think the
8999.88|3.059|big question in my mind is for sure GPT
9001.5|3.54|will be able to program quite well
9002.939|3.96|competently and so on how do you steer
9005.04|3.42|the system you still have to provide
9006.899|3.661|some guidance to what you actually are
9008.46|4.38|looking for and so how do you steer it
9010.56|4.02|and how do you say how do you talk to it
9012.84|3.78|how do you um
9014.58|3.48|audit it and verify that what is done is
9016.62|3.6|correct and how do you like work with
9018.06|4.799|this and it's as much not just an AI
9020.22|5.58|problem but a UI ux problem yeah
9022.859|5.46|um so beautiful fertile ground for so
9025.8|4.5|much interesting work for vs code plus
9028.319|3.361|plus where you're not just it's not just
9030.3|3.179|human programming anymore it's amazing
9031.68|4.38|yeah so you're interacting with the
9033.479|4.38|system so not just one prompt but it's
9036.06|3.48|iterative prompting yeah you're trying
9037.859|3.421|to figure out having a conversation with
9039.54|3.779|the system yeah that actually I mean to
9041.28|3.42|me that's super exciting to have a
9043.319|2.401|conversation with the program I'm
9044.7|2.82|writing
9045.72|3.36|yeah maybe at some point uh you're just
9047.52|3.44|conversing with it it's like okay here's
9049.08|3.96|what I want to do actually this variable
9050.96|5.08|maybe it's not even that low level as
9053.04|5.34|variable but you can also Imagine like
9056.04|4.2|can you translate this to c plus and
9058.38|3.66|back to python yeah that already kind of
9060.24|4.44|existence no but just like doing it as
9062.04|4.08|part of the program experience like I
9064.68|2.42|think I'd like to write this function in
9066.12|3.72|C plus plus
9067.1|4.54|or or like you just keep changing for
9069.84|4.38|different uh different programs because
9071.64|3.86|they're different syntax maybe I want to
9074.22|3.96|convert this into a functional language
9075.5|5.56|and so like you get to become
9078.18|5.219|multilingual as a programmer and dance
9081.06|4.32|back and forth efficiently yeah I mean I
9083.399|3.54|think the UI ux of it though is like
9085.38|3.479|still very hard to think through because
9086.939|3.781|it's not just about writing code on a
9088.859|3.361|page you have an entire developer
9090.72|3.48|environment you have a bunch of hardware
9092.22|3.42|on it uh you have some environmental
9094.2|2.88|variables you have some scripts that are
9095.64|3.179|running in the Chrome job like there's a
9097.08|4.92|lot going on to like working with
9098.819|5.761|computers and how do these uh systems
9102.0|3.84|set up environment flags and work across
9104.58|2.819|multiple machines and set up screen
9105.84|3.599|sessions and automate different
9107.399|3.841|processes like how all that works and
9109.439|3.361|it's auditable by humans and so on is
9111.24|4.56|like massive question at the moment
9112.8|5.519|you've built archive sanity
9115.8|4.86|what is archive and what is the future
9118.319|4.62|of academic research publishing that you
9120.66|3.9|would like to see so archive is This
9122.939|3.841|pre-print Server so if you have a paper
9124.56|3.72|you can submit it for publication to
9126.78|3.0|journals or conferences and then wait
9128.28|3.539|six months and then maybe get a decision
9129.78|3.3|pass or fail or you can just upload it
9131.819|3.301|to Archive
9133.08|3.96|and then people can tweet about it three
9135.12|3.18|minutes later and then everyone sees it
9137.04|3.72|everyone reads it and everyone can
9138.3|5.22|profit from it uh in their own ways you
9140.76|5.219|can cite it and it has an official look
9143.52|4.379|to it it feels like a pub like it feels
9145.979|3.481|like a publication process yeah it feels
9147.899|3.601|different than you if you just put in a
9149.46|4.26|blog post oh yeah yeah I mean it's a
9151.5|4.02|paper and usually the the bar is higher
9153.72|3.42|for something that you would expect on
9155.52|3.06|archive as opposed to and something you
9157.14|4.2|would see in a blog post well the
9158.58|4.44|culture created the bar because you
9161.34|3.599|could probably yes host a pretty crappy
9163.02|3.959|face for an archive
9164.939|3.54|um so what's that make you feel like
9166.979|4.981|what's that make you feel about peer
9168.479|6.781|review so rigorous peer review by two
9171.96|6.06|three experts versus the peer review of
9175.26|4.5|the community right as it's written yeah
9178.02|3.72|basically I think the community is very
9179.76|5.219|well able to peer review things very
9181.74|4.739|quickly on Twitter and I think maybe it
9184.979|3.181|just has to do something with AI machine
9186.479|2.941|learning field specifically though I
9188.16|4.62|feel like things are more easily
9189.42|5.28|auditable um and the verification is is
9192.78|3.96|easier potentially than the verification
9194.7|3.96|somewhere else so it's kind of like um
9196.74|2.94|you can think of these uh scientific
9198.66|2.4|Publications there's like little
9199.68|2.52|blockchains where everyone's building on
9201.06|3.12|each other's work and setting each other
9202.2|3.72|and you sort of have ai which is kind of
9204.18|5.1|like this much faster and loose
9205.92|5.76|blockchain but then you have and any one
9209.28|3.78|individual entry is like very um very
9211.68|2.759|cheap to make and then you have other
9213.06|3.0|fields where maybe that model doesn't
9214.439|4.141|make as much sense
9216.06|4.5|um and so I think in AI at least things
9218.58|3.359|are pretty easily verifiable and so
9220.56|2.7|that's why when people upload papers
9221.939|3.601|they're a really good idea and so on
9223.26|4.08|people can try it out like the next day
9225.54|3.18|and they can be the final Arbiter
9227.34|2.82|whether it works or not on their problem
9228.72|3.54|and the whole thing just moves
9230.16|4.14|significantly faster so I kind of feel
9232.26|3.42|like Academia still has a place sorry
9234.3|2.94|this like conference Journal process
9235.68|4.74|still has a place but it's sort of like
9237.24|5.28|an um it lags behind I think and it's a
9240.42|4.92|bit more maybe higher quality process
9242.52|4.2|but it's not sort of the place where you
9245.34|3.12|will discover Cutting Edge work anymore
9246.72|2.94|yeah it used to be the case when I was
9248.46|3.0|starting my PhD that you go to
9249.66|3.48|conferences and journals and you discuss
9251.46|3.42|all the latest research now when you go
9253.14|3.06|to a conference or Journal like no one
9254.88|3.38|discusses anything that's there because
9256.2|4.92|it's already like three generations ago
9258.26|4.78|irrelevant yes which makes me sad about
9261.12|3.96|like deepmind for example where they
9263.04|4.439|they still they still publish in nature
9265.08|4.14|and these big prestigious I mean there's
9267.479|4.621|still value as opposed to The Prestige
9269.22|5.04|that comes with these big venues but the
9272.1|4.2|the result is that they they'll announce
9274.26|4.86|some breakthrough performance and it'll
9276.3|6.599|take like a year to actually publish the
9279.12|4.92|details I mean and those details in if
9282.899|3.301|they were published immediately would
9284.04|3.48|Inspire the community to move in certain
9286.2|2.76|directions with that yeah it would speed
9287.52|3.18|up the rest of the community but I don't
9288.96|4.2|know to what extent that's part of their
9290.7|3.96|objective function also that's true so
9293.16|4.199|it's not just the prestige a little bit
9294.66|4.92|of the delay is uh is part yeah they
9297.359|4.62|certainly deepmind specifically has been
9299.58|3.84|um working in the regime of having a
9301.979|3.84|slightly higher quality basically
9303.42|4.5|process and latency and uh publishing
9305.819|5.341|those papers that way another question
9307.92|5.28|from Reddit do you or have you suffered
9311.16|5.58|from imposter syndrome being the
9313.2|5.64|director of AI Tesla being this person
9316.74|4.68|when you're at Stanford where like the
9318.84|5.519|world looks at you as the expert in AI
9321.42|5.22|to teach teach the world about machine
9324.359|4.021|learning when I was leaving Tesla after
9326.64|4.32|five years I spent a ton of time in
9328.38|4.14|meeting rooms uh and you know I would
9330.96|3.12|read papers in the beginning when I
9332.52|3.0|joined Tesla I was writing code and then
9334.08|2.58|I was writing lesson last code and I was
9335.52|3.0|reading code and then I was reading
9336.66|3.36|lesson less code and so this is just a
9338.52|3.54|natural progression that happens I think
9340.02|3.54|and uh definitely I would say near the
9342.06|2.64|tail end that's when it sort of like
9343.56|3.12|starts to hit you a bit more that you're
9344.7|3.6|supposed to be an expert but actually
9346.68|3.06|the source of Truth is the code that
9348.3|4.139|people are writing the GitHub and the
9349.74|4.02|actual the actual code itself and you're
9352.439|3.601|not as familiar with that as you used to
9353.76|3.84|be and so I would say maybe there's some
9356.04|3.66|like insecurity there yeah that's
9357.6|3.42|actually pretty profound that a lot of
9359.7|2.88|the insecurity has to do with not
9361.02|3.36|writing the code in the computer science
9362.58|3.96|space like that because that is the
9364.38|3.18|truth that that right there code is the
9366.54|2.58|source of Truth the papers and
9367.56|4.379|everything else it's a high level
9369.12|4.02|summary I don't uh yeah just a high
9371.939|2.581|level summary but at the end of the day
9373.14|3.6|you have to read code it's impossible to
9374.52|5.28|translate all that code into actual uh
9376.74|4.199|you know paper form uh so when when
9379.8|2.22|things come out especially when they
9380.939|3.0|have a source code available that's my
9382.02|3.78|favorite place to go so like I said
9383.939|6.481|you're one of the greatest teachers of
9385.8|7.5|machine learning AI ever uh from cs231n
9390.42|4.38|to today what advice would you give to
9393.3|3.0|beginners interested in getting into
9394.8|5.34|machine learning
9396.3|5.28|beginners are often focused on like what
9400.14|4.08|to do and I think the focus should be
9401.58|4.26|more like how much you do so I I'm kind
9404.22|3.84|of like believer on a high level in this
9405.84|3.72|10 000 hours kind of concept where
9408.06|2.82|you just kind of have to just pick the
9409.56|2.64|things where you can spend time and you
9410.88|2.76|you care about and you're interested in
9412.2|2.64|you literally have to put in 10 000
9413.64|2.759|hours of work
9414.84|3.18|um it doesn't even like matter as much
9416.399|3.42|like where you put it and your you'll
9418.02|3.18|iterate and you'll improve and you'll
9419.819|3.061|waste some time I don't know if there's
9421.2|3.239|a better way you need to put in 10 000
9422.88|2.58|hours but I think it's actually really
9424.439|3.54|nice because I feel like there's some
9425.46|3.899|sense of determinism about uh being an
9427.979|3.601|expert at a thing if you spend ten
9429.359|4.141|thousand hours you can literally pick an
9431.58|3.66|arbitrary thing and I think if you spend
9433.5|3.12|ten thousand hours of deliberate effort
9435.24|3.72|and work you actually will become an
9436.62|4.44|expert at it and so I think it's kind of
9438.96|4.859|like a nice thought
9441.06|4.44|um and so uh basically I would focus
9443.819|4.261|more on like are you spending 10 000
9445.5|4.2|hours that's what I focus on so and then
9448.08|3.779|thinking about what kind of mechanisms
9449.7|4.44|maximize your likelihood of getting to
9451.859|5.161|ten thousand dollars exactly which for
9454.14|5.04|us silly humans means probably forming a
9457.02|3.839|daily habit of like every single day
9459.18|3.48|actually doing the thing whatever helps
9460.859|3.96|you so I do think to a large extent is a
9462.66|3.9|psychological problem for yourself uh
9464.819|3.481|one other thing that I help that I think
9466.56|3.299|is helpful for the psychology of it is
9468.3|3.179|many times people compare themselves to
9469.859|3.901|others in the area I think this is very
9471.479|4.38|harmful only compare yourself to you
9473.76|4.559|from some time ago like say a year ago
9475.859|4.08|are you better than you year ago this is
9478.319|3.361|the only way to think
9479.939|3.181|um and I think this then you can see
9481.68|4.2|your progress and it's very motivating
9483.12|5.04|that's so interesting that focus on the
9485.88|4.439|quantity of ours because I think a lot
9488.16|4.8|of people uh in the beginner stage but
9490.319|6.781|actually throughout get paralyzed
9492.96|6.6|uh by uh the choice like which one do I
9497.1|4.379|pick this path or this path yeah like
9499.56|3.72|they'll literally get paralyzed by like
9501.479|3.061|which ID to use well they're worried
9503.28|3.24|yeah they're worried about all these
9504.54|3.359|things but the thing is some of the you
9506.52|2.82|you will waste time doing something
9507.899|2.881|wrong yes you will eventually figure out
9509.34|3.66|it's not right you will accumulate scar
9510.78|3.539|tissue and next time you'll grow
9513.0|3.12|stronger because next time you'll have
9514.319|3.781|the scar tissue and next time you'll
9516.12|3.359|learn from it and now next time you come
9518.1|2.46|into a similar situation you'll be like
9519.479|3.42|all right
9520.56|3.839|I messed up I've spent a lot of time
9522.899|3.181|working on things that never materialize
9524.399|3.061|into anything and I have all that scar
9526.08|3.359|tissue and I have some intuitions about
9527.46|3.6|what was useful what wasn't useful how
9529.439|4.081|things turned out uh so all those
9531.06|4.379|mistakes were uh were not dead work you
9533.52|4.26|know so I just think you should just
9535.439|4.321|focus on working what have you done what
9537.78|4.14|have you done last week
9539.76|4.2|uh that's a good question actually to
9541.92|3.66|ask for for a lot of things not just
9543.96|4.14|machine learning
9545.58|4.26|um it's a good way to cut the
9548.1|4.799|the I forgot what the term will use but
9549.84|5.58|the fluff the blubber whatever the uh
9552.899|5.521|the inefficiencies in life uh what do
9555.42|4.08|you love about teaching you seem to find
9558.42|3.18|yourself
9559.5|3.54|often in the like drawn to teaching
9561.6|3.0|you're very good at it but you're also
9563.04|5.34|drawn to it I mean I don't think I love
9564.6|6.66|teaching I love happy humans and happy
9568.38|4.5|humans like when I teach yes I I
9571.26|3.059|wouldn't say I hate teaching I tolerate
9572.88|3.78|teaching but it's not like the act of
9574.319|4.921|teaching that I like it's it's that um
9576.66|5.34|you know I I have some I have something
9579.24|4.26|I'm actually okay at it yes I'm okay at
9582.0|4.56|teaching and people appreciate it a lot
9583.5|5.46|yeah and uh so I'm just happy to try to
9586.56|4.74|be helpful and uh teaching itself is not
9588.96|4.019|like the most I mean it's really it can
9591.3|3.0|be really annoying frustrating I was
9592.979|3.96|working on a bunch of lectures just now
9594.3|4.32|I was reminded back to my days of 231
9596.939|2.941|and just how much work it is to create
9598.62|3.06|some of these materials and make them
9599.88|3.66|good the amount of iteration and thought
9601.68|3.78|and you go down blind alleys and just
9603.54|3.42|how much you change it so creating
9605.46|3.359|something good
9606.96|5.16|um in terms of like educational value is
9608.819|4.861|really hard and uh it's not fun it's
9612.12|3.359|difficult so for people should
9613.68|3.9|definitely go watch your new stuff you
9615.479|3.42|put out there are lectures where you're
9617.58|3.6|actually building the thing like from
9618.899|5.101|like you said the coldest truth so
9621.18|4.92|discussing back propagation by building
9624.0|3.359|it by looking through and just the whole
9626.1|2.58|thing so how difficult is that to
9627.359|3.54|prepare for I think that's a really
9628.68|4.32|powerful way to teach how did you have
9630.899|4.621|to prepare for that or are you just live
9633.0|4.14|thinking through it I will typically do
9635.52|3.9|like say three takes and then I take
9637.14|3.48|like the the better take uh so I do
9639.42|2.399|multiple takes and I take some of the
9640.62|3.239|better takes and then I just build out a
9641.819|4.021|lecture that way uh sometimes I have to
9643.859|3.241|delete 30 minutes of content because it
9645.84|3.059|just went down the Nelly that I didn't
9647.1|4.379|like too much there's about a bunch of
9648.899|3.841|iteration and it probably takes me you
9651.479|2.941|know somewhere around 10 hours to create
9652.74|4.26|one hour of content to give one hour
9654.42|4.979|it's interesting I mean is it difficult
9657.0|4.62|to go back to the like the basics do you
9659.399|3.841|draw a lot of like wisdom from going
9661.62|3.0|back to the basics yeah going back to
9663.24|2.699|back propagation loss functions where
9664.62|3.42|they come from and one thing I like
9665.939|3.061|about teaching a lot honestly is it
9668.04|3.66|definitely strengthens your
9669.0|4.439|understanding uh so it's not a purely
9671.7|3.84|altruistic activity it's a way to learn
9673.439|4.621|if you have to explain something to
9675.54|5.939|someone uh you realize you have gaps in
9678.06|5.4|knowledge uh and so I even surprised
9681.479|3.42|myself in those lectures like also the
9683.46|2.58|result will obviously look at this and
9684.899|2.821|then the result doesn't look like it and
9686.04|3.14|I'm like okay I thought I understood
9687.72|3.5|this yeah
9689.18|4.78|but that's why it's really cool to
9691.22|4.3|literally code you run it in a notebook
9693.96|3.78|and it gives you a result and you're
9695.52|4.32|like oh wow and like actual numbers
9697.74|3.72|actual input act you know actual code
9699.84|3.599|yeah it's not mathematical symbols Etc
9701.46|4.32|the source of Truth is the code it's not
9703.439|4.441|slides it's just like let's build it
9705.78|4.02|it's beautiful you're a rare human in
9707.88|5.939|that sense uh what advice would you give
9709.8|5.94|to researchers uh trying to develop and
9713.819|5.04|publish idea that have a big impact in
9715.74|5.46|the world of AI so maybe
9718.859|4.801|um undergrads maybe early graduate
9721.2|3.72|students yep I mean I would say like
9723.66|3.659|they definitely have to be a little bit
9724.92|4.14|more strategic than I had to be as a PhD
9727.319|3.841|student because of the way AI is
9729.06|4.2|evolving it's going the way of physics
9731.16|3.48|where you know in physics you used to be
9733.26|2.52|able to do experiments on your benchtop
9734.64|3.42|and everything was great and you could
9735.78|5.159|make progress and now you have to work
9738.06|4.68|in like LHC or like CERN and
9740.939|2.641|and so AI is going in that direction as
9742.74|2.94|well
9743.58|3.42|um so there's certain kinds of things
9745.68|4.02|that's just not possible to do on the
9747.0|5.1|bench top anymore and uh
9749.7|4.08|I think um that didn't used to be the
9752.1|3.36|case at the time do you still think that
9753.78|5.64|there's like
9755.46|7.08|Gan type papers to be written where like
9759.42|4.74|uh like very simple idea that requires
9762.54|3.24|just one computer to illustrate a simple
9764.16|3.18|example I mean one example that's been
9765.78|3.659|very influential recently is diffusion
9767.34|4.8|models diffusion models are amazing the
9769.439|3.721|fusion models are six years old for the
9772.14|3.24|longest time people were kind of
9773.16|3.96|ignoring them as far as I can tell and
9775.38|4.14|they're an amazing generative model
9777.12|3.96|especially in uh in images and so stable
9779.52|3.959|diffusion and so on it's all diffusion
9781.08|4.68|based the fusion is new it was not there
9783.479|3.901|and came from well it came from Google
9785.76|3.48|but a researcher could have come up with
9787.38|3.479|it in fact some of the first
9789.24|3.9|actually no those came from Google as
9790.859|4.201|well but a researcher could come up with
9793.14|3.6|that in an academic Institution
9795.06|4.86|yeah what do you find Most Fascinating
9796.74|5.159|about diffusion models so from the
9799.92|3.36|societal impact to the the technical
9801.899|3.021|architecture what I like about the
9803.28|4.619|fusion is it works so well
9804.92|5.74|is that surprising to you the amount of
9807.899|5.341|the variety almost the novelty of the
9810.66|5.22|synthetic data is generating yeah so the
9813.24|5.46|stable diffusion images are incredible
9815.88|5.34|it's the speed of improvement in
9818.7|4.02|generating images has been insane uh we
9821.22|3.78|went very quickly from generating like
9822.72|3.599|tiny digits to the tiny faces and it all
9825.0|2.88|looked messed up and now we have stable
9826.319|3.061|diffusion and that happened very quickly
9827.88|4.2|there's a lot that Academia can still
9829.38|5.28|contribute you know for example um flash
9832.08|4.62|attention is a very efficient kernel for
9834.66|4.44|running the attention operation inside
9836.7|3.96|the Transformer that came from academic
9839.1|4.14|environment it's a very clever way to
9840.66|4.14|structure the kernel uh that that's the
9843.24|3.6|calculation so it doesn't materialize
9844.8|3.48|the attention Matrix
9846.84|2.639|um and so there's I think there's still
9848.28|3.0|like lots of things to contribute but
9849.479|3.061|you have to be just more strategic do
9851.28|2.94|you think neural networks could be made
9852.54|3.42|to reason
9854.22|3.719|uh yes
9855.96|4.14|do you think they're already reason yes
9857.939|6.021|what's your definition of reasoning
9860.1|6.54|uh information processing
9863.96|6.12|so in a way that humans think through a
9866.64|3.44|problem and come up with novel ideas
9870.96|5.72|it it feels like a reasoning yeah so the
9874.5|4.58|the novelty
9876.68|5.139|I don't want to say but out of
9879.08|5.26|distribution ideas
9881.819|3.841|you think it's possible yes and I think
9884.34|3.479|we're seeing that already in the current
9885.66|3.779|neural Nets you're able to remix the
9887.819|3.601|training set information into true
9889.439|4.521|generalization in some sense that
9891.42|4.32|doesn't appear it doesn't matter
9893.96|4.0|like you're doing something interesting
9895.74|3.9|algorithmically you're manipulating
9897.96|3.18|you know some symbols and you're coming
9899.64|4.92|up with some
9901.14|7.02|correct a unique answer in a new setting
9904.56|6.48|what would uh illustrate to you holy
9908.16|5.159|shit this thing is definitely thinking
9911.04|3.6|to me thinking or reasoning is just
9913.319|2.941|information processing and
9914.64|3.96|generalization and I think the neural
9916.26|4.74|Nets already do that today so being able
9918.6|6.299|to perceive the world or perceive the
9921.0|6.66|whatever the inputs are and to make
9924.899|3.96|uh predictions based on that or actions
9927.66|3.3|based on that that's that's the reason
9928.859|3.901|yeah you're giving correct answers in
9930.96|4.14|novel settings
9932.76|4.2|by manipulating information you've
9935.1|3.0|learned the correct algorithm you're not
9936.96|3.019|doing just some kind of a lookup table
9938.1|4.74|and there's neighbor search
9939.979|5.441|let me ask you about AGI what what are
9942.84|5.46|some moonshot ideas you think might make
9945.42|5.1|significant progress towards AGI or
9948.3|4.26|maybe in other ways what are big
9950.52|3.78|blockers that we're missing now so
9952.56|5.339|basically I am fairly bullish on our
9954.3|6.66|ability to build agis uh basically
9957.899|4.861|automated systems that we can interact
9960.96|3.359|with and are very human-like and we can
9962.76|4.8|interact with them in a digital realm or
9964.319|5.101|Physical Realm currently it seems most
9967.56|4.68|of the models that sort of do these sort
9969.42|5.939|of magical tasks are in a text Realm
9972.24|5.04|um I think uh as I mentioned I'm
9975.359|3.181|suspicious that the text realm is not
9977.28|3.6|enough to actually build full
9978.54|3.899|understanding of the world I do actually
9980.88|3.36|think you need to go into pixels and
9982.439|3.601|understand the physical world and how it
9984.24|3.3|works so I do think that we need to
9986.04|4.14|extend these models to consume images
9987.54|4.98|and videos and train on a lot more data
9990.18|3.78|that is multimodal in that way
9992.52|3.06|if you think you need to touch the world
9993.96|3.06|to understand it also well that's the
9995.58|3.84|big open question I would say in my mind
9997.02|5.04|is if you also require the embodiment
9999.42|5.399|and the ability to uh sort of interact
10002.06|4.02|with the world run experiments and have
10004.819|4.201|a data of that form then you need to go
10006.08|4.62|to Optimus or something like that and so
10009.02|3.14|I would say Optimus in some way is like
10010.7|5.699|a hedge
10012.16|6.699|in AGI because it seems to me that it's
10016.399|3.781|possible that just having data from the
10018.859|3.841|internet is not enough
10020.18|6.0|if that is the case then Optimus may
10022.7|5.46|lead to AGI because Optimus would I to
10026.18|3.54|me there's nothing Beyond optimism you
10028.16|2.88|have like this humanoid form factor that
10029.72|2.7|can actually like do stuff in the world
10031.04|4.26|you can have millions of them
10032.42|4.86|interacting with humans and so on and uh
10035.3|3.599|if that doesn't give a rise to AGI at
10037.28|2.82|some point like not I'm not sure what
10038.899|3.301|will
10040.1|4.14|um so from a completeness perspective I
10042.2|4.26|think that's the uh that's a really good
10044.24|4.38|platform but it's a much harder platform
10046.46|3.359|because uh you are dealing with atoms
10048.62|3.18|and you need to actually like build
10049.819|4.141|these things and integrate them into
10051.8|5.099|society so I think that path takes
10053.96|4.56|longer but it's much more certain and
10056.899|3.0|then there's a path of the internet and
10058.52|4.26|just like training these compression
10059.899|4.681|models effectively uh on uh trying to
10062.78|4.8|compress all the internet
10064.58|5.16|and that might also give these agents as
10067.58|4.98|well compress the internet but also
10069.74|4.32|interact with the internet yeah so it's
10072.56|4.259|not obvious to me
10074.06|6.06|in fact I suspect you can reach AGI
10076.819|5.941|without ever entering the physical world
10080.12|5.16|and which is a little bit more
10082.76|4.92|uh concerning because
10085.28|3.42|it might that results in it happening
10087.68|3.48|faster
10088.7|4.38|so it just feels like we're in again
10091.16|2.88|boiling water we won't know as it's
10093.08|4.56|happening
10094.04|5.64|I would like to I'm not afraid of AGI
10097.64|4.38|I'm excited about it there's always
10099.68|3.86|concerns but I would like to know when
10102.02|4.44|it happens
10103.54|5.319|yeah or and have like hints about when
10106.46|4.08|it happens like a year from now it will
10108.859|3.241|happen that kind of thing yeah I just
10110.54|3.66|feel like in the digital realm it just
10112.1|3.719|might happen yeah I think all we have
10114.2|4.199|available to us because no one has built
10115.819|6.0|AGI again so all we have available to us
10118.399|5.101|is uh is there enough for cow ground on
10121.819|3.421|the periphery I would say yes and we
10123.5|4.439|have the progress so far which has been
10125.24|4.38|very rapid and uh there are next steps
10127.939|3.841|that are available and so
10129.62|3.66|I would say uh yeah it's quite likely
10131.78|4.199|that we'll be interacting with digital
10133.28|4.68|entities how will you know that
10135.979|3.181|somebody's birthday it's going to be a
10137.96|2.58|slow I think it's going to be a slow
10139.16|3.0|incremental transition is going to be
10140.54|3.6|product based and focused it's going to
10142.16|4.62|be GitHub co-pilot getting better and
10144.14|4.14|then uh GPT is helping you right and
10146.78|3.539|then these oracles that you can go to
10148.28|4.14|with mathematical problems I think we're
10150.319|3.721|on a on the verge of being able to ask
10152.42|4.26|very complex
10154.04|4.319|questions in chemistry physics math of
10156.68|3.06|these oracles and have them complete
10158.359|3.901|Solutions
10159.74|4.079|so AGI to use primarily focus on
10162.26|2.82|intelligence so Consciousness doesn't
10163.819|3.781|enter
10165.08|4.5|into uh into it
10167.6|3.66|so in my mind Consciousness is not a
10169.58|3.48|special thing you will you will figure
10171.26|4.08|out and bolt-on I think it's an emerging
10173.06|3.06|phenomenon of a large enough and complex
10175.34|4.2|enough
10176.12|5.279|um generative model sort of so
10179.54|4.859|um if you have a complex and Alpha World
10181.399|5.161|model that understands the world then it
10184.399|4.621|also understands its predicament in the
10186.56|3.839|world as being a language model which to
10189.02|3.9|me is a form of Consciousness or
10190.399|3.96|self-awareness and so in order to
10192.92|3.059|understand the world deeply you probably
10194.359|3.841|have to integrate yourself into the
10195.979|4.041|world yeah and in order to interact with
10198.2|4.8|humans and other living beings
10200.02|4.36|Consciousness is a very useful tool I
10203.0|2.78|think Consciousness is like a modeling
10204.38|4.439|insight
10205.78|5.02|modeling Insight yeah it's a you have a
10208.819|2.941|powerful enough model of understanding
10210.8|3.0|the world that you actually understand
10211.76|4.62|that you are an entity in it yeah but
10213.8|4.74|there's also this um perhaps just a
10216.38|3.84|narrative we tell ourselves there's a it
10218.54|3.72|feels like something to experience the
10220.22|3.54|world the hard problem of Consciousness
10222.26|3.0|yeah but that could be just the
10223.76|2.7|narrative that we tell ourselves yeah I
10225.26|2.94|don't think what yeah I think it will
10226.46|3.96|emerge I think it's going to be
10228.2|3.96|something uh very boring like we'll be
10230.42|3.36|talking to these uh digital AIS they
10232.16|3.659|will claim they're conscious they will
10233.78|3.0|appear conscious they will do all the
10235.819|3.421|things that you would expect of other
10236.78|4.74|humans and uh it's going to just be a
10239.24|4.88|stalemate I I think there would be a lot
10241.52|5.94|of actual fascinating ethical questions
10244.12|6.58|like Supreme Court level questions
10247.46|5.88|of whether you're allowed to turn off a
10250.7|4.34|conscious AI if you're allowed to build
10253.34|4.26|the conscious AI
10255.04|5.98|maybe there would have to be the same
10257.6|5.52|kind of debates that you have around
10261.02|5.58|um sorry to bring up a political topic
10263.12|5.66|but you know abortion which is the
10266.6|5.879|deeper question with abortion
10268.78|7.24|is what is life and the Deep question
10272.479|5.641|with AI is also what is life and what is
10276.02|3.72|conscious and I think that'll be very
10278.12|4.5|fascinating
10279.74|6.5|to bring up it might become illegal to
10282.62|6.3|build systems that are capable that like
10286.24|4.18|of such a level of intelligence that
10288.92|3.66|Consciousness would emerge and therefore
10290.42|4.74|the capacity to suffer would emerge and
10292.58|4.62|some A system that says no please don't
10295.16|5.1|kill me well that's what the Lambda
10297.2|4.739|compute the Lambda chatbot already told
10300.26|3.9|um this Google engineer right like it it
10301.939|4.92|was talking about not wanting to die or
10304.16|4.46|so on so that might become illegal to do
10306.859|4.561|that right
10308.62|4.72|I because otherwise you might have a lot
10311.42|4.74|of a lot of creatures that don't want to
10313.34|5.24|die and they will uh you can just spawn
10316.16|4.68|Infinity of them on a cluster
10318.58|4.239|and then that might lead to like
10320.84|3.54|horrible consequences because then there
10322.819|3.54|might be a lot of people that secretly
10324.38|3.72|love murder and they'll start practicing
10326.359|4.561|murder on those systems I mean there's
10328.1|5.04|just I to me all of this stuff just
10330.92|4.559|brings a beautiful mirror to The Human
10333.14|4.62|Condition and human nature we'll get to
10335.479|4.741|explore it and that's what like the best
10337.76|4.679|of uh the Supreme Court of all the
10340.22|3.84|different debates we have about ideas of
10342.439|3.42|what it means to be human we get to ask
10344.06|3.719|those deep questions that we've been
10345.859|4.161|asking throughout human history there's
10347.779|4.981|always been the other in human history
10350.02|4.959|uh we're the good guys and that's the
10352.76|3.78|bad guys and we're going to uh you know
10354.979|4.021|throughout human history let's murder
10356.54|4.8|the bad guys and the same will probably
10359.0|3.54|happen with robots it'll be the other at
10361.34|2.58|first and then we'll get to ask
10362.54|3.3|questions of what does it mean to be
10363.92|4.019|alive what does it mean to be conscious
10365.84|3.36|yeah and I think there's some Canary in
10367.939|2.04|the coal mines even with what we have
10369.2|2.699|today
10369.979|3.661|um and uh you know for example these
10371.899|3.121|there's these like waifus that you like
10373.64|3.0|work with and some people are trying to
10375.02|3.78|like this company is going to shut down
10376.64|4.139|but this person really like yeah love
10378.8|3.96|their waifu and like is trying to like
10380.779|3.901|Port it somewhere else and like it's not
10382.76|4.2|possible and like I think like
10384.68|5.82|definitely uh people will have feelings
10386.96|5.1|towards uh towards these um systems
10390.5|4.2|because in some sense they are like a
10392.06|4.68|mirror of humanity because they are like
10394.7|4.26|sort of like a big average of humanity
10396.74|4.68|yeah in a way that it's trained but we
10398.96|4.92|can that average we can actually watch
10401.42|4.32|it's nice to be able to interact with
10403.88|4.5|the big average of humanity yeah and do
10405.74|5.28|like a search query on it yeah yeah it's
10408.38|4.019|very fascinating and uh we can also of
10411.02|3.12|course also like shape it it's not just
10412.399|2.941|a pure average we can mess with the
10414.14|2.46|training data we can mess with the
10415.34|3.66|objective we can fine tune them in
10416.6|5.339|various ways so we have some
10419.0|6.779|um you know impact on what those systems
10421.939|5.46|look like if you want to achieve AGI
10425.779|4.62|um and you could have a conversation
10427.399|4.741|with her and ask her uh talk about
10430.399|4.08|anything maybe ask her a question what
10432.14|3.48|kind of stuff would you would you ask I
10434.479|4.321|would have some practical questions in
10435.62|5.04|my mind like uh do I or my loved ones
10438.8|3.38|really have to die uh what can we do
10440.66|4.199|about that
10442.18|5.02|do you think it will answer clearly or
10444.859|4.381|would it answer poetically
10447.2|3.36|I would expect it to give Solutions I
10449.24|3.0|would expect it to be like well I've
10450.56|2.94|read all of these textbooks and I know
10452.24|2.46|all these things that you've produced
10453.5|2.46|and it seems to me like here are the
10454.7|3.659|experiments that I think it would be
10455.96|3.479|useful to run next and hear some Gene
10458.359|3.42|therapies that I think would be helpful
10459.439|4.141|and uh here are the kinds of experiments
10461.779|3.361|that you should run okay let's go over
10463.58|6.359|the Start experiment okay
10465.14|8.339|imagine that mortality is actually uh
10469.939|5.88|like a prerequisite for happiness so if
10473.479|5.041|we become immortal we'll actually become
10475.819|4.861|deeply unhappy and the model is able to
10478.52|4.56|know that so what is this supposed to
10480.68|3.9|tell you stupid human about it yes you
10483.08|3.0|can become a mortal but you will become
10484.58|5.22|deeply unhappy
10486.08|5.94|if if the model is if the AGI system
10489.8|4.26|is trying to empathize with you human
10492.02|4.259|what is this supposed to tell you that
10494.06|4.379|yes you don't have to die but you're
10496.279|3.781|really not going to like it because that
10498.439|4.201|is it going to be deeply honest like
10500.06|7.28|there's a Interstellar what is it the AI
10502.64|7.44|says like humans want 90 honesty
10507.34|4.3|so like you have to pick how honest I
10510.08|4.08|want to answer these practical questions
10511.64|4.56|yeah I love Yeah Interstellar by the way
10514.16|3.779|I think it's like such a sidekick to the
10516.2|3.06|entire story but
10517.939|3.481|at the same time it's like really
10519.26|4.019|interesting it's kind of limited in
10521.42|3.42|certain ways right yeah it's limited and
10523.279|3.721|I think that's totally fine by the way I
10524.84|4.38|don't think uh I think it's
10527.0|5.1|find impossible to have a limited and
10529.22|5.4|imperfect agis
10532.1|5.1|is that the feature almost as an example
10534.62|4.92|like it has a fixed amount of compute on
10537.2|4.44|its physical body and it might just be
10539.54|4.5|that even though you can have a super
10541.64|4.139|amazing Mega brain super intelligent AI
10544.04|4.14|you also can have like you know less
10545.779|4.321|intelligent AIS that you can deploy in a
10548.18|3.719|power efficient way and then they're not
10550.1|4.2|perfect they might make mistakes no I
10551.899|4.5|meant more like say you had infinite
10554.3|3.66|compute and it's still good to make
10556.399|3.901|mistakes sometimes
10557.96|3.06|like in order to integrate yourself like
10560.3|2.58|um
10561.02|4.02|what is it going back to Goodwill
10562.88|4.74|Hunting uh Robin Williams character
10565.04|5.46|says like the human imperfections that's
10567.62|5.58|the good stuff right isn't it isn't that
10570.5|6.479|this like we don't want perfect we want
10573.2|5.1|flaws in part to form connections with
10576.979|2.88|each other because it feels like
10578.3|2.46|something you can attach your feelings
10579.859|4.441|to
10580.76|6.42|the the flaws in that same way you want
10584.3|4.26|an AI That's flawed I don't know I feel
10587.18|4.02|like perfectionist but then you're
10588.56|5.16|saying okay yeah but that's not AGI but
10591.2|4.44|see AGI would need to be intelligent
10593.72|3.66|enough to give answers to humans that
10595.64|3.66|humans don't understand and I think
10597.38|4.019|perfect isn't something humans can't
10599.3|4.679|understand because even science doesn't
10601.399|6.181|give perfect answers there's always gabs
10603.979|5.88|and Mysteries and I don't know I I don't
10607.58|4.8|know if humans want perfect
10609.859|4.021|yeah I could imagine just uh having a
10612.38|4.2|conversation with this kind of Oracle
10613.88|4.86|entity as you'd imagine them and uh yeah
10616.58|3.84|maybe it can tell you about
10618.74|4.68|you know based on my analysis of Human
10620.42|4.2|Condition uh you might not want this and
10623.42|4.68|here are some of the things that might
10624.62|7.02|but every every dumb human will say yeah
10628.1|5.16|yeah trust me I can give me the truth I
10631.64|5.6|can handle it but that's the beauty a
10633.26|6.719|lot of people can choose uh so but then
10637.24|5.26|the old marshmallow test with the kids
10639.979|5.46|and so on I feel like too many people
10642.5|5.1|uh like it can't handle the truth
10645.439|3.721|probably including myself like the Deep
10647.6|3.9|truth of The Human Condition I don't I
10649.16|4.5|don't know if I can handle it like what
10651.5|4.68|if there's some dark stuff what if we
10653.66|5.1|are an alien science experiment and it
10656.18|4.74|realizes that what if it had I mean
10658.76|3.679|I mean this is the Matrix you know the
10660.92|4.859|middle over again
10662.439|6.641|I don't know I would what would I talk
10665.779|5.58|about I don't even yeah I
10669.08|4.08|uh probably I will go with the save for
10671.359|4.08|scientific questions at first that have
10673.16|5.52|nothing to do with my own personal life
10675.439|6.481|yeah immortality just like about physics
10678.68|4.92|and so on yeah uh to build up like let's
10681.92|3.6|see where it's at or maybe see if it has
10683.6|4.44|a sense of humor that's another question
10685.52|4.62|would it be able to uh presumably in
10688.04|4.22|order to if it understands humans deeply
10690.14|5.88|would able to generate
10692.26|5.559|uh yep to generate humor yeah I think
10696.02|3.959|that's actually a wonderful Benchmark
10697.819|4.321|almost like is it able I think that's a
10699.979|3.721|really good point basically to make you
10702.14|3.12|laugh yeah if it's able to be like a
10703.7|2.46|very effective stand-up comedian that is
10705.26|2.58|doing something very interesting
10706.16|4.14|computationally I think being funny is
10707.84|4.139|extremely hard yeah
10710.3|4.92|because
10711.979|5.821|it's hard in a way like a touring test
10715.22|4.259|the original intent of the touring test
10717.8|5.28|is hard because you have to convince
10719.479|5.761|humans and there's nothing that's why
10723.08|4.56|that's why when comedians talk about
10725.24|4.5|this like there's this is deeply honest
10727.64|3.66|because if people can't help but laugh
10729.74|3.18|and if they don't laugh that means
10731.3|3.24|you're not funny they laugh that's funny
10732.92|3.42|and you're showing you need a lot of
10734.54|3.359|knowledge to create to create humor
10736.34|2.82|about like the occupational Human
10737.899|3.0|Condition and so on and then you need to
10739.16|3.48|be clever with it
10740.899|3.901|uh you mentioned a few movies you
10742.64|5.339|tweeted movies that I've seen five plus
10744.8|5.46|times but I'm ready and willing to keep
10747.979|4.5|watching Interstellar Gladiator contact
10750.26|5.28|Goodwill Hunting The Matrix Lord of the
10752.479|5.761|Rings all three Avatar Fifth Element so
10755.54|4.399|on goes on Terminator two Mean Girls I'm
10758.24|5.159|not gonna ask about that
10759.939|5.621|mean girls is great
10763.399|4.08|um what are some of the jump onto your
10765.56|5.219|memory that you love
10767.479|5.281|and why like you mentioned the Matrix
10770.779|3.481|as a computer person why do you love The
10772.76|3.0|Matrix
10774.26|2.76|there's so many properties that make it
10775.76|2.58|like beautiful and interesting so
10777.02|3.959|there's all these philosophical
10778.34|5.04|questions but then there's also agis and
10780.979|4.861|there's simulation and it's cool and
10783.38|4.32|there's you know the black uh you know
10785.84|3.599|uh the look of it the feel of it the
10787.7|3.42|look of it the feel of it the action the
10789.439|3.781|bullet time it was just like innovating
10791.12|5.159|in so many ways
10793.22|5.46|and then uh Good Good Will Hunting why
10796.279|5.281|do you like that one yeah I just I
10798.68|5.16|really like this uh torture genius sort
10801.56|4.08|of character who's like grappling with
10803.84|3.54|whether or not he has like any
10805.64|3.54|responsibility or like what to do with
10807.38|4.26|this gift that he was given or like how
10809.18|4.2|to think about the whole thing and uh
10811.64|5.04|there's also a dance between the genius
10813.38|4.92|and the the personal like what it means
10816.68|3.06|to love another human being and there's
10818.3|2.88|a lot of themes there it's just a
10819.74|3.3|beautiful movie and then the fatherly
10821.18|4.08|figure The Mentor in the in the
10823.04|3.06|psychiatrist and the it like really like
10825.26|2.4|uh
10826.1|2.759|it messes with you you know there's some
10827.66|4.26|movies that's just like really mess with
10828.859|6.481|you uh on a deep level do you relate to
10831.92|5.76|that movie at all no it's not your fault
10835.34|5.639|doctor as I said Lord of the Rings
10837.68|4.92|that's self-explanatory Terminator 2
10840.979|3.721|which is interesting
10842.6|3.42|you we watch that a lot is that better
10844.7|3.06|than Terminator one
10846.02|4.379|you like you like Arnold I do like
10847.76|4.44|Terminator one as well uh I like
10850.399|3.291|Terminator 2 a little bit more but in
10852.2|3.42|terms of like its surface properties
10853.69|3.91|[Laughter]
10855.62|4.26|do you think Skynet is at all a
10857.6|4.98|possibility oh yes
10859.88|4.92|well like the actual sort of uh
10862.58|6.319|autonomous uh weapon system kind of
10864.8|4.099|thing do you worry about that uh stuff
10869.3|4.679|I 100 worry about it and so the I mean
10872.0|3.72|the uh you know some of these uh fears
10873.979|2.761|of AGS and how this will plan out I mean
10875.72|3.599|these will be like very powerful
10876.74|3.72|entities probably at some point and so
10879.319|3.061|um for a long time they're going to be
10880.46|3.72|tools in the hands of humans uh you know
10882.38|3.84|people talk about like alignment of agis
10884.18|4.799|and how to make the problem is like even
10886.22|4.8|humans are not aligned uh so
10888.979|4.141|uh how this will be used and what this
10891.02|3.36|is going to look like is um yeah it's
10893.12|3.42|troubling so
10894.38|4.08|do you think it'll happen so slowly
10896.54|4.56|enough that we'll be able to
10898.46|4.5|as a human civilization think through
10901.1|3.9|the problems yes that's my hope is that
10902.96|3.899|it happens slowly enough and in an open
10905.0|3.96|enough way where a lot of people can see
10906.859|4.201|and participate in it just figure out
10908.96|3.72|how to deal with this transition I think
10911.06|3.18|which is going to be interesting I draw
10912.68|4.02|a lot of inspiration from nuclear
10914.24|4.92|weapons because I sure thought it would
10916.7|4.56|be it would be fucked once they develop
10919.16|3.5|nuclear weapons but like it's almost
10921.26|4.92|like
10922.66|4.6|uh when the when the systems are not so
10926.18|3.0|dangerous they destroy human
10927.26|4.98|civilization we deploy them and learn
10929.18|4.799|the lessons and then we quickly if it's
10932.24|4.199|too dangerous we're quickly quicker we
10933.979|4.141|might still deploy it uh but you very
10936.439|3.061|quickly learn not to use them and so
10938.12|3.96|there'll be like this balance that you
10939.5|5.399|humans are very clever as a species it's
10942.08|4.68|interesting we exploit the resources as
10944.899|4.141|much as we can but we don't we avoid
10946.76|4.32|destroying ourselves it seems like
10949.04|3.54|well I don't know about that actually I
10951.08|2.46|hope it continues
10952.58|2.46|um
10953.54|3.779|I mean I'm definitely like concerned
10955.04|4.08|about nuclear weapons and so on not just
10957.319|4.261|as a result of the recent conflict even
10959.12|4.739|before that uh that's probably like my
10961.58|5.88|number one concern for society so if
10963.859|6.96|Humanity uh destroys itself
10967.46|6.54|or destroys you know 90 of people that
10970.819|4.5|would be because of nukes I think so
10974.0|3.24|um and it's not even about full
10975.319|3.241|destruction to me it's bad enough if we
10977.24|3.36|reset society that would be like
10978.56|4.379|terrible it would be really bad and I
10980.6|5.1|can't believe we're like so close to it
10982.939|4.5|yeah it's like so crazy to me it feels
10985.7|4.38|like we might be a few tweets away from
10987.439|5.161|something like that yep basically it's
10990.08|4.02|extremely unnerving but and has been for
10992.6|5.879|me for a long time
10994.1|6.54|it seems unstable that world leaders
10998.479|4.261|just having a bad mood
11000.64|4.259|can like um
11002.74|6.239|take one step towards a bad Direction
11004.899|6.42|and it escalates yeah and because of a
11008.979|4.021|collection of bad moods it can escalate
11011.319|3.12|without being able to
11013.0|3.54|um stop
11014.439|4.141|yeah it's just it's a huge amount of uh
11016.54|3.84|Power and then also with the
11018.58|3.66|proliferation and basically I don't I
11020.38|2.939|don't actually really see I don't
11022.24|1.88|actually know what the good outcomes are
11023.319|2.821|here
11024.12|4.06|uh so I'm definitely worried about that
11026.14|3.9|a lot and then AGI is not currently
11028.18|4.62|there but I think at some point we'll
11030.04|5.64|more and more become uh something like
11032.8|4.5|it the danger with AGI even is that I
11035.68|2.94|think it's even less likely worse in a
11037.3|4.38|sense that
11038.62|4.68|uh there are good outcomes of AGI and
11041.68|3.96|then the bad outcomes are like an
11043.3|4.8|absolute way like a tiny one way and so
11045.64|4.5|I think um capitalism and humanity and
11048.1|4.14|so on will drive for the positive
11050.14|3.54|uh ways of using that technology but
11052.24|4.44|then if bad outcomes are just like a
11053.68|4.86|tiny like flipping minus sign away uh
11056.68|3.96|that's a really bad position to be in a
11058.54|4.14|tiny perturbation of the system results
11060.64|4.98|in the destruction of the human species
11062.68|4.08|it's a weird line to walk yeah I think
11065.62|2.699|in general what's really weird about
11066.76|3.0|like the Dynamics of humanity and this
11068.319|3.481|explosion was talked about is just like
11069.76|4.5|the insane coupling afforded by
11071.8|4.019|technology yeah and uh just the
11074.26|3.66|instability of the whole dynamical
11075.819|3.181|system I think it's just it doesn't look
11077.92|3.18|good honestly
11079.0|3.54|yes that explosion could be destructive
11081.1|4.259|and constructive and the probabilities
11082.54|4.5|are non-zero in both both senses I'm
11085.359|3.481|going to have to I do feel like I have
11087.04|3.6|to try to be optimistic and so on and
11088.84|3.3|yes I think even in this case I still am
11090.64|2.88|predominantly optimistic but there's
11092.14|3.78|definitely
11093.52|5.04|me too uh do you think we'll become a
11095.92|4.5|multiplayer species
11098.56|4.7|probably yes but I don't know if it's
11100.42|5.82|dominant feature of uh future Humanity
11103.26|4.3|uh there might be some people on some
11106.24|2.28|planets and so on but I'm not sure if
11107.56|3.24|it's like
11108.52|5.22|yeah if it's like a major player in our
11110.8|5.34|culture and so on we still have to solve
11113.74|4.86|the drivers of self-destruction here on
11116.14|4.679|Earth so just having a backup on Mars is
11118.6|3.6|not going to solve the problem so by the
11120.819|2.881|way I love the backup on Mars I think
11122.2|4.8|that's amazing you should absolutely do
11123.7|6.18|that yes and I'm so thankful uh and
11127.0|5.22|would you go to Mars uh personally no I
11129.88|4.439|do like Earth quite a lot okay uh I'll
11132.22|3.9|go to Mars I'll go for you unless I'll
11134.319|3.721|tweet at you from there maybe eventually
11136.12|3.359|I would once it's uh safe enough but I
11138.04|3.54|don't actually know if it's on my
11139.479|3.361|lifetime scale unless I can extend it by
11141.58|2.819|a lot
11142.84|3.42|I do think that for example a lot of
11144.399|3.301|people might disappear into
11146.26|2.58|um virtual realities and stuff like that
11147.7|2.579|and I think that could be the major
11148.84|2.82|thrust of
11150.279|4.141|um sort of the cultural development of
11151.66|4.68|humanity if it survives uh so it might
11154.42|4.38|not be it's just really hard to work in
11156.34|3.78|Physical Realm and go out there and I
11158.8|4.32|think ultimately all your experiences
11160.12|5.46|are in your brain yeah and so it's much
11163.12|4.02|easier to disappear into digital Realm
11165.58|4.199|and I think people will find them more
11167.14|4.38|compelling easier safer
11169.779|3.601|more interesting so you're a little bit
11171.52|3.419|captivated by Virtual Reality by the
11173.38|3.24|possible worlds whether it's the
11174.939|3.181|metaverse or some other manifestation of
11176.62|4.62|that yeah
11178.12|6.06|yeah it's really interesting it's uh
11181.24|5.82|I'm I'm interested just just talking a
11184.18|4.32|lot to Carmack where's the
11187.06|3.66|where's the thing that's currently
11188.5|3.54|preventing that yeah I mean to be clear
11190.72|2.94|I think what's interesting about the
11192.04|3.18|future is
11193.66|3.119|um it's not that
11195.22|2.94|I kind of feel like
11196.779|3.181|the variance in The Human Condition
11198.16|4.14|grows that's the primary thing that's
11199.96|3.6|changing it's not as much the mean of
11202.3|2.639|the distribution it's like the variance
11203.56|3.06|of it so there will probably be people
11204.939|2.821|on Mars and there will be people in VR
11206.62|2.58|and they're all people here on Earth
11207.76|3.12|it's just like there will be so many
11209.2|3.18|more ways of being
11210.88|2.82|and so I kind of feel like I see it as
11212.38|3.42|like a spreading out of a human
11213.7|3.3|experience there's something about the
11215.8|3.0|internet that allows you to discover
11217.0|3.359|those little groups and you you
11218.8|3.24|gravitate each other something about
11220.359|3.241|your biology likes that kind of world
11222.04|3.06|and that you find each other yeah and
11223.6|2.58|we'll have transhumanists and then we'll
11225.1|2.759|have the Amish and they're gonna
11226.18|2.759|everything is just gonna coexist you
11227.859|2.58|know the cool thing about it because
11228.939|3.721|I've interacted with a bunch of Internet
11230.439|5.34|communities is
11232.66|5.52|um they don't know about each other like
11235.779|4.021|you can have a very happy existence just
11238.18|3.42|like having a very close-knit community
11239.8|3.84|and not knowing about each other I mean
11241.6|4.799|even even since this just having
11243.64|5.04|traveled to Ukraine there's they they
11246.399|4.981|don't know so many things about America
11248.68|4.44|you you like when you travel across the
11251.38|3.18|world I think you experience this too
11253.12|3.12|there are certain cultures they're like
11254.56|4.56|they have their own thing going on they
11256.24|4.26|don't and so you can see that happening
11259.12|3.3|more and more and more and more in the
11260.5|3.779|future we have little communities yeah
11262.42|3.84|yeah I think so that seems to be the
11264.279|3.601|that seems to be how it's going right
11266.26|3.24|now and I don't see that Trend like
11267.88|3.42|really reversing I think people are
11269.5|3.96|diverse and they're able to choose their
11271.3|4.019|own like path and existence and I sort
11273.46|4.2|of like celebrate that
11275.319|4.861|um and so will you spend so much time in
11277.66|4.38|the meters in the virtual reality or
11280.18|5.219|which Community are you are you the
11282.04|6.96|physicalist uh the the the physical
11285.399|6.361|reality enjoyer or uh do you see drawing
11289.0|4.26|a lot of uh pleasure and fulfillment in
11291.76|3.66|the digital world
11293.26|4.44|yeah I think well currently the virtual
11295.42|4.14|reality is not that compelling I do
11297.7|4.32|think it can improve a lot but I don't
11299.56|3.66|really know to what extent maybe you
11302.02|2.52|know there's actually like even more
11303.22|5.46|exotic things you can think about with
11304.54|5.64|like neural links or stuff like that so
11308.68|3.96|um currently I kind of see myself as
11310.18|5.06|mostly a team human person I love nature
11312.64|6.06|yeah I love Harmony I love people I love
11315.24|6.4|Humanity I love emotions of humanity
11318.7|4.92|um and I I just want to be like in this
11321.64|4.38|like solar Punk little Utopia that's my
11323.62|4.199|happy place yeah my happy place is like
11326.02|3.78|uh people I love thinking about cool
11327.819|4.681|problems surrounded by a lush beautiful
11329.8|4.86|Dynamic nature yeah yeah and secretly
11332.5|5.279|high tech in places that count places
11334.66|6.239|like they use technology to empower that
11337.779|4.441|love for other humans and nature yeah I
11340.899|3.481|think a technology used like very
11342.22|3.9|sparingly uh I don't love when it sort
11344.38|4.979|of gets in the way of humanity in many
11346.12|5.04|ways uh I like just people being humans
11349.359|3.361|in a way we sort of like slightly
11351.16|3.54|evolved and prefer I think just by
11352.72|3.78|default people kept asking me because
11354.7|3.42|they they know you love reading are
11356.5|4.439|there particular books
11358.12|3.72|that you enjoyed that had an impact on
11360.939|4.321|you
11361.84|5.099|for silly or for profound reasons that
11365.26|3.9|you would recommend
11366.939|4.38|you mentioned the vital question
11369.16|3.72|many of course I think in biology as an
11371.319|4.261|example the vital question is a good one
11372.88|4.399|anything by McLean really uh life
11375.58|4.8|ascending I would say is like a bit more
11377.279|4.361|potentially uh representative as like a
11380.38|3.059|summary
11381.64|4.02|of a lot of the things he's been talking
11383.439|3.96|about I was very impacted by the selfish
11385.66|3.6|Gene I thought that was a really good
11387.399|3.301|book that helped me understand altruism
11389.26|3.0|as an example and where it comes from
11390.7|3.119|and just realizing that you know the
11392.26|3.3|selection is in the level of genes was a
11393.819|2.821|huge insight for me at the time and it
11395.56|2.94|sort of like cleared up a lot of things
11396.64|4.92|for me what do you think about
11398.5|4.6|the the idea that ideas of the organisms
11401.56|4.2|the means yes love it 100
11403.1|4.64|[Laughter]
11405.76|5.099|are you able to walk around with that
11407.74|5.039|notion for a while that that there is an
11410.859|3.42|evolutionary kind of process with ideas
11412.779|3.721|as well there absolutely is there's
11414.279|4.321|memes just like genes and they compete
11416.5|4.56|and they live in our brains it's
11418.6|4.14|beautiful are we silly humans thinking
11421.06|3.2|that we're the organisms is it possible
11422.74|4.26|that the primary
11424.26|4.719|organisms are the ideas
11427.0|3.779|yeah I would say like the the ideas kind
11428.979|4.5|of live in the software of like our
11430.779|5.16|civilization in the in the minds and so
11433.479|6.0|on we think as humans that the hardware
11435.939|5.821|is the fundamental thing I human is a
11439.479|5.041|hardware entity yeah but it could be the
11441.76|4.5|software right yeah
11444.52|3.419|yeah I would say like there needs to be
11446.26|3.84|some grounding at some point to like a
11447.939|4.281|physical reality yeah but if we clone an
11450.1|2.12|Andre
11452.319|4.681|the software is the thing
11454.479|4.321|like is this thing that makes that thing
11457.0|3.42|special right yeah I guess I you're
11458.8|3.36|right but then cloning might be
11460.42|3.0|exceptionally difficult like there might
11462.16|3.06|be a deep integration between the
11463.42|3.359|software and the hardware in ways we
11465.22|2.94|don't quite understand well from the
11466.779|3.601|evolution point of view like what makes
11468.16|4.56|me special is more like the the gang of
11470.38|3.84|genes that are writing in my chromosomes
11472.72|3.599|I suppose right like they're the they're
11474.22|3.84|the replicating unit I suppose and no
11476.319|5.46|but that's just for you the thing that
11478.06|7.259|makes you special sure wow
11481.779|6.481|the reality is what makes you special is
11485.319|5.881|your ability to survive
11488.26|5.76|based on the software that runs on the
11491.2|4.14|hardware that was built by the genes
11494.02|3.18|um so the software is the thing that
11495.34|4.5|makes you survive not the hardware
11497.2|4.5|all right yeah it's just like a second
11499.84|3.3|layer it's a new second layer that
11501.7|3.18|hasn't been there before the brain they
11503.14|4.02|both they both coexist but there's also
11504.88|5.76|layers of the software I mean it's it's
11507.16|5.819|not it's a it's a abstraction that's uh
11510.64|5.52|on top of abstractions but okay so
11512.979|5.46|selfish Gene um a neckline I would say
11516.16|5.159|sometimes books are like not sufficient
11518.439|5.04|I like to reach for textbooks sometimes
11521.319|3.601|um I kind of feel like books are for too
11523.479|3.721|much of a general consumption sometime
11524.92|3.54|and they just kind of like uh they're
11527.2|3.18|too high up in the level of abstraction
11528.46|4.5|and it's not good enough yeah so I like
11530.38|3.96|textbooks I like the cell I think the
11532.96|4.08|cell was pretty cool
11534.34|4.92|uh that's why also I like the writing of
11537.04|6.0|uh McLean is because he's pretty willing
11539.26|5.4|to step one level down and he doesn't uh
11543.04|2.46|yeah he's sort of he's willing to go
11544.66|2.52|there
11545.5|3.12|but he's also willing to sort of be
11547.18|3.12|throughout the stack so he'll go down to
11548.62|4.199|a lot of detail but then he will come
11550.3|4.2|back up and I think he has a yeah
11552.819|3.66|basically I really appreciate that
11554.5|4.26|that's why I love college early college
11556.479|4.981|even high school but just textbooks on
11558.76|5.34|the basics yeah of Computer Science and
11561.46|6.42|Mathematics of of biology of chemistry
11564.1|6.12|yes those are they condense down like uh
11567.88|3.72|uh it's sufficiently General that you
11570.22|3.059|can understand the both the philosophy
11571.6|4.14|and the details but also like you get
11573.279|4.5|homework problems and you you get to
11575.74|4.5|play with it as much as you would if you
11577.779|3.781|weren't yeah programming stuff yeah and
11580.24|3.239|then I'm also suspicious of textbooks
11581.56|3.839|honestly because as an example in deep
11583.479|3.3|learning uh there's no like amazing
11585.399|3.301|textbooks and I feel this changing very
11586.779|4.981|quickly I imagine the same is true and
11588.7|4.44|say uh synthetic biology and so on these
11591.76|2.94|books like this cell are kind of
11593.14|3.12|outdated they're still high level like
11594.7|3.779|what is the actual real source of truth
11596.26|4.74|it's people in wet Labs working with
11598.479|4.201|cells yeah you know sequencing genomes
11601.0|3.54|and
11602.68|3.78|yeah actually working with working with
11604.54|3.42|it and uh I don't have that much
11606.46|3.3|exposure to that or what that looks like
11607.96|3.0|so I sold them fully I'm reading through
11609.76|2.519|the cell and it's kind of interesting
11610.96|2.819|and I'm learning but it's still not
11612.279|3.66|sufficient I would say in terms of
11613.779|3.781|understanding well it's a clean
11615.939|2.641|summarization of the mainstream
11617.56|3.299|narrative
11618.58|4.859|yeah but you have to learn that before
11620.859|4.381|you break out yeah towards The Cutting
11623.439|3.0|Edge yeah what is the actual process of
11625.24|3.36|working with these cells and growing
11626.439|3.301|them and incubating them and you know
11628.6|3.06|it's kind of like a massive cooking
11629.74|2.94|recipe so making sure your self slows
11631.66|2.76|and proliferate and then you're
11632.68|3.9|sequencing them running experiments and
11634.42|3.66|uh just how that works I think is kind
11636.58|3.18|of like the source of truth of at the
11638.08|3.6|end of the day what's really useful in
11639.76|4.559|terms of creating therapies and so on
11641.68|4.139|yeah I wonder in the future AI textbooks
11644.319|3.0|will be because you know there's a
11645.819|3.781|artificial intelligence a modern
11647.319|4.381|approach I actually haven't read if it's
11649.6|4.32|come out the recent version the recent
11651.7|4.079|there's been a recent Edition I also saw
11653.92|3.479|there's a science a deep learning book
11655.779|3.54|I'm waiting for textbooks that worth
11657.399|4.621|recommending worth reading it's It's
11659.319|6.061|tricky because it's like papers
11662.02|5.1|and code code honestly papers are quite
11665.38|3.72|good I especially like the appendix
11667.12|5.359|appendix of any paper as well it's like
11669.1|6.0|it's like the most detail it can have
11672.479|3.821|it doesn't have to be cohesive to
11675.1|2.94|connected to anything else you just
11676.3|3.24|describe me a very specific way you
11678.04|2.76|solved a particular thing yeah many
11679.54|3.3|times papers can be actually quite
11680.8|3.42|readable not always but sometimes the
11682.84|3.479|introduction in the abstract is readable
11684.22|3.78|even for someone outside of the field uh
11686.319|2.821|not this is not always true and
11688.0|3.42|sometimes I think unfortunately
11689.14|4.08|scientists use complex terms even when
11691.42|3.84|it's not necessary I think that's
11693.22|4.62|harmful I think there there's no reason
11695.26|4.139|for that and papers sometimes are longer
11697.84|2.58|than they need to be in this in the
11699.399|3.96|parts that
11700.42|4.8|don't matter yeah appendix would be long
11703.359|3.601|but then the paper itself you know look
11705.22|3.0|at Einstein make it simple
11706.96|2.939|yeah but certainly I've come across
11708.22|3.179|papers I would say in say like synthetic
11709.899|2.88|biology or something that I thought were
11711.399|2.761|quite readable for the abstract and the
11712.779|2.761|introduction and then you're reading the
11714.16|2.76|rest of it and you don't fully
11715.54|4.16|understand but you kind of are getting a
11716.92|6.24|gist and I think it's cool
11719.7|5.14|what uh advice you give advice to folks
11723.16|4.14|interested in machine learning and
11724.84|4.979|research but in General Life advice to a
11727.3|4.74|young person High School
11729.819|3.901|um Early College about how to have a
11732.04|3.42|career they can be proud of or a life
11733.72|3.66|they can be proud of
11735.46|3.359|yeah I think I'm very hesitant to give
11737.38|2.7|general advice I think it's really hard
11738.819|2.881|I've mentioned like some of the stuff
11740.08|3.18|I've mentioned is fairly General I think
11741.7|3.659|like focus on just the amount of work
11743.26|4.26|you're spending on like a thing
11745.359|3.781|uh compare yourself only to yourself not
11747.52|4.259|to others that's good I think those are
11749.14|4.679|fairly General how do you pick the thing
11751.779|4.681|uh you just have like a deep interest in
11753.819|4.62|something uh or like try to like find
11756.46|3.479|the art Max over like the things that
11758.439|3.181|you're interested in ARG Max at that
11759.939|4.201|moment and stick with it how do you not
11761.62|6.3|get distracted and switch to another
11764.14|6.06|thing uh you can if you like
11767.92|4.62|um well if you do an ARG Max repeatedly
11770.2|3.72|every week it doesn't converge it
11772.54|3.359|doesn't it's a problem yeah you can like
11773.92|3.96|low pass filter yourself uh in terms of
11775.899|3.181|like what has consistently been true for
11777.88|3.96|you
11779.08|4.02|um but yeah I definitely see how it can
11781.84|2.639|be hard but I would say like you're
11783.1|3.719|going to work the hardest on the thing
11784.479|3.541|that you care about the most also a low
11786.819|3.601|pass filter yourself and really
11788.02|3.66|introspect in your past were the things
11790.42|2.88|that gave you energy and what are the
11791.68|4.44|things that took energy away from you
11793.3|3.9|concrete examples and usually uh from
11796.12|3.779|those concrete examples sometimes
11797.2|3.84|patterns can merge I like I like it when
11799.899|2.641|things look like this when I'm these
11801.04|3.0|positions so that's not necessarily the
11802.54|3.72|field but the kind of stuff you're doing
11804.04|4.08|in a particular field so for you it
11806.26|3.719|seems like you were energized by
11808.12|4.8|implementing stuff building actual
11809.979|5.281|things yeah being low level learning and
11812.92|3.42|then also uh communicating so that
11815.26|3.66|others can go through the same
11816.34|4.2|realizations and shortening that Gap
11818.92|3.059|um because I usually have to do way too
11820.54|2.76|much work to understand the thing and
11821.979|3.241|then I'm like okay this is actually like
11823.3|4.32|okay I think I get it and like why was
11825.22|4.86|it so much work it should have been much
11827.62|4.02|less work and that gives me a lot of
11830.08|3.779|frustration and that's why I sometimes
11831.64|5.0|go teach so aside from the teaching
11833.859|6.661|you're doing now uh putting out videos
11836.64|4.78|aside from a potential uh Godfather part
11840.52|4.379|two
11841.42|5.34|uh with the AGI at Tesla and Beyond uh
11844.899|3.721|what does the future for Android kapati
11846.76|4.92|hold have you figured that out yet or no
11848.62|6.48|I mean uh as you see through the fog of
11851.68|5.34|war that is all of our future
11855.1|3.54|um do you do you start seeing
11857.02|3.78|silhouettes of the what that possible
11858.64|3.6|future could look like
11860.8|3.66|the consistent thing I've been always
11862.24|4.079|interested in for me at least is is AI
11864.46|3.84|and um
11866.319|3.66|uh that's probably where I'm spending my
11868.3|3.599|rest of my life on because I just care
11869.979|3.661|about a lot and I actually care about
11871.899|3.661|like many other problems as well like
11873.64|4.56|say aging which I basically view as
11875.56|3.9|disease and uh
11878.2|3.18|um I care about that as well but I don't
11879.46|4.2|think it's a good idea to go after it
11881.38|4.26|specifically I don't actually think that
11883.66|3.659|humans will be able to come up with the
11885.64|3.66|answer I think the correct thing to do
11887.319|3.66|is to ignore those problems and you
11889.3|3.179|solve Ai and then use that to solve
11890.979|2.641|everything else and I think there's a
11892.479|3.721|chance that this will work I think it's
11893.62|5.1|a very high chance and uh that's kind of
11896.2|4.32|like the the way I'm betting at least so
11898.72|4.2|when you think about AI are you
11900.52|5.879|interested in all kinds of applications
11902.92|5.76|all kinds of domains and any domain you
11906.399|4.08|focus on will allow you to get insights
11908.68|3.48|to the big problem of AGI yeah for me
11910.479|3.0|it's the ultimate mental problem I don't
11912.16|2.88|want to work on any one specific problem
11913.479|3.361|there's too many problems so how can you
11915.04|3.779|work on all problems simultaneously you
11916.84|3.92|solve The Meta problem which to me is
11918.819|5.221|just intelligence and how do you
11920.76|6.519|automate it is there cool small projects
11924.04|5.58|like archive sanity and and so on that
11927.279|5.7|you're thinking about the the the the
11929.62|4.92|world the ml world can anticipate
11932.979|3.621|there's some always like some fun side
11934.54|3.72|projects yeah um archive sanity is one
11936.6|4.06|basically like there's way too many
11938.26|4.679|archive papers how can I organize it and
11940.66|4.14|recommend papers and so on uh I
11942.939|3.301|transcribed all of your yeah podcasts
11944.8|5.28|what did you learn from that experience
11946.24|5.64|uh from transcribing the process of like
11950.08|3.72|you like consuming audiobooks and and
11951.88|4.38|podcasts and so on and here's the
11953.8|4.74|process that achieves
11956.26|4.32|um closer to human level performance and
11958.54|3.72|annotation yeah well I definitely was
11960.58|4.14|like surprised that uh transcription
11962.26|4.139|with opening eyes whisper was working so
11964.72|4.259|well compared to what I'm familiar with
11966.399|5.04|from Siri and like a few other systems I
11968.979|4.8|guess it works so well and
11971.439|3.901|uh that's what gave me some energy to
11973.779|3.601|like try it out and I thought it could
11975.34|5.16|be fun to random podcasts it's kind of
11977.38|4.14|not obvious to me why whisper is so much
11980.5|2.16|better compared to anything else because
11981.52|2.4|I feel like there should be a lot of
11982.66|2.699|incentive for a lot of companies to
11983.92|3.18|produce transcription systems and that
11985.359|3.481|they've done so over a long time whisper
11987.1|4.62|is not a super exotic model it's a
11988.84|5.28|Transformer it takes smell spectrograms
11991.72|4.559|and you know just outputs tokens of text
11994.12|3.12|it's not crazy uh the model and
11996.279|2.04|everything has been around for a long
11997.24|3.36|time
11998.319|4.741|I'm not actually 100 sure why yeah it's
12000.6|3.96|not obvious to me either it makes me
12003.06|3.839|feel like I'm missing something I'm
12004.56|5.16|missing something yeah because there's a
12006.899|4.441|huge even at Google and so on YouTube uh
12009.72|3.719|transcription yeah
12011.34|3.86|um yeah it's unclear but some of it is
12013.439|5.34|also integrating into a bigger system
12015.2|4.659|yeah that so the user interface how it's
12018.779|3.781|deployed and all that kind of stuff
12019.859|4.92|maybe running it as an independent thing
12022.56|3.839|is eat much easier like an order of
12024.779|3.66|magnitude easier than deploying to a
12026.399|4.38|large integrated system like YouTube
12028.439|4.261|transcription or
12030.779|4.981|um anything like meetings like Zoom has
12032.7|5.579|trans transcription that's kind of
12035.76|3.84|crappy but creating uh interface where
12038.279|4.021|it detects the different individual
12039.6|3.36|speakers it's able to
12042.3|4.019|um
12042.96|4.92|display it in compelling ways Run in
12046.319|4.201|real time all that kind of stuff maybe
12047.88|5.04|that's difficult but that's the only
12050.52|5.339|explanation I have because like um
12052.92|5.22|I'm currently paying uh quite a bit for
12055.859|5.701|human uh transcription human caption
12058.14|5.46|right annotation and like it seems like
12061.56|3.78|uh there's a huge incentive to automate
12063.6|2.94|that yeah it's very confusing and I
12065.34|2.639|think I mean I don't know if you looked
12066.54|3.899|at some of the whisper transcripts but
12067.979|4.741|they're quite good they're good and
12070.439|3.141|especially in tricky cases yeah I've
12072.72|3.719|seen
12073.58|4.84|uh Whispers performance on like super
12076.439|4.141|tricky cases and it does incredibly well
12078.42|5.46|so I don't know a podcast is pretty
12080.58|5.58|simple it's like high quality audio and
12083.88|5.22|you're speaking usually pretty clearly
12086.16|6.119|and so I don't know it uh I don't know
12089.1|4.679|what open ai's plans are yeah either but
12092.279|3.481|yeah there's always like fun fun
12093.779|3.66|projects basically and stable diffusion
12095.76|2.94|also is opening up a huge amount of
12097.439|2.88|experimentation I would say in the
12098.7|5.04|visual realm and generate generating
12100.319|4.681|images and videos and movies videos now
12103.74|3.119|and so that's going to be pretty crazy
12105.0|4.08|uh that's going to that's going to
12106.859|4.141|almost certainly work and it's going to
12109.08|3.239|be really interesting when the cost of
12111.0|3.359|content creation is going to fall to
12112.319|3.721|zero you used to need a painter for a
12114.359|3.661|few months to paint a thing and now it's
12116.04|4.439|going to be speak to your phone to get
12118.02|5.72|your video so if Hollywood will start
12120.479|6.0|using that to generate scene means
12123.74|5.4|which completely opens up yeah so you
12126.479|5.46|can make a like a movie like Avatar
12129.14|5.02|eventually for under a million dollars
12131.939|3.901|much less maybe just by talking to your
12134.16|2.72|phone I mean I know it sounds kind of
12135.84|3.059|crazy
12136.88|3.939|and then there'd be some voting
12138.899|3.841|mechanism like how do you have a like
12140.819|4.821|would there be a show on Netflix that's
12142.74|5.4|generated completely uh automatedly
12145.64|4.24|potentially yeah and what does it look
12148.14|4.74|like also when you can just generate It
12149.88|5.78|On Demand and it's uh and there's
12152.88|5.099|Infinity of it yeah
12155.66|4.239|oh man
12157.979|4.141|all the synthetic content I mean it's
12159.899|3.841|humbling because we we treat ourselves
12162.12|3.739|as special for being able to generate
12163.74|5.1|art and ideas and all that kind of stuff
12165.859|5.861|if that can be done in an automated Way
12168.84|5.099|by AI yeah I think it's fascinating to
12171.72|3.24|me how these uh the predictions of AI
12173.939|2.161|and what it's going to look like and
12174.96|3.18|what it's going to be capable of are
12176.1|4.02|completely inverted and wrong and the
12178.14|4.2|Sci-Fi of 50s and 60s was just like
12180.12|4.62|totally not bright they imagined AI is
12182.34|3.72|like super calculating theore improvers
12184.74|4.02|and we're getting things that can talk
12186.06|4.919|to you about emotions they can do art
12188.76|5.82|it's just like weird are you excited
12190.979|6.361|about that feature just ai's like hybrid
12194.58|5.399|systems heterogeneous systems of humans
12197.34|5.099|and AIS talking about emotions Netflix
12199.979|3.901|and chill with an AI system legit where
12202.439|3.481|the Netflix thing you watch is also
12203.88|3.54|generated by AI
12205.92|4.26|I think it's uh it's going to be
12207.42|4.74|interesting for sure and I think I'm
12210.18|3.36|cautiously optimistic but it's not it's
12212.16|3.36|not obvious
12213.54|6.359|well the sad thing is your brain and
12215.52|7.02|mine developed in a time where
12219.899|4.441|um before Twitter before the before the
12222.54|3.72|internet so I wonder people that are
12224.34|3.36|born inside of it might have a different
12226.26|4.2|experience
12227.7|5.64|um like I maybe you can will still
12230.46|4.14|resist it uh and the people born now
12233.34|2.939|will not
12234.6|3.66|well I do feel like humans are extremely
12236.279|4.5|malleable yeah
12238.26|5.96|and uh you're probably right
12240.779|6.421|what is the meaning of life Andre
12244.22|4.96|we we talked about sort of
12247.2|4.92|the universe having a conversation with
12249.18|6.66|us humans or with the systems we create
12252.12|5.4|to try to answer for the university for
12255.84|4.2|the creator of the universe to notice us
12257.52|3.66|we're trying to create systems that are
12260.04|3.54|loud enough
12261.18|3.66|just answer back
12263.58|2.64|I don't know if that's the meaning of
12264.84|3.18|life that's like meaning of life for
12266.22|3.599|some people the first level answer I
12268.02|3.24|would say is anyone can choose their own
12269.819|4.681|meaning of life because we are conscious
12271.26|5.58|entity and it's beautiful number one but
12274.5|4.56|uh I do think that like a deeper meaning
12276.84|3.899|of life if someone is interested is uh
12279.06|5.64|or along the lines of like what the hell
12280.739|5.7|is All This and like why and if you look
12284.7|2.94|at the into fundamental physics and the
12286.439|4.441|quantum field Theory and a standard
12287.64|3.96|model they're like very complicated and
12290.88|2.58|um
12291.6|4.259|there's this like you know 19 free
12293.46|3.96|parameter parameters of our universe and
12295.859|3.96|like what's going on with all this stuff
12297.42|3.899|and why is it here and can I hack it can
12299.819|3.42|I work with it is there a message for me
12301.319|3.361|am I supposed to create a message
12303.239|3.0|and so I think there's some fundamental
12304.68|3.66|answers there but I think there's
12306.239|4.321|actually even like you can't actually
12308.34|4.32|really make dent in those without more
12310.56|4.02|time and so to me also there's a big
12312.66|3.18|question around just getting more time
12314.58|2.399|honestly
12315.84|4.019|yeah that's kind of like what I think
12316.979|4.141|about quite a bit as well so kind of the
12319.859|3.661|ultimate
12321.12|6.38|or at least first way to sneak up to the
12323.52|7.379|why question is to try to escape
12327.5|6.76|uh the system the universe yeah and then
12330.899|4.801|for that you sort of uh backtrack and
12334.26|3.059|say okay for that that's going to be
12335.7|3.96|take a very long time so the why
12337.319|4.321|question boils down from an engineering
12339.66|3.0|perspective to how do we extend yeah I
12341.64|2.52|think that's the question number one
12342.66|3.48|practically speaking because you can't
12344.16|4.38|uh you're not gonna calculate the answer
12346.14|4.139|to the deeper questions in the time you
12348.54|3.42|have and that could be extending your
12350.279|3.721|own lifetime or extending just the
12351.96|4.019|lifetime of human civilization of
12354.0|4.62|whoever wants to not many people might
12355.979|4.92|not want that but I think people who do
12358.62|4.619|want that I think um I think it's
12360.899|3.481|probably possible uh and I don't I don't
12363.239|2.941|know that people
12364.38|3.059|fully realize this I kind of feel like
12366.18|3.719|people think of death as an
12367.439|4.321|inevitability but at the end of the day
12369.899|4.801|this is a physical system some things go
12371.76|5.46|wrong uh it makes sense why things like
12374.7|4.8|this happen evolutionarily speaking and
12377.22|4.679|uh there's most certainly interventions
12379.5|4.02|that uh that mitigate it that would be
12381.899|2.821|interesting if death is eventually
12383.52|3.959|looked at as
12384.72|4.86|as a fascinating thing that used to
12387.479|4.021|happen to humans I don't think it's
12389.58|3.54|unlikely I think it's I think it's
12391.5|5.399|likely
12393.12|5.4|and it's up to our imagination to try to
12396.899|4.741|predict what the world without death
12398.52|5.82|looks like yeah it's hard to I think the
12401.64|5.16|values will completely change
12404.34|5.22|could be I don't I don't really buy all
12406.8|5.639|these ideas that oh without that there's
12409.56|4.44|no meaning there's nothing as
12412.439|3.601|I don't intuitively buy all those
12414.0|3.18|arguments I think there's plenty of
12416.04|2.699|meaning plenty of things to learn
12417.18|3.84|they're interesting exciting I want to
12418.739|4.62|know I want to calculate uh I want to
12421.02|4.08|improve the condition of
12423.359|4.08|all the humans and organisms that are
12425.1|4.679|alive yet the way we find meaning might
12427.439|4.681|change we there is a lot of humans
12429.779|5.221|probably including myself that finds
12432.12|4.14|meaning in the finiteness of things but
12435.0|3.3|that doesn't mean that's the only source
12436.26|4.139|of meaning yeah I do think many people
12438.3|4.08|will will go with that which I think is
12440.399|4.201|great I love the idea that people can
12442.38|4.019|just choose their own adventure like you
12444.6|5.339|you are born as a conscious free entity
12446.399|6.901|by default I'd like to think and um you
12449.939|5.761|have your unalienable rights for Life uh
12453.3|4.92|in the pursuit of happiness I don't know
12455.7|4.56|if you have that in the nature the
12458.22|4.019|landscape of happiness you can choose
12460.26|4.32|your own adventure mostly and that's not
12462.239|5.401|it's not fully true but I still am
12464.58|6.359|pretty sure I'm an NPC but
12467.64|5.339|um an NPC can't know it's an NPC
12470.939|4.021|there could be different degrees and
12472.979|4.821|levels of consciousness I don't think
12474.96|5.64|there's a more beautiful way to end it
12477.8|4.059|uh Andre you're an incredible person I'm
12480.6|2.639|really honored you would talk with me
12481.859|4.141|everything you've done for the machine
12483.239|4.861|learning world for the AI world
12486.0|4.2|to just inspire people to educate
12488.1|3.48|millions of people it's been it's been
12490.2|3.06|great and I can't wait to see what you
12491.58|3.18|do next it's been an honor man thank you
12493.26|2.34|so much for talking today awesome thank
12494.76|2.099|you
12495.6|3.96|thanks for listening to this
12496.859|4.38|conversation with Andre karapathi to
12499.56|4.679|support this podcast please check out
12501.239|5.221|our sponsors in the description and now
12504.239|4.261|let me leave you with some words from
12506.46|4.8|Samuel Carlin
12508.5|6.899|the purpose of models is not to fit the
12511.26|6.12|data but to sharpen the questions
12515.399|4.821|thanks for listening and hope to see you
12517.38|2.84|next time