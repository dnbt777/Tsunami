start_time|end_time|text
0.03|3.389|like to point out that what I'll be
1.35|3.33|presenting today is partly my work in
3.419|3.541|collaboration with others and sometimes
4.68|4.29|I'm presenting work done by people in my
6.96|3.84|group that I wasn't really involved in
8.97|2.94|but it's joint work with many many
10.8|3.419|people you'll see lots of names
11.91|5.55|throughout the talk so take that with a
14.219|6.241|grain of salt so what I'm going to tell
17.46|4.77|you about is kind of how Google got to
20.46|3.92|where it is today in terms of using deep
22.23|5.1|learning in a lot of different places
24.38|5.35|the project that I'm involved in
27.33|4.14|actually started in 2011 when Andrea was
29.73|3.57|spending one day a week at Google
31.47|5.249|and I happened to bump into him in the
33.3|4.47|micro kitchen and and I said Oh what do
36.719|3.241|you were doing he's like I don't know
37.77|4.41|but I haven't figured out yet but big
39.96|4.38|neural nets are interesting oh my god
42.18|4.109|that's cool and turns out I had done an
44.34|4.89|undergrad thesis on parallel training of
46.289|5.071|neural nets like ages ago I won't even
49.23|5.13|tell you how long ago back kind of in
51.36|5.78|the first exciting period murrelets and
54.36|5.519|I always kind of really liked the the
57.14|4.599|computational model they provided but at
59.879|3.391|that time it was a little too early like
61.739|2.731|we didn't have a big enough data sets we
63.27|4.44|didn't have enough computation to really
64.47|5.13|make them sing and Andrew Cantor said Oh
67.71|5.04|will it be interesting to train big nips
69.6|5.46|so I'm like okay that sounds fun so we
72.75|5.909|kind of collaboratively started the
75.06|5.07|brain project to push out the size and
78.659|3.121|scale of neural nets that we could train
80.13|3.989|and in particular we were really
81.78|4.769|interested in using big data sets and
84.119|3.961|large amounts of computation to tackle
86.549|3.5|perception problems and language
88.08|4.92|problems
90.049|4.78|Andrew themwhen often family Coursera
93.0|5.07|and kind of drifting away from Google
94.829|4.921|but since then we've been doing a lot of
98.07|4.259|interesting work in both kind of
99.75|3.63|research areas in a lot of different
102.329|2.43|domains you know one of the nice things
103.38|3.54|about neural ances they're incredibly
104.759|3.57|applicable to many many different kinds
106.92|5.01|of problems as I'm sure you've seen in
108.329|5.671|this class and we've also deployed
111.93|3.869|production systems using neural nets in
114.0|2.85|a pretty wide variety of different
115.799|3.36|products so I'll kind of give you a
116.85|3.57|sampling of some of the research some of
119.159|3.511|the production aspects some of the
120.42|5.28|systems that we've built underneath the
122.67|4.32|covers including kind of some of the
125.7|2.52|implementation stuff that we do in
126.99|4.859|cancer flow to make these kinds of
128.22|4.8|models run fast and I'll focus on neural
131.849|2.191|nets but a lot of the techniques are
133.02|3.719|more applicable
134.04|3.63|than just normal ads tensorflow you can
136.739|2.67|train lots of different kinds of
137.67|3.84|reinforcement algorithms or other kinds
139.409|4.261|of you know other kinds of machine
141.51|4.13|learning models than just real mats okay
143.67|4.05|can everyone hear me
145.64|4.06|excellent someone of the back gave a
147.72|4.049|thumbs up so one of the things I really
149.7|4.2|like about the team we've put together
151.769|3.511|is that we have a really broad mix of
153.9|3.75|different kinds of expertise so we have
155.28|3.629|people are really experts at machine
157.65|4.08|learning research you know people like
158.909|5.91|Geoffrey Hinton other people like that
161.73|5.28|we have large-scale distributed systems
164.819|4.351|builders I kind of consider myself in
167.01|3.839|that more in that mold and then we have
169.17|4.53|people kind of with a mix of those
170.849|5.7|skills and often some of the projects we
173.7|4.23|work on you collectively put together
176.549|4.41|people with these different kinds of
177.93|4.02|expertise and collectively you do
180.959|2.64|something that none of you could do
181.95|4.009|individually because often you need both
183.599|5.191|kind of large scale systems thinking and
185.959|4.9|sort of clever machine learning ideas so
188.79|4.08|that's always fun and you often kind of
190.859|6.24|pick up and learn new things from other
192.87|8.759|people it's great so a rough outline
197.099|6.061|actually this is from an old deck so you
201.629|3.51|know you can kind of see the progress of
203.16|3.24|how Google has been applying deep
205.139|2.731|learning across lots of different areas
206.4|2.729|well this is sort of when we started the
207.87|3.63|project and we started collaborating
209.129|3.841|with a speech team a bit and started
211.5|4.829|doing it with some kind of early
212.97|5.19|computer vision kinds of problems and as
216.329|3.87|we had success in some of those domains
218.16|4.71|other teams at Google would say hey I
220.199|4.201|have a problem too and like they would
222.87|3.869|come to us or we would go to them and
224.4|4.08|say hey we think this could help with
226.739|4.231|your particular problem and over time
228.48|5.25|we've kind of gradually not so gradually
230.97|4.019|expanded the set of teams and areas that
233.73|4.8|we've been applying these kinds of
234.989|5.491|problems to and you see the breadth of
238.53|5.099|different kinds of areas it's not like
240.48|4.74|it's only computer vision problems so
243.629|4.32|that's that's kind of nice we're
245.22|5.359|continuing to grow which is good and
247.949|5.01|part of the reason for that broad
250.579|5.08|spectrum of things is that you can
252.959|4.981|really think of neural nets as these
255.659|3.45|nice really Universal systems that you
257.94|2.969|can put lots of different kinds of
259.109|3.951|inputs into you can put lots get lots of
260.909|4.651|different kinds of outputs out of them
263.06|4.329|with you know slight differences in the
265.56|5.37|model you try but in
267.389|4.86|general the same fundamental techniques
270.93|3.84|work pretty well across all these
272.249|4.14|different domains and it gives
274.77|2.79|state-of-the-art results as a sure
276.389|3.03|you've heard about in this class and
277.56|4.349|lots of different areas you know pretty
279.419|5.101|much any computer vision problem any
281.909|4.921|speech problem these days starting to be
284.52|4.919|more the case in lots of language
286.83|5.01|understanding areas lots of kind of
289.439|3.57|other areas of science like drug
291.84|2.549|discovery you're starting to have
293.009|7.741|interesting neural net models that are
294.389|10.951|better than alternatives yeah I like
300.75|6.029|them they're good along the way we've
305.34|4.319|kind of built two different generations
306.779|5.281|of our underlying system software for
309.659|4.62|training and deploying neural nets the
312.06|6.18|first was called disbelief we published
314.279|5.25|paper about that in nips 2012 it had the
318.24|3.66|advantage that it was really scalable
319.529|3.781|like the first one of the first uses we
321.9|2.519|put to it was doing some unsupervised
323.31|3.449|training I'll tell you about in a minute
324.419|5.041|which used 16,000 cores to train a big
326.759|4.141|noelite with a lot of parameters I was
329.46|3.54|good for production use but it wasn't
330.9|4.62|super flexible for research like it was
333.0|3.9|kind of hard to Express kind of weirder
335.52|2.73|more esoteric kinds of models
336.9|3.329|reinforcement learning algorithms would
338.25|4.62|be hard to express in it had this kind
340.229|5.881|of much more layer driven approach with
342.87|5.34|up and down messages and it worked well
346.11|3.989|for what it did but we kind of took a
348.21|4.049|step back about a year and a little bit
350.099|3.87|ago and started building our second
352.259|3.63|generation system tensorflow which is
353.969|3.93|based on what we learned with the first
355.889|4.71|generation and what we learned from
357.899|5.58|looking at other sort of available open
360.599|4.74|source packages and we think it's
363.479|3.75|retained a lot of the good features of
365.339|3.57|disbelief but also made it pretty
367.229|5.49|flexible for a wide variety of research
368.909|8.13|uses we've open sourced it which I
372.719|5.91|gather you heard about so one of the
377.039|3.12|really nice properties of neural nets I
378.629|4.26|grabbed this from a particular paper
380.159|4.23|because it had graphs on both scaling
382.889|4.26|the size of training data and how
384.389|4.381|accuracy increases and also scaling the
387.149|3.961|size of the neural net and how accuracy
388.77|3.569|increases the exact details aren't
391.11|3.299|important you can find these kinds of
392.339|4.14|trends in hundreds of papers but one of
394.409|3.81|the really nice properties is if you
396.479|4.74|have more data and you can make your
398.219|3.281|model bigger generally scaling both of
401.219|2.171|those
401.5|4.68|things is even better than scaling just
403.39|4.47|one of them you need a really big model
406.18|3.45|in order to capture kind of the more
407.86|3.93|subtle trends that appear in larger and
409.63|4.35|larger datasets you know any neural map
411.79|3.93|will capture kind of obvious trends or
413.98|3.3|obvious Kenza patterns but the more
415.72|3.54|subtle ones are ones where you need a
417.28|5.78|bigger model to capture kind of that
419.26|6.51|that extra sue swamps of subtlety and
423.06|5.95|that requires a lot more computation so
425.77|5.04|we focus a lot on scaling the
429.01|7.01|computation we need and being able to
430.81|7.83|Train big models on big datasets right
436.02|5.23|okay so one of the first things we did
438.64|4.05|in this project was we said Oh
441.25|3.96|unsupervised learning is going to be
442.69|7.91|really important and we had a big focus
445.21|5.39|on that initially quickly and others
450.84|4.03|said what would happen if we did
453.19|3.0|unsupervised learning and random YouTube
454.87|3.18|frames so the idea is we're going to
456.19|4.17|take ten million random YouTube frames
458.05|4.38|single frames from a bunch of random
460.36|3.51|videos and we're going to essentially
462.43|3.78|train an autoencoder everyone knows what
463.87|5.79|an auto coder is yeah so this is like a
466.21|4.44|fancy multi-level auto encoder you know
469.66|2.43|in this one we're just trying to
470.65|2.97|reconstruct the image now when we're
472.09|3.18|trying to reconstruct the representation
473.62|7.35|here from the representation there and
475.27|7.11|so on and we used 16,000 cores we didn't
480.97|3.33|have GPUs in the data center at the time
482.38|6.15|so we compensated with like throwing
484.3|5.49|more CPUs at it and we used async sqd
488.53|3.75|which I'll talk about in a minute for
489.79|3.54|optimization I'd actually had a lot of
492.28|4.1|parameters because it was not
493.33|5.07|convolutional this was prior to
496.38|3.43|convolutions being all the rage so we
498.4|2.7|said well we'll have local receptive
499.81|3.39|fields but they won't be convolutional
501.1|3.66|and we'll learn like separate
503.2|4.65|representations for this part of the
504.76|4.8|image in this part of the image which is
507.85|2.55|kind of an interesting twist I think
509.56|3.359|it'd be actually an interesting
510.4|4.71|experiment to redo this work but with
512.919|4.92|convolutional parameter sharing that
515.11|4.049|would be kind of cool in any case the
517.839|4.08|representation we learned at the top
519.159|4.741|after like nine layers of these non
521.919|5.071|convolutional local receptive fields had
523.9|5.43|60,000 neurons at the top level and one
526.99|4.05|of the things we thought might happen is
529.33|4.23|it would learn kind of high-level
531.04|3.7|feature detectors so in particular
533.56|3.73|you're proving in pixels but
534.74|4.2|could it learn high-level concepts so we
537.29|4.26|had a dataset that was half faces and
538.94|5.339|half not faces and we found looked
541.55|4.11|around for neurons that were good
544.279|3.841|selectors of whether or not the image
545.66|4.82|the test image contained a face and we
548.12|5.64|found several such neurons the best one
550.48|5.049|that are those are some of the sample
553.76|6.15|images that cause that neuron to get the
555.529|6.601|most excited and then if you look around
559.91|4.53|for what stimulus will cause that neuron
562.13|8.64|to get the most excited there's creepy
564.44|8.25|face guy and so that's kind of
570.77|4.319|interesting like we had no labels in the
572.69|6.18|image in the dataset at all that we were
575.089|5.851|training and a neuron in this model has
578.87|4.35|picked up on the fact that faces or
580.94|4.41|things I'm going to get excited when I
583.22|5.369|see kind of a Caucasian face from head
585.35|6.0|on its YouTube so we also have a cat
588.589|5.091|neuron we had a dataset that was half
591.35|8.52|cats and half not cats and this is
593.68|8.07|average tabby I call him and then you
599.87|4.65|can take that unsupervised model and
601.75|5.62|start a supervised training task so in
604.52|5.129|particular at this time we were training
607.37|4.44|on the image net 20,000 class task which
609.649|3.451|is not the one that most image net
611.81|3.12|results are reported on that one's a
613.1|4.979|thousand classes who's trying to
614.93|6.659|distinguish an image from one of 20,000
618.079|5.461|classes it's a much harder task and when
621.589|4.681|we trained and then looked around at
623.54|4.38|what kinds of images cause different
626.27|3.15|top-level neurons to get excited you see
627.92|5.13|they're picking up on very high level
629.42|8.69|concepts you know yellow flowers only or
633.05|7.08|waterfowl pizzas I like pizza and this
638.11|3.25|pre-training actually increased the
640.13|5.269|state-of-the-art accuracy on that
641.36|4.039|particular task fair amount at that time
646.089|4.391|then we kind of lost our excitement
649.25|3.17|about unsupervised learning because
650.48|4.32|supervised learning works so darn well
652.42|6.64|and so we started working with a speech
654.8|6.0|team who at the time was had a non
659.06|4.41|neural net based acoustic model so he's
660.8|6.09|essentially trying to go from a small
663.47|4.44|segment of audio data like 150
666.89|1.54|milliseconds and you're trying to
667.91|2.11|predict what
668.43|6.81|sound is being uttered in the middle 10
670.02|8.67|milliseconds and so we just decided to
675.24|6.27|try a 8 layer fully connected robot and
678.69|4.74|then predict one of 14,000 try phones at
681.51|5.34|the top and that worked phenomenally
683.43|5.49|well basically you could train it pretty
686.85|4.08|quickly and it gave a huge reduction in
688.92|3.18|order like this is one of the people on
690.93|2.37|the speech team said that's like the
692.1|3.989|biggest single improvement they've seen
693.3|6.32|in their 20 years in speech research and
696.089|11.821|that launched as part of the Android
699.62|10.75|voice search system in 2012 I think so
707.91|4.14|one of the things we often do is find
710.37|3.6|that we have a lot of data for some
712.05|5.19|tasks but not very many very much data
713.97|6.78|for other tasks and so for that we often
717.24|5.969|deploy systems that make use of multi
720.75|4.92|task and transfer learning in various
723.209|6.031|ways so let's look at an example where
725.67|5.789|we use this in speech so obviously with
729.24|4.2|English we have a lot of data and we get
731.459|4.951|a really nice low Werder at lower is
733.44|4.2|better for Portuguese on the other hand
736.41|2.52|at that time we didn't have that much
737.64|3.24|training data we had 100 hours of
738.93|5.46|Portuguese data and so the word error
740.88|5.64|rate is a lot worse which is bad
744.39|3.51|so one of the first and most simple
746.52|3.3|things you can do which is kind of what
747.9|3.72|you do when you take a model has been
749.82|2.94|pre trained on imagenet and apply to
751.62|3.78|some other problem where you don't have
752.76|4.35|as much data as you just start training
755.4|3.51|with those weights rather than totally
757.11|2.88|random weights and that actually
758.91|3.15|improves your word error rate for
759.99|3.69|Portuguese a bit because there's enough
762.06|3.51|similarities and the kinds of features
763.68|5.34|you want for speech in general
765.57|4.92|regardless of language a more
769.02|4.5|complicated thing you can do is actually
770.49|4.89|jointly train models that share a bunch
773.52|6.18|of parameters across all languages or in
775.38|6.959|this case all all European languages I
779.7|6.36|think is what we use to and so there you
782.339|5.611|see we're jointly training on this data
786.06|4.29|and we actually got a pretty significant
787.95|5.61|improvement even over the just copying
790.35|4.83|the data to the Portuguese model but in
793.56|3.51|surprisingly we actually got a small
795.18|4.38|improvement in English because in in
797.07|3.81|total across all the other languages we
799.56|2.64|actually almost doubled the amount of
800.88|4.32|training data we were able to use
802.2|5.52|is in this model compared to just
805.2|4.08|English alarm so basically like
807.72|2.58|languages without much data at all
809.28|2.61|improved a lot
810.3|5.52|languages with a lot of data improved
811.89|5.58|even a little bit and then we had a
815.82|2.58|language specific top layer we could
817.47|2.79|have build a little little bit of
818.4|3.57|fiddling to figure out you know does it
820.26|5.04|make sense to have two language specific
821.97|6.3|top layers one sadly these are the kinds
825.3|5.97|of human guided choices you make and go
828.27|4.83|that's the production speech models have
831.27|5.01|evolved a lot from those fairly simple
833.1|4.77|feed-forward models they use now l STM's
836.28|3.9|to deal with time dimension they use
837.87|4.47|consolation convolutions to make them
840.18|5.01|invariant to different frequencies so
842.34|3.93|there was a paper published here you you
845.19|2.49|know you don't necessarily need to
846.27|3.87|understand all the details but there's a
847.68|5.55|lot of more complexity in the kinds of
850.14|4.44|model and it's it's using much more
853.23|5.01|sophisticated recurrent models and
854.58|6.09|convolutional models a recent trend has
858.24|5.01|been that you can use LS gems completely
860.67|4.68|end end so rather than having an
863.25|3.99|acoustic model and then a language model
865.35|3.06|that kind of takes the output of the
867.24|3.87|acoustic model and then is trained
868.41|4.79|somewhat separately you can go directly
871.11|5.31|from audio waveforms to producing
873.2|4.39|transcript to character at a time and I
876.42|5.19|think that's going to be a really big
877.59|6.24|trend both in speech and more generally
881.61|5.16|in a lot of computing systems you often
883.83|5.31|have today a lot of systems are kind of
886.77|5.22|composed of a bunch of subsystems each
889.14|5.22|perhaps with some machine learning and
891.99|4.38|some kind of hand coded pieces and then
894.36|5.64|are usually a big pile of GUI code to
896.37|6.47|glue it all together and often all those
900.0|5.46|separately developed pieces have
902.84|4.66|impediments to optimization right like
905.46|3.66|you optimize your subsystem in the
907.5|3.9|context of some metric but that metric
909.12|3.9|might not be the right thing for the
911.4|6.48|final task you care about which might be
913.02|9.27|transcribing speech correctly so having
917.88|5.58|a much bigger single system like a
922.29|3.27|single neural lab that goes directly
923.46|3.27|from audio waveform all the way to the
925.56|3.66|end objective you care about
926.73|4.11|transcription and that you can then
929.22|3.27|optimize end-to-end through and there's
930.84|4.439|not sort of a lot of hand written code
932.49|4.11|in the middle that is going to be a big
935.279|2.87|trend I think you'll see that here
936.6|7.739|you'll see that in machine translation
938.149|8.081|lots of other kinds of domains so this
944.339|3.391|class is all about convolutions so we
946.23|2.729|have tons of vision problems that we've
947.73|3.81|been using various kinds of
948.959|5.911|convolutional models for you know the
951.54|4.68|big excitement around convolutional
954.87|3.17|neural nets well first it started with
956.22|3.869|yum yum Coons check reading
958.04|5.44|convolutional net and then it kind of
960.089|5.37|like subsided for a while and then Alex
963.48|5.64|Khrushchev CEO sutskever and Jeffrey
965.459|5.011|Hinton's paper in 2012 which like blew
969.12|5.009|the other competitors out of the water
970.47|6.659|in the image net 2012 challenge using a
974.129|5.58|neural net I think put those things on
977.129|3.57|everyone's map again as saying well we
979.709|2.701|should really should be using these
980.699|3.87|things for vision because they work
982.41|4.979|really well and the next year there was
984.569|3.841|something like 20/20 of the entries or
987.389|6.39|something used neural nets whereas
988.41|6.75|previously it was just Alex we've had a
993.779|4.17|bunch of people at Google looking at
995.16|4.169|various kinds of architectures for doing
997.949|2.671|better and better image net
999.329|2.971|classification so the inception
1000.62|3.839|architecture has like this complicated
1002.3|3.57|module of like different size
1004.459|4.261|convolutions that are all kind of
1005.87|4.38|concatenated together and then you kind
1008.72|4.08|of replicate those modules a bunch of
1010.25|4.559|times and very you end up with a very
1012.8|6.42|deep neural net that turns out to be
1014.809|6.39|quite good at recognition there's been
1019.22|3.179|some slight additions to that and it's
1021.199|5.01|like changes to make it even more
1022.399|9.0|accurate you know I have you seen a
1026.209|8.071|slide like that and like okay yeah so I
1031.399|5.94|I was lazy and only took my slides from
1034.28|5.07|a older thing I have you told the story
1037.339|6.21|about Andre sitting down on ham labeling
1039.35|5.88|images okay so anyway Andre decided
1043.549|3.331|since you were helping to administer the
1045.23|3.24|image in that contest he would sit down
1046.88|4.11|and subject himself to a hundred hours
1048.47|5.12|of training with like a training test
1050.99|5.36|training test split and like
1053.59|5.76|is that an Australian Shepherd dog I
1056.35|4.38|don't know and he also I think convinced
1059.35|2.76|one of his lab mates to do it but they
1060.73|3.569|weren't as diligent so he did about a
1062.11|6.36|hundred and twenty hours of training on
1064.299|6.36|images and his his love poor lab mate
1068.47|5.13|got tired after 12 hours of filming so
1070.659|6.541|he got 5.1 percent error and the lab
1073.6|5.1|mate got I think 12 percent error sorry
1077.2|3.9|about that we originally tried to do it
1078.7|3.599|ensemble of our entire lab and had a
1081.1|2.939|crew meeting where we all just tried
1082.299|3.811|those like sit down and evaluate human
1084.039|4.11|test error on imagenet but without
1086.11|4.679|training we did really really poorly
1088.149|4.291|like on trail I got fed up with how bad
1090.789|3.211|we all did and went home for the weekend
1092.44|4.95|and came back and was really good at
1094.0|5.76|image now a hundred and twelve hours
1097.39|3.87|later whatever anyway he has a great
1099.76|3.539|blog post about it I encourage you to
1101.26|4.73|check it out he has a lot of parameters
1103.299|5.371|though so
1105.99|3.94|typical humans are like you know eighty
1108.67|6.3|trillion connections I'm going to give
1109.93|6.63|him 100 what one point about these
1114.97|3.48|models is that models with a small
1116.56|4.38|number of parameters fit well on like
1118.45|5.16|mobile devices so Andre doesn't fit well
1120.94|5.04|on a mobile phone but the general trend
1123.61|3.57|other than Andre is like smaller numbers
1125.98|4.74|of parameters compared to Alex net
1127.18|5.31|mostly Alex net had like these two giant
1130.72|4.53|fully connected layers at the top at
1132.49|4.41|China but a lot of parameters and later
1135.25|4.64|work just kind of did away with those
1136.9|5.13|for the most part and so they've used
1139.89|4.21|you know a smaller number of parameters
1142.03|4.11|but more floating-point operations
1144.1|4.34|because they reuse convolutional
1146.14|5.43|parameters more which is good for
1148.44|5.2|fitting them on phones we released as
1151.57|4.92|part of a tensor flow update a
1153.64|5.31|pre-trained inception model that you can
1156.49|5.37|use there's a nice tutorial about it
1158.95|5.1|there's Grace Hopper although we think
1161.86|6.63|it's military uniform which is not
1164.05|5.79|terribly inaccurate one of the nice
1168.49|2.94|things about these models is they're
1169.84|2.7|really good at doing very fine grained
1171.43|2.79|classifications I think one of the
1172.54|3.15|things that is an Andres blog is that
1174.22|2.52|the computer models are actually much
1175.69|4.38|much better than people at
1176.74|7.2|distinguishing exact breeds of dogs but
1180.07|7.05|humans are better at often picking out a
1183.94|5.58|small you know if if the label is
1187.12|4.5|ping-pong ball and it's like a giant
1189.52|3.96|scene of people playing ping-pong humans
1191.62|5.99|are better at that because the models
1193.48|7.17|tend to focus on things with more pixels
1197.61|4.57|if you train models with the right kinds
1200.65|3.12|of data you know generalize well these
1202.18|3.84|scenes look nothing alike but they
1203.77|3.36|actually you know we'll both get labeled
1206.02|4.65|as Mele if your training data is
1207.13|5.09|represented well they make kind of
1210.67|4.8|sensible errors which is kind of nice
1212.22|4.3|you know it's not a snake but you
1215.47|3.75|understand why it might have said that
1216.52|5.28|and I know it's not a dog but I actually
1219.22|5.01|had to think carefully if the front
1221.8|5.78|animal there is a is a donkey or a goat
1224.23|9.47|I'm not still not entirely sure
1227.58|9.179|any votes yeah right it's hard so one of
1233.7|4.679|the production uses we've put these
1236.759|4.071|kinds of models too is Google photo
1238.379|4.951|search so we launched Google photo
1240.83|4.39|product and you can search the photos
1243.33|3.569|that you've uploaded without tagging
1245.22|3.48|them at all you just type ocean and all
1246.899|5.22|of a sudden all of your motion photos
1248.7|6.419|show up so for example this user posted
1252.119|5.13|publicly hey I and they posted a
1255.119|4.351|screenshot hey I didn't tag these and I
1257.249|6.841|type statue and they just showed up or
1259.47|6.089|see drawing you know Yoda this is a
1264.09|4.649|tough Yoda because it's got a lot of
1265.559|4.891|texture compared to most Yoda's so we're
1268.739|6.75|pretty pleased to retrieve macrame
1270.45|9.209|jota's we have a lot of kind of other
1275.489|5.611|kinds of more specific visual tasks like
1279.659|2.73|essentially one of the things we want to
1281.1|2.459|do in our Street View imagery so we have
1282.389|3.211|these cars the drive around the world
1283.559|4.651|and take pictures of all the the roads
1285.6|3.899|and sweet teens and then we want to be
1288.21|4.399|able to read all the text that we find
1289.499|5.4|so first you have to find the text and
1292.609|3.731|well one of the first things you want to
1294.899|3.78|do is find all the addresses and then
1296.34|3.689|help improve the maps and once you do
1298.679|4.411|that you want to like read all the other
1300.029|4.5|text so you can see that it does we have
1303.09|3.929|a model that does a pretty good job of
1304.529|6.89|predicting at a pixel level which which
1307.019|8.01|pixels contain text or not and it does
1311.419|5.98|pretty well in that well first of all it
1315.029|3.78|finds lots of text and the training data
1317.399|3.41|had different kinds of character sets
1318.809|4.83|represented so it has no problem
1320.809|6.641|recognizing Chinese characters English
1323.639|5.04|characters Roman Latin characters it
1327.45|3.75|does pretty well with like different
1328.679|4.71|colors of text in different fonts and
1331.2|3.539|sizes and some of them are very close to
1333.389|4.92|the camera some are very far away and it
1334.739|6.3|does just fine and this is data from
1338.309|7.021|just human label drawn polygons around
1341.039|5.76|pieces of text and then they transcribed
1345.33|6.51|it and then we have an OCR model that we
1346.799|6.541|also trained we've been kind of
1351.84|3.6|gradually releasing other kinds of
1353.34|4.62|product so we just launched cloud vision
1355.44|4.349|set of api's you can do lots of things
1357.96|2.97|like label images this is meant for
1359.789|3.901|people who don't necessarily
1360.93|5.07|want to want or to have machine learning
1363.69|3.66|expertise they just kind of want to do
1366.0|3.21|cool stuff with images you want to be
1367.35|5.6|able to you know say oh that's a running
1369.21|6.12|scene you want to do the OCR and find
1372.95|3.64|text in any image that you've uploaded
1375.33|3.33|so you just basically give it an image
1376.59|5.55|and say I'd like to run OCR and labeled
1378.66|5.19|generation on this image and off it goes
1382.14|5.91|so people have been pretty happy with
1383.85|5.82|that you know internally people have
1388.05|3.6|been thinking of more creative uses of
1389.67|3.6|how to use computer vision essentially
1391.65|3.12|now that computer vision sort of really
1393.27|5.49|actually works compared to five years
1394.77|5.85|ago this is something that our our our
1398.76|3.9|geo team that processes satellite
1400.62|4.89|imagery put together and released which
1402.66|4.68|is basically a way of predicting the
1405.51|4.86|slope of roofs from multiple satellite
1407.34|4.56|views of that because we like have you
1410.37|3.09|know every few months we get new
1411.9|3.63|satellite imagery until we have multiple
1413.46|3.48|views of the same location and we can
1415.53|3.21|predict what the slope of the roof is
1416.94|3.87|given all those different views of the
1418.74|4.26|same location and how much sun exposure
1420.81|4.02|it'll get and then predict you know if
1423.0|4.98|you were to install solar panels on your
1424.83|6.18|house how much energy could you generate
1427.98|4.95|at that good thing kind of cool you know
1431.01|7.61|it's like a small random thing that you
1432.93|8.49|can do now that vision works okay so
1438.62|4.54|this class has been I assume mostly
1441.42|3.63|about vision so I'm going to talk now
1443.16|4.77|about other kinds of problems like
1445.05|7.17|language understanding one of the most
1447.93|8.49|important problems is search obviously
1452.22|6.45|so we care a lot about search and in
1456.42|4.17|particular if I do the query car parts
1458.67|4.19|for sale I'd like to determine which of
1460.59|4.8|these two documents is more relevant and
1462.86|3.85|if you just look at the surface forms of
1465.39|2.73|the word that first document looks
1466.71|5.66|pretty darn relevant because it has like
1468.12|6.45|lots of the words occur and lots of read
1472.37|5.56|but actually the second document is much
1474.57|6.6|more relevant given that and we'd like
1477.93|4.94|to be able to understand that so how
1481.17|3.87|much have you talked about embedding
1482.87|4.15|actually
1485.04|3.6|captioning model Oh awesome so you know
1487.02|6.21|about embeddings great embeddings you're
1488.64|7.14|fantastic so I will go quickly but
1493.23|4.41|basically you want to represent words or
1495.78|4.26|things in high dimensional things that
1497.64|4.26|are sparse map them into a dense space
1500.04|4.88|some hundred dimensional or a thousand
1501.9|8.52|dimensional space so that you can now
1504.92|7.6|have things that are near each other and
1510.42|3.72|have similar meanings will end up near
1512.52|3.15|each other in these high dimensional
1514.14|3.03|spaces so for example you'd like
1515.67|2.34|porpoise and dolphin to be very near
1517.17|2.07|each other in this high dimensional
1518.01|3.78|space because there are quite similar
1519.24|6.27|words and have similar meanings they
1521.79|8.43|share the same sense of purpose No okay
1525.51|6.54|maybe that and SeaWorld should be kind
1530.22|5.3|of nearby and camera and Paris should be
1532.05|5.46|pretty far away and you can train
1535.52|3.67|embeddings in lots of different ways one
1537.51|3.18|is to have it kind of as the first thing
1539.19|4.59|you do when you're feeding it into an
1540.69|5.19|LST M an even simpler thing is a
1543.78|4.35|technique my former colleague too much
1545.88|4.26|McAuliffe came up with that we publish
1548.13|3.65|paper about where essentially it's
1550.14|3.87|called the word defect model and
1551.78|4.33|essentially you pick a window of words
1554.01|3.81|maybe 20 words why'd you pick the Center
1556.11|3.99|word and then you pick another random
1557.82|4.02|word you try to use the embedding
1560.1|5.7|representation of that Center word to
1561.84|5.88|predict the other word and then you can
1565.8|3.87|train that whole thing with backdrop so
1567.72|3.84|essentially you adjust the weights and
1569.67|6.0|the softmax classifier and then in turn
1571.56|5.91|you through back propagation you you
1575.67|4.08|make little adjustments to the embedding
1577.47|3.54|representation of that Center word so
1579.75|3.56|that next time you'll be able to better
1581.01|5.01|predict the word parts from automobile
1583.31|4.48|and it actually works right like that's
1586.02|4.11|one of the really nice things about
1587.79|4.17|embeddings is given enough training data
1590.13|3.84|you get really phenomenal
1591.96|3.75|representations of words so these are
1593.97|4.26|the nearest neighbors for these three
1595.71|4.98|different words we actually had short
1598.23|4.29|phrases as vocabulary items in this
1600.69|4.08|particular run so tiger shark you can
1602.52|5.19|click up as one one embedding vector and
1604.77|6.45|these are the nerves neighbors so it got
1607.71|6.54|the sense of sharpness car is
1611.22|6.33|interesting right like you see why this
1614.25|4.71|is useful for search because you have
1617.55|3.18|things that
1618.96|3.9|people often hand code and information
1620.73|5.46|retrieval systems like plurals and
1622.86|5.76|stemming and like some kind of simple
1626.19|4.5|synonyms but here you just see like Oh a
1628.62|4.289|car automobile pickup truck racing car
1630.69|4.29|passenger car dealership is kind of
1632.909|4.681|related you just see that it has this
1634.98|4.37|this right concept of a knife kind of
1637.59|5.13|smooth representation of car rather than
1639.35|7.48|explicitly only the letter C a are match
1642.72|6.15|that and it turns out that if you train
1646.83|3.839|using the word defect approach the
1648.87|3.059|directions turn out to be meaningful in
1650.669|4.01|these high dimensional spaces so not
1651.929|4.98|only is proximity interesting but
1654.679|6.61|directions are interesting so it turns
1656.909|7.981|out if you look at capital and country
1661.289|5.401|pairs you go roughly the same direction
1664.89|5.419|and distance to get from a country to
1666.69|8.64|its corresponding capital or vice versa
1670.309|6.61|for any country capital pair and you
1675.33|3.39|also kind of see some semblance of other
1676.919|3.961|structure so this is the embeddings map
1678.72|7.11|down to two dimensions via principal
1680.88|7.35|components analysis so and you see kind
1685.83|6.93|of interesting structures around verb
1688.23|6.9|tenses regardless of the firm which
1692.76|5.43|means you can solve analogies like queen
1695.13|4.56|is the king as woman is to man by doing
1698.19|3.089|some simple vector arithmetic so you're
1699.69|3.63|literally just looking up the embedding
1701.279|4.77|vector and then adding the difference to
1703.32|10.17|get to that point approximately at that
1706.049|9.211|point so we've been in collaboration
1713.49|3.45|with the search team we launched kind of
1715.26|5.37|one of the biggest search ranking
1716.94|5.849|changes in the last few years we called
1720.63|3.929|it ranked brain it's essentially just a
1722.789|4.86|deep neural app that uses embeddings and
1724.559|4.62|a bunch of of neural net layers to give
1727.649|3.801|you a score for how relevant this
1729.179|6.12|document is for this particular query
1731.45|6.579|and it's the third most important search
1735.299|5.271|ranking signal now out of hundreds of
1738.029|7.53|such signals
1740.57|6.4|that's called smart reply was a little
1745.559|4.051|collaboration we did with the Gmail team
1746.97|4.079|we're essentially replying to mail on
1749.61|2.43|your phone kind of sucks because typing
1751.049|3.181|is hard
1752.04|4.29|and so we wanted to have a system where
1754.23|6.15|often you can predict what would be a
1756.33|5.64|good reply just looking at message so we
1760.38|3.84|have a small network that predicts is
1761.97|5.61|that a likely to be something that I can
1764.22|6.27|have a short Taurus Ponce - if yes then
1767.58|5.34|we activate a much bigger lsdm based
1770.49|4.32|model and this is a message one of my
1772.92|3.33|colleagues received working the project
1774.81|2.55|had said from his brother he said we
1776.25|3.18|wanted to invite you to join us for an
1777.36|4.02|early Thanksgiving bla bla bla bla bla
1779.43|5.67|please bring your favorite dish RSVP by
1781.38|6.0|next week so then the model predicts
1785.1|5.31|count us in will be there or sorry we
1787.38|5.66|won't be able to make it which is great
1790.41|4.71|if you get a lot of email it's fantastic
1793.04|4.75|although your replies will be somewhat
1795.12|7.98|terse although you can edit them which
1797.79|8.94|is nice you know we can do interesting
1803.1|5.58|things like this is a mobile app that
1806.73|3.59|actually runs in airplane mode so it's
1808.68|3.9|actually running the models on the phone
1810.32|4.18|and it's actually got a lot of
1812.58|6.3|interesting things some of which I
1814.5|7.02|didn't entirely realize so you're
1818.88|4.86|essentially using the camera image
1821.52|4.86|you're detecting text in it you're
1823.74|2.91|finding what the words are doing OCR on
1826.38|1.44|it
1826.65|2.85|you're then running it through a
1827.82|3.33|translation model you configure it in a
1829.5|3.48|particular mode this is just cycling
1831.15|3.09|through different languages but normally
1832.98|5.64|you'd set it on Spanish mode and it
1834.24|5.49|would only show you Spanish but the
1838.62|2.55|thing I didn't realize is there's
1839.73|4.44|actually an interesting font selection
1841.17|6.45|problem in how to like choose what font
1844.17|6.24|to show for the output so anyway it's
1847.62|4.29|kind of cool good if you're traveling to
1850.41|5.01|interesting places I'm actually going to
1851.91|4.83|Korea on Saturdays so I'm I'm looking
1855.42|8.16|forward to using my Translate app
1856.74|8.67|because I don't speak Korean so one of
1863.58|4.32|the things we do a bit of work on is
1865.41|5.88|reducing inference cost there's like
1867.9|6.24|nothing worse than this feeling that wow
1871.29|5.04|my model is so awesome it's great it's
1874.14|5.58|it's just sad that it drains my phone's
1876.33|5.13|battery in two minutes or you know I
1879.72|4.14|can't afford the computation to run it
1881.46|4.77|at you know hike ups in my datacenter
1883.86|5.19|even though I have gobs of machines
1886.23|5.43|so there's lots of tricks you can use in
1889.05|5.07|particular the simplest one is inference
1891.66|6.05|is generally much more forgiving of even
1894.12|3.59|much lower precision
1897.95|4.54|computation than training so for
1901.14|3.0|inference we usually find we can
1902.49|4.26|quantize all the weights to eight bits
1904.14|4.2|or even less eight bits is just a nice
1906.75|3.81|quantity that CPUs like to deal with
1908.34|5.16|really you could do six bits probably
1910.56|4.86|but that doesn't help you that much so
1913.5|3.54|that gives you like a nice 4x memory
1915.42|4.68|reduction in storing the parameters and
1917.04|4.77|also gives you 4x computation efficiency
1920.1|3.39|because you can use CPU vector
1921.81|3.96|instructions to do four multiplies
1923.49|4.83|instead of one 32-bit floating-point
1925.77|4.04|multiply so that's really good
1928.32|4.08|I'm gonna tell you about kind of a cuter
1929.81|4.99|more exotic way of getting more
1932.4|4.25|efficiency out of a mobile phone there's
1934.8|4.05|a technique called distillation that
1936.65|5.83|Geoffrey Hinton oreal venules and I
1938.85|5.55|worked on so suppose you have a really
1942.48|3.21|really giant model the problem I just
1944.4|4.02|described where you have this fantastic
1945.69|5.04|model you're really pleased with maybe
1948.42|4.05|you have an ensemble of those and now
1950.73|5.76|you want a smaller cheaper model with
1952.47|7.59|almost the same accuracy so here it is
1956.49|4.98|your giant expensive model you feed this
1960.06|4.29|image in and it gives you fantastic
1961.47|6.15|predictions like 0.95 Jaguar I'm pretty
1964.35|7.65|sure and I'm definitely sure that's not
1967.62|6.18|a car ten to the minus six for car 0.04
1972.0|6.21|you know I'm hedging a bit it could be a
1973.8|7.64|lion right so that's what a really
1978.21|5.16|accurate model will do so the main idea
1981.44|4.39|unfortunately we later discovered that
1983.37|4.5|rich Khurana in 2006 had published a
1985.83|5.76|similar idea in a paper called model
1987.87|5.52|compression so the ensemble or your
1991.59|3.3|giant accurate model implements this
1993.39|5.4|interesting function from input to
1994.89|6.57|output so if you forget the fact that
1998.79|4.44|there's some structure there and you
2001.46|3.41|just try to use the information that's
2003.23|4.2|contained to that function
2004.87|4.51|how can we transfer the knowledge in
2007.43|4.79|that really accurate function into a
2009.38|5.7|smaller representation of the function
2012.22|4.9|so when you're training a model
2015.08|3.87|typically what you do is you feed it an
2017.12|2.34|image like this and then you give it
2018.95|2.94|target
2019.46|4.349|to try to achieve and you give it the
2021.89|5.43|target one Jaguar and zero for
2023.809|6.061|everything else well I'm going to call
2027.32|5.55|that a hard target so that's kind of the
2029.87|4.83|the ideal your model is striving to
2032.87|3.419|achieve and you give it you know
2034.7|2.609|hundreds of thousands or millions of
2036.289|3.841|training images that it tries to
2037.309|4.35|approximate all these you know one hot
2040.13|3.72|vectors for all the different images and
2041.659|3.561|an actual fact it doesn't quite do that
2043.85|3.24|because it gives you this nice
2045.22|4.99|probability distribution over different
2047.09|7.38|images over different classes for the
2050.21|7.62|same image so let's take our giant
2054.47|5.159|expensive model and one of the things we
2057.83|4.559|can do is we can actually soften that
2059.629|6.861|distribution a bit and this is what
2062.389|8.341|Geoffrey Hinton calls a dark knowledge
2066.49|5.859|it sounds fancier but if you soften this
2070.73|3.689|by essentially dividing all the logistic
2072.349|4.441|units by a temperature T there might be
2074.419|4.411|like five or ten or something you then
2076.79|4.44|get a softer representation of this
2078.83|5.25|probability distribution where you say
2081.23|4.379|okay it's a Jaguar but also kind of head
2084.08|4.68|your bets a little and call it a bit of
2085.609|7.101|a lion maybe even less of a cow still
2088.76|8.369|call it definitely not a car and that's
2092.71|5.83|something you can then use and this full
2097.129|2.911|distribution conveys a lot more
2098.54|3.36|information about the image about the
2100.04|3.48|function that's being implemented by
2101.9|3.24|this large ensemble right because the
2103.52|3.72|ensemble is trying to hedge its bets and
2105.14|3.57|do a really good job on giving you a
2107.24|6.15|probability probability distribution
2108.71|7.08|over that image so then you can train
2113.39|3.75|the small model so normally when you
2115.79|3.48|frame you just train on the hard targets
2117.14|4.92|but instead you can train on some
2119.27|6.72|combination of the hard targets plus the
2122.06|5.789|soft targets and the training objective
2125.99|6.21|is going to try to mat match some
2127.849|7.221|function of those two things so this
2132.2|5.31|works surprisingly well so here's an
2135.07|4.51|experiment we did on a large speech
2137.51|5.3|model so we started with the model that
2139.58|5.519|classified 58.9% of frames correctly
2142.81|3.85|that's our big accurate model and now
2145.099|4.681|we're going to use that model to provide
2146.66|5.28|soft targets for a smaller model that
2149.78|3.48|also gets to see the hard targets and
2151.94|4.67|we're going to train it not only three
2153.26|6.42|percent of the data so the new model
2156.61|7.06|with the soft targets gets almost that
2159.68|6.48|accuracy fifty-seven percent and with
2163.67|4.41|just hard targets it drastically over
2166.16|3.93|fits and it gets to forty four point
2168.08|4.95|five percent accurate and then goes
2170.09|6.06|south so soft targets are really really
2173.03|4.89|good regularizer and the other thing is
2176.15|3.06|that because these soft targets have so
2177.92|2.91|much information in them compared to
2179.21|4.86|just a single one and a bunch of zeros
2180.83|5.75|you train much much faster you get to
2184.07|6.18|that accuracy and like phenomenal weak
2186.58|5.68|short amounts of time so that that's
2190.25|4.26|pretty nice and you can do this approach
2192.26|5.04|with like giant ensembles mapping into
2194.51|5.45|one sized model of that ensemble you can
2197.3|6.83|do from a large model into a smaller one
2199.96|8.35|somewhat underappreciated technique okay
2204.13|7.36|let's see so one of the things we did
2208.31|5.19|when we thought about building tensor
2211.49|4.59|flow was we kind of took a step back
2213.5|3.99|from where we were and we said what do
2216.08|2.82|you really want in a research system so
2217.49|3.0|you want a lot of different things and
2218.9|4.32|it's kind of hard to balance all of
2220.49|4.68|those things but really one of the
2223.22|4.47|things you really care about if your
2225.17|4.32|researcher is ease of expression I want
2227.69|7.49|to be able to take any old research idea
2229.49|5.69|and try it out yeah
2244.48|6.84|I don't remember the exact details there
2247.6|5.1|in this archived paper it was
2251.32|5.52|considerably smaller I think like
2252.7|7.35|instead of thousand wide fully connected
2256.84|6.51|layers it was like 600 or 500 wide which
2260.05|5.19|is actually big difference but checking
2263.35|7.98|that paper for the details I'm probably
2265.24|7.44|miss remembering right and then you want
2271.33|3.81|to be able to take your research idea
2272.68|4.02|scale it and run experiments quickly you
2275.14|3.77|want to be able to run it portably on
2276.7|4.29|both you know data centers and on phones
2278.91|4.27|it's nice to be able to reproduce things
2280.99|4.35|in you want to go from a good research
2283.18|4.22|idea to a production system without
2285.34|5.31|having to rewrite in some other system
2287.4|4.63|so that's how we kind of load the main
2290.65|4.92|things we were considering when building
2292.03|7.62|tensorflow we open sourced it as you're
2295.57|7.14|aware I kind of already said that our
2299.65|6.03|first system wasn't as flexible so the
2302.71|6.3|core bits of tensorflow are we have a
2305.68|4.86|notion of different devices it is
2309.01|2.85|portable so it runs on a bunch of
2310.54|3.66|different operating systems we have this
2311.86|4.05|core graph execution engine and then on
2314.2|3.0|top of that we have different front ends
2315.91|3.0|where you express the kinds of
2317.2|4.11|computations you're trying to do we have
2318.91|4.14|a C++ front-end which most people don't
2321.31|4.11|use in them we have the Python front-end
2323.05|4.53|which most of you are probably more
2325.42|3.69|familiar with where most thing but
2327.58|2.94|there's nothing preventing people from
2329.11|5.49|putting other languages on it we wanted
2330.52|7.17|to be fairly language neutral so there's
2334.6|5.28|some work going on to put a go front end
2337.69|5.04|on there other kinds of languages we
2339.88|4.2|think that'll be good and you want to be
2342.73|2.67|able to take that model and run it on a
2344.08|5.31|pretty wide variety of different
2345.4|5.4|platforms the basic computational model
2349.39|3.33|is a graph I don't know how much you
2350.8|3.53|talked about this in your overview of
2352.72|3.78|little bit okay so there's a graph
2354.33|4.27|things that flow along the edges or
2356.5|4.98|tensors so arbitrary and dimensional
2358.6|8.16|arrays with a primitive type like float
2361.48|6.9|or int unlike pure data flow models
2366.76|2.279|there's actually state in this graph so
2368.38|2.159|you have
2369.039|3.66|things like biases which is a variable
2370.539|4.38|and then you have operations that can
2372.699|3.63|update things that have persistent state
2374.919|3.06|so you can go through the whole graph
2376.329|7.25|compute some gradient and then adjust
2377.979|8.45|the biases based on the gradient the
2383.579|6.821|graph goes through a series of stages
2386.429|5.5|one important stage is deciding given a
2390.4|4.169|whole bunch of computational devices and
2391.929|5.16|the graph where are we going to run each
2394.569|5.01|of the different nodes in the graph in
2397.089|5.1|terms of computation so for example here
2399.579|5.76|we might have a CPU in blue and a GPU
2402.189|5.0|card in green and we might want to run
2405.339|5.21|the graph in such a way that all the
2407.189|6.971|extensive computation happens on the GPU
2410.549|5.56|so actually as an aside this placement
2414.16|3.869|decisions are kind of tricky we allow
2416.109|5.521|users to provide hints that guide this a
2418.029|5.46|bit and then given the hints which are
2421.63|3.889|not necessarily hard constraints on an
2423.489|4.44|exact device but might be something like
2425.519|7.3|you should really try to run this on a
2427.929|8.9|GPU or place it on task 7 and I don't
2432.819|6.51|care what device and then we want to
2436.829|3.88|basically minimize the time for the
2439.329|3.42|graph subject to all kinds of other
2440.709|7.86|constraints like the memory we have
2442.749|7.44|available on each GPU card or on CPUs I
2448.569|2.79|think it'd be interesting to actually
2450.189|2.28|use and roll that with some
2451.359|3.11|reinforcement learning because you can
2452.469|4.47|actually measure an objective here of
2454.469|4.51|you know if I place this node in this
2456.939|3.961|node in this node and this way how fast
2458.979|3.48|is my graph and I think that would be a
2460.9|5.849|pretty interesting reinforcement
2462.459|5.76|learning problem once we've made
2466.749|2.91|decisions of where to place things then
2468.219|3.24|we insert the send and receive nodes
2469.659|3.9|which essentially encapsulate all the
2471.459|3.63|communication in the system so basically
2473.559|2.85|when you want to move a tensor from one
2475.089|3.6|place to another there's a send node
2476.409|3.991|that'll kind of just hold on to the
2478.689|3.9|tensor until the receive node checks in
2480.4|5.459|and says hey I really love that data for
2482.589|7.02|that tensor and you do this for all the
2485.859|5.19|edges that cross device boundaries and
2489.609|3.031|you have different implementations of
2491.049|4.32|send and receive pairs depending on the
2492.64|4.169|device so you have for example if the
2495.369|3.45|GPUs are on the same machine you can
2496.809|4.56|often do our DMA directly from one GPUs
2498.819|3.721|memory to the other if they're on
2501.369|2.971|different machines then you do
2502.54|4.95|across machine RPC your network might
2504.34|5.37|support our DMA across the network in
2507.49|4.35|that case you would just use you know
2509.71|6.11|directly reach into this other GPUs
2511.84|6.42|memory on this other machine and grab it
2515.82|4.63|you can define new operations and
2518.26|4.14|kernels pretty easily
2520.45|6.45|session interfaces essentially how you
2522.4|6.3|run the graph and typically you run you
2526.9|4.02|set up a graph once and then you run it
2528.7|3.99|a lot so that allows us to kind of have
2530.92|6.27|the system do a lot of optimization and
2532.69|7.08|decisions about essentially how it wants
2537.19|4.98|to place computation nodes and perhaps
2539.77|4.71|do some experiments on like does it make
2542.17|3.69|more sense to put it here here because
2544.48|5.01|it's going to amortize that over lots
2545.86|5.1|and lots of run calls the single process
2549.49|3.6|configuration everything runs in one
2550.96|4.38|process and it's just sort of simple
2553.09|3.9|procedure calls in a distributed setting
2555.34|3.09|there's a client process a master
2556.99|4.41|process and then a bunch of workers that
2558.43|5.13|have devices and the master use client
2561.4|4.14|says I'd like to run this sub graph the
2563.56|4.05|master says oh okay that means I need to
2565.54|5.88|talk to process 1 & 2 and tell them to
2567.61|7.08|do stuff you can feed in fetch data and
2571.42|5.61|that means that I might sort of have a
2574.69|4.65|more complex graph but I only need to
2577.03|5.55|run little bits of it because I only
2579.34|7.53|need to run the parts of the computation
2582.58|8.15|that the outputs you asked for are are
2586.87|3.86|needed based on what you asked for it ah
2591.0|5.77|we focus a lot on being able to scale
2594.76|3.69|this to distributed environment we
2596.77|3.21|actually one of the biggest things when
2598.45|4.53|we first open sourced enter flow we
2599.98|5.91|hadn't quite carved apart a open source
2602.98|5.01|of all distributed implementation so
2605.89|3.84|that was github issue number 23 which
2607.99|5.1|got filed within like a day of our
2609.73|6.03|release said hey where's the distributed
2613.09|6.57|version we did the initial release last
2615.76|5.58|Thursday so that's good it'll get better
2619.66|3.6|packaging but at the moment you can kind
2621.34|4.07|of hand configure multiple processes
2623.26|5.43|with the names of the other processes
2625.41|5.11|involved IP addresses and ports we're
2628.69|5.01|going to package that up better in like
2630.52|5.4|a couple of weeks but that's there which
2633.7|2.52|is good and the whole reason to have
2635.92|3.0|that
2636.22|6.21|is that you want much better turnaround
2638.92|6.929|time for experiments so if you're in the
2642.43|5.189|mode where your training and experiment
2645.849|3.871|iteration is kind of minutes or hours
2647.619|4.201|that's really really good if you're in
2649.72|5.19|the mode of like multiple weeks that's
2651.82|5.13|kind of hopeless right like more than a
2654.91|3.75|month you you generally won't even do it
2656.95|4.58|or if you do you're like oh my
2658.66|6.209|experiments done why did I do that again
2661.53|5.2|so we really emphasize a lot in our
2664.869|5.73|group just being able to make it so
2666.73|10.35|people can do experiments as fast as as
2670.599|7.891|reasonable so the two main things we do
2677.08|3.24|our model parallelism and data
2678.49|5.129|parallelism I'll talk about both you've
2680.32|3.81|talked about this a little bit or okay
2683.619|3.511|great
2684.13|5.719|so the best way you can decrease time
2687.13|5.82|training time is decrease the step time
2689.849|4.541|so one of the really nice properties
2692.95|3.06|most neural Nets have is there's lots
2694.39|3.09|and lots of inherent parallelism right
2696.01|4.5|like if you think about a convolutional
2697.48|5.129|model there's lots of parallelism at
2700.51|3.57|each of the layers because all the
2702.609|4.861|spatial positions are mostly independent
2704.08|5.64|you can just run run them in parallel on
2707.47|4.139|different devices the problem is
2709.72|4.139|figuring out how to communicate how to
2711.609|5.191|distribute that computation in such a
2713.859|5.551|way that communication doesn't kill you
2716.8|4.68|a few things help you so one is local
2719.41|4.199|connectivity like convolutional neural
2721.48|3.6|nets have this nice property that
2723.609|3.781|they're generally looking at like a five
2725.08|5.67|by five patch of data below them and
2727.39|5.07|they don't need anything else and the
2730.75|4.41|neuron next to it has a whole lot of
2732.46|5.46|overlap with the data it needs for for
2735.16|4.38|that first neuron you can have towers
2737.92|4.38|with little or no connectivity between
2739.54|4.23|the towers so every few layers you might
2742.3|4.35|communicate a little bit but mostly you
2743.77|5.31|don't the original Alex net paper did
2746.65|4.14|that so it essentially had two separate
2749.08|4.56|towers that mostly ran independently on
2750.79|5.46|GPUs two different GPUs and occasionally
2753.64|3.99|exchanged some information you can have
2756.25|5.25|specialized parts of the model that are
2757.63|5.84|active only for some examples there's
2761.5|5.67|lots of ways to exploit parallelism so
2763.47|5.74|when you're just naively compiling
2767.17|2.92|matrix-multiply code with GCC or
2769.21|2.14|something yet
2770.09|4.38|probably already take advantage of
2771.35|6.15|instruction parallelism present on Intel
2774.47|5.7|CPUs across cores you can use thread
2777.5|6.0|parallelism and and spread things that
2780.17|5.43|way across devices communicating between
2783.5|4.59|GPUs is often pretty limited so you have
2785.6|4.44|like a factor of 30 to 40 better
2788.09|4.77|bandwidth to the local GPU memory than
2790.04|5.49|you do to like another GPU cards memory
2792.86|4.86|on the same machine and across machine
2795.53|4.5|boundaries is generally even worse so
2797.72|4.26|it's pretty important to kind of keep as
2800.03|5.04|much data local as you can and avoid
2801.98|5.15|needing too much communication bandwidth
2805.07|4.35|but model parallelism the basic idea is
2807.13|4.72|you're just going to partition the
2809.42|6.8|computation of the model somehow maybe
2811.85|10.71|spatially like this maybe layer by layer
2816.22|7.9|and then in this case for example the
2822.56|3.27|only communication I need to do is that
2824.12|4.02|this boundary you know some of the data
2825.83|3.78|from partition 2 is needed for the input
2828.14|6.69|of that partition 1 but mostly all the
2829.61|8.22|data is local the other technique you
2834.83|4.83|can use for speeding up convergence is
2837.83|4.32|data parallelism so in that case you're
2839.66|4.05|going to use many different replicas of
2842.15|2.76|the same model structure and they're all
2843.71|5.09|going to collaborate to update
2844.91|6.44|parameters so in some shared set of
2848.8|5.23|servers that hold the parameter state
2851.35|4.81|speed ups depend a lot on the kind of
2854.03|5.25|model you know it could be 10 to 40 X
2856.16|6.21|speed-up for 50 replicas sparse models
2859.28|4.83|with like really large embeddings for
2862.37|3.57|every vocabulary word none demand
2864.11|3.99|generally you can support more
2865.94|3.77|parallelism because most updates only
2868.1|3.57|update a handful of the embedding
2869.71|3.64|entries you know if you have a sentence
2871.67|4.08|that has like 10 unique words in it out
2873.35|4.91|of a million and you can have millions
2875.75|5.97|and millions are thousands of replicas
2878.26|4.93|doing lots of work so the basic idea in
2881.72|2.76|data parallelism is you have these
2883.19|3.81|different model replicas you're going to
2884.48|4.53|have the centralized system that keeps
2887.0|3.54|track of the parameters that may not
2889.01|2.97|just be a single machine it may be a lot
2890.54|5.4|of machines because you need a lot of
2891.98|6.12|network bandwidth sometimes to keep all
2895.94|4.02|these model replicas fed with parameters
2898.1|5.09|so that might you know in our big setups
2899.96|5.36|that might be 127 machines the top
2903.19|4.29|and then you know you might have 500
2905.32|4.41|replicas of the models down there and
2907.48|3.81|before every model replica does a mini
2909.73|4.98|batch it's going to grab the parameters
2911.29|4.83|so it says okay you hundred and twenty
2914.71|5.37|seven machines give me the parameters
2916.12|6.39|and then it does a computation of a
2920.08|4.56|random mini batch and figures out what
2922.51|3.39|the gradient should be it doesn't apply
2924.64|2.49|the gradient locally it sends the
2925.9|3.47|gradient back to the parameter servers
2927.13|5.52|parameter servers then update the
2929.37|6.45|current parameter values and then before
2932.65|5.31|the next step we do the same thing
2935.82|4.21|fairly Network intensive depending on
2937.96|3.42|your model things that help here are
2940.03|3.81|models that don't have very many
2941.38|4.44|parameters convolutions are really nice
2943.84|4.77|in that respect LS TMS are nice in that
2945.82|4.92|respect because you're essentially then
2948.61|4.74|reusing every parameter lots and lots of
2950.74|5.7|times so you already reuse it you know
2953.35|4.71|however big your batch size is on the
2956.44|2.76|model so if your batch size is 128
2958.06|3.06|you're going to bring a parameter over
2959.2|3.93|you can use it 128 times for all the
2961.12|3.84|different elements in the batch but if
2963.13|4.02|you have a convolutional model now
2964.96|4.11|you're going to get an additional factor
2967.15|4.17|of reuse of maybe like 10,000 different
2969.07|5.16|positions in a layer that you're going
2971.32|4.65|to reuse it and an LS TM if you unroll
2974.23|5.78|100 time steps you're going to reuse it
2975.97|6.35|a hundred times just for the unrolling
2980.01|4.6|so those kinds of things that have
2982.32|5.32|models that have lots of computation and
2984.61|4.68|fewer parameters to sort of drive that
2987.64|4.17|computation generally will work better
2989.29|7.08|in data parallel environments
2991.81|6.21|now there's an obvious issue depending
2996.37|3.48|on how you do this so one way you can do
2998.02|3.18|this is completely asynchronously every
2999.85|4.5|model replica is just sitting in a loop
3001.2|5.1|and fetching the parameters doing a mini
3004.35|3.84|batch computing radiant's sending it up
3006.3|3.6|there and if you do that asynchronously
3008.19|4.29|then the gradient it computes may be
3009.9|4.44|completely stale with respect to the
3012.48|3.6|where the parameters are now right
3014.34|4.02|you've computed it with respect to this
3016.08|4.23|parameter value but meanwhile ten other
3018.36|3.96|replicas if mid calls the parameters can
3020.31|4.32|be ander over to here and now you apply
3022.32|5.01|the gradient that you thought was for
3024.63|4.28|here to this value so it makes
3027.33|3.51|theoreticians incredibly uncomfortable
3028.91|5.05|they're already uncomfortable because
3030.84|5.9|it's completely non convex problems but
3033.96|2.78|the good news is it worked
3037.18|5.53|up to a certain level it would be really
3039.92|4.71|good to understand the conditions under
3042.71|4.65|which you know this works in a more
3044.63|4.35|theoretical basis but in practice it
3047.36|2.88|does seem to work pretty well the other
3048.98|3.03|thing you can do is do this completely
3050.24|3.87|synchronously so you can have one
3052.01|3.99|driving loop that says okay everyone go
3054.11|3.18|they all get the parameters they all
3056.0|2.64|compute gradients and then you wait for
3057.29|2.73|all the gradients to show up and do
3058.64|3.92|something with the gradients average
3060.02|4.68|them or add them together and that
3062.56|4.24|effectively just looks like a giant
3064.7|4.44|batch if you have our replicas that
3066.8|5.45|looks like you know our times each
3069.14|5.19|individual ones batch size which
3072.25|3.97|sometimes works you kind of get
3074.33|4.44|diminishing returns from larger and
3076.22|6.24|larger batch sizes but the more training
3078.77|5.94|examples you have the more tolerant you
3082.46|4.11|are of a bigger batch size generally if
3084.71|3.78|you have a trillion training examples
3086.57|3.84|you know a batch size of 8,000 is sort
3088.49|4.08|of okay if you have a million training
3090.41|7.8|examples batch size of 8,000 is not so
3092.57|8.37|great right I think I said this there's
3098.21|5.25|even more complicated choices where you
3100.94|6.81|can have like M asynchronous groups of
3103.46|8.58|ends in your disrupting is all right I
3107.75|5.73|said that convolutions our current
3112.04|5.04|models are good because they reuse the
3113.48|4.83|parameters a lot so data parallelism is
3117.08|3.57|actually really really important for
3118.31|5.4|almost all of our models that's how we
3120.65|8.27|get to the point of training models in
3123.71|7.65|like half a day or a day generally so
3128.92|8.47|you know you see some of the rough kinds
3131.36|10.23|of setup for use and here's an example
3137.39|7.74|training graph of imagenet model one GPU
3141.59|6.03|ten GPUs 50 GPUs and there's the kind of
3145.13|4.05|speed up yet right like sometimes these
3147.62|3.96|graphs are deceiving like the difference
3149.18|4.71|between 10 and 50 is doesn't seem that
3151.58|5.16|big like because lines are kind of close
3153.89|4.71|to each other sort of but in actual fact
3156.74|5.25|the difference between 10 and 50 is like
3158.6|5.16|a factor of 4.1 or something so that
3161.99|5.69|doesn't look like a factor of 4.1
3163.76|3.92|difference does it but it is
3168.73|4.089|anyway yeah the way you do it is you you
3171.47|3.18|like see where that one crosses point
3172.819|9.27|six and see where that one crosses my
3174.65|9.15|text okay so let me show you some of the
3182.089|3.931|slight tweaks you make to tensorflow
3183.8|4.019|models to exploit these different kinds
3186.02|3.15|of parallelism one of the things we
3187.819|4.111|wanted was for these kinds of
3189.17|4.949|parallelism notions to be pretty easy to
3191.93|4.95|express so one of the things we like
3194.119|4.71|about tensorflow is it Maps pretty well
3196.88|4.8|to the kind of the things you might see
3198.829|4.73|in a research paper so it's not nope you
3201.68|6.659|don't have to read all that but it's not
3203.559|6.731|too different than what you would see in
3208.339|5.97|the research paper just kind of nice
3210.29|7.289|that's like a simple elf stem cell this
3214.309|4.981|is the sequence to sequence model that
3217.579|5.04|Elias let's giver Oreo venules and
3219.29|4.44|quickly published nips 2014 we're
3222.619|2.521|essentially trying to take an input
3223.73|5.43|sequence and map it to an output
3225.14|5.61|sequence this is a really big area of
3229.16|3.06|research it turns out these kinds of
3230.75|4.92|models are applicable for lots and lots
3232.22|5.55|of kinds of problems there's lots of
3235.67|10.26|different groups doing interesting and
3237.77|10.95|active work in this area yeah so here's
3245.93|6.24|just some examples of recent work in the
3248.72|6.74|last year and a half in this area from
3252.17|3.29|lots of different labs around the world
3255.609|5.531|you've already talked about a captioning
3258.41|8.49|is cool yes so instead of a sequence you
3261.14|8.07|can put in pixels so you put in pixels
3266.9|5.37|you run it through a CNN that's your
3269.21|7.02|initial state and then you can generate
3272.27|5.52|captions it's pretty amazing so if you'd
3276.23|4.05|asked me five years ago can computer do
3277.79|5.67|that I was then I don't think so not for
3280.28|5.25|a while here we are it can actually do
3283.46|3.3|and the nice thing is it's a generative
3285.53|3.87|model so you can generate different
3286.76|4.89|sentences by exploring the distribution
3289.4|4.59|you know I think both of those are nice
3291.65|7.79|captions it's not quite as sophisticated
3293.99|5.45|as the human one you'll often see this
3299.75|6.84|one of the things is if you if you train
3303.29|4.71|the model a little bit it's really
3306.59|5.07|important to retrain your models to
3308.0|4.17|convergence because like that's not so
3311.66|3.33|good
3312.17|6.95|but if you train that model longer it's
3314.99|4.13|the same model it just got a lot better
3320.26|4.93|same thing here right train that is
3323.84|4.56|sitting on the tracks yes that's true
3325.19|4.98|but that one's that one's better but you
3328.4|3.66|still see the human has a lot more
3330.17|4.02|sophistication right like they know that
3332.06|4.5|they're across the tracks near a Depot
3334.19|6.68|and that's sort of a more subtle thing
3336.56|6.84|that the models will pick up on another
3340.87|3.79|kind of cute use of LSD m's you can
3343.4|6.65|actually use them to solve all kinds of
3344.66|9.39|cool graph problems so oreal venules
3350.05|6.55|mara fortunato and FDP i did this work
3354.05|6.03|which you start with that set of points
3356.6|5.94|and then you try to predict the
3360.08|6.26|traveling salesman tour for that that
3362.54|7.62|works best or the convex hull or dallona
3366.34|6.1|triangulation of graphs it's kind of
3370.16|3.66|cool you know it's just a sequence to
3372.44|2.82|sequence problem where you feed in the
3373.82|3.57|sequence of points and then the output
3375.26|6.81|is the right set of points for whatever
3377.39|5.97|problem you care about I already talked
3382.07|5.34|about smart reply okay
3383.36|6.17|so LS GM's so once you have that L STM
3387.41|6.2|cell code that I showed you I'm there
3389.53|6.49|you can unroll it in time 20 time steps
3393.61|4.57|let's say you wanted four layers per
3396.02|3.78|time step instead of one well you would
3398.18|4.62|make a little bit of change to your code
3399.8|6.24|and you would do that now you have four
3402.8|4.47|layers of computation instead of one one
3406.04|3.12|of the things you might want to do is
3407.27|4.17|run each of those layers on a different
3409.16|4.98|GPU so that's the change you would make
3411.44|4.23|to your console flow code to do that and
3414.14|4.05|that then allows you to have a model
3415.67|4.86|like this so this is my sequence these
3418.19|5.94|are the different deep LS TM layers I
3420.53|6.42|have per time step and after the first
3424.13|5.31|little bit I can start getting more and
3426.95|3.75|more GPUs kind of involved in the
3429.44|3.54|process
3430.7|3.36|ah and you essentially pipeline the
3432.98|2.97|entire thing
3434.06|3.98|there's a giant softmax at the top but
3435.95|5.07|you can split across GPUs pretty easily
3438.04|6.4|so that's model parallelism right we've
3441.02|4.95|now got six GPUs in this picture we
3444.44|5.13|actually use eight we split the softmax
3445.97|6.06|across four GPUs and then so every
3449.57|4.92|replica would be eight GPU cards on the
3452.03|4.68|same machine all kind of humming along
3454.49|4.47|and then you might use data parallelism
3456.71|5.1|in addition to that to train you know a
3458.96|6.45|bunch of eight GPU card replicas to
3461.81|5.43|train quickly we have this notion of
3465.41|3.689|queues so you can kind of have tensor
3467.24|4.83|flow graphs that do a bunch of stuff and
3469.099|5.281|then stuff it in a queue and then later
3472.07|4.259|you have another bit of tensor flow
3474.38|4.83|graph that starts with D queuing some
3476.329|4.77|stuff and then does some things so one
3479.21|3.99|one example is you might want to
3481.099|4.531|prefetch inputs and then like do the
3483.2|4.95|JPEG decoding to convert them into sort
3485.63|4.56|of arrays and maybe do some whitening
3488.15|5.4|and cropping a random crop selection and
3490.19|6.419|that's stuff them in a cube and then you
3493.55|5.97|can then DQ on say different GPU cards
3496.609|6.151|or something we also can group similar
3499.52|5.28|examples so for translation work we
3502.76|5.04|actually bucket by length of sentence so
3504.8|4.35|that your batch has a bunch of examples
3507.8|3.96|that are all roughly the same sentence
3509.15|5.01|length all thirteen to sixteen word
3511.76|4.65|sentences or something that just means
3514.16|4.89|we then need to only execute exactly
3516.41|5.459|that many unrolled steps rather than you
3519.05|4.289|know arbitrary max sentence length it's
3521.869|3.601|good for randomization and shuffling so
3523.339|3.621|we have a shuffling queue you can just
3525.47|9.96|stuff a whole bunch of examples and then
3526.96|10.47|get random ones out oh yeah I don't know
3535.43|5.25|what I'm saying
3537.43|4.81|data parallelism right so again we want
3540.68|6.24|to be able to have many replicas of this
3542.24|6.93|thing and so you make modest amounts of
3546.92|4.59|changes to your code we're not quite as
3549.17|3.51|happy with this amount of change but
3551.51|3.12|this is kind of what you would do
3552.68|3.72|there's a supervisor that has a bunch of
3554.63|6.02|things you now say there's parameter
3556.4|6.62|devices and then prepare the session
3560.65|5.31|and then each one of these runs a local
3563.02|4.59|loop and you now keep track of how many
3565.96|3.69|steps have been applied globally across
3567.61|4.23|all the different replicas and as soon
3569.65|6.99|as the cumulative sum of all those is
3571.84|6.0|big enough they all exit so asynchronous
3576.64|2.55|training looks kind of like that you
3577.84|4.77|have three separate client threads
3579.19|4.74|driving three separate replicas all with
3582.61|2.73|parameter devices so one of the big
3583.93|3.12|simplifications from disbelief to
3585.34|3.87|tensorflow is we don't have the separate
3587.05|6.42|parameter server notion anymore
3589.21|6.93|we have tensors and variables variables
3593.47|5.43|that contain tensors and they're just
3596.14|4.56|other parts of the graph and typically
3598.9|3.24|you map them on to a small set of
3600.7|4.2|devices they're gonna hold view
3602.14|3.87|parameters but it's all kind of unified
3604.9|3.33|in the same framework whether I'm
3606.01|3.69|sending a tensor that's parameters or
3608.23|4.83|activations or whatever it doesn't
3609.7|5.91|matter this is kind of a synchronous
3613.06|5.19|view I have one client and I just split
3615.61|6.72|my batch across three replicas and add
3618.25|5.57|the gradient and apply them neural nets
3622.33|5.4|turn out to be pretty tolerant of
3623.82|7.42|reduced precision so you know convert to
3627.73|5.67|FP 16 there's actually an I Triple E
3631.24|4.95|standard for 16-bit floating points now
3633.4|5.72|floating point values now most CPUs
3636.19|6.27|don't quite support that yet so we
3639.12|5.02|implemented our own 16-bit format which
3642.46|5.45|is essentially we have a 32-bit float
3644.14|3.77|and we lop off two bytes in mantissa and
3648.48|5.19|you should kind of do stochastic
3650.86|7.47|probabilistic rounding but we don't so
3653.67|6.76|sort of okay it's just noise and then
3658.33|5.73|you can convert it to 32 bits on the
3660.43|14.4|other side by filling in zeros it's it's
3664.06|12.92|very CPU friendly no typos well so model
3674.83|4.65|and data parallelism in conjunct
3676.98|4.33|really lets you train models quickly and
3679.48|5.13|that's what this is all really about is
3681.31|5.31|being able to take a research idea try
3684.61|3.63|it out on a large data set that's
3686.62|4.32|representative of a problem you care
3688.24|5.14|about figure out did that work figure
3690.94|3.849|out what the next set of experiments is
3693.38|3.179|it's pretty easy to express some
3694.789|3.48|tensorflow the data parallelism were not
3696.559|5.49|so happy with for asynchronous
3698.269|7.08|parallelism but in general it's it's not
3702.049|6.48|too bad we've open-sourced tensorflow
3705.349|6.541|because we think that'll make it easier
3708.529|7.111|to share research ideas we think you
3711.89|5.55|know having lots of people using the
3715.64|3.959|system outside of Google is a good thing
3717.44|5.429|they'll improve it and bring ideas that
3719.599|4.98|we don't necessarily have it makes it
3722.869|3.271|pretty easy to deploy machine learning
3724.579|4.23|systems into real products because you
3726.14|3.54|can go from a research idea into
3728.809|3.24|something running out of phone
3729.68|3.869|relatively easily the community of
3732.049|3.54|tensorflow users outside Google is
3733.549|3.57|growing which is nice they're doing all
3735.589|4.44|kinds of cool things so I picked a few
3737.119|5.581|random examples of things people have
3740.029|5.82|done that are posted in github this is
3742.7|5.97|one that's like a Andre has this this
3745.849|5.071|convinent J's which runs neural nets in
3748.67|4.32|your browser using javascript and one of
3750.92|4.08|the things he has is a little game uses
3752.99|4.65|reinforcement learning where the yellow
3755.0|4.74|dot learns that I think it learns to eat
3757.64|3.24|the oh yeah learns to eat the green dots
3759.74|3.029|and avoid the red dots
3760.88|3.78|so someone reimplemented that in
3762.769|8.34|tensorflow and actually added orange
3764.66|8.159|dots that are really bad and someone
3771.109|3.571|implemented this really nice paper from
3772.819|3.331|University of Tor brigand and the Mac
3774.68|3.629|spawn gets to do - I don't have you seen
3776.15|4.5|this work where you take an image a
3778.309|6.181|picture and typically a painting and
3780.65|6.48|then it renders the the picture in the
3784.49|5.029|style of that painter and you end up
3787.13|5.129|with cool stuff like that
3789.519|7.09|so someone implemented that you know
3792.259|6.27|there's a character or an end model the
3796.609|3.48|kiosk is a popular sort of higher-level
3798.529|6.121|library to make it easier to express
3800.089|7.52|roll mats someone implemented the the
3804.65|5.76|neural captioning model in Penzer flow
3807.609|7.621|there's a effort underway to translate
3810.41|7.59|it into Mandarin it's cool it's great
3815.23|4.389|the last thing I will talk about is the
3818.0|3.42|brain residency program so we've started
3819.619|5.67|this program it's a bit of an experiment
3821.42|4.409|this year so this is more as an FYI for
3825.289|1.651|next
3825.829|2.49|here because our applications were
3826.94|4.379|closed we're actually selecting our
3828.319|6.0|final candidates this week and then the
3831.319|5.19|idea is the people will spend a year in
3834.319|5.7|our group doing deep learning research
3836.509|5.34|and the hope is they'll come out and
3840.019|3.48|have published a couple of papers on
3841.849|5.19|archive or submitted to conferences and
3843.499|4.98|learn a lot about doing sort of
3847.039|6.18|interesting machine learning research
3848.479|8.82|and you know we're looking for people
3853.219|6.09|for next year obviously that are strong
3857.299|4.31|in you know anyone taking this class
3859.309|5.97|would probably that's what fits the bill
3861.609|6.4|will reopen applications in the fall so
3865.279|7.7|if you're graduating like next year this
3868.009|10.171|could be a good opportunity there you go
3872.979|7.901|there's a bunch more reading there start
3878.18|4.349|here because I did a lot of work in the
3880.88|6.479|tensorflow white paper to make the whole
3882.529|6.48|set of references clickable and so you
3887.359|6.0|can click your way through to 50 other
3889.009|8.0|papers okay it's all I have I'm done
3893.359|3.65|early 165
3905.31|6.309|yeah so it seems like models like smart
3908.83|4.92|reply get better with the more data you
3911.619|4.98|have Google probably has the biggest
3913.75|4.89|dataset of email in the world but people
3916.599|3.931|are kind of might be like uncomfortable
3918.64|4.02|with having a private email being used
3920.53|4.65|for it's sort of like how do you guys
3922.66|6.54|handle this sort of privacy after
3925.18|6.15|singing yes so those kinds of things are
3929.2|4.649|actually tricky and we have it actually
3931.33|4.89|a pretty extensive detailed process for
3933.849|6.27|things that are you know talking about
3936.22|6.75|you know using a user's private data for
3940.119|4.921|these kinds of things so for smart reply
3942.97|3.72|essentially all the replies that were
3945.04|4.079|gen that it ever will generate are
3946.69|5.64|things that have been said by thousands
3949.119|6.091|of users so the input to the model for
3952.33|4.98|training is an email which is typically
3955.21|3.93|not set by thousands people but the only
3957.31|5.039|things we'll ever suggest are things
3959.14|4.92|that are generated in response by you
3962.349|4.891|know sufficient number of unique users
3964.06|4.59|to protect the privacy of the users so
3967.24|2.79|that's the kind of things you're
3968.65|3.03|thinking about when designing products
3970.03|5.73|like that and there's actually a lot of
3971.68|6.47|care and thought going into you know we
3975.76|4.859|think this would be a great feature but
3978.15|4.09|how can we do this in a way that that
3980.619|5.871|ensures that people's privacy is
3982.24|4.25|protected yeah
3989.44|6.58|engine donatello situation remember from
3993.05|7.11|the paper as for working on this massive
3996.02|5.91|jpg dataset and you guys at some point
4000.16|4.29|decide that we need a lot of different
4001.93|5.93|specialist networks in order to work
4004.45|5.61|some of the more difficult aspects and
4007.86|4.09|at some point in the paper you guys
4010.06|3.78|mentioned technology considering the
4011.95|3.9|possibility of them distilling all these
4013.84|5.34|different specialists into a single
4015.85|5.0|larger network I think there's a large
4019.18|4.71|there's already some work done to fire
4020.85|5.86|running through the use of polycast
4023.89|4.5|learning and such for medical specialist
4026.71|3.42|for different games it's going to in
4028.39|3.75|single thing but that was still a
4030.13|3.87|relatively small scale and I was
4032.14|4.2|wondering you know everybody considered
4034.0|7.8|has there been something further work
4036.34|7.95|done on our scale distillation so we
4041.8|6.26|haven't pursued the distillation work as
4044.29|6.0|much as we probably should have should
4048.06|3.91|it's just kind of been one of the things
4050.29|3.03|on the back burner compared to all the
4051.97|5.04|other things we've been working on I do
4053.32|4.86|think the notion of specialists so I
4057.01|3.36|didn't talk about that at all but
4058.18|4.26|essentially we had a model that was a
4060.37|4.92|sort of an arbitrary imagenet
4062.44|4.8|classification model or like jft which
4065.29|4.44|is like 17,000 glasses or something it's
4067.24|4.35|an internal data set so we trained a
4069.73|5.03|good general model that could deal with
4071.59|6.48|all those classes and then we found
4074.76|5.74|interesting confused confusable classes
4078.07|3.81|that auto algorithmically like all the
4080.5|3.81|kinds of mushrooms in the world and we
4081.88|5.1|would train specialists on data sets
4084.31|4.26|that were enriched with only mushroom
4086.98|5.82|data primarily and then occasional
4088.57|6.06|random images and we could train 50 such
4092.8|3.78|models that were each good at different
4094.63|6.84|kinds of things and get pretty
4096.58|8.07|significant accuracy increases at the
4101.47|5.16|time we were able to distill it into a
4104.65|3.69|single model pretty well but we haven't
4106.63|4.26|really pursued that too much turns up
4108.34|4.95|just the mechanics of then training 50
4110.89|7.17|separate models and then distilling them
4113.29|7.95|is a bit unwieldy yeah
4118.06|6.09|I had a question about the partiers in
4121.24|5.7|the big model in the hizzle model but
4124.15|5.04|you've been worrying to think that a
4126.94|4.11|small model and we optimized it with
4129.19|3.81|plastic it means we only get like 40%
4131.05|3.63|racing and when we automate it with
4133.0|4.2|other techniques get 60% accuracy
4134.68|4.71|because like using the capacity of the
4137.2|5.81|model is enough to solve the text with
4139.39|7.469|we don't know how to optimize properly
4143.01|9.46|so like doesn't it mean that we fail at
4146.859|8.281|optimizing everything in some way i i
4152.47|4.5|will first say i think the area of
4155.14|4.08|optimization is a ripe one for
4156.97|3.63|exploration and further research because
4159.22|5.16|as you say this clearly demonstrates
4160.6|5.31|that we're i mean it's a different
4164.38|4.08|objective we're telling the model to do
4165.91|5.1|right we're telling it to use this hard
4168.46|4.41|label or use this hard label and also
4171.01|5.16|get this incredibly rich gradient which
4172.87|5.01|says like here's a hundred other signals
4176.17|3.99|of information so in some sense it's an
4177.88|5.25|unfair comparison right it you're
4180.16|5.85|telling it a lot more stuff about every
4183.13|4.62|example in that case so in some times
4186.01|4.14|it's not so much an optimization failing
4187.75|4.37|it's maybe we should be figuring out how
4190.15|5.58|to feed richer signals than just a
4192.12|5.56|single binary label to our models I
4195.73|4.71|think that's probably an interesting
4197.68|5.01|area to pursue we've thought about ideas
4200.44|5.13|of having a big ensemble of models all
4202.69|4.62|training collectively and sort of
4205.57|3.36|exchanging information in the form of
4207.31|3.48|their predictions rather than in their
4208.93|5.6|parameters because that might be a much
4210.79|6.15|cheaper more network friendly way of
4214.53|4.48|collaboratively training on a really big
4216.94|3.75|data set each train on one percent of
4219.01|4.61|the day or something and swap
4220.69|2.93|predictions
4224.5|19.86|simple thing where you take the the
4226.03|21.38|captions like yeah I mean I think all
4244.36|6.09|these kinds of ideas are worth pursuing
4247.41|5.77|the the captioning work is interesting
4250.45|5.67|but it tends to we tend to have many
4253.18|5.73|fewer labels with captions than we have
4256.12|7.83|images with sort of hard labels like
4258.91|6.78|cheetah or Jaguar at least that are
4263.95|4.62|prepared in a clean way I think actually
4265.69|4.62|on the web there's a lot of images with
4268.57|3.57|sentences written about them the trick
4270.31|13.74|is identifying which sentence is about
4272.14|13.59|which image yeah yeah yeah so it depends
4284.05|3.0|on the problem some problems you know
4285.73|3.03|you don't need to really train online
4287.05|4.2|like speech recognition is a good
4288.76|5.52|example it's not like human vocal cords
4291.25|5.07|change that often the words you say
4294.28|3.75|change a little bit so query
4296.32|5.13|distributions tend to be not very
4298.03|6.66|stationary right like the words everyone
4301.45|4.53|collectively says tomorrow are pretty
4304.69|4.86|similar to the ones they say today but
4305.98|5.25|subtly different like Long Island
4309.55|3.36|Chocolate Festival might suddenly become
4311.23|3.99|more and more prominent over the next
4312.91|3.45|two weeks or something and those kinds
4315.22|3.75|of things you know you need to be
4316.36|4.26|cognizant of the fact that you want to
4318.97|4.08|capture those kinds of effects and one
4320.62|4.74|of the ways to do it is to train your
4323.05|4.11|model in an online manner sometimes it
4325.36|3.39|doesn't need to be so online that you
4327.16|3.78|like get an example and immediately
4328.75|3.54|update your model but you know depending
4330.94|6.18|on the problem every five minutes or ten
4332.29|8.33|minutes or hour or day is sufficient for
4337.12|7.14|most problems but it is pretty important
4340.62|6.76|to do that for non-stationary problems
4344.26|7.95|like ads or search queries or things
4347.38|6.63|that change over time like that yeah you
4352.21|2.77|mentioned that rankbrain was the third
4354.01|4.78|most
4354.98|19.2|research water 1 2 if you can tell us I
4358.79|17.58|can't say yes yeah yeah I mean noise and
4374.18|3.87|training data sets actually happens all
4376.37|4.59|the time right like even if you look at
4378.05|4.11|the image net examples occasionally
4380.96|4.32|you'll come across one and you're like
4382.16|4.47|actually I was just sitting in a meeting
4385.28|3.0|with some people who are working on
4386.63|4.23|visualization techniques and one of the
4388.28|4.8|things that were visualizing was see far
4390.86|3.93|input data and they had this kind of
4393.08|4.71|cool representation of all the c4
4394.79|5.82|examples all mapped down to like 4 by 4
4397.79|4.74|pixels each on their screen so 60,000
4400.61|3.45|images and like you could kind of pick
4402.53|3.84|things out and select and sort and
4404.06|5.19|you're like oh here's one that like the
4406.37|7.17|model predicted with high confidence but
4409.25|6.48|it got wrong and it's at airplane as the
4413.54|6.15|models that are playing and you look at
4415.73|6.54|the image and it's an airplane and the
4419.69|8.46|label is not airplane you're like oh I
4422.27|8.43|understand why I got it wrong so it's
4428.15|3.81|you know you want to make sure your data
4430.7|3.3|set is as clean as possible because
4431.96|6.33|training at noisy data is generally not
4434.0|6.69|as good as clean data but on the other
4438.29|5.1|hand expending too much effort to clean
4440.69|5.16|the data is often more more effort than
4443.39|5.55|it's worth so you kind of do some
4445.85|5.13|filtering kinds of things to you know
4448.94|5.28|throw out the obvious bad stuff and
4450.98|6.68|generally more noisy data is often
4454.22|3.44|better than less clean data
4462.05|6.46|depends on the problem but but certainly
4465.3|4.41|that's one thing to try and then if
4468.51|7.97|you're unhappy with the result then
4469.71|8.39|investigate why other questions okay
4476.48|4.71|cool
4478.1|3.09|thank you