start_time|end_time|text
0.38|5.11|so before we get to dive into some of
2.79|4.859|the material today on loss functions and
5.49|4.439|optimization I wanted to go over some
7.649|3.811|administrative things first just as a
9.929|3.54|reminder the first assignment is due on
11.46|4.589|next Wednesday so you have roughly nine
13.469|5.4|days left and just as a warning Monday
16.049|4.74|is holidays so there will be no class no
18.869|4.381|office hours so plan out your time
20.789|3.811|accordingly to make sure that you can
23.25|3.18|complete the assignment in time of
24.6|3.48|course you also have some late days that
26.43|5.849|you can use and allocate among your
28.08|5.88|assignments as you see fit okay so
32.279|3.061|diving into the material first I'd like
33.96|4.14|to remind you where we are currently
35.34|4.44|last time we looked at this problem of
38.1|3.6|visual recognition and specifically at
39.78|3.63|image classification and we were talking
41.7|3.24|about the fact that this is actually a
43.41|3.18|very difficult problem right so if you
44.94|3.99|just consider the cross-product of all
46.59|5.07|the possible variations that we have to
48.93|4.68|be robust to when we recognize any of
51.66|3.329|these categories such as cat it just
53.61|3.81|seems like such an intractable and
54.989|4.171|possible problem and not only do we know
57.42|3.299|how to solve these problems now but we
59.16|3.809|can solve this problem for thousands of
60.719|4.62|categories and the state-of-the-art
62.969|3.991|methods work almost at human accuracy or
65.339|5.191|even slightly surpassing it and some of
66.96|6.75|those at classes and it also runs nearly
70.53|5.4|in real time on your phone and so
73.71|4.26|basically and all of this also happened
75.93|3.57|in the last three years and also you'll
77.97|2.85|be experts by the end of this class on
79.5|3.57|all of this technology so it's really
80.82|3.659|cool and exciting ok so that's the
83.07|2.189|problem of image classification and
84.479|2.43|visual recognition
85.259|2.821|we talked specifically about the data
86.909|2.85|driven approach and the fact that we
88.08|3.3|can't just explicitly hard-code these
89.759|4.021|classifiers so we have to actually train
91.38|4.02|them from data and so we looked at the
93.78|3.12|idea of having different the training
95.4|3.24|data having different validation splits
96.9|3.66|where we test out our hyper parameters
98.64|3.96|and a test that that you don't touch too
100.56|3.36|much we look specifically at the example
102.6|3.839|of the nearest neighbor classifier and
103.92|4.379|someone and the K nearest neighbor
106.439|3.18|classifier and I talked about the CFR 10
108.299|4.261|dataset which is our tow data set that
109.619|5.971|we play with during this class then I
112.56|5.4|introduce the idea of this approach that
115.59|4.29|I termed parametric approach which is
117.96|5.189|really that we're writing a function f
119.88|5.309|from image directly to the raw tenant
123.149|3.601|scores if you have ten classes and this
125.189|4.8|parametric form we seem to be a linear
126.75|4.56|first so we just have F equals WX and we
129.989|2.791|talked about the interpretations of this
131.31|2.49|linear classifier the fact that you can
132.78|2.7|interpret it as match
133.8|3.24|templates or that you can interpret it
135.48|2.94|as these images being in a very high
137.04|3.41|dimensional space and our linear
138.42|5.1|classifiers are kind of going in and
140.45|6.25|coloring this space by class scores so
143.52|5.4|to speak and so by the end of the class
146.7|4.17|we got to this picture where we suppose
148.92|3.87|we have a training example training data
150.87|4.08|set of just three images here along the
152.79|4.47|columns and we have some classes say ten
154.95|4.74|classes in C for ten and basically this
157.26|4.59|function f is assigning scores for every
159.69|3.45|single one of these images with some
161.85|3.3|particular setting of weights which I've
163.14|3.96|chosen randomly here we get some scores
165.15|3.54|out and so some of these results are
167.1|3.18|good and some of them are bad so if you
168.69|3.33|inspect this course for example in the
170.28|3.93|first image you can see that the correct
172.02|4.41|class which is cat got the score of 2.9
174.21|4.26|and that's kind of in the middle so some
176.43|3.72|some classes here received a higher
178.47|3.03|score which is not very good some
180.15|3.09|classes received a much lower score
181.5|4.53|which is good for that particular image
183.24|5.19|the car was very well classified because
186.03|4.17|the class score a car was much higher
188.43|3.27|than all of the other ones and the Frog
190.2|4.5|was not very well classified at all
191.7|5.28|right so we have this notion that for
194.7|3.84|different weights these different
196.98|2.729|weights work better or worse on
198.54|3.72|different images and of course we're
199.709|4.381|trying to find weights that give us
202.26|3.93|scores that are consistent with all the
204.09|4.26|ground truth labels all the labels in
206.19|4.23|the data and so what we're going to do
208.35|3.6|now is so far we've only eyeballed what
210.42|3.15|I just described like this is good or
211.95|3.27|that's not so good and so on but we have
213.57|3.72|to actually give it we have to actually
215.22|4.23|quantify this notion we have to say that
217.29|5.22|this particular set of weights W is say
219.45|4.74|like 12 bad or 1.5 bad or whatever and
222.51|3.3|then once we have this loss function
224.19|3.66|we're going to minimize it so we're
225.81|3.57|going to find W that gets us lowest loss
227.85|3.66|and we're going to look into that today
229.38|4.29|so we're going to look specifically into
231.51|4.56|how we can define a loss function that
233.67|3.63|measures this unhappiness and then we're
236.07|4.41|actually going to look at two different
237.3|5.46|cases a SVM cost and a soft max cost or
240.48|3.27|a cross entropy cost and then we're
242.76|2.28|going to look into the process of
243.75|3.06|optimization which is how do you start
245.04|3.36|off with these random weights and how do
246.81|5.01|we actually find very very good setting
248.4|4.95|of weights efficiently okay so I'm going
251.82|3.6|to downsize this example so that we have
253.35|3.21|a nice working example to work with so
255.42|3.3|suppose we only had three classes
256.56|4.77|instead of you know tens of thousands
258.72|5.31|and we have these three images and these
261.33|3.78|are our scores for some set of w's and
264.03|2.72|we're going to now try to write down
265.11|4.16|exactly our
266.75|4.56|happiness with this result so the first
269.27|4.17|loss we're going to look into is termed
271.31|4.44|a multi-class SVM loss this is a
273.44|3.42|generalization of a binary support
275.75|2.55|vector machine that you may have seen
276.86|4.5|already in different classes
278.3|5.67|I think 229 covers as well and so the
281.36|5.4|setup here is that we have the score
283.97|4.59|function right so s is a vector of Class
286.76|4.98|scores these are our s vectors and
288.56|5.82|there's a specific term here loss equals
291.74|3.96|to stuff and I'm going to interpret this
294.38|4.35|loss now for you so that and we're going
295.7|4.76|to see through a specific example into
298.73|4.56|why this expression makes sense
300.46|5.83|effectively what the SVM loss is saying
303.29|5.64|is that it's summing across all the
306.29|5.1|incorrect examples so all the all the
308.93|6.12|something cross all the incorrect scores
311.39|5.88|classes so for every single example we
315.05|4.05|have that loss and it's something across
317.27|3.24|all the incorrect classes and it's
319.1|2.94|comparing the score that the correct
320.51|4.26|class received and the score that the
322.04|5.67|incorrect class received J minus s of
324.77|6.48|why I why I being the correct label plus
327.71|5.31|1 and then that's maxed of 0 so what's
331.25|4.59|going on here is we're comparing the
333.02|4.8|difference in the scores and this
335.84|4.44|particular loss is saying that not only
337.82|4.26|do I want the correct score to be higher
340.28|3.3|than the in credit score but there's
342.08|3.69|actually a safety margin that we're
343.58|5.91|putting on we're using a safety margin
345.77|7.38|of exactly 1 and we're going to go into
349.49|4.98|why 1 makes sense to use as opposed to
353.15|3.6|some other hyper parameter that we have
354.47|4.17|to choose there and intuitively you can
356.75|3.72|look into notes for much more rigorous
358.64|3.72|derivation of exactly why that one
360.47|3.78|doesn't matter but intuitively to think
362.36|4.29|about this this course are kind of
364.25|4.229|scale-free because I can scale my W I
366.65|3.93|can make it larger or smaller and you're
368.479|3.961|going to get larger or smaller scores so
370.58|3.6|really there's this free parameter of
372.44|4.11|these scores and how large or small they
374.18|4.2|can be that is tied to how large your
376.55|3.66|weights are in magnitude and so these
378.38|4.59|scores are kind of arbitrary so using 1
380.21|5.04|is just an arbitrary choice just on some
382.97|3.69|extent ok so let's see specifically how
385.25|3.81|this expression works with a concrete
386.66|5.13|example so here I'm going to evaluate
389.06|4.8|that loss for the first example so here
391.79|3.689|we're computing we're plugging in these
393.86|3.66|scores so we see that we're comparing
395.479|4.171|the score we got for car which is PI
397.52|2.489|point 1 minus 3.2 which is the correct
399.65|2.28|class
400.009|5.101|our and then adding our safety margin of
401.93|4.379|1 and the max of 0 and that is really
405.11|3.359|what it's doing is it's going to be
406.309|3.991|clamping values at 0 right so if we get
408.469|4.17|a negative result we're going to just
410.3|3.959|clamp it at 0 so if you see for the
412.639|4.56|second-class score the incorrect class
414.259|5.041|of frog negative 1.7 subtracted from 3.2
417.199|3.93|at a safety margin and we get negative 3
419.3|4.319|point 9 and then when you work this
421.129|3.78|through you get a loss of 2.9 so
423.619|3.6|intuitively what you can see here the
424.909|5.16|way this worked out is intuitively the
427.219|5.85|cat score is 3.2 so according to the SVM
430.069|4.41|loss we we would like ideally is that
433.069|4.861|this course for all the inquiry classes
434.479|5.071|are up to at most 2.2 but the car class
437.93|3.959|actually had much higher much higher
439.55|4.349|score right than 1 and this difference
441.889|4.02|in what we would have liked which is 2.2
443.899|5.13|and what actually happened which is 5.1
445.909|6.09|is exactly this difference of 2.9 which
449.029|6.36|is how bad of a score outcome this was
451.999|4.771|and in the other case in frog case you
455.389|4.02|can see that the Frog score was quite a
456.77|5.129|bit lower below 2.2 and so the way that
459.409|3.48|works out in the math is that you end up
461.899|2.85|getting a negative number when you
462.889|3.81|compare this course and then the max of
464.749|3.39|0 clamps it at 0 so you get a 0 loss
466.699|3.661|contribution for that particular part
468.139|5.27|and you end up with a loss of 2.9 okay
470.36|5.609|so that's the loss for this first image
473.409|3.94|for the second image we're going to
475.969|3.18|again do the same thing plug in the
477.349|4.56|numbers we're comparing the cats go to
479.149|5.25|the car score so we get a 1 point 3
481.909|6.331|minus 4 / 9 at a safety margin and the
484.399|5.13|same for for the other class so when you
488.24|4.079|plug it in you actually end up good with
489.529|6.42|a loss of 0 and loss of 0 intuitively is
492.319|6.45|because the car score here is it is true
495.949|5.101|that the car score is higher than all
498.769|4.23|the other scores for that image by at
501.05|4.5|least one right that's why we got zero
502.999|4.56|score zero loss that is so the
505.55|3.959|constraint was satisfied and so we get
507.559|3.33|zero loss and in this frog case we end
509.509|3.03|up with a very bad loss because of
510.889|3.421|course the Frog class received a very
512.539|3.63|low score but the other classes received
514.31|5.009|quite high score so this adds up to an
516.169|4.56|unhappiness of 10.9 and now if we
519.319|3.061|actually want to combine all of this
520.729|3.29|into a single loss function we're going
522.38|3.36|to do the relatively intuitive
524.019|3.491|transformation here where we just take
525.74|3.209|the average across all the losses we
527.51|3.449|obtained over the entire training set
528.949|3.421|and so we would say that the loss at the
530.959|2.491|end when you average these numbers is
532.37|3.51|4.6
533.45|6.12|so this particular setting of W on this
535.88|5.13|training data gives us some scores which
539.57|4.079|we plug into the loss function and we
541.01|4.98|given you get an unhappiness F 4.6 with
543.649|3.451|this result okay so now I'm going to ask
545.99|2.46|you a series of questions to kind of
547.1|3.33|test your understanding a bit about how
548.45|3.9|this works I'll get into questions in a
550.43|6.69|bit let me just pose my own questions
552.35|6.71|first first of all what if that sum over
557.12|6.329|there which is the sum over all the
559.06|6.219|incorrect classes of J what is that was
563.449|3.991|instead sum over all the classes not
565.279|4.141|just the incorrect ones so what if we
567.44|3.93|allow J to equal to y I why am I
569.42|7.37|actually adding that small constraint in
571.37|8.339|the sum over there sorry go ahead
576.79|4.27|yes so in fact what whatever happened is
579.709|4.261|the reason that that's a J not equal to
581.06|5.7|Y I is if we allow J to equal to Y then
583.97|4.59|score of why I cancel score of Y I you
586.76|2.85|end up with a zero and really what
588.56|3.45|you're doing is you're adding a constant
589.61|3.93|of one so if that sum is over all the
592.01|3.36|scores then really we'd be just
593.54|5.43|inflating the loss by a constant of one
595.37|7.14|so that's why that's there second what
598.97|4.979|if we used a mean instead of a sum right
602.51|5.79|so I'm summing up over all these
603.949|6.481|constraints what if I use the mean just
608.3|3.42|like I'm using mean to actually average
610.43|2.99|over all the losses for all the examples
611.72|10.17|what if I use the mean over this course
613.42|10.27|the score constraints good so you're
621.89|5.34|saying if there were too many classes
623.69|5.19|that would dilute the loss so you're
627.23|6.96|right in that the absolute value of the
628.88|12.38|loss would be lower so it would be a
634.19|7.07|constant factor why that's right yeah
643.899|5.05|some of these choices matter but yes so
647.66|3.419|basically what you're pointing out is if
648.949|3.93|we did actually do an average here we'd
651.079|3.721|be averaging over the number of classes
652.879|3.33|here but there's a constant number of
654.8|3.089|classes say three in the specific
656.209|3.63|example so that amounts to putting a
657.889|3.781|constant of one third in front of the
659.839|3.48|loss and since we're always in the end
661.67|3.269|so that would make the loss lower just
663.319|2.94|like you pointed out but in the end what
664.939|3.84|we're always interested in is we're
666.259|4.591|going to minimize a W over that loss so
668.779|4.141|if you're shifting your loss up by one
670.85|3.39|or if you're scaling it with a constant
672.92|2.459|this actually doesn't change your
674.24|3.0|solutions right you're still going to
675.379|4.02|end up with the same optimal w's so
677.24|4.079|these choices are kind of basically free
679.399|3.54|parameters doesn't matter so for
681.319|3.39|convenience I'm adding a J not equal to
682.939|3.33|Y I and I'm not actually taking a mean
684.709|4.11|although it's the same thing and the
686.269|4.74|same loss also goes for us for whether
688.819|6.421|or not we average or sum across the
691.009|6.75|examples okay next question what if we
695.24|3.87|instead used not the formulation over
697.759|3.69|there but a very similar looking
699.11|5.07|formulation but there's an additional
701.449|4.44|squared at the end so we're taking the
704.18|5.82|difference between scores plus 1 this
705.889|7.68|margin and then we're squaring that do
710.0|5.279|we obtain the same or different loss
713.569|3.24|when you think do we obtain the same or
715.279|2.85|different loss in a sense that if you
716.809|11.991|were to optimize this and find the best
718.129|10.671|W do we get the same result or not yes
730.75|7.089|so I like the fact that it's divided you
734.0|6.3|would in fact get a different loss it's
737.839|4.05|not as obvious to see but what one way
740.3|6.089|to see it is that we're not just clearly
741.889|6.151|scaling not just clearly scaling the
746.389|3.29|loss up or down by constant or shifting
748.04|4.2|it by a constant we're actually changing
749.679|5.861|the difference we were changing the
752.24|5.01|trade-offs nonlinearly in terms of how
755.54|3.06|the SVM the support vector machine is
757.25|3.24|going to go there and trade out the
758.6|4.229|different score margins in different
760.49|4.409|examples but it's not obvious to see but
762.829|3.63|basic it's not very clear but I wanted
764.899|5.851|to illustrate that not all changes to
766.459|5.82|this loss are completely no op and the
770.75|3.269|second formulation here is in fact about
772.279|3.78|something we call a squared hinge loss
774.019|2.461|instead of the one on top which we call
776.059|2.701|hinge loss
776.48|3.45|and you can use two different it's kind
778.76|3.33|of a hyper parameter which one you use
779.93|3.93|most often you see the first formulation
782.09|3.39|that's what we use most of the time but
783.86|2.7|sometimes you can see datasets where the
785.48|2.79|squared hinge loss ends up working
786.56|3.54|better so that's something you play with
788.27|4.64|that's really a hyper parameter but it's
790.1|5.34|most often used form as the first one
792.91|5.68|let's also think about the scale of this
795.44|5.7|loss was the min and the max possible
798.59|4.65|loss that you can achieve with the
801.14|6.33|multi-class SVM on your entire data set
803.24|9.06|what is the smallest value 0 good what
807.47|6.93|is the highest value yeah it's infinite
812.3|4.56|right so basically the scores could be
814.4|4.59|arbitrarily terrible so if you're at
816.86|3.87|sign score to the correct example is
818.99|4.89|very very small then you're going to get
820.73|5.57|your loss going to infinity okay and one
823.88|3.96|more question which becomes kind of
826.3|3.52|important when we start doing
827.84|3.6|optimization usually when we actually
829.82|3.48|optimize these loss functions we start
831.44|3.6|off with the initialization of W that
833.3|3.36|are very small weights so what ends up
835.04|3.81|happening is that the scores at the very
836.66|4.35|beginning of optimization are roughly
838.85|4.47|near zero all of these are like small
841.01|4.62|numbers near zero so what is the loss
843.32|6.96|when all of these are near zero in this
845.63|6.54|particular case that's right number of
850.28|4.65|class is minus one so if all the scores
852.17|4.44|are zero then with this particular loss
854.93|3.75|I put down here and by doing an average
856.61|3.48|across this way we would have achieved a
858.68|3.27|loss of two okay
860.09|3.66|so this is not very important where it's
861.95|3.0|important is for sanity checks when
863.75|2.37|you're actually starting optimization
864.95|3.84|and you're starting with very small
866.12|4.38|numbers W and you print out your first
868.79|2.94|loss as you're starting the optimization
870.5|2.73|and you want to make sure that you kind
871.73|3.36|of understand the functional forms and
873.23|4.35|that they can think through whether or
875.09|4.14|not the number you get makes sense so if
877.58|3.27|I'm seeing two in this case that I'm
879.23|4.08|happy that the further losses may be
880.85|3.84|implemented correctly and 100% sure but
883.31|3.93|shirt suddenly there's nothing wrong
884.69|5.73|with it right away so it's interesting
887.24|4.71|to think about these let's see I'm going
890.42|3.15|to go more into this loss a tiny bit but
891.95|4.23|is there a question in terms of this
893.57|6.329|slide right now good
896.18|5.9|why I wernicki more efficient do not do
899.899|2.181|them
905.8|5.08|oh yeah so with the question is and I
909.14|3.449|was asked to repeat the questions would
910.88|3.57|it be not efficient to actually not have
912.589|3.781|this ugly constraint G I J is not why I
914.45|3.72|because it makes it more difficult to
916.37|3.18|actually do these easy vectorized
918.17|3.87|implementations of this last
919.55|4.77|implementation so that actually predicts
922.04|4.109|my next slide to some degree so let me
924.32|3.389|just go into that so here's some numpy
926.149|4.891|code for how i would write out to this
927.709|5.431|loss function in vectorize numpy code so
931.04|3.72|here we're evaluating Li in vectorize
933.14|4.41|numpy we're getting a single example
934.76|5.55|here so X is a single column vector y is
937.55|4.77|an integer specifying the label and W is
940.31|3.93|our weight matrix so what we do is we
942.32|3.959|evaluate this course which is just W
944.24|3.96|times X then we compute these margins
946.279|4.521|which is the difference between the
948.2|5.639|scores we obtain and the correct score
950.8|4.539|plus 1 so these are numbers between 0
953.839|3.951|and whatever and then see this
955.339|9.481|additional online margins at y equals 0
957.79|8.44|why is that there yeah exactly so
964.82|2.73|basically I'm doing this efficient
966.23|3.66|vectorized implementation which goes to
967.55|4.08|your point and then I want to erase that
969.89|3.87|margin there because I'm certain that
971.63|4.95|margins that Y currently is 1 and I
973.76|7.769|don't want to inflate my score and so
976.58|6.96|I'll set that to 0 sorry yes I suppose
981.529|3.351|you could subtract one at the end as
983.54|3.6|well
984.88|3.82|that's right so we can optimize this if
987.14|3.449|we want but we're not going or not going
988.7|3.36|to think about this too much if you do
990.589|4.231|if you do in your assignment that's very
992.06|4.11|welcome for extra bonus points and then
994.82|5.459|we're summing up this margins and so we
996.17|5.19|get lost again ok going back to the
1000.279|3.3|slide any more questions about this
1001.36|4.469|formulation and by the way this
1003.579|4.861|formulation if you wanted to make it if
1005.829|4.081|you actually write it down for just two
1008.44|6.66|classes you'll see that it reduces to a
1009.91|6.27|binary support vector machine loss okay
1015.1|2.82|cool
1016.18|2.82|so we'll see a different loss function
1017.92|3.72|soon and then we're going to look at
1019.0|4.649|comparisons of them as well but for now
1021.64|5.01|actually so at this point what we have
1023.649|4.29|is we have this linear mapping to get
1026.65|2.58|scores and then we have this loss
1027.939|1.681|function which have now written out and
1029.23|2.25|it's full
1029.62|5.76|form where we have these differences
1031.48|5.339|between this course +1 sum over the
1035.38|3.15|incorrect classes and the Sun and the
1036.819|3.661|average across all the examples right so
1038.53|3.059|that's the loss function right now now
1040.48|3.27|I'd like to convince you that there's
1041.589|4.021|actually a bug with this loss function
1043.75|5.27|in other words if I'd like to use this
1045.61|6.12|loss on some data set in practice I
1049.02|5.35|might get some not very nice properties
1051.73|4.86|okay if this if this was the only thing
1054.37|3.63|I was using by itself and it's not
1056.59|3.03|completely obvious to see exactly what
1058.0|4.65|the issue is so I'll give you guys a
1059.62|5.55|hint in particular suppose that we found
1062.65|6.45|the W such that we're getting zero loss
1065.17|10.92|okay on some data set and now the
1069.1|9.69|question is is this W unique or phrase
1076.09|4.41|in another way can you give me a W that
1078.79|10.11|would be different but also definitely
1080.5|10.35|achieves a zero loss in the back that's
1088.9|3.48|right and so you're saying we can scale
1090.85|3.03|it by some constant alpha and in
1092.38|7.56|particular alpha must obey some
1093.88|8.88|constraint you'd probably want it to be
1099.94|4.86|greater than one right so basically what
1102.76|3.72|I can do is I can if i change my weights
1104.8|4.17|and i make them larger and larger all i
1106.48|3.99|would be doing is i'm just create making
1108.97|3.57|this score difference larger and larger
1110.47|5.04|as ice kml w right because of the linear
1112.54|4.5|lost form here so basically that's not a
1115.51|3.48|very desirable property because we have
1117.04|4.26|the this entire subspace of W that is
1118.99|3.9|optimal and all of them are according to
1121.3|4.32|this loss function completely the same
1122.89|4.74|but intuitively that's not like a very
1125.62|3.78|nice property to have and so just to see
1127.63|3.84|this numerically to convince yourself
1129.4|3.659|that this is the case I've taken this
1131.47|4.47|example where we achieved previously
1133.059|5.761|zero loss there before and now suppose I
1135.94|4.56|multiply my WI twice I mean this is a
1138.82|3.66|very simple math going on here but
1140.5|3.69|basically I would be inflating or my
1142.48|3.93|scores by two times and so their
1144.19|4.38|difference would also become just larger
1146.41|4.56|so if all your score differences inside
1148.57|3.54|the max of 0 were already negative then
1150.97|2.76|they're just going to become more and
1152.11|3.69|more negative and so you end up with
1153.73|3.96|larger and larger negative values inside
1155.8|5.57|the maxes and they're just become 0 all
1157.69|3.68|the time right good
1163.589|9.3|so all the scale in fact it would have
1165.94|6.949|to be larger than one because let's see
1173.369|4.8|yes so there's that added margin of 1
1175.869|10.02|which is company things yeah okay
1178.169|11.47|another question with the scaling apply
1185.889|5.431|to this to the bias part so here I'm
1189.639|5.49|just I guess I'm not assuming the bias
1191.32|6.0|for simplicity but yeah basically these
1195.129|4.05|scores are W X plus P so so you're just
1197.32|7.229|yet forget the bias and we're just
1199.179|7.771|killing W by itself okay cool so the way
1204.549|4.59|to fix this is intuitively we have this
1206.95|3.809|entire subspace of WS and it all works
1209.139|3.27|the same according to this loss function
1210.759|3.42|and what we'd like to do is we'd like to
1212.409|4.08|have a preference over some WS over
1214.179|4.65|others just based on intrinsic you know
1216.489|4.17|what what do we desire of W to look like
1218.829|4.56|forget what the data is just what what
1220.659|4.17|are nice things to have about a W and so
1223.389|2.79|this introduces the notion of
1224.829|3.361|regularization which we're going to be
1226.179|3.18|attending to our loss function so we
1228.19|3.0|have an additional term there which is
1229.359|3.93|lambda times a regularization function
1231.19|4.349|of W and the regularization function
1233.289|4.2|measures the niceness of your W okay and
1235.539|4.38|so we don't only want to fit the data
1237.489|5.79|but we also want W to be nice and we're
1239.919|4.85|going to see some ways of framing that
1243.279|3.09|and exactly why they make sense and
1244.769|3.54|intuitively what's going on is
1246.369|4.77|regularization is a way of trading off
1248.309|5.261|your training act your training loss and
1251.139|4.65|your generalization loss on a test set
1253.57|3.569|so intuitively regularization is a set
1255.789|3.45|of techniques where we're adding
1257.139|4.051|objectives to the loss which we'll be
1259.239|3.69|fighting with this guy so this guy just
1261.19|4.079|wants to fit your training data and that
1262.929|3.84|guy wants W to look some particular way
1265.269|3.54|and so they're fighting each other
1266.769|3.75|sometimes in your objective because we
1268.809|3.54|want to simultaneously achieve both of
1270.519|3.66|them but it turns out that adding these
1272.349|3.57|regularization techniques even if it
1274.179|3.12|makes your training error worse so we're
1275.919|3.12|not correctly classifying all the
1277.299|3.09|examples what you notice is that the
1279.039|3.24|test set performance ends up being
1280.389|5.01|better and we'll see an example of why
1282.279|4.35|that might be actually with the neck for
1285.399|2.88|now I just wanted to point out in the
1286.629|3.09|next slide but for now I just want to
1288.279|3.21|point out that the most common form of
1289.719|4.331|regularization is the what we call l2
1291.489|4.091|regularization or weight decay
1294.05|3.69|and really what we're doing is supposed
1295.58|4.89|W in this case is a 2d matrix so I have
1297.74|4.68|two sums over K and L the rows and
1300.47|4.41|columns but really is just all the
1302.42|4.5|element wise W squared and we're just
1304.88|4.26|putting them all into the loss okay so
1306.92|5.97|this this particular regularization it
1309.14|5.91|likes W is to be 0 right so when W is
1312.89|3.78|all 0 then regularization is happy but
1315.05|3.63|of course W can't be all 0 because then
1316.67|4.95|you can't classify so these guys will
1318.68|4.38|fight each other there are different
1321.62|4.02|forms of regularization with different
1323.06|5.61|pros and cons we'll go into some of them
1325.64|4.32|much later in the class and I just like
1328.67|2.82|to say for now that basically l2
1329.96|4.08|regularization is the most common form
1331.49|4.71|and that's what you'll use a quite often
1334.04|4.08|in this class as well so now I'd like to
1336.2|3.57|convince you I'd like to convince you
1338.12|4.47|that this is a reasonable thing to want
1339.77|5.01|out of a w that it's weights are small
1342.59|4.71|so consider this very simple cooked up
1344.78|5.22|example to get the intuition suppose we
1347.3|3.9|have an example where we are in four
1350.0|2.31|dimensional space where we're doing this
1351.2|3.84|classification and we have an input
1352.31|3.99|vector of just all one's X and now
1355.04|4.11|suppose we have these two candidate
1356.3|5.64|weight matrices or weight single weights
1359.15|6.44|I suppose right now so one of them is 1
1361.94|5.76|0 0 and the other is 0.25 everywhere
1365.59|4.33|since we have linear loss functions
1367.7|4.08|you'll see that their effects are the
1369.92|4.59|same so basically the way we are
1371.78|4.83|evaluating score is by WX so the dot
1374.51|3.48|product with X is identical for both of
1376.61|4.68|these this course would come out both of
1377.99|5.16|these but regularization would strictly
1381.29|3.45|favor one of these over the other which
1383.15|3.84|one would the regularization cost favor
1384.74|3.9|even though their effects are the same
1386.99|5.42|which one is better in terms of
1388.64|5.85|regularization the second one right and
1392.41|3.31|so the regularization will tell you that
1394.49|2.85|even though they are achieving the same
1395.72|3.51|effects in terms of the data loss
1397.34|3.24|classification down the road we actually
1399.23|3.3|significantly prefer the second one
1400.58|5.12|what's better about the second one why
1402.53|3.17|is that a good idea to have
1408.529|7.661|sorry can you repeat that that's correct
1414.389|3.811|so well that's one that's the
1416.19|4.589|interpretation I liked the most as well
1418.2|5.309|it takes into account the most number of
1420.779|4.53|things in your ex vector right so what
1423.509|4.14|this ultra regularization wants to do is
1425.309|3.631|it wants to spread out your w's as much
1427.649|3.061|as possible so that you're taking into
1428.94|4.049|account all the input features or all
1430.71|3.929|the input pixels it wants to use as much
1432.989|3.54|of those as many of those dimensions as
1434.639|4.561|it likes if it's achieving the same
1436.529|4.65|effect intuitively speaking and so
1439.2|5.12|that's better than just focusing on just
1441.179|5.19|one input dimension it's just nice it's
1444.32|4.15|something that often works in practice
1446.369|5.25|basically just the way things are big
1448.47|5.519|assets are arranged and the properties
1451.619|4.62|that they usually have statistically ok
1453.989|3.75|any questions about this so
1456.239|4.56|regularization good idea everyone is
1457.739|4.92|sold ok great so basically our losses
1460.799|3.45|will always have this form where we have
1462.659|3.031|the data loss and then we'll also have a
1464.249|4.591|regularization it's a very common thing
1465.69|4.439|to have in practice ok I'm now going to
1468.84|3.529|go into the second classifier the
1470.129|4.711|softmax classifier and we'll see some
1472.369|4.451|differences between the support vector
1474.84|3.51|machine and this soft max classifier in
1476.82|3.479|practice these are kind of like these
1478.35|3.809|two choices that you can have either SVM
1480.299|3.901|or soft max the most two commonly used
1482.159|5.52|linear classifiers often you'll see that
1484.2|4.859|soft max classifier is preferred and I'm
1487.679|3.69|not exactly sure why because usually
1489.059|4.021|they end up working about the same and I
1491.369|2.851|just like to mention that this is also
1493.08|2.61|sometimes called multinomial logistic
1494.22|2.819|regression so if you're familiar with
1495.69|2.489|logistic regression this is just a
1497.039|3.291|generalization of it into multiple
1498.179|4.56|dimensions or in this case multiple
1500.33|5.099|classes not just you was there a
1502.739|2.69|question over there or
1514.82|4.71|yes the question is why do we want to
1517.85|4.88|use regularization basically so I don't
1519.53|5.67|think I sold it very well if you're
1522.73|3.699|compose you have this entire sub base of
1525.2|1.8|voice that is all achieving the same
1526.429|4.831|effects
1527.0|6.299|we'd like to pick between them in some
1531.26|5.07|way and I think what I'm arguing for is
1533.299|6.091|that wanting low w's is a reasonable way
1536.33|4.71|to pick among them and the l2
1539.39|3.659|regularization will favor diffuse double
1541.04|4.74|use like in this case here and one of
1543.049|5.041|the intuitive ways in which I can try to
1545.78|7.08|pitch why this is a good idea is that
1548.09|6.81|diffuse weights basically see this w1 is
1552.86|2.37|a completely ignoring your inputs to 3 &
1554.9|2.67|4
1555.23|3.78|but w2 is using all of the inputs right
1557.57|3.3|because the weights are more diffuse and
1559.01|7.14|so intuitively this just ends up usually
1560.87|7.77|working better at a test time because
1566.15|4.62|more evidence is being accumulated into
1568.64|6.2|your decisions instead of just one
1570.77|4.07|single evidence one single feature
1576.07|3.18|that's right
1581.78|6.21|that's right that's right so the idea
1585.41|4.5|here is that these two W 1 and W 2
1587.99|3.6|they're achieving the same effect so
1589.91|3.57|this data loss suppose that that's
1591.59|3.78|basically it doesn't care between the
1593.48|3.36|two but the regularization expresses
1595.37|2.97|preference for them and since we have it
1596.84|3.6|in the objective and we're going to end
1598.34|3.12|up optimizing over this loss function so
1600.44|2.76|we're going to find the W that
1601.46|4.41|simultaneously accomplishes both of
1603.2|4.17|those and so we end up at W that not
1605.87|3.06|only classifies correctly but we also
1607.37|3.18|have this added preference that actually
1608.93|4.29|we want it to be and we want it to be
1610.55|11.97|diffused as much as possible awesome
1613.22|12.33|good yes so in this particular example
1622.52|4.41|l1 would also be indifferent l1 has some
1625.55|2.85|nice properties which I don't want to go
1626.93|5.73|into right now we might cover it later
1628.4|8.19|l1 has some property is like a sparsity
1632.66|5.88|inducing properties where if you end up
1636.59|3.57|having l1 s into your in your objectives
1638.54|4.14|you'll find that lots of WS will end up
1640.16|4.65|being exactly 0 for reasons that we
1642.68|4.89|might go into later and that sometimes
1644.81|5.64|is like a feature selection almost and
1647.57|8.09|so l1 is another alternative that we
1650.45|5.21|might go into a bit more later good
1666.12|5.29|yes so the question is yeah so you're
1669.94|3.42|pointing out that isn't it may be a good
1671.41|9.0|thing that we're ignoring features and
1673.36|8.13|just using one of them yeah so there's
1680.41|2.79|many technical reasons why
1681.49|4.95|regularization is a good idea I wanted
1683.2|5.4|to give you just basic intuition so
1686.44|7.77|maybe uh maybe I failed at that but I I
1688.6|6.72|think that's a fair point um yep I'm not
1694.21|4.829|sure if I have a good return I would
1695.32|6.599|have to good can you say that like
1699.039|7.431|epsilon zero zero would do the exact
1701.919|7.26|same thing use W one small number so
1706.47|5.35|that but that factor would be the exact
1709.179|6.421|same thing but also has more much more
1711.82|5.969|regulation so you want to consider a
1715.6|4.5|different W and you want to looks like a
1717.789|6.301|different from these two I'm just saying
1720.1|7.86|like the previous question was like
1724.09|7.17|isn't it great that we're ignoring some
1727.96|4.44|valleys why why would you yeah isn't
1731.26|2.37|that a feature not a bug that we're
1732.4|3.0|ignoring some inputs
1733.63|5.73|yeah that's not saying that you could
1735.4|7.8|just have like point zero zero one zero
1739.36|5.52|zero as another W vector that would do
1743.2|7.99|exactly the same thing is the
1744.88|8.46|in terms of its decisions but I see okay
1751.19|5.79|thanks
1753.34|4.66|yeah I didn't want to die too too much
1756.98|2.699|into this there's actually like an
1758.0|3.63|entire literature of regularization and
1759.679|3.721|looking at the test error and actually
1761.63|3.75|uh you know writing theorems in learning
1763.4|3.72|theory and you saw some of that in 229
1765.38|3.96|and there are some results on why
1767.12|4.26|regularization is a good case in it in
1769.34|4.02|those areas and I don't think I won't
1771.38|3.81|want to go into that and it's also also
1773.36|3.179|beyond the scope of this class so for
1775.19|2.88|this class just that ultra
1776.539|6.27|regularization will make your test error
1778.07|6.0|better okay so I'm going to go into
1782.809|5.161|softness classifier now which is this
1784.07|5.219|generalization of logistic regression so
1787.97|2.85|the way the way this will work is this
1789.289|4.051|is just a different functional form for
1790.82|4.979|how loss is specified on top of B scores
1793.34|4.77|so in particular there's this
1795.799|4.051|interpretation that softness classifier
1798.11|3.75|puts on top of these scores these are
1799.85|4.02|not just some arbitrary scores and we
1801.86|3.54|want some margins to be met but we have
1803.87|4.47|specific interpretation that is maybe
1805.4|4.86|more principled kind of from a
1808.34|4.41|probabilistic point of view where we
1810.26|3.93|actually interpret these scores not just
1812.75|3.15|as these things that mean margins but
1814.19|3.54|these are actually the unnormalized lock
1815.9|5.55|probabilities that are assigned to
1817.73|5.04|different classes okay so we're going to
1821.45|3.42|go into exactly what this means in a bit
1822.77|5.159|so these are unnormalized lock
1824.87|5.549|probabilities of all the Y's given the
1827.929|5.071|image so in other words we're assuming
1830.419|4.441|that if the scores are unknown y's log
1833.0|3.539|probabilities then the way to get
1834.86|4.83|probabilities of different classes like
1836.539|5.691|class k is that we take the score we
1839.69|4.8|exponentiate all of them to get the
1842.23|4.569|unnormalized probabilities and we
1844.49|4.38|normalize them to get the normalized
1846.799|5.37|probabilities so we divide by the sum
1848.87|5.309|over all the exponentiated scores and
1852.169|3.51|that's how we actually get this
1854.179|4.051|expression for a probability of a class
1855.679|4.171|given the image and so this function
1858.23|4.17|here is called the softmax function if
1859.85|4.5|you if you see it somewhere it's the e
1862.4|4.019|to the the element you're currently
1864.35|5.22|interested in divided by the sum over
1866.419|4.951|all exponentiated scores okay and so the
1869.57|2.94|way this will work basically is if we're
1871.37|3.15|in this probabilistic framework where we
1872.51|3.57|are looking at we're deciding that this
1874.52|3.07|is the probability of different classes
1876.08|3.13|then makes sense
1877.59|3.3|of what you want usually want to do in
1879.21|2.969|this setting we have a probability over
1880.89|3.6|different classes one of these is
1882.179|5.791|correct so we want to just maximize the
1884.49|6.75|log likelihood of for the loss function
1887.97|7.05|and sorry we want to maximize the log
1891.24|5.49|likelihood of the true class and since
1895.02|4.62|we're writing a loss function we want to
1896.73|5.52|minimize the negative log likelihood of
1899.64|4.56|the true class okay so you end up with a
1902.25|3.539|series of expressions here really our
1904.2|3.959|loss function is we want the log
1905.789|4.38|likelihood of the correct class to be
1908.159|4.5|high so negative of it want to be low
1910.169|4.081|and the log likelihood is softmax
1912.659|4.49|function of your scores let's look at a
1914.25|5.19|specific example to make this more clear
1917.149|3.76|okay and here I've actually like subbed
1919.44|4.229|in that expression so that this is the
1920.909|4.5|loss negative log of that expression
1923.669|2.76|let's look at how this expression works
1925.409|2.791|and I think it will give you a better
1926.429|4.291|intuition of exactly what this is doing
1928.2|4.349|lights what's computing so suppose here
1930.72|3.66|we have these scores that came out from
1932.549|3.931|our neural network or from our linear
1934.38|4.049|classifier and these are the
1936.48|3.299|unnormalized log probabilities so as I
1938.429|2.85|mentioned we want to exponentiate them
1939.779|3.03|first because under this interpretation
1941.279|3.841|that gives us the normalized
1942.809|4.11|probabilities and now probability is
1945.12|5.429|always sum to one so we have to divide
1946.919|5.701|by the sum of all of these so we add up
1950.549|3.931|these guys and we divide to actually get
1952.62|3.87|probabilities out so under this
1954.48|3.329|interpretation we've carried out the set
1956.49|3.21|of transformations and what this is
1957.809|3.961|saying is that in this interpretation
1959.7|5.52|the probability assigned to this image
1961.77|6.48|of being a cat is 13% car is 87 percent
1965.22|5.189|and frog is very unlikely 0% so these
1968.25|3.75|are the probabilities and now normally
1970.409|3.331|in this setting you want to maximize the
1972.0|3.419|log probability because it turns out
1973.74|3.45|that maximizing just the raw probability
1975.419|3.961|is not as nice mathematically so
1977.19|5.13|normally you see maximizing log
1979.38|4.98|probabilities and then so we want to
1982.32|4.229|minimize the negative log probability so
1984.36|5.309|the correct class here is cat which is
1986.549|5.911|only having 13% chance under this
1989.669|5.721|interpretation so negative log of 0.1 3
1992.46|5.04|gives us 0.89 and so that's the final
1995.39|5.889|that's the final loss that we would
1997.5|5.549|achieve for this class here under this
2001.279|6.15|interpretation of a soft soft mess
2003.049|6.51|classifier so 0.894 sometimes okay so
2007.429|4.131|let's go over some examples let's go
2009.559|4.171|over some questions now related to this
2011.56|4.15|to try to interpret exactly how this
2013.73|4.53|works first where's the min and the max
2015.71|4.11|possible loss with this lost function so
2018.26|5.13|that's the lost function what is the
2019.82|4.83|smallest value and the highest value so
2023.39|3.39|I'll give you a chance to think about is
2024.65|7.16|what is the smallest value that we can
2026.78|7.86|achieve zero and how would that happen
2031.81|5.41|okay good so if you're correct class is
2034.64|4.17|getting probability of one where we have
2037.22|3.3|a one which will plug into the log and
2038.81|5.6|we're getting negative log of 1 which is
2040.52|6.75|zero and the highest possible loss
2044.41|4.81|infinite so just as with SVM we're
2047.27|5.34|getting the same zero is minimum and
2049.22|5.01|infinite is maximum so infinite loss
2052.61|3.72|would be achieved if you end up giving
2054.23|4.29|your cat score very tiny probability and
2056.33|4.86|then log of zero gives you negative
2058.52|6.09|infinity so negative that is just
2061.19|7.41|infinite so yeah so the same balance as
2064.61|7.38|SVM and also this question normally when
2068.6|5.039|we initialize W with roughly small you
2071.99|4.02|small weights we end up with all the
2073.639|3.961|scores that are nearly zero what ends up
2076.01|2.879|being the loss in this case if you're
2077.6|2.73|doing sanity checks at the beginning of
2078.889|4.341|your optimization what do you expect to
2080.33|2.9|see as your first loss
2087.97|8.849|yeah yeah that's right so it's negative
2094.659|3.601|log of one over number of classes so
2096.819|4.651|you'd basically be getting all zeros
2098.26|4.95|here you get all ones here and so here
2101.47|3.75|is one over the number of classes and
2103.21|4.2|then negative log of that ends up being
2105.22|4.83|your final loss so actually for myself
2107.41|4.14|whenever I run optimization I sometimes
2110.05|3.21|take note of my number of classes and I
2111.55|3.12|evaluate negative log of one over the
2113.26|2.94|number of classes and I'm trying to see
2114.67|3.03|what is the my first beginning loss that
2116.2|2.879|I expect and so when I start the
2117.7|2.79|optimization I make sure that I'm
2119.079|3.571|getting roughly that otherwise I know
2120.49|4.2|something's maybe slightly off I expect
2122.65|3.78|to get something on that order moreover
2124.69|3.929|as I'm optimizing I expect that I go
2126.43|3.57|from that to zero and if I'm seeing
2128.619|2.371|negative numbers then I know from the
2130.0|2.069|functional form that something very
2130.99|2.46|strange is going on
2132.069|3.631|right because you never actually expect
2133.45|4.56|to get negative numbers out of this so
2135.7|3.3|that's the softmax loss I'll show you
2138.01|2.609|one more slide and I'll take some
2139.0|3.0|questions just to reiterate the
2140.619|3.96|difference between them and really what
2142.0|4.589|they look like is we have the score
2144.579|3.99|function which gives us WX times B we
2146.589|3.51|get our scores vector and now the
2148.569|4.951|difference is just how they interpret
2150.099|5.941|what B scores coming out from this F
2153.52|4.559|function is so either is just random
2156.04|4.2|scores no interpretation whatsoever we
2158.079|4.02|just want the large larger score the
2160.24|4.47|correct score to be some margin above
2162.099|3.871|the incorrect scores or we interpret it
2164.71|3.06|to be these unnormalized log
2165.97|3.389|probabilities and then in this framework
2167.77|3.27|we first want to get the probabilities
2169.359|2.851|and then we want to maximize the
2171.04|3.42|probability of the correct classes or
2172.21|3.899|the log of them and so that ends up
2174.46|4.59|giving us the loss function for south
2176.109|5.131|max so they start off with the same way
2179.05|4.799|but they just happen to get a different
2181.24|5.07|result we'll go into exactly what the
2183.849|10.77|difference is of them are in a bit there
2186.31|10.259|are questions for now that's correct so
2194.619|3.541|they they take about the same time to
2196.569|3.421|calculate for sure especially once you
2198.16|3.419|have a ComNet your classifier is near
2199.99|3.27|instantaneous to evaluate most of the
2201.579|3.54|work is done in doing all the
2203.26|3.72|convolutions and so we'll see that the
2205.119|5.011|classifier and especially the loss is
2206.98|6.33|roughly the same of course softmax
2210.13|4.229|involves some X and so on so these
2213.31|3.63|operations are slightly more expensive
2214.359|4.051|perhaps but usually it completely washes
2216.94|2.429|away compared to everything else you're
2218.41|4.22|worried about which is all the
2219.369|3.261|convolutions over the image
2236.66|7.15|sorry I didn't catch your question for
2238.62|6.72|you why do we want to maximize lock
2243.81|6.3|probabilities instead of probabilities
2245.34|7.62|directly it turns out when you so this
2250.11|4.32|is partly covered in 229 when you do
2252.96|2.85|logistic regressions and so on if you
2254.43|3.57|just want to maximize probability it
2255.81|4.08|would be the exact same problem because
2258.0|3.03|log is a monotonic function and so
2259.89|2.82|maximizing the probability and
2261.03|4.02|maximizing the log probability give you
2262.71|4.23|the identical result but in terms of the
2265.05|3.18|math everything comes out much nicer
2266.94|2.31|looking when you actually put a lot of
2268.23|5.46|there but it's the exact same
2269.25|5.52|optimization problem okay cool let's
2273.69|3.12|look at some interpretations of these
2274.77|4.2|two and exactly how they differ so south
2276.81|4.47|max versus SVM and trying to give you an
2278.97|4.59|idea about one property that actually is
2281.28|3.54|quite different between the two so
2283.56|3.81|they're these two different functional
2284.82|5.19|forms and now assume that we have these
2287.37|4.65|three examples all three examples and
2290.01|3.18|suppose there are three classes three
2292.02|3.18|different examples and these are the
2293.19|3.48|scores of these examples and for every
2295.2|3.45|one of these examples the first class
2296.67|4.26|here is the correct class so 10 is the
2298.65|5.07|correct class score and the other scores
2300.93|6.09|are these guys either the first one
2303.72|5.75|second or third one and now just think
2307.02|5.43|about what these losses tell you about
2309.47|6.31|how desirable these outcomes are in
2312.45|4.65|terms of that W in a particular one way
2315.78|3.21|to think about it for example is suppose
2317.1|3.87|I take this data point the third one 10
2318.99|5.28|negative 100 negative 100 and suppose I
2320.97|5.76|jiggle it like I move it around a bit in
2324.27|6.59|my input space what is happening to the
2326.73|4.13|losses as I do that
2337.459|4.27|okay I'll do this so they increase and
2340.319|3.12|decrease as I wiggle this data point
2341.729|7.44|round do they both increase or decrease
2343.439|7.38|for the third data point for example SVM
2349.169|3.27|remains the same correct and why is that
2350.819|3.42|it's because the margin was met by a
2352.439|3.75|huge amount so there's this added
2354.239|4.41|robustness when I take this data up when
2356.189|4.83|I shake it around the SVM is already
2358.649|4.53|very happy because the margins were met
2361.019|5.7|by you know we desire a margin of 1 and
2363.179|4.44|here we have a margin of 109 so
2366.719|2.67|basically there's a huge amount of
2367.619|3.75|margin the SVM doesn't express a
2369.389|3.9|preference over these examples where
2371.369|4.2|this course come out very negative then
2373.289|4.08|the SVM adds no additional preference
2375.569|3.39|over do I want these to be negative 20
2377.369|4.17|or negative 100 or negative a thousand
2378.959|3.21|the SVM won't care but the S but the
2381.539|2.97|softmax
2382.169|4.38|could always see you will always get an
2384.509|3.96|improvement for softmax right so softmax
2386.549|4.56|function expresses preference for it
2388.469|4.02|ones these to be negative 200 or 500 or
2391.109|3.84|a thousand all of them would give you
2392.489|5.19|better loss right but the SVM at this
2394.949|4.59|point doesn't care and for the other
2397.679|3.12|examples I don't know if it's as I mean
2399.539|3.42|that's one clear distinction right so
2400.799|3.84|the SVM has this added robustness to it
2402.959|3.421|wants this margin to be met but beyond
2404.639|3.96|that it doesn't micromanage your scores
2406.38|4.559|where softmax will always want these
2408.599|5.07|scores to be you know everything here
2410.939|4.17|nothing there and so that's one kind of
2413.669|4.97|a very clear difference between the two
2415.109|3.53|I was our question good
2424.259|3.84|yes so the margin of one I mentioned
2426.839|3.45|very briefly that that's not a hyper
2428.099|4.02|parameter you can fix it to be one the
2430.289|5.58|reason for that is that these scores
2432.119|6.45|they're the kind of the absolute values
2435.869|5.16|of those scores are kind of a they don't
2438.569|3.72|really matter because my W I can make it
2441.029|5.97|larger or smaller and I can achieve
2442.289|6.18|different size scores and so one turns
2446.999|2.881|out to work better and in the notes I
2448.469|4.411|have a longer derivation where I go into
2449.88|4.649|details exactly why one is safe to
2452.88|2.79|choose so I refer to that but I didn't
2454.529|7.5|want to spend time on it in the lecture
2455.67|7.77|oh so zero would be if you wanted to use
2462.029|3.27|zero that would be trouble you can use
2463.44|6.029|any positive number and that would give
2465.299|9.661|you an SVM if you use zero that would
2469.469|7.681|look different so one example for
2474.96|3.269|example this added constant there one
2477.15|2.369|property it gives you when you actually
2478.229|3.75|go through the mathematical analysis
2479.519|3.54|like saying the SVM in CS 229 is you
2481.979|4.201|will see that it achieves this max
2483.059|5.641|margin property where the SVM will find
2486.18|5.22|that the best margin when you actually
2488.7|4.409|have a plus constant there combined with
2491.4|3.359|the l2 regularization on the weights so
2493.109|4.591|you want very small weights that meet a
2494.759|5.04|specific margin and SVM will give you
2497.7|3.599|this very nice max margin property that
2499.799|4.68|I didn't really go into in this in this
2501.299|4.381|lecture right now but but basically do
2504.479|6.11|want the positive number there otherwise
2505.68|4.909|things would break good
2519.11|6.97|um yeah is there so you're saying we're
2524.52|3.36|taking this exponential of these numbers
2526.08|4.02|that are real numbers and we're
2527.88|6.06|interpreting them as probabilities we're
2530.1|5.1|kind of free to so we decided you're
2533.94|3.63|getting these scores out and it's up to
2535.2|3.93|you to to endow them with interpretation
2537.57|2.82|right we can have different losses in
2539.13|2.94|this specific case I showed you
2540.39|3.36|multi-class SVM there's in fact multiple
2542.07|3.33|versions of a multi-class SVM you can
2543.75|5.03|fiddle around with exactly the loss
2545.4|5.37|expression and one of the one of the
2548.78|2.8|interpretations we can put on this
2550.77|3.36|course is that there are these
2551.58|3.84|unnormalized block probabilities they
2554.13|2.55|can't be normalized because they just
2555.42|2.58|can't we have to normalize them
2556.68|3.84|explicitly because there's no constraint
2558.0|5.16|that the output of your function will be
2560.52|3.84|normalized and they have to be they
2563.16|2.63|can't be probabilities because you're
2564.36|5.25|outputting just these real numbers that
2565.79|5.29|that can be positive or negative so we
2569.61|4.14|interpret them as LOC probabilities and
2571.08|5.52|and that requires us to exponentiate
2573.75|10.04|them it's a very bad kind of explanation
2576.6|7.19|of it because the thing is good
2593.75|3.3|yeah that's right so there are really
2594.92|4.52|cool or connections to physics and how
2597.05|4.95|they actually think about loss functions
2599.44|11.62|for them energy and loss is like kind of
2602.0|11.22|an equivalent as well good once it goes
2611.06|3.96|beyond the certain margin of two or
2613.22|3.45|three and just wind exponentiated
2615.02|5.819|the difference you will get in software
2616.67|7.89|you will be vanishingly small so you're
2620.839|4.651|talking about so say for example in this
2624.56|3.72|case yeah
2625.49|11.879|and now you arguing about save this one
2628.28|11.67|yeah that's right so what you're saying
2637.369|4.081|I think if Einstein correctly is the
2639.95|3.48|softmax would already look at this and
2641.45|3.72|give zero probabilities here and one
2643.43|3.689|here right so you're saying if I jiggle
2645.17|3.78|this around nothing's changing I think
2647.119|3.571|the difference is the loss would
2648.95|3.33|definitely change for softmax
2650.69|3.0|even though it wouldn't change a lot but
2652.28|3.299|it would definitely change so softmax
2653.69|9.149|still expresses preference whereas SVM
2655.579|8.941|gets you identically zero right yeah
2662.839|2.611|yeah so the preference wouldn't be very
2664.52|2.76|big but they're different layers
2665.45|3.84|preference but in practice basically
2667.28|5.37|this distinction the intuition I'm
2669.29|7.049|trying to give you is that the SVM has a
2672.65|4.86|very local part of the space in which
2676.339|5.131|you're classifying that it cares about
2677.51|5.52|and beyond it it's invariant and the
2681.47|4.17|softmax kind of is a function of the
2683.03|3.93|full data cloud it cares about it cares
2685.64|3.209|about all the points in your data cloud
2686.96|2.94|not just you know there's like a small
2688.849|3.151|class here that you're trying to
2689.9|3.63|separate out from everything else a soft
2692.0|3.27|max will kind of consider the full data
2693.53|3.569|cloud when it's fitting your plane and
2695.27|3.69|SVM will just want to separate out that
2697.099|5.041|tiny piece from the immediate part of
2698.96|5.1|the data cloud like that in practice
2702.14|4.35|when you actually run these they kind of
2704.06|5.13|give nearly identical results almost
2706.49|4.92|always so really what I'm trying to I'm
2709.19|3.77|not trying to pitch one or the other I'm
2711.41|3.36|just trying to give you this notion that
2712.96|3.909|you're in charge of the last function
2714.77|3.69|you get some scores out and you can
2716.869|2.49|write down nearly any mathematical
2718.46|3.06|expression as long as it's
2719.359|3.901|differentiable into what you want your
2721.52|3.0|scores to be like and there are
2723.26|2.359|different ways of actually formulating
2724.52|2.66|this and actually
2725.619|3.96|two examples that are common to seem
2727.18|4.02|practice but in practice we can put down
2729.579|4.081|any losses for what you want your scores
2731.2|4.159|to be and that's a very nice feature
2733.66|4.439|because we can optimize over all of it
2735.359|7.831|okay let me show you an interactive web
2738.099|5.091|demo at this point jefra
2745.95|7.659|all right let's see you this so this is
2752.259|3.121|an interactive demo in our class page
2753.609|4.14|you can find it at this URL
2755.38|3.6|I wrote it last year and I have to show
2757.749|3.57|it to all of you guys to justify
2758.98|5.879|spending one day on developing all this
2761.319|5.76|okay but I'm not sure last year not too
2764.859|3.541|many people looked at this okay but
2767.079|5.581|basically this is one day of my life you
2768.4|6.3|should all look at this so we have here
2772.66|5.31|is a two-dimensional problem with three
2774.7|5.369|classes and I'm showing here three
2777.97|4.139|classes each has three examples over
2780.069|3.78|here in two dimensions and I'm showing
2782.109|3.541|the three classifiers here is the level
2783.849|4.2|set so for example the red classifier is
2785.65|4.349|has scores of zero along the line and
2788.049|4.111|then I'm showing the arrows in which the
2789.999|5.461|scores increase right here's our W
2792.16|4.859|matrix so as you recall this W matrix
2795.46|3.149|the rows of that W matrix are the
2797.019|3.57|different classifiers so we have the
2798.609|3.811|blue classifier red-green classifier and
2800.589|3.27|red classifier and we have both the
2802.42|4.47|weights for both the X and the y
2803.859|4.38|component and also the biases and then
2806.89|2.969|here we have need data sets so we have
2808.239|3.87|the X and the y coordinate of all the
2809.859|5.19|data points their correct label and this
2812.109|4.801|course as well as the loss achieved by
2815.049|4.141|all those data points right now with
2816.91|3.51|this setting of W and so you can see
2819.19|3.119|that I'm taking the mean over all the
2820.42|3.869|loss so right now our data loss is two
2822.309|4.44|point seven seven regularization loss
2824.289|3.841|for this w is three point five and so
2826.749|3.78|our total loss is six point two seven
2828.13|5.25|okay and so basically you can fiddle
2830.529|5.611|around with this so let's see so as I
2833.38|5.07|change my W you can see that here I'm
2836.14|5.879|making my W one of the W is bigger and
2838.45|5.609|you can see what that does in in there
2842.019|6.451|or the bias you can see that the bias
2844.059|7.411|basically shuts these hyperplanes okay
2848.47|4.17|and then what we can do is we can what
2851.47|2.339|we're going to work this is kind of a
2852.64|3.209|preview of what's going to happen we're
2853.809|3.21|getting the loss here and then we're
2855.849|2.91|going to do back propagation which is
2857.019|2.131|giving us the gradient over how we want
2858.759|2.551|to
2859.15|4.98|just these double use in order to make
2861.31|4.71|the loss smaller and so what we're going
2864.13|3.33|to do is this repeated updates where we
2866.02|4.71|start off with this w but now I can
2867.46|6.63|improve I can improve this set of WS so
2870.73|4.74|when I do a parameter update this is
2874.09|3.69|actually using these gradients which are
2875.47|3.96|shown here in red and it's actually
2877.78|3.3|making a tiny change to every single
2879.43|3.6|parameter according to this gradient
2881.08|3.54|right so as I do
2883.03|3.81|parameter update you can see that the
2884.62|4.44|loss here is decreasing
2886.84|3.24|especially the total loss here so the
2889.06|2.64|loss just keeps getting better and
2890.08|2.88|better as I do parameter update so this
2891.7|5.34|is the process of optimization that
2892.96|6.27|we're going to go into in a bit so I can
2897.04|4.14|also start a repeated update and then
2899.23|3.72|basically we keep improving this W over
2901.18|3.72|and over until our loss it started off
2902.95|3.81|was roughly three or something like that
2904.9|4.35|so now our mean loss over the data is
2906.76|3.87|0.1 or something like that and we're
2909.25|7.37|correctly classifying all these all
2910.63|8.67|these points here so I can also
2916.62|4.18|randomized randomized W so just kind of
2919.3|2.61|knocks it off and then this always
2920.8|4.49|converges to the exact same point
2921.91|5.04|through the process of optimization and
2925.29|2.98|you can play here with the
2926.95|3.84|regularization as well you have
2928.27|3.75|different forms of a loss so the one
2930.79|3.09|I've shown you right now is the Western
2932.02|4.11|Watkins SVM formulation there's a few
2933.88|4.86|more SVM formulations and there's also
2936.13|4.98|soft max here and you'll see that when I
2938.74|6.42|switch to soft max loss our losses look
2941.11|5.52|different and but the solution ends up
2945.16|3.96|being roughly the same so when I switch
2946.63|3.99|back to an SVM you know the hyper planes
2949.12|7.2|move around the tiny bit but really it's
2950.62|8.4|it's mostly the same and so anyways so
2956.32|6.18|this is the step size so this is how
2959.02|4.98|much how big of steps are we making when
2962.5|3.81|we get the gradient on how to improve
2964.0|3.54|things so randomized parameters we
2966.31|2.43|usually start with the berry mix this
2967.54|2.58|step size these things are jiggling
2968.74|2.97|trying to separate out these data points
2970.12|3.12|and then over time what we're going to
2971.71|4.35|be doing in optimization as we're going
2973.24|6.06|to decrease our update size and this
2976.06|4.94|thing will just slowly converging on the
2979.3|4.26|parameters that we want in the end and
2981.0|3.79|so so you guys can play with this and
2983.56|3.6|you can see how these scores jiggle
2984.79|5.0|around and what the loss is and if I
2987.16|5.37|stop a repeated update work with yours
2989.79|3.1|you can also drag these points but I
2992.53|2.22|think
2992.89|3.48|on the Mac it doesn't work so : so when
2994.75|6.12|I try to drag this point it disappears
2996.37|5.58|so but it works on a desktop so I don't
3000.87|4.17|want to go in and figure out exactly
3001.95|13.17|what happened there but so you can play
3005.04|11.76|with this okay so I'm going to go into
3015.12|2.82|the process optimization now just to
3016.8|6.66|give you a sense of what this looks like
3017.94|7.05|so we have this app function we have
3023.46|3.93|these two formulations that I've shown
3024.99|3.96|you and the full loss is achieved as the
3027.39|4.05|mean loss over data plus regularization
3028.95|5.25|this is one other diagram to show you
3031.44|4.23|how what this looks like I don't think
3034.2|2.55|it's a very good diagram and there's
3035.67|3.21|something confusing about it that I
3036.75|4.2|can't remember from last year but
3038.88|6.03|basically you have this data x and y
3040.95|6.21|your images and your labels and there's
3044.91|4.29|w and we're computing this course and
3047.16|3.42|getting the loss and the regularization
3049.2|4.92|loss is only a function of the weights
3050.58|6.0|not of the data and basically what we
3054.12|3.84|want to do now is we don't have control
3056.58|3.15|over the data set right that's given to
3057.96|4.08|us but we have control over that W and
3059.73|5.31|as we change that W the loss will be
3062.04|5.25|different so for any W you give me I can
3065.04|4.56|compute the loss and that loss is linked
3067.29|4.65|to how well we're classifying all of our
3069.6|3.96|examples so one thing a low loss means
3071.94|3.21|we're classifying them very very well on
3073.56|2.7|the training data and then we're
3075.15|2.94|crossing our fingers that that also
3076.26|4.41|works on on some test data that we
3078.09|6.15|haven't seen so here's one strategy for
3080.67|5.37|optimization it's a random search so
3084.24|3.9|because we can evaluate loss for any
3086.04|4.44|arbitrary W what I can afford to do and
3088.14|3.9|I'm not sure I don't want to go through
3090.48|3.84|this in full detail but effectively I
3092.04|3.93|randomly sample W's and I can check
3094.32|4.08|their loss and I can just keep track of
3095.97|5.04|the W that works best okay so that's an
3098.4|5.31|amazing process of optimization of guess
3101.01|5.34|and check and it turns out if you do
3103.71|3.81|this I think I tried a thousand times if
3106.35|3.12|you do this a thousand times
3107.52|4.38|and you take the best W found at random
3109.47|4.83|and you run it on your C for ten data
3111.9|4.38|test data you end up with about fifteen
3114.3|3.39|point five percent accuracy and since
3116.28|4.41|there are ten classes and see far the
3117.69|5.01|mean the baseline is a ten percent
3120.69|3.18|that's our chance performance so fifteen
3122.7|2.22|point five there's some signal actually
3123.87|3.69|indelibly
3124.92|4.47|and so state of the art is at 95 which
3127.56|6.33|is a covenant so we have some gap to
3129.39|6.63|clothes over the next two weeks or so so
3133.89|4.53|this is so don't use this just because
3136.02|4.11|it's on the slides one interpretation of
3138.42|3.54|exactly what this looks like this
3140.13|3.99|process of optimization is that we have
3141.96|4.77|this lost landscape right this lost
3144.12|5.55|landscape is in this high dimensional W
3146.73|5.97|space so here we I guess if you're 3d
3149.67|4.71|and your loss is the height then you
3152.7|4.47|only have to double use in this case and
3154.38|4.47|you're here and you're blindfolded
3157.17|3.09|that's your current W you can't see
3158.85|3.39|where the valleys are but you're trying
3160.26|3.72|to find low loss and so you're
3162.24|3.45|blindfolded and you have an altitude
3163.98|3.93|meter and so you can tell what your
3165.69|3.33|losses at any single point and you're
3167.91|3.96|trying to get to the bottom of the
3169.02|6.33|valley right and so that's really the
3171.87|5.22|process of optimization and what we've
3175.35|4.14|shown what I've shown you so far is this
3177.09|3.81|random optimization where you teleport
3179.49|3.81|around and you just check your altitude
3180.9|3.75|right so not the best idea so we're
3183.3|2.88|going to do instead is we're going to
3184.65|3.69|use what I refer to already as a
3186.18|4.88|gradient or really we're just computing
3188.34|6.09|the slope across in every single
3191.06|5.14|direction so I'm trying to compute the
3194.43|4.98|slope and then I'm going to go downhill
3196.2|4.65|okay so we're following the slope I'm
3199.41|2.79|not going to go into too much detail on
3200.85|3.69|this but basically there's an expression
3202.2|6.86|for the gradient which is defined like
3204.54|7.41|that there's a derivative calculus 101 a
3209.06|4.87|definition in multiple dimensions if you
3211.95|3.96|have a vector of derivatives that's
3213.93|3.21|referred to as the gradient right so
3215.91|3.69|because we have multiple dimensions
3217.14|6.51|multiple w's we have a gradient vector
3219.6|6.06|okay so this is the expression and in
3223.65|3.6|fact we can numerically evaluate this
3225.66|2.94|expression before I go into the analytic
3227.25|2.67|solution I'll just show you what that
3228.6|3.84|would look like to evaluate a gradient
3229.92|4.83|at some W so suppose we have some
3232.44|4.23|current W and we're getting some loss
3234.75|4.17|okay what we want to do now is we want
3236.67|5.7|to get an idea about the slope at this
3238.92|4.65|point so we're going to basically look
3242.37|3.33|at this formula and we're just going to
3243.57|4.32|evaluate it so I'm going to go in the
3245.7|3.57|first dimension and I'm going and really
3247.89|4.41|what this formula is telling you to do
3249.27|5.28|is evaluate X plus your altitude at X
3252.3|4.5|plus h subtracted from f of X and divide
3254.55|3.65|by h what that corresponds to is me
3256.8|3.71|being on this length scale
3258.2|4.29|taking a small step in some direction
3260.51|3.27|and looking whether or not my foot went
3262.49|3.63|up or down right that's what the
3263.78|4.38|gradient is telling me so suppose I took
3266.12|4.05|a small step and the loss there is one
3268.16|3.99|point two five then I can use that
3270.17|3.33|formula with a finite difference
3272.15|3.84|approximation where I've used the small
3273.5|3.78|H to actually derive that the gradient
3275.99|3.9|here is negative two point five the
3277.28|4.5|slope is downwards so I took a step the
3279.89|3.3|loss decreased so this is sloping
3281.78|3.63|downwards in terms of the loss function
3283.19|4.32|so negative two point five in that
3285.41|2.97|particular dimension so now I can do
3287.51|2.64|this for every single dimension
3288.38|4.17|independently right so I go into the
3290.15|4.47|second dimension I add a small amount so
3292.55|3.93|I step in a different direction I look
3294.62|3.09|at what happened to the loss I use that
3296.48|3.75|formula and it's telling me that the
3297.71|4.05|gradient the slope is point six and I
3300.23|4.14|can do that in the third dimension and I
3301.76|4.8|get the gradient there okay so what I'm
3304.37|5.31|referring to here is I'm basically
3306.56|4.56|evaluating the numerical gradient which
3309.68|2.91|is using this finite difference
3311.12|3.39|approximation where for every single
3312.59|3.66|dimension independently I can take a
3314.51|3.6|small step I can evaluate the loss and
3316.25|3.18|that tells me the slope is it going
3318.11|4.37|upwards or downwards for every single
3319.43|5.58|one of these parameters and so this is
3322.48|4.78|evaluating numerical gradient the way
3325.01|4.05|this would look like is a Python
3327.26|3.12|function here it looks ugly because it
3329.06|3.9|turns out it's slightly tricky to
3330.38|4.35|iterate over all the W's but basically
3332.96|4.02|we're just looking at f of X plus h
3334.73|4.68|comparing to f of X and dividing by H
3336.98|4.14|and we're getting the gradient now the
3339.41|4.5|problem with this is if you want to use
3341.12|3.9|the numerical gradient then of course we
3343.91|2.61|have to do this for every single
3345.02|2.91|dimension to get a sense of what the
3346.52|4.95|gradient is in every single dimension
3347.93|5.22|and right when you have a ComNet you
3351.47|3.6|have hundreds of millions of parameters
3353.15|4.68|right so we can't afford to actually
3355.07|5.04|check the loss in hundreds of millions
3357.83|4.92|of parameters before we do a single step
3360.11|4.5|so this approach where we would try to
3362.75|3.6|evaluate the gradient numerically is
3364.61|2.52|first of all it's approximate because
3366.35|2.52|we're using finite difference
3367.13|3.84|approximations but second is also
3368.87|4.8|extremely slow because I need to do
3370.97|4.47|million checks of the last function on
3373.67|2.94|my ComNet before I know what the
3375.44|5.04|gradient is and I can take a parameter
3376.61|5.73|update so very slow approximate turns
3380.48|5.37|out that this is also silly right
3382.34|5.82|because the loss is a function of W as
3385.85|4.08|we've written it out and really what we
3388.16|2.9|want is we want the gradient of the last
3389.93|2.78|function with respect to W
3391.06|6.09|and luckily we can just write that down
3392.71|8.37|thanks to these guys you actually know
3397.15|5.1|who those guys are right away you need
3401.08|2.43|to know the light knits that's right
3402.25|5.82|do you know which is which because they
3403.51|6.15|look this it's just uh yeah they look a
3408.07|4.56|remarkably similar but basically nice
3409.66|4.62|enlighten it's sort of two inventors of
3412.63|4.44|calculus there's actually controversy
3414.28|5.16|over who really invented calculus and
3417.07|3.87|these guys fought each other over it but
3419.44|4.35|basically calculus is this powerful
3420.94|3.93|hammer and so what we can do is instead
3423.79|2.64|of doing the silly thing where we're
3424.87|3.6|evaluating numerical gradient we can
3426.43|3.72|actually use calculus and we can write
3428.47|3.78|down an expression for what the gradient
3430.15|4.62|is off that lost function in the weight
3432.25|4.08|space so basically instead of fumbling
3434.77|2.82|around and doing this is it going
3436.33|3.45|upwards it going down by checking the
3437.59|4.59|loss I just have an expression where I
3439.78|4.17|take the gradient of this and I can sing
3442.18|3.78|simply evaluate what that entire vector
3443.95|3.54|is so that's the only way that you can
3445.96|3.3|actually run this in practice right we
3447.49|4.1|can just have an expression for here's
3449.26|4.95|the gradient we can do a step and so on
3451.59|4.33|so in summary basically numerical
3454.21|4.92|gradient approximate slow but very easy
3455.92|5.07|to write because you're just doing this
3459.13|3.36|very simple process for any arbitrary
3460.99|3.87|loss function I can get the gradient
3462.49|4.86|vector for analytic gradient which is
3464.86|5.76|you actually do calculus it's exact no
3467.35|4.44|finite approximations it's very fast but
3470.62|4.02|it's error-prone because you actually
3471.79|5.07|have to do math right so in practice
3474.64|4.56|what you see is we always use analytic
3476.86|4.05|gradient we do clear calculus we figure
3479.2|3.27|out what the gradient should be but then
3480.91|3.63|you always check your implementation
3482.47|5.46|using a numerical gradient check as it's
3484.54|4.47|referred to so I will do all my calculus
3487.93|3.24|I figure out what the loss function
3489.01|5.4|should be I write an expression for the
3491.17|5.55|gradient I evaluate it in my code so I
3494.41|3.69|get an analytic gradient and then I also
3496.72|2.82|evaluate a numerical gradient on the
3498.1|2.82|side and that takes awhile but you
3499.54|2.88|enumerate your you evaluate your
3500.92|3.87|numerical gradient and you make sure
3502.42|3.69|that those two are the same and then we
3504.79|3.63|say that you pass the gradient check
3506.11|3.72|okay so that's what you see in practice
3508.42|3.12|whenever you try to develop a new module
3509.83|3.51|for your neural network you write out at
3511.54|3.75|Sloss you write the backward pass for it
3513.34|3.3|that computes the gradient and then you
3515.29|3.27|have to make sure the gradient check it
3516.64|4.29|just to make sure that your calculus is
3518.56|4.65|correct and then I've already referred
3520.93|3.73|to this process of optimization which we
3523.21|3.849|saw nicely in the web demo
3524.66|4.409|where we have this loop when we optimize
3527.059|4.53|where we simply evaluate the gradient on
3529.069|4.05|your loss function and then knowing the
3531.589|3.421|gradient we can perform a parameter
3533.119|4.111|update where we change this W by tiny
3535.01|5.849|amount in particular we want to update
3537.23|6.54|with the negative step size times the
3540.859|4.44|gradient the negative is there because
3543.77|3.029|the gradient tells you the direction of
3545.299|3.421|the greatest increase it tells you which
3546.799|3.54|way the loss is increasing and we want
3548.72|2.819|to minimize it which is where the
3550.339|3.301|negative is coming from we have to go
3551.539|3.631|into negative gradient direction step
3553.64|2.79|size here is a hyper parameter that will
3555.17|3.689|cause you a huge amount of headaches
3556.43|4.649|step size or learning rate this is the
3558.859|6.96|most critical parameter to basically
3561.079|6.061|worry about that really there's two that
3565.819|3.27|you have to worry about the most the
3567.14|3.78|step size or learning rate and there's
3569.089|3.361|the weight regularization strength
3570.92|3.27|lambda that we saw already those two
3572.45|3.419|parameters are really the two largest
3574.19|3.81|headaches and that's usually what we
3575.869|9.301|cross validate over was there a question
3578.0|9.39|in the back by the way it's not that
3585.17|5.01|gradient is just gradient it tells you
3587.39|5.659|the slope in every single direction and
3590.18|5.639|then we just take a step size step of it
3593.049|4.841|so the process of optimization in this
3595.819|3.901|weight space is you're somewhere in your
3597.89|3.899|W you get your gradient and you March
3599.72|5.01|some amount in the direction of the
3601.789|4.77|gradient but you don't know how much so
3604.73|3.15|that's the step size and you saw that
3606.559|2.821|when I increase the step size in the
3607.88|2.82|demo things were jiggling generating
3609.38|2.85|around quite a lot right there was a lot
3610.7|3.06|of energy in the system that's because I
3612.23|3.9|was taking huge jumps all over this
3613.76|4.74|basin so here the loss function is
3616.13|4.169|minimal at the blue part there and it's
3618.5|4.74|high in the red parts so we want to get
3620.299|4.05|to them lowest part of the basin this is
3623.24|3.809|actually what the loss function looks
3624.349|4.621|like for an SVM or for legislation these
3627.049|3.181|are convex problems so as you really
3628.97|3.03|just a bowl and we're trying to get to
3630.23|3.48|the bottom of it but this bowl is like
3632.0|5.549|30,000 dimensional so that's why it
3633.71|5.639|takes a while okay so we take a step and
3637.549|4.77|we evaluate the gradient and repeat this
3639.349|4.801|over and over in practice there's this
3642.319|3.601|additional part that I wanted to mention
3644.15|4.23|where we don't actually evaluate the
3645.92|5.189|loss for the entire training data set in
3648.38|3.81|fact what we do is we only use what's
3651.109|3.661|called a mini batch gradient descent
3652.19|5.01|where we have this entire data set but
3654.77|3.6|we sample batches from it so we sample
3657.2|3.27|say like
3658.37|4.14|say 32 examples out of my training data
3660.47|4.08|I evaluate the loss in the gradient on
3662.51|3.42|this batch of 32 and then I do my
3664.55|3.3|parameter update and I keep doing this
3665.93|3.69|over and over again and basically what
3667.85|3.99|ends up happening is if you only sample
3669.62|4.32|very few data points from your training
3671.84|4.17|data then your estimate of the gradient
3673.94|4.14|of course over the entire training set
3676.01|3.93|is kind of noisy because you're only
3678.08|3.9|estimating it based on a small subset of
3679.94|4.2|your data but it allows you to step more
3681.98|3.69|so you can do more steps with
3684.14|3.54|approximate gradient or you can do few
3685.67|3.93|steps with exact gradient and in
3687.68|4.8|practice what ends up working better is
3689.6|4.77|if you use mini batch and it's much more
3692.48|3.48|efficient of course and it's impractical
3694.37|4.47|to actually do full batch gradient
3695.96|6.24|descent so common mini batch size is 32
3698.84|5.43|64 128 256 this is not usually a hyper
3702.2|4.38|parameter we worry about too much you
3704.27|3.96|usually set it based on whatever fits on
3706.58|3.21|your GPU we're going to be talking about
3708.23|3.06|GPUs in a bit but they have finite
3709.79|3.09|amount of memory say about like 6
3711.29|3.9|gigabytes or 12 gigabytes if you have a
3712.88|4.29|good GPU and you usually choose a batch
3715.19|3.93|size such that the small mini batch of
3717.17|3.27|examples fits in your memory so that's
3719.12|2.79|how usually that's determined it's not a
3720.44|10.35|hyper parameter that actually matters a
3721.91|10.35|lot in a optimization sense good yeah
3730.79|3.12|for sure and we're going to get to
3732.26|3.99|momentum in a bit but if you wanted to
3733.91|3.42|use momentum then yeah this is just fine
3736.25|3.92|we always use mini batch gradient
3737.33|4.95|descent with momentum very common to do
3740.17|3.7|so just to give you an idea about what
3742.28|4.14|this looks like in practice if I'm
3743.87|4.68|running optimization over time and I'm
3746.42|4.41|looking at the loss evaluated on just a
3748.55|4.35|small mini batch of data and you can see
3750.83|3.57|that basically my loss goes down over
3752.9|4.23|time on these mini batches from the
3754.4|4.98|training data so as I'm optimizing I'm
3757.13|4.62|going downhill now of course if I was
3759.38|3.93|doing full batch gradient descent so
3761.75|2.76|this was not just mini batches sample
3763.31|2.79|from the data you wouldn't expect as
3764.51|3.78|much noise you just expect this to be a
3766.1|3.81|line that just goes down but because we
3768.29|3.18|use mini batches you get this noise in
3769.91|3.6|there because how many batches are
3771.47|4.44|better than others but over time they
3773.51|4.52|kind of all go down over time is there a
3775.91|2.12|question
3783.7|3.79|yes so you're wondering about the shape
3786.14|3.39|of this loss function you're used to
3787.49|3.93|maybe seeing more rapid improvement
3789.53|5.55|quicker these loss functions come in
3791.42|5.76|different shapes sizes so it really
3795.08|4.62|depends it's not necessarily the case
3797.18|4.32|that a loss function must look very
3799.7|3.84|sharp in the beginning although
3801.5|4.41|sometimes they do give different shapes
3803.54|4.23|for example it also matters on your
3805.91|3.8|initialization if I'm careful with my
3807.77|5.52|initialization I would expect less of a
3809.71|5.38|jump but if I initialize very
3813.29|3.48|incorrectly then you would expect that
3815.09|3.57|that's going to be fixed very early on
3816.77|3.21|in the optimization we're going to get
3818.66|4.23|to some of those parts I think much
3819.98|8.19|later I also wanted to show you a plot
3822.89|6.96|of the effects of learning rate on your
3828.17|4.05|loss function and this learning rate is
3829.85|3.96|the step size basically if you have very
3832.22|3.33|high learning rates or step sizes you
3833.81|3.96|start thrashing around in your W space
3835.55|4.62|and so either you don't converge or you
3837.77|3.9|explode if you have a very low learning
3840.17|3.09|rate then you're barely doing any
3841.67|5.07|updates and all so it takes a very long
3843.26|5.4|time to actually converge and if you
3846.74|3.81|have a high learning rate sometimes you
3848.66|4.35|can basically get kind of stuck in a bad
3850.55|3.69|position of a loss so these loss
3853.01|2.37|functions kind of you need to get down
3854.24|2.58|to the minimum so if you have too much
3855.38|3.42|energy and you're stepping too quickly
3856.82|3.33|then you don't have you don't allow your
3858.8|3.6|problem to kind of settle in on the
3860.15|4.41|smaller local minima and your objective
3862.4|3.39|in general when you talk about neural
3864.56|2.61|networks and optimization you'll see a
3865.79|2.85|lot of hand waving because that's the
3867.17|3.93|only way we communicate about these
3868.64|4.08|losses and basin's so just imagine like
3871.1|3.66|a big basin of loss and there are these
3872.72|3.87|like smaller pockets of smaller loss and
3874.76|3.6|so if you're thrashing around and you
3876.59|4.2|can't settle in on the smaller lost
3878.36|4.62|parts and converge further so that's why
3880.79|3.45|the learning rate is no good and so you
3882.98|2.67|need to find the correct learning rate
3884.24|3.21|which will cause you a lot of headaches
3885.65|2.97|and what people do most of the time is
3887.45|2.46|sometimes you start off with a high
3888.62|4.08|learning rate so you get some benefits
3889.91|4.92|and then you decay it over time so you
3892.7|3.51|start off with high and then we decay
3894.83|5.04|this learning rate over time as we're
3896.21|5.34|settling in on the good solution and I
3899.87|3.36|also want to point out who I'll go into
3901.55|3.54|this in much more detail but the way I'm
3903.23|3.42|doing the update here which is how do
3905.09|5.4|you use the gradients to actually modify
3906.65|5.91|your W that's called an update parameter
3910.49|3.99|update there are many different forms
3912.56|4.49|doing it this is the simplest way which
3914.48|4.83|we refer to as just SGD simplest
3917.05|3.76|stochastic gradient descent but there
3919.31|3.45|are many formulas such as momentum that
3920.81|3.18|was already mentioned in momentum you
3922.76|3.66|basically imagine as you're doing this
3923.99|4.86|optimization you imagine keeping track
3926.42|4.17|of this velocity so as I'm stepping I'm
3928.85|3.09|also keeping track of my velocity so if
3930.59|2.01|I keep seeing a positive gradient in
3931.94|2.1|some direction
3932.6|4.02|I will accumulate velocity in that
3934.04|4.53|direction so I don't need so I'm going
3936.62|3.18|to go faster in that direction and so
3938.57|3.15|there are several formulas we'll look at
3939.8|2.46|them shortly in the class but at a grad
3941.72|4.53|rmsprop
3942.26|6.54|atom more commonly used so just to show
3946.25|3.96|you effect of different what these look
3948.8|3.24|like these different choices and what
3950.21|6.33|they might do in your loss function this
3952.04|7.86|is a figure from Alec so here we have a
3956.54|5.52|loss function and these are the level
3959.9|3.36|curves and we start off optimization
3962.06|3.99|over there and we're trying to get to
3963.26|4.32|the basin and different update formulas
3966.05|3.78|will give you better or worse
3967.58|3.96|convergence in different problems so you
3969.83|3.96|can see for example this momentum in
3971.54|4.05|green it built up momentum as it went
3973.79|4.11|down and then it overshot and then it
3975.59|3.99|kind of go back goes back and this SGD
3977.9|4.14|takes forever to converge in red that's
3979.58|3.81|what I presented you so far so SGD takes
3982.04|4.26|forever to converge and there are
3983.39|4.05|different ways of actually performing
3986.3|2.34|this parameter update there are more or
3987.44|4.11|less efficient in the case of
3988.64|6.48|optimization yeah so we'll see much more
3991.55|5.54|of this soon I also wanted to mention at
3995.12|4.38|this point a slightly shifting gears I
3997.09|4.3|wanted to go slightly into I'd explain
3999.5|3.3|now basically a linear classification we
4001.39|2.49|know how to set up the problem we know
4002.8|2.76|there are different loss functions we
4003.88|3.51|know how to optimize them so we can kind
4005.56|4.2|of do linear classifiers at this point
4007.39|3.72|in the class I wanted to mention that I
4009.76|2.46|want to give you a sense of what
4011.11|2.55|computer vision looked like before
4012.22|3.45|commnets came about so that you have a
4013.66|4.2|bit of historical perspectives because
4015.67|3.54|we used linear classifiers all the time
4017.86|3.12|but of course you don't use linear
4019.21|4.44|classifiers on the raw original image
4020.98|4.2|because that's a pixel you don't want to
4023.65|3.15|put linear classifiers on pixels we saw
4025.18|3.96|all the problems with it like you have
4026.8|3.45|to cover all the modes and so on so what
4029.14|2.22|people used to do is they used to
4030.25|4.17|compute all these different feature
4031.36|4.47|types of images and then you compute
4034.42|3.71|different descriptors and different
4035.83|4.56|feature types and you get these
4038.13|3.88|statistical summaries of what the image
4040.39|3.6|looks like what the frequencies are like
4042.01|4.02|and so on and then we concatenated all
4043.99|4.25|those into large vectors and then we
4046.03|4.35|type those into linear classifiers so
4048.24|3.73|different feature types all of them
4050.38|2.97|concatenate it and then that went into
4051.97|3.21|linear classifiers that was usually the
4053.35|3.42|pipeline so just to give you an idea of
4055.18|3.75|really what these feature types were
4056.77|3.3|like one very simple feature type you
4058.93|3.54|might imagine is just the color
4060.07|5.07|histogram so I go over all the pixels in
4062.47|4.35|the image and I bend them and to say how
4065.14|4.26|many bins are there for different colors
4066.82|3.9|depending on the hue of the color as you
4069.4|2.79|can imagine this is kind of like one
4070.72|3.45|statistical summary of what's in the
4072.19|3.81|image is just a number of colors in each
4074.17|3.18|bin so this will become one of my
4076.0|2.64|features that I would eventually become
4077.35|5.58|captain aiding with many different
4078.64|5.76|feature types another kind of and so
4082.93|2.97|basically the classifier if you think
4084.4|3.03|about it the linear classifier can use
4085.9|2.97|these features to actually perform the
4087.43|3.63|classification because the linear
4088.87|4.11|classifier can like or dislike seeing
4091.06|4.04|lots of different colors in the image
4092.98|4.14|with positive or negative weights very
4095.1|4.23|common features also included things
4097.12|4.59|like what we call sift and hawk features
4099.33|4.029|basically these where you go in local
4101.71|2.94|neighborhoods in the image and you look
4103.359|4.141|at whether or not there are lots of
4104.65|4.169|edges of different orientations so are
4107.5|3.0|there lots of horizontal edges or
4108.819|4.02|vertical edges we make up histograms
4110.5|5.31|over that and so then you end up with
4112.839|4.281|just this summary of what kinds of edges
4115.81|4.47|are where in the image and you
4117.12|5.41|concatenate all those together there was
4120.28|3.93|different lots of different feature
4122.53|5.039|types that were proposed over the years
4124.21|5.85|just LBP text on lots of different ways
4127.569|4.531|of measuring what kinds of things are
4130.06|4.29|there in the image and statistics of
4132.1|5.64|them and then we had these pipelines
4134.35|5.46|called bag-of-words pipelines where you
4137.74|4.86|look at different points in your image
4139.81|4.44|you describe a little local patch with
4142.6|3.18|some scheme that you come up with like
4144.25|4.17|looking at the frequencies or looking at
4145.78|4.86|the colors or whatever and then we came
4148.42|4.29|up with these dictionaries for okay
4150.64|3.42|here's the stuff we see in images like
4152.71|3.66|there's lots of high frequency stuff or
4154.06|4.41|low frequency stuff and blue and so on
4156.37|4.92|so you end up with these centroids using
4158.47|4.889|k-means of what kind of stuff do we seen
4161.29|4.71|images and then we express every single
4163.359|5.101|image as statistics over how much of
4166.0|3.9|each thing we see in the image so for
4168.46|3.75|example this image has lots of high
4169.9|4.26|frequency green stuff so you might see
4172.21|4.02|some feature vector that basically will
4174.16|4.56|have a high value in high frequency and
4176.23|3.57|in green and then what we did is we
4178.72|2.85|basically took these
4179.8|4.83|vectors we concatenated them and put a
4181.57|4.47|linear classifier on them so really the
4184.63|3.33|context for what we were doing is as
4186.04|3.36|follows what it looked like
4187.96|3.9|Muslim computer vision before roughly
4189.4|3.93|2012 was that you take your image and
4191.86|3.48|you have a step of feature extraction
4193.33|4.08|where we decided what are important
4195.34|4.08|things to you know compute about an
4197.41|4.44|image different frequencies different
4199.42|4.05|bins and we decided on what are
4201.85|2.82|interesting features and you'd see
4203.47|2.34|people take like 10 different feature
4204.67|2.91|types in every paper and just
4205.81|3.75|concatenate all of it just just dump all
4207.58|3.78|of it you end up with one giant feature
4209.56|3.06|vector over your image and then you put
4211.36|3.45|a linear classifier on top of it just
4212.62|3.81|like we saw right now and so you train
4214.81|3.63|sale in your SVM on top of all these
4216.43|4.26|feature types and what we're replacing
4218.44|4.53|it since then we found that what works
4220.69|4.2|much better is you start with the raw
4222.97|4.5|image and you think of the whole thing
4224.89|4.17|you're not designing some part of it in
4227.47|3.54|isolation of what you think is a good
4229.06|4.38|idea or not we come up with an
4231.01|4.35|architecture that can simulate a lot of
4233.44|3.84|those different features so to speak and
4235.36|4.14|since everything is just a single
4237.28|4.05|function we don't just train the top of
4239.5|3.27|it on top of the features but we can
4241.33|3.21|actually train all the way down to the
4242.77|4.59|pixels and we can train our feature
4244.54|4.38|extractors effectively so that was the
4247.36|3.78|big innovation and how you approach this
4248.92|3.93|problem is we try to eliminate a lot of
4251.14|3.3|hand engineered components and we're
4252.85|3.78|trying to have a single differentiable
4254.44|4.08|blob so that we can fully train the full
4256.63|4.35|thing starting at the raw pixels so
4258.52|3.9|that's where historically this is coming
4260.98|4.71|from and what we'll be doing in this
4262.42|5.16|class and so next class we'll be looking
4265.69|4.23|specifically at this problem of we need
4267.58|3.54|to compute the analytic gradients and so
4269.92|2.85|we're going to go into back propagation
4271.12|4.35|which is an efficient way of computing
4272.77|4.68|analytic gradient and so that's backdrop
4275.47|4.02|and you're going to become good at it
4277.45|5.33|and then we're going to go slightly into
4279.49|3.29|neural networks that's it