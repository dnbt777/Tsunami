start_time|end_time|text
0.03|3.99|yeah so thank you very much for the
1.079|4.981|introduction so today I'll speak about
4.02|4.44|deep learning especially in the context
6.06|4.829|of computer vision so you saw in the
8.46|4.02|previous talk is neural networks so you
10.889|3.54|saw the neural networks are organized
12.48|3.69|into these layers fully connected layers
14.429|3.811|where neurons in one layer are not
16.17|3.18|connected but they're connected fully to
18.24|2.73|all the neurons in the previous layer
19.35|4.11|and we saw that basically we have this
20.97|5.069|layer wise structure from input until
23.46|5.25|output and there are neurons and
26.039|4.201|nonlinearities etc now so far we have
28.71|3.509|not made too many assumptions about the
30.24|3.479|inputs so in particular here we just
32.219|3.511|assume that an input is some kind of a
33.719|6.511|vector of numbers that we plug into this
35.73|6.78|neural network so that both a bug and a
40.23|4.649|feature to some extent because in most
42.51|3.479|in most real-world applications we
44.879|2.941|actually can make some assumptions about
45.989|6.09|the input that make learning much more
47.82|7.41|efficient learning much more efficient
52.079|4.951|so in particular usually we don't just
55.23|3.66|want to plug in into neural networks
57.03|3.299|vectors of numbers but they actually
58.89|2.759|have some kind of a structure so we
60.329|3.23|don't have vectors of numbers but these
61.649|4.65|numbers are arranged in some kind of a
63.559|4.6|layout like an N dimensional array of
66.299|3.601|numbers so for example spectrograms are
68.159|3.0|two dimensional arrays of numbers images
69.9|3.39|are three dimensional arrays of numbers
71.159|4.171|videos would be four dimensional arrays
73.29|3.96|of numbers text you could treat as one
75.33|3.42|dimensional array of numbers and so
77.25|4.229|whenever you have this kind of local
78.75|3.9|connectivity structure in your data then
81.479|2.881|you'd like to take advantage of it and
82.65|2.539|convolutional neural networks allow you
84.36|3.42|to do that
85.189|3.79|so before I dive into commercial neural
87.78|3.449|networks and all the details of the
88.979|3.901|architectures I'd like to briefly talk
91.229|4.051|about a bit of the history of how this
92.88|4.169|field evolved over time so I like to
95.28|3.69|start off usually with talking about
97.049|4.201|Hubble and Wiesel and the experiments
98.97|3.899|that they performed in 1960s so what
101.25|4.079|they were doing is trying to study the
102.869|5.64|computations that happen in the early
105.329|4.86|visual cortex areas of a cat and so they
108.509|4.051|had cat and they plugged in electrodes
110.189|4.261|that could record from the different
112.56|3.72|neurons and then they showed the cat
114.45|3.269|different patterns of light and they
116.28|2.85|were trying to debug a neurons
117.719|2.671|effectively and try to show them
119.13|3.029|different patterns and see what they
120.39|4.92|responded to and a lot of these
122.159|5.07|experiments inspired some of the
125.31|3.27|modeling that came in afterwards so in
127.229|2.67|particular one of the early models that
128.58|4.499|try to take advantage of some of the
129.899|5.611|results of these experiments where the
133.079|4.8|was the model called Newark cockney
135.51|4.17|truant from Fukushima in 1980s and so
137.879|3.36|what you saw here was these this
139.68|3.24|architecture that again is layer wise
141.239|3.511|similar to what you see in the cortex
142.92|3.899|where you have these simple and complex
144.75|4.5|cells where the simple cells detect
146.819|3.931|small things in the visual field and
149.25|3.48|then you have this local connectivity
150.75|3.84|pattern and the simple and complex cells
152.73|5.52|alternate in this layered architecture
154.59|4.83|throughout and so this was this looks a
158.25|2.519|bit like a comm net because you have
159.42|3.33|some of its features like say the local
160.769|3.39|connectivity but at the time this was
162.75|4.94|not trained with backpropagation these
164.159|6.39|were specific heuristic Allah chose in'
167.69|5.079|updates that and this was unsupervised
170.549|3.27|learning back then so the first time
172.769|2.161|that we've actually used back
173.819|3.09|propagation to train some of these
174.93|6.27|networks was an experiment of a young
176.909|5.97|lagoon in the 1990s and so this is an
181.2|3.36|example of one of the networks that was
182.879|3.841|developed back then in 1990s by anne
184.56|3.209|lagoon as lina at five and this is what
186.72|3.03|you would recognize today as a
187.769|3.81|convolutional neural network so it has a
189.75|4.349|lot of the very simple computational
191.579|4.41|layers and it's alternating and it's a
194.099|3.54|similar kind of design to what you would
195.989|3.33|see in the Fukushima's new york cognate
197.639|3.391|Ron but this was actually trained with
199.319|5.64|backpropagation and to end using
201.03|6.45|supervised learning now so this happened
204.959|6.301|in roughly 1990s and we're here in 2016
207.48|8.49|basically about 20 years later now
211.26|7.53|computer vision has has for a long time
215.97|4.229|kind of worked here on larger images and
218.79|3.449|a lot of these models back then were
220.199|5.611|applied to very small kind of settings
222.239|4.351|like say recognizing digits in zip codes
225.81|1.919|and things like that
226.59|3.179|and they were very successful in those
227.729|4.5|domains but back at least when I entered
229.769|3.96|computer vision roughly 2011 it was
232.229|2.91|thought that a lot of people were aware
233.729|4.141|of these models but it was thought that
235.139|5.371|they would not scale up naively into
237.87|4.289|large complex images that they would be
240.51|3.21|constrained to these toy tasks for a
242.159|2.97|long time or I shouldn't say toy because
243.72|2.79|these were very important tasks but
245.129|4.26|certainly like smaller visual
246.51|4.589|recognition problems and so in computer
249.389|3.901|vision in roughly 2011 it was much more
251.099|4.35|common to use a kind of these feature
253.29|3.809|based approaches at the time and they
255.449|3.51|didn't work essentially that well so
257.099|3.45|when I entered my PhD in 2011 working on
258.959|4.231|computer vision you would run a state of
260.549|5.531|the art object detector on this image
263.19|4.539|and you might get something like this
266.08|2.7|where cars were detected in trees and
267.729|2.761|you would kind of just shrug your
268.78|3.419|shoulders and say well that just happens
270.49|4.37|sometimes you kind of just accept it as
272.199|4.74|a as a something that would just happen
274.86|3.429|and of course this is a caricature
276.939|3.66|things actually worked like relatively
278.289|3.571|decent I should say but definitely there
280.599|4.59|were many mistakes that you would not
281.86|5.82|see today about four years nian 2016
285.189|3.871|five years later and so a lot of
287.68|2.94|computer vision kind of looked much more
289.06|3.419|like this when you look into a paper of
290.62|3.299|trying that try to do image
292.479|2.851|classification you would find this
293.919|4.231|section in the paper on the features
295.33|6.78|that they used so this is one page of
298.15|6.72|features and so they would use yeah a
302.11|4.38|gist hog etc and then the second page of
304.87|3.299|features and all their hyper parameters
306.49|3.359|so all kinds of different histograms and
308.169|4.47|you would extract this kitchen sink of
309.849|4.921|features and a third page here and so
312.639|3.75|you end up with this very large complex
314.77|3.449|code base because some of these feature
316.389|3.571|types are implemented in MATLAB some of
318.219|3.091|them in Python some of them in C++ and
319.96|2.91|you end up with this large code base of
321.31|3.15|extracting all these features caching
322.87|3.09|them and then eventually plugging them
324.46|3.569|into linear classifiers to do some kind
325.96|6.12|of visual recognition tasks so it was
328.029|5.79|quite unwieldy but it worked to some
332.08|3.329|extent but they were definitely a room
333.819|4.53|for improvement and so a lot of this
335.409|4.681|change in computer vision in 2012 with
338.349|2.91|this paper from Astrid chef Sookie Ilya
340.09|3.93|sutskever and Geoff Hinton
341.259|4.56|so this is the first time that someone
344.02|3.78|took a convolutional neural network that
345.819|4.44|is very similar to the one that you saw
347.8|4.039|in from 1998 from Jana Kuhn and I'll go
350.259|4.141|into details of how they defer exactly
351.839|4.33|but they took that kind of network they
354.4|2.759|scaled it up they made it much bigger
356.169|3.271|and they trained it on a much bigger
357.159|4.051|data set on GPUs and things basically
359.44|3.0|ended up working extremely well and this
361.21|2.699|is the first time the computer vision
362.44|3.899|community has really noticed these
363.909|6.0|models and adopted them to work on
366.339|5.911|larger images so we saw that the
369.909|4.47|performance of these models has improved
372.25|5.219|drastically here we are looking at the
374.379|5.22|image net eyeless VRC visual recognition
377.469|3.931|challenge over the years and we're
379.599|4.53|looking at the top 5 error so low is
381.4|4.68|good and you can see that from 2010 in
384.129|3.66|the beginning these were feature based
386.08|3.929|methods and then in 2012 we had this
387.789|4.41|huge jump in performance and that was
390.009|4.231|due to the first kind of convolutional
392.199|3.571|neural network in 2012 and then we've
394.24|4.799|managed to push that over time and now
395.77|4.26|we're down to about 3.5 7% I think the
399.039|3.121|results for image 2
400.03|4.59|thousand imagenet challenge 2016 are
402.16|3.72|actually due to come out today but I
404.62|3.48|don't think that actually they've come
405.88|6.51|out yet I have this second tab here
408.1|7.11|opened I was waiting for the result but
412.39|3.65|I don't think this is a Pia tiah okay no
415.21|3.03|nothing
416.04|4.66|alright well we'll get to find out very
418.24|5.13|soon what happens right here so I'm very
420.7|3.87|excited to see that just to put this in
423.37|2.46|context by the way because you're just
424.57|3.18|looking at numbers like three point five
425.83|2.7|seven how good is that that's actually
427.75|2.79|really really good
428.53|4.68|so what something that I did about two
430.54|4.38|years ago now now is that I try to
433.21|4.29|measure the human accuracy on this data
434.92|4.35|set and so what I did for that is I
437.5|4.23|developed this web interface where I
439.27|3.99|would show myself image net images from
441.73|4.35|the test set and then I had this
443.26|3.84|interface here where I would have all
446.08|3.12|the different classes of image net
447.1|4.47|there's 1,000 of them and some example
449.2|3.72|images and then basically you go down
451.57|3.6|this list and you scroll for a long time
452.92|3.81|and you find what class you think that
455.17|4.68|image might be and then I competed
456.73|8.58|against the ComNet at the time and this
459.85|6.99|was Google net in 2000 in 2014 and so
465.31|3.72|hot dog is a very simple class you can
466.84|4.26|do that quite easily but why is the
469.03|4.14|accuracy not 0% it well some of the
471.1|3.99|things like hot dog seems very easy why
473.17|3.03|isn't it trivial for humans to see well
475.09|2.61|it turns out that some of the images in
476.2|3.84|a test set of image net are actually
477.7|4.74|mislabeled but also some of the images
480.04|3.69|are just very difficult to guess so in
482.44|3.0|particular if you have this Terrier
483.73|3.27|there's 50 different types of terriers
485.44|3.6|and it turns out to be very difficult
487.0|3.93|task to find exactly which type of
489.04|4.11|Terrier that is you can spend minutes
490.93|3.33|trying to find it turns out that good
493.15|3.18|convolutional neural networks are
494.26|3.42|actually extremely good at this and so
496.33|4.8|this is where I would lose points
497.68|4.95|compared to ComNet so I estimate that
501.13|3.09|human accuracy based on this is roughly
502.63|3.54|2 to 5 percent range depending on how
504.22|3.21|much time you have and how much
506.17|3.0|expertise you have and how many people
507.43|3.6|you involve and how much they really
509.17|4.83|want to do this which is not too much
511.03|5.43|and so really we're doing extremely well
514.0|4.62|and so we're down to 3 percent and I
516.46|4.59|think the error rate if I remember
518.62|4.2|correctly was about 1.5 percent so if we
521.05|4.44|get below 1.5 percent I would be
522.82|5.25|extremely suspicious on image net that
525.49|6.85|seems wrong so to summarize basically
528.07|5.86|what we've done is before 2012 computer
532.34|3.33|somewhat like this where we had these
533.93|3.57|feature extractors and then we trained a
535.67|4.56|small portion at the end of the feature
537.5|4.35|extractor extraction step and so we only
540.23|3.6|trained this last piece on top of these
541.85|3.36|features that were fixed and we
543.83|3.0|basically replaced the feature extractor
545.21|3.15|in step with a single convolutional
546.83|2.97|neural network and now we trained
548.36|3.3|everything completely end-to-end and
549.8|3.75|this turns out to work quite nicely so
551.66|4.38|I'm going to go into details of how this
553.55|5.31|works in a bit also in terms of code
556.04|4.22|complexity we kind of went from a setup
558.86|4.83|that looks whoops
560.26|5.23|way ahead okay we went from a setup that
563.69|3.6|looks something like that and papers to
565.49|3.57|something like you know instead of
567.29|3.36|extracting all these things we just say
569.06|3.029|applied 20 layers with three by three
570.65|3.48|column or something like that and things
572.089|3.421|work quite well this is of course an
574.13|2.91|over-exaggeration but I think it's a
575.51|4.17|correct first order statement to make is
577.04|4.41|that we've definitely seen that we've
579.68|3.0|reduced code complexity quite a lot
581.45|3.18|because these architectures are so
582.68|5.19|homogeneous compared to what we've done
584.63|5.07|before so it's also remarkable that so
587.87|3.57|we had this reduction in complexity we
589.7|3.27|had this amazing performance on imagenet
591.44|4.2|one other thing that was quite amazing
592.97|4.11|about the results in 2012 that is also a
595.64|3.9|separate thing that did not have to be
597.08|4.259|the case is that the features that you
599.54|3.06|learn by training on image that turned
601.339|3.301|out to be quite generic and you can
602.6|4.56|apply them in different settings so in
604.64|4.199|other words this transfer learning works
607.16|2.91|extremely well and of course I didn't go
608.839|3.331|into details of convolutional networks
610.07|3.51|yet but we start with an image and we
612.17|2.94|have a sequence of layers just like in a
613.58|4.08|normal neural network and at the end we
615.11|4.5|have a classifier and when you pre train
617.66|3.36|this network on image net then it turns
619.61|3.51|out that the features that you learn in
621.02|3.69|the middle are actually transferable and
623.12|3.33|you can use them on different data sets
624.71|3.57|and that this works extremely well and
626.45|3.51|so that didn't have to be the case you
628.28|2.58|might imagine that you could have a
629.96|2.55|convolutional network that works
630.86|3.33|extremely well on image net but when you
632.51|3.15|try to run it on some something else
634.19|3.149|like birds data set or something that it
635.66|3.15|might just not work well but that is not
637.339|4.801|the case and that's a very interesting
638.81|5.73|finding in my opinion so people notice
642.14|4.14|this back in roughly 2013 after the
644.54|3.27|first convolution networks they noticed
646.28|3.39|that you can actually take many computer
647.81|3.09|vision datasets and it used to be that
649.67|2.64|you would compete on all of these kind
650.9|3.39|of separately and design features maybe
652.31|4.23|for some of these separately and you can
654.29|4.739|just shortcut all those steps that we
656.54|4.23|had designed and you can just take these
659.029|3.691|pre trained features that you get from
660.77|3.39|imagenet and you can just train a linear
662.72|2.96|classifier on every single data set on
664.16|3.08|top of those features and you up
665.68|3.81|many state-of-the-art results across
667.24|4.26|many different data sets and so this was
669.49|4.409|quite a remarkable finding back then I
671.5|4.14|believe so things worked very well an
673.899|4.051|image net Thanks transferred very well
675.64|5.04|and the code complexity of course got
677.95|4.38|much much more manageable so now all
680.68|3.42|this power is actually available to you
682.33|4.08|with very few lines of code if you want
684.1|3.929|to just use a convolutional network on
686.41|2.85|images it turns out to be only a few
688.029|3.12|lines of code if you use for example
689.26|3.48|Karis is one of the deep learning
691.149|4.141|libraries that I'm going to go into and
692.74|4.17|I'll mention again later in the talk but
695.29|3.48|basically just load a state-of-the-art
696.91|3.53|complex all neural network you take an
698.77|4.05|image you load it and you compute your
700.44|4.36|predictions and it tells you that this
702.82|4.53|is an African elephant inside that image
704.8|3.84|and this took a couple couple hundred or
707.35|3.48|a couple ten milliseconds if you have a
708.64|4.08|GPU and so everything does much faster
710.83|3.449|much simpler works really well transfers
712.72|3.57|really well so this was really a huge
714.279|3.391|advance in computer vision and so as a
716.29|3.93|result of all these nice properties
717.67|5.43|commnets today are everywhere so here's
720.22|5.28|a collection of some of the some of the
723.1|4.38|things I try to find across across
725.5|3.149|different applications so for example
727.48|4.049|you can search google photos for
728.649|5.671|different types of categories like in
731.529|4.951|this case rubik's cube you can find
734.32|3.78|house numbers very efficiently you can
736.48|2.7|of course this is very relevant in
738.1|3.03|self-driving cars and we're doing
739.18|3.0|perception in the cars accomplishable
741.13|3.149|networks are very relevant they're
742.18|4.26|medical image diagnosis recognizing
744.279|5.371|Chinese characters doing all kinds of
746.44|5.37|medical segmentation tasks quite random
749.65|3.89|tasks like wail recognition and more
751.81|4.11|generally many tackle challenges
753.54|4.36|satellite image analysis recognizing
755.92|5.01|different types of galaxies you may have
757.9|4.68|seen recently that a wave net from
760.93|3.779|deepmind also very interesting paper
762.58|4.14|that they generate music and they
764.709|3.75|generate speech and so this is a
766.72|2.97|generative model and that's also just a
768.459|2.82|comm that is doing most of the heavy
769.69|5.16|lifting here so it's a convolutional
771.279|5.761|network on top of sound and other tasks
774.85|3.929|like image captioning in the context of
777.04|3.84|reinforcement learning and agent in
778.779|3.841|environment interactions we've also seen
780.88|3.78|a lot of advances of using commnets as
782.62|3.45|the core computational building block so
784.66|3.45|when you want to play Atari games or you
786.07|4.259|want to play alphago or doom or
788.11|3.78|Starcraft or if you want to get robots
790.329|3.781|to perform interesting manipulation
791.89|4.21|tasks all of this users come that's as a
794.11|5.65|core computational
796.1|5.28|block to do very impressive things not
799.76|3.27|only are we using it for a lot of
801.38|5.79|different application we're also finding
803.03|6.08|uses in art so so here are some examples
807.17|3.84|from deep dreams so you can basically
809.11|4.45|simulate what it looks like what it
811.01|4.5|feels like maybe to be on some drugs so
813.56|3.3|you can take images and you can just
815.51|2.94|loosen it features these income that's
816.86|3.0|or you might be familiar with neural
818.45|3.63|style which allows you to take arbitrary
819.86|4.02|images and transfer arbitrary styles of
822.08|3.15|different paintings like Van Gogh on top
823.88|3.18|of them and this is all using
825.23|3.42|convolutional networks the last thing
827.06|3.66|I'd like to note that I find also
828.65|4.32|interesting is that in the process of
830.72|3.96|trying to develop better computer vision
832.97|3.66|architectures and trying to basically
834.68|3.66|optimize for performance on the image
836.63|3.57|net challenge we've actually ended up
838.34|3.27|converging to something that potentially
840.2|3.66|might function something like your
841.61|3.6|visual cortex in some ways and so these
843.86|2.4|are some of the experiments that I find
845.21|4.89|interesting where they've studied
846.26|6.84|macaque monkeys and they record from a
850.1|4.47|subpopulation of the of the i.t cortex
853.1|3.9|this is the part that does a lot of
854.57|3.6|object recognition and so they record so
857.0|2.64|basically they take a monkey and they
858.17|3.6|take a ComNet and they show them images
859.64|4.2|and then you look at what those images
861.77|3.69|are represented at the end of this
863.84|3.21|network so inside the monkey's brain or
865.46|3.36|on top of your convolutional network as
867.05|3.27|we look at representations of different
868.82|3.06|images and then it turns out that
870.32|3.75|there's a mapping between those two
871.88|4.08|spaces that actually seems to indicate
874.07|3.72|to some extent that some of the things
875.96|3.09|we're doing somehow ended up converging
877.79|4.32|to something that the brain could be
879.05|5.1|doing as well in the visual cortex so
882.11|3.51|that's just some intro I'm now going to
884.15|4.59|dive into convolutional networks and try
885.62|5.22|to explain the briefly how these
888.74|3.75|networks work of course there's an
890.84|3.39|entire class on this that I taught which
892.49|3.57|is a convolutional networks class and so
894.23|3.78|I'm going to distill some of you know
896.06|3.96|those 13 lectures into one lecture so
898.01|2.79|we'll see how that goes I won't cover
900.02|4.2|everything of course
900.8|5.91|okay so convolutional neural network is
904.22|4.44|really just a single function it goes
906.71|4.35|from it's a function from the raw pixels
908.66|4.95|of some kind of an image so we take 224
911.06|4.65|by 224 by 3 image so 3 here is for the
913.61|3.72|color channels RGB you take the raw
915.71|3.36|pixels you put it through this function
917.33|3.48|and you get 1000 numbers at the end in
919.07|3.36|the case of image classification if
920.81|4.2|you're trying to categorize images into
922.43|4.38|1000 different classes and really
925.01|3.18|functionally all that's happening in a
926.81|2.15|convolutional net work is just dot
928.19|2.93|products
928.96|4.14|and max operations that's everything but
931.12|3.63|they're wired up together in interesting
933.1|4.59|ways so that you are basically doing
934.75|5.58|visual recognition and in particular the
937.69|4.56|this function f has a lot of knobs in it
940.33|3.0|so these w's here that participate in
942.25|2.7|these dot products and in these
943.33|4.08|convolutions and fully connected layers
944.95|4.14|and so on these WS are all parameters of
947.41|3.0|this network so normally you might have
949.09|4.02|about on the order of 10 million
950.41|6.0|parameters and those are basically knobs
953.11|4.98|that change this function and so we'd
956.41|3.78|like to change those knobs of course so
958.09|3.9|that when you put images through that
960.19|3.45|function you get probabilities that are
961.99|4.44|consistent with your training data and
963.64|3.9|so that gives us a lot to tune and turns
966.43|2.13|out that we can do that tuning
967.54|4.68|automatically with back propagation
968.56|5.16|through that search process now more
972.22|3.63|concretely accomplish on your network is
973.72|3.9|made up of a sequence of layers just as
975.85|3.12|in a case of normal neural networks but
977.62|3.48|we have different types of layers that
978.97|3.9|we play with so we have convolutional
981.1|4.43|layers here I'm using rectified linear
982.87|5.1|unit relu for short as a non-linearity
985.53|3.67|so I'm making that and explicit its own
987.97|3.24|layer
989.2|4.08|pooling layers and fully connected
991.21|3.33|layers the core computational building
993.28|3.81|block of a convolutional network though
994.54|4.32|is this convolutional layer and we have
997.09|3.15|nonlinearities interspersed we are
998.86|2.76|probably getting rid of things like
1000.24|3.33|pooling layers we might see them
1001.62|3.03|slightly going away over time and fully
1003.57|2.4|connected layers can actually be
1004.65|2.76|represented there are basically
1005.97|4.02|equivalent to convolutional layers as
1007.41|5.22|well and so really it's just a sequence
1009.99|3.96|of complex in the simplest case so let
1012.63|2.64|me explain convolutional layer because
1013.95|2.91|that's the core computational building
1015.27|6.48|block here that does all the heavy
1016.86|6.45|lifting so the entire comm that is this
1021.75|3.87|collection of layers and these layers
1023.31|3.66|don't function over vectors so they
1025.62|2.67|don't transform vectors as a normal
1026.97|4.23|neural network but they function over
1028.29|4.44|volumes so a layer will take a volume a
1031.2|3.66|three-dimensional volume of numbers an
1032.73|4.859|array in this case for example we have a
1034.86|4.41|32 by 32 by 3 image so those three
1037.589|3.631|dimensions are the width height and I'll
1039.27|4.02|refer to the third dimension as depth we
1041.22|3.42|have three channels that's not to be
1043.29|2.76|confused with the depth of a network
1044.64|2.85|which is the number of layers in that
1046.05|4.11|network so this is just depth of a
1047.49|4.26|volume so this complex layer accepts a
1050.16|3.36|three dimensional volume and it produces
1051.75|3.93|a three dimensional volume using some
1053.52|4.26|weights so the way it actually produces
1055.68|3.36|this output volume is as follows we're
1057.78|2.07|going to have these filters in a
1059.04|3.63|convolutional layer
1059.85|4.38|so these filters are always small
1062.67|4.23|patiently like say for example five by
1064.23|5.04|five filter but their depth extends
1066.9|5.43|always through the input depth of the
1069.27|5.85|input volume so since the input volume
1072.33|4.5|has three channels the depth is 3 then
1075.12|4.35|our filters will always match that
1076.83|4.68|number so we have depth of 3 in our
1079.47|3.21|filters as well and then we can take
1081.51|3.39|those filters and we can basically
1082.68|4.65|convolve them with the input volume so
1084.9|5.43|what that amounts to is we take this
1087.33|4.98|filter oh yeah so that's just the point
1090.33|4.08|that the channels here must match we
1092.31|3.54|take that filter and we slide it through
1094.41|3.15|all spatial positions of the input
1095.85|3.24|volume and along the way as we're
1097.56|4.59|sliding this filter we're computing dot
1099.09|5.28|products so W transpose X plus B where W
1102.15|4.35|are the filters and X is a small piece
1104.37|3.81|of the input volume and B is offset and
1106.5|3.21|so this is basically the convolutional
1108.18|2.82|operation you're taking this filter and
1109.71|2.91|you're sliding it through at all spatial
1111.0|3.93|positions and you're computing that
1112.62|4.89|products so when you do this you end up
1114.93|5.76|with this activation map so in this case
1117.51|5.28|we get a 28 by 28 activate activation
1120.69|4.08|map 28 comes from the fact that there
1122.79|6.69|are 28 unique positions to place this
1124.77|6.39|5x5 filter into this 3 32 by 32 space so
1129.48|3.36|there are 28 by 28 unique positions you
1131.16|2.97|can place that filter in and every one
1132.84|4.41|of those you're going to get a single
1134.13|7.29|number of how well that filter alikes
1137.25|6.57|that part of the input so that carves
1141.42|3.51|out a single activation map and now in a
1143.82|2.34|compositional layer we don't just have a
1144.93|3.21|single filter but we're going to have an
1146.16|3.84|entire set of filters so here's another
1148.14|3.81|filter a green filter we're going to
1150.0|4.74|slide it through the input volume it has
1151.95|4.92|its own parameters so these there are 75
1154.74|4.38|numbers here that basically make up a
1156.87|3.3|filter there are different 75 numbers we
1159.12|3.0|convolve them through get a new
1160.17|3.48|activation map and we continue doing
1162.12|3.63|this for all the filters in that
1163.65|4.11|convolutional layer so for example if we
1165.75|4.49|had six filters in this convolutional
1167.76|5.1|layer then we might end up with 28 by 28
1170.24|4.48|activation maps six times and we stock
1172.86|4.2|them along the depth dimension to arrive
1174.72|4.38|at the output volume of 28 by 28 by 6
1177.06|4.08|and so really what we've done is we've
1179.1|4.71|we represented the original image which
1181.14|6.81|is 32 by 32 by 3 into a kind of a new
1183.81|5.76|image that is 28 by 28 by 6 where this
1187.95|3.87|image basically has these 6 channels
1189.57|6.46|that tell you how well every filter
1191.82|7.099|matches or likes every part of the input
1196.03|4.6|so let's compare this operation to say
1198.919|3.14|using fully connected layer as you would
1200.63|4.23|in a normal neural network
1202.059|5.23|so in particular we saw that we process
1204.86|6.03|the 32 by 32 by 3 volume into 28 by 28
1207.289|5.37|by 6 volume and one question might want
1210.89|3.75|to ask is how many parameters would this
1212.659|3.601|require if we wanted a fully connected
1214.64|4.23|layer of the same number of output
1216.26|5.399|neurons here so we wanted 28 by 28 by 6
1218.87|5.22|or times 20 times when it's 12 times 28
1221.659|4.051|times 6 number of neurons fully
1224.09|3.48|connected how many parameters would that
1225.71|3.42|be turns out that that would be quite a
1227.57|3.359|few parameters right because every
1229.13|3.6|single neuron in the output volume would
1230.929|5.521|be fully connected to all of the 32 by
1232.73|5.49|32 by 3 numbers here so basically every
1236.45|4.229|one of those - 28 by 28 by 6 now
1238.22|4.53|Newell's is connected to 32 by 3 2 by 3
1240.679|4.23|turns out to be about 15 million
1242.75|3.63|parameters and also on that order of
1244.909|2.941|number of multiplies so you're doing a
1246.38|2.82|lot of compute and you're introducing a
1247.85|3.66|huge amount of parameters into your
1249.2|4.94|network now since we're doing
1251.51|4.59|convolution instead you'll notice that
1254.14|3.31|think about a number of parameters that
1256.1|5.61|we've introduced with this example
1257.45|6.81|convolutional layer so we've used we had
1261.71|5.339|6 filters and every one of them was a 5
1264.26|4.74|by 5 by 3 filter so basically we just
1267.049|3.601|have 5 by 5 by 3 filters we have 6 of
1269.0|3.96|them if you just multiply that out we
1270.65|3.659|have 450 parameters and in this I'm not
1272.96|3.599|counting the biases I'm just counting
1274.309|4.021|the raw weights so compared to 15
1276.559|4.711|million we've only introduced very few
1278.33|4.469|parameters also how many multiplies have
1281.27|1.98|we done so computationally how many
1282.799|2.971|flops
1283.25|4.02|are we doing well we have twenty by
1285.77|3.48|twenty eight by six outputs to produce
1287.27|3.69|and every one of these numbers is a
1289.25|3.419|function of a five by five by three
1290.96|5.25|region in the original image so
1292.669|4.921|basically we have 20 by 20 by 6 and then
1296.21|3.69|there's every one of them is computed by
1297.59|3.44|doing 5 times 5 times 3 multiplies so
1299.9|4.98|you end up with only on the order of
1301.03|5.95|350,000 multiplies so we've reduced from
1304.88|3.779|15 million to quite a few so we're doing
1306.98|3.96|less flops and we're using fewer
1308.659|4.441|parameters and really what we've done
1310.94|4.55|here is we've made assumptions right so
1313.1|4.86|we've made the assumption that because
1315.49|3.85|the fully connected layer if this wasn't
1317.96|4.5|fully connected layer could compute the
1319.34|4.559|exact same thing but it would so
1322.46|2.88|specific setting of those 15 million
1323.899|2.881|parameters would actually produce the
1325.34|2.969|exact output of this convolutional layer
1326.78|2.34|but we've done it much more efficiently
1328.309|3.991|we've done that by
1329.12|5.13|reducing these biases so in particular
1332.3|3.24|we've made assumptions we've assumed for
1334.25|3.059|example that since we have these fixed
1335.54|3.6|filters that we're sliding across space
1337.309|3.061|we've assumed that if there's some
1339.14|2.88|interesting feature that you'd like to
1340.37|3.6|detect in one part of the image like say
1342.02|3.33|top left then that feature will also be
1343.97|3.42|useful somewhere else like on the bottom
1345.35|3.66|right because we fix these filters and
1347.39|3.66|apply them at all the spatial positions
1349.01|3.81|equally you might notice that this is
1351.05|3.33|not always something that you might want
1352.82|3.72|for example if you're getting inputs
1354.38|3.12|that are centered face images and you're
1356.54|2.91|doing some kind of a face recognition
1357.5|3.42|isn't like that then you might expect
1359.45|3.45|that you might want different filters at
1360.92|3.87|different spatial positions like say for
1362.9|3.659|I region so you might want to have some
1364.79|3.33|I like filters and for math region you
1366.559|3.181|might want to have mouth specific
1368.12|2.88|features and so on and so in that case
1369.74|3.0|you might not want to use convolutional
1371.0|3.42|layer because those features have to be
1372.74|4.53|shared across all spatial positions and
1374.42|5.13|the second assumptions that we made is
1377.27|4.38|that these filters are small locally and
1379.55|3.69|so we don't have global connectivity we
1381.65|3.21|have this local connectivity but that's
1383.24|3.78|okay because we end up stacking up these
1384.86|4.44|convolutional layers in sequence and so
1387.02|4.35|this the neurons at the end of the
1389.3|3.69|ComNet will grow their receptive field
1391.37|3.21|as you stack these convolutional layers
1392.99|3.0|on top of each other so at the end of
1394.58|3.62|the combat those neurons end up being a
1395.99|4.23|function of the entire image eventually
1398.2|3.79|so just to give an idea about what these
1400.22|4.17|activation maps look like concretely
1401.99|4.2|here's an example of an image on the top
1404.39|3.539|left this is a part of a car I believe
1406.19|3.9|and we have these different filters at
1407.929|4.111|we have 32 different small filters here
1410.09|3.48|and so if we were to convolve these
1412.04|4.11|filters with this image we end up with
1413.57|4.17|these activation labs so this filter if
1416.15|3.3|you convolve it you get this activation
1417.74|3.569|lab and so on so this one for example
1419.45|3.479|has some orange stuff in it so when we
1421.309|3.721|convolve with this image you see that
1422.929|3.661|this white here is denying the fact that
1425.03|3.3|that filter matches that part of the
1426.59|3.719|image quite well and so we get these
1428.33|3.51|activation maps you stack them up and
1430.309|4.201|then that goes into the next
1431.84|4.95|convolutional layer so the way this
1434.51|4.86|looks then looks like then is that we
1436.79|3.81|processed this with some kind of a
1439.37|3.84|convolutional layer we get some output
1440.6|4.23|we apply a rectified linear units some
1443.21|3.24|kind of a non-linearity as normal and
1444.83|4.8|then we would just repeat that operation
1446.45|5.34|so we keep plugging these values into
1449.63|4.29|the next convolutional layer and so they
1451.79|3.54|plug into each other in sequence okay
1453.92|4.23|and so we end up processing the image
1455.33|4.5|over time so that's the convolutional
1458.15|3.42|layer and you'll notice that there are a
1459.83|2.97|few more layers so in particular the
1461.57|5.19|pooling layer i'll explain very
1462.8|5.88|briefly pooling layer is quite simple if
1466.76|3.03|you've used Photoshop or something like
1468.68|3.27|that you've taken a large image and
1469.79|2.52|you've resized it you downsampled the
1471.95|2.28|image
1472.31|3.81|well pulling layers do basically
1474.23|3.12|something exactly like that but they're
1476.12|3.84|doing it on every single channel
1477.35|4.86|independently so for every one of these
1479.96|4.89|channels independently in a input volume
1482.21|4.65|will pluck out that activation lab will
1484.85|4.08|down sample it and that becomes a
1486.86|4.29|channel in the output volume so it's
1488.93|4.65|really down sampling operation on these
1491.15|3.75|volumes so for example one of the common
1493.58|2.73|ways of doing this in the context of
1494.9|3.6|neural networks especially is to use
1496.31|3.48|maximum operation so in this case it
1498.5|5.64|would be common to say for example use
1499.79|7.02|two by two filters stride to so and do
1504.14|4.83|max operation so if this is an input
1506.81|4.62|channel in a volume then we're basically
1508.97|4.02|what that amounts to is we're truncating
1511.43|4.14|it into these two by two regions and
1512.99|5.91|we're taking a max over four numbers to
1515.57|4.89|produce one piece of the output okay so
1518.9|3.42|this is a very cheap operation that down
1520.46|3.03|samples your volumes it's really a way
1522.32|2.82|to control the capacity of the network
1523.49|2.28|so you don't want too many numbers you
1525.14|2.55|don't want things to be too
1525.77|4.02|computationally expensive it turns out
1527.69|3.48|that a pooling layer allows you to down
1529.79|3.3|sample your volumes you're going to end
1531.17|3.48|up doing less computation and it turns
1533.09|3.99|out to not hurt the performance too much
1534.65|3.51|so we use them basically as a way of
1537.08|4.65|controlling the capacity of these
1538.16|4.56|networks and the last layer that I want
1541.73|2.49|to briefly mention of course is the
1542.72|3.63|fully connected layer which is exactly
1544.22|3.87|as what you're familiar with so we have
1546.35|3.21|these volumes throughout as we process
1548.09|2.61|the image at the end you're left with
1549.56|3.0|this volume and now you'd like to
1550.7|3.78|predict some classes so we do is we just
1552.56|3.72|take that volume we stretch it out into
1554.48|3.21|a single column and then we apply for
1556.28|2.52|the connected layer which is really
1557.69|4.53|amounts to just a matrix multiplication
1558.8|5.25|and then that gives us probabilities
1562.22|3.02|after applying like a soft Max or
1564.05|4.14|something like that
1565.24|4.15|so let me now show you briefly a demo of
1568.19|5.4|what the convolutional Network looks
1569.39|5.79|like so this is common nsj this is a
1573.59|2.91|deep learning library for training
1575.18|3.0|convolutional neural networks that I've
1576.5|4.02|that is implemented in JavaScript I
1578.18|4.17|wrote this maybe two years ago at this
1580.52|3.36|point so here what we're doing is we're
1582.35|4.11|training a convolutional network on the
1583.88|5.67|c 410 dataset see 410 is a data set of
1586.46|5.1|50,000 images each image is 32 by 32 by
1589.55|4.38|3 and there are different ten different
1591.56|4.08|classes so here we are training this
1593.93|4.14|network in the browser and you can
1595.64|4.17|the loss is decreasing which means that
1598.07|5.1|we're better classifying these inputs
1599.81|4.65|and so here's the network specification
1603.17|2.61|which you can play with because this is
1604.46|3.78|all done in the browser so you can just
1605.78|4.14|change this and play with this so this
1608.24|3.66|is an input image and this convolutional
1609.92|3.45|network I'm showing here all the
1611.9|4.56|intermediate activations and all the
1613.37|4.8|intermediate basically activation maps
1616.46|2.82|that we're producing so here we have a
1618.17|2.7|set of filters
1619.28|3.69|we're convolving them with the image and
1620.87|3.6|getting all these activation maps I'm
1622.97|3.69|also showing the gradients but I don't
1624.47|5.07|want to dwell on that too much then your
1626.66|5.31|threshold so rel will do anything below
1629.54|4.29|zero gets clamped at zero and then you
1631.97|4.25|pull so this is just down sampling
1633.83|6.0|operation and then another convolution
1636.22|4.75|relu pool compre loophole etc until at
1639.83|3.36|the end we have a fully connected layer
1640.97|4.05|and then we have our soft max so that we
1643.19|3.72|get probabilities out and then we apply
1645.02|4.14|a loss to those probabilities and back
1646.91|3.78|propagate and so here we see that I've
1649.16|4.23|been training in this tab for the last
1650.69|3.87|maybe 30 seconds or one minute and we're
1653.39|3.63|already getting about 30 percent
1654.56|4.14|accuracy on C for ten so this these are
1657.02|2.85|test images from C for ten and these are
1658.7|2.73|the outputs of this compositional
1659.87|3.15|network and you can see that it learned
1661.43|2.82|that this is already a car or something
1663.02|3.93|like that so this trains pretty quickly
1664.25|5.06|in JavaScript so you can play with this
1666.95|4.38|and continue the architecture and so on
1669.31|3.91|another thing I'd like to show you is
1671.33|3.45|this video because it gives you again
1673.22|2.79|this like very intuitive visceral
1674.78|3.12|feeling of exactly what this is
1676.01|4.77|computing is there's a very good video
1677.9|4.89|by Jason Kaczynski from recent advance
1680.78|4.68|I'm going to play this in a bit this is
1682.79|3.84|from the deep visualization tool box so
1685.46|3.0|you can download this code and you can
1686.63|3.81|play with this it's this interactive
1688.46|3.75|convolutional network demo this is
1690.44|3.23|neural networks have enabled computers
1692.21|4.14|to better see and understand the world
1693.67|4.72|they can recognize good buses and zip
1696.35|4.17|top left corner we showed you in this
1698.39|3.87|case kappa hi Daddy so what we're seeing
1700.52|5.01|here is these are activation laps in
1702.26|6.09|some particular shown in real time as
1705.53|4.86|this demo is running so these are for
1708.35|3.12|the calm one layer of an Alex net which
1710.39|2.49|we're going to go into in much more
1711.47|3.0|detail but these are the different
1712.88|4.71|activation maps that are being produced
1714.47|5.97|at this point neural network called Alex
1717.59|4.17|net running in cafe by interacting with
1720.44|3.25|the network we can see what some of the
1721.76|5.03|neurons
1723.69|4.78|for example on this first leg the unit
1726.79|5.67|in the center responds strongly to light
1728.47|6.09|to dark edges its neighbor one neuron
1732.46|6.12|over responds to edges in the opposite
1734.56|5.85|direction dark to light using
1738.58|3.39|optimization we can synthetically
1740.41|3.27|produce images that light up each neuron
1741.97|4.17|on this layer to see what each neuron is
1743.68|4.26|looking for we can scroll through every
1746.14|4.07|layer in the network to see what it does
1747.94|5.55|including convolution pooling and
1750.21|4.78|normalization layers we can switch back
1753.49|3.21|and forth between showing the actual
1754.99|5.6|activations and showing images
1756.7|3.89|synthesized to produce high activation
1761.52|3.76|but the time you get to the fifth
1763.39|6.21|convolutional layer the features being
1765.28|6.39|computed represent abstract concepts for
1769.6|4.17|example this neuron seems to respond to
1771.67|3.39|phases we can further investigate this
1773.77|3.78|neuron by showing a few different types
1775.06|4.32|of information first we can artificially
1777.55|3.42|create optimized images using new
1779.38|3.63|regularization techniques that are
1780.97|3.72|described in our paper these synthetic
1783.01|4.2|images show that this neuron fire is in
1784.69|3.84|response to a face and shoulders we can
1787.21|2.79|also plot the images from the training
1788.53|3.96|set that activate this neuron the most
1790.0|3.96|as well as pixels from those images most
1792.49|3.63|responsible for the high activations
1793.96|4.74|computed via the D combination technique
1796.12|5.1|this feature responds to multiple faces
1798.7|5.58|in different locations and by looking at
1801.22|4.65|the D cons we can see that it would
1804.28|4.35|respond more strongly if we had even
1805.87|4.32|darker eyes and rosy lips we can also
1808.63|3.57|confirm that it cares about the head and
1810.19|2.93|shoulders that ignores the arms and
1812.2|3.27|torso
1813.12|6.25|we can even see that it fires to some
1815.47|6.18|extent for cat faces using back prop or
1819.37|3.99|decom we can see that this unit depends
1821.65|4.08|most strongly on a couple units in the
1823.36|5.7|previous layer con four and on about a
1825.73|5.67|dozen or so in con 3 now let's look at
1829.06|5.34|another neuron on this layer so what's
1831.4|4.38|this unit doing from the top 9 images we
1834.4|3.96|might conclude that it fires 4 different
1835.78|4.2|types of clothing but examining the
1838.36|2.77|synthetic images shows that it may be
1839.98|4.3|detecting not clothing
1841.13|5.45|say but wrinkles in the live plot we can
1844.28|5.009|see that it's activated by my shirt and
1846.58|5.339|smoothing out half of my shirt causes
1849.289|5.811|that hack of the activations to decrease
1851.919|5.591|finally here's another interesting memo
1855.1|4.959|this one has learned to look for printed
1857.51|5.76|text in a variety of sizes colors and
1860.059|4.62|fonts this is pretty cool because we
1863.27|3.72|never asked the network to look for
1864.679|3.661|wrinkles or text or faces the only
1866.99|3.24|papers were provided were at the very
1868.34|3.39|last layer so the only reason the
1870.23|3.87|network learned features like text and
1871.73|5.1|faces in the middle was to support final
1874.1|4.5|decisions at that last layer for example
1876.83|4.38|the text detector may provide good
1878.6|4.8|evidence that a rectangle is in fact a
1881.21|4.11|book seen on edge and detecting many
1883.4|3.81|books next to each other might be a good
1885.32|3.359|way of detecting a bookcase which was
1887.21|5.16|one of the categories we trained the net
1888.679|5.191|to recognize in this video we've shown
1892.37|3.419|some of the features of the deep is
1893.87|4.23|toolbox okay so I encourage you to play
1895.789|3.601|with that it's really fun so I hope that
1898.1|2.34|gives you an idea about exactly what's
1899.39|2.7|going on there at these convolutional
1900.44|3.239|layers we downsample them from what from
1902.09|3.6|time to time there's usually some fully
1903.679|3.331|connected layers at the end but mostly
1905.69|3.989|it's just these convolutional operations
1907.01|4.23|stacked on top of each other so what I'd
1909.679|3.061|like to do now is I'll dive into some
1911.24|3.54|details of how these architectures are
1912.74|3.809|actually put together the way I'll do
1914.78|3.389|this is I'll go over all the winners of
1916.549|2.701|the imagenet challenges and I'll tell
1918.169|2.911|you about the architectures how they
1919.25|3.059|came about how they differ and so you'll
1921.08|3.27|get a concrete idea about what these
1922.309|3.631|architectures look like in practice so
1924.35|5.67|we'll start off with the Alex net in
1925.94|6.66|2012 so the Alex net just to give you an
1930.02|4.769|idea about the sizes of these networks
1932.6|5.579|and the images that they process it took
1934.789|5.27|to 27 by 220 7 by 3 images and the first
1938.179|3.901|layer of an Alex net for example was a
1940.059|4.87|completion layer that had 11 by 11
1942.08|5.76|filters applied with a stride of four
1944.929|4.561|and there are 96 of them stride of four
1947.84|3.959|I didn't fully explain because I wanted
1949.49|3.6|to save some time but intuitively it
1951.799|2.911|just means that as you're sliding this
1953.09|3.209|filter across the input you don't have
1954.71|3.18|to slide in one pixel at a time but you
1956.299|3.571|can actually jump a few pixels at a time
1957.89|5.19|so we have 11 by 11 filters with a
1959.87|4.95|stride a skip of four and we have 96 of
1963.08|3.36|them you can try to compute for example
1964.82|5.52|what is the output volume if you apply
1966.44|5.46|this this sort of convolutional layer on
1970.34|2.73|top of this volume and I didn't go into
1971.9|3.21|details of how you compute that
1973.07|3.75|but basically there are formulas for
1975.11|5.789|this and you can look into details in
1976.82|7.02|the class but you arrive at 55 by 55 by
1980.899|5.191|96 volume as output the total number of
1983.84|5.64|parameters in this layer we have 96
1986.09|6.38|filters every one of them is 11 by 11 by
1989.48|5.88|3 because that's the input depth of
1992.47|5.02|these images so basically just amounts
1995.36|4.23|to 11 but times 11 times 3 and then you
1997.49|5.309|have 96 filters so about 35,000
1999.59|4.62|parameters in this very first layer then
2002.799|4.23|the second layer of an Alex net is a
2004.21|4.74|pooling layer so we apply three by three
2007.029|4.14|filters at Stride of two and they do max
2008.95|4.439|pooling so you can again compute the
2011.169|4.171|output volume size of that after
2013.389|4.081|applying this to that volume and you
2015.34|4.38|arrive if you do some very simple
2017.47|3.99|arithmetic there you arrive at 27 by 27
2019.72|3.6|by 96 so this is the down sampling
2021.46|2.969|operation you can think about what is
2023.32|5.489|the number of parameters and this
2024.429|5.88|pooling layer and of course it's zero so
2028.809|3.811|pooling layers compute a fixed function
2030.309|3.691|fixed down sampling operation there are
2032.62|2.73|no parameters involved in pulling a
2034.0|2.519|layer all the parameters are in
2035.35|3.09|convolutional layers and the fully
2036.519|4.74|connected layers which are some extent
2038.44|4.92|equivalent to convolutional layers so
2041.259|3.571|you can go ahead and just basically
2043.36|3.12|based on the description in the paper
2044.83|3.0|although is non-trivial I think based on
2046.48|3.48|the description of this particular paper
2047.83|4.44|but you can go ahead and decipher what
2049.96|4.32|the volumes are throughout you can look
2052.27|4.26|at the kind of patterns that emerge in
2054.28|3.45|terms of how you actually increase
2056.53|3.0|number of filters in higher
2057.73|4.619|convolutional layers so we started off
2059.53|6.78|with 96 then we go to 256 filters then
2062.349|6.421|to 384 and eventually 4096 units click
2066.31|4.23|on layers you'll see also normalization
2068.77|3.54|layers here which have since become
2070.54|3.569|slightly deprecated it's not very common
2072.31|3.96|to use the normalization layers that
2074.109|4.05|were used at the time for the election
2076.27|4.379|architecture what's interesting to note
2078.159|4.47|is how this differs from the 1998 Iyanla
2080.649|4.23|cool network so in particular
2082.629|5.071|I usually like to think about for things
2084.879|5.24|that hold back progress so at least in a
2087.7|5.58|deep learning so the data is a
2090.119|4.51|constraint compute and then I like to
2093.28|3.329|differentially differentiate between
2094.629|3.361|algorithms and infrastructure algorithms
2096.609|2.73|being something that feels like research
2097.99|2.79|and infrastructure being something that
2099.339|3.211|feels like a lot of engineering has to
2100.78|3.93|happen and so in particular we've had
2102.55|3.99|progress in all those four fronts so we
2104.71|3.659|see that in 1998
2106.54|3.059|the data you could get ahold of maybe
2108.369|3.031|would be on the order of a few thousand
2109.599|3.451|whereas now we have a few million so we
2111.4|4.89|had three orders of magnitude of
2113.05|4.71|increase in number of data compute GPUs
2116.29|3.45|have become available and we use them to
2117.76|5.22|train these networks they are about say
2119.74|5.099|roughly 20 times faster than CPUs and
2122.98|3.57|then of course CPUs we have today are
2124.839|3.481|much much faster than CPUs that they
2126.55|3.09|have back in 1998 so I don't know
2128.32|2.549|exactly to what that works out to but I
2129.64|2.61|wouldn't be surprised if it's again on
2130.869|3.931|the order of three orders of magnitude
2132.25|3.869|of improvement again I'd like to
2134.8|2.64|actually skip over algorithm and talk
2136.119|4.441|about infrastructure so in this case
2137.44|4.56|we're talking about Nvidia releasing the
2140.56|2.94|cuda library that allows you to
2142.0|3.45|efficiently create all these matrix
2143.5|4.89|vector operations and apply them on
2145.45|4.8|arrays of numbers so that's a piece of
2148.39|3.36|software that you rely on and that we
2150.25|4.079|take advantage of that wasn't available
2151.75|3.9|before and finally algorithms is kind of
2154.329|3.5|an interesting one because there's been
2155.65|4.89|in those 20 years there's been much less
2157.829|4.631|improvement in an algorithms than all
2160.54|3.51|these other three pieces so in
2162.46|3.48|particular what we've done with the 1998
2164.05|3.66|network is we've made it bigger so you
2165.94|4.98|have more channels you have more layers
2167.71|6.09|by bit and the two really new things
2170.92|6.96|algorithmically are dropout and
2173.8|5.97|rectified linear units so dropout is a
2177.88|3.33|regularization technique developed by
2179.77|3.69|geoff hinton and colleagues and
2181.21|4.23|rectified linear units are these
2183.46|4.619|nonlinearities that train much faster
2185.44|5.22|than sigmoids and ten HS and this paper
2188.079|4.471|actually had a plot that showed that the
2190.66|3.3|rectified linear units trained a bit
2192.55|2.67|faster than sigmoids and that's
2193.96|3.0|intuitively because of the vanishing
2195.22|3.96|gradient problems and when you have very
2196.96|3.75|deep networks with sigmoids those
2199.18|4.5|gradients banish as Hugh was talking
2200.71|4.35|about in last lecture so what's
2203.68|3.389|interesting also to note by the way is
2205.06|4.019|that both drop out and relu are
2207.069|4.441|basically like one line or two lines of
2209.079|4.411|code to change so it's about two line
2211.51|3.72|diff total in those twenty years and
2213.49|4.53|both of them consist of setting things
2215.23|4.23|to zero so with the relevance of things
2218.02|3.18|to zero when they're lower than zero and
2219.46|4.8|with dropout you set things to zero at
2221.2|4.29|random so it's a good idea to set things
2224.26|3.75|to zero apparently that's what we
2225.49|4.17|learned so if you try to find a new cool
2228.01|3.72|algorithm look for one line dips that
2229.66|4.11|set something to zero probably will work
2231.73|5.97|better and we could add you here to this
2233.77|5.54|list now some of the newest things that
2237.7|3.2|happened some of the
2239.31|3.27|comparing it again and giving you an
2240.9|4.62|idea about the hyper parameters that are
2242.58|4.5|in this architecture it was the first
2245.52|4.23|use of rectified linear units we haven't
2247.08|3.99|seen that as much before this network
2249.75|2.34|using the normalization layers which are
2251.07|3.09|not used anymore
2252.09|4.53|at least in a specific way that they use
2254.16|4.92|them in this paper they used heavy data
2256.62|4.71|augmentation so you don't only put in
2259.08|3.69|you don't only pipe these images into
2261.33|2.73|the networks exactly as they come from
2262.77|3.27|the data set but you jitter them
2264.06|3.33|spatially around a bit and you work them
2266.04|3.18|and you change the colors a bit and you
2267.39|3.39|just do this randomly because you're
2269.22|3.3|trying to build in some invariances to
2270.78|3.41|these small perturbations and you're
2272.52|6.14|basically hallucinating additional data
2274.19|7.39|it was the first real use of drop out
2278.66|4.42|and roughly you see standard hyper
2281.58|4.05|parameters like say batch sizes of
2283.08|5.27|roughly 128 using stochastic gradient
2285.63|5.31|descent with momentum usually point nine
2288.35|4.57|in the momentum learning rates of 1e
2290.94|4.17|negative two you reduce them in normal
2292.92|3.69|ways so you're reduced roughly by factor
2295.11|4.56|of ten whenever validation stops
2296.61|6.26|improving and weight decay of just a bit
2299.67|5.88|five you negative four and ensemble
2302.87|4.99|so you train seven independent
2305.55|3.36|commercial networks separately and then
2307.86|2.64|you just average their predictions
2308.91|4.65|always gives you additional 2%
2310.5|5.76|improvement so this is Alex net the
2313.56|4.82|winner of 2012 in 2013 the winner was
2316.26|6.06|the Z F net this was developed by
2318.38|6.46|Matthew Siler and Rob progress in 2013
2322.32|4.17|and this was an improvement on top of
2324.84|3.3|Alex net architecture in particular one
2326.49|3.57|of the bigger differences here where
2328.14|3.45|that the convolutional layer the first
2330.06|3.54|convolutional layer they went from 11 by
2331.59|4.05|11 stride four to seven by seven strike
2333.6|4.02|two so if slightly smaller filters and
2335.64|3.06|you apply them more densely and then
2337.62|2.55|also they notice that these
2338.7|4.05|convolutional layers in the middle if
2340.17|4.32|you make them larger if you scale them
2342.75|3.21|up then you actually gain performance so
2344.49|4.68|they managed to improve a tiny bit
2345.96|6.78|matthew Zeiler then went he became the
2349.17|5.16|founder of clarify and he worked on this
2352.74|3.51|a bit more inside clarify and he managed
2354.33|3.78|to push the performance to 11% which was
2356.25|3.9|the winning entry at the time but we
2358.11|4.14|don't actually know what gets you from
2360.15|3.6|14% to 11% because Matthew never
2362.25|3.42|disclosed the full details of what
2363.75|3.21|happened there but he did say that it
2365.67|4.02|was more tweaking of these hyper
2366.96|5.22|parameters and optimizing that a bit so
2369.69|3.45|that was 2013 winner in 2014 we saw a
2372.18|3.18|slightly bigger
2373.14|4.11|to this so one of the networks that was
2375.36|3.87|introduced then was a vgg net from Karen
2377.25|3.45|Simonian and andrew zisserman what's
2379.23|2.76|beautiful about vgg net and they
2380.7|2.52|explored a few architectures here and
2381.99|2.37|the one that ended up working best was
2383.22|2.94|this D column which is what I'm
2384.36|4.23|highlighting it was beautiful about the
2386.16|4.86|vgg net is that it's so simple so you
2388.59|3.87|might have noticed in these previous in
2391.02|2.85|these previous networks you have these
2392.46|3.42|different filter sizes different layers
2393.87|3.48|and you do different amount of strides
2395.88|2.58|and everything kind of looks a bit hairy
2397.35|3.15|and you're not sure where these hyper
2398.46|4.77|parameters are coming from VG's unit is
2400.5|4.5|extremely uniform all you do is 3x3
2403.23|3.81|convolutions with stride one pad one and
2405.0|4.47|you do two by two Macs Bowling's with
2407.04|4.32|stride two and you do this throughout
2409.47|3.72|completely homogeneous architecture and
2411.36|4.26|you just alternate a few columns and a
2413.19|4.26|few pool layers and you get top top
2415.62|6.39|performance so they managed to reduce
2417.45|5.76|the air down to 7.3% in the vdg net just
2422.01|1.89|with a very simple item Oh genius
2423.21|3.21|architecture
2423.9|4.41|so it's I've also here written out this
2426.42|3.93|a D architecture it's just so you can
2428.31|3.78|see I'm not I'm not sure how instructed
2430.35|3.48|this is because it's kind of dense but
2432.09|3.48|you can definitely see and you can look
2433.83|3.57|at this outline perhaps but you can see
2435.57|4.61|how these volumes develop and you can
2437.4|4.77|see the kinds of sizes of these filters
2440.18|3.82|so they're always three by three but the
2442.17|3.18|number of filters again grows so we
2444.0|4.41|started off with 64 and then we go to
2445.35|6.9|128 256 512 so we're just doubling it
2448.41|5.67|over time I also have a few numbers here
2452.25|4.11|just to give you an idea of the scale at
2454.08|3.63|which these networks normally operate so
2456.36|3.33|we have on the order 140 million
2457.71|3.57|parameters this is actually quite a lot
2459.69|3.03|I'll show you in a bit that this can be
2461.28|4.35|about five or ten million parameters and
2462.72|5.01|works just as well and it's about
2465.63|4.86|hundred megabytes for image in terms of
2467.73|4.14|memory in the forward pass and then the
2470.49|2.97|backward pass also needs roughly on that
2471.87|4.62|order so that's roughly the numbers that
2473.46|4.89|were we're working with here also you
2476.49|3.84|can note that most of the and this is
2478.35|3.78|true mostly in convolutional networks is
2480.33|3.06|that most of the memory is in the early
2482.13|3.09|convolutional layers most of the
2483.39|3.06|parameters at least in the case where
2485.22|4.41|you use these giant fully connected
2486.45|5.19|layers at the top would be here so the
2489.63|3.45|winner actually in 2014 was not the VG
2491.64|3.39|net I only present it because it's such
2493.08|3.59|a simple architecture but the winner was
2495.03|4.23|actually Google net with a slightly
2496.67|4.96|hairier architecture we should say so
2499.26|4.83|it's still a sequence of things but in
2501.63|3.69|this case they've put inception modules
2504.09|2.71|in sequence and this is an example
2505.32|2.95|inception module I don't know
2506.8|3.0|then too much time to go into the
2508.27|3.0|details but you can see that it consists
2509.8|5.04|basically of convolutions and different
2511.27|8.43|kinds of strides and so on so the Google
2514.84|6.06|net is look slightly a hairier but it
2519.7|3.39|turns out to be more efficient in
2520.9|4.08|several respects so for example it works
2523.09|4.68|a bit better than vgg net at least at
2524.98|5.07|the time it only has 5 million
2527.77|3.6|parameters compared to VG nets 140
2530.05|3.33|million parameters so a huge reduction
2531.37|3.87|and you do that by the way by just
2533.38|3.33|throwing away fully connected layers so
2535.24|3.09|you'll notice in this breakdown I did
2536.71|3.51|these poly connected layers here have
2538.33|3.24|100 million parameters and 16 million
2540.22|3.66|parameters turns out you don't actually
2541.57|3.57|need that so if you take them away that
2543.88|3.72|actually doesn't hurt the performance
2545.14|7.44|too much so you can get a huge reduction
2547.6|6.75|of parameters and it was it was slightly
2552.58|3.57|we can also compare to the original
2554.35|3.69|Alex net so compared to the original
2556.15|3.15|Alex net we have fewer parameters a bit
2558.04|3.06|more compute and a much better
2559.3|3.51|performance so Google net was really
2561.1|4.17|optimized to have a low footprint both
2562.81|4.56|memory wise both computation wise and
2565.27|4.62|both parameter wise but it looks a bit
2567.37|4.23|uglier and VG net is a very beautiful
2569.89|4.41|homogeneous architecture but there are
2571.6|6.75|some inefficiencies in it okay so that's
2574.3|5.79|a 2014 now in 2015 we had a slightly
2578.35|3.6|bigger Delta on top of the architectures
2580.09|3.48|so right now these architectures if you
2581.95|3.0|on laocoon looked at them maybe in 1998
2583.57|3.21|he would still recognize everything so
2584.95|3.9|everything looks very like simple you've
2586.78|3.42|just played with had parameters so one
2588.85|2.97|of the first kind of bigger departures I
2590.2|4.23|would argue was in 2015 with the
2591.82|4.44|introduction of residual networks and so
2594.43|3.69|this has worked from kamini Hey and
2596.26|4.62|colleagues in Microsoft Research Asia
2598.12|4.95|and so they did not only win the image
2600.88|3.6|net challenge in 2015 but they want a
2603.07|3.12|whole bunch of challenges and this was
2604.48|3.69|all just by applying these residual
2606.19|3.39|networks that were trained on image net
2608.17|2.97|and then fine-tuned on all these
2609.58|3.3|different tasks and you basically can
2611.14|7.11|crush lots of different tasks whenever
2612.88|7.44|you get a new awesome Kombat so at this
2618.25|4.14|time the performance was basically 3.5
2620.32|5.1|7% from these residual networks so this
2622.39|4.47|is 2015 also this paper try to argue
2625.42|3.96|that if you look at the number of layers
2626.86|4.32|it goes up and then it
2629.38|3.39|they made the point that with residual
2631.18|4.02|networks as well see in a bit you can
2632.77|3.66|introduce many more layers and they and
2635.2|3.54|that that correlates strongly with
2636.43|3.47|performance we've since found that in
2638.74|2.809|fact you can make these residual
2639.9|3.54|works quite shop quite a lot shallower
2641.549|3.57|like say on the order of 20 or 30 layers
2643.44|3.69|and they work just as fine just as well
2645.119|3.21|so it's not necessarily the depth here
2647.13|2.939|but I'll go into that in a bit
2648.329|3.601|but you get a much better performance
2650.069|5.04|what's interesting about this paper is
2651.93|4.95|this this plot here where they compare
2655.109|2.97|these residual networks and I'll go into
2656.88|2.85|details of how they work in a bit and
2658.079|3.24|these what they call plane networks
2659.73|4.139|which is everything I've explained until
2661.319|3.811|now and the problem with plane networks
2663.869|3.18|is that when you try to scale them up
2665.13|4.32|and introduce additional layers they
2667.049|5.401|don't get monotonically better so if you
2669.45|5.22|take a 20 layer model and on this is on
2672.45|3.93|C far ten experiments if you take a 20
2674.67|4.26|layer model and you run it and then you
2676.38|4.439|take a 56 layer model you'll see that
2678.93|4.109|the 56 layer model performs worse and
2680.819|4.141|this is not just on the test data so
2683.039|4.231|it's not just an overfitting issue this
2684.96|3.69|is on the training data the 56 layer
2687.27|3.299|model performs worse on the training
2688.65|4.23|data than the 20 layer model even though
2690.569|4.591|the 56 layer model can imitate 20 layer
2692.88|4.169|model by setting 36 layers to compute
2695.16|4.26|identities so basically it's an
2697.049|4.861|optimization problem that you can't find
2699.42|4.85|the solution once your problem size
2701.91|5.159|grows that much bigger in this plane net
2704.27|4.42|architecture so in the residual networks
2707.069|2.671|that they proposed they found that when
2708.69|3.45|you wire them up in a slightly different
2709.74|4.65|way you monotonically get a better
2712.14|4.74|performance as you add more layers so
2714.39|3.99|more layers always strictly better and
2716.88|4.5|you don't run into these optimization
2718.38|4.979|issues so comparing residual networks to
2721.38|3.39|plane networks in plane networks as I've
2723.359|3.811|explained already you have this sequence
2724.77|4.049|of convolutional layers where every
2727.17|4.08|convolutional layer operates over volume
2728.819|3.361|before and produces volume in residual
2731.25|2.609|networks we have this first
2732.18|4.919|convolutional layer on top of the raw
2733.859|5.7|image then there's a pooling layer so at
2737.099|4.98|this point we've reduced to 56 by 56 by
2739.559|4.351|64 the original image and then from here
2742.079|3.811|on they have these residual blocks with
2743.91|5.879|these funny skipped connections and this
2745.89|6.03|turns out to be quite important so let
2749.789|4.26|me show you what these look like
2751.92|4.619|so the original climbing paper had this
2754.049|5.01|architecture here shown under original
2756.539|4.26|so on the left you see original residual
2759.059|3.871|networks design since then they had an
2760.799|3.181|additional paper that played with the
2762.93|3.689|architecture and found that there's a
2763.98|4.41|better arrangement of layers inside this
2766.619|4.141|block that works better empirically and
2768.39|3.719|so the way this works so concentrate on
2770.76|2.759|the proposed one in the middle since
2772.109|4.38|that works so well
2773.519|4.71|you have this pathway where you have
2776.489|3.24|this representation of the image X and
2778.229|3.93|then instead of transforming that
2779.729|5.7|representation X to get a new X to plug
2782.159|5.01|in later we end up having this X we go
2785.429|3.84|off and we do some compute on the side
2787.169|4.59|so that's that residual block doing some
2789.269|5.371|computation and then you add your result
2791.759|4.23|on top of X so you have this addition
2794.64|3.689|operation here going to the next
2795.989|5.13|residual block so you have this X and
2798.329|4.65|you always compute deltas to it and I
2801.119|3.12|think this it's not intuitive that this
2802.979|2.58|should work much better or why that
2804.239|2.91|works much better I think it becomes a
2805.559|2.7|bit more intuitively clear if you
2807.149|3.78|actually understand the backpropagation
2808.259|4.08|dynamics and how backprop works and this
2810.929|3.451|is why I always urge people also to
2812.339|3.27|implement back rub themselves to get an
2814.38|3.51|intuition for how it works what it's
2815.609|3.42|computing and so on because if you
2817.89|2.849|understand back rub you'll see that
2819.029|4.83|addition operation is a gradient
2820.739|4.38|distributor so you get a gradient from
2823.859|2.7|the top and this gradient will flow
2825.119|3.33|equally to all the children that
2826.559|3.21|participated in that addition so you
2828.449|2.85|have gradient flowing here from the
2829.769|3.121|supervision so you have supervision at
2831.299|4.11|the very bottom here in this diagram and
2832.89|3.779|it kind of flows upwards and it flows
2835.409|3.21|through these residual blocks and then
2836.669|3.75|gets added to this stream and so you end
2838.619|4.53|up with but this addition distributes
2840.419|4.44|that gradient always identically through
2843.149|3.45|so what you end up with is this kind of
2844.859|3.39|a gradient superhighway as I like to
2846.599|3.39|call it where these gradients from your
2848.249|3.51|supervision go directly to the original
2849.989|3.12|convolutional layer and then on top of
2851.759|3.15|that you get these deltas from all the
2853.109|5.4|residual blocks so these block can come
2854.909|5.79|on online and can help out that original
2858.509|4.621|stream of information this is also
2860.699|5.07|related to I think why LST MS along
2863.13|3.989|short-term memory networks work better
2865.769|3.361|than recurrent neural networks because
2867.119|4.68|they also have these kind of additional
2869.13|3.599|addition operations in the lsdm and it
2871.799|3.66|just makes the gradients flow
2872.729|4.5|significantly better then there were
2875.459|2.97|some results on top of residual networks
2877.229|2.94|that I thought were quite amusing
2878.429|3.57|so recently for example we had this
2880.169|5.37|result on deep networks with stochastic
2881.999|5.07|depth the idea here was that the authors
2885.539|3.091|of this paper noticed that you have
2887.069|4.05|these residual blocks that compute
2888.63|4.649|Delta's on top of your string and you
2891.119|4.53|can basically randomly throw out layers
2893.279|4.05|so you have these say hundred blocks 100
2895.649|4.5|residual box and you can randomly drop
2897.329|4.59|them out and at test time similar to
2900.149|3.21|drop out you introduce all of them and
2901.919|2.94|they all work at the same time but you
2903.359|2.941|have to scale things and it just like
2904.859|3.031|with dropout
2906.3|3.33|but basically it's kind of a unintuitive
2907.89|3.93|result because you can throw out layers
2909.63|3.78|at random and I think it breaks the
2911.82|3.99|original notion of what we had of
2913.41|5.1|commnets of as like these these feature
2915.81|3.96|transformers we compute more and more
2918.51|3.78|complex features over time or something
2919.77|4.38|like that and I think it seems much more
2922.29|3.93|intuitive to think about these residual
2924.15|4.98|networks at least to me as some kinds of
2926.22|4.35|dynamical systems where you have this
2929.13|3.18|original representation of the image X
2930.57|3.99|and then every single residual block is
2932.31|4.26|kind of like a vector field that because
2934.56|3.99|it computes in a delta on top of your
2936.57|4.59|signal and so these vector fields nudge
2938.55|4.8|your original representation X towards a
2941.16|5.28|space where you can decode the answer Y
2943.35|4.53|of like the class of that X and so if
2946.44|3.33|you drop off some of these residual
2947.88|3.33|blocks at random then if you haven't
2949.77|2.7|applied one of these vector fields then
2951.21|2.73|the other vector fields that come later
2952.47|5.01|can kind of make up for it and they
2953.94|4.71|nudge they basically nudge the they pick
2957.48|4.1|up the slack and they nudge along
2958.65|5.16|anyways and so that's possibly why this
2961.58|5.11|the image I currently have in mind of
2963.81|4.56|how these things work so much more like
2966.69|2.97|dynamical systems in fact another
2968.37|2.79|experiments that people are playing with
2969.66|3.33|that I also find interesting is you
2971.16|3.72|don't have you can share these residual
2972.99|3.66|blocks so it starts to look more like a
2974.88|2.97|recurrent neural network so these
2976.65|2.97|residual blocks would have shared
2977.85|3.75|connectivity and then you have this
2979.62|3.54|dynamical system really where you're
2981.6|3.03|just running a single RNN a single
2983.16|3.33|vector field did you keep iterating over
2984.63|3.18|and over and then your fixed point gives
2986.49|2.94|you the answer so it's kind of
2987.81|5.49|interesting what's happening
2989.43|5.52|it looks very funny ok we've had many
2993.3|3.15|more interesting results that so people
2994.95|3.63|are playing a lot with these residual
2996.45|4.26|networks and improving on them in
2998.58|3.54|various ways so as I mentioned already
3000.71|3.15|it turns out that you can make these
3002.12|4.11|residual networks much shallower and
3003.86|3.96|make them wider so you introduce more
3006.23|3.54|channels and that can work just as well
3007.82|3.09|if not better so it's not necessarily
3009.77|4.35|the depth that is giving you a lot of
3010.91|5.1|the performance it's you can scale down
3014.12|3.83|the depth and if you increase the width
3016.01|4.26|that can actually work better and
3017.95|4.18|they're also more efficient if you do it
3020.27|3.78|that way there's more funny
3022.13|3.66|regularization techniques here swap-out
3024.05|4.26|is a funny regularization technique that
3025.79|5.04|actually interpolates between plane nets
3028.31|5.37|rez nets and dropout so that's also a
3030.83|3.96|funny paper with fractal nets we
3033.68|2.76|actually have many more different types
3034.79|3.0|of nets and so people have really
3036.44|2.77|experimented with this a lot I'm really
3037.79|3.549|eager to see what the winning
3039.21|3.87|we'll be in 2016 as a result of a lot of
3041.339|3.631|this one of the things that has really
3043.08|3.509|enabled this rapid experimentation in
3044.97|3.45|the community is that somehow we've
3046.589|4.53|developed luckily this culture of
3048.42|5.58|sharing a lot of code among ourselves so
3051.119|4.261|for example Facebook has released just
3054.0|3.06|as an example Facebook has released
3055.38|3.479|residual networks code and torch that is
3057.06|3.24|really good that a lot of these papers I
3058.859|2.881|believe have adopted and worked on top
3060.3|3.63|of and that allowed them to actually
3061.74|5.609|really scale up their experiments and
3063.93|4.86|and it explore different architectures
3067.349|3.451|so it's great that this has happened
3068.79|3.9|unfortunately a lot of these papers are
3070.8|3.539|come kind of on archive and it's kind of
3072.69|2.97|a chaos as these are being uploaded so
3074.339|3.78|at this point I think this is a natural
3075.66|4.98|point to plug very briefly in my archive
3078.119|5.25|sanity calm so this is the best website
3080.64|5.43|ever and what it does is it crawls
3083.369|5.25|archive and it takes all the papers and
3086.07|3.75|it analyzes all the papers the full-text
3088.619|3.421|of the papers and creates tf-idf
3089.82|3.81|bag-of-words features for all the papers
3092.04|3.299|and then you can do things like you can
3093.63|3.12|search a particular paper like residual
3095.339|3.661|networks paper here and you can look for
3096.75|3.66|similar papers on archive and so this is
3099.0|2.849|a sorted list of basically all the
3100.41|3.75|residual networks papers that are most
3101.849|3.841|related to that paper or you can also
3104.16|2.97|create user accounts and you can create
3105.69|3.3|a library of papers that you like and
3107.13|3.9|then archive Sanofi will train a support
3108.99|3.9|vector machine for you and basically you
3111.03|3.9|can look at what our archive papers over
3112.89|3.78|the last month that I would enjoy the
3114.93|3.78|most and that's just computed by archive
3116.67|3.99|sanity and so it's like a curated feed
3118.71|4.02|specifically for you so I use this quite
3120.66|6.36|a bit and I find it in useful so I hope
3122.73|5.7|that other people do as well okay so we
3127.02|3.03|saw convolutional neural networks I
3128.43|3.12|explained how they work I explained some
3130.05|2.88|of the background context I've given you
3131.55|2.73|an idea of what they look like in
3132.93|2.64|practice and we went through case
3134.28|3.69|studies of the winning architectures
3135.57|4.049|over time but so far we've only looked
3137.97|3.33|at image classification specifically so
3139.619|3.301|we're categorizing images into some
3141.3|3.539|number of bins so I'd like to briefly
3142.92|3.72|talk about addressing other tasks in
3144.839|2.491|computer vision and how you might go
3146.64|3.93|about doing that
3147.33|4.86|so the way to think about doing other
3150.57|3.48|tasks in computer vision is that really
3152.19|3.06|what we have is you can think of this
3154.05|3.51|computational convolutional neural
3155.25|4.05|network as this block of compute that
3157.56|3.51|has a few million parameters in it and
3159.3|5.34|it can do basically arbitrary functions
3161.07|5.37|that are very nice over images and so
3164.64|4.83|takes an image gives you some kind of
3166.44|4.97|features and now different tasks will
3169.47|3.139|basically look as follows you want to
3171.41|2.49|picked some kind of a thing and
3172.609|2.821|different tasks there will be different
3173.9|3.51|things and you always have a desired
3175.43|3.48|thing and then you want to make the
3177.41|3.72|predicted thing much more closer to the
3178.91|3.87|desired thing and you back propagate so
3181.13|3.03|this is the only part usually that
3182.78|2.7|changes from task to task you'll see
3184.16|2.85|that these comments don't change too
3185.48|3.27|much what changes is your last function
3187.01|4.47|at the very end and that's what actually
3188.75|4.02|helps you really transfer a lot of these
3191.48|2.7|winning architectures they usually use
3192.77|2.579|these pre trained networks and you don't
3194.18|2.97|worry too much about the details of that
3195.349|3.391|architecture because you're only worried
3197.15|3.24|about you know adding a small piece at
3198.74|3.809|the top or changing the last function or
3200.39|3.39|substituting a new data set and so on so
3202.549|3.451|just to make this slightly more concrete
3203.78|4.769|in image classification we apply this
3206.0|4.02|compute block we get these features and
3208.549|3.3|then if I want to do classification I
3210.02|3.569|would basically predict 1,000 numbers
3211.849|3.361|that give me the LOC probabilities of
3213.589|3.27|different classes and then I have a
3215.21|4.5|predicted thing a desired thing
3216.859|4.771|particular class and I can back prop if
3219.71|3.54|I'm doing image captioning the it also
3221.63|4.439|looks very similar instead of predicting
3223.25|4.859|just a vector of 1,000 numbers I now
3226.069|3.3|have for example at ten thousand ten
3228.109|3.24|thousand words in some kind of
3229.369|3.72|vocabulary and I'd be predicting ten
3231.349|3.091|thousand numbers and a sequence of them
3233.089|3.391|and so I can use a recurrent neural
3234.44|4.56|network which you will hear much more
3236.48|4.829|about I think in Richards lecture just
3239.0|3.569|after this and so I produce a sequence
3241.309|2.401|of ten thousand dimensional vectors and
3242.569|2.22|that's just a description and they
3243.71|3.149|indicate the probabilities of different
3244.789|4.201|words to be emitted at different time
3246.859|4.021|steps or for example if you want to do
3248.99|4.799|localization again most of the block
3250.88|5.85|stays unchanged but now we also want
3253.789|4.83|some kind of a extent in the image so
3256.73|3.15|suppose we want to classify we don't
3258.619|2.821|only just want to classify this as an
3259.88|3.36|airplane but we want to localize it with
3261.44|3.659|X Y width height bounding box
3263.24|3.45|coordinates and if we make a specific
3265.099|3.601|assumption as well that there's always a
3266.69|3.99|single one thing in the image like a
3268.7|3.839|single airplane in every image then you
3270.68|4.26|can just afford to just predict that so
3272.539|3.78|we predict these softmax scores just
3274.94|3.69|like before and apply the cross-entropy
3276.319|4.081|loss and then we can predict X Y width
3278.63|3.149|height on top of that and we use alloc
3280.4|3.81|and l2 loss or a Hooper loss or
3281.779|4.26|something like that so you just have a
3284.21|4.139|predicted thing a desired thing and you
3286.039|3.601|just back drop if you want to do
3288.349|3.24|reinforcement learning because you want
3289.64|3.659|to play different games then again the
3291.589|2.7|setup is you just predict some different
3293.299|3.3|thing and it has some different
3294.289|3.661|semantics so in this case we will be for
3296.599|2.97|example predicting eight numbers that
3297.95|3.57|give us the probabilities of taking
3299.569|3.99|different actions for example there are
3301.52|3.66|eight discrete actions in Atari then we
3303.559|3.211|just predict eight numbers and then
3305.18|3.27|we trained us with a slightly different
3306.77|2.67|manner because in the case of
3308.45|3.06|reinforcement learning you don't
3309.44|3.629|actually have a you don't actually know
3311.51|3.329|what the correct action is to take at
3313.069|4.111|any point in time but you can still get
3314.839|4.2|a desired thing eventually because you
3317.18|5.04|just run these rollouts over time and
3319.039|6.421|you just see what what happens and then
3322.22|4.29|that helps you that helps inform exactly
3325.46|2.31|what the correct answer should have been
3326.51|2.849|or what the desired thing should have
3327.77|3.42|been in any one of those rollouts in any
3329.359|2.911|point in time I don't want to dwell on
3331.19|2.76|this too much in this lecture though
3332.27|2.7|it's outside of the scope you'll hear
3333.95|4.829|much more about reinforcement learning
3334.97|5.91|in the in a later lecture if you wanted
3338.779|4.741|to do segmentation for example then you
3340.88|4.709|don't want to predict a single vector of
3343.52|3.809|numbers for a single for single image
3345.589|3.421|but every single pixel has its own
3347.329|3.331|category that you'd like to predict so
3349.01|2.49|data set will actually be colored like
3350.66|3.51|this and you have different classes
3351.5|5.279|different areas and then instead of
3354.17|4.83|predicting a single vector of classes
3356.779|3.78|you predict an entire array of 224 by
3359.0|3.69|224 since that's the extent of the
3360.559|3.931|original image for example times 20 if
3362.69|4.139|you have 20 different classes and then
3364.49|4.65|you basically have 2 24 by 2 24
3366.829|3.571|independent soft maxes here that's one
3369.14|3.6|way you could pose this and then you
3370.4|4.439|back propagate this would here would be
3372.74|3.99|slightly more difficult because you see
3374.839|3.24|here I have a decom players mentioned
3376.73|3.21|here and I didn't explain the
3378.079|3.121|convolutional layers they're related to
3379.94|3.869|convolutional layers they do a very
3381.2|4.53|similar operation but kind of backwards
3383.809|3.451|in some way so a compilation layer kind
3385.73|3.629|of does these down sampling operations
3387.26|3.72|as it computes a decon layer does these
3389.359|3.661|kind of up sampling operations as it
3390.98|3.69|computes these convolutions but in fact
3393.02|4.259|you can implement a decomp layer using
3394.67|4.59|accomplish so what you do is you decom
3397.279|4.441|forward pass is the cobbler backward
3399.26|5.19|pass and the decom backward pass is the
3401.72|4.71|complex basically so they're basically
3404.45|3.44|an identical operation but just are you
3406.43|4.439|up sampling we're down sampling kind of
3407.89|4.179|so you can use decomp layers or you can
3410.869|2.46|use hyper columns and there are
3412.069|3.571|different things that people do in
3413.329|3.51|segmentation literature but that's just
3415.64|3.0|the rough idea as you're just changing
3416.839|3.45|to loss function at the end if you
3418.64|3.12|wanted to do auto-encoders so you want
3420.289|2.82|to do some surprise landing or something
3421.76|3.059|like that well you're just trying to
3423.109|3.151|predict the original image so you're
3424.819|3.331|trying to get the convolutional network
3426.26|3.96|to implement the identity transformation
3428.15|3.99|and the trick of course it makes it
3430.22|3.089|non-trivial is that you're forcing the
3432.14|3.449|representation to go through this
3433.309|4.201|representational bottleneck of 7 by 7 by
3435.589|2.71|512 so the network must find an
3437.51|2.38|efficient represent
3438.299|3.841|of the original image so that it can
3439.89|4.26|decode it later so that would be a auto
3442.14|3.929|encoder you again have an l2 loss at the
3444.15|3.329|end and your backdrop or if you want to
3446.069|3.03|do variational auto-encoders you have to
3447.479|3.39|introduce a repair motorisation layer
3449.099|3.45|and you have to append an additional
3450.869|3.45|small loss that makes your posterior
3452.549|2.88|beer prior but it's just like an
3454.319|2.61|additional layer and then you have an
3455.429|3.471|entire generative model and you can
3456.929|5.19|actually like sample images as well if
3458.9|5.109|you wanted to do detection things get a
3462.119|3.6|little more hairy perhaps a compared to
3464.009|3.24|localization or something like that so
3465.719|3.181|one of my favorite detectors perhaps to
3467.249|3.51|explain as the yellow detector because
3468.9|3.209|it's perhaps the simplest one it doesn't
3470.759|3.21|work the best but it's the simplest one
3472.109|4.35|to explain and has the core idea of how
3473.969|6.03|people do detection in computer vision
3476.459|5.431|and so the way this works is we reduced
3479.999|4.411|the original image to a seven by seven
3481.89|6.319|by 512 feature so really there are these
3484.41|6.299|49 discrete locations that we have and
3488.209|4.27|at every single one of these 49
3490.709|4.08|locations we're going to predict in
3492.479|3.54|yellow we're going to predict a class so
3494.789|2.341|that's shown here on the top right so
3496.019|4.35|every single one of these forty-nine
3497.13|4.919|will be some kind of a soft Max and then
3500.369|3.21|additionally at every single position
3502.049|3.841|we're going to predict some number of
3503.579|4.5|bounding boxes and so there's going to
3505.89|5.099|be a B number of bounding boxes say B is
3508.079|4.801|10 so we're going to be predicting 50
3510.989|3.151|numbers and the the 5 comes from the
3512.88|3.03|fact that every bounding box will have
3514.14|3.689|five numbers associated with it so you
3515.91|4.349|have to describe the XY the width and
3517.829|3.72|the height and you have to also indicate
3520.259|4.02|some kind of a confidence of that
3521.549|4.65|bounding box so that's the fifth number
3524.279|3.66|is some kind of a confidence measure so
3526.199|3.48|you basically end up predicting these
3527.939|4.5|bounding boxes they have positions they
3529.679|4.32|have class they have confidence and then
3532.439|2.971|you have some true bounding boxes in the
3533.999|4.02|image so you know that there are certain
3535.41|5.429|true boxes and they have certain class
3538.019|4.98|and what you do then is you match up the
3540.839|4.801|desired thing with the predicted thing
3542.999|5.671|and whatever so say for example you had
3545.64|4.77|one bounding box of a cat then you would
3548.67|3.689|find the closest predicted bounding box
3550.41|3.72|and you would mark it as a positive and
3552.359|3.99|you would try to make that associated
3554.13|4.049|grid cell predict cat and you would
3556.349|4.98|nudge the prediction to be slightly more
3558.179|4.44|towards the cat the box and so all this
3561.329|2.64|can be done with simple losses and you
3562.619|3.511|just back propagate that and then you
3563.969|3.931|have a detector or if you want to get
3566.13|3.419|much more fancy you you could do dense
3567.9|3.19|image captioning so in this case this is
3569.549|3.281|a combination of detection
3571.09|3.69|and image captioning this is a paper
3572.83|3.99|with my equal quality in Johnson and
3574.78|3.72|Feifei Lee from last year and so what we
3576.82|2.67|did here is image comes in and it
3578.5|2.67|becomes much more complex
3579.49|3.66|I don't maybe want to go into it as much
3581.17|3.87|but the first order approximation is
3583.15|4.05|that instead it's basically a detection
3585.04|4.2|but instead of predicting fixed classes
3587.2|3.54|we instead predict a sequence of words
3589.24|3.63|so we use a recurrent neural network
3590.74|3.72|there but basically I can take an image
3592.87|3.33|then and you can predict you can both
3594.46|4.59|detect and predict and describe
3596.2|4.11|everything in a complex visual scene so
3599.05|2.82|that's just some overview of different
3600.31|3.84|tasks that people care about most of
3601.87|4.17|them consist of just changing this top
3604.15|3.63|part you put different loss function a
3606.04|3.33|different data set but you'll see that
3607.78|2.97|this computational block stays
3609.37|3.09|relatively unchanged from time to time
3610.75|3.81|and that's why as I mentioned when you
3612.46|3.3|do transfer learning you just want to
3614.56|3.03|kind of take these blue train networks
3615.76|3.51|and you mostly want to use whatever
3617.59|4.98|works well on imagenet because a lot of
3619.27|4.98|that does not change too much okay so in
3622.57|3.54|the last part of the talk I'd like to
3624.25|3.75|just make sure we're good on time okay
3626.11|4.26|we're good so in the last part of the
3628.0|4.05|talk I just wanted to give some hints of
3630.37|3.24|some practical considerations when you
3632.05|2.01|want to apply convolutional net works in
3633.61|2.79|practice
3634.06|3.96|so first consideration you might have if
3636.4|4.8|you want to run these networks is what
3638.02|5.82|hardware do I use so some of the options
3641.2|4.17|that I think are available to you well
3643.84|4.05|first of all you can just buy a machine
3645.37|4.56|so for example and Vidya has these
3647.89|4.71|digits dev boxes that you can buy
3649.93|4.65|they have Titan X GPUs which are strong
3652.6|3.93|GPUs you can also if you're much more
3654.58|4.02|ambitious you can buy dgx one which has
3656.53|4.08|the newest Pascal P 100 GPS
3658.6|3.87|unfortunately the dgx one is about a
3660.61|3.3|hundred and thirty thousand dollars so
3662.47|4.08|this is kind of an expensive
3663.91|4.38|supercomputer but the digits death box I
3666.55|4.05|think is more accessible and so that's
3668.29|5.04|one option we can go with alternatively
3670.6|5.13|you can look at the specs of a dev box
3673.33|3.81|and those specs are there good specs and
3675.73|2.96|then you can buy all the components
3677.14|4.47|yourself and assemble it like Lego
3678.69|4.12|unfortunately you that's prone to
3681.61|2.73|mistakes of course but you can
3682.81|4.71|definitely reduce the price maybe by
3684.34|5.31|fracture like to it compared to the
3687.52|3.18|Nvidia machine but of course Nvidia
3689.65|2.25|machine would just come with all the
3690.7|3.42|software installed all the hardware is
3691.9|3.72|ready and you can just do work there are
3694.12|3.12|a few GPU offerings in the cloud but
3695.62|3.69|unfortunately it's actually not at a
3697.24|3.75|good place right now it's actually quite
3699.31|4.29|difficult to get GPUs in the cloud good
3700.99|3.99|GPUs at least so Amazon AWS has these
3703.6|3.42|great k5
3704.98|3.57|five 20s they're not very good GPUs
3707.02|2.94|they're not fast they don't have too
3708.55|4.17|much memory it's actually kind of a
3709.96|4.409|problem Microsoft Azure is coming up
3712.72|4.23|Azura is coming up with its own offering
3714.369|4.351|soon so I think they've announced it and
3716.95|3.6|it's in some kind of a beta stage if I
3718.72|3.66|remember correctly and so those are
3720.55|3.66|powerful GPUs K 80s that would be
3722.38|4.08|available to at open the eye for example
3724.21|3.6|you use Sarah scale so seer scale is
3726.46|3.36|much more a slightly different model you
3727.81|4.11|can't spin up GPUs on demand but they
3729.82|3.45|allow you to rent a box in the cloud so
3731.92|2.85|what that amounts to is that we have
3733.27|5.25|these boxes somewhere in the cloud I
3734.77|6.42|have just the DNA I just have the URL is
3738.52|4.65|sh2 it it's a it's a Titan X boxes in
3741.19|4.8|the machine and so you can just do work
3743.17|5.31|that way so these options are available
3745.99|4.14|to hardware wise in terms of software
3748.48|2.61|there are many different frameworks of
3750.13|3.2|course that you could use for deep
3751.09|4.019|learning so these are some of the more
3753.33|4.15|common ones that you might see in
3755.109|4.441|practice so different people have
3757.48|3.48|different recommendations on this I
3759.55|2.64|would my personal recommendation right
3760.96|4.95|now to most people if you just want to
3762.19|5.4|apply this in practical settings 90% of
3765.91|4.05|the use cases are probably addressable
3767.59|5.73|with things like Harris so Karis would I
3769.96|8.19|go to number one thing to look at Karis
3773.32|6.21|is a layer over tensorflow or Theano and
3778.15|3.36|basically just a higher-level
3779.53|3.54|API over either of those so for example
3781.51|4.17|I usually use Karis on top of tensorflow
3783.07|4.74|and it's a much more higher level
3785.68|3.78|language than raw tensorflow
3787.81|3.15|so you can also work in raw tensorflow
3789.46|3.899|but you'll have to do a lot of low level
3790.96|3.81|stuff if you need all that freedom then
3793.359|2.551|that's great because that allows you to
3794.77|4.11|have much more freedom in terms of how
3795.91|4.32|you design everything but it can be
3798.88|2.76|slightly more worthy for example you
3800.23|3.42|have to assign every single weight you
3801.64|4.2|have to assign a name stuff like that
3803.65|4.02|and so it's just much more wordy but you
3805.84|3.09|can work at that level or for most
3807.67|3.09|applications I think Karis would be
3808.93|3.54|sufficient and I've used torch for a
3810.76|3.48|long time I still really like torch it's
3812.47|2.88|very lightweight interpretable it works
3814.24|2.97|just just fine
3815.35|6.24|so those are the options that I would
3817.21|5.85|currently consider at least another
3821.59|3.24|practical consideration you might be
3823.06|3.27|wondering what architecture what
3824.83|3.21|architecture do I use in my problem so
3826.33|5.31|my answer here and I've already hinted
3828.04|5.49|at this is don't be a hero don't go
3831.64|3.54|crazy don't design your own neural
3833.53|3.67|networks and convolutional layers and
3835.18|4.36|don't probably don't you don't
3837.2|4.05|to do that probably so the algorithm is
3839.54|4.5|actually very simple look at whatever is
3841.25|4.74|currently the latest released thing that
3844.04|4.049|works really well in iOS VRC you
3845.99|3.809|download that pre-trained model and then
3848.089|3.061|you potentially add or delete some
3849.799|2.971|layers on top because you want to do
3851.15|3.09|some other tasks so that usually
3852.77|2.88|requires some tinkering at the top or
3854.24|3.059|something like that and then you
3855.65|3.26|fine-tune it on your application so
3857.299|3.961|actually a very straightforward process
3858.91|3.82|the first degree I think to most
3861.26|4.079|applications would be don't tinker with
3862.73|4.349|it too much you're going to break it but
3865.339|2.911|of course you can also take two 2:31 end
3867.079|4.04|and then you might become much better at
3868.25|6.69|at tinkering with these architectures
3871.119|6.43|second is how do I choose the parameters
3874.94|5.609|and my answer here again would be don't
3877.549|4.53|be a hero look into papers look what
3880.549|3.06|happens they use for the most part
3882.079|3.03|you'll see that all papers use the same
3883.609|3.421|hyper parameters they look very similar
3885.109|3.541|so Adam when you add them for
3887.03|2.85|optimization it's always learning rate
3888.65|5.73|one in negative three or one integrate
3889.88|6.09|four so four you can also use sed
3894.38|3.09|momentum it's always the similar kinds
3895.97|3.329|of learning rates so don't go too crazy
3897.47|3.089|designing this one of the things you
3899.299|3.931|probably want to play with the most is
3900.559|4.02|the regularization so and in particular
3903.23|2.849|not the l2 regularization but the
3904.579|5.701|dropout rates is something I would
3906.079|5.581|advise instead and so because you might
3910.28|2.76|have it smaller or a much larger data
3911.66|3.149|set if you have a much smaller data set
3913.04|3.269|and overfitting is a concern so you want
3914.809|3.3|to make sure that you regular eyes
3916.309|3.481|properly with dropout and then you might
3918.109|3.781|want to as a second degree consideration
3919.79|3.509|may be the learning rate you want to
3921.89|2.699|tune that a tiny bit but that yeah
3923.299|4.111|that's usually doesn't as much of an
3924.589|3.99|effect so really there's like two hyper
3927.41|2.79|parameters and you take a pre train
3928.579|6.24|network and this is 90% of the use cases
3930.2|6.45|I would say yeah so compared to when
3934.819|5.421|computer version 2011 where you might
3936.65|7.199|have hundreds of high parameters so yeah
3940.24|5.41|okay and in terms of distributed
3943.849|3.99|training so if you want to work at scale
3945.65|3.39|because if you want to Train imagenet or
3947.839|3.301|some large scale data sets you might
3949.04|2.88|want to train across multiple GPUs so
3951.14|2.4|just to give an idea
3951.92|2.909|most of these state-of-the-art networks
3953.54|3.72|are trained on the order of a few weeks
3954.829|5.101|across multiple GPUs usually four or
3957.26|3.9|eight GPUs and these GPS are roughly on
3959.93|2.97|the order of one thousand dollars each
3961.16|3.81|but then you also have to house them so
3962.9|3.06|of course that has a different price but
3964.97|3.75|you almost always want to train on
3965.96|4.02|multiple GPUs if possible usually you
3968.72|1.92|don't end up training across machines
3969.98|2.039|that's
3970.64|2.879|much more rare I think to train across
3972.019|2.85|machines what's much more common is you
3973.519|2.941|have a single machine and it has eight
3974.869|3.541|Titan exes or something like that and
3976.46|3.629|you do distributor training on those
3978.41|3.33|eight titan axis there are different
3980.089|3.51|ways to distribute a training so if
3981.74|3.75|you're very if you're feeling fancy you
3983.599|3.631|can try to do some model parallelism
3985.49|4.829|where you split your network across
3987.23|3.99|multiple GPUs I would instead advise
3990.319|2.76|some kind of a data parallelism
3991.22|4.74|architecture so usually what you see in
3993.079|5.131|practice is you have a GPUs so I take my
3995.96|4.77|batch of 256 images or something like
3998.21|4.079|that I split it and I split it equally
4000.73|4.41|across the GPUs I do forward pass on
4002.289|4.681|those GPUs and then I basically just add
4005.14|2.31|up all the gradients and I propagate
4006.97|2.099|that through
4007.45|3.69|so you're just distributing this batch
4009.069|3.72|and you're doing mathematical you're
4011.14|3.87|doing the exact same thing as if you had
4012.789|4.171|a giant GPU but you're just splitting up
4015.01|3.42|that batch across different GPUs but
4016.96|3.48|you're still doing synchronous training
4018.43|3.51|with SGD as normal so that's what you'll
4020.44|4.47|see most in practice which i think is
4021.94|6.06|the best thing to do right now for most
4024.91|4.56|normal applications and other kind of
4028.0|3.839|considerations that sometimes enter that
4029.47|3.51|you could may be worried about is that
4031.839|3.301|there are these bottlenecks to be aware
4032.98|3.75|of some particular CPU to disk
4035.14|3.03|bottleneck this means that you have a
4036.73|3.569|giant data set it's somewhere on some
4038.17|3.96|disk you want that disk to probably be
4040.299|3.901|an SSD because you want this loading to
4042.13|3.389|be quick because these GPUs process data
4044.2|2.849|very quickly and that might actually be
4045.519|3.57|a Balan like like loading the data could
4047.049|3.72|be a bomb like so many applications you
4049.089|3.901|might want to pre process your data make
4050.769|4.26|sure that it's read out contiguously and
4052.99|3.9|very raw form from something like an HD
4055.029|4.77|f5 file or some kind of other binary
4056.89|5.04|format and another bottleneck to be
4059.799|3.421|aware of is the CPU GPU bottleneck so
4061.93|3.089|the GPU is doing a lot of heavy lifting
4063.22|3.389|of the neural network and the CPU is
4065.019|2.85|loading the data and you might want to
4066.609|3.631|use things like prefetching threads
4067.869|4.291|where the CPU while the networks are
4070.24|3.629|doing forward backward on the GPU your
4072.16|3.629|CPU is busy loading the data from the
4073.869|4.621|disk and maybe doing some pre-processing
4075.789|5.161|and making sure that it can ship it off
4078.49|3.299|to the GPU at the next time step so
4080.95|2.669|those are some of the practical
4081.789|3.72|considerations I could come up with for
4083.619|3.15|this lecture if you wanted to learn much
4085.509|2.31|more about convolutional neural networks
4086.769|2.55|and a lot of what I've been talking
4087.819|4.081|about then I encourage you to check out
4089.319|5.071|CS 231 n we have lecture videos
4091.9|4.5|available we have notes slides and
4094.39|4.05|assignments everything is up and
4096.4|6.379|available so you're welcome to check it
4098.44|4.339|out and that's it thank you
4109.85|4.29|so I guess I can take some questions
4111.69|2.45|yeah
4132.709|7.75|hello hello hi I'm Kyle afar from Luna
4137.929|4.18|I'm using a lot of convolutional nets
4140.459|4.02|for genomics when the problems that we
4142.109|5.1|see is that our genomic sequence tends
4144.479|4.11|to be arbitrary length so right now
4147.209|2.94|we're pattern for a lot of zeros but
4148.589|4.35|we're curious as to what your thoughts
4150.149|4.95|are on using CN NS for things of
4152.939|5.1|arbitrary size where we can't just down
4155.099|4.38|sample to 277 by 277 yep
4158.039|3.54|so is this lecture genomic sequence of
4159.479|3.901|like a TCG like that kind of sequence
4161.579|3.57|exactly yeah so some of the options
4163.38|3.059|would be so recurrent neural networks
4165.149|3.81|might be a good fit because they allow
4166.439|3.99|arbitrarily sized contexts another
4168.959|3.84|option I would say is if you look at the
4170.429|4.02|wave net paper from deep mind they have
4172.799|3.15|audio and they're using convolutional
4174.449|2.4|networks for processing it and I would
4175.949|2.46|basically adopt that kind of an
4176.849|3.36|architecture they have this clever way
4178.409|4.2|of doing what's called a truce or
4180.209|4.29|dilated convolutions and so that allows
4182.609|4.14|you to capture a lot of context with few
4184.499|3.84|layers and so let's call dilated
4186.749|2.97|convolutions and the wavelet paper has
4188.339|2.46|some details and there's an efficient
4189.719|2.46|implementation of it that you should be
4190.799|3.03|aware of on github and so you might be
4192.179|4.05|able to just drag and drop the fast wave
4193.829|3.84|net code into that application and so
4196.229|3.06|you have much larger context but it's of
4197.669|3.45|course not infinite context as you might
4199.289|3.241|have with a recurrent Network yeah we're
4201.119|3.33|definitely checking those out we also
4202.53|4.379|tried our n ends they're quite slow for
4204.449|4.831|these things our main problems that the
4206.909|5.13|genes can be very short or very long but
4209.28|3.959|the whole sequence matters so I think
4212.039|2.761|that's one of the challenges that we're
4213.239|5.101|looking at with this type of problem
4214.8|4.56|interesting yeah so those would be the
4218.34|2.339|two options that I would play with
4219.36|4.699|basically I think those are the two demo
4220.679|3.38|where thank you
4227.159|3.971|thanks for a great lecture so my
4229.719|3.63|question is that is there a clear
4231.13|4.139|mathematical or conceptual understanding
4233.349|3.33|when people decide how many hidden
4235.269|5.22|layers have to be part of their
4236.679|5.28|architecture yeah so the answer with a
4240.489|3.24|lot of this is there a mathematical
4241.959|3.75|understanding will likely be no because
4243.729|3.99|we are in very early phases of just
4245.709|5.401|doing a lot of empirical and I'll guess
4247.719|4.951|and check kind of work and so theory is
4251.11|3.359|in some some ways like lagging behind a
4252.67|4.139|bit I would say that was residual
4254.469|4.86|networks you want to have more layers
4256.809|3.96|usually works better and so you can take
4259.329|3.15|these layers outdoor you can put them in
4260.769|3.031|and it's just mostly computational
4262.479|4.14|consideration of how much can you fit in
4263.8|5.1|so our consideration is usually is you
4266.619|3.6|have a GPU it has maybe 16 gigs of ram
4268.9|3.929|or 12 gigs of ram or something
4270.219|3.811|I want certain batch size and I have
4272.829|3.571|these considerations and that upper
4274.03|4.109|bounds the amount of like layers or how
4276.4|3.239|big they could be and so I use the
4278.139|3.27|biggest thing that fits in my GPU and
4279.639|4.44|that's mostly what the way you choose
4281.409|3.75|this and then you regularize it very
4284.079|2.91|strongly so if you have a very small
4285.159|3.09|data set then you might end up with a
4286.989|2.76|pretty big Network for your data set so
4288.249|3.21|you might want to make sure that you are
4289.749|8.761|tuning those dropout rates properly and
4291.459|9.901|so you're not overfitting I have
4298.51|4.709|question my understanding is that the
4301.36|3.869|recent convolution that doesn't use
4303.219|5.19|polling layers right so the question is
4305.229|6.691|why you know why don't they use fungal
4308.409|6.0|areas so you know is there still a place
4311.92|4.099|for puli yeah yeah so certainly so if
4314.409|3.81|you saw for example the residual Network
4316.019|4.361|at the end there was a single pooling
4318.219|3.9|layer at the very beginning but mostly
4320.38|3.359|they went away you're right so took her
4322.119|3.21|I wonder if I can find the slide I
4323.739|6.541|wonder if this is a good idea to try to
4325.329|8.94|find the slide that's bro okay let me
4330.28|5.73|just find this okay so this was the
4334.269|3.511|residual network architecture so you see
4336.01|3.87|that they do a first comm and then
4337.78|3.48|there's a single pool right there but
4339.88|3.299|certainly the trend has been to throw
4341.26|2.37|them away over time and there's a paper
4343.179|2.31|also
4343.63|4.859|it's called striving for simplicity the
4345.489|4.17|all convolutional neural network and the
4348.489|2.61|point in that paper is look you can
4349.659|2.79|actually do stranded convolutions you
4351.099|3.511|can throw away pulling layers all
4352.449|3.601|together or it's just as well so pulling
4354.61|3.9|layers are kind of I would say this kind
4356.05|3.6|of a bit of a historical vestige of they
4358.51|1.859|needed things to be efficient then they
4359.65|3.0|need to control
4360.369|3.691|Bastian downsample things quite a lot
4362.65|4.17|and so we're kind of throwing them away
4364.06|4.619|over time and yeah they're not doing
4366.82|4.47|anything like super useful they're doing
4368.679|4.081|this fixed operation and you want to
4371.29|2.88|learn as much as possible so maybe you
4372.76|3.689|don't actually want to get rid of that
4374.17|4.199|information so it's always more
4376.449|3.141|appealing to it's probably more
4378.369|3.801|appealing I would say to throw them away
4379.59|5.5|well you mentioned there is a sort of
4382.17|5.41|cognitive or brain analogy that the
4385.09|4.049|brain is doing polling so yeah so I
4387.58|2.909|think that analogy is stretched by a lot
4389.139|8.1|so the brain I'm not sure every brain is
4390.489|9.721|doing pulling yeah about image
4397.239|5.071|compression not for justification about
4400.21|3.659|the usage of neural networks for image
4402.31|3.24|compression do we have any examples
4403.869|4.56|sorry I couldn't hear the question it's
4405.55|4.799|of classification for images can we use
4408.429|4.56|the neural networks for image
4410.349|3.991|compression image compression yeah I
4412.989|3.871|think there's actually a really exciting
4414.34|3.87|work in this area so one that I'm aware
4416.86|3.42|of for example as a recent work from
4418.21|3.21|Google where they're using commercial
4420.28|3.56|networks and recurrent networks to come
4421.42|4.77|up with variably sized codes for images
4423.84|3.7|so certainly a lot of these generative
4426.19|4.199|models I mean they are very related to
4427.54|4.74|compression so definitely a lot of work
4430.389|3.721|in the area of them that I'm excited
4432.28|3.089|about also for example super resolution
4434.11|4.859|networks so you saw the recent
4435.369|5.221|acquisition of magic pony by Twitter so
4438.969|3.451|they were also doing something that
4440.59|3.299|basically allows you to compress you can
4442.42|4.44|send low resolution strings because you
4443.889|7.171|can up sample it on the client and so a
4446.86|7.29|lot of work in that area yeah I had we
4451.06|5.82|should patent it after you I can't
4454.15|5.069|please comment on scalability regarding
4456.88|5.79|number of classes so what does it take
4459.219|5.551|if we go up to 10,000 or 100,000 classes
4462.67|4.02|hmm yes so if you have a lot of classes
4464.77|3.63|then of course you can grow your softmax
4466.69|3.06|but that becomes inefficient at some
4468.4|3.299|point because you're doing a giant
4469.75|3.42|matrix multiply so some of the ways that
4471.699|3.42|people are addressing this in practice I
4473.17|2.489|believe is you use of like hierarchical
4475.119|4.201|softmax
4475.659|5.641|and things like that so you you
4479.32|3.72|decompose your classes into groups and
4481.3|4.85|then you kind of predict one group at a
4483.04|6.0|time and you kind of converge that way
4486.15|4.93|so I'm not I see these papers but I
4489.04|3.329|don't I'm not an expert on exactly how
4491.08|2.79|this works but I do know that they are
4492.369|3.151|called softmax is something that people
4493.87|3.3|thing especially for example in language
4495.52|3.78|models this is often used because you
4497.17|3.72|have a huge amount of words and you
4499.3|2.94|still need to predict them somehow so I
4500.89|2.37|believe Thomas Mikhailov for example he
4502.24|5.4|has some papers on using hierarchical
4503.26|6.29|softmax in this context would you could
4507.64|4.65|you talk a little bit about the
4509.55|4.14|convolutional functions like what what
4512.29|3.3|considerations you should make in
4513.69|4.63|selecting the functions that are used in
4515.59|3.87|the convolutional filters selecting the
4518.32|3.84|functions that are used in the
4519.46|4.26|convolutional filters so these filters
4522.16|3.83|are just parameters right so we train
4523.72|5.34|those filters they're just numbers that
4525.99|4.15|we trained with backpropagation okay are
4529.06|3.77|you talking about the nonlinearities
4530.14|5.19|perhaps or yeah I'm just wondering about
4532.83|4.21|when you're selecting those the features
4535.33|3.93|or when you're getting the when you're
4537.04|3.99|trying to train to just understand
4539.26|4.29|different features with an image what
4541.03|3.84|what are those filters actually doing
4543.55|2.67|well I see you're talking about
4544.87|2.55|understanding exactly what those filters
4546.22|2.76|are looking for in the engine somewhat
4547.42|4.53|so a lot of interesting work especially
4548.98|4.53|for example so Jason your Sinskey he has
4551.95|2.85|this deepest toolbox and I've shown you
4553.51|3.42|that you can kind of debug it that way a
4554.8|4.05|bit there's an entire lecture to
4556.93|4.5|encourage you to watch in CS 231 and on
4558.85|4.41|visualizing understanding accomplish all
4561.43|3.96|networks so people use things like a
4563.26|4.53|decom or guided or guided back
4565.39|3.87|propagation or you back propagate to
4567.79|3.12|image and you try to find the stimulus
4569.26|3.59|that maximally activates any arbitrary
4570.91|4.53|neuron so different ways of probing it
4572.85|4.66|and different ways have been developed
4575.44|3.12|and there's a lecture about it so I
4577.51|4.25|would I would check that out
4578.56|6.48|great thanks I had a question regarding
4581.76|5.74|the size of fine-tuning data set for
4585.04|4.97|example is there a ballpark game number
4587.5|4.97|if you are trying to do classification
4590.01|6.22|how many do you put you need for
4592.47|5.71|fine-tuning it to your sample set so how
4596.23|5.42|many how many data points do you need to
4598.18|6.24|get good performance since the question
4601.65|4.84|okay so so okay so this is like the most
4604.42|4.92|boring answer I think because the more
4606.49|6.12|the better always and it's really hard
4609.34|5.03|to say actually the company you need so
4612.61|3.84|usually one way one way to look at it as
4614.37|3.31|one heuristic that people sometimes
4616.45|2.88|follow is you look at a number of
4617.68|3.57|parameters and you want the number of
4619.33|3.18|examples to be on the order of number of
4621.25|3.06|parameters that's one way people
4622.51|3.42|sometimes break it down right for
4624.31|3.45|fine-tuning because we will have an
4625.93|3.66|image net model so
4627.76|3.24|I was hoping that most of the things
4629.59|3.06|would be taken care or there and then
4631.0|3.84|you're just fine-tuning so you you might
4632.65|3.51|need a lower order I say so when you're
4634.84|2.73|saying fine-tuning are you finding the
4636.16|3.21|whole network or you're using some of it
4637.57|3.69|or just the top classifier just the top
4639.37|3.0|classifier yeah so one another way to
4641.26|2.49|look at it is you have some number of
4642.37|3.93|parameters and you can estimate the
4643.75|4.05|number of bits that you think every
4646.3|3.21|parameter has and then you count the
4647.8|3.0|number of bits in your data so that's
4649.51|4.8|kind of like comparisons you would do
4650.8|4.74|but really uh yeah I have no good answer
4654.31|2.79|so the more the better and you have to
4655.54|2.64|try and you have to regularize and you
4657.1|2.1|have to cross validate that and you have
4658.18|3.69|to see what performance you get over
4659.2|6.57|time because it's to task it and then
4661.87|5.16|for me to say something stronger hi I
4665.77|3.23|would like to know how do you think the
4667.03|4.71|Covenant will work in this rady case
4669.0|5.41|like is they just a simple extension of
4671.74|5.34|the 2d case oh do we need some extra
4674.41|5.34|tweak about in 3d case so you're talking
4677.08|5.43|specifically about say videos or some 3d
4679.75|5.49|accurate talking about the image that
4682.51|4.71|has the depth information oh I see so
4685.24|2.34|say you have like RGB D input and things
4687.22|2.52|like that
4687.58|5.52|yeah so I'm not too familiar with people
4689.74|5.49|do but I do know for example that people
4693.1|3.66|try to have for example one thing he can
4695.23|3.66|do is just treat it as a fourth Channel
4696.76|3.33|or maybe you want the separate ComNet on
4698.89|2.97|top of the depth channel and do some
4700.09|3.33|fusion later so I don't know exactly
4701.86|5.7|what the state-of-the-art in treating
4703.42|5.37|that depth channel is right now so I
4707.56|3.48|don't exactly how they do what I do
4708.79|4.5|right now oh so maybe just one more
4711.04|6.3|question just how do you think the 3d
4713.29|5.82|object great condition a 3d object yeah
4717.34|4.43|recognition so what is the output that
4719.11|5.49|you'd like the oppo is still the class
4721.77|5.53|probability but we are not treating the
4724.6|4.05|2d image but the 3d representation of
4727.3|4.8|the art I say so do you have a mesh or
4728.65|6.12|point cloud yeah I see yeah so also not
4732.1|4.65|not exactly my area for currently but so
4734.77|3.27|the problem with these meshes and so on
4736.75|2.76|is that there's just like a rotational
4738.04|6.21|degree of freedom that I'm not sure what
4739.51|6.03|people do about honestly so the yeah so
4744.25|2.1|I'm actually not an expert on this so I
4745.54|1.89|don't want to comment there are some
4746.35|2.58|obvious things you might want to try
4747.43|3.42|like you might want to plug in all the
4748.93|4.23|possible ways you could orient this and
4750.85|3.15|then a test time averaged over them so
4753.16|2.34|there would be some of the obvious
4754.0|2.61|things to play with but I don't I'm not
4755.5|4.19|actually sure what the state of the art
4756.61|3.08|is okay thank you
4760.79|4.75|so coming back to the distributed
4763.44|4.65|training is it possible to do even the
4765.54|5.13|classification a distributed way or my
4768.09|5.43|questions in future can I imagine my our
4770.67|7.14|cellphones do these things together for
4773.52|5.88|one inquiry our cellphones oh I see
4777.81|3.9|you're trying to get cell phones
4779.4|6.99|distributed training yes it's a train
4781.71|6.72|it's arrived quite a fun very radical
4786.39|3.63|idea so related thoughts I had recently
4788.43|4.59|was so I had come the jas in the browser
4790.02|4.11|and I was thinking of basically this
4793.02|2.4|trains narrow networks and I was
4794.13|2.88|thinking about similar questions because
4795.42|3.78|you could imagine shipping this off as
4797.01|3.51|an ad equivalent like the people just
4799.2|2.67|include this in the JavaScript and then
4800.52|4.83|everyone's browsers are kind of like
4801.87|4.98|training a small network so I think
4805.35|2.85|that's a related question do you think
4806.85|3.24|there's like too much communication
4808.2|3.75|overhead or it could be actually really
4810.09|3.87|disturbed in an efficient way
4811.95|4.32|yes so the problem with distributing it
4813.96|4.11|a lot is actually a stale gradients
4816.27|3.99|problem so when you look at some of the
4818.07|3.69|papers that Google has put out about
4820.26|3.18|distributed training as you look at the
4821.76|4.08|number of workers when you do
4823.44|4.02|asynchronous SGD number of workers and
4825.84|2.94|the the performance improvement you get
4827.46|3.18|it kind of like plateaus quite quickly
4828.78|3.81|after like eight workers or something
4830.64|3.66|quite small so I'm not sure if there are
4832.59|3.39|ways of dealing with thousands of
4834.3|3.96|workers the issue is that you have a
4835.98|5.04|distributed every worker has this like
4838.26|6.57|specific snapshot of the weights that
4841.02|5.79|are currently I have to pull you pull
4844.83|3.6|from the master and now you have a set
4846.81|3.57|of ways that you're using and do forward
4848.43|3.33|backward and you send an update but by
4850.38|3.06|the time you send an update and you down
4851.76|3.84|your forward backward the parameters
4853.44|3.96|server has now done like lots of updates
4855.6|3.87|from like thousands of other things and
4857.4|4.38|so you're grading the scale you've
4859.47|5.19|evaluated it every wrong an old location
4861.78|5.28|and so it's an incorrect direction now
4864.66|3.45|and everything breaks so that's the
4867.06|4.56|challenge and I'm not sure what people
4868.11|5.28|are doing about this yeah I was
4871.62|5.28|wondering about applications of
4873.39|5.16|convolutional nets to two inputs at a
4876.9|3.51|time so let's say you have two pictures
4878.55|3.72|of jigsaw puzzles puzzles
4880.41|3.29|these are pieces they're trying to
4882.27|4.17|figure out if they fit together or
4883.7|4.39|whether one object compares to the other
4886.44|4.08|in a specific way have you heard of any
4888.09|4.29|implementation of this kind yes so you
4890.52|2.79|have two inputs instead of one yeah so
4892.38|2.16|the common way
4893.31|2.55|dealing with that as you put a comment
4894.54|3.21|on each and then you do some kind of a
4895.86|5.27|fusion eventually to to merge the
4897.75|5.19|information right I see and same for
4901.13|4.72|recurrent neural networks if you have
4902.94|3.93|like variable input so for example in
4905.85|2.79|the context the videos where you have
4906.87|2.61|frames coming in yeah then yeah so some
4908.64|1.95|of the approaches are you have
4909.48|3.63|accomplished all Network on the frame
4910.59|4.74|and then at the top you tie it in with
4913.11|4.14|the recurrent neural network so you have
4915.33|3.24|these you reduce the image to some kind
4917.25|3.21|of a lower dimensional representation
4918.57|3.29|and then that get that's an input to a
4920.46|3.3|recurrent neural network at the top
4921.86|3.28|there are other ways to play with this
4923.76|2.73|for example you can actually make the
4925.14|3.39|recurrent you can make every single
4926.49|4.47|neuron in the calm that recurrent that's
4928.53|4.77|also one funny way of doing this so
4930.96|4.44|right now when a neuron computes its
4933.3|4.83|output it's only a function of a local
4935.4|4.61|neighborhood and below it but you can
4938.13|4.47|also make it in addition a function of
4940.01|4.03|that same local neighborhood or like its
4942.6|5.49|own activation perhaps in the previous
4944.04|5.43|time step if that makes sense so so this
4948.09|2.64|so this neuron is not just computing a
4949.47|3.24|dot product with the with the current
4950.73|4.5|patch but it's also incorporating a dot
4952.71|4.5|product of its own and maybe it's
4955.23|3.42|neighborhoods activations at the
4957.21|2.64|previous time step of the frame so
4958.65|3.03|that's kind of like a small or an update
4959.85|2.64|hidden inside every single neuron so
4961.68|2.1|those are the things that I think people
4962.49|2.97|play with when I'm not familiar with
4963.78|4.4|what currently is working best in this
4965.46|4.29|area pretty awesome thank you yeah yeah
4968.18|5.26|thanks for the great talk
4969.75|5.04|final question regarding the latency for
4973.44|3.51|the models that are trained using
4974.79|3.75|multiple layers so especially at the
4976.95|4.26|prediction time you know as we add more
4978.54|4.5|more layers for the forward pass it will
4981.21|3.42|take some time you know it'll increase
4983.04|3.33|in the latency right for the prediction
4984.63|5.01|so what are the numbers that we have
4986.37|5.67|seen you know you know presently that
4989.64|4.38|you know that you know if you can share
4992.04|4.89|that you know the prediction time or the
4994.02|4.38|you know the latency at the the forward
4996.93|3.69|pass so you're worried for example
4998.4|3.72|you're some you want to run a friction
5000.62|4.17|very quickly would it be on an embedded
5002.12|4.05|device or is this in the cloud uh you're
5004.79|3.42|suppose you know it's a cell phone you
5006.17|3.87|know you have your you know identifying
5008.21|4.47|the objects or you know you're you're
5010.04|4.74|doing some you know image analysis or
5012.68|3.51|something yeah so there's definitely a
5014.78|2.67|lot of work on this so one way you would
5016.19|2.94|approach this actually is you have this
5017.45|4.32|network that you've trained using
5019.13|5.7|floating point arithmetic 32 bits say
5021.77|3.92|and so there's a lot of work on taking
5024.83|2.34|that Network and
5025.69|3.67|discretizing all
5027.17|4.44|into like intz and making it much
5029.36|4.049|smaller and pruning connections so one
5031.61|3.33|of the works I'm related to this for
5033.409|4.141|example is someone here at Stanford has
5034.94|4.14|few papers on getting rid of spurious
5037.55|3.12|connections and reducing the network as
5039.08|3.09|much as possible and then making
5040.67|4.319|everything very efficient with integer
5042.17|5.37|arithmetic so basically you achieve this
5044.989|6.271|by discretizing all the weights and all
5047.54|5.369|the activations and throwing away and
5051.26|4.26|pruning the network so there are some
5052.909|4.111|tricks like that that people play that's
5055.52|3.869|mostly what you would do in an embedded
5057.02|3.99|device and then the challenge of course
5059.389|2.671|is you've changed the network and now
5061.01|2.459|you just kind of are crossing your
5062.06|3.54|fingers that it works well and so I
5063.469|4.051|think what's interesting for Reese from
5065.6|3.869|research standpoint is he'd like to do
5067.52|3.96|you'd like your test time to exactly
5069.469|3.781|match your training time right so then
5071.48|3.21|you get the best performance and so the
5073.25|3.06|question is how do we train with low
5074.69|3.21|precision arithmetic and there's a lot
5076.31|4.8|of work on this as well so say from your
5077.9|4.5|show up in Joe's lab as well and so
5081.11|4.14|that's exciting directions of how you
5082.4|4.319|train in low precision regime do you
5085.25|3.81|have any numbers I mean that you can
5086.719|5.311|share for the new state of the art how
5089.06|4.86|much time does it yes I see the papers
5092.03|3.66|but I'm not sure if I remember the exact
5093.92|3.56|reductions it's on the order of okay I
5095.69|4.679|don't want to say because it's go no
5097.48|5.199|thanks I don't want to try to guess this
5100.369|5.451|thank you all right we're out of time
5102.679|3.141|let's thank Andrew
5111.24|6.09|lunch is outside and will restart at
5114.33|3.0|12:45