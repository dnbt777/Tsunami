start_time|end_time|text
0.24|3.84|hi everyone hope you're well
2.24|3.92|and next up what i'd like to do is i'd
4.08|4.479|like to build out make more
6.16|4.08|like micrograd before it make more is a
8.559|2.801|repository that i have on my github
10.24|2.399|webpage
11.36|3.04|you can look at it
12.639|3.681|but just like with micrograd i'm going
14.4|3.52|to build it out step by step and i'm
16.32|2.719|going to spell everything out so we're
17.92|2.32|going to build it out slowly and
19.039|3.121|together
20.24|4.32|now what is make more
22.16|5.359|make more as the name suggests
24.56|4.479|makes more of things that you give it
27.519|4.0|so here's an example
29.039|3.441|names.txt is an example dataset to make
31.519|2.88|more
32.48|4.32|and when you look at names.txt you'll
34.399|3.761|find that it's a very large data set of
36.8|3.36|names
38.16|3.52|so
40.16|4.0|here's lots of different types of names
41.68|4.399|in fact i believe there are 32 000 names
44.16|3.68|that i've sort of found randomly on the
46.079|4.0|government website
47.84|5.359|and if you train make more on this data
50.079|5.201|set it will learn to make more of things
53.199|4.401|like this
55.28|5.04|and in particular in this case that will
57.6|4.72|mean more things that sound name-like
60.32|3.52|but are actually unique names
62.32|2.96|and maybe if you have a baby and you're
63.84|3.2|trying to assign name maybe you're
65.28|4.24|looking for a cool new sounding unique
67.04|4.24|name make more might help you
69.52|3.84|so here are some example generations
71.28|4.879|from the neural network
73.36|4.399|once we train it on our data set
76.159|3.521|so here's some example
77.759|3.921|unique names that it will generate
79.68|3.759|dontel
81.68|2.799|irot
83.439|3.521|zhendi
84.479|4.401|and so on and so all these are sound
86.96|3.68|name like but they're not of course
88.88|4.0|names
90.64|4.56|so under the hood make more is a
92.88|4.4|character level language model so what
95.2|4.48|that means is that it is treating every
97.28|4.799|single line here as an example and
99.68|4.32|within each example it's treating them
102.079|6.801|all as sequences of individual
104.0|6.56|characters so r e e s e is this example
108.88|2.96|and that's the sequence of characters
110.56|4.239|and that's the level on which we are
111.84|4.639|building out make more and what it means
114.799|3.6|to be a character level language model
116.479|3.441|then is that it's just uh sort of
118.399|2.961|modeling those sequences of characters
119.92|3.68|and it knows how to predict the next
121.36|3.92|character in the sequence
123.6|3.839|now we're actually going to implement a
125.28|3.92|large number of character level language
127.439|3.44|models in terms of the neural networks
129.2|4.24|that are involved in predicting the next
130.879|4.401|character in a sequence so very simple
133.44|3.68|bi-gram and back of work models
135.28|4.319|multilingual perceptrons recurrent
137.12|4.56|neural networks all the way to modern
139.599|4.081|transformers in fact the transformer
141.68|4.559|that we will build will be basically the
143.68|4.96|equivalent transformer to gpt2 if you
146.239|4.64|have heard of gpt uh so that's kind of a
148.64|3.92|big deal it's a modern network and by
150.879|3.761|the end of the series you will actually
152.56|4.24|understand how that works um on the
154.64|5.2|level of characters now to give you a
156.8|4.64|sense of the extensions here uh after
159.84|3.44|characters we will probably spend some
161.44|3.6|time on the word level so that we can
163.28|4.239|generate documents of words not just
165.04|4.4|little you know segments of characters
167.519|3.44|but we can generate entire large much
169.44|2.879|larger documents
170.959|3.681|and then we're probably going to go into
172.319|4.721|images and image text
174.64|5.36|networks such as dolly stable diffusion
177.04|5.119|and so on but for now we have to start
180.0|3.36|here character level language modeling
182.159|2.641|let's go
183.36|3.599|so like before we are starting with a
184.8|3.76|completely blank jupiter notebook page
186.959|4.801|the first thing is i would like to
188.56|5.28|basically load up the dataset names.txt
191.76|3.6|so we're going to open up names.txt for
193.84|3.52|reading
195.36|4.4|and we're going to read in everything
197.36|4.0|into a massive string
199.76|3.36|and then because it's a massive string
201.36|3.12|we'd only like the individual words and
203.12|3.36|put them in the list
204.48|3.28|so let's call split lines
206.48|3.759|on that string
207.76|4.24|to get all of our words as a python list
210.239|3.121|of strings
212.0|3.76|so basically we can look at for example
213.36|5.68|the first 10 words
215.76|5.68|and we have that it's a list of emma
219.04|4.64|olivia eva and so on
221.44|4.079|and if we look at
223.68|3.36|the top of the page here that is indeed
225.519|2.64|what we see
227.04|2.559|um
228.159|4.08|so that's good
229.599|6.0|this list actually makes me feel that
232.239|5.041|this is probably sorted by frequency
235.599|3.36|but okay so
237.28|3.28|these are the words now we'd like to
238.959|3.36|actually like learn a little bit more
240.56|3.36|about this data set let's look at the
242.319|4.081|total number of words we expect this to
243.92|3.76|be roughly 32 000
246.4|2.72|and then what is the for example
247.68|3.279|shortest word
249.12|4.479|so min of
250.959|6.081|length of each word for w inwards
253.599|4.64|so the shortest word will be length
257.04|4.159|two
258.239|4.881|and max of one w for w in words so the
261.199|3.361|longest word will be
263.12|2.72|15 characters
264.56|2.8|so let's now think through our very
265.84|2.88|first language model
267.36|3.36|as i mentioned a character level
268.72|4.72|language model is predicting the next
270.72|4.479|character in a sequence given already
273.44|3.12|some concrete sequence of characters
275.199|2.801|before it
276.56|4.4|now we have to realize here is that
278.0|5.919|every single word here like isabella is
280.96|4.56|actually quite a few examples packed in
283.919|3.361|to that single word
285.52|3.44|because what is an existence of a word
287.28|3.84|like isabella in the data set telling us
288.96|4.64|really it's saying that
291.12|5.359|the character i is a very likely
293.6|4.96|character to come first in the sequence
296.479|5.201|of a name
298.56|5.76|the character s is likely to come
301.68|4.72|after i
304.32|3.28|the character a is likely to come after
306.4|2.96|is
307.6|4.879|the character b is very likely to come
309.36|5.04|after isa and so on all the way to a
312.479|3.201|following isabel
314.4|2.88|and then there's one more example
315.68|3.359|actually packed in here
317.28|4.08|and that is that
319.039|4.72|after there's isabella
321.36|4.08|the word is very likely to end
323.759|3.601|so that's one more sort of explicit
325.44|4.16|piece of information that we have here
327.36|4.32|that we have to be careful with
329.6|4.08|and so there's a lot backed into a
331.68|3.68|single individual word in terms of the
333.68|4.32|statistical structure of what's likely
335.36|3.839|to follow in these character sequences
338.0|3.52|and then of course we don't have just an
339.199|3.601|individual word we actually have 32 000
341.52|3.28|of these and so there's a lot of
342.8|3.36|structure here to model
344.8|3.28|now in the beginning what i'd like to
346.16|5.039|start with is i'd like to start with
348.08|4.959|building a bi-gram language model
351.199|3.44|now in the bigram language model we're
353.039|3.681|always working with just
354.639|4.641|two characters at a time
356.72|4.16|so we're only looking at one character
359.28|3.199|that we are given and we're trying to
360.88|2.96|predict the next character in the
362.479|3.84|sequence
363.84|4.479|so um what characters are likely to
366.319|3.841|follow are what characters are likely to
368.319|3.521|follow a and so on and we're just
370.16|2.72|modeling that kind of a little local
371.84|3.12|structure
372.88|4.08|and we're forgetting the fact that we
374.96|3.359|may have a lot more information we're
376.96|3.359|always just looking at the previous
378.319|3.361|character to predict the next one so
380.319|2.88|it's a very simple and weak language
381.68|2.4|model but i think it's a great place to
383.199|2.481|start
384.08|3.36|so now let's begin by looking at these
385.68|3.359|bi-grams in our data set and what they
387.44|3.44|look like and these bi-grams again are
389.039|4.081|just two characters in a row
390.88|4.319|so for w in words
393.12|3.199|each w here is an individual word a
395.199|4.401|string
396.319|5.361|we want to iterate uh for
399.6|4.4|we're going to iterate this word
401.68|4.239|with consecutive characters so two
404.0|5.36|characters at a time sliding it through
405.919|5.521|the word now a interesting nice way cute
409.36|3.839|way to do this in python by the way is
411.44|4.879|doing something like this for character
413.199|6.801|one character two in zip off
416.319|5.361|w and w at one
420.0|2.8|one column
421.68|2.88|print
422.8|3.119|character one character two
424.56|2.88|and let's not do all the words let's
425.919|3.12|just do the first three words and i'm
427.44|2.479|going to show you in a second how this
429.039|2.88|works
429.919|3.761|but for now basically as an example
431.919|3.361|let's just do the very first word alone
433.68|4.639|emma
435.28|5.68|you see how we have a emma and this will
438.319|5.44|just print e m m m a
440.96|5.84|and the reason this works is because w
443.759|4.88|is the string emma w at one column is
446.8|2.88|the string mma
448.639|4.721|and zip
449.68|5.359|takes two iterators and it pairs them up
453.36|4.0|and then creates an iterator over the
455.039|4.401|tuples of their consecutive entries
457.36|4.48|and if any one of these lists is shorter
459.44|4.24|than the other then it will just
461.84|7.12|halt and return
463.68|6.239|so basically that's why we return em mmm
468.96|3.12|ma
469.919|5.201|but then because this iterator second
472.08|4.799|one here runs out of elements zip just
475.12|4.56|ends and that's why we only get these
476.879|4.961|tuples so pretty cute
479.68|4.239|so these are the consecutive elements in
481.84|3.039|the first word now we have to be careful
483.919|3.361|because we actually have more
484.879|5.04|information here than just these three
487.28|5.039|examples as i mentioned we know that e
489.919|4.481|is the is very likely to come first and
492.319|3.28|we know that a in this case is coming
494.4|3.359|last
495.599|3.681|so one way to do this is basically we're
497.759|3.761|going to create
499.28|3.759|a special array here all
501.52|3.76|characters
503.039|5.361|and um we're going to hallucinate a
505.28|4.56|special start token here
508.4|3.999|i'm going to
509.84|4.72|call it like special start
512.399|4.08|so this is a list of one element
514.56|3.2|plus
516.479|4.8|w
517.76|4.959|and then plus a special end character
521.279|4.641|and the reason i'm wrapping the list of
522.719|5.921|w here is because w is a string emma
525.92|4.88|list of w will just have the individual
528.64|3.199|characters in the list
530.8|3.92|and then
531.839|6.241|doing this again now but not iterating
534.72|5.44|over w's but over the characters
538.08|4.64|will give us something like this
540.16|4.96|so e is likely so this is a bigram of
542.72|3.679|the start character and e and this is a
545.12|3.92|bigram of the
546.399|4.081|a and the special end character
549.04|2.96|and now we can look at for example what
550.48|4.0|this looks like for
552.0|4.16|olivia or eva
554.48|3.12|and indeed we can actually
556.16|3.2|potentially do this for the entire data
557.6|3.04|set but we won't print that that's going
559.36|3.12|to be too much
560.64|4.319|but these are the individual character
562.48|4.0|diagrams and we can print them
564.959|3.361|now in order to learn the statistics
566.48|4.08|about which characters are likely to
568.32|4.4|follow other characters the simplest way
570.56|3.839|in the bigram language models is to
572.72|3.679|simply do it by counting
574.399|4.0|so we're basically just going to count
576.399|3.841|how often any one of these combinations
578.399|3.361|occurs in the training set
580.24|2.88|in these words
581.76|3.12|so we're going to need some kind of a
583.12|4.159|dictionary that's going to maintain some
584.88|4.88|counts for every one of these diagrams
587.279|5.601|so let's use a dictionary b
589.76|4.72|and this will map these bi-grams so
592.88|3.28|bi-gram is a tuple of character one
594.48|4.24|character two
596.16|4.88|and then b at bi-gram
598.72|4.48|will be b dot get of bi-gram
601.04|3.6|which is basically the same as b at
603.2|3.84|bigram
604.64|4.72|but in the case that bigram is not in
607.04|4.799|the dictionary b we would like to by
609.36|3.68|default return to zero
611.839|3.68|plus one
613.04|5.2|so this will basically add up all the
615.519|4.721|bigrams and count how often they occur
618.24|4.159|let's get rid of printing
620.24|3.76|or rather
622.399|4.721|let's keep the printing and let's just
624.0|5.279|inspect what b is in this case
627.12|4.0|and we see that many bi-grams occur just
629.279|3.68|a single time this one allegedly
631.12|4.24|occurred three times
632.959|4.961|so a was an ending character three times
635.36|6.56|and that's true for all of these words
637.92|8.68|all of emma olivia and eva and with a
641.92|4.68|so that's why this occurred three times
646.64|3.84|now let's do it for all the words
651.279|5.441|oops i should not have printed
655.04|3.68|i'm going to erase that
656.72|3.84|let's kill this
658.72|3.6|let's just run
660.56|3.519|and now b will have the statistics of
662.32|3.519|the entire data set
664.079|4.241|so these are the counts across all the
665.839|4.081|words of the individual pie grams
668.32|3.199|and we could for example look at some of
669.92|3.44|the most common ones and least common
671.519|3.521|ones
673.36|4.08|this kind of grows in python but the way
675.04|4.479|to do this the simplest way i like is we
677.44|4.32|just use b dot items
679.519|4.801|b dot items returns
681.76|5.28|the tuples of
684.32|4.88|key value in this case the keys are
687.04|3.84|the character diagrams and the values
689.2|3.199|are the counts
690.88|3.92|and so then what we want to do is we
692.399|2.401|want to do
695.68|6.719|sorted of this
698.399|4.0|but by default sort is on the first
703.519|4.0|on the first item of a tuple but we want
705.92|3.359|to sort by the values which are the
707.519|3.12|second element of a tuple that is the
709.279|3.68|key value
710.639|4.64|so we want to use the key
712.959|4.641|equals lambda
715.279|3.601|that takes the key value
717.6|4.64|and returns
718.88|5.68|the key value at the one not at zero but
722.24|4.88|at one which is the count so we want to
724.56|5.839|sort by the count
727.12|5.519|of these elements
730.399|4.24|and actually we wanted to go backwards
732.639|4.561|so here we have is
734.639|3.76|the bi-gram q and r occurs only a single
737.2|3.439|time
738.399|3.44|dz occurred only a single time
740.639|2.721|and when we sort this the other way
741.839|3.44|around
743.36|4.96|we're going to see the most likely
745.279|5.36|bigrams so we see that n was
748.32|4.639|very often an ending character
750.639|3.76|many many times and apparently n almost
752.959|3.201|always follows an a
754.399|4.24|and that's a very likely combination as
756.16|3.679|well
758.639|3.281|so
759.839|5.041|this is kind of the individual counts
761.92|4.159|that we achieve over the entire data set
764.88|3.44|now it's actually going to be
766.079|3.681|significantly more convenient for us to
768.32|3.36|keep this information in a
769.76|3.84|two-dimensional array instead of a
771.68|2.8|python dictionary
773.6|3.12|so
774.48|4.0|we're going to store this information
776.72|3.28|in a 2d array
778.48|2.96|and
780.0|3.44|the rows are going to be the first
781.44|3.839|character of the bigram and the columns
783.44|3.44|are going to be the second character and
785.279|3.601|each entry in this two-dimensional array
786.88|4.399|will tell us how often that first
788.88|3.759|character files the second character in
791.279|3.36|the data set
792.639|3.44|so in particular the array
794.639|4.161|representation that we're going to use
796.079|4.161|or the library is that of pytorch
798.8|3.599|and pytorch is a deep
800.24|4.96|learning neural network framework but
802.399|3.761|part of it is also this torch.tensor
805.2|2.8|which allows us to create
806.16|3.6|multi-dimensional arrays and manipulate
808.0|2.72|them very efficiently
809.76|2.96|so
810.72|4.0|let's import pytorch which you can do by
812.72|3.6|import torch
814.72|2.72|and then we can create
816.32|4.319|arrays
817.44|5.44|so let's create a array of zeros
820.639|3.921|and we give it a
822.88|4.16|size of this array let's create a three
824.56|4.0|by five array as an example
827.04|4.479|and
828.56|5.279|this is a three by five array of zeros
831.519|5.041|and by default you'll notice a.d type
833.839|4.321|which is short for data type is float32
836.56|2.88|so these are single precision floating
838.16|3.6|point numbers
839.44|4.88|because we are going to represent counts
841.76|4.24|let's actually use d type as torch dot
844.32|3.44|and 32
846.0|4.079|so these are
847.76|5.04|32-bit integers
850.079|4.481|so now you see that we have integer data
852.8|4.56|inside this tensor
854.56|4.399|now tensors allow us to really
857.36|3.36|manipulate all the individual entries
858.959|3.921|and do it very efficiently
860.72|2.96|so for example if we want to change this
862.88|3.04|bit
863.68|6.0|we have to index into the tensor and in
865.92|5.52|particular here this is the first row
869.68|4.48|and the
871.44|6.399|because it's zero indexed so this is row
874.16|4.56|index one and column index zero one two
877.839|4.0|three
878.72|4.88|so a at one comma three we can set that
881.839|5.201|to one
883.6|5.12|and then a we'll have a 1 over there
887.04|5.44|we can of course also do things like
888.72|5.119|this so now a will be 2 over there
892.48|3.599|or 3.
893.839|3.36|and also we can for example say a 0 0 is
896.079|4.0|5
897.199|5.041|and then a will have a 5 over here
900.079|4.241|so that's how we can index into the
902.24|4.24|arrays now of course the array that we
904.32|4.48|are interested in is much much bigger so
906.48|3.44|for our purposes we have 26 letters of
908.8|3.599|the alphabet
909.92|4.08|and then we have two special characters
912.399|5.761|s and e
914.0|5.199|so uh we want 26 plus 2 or 28 by 28
918.16|2.96|array
919.199|3.361|and let's call it the capital n because
921.12|3.36|it's going to represent sort of the
922.56|4.16|counts
924.48|4.24|let me erase this stuff
926.72|3.679|so that's the array that starts at zeros
928.72|4.96|28 by 28
930.399|4.161|and now let's copy paste this
933.68|3.279|here
934.56|4.56|but instead of having a dictionary b
936.959|4.0|which we're going to erase we now have
939.12|3.279|an n
940.959|3.201|now the problem here is that we have
942.399|3.12|these characters which are strings but
944.16|3.919|we have to now
945.519|4.961|um basically index into a
948.079|4.0|um array and we have to index using
950.48|4.719|integers so we need some kind of a
952.079|4.721|lookup table from characters to integers
955.199|2.801|so let's construct such a character
956.8|2.479|array
958.0|3.12|and the way we're going to do this is
959.279|3.441|we're going to take all the words which
961.12|3.2|is a list of strings
962.72|3.28|we're going to concatenate all of it
964.32|3.28|into a massive string so this is just
966.0|3.199|simply the entire data set as a single
967.6|3.2|string
969.199|4.32|we're going to pass this to the set
970.8|3.599|constructor which takes this massive
973.519|3.44|string
974.399|4.481|and throws out duplicates because sets
976.959|4.161|do not allow duplicates
978.88|5.28|so set of this will just be the set of
981.12|4.88|all the lowercase characters
984.16|4.08|and there should be a total of 26 of
986.0|2.24|them
988.56|4.079|and now we actually don't want a set we
989.92|4.64|want a list
992.639|3.521|but we don't want a list sorted in some
994.56|3.04|weird arbitrary way we want it to be
996.16|3.599|sorted
997.6|4.239|from a to z
999.759|5.281|so sorted list
1001.839|3.201|so those are our characters
1005.6|4.32|now what we want is this lookup table as
1007.279|5.68|i mentioned so let's create a special
1009.92|5.839|s2i i will call it
1012.959|5.841|um s is string or character and this
1015.759|4.161|will be an s2i mapping
1018.8|5.44|for
1019.92|6.96|is in enumerate of these characters
1024.24|5.76|so enumerate basically gives us this
1026.88|5.439|iterator over the integer index and the
1030.0|5.199|actual element of the list and then we
1032.319|4.401|are mapping the character to the integer
1035.199|4.72|so s2i
1036.72|6.8|is a mapping from a to 0 b to 1 etc all
1039.919|3.601|the way from z to 25
1044.079|3.12|and that's going to be useful here but
1045.439|4.321|we actually also have to specifically
1047.199|6.401|set that s will be 26
1049.76|6.159|and s to i at e will be 27 right because
1053.6|4.48|z was 25.
1055.919|3.921|so those are the lookups and now we can
1058.08|3.44|come here and we can map
1059.84|2.88|both character 1 and character 2 to
1061.52|3.76|their integers
1062.72|6.64|so this will be s2i at character 1
1065.28|6.8|and ix2 will be s2i of character 2.
1069.36|6.319|and now we should be able to
1072.08|6.8|do this line but using our array so n at
1075.679|4.88|x1 ix2 this is the two-dimensional array
1078.88|4.08|indexing i've shown you before
1080.559|4.24|and honestly just plus equals one
1082.96|3.2|because everything starts at
1084.799|3.12|zero
1086.16|2.72|so this should
1087.919|5.041|work
1088.88|6.159|and give us a large 28 by 28 array
1092.96|3.92|of all these counts so
1095.039|4.081|if we print n
1096.88|4.96|this is the array but of course it looks
1099.12|4.559|ugly so let's erase this ugly mess and
1101.84|2.959|let's try to visualize it a bit more
1103.679|3.201|nicer
1104.799|4.0|so for that we're going to use a library
1106.88|3.44|called matplotlib
1108.799|3.681|so matplotlib allows us to create
1110.32|5.76|figures so we can do things like plt
1112.48|6.559|item show of the counter array
1116.08|5.839|so this is the 28x28 array
1119.039|4.801|and this is structure but even this i
1121.919|3.76|would say is still pretty ugly
1123.84|3.68|so we're going to try to create a much
1125.679|4.0|nicer visualization of it and i wrote a
1127.52|4.32|bunch of code for that
1129.679|4.161|the first thing we're going to need is
1131.84|5.52|we're going to need to invert
1133.84|5.92|this array here this dictionary so s2i
1137.36|4.88|is mapping from s to i
1139.76|4.72|and in i2s we're going to reverse this
1142.24|4.319|dictionary so iterator of all the items
1144.48|3.84|and just reverse that array
1146.559|6.0|so i2s
1148.32|5.84|maps inversely from 0 to a 1 to b etc
1152.559|3.601|so we'll need that
1154.16|3.44|and then here's the code that i came up
1156.16|3.84|with to try to make this a little bit
1157.6|2.4|nicer
1160.48|2.88|we create a figure
1162.0|2.4|we plot
1163.36|2.72|n
1164.4|3.6|and then we do and then we visualize a
1166.08|5.2|bunch of things later let me just run it
1168.0|3.28|so you get a sense of what this is
1171.919|3.361|okay
1172.96|4.16|so you see here that we have
1175.28|4.56|the array spaced out
1177.12|5.2|and every one of these is basically like
1179.84|4.8|b follows g zero times
1182.32|5.52|b follows h 41 times
1184.64|4.64|um so a follows j 175 times
1187.84|5.04|and so what you can see that i'm doing
1189.28|4.96|here is first i show that entire array
1192.88|3.84|and then i iterate over all the
1194.24|5.04|individual little cells here
1196.72|5.839|and i create a character string here
1199.28|5.92|which is the inverse mapping i2s of the
1202.559|4.161|integer i and the integer j so those are
1205.2|3.359|the bi-grams in a character
1206.72|5.28|representation
1208.559|5.6|and then i plot just the diagram text
1212.0|4.0|and then i plot the number of times that
1214.159|3.361|this bigram occurs
1216.0|4.0|now the reason that there's a dot item
1217.52|5.44|here is because when you index into
1220.0|5.919|these arrays these are torch tensors
1222.96|5.12|you see that we still get a tensor back
1225.919|4.0|so the type of this thing you'd think it
1228.08|3.839|would be just an integer 149 but it's
1229.919|2.961|actually a torch.tensor
1231.919|3.441|and so
1232.88|5.52|if you do dot item then it will pop out
1235.36|5.28|that in individual integer
1238.4|4.08|so it will just be 149.
1240.64|3.12|so that's what's happening there and
1242.48|2.72|these are just some options to make it
1243.76|4.88|look nice
1245.2|3.44|so what is the structure of this array
1249.12|3.039|we have all these counts and we see that
1250.48|3.439|some of them occur often and some of
1252.159|3.841|them do not occur often
1253.919|3.201|now if you scrutinize this carefully you
1256.0|2.559|will notice that we're not actually
1257.12|3.439|being very clever
1258.559|3.681|that's because when you come over here
1260.559|4.161|you'll notice that for example we have
1262.24|4.72|an entire row of completely zeros and
1264.72|3.92|that's because the end character
1266.96|3.199|is never possibly going to be the first
1268.64|3.76|character of a bi-gram because we're
1270.159|4.081|always placing these end tokens all at
1272.4|4.399|the end of the diagram
1274.24|5.36|similarly we have entire columns zeros
1276.799|4.561|here because the s
1279.6|4.079|character will never possibly be the
1281.36|4.24|second element of a bigram because we
1283.679|3.921|always start with s and we end with e
1285.6|4.48|and we only have the words in between
1287.6|4.64|so we have an entire column of zeros an
1290.08|4.24|entire row of zeros and in this little
1292.24|4.559|two by two matrix here as well the only
1294.32|4.16|one that can possibly happen is if s
1296.799|4.561|directly follows e
1298.48|5.12|that can be non-zero if we have a word
1301.36|3.52|that has no letters so in that case
1303.6|3.84|there's no letters in the word it's an
1304.88|5.2|empty word and we just have s follows e
1307.44|4.239|but the other ones are just not possible
1310.08|3.599|and so we're basically wasting space and
1311.679|3.841|not only that but the s and the e are
1313.679|3.761|getting very crowded here
1315.52|3.44|i was using these brackets because
1317.44|2.88|there's convention and natural language
1318.96|4.16|processing to use these kinds of
1320.32|4.8|brackets to denote special tokens
1323.12|3.76|but we're going to use something else
1325.12|3.039|so let's fix all this and make it
1326.88|2.64|prettier
1328.159|2.961|we're not actually going to have two
1329.52|3.44|special tokens we're only going to have
1331.12|2.559|one special token
1332.96|2.48|so
1333.679|5.12|we're going to have n by n
1335.44|4.96|array of 27 by 27 instead
1338.799|3.601|instead of having two
1340.4|4.24|we will just have one and i will call it
1342.4|4.88|a dot
1344.64|5.76|okay
1347.28|4.399|let me swing this over here
1350.4|3.12|now one more thing that i would like to
1351.679|4.48|do is i would actually like to make this
1353.52|4.24|special character half position zero
1356.159|3.601|and i would like to offset all the other
1357.76|2.72|letters off i find that a little bit
1359.76|2.799|more
1360.48|4.16|pleasing
1362.559|3.841|so
1364.64|3.84|we need a plus one here so that the
1366.4|3.36|first character which is a will start at
1368.48|2.72|one
1369.76|6.08|so s2i
1371.2|5.52|will now be a starts at one and dot is 0
1375.84|3.04|and
1376.72|3.76|i2s of course we're not changing this
1378.88|4.0|because i2s just creates a reverse
1380.48|3.84|mapping and this will work fine so 1 is
1382.88|3.6|a 2 is b
1384.32|4.719|0 is dot
1386.48|3.76|so we've reversed that here
1389.039|3.841|we have
1390.24|4.48|a dot and a dot
1392.88|4.96|this should work fine
1394.72|4.0|make sure i start at zeros
1397.84|2.719|count
1398.72|3.839|and then here we don't go up to 28 we go
1400.559|5.681|up to 27
1402.559|3.681|and this should just work
1410.799|2.801|okay
1411.679|3.681|so we see that dot never happened it's
1413.6|2.8|at zero because we don't have empty
1415.36|3.6|words
1416.4|4.32|then this row here now is just uh very
1418.96|5.92|simply the um
1420.72|7.04|counts for all the first letters so
1424.88|5.279|uh j starts a word h starts a word i
1427.76|4.0|starts a word etc and then these are all
1430.159|2.801|the ending
1431.76|2.88|characters
1432.96|4.0|and in between we have the structure of
1434.64|4.88|what characters follow each other
1436.96|3.76|so this is the counts array of our
1439.52|3.759|entire
1440.72|4.24|data set so this array actually has all
1443.279|4.161|the information necessary for us to
1444.96|4.64|actually sample from this bigram
1447.44|4.32|uh character level language model
1449.6|3.6|and um roughly speaking what we're going
1451.76|3.12|to do is we're just going to start
1453.2|3.52|following these probabilities and these
1454.88|3.84|counts and we're going to start sampling
1456.72|3.76|from the from the model
1458.72|4.959|so in the beginning of course
1460.48|4.079|we start with the dot the start token
1463.679|3.761|dot
1464.559|5.921|so to sample the first character of a
1467.44|5.2|name we're looking at this row here
1470.48|4.079|so we see that we have the counts and
1472.64|4.56|those concepts terminally are telling us
1474.559|4.961|how often any one of these characters is
1477.2|4.64|to start a word
1479.52|5.2|so if we take this n
1481.84|5.6|and we grab the first row
1484.72|3.6|we can do that by using just indexing as
1487.44|4.16|zero
1488.32|5.28|and then using this notation column for
1491.6|4.88|the rest of that row
1493.6|5.199|so n zero colon
1496.48|4.079|is indexing into the zeroth
1498.799|3.12|row and then it's grabbing all the
1500.559|2.961|columns
1501.919|3.281|and so this will give us a
1503.52|4.8|one-dimensional array
1505.2|5.76|of the first row so zero four four ten
1508.32|4.88|you know zero four four ten one three oh
1510.96|4.719|six one five four two etc it's just the
1513.2|6.64|first row the shape of this
1515.679|5.441|is 27 it's just the row of 27
1519.84|2.56|and the other way that you can do this
1521.12|2.559|also is you just you don't need to
1522.4|3.68|actually give this
1523.679|4.401|you just grab the zeroth row like this
1526.08|3.839|this is equivalent
1528.08|3.68|now these are the counts
1529.919|5.041|and now what we'd like to do is we'd
1531.76|4.32|like to basically um sample from this
1534.96|2.319|since these are the raw counts we
1536.08|3.04|actually have to convert this to
1537.279|5.52|probabilities
1539.12|5.84|so we create a probability vector
1542.799|5.36|so we'll take n of zero
1544.96|4.959|and we'll actually convert this to float
1548.159|3.601|first
1549.919|2.801|okay so these integers are converted to
1551.76|2.799|float
1552.72|3.52|floating point numbers and the reason
1554.559|4.24|we're creating floats is because we're
1556.24|4.559|about to normalize these counts
1558.799|4.961|so to create a probability distribution
1560.799|5.12|here we want to divide
1563.76|4.56|we basically want to do p p p divide p
1565.919|2.401|that sum
1569.6|4.079|and now we get a vector of smaller
1571.44|3.76|numbers and these are now probabilities
1573.679|5.041|so of course because we divided by the
1575.2|5.2|sum the sum of p now is 1.
1578.72|3.839|so this is a nice proper probability
1580.4|3.92|distribution it sums to 1 and this is
1582.559|3.441|giving us the probability for any single
1584.32|3.599|character to be the first
1586.0|3.6|character of a word
1587.919|3.601|so now we can try to sample from this
1589.6|3.4|distribution to sample from these
1591.52|3.36|distributions we're going to use
1593.0|3.08|storch.multinomial which i've pulled up
1594.88|5.44|here
1596.08|4.24|so torch.multinomial returns uh
1600.48|3.84|samples from the multinomial probability
1602.24|4.16|distribution which is a complicated way
1604.32|4.08|of saying you give me probabilities and
1606.4|3.04|i will give you integers which are
1608.4|3.12|sampled
1609.44|3.68|according to the property distribution
1611.52|3.2|so this is the signature of the method
1613.12|4.24|and to make everything deterministic
1614.72|4.48|we're going to use a generator object in
1617.36|3.52|pytorch
1619.2|3.28|so this makes everything deterministic
1620.88|3.2|so when you run this on your computer
1622.48|3.36|you're going to the exact get the exact
1624.08|3.12|same results that i'm getting here on my
1625.84|4.8|computer
1627.2|3.44|so let me show you how this works
1632.64|5.519|here's the deterministic way of creating
1635.36|4.64|a torch generator object
1638.159|3.041|seeding it with some number that we can
1640.0|3.6|agree on
1641.2|3.599|so that seeds a generator gets gives us
1643.6|2.88|an object g
1644.799|3.521|and then we can pass that g
1646.48|3.679|to a function
1648.32|4.32|that creates um
1650.159|5.041|here random numbers twerk.rand creates
1652.64|4.88|random numbers three of them
1655.2|5.199|and it's using this generator object to
1657.52|4.32|as a source of randomness
1660.399|3.841|so
1661.84|4.64|without normalizing it
1664.24|4.159|i can just print
1666.48|4.24|this is sort of like numbers between 0
1668.399|4.64|and 1 that are random according to this
1670.72|3.839|thing and whenever i run it again
1673.039|3.201|i'm always going to get the same result
1674.559|4.161|because i keep using the same generator
1676.24|5.36|object which i'm seeing here
1678.72|5.28|and then if i divide
1681.6|4.319|to normalize i'm going to get a nice
1684.0|3.52|probability distribution of just three
1685.919|3.36|elements
1687.52|4.08|and then we can use torsion multinomial
1689.279|4.321|to draw samples from it so this is what
1691.6|5.12|that looks like
1693.6|4.72|tertiary multinomial we'll take the
1696.72|4.24|torch tensor
1698.32|4.16|of probability distributions
1700.96|3.52|then we can ask for a number of samples
1702.48|4.48|let's say 20.
1704.48|4.319|replacement equals true means that when
1706.96|3.92|we draw an element
1708.799|4.161|we will uh we can draw it and then we
1710.88|4.88|can put it back into the list of
1712.96|4.48|eligible indices to draw again
1715.76|4.0|and we have to specify replacement as
1717.44|4.08|true because by default uh for some
1719.76|3.2|reason it's false
1721.52|2.72|and i think
1722.96|2.719|you know it's just something to be
1724.24|3.36|careful with
1725.679|3.6|and the generator is passed in here so
1727.6|4.24|we're going to always get deterministic
1729.279|4.4|results the same results so if i run
1731.84|3.439|these two
1733.679|3.441|we're going to get a bunch of samples
1735.279|3.601|from this distribution
1737.12|3.279|now you'll notice here that the
1738.88|5.6|probability for the
1740.399|7.841|first element in this tensor is 60
1744.48|6.079|so in these 20 samples we'd expect 60 of
1748.24|4.559|them to be zero
1750.559|3.6|we'd expect thirty percent of them to be
1752.799|4.641|one
1754.159|5.52|and because the the element index two
1757.44|4.8|has only ten percent probability very
1759.679|4.401|few of these samples should be two and
1762.24|3.039|indeed we only have a small number of
1764.08|4.8|twos
1765.279|5.76|and we can sample as many as we'd like
1768.88|4.399|and the more we sample the more
1771.039|4.801|these numbers should um roughly have the
1773.279|5.041|distribution here
1775.84|5.76|so we should have lots of zeros
1778.32|6.56|half as many um
1781.6|4.48|ones and we should have um three times
1784.88|4.159|as few
1786.08|4.4|oh sorry s few ones and three times as
1789.039|2.64|few uh
1790.48|2.96|twos
1791.679|4.0|so you see that we have very few twos we
1793.44|4.16|have some ones and most of them are zero
1795.679|3.12|so that's what torsion multinomial is
1797.6|3.439|doing
1798.799|3.76|for us here
1801.039|4.081|we are interested in this row we've
1802.559|2.561|created this
1805.6|4.0|p here
1806.799|4.561|and now we can sample from it
1809.6|3.199|so if we use the same
1811.36|3.039|seed
1812.799|5.281|and then we sample from this
1814.399|8.241|distribution let's just get one sample
1818.08|7.12|then we see that the sample is say 13.
1822.64|4.72|so this will be the index
1825.2|5.199|and let's you see how it's a tensor that
1827.36|5.52|wraps 13 we again have to use that item
1830.399|4.88|to pop out that integer
1832.88|4.48|and now index would be just the number
1835.279|4.88|13.
1837.36|6.16|and of course the um we can do
1840.159|4.88|we can map the i2s of ix to figure out
1843.52|4.48|exactly which character
1845.039|5.041|we're sampling here we're sampling m
1848.0|3.12|so we're saying that the first character
1850.08|2.959|is
1851.12|4.0|in our generation
1853.039|4.161|and just looking at the road here
1855.12|4.559|m was drawn and you we can see that m
1857.2|3.839|actually starts a large number of words
1859.679|4.961|uh m
1861.039|5.201|started 2 500 words out of 32 000 words
1864.64|3.279|so almost
1866.24|3.52|a bit less than 10 percent of the words
1867.919|5.281|start with them so this was actually a
1869.76|5.36|fairly likely character to draw
1873.2|3.28|um
1875.12|2.96|so that would be the first character of
1876.48|4.0|our work and now we can continue to
1878.08|4.8|sample more characters because now we
1880.48|4.16|know that m started
1882.88|4.0|m is already sampled
1884.64|4.879|so now to draw the next character we
1886.88|4.0|will come back here and we will look for
1889.519|3.121|the row
1890.88|3.679|that starts with m
1892.64|3.919|so you see m
1894.559|4.881|and we have a row here
1896.559|6.641|so we see that m dot is
1899.44|5.52|516 m a is this many and b is this many
1903.2|3.359|etc so these are the counts for the next
1904.96|3.599|row and that's the next character that
1906.559|3.441|we are going to now generate
1908.559|3.041|so i think we are ready to actually just
1910.0|2.72|write out the loop because i think
1911.6|2.88|you're starting to get a sense of how
1912.72|3.439|this is going to go
1914.48|3.36|the um
1916.159|6.161|we always begin at
1917.84|7.04|index 0 because that's the start token
1922.32|3.76|and then while true
1924.88|3.519|we're going to grab the row
1926.08|5.04|corresponding to index
1928.399|6.0|that we're currently on so that's p
1931.12|7.36|so that's n array at ix
1934.399|4.081|converted to float is rp
1939.039|5.601|then we normalize
1941.2|3.44|this p to sum to one
1945.279|5.441|i accidentally ran the infinite loop we
1948.24|5.52|normalize p to something one
1950.72|4.88|then we need this generator object
1953.76|3.2|now we're going to initialize up here
1955.6|4.319|and we're going to draw a single sample
1956.96|2.959|from this distribution
1960.799|5.76|and then this is going to tell us what
1962.799|5.921|index is going to be next
1966.559|3.12|if the index sampled is
1968.72|3.92|0
1969.679|5.681|then that's now the end token
1972.64|5.12|so we will break
1975.36|5.919|otherwise we are going to print
1977.76|3.519|s2i of ix
1982.24|2.559|i2s
1985.279|6.801|and uh that's pretty much it we're just
1987.84|6.0|uh this should work okay more
1992.08|4.88|so that's that's the name that we've
1993.84|7.28|sampled we started with m the next step
1996.96|4.16|was o then r and then dot
2001.36|5.039|and this dot we it here as well
2004.799|4.961|so
2006.399|3.361|let's now do this a few times
2009.919|6.64|so let's actually create an
2013.44|3.119|out list here
2017.12|2.559|and instead of printing we're going to
2018.559|5.201|append
2019.679|4.081|so out that append this character
2024.399|4.961|and then here let's just print it at the
2026.48|5.439|end so let's just join up all the outs
2029.36|4.0|and we're just going to print more okay
2031.919|3.12|now we're always getting the same result
2033.36|3.679|because of the generator
2035.039|5.041|so if we want to do this a few times we
2037.039|5.441|can go for i in range
2040.08|5.599|10 we can sample 10 names
2042.48|4.319|and we can just do that 10 times
2045.679|2.72|and these are the names that we're
2046.799|4.32|getting out
2048.399|2.72|let's do 20.
2054.24|2.24|i'll be honest with you this doesn't
2055.44|2.8|look right
2056.48|4.0|so i started a few minutes to convince
2058.24|4.159|myself that it actually is right
2060.48|4.32|the reason these samples are so terrible
2062.399|4.081|is that bigram language model
2064.8|2.879|is actually look just like really
2066.48|3.52|terrible
2067.679|3.281|we can generate a few more here
2070.0|3.2|and you can see that they're kind of
2070.96|5.199|like their name like a little bit like
2073.2|5.36|yanu o'reilly etc but they're just like
2076.159|4.321|totally messed up um
2078.56|4.319|and i mean the reason that this is so
2080.48|4.0|bad like we're generating h as a name
2082.879|4.321|but you have to think through
2084.48|5.28|it from the model's eyes it doesn't know
2087.2|5.28|that this h is the very first h all it
2089.76|6.079|knows is that h was previously and now
2092.48|4.56|how likely is h the last character well
2095.839|2.961|it's somewhat
2097.04|2.96|likely and so it just makes it last
2098.8|3.2|character it doesn't know that there
2100.0|4.4|were other things before it or there
2102.0|3.599|were not other things before it and so
2104.4|2.08|that's why it's generating all these
2105.599|2.48|like
2106.48|4.879|nonsense names
2108.079|3.28|another way to do this is
2111.92|2.56|to convince yourself that this is
2112.96|4.72|actually doing something reasonable even
2114.48|6.48|though it's so terrible is
2117.68|5.36|these little piece here are 27 right
2120.96|3.36|like 27.
2123.04|3.2|so how about if we did something like
2124.32|3.279|this
2126.24|2.64|instead of p having any structure
2127.599|3.121|whatsoever
2128.88|5.36|how about if p was just
2130.72|3.52|torch dot once
2134.88|4.479|of 27
2137.2|5.6|by default this is a float 32 so this is
2139.359|5.601|fine divide 27
2142.8|4.319|so what i'm doing here is this is the
2144.96|4.879|uniform distribution which will make
2147.119|5.201|everything equally likely
2149.839|4.321|and we can sample from that so let's see
2152.32|3.6|if that does any better
2154.16|3.28|okay so it's
2155.92|3.199|this is what you have from a model that
2157.44|4.0|is completely untrained where everything
2159.119|4.401|is equally likely so it's obviously
2161.44|5.6|garbage and then if we have a trained
2163.52|5.599|model which is trained on just bi-grams
2167.04|4.0|this is what we get so you can see that
2169.119|4.96|it is more name-like it is actually
2171.04|4.88|working it's just um
2174.079|3.76|my gram is so terrible and we have to do
2175.92|4.24|better now next i would like to fix an
2177.839|4.081|inefficiency that we have going on here
2180.16|4.16|because what we're doing here is we're
2181.92|4.48|always fetching a row of n from the
2184.32|3.36|counts matrix up ahead
2186.4|2.56|and then we're always doing the same
2187.68|3.12|things we're converting to float and
2188.96|3.84|we're dividing and we're doing this
2190.8|3.52|every single iteration of this loop and
2192.8|2.88|we just keep renormalizing these rows
2194.32|3.36|over and over again and it's extremely
2195.68|3.28|inefficient and wasteful so what i'd
2197.68|4.24|like to do is i'd like to actually
2198.96|5.119|prepare a matrix capital p that will
2201.92|3.679|just have the probabilities in it so in
2204.079|4.0|other words it's going to be the same as
2205.599|4.48|the capital n matrix here of counts but
2208.079|4.801|every single row will have the row of
2210.079|4.321|probabilities uh that is normalized to 1
2212.88|3.68|indicating the probability distribution
2214.4|3.52|for the next character given the
2216.56|4.96|character before it
2217.92|5.199|um as defined by which row we're in
2221.52|3.44|so basically what we'd like to do is
2223.119|3.361|we'd like to just do it up front here
2224.96|4.56|and then we would like to just use that
2226.48|6.4|row here so here we would like to just
2229.52|5.36|do p equals p of ix instead
2232.88|3.12|okay
2234.88|2.88|the other reason i want to do this is
2236.0|3.359|not just for efficiency but also i would
2237.76|3.76|like us to practice
2239.359|4.24|these n-dimensional tensors and i'd like
2241.52|3.04|us to practice their manipulation and
2243.599|2.401|especially something that's called
2244.56|2.32|broadcasting that we'll go into in a
2246.0|2.16|second
2246.88|3.6|we're actually going to have to become
2248.16|3.84|very good at these tensor manipulations
2250.48|3.04|because if we're going to build out all
2252.0|3.359|the way to transformers we're going to
2253.52|4.4|be doing some pretty complicated um
2255.359|4.081|array operations for efficiency and we
2257.92|4.159|need to really understand that and be
2259.44|4.32|very good at it
2262.079|3.76|so intuitively what we want to do is we
2263.76|4.4|first want to grab the floating point
2265.839|3.52|copy of n
2268.16|2.72|and i'm mimicking the line here
2269.359|3.841|basically
2270.88|4.719|and then we want to divide all the rows
2273.2|4.159|so that they sum to 1.
2275.599|4.961|so we'd like to do something like this p
2277.359|3.921|divide p dot sum
2280.56|2.24|but
2281.28|4.0|now we have to be careful
2282.8|5.2|because p dot sum actually
2285.28|5.36|produces a sum
2288.0|6.96|sorry equals and that float copy
2290.64|6.32|p dot sum produces a um
2294.96|4.56|sums up all of the counts of this entire
2296.96|4.399|matrix n and gives us a single number of
2299.52|3.28|just the summation of everything so
2301.359|3.841|that's not the way we want to define
2302.8|4.799|divide we want to simultaneously and in
2305.2|5.36|parallel divide all the rows
2307.599|5.041|by their respective sums
2310.56|5.2|so what we have to do now is we have to
2312.64|4.64|go into documentation for torch.sum
2315.76|3.2|and we can scroll down here to a
2317.28|4.4|definition that is relevant to us which
2318.96|4.879|is where we don't only provide an input
2321.68|4.08|array that we want to sum but we also
2323.839|3.361|provide the dimension along which we
2325.76|4.079|want to sum
2327.2|3.84|and in particular we want to sum up
2329.839|2.481|over rows
2331.04|2.72|right
2332.32|3.92|now one more argument that i want you to
2333.76|4.079|pay attention to here is the keep them
2336.24|4.0|is false
2337.839|4.561|if keep them is true then the output
2340.24|3.52|tensor is of the same size as input
2342.4|3.439|except of course the dimension along
2343.76|3.52|which is summed which will become just
2345.839|6.161|one
2347.28|7.2|but if you pass in keep them as false
2352.0|4.8|then this dimension is squeezed out and
2354.48|4.32|so torch.sum not only does the sum and
2356.8|3.6|collapses dimension to be of size one
2358.8|3.36|but in addition it does what's called a
2360.4|4.16|squeeze where it squeezes out it
2362.16|3.6|squeezes out that dimension
2364.56|2.48|so
2365.76|3.28|basically what we want here is we
2367.04|3.68|instead want to do p dot sum of some
2369.04|3.44|axis
2370.72|4.8|and in particular notice that p dot
2372.48|5.359|shape is 27 by 27
2375.52|4.48|so when we sum up across axis zero then
2377.839|4.721|we would be taking the zeroth dimension
2380.0|4.96|and we would be summing across it
2382.56|4.4|so when keep them as true
2384.96|5.04|then this thing will not only give us
2386.96|4.879|the counts across um
2390.0|3.599|along the columns
2391.839|5.52|but notice that basically the shape of
2393.599|5.361|this is 1 by 27 we just get a row vector
2397.359|2.881|and the reason we get a row vector here
2398.96|3.52|again is because we passed in zero
2400.24|4.48|dimension so this zero dimension becomes
2402.48|4.16|one and we've done a sum
2404.72|3.359|and we get a row and so basically we've
2406.64|2.64|done the sum
2408.079|3.04|this way
2409.28|3.6|vertically and arrived at just a single
2411.119|4.081|1 by 27
2412.88|4.8|vector of counts
2415.2|5.04|what happens when you take out keep them
2417.68|5.84|is that we just get 27. so it squeezes
2420.24|7.599|out that dimension and we just get
2423.52|4.319|a one-dimensional vector of size 27.
2428.56|5.12|now we don't actually want
2431.28|6.16|one by 27 row vector because that gives
2433.68|5.679|us the counts or the sums across
2437.44|3.679|the columns
2439.359|3.921|we actually want to sum the other way
2441.119|5.121|along dimension one and you'll see that
2443.28|6.559|the shape of this is 27 by one so it's a
2446.24|6.56|column vector it's a 27 by one
2449.839|4.0|vector of counts
2452.8|2.319|okay
2453.839|3.121|and that's because what's happened here
2455.119|6.321|is that we're going horizontally and
2456.96|6.48|this 27 by 27 matrix becomes a 27 by 1
2461.44|4.879|array
2463.44|4.639|now you'll notice by the way that um the
2466.319|4.161|actual numbers
2468.079|4.481|of these counts are identical
2470.48|3.44|and that's because this special array of
2472.56|3.2|counts here comes from bi-gram
2473.92|3.76|statistics and actually it just so
2475.76|3.44|happens by chance
2477.68|3.36|or because of the way this array is
2479.2|4.24|constructed that the sums along the
2481.04|5.039|columns or along the rows horizontally
2483.44|3.919|or vertically is identical
2486.079|4.0|but actually what we want to do in this
2487.359|3.76|case is we want to sum across the
2490.079|3.76|rows
2491.119|6.081|horizontally so what we want here is p
2493.839|5.601|that sum of one with keep in true
2497.2|3.76|27 by one column vector
2499.44|4.24|and now what we want to do is we want to
2500.96|2.72|divide by that
2504.56|4.24|now we have to be careful here again is
2506.319|5.361|it possible to take
2508.8|6.4|what's a um p dot shape you see here 27
2511.68|7.52|by 27 is it possible to take a 27 by 27
2515.2|6.08|array and divide it by what is a 27 by 1
2519.2|4.56|array
2521.28|4.079|is that an operation that you can do
2523.76|3.04|and whether or not you can perform this
2525.359|4.161|operation is determined by what's called
2526.8|5.12|broadcasting rules so if you just search
2529.52|3.44|broadcasting semantics in torch
2531.92|2.399|you'll notice that there's a special
2532.96|3.92|definition for
2534.319|5.76|what's called broadcasting that uh for
2536.88|5.199|whether or not um these two uh arrays
2540.079|3.76|can be combined in a binary operation
2542.079|3.441|like division
2543.839|3.361|so the first condition is each tensor
2545.52|2.96|has at least one dimension which is the
2547.2|2.399|case for us
2548.48|2.8|and then when iterating over the
2549.599|2.72|dimension sizes starting at the trailing
2551.28|3.28|dimension
2552.319|3.921|the dimension sizes must either be equal
2554.56|3.44|one of them is one or one of them does
2556.24|2.64|not exist
2558.0|3.28|okay
2558.88|5.36|so let's do that we need to align the
2561.28|4.4|two arrays and their shapes which is
2564.24|3.76|very easy because both of these shapes
2565.68|4.48|have two elements so they're aligned
2568.0|4.24|then we iterate over from the from the
2570.16|5.28|right and going to the left
2572.24|4.8|each dimension must be either equal one
2575.44|3.76|of them is a one or one of them does not
2577.04|4.799|exist so in this case they're not equal
2579.2|4.0|but one of them is a one so this is fine
2581.839|2.161|and then this dimension they're both
2583.2|2.639|equal
2584.0|4.48|so uh this is fine
2585.839|5.0|so all the dimensions are fine and
2588.48|4.32|therefore the this operation is
2590.839|3.641|broadcastable so that means that this
2592.8|4.0|operation is allowed
2594.48|5.28|and what is it that these arrays do when
2596.8|4.88|you divide 27 by 27 by 27 by one
2599.76|4.4|what it does is that it takes this
2601.68|5.439|dimension one and it stretches it out it
2604.16|4.8|copies it to match
2607.119|3.601|27 here in this case
2608.96|3.84|so in our case it takes this column
2610.72|5.92|vector which is 27 by 1
2612.8|4.96|and it copies it 27 times
2616.64|3.92|to make
2617.76|4.4|these both be 27 by 27 internally you
2620.56|3.6|can think of it that way and so it
2622.16|3.36|copies those counts
2624.16|3.12|and then it does an element-wise
2625.52|3.2|division
2627.28|3.44|which is what we want because these
2628.72|4.24|counts we want to divide by them on
2630.72|4.0|every single one of these columns in
2632.96|3.52|this matrix
2634.72|2.96|so this actually we expect will
2636.48|3.119|normalize
2637.68|3.919|every single row
2639.599|4.48|and we can check that this is true by
2641.599|5.24|taking the first row for example and
2644.079|6.161|taking its sum we expect this to be
2646.839|6.201|1. because it's not normalized
2650.24|4.48|and then we expect this now because if
2653.04|3.84|we actually correctly normalize all the
2654.72|4.399|rows we expect to get the exact same
2656.88|4.88|result here so let's run this
2659.119|4.561|it's the exact same result
2661.76|3.44|this is correct so now i would like to
2663.68|3.52|scare you a little bit
2665.2|3.36|uh you actually have to like i basically
2667.2|3.2|encourage you very strongly to read
2668.56|3.2|through broadcasting semantics
2670.4|3.84|and i encourage you to treat this with
2671.76|4.0|respect and it's not something to play
2674.24|3.359|fast and loose with it's something to
2675.76|3.2|really respect really understand and
2677.599|2.881|look up maybe some tutorials for
2678.96|3.359|broadcasting and practice it and be
2680.48|3.68|careful with it because you can very
2682.319|4.321|quickly run into books let me show you
2684.16|2.48|what i mean
2687.119|3.281|you see how here we have p dot sum of
2688.64|4.56|one keep them as true
2690.4|5.199|the shape of this is 27 by one let me
2693.2|5.2|take out this line just so we have the n
2695.599|4.961|and then we can see the counts
2698.4|4.08|we can see that this is a all the counts
2700.56|2.88|across all the
2702.48|4.56|rows
2703.44|6.0|and it's a 27 by one column vector right
2707.04|3.36|now suppose that i tried to do the
2709.44|4.399|following
2710.4|5.52|but i erase keep them just true here
2713.839|4.24|what does that do if keep them is not
2715.92|4.32|true it's false then remember according
2718.079|4.961|to documentation it gets rid of this
2720.24|4.56|dimension one it squeezes it out so
2723.04|4.16|basically we just get all the same
2724.8|5.2|counts the same result except the shape
2727.2|4.399|of it is not 27 by 1 it is just 27 the
2730.0|4.16|one disappears
2731.599|6.321|but all the counts are the same
2734.16|5.84|so you'd think that this divide that
2737.92|4.159|would uh would work
2740.0|4.24|first of all can we even uh write this
2742.079|4.161|and will it is it even is it even
2744.24|3.359|expected to run is it broadcastable
2746.24|2.879|let's determine if this result is
2747.599|3.921|broadcastable
2749.119|3.681|p.summit one is shape
2751.52|6.0|is 27.
2752.8|4.72|this is 27 by 27. so 27 by 27
2757.599|6.081|broadcasting into 27. so now
2761.599|4.801|rules of broadcasting number one align
2763.68|4.08|all the dimensions on the right done now
2766.4|2.719|iteration over all the dimensions
2767.76|2.319|starting from the right going to the
2769.119|3.841|left
2770.079|4.881|all the dimensions must either be equal
2772.96|4.72|one of them must be one or one that does
2774.96|4.96|not exist so here they are all equal
2777.68|3.76|here the dimension does not exist
2779.92|4.32|so internally what broadcasting will do
2781.44|4.399|is it will create a one here
2784.24|3.52|and then
2785.839|4.401|we see that one of them is a one and
2787.76|4.64|this will get copied and this will run
2790.24|4.56|this will broadcast
2792.4|4.8|okay so you'd expect this
2794.8|2.4|to work
2797.28|2.96|because we we are
2801.2|2.32|this broadcast and this we can divide
2802.8|2.319|this
2803.52|3.12|now if i run this you'd expect it to
2805.119|2.72|work but
2806.64|3.04|it doesn't
2807.839|3.52|uh you actually get garbage you get a
2809.68|2.72|wrong dissolve because this is actually
2811.359|5.321|a bug
2812.4|4.28|this keep them equals true
2817.119|2.72|makes it work
2820.56|4.16|this is a bug
2822.8|4.48|in both cases we are doing
2824.72|4.48|the correct counts we are summing up
2827.28|3.6|across the rows
2829.2|3.44|but keep them is saving us and making it
2830.88|3.36|work so in this case
2832.64|3.12|i'd like to encourage you to potentially
2834.24|4.16|like pause this video at this point and
2835.76|6.16|try to think about why this is buggy and
2838.4|3.52|why the keep dim was necessary here
2842.16|2.24|okay
2842.96|3.599|so the reason to do
2844.4|3.439|for this is i'm trying to hint it here
2846.559|2.881|when i was sort of giving you a bit of a
2847.839|2.48|hint on how this works
2849.44|2.72|this
2850.319|4.081|27 vector
2852.16|4.24|internally inside the broadcasting this
2854.4|5.12|becomes a 1 by 27
2856.4|5.6|and 1 by 27 is a row vector right
2859.52|3.599|and now we are dividing 27 by 27 by 1 by
2862.0|3.839|27
2863.119|4.48|and torch will replicate this dimension
2865.839|3.841|so basically
2867.599|3.441|uh it will take
2869.68|3.919|it will take this
2871.04|4.24|row vector and it will copy it
2873.599|4.321|vertically now
2875.28|4.96|27 times so the 27 by 27 lies exactly
2877.92|4.24|and element wise divides
2880.24|4.079|and so basically what's happening here
2882.16|3.919|is
2884.319|5.04|we're actually normalizing the columns
2886.079|5.28|instead of normalizing the rows
2889.359|4.24|so you can check that what's happening
2891.359|4.881|here is that p at zero which is the
2893.599|4.96|first row of p dot sum
2896.24|4.48|is not one it's seven
2898.559|5.04|it is the first column as an example
2900.72|3.76|that sums to one
2903.599|2.641|so
2904.48|3.599|to summarize where does the issue come
2906.24|3.839|from the issue comes from the silent
2908.079|3.841|adding of a dimension here because in
2910.079|3.921|broadcasting rules you align on the
2911.92|4.159|right and go from right to left and if
2914.0|4.0|dimension doesn't exist you create it
2916.079|3.52|so that's where the problem happens we
2918.0|3.68|still did the counts correctly we did
2919.599|4.96|the counts across the rows and we got
2921.68|4.56|the the counts on the right here as a
2924.559|3.76|column vector but because the keep
2926.24|3.599|things was true this this uh this
2928.319|4.081|dimension was discarded and now we just
2929.839|4.24|have a vector of 27. and because of
2932.4|3.6|broadcasting the way it works this
2934.079|2.881|vector of 27 suddenly becomes a row
2936.0|2.88|vector
2936.96|4.0|and then this row vector gets replicated
2938.88|6.4|vertically and that every single point
2940.96|4.32|we are dividing by the by the count
2945.44|3.36|in the opposite direction
2947.28|4.319|so uh
2948.8|4.16|so this thing just uh doesn't work this
2951.599|2.561|needs to be keep things equal true in
2952.96|3.359|this case
2954.16|3.679|so then
2956.319|3.52|then we have that p at zero is
2957.839|3.841|normalized
2959.839|4.72|and conversely the first column you'd
2961.68|5.919|expect to potentially not be normalized
2964.559|6.481|and this is what makes it work
2967.599|5.441|so pretty subtle and uh hopefully this
2971.04|3.92|helps to scare you that you should have
2973.04|4.799|a respect for broadcasting be careful
2974.96|4.08|check your work uh and uh understand how
2977.839|2.561|it works under the hood and make sure
2979.04|2.799|that it's broadcasting in the direction
2980.4|3.679|that you like otherwise you're going to
2981.839|4.881|introduce very subtle bugs very hard to
2984.079|4.641|find bugs and uh just be careful one
2986.72|4.72|more note on efficiency we don't want to
2988.72|4.56|be doing this here because this creates
2991.44|2.879|a completely new tensor that we store
2993.28|3.12|into p
2994.319|3.441|we prefer to use in place operations if
2996.4|3.6|possible
2997.76|4.079|so this would be an in-place operation
3000.0|3.44|it has the potential to be faster it
3001.839|4.321|doesn't create new memory
3003.44|4.48|under the hood and then let's erase this
3006.16|2.959|we don't need it
3007.92|2.96|and let's
3009.119|4.48|also
3010.88|3.679|um just do fewer just so i'm not wasting
3013.599|2.321|space
3014.559|2.401|okay so we're actually in a pretty good
3015.92|3.36|spot now
3016.96|5.119|we trained a bigram language model and
3019.28|5.12|we trained it really just by counting uh
3022.079|4.24|how frequently any pairing occurs and
3024.4|3.439|then normalizing so that we get a nice
3026.319|4.721|property distribution
3027.839|4.881|so really these elements of this array p
3031.04|3.519|are really the parameters of our biogram
3032.72|4.16|language model giving us and summarizing
3034.559|4.081|the statistics of these bigrams
3036.88|3.6|so we train the model and then we know
3038.64|4.719|how to sample from a model we just
3040.48|5.04|iteratively uh sample the next character
3043.359|3.601|and feed it in each time and get a next
3045.52|2.96|character
3046.96|3.359|now what i'd like to do is i'd like to
3048.48|4.48|somehow evaluate the quality of this
3050.319|4.401|model we'd like to somehow summarize the
3052.96|4.48|quality of this model into a single
3054.72|4.24|number how good is it at predicting
3057.44|3.52|the training set
3058.96|5.2|and as an example so in the training set
3060.96|4.96|we can evaluate now the training loss
3064.16|2.72|and this training loss is telling us
3065.92|2.24|about
3066.88|3.12|sort of the quality of this model in a
3068.16|3.679|single number just like we saw in
3070.0|3.359|micrograd
3071.839|2.641|so let's try to think through the
3073.359|3.601|quality of the model and how we would
3074.48|3.599|evaluate it
3076.96|3.599|basically what we're going to do is
3078.079|4.801|we're going to copy paste this code
3080.559|3.52|that we previously used for counting
3082.88|2.719|okay
3084.079|3.681|and let me just print these diagrams
3085.599|4.081|first we're gonna use f strings
3087.76|3.2|and i'm gonna print character one
3089.68|3.2|followed by character two these are the
3090.96|3.2|diagrams and then i don't wanna do it
3092.88|4.719|for all the words just do the first
3094.16|5.919|three words so here we have emma olivia
3097.599|4.161|and ava bigrams
3100.079|4.561|now what we'd like to do is we'd like to
3101.76|4.96|basically look at the probability that
3104.64|3.439|the model assigns to every one of these
3106.72|2.72|diagrams
3108.079|3.04|so in other words we can look at the
3109.44|3.52|probability which is
3111.119|4.881|summarized in the matrix b
3112.96|4.96|of i x 1 x 2
3116.0|4.64|and then we can print it here
3117.92|4.08|as probability
3120.64|4.08|and because these properties are way too
3122.0|4.72|large let me present
3124.72|4.32|or call in 0.4 f
3126.72|3.599|to like truncate it a bit
3129.04|2.72|so what do we have here right we're
3130.319|2.8|looking at the probabilities that the
3131.76|3.359|model assigns to every one of these
3133.119|3.521|bigrams in the dataset
3135.119|3.44|and so we can see some of them are four
3136.64|3.28|percent three percent etc
3138.559|4.721|just to have a measuring stick in our
3139.92|5.439|mind by the way um we have 27 possible
3143.28|4.16|characters or tokens and if everything
3145.359|3.521|was equally likely then you'd expect all
3147.44|3.119|these probabilities
3148.88|3.52|to be
3150.559|3.76|four percent roughly
3152.4|3.52|so anything above four percent means
3154.319|3.76|that we've learned something useful from
3155.92|3.52|these bigram statistics and you see that
3158.079|2.801|roughly some of these are four percent
3159.44|2.399|but some of them are as high as 40
3160.88|3.52|percent
3161.839|3.76|35 percent and so on so you see that the
3164.4|3.04|model actually assigned a pretty high
3165.599|4.401|probability to whatever's in the
3167.44|4.24|training set and so that's a good thing
3170.0|3.2|um basically if you have a very good
3171.68|3.28|model you'd expect that these
3173.2|3.919|probabilities should be near one because
3174.96|3.68|that means that your model is correctly
3177.119|3.121|predicting what's going to come next
3178.64|4.16|especially on the training set where you
3180.24|3.44|where you trained your model
3182.8|2.48|so
3183.68|3.84|now we'd like to think about how can we
3185.28|4.16|summarize these probabilities into a
3187.52|4.16|single number that measures the quality
3189.44|3.76|of this model
3191.68|3.439|now when you look at the literature into
3193.2|4.0|maximum likelihood estimation and
3195.119|3.601|statistical modeling and so on
3197.2|4.159|you'll see that what's typically used
3198.72|4.879|here is something called the likelihood
3201.359|4.401|and the likelihood is the product of all
3203.599|3.681|of these probabilities
3205.76|3.68|and so the product of all these
3207.28|4.559|probabilities is the likelihood and it's
3209.44|5.52|really telling us about the probability
3211.839|5.76|of the entire data set assigned uh
3214.96|4.399|assigned by the model that we've trained
3217.599|3.601|and that is a measure of quality
3219.359|3.841|so the product of these
3221.2|3.44|should be as high as possible
3223.2|3.359|when you are training the model and when
3224.64|3.12|you have a good model your pro your
3226.559|2.8|product of these probabilities should be
3227.76|2.559|very high
3229.359|2.161|um
3230.319|3.121|now because the product of these
3231.52|3.52|probabilities is an unwieldy thing to
3233.44|3.52|work with you can see that all of them
3235.04|3.36|are between zero and one so your product
3236.96|3.119|of these probabilities will be a very
3238.4|2.48|tiny number
3240.079|1.681|um
3240.88|2.4|so
3241.76|3.2|for convenience what people work with
3243.28|2.799|usually is not the likelihood but they
3244.96|2.879|work with what's called the log
3246.079|2.801|likelihood
3247.839|2.961|so
3248.88|3.84|the product of these is the likelihood
3250.8|4.16|to get the log likelihood we just have
3252.72|4.399|to take the log of the probability
3254.96|4.72|and so the log of the probability here i
3257.119|4.801|have the log of x from zero to one
3259.68|4.879|the log is a you see here monotonic
3261.92|5.28|transformation of the probability
3264.559|4.161|where if you pass in one
3267.2|3.44|you get zero
3268.72|3.44|so probability one gets your log
3270.64|2.959|probability of zero
3272.16|3.52|and then as you go lower and lower
3273.599|3.76|probability the log will grow more and
3275.68|5.52|more negative until all the way to
3277.359|3.841|negative infinity at zero
3281.839|4.881|so here we have a log prob which is
3284.0|4.48|really just a torch.log of probability
3286.72|3.2|let's print it out to get a sense of
3288.48|3.119|what that looks like
3289.92|4.72|log prob
3291.599|3.041|also 0.4 f
3294.72|3.839|okay
3296.559|4.081|so as you can see when we plug in
3298.559|3.76|numbers that are very close some of our
3300.64|2.719|higher numbers we get closer and closer
3302.319|2.641|to zero
3303.359|3.2|and then if we plug in very bad
3304.96|4.56|probabilities we get more and more
3306.559|4.24|negative number that's bad
3309.52|2.88|so
3310.799|4.401|and the reason we work with this is for
3312.4|4.48|a large extent convenience right
3315.2|3.68|because we have mathematically that if
3316.88|4.239|you have some product a times b times c
3318.88|4.8|of all these probabilities right
3321.119|4.24|the likelihood is the product of all
3323.68|3.679|these probabilities
3325.359|3.041|then the log
3327.359|3.44|of these
3328.4|4.88|is just log of a plus
3330.799|2.481|log of b
3333.68|3.76|plus log of c if you remember your logs
3336.16|3.52|from your
3337.44|4.0|high school or undergrad and so on
3339.68|2.8|so we have that basically
3341.44|3.2|the likelihood of the product
3342.48|4.4|probabilities the log likelihood is just
3344.64|4.159|the sum of the logs of the individual
3346.88|3.12|probabilities
3348.799|3.921|so
3350.0|4.559|log likelihood
3352.72|4.399|starts at zero
3354.559|5.681|and then log likelihood here we can just
3357.119|3.121|accumulate simply
3360.319|3.52|and in the end we can print this
3365.359|3.281|print the log likelihood
3369.52|4.319|f strings
3371.68|6.639|maybe you're familiar with this
3373.839|4.48|so log likelihood is negative 38.
3379.92|2.56|okay
3381.28|3.92|now
3382.48|5.359|we actually want um
3385.2|5.119|so how high can log likelihood get it
3387.839|4.081|can go to zero so when all the
3390.319|3.28|probabilities are one log likelihood
3391.92|3.52|will be zero and then when all the
3393.599|3.841|probabilities are lower this will grow
3395.44|4.32|more and more negative
3397.44|4.399|now we don't actually like this because
3399.76|4.88|what we'd like is a loss function and a
3401.839|4.321|loss function has the semantics that low
3404.64|2.8|is good
3406.16|4.159|because we're trying to minimize the
3407.44|4.32|loss so we actually need to invert this
3410.319|5.201|and that's what gives us something
3411.76|3.76|called the negative log likelihood
3415.92|5.679|negative log likelihood is just negative
3418.559|3.04|of the log likelihood
3423.76|2.64|these are f strings by the way if you'd
3425.04|4.24|like to look this up
3426.4|4.48|negative log likelihood equals
3429.28|3.6|so negative log likelihood now is just
3430.88|4.719|negative of it and so the negative log
3432.88|4.719|block load is a very nice loss function
3435.599|4.081|because um
3437.599|4.561|the lowest it can get is zero
3439.68|4.96|and the higher it is the worse off the
3442.16|3.84|predictions are that you're making
3444.64|3.28|and then one more modification to this
3446.0|3.839|that sometimes people do is that for
3447.92|4.24|convenience uh they actually like to
3449.839|4.48|normalize by they like to make it an
3452.16|4.88|average instead of a sum
3454.319|4.961|and so uh here
3457.04|4.4|let's just keep some counts as well
3459.28|3.519|so n plus equals one
3461.44|2.56|starts at zero
3462.799|3.361|and then here
3464.0|3.76|um we can have sort of like a normalized
3466.16|3.84|log likelihood
3467.76|2.24|um
3470.4|4.24|if we just normalize it by the count
3472.4|4.48|then we will sort of get the average
3474.64|4.56|log likelihood so this would be
3476.88|5.199|usually our loss function here is what
3479.2|4.72|this we would this is what we would use
3482.079|4.48|uh so our loss function for the training
3483.92|4.56|set assigned by the model is 2.4 that's
3486.559|3.841|the quality of this model
3488.48|3.52|and the lower it is the better off we
3490.4|2.959|are and the higher it is the worse off
3492.0|2.24|we are
3493.359|3.681|and
3494.24|5.28|the job of our you know training is to
3497.04|5.759|find the parameters that minimize the
3499.52|5.039|negative log likelihood loss
3502.799|3.681|and that would be like a high quality
3504.559|3.441|model okay so to summarize i actually
3506.48|4.319|wrote it out here
3508.0|3.92|so our goal is to maximize likelihood
3510.799|3.201|which is the
3511.92|3.6|product of all the probabilities
3514.0|3.52|assigned by the model
3515.52|4.24|and we want to maximize this likelihood
3517.52|4.4|with respect to the model parameters and
3519.76|4.16|in our case the model parameters here
3521.92|3.52|are defined in the table these numbers
3523.92|2.48|the probabilities
3525.44|2.399|are
3526.4|3.919|the model parameters sort of in our
3527.839|4.161|program language models so far but you
3530.319|3.361|have to keep in mind that here we are
3532.0|3.839|storing everything in a table format the
3533.68|4.8|probabilities but what's coming up as a
3535.839|4.881|brief preview is that these numbers will
3538.48|4.56|not be kept explicitly but these numbers
3540.72|3.76|will be calculated by a neural network
3543.04|3.2|so that's coming up
3544.48|3.68|and we want to change and tune the
3546.24|3.359|parameters of these neural networks we
3548.16|3.28|want to change these parameters to
3549.599|3.681|maximize the likelihood the product of
3551.44|3.6|the probabilities
3553.28|3.2|now maximizing the likelihood is
3555.04|3.6|equivalent to maximizing the log
3556.48|3.359|likelihood because log is a monotonic
3558.64|3.36|function
3559.839|4.48|here's the graph of log
3562.0|5.119|and basically all it is doing is it's
3564.319|5.04|just scaling your um you can look at it
3567.119|5.361|as just a scaling of the loss function
3569.359|5.041|and so the optimization problem here and
3572.48|3.52|here are actually equivalent because
3574.4|2.56|this is just scaling you can look at it
3576.0|2.64|that way
3576.96|4.08|and so these are two identical
3578.64|3.199|optimization problems
3581.04|2.079|um
3581.839|2.72|maximizing the log-likelihood is
3583.119|3.921|equivalent to minimizing the negative
3584.559|4.24|log likelihood and then in practice
3587.04|3.759|people actually minimize the average
3588.799|4.081|negative log likelihood to get numbers
3590.799|4.401|like 2.4
3592.88|4.479|and then this summarizes the quality of
3595.2|4.399|your model and we'd like to minimize it
3597.359|4.96|and make it as small as possible
3599.599|4.561|and the lowest it can get is zero
3602.319|3.601|and the lower it is
3604.16|3.28|the better off your model is because
3605.92|3.919|it's signing it's assigning high
3607.44|3.84|probabilities to your data now let's
3609.839|2.881|estimate the probability over the entire
3611.28|4.079|training set just to make sure that we
3612.72|4.48|get something around 2.4 let's run this
3615.359|5.281|over the entire oops
3617.2|7.2|let's take out the print segment as well
3620.64|5.04|okay 2.45 or the entire training set
3624.4|2.159|now what i'd like to show you is that
3625.68|2.56|you can actually evaluate the
3626.559|3.841|probability for any word that you want
3628.24|4.64|like for example
3630.4|5.36|if we just test a single word andre and
3632.88|4.239|bring back the print statement
3635.76|4.88|then you see that andre is actually kind
3637.119|4.561|of like an unlikely word like on average
3640.64|1.919|we take
3641.68|3.119|three
3642.559|3.921|log probability to represent it and
3644.799|5.201|roughly that's because ej apparently is
3646.48|4.72|very uncommon as an example
3650.0|3.76|now
3651.2|4.72|think through this um
3653.76|6.0|when i take andre and i append q and i
3655.92|3.84|test the probability of it under q
3660.16|2.8|we actually get
3661.68|3.919|infinity
3662.96|4.72|and that's because jq has a zero percent
3665.599|3.681|probability according to our model so
3667.68|3.52|the log likelihood
3669.28|5.12|so the log of zero will be negative
3671.2|4.48|infinity we get infinite loss
3674.4|2.48|so this is kind of undesirable right
3675.68|3.439|because we plugged in a string that
3676.88|3.6|could be like a somewhat reasonable name
3679.119|3.281|but basically what this is saying is
3680.48|4.96|that this model is exactly zero percent
3682.4|4.0|likely to uh to predict this
3685.44|4.24|name
3686.4|5.04|and our loss is infinity on this example
3689.68|3.119|and really what the reason for that is
3691.44|3.52|that j
3692.799|4.081|is followed by q
3694.96|5.68|uh zero times
3696.88|5.28|uh where's q jq is zero and so jq is uh
3700.64|2.959|zero percent likely
3702.16|3.439|so it's actually kind of gross and
3703.599|3.441|people don't like this too much to fix
3705.599|3.681|this there's a very simple fix that
3707.04|3.36|people like to do to sort of like smooth
3709.28|3.279|out your model a little bit and it's
3710.4|3.52|called model smoothing and roughly
3712.559|3.681|what's happening is that we will eight
3713.92|3.199|we will add some fake counts
3716.24|3.04|so
3717.119|3.761|imagine adding a count of one to
3719.28|4.079|everything
3720.88|3.679|so we add a count of one
3723.359|2.161|like this
3724.559|3.121|and then we recalculate the
3725.52|3.68|probabilities
3727.68|3.2|and that's model smoothing and you can
3729.2|3.599|add as much as you like you can add five
3730.88|3.84|and it will give you a smoother model
3732.799|3.04|and the more you add here
3734.72|3.04|the more
3735.839|3.76|uniform model you're going to have and
3737.76|3.359|the less you add
3739.599|2.641|the more peaked model you are going to
3741.119|3.761|have of course
3742.24|3.44|so one is like a pretty decent count to
3744.88|2.64|add
3745.68|5.119|and that will ensure that there will be
3747.52|4.48|no zeros in our probability matrix p
3750.799|3.361|and so this will of course change the
3752.0|4.48|generations a little bit in this case it
3754.16|4.159|didn't but in principle it could
3756.48|4.639|but what that's going to do now is that
3758.319|4.0|nothing will be infinity unlikely
3761.119|2.801|so now
3762.319|3.76|our model will predict some other
3763.92|4.159|probability and we see that jq now has a
3766.079|3.52|very small probability so the model
3768.079|3.921|still finds it very surprising that this
3769.599|4.401|was a word or a bigram but we don't get
3772.0|3.28|negative infinity so it's kind of like a
3774.0|2.24|nice fix that people like to apply
3775.28|3.039|sometimes and it's called model
3776.24|4.24|smoothing okay so we've now trained a
3778.319|5.841|respectable bi-gram character level
3780.48|5.44|language model and we saw that we both
3784.16|3.919|sort of trained the model by looking at
3785.92|4.08|the counts of all the bigrams and
3788.079|3.361|normalizing the rows to get probability
3790.0|4.16|distributions
3791.44|5.119|we saw that we can also then use those
3794.16|5.28|parameters of this model to perform
3796.559|4.401|sampling of new words
3799.44|3.52|so we sample new names according to
3800.96|3.599|those distributions and we also saw that
3802.96|3.599|we can evaluate the quality of this
3804.559|3.76|model and the quality of this model is
3806.559|3.601|summarized in a single number which is
3808.319|3.76|the negative log likelihood and the
3810.16|3.12|lower this number is the better the
3812.079|3.361|model is
3813.28|4.4|because it is giving high probabilities
3815.44|4.72|to the actual next characters in all the
3817.68|4.72|bi-grams in our training set
3820.16|4.24|so that's all well and good but we've
3822.4|3.76|arrived at this model explicitly by
3824.4|4.48|doing something that felt sensible we
3826.16|4.72|were just performing counts and then we
3828.88|3.199|were normalizing those counts
3830.88|3.28|now what i would like to do is i would
3832.079|3.681|like to take an alternative approach we
3834.16|3.28|will end up in a very very similar
3835.76|3.52|position but the approach will look very
3837.44|3.44|different because i would like to cast
3839.28|3.36|the problem of bi-gram character level
3840.88|3.28|language modeling into the neural
3842.64|2.959|network framework
3844.16|3.439|in the neural network framework we're
3845.599|3.681|going to approach things slightly
3847.599|4.96|differently but again end up in a very
3849.28|5.6|similar spot i'll go into that later now
3852.559|3.681|our neural network is going to be a
3854.88|3.76|still a background character level
3856.24|4.079|language model so it receives a single
3858.64|3.12|character as an input
3860.319|3.76|then there's neural network with some
3861.76|4.72|weights or some parameters w
3864.079|4.321|and it's going to output the probability
3866.48|4.079|distribution over the next character in
3868.4|4.24|a sequence it's going to make guesses as
3870.559|5.28|to what is likely to follow this
3872.64|5.04|character that was input to the model
3875.839|3.841|and then in addition to that we're going
3877.68|3.84|to be able to evaluate any setting of
3879.68|3.919|the parameters of the neural net because
3881.52|3.68|we have the loss function
3883.599|2.881|the negative log likelihood so we're
3885.2|3.04|going to take a look at its probability
3886.48|3.52|distributions and we're going to use the
3888.24|3.44|labels
3890.0|3.359|which are basically just the identity of
3891.68|2.96|the next character in that diagram the
3893.359|3.041|second character
3894.64|3.76|so knowing what second character
3896.4|4.399|actually comes next in the bigram allows
3898.4|4.399|us to then look at what how high of
3900.799|3.04|probability the model assigns to that
3902.799|2.24|character
3903.839|3.121|and then we of course want the
3905.039|3.76|probability to be very high
3906.96|3.76|and that is another way of saying that
3908.799|3.681|the loss is low
3910.72|3.599|so we're going to use gradient-based
3912.48|3.68|optimization then to tune the parameters
3914.319|4.0|of this network because we have the loss
3916.16|4.08|function and we're going to minimize it
3918.319|3.361|so we're going to tune the weights so
3920.24|2.72|that the neural net is correctly
3921.68|2.639|predicting the probabilities for the
3922.96|3.119|next character
3924.319|3.201|so let's get started the first thing i
3926.079|3.121|want to do is i want to compile the
3927.52|2.72|training set of this neural network
3929.2|2.08|right so
3930.24|2.799|create
3931.28|5.039|the training set
3933.039|4.56|of all the bigrams
3936.319|3.04|okay
3937.599|3.041|and
3939.359|4.321|here
3940.64|4.479|i'm going to copy paste this code
3943.68|3.679|because this code iterates over all the
3945.119|3.841|programs
3947.359|3.2|so here we start with the words we
3948.96|3.28|iterate over all the bygrams and
3950.559|3.441|previously as you recall we did the
3952.24|3.52|counts but now we're not going to do
3954.0|2.799|counts we're just creating a training
3955.76|2.88|set
3956.799|4.881|now this training set will be made up of
3958.64|3.04|two lists
3962.0|4.24|we have the
3964.64|3.04|inputs
3966.24|3.2|and the targets
3967.68|3.76|the the labels
3969.44|3.679|and these bi-grams will denote x y those
3971.44|3.359|are the characters right
3973.119|3.041|and so we're given the first character
3974.799|2.881|of the bi-gram and then we're trying to
3976.16|3.199|predict the next one
3977.68|4.56|both of these are going to be integers
3979.359|4.161|so here we'll take x's that append is
3982.24|5.359|just
3983.52|5.76|x1 ystat append ix2
3987.599|3.841|and then here
3989.28|4.799|we actually don't want lists of integers
3991.44|6.679|we will create tensors out of these so
3994.079|7.361|axis is torch.tensor of axis and wise a
3998.119|4.281|storage.tensor of ys
4001.44|2.24|and then
4002.4|2.88|we don't actually want to take all the
4003.68|3.28|words just yet because i want everything
4005.28|3.6|to be manageable
4006.96|4.24|so let's just do the first word which is
4008.88|4.0|emma
4011.2|4.159|and then it's clear what these x's and
4012.88|4.88|y's would be
4015.359|4.24|here let me print
4017.76|3.76|character 1 character 2 just so you see
4019.599|5.361|what's going on here
4021.52|8.0|so the bigrams of these characters is
4024.96|6.72|dot e e m m m a a dot so this single
4029.52|3.92|word as i mentioned has one two three
4031.68|2.96|four five examples for our neural
4033.44|4.08|network
4034.64|4.56|there are five separate examples in emma
4037.52|3.68|and those examples are summarized here
4039.2|3.839|when the input to the neural network is
4041.2|4.72|integer 0
4043.039|5.601|the desired label is integer 5 which
4045.92|5.199|corresponds to e when the input to the
4048.64|4.959|neural network is 5 we want its weights
4051.119|3.92|to be arranged so that 13 gets a very
4053.599|4.161|high probability
4055.039|4.08|when 13 is put in we want 13 to have a
4057.76|3.76|high probability
4059.119|4.48|when 13 is put in we also want 1 to have
4061.52|4.319|a high probability
4063.599|4.561|when one is input we want zero to have a
4065.839|5.601|very high probability so there are five
4068.16|6.32|separate input examples to a neural nut
4071.44|3.04|in this data set
4074.96|4.0|i wanted to add a tangent of a node of
4077.52|3.92|caution to be careful with a lot of the
4078.96|4.96|apis of some of these frameworks
4081.44|4.399|you saw me silently use torch.tensor
4083.92|3.919|with a lowercase t
4085.839|3.681|and the output looked right
4087.839|3.041|but you should be aware that there's
4089.52|4.319|actually two ways of constructing a
4090.88|5.439|tensor there's a torch.lowercase tensor
4093.839|4.721|and there's also a torch.capital tensor
4096.319|4.0|class which you can also construct
4098.56|4.239|so you can actually call both you can
4100.319|5.04|also do torch.capital tensor
4102.799|4.641|and you get a nexus and wise as well
4105.359|3.44|so that's not confusing at all
4107.44|2.399|um
4108.799|2.721|there are threads on what is the
4109.839|3.52|difference between these two
4111.52|3.6|and um
4113.359|2.96|unfortunately the docs are just like not
4115.12|3.599|clear on the difference and when you
4116.319|4.561|look at the the docs of lower case
4118.719|4.801|tensor construct tensor with no autograd
4120.88|4.72|history by copying data
4123.52|3.679|it's just like it doesn't
4125.6|2.96|it doesn't make sense so the actual
4127.199|2.801|difference as far as i can tell is
4128.56|2.96|explained eventually in this random
4130.0|3.199|thread that you can google
4131.52|3.52|and really it comes down to
4133.199|3.361|i believe
4135.04|3.44|that um
4136.56|4.08|what is this
4138.48|4.0|torch.tensor in first d-type the data
4140.64|3.679|type automatically while torch.tensor
4142.48|2.96|just returns a float tensor
4144.319|3.44|i would recommend stick to
4145.44|4.08|torch.lowercase tensor
4147.759|3.761|so um
4149.52|4.319|indeed we see that when i
4151.52|6.56|construct this with a capital t the data
4153.839|7.201|type here of xs is float32
4158.08|6.48|but towards that lowercase tensor
4161.04|5.679|you see how it's now x dot d type is now
4164.56|3.599|integer
4166.719|4.0|so um
4168.159|4.0|it's advised that you use lowercase t
4170.719|3.681|and you can read more about it if you
4172.159|3.52|like in some of these threads but
4174.4|2.08|basically
4175.679|2.401|um
4176.48|3.199|i'm pointing out some of these things
4178.08|3.52|because i want to caution you and i want
4179.679|3.921|you to re get used to reading a lot of
4181.6|2.719|documentation and reading through a lot
4183.6|3.36|of
4184.319|3.84|q and a's and threads like this
4186.96|2.16|and
4188.159|2.401|you know some of the stuff is
4189.12|2.8|unfortunately not easy and not very well
4190.56|4.08|documented and you have to be careful
4191.92|5.04|out there what we want here is integers
4194.64|3.36|because that's what makes uh sense
4196.96|2.4|um
4198.0|3.12|and so
4199.36|3.2|lowercase tensor is what we are using
4201.12|3.36|okay now we want to think through how
4202.56|3.679|we're going to feed in these examples
4204.48|4.56|into a neural network
4206.239|4.721|now it's not quite as straightforward as
4209.04|3.92|plugging it in because these examples
4210.96|4.88|right now are integers so there's like a
4212.96|4.56|0 5 or 13 it gives us the index of the
4215.84|4.08|character and you can't just plug an
4217.52|4.88|integer index into a neural net
4219.92|4.56|these neural nets right are sort of made
4222.4|2.96|up of these neurons
4224.48|2.8|and
4225.36|3.92|these neurons have weights and as you
4227.28|4.72|saw in micrograd these weights act
4229.28|5.28|multiplicatively on the inputs w x plus
4232.0|3.679|b there's 10 h's and so on and so it
4234.56|3.28|doesn't really make sense to make an
4235.679|4.721|input neuron take on integer values that
4237.84|3.76|you feed in and then multiply on with
4240.4|2.4|weights
4241.6|3.04|so instead
4242.8|4.16|a common way of encoding integers is
4244.64|4.079|what's called one hot encoding
4246.96|4.32|in one hot encoding
4248.719|5.281|we take an integer like 13 and we create
4251.28|5.28|a vector that is all zeros except for
4254.0|5.44|the 13th dimension which we turn to a
4256.56|4.56|one and then that vector can feed into a
4259.44|3.68|neural net
4261.12|3.52|now conveniently
4263.12|4.4|uh pi torch actually has something
4264.64|2.88|called the one hot
4267.84|6.0|function inside torching and functional
4270.239|4.721|it takes a tensor made up of integers
4273.84|4.319|um
4274.96|4.16|long is a is a as an integer
4278.159|4.321|um
4279.12|5.2|and it also takes a number of classes um
4282.48|5.199|which is how large you want your uh
4284.32|5.72|tensor uh your vector to be
4287.679|4.641|so here let's import
4290.04|4.04|torch.n.functional sf this is a common
4292.32|4.32|way of importing it
4294.08|4.56|and then let's do f.1 hot
4296.64|4.64|and we feed in the integers that we want
4298.64|5.36|to encode so we can actually feed in the
4301.28|4.879|entire array of x's
4304.0|3.679|and we can tell it that num classes is
4306.159|3.361|27.
4307.679|4.0|so it doesn't have to try to guess it it
4309.52|5.04|may have guessed that it's only 13 and
4311.679|5.761|would give us an incorrect result
4314.56|6.88|so this is the one hot let's call this x
4317.44|4.0|inc for x encoded
4322.0|5.04|and then we see that x encoded that
4323.679|6.641|shape is 5 by 27
4327.04|5.199|and uh we can also visualize it plt.i am
4330.32|3.2|show of x inc
4332.239|3.121|to make it a little bit more clear
4333.52|3.6|because this is a little messy
4335.36|5.28|so we see that we've encoded all the
4337.12|5.68|five examples uh into vectors we have
4340.64|4.32|five examples so we have five rows and
4342.8|3.439|each row here is now an example into a
4344.96|3.279|neural nut
4346.239|4.241|and we see that the appropriate bit is
4348.239|3.601|turned on as a one and everything else
4350.48|2.96|is zero
4351.84|3.92|so um
4353.44|4.799|here for example the zeroth bit is
4355.76|4.399|turned on the fifth bit is turned on
4358.239|4.401|13th bits are turned on for both of
4360.159|4.401|these examples and then the first bit
4362.64|4.4|here is turned on
4364.56|5.2|so that's how we can encode
4367.04|5.04|integers into vectors and then these
4369.76|3.76|vectors can feed in to neural nets one
4372.08|3.04|more issue to be careful with here by
4373.52|3.36|the way is
4375.12|3.2|let's look at the data type of encoding
4376.88|2.48|we always want to be careful with data
4378.32|3.359|types
4379.36|3.359|what would you expect x encoding's data
4381.679|2.961|type to be
4382.719|3.44|when we're plugging numbers into neural
4384.64|2.8|nuts we don't want them to be integers
4386.159|4.241|we want them to be floating point
4387.44|5.68|numbers that can take on various values
4390.4|3.839|but the d type here is actually 64-bit
4393.12|2.559|integer
4394.239|4.641|and the reason for that i suspect is
4395.679|6.161|that one hot received a 64-bit integer
4398.88|4.319|here and it returned the same data type
4401.84|3.6|and when you look at the signature of
4403.199|5.201|one hot it doesn't even take a d type a
4405.44|5.12|desired data type of the output tensor
4408.4|3.6|and so we can't in a lot of functions in
4410.56|3.76|torch we'd be able to do something like
4412.0|4.48|d type equal storage.float32
4414.32|3.6|which is what we want but one heart does
4416.48|3.199|not support that
4417.92|5.279|so instead we're going to want to cast
4419.679|5.121|this to float like this
4423.199|3.201|so that these
4424.8|3.84|everything is the same
4426.4|5.839|everything looks the same but the d-type
4428.64|5.68|is float32 and floats can feed into
4432.239|3.761|neural nets so now let's construct our
4434.32|4.24|first neuron
4436.0|4.08|this neuron will look at these input
4438.56|3.52|vectors
4440.08|3.68|and as you remember from micrograd these
4442.08|5.2|neurons basically perform a very simple
4443.76|4.479|function w x plus b where w x is a dot
4447.28|2.24|product
4448.239|3.761|right
4449.52|4.639|so we can achieve the same thing here
4452.0|3.679|let's first define the weights of this
4454.159|3.52|neuron basically what are the initial
4455.679|3.04|weights at initialization for this
4457.679|3.921|neuron
4458.719|4.561|let's initialize them with torch.rendin
4461.6|2.96|torch.rendin
4463.28|3.76|is um
4464.56|4.639|fills a tensor with random numbers
4467.04|4.0|drawn from a normal distribution
4469.199|2.641|and a normal distribution
4471.04|3.28|has
4471.84|4.0|a probability density function like this
4474.32|4.72|and so most of the numbers drawn from
4475.84|4.8|this distribution will be around 0
4479.04|3.36|but some of them will be as high as
4480.64|5.68|almost three and so on and very few
4482.4|6.64|numbers will be above three in magnitude
4486.32|4.08|so we need to take a size as an input
4489.04|3.84|here
4490.4|4.16|and i'm going to use size as to be 27 by
4492.88|2.64|one
4494.56|4.159|so
4495.52|7.52|27 by one and then let's visualize w so
4498.719|5.201|w is a column vector of 27 numbers
4503.04|3.84|and
4503.92|4.72|these weights are then multiplied by the
4506.88|3.839|inputs
4508.64|4.48|so now to perform this multiplication we
4510.719|4.241|can take x encoding and we can multiply
4513.12|4.4|it with w
4514.96|4.88|this is a matrix multiplication operator
4517.52|4.88|in pi torch
4519.84|3.76|and the output of this operation is five
4522.4|2.4|by one
4523.6|2.24|the reason is five by five is the
4524.8|3.2|following
4525.84|4.72|we took x encoding which is five by
4528.0|5.52|twenty seven and we multiplied it by
4530.56|3.84|twenty seven by one
4533.52|2.96|and
4534.4|4.4|in matrix multiplication
4536.48|5.12|you see that the output will become five
4538.8|6.0|by one because these 27
4541.6|5.28|will multiply and add
4544.8|3.919|so basically what we're seeing here outs
4546.88|4.96|out of this operation
4548.719|4.96|is we are seeing the five
4551.84|4.48|activations
4553.679|4.48|of this neuron
4556.32|3.44|on these five inputs
4558.159|3.681|and we've evaluated all of them in
4559.76|4.16|parallel we didn't feed in just a single
4561.84|4.8|input to the single neuron we fed in
4563.92|4.16|simultaneously all the five inputs into
4566.64|4.48|the same neuron
4568.08|6.32|and in parallel patrol has evaluated
4571.12|4.72|the wx plus b but here is just the wx
4574.4|5.279|there's no bias
4575.84|5.6|it has value w times x for all of them
4579.679|3.681|independently now instead of a single
4581.44|3.759|neuron though i would like to have 27
4583.36|4.16|neurons and i'll show you in a second
4585.199|4.561|why i want 27 neurons
4587.52|3.679|so instead of having just a 1 here which
4589.76|2.64|is indicating this presence of one
4591.199|3.441|single neuron
4592.4|5.92|we can use 27
4594.64|7.12|and then when w is 27 by 27
4598.32|8.16|this will in parallel evaluate all the
4601.76|6.8|27 neurons on all the 5 inputs
4606.48|4.88|giving us a much better much much bigger
4608.56|5.44|result so now what we've done is 5 by 27
4611.36|6.4|multiplied 27 by 27
4614.0|7.44|and the output of this is now 5 by 27
4617.76|3.68|so we can see that the shape of this
4621.76|4.479|is 5 by 27.
4623.84|3.2|so what is every element here telling us
4626.239|2.96|right
4627.04|5.679|it's telling us for every one of 27
4629.199|3.52|neurons that we created
4633.199|6.401|what is the firing rate of those neurons
4636.64|4.079|on every one of those five examples
4639.6|5.68|so
4640.719|7.52|the element for example 3 comma 13
4645.28|4.0|is giving us the firing rate of the 13th
4648.239|3.601|neuron
4649.28|5.2|looking at the third input
4651.84|4.399|and the way this was achieved is by a
4654.48|3.28|dot product
4656.239|2.641|between the third
4657.76|3.68|input
4658.88|5.92|and the 13th column
4661.44|4.16|of this w matrix here
4664.8|1.68|okay
4665.6|2.639|so
4666.48|4.32|using matrix multiplication we can very
4668.239|4.401|efficiently evaluate
4670.8|4.16|the dot product between lots of input
4672.64|4.88|examples in a batch
4674.96|4.719|and lots of neurons where all those
4677.52|3.52|neurons have weights in the columns of
4679.679|2.721|those w's
4681.04|3.44|and in matrix multiplication we're just
4682.4|3.839|doing those dot products and
4684.48|4.0|in parallel just to show you that this
4686.239|4.161|is the case we can take x and we can
4688.48|3.6|take the third
4690.4|4.24|row
4692.08|4.88|and we can take the w and take its 13th
4694.64|2.32|column
4697.36|4.16|and then we can do
4698.8|7.84|x and get three
4701.52|8.08|elementwise multiply with w at 13.
4706.64|5.28|and sum that up that's wx plus b
4709.6|3.2|well there's no plus b it's just wx dot
4711.92|2.16|product
4712.8|2.399|and that's
4714.08|2.8|this number
4715.199|4.321|so you see that this is just being done
4716.88|3.52|efficiently by the matrix multiplication
4719.52|3.199|operation
4720.4|5.6|for all the input examples and for all
4722.719|6.561|the output neurons of this first layer
4726.0|5.12|okay so we fed our 27-dimensional inputs
4729.28|5.12|into a first layer of a neural net that
4731.12|6.079|has 27 neurons right so we have 27
4734.4|5.6|inputs and now we have 27 neurons these
4737.199|4.321|neurons perform w times x they don't
4740.0|3.6|have a bias and they don't have a
4741.52|4.96|non-linearity like 10 h we're going to
4743.6|4.32|leave them to be a linear layer
4746.48|3.04|in addition to that we're not going to
4747.92|3.52|have any other layers this is going to
4749.52|4.0|be it it's just going to be
4751.44|4.96|the dumbest smallest simplest neural net
4753.52|4.56|which is just a single linear layer
4756.4|4.799|and now i'd like to explain what i want
4758.08|4.48|those 27 outputs to be
4761.199|3.441|intuitively what we're trying to produce
4762.56|3.44|here for every single input example is
4764.64|3.039|we're trying to produce some kind of a
4766.0|3.28|probability distribution for the next
4767.679|3.761|character in a sequence
4769.28|3.76|and there's 27 of them
4771.44|3.36|but we have to come up with like precise
4773.04|4.639|semantics for exactly how we're going to
4774.8|4.879|interpret these 27 numbers that these
4777.679|3.441|neurons take on
4779.679|2.881|now intuitively
4781.12|2.88|you see here that these numbers are
4782.56|2.56|negative and some of them are positive
4784.0|2.48|etc
4785.12|3.76|and that's because these are coming out
4786.48|4.719|of a neural net layer initialized with
4788.88|2.319|these
4791.36|2.879|normal distribution
4792.96|2.88|parameters
4794.239|2.96|but what we want is we want something
4795.84|3.12|like we had here
4797.199|3.921|like each row here
4798.96|3.199|told us the counts and then we
4801.12|3.119|normalized the counts to get
4802.159|4.241|probabilities and we want something
4804.239|3.601|similar to come out of the neural net
4806.4|4.16|but what we just have right now is just
4807.84|4.399|some negative and positive numbers
4810.56|3.44|now we want those numbers to somehow
4812.239|3.041|represent the probabilities for the next
4814.0|3.6|character
4815.28|4.64|but you see that probabilities they they
4817.6|4.32|have a special structure they um
4819.92|2.88|they're positive numbers and they sum to
4821.92|2.64|one
4822.8|2.96|and so that doesn't just come out of a
4824.56|3.2|neural net
4825.76|5.28|and then they can't be counts
4827.76|4.959|because these counts are positive and
4831.04|3.44|counts are integers
4832.719|3.92|so counts are also not really a good
4834.48|3.679|thing to output from a neural net
4836.639|3.121|so instead what the neural net is going
4838.159|3.921|to output and how we are going to
4839.76|5.84|interpret the um
4842.08|6.4|the 27 numbers is that these 27 numbers
4845.6|4.079|are giving us log counts
4848.48|1.92|basically
4849.679|3.201|um
4850.4|4.4|so instead of giving us counts directly
4852.88|3.12|like in this table they're giving us log
4854.8|2.879|counts
4856.0|3.36|and to get the counts we're going to
4857.679|3.681|take the log counts and we're going to
4859.36|2.96|exponentiate them
4861.36|2.799|now
4862.32|4.879|exponentiation
4864.159|4.641|takes the following form
4867.199|3.681|it takes numbers
4868.8|4.0|that are negative or they are positive
4870.88|3.839|it takes the entire real line
4872.8|4.399|and then if you plug in negative numbers
4874.719|5.841|you're going to get e to the x
4877.199|6.161|which is uh always below one
4880.56|4.72|so you're getting numbers lower than one
4883.36|4.08|and if you plug in numbers greater than
4885.28|5.52|zero you're getting numbers greater than
4887.44|5.759|one all the way growing to the infinity
4890.8|4.32|and this here grows to zero
4893.199|4.561|so basically we're going to
4895.12|4.88|take these numbers
4897.76|2.24|here
4900.32|4.24|and
4903.28|2.879|instead of them being positive and
4904.56|4.159|negative and all over the place we're
4906.159|4.0|going to interpret them as log counts
4908.719|4.0|and then we're going to element wise
4910.159|4.321|exponentiate these numbers
4912.719|3.681|exponentiating them now gives us
4914.48|3.12|something like this
4916.4|2.88|and you see that these numbers now
4917.6|3.2|because they went through an exponent
4919.28|5.28|all the negative numbers turned into
4920.8|6.32|numbers below 1 like 0.338 and all the
4924.56|4.079|positive numbers originally turned into
4927.12|3.599|even more positive numbers sort of
4928.639|3.841|greater than one
4930.719|3.761|so like for example
4932.48|5.92|seven
4934.48|6.56|is some positive number over here
4938.4|6.4|that is greater than zero
4941.04|5.28|but exponentiated outputs here
4944.8|4.24|basically give us something that we can
4946.32|5.2|use and interpret as the equivalent of
4949.04|7.28|counts originally so you see these
4951.52|7.04|counts here 112 7 51 1 etc
4956.32|3.919|the neural net is kind of now predicting
4958.56|2.96|uh
4960.239|3.601|counts
4961.52|4.159|and these counts are positive numbers
4963.84|2.879|they can never be below zero so that
4965.679|2.881|makes sense
4966.719|2.96|and uh they can now take on various
4968.56|5.599|values
4969.679|6.48|depending on the settings of w
4974.159|4.08|so let me break this down
4976.159|4.881|we're going to interpret these to be the
4978.239|2.801|log counts
4981.199|3.921|in other words for this that is often
4982.96|5.6|used is so-called logits
4985.12|6.079|these are logits log counts
4988.56|4.8|then these will be sort of the counts
4991.199|5.04|largest exponentiated
4993.36|4.64|and this is equivalent to the n matrix
4996.239|3.841|sort of the n
4998.0|3.6|array that we used previously remember
5000.08|4.0|this was the n
5001.6|6.16|this is the the array of counts
5004.08|4.88|and each row here are the counts for the
5007.76|4.479|for the um
5008.96|3.279|next character sort of
5012.639|5.281|so those are the counts and now the
5014.8|4.8|probabilities are just the counts um
5017.92|3.68|normalized
5019.6|3.44|and so um
5021.6|3.2|i'm not going to find the same but
5023.04|2.96|basically i'm not going to scroll all
5024.8|3.359|over the place
5026.0|4.08|we've already done this we want to
5028.159|4.08|counts that sum
5030.08|4.639|along the first dimension and we want to
5032.239|4.561|keep them as true
5034.719|5.201|we've went over this and this is how we
5036.8|6.399|normalize the rows of our counts matrix
5039.92|4.96|to get our probabilities
5043.199|4.721|props
5044.88|3.759|so now these are the probabilities
5047.92|2.239|and
5048.639|2.721|these are the counts that we ask
5050.159|3.52|currently and now when i show the
5051.36|4.24|probabilities
5053.679|3.681|you see that um
5055.6|3.84|every row here
5057.36|4.0|of course
5059.44|3.68|will sum to 1
5061.36|3.92|because they're normalized
5063.12|4.24|and the shape of this
5065.28|4.48|is 5 by 27
5067.36|4.319|and so really what we've achieved is for
5069.76|4.0|every one of our five examples
5071.679|3.361|we now have a row that came out of a
5073.76|3.76|neural net
5075.04|4.159|and because of the transformations here
5077.52|3.92|we made sure that this output of this
5079.199|4.801|neural net now are probabilities or we
5081.44|3.84|can interpret to be probabilities
5084.0|4.0|so
5085.28|4.399|our wx here gave us logits
5088.0|2.639|and then we interpret those to be log
5089.679|2.721|counts
5090.639|3.281|we exponentiate to get something that
5092.4|2.96|looks like counts
5093.92|3.52|and then we normalize those counts to
5095.36|3.68|get a probability distribution
5097.44|2.88|and all of these are differentiable
5099.04|3.28|operations
5100.32|4.319|so what we've done now is we're taking
5102.32|4.48|inputs we have differentiable operations
5104.639|3.6|that we can back propagate through
5106.8|3.04|and we're getting out probability
5108.239|2.801|distributions
5109.84|3.52|so
5111.04|4.08|for example for the zeroth example that
5113.36|3.68|fed in
5115.12|3.68|right which was um
5117.04|3.52|the zeroth example here was a one-half
5118.8|3.68|vector of zero
5120.56|6.0|and um
5122.48|6.159|it basically corresponded to feeding in
5126.56|4.48|this example here so we're feeding in a
5128.639|4.0|dot into a neural net and the way we fed
5131.04|3.28|the dot into a neural net is that we
5132.639|3.921|first got its index
5134.32|4.72|then we one hot encoded it
5136.56|4.0|then it went into the neural net and out
5139.04|4.32|came
5140.56|5.84|this distribution of probabilities
5143.36|5.76|and its shape
5146.4|4.96|is 27 there's 27 numbers and we're going
5149.12|5.28|to interpret this as the neural nets
5151.36|5.2|assignment for how likely every one of
5154.4|5.279|these characters um
5156.56|5.76|the 27 characters are to come next
5159.679|3.841|and as we tune the weights w
5162.32|3.04|we're going to be of course getting
5163.52|3.6|different probabilities out for any
5165.36|3.6|character that you input
5167.12|3.84|and so now the question is just can we
5168.96|4.0|optimize and find a good w
5170.96|4.32|such that the probabilities coming out
5172.96|4.4|are pretty good and the way we measure
5175.28|3.68|pretty good is by the loss function okay
5177.36|3.04|so i organized everything into a single
5178.96|3.6|summary so that hopefully it's a bit
5180.4|4.0|more clear so it starts here
5182.56|3.76|with an input data set
5184.4|4.16|we have some inputs to the neural net
5186.32|4.48|and we have some labels for the correct
5188.56|4.159|next character in a sequence these are
5190.8|4.56|integers
5192.719|4.721|here i'm using uh torch generators now
5195.36|3.2|so that you see the same numbers that i
5197.44|3.36|see
5198.56|4.24|and i'm generating um
5200.8|6.72|27 neurons weights
5202.8|4.72|and each neuron here receives 27 inputs
5208.56|4.32|then here we're going to plug in all the
5210.4|5.279|input examples x's into a neural net so
5212.88|4.72|here this is a forward pass
5215.679|4.721|first we have to encode all of the
5217.6|5.119|inputs into one hot representations
5220.4|4.0|so we have 27 classes we pass in these
5222.719|6.96|integers and
5224.4|7.839|x inc becomes a array that is 5 by 27
5229.679|4.56|zeros except for a few ones
5232.239|4.48|we then multiply this in the first layer
5234.239|4.641|of a neural net to get logits
5236.719|3.92|exponentiate the logits to get fake
5238.88|3.279|counts sort of
5240.639|3.681|and normalize these counts to get
5242.159|4.321|probabilities
5244.32|5.68|so we lock these last two lines by the
5246.48|6.719|way here are called the softmax
5250.0|5.92|which i pulled up here soft max is a
5253.199|5.681|very often used layer in a neural net
5255.92|5.04|that takes these z's which are logics
5258.88|4.799|exponentiates them
5260.96|3.679|and divides and normalizes it's a way of
5263.679|3.52|taking
5264.639|3.921|outputs of a neural net layer and these
5267.199|2.561|these outputs can be positive or
5268.56|3.84|negative
5269.76|5.439|and it outputs probability distributions
5272.4|4.4|it outputs something that is always
5275.199|3.281|sums to one and are positive numbers
5276.8|3.359|just like probabilities
5278.48|2.96|um so it's kind of like a normalization
5280.159|3.201|function if you want to think of it that
5281.44|4.16|way and you can put it on top of any
5283.36|3.76|other linear layer inside a neural net
5285.6|4.16|and it basically makes a neural net
5287.12|6.16|output probabilities that's very often
5289.76|4.879|used and we used it as well here
5293.28|2.879|so this is the forward pass and that's
5294.639|3.201|how we made a neural net output
5296.159|3.201|probability
5297.84|2.799|now
5299.36|3.44|you'll notice that
5300.639|2.161|um
5302.96|2.96|all of these
5304.239|3.041|this entire forward pass is made up of
5305.92|3.2|differentiable
5307.28|3.68|layers everything here we can back
5309.12|4.079|propagate through and we saw some of the
5310.96|3.759|back propagation in micrograd
5313.199|3.601|this is just
5314.719|3.52|multiplication and addition all that's
5316.8|2.96|happening here is just multiply and then
5318.239|2.48|add and we know how to backpropagate
5319.76|2.24|through them
5320.719|3.121|exponentiation we know how to
5322.0|4.48|backpropagate through
5323.84|5.359|and then here we are summing
5326.48|3.6|and sum is is easily backpropagable as
5329.199|3.361|well
5330.08|4.48|and division as well so everything here
5332.56|4.96|is differentiable operation
5334.56|5.2|and we can back propagate through
5337.52|4.08|now we achieve these probabilities which
5339.76|4.16|are 5 by 27
5341.6|4.72|for every single example we have a
5343.92|4.56|vector of probabilities that's into one
5346.32|4.08|and then here i wrote a bunch of stuff
5348.48|2.96|to sort of like break down uh the
5350.4|3.92|examples
5351.44|4.88|so we have five examples making up emma
5354.32|5.68|right
5356.32|7.28|and there are five bigrams inside emma
5360.0|6.32|so bigram example a bigram example1 is
5363.6|4.639|that e is the beginning character right
5366.32|4.08|after dot
5368.239|3.041|and the indexes for these are zero and
5370.4|3.68|five
5371.28|4.64|so then we feed in a zero
5374.08|4.0|that's the input of the neural net
5375.92|5.36|we get probabilities from the neural net
5378.08|6.0|that are 27 numbers
5381.28|4.56|and then the label is 5 because e
5384.08|3.84|actually comes after dot
5385.84|3.52|so that's the label
5387.92|4.4|and then
5389.36|4.96|we use this label 5 to index into the
5392.32|2.8|probability distribution here
5394.32|1.68|so
5395.12|4.88|this
5396.0|5.28|index 5 here is 0 1 2 3 4 5. it's this
5400.0|4.0|number here
5401.28|4.08|which is here
5404.0|3.28|so that's basically the probability
5405.36|3.359|assigned by the neural net to the actual
5407.28|2.879|correct character
5408.719|3.761|you see that the network currently
5410.159|5.121|thinks that this next character that e
5412.48|4.48|following dot is only one percent likely
5415.28|3.52|which is of course not very good right
5416.96|3.84|because this actually is a training
5418.8|4.0|example and the network thinks this is
5420.8|4.0|currently very very unlikely but that's
5422.8|4.48|just because we didn't get very lucky in
5424.8|4.48|generating a good setting of w so right
5427.28|4.64|now this network things it says unlikely
5429.28|5.439|and 0.01 is not a good outcome
5431.92|3.84|so the log likelihood then is very
5434.719|3.52|negative
5435.76|3.6|and the negative log likelihood is very
5438.239|4.161|positive
5439.36|4.64|and so four is a very high negative log
5442.4|2.88|likelihood and that means we're going to
5444.0|3.44|have a high loss
5445.28|6.32|because what is the loss the loss is
5447.44|6.16|just the average negative log likelihood
5451.6|3.68|so the second character is em
5453.6|4.16|and you see here that also the network
5455.28|5.52|thought that m following e is very
5457.76|3.04|unlikely one percent
5460.96|3.279|the for m following m i thought it was
5463.04|3.04|two percent
5464.239|4.4|and for a following m it actually
5466.08|4.639|thought it was seven percent likely so
5468.639|3.681|just by chance this one actually has a
5470.719|4.561|pretty good probability and therefore
5472.32|4.72|pretty low negative log likelihood
5475.28|3.04|and finally here it thought this was one
5477.04|3.44|percent likely
5478.32|4.56|so overall our average negative log
5480.48|4.239|likelihood which is the loss the total
5482.88|3.6|loss that summarizes
5484.719|3.44|basically the how well this network
5486.48|3.6|currently works at least on this one
5488.159|5.04|word not on the full data suggested one
5490.08|4.96|word is 3.76 which is actually very
5493.199|3.601|fairly high loss this is not a very good
5495.04|3.52|setting of w's
5496.8|4.399|now here's what we can do
5498.56|4.4|we're currently getting 3.76
5501.199|4.721|we can actually come here and we can
5502.96|5.679|change our w we can resample it so let
5505.92|4.56|me just add one to have a different seed
5508.639|4.161|and then we get a different w
5510.48|4.159|and then we can rerun this
5512.8|5.76|and with this different c with this
5514.639|6.161|different setting of w's we now get 3.37
5518.56|3.599|so this is a much better w right and
5520.8|3.919|that and it's better because the
5522.159|4.881|probabilities just happen to come out
5524.719|4.081|higher for the for the characters that
5527.04|2.96|actually are next
5528.8|5.52|and so you can imagine actually just
5530.0|5.44|resampling this you know we can try two
5534.32|2.8|so
5535.44|3.04|okay this was not very good
5537.12|3.76|let's try one more
5538.48|4.32|we can try three
5540.88|3.96|okay this was terrible setting because
5542.8|6.48|we have a very high loss
5544.84|4.44|so anyway i'm going to erase this
5549.92|3.04|what i'm doing here which is just guess
5551.44|3.199|and check of randomly assigning
5552.96|4.48|parameters and seeing if the network is
5554.639|4.641|good that is uh amateur hour that's not
5557.44|3.279|how you optimize a neural net the way
5559.28|3.2|you optimize your neural net is you
5560.719|3.041|start with some random guess and we're
5562.48|2.64|going to commit to this one even though
5563.76|3.12|it's not very good
5565.12|3.119|but now the big deal is we have a loss
5566.88|3.04|function
5568.239|4.601|so this loss
5569.92|6.4|is made up only of differentiable
5572.84|4.68|operations and we can minimize the loss
5576.32|2.319|by tuning
5577.52|3.679|ws
5578.639|3.921|by computing the gradients of the loss
5581.199|3.761|with respect to
5582.56|4.56|these w matrices
5584.96|4.56|and so then we can tune w to minimize
5587.12|4.64|the loss and find a good setting of w
5589.52|3.84|using gradient based optimization so
5591.76|2.8|let's see how that will work now things
5593.36|3.68|are actually going to look almost
5594.56|3.599|identical to what we had with micrograd
5597.04|3.84|so here
5598.159|5.601|i pulled up the lecture from micrograd
5600.88|4.08|the notebook it's from this repository
5603.76|3.12|and when i scroll all the way to the end
5604.96|3.6|where we left off with micrograd we had
5606.88|2.72|something very very similar
5608.56|2.639|we had
5609.6|4.559|a number of input examples in this case
5611.199|5.361|we had four input examples inside axis
5614.159|3.441|and we had their targets these are
5616.56|3.119|targets
5617.6|3.599|just like here we have our axes now but
5619.679|4.401|we have five of them and they're now
5621.199|4.641|integers instead of vectors
5624.08|4.8|but we're going to convert our integers
5625.84|6.08|to vectors except our vectors will be 27
5628.88|4.72|large instead of three large
5631.92|3.92|and then here what we did is first we
5633.6|4.639|did a forward pass where we ran a neural
5635.84|4.399|net on all of the inputs
5638.239|4.641|to get predictions
5640.239|4.801|our neural net at the time this nfx was
5642.88|3.68|a multi-layer perceptron
5645.04|3.199|our neural net is going to look
5646.56|3.84|different because our neural net is just
5648.239|4.161|a single layer
5650.4|3.36|single linear layer followed by a soft
5652.4|3.44|max
5653.76|3.919|so that's our neural net
5655.84|3.68|and the loss here was the mean squared
5657.679|3.361|error so we simply subtracted the
5659.52|3.6|prediction from the ground truth and
5661.04|4.24|squared it and summed it all up and that
5663.12|4.4|was the loss and loss was the single
5665.28|5.439|number that summarized the quality of
5667.52|6.24|the neural net and when loss is low like
5670.719|5.44|almost zero that means the neural net is
5673.76|4.72|predicting correctly
5676.159|4.801|so we had a single number that uh that
5678.48|4.32|summarized the uh the performance of the
5680.96|3.679|neural net and everything here was
5682.8|4.0|differentiable and was stored in massive
5684.639|4.08|compute graph
5686.8|3.28|and then we iterated over all the
5688.719|3.601|parameters we made sure that the
5690.08|4.0|gradients are set to zero and we called
5692.32|3.76|lost up backward
5694.08|4.32|and lasted backward initiated back
5696.08|3.2|propagation at the final output node of
5698.4|2.4|loss
5699.28|3.12|right so
5700.8|3.12|yeah remember these expressions we had
5702.4|3.12|loss all the way at the end we start
5703.92|2.4|back propagation and we went all the way
5705.52|2.88|back
5706.32|4.399|and we made sure that we populated all
5708.4|4.239|the parameters dot grad
5710.719|3.761|so that graph started at zero but back
5712.639|3.761|propagation filled it in
5714.48|4.159|and then in the update we iterated over
5716.4|5.04|all the parameters and we simply did a
5718.639|5.921|parameter update where every single
5721.44|6.08|element of our parameters was nudged in
5724.56|5.679|the opposite direction of the gradient
5727.52|4.159|and so we're going to do the exact same
5730.239|4.161|thing here
5731.679|5.44|so i'm going to pull this up
5734.4|2.719|on the side here
5738.48|2.8|so that we have it available and we're
5740.08|4.24|actually going to do the exact same
5741.28|5.6|thing so this was the forward pass so
5744.32|5.12|where we did this
5746.88|4.319|and probs is our wipe red so now we have
5749.44|3.44|to evaluate the loss but we're not using
5751.199|3.281|the mean squared error we're using the
5752.88|3.44|negative log likelihood because we are
5754.48|4.48|doing classification we're not doing
5756.32|6.08|regression as it's called
5758.96|5.52|so here we want to calculate loss
5762.4|4.719|now the way we calculate it is it's just
5764.48|6.159|this average negative log likelihood
5767.119|6.161|now this probs here
5770.639|5.04|has a shape of 5 by 27
5773.28|4.959|and so to get all the we basically want
5775.679|4.321|to pluck out the probabilities at the
5778.239|3.841|correct indices here
5780.0|4.48|so in particular because the labels are
5782.08|3.92|stored here in array wise
5784.48|3.04|basically what we're after is for the
5786.0|4.88|first example we're looking at
5787.52|5.199|probability of five right at index five
5790.88|5.279|for the second example
5792.719|4.721|at the the second row or row index one
5796.159|4.08|we are interested in the probability
5797.44|6.0|assigned to index 13.
5800.239|7.121|at the second example we also have 13.
5803.44|6.32|at the third row we want one
5807.36|4.96|and then the last row which is four we
5809.76|4.24|want zero so these are the probabilities
5812.32|3.6|we're interested in right
5814.0|4.56|and you can see that they're not amazing
5815.92|4.16|as we saw above
5818.56|3.679|so these are the probabilities we want
5820.08|4.4|but we want like a more efficient way to
5822.239|4.0|access these probabilities
5824.48|3.44|not just listing them out in a tuple
5826.239|3.601|like this so it turns out that the way
5827.92|4.96|to do this in pytorch uh one of the ways
5829.84|5.6|at least is we can basically pass in
5832.88|2.56|all of these
5836.639|5.441|sorry about that all of these um
5839.679|3.201|integers in the vectors
5842.08|1.76|so
5842.88|3.04|the
5843.84|3.2|these ones you see how they're just 0 1
5845.92|3.279|2 3 4
5847.04|5.76|we can actually create that using mp
5849.199|5.201|not mp sorry torch dot range of 5
5852.8|4.24|0 1 2 3 4.
5854.4|3.839|so we can index here with torch.range of
5857.04|4.079|5
5858.239|4.88|and here we index with ys
5861.119|5.801|and you see that that gives us
5863.119|3.801|exactly these numbers
5868.96|4.96|so that plucks out the probabilities of
5871.44|4.799|that the neural network assigns to the
5873.92|4.4|correct next character
5876.239|3.361|now we take those probabilities and we
5878.32|5.2|don't we actually look at the log
5879.6|6.079|probability so we want to dot log
5883.52|4.159|and then we want to just
5885.679|2.881|average that up so take the mean of all
5887.679|2.641|of that
5888.56|5.599|and then it's the negative
5890.32|7.76|average log likelihood that is the loss
5894.159|7.52|so the loss here is 3.7 something and
5898.08|5.36|you see that this loss 3.76 3.76 is
5901.679|3.601|exactly as we've obtained before but
5903.44|3.04|this is a vectorized form of that
5905.28|1.919|expression
5906.48|3.04|so
5907.199|4.161|we get the same loss
5909.52|4.48|and the same loss we can consider
5911.36|4.96|service part of this forward pass
5914.0|3.92|and we've achieved here now loss
5916.32|3.76|okay so we made our way all the way to
5917.92|4.08|loss we've defined the forward pass
5920.08|4.159|we forwarded the network and the loss
5922.0|5.199|now we're ready to do the backward pass
5924.239|2.96|so backward pass
5928.0|4.4|we want to first make sure that all the
5929.52|5.84|gradients are reset so they're at zero
5932.4|4.799|now in pytorch you can set the gradients
5935.36|4.0|to be zero but you can also just set it
5937.199|4.401|to none and setting it to none is more
5939.36|4.96|efficient and pi torch will interpret
5941.6|4.16|none as like a lack of a gradient and is
5944.32|3.6|the same as zeros
5945.76|4.56|so this is a way to set to zero the
5947.92|2.4|gradient
5950.4|3.44|and now we do lost it backward
5954.639|2.961|before we do lost that backward we need
5956.159|2.641|one more thing if you remember from
5957.6|3.68|micrograd
5958.8|6.319|pytorch actually requires
5961.28|5.68|that we pass in requires grad is true
5965.119|3.361|so that when we tell
5966.96|3.759|pythorge that we are interested in
5968.48|4.96|calculating gradients for this leaf
5970.719|5.121|tensor by default this is false
5973.44|4.48|so let me recalculate with that
5975.84|4.799|and then set to none and lost that
5977.92|4.4|backward
5980.639|3.761|now something magical happened when
5982.32|4.879|lasted backward was run
5984.4|4.64|because pytorch just like micrograd when
5987.199|4.241|we did the forward pass here
5989.04|4.159|it keeps track of all the operations
5991.44|4.16|under the hood it builds a full
5993.199|3.281|computational graph just like the graphs
5995.6|3.2|we've
5996.48|4.32|produced in micrograd those graphs exist
5998.8|3.919|inside pi torch
6000.8|3.2|and so it knows all the dependencies and
6002.719|2.241|all the mathematical operations of
6004.0|3.04|everything
6004.96|4.56|and when you then calculate the loss
6007.04|4.639|we can call a dot backward on it
6009.52|4.08|and that backward then fills in the
6011.679|3.52|gradients of
6013.6|4.72|all the intermediates
6015.199|5.201|all the way back to w's which are the
6018.32|4.799|parameters of our neural net so now we
6020.4|6.4|can do w grad and we see that it has
6023.119|3.681|structure there's stuff inside it
6029.04|4.32|and these gradients
6030.8|6.0|every single element here
6033.36|7.279|so w dot shape is 27 by 27
6036.8|6.24|w grad shape is the same 27 by 27
6040.639|3.761|and every element of w that grad
6043.04|4.56|is telling us
6044.4|4.319|the influence of that weight on the loss
6047.6|3.2|function
6048.719|3.201|so for example this number all the way
6050.8|3.52|here
6051.92|3.6|if this element the zero zero element of
6054.32|3.28|w
6055.52|4.48|because the gradient is positive is
6057.6|5.44|telling us that this has a positive
6060.0|4.4|influence in the loss slightly nudging
6063.04|3.92|w
6064.4|3.36|slightly taking w 0 0
6066.96|3.44|and
6067.76|4.64|adding a small h to it
6070.4|5.279|would increase the loss
6072.4|4.319|mildly because this gradient is positive
6075.679|2.881|some of these gradients are also
6076.719|3.52|negative
6078.56|3.84|so that's telling us about the gradient
6080.239|5.121|information and we can use this gradient
6082.4|5.04|information to update the weights of
6085.36|4.0|this neural network so let's now do the
6087.44|4.799|update it's going to be very similar to
6089.36|4.4|what we had in micrograd we need no loop
6092.239|3.841|over all the parameters because we only
6093.76|3.28|have one parameter uh tensor and that is
6096.08|4.88|w
6097.04|5.119|so we simply do w dot data plus equals
6100.96|2.88|uh the
6102.159|6.641|we can actually copy this almost exactly
6103.84|4.96|negative 0.1 times w dot grad
6109.36|5.12|and that would be the update to the
6112.239|3.681|tensor
6114.48|4.08|so that updates
6115.92|2.64|the tensor
6118.639|2.48|and
6119.52|4.8|because the tensor is updated we would
6121.119|4.241|expect that now the loss should decrease
6124.32|5.04|so
6125.36|4.0|here if i print loss
6129.44|3.679|that item
6131.119|5.361|it was 3.76 right
6133.119|5.841|so we've updated the w here so if i
6136.48|5.12|recalculate forward pass
6138.96|4.56|loss now should be slightly lower so
6141.6|4.079|3.76 goes to
6143.52|3.199|3.74
6145.679|3.921|and then
6146.719|4.081|we can again set to set grad to none and
6149.6|2.88|backward
6150.8|4.0|update
6152.48|4.719|and now the parameters changed again
6154.8|6.76|so if we recalculate the forward pass we
6157.199|4.361|expect a lower loss again 3.72
6162.159|5.441|okay and this is again doing the we're
6164.48|3.12|now doing gradient descent
6168.48|4.159|and when we achieve a low loss that will
6170.639|3.761|mean that the network is assigning high
6172.639|3.441|probabilities to the correctness
6174.4|3.52|characters okay so i rearranged
6176.08|3.36|everything and i put it all together
6177.92|3.44|from scratch
6179.44|3.759|so here is where we construct our data
6181.36|3.359|set of bigrams
6183.199|3.681|you see that we are still iterating only
6184.719|4.561|on the first word emma
6186.88|4.48|i'm going to change that in a second i
6189.28|5.28|added a number that counts the number of
6191.36|5.52|elements in x's so that we explicitly
6194.56|3.44|see that number of examples is five
6196.88|2.56|because currently we're just working
6198.0|2.56|with emma and there's five backgrounds
6199.44|3.12|there
6200.56|4.72|and here i added a loop of exactly what
6202.56|4.88|we had before so we had 10 iterations of
6205.28|3.6|grainy descent of forward pass backward
6207.44|2.88|pass and an update
6208.88|3.92|and so running these two cells
6210.32|5.04|initialization and gradient descent
6212.8|3.359|gives us some improvement
6215.36|2.799|on
6216.159|5.52|the loss function
6218.159|7.201|but now i want to use all the words
6221.679|4.96|and there's not 5 but 228 000 bigrams
6225.36|2.879|now
6226.639|3.121|however this should require no
6228.239|3.44|modification whatsoever everything
6229.76|3.28|should just run because all the code we
6231.679|4.48|wrote doesn't care if there's five
6233.04|5.36|migrants or 228 000 bigrams and with
6236.159|4.161|everything we should just work so
6238.4|3.279|you see that this will just run
6240.32|4.319|but now we are optimizing over the
6241.679|4.801|entire training set of all the bigrams
6244.639|3.52|and you see now that we are decreasing
6246.48|5.44|very slightly so actually we can
6248.159|3.761|probably afford a larger learning rate
6252.32|4.68|and probably for even larger learning
6254.0|3.0|rate
6260.639|3.681|even 50 seems to work on this very very
6262.56|4.32|simple example right so let me
6264.32|4.96|re-initialize and let's run 100
6266.88|5.04|iterations
6269.28|2.64|see what happens
6272.88|2.96|okay
6276.239|4.241|we seem to be
6279.04|3.679|coming up to some pretty good losses
6280.48|4.0|here 2.47
6282.719|3.361|let me run 100 more
6284.48|3.52|what is the number that we expect by the
6286.08|4.159|way in the loss we expect to get
6288.0|4.0|something around what we had originally
6290.239|3.281|actually
6292.0|3.84|so all the way back if you remember in
6293.52|5.36|the beginning of this video when we
6295.84|5.68|optimized uh just by counting
6298.88|4.56|our loss was roughly 2.47
6301.52|5.04|after we had it smoothing
6303.44|4.88|but before smoothing we had roughly 2.45
6306.56|3.119|likelihood
6308.32|2.64|sorry loss
6309.679|4.081|and so that's actually roughly the
6310.96|4.88|vicinity of what we expect to achieve
6313.76|4.08|but before we achieved it by counting
6315.84|3.839|and here we are achieving the roughly
6317.84|3.12|the same result but with gradient based
6319.679|4.241|optimization
6320.96|5.279|so we come to about 2.4
6323.92|3.199|6 2.45 etc
6326.239|2.48|and that makes sense because
6327.119|3.361|fundamentally we're not taking any
6328.719|3.201|additional information we're still just
6330.48|3.36|taking in the previous character and
6331.92|3.44|trying to predict the next one but
6333.84|4.319|instead of doing it explicitly by
6335.36|4.0|counting and normalizing
6338.159|3.281|we are doing it with gradient-based
6339.36|4.64|learning and it just so happens that the
6341.44|4.88|explicit approach happens to very well
6344.0|4.48|optimize the loss function without any
6346.32|3.76|need for a gradient based optimization
6348.48|3.52|because the setup for bigram language
6350.08|4.24|models are is so straightforward that's
6352.0|4.0|so simple we can just afford to estimate
6354.32|2.799|those probabilities directly and
6356.0|2.8|maintain them
6357.119|3.681|in a table
6358.8|4.08|but the gradient-based approach is
6360.8|4.0|significantly more flexible
6362.88|3.68|so we've actually gained a lot
6364.8|4.319|because
6366.56|4.48|what we can do now is
6369.119|4.161|we can expand this approach and
6371.04|3.679|complexify the neural net so currently
6373.28|3.04|we're just taking a single character and
6374.719|3.601|feeding into a neural net and the neural
6376.32|4.24|that's extremely simple but we're about
6378.32|4.16|to iterate on this substantially we're
6380.56|4.0|going to be taking multiple previous
6382.48|3.6|characters and we're going to be feeding
6384.56|4.0|feeding them into increasingly more
6386.08|4.079|complex neural nets but fundamentally
6388.56|4.0|out the output of the neural net will
6390.159|3.841|always just be logics
6392.56|3.44|and those logits will go through the
6394.0|3.84|exact same transformation we are going
6396.0|3.52|to take them through a soft max
6397.84|4.24|calculate the loss function and the
6399.52|5.36|negative log likelihood and do gradient
6402.08|5.36|based optimization and so actually
6404.88|4.88|as we complexify the neural nets and
6407.44|4.0|work all the way up to transformers
6409.76|3.2|none of this will really fundamentally
6411.44|3.199|change none of this will fundamentally
6412.96|2.64|change the only thing that will change
6414.639|3.04|is
6415.6|3.519|the way we do the forward pass where we
6417.679|4.0|take in some previous characters and
6419.119|4.801|calculate logits for the next character
6421.679|3.44|in the sequence that will become more
6423.92|3.44|complex
6425.119|3.681|and uh but we'll use the same machinery
6427.36|3.279|to optimize it
6428.8|3.28|and um
6430.639|2.48|it's not obvious how we would have
6432.08|2.8|extended
6433.119|4.241|this bigram approach
6434.88|4.48|into the case where there are many more
6437.36|4.0|characters at the input because
6439.36|3.759|eventually these tables would get way
6441.36|4.799|too large because there's way too many
6443.119|4.641|combinations of what previous characters
6446.159|3.441|could be
6447.76|3.359|if you only have one previous character
6449.6|4.0|we can just keep everything in a table
6451.119|4.321|that counts but if you have the last 10
6453.6|3.119|characters that are input we can't
6455.44|3.04|actually keep everything in the table
6456.719|3.52|anymore so this is fundamentally an
6458.48|3.6|unscalable approach and the neural
6460.239|3.761|network approach is significantly more
6462.08|4.72|scalable and it's something that
6464.0|4.56|actually we can improve on over time so
6466.8|4.24|that's where we will be digging next i
6468.56|3.679|wanted to point out two more things
6471.04|2.96|number one
6472.239|2.801|i want you to notice that
6474.0|2.639|this
6475.04|4.0|x ink here
6476.639|3.761|this is made up of one hot vectors and
6479.04|4.079|then those one hot vectors are
6480.4|5.36|multiplied by this w matrix
6483.119|4.321|and we think of this as multiple neurons
6485.76|2.879|being forwarded in a fully connected
6487.44|2.56|manner
6488.639|3.281|but actually what's happening here is
6490.0|4.32|that for example
6491.92|5.759|if you have a one hot vector here that
6494.32|4.799|has a one at say the fifth dimension
6497.679|3.44|then because of the way the matrix
6499.119|4.321|multiplication works
6501.119|4.481|multiplying that one-half vector with w
6503.44|4.0|actually ends up plucking out the fifth
6505.6|3.92|row of w
6507.44|3.759|log logits would become just the fifth
6509.52|3.44|row of w
6511.199|4.0|and that's because of the way the matrix
6512.96|3.92|multiplication works
6515.199|2.561|um
6516.88|3.12|so
6517.76|4.24|that's actually what ends up happening
6520.0|3.199|so but that's actually exactly what
6522.0|4.639|happened before
6523.199|5.04|because remember all the way up here
6526.639|3.681|we have a bigram we took the first
6528.239|6.721|character and then that first character
6530.32|6.24|indexed into a row of this array here
6534.96|3.759|and that row gave us the probability
6536.56|4.559|distribution for the next character so
6538.719|4.881|the first character was used as a lookup
6541.119|4.0|into a
6543.6|2.639|matrix here to get the probability
6545.119|2.321|distribution
6546.239|3.361|well that's actually exactly what's
6547.44|4.4|happening here because we're taking the
6549.6|3.84|index we're encoding it as one hot and
6551.84|3.839|multiplying it by w
6553.44|4.4|so logics literally becomes
6555.679|2.161|the
6558.0|4.56|the appropriate row of w
6560.8|4.08|and that gets just as before
6562.56|3.679|exponentiated to create the counts
6564.88|2.56|and then normalized and becomes
6566.239|3.201|probability
6567.44|3.92|so this w here
6569.44|5.6|is literally
6571.36|6.879|the same as this array here
6575.04|5.599|but w remember is the log counts not the
6578.239|4.561|counts so it's more precise to say that
6580.639|5.52|w exponentiated
6582.8|6.48|w dot x is this array
6586.159|4.241|but this array was filled in by counting
6589.28|2.64|and by
6590.4|3.44|basically
6591.92|3.92|populating the counts of bi-grams
6593.84|4.08|whereas in the gradient-based framework
6595.84|3.52|we initialize it randomly and then we
6597.92|2.56|let the loss
6599.36|3.839|guide us
6600.48|5.28|to arrive at the exact same array
6603.199|3.52|so this array exactly here
6605.76|3.359|is
6606.719|5.52|basically the array w at the end of
6609.119|5.841|optimization except we arrived at it
6612.239|4.4|piece by piece by following the loss
6614.96|3.6|and that's why we also obtain the same
6616.639|3.841|loss function at the end and the second
6618.56|4.0|note is if i come here
6620.48|4.4|remember the smoothing where we added
6622.56|3.44|fake counts to our counts
6624.88|3.6|in order to
6626.0|4.96|smooth out and make more uniform the
6628.48|4.0|distributions of these probabilities
6630.96|4.0|and that prevented us from assigning
6632.48|4.639|zero probability to
6634.96|5.279|to any one bigram
6637.119|5.681|now if i increase the count here
6640.239|5.041|what's happening to the probability
6642.8|5.12|as i increase the count probability
6645.28|5.04|becomes more and more uniform
6647.92|4.64|right because these counts go only up to
6650.32|4.0|like 900 or whatever so if i'm adding
6652.56|3.84|plus a million to every single number
6654.32|4.08|here you can see how
6656.4|3.759|the row and its probability then when we
6658.4|4.56|divide is just going to become more and
6660.159|4.96|more close to exactly even probability
6662.96|3.6|uniform distribution
6665.119|5.681|it turns out that the gradient based
6666.56|6.559|framework has an equivalent to smoothing
6670.8|5.04|in particular
6673.119|5.361|think through these w's here
6675.84|4.24|which we initialized randomly
6678.48|3.6|we could also think about initializing
6680.08|5.84|w's to be zero
6682.08|5.44|if all the entries of w are zero
6685.92|2.799|then you'll see that logits will become
6687.52|2.639|all zero
6688.719|3.361|and then exponentiating those logics
6690.159|3.681|becomes all one
6692.08|3.599|and then the probabilities turned out to
6693.84|4.16|be exactly uniform
6695.679|5.52|so basically when w's are all equal to
6698.0|4.639|each other or say especially zero
6701.199|3.201|then the probabilities come out
6702.639|2.801|completely uniform
6704.4|4.799|so
6705.44|6.4|trying to incentivize w to be near zero
6709.199|4.241|is basically equivalent to
6711.84|3.6|label smoothing and the more you
6713.44|3.92|incentivize that in the loss function
6715.44|3.44|the more smooth distribution you're
6717.36|2.72|going to achieve
6718.88|1.96|so this brings us to something that's
6720.08|2.8|called
6720.84|4.12|regularization where we can actually
6722.88|3.6|augment the loss function to have a
6724.96|4.0|small component that we call a
6726.48|3.679|regularization loss
6728.96|3.44|in particular what we're going to do is
6730.159|4.401|we can take w and we can for example
6732.4|5.36|square all of its entries
6734.56|4.4|and then we can um whoops
6737.76|3.04|sorry about that
6738.96|4.4|we can take all the entries of w and we
6740.8|2.56|can sum them
6743.52|4.719|and because we're squaring uh there will
6745.76|4.08|be no signs anymore um
6748.239|3.201|negatives and positives all get squashed
6749.84|3.92|to be positive numbers
6751.44|4.799|and then the way this works is you
6753.76|5.68|achieve zero loss if w is exactly or
6756.239|4.88|zero but if w has non-zero numbers you
6759.44|3.36|accumulate loss
6761.119|3.761|and so we can actually take this and we
6762.8|6.0|can add it on here
6764.88|5.52|so we can do something like loss plus
6768.8|3.12|w square
6770.4|3.199|dot sum
6771.92|3.52|or let's actually instead of sum let's
6773.599|3.841|take a mean because otherwise the sum
6775.44|3.44|gets too large
6777.44|3.84|so mean is like a little bit more
6778.88|4.08|manageable
6781.28|4.24|and then we have a regularization loss
6782.96|3.759|here say 0.01 times
6785.52|3.76|or something like that you can choose
6786.719|5.52|the regularization strength
6789.28|5.12|and then we can just optimize this and
6792.239|4.161|now this optimization actually has two
6794.4|4.16|components not only is it trying to make
6796.4|3.44|all the probabilities work out but in
6798.56|3.52|addition to that there's an additional
6799.84|4.879|component that simultaneously tries to
6802.08|4.4|make all w's be zero because if w's are
6804.719|3.761|non-zero you feel a loss and so
6806.48|4.159|minimizing this the only way to achieve
6808.48|4.0|that is for w to be zero
6810.639|4.0|and so you can think of this as adding
6812.48|5.84|like a spring force or like a gravity
6814.639|5.361|force that that pushes w to be zero so w
6818.32|3.68|wants to be zero and the probabilities
6820.0|4.239|want to be uniform but they also
6822.0|4.32|simultaneously want to match up your
6824.239|3.121|your probabilities as indicated by the
6826.32|2.879|data
6827.36|5.279|and so the strength of this
6829.199|5.201|regularization is exactly controlling
6832.639|4.56|the amount of counts
6834.4|4.96|that you add here
6837.199|3.44|adding a lot more counts
6839.36|3.44|here
6840.639|4.0|corresponds to
6842.8|3.68|increasing this number
6844.639|3.361|because the more you increase it the
6846.48|4.4|more this part of the loss function
6848.0|5.599|dominates this part and the more these
6850.88|4.56|these weights will un be unable to grow
6853.599|4.721|because as they grow
6855.44|5.759|they uh accumulate way too much loss
6858.32|5.12|and so if this is strong enough
6861.199|5.52|then we are not able to overcome the
6863.44|4.64|force of this loss and we will never
6866.719|2.561|and basically everything will be uniform
6868.08|2.88|predictions
6869.28|3.76|so i thought that's kind of cool okay
6870.96|3.279|and lastly before we wrap up
6873.04|3.76|i wanted to show you how you would
6874.239|5.041|sample from this neural net model
6876.8|3.919|and i copy-pasted the sampling code from
6879.28|4.0|before
6880.719|3.52|where remember that we sampled five
6883.28|3.12|times
6884.239|6.241|and all we did we start at zero we
6886.4|5.92|grabbed the current ix row of p and that
6890.48|4.4|was our probability row
6892.32|4.399|from which we sampled the next index and
6894.88|4.0|just accumulated that and
6896.719|3.601|break when zero
6898.88|3.96|and running this
6900.32|5.2|gave us these
6902.84|4.759|results still have the
6905.52|3.599|p in memory so this is fine
6907.599|4.241|now
6909.119|5.761|the speed doesn't come from the row of b
6911.84|5.2|instead it comes from this neural net
6914.88|6.16|first we take ix
6917.04|5.36|and we encode it into a one hot row of x
6921.04|4.079|inc
6922.4|4.48|this x inc multiplies rw
6925.119|4.241|which really just plucks out the row of
6926.88|3.52|w corresponding to ix really that's
6929.36|3.759|what's happening
6930.4|4.319|and that gets our logits and then we
6933.119|3.441|normalize those low jets
6934.719|4.321|exponentiate to get counts and then
6936.56|4.72|normalize to get uh the distribution and
6939.04|5.04|then we can sample from the distribution
6941.28|2.8|so if i run this
6945.119|3.761|kind of anticlimactic or climatic
6947.199|3.681|depending how you look at it but we get
6948.88|3.359|the exact same result
6950.88|2.719|um
6952.239|3.44|and that's because this is in the
6953.599|3.361|identical model not only does it achieve
6955.679|2.401|the same loss
6956.96|2.32|but
6958.08|4.4|as i mentioned these are identical
6959.28|5.839|models and this w is the log counts of
6962.48|4.88|what we've estimated before but we came
6965.119|3.201|to this answer in a very different way
6967.36|2.96|and it's got a very different
6968.32|3.359|interpretation but fundamentally this is
6970.32|4.48|basically the same model and gives the
6971.679|4.48|same samples here and so
6974.8|3.359|that's kind of cool okay so we've
6976.159|4.321|actually covered a lot of ground we
6978.159|3.761|introduced the bigram character level
6980.48|3.6|language model
6981.92|4.0|we saw how we can train the model how we
6984.08|4.0|can sample from the model and how we can
6985.92|4.239|evaluate the quality of the model using
6988.08|3.519|the negative log likelihood loss
6990.159|3.281|and then we actually trained the model
6991.599|3.361|in two completely different ways that
6993.44|2.799|actually get the same result and the
6994.96|3.679|same model
6996.239|3.92|in the first way we just counted up the
6998.639|2.801|frequency of all the bigrams and
7000.159|4.401|normalized
7001.44|6.239|in a second way we used the
7004.56|6.24|negative log likelihood loss as a guide
7007.679|5.04|to optimizing the counts matrix
7010.8|4.16|or the counts array so that the loss is
7012.719|4.081|minimized in the in a gradient-based
7014.96|3.44|framework and we saw that both of them
7016.8|3.52|give the same result
7018.4|2.96|and
7020.32|2.16|that's it
7021.36|2.56|now the second one of these the
7022.48|3.6|gradient-based framework is much more
7023.92|4.239|flexible and right now our neural
7026.08|4.48|network is super simple we're taking a
7028.159|4.161|single previous character and we're
7030.56|3.44|taking it through a single linear layer
7032.32|3.919|to calculate the logits
7034.0|3.76|this is about to complexify so in the
7036.239|4.241|follow-up videos we're going to be
7037.76|4.08|taking more and more of these characters
7040.48|3.28|and we're going to be feeding them into
7041.84|3.52|a neural net but this neural net will
7043.76|4.16|still output the exact same thing the
7045.36|3.839|neural net will output logits
7047.92|2.96|and these logits will still be
7049.199|3.04|normalized in the exact same way and all
7050.88|2.799|the loss and everything else and the
7052.239|3.44|gradient gradient-based framework
7053.679|4.881|everything stays identical it's just
7055.679|4.801|that this neural net will now complexify
7058.56|3.679|all the way to transformers
7060.48|6.239|so that's gonna be pretty awesome and
7062.239|4.48|i'm looking forward to it for now bye