start_time|end_time|text
0.56|10.15|[Music]
11.759|4.481|today here with me is andre kerpafi
14.4|3.68|andre is the director of artificial
16.24|3.119|intelligence and autopilot vision at
18.08|2.48|tesla
19.359|2.641|he's one of the world's leading
20.56|3.36|visionaries in deep learning and
22.0|4.64|computer vision
23.92|4.16|ever since his phd days at stanford
26.64|3.52|back when deep learning was just
28.08|3.359|starting to emerge as a viable
30.16|2.88|technology
31.439|5.041|ander has not only been a leading
33.04|5.28|researcher but also leading educator
36.48|4.32|from there he became one of the founding
38.32|4.559|members of openai the ai research
40.8|4.72|organization in san francisco initially
42.879|3.68|largely funded by elon musk
45.52|2.96|and
46.559|4.801|from there at some point elon musk then
48.48|5.759|recruited andre to head up autopilot
51.36|5.039|efforts at tesla
54.239|3.681|andre you and i used to spend so much
56.399|3.441|time together
57.92|4.4|for listeners andre and i used to work
59.84|4.319|together at openai but we also used to
62.32|4.56|see each other at all of the ai
64.159|4.32|conferences academic working groups but
66.88|3.2|now it's actually been quite a while
68.479|4.0|since we've seen each other and so i'm
70.08|4.079|excited to get to catch up not even sure
72.479|4.401|when is the last time we saw each other
74.159|5.761|maybe nerves maybe my wedding maybe
76.88|5.76|covering offices do you remember
79.92|4.4|i do it was just before the pandemic i
82.64|4.24|think
84.32|4.96|right before pandemic was always i've
86.88|3.84|been at nerves in vancouver
89.28|3.04|yeah i remember
90.72|4.48|i remember the
92.32|5.839|the burgers we went to eating as a live
95.2|5.279|bar across the conference center
98.159|4.401|yeah those were days um and of course i
100.479|5.28|visited covariant and saw your offices
102.56|5.199|and uh we had a chance to talk there
105.759|5.36|which was a lot of fun i hope we can
107.759|4.72|host you again sometime soon um
111.119|3.601|now
112.479|4.161|i actually spent most of yesterday
114.72|2.96|watching all the videos listed on your
116.64|2.479|website
117.68|4.24|absolutely brilliant
119.119|4.64|what you've achieved and how you explain
121.92|4.239|it there
123.759|4.881|now can you tell our listeners a little
126.159|3.681|bit about how you went
128.64|2.72|from
129.84|3.119|slovakia
131.36|4.959|age 15
132.959|6.241|to becoming tesla's ai director that's a
136.319|4.801|quite all-encompassing question
139.2|3.679|yeah it's a long story
141.12|4.88|so as you mentioned my parents decided
142.879|4.72|to immigrate to canada when i was 15.
146.0|4.4|um
147.599|4.961|and yeah i was not a very happy sort of
150.4|3.119|person in slovakia i always wanted to
152.56|2.64|leave
153.519|4.72|slovak has
155.2|4.48|not a not an incredibly ambitious place
158.239|3.841|and
159.68|4.4|i felt that um i was upper bounded in
162.08|4.4|terms of what i can achieve there and so
164.08|4.879|i always wanted to go to canada america
166.48|4.8|and uh do something substantial
168.959|5.521|and um so when they asked when they kind
171.28|6.959|of hinted that we may be able to uh
174.48|5.44|go to canada i was on board instantly um
178.239|3.441|and then my sister was not quite as on
179.92|3.92|board and you know everyone else in the
181.68|5.04|family as well but i sort of worked to
183.84|4.72|convince everyone make the move
186.72|3.12|and
188.56|3.039|yeah so
189.84|5.6|we came to canada i started in high
191.599|5.041|school i barely spoke any english
195.44|3.12|i had to
196.64|3.76|learn english i was very good at math
198.56|4.399|luckily the slovakian curriculum is
200.4|4.96|quite good at math
202.959|2.401|and so
206.0|3.84|i was able to sort of
208.0|3.04|get into their good courses and go
209.84|3.119|through high school
211.04|4.0|join the university of toronto and kind
212.959|4.801|of get into computer science and and so
215.04|4.32|on uh it is a long story
217.76|3.119|it is a long story but i think there are
219.36|2.879|some really interesting parts to it for
220.879|3.521|example
222.239|4.481|somewhere i read that
224.4|5.28|jeff hinton at toronto is the one who
226.72|4.4|first showed you neural networks yeah
229.68|3.119|yeah so in the university of toronto is
231.12|3.44|when i first came into contact sort of
232.799|4.241|with deep learning through jeff hinton's
234.56|5.2|class and he taught the class and at the
237.04|4.8|time this was a very very simple
239.76|4.8|primordial deep learning so we were
241.84|4.72|looking at little digits white on black
244.56|4.319|three two four one and we're trying to
246.56|3.92|recognize you know those digits and so
248.879|4.401|by today's standards these were
250.48|5.84|incredibly toy problems um
253.28|5.76|and uh i was fascinated by the way that
256.32|3.52|jeff hinton spoke about these algorithms
259.04|2.56|um
259.84|3.44|he kept making analogies to the human
261.6|2.8|brain and
263.28|2.96|um
264.4|4.079|you know the way he talked about the
266.24|4.08|neural net it was like in the mind of
268.479|3.681|the network and he kept using these
270.32|3.84|anthropomorphic descriptions for what
272.16|4.319|was going on in the algorithm and i
274.16|3.92|found that analogy fascinating and so
276.479|3.921|that's kind of what pulled me in i would
278.08|5.92|say into the entire area
280.4|5.84|and then yeah i i audited the class um
284.0|4.4|and i also went to some of the reading
286.24|3.92|groups that he hosted with his students
288.4|3.04|and that's basically when i became
290.16|3.52|extremely interested in deep learning
291.44|3.12|and have been in deep learning since
293.68|3.84|now
294.56|4.639|if we jump ahead a little bit i think
297.52|4.56|the first time you really
299.199|4.881|were very visible as somebody in uh deep
302.08|4.0|learning was during your phd days at
304.08|3.6|stanford when you were the one who were
306.08|3.92|generating a lot of the research
307.68|4.32|progress and educational content can you
310.0|4.16|say a bit more about
312.0|4.24|uh how do you get going on that at
314.16|5.2|stanford yeah so i think you're alluding
316.24|5.36|to cs231n the class that i ended up
319.36|3.76|basically uh
321.6|3.439|designing to a very large extent and
323.12|3.84|then being the primary instructor for
325.039|4.081|together with faith hey and it was
326.96|5.44|really the first deep learning class at
329.12|5.359|stanford and became extremely successful
332.4|4.88|so in the first offering it was maybe
334.479|4.081|150 students or so and by the time i
337.28|3.44|left it was
338.56|3.6|700 or so
340.72|3.199|and so this became one of the biggest
342.16|2.879|classes at stanford
343.919|2.961|um
345.039|5.521|and the way it came about i've always
346.88|5.52|had a passion for teaching and even
350.56|3.68|during my master's degree at university
352.4|3.76|of british columbia
354.24|3.84|ta in different classes was always the
356.16|4.319|highlight of my experience
358.08|4.399|i just love watching people learn new
360.479|4.801|skills and then go out and do cool
362.479|6.0|things with those skills and
365.28|5.759|i feel like it's such a large lever over
368.479|4.801|you know kind of impact it's indirect
371.039|4.88|but i think it's a very large lever
373.28|4.32|and so i was i was really um
375.919|3.361|you know just very passionate about
377.6|3.28|teaching in general
379.28|2.88|and deep learning at the time was
380.88|4.8|starting to have some of its first
382.16|4.879|successes uh so in 2012 uh we had the
385.68|3.84|first um
387.039|4.401|convolutional neural network uh give a
389.52|4.16|stunning performance on this imagenet
391.44|4.08|benchmark in
393.68|3.2|in computer vision and image
395.52|3.36|classification
396.88|3.759|and a lot of people suddenly paid a lot
398.88|3.599|of attention to deep learning
400.639|3.521|and i happened to
402.479|3.84|be in a place where i understood the
404.16|5.039|technology and i was very passionate
406.319|4.801|about teaching and faith approached me
409.199|3.921|and she pitched me on the idea that hey
411.12|5.28|we could start a class and actually
413.12|5.44|teach people about this and i instantly
416.4|3.76|i instantly jumped at the idea i loved
418.56|4.16|it i
420.16|4.159|put my entire phd in research on hold
422.72|3.919|it's not something you would typically
424.319|5.201|want to do as a phd student because your
426.639|4.641|primary output is research and i ended
429.52|3.04|up not doing basically any research for
431.28|3.84|maybe a year
432.56|5.759|because i just focused on the class and
435.12|4.88|its design but i felt like it was
438.319|3.841|probably more impactful than getting a
440.0|4.8|paper or two out to actually like do
442.16|3.599|this class and do a good job of it
444.8|2.56|and
445.759|3.28|yeah so we came up with the curriculum
447.36|3.839|and taught it and it was amazing and it
449.039|5.201|was probably the highlight of my phd
451.199|3.041|so andre i mean
454.479|3.361|a lot of people already know this but
456.08|3.04|some people probably don't
457.84|4.479|i mean you're saying this class went
459.12|5.759|from 150 to 700 students from year one
462.319|4.0|to year two but the reality is much
464.879|4.0|bigger than that of course i mean this
466.319|5.28|class was put on youtube and there were
468.879|4.961|hundreds of thousands of if not millions
471.599|3.6|of people watching your lectures
473.84|4.639|because it wasn't just the first
475.199|4.641|stanford class it was the class that
478.479|4.16|everybody
479.84|4.88|was watching following along
482.639|4.321|because deep playing was this new thing
484.72|4.4|and it was the place you would go if you
486.96|4.16|wanted to understand it you had to go to
489.12|4.799|andre karpathy's class that that's where
491.12|3.919|everybody went and so i think yeah i
493.919|3.68|just want to
495.039|4.481|clarify there's more than 700 people who
497.599|4.801|were active in that class
499.52|5.28|um yeah absolutely i did think it had a
502.4|4.88|larger reach than i had anticipated at
504.8|3.839|the time of course by a lot i still
507.28|3.759|people come up to me randomly in
508.639|4.4|conferences and even in like in a coffee
511.039|3.601|shop and tell me that they've uh you
513.039|3.041|know they saw my class and they really
514.64|3.6|enjoyed it and
516.08|3.519|you know i i've heard it many times but
518.24|2.239|it always brings the same amount of
519.599|2.56|pleasure
520.479|4.001|and so i feel like that was a very good
522.159|4.24|investment in time very proud of it
524.48|5.2|when you go and check out one of andre's
526.399|5.841|videos the most frequent comment is
529.68|5.36|just two words my hero that's that's
532.24|4.64|what you say because that you opened up
535.04|4.72|a whole field for
536.88|4.399|so many people that was hard to access
539.76|2.639|and all of a sudden they could be part
541.279|2.961|of it
542.399|4.401|um now
544.24|4.0|how would you explain
546.8|3.36|that that moment that triggered your
548.24|4.48|teaching the class you said imagenet
550.16|4.239|happened in 2012.
552.72|3.119|what happened there what was that all
554.399|4.241|about
555.839|4.0|yeah so as i mentioned when i first
558.64|3.04|encountered deep learning in jeff
559.839|3.921|hinton's class we were working with
561.68|5.12|these tiny black and white images so
563.76|4.88|these are tiny 28 by 28 images where you
566.8|4.719|have like a single digit like a seven or
568.64|4.24|six and we're trying to recognize
571.519|3.361|like what it is
572.88|3.519|and so deep learning which is this class
574.88|4.8|of
576.399|4.481|neural network neural networks
579.68|2.88|approaches
580.88|3.12|where
582.56|3.76|you basically have neurons that are
584.0|4.0|connected to each other with different
586.32|3.76|strengths and you're trying to tune the
588.0|4.72|strengths between the neurons so that
590.08|4.4|they take your input in this case this
592.72|4.239|image and try to
594.48|5.12|you know the the neurons fire in the
596.959|5.601|sequence and then the last neurons tell
599.6|4.72|you which digit it is in the image
602.56|4.959|and so it's a class of technology that
604.32|6.16|was used in these super toy problems
607.519|4.961|and when i entered uh stanford and i was
610.48|4.479|in computer vision these approaches were
612.48|4.0|not uh what you would use for computer
614.959|4.56|vision applications
616.48|5.359|so computer vision was a
619.519|4.88|field that was mostly working with much
621.839|4.56|larger higher resolution images so we're
624.399|6.321|talking you know what one two three
626.399|6.321|megapixel inputs so 1000 by 1000 images
630.72|3.04|real normal big images
632.72|2.72|and
633.76|3.84|it was thought and there was a very
635.44|4.079|different class of approaches to how you
637.6|4.16|um you know attack computer vision
639.519|5.281|problems in those settings
641.76|4.56|and so at the time no one was using deep
644.8|3.36|learning in computer vision deep
646.32|3.28|learning was this branch of machine
648.16|2.64|learning out there
649.6|2.239|somewhere
650.8|3.52|and
651.839|4.161|it was very different not used and it
654.32|4.24|was thought the conventional wisdom at
656.0|4.399|the time was that these approaches would
658.56|3.68|not scale to large
660.399|4.961|resolution images
662.24|5.279|and it was in 2012 that uh jeff hinton
665.36|4.08|and his team um in the university of
667.519|4.641|toronto uh ask kurchevsky and elia
669.44|4.72|suskover published a paper showing
672.16|4.239|that a scaled up version of the neural
674.16|3.76|network uh really running
676.399|4.0|running on special
677.92|6.56|you know gpus in the computer a special
680.399|4.081|type of processor that is um
684.56|2.24|very
687.36|3.36|that is very good at running these kinds
688.959|3.841|of computations that make up the neural
690.72|3.359|network that when you scale up these
692.8|3.039|networks so it's not just a little baby
694.079|3.2|network with a couple thousand neurons
695.839|2.801|but it's actually a much bigger network
697.279|3.601|with several hundred thousand of them
698.64|4.72|connected with like millions of uh
700.88|4.24|weights and synapses
703.36|4.479|that actually these can do incredibly
705.12|5.36|well even on normal sized images and
707.839|4.0|achieve extremely good performance
710.48|3.359|compared to what was available in
711.839|4.641|computer vision at the time
713.839|5.68|and this turned the entire field upside
716.48|5.52|down it was a massive tectonic change in
719.519|5.361|computer vision so if you visited a
722.0|5.04|computer vision conference in 2012
724.88|4.56|there would be basically like one or two
727.04|4.16|papers on deep learning but if you visit
729.44|3.199|it five years later
731.2|4.879|it would be one or two papers that are
732.639|5.281|not deep learning it was a complete
736.079|3.281|upheaval
737.92|3.039|and today of course he would not dream
739.36|2.56|of doing computer vision without deep
740.959|3.361|learning
741.92|3.76|so i happened to be at the right place
744.32|4.8|at the right time
745.68|5.68|with interest in education and uh stars
749.12|4.64|sort of aligned in the way that
751.36|4.159|i was able to explain the material and
753.76|3.759|hopefully empower a lot of people to use
755.519|4.56|this powerful technology for computer
757.519|4.721|vision problems in the world now
760.079|5.44|you absolutely did and i'm curious if
762.24|6.159|you had to describe just deep learning
765.519|4.641|let's put aside image in that moment for
768.399|4.961|just deep learning itself how would you
770.16|4.799|describe deep learning to i don't know
773.36|2.56|your parents or
774.959|3.361|you know
775.92|4.08|uncle or something who doesn't work in
778.32|4.0|in the space let's use a specific
780.0|4.079|example because i think it's useful so
782.32|4.639|let's let's talk about image recognition
784.079|5.601|right so we have images and they are
786.959|4.721|just um images are made up to computer
789.68|3.599|of a large number of pixels
791.68|3.2|and each pixel just tells you the amount
793.279|3.921|of brightness in the red green and blue
794.88|4.079|channel at that point and so you have a
797.2|4.96|large array of numbers and you have to
798.959|6.32|go from that to hey it's a cat or a dog
802.16|6.16|and typical conventional software is
805.279|5.601|written by a person programmer writing a
808.32|4.88|series of instructions to go from the
810.88|4.56|input to the output so in this case you
813.2|4.079|want someone to write a program for how
815.44|3.68|do you combine these millions of pixel
817.279|4.081|values into
819.12|4.399|like is it a cat or a dog turns out no
821.36|4.08|one can write this program it's a very
823.519|3.601|complicated program because there's a
825.44|3.199|huge amount of variability in what a cat
827.12|4.32|or doc can look like in different
828.639|4.241|brightness conditions arrangements poses
831.44|3.839|occlusions
832.88|3.36|basically no one can write this program
835.279|4.161|so
836.24|5.279|deep learning is a different class of
839.44|4.48|programming in my mind
841.519|4.961|where no one is explicitly writing the
843.92|4.64|algorithm for this recognition problem
846.48|3.599|instead we are
848.56|4.56|structuring the entire process slightly
850.079|6.401|differently so in particular we arrange
853.12|4.079|a large data set of uh possible images
856.48|1.599|and
857.199|2.64|um
858.079|3.601|the desired labels that should come out
859.839|3.761|from the algorithm so hey when you get
861.68|3.68|this input this is a cat when you get
863.6|4.239|this output this should be a dog and so
865.36|4.24|on so we're kind of stipulating what is
867.839|2.961|the desired behavior on a high level
869.6|3.2|we're not talking about what is the
870.8|4.32|algorithm we're measuring the
872.8|4.24|performance of some algorithm
875.12|3.68|and then you need some
877.04|2.88|and then roughly what we do is we lay
878.8|4.24|out
879.92|4.8|a neural network which is these um
883.04|4.4|it's it's a bunch of neurons connected
884.72|4.799|to each other with some strengths and
887.44|3.92|you you feed them images and they
889.519|5.12|predict what's in them
891.36|4.719|and the problem now is reduced because
894.639|3.2|um you're just trying to find the
896.079|4.161|setting of these synaptic strengths
897.839|3.841|between the neurons so that the outcomes
900.24|4.32|are what you want
901.68|5.519|and so as an example the 2012 imagenet
904.56|5.12|model which was roughly 60 million
907.199|5.2|parameters so the weights of the neural
909.68|4.959|network were really 60 million knobs and
912.399|4.081|those knobs can be arbitrary values
914.639|4.0|and how do you set the 60 million
916.48|4.0|weights so that the network gives you
918.639|4.32|the correct predictions
920.48|4.56|and so deep learning is is a class of is
922.959|4.0|a way of of
925.04|3.919|training this neural network and finding
926.959|3.041|a good setting of these 60 million
928.959|2.161|numbers
930.0|3.68|um
931.12|4.399|and so roughly uh the neural network
933.68|3.68|sort of looks at the image gives you a
935.519|3.44|prediction and then you measure the
937.36|4.96|error it's like okay you said this is a
938.959|5.601|cat but actually this is a dog and then
942.32|4.639|and there's a mathematical procedure for
944.56|4.56|tuning uh the strengths
946.959|3.761|so that the neural network adapts itself
949.12|3.68|to agree with you
950.72|4.32|and so deep learning is is basically a
952.8|4.8|different software programming paradigm
955.04|4.56|where we specify what we want
957.6|4.239|and then we use sort of mathematics and
959.6|3.84|algorithms to tune the system to give
961.839|2.401|you what you want
963.44|2.48|and
964.24|2.959|there's some design that goes into the
965.92|3.12|neural network architecture and how do
967.199|3.76|you wire everything up but then there's
969.04|4.479|also a huge amount of design and effort
970.959|4.88|spent on the data sets themselves and
973.519|3.841|curating them and
975.839|3.36|you know because those data sets are now
977.36|3.76|your constraints on the behavior that
979.199|3.361|you are asking from the system
981.12|3.12|so it's a very different way of
982.56|3.6|approaching problems that was not there
984.24|3.599|before everything used to be written by
986.16|4.0|person now we just write the
987.839|4.881|specification and we write a rough
990.16|4.56|layout of the algorithm but it's a it's
992.72|3.039|what i refer to as fill in the blanks
994.72|2.16|programming
995.759|2.721|because we sort of lay out an
996.88|3.6|architecture and a rough layout of the
998.48|4.159|net but there's a huge amount of blanks
1000.48|4.799|which are the weights and the knobs and
1002.639|4.241|those are set now during the training of
1005.279|3.92|this network
1006.88|3.519|so that's i think the bird's eye view of
1009.199|3.76|how this is different
1010.399|6.161|i like the way you explain that and
1012.959|5.12|and it's of course no coincidence that
1016.56|4.32|you're heading up
1018.079|4.401|self-driving at tesla
1020.88|3.84|and that you're one of the world leading
1022.48|3.52|experts in this exact discipline of deep
1024.72|3.199|learning there's got to be a strong
1026.0|3.76|connection there i want to i want to go
1027.919|4.081|a little bit towards the tesla side of
1029.76|2.24|things
1033.679|4.801|what was the moment you decided to join
1035.439|6.081|tesla how did that come about
1038.48|4.959|yeah so um after my phd at stanford i
1041.52|3.6|went to be a research scientist one of
1043.439|4.48|the founding members at openai which is
1045.12|4.72|where we overlapped briefly as well
1047.919|5.041|and i spent about
1049.84|5.28|almost two years at openai and by the
1052.96|3.839|time of two years at open ai i have been
1055.12|4.16|doing research for
1056.799|5.201|about a decade so my master's degree my
1059.28|4.639|phd and then open ai and so i spent
1062.0|4.48|about a decade reading and writing
1063.919|5.041|papers and working on you know training
1066.48|3.92|neural networks but in an academic
1068.96|3.04|setting mostly
1070.4|3.76|and so i was definitely getting a little
1072.0|3.44|bit restless at that time
1074.16|3.28|because
1075.44|3.2|i felt like
1077.44|3.359|these
1078.64|5.36|these algorithms are extremely powerful
1080.799|4.0|and uh can can really move the needle
1084.0|2.72|um
1084.799|5.281|on some very incredibly important
1086.72|5.44|problems in society and um
1090.08|4.0|i wanted to take a more active role in
1092.16|3.6|doing that and so i was getting a bit
1094.08|3.2|restless i was looking at different
1095.76|3.6|opportunities and say startups and
1097.28|4.16|things like that and then one thing that
1099.36|4.319|kind of happened on the side is because
1101.44|5.84|openai was at the time
1103.679|5.761|under the umbrella of elon organizations
1107.28|3.84|a few times we were interacting with
1109.44|3.52|people at tesla and i was kind of
1111.12|3.6|consulting a little bit for some of the
1112.96|2.8|problems in the autopilot
1114.72|2.0|and
1115.76|2.72|um
1116.72|3.28|i kind of realized that they were
1118.48|2.96|dealing with fundamentally a deep
1120.0|2.72|learning computer vision problem and
1121.44|3.04|this was the
1122.72|3.839|fundamental constraint to whether or not
1124.48|2.8|this product would work
1126.559|2.24|and
1127.28|3.04|so i was kind of like intrigued by that
1128.799|3.12|but it was just a few consulting
1130.32|3.359|opportunities in here and there i sort
1131.919|3.281|of spoke to the team
1133.679|3.521|but at this time when i was getting
1135.2|4.08|really restless to applied
1137.2|4.479|technology in the industry actually elon
1139.28|4.32|reached out and he asked me hey you've
1141.679|5.041|been like sort of consulting for for the
1143.6|4.72|team um do you actually want to join in
1146.72|5.28|and lead the computer vision team and
1148.32|4.8|the ai team here and um help get this
1152.0|3.36|car to drive
1153.12|4.32|and so he caught me at a very
1155.36|4.64|kind of correct time when i was really
1157.44|4.72|getting restless and i felt like
1160.0|3.36|this is perfect and i think i can do
1162.16|2.24|this i think i have the skills to
1163.36|2.8|contribute here
1164.4|4.32|this is an incredibly impactful
1166.16|4.08|opportunity and i love the company and
1168.72|4.0|of course i love elon and everything
1170.24|3.92|that he's doing and so i would say that
1172.72|3.52|again sort of it was a moment where
1174.16|3.44|stars aligned for me and i felt very
1176.24|2.64|strongly that this is the right thing to
1177.6|3.28|do at this time
1178.88|3.919|and so i left open ai and i've been at
1180.88|4.72|tesla for the last four years or so
1182.799|4.321|almost uh so yeah it's been some time
1185.6|3.76|yeah i've been there for four years and
1187.12|3.6|kind of finally i remember this moment
1189.36|2.88|where
1190.72|3.12|you were just about to leave open the
1192.24|4.08|eye and
1193.84|3.6|a bunch of us are chatting about your
1196.32|3.359|plans
1197.44|4.96|and you're joking
1199.679|4.561|uh but you're also half serious
1202.4|4.159|and and you're saying
1204.24|5.28|well you know this is a job that on
1206.559|4.801|average uh people last six months and
1209.52|4.08|then you want to take time for somebody
1211.36|3.92|else to take over and here you are an
1213.6|3.92|average six months leading up to when
1215.28|3.68|you started and now almost four years
1217.52|4.399|and
1218.96|4.719|knowing this i think knock on wood um of
1221.919|4.0|how this is going this is just amazing
1223.679|4.081|uh yeah that that's accurate i was aware
1225.919|3.521|of the average tenure uh at tesla
1227.76|4.24|especially when you're working on very
1229.44|5.68|important projects very close to elon
1232.0|4.32|and so um yeah i was very much aware of
1235.12|2.96|this so when i made your transition to
1236.32|3.599|tesla for example i did not give up my
1238.08|3.68|apartment in san francisco because i was
1239.919|3.681|just kind of like
1241.76|3.2|not you know
1243.6|3.12|really hedging my bets on what's going
1244.96|3.36|to happen in the next few months but uh
1246.72|3.04|yeah here i am for four years later
1248.32|4.88|still here
1249.76|5.919|yeah amazing i'm curious um if you look
1253.2|3.359|at the tesla mission statement it's
1255.679|5.041|about
1256.559|6.801|transition to renewable energy right
1260.72|4.48|um which
1263.36|4.24|i'd like first sight
1265.2|5.12|doesn't seem to directly tie into
1267.6|4.48|self-driving being kind of
1270.32|3.44|part of wanting to transition to
1272.08|4.0|renewable energy so can you say a bit
1273.76|3.919|about how self-driving and renewable
1276.08|4.64|energy play together yeah i think it's
1277.679|5.12|it's a good question i think broadly
1280.72|3.839|elon sort of has a number of companies
1282.799|3.36|and a number of bets around just a
1284.559|3.281|higher level goal of
1286.159|4.64|you know making the future good increase
1287.84|3.92|the probability of the future being good
1290.799|2.081|um
1291.76|3.039|and
1292.88|4.08|you know there's there's many aspects of
1294.799|4.481|the to that of course and he's vote he's
1296.96|4.48|focused the tesla mission around um
1299.28|3.519|you know
1301.44|4.32|accelerating the transition to
1302.799|4.801|sustainable energy fundamentally a large
1305.76|4.72|piece of this is getting people to
1307.6|5.36|transition to electric vehicles
1310.48|4.319|and we need to manufacture them at scale
1312.96|3.92|and we want them to
1314.799|3.601|to look like the future and so the
1316.88|3.279|entire product itself
1318.4|4.96|uh sort of looks like the future it's a
1320.159|7.121|very clean design and uh you want to be
1323.36|5.52|inspired by progress in society and and
1327.28|4.0|that things are developing in a positive
1328.88|4.64|direction and so the car looks much more
1331.28|4.399|futuristic and i think a big part of
1333.52|5.12|that also is that the car becomes
1335.679|4.561|uh sort of um you know it just becomes
1338.64|4.08|something magical in your life that can
1340.24|3.84|take you around in this beautiful future
1342.72|5.52|and so i think
1344.08|6.24|autonomy really is um
1348.24|4.799|part of just a broader vision to to this
1350.32|4.719|future that we want to be part of where
1353.039|4.481|we are driving uh electric vehicles with
1355.039|4.561|very little footprint and uh the society
1357.52|3.92|is sort of automated to a large extent
1359.6|4.48|and there's a huge amount of problems of
1361.44|4.239|course also around transportation and
1364.08|3.12|putting people in the loop
1365.679|5.36|with the amount of accidents that they
1367.2|5.52|get into and also with the fact that
1371.039|3.681|you don't want people to be really
1372.72|4.72|driving these cars because human brain
1374.72|4.72|is capable of so many beautiful things
1377.44|3.68|uh so why should you solve the line
1379.44|3.52|following problem
1381.12|2.799|you know that that is not a good use of
1382.96|2.8|the brain
1383.919|4.24|uh bit harder than have to build it
1385.76|4.08|though isn't it so not only is it unsafe
1388.159|2.961|to drive these cars it's also just you
1389.84|3.04|want the brains to be doing something
1391.12|4.88|different um and so we have the
1392.88|4.56|technology to to address this um
1396.0|3.28|so that's why
1397.44|3.2|yeah we're working on it that's really
1399.28|3.68|intriguing that the way i'm
1400.64|4.8|internalizing this is that
1402.96|4.4|if you want people to transition off
1405.44|4.4|something they like
1407.36|4.16|people right like their existing cars
1409.84|3.52|you gotta you can't just tell them let
1411.52|3.92|go of your existing cars
1413.36|3.679|and you know stop using them you got to
1415.44|4.0|show them something even shinier
1417.039|4.321|something even more exciting
1419.44|3.68|that in the process also gets them onto
1421.36|3.439|renewables yeah we want people to
1423.12|3.2|transition to electric vehicles that are
1424.799|3.681|also
1426.32|4.16|very competent in the world and
1428.48|4.16|transport you around before we dive into
1430.48|4.079|the technology itself for self-driving
1432.64|3.6|got got another question at the higher
1434.559|4.0|level which is
1436.24|4.559|how is it working with elon musk i mean
1438.559|4.401|he he might well be the most famous
1440.799|5.201|person in the world at this point and
1442.96|5.599|you are actually working with him
1446.0|3.76|what is that like well he's obviously a
1448.559|3.281|very
1449.76|3.12|incredible person in many ways i'm still
1451.84|4.079|trying to
1452.88|5.12|really map out his superpowers
1455.919|4.321|he has incredibly well developed
1458.0|4.4|intuition i would say in many aspects
1460.24|3.439|where uh
1462.4|3.759|he makes
1463.679|3.921|the right judgment calls sometimes in
1466.159|3.921|what i perceive to be a lack of
1467.6|4.24|information uh like
1470.08|4.8|because he's not fully in detail of all
1471.84|4.4|the things um but yet his judgment is
1474.88|2.159|extremely good
1476.24|4.48|um
1477.039|5.601|and so i i still haven't fully
1480.72|3.839|sort of understood how that happens he
1482.64|3.6|has a way of taking a very complex
1484.559|3.12|system and simplifying it to just like
1486.24|3.039|the fundamentals and the really the
1487.679|3.681|first principal components of what
1489.279|4.961|really matters about the system and then
1491.36|4.48|making uh statements about about those
1494.24|4.0|and so it's a very different way of
1495.84|4.88|thinking that i find kind of fascinating
1498.24|4.4|by default for example um
1500.72|3.36|sometimes i get sort of overwhelmed by
1502.64|3.039|the system i feel like i need to know
1504.08|3.52|the system in its full detail to make
1505.679|4.721|the correct decisions but that's not how
1507.6|5.36|he operates he somehow has a way to
1510.4|4.56|distill the system into a much simpler
1512.96|4.0|system in which he operates
1514.96|4.56|and so i think i've learned a lot about
1516.96|3.599|just how to approach problems and uh you
1519.52|4.399|know
1520.559|4.641|he's a double-edged sword because um
1523.919|3.521|in terms of working with him right
1525.2|4.88|because he wants the future yesterday
1527.44|3.92|and uh you know he uh he will push
1530.08|3.36|people and he will inject a lot of
1531.36|3.919|energy and he wants it to happen quickly
1533.44|4.32|and you have to be of a certain
1535.279|4.321|i think uh attitude to really tolerate
1537.76|3.519|that over long periods of time
1539.6|3.36|but he surrounds himself with people who
1541.279|3.601|get energy out of that and they also
1542.96|3.12|want the future to happen quicker
1544.88|3.36|and
1546.08|4.24|those people really thrive at tesla and
1548.24|4.48|so i happen to also
1550.32|3.92|i think be like that and so i don't
1552.72|3.439|personally mind it i actually kind of
1554.24|4.0|thrive on it
1556.159|2.961|and i love the energy of
1558.24|3.439|of
1559.12|4.559|getting this to work faster and uh you
1561.679|3.681|know making a difference
1563.679|3.841|and having this impact
1565.36|4.0|and so i really enjoy working with him
1567.52|3.92|because he has a way of injecting energy
1569.36|4.4|into the system
1571.44|5.2|driving momentum and he has incredibly
1573.76|4.96|good good and developed judgment and so
1576.64|3.84|yeah i overall just
1578.72|4.48|really really enjoyed working with him
1580.48|5.199|sounds wonderful would you say you talk
1583.2|3.76|with him pretty much every week or
1585.679|3.36|whatever that's right so we have
1586.96|4.319|autopilot meetings that range from a
1589.039|4.961|week to multiple times a week depending
1591.279|4.64|on uh you know just how much scrutiny is
1594.0|4.24|being put on the autopilot maybe right
1595.919|5.12|in front of releases we would have uh
1598.24|4.319|more than a week and multiple times in
1601.039|2.801|the history of the team it's been every
1602.559|2.641|single day
1603.84|3.28|um
1605.2|3.68|and uh
1607.12|2.88|so yeah on any of those frequencies
1608.88|3.919|depending on
1610.0|6.08|what's happening that's so exciting wow
1612.799|7.201|now if we think about self-driving cars
1616.08|6.56|it's probably the kind of most tangible
1620.0|4.64|ai concept for the public
1622.64|4.88|because so many people have cars and
1624.64|4.24|it's how their car is going to change
1627.52|3.12|because of
1628.88|2.72|ai right
1630.64|2.48|and
1631.6|3.84|certainly one of the most written about
1633.12|4.4|aspects of ai research and application
1635.44|3.04|in the press
1637.52|2.879|but
1638.48|6.24|not everybody really realizes
1640.399|6.081|how driverless cars and ai are connected
1644.72|3.52|what is the backstory there how long
1646.48|4.079|have people been working on self-driving
1648.24|4.08|cars and
1650.559|4.321|what is the ai role what is what is
1652.32|3.92|happening under the hood yeah so
1654.88|3.2|people have of course been thinking
1656.24|3.6|about cars that drive themselves for a
1658.08|4.16|very long time
1659.84|4.959|some things are very easy to
1662.24|4.88|imagine but very difficult to execute on
1664.799|4.721|like driverless cars
1667.12|4.559|some things are not like that um so for
1669.52|4.0|example a cryptocurrency in bitcoin is
1671.679|3.12|hard to sort of come up with so you
1673.52|3.279|won't see something like that maybe
1674.799|3.6|featured in as much sci-fi
1676.799|2.801|but driverless cars are something that
1678.399|3.121|people have been dreaming about for a
1679.6|4.0|very long time
1681.52|2.879|and working on for a long time
1683.6|2.4|um
1684.399|3.28|and i think fundamentally what makes it
1686.0|3.039|hard is
1687.679|3.281|right that you have to deal with a huge
1689.039|3.441|amount of variability of what the world
1690.96|2.719|looks like
1692.48|3.919|and
1693.679|6.0|it's roughly it's basically true that
1696.399|5.921|for ai and technology as it is today
1699.679|4.48|the degree of difficulty is proportional
1702.32|4.079|to the degree of variability you're
1704.159|4.0|going to encounter in the application
1706.399|3.121|so the more scenarios you have to deal
1708.159|2.64|with the harder it will be for the
1709.52|3.039|technology
1710.799|4.161|and that's what makes this hard for
1712.559|3.761|self-driving cars as well is that
1714.96|3.36|environments out there are quite
1716.32|3.92|variable maybe on the highway you're
1718.32|3.599|just dealing with lane following but
1720.24|3.12|once you get off the highway into city
1721.919|3.841|streets
1723.36|3.679|for in san francisco and so on the the
1725.76|2.56|amount of things you can encounter is
1727.039|3.601|very large
1728.32|3.359|and designing to it is incredibly
1730.64|3.44|difficult
1731.679|5.521|and that's where all the action is you
1734.08|6.64|hit upon variability right that that's
1737.2|4.88|that's making it so hard can you
1740.72|3.76|dig a little deeper
1742.08|4.56|why this variability
1744.48|3.12|make it hard so like i mentioned you
1746.64|2.24|want
1747.6|2.4|you are giving
1748.88|3.039|like when you're creating these deep
1750.0|3.36|learning systems you are giving them
1751.919|2.561|some kind of a specification for how
1753.36|2.16|they should act in different
1754.48|3.04|environments
1755.52|3.279|in different cases so hey this is a cat
1757.52|2.72|this is a dog
1758.799|2.801|and
1760.24|3.439|um
1761.6|4.0|the network starts from scratch it's not
1763.679|3.6|like your human brain that is born into
1765.6|3.76|a three-dimensional physical reality
1767.279|3.76|where you sort of understand a lot of
1769.36|3.76|objects and you come with all these all
1771.039|3.601|this built-in hardware but then also
1773.12|3.12|incredibly powerful learning algorithms
1774.64|3.519|so you can understand objects object
1776.24|3.919|permanence and how the world works these
1778.159|3.921|neural networks um they are made up of
1780.159|3.76|neurons like your brain but they
1782.08|3.52|function they actually it's a very
1783.919|3.76|it's not an exactly correct analogy and
1785.6|4.319|it's misleading these neural networks
1787.679|4.321|again it's better to think of them as a
1789.919|4.961|mathematical function with a lot of free
1792.0|4.96|parameters 60 million knobs that must be
1794.88|3.919|set to get the correct behavior
1796.96|3.76|and in the beginning the setting of
1798.799|3.681|these knobs is completely random
1800.72|3.28|so the neural net is implementing a
1802.48|2.88|completely random function it's doing
1804.0|3.36|completely random things and it's
1805.36|4.08|starting basically from scratch
1807.36|3.84|and so you have to tell it what to do in
1809.44|3.359|every situation and the more situations
1811.2|3.28|you have the more you're going to have
1812.799|3.521|to
1814.48|4.319|give it in order for it to do the right
1816.32|4.479|thing in all the cases
1818.799|3.6|so andre when the neural network starts
1820.799|3.441|from scratch
1822.399|4.64|and you put that neural network
1824.24|5.52|on a tesla what what would happen if it
1827.039|3.76|drives at tesla
1829.76|2.48|well
1830.799|4.041|you'll get random behavior when it's
1832.24|5.52|from scratch it'll be completely random
1834.84|4.199|behavior got it so it starts not knowing
1837.76|3.279|what to do
1839.039|3.921|so you probably don't put those on on
1841.039|4.64|the cars actually no
1842.96|2.719|you don't want to do that
1847.679|3.441|and so
1849.44|3.119|how when you deal with all this
1851.12|4.0|variability and you want this neural
1852.559|4.801|network to internalize that variability
1855.12|4.88|um
1857.36|3.6|can you say more about
1860.0|2.64|what
1860.96|3.12|i mean what what makes the neural
1862.64|3.519|network internalize that variability
1864.08|4.16|what's what's the solution to that it so
1866.159|3.52|it looks like um
1868.24|3.679|we do it through
1869.679|3.041|roughly almost brute force ways right
1871.919|2.401|now
1872.72|3.76|so if i want the neural network to
1874.32|5.599|function in millions of situations i
1876.48|4.799|need to plug in millions of
1879.919|3.681|examples
1881.279|4.161|and or something on that order so the
1883.6|4.48|neural networks do show some ability to
1885.44|3.92|sort of interpolate between the examples
1888.08|2.319|you've given them
1889.36|3.039|they are
1890.399|3.76|they're not as good at extrapolating
1892.399|3.76|but as long as you sort of cover the
1894.159|3.441|space of possibility and tell the neural
1896.159|3.52|network what to do in those different
1897.6|4.319|scenarios they have some ability to
1899.679|4.72|interpolate between examples
1901.919|4.161|but it's it's limited and so if you
1904.399|3.52|really have a massive amount of
1906.08|4.16|variability that you want the system to
1907.919|5.36|perform well on uh you actually have to
1910.24|4.72|cover that space uh to a large extent
1913.279|3.601|so how how do you how do you get the
1914.96|3.76|data to cover that space as i mentioned
1916.88|3.84|in this new programming paradigm there's
1918.72|4.16|a bit of designing the neural network
1920.72|4.72|and the neurons and so on but a massive
1922.88|4.639|amount of work is on curating uh these
1925.44|5.52|data sets
1927.519|6.961|and um fundamentally you you roughly
1930.96|4.8|start with a data set um
1934.48|2.88|you start with some data set and you
1935.76|3.279|train your neural network and then you
1937.36|3.12|measure its performance and you look at
1939.039|2.48|where it works and where it does not
1940.48|2.0|work
1941.519|2.481|and
1942.48|2.88|the fundamentally the way you're
1944.0|3.44|iterating on this neural network to get
1945.36|3.76|it to work is you need to find a lot of
1947.44|2.959|examples where it does not do what you
1949.12|3.039|want to do
1950.399|3.601|and then you need to get those
1952.159|3.201|situations and you need to label
1954.0|2.799|correctly what should have happened in
1955.36|3.36|those situations where the correct label
1956.799|3.6|would have been in all those cases
1958.72|3.679|and then you need to put those into the
1960.399|3.76|training set for the neural network
1962.399|4.16|and so the neural network is now trained
1964.159|4.24|on the previous data set but also on a
1966.559|3.441|data set of where it failed before but
1968.399|4.16|now has the correct label
1970.0|4.32|and this improves some situations again
1972.559|4.561|and then you have to again
1974.32|4.56|look at where it's failing now and the
1977.12|4.0|faster you can spin this loop of just
1978.88|4.96|iterating and curating your data set
1981.12|4.159|um the the better this neural network
1983.84|3.36|will become
1985.279|4.0|and luckily we are in a position with
1987.2|4.56|these deep neural networks that as long
1989.279|3.441|as the data set is
1991.76|2.32|um
1992.72|3.199|as long as the data says improving
1994.08|4.079|there's no real upper bound on the
1995.919|3.841|performance of the network um
1998.159|3.601|with if you have enough computation
1999.76|3.12|available for it and a large enough data
2001.76|3.279|set
2002.88|6.08|it will find the correct sort of
2005.039|5.681|solution to making your labels work
2008.96|2.8|so most of the engineering is on the
2010.72|3.52|data set
2011.76|4.639|and primarily it comes from sourcing
2014.24|3.84|examples where you're not working yet
2016.399|4.241|and sourcing examples where it's not
2018.08|4.64|working yet is is that when i drive my
2020.64|4.08|tesla is am i sourcing those examples
2022.72|3.12|and how does that work uh yeah exactly
2024.72|3.28|so
2025.84|3.439|um it's a great question a lot of what i
2028.0|3.279|do of course
2029.279|3.12|at work is just curating these data sets
2031.279|2.801|as i mentioned that's where all the
2032.399|3.12|engineering now is it's not people
2034.08|3.12|writing algorithms it's people
2035.519|3.52|collecting data sets
2037.2|3.28|and uh so you know for example there's
2039.039|4.081|lots of things we want to know about the
2040.48|4.48|scene right so we want to know where the
2043.12|3.439|lines are where the edges are where the
2044.96|4.08|traffic lights are where the other cars
2046.559|5.04|are whether or not the car door is open
2049.04|5.2|on the car if the left blinker is on a
2051.599|5.361|huge amount of things so roughly we have
2054.24|5.439|maybe say 30 top level tasks but a lot
2056.96|5.36|of those tasks have many sub tasks like
2059.679|4.321|for a car you may want to know a lot of
2062.32|3.599|attributes about it what kind of a
2064.0|4.56|vehicle is it
2065.919|3.841|you know is the car door open and so on
2068.56|2.559|so you end up with a huge amount of
2069.76|3.359|predictions that your neural network has
2071.119|3.441|to make about the world
2073.119|3.361|and um
2074.56|3.599|there are and now these networks are
2076.48|3.679|deployed in people's cars and they're
2078.159|4.801|running and making predictions and then
2080.159|3.92|we have to come up with lots of ways to
2082.96|2.56|source
2084.079|3.361|inaccuracies
2085.52|5.04|and there's many ways by which we do
2087.44|4.719|that um maybe one very simple example is
2090.56|3.44|if you intervene because the autopilot
2092.159|3.76|did not do something correct typically
2094.0|4.72|when you intervene in a large number of
2095.919|4.401|cases that has to do with an incorrect
2098.72|4.8|prediction from the network
2100.32|5.2|so an intervention is a trigger and we
2103.52|3.68|collect some of those images
2105.52|2.88|and then we look at them and we look at
2107.2|3.2|whether or not the predictions were
2108.4|4.16|correct and how are they wrong and that
2110.4|4.719|helps us triage should this example go
2112.56|4.64|into what labeling project and where
2115.119|3.361|should it end up in in what data set and
2117.2|2.8|with what label
2118.48|2.48|and that's how we sort of iterate on the
2120.0|3.28|system
2120.96|4.8|but there's many triggers that are
2123.28|4.079|active at any point in time as one more
2125.76|3.76|example
2127.359|3.681|if you have a detection of say a stop
2129.52|3.599|sign or something like that
2131.04|3.68|if the so you have a bounding box that
2133.119|2.48|the computer is putting around the stop
2134.72|3.119|sign
2135.599|4.24|and if the stop sign detection uh
2137.839|3.201|flickers for example so it's there and
2139.839|3.201|then the network says oh it's not a stop
2141.04|3.76|time oh wait it is stop sign when you
2143.04|4.0|see this disagreement with itself over
2144.8|4.24|time that also is typically an extremely
2147.04|4.0|good source of data
2149.04|3.12|so flicker and temporally consistent
2151.04|2.72|predictions
2152.16|3.679|or for example disagreements with the
2153.76|4.319|map so we think there's a stop sign but
2155.839|3.841|the map says that there isn't one so
2158.079|3.921|there's lots of different ways by which
2159.68|4.159|we gather examples where the network is
2162.0|3.92|mispredicting and
2163.839|4.0|for us it's an exercise of how quickly
2165.92|4.08|can you enter those examples into a
2167.839|4.721|training set and that's
2170.0|4.32|a huge portion of what the team is doing
2172.56|4.08|when i try to think about the data
2174.32|3.92|you're feeding into the system
2176.64|3.92|how much data is that i mean are we
2178.24|4.16|thinking thousands of images millions
2180.56|3.36|what magnitude are we talking about here
2182.4|3.52|yep so we're talking about millions of
2183.92|4.32|images easily
2185.92|4.64|it's on that order so millions of images
2188.24|3.76|that are annotated with all kinds of
2190.56|3.6|information the neural network should
2192.0|4.88|extract yes automatically in the future
2194.16|6.64|from similar images yep
2196.88|4.8|that's amazing now
2200.8|2.319|one of the
2201.68|4.64|recurring themes it seems in deep
2203.119|6.48|learning is um large data but also
2206.32|3.279|um large compute
2209.76|4.0|let's say you want to train the
2211.52|4.24|autopilot from all that data
2213.76|3.12|you say okay i'm going to retrain it
2215.76|2.64|push all the data through the new
2216.88|3.04|network and train it
2218.4|3.76|how much compute does it take how long
2219.92|4.0|does it take to train an autopilot
2222.16|3.679|yeah so what you're getting what you're
2223.92|3.919|getting at is these neural networks are
2225.839|3.841|quite expensive to train so we start
2227.839|3.441|with millions of images and a typical
2229.68|2.8|neural network
2231.28|2.24|if you want to
2232.48|3.359|typically what you will see in the
2233.52|4.24|industry is most networks train roughly
2235.839|3.76|on the order of two to three weeks of
2237.76|3.28|time
2239.599|3.441|because two to three weeks is actually
2241.04|3.44|more of a psychological
2243.04|2.799|reason for that is because that's the
2244.48|2.4|amount of time that a person is willing
2245.839|1.76|to wait
2246.88|2.239|for
2247.599|3.281|for the network to converge and to
2249.119|2.801|measure its performance
2250.88|2.88|um
2251.92|3.28|so
2253.76|2.56|but yeah they have to look at a lot of
2255.2|2.32|examples they have to make a lot of
2256.32|2.48|predictions and they have to be
2257.52|3.28|corrected on the predictions they're
2258.8|4.24|making during the training loop and this
2260.8|3.76|takes a long time
2263.04|3.2|and
2264.56|4.0|as you are scaling up the amount of
2266.24|5.76|compute available
2268.56|5.44|you can afford to um to use a bigger
2272.0|3.599|network and a bigger network will almost
2274.0|4.079|always work better
2275.599|3.921|uh but it needs more training time
2278.079|3.121|and so
2279.52|3.28|we're in a place where we are and this
2281.2|3.68|is a beautiful place to be by the way we
2282.8|4.16|are not constrained by human ingenuity
2284.88|3.6|and algorithms as used to be the case in
2286.96|3.92|computer vision because we had a class
2288.48|4.72|of approaches that leveled off and then
2290.88|4.64|we were the constraint but now
2293.2|4.24|we human ingenuity is not a constraint
2295.52|3.52|the constraint is the size of the data
2297.44|3.84|set and the amount of compute that you
2299.04|4.0|have available to you the algorithm now
2301.28|3.36|is known everyone knows the same
2303.04|4.24|algorithms and we just need to run them
2304.64|4.719|at scale and we're getting benefits for
2307.28|3.839|free just by scaling up the network
2309.359|3.601|making a bigger network and making a
2311.119|3.441|bigger data set so it's a beautiful
2312.96|3.44|place to be because you have a recipe a
2314.56|4.16|template by which you can make progress
2316.4|3.36|and you're just bounded by
2318.72|3.359|um
2319.76|4.16|very concrete tangible things that you
2322.079|3.681|can improve like the size of your
2323.92|3.28|training cluster and things like that
2325.76|3.12|where here said that the algorithms
2327.2|3.2|understood
2328.88|2.88|that that's true of course it still
2330.4|3.76|requires
2331.76|3.68|some true expertise in the space to to
2334.16|3.12|understand those algorithms but you're
2335.44|5.2|right they're not secret
2337.28|4.88|i i hear part of what you're saying
2340.64|3.76|it seems like
2342.16|4.88|you are spending a lot of your time on
2344.4|5.04|the data itself and a lot less on
2347.04|4.16|changing the algorithms
2349.44|3.76|what does that look like
2351.2|4.159|i mean i imagine you have a large team
2353.2|3.36|that helps with the data and so forth
2355.359|3.201|like what does that look like
2356.56|4.559|organizationally yeah and i think like
2358.56|4.4|to your point briefly um it's a good
2361.119|3.201|observation that the algorithms it's not
2362.96|2.48|fair to say that they're fully figured
2364.32|3.279|out and known
2365.44|3.6|it's i would say it's more true in some
2367.599|3.361|domains than others like in computer
2369.04|3.28|vision i think we we have a class of
2370.96|2.879|algorithms that we're pretty happy with
2372.32|3.519|for the simplest image recognition
2373.839|3.841|problems in many cases for example
2375.839|2.961|you're dealing with robots doing pick
2377.68|3.679|and plays and things like that i would
2378.8|5.68|say algorithms are absolutely much less
2381.359|5.361|known um and so different domains will
2384.48|4.48|will have will have different maturity
2386.72|3.44|of the technology available
2388.96|2.48|um
2390.16|3.04|and i also
2391.44|3.36|want to say that it's not the case that
2393.2|3.44|we spend zero time on algorithms it's
2394.8|4.64|more like we spend 25 percent of the
2396.64|5.04|time not 100 of the time and the only
2399.44|3.84|reason i typically point it out and
2401.68|3.04|stress that
2403.28|3.6|is because
2404.72|5.04|uh typically people coming from say
2406.88|4.16|academia have an expectation
2409.76|3.12|so in academia when you're working with
2411.04|3.12|neural networks typically your data set
2412.88|2.56|is fixed because we have certain
2414.16|2.32|benchmarks that we're interested in
2415.44|2.8|driving up
2416.48|3.76|so your data set is fixed like say the
2418.24|4.48|imagenet and your task is to iterate on
2420.24|5.359|the algorithm uh and then neural network
2422.72|5.68|design and layout to improve the numbers
2425.599|4.401|um and so everyone's 100 of the time on
2428.4|3.36|the neural network itself the structure
2430.0|2.48|the loss function and all the pieces of
2431.76|2.24|that
2432.48|4.08|and data says fixed
2434.0|4.56|and my reaction is to it is strong only
2436.56|3.84|because when you're in the industry you
2438.56|3.6|will iterate a lot on the data set as
2440.4|3.84|well so that's not to say that the
2442.16|5.199|algorithm design and modeling um is not
2444.24|5.44|there it's just uh it's the second order
2447.359|3.361|effect of what you would be doing
2449.68|2.56|um
2450.72|2.72|it's sort of the second term in the
2452.24|2.16|equation
2453.44|3.76|um
2454.4|5.28|and as i said it also varies per area so
2457.2|4.56|i would say um in robotics it's much
2459.68|4.48|less certain how to lay out the problem
2461.76|5.04|um how you structure it how you arrange
2464.16|4.24|it what is the data set how do you um
2466.8|3.68|what what labels are you collecting at
2468.4|4.4|what level of abstraction huge huge
2470.48|4.56|design space and not obvious what works
2472.8|4.48|yet uh but i would say that's less the
2475.04|4.72|case in just simple image recognition
2477.28|4.96|well i i like i like that you expanded
2479.76|4.559|them up on that
2482.24|3.2|the thing i'm actually curious about
2484.319|3.921|is
2485.44|6.8|how this relates to this term you coined
2488.24|6.8|a little while ago software 2.0
2492.24|4.8|because it seems very related yeah
2495.04|5.279|yeah exactly so um
2497.04|6.64|software 2.0 was uh kind of like a blog
2500.319|5.601|post i published um a few years ago
2503.68|3.84|and it was just making the point that
2505.92|3.6|you know of course we have a lot of uh
2507.52|4.96|software that's driving large parts of
2509.52|5.28|society and automation in um
2512.48|3.76|in a space of information and so on
2514.8|3.2|and um
2516.24|4.4|a lot of the software right now is
2518.0|5.44|written by people uh so you know banking
2520.64|4.479|systems and
2523.44|3.76|you know internet search and things like
2525.119|3.361|that everything is sort of algorithms
2527.2|3.52|developed by people
2528.48|4.56|in principle understood and uh
2530.72|3.22|orchestrated in a certain way
2533.04|2.4|and
2533.94|3.659|[Music]
2535.44|5.44|it seems to me basically that with
2537.599|5.121|progress and deep learning um
2540.88|5.04|it you can sort of think of that neural
2542.72|5.04|network as a piece of software um
2545.92|2.72|but the software was not written by
2547.76|3.2|person
2548.64|3.84|this per the software was written by an
2550.96|2.72|optimization
2552.48|2.639|and so
2553.68|3.2|it's kind of like a new programming
2555.119|3.2|paradigm that we are not directly
2556.88|4.719|writing the algorithm
2558.319|5.441|we are programming the data sets and the
2561.599|4.0|algorithm really is an outcome
2563.76|3.359|of this training process or this
2565.599|2.48|compilation
2567.119|2.081|um
2568.079|2.641|as
2569.2|3.84|which would be sort of the equivalent in
2570.72|3.92|typical software so you would take your
2573.04|2.88|source code and you would compile it and
2574.64|2.88|get a binary
2575.92|3.84|so here the source code are the data
2577.52|4.4|sets the compilation is the training of
2579.76|4.72|the neural org and your binary is the
2581.92|4.72|final neural net the weights
2584.48|5.04|and to me what's happening in society
2586.64|4.479|right now is that we are well number one
2589.52|3.68|a lot of software that we couldn't have
2591.119|4.881|written before is now possible to write
2593.2|4.56|like image recognition systems but also
2596.0|3.68|a lot of system that a lot of software
2597.76|4.72|that used to be written in by
2599.68|4.8|instruction software 1.0 style
2602.48|6.56|can now be ported over to this more
2604.48|6.0|powerful paradigm uh to software 3.0
2609.04|3.2|and the programming sort of looks
2610.48|3.44|different and the reason i wrote that
2612.24|3.359|post is that it's a little bit of a call
2613.92|3.76|to arms to
2615.599|3.841|all the engineers in that
2617.68|4.0|over the la we've been programming in
2619.44|4.159|the software 1.0 paradigm for four or
2621.68|3.6|five decades and we have a huge amount
2623.599|4.561|of infrastructure to help us program in
2625.28|4.96|this paradigm so we have ides that help
2628.16|4.08|you write code they point out bugs they
2630.24|3.2|do syntax highlighting there's a huge
2632.24|3.52|amount of software infrastructure we've
2633.44|4.08|built to help us program but this is not
2635.76|4.0|yet the case in this new programming
2637.52|4.48|paradigm so we have to develop
2639.76|4.559|completely new tools around data set
2642.0|3.839|curation monitoring the deployment of
2644.319|3.121|these neural networks the iteration the
2645.839|3.121|fine tuning
2647.44|3.36|everything that goes into programming
2648.96|3.68|this new paradigm is an uncharted
2650.8|3.68|territory and
2652.64|4.32|the tools that we have to iterate on
2654.48|4.56|these data sets are extremely primordial
2656.96|4.879|and i think can be improved a lot
2659.04|5.039|and so really the post was about
2661.839|4.321|pointing out that this is not just some
2664.079|3.841|kind of a classifier in machine learning
2666.16|3.12|this is actually a restructuring of how
2667.92|2.8|we write software
2669.28|2.88|and people have to take it seriously and
2670.72|3.44|we have to borrow a lot of what we've
2672.16|3.919|done with software 1.0 infrastructure
2674.16|3.679|and that helped us program and we have
2676.079|3.441|to port equivalents
2677.839|3.52|into working with neural nets because a
2679.52|4.0|lot of software will start to look like
2681.359|4.401|weights in the neural net it won't be
2683.52|4.079|cpos plus or python or whatnot and what
2685.76|3.599|do you say at this point when you talk
2687.599|3.921|about this neural nets effectively being
2689.359|4.641|the program
2691.52|4.16|to build a self-driving car is it just a
2694.0|3.52|neural net that's been trained with a
2695.68|4.8|lot of data or are there still other
2697.52|4.88|components yeah
2700.48|5.2|yeah that's a really good question so
2702.4|4.08|in the car uh there is there are both
2705.68|3.04|so
2706.48|3.599|images enter in the beginning right and
2708.72|2.639|we have pixels of an image telling us
2710.079|2.401|fundamentally what's out there in the
2711.359|3.281|world
2712.48|3.839|and then uh neural networks are doing
2714.64|3.199|some portion of the recognition so
2716.319|3.441|they're telling you hey there's a stop
2717.839|3.841|sign person etc
2719.76|4.24|but you can't just directly drive on
2721.68|4.159|person stop sign etc you have to
2724.0|5.119|actually write some logic around how do
2725.839|5.76|you take those intermediate uh sort of
2729.119|4.24|representations and predictions and you
2731.599|3.601|want to avoid the pedestrian and you
2733.359|4.081|want to stop at the stop sign and so
2735.2|4.56|there's still a lot of software 1.0 code
2737.44|4.48|sitting on top of the neural net
2739.76|4.4|and that code is basically reacting to
2741.92|3.679|the predictions so that it speeds up
2744.16|3.439|slows down turns the wheel to stay in
2745.599|4.321|the lane line markings and so on
2747.599|5.201|what i have seen in the history of the
2749.92|3.919|team since i've joined in four years ago
2752.8|1.92|is that
2753.839|2.881|um
2754.72|3.04|and this is also why i think is that
2756.72|2.24|really
2757.76|4.0|we've been porting a lot of the
2758.96|4.96|functionality from the software 1.0 land
2761.76|4.079|into the neural network and so
2763.92|3.76|originally the neural networks would
2765.839|4.081|only make predictions for example for a
2767.68|3.679|single image and they would tell you
2769.92|3.28|okay there's a there's a piece of a road
2771.359|4.881|edge but we actually don't just have a
2773.2|4.639|single image we have eight images right
2776.24|4.4|uh coming from eight different cameras
2777.839|4.881|that are surround in the vehicle
2780.64|4.0|so every image independently predicts
2782.72|3.68|little pieces of road edges and curves
2784.64|3.439|but there needs to be something above it
2786.4|3.6|that stitches it up into a
2788.079|3.28|three-dimensional sort of
2790.0|2.72|bird's-eye view of what's happening
2791.359|3.601|around the vehicle
2792.72|4.32|and that was all done in software
2794.96|4.159|developed by people so you take road
2797.04|3.52|edges from here you project them out go
2799.119|3.601|digest from all the cameras project them
2800.56|4.4|out stitch them up across boundaries and
2802.72|4.96|then over time you need to also stitch
2804.96|4.399|them up and track them and make it serve
2807.68|4.399|temporally continuous
2809.359|5.201|and all that was written by people
2812.079|4.721|and what we've done since then is is the
2814.56|4.16|neural network has engulfed a lot of the
2816.8|3.84|pieces of the engineering so the neural
2818.72|4.879|networks that are in the car today
2820.64|3.92|will not make a prediction per image
2823.599|2.321|um
2824.56|2.64|they will make prediction directly in
2825.92|3.28|the bird's eye view
2827.2|4.32|so they will say okay
2829.2|4.08|i've seen these eight images and from
2831.52|3.44|that i can see that the road edges are
2833.28|4.24|this way around the car
2834.96|4.48|and also i've seen the images over time
2837.52|3.52|and i've done the tracking and having
2839.44|3.52|accumulated information from all those
2841.04|3.519|frames here's actually what the world
2842.96|2.56|looks like around you
2844.559|3.601|and so
2845.52|4.64|pieces of the software 1.0 code are
2848.16|3.199|being engulfed by the neural net and
2850.16|3.919|it's taking on more and more
2851.359|4.881|responsibility in the stack
2854.079|4.321|and maybe at the end of the day this can
2856.24|3.44|all just be a neural net so maybe
2858.4|2.32|there's a very little room for
2859.68|3.12|engineering
2860.72|3.92|maybe the images just come in and what
2862.8|3.2|comes out is just what you really want
2864.64|2.719|which is the steering and the
2866.0|3.359|acceleration
2867.359|2.881|easily said
2869.359|2.161|hard
2870.24|2.96|hard to do
2871.52|3.44|but that is the final
2873.2|3.919|conclusion i would say of of this kind
2874.96|4.159|of a transition and there's very little
2877.119|4.881|software written by people it's just a
2879.119|4.24|neural net does the whole thing um
2882.0|4.72|yeah
2883.359|5.121|that's the holy grail i would say
2886.72|5.04|we are dropping new interviews every
2888.48|5.119|week so subscribe to the robot brains on
2891.76|3.839|whichever platform you listen to your
2893.599|3.921|podcasts
2895.599|3.121|now
2897.52|3.68|when
2898.72|5.44|when people think about neural nets
2901.2|5.52|often part of the reaction is um at
2904.16|4.399|least in in the early days was
2906.72|3.2|it's hard to understand what they do and
2908.559|2.721|and here you are
2909.92|3.12|putting a neural net as part of the
2911.28|4.079|decision-making system for driving
2913.04|4.72|people which is of course i mean
2915.359|5.041|a very uh risky thing if
2917.76|4.799|the autopilot makes mistakes right so
2920.4|5.12|how do you build confidence
2922.559|5.441|in the system and how i imagine you have
2925.52|4.319|early rollouts sometimes in your own how
2928.0|3.92|do you decide you're willing to try it
2929.839|4.081|out you know so maybe maybe directly
2931.92|2.96|engineered code is in is in charge of a
2933.92|2.32|lot of the
2934.88|2.479|um
2936.24|2.72|the stack
2937.359|3.681|but i think it gives a full sense of
2938.96|3.68|understanding of the entire system
2941.04|3.44|because ultimately this can be hundreds
2942.64|3.439|of thousands of lines of code so yes you
2944.48|4.079|can analyze individual functions but
2946.079|4.0|this is a very complex dynamical system
2948.559|3.04|and i think you may have a false
2950.079|3.52|impression that you actually
2951.599|3.441|understand the system um even though you
2953.599|3.76|understand like the individual
2955.04|4.72|components i would say really what it
2957.359|3.921|comes down to is you want a very robust
2959.76|3.76|process for
2961.28|4.64|really testing the hole and subjecting
2963.52|4.319|it to a huge amount of evaluation maybe
2965.92|3.52|both in for all the individual
2967.839|3.361|components making sure that okay the
2969.44|3.44|detection itself works and all the
2971.2|3.919|pieces of the neural network
2972.88|3.76|individually by themselves but then also
2975.119|2.801|end-to-end integration tests and you
2976.64|3.28|just want to
2977.92|3.679|to test the system and you want to do
2979.92|2.56|this whether or not a neural net is in
2981.599|2.48|charge
2982.48|3.04|and you want to subject it to say a huge
2984.079|4.641|amount of simulation to make sure it's
2985.52|5.839|working as as um expected and also of
2988.72|4.24|course through driving and so we have a
2991.359|5.601|large qa
2992.96|5.68|team that drives the car and uh you know
2996.96|3.119|verifies that everything is working you
2998.64|3.36|know as well as possible
3000.079|4.24|um and so we have a number of mechanisms
3002.0|4.4|by which we test these systems
3004.319|4.321|another one that's big for us is
3006.4|4.64|shadow mode releases so you can deploy
3008.64|5.199|the functionality but it's not wired up
3011.04|4.64|to control it's just making predictions
3013.839|3.841|but it's not actually like acting it's
3015.68|3.439|there just uh
3017.68|3.919|silently observing and making
3019.119|4.881|predictions and then we sort of test it
3021.599|3.921|out without it actually driving the car
3024.0|2.48|and so in some cases you can also do
3025.52|3.68|that
3026.48|4.24|um so to me this is just
3029.2|2.8|basically the idea that we understood
3030.72|3.839|the previous
3032.0|4.4|software is is false and fundamentally
3034.559|3.841|you just need extremely good evaluation
3036.4|3.679|now in those evaluations i'm curious as
3038.4|2.959|ever any of the testers or you
3040.079|3.201|experienced something they're really
3041.359|4.24|surprised by and like wow this car is
3043.28|3.92|smarter than i thought um
3045.599|3.361|i mean basically every time it drives me
3047.2|4.159|around in the latest uh wholesale
3048.96|4.56|driving beta builds um
3051.359|3.841|and just the emergent sometimes you know
3053.52|5.039|just the emergent properties of how it
3055.2|5.28|handles uh different uh situations like
3058.559|3.921|there's a bicyclist an oncoming vehicle
3060.48|3.68|and if you program it properly and then
3062.48|2.879|your work works very well you'll get
3064.16|3.439|these emerging behaviors where it does
3065.359|4.72|the right thing and uh so i would say
3067.599|3.76|like every drive i have maybe a few of
3070.079|3.681|those um
3071.359|4.24|wow yeah
3073.76|3.359|yeah that must be a real thrill i gotta
3075.599|3.041|imagine you still hold your hand to the
3077.119|4.0|steering wheel on your foot on the brake
3078.64|5.199|pedal just just in case oh absolutely
3081.119|5.2|yeah so the current system is the full
3083.839|3.841|self-driving beta build um that i drive
3086.319|3.52|around every day
3087.68|3.28|and it's actually quite capable i think
3089.839|3.28|people sort of understand that the
3090.96|3.76|autopilot is um
3093.119|3.521|you know works quite well on the highway
3094.72|3.52|and a lot of people use it
3096.64|3.28|and it can keep a lane on the highway
3098.24|3.68|but the latest builds that we have in
3099.92|3.679|the full soil driving package are quite
3101.92|3.199|competent even off highway in city
3103.599|3.281|streets so
3105.119|3.761|i was driven to get a coffee this
3106.88|3.92|morning and back to my house
3108.88|4.88|a 20-minute drive or in palo alto and it
3110.8|5.039|was zero intervention drive and so
3113.76|4.079|uh and this is a relatively routine for
3115.839|4.161|us so it's not a perfect system but it's
3117.839|3.921|really getting there and i definitely
3120.0|4.72|keep my hands on the wheel because
3121.76|4.48|there's still yeah you know we will
3124.72|3.119|still do um
3126.24|3.119|not very clever things once in a while
3127.839|2.561|and so there's definitely more work to
3129.359|2.321|be done
3130.4|3.439|now of course whenever it makes a
3131.68|4.159|mistake in some sense that's that's high
3133.839|4.0|value assuming the person takes over
3135.839|4.24|correctly of course because that gives
3137.839|4.081|you the most valuable data the missing
3140.079|3.76|pieces of the puzzle yeah that's right
3141.92|4.24|so interventions are are very helpful
3143.839|3.841|source of data for us um
3146.16|4.8|and you know as i mentioned there's a
3147.68|5.919|lot of other ways that we can also get
3150.96|5.2|get um data that where the network is
3153.599|4.561|misbehaving a lot of disagreements for
3156.16|3.199|example with the human driver like we
3158.16|3.28|think there's a stop sign we should be
3159.359|4.401|stopping but the person just went
3161.44|4.159|uh we can look at a lot of that data and
3163.76|4.079|maybe half of the time it's people just
3165.599|4.161|running a stop sign we see a lot of that
3167.839|3.201|half of the time it's hey there was a
3169.76|2.72|stop sign but actually it was not for
3171.04|2.96|you it was worth for the oncoming
3172.48|3.28|traffic and the stop sign was just
3174.0|3.599|angled way too much and it looked
3175.76|2.799|deceiving to the neural network
3177.599|2.72|and so
3178.559|2.8|both would be coming back in this stream
3180.319|3.121|of data
3181.359|3.2|now
3183.44|2.56|another
3184.559|3.201|thing that um
3186.0|4.0|i've heard you talk about and that just
3187.76|4.64|sounds really intriguing ties into all
3190.0|6.559|of this is this
3192.4|4.159|thing called operation vacation
3197.28|5.839|sounds very intriguing who doesn't want
3198.88|6.32|a vacation um what is operation vacation
3203.119|4.0|yeah so um
3205.2|3.6|in the process of iterating on all these
3207.119|4.081|predictions in the team
3208.8|4.799|we are noticing that more and more of
3211.2|4.8|its components can be automated
3213.599|4.321|so as i describe the process
3216.0|3.599|you need to um
3217.92|3.679|your neural network makes predictions
3219.599|3.361|you need to source at scale
3221.599|2.801|mispredictions
3222.96|2.639|annotate them correctly and put them
3224.4|3.12|into training set and retrain the
3225.599|3.601|network that's the loop
3227.52|4.16|and we're noticing that you can involve
3229.2|4.0|engineers less and less in
3231.68|2.56|that loop
3233.2|3.52|and
3234.24|4.319|through a lot of automation now
3236.72|3.52|it's not all the engineers that get to
3238.559|3.201|eventually go on a vacation once we've
3240.24|3.52|automated the whole thing
3241.76|4.16|uh because there's a huge amount of um
3243.76|2.96|there's a large data labeling team
3245.92|2.72|who
3246.72|3.68|who has to stick around
3248.64|2.8|monitor your triggers and annotate the
3250.4|2.64|data
3251.44|2.879|but the actual software engineers who
3253.04|2.0|write code
3254.319|2.8|could
3255.04|3.519|in principle go on vacation uh having
3257.119|3.601|automated all the pieces of this
3258.559|4.161|improvement loop
3260.72|2.72|so i would say it's kind of like a
3262.72|3.76|half
3263.44|5.119|north star for the team where once these
3266.48|3.68|neural networks are just getting better
3268.559|4.481|by themselves with a lot of people in
3270.16|5.04|between but just data labelers mostly
3273.04|3.68|um we get to all go on a vacation and
3275.2|3.919|the autopilot could in principle just
3276.72|4.8|improve automatically are you worried
3279.119|6.0|though that that you all might let you
3281.52|3.599|be on vacation for the rest of your life
3286.24|4.879|we may be able to get away with a few
3287.92|3.199|days we'll see i'm not sure
3291.599|4.081|it's it's so interesting because it
3293.839|3.681|it also reminds me of when when you were
3295.68|3.2|actually visiting cover and you said
3297.52|4.079|something along the lines of the data
3298.88|5.12|annotation is what you spend all your
3301.599|3.281|time on and the data annotation playbook
3304.0|4.4|is
3304.88|5.679|is so valuable is is the thing that that
3308.4|3.52|generates so much value right which is
3310.559|3.601|something that somebody in academia of
3311.92|2.96|course would never even uh pay attention
3314.16|3.36|to
3314.88|4.4|um but operation vacation sounds
3317.52|3.839|exactly like that that the people who
3319.28|4.24|are still working are the ones who are
3321.359|4.881|working with the data and everybody else
3323.52|4.559|is is just on the beach i guess
3326.24|3.599|yes
3328.079|3.76|i mean it is it is it is done half
3329.839|3.681|jokingly actually as i describe the
3331.839|3.201|system there's plenty of design and
3333.52|3.36|engineering that can still go into the
3335.04|3.2|fundamentals like as an example the
3336.88|2.959|system right now makes all these
3338.24|3.2|intermediate predictions and there's
3339.839|4.0|still a lot of human driven human
3341.44|4.32|written code on top of it and this human
3343.839|3.361|written code is very difficult to write
3345.76|2.96|and it's brittle and it will not
3347.2|2.8|fundamentally i think scale to where we
3348.72|4.0|need it to be
3350.0|3.839|if you really want 99.99 of accuracy and
3352.72|2.56|comfort
3353.839|3.921|and um
3355.28|4.0|so i think there's a lot of
3357.76|3.76|there's some challenges that sort of
3359.28|4.079|remain i would say on the modeling front
3361.52|3.039|and so we'll be busy with those but the
3363.359|3.76|fundamental if you're just talking about
3364.559|5.04|the perception system itself i think its
3367.119|4.641|improvement can be just and just
3369.599|3.76|improved autonomously just on the road
3371.76|2.64|detection itself
3373.359|2.401|and
3374.4|2.719|but yeah as you mentioned data
3375.76|3.359|annotation is not something you would do
3377.119|3.761|as a deep learning engineer we spend a
3379.119|3.601|lot of time on it i actually have an
3380.88|3.84|entire data labeling org
3382.72|4.24|that we've grown inside tesla because
3384.72|4.399|this is so fundamental to what we do a
3386.96|4.56|typical approach would be that you
3389.119|4.96|outsource it to third parties we don't
3391.52|3.839|do that we have a highly professional
3394.079|4.72|highly trained
3395.359|4.96|workforce that curates our data sets and
3398.799|2.32|we think that this is the right way to
3400.319|2.48|go
3401.119|3.521|because this is just a new software
3402.799|4.961|programming paradigm again these are our
3404.64|4.719|new programmers in the software 2.0 land
3407.76|3.359|and so they have to
3409.359|3.281|when they're annotating examples they're
3411.119|3.041|telling the system how to interpret the
3412.64|3.12|scene and they are quite literally
3414.16|4.08|programming the autopilot
3415.76|4.24|so we invest quite a bit into the org
3418.24|3.04|and we keep it close and they
3420.0|2.319|collaborate with the engineers very
3421.28|2.96|closely
3422.319|5.121|that's amazing now when when i think
3424.24|4.48|about data annotation i can also
3427.44|3.119|i mean immediately the other thing i'm
3428.72|3.119|thinking about is self-supervised
3430.559|3.601|learning which has made a lot of
3431.839|3.52|progress in ai in the last two three
3434.16|3.04|years
3435.359|3.44|both in computer vision and in natural
3437.2|5.2|language processing but probably here
3438.799|5.121|the vision part is more important and so
3442.4|3.439|i'm curious about your thoughts on the
3443.92|4.08|role of self-supervised learning maybe
3445.839|3.361|you can first define uh for our
3448.0|4.72|listeners what is self-supervised
3449.2|5.359|learning and then and say a bit about cs
3452.72|4.399|yeah so here's the here's the issue with
3454.559|4.721|the current technology basically is
3457.119|4.081|i can get almost any arbitrary deduction
3459.28|3.2|to work at this point and this is just
3461.2|3.2|technology
3462.48|3.839|but i need tens of thousands of examples
3464.4|3.439|for it so if i need to recognize fire
3466.319|3.841|hydrants
3467.839|4.161|absolutely doable i need 10 000 examples
3470.16|3.919|50 000 examples and i need to do a bit
3472.0|3.92|of data engine to pad out to the data
3474.079|3.361|set and i know this will work with a
3475.92|2.8|with the neural network this is just
3477.44|3.119|technology
3478.72|4.16|but there's a lot of things you want to
3480.559|3.76|recognize and it feels silly to have to
3482.88|3.76|redo this work
3484.319|4.321|of like hey 50 000 times this is a fire
3486.64|2.959|hydrant from all the possible rotations
3488.64|2.159|and all the possible brightness
3489.599|3.041|conditions
3490.799|2.641|it just seems so silly
3492.64|2.32|um
3493.44|3.119|and so this is
3494.96|3.76|you know this is where the analogy again
3496.559|3.361|what the human brain breaks
3498.72|2.879|in that
3499.92|3.84|for a person you show them a fire
3501.599|4.24|hydrant and they sort of get it it's the
3503.76|3.599|yellow things on the side of the road
3505.839|2.321|that's not how our current technology
3507.359|3.681|works
3508.16|4.159|it it needs a really good coverage of
3511.04|3.519|fire hydrants
3512.319|4.401|and so that's why a lot of people are
3514.559|3.361|perceiving basically this um
3516.72|2.56|there's almost like flaw with the
3517.92|2.879|technology right now and they're trying
3519.28|3.44|to come up with ways
3520.799|3.121|that will not require that huge amount
3522.72|3.839|of annotation
3523.92|4.08|um so maybe with very few examples the
3526.559|3.04|the neural network just like a human
3528.0|3.359|network should already sort of like know
3529.599|3.121|about fire hydrants and you're just
3531.359|3.76|telling it hey that yellow thing on the
3532.72|4.16|side of the road is is um
3535.119|3.361|you know you don't need 50 000 examples
3536.88|3.12|you need very very few because the
3538.48|3.28|network already sort of understood fire
3540.0|3.28|hydrants and now it's just getting a
3541.76|3.039|label for the thing it already has a
3543.28|4.64|neuron for and so it's much more
3544.799|4.721|efficient at the use of that dataset
3547.92|3.12|so
3549.52|3.44|so andre when you say the network
3551.04|4.48|already kind of understood fire hydrants
3552.96|4.0|we was never told what what they are but
3555.52|2.96|where does that sort of understood it
3556.96|3.28|already come from
3558.48|4.16|exactly so that's where self-supervised
3560.24|4.24|learning is about is
3562.64|4.4|how do you train
3564.48|4.24|on a large collection of examples
3567.04|4.319|that did not have to go through human
3568.72|3.68|annotation effort we so maybe people
3571.359|2.641|didn't go in and they didn't put
3572.4|3.12|bounding boxes around fire hydrants
3574.0|3.599|maybe it's just a huge amount of data
3575.52|3.12|and fire hundreds are featured in some
3577.599|3.361|of it
3578.64|4.959|and uh maybe there are other objectives
3580.96|5.44|than explicit matching of human
3583.599|3.52|annotation that we can use
3586.4|4.56|to
3587.119|5.761|to pre-train these networks so that um
3590.96|3.119|they develop these representations so
3592.88|4.959|there's many ways that people are trying
3594.079|6.081|to arrange it as one example of many um
3597.839|3.681|that seems to work relatively well is
3600.16|2.24|for example you could try to predict the
3601.52|4.0|future
3602.4|5.919|um and so it's not that we don't use
3605.52|4.96|labeled data it's that we are using data
3608.319|4.081|that is annotated for free
3610.48|3.839|because when you have a video of what
3612.4|3.84|happened in the world you serve half the
3614.319|2.8|future and came for free in the data
3616.24|2.319|stream
3617.119|3.2|so you're still training the network to
3618.559|4.081|predict a thing
3620.319|3.841|uh just like normal supervised learning
3622.64|3.439|but you happen to
3624.16|2.8|have that thing for free without human
3626.079|2.321|effort
3626.96|3.599|and so self-supervised learning is a
3628.4|5.28|class of approaches that try to leverage
3630.559|5.04|the structure of the data in and try to
3633.68|4.48|take advantage of the free supervision
3635.599|5.041|that we have just in raw data streams
3638.16|4.639|instead of uh to to sort of
3640.64|4.24|uh get the networks to to arrange
3642.799|4.401|themselves into configurations that they
3644.88|5.12|kind of understand the world um so that
3647.2|4.48|it's much more efficient per label to
3650.0|3.359|train anything else
3651.68|2.879|fire hydrants might not be
3653.359|3.361|like
3654.559|4.081|the best example but uh yeah as an
3656.72|4.079|example to predict the future uh if you
3658.64|3.679|want you have to actually understand the
3660.799|4.56|layout of the entire scene and how
3662.319|4.561|people and cars move and interact and so
3665.359|3.281|uh this prediction problem forces the
3666.88|3.28|neural network to understand that hey
3668.64|4.0|there are cars they move around there
3670.16|4.159|are people they move around they avoid
3672.64|3.36|these areas and so when i need to
3674.319|4.721|predict the future i need to actually
3676.0|4.079|parse the scene to do that properly
3679.04|2.48|and so
3680.079|3.52|yeah there is a class of approaches and
3681.52|4.16|we have tried a number of them
3683.599|3.361|i do find that
3685.68|3.6|in these incredibly valuable
3686.96|5.119|applications uh just paying for the
3689.28|4.48|labels is often the right way to go
3692.079|4.24|instead of paying
3693.76|4.64|researchers
3696.319|3.76|and uh
3698.4|3.6|but i think i basically kind of agree
3700.079|4.161|with that um
3702.0|2.24|um
3704.64|4.8|yeah this is it's not ideal and uh there
3707.359|3.281|are some uh techniques that as you
3709.44|2.8|mentioned are seeing quite a lot of
3710.64|5.04|traction and we have experimented with a
3712.24|3.44|number of them internally at tesla
3715.92|4.159|that's really exciting because i mean
3718.24|3.839|the way i also see is that once you go
3720.079|3.76|self-supervised
3722.079|5.361|you you can use infinite data
3723.839|5.2|effectively because all data works right
3727.44|4.24|you have to be careful though because
3729.039|4.0|more data is not always better if you if
3731.68|3.84|you add
3733.039|5.52|boring data into your data set you may
3735.52|4.96|actually be diluting your data set right
3738.559|3.441|because your neural network will train
3740.48|2.8|for like i mentioned three weeks and
3742.0|3.359|it's going to see some number of
3743.28|3.759|examples in a training in this training
3745.359|3.68|and if a lot of the examples are boring
3747.039|3.28|it's not going to learn a lot so you
3749.039|2.8|actually want to be very careful with
3750.319|3.841|the and this is why i talk about
3751.839|4.48|curation of data sets it's an active
3754.16|5.36|process of adding hard examples and
3756.319|5.04|subtracting the easy examples often
3759.52|3.599|and a very easy way to see this is of
3761.359|3.68|course if i had just a single image in
3763.119|4.321|my massive data set of course that's not
3765.039|4.32|helpful so you really want to pad out
3767.44|4.0|the variability and that's why i use
3769.359|4.641|active terms like curation when i talk
3771.44|3.52|about data sets it's an active process
3774.0|3.359|to
3774.96|5.52|to curate the data set
3777.359|3.921|one thing that tesla has also announced
3780.48|4.879|is
3781.28|6.079|building their own chips for ai compute
3785.359|4.641|why why does that matter
3787.359|5.68|so there's many possible answers to that
3790.0|5.44|of course uh i think to a large extent
3793.039|3.76|elon sees ai as just a fundamental like
3795.44|4.0|pillar of
3796.799|5.201|of a lot of this technology and and
3799.44|4.399|wants to invest into internal teams that
3802.0|4.319|develop a lot of this technology and
3803.839|4.24|co-design everything tesla is is
3806.319|3.28|definitely about vertical integration
3808.079|3.52|and squeezing out a lot of juice from
3809.599|2.72|the benefits of that
3811.599|2.801|so
3812.319|3.76|to a very large extent of course we own
3814.4|2.959|the entire manufacturing of the vehicle
3816.079|3.921|in the factory
3817.359|4.0|and then we own a lot of the pieces of
3820.0|4.079|okay the hardware itself how's it
3821.359|3.68|pointed all the design decisions
3824.079|2.401|and
3825.039|3.76|we own the cluster we own the data
3826.48|4.16|labeling team and also we own the
3828.799|3.201|inference hardware the chip that
3830.64|2.399|actually runs the neural network on the
3832.0|2.88|car
3833.039|4.241|to us is just another another
3834.88|3.84|opportunity to co-design everything
3837.28|2.88|specifically for the purposes of
3838.72|4.319|self-driving
3840.16|4.56|and so the chip is designed with with
3843.039|3.52|the kinds of neural networks we want to
3844.72|2.72|run in mind
3846.559|2.961|and
3847.44|3.76|the hardware itself is just targeted to
3849.52|4.64|the operations that we want to run and
3851.2|4.8|do that do that very efficiently
3854.16|3.919|and so really it's just a
3856.0|3.599|it's a theme of tesla and it allows us
3858.079|3.121|to co-design all the components to work
3859.599|3.76|together towards a single goal in this
3861.2|3.44|case uh full cell driving
3863.359|3.361|when i think about
3864.64|4.32|chips for ai compute
3866.72|4.079|i didn't think there is training and
3868.96|3.2|then there is inference as you alluded
3870.799|3.441|to which is
3872.16|3.28|when it's used for driving
3874.24|3.68|um
3875.44|3.599|are you using both is it just inference
3877.92|2.96|right now
3879.039|3.601|yeah good question so as you mentioned
3880.88|3.439|you will typically
3882.64|3.52|um i guess hardware for deep learning
3884.319|4.48|actually kind of has like two broad
3886.16|4.159|areas now uh there's hardware you would
3888.799|3.28|use to train your networks and that
3890.319|3.76|looks very different from the hardware
3892.079|4.401|you were you might want to use to run a
3894.079|4.0|neural network um so running a neural
3896.48|3.04|network is computationally much more
3898.079|2.641|straightforward thing
3899.52|3.76|you're just kind of like doing the
3900.72|3.76|neurons just have to fire in a sequence
3903.28|3.44|if you're training a neural network
3904.48|3.28|there's a lot more that goes on there
3906.72|3.2|because
3907.76|3.839|you have to run the neural network
3909.92|3.36|forward but then you also have to
3911.599|3.041|implement the back propagation algorithm
3913.28|3.44|and you have to run the backward pass
3914.64|3.36|and you have to update the weights
3916.72|3.359|and there's a lot of technical details
3918.0|4.079|as to like at what precision do you run
3920.079|4.161|all this mathematical precision in terms
3922.079|4.24|of the numbers involved and so there's a
3924.24|5.359|lot of details that make the training a
3926.319|7.601|much more heavy endeavor and the testing
3929.599|5.681|the inference uh a much simpler endeavor
3933.92|4.32|and so as you mentioned we currently
3935.28|4.96|have a chip for inference uh that is
3938.24|3.28|that we own and we've designed and is in
3940.24|3.44|all the cars
3941.52|4.88|and we are also working on a training
3943.68|5.2|computer and this is a project dojo and
3946.4|4.32|elon has sort of alluded to it
3948.88|3.76|on a high level number of times
3950.72|4.399|and it is really just pushing this code
3952.64|3.679|design even further and we have a rough
3955.119|3.2|understanding of what these
3956.319|3.121|computational workflows look like for
3958.319|3.601|training neural networks for the
3959.44|3.44|autopilot it's a massive amount of video
3961.92|5.76|training
3962.88|6.479|and um we are building a chip directly
3967.68|3.359|sort of designed for that kind of a
3969.359|2.881|computational workload
3971.039|3.841|and so
3972.24|4.16|yeah that's absolutely an active project
3974.88|4.159|currently at tesla
3976.4|4.159|i'm curious about your thoughts i mean
3979.039|3.601|you were at open eye you're one of the
3980.559|3.28|founding members and
3982.64|4.0|open the eye
3983.839|5.121|recently then um
3986.64|3.919|somewhat recently raised billion dollars
3988.96|3.359|with specifically compute in mind and so
3990.559|3.121|i'm curious about that strategic angle
3992.319|3.121|also is that is that something in your
3993.68|3.2|mind that
3995.44|4.72|more compute
3996.88|5.679|is the only way to succeed in ai yeah i
4000.16|4.959|think more compute is
4002.559|4.641|one of the fundamental limiting blocks
4005.119|4.801|right now for a lot of things for a lot
4007.2|4.0|of domains openai is right now focused
4009.92|2.399|on for example natural language
4011.2|2.8|processing
4012.319|4.8|for example with their most recent work
4014.0|5.359|on gpt so what they're doing there is
4017.119|5.281|it's a language modeling task where the
4019.359|3.921|neural network is generating language
4022.4|3.439|text
4023.28|4.16|and so you can get you can feed the text
4025.839|3.121|and it will continue text or you can ask
4027.44|3.119|it to produce text with certain
4028.96|3.839|properties or it will answer your
4030.559|3.28|questions or it will talk to you
4032.799|2.0|and
4033.839|2.72|for
4034.799|3.76|so what's happening there is
4036.559|3.921|the algorithms again in this setting are
4038.559|3.201|actually quite well known and understood
4040.48|3.04|as you mentioned the neural network
4041.76|3.279|takes the form of this transformer
4043.52|3.2|you're training it in a very kind of
4045.039|4.56|standard regime with back propagation
4046.72|4.24|stochastic gradients and so on so that's
4049.599|3.44|understood so the algorithms are not the
4050.96|4.48|bottleneck for them the data set is also
4053.039|4.0|not a bottleneck for that uh class of
4055.44|3.52|problems because we have the internet
4057.039|3.921|with huge amount of text
4058.96|3.839|so in that regime so you are not upper
4060.96|3.839|bounded by data sets
4062.799|4.641|but you are upper bounded by the compute
4064.799|4.0|available to you which really restricts
4067.44|2.48|the size of the model that you can
4068.799|3.121|actually use
4069.92|4.639|and like i said in deep learning we are
4071.92|4.639|blessed with algorithms that seem to
4074.559|3.52|continue to work better and better as
4076.559|3.121|you just make them bigger you're
4078.079|5.04|literally just adding neurons into the
4079.68|5.679|system and it works better
4083.119|3.281|and so openi is primarily gated by
4085.359|2.881|compute
4086.4|4.719|in the setting if they could train a
4088.24|5.28|bigger network it would work better and
4091.119|4.561|that's not the way it used to be in ai
4093.52|5.36|we used to be bottlenecked by algorithms
4095.68|4.559|and so what a beautiful place to be
4098.88|3.279|if they could just run a bigger network
4100.239|3.841|it would work much better and the
4102.159|5.361|results would be even more magical and
4104.08|5.279|is that true for tesla also is that
4107.52|4.319|yes i would say so neural networks have
4109.359|4.561|this property in general that um yeah if
4111.839|4.161|you make them bigger uh they will almost
4113.92|3.759|always work work better and
4116.0|3.279|you know you um
4117.679|2.801|and you know in the limit you can for
4119.279|2.48|example use
4120.48|3.199|this is slightly more technical but you
4121.759|4.241|could use model ensembles you could use
4123.679|5.12|dropout and a lot of techniques to
4126.0|4.239|basically make sure that uh that
4128.799|3.601|these models
4130.239|4.881|work better when you scale them up and
4132.4|4.0|so we are also limited by compute uh to
4135.12|3.44|a large extent and we have to be very
4136.4|3.439|creative in how we squeeze out all the
4138.56|2.96|juice from all the flops that we have
4139.839|3.601|available on the car
4141.52|3.92|um and so that's the case also on the
4143.44|3.68|car but also during training
4145.44|3.2|for us right so you want to train as big
4147.12|3.199|of a network as possible
4148.64|2.719|and for us also
4150.319|2.561|um
4151.359|3.36|you have to consider the data center to
4152.88|3.6|whatever extent that is a bottleneck and
4154.719|3.761|the algorithms and the models and to
4156.48|4.0|whatever extent that is
4158.48|4.96|and so for us for example
4160.48|5.679|we do do a lot of manual labeling but we
4163.44|3.52|are also looking into ways that you can
4166.159|3.12|um
4166.96|4.96|train on um
4169.279|5.201|data without having to label with a
4171.92|4.879|human or you can use sensors expensive
4174.48|3.759|sensors to annotate your data
4176.799|3.281|and um
4178.239|4.08|so maybe maybe you have a few cars to
4180.08|4.48|drive around with say radars or lidars
4182.319|3.601|or any other sensing suite you want
4184.56|2.48|that gives you extra information about
4185.92|3.04|the scene
4187.04|3.6|and that can function as annotation for
4188.96|2.48|computer vision
4190.64|2.719|um
4191.44|3.84|and so computer vision can be matching
4193.359|4.241|those sensors and imitating them
4195.28|4.399|and so you have sensor annotation human
4197.6|3.68|annotation or self annotation like
4199.679|4.241|predicting the future and so all of
4201.28|4.399|those are knobs and kind of algorithms
4203.92|4.0|you could play with tesla is not the
4205.679|4.241|only company trying to build
4207.92|4.239|self-driving cars
4209.92|4.96|there is other efforts out there
4212.159|5.201|and sometimes at least in the media it's
4214.88|4.08|depicted as a bit of a race of who's
4217.36|2.24|going to get there first and so forth
4218.96|2.88|and
4219.6|4.0|so
4221.84|2.8|how do you see the tesla effort
4223.6|3.04|different
4224.64|3.92|from the other efforts it's a very good
4226.64|4.8|question because it is very different
4228.56|5.04|and it is not obvious so for example
4231.44|4.239|there was a
4233.6|3.84|there was a video just recently released
4235.679|4.56|where someone
4237.44|4.88|used a waymo car
4240.239|3.92|and the waymo drove them
4242.32|3.6|to some location i forget the details
4244.159|4.161|and then they use the tesla autopilot
4245.92|4.4|full self-driving beta build and it also
4248.32|3.68|drove them there with zero interventions
4250.32|3.52|and so both cars took the same route and
4252.0|5.36|got to the same spot with zero
4253.84|5.6|interventions um and so to a third third
4257.36|3.76|party observer just looking at this
4259.44|3.12|these are cars they take right turns
4261.12|4.0|left turns they navigate you to where
4262.56|4.32|you need to be it looks the same
4265.12|3.84|but under the hood the systems are
4266.88|4.24|actually extremely different
4268.96|3.759|quite different so
4271.12|3.2|the approach of waymo and many others in
4272.719|3.52|the industry and i would say in the
4274.32|4.48|industry we'll see these two classes of
4276.239|5.201|approaches really and one is way more
4278.8|3.52|like and the other is tesla like i guess
4281.44|3.04|in my
4282.32|4.08|sort of like description of it i suppose
4284.48|3.759|and in the waymo like approach you are
4286.4|4.4|going to first
4288.239|3.841|outfit the car with many more sensors
4290.8|2.96|um
4292.08|4.159|in particular the use
4293.76|4.64|of uh quite expensive lidar sensors that
4296.239|5.361|are on top uh they give you range
4298.4|5.04|sensing around you and you also have
4301.6|3.599|these high definition maps so you need
4303.44|3.44|to drive around before you make the trip
4305.199|3.361|and you need to pre-map the environment
4306.88|3.76|very high definition
4308.56|4.08|and then when you are driving you know
4310.64|3.599|exactly where you are on that map so you
4312.64|2.88|know exactly how to stay on it and how
4314.239|2.881|to drive
4315.52|3.04|and this is very different from what the
4317.12|2.64|tesla car is doing
4318.56|2.4|because
4319.76|2.88|first of all we do not have very
4320.96|5.04|expensive sensing we just have a few
4322.64|4.88|cameras that give us surround view
4326.0|2.96|and
4327.52|3.679|and by the way that's already a lot of
4328.96|4.8|information because each camera is say
4331.199|4.401|several megapixels and so you're getting
4333.76|5.12|many millions of observations of what's
4335.6|4.559|around the car when each ray really is
4338.88|2.88|of brightness is telling you something
4340.159|3.04|about the world so you're getting a huge
4341.76|3.04|amount of information from cameras that
4343.199|3.04|is very very cheap and economical to
4344.8|3.68|produce
4346.239|4.801|um and we do not use high definition
4348.48|4.239|maps so we have very low definition maps
4351.04|2.639|that are kind of like a google map so
4352.719|3.361|it's telling you that hey you should
4353.679|3.841|take right turn left turn et cetera but
4356.08|3.599|we do not know to a centimeter level
4357.52|4.4|accuracy where the curve is everything
4359.679|3.601|is coming from the system at that time
4361.92|3.04|through vision
4363.28|3.52|and so the car is encountering these
4364.96|3.44|intersections and these areas for the
4366.8|4.08|first time basically as it's driving
4368.4|4.88|around and it needs to look at the
4370.88|4.16|images and decide these are curbs these
4373.28|3.84|are lane markings this is how many lanes
4375.04|3.6|there are this is where i should be to
4377.12|4.48|take a left turn
4378.64|5.84|and so it's a much higher bar
4381.6|4.72|much harder to design but it's also much
4384.48|2.8|cheaper because the sensor suite is just
4386.32|2.64|cameras
4387.28|3.04|and it's not specific to a location that
4388.96|4.16|you had to pre-map
4390.32|4.32|so our system is very cheap and it will
4393.12|3.36|work anywhere
4394.64|4.48|what this allows you to do then is that
4396.48|4.16|this affords you scale so waymo can have
4399.12|4.48|maybe a few hundred cars or something
4400.64|5.92|like that we have millions of cars
4403.6|5.36|and as i mentioned scale is incredibly
4406.56|5.04|important to getting ai to work because
4408.96|4.719|everything is about data set curation
4411.6|3.92|and so i do not see how you can
4413.679|5.121|fundamentally really get a system to
4415.52|5.679|work well in absence of scale
4418.8|3.76|and so i think i would much rather give
4421.199|4.48|up some sensing
4422.56|4.639|in return for scale in ai problems i'm
4425.679|3.841|kind of curious when
4427.199|4.0|when you made your decision to to go to
4429.52|3.679|tesla i mean you must have seen that
4431.199|3.201|bifurcation and was that something on
4433.199|2.881|your mind at the time that you thought
4434.4|4.4|about a lot about what you believe is
4436.08|5.92|going to be the way forward absolutely i
4438.8|5.04|i definitely saw the bifurcation and um
4442.0|4.56|i felt like tesla had the right approach
4443.84|5.04|fundamentally and i'm a huge believer in
4446.56|4.24|deep neural networks and their power and
4448.88|4.24|i think images provide you
4450.8|3.6|with a huge amount of information and
4453.12|2.96|it's just a question of processing it
4454.4|3.44|and these deep neural networks that i
4456.08|3.119|know are capable of doing the processing
4457.84|3.44|that we need of them
4459.199|4.721|and so to me it's actually a brilliant
4461.28|3.52|strategic decision from elon
4463.92|2.88|and
4464.8|3.76|i was absolutely on board with a vision
4466.8|3.12|only approach and i do believe that the
4468.56|2.24|system can be
4469.92|2.799|can be
4470.8|3.28|arranged to to process all that
4472.719|3.281|information and actually drive around
4474.08|6.24|have you ever
4476.0|7.679|had to sleep on a bench or a sofa in the
4480.32|5.6|tesla headquarters like elon
4483.679|4.48|uh so yes uh
4485.92|5.2|i have slept at tesla a few times
4488.159|4.881|uh even though i live very nearby but
4491.12|4.24|there were definitely a few fires where
4493.04|4.159|that has happened i found
4495.36|4.16|i walked around the office and i was
4497.199|4.241|trying to find a nice place to to find
4499.52|4.4|uh and i found a
4501.44|4.239|little exercise studio
4503.92|3.759|so there were a few yoga mats and i
4505.679|4.801|figured yoga mat is a great place so i
4507.679|5.52|just uh crashed there
4510.48|4.56|and it was great and uh i actually slept
4513.199|3.281|really well and could get right back
4515.04|3.92|into it in the morning so it was
4516.48|4.4|actually a pretty pleasant experience
4518.96|3.759|oh wow
4520.88|5.68|i haven't done nothing in the while
4522.719|3.841|i had not expected this to be the answer
4528.08|4.56|cool wow
4530.159|4.08|so it's not not only elon who sleeps at
4532.64|3.84|tesla every now and then
4534.239|3.92|yeah i think it's good for the soul you
4536.48|3.44|want to be invested into the problem and
4538.159|4.08|you're just too caught up in it and you
4539.92|3.84|don't you don't want to travel and so on
4542.239|3.92|you just uh
4543.76|4.479|i like really i like being overtaken by
4546.159|3.761|problems sometimes when you're just so
4548.239|4.161|into it and you really want it to work
4549.92|4.4|and sleep is in the way and you just
4552.4|4.48|need to get it over with so that you can
4554.32|4.48|get back into it so it doesn't happen
4556.88|3.2|too often but when it does i actually do
4558.8|3.439|enjoy it i
4560.08|4.159|love the energy of the problem solving
4562.239|2.881|and uh i think it's good for the soul
4564.239|2.721|yeah
4565.12|4.16|so i'm curious what what's your view on
4566.96|3.6|the future of ai when we think beyond
4569.28|3.439|self-driving
4570.56|3.84|what are the big things on the horizon
4572.719|4.561|for us i think like
4574.4|5.12|first of all like wow the progress is
4577.28|3.52|incredibly fast when you're zoomed in to
4579.52|2.56|the day-to-day and the different papers
4580.8|2.8|that are coming out on the scale of a
4582.08|4.639|week maybe sometimes it can feel
4583.6|5.119|slightly slow but when you zoom out like
4586.719|3.681|alex net as i mentioned this uh this
4588.719|3.361|image net recognition benchmark that was
4590.4|2.88|beaten by neural net that really started
4592.08|3.76|the deep learning revolution and
4593.28|5.12|transformation was 2012.
4595.84|3.76|we're in 2021 so it hasn't even been a
4598.4|3.2|decade
4599.6|4.16|and i'll get to live hopefully four more
4601.6|5.599|decades or something like that maybe
4603.76|6.72|so if if like from 2012 to now
4607.199|5.921|has been a complete transformation of ai
4610.48|4.719|and a lot happened in a decade and so if
4613.12|4.4|i'm going to witness something on those
4615.199|5.681|orders of magnitude in next four years
4617.52|4.719|it's really mind-boggling to extrapolate
4620.88|2.88|and fundamentally we have these
4622.239|4.321|algorithms that seem to be on upper
4623.76|4.32|bounded by the data and the compute um
4626.56|3.119|and
4628.08|3.2|we're going to get more compute and we
4629.679|3.841|are specializing all of our hardware to
4631.28|3.919|neural networks and all that is ongoing
4633.52|3.28|our current processors actually are not
4635.199|2.721|very specialized for running neural nets
4636.8|1.919|and there's a lot of long-term fruit
4637.92|3.52|there
4638.719|4.321|um and so and also the size of the field
4641.44|2.96|has grown and so there's a lot more
4643.04|3.04|brain power going into improving
4644.4|4.24|everything and so there's this
4646.08|4.639|exponential like return on all of this
4648.64|2.96|investment in hardware and software
4650.719|3.52|and so
4651.6|4.16|you shouldn't expect linear improvements
4654.239|3.361|you should actually expect like some
4655.76|4.64|kind of an exponential improvements
4657.6|4.24|so it gets even more mind-boggling
4660.4|3.2|and so i think in the short term we're
4661.84|3.12|absolutely going to see much more
4663.6|3.68|automation
4664.96|4.0|be it self-driving cars or drones or
4667.28|3.28|warehouses and
4668.96|4.32|uh and so on
4670.56|3.92|um that's very easy to predict and
4673.28|3.04|um
4674.48|5.04|but i think on the long term that's
4676.32|4.8|where it starts to get kind of even more
4679.52|4.24|um
4681.12|4.72|dicey because uh
4683.76|4.56|you know like i joined open ai openai is
4685.84|4.319|basically a agi project artificial
4688.32|4.08|general intelligence so the idea is
4690.159|5.121|we're trying to develop fundamentally a
4692.4|5.12|artificial brain that thinks and wants
4695.28|3.2|and acts and functions like a human
4697.52|3.6|being
4698.48|4.32|so i would say next to a visual cortex
4701.12|3.2|we sort of have a check mark like that
4702.8|3.2|part of the brain sort of maybe like
4704.32|3.2|understand the principles of but we
4706.0|4.159|certainly haven't
4707.52|4.48|understood the entire brain and how
4710.159|4.08|um you know decision making is done and
4712.0|4.56|so on but i think we are
4714.239|3.92|with robotics and so on we are we are
4716.56|3.92|probably going to make a massive dent
4718.159|3.281|into that over the next decade or two or
4720.48|3.36|three
4721.44|3.759|and uh
4723.84|3.2|yeah i i think we're probably going to
4725.199|4.881|see some very exciting things come from
4727.04|5.8|from ai because the technology is not
4730.08|5.44|really upper bounded in any like real
4732.84|4.28|way um
4735.52|3.36|and it's mildly concerning but kind of
4737.12|2.64|exciting so i think we'll see what
4738.88|2.56|happens
4739.76|4.0|andre it's been absolutely wonderful
4741.44|5.6|having you on learn so much
4743.76|5.2|thank you now if anyone
4747.04|3.36|listening is like me
4748.96|3.92|and would like to keep learning from
4750.4|4.16|andre i highly recommend viewing and
4752.88|3.0|reading all the material on andre's
4754.56|3.2|webpage
4755.88|3.96|carpathi.ai
4757.76|3.919|this includes his talk at tesla autonomy
4759.84|3.28|day where he's on stage together with
4761.679|3.841|elon musk
4763.12|3.599|and i highly recommend following andre
4765.52|3.44|on twitter
4766.719|5.361|where he very generously shares his
4768.96|7.8|latest insights on ai with the world and
4772.08|4.68|on twitter that's at karpathy
4780.44|6.15|[Music]
4790.75|24.159|[Music]
4818.8|2.08|you