start_time|end_time|text
0.72|4.68| Yeah, before we jump into deep learning, let me briefly define
5.44|3.48| what machine learning is and what it is all about in a few
8.92|5.08| minutes. So it all goes back to the traditional programming
14.04|4.16| paradigm. So what do I mean by that? It's like, yeah, the
18.2|4.4| development of computer software to make our lives easier. So I
22.6|3.76| think one of the motivations behind developing software was
26.36|4.4| to make common tasks more convenient, for example,
31.04|4.36| replacing physical mail, by let's say, email, although it's
35.4|4.52| not 100% replaced. But yeah, with that, like change, now
39.92|3.24| things are a little bit more convenient compared to writing a
43.16|2.56| letter by hand, and then bringing it to the post office,
45.72|3.48| and then taking a few days until it's delivered, and so forth.
49.4|2.38| Email makes this whole communication aspect more
51.78|3.88| convenient. Although I would say maybe email is not so great,
55.66|3.82| because everyone included, I think, think that email is maybe
59.6|3.8| not making life easier, but harder, because there's no more
63.58|6.46| email than physical mail. In any case, so let's now imagine you
70.06|2.58| have an email program, and you want to make email more
72.64|5.4| convenient, you want to filter out spam, so unwanted email. So
78.04|5.92| imagine you want to design a spam filter. So as a programmer,
83.96|3.86| you want to design the spam filter. So our program is the
88.74|4.76| spam filter. And then we can give this to the computer, who
93.5|4.04| then will produce the outputs, which would be the label,
99.1|6.4| whether something is spam or not spam, or maybe going one step
106.34|3.76| further, just putting it into the right folder, like either
110.1|5.08| the inbox or the spam box on our email program. Now, how do we
115.18|4.2| design this filter? I mean, as a programmer, this could be a very
119.38|4.72| tedious exercise, we would first take a look at examples of
124.14|4.8| email. So we would take a look at our inbox, and then look at
128.94|4.08| what could be some spam email, we would then compare it to
133.02|3.4| non spam email, think about it, and maybe come up with a rule
136.42|10.92| that says, for example, if let's say, if email has the word, let's
147.34|9.2| say, win money or something like that, in the subject, then
158.86|6.0| classify it as spam. And then you can have an else, if
164.86|3.52| if something else, and so forth, you can develop these rules,
168.78|4.16| hard code them in your program, and then develop a spam folder
172.94|2.68| like that. But I think it would be super tedious to do that,
175.62|3.16| because you would have to take a look at a lot of messages, and
178.78|4.6| do a lot of testing and see if your rule works. And if some
183.66|3.52| additional l l if statement could improve it and not. And
187.18|3.68| it is like a lot of work like to take a look at this. And this is
190.86|4.36| why machine learning is so popular, because it can make
195.22|2.72| this life easier for us programmers for developing
198.3|5.56| software that can, for example, classify things. So here, in
203.86|4.56| contrast, at the bottom, I have machine learning in contrast to
208.42|2.88| the traditional programming paradigm. So in machine
211.3|7.36| learning, instead of having the programmer look at these inputs,
218.66|3.64| and making decisions, we provide the machine learning algorithm
222.46|5.52| with inputs and outputs. Again, outputs would be the labels for
227.98|4.72| our email. So we have a labeled data set. So here, this would be
233.34|5.96| our emails, and the outputs would be whether they are spam or
239.3|3.88| not spam. So a human actually would have to label those. So
243.18|3.96| you have to have a human to assign these labels to show the
247.14|3.72| computer what we want. So it's basically this is what what we
250.86|4.12| want the desired desirable outcome. So we have as a human,
254.98|2.04| we have to of course, communicate to the computer
257.02|4.2| what we want. We have to say, okay, we want spam and non spam
261.26|4.16| email labels. So we provide these as examples. And then the
265.42|4.64| computer can learn rules to make this classification. So the
270.26|2.56| computer is actually developing this program. This is our
272.82|8.52| machine learning model. And then the machine learning model can
281.34|4.68| actually replace our role as the programmer, developing the
286.02|2.88| program manually, we can actually give the program
289.14|3.24| directly to the computer to produce new outputs on new data.
292.66|4.8| So machine learning is the in a way the automatic learning from
297.5|4.04| examples. So there's also a famous quote by Arthur Samuel,
301.54|3.8| Samuel, this is a quote that you can find in almost every
305.34|2.84| machine learning textbook. So the quote goes like this,
308.38|3.0| machine learning is the field of study that gives computers the
311.38|5.64| ability to learn without being explicitly programmed. So here,
317.02|3.8| that means we are providing examples, and then the algorithm
320.82|3.2| learns automatically basic from based on the data instead of
324.02|4.44| having humans thinking about these rules. That's machine
328.46|3.2| learning in a nutshell. Specifically, this is a subfield
331.66|2.48| of machine learning called supervised learning, which I
334.14|4.96| will talk about in a future video. So yeah, but you may
339.1|4.76| wonder, how is machine learning now related to deep learning and
343.94|2.72| for example, artificial intelligence, you probably all
346.66|4.04| heard about AI and artificial intelligence. Most of the time
350.74|5.68| nowadays, deep learning and AI are used interchangeably.
356.42|4.44| However, there is a distinction I wanted to briefly discuss. So
360.86|3.52| machine learning, I would say is the biggest field. It's like
365.54|4.64| field encompassing deep learning. So deep learning is
370.18|2.8| strictly a subfield of machine learning, a subfield that
372.98|5.88| focuses on neural networks, deep neural networks, and AI is
379.14|3.92| intersecting with both, I would say, if there's one thing about
383.06|6.84| this graphic is I made the this one maybe I'm not I mean, not
389.9|3.84| big enough. But maybe I made this this part here too big. So
393.74|3.64| there is also what I wanted to say here is there are also AI
397.38|4.36| methods that don't use machine learning. So let me go through
401.74|5.56| these things step by step. So first of all, there are
407.3|6.12| there are different types of AI. So usually we say, generally AI
413.42|2.88| as artificial intelligence, which is a subfield of computer
416.3|4.32| science, solving tasks humans are good at, for example,
420.78|4.16| natural language, speech recognition, image recognition,
424.94|7.88| and so forth. And then we can subcategorize AI into two smaller
432.82|6.64| categories. One is narrow AI, and one is artificial general
439.54|7.0| intelligence. So what is narrow AI, narrow AI is a form of AI
446.54|4.6| that is focused on solving a particular task. So only one
451.14|3.68| task at a time, for example, image classification, or playing
454.82|3.88| a game, driving a car, let's say an algorithm for unlocking your
458.7|4.08| phone. So this would be a narrow AI, because it can only do
462.78|3.44| one task. So it's not like a human, a human can do multiple
466.22|4.56| things. I mean, I can go skiing, I can do cooking, I can write
470.78|5.36| emails, I can record a lecture and things like that. So I can
476.14|3.64| do multiple things, but a narrow AI system can only do one thing
479.78|4.16| that it has been developed for. In contrast, artificial general
483.94|5.08| intelligence is multipurpose AI, mimicking human intelligence
489.02|4.76| across multiple tasks. So if you have seen the movie X Machina,
494.54|2.84| the robot in this movie, for example, I would say it would be
497.38|6.52| more like a AGI agent where it can do things a human can do. So
503.9|2.68| multiple things, not only classifying images, for example,
506.74|3.12| so in that way, there's a difference between narrow AI and
509.9|3.88| AGI. However, AGI is for most people what they want to
513.78|4.64| accomplish is like the far future goal, but we are not very
518.42|3.08| close to that one yet. So that's like, people are actually
521.5|3.64| arguing whether it's possible at all, whether it will be possible.
525.62|3.4| Some people think it's like within 50 years, some people say
529.02|3.72| within 1000 years, there's actually a nice book on what was
532.74|3.84| the name architects of intelligence where the author I
536.58|3.52| think his last name was Ford, I forgot the first name. So the
540.1|5.08| author interviewed multiple experts in deep learning, when
545.18|4.32| when they would predict AGI will be invented. And there's like a
549.5|8.2| huge, huge span of predictions between 20 and 20 years, and
557.7|2.84| maybe 10,000 years, or maybe never things like that. So no
560.54|4.6| one really has a good idea, even when, or if this will ever be
565.14|4.56| invented. Narrow AI is something that we have nowadays in in
569.74|3.76| almost every aspect of our lives. And I will also talk more
573.5|6.68| about examples of that. So, um, yeah, so why did I do? Why did I
580.18|4.08| draw these circles like that? So AI, there was also something
584.26|3.52| called good old fashioned AI, it does not always have to involve
587.78|3.44| machine learning. For example, when we developed our spam
591.22|3.64| filter a few slides back, when I designed these if and else
594.86|3.28| rules, as a programmer, I was developing an intelligent
598.14|3.68| system, right? If I add enough of these if and else rules, this
601.82|4.08| system will be intelligent, and we'll be able to sort my emails
605.94|2.92| by spam and not spam. However, for that, I didn't use machine
608.86|3.88| learning. So in that way, AI doesn't always have to use
612.74|5.0| machine learning. Nowadays, most of the AI systems use machine
617.74|3.96| learning, though. And also, even more of them are using deep
621.7|3.52| learning, because deep learning is usually very good at natural
625.22|4.08| language and computer vision. So and this is also the focus of
629.3|2.48| this course. And this course will be focusing on deep
631.78|3.4| learning. Regular machine learning that is not deep
635.18|3.48| learning could be, for example, generalized linear models, for
638.66|3.72| example, linear logistic regression, tree based methods,
642.86|5.48| certain methods like random forests, or gradient boosting,
648.78|3.76| support vector machines, k nearest neighbors, this is all
653.26|4.78| something we covered in machine learning statistics 451
658.04|3.82| introduction to machine learning and the fall semester. In this
661.86|2.32| semester, we will be specifically focused on deep
664.18|3.92| learning, which is deep neural networks, which are very good at
668.14|3.08| our computer vision and natural language, which is something
671.24|4.3| these methods are not good at. So these methods, only because
675.54|2.4| we call them traditional doesn't mean they are bad, they are
677.94|4.32| still really, really powerful and useful for tabular data, I
682.26|4.2| will explain what I mean by that later. So they're really good at
686.46|5.24| on learning from tabular data. And deep learning is more suited
691.7|4.12| for learning from raw data, like images and speech and things
695.82|2.64| like that. So it's, it's not like one is better than the
698.46|3.56| other. The purposes are kind of different. So that's, that's the
702.02|0.96| main difference, basically.
704.74|3.6| Yeah, so yeah, just one more example of an AI system that
708.34|2.9| does not involve machine learning and deep learning. So
711.24|3.18| as far as I know, I mean, I was a bit young back then. But as
714.42|5.48| far as I know, deep blue, that was like a old chess computer is
719.9|3.34| not based on machine learning, it is like using an alpha beta
723.24|4.26| search, which is a search algorithm for finding good chess
727.5|2.52| moves. And as far as I know, for example, this would be an
730.02|3.84| example of a good old fashioned artificial intelligence that is
733.86|3.36| not involving machine learning, I may be wrong, but then there
737.22|6.04| are definitely examples of AI systems that don't use machine
743.26|6.48| learning. So then in general, we can say I is a system that
749.82|3.64| employs rules and is kind of intelligent through these rules
753.46|2.04| by using these rules. For example, if you think back of
755.5|4.28| our spam filter, that we could develop by hand by having a lot
759.78|4.84| of if and else statements, this can become intelligent as a
764.62|2.8| narrow AI, but it doesn't necessarily have to involve
767.42|3.76| machine learning. And yeah, machine learning is about
771.18|3.92| algorithms that learn models or representations or rules
775.1|4.0| automatically from data and examples, the labeled data. For
779.1|2.44| example, if you think back of the slide that I showed you,
781.74|4.32| when we showed algorithm examples of labeled email, and
786.3|2.72| then the algorithm would develop the program that would be what
789.02|3.88| machine learning is about. And then deep learning is also
792.9|2.68| machine learning, but it is specifically focused on
795.72|3.62| multi layer neural networks. So they are a little bit more and
799.34|4.42| more complex than simpler algorithms are not necessarily
803.76|3.08| they have usually more parameters. And we will see all
806.84|5.22| about that in this course. Yeah, here are some applications of
812.06|3.46| machine learning and deep learning in practice. So one, we
815.52|3.56| already covered the email spam detection. Another popular
819.08|3.72| example of machine learning would be deep learning specific
823.08|2.92| would be fingerprint and face detection and matching on the
826.0|2.88| phone. So if you have a smartphone, you probably either
828.88|4.84| have a fingerprint sensor or camera that detects your face to
833.72|3.68| unlock your phone, or web search is also heavily using machine
837.4|3.64| and deep learning, for example, Dr. Goh, Bing and Google spots
841.04|3.56| predictions, people use it for making predictions. At the post
844.6|3.04| office, also machine learning and deep learning are used for
848.64|5.72| scanning in the letters, the letters on the letters, and the
854.36|3.32| zip codes and then categorize the letters by zip codes like
857.68|3.12| image recognition, and handwriting recognition. And the
860.8|3.76| same is true for ATMs for reading checks. This was actually
864.56|4.52| one of the earliest applications of deep learning or machine
869.08|2.6| learning, it was a multi layer neural network, in particular,
871.68|2.84| convolution neural network, which we will be covering in
874.52|3.96| this course, it wasn't called Lynette. And it goes back to
878.48|4.12| the 90s. So it's almost 30 years ago. And that was one of the
882.6|3.12| early applications of deep learning. I mean, I say deep
885.72|2.68| learning, back then, the term deep learning wasn't invented. So
888.4|2.28| back then, people called it machine learning, but it was a
890.88|5.2| deep neural network. So here's a fun video. It's a real video
896.28|4.6| from the 90s, illustrating how this works. So here's a hand
900.88|5.0| written image of a handwritten digit. And then the machine
905.88|3.04| learning here, machine learning system here recognizes which
908.96|2.64| digit that is, and that can be then used in an ATM, for
911.6|4.08| example, or for sorting the zip codes. So of course, we will be
915.68|2.56| developing much more sophisticated systems in these
919.08|3.56| next couple of weeks. But this is, I think, a nice, nice
922.64|5.88| example of classic deep learning. Yeah, other applications
928.52|3.44| include, for example, smart assistance, like Apple Siri,
932.12|3.12| like the voice assistant, and also Amazon Alexa, and all these
935.24|3.84| types of voice assistance nowadays, or using deep
939.08|4.16| learning. And then the product recommendations, if you know
943.24|3.2| Netflix or Amazon, they always recommend products based on
947.0|3.84| machine learning, self driving cars, unfortunately, still not
950.84|2.8| here yet. I mean, I'm not sure if it's unfortunate. But yeah,
953.64|3.4| that would be another great application, not application,
957.04|4.12| but at least example of deep learning. It's actually a bit
961.16|2.52| complicated. So there are many things at work, from
963.68|2.96| reinforcement learning to supervised learning with
966.68|4.48| images. So here's like a little example from Waymo. So that
971.16|4.4| would be another area where AI deep learning machine learning
975.6|4.52| are used, language translation, sentiment analysis, drug
980.12|5.16| design, medical diagnoses, diagnoses, and things like that.
985.28|4.68| So I will also at the end of each week, upload a video that I
989.96|6.68| will call stuff in the news, where I will highlight some of
996.64|3.4| the recent applications or interesting things in the deep
1000.04|2.96| learning world, where I will show you way more examples. For
1003.0|3.28| example, I'm just thinking of this because when I mentioned
1007.04|4.28| medical diagnoses is there was like a system recently a new
1011.32|3.76| system for detecting COVID from lung x rays. There have been
1015.08|2.2| lots of these systems lately, but there was a particularly
1017.28|3.52| good one, for example, last week, in collaboration with
1021.04|3.56| doctors at NYU. And I will show you more examples of deep
1024.6|3.12| learning in the real world in these stuff in the news videos.
1027.72|4.08| But yeah, that is just a quick overview of machine learning.
1033.04|4.68| Just to lay the groundwork. And then in the next few videos, I
1037.72|3.12| will say a little bit more about the subcategories of machine
1040.84|2.28| learning. It also applies, of course, to deep learning,
1043.12|2.64| because we've learned that deep learning is a subcategory of
1045.76|2.12| machine learning. And we will also talk more about the
1047.88|3.52| workflow and some jargon. And then about the tools we'll be
1051.4|3.52| using in this course. So this is still all lecture one. And then
1054.92|5.24| I will pause this video here and then record the next one on the
1060.16|28.56| broad categories of machine learning.