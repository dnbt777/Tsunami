start_time|end_time|text
0.8|4.2| Yeah, let's not talk about pytorch custom data load. So
5.24|4.12| the data loader is a class in pytorch that lets us Yeah, a
9.36|4.08| lot data more conveniently compared to doing it manually. I
13.44|5.04| will show you two notebooks. One is just the data loader itself
18.52|3.96| with a simple example. And then I will show you how we can use
22.48|6.64| it in a model training context. So yeah, what I should say is
29.12|3.8| I'm actually using MNIST here. And you may wonder why MNIST
32.92|3.56| because there's already MNIST data set and data loader
36.52|3.0| implemented in torch vision, which we could technically
39.52|3.52| import, which is what we have done. And yeah, last couple of
43.04|5.88| videos. So the reason is, MNIST is relatively small. And yeah,
48.92|3.32| in this way, I can upload it to GitHub. So I can upload this
52.24|3.76| without, let's say, taking too much space in that repository.
56.0|4.32| And it's also for you faster to download. And it was just convenient
61.36|2.4| because you are already familiar with it. But of course, here
63.76|4.72| MNIST this represents a more general data set. So think of
68.48|4.6| it as an arbitrary data set consisting of PNG files. So what
73.08|5.84| I've done is I divided MNIST into three parts, a training set,
78.92|4.84| a validation set, and a test set. So I put them here into
83.76|4.72| um, PNG files, just in each folder, there's a set of PNG
88.48|8.04| files, as you can see here. And I have also a corresponding CSV
96.52|6.2| file. So here in the CSV file, I have the class labels and the
102.72|4.76| file name. Of course, you can also if you like, you can have
107.48|5.44| only one folder with PNG files and then have a column with
112.92|4.92| validation train and test index. So you can also specify it like
117.84|3.96| this. I mean, how you set it up is up to you. I sometimes find
121.8|2.84| it convenient to do it like this. Sometimes I only have one
124.64|4.2| gigantic PNG file folder and keep track of what is training
128.84|3.04| what is validation with this test, I keep track of it with
131.88|3.12| columns in the CSV file. But this is really optional. I mean,
135.0|3.32| like how you want to set up is up to you. You can set it up
138.32|3.32| however you like. And I will show you how we can then handle
141.64|5.12| handle that with pytorch data set class. So back to this
146.76|3.24| notebook, so I showed you now, I have these files. So focus now
150.0|3.52| on the on these three folders. And these CSV files, the helper
153.52|2.88| function, I will use them later in this train model notebook.
157.76|3.8| So yeah, let's get started. So usually, when I have a new
161.56|4.24| data set, what I do first is I inspect this data set. So I
166.92|4.04| sometimes use I use image IO, sometimes I just use the Python
170.96|4.44| image library. I'm not very consistent, it doesn't really
175.4|3.36| matter. There are multiple libraries in Python that lets
178.76|4.28| you open a PNG file or JPEG file in Python itself. And then you
183.04|4.4| can take a look at it. So here, I'm using PIL, it's the Python
187.44|3.44| imaging library. If you have to install it, I think you have to
190.88|8.56| do kind of install pillow. Why pillow and not why pill or PIL,
199.44|3.68| that is because on the Python imaging library, I think it got
203.12|4.12| abandoned at some point. And then some people forked it on
207.52|4.44| GitHub to further maintain it. And this fork is called pillow.
212.36|3.88| But even if you install it as pillow, the import is identical,
216.24|4.68| you use this one to import it. Or in particular, we are only
220.92|4.16| implementing the importing this image class. So here, I'm just
225.08|5.0| looking at the image. So here, I'm loading one data point or
230.08|5.64| one image from this MNIST train folder. Why C map binary? Yeah,
235.72|3.12| because color maps by default is this the readers color map,
238.84|3.92| which is kind of useful for heat maps. But yeah, here, maybe it
242.76|4.0| looks a bit goofy if we have these colors for MNIST. So here
246.76|5.2| we use just this version. All right. Yeah, also, I find it
251.96|2.64| helpful to just take a look at the image dimensions. So here,
254.6|4.28| here, it's 28 by 28. There is no color channel. And you can see
258.88|7.28| the values, the pixel values are between zero and 255. Could be
266.16|3.12| 254. I'm not actually not quite sure. He actually I see the
269.4|1.92| the highest one is 253.
274.72|5.32| Alright, so then looks okay. So we know, know what we are
280.04|9.48| working with. Let's now load the CSV files, pandas and CSV files.
289.76|4.68| So these are only the first five rows with this head command.
296.24|4.2| Yeah, and I can also show you Oh, you can see it right here.
301.64|4.68| The data set is yeah, only I made it artificially small,
306.32|3.52| there are only 256 images in each data set. And this is of
309.84|3.76| course, much bigger. It's usually, I think 50,000 in the
313.6|3.24| training set and 10,000 a test set. Here, I just made it
316.84|3.28| smaller, because I'm going to upload this to GitHub. So you
320.12|4.36| can download it in this way. It's not like too much taking up
324.48|3.76| too much space there. Otherwise, I don't want to upload 50,000
328.24|3.76| small files and stuff, you know. Alright, so here,
332.0|6.72| um, here's our interesting part. Now, that's the data set class
338.72|3.88| and pytorch. And so in order to do to use the data loader, we
342.6|2.72| need a data set. So there are two parts, one is the data set,
345.32|2.76| and one is the data loader. So let's talk about the data set
348.08|3.32| first, because that's what we need for making the data loader.
352.0|6.92| So here, the data set is really how we read the data. So this is
358.92|4.6| something you have to set up yourself for a new data set. So
363.52|6.48| here, this is from pytorch torch utils data, this is something a
370.0|3.92| class from pytorch. And here, this is called class inheritance
373.92|3.6| in Python. So we are inheriting certain features from data set,
377.76|3.84| so that they are available in our data sets, it's called class
381.6|3.52| inheritance, it's like a, not a pytorch, but a Python concept.
385.8|2.76| So and then we're defining our own data set, I'm just calling
388.56|4.28| it my data set, but you can call it whatever you like. And then,
393.2|3.2| like in every class, we have an init method. And here in this
396.4|3.36| constructor, and this init method, I'm specifying certain
399.76|3.76| things. It's basically, by the way, arbitrary, what I put here,
403.8|3.4| it's not required to put anything here. But what we need
407.2|3.28| here, because we have CSV files, and we have folders, I put both
410.8|3.76| the CSV path, path, the path to the CSV file, let's say the
414.56|3.76| training CSV, and the image directory, for example, here,
418.32|5.16| this directory. And there's also a transform for doing a custom
423.48|3.6| image transformation, I will show you just a very basic
427.12|2.88| transformation, actually, we're not doing any transformation. I
430.0|5.56| will talk about this in the next lecture. Yeah, so what's going on
435.56|4.2| here is in the init, in the end, we are loading the CSV file and
439.76|3.8| keep it attached to the data loader. Not now, we don't need
443.56|8.0| it attached, we one second. So we load CSV file, we save the
451.56|3.32| image directory to the self dot image dear attribute, so we can
454.88|5.28| use it later. And then we save the image names as self dot image
460.2|3.6| names. And this comes from the CSV file from the file name
463.8|3.36| column. So if I scroll up again, this is this column, we just
467.16|4.04| save this column here. And then we also save the class label
471.2|4.32| column as self dot y, these are our class labels. And then we
475.52|4.5| just store whatever we provide us transform here. So this is a
480.02|5.66| setup for the data set when it's created. And here, this is how a
485.68|3.24| data point gets loaded a single data point, remember that this
488.92|6.36| one that was in short unit animation, loading a pair of data
495.28|3.64| point with its training label, basically, so one image and one
498.92|4.0| label. So that's what we are, what's loaded with this get item
502.92|4.72| here. Here, you have to have this index here. I mean, there are
507.68|5.12| other ways, but I find it convenient with the index. And
512.8|4.32| then we have to specify. So what we do is here, we specify how we
517.12|5.48| obtain one image and one corresponding label. So how do
522.6|3.56| we open the image? So image dot open, so this is similar to what
526.16|8.84| I used up here, image dot open. And then I'm giving it the path.
535.04|6.12| So the path is based on the image directory that I provide
541.16|5.84| here. And then the image name. So the image name is in this
547.02|6.9| column, right? So here, what IMG is, it will be, for example,
553.92|9.12| something like MNIST train, let's say one dot png. So here,
563.04|3.8| index will select a random one, so it could be the one or three
566.84|7.6| or five, one, two, 123, whatever. So this is chosen
574.44|3.24| randomly. So this is how this data set is basically shuffled
577.68|3.96| by always picking the indices in random order. And then there's
581.64|3.04| an optional transformation that we can apply to the images, for
584.68|3.92| example, normalization, rotation, and things like that.
588.6|4.38| And I will show you how that works in the next lecture. And
592.98|4.38| then we also obtain the corresponding class label. So if
597.36|5.12| index is, let's say one, then we will let's say, index is here
602.48|3.72| one, then we would obtain image 513 dot png and the
606.2|3.92| corresponding label zero. And then it returns both the image
610.12|3.2| and the label. And that's essentially it, there's one more
613.32|4.24| method here, that's the len. And this one is the length of the
617.56|5.04| data set. So that is how this data set knows when one epoch is
622.6|5.24| finished. So here, we can simply compute the length by getting
627.84|4.18| the shape of this y, which is the class label column. So
632.02|13.0| essentially, I have not imported anything here. I actually should
645.02|5.4| have def is not defined, huh? Oh, I sorry, I called it the
650.42|11.68| gift train. Alright. Okay. So this is our data set. So this is
662.1|5.36| really specifying how we lot a data set or images from the
667.46|4.56| data set. And now this is the data loader that is also
672.02|3.96| loading data points. But this is really for making our mini
675.98|10.22| batches. So for doing that, we need the data set. So here, what
686.2|3.28| I'm doing is I'm setting up the training data set. So the
689.48|4.9| training data set has the CSV file, men, mnist, underscore
694.38|4.28| train dot CSV, and the folder mnist train. This is this folder
698.66|5.6| here. And this CSV file. Let me before I explain this in more
704.26|2.8| detail, also show you the validation data set. So here's
707.06|2.52| the same thing for the validation set. But notice that
709.58|2.52| the folders names are different, and the CSV file names are
712.1|7.76| different. And here is the same for the test set. Now, see,
719.86|3.64| there's another thing going on transform. And this is our
723.5|5.0| custom transformation. We don't do anything here, except
728.78|4.16| converting the image to a pytorch tensor. So there's the
732.94|4.76| torch vision library, which has this transforms package or sub
737.7|5.38| library. And there are different methods for augmenting and
743.08|3.12| transforming images here, I'm using something called to
746.2|4.38| tensor. And this one will convert an image to pytorch
750.58|4.36| tensor. But it will also normalize the images by dividing
754.94|5.28| them by 255 automatically. I actually find this, I don't know,
760.22|3.12| I would like if it wouldn't do this automatically, because
763.34|5.32| it's maybe something we don't want to do. But in any case, it
768.66|3.04| does. So what I mean is, it would be cool to have the
771.86|2.44| choice, whether we do it or not, maybe there's a new function
774.3|2.72| that has or give you gives you the choice. But it's actually
777.02|2.6| not a bad idea to normalize images. So in a way, it's maybe
779.62|3.16| good. So people avoid making mistakes, because you're
782.78|2.4| training a network on unnormalized images is usually a
785.18|7.2| bad idea. Okay. Um, yeah, so this is how we then set up our
793.3|3.24| training data set. Now we have created a data set of training
796.54|3.6| data set using our my data set class that we defined here. So
800.14|2.72| here, this is just defining the class. And here, we are actually
802.86|3.8| using it. And now we are setting up the data loader. So that's
806.66|4.88| the main part, which takes in this training data set. And
811.54|4.62| here, we also specify the batch size. We specify whether we
816.16|2.9| shuffle or not, after each epoch. So this is shuffling,
820.26|4.68| essentially before each epoch. And there is also a parameter
825.3|6.68| num workers. So it would be great to have a whiteboard here
831.98|7.8| or something. I don't have one. But think about it as this. So
839.78|4.12| if we Python is single threaded, usually, so there's one main
843.9|4.12| Python Python process, one process running. So there's
848.02|4.72| usually let's say, data processing. And then there's our
852.74|5.44| model. And this, let's say, we give our data to the GPU. And
858.18|7.72| then on the GPU, that happens to model training. And then it then
865.9|8.36| then it goes back to data processing again. And then it's
874.26|3.44| basically a repeating loop. So we're going from data processing
877.7|2.52| to the GPU, where we do the model training and then data
880.22|3.68| processing GPU model training. And this would also be true for
883.9|4.24| CPU. The main point is that this is sequential because Python is
888.14|5.84| usually one single process, one main process. However, data
893.98|4.56| processing can be slow. I mean, it can take, let's say 10
898.54|6.28| seconds or five seconds to load the images. So it would be more
904.82|6.32| efficient if we have the data processing decoupled from giving
911.14|3.4| the data to the GPU and the model training if those happen
914.54|3.32| like in parallel, right, so we could have actually multiple
917.86|5.6| CPUs via multiple CPUs, we can do the data processing and then
923.46|3.88| the data is already ready in the memory. And the GPU just has to
927.34|2.56| read it and do the model training and it has never, never
929.9|6.84| has to wait until the next batch is processed. So in that sense,
936.74|4.44| we can use multi processing of our CPU to prepare the next
941.18|3.8| batch of images for the GPU so that GPU doesn't have to wait.
944.98|3.72| For that, we can use the number of workers greater than zero. If
948.7|6.0| we have zero, then only one main Python processes used for both
954.74|3.24| for everything for the whole pipeline. If we set it to one,
958.26|2.68| then it will create one sub process to load the data, which
960.94|4.44| is makes it more efficient. And two is even better. I noticed
965.38|2.44| when I run it here, actually, I get problems recently with
967.82|4.04| recent versions. I think this is because m this is so fast to
971.86|4.68| load, that it will just load too many things at once. And then it
976.54|4.08| has too many open files waiting for the GPU to be processed. So
980.62|3.28| I get some nowadays an error when I run it on mnist. But if I
983.9|2.48| have any other data set other than mnist, that is usually not
986.38|2.4| a problem, because mnist is really just too simple. I think
988.78|3.44| that's the problem. So I set it to zero. But in your projects,
992.22|2.44| you may want to set it to a higher number. And for example,
994.66|3.96| in my research projects, I usually use two or three without
998.62|6.32| two or three without problems. Yeah. Well, I should also
1004.98|5.16| explain what drop last means. So if you have a number that is,
1010.14|3.96| let's say, not divisible by 32, then there will be a last batch
1014.1|4.2| that is smaller than 32, right. And if drop last is true, it
1018.3|4.8| will be dropped. You don't have to do this. I mean, like, you
1023.1|2.8| don't have to drop this. But I noticed sometimes in my research
1025.9|4.08| code that if I have, let's say, batch sizes of 512, and then the
1029.98|3.92| last batch is only 11 examples, this last batch can be extremely
1033.9|5.08| noisy, and sometimes harm the model performance as a bad
1038.98|2.88| update at the end of the epoch. So personally, in my projects,
1041.86|4.12| I found usually dropping the last mini batch, if it's smaller
1045.98|6.08| than the batch size is sometimes good. Alright, let's take a
1052.06|3.22| look now. So here we are initializing all the data loaders
1055.28|4.62| for the training set for the validation set and the test set.
1061.62|3.44| And here, I'm just, yeah, I'm iterating through it to just
1065.06|3.4| make sure that it works. So yeah, I'm simulating how we
1068.46|4.72| would train a model. So we have, let's say, just two epochs. And
1073.22|5.2| then we iterate through the batches here. For our training
1078.42|2.68| order, this is actually what you have seen before, we have used
1081.28|3.98| the built in MLS data set. Here, I'm transferring it to the
1085.26|3.24| device. So the device, if you have a GPU, it will be the first
1088.5|4.44| GPU. Otherwise, it will be the CPU. So yeah, it will just
1093.02|1.28| iterate. See,
1097.74|6.1| to just give the batch size, so it will create 12345678 mini
1103.84|7.0| batches. And that is it. Let me change this to one and see what
1110.84|5.42| happens. So I don't always get this error. But with MNIST, see,
1116.26|4.96| I get something called like this.
1127.46|4.14| I think this is because there are too many open files doesn't
1131.6|5.6| say so explicitly. Because the weird thing is, I don't get this
1137.2|3.6| error when I run this on data sets that are not MNIST. There's
1140.8|3.32| something about MNIST. I think it's MNIST is just too simple.
1145.28|3.84| It's a little bit weird, to be honest. Also, I can't remember
1149.12|3.76| in the past getting this error. But anyways, could also be my
1152.88|3.8| computer because I compiled pytorch from scratch. But I
1156.68|9.28| also get this error on my other machine. So anyways, so let's go
1165.96|2.86| back to this one. Yeah. And here, we can also just print the
1168.82|4.7| shape of one of the batches here. So the shape is 32, then
1173.52|3.82| the color channel is only one color channel. So because it's
1177.34|5.5| back in white, and then 28 pixels high 28 pixels wide, he
1182.84|5.86| is just printing it as a vector if we reshape it 32 times 784.
1188.8|4.6| So this is what our multi layer perceptron needs as an input. So
1193.4|3.4| convolutional networks can work with this input directly.
1197.32|3.8| multi layer perceptrons cannot they can only work with this is
1201.12|3.12| just for reference. So it looks like the torch tensor, you can
1204.24|8.36| see it's normalized, we should be able to maybe we can't just
1212.68|4.36| see if it because it's abbreviating it. So we can print
1217.04|4.6| it. You can see the highest values point 999 because it's
1221.64|6.88| 253 divided by 255. Alright, so this is how the data loader
1228.52|4.64| works. Let me now show you the model training code here using
1233.16|6.08| the custom data loader. So here, I'm now using a hybrid of what I
1239.24|4.52| showed you two videos ago when I use helper functions, helper
1243.76|6.08| scripts and a notebook. So here, I've set up several helper
1249.84|4.28| files that I may reuse in different projects. And this
1254.12|3.8| helps me keeping the notebook kind of small. So if I make a new
1257.92|6.92| notebook, let's say I call it notebook. To I can make some
1264.84|2.4| changes to this notebook, for example, some settings, but I
1267.24|3.46| don't have to copy and paste all the code. It's in that way easier
1270.7|3.42| to read, especially if you want to let's say modify some
1274.12|3.48| function as a bug in the accuracy function, then you
1277.6|3.84| don't have to go back to every file here and change the code,
1281.44|2.08| you only have to change it in one of the files and the pie
1283.52|5.68| files. So I can just maybe open them, show you what I mean. So
1290.08|3.48| example, helper evaluate, I have this set all seats, deterministic
1293.56|2.8| compute accuracy. So if there's a bug, for example, I only have
1296.36|2.44| to change it here once I don't have to go back to all my
1298.8|3.4| notebooks. I find this very helpful if I have a project with
1302.2|3.8| multiple model training and model notebook scripts or
1306.0|2.04| notebooks and scripts. All right.
1310.0|5.04| We close this again, we can take a look at individual ones. So
1315.76|4.44| yeah, yeah, importing certain functions from this, from these
1320.2|0.88| helper files.
1322.32|2.44| Then here are my settings, you can also like I explained
1324.76|2.58| before, have a separate settings file here, I have it just in a
1327.34|3.58| notebook itself, random seed batch size, a number of epochs.
1330.92|4.44| And then I'm using these to make that deterministic. And he has
1335.36|4.0| just, so yeah, I have a get data loaders function that actually
1339.36|2.8| uses the data model from the previous notebook that I showed
1342.16|4.48| you, I just put it into this script here. Now I have my data
1346.64|5.84| set here. And I have written a get data loader, which will set
1352.48|4.72| it up for me automatically. So that's basically just a slightly
1357.24|2.6| modified version of what I've showed you in the previous
1359.84|3.24| notebook, where I just have arbitrary paths and stuff. And
1363.08|2.56| it will return the training loader validation order and test
1365.64|3.4| loader. And here, I'm just testing that they actually work.
1369.28|4.8| So just getting some statistics. And you can see, so if I run
1374.08|3.64| this again, you can see that the shuffling works, because you can
1377.72|3.24| see that these numbers change. So these are the first 10
1380.96|4.16| labels. So you can see, so every time it will start from scratch,
1385.12|6.32| because I break here. So you can see these numbers change. However,
1391.44|5.44| if I set my random seed, I always get the same order. See,
1396.88|4.28| I can run this again, always get the same order because of the
1401.16|6.28| random seed, the random seed. Yeah, makes the makes it
1407.44|3.56| consistent. It's so for example, if you run this code, you will
1411.0|4.32| get the same model and same accuracy I got, because you use
1415.56|3.52| the same random seed. This is useful, for example, if you do
1419.36|2.56| research, and you develop some code and want to share it with
1421.96|3.08| someone else and other person wants to reproduce your code.
1429.8|3.76| So yeah, here's the multi layer perceptron. I simplified this a
1433.56|2.4| little bit. So I'm using sequential now I mean,
1435.96|3.36| simplified compared to two videos ago. Here, I'm actually
1439.32|3.44| using flatten, this is actually new, I like this a lot. So this
1442.76|3.88| way, we don't have to reshape our feature vector. So it will
1447.0|6.56| essentially reshape the 28 by 28 to 784 for us. So we don't have
1453.56|4.64| to do it manually somewhere down here. And this is it. So here,
1458.2|2.28| I'm using sequential, so I don't have to do anything in the
1460.48|4.12| forward, it will automatically return the logits. So here, this
1464.6|3.88| is a multi layer perceptron with only one hidden layer. So this
1468.48|3.32| is the first hidden layer, then with a sigmoid activation, and
1471.8|4.56| then we have the output layer. And then we would technically
1476.36|2.48| have a softmax, but we don't need to have the softmax
1478.84|3.88| because the functional cross entropy loss in pytorch computes
1482.72|5.8| the softmax for us. Alright, so this is how it works. So don't
1488.52|4.68| need to set another seat here, because I've done that above. So
1493.2|6.36| here, the seat would be for for the initial random weights, we'll
1499.56|4.56| also talk about this in two lectures. So not the next
1504.12|3.04| lecture, but the next one. After that, we will talk about these
1507.16|3.96| different ways we can initialize weights, use stochastic gradient
1511.12|4.56| descent. And here, I also just brought a function for training
1515.68|3.24| the model is essentially what you've seen before, I just put
1518.92|3.04| it into a separate file here. So if I go to help out a train dot
1521.96|3.4| train dot pi, I have all the code I have had previously in
1525.36|4.64| here. Because it's essentially always the same code. So you can
1530.0|4.0| use that in other projects as well. You can just copy and
1534.0|2.96| paste that just keeps the notebook more readable in that
1536.96|4.28| way. It's not such a long notebook anymore. Oops, we got
1541.24|4.64| here. That's what I always forget defining things. Alright,
1545.88|3.6| so trains will train very fast, actually, because we only have
1549.48|8.42| 256 data points in each data set. This training fast. Now we
1557.9|2.2| get actually pretty high accuracy. I mean, given that we
1560.1|3.32| only have 256 images, it's also barely overfitting. It's
1563.42|4.84| actually not Yeah, you can see it's 91% and 73. It's actually
1568.34|3.72| it is overfitting. But yeah, the validation accuracy and test
1572.06|2.48| accuracy are almost identical. The difference here, why is the
1574.54|2.66| difference? It's usually just a small random effect, right,
1577.2|6.6| because it's a small data set 256. Yeah, and then I also have
1583.8|3.0| functions for plotting the training loss and the accuracy
1586.84|4.12| is also helpful. So yeah, I have the version with a running
1590.96|6.88| average. And can see on the loss goes down. We are trained for
1597.84|3.44| 100 epochs. And here the accuracy goes up. But then at
1601.28|3.04| some point, there's more and more overfitting. So yeah, put
1604.32|3.92| these plotting functions in help out of plotting, if you ever
1608.24|2.92| need them. I think I will also personally reuse them in future
1611.16|2.4| lectures, because then I don't have to make these long
1613.56|4.12| notebooks, because this code is really always the same. So I
1617.72|4.24| have it sometime defined here, and then I can reuse that. You
1621.96|3.6| don't have to honestly memorize any of that. Or it's good, maybe
1625.56|2.04| to understand it if you want to change it, but you don't even
1627.64|3.8| technically have to understand any of these details. So it's
1631.44|3.76| also something I wrote one time. And if I ever need it again,
1635.44|4.2| I'll just copy and paste it. Because there are too many other
1639.64|3.16| things to worry about. It's rewriting, this is, it took me
1642.8|2.52| some time, I had to, there were some bugs, and things didn't
1645.32|4.16| work. And that way, you write it once so that it works, and then
1649.48|5.16| you can just reuse it. Alright, so last as a show examples
1654.64|3.0| function I wrote, so it shows some of the images. So you can
1657.64|5.2| see, P means predicted and T means true label or target
1662.84|8.02| label. So these are all correct. So here, this is a predicted as
1670.88|3.48| two, but the target is six, I see, I think I made an error
1674.36|3.86| here that can't be right. Maybe it is right. But let me double
1678.22|3.66| check. I haven't planned this. It's very spontaneous. So good
1681.88|7.52| that we look at it, I think is, yeah, I saw it's my mistake. I
1689.4|5.16| just wrote this code, actually, for this lecture. So made a
1694.56|4.76| mistake. Let's do this again.
1699.32|15.84| Oops, should have been targets. One of the disadvantages because
1715.16|4.8| I have the import at the top of this notebook. I have to run the
1719.96|13.12| whole notebook. But it's faster. Alright, so that looks better
1733.08|5.2| now predicted six, target two predicted five, well, target
1738.28|4.72| zero. Some other mistake here, you can see the model makes some
1743.0|3.08| mistakes. But I think these are just mistakes, because the model
1746.08|2.92| hasn't haven't hasn't seen enough numbers, because these are
1749.0|2.6| should be easy to distinguish them. I think they are clearly
1751.6|4.72| number twos. Okay, so yeah, this is the custom data loader. So
1756.32|4.8| that's it then for this lecture. Next week, we will talk about
1762.24|4.8| regularization like preventing overfitting. All right, have a
1767.04|12.0| good weekend.