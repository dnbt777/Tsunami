start_time|end_time|text
0.56|2.92| Yes, in the previous video, I showed you the big picture
3.48|4.32| overview of how a recurrent neural network looks like. And
7.8|3.32| now I want to show you that we can use this architecture for
11.32|4.7| different types of sequence modeling tasks. So on this
16.02|2.94| slide, I have an overview of the four common sequence modeling
18.96|4.44| tasks, and I will walk through them step by step in the next
23.4|6.8| couple of slides. So starting with this many to one setting,
30.44|5.08| that is when we have multiple inputs, and one output. So the
35.52|3.32| input data is a sequence, but the output is a fixed size
38.84|4.08| vector, or value, not a sequence. One example would be
42.92|3.44| sentiment analysis, where the input could be some text and the
46.36|4.4| output could be a class level, whether the text is positive or
50.76|2.94| negative in terms of the sentiment. For instance, if you
53.7|3.42| think back of the movie review example that I mentioned
57.12|4.08| earlier, so each input can be a written review, and the output
61.2|3.12| could be whether the reviewer thinks the movie is positive or
64.32|6.96| negative. Another one would be one to many. So this is another
71.32|3.84| type of sequence modeling task where you could I mean, this is
75.3|3.0| a little bit more beyond just standard RNNs. It's more like
78.3|4.22| something that you could use together with CNNs. So it's also
82.52|5.96| of course possible to combine both networks. So here, the
88.48|5.04| input data would be standard input. So for example, an image
93.84|3.54| and the output would be a sequence. And one example would
97.38|3.66| be image captioning, where here the input is, let's say an image
101.04|4.36| of something. And then the output is the text description
105.4|2.8| matching that image. For instance, if you have a picture
108.2|4.44| of someone who's playing tennis, you can have a, let's say, an
112.64|6.08| image like that. And there's a person with a tennis racket or
118.72|2.6| something like that. And the description based on that image
121.32|4.28| could be the sequence of text saying a person playing tennis
125.6|6.44| or something like that. Another type of task is many to many.
132.04|3.4| And there are actually two flavors of that. So here, in
135.44|3.56| general, in the many to many setup, the inputs and the
139.0|5.4| outputs are sequences. And it could be a direct or a delayed
144.56|4.12| setup here. So on the left hand side, this is like a direct one
148.68|4.66| where we have an input here and an output there. And then for
153.34|2.52| the next element in the sequence and input and an output and so
155.86|5.02| forth. And this could be for instance, a video captioning. So
160.88|3.9| for instance, if you have a video, which consists of
164.92|3.88| multiple frames, where each frame is an image, so if I go
168.8|4.2| back one time, so each frame would be one to many tasks. But
173.0|2.6| when you think of a video, you have multiple of these frames,
175.88|4.6| it would be then generating a description for each input. And
180.48|4.08| a delayed task would be, for example, translating one
184.56|4.08| language into another language. So you could have a sentence in
188.64|4.24| English, and then you let's say translated to German. So here,
192.88|4.44| this would not be a good case for a direct setup, because you
197.32|4.2| don't want to translate each word, you don't want to
201.6|2.6| translate the sentence word by word, right? Because usually,
205.04|2.44| if you think of like, just taking a dictionary and
208.04|3.2| translating word to word from one language and the other, it
211.24|4.18| usually doesn't give you very readable results, because it's
215.44|3.04| more complicated than that, because different languages
218.48|3.16| have different grammar rules. So you can't just translate word
221.64|3.12| by word, you have to first read the whole sentence, and then you
224.76|5.0| can generate the translation. Alright, so this was just a
229.76|3.36| quick overview of the different sequence modeling tasks. In the
233.12|3.36| next video, we will take a look at backpropagation through time
236.48|2.72| that is how we learn the parameters and then recurrent
239.2|4.32| network. Then we will talk about an improvement of the standard
243.72|2.72| recurrent neural network setup. And then we will take a look at
246.44|4.24| examples here. And these examples will be a many to one
250.68|6.12| examples using word RNNs, where we will train RNN classifier.
257.2|3.68| And yeah, later, later in this class, I'm planning to also have
260.88|3.0| something on generating text, maybe we have to see how much
263.88|3.72| time we have maybe also language translation. Alright, so next,
267.6|16.56| let's talk about backpropagation through time.