start_time|end_time|text
0.78|3.42| Yeah, hi, everyone. So for some reason, the semester went by far
4.2|2.44| more quickly than I thought, or at least far more quickly than
6.64|3.6| it felt like. And yeah, we are already here at our last
10.26|2.98| lecture. And of course, this lecture, like I mentioned, will
13.24|3.2| be optional, because I know you're working very hard right
16.44|3.12| now on your class projects. And I'm also really looking forward
19.78|2.98| to watching your class project presentations and reading your
22.76|4.36| reports on this week and next week. So yeah, like I said,
27.12|3.84| there won't be any quiz or any grading related to this lecture.
30.96|3.68| So you can watch it now, next week, sometime later in summer,
34.64|2.88| or maybe not at all, if you're not interested in this topic. So
37.52|3.76| the topic is recurrent neural networks and transformers for
41.28|3.2| sequence generation. So we covered recurrent neural networks
44.48|3.4| before, but only talking about classification. Now we are
47.88|3.92| focusing on generating new data with recurrent neural networks,
52.08|4.4| then we will add an attention mechanism to improve the
56.48|3.0| sequence generation process with recurrent neural networks. And
59.48|2.76| then we will actually take away the recurrent neural network
62.24|3.56| part and just take a look at attention, which is the the
65.8|3.68| basis behind these transformer networks, which have become very
69.48|3.88| popular, especially in the last one, two years. So with that,
73.4|3.12| um, yeah, let's let's get started with our last lecture.
78.24|4.04| Alright, so here's an outline of the six broad topics I have in
82.28|4.04| mind for today. First, we will start with a general discussion
86.32|3.72| about sequence generation with recurrent neural networks.
90.36|3.36| Before in an earlier lecture, we talked about recurrent neural
93.72|4.48| networks for classification. Now we will learn that we can also
98.2|4.08| use them to generate sequences. And in particular, we will be
102.28|4.28| taking a look at the so called character RNN, a character RNN
106.56|4.48| as a RNN that takes in one character at a time, for
111.04|3.92| example, letters in the alphabet, and can then generate
114.96|4.64| new text from that, then we will learn about a concept called
119.64|3.8| attention. Originally, that was formulated with all four
123.72|4.2| recurrent neural networks, so that at each time step, the
127.92|3.6| recurrent neural network can pay attention to certain parts of
131.52|4.08| the sequence. And this was particularly useful for dealing
135.6|6.24| with long sequences. So then we will learn about some concept
141.84|3.28| called, or the paper was at least called attention is all
145.12|5.0| you need. And this is about using just this attention or
150.12|4.76| self attention mechanism without using an RNN. And the
154.88|3.2| researchers have shown that just using the attention mechanism
158.08|2.28| can get you a really good performance. And you actually
160.36|4.28| don't need the recurrent network for that. So this gave rise to
164.64|3.92| the so called transformer models that we will then talk about.
168.56|4.84| And then I will also show you as one code example, how we can use
173.56|4.28| transformers and pytorch. So okay, these are our six broad
177.84|3.32| topics. Let's start at the top with the next video and talk
181.16|17.6| about sequence generation with recurrent neural networks.