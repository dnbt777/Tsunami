start_time|end_time|text
0.36|2.36| Yeah, hi, and good morning, everyone. I hope you had a good
2.72|3.44| week and worked through all the lecture one material. Yeah, I
6.16|2.84| noticed that there were not that many questions, which I hope is
9.0|2.52| a good sign. So that means hopefully things were not too
11.52|3.56| complicated. And in this second lecture, I want to talk about a
15.08|2.92| brief summary of the history of neural networks and deep
18.0|3.0| learning. And you may wonder, why are we going to talk about
21.0|2.36| the history of deep learning? Why don't we just get started?
23.72|3.48| And I think a good justification for that is really that this
27.2|3.28| will provide you a nice big picture overview of all the
30.48|2.72| different topics in deep learning. So more like from a
33.2|3.52| historical perspective, because that's also somewhat how we are
36.72|3.2| going to talk about that in more detail, like starting with
40.12|4.2| simple things like single layer neural networks, and then because
44.32|3.4| they are kind of limited, we add additional hidden layers. So
47.72|3.76| they become more powerful at solving certain problems. And
51.48|4.04| then we will talk about also some advances like making them
55.52|4.44| work better for image data, like convolution neural networks and
59.96|3.84| making them work better for text data like sequence data, using
63.8|3.24| recurrent neural networks. So in that way, this lecture will
67.04|2.72| provide you with a big picture of all the little topics we are
69.76|3.4| going to cover in this course. So with that, then let me get
73.16|0.6| started.
75.36|3.0| Yeah, and when we are talking about the history of neural
78.36|3.48| networks and deep learning in this lecture, I also want to
81.84|3.94| emphasize again, this is the brief history of neural networks
85.78|2.9| and deep learning. I don't want to cover every nitty gritty
88.68|3.32| detail in this lecture, because otherwise, it would be easily a
92.0|3.36| two or three hour lecture or even longer. So in this way, I
95.36|2.84| just want to give you a short overview of the most important
98.2|4.24| parts that are important for this course. So yeah, I
102.56|2.92| structured this lecture into five parts, starting with the
105.48|4.32| simplest topic, artificial neurons, these are simple,
109.8|3.18| single layer neural networks. However, they have some
112.98|2.84| shortcomings, which are addressed in the multi layer
115.82|3.72| neural networks. So in the second part, we will talk about
119.64|3.06| why multi layer neural networks were invented and why they are
122.7|4.44| useful. And then how we go from multi layer neural networks to
127.14|2.72| deep learning, because multi layer networks have been around
129.86|3.76| since maybe at least 50 years. So deep learning is a more
133.62|4.04| recent term. So how did it evolve? How did multi layer
137.66|3.32| neural networks involve evolve into deep learning? Okay, and
140.98|3.98| then we will talk a little bit about deep learning hardware and
144.98|4.04| software developments, like recent tools that have been
149.22|4.52| developed to make computers that say better head deep learning
153.74|3.64| and also help humans to implement the more and more
157.38|3.2| complicated deep learning models. And then I will also
160.78|3.96| briefly outline the current research trends. Well, I would
164.74|3.34| say more like things that just emerged in the last few years,
168.1|3.96| one to one to three years that have become more popular in the
172.06|23.24| recent conference proceedings and so forth.