start_time|end_time|text
2.96|3.28| Okay, let's now talk about the second subcategory of machine
6.24|3.08| learning. And of course, it also implies it's a subcategory of
9.48|3.44| deep learning. So this is unsupervised learning, which in
12.92|3.32| contrast to supervised learning, does not use any labels or
16.24|3.68| targets. So we don't have any feedback here. And it's more
19.92|5.28| about finding a hidden structure in the data. So in that sense,
25.24|2.84| we can also think of unsupervised learning as
28.08|3.56| representation learning. And this is sometimes also used for
31.68|3.04| dimensionality reduction, it doesn't have to be used for
34.72|3.6| dimensionality reduction, but it's one application of it. So
38.8|3.24| you probably have heard of principal component analysis and
42.04|4.44| other statistics classes, or short PCA, which is a linear
46.48|3.56| transformation technique that rotates the data and then
51.36|5.12| extracts a linear combination of the inputs. So if you
56.48|3.84| consider this example here, there are two features of
60.32|5.44| feature one and feature two, these are our inputs. And here
65.76|5.16| these circles are our data points in this space. And with
70.92|4.32| principal component analysis, we find the eigenvectors of this
75.24|5.88| data set. So in that way, we use these eigenvectors to rotate the
81.12|3.72| data. So we have these two principal components, these are
84.84|3.84| essentially eigenvectors. And usually, we sort them by
88.68|3.54| decreasing order so that we sort them by the eigenvalues by the
92.22|5.18| corresponding eigenvalues. So we usually keep the large eigenvalues
97.4|2.14| or the eigenvectors corresponding to the large
99.54|5.16| eigenvalues. So in this case, on the eigenvalue corresponding to
104.7|4.06| the first principal component is larger than the second one. So
108.76|4.08| in a practical application, we may use this first principal
112.84|4.56| component to have a compressed representation of our data. But
117.4|4.12| yeah, this is a little bit more detail than we need to know. I
121.52|3.24| just wanted to show you an example of unsupervised
124.76|3.52| learning. If you don't know how PCA works, no worries about
128.28|4.44| that. It's just if you know it, this is a nice example of
132.72|2.92| unsupervised learning. Another example of unsupervised
135.64|3.54| learning are auto encoders. And this is something we will be
139.18|3.6| talking in part five of this course. So this will be the
142.78|4.76| first lecture in part five, generative adversarial general
147.54|4.2| generative deep learning. So auto encoders work like this,
151.86|3.72| it's actually a very simple concept, you have input data. So
155.58|6.16| this is your input data. And then you have the output
161.74|4.16| produced by the auto encoder. And the auto encoder consists of
165.9|5.36| two parts, an encoder and a decoder. And first, the
171.26|4.4| dimensionality of the input is very large. And then through
175.66|4.96| hidden layers, there are that's a learned representation that is
180.66|3.2| smaller dimensional. So we call that also the latent
183.86|3.56| representation or feature embedding. This is, let's say,
187.46|7.8| low dimensional. And this is high dimensional. So you can
195.26|3.88| think of each pixel in the image as a feature. So if we have,
199.52|8.86| let's say 100 times 100 pixels, we have 100,000 features as
208.38|3.56| input. So that way, it's a very high dimensional input. And then
211.94|4.16| you can maybe make this like 10 dimensional, it really depends
216.1|2.28| on the data set. But let's say we make this 10 dimensional,
218.84|3.06| this is learned by the encoder, it's a neural network. And then
221.9|4.4| we have a decoder, which undoes that it's basically the opposite
226.46|4.44| taking the low dimensional input, and making the high
230.9|4.2| dimensional, let's say the 100,000 dimensional output. So
235.1|6.52| the goal here is reconstructing the input. So why would we be
241.62|3.44| interested in that? So why is that a useful exercise? But
245.06|2.84| what's the point of this auto encoder, if it's just learning
247.9|4.32| how to reconstruct the input. So the goal is basically what the
252.34|3.56| interesting part is, this latent representation. So you can think
255.9|6.08| of this as a compressed version of your data. So the decoder is
262.02|5.88| able to reconstruct the original image from this small dimension,
267.98|4.68| it means that this this dimensional here is sufficient to
272.66|3.68| encode important information about the data. So it's, you can
276.34|10.6| think of it as a compressed version of the data. So in that
286.94|3.0| way, it's also dimensionality reduction, there's actually a
289.94|3.88| close relationship between an auto encoder and principal
293.82|3.92| component analysis, if the auto encoder consists of linear
297.74|2.6| activations, but don't worry about this detail, we will be
300.34|3.32| talking about auto encoders more in part five, it's just another
303.66|4.72| example of unsupervised learning here. And just for reference,
308.38|4.28| because I already had this nice cat picture, again, how
312.66|3.84| classification works is the majority of deep learning is
316.5|4.08| about classification. So consider we have an input data
320.58|3.6| point here, it's this cat image. And during training, we have a
324.18|5.16| label that's cat here. And then the network produces probability,
329.46|3.52| the probability that this image is a cat. And then we can give
332.98|2.92| it a new data, it could be a dog or a cat, and basically
335.9|2.96| everything, anything, and then it would produce a probability,
339.1|5.12| how likely is it to belong to the class cat, for example. So a
344.22|3.92| classifier is classifying the images, what label they have,
348.38|3.64| whereas unsupervised learning is really very different. It's not
352.02|3.24| about predicting any labels here, it's about learning this
355.3|3.44| hidden representation that can be used to reconstruct the
358.74|5.4| input. Okay, so this was one example of unsupervised
364.14|2.64| learning, the dimensionality reduction or representation
366.78|3.28| learning. Another example of unsupervised learning is
370.06|3.52| clustering, you've probably heard of clustering before, it's
373.86|3.68| assigning a group membership to unlabeled examples. So here,
378.14|3.24| let's consider a data set where I have again, two features x one
381.38|3.24| and x two, I don't have any class labels, I'm just grouping
384.62|3.36| them by similarity. And just by looking at it, you can think of
387.98|2.56| these points here, because they are closer together that they
390.54|3.08| may belong to a cluster, and these belong to a cluster and so
393.62|2.56| forth. Here, it's kind of obvious what belongs to a
396.18|4.24| cluster. In real life, cluster boundaries are sometimes not so
400.42|4.12| clear. It's also usually high dimensionality. So usually
404.58|5.44| clustering is about finding group memberships. So yeah, but
410.02|2.88| here, the difference again, to classification is that we don't
412.9|4.72| know the true labels. So we can also say this could maybe be one
417.62|2.84| cluster, and this could be one cluster, there are some measures
420.46|4.08| for measuring cluster quality, like intrinsic measures,
424.54|3.28| measures, but we don't have like, a real true answer here.
428.7|2.96| Also clustering, I'm just mentioning it here, but it also
431.66|3.0| want to play a role in this course. So we won't be talking
434.66|4.96| about clustering in this class. It's really not the goal of this
439.62|3.12| class here. And it's more like a data mining topic, I would say.
444.54|2.0| Alright, in the next video, let me briefly talk about
446.54|1.16| reinforcement learning.