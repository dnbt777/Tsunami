start_time|end_time|text
1.22|3.86| Yes, so in the previous videos, we talked about the VGG 16
5.08|4.2| architecture and the residual network. Now I want to talk
9.28|3.38| about a topic that is somewhat related to convolutional
12.66|3.12| neural network architectures. It's not super important in
15.78|4.14| terms of, let's say implementing better performing convolution
19.92|3.0| networks, but I think that really helps like solidifying the
22.92|3.36| understanding of how convolutions work. So the first
26.28|3.16| topic I want to talk about is replacing max pooling with
29.44|3.72| convolution layers. And then and then with video after that, I
33.16|3.96| want to talk about replacing fully connected layers by
37.12|3.72| convolution layers. So both videos will be essentially
40.84|3.4| about simplifying a neural network architecture by
44.56|3.28| essentially getting rid of max pooling and getting rid of fully
47.84|4.36| connected layers. It won't result necessarily in a better
52.2|3.52| performance. But it is I think, just an interesting thought
55.72|6.04| experiment. So the first video here, or the two video series
61.76|4.24| will be focused on replacing max pooling. So there's action
66.0|3.6| architecture that is called the all convolutional network. It
69.6|2.48| comes from a paper that is already seven years old. It's
72.08|3.24| entitled striving for simplicity, they're all
75.32|4.32| convolutional network. So here, the authors propose replacing
79.64|4.4| max pooling with a convolution layer that has a stride of two.
84.04|4.2| And this is sometimes also called strided convolution. So
88.24|3.32| now on traditional neural network or convolution network,
91.56|5.68| we have usually a convolution layer with stride equals one.
97.64|7.24| And then we have max pooling, usually two by two max pooling,
105.8|5.2| also with a stride of two. And then we have a convolutional
111.0|4.92| layer again, with stride of one, and we continue like that. And
115.92|4.8| usually, the convolution layers, they preserve the size, because
120.72|4.56| we have a stride of one. And the max pooling will reduce the size
125.44|4.32| to fold, it will have the size. So the size that comes out of it
129.76|3.6| is one half. If we have, let's say a two by two max pooling
133.36|5.48| with a stride of two, and can maybe also write the stone. So
138.84|3.92| the kernel size is usually two by two, and this is stride by
142.76|3.64| two. And this helps us also, you're achieving a little bit of
146.4|3.96| this location invariance. However, it's not essential to
150.36|4.56| have that. So you can technically get rid of this, and
154.92|4.52| then just increase the stride here by two, or here, and you
159.44|4.48| will have the same effect that you reduce the size by one half.
163.92|5.08| So I don't want to go into too much detail here. But if you
169.0|2.36| look at the experimental results, when I recall correctly,
171.36|4.72| they found that the performance slightly decreases when you get
176.08|2.8| rid of this max pooling. However, how you can get an even
178.88|3.88| better performance than before is by replacing this max
182.76|5.4| pooling by convolutional layer. Let me get rid of this two here
188.16|4.36| first. So we have a one here, and then you can have a
192.52|5.8| convolutional layer here with stride equals two. And this will
198.32|3.56| also have this one over half effect that it will decrease the
201.88|3.96| size by half. But instead of using the max pooling, you have
205.84|2.48| the convolution, which has weight parameters, and you can
208.32|3.76| think of it as something like a learnable pooling, at least
212.08|3.16| that's what they argue here in that paper. So it will be of
215.24|2.08| course, a little bit more expensive, because you have no
217.36|3.48| more parameters. But in that way, you can also simplify the
220.84|5.04| network in terms of having it look simpler way, just saying,
225.88|3.56| okay, we only use convolutions, we don't use anything else, if
229.44|2.56| that's desirable. Of course, you still need the activation
232.0|4.84| function, but you don't need pooling layers, for example. I
236.84|4.28| recall there was a talk by Geoff Hinton, I don't recall the
241.12|4.76| exact words. But I remember, Geoff Hinton said something along
245.88|3.28| the lines of that max pooling was one of the biggest mistakes
249.16|3.96| in computer vision, in terms of convolutional networks.
253.6|2.52| Personally, I think it's actually not that bad. Max
256.12|4.4| pooling works quite well. There's not necessarily urge to
260.52|3.24| get rid of this. So it's here more like a thought experiment,
263.76|4.28| how you can potentially simplify a neural network architecture.
269.4|3.76| And then you're talking about simplifying. So you can also get
273.16|3.52| rid of the fully connected layer using convolutions, I will talk
276.68|2.84| more about that in the next video. And another way to get
279.56|3.56| rid of fully connected layers is by using your global average
283.12|4.92| pooling. So I'm not sure if this was the paper that kind of
288.08|4.48| proposed that in the first place. Um, I guess it was not,
292.56|5.08| but this was nonetheless a nice figure. So usually, we use these
297.64|2.24| fully connected layers, like shown here on the left hand
299.88|4.0| side, we use these fully connected layers to map from the
303.88|4.16| convolutional layer onto the number of desired class label.
308.04|4.84| So usually, we have a fixed number of class labels. And in
312.88|3.52| order to get from the feature map size to the number of class
316.4|4.64| labels, we use these fully connected layers. So on the
321.04|3.44| first fully connected layer here would have would have as the
324.48|5.28| input size, the reshaped feature map size. So things will become
329.76|2.72| more clear when I show you the code example. This is something
332.48|2.44| you have seen before, it's not new, it may look a little bit
334.92|3.0| different, because I haven't shown that in a figure here. But
337.92|6.8| this is essentially when we reshape so that it matches the
344.72|4.28| size here and the fully connected layer. And what comes
349.0|3.88| out of here, let's call that H, like some hidden dimension, it
352.88|3.56| goes into the next fully connected layer. And here, the
356.44|6.68| output is then the number of classes. Of course, yeah, this
364.16|3.32| fully connected part is usually very intensive in terms of lots
367.48|4.36| of parameters. You can simplify this by using global average
371.84|7.12| pooling. So here, what you do is essentially, first of all, you
378.96|8.28| assume that the number of channels in the last convolution
387.24|11.56| layer is equal to the number of number of classes. And global
398.8|2.92| average pooling works essentially like that. You have
401.72|3.12| heard about average pooling, which is just taking the average
404.84|4.28| value. And global here means of the whole feature map. So you
409.12|4.2| would technically just use the whole feature map here. And then
413.32|4.08| average over all these values. And this will be then the single
417.4|4.12| value here. And then you do the same thing for the next one. So
421.52|3.68| you just average over the whole feature maps. And that is also a
425.2|3.68| way to get rid of fully connected layers. And by the way,
429.08|2.72| here on the left hand side, this is actually not necessary to
431.8|3.56| have two fully connected layers, you could technically also
435.36|4.4| reshape into this one. And this one takes out the number of class
439.76|5.2| labels. It can be good to have a fully connected layer, it's like
444.96|3.64| additional parameters to learn, but it's also not essential, you
448.6|3.56| can just have all the parameters learned in this convolutional
452.16|3.48| network, and or convolutional part and then have the global
455.64|3.34| average pooling. And I will show you next code example, how that
458.98|5.0| works. And in the next video, I will also show you how we can
463.98|4.36| replace that by an equivalent convolutional operation.
468.34|3.86| Actually, there are two ways to do that. So personally, again, I
472.2|3.76| would say there's no reason to get rid of the fully connected
475.96|4.04| layers, they are just fine. And many or even most architectures
480.0|3.16| use fully connected layers. But if you wanted to, you could
483.16|4.04| technically also get rid of it. All right, let me show you in
487.2|3.8| the next video, a code example of an implementation of this all
491.0|2.72| convolutional network. And I think this will probably make
493.96|3.16| certain things a little bit more clear that I just was drawing
497.12|22.08| here. All right.