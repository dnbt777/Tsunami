start_time|end_time|text
0.2|4.76| All right, let's now talk about the auto encoders. Now, finally,
5.44|3.12| we are starting with fully connected auto encoders,
8.56|3.52| because, yeah, they are the simplest type of auto encoder.
13.12|3.48| And you can think of such an auto encoder as an hourglass
16.62|6.5| shaped multilayer perceptron. So here's a visualization of a
23.12|2.44| very simple type of auto encoder, a fully connected
26.52|3.12| auto encoder. So you can really think of it as a multilayer
29.64|8.2| perceptron. So here, let's start by, let's start by looking only
37.84|6.04| at what I circled here, this is the so called encoder part. So
44.64|3.12| essentially, this is a fully connected layer. So you can
47.76|3.74| think of it in the context of torch, pytorch, you can think
51.5|6.84| of it as a linear layer, fully connected layer with here, five
58.34|5.22| inputs, and two outputs. And then on the other side here, we
63.56|6.66| have a decoder. And the decoder is essentially also fully
70.22|9.82| connected layer. Now with the opposite, two inputs and five
80.06|2.54| outputs. So it's essentially reverse, it's going back into
82.6|7.32| the original dimension. And in between, we have something that
89.92|4.48| we call the hidden units, or sometimes we also use the word
94.4|4.32| embedded space, or latent space, latent representation, for
98.72|3.68| instance, or a bottleneck, because it's like a bottleneck
102.4|6.6| here. And the outputs would be the reconstructed inputs. So
109.0|5.72| what we're doing is we are projecting these features into a
114.72|3.48| smaller dimensional space. And then we are reconstructing them.
118.76|2.48| I will show you in the next couple of slides why that's
121.24|3.28| necessary. Here, it's just the basic setup, I'm just showing
124.76|5.84| how it looks like. And if we would have it set up like this,
130.88|3.36| it would be identical to the principal component analysis
134.24|4.84| that I showed you in the previous video, except with the
139.08|4.08| difference that here, there is no orthogonality constraint. So
143.16|4.16| there is no explicit way to ensure that feature one here and
147.32|4.08| feature two in the embedded space are orthogonal. So that
151.4|3.12| would be different from the principal component analysis,
154.68|3.88| principal component analysis has the constraint that the features
158.88|5.12| are orthogonal, because we are extracting eigenvectors. And
164.0|5.08| another difference here is, I said that we have a fully
169.08|4.0| connected layer and a fully connected layer. But of course,
173.08|2.96| you know, that would not be, I mean, it would be kind of boring,
176.04|3.36| because then we only have linear transformation here. And in
179.4|3.68| practice, it would be more powerful to have a nonlinear
183.08|4.2| transformation or the ability to learn nonlinear transformations.
188.0|3.44| So in practice, we would have connected to this fully
191.44|4.4| connected layer here. And it's, I'm not sure how to visualize
195.84|6.92| this exactly. But this should, this is an activation function
203.56|2.92| here, that should symbolize an activation function. And
206.48|3.0| similarly, here, we would have an activation function after the
209.48|3.68| fully connected layer. So what I mean is, we would have torch
213.16|10.36| dot n dot linear, and then let's say torch dot relu. And I think
223.52|9.36| it's an n functional and functional. Relu can also use a
232.88|6.8| smaller case relu. So we would have linear layer, nonlinear
239.68|3.04| activation function, just like in a multilayer perceptron, then
242.72|2.64| again, a linear layer here, and then we would have another
246.36|5.68| activation function, let's say, torch dot sigmoid. I will
252.04|4.36| explain to you why a sigmoid here, when we talk about the
256.4|3.64| implementation later. I don't want to explain too many things
260.04|2.92| on this one slide, because it's already a little bit crowded. But
263.16|5.32| the bottom line is we have a fully connected layer, and
268.48|3.32| nonlinear activation, fully connected layer, nonlinear
271.8|3.96| activation. And I'm showing you here, something where we only
275.76|3.28| have two units in the center. But this is like arbitrary, it
279.04|4.64| could also be more than two. And of course, it could also be more
283.68|5.24| than one fully connected layer. And nonlinear activation, I
288.92|3.4| could have multiple fully connected layers, the same way
292.32|2.6| you can have a multilayer perceptron with one hidden
294.92|3.1| layer, two hidden layers, three hidden layers, and so forth. So
298.02|3.7| the number of hidden layers is also arbitrary here, I just try
301.72|7.48| to keep it simple to fit it also onto the slide. So yeah, like I
309.2|2.98| said before, if we don't use the nonlinear activation function,
312.18|3.9| this would be similar to principal component analysis. But
316.08|3.34| in practice, we would use nonlinear activation functions.
319.44|3.24| So it's not like principal component analysis, it's
322.68|3.08| actually more powerful than principal component analysis,
325.76|8.32| because we can learn nonlinear transformations. Yeah, the one
334.12|3.96| missing piece I didn't mention in the previous slide is what
338.08|2.96| the point is of having the inputs and then the outputs,
341.04|3.7| which are the reconstructed inputs, this is so that we can
344.74|4.98| learn this transformation. So what we are doing is we are
349.72|4.2| computing the difference between the inputs and outputs. And we
353.92|3.72| use that for back propagation, so that the auto can auto
357.64|7.28| encoder can learn to do a good compression of the data. So what
364.92|6.32| happens is the auto encoder goes from this large dimensional
371.24|4.48| input to this small representation to this embedded
375.72|5.04| space where there's a smaller, let's say this is large, this is
380.76|7.28| smaller, and it's large again. And how do we learn that? How do
388.04|5.3| we know that this is a good representation? I mean, we could
393.34|3.3| just arbitrarily come up with two numbers, how do we know it
396.72|3.42| represents our original data? Well, how do we know that's a
400.14|6.9| good way of compressing this data? So this is why we have to
407.04|4.4| project it back here. So we are projecting back into the original
411.44|3.84| space. And then we can compare. So then we can compare the
415.28|3.8| outputs to the inputs. And what we want is, we want them to be
419.12|4.16| similar. And if they are similar, so if I have input
423.28|2.88| data, and I'm able to reconstruct this output data,
426.68|4.64| or I have my output similar to the input, that means that my
431.64|3.88| embedded space here, my latent representation has to have
435.52|4.12| important information captured about my input data. Because if
439.64|4.12| this in the center would not contain any useful information,
444.04|3.44| then we would not be able to reconstruct the inputs via the
447.48|3.64| outputs. So this is really the setup is to ensure that the
451.12|5.22| auto encoder is indeed able to retain the most useful
456.34|5.7| information in this embedded space. And there are different
462.2|2.52| loss functions for that. And of course, the simplest one would
464.72|4.68| be just the two difference or mean squared error. So we are
470.24|6.48| just computing for each input here. So we have five inputs, and
476.72|3.74| also five outputs, we would be comparing comparing them one by
480.46|4.62| one. So let me use a different color, maybe. Which color should
485.08|7.72| I use since pink. So we would compare this one, this one, this
492.8|8.04| one, this one, this one, sum them up here. And then we could
501.02|5.46| also average like one over m, let's say m for the
506.68|6.2| dimensionality, like the mean squared error. If we would
512.88|10.72| compute it as one over m. Okay. Um, yeah, this is how the basic
523.64|5.12| setup of an auto encoder looks like. Yes, we have a question
529.16|3.48| that if we can achieve the same thing that we can achieve with
532.64|3.5| an auto encoder, just using PCA, which is essentially a linear
536.14|3.3| transformation, kind of matrix factorization that is very
539.44|4.38| efficient, more efficient, in fact, then it's a using back
543.82|2.9| propagation with stochastic gradient descent to train the
546.72|3.16| auto encoder. Why do we bother about auto encoders in the first
549.88|4.72| place? Well, I mean, like I said before, principal component
554.64|2.76| analysis is a linear transformation. And auto
557.4|2.96| encoders can be more powerful than that we can learn non
560.36|3.72| linear transformations. And for instance, if we work with image
564.08|3.08| data, we can swap out the fully connected layers, let's say with
567.16|3.36| convolution layers, and so forth. So we have just more,
570.76|3.92| let's say, opportunities to make good models for different types
574.68|5.44| of data that is more complicated. All right, so also
580.12|3.96| your potential applications of this auto encoder. So in
584.08|2.88| practice, of course, there is no point in let's say, just
587.24|3.56| reconstructing the image, because, well, if we already
590.8|2.76| have the input image, why would we be interested in that
593.8|2.84| reconstruction. So here, the reconstruction in the regular
596.64|6.16| auto encoder is only used for computing the mean squared error
602.8|6.96| loss for learning the embedding space here. And after training,
609.76|4.16| we can, after the auto encoder has been trained, we can, yeah,
613.96|4.36| we can remove this part, I will show you also in a code example
618.32|4.12| later, how that works, we can remove that part, and then only
622.44|5.48| use that embedding as extracted features. So for instance, some
627.92|4.64| people, if we have a large data set may train auto encoder on a
632.56|3.96| large data set, generate all the embeddings and then try out
636.52|3.0| whether let's say training a classifier on top of it hurt
639.52|2.96| helps like using traditional machine learning, like support
642.48|3.52| vector machines, k nearest neighbors, random forests, of
646.0|4.52| course, you can also use this directly, like a multi layer
650.52|3.48| perceptron with one hidden layer, you have, let's say you
654.0|2.76| make this a bit bigger, and then you have the output layer, you
656.76|2.52| can have a multi layer perceptron. But if you don't
659.28|2.4| want that, you can also yet train the auto encoder on a
661.68|2.8| large data set where, where you don't maybe have label
664.48|3.64| information. So you can apply this to a large unlabeled data
668.12|3.12| set, because auto encoders don't require label information,
671.48|3.7| whereas the normal multi layer perceptron would require that. So
675.18|3.9| for instance, you can, similar to transfer learning, train your
679.08|4.6| auto encoder on a very large data set, then it learns how to
683.68|3.64| extract good features. And let's say you only have a you have only
687.32|4.4| labels for a subset of that data. For that, then you can use,
691.8|3.28| let's say traditional methods and train those on the
695.08|5.52| embeddings. You can also use the latent space. So the lower
700.6|2.96| dimensional space for visualization purposes, if it's
703.56|3.16| two dimensional, for example. So for instance, if you want to do
706.72|4.56| exploratory data analysis in a scatterplot, but of course, it's
711.28|3.88| not restricted to do dimensions, you can also have a larger. So
715.16|2.92| for instance, if you want to be doing clustering or something
718.08|3.28| like that, and the original input space is too large for
721.36|3.36| computing pairwise similarities, you may also want to consider
724.8|3.4| using this for dimensionality reduction. However, I must say
729.04|3.08| that in a real world application, I would probably not
732.12|4.12| recommend an auto encoder for dimensionality reduction for
736.24|3.12| nonlinear transform, dimensionality reduction, there
739.36|3.12| are better techniques. For instance, if you are interested
742.48|3.6| in visualization, let's say an exploratory data analysis,
746.56|2.36| converting your data into a two dimensional space for
748.92|3.6| visualization as a technique called t distributed and
752.52|4.28| stochastic neighbor embedding t sneak, or there's also another
756.8|2.6| technique called you map, which can be also used for
759.72|2.88| dimensionality reduction, these are a little bit more, let's say
762.64|3.44| robust. So these are better techniques for dimensionality
766.08|3.32| reduction. But yeah, auto encoders are still very good
769.44|5.0| techniques for let's say, learning on unlabeled, large
774.44|4.12| unlimited data set, and then having something as an input to
779.48|3.96| traditional machine learning classifier. But of course, there
783.44|3.04| are many more interesting aspects and applications of
786.48|2.92| auto encoders, which we are not covering this first lecture. But
789.72|2.16| in the next lecture, for example, we will be talking
791.88|2.56| about a variational auto encoders. And this auto
794.44|6.96| encoder here would form the basic basic model behind this
801.4|3.52| variational auto encoder. So learning about this auto encoder
804.92|3.92| here will help us understand how variational auto encoder works
808.84|5.16| next lecture. So here's an implementation of a simple auto
814.0|4.52| encoder, just using fully connected layers. So using
818.52|6.28| applying it to the MNIST data set. So on the left hand side, I
824.8|4.2| have a handwritten digit, the handwritten digit seven. In MNIST
829.0|4.76| it's a 28 times 28 dimensional image. So I'm reshaping this to
833.76|4.92| a 784 dimensional feature vector. And this goes into my
838.88|4.28| fully connected layer that is followed by a leaky relu. So
843.16|3.24| this fully connected layer compresses the input image from
846.4|3.88| 784 to 32 dimensions. So it doesn't have to be two
850.28|3.76| dimensions, you can also have more than two dimensions, of
854.04|5.08| course. And then I'm having I'm using another fully connected
859.12|6.36| layer that converts the 32 dimensional hidden space here
865.72|4.0| back into a 784 dimensional representation. And this fully
869.72|3.88| connected layer is followed by a sigmoid activation. Why sigmoid
873.6|3.9| activation? That's because I normalize the input images, the
877.5|4.22| pixels, such that they are in a range between zero and one. So
881.72|3.36| the sigmoid will also output values in a range between zero
885.08|4.84| and one. So I'm applying the sigmoid to get the same values
889.92|5.92| as the input has. So the same range of pixel values. So this
895.84|3.32| will also be zero between zero and one. And then I can compute
899.44|2.44| the mean squared error or minimize the mean squared error
901.88|7.28| between the pixels here. So here is the is a snapshot of the
909.16|5.88| original m list images. And at the bottom are the reconstructed
915.04|2.8| ones. And you can see, they're not perfect. There are some
917.84|5.2| artifacts here. But overall, it looks pretty good. So our very
923.04|3.8| simple auto encoder is able to retain enough information in
926.84|4.36| this 30 dimensional space to reconstruct the original images.
931.2|4.08| And if you think about it, 32 is a proxy, approximately like 20
935.28|6.4| times smaller than our 700 dimensional input. So I was able
941.68|4.88| to, here, reduce the side 20 fold. If you're interested in
946.56|5.12| this code, it's here, I have it here on GitHub, I won't walk you
951.68|3.68| through this code. Because in the next videos, I want to show
955.36|2.88| you a convolution auto encoder, which is slightly more
958.24|3.48| interesting. And I implemented some code for this class also to
961.72|3.44| make this more interesting. So we will be focusing on a more
965.16|2.44| interesting example of a convolution auto encoder. But if
967.6|3.6| you're interested here, you can also find the code for the simple
971.2|2.68| auto encoder, which is essentially very similar to a
974.0|4.96| multi layer perceptron. Okay, so in the next video, let me then
979.12|4.08| introduce some concepts about convolution auto encoders. It
983.2|4.06| involves transposed convolutions and deconvolutions. It's just a
987.26|4.44| different way name for, for the same thing. And then we will
991.7|26.88| after this next video, we will implement this in pytorch.