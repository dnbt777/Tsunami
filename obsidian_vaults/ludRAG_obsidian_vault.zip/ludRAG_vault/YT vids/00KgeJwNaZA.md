start_time|end_time|text
1.74|3.58| Okay, now in this video, let me explain how we train Adaline
5.32|4.56| using the concept of automatic differentiation and pytorch. So
9.88|4.6| I prepared a code notebook here, where I have three different
14.48|4.16| implementations of Adaline. First is the manual implementation
18.64|4.44| that we saw last week, then I have an implementation using
23.08|2.8| the grad function that I just explained in the previous video.
26.28|3.56| And then I show you an even more automatic way using the
29.84|4.4| backward function that pytorch automatically creates based on a
34.24|3.92| forward function. And that is also a topic I will then dive in
38.52|3.16| more in the next video. So here, I want to just show you how it
41.68|3.28| works. And then next video, I explain it a little bit more.
46.2|4.28| Alright, so starting again with watermark checking our versions
50.48|3.6| here, I can also make this a little bit bigger. So here again,
54.08|3.88| this is our Adaline model that we talked about extensively last
57.96|3.92| week, where we have multiple inputs, the weights, the net
61.88|4.28| input function, the activation function is just a identity
66.16|2.56| function, and then the threshold function for prediction.
70.72|3.12| Alright, let's import some libraries, we will be using the
73.84|2.52| grad function I explained in the previous video, and we will also
76.36|3.96| make use of the functional API. Again, the function API will be
80.32|5.4| a more discussion topic in more detail in the next video. So we
85.72|3.02| will be working with the iris data set again, because it's
88.76|2.88| simple. So we can then focus more on the code rather than on
91.64|5.68| the data set. So here we have no data set. And this is exactly
97.64|3.16| the same as we have done in the previous week week. So if you're
100.8|3.6| unsure how this works, this is exactly the same code as last
104.4|4.92| week. So you can go to the video from last week. So everything is
109.32|3.96| explained in that video last week. Alright, so also just to
113.28|3.8| recap, this is exactly the same code that we were using last
117.08|2.92| week. So here, this is our airline implementation, where we
120.0|4.24| first initialize the weights and the bias, we have our forward
124.24|3.12| function that computes the net inputs, and then the activation.
128.4|3.84| And then we have the backward function where we computed the
132.24|4.14| gradient by ourselves. So what I mean by that is we derived it in
136.38|3.18| the slides, we had a slide on how we derive that gradient. And
139.56|3.12| then here, this would be the equivalent code implementation
142.68|5.96| of that. Yeah, we have some training and evaluation wrappers
148.64|3.72| just to make things a bit more convenient to look at. So we
152.36|3.4| have a loss function, then we compute where we can plot the
155.76|3.32| loss function during training. So here in our training function,
159.08|3.88| again, like in last week, we have a cost list with where we
162.96|4.12| compute the cost, which is actually the loss over the epoch
168.0|4.48| or mini batch, actually. So let me see. So what we do is we
172.48|4.4| iterate over the epochs. So for each epoch, we shuffle the
176.88|4.66| data set. And then we create the mini batches. And for each mini
181.54|4.0| batch here, we perform the forward pass that is like
185.54|5.64| predicting the class labels. And then we compute the backward
191.18|5.72| pass. So here, this is computing the negative gradients, the
196.92|3.7| negative gradient of the loss with respect to the weights and
200.62|5.0| the bias. And then we update the weights. So we updated by
207.34|3.6| Yeah, we have the original weight, we updated by adding the
210.94|4.32| negative gradient multiplied with the learning rate. Why for
215.26|2.44| some reason commented that out? Yeah, I think it was just too
217.7|3.36| much output. And I wanted to keep this notebook short,
221.06|2.56| because there will be other codes. And it was too long.
223.62|3.0| Otherwise too detailed. We don't need that level of detail here.
226.62|4.62| Here, we are just printing the number of epochs and the loss
231.24|4.48| for each epoch. So let's define it. So note, this is not running
235.72|2.68| any code, because it's just setting up the functions here.
240.84|7.2| And then here, we are defining or initializing the model. So x
248.04|3.16| train size, this is the same, I could have used shape, this is
251.2|4.28| the same as shape. So it's the number of features. It's the
255.48|7.32| same as shape one, some more features. Then yeah, here's our
262.84|6.52| data sets. input, the number of epochs 20 learning rate point or
269.36|3.92| one, the random seed, so we can reproduce these results. So that
273.28|2.6| means if someone else like you runs this code, you should get
276.44|4.24| exactly the same results. And then the mini batch size, how
280.68|4.48| many mini batches we use in each iteration, not the random seed
285.16|3.28| here is only used for shuffling the data set, right? If I go up
288.44|5.16| again, this is being used when we shuffle the data set. So if
293.6|2.52| you change the random seed, you might get some different
296.12|6.12| results. Alright, so let's do this. So this is training and
302.24|3.64| this is super fast. So you can see the outputs are immediately
305.88|3.8| here. Usually for deep learning, it would take maybe depends
309.68|2.56| really, but it could take 10 minutes per epoch can take an
312.24|3.36| hour per epoch depends really on the data set. So let's take a
315.6|5.8| look at the loss. Okay, this is converging, it's not converted,
321.4|2.76| but doesn't really matter. Because here, the point is
324.16|4.68| really explaining the automatic gradient computation in the next
328.92|4.76| code. I want to why I'm showing you this is so that you can
333.68|3.88| compare the automatic way of pytorch of doing this with this
337.56|2.8| one, and you will see it's exactly the same result. So just
340.36|5.08| to show you that our conceptual thing thing that we did manually
345.44|3.56| last week is actually correct. And while other way around that
349.0|4.16| pytorch is actually correct. Alright, so here, that's the
353.16|4.96| predictions for computing the test and training accuracies.
358.36|4.16| Also, it's essentially the same concept as last week. So nothing
362.52|5.96| new here. Now, after we just recapped, yeah, the manual
368.48|2.36| implementation of the underlying that we talked about last week,
371.0|4.52| now let's do this semi automatically or semi manually
375.86|5.42| using this autograd API from pytorch. So there will be only
381.28|4.16| very subtle changes. So this one is exactly the same as before.
387.76|3.88| Now, the only difference is in the train method. So let me
391.68|3.84| scroll to the relevant part. So notice everything here is the
395.52|3.72| same. What has changed is now how we compute the gradients
399.24|4.64| here. So now we use this grad function to compute the
403.88|3.76| gradients of the loss with respect to the model weights.
409.0|4.64| And then we retain the graph. Remember from last video, this
413.64|4.04| is if we need again gradients, we need to retain it one more
417.68|3.72| time. So because we want to compute the bias here, too. And
421.4|3.84| then here, we don't care because in the next round, it will be
425.24|2.88| constructed from scratch the graph. So here, we don't need to
428.12|5.12| retain the graph. Why the minus one. So that is because we want
433.24|3.4| to have the negative gradient, because then we, we add the
436.64|3.28| negative gradient to the model weight. We could also just skip
439.92|5.28| this step. Of course, right, we can do it like this, and add a
445.2|6.24| minus here. Oops, same thing. But just to keep it consistent
451.44|2.56| with the implementation that we had before our manual
454.0|3.44| implementation, I wanted to make it as similar as possible.
458.44|5.24| Alright, so the only difference to before is now that how we
463.68|2.32| compute the gradients, notice that there is no backward
466.0|4.92| function. Now, if I scroll up again, show it to you again, in
470.92|4.52| the previous time, we had backward here to compute the
475.44|4.16| gradients where backward was our manual way of computing the
479.6|3.4| gradients. Now, we do it automatically. See, this is
483.0|3.52| actually because of this scrolling is why I commented on
486.52|2.16| the logging because otherwise, it would be a lot of stuff to
488.68|6.68| scroll here. All right, um, back to the thing here. So yeah,
495.36|2.84| here, here, this is the difference. Instead of using
498.24|2.72| backward with our manual gradients, we now use this grad
500.96|4.2| function. Except that everything should be the same. I made a
505.16|4.0| small modification here to the logging. Notice that I use with
509.16|4.08| torch no grad, because when we just do some logging here, we
513.24|3.0| don't do any model training here, we don't need to
516.24|3.24| construct the graph, it would be computationally wasteful to
519.72|3.8| build the graph, because otherwise, it will create the
523.52|4.84| graph in our forward method. So here, this one, because we have
528.36|3.68| set a request gradient to true, if this is set to true, every
532.04|3.36| time this is used, it will create this computation graph.
535.4|4.68| Okay, so here, the computation graph gets destroyed, because we
540.08|3.68| don't have retained graph to true. So every time we do the
543.76|6.88| for loop here, it makes a new graph. Here, we don't call grad,
550.68|3.8| right. So here, it would create a graph, but we don't need this
554.48|2.68| graph. And it would be just computationally wasteful. It's
557.16|2.72| just a good habit. If we don't need a graph, if we don't need
559.88|4.56| to compute gradients here for logging, then we can use this
564.44|5.6| with torch, no gradient context, and everything that is indented.
570.36|5.0| So everything that is below here does not construct a computation
575.36|3.12| graph, it's just to save computational resources. Here is
578.48|3.04| such a simple code, it doesn't matter. But it does matter for
581.52|5.8| deeper neural networks. All right, so defining it, then
587.32|2.68| again, same as before, we initialize the model, notice
590.0|4.68| that there's no other lines to instead of a line one, then
594.72|4.84| training the model. So we can see again, the loss goes down,
599.6|4.08| dot up, dot up, dot up. And let's take a look. plot should
603.68|5.24| look exactly like before. Let's compute the training accuracy
608.92|3.52| and test accuracy. Also, the same as before, you can actually
612.44|5.64| double check, these are exactly the same numbers as the ones
618.08|4.72| here. All right, so this is now doing things more conveniently,
622.8|4.04| right? So, because you can think of it, um, if I scroll up again,
627.12|2.24| you don't want to scroll that much. But I think it's useful
629.36|2.96| here in this case. So if this forward one would be a very long
632.32|2.76| complicated function using multiple layers and stuff like
635.08|4.44| that, you can already see how it's convenient to not implement
639.52|3.84| this backward method by hand by deriving that by hand, right? I
643.36|3.64| mean, it's a good exercise, still, but it is also very
647.0|3.32| it is also very error prone for deep neural networks. So it's
650.32|2.8| better to rely on these automatic functions. However,
653.16|3.0| there is an even more convenient way to do this that I want to
656.16|5.48| show you now. So this is usually how people most people use
661.64|5.52| pytorch. So you can actually use the so called linear layer
667.16|5.16| here. So this is as I explained last week, this is computing the
672.32|6.84| net input. I have now an additional step. So here I have
679.16|6.2| this zero. So what's going on here? So usually when we use
685.36|4.52| torch dot n dot linear, it's thinking we want to implement
689.88|2.6| some multi layer neural network, because that's what most people
692.48|4.04| do in deep learning. And then it will initialize the weights to
696.52|3.56| small random numbers. This would be also totally fine for our
700.08|4.16| edeline here. However, to make our edeline combination here
704.24|3.76| more comparable to the previous two codes I showed you before
708.0|3.36| where we use zero weights, I also want to use zero weights.
711.4|4.76| So I'm setting these weights to zero here. So just to show you
716.16|7.68| what I mean, let me just do this. Alright, let me just use
723.84|5.84| this. And then I should have of course, assigned it to something,
729.92|3.76| you can see that these should be small random values, see that.
734.08|9.0| And if I set them to zero, they will be oops, the problem you
743.08|5.16| have to detach it, it doesn't like it. If you have a variable
748.24|6.16| defined, and you want to modify it, like in place, leaf variable
754.4|4.4| means a leaf, it's like an endpoint. And it doesn't like it
758.8|3.04| if you modify it with an in place operation, because it's
761.84|2.0| also error prone, this is usually something you don't want
763.84|3.92| to do in a network. So it's kind of warning you. So you have to
768.4|5.36| detach it from the graph here. Oops, there we go. So now I set
773.76|5.04| it to zero. Also, notice I didn't, I didn't do this here
778.8|4.24| equal to, because there's a convention in pytorch, there are
783.04|3.28| these so called in place operations, these with an
786.32|5.6| underscore, they do an operation in place. So there's no return
791.92|3.84| value, actually, it just takes the existing vector and over
795.76|3.44| writes it. This is also done for computational efficiency,
799.2|5.12| because imagine you have a very large vector. And then you want
804.32|3.52| to override it with all zeros, you would have to memory briefly
807.84|2.8| create two vectors, you have the original one, then the zero
810.64|2.96| vector and the zero vector overrides the original one. So in
813.6|2.64| a brief moment in time, you would have two vectors in
816.24|2.56| memory, and it would take twice as much memory. So if you do
818.8|4.64| this with large matrices, it can in certain GPUs be a problem.
823.44|2.4| I mean, it's just wasteful. So in this case, these underscore
825.84|5.04| operations, modify something in place. But yeah, I'm getting
830.88|4.48| sidetracked here. Let's go back to what's going on here. So here
835.36|5.2| I'm now defining the forward path, pass, sorry, the weights
840.56|4.24| used in the forward pass using this linear wrapper. We talked
844.8|4.32| about this briefly last week. And then so I'm signing it to
849.12|3.52| self dot linear. And then I'm using it in the forward method
852.64|5.2| here. So here, computing the net inputs using self dot linear,
858.72|2.88| then I'm computing the activations, activations, that's
862.96|3.6| nothing an identity function. So I'm just overwriting it. And
866.56|4.8| then I'm returning it. Alright, so here, now I'm training it
871.36|6.64| again. Notice, the only things I define are this weight layer
878.0|3.76| here. And this forward method here, I'm not defining anything
881.76|3.84| else. In the train function, this is fundamentally very
885.6|5.68| similar to before. Except now, see, I'm computing the loss
891.28|5.76| here. So I'm computing loss function, I'm using here, the mse
897.04|3.28| loss, I could use my own loss. But like I mentioned, if there
900.32|2.72| is a function that is already implemented in pytorch, I
903.04|2.64| recommend using that one over your own implementation, because
905.68|2.96| it's usually more efficient. They use some tricks under the
908.64|3.52| hood, also c++ code to implement things more efficiently. So
912.16|7.84| here, we are using this mse loss. And then we are resetting
920.0|4.56| the gradients using zero grad, and calling backward. So
924.56|4.08| multiple steps that are new now that are happening here. So
930.24|4.08| calling forward to predict the outputs, the class label, so
934.32|3.2| compute outputs, then it's actually not the class name, it
937.52|3.28| is the net inputs, the because it's before the threshold
940.8|5.68| function, let me scroll up one more time. So we are we are
946.48|2.88| here, this this value here, we are computing this value.
952.0|6.16| Alright, we're computing this value y hat. Oh, this is the
958.16|6.0| previous one, sorry. Okay, here, for it. So we are computing
964.16|4.88| this y hat value, then we compute the prediction error,
970.24|5.04| using the mean square error here. Notice that I'm resetting
975.28|2.64| gradients from the previous iteration. So this will be
977.92|5.2| running multiple times. And there is how pytorch works,
983.12|4.48| there is a dot grad attribute that will be set for these
987.6|4.56| variables after each iteration. And we are resetting it,
992.16|5.04| otherwise, you would be accumulating the gradients. So
997.28|2.56| usually, it's not the case in deep learning, we usually
999.84|3.6| compute the gradients, update the weights, then do the next
1003.44|2.48| round, compute the gradients updates the way update the
1005.92|2.64| weights. But there are some applications where we want to,
1008.56|3.68| for example, not update the weights after each epoch, for
1012.24|2.64| example, we can do two forward passes and then update the
1014.88|4.8| weights. So this would be possible, we could, for example,
1019.68|3.76| skip zeroing the gradient. So we, we could technically, for
1023.44|5.2| certain research experiments, accumulate the experiments. So
1028.64|2.72| this is why pytorch has this implementation to allow certain
1031.36|3.28| researchers to do some more flexible research, but it also
1034.88|4.48| is a normal user forces us to remember to zero the gradients.
1040.32|4.16| So here, the opt so we are also using, I should say an
1044.48|5.52| optimizer, stochastic gradient descent, that is more automatically
1050.0|6.96| than what we have done before. So prediction, computing the
1056.96|3.12| loss zeroing the gradients from the previous round, calling
1060.08|4.4| backward that computes our gradients, and then updating the
1064.48|4.96| weights. So this is usually a typical pytorch workflow, that
1069.44|3.12| is what people do, usually in practice, and what we do when we
1072.56|5.68| do implement neural networks. In the previous round, we had it
1078.24|7.12| manually. So we had computed forward, and then we had our
1085.36|3.6| loss function. But then we computed here, the negative
1088.96|4.56| gradients, and we did the stuff here, the update automatically,
1093.6|5.12| this is what in our code information below is equal to
1098.72|7.04| optimize step. So how does optimizer know that we want to
1105.76|4.0| update the weight and the bias? Well, that is because we feed
1109.76|6.08| it with the parameters I will show you. Here we are, we
1115.84|3.36| provided TSC with model parameters. So there's also a
1119.2|3.76| concept, if you use these functions like torch that linear,
1123.2|3.6| these will be registered as model parameters in this module
1126.8|4.32| here. So here, this will automatically contain the model
1131.12|5.76| parameters, let me actually show it to you. So here we have,
1136.96|3.28| where was it first grow up, we haven't actually defined it yet,
1140.24|4.4| sorry. So let me execute this part first, and then I will show
1144.64|6.64| you more details. All right, so I already ran this, so
1151.28|4.08| everything should work and actually also, it's fine. So here
1155.36|8.16| you can see, okay, maybe can't because it's a generator. So you
1163.52|5.2| can see there are these two entries, one is actually the
1168.76|2.6| weights, and one is the bias. So they are registered under the
1171.36|3.6| parameters. So these are really the values that we have as
1174.96|9.12| model, dot FC dot weights. What was it? How did we save it one
1184.08|7.52| second, or linear, we call it linear, not FC. Okay. So you can
1191.6|5.2| see, these are corresponding to this one. And this one is
1196.8|4.08| corresponding to this one. So this is how the optimizer knows
1201.24|5.28| what to update when we call step. I can maybe also show you
1206.52|7.2| on model linear, weight, there should be a grad. So this is the
1213.72|3.92| gradient, the gradient from training it. So from the
1217.64|4.68| backward pass, and if we call backward, the next round, it
1222.32|7.12| will add to this gradient, so it will grow. So this one should
1229.44|10.2| actually make it zero. Let's execute this doesn't work. Oh,
1239.64|5.08| it's, it's because it's defined outside this outside this
1244.72|5.64| function here. That's a bit unfortunate. Um, yeah, it would
1250.36|4.64| be tricky to show it to you here. Maybe I can can do it
1255.0|24.68| differently. I can do it here before. After. All right, it's
1279.68|3.28| actually none. Also, okay, no, it's something else. So I think
1282.96|3.48| the first round, so you can see it first, it's this and then
1286.44|4.68| after zero, this and then it's this and this, you can see how
1291.12|4.52| it's computed, then zero to computer zero. If I don't do
1295.64|6.2| this one, it will just grow larger and larger. You can see
1301.84|3.32| that. Maybe not because it's positive or negative, but you
1305.16|4.96| can see how large it becomes. That's actually not good. So
1310.12|4.8| here, the model wouldn't learn anything useful, I guess. Let's
1314.92|3.36| see. Yeah, you can see it's not learning anything useful. So
1318.28|7.8| let's fix that. All right, let's fix this and run it properly.
1330.88|5.68| All right. And you can see this is the same as before. When I
1336.56|3.52| compute the test and training accuracy, look at these values,
1340.36|6.2| values 92.86% and 93.33%. And this is exactly the same accuracy.
1346.56|8.12| Let me scroll up to our manual implementation is exactly the
1354.68|4.28| same number here. So you can see pytorch is performing exactly
1358.96|3.12| the same thing we do manually. So our manual derivatives are
1362.08|3.96| correct. And vice versa pytorch is also correct. So I will talk
1366.04|4.0| about this more in the slides explaining this again. But I
1370.04|5.08| think if this is still unclear, maybe focus on this part. So
1375.12|3.56| this is really how we use pytorch like forward, compute
1378.68|5.44| the loss, zero, the gradients backward update. And this is
1384.12|2.68| essentially a pytorch in a nutshell. And we can use this
1386.8|3.92| API for all types of models. So the only difference is really
1390.72|5.28| here when we define the weight parameters and the forward pass.
1396.24|3.0| So this is the only difference, the training loop is essentially
1399.24|4.72| always the same. All right, then let me stop this video, and then
1403.96|3.0| go back into the slides and explain to you a little bit more
1406.96|15.0| about the pytorch API.