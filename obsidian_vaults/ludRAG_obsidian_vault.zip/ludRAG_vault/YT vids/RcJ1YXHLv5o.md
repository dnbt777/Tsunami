start_time|end_time|text
5.0|6.08|and hello everyone here so today for our
8.0|6.0|speaker we have Albert Jang from mistal
11.08|5.119|AI um and also from the University of
14.0|4.96|Cambridge nice to meet you and thank you
16.199|5.881|for uh coming today um and being our
18.96|6.52|speaker so Albert is a AI scientist at
22.08|5.199|mistal Ai and the final year PhD student
25.48|4.68|at the computer science department of
27.279|4.601|Cambridge University he works on on
30.16|4.719|language model pre-training and
31.88|6.24|reasoning at myal Ai and language models
34.879|5.52|for mathematics at Cambridge um so thank
38.12|5.52|you for coming today and today Albert is
40.399|6.601|going to talk about mistol um a sparse
43.64|8.52|mixture of experts language models and
47.0|8.079|yeah I think I will now uh leave it for
52.16|5.12|Albert hi uh Emily thanks uh thanks for
55.079|5.16|the really nice introduction um so let
57.28|4.56|me share my screen here yeah so yeah
60.239|3.96|thanks very much again for the really
61.84|4.8|nice introduction Emily um so today I'll
64.199|6.361|be talking about demystifying mixure of
66.64|6.519|experts and my name is Albert I'm
70.56|3.919|scientist at mroi and a PhD unit at
73.159|3.241|University of
74.479|3.841|Cambridge so the content you'll be
76.4|4.56|hearing today uh first I will talk about
78.32|5.08|the architecture of uh first the dence
80.96|4.36|Transformers architecture uh just to
83.4|5.719|review and also the sparse mixture of
85.32|5.439|experts or smoes um so after that I'll
89.119|4.28|be talking about inter Ting sparse
90.759|5.081|mixture of experts models and the
93.399|4.241|majority of this slides will be based on
95.84|4.08|the mixture of experts paper that will
97.64|4.56|put out early uh earlier this year in
99.92|4.08|January and throughout this talk if you
102.2|3.32|have any questions feel free to raise
104.0|4.32|your hand and I'll be really happy to
105.52|5.32|answer and also uh I'll be posing some
108.32|5.04|open research questions uh because the
110.84|4.04|these things are really uh very much on
113.36|3.2|the research and we hope that more
114.88|3.08|research can be down and so the open
116.56|3.919|source Community can really enjoy the
117.96|4.4|benefits okay let's get started
120.479|4.761|um so first let's talk about talk about
122.36|5.679|architecture uh we can first talk about
125.24|4.159|the dense Transformer architecture that
128.039|4.001|a lot of people must have already talked
129.399|5.681|about um but here I want to focus on the
132.04|5.96|Mi mistol 7B model which is the dense
135.08|6.08|Transformer um the the the main
138.0|5.319|difference between the mro 7B model and
141.16|3.92|the rest I guess the rest of the uh Dan
143.319|4.041|transform models is that it has group
145.08|4.08|CER attention uh which means which is
147.36|4.519|different from the multi-ad and multier
149.16|4.84|attention some in between so for multi
151.879|4.561|had attention you have the same number
154.0|5.36|of uh you have same the same number of
156.44|5.6|keys queries and values and for multier
159.36|4.92|attention you have a lot of CES and just
162.04|4.559|one key and one value and group CER
164.28|5.84|attention are sort of in between and you
166.599|5.0|have a lot of queries uh much less keys
170.12|4.56|keys and
171.599|4.601|values also the difference uh also
174.68|4.36|there's another difference in the
176.2|4.28|attention we're using for uh mral 7B
179.04|4.24|that is we're using sliding window
180.48|4.96|attention the idea being uh for some of
183.28|5.239|the lower layers of the Transformer the
185.44|6.439|tokens um uh so so for for each token
188.519|5.64|position they they attend to uh a
191.879|4.521|relatively short span of previous tokens
194.159|4.041|and as you go deeper in the Transformer
196.4|4.04|the later token positions will get
198.2|5.64|information transmitted from the earlier
200.44|5.76|token uh positions and neither of these
203.84|4.84|architectural uh designs are new so
206.2|5.36|these are already present in the uh in
208.68|5.639|previous Works uh from from 2023 uh 2019
211.56|5.08|and 2020 so so these are really nothing
214.319|4.64|new but we decided to adopt these
216.64|5.08|architectural changes in mro 7B uh to
218.959|4.881|make a better model okay so after after
221.72|4.439|writing these slides I I realized
223.84|5.28|there's um actually a huge number of
226.159|5.0|decision choices you have to make in in
229.12|3.28|in designing a a Transformer
231.159|3.761|architecture because there are so many
232.4|5.759|details so um like just presenting this
234.92|4.879|doesn't feel sufficient so I try to uh
238.159|5.121|well first these are the sort of
239.799|6.0|standard configurations for mrol 7B and
243.28|5.56|also I just want to have a very single
245.799|4.561|uh very some very clean code in pytorch
248.84|3.319|that just tells you how to write a
250.36|5.2|single Transformer layer and I'll be
252.159|6.841|adopting the uh Nome shazir uh notation
255.56|6.32|by annotating the the the dimensions of
259.0|5.44|every tensor as a suffix in in the
261.88|7.92|variable name so let's say our sequence
264.44|10.479|size is 8,000 uh 8K and that we have
269.8|6.52|have uh 32 uh query heads and eight kmb
274.919|4.201|heads so this is quite standard for
276.32|5.96|group query attention and our high head
279.12|5.48|dimensions are 128 and our latent
282.28|6.24|Dimensions is
284.6|7.12|14K um so in order to write a single
288.52|7.64|Transformer layer
291.72|8.24|um uh first you initialize your uh query
296.16|5.52|key and value matrices so here I down
299.96|4.0|their Dimensions here and notice that we
301.68|5.079|don't use bias so there's no bias in any
303.96|6.76|of these matrices and we also write down
306.759|6.561|our output uh uh Matrix so to know that
310.72|5.8|uh the alpha Matrix has uh the same
313.32|6.04|dimensions as the transpose of the C of
316.52|5.2|the Cur Matrix um so in order to write
319.36|5.92|an attention forward layer uh so here
321.72|5.88|let's assume that our uh input X has the
325.28|5.08|dimension L * D so L is the sequence
327.6|6.52|length and D is the latent dimension
330.36|5.679|um so you first want to uh use these uh
334.12|6.519|matrices to to try to find what your
336.039|6.88|cury key and values are um so here their
340.639|5.601|uh Dimensions have been normalized to l
342.919|5.681|and H LK and LBH
346.24|3.399|respectively and then you want to apply
348.6|3.56|Rosary
349.639|4.4|embedding to your keys and queries you
352.16|4.599|don't really apply that to values and
354.039|6.28|then you do a very uh standard attention
356.759|6.521|mechanism uh uh with the uh with the the
360.319|5.481|queries keys and values uh to know here
363.28|4.08|we actually repeat the keys and values a
365.8|4.36|couple of times to make their Dimensions
367.36|5.48|match with the
370.16|5.92|queres and then we just return the
372.84|5.56|output uh uh multiply with the output
376.08|6.16|Matrix so this is your very standard
378.4|5.84|attention forward layer and uh to have a
382.24|4.239|transform layer you also want to tie
384.24|6.0|that uh you you want to First do a
386.479|6.12|normalization here we use RSM uh RMS
390.24|4.44|Norm over the input and then we do a
392.599|4.641|tension forward um and then we do a
394.68|5.84|tension residual layer uh followed by
397.24|5.76|normalization plus an MLP plus a dense
400.52|6.119|residual layer so this is what's present
403.0|6.56|in a Transformer layer okay um so with
406.639|5.761|these architecture designs we managed to
409.56|4.8|make a model that's uh quite good uh so
412.4|3.799|this is releas this was released in
414.36|4.399|September last year and it was able to
416.199|5.72|beat a lot of the Llama 2 models back
418.759|6.16|then despite being very very
421.919|4.68|small okay so let's now go to the
424.919|3.72|interesting bits that's mixture of
426.599|4.32|experts and mixture of experts is not a
428.639|5.28|very a new idea it's been present
430.919|4.921|forever and uh there are a couple very
433.919|4.28|uh quite recent papers that really
435.84|4.079|highlighted the importance and like how
438.199|4.68|uh what are the benefits you're getting
439.919|7.081|from these mixture of expert mixtures of
442.879|6.76|xert layer um uh models so uh the I
447.0|4.599|guess the probably the most wellknown
449.639|5.641|one is the switch Transformers uh that
451.599|5.641|is the Google paper uh that scales
455.28|3.44|Transformers to trillions trillion
457.24|4.48|parameter models with simple and
458.72|4.84|efficient sparcity um and they discussed
461.72|3.36|a lot about the sort of parallelism
463.56|6.16|decisions you can make about data
465.08|7.559|parallelism model parallelism and expert
469.72|6.199|parallelism and for the mixture of a
472.639|7.481|mixture of experts layer it's also it's
475.919|7.68|even older idea so from 2017 uh also by
480.12|6.24|some um quite famous vi from Google and
483.599|4.641|uh the idea is that you try to take out
486.36|4.959|uh so so at the time they were still
488.24|4.84|using recurrent language models um so at
491.319|4.28|the T the idea is that you try to have a
493.08|4.48|gating layer uh a gating Network that
495.599|7.121|decides which experts you should route
497.56|7.0|to okay um so in our mixture of experts
502.72|5.12|uh uh in our implementation of the
504.56|5.28|mixture of experts layer uh we're doing
507.84|5.28|something very similar so have the
509.84|5.759|inputs uh that are get sent to a router
513.12|6.279|and the router assign the gating ways
515.599|8.56|and to pick the top two uh experts to uh
519.399|6.88|to give this inputs to and uh after
524.159|4.081|these experts individually process the
526.279|3.961|inputs the gating wavs will be applied
528.24|5.4|to the output of the experts and they
530.24|6.159|get sum to get to the results so if you
533.64|5.52|uh write it in very uh mathematically uh
536.399|5.721|you can say that the uh the input is X
539.16|5.44|and the the router has a matrix multiply
542.12|4.88|to it and then you take the top K uh
544.6|4.4|experts out of that do a softmax and
547.0|5.56|these are your getting these are your
549.0|6.8|gating weights and um and uh output of
552.56|6.399|the uh the mixture of X for layer Y is
555.8|5.8|the softmax of the top two uh gating
558.959|5.401|gating weights times a sweet glue
561.6|4.52|function over X so um for for each of
564.36|5.719|the
566.12|6.88|experts okay um so
570.079|5.161|sparse mixture of xers model near is
573.0|5.04|quite near the cost performance uh
575.24|5.08|perito Frontier uh because at for each
578.04|4.28|token you don't the token do doesn't
580.32|4.4|have to go through the entire uh neuron
582.32|5.16|Network's parameters instead it can just
584.72|5.64|go to like the active parameters for for
587.48|5.12|that token and and this mix uh mixture
590.36|5.159|of experts model can outperform Lama
592.6|5.2|270p uh with about five times faster
595.519|5.241|inference uh so we kind of see it as a
597.8|5.8|dropping replacement for GB3 five which
600.76|5.319|can also Master quite a few uh European
603.6|5.96|languages in addition to English and you
606.079|6.0|can gracefully handle contact 32k tokens
609.56|5.04|so this mixture of expert uh model was
612.079|5.44|released under Apache 2 2.0 so you can
614.6|5.04|free to use for commercial purposes I
617.519|5.281|also attach the configurations for the
619.64|4.72|mixture of expers model here but I um so
622.8|5.159|you can you can you can refer this back
624.36|8.039|to the mro 7B to see the
627.959|7.641|differences okay so um I want to talk
632.399|6.281|about what does uh amoi which is a verb
635.6|5.0|I just created uh the the MLP layers
638.68|5.159|actually give you so the conventional
640.6|5.64|wisdom is that the MLPs in a neur in a
643.839|4.44|Transformer network uh store knowledge
646.24|3.96|and the tension stores algorithms or
648.279|5.041|reasoning or they sort of implement
650.2|6.24|algorithms and reasoning so by m moying
653.32|6.88|the MLP layers we're supposed to get a
656.44|8.56|boost in knowledge right um and indeed
660.2|8.0|we try to Benchmark uh mixol a * 7B uh
665.0|6.48|with a Mr 7B and a couple Lama two ler a
668.2|5.319|couple of the Llama 2 models and uh in a
671.48|4.24|couple of different categories you can
673.519|5.921|definitely see that on the knowledge
675.72|7.72|heavy tasks such as mlu and knowledge uh
679.44|6.16|the mixol uh a Time 7B model which is uh
683.44|5.24|shaded in yellow here is doing a lot
685.6|6.64|better than mol 7B um and also of the
688.68|5.64|reasoning comp hension and uh tasks uh
692.24|5.839|it seems to be doing a little bit better
694.32|6.319|but still uh but not not as much as it
698.079|6.241|does on knowledge in
700.639|5.76|mm okay um and here is a different graph
704.32|4.959|where here what we're trying to show is
706.399|5.921|that what is on the horizontal axis is
709.279|5.641|the number of active active parameters
712.32|5.6|and on the vertical axis is the
714.92|7.159|performance of the models on uh various
717.92|5.96|tasks and the the sort of uh brown dots
722.079|5.121|here are llama 2 models the series of
723.88|6.68|llama 2 models and the orange dots are m
727.2|8.24|models from mial 7B to uh Mix A Time 7B
730.56|7.519|so the Mixel a Time 7B uses only um 12.9
735.44|5.079|billion active parameters so close to 13
738.079|4.601|billion uh yet it can perform quite a
740.519|4.12|bit better uh especially in the
742.68|4.68|knowledge category you can see the drop
744.639|5.241|you can see the increase from mial 7B to
747.36|4.0|Mixel a * 7B is quite huge here
749.88|3.92|um there are some improvements on other
751.36|3.76|categories but the knowledge Improvement
753.8|4.96|is is really
755.12|7.88|great okay um so there is a research
758.76|8.639|question uh that is if uh if uh making
763.0|7.959|your language model uh uh if making the
767.399|6.44|MLP layers of your language model can
770.959|4.841|give you a huge boost in knowledge like
773.839|5.081|how about Amo ifying the attention
775.8|5.44|layers right so this is also very well
778.92|4.32|not very old but like quite old idea uh
781.24|4.839|from 2022 in the switch Transformer
783.24|6.68|papers um so the idea is you can replace
786.079|6.801|the trainable qkv matrices with switch
789.92|6.08|layers so instead of doing a standard
792.88|7.16|matrix multiplication you can do a m so
796.0|6.959|you have a gating layer and then um some
800.04|5.28|dance layers uh for the qkb matri
802.959|6.601|matricies and the problem at a time was
805.32|6.0|with stability um so if you use bf16
809.56|4.2|Precision to train your models they can
811.32|5.04|sometimes diverge but if you had use
813.76|5.36|fp32 they don't uh and you get some
816.36|4.64|performance boost which is nice um but
819.12|4.64|at present days mostly we're try we're
821.0|7.76|we're training with bf6 so we have to
823.76|6.96|find a way to make it work um and uh so
828.76|4.36|to to in order to make this work maybe
830.72|4.96|you can try better stability techniques
833.12|6.12|maybe some normalization or maybe you
835.68|6.44|could use a different way to uh to too
839.24|4.12|by the C the the the attention layers so
842.12|2.92|this is the open research question I
843.36|4.08|would really like to see some research
845.04|6.039|to be done
847.44|5.519|here um and after this I want to just uh
851.079|4.281|talk about several myths that seems to
852.959|5.12|be present around the mixture of xers
855.36|5.919|models so the miss one is that there're
858.079|5.44|eight experts in Mixr a Time 7B so this
861.279|7.321|is probably our our fault by naming our
863.519|7.32|our model mixol A * 7B um and um so the
868.6|4.479|truth is that every layer has every
870.839|4.161|Transformer layer has eight experts and
873.079|5.041|these experts are permutationally
875.0|6.56|equivalent so you because the way it
878.12|6.0|works is that the gating the gating uh
881.56|5.199|the gating Network decides how much Wass
884.12|4.079|to give to uh each of the how much waste
886.759|5.08|to give to each of the experts and only
888.199|8.76|picks the top two so it doesn't matter
891.839|7.24|um so it doesn't matter how you uh sorry
896.959|3.88|so so it doesn't matter how you uh
899.079|4.76|permute them they will give you the same
900.839|6.161|result so that means instead of eight
903.839|5.321|experts you actually have 32 * 8 experts
907.0|5.88|in total and they're relatively
909.16|7.76|independent uh uh across
912.88|7.639|layers um the M two is that there are 56
916.92|5.56|billion parameters in Mixr a Time 7B um
920.519|5.161|but the gating and the attention layers
922.48|6.08|are shared so these are not in the a
925.68|5.8|times part and uh in fact there are only
928.56|4.959|uh 40 6 * 7 billion parameters in total
931.48|4.64|and each token will will actually only
933.519|4.12|see 12.9 billion active parameters
936.12|5.76|instead of
937.639|6.281|14 okay um so uh another thing that
941.88|4.72|seems to be quite popular these days is
943.92|5.159|to compare everything uh uh tying
946.6|4.799|everything that's related to cost with
949.079|4.601|the number of active parameters as if
951.399|4.281|they are proportional and uh that's
953.68|4.079|that's not quite true right because mix
955.68|5.399|roll a Time 7B has fewer active
957.759|5.2|parameters than l to 13B but having this
961.079|4.68|of expert routing means that you need to
962.959|5.081|send tokens around to different experts
965.759|4.2|like quite dynamically so that means you
968.04|4.159|have more communication cost you cannot
969.959|5.36|just pre-program like which token will
972.199|6.08|be sent to which expert um while you're
975.319|5.281|gain much more in performance divided by
978.279|4.321|cost the absolute the absolute cost is
980.6|5.919|not proportional to the active parameter
982.6|7.239|count um so usually your uh mixture of
986.519|6.521|expers your mixture of expers model uh
989.839|4.92|if you have the active parameters uh
993.04|4.359|your your actual cost of serving these
994.759|4.841|models is actually a bit more than the
997.399|5.161|uh than the equivalent dance model with
999.6|6.52|the same number of acent
1002.56|4.8|parameters okay um here's also a really
1006.12|3.36|I think a really interesting research
1007.36|4.479|question is how do you balance loads at
1009.48|5.24|INF time right so your gting layer might
1011.839|4.881|still decide to do unbalanced loading at
1014.72|4.239|inference time which makes inference
1016.72|4.4|slower what that means is that ideally
1018.959|4.12|you want your eight experts or like how
1021.12|3.679|however many experts you have ideally
1023.079|4.401|you want them to handle the same number
1024.799|4.52|of tokens such that you don't get the uh
1027.48|3.599|you don't get the slowest you you don't
1029.319|4.561|always have to wait for the slowest
1031.079|5.441|expert and some nice ideas around like
1033.88|4.959|mixture of depth and also damic loading
1036.52|5.319|based on scores so some of the ideas are
1038.839|4.881|like uh if you uh if you saturate one of
1041.839|4.72|the experts maybe you can try to find a
1043.72|5.72|neighbor uh of that expert to to to give
1046.559|4.921|the token to which is not saturated
1049.44|4.16|and then sort of try to slowly fill up
1051.48|4.84|the number the the total number of
1053.6|7.56|expert times token count you
1056.32|7.04|have okay um another I think quite quite
1061.16|6.48|open research question is how can you
1063.36|7.6|compress smoes and this uh comes from a
1067.64|6.56|screenshot I I uh someone took of uh Tim
1070.96|7.24|dmer because I really trust this man's
1074.2|8.12|uh model compression uh SK skills with
1078.2|6.24|my life so uh Tim jur said uh he he
1082.32|5.2|thinks we can compress a mixture of X
1084.44|5.4|ver model to uh lower smaller than four
1087.52|4.32|gigabytes um so
1089.84|4.8|becausee uh compression is quite
1091.84|5.199|different from dense Transformer uh
1094.64|4.039|compression uh because the regular
1097.039|4.041|Transformers they are really really
1098.679|4.041|difficult SP to sparsify and this is
1101.08|4.88|really true for like the feed forward
1102.72|5.64|the the MLP layers but the MLP uh the
1105.96|4.28|Moe layers are quite different so maybe
1108.36|3.88|there's something you can do with Amo
1110.24|4.319|layers such that your compression is
1112.24|4.88|much much more efficient so by
1114.559|5.48|compression here I mean spcification so
1117.12|4.96|like a lot of the U so so sparsification
1120.039|3.88|not in the sense of like choosing only
1122.08|4.64|top two experts instead of uh instead of
1123.919|5.081|eight but I mean a lot of the parameters
1126.72|4.12|might be like doing not much work and
1129.0|6.32|you can like Shar them
1130.84|7.56|out okay um so this is this was um said
1135.32|4.359|by Tim deur in December last year and I
1138.4|4.279|don't think of seeing like much
1139.679|6.0|convincing work on like um sparsifying
1142.679|6.041|Moes to to an extreme but I really like
1145.679|6.521|uh more more work going going on
1148.72|6.76|here okay um now I want want to talk
1152.2|7.56|about uh how to interpret uh uh mixture
1155.48|7.28|of expert models um so the mixture of
1159.76|4.88|expert models with a sparse gating layer
1162.76|3.96|actually uh provide you an incredible
1164.64|5.08|opportunity by giving you disg grade
1166.72|4.52|gating signals um so so deep neuron
1169.72|3.68|networks are traditionally very very
1171.24|4.319|hard to interpret things like all the
1173.4|5.8|ways and activations living very high
1175.559|6.641|dimensional Place spaces and the
1179.2|5.68|attention in uh Transformers potentially
1182.2|5.04|offers some interpretation opportunity
1184.88|3.88|um because you can look at like how much
1187.24|5.559|of the attention weights get assigned to
1188.76|5.64|which tokens or to to to um uh to to
1192.799|4.201|which tokens but like you you're
1194.4|4.279|essentially picking at like what is the
1197.0|3.84|model looking at by looking at the
1198.679|4.841|ention scores but this also quickly gets
1200.84|5.16|very messy as you have a lot of
1203.52|4.44|attention hats and it's hard to
1206.0|4.76|visualize and hard to
1207.96|5.32|interpret and the gating layers in as SM
1210.76|4.08|Mo potentially tells you a bit more uh
1213.28|4.879|because it tells you like which experts
1214.84|6.16|is looking at wish tokens um so can we
1218.159|6.041|make some sense out of this then um so
1221.0|4.4|in our uh paper we try to find if
1224.2|3.92|there's some sort of domain
1225.4|4.96|specialization with these experts um so
1228.12|6.08|we took the validation splits of the
1230.36|5.52|pile data sets uh and um so these are
1234.2|5.2|represented in different colors you can
1235.88|6.2|see the red is archive uh the green one
1239.4|4.44|here is GitHub and the sort of blue one
1242.08|5.32|here is field field papers the purple
1243.84|7.04|one is stack exchange and for layers 0
1247.4|5.88|15 and 31 so these correspond to the the
1250.88|4.24|the the shallowest layer the sort of mid
1253.28|4.399|layer and the deepest layer so this is
1255.12|4.72|the layer 31 is the layer just before
1257.679|4.841|decoding
1259.84|7.719|so for each of these layers we plot how
1262.52|7.36|much each expert is selected um so uh
1267.559|4.521|since we have eight experts the sort of
1269.88|3.919|uh random random selection chance is
1272.08|5.4|around is
1273.799|5.721|12.5% and you can see that at layer zero
1277.48|4.799|so this is the layer that's closest to
1279.52|6.32|the raw tokens um you will see that the
1282.279|5.601|distribution is quite uh quite uniform
1285.84|4.959|it's it's it's not like very uniform but
1287.88|5.36|quite so this might be telling us that
1290.799|4.281|this layer is like too shallow that it's
1293.24|3.799|uh still doing some a lot of syntactical
1295.08|4.8|stuff that you don't get a lot of
1297.039|7.52|meaningful domain specialization going
1299.88|6.08|on and um on the sort of the mid layer
1304.559|3.961|so here is potentially where you get a
1305.96|5.52|lot of semantic information you can you
1308.52|4.84|can notice that expert 3 here uh is
1311.48|5.84|doing something quite interesting right
1313.36|5.559|so because it's it's it gets selected
1317.32|4.719|very
1318.919|4.961|not very often for any of the other
1322.039|3.801|categories but gets really selected
1323.88|3.88|quite a lot for DM mathematics and
1325.84|4.68|second place is get up so maybe this
1327.76|5.279|layer uh so maybe this expert in expert
1330.52|5.6|3 in layer 15 is doing something that's
1333.039|5.041|math and code heavy U but this is uh
1336.12|5.24|quite speculative and we cannot really
1338.08|5.4|conclude much out of it and for layer 31
1341.36|4.64|I think the distribution go back to
1343.48|5.16|close to uniform again although you get
1346.0|4.279|some spiking uh distributions here and
1348.64|4.56|here and there that specialize in
1350.279|4.961|mathematics it seems or since it's um
1353.2|3.359|since the data SI Deep Mind mathematics
1355.24|3.76|is more
1356.559|5.561|like
1359.0|7.2|arithmetics okay um we also did some
1362.12|6.88|analysis on cona tokens so the the
1366.2|4.839|question to ask here is whether two
1369.0|6.039|tokens that are consective get assigned
1371.039|6.52|to the same expert um so here we have
1375.039|6.721|the first choice so that means if a
1377.559|8.401|token is given to expert I does the next
1381.76|6.32|token also get assigned to expert I
1385.96|4.44|right and we also we we we we're still
1388.08|4.68|doing this analysis on the three layers
1390.4|4.48|layer zero layer 15 and layer 31
1392.76|4.799|corresponding to three different places
1394.88|6.799|in the network and the validation set is
1397.559|7.72|still the pile validation
1401.679|7.48|split so the random chance uh assignment
1405.279|6.0|score uh uh random chance assignment um
1409.159|5.041|will give you 12
1411.279|5.52|12.5% uh in terms of like how how many
1414.2|4.52|of the uh tokens get that are assigned
1416.799|4.681|to expert I still get assigned to expert
1418.72|6.36|I sorry the max token also gets assigned
1421.48|6.64|to expert I and we can see that at layer
1425.08|6.32|zero this is slightly higher than random
1428.12|6.439|U but at layer 15 this is significantly
1431.4|5.24|uh higher than random right so uh almost
1434.559|4.6|uh well it's almost double the random
1436.64|6.039|chance uh that the
1439.159|5.281|uh the first choice for the uh gating
1442.679|5.041|layer will actually assign the next
1444.44|6.479|token to the same uh expert as this
1447.72|5.0|token and when go to the last layer
1450.919|4.681|you'll find that this trend sort
1452.72|4.8|regresses a little bit uh the uh it's
1455.6|6.16|still sign quite significantly higher
1457.52|6.96|than ROM but it's a bit less than layer
1461.76|6.36|15 um we also look at like the first or
1464.48|6.28|second choice so uh if if if this expert
1468.12|5.2|is not chosen as the like the the the
1470.76|5.84|best the best expert to Route this token
1473.32|7.32|to uh could it be the second best um so
1476.6|6.48|here the random chance uh uh uh
1480.64|4.8|probability is around 46% and you can
1483.08|3.839|see for layer zero this we have the sort
1485.44|4.92|of the same pattern right so the for
1486.919|6.201|layer zero the uh number of times that
1490.36|4.679|the the next token get assigned to the
1493.12|4.159|first or second choice for for this
1495.039|5.201|expert is around just slightly higher
1497.279|4.64|than random and for layer 15 this is
1500.24|4.24|really really significantly higher and
1501.919|4.321|then for layer 31 it sort of regresses a
1504.48|3.559|little bit so I think there there
1506.24|3.76|certainly some sort of more detailed
1508.039|3.681|analysis to be done here uh that can
1510.0|4.52|conclude out of the uh from from these
1511.72|6.92|mixture of experts
1514.52|6.36|models also we try to visualize uh in in
1518.64|5.96|three examples like which experts
1520.88|6.2|actually selected which uh which tokens
1524.6|4.4|so um we have three examples so the
1527.08|5.0|first example is from
1529.0|6.12|um is actually from the uh GitHub code
1532.08|5.64|for the layer and the second example are
1535.12|4.919|like simple arithmetic questions I think
1537.72|5.04|from DM mathematics and the third is
1540.039|5.041|from a simple multiple choice question
1542.76|5.2|and this is for layer zero layer 15 and
1545.08|5.12|layer 31 you can see that there's there
1547.96|6.959|doesn't seem to be much specialization
1550.2|7.479|right um uh uh so here a lot of digits
1554.919|5.081|get assigned to the same sorry so the
1557.679|5.801|colors repres present different experts
1560.0|6.0|so here all these digits get assigned to
1563.48|4.96|the same expert but that seems to be it
1566.0|4.76|we don't see a lot of like very clear
1568.44|8.04|distinction between like which experts
1570.76|9.24|like which uh tokens right um so that
1576.48|5.48|really closely relates to uh myth four
1580.0|4.039|that is you really uh the myth four is
1581.96|4.48|that you want experts to specialize in
1584.039|5.041|domains let's say you have two experts
1586.44|4.28|specialized in coding uh so that means
1589.08|3.52|they just basically like if you have
1590.72|4.959|some code they'll just handle all the
1592.6|4.959|tokens um then what do the other other
1595.679|3.961|experts do when you're coding right so
1597.559|4.281|when you want to generate a lot of uh a
1599.64|4.279|lot of code it seems that you will only
1601.84|3.6|have the chance to uh root all your
1603.919|3.921|tokens to these two experts and the
1605.44|4.76|other expert just stand there and do
1607.84|4.48|nothing so you actually want all the
1610.2|5.079|expert to be fully engaged at all the
1612.32|6.44|time to maximize your inference
1615.279|5.88|efficiency language also is so complex
1618.76|4.84|that man specifying these domains uh
1621.159|4.281|that experts should specialize over uh
1623.6|3.559|seems to be a simplification to me
1625.44|4.16|because there might be like a lot of
1627.159|5.041|underlying features that the experts are
1629.6|5.559|actually specializing over and just not
1632.2|4.76|present at the high like the very high
1635.159|4.88|domain
1636.96|5.36|level um there's a treasure hunt so this
1640.039|5.64|is this is why we love open source so
1642.32|7.479|much so like around after 24 hours of
1645.679|7.201|our uh Mixr a * 7B model release uh
1649.799|4.921|there's a guy um on a Chinese website
1652.88|3.56|that just found out that there is one
1654.72|4.76|expert in one of the layers that's
1656.44|7.8|particularly crucial so what they did
1659.48|9.679|was that they try to remove um the I
1664.24|7.679|expert from uh from all of the layers
1669.159|5.441|and here you can see what are the
1671.919|5.441|effects if you remove the I expert and
1674.6|7.959|the uh on the vertical axis is the mmu
1677.36|7.199|score um it seems that if you remove the
1682.559|5.161|third expert then everything just
1684.559|10.161|collapses the MML score is 0.63 so this
1687.72|9.199|is 0.63% not um uh uh uh not uh 63% and
1694.72|5.4|for other uh for other experts if you
1696.919|6.561|remove the uh I expert the mmu scores
1700.12|5.48|drop a little bit but not too much um so
1703.48|4.319|and they made this meme about it so the
1705.6|4.0|expert 3 seems to be doing all the work
1707.799|3.961|well all the experts are sort of
1709.6|6.36|standing around and do not
1711.76|6.32|much okay um so I think another really
1715.96|4.599|important research question here is how
1718.08|4.64|do we interpret the mixture of expert
1720.559|4.321|decisions and what what are the features
1722.72|3.76|that they're learning so the experts
1724.88|3.72|might capture features that are really
1726.48|5.4|different uh very different concepts
1728.6|4.6|than what we perceive as Concepts and it
1731.88|3.84|might be more efficient to represent
1733.2|5.199|linear combinations of Concepts as long
1735.72|5.079|as they spend sort of the same sub space
1738.399|5.481|right and it how do we recover that
1740.799|6.161|Subspace or how do we recover um some of
1743.88|4.84|the uh um some of the stats that we can
1746.96|2.959|actually understand what are the
1748.72|2.16|underlying Concepts that they're
1749.919|5.6|actually
1750.88|7.36|learning okay um so I just want to also
1755.519|4.921|uh just conclude here that um a sparse
1758.24|4.76|mixture of xers models are leverage
1760.44|4.32|sparity to gain a lot more knowledge and
1763.0|4.72|you can train very good uh mixture of
1764.76|5.6|expert Mi mixture of experts models to
1767.72|4.439|be efficient at inference and expert
1770.36|4.559|specialization is not as straightforward
1772.159|4.0|as one might think and just there's just
1774.919|4.721|tons to do in architecture and
1776.159|7.4|interpretability research um and also
1779.64|7.639|just want to plug Mr AI uh co-founded by
1783.559|6.681|uh uh uh by Arthur Timothy and Gom and
1787.279|5.081|we're have uh offices in Paris London
1790.24|5.0|San Francisco Bay Area it's actually
1792.36|6.199|currently it's actually in Palo uh have
1795.24|4.799|500 million in funding and if you enjoy
1798.559|4.161|solving the research questions that I
1800.039|4.88|just mentioned or uh doing open source
1802.72|4.48|AI or just uh generally empowering
1804.919|4.921|people with uh language models uh you're
1807.2|5.16|very welcome to join us um thank you
1809.84|6.319|very much if any of youall have any
1812.36|6.679|questions feel free to come up and ask
1816.159|6.12|so uh I recently uh read the paper from
1819.039|7.601|meta uh they are using the Intensive
1822.279|8.28|model uh not this one uh 28 I think page
1826.64|6.56|28 yeah okay so which is I feel like
1830.559|5.72|it's the other direction opposite way
1833.2|6.479|why you choose The Spar mixture of exper
1836.279|5.801|rather than the other people now I see
1839.679|5.72|most of them using the Intensive
1842.08|7.719|models like to do some of like Edge
1845.399|8.081|database like in a confined scope you
1849.799|7.041|can have more knowledges in the um
1853.48|4.96|confined scope that's I see the train
1856.84|4.36|goes to that way
1858.44|5.599|for example you go to the uh Egypt
1861.2|5.079|Museum here uh in I think in Sun
1864.039|6.24|somewhere right so you can have the chat
1866.279|6.561|gbt uh have the local U knowledges which
1870.279|5.12|you cannot get it from the internet but
1872.84|6.12|you can only cooperate with the museum
1875.399|6.88|and get it I think uh the Intensive
1878.96|6.04|model allows this kind of uh more uh
1882.279|6.0|domain knowledge like going deeper but
1885.0|4.84|now here you are using the spous model
1888.279|4.561|with mixture of
1889.84|6.559|experts to me it's the opposite can you
1892.84|5.92|explain why yeah sure um so so if I
1896.399|4.24|understand the question correctly the uh
1898.76|3.639|the question is asking uh why are we
1900.639|4.76|choosing sparse mixture of experts
1902.399|6.16|models instead of uh dance models that
1905.399|6.681|are there's no sort of sparcity involved
1908.559|5.441|um so I think for for for as devices uh
1912.08|4.12|dense models are have a lot of potential
1914.0|5.12|because uh for spars mixure of expert
1916.2|5.319|models uh although you have uh sparity
1919.12|4.88|in um inference time so that means a
1921.519|4.12|token does not have to see all the uh
1924.0|4.32|parameters but rather just a small
1925.639|5.64|fraction of it uh you still have to load
1928.32|5.88|all of the experts into memory and that
1931.279|5.161|might pose a huge challenge for Adge
1934.2|4.16|devices so so like your phone might not
1936.44|4.959|have like 200 gigabytes of memory in
1938.36|5.88|order to uh run inference like very uh
1941.399|6.081|uh uh you order to run inference very
1944.24|5.399|efficiently but for um like I guess for
1947.48|7.72|data or for people who are serving these
1949.639|7.64|models uh it might pose a uh advantage
1955.2|5.839|in terms of inference cost uh because
1957.279|7.12|you can have um you can have very good
1961.039|6.841|uh performance slash uh divided by cost
1964.399|6.361|ratio I see so your point is because
1967.88|5.799|there's not enough uh memory at the edge
1970.76|6.48|so for the edge it's better to use Spas
1973.679|5.761|model rather than denve model oh so no
1977.24|6.08|no I meant uh for for ad it's I think
1979.44|5.32|it's good to use dense models ah because
1983.32|3.479|because for sparse models you still have
1984.76|5.56|to load everything into into memory yeah
1986.799|6.521|yeah yeah so so your your use case is is
1990.32|5.56|more for like a closer to the center of
1993.32|8.079|the cloud is it what you
1995.88|5.519|mean uh yeah yeah okay got it thank
2001.48|4.799|you thank you does anyone else have a
2004.36|4.64|question they'd like to
2006.279|5.041|ask yes
2009.0|2.32|do you want
2015.399|5.64|to I have a question in regards to fine
2018.799|5.641|tuning um we've been working with
2021.039|6.441|multiple models so Gemini Char
2024.44|5.32|jpt llama and there is a big problem of
2027.48|6.079|fine tune in these models especially on
2029.76|5.919|on you know tensor on images um they're
2033.559|5.761|like having issues with understanding
2035.679|5.88|what what can you say about that
2039.32|6.64|uh you mean in general fine-tuning
2041.559|7.56|language models on Vis visual tasks
2045.96|6.199|yeah um I guess okay I guess that's a
2049.119|7.601|very broad question uh what I can what I
2052.159|6.96|can say about that is uh there's um I I
2056.72|3.959|guess for chat gbt and and Gemini you
2059.119|4.161|don't really have the model weights in
2060.679|6.72|your hand so you're basically relying on
2063.28|6.839|open AI or Google uh to do lur for you
2067.399|5.52|right um so you get I guess you have
2070.119|5.321|less control over your fine tuning uh
2072.919|3.881|whereas for an open source model or I
2075.44|3.28|guess open waste model you actually have
2076.8|4.079|waste in your hands so you can do you
2078.72|6.28|can do Laura you can do full fine tuning
2080.879|6.361|I guess you get more control and um yeah
2085.0|4.04|I I guess that's in general like what
2087.24|4.879|what I can say about like fine-tuning
2089.04|5.24|open source models versus uh versus very
2092.119|4.28|close Source models but like I guess
2094.28|3.92|that really highly depends like exactly
2096.399|4.641|what happens when you're doing really
2098.2|5.32|depends on your use case and your data
2101.04|5.48|yeah I mean I sorry I was a little bro
2103.52|6.12|so um when we try start transferring
2106.52|6.559|them into a large large data sets let's
2109.64|5.52|say like 10,000 images or 5,000 images
2113.079|3.681|so and you you have to transfer them
2115.16|3.56|into textual format because none of
2116.76|4.76|these models are actually tuned designed
2118.72|6.0|to be fine tuned on images they don't
2121.52|7.96|understand it so is this something you
2124.72|9.68|see in development in open source models
2129.48|8.879|um so do by trans by translating these
2134.4|5.48|images into text you mean like OCR or
2138.359|3.521|that is that something digital format
2139.88|4.36|it's the textual format so they do
2141.88|5.04|understand them in dig as an image if
2144.24|4.72|you upload them into like text text line
2146.92|3.919|right like you go to charp but when you
2148.96|4.32|start feeding them through apis you need
2150.839|4.201|to transfer them so then it becomes a
2153.28|3.36|problem like is there any way to
2155.04|4.14|overcome this issue with open source
2156.64|4.28|models
2159.18|5.26|[Music]
2160.92|6.399|um I I guess I'm not uh I guess I'm not
2164.44|5.48|entirely sure what the root cause of the
2167.319|4.481|of of this problem is but I I I think
2169.92|3.919|I'm sure that with open source models
2171.8|3.48|you can actually while you can see like
2173.839|4.721|what the ways are doing right so you can
2175.28|5.48|you can actually tell what are like you
2178.56|5.4|you have more control of the ways
2180.76|7.359|basically uh so I think open open way
2183.96|4.159|definitely post an advantage here
2190.76|3.559|thank you for your question thank you
2192.319|5.121|for the question does anyone else have
2194.319|6.04|any other questions in
2197.44|5.52|person yeah I guess I was curious uh
2200.359|4.321|like where you think the improvements of
2202.96|5.159|mixtures mixture of experts are like
2204.68|5.28|coming from like I've I've heard that
2208.119|3.601|you can like put different experts or
2209.96|5.28|different like feed for networks on
2211.72|5.119|different gpus and that that like um
2215.24|4.04|allows it to be more parallel and like
2216.839|4.681|speed things up from like a compute
2219.28|4.52|perspective or is it like more the
2221.52|4.36|sparcity itself that is like giving
2223.8|3.519|these improvements I guess is there any
2225.88|4.32|insight on
2227.319|5.081|that um I guess there are there are two
2230.2|4.48|Dimensions to this right so in terms of
2232.4|6.12|improvement um the one dimension is
2234.68|6.52|performance um uh so so as I said the
2238.52|7.36|mixture mixture of experts models have
2241.2|6.44|these uhe MLP layers so imagine your
2245.88|3.56|your original MLP layers and then you
2247.64|4.04|make it eight times wider you will be
2249.44|4.56|able to store a lot more knowledge into
2251.68|4.48|into these layers um because well you
2254.0|4.44|have more parameter counts uh so that's
2256.16|4.84|I guess the own the performance um
2258.44|4.04|Dimension that you you can actually uh
2261.0|3.839|you can actually store a lot more
2262.48|5.28|knowledge into into these models and on
2264.839|4.48|the performance uh sorry and the other
2267.76|4.64|dimension is the the inference
2269.319|4.52|efficiency Dimension right so uh um so
2272.4|4.24|uh definitely go read the switch
2273.839|5.321|Transformer paper where they dis discuss
2276.64|4.679|the um okay I guess that's training
2279.16|4.679|efficiency but they really discussed in
2281.319|5.561|quite quite quite a lot of details about
2283.839|5.28|data parallelism uh model parallelism
2286.88|4.4|and expert parallelism and how they
2289.119|3.801|affect the efficiency uh what's the
2291.28|5.68|communication cost there what's the best
2292.92|6.32|way to trade a models um and for for for
2296.96|6.92|these uh sparse mixture experts models
2299.24|8.04|since you only so so you only select um
2303.88|6.04|13 billion parameters uh for each token
2307.28|4.36|at inference time you are actually uh
2309.92|3.96|trying to select the most relevant
2311.64|5.28|parameters for each token so that can
2313.88|5.56|make inference quite a lot uh quite a
2316.92|4.24|lot more efficient um I hope that answer
2319.44|4.52|your question um yeah I know that
2321.16|5.32|definitely did um I guess I was also
2323.96|5.8|wondering like if if you seen like the
2326.48|5.599|uh mixture of depths paper um and like
2329.76|3.839|that as like a way of sparity do you
2332.079|4.681|have any thoughts on
2333.599|4.881|that yeah I think sparity sparity helps
2336.76|4.16|when you can do
2338.48|4.839|like so adaptive computation so the
2340.92|5.88|mixture of depth model is like the best
2343.319|6.961|example of um the uh adaptive
2346.8|5.4|computation which means for different
2350.28|3.44|tokens for for predicting different
2352.2|5.24|tokens you you
2353.72|6.96|want first um different parameters to
2357.44|6.679|engage so in the mixture of depth uh uh
2360.68|7.48|paper they uh they selected different
2364.119|5.801|number of parameters to engage in uh
2368.16|3.919|calculating each token and in our paper
2369.92|5.52|we select different like the same number
2372.079|6.28|of the same number of parameters but
2375.44|6.6|like uh but different experts so it's
2378.359|6.401|it's a the the difference is uh I guess
2382.04|4.24|quality versus quality like but there
2384.76|3.839|are like two Dimension two different
2386.28|4.0|dimensions you can optimize over you
2388.599|4.401|definitely want to have to select the
2390.28|5.799|most relevant parameters and as few
2393.0|5.72|parameters as possible for decoding
2396.079|4.441|at yeah okay um yeah I think those all
2398.72|4.68|my
2400.52|5.44|questions perfect thank you we'll take
2403.4|4.84|one more inperson question if any of you
2405.96|5.159|all have anything if not we can turn it
2408.24|2.879|to the online
2411.2|3.0|questions
2419.68|5.76|yes hey Alber thanks for the talk um
2422.52|4.04|just one in the earlier you uh like
2425.44|3.24|beginning of the presentation you
2426.56|4.0|mentioned like routing and communication
2428.68|4.52|cost and I was wondering if you could
2430.56|3.88|talk about like how that scales uh you
2433.2|3.6|know relative to the number of experts
2434.44|6.52|you have in
2436.8|6.279|parameters oh yeah sure so um so so that
2440.96|4.84|depends on like the first the number of
2443.079|4.641|uh the number of experts you have and uh
2445.8|5.279|also depends on like how large each
2447.72|7.32|expert is um so that that sort of uh can
2451.079|5.441|change your the way you do pism so um we
2455.04|2.76|know that communication is really
2456.52|3.2|expensive when you need to go from one
2457.8|3.319|GPU to another and it's more expensive
2459.72|5.24|if you want to go from one node to
2461.119|6.441|another um and if you have a huge ton of
2464.96|7.48|experts that will not fit into just one
2467.56|7.519|node um then you really incur a huge qu
2472.44|5.2|quite a big communication cost and uh
2475.079|5.441|like how to scale beyond that is is I
2477.64|7.32|guess is a is is a very open scientific
2480.52|7.24|questions um but like essentially the um
2484.96|5.879|the communication cost you incur is uh
2487.76|6.48|roughly proportional to to to the uh to
2490.839|5.681|to the number of uh token routing uh
2494.24|4.839|first between gpus and then between
2496.52|5.319|notes thank
2499.079|5.681|you thank you for all the questions um
2501.839|4.48|we'll have Stephen uh introduce some of
2504.76|4.44|the questions that were submitted by the
2506.319|2.881|people joining us on
2511.0|7.28|Zoom hey y can you hear me yep he thanks
2515.56|4.24|for the great talk thanks um all right
2518.28|4.64|so we have some questions through zoom
2519.8|4.92|and slido I'm G to um pick and choose
2522.92|5.72|some of them starting with some Zoom
2524.72|6.76|questions maybe um so we have a question
2528.64|4.84|here about any comments on why
2531.48|3.96|potentially llama 3 is not using a
2533.48|4.92|mixture of experts a lot of people
2535.44|4.32|suspected they might after misal success
2538.4|3.76|um I don't know if you would know
2539.76|4.92|anything about that but yeah I don't
2542.16|5.56|know just ask a lot of people
2544.68|5.12|sorry right um
2547.72|5.76|let me
2549.8|5.519|see here's OD question um do you foresee
2553.48|3.8|mixture of experts techniques being
2555.319|5.24|incorporated into the other large
2557.28|4.92|Foundation models or will it remain a
2560.559|3.04|subset of models that are best for
2562.2|5.119|certain use
2563.599|6.121|cases oh uh certainly so uh as uh I
2567.319|5.081|think as my answer to the first like
2569.72|4.8|iners question was um for as devices you
2572.4|4.199|probably you probably want want to stick
2574.52|4.799|with dense models because of the memory
2576.599|5.801|constraints and for mixture vorts models
2579.319|5.641|you really gain a lot in uh efficiency
2582.4|4.6|if you if you can serve it at scale um
2584.96|5.2|so if you have if you have high batch
2587.0|5.2|sizes you will potentially be doing you
2590.16|4.28|will potentially be doing better uh in
2592.2|4.68|terms of throughput than the dance
2594.44|5.159|models um so yeah it definitely depends
2596.88|4.479|on like um depends on your use case uh
2599.599|5.201|usually the larger this the larger the
2601.359|5.76|scale the better the well I guess the
2604.8|4.519|more the benefit of the mixure VAR
2607.119|4.321|expert model shine and well it's
2609.319|4.28|speculated that gb4 is a mixure of
2611.44|5.0|experts model if you haven't heard
2613.599|4.921|already can mixure of experts models out
2616.44|5.04|perform domain specific models at their
2618.52|7.76|respective tasks with
2621.48|7.4|experts um so well first um
2626.28|4.12|usually um models that have been trained
2628.88|4.16|for particular domains are really hard
2630.4|5.32|to beat I I think that's where also
2633.04|4.279|where the the purpose of continuous Pro
2635.72|5.0|training and fun tuning comes uh comes
2637.319|5.921|in so if you uh let's say you you first
2640.72|4.119|prra a general tax model and then you
2643.24|3.64|want to adapt it to the medical domain
2644.839|3.881|so you grab a lot of medical data and
2646.88|3.28|then you continue P tray or fting on
2648.72|5.08|that that model is going to be really
2650.16|5.959|hard to beat um and I think um the
2653.8|4.68|mixture of experts model uh the experts
2656.119|4.72|don't really um at least in our case
2658.48|4.44|here the expert don't really focus on
2660.839|3.641|like tradition like domains as we know
2662.92|3.0|it they don't have we don't have a
2664.48|6.04|medical expert we don't have a coding
2665.92|7.08|expert rather they just try to uh extend
2670.52|6.319|they try to they have Concepts encoded
2673.0|7.04|in a very u non-interpretable Way um so
2676.839|4.52|so I I wouldn't say that just taking one
2680.04|6.6|mixture of EX first model would just
2681.359|8.96|outperform all the other uh domain Focus
2686.64|6.0|models right that makes sense um here's
2690.319|4.441|a question has there been any study on
2692.64|4.919|whether thee layers should be both at
2694.76|5.04|the early layers and deep layers for old
2697.559|5.961|neuron Network Ensemble methods late
2699.8|7.12|Fusion tends to work better than early
2703.52|6.039|Fusion so um okay I think that's a
2706.92|5.439|really great question because um I think
2709.559|6.601|from inception from the the neuron
2712.359|6.081|Network um we are trying to adopt this
2716.16|6.08|um we're we're trying sort of have this
2718.44|5.76|tradition of um having layers that are
2722.24|5.76|that look exactly the same as at each
2724.2|6.52|other um so you have and and so then you
2728.0|4.72|can try to focus on just designing this
2730.72|3.639|layer to be as perfect as possible and
2732.72|4.44|then you can just copy paste that a
2734.359|4.72|couple of times um but I think I've
2737.16|3.679|recently seing a paper sorry I don't
2739.079|4.801|remember the name but I think they're
2740.839|5.041|just trying to put uh layers in random
2743.88|5.04|ERS so sometimes it can be attention
2745.88|5.92|first sometimes it can be M first and
2748.92|4.8|they can have Al also some other quite
2751.8|4.16|wacky layers uh but I think that
2753.72|3.92|performs quite well uh it's unclear to
2755.96|4.44|me
2757.64|5.56|like why that is it could be just chance
2760.4|5.56|um but I guess in I guess in ter in ter
2763.2|5.0|if you wanted to design a generally
2765.96|4.24|really perform really performing model
2768.2|6.24|it's really safe to have the same
2770.2|6.76|architecture uh for every layer um uh so
2774.44|4.44|yeah so I guess that's I guess the sa
2776.96|3.72|safest Choice uh you can also do some
2778.88|4.36|sort of neuro architecture search in
2780.68|5.399|order to optimize your layer sorry
2783.24|4.48|optimize your architecture um but that's
2786.079|3.721|that which is a much more principled
2787.72|4.56|approach that's so guessing that this
2789.8|7.759|ler might work
2792.28|7.68|better all right thanks for the answer
2797.559|5.201|um asking could you talk a bit more
2799.96|4.359|about how the different uh the eight
2802.76|4.0|experts are built are they just fine-
2804.319|6.841|tuned on different data
2806.76|8.04|sets um so they are they are trained on
2811.16|6.56|the on the on roughly the same data sets
2814.8|5.799|um but I I I'm not sure if I can say
2817.72|5.04|more than that but uh yeah
2820.599|3.921|sorry all right and here's a question
2822.76|3.559|some work has suggested that learning to
2824.52|4.2|Route doesn't perform any better than
2826.319|4.76|simply using for example a random
2828.72|4.599|mapping of inputs to experts do you have
2831.079|5.48|any
2833.319|5.361|thoughts I think that
2836.559|5.0|um I would I would definitely need to
2838.68|5.08|see the the the paper first but I
2841.559|4.321|wouldn't be too surprised if that's the
2843.76|3.839|case I I would still be surprised but
2845.88|4.4|not like extremely surpised
2847.599|6.801|because if you if you think about Amo
2850.28|6.799|ifying the uh MLP layers as augmenting
2854.4|5.76|the the knowledge capacity then uh it
2857.079|4.921|seems that you can potentially uh just
2860.16|4.959|do do that in a very root Force way and
2862.0|5.079|just randomly mapping the the tokens to
2865.119|5.761|to random layer to sorry to random
2867.079|8.28|experts um I would still think that the
2870.88|7.76|gating has the advantage of um you know
2875.359|7.0|um of being able to choose experts more
2878.64|6.04|intelligently than just randomly so um
2882.359|5.121|yeah I I I I I don't know that paper but
2884.68|4.32|I I I would love to see it um someone
2887.48|3.2|was asking could you speak a bit about
2889.0|4.28|the general development process from
2890.68|4.879|your perspective for this model what
2893.28|4.72|aspects design choices hyperparameters
2895.559|6.361|and so forth did you try that did not
2898.0|8.0|work before arriving at this specific
2901.92|5.84|architecture um so we know uh so for for
2906.0|4.76|this particular archit Ure uh the
2907.76|5.359|mixture of experts architecture uh we
2910.76|4.72|kind of know that it will work because
2913.119|5.601|um there there's they're having a lot of
2915.48|4.56|successful papers beforehand um in terms
2918.72|3.879|of like what sort of things you need to
2920.04|4.96|consider um I think one really good
2922.599|5.881|practice I guess for an AI companies
2925.0|6.119|that of as a like a a single developer
2928.48|4.48|is to always cons like you you you
2931.119|5.881|always want to take
2932.96|5.44|inference um needs um you you you want
2937.0|3.64|to think about inference needs before
2938.4|4.6|you design the architecture for a model
2940.64|5.64|uh you don't want to so for example you
2943.0|6.0|don't want to have an have a model
2946.28|6.48|that's just just slightly exceeds like
2949.0|5.64|what a single 800 uh 80 80 gab h100 can
2952.76|4.16|contain and then you you you basically
2954.64|3.919|lose a lot of efficiency uh from just
2956.92|4.36|like being like overhead being just a
2958.559|6.601|little little bit more than 80 gigabytes
2961.28|5.72|um so I think in terms of design before
2965.16|6.12|training the model uh you definitely
2967.0|6.72|want to consider how do how do how do in
2971.28|5.88|how to infer with this model um and in
2973.72|4.399|terms of the uh hyper parameters you
2977.16|5.28|definitely want to do some sort of
2978.119|6.44|scaling law uh before you you like some
2982.44|4.32|some sort of scaling law uh I guess
2984.559|5.121|search and Analysis before trainer model
2986.76|7.039|to make sure that short model is served
2989.68|8.56|um at the best performance uh cost ratio
2993.799|7.881|um so yeah that's it
2998.24|5.68|great um speaking of uh GPU memory
3001.68|5.24|someone is asking what is the inference
3003.92|6.0|runtime GPU memory footprint for um the
3006.92|5.04|7B model versus the 8X 7B it would be
3009.92|4.24|great to understand this for specific
3011.96|4.76|applications especially if mistol has
3014.16|5.439|the potential to run on edge devices um
3016.72|5.839|with sufficient GPU of
3019.599|5.601|vram um sorry I I I I don't think I got
3022.559|5.201|the the last part of the question so ad
3025.2|4.72|devices and GPU uh oh no they're just
3027.76|5.52|asking what is the approximate inference
3029.92|6.76|runtime of um in terms of GPU memory
3033.28|9.039|footprint for the 7B model versus the 8
3036.68|11.24|by 7B ah okay I see so uh if you do like
3042.319|7.561|if if you do very naive um uh if you if
3047.92|4.6|you do it very straightforwardly that
3049.88|5.56|should load for for the a uh a Time 7B
3052.52|5.319|to load all the experts in and then uh
3055.44|6.44|the experts always stay in GPU memory
3057.839|5.72|then your uh then then the different the
3061.88|4.4|the difference between the a * 7B and
3063.559|3.641|the 7B will be the same as the ratio
3066.28|5.039|between
3067.2|7.96|46.7 to 7 uh that's the memory
3071.319|5.961|requirement um but the at at infin time
3075.16|5.84|since we the mixture of xer model only
3077.28|6.839|has 13B active parameters uh so each
3081.0|5.96|token get to see much fewer parameters
3084.119|5.24|than there are in the memory um and you
3086.96|5.599|can do some interesting things like like
3089.359|4.76|um I think CPU like I kind of forgot the
3092.559|4.361|the name for it but you can keep some of
3094.119|4.641|the experts uh in CPU and then uh and
3096.92|3.0|then only load them when you need them
3098.76|4.72|um so I think that's something you can
3099.92|5.76|you can do as well um but then you you
3103.48|4.24|also lose uh some efficiency because you
3105.68|4.119|need to constantly transfer uh
3107.72|4.48|parameters from CPU to GPU and vice
3109.799|4.8|versa right that makes sense speaking of
3112.2|4.76|parameters someone asked do you have a
3114.599|5.441|rough rule of thumb for how to
3116.96|5.28|approximate how capable Ane model would
3120.04|4.36|be in terms of equivalent dense
3122.24|4.52|parameters for example I've heard that
3124.4|4.76|calculating the geometric mean of active
3126.76|5.359|parameters to Total parameters is a good
3129.16|5.36|way to do this which would mean that 13
3132.119|4.0|billion active parameters with 47
3134.52|4.799|billion total parameters would be
3136.119|5.601|equivalent to a 22 billion parameters
3139.319|6.76|dense model um I'm wondering how
3141.72|6.52|accurate that would be um so I I think
3146.079|4.081|that's I I think that's a good rule of
3148.24|5.16|thumb um although that definitely
3150.16|7.12|depends on like how how how well you
3153.4|7.0|train these models um like um uh and how
3157.28|5.68|many tokens do you put through them and
3160.4|4.04|how good are those tokens if all other
3162.96|3.56|things being equal I think that's a very
3164.44|4.159|good rule of
3166.52|4.2|Thum all right great and I'm just
3168.599|4.48|looking at some of the uploaded slider
3170.72|4.68|questions um someone asked for the
3173.079|4.121|treasure hunted expert was there a
3175.4|4.12|reverse experiment of removing all
3177.2|5.68|experts except number
3179.52|5.319|three oh uh that's a that's a great
3182.88|3.64|question I think yeah if if you can
3184.839|3.361|figure that out I I'll be really like
3186.52|4.36|I'll be all yours I'll be really happy
3188.2|7.599|to hear that so so then then you're just
3190.88|8.32|trying to I guess you're trying to trim
3195.799|6.32|the a * 7B back into a 7B which might be
3199.2|2.919|an interesting experiment to
3203.079|6.601|do right um someone asked what is your
3206.839|4.28|intuition about why the 8X 7B is
3209.68|3.56|significantly better at reasoning
3211.119|4.401|compared to the 7B are they learning
3213.24|5.2|better internal
3215.52|5.24|algorithms um that could be the case
3218.44|5.28|although I think that's very speculative
3220.76|5.76|I think okay so I think for a lot of
3223.72|5.44|these benchmarks uh for example the even
3226.52|6.799|for the math benchmark
3229.16|5.959|the the like what you do like what s of
3233.319|4.441|things count as knowledge and what
3235.119|5.361|things count as reasoning is quite
3237.76|5.16|ambiguous for example if you are doing a
3240.48|4.2|math task and you can reason to get
3242.92|4.32|something out or you can just recall oh
3244.68|4.639|here's a Lama and I can just use that
3247.24|4.44|and so I think there's like high
3249.319|3.601|ambiguity between what sort of things
3251.68|4.72|count has knowledge what sort of things
3252.92|7.639|counts as reasoning um so for this
3256.4|6.679|particular example um the a * 7B
3260.559|6.681|definitely gains a lot more in knowledge
3263.079|6.0|uh but does the gaining uh knowledge
3267.24|4.879|also induc some sort of change in its
3269.079|5.601|reasoning capability I don't know uh but
3272.119|3.761|I I think that that's just like whatever
3274.68|3.28|I can say about it is like highly
3275.88|3.919|speculative but I'll say the the
3277.96|3.76|benchmarks themselves are also very
3279.799|5.28|ambiguous so so I think it's worth
3281.72|6.16|finding out what exactly um is
3285.079|5.28|doing great another question about GPU
3287.88|4.919|memory um someone's saying in production
3290.359|4.841|we're constantly bounded by GPU memory
3292.799|4.161|instead of compute we'll mixure of
3295.2|4.44|experts make it more challenging to
3296.96|4.399|serve any extra cost besides
3299.64|4.36|communication
3301.359|5.76|overhead um so you Pur of cost I think
3304.0|6.119|communication like um yeah so so when
3307.119|5.761|you say you're founded by GPU memory I I
3310.119|5.601|assume that it's it's like it's like
3312.88|4.8|comparing the a Time 7B to a 7B um then
3315.72|3.72|yes if you need to load all the experts
3317.68|3.919|into the GPU memory then yeah you're
3319.44|5.8|going to consume you're going to uh
3321.599|5.561|you're going to use a lot more um so the
3325.24|6.839|the the
3327.16|5.76|the benefit or or the advantage of the a
3332.079|4.28|Time
3332.92|7.84|7B over the 7B
3336.359|8.0|um is that at or let's let's say over an
3340.76|6.96|equivalent dense models uh with similar
3344.359|6.041|active parameter count is that at high
3347.72|4.04|batch size you'll get more thorough put
3350.4|4.8|because you'll get different experts
3351.76|5.44|hand handling uh handling the the the
3355.2|3.68|the tokens at same
3357.2|4.639|um
3358.88|5.439|so I'd say yes mixer of exp first model
3361.839|5.561|definitely gives you a little bit more
3364.319|5.881|trouble in terms of serving but the if
3367.4|4.919|you have high volume it's definitely
3370.2|4.599|worth it because you you you get much
3372.319|5.601|more efficient in in processing these
3374.799|6.601|tokens okay great um here I'll ask a few
3377.92|5.28|more um since we do have some extra time
3381.4|3.159|um but do let me know when you might
3383.2|3.44|need to
3384.559|4.52|leave so someone has ask asking
3386.64|4.6|specifically about the architecture um
3389.079|5.52|they want you to clarify does each layer
3391.24|7.0|include attention routing and experts or
3394.599|7.321|layers of attention then routing then
3398.24|6.0|experts ah okay uh let me try to find
3401.92|8.679|it
3404.24|10.48|um yes so um the so the architecture of
3410.599|8.361|mixol a * 7B is exactly the same as mol
3414.72|6.879|7B uh as I've shown here uh so in mral
3418.96|4.639|7B you first do for for each of the
3421.599|6.801|input you do normalization you do
3423.599|8.96|attenion residual Norm MLP residual so
3428.4|6.24|it's um attention followed by MLP okay
3432.559|4.28|and the only difference is in the MLP
3434.64|4.24|layer here so instead of instead of so
3436.839|4.561|after the attention layer and after the
3438.88|5.6|res the attention residual instead of
3441.4|6.32|doing MLP you do Ane MLP here so here
3444.48|7.2|instead of just using one uh uh or a
3447.72|8.359|couple uh one Matrix to process uh these
3451.68|6.879|uh this hidden uh this L representation
3456.079|4.401|you use eight experts well you you
3458.559|4.321|choose two out of eight experts to
3460.48|2.4|process
3463.96|6.079|that right that makes sense um all right
3468.839|2.72|let's
3470.039|6.161|see
3471.559|4.641|um give me a sec
3477.44|4.72|last
3479.2|5.919|um introduces extra load balancing
3482.16|4.32|losses and loss function discontinu uh
3485.119|3.68|disc
3486.48|4.72|discontinuities um did you run into any
3488.799|3.641|difficulties while training due to these
3491.2|3.08|um
3492.44|4.32|complications um yeah that that's a
3494.28|5.0|really great question so I think uh to
3496.76|4.0|to to try to clarify the question um my
3499.28|3.799|understanding is that when you're
3500.76|4.039|training uh mixture of experts models
3503.079|3.601|you definitely want each of your expert
3504.799|4.121|to be quite balanced
3506.68|5.96|in the sense that they handled a similar
3508.92|6.56|amount of uh tokens such that you're not
3512.64|4.88|uh like I guess uh I was waiting for the
3515.48|4.119|the slowest expert or the expert that
3517.52|4.16|handles the most um so yes you
3519.599|5.2|definitely need to uh do something to
3521.68|8.119|make the the the load uh balance a bit a
3524.799|7.841|bit better um in in trading but um uh I
3529.799|4.8|I we we didn't run into any any big
3532.64|4.959|troubles uh during training this this
3534.599|3.0|model
3538.48|7.2|and here's a question about R um here's
3542.799|4.841|the here when Ane approach would be
3545.68|5.28|preferred to a rag approach in a given
3547.64|7.199|domain um pros and cons
3550.96|8.52|Etc I I think these are athal so you can
3554.839|6.841|use Ane model to do rack um like so I I
3559.48|4.96|don't see why like I don't see why there
3561.68|6.159|should be a conflict between the two um
3564.44|8.919|yeah so so so like you can do uh dance
3567.839|9.0|model no rag dance model rag Moe no rag
3573.359|6.601|rag right and someone asked Can you
3576.839|5.041|potentially swap out one expert and
3579.96|3.8|insert a domain specific expert that
3581.88|7.0|wasn't trained on the same training data
3583.76|10.279|set like a customizable or modular
3588.88|7.28|uhe I see um I think that's possible uh
3594.039|5.921|given that you also you also need need
3596.16|6.919|to so so after you swap out one of the
3599.96|4.599|one of the experts and uh and and
3603.079|4.921|replace it with the domain specific
3604.559|5.081|expert uh but you after after you do the
3608.0|3.92|swapping you definitely need to train
3609.64|5.919|this model a bit more uh such that the
3611.92|6.48|ging layers know how to such as the
3615.559|4.921|gting layers know how to uh uh how how
3618.4|5.56|to route the that's that's you have a
3620.48|5.119|Med medical expert swapped in uh you you
3623.96|2.76|need to train your gting layers a little
3625.599|3.321|bit such
3626.72|5.24|it knows how to how to handle medical
3628.92|5.679|situations um and to basically treat
3631.96|4.599|this this replaced expert quite
3634.599|3.52|differently uh so I think it's totly
3636.559|4.52|possible and very exciting research
3638.119|4.68|Direction there there're being uh quite
3641.079|4.681|interesting research done all like
3642.799|5.161|merging and uh swapping and Franken
3645.76|3.4|merge these models uh so I think that's
3647.96|2.96|that's certainly some something
3649.16|4.159|something uh very exciting looking
3650.92|2.399|forward to
3654.599|5.52|it okay great I'll ask a two more zoom
3657.44|4.8|questions and that'll be it um so
3660.119|3.92|someone asked during training is mixture
3662.24|3.879|of experts less computationally
3664.039|3.161|intensive since the gradients would
3666.119|4.081|always be
3667.2|5.32|7B how do how do the gradients back
3670.2|7.879|propagate through the routing
3672.52|8.36|head so um if I go to the routing layer
3678.079|5.601|uh you will see that the um the the the
3680.88|5.88|TP so so all the operations here are
3683.68|6.52|differentiable so um the
3686.76|5.799|there is no there's no uh I guess like
3690.2|5.359|discrete operations such that the the
3692.559|4.681|the gradient just stops there uh so this
3695.559|5.921|thing this thing is entirely like end to
3697.24|6.079|end differentiable um uh sorry what's
3701.48|4.76|the first part of the question
3703.319|4.641|again you're asking if training Moes is
3706.24|5.28|less computationally
3707.96|5.879|intensive uh so the the cost of training
3711.52|6.319|is roughly proportional to the number of
3713.839|6.44|active parameters you have um um and so
3717.839|5.44|so it's roughly equivalent to training a
3720.279|5.481|13B um and but you incur some extra
3723.279|2.481|communication
3728.48|8.599|cost okay great um last question um um
3733.68|5.399|let's talk about even bigger models even
3737.079|6.28|if we're moving away from the Paro
3739.079|6.96|Frontier like those 8X 22 8x3 or even 8X
3743.359|5.96|100 plus spilling parameter models you
3746.039|5.601|see any further um serving challenges
3749.319|5.881|when one GPU cannot even hold a full
3751.64|8.199|expert after heavy
3755.2|5.919|quantization I see um yes so I I think
3759.839|5.041|if you have one
3761.119|9.041|GPU I think I would go for a dance model
3764.88|8.479|or uh um or or or a heavily quantized uh
3770.16|5.32|mixture of expert model um and about
3773.359|4.801|like what you said about U like having
3775.48|5.68|more module experts like having 128
3778.16|6.0|experts I think that's something super
3781.16|7.52|exciting uh because that basically
3784.16|5.919|allows you to specialize your um uh
3788.68|3.48|basically allows your experts to
3790.079|4.321|specialize a bit more um and that's
3792.16|5.399|always exciting you can always uh reduce
3794.4|6.399|the number of uh you you can always make
3797.559|5.48|the expert specialized um uh better uh
3800.799|4.121|and you you can pick basically allow
3803.039|4.08|giving your gating gating layers more
3804.92|5.159|power to choose like which experts are
3807.119|4.96|are the best for this token um I think
3810.079|4.72|for serving purposes that will
3812.079|4.72|definitely make things very very hard um
3814.799|7.361|even like even after having quantization
3816.799|7.201|if if you have 128 experts um then and
3822.16|4.56|potentially you you you we're talking
3824.0|6.24|about multi like having the the model
3826.72|6.399|model in multiple nodes that will make
3830.24|5.839|the well I guess both make the make the
3833.119|5.96|Implement implementation harder and also
3836.079|4.72|the uh and and also the communication
3839.079|3.681|cost higher so that's something you
3840.799|5.04|probably want to leave to a to a model
3842.76|6.44|provider uh through API like serving
3845.839|6.52|yourself but I think for like mix X
3849.2|4.919|model Mix A Time 7B is definitely after
3852.359|4.161|quantization is definitely very um very
3854.119|5.281|doable on on single
3856.52|5.839|GPU all right great thanks for answering
3859.4|5.439|u a bunch of questions from very curious
3862.359|6.641|folks um so thanks again Albert for the
3864.839|4.161|amazing talk and the time today