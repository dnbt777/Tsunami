start_time|end_time|text
1.76|3.56| All right, let's now take a look at some code examples. But before
5.32|3.9| that, I have a few slides I wanted to go through, just to
9.22|3.62| summarize, yeah, what we are going to take a look at in the
12.84|4.72| code. But then also to add a few things about multi layer
17.56|2.8| perceptrons that I didn't mention in the previous slides.
21.12|4.08| So I prepared two code notebooks, and I will also show
25.2|3.6| you some Python scripts as alternative. So in these code
28.8|2.98| notebooks, I implemented a multi layer perceptron with a
31.8|3.44| sigmoid activation and a mean squared error loss, and the
35.24|3.68| multi layer perceptron, the same one, but with softmax activation
38.92|4.66| and cross entropy loss. So there are, let's take a look at the
43.58|4.9| left hand side. There are two plots here. So one is showing
48.48|4.08| the loss for each mini batch. So you can see it goes down. That's
52.56|3.2| what you want to see the trend goes down. While we are training
55.76|2.88| it, it's a bit noisy, this is expected because it's on
59.36|4.32| stochastic gradient descent. So these updates are noisy. At the
63.68|5.56| bottom, I'm plotting the loss computed of like computing over
69.6|4.0| it over the whole training set. So after each training epoch,
73.6|2.6| I'm computing the loss of the whole training set. So this is
76.2|4.16| why it's smoother here. So you can see I'm training for 100
80.36|7.4| epochs. So x axis is the number of epochs. Actually, I think I
87.76|3.62| think I've probably wrote epoxy, I can't see always the bottom of
91.38|3.1| the slide, because there is like, for the pen, the color
94.48|4.16| bar, but I think that it says epoch. Anyways, so you can see
98.68|3.68| this is training nicely. But the accuracy is quite low, it only
102.36|5.04| reaches 90% training accuracy, 91% test accuracy. One good
107.4|3.0| thing about it is it's not overfitting. But if you recall
110.4|5.36| from the softmax regression lecture, we already achieved 92%
115.76|3.4| something using just softmax regression. So um, yeah, the
119.16|3.0| reason why I think this multi layer perceptron is not working
122.16|3.64| well, my suspicion is it's because the sigmoid activation
125.8|3.4| and the MSE loss are not a good combination. Like I outlined
129.28|4.88| earlier, when because the terms don't cancel so nicely compared
134.16|3.64| to softmax and cross entropy, or even sigmoid and cross entropy,
138.2|6.24| what happens is that we have the derivative of the sigmoid
144.44|4.52| function in the chain rule. And this will be a number smaller
148.96|3.4| than one, which can be a little problematic. Because yeah, you
152.36|3.16| may have like these small numbers multiplying things with
155.52|2.04| a small number, and then you have a vanishing gradient
157.56|2.38| problem. So you make the gradient very small, and then
159.96|2.64| maybe you don't update, that could be one problem, I can see
162.6|4.56| with that. If you use the cross entropy loss, um, it's a little
167.16|2.8| bit less of an issue. So cross entropy loss is usually better
169.96|3.04| with sigmoid activation, or can also use a softmax activation,
173.0|3.4| which I would recommend, because we have, yeah, a mutually
176.4|3.36| exclusive classes. So like we talked about, why not also using
179.76|3.04| softmax activation, you can play around, actually, you can take
182.8|2.84| this good example and change softmax to sigmoid, you will see
185.64|3.8| there's not a big difference, though. But on here, here on the
189.44|3.52| right hand side, um, you can see though, what the main takeaway
192.96|3.16| is, that, again, the loss goes down, that's what you want to
196.12|3.1| see. But what you can see is also the training accuracy is
199.22|5.14| 99%. And the test accuracy 90, almost 98%. There's a little
204.36|3.44| bit of overfitting, we will talk about overfitting after the
207.8|4.56| Jupyter Notebook video in the next video. But yeah, what you
212.36|3.2| can see is the cross entropy loss actually works much better
215.56|5.04| here than the MSC loss. Um, yeah, a few more things I
220.6|3.48| already talked about dead neurons. So we can also use the
224.08|2.4| relu activation function, which is very popular, you can
226.48|4.94| actually try it on in the code notebooks. It's, like I said,
231.42|2.58| probably the most popular activation function, I use it
234.0|3.36| all the time for most of my stuff, because it works well
237.36|3.88| usually. However, theoretically, there's this problem that it
241.24|3.16| might have this dead neuron problem, like the relus might
244.4|3.04| die during training, that happens if the input is too
247.44|5.04| large or too small, so that the net input is yes, negative. So
252.48|4.12| if you have a large input and a negative weight, then yeah, the
256.6|3.44| net input will be negative. Or if you have a positive weight,
261.32|5.24| and are very small input, very negative input, then also the
266.56|5.12| net input will be negative. And if it's so negative, that it's
271.68|3.8| extremely negative, then maybe it will never be possible to
275.48|5.4| escape this problem. Because even though you have the
280.88|2.92| multivariable chain rule, you combine certain things, you may
283.8|3.2| never be able to reach this threshold have a positive
287.0|2.96| number. So you will never maybe update a certain weight, and
289.96|3.84| then you end up with this dead neuron. However, like I said,
293.84|3.84| it's maybe not necessarily bad, because if you have a lot of
297.68|4.44| neurons, your network has a tendency to overfit, then yeah,
302.12|2.92| removing some neurons removes some parameters, and it can
305.04|4.96| maybe help actually achieving a better performance because it's
310.0|4.36| kind of simplifying the network like pruning excessive weights.
316.88|3.12| Also, one advantage of value compared to let's say, the
320.0|3.8| sigmoid or 10 h function is that it suffers less from this
323.8|2.4| vanishing gradient problem that I explained on the previous
326.2|2.96| slide, because the gradient is either zero or one. So you
329.16|3.0| either have the dead neuron, in the worst case, or no gradient
332.16|2.2| in the worst case. But in the other case, if you have a
334.36|3.36| positive net input, you always have a strong gradient of one,
337.96|3.92| but it could technically leads to exploding gradient problems
341.88|3.0| if you have some values that are greater than one from other
344.88|5.0| parts of the network. But yeah, I will talk more about vanishing
349.88|4.76| and exploding gradients when we talk about that would be a good
354.64|2.3| point for recurrent neural networks. We will talk about
356.94|2.7| that when we talk about recurrent neural networks later.
359.96|2.32| But yeah, in general, just wanted to summarize these few
362.28|0.6| points.
364.16|6.8| Another thing is, shall we use a wide or deep multilayer
370.96|2.96| perceptron? So if we have to choose, which one would be
373.92|5.08| better. So let's say we could make a multilayer perceptron,
379.04|3.4| when we only have a small number of units in each layer, let's
382.44|4.36| say, five in each, but have a lot of layers, or we could make
386.8|3.8| a very wide network where we have, let's say, only one hidden
390.6|5.52| layer. But then let's say we have 100 units in that layer. So
396.12|3.8| what is preferable? I mean, theoretically, there has been
400.36|6.0| some work on the universal approximation theory or theorem.
406.36|2.92| In that case, I think it's a theorem, even I haven't actually
409.28|3.24| read these papers, I only know they exist. So there are
413.52|6.64| theorems showing that multilayer perceptron with one arbitrarily
420.32|6.0| large hidden layer can already approximate arbitrary functions.
426.36|3.52| So that case, if a multilayer perceptron with only one very,
429.88|2.64| very big hidden layer can already do that, why would we
432.52|5.68| even care about having multiple layers? I mean, the ability to
438.2|5.52| approximate arbitrary function doesn't mean it's practical to
443.72|2.4| train such a network. So first of all, there are some
446.12|2.76| challenges with training, also just large matrix
448.88|4.4| multiplications. But then also, you need more parameters really,
453.6|5.6| to have the same expressiveness as using more layers, with fewer
459.2|2.44| number of parameters, if you have fewer parameter parameters,
461.64|2.84| but more layers, you have more combinatorially more
464.6|2.8| combinations possible. So this way, you have the same
467.4|3.92| same expressiveness as with multilayer perceptron with only
471.32|4.56| few large hidden layers. But then if you have a lot of these
476.36|3.88| layers, then you may suffer from vanishing and exploding gradients
480.24|2.28| that I just mentioned on the previous slide. So usually,
482.52|5.4| there's a trade off in practice. For multilayer perceptrons, you
488.4|3.48| never really go deeper than one or two layers, because then you
491.88|3.28| have like these vanishing, exploding gradient problems. But
495.16|4.52| later, we will talk about convolutional networks, and other
499.68|3.4| types of networks where we can actually go deeper, without
503.08|2.56| having these exploding and vanishing gradient problems. So
505.64|3.84| there are some tricks. And this is basically what deep learning
509.48|5.2| is about. It is about designing things cleverly, so that we can
514.68|2.88| go deeper without having vanishing, exploding gradient
517.56|2.52| problems for multilayer perceptrons, because it's not
520.08|3.04| really a deep learning architecture. One or two hidden
523.12|2.72| layers is enough, you will notice if you try it, to
525.84|2.6| implement a multilayer perceptron with three or four
528.44|3.76| layers, you will usually notice it doesn't train so well anymore,
532.2|3.36| because the arrows don't back propagate so far anymore. So a
535.56|3.12| practical consideration is usually using one or two hidden
538.68|2.54| layers in a multilayer perceptron. If we talk about
541.22|4.02| convolutional layers, we can go up to 500 or maybe 500. But
545.36|5.64| let's say 150 200. That's even very common these days. But
551.0|4.28| convolution networks are topic for another lecture. So yeah,
555.28|4.08| like I said, just to summarize again, we can achieve the same
559.36|3.48| expressiveness with more layers, but fewer parameters compared to
562.84|5.4| having like one large layer with a lot of parameters. But also,
568.24|2.6| what's nice about having more layers than compared to one is
571.04|2.96| that we have some form of regularization, because later
574.0|3.16| layers are constrained on the behavior of earlier layers. So
577.16|3.48| we have also, in that way, having more layers can also,
580.64|4.96| sometimes in theory, at least be helpful. But then, like I said,
585.6|2.88| we have the vanishing exporting greater problems. And later, we
588.48|5.56| will talk more about that. So now it's time that I show you
594.06|3.06| the code example. So let me pause this video and then start
597.12|10.56| my Jupyter Notebook.