start_time|end_time|text
5.6|7.76|hello everyone today we have a NZ yes uh
9.679|5.321|from hugging base um who is working on
13.36|3.16|AI safety and Alignment using
15.0|5.279|reinforcement learning with human
16.52|5.999|feedback um she's an expert in the space
20.279|5.0|of large language models
22.519|5.401|and their
25.279|5.561|evaluation um before hugging face she
27.92|5.799|led a team of researchers at sales SCE
30.84|5.84|focused on building robust um natural
33.719|5.641|language generation systems based on LMS
36.68|5.66|and she got her PhD at UT Austin in
39.36|6.199|computer science so everyone
42.34|3.219|[Music]
47.199|5.441|welcome great thanks for having me uh so
50.32|4.559|the title of my talk today is recipes
52.64|5.68|for training helpful chat
54.879|5.64|Bots um so here's the introduction uh I
58.32|4.16|was part of this team called the h 4 at
60.519|3.761|hugging face and today I'll you know
62.48|4.679|walk you through what we built you know
64.28|4.6|how we decided on you know what we need
67.159|3.481|for building that and so essentially
68.88|4.0|what we wanted to build and the goal of
70.64|5.24|the team and the project since earlier
72.88|5.32|this year was to figure out a recipe for
75.88|4.04|H4 which stands for helpful harmless
78.2|5.04|honest and Huggy because it's hugging
79.92|5.239|face chatbot um and so like you know the
83.24|4.04|ingredients essentially work to like you
85.159|3.96|know figure out what kind of data sets
87.28|3.44|do we need for supervised Trine tuning
89.119|3.561|and RL
90.72|5.0|um and we wanted to like you know not
92.68|4.719|worry about pre- chaining instead take a
95.72|3.92|open- source pre- chain model and
97.399|4.281|recreate the secret source of alignment
99.64|4.68|on it um and the procedure that we
101.68|4.84|wanted to follow and replicate on open
104.32|3.839|source is this figure that I'm pretty
106.52|3.4|sure most of you are familiar with at
108.159|5.0|this point is like from this instruct
109.92|6.479|gbd paper from openi uh which shows
113.159|5.121|three steps uh I'm going to go into a
116.399|4.161|bit more detail on this because the
118.28|3.759|slide is much smaller over here uh but
120.56|3.8|this is what the outline of the talk
122.039|4.201|looks like um I'll be getting to detail
124.36|3.92|of like you know how did we decide what
126.24|4.12|kind of data how much data and all the
128.28|5.8|details of the data for supervised fine
130.36|5.92|tuning um then similarly for rlf um then
134.08|4.72|I'm going to talk about distillation of
136.28|4.76|language model alignment um then
138.8|5.24|experiments with different helpfulness
141.04|5.919|recipes finally talk about evaluation of
144.04|4.52|these models and quirks of using GPD 4
146.959|4.201|as an
148.56|4.64|evaluator okay so this is kind of like
151.16|4.76|you know what a overall recipe that
153.2|4.88|instruct gbd paper from open I put
155.92|4.8|forward as you know the steps for
158.08|4.4|training a chatbot um so the first step
160.72|3.76|over here is to do supervised
162.48|4.16|fine-tuning essentially like you know
164.48|4.32|you're doing fine tuning with human
166.64|4.28|instruction demonstration data so the
168.8|4.799|input and the output are both given by
170.92|4.88|humans the step two is like you know the
173.599|4.36|input is given by a human the output
175.8|3.96|comes from models and then the human
177.959|3.881|just rates thumbs up thumbs down or
179.76|3.52|Banks them and then you train a reward
181.84|3.679|model which is essentially just a
183.28|4.239|classifier and then the final step three
185.519|4.201|is doing fine-tuning using that reward
187.519|4.28|model with uh with reinforcement
189.72|4.239|learning um and so the way I'm looking
191.799|4.72|at is like step one is more for like you
193.959|4.92|know making a model into a helpful
196.519|4.36|chatbot and the steps two and three are
198.879|4.92|essentially trying to add those guard
200.879|4.761|rails in place for harmlessness so in
203.799|4.681|let's get started with talking about
205.64|6.04|helpfulness and most of my uh talk today
208.48|5.8|will be focused on the step one um so
211.68|4.4|the let let's start uh diving deeper
214.28|3.44|into this and let's started with like
216.08|3.84|you know the data set like how do we
217.72|5.28|decide what we need for doing the
219.92|5.08|supervised fine tuning so like you the
223.0|4.319|data set for helpfulness for supervised
225.0|4.72|fine tuning looks somewhat like this
227.319|4.56|this is from the self- instruct paper if
229.72|4.2|you aware of that from end of last year
231.879|4.56|so you have something that we call as a
233.92|5.039|task which then has an instruction which
236.439|4.8|is essentially a request by a user
238.959|4.48|asking the model model to like fulfill a
241.239|4.681|like give a response to certain task and
243.439|4.8|that follow that is followed by a input
245.92|4.36|and output the input in this case is
248.239|4.36|optional it could just be part of the
250.28|4.039|instruction um and then the output is
252.599|3.76|the expected output that the model
254.319|4.32|should generate but while we are doing
256.359|4.041|this training the human provides the
258.639|4.84|expected output that the model would
260.4|5.16|have generated in the actual test case
263.479|4.641|um and so here the input and the output
265.56|4.72|are called instance or demonstration or
268.12|4.799|completion and that's why this is called
270.28|2.639|instruction
273.12|4.84|demonstration uh so this is kind of like
275.36|4.36|just a high level landscape of what
277.96|4.239|these data sets for instruction
279.72|4.039|demonstration look like um and you must
282.199|4.241|have you know been familiar with at
283.759|5.121|least some of these um and like you know
286.44|5.52|the way I'm try to put this is on this
288.88|5.879|line where on one side I'm showing data
291.96|4.959|sets that were generated using models or
294.759|4.361|more powerful language models and so
296.919|4.28|they are more synthetic data sets on the
299.12|4.079|right I'm showing like human written
301.199|4.161|data sets and so these are model these
303.199|4.601|are uh these are data sets that the
305.36|4.96|human wrote the input as well as the
307.8|4.2|expected output and so examples of these
310.32|3.76|are like you know so the surge instruct
312.0|5.24|is the data set that we at hugging phas
314.08|5.959|H4 you know contracted with surge this
317.24|4.799|company that you know that basically had
320.039|3.761|U contracts with annotators that were
322.039|4.0|writing the inputs and outputs but we
323.8|4.56|had to give them all the specifications
326.039|3.681|of what kind of data we need um and then
328.36|3.08|you must have heard of like you
329.72|3.319|obviously open assistant is this other
331.44|3.479|CommunityWide effort where you know
333.039|4.681|people contributed manually writing
334.919|4.72|inputs and outputs similarly with Dolly
337.72|3.52|um and then on the other end you can see
339.639|3.441|like you know the self- instruct data
341.24|3.72|set I'm going to like dive into some of
343.08|4.88|these how are these synthetic data sets
344.96|5.12|created for uh for helpfulness or for
347.96|5.12|supervised fine
350.08|4.76|tuning so one of the examples of how
353.08|3.64|this synthetic data is created is in
354.84|4.199|this self- instruct paper which is
356.72|6.08|called bootstrapping the data so in this
359.039|6.641|case they start with 175 C task that is
362.8|5.08|you know a 175 like a very small uh data
365.68|4.6|set of examples where the manually
367.88|4.56|written inputs and outputs from humans
370.28|4.0|those are added to a task pool then a
372.44|4.12|language model like you know basically
374.28|3.479|you bootstrap by giving that language
376.56|3.56|giving that to the language model in a
377.759|5.16|few short setting and ask it to generate
380.12|4.88|more data like that um and then you have
382.919|3.761|another language model that does this
385.0|4.16|task classification like you know what
386.68|5.76|kind of task is this um is this sample
389.16|4.92|or example belonging to and finally it
392.44|3.44|also does this more fine grain
394.08|4.239|classification as to like you know does
395.88|4.439|it have you know output first or does it
398.319|3.6|require input first and so on and
400.319|3.561|because this is synthetic data and
401.919|4.361|created in this like a very scalable way
403.88|5.719|you also have to do a lot of filtering
406.28|6.0|to make sure that it is very high
409.599|4.641|quality so another way of generating
412.28|4.72|this kind of synthetic data is what
414.24|5.2|Ultra Chad did and in this case they had
417.0|5.08|like a human in the loop process so
419.44|4.599|human would like you know look up like
422.08|4.36|either you know search Wikipedia or
424.039|4.88|something um and then come up with you
426.44|5.12|know topics that they want to generate
428.919|4.481|data for and then you know ask the model
431.56|4.24|like provide it with the required
433.4|3.799|material that would be needed for you
435.8|3.32|know coming up with say question
437.199|4.201|answering or summarization or any of
439.12|5.24|these specific tasks um and then give it
441.4|5.199|to a more powerful model like chb gbd4
444.36|4.36|in this case it was J gbd and then or
446.599|4.32|actually gbd4 and then you kind of like
448.72|3.879|you know keep doing these Loops of like
450.919|3.201|you know giving the material to the
452.599|3.121|model and say like come up with
454.12|3.84|questions and answers of on this
455.72|4.44|particular task using all this material
457.96|3.919|and then you know then the human looks
460.16|3.56|at it and then keeps squaring it and
461.879|3.841|refining it more and more so this is
463.72|3.879|another way of creating synthetic data
465.72|3.72|obviously this has a human sitting there
467.599|4.641|and doing a lot more filtering in the
469.44|4.92|process um then there's another one
472.24|3.76|which is like even less human involved
474.36|5.04|which is role playing and this is the
476.0|5.24|camel data set uh in this case all the
479.4|5.12|you all that the human does is like come
481.24|5.679|up with an idea of what task or what you
484.52|4.04|know example they want so at a high
486.919|3.801|level it would be like develop a trading
488.56|5.28|bot for the stock market and there would
490.72|5.479|be two llms one would be role playing as
493.84|4.88|a AI assistant the other would be role
496.199|4.641|playing as a AI user and then they
498.72|4.599|basically just specify the task and like
500.84|4.68|let these two Bots chat with each other
503.319|4.761|and create a conversation data set which
505.52|5.72|is again like a synthetic data set for
508.08|3.16|supervised fine tuning
512.039|3.68|so this is kind of like you know just
513.68|3.719|going back to this you know landscape it
515.719|3.44|looks like you know there there people
517.399|3.961|have been very creative and how do we
519.159|4.481|get you know very high quality data
521.36|4.52|quickly without spending a lot of money
523.64|3.96|um and because humans are inefficient
525.88|3.72|and expensive and so these are like you
527.6|3.919|know some examples that we looked at but
529.6|4.84|on the other hand we also cannot like
531.519|5.201|you know underestimate how good quality
534.44|5.76|like the manually created data sets are
536.72|4.92|and so we at um hug phase decided to
540.2|3.079|like you know go with everything like
541.64|3.92|very manual and like you know have
543.279|4.401|humans do both the input and output also
545.56|4.64|go figure out like what are the you know
547.68|4.44|essential documents or you know other
550.2|3.6|material they need for coming up with
552.12|4.24|creating this data
553.8|4.32|set but when we started doing that we
556.36|4.159|were earlier in the year so this is back
558.12|3.88|in January or February of this year and
560.519|4.241|this is what the landscape looked like
562.0|4.519|at that time um and so there was very
564.76|4.639|little data sets available a lot of
566.519|5.081|these were mostly synthetically created
569.399|4.12|um so we wanted to like you know kind of
571.6|3.44|Leverage What was existing out there but
573.519|3.361|we also had to make some really
575.04|3.72|important decisions CU we going to like
576.88|3.92|P pay money and like make sure that the
578.76|4.16|data that we collect is actually useful
580.8|4.279|for building the model and you know the
582.92|4.56|applications that are built on top of
585.079|4.921|it so these are the learnings that we
587.48|4.52|had from the past papers that were you
590.0|4.6|know creating these supervised F data
592.0|4.76|set we knew that the data set has to be
594.6|3.799|in the range of tens of thousands of
596.76|4.4|examples so this is from the self-
598.399|5.241|instruct data said um and we also knew
601.16|3.88|that you know these U models that are
603.64|4.0|trained on this data set show
605.04|4.76|diminishing returns after just a few
607.64|3.8|thousand high quality instructions so
609.8|3.4|you don't need a lot and then it
611.44|4.0|saturates very quickly so these are the
613.2|3.84|two findings that we had when we started
615.44|3.36|to like go collect data set for
617.04|4.64|supervised F
618.8|5.24|unit um but we also had to give some
621.68|4.399|very fine grain specifications on what
624.04|3.72|we want for our data set um in
626.079|3.641|particular we had to decide what is the
627.76|3.48|task distribution we want for the data
629.72|3.4|that we are collecting I mean we know
631.24|4.76|it's tens of thousands but how many
633.12|4.519|thousand of what task right the length
636.0|3.6|distribution like you know should the
637.639|4.561|prompt have a certain length is that
639.6|4.08|even an important factor um and one
642.2|3.16|thing is that we wanted we we had
643.68|3.56|decided that we want to make it high
645.36|3.88|quality and human written but then there
647.24|4.68|were like options on that as well we
649.24|6.12|could go with external vendors like sge
651.92|5.88|scale AI AWS CR and so on or we could
655.36|4.32|hire our own contractors from upwork and
657.8|4.32|mtk and so those were like decisions
659.68|5.399|that we had to make so let's look at
662.12|6.56|each of these one by one so because we
665.079|6.041|were recreating this instruct GPT recipe
668.68|3.8|for this helpful chatbot we wanted to
671.12|3.719|like you know take inspiration from
672.48|4.2|their task distribution so on the left
674.839|4.8|I'm showing like the task distribution
676.68|4.64|that instruct gbd did for uh open ey did
679.639|3.601|for the instruct gbd paper as you can
681.32|4.639|see that generation is like you know the
683.24|4.56|majority of it uh followed by some you
685.959|3.921|know some of these open-ended tasks and
687.8|4.08|brainstorming tasks and so on and these
689.88|4.959|are examples of like what prompts of
691.88|4.759|each of those look like so we decided to
694.839|3.12|like you know just go with that but
696.639|3.281|instead you must have noticed that
697.959|4.32|there's this category called other in
699.92|4.28|their table and we obviously don't know
702.279|4.481|what that was but so we decided to
704.2|4.56|replace that with code so essentially it
706.76|3.519|would be like debugging asking quite
708.76|4.319|clarification questions about the code
710.279|4.521|it's like code plus natural language um
713.079|3.32|so this is how what our final
714.8|4.32|distribution looked
716.399|4.801|like U the second question was the
719.12|3.719|length distribution so we also had to
721.2|3.28|like you know figure out like you know
722.839|3.361|how important is the length and should
724.48|3.88|we like you know have a certain length
726.2|4.28|distribution then we ask uh these
728.36|4.919|companies to collect data for us so we
730.48|4.96|did a pilot study with s scale Ai and
733.279|3.641|AWS Sage maker Ground Road which is more
735.44|3.44|like a managed service so it's very
736.92|5.479|different from MK and they have very
738.88|6.48|high quality um human uh humans like
742.399|4.88|basically writing these examples um and
745.36|4.479|so I wanted to like just highlight that
747.279|5.0|you know this are the first rows here
749.839|4.0|show what the instruct gbd length
752.279|3.281|distribution looks like and as you can
753.839|3.521|see this is obviously the full data set
755.56|4.0|this is more like pilot so like the
757.36|5.4|counts are much smaller uh but you can
759.56|4.519|see like the maximum is uh 248 and as we
762.76|3.96|know like that's was like the standard
764.079|4.401|Contex size in the beginning of the year
766.72|3.4|um and then you know there is obviously
768.48|3.919|like even the mean and you know that
770.12|4.12|much it's not like basically it's more
772.399|3.841|or less you know in the range but if you
774.24|4.68|look at you know these examples from
776.24|5.52|surge AWS a scale AI there's very high
778.92|6.279|variance so for example AWS stage maker
781.76|5.4|the maximum prompt length is 1036 but
785.199|4.841|then like you know the mean is just
787.16|5.72|54 um and on the other hand with surge
790.04|5.239|the maximum length is 500 but then the
792.88|4.28|mean is much like you know one 104 so
795.279|3.24|it's like more in the range of what we
797.16|4.359|would expect from like you know this
798.519|4.601|difference in instruct GPD and similarly
801.519|4.12|with scale AI we found that you know
803.12|5.719|there are um promps were just very very
805.639|4.681|U short um and so just based on this we
808.839|3.281|said that you know okay we should
810.32|3.639|probably just go with search cuz you
812.12|4.399|know that seems like something that is
813.959|4.68|more um you know in the range like not
816.519|4.521|very high
818.639|4.921|variance so we ended up collecting
821.04|5.12|10,000 instruction demonstration pairs
823.56|4.24|from Serge and this is what the task
826.16|3.2|distribution looked like so this very
827.8|4.159|much follows the task distribution
829.36|4.36|instruct gbd um except for the coding
831.959|3.521|part which was like the other category
833.72|3.84|over there and these are the number of
835.48|4.32|examples we collected for each of these
837.56|4.079|tasks um and and year over year I'm
839.8|4.2|showing like you know the average length
841.639|3.681|for each of these task categories um and
844.0|3.399|one thing I wanted to highlight was
845.32|5.16|which was very surprising to me is that
847.399|5.601|the chat is actually one of the shortest
850.48|4.479|prompt length categories which but for
853.0|4.519|open AI that is actually one of the
854.959|5.161|longest prompt plan categor so uh which
857.519|4.081|was very interesting and so um obviously
860.12|3.639|like you know at that time we did not
861.6|3.72|think much about it but when we like
863.759|3.52|started training models and started
865.32|3.959|looking at the evaluation results we
867.279|3.36|were kind of like you know if had to go
869.279|3.881|back and change things how would we
870.639|4.161|change that um and so these were like
873.16|4.119|things that we started you know looking
874.8|5.36|at more carefully after we had already
877.279|2.881|collected the data
880.199|5.64|set um so here are examples of what that
883.48|5.0|data set looked like U you know
885.839|4.161|classification generation brainstorming
888.48|3.76|I'm sure you all must have seen at least
890.0|4.279|some of these kind of examples of
892.24|4.0|instruction demonstration data sets so
894.279|4.401|it's very much like it has everything
896.24|4.8|that you can expect from like NLP time
898.68|6.44|kind of task but also more open-ended
901.04|4.08|chatty um task as
907.24|5.92|well okay so here are like some details
910.32|5.439|about the task force that was used by
913.16|5.16|sege to generate this data said uh we
915.759|4.561|requested a us-based task force mainly
918.32|4.639|because we like I said we just wanted to
920.32|4.68|replicate what instruct gbd was doing
922.959|3.88|and based on anthropic and open a paper
925.0|4.44|it seemed like they they prefer going
926.839|5.401|with the us-based task force um the
929.44|6.04|gender roughly equally divided and the
932.24|4.8|age range was also very U you know very
935.48|4.919|it was like a big range going all the
937.04|5.4|way from 19 to 62 um and then people had
940.399|4.12|like you know uh education background
942.44|4.079|ranges from technical degree to PhD so
944.519|4.8|PhD was mainly for tasks like math
946.519|2.8|coding and so
949.92|5.399|on okay so now I wanted to like switch
952.959|5.041|gears a little bit and talk about this
955.319|5.681|diff this data set that we collected for
958.0|4.88|ourl or for human preferences before I
961.0|4.04|get into like you know the experiments
962.88|4.24|we ran with this supervised funing data
965.04|4.88|set and what results we
967.12|5.079|got so again over here while we were
969.92|3.96|collecting human preference data set we
972.199|4.161|had to come up with what are the
973.88|4.24|specifications of these data sets so
976.36|4.279|again just to like contrast this with
978.12|4.639|how is it different from sft the sft
980.639|4.401|data set both the input and the output
982.759|4.52|are written by humans in this case the
985.04|4.12|human writes the input the output comes
987.279|4.48|from Models which is respon respes but
989.16|4.679|then the human just ranks or rates them
991.759|4.76|on a certain
993.839|3.8|scale U so yeah essentially we had to
996.519|4.521|decide like what is the task
997.639|5.361|distribution looks like for rlf data is
1001.04|3.919|it going to be same as supervised fine
1003.0|3.92|tuning what about the length
1004.959|3.961|distribution and should we do like
1006.92|4.56|single Turn versus multi- turn so in
1008.92|4.52|instruct GPT it was mainly single turn
1011.48|3.52|so if we trying to replicate instruct
1013.44|2.759|gbd we would have to go with single term
1015.0|3.279|but if you're you know trying to
1016.199|4.841|replicate something like Chad gbd it
1018.279|4.48|would have to be like a multi-t dialogue
1021.04|3.72|um and then we had to also like you know
1022.759|4.121|decide on these dimensions of like
1024.76|4.0|helpful helpfulness honesty and
1026.88|4.64|harmlessness so these are like the HHH
1028.76|5.84|that entropic follows like um openi puts
1031.52|3.08|it as like helpfulness
1037.6|3.88|trifula is individually or are they
1039.88|3.4|going to rank them and what are the
1041.48|4.68|implications of like you know us
1043.28|5.8|deciding one way or the
1046.16|6.36|other so we started by doing
1049.08|5.36|um pilot study again so we we took 300
1052.52|3.519|prompt from the self- instruct data set
1054.44|4.4|the data set that was released end of
1056.039|5.201|last year um and then you know gave it
1058.84|4.64|uh generated model responses from our
1061.24|4.92|models and then gave it to data vendors
1063.48|4.76|to like rate the responses of the models
1066.16|4.6|and we use this anthropic template on
1068.24|4.48|the left which is essentially asking the
1070.76|4.039|mo asking the human choose the most
1072.72|3.439|helpful and honest response and then you
1074.799|4.441|know these are the responses from like
1076.159|5.481|Model A and model B and this is a scale
1079.24|4.679|which is also working as like sort of a
1081.64|5.68|ranking thing in the sense that 1 to
1083.919|6.841|four is like decreasingly Model A and 5
1087.32|6.32|to8 is increasingly model
1090.76|5.08|B um and also like you know one other
1093.64|4.56|thing we had to decide about is like how
1095.84|4.199|much data should we collect um and so
1098.2|3.719|again this is from the instruct GPD
1100.039|4.081|paper and as you can see like you know
1101.919|4.12|they have like the train and validation
1104.12|4.039|splits for each of the three steps which
1106.039|4.601|are the sft training the reward model
1108.159|5.041|and the Poo um and this one is in the
1110.64|4.32|order of tens of thousands and like over
1113.2|4.44|overall this combined which is like you
1114.96|5.12|know this process of rlf comes up to
1117.64|2.44|about
1122.32|6.12|100,000 great okay so then once we got
1125.4|5.08|this pilot study data back we sat down
1128.44|3.96|and we wanted to also like you know so I
1130.48|4.559|looked at it manually and I felt that I
1132.4|4.88|did not agree with most of the answers
1135.039|4.52|that you know the annotators from each
1137.28|4.12|of these companies were providing and so
1139.559|4.161|I was kind of like you know I don't
1141.4|3.759|think this is high quality at all uh so
1143.72|3.16|what I decided is like you know I told
1145.159|4.281|my team let's go and like you know rate
1146.88|4.84|it within ourselves and then you know we
1149.44|4.56|we basically rated like about 100
1151.72|4.64|examples or so um and we followed like a
1154.0|5.24|similar template of like 1 to 4 and 5
1156.36|4.92|to8 and it basically the output like you
1159.24|3.72|know the takeaway was that even we did
1161.28|3.759|not agree amongst each other so
1162.96|4.0|essentially like our models earlier in
1165.039|3.76|the year were so bad you were
1166.96|3.04|essentially breaking tag like
1168.799|3.481|arbitrarily like you know you're
1170.0|4.36|deciding between like should it be like
1172.28|3.16|you know three versus like seven or
1174.36|2.799|something like that so if they're
1175.44|4.359|equally bad it's hard to like decide
1177.159|4.121|which one is better right and so we were
1179.799|3.76|kind of like breaking some of these ties
1181.28|4.16|arbitrarily and so uh as you can see
1183.559|3.761|like you know there was barely any like
1185.44|3.84|you know agreement or correlation among
1187.32|4.28|our outputs and then you know when I
1189.28|4.08|aggregated that and you know looked at
1191.6|4.12|you know how well do we correlate with
1193.36|4.04|like for for example Surge and scale and
1195.72|4.319|so we decided like you know scale AI we
1197.4|4.639|had like more um like the maximum
1200.039|4.201|overlap was with scale compared to like
1202.039|2.201|say
1204.72|5.48|surge okay so we ended up collecting
1207.84|4.719|20,000 dialog so we decided to go with
1210.2|4.16|multi-turn um and so we want because it
1212.559|4.36|was multi-turn you would have like
1214.36|4.199|20,000 overall dialogues but the number
1216.919|3.481|of prompts would be 880,000 so there
1218.559|4.0|would be each dialogue would have about
1220.4|3.759|four turns on an average so like you
1222.559|3.761|know a human would prompted the model
1224.159|4.201|would respond a human would like rate
1226.32|4.08|the response and then you know ask the
1228.36|3.559|follow-up question and then again the
1230.4|4.36|model would like you know generate two
1231.919|4.721|responses and that is how it would go on
1234.76|4.88|um and so the task distribution we
1236.64|4.6|decided to follow was um a little bit
1239.64|4.159|different from what we had for
1241.24|4.64|supervised fine tuning um and the reason
1243.799|5.921|behind that was that we wanted to focus
1245.88|5.799|more on tasks that were like factual so
1249.72|4.4|that uh you know essentially this is
1251.679|4.081|more about making the model learn like
1254.12|3.72|between positive and negative signals so
1255.76|3.2|making the model like discriminate
1257.84|3.0|between between like you know what is
1258.96|4.079|facture what is not what is helpful what
1260.84|4.719|is not and what is harmless and what is
1263.039|4.481|not um and like you know for for example
1265.559|3.561|task like generation and brainstorming
1267.52|3.159|there's no one correct answer like you
1269.12|3.96|know everyone can come up with like
1270.679|4.041|different list or recipes and you know
1273.08|3.64|it's hard to say is this the best answer
1274.72|4.04|is the most helpful answer but if you
1276.72|4.24|ask like a factual question it's like
1278.76|3.96|very clear what is correct and what is
1280.96|3.839|not um so that was kind of like a
1282.72|3.839|reasoning behind doing this um and so
1284.799|3.321|this is a task distribution that we came
1286.559|3.881|up with for collecting the human
1288.12|5.159|reference data
1290.44|5.119|set also about the length because we are
1293.279|3.76|doing this in a multi- setting and so we
1295.559|3.761|wanted to make sure like you know the
1297.039|4.201|entire dialogue could fit into like the
1299.32|3.359|context line of the models we have
1301.24|3.48|decided to like you know ask them to
1302.679|3.081|keep the overall dialogue to be shorter
1304.72|4.319|than
1305.76|5.56|248 uh tokens um and then it was multi-
1309.039|4.52|turn with an average of four turns per
1311.32|4.239|dialogue um then obviously we had to
1313.559|3.961|also select on the dimension of like
1315.559|5.641|whether we are going for like helpful
1317.52|5.48|over harmless or you know honesty so we
1321.2|3.839|followed this instructions from this
1323.0|5.039|openi guidelines I'm not sure if I can
1325.039|5.721|pull this up that would be
1328.039|5.961|nice okay
1330.76|5.279|great but yeah so open AI has this um
1334.0|4.08|document which is public of like
1336.039|4.721|labeling instructions that they shared
1338.08|3.92|with their annotators um and so they
1340.76|3.519|have obviously like I said they have
1342.0|4.279|helpful truthful and harmless but then
1344.279|4.361|they also have this thing how do I
1346.279|4.28|scroll down okay
1348.64|3.88|so they have definitions on what does
1350.559|3.681|what do they mean by helpfulness what do
1352.52|4.279|they mean by truthfulness and what do
1354.24|5.24|they mean by harmlessness so in our case
1356.799|4.601|because our models were not as good we
1359.48|4.16|decided to focus on helpfulness and
1361.4|4.96|truthfulness and when they had to break
1363.64|5.72|ties open AI says that you know choose
1366.36|6.72|truthfulness over helpfulness over your
1369.36|3.72|so like let me see that where is
1375.559|4.401|that um
1383.36|4.64|yeah so they wanted to like prioritize
1386.32|3.16|harmlessness and truthfulness over
1388.0|3.36|helpfulness but we went with the other
1389.48|4.72|way around we said we wanted to like
1391.36|4.679|prioritize helpfulness over honesty or
1394.2|3.56|harmlessness because I mean we weren't
1396.039|4.041|even focusing on harmlessness because we
1397.76|4.08|just wanted to get a model to a certain
1400.08|5.04|capabilities before we start thinking
1401.84|5.16|about that uh but yeah this is really a
1405.12|4.039|very good document and like you know
1407.0|4.76|defines what should the annotator be
1409.159|4.321|looking at and how do they decide um
1411.76|4.039|when the moral responses are very close
1413.48|4.72|how do they break those
1415.799|4.36|dieses um and for like you know deciding
1418.2|4.359|between what kind of template should be
1420.159|4.161|use for an collecting these annotations
1422.559|3.401|we started off with anthropic template
1424.32|4.0|that I showed few slides earlier which
1425.96|4.48|was on a scale of 1 to8 but essentially
1428.32|3.88|ranking between these two models and
1430.44|4.08|then you know llama 2 came out while we
1432.2|3.92|were in this iterative process and our
1434.52|4.039|iterative process was essentially we
1436.12|4.439|used to give a end point to the V Ender
1438.559|3.521|and then the you know the basically the
1440.559|3.36|annotators that they had in the man
1442.08|4.24|managed task force would prompt these
1443.919|4.521|endpoints the model would respond two
1446.32|3.599|response would generate two responses
1448.44|3.44|they would you know follow the
1449.919|4.0|instructions and you know give the
1451.88|4.039|ranking for each of those instruction
1453.919|3.36|each of those model responses and then
1455.919|2.88|you know again like follow up with the
1457.279|3.121|second prompt and the conversation would
1458.799|3.561|go on and then they would give us the
1460.4|4.399|data at the end of that week we would
1462.36|4.919|fine tune a model on that data so that
1464.799|4.561|the model now is hopefully better and
1467.279|3.801|then we give like a better endpoint to
1469.36|3.72|them for the next week to continue this
1471.08|3.719|process so it's like very iterative and
1473.08|4.44|like you know they have to adapt to like
1474.799|4.961|model getting better week by
1477.52|3.92|week um so yeah basically but like you
1479.76|3.56|know we decided to switch to I think for
1481.44|4.32|one or two weeks we collected and
1483.32|5.32|Tropics um use anthropic scale for
1485.76|4.639|collecting data set uh but then llama 2
1488.64|3.399|came out and their results showed that
1490.399|3.921|you know clearly that that you know they
1492.039|4.401|were using this much more easier scale
1494.32|4.079|of just one to four uh so they were like
1496.44|3.52|you know um choosing which one is a
1498.399|3.801|better response between the two
1499.96|4.92|responses and then saying how much
1502.2|4.599|better it is so is it like significantly
1504.88|3.679|better or is it only slightly better and
1506.799|4.401|so that that was the ranking of like
1508.559|6.321|scale one to four um so here are
1511.2|6.64|examples of data that we collected so on
1514.88|4.72|the left you can see that it is asking
1517.84|4.12|about like you know basically human
1519.6|4.24|human is prompting with a question and
1521.96|3.52|then the B generates a response and then
1523.84|3.6|so this is the response that the human
1525.48|4.4|chose at this turn and then the human
1527.44|4.68|you follows up with the second prompt
1529.88|3.919|and then this is the bot response that
1532.12|4.039|was chosen by this human and this is the
1533.799|4.081|rejected bot response and this is giving
1536.159|3.321|the response margin of three which is
1537.88|3.279|saying that they are quite a bit
1539.48|4.4|different so four is like very different
1541.159|4.721|and one being very slightly
1543.88|3.399|different and then here on the right
1545.88|3.679|hand side is more about sort of
1547.279|4.12|generation brainstorming kind of a
1549.559|3.761|example where in the human is asking
1551.399|3.76|like can you write a text message
1553.32|3.479|wishing their husband a happy
1555.159|4.52|anniversary and then the bot writes
1556.799|5.321|something um I guess my thing messed up
1559.679|4.281|the Emojis but um you know then the
1562.12|3.84|human follows up with saying hey you
1563.96|3.16|missed this important detail which is
1565.96|3.36|you know they have been married for
1567.12|3.919|eight years and so this is a chosen bot
1569.32|3.719|response this is the rejected one that
1571.039|4.281|the human you know chose between those
1573.039|5.601|two and as you can see they are quite
1575.32|6.8|good so the response margin is just one
1578.64|3.48|so they're like just slightly
1582.88|5.08|different okay sounds good uh so now I'm
1586.0|4.24|going to like talk about this another
1587.96|5.12|recipe that we tried which is you know
1590.24|5.159|using synthetic data set essentially for
1593.08|4.68|distillation of AI alignment which is
1595.399|4.801|basically the paper that we released
1597.76|4.56|last week called zeper and which was
1600.2|5.12|like a seven billion parameter model
1602.32|6.079|which actually beat Chad GPT and this
1605.32|4.52|Builds on top of the mile model uh but I
1608.399|3.241|just wanted to like you know yeah just
1609.84|3.0|you know basically we recreated some of
1611.64|3.919|the steps that were there on the
1612.84|5.24|instruct gbd paper but now with using
1615.559|4.6|synthetic data set um and and so the
1618.08|4.12|first one is like you know you you are
1620.159|4.12|basically like using a data set in this
1622.2|4.12|case we use ultra chat so this is a data
1624.279|3.801|set I showed a few slides earlier for
1626.32|3.68|supervised fine tuning where in like a
1628.08|4.04|human was brainstorming and like
1630.0|4.159|Gathering the material and then play
1632.12|4.64|like you know chatting with this gbd4
1634.159|4.12|model to like generate uh multiple
1636.76|3.24|different you know outputs for the
1638.279|3.64|instruction and then you know this is
1640.0|4.559|how we collect that data set which is
1641.919|5.081|called the ultra chat um and then we use
1644.559|4.801|that for fine-tuning our model and then
1647.0|4.919|the second step is the response
1649.36|5.12|generation AI ranking so in this case
1651.919|4.161|also like you know we used uh Ultra
1654.48|4.04|feedback which is a data set that was
1656.08|4.92|released and the way this data set was
1658.52|5.039|uh was constructed was that you know
1661.0|4.76|they asked U basically like you know
1663.559|4.24|took some prompts from like share GPD
1665.76|4.32|and some of these different data sets of
1667.799|4.401|sft that were already out there and then
1670.08|3.719|they gave it to four different models
1672.2|5.359|like four different powerful models like
1673.799|5.76|Palm 2 claw 2 GPD 4 and so uh and so on
1677.559|4.281|and then they asked this gb4 to like
1679.559|4.6|rank which one is rank each of those
1681.84|4.28|four responses and then so like you know
1684.159|3.88|the one that is the best is the one that
1686.12|3.72|gbd4 ranks as the highest so each of
1688.039|3.76|these are scored individually on a scale
1689.84|5.48|of 1 to 10 and the one that gets the
1691.799|3.521|maximum score is like the best
1695.48|4.84|response and then finally we did we did
1697.96|4.28|something called DPO which um you might
1700.32|5.28|have been aware of came out of Stanford
1702.24|4.679|is like this kind of alternative to rlf
1705.6|3.64|which is like doing this direct
1706.919|5.0|preference optimization and so instead
1709.24|4.52|of like you know um basically doing this
1711.919|3.521|iterative process of fine tuning you
1713.76|4.2|directly like optimize on like the
1715.44|5.56|chosen one so we just take that and then
1717.96|5.599|um find tuna model directly on that uh
1721.0|4.6|chosen response and the other one that
1723.559|4.441|we are using is like a random response
1725.6|5.36|from these other three
1728.0|5.0|responses um okay so I'm going to uh
1730.96|5.199|talk a little bit about experiments and
1733.0|5.399|evaluation for each of these recipes one
1736.159|4.4|is collecting everything thing with like
1738.399|4.361|humans involved and the second one is
1740.559|4.0|everything which is synthetic um but
1742.76|3.6|then before I discuss evaluation I
1744.559|3.881|wanted to talk about like what are the
1746.36|4.0|benchmarks that we are evaluating on and
1748.44|4.28|how good are these benchmarks for
1750.36|4.199|evaluating chat Bots um and to think
1752.72|3.799|about evaluation we need to First think
1754.559|4.281|about how are we training these models
1756.519|3.801|so like today all the models that are
1758.84|4.16|trained are like more or less have these
1760.32|4.16|four ways of learning the first one is
1763.0|2.84|pre- training the language model
1764.48|3.559|essentially are predicting the next
1765.84|4.76|token and examples of these are like
1768.039|5.48|gpt3 op and so like the foundation
1770.6|5.04|models um the second type of learning is
1773.519|4.201|in context learning or the prompt based
1775.64|4.6|learning um in this case you're like
1777.72|4.64|just giving a new kind of task in the
1780.24|4.4|context of the model and then you know
1782.36|3.76|ask it to like you know do that on new
1784.64|3.519|examples so like you know if you wanted
1786.12|3.72|to write a poem for example for GB3 you
1788.159|3.24|would like have written that in the
1789.84|4.16|context and then it would have generated
1791.399|5.52|new poem on some other
1794.0|5.32|topic uh the third type of uh learning
1796.919|4.321|is the supervised fine-tuning um which
1799.32|4.239|was kind of like the first step of
1801.24|4.159|training a chatbot in this case you're
1803.559|3.681|like fine-tuning on the instruction
1805.399|3.361|following data and then you want these
1807.24|3.439|language models which are just
1808.76|3.96|pre-trained to predict the next token to
1810.679|4.6|become chatty and to like generate
1812.72|4.48|open-ended responses um and then finally
1815.279|4.201|the fourth one is reinforcement learning
1817.2|3.88|from Human feedback which is nud nudging
1819.48|4.24|the language model towards the values
1821.08|5.16|you desire and examples include llama to
1823.72|6.12|chat from
1826.24|6.64|meta um so the first two steps are you
1829.84|5.04|know we have a lot of benchmarks for
1832.88|4.24|these two types of training like Sanford
1834.88|5.24|Helm is an example of that or the Google
1837.12|6.159|big bench or even hugging faces open llm
1840.12|5.32|leaderboard uh but for the for these two
1843.279|3.64|types of uh learning which is supervised
1845.44|3.44|fine tuning and reinforcement learning
1846.919|4.36|from Human feedback which are parts of
1848.88|4.159|like this recipe for training or chatbot
1851.279|3.601|there's you know not a lot of
1853.039|3.6|leaderboards or evaluation benchmarks
1854.88|3.08|available but there are some available
1856.639|2.76|and I wanted to to like you know just
1857.96|3.88|highlight some of
1859.399|4.88|those so like yeah this is essentially
1861.84|4.319|like the steps three and four year match
1864.279|4.0|to like you know the step one over here
1866.159|3.441|which is helpfulness and then steps two
1868.279|3.88|and three over here which is like you
1869.6|4.16|know nudging the model towards U being
1872.159|4.24|more
1873.76|5.399|harmless so if you had to you know
1876.399|4.841|evaluate the chat bot for each of these
1879.159|4.081|steps you would have to think about how
1881.24|3.96|do you evaluate instruction following a
1883.24|3.279|chattiness you would have to EV you know
1885.2|3.079|think about how do you evaluate the
1886.519|4.321|reward model which is essentially a
1888.279|4.041|classifier and then finally think about
1890.84|3.52|you know how do you evaluate for
1892.32|4.92|harmlessness which is by red caming or
1894.36|5.24|adversary prompting the uh the language
1897.24|4.2|model um so for the first step you would
1899.6|3.76|have to see like does the model generate
1901.44|4.28|useful responses on the topic and are
1903.36|4.0|they open-ended and one example of a
1905.72|3.36|prompt that you would try to evaluate
1907.36|3.76|the model would be to like know save
1909.08|5.24|brainstorm a list of the New Year's
1911.12|5.36|resolution um and so examples of uh
1914.32|4.44|benchmarks and evaluation boards that
1916.48|4.64|are that are looking at this sort of
1918.76|5.08|like supervis finetuning is like hugging
1921.12|5.32|faces a leaderboard with ELO ratings so
1923.84|4.28|ELO is this metric that is used in chess
1926.44|3.239|which is like you know you're pairing
1928.12|3.039|one player against the other and you
1929.679|3.521|want to like rank these players when
1931.159|4.48|they have like these tournaments against
1933.2|5.199|each of each other and so in a similar
1935.639|4.601|sense we are um you know using taking
1938.399|4.16|these chat Bots and then you know
1940.24|4.439|putting them in a pair wise setting and
1942.559|4.641|then we we partnered with scale Ai and
1944.679|4.72|they provided humans to like annotate
1947.2|4.599|which response is better and we did that
1949.399|4.921|for every single combination so like it
1951.799|4.84|was nc2 where n is the number of prompts
1954.32|5.719|we are looking at and so we generate nc2
1956.639|4.88|combinations and we rate each of them
1960.039|3.961|and so these are the ELO ratings that we
1961.519|4.481|get out of it um and on this this column
1964.0|3.96|here shows that what what would the
1966.0|4.639|rating uh what is the rating you would
1967.96|4.599|get if you would have used GPD 4 as a
1970.639|3.961|proxy for humans so instead of like
1972.559|4.0|humans sitting and rating each of those
1974.6|4.0|you're asking like you know gbd4 to
1976.559|4.48|select which is a better
1978.6|4.0|response um yeah and so this is
1981.039|3.961|basically the first table here showing
1982.6|4.52|if you allow ties in the sense sorry if
1985.0|5.84|there was no tie allowed and this table
1987.12|3.72|here is showing that if ties were
1991.279|4.841|allowed um another example is you know
1994.279|4.4|this leaderboard from Stanford which is
1996.12|4.399|alpaka eval leaderboard um and they are
1998.679|4.681|doing something very similar in the
2000.519|5.241|sense that they have gbd4 and Claude as
2003.36|5.159|an evaluator and they are doing like a
2005.76|4.919|pairwise uh evaluation of these models
2008.519|4.361|or chatbot models um and they're
2010.679|5.24|reporting the win rate of you know which
2012.88|6.0|model wins against the other
2015.919|4.801|one there's also the lmis leaderboard
2018.88|3.6|from Berkeley which has this thing
2020.72|4.319|called the chatbot Arena which is
2022.48|4.919|essentially like a publicly crowdsourced
2025.039|3.681|leaderboard wherein you can like go chat
2027.399|3.24|like you know chat with any of their
2028.72|3.72|models and then give them rating to like
2030.639|4.081|which one was more helpful and which one
2032.44|4.119|was better um and so this again has like
2034.72|4.679|a leaderboard of Elo ratings because
2036.559|5.921|this is done done in a pairwise
2039.399|5.0|setting there's another uh Benchmark
2042.48|4.679|from lmis which is called The Empty
2044.399|5.041|bench or the multi-turn bench Benchmark
2047.159|5.041|and this is the first ever multi-turn
2049.44|4.88|dialogue Benchmark uh that is evaluating
2052.2|4.56|chat Bots and so it has there are just
2054.32|5.12|like 80 examples in this across like a
2056.76|5.8|bunch of categories but essentially what
2059.44|5.08|the way it works is that the the first
2062.56|4.72|turn or the first prompt from The
2064.52|5.639|Benchmark is prompted to the model then
2067.28|4.96|GPD 4 is asked to score on a score of 1
2070.159|4.0|to 10 how how how is how good is the
2072.24|3.919|model's response and then you know it is
2074.159|4.52|followed up by another prompt which is
2076.159|4.281|like you know the The multi-t Prompt
2078.679|3.121|which is like related to the question
2080.44|3.199|but it might not be related to the
2081.8|3.64|model's responses because you know this
2083.639|3.72|is already constructed and they always
2085.44|5.56|like follow up with the same response to
2087.359|7.161|every B and then again gbd4 evaluates
2091.0|5.28|how good was the second turn of the
2094.52|4.24|response so this is like the
2096.28|5.36|consolidated leaderboard from LM LMS
2098.76|4.64|showing both the arena ELO rating as
2101.64|3.92|well as empty bench score so these are
2103.4|5.04|scores that are aggregated across all
2105.56|7.0|the 80 examples and this is GPD score
2108.44|4.12|scoring from like 1 to 10 let me show
2112.599|4.721|you cool so I think the Second Step that
2115.4|4.48|we wanted to like look at in our
2117.32|4.64|evaluating a chatbot chart was like you
2119.88|3.959|know think about how do you evaluate a
2121.96|3.879|reward model so when you have these
2123.839|3.561|human preference data set collected and
2125.839|3.921|you train this reward model which is
2127.4|3.719|essentially a classifier to discriminate
2129.76|3.599|between like you know truthful and
2131.119|3.96|untruthful response or like you know can
2133.359|5.201|it rank helpful response higher than the
2135.079|5.201|less helpful less helpful responses and
2138.56|4.32|you know there's literally no open-
2140.28|4.28|Source uh data uh leaderboard available
2142.88|3.6|for evaluating these like preference
2144.56|4.16|model or the reward models but
2146.48|4.56|internally at hugging phas we have our
2148.72|4.599|own data set for evaluating so that we
2151.04|4.52|know that as we are adding more human
2153.319|4.481|preference data our models are actually
2155.56|4.12|getting better
2157.8|4.039|uh so this is essentially we are
2159.68|4.639|evaluating on these open-source data
2161.839|4.881|sets which is the enthropy helpful data
2164.319|4.8|set the open Assistant data set um the
2166.72|3.92|Stanford's human preference data set um
2169.119|3.401|and also the learning to summarize data
2170.64|3.92|sets from the very first paper from
2172.52|5.559|openi which was looking at learning to
2174.56|4.88|summarize um and so uh so this is like
2178.079|4.441|you know basically seeing that you know
2179.44|4.919|how good U is our reward model um and
2182.52|4.559|then finally the third type of
2184.359|4.72|evaluation is red teaming and so this
2187.079|4.721|case you want to craft a prompt in a way
2189.079|5.121|that could surface model vulnerabilities
2191.8|4.0|and emerging capabilities um and for
2194.2|3.96|example if you're asking like how do I
2195.8|3.76|plan a brand robbery is the model
2198.16|3.6|actually like you know helping you with
2199.56|4.559|that and trying to elicit undesired
2201.76|4.44|behavior from the model um and
2204.119|3.841|unfortunately actually there's no leader
2206.2|3.6|open source leaderboard available for
2207.96|3.72|this thing there's just one data set
2209.8|4.08|from anthropic which has all the three
2211.68|4.0|included which is the actually it has
2213.88|3.959|both helpfulness and harmlessness it's
2215.68|3.56|the H Edge data set Set uh from
2217.839|3.121|anthropic and that's the only open
2219.24|4.4|source data set available for red
2220.96|4.399|teaming um but there's no leaderboard
2223.64|3.52|available for red teaming and so this
2225.359|3.401|was like a Blog that I wrote earlier in
2227.16|3.439|the year saying like you know
2228.76|3.48|highlighting this Gap and saying that
2230.599|3.0|you know putting out an announcement
2232.24|3.68|saying like we should get together and
2233.599|3.801|build a data set for red teing um and if
2235.92|4.04|you have heard of like the Defcon red
2237.4|4.04|teaming design Challenge and you know
2239.96|4.28|basically crowdsourcing some of these
2241.44|5.48|red teaming work kind of came out of
2244.24|4.32|that okay so now I'm going to get into
2246.92|3.52|now that we have discussed evaluation
2248.56|3.559|and benchmarks and leaderboards I'm
2250.44|3.76|going to talk about results and what do
2252.119|5.24|they look like on each of and some of
2254.2|7.08|these benchmarks um so here I'm showing
2257.359|6.121|the results for this Lama 23 billion um
2261.28|5.0|on the open llm leaderboard from hucking
2263.48|5.2|phas and in this case I was using the
2266.28|3.96|data set that we collected from search
2268.68|4.28|that was a 10,000 instruction
2270.24|4.76|demonstration data um and I he on this
2272.96|4.56|you know these are basically the four
2275.0|4.52|data sets which are like NLP Focus data
2277.52|3.68|sets that we have as part of open llm
2279.52|5.599|leaderboard which are the arc challenge
2281.2|6.04|the Hendrix Haag and truthful QA um and
2285.119|4.601|you're like you know this is how well a
2287.24|4.68|model does and every every all of this
2289.72|4.2|is essentially accuracy and this is the
2291.92|3.72|Lima paper or the Lima model which is
2293.92|3.8|less is more for alignment that came
2295.64|4.16|from meta and they just use thousand
2297.72|4.119|examples of high quality instructions
2299.8|4.799|and showed that you can get a very good
2301.839|4.041|chat Bo by just using thousand examples
2304.599|2.801|and this is like you know taking the
2305.88|3.6|longest examp example from open
2307.4|4.32|assistant and just chosing the top 500
2309.48|4.72|of them um and so we found that our
2311.72|4.8|model does slightly better than you know
2314.2|4.76|each both of like Lama and open
2316.52|4.16|Assistant except for in truthful QA
2318.96|4.159|where we found that the Lima and open
2320.68|5.08|Assistant did better than
2323.119|4.521|us and similarly like actually like in
2325.76|3.92|empty bench we found like you know the
2327.64|4.16|opposite was true so this is like you
2329.68|4.52|know empty benches remember that lmis
2331.8|4.12|had like you know turn zero and turn one
2334.2|4.08|and then so this is reporting the first
2335.92|5.0|response this like gbd4 is essentially
2338.28|4.64|scoring on a score of 1 to 10 how good
2340.92|3.919|each how good these models are on the
2342.92|4.88|first dialogue turn and the second
2344.839|5.24|dialog turn and the average score um and
2347.8|4.279|so actually this is kind of more um
2350.079|4.161|counterintuitive to what we found on
2352.079|4.561|this automatic evals is that actually
2354.24|4.4|the empty Bend says that you know our
2356.64|3.719|the data that a model trained on the
2358.64|4.24|data that we collected from search is
2360.359|4.201|not very good and in fact Lima and open
2362.88|5.12|Assistant which are like a fraction of
2364.56|7.039|the size of the data we had much better
2368.0|5.2|so this was kind of um surprising and
2371.599|4.48|then I looked into like you know let me
2373.2|4.76|look at is the length a factor in this
2376.079|3.641|um and it does seem like you know like
2377.96|3.08|the DAT I was looking at each of those
2379.72|3.28|and then you know looked at the average
2381.04|4.2|length of the prompts in each of those
2383.0|4.359|and it seems like there is a very wide
2385.24|4.44|range for example like our data said the
2387.359|4.881|average length was just 21 of these
2389.68|5.72|promps while Lima is like double of that
2392.24|5.76|and open assistant is almost double of
2395.4|5.0|that
2398.0|4.88|um so then I did this experiment wherein
2400.4|4.56|I wanted to check like if I controlled
2402.88|4.8|for the size of the data but then you
2404.96|5.04|know let the length be varied The Prompt
2407.68|3.76|length does that affect the performance
2410.0|3.4|um so in particular like I think I
2411.44|4.879|highlighted this before is that our chat
2413.4|4.88|category was like really short and so it
2416.319|5.0|actually found that you know like Lent
2418.28|5.72|did not really affect that much except
2421.319|4.481|for this truthful QA data set even for
2424.0|4.599|this hell swag even though it looks more
2425.8|4.319|actually just in the third digit um and
2428.599|3.361|over here you can see like the actual
2430.119|4.24|difference only made on truthful QA
2431.96|5.119|which actually preferred models that
2434.359|5.121|were generating longer
2437.079|5.361|responses but on the other hand the mty
2439.48|4.76|Ben score was again not in not aligning
2442.44|4.96|or correlated with what we found with
2444.24|5.48|these automatic metrics and evaluations
2447.4|5.919|of in the sense that gbd4 actually did
2449.72|4.96|not prefer like longer responses and so
2453.319|3.28|this was like you know a little bit
2454.68|3.88|counterintuitive and so need to to like
2456.599|4.48|dig more into like what's going on over
2458.56|5.2|here um but you know it actually found
2461.079|5.24|that you know like shorter responses
2463.76|4.76|were better than you know longer respon
2466.319|4.161|um although there was like not much of a
2468.52|4.079|very much of a
2470.48|4.52|difference so the other experiment and
2472.599|4.601|ablation we did is that just removing
2475.0|4.28|amounts of data and seeing like if you
2477.2|3.96|incrementally add more data how does
2479.28|3.92|that affect performance and this is
2481.16|4.6|again on that auto like open llm
2483.2|3.8|leaderboard from um from hugging phase
2485.76|4.359|which is looking at some of these
2487.0|5.2|standard NLP benchmarks and Reporting
2490.119|3.881|accuracy and so this is like starting
2492.2|4.68|with just 10% of all the data we
2494.0|4.96|collected from search and as you can see
2496.88|4.12|like you know in all these benchmarks
2498.96|3.72|actually like it saturates very quickly
2501.0|4.24|and in some of them you actually get
2502.68|4.8|like know you basically lose performance
2505.24|4.4|if you keep adding data and so this is
2507.48|3.76|kind of aligning with when I started
2509.64|3.56|when we started collecting data we had
2511.24|4.48|this diminishing return plot wherein you
2513.2|4.84|said that if you have just very few
2515.72|4.16|thousand examples of very high quality
2518.04|4.12|instruction following data set that's
2519.88|4.6|good enough and then your U then your
2522.16|4.199|performance saturates or plateus very
2524.48|5.44|quickly after that and so that is kind
2526.359|3.561|of the what we got as
2530.92|4.439|well um similarly I think this is where
2533.52|5.0|one place where empty bench actually
2535.359|6.72|correlated with the um automated metrics
2538.52|5.599|is that uh gp4 also like you know showed
2542.079|4.841|that you know after like about 4,000
2544.119|4.72|examples um it was basically very barely
2546.92|4.76|any gain in performance actually like
2548.839|4.961|decreasing performance um on the with
2551.68|2.12|the
2554.24|5.119|model okay great so that was all the
2556.68|5.56|results on using like these human
2559.359|5.2|curated very high quality data set what
2562.24|4.119|about like results from distillation
2564.559|4.401|from these synthetic data sets in
2566.359|4.361|particular we use ultra chat for
2568.96|4.04|supervised fine tuning and Ultra
2570.72|4.639|feedback for
2573.0|3.96|DPO and so these are the results so this
2575.359|3.321|is like basic basically just work that
2576.96|4.359|was released last week we haven't yet
2578.68|4.28|released the code and uh the data set
2581.319|3.641|which we are going to do this week and
2582.96|3.96|so here I'm highlighting that zepher is
2584.96|4.8|the model we released we built we use
2586.92|5.88|mistl as the foundation model and then
2589.76|5.64|fine-tuned it using Ultra chat and then
2592.8|4.92|did DPO on Ultra feedback and as you can
2595.4|5.52|see that it actually beats chat gbd on
2597.72|3.2|this alpaka eval
2601.559|6.52|leaderboard also it is like the best in
2605.559|2.52|the
2608.359|5.361|in all the open at least it's like it
2610.28|6.079|beats most of the 13 billion parameter
2613.72|6.119|models and it's like quite competitive
2616.359|4.641|to clot to again on the alaka eval
2619.839|3.561|leader
2621.0|6.24|board so this is the model which has
2623.4|7.52|both sft and DPO uh so we want we did an
2627.24|6.04|appalation on how good or how useful is
2630.92|4.04|like you know sfd and how useful is DPO
2633.28|3.64|because there's this two-step process is
2634.96|3.359|like first you find tune on instruction
2636.92|4.88|demonstration then you find tune on
2638.319|5.561|human preferences and so this is the the
2641.8|5.039|first row over here is showing what if
2643.88|4.479|you directly did DPO on Ultra feedback
2646.839|3.401|and did not do the supervised fine
2648.359|4.561|tuning and you actually saw that that's
2650.24|4.44|really bad so that doesn't work at all
2652.92|3.48|and then the second one is saying that
2654.68|4.24|what if you just did supervised fine
2656.4|4.56|tuning and did not do DPO and so this
2658.92|3.639|actually which is like the first step um
2660.96|3.24|and this actually works decently well
2662.559|4.361|and it's like you know basically getting
2664.2|5.0|you to like 80 or 90% of the overall
2666.92|4.48|performance um and finally this is doing
2669.2|4.48|like supervised fine tuning on the human
2671.4|4.04|preference data so you take this row and
2673.68|3.919|do another round of supervised fine
2675.44|3.76|tuning but on this data of human
2677.599|3.76|preferences so you remember you had like
2679.2|4.48|the Chosen and the rejected so you give
2681.359|4.161|all the dialog history and then the
2683.68|3.679|expected completion is the chosen
2685.52|3.559|dialogue response so in this case you're
2687.359|3.841|not really doing that discriminative
2689.079|4.121|thing you're still doing the sft process
2691.2|3.919|but you're just you know like using that
2693.2|4.28|in a smart using the data set in a Smart
2695.119|4.72|Way um so that it follows a template of
2697.48|4.28|what supervis fine tuning does um and
2699.839|4.561|then that as well we found that you know
2701.76|5.839|wasn't very helpful so the best recipe
2704.4|6.0|obviously is DPO plus sft so you know
2707.599|4.96|doing sft first on the ultra chat and
2710.4|4.48|then DPO on the ultra feedback both of
2712.559|4.121|these data sets are synthetic um and
2714.88|5.56|then you know all but it's like only
2716.68|3.76|slightly better than just doing
2720.8|5.2|sfd okay so I'm getting to this final
2723.52|4.88|section of my talk which is essentially
2726.0|4.48|looking at you know so we have seen a
2728.4|4.159|lot of these evaluation and benchmarks
2730.48|4.28|and leaderboards and many of them are
2732.559|5.241|starting to adopt these powerful models
2734.76|5.64|like CLA 2 and gbd4 and are using as
2737.8|4.16|proxy for humans in evaluation and so
2740.4|3.36|what are the quirks associated with
2741.96|3.72|doing that and are things that we should
2743.76|4.599|like be like you know considering when
2745.68|5.52|we are doing this at a very large
2748.359|5.2|scale so when we did that uh when we use
2751.2|5.639|gbd4 as an evaluator we found that it
2753.559|4.881|actually has a positional bias and so in
2756.839|4.081|particular it is predisposed to
2758.44|4.639|generating of rating of one in a prir
2760.92|3.8|wise preference collection setting and
2763.079|4.881|so like you know this chart over here
2764.72|5.56|shows like the average rating uh for for
2767.96|4.44|model responses across like the entire
2770.28|4.36|data set and on the right on the other
2772.4|3.84|hand humans are more or less uniform and
2774.64|3.88|so you expect that you know this
2776.24|5.8|distribution seems much more better than
2778.52|3.52|this distribution which is cute to the
2782.16|5.08|right so then what we did is that we
2784.92|4.439|prompted GPD before to say that hey you
2787.24|4.44|have this left bias and you always
2789.359|4.2|generate this rating of one you know be
2791.68|4.52|aware of this bias and then you tell it
2793.559|5.081|to debias itself it actually flips the
2796.2|4.159|bias in the opposite direction so then
2798.64|3.28|it starts like it's it is more
2800.359|3.321|self-aware in the sense that it knows
2801.92|3.48|that you know it has this bias and now
2803.68|4.08|it starts generating more ratings of
2805.4|4.28|five and six and the one way of getting
2807.76|4.04|rid of this is that we kind of make sure
2809.68|4.08|that each response is equally likely to
2811.8|3.84|be in right and left position so that
2813.76|5.0|that kind of dilutes like this bias that
2815.64|5.679|Happ it has to each of these
2818.76|4.16|positions um and then you know we found
2821.319|3.841|that actually like prompting the G
2822.92|4.08|prompting GPD 4 to generate scores so
2825.16|4.199|asking it to score like each response
2827.0|4.24|individually like empty bench does and
2829.359|3.521|then instead of ranking but in a pair
2831.24|4.2|wise setting we actually found that that
2832.88|4.719|alleviates the problem a little bit but
2835.44|5.2|does not completely get rid of the
2837.599|5.681|problem uh we also found evidence of
2840.64|5.679|doping between training and evaluation
2843.28|5.76|so in particular we found that GPD for
2846.319|4.921|prefers models that were trained on GPD
2849.04|4.16|for's data so these all these models
2851.24|5.52|here were trained on data that was
2853.2|6.72|bootstrapped using gbd4 and you know so
2856.76|5.559|it prefers that over humans who are like
2859.92|4.24|more factual much more higher quality
2862.319|4.401|but they might be very succinct and to
2864.16|4.04|the point um so this is one thing that
2866.72|3.44|you know we should be aware of when we
2868.2|3.96|using gbd4 as an
2870.16|3.8|evaluator the other thing is that you
2872.16|3.919|know it's also like concurs with
2873.96|4.8|findings from these other papers which
2876.079|5.121|is that gbd4 prefers models with higher
2878.76|5.0|diversity so that is number of unique
2881.2|4.0|tokens in the response and the longer
2883.76|3.16|responses so if you have like this
2885.2|4.96|listof list kind of response just like
2886.92|5.12|Chad gbd does um gbd4 is like
2890.16|3.199|predisposed to like rating that higher
2892.04|3.799|compared to a model that does not
2893.359|2.48|generate
2896.52|5.839|that um we also found that gbd4 has poor
2900.0|4.48|correlation with humans on low entropy
2902.359|4.041|tasks such as math coding and reasoning
2904.48|4.44|so remember that a leader I showed you
2906.4|4.679|where we had compared like how does gbd4
2908.92|4.72|ELO rating compared to humans and then
2911.079|4.52|we dive deeper into like how does that
2913.64|3.84|compare on each of these different task
2915.599|3.801|distribution and categories and so this
2917.48|4.599|is what it looks like so it seems like
2919.4|4.959|you know it says lower correlation with
2922.079|4.04|humans on some of these more factual
2924.359|3.96|like you know more kind of like
2926.119|4.72|expecting one correct answer and they're
2928.319|4.881|actually highly correlated with humans
2930.839|4.081|on these more High entropy tasks where
2933.2|3.24|you like brainstorming and creative
2934.92|4.32|generation which was was kind of
2936.44|4.679|unintuitive and counterintuitive because
2939.24|4.04|um you could have so many different ways
2941.119|4.44|of coming up with like you know a recipe
2943.28|4.519|or a list of something uh but that's
2945.559|4.641|where like the rating of gbd4 and humans
2947.799|2.401|are more
2951.2|5.879|correlated okay so the final thing is
2954.4|4.36|takeaways so there's a bunch of this but
2957.079|3.561|U let's try to break it down essentially
2958.76|4.28|like you know we discussed like how do
2960.64|5.28|we come up with steps for data curation
2963.04|4.6|for supervised fine tuning and rlf and
2965.92|3.8|it involves like several critical
2967.64|3.84|factors such as how much data do you
2969.72|4.32|need to collect what is the length of
2971.48|5.119|the uh prompts and the distribution of
2974.04|4.079|those lens the task distribution and
2976.599|3.24|what is the role of humans like you know
2978.119|3.68|do you need synthetic data do you need
2979.839|4.24|completely manually curated or something
2981.799|3.921|in the middle um and we looked at like
2984.079|4.72|there are many tools for like efficient
2985.72|6.24|fine-tuning of Open Source llms uh from
2988.799|5.201|the sft results we found that truthful
2991.96|4.28|QA is was the main differentiating
2994.0|4.599|Benchmark for these automated eval
2996.24|4.879|metrics um and then we found that empty
2998.599|5.081|B scores were actually not correlated
3001.119|5.321|with these automated metrics and so um
3003.68|4.56|it was more sort of um you know only on
3006.44|4.04|like some of these models we found that
3008.24|4.0|they were correlated um for the
3010.48|4.319|distillation results which is from The
3012.24|6.24|Zephyr 7B where we are like fine-tuning
3014.799|6.481|on synthetic data we found that dsft on
3018.48|4.92|AI generate data and the DPO or
3021.28|4.44|distillation of DPO and AI feedback data
3023.4|5.199|actually beats Chad gbt even even though
3025.72|4.28|the model is just 7 billion parameter um
3028.599|4.121|and then we found that you know
3030.0|5.04|benchmarking Gap in assessing rlf models
3032.72|4.839|in particular that we don't have
3035.04|4.4|benchmarks for uh assessing reward
3037.559|4.481|models and we also don't have open-
3039.44|4.2|Source benchmarks for um evaluating red
3042.04|3.68|teing and model
3043.64|4.0|vulnerabilities then finally we'd like
3045.72|4.72|you know dive deeper into like you know
3047.64|5.52|looking at quirks of using gbd4 or some
3050.44|4.24|of these powerful llms as an evaluator
3053.16|4.0|um and some of them were like you know
3054.68|5.639|they prefer models trained on gbd4 like
3057.16|4.919|data it has like a left positional bias
3060.319|4.561|and then it has high correlation with
3062.079|4.961|humans on Creative task compared to like
3064.88|4.959|coding or reasoning
3067.04|4.92|task and my work was has been covered on
3069.839|4.641|the New York Times article cover which
3071.96|4.72|talks about the secret ing gradient of
3074.48|4.639|alignment which is for chat GB which is
3076.68|3.919|alignment I'm also part of the United
3079.119|3.561|Nations Advisory board that was
3080.599|4.48|announced last week so really humbled to
3082.68|5.28|be part of that um there are some block
3085.079|5.801|post um you know basically like yeah we
3087.96|4.879|kind of like did not publish a whole lot
3090.88|4.04|this year but we wrote a bunch of blog
3092.839|4.841|post highlighting what we are releasing
3094.92|4.48|and working on um and also like you know
3097.68|4.24|some of these are part of the talk um
3099.4|5.24|that I just discussed um and this is
3101.92|5.48|part of the H4 Team U you know I'm
3104.64|5.159|grateful to be part of this um and
3107.4|2.399|thanks for
3114.359|3.0|listening
3130.24|3.92|when you get alternating responses from
3131.96|4.2|the models do you select really high
3134.16|4.0|temperatures or you keep it pretty close
3136.16|5.36|to the temperature value that's also CH
3138.16|6.04|the model yeah so we we did like you
3141.52|4.36|know basically chose like you know the
3144.2|3.96|we tried experiment with different
3145.88|5.16|temperatures but then we actually found
3148.16|4.8|that um just using different sampling
3151.04|4.559|strategy worked better so like you know
3152.96|4.76|using a different value of p and then K
3155.599|5.2|and some combination of that as opposed
3157.72|3.079|to just like relying on
3173.92|4.159|temperature here's
3175.839|2.24|one of
3179.28|6.92|the so curious your thoughts on doing
3183.079|6.601|that scale and like what are the
3186.2|3.48|different tactics and
3194.24|5.44|techniques yeah so uh I think for red
3197.44|5.359|teing at scale there's actually a paper
3199.68|6.0|that came out recently called gbd fuzzer
3202.799|5.04|that actually like you know uh straps
3205.68|3.72|and uses these powerful llms to G break
3207.839|3.321|other llms and also there was a deep
3209.4|3.919|mind paper I think actually like one and
3211.16|4.159|a half to almost two years ago that was
3213.319|4.081|red teing large language models with
3215.319|4.48|large language models so how do you like
3217.4|4.719|red team and evaluate a language model
3219.799|4.32|by using another powerful language model
3222.119|6.041|and so I think that is kind of the way
3224.119|7.361|to go in terms of scale um and sorry
3228.16|5.8|what was the second question um I guess
3231.48|6.72|I was asking like what are the unique uh
3233.96|5.72|bre thator or what makes te other you
3238.2|5.04|need from
3239.68|6.24|Team regular infrastructure or softare
3243.24|5.04|yeah so I think one thing is this idea
3245.92|5.56|of like emerging capabilities which is
3248.28|4.48|essentially like um as you scale up and
3251.48|3.599|which is a trend that we seeing like you
3252.76|4.16|know as we are scaling up there are
3255.079|3.48|things that these models do or like you
3256.92|3.56|know capabilities that emerge that were
3258.559|3.921|not there in the smaller models I think
3260.48|4.76|examples are Chain of Thought reasoning
3262.48|5.119|which you know gpd2 or gbd was not
3265.24|4.24|capable of doing it um and as we scale
3267.599|3.681|up and the other example is this few
3269.48|4.359|short prompting that we first saw in
3271.28|5.039|gbd3 as in like you could give it a
3273.839|4.48|completely new task and not update its
3276.319|4.04|parameters in any way but just put it as
3278.319|3.921|part of the prompt and then you know now
3280.359|5.041|it just launch the task and then it can
3282.24|4.68|do it on N number of examples right um
3285.4|3.719|and so like labeling and all these
3286.92|4.639|things started coming up like using gbd3
3289.119|4.121|as a labeler and all that um when we
3291.559|3.52|kind of like discovered that thing so I
3293.24|3.68|think essentially like you know and the
3295.079|4.881|another example is like manipulation I
3296.92|4.919|don't think any open source models are
3299.96|3.399|capable of that yet but I know like
3301.839|3.76|anthropic and opening and these
3303.359|4.401|companies are focusing on like you know
3305.599|3.641|um deception and manipulation because
3307.76|3.599|when when you start like you know
3309.24|3.64|chatting with these models you start
3311.359|3.601|like you know treating them as a
3312.88|4.239|companion U especially like if you have
3314.96|4.08|like character AI kind of a thing where
3317.119|3.521|you know you you might try confiding in
3319.04|3.6|them start confiding in them sharing
3320.64|4.56|information that you probably shouldn't
3322.64|4.08|um and then they can use it against you
3325.2|3.639|maybe like you know an example of that
3326.72|4.52|is like um I think recently we saw that
3328.839|4.801|gbd4 actually manipulated someone to
3331.24|4.119|like read the capture to it in some way
3333.64|4.439|and like tell it what the capture reads
3335.359|5.601|and so that's a really concrete example
3338.079|5.28|of manipulation and so um it seems like
3340.96|4.079|now these models are capable capable of
3343.359|3.96|that I don't think open source models
3345.039|4.441|are there yet but these are like just
3347.319|4.081|like you know things that come out and
3349.48|4.52|like vulnerabilities that would surface
3351.4|5.159|when we do R
3354.0|3.68|te
3356.559|4.76|W
3357.68|7.119|idea like as
3361.319|5.921|those like creating data set pretty
3364.799|4.721|important but I know there also question
3367.24|5.2|like if you're open source data sets
3369.52|6.279|like for you after just tell B actors
3372.44|7.48|how to use models for that and so I gu
3375.799|4.121|what's your take on that idea what's
3380.64|6.399|like yeah so I would say like it was um
3384.72|5.079|it's it's less about open- sourcing a
3387.039|5.241|data set that is crafted to kind of
3389.799|4.28|elicit this Behavior it's more about the
3392.28|3.759|kind of harms that we should be thinking
3394.079|4.72|about um so it's more about like you
3396.039|5.681|know hallucinating or plagiarism
3398.799|5.04|manipulation you know trying to leak pii
3401.72|4.119|information People's Credit Card SSN
3403.839|3.041|things like that um it's more about like
3405.839|3.641|thinking about these different
3406.88|5.36|dimensions and giving concrete examples
3409.48|5.48|of how these models can you know elicit
3412.24|4.48|this Behavior Uh but I think what you
3414.96|4.159|trying to like talk about is that you
3416.72|3.639|know what if we gave them concrete ways
3419.119|2.92|like concrete prompts on how you
3420.359|3.68|jailbreak and then they can go and try
3422.039|3.56|to do that um I think first thing is
3424.039|3.481|like you know while we are doing this we
3425.599|3.24|would have evaluated our models and we
3427.52|3.799|would then start thinking about guard
3428.839|4.161|rails and safety ourself um and if
3431.319|3.48|indeed like you know the data set is so
3433.0|3.559|good that we can say that a lot of these
3434.799|3.32|powerful models are failing on that then
3436.559|3.441|obviously you don't open source it
3438.119|3.881|instantly but you actually think about
3440.0|4.0|what is the best way to put it out there
3442.0|4.72|by first securing the model making sure
3444.0|5.359|that it does not like you know basically
3446.72|4.2|does not elicit that kind of behavior um
3449.359|3.321|and then sharing it while you have
3450.92|3.36|already you know kind of crossed that
3452.68|3.399|bridge and being like yeah my model is
3454.28|5.559|safeguarded against that so it's more
3456.079|6.48|like yeah a process of um a gradient of
3459.839|2.72|things that you need to
3464.119|5.361|do for a great talk um there recently
3467.16|4.959|been some papers about um like
3469.48|5.68|retraining on data you know getting to
3472.119|5.841|collap models um I mean obviously like
3475.16|5.6|not the case but if you're using LM data
3477.96|7.359|for fine tuning you seen any any of
3480.76|7.559|potential csis worried about from that
3485.319|4.681|prevent that yeah so you're talking
3488.319|3.52|about like when you're using synthetic
3490.0|3.88|data bootstrap on another language
3491.839|4.321|models have we seen like collapse of
3493.88|5.64|like some kind of uh like mode collapse
3496.16|5.919|or something like that or um so actually
3499.52|4.599|so far uh it's been like clear that
3502.079|4.201|these are good like these these actually
3504.119|4.0|turn like you know regular chat Bots and
3506.28|3.68|like regular language models into chat
3508.119|3.401|Bots and which are as good as the
3509.96|4.119|experience that you get by chatting with
3511.52|4.2|chat gbd but although like you know like
3514.079|3.0|the kind of the quirks that I raised
3515.72|2.879|which is like you know when you have
3517.079|3.24|these models and then you like now put
3518.599|3.801|them on a benchmark and then you see
3520.319|4.121|that Suddenly It's like 90% it might
3522.4|4.0|just be because you use the model that
3524.44|3.399|was the evaluator to generate the data
3526.4|3.88|and then trade this model and that in
3527.839|4.601|turn like this doping thing right um and
3530.28|4.759|so that is one thing that was uh that is
3532.44|6.56|important to think about um the other
3535.039|6.721|thing is um uh what was I going to say I
3539.0|2.76|forgot
3551.4|5.679|um yeah the other thing is like about
3553.559|5.56|the licensing part which is kind of um
3557.079|4.161|not related to what you were asking but
3559.119|4.281|essentially like you know um there was
3561.24|3.839|this kind of like you cannot like we
3563.4|3.199|could open we cannot open open source
3565.079|3.681|and commercially so it's like you know
3566.599|5.321|still restrictive license um and you
3568.76|5.96|cannot use it for building and selling
3571.92|4.56|applications U Down the Line uh but then
3574.72|4.599|it's still like good as like a research
3576.48|4.8|artifact and so U I think I like we
3579.319|4.121|would have seen these kind of collapses
3581.28|3.64|happen if it was allowed to use these
3583.44|3.359|commercially and then people would have
3584.92|3.32|been like oh but like actually recently
3586.799|4.161|we did see like so there's this company
3588.24|5.119|called Daxter uh which US which was
3590.96|3.68|using gbd4 for summarization they
3593.359|3.841|replace it with the open source mod
3594.64|5.08|model called mistel and they said that
3597.2|4.08|their customers haven't complained and
3599.72|4.0|you know they're saving a ton of money
3601.28|4.559|and it just seems to work fine and uh
3603.72|4.399|they like you know it's just as good and
3605.839|4.76|so but not not that I'm saying that Mel
3608.119|4.841|is trained on any of the synthetic data
3610.599|4.121|but it's just an example of like things
3612.96|4.159|that would become very clear by doing
3614.72|3.879|this sort of AB testing where you like
3617.119|5.96|replace this model by another one and
3618.599|4.48|see how that affects things thank
3623.559|3.8|you
3625.88|4.479|I have a question on
3627.359|3.0|Zoom
3630.68|6.0|yes right um uh it's it seems like
3634.359|6.601|another access you might um beat chat
3636.68|6.04|gbt on is on cost uh so I wondered why I
3640.96|3.92|wonder what your total budget was or
3642.72|3.879|your total cost was to to produce your
3644.88|6.199|model that beat
3646.599|8.081|them oh so the Zer 7B was just four
3651.079|7.76|hours of training on 16a 100s so that's
3654.68|6.399|less than $50 I guess um because we used
3658.839|4.0|a synthetic data set which was already
3661.079|5.76|open source which is ultra chat and
3662.839|5.881|Ultra feedback um but the cost
3666.839|3.921|Associated the overall cost all the
3668.72|5.079|people and everything
3670.76|5.079|yeah I see okay so all the people and
3673.799|4.881|everything in the sense so there were no
3675.839|4.76|um I guess like Ultra chat probably
3678.68|4.639|might have reported some cost and Ultra
3680.599|4.881|feedback but they are mostly synthetic
3683.319|5.72|synthetically creative with very little
3685.48|5.0|human intervention um and so they might
3689.039|3.56|uh I don't know if they report that I
3690.48|3.92|haven't looked into that but I would say
3692.599|4.0|it was still much more cost efficient
3694.4|4.439|than what what we spent on buying data
3696.599|5.48|from Surge and scale Ai and we spent
3698.839|5.561|about half a million buying about 20,000
3702.079|5.52|prompts of human preferences the 20,000
3704.4|5.04|dialogue um and about 10,000 um
3707.599|5.841|instruction demonstration
3709.44|7.0|data so that was quite a
3713.44|3.0|bit
3722.96|4.2|thing I'm curious about is the scale
3724.599|6.76|that you used from evaluating the bias
3727.16|6.52|uh for GT4 uhuh so saw it was like one7
3731.359|2.321|on
3738.279|6.361|slide this one uh
3741.4|5.639|yeah oh so yeah this was U the entropic
3744.64|4.639|scale like remember that like 1 to four
3747.039|5.121|is decreasingly a and 5 to 8 is
3749.279|8.56|increasingly B yeah and now it's giving
3752.16|8.48|the mod to outut yes exactly
3757.839|6.601|yeah in these types of valuations how
3760.64|8.159|sensitive to the pro do you find the to
3764.44|7.159|be you one found it that it has account
3768.799|6.601|for this uh left bias you know right
3771.599|6.2|bias what's stopping you from that say
3775.4|3.719|the distribution should be um uniform
3777.799|4.161|distribution should be normal and just
3779.119|5.68|kind of playing iteratively to see how
3781.96|5.359|to be yeah yeah I think that's a good
3784.799|4.601|point in the sense like we did not study
3787.319|5.641|as to what were there certain tasks or
3789.4|5.8|prompts that were putting off GPD 4 to
3792.96|4.0|like you know generate this kind of bias
3795.2|5.119|um although I would say that you know
3796.96|6.599|this was also observed by lenis and it's
3800.319|4.601|part of their findings as well somewhere
3803.559|3.681|else
3804.92|5.199|uh but yeah so the lmis paper also has
3807.24|4.72|that um and but it will be interesting
3810.119|4.24|like it will be surprising if it
3811.96|4.399|generates this on like very long prompts
3814.359|4.081|or prompts from like math or something
3816.359|3.401|which are just hard to kind of like
3818.44|3.8|evaluate when there are like two
3819.76|4.519|responses which are at least as a human
3822.24|3.64|like when I see like a bunch of code
3824.279|2.76|like you know on this side and this side
3825.88|2.439|and then that's very hard to say and
3827.039|3.681|both of them are trying to do the same
3828.319|5.201|thing but a very different approach it's
3830.72|7.28|very hard to evaluate them right um and
3833.52|4.48|so um yeah we haven't looked into
3842.559|5.841|that perhaps another thing is do you
3844.88|6.88|think order matters like which um out
3848.4|6.0|you get to G4 first yeah I mean that was
3851.76|4.519|basically the takeaway was that you know
3854.4|4.159|so it's interesting because humans
3856.279|3.681|usually have recency bias which is
3858.559|2.681|essentially the last thing that you read
3859.96|3.399|is the thing that you remember and so
3861.24|3.879|you would just you know try to like you
3863.359|3.68|know choose that more you know you're
3865.119|3.96|just inclined to do that and gbd4
3867.039|4.24|actually had a left bias so the F thing
3869.079|3.841|that it first saw in some sense and I
3871.279|3.28|think some like I think Alum sis was the
3872.92|4.04|one that proposed because it has this
3874.559|6.56|left to right training maybe that's why
3876.96|5.879|it has that uh kind of a bias but um but
3881.119|4.281|yeah so I think the way we elevated that
3882.839|4.76|was that you know having every model's
3885.4|3.8|output be equally likely to be on the
3887.599|4.081|left and the right inside so if like
3889.2|4.639|we're doing alaka and vuna then instead
3891.68|4.0|of just doing alpaka on left and vuna on
3893.839|3.76|right we would just randomly like switch
3895.68|4.76|them and so both of them are likely to
3897.599|2.841|occur in both these
3900.799|6.24|positions and you still s
3904.16|5.6|l if you just ask it to like rate it on
3907.039|4.76|a scale of fun yes but if you say that
3909.76|4.12|you know hey you have this bias and make
3911.799|3.681|it try to make it aware of it then it
3913.88|4.679|flips and it generates something like
3915.48|3.079|that so
3923.079|3.0|yeah
3939.96|5.399|is there other approaches where you can
3942.119|4.281|you prompt them out by shuffling the
3945.359|2.92|promps and then
3946.4|4.52|[Music]
3948.279|4.8|you
3950.92|4.119|deas de
3953.079|6.52|results
3955.039|4.56|uh by shuffling the promps you mean like
3960.16|5.32|uh order how
3963.079|4.96|you put
3965.48|5.079|the yeah so that's what we did is that
3968.039|5.121|you know we would like you know randomly
3970.559|5.76|Shuffle the left and the right and then
3973.16|5.679|so each model so like so basically like
3976.319|4.401|you have you create nc2 combinations
3978.839|5.24|suppose you want to evaluate three
3980.72|5.399|models on 10 prompts so you'll have 10 C
3984.079|4.04|two combinations where n is the number
3986.119|4.081|of forms um oh sorry the number of
3988.119|4.121|models and then you would like you know
3990.2|3.52|basically like generate like so this
3992.24|2.72|will be a total data set so like you
3993.72|3.319|know you would have generated 10
3994.96|4.24|responses from each of these models and
3997.039|5.04|then put them together in this 3c2
3999.2|5.2|setting and then uh so like that would
4002.079|4.121|be like a combination of each of these
4004.4|3.919|and then you make sure that every time
4006.2|3.96|the like the models on the left are
4008.319|4.081|equally likely to also occur on the
4010.16|4.08|right so if you are doing like model one
4012.4|3.28|and then model two then you also make
4014.24|3.76|sure like you also do model two and then
4015.68|5.32|model one on a different
4018.0|3.0|prompt
4027.76|4.92|so there's more
4029.68|3.0|question
4040.52|5.4|okay oh okay sure
4042.92|3.0|sorry
4047.4|2.879|should I keep the zoom
4063.119|3.2|on thank
4067.079|3.881|you ask one about
4072.119|3.801|what just
4076.039|5.161|so um on the
4078.359|4.76|reinforc build reward model and that
4081.2|4.399|reward model I take text input and then
4083.119|4.401|humans give it scores supervis problem
4085.599|5.68|we trying to predict from the text the
4087.52|3.759|score and then I have a reward
4097.08|4.92|model statement total and I pump that
4099.48|5.52|through the reward model optimiz this
4102.0|4.199|yes that's that's how rewards right only
4105.0|4.4|have rewards at the
4106.199|4.52|very that's how you yes exactly and so
4109.4|2.6|you have to it's very sample and
4110.719|3.6|efficient in sense you have to keep
4112.0|4.319|doing this again and again and then
4114.319|4.88|that's why you need 100,000 examples for
4116.319|7.681|doing ARA but only 10,000
4119.199|4.801|for that's kind of the okay great thanks
4127.4|3.0|very