start_time|end_time|text
0.64|3.88| Yeah, hi, everyone. So lots of exciting things happened again
4.52|3.68| this week. So always tricky to be selective and to keep the
8.2|3.72| number of topics small and manageable. So for this week,
11.92|2.56| since we talked about convolution neural networks
14.48|3.64| this week, I selected a few topics related to that topic. So
18.12|4.52| one is a paper on analyzing the bias of different methods and
22.64|4.92| also introducing certain type of MNIST data set for analyzing
27.56|4.32| biases. And then I will also talk about a new convolution
31.88|2.8| network architecture that was introduced this week, which
34.68|2.68| might be also interesting to you and also interesting in the
37.36|3.64| context of your class projects. So with that, let's get started.
45.72|3.52| Yeah, previously, we discussed that there can be big issues
49.24|3.32| with bias when we apply deep learning to certain types of
52.56|4.24| problems. For instance, this is something I took from a previous
56.8|3.4| video when we discussed this particular system where people
60.2|5.6| trained deep neural network to judge job applicants. And in
65.8|3.72| particular, the big issue here was that the system was rating
69.52|3.92| job applicants substantially differently. If there was a
73.44|2.72| bookshelf in the background, and of course, that's something
76.16|5.12| that should not happen. So this week, there was a paper on
81.96|3.96| evaluating different systems for mitigating such bias. So there
85.92|2.72| are different techniques that were developed. And the
88.64|4.72| question is essentially, how good are they? Really? So the
93.36|3.8| learning of these inappropriate biases can cause deep learning
97.16|3.84| models, essentially to perform really badly on minority groups.
101.0|3.96| That's something we want to prevent or avoid. And these
104.96|2.76| methods that have been developed, the question is
107.72|4.12| essentially, do they really work? And how useful are they? If
111.84|2.76| you recall, there was also a paper that I presented a few
114.6|3.04| weeks ago, where someone essentially said, Yes, these
117.64|4.56| methods work, but only like in a very stereotypical sense of
122.2|5.12| fairness. But in any case, so I think, um, yeah, one, or there
127.32|3.56| are multiple problems, one is essentially, does it even make
130.88|3.84| sense? Or is it a good idea to even apply this model to a given
134.72|4.88| type of problem? The other one is then what methods can we use
139.6|6.04| to, let's say, reduce the bias? And then also, how can we assess
145.64|2.56| that really, whether these methods really work? So they're
148.2|3.16| like these three different levels of questions we should
151.36|5.48| ask. So here, what the authors did is they try to improve the
156.84|3.64| evaluation protocol and also provide a new data set, they
160.48|2.88| call it the biased MNIST data set. And in particular, they
163.36|3.6| evaluated seven different methods and their code and data
166.96|6.36| sets are available here on GitHub. So here's an overview
173.72|3.4| from the paper, how they kind of describe the problem of
177.12|4.08| analyzing the biases. So there are different types of data
181.2|3.76| sets, there was this Q&A data set. And there's also the
185.2|5.92| setup a data set, which we may be using later in this class in
191.12|4.28| the context of generative adversarial networks, also, or
195.4|2.72| variational auto encoders, I will also make a few examples.
199.44|4.96| But yeah, essentially, this Q&A data set, it's, it has difficult
204.92|6.2| types of biases included. And the ease of analysis is not good,
211.12|4.36| though. So even though this is maybe good data set for having a
215.48|2.96| challenging task for neural network, in terms of biases,
218.6|4.64| it's not so easy to analyze. And the setup a data set, and the
223.24|3.2| colored MNIST data set, which is essentially a version of MNIST
226.44|4.16| with colors, they are both easy to analyze. But the biases to
230.6|4.32| detect are too simple to really, I would say, or what they say is
235.24|3.8| that simple to really assess the different methods for mitigating
239.04|3.44| bias. So they develop this bias MNIST data set, which they say
242.48|4.68| is easy to analyze, and also provides an adequate difficulty
247.16|7.16| of these biases. So the task in this biased MNIST data set is as
254.32|3.56| follows, it's also about recognizing 10 different digits
257.88|5.28| from zero to nine. And these include nine, no, sorry, seven
263.28|3.48| different sources of bias. So one is the background color, the
266.76|3.76| color of the target digit to be classified, the position of the
270.52|5.76| digit. So they have nine grid locations on the distractor
276.28|3.74| shapes. So they have other shapes in that image to distract
280.02|3.94| from the prediction, the color of these distractors, the type
283.96|2.92| of texture, and the texture color. So that's essentially
286.88|4.48| background. Also, in a way, I mean, they have the background
291.36|2.88| color, but then they also have these background textures. So
294.24|4.04| here's an example of how this might look like. So in the top
298.28|4.0| row is the digit one, so we can see it here. And they say, for
302.28|4.8| instance, on that, in this example, the one is most often
307.08|4.0| green, and is most often placed on a purple background. And it
311.1|3.82| often occurs or co occurs with right angled triangles, like you
314.92|4.76| can see here, but sometimes they have a different color, for
319.68|5.0| example, making it red. So this, in this case, when it's green,
324.68|4.02| it would be the majority. And if it's another color, it would be
328.7|4.7| the minority class or group. So that way, for each digit, they
333.4|5.32| have something that is common, again, among the majority class
338.72|3.0| and not so common in the minority class, for instance,
341.72|3.18| changing the color or changing the background and these types
344.9|6.26| of things. So with that, they try to assess how sensitive the
351.16|6.28| network is towards these things that are not the digit itself.
357.44|3.64| So how sensitive is the network towards changing the color of
361.08|3.32| the distractor or the shape of the distractor and so forth, and
364.56|3.2| how sensitive is the network towards the placement, whether
367.76|4.2| it's in the center here on upper part and things like that. So
371.96|4.0| there are different types of distractions that they try to
375.96|4.24| analyze, whether the network is focusing on the digit itself, or
380.2|5.96| other things like color, and so forth. So here are some results
386.16|3.24| from that paper, I must say, it's a little bit tricky to
389.4|3.76| interpret. So I hope I understand this correctly. It
393.16|4.28| was not very, or entirely clear from the paper. But based on my
397.44|3.6| interpretation, let me walk you through this. So first, let's
401.04|4.52| take a look at this MMD plot here. So they define MMD as the
405.56|4.12| majority minority difference, measuring the difference between
409.68|2.76| majority minority groups. So they compute the accuracy of the
412.44|3.6| majority class. For example, if you consider from the previous
416.04|3.56| slide, the MNIST digit, the green one, that would be the
419.96|3.04| majority class, and then the minority class would be when
423.0|7.56| it's a red, for example. So yeah, so they have the MMD here
430.56|3.76| for different types of biases, the seven different biases that
434.32|3.84| we talked about in the previous slide. And they focus on one
438.28|3.12| bias at a time that they call the explicit bias. And that is
441.4|3.68| the one that the model is addressing, and they implicit
445.08|3.88| biases are the ones that are not addressed. And here the box
448.96|2.5| spot is over when I said correctly over the different
451.46|3.06| methods. So we'll take a look at it afterwards. But there are
454.52|3.56| seven different methods listed down here. So the box spot is
458.08|4.12| across the different methods. So for instance, what you can see
462.2|3.92| here, if methods treat background color as explicit
466.12|4.88| bias, you can see, on average, or the median here is lower
471.56|3.28| compared to the implicit bias. So implicit biases are the ones
474.84|3.72| not treated. And they look at it for the different types of
478.56|5.16| biases as the explicit bias. And you can see, in all cases, the
483.72|6.68| explicit bias, or the median here of the explicit bias is
490.4|3.5| lower than the median of the implicit ones. So the methods
493.9|4.1| are essentially working to some extent, in terms of lowering
498.0|4.36| the bias of a target variable that you specify, for instance,
502.36|3.28| destructor shape, destructor color, and so forth. For digit
505.64|2.48| position, we see there's not much of a difference. It could
508.12|3.84| be because convolutional networks are naturally somewhat
512.0|3.6| equivalent to the position. And people also often naturally use
515.6|5.32| data augmentation already for random cropping the inputs. But
521.08|2.24| other than that, you can see there's a large difference
523.32|3.04| between explicit and implicit bias. So the methods are
526.36|3.48| working to some extent, but also at the other hand, they are far
529.84|3.84| away from zero. So they're not working very well. And you can
533.68|3.36| see, for the ones that are implicit, the implicit biases,
537.04|3.0| they still exist. And there's a huge difference between 30 and
540.04|4.68| 40%. This is like a huge difference between the majority
544.72|4.72| and minority classes. So looking at these methods in more detail
550.32|4.72| here, so what we can see here is seven methods. This is STDM.
555.04|3.92| This is the what they call the standard method. And this is
558.96|3.6| this is just a baseline model, you can think of it as the
562.88|4.56| baseline. And then they have seven other methods they
567.44|5.4| compared to. So let's say the up WT here. So for this up WT,
573.2|3.48| they kind of was drawing over it. But there's this on
576.72|4.88| explicit bias, you can see that. So now the box, but I also say
581.64|2.28| when I understand it correctly, the box plot now the range of
583.92|3.08| the box plot is over these different types of implicit
587.0|2.92| biases. So the range is now over the implicit biases. And you can
589.92|9.4| see across these different biases. When in this case, you
599.36|5.96| take a look at one explicit bias, it's close to zero, but
605.32|3.84| the implicit biases, the other ones are still high. So how I
609.16|4.92| think they analyzed it is they considered all these biases,
614.08|3.96| like a for loop over the biases, and then they treated each one
618.04|3.12| as the explicit bias, while treating all the remaining six
621.16|4.12| ones as the implicit ones, and then averaging over that. So
625.28|6.48| that's how on average the method performs. When you rotate what
631.8|4.84| explicit and implicit biases are, you can see, this method is
636.64|2.68| pretty good at dealing with these explicit biases, if you
639.32|4.04| specify it, but all the others are still a big issue, actually,
643.36|4.28| even bigger than in the standard model. So in that way, if you
647.64|3.64| use that method, you may be fixing the explicit bias that
651.28|3.16| you specify, but you make everything else worse. And
654.44|4.44| overall, there's no real method that can deal with all the
658.88|4.0| implicit biases, you can see. Yeah, there are big issues
662.88|4.0| everywhere. Maybe this method here, it's on for the explicit
666.88|4.44| and implicit biases, the lowest, think really, the tricky part is
671.32|3.36| the implicit biases, because that's something that can be
674.68|3.32| lurking in your data set, explicit biases, you can be
678.0|2.84| aware, even if it exists, you can maybe tell people, okay,
680.84|2.8| this is something to look out for, but implicit biases, I
683.64|2.68| think that's maybe an even bigger issue. But yeah, you can
686.32|5.96| see all these methods. They are not super robust to these types
692.28|2.64| of issues. On the right hand side, there's a different
694.92|4.68| evaluation, they call it the iOS M, which is the improvement
699.6|3.48| over the standard model. And this measures the difference in
703.12|3.08| the group's accuracy compared to the standard model. And also
706.2|5.0| here, you can see that for most cases, these models or methods
712.28|4.8| have issues. But for celeb A, there are some methods where
717.08|3.88| there is really low row difference for these four types
721.32|4.24| of biases. So there are methods that address this very well on
725.56|4.48| simple data sets like celeb A. But then when they look at this,
730.08|3.72| biased MNIST, these issues still occur because you can see LNL
733.8|3.08| and I am for these are these two. So these still have
736.88|3.48| issues. So yeah, with that, you can see maybe the biased MNIST
740.36|2.52| data set is also something to consider when developing
742.88|3.56| methods, because the celeb A data set on the right hand side
746.44|4.48| might be too simple. Alright, but yeah, this is, I think,
750.92|3.24| still an active area of research. I'm also no expert in
754.16|3.72| this field, I just thought this might be an interesting paper to
757.88|4.56| look at and a new data set for evaluating potential methods for
762.44|1.24| mitigating bias.
766.48|3.24| Alright, let's now talk about a convolution neural network
769.72|3.88| architecture. So in class, we only talked about a few of them,
773.8|3.24| because we have we have timing constraints. But yeah, there are
777.04|2.88| always more interesting ones. And one I mentioned was
779.92|4.08| efficient nets. So just to recap, or not recap, but just to
784.0|2.08| introduce them, because we haven't even talked about them
786.08|4.2| yet. There was the efficient net architecture or family of
790.28|3.56| architectures introduced about two years ago. So that's not
793.84|3.6| news, we will get to the news in the next slide. But essentially,
798.04|5.12| this is an approach for building efficient neural network
803.16|6.76| architectures. So it's about scaling up convolution networks,
809.92|3.84| using a compound coefficient. So traditionally, there are three
813.76|3.72| different ways we can scale convolution networks. One is
817.48|4.4| here by adding more layers, one is by making the layers wider,
822.08|4.48| and one is by changing the image resolution. Usually, if we
826.56|3.52| increase the image resolution, the networks don't perform so
830.08|4.2| well. So we have to do also changes to the layers and the
834.28|4.56| number of layers and the width of the layers. So the idea
838.84|5.32| behind efficiency, efficient net is to analyze how scaling kind
844.16|4.92| of relates to each other. So here, they are coming up with a
849.16|3.16| certain formula to do the scaling of these three
852.32|5.04| components. And what they found is that, yeah, by their approach,
857.36|3.56| they can achieve a better accuracy with fewer parameters,
861.28|4.88| and also having networks that work or run faster than
866.16|3.8| reference networks when they apply the scaling. So here on
869.96|4.52| the left hand side is comparison. So you have, for
874.48|5.4| example, resonant over 52 here, so big network, dense net,
880.16|5.0| inception, and so forth. So here they are as the number of
885.16|4.2| parameters. So on the right, these are bigger, of course. And
890.04|4.84| on the y axis is the performance on image net. So you can see
894.88|4.96| that this efficient net is smaller in terms of the number
899.84|3.0| of parameters than other reference architectures appear,
903.0|4.38| but it's also fast. So sorry, better performing. So looking at
907.38|5.02| the best performing network might be this one. Let's look at
912.4|2.84| the best performing network that is not efficient net, it might be
915.28|4.16| this one. So you can see that this one might be comparable or
919.44|4.52| here before if I go straight, so you can see you they develop a
923.96|3.52| much more efficient architecture that reaches the same accuracy
927.48|3.6| as this mover net here. So that is actually a really interesting
931.08|4.56| approach, this efficient net. Yeah, the news here is though
935.64|3.36| there is an efficient net version to know which was
939.0|4.24| released awesome April 1. So there were two April 1 papers
943.24|2.36| and you have to be always a little bit careful with April
945.6|5.2| 1. Like, you probably remember from my car network that might
950.8|4.32| be sometimes not a true network might be just a fun thing.
955.48|3.24| April's food joke. But yeah, in this case, it seems to be a
958.72|3.56| legit paper. And it's actually a pretty cool one. It's extending
962.28|4.8| efficient net to perform even better. So here, they introduced
967.08|4.4| new operations such as the fused MB convolution, we won't go into
971.48|2.44| too much detail about that. But it's essentially about
973.96|4.24| progressively increasing the image size during training. So
978.64|3.2| usually, when you increase the image size, the performance
981.84|2.96| degrades, there's also more overfitting, it's probably just
984.8|4.96| due to the fact that there are more pixels now. And what they
989.76|4.04| do is during training, they scale the resolution
993.8|3.44| progressively. And then while they are doing that, they are
997.24|3.24| adaptively adjusting the regularization using both drop
1000.48|4.84| out and data augmentation. So here, they have now a way to
1005.88|3.8| train with larger images, while adaptively reducing the
1009.68|3.44| overfitting, which I thought is a cool idea, too. And you can
1013.12|5.64| see, this is the actually all of them are efficient net version
1018.76|5.52| two architectures. Um, and you can see they all perform better
1024.32|3.32| than much better than the efficient net version one here.
1027.64|6.2| So it's actually a huge improvement. It's 83 to 87 4%
1033.84|6.04| points on image net. And while still being efficient. Yeah,
1039.88|3.44| since we recently talked about different optimization
1043.6|3.04| algorithms, and we also had a quiz and exam question on that,
1046.64|4.16| I just wanted to introduce a new one. So there's now mad grad,
1050.8|4.72| which does not stand for mad grad student. But yeah, it's
1055.56|6.48| it's an modification essentially of at a grad and Adam. So they
1062.04|2.36| say that Adam doesn't quite reach the goal of being a
1064.4|2.92| general purpose deep learning optimizer. And the mad grad
1067.36|3.28| method is directly designed to address these issues. So Adam,
1071.36|4.04| and SGD with momentum, they work well across different types of
1075.4|4.36| problems, but not all problems. So it's a little hard to see
1079.76|4.52| here. On the left hand side, this is Adam here. And on the
1084.28|5.36| right hand side, Adam is up here in the top performing region.
1090.24|8.4| And for SGD, let me underline this first GD plus momentum. I
1098.64|5.84| think it's up here and up here. And you can see, sometimes Adam
1104.48|4.08| is better, sometimes SGD is better. And they have now
1108.6|4.52| apparently in a new method, mad grad, which is always
1113.16|6.16| performing well, it's always somewhere up there. So that is
1119.32|3.6| maybe another interesting thing to check out. So I haven't tried
1122.92|3.08| this in practice yet. And yeah, but if you're interested,
1126.0|4.64| that's another interesting thing to try. They have the code on
1130.64|2.56| GitHub, I think it's also linked in that paper. So I haven't
1133.2|3.16| looked into detail into this paper. But it might be another
1136.36|5.36| interesting method to consider. So yeah, last week, I briefly
1141.72|3.08| mentioned this new tool for tracking machine learning
1144.8|5.36| experiments called aim, aim is for some reason not on this list
1150.16|3.48| here. But yeah, here is an interesting list of different
1153.72|4.32| experiment tracking tools. Last week, I also mentioned ml flow
1158.04|3.84| and tensor board. But yeah, here are a few more of these. So this
1161.88|4.04| graphic was made by the people at Dex hub, which is also in
1165.92|3.28| here. So you should take this graphic maybe with a grain of
1169.2|5.96| salt. But it's still maybe an interesting table, where you can
1175.16|4.0| find different, yeah, alternatives for tracking
1179.16|2.76| machine learning experiments, which may be useful to you if
1181.92|2.96| you're working on your class project, and you want to, I
1184.88|2.6| would say take a more organized approach compared to, let's say
1187.48|3.16| tracking the performances of your models in an Excel
1190.64|4.76| spreadsheet or using matplotlib. Personally, I'm not extensively
1195.4|3.88| using these methods. With a colleague, we are using ml flow
1199.28|4.28| right now, I sometimes use tensor board. But often, I also
1203.56|3.04| don't use either of them. I think others are also pretty
1206.6|2.8| good. It's really just a matter of taste and how big your
1209.4|4.52| experiments are. And if you are doing a lot of experiments, a
1213.92|3.52| lot of the time, then of course, it might be worthwhile investing
1217.44|2.92| in some of these. It's essentially with everything like,
1220.56|5.2| it really depends to find the sweet spot between not using
1225.76|2.52| something that is kind of overkill for what you're trying
1228.28|3.56| to do. But also, if you're doing something frequently and often
1231.84|3.7| on a large scale, before reinventing the wheel and
1235.54|3.78| writing your own tool for tracking, maybe look whether
1239.32|2.56| there's something out there already that can solve your
1241.88|4.6| problem. Alright, so with that, that's it for this week. Next
1246.48|4.2| week, we will be wrapping up the lecture on transfer learning.
1250.68|26.44| And then we will talk about recurrent neural networks.