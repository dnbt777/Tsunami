start_time|end_time|text
0.48|3.92| All right, let me now show you how we can implement residual
4.4|4.64| networks in pytorch. So I will show you two notebooks. First is
9.06|3.7| a naive implementation I have made myself. And then I will
12.76|4.4| show you a more sophisticated implementation of resnet 34 from
17.16|4.08| the pytorch community. So in this first notebook, now I will
21.24|3.8| show you what we talked about in the last video, these two
25.2|3.98| different types of residual blocks. And then in the next
29.18|4.08| notebook, I will show you this residual network with 34 layers.
33.68|3.58| So yeah, I'm not going to rerun this notebook, it didn't take
37.26|5.46| too long. But yeah, why waiting if, if it's not necessary. So
42.72|5.82| we'll show you just the results. So um, yeah, here, it's just a
48.54|5.78| boilerplate, importing torch and numpy, the usual stuff for the
54.32|3.04| data set. So I'm not using the helper functions here, because
57.36|4.52| yeah, it's really just very simple. So I didn't really
61.88|5.12| focus on abstracting things, I just coded the residual blocks.
67.0|5.12| And this is a self contained notebook in that way. So here,
72.16|3.14| I'm using the MNIST data set just for simplicity, because
75.32|3.04| just wanted to have a data set doesn't really matter which one,
78.52|2.64| because this is not going to be a good convolution network. It's
81.16|3.72| just like more of a proof of concept how the residual block
84.88|3.72| works. So the data set really doesn't matter that much here.
89.12|4.8| So here, I'm implementing now this residual block, the one
93.92|5.14| where the input has the same dimension as here, the output
99.06|6.78| from the residual part. So how does it look like? So this one,
106.04|4.52| so I implemented it using the torch module class, just a
110.56|4.32| regular confinet that I'm implementing here, I have a
114.88|4.12| confinet with two residual blocks. And each of those is one
119.0|4.24| residual block. So you can see that this convolution here
123.24|3.52| represents this one. So here, I'm starting with one channel for
126.76|6.84| output channels. Then I have batch norm. Then I have relu. By
133.6|3.16| the way, I haven't really explained what that one one
136.76|3.32| means. I think I have used that before in some other code. So in
140.08|5.4| place equals true. This just means that pytorch doesn't have
145.48|5.04| to make a copy of that array internally. So we could do
150.52|3.52| something like that. I mean, not here inside, but in general, we
154.04|1.0| could do something like
160.64|5.0| like this. Just let's write it like this. So this will create
165.64|6.68| a new a new tensor x and then overwrite this tensor x. So it's
172.48|3.96| essentially overwriting this tensor x. But for a brief moment
176.44|3.92| in time, when this gets executed, there are two arrays
180.36|3.8| of this is an existing ones, if I have some previous
184.16|4.64| computation here. So this previous computation created x.
189.2|4.2| And then when I'm calling this, it will take an x and create a
193.4|4.04| new version while x is still in memory. So for a brief moment in
197.44|4.68| time, I have to erase in memory, it's not a big deal at all. But
202.16|2.92| you have to I mean, under the hood, allocate memory in the
205.08|3.12| GPU and stuff like that. So it's kind of a little bit more
208.64|4.84| expensive to do that compared to doing an in place operation. And
213.48|4.4| in place operation is essentially modifying something in place
217.88|3.44| without creating a new array. So it's slightly more efficient.
221.32|2.64| It's not always possible to do that. But yeah, if you can do
223.96|3.6| that, it's actually nice. So it's essentially the difference
227.56|3.76| between let's say, writing this and x plus equals one in that
231.32|3.6| sense, you are directly modifying something. Whereas
234.92|3.44| here you are having creating a copy and then assigning the
238.36|0.72| copy to it.
240.28|3.24| Anyways, it's a little tangent. The results are exactly the
243.52|2.72| same whether you do this or this. And in practice, you
246.24|2.72| probably won't notice any difference anyway. So it does
248.96|4.84| not really matter. But yeah, why not doing it? Alright, so small
253.8|3.72| tangent. So we have convolution, batch norm, and then this relu
257.56|4.4| this is this part is really the first three. And then we have
261.96|2.56| another convolution and the batch norm, which is this part.
264.84|3.28| Notice that I'm going from one to four, and then back from four
268.12|3.74| to one seems kind of weird. But why am I doing that? Yeah, it's
271.86|2.86| really like to match the dimensions. Otherwise, I will
274.72|3.16| have more channels here than I have as an input. So I would
277.88|3.28| have fought channels here, and then one input channel. And that
281.16|2.92| doesn't really work if we add them, because then it's not an
284.08|4.48| identity anymore. Okay. Yeah. And we also have one fully
288.56|5.12| connected layer. This is just to make this classifier. So yes, I
293.68|4.4| am implementing this. So here, I was just defining or
298.08|3.28| initializing these layers, the blocks and he I'm calling them.
301.36|6.12| So in the forward pass is really where things happen. So I save
307.48|5.84| x as the shortcut here. So I'm saving this year, then I'm
313.36|5.76| calling my block. So this part, I highlighted here, this is
319.12|5.92| really calling this whole block, right? So it's this whole block.
327.6|5.2| And actually, I could have these are kind of redundant, I could
332.8|3.04| have used the same. Okay. But then of course, the weights are
335.84|4.2| different. Anyway, sorry. So I call my block here. And then I
340.04|4.04| have my relu function. And the relu function is applied to x
344.08|5.84| plus the shortcut. So this part really is this part. So I'm, I'm
349.92|2.88| adding inside and then I'm applying the relu. So the relu
353.16|3.24| that is what is shown here. And here I have this addition,
356.96|3.2| right? So this is essentially one residual block. And then I'm
360.2|3.88| repeating it. So why am I not using one here? Well, then it
364.08|4.24| would be the same layer, it's that wouldn't work really. Okay.
370.84|3.2| But the shape is the same, it's just we have different weights,
374.04|4.48| right? So it's just like having two convolution layers after
378.52|4.4| each other. And then we have this linear here, which is
382.92|12.4| turning this into a classifier. Alright, so so the linear layer
395.32|4.72| has output the num classes. And here I'm just flattening it. So
400.04|6.52| I'm assuming what comes out of this block two has a
406.56|7.62| dimensionality 28 times 28 is 784. Yeah, and then I'm running
414.18|3.02| this. So I'm just pasting my convenience functions that I
417.2|2.5| usually have in my helper function, it's a slightly
419.7|2.58| simpler version, because I'm not plotting anything, I just want to
422.28|3.06| show you that this actually runs doesn't get great performance,
425.34|4.74| because of course, it's a very naive implementation. There's
430.08|4.12| also only the training accuracy, the test accuracy is 92%. So
434.2|2.92| what I show what I mean is, how do I know that this is the
437.12|2.8| actual number? I mean, I can think about it, I can look at
439.92|2.5| this. But like I explained in the previous video, what I can
442.42|6.14| also do is what most people do is just print x dot size, then
448.56|10.88| you can oops, run everything here. Then can run the training
459.44|2.2| and then you will see the size. Of course, you don't want to
461.64|2.4| complete it because it's annoying to have it here. So I
464.04|4.44| just stopped it, I can see all it's 128 times 28. And that is
468.6|5.64| what I can then copy and paste and then go here and put it in
474.56|5.24| here. Right. So that's where this number comes from. And it
479.8|8.24| is also where this number comes from. Okay. In practice, if you
488.04|3.44| don't want to think about it too hard, and you are debugging
491.48|3.2| things, I mean, it doesn't hurt to insert a print statement.
494.68|5.84| That's what everyone is doing. Okay. Um, so we trained that.
500.72|4.52| No, of course, I interrupted it. But suppose it trained, I mean,
505.24|4.48| it trained before. So if I fix it, it would train. Now, the
509.72|4.66| second part, now focusing on the more interesting part where we
514.38|4.26| have this resizing here. So I'm implementing this a little bit
518.64|5.08| differently now using a reusable unit, I call that a residual
523.72|4.2| block. So I'm implementing my residual block here. And this
527.92|6.2| one is implemented the same way. Now, it's a little bit more
534.12|3.44| general, I have something called channels here, this is the input
537.56|3.24| channels, or let's say the first number of channels, the output
540.8|4.48| channels. And then here, I have one and two. So I'm going from
545.28|6.72| zero to one to two. And I can, I mean, I'm not defining what
552.0|2.56| these numbers are, I'm defining them later, when I'm calling
554.56|2.72| this, I can maybe briefly skip ahead. So I'm using this
557.28|2.88| residual block, actually, in my convolutional network here. So
560.16|2.44| I'm using it here. And here, I'm defining the channels, I'm
562.6|4.68| going from one to four to eight. So
569.56|2.52| yes, so that's what I'm doing here. So I'm going from zero,
572.08|5.96| so one to four, sorry, one to four to eight. And then I have
578.04|3.88| my shortcut, which goes also from zero, sorry, from one to
581.92|3.92| eight. Otherwise, I wouldn't be able to edit because if let's
585.84|4.84| say this is one channel, outcomes, eight channels, then
590.68|2.24| this also has to be eight channels. Otherwise, I can't
592.92|8.2| edit. So that's what's going on there. So my residual block
601.12|3.48| block, scrolling up again, so we can see everything. So my
604.6|4.12| residual block 123, this is really on this part, these three
608.72|2.8| first blocks. And then like before, the second blocks are
611.64|3.24| this and this. Now, the difference is that I have
615.2|3.92| different numbers of channels. And I can also reduce the size.
619.64|4.52| Right. So yeah, I have a stride of two. So that will reduce the
624.16|4.0| size, I have to do a stride of two here to to match these
628.16|2.92| dimensions. So yeah, I have to be a little bit more careful
631.28|5.12| that the dimensions match also. Yeah, and then as before, I have
636.4|4.36| my block, I have a shortcut, and both the block plus shortcut,
641.04|3.4| they go into my relu function. So this is what I'm showing you
644.44|3.52| here, this residual block is really this whole thing here.
649.16|3.68| And then I'm using my residual block, I'm initializing one
652.84|3.2| residual block, and another so I have a network with two
656.04|2.74| residual blocks, the first one goes from one to eight, and the
658.78|5.12| second one from eight to 32. And the number of the size is here
663.9|4.24| seven times seven times 32. So it's because we are also having
668.18|4.32| the dimensions here, half and half approximately. So going
672.5|6.44| from 28 times 28 to 14 times 14, and from 14 times 14 to seven
678.98|6.16| times seven. Yeah, this is essentially it. So that's how we
685.14|8.2| implement this. So yeah, then we are training it trains here, and
693.34|4.68| it performs much better than our previous implementation. But
698.02|4.36| again, the goal of residual networks is really to go deep in
702.38|2.4| the network in terms of the number of layers. So here, we
704.78|3.0| only have two layers. So I mean, this is probably not a great
707.78|3.68| network to use for other data sets. Here, we are just using
711.46|3.52| MNIST. So if we want to use a more, I would say sophisticated
714.98|3.08| data set, I'm actually only using cipher 10, because it's
718.1|2.64| simple to a lot. But if you want to use a different data set,
721.14|3.84| ResNet 34 is a good choice. So this is the one, the deep one
724.98|3.36| here, it performs pretty well going back here, it gets
728.38|3.72| actually pretty good performance on an image net to one accuracy
732.42|5.4| better than VGG, for example. And how does that work? So it's
737.82|8.6| the same concept, like shown on sorry, like shown here, except
746.46|3.68| more, I would say more sophisticated implementation of
750.14|2.8| that. So I could have implemented it by hand, but
753.26|3.32| there's always the chance to make mistakes at some point. So
756.58|3.84| why not using what's already implemented? So here, this is
760.42|3.0| again, I'm using my helper functions, that's again, the
763.42|4.38| same that explained for VGG 16. So everything is the same as
767.8|3.34| for VGG 16. So I don't have to discuss everything again, the
771.14|4.56| only new part here is really this part, the model. So here, I
775.7|2.88| actually copied the code from this website, which is an
778.58|4.68| implementation, the official pytorch implementation, which
783.62|3.56| has different versions of ResNet, wide ResNet, regular
787.18|5.58| ResNet, 18 layers, 34 layers, 100 layers, 152 layers, and so
792.76|6.36| forth. I grabbed the code that is used to initialize all of
799.12|2.78| these networks. So they have written some code that can be
801.92|3.5| reused for different types of residual networks. So here was
805.66|3.92| copying it and simplifying a little bit. So it's not that
809.58|2.36| long. And then they have something they call the
811.94|3.28| bottleneck. It's kind of similar to what I call the residual
816.02|5.72| block. What we have here. And then I mean, it's relatively
821.74|4.36| complicated, I have to admit, it would take me also a couple of
826.1|3.54| hours to really understand how that is implemented. The most
829.64|2.64| important thing is that it works. Many people are using it.
832.28|3.64| So I'm kind of trusting that this is indeed working. So they
835.92|3.48| have like a make layer method here or function here that
839.4|2.56| creates these layers, it's a little bit more sophisticated
841.96|4.64| than than my version. So and then in the forward method, you
846.6|3.62| have these different layers. So each layer has also multiple
850.22|3.5| conversion layers. That's how you get the number 34. And we
853.72|3.16| can also use the torch flatten function here. That's actually
856.88|2.16| something I should also maybe use more often. It's a more
859.04|3.4| recent thing. So I could actually technically replace
864.0|4.62| replace that one by flatten. So here that could be replaced by
868.62|2.38| flatten. But I still need to know this number anyways,
871.0|2.36| because I have to put it here for the number of parameters. So
873.36|2.76| even though we can put a torch flatten here, it's it's not that
876.12|8.4| much simpler. Um, yeah. So that is essentially it. So here, I
884.52|2.42| would have to know still this number in this linear near the
886.94|2.92| 500 to 12. So I could technically also write this as
890.16|8.0| torch. view, minus one, five, 12, think blocks expansion here
898.16|3.28| is one, this is only used for the other types of networks or
901.44|3.72| other residual nets. So could technically also write it like
905.16|3.72| this. But yeah, we have this nicer flatten thing. What's
908.88|3.56| nice about flatten is everyone knows what flatten that it has a
912.44|3.72| meaning that is more intuitive, maybe than saying view, minus
916.16|6.16| one or something. Okay. Yeah, yeah, it's also the same code
922.36|4.12| that I used for the VGG. And now it's training. Actually, we are
926.48|7.72| using cipher 10 here. Let me open this one again. So here, I
934.2|6.16| have 70 by 70 images, scrolling up, sorry. Yeah, I have made it
940.36|2.6| larger, because otherwise, the performance was really poor. I
942.96|2.48| mean, all these types of networks are really implemented
945.44|4.52| for bigger data sets, not cipher 10. I'm just using cipher 10.
950.12|2.76| Because then we don't have to download a separate data set, if
952.88|3.8| you want to reproduce these results. And I showed you how
956.68|4.04| you can use your own data set, too. So in that way, shouldn't
960.72|2.14| be an issue for you. But if you have questions, you can always
962.86|4.22| ask, I'm happy to help with that. So here, with Resnet, we
967.08|4.6| get approximately 48%, which is not much better than what we got
971.68|5.1| with VGG 16. Here, it's also kind of the same. But notice,
976.8|3.2| even though I use larger images here, it was at least at least
980.0|6.44| faster to run 62 minutes versus 90 minutes. Okay, so if I if I
986.44|2.84| would have made the images smaller here, the same size, it
989.28|3.48| would have probably finished in like 30 or 40 minutes. Also,
992.76|4.24| overfitting. So here might be a case for adding more dropout. So
997.0|4.52| here, we only have, do we have actually dropped? Not not
1001.52|4.6| really, we only have batch norm. So maybe could be added to
1006.56|8.24| could be adding dropout. Okay, so some of the results gets bird
1014.8|2.88| and frog wrong. What was the one that this one gone wrong?
1017.68|5.12| Oh, dear and frog. Interesting. So yeah, animal classes are still
1022.8|3.24| confusing. You can also pro yet you can see, again, the square
1026.04|1.6| where it makes misclassifications between
1027.64|3.8| different animals. Again, the tech cats and dogs. And yeah,
1031.44|5.84| this is Resnet implemented here. Honestly, if you implement
1037.28|2.36| networks, you don't have to implement things from scratch
1039.64|3.32| unless it's for educational purposes, like for learning
1042.96|4.56| things. Usually when you find a paper, or read a paper with an
1047.52|3.68| interesting implementation, or thing you want to try, usually
1051.2|4.44| what people do is they would go on GitHub and search for the
1055.64|3.56| original authors providing the code for that paper, and then
1059.2|4.2| adopting this code. So you would technically not run it one to
1063.4|2.58| one, you have to probably make some modifications so that it
1065.98|3.62| works for your data set. But usually in practice, once we are
1069.6|2.52| working with these more complicated data sets, there's
1072.12|3.28| no doesn't make sense to implement this resident 34,
1075.4|2.76| let's say completely from scratch, it's only another
1078.16|3.32| source of making errors. I mean, it's useful here as a thought
1081.48|4.44| exercise to do it with a simple case with two layers, where you
1085.92|5.24| have simple implementation with two layers, yet maybe makes
1091.16|4.16| sense to do that. But if you go deeper resident 34, maybe use
1095.32|3.96| something that is someone has implemented saves you lots of
1099.28|4.08| time and pain in that way. Alright, so okay, this is
1103.36|5.0| resident, I think we are already at the 75 minutes. So we will
1108.36|2.16| continue next week with
1112.32|3.08| the all convolutional network, I already implemented this
1115.48|3.28| somewhere here. And then we will also talk about transfer
1118.76|2.72| learning, I have to still implement it anyway, not I have
1121.48|4.32| it here already. So we will talk about transfer learning also
1125.8|8.08| next week. Alright.