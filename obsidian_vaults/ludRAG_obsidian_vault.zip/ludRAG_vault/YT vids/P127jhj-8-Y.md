start_time|end_time|text
5.839|5.281|hey everyone welcome to the first an
8.16|4.72|introductory lecture for cs25
11.12|4.719|transformers united
12.88|4.88|so cs25 was a class that the three of us
15.839|4.641|created and taught at stanford in the
17.76|4.24|fall of 2021 and the subject of the
20.48|3.28|class is
22.0|4.64|not as the picture might suggest it's
23.76|5.279|not about robots that can transform into
26.64|5.039|cars it's about deep learning models and
29.039|5.281|specifically the particular kind of deep
31.679|4.801|learning models that have revolutionized
34.32|4.399|multiple fields starting from natural
36.48|3.84|language processing uh to things like
38.719|3.201|computer vision and reinforcement
40.32|2.64|learning to name a few
41.92|3.28|um
42.96|4.48|we have an exciting set of videos lined
45.2|4.0|up for you we have some truly fantastic
47.44|3.68|speakers come and give talks about how
49.2|3.839|they were applying transformers
51.12|3.759|in their own research
53.039|5.121|and we hope you will enjoy and learn
54.879|5.041|from these talks um this video is purely
58.16|4.32|an introductory lecture to talk a little
59.92|4.319|bit about transformers and uh before we
62.48|4.72|get started i'd like to introduce the
64.239|4.641|instructors so my name is advair i am a
67.2|3.919|software engineer at a company called
68.88|5.279|applied intuition before this i was a
71.119|4.161|master's student in cs at stanford
74.159|2.96|and
75.28|5.36|i'm one i am one of the co-instructors
77.119|5.201|for cs25 uh chaitanya div if the two of
80.64|4.479|you could introduce yourselves
82.32|5.36|so hi everyone i am a phd student at
85.119|4.96|sample before this i was uh
87.68|4.16|pursuing a master's here um researching
90.079|4.161|a lot in general modeling enforcement
91.84|3.2|learning and robotics uh so nice to meet
94.24|2.96|you
95.04|3.2|yeah that was div for since he didn't
97.2|2.239|say his name
98.24|2.16|chaitanya if you want to introduce
99.439|3.841|yourself
100.4|4.64|yeah uh hi everyone my name is chaitanya
103.28|4.08|and i'm currently working as an ml
105.04|4.96|engineer at a startup uh called move
107.36|4.96|works before that i was a master student
110.0|4.56|at stanford specializing in nlp and was
112.32|5.68|a member of the prize filling stanford's
114.56|3.44|team for the alexa price challenge
118.079|2.64|right awesome
119.52|3.36|so
120.719|3.601|moving on to the
122.88|2.72|rest of this talk
124.32|3.119|essentially
125.6|2.879|what we hope you will learn watching
127.439|2.88|these videos
128.479|3.281|and what we hope uh
130.319|3.601|the people who took our class in the
131.76|3.36|fall of 2021 learned
133.92|2.8|is three things
135.12|4.4|one is we hope you will have an
136.72|4.879|understanding of how transformers work
139.52|4.719|secondly we hope you will
141.599|4.801|learn and by the end of these talks
144.239|3.921|understand how transformers are being
146.4|2.8|applied beyond just natural language
148.16|3.76|processing
149.2|3.759|and thirdly we hope that some of these
151.92|3.36|talks will
152.959|3.841|spark some new ideas within you
155.28|3.679|and hopefully lead to new directions of
156.8|4.96|research new kinds of innovation and
158.959|2.801|things of that sort
163.92|3.12|and
165.519|2.241|to begin we're going to talk a little
167.04|2.559|bit
167.76|4.24|about transformers and introduce some of
169.599|3.92|the context behind transformers as well
172.0|3.68|and for that i'd like to hand it off to
173.519|2.161|div
180.0|4.64|so hi everyone
181.28|5.039|um so welcome to our transformer seminar
184.64|3.679|uh so i will start first with an
186.319|4.56|overview of the attention timeline uh
188.319|3.761|and how it came to be uh the the key
190.879|3.201|idea about transformers was the
192.08|3.76|self-potential mechanism uh that was
194.08|3.36|developed in 2017 and this all started
195.84|4.16|with this one paper called retention is
197.44|4.4|all you need i was on youtube uh before
200.0|4.48|2017 we used to have this prehistoric
201.84|5.679|era where we had uh older models like
204.48|5.36|rnns lstms and uh simpler attention
207.519|4.08|mechanisms and eventually like the
209.84|3.44|growth in transformers has exploded into
211.599|2.481|other fields and has become prominent in
213.28|3.519|like
214.08|5.6|all of machine learning and uh i'll go
216.799|5.041|and see and show how this has been used
219.68|3.76|so in the prehistoric era there used to
221.84|2.88|be rnns
223.44|4.079|there were different models like the
224.72|4.56|sequencer sequence lstms gius
227.519|4.161|they were good at encoding um some sort
229.28|4.0|of memory but they did not work for
231.68|4.08|encoding long sequences and they were
233.28|4.159|very bad at encoding context so here is
235.76|3.199|an example where you if you have a
237.439|5.041|sentence like i grew up in france dot
238.959|5.041|dot dot so i speak fluent dash then you
242.48|3.52|want to fill this with like a french
244.0|3.519|based on the context but like a lsd
246.0|3.519|model might not know what it is and
247.519|3.92|might just make a very big mistake here
249.519|4.241|similarly we can show some sort of
251.439|4.561|correlation map uh here where if we have
253.76|4.4|a pronoun like it we wanted to correlate
256.0|4.079|to one of the past nouns that we have
258.16|4.8|seen so far like a animal
260.079|5.84|um but again uh older models were like
262.96|5.28|really not good at this context encoding
265.919|4.321|so where we are currently now is on the
268.24|3.44|verge of takeoff we've begun to realize
270.24|3.6|the potential of transformers in
271.68|4.88|different fields we have started to use
273.84|5.04|them to solve long sequence problems in
276.56|4.8|protein folding such as like the alpha
278.88|3.68|pole model from gp from open from
281.36|3.36|deepmind
282.56|5.199|which gets 95 percent accuracy on
284.72|4.32|different challenges in offline rl uh we
287.759|3.281|can use it for few shot and zero
289.04|3.76|structuralization for text and image
291.04|3.28|generation and we can also use this for
292.8|4.32|like content generation so here is
294.32|5.12|example from openai where you can give a
297.12|3.919|different text prompt and
299.44|3.28|have an ai generator fictional image for
301.039|3.761|you
302.72|3.36|and uh so there's a
304.8|2.8|talk on this that you can also watch in
306.08|3.119|youtube which basically says that ls
307.6|3.84|students are dead and long-lived
309.199|4.0|transformers
311.44|2.56|so what's the future
313.199|2.72|so
314.0|4.24|we can enable a lot more applications
315.919|4.801|for transformers um they can be applied
318.24|4.32|to any form of sequence modeling so you
320.72|3.12|can use we could use them for video
322.56|3.84|understanding we can use them for
323.84|4.079|finance and a lot more so basically
326.4|2.48|imagine all sorts of genetic modeling
327.919|2.56|problems
328.88|4.08|nevertheless there are a lot of missing
330.479|4.801|ingredients so like the human brain we
332.96|5.679|need some sort of external memory
335.28|5.28|unit which is the hippocampus for us and
338.639|3.521|they are saying some early works here so
340.56|2.639|one nice work you might want to check
342.16|2.0|out is called this neural tuning
343.199|2.801|machines
344.16|3.92|similarly uh the current attention
346.0|4.72|mechanisms are very computationally
348.08|4.24|complex in terms of time and they scale
350.72|3.919|correctly which we will discuss later
352.32|3.76|and we want to make them more linear and
354.639|3.041|the third problem is that we want to
356.08|3.52|align our current sort of language
357.68|4.239|models with the how the human brain
359.6|3.439|works and human values and this also big
361.919|4.72|issue
363.039|4.801|okay so now i will deep dive deep dive i
366.639|3.521|will
367.84|5.44|dive deeper into the tension mechanisms
370.16|4.24|and uh show how they came out to be
373.28|2.639|so
374.4|4.0|initially there used to be very simple
375.919|4.481|mechanisms um where attention was
378.4|3.68|inspired by the process of importance
380.4|3.2|reading or putting attention on
382.08|3.679|different parts of uh
383.6|3.599|image where like similar to a human
385.759|3.201|where you might focus more on like a
387.199|2.801|foreground uh if you have an image of a
388.96|2.0|dog compared to like the rest of the
390.0|2.639|background
390.96|3.6|so in the case of soft retention what
392.639|4.241|you do is you learn this simple soft
394.56|4.4|attention weighting for each pixel which
396.88|3.92|can be a weight between zero to one uh
398.96|3.76|the problem over here is that this is a
400.8|4.16|very expensive computation and then you
402.72|4.319|can as show as as it's shown in the
404.96|3.359|figure on the left uh you can see we are
407.039|3.121|calculating this attention for the whole
408.319|4.241|image um
410.16|3.28|what you can do instead is you can just
412.56|2.72|uh
413.44|3.68|calculate a zero to one attention map
415.28|4.24|where we directly put a one on wherever
417.12|5.04|the dog is and a zero wherever uh it's a
419.52|4.239|background uh this is like uh less
422.16|3.28|computation expensive but the problem is
423.759|3.28|it's non-differentiable and makes things
425.44|3.92|harder to drain
427.039|3.841|uh going forwards we also have different
429.36|3.2|varieties of basic attention mechanisms
430.88|2.879|that came that were proposed before
432.56|2.56|self-retention
433.759|3.681|uh so the first
435.12|4.079|variety here is global tension models so
437.44|3.039|in global attention models for each
439.199|4.241|hidden
440.479|5.761|layer input a hidden layer output you
443.44|4.8|learn an attention weight uh a of b
446.24|3.2|and this is element twice multiplied
448.24|3.84|with your current output to calculate
449.44|4.96|your final output uh yt
452.08|4.64|um similarly you have local attention
454.4|4.32|models where instead of calculating the
456.72|4.8|global attention for over the whole
458.72|4.72|sequence length you only calculate the
461.52|4.56|attention over a small window
463.44|4.479|and uh and then you wait by the tension
466.08|5.839|of the window in into like the current
467.919|6.481|output uh to get like the final output
471.919|3.84|uh so moving on uh i will pass on to
474.4|4.0|chattanooga to discuss self-retention
475.759|4.88|mechanisms and transforms
478.4|4.72|yeah uh thank you this for covering a
480.639|4.56|brief overview of how the
483.12|3.84|primitive versions of attention work
485.199|4.321|now just before we talk about
486.96|5.359|self-attention uh just a bit of a trivia
489.52|5.04|that this term was first introduced by a
492.319|4.241|paper which from line it all which was
494.56|3.84|uh which provided a framework for a
496.56|4.479|self-attentive uh
498.4|4.88|uh frame a self-attentive mechanism for
501.039|4.72|sentence and weddings and now moving on
503.28|4.88|to the main crux of the transformers
505.759|4.801|paper which was the self-retention block
508.16|5.359|so self-retention is the basis is the
510.56|4.719|main uh comp building block for the how
513.519|5.041|for what makes the transformers model
515.279|6.161|work so well and to enable them and make
518.56|5.52|them so powerful so to think of it more
521.44|4.64|easily uh we can uh break down the
524.08|4.24|self-retention as a search retrieval
526.08|5.36|problem so the problem is that given a
528.32|5.44|query queue and uh we the we need to
531.44|3.76|find a set of keys k which are most
533.76|4.32|similar to q and return the
535.2|4.72|corresponding key values called v
538.08|3.68|now these three vectors can be drawn
539.92|4.56|from the same source for example we can
541.76|5.28|have that q k and v are all equal to a
544.48|5.6|single vector x where x can be output of
547.04|4.96|a previous layer in transformers
550.08|4.319|these vectors are obtained by applying
552.0|3.76|different linear transformations to x so
554.399|3.44|as to enable
555.76|3.84|the model to capture more
557.839|3.68|complex interactions between the
559.6|3.04|different tokens at different places of
561.519|3.521|the sentence
562.64|4.4|now how attention is computed is just a
565.04|3.28|weighted summation of the similarities
567.04|3.359|between the
568.32|4.72|query and key vectors which is weighted
570.399|5.361|by the respective value for those keys
573.04|4.64|and in the transformers paper they used
575.76|4.24|the scale dot product as a similarity
577.68|4.08|function for the queries and keys
580.0|4.399|and another important aspect of the
581.76|4.8|transformers was the introduction of
584.399|4.161|multi-head self-retention so what
586.56|5.12|multi-head self-retention means is that
588.56|4.8|the retention is for at every layer the
591.68|4.159|self attention is performed multiple
593.36|5.12|times which enables the model to learn
595.839|4.881|multiple representation subspaces
598.48|4.72|so in a way you can think of it that
600.72|5.04|each head is
603.2|4.4|has a uh has a power to look at
605.76|4.72|different things and to learn different
607.6|5.359|semantics for example one head can be
610.48|4.799|learning to try to predict uh what is
612.959|4.481|the part of speech for those tokens one
615.279|4.721|head might be learning what is the
617.44|4.88|syntactic structure of the sentence and
620.0|5.44|uh and all those things that are there
622.32|6.32|uh to understand what this uh what the
625.44|4.72|upcoming uh sentence means
628.64|3.28|now to better understand what the
630.16|3.359|self-attention works and what are the
631.92|3.2|different computations there is a short
633.519|3.44|video
635.12|3.839|so
636.959|4.161|in this so as you can see
638.959|4.32|there are three incoming tokens
641.12|4.399|so input one input to input three we
643.279|5.761|apply linear transformations to get the
645.519|6.0|key value of vectors for each input
649.04|4.32|and then give once a query queue comes
651.519|3.841|we calculated similarity with the key
653.36|3.52|with respect to key vectors and then
655.36|3.12|multiply those
656.88|4.32|scores with the
658.48|4.08|value vector and then add them all up to
661.2|3.44|get the output
662.56|3.92|the same computation is then performed
664.64|4.4|on all the tokens
666.48|5.2|and we get the output of the self
669.04|4.16|retention layer so as you can see here
671.68|3.279|the final output of the send self
673.2|4.319|retention layer is in dark green that's
674.959|4.641|at the top of the screen
677.519|3.841|so now again for the final token we
679.6|4.239|perform everything same queries
681.36|4.56|multiplied by keys we get the similarity
683.839|4.401|scores and then those similarity scores
685.92|4.4|obey the value vectors and then we
688.24|3.92|finally perform the addition to get the
690.32|4.4|self attention output of the
692.16|2.56|transformers
699.12|4.64|apart from self retention there are
701.519|4.88|some other necessary ingredients that
703.76|5.28|makes uh the transformers so powerful
706.399|4.161|one important aspect is the uh presence
709.04|3.919|of positional representations or the
710.56|4.64|embedding layer so
712.959|4.32|the way rnns worked
715.2|4.319|very well was that since they process
717.279|4.961|each the information in a sequential
719.519|4.961|ordering so there was this notion of uh
722.24|3.839|ordering right and which is also very
724.48|3.599|important in understanding language
726.079|2.88|because we all know that we
728.079|2.721|read
728.959|4.721|any piece of text from
730.8|4.719|left to right in most uh
733.68|4.24|in most of the languages and also right
735.519|4.241|to left in some languages so there is a
737.92|4.4|notion of ordering which is lost in kind
739.76|4.48|of self-attention because every word is
742.32|5.04|attending to every other world that's
744.24|4.56|why this paper introduced a separate uh
747.36|3.52|embedding layer for introducing
748.8|3.92|positional representations
750.88|4.88|the second important aspect is having
752.72|4.64|non-linearities so if you think of uh
755.76|3.36|all the computation that is happening in
757.36|3.68|the cell potential there it's all linear
759.12|4.0|because it's all matrix multiplication
761.04|4.479|but as we all know that deep learning
763.12|4.959|models uh work well when they are able
765.519|4.56|to uh when they are able to learn more
768.079|4.241|complex mappings between input and
770.079|4.081|output which can be uh attained by a
772.32|3.44|simple mlp
774.16|2.4|and the third important component of the
775.76|3.44|self
776.56|4.8|of the transformers is the masking so
779.2|3.439|masking is what allows to parallelize
781.36|3.36|the operations
782.639|4.481|uh since every word can attend to every
784.72|4.4|other word in the decoder part of the
787.12|4.719|transformers which otherwise gonna be
789.12|4.959|talking about later is the problem comes
791.839|4.961|that you don't want the decoder to look
794.079|5.521|into the future because that can result
796.8|5.839|in data leakage so that's why masking
799.6|6.4|helps the decoder to avoid that future
802.639|5.601|information and learn only what has been
806.0|3.44|how what uh what the model has processed
808.24|4.56|so far
809.44|6.639|so now on to the uh the encoder decoder
812.8|3.279|architecture of the transformers
816.399|3.201|yeah thanks tethanya for talking about
818.079|2.721|self-attention
819.6|3.12|so
820.8|4.08|self-retention is sort of the key
822.72|4.72|ingredient or one of the key ingredients
824.88|4.639|that allows transformers to work so well
827.44|4.16|but at a very high level the
829.519|5.68|model that was proposed in the vaswani
831.6|5.76|at all paper of 2017 was like previous
835.199|4.401|language models in the sense that it had
837.36|4.32|an encoder decoder architecture what
839.6|3.52|that means is let's say you're working
841.68|3.599|on a translation problem you want to
843.12|3.6|translate english to french the way that
845.279|3.281|would work is you would read in the
846.72|3.84|entire input
848.56|3.76|of your english sentence you would
850.56|4.48|encode that input so that's the encoder
852.32|4.24|part of the network and then you would
855.04|3.599|generate token by token the
856.56|3.839|corresponding friends translation and
858.639|4.481|the decoder is the part of the network
860.399|3.921|that is responsible for generating those
863.12|1.92|tokens
864.32|2.959|so
865.04|4.32|you can think of these encoder blocks
867.279|3.841|and decoder blocks as
869.36|4.479|essentially something like lego they
871.12|3.44|have these sub components that make them
873.839|2.961|up
874.56|4.48|and in particular the encoder block has
876.8|4.96|three main sub components the first is a
879.04|5.76|self retention layer um that chaitanya
881.76|5.84|talked about earlier and as talked about
884.8|4.32|earlier as well you need a feed forward
887.6|3.2|layer after that because the
889.12|3.519|self-retention layer only performs
890.8|2.8|linear operations and so you need
892.639|2.481|something that can capture the
893.6|4.479|non-linearities
895.12|4.48|um you also have a layer norm after this
898.079|3.44|and lastly there are residual
899.6|3.039|connections between different encoder
901.519|2.88|blocks
902.639|3.76|the decoder is very similar to the
904.399|4.24|encoder but there's one difference which
906.399|4.24|is that it has this extra layer because
908.639|4.401|the decoder doesn't just do multi-head
910.639|4.961|attention on the output of the previous
913.04|4.32|layers so so for context the encoder
915.6|2.96|does multi-head attention
917.36|2.96|so each
918.56|2.719|self-retention layer in the encoder
920.32|3.44|block
921.279|4.8|in each of the encoder blocks does
923.76|3.519|multi-head attention looking at the
926.079|4.0|previous
927.279|4.641|layers of the encoder blocks the decoder
930.079|3.68|however does
931.92|4.159|that in the sense that it also looks at
933.759|3.76|the previous layers of the decoder but
936.079|3.68|it also looks at the output of the
937.519|6.24|encoder and so it needs us a multi-head
939.759|7.361|attention layer over the encoder blocks
943.759|5.841|and lastly there's masking as well um so
947.12|4.639|if you are because every token can look
949.6|4.08|at every other token um you want to sort
951.759|3.601|of make sure in the decoder that you're
953.68|3.599|not looking into the future so if you're
955.36|3.36|in position three for instance you
957.279|4.56|shouldn't be able to look at position
958.72|3.119|four and position five
963.04|5.359|so those are sort of all the components
965.04|5.599|that led to the creation of the model in
968.399|3.521|um the vasani idol paper
970.639|2.961|and
971.92|4.24|um let's talk a little bit about the
973.6|5.12|advantages and drawbacks of this model
976.16|4.4|um so the two main advantages which are
978.72|4.16|huge advantages and which are why
980.56|3.12|transformers have done such a good job
982.88|2.399|of
983.68|4.24|revolutionizing
985.279|5.441|many many fields within deep learning
987.92|4.88|um are as follows so so the first is
990.72|4.479|there is this constant path length
992.8|3.92|between any two positions in a sequence
995.199|3.121|because every
996.72|2.96|token in the sequence is looking at
998.32|3.36|every other token
999.68|3.68|and this basically solves the problem
1001.68|3.44|that they've talked about earlier with
1003.36|4.0|long sequences you don't have this
1005.12|4.0|problem with long sequences where if
1007.36|3.52|you're trying to predict a token that
1009.12|4.959|depends on a word
1010.88|4.319|that was far far behind in a sentence
1014.079|2.641|you don't have the problem of losing
1015.199|2.801|that context now the distance between
1016.72|3.84|them is only
1018.0|4.16|one in terms of the path length
1020.56|3.759|also because the nature of the
1022.16|3.759|computation that's happening transformer
1024.319|3.52|models lend themselves really well to
1025.919|4.081|parallelization and because of the
1027.839|4.24|advances that we've had with gpus
1030.0|4.24|basically if you take a transfer model
1032.079|3.521|with n parameters and you take a model
1034.24|3.839|that isn't a transformer say like i can
1035.6|3.839|have stm with also with n parameters
1038.079|3.76|training the transformer model is going
1039.439|4.801|to be much faster because of the
1041.839|4.161|parallelization that it leverages
1044.24|4.4|so those are the advantages
1046.0|5.039|the disadvantages are basically
1048.64|4.08|self-attention takes quadratic time
1051.039|4.0|because every token looks at every other
1052.72|4.56|token order n square as you might know
1055.039|4.88|does not scale and there's actually been
1057.28|4.639|a lot of work in trying to tackle this
1059.919|3.521|so we've linked to some here big bird
1061.919|3.841|lin former and reformer are all
1063.44|6.0|approaches to try and make this linear
1065.76|3.68|or quasi-linear essentially
1071.039|2.88|and
1071.919|3.441|yeah we highly recommend to
1073.919|3.521|recommend going through jay alamer's
1075.36|4.4|blog the illustrated transformer which
1077.44|3.68|provides great visualizations and
1079.76|4.4|explains everything that we just talked
1081.12|3.04|about in great detail
1084.64|3.44|yeah and i'd like to pass it on to
1086.0|4.24|chaitanya for applications of
1088.08|4.32|transformers
1090.24|4.319|yeah so now moving on to like some of
1092.4|4.159|the recent work uh some of the work that
1094.559|3.521|uh very shortly followed the
1096.559|4.641|transformers paper
1098.08|6.08|so one of the models that came out uh
1101.2|5.52|was gpt the gbt architecture which was
1104.16|4.56|released by open eyes so uh so open ei
1106.72|4.88|had the latest model that opened here
1108.72|5.36|has in the gpt series is the gpd3 so it
1111.6|4.24|consists of only the decoder blocks from
1114.08|3.839|transformers and is trained on our
1115.84|4.64|traditional language modeling task which
1117.919|4.481|is uh predicting the current token which
1120.48|5.28|is separating the next token given the
1122.4|4.24|last uh t tokens that that the model has
1125.76|3.2|seen
1126.64|4.32|and for any downstream tasks now the
1128.96|3.92|model can just you can just train a
1130.96|3.04|classification layer on the last hidden
1132.88|2.32|state
1134.0|4.72|which can be
1135.2|6.479|which can have any number of labels and
1138.72|5.28|since the model is generative in nature
1141.679|4.801|you can also use the pre-trained network
1144.0|5.039|as uh for generative kind of tasks such
1146.48|4.559|as summarization and natural language
1149.039|4.241|and natural language generation
1151.039|5.201|for things for that instance
1153.28|5.759|another important aspect that gpt 3
1156.24|4.72|gained popularity was its ability to
1159.039|3.441|to be able to perform in context
1160.96|3.68|learning what the authors called into
1162.48|5.12|context learning so this is the ability
1164.64|5.36|wherein the model can perform can learn
1167.6|4.24|under few short settings uh what what
1170.0|3.76|the task is to complete the task without
1171.84|4.88|performing any gradient updates for
1173.76|5.36|example let's say the model is shown
1176.72|6.319|a bunch of addition examples and then if
1179.12|6.96|you pass in a new uh input and leave the
1183.039|5.281|uh and just leave it at uh at equal to
1186.08|5.04|sign the model tries to predict the act
1188.32|5.44|next token uh which very well comes out
1191.12|4.88|to be the sum of the uh the sum of the
1193.76|4.72|numbers that's that is shown another
1196.0|5.12|example can be also the spell correction
1198.48|5.92|task or the translation task so this is
1201.12|6.32|this was the ability that uh made gpt 3
1204.4|6.399|so much uh uh talked about in the nlp
1207.44|5.76|world and uh right now also like many
1210.799|4.161|applications have been made using gp3
1213.2|4.4|which includes uh the
1214.96|4.959|one of them being the vs code co-pilot
1217.6|4.24|which uh tries to
1219.919|4.321|which tries to generate a piece of code
1221.84|4.319|given our doctrine kind of natural
1224.24|5.04|language text
1226.159|4.64|another major uh model that came out
1229.28|4.56|that was based on the transformers
1230.799|4.88|architecture was bird so but uh lends
1233.84|3.68|its name from it's an acronym for
1235.679|3.841|bi-directional encoding encoder
1237.52|4.48|representations of transformers
1239.52|4.0|it consists of uh only the encoder
1242.0|4.32|blocks of the transformers which is
1243.52|3.84|unlike gpd3 which had only the decoder
1246.32|3.52|blocks
1247.36|5.04|now this prop because of this change
1249.84|4.959|there there comes a problem because
1252.4|4.159|uh because bert has only the encoder
1254.799|4.0|block so it sees the entire piece of
1256.559|4.321|text it cannot be pre-trained on a live
1258.799|4.721|language modeling task because of the
1260.88|4.72|problem of data leakage from the future
1263.52|5.12|so what the authors came up with was a
1265.6|4.88|clever idea and they uh and they came up
1268.64|4.48|with a novel task called mass language
1270.48|4.64|modeling which was uh which included to
1273.12|3.76|replace certain birds with a placeholder
1275.12|4.88|and then the model tries to predict
1276.88|5.919|those words given the entire context
1280.0|5.039|now apart from this token level task
1282.799|3.681|there was the authors also added a
1285.039|3.12|second objective called the next
1286.48|3.92|sentence prediction which was a sentence
1288.159|4.88|level task
1290.4|4.32|wherein given two chunks of text
1293.039|3.921|the model tried to predict whether the
1294.72|3.68|second sentence followed the other
1296.96|2.8|sentence or not follow the first
1298.4|3.36|sentence or not
1299.76|4.32|and now for after pre-training this
1301.76|3.68|model for any downstream task the model
1304.08|2.88|can be further fine-tuned with an
1305.44|4.16|additional classification layer just
1306.96|5.28|like it was in chip e3
1309.6|5.04|so ah these are the two models that were
1312.24|5.04|that have been like very popular and
1314.64|5.039|have made a lot of applications made
1317.28|4.24|their way in lot of applications but the
1319.679|3.36|landscape has changed quite a lot since
1321.52|3.36|we have taken this class there are
1323.039|4.161|models with different pre-training
1324.88|4.56|techniques like elektra d berta and
1327.2|5.359|there are also models that do
1329.44|4.8|well in like other modalities and which
1332.559|3.36|we're going to be talking about in other
1334.24|4.72|lecture series as well
1335.919|5.601|so yeah that's all from this lecture and
1338.96|4.64|thank you for tuning in
1341.52|4.08|yeah um just want to just want to end by
1343.6|4.72|saying thank you all for watching this
1345.6|5.52|and we have a really exciting set of
1348.32|4.479|videos with truly amazing speakers and
1351.12|3.52|we hope you are able to derive value
1352.799|3.441|from that
1354.64|4.6|thanks a lot thank you thank you
1356.24|3.0|everyone
1362.96|2.079|you