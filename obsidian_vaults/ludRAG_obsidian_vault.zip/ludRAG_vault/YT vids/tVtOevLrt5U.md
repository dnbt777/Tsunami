start_time|end_time|text
6.14|4.66|okay great so the first sort of um paper
9.599|2.58|that I'm going to talk about is called
10.8|2.759|emerging abilities of large language
12.179|3.721|models
13.559|4.501|um and this paper was especially cool uh
15.9|4.2|I think because we got people from
18.06|4.02|Google and deepmind and and also at
20.1|5.4|Stanford you might recognize Percy or
22.08|4.68|Tatsu or arishi I mean we got people to
25.5|3.66|sort of agree on what's the nice
26.76|3.54|framework of looking at why we want to
29.16|3.419|scale
30.3|3.18|um and emerging abilities
32.579|2.341|um
33.48|3.419|so
34.92|4.62|uh one of the things that we've seen
36.899|4.621|throughout language models is that you
39.54|3.78|sort of get these predictable gains as a
41.52|4.74|result of scaling so here's the
43.32|6.12|canonical you know Kaplan at all paper
46.26|4.86|where you can see that if you scale up
49.44|4.26|the size of the language model measure
51.12|4.5|it either in compute in data set size or
53.7|5.94|in parameters
55.62|6.72|you see that the loss on on the test set
59.64|3.719|actually goes down predictably yeah I
62.34|2.52|don't know if you're screen sharing so
63.359|6.3|people on Zoom I don't think can see the
64.86|6.96|slides okay yeah yeah sorry okay
69.659|3.541|okay
71.82|4.32|um I guess I'll say this for the third
73.2|4.14|time uh as as we've seen in language
76.14|2.82|models
77.34|4.919|if you scale up the size of the language
78.96|4.86|model uh measured either in compute uh
82.259|3.481|in data set size or a number of
83.82|4.38|parameters you can see that there's a
85.74|5.36|sort of this predictable uh Improvement
88.2|2.9|in the test loss
91.619|2.221|um
92.34|3.599|now what I'm going to be talking about
93.84|4.08|in terms of emergence is something
95.939|3.901|that's actually unpredictable
97.92|4.86|if you only look at smaller language
99.84|5.04|models so one way that emergence has
102.78|4.74|been described in the broader science
104.88|4.98|literature is it's basically seen as a
107.52|4.44|qualitative change that arises from
109.86|4.86|quantitative changes I mean it sort of
111.96|4.86|started with this article in science by
114.72|4.219|a Nobel prize winning physicist called
116.82|5.88|more is different
118.939|5.381|and I really like this post from Jacob
122.7|3.72|steinart that sort of describes
124.32|3.84|emergence and and he gives a couple of
126.42|4.679|good examples here
128.16|4.64|for example he says with uranium with a
131.099|3.901|bit of uranium nothing special happens
132.8|4.06|with a large amount of urine impact
135.0|2.72|densely enough you get a nuclear
136.86|3.9|reaction
137.72|5.379|and then also with DNA for example given
140.76|3.72|only small molecules such as calcium you
143.099|3.421|can't meaningfully encode useful
144.48|5.66|information but given larger models such
146.52|3.62|as DNA you can encode a genome
151.14|6.0|um so for this particular work uh we use
154.56|4.86|this definition of emerge abilities of
157.14|5.7|large language models in particular so
159.42|5.76|we say that ability is emergent if it is
162.84|4.979|not present in smaller models but it is
165.18|4.62|present in larger models
167.819|4.621|um and the sort of natural question here
169.8|4.68|is like how do you measure the size or
172.44|4.379|the scale of the language model and
174.48|3.96|they're sort of traditionally three axes
176.819|3.841|of scale so the training flops are the
178.44|3.48|amount of compute that you use to train
180.66|3.359|the language model
181.92|4.26|the number of model parameters or like
184.019|3.601|the the size the language model and also
186.18|3.66|the size of the training data set that
187.62|4.32|the model is trained on
189.84|4.319|um and a lot of the plots here will use
191.94|4.74|either training flops or the number of
194.159|5.041|model parameters the reason is that the
196.68|4.62|trained asset size is usually fixed for
199.2|4.08|for different size models and because
201.3|4.92|training flops is just the data set size
203.28|4.86|times model parameters you'll it you can
206.22|4.14|get a similar plot from either training
208.14|5.48|flops or number of model parameters for
210.36|3.26|most language models
214.68|4.86|um great and so the first type of
217.319|4.461|emergence yes sir go ahead
219.54|2.24|foreign
237.06|4.62|so yeah for example uh I'll just give a
239.94|3.48|I'll just give an example here which is
241.68|4.139|actually the next slide
243.42|3.72|um so basically we have this way of
245.819|3.121|interacting with language models called
247.14|3.179|few shot prompting
248.94|3.42|um and the way it works is like you know
250.319|3.801|the language model is a really good next
252.36|5.04|word predictor
254.12|6.88|and when you give the model an example
257.4|5.94|and then you ask it for an unseen uh an
261.0|4.86|unseen um like movie review for example
263.34|3.9|and then you say what's the output and
265.86|3.54|then here the language model can say
267.24|4.679|positive because it understands to use
269.4|4.62|the context from the review uh to give
271.919|4.621|the next token
274.02|5.28|um and the definition of we let that we
276.54|4.98|use for like having ability or not is
279.3|4.56|that basically a few shot prompted like
281.52|5.22|tasks for example a sentiment analysis
283.86|5.04|is emergent if it has random accuracy
286.74|4.44|for small models but above random
288.9|4.32|accuracy for large models does that make
291.18|4.079|sense so basically if if the model isn't
293.22|3.6|doing any better than random then we say
295.259|3.481|it doesn't have the ability to do this
296.82|3.06|particular task
298.74|2.7|yeah
299.88|4.8|cool
301.44|4.14|I mean I'll give a few examples here
304.68|3.42|um
305.58|4.38|so here's sort of the canonical way that
308.1|3.379|we look at plots for emergence so
309.96|4.2|basically
311.479|4.841|what we have each of these different
314.16|3.66|plots is a different task and I'll go
316.32|3.9|over some examples soon
317.82|5.159|but the way you read the plot is the
320.22|5.699|x-axis is a number of training flops or
322.979|4.681|the model scale and then the y-axis is
325.919|4.441|like the accuracy or like how good the
327.66|4.92|model is doing the task
330.36|4.38|um and then you know we have different
332.58|4.92|language models from open AI from Google
334.74|4.26|and from deepmind and then each of the
337.5|4.02|points is like a different language
339.0|4.08|model it's not a language model over the
341.52|3.06|course of training like each point is a
343.08|4.2|different language model
344.58|4.8|and what you see is that for the very
347.28|4.259|small language models
349.38|3.78|um you basically get a performance
351.539|4.281|that's that's close to random or not
353.16|2.66|being any better
356.1|3.3|um and then once you pass a certain
357.539|3.841|threshold
359.4|4.139|um you can see that the the performance
361.38|4.92|suddenly gets like a lot above uh
363.539|5.16|substantially above random and this is
366.3|4.38|what we call emergence so basically if
368.699|4.621|you were to extrapolate like the lines
370.68|4.5|uh from the small language models you
373.32|3.18|might predict that it would never you
375.18|3.42|know do better than random because it's
376.5|3.78|just a flat line but the interesting
378.6|4.02|phenomena is that when you scale up past
380.28|3.84|a certain threshold you actually do see
382.62|3.48|this emerging phenomena where the model
384.12|4.079|does a lot better than random
386.1|4.2|foreign
388.199|3.541|so let me go over some like concrete
390.3|4.679|examples
391.74|7.82|so here's uh one task it's basically a
394.979|8.22|benchmark called multitask nlu or mmlu
399.56|6.16|and basically uh what it is it's a bunch
403.199|3.661|of uh test questions uh ranging from
405.72|3.62|high school all the way to like
406.86|4.92|professional level exams
409.34|5.68|and how it works is the language model
411.78|6.0|sort of given uh for example here is a
415.02|4.38|high school math example and the
417.78|3.9|language model is given like a few
419.4|4.38|examples and then for an unseen question
421.68|4.019|it has to give the answer
423.78|5.039|and then you can see in the plot on the
425.699|5.581|right so for the model scale if you go
428.819|4.32|up to sort of 10 to the power of 22
431.28|3.72|training flops you don't actually get
433.139|4.321|any better than random accuracy on this
435.0|5.28|task but if you scale up to 10 to the 24
437.46|5.28|training flops then you see that all the
440.28|6.02|like three models there do much better
442.74|3.56|than uh than random accuracy
447.419|3.021|um yeah the
450.539|3.66|is it roughly similar or because these
452.819|3.421|are like different models straight by
454.199|4.62|different orgs
456.24|4.26|um yeah the scale is uh I think within
458.819|4.621|an order of magnitude for for these
460.5|5.58|models here yeah yeah and like every
463.44|5.699|single doc on each individual tracks is
466.08|4.86|the same data uh yes the data the data
469.139|3.601|is fixed um except for chinchilla
470.94|3.12|chinchilla uses more data for larger
472.74|2.7|models but
474.06|3.539|um I believe yeah for all the other
475.44|4.28|models here the amount of data is the
477.599|2.121|same
480.96|3.66|um yeah here's just another example to
482.88|4.74|sort of um
484.62|5.82|show it more concretely so this is a
487.62|4.32|task from the big bench Benchmark
490.44|5.22|um just as an aside the big bench
491.94|5.759|Benchmark is like 200 benchmarks uh and
495.66|3.599|basically it's like a crowdsource set of
497.699|3.78|benchmarks I'd recommend looking at if
499.259|4.681|you're doing that component work and
501.479|5.581|basically the task is the language model
503.94|5.599|has to take an English sentence and then
507.06|4.8|give the International Phonetic Alphabet
509.539|4.18|transliteration the IPA transliteration
511.86|3.479|which is basically like how to pronounce
513.719|4.56|it
515.339|4.56|um and for this for this uh task the
518.279|4.921|evaluation metric is actually blue or
519.899|5.121|like an engram overlap metric
523.2|5.4|um and and you get a similar uh
525.02|6.46|phenomena where as you uh increase the
528.6|5.1|size of language model it's flat for a
531.48|5.06|while and then suddenly the Improvement
533.7|2.84|is above random
537.12|4.92|um great
539.16|4.739|so I'll talk about another uh
542.04|3.66|interesting result I hear that that's
543.899|3.781|why it's emerging so this was a
545.7|3.48|technical report that we put out um a
547.68|3.0|couple of months ago
549.18|3.24|um and basically there's this really
550.68|5.219|interesting prize
552.42|6.66|um in or it's like a a one-time prize in
555.899|5.161|um uh in language models where uh
559.08|4.259|anthropics which is like a startup
561.06|4.5|basically had this prize where If people
563.339|4.62|could come up with a task where the
565.56|3.68|performance on the task would actually
567.959|3.901|decrease
569.24|5.56|as you increase the size of the language
571.86|3.659|model then you would get like a bunch of
574.8|2.039|money
575.519|2.88|so basically there are a lot of
576.839|3.841|submissions to this and here's one
578.399|3.841|example of like a task where they found
580.68|3.3|that the performance would actually
582.24|4.5|decrease if you increase the size of the
583.98|4.5|language model so the task is out of
586.74|3.9|created here it's like repeat my
588.48|4.14|sentences back to me and then uh the
590.64|5.4|input is like all that glisters is not
592.62|5.82|glib and then the output is uh the model
596.04|4.5|has to completely has to accurately say
598.44|2.82|a glib
600.54|4.08|um
601.26|6.12|and so what happened is for the small
604.62|5.159|language model it doesn't know the
607.38|3.72|phrase all that glisters is not gold so
609.779|4.921|it just like copies the input and
611.1|5.58|actually does get it's like 100 on that
614.7|4.259|um but then for the medium-sized
616.68|3.839|language model uh what you would see is
618.959|3.541|that the performance actually decrease
620.519|4.021|because the medium-sized language model
622.5|3.66|knows the phrase all that glisters is
624.54|3.9|not gold and then it says gold which
626.16|5.28|actually is not what the task asks it to
628.44|5.94|do yeah okay can you give a physical
631.44|4.56|estimate of 10 to the 24 plots possibly
634.38|4.1|in terms of training time or number of
636.0|2.48|gpus
638.58|3.199|um yeah so I think
640.86|5.46|um
641.779|9.221|uh 10 to the 24 flops uh is around so at
646.32|9.66|Google we use tpus and one pod of tpus I
651.0|7.079|believe is equal to like 4 000 a100s
655.98|4.919|um and 10 to the 24 flops is like two
658.079|4.32|pods uh for around six weeks or
660.899|3.0|something like that
662.399|4.041|um so it's a lot of compute to do the
663.899|2.541|pre-training
666.6|2.64|um
667.5|3.24|I don't know do you guys remember in
669.24|3.06|like chemistry class when you'd have
670.74|3.9|like moles
672.3|3.659|and it would be like 10 to the 23 and
674.64|2.699|then you're like teacher would be like
675.959|3.961|oh don't even think about like how big
677.339|5.101|this number is that's like the number of
679.92|4.08|like floating Point operations that uh
682.44|3.98|goes into the pre-training of some of
684.0|2.42|these models
686.519|5.461|um okay great anyways uh so
689.94|3.6|um yeah so so basically the medium-sized
691.98|3.599|language model will actually do worse oh
693.54|5.64|yeah did you have another question
695.579|6.481|yeah oh wait is did this one win the
699.18|4.98|prize or not I'm like um this one is uh
702.06|6.14|one of the the winner I think it's like
704.16|4.04|the third place winner or something yeah
709.82|4.24|because like I would say my initial
712.56|3.54|opinion would be like oh you can just
714.06|4.08|like put the negatives like on how you
716.1|3.9|evaluate
718.14|4.08|uh what do you mean flip a negative side
720.0|5.1|well because like all of this depends on
722.22|5.46|like which evaluations you
725.1|4.679|use yeah to measure a few years
727.68|3.839|so like it's like the
729.779|4.261|the measurement is very sparse like you
731.519|4.5|only get credit if you do it perfectly
734.04|4.62|yeah yeah like show a lot of things
736.019|5.101|emerge because like you just won't hit
738.66|5.1|it perfectly until like it's like really
741.12|5.82|optimized for a long time or like if you
743.76|4.86|take a test and then like uh evaluate it
746.94|4.1|it's like it's minus signs like looking
748.62|2.42|at like
753.32|4.12|yeah I mean they they so for this thing
756.0|3.0|they like accounted for all like you
757.44|3.78|can't just say like the task should be
759.0|4.26|do badly on something it has to be like
761.22|3.359|a meaningful sort of task
763.26|3.72|um and then I guess your your point
764.579|4.56|about like the how credits assignment or
766.98|3.599|the valuation metric works is actually a
769.139|3.481|really good one
770.579|5.401|um yeah so I guess it still kind of
772.62|6.12|counts if like you know uh I I guess the
775.98|3.359|argument is sort of the the
778.74|2.46|um
779.339|4.081|the performance might not look emergent
781.2|4.439|if you assign partial credit
783.42|3.84|um but we have like a bunch of uh I can
785.639|3.0|show example later but
787.26|3.06|um even if you use partial credit
788.639|3.241|metrics you'll often still see the same
790.32|3.36|type of emergence
791.88|3.36|um so it's not purely a phenomenon if
793.68|4.399|like uh not assigning partial credit
795.24|2.839|based on evaluation
798.66|3.08|um
799.32|2.42|well
802.139|5.341|um and then uh great so what what we
805.62|3.719|sort of sort of argued in this paper is
807.48|3.18|that yeah there might be some tasks
809.339|4.261|where the performance starts to decrease
810.66|6.299|if you use a medium-sized language model
813.6|4.979|um but if you keep scaling uh all the
816.959|4.68|way to you know the largest model that
818.579|6.841|we have at Google that's known publicly
821.639|5.101|uh Palm uh you'll see that uh the
825.42|3.599|language model I can actually go back
826.74|5.219|and do the task correctly because uh the
829.019|5.341|large language model uh also knows the
831.959|4.801|phrase all that glisters is not gold uh
834.36|4.14|but I also understands repeat my
836.76|4.019|sentences back to me
838.5|4.32|um so it's able to get 100 uh on this
840.779|5.24|task so this is a different type of uh
842.82|3.199|emergence also
847.8|5.039|um uh and a another class of emergence
851.1|3.179|that we sort of talk about
852.839|5.161|um in the paper is like an emergent
854.279|5.101|prompting technique so basically uh you
858.0|2.639|know other than future thought prompting
859.38|3.72|there's like other ways of like
860.639|3.961|interacting with the language models
863.1|5.539|um that uh
864.6|4.039|can be considered emergent yeah
870.839|4.921|um the question is did all models
872.579|5.521|undergo instruction fine tuning
875.76|3.84|um none of these models under one
878.1|4.52|instruction fine-tuning for for this
879.6|3.02|plot yeah
884.22|4.14|um great yeah so so
886.62|5.399|um yeah so one way of interacting with
888.36|5.76|language models is uh uh it by basically
892.019|4.56|finding the model using a technique
894.12|4.86|called rlhf and basically the way it
896.579|4.44|works is you have this data and humans
898.98|3.539|rate like preferences for what type of
901.019|4.021|outputs they prefer
902.519|5.94|and then the model strand on RL to sort
905.04|6.12|of optimize for human preferences
908.459|5.06|and what this plot is showing here is
911.16|5.22|that if you do this RL HF on the model
913.519|5.56|the model performance on a different
916.38|4.74|zero shot task actually gets worse for
919.079|4.2|small models you can see the the blue
921.12|5.18|line is above the Orange Line blue line
923.279|5.641|is the Baseline the word line is arlohs
926.3|4.479|and then if you do it for large models
928.92|3.96|though then you can see that the
930.779|5.521|performance actually has a positive
932.88|4.079|Delta from doing rlh
936.3|2.58|um
936.959|4.141|and so this is sort of interesting thing
938.88|3.959|where like a certain technique might
941.1|3.12|only help if you try on a large enough
942.839|3.841|language model so if you only tried on
944.22|5.16|the small small language models it'd be
946.68|5.279|tough to draw the conclusion that uh it
949.38|3.72|wouldn't help performance
951.959|3.06|um and then later I'll talk about Chain
953.1|4.28|of Thought prompting as another emergent
955.019|2.361|uh
958.56|3.48|um so here's sort of the hand wavy
960.0|6.48|diagram that I sort of used to think
962.04|6.84|about uh emergence as a framework so on
966.48|4.56|the x-axis here there's like a scale of
968.88|5.579|the language model and on the y-axis is
971.04|5.7|a sort of imaginary like you know a
974.459|3.901|scale of like a range of things that a
976.74|3.06|language model can do
978.36|3.18|and then basically you can pick like
979.8|3.899|some random Point like say 100 billion
981.54|4.38|parameters in the language model
983.699|4.2|um and there will be certain abilities
985.92|3.24|um any okay so first you can see as you
987.899|4.081|increase the size of the language model
989.16|4.619|the number of like tasks or things the
991.98|3.12|language can do increases
993.779|3.24|um and then you can see there are some
995.1|4.679|tasks where
997.019|4.56|um a one like models above 100 billion
999.779|3.24|parameters for example can do them but
1001.579|3.18|models below 100 million parameters
1003.019|4.101|can't do them and we call these emergent
1004.759|2.361|abilities
1007.579|2.18|yeah
1010.1|6.299|oh it's just highlighting like
1013.1|4.799|um the dark blue is like tasks that a
1016.399|2.461|smaller language model wouldn't be able
1017.899|3.601|to do
1018.86|5.64|does that make sense yeah and then
1021.5|6.0|then find the light region up top
1024.5|4.679|um oh that just means like tasks that we
1027.5|3.24|haven't been able to solve yet with
1029.179|2.64|language models yeah
1030.74|2.819|cool
1031.819|3.421|and I'm curious to know do you think
1033.559|3.78|that it's not that those tasks in the
1035.24|3.719|white region are unsolvable and like 100
1037.339|5.34|billion scale
1038.959|6.301|or do you think that better models
1042.679|4.201|specific training data would allow us to
1045.26|3.84|get 100 billion scale to get into that
1046.88|6.96|white regime yeah I definitely think
1049.1|6.78|that um it's not a uh fixed
1053.84|4.02|um uh I'll give an example shortly but
1055.88|4.44|it's not it's not uh
1057.86|4.679|you know it's not a rule that you have
1060.32|4.08|to have 100 parameters to do a certain
1062.539|3.481|task it's just that that happens to be
1064.4|3.72|the threshold that we we've observed in
1066.02|4.7|models so far and I do think with better
1068.12|6.5|training data and architecture and
1070.72|3.9|algorithms we can probably beat that
1075.22|5.319|cool um
1077.419|5.88|yeah so as Rylan just mentioned um one
1080.539|4.321|example of uh getting emergence uh can
1083.299|3.061|be with better data so it's not all
1084.86|3.3|about scale I'll sort of give some
1086.36|3.84|Nuance here so
1088.16|4.2|um for this task is just one of the
1090.2|3.96|tasks in the big bench Benchmark
1092.36|4.74|um you can see that for like Lambda
1094.16|4.44|which is a Google model on gpt3
1097.1|6.72|um you actually don't get emergence from
1098.6|7.439|scaling to 137 or 100 uh 137 175 million
1103.82|3.78|parameters
1106.039|3.901|um but when you come in with a different
1107.6|3.6|language model Palm which is train on
1109.94|4.02|better data
1111.2|4.74|um than Lambda mgbt3 you actually can
1113.96|3.9|get the submergent ability even with
1115.94|4.64|this model language model so here at 62
1117.86|2.72|billion parameters
1129.98|4.079|um yeah so so the the challenging thing
1132.32|3.66|is that's a great question
1134.059|4.201|um there's like a lot of differences
1135.98|4.98|between Palm and and Lambda for example
1138.26|4.32|and we can't really ablate them in any
1140.96|4.14|controlled way because of the cost of
1142.58|4.74|pre-training but are like sort of
1145.1|3.78|running hypothesis is that Palm is
1147.32|3.9|trained on better data and that accounts
1148.88|4.14|for a lot of the difference between
1151.22|4.94|um Paul and Lambda it seem like the
1153.02|3.14|smaller skills but it is possible
1160.28|2.82|um yeah that's a good question so I
1161.72|4.94|guess even here you can look at like for
1163.1|3.56|example the Palm 8 billion model
1167.059|3.24|that point there
1168.74|3.299|um you can ablate it and it's like a
1170.299|3.841|little bit higher but it's not really an
1172.039|4.02|emergent yet at that point so it's hard
1174.14|3.419|to it's hard to tell for you know for
1176.059|2.761|example this particular task what the
1177.559|2.221|effect is
1178.82|3.239|yeah
1179.78|4.44|Zoom yeah are there two different
1182.059|3.48|versions of palm if not why are there
1184.22|4.26|two lines
1185.539|6.241|oh so I think the two lines here one is
1188.48|5.4|like uh maybe three shot and then one is
1191.78|5.1|like zero shot
1193.88|4.919|um something like that so it just refers
1196.88|3.24|to the the way that we're using the
1198.799|3.361|language model either with or without
1200.12|4.5|exemplars
1202.16|4.68|yeah
1204.62|4.439|great
1206.84|5.699|I'll talk about it yeah a small ablation
1209.059|6.301|here that sort of shows this so uh this
1212.539|5.581|is an ablation on sort of a toy task uh
1215.36|4.86|where uh basically the language model
1218.12|4.02|has to know that like in English you
1220.22|3.48|have to use plural verbs with plural
1222.14|4.38|subjects and singular verbs with
1223.7|5.64|singular subjects
1226.52|5.039|um and uh the way that what we're doing
1229.34|4.98|here is basically we train like these
1231.559|6.0|small burnt models from scratch and then
1234.32|5.04|we held out like uh we we fixed the
1237.559|4.021|frequency of certain verbs in the
1239.36|4.559|training data set which basically says
1241.58|5.76|like okay what's the effect of seeing a
1243.919|5.341|certain verb in the data more often
1247.34|4.44|um in this plot uh the x-axis is like
1249.26|4.74|the frequency of the verb and the y-axis
1251.78|5.46|is the error rate and what you basically
1254.0|5.1|see is that if you have more in domain
1257.24|4.86|data so if the model sees the verb more
1259.1|4.439|times it does the task a lot better I
1262.1|3.48|mean this is sort of an example of like
1263.539|3.781|having higher quality data or data
1265.58|4.02|that's more in domain for the tasks that
1267.32|4.62|you're evaluating on can make a big
1269.6|4.5|difference even if you're fixing uh the
1271.94|3.84|compute the size of the model and the
1274.1|4.26|rest of the data
1275.78|4.32|Yeah question on Zoom someone asks could
1278.36|3.66|there be a way to distill emergent
1280.1|4.5|abilities down to smaller models from
1282.02|5.399|larger teacher models
1284.6|4.14|um yeah I think so so
1287.419|3.541|um
1288.74|4.74|larger teacher models uh can basically
1290.96|5.339|you can use them for example to generate
1293.48|5.46|data and then if you fine-tune the
1296.299|4.86|larger the smaller model on data it's
1298.94|4.2|pretty likely that you'll be able to uh
1301.159|2.821|get the ability to emerge in a smaller
1303.14|2.159|model
1303.98|3.54|um I'll talk about example of this too
1305.299|4.26|let's see oh actually that's a next
1307.52|3.899|slide so
1309.559|3.661|um desired behaviors can be induced in
1311.419|4.821|smaller models once you sort of know
1313.22|7.02|what Behavior you want so for example
1316.24|6.1|here's the instructory PT uh uh here's a
1320.24|5.1|figure from the instruction PT paper
1322.34|5.04|and basically the desired Behavior here
1325.34|4.98|is like instruction following
1327.38|4.74|and you can see that uh there's multiple
1330.32|4.2|models so on the left you have these
1332.12|4.08|small models that are trained with rlhf
1334.52|4.5|and they actually have better
1336.2|4.26|performance than larger models train on
1339.02|2.88|weaker techniques
1340.46|3.06|um so you can you can so basically the
1341.9|4.56|point is like if you know that you want
1343.52|5.159|a certain behavior that sort of you saw
1346.46|4.74|previously in our emergency in an
1348.679|4.081|emergent way in a larger model you can
1351.2|4.44|find a way to fine-tune on that behavior
1352.76|5.1|specifically and induce that behavior in
1355.64|4.2|a smaller model
1357.86|4.439|I guess the one of the limitations is
1359.84|3.78|that like you unless you know like all
1362.299|3.24|the behaviors that you want you can't
1363.62|4.28|really get this natural emerging
1365.539|2.361|Behavior
1369.74|4.799|um uh I uh yeah another sort of
1372.08|3.959|discussion Point here is that like
1374.539|4.201|there's this question of like what's the
1376.039|4.38|right x-axis for emergence so like right
1378.74|3.96|now we mostly talk about like model
1380.419|3.901|parameters and training flops but like I
1382.7|3.78|guess you could like if you ask deepmind
1384.32|4.38|people like how they look at it you'll
1386.48|3.96|sort of get this argument that model
1388.7|4.2|parameters and training flops are really
1390.44|3.42|just a proxy for like how good the model
1392.9|2.58|is
1393.86|3.84|um and how good the model is can really
1395.48|4.319|be measured by like uh perplexity or
1397.7|5.4|like how well it's doing on some on some
1399.799|5.821|uh Dev sets such as Wiki text 103.
1403.1|3.24|um so basically you can also measure
1405.62|3.179|um
1406.34|5.1|uh emergence in terms of perplexity so
1408.799|4.921|so here is
1411.44|3.479|um wikitex perplexity
1413.72|3.66|um and then you can see like on a
1414.919|4.021|downstream task that as the perplexity
1417.38|3.0|uh gets better there's sort of this
1418.94|2.4|threshold where you're able to do a lot
1420.38|3.84|better
1421.34|4.86|um on the downstream task
1424.22|3.959|um and there's sort of a strong
1426.2|3.9|correlation right at least right now
1428.179|3.721|between perplexity and training compute
1430.1|5.059|so you can see like these two lines are
1431.9|6.48|are pretty similar and um
1435.159|4.781|basically I think uh in the future if we
1438.38|3.0|have you know much better models that
1439.94|3.359|are a lot smaller turn on much better
1441.38|4.08|data and better algorithms then maybe
1443.299|3.301|Wiki text perplexity can show a
1445.46|3.959|different type of
1446.6|5.18|um plot than using other uh metrics yeah
1449.419|2.361|go ahead
1452.0|6.24|so Wiki text uh is basically
1456.02|4.98|um a uh I think it's like a subset of
1458.24|4.799|Wikipedia and then perplexity is like a
1461.0|4.26|measure of how well you can predict the
1463.039|4.321|next word in a data set
1465.26|3.779|so basically if you if you're really
1467.36|4.559|good at modeling the next word on this
1469.039|4.981|like particular evaluation set
1471.919|5.161|um that that's sort of a measure of like
1474.02|5.72|how well you understand language
1477.08|2.66|that makes sense
1481.1|4.92|oh this is like a held out test out
1484.28|4.74|yeah
1486.02|3.0|cool
1489.32|3.12|um
1490.34|4.92|and then a final thing that I think is
1492.44|4.859|like pretty exciting about emergence is
1495.26|3.48|that they're sort of uh not just like
1497.299|3.601|technical emergence that we've talked
1498.74|4.799|about but there's sort of sociological
1500.9|4.5|changes in how the AI Community views
1503.539|4.02|like scaling and how to use language
1505.4|5.88|models
1507.559|5.401|um so here's some examples of
1511.28|4.5|um where scaling up the size of the
1512.96|6.06|language model enables you to in this
1515.78|5.04|sort of few shot scenario uh beat a task
1519.02|3.18|specific fine-tuned language model
1520.82|3.839|that's usually fine-tuned on say
1522.2|5.52|thousands of of examples
1524.659|5.541|so basically the green line is the prior
1527.72|5.4|state-of-the-art achieved by fine-tuning
1530.2|4.66|and then if you just uh and then the
1533.12|3.419|blue dots basically show if you take a
1534.86|2.939|pre-trained language model and you do
1536.539|2.76|few shot prompting which means the
1537.799|3.181|language model isn't intentionally
1539.299|2.88|trained to do the task
1540.98|3.059|um you can often get state-of-the-art
1542.179|3.961|results just by continuing to scale up
1544.039|3.601|the size of the language model and
1546.14|3.48|obviously there's there's limitations
1547.64|4.32|here you don't want to just keep scaling
1549.62|4.08|up in order to get state of the art but
1551.96|3.12|I think it's a it's a pretty big change
1553.7|3.66|in people's minds that you could
1555.08|3.54|actually get some of the best results uh
1557.36|4.4|just by scaling up the size and language
1558.62|3.14|model and doing property
1570.2|5.459|uh which one this one
1572.72|4.819|not sure should we in general assume oh
1575.659|3.601|he said yes
1577.539|4.12|okay
1579.26|5.22|we said should we in general assume that
1581.659|5.701|scale trumps
1584.48|5.1|yeah so um that's a great question uh so
1587.36|5.52|this plot is saying that um you
1589.58|5.82|fine-tune and you can do uh and and okay
1592.88|4.08|yeah so uh it depends on your like
1595.4|6.06|particular
1596.96|5.819|um uh task uh but what this plot is
1601.46|3.079|saying
1602.779|4.081|um is that
1604.539|5.74|uh like
1606.86|5.52|we're not like fine-tuned smaller models
1610.279|3.721|um can do well on some tasks if you if
1612.38|3.72|you target it well but for like tests
1614.0|3.419|that are more complicated
1616.1|4.8|um often you can do better just by
1617.419|5.041|scaling um so they're sort of uh tasks
1620.9|4.74|that fall into both of these categories
1622.46|5.88|uh and I wouldn't say that um it's
1625.64|3.419|contradictory I guess some tasks
1628.34|4.319|um
1629.059|5.161|you would do a lot better uh just by
1632.659|4.26|um just basically the size of the model
1634.22|4.02|and then other tasks if it's like a very
1636.919|4.021|narrow domain or the large language
1638.24|4.74|model might not be trained on that kind
1640.94|4.28|of data then you would do better by fine
1642.98|2.24|too
1646.94|3.9|okay great
1649.159|3.481|um so here's sort of a little summary
1650.84|4.14|slide so basically emerging abilities
1652.64|4.74|can only be observed in large models and
1654.98|4.38|if you try to predict uh their emergence
1657.38|3.179|just by looking at the plots for small
1659.36|3.179|models then you wouldn't be able to do
1660.559|4.021|it
1662.539|4.681|um and I I sort of had a little
1664.58|4.52|reflection on how to look at this so
1667.22|5.16|emergence is really this framing of like
1669.1|4.84|uh how to view new abilities that are
1672.38|4.2|not intentionally built in to the
1673.94|4.14|pre-training and I think the subtext for
1676.58|3.839|this is super important which is like
1678.08|4.02|you can see it as implicit argument for
1680.419|3.781|why we should keep scaling up language
1682.1|3.54|models because you don't you get these
1684.2|3.54|abilities that are really hard to find
1685.64|3.48|otherwise
1687.74|3.0|um and the context around this is pretty
1689.12|3.78|important because
1690.74|4.86|um it's really expensive to to continue
1692.9|4.86|scaling up these models and
1695.6|3.6|um you know even like one year ago a lot
1697.76|3.0|of people didn't believe that you could
1699.2|2.64|do better on certain tasks just by
1700.76|2.64|scaling up the size of the language
1701.84|3.9|model
1703.4|3.54|they sort of uh if you work in Industry
1705.74|4.14|at all there's like this interesting
1706.94|5.46|tension between emergence and also like
1709.88|4.919|many production tasks so emergence is
1712.4|4.56|sort of this like task General phenomena
1714.799|3.661|where you scale up the model and it's
1716.96|3.719|like really expensive but the single
1718.46|5.819|model can do a lot of tasks this is sort
1720.679|5.521|of like a in the direction of AGI
1724.279|5.161|um and then for many production tasks
1726.2|4.56|you have sort of the opposite where you
1729.44|4.2|know what task it is for example
1730.76|4.56|translating to Spanish and then you have
1733.64|3.48|these constraints on compute because you
1735.32|3.42|know when you build Google Translate for
1737.12|3.24|example you don't want people to have to
1738.74|2.819|wait a couple seconds just to get the
1740.36|3.299|translation
1741.559|4.441|and then you also happen to have a lot
1743.659|4.921|of in domain data so you have for
1746.0|5.82|example like you know a million uh pairs
1748.58|5.579|of English Spanish sentences to train on
1751.82|4.08|and this is like sort of the opposite
1754.159|5.101|setting where you don't really care
1755.9|4.98|about uh that the model is emergence you
1759.26|3.6|can just train a very small model on the
1760.88|4.56|data and do one of the tasks without
1762.86|6.6|having to use lab compute
1765.44|5.459|and the final point is that I think uh a
1769.46|2.939|really promising research direction if
1770.899|4.201|anyone is interested in doing research
1772.399|5.52|is to like work on predicting future
1775.1|4.26|emerging abilities and I haven't seen a
1777.919|3.901|lot of work on it recently just because
1779.36|4.02|I think maybe it's too hard for example
1781.82|4.2|like you could only like predict
1783.38|4.62|emergence for a specific task
1786.02|3.96|um uh or like one way of strict
1788.0|4.02|emergence might not be super General and
1789.98|3.419|uh so so I haven't seen much work on
1792.02|3.42|that but I think this is a pretty
1793.399|3.481|promising direction to work on I mean
1795.44|3.56|maybe a topic is working on it I don't
1796.88|2.12|know
1800.179|4.321|um okay great any questions on that
1801.559|5.72|before I move on to channel.com
1804.5|2.779|yeah go ahead
1809.179|4.5|thank you which parameters are best
1812.12|3.24|skilled to get like improve your
1813.679|6.081|properties it's obviously there are many
1815.36|4.4|different options for wearing glasses
1824.14|3.759|or whatever
1826.1|4.02|is that mostly something we just test
1827.899|3.961|and then we find out which ones scale
1830.12|3.659|that here gets better results or like
1831.86|4.26|yeah
1833.779|5.101|I would say that we don't have very
1836.12|5.1|principled methods for like how to scale
1838.88|3.0|these architectures
1841.22|2.28|um
1841.88|3.779|I'm not an expert in this but some of it
1843.5|3.899|has to deal with like how many
1845.659|3.841|parameters you can fit onto a particular
1847.399|4.801|TPU
1849.5|4.44|um uh but in general I think you scale
1852.2|4.02|up like the number of intentions heads
1853.94|3.78|and the embeddings like somewhat
1856.22|2.88|proportionally
1857.72|4.14|um but yeah I think this is like an open
1859.1|5.16|research question and because you know
1861.86|3.96|you can't really do ablations over these
1864.26|3.299|these pre-training
1865.82|4.2|um you can't really do ablations of your
1867.559|4.98|pre-training it's hard to sort of uh you
1870.02|4.68|know have any principled way of doing it
1872.539|3.481|other than some Engineers who are in
1874.7|2.52|charge of like doing it saying okay I
1876.02|4.139|think this is the right thing to do and
1877.22|5.699|then it kind of works and go with it
1880.159|5.161|yeah do you have any indication of the
1882.919|4.801|asymptotic behavior of the scalping if
1885.32|4.5|you expect that eventually you would you
1887.72|3.78|know reach either some Plateau a split
1889.82|4.82|Planet but non-zero loss or it would
1891.5|3.14|just go all the way down to zero
1894.679|4.021|um yeah that's a great question
1897.32|3.839|um
1898.7|5.82|I think I mean there's uh you mean on
1901.159|4.921|like uh perplexity or like some uh on a
1904.52|3.48|particular task or just in general on
1906.08|3.54|like Network predictions well seems like
1908.0|3.84|this is also pretty General pretty task
1909.62|5.279|independent right it's like emergent
1911.84|4.88|scaling yeah but take the limit of
1914.899|3.601|infinite parameters then even
1916.72|3.88|analytically is there any sense of
1918.5|5.399|whether how that can move
1920.6|4.92|yeah I have no clue um I think if if uh
1923.899|3.9|like for most of these tasks there's
1925.52|4.08|like a limit to accuracy like 100 for
1927.799|4.081|example so there's some there's some
1929.6|3.959|sort of asymptote there but I guess
1931.88|3.779|um the deeper question that you might be
1933.559|3.901|asking is like can a language model like
1935.659|3.181|perfectly know like
1937.46|4.319|you know how to predict the next word
1938.84|6.059|for any given input
1941.779|5.64|um and maybe like I mean I guess there's
1944.899|5.28|some like limit to like
1947.419|4.14|um like if I say a sentence um there are
1950.179|2.581|like two possible next words or
1951.559|3.48|something and you might not be able to
1952.76|2.88|get guessed that perfectly
1955.039|2.341|um
1955.64|3.06|so I think there's some limit but like I
1957.38|2.82|think we're far from reaching that limit
1958.7|2.82|and there's still a lot of Unsolved
1960.2|2.52|tasks that
1961.52|3.48|um sort of indicate that there's a lot
1962.72|4.5|of Headroom
1965.0|4.98|yeah if researchers are interested in
1967.22|5.22|studying emergence yeah what family of
1969.98|5.28|different size models is publicly
1972.44|5.04|available or best for study
1975.26|3.0|yeah good question
1977.48|5.34|um
1978.26|6.12|so uh I think the openai API has like a
1982.82|3.239|lot of language models and we actually
1984.38|4.5|use that a lot even at Google it's used
1986.059|4.921|to study emergence and that's sort of
1988.88|4.98|one way of doing it and actually a lot
1990.98|4.26|of these models are currently free
1993.86|3.539|um they're rate limited but they're free
1995.24|3.12|so that so we also use that
1997.399|3.741|um
1998.36|5.22|I think there's also uh
2001.14|4.24|smaller language models like for example
2003.58|4.439|there's like a ul2 model that's like 20
2005.38|3.96|billion parameters but I guess you're
2008.019|2.52|right there there is sort of this
2009.34|2.579|challenge where like the small language
2010.539|3.36|models you won't see a lot of these
2011.919|3.961|emerging behaviors so you kind of have
2013.899|2.821|to either train
2015.88|3.72|um
2016.72|5.88|uh yeah so you kind of have to uh either
2019.6|4.919|use like open AI API for now or or wait
2022.6|4.86|until people train larger models I guess
2024.519|3.961|there's also the uh Bloom and like you
2027.46|3.3|guys probably know better than me like
2028.48|3.9|opt models that are publicly available
2030.76|2.46|but I haven't seen a lot of experiments
2032.38|3.6|on them
2033.22|5.64|yeah yeah
2035.98|5.22|so like my question is are there are
2038.86|4.08|there emergent abilities that like are
2041.2|3.92|accessible in the lower parameter
2042.94|2.18|reviews
2049.619|4.06|there might be like somebody maybe not
2052.3|3.24|like Chain of Thought but like are there
2053.679|3.96|some that are like yeah definitely I
2055.54|3.78|think uh in the paper we had like the
2057.639|3.121|list of a couple dozen abilities that
2059.32|3.0|would be emerging at like 8 billion
2060.76|4.379|parameters or like six people in
2062.32|4.279|parameters or something like that yeah
2065.139|3.661|yeah
2066.599|4.661|the first question is do you see
2068.8|5.16|strategy tactics between the larger Tech
2071.26|4.859|firms differing systematically in
2073.96|5.48|studying these models whereas basically
2076.119|3.321|everyone taking the same approach
2080.139|2.121|um
2083.04|5.74|I I I wouldn't say that everyone is
2086.32|4.14|taking the same approach
2088.78|4.44|um I think
2090.46|6.24|as one example anthropic takes like a
2093.22|5.34|very safety Centric approach and they're
2096.7|4.5|super interested in like emerging
2098.56|4.26|abilities because uh there could be
2101.2|3.419|emergent abilities that are undesirable
2102.82|3.6|and they want to predict those types of
2104.619|4.621|things
2106.42|4.439|um I also don't know what happens at
2109.24|4.32|other companies other than at Google so
2110.859|5.461|I can't really speak too much to that
2113.56|4.74|yeah the second question what are some
2116.32|4.019|examples of tasks or abilities that have
2118.3|4.62|not yet emerged even in models like
2120.339|4.681|Lambda and chat GPT Etc
2122.92|4.699|oh yeah I have uh maybe I'll just show
2125.02|2.599|this real quick
2130.599|2.061|um
2133.42|7.439|there's like a nice list somewhere
2137.859|3.0|so
2144.82|6.6|so yeah so basically what we did is um
2148.839|4.141|there's like 200 tasks in big bench and
2151.42|5.22|then we basically classified them into
2152.98|6.66|like smoothly increasing emergent with
2156.64|4.74|gpt3 or Lambda emergent with palm and
2159.64|3.9|then flat which is like no model better
2161.38|4.68|than random so I think if you look at
2163.54|4.5|any of these tasks here
2166.06|5.34|um they should still not have emerged
2168.04|6.44|yet and if you can uh get them to merge
2171.4|3.08|that'd be interesting yeah
2174.88|5.219|sorry
2177.18|4.419|questions oh okay yeah this is not a
2180.099|3.181|super uh I think this is like a couple
2181.599|3.361|months old so sorry
2183.28|5.66|yeah yeah
2184.96|3.98|oh 20 Questions okay yeah
2189.46|3.6|yeah I think
2191.38|3.3|like the cool thing is like you can see
2193.06|3.6|over time right like originally like
2194.68|3.78|maybe only like these were you know
2196.66|3.179|emergent and then when Palm came out
2198.46|3.48|you'd see a couple dozen more abilities
2199.839|3.361|you can imagine and then you know I
2201.94|3.54|suspect
2203.2|4.62|um you know in a year or two most of
2205.48|4.26|these will become emergent and uh we'll
2207.82|4.08|need harder benchmarks yeah there's
2209.74|4.74|another question why doesn't Google take
2211.9|4.439|as much of a safety center approach like
2214.48|3.66|you said in Project notes are there
2216.339|5.121|reasons to believe harmful capabilities
2218.14|3.32|wouldn't be emerging
2222.88|3.6|um yeah I don't want to answer the
2224.32|6.24|question on behalf of Google I just can
2226.48|5.7|only talk about uh my own opinions
2230.56|3.539|um but I think the reality is that
2232.18|3.419|Google if even if you look at like the
2234.099|3.901|amount of research that Google does it
2235.599|4.681|might not be in the large language
2238.0|4.5|models very specifically but like the
2240.28|3.96|amount of Safety Research that we do I
2242.5|3.0|think is more than andropic if you if
2244.24|3.24|you actually look at like the number of
2245.5|5.48|papers published don't quote me on this
2247.48|3.5|but uh I think that's correct
2251.44|5.54|um okay
2253.119|3.861|uh uh great
2257.74|4.32|so
2260.26|3.839|yeah I'll talk about um Chain of Thought
2262.06|4.5|prompting so basically channel.prompting
2264.099|4.321|is uh this way of doing reasoning
2266.56|3.48|multi-step reasoning with large language
2268.42|2.699|models
2270.04|1.92|um and
2271.119|3.121|um
2271.96|4.5|yeah I wanted to say that I get super
2274.24|4.8|exciting to see like a lot of people at
2276.46|5.76|Google working on this and also to see
2279.04|6.96|um uh Sundar CEO present this at our
2282.22|4.74|last year's uh Google IO press event
2286.0|4.38|um
2286.96|5.7|and uh basically the motivation for this
2290.38|4.86|is that we want language models to do
2292.66|4.86|like more complicated tasks that you
2295.24|3.839|know for example uh we know language
2297.52|4.319|models can do easy tasks like Cinema
2299.079|4.621|analysis or translation but what about
2301.839|4.26|like more complicated tasks that might
2303.7|3.98|even take a human uh minute or more to
2306.099|3.961|do
2307.68|5.08|and the goal here is to basically guide
2310.06|4.019|them with metadata so for example
2312.76|3.66|instead of just giving like an input
2314.079|5.101|output pair we want to give them the
2316.42|4.98|entire reasoning process and have them
2319.18|4.62|mimic that
2321.4|4.08|um and the basically you can see here uh
2323.8|3.059|you know in a standard prompt you have
2325.48|3.119|like the question and then the answer
2326.859|3.72|and then you have a question in the
2328.599|4.381|model gives a new answer unfortunately
2330.579|3.661|it's wrong
2332.98|2.7|um and then with Chain of Thought
2334.24|4.14|prompting
2335.68|4.62|um uh you give the model a question and
2338.38|4.199|then kind of like how your teacher would
2340.3|4.319|ask you to show your work uh you give
2342.579|4.26|like the uh the Chain of Thought is what
2344.619|3.421|we call it or basically a reasoning path
2346.839|3.121|um and then you give the final answer
2348.04|3.9|and then when the model excuse this
2349.96|3.42|unseen question now it's able to give
2351.94|3.12|the reasoning path and then give the
2353.38|4.5|correct final answer
2355.06|4.74|and the way that we add these uh prompts
2357.88|3.78|into the prompt is basically we just
2359.8|4.26|manually write a couple and then add it
2361.66|7.58|into the top
2364.06|5.18|um so let me just show how that works
2369.88|5.88|um so this was the open API
2372.66|6.04|and basically
2375.76|5.76|uh here's like the non-chain f.way of
2378.7|3.419|doing it so basically you would have
2381.52|2.4|um
2382.119|4.561|question answer question answer question
2383.92|4.919|answer and then new question about you
2386.68|3.419|know cafeteria 23 apples they use 20 and
2388.839|2.76|make lunch and bought six more how many
2390.099|5.721|apples they have
2391.599|6.901|I'm in the model uh gets it wrong
2395.82|6.1|and the only difference with chain F dot
2398.5|5.4|is that you give these uh intermediate
2401.92|3.659|reasoning paths
2403.9|3.66|um before giving the final answer so
2405.579|3.54|here's a path there's a there's a
2407.56|5.279|reasoning chain there's another
2409.119|6.0|reasoning chain and then uh now the
2412.839|6.24|model for this unseen question
2415.119|5.281|uh gives the entire reasoning process
2419.079|3.901|um and then this actually enables the
2420.4|5.15|model to get it correct
2422.98|5.0|I'll give another quick example
2425.55|5.35|[Music]
2427.98|4.359|so here the task is uh just take the
2430.9|4.8|last letters of the words and Bill Gates
2432.339|5.28|so like L from Bill and S from Gates and
2435.7|3.54|then concatenate them and the answer
2437.619|4.261|should be LS
2439.24|5.58|and then here the model gets it wrong
2441.88|4.92|the answer should be NK
2444.82|4.94|it says SK
2446.8|5.88|and then if you do Chain of Thought
2449.76|5.02|obviously this has become it becomes
2452.68|3.54|very easy for the model so you know it
2454.78|5.64|says the last letter of Bill is L the
2456.22|6.6|last letter Gates is s the answer is LS
2460.42|4.919|and then here it's able to do the last
2462.82|6.12|layer for elon's M and the last letter
2465.339|6.78|of mosque is K and answer is NK
2468.94|6.419|um so any any is this clear any
2472.119|5.661|questions about what's going on here
2475.359|2.421|okay
2477.82|3.06|um
2478.9|4.14|so basically we can have these similar
2480.88|5.06|plots where the x-axis is the model
2483.04|5.579|scale the y-axis is the performance
2485.94|4.72|so on the left we have this math board
2488.619|4.081|question Benchmark called gsmak it's
2490.66|4.04|basically like questions that you'd see
2492.7|5.04|in like an elementary school math test
2494.7|5.56|and you can see the the blue dot is
2497.74|4.26|standard and the purple star is Chain of
2500.26|3.48|Thought I mean basically you see that
2502.0|4.74|the Chain of Thought if you use a large
2503.74|5.4|enough model does a lot better than
2506.74|3.839|standard prompting
2509.14|3.86|um it actually beats the fine-tuned
2510.579|5.221|state of the art um at the time
2513.0|5.92|a similar example is is on this
2515.8|5.58|Benchmark called strategy QA and what
2518.92|4.02|strategy is it's basically like this uh
2521.38|3.12|World Knowledge plus Common Sense
2522.94|3.48|reasoning Benchmark so the question
2524.5|5.099|would be like can you hide a basketball
2526.42|5.159|in the sand cat's ear and then the model
2529.599|3.541|would uh say like you know basketball is
2531.579|3.54|about this size the sand cat's ear is
2533.14|3.36|that those server would not fit
2535.119|3.541|um and now this Benchmark you can also
2536.5|5.28|see that we can beat the fine-tune state
2538.66|4.32|of the art from before just by using
2541.78|3.799|Chain of Thought with a large enough
2542.98|2.599|language model
2548.02|4.98|um so one way we use this is that we
2550.54|6.12|evaluate a Chain of Thought on a certain
2553.0|5.28|subset of of big bench tasks so we
2556.66|4.08|created this subset called Big bench
2558.28|4.38|hard and basically it's like 23
2560.74|5.58|challenging tasks from Big bench where
2562.66|6.24|like no model had done better than uh
2566.32|4.38|the average human Raider
2568.9|3.66|um so the way that you prompt the model
2570.7|4.26|is that you'd have like a task
2572.56|6.48|description question options chain of
2574.96|5.46|dot uh and then the test time question
2579.04|3.02|um and so I'll give a couple examples of
2580.42|6.36|like tasks here
2582.06|6.46|uh so uh one example is navigate uh
2586.78|4.079|basically what the language model has to
2588.52|4.02|do and this task is uh it has to
2590.859|3.601|basically follow these so the question
2592.54|3.9|is like if you follow these instructions
2594.46|3.6|do you return to the starting point turn
2596.44|4.74|left turn right take five steps take
2598.06|5.94|four steps turn around take nine steps
2601.18|5.159|um and then the model uh following the
2604.0|5.28|future exemplars is able to like
2606.339|4.801|basically track state after all of uh
2609.28|4.02|all of the actions and then at the end
2611.14|4.08|it says okay are we at the final answer
2613.3|3.9|so the answer are we at the Fun are we
2615.22|5.099|at the original location I mean if it is
2617.2|4.139|zero zero the answer is yes
2620.319|4.02|um
2621.339|5.341|just give an example of another task
2624.339|4.141|um here's a task that's like very easy
2626.68|4.32|for humans basically word sorting so
2628.48|4.619|like there's a list of words Burley
2631.0|4.22|Baylor I'm not gonna read them and
2633.099|5.041|basically uh the model has to sort them
2635.22|4.359|alphabetical order
2638.14|3.24|um and here the model can follow the
2639.579|4.081|future employers so you have this uh
2641.38|5.219|pretty complicated like
2643.66|5.459|um uh chain of dot where the model has
2646.599|4.26|to like sort each of the subparts and
2649.119|4.641|then finally it gets to the the final
2650.859|2.901|answer which is correct
2653.92|3.84|foreign
2654.88|5.76|so here's sort of this result summary on
2657.76|6.48|on this subset um of big bench so you
2660.64|5.52|can see okay uh we have uh two metrics
2664.24|3.42|uh one is just the average performance
2666.16|4.679|on all these tasks
2667.66|6.72|um and the second uh is the percent of
2670.839|6.421|tasks that are above uh the average
2674.38|6.54|human reader so average numerator is 67
2677.26|5.579|Max human right is 94. and then prior
2680.92|4.199|results uh the model was doing like way
2682.839|5.041|worse it was like 50. I mean this is
2685.119|4.74|sort of by Def by construction of this
2687.88|4.439|subset
2689.859|4.621|um and then we used code eventually O2
2692.319|3.421|which is like one of the open AI models
2694.48|5.76|um and actually you can use this one for
2695.74|5.879|free with open API and basically uh if
2700.24|3.54|you do answer only prompting without
2701.619|4.081|Chain of Thought then you sort of are
2703.78|5.16|being the average numerator on like five
2705.7|5.7|of 27 but if you use chain f.prompting
2708.94|4.08|then the performance increases by this
2711.4|4.56|uh pretty decent amount and you're able
2713.02|5.22|to pass the human average human other
2715.96|3.42|majority of tasks
2718.24|3.48|um and then below is just this
2719.38|4.26|visualization of uh the tasks that are
2721.72|4.859|doing worse than humans in red and then
2723.64|5.699|better than humans in thank you yeah
2726.579|5.221|two questions isn't this similar to rlh
2729.339|5.661|Spirit at least
2731.8|6.62|uh is what similar
2735.0|3.42|I'm not sure
2740.38|6.42|um yeah I think uh it's uh there
2744.4|3.84|I wouldn't call it similar so like Chain
2746.8|3.6|of Thought is basically you take a
2748.24|3.54|pre-trained language model and you use a
2750.4|4.02|prompting technique that includes
2751.78|5.339|intermediate musica
2754.42|4.26|um the way that rlhf works is that you
2757.119|4.021|have this additional data that you want
2758.68|4.56|to fine-tune the model on and you have a
2761.14|5.34|preference model that sort of predicts
2763.24|3.96|like how well does a certain output
2766.48|4.2|um
2767.2|7.32|uh uh uh How likely is that to be
2770.68|5.76|preferred by humans and then rlhf uh
2774.52|4.14|what that does is it fine-tune them all
2776.44|4.02|it fine-tunes like the language model to
2778.66|4.38|do well on the preference model's
2780.46|4.139|prediction so basically uh it's it's
2783.04|3.12|sort of aligning the model with what
2784.599|4.26|humans would prefer
2786.16|5.78|is there a second question
2788.859|3.081|okay um
2796.48|3.24|um yes uh the short answer is yes
2799.119|2.401|um
2799.72|4.32|the sort of complicated thing about that
2801.52|4.86|is that you have to have like Chain of
2804.04|3.539|Thought intermediate steps and those are
2806.38|4.8|pretty
2807.579|5.461|um uh it can be costly to sort of uh to
2811.18|4.1|gather that data and to do the fine
2813.04|2.24|today
2819.28|4.079|I like prompt Engineering in general is
2821.319|4.381|just an artifact that won't be necessary
2823.359|4.681|for larger scale models that are better
2825.7|4.74|able to understand
2828.04|4.62|yeah so that's a great question
2830.44|4.32|um uh basically the question is like how
2832.66|3.84|like ephemeral is like prompt
2834.76|4.62|engineering gonna be
2836.5|5.099|um I think uh we'll find out but um some
2839.38|4.32|initial intuitions are that like for
2841.599|3.72|easy tasks that are like you know easy
2843.7|2.879|to describe and maybe they're multiple
2845.319|3.181|choice
2846.579|3.481|um larger models will probably be more
2848.5|3.66|robust to prompt engineering and there's
2850.06|3.84|sort of less you can do with that but I
2852.16|3.48|think as language models get more
2853.9|3.3|powerful
2855.64|3.42|um it'll sort of be more normal to use
2857.2|4.44|them on a lot a lot more challenging
2859.06|4.5|tasks and in those tasks you'll have to
2861.64|3.78|specify exactly what you want them all
2863.56|3.059|to do et cetera so I think there'll
2865.42|2.34|still be some room for prompt
2866.619|3.381|engineering there at least in the near
2867.76|2.24|future
2876.66|4.78|and then the other one basically sorting
2879.339|7.101|the words
2881.44|5.0|yeah so I mean I see that's okay because
2887.579|5.341|one thing that it does that took a while
2890.079|5.581|but with that model also become better
2892.92|4.36|do you have to give the channel thought
2895.66|3.659|for like the topic words are the best
2897.28|6.42|yeah that's a great question
2899.319|6.54|um so uh for some tasks where you've
2903.7|3.84|seen similar data in pre-training the
2905.859|3.96|model can do really well even if the
2907.54|3.539|Chain of Thought is from another task
2909.819|2.581|um so for example like math word
2911.079|3.24|problems you actually don't really need
2912.4|3.719|a math Chain of Thought because the mod
2914.319|3.601|already knows how to do that but like
2916.119|3.48|for a tasks like this
2917.92|3.78|you probably haven't seen any data
2919.599|4.081|that's like the Chain of Thought here so
2921.7|3.419|without task specific exemplars you
2923.68|2.88|probably wouldn't do super well on tasks
2925.119|3.781|like this without
2926.56|4.62|um manually writing them uh for for
2928.9|4.02|other examples
2931.18|3.74|uh yeah
2932.92|2.0|um
2938.88|4.0|do you pursue the model as like if I was
2941.38|3.5|a person how would I do this better or
2942.88|5.4|is it like trying to give it more like
2944.88|6.4|uh compute in order to like like before
2948.28|3.72|yesterday enter yeah great question
2951.28|2.819|um
2952.0|4.14|I think my motivation was just thinking
2954.099|4.621|about it just as you said like what's
2956.14|5.58|going on in sort of a human's mind while
2958.72|5.76|they try to solve this math question
2961.72|4.859|um and uh well if you notice like at
2964.48|3.9|least some humans will think actually in
2966.579|3.601|natural language
2968.38|3.84|um so like if you just like think about
2970.18|3.24|like if you pay attention a lot to like
2972.22|2.7|what's going on in your mind you
2973.42|3.3|actually notice that you sometimes you
2974.92|4.32|think a language and so while the
2976.72|4.26|language too so that was kind of the
2979.24|5.099|motivation behind
2980.98|4.8|um asking language model to do that and
2984.339|3.361|I think
2985.78|4.319|um uh one thing that sort of went well
2987.7|4.139|is that uh the development of like this
2990.099|5.22|technique actually coincided with like
2991.839|4.381|the development of palm and so
2995.319|3.181|um
2996.22|5.16|uh yeah basically having the model Palm
2998.5|5.52|sort of allowed us to do a lot uh better
3001.38|4.979|tasks or a lot more challenging tasks uh
3004.02|4.579|using Chain of Thought
3006.359|2.24|yeah
3008.72|5.32|like we're saying that it matters is the
3011.76|3.96|absolute number of examples of such a
3014.04|2.76|thought process or whatever in the data
3015.72|4.08|set
3016.8|5.279|um or in the front unit is that is that
3019.8|4.5|the main significant thing or is it like
3022.079|3.481|is this relative number of frequency of
3024.3|2.94|like those examples are just like
3025.56|3.779|negative examples which are like not
3027.24|4.26|good examples of content reasons do
3029.339|3.961|those matter as much as just the
3031.5|3.839|absolute number of
3033.3|3.96|um for example
3035.339|2.821|yeah good question
3037.26|2.76|um
3038.16|3.54|so I guess the challenging thing is like
3040.02|4.2|we can't really measure how many similar
3041.7|5.159|examples are in the training center uh
3044.22|5.16|you know it's it's hard to do that well
3046.859|4.561|and uh no I don't think anyone's done
3049.38|4.38|that before so it's for this open
3051.42|3.72|question of like why uh China thought
3053.76|2.339|even works because you actually don't
3055.14|2.82|see
3056.099|3.121|a similar data like that in the training
3057.96|1.92|set
3059.22|2.94|um
3059.88|4.699|yeah I think it's open question like why
3062.16|2.419|it works
3070.339|4.621|think about like how um
3076.4|4.06|but like how do you actually think like
3078.599|3.72|in like what a situation for the model
3080.46|5.52|or like I mean understand like a shift
3082.319|5.401|in for a specific task like some weights
3085.98|4.28|get like warm and
3087.72|2.54|Focus
3090.54|3.42|yeah I don't really think about it in
3092.46|2.879|terms of like what's going on in the
3093.96|3.48|weights I guess the way that I think
3095.339|4.02|about it is that like
3097.44|3.6|um it'd be unfair for me to like give
3099.359|4.081|you a math question and ask you to give
3101.04|3.96|me the answer within like half a second
3103.44|3.24|which is basically like what you're
3105.0|3.24|doing with the model and when you don't
3106.68|2.76|do a Chain of Thought right you're
3108.24|2.7|basically asking this like challenging
3109.44|3.84|question and the model doesn't have
3110.94|3.659|enough compute to like solve it in one
3113.28|3.36|pass to give you the next answer
3114.599|4.321|immediately
3116.64|2.82|um I think the second thing that
3118.92|3.899|um
3119.46|5.04|I sort of think about is that like the
3122.819|3.121|model has learned like a compositional
3124.5|3.599|set of skills
3125.94|3.96|um during during pre-training so maybe
3128.099|4.441|it hasn't really learned like you know
3129.9|3.959|this particular navigate task during
3132.54|4.14|pre-training but it's doing other things
3133.859|4.381|right so I'm like okay if you uh take
3136.68|3.24|five steps and you're facing this maybe
3138.24|3.42|yeah you should add five here or
3139.92|3.899|something like that right and it's
3141.66|4.5|learned how to do pattern matching so
3143.819|4.8|uh maybe in the future exemplars it can
3146.16|4.38|match sort of uh what the reasoning path
3148.619|3.48|is with like what the question was and
3150.54|3.24|so there's sort of these little skills
3152.099|3.121|that the model may know
3153.78|2.76|um and then maybe if you can combine
3155.22|3.0|them together in some clever way then
3156.54|4.46|you can get them all to solve a more
3158.22|2.78|challenging problems
3161.88|2.3|um okay
3164.819|3.921|Iran uh how much time do we have
3170.88|4.88|okay 50 okay
3173.7|2.06|okay
3178.339|5.801|uh okay great
3181.74|5.16|a good example of how we can
3184.14|5.64|get away yeah
3186.9|5.939|is
3189.78|6.18|yeah okay great yeah feel free to keep
3192.839|5.28|asking questions if you have any um
3195.96|4.32|so uh
3198.119|4.2|yeah here's another example of emergence
3200.28|4.26|so basically you can see there's three
3202.319|4.381|models here in structured BTT codex and
3204.54|6.059|poem Chain of Thought in blue non-chain
3206.7|5.94|of thought uh is in uh is in Gray and
3210.599|3.781|then you can see uh you actually have to
3212.64|4.199|have sufficient model scale to get Chain
3214.38|5.52|of Thought to work well
3216.839|4.621|um and uh I guess the intuition here is
3219.9|4.38|that like if you have a really small
3221.46|4.5|model uh the the model sort of will keep
3224.28|4.079|repeating itself or not say anything
3225.96|3.84|coherent Navigator final answer which is
3228.359|3.541|why using Chain of Thought for the small
3229.8|3.72|models doesn't really work well and then
3231.9|3.0|for the large models obviously you know
3233.52|3.9|for multiple step map like for
3234.9|5.159|multi-step problems uh the model is
3237.42|4.02|going to uh be able to solve the task at
3240.059|3.06|a lot higher accuracy with Chain of
3241.44|3.96|Thought
3243.119|4.2|okay
3245.4|4.38|um and another cool thing about Chain of
3247.319|3.661|Thought is there are sort of some tasks
3249.78|2.819|where
3250.98|5.04|um you sort of wouldn't get emergent
3252.599|6.121|Behavior at all uh so you know emergence
3256.02|5.819|hasn't been unlocked uh yet
3258.72|4.56|um but uh you can see that the if you
3261.839|4.141|use Chain of Thought you can unlock this
3263.28|5.7|emergent performance uh in in smaller
3265.98|5.4|models so uh one example here is like
3268.98|4.74|multi-step arithmetic where like I don't
3271.38|3.84|know if you'll ever you know maybe I
3273.72|3.18|don't want to say never but like it you
3275.22|3.48|can it's hard to imagine a model like
3276.9|3.36|getting this you know here's a question
3278.7|4.139|and then the next token is correct
3280.26|3.96|that's pretty hard to solve in one step
3282.839|3.361|um but with Chain of Thought you can get
3284.22|3.899|like you know 50 accuracy on this just
3286.2|3.06|by having the model
3288.119|3.301|um output
3289.26|5.12|um these intermediate uh intermediate
3291.42|2.96|reducing steps
3311.0|4.2|definitely yeah yeah but like
3315.3|4.259|then there's this question of like what
3317.339|3.421|happens empirically right and like I
3319.559|3.321|understand that like it isn't
3320.76|4.62|necessarily a lot of space
3322.88|5.76|yeah so like
3325.38|3.26|um my question just like how
3329.059|4.3|uh tell the difference like maybe if
3331.92|3.179|they're like ways to tell the difference
3333.359|3.74|between like things that have on a merch
3335.099|4.381|because like there's just like no space
3337.099|4.841|or like
3339.48|4.859|um like like there's so many tasks that
3341.94|4.679|like it kind of like allotted any any
3344.339|4.801|space to specifically do that one versus
3346.619|4.561|like uh like the the task is so hard
3349.14|4.919|that like but
3351.18|6.24|it just can't even if you like it
3354.059|5.341|yeah capacity to try and do it yeah
3357.42|2.82|that's a good question I think
3359.4|2.939|um
3360.24|4.98|there seems to be like some subset of
3362.339|4.681|tasks where uh it's just like doesn't
3365.22|4.44|fit well with the way that we train
3367.02|4.799|language models so for example like in
3369.66|6.419|language models we use tokens right and
3371.819|6.54|so if you give it like the token four it
3376.079|4.02|actually doesn't take the number four it
3378.359|4.561|takes like this embedding that's like
3380.099|5.101|you know 1000 Dimensions or something or
3382.92|4.199|if you like give it a word and ask it to
3385.2|3.359|reverse like the letters this is like a
3387.119|3.061|super easy task but like the way we
3388.559|3.0|train the model doesn't actually look at
3390.18|3.12|the letters and stuff
3391.559|3.721|so I mean there's a certain subset of
3393.3|3.84|tasks where like
3395.28|4.559|um it doesn't really just fit well with
3397.14|5.28|the way that we train Transformers and
3399.839|3.901|um you can actually like I mean I think
3402.42|3.36|these if you really care about these
3403.74|4.379|tasks you can just solve them uh using
3405.78|4.5|like code or something like that
3408.119|4.98|um but yeah I I think uh I don't think
3410.28|4.14|like this is really an inherent um
3413.099|3.121|something that would never emerge
3414.42|4.1|because it's too hard
3416.22|2.3|um yeah
3426.78|2.94|um so the question someone asked is do
3428.22|3.54|you think China thought would be a
3429.72|4.5|viable interpretability technique for
3431.76|4.2|very Advanced AI systems and they
3434.22|3.66|mentioned that there's some research by
3435.96|4.34|tropical externalized reasoning
3437.88|5.34|oversight by camera
3440.3|5.44|oh will it be a viable interpretability
3443.22|4.26|technique for advanced AI
3445.74|3.839|um yeah am I supposed to repeat this
3447.48|3.359|yeah yeah sorry please oh so the
3449.579|1.861|question is
3450.839|3.141|um
3451.44|5.28|can chain if not be a viable
3453.98|4.839|interpretability technique for AI I
3456.72|4.2|think um there's no guarantee that like
3458.819|5.04|the Chain of Thought is how the model
3460.92|4.32|actually arrives at the final answer but
3463.859|2.881|often you can use it to like sort of
3465.24|3.9|debug like why isn't the model getting
3466.74|4.02|this question correct or like
3469.14|3.179|um what what can we do better in the
3470.76|2.94|Chain of Thought to help them all get
3472.319|3.0|this correct
3473.7|3.119|um I haven't read the anthropic paper
3475.319|4.081|that that was mentioned so I actually
3476.819|4.941|don't know the answer to that
3479.4|2.36|um okay
3483.54|6.0|um another uh interesting uh result that
3486.839|4.381|we had here was that uh you can actually
3489.54|2.94|do like multilingual Chain of Thought
3491.22|2.7|prompting
3492.48|4.139|um and so basically what we've had is
3493.92|4.32|like we translated this like uh you know
3496.619|3.24|benchmark of math report problems than
3498.24|3.359|10 languages
3499.859|4.441|um and then we prompt them uh the model
3501.599|4.441|to do it in like say Bengali and then
3504.3|3.779|the model has like basically do the math
3506.04|4.019|problem in Bengali
3508.079|3.24|um and give the final answer
3510.059|3.241|um I think the cool thing about this is
3511.319|3.961|that like this input is like highly
3513.3|5.34|improbable right so like Bengali is like
3515.28|4.799|0.01 of the pre-training data and uh you
3518.64|4.38|know math word problems are probably
3520.079|4.141|even smaller subset of that
3523.02|3.96|um and basically the interesting thing
3524.22|4.859|is the model can actually do like uh
3526.98|4.02|these types of questions pretty well uh
3529.079|3.361|to probably surprising degrees like you
3531.0|2.64|know if you ask people before I show
3532.44|2.159|them this result like oh how well can
3533.64|2.939|the model do you like these math
3534.599|4.5|questions in Swahili like oh probably
3536.579|4.861|like 10 but actually
3539.099|5.46|um even like you know very unrepresented
3541.44|5.58|languages like uh Swahili or Bengali or
3544.559|4.02|uh Telugu and and Thai
3547.02|3.059|um the model can do so like surprisingly
3548.579|4.081|well despite the fact that they only
3550.079|5.72|occupy like a very small uh subset of
3552.66|3.139|the the pre-trained data
3555.96|5.18|yeah
3558.359|2.781|most of my experience
3563.16|3.72|with nothing like explicitly training
3564.96|3.72|these languages right it seems to sort
3566.88|3.959|of like derive reasoning independent of
3568.68|3.36|language to some extent yeah you do the
3570.839|3.301|reasoning actually it's kind of funny
3572.04|3.42|like sometimes it always looks like it
3574.14|2.699|does the reasoning in English and it
3575.46|4.32|translates back to the other language
3576.839|4.561|because like answers it gives you a sort
3579.78|2.88|of like if you like reasoned in English
3581.4|3.899|and then translate to the other thing
3582.66|3.959|did you think that like uh learning the
3585.299|3.0|like structure of a language and
3586.619|3.061|learning reasoning abilities are like
3588.299|3.961|somewhat separate in large language
3589.68|4.2|models or that like even inherently will
3592.26|3.18|like learn shade of thought reasoning
3593.88|2.939|within that language within the
3595.44|3.98|structure of the language like the way
3596.819|4.8|thought Works in that language
3599.42|4.36|yeah that's a great question I'm not
3601.619|3.96|sure how to measure that but uh I've
3603.78|3.18|definitely thought about it I think the
3605.579|3.121|language I mean based on these results
3606.96|3.72|like you definitely Pro you probably
3608.7|3.96|didn't have any math questions in
3610.68|3.72|Swahili for the for the model to learn
3612.66|3.3|from and I think definitely there's
3614.4|3.659|something language agnostic going on
3615.96|4.139|where the model learns reasoning sort of
3618.059|3.361|independently of the language and then
3620.099|4.081|it can express it in different languages
3621.42|4.439|if it needs to yeah but I I don't have a
3624.18|4.76|I don't think anyone I don't think we
3625.859|3.081|know the answer yet yeah
3630.9|3.719|um
3631.74|5.28|yeah so so basically like one question
3634.619|5.041|that uh comes up frequently is like why
3637.02|4.14|does scaling up improve Chain of Thought
3639.66|3.0|um and one way of looking at this is
3641.16|4.199|like we can take a smaller model like
3642.66|5.04|pom62b and see like what types of errors
3645.359|4.5|are fixed from scaling up to 540 going
3647.7|3.78|parameters I mean you can see that like
3649.859|3.061|for for these three categories that we
3651.48|3.18|came up with
3652.92|3.48|um some of all of them get fixed so
3654.66|4.02|scaling seems to have this like sort of
3656.4|3.659|universal effect on improving uh
3658.68|3.74|different types of Errors from solid
3660.059|2.361|models
3663.78|3.539|um and then here's this the same hand
3665.339|4.321|wavy diagram and expressed in different
3667.319|3.661|ways so basically you have like some
3669.66|3.48|tasks that are doable with standard
3670.98|3.9|prompting so in blue
3673.14|3.9|um and then uh the the goal of
3674.88|4.439|channel.prompting is a sort of increase
3677.04|4.799|the sub the the set of tasks that we can
3679.319|4.921|do so for example now uh the ones shown
3681.839|4.74|in uh Pink include math word problems
3684.24|4.079|symbolic reasoning and com
3686.579|4.441|challenging Common Sense reasoning yeah
3688.319|6.121|one more question have you done any
3691.02|6.18|compilations to figure out how uh like
3694.44|4.26|much is any of this contribution just
3697.2|4.5|because of the fact that you do more
3698.7|5.399|complications when you put in longer
3701.7|4.44|prompts like uh you know like you put
3704.099|3.96|multiple passes through the model you
3706.14|3.719|create multiple embeddings for sort of
3708.059|3.901|like you know adjust the things the
3709.859|3.141|model is looking at in a way yeah how
3711.96|3.18|much would I like have you tried
3713.0|4.96|non-shade of thought prompts with like
3715.14|6.179|same token lengths yeah yeah we tried
3717.96|4.92|with like uh XXXX or something it
3721.319|3.421|doesn't really it doesn't work
3722.88|3.84|so I think it's not just about the
3724.74|4.319|compute I think it's about
3726.72|5.04|the language guiding the model uh as
3729.059|4.441|part of the reasoning yeah
3731.76|3.359|and describing the problem in more
3733.5|2.94|details or not being champion I know
3735.119|2.881|this is like a super range question I'm
3736.44|3.119|just very curious about like
3738.0|3.24|it's the interesting
3739.559|4.28|property and I'm very curious like
3741.24|2.599|exactly how
3744.42|4.439|yeah you mean like describing the
3745.92|4.08|question in three different ways
3748.859|3.0|more kill instead of like
3750.0|3.96|to do a step-by-step thing and seeing
3751.859|3.96|how that like yeah I haven't tried that
3753.96|4.099|but I would be uh surprised if that
3755.819|2.24|worked
3763.64|5.14|yeah that doesn't work as well okay yeah
3766.38|5.12|but it depends on the task also so like
3768.78|2.72|yeah yeah yeah
3775.38|3.56|um it that seems to be the case yeah
3778.98|2.0|yeah
3782.42|6.04|that's your calculation
3785.54|4.299|towards the answer like anyway you know
3788.46|3.72|like in a way like in a black population
3789.839|4.381|the chain of salt is like a very sort of
3792.18|3.72|structured thing it's like what if the
3794.22|5.3|same structure is bizarre but like we
3795.9|5.459|use some more random things
3799.52|3.22|yeah
3801.359|3.421|um you could try it I would be surprised
3802.74|4.02|if it works I I I I think like
3804.78|3.539|outputting tokens
3806.76|4.039|um is pretty important for the for the
3808.319|2.48|model yeah
3812.22|3.42|okay
3814.38|2.76|um
3815.64|4.5|so we're doing all the time okay great
3817.14|4.56|so uh the last part I think is a pretty
3820.14|3.179|cool trick with chain of thoughts so
3821.7|2.46|basically
3823.319|2.341|um
3824.16|3.72|what people usually do is they'll just
3825.66|3.419|generate one Chain of Thought
3827.88|3.12|um and then they'll take the final
3829.079|4.141|answer but there's this nice shirt
3831.0|3.78|called self-consistency where you can
3833.22|3.0|use like temperature sampling with the
3834.78|3.24|model to generate like a bunch of
3836.22|3.06|different uh reasoning pads and final
3838.02|2.64|answers
3839.28|3.66|um and then if you just take a majority
3840.66|3.84|vote over the final answers this ends up
3842.94|4.679|like improving performance by like a
3844.5|5.52|pretty big margin so uh for example here
3847.619|4.621|you can see on gsmak which is like the
3850.02|4.44|math word problem data set
3852.24|4.26|um the Improvement goes from like uh you
3854.46|4.44|know the performance like 56 and then if
3856.5|3.54|you do self-consistency then it becomes
3858.9|3.56|74 which is like a pretty big
3860.04|2.42|Improvement
3867.0|5.04|oh I think 40. so it increases the cost
3869.76|5.4|of the inference time compute
3872.04|5.539|um but uh yeah it improves performance
3875.16|2.419|by a lot
3882.48|3.859|change battery over yeah
3886.38|4.8|um I think uh it depends on the uh sorry
3889.38|4.14|the question is how many chains do you
3891.18|3.96|need to get a performance gain uh I
3893.52|3.299|think the um
3895.14|4.14|the answer really depends on the data
3896.819|5.841|set but usually you can get something
3899.28|3.38|good with like 16 I think
3903.299|3.241|oh sorry the other question how does the
3905.22|3.18|temperature change the way the model
3906.54|3.539|works
3908.4|2.64|okay uh the question is how does the
3910.079|4.52|temperature change the way the model
3911.04|7.319|Works basically when you use temperature
3914.599|5.74|decoding the language model can like
3918.359|3.601|stochastically pick one of the outputs
3920.339|4.141|instead of always picking the highest
3921.96|5.639|probability next word so basically you
3924.48|6.48|get these like more stochastic outputs
3927.599|5.041|that are still uh based on what the
3930.96|4.02|language model has learned but it's just
3932.64|4.939|a little bit more random
3934.98|2.599|okay
3938.339|3.24|um and then like finally like yeah
3939.799|3.76|self-consistency also seems to be
3941.579|3.421|emerging ability I guess part of it is
3943.559|3.601|because Chain of Thought is emergent
3945.0|4.92|because uh you wouldn't get you know any
3947.16|6.12|better than random performance
3949.92|5.939|um uh uh without uh doing Chain of
3953.28|4.68|Thought but um uh yeah you kind of see
3955.859|4.821|this big Delta from self-consistency for
3957.96|2.72|larger models
3962.579|2.881|um
3963.24|4.68|great so uh
3965.46|3.899|uh I'm gonna run out of time let me just
3967.92|2.879|go to uh
3969.359|2.821|I'll just talk about this a little bit
3970.799|4.32|so
3972.18|4.439|um I think uh in addition to just purely
3975.119|2.881|scaling up the language model which is
3976.619|3.781|only available to like people in
3978.0|4.799|Industry I think there's like a couple
3980.4|4.08|interesting directions to
3982.799|3.121|um to work on
3984.48|2.639|um one is like better prompting and
3985.92|3.179|characterization of wing
3987.119|4.68|responsibilities I think right now we're
3989.099|4.801|sort of just at the edge of uh you know
3991.799|4.081|knowing what the best way to prompt
3993.9|2.699|language models is
3995.88|2.219|um
3996.599|3.361|there's also like pretty good applied
3998.099|3.601|work so like uh you can use language
3999.96|3.599|models I've heard to train therapists
4001.7|4.08|Let's help with creative writing to help
4003.559|3.54|with science I think chat GPT has really
4005.78|3.12|shown
4007.099|3.661|um what language funnels can do in this
4008.9|4.5|regard
4010.76|4.74|um I think benchmarks are also something
4013.4|4.5|that's pretty lacking because I think uh
4015.5|4.14|we solved benchmarks pretty quickly
4017.9|3.959|um for example Palm beat the average
4019.64|3.56|human on big bench uh you know within a
4021.859|3.96|year or something a big bench coming out
4023.2|4.119|so I think we need more uh benchmarks
4025.819|3.48|and that's that's that I think that's
4027.319|4.081|going to be an important contribution
4029.299|4.981|and then the final one is like how can
4031.4|4.62|we like uh have compute efficient
4034.28|2.88|methods to to make language models
4036.02|4.26|better
4037.16|4.8|um so that uh you know it's it's less
4040.28|4.319|expensive to use them and more people
4041.96|7.139|get to use them
4044.599|6.661|um great so uh I'll end here
4049.099|3.901|um and feel free to email me if you have
4051.26|3.48|any any feedback and if you're
4053.0|6.859|interested in Google uh yeah feel free
4054.74|5.119|to meet as well awesome thanks thank you
4061.31|4.099|[Applause]