start_time|end_time|text
1.08|2.96| Alright, for the remaining two parts of this lecture, let's now
4.04|3.16| talk about the softmax regression learning rule. With
7.2|3.44| that, I mean, computing the gradient of the loss with
10.64|2.92| respect to the weights and the bias unit, so that we can then
13.56|3.44| use gradient descent or stochastic gradient descent to
17.16|3.76| train a softmax regression classifier. And once we cover
20.92|3.6| the big picture of how that works, we will then implement
24.52|4.64| that in code and see how it works, actually. So the concept
29.16|3.0| is actually the same as with Adeline and the logistic
32.16|2.8| regression classifier that we talked about before, because
34.96|3.6| they are also softmax regression is still a single layer neural
38.56|3.36| network. So what we have is or what we want first, what we
41.92|4.56| want is the partial derivative of the loss with respect to a
46.48|4.04| weight wi, or essentially, also, we can talk about the gradient
50.52|3.32| of the loss with respect to the weight vector, that's what we
53.84|3.44| ultimately want. But here, it's just easier to write it as a
57.28|3.48| partial derivative. And then here, we will also want to
60.76|3.4| compute the partial derivative of the loss with respect to the
64.16|3.96| bias unit. So when we have these partial derivatives, we can then
68.12|3.44| use stochastic gradient descent to update the weights. And it's
71.56|4.36| the same as we've done it with Adeline, linear regression and
75.92|5.2| logistic regression. So the same setup here, like I said applies,
81.12|8.12| we can use the chain rule to decompose this derivative into
89.24|3.68| individual terms. So we can compute the partial derivative
92.92|3.8| of the loss with respect to the activation, and then the partial
96.72|2.84| derivative of the activation with respect to the net input,
99.56|3.08| and then the partial derivative of the net input with respect to
102.84|6.68| weight wi. The only difference here is compared to the regular
109.52|7.8| logistic regression is that we now have the softmax activation.
120.36|5.44| And just for reference in Adeline, we had an identity
128.12|8.64| function as activation. And in the regular logistic regression,
136.76|7.92| what we had was the sigmoid, or let's say the logistic sigmoid
147.08|3.6| as activation. So the only thing that really changes is that we
150.68|3.96| have now a different activation function in softmax compared to
154.64|3.24| what we've done before. And then yeah, also equivalently, we can
157.92|3.36| compute the partial derivative of the loss with respect to the
161.28|5.04| bias, it's the same concept, really. So here's a sketch of
166.32|3.96| the computation graph of softmax regression. I always personally
170.28|3.52| find it easy to think of a model. If I look at the
173.84|3.08| computation graph, I mean, if you have a very large, big
176.92|2.96| model, of course, you don't want to write all the down all the
179.88|4.32| units. But a simplified version of the model, actually, I find
184.24|6.44| usually helps in practice. So here, notice that this is not a
190.68|3.8| multi layer neural network yet, we will talk about the multi
194.48|5.28| layer neural network in the next lecture. So it's still one layer,
199.8|4.16| and there is no hidden layer, it may look like it, because what I
203.96|4.56| did is I was drawing the net inputs as a intermediate step.
208.76|5.24| Usually, when you later look at drawings of multi layer neural
214.0|3.76| networks, the net input and activation function are combined
217.76|4.32| into one function or one node, actually. So in that way, I was
222.08|5.28| just writing those explicitly, if I wanted to illustrate a
227.36|2.96| multi layer neural network, for example, a multi layer perceptron
230.32|5.44| with one hidden layer, then I would have to add another, let's
235.76|7.92| say z two, and a two in between. So before the loss, basically,
243.68|4.56| there would be another layer. So yeah, so what I wanted to say is
248.24|4.68| here, we still only have one weight layer. So this is this
252.92|4.16| one here, there's no additional weight layer. In a multi layer
257.12|2.56| case, we will talk about that in the next lecture, we will have
259.68|4.72| another weight layer. So in here, this would be where we
264.4|3.12| apply the softmax activation. But notice that we don't have any
267.52|4.32| weights here, I was just drawing how it conceptually works. So
271.84|2.92| remember, from the softmax activation, what happens is that
274.76|5.04| each activation that comes out of it depends on all inputs, all
279.8|5.28| net inputs, because we have this normalization going on in softmax.
286.92|4.44| So yeah, then we can apply actually the multivariable chain
291.36|3.08| rule, or we have to apply the multivariable chain rule, because
295.48|2.68| let's consider the case where we want to compute the partial
298.16|5.32| derivative of the weight w one to this one here that I
303.48|7.92| that I highlighted. So if you look at it, so what's involved
311.4|7.0| here is x two, this one goes into z one, z one goes into a
318.4|5.36| one via the softmax. And then it goes to the loss, but you can
323.76|4.92| also see it's connected to a two because it's also involved in
328.68|4.84| the computing all the terms in the softmax. So there are
333.72|3.52| multiple things now all the blue ones that I circled that are
337.24|4.36| involved in the partial derivative of the loss with
341.6|6.64| respect to w one, two. Alright, so for that, because there are
348.24|5.12| no two parts, this a one and this a two, we have to use the
353.36|3.96| multivariable chain rule. So for this upper part here, that's
357.32|2.92| what I have here on the left hand side. And for this lower
360.24|2.72| part, this is what I have here on the right hand side. It's
363.0|3.56| essentially the same concept, we compute the partial derivative
366.56|3.88| of the loss with respect to the weight. For the left part, it's
370.72|2.76| we can decompose it into the partial derivative of the loss
373.48|3.4| with respect to a one, a one with respect to z one and z one
377.1|3.1| with respect to w one, two, on the right hand side, the only
380.2|5.08| difference is here that instead of a one, I have a two now,
385.28|3.24| right, because that's what it's this path. So on the right hand
388.52|6.0| side, I'm we are looking really at this path. And on the left
394.52|6.68| hand side, we look at this path. Alright, so the derivatives, I
401.2|2.68| was just writing them out here, I can actually walk you through
403.88|3.24| this, I sketched it out in the next couple of slides, it
407.12|4.32| actually took some time to type this in LaTeX, but then we will
411.44|4.36| then we will have it for reference. So here, we have
415.8|4.52| these three terms, the partial derivative of the loss with
420.32|2.2| respect to the activation, notice, it's essentially the
422.52|4.92| same, except that we have here, index one, and here, index two.
427.96|2.12| And here, this is the partial derivative of the softmax
430.08|5.0| function with respect to the net input z one. And this is the
435.28|2.04| partial derivative of the softmax function with respect
437.32|4.76| to also z one, but now we have the unit a two here and here,
442.08|5.08| then unit a one. Right, so maybe let's go through this in the
447.16|4.56| next couple of slides, I've sketched this out. Yeah, let's
451.72|3.24| start from the left hand side. So what we have is the partial
454.96|4.2| derivative of the loss with respect to a one. So the loss,
459.32|3.98| if you recall, that's the multi category cross entropy, yet for
463.3|4.9| just one training example, so I'm omitting the outer sum. So
468.2|5.12| we are just looking at the sum over the class labels, class
473.32|0.68| labels,
477.36|6.36| j equals one to h. And yeah, this is just the multi category
483.72|4.96| cross entropy loss. And notice now that, yeah, there's a sum
488.68|6.0| over the labels, the true labels, yj and aj. And if I just
494.68|4.0| look at the partial derivative of a with respect to one, all
498.68|4.3| these terms will be zero, right, because then these will be
502.98|3.78| constants, they will be all constants, except for the case,
506.76|3.6| of course, where we have a one. So what I can do is I can just
510.38|4.66| drop the sum, right. So and this can be then a one, right. And
515.04|3.92| yeah, what is the derivative then of, let's say, if we have
518.96|4.24| something like log x, the derivative of this one would be
523.24|6.0| one over x, right. So in the same way, if I take the partial
529.24|4.2| derivative of this whole term here, this one is a scaling
534.08|2.64| value here. And then this one, the derivative of this part is
536.72|7.5| one over a one. So my derivative of this term is y one over a
544.22|3.54| one. And similarly, I could do the same thing for this part
547.76|5.34| here. For this part, it would be the same thing, except that we
553.1|4.02| have no index two, because I mean, if you look at the left
557.12|3.32| hand side, this would be the same. And what remains is
560.44|3.44| really only the part with the index two, we can also cancel
563.88|3.68| the sum. So this is how we get this partial derivative. And I
567.56|3.44| should also say, this is the last time I will really torture
571.0|4.12| you with this one, because the upcoming lectures next week,
575.12|2.88| when we talk about the multi layer perception, we don't want
578.0|2.64| to walk through this every time, because it's really just the
580.64|3.24| same concept. So this is really the last time I'm doing it in
583.88|5.12| detail. Later in this course, we will move at a faster pace and
589.0|3.24| omit these types of details, because this is I think, really
593.4|3.08| good to understand once, but we don't have to do it every time
596.48|2.64| because there are more interesting things to cover,
599.12|4.42| like multi layer perception, finding good learning rates,
603.54|3.14| optimizers, and convolution networks and recurrent networks
606.68|3.4| and so forth. So yeah, so if this is boring, it will be over
610.08|2.44| in five minutes, and then we will move on to more exciting
612.52|0.52| parts.
614.6|5.36| Yeah, now the second part. So this is slightly more involved,
619.96|3.84| but also not that complicated. So let's look at the partial
623.8|7.52| derivative of the softmax unit a one with respect to z one. So
631.48|3.48| yeah, just spelling it out. So this is again, our softmax
634.96|3.48| activation. So here, we are looking at the softmax
638.48|5.0| activation for z, z one, and remember that we are summing
643.52|6.36| over all the other units here for normalization. So for that,
649.88|5.5| we have now a quotient. So we have to use the quotient rule.
655.88|4.06| So I've added it here for reference. So in that way, it's
659.94|2.72| easy, or I find it easy to think of this as
664.38|2.66| fx. And this one is
668.58|5.48| gx. And then we can apply this rule here. So we delete this
674.06|3.42| again, because otherwise, it's too crowded here. Maybe it's
677.48|6.74| fine. It's just f and this is g. So what we have is g times f
684.22|7.28| prime. So essentially bringing this one here, and then f prime
692.54|5.32| is this part. And then on the left, on the right hand side, we
697.86|6.56| do f. So this part times the derivative of this part g prime,
704.42|5.64| and then divide it by g squared here. Alright, so if we look at
710.06|3.72| this, um, now we can simplify certain things, right? So if we
713.78|4.68| look at this, we have here the partial derivative of the
718.5|5.6| exponential term with respect to z one. So this just cancels
724.1|2.4| right, because the partial derivative of or the derivative
726.5|3.08| of e to the power of something is e to the power of something.
729.82|3.48| So this simplifies on the right hand side, same as on the
733.3|2.96| previous slide, we have a partial derivative with respect
736.26|3.72| to z one, we have this sum here, but we can cancel the sum,
739.98|5.0| because all the other terms will be zeros, because except for z
744.98|3.96| one, we can treat them as constants. So this goes away. So
748.94|5.12| if we cancel this sum, and we cancel this one, what remains is
754.14|4.8| this very simple term now. So with that, we can now factorize
758.94|4.56| this, because note that we have a e to the power of z one here, and here
763.5|4.62| too, so we can bring that outside here. So we just move
768.12|6.18| that outside. And then if we look at this, so we can take the
774.3|5.92| left part, so we can, um, can I say that, so we can take this
780.22|4.2| part without the square, this is actually again, this is our
784.42|10.56| softmax for easy one. Right, so this is what I have written here
794.98|2.56| on the left hand side. And then what remains on the right hand
797.54|4.96| side is this term. And now if I divide this term by what I have
802.5|4.08| here in the square brackets, if I divide it by the sum of over
806.74|5.4| easy j, then this one will become one, this one will become
812.14|4.76| one. And this has been the division by this on some term,
817.5|5.92| right, so which is essentially one minus the activation one. So
823.5|3.8| this is a one, and this will be one minus a one. And then if I
827.3|2.64| put them together, I end up with this term. So it's actually not
829.94|4.48| that complicated. We can also do the same thing then, for this
834.44|5.86| second term here on the right hand side. So again, the same
840.3|2.96| concept applies, it's still a quotient. The only difference is
843.26|5.96| now that we have easy one here, and easy to hear, because we are
849.22|3.56| looking at a two. But yeah, we can do the same thing using the
852.78|3.48| quotient rule. So I don't want to have to walk through this, I
856.26|7.38| think. But you notice here, that this term will be zero, because
863.64|3.42| we are looking at the partial derivative of z one with respect
867.06|3.3| to sorry, of the partial derivative of this term with
870.36|3.52| respect to z one. But since we have easy to hear, this is
873.88|3.36| actually a constant. So this whole thing becomes zero, and
877.24|4.22| zero times this one will also still be zero. So this simplifies
881.46|3.48| here a lot. And on the right hand side, because we are
884.94|4.0| looking at z one, part of derivative with respect to z
888.94|6.16| one, this one simplifies the partial derivative simplifies to
895.1|7.04| easy one. And we have easy two times easy one. So this way, we
902.14|4.8| have this as the second activation, and this as the first
906.98|4.04| activation. So in that way, we also have a very simple
911.06|3.88| derivative. Yeah. And so lastly, the last term is the partial
914.94|3.64| derivative of the net input with respect to one of the weights,
918.7|3.82| w one two. And yeah, I think you have seen that many, many times
922.52|3.26| in the context of add a line and logistic regression. So I don't
925.78|4.0| have to tell you how we get to the yet derivative of x two in
929.78|3.52| this case. Alright, so but now we have all three parts, right?
933.3|5.8| So we have this part, this part, and this part, and also the same
939.1|3.52| thing on the right hand side. So we can actually put all things
942.62|5.82| together. So this part, let me just show this in different
948.44|9.34| colors. And this part, and then the same thing on the right hand
957.78|3.68| side. So we can put them all together. And if you walk through
961.46|4.32| this little thing here, I did, you will see that this actually
965.78|2.96| simplifies to a very, very simple learning rule. So if we
968.74|3.64| put everything together, we have a very simple learning rule,
972.38|7.92| which is this label for class one, minus a one times x two.
980.94|4.96| And this is something you may, yeah, remember from end of line
985.9|4.04| or logistic regression, it's exactly the same learning rule,
990.06|3.92| except now, so the differences in logistic regression, we just
994.02|4.32| brought it as follows, we didn't have an index, right, because we
998.34|3.56| didn't have multiple units, and we didn't have a one hot
1001.9|3.72| encoding. In this case, we have these different units. But
1006.06|3.24| except that it's exactly the same learning rule, it's a super
1009.5|3.92| simple learning rule. And it is also showing that softmax
1013.42|3.84| regression, or the softmax activation works very well with
1017.5|5.0| the cross entropy loss. Later, we will also take a look at
1022.5|3.16| multi layer perceptrons. And you could actually combine softmax
1025.66|3.76| regression, sorry, softmax activation with a mean squared
1029.42|4.6| error loss. It's totally fine to do that. But the derivative will
1034.02|3.96| not be so nice that these terms cancel. So this is actually, I
1037.98|4.0| think a very nice combination. Because if we have such a simple
1042.22|3.64| partial derivative term, it's easy to implement in code. And
1045.86|3.72| it's numerically also more stable compared to longer
1050.22|4.24| equations. Yeah, and lastly, we can also write this more
1054.46|4.28| compactly using linear algebra. So on the left hand side is what
1058.74|2.88| I have showed you on the previous slide. So we can
1061.66|3.44| implement this learning rule instead of writing it as a
1065.1|2.96| partial derivative with respect to one of the weights, we can
1068.06|3.66| write this compactly as the gradient of the loss with
1071.72|4.82| respect to the weight. And we can write this as shown here,
1076.82|5.44| where this is a capital W. So this is relief with respect to
1082.26|3.66| all the weights. And we can write this with the design
1085.92|3.62| matrix here, the one hot encoded matrix. So the design matrix is
1089.54|4.04| an n times m matrix. Note that we use a transpose though. So
1093.58|4.22| it's m times n. And here this one, this would be the one hot
1097.8|4.5| encoded matrix, which is n times h, where h is our number of
1102.3|4.88| class labels. So in this case, h equals two, and a has the same
1107.46|5.36| dimension as y. So it's also n times h. Um, yeah, why does this
1112.82|3.42| true? It's a little bit maybe not so obvious to see. So I
1116.24|2.98| recommend maybe sketching this out if this is confusing. But
1119.22|3.52| also in practice, how I would implement something like that is
1122.78|4.6| I would go in my code, implement this one here with very simple,
1127.5|3.92| let's say Python for loops, make sure that it works and then
1131.58|3.88| translate the for loops into dot products and matrix
1135.46|2.94| multiplications. So this is really more complicated. Also, I
1138.4|3.34| find this sometimes really hard to do in practice. And this is
1141.74|4.84| also why I kind of admire people who did research in the 1980s
1146.58|3.88| and 1990s before, or maybe even the 2000s before there were
1150.46|3.2| tools like pytorch, before we could compute these gradients
1153.66|3.56| automatically. So it's actually not so easy to do, I mean, to
1157.26|3.24| implement this efficiently. So I have actually great respect for
1160.5|3.04| everyone who did that by hand back in the day. But yeah,
1163.54|3.88| nowadays, we do this all automatically. So we will
1167.42|4.12| actually see that this what I showed you actually works if I
1171.54|2.94| implemented in code, but then also show you that it gives the
1174.48|28.02| same results as pytorch, autograd API.