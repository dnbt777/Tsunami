start_time|end_time|text
0.92|2.84| Alright, so at the end of the previous video, I promised you
3.76|3.32| to show you Alex net now. But before we do that, let me show
7.08|3.12| you one more thing how we save and load models. And then in the
10.2|4.56| next video, I will show you Alex net. So I explained to you how
14.76|2.28| that works in an earlier lecture. But yeah, it's really
17.04|3.2| good to just recap that because I think it might be very useful
20.24|5.52| for your class projects. So here, I have a subfolder, I just
25.76|2.94| called it safe and Lord. So all of that is on GitHub, I will add
28.7|5.02| the links. So this safe and Lord subfolder, and let's do the
33.74|3.66| Alex net first with only training it for like one or two
37.4|5.56| epochs. So here, I'm showing you how we can save a model. So same
42.96|4.88| thing as before. Notice that I'm having now this path dot insert
47.88|4.28| dot dot. That's because all my helper files are one level
52.2|3.2| higher than this folder where I'm executing this notebook. So
55.4|2.12| it's basically going back one folder, and this is where my
57.52|2.56| helper files is. So this is essentially just adding this
60.08|4.16| path, so that Python knows where to find these helper files. Of
64.24|2.88| course, you can also make this a Python a Python package and
67.12|5.2| then import this as a package by different by a setup file,
72.32|3.72| maybe even, but this might be overkill here. So here, for
76.04|3.44| experimental purposes, it's just sufficient to just add the path
79.48|4.88| and it will find this and run this or import everything. So
84.36|4.04| everything here is the same as before. So now let's train only
88.4|5.92| for three epochs or something to and it's all the same stuff. So
94.32|3.96| I don't have to explain all of that again. So this is
98.28|5.6| essentially not training for two epochs instead of five. So let's
103.92|2.4| briefly wait until this finishes, it shouldn't take that
106.32|16.16| long, maybe a minute or something. Half a minute. All
122.48|3.36| right. So here, maybe we might think, okay, it might be good to
125.84|4.32| train a bit longer. So actually, I also added an another. So I
130.16|4.56| have this show example function. So here, everything looks
134.72|4.56| correct, all looks fine. But I also added another functional
139.32|4.64| confusion matrix, students who took 451 last semester may know
143.96|3.48| what the confusion matrix is. But yeah, essentially, for those
147.44|2.52| who are not familiar with that, it's essentially a matrix
149.96|4.84| showing the predicted labels versus the true labels. So how
154.8|6.08| many, let's say how many nines were predicted as zero, right?
160.88|4.56| So you can see where the model makes the most mistakes, what
165.44|4.44| you want is you want the highest number here in the diagonal, you
169.88|3.68| can see, for instance, the model mistakes, a lot of the nines as
173.56|6.4| a five, or mistakes, a lot of can we see here, twos as seven,
180.16|2.44| I mean, they are quite similar, right? A two and a seven are not
182.6|3.04| that different. So it's kind of interesting to look at that and
185.64|3.8| see where the model makes the most mistakes. But this is just
189.44|3.28| as a side note. So the main part I wanted to talk about is the
192.76|4.6| model saving here. So here, what we do is we save the model
197.8|3.68| parameters, that's the state dict. So take a dictionary
201.48|2.92| consisting of the state or the weights and everything, all the
204.4|5.92| parameters, and we are saving it to file called model dot PT. So
210.32|4.72| PT just for pytorch, but you can choose any name that you prefer,
215.04|5.28| you can also spell it out, like pytorch, oops, doesn't really
220.32|5.88| matter. Okay, and then let's do that. So then it will all but we
226.2|5.68| also do is we save the optimizer state because we use on s SGD
231.88|4.16| with momentum. So there's also a momentum state that we save, if
236.04|3.0| we want to continue using that optimizer. And we also have the
239.04|3.92| scheduler. So we also say the scheduler state, I mean, you
242.96|3.12| don't have to do that. You can start from scratch with a new
246.08|2.88| optimizer and scheduler. But if we really wanted to just
248.96|3.12| continue training, like if the run here got interrupted, for
252.08|3.76| example, then this would be the proper way to do it in ways that
255.84|3.84| we save all of them and then load all of these states. So now
260.48|7.92| we have these here in this safe and load folder. And can we see
268.4|3.8| this? I'm not sure we can see that the file size is also quite
272.2|2.48| it's also quite interesting. Sometimes these are pretty large
274.68|5.2| the model because there are lots of weights. Anyways. Now, assume
279.88|3.72| we have saved the model. Let's now load the model. So you have
283.6|3.4| a prepared another notebook. Actually, it's all the same
287.0|4.0| stuff. So everything is the same. It's kind of required
291.04|5.56| because what we do is we first have to initialize the model. So
296.6|3.84| that is what creates the class. And then once we have initialized
300.44|3.12| it, this is really only the new part. That's how we load the
303.56|4.64| model. So now we have torch law load, and then the model dot pt
308.2|3.08| file, the same thing for the optimizer and scheduler. And then
311.28|3.0| we are loading this state dict here into the model. But
314.28|2.84| notice that we have to initialize the model. As before,
317.14|3.5| that's the same thing as before, but we have to do that. Because
320.64|3.44| otherwise, it wouldn't know where yet where to put the
324.08|4.0| parameters, right? So okay, if we've done that, we can then
328.08|3.84| train the model further here for 10 epochs, it might take quite
331.92|3.96| a while. But yeah, we would then continue training that model. So
335.88|4.44| that's how you save and load models. Next in the next video.
340.32|17.88| Next in the next video. Now let's get finally to the Alex net.