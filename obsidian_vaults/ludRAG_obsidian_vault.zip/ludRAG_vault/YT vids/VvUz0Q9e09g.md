start_time|end_time|text
0.16|3.54| Yeah, so in this video, let me briefly go over the basic
3.72|4.92| concept of automatic differentiation in pytorch. And
8.64|2.04| then in the next video, we will take a look at a more
10.68|3.76| comprehensive example, training and align the adaptive linear
14.44|4.2| neuron using the other automatic differentiation concepts in
18.64|4.96| pytorch. So here, I just want to show you the computation graph
23.6|2.2| that we talked about in the previous videos in the context
25.8|4.66| of pytorch. So here in this notebook, I should also say, or
30.46|3.62| you can find it here on GitHub, I will upload it to GitHub after
34.16|3.44| you have finished recording. And I will also add a link to canvas
37.6|3.44| so you can't miss it. In case you want to play around with it.
41.4|5.12| So yeah, let me clear the outputs and then execute it one
46.52|3.8| by one. Of course, starting with watermark to see what versions
50.32|2.88| I have, you can also run this with a newer older version, it
53.2|6.0| should work the same way. So yeah, here, I'm imparting now the
59.2|5.2| autograd API, which is the automatic differentiation API.
64.72|4.12| So autograd, you can think of it as automatic gradient. Later on,
68.84|3.02| when we train deeper neural networks, we don't have to use
71.86|4.22| autograd explicitly. So there are functions that in pytorch
76.08|2.52| that we define like layers, convolution layers and the
78.6|3.72| backward function that will use autograd under the hood. But I
82.32|3.08| think it's useful to understand how autograd works, because you
85.4|4.32| may also want to use this in some other contexts. Alright, so
89.72|3.6| let's import these. And here's the computation graph that we
93.32|3.18| talked about in the previous video, same thing, so I don't
96.5|3.7| have to go over this again, I think. So here, I'm defining
100.2|3.84| this computation graph in pytorch. So I have my input
104.36|7.08| vector, or tensor x, a weight, w, bias B, and the activation,
111.44|4.2| that's the relu function. So I could have also used these
115.64|2.2| intermediate variables, but I think it would be a little bit
117.84|4.4| overkill, we don't really need to do that. Um, then then
122.24|4.16| now there's a attribute here, or a value that I said requires
126.68|4.84| grad equals to true. Why am I doing that? That means I am
131.52|3.52| interested in computing the gradient or derivative here. If
135.04|4.92| I don't do that, by default, it will be if I don't do that, it
139.96|5.04| will be equal to false if I don't do anything. So it's
145.0|2.68| actually a good decision by pytorch, because not always when
147.68|2.28| we use pytorch, we are interested in computing
149.96|4.52| gradients. And now when I run this code here, we can't see it
154.48|3.28| here. But under the hood, it will actually create a
157.76|3.68| computation graph similar to this one and save it internally.
161.68|3.28| And of course, this takes up memory in the computer. So if we
164.96|4.08| don't need a computation graph, it doesn't create it. But we can
169.04|2.96| say we want it because when we want to compute gradients, we
172.0|3.64| need that because we need to know how we can go backward. So
175.64|4.52| in this case, we set requires gradient equals to true. This
180.16|5.04| means we will later on compute the gradient. So please construct
185.2|4.44| this computation graph. So you can just say I see that the
189.64|4.8| result is indeed the one that we have here in the figure. Now,
194.44|4.6| um, yeah, we are computing the gradient here. So using this
199.04|4.08| grad function here. So if I go up again, this is something I
203.12|5.0| imported here from the autograd API. So I'm importing this grad
208.12|4.36| function. And now I'm computing the gradient of a with respect
212.48|7.04| to W. I'm also saying retain the graph, the computation graph, I
219.52|4.0| say, do it like set it to true. So it will retain it. Let's do
223.52|3.68| this. So this computes the gradient of all the partial
227.2|4.04| derivative of a with respect to W. The reason why it's gradient
231.24|3.28| and not partial derivative is it's usually working, of course,
234.52|3.96| with, um, yeah, vectors and matrices. And this is a very
238.48|2.68| simple example. In this case, we only have scalars. But this is
241.16|2.28| a general function that works also, yeah, with vectors and
243.44|5.52| matrices. So yeah, the partial derivative here is three. So
248.96|4.4| that's what we also got here, if you recall. So everything makes
253.36|4.96| sense and looks good. So now I'm doing this, um, again, for the
258.32|4.48| bias unit here. So I get my derivative of one. So also just
262.8|2.76| to double check, this is also what we have here. So everything
265.56|5.08| makes sense. So notice now I didn't set or retain graph to
270.64|3.52| true. So I didn't do it. And if it's not set, then it will
274.44|4.36| actually destroy the computation graph after calling grad. So
278.8|2.84| why is that usually in the context of a deep neural
281.64|3.8| network, we don't need the graph again, until the next forward
285.44|4.24| path pass. And since it's a dynamic framework, the forward
289.72|3.8| path pass might change. So actually, the graph is
293.52|3.4| constructed every time from scratch. But this is not a
296.92|3.56| detail we need to be concerned with right now. What I mentioned
300.48|3.24| or what I wanted to show you here is if I now execute this
303.72|4.24| again, it won't work, because we have destroyed the computation
307.96|4.8| graph, it says, or it basically tells us why this error occurs,
312.76|3.28| is this because we haven't retained the graph, so we can't
316.04|3.2| do it twice? Why is that done? It's usually yet to save also
319.24|4.08| memory, because imagine, you wouldn't do that. And you have
323.32|3.84| a deep neural network. And you call the forward method multiple
327.16|3.2| times, then in each epoch, or in each iteration, the graph
330.36|2.32| would be bigger and bigger and bigger and bigger and bigger.
332.84|3.36| So in this case, it's getting destroyed after each update, or
336.2|3.44| after each grading computation, and then rebuild from scratch to
339.64|4.72| prevent having it growing infinitely large. Okay, so but
344.36|4.24| this was just a basic concept of how this works. I will show you
349.0|4.32| in a later video next video, how this is done automatically by a
353.32|3.52| pytorch using the backward function. But it's still good to
356.84|3.04| understand, like these basic concepts, because that's, yeah,
359.88|2.72| it's just from a also scientific point of view, just
362.6|2.56| interesting to understand what's going on under the hood in
365.16|7.36| pytorch. Alright, so here, um, also, we can compute derivatives
372.52|3.6| of arbitrary functions. So if we implement them ourselves, so here
376.12|4.56| have an if and else. Also, this would work. We don't have to
380.76|2.32| define our own riddle function, because there is already a
383.08|4.0| riddle function and pytorch. So I actually skipped over this.
387.4|5.92| But notice, I also imported here, torch dot function, and
393.32|4.24| n dot functional. So I will explain this later on in a later
397.56|5.04| video this today. So this is an N is a neural network sub library
402.6|2.48| that contains a lot of convenience functions for neural
405.08|4.16| networks. And functional is the functional API, I will also go
409.24|3.04| over more details about that. Here, I'm just using the
412.28|4.32| shortcut F, because otherwise, it would be much more to type. So
416.68|4.96| pytorch developers me included lazy, so we use F as a shortcut
421.64|4.88| for an n dot functional. And here's the relu function I use
426.52|4.64| from this functional sub API. However, if I wanted to, I can
431.16|3.52| also implement the relu function myself, it's quite simple. But
434.68|3.2| if there's already an existing function pytorch, I actually
437.88|2.0| recommend using that one, because it's usually more
439.88|2.56| efficient than our own implementation. But here, that's
442.44|4.64| just to show you that we could equally implemented ourselves.
447.08|5.12| And this would also work. Alright, so what I'm showing you
452.2|3.04| here is that even if it's an if and else, like these pytorch
455.24|6.72| Python statements, it can also correctly deal with those. And
461.96|4.64| also, in case we have something where it's not defined, the
466.6|2.4| gradient is not defined, it will also be automatically able to
469.0|3.52| do something reasonable. So for example, here, this has the case
472.52|5.12| the case where the input is minus one, w is one, so we have
477.72|4.56| minus one times one is minus one, plus the bias is zero. So
482.28|3.6| the gradient of that one, or the partial derivative of the
485.88|4.08| relu with respect to the input should be zero, right? Actually,
489.96|2.8| it should be not defined. But like we said earlier, in the
492.76|4.0| lecture, we use the trick, so it can be adjusted to zero. And
496.76|4.16| let's see if it is also doing it. Yep, so it's working here. So
500.92|3.2| it's doing something reasonable, it is not crashing here, right?
504.12|4.72| So if I show you my slides, again, we said that earlier,
508.84|4.48| some time ago here, where the derivative is not defined, but
513.32|2.48| it would do something reasonable. So in that case,
515.8|2.4| pytorch is also doing something reasonable, it's not crashing.
518.52|3.68| And it works. So yeah, this was briefly how the automatic
522.24|4.28| differentiation works in pytorch using this grad function, and
526.52|2.48| really what it is doing, it's going on constructing a
529.0|4.4| computation graph under the hood, and then is it's going to
533.4|3.52| compute the derivatives for us. And in the next video, I will
536.92|4.4| show you how we can do that for model training for training
541.32|19.92| guideline.