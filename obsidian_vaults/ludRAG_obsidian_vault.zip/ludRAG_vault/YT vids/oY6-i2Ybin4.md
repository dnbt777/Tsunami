start_time|end_time|text
1.88|3.1| Yeah, in order to understand automatic differentiation, I
4.98|4.02| think it's helpful to take a look at computation graphs. So
9.0|4.32| computation graphs are a graph of a computation or calculation
13.72|4.24| that we define or execute in pytorch. So in pytorch, in
17.96|3.04| particular, when we implement new network models, there will
21.0|6.84| be two methods, one is the forward method, and one is the
30.36|4.48| backward method. So in the forward method, this one
34.88|7.2| constructs the graph, and then backward essentially computes
45.36|5.4| gradients by walking backward. So forward graph is constructing
50.76|3.28| a graph, if we have a graph with multiple inputs, some
54.04|2.84| computations, this is like the forward method, and then the
56.88|4.92| backward method, based on the output, we compute the
61.84|4.8| derivatives of the output or the loss with respect to these
66.64|3.36| inputs, for example, the weights that we want to update. So in
70.0|2.92| this lecture, I want to in this video, I want to briefly go
72.92|3.5| over, yeah, what such a computation graph is, and how we
76.42|4.5| work with it conceptually, before we see how pytorch handles
80.92|5.2| that. So yeah, in the context of deep learning, and pytorch, it
86.12|3.32| is helpful to think about neural networks as computation graphs,
89.48|2.48| because neural networks are really just a chain of
92.12|5.16| computations like nested computations. Yeah, so that we
97.28|3.86| have a concrete example, let's take a look at a activation
101.14|3.82| function that is not a linear activation function. So if you
104.96|5.76| recall the Adeline model, what we had is what we had was a
110.72|5.44| computation that computed the net input, which was then passed
116.16|4.76| on to a threshold function. So the net input is considered one
120.92|5.88| weight, one feature was computed as follows. And then we had an
126.8|3.84| Adeline, this activation function, which was just an
130.64|7.8| identity function. So this one was just an identity function.
139.2|3.96| And now we are taking a look at a function where the sigma is
143.16|3.48| not an identity function. So we are now taking a look at to make
146.64|3.88| it a little bit more interesting at this relu function. So in
150.52|5.76| this case, now what we have is the sigma is the activation
156.28|4.28| function is this relu function that I have written down here.
160.8|2.76| So the relu function in the context of a neural network
163.8|6.2| usually takes also the net input. So this is our net input,
170.02|4.22| you can think of it as the net input. And we will revisit the
174.32|4.0| relu function also in a later lecture and also talk about why
178.32|3.48| it is so commonly used in deep learning. So for right now, just
181.8|4.08| think of it as an activation function that is almost like a
185.88|3.4| linear function, but not quite. So the shape of this function is
189.28|3.6| as follows. So on the in the plot, I'm showing you how it
192.88|4.2| looks like for different inputs. So here, we have the input to
197.08|4.08| the function, for example, the net input z. And here, we have
201.16|5.4| the output on the y axis. And the relu function is defined as
207.16|5.64| almost like the identity function. So it returns z, the
212.8|5.88| input, if z is greater than zero and zero otherwise, so it really
218.68|12.08| is this region, an identity function. And here, not it's not
230.76|3.88| doing anything on the left hand side. So it's, it's clipped, you
234.64|5.4| can think of it as a clipping here. So why is that useful in
240.04|2.48| the context of deep learning? We will talk about this more, but
242.52|3.36| this is essentially yet to have a non linearity in the
245.92|2.88| multilayer network. Because if we have multiple linear
248.8|2.96| function, regular linear functions, the combination of
251.76|3.44| linear functions is also a linear function. So in a sense,
255.24|3.24| our network won't be able to approximate nonlinear
258.48|4.56| functions. But yeah, that would be going a little bit too far
263.04|2.96| ahead, we will talk about this more in detail here, we just
266.0|6.6| care about the computation. So also note for this relu function,
272.6|3.16| this one would be not differentiable in a mathematical
275.76|3.8| sense. Yeah, just to briefly redraw the relu function here
279.56|3.84| for reference. So how it looks like is that it is zero, if the
283.4|3.8| input is smaller than zero, and the identity function of the
287.2|4.6| input is larger than zero. So here, we have this little kink
291.96|3.44| at zero. And now for the left hand side, because there is no
295.4|4.68| slope, right, we can immediately see the derivative of this
300.08|3.48| function is zero. On the right hand side, it's an identity
303.56|6.72| function. So if the function is this, then the derivative of this
310.28|4.68| function would be one, right? So slope one. So on the right hand
314.96|2.36| side, we have a slope of one on the left hand side, we have a
317.32|3.4| slope of zero. But here at this kink, we have a problem. Now, if
320.72|2.8| you recall from calculus classes, this would be a
323.52|3.36| function that is not differentiable. So in this case,
326.88|3.56| we have a derivative of zero, if the input is smaller than zero,
330.8|4.16| the derivative of one of the input is larger than zero. But
334.96|3.24| otherwise, if the input is exactly zero, then the
338.2|4.0| derivative does not exist. So yeah, what do we do now? So in
342.2|2.24| computer science, or in the computational context, we are
344.44|4.68| not that picky, we just make a small adjustment. So we adjust
349.12|5.72| the derivative as follows, that it is zero, if z is smaller or
354.84|4.2| equal to zero. So that's just adding this smaller equal to
359.04|3.76| here to fix this issue. And otherwise, sorry, this should
362.8|4.16| be actually a one, it's one if z is greater than zero, notice
366.96|2.52| that we could have also otherwise written it the other
369.48|6.72| way around, we could also write it as smaller and sorry, larger
376.2|4.44| or equal. It doesn't really matter. Because it's so rare
380.64|3.12| that we hit exactly zero anyways, that this will probably
383.76|3.16| never happen in practice anyways. Because yeah, usually
386.92|4.72| we work with floating point numbers like lots of digits of
391.88|2.88| the decimal point. So it's very rare to hit an exact zero
394.76|4.26| anyways. So even though it's not differentiable, in a mathematical
399.02|2.62| sense, we make in the computational sense, this little
401.64|4.44| adjustment and define the derivatives as follows. Okay,
406.08|3.44| but yeah, let's move on to the computation graph. Just to
409.52|2.96| summarize, now we have the following activation function,
412.52|5.4| just just a summary. It's a multivariable function. Where we
417.92|5.04| have three inputs, we have the features. So here, we only have
422.96|3.88| one feature for simplicity. So let me actually annotate it
426.84|4.6| here, one feature, one training example for simplicity, we have
431.44|3.8| the bias unit, and the weight parameter. Also, for simplicity,
435.24|2.8| only one weight parameter corresponding to the one
438.68|4.36| training examples feature. So as you recall, we usually come
443.2|4.08| calculate the net input, for example, in airline, and then we
447.28|2.72| would pass it to an activation function. In this case, we use
450.0|4.52| this relu function. So right now, we don't even have to think
454.52|4.0| about your networks, if you don't want to here, you can just
458.52|2.76| think of it as a simple computation that we want to
461.28|4.2| represent using a computation graph. So how would we do that?
467.6|4.08| So here would be a computation graph of this function. So I
471.68|2.84| use some intermediate variables to make this a little bit easier
474.52|4.72| to read. So we define this computation as you, and we
479.24|5.24| compute define this computation as V. So we have three inputs,
484.48|4.76| like I said, input one, the bias inputs to the feature input
489.24|4.24| three, the weight, what we do is the first part is we compute u
493.48|3.76| here, right? So this is multiplying x and w. So this is
497.24|4.04| this multiplication here. So we define u as a placeholder here,
501.44|5.96| u is equal to w x. And then what we do is we add the bias unit
507.4|4.96| here, right? So we have u plus b. So we have this operation
512.36|6.16| here, which gives us another variable V. And then V goes
518.56|4.8| through this. Yeah, activation function. Also, I could have
523.36|4.04| used z, because this is like really the net input. But for
527.4|3.28| some reason, I used to be here shouldn't really matter. Just
530.68|3.72| think of it as a computation here that we then represent as
534.4|6.0| such a graph. So yeah, in the context of deep learning, we are
540.4|3.28| usually interested in computing the partial derivative of the
543.68|3.24| loss function with respect to the weights, or the bias unit.
548.44|2.88| As we've seen in the Adeline lecture last week, and we can
551.32|4.38| actually decompose that into smaller sub steps, right? Using
555.7|4.02| the chain rule, we can also decompose it into the partial
559.72|3.64| derivative of the loss with respect to the activation, and
563.4|5.56| times the derivative of the activation with respect to the
568.96|3.36| weights and so decomposing it. So here we have a simpler
572.32|3.28| computation graph, I haven't included a loss function here.
575.84|2.84| So what we're actually looking at here is only the activation.
578.68|4.76| So we are in this example, only walking through this part. So
583.44|2.82| the partial derivative of the activation with respect to the
586.26|3.62| weights, which we can also further decompose into sub steps
589.88|6.36| using the chain rule. So that's what I'm doing here. But I'm
596.24|2.44| well, that's what I'm going to show you in the next couple of
598.68|3.56| slides. So here I have the first step. So computing the
602.24|5.16| derivative of the activation with respect to the input of the
607.4|4.8| activation. So here, this is the term the derivative of a with
612.2|4.98| respect to B, that's the first step. And using this computation
617.18|3.22| graph, we can really make this super easy, like computing this
620.4|4.92| whole part by doing it in in smaller steps. So the next step
625.32|3.86| would be, for example, computing the derivative of V with respect
629.18|3.82| to B. So because we are interested in both on usually
633.12|3.04| also the bias, because the bias is also like the weight and
636.16|8.56| model parameter, which we can then also write as follows. So
645.04|5.84| this part here would be sorry, this whole part here would be
651.84|2.44| this one here, what we're looking at right now. So the
654.28|7.12| next step is computing the partial derivative of B with
661.4|7.0| respect to B. It's left in here. Yeah, then we can do this also
668.4|3.6| for the other parts. So what's so nice about a computation graph
672.0|4.8| is that we can do it step by step, right. So we can, for each
676.8|5.8| computation, do a backtrack here and annotate our graph. And then
682.6|2.4| we can put everything together. So if we're interested in the
685.0|3.84| derivative of a of the output with respect to the input, we
688.84|2.72| just need to use the chain rule, right. So we can then write this
691.56|14.8| as B, B, times the times the V. So this is a thing mathematicians
706.36|5.2| usually don't like, but we can actually cancel these. So this
711.56|4.52| is why we get this one using the chain rule. And we can also do
716.08|3.92| this here at the bottom, right. So we can do this for this part.
720.24|6.4| So the derivative of a with respect to W would be putting
726.64|11.56| all these together. D, D, B, and then you can technically see how
738.2|5.52| things cancel, right. So this is how we get this one. But
743.72|2.76| technically, this is not a right way to do I mean, we shouldn't
746.48|4.48| cancel things here. But I use use it all the time as a memory, I
750.96|5.2| would say, memory bridge here or something. Alright, so yeah,
756.16|3.2| this is what I've done here. If you want to step through that in
759.36|2.44| the slides. So I was just putting things together here.
763.08|3.92| Yeah, let's now take a look at a concrete example with some
767.0|4.72| some actual numbers. So assume the base unit is one, the weights
771.72|5.56| are two, and we have an input of three. So the intermediate value
777.28|4.88| u would be then six, right? Because two times three, six,
782.2|5.04| and then six plus one is seven. And for the relu function,
787.26|3.14| because it's positive, it's an identity function. So it's also
790.4|5.04| seven. Now let's differentiate. So the derivative of the relu
795.44|4.16| function, if the input is greater than zero is one, right,
799.6|2.86| because it's an identity function. So the derivative of
802.46|4.86| this part here would be one. Then, yeah, let's compute the
807.32|5.68| derivative here and here. So if we look at V, so V, you can
813.0|4.52| think of it as a sum of two functions here. So the
817.92|3.56| derivatives can be then computed separately. So if we look at,
821.52|2.72| let's say the upper part here, let's take a look at this one,
824.24|4.08| the derivative of V with respect to B. So in this case, u is a
828.32|3.6| constant, so we can ignore that and the derivative of B would be
831.92|4.88| one, so there should be a one. And similarly, the other way
836.8|4.8| around, at the bottom here, B becomes a constant, and the
841.6|3.96| derivative of V with respect to u is then also one, right, so we
845.56|4.04| can also put a one here. All right, moving on. So we have a
849.64|4.44| derivative here. So what do we have here? So this is just w x,
854.08|4.6| if we compute the derivative of u with respect to w, then the
858.68|5.88| derivative would be x, and x is what is x, x is three. So here,
864.6|3.68| we should have a three. And yeah, then putting everything
868.28|4.12| together here, the partial derivative of the activation
872.4|4.4| with respect to w would be three times one times one is equal to
876.8|4.6| three, because we are combining with a chain rule. These here,
881.4|6.36| and similarly, we can combine on the results for for this part
887.76|4.6| here, too. So in this way, the result here would be also yet
892.36|4.8| one, because it's one times one. Alright, so this is how we use
897.16|3.96| computation graphs. And I will show you in the next video, how
901.12|3.68| we can implement this in pytorch, where it computes these
905.36|3.68| derivatives for us. Of course, this example is a trivial one.
909.04|3.24| It's very simple, right? That's something you can do in a few
912.28|4.08| seconds by hand. But if you rethink of computational graphs
916.36|3.0| as new networks that are more complicated with many layers,
919.36|3.96| and on lots of input features and stuff, it would be tedious
923.32|4.52| to code it all up in pytorch by yourself or in NumPy. So that is
927.84|2.92| why there's this automatic differentiation that I will show
930.76|4.76| you where pytorch will construct this graph here under the hood.
935.84|2.56| Like, we can actually print out the graph, but we don't have to
938.4|4.4| have to, it will do it automatically for us. Yeah, just
942.8|3.2| some more computation graphs that will be relevant, or that
946.0|3.28| are kind of related to deep learning, just to complete this
949.28|5.08| video here. So yeah, here, we have an example of a graph with
954.36|4.72| a single path. So you can maybe also think of it as a as a
959.08|3.64| simple add a line or logistic regression model, which we will
962.72|3.12| be covering next lecture. So you can think of it as an airline is
965.84|3.36| maybe simpler when you think of the sigma here as an identity
969.2|4.56| function. So this would be the full graph based on what I've
973.76|3.04| shown you earlier. So in the previous slide, I showed you
976.8|4.8| only this part here. Now also think of the output where we
981.6|4.16| compute the loss, for example, an airline, the mean squared
985.76|5.52| error between the prediction or the output and the actual class
991.28|5.04| level. So if we have a case like that, then we compute the
996.36|2.76| derivative of the loss with respect to the weights. And this
999.12|4.4| can be decomposed into the loss with respect to the output. So
1003.52|4.24| this would be this part here, then the output with respect to
1007.96|3.36| the activation. So this would be this part, and then the
1011.32|2.36| activation with respect to the weights, this would be this
1013.68|5.88| part. And this is what we had in the last slide as an example. So
1019.56|5.52| this would be a simple case of graph with a single path. So in
1025.08|3.8| practice, there will be oscillator some more complicated
1028.88|4.16| constructs, for example, imagine a graph with weight sharing, it
1033.08|2.96| is kind of related to what's going on in convolutional
1036.04|3.12| networks, that will be something that will be covered later.
1039.4|3.96| Here's a simple example. Imagine, we have a case, we
1043.36|4.24| have a single input, and then we have a weight parameter that is
1047.6|3.92| that is shared. So that's the same weight that goes here to
1051.52|2.76| compute some activation. So these could be different
1054.28|5.76| functions, a one and a two could be on different functions. And
1060.04|4.96| then we compute some output. And then also here the loss like on
1065.0|3.48| the previous slide. So if we have a case like that, we have
1068.48|4.4| to use the multivariable chain rule because there are no two
1072.88|4.16| paths, like there's some some weight sharing going on. So if
1077.04|5.4| we want to update the W, it depends really on this path
1082.44|3.52| here, and this path, right. So we have to combine them. So we
1085.96|5.04| have the multivariable channel, we compute the loss. So here,
1091.0|3.52| the derivative, this is the same, you can use blue here. So
1094.52|5.48| you can see this is the same here. And then we have two
1100.0|6.6| different derivatives. So we have this one here. And so here
1106.6|2.56| at the bottom, we would have Oh, for some reason, I haven't
1109.16|4.88| written it down. A two, this would be this one here. And
1114.04|3.32| then which color didn't I Okay, let's use this one. And then
1117.76|3.52| this derivative here. And then I'm running out of colors, I
1121.28|3.04| use black, and this one here, and then putting it together
1124.32|3.4| with a multivariable chain rule. Right. So that would be a case
1127.72|5.36| where we have weight sharing. So here would be an example of a
1133.08|3.8| multi layer perceptron, which we will be covering next week. So
1136.88|3.88| here, we also have multiple paths if we want to update
1140.76|3.6| certain weights. So this is a multi layer perceptron with two
1144.36|2.96| hidden layers, you can see there are no two levels of
1147.32|4.76| activations, one level is here, and one level is here. So this
1152.08|8.96| is the first hidden layer, and this is the second hidden layer.
1161.04|3.32| And again, this part is like the same as in the previous slide,
1164.36|4.72| the loss. Um, let's say we are interested here in computing the
1169.08|3.72| derivative of the loss with respect to this weight here, W
1172.8|4.04| one, one, in the first hidden layer. So in order to do that,
1176.84|3.84| we compute the loss. So sorry, the compute the loss, but then
1180.68|3.2| also the derivative of the loss with respect to the output that
1183.88|8.64| would be this part here. And then we go here, this would be
1192.56|7.32| this part. And then we go here, which would be this part. So we
1199.88|3.72| are skipping across some parts later, and next week, we'll do
1203.6|3.56| this step by step in more detail. And then so I'm skipping
1207.72|4.08| here a lot of steps. So because this could also be decomposed as
1211.8|3.4| as sub steps with a net input and so forth, but let's not do
1215.2|5.28| it here. And then we have this part, which is the derivative of
1220.9|2.9| this activation, the a one with respect to this weight, let me
1223.8|5.2| use the green color here. So this is here. So we are
1229.0|11.76| computing with respect to one here. All right. However, note
1240.76|3.44| that there's a second path, right? So we can also let's use
1244.2|3.28| the red here. Let's go to the second path. So it's again, the
1247.48|5.76| same line one is like this one. But we have no also the second
1253.24|5.0| path. Oh, sorry, I said was wrong. The second path would be
1258.24|4.92| this one. And this one, see, it's actually not so easy to see
1263.2|4.92| what is going into here. So this would be the second path. If I
1268.12|3.4| use a different color, let's say pink for the forward here. So
1271.52|3.44| you can see this one, this one, and this one is one path. And
1274.96|4.32| the other one is this one. And this one, and this one, so they
1279.28|7.32| both go in there. So the second path would be then the same as
1286.6|3.2| before and the end here. But then this one is a little bit
1289.8|4.4| different because it's now the second unit here. And then this
1294.2|4.24| one is also the second unit. This is this connection here. And
1298.44|4.12| then we compute this part here, which this is the same. So in
1302.56|3.28| that case, you can see actually things can become quite
1305.84|2.98| complicated if we have a multi layer network. And now imagine
1308.82|2.66| coding this by hand, like computing the derivatives,
1311.52|3.74| implementing them in code. It's very error prone. It's important
1315.26|3.86| to on the big picture, you understand what's going on. But
1319.12|3.16| you're implementing this in by hand. And this is only for one
1322.28|2.48| way, it would be very error prone, which is why we actually
1324.76|3.32| use deep learning frameworks that can do this automatically
1328.08|2.76| for us. So in the deep learning framework, we only have to
1331.0|3.48| provide the forward computation. And then the backward
1334.48|3.08| computation is yet derived automatically because you can,
1337.88|3.36| yeah, you can implement simple rules to do that automatically,
1341.24|2.2| you just have to be careful implementing these rules once
1343.44|2.56| and then you can always apply them to any arbitrary
1346.0|4.32| computations. Okay, so in the next video, I will show you how
1350.32|3.36| we can do this automatic differentiation in pytorch. And
1353.68|3.08| then in the next videos, I will also do this in a more
1357.88|3.0| comprehensive example using the airline that we talked about
1360.9|3.66| last week. And then we will also take a closer look at the pytorch
1364.56|16.64| API, the convenience functions. All right.