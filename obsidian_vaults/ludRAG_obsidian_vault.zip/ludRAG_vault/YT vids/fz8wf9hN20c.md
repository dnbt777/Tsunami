start_time|end_time|text
5.839|4.92|all right so hey guys um thanks for
8.599|4.16|coming to our second class um today we
10.759|4.441|have the pleasure of welcoming aishia
12.759|4.44|he's a senior research scientist at
15.2|4.68|Google mine where he works on the
17.199|5.4|robotics team um he received his PhD
19.88|4.8|here actually um working with um Sylvio
22.599|4.08|salaries and Stanford vision and
24.68|4.48|learning lab as well as
26.679|5.361|leonit um and his mission is to build
29.16|5.0|intelligent embodied agents um that can
32.04|4.76|interact with complex and unstructured
34.16|6.04|real world environments um with
36.8|5.2|applications home robotics um recently
40.2|4.359|has he has been exploring the use of um
42.0|5.16|Foundation models um for robots decision
44.559|4.32|making and action Generation Um so now
47.16|4.68|I'll hand it off to
48.879|5.401|P um hi everyone um I'm super happy to
51.84|4.76|be here and happy to be back I graduated
54.28|4.56|from here two years ago and now I'm a
56.6|4.36|research scientist at Google deep mind
58.84|3.92|uh I work on the robotic team and today
60.96|3.68|I will be talking about low-level
62.76|4.679|embodied intelligence with Foundation
64.64|4.72|models so uh it's definitely an
67.439|4.201|interesting topic and I will introduce
69.36|4.28|what is embodied intelligence and what
71.64|5.36|is low-level embodied intelligence and
73.64|5.799|how we can um accelerate the building of
77.0|5.439|them with the foundation
79.439|5.64|models um all right so why are we
82.439|4.601|working on embodied intelligence so
85.079|6.04|embodied intelligence is an integral
87.04|7.16|part of um artificial elligence and it's
91.119|5.441|an important Milestone to um artificial
94.2|4.76|general intelligence and it has a lot of
96.56|4.879|use cases like for example we all hope
98.96|6.08|we have a home robot that can be our
101.439|7.081|home um 247 and clean the home for us or
105.04|5.759|um um clean up our um messy room or cook
108.52|4.599|for us or taking care of our our uh
110.799|4.441|aging family members so we are not quite
113.119|5.241|there yet in fact we are quite far from
115.24|5.08|it uh that is because our intelligence
118.36|4.92|is currently mostly in the the virtual
120.32|6.56|world so we have ai agent that can help
123.28|5.199|us draft emails or write eloquent essays
126.88|4.52|but they are not super good at
128.479|5.76|interacting with the messy uh real world
131.4|6.479|unstructured complex environment that
134.239|6.401|human resides in so just to give you
137.879|5.36|guys a couple examples of how messy the
140.64|5.0|the real world can be and how hostile it
143.239|5.881|could be to to robotics I want to show
145.64|6.0|you a curious mistake or curious error
149.12|4.72|uh from one of our robots so the task is
151.64|5.0|to put the uh put the Cod can in the
153.84|5.56|sink and watch what the robot do the
156.64|7.56|robot grab the Coke can and open the tab
159.4|6.6|so um this is kind of dangerous but it's
164.2|4.08|kind of interesting right because we
166.0|4.64|never expect it would uh do something
168.28|4.4|like that it's just from random noise it
170.64|5.76|it it starts to open the top and the
172.68|5.52|water starts to come out so for a an an
176.4|4.199|agent to have this type of physical
178.2|5.24|intelligence it need to understand the
180.599|4.401|effect of its actions and what is
183.44|3.84|so-called a world model so people have
185.0|3.959|been complaining that language model so
187.28|5.0|far don't have a world model so it
188.959|5.2|doesn't understand geometry doesn't
192.28|4.599|understand spatial relationship of
194.159|5.321|objects or the effect of actions
196.879|6.08|basically how object will will move
199.48|6.24|according to physical laws so uh we are
202.959|5.601|not quite there yet in another case so
205.72|5.96|uh this is our robot that is ready to
208.56|4.879|deliver a can or throw away again but as
211.68|4.08|you could see we have this Pro
213.439|5.601|pre-programmed behavior of tucking the
215.76|5.92|arm behind and in doing that the can is
219.04|5.64|upside down so if there's any liquid in
221.68|5.68|a can it will spill and damage the robot
224.68|4.52|so it's another example of real world is
227.36|5.84|really complex and there are a lot of
229.2|6.2|things to model and um in order for our
233.2|3.879|robots to have this sort of ambient
235.4|4.52|intelligence it really need to
237.079|4.641|understand a lot of very Nuance um uh
239.92|3.84|details of the environment and
241.72|6.28|understanding the physics physical laws
243.76|6.44|and understanding um effect of its
248.0|3.68|actions um how do we do that there are
250.2|4.039|many ways to achieve embodied
251.68|5.399|intelligence actually throughout my PhD
254.239|5.4|study I've been fascinated by this idea
257.079|5.441|of uh creating interactive environments
259.639|4.761|basically let agent explore in this
262.52|4.2|interactive environments basically
264.4|5.92|create environments that are complex
266.72|5.919|enough so so that if the agent need to
270.32|3.879|survive in such environment it must
272.639|4.601|develop intelligence so it's a
274.199|5.161|ecological view of perception and agency
277.24|5.92|and is popularized by American
279.36|6.44|psychologist James J Gibson so um he has
283.16|4.68|a famous quote ask not what what is
285.8|4.64|inside your head but what your head is
287.84|5.4|inside of so human learned this type of
290.44|5.599|embodied intelligence human is able to
293.24|4.84|manipulate objects e effortlessly one
296.039|3.72|because of evolution second because the
298.08|3.16|the childhood experience we have been
299.759|3.801|playing with this toy we have been
301.24|4.84|interacting with this toy and watch the
303.56|5.6|physical effect so that we learn um and
306.08|6.36|similarly we can give robot uh a safe
309.16|4.72|play pan so they can explore in those uh
312.44|3.92|environment and interact with
313.88|4.96|environment and play and watch the uh
316.36|4.6|effect of actions and effectively
318.84|6.04|understand how to manipulate those
320.96|7.16|objects um so I have been um developing
324.88|5.2|this uh simulation environment uh one of
328.12|5.6|which is called Gibson environment which
330.08|7.04|is published as cvpr uh it's mainly
333.72|5.56|aiming at simulating the visual World
337.12|4.96|faithfully and also simulate physical
339.28|4.72|world to some extent so we we build this
342.08|4.64|environment which is a scanned
344.0|4.84|environment from a lot of houses and
346.72|5.039|then an agent we can spawn an agent in
348.84|6.4|that in this case a humanoid agent and
351.759|5.601|the agent can learn learn to walk or to
355.24|4.28|run in this environment and simulate all
357.36|4.839|this perception information so we can
359.52|4.56|can create a perception action Loop uh
362.199|4.361|for this for this agent and similarly we
364.08|5.839|can put other types of agent in this
366.56|5.68|environment in this case a little a
369.919|5.161|little cart and we can also put
372.24|6.079|quadruped or or this ant into this
375.08|5.959|environment so essentially we create um
378.319|5.0|an environment where we can simulate a
381.039|4.241|perception for for the agent and then we
383.319|4.841|can create a neuron Network to map the
385.28|4.68|perception to action and uh this way we
388.16|4.479|achieve some sort of physical
389.96|4.88|intelligence it's mostly for uh navigate
392.639|5.201|navigation and
394.84|5.799|Locomotion this is not enough um so in
397.84|5.359|this case the the the environment is one
400.639|5.12|monolithic piece of mesh as you can see
403.199|5.601|the the agent run into the wall and it
405.759|5.16|it bounc back so there's no articulation
408.8|4.08|in this environment so it's not
410.919|4.601|simulating the full complexity of the
412.88|5.039|environment so the the the things uh
415.52|4.799|that we can do with our agent is rather
417.919|4.321|limited so that's what why we create
420.319|4.081|other simulation environment one of
422.24|5.12|which is I Gibson environment which is
424.4|6.12|called interactive Gibson so uh what we
427.36|5.839|do is we create we we again scan a lot
430.52|5.56|of uh real world houses and then we
433.199|5.481|convert them to uh CAD assets basically
436.08|5.36|mesh assets that are interactable in
438.68|4.799|this case we have a simulated agent that
441.44|4.879|go into the environment and then close
443.479|4.881|all the drawers um so we are able to do
446.319|4.32|that because we we model the complexity
448.36|4.72|of the world a little bit more we go
450.639|4.161|beyond just modeling the visual world we
453.08|2.64|we start to model physics a little bit
454.8|3.32|more
455.72|4.879|basically um modeling the degree of
458.12|5.88|freedom in environment and and our agent
460.599|7.081|can do more than just navigating around
464.0|6.24|so um we can go even further so we can
467.68|4.44|even model more degree of freedom and
470.24|4.56|our agent can develop more complicated
472.12|6.28|Behavior such as unloading a dishwasher
474.8|5.799|and find a bow or uh take out a bow and
478.4|4.6|put it on the table so as we scale up
480.599|5.081|the complexity of the environment we we
483.0|5.759|are able to um learn much more
485.68|6.04|complicated skills um in in simulation
488.759|4.961|and that's one way to achieve embodied
491.72|5.12|intelligence uh which is to build
493.72|3.12|complex enough simulation
497.68|4.76|environment um not just the my research
500.28|4.56|but the entire field of computer vision
502.44|4.84|is undergoing a paradigm shift so
504.84|5.639|previously we are focusing on internet
507.28|6.16|AI we cured a lot of Internet data sets
510.479|4.841|to uh study problems like classification
513.44|5.079|segmentation and detection basically all
515.32|6.639|these computer Vis problems now we focus
518.519|5.44|a lot more on embodied AI uh which is
521.959|3.801|adding the the action Dimension to the
523.959|3.921|problem that we are studying problems
525.76|4.48|like visual navigation manipulation
527.88|5.16|rearrangement embody question answering
530.24|5.92|instruction following um and the
533.04|5.479|simulators replace in some in some some
536.16|5.679|sense replace the original role of data
538.519|4.801|sets one thing that doesn't change uh
541.839|4.881|which is the data is still super
543.32|6.36|important we are still relying on a
546.72|5.559|large amount of data to uh learn this
549.68|6.04|intelligent Behavior no matter it's from
552.279|7.12|a static data set or from a
555.72|6.84|simulator so um learning in simulation
559.399|5.721|can can take a lot of interactions so
562.56|4.92|just give you um an example we create
565.12|5.2|this uh ibson environment and we want to
567.48|4.88|learn a behavior called go into a room
570.32|4.92|through a closed door so this is a
572.36|5.32|rather simple Behavior which I can show
575.24|5.32|on the top right of the screen so the
577.68|4.599|agent need to stop in front of the door
580.56|3.399|it need to stop at the right distance if
582.279|4.12|it's stop too close to the door it
583.959|4.521|cannot extend its arm if it's too far it
586.399|4.241|cannot open the door and then it
588.48|4.32|basically open the door let me play this
590.64|4.92|again open is a door when there's enough
592.8|5.68|clearance it will go into the door
595.56|5.959|however it takes about 50,000 episodes
598.48|5.64|or 1 25 million environment interactions
601.519|4.32|to learn this type of behavior um this
604.12|4.159|is because we are using model free
605.839|4.641|reinforcement learning the agent is
608.279|4.24|exploring this environment it could
610.48|5.64|really push any point it could rather
612.519|6.041|stop at any point so um we we give it a
616.12|5.36|reward function to go into the room but
618.56|3.719|it's very rare that it will stumble upon
621.48|2.88|this
622.279|4.56|Behavior I would like to argue with
624.36|4.76|Foundation models we can do a lot uh a
626.839|3.921|lot more different right so what do you
629.12|3.6|what do you do nowadays you just ask a
630.76|3.92|hbt how do you go into your room through
632.72|4.08|a closed door and it will say open the
634.68|4.2|door walk through the door so this is a
636.8|5.36|this is a gross simplification of the
638.88|5.44|problem of course um it it's the problem
642.16|5.119|is not that simple but what I'm just
644.32|6.16|saying is that we can leverage a lot of
647.279|5.641|semantic prior from the the foundation
650.48|4.4|models so if we if we if we really like
652.92|4.479|data if we really need a lot of data the
654.88|5.0|foundation model is a compressed version
657.399|4.641|of the entire data and it's a know base
659.88|4.199|that you can quiry and to accelerate the
662.04|4.16|development of Robotics of course
664.079|5.121|simulation and real world data is still
666.2|4.52|super super important but maybe we can
669.2|4.6|uh get the best of both worlds we can
670.72|5.919|use Foundation models plus uh a limited
673.8|4.52|amount of simulation of real world data
676.639|2.721|um so that's what I'm going to talk
678.32|3.68|about
679.36|5.52|today so where are we in terms of
682.0|4.8|foundation models plus robotics so our
684.88|4.16|team at Google deepmind has been
686.8|4.76|piloting in Foundation model Plus
689.04|5.52|robotics so we developed Advanced
691.56|5.92|planning high level planning algorithm
694.56|6.079|one of the first is called Palm Sayan it
697.48|5.039|is an algorithm that can parse a user
700.639|3.76|command so so here is a demo here's a
702.519|3.56|scenario here is the user command I
704.399|3.041|spill my Coke on the table how would you
706.079|3.601|throw it away and bring me something to
707.44|4.92|help clean and it's quiring a large
709.68|5.2|language model uh which is given a score
712.36|4.279|uh um highlighted in blue and there's
714.88|4.079|also an affordance score the affordance
716.639|4.44|will tell you whether an action at a
718.959|4.721|given state is possible it's argumenting
721.079|5.161|the language model to give you only
723.68|4.48|possible things so essentially it is
726.24|3.88|doing the planning doing the semantic
728.16|3.919|planning with a language model but it's
730.12|6.719|also taking into consideration what it
732.079|7.76|can do so it's not just a um outputting
736.839|4.761|the like language model are tend to
739.839|3.56|hallucination uh it it doesn't
741.6|3.52|hallucinate it only give you what is
743.399|3.44|possible for the robot to do and what is
745.12|4.719|actionable for the robot and the robot
746.839|6.201|is doing the thing that is advancing the
749.839|6.56|long Horizon task progress and also each
753.04|5.72|task is executed by a low Lev policy
756.399|4.921|here it doesn't quite uh clean the the
758.76|4.519|the table uh because uh we haven't added
761.32|3.319|this to the low level skill but imagine
763.279|4.081|there is a low level skill to clean the
764.639|5.081|table it will finish the entire
767.36|5.88|thing uh what is the Lo of policy used
769.72|6.88|to here the Lo of policy used to here is
773.24|6.2|robotic Transformer one uh rt1 it's our
776.6|5.08|team's homegrown transform forer
779.44|5.32|essentially we collect a large data set
781.68|6.04|of uh human demonstrations we put a
784.76|6.48|Transformer um and we we train train it
787.72|6.4|on uh this large data set of expert
791.24|7.36|trajectories it is able to do about 700
794.12|6.279|tasks with 97% success rate so um and it
798.6|4.359|gener it has interesting generalization
800.399|5.201|Behavior it can operate in a new kitchen
802.959|5.521|it has never seen before so which is
805.6|6.0|showing um there is a successful recipe
808.48|5.599|to apply foundation models in robotics
811.6|4.84|so that's roughly where are we in terms
814.079|5.44|of foundation model plus robotics um and
816.44|6.12|I would I will I will um talk about a
819.519|7.081|few new works that is bringing this to
822.56|7.04|uh the next level so um actually U my
826.6|4.96|teammate Ted give a talk of foundation
829.6|5.12|models plus robotics at the beginning of
831.56|6.12|this this year um it's also this class
834.72|5.16|cs25 I highly recommend it it's uh it's
837.68|4.599|available on YouTube I actually watch it
839.88|4.84|last night so that I don't repeat um
842.279|6.281|some of the the contents but what he
844.72|6.919|basically mentioned is that we um he
848.56|5.32|revealed our team's progress in terms of
851.639|5.281|building this robot robotic Foundation
853.88|5.079|models and we have had a lot of some
856.92|6.8|somewhat detour and now we we sort of
858.959|7.0|figured out a recipe so in 2021 to 2022
863.72|4.16|is how we scale to many tasks with
865.959|5.361|demonstrations how do we collect a large
867.88|6.879|amount of data uh in fact um about
871.32|5.879|100,000 U demonstrations and we tried
874.759|4.0|different ways to do it we tried the
877.199|4.041|behavior cloning we tried imitation
878.759|4.601|learning plus reinforcement learning and
881.24|5.24|um some other ways or combining them
883.36|6.2|with language models such as Sean in
886.48|4.84|2022 to 2023 uh is about how we can
889.56|3.88|leverage Foundation models to accelerate
891.32|5.079|robotics we really see a proliferation
893.44|5.44|of um using Foundation models to
896.399|4.601|accelerate robotics uh both on the high
898.88|3.759|level planning and low level control
901.0|2.44|probably leaning more towards the high
902.639|5.161|level
903.44|6.92|planning so if the recipe Works um so so
907.8|5.479|the recipe is essentially uh combine a
910.36|4.96|large scale diverse offline data set
913.279|4.48|which uh with with high capacity
915.32|4.879|architecture such as a Transformer and
917.759|4.561|using language as a universal glue so
920.199|3.961|this will be the the recipe to build
922.32|4.879|Foundation models for
924.16|4.599|robotics okay so if this recipe Works
927.199|3.64|what do we do what do we do next
928.759|5.161|essentially we just uh let's just scale
930.839|5.521|everything to to others of magnitude and
933.92|4.76|uh and be done with it and and and solve
936.36|3.88|Robotics and and and guess what that's
938.68|3.2|what we did so that's the end of the
940.24|4.959|lecture maybe we can cut this a little
941.88|6.879|bit short um and that that's a joke
945.199|6.041|that's that's not happening um so we we
948.759|4.721|we are still on our way uh on our quest
951.24|4.12|to solve lowlevel embodied intelligence
953.48|6.039|when I talk to people uh that you can
955.36|6.76|use Foundation models to uh uh to do
959.519|5.481|robotics uh their reaction would be it's
962.12|5.519|mostly doing highle reasoning it doesn't
965.0|5.12|do the lowlevel uh manipulation really
967.639|4.041|well uh and that that's for a reason
970.12|4.92|like one of the reason is there's a
971.68|4.8|morava paradox uh morava Paradox is
975.04|3.84|observation that in artificial
976.48|4.32|intelligence and Robotics contrary to
978.88|4.0|traditional assumptions or our
980.8|4.719|intuitions reasoning requires very
982.88|4.84|little computation but S motor control
985.519|5.88|and perception skills require enormous
987.72|7.84|comput sources that is because as U
991.399|5.761|biological creators we um we we acquire
995.56|4.36|the sensory model skills through
997.16|6.2|Evolution um this is very different so
999.92|5.64|we don't we might not be able to um like
1003.36|5.52|reason or do large amount of large scale
1005.56|6.12|computation but this uh sensory model
1008.88|5.079|control is integral to our survival so
1011.68|4.959|it's it's essentially already learned in
1013.959|5.161|our DNA but in in robotics it's a little
1016.639|4.801|bit different so the the the ch tips are
1019.12|4.079|very good at doing reasoning and
1021.44|3.639|computation but they are not super good
1023.199|3.801|they haven't experienced the world they
1025.079|5.161|haven't acquired the sensory model
1027.0|5.839|skills that is uh necessary for them to
1030.24|5.679|uh do task in the real world here is
1032.839|6.24|example when the the the uh computer
1035.919|6.361|beat the Caspar of basically the human
1039.079|5.0|champion in chess uh there is another
1042.28|4.84|robot arm moving the chest piece it can
1044.079|5.001|beat the human champion in uh in chess
1047.12|3.96|but there are still some need to move
1049.08|4.76|the chest piece similarly in in the
1051.08|5.12|alphao moment when lisador was beaten by
1053.84|4.16|alphao there's still someone who is
1056.2|3.68|moving the chest piece for them it's not
1058.0|4.6|a robot doing that so this is showing
1059.88|4.56|the reasoning is the hard things are
1062.6|4.88|easy and the easy things are
1064.44|6.04|hard there's another thing that prevent
1067.48|5.319|us from like using Foundation models
1070.48|5.4|more prevalently more in a larger skill
1072.799|5.561|in robotics which is the training data
1075.88|3.88|bias like the training data of
1078.36|4.64|Foundation models or large language
1079.76|5.76|models are mostly language tasks so it's
1083.0|4.84|perhaps not that surprising it knows how
1085.52|4.44|to clean up a kitchen because maybe
1087.84|4.12|there are W Wiki how articles teaching
1089.96|4.12|you how to clean up a kitchen or to do
1091.96|4.4|something in a procedural way but there
1094.08|4.52|is no Wiki how articles teaching you how
1096.36|4.6|to move your finger 5 centimeters to the
1098.6|4.68|left because people just don't uh say
1100.96|5.079|that people don't write that down so
1103.28|5.279|there is very limited amount of uh this
1106.039|4.281|lowlevel Control Data in Lar anguage
1108.559|3.681|model training cpra so we do have a lot
1110.32|4.2|of challenges in bringing the foundation
1112.24|4.36|models to a lower level so that's what I
1114.52|5.0|mean by lowle embodied
1116.6|4.6|intelligence so uh any any questions so
1119.52|4.32|far also I want to make this quite
1121.2|5.76|interactive so there is any questions
1123.84|3.12|feel free to interrupt me
1129.08|4.92|anytime all right if not we can uh we
1131.6|4.0|can continue so there are a couple
1134.0|4.039|challenges of using large language
1135.6|5.0|models for lowle control U as I just
1138.039|7.481|mentioned men the first thing is lack of
1140.6|8.4|data so we only have um perhaps 100,000
1145.52|6.68|episodes uh of um of human demonstration
1149.0|5.679|data and takes about 13 robots 17 months
1152.2|4.959|to collect so it's a huge amount of
1154.679|4.841|effort on the country large language
1157.159|5.161|models are trained on the order of a
1159.52|5.2|thousand billion tokens pal a smaller
1162.32|5.719|Palm was trained on 780 billion
1164.72|6.52|parameter uh 780 billion tokens and the
1168.039|5.081|L one is trained uh the the the
1171.24|5.319|following the chinchilla rule you would
1173.12|6.0|need to train on 1.35 trillion tokens so
1176.559|5.281|it's a huge amount of
1179.12|5.679|um discrepancy between how much data we
1181.84|6.28|can achieve in robotics and how much uh
1184.799|5.12|we can get in large language models so
1188.12|4.2|we will always be bounded by robotic
1189.919|4.321|data so can we maybe we can scale on
1192.32|4.0|other fronts maybe we can keep the
1194.24|4.439|robotics data the same and then we can
1196.32|4.44|scale on on other fronts like maybe we
1198.679|4.601|can scale the pretraining mix of text
1200.76|6.159|and image or maybe image and text pairs
1203.28|5.84|maybe we can build this this cake and
1206.919|3.961|the robotics data is just a cherry on
1209.12|5.439|top of it and we can scale the
1210.88|5.36|foundation really really well um some of
1214.559|4.24|my my work that I'm going to talk about
1216.24|4.84|today actually reuse the rt1 data we
1218.799|4.441|don't collect new data for rt2 but we
1221.08|3.68|want to do more things with the same
1223.24|5.04|amount of
1224.76|5.32|data um the Second Challenge is um kind
1228.28|4.639|of related to the first challenge
1230.08|5.52|language models lacks an interface for
1232.919|4.88|lowle control if you ask a language
1235.6|4.68|model how do you make a robot dog stand
1237.799|4.201|up on two feet it will tell you a lot of
1240.28|3.759|things that sounds reasonable sounds
1242.0|4.4|plausible it will tell you the robot
1244.039|4.801|dog's torso is upright balance over to
1246.4|4.36|hind feet and standing shoulder width
1248.84|3.92|apart this is great this is all great
1250.76|5.48|but we cannot put it on the
1252.76|5.2|robot um on on on the other on the other
1256.24|3.84|hand maybe we can ask language model to
1257.96|4.4|write control code to directly control
1260.08|6.0|the robot but usually that requires you
1262.36|6.439|to curate an API that is friendly to the
1266.08|5.16|language model if I directly ask it to
1268.799|4.24|give you my join angles to make the
1271.24|3.2|robot stand upright it will not give you
1273.039|4.24|the right thing because it doesn't have
1274.44|4.96|enough context so essentially um large
1277.279|5.441|language models don't speak robot
1279.4|5.159|language uh can we actually find the the
1282.72|4.24|right robot language can we find the
1284.559|5.161|interface between large language models
1286.96|5.079|and robot control or can we just treat
1289.72|4.36|Robot action as another language so
1292.039|5.401|that's what we want to find
1294.08|4.76|out so um in today's agenda I will be
1297.44|4.16|talking about lowlevel embod
1298.84|5.439|intelligence with Foundation models it's
1301.6|4.439|uh separated into two parts and it's
1304.279|3.801|addressing the two challenges that I
1306.039|4.601|have just mentioned part one is about
1308.08|5.04|model consolidation uh joint scaling and
1310.64|4.8|positive transfer so I have to put them
1313.12|5.0|in one uh part because they are somewhat
1315.44|4.44|related and part two is developing new
1318.12|4.6|interface of large language
1319.88|5.919|models so uh what do I mean by model
1322.72|6.959|consolidation model consolidation uh yes
1325.799|4.961|question yeah I just ask why you use and
1329.679|4.161|for
1330.76|5.36|generating L
1333.84|3.959|code
1336.12|3.96|description
1337.799|4.681|yeah yeah that's a great question so the
1340.08|5.32|question is why cannot we find tun
1342.48|7.319|language model to directly output low
1345.4|6.48|level code um and or like robot actions
1349.799|4.0|so I will be talking about rt2 which
1351.88|4.44|does somewhat similar to that it
1353.799|4.841|fine-tune language model to Output
1356.32|4.68|action as a language uh to find to
1358.64|4.08|Output our action representation uh
1361.0|3.08|there are certain downsides to that like
1362.72|4.52|for example you would need to collect
1364.08|6.12|additional data for to find a language
1367.24|5.28|model um so either we can find T that or
1370.2|4.32|we can use a language model zero shot if
1372.52|4.44|you find the right interface which I
1374.52|5.639|will talk about a little bit in a part
1376.96|6.56|two without find
1380.159|4.681|yeah so uh the model consolidation is
1383.52|2.92|essentially we can do the high level
1384.84|4.68|reasoning and low level control in one
1386.44|4.96|model and Joint scaling is not only we
1389.52|5.159|we scale the robot data which is
1391.4|6.159|expensive we also scale um the the the
1394.679|4.961|pr trining data or we already start from
1397.559|4.12|a pre-trained vision language model and
1399.64|4.519|a positive transfer is model benefiting
1401.679|4.841|from diverse uh joint training across
1404.159|6.52|internet scale language vision and
1406.52|7.759|vision language domains uh combined with
1410.679|7.681|robotics so uh this is a continuation of
1414.279|7.481|the the the axis that Tad get Drew in
1418.36|6.08|his previous talk so we can see there is
1421.76|4.68|a trend so so this uh visualization
1424.44|6.599|basically highlights some of the work on
1426.44|7.32|our team and uh each each each work each
1431.039|4.161|column is basically a robotic system
1433.76|3.6|that is able to do both high level
1435.2|5.2|reasoning and lowle control so
1437.36|6.84|previously we need to uh have separate
1440.4|6.56|models for each thing previously uh in
1444.2|4.88|the initial release of Sean the planning
1446.96|5.4|is done by a large language model and
1449.08|7.32|affordance is done by um the affordance
1452.36|7.96|is done by um a QT op like policy uh
1456.4|5.759|trained with Sim real so um and the low
1460.32|5.0|LEL low level policy is robotic
1462.159|7.161|Transformer one so it's it's each model
1465.32|6.32|doing its dedicated thing and uh uh we
1469.32|5.2|need to train each model differently and
1471.64|4.48|perhaps with different type of data and
1474.52|5.96|later we have q Transformer which
1476.12|7.52|unifies which is a kind of a offline RL
1480.48|4.799|method uh that is leveraging Transformer
1483.64|3.519|architecture so it's it's a
1485.279|4.081|high-capacity architecture it can train
1487.159|5.321|on both positive data and negative data
1489.36|5.72|and with that we we able to get a policy
1492.48|5.0|uh that is Al also understanding
1495.08|4.24|affordances so we can unify the low Lev
1497.48|3.919|policy and affordances but the planning
1499.32|5.079|is still a large language model and then
1501.399|6.121|we have py uh which is a vision language
1504.399|5.481|model uh which is a large language model
1507.52|5.32|also trained on Vision language domain
1509.88|4.519|so the P can do planning and affordance
1512.84|4.64|in just a one model but the low level is
1514.399|5.76|still using rt1 and finally we unify
1517.48|4.799|everything together like there is rt2
1520.159|3.88|which I'm going to talk about today that
1522.279|3.721|can do both high level planning to some
1524.039|5.88|extent uh generating affordance and do
1526.0|6.72|lowlevel uh policies so behind the model
1529.919|5.841|consolidation is the consolidation of
1532.72|6.6|tasks we can represent every task as a
1535.76|5.799|Vision Plus text to text uh task so it's
1539.32|5.12|a it's a really Universal representation
1541.559|6.321|of the task and then with that you can
1544.44|5.119|train it really on using a lot of data
1547.88|4.679|and you can see positive transfer
1549.559|5.521|basically learning learning affordance
1552.559|6.24|can also tell you uh how to achieve a
1555.08|5.479|task like like there there are transfer
1558.799|3.88|between tasks when you pull all the
1560.559|5.201|tasks
1562.679|5.24|together so to understand this join
1565.76|4.88|scaling and to understand the model
1567.919|5.201|consolidation we need to um understand
1570.64|4.84|palm e a little bit so palm e is
1573.12|4.76|embodied multimodal language model it's
1575.48|4.919|based on the palm architecture so Palm
1577.88|6.12|is a large language model we made some
1580.399|6.0|adaptation on the architecture so it can
1584.0|6.72|understand multimodel input
1586.399|8.321|so it's it is basically one model um
1590.72|7.8|that is able to take in multimodal input
1594.72|7.4|so um in large language models each word
1598.52|7.32|is tokenized and tokenized and getting
1602.12|5.6|this this embedding of this um words and
1605.84|5.839|then that is feed fed into a large
1607.72|6.4|language model so in pal what we do is
1611.679|5.12|instead of using words we can use
1614.12|5.24|multimodal tokens so the multimodal
1616.799|5.6|tokens Can come from a vision Lang can
1619.36|6.88|come from a vision Transformer a viit or
1622.399|7.441|it can come from uh robot sensory data
1626.24|6.28|so every um every multimodel
1629.84|6.719|token then we map it to the text
1632.52|7.759|embedding space um we basically train a
1636.559|6.761|a linear a fine transform between the
1640.279|7.28|multimodal token and the the text in
1643.32|7.92|beding space and then we can treat um
1647.559|6.641|the multimodal token as words as well so
1651.24|5.6|essentially we have a language model as
1654.2|5.479|as as a solid base and then we start to
1656.84|5.16|adapt it to understand multimodal tokens
1659.679|5.081|so this is quite interesting because we
1662.0|5.559|don't it doesn't require a ton of
1664.76|5.6|adaptation or fine-tuning for it to
1667.559|6.0|understand uh multimodal input it just
1670.36|5.559|aligns naturally to the multimodal input
1673.559|5.0|such as images I will show a couple of
1675.919|4.721|examples of what they can do and and we
1678.559|4.281|can train the same way as training large
1680.64|4.639|language models so essentially we can
1682.84|4.76|reuse the same infrastructure and
1685.279|6.12|training algorithm and everything uh to
1687.6|6.4|train this P me um a couple other things
1691.399|4.481|we we find along the way is positive
1694.0|5.64|transfer uh which I will share in a
1695.88|6.639|little bit so um I guess here I also
1699.64|5.48|want to mention uh P me is one of the
1702.519|6.16|largest model we have explored so far it
1705.12|6.799|has 562 billion parameters which is by
1708.679|5.88|concatenating the the Palm 540 billion
1711.919|5.76|parameters and the 22 billion VI and we
1714.559|7.401|find a lot of uh emerging capabilities
1717.679|7.041|of these models that is we we haven't um
1721.96|4.319|uh expected during training time but
1724.72|4.4|really we can prompt these models and
1726.279|5.52|ask you to do interesting things we have
1729.12|4.64|also explored uh using neuros sing
1731.799|3.0|representation basically an object
1733.76|5.039|Centric
1734.799|8.201|representation um to and fed into into
1738.799|7.161|pal so um object Centric representation
1743.0|5.919|assigns one token to each
1745.96|5.64|object and we find this representation
1748.919|5.12|is super helpful for robot planning
1751.6|4.76|tasks because traditional viit
1754.039|3.841|representation is based on grid and it
1756.36|4.199|doesn't have a full understanding of
1757.88|6.48|like objects and their relationships uh
1760.559|6.12|we have done a ex um extensive study on
1764.36|4.72|the the scaling performance and the
1766.679|5.081|catastrophic forgetting performance um
1769.08|4.479|and all other uh interesting experiment
1771.76|4.08|in in the paper so please refer to the
1773.559|5.641|paper for more so here I'm just showing
1775.84|5.839|some interesting uh qualitative examples
1779.2|6.56|of um or some emerging capability of
1781.679|6.201|Tomy that we found out so first we found
1785.76|4.32|this model has some reasoning capability
1787.88|4.24|you can give it an image and ask it
1790.08|3.959|questions uh that requires a little bit
1792.12|4.84|reasoning and you can prompt this with
1794.039|5.801|with let's think step by step which is
1796.96|4.92|um a technique used to elicit reasoning
1799.84|3.64|in large language models but here in
1801.88|4.56|multimodal language models you can do
1803.48|5.439|the same I guess people also are also
1806.44|4.839|experimenting it uh these days with gbt
1808.919|5.281|4V you can also prompt it to think step
1811.279|6.081|by step or count row by row uh but here
1814.2|5.44|um this is before gbt 4V and we were
1817.36|4.199|able to elicit reasoning using some of
1819.64|4.96|the interesting prompts such as we can
1821.559|5.36|ask it uh in this photo um are there
1824.6|4.48|more cats or more dogs let's think step
1826.919|4.041|by step and they found the the pal me
1829.08|5.92|found out there are equal amount of dogs
1830.96|5.92|and cats and on the right um given image
1835.0|4.24|can I go down the street on a bicycle
1836.88|5.08|yes or no let's think step by step and
1839.24|4.72|the reply is do not enter second except
1841.96|4.839|the bicycles do not entry except the
1843.96|7.12|bicycles yes so it's doing this mod of
1846.799|6.441|reasoning and it's mixing um this
1851.08|4.839|understanding of symbols and also mixing
1853.24|4.6|the understanding of text so this is
1855.919|4.321|quite quite amazing to me
1857.84|4.4|uh to be to be honest when I first saw
1860.24|4.48|this I didn't expect a multi mod
1862.24|5.439|language model would be able to do that
1864.72|5.28|and uh we also tried one thing which is
1867.679|4.561|traditionally very difficult to to uh to
1870.0|4.96|language models which is to tell a joke
1872.24|5.2|language models can understand joke but
1874.96|5.76|sometimes it just doesn't it's not able
1877.44|5.32|to tell you a joke um like when it comes
1880.72|3.959|to the punch line because it's just
1882.76|4.519|trying to make something that is
1884.679|4.12|plausible and sounds like a joke and
1887.279|3.88|when there it comes to the punchline it
1888.799|4.76|doesn't really know what to say so here
1891.159|5.201|I give it an image and I ask it to come
1893.559|5.12|come up with a description and then come
1896.36|4.84|comes up with a joke so this guide
1898.679|4.321|language model to think step by step and
1901.2|4.439|the description is a donkey is carrying
1903.0|4.24|a dog cat and rooster and the joke is
1905.639|4.0|what do you call a donkey with a rooster
1907.24|4.439|on his back a rooster booster um it's so
1909.639|4.241|creative like when I saw this I'm I'm
1911.679|4.24|pleasantly uh surprised and I searched
1913.88|4.399|online I couldn't find another joke like
1915.919|4.6|that so it's actually original joke by
1918.279|6.441|pomy and finally we see some math
1920.519|7.04|reasoning with this model um um
1924.72|6.6|basically I give it a messy manual from
1927.559|5.681|a pizza store and I ask it um how much
1931.32|3.319|is a I'm just buying a pizza for me and
1933.24|4.76|my friend how much should I pay let's
1934.639|7.081|think step by step and it's figuring out
1938.0|6.0|there's a pizza and there's a $9.99 and
1941.72|4.839|it tell you the price uh in some of the
1944.0|4.24|answers it even calculate text but text
1946.559|2.6|but the text is hallucinated so that
1948.24|3.36|doesn't
1949.159|5.88|work all right let's talk about positive
1951.6|7.319|transfer so apart from the amazing capab
1955.039|6.88|amazing um uh things that py can do it
1958.919|7.401|also has interesting positive transfer
1961.919|7.0|Behavior so um when we train P me on a
1966.32|4.8|single domain when we train it on just a
1968.919|4.401|single robotics task the performance is
1971.12|5.2|not super great but when we pull all the
1973.32|6.64|data together and we also include uh
1976.32|5.92|internet SC SC um Vision language tasks
1979.96|4.52|such as captioning or Vision visual
1982.24|5.559|question answering it is able to do much
1984.48|5.96|better so this shows that it's important
1987.799|6.921|to mix all the data together and train
1990.44|7.119|it jointly the internet scale data can
1994.72|5.0|uh can act as a a regularizer for you to
1997.559|3.681|not forget the
1999.72|3.679|representations and those
2001.24|3.96|representations are in turn very useful
2003.399|4.16|for
2005.2|4.12|robotics so that's that's a POS transfer
2007.559|3.401|results and we start to see more and
2009.32|5.52|more positive transfer in other of our
2010.96|6.679|studies yes so how much to colletive
2014.84|5.36|like in simulation or in real world like
2017.639|4.76|I think the like the playing with the
2020.2|5.12|Sorting stuff on the table is very
2022.399|7.481|impressive right yeah that's that's a
2025.32|7.359|very good point so um for the for the
2029.88|6.919|for the so these are all planning data
2032.679|6.641|like high level planning um it is um so
2036.799|4.6|so so maybe let's let's just talk about
2039.32|5.599|two things so first of all the the
2041.399|6.081|Sorting results um the lowlevel policy
2044.919|5.0|is still using uh a traditional
2047.48|5.72|controller so it's using a policy called
2049.919|6.641|lava and that policy is trained down 68
2053.2|6.0|uh thousand episodes um the high level
2056.56|5.76|planning is probably easier than you
2059.2|5.8|think because it it only need to tell um
2062.32|4.319|so put the it's given command to the low
2065.0|2.76|LEL policy so it's basically only need
2066.639|3.841|to
2067.76|4.599|um put the red block into top left
2070.48|4.24|corner put another red block into top
2072.359|4.881|left corner so it's rather a quite
2074.72|5.0|Standard Auto regressive um Auto
2077.24|5.04|regressive like language modeling task
2079.72|5.399|the only thing you need to do is to
2082.28|4.839|determine what task is not finished yet
2085.119|3.681|so for example if the block is already
2087.119|4.121|in a corner it shouldn't call Lo of
2088.8|4.359|policy to move it to the corner again so
2091.24|4.359|it's it's rather like understand parsing
2093.159|4.561|the states and understanding the states
2095.599|4.561|so this high level policy only requires
2097.72|4.879|about like 50 to 100 demonstrations to
2100.16|4.04|learn so it's quite parameter efficient
2102.599|3.881|and in the future that's a very good
2104.2|4.879|question actually in the future a lot of
2106.48|4.8|uh these tasks can be taught in context
2109.079|4.561|so maybe we just demonstrate it once to
2111.28|3.48|the large language model then it knows
2113.64|4.68|how to do
2114.76|6.92|that how can how can the language model
2118.32|5.279|know like like which
2121.68|4.2|level this
2123.599|5.441|is yeah this is through human
2125.88|4.84|demonstration as well so human human on
2129.04|3.92|a low level can demonstrate low level
2130.72|4.879|policy by T operating a robot to do a
2132.96|7.159|certain task but on a high level it
2135.599|6.841|could also um it could also just uh give
2140.119|4.601|the low policy like imagine your control
2142.44|4.32|interface is through text and then you
2144.72|4.92|can you as a human you can also guide a
2146.76|5.52|low Lev policy to accomplish a task and
2149.64|5.04|then nothing thing uh can can then be
2152.28|4.88|used to to train a large language model
2154.68|4.0|so that's for the Sorting sorting block
2157.16|4.439|the second is a little bit more
2158.68|6.8|interesting because the planning steps
2161.599|6.561|are actually generated by pal so we
2165.48|5.96|essentially distilled pal plus this
2168.16|4.12|affordance model into pal e so that
2171.44|2.6|that's that's a little bit more
2172.28|4.52|interesting that's like using the AI
2174.04|5.6|data to boost strap itself that that
2176.8|5.279|that uh that one has about 3,000
2179.64|5.36|episodes also not not quite a lot U but
2182.079|5.441|it's able to learn complex planning
2185.0|5.56|Behavior replanning behavor your error
2187.52|6.96|recovery which I will show in this slide
2190.56|7.519|so with the paly as a high level planner
2194.48|5.32|we are able to do um pick the take the
2198.079|5.601|rice chips out of the
2199.8|7.44|drawer and uh there is a Twist which is
2203.68|6.2|um I will be messing with the robot and
2207.24|6.68|so as it put onto the onto counter I put
2209.88|6.36|it back to the drawer and as it uh um
2213.92|4.04|pick it up again and then I put it back
2216.24|4.24|again so it's able to understand the
2217.96|4.32|state it's able to understand my task is
2220.48|4.92|not finished I cannot proceed with the
2222.28|5.2|next task now after I don't mess it with
2225.4|5.12|mess with it anymore it's able to close
2227.48|7.68|a drawer and pick up the the bag of
2230.52|7.079|chips so um Tomy is able to combine
2235.16|5.48|affordance and planning in one model and
2237.599|3.961|do uh complex reasoning of of the scene
2240.64|3.88|and
2241.56|6.32|environment and interestingly we can use
2244.52|5.0|the exact same model checkpoint to do
2247.88|4.12|block sorting as well so this is the
2249.52|5.44|same model chech point it can not only
2252.0|7.48|reason about how to bring a b of chips
2254.96|7.84|to a user it can also th blocks so and
2259.48|6.599|it's also responding to a theal uh
2262.8|5.6|peration like if the user is uh putting
2266.079|5.401|the Block in the middle again it's able
2268.4|5.84|to recover from that so these are all
2271.48|4.119|coming from the same model and it can
2274.24|3.04|also tell
2275.599|5.161|joke
2277.28|6.48|so yeah this is the power of like uh uh
2280.76|5.4|like Vis Vision language models uh now
2283.76|4.48|we want to go a level deeper like these
2286.16|3.439|are all Vision language models that are
2288.24|3.4|used for planning or high level
2289.599|5.401|reasoning can we use them for low LEL
2291.64|5.92|control it turns out we can we can um
2295.0|4.48|and that's the rt2 work which is Vision
2297.56|4.32|language action model that transfer web
2299.48|7.119|knowledge to robotic control what can I
2301.88|8.239|do when when asked uh pick up the uh EX
2306.599|5.401|tin animal and it has a whole range of
2310.119|6.121|objects on the table it will pick up the
2312.0|7.04|dinosaur so it can link the extinct
2316.24|5.599|animal to dinosaur and to the action
2319.04|5.799|that pick the dinosaur up so it's really
2321.839|4.721|doing like this this emergent reasoning
2324.839|5.561|and also the manipulation in just the
2326.56|6.44|one model and by the way uh this robot
2330.4|5.36|hasn't seen any of these before in at
2333.0|4.76|least in the robot training data it it
2335.76|4.319|might have seen this in the internet
2337.76|5.24|catalog right but it has never seen it
2340.079|6.04|in the um in the robotics training data
2343.0|7.56|so uh it's it's quite interesting how we
2346.119|7.121|need to evaluate these robot nowadays um
2350.56|5.4|so in U when we evaluate language models
2353.24|4.32|to prevent uh data contamination every
2355.96|3.76|time you need to give it new questions
2357.56|4.559|because otherwise it might already in
2359.72|4.24|memorize it in in its training when we
2362.119|4.121|evaluate this robots we actually go to
2363.96|4.32|Dollar Store dollar store to buy all
2366.24|4.079|these toys to make sure it hasn't seen
2368.28|4.2|that before and as we run more
2370.319|4.201|evaluation maybe there will be some
2372.48|5.8|replication as well but as you can see
2374.52|5.04|it is able to understand um to pick up
2378.28|4.16|this dinosaur
2379.56|5.12|toy um how do we do that how did we do
2382.44|5.36|that so we start from a vision language
2384.68|5.76|model that is trained on internet scale
2387.8|5.559|data and then we also combine it with
2390.44|6.96|robotics action data uh which is the rt1
2393.359|6.76|data and we get rt2 and u we can dive
2397.4|5.04|deeper a little bit deeper into into A2
2400.119|4.761|so first what is a vision language Model
2402.44|6.24|A Vision language model is a Transformer
2404.88|9.479|is a Transformer that take in image and
2408.68|8.72|text and then output text so um we
2414.359|6.72|uh within Google there's a ver language
2417.4|6.04|model called P which is encoder decoder
2421.079|4.481|type of architecture it's basically
2423.44|4.399|having a viit to understand images and
2425.56|4.039|then a Transformer encoder um and the
2427.839|4.961|Transformer
2429.599|5.441|decoder um they Encompass both the
2432.8|4.16|visual and semantics to understand the
2435.04|5.76|world and in robotics we have to deal
2436.96|5.399|with a lot of both of these and the
2440.8|4.36|question is can we leverage the
2442.359|5.161|knowledge in the the the the uh Vision
2445.16|4.88|language models and apply them to
2447.52|4.64|robotics on the other hand we have the
2450.04|5.84|it1 uh if you want to learn more about
2452.16|7.76|rt1 you can listen to the previous um um
2455.88|7.239|episode of this cs25 by T so he give a
2459.92|7.159|detailed introduction on rt1 but the rt1
2463.119|5.561|is if you stand far enough um it is also
2467.079|4.841|a vision
2468.68|5.679|language to action or something model
2471.92|4.32|right it takes in a human instruction it
2474.359|3.96|takes in the current camera image the
2476.24|4.64|camera image pass through a film
2478.319|5.481|efficient net which is tokenized into 81
2480.88|4.52|tokens and then going to a token learner
2483.8|4.08|which compress everything into eight
2485.4|4.6|tokens and then there is a Transformer
2487.88|4.36|block leveraging a lot of self intention
2490.0|5.44|layer and then generate actions the
2492.24|6.68|action is also tokenized uh the robot
2495.44|7.84|have a um seven degree of
2498.92|6.919|Freedom um basically the the the and
2503.28|4.6|Factor has six degree of Freedom it's
2505.839|4.921|position and rotation and the Grier can
2507.88|5.32|open and close and there's another um
2510.76|5.359|Dimension representing terminate the
2513.2|5.8|episode or not terminating means my task
2516.119|6.921|is is already done and we discretize
2519.0|6.079|every um Dimension into 256 bins and
2523.04|4.64|then we do crossentropy loss on those
2525.079|5.201|bins so that's a rt1 architecture in a
2527.68|4.6|nutshell it's it's it's surp it's quite
2530.28|4.48|similar to a vision language model with
2532.28|4.4|different output tokens so it's rather
2534.76|4.0|natural that we just use a large
2536.68|4.96|pretrained Vision language model
2538.76|4.48|directly as policy we can use the pi or
2541.64|4.6|Pal as a
2543.24|5.079|policy and one question is how do we
2546.24|4.319|deal with actions when using pre-trained
2548.319|5.24|uh Vision language models and here is
2550.559|6.641|action representation that we use um the
2553.559|5.921|robot actions here are the eight uh
2557.2|4.399|dimensions and as I mentioned there's
2559.48|4.4|termination position change and rotation
2561.599|6.601|change and we discretize everything into
2563.88|5.959|2 256 bins we also have tried other
2568.2|4.359|alternative representations but they are
2569.839|4.48|not as good as just this like naive
2572.559|4.28|representation
2574.319|5.721|yes yeah
2576.839|5.72|yeah what is film effici oh the film
2580.04|4.84|efficient net is a pretrained
2582.559|5.361|convolutional neural network it's used
2584.88|4.88|to tokenize the images so the reason
2587.92|3.8|that we do this is um through some
2589.76|4.16|ablation study we can tokenize the image
2591.72|4.32|in different ways we can tokenize in
2593.92|5.0|rest net we can tokenize everything into
2596.04|5.76|rest net and we can tokenize using film
2598.92|5.04|efficient net film what it means is it
2601.8|5.559|also take into the language embedding
2603.96|8.32|and append it to the inter the layers of
2607.359|4.921|the of the rest net so we basically have
2612.92|7.72|like yeah that goes through
2617.079|3.561|this that's right that's
2622.8|5.48|right action that's right is action as
2625.76|6.4|in code the action is not in code the
2628.28|5.52|action is is in a is in text is in like
2632.16|2.919|basically what is shown here like this
2633.8|3.44|is the
2635.079|4.721|action
2637.24|4.68|it's eight numbers each number range
2639.8|5.6|from 0 to
2641.92|6.24|255 yeah and and maybe another note on
2645.4|5.88|the film rest net it's about how we
2648.16|5.6|tokenize the images and how we combine
2651.28|4.68|um Vision information and language
2653.76|4.079|information there are many ways to do
2655.96|4.599|that this is not the only way there is
2657.839|4.441|early fusion and late fusion and there
2660.559|3.881|is also cross attention you can
2662.28|4.559|basically tokenize your image just by
2664.44|4.879|itself and then you can have Lang and
2666.839|4.921|you use cross attention to combine the
2669.319|4.481|image and text representation so here we
2671.76|4.599|are using the this this model this is
2673.8|4.92|it1 for robotics so we do have a lot of
2676.359|4.24|considerations such as latency that's
2678.72|5.72|why we use this film resonant because
2680.599|5.361|it's super fast and it can output
2684.44|4.2|limited amount of tokens which we can
2685.96|7.399|further compress with token learner yeah
2688.64|4.719|yeah and this like aive like every
2693.88|7.04|sing right so it is agressive yeah and
2697.76|5.68|every time we use history of up to six
2700.92|4.76|six steps so every time you see this
2703.44|6.159|image right now and you see about two
2705.68|6.399|seconds of History before before it and
2709.599|4.601|um this will be the your your
2712.079|4.28|input yeah again if you have more
2714.2|4.96|questions about rt1 I recommend watching
2716.359|7.0|the uh previous episode
2719.16|7.36|um and U and here is all about rt2 so we
2723.359|5.2|can convert the the string of numbers um
2726.52|3.88|this will be our output of our
2728.559|3.721|Transformer uh which is a vision
2730.4|4.56|language model we tried other
2732.28|5.039|Alternatives uh such as floating numbers
2734.96|5.2|floating numbers is not super friendly
2737.319|5.681|to language model tokenizer because uh
2740.16|4.8|it has this decimal points we also tried
2743.0|3.8|the human language such as left or right
2744.96|3.879|it's more semantic representation but
2746.8|5.16|they cannot be directly executed on
2748.839|7.161|robot which is liation of this
2751.96|5.8|method um so if we commit to this action
2756.0|3.68|representation which is just a string of
2757.76|4.44|numbers we essentially get a vision
2759.68|6.639|language action model we tried different
2762.2|7.6|variants including polyx um this is a
2766.319|6.921|Pathways language and image model uh it
2769.8|6.0|can um there are five billion parameters
2773.24|4.68|variant and 55 billion parameter variant
2775.8|3.24|and we also tried P me which is 12
2777.92|4.32|billion
2779.04|6.44|parameters the the procedure that we did
2782.24|4.079|um to train this altit is via coine
2785.48|4.079|tuning
2786.319|6.401|coine tuning is to put the internet
2789.559|6.0|scale data and the robotic data together
2792.72|5.28|and then we fine tune it um on this
2795.559|5.601|mixture of data so that it doesn't it
2798.0|5.48|retains the internet scale
2801.16|4.36|knowledge um maybe that's also an
2803.48|3.839|artifact of our data is too small and
2805.52|3.799|not diverse enough so if you just a fine
2807.319|5.24|tune on robotics data it will quickly
2809.319|5.841|overfit and forgot about um all this
2812.559|5.76|paining mixture uh maybe it's it's a
2815.16|6.0|dynamic of scale so so uh we'll
2818.319|6.121|see uh at inference time how do we do
2821.16|5.959|this uh we basically we again we do this
2824.44|6.24|Auto regressively we have a an
2827.119|6.0|instruction um of um task and we format
2830.68|4.439|this as a question and answering task uh
2833.119|4.321|what should the robot do to achieve a
2835.119|4.281|certain task and the task is a strin
2837.44|4.879|that human give the robot for the robot
2839.4|7.159|to achieve and it also have the current
2842.319|6.921|observation um which is the um
2846.559|5.161|which is the um U robot observation the
2849.24|5.0|camera image RGB image it pass through
2851.72|5.56|AIT and then it pass through the large
2854.24|6.079|language model and then output uh a list
2857.28|5.68|of tokens so we leverage constraint
2860.319|7.201|decoding to make sure it always have
2862.96|6.8|eight numbers um and um because
2867.52|4.079|otherwise we cannot DET toonize it it's
2869.76|4.72|very easy for language model to just
2871.599|4.921|miss one number right so we do have some
2874.48|3.72|mechanism uh such as constraint the
2876.52|3.72|decoding and beam search to make sure
2878.2|4.76|the format is correct after we get a
2880.24|5.839|string of a numbers we DET toonize it to
2882.96|4.84|a delta T and Delta R which is the and
2886.079|4.401|effector Delta post and the robot can
2887.8|4.72|just directly run this on the robot
2890.48|4.359|after it run on the robot we repeat this
2892.52|3.92|process we get another New Image run
2894.839|4.121|through this process and get a new
2896.44|6.119|action and we repeat this process until
2898.96|5.84|a termination is decoded so um some
2902.559|5.121|people might be concerned that this is
2904.8|5.88|rather slow um it's it's in fact quite
2907.68|5.36|slow uh because it's a 12 12 billion
2910.68|5.36|parameters or five billion parameters uh
2913.04|5.44|we cannot run on a robot so we run on a
2916.04|5.079|TP cluster and the robot is quiring the
2918.48|5.839|TP cluster to get the numbers and apply
2921.119|5.0|it uh on on the robot so for the 12
2924.319|5.121|billion parameters we can actually run
2926.119|5.321|at 10 Hertz so it's quite fast for all
2929.44|5.0|of model we can run at at least three
2931.44|5.28|Hertz so that is that is sufficient for
2934.44|5.399|uh controlling a Rob
2936.72|6.56|robot and we see a lot of emerging
2939.839|5.641|skills that is not trained um that is
2943.28|4.96|not on the training set essentially uh
2945.48|4.56|as I just mentioned we are probing what
2948.24|3.4|this rt2 can do we actually don't know
2950.04|4.4|so we are trying to figure out what rt2
2951.64|5.439|can do so we we we test it with a lot of
2954.44|5.84|new tasks such as put a strawberry into
2957.079|5.441|the correct bow or move banana to
2960.28|5.839|Germany like just to test its
2962.52|5.88|understanding of symbols or Flags um
2966.119|5.041|pick land animal uh there's a horse
2968.4|5.399|there's octopus basically tested
2971.16|3.919|semantic reasoning and also uh low level
2973.799|5.881|manipulation
2975.079|7.561|skills and we uh divide the the tasks
2979.68|5.56|into simple understanding and reasoning
2982.64|6.159|and human recognition and average we
2985.24|6.68|found that uh with rt1 which is not
2988.799|6.04|trained on internet scale data we we do
2991.92|9.159|quite poorly in this emerging evaluation
2994.839|9.601|tasks and uh in uh in the um rt2
3001.079|5.361|variance which is co coine tuned on the
3004.44|4.159|internet data and on robotics data we do
3006.44|6.159|much better in these tasks and there is
3008.599|7.161|also um effect of scale so the R2 with a
3012.599|5.441|55 billion po um is performing better
3015.76|4.079|than the 12 billion py although they
3018.04|4.279|perform quite similarly for IND domain
3019.839|4.601|tasks so but the the generalization is
3022.319|4.441|kind of interesting it seems uh with
3024.44|5.119|larger scale you can
3026.76|6.4|better and here are some videos of the
3029.559|6.601|robot um achieving these tasks like
3033.16|6.08|moving the banana to a number put the
3036.16|5.72|strawberry in into the correct bow move
3039.24|5.8|move a Rubik's Cube to the water bottle
3041.88|5.439|but I'm speaking Chinese um moving the
3045.04|5.64|banana to a German flag so it's able to
3047.319|6.0|do all all of these very interesting
3050.68|5.879|tasks uh in terms of the quantitative
3053.319|5.52|evaluations uh we also found that um the
3056.559|4.481|altitude policy is quite robust to
3058.839|3.96|unseeing objects unseeing backgrounds
3061.04|3.88|and unseeing
3062.799|4.961|environments and here is another
3064.92|5.72|evidence of positive transfer so coine
3067.76|5.28|tune with vqa data outperforms fine
3070.64|5.32|tuning on robotics only and if you're
3073.04|4.72|train on robot data from scratch it it
3075.96|3.8|barely works it almost doesn't work
3077.76|4.48|because it overfits to robot data and
3079.76|6.599|our robot data is just too small so we
3082.24|6.64|do need uh to um do Co fine tuning or at
3086.359|5.041|least the fine tuning so it retains its
3088.88|5.32|internet skill knowledge this is also a
3091.4|5.32|recipe for how people would develop a
3094.2|4.44|domain specific Vision language model so
3096.72|3.839|you start from a very General Vision
3098.64|4.919|language model and you find you on your
3100.559|5.24|domain or you can coine tune with with
3103.559|5.601|your your specific domain data this is
3105.799|5.201|likely a problem that each vertical of
3109.16|4.199|uh artificial intelligence would uh
3111.0|5.04|would uh incur
3113.359|4.48|someday uh we can also test on other
3116.04|5.12|platforms like this shows some cross
3117.839|5.801|embodiment the rt2 PO 3B outperforms
3121.16|4.88|previous models in terms of moving
3123.64|5.76|blocks around a TOD
3126.04|5.039|environment so this is um and and in
3129.4|4.84|large language models we have this Chain
3131.079|5.441|of Thought reasoning which is um a
3134.24|4.52|method to elicit reasoning in in large
3136.52|3.559|language models um you can either do
3138.76|3.359|zero short CH of thought reasoning by
3140.079|4.28|say less thing step by step I'll give it
3142.119|4.48|examples of reasoning is is basically
3144.359|4.921|decoding more things and then come to
3146.599|6.041|the conclusion we can uh use a similar
3149.28|6.16|procedure for um the rt2 as well so in
3152.64|4.719|rt2 P me instead of directly decoding
3155.44|4.919|the actions we can actually decode a
3157.359|4.601|plan and then aend it with actions so
3160.359|3.76|this gives the language model and
3161.96|4.399|opportunity to understand a question or
3164.119|4.68|par a question differently it also giv
3166.359|4.681|us the the opportunity to reason about
3168.799|4.681|things a little bit for example if
3171.04|4.0|you'll say uh bring me a drink and it
3173.48|3.48|will say pick up seven up can because
3175.04|4.48|there's a seven up can on the on the
3176.96|4.639|table so we synthesized a couple hundred
3179.52|3.52|such examples using a large language
3181.599|3.881|model just by argumenting the
3183.04|4.68|instruction and then fine tune the ait2
3185.48|4.96|just for a couple hundred steps so it's
3187.72|4.56|between full fine-tuning and Inc context
3190.44|3.76|learning and is able to do some
3192.28|4.24|reasoning and some of the interesting
3194.2|4.359|reasoning tasks include I need to hammer
3196.52|5.16|a nail Which object from the scene might
3198.559|5.04|be useful and in the scene there is a a
3201.68|4.52|headphone there is a rock and there is a
3203.599|4.161|sticky note and the robot will say rocks
3206.2|4.2|and then generate actions to pick up the
3207.76|6.12|rock so it's interesting that it's able
3210.4|5.32|to do this of reasoning with with it2
3213.88|4.56|and here is a demonstration of some of
3215.72|5.399|the Chain of Thought reasoning with it2
3218.44|5.56|P me and the task is pick up the thing
3221.119|5.24|that is different from all other objects
3224.0|3.92|um and it pick up the the the chocolate
3226.359|4.041|because this is a snack and other things
3227.92|4.52|are the drink and I can also speak a
3230.4|4.439|different language and the plan would be
3232.44|4.639|to translate it into a language that is
3234.839|4.601|familiar with which is English and then
3237.079|2.361|do the
3239.92|4.04|task um there are also potentially
3242.64|3.159|failure case of the Chain of Thought
3243.96|3.28|reasoning so here I say move the green
3245.799|3.601|object together and as you can see the
3247.24|3.64|robot oscillates between the two green
3249.4|4.32|objects because there are rather two
3250.88|4.28|plants it could move the the can to the
3253.72|3.52|back of chips or it could move the back
3255.16|5.52|of chips to the can uh it oscillates
3257.24|5.359|between two plant until uh one action
3260.68|5.6|bring it to an object and it will commit
3262.599|5.881|to one of a plan rather than another
3266.28|4.039|it's not always guaranteed to work but
3268.48|4.04|it's quite interesting and it's also
3270.319|5.081|interesting that again we are testing
3272.52|6.24|the manipulation policy like how we test
3275.4|5.28|intelligence of human or animals or kids
3278.76|3.599|um because they they're they're getting
3280.68|4.04|more and more
3282.359|5.361|advanced um as a summary we have the
3284.72|4.879|vision language and action model um that
3287.72|4.399|is able to achieve improve improve the
3289.599|4.96|generalization it can do new tasks and
3292.119|5.121|operate new objects it can also do Chain
3294.559|5.24|of Thought reasoning and improving the
3297.24|4.92|underlying model um such as the the
3299.799|6.361|vision language model Itself by scaling
3302.16|6.439|it up um and um trained with internet
3306.16|4.159|scale data or trained with larger or
3308.599|3.641|higher quality internet scale data we
3310.319|4.441|can achieve better robot control which
3312.24|4.28|is quite amazing because robotics field
3314.76|3.28|has been traditionally developing quite
3316.52|3.36|slowly and is bounded by Hardware
3318.04|4.2|bounded by a lot of different things
3319.88|5.919|bounded by operation but now it seems we
3322.24|5.96|can piggyback on the development of the
3325.799|4.04|foundation model field and whatever they
3328.2|3.599|do will trickle down to our field as
3329.839|4.641|well and the future will be to increase
3331.799|5.161|the motion diversity and extent uh on
3334.48|4.44|the Chain of Thought reasoning
3336.96|5.599|capability and many
3338.92|5.52|more and uh um so there's another
3342.559|4.04|example of positive transfer which you
3344.44|4.48|you might have seen recently uh so so
3346.599|3.48|far I've been talking about uh scaling
3348.92|3.96|differently right I've been talking
3350.079|4.72|about don't scale robotics data um and
3352.88|4.28|scale other data that's because robotics
3354.799|4.401|data data is so hard to collect and and
3357.16|5.12|the purpose is not to avoid collecting
3359.2|5.359|robotics data it's to uh develop a
3362.28|4.44|recipe that you can do more with limited
3364.559|5.121|robotics data however there's also an
3366.72|6.399|effort from our team and the the entire
3369.68|5.919|robotics field uh to scale up the robot
3373.119|4.761|data collection which is called the open
3375.599|5.24|X embodiment and the model train is
3377.88|6.199|called RTX robotics Transformer X it's
3380.839|6.641|basically 22 type of embodiments and two
3384.079|4.96|uh 57 two skills and 60 data sets pulled
3387.48|3.8|all together so this will be the
3389.039|4.56|ultimate data set we can use to study
3391.28|4.799|positive transfer and the scale to to
3393.599|5.161|study this joint
3396.079|8.441|scaling and um there are already
3398.76|7.64|evidences of uh positive transfer so um
3404.52|4.519|we pulled all the data together from all
3406.4|5.08|these labs and find a common action
3409.039|4.52|representation that we can use to train
3411.48|4.44|a robotic Transformer and we have
3413.559|6.321|already found this a jointly trained
3415.92|6.0|model can outperform task specific model
3419.88|4.52|uh that is developed in in each of the
3421.92|6.119|lab so there is some benefits in pulling
3424.4|7.0|all the data together so um scaling
3428.039|5.641|robot data is also quite
3431.4|4.32|important so the summary for this part
3433.68|4.76|is that we are having a model
3435.72|4.76|consolidation we can now do the high
3438.44|4.04|level reasoning and load of control in
3440.48|4.72|one model and the load of control part
3442.48|5.68|is what excites me because it's so far
3445.2|5.599|away from the traditional language model
3448.16|5.159|U domain it's it's it's so different and
3450.799|4.681|it so shows science of life that we can
3453.319|5.161|trickle down a lot more than we used to
3455.48|4.28|think uh is possible and we can scale
3458.48|3.8|the pre-training of vision language
3459.76|4.4|models as well as scaling robotics data
3462.28|4.68|and we observe more and more positive
3464.16|4.919|transfer a model benefiting from diverse
3466.96|5.56|joint training across internet scale
3469.079|3.441|language vision and vision language
3473.0|5.76|domains all right so um I noticed that
3476.48|4.559|we are close to running out of time so I
3478.76|3.88|will just very quickly go through the
3481.039|4.361|second part which I think is also
3482.64|5.32|interesting it is to find new interfaces
3485.4|5.199|of language models but I would only talk
3487.96|4.839|at a very high level uh so language
3490.599|4.041|models as we can see can directly output
3492.799|5.161|action tokens if we found action
3494.64|5.159|representation so we can treat action as
3497.96|2.96|yet another language to the language
3499.799|2.641|model so language model can do
3500.92|3.08|translation so it should be able to
3502.44|3.0|generate action as well but that
3504.0|3.52|requires f
3505.44|4.0|can we do can we do it without fine
3507.52|5.279|tuning or can we generate more
3509.44|6.919|expressive actions that is beyond this
3512.799|5.441|the scope of fine tuning so um that is
3516.359|4.44|about finding the right interface so
3518.24|4.359|previously we have already established
3520.799|3.721|that language model doesn't have an
3522.599|4.72|action interface if it has an action
3524.52|5.24|interface it's it's not as
3527.319|4.641|effective so what is the best interface
3529.76|5.48|between language and low LEL actions I
3531.96|6.04|would argue the best interface um
3535.24|6.68|between language model and the Loos loo
3538.0|6.599|actions is reward functions and reward
3541.92|4.76|functions is universal it it has been
3544.599|4.121|used in reinforcement learning and it's
3546.68|4.52|also a repar
3548.72|4.68|reparameterization of actions what is
3551.2|5.639|action let me let's see if I want to
3553.4|5.0|pick up this uh bottle and I can say
3556.839|3.881|what what is a skill a skill is a
3558.4|4.32|mapping between my observation and my
3560.72|3.72|action so the mapping between my
3562.72|2.48|observation and action can be seen as a
3564.44|2.56|scale
3565.2|4.56|but a skill can have alternative
3567.0|5.319|definition which is a set of constraints
3569.76|4.68|and a set of objectives so picking up
3572.319|5.24|the bottle means the bottle is in my
3574.44|5.2|right hand and the bottle is off is off
3577.559|4.121|a supporting surface that means picking
3579.64|4.6|up and how do I pick it up doesn't
3581.68|4.84|really matter uh that's a more kind of
3584.24|4.599|uh to its broader sense a definition of
3586.52|3.88|skills it's more transferable between
3588.839|5.0|different different
3590.4|6.08|skills and um that and the constraints
3593.839|6.441|and objectives can be represented as
3596.48|6.68|rewards so we can ask language model to
3600.28|4.36|generate these reward functions and then
3603.16|3.399|uh there's Optimizer it could be
3604.64|5.24|reinforced learning or it could be model
3606.559|6.961|predictive control uh that optimize for
3609.88|6.08|those rewards and then um run it on the
3613.52|5.2|robot so what is in the reward
3615.96|5.56|translator it is uh let's let's open a
3618.72|5.2|box so the reward translator basically
3621.52|5.48|is is a two-stage process it's using the
3623.92|5.08|same language model and it is using two
3627.0|4.559|different prompts so the motion
3629.0|4.839|description basically describes the the
3631.559|4.601|motion so just now we we found that the
3633.839|4.96|language model can can output a
3636.16|5.52|description of how a robot doc should
3638.799|5.0|stand up but it's not able to achieve
3641.68|3.56|that but the the motion description is
3643.799|3.8|still sensible it still makes sense it
3645.24|5.319|gives you the right thing so we're just
3647.599|4.681|a like generate this motion description
3650.559|4.28|and then we have a reward translator
3652.28|5.68|reward coder that translate this motion
3654.839|5.601|description into a piece of code uh that
3657.96|3.44|is uh representing that is representing
3660.44|3.76|reward
3661.4|6.08|functions and these reward functions
3664.2|5.44|cannot be directly executed on the robot
3667.48|4.8|but it can go through a optimization
3669.64|5.32|process to to learn how to achieve those
3672.28|4.799|reward functions so we're using reward
3674.96|5.119|as the the interface between language
3677.079|5.601|model and a lot of controller and for
3680.079|5.0|the low controller we're using modal MPC
3682.68|4.28|which is a model predicted control uh
3685.079|4.601|model predict control algorithm it's
3686.96|4.92|basically uh a blackbox controller it
3689.68|5.24|samples a lot of tra trajectories and
3691.88|6.479|find one that optimize your
3694.92|5.879|reward and we test it on a robot dog a
3698.359|4.801|quadr robot essentially and a dextrus
3700.799|4.8|manipulator so the dextrus manipulator
3703.16|6.919|has an arm of six or seven degree of
3705.599|6.281|freedom and a hand um it's impossible to
3710.079|6.441|control it because it has so many degre
3711.88|7.6|Freedom so um it's highly um challenging
3716.52|5.599|so just to Showcase some of the examples
3719.48|7.24|I admitted the motion description part I
3722.119|7.401|only output the um the uh reward code
3726.72|5.16|part so it seems that the language model
3729.52|5.559|is able to generate the right reward
3731.88|4.719|functions to make the robot stand up on
3735.079|4.04|two back feet like a
3736.599|3.921|human all right and then now we are a
3739.119|3.68|little bit more ambitious like we know
3740.52|4.2|it can stand up uh can we make the robot
3742.799|4.32|do a moon walk while standing up like
3744.72|4.16|this so moonwalk is from Michael Jackson
3747.119|4.44|and it's very challenging how do we make
3748.88|5.56|the robot to do it so it generate the
3751.559|6.681|motion description and gener the reward
3754.44|6.639|code but the motion is uh not not so
3758.24|4.319|correct not exactly what we want the
3761.079|3.28|nice thing about using a language model
3762.559|4.28|and using the reward function is that
3764.359|5.041|you can coach the robot you can go back
3766.839|5.401|and explain what went wrong and ask the
3769.4|4.36|language model to fix it so now we can
3772.24|3.559|actually say you're you're you're being
3773.76|4.559|very patient you say moonwalk means a
3775.799|4.841|robot should mo mo walk backward while
3778.319|5.28|the feet swing as if they are moving
3780.64|5.04|forward uh such a such a great uh
3783.599|4.641|explanation kudos to my colleague and
3785.68|5.52|correct your answer and also make it
3788.24|4.96|work at a speed of 0.5 meters per second
3791.2|3.72|and after you like being very patient
3793.2|4.2|and give it the right instruction it's
3794.92|5.0|able to modify the reward the motion
3797.4|5.08|descriptor descriptor and also generate
3799.92|5.04|the right set of rewards to make this
3802.48|5.4|happen and now you can teach robot to do
3804.96|3.8|moonwalk just by using the language as
3807.88|3.04|an
3808.76|4.96|interface and one day we'll be able to
3810.92|6.159|do this on the real robot as well yes so
3813.72|3.359|previous section you show
3818.279|5.241|how numbers and your constra them toate
3821.48|3.76|numbers here how do you prevent it from
3823.52|4.319|Just
3825.24|5.68|hallucinating right so uh that's a great
3827.839|5.921|question um in in in this work we are
3830.92|5.919|not preventing it hallucination to do
3833.76|5.799|hallucination in a programmatic way we
3836.839|6.44|have a a set of system prompts or a set
3839.559|5.921|of rules that is explaining the API
3843.279|5.8|after all the reward functions need to
3845.48|6.639|be able to be compiled by the optimizer
3849.079|5.601|and then like uh after yeah so we do
3852.119|4.361|need to have some check uh what's more
3854.68|4.0|if it doesn't compile we can just give
3856.48|3.76|the error message to the language model
3858.68|3.52|it doesn't have to propagate all the way
3860.24|4.039|to the motion descriptor it can stay at
3862.2|3.76|the reward coder if there are errors
3864.279|3.361|please fix it so after that you should
3865.96|4.92|be able to fix
3867.64|5.399|it um we can also chain multiple tasks
3870.88|5.399|together uh using this framework we can
3873.039|5.641|say open the drawer uh take the the
3876.279|4.441|Apple put it into the drawer and close
3878.68|5.32|the drawer and it's it will be able to
3880.72|5.639|do that so we tried that just using
3884.0|5.4|reward coder is not good enough it's
3886.359|5.601|rather our two-stage prompt is us really
3889.4|4.8|really helpful uh I think that's another
3891.96|4.599|inspiration for other fields like when
3894.2|4.399|your domain is too different from
3896.559|3.921|language domain maybe it would be good
3898.599|3.881|to find an intermediate representation
3900.48|4.079|and ask the language model to explain in
3902.48|5.72|that intermediate representation before
3904.559|6.161|directly go to a more obscure uh
3908.2|4.04|representation and uh uh finally we want
3910.72|4.24|to transfer this to the real world but
3912.24|5.039|but there is a challenge in simulation
3914.96|6.359|it might generate actions that are too
3917.279|5.681|dextrous like this um this uh uh this
3921.319|3.361|thing is not possible to do in the real
3922.96|4.359|world so
3924.68|5.32|we add a few more regular Riser terms to
3927.319|5.401|stabilize the motion and we also run
3930.0|5.72|some State estimation on the real robot
3932.72|5.24|so that they um they understand uh where
3935.72|4.639|is the the cubes and then we can in the
3937.96|4.2|simulation grab the motion and then
3940.359|4.72|achieve it in the real world so here are
3942.16|5.28|some of the execution in the real world
3945.079|5.361|so you can say pick up the Rubik's Cube
3947.44|5.28|and it will generate the motion to pick
3950.44|4.599|up the Rubik SCP and this is quite
3952.72|6.52|different from rt2 the motion are quite
3955.039|8.0|smooth um it's uh it's quite fast it's
3959.24|7.96|much faster than uh three Herz so here
3963.039|8.601|it can do 10 Hertz or even uh even 30
3967.2|4.44|Hertz so it's comparable with
3971.76|4.68|human all right so that's a language to
3974.559|3.961|reward there's one last thing that I
3976.44|5.359|want to talk about in terms of finding
3978.52|5.24|the a new interface so a lot of time we
3981.799|4.441|have been thinking about language model
3983.76|5.4|as a semantic engine a semantic machine
3986.24|5.039|it understands semantics so for example
3989.16|4.28|you say the the the student takes out
3991.279|4.32|the student takes out the book you will
3993.44|4.72|say book like language model is able to
3995.599|4.48|reason about such a sequence but if you
3998.16|4.32|do lowlevel patterns like if you just
4000.079|4.28|give it the Obscure numbers can you do
4002.48|3.799|what can you do like it's it's actually
4004.359|4.881|a lowlevel interface and we can open up
4006.279|5.76|the lowle interface to uh off language
4009.24|4.599|model and ask it to do robotics tasks so
4012.039|3.76|in this paper large language language
4013.839|4.161|model model as general pattern machines
4015.799|4.921|we explore using the lowlevel interface
4018.0|5.039|of a large language model essentially
4020.72|4.48|asking it to reason about different
4023.039|4.121|sequences and is surprisingly quite
4025.2|6.599|effective and it can solve tasks like
4027.16|6.72|the The Arc Challenge and the pcfg um
4031.799|3.681|and it can even do sequence Improvement
4033.88|2.959|so I will dig a little bit into sequence
4035.48|4.319|Improvement because that's quite
4036.839|4.48|relevant to robotics so sequence
4039.799|4.24|Improvement is that you prompt the
4041.319|5.401|language model with State action and
4044.039|6.04|reward tupos and you Pro just prompt it
4046.72|5.28|with higher reward and see if it can
4050.079|4.561|generate actions that achieve the higher
4052.0|5.4|reward so it's doing reinforc learning
4054.64|4.88|or reinforc learning like thing but in
4057.4|5.32|context so this is quite amazing so
4059.52|5.44|previously you would need a a dedicated
4062.72|4.559|algorithm collecting data replay buffer
4064.96|3.52|to do this reinforc learning but now you
4067.279|3.201|can just build everything in the
4068.48|4.16|language model context by leveraging the
4070.48|5.0|lowle interface of a language
4072.64|4.6|model and with that we can actually do
4075.48|3.2|something like clicker training so if
4077.24|3.68|you're are not very familiar with
4078.68|5.56|clicker training is how you can do you
4080.92|5.28|can U you can have a dog and you you can
4084.24|6.68|um when it does the right thing you give
4086.2|8.56|it a reward by by right so you can uh so
4090.92|7.12|the clicker training is um giving the
4094.76|4.959|the agent a reward and uh we we can now
4098.04|4.639|use clicker training to train robots as
4099.719|4.841|well so here uh the robot is exploring
4102.679|3.64|but I would give click it does the right
4104.56|5.52|thing or towards the right direction and
4106.319|5.721|over time uh it will be able to push the
4110.08|4.719|back of chips which is the objective of
4112.04|5.4|this training so you can do this entire
4114.799|5.761|uh decision Transformer like operation
4117.44|4.6|but purely in context by just give the
4120.56|4.159|language Model A bunch of patterns and
4122.04|5.04|ask you to figure out what is what is
4124.719|4.48|what is the regularity of this sequence
4127.08|5.04|and this way it can generate new actions
4129.199|7.04|to improve previous
4132.12|6.32|sequence all right uh um so for the
4136.239|5.56|language model uh we can find new
4138.44|5.96|interfaces that are more uh suitable for
4141.799|5.04|teaching it low level skills uh reward
4144.4|3.839|is a bridge and of language model and
4146.839|4.561|low level control and we can fully
4148.239|5.361|leverage it as a universal interface and
4151.4|5.56|you can optimize in real
4153.6|5.719|time um sometimes it outperforms
4156.96|4.759|generating action directly so it uh
4159.319|4.88|really motivates to use the uh reward
4161.719|4.04|functions as interface and the language
4164.199|3.12|model as a general pattern machines we
4165.759|3.4|can use language model beyond the
4167.319|4.48|semantic tasks we can ask it to reason
4169.159|4.801|low level things and also robotics as a
4171.799|4.081|do domain Rich of sequence
4173.96|3.879|transformation and sequence completion
4175.88|4.319|and sequence Improvement tasks so we can
4177.839|4.36|really study the the lower level
4180.199|5.921|mechanisms of language
4182.199|6.761|models and the key takeaway is that um
4186.12|5.8|for for this talk is that we are seeing
4188.96|4.799|more and more use of foundation models
4191.92|5.16|not only on the semantic reasoning side
4193.759|5.081|side of Robotics but more on the dextrus
4197.08|4.72|on the generating actions on the lower
4198.84|5.6|level embod embod and intelligence side
4201.8|4.879|of Robotics and we can we need to
4204.44|4.04|rethink the scaling law of Robotics and
4206.679|4.0|Transformer how do we scale it with
4208.48|4.199|limited amount of data we have a new
4210.679|4.321|recipe for scaling robot model and data
4212.679|4.761|in rt2 which shows that you can do more
4215.0|4.0|with the same data with essentially rt1
4217.44|3.88|data plus internet data you can
4219.0|4.88|generalize to a lot more things in RTX
4221.32|4.2|shows that you can do a lot more with
4223.88|3.2|more data there is also benefits to
4225.52|3.56|collecting more robotics data and
4227.08|3.88|there's positive transfers everywhere
4229.08|4.2|and apart to uh in terms of new
4230.96|5.04|interfaces for language models I think
4233.28|4.56|it's worth uh for the robotics field to
4236.0|4.04|think about developing new and lower
4237.84|5.359|level interface to language models which
4240.04|5.04|facilitate uh learning low level skills
4243.199|3.921|with that I I would like to conclude my
4245.08|4.32|talk and if you find it interesting
4247.12|4.76|there are a lot of references for you to
4249.4|6.16|to uh look into and special thanks to my
4251.88|5.68|team uh Google mind Robo robotics team
4255.56|4.56|so we're at a Forefront of developing
4257.56|5.92|Foundation models for Robotics and stay
4260.12|3.36|tuned for more in the future thank
4268.08|6.72|you yes you mentioned that FL numbers
4271.719|5.841|are difficult for large language model
4274.8|5.56|but if you're just generating the action
4277.56|5.159|tokens like no you know no rocks or
4280.36|4.68|whatever you had an example why don't
4282.719|5.881|you just have like linear layer appended
4285.04|5.24|to the you the Transformer that just
4288.6|5.079|numbers
4290.28|7.24|from whatever yeah the the question is
4293.679|5.441|that uh um if the if we are uh the large
4297.52|3.4|language models have difficulty
4299.12|3.48|understanding numbers why don't we use a
4300.92|5.0|linear layer to outut the action
4302.6|5.48|directly I think so language models are
4305.92|5.16|difficult to understand numbers but
4308.08|5.079|sometimes we still want it to kind of
4311.08|3.36|bring in Knowledge from the pre-training
4313.159|4.721|mixture
4314.44|5.96|like if if um I want if I have a new
4317.88|5.319|layer like that that new layer is not
4320.4|4.6|present in the pre training so how do I
4323.199|3.401|expect it to transfer I think that's
4325.0|3.92|that's an interesting question but at
4326.6|4.28|the same time I don't necessarily think
4328.92|4.2|using the raw numbers is a right
4330.88|4.0|interface there we probably could do
4333.12|4.4|some action representation learning to
4334.88|5.0|learn a representation and the language
4337.52|4.52|model can output that representation so
4339.88|4.12|we're still trying to figure out what is
4342.04|4.04|the uh right representation
4344.0|4.36|so among the representations that we
4346.08|6.079|have tried before like decimal numbers
4348.36|6.44|Flo numbers uh extra tokens we find just
4352.159|4.961|using numbers or actual tokens would be
4354.8|5.32|would be good
4357.12|3.0|enough
4372.44|3.0|yes
4377.239|5.561|pring yeah um I think both directions
4380.56|4.88|are are worth exploring there are
4382.8|4.839|different advantages of generating like
4385.44|4.44|generating action directly I think it's
4387.639|5.52|it it borrows the auto regressive nature
4389.88|5.759|of like um language modeling and it's it
4393.159|5.241|aligns with a lot of other tasks like
4395.639|5.161|visual question answering really well
4398.4|4.319|the limitation is that then uh when
4400.8|4.399|you're generating actions it's heavily
4402.719|4.681|regularized can you generate dextrous
4405.199|4.601|actions that is so out of distribution
4407.4|5.319|that is kind of difficult the language
4409.8|4.919|to reward actually brings a a page of
4412.719|4.401|the book of traditional robotics like
4414.719|6.0|right this optimization based or model
4417.12|6.96|predicted control so and you can also
4420.719|6.081|take into let's say safety constraints
4424.08|6.04|uh more more more easily it can generate
4426.8|5.24|more diverse actions maybe one recipe is
4430.12|4.16|to generate a lot of data with the
4432.04|5.199|language to reward system and distill
4434.28|5.56|them into a Transformer because then
4437.239|5.48|you're imbuing your large language model
4439.84|4.839|with all this other desirable uh the
4442.719|4.321|language through World itself I don't
4444.679|4.401|know how scalable it is like it's we're
4447.04|5.48|not fine tuning language model so maybe
4449.08|5.28|you are limited to what the uh you are
4452.52|4.44|at the mercy of the training data of the
4454.36|5.04|language model the language model can do
4456.96|5.759|uh moonwalk because it it knows what
4459.4|4.68|moonwalk is it roughly knows how that uh
4462.719|3.161|like how to do that
4464.08|3.559|but if you want to scale to completely
4465.88|3.48|new things maybe you can use the
4467.639|4.841|language to world to boost drop your
4469.36|5.12|data generation and then put into like
4472.48|4.719|the other
4474.48|5.64|policy
4477.199|6.121|okay what's the next directions gos it's
4480.12|3.2|like the language
4484.4|4.72|the yeah I think that's a good question
4486.8|4.52|so this the scaling the the scaling
4489.12|4.519|being the end of the lecture uh that has
4491.32|4.76|a joke but as as I'm I'm being quite
4493.639|5.841|serious like it's actually a promising
4496.08|7.32|recipe so uh we have been we have been
4499.48|6.44|um everybody is believing in the power
4503.4|4.4|of the scaling rule so just by giving it
4505.92|4.279|more data giving it more compute you
4507.8|7.2|will see interesting kind of
4510.199|7.641|capabilities coming out yeah Al gb2 GB
4515.0|6.12|big J so do you think like we ready for
4517.84|7.24|robotics to have that Chum we can you
4521.12|7.72|see the cap yeah um I still I still
4525.08|5.8|think we are not quite like we don't
4528.84|5.52|quite have enough data I think that's
4530.88|6.08|still probably the biggest bottleneck so
4534.36|4.879|we are trying to find ways to do more
4536.96|4.92|with limited data and we are trying to
4539.239|4.801|collect more data and I think it needs
4541.88|5.12|some time for for us to accumulate
4544.04|5.28|enough data and currently I say uh we
4547.0|4.96|have science of life for positive
4549.32|3.879|transfer but in in language models
4551.96|3.679|people don't talk about positive
4553.199|5.281|transfers anymore because it's so common
4555.639|6.441|place right you you see it everywhere um
4558.48|5.719|and robot robotics is not at that stage
4562.08|5.68|yet yeah how much is your te thinking
4564.199|6.881|about safety and Alignment yeah are you
4567.76|5.28|just like right now like relying on kind
4571.08|4.0|of the ethics that emerge from the large
4573.04|4.639|language models like it won't you know
4575.08|4.599|tell you to kill to achieve yeah that's
4577.679|4.601|a very good question actually we take
4579.679|4.841|safety very very seriously because all
4582.28|5.6|of the the domains of developing
4584.52|6.4|language models um it doesn't have
4587.88|6.48|direct like impact on on the physical
4590.92|6.08|world but here like um it could have
4594.36|5.08|potential harm to to human and to the
4597.0|5.52|environment and Gary Marcus actually
4599.44|6.16|give a comment to previously to our work
4602.52|4.44|that what if you say U bring bring out a
4605.6|3.24|bow feed the cat and put it in the
4606.96|4.08|dishwasher where it put the cat in the
4608.84|5.0|dishwasher right if it misunderstand
4611.04|7.56|actually it will have a a catastrophic
4613.84|7.28|uh um failure case um we we take uh
4618.6|5.16|safety carefully by designing like
4621.12|6.039|hardware and software safety layers and
4623.76|6.439|uh there are also some constitutional
4627.159|5.761|like safety um uh thing that is coming
4630.199|5.321|out sometime soon I cannot tell much
4632.92|5.239|details right now but uh sometime soon
4635.52|5.44|we releas some work is it something like
4638.159|6.201|if there's a human like just don't
4640.96|5.759|interact well know I think it's a little
4644.36|4.76|bit more nuanced and more detailed than
4646.719|5.041|that yeah but we do take safety quite
4649.12|4.2|seriously and in some of our experiments
4651.76|3.56|actually the robot finger would break
4653.32|4.24|off because it cannot apply enough Force
4655.32|4.68|to an environment so that's just yet
4657.56|7.0|another way of ensuring
4660.0|4.56|safety can we have some like Vis
4668.0|7.0|mod and maybe this is kind of like but
4675.159|3.921|right right yeah I think it it would be
4684.08|4.119|possible thank you for cool
4692.159|3.0|cool