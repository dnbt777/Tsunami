start_time|end_time|text
1.28|3.84| Yes, in the previous video, we discussed what learning rate
5.14|4.02| decay is and why it might be useful. Let's now see how we can
9.16|5.36| do this in practice in pytorch. So first, the manual way, the
14.52|3.36| tedious way, we can define our own function to do learning rate
17.88|3.68| decay in pytorch. So here, I defined a function called the
21.56|3.68| just learning rate. And this is implementing the exponential
25.24|3.7| decay that we talked about in the last video. So what it is
28.94|4.62| doing is it's every 10th epoch. So this line may read a little
33.56|5.72| bit counter intuitively, because this modulus operator is
39.28|4.4| essentially doing a division and then returning the remainder of
43.68|5.48| that division. So if I have a number that is not divisible by
49.16|3.96| 10, it will return the remainder. And here, it's
53.12|3.76| essentially saying if there's no remainder, then do this. So it's
56.88|5.2| essentially doing something every 10 epochs. So if the
62.08|4.2| number is divisible by 10, do this. And what I'm doing here is
66.28|5.2| I'm essentially implementing the exponential decay, and I'm
71.48|4.76| applying it to the learning rate. So I implemented this in a
76.24|2.92| way here that looks a little bit complicated. That is because
79.16|3.94| there are different optimizers. And some optimizers have a
83.1|2.5| different learning rates for different parameter groups and so
85.6|4.92| forth. So this will essentially take care of updating all the
90.54|3.52| learning rates that are relevant. Alright, so this would
94.06|3.94| be the tedious way and then you can call this function after
98.0|7.32| every epoch. So if you have a for loop so far, epoch in range,
106.84|6.88| num epochs or something like that. And then for each, I'm not
113.72|4.32| writing it out, but for each mini batch, essentially, then
118.04|3.56| you do your training, and you would have this function for
121.6|3.04| each epoch, but not for each minute bit. So what you would
124.64|7.4| put it essentially here, like, just learning rate, and so
132.04|2.68| forth. I can't write down here because I have my color bar
134.72|3.56| here. But he would put essentially the function here,
138.72|3.7| adjust learning rate with the optimizers input, the epoch
142.42|2.98| number, the initial learning rate and the decay rate, and
145.4|3.88| then it will update every 10th epoch. However, this is just
149.28|3.2| the other manual way. So you can see how you could implement it
152.48|3.12| yourself if you have an idea for a new learning rate. But in
155.6|4.22| practice, if you want to just use an existing common way of
159.82|3.02| doing learning rate decay, you can use one of the built in
162.84|3.68| functions in pytorch. So for that, I recommend going to this
166.52|3.64| website, they have a selection of different learning rate
170.16|4.02| schedulers. Here's just an example. That is a very generic
174.18|4.9| one. So here, I chose a screenshot of this particular
179.08|2.86| example, because it came with a practical example. So I didn't
181.94|4.48| have to retype it. So how this works is essentially that you
186.42|3.1| initialize the scheduler. So here, it's a lambda learning
189.52|3.44| rate scheduler, you give it the optimizer, and then these
192.96|4.76| values. And then you iterate over the epochs. And then for
197.72|4.36| each epoch, you call this dot step, essentially. And then you
202.08|2.32| have your train function and validation function that we
204.56|3.3| usually use in this class, too. So essentially, you have two
207.86|4.06| steps, only one step is initializing it. And the second
211.92|4.86| step is essentially using it. And that's it. And you can do
216.78|5.18| that with any type of scheduler they have on that website. So
221.96|3.54| here, I'm showing you now how that works with the exponential
225.5|4.44| learning rate scheduler. So here, I have first an
229.94|3.9| initialization of a model, then I initialize my optimizer here,
233.84|3.24| I'm using a stochastic gradient descent optimizer, and then I'm
237.08|4.4| initializing my scheduler. So here, notice I'm giving it the
241.48|6.8| optimizer as input. And then I have my main training loop. So
248.3|3.06| five epochs, set my model into training mode, and then I
251.36|5.12| iterate over the mini batches. And this is our typical model
256.48|5.8| training. So we call the model, compute the loss, set the
262.28|4.76| gradients to zero to back propagation. Yeah, do the
267.04|3.76| gradient. So here, this is the applying the gradient. So
271.0|2.36| backward, we'll compute the gradients. Here, we are doing
273.36|3.8| the gradient update. Here's some logging. And then notice after
277.16|3.68| the epoch, that's where we call the scheduler step. But you can
280.84|4.08| also actually put it up here if you want to. So it doesn't
284.92|0.6| really matter.
287.48|3.56| Alright, let's now talk about my favorite way of learning rate
291.04|4.56| decay. So I'm not using learning rate decay that often, because I
295.6|3.52| usually find that Adam, an optimizer that we will be
299.16|3.44| discussing later, works pretty well out of the box. But yeah,
302.6|4.0| sometimes I compare it to SGD and learning rate decay. And I
306.6|2.52| find it actually, yeah, this method works actually best
309.12|3.64| compared to other methods I've tried. And yeah, I got this from
312.78|4.38| a paper in 2016 on deep residual learning, which is the paper
317.16|4.04| that originally proposed the rest net, which we will be
321.2|3.76| talking about also next week, it's among the most popular
325.04|4.36| convolutional networks here. But yeah, here, I'm not sure if they
329.4|3.36| proposed this learning rate decay method for the first time.
332.94|2.66| But yeah, that's at least where I got the inspiration for that.
335.6|4.96| So what they do is on they use regular SGD with a mini batch
340.56|4.24| size of 256. And then they start with a learning rate of point
344.84|3.44| one, which is actually quite large for SGD. But yeah, they
348.28|4.64| start with point one and then divided by 10 every time then
352.96|5.2| when the error plateaus. So essentially, if they do the
358.16|3.8| training and notice that the loss doesn't further go down, I
361.96|3.4| mean, of course, there's some wiggle room. So if it stays
365.36|3.88| stays, let's say within a certain margin, then they divide
369.24|3.32| the learning rate by 10. So yeah, that's the whole trick.
372.56|5.84| And they also actually use weight decay of point 001. So
378.44|2.88| weight decay, we discussed this in the previous lecture, that's
381.36|3.28| essentially L two regularization, and they use a
384.64|3.6| momentum of point nine and momentum I will explain in the
388.24|5.64| next video. But let me show you how this works in practice in
393.88|3.76| pytorch. So I prepared a code example. So I put it here as
397.96|4.48| scheduler, I, as an ipython or Jupyter Notebook. And I will
402.44|3.28| share that on the repository, like always. So I will include a
405.72|6.36| link under the video. And yeah, so what I'm doing here is I'm
412.08|4.2| initializing the multi layer perception from last week, where
416.28|5.08| we used batch norm and dropout. And I'm now using SGD with a
421.36|4.96| learning rate of point one. And here, this is the learning rate
426.32|4.52| scheduler from pytorch that can be used, similar to what they
430.84|4.4| proposed on the previous slide, where they have basically the
435.68|3.96| monitoring of the plateauing error, and the divide by 10
439.68|3.28| every time the error plateaus. So this is essentially this
443.0|4.0| learning rate scheduler here. So I'm providing it with the
447.0|4.72| optimizer. And the factor is essentially by how much we divide
451.72|4.08| it. So point one means times point one and times point one is
455.8|3.84| essentially dividing by 10, like they describe in the paper. But
459.64|2.16| yeah, you can of course change that it's another hyper
461.8|4.76| parameter. Then there's a mode. So the mode, it really depends
466.56|5.84| on where or what you apply this to. So you can apply this to
472.4|5.88| anything you like during training. So here, they say, error,
478.32|2.96| it's not quite clear what they mean by error, it could be
481.28|2.36| either the loss or the classification error.
484.0|4.28| Personally, I tried on different things. And I find it usually
488.28|4.6| works best if I do this on the arrow on the validation set or
492.88|3.34| accuracy on the validation set. So I usually like to work with
496.24|2.92| accuracy instead of error. Because I know it's more
499.16|3.08| positive, it sounds better, like having a high accuracy sounds
502.24|2.36| better than having a low error. For some reason, I don't know, I
504.6|3.46| like accuracy. It's maybe also because in the context of psychic
508.06|1.94| learn, everything is an accuracy. And I really like
510.0|5.84| psychic learn. It's a for those who haven't taken 451. It's a
516.2|3.2| package for traditional machine learning, which has a very nice
519.4|5.96| API. Anyways, um, so here, I have a modified version of my
525.36|2.44| train model function that we used in previous lectures, I
527.8|5.4| will show you the relevant parts in the next slide. And I'm
533.2|6.76| applying this reduce L or L or on plateau method or scheduler
540.24|5.56| to the validation set accuracy. And essentially, I'm saying I
545.8|4.2| want to maximize the validation set accuracy. So every time it
550.0|3.92| plateaus, I want to divide the learning rate by 10. So I'm I'm
553.92|3.72| saying max, because for accuracy, the higher the better.
557.8|6.68| If I use the mini batch loss, I would put min here, right. So
565.24|4.2| essentially, I tried it with many different things. The
570.08|3.48| training set loss, the training set accuracy, the validation set
573.56|3.72| accuracy, the validation set loss. And from all my experience,
577.28|4.28| I find that using it with a validation accuracy happens for
581.56|3.64| me at least to work best. Alright, so and here are the
585.2|7.96| relevant parts from this train model function. So here, I'm
593.2|3.64| zoomed in. Again, you can find it next to this notebook in the
596.84|2.44| GitHub repository, I will include the link at the bottom.
600.24|5.28| And yeah, essentially, we have the loop over the epochs, then
605.52|3.96| the loop over the mini batches here, I just left out all the
609.48|3.04| code because it would be too long otherwise. And then I'm
612.52|3.64| just saying if we use a scheduler, so this can is by
616.16|3.96| default, none, but we can, of course, like I showed on the
620.12|5.44| previous slide, provide here the scheduler. So if we have a
625.56|3.44| scheduler, and it's set to validation, accuracy, it will
629.12|4.24| essentially just do this step based on the validation accuracy,
633.36|2.08| which we collect during training. So I have a
635.44|3.56| validation accuracy, I keep track of during training, I do
639.0|3.72| this for logging purposes, so I can do a plot later on. And so
642.72|2.84| yeah, do it on the latest validation set accuracy, if it
645.56|3.16| hasn't improved substantially compared to the previous
649.12|4.44| iteration. So I think it's for over three iterations, then it
653.56|3.48| will divide the learning rate by a factor of 10. But you can also
657.04|6.26| set a number to include like, how often does doesn't have to
663.3|2.82| stagnate before you divide by 10. So there are a lot of
666.12|2.64| options that you may also want to choose. But I found just
668.76|4.0| this works well for me. Yeah, related to learning rate
672.76|3.8| schedulers and optimizers, I also wanted to say something
676.56|4.48| about saving models in pytorch. We haven't talked about saving
681.04|3.48| models in pytorch yet. But yeah, it's kind of an important
684.52|3.7| topic, right? So if you train a model, let's say for a certain
688.22|3.78| number of iterations, and you want to use it another day for
692.0|3.12| making predictions, it's of course important to save that
695.12|2.44| model. So you don't have to retrain it from scratch every
697.56|3.66| time, right? But also, sometimes you just want to train it
701.22|3.28| longer, let's say you train it for 100 epochs, and you find
704.52|4.28| huh, the loss has not quite converged yet, let me train it
708.8|2.92| longer. So instead of just rerunning the training from
711.72|3.16| scratch, you can, in that case, then just let's say, laud your
714.88|5.48| model from a previous round, and then continue running it. So
720.54|2.82| saving a model in pytorch is actually quite simple. So there
723.36|2.56| are two ways of doing it, but I will only show you the
725.92|4.28| recommended way of doing it. So the recommended way is using
730.2|5.26| torch safe on the model state dictionary. So the model state
735.46|3.72| dictionary contains all the model settings and also all the
739.18|4.38| model parameters. However, then also, if you use an optimizer
743.56|3.28| that has a state, for example, if you use SGD and change the
746.84|3.48| learning rate, the learning rate would be a state essentially.
750.52|4.48| So you can also save that. So here, you can do optimizer dot
755.0|3.8| state dict. And then it will also save that it will all be
758.8|3.2| saved as I think they are actually pickle files, but I'm
762.0|3.36| actually not sure what I think they could be email files, I
765.36|3.44| honestly forgot, I just call them dot p t files, pytorch
768.8|4.52| files. And yeah, these contain the settings for your model,
773.32|5.6| essentially. And then if you want to laud your model, you can
778.92|3.48| use so you have to do it in two steps, you have to first
782.4|5.52| initialize your model. Because here, really, you're only you're
787.92|2.64| only saving the parameters of the model, like the weights and
790.56|5.16| everything. And here, you can hear you, for instance,
795.72|2.64| initialize your model, it has to be the same model that you
798.36|5.44| saved. And then what you do is you have like this Lord state
803.8|3.08| dict. So it's easy to remember, because this is called state
806.88|2.04| dict here. And this is essentially just Lord state
808.92|3.36| dict. And then but you have to do an inner torch load here,
812.28|3.32| which is loading this pytorch file. So if you do that, it
815.6|5.96| will laud the model. And it will essentially laud the weights in
821.56|3.44| this state dict are the weights, it will laud the weights into
825.08|5.56| that model here. And that's all there is to it, essentially. If
830.64|2.56| you have an optimizer, though, that you saved, and you want to
833.2|2.92| reuse, you do the same thing here for the optimizer, for
836.12|3.72| instance, you just initialize a blank optimizer, let's say a
839.84|4.08| student optimizer with the model parameters, and then you laud
844.16|3.84| the state dict. So if you had used a learning rate scheduler
848.0|2.92| that changed the learning rate, it will then update the learning
850.92|3.5| rate. So you don't have to remember or check manually. And
854.42|3.3| then you also for the scheduler, if you use the exponential
858.24|2.6| scheduler, it will, of course, you have change over time,
860.84|6.44| right? So in that way, um, you can also then get a lot the
867.28|4.12| scheduler with its parameters. All right, so and that is
871.4|20.16| essentially how you save and laud models in pytorch.