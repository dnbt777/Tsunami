start_time|end_time|text
0.4|3.48| Yeah, let's now generalize the concept of logistic regression
4.12|4.02| to multiple classes. This is also known as softmax
8.14|3.56| regression, or sometimes also called multinomial logistic
11.7|4.02| regression. So for this, we will consider a relatively simple
15.72|4.32| data set the MNIST data set. I already introduced this in the
20.04|4.44| introductory lectures. So these are 60,000 handwritten digits in
24.48|5.12| the training set. And yet it's a nice and balanced data set. So
29.6|3.06| balanced means that there's the same number of training
32.66|3.62| examples per class. So in this case, we have 10 classes, the
36.28|3.84| handwritten digits on zero to nine, and there are 6000 digits
40.16|4.12| per class. Here's an example of how these digits look like. And
44.36|4.76| each of these on training examples here has an image
49.12|5.04| dimension of 28 times 28 times one, so 28 for the height and
54.16|4.52| 28 for the width. So this is the number of pixels. So we have a
58.68|6.6| total 784 pixels of features per training example. And pytorch,
65.28|6.36| we will be using a format, so called NCHW, which is how we
71.96|5.68| represent a mini batch or an image batch. So here, in this
77.64|5.92| case, we have 128 examples in that mini batch. So the one at
83.56|4.88| 28 is for this in here, then we have the color channel, we have
88.44|2.96| only one color channel, because these are black and white
91.4|4.28| images. So there are no red, green and blue colors. And then
95.68|6.8| we have the height, so 28 pixels. And for the width, we
102.48|3.48| have also 28 pixels. This is usually how we read in the data
105.96|3.96| set into pytorch. And we will be also looking at code examples
109.92|6.6| for that. So yeah, just to recap, we have 60,000 training
116.52|4.2| examples, and then the corresponding labels. And then
120.72|6.32| we have for the test images and test labels 10,000 each. So
127.04|3.52| that's just how the data set looks like. Um, yeah, for soft
130.56|6.28| max regression, we will actually concatenating these images, or
136.84|3.16| these features in the image to a long vector, like we discussed
140.0|4.84| in the introductory lecture. So here's just an example of how
144.84|3.24| kind of diverse these handwritings are. So these are
148.08|5.04| all the letter seven, sorry, the number seven. So illustrations
153.12|3.48| of different sevens. So different people writing down a
156.6|4.76| seven, and you can see, varies a lot. So personally, where I grew
161.36|3.4| up in Germany, we usually write a seven like this with this
165.08|3.16| crossline here. In the US, it's more common to write it like
168.24|4.36| this. But you can see, they're also very interesting flavors of
172.6|4.44| flavors of this, for example, looks like a C almost here, this
177.04|2.36| one is actually interesting, because in Germany, we write a
179.4|3.56| one as follows like this, this is a one in Germany. In the US,
183.32|3.56| one is usually written as this one. So but you can see, just by
186.88|2.88| looking at these handwritings, it's sometimes maybe not even
189.76|3.44| clear what the number is. So if I wouldn't tell you that these
193.2|2.56| are different illustrations of sevens, some people might think
195.76|3.44| these might be ones. And yeah, this actually, I don't even know
199.2|3.72| it could be a C if you have a data set of letters and digits,
202.92|5.12| for example. So yeah, like I mentioned in the context of
208.04|3.2| pytorch, and when we work with unstructured data, also later
211.24|4.04| with convolution networks, we would be working with the format
215.32|7.28| the n ch w as follows. So this would be a four dimensional
222.72|4.56| tensor. Think I introduced that in the first lecture of this
227.28|3.84| course, so long time ago. So yeah, here's how it would look
231.12|3.4| like in pytorch, where we have this four dimensional tensor.
236.96|2.36| Actually, in this case, it's a three dimensional tensor, I only
239.48|4.72| represent one single image. So it's a single image here at the
244.2|7.64| bottom, representing the number three. And you can see there are
251.94|4.04| different values from zero to 0.5. I think the highest one
255.98|4.14| would be approaching one. And that is because I normalized
261.52|6.4| these pixels by dividing them by 255. And this is because these
267.92|3.56| values between or around zero, or in this case, between zero
271.48|2.76| and one work better with gradient descent, it would be
274.24|3.92| even better, for example, to normalize these images such that
278.16|4.6| they are centered at zero. So you can, for example, subtract a
282.76|3.84| point five, if you have the range between zero and one, you
286.6|4.44| can subtract a point five, and then it will be ranging between
291.68|4.6| minus point five, two point five. And this would work even
296.28|3.2| better. Or people say that would work better with gradient
299.48|2.92| descent, because now it's centered at zero, and you can
302.4|3.36| have positive and negative inputs equally. However, in
305.76|3.12| practice, personally, I, for these simple data sets, I don't
308.88|2.76| notice a big difference, especially if we work with
311.64|3.72| logistic regression. Sometimes I put more effort into
315.36|3.2| normalizing the input images, for example, doing the standard
318.6|4.36| normal standardization, the what people call the standard normal
324.48|5.02| data. So it's giving you our data, the properties of standard
329.5|2.5| normal distribution. But of course, if your data is not
332.0|2.36| normally distributed from begin with, it will also not be
334.36|2.92| normally distributed after normalizing. So what I mean is,
337.28|4.8| for example, if you have, it's called x prime, if you have a
342.08|6.64| given feature, max, you subtract the mean of the feature and then
348.72|2.52| divide it by the standard deviation. So this would be
351.32|6.0| called standardization. Or some people just call that normal z
357.32|6.16| score normalization. Um, this is also recommended, we can do that
363.48|4.6| here, too. But since the images are the feature, sorry, the
368.08|5.78| features are all equal, they are all from zero to 25 at 155. For
373.86|4.58| pixels, it wouldn't make a big difference whether we use this
378.72|3.44| standardization or just scale them between the range minus
382.16|3.12| point five and point five. So that's like a minor detail.
386.8|3.52| Alright, so but I'm getting sidetracked here. What I wanted
390.32|3.0| to mention is the main point here is what we are doing now is
393.32|3.88| we are concatenating. So if I go back, we are concatenating the
397.2|4.52| rows. So if you consider, fortunately, there's a line
402.12|3.76| wrapping here, if you consider this here as the first row, then
406.0|1.76| I can maybe write this down first row.
407.76|21.36| First row, then second row, third row, and so forth. If we
429.12|5.96| concatenate these rows, we get a one long vector here. That's how
435.08|3.48| it looks like. So here, I've concatenated these rows, just to
438.92|3.32| illustrate this again, let me jump back one more time. So here
442.24|3.8| in green, this would be really the first row on in this image
446.04|5.12| here. In blue, this would be second row. And the third row
451.16|4.44| here in red would be this one. If we concatenate them, by that,
455.6|2.68| I mean, if we make one long vector, so the green one first,
458.68|5.56| then the blue one. And then the red one, we can use that as
464.24|3.72| input for our logistic regression model. And in the
467.96|2.88| case of the MDS data set, we have more than two classes. So
470.84|3.72| we are going to use softmax regression. Yeah, to just
474.56|3.16| briefly recap on before I introduced the softmax model,
477.96|3.96| here's a drawing of the regular logistic regression model for
481.92|4.28| the binary classification case. So as input, we have a feature
486.2|4.56| vector. And then we have this weight vector. So we compute the
490.76|3.84| dot product between the two at the bias unit, which gives us
494.92|3.92| the net input. And then we put the net input through a non
498.84|2.16| linear activation function, the logistic
502.84|4.44| sigmoid function, which we defined as follows.
510.08|5.44| And then if so what it what it represents is the probability. So
515.52|2.44| this present represents the probability that a training
517.96|6.92| example belongs to class one, if we wanted to compute the
524.88|3.22| probability that it belongs to class zero, we can yeah, we
528.1|2.58| could, we could compute it as
535.2|4.08| one minus this right, one minus this probability, this would
539.28|9.44| give us the probability that it belongs to class zero. But back
548.72|4.6| to this one here now, so we have a probability and it belongs to
553.32|3.24| class one. And then we can say if this probability is greater,
558.56|8.92| if p is greater than point five, then class one. And if it's
567.48|8.08| smaller than point five, class zero. So how can we generalize
575.56|3.56| this now to multiple classes? So for that, we can actually
579.12|3.2| extend this model. So here's a drawing of a model that would
582.32|3.96| work with a multiclass classification data set, where
586.28|4.08| we have more than two classes. So just to jump back one more
590.36|4.96| time. So this model here that I'm circling in green, this can
595.32|3.64| actually be thought of as a model that is embedded in this
598.96|4.4| bigger model here. So if we have the same inputs here, it's the
603.36|4.0| same as before our feature vector of dimensionality m, we
607.36|4.72| can think of everything I'm drawing now in green, as the
612.08|3.34| same model that I showed you before, right. So if you look at
615.42|2.1| this, it's the same model. I mean, it's of course a little
617.52|2.8| bit skewed, because these lines are a little bit different, but
620.48|3.32| it's essentially the same model. And so this would be one
623.8|2.52| logistic regression model. And for that one, we have a feature
626.32|4.6| vector of dimensionality m, so we can have the feature vector.
630.92|7.28| Let's write it down like one, one, like this, one, one, one,
638.68|9.36| two, and one, let's say three, if we have three classes. Sorry,
648.04|4.32| if we have three features, let's do m to have it more general. So
652.36|5.68| if we have m features, we have this feature vector here. And
658.06|3.5| notice now, I mean, we have multiple of these logistic
661.56|3.08| regression models, the second model would be this one here,
664.64|3.44| right? So another logistic regression model, same inputs.
668.84|2.24| And for this one, we can also have a feature vector for this
671.08|9.12| one, we could have the feature vector to 122 and two m. And
680.2|6.52| then there's a third model here, right? So this is the third
686.72|3.28| model. And for that, we also have a feature vector, we can
690.0|5.88| write it as on w three, one, w two, three, two, and w three,
696.04|5.72| three. Right. So if I call this feature vector, let's say, let's
701.76|16.72| call it w one. And this is w two. And this is w three. Right. So
718.48|4.76| I have now three feature vectors. So if I stack them, I
723.24|4.36| can stack them to make a feature matrix. So this matrix here, so
727.6|7.16| I can write this matrix as I think I would need to transpose
734.76|9.16| this. So we would have w one, transpose, w two, transpose,
744.0|5.48| and three transpose. So this would be my feature matrix of
749.48|4.6| the majority h times m, where h is the number of output nodes
754.08|4.86| here. So this would be one way I could generalize my logistic
758.96|4.16| regression model. And then we can compute also the class
763.12|3.44| membership probabilities here. However, notice now, the class
766.56|3.52| membership probabilities work a little bit differently. So
770.08|2.8| because we don't have a binary classification problem now, but
772.88|4.08| each node is still binary. So here, let's say in green, this
776.96|5.28| would be the probability that this is class one. In blue, this
782.24|6.12| is the probability that is class two. But now each probability
788.36|5.78| works like this. That it is the probability that this is the
794.14|3.84| class. So the probability that is class three, versus not being
797.98|5.8| class three. So what can happen is that or what will probably
803.78|2.66| likely happen is that these probabilities don't sum up to
806.44|3.04| one. So for example, for a given input, if we have the digit
809.48|5.74| three, we may get a probability that this is point three, or
815.22|11.04| let's say, 33%. That this isn't class one. Let's say 40% that
826.26|9.8| this is class two, and then 70% that this is class three. So but
836.06|3.8| yeah, these don't sum up to one. So for example, if the
839.86|3.52| probability is 40%, this is class two, the probability that
843.38|5.4| this is not class two would be 60%. And for this one, for the
848.78|4.76| first one, the probability that it would be class three would be
854.46|5.48| 67%. In any case, these probabilities don't sum up to
859.94|3.24| one, if we also take a look at this one, these don't sum up to
863.18|4.0| one, it can be a little bit weird. So if we have a number,
867.22|7.32| let's say the digit three, how can it be 33%? Number 140%,
874.54|4.52| number two, and 70% probability number three, it doesn't really
879.82|4.44| make intuitive sense. I think this would make sense if we have
884.26|4.04| a data set when the classes are not mutually exclusive. For
888.3|5.68| example, if you have something like a vehicle, there's a high
893.98|3.52| probability that an object in an image is a vehicle, there's
897.54|4.28| maybe also probability greater than 50%, that this is a car.
902.22|2.68| And then maybe a probability, a certain probability that it's a
904.9|2.84| certain brand of a car and so forth. So where we don't have
908.1|3.4| mutually exclusive classes, but in the case of digits, it would
911.5|5.04| be more intuitive if these probabilities sum up to one. And
916.54|3.22| for that, we have this multinomial logistic regression
919.76|2.54| model or softmax regression model. So what I showed you in
922.3|3.12| the previous case was more like a concatenation of individual
925.42|3.12| logistic regression models, here would be the real multinomial
928.54|3.84| logistic regression model where we assume that the classes are
932.38|4.2| mutually exclusive. So what is the difference between this
936.62|3.16| slide and the previous slide? So if I go back one more time in
939.78|5.04| the previous slide, it's hard to see now, but we had one sigmoid
944.82|4.62| activation in each node here. So I'm getting rid of this sigmoid
949.44|6.3| activation and have a so called softmax activation. And also
955.74|3.16| notice that I'm drawing it a bit differently before I was drawing
958.9|3.96| it inside here, because they were all independent from each
962.86|3.78| other. Now, the softmax activation is actually not
966.64|4.7| independent for each node. So all the activation go into the
971.34|5.12| same softmax activation. And then there's some computation
976.46|2.44| going on, I will explain to you how that works in the next
978.9|4.32| video. And what comes out are these activations that now sum
983.22|3.78| up to one. So these sum up to one. So for example, the first
987.0|5.54| one may be 10% probability that it belongs to class one, then
992.58|6.76| that might be 20% for class two and 70% for class three and so
999.34|4.08| forth. And how can we then convert it into a class label,
1003.62|5.56| we would take the arc max. So the arc max is the position, the
1009.18|4.68| index position of the highest value. If I scan these three
1013.86|6.44| positions, let's say, position one, position two, and position
1020.3|3.98| three, the highest index 70%, this would be three. So this
1024.28|5.04| would return class label three, if I apply the arc max. If this
1029.32|3.58| is unclear, we will walk through the step by step in the next
1032.9|4.16| video. So this was just the introduction of how the softmax
1037.1|4.24| regression model looks like. It's basically here, the
1041.34|3.76| concatenation of individual logistic regression models. And
1045.1|3.8| in the next videos, we will talk about softmax, and this arc max
1048.9|10.68| and how we also compute the loss function.