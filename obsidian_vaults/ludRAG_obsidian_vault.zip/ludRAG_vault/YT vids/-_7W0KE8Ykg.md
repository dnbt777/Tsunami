start_time|end_time|text
0.76|3.32| Yeah, let us now get to these nonlinear activation functions.
4.28|2.92| So why are we interested in these nonlinear activation
7.2|3.12| functions? Yeah, together with the hidden layers, they allow
10.32|4.44| us to model complex nonlinear decision boundaries. So with
14.76|3.98| that, we can solve complicated problems, complicated
18.76|4.08| classification problems, for instance. So but before we take
22.84|2.64| a look at these nonlinear activation functions more
25.48|5.52| closely, let us briefly recap the pytorch API. So this is
31.12|3.84| something I just copy and paste it from lecture five, where we
34.96|3.96| already had a multi multi layer perceptron, just to illustrate
38.92|3.86| how the pytorch API works. So on the left hand side, yeah, this
42.78|4.78| is like the regular approach. So where we have in it,
48.36|4.3| constructor, and here, this is a multi layer perceptron with two
52.66|3.22| hidden layers, I called them linear one and linear two,
56.08|3.24| because linear because the layer is called linear, it's computing
59.32|4.8| the net input, right? So these are our layers that we use and
64.12|4.0| one output layer. So this is essentially the setup that I
68.12|3.44| showed you earlier on in the slides, if I can just go back.
73.88|3.6| So this is essentially this setup where we have one hidden
77.48|7.04| layer, second hidden layer, and an output layer. Alright, so
84.56|4.38| this is how it looks like. And in the forward method, we use
88.94|4.58| these actual layers. So we apply the first hidden layer, then we
93.52|6.84| have our nonlinear activation here, it's a relu function, we
100.36|6.4| will revisit this in a few slides, then another net input
106.76|4.08| and another activation function, another net input. And then
111.16|4.92| usually, we would compute the softmax in pytorch. Recall, we
116.08|4.48| use this cross entropy loss, which already computes the soft
120.56|4.04| max for us, so we don't have to do it ourselves. So here, we
124.6|5.84| apply this lock softmax function on the logits. So there's also a
130.44|5.24| softmax function. But here, we compute this based on the we use
135.68|3.2| the lock softmax, because it's numerically more stable, if we
138.88|6.76| were to use the negative log likelihood loss. This is really
145.64|3.24| the only if we want to use the negative log likelihood loss.
149.12|3.56| Otherwise, we would just use softmax if we are interested in
152.68|3.0| the probabilities. To be honest, now looking at this, I don't
155.68|4.0| know why I used lock softmax, I think, in the big code example,
160.0|4.52| when I created lecture five, I had the negative log likelihood
164.52|4.72| here. So also, technically, you don't have to compute the
169.24|4.16| probabilities within this class, you can do this separately, if
173.4|2.2| you care about because technically, you never have to
175.6|4.12| use the probability if you use the cross entropy function in
179.72|2.92| pytorch for optimization. But again, this will become more
182.64|2.96| clear when we look at the concrete code example in the
185.6|4.0| next video. On the right hand side, the main difference is
189.6|3.96| that I'm using the sequential API, which can be a little bit
193.56|5.28| more, I would say, easier to read more compact. So that's
198.84|5.84| exactly the same network, except that here, we define it and
204.96|2.92| sequential can actually also run it. So we don't have to put it
208.52|4.6| explicitly in the forward method, it will already do it
213.12|2.96| for us if we call here my network, I just called it my
216.08|3.28| network. So it is, in a way a little bit more convenient.
219.64|2.16| What's more convenient in particular is that we don't have
221.8|5.48| to define these steps in the order these are used ourselves.
227.4|4.84| And we can also just read right now from here, how these layers
232.24|2.72| executed, they are executed from top to bottom. This is also the
234.96|3.16| case here. But for example, if I want to know what the linear one
238.12|3.12| is, I have to go up and look it up here. So it's a little bit
241.24|2.92| more, I would say error prone, whereas on the right hand side,
244.48|3.32| we define it. And we also directly use it in that order.
247.84|3.32| So it's a little bit more, it's a bit safer, I would say. So
251.16|3.64| yeah, so the flow is we apply a linear layer, a nonlinear
254.8|3.44| activation, a linear layer, nonlinear activation, and a
258.24|3.6| linear layer. And that will produce our logits. And then if
261.84|3.2| we're interested in that the probabilities, but again, pytorch
265.04|2.8| and cross entropy already applies the softmax for us, so
267.84|3.52| we don't have to do it ourselves. So technically, we
271.36|4.66| can skip this softmax step and don't have to use that. It's
276.02|3.52| just like, I usually like to include the probabilities
279.54|3.66| because I sometimes also print out the results from a model
283.2|4.64| and analyze it with plots and probability plots and stuff like
287.84|2.36| that. So in that way, I sometimes find it helpful to
290.2|2.52| have the probabilities available. So I usually save my
292.72|4.82| results, but you don't have to worry about this really. Alright,
297.54|4.02| so with that, we can then solve the XR problem using these
301.56|2.84| nonlinear activation functions. So the nonlinear activation
304.4|3.52| functions, let us make complex decision boundaries, like I
307.92|5.4| just said, so here, this is like a toy data set, I made just two
313.32|5.16| features, x one and x two, just for simplicity, two classes,
318.48|6.0| these orange ones, and these blue dots. So the orange squares
324.48|4.16| and the blue dots on the left hand side here, just for fun, I
328.64|4.24| was applying a multi layer perceptron with one hidden layer
333.2|2.4| and a linear activation function. So recall the linear
335.6|5.4| activation function looks like that. So you can see that on the
341.0|4.48| left hand side, that it's a linear decision boundary, even
345.48|3.52| though we have a hidden layer, by the way, I don't want to open
349.0|3.16| the code notebook right now, because then I have to switch
352.16|3.88| the screen again. But if you're interested, after watching this
356.04|3.88| video, you can double check here under this link, that this is
359.92|3.36| indeed the code is indeed correct. So you can reproduce
363.28|2.88| these results, if you don't believe me. But in any case, so
366.16|3.8| you can see, on the left hand side, this is a linear decision
369.96|3.76| boundary, even though we have a hidden layer. So what happened
373.72|4.08| here? So because in logistic regression, we had a nonlinear
377.8|3.32| activation function, and no hidden layer, it was a linear
381.12|5.68| decision boundary. Now we have a hidden layer. And no nonlinear
386.8|2.58| activation, we also have a decision boundary that is
389.38|6.84| linear. So let's recap logistic regression. No hidden layer.
396.22|20.16| Plus, nonlinear activation gives us a linear boundary MLP with
416.38|14.58| with linear activation plus hidden layer, also linear
430.96|12.64| boundary. So from that, we can deduce neither the hidden layer,
443.6|4.84| which we have in the multi layer perceptron, nor the nonlinear
448.44|5.6| activation function alone are sufficient for making a nonlinear
454.04|2.36| decision boundary, they are necessary, but they are not
456.4|2.88| sufficient for making a nonlinear decision boundary. In
459.28|4.48| fact, we need both, we need both the hidden layers, and the
463.76|2.78| nonlinear activation functions to make a nonlinear decision
466.54|7.2| boundary. So on the right hand side, I have now the same
473.78|3.44| multi layer perceptron with one hidden layer, the same number of
477.22|4.08| weights, the only difference is that I'm now using a nonlinear
481.3|4.06| activation function, here, I'm using the relu function. And you
485.36|4.64| remember, this is very simple, it's actually just thresholded
490.0|3.52| at zero. So if the input is negative, the output is zero,
493.52|3.28| otherwise, it's an identity function. So it's almost an
496.8|3.76| identity function, but not quite. And this is sufficient
500.56|3.0| together with the hidden layers to make a nonlinear decision
503.56|2.68| border, you can see, this decision border is no nonlinear,
506.24|5.2| you can see it's solving this x or problem. So it can now
511.44|5.36| classify these data points correctly. So why is this working?
516.8|3.76| And why is this not working? So why is the linear decision?
520.56|5.4| Linear activation function, not sufficient and produces a linear
526.76|4.32| decision region. That's because if you think about it, even
531.08|4.36| though we have a hidden layer, if we have a linear activation
535.44|3.52| function, what happens is that we have essentially a
538.96|4.72| combination of multiple linear functions. And the combination
543.68|4.76| of multiple linear functions is still a linear function. So if
548.44|2.24| we don't use nonlinear activation functions, then we
550.68|3.16| don't really gain anything by using a hidden layer. So we need
553.84|3.12| actually both hidden layers and nonlinear activation functions
556.96|5.44| to produce these complex decision boundaries. Actually,
562.4|3.76| they are way more than just relu functions, really just happens
566.16|3.68| to be popular because it's, it's quite simple and quite fast to
569.84|2.88| compute and has also some other nice properties, which I will
572.72|3.64| also briefly talk about in a few minutes. So but yeah,
576.36|3.92| traditionally, these are also one of the most popular
580.36|2.72| activation functions in multi layer perceptrons. With that, I
583.08|3.88| mean, the logistic sigmoid that we already encountered in the
586.96|3.32| context of logistic regression. So back in the day, I would say
590.28|3.16| even the sigmoid was maybe the most popular activation function
593.44|3.56| in multi layer perceptrons. But again, it has this problem that
597.0|5.08| these gradients saturate here. Another very popular activation
602.08|3.28| function for a while was the 10 h function, it's also a sick
605.36|4.88| model. So both are sick model functions. It's also sick model
610.28|6.48| function. So as shaped by this hyperbolic tangent function looks
616.76|3.44| a little bit different. So you can see this one, the logistic
620.2|4.36| sigmoid function is centered around zero, and the output is
624.56|5.4| point five. Whereas this one is centered at zero. And the output
630.88|4.24| at zero is also zero. So it's producing positive and negative
635.12|3.16| values, which can be an advantage. There's also a hard
638.28|5.0| tension, which is essentially very similar to 10 h, except
643.28|5.92| that it's thresholded here, similar to relu. So what is the
649.2|4.92| advantage of let's say the 10 h over the sigmoid activation. So
654.12|5.24| the event of 10 h is really like that we have this centering at
659.56|5.24| zero. So that we have positive and negative values. And you can
664.8|6.84| also see it's steeper. So here, the it's steeper than this one.
671.64|4.08| So we have larger gradients. It has also a very simple
675.72|2.96| derivative, one minus 10 h, recall for the logistic
678.68|8.0| sigmoid, the derivative was like this. So itself times one minus
686.68|5.76| itself, so the derivative is slightly smaller, because it's
692.44|5.64| you're multiplying two numbers smaller than one with each
698.08|6.6| other. So whereas here, you have one minus this one. But then you
704.68|2.04| have also the squared here. So it's actually not that
706.72|6.72| different. Okay, um, yes. So but both have the problem that if
713.44|3.44| you make a wrong prediction, it's both if you make a right or
716.88|4.36| wrong prediction, but in both cases, you hear and hear, so you
721.24|3.04| saturate it. So that that can be a problem. If you make a wrong
724.28|4.16| prediction, you end up with a very small partial derivative
729.16|2.56| with with respect to its derivative with respect to its
731.72|3.6| input. And then when you compute the partial derivatives in the
735.32|3.48| chain rule, then yeah, you will get very small gradients and the
738.8|3.68| learning will be very slow, which can be a disadvantage. Or
742.48|5.36| maybe one more thing about why it's good to have negative and
747.84|3.56| positive values, that just gives you more combinations. So
751.4|3.92| imagine you initialize your weights from let's say a small
755.68|3.2| from a random normal distribution, standard normal
758.88|2.56| distribution, let's say, or a scale to standard normal
761.44|3.08| distribution. So you initialize your weights such that they are
764.52|2.72| centered at zero. So you can have positive and negative
767.6|4.24| starting weights. And if you also use this 10h, which can
771.84|2.48| have positive and negative values, you get just more
774.32|3.84| combinations of possible values, whether you combine a positive
778.16|2.16| with a negative number and negative with a positive number
780.64|2.64| to negative numbers or to positive numbers, you have four
783.28|3.2| different ways you can combine these signs. Whereas if you have
786.48|2.52| a activation function that can only produce positive numbers,
789.0|3.0| you're a little bit more limited. So I would say that
792.0|3.24| 10h is a little bit more expressive, it allows you a
795.24|3.2| little bit more explicit expressivity, if that's the
798.44|4.16| word. But yeah, I think also in practice, when I use them, and I
802.6|3.6| recall, I only saw a minor difference using one over the
806.2|3.48| other, really, if you use a redo function that gives you a better
809.68|5.56| bang for the buck, usually. So here are some more nonlinear
815.24|4.04| activation functions, including the redo function. So the redo
819.28|3.96| function here, that's something you've seen before, it's I would
823.24|4.2| say still the most widely used activation function in deep
827.44|4.24| learning. I think it's maybe 10 years old by now, something like
831.68|4.48| that. But when you look at recent papers, people still use
836.2|4.04| a relu a lot. It has three nice properties. It's simple to
840.24|4.92| compute, really. And you have always, yeah, large derivative,
845.16|3.12| the derivative is one. So if you use the chain rule, and your
848.28|4.76| derivative is one, if the inputs are positive, then yeah, you
853.04|5.16| don't diminish the product in the on general, okay, but it can
858.2|3.56| also be zero, which can be a problem. So if you have negative
861.78|4.58| inputs to this activation function, you are your output
866.68|3.76| would be zero, which will then basically cancel the weight
870.44|3.32| update for that corresponding weight corresponding to this
873.76|5.0| activation, or connected to this activation. So that can be a
878.76|3.76| problem if you always have very negative input. So there is a
882.52|10.4| problem called dying neurons or debt. Relu's that happens
892.92|4.32| usually when you have somehow updated the weights, such that
897.24|3.16| you will never come into the positive region anymore. And
900.4|2.4| then yeah, you will never be able to update your weights
902.8|4.12| again, because the derivative will always be zero, it can be a
906.92|3.2| problem. However, in practice, some people argue it can also be
910.12|4.92| an advantage because it can help with pruning, let's say,
915.28|3.24| unnecessary neurons, like if you have an excessive number of
918.52|4.16| neurons, this way, you can get rid of some of them. And it may
922.8|4.88| help with preventing overfitting. A version of Relu
927.68|4.64| that some people find to perform sometimes a little bit better is
932.32|3.96| the leaky relu, which doesn't have the problem of these dying
936.28|4.76| neurons. So here, the difference is that we have, so if we look
941.04|5.4| at the simplified notation, the the piecewise linear function
946.44|5.24| here, um, what you can see here, or the piecewise function,
951.68|3.44| sorry, what you can see here is that the only difference is that
955.12|4.16| we have now this alpha here, which is a slope, if the input
959.32|3.68| is smaller than zero, so for the negative region here, we have
963.0|3.84| now a slope, what value we can choose for the slope, it's a
966.84|6.4| hyper parameter, right? So hyper parameters is something that you
973.24|5.2| as the practitioner have has to choose. So there's no way you
978.48|2.48| get second know what's a good value if it's a hyper parameter.
981.32|4.12| It's something you have to try out in practice and change and
985.44|4.28| see what performs better. I have seen all kinds of values for
989.72|3.64| this negative slope here, or for the slope in the negative region.
993.92|4.84| So in Keras, that's API for TensorFlow, I believe they use
998.76|4.1| point three as the default value. In pytorch, I don't know
1002.86|2.98| exactly the default. I usually specify it myself, I usually use
1005.84|4.52| something like point one or point one. But yeah, there are
1010.56|3.04| different values that work well for different problems. In
1013.6|3.06| practice, you will only see a slight small difference. So it's
1016.66|3.42| not something if your network that say doesn't perform very
1020.08|3.96| well, then choosing different value here probably won't make a
1024.04|4.2| big difference. So you have very bigger problems to fix. But it
1028.24|3.08| can give you maybe 123 percentage points in terms of
1031.32|4.68| accuracy, if you're lucky. I said hyper parameters cannot be
1036.0|2.92| like automatically learned from gradient descent. However,
1038.92|5.04| people designed parameterized version of the leaky relu, it's
1043.96|5.24| called Prelude parameterized relu basically. And here, this is
1049.2|3.52| essentially the same as buff. But here, the people made it
1052.84|4.52| made alpha trainable parameter. So it's parameter that can be
1057.36|4.66| also updated with gradient descent. So in practice, I
1062.02|3.98| honestly never really have never really seen this being used. I'm
1066.0|5.64| not sure if this is really that useful. There's also an elu an
1071.64|3.76| exponential linear unit. So it's getting around this kink here.
1075.4|3.24| It's like a more like a smooth version here in this kink. So
1078.64|2.12| there are different types, really many, many different
1080.76|2.68| types of nonlinear activation functions. There's also I
1083.44|5.52| recall there's a cell I've seen that quite often recently, it's
1088.96|4.06| on thing it stands for self normalizing exponential linear
1093.02|3.54| unit. So it has some nice properties also. But yeah,
1096.6|3.16| again, there are lots of different flavors. Usually,
1099.76|3.28| um, people still use the relu a lot because it just performs
1103.04|4.8| well. Yeah, related to the topic of nonlinear activation
1107.84|4.64| functions, I saw this paper here, last year called smooth
1112.48|3.16| adversarial training. I booked marked it because I knew it
1115.64|4.76| would become handy when I teach a class on deep learning. So
1121.6|2.6| adversarial training, just briefly, what is adversarial
1124.2|4.04| training adversarial training is, yeah, on exploiting deep
1128.24|3.56| neural networks, or more like fooling deep neural networks,
1131.8|4.96| it's, if you have, let's say an image or some data point, and
1136.76|2.64| your network makes a prediction, let's say you have an image of
1139.4|4.68| a cat, it predicts cat, there's some way you can exploit the
1144.08|3.66| network by just changing the image very slightly making like
1147.74|3.54| a few pixel changes. But you find these pixel changes that
1151.28|3.76| are able to fool the network to let's say now think that the
1155.04|5.04| image is a dog instead of a cat. So it's like exploiting
1160.08|4.98| weaknesses in the network. So like the author say it is
1165.06|4.1| commonly believed that networks cannot be both accurate and
1169.2|5.44| robust. So usually, if you want to make your network more robust
1174.66|3.7| towards these adversarial examples, you usually trade it
1178.36|4.28| off by Yeah, by suffering in terms of accuracy. So the
1182.64|4.96| accuracy is usually lower in these more robust networks. So
1187.6|4.32| like I say, gaining robustness means losing accuracy. However,
1193.04|3.28| yeah, let me just read it. Our key observation is that the
1196.34|3.82| widely used relu activation function significantly weakens
1200.2|3.24| adversarial training due to its non smooth nature. So it sounds
1203.44|4.04| like the relu is like a little bit of a disadvantage for
1207.48|5.68| adversarial training. Hence, we propose smooth adversarial
1213.16|3.56| training, in which we replace relu with its smooth
1216.72|3.88| approximations to strengthen adversarial training. So the
1220.6|4.72| authors argue that if you replace this revenue here in
1225.32|4.8| red with this non smooth point here with a smooth version, for
1230.12|3.16| example, the permit rig soft plus function, then yeah, you
1233.28|2.88| can strengthen it because now maybe it has something to do
1236.16|2.92| with the gradients because here you have this big difference
1239.08|3.44| whereas here you have also something in between. So now
1242.52|3.56| this is maybe helping with this adversarial training. So based
1246.08|4.76| on the experiments. Yeah, and the second reason why I like
1250.84|4.84| this paper is because they have a nice summary of the smooth
1255.84|4.16| approximations of the non smooth relu function. So on the left
1260.0|3.04| hand side, this is how the activation functions look like
1263.04|3.88| they call it here the forward path. And then here are the
1266.96|4.4| derivatives for the backward path on the right hand side. So
1271.4|4.4| yeah, you can see these are all slightly different, but they are
1275.8|6.0| all kind of approximating the other relu in some way. In
1281.8|4.32| practice, um, yeah, in practice, this has a big implication
1286.6|2.96| apparently for the adversarial robustness. But also, like I
1289.56|4.16| said, choosing different activation functions that are
1293.76|3.52| relatively similar, it doesn't make a big impact in practice.
1297.28|3.92| So also what they see here, it's just one percentage point. So
1301.2|3.56| one percentage point between relu and the others. So it helps
1304.76|2.72| a little bit these some of these others perform actually better,
1307.88|3.32| a little bit better. It's not huge, but it's a little bit
1311.2|3.32| better. So it's in a way it doesn't hurt using them. But on
1314.52|2.48| the other hand, you can see there's a huge advantage in
1317.0|6.8| terms of adversarial robustness from 33%, up to 42%. It's almost
1323.8|4.68| a 10% 10% difference in terms of adversarial robustness. So
1328.48|4.88| given that, I mean, it's not much work to just replace relu
1333.52|3.84| with one of these non other nonlinear activation functions,
1338.12|2.96| given that it's not much work, why not doing it right? So it's
1341.08|5.28| actually quite interesting. Yeah, and because activation
1346.36|4.08| functions are quite boring, I have a quite fun visualization
1350.44|3.0| here I just saw today coincidentally. So that's these
1353.64|3.36| dance moves of deep learning activation functions. With that,
1357.0|4.24| I want to enter this video. And then in the next video, we will
1361.24|4.52| talk a little bit more about multilayer perceptrons and in
1365.76|11.04| particular, coding it up in pytorch and training it.