start_time|end_time|text
0.94|2.84| Yeah, let's start by taking a look at the results from the
3.78|5.16| previous run. So as we can see, I would finished after
8.96|4.02| approximately four minutes, as we can see, yeah, the loss looks
12.98|4.0| nice, it goes down. So you can see, for the different epochs,
16.98|5.54| the loss continually goes down, maybe training a little bit
22.52|2.42| longer would have been nice, because we can see there's still
24.94|4.2| a trend here. But overall, that looks pretty good. And then also
29.14|4.62| when we compute the accuracy, we get a good accuracy here. Now,
33.76|4.68| let me show you how I would organize my code, if I work on a
38.44|4.62| bigger project where I do more tuning. So what I like to do is
43.06|5.42| I like to do, like to use Python scripts for that. So if I have a
48.48|4.42| folder here, I have usually multiple files, one helper dot
52.9|4.22| pi file, sometimes also multiple helper files, where I keep
57.12|3.66| functions that I want to reuse across different projects. But
60.78|4.16| also, if I have multiple models, I keep like general functions in
64.94|2.8| there. For example, computing, the accuracy would be such a
67.74|3.48| function. And I also have a settings file with your model
71.22|3.2| settings and hyper parameter settings, and so forth. And
74.42|3.92| then the main train model file, which is used for training the
78.34|6.36| model. So let's open them and take a look. So I'm opening them
84.7|2.72| here in Visual Studio code. What I really like about Visual
87.42|4.04| Studio code is that it's fast and also shows me if I make
91.46|4.88| errors, for example. So if I, let's say, um, I don't know,
96.34|4.32| let's say I make a typo here, I type FLSE set of faults, it
100.66|4.24| would tell me undefined name. So it's quite smart, it will find
105.1|3.92| out if I have something that is not defined. So that's what I
109.02|5.02| like about it. So it's easy to quickly find typos to debug your
114.04|4.18| code. So starting with, let's say starting with a train model
118.22|6.04| file. So the train model file here is importing from the
124.26|3.6| helper file. So there are general functions, like I
127.86|4.32| mentioned, so I'm importing the data loaders, and functions for
132.22|3.12| setting the random seeds and making everything deterministic.
135.74|3.48| I'm this is something I'm using in many different projects. So
139.22|3.5| I'm keeping this in my general file. And also things like
142.72|2.7| computing the accuracy and plotting the training loss and
145.46|3.5| accuracy and so forth. So that's something I like to reuse in
148.96|2.78| other projects. Or if I have multiple train model files,
152.1|4.88| let's say train model, mlp one and train model mlp two and so
156.98|3.52| forth, I can reuse that code, I don't have to copy and paste it
160.5|7.04| every time. Other things here is, I'm also setting it up such
167.54|3.86| that it yeah, that it can read command line arguments, I will
171.4|3.1| show you how to run this in a second. But here, for example,
174.82|3.82| I'm setting it up with this argument parser that accepts one
178.64|4.7| argument called settings dot path and one results dot path.
183.5|3.36| So here, this is where it finds the hyper parameter settings and
186.86|3.56| model settings. And here's where it's putting the log files and
190.42|4.72| results from that run. So my settings file I'm using YAML. So
195.14|4.68| YAML is a thing it sends for yet another markdown language, or
199.82|5.96| mark, markup language. So what that means, it's just a simple
205.82|4.96| way of writing a text file that is human readable. So here's my
210.78|5.44| YAML file. And there's actually a Python library called py
216.22|4.4| YAML, which lets you load these YAML files, I'm doing it here.
220.78|4.86| So if I'm loading it like this, then settings will be a Python
225.64|2.78| dictionary. So it's loading the YAML file into a Python
228.42|3.44| dictionary that I can use. So why am I doing that? It's just
231.86|3.12| for organizing things. So I could, for example, have
234.98|3.4| multiple settings files, and each one has a different hyper
238.38|5.0| parameter setting. And then I can keep everything organized by
243.38|5.08| having these files. But of course, you can always put
248.46|4.66| everything, I could put the settings. Also, instead of using
253.12|4.58| the YAML file, I could of course also write a Python dictionary
257.7|5.8| here. And then you would have to add the strings and then the
263.5|2.92| commas and so forth. So you could also of course, do that.
266.62|4.28| But if you have bigger projects, it might be helpful to organize
270.94|2.48| things this way, because then you have maybe multiple settings
273.42|3.28| files that you want to set up and run in parallel or something
276.7|7.36| like that. Here, I'm using a trick. So to, how can I say
284.06|3.28| that? So usually, I like to print things to the command
287.34|3.76| line when I run my script. But also, I want to keep a record of
291.1|4.24| it later on that I can take a look at. So here, this is like a
295.38|5.04| trick so that you can see the output on the command line. But
300.42|4.72| also, it will be written to a file. So everything I print,
305.16|2.98| this will also be written to a file called training dot log,
308.36|4.02| which will be in the results path. So I'm going over this
312.42|3.6| rather quickly. But if you have any questions, let me know. Also,
316.02|2.82| this is nothing you have to know for the exam or anything. I'm
318.84|2.78| just showing it to you and sharing it with you. Because I
321.62|3.52| think it could be helpful for your project. If you're using
325.18|3.6| Google Collab, it's maybe easier to have everything in a single
328.78|3.36| notebook. But I think, in general, if you are organizing
332.18|3.72| your projects on your computer, it might be helpful also
335.9|3.92| sometimes to use these scripts files before you run them on in
339.82|6.52| a notebook. So yeah, so going down here, just printing some
346.34|3.76| output for logging purposes, that I'm using my set
350.14|2.68| deterministic function from my helper file that I imported
352.82|4.0| earlier, this makes my code run deterministically. That means if
356.82|3.04| I run it again, I will get exactly the same results. There
359.86|4.8| are also the data loaders I'm loading here. So it's, I think
364.66|2.52| more convenient, because it's a lot of code to put this into a
367.18|4.6| separate file, if I go here again, so the data loader, I
371.82|2.64| think I'll put it on the bottom here, it's actually a pretty big
374.84|4.46| code chunk. So I'm just writing it here, and then reuse that in
379.3|3.6| my different projects when I use MNIST. So I don't have to always
382.98|2.72| put all the code into this file, I just have to copy and paste
385.7|5.8| my helper file. Alright, so here, this is now how I provide
391.5|4.12| the hyper parameters, because settings is a dictionary, it has
395.62|3.88| the dictionary entries, corresponding to these entries
399.5|4.12| here. So there's a batch size. So I'm passing, so I'm not
403.62|2.44| hard coding these values, they're all read from the
406.06|3.68| settings files. So if I change my settings files, I don't have
409.74|3.44| to, I never have to modify train model. So I never have to really
413.18|3.32| touch that I can do a hyper parameter tuning by just
416.5|3.92| changing this only this one single file. Alright, so then
420.42|4.16| there's my multi layer perceptron here. Just a regular
424.58|3.92| training using a different use Adam here, I just see could also
428.5|4.4| use SGD, we will be talking about Adam in a future lecture.
432.9|5.4| It's like a slightly improved version of SGD. Yeah, and then
438.3|3.98| this is just the whole code I used also in the previous
442.46|3.76| notebooks. And then, yeah, I have a plotting function for
446.22|2.72| plotting the loss and the accuracy. Again, you don't have
448.94|3.76| to know all these details. It's just can copy and paste that
452.7|4.6| from my code. It's usually just something. Yeah, it's more like
457.3|5.92| software engineering at that point. Um, yeah, I also, just
463.22|5.2| for bookkeeping, I create a results dictionary. So here, I
468.42|4.36| keep the training accuracies, the validation accuracies, the
472.78|5.6| final test set accuracy, and also the settings for also
478.38|3.2| bookkeeping. So if I want to look that up later, I have a
481.58|3.24| record of that. So for example, let's say you run your model.
485.02|2.6| But later on, you decide you want to make some different
487.62|2.48| plots. This way, you don't have to rerun your model, you have
490.1|3.84| all your data here. And I'm saving that to a YAML file.
494.82|6.6| Alright, so let's run this then and see how it works. So here,
501.42|3.56| I'm in this folder. And if I want to run this, I type Python
505.46|3.48| train model, but pi and then remember that two arguments, I
508.94|4.16| can maybe try to run without it should complain. Yeah, it says
513.5|2.88| following arguments are required settings path and results path.
516.62|4.28| So just to show you, let me show you the results. You can see it's
520.94|5.84| empty right now. Now I'm executing it Python train
526.78|5.84| model and giving it the settings path. Just called it settings
532.62|8.68| dot YAML. So this is just this file here. And then results path.
544.22|9.52| Just call it results. So then it's running. And you can see
553.74|2.92| while it is running, it's putting things here. But it's
556.66|3.68| already also putting a log file here. So you can either check
560.34|3.72| the command line here. Or you can already if you don't have,
564.3|3.08| let's say if you are on the server, and you don't have a
567.38|3.72| stable connection, and this gets interrupted, then you still have
571.1|3.28| this log file here. Okay, that's already finished. I was pretty
574.38|3.88| quick. So now everything we have seen is in this log file here as
578.26|3.08| well. So just for records for future record, if you close this
581.5|4.12| session here, you will have it still available. Then we have
585.62|4.22| all plots here that we generated. So this is a slightly
589.84|3.18| fancier version of the mini batch loss. So yeah, I'm
593.02|7.48| computing the running average. And yeah, this is on the left
600.5|3.32| hand side, the training and validation accuracy for the
603.82|4.64| different epochs for the 10 epochs. Yeah, and I have that
608.46|3.36| now for my records. And I also have this results dictionary if
611.82|4.08| I want to create new plots. So this is also a YAML file with a
615.9|5.12| settings, the final test accuracy, the training
621.02|7.32| accuracies, and validation accuracies. Of course, if you
628.34|4.76| have, let's say you have a Jupyter Notebook, you it's
633.1|2.42| sometimes more convenient, for example, if you want Google
635.54|4.2| collab, to have everything in a single file, but there's also a
639.74|4.44| way you can do a hybrid of that. So if I go into this directory,
644.18|3.72| let me just create a new Jupyter Notebook, for example, like
647.9|3.76| here, it's a new Jupyter Notebook, I can also maybe don't
651.66|8.08| have to use a YAML file. But I could also close these files on
659.74|9.5| second. I could also import from my helper file. So when I have,
669.24|4.34| for example, here, these imports from helper import, I can do
673.58|3.56| the same thing. Also with my Jupyter Notebooks, I can also
677.14|2.92| import here and see. So only the only thing I have to do is I
680.06|3.28| have to have the helper file in the same folder as the Jupyter
683.34|4.4| Notebook. But that way, you can keep your Jupyter Notebooks
687.74|3.28| rather small, you don't have to make them huge. So you can
691.14|4.42| technically you could also copy and paste this, you have to make
695.56|4.42| some modifications because we don't have these arguments, but
699.98|8.28| we could say, um, yeah, arcs result path. The problem would
708.26|5.88| be we had, we would have to change this one to result path,
714.74|6.92| we could do it like this. And then let's say results. And then
721.66|10.72| settings like this, and then we have to remove this arc here
732.38|6.24| everywhere. So I can maybe quickly do that is by making a
738.62|8.0| new text file. And then replace arc dot, actually don't know
746.62|4.08| this works here. Okay, I would maybe I can do that in quick more
750.7|11.6| quickly here. arcs dot, just replacing every instance of arcs
763.62|13.56| like this. And then copying it back here. Okay. Yeah, that
777.18|3.24| should technically work, it will probably complain, I've probably
780.42|1.32| forgot something here.
785.06|0.96| Well, it actually works.
787.5|3.12| Yeah, so we could also run the code then in the Jupyter
790.62|4.0| Notebook here if we wanted to. So note that we saved some space
794.62|3.16| by not putting these functions from the helper functions into
797.78|2.68| this notebook. So it's a little bit shorter. So this way, you
800.46|4.24| can also take advantage of that on Google Collab. Alright, so
804.7|3.52| this is it for the coding examples, I will upload them all
808.22|3.64| to GitHub. So you can take a closer look. And then we will
811.86|28.56| continue with some aspects about multilayer perceptrons.