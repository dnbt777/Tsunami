start_time|end_time|text
1.22|2.72| Yeah, if you remember, I mentioned there are three broad
3.94|2.48| categories of machine learning. And if you counted with me, we
6.42|3.32| already covered those three, they are supervised learning,
9.74|3.36| unsupervised learning and reinforcement learning. So yeah,
13.1|3.24| why is there another video on the three categories of deep
16.34|4.56| learning? So they are actually two special cases of supervised
20.9|2.12| learning that I just wanted to briefly cover because they are
23.02|4.24| super interesting. So one is called semi supervised learning,
27.26|2.84| which is kind of like a mix between supervised and
30.1|4.28| unsupervised learning. So in that scenario, we have some
34.38|2.72| labels for some training examples, but not labeled for
37.1|4.5| others. So semi supervised learning is about using the
41.6|3.52| labeled training subsets to label the unlabeled portion of
45.12|2.78| the training set for which we don't have labels, and then we
47.9|3.8| can use them to make a better decision boundary. So here's a
51.7|3.24| sketch that I made, like a very simple example. On the left hand
54.94|3.72| side, we have a supervised data set. So this is strictly
59.74|5.16| supervised, where we only have two classes, the class one here
64.92|3.62| and the class two. So these are our two classes here. And we
68.54|2.64| made the right for decision boundary like that. So again,
71.18|3.0| this is a two feature problem. And our decision boundary might
74.18|4.32| be just like here in the center between the two. Now consider a
78.5|3.6| case where we have more data, but the data is unlabeled. So
82.1|3.78| consider this unlabeled data, I added it here on the right hand
85.88|4.34| side. So these blue dots are the unlabeled data points. And if I
90.22|2.8| consider these unlabeled data points, a semi supervised
93.04|3.7| learning system may derive a slightly different decision
96.74|3.52| boundary. So going from here to here, I have not changed the
100.26|4.04| position of the class one and class two examples. However, I
104.3|3.72| added these blue dots here. And the machine learning system may
108.02|3.52| use them to put the decision boundary more like this
111.54|3.96| diagonally. Of course, it assumes or makes the assumption
115.5|3.88| that this data point is actually one of the diamonds, the class
119.38|2.56| one ones, it doesn't have to be correct. We don't know because
121.94|2.6| we don't have labeled information. It's just an
124.54|4.36| assumption. But yeah, we can actually still use this data to
128.9|4.4| make assumptions. And this can potentially improve the system.
133.5|2.56| So in this case, the decision boundary might be slightly
136.06|2.68| different. And this might be a slightly better decision
138.74|4.64| boundary. Yeah, this is a special case of supervised
143.38|2.8| learning. Other case of supervisor of supervised
146.18|3.68| learning is self supervised learning. And this is a very
149.86|4.16| popular area of research right now in deep learning. So it's
154.02|3.12| yeah, it's a very recent development and very hot topic.
157.62|4.88| And it's particularly useful also for training large models
162.5|3.68| that need a lot of data. And where we don't have access to
166.18|5.04| Yeah, these large amounts of data. So it's usually about
171.62|5.16| pre training a model on a larger data set, and then you're
176.78|3.04| fine tuning it on a smaller data set. So this is sometimes also
179.82|3.88| called transfer learning, because we are transferring the
183.7|7.48| model from one task to another task. And yeah, here, why is it
191.18|4.8| called self supervised learning? It's because we are deriving a
195.98|3.88| utilizing label information directly from the data itself,
200.06|5.52| rather than having humans annotating it. So let's let me
205.58|3.76| think of an example. So you have probably heard of BERT, the
209.34|2.96| language model, it's a very large model of billions of
212.3|2.28| parameters, it's very hard to train, you need a lot of data
214.58|4.0| for that. However, you don't have really millions of
218.62|3.96| documents that are labeled with some classification task. So
222.58|5.04| think of building a spam classification system, you want
227.62|3.6| to build a very good system. But you have a lot of parameters in
231.22|4.76| this model. So but you only have, let's say 100,000 labeled
235.98|4.24| images labeled emails, which are not enough for the system. So
240.22|2.72| what you can do is you can pre train it on all the text on the
242.94|3.92| internet. And here, how do you get the labels for that you make
246.86|4.4| up some labeling task that is kind of contained in the data
251.26|3.8| set itself. So in the case of BERT, this BERT model, what the
255.06|5.96| researchers do is the mask, I think it's 15% of the words. So
261.02|3.96| they give it the text, some text on the internet, and they remove
265.02|4.96| 15% of the words, and they let the system predict these words.
270.1|3.28| So for that, so you are kind of removing or withholding the
273.38|4.2| labels, but you're using the data itself as the label
277.58|4.4| information. So you are, you have, let's say a sentence, and
281.98|3.92| then you remove, let's say these parts of the sentence, and you
285.9|3.44| have the model, predict these parts of the sentence, but you
289.38|2.92| you know what the correct labels are. So in that way, you can
292.3|4.44| teach the machine. Or another second self supervised task
296.78|4.16| within the BERT system is predicting whether a certain
300.94|3.28| sentence is contained in the document. For example, if you
304.22|5.32| have a document with multiple sentences, you remove one of
309.54|3.64| these sentences, or you just take it out, and you make up a
313.18|3.32| new sentence, a second sentence, it's not in the same document,
316.5|1.84| you just maybe make it up or take it from a different
318.34|4.48| document. And then you let the system predict which of the two
322.82|3.24| sentences is actually in the real document. So you, you kind
326.06|3.76| of make up these classification tasks by yourself, you create
329.82|3.44| them from the data without needing a human to label it.
333.26|3.42| Because yeah, in that way, you teach the model to understand
336.7|4.56| the sentences. However, it still cannot predict spam or non spam,
341.26|3.84| it can only predict now missing words or the sentences, but it
345.1|3.68| kind of helps the model to deal with language. So after you
348.78|4.48| completed the training of the BERT system, with self
353.26|3.24| supervision, you can take this pre trained system, and then fit
356.5|5.8| it on the smaller spam and non spam data set to have a
362.3|3.0| prediction task now that is a little bit different. But yeah,
365.34|2.64| during this task, it learned how to understand language, and then
367.98|2.92| you can apply it to the classification task to train it
370.9|3.92| on that one. So this is called here on this one, on the right
374.82|5.36| one, it's called pre training, and then you have the transfer
380.18|4.0| learning and then fine tuning on the real data set you care
384.18|2.84| about. So this would be an example of self supervised
387.02|4.44| learning. Another case of self supervised learning is from the
391.46|4.04| image domain from computer vision, where, for example, you
395.5|3.76| want to train a classifier to classify cats and dogs, but you
399.26|2.6| don't have many cats and dogs in your data set. It's very small
401.86|4.16| data set. So you want to use unlabeled images, for example,
406.46|2.44| to have it learned. So here, you don't know what's in the image,
408.9|2.36| because you don't have the labels for that. But you can
411.26|3.84| actually use the image still. So what you can do is you can
415.66|3.76| divide the image into smaller images here. And what I've shown
419.42|4.0| you as an example is by dividing the images in eight, or actually
423.42|6.52| nine parts. And then you take out one part, and you predict
430.22|4.32| whether another part is a label on a neighbor or not. And you
434.54|3.64| know, the answer for that, because you know, this image and
438.18|3.76| you divided it yourself, you can write a Python algorithm for
441.94|7.36| that, you know, all the labels here, the 12812345678. And you
449.3|5.28| withhold this ninth part. And then you ask basically, which
454.62|4.92| so you, you have extracted this part, you presented to the deep
459.54|3.32| learning system, or the convolutional network. And then
462.86|4.96| you present it with another one of these. So you have seven
467.86|3.16| other of these image chunks. So here, I have it next to it. And
471.02|4.0| then you have it predict what label is, is it the seven
475.34|3.04| position seven, position five, position three, and so forth. So
478.38|2.76| you know the answer, because you were the one dividing this
481.14|3.32| image was, let's say, a Python algorithm. And you have the
484.46|3.0| machine, then, or you teach the machine to predict the right
487.46|3.68| position. So why is that useful, if you want to build a cat
491.18|4.4| versus doc classifier, this is really like helping the system
495.9|4.04| to learn to understand what's in the image, what's an object,
500.1|2.16| because it kind of has to understand a little bit about
502.26|3.44| cats here, to put them in the right order, because here, you
505.7|3.76| have the ear, there's an eye here, a part of an eye, that's
509.46|3.32| part of an eye here. So it has to kind of somewhat learn the
512.78|4.36| structure of a cat to put these pieces into the right order. And
518.22|2.48| you have maybe also other objects there, like dogs and
520.7|2.52| cats and other animals. So it kind of learns the structure of
523.22|5.88| an animal. And it's like the pre training task again. And then
529.1|2.96| after this pre training, you can take your network and fit it
532.06|2.96| onto a smaller target data set that is, let's say, concerned
535.02|3.92| with animal classification. But again, self service learning,
538.94|3.68| it's like a very recent very hot topic, we will maybe briefly
542.62|4.52| revisit this in the context of transformers at the very end of
547.14|2.76| this course. But yeah, I just wanted to mention it for
549.9|3.28| completeness. It's more like an I would say a little bit of an
553.18|3.24| advanced topic for this introductory course. So I just
556.42|2.44| want to introduce it that it exists, you might find that
558.86|2.68| interesting, you can maybe play around with that in your class
561.54|2.3| project, that might be something to explore. There are many
563.84|2.76| different types of self supervised learning approaches.
566.6|4.1| But yeah, that would be another special case of supervised
570.7|4.9| learning. So okay, now I covered all the broad categories of
575.72|4.12| machine learning. And the next on the remaining three parts of
579.84|2.02| lecture one, they will be probably hopefully a little bit
581.86|4.64| shorter. I will briefly talk about the supervised learning
586.5|4.32| workflow, like going into a little bit more detail of how we
590.82|4.08| get train a supervised learning system, the different steps. And
594.9|4.48| then I will introduce some of the notation and jargon like
599.38|5.78| some mathematical notation, like how we use symbols to denote a
605.16|3.74| training set and loss function and things like that. And then I
608.9|3.64| will talk a little bit about the tools pytorch that we will be
612.54|3.48| using just introducing it. And we will cover that also in more
616.06|4.0| detail in a later lecture. But yeah, this is also just the
620.06|5.2| introduction. So if there are some details that I introduced
625.26|3.32| here, that are maybe too much detail, and it's confusing, don't
628.58|3.44| worry about it. I just wanted to give you a brief picture
632.02|4.56| overview. And we will cover the important details really much
636.58|5.24| more slowly later in this class. Alright, so that's it for now.
641.82|8.76| And the next video will be on the supervised learning workflow.