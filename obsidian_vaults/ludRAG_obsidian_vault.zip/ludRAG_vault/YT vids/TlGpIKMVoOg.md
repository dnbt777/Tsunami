start_time|end_time|text
0.48|2.4| Yeah, so in this video, I'm going to show you how we can
2.88|5.04| implement a perceptron in Python using NumPy and pytorch. So I
7.92|3.72| will be using Jupyter notebooks, because I think for simpler
11.64|2.76| code examples, it's actually quite nice to use Jupyter
14.4|3.56| notebooks, because I can execute one thing at a time, and it will
17.96|3.24| make things easier to explain. However, later on in this
21.2|4.64| course, we have to I think move to Python script files, because
25.84|4.48| when the deep learning models become larger and larger, managing
30.32|2.56| them and Jupyter notebooks can be a little bit, I would say
32.88|4.2| tedious and also dangerous. Because it's easy to lose the
37.08|2.48| overview and debugging is a little harder if you have the
39.56|2.9| separate cells and stuff like that. And then the danger is
42.46|5.16| that you might execute things out of order. And yeah, also, you
47.62|3.02| want to import certain aspects from different files, you don't
50.64|1.8| want to have everything in one notebook, because then it
52.44|4.48| becomes really confusing and manageable. But we will get to
56.92|4.68| these parts later in this course. So yeah, so back to
61.6|3.84| this topic of the perceptron implementation in NumPy and pytorch
65.84|4.04| on all the code files are actually on GitHub. So if you go
69.88|3.16| here to this link, or I will also link them on canvas so that
73.04|3.2| you can just click on them if you are interested to play around
76.24|4.74| with them. The homework will be based actually on the NumPy one
80.98|3.7| where I will ask you to implement this in plain Python,
84.8|4.64| just to make sure you understand what's going on. And by
90.4|3.74| converting NumPy code to Python, I think you will work with the
94.14|2.58| code step by step and get a better understanding of these
97.44|3.6| individual things. And I think also you're going from NumPy to
101.04|3.2| Python is easier than from Python to NumPy if you are
104.44|5.08| relatively new to NumPy. So in that way, let me now walk
109.52|2.82| through the NumPy notebook. The pytorch notebook is actually
112.34|2.64| very, very similar, which is one of the cool things about
114.98|3.02| pytorch, because it is very similar to NumPy. Except there
118.0|3.06| are some extra features that we will be using later on. And I
121.06|2.98| will have a lecture on pytorch where I will explain you these
124.04|4.76| differences. So for right now, it doesn't make such a big
128.8|3.12| difference whether we use the NumPy or pytorch notebook. I
131.92|3.64| will also show you a step by step comparison after I
135.64|2.64| explained the NumPy notebook. So you will see what's actually
138.28|4.02| different between the two. Alright, but let's do one thing
142.3|4.1| at a time. So here, I will make this a little bigger. I hope
146.4|9.12| it's easier to see them. It's almost too big. Alright, so yeah,
155.52|4.44| so I'm starting here, let me clear, maybe the outputs, and
159.96|3.96| then I will execute them one at a time. So I'm importing some
163.92|4.24| libraries for those who have not used notebooks, this one here,
168.16|3.8| this command is for showing plots in the notebook. It's
171.96|4.0| technically not necessary anymore. Always sometimes, on
175.96|3.08| some computers, plots will not be shown in a notebook, if you
179.04|2.2| don't include that line, and it doesn't hurt to include that
181.24|4.52| line. So I always do this. Here, I'm just loading the data set.
186.72|2.64| So there's nothing really interesting happening here. But
189.36|4.4| I will step through this step by step. So the data set is like
193.76|3.24| some toy data that I generated, I will show you how that looks
197.0|3.32| like shortly. So here, I have two feature columns, I didn't
200.32|3.56| include any column header. But this is the first feature. This
203.88|3.52| is the second feature value. And this is the class table here. So
207.4|3.28| there are zeros and ones. And you can see the data set is not
210.68|2.8| shuffled. And actually, it's helpful for learning if the
213.48|2.56| data set is shuffled, it will make the learning a little bit
216.04|7.28| faster in the perceptron. Yeah, alright. So here, I'm loading
223.32|4.32| the data set into NumPy can also use pandas. But I thought it
227.64|2.36| might be overkill, because it's a relatively simple data set.
230.4|6.12| And then I'm assigning the features to x, which is a
236.64|4.6| matrix, then, and y, which is the class table. I can maybe
242.44|4.64| show you just how they look like. So this is x, it's a matrix.
247.12|5.4| And y is class level array. So here, it's shuffled because I
252.52|3.12| actually executed this whole bunch of code. So you then can
255.64|4.56| already guess what's going on here. So here, I'm loading the
260.2|3.04| data, and then just printing some summary information, it's
263.24|3.24| always, I think a good idea to do that to get an idea. So we
266.48|4.72| have 50 labels from class zero and 50 labels from class one, we
271.2|4.88| have thus 100 data points in total, and two feature columns,
277.04|3.4| and also 100 labels. So, for example, here, we can see, okay,
280.44|2.8| these and these match numbers match. So and that's what we
283.24|3.32| expect. It's just some sanity checks here and some making sure
286.56|5.24| that everything looks okay. Then here, I'm shuffling the data set
291.84|5.04| so that they are not all in order, they are shuffled. And
296.92|5.04| how I'm doing that is I have to shuffle x and y together, right?
301.96|4.08| So otherwise, on everything will be mixed up, then the features
306.04|2.68| won't correspond to the class labels anymore. So how am I
308.72|2.92| doing that is I'm creating a shuffle index. So I can just
311.64|9.0| show you creating this shuffle index here. And how it looks
320.64|5.16| like this is just the numbers from zero to 99. So the 100
326.2|4.92| indices, and then I'm actually shuffling these indices. So here,
331.12|3.76| I'm generating random number generator, and then I am
334.88|6.52| shuffling these indices here. So you can look at these after
341.4|13.0| shuffling. So after I execute that, you will see that oops,
354.44|3.36| that's too much. But you will see they are no random order.
358.04|3.48| And then I'm using that to select the data points from x
361.52|5.28| and y. So then x and y will be shuffled based on the shuffle
366.8|4.36| index here. So that's how we shuffle. And then I will use the
371.16|7.64| first 70 data points for training. And the last 30. So
378.84|3.32| we have 100 data points to 70 to 100. The last 30 data points
382.4|4.56| will be for our test set. Later on, we will be seeing or using
386.96|3.6| more convenient ways to load data in pytorch. So there are
390.56|3.36| some loading utilities here, I'm just doing it step by step. So
393.92|4.8| you get a feeling of what's basically going on. And then I'm
399.28|2.88| normalizing the data. So this is sometimes also called
402.16|5.56| standardization. So here, I'm standardizing the data such that
407.76|2.96| after standardization, it will have mean zero and unit
410.76|3.52| variance. So I'm subtracting the mean and divide by the standard
414.28|2.52| deviation. So here, I'm computing the mean and
416.8|6.44| standard deviation of my sample. And then I'm subtracting the
423.24|5.44| mean and divide by the standard deviation. And then both will be
429.16|4.6| having mean zero and subdivision one, so unit variance, so you
433.76|2.68| can actually check that.
436.44|10.4| Oops. It's not quite true, because we have to look at the
446.84|7.52| training. Okay, very close to zero. So this is 70 digits after
454.36|4.4| zero. So 0.000 or something up to two. So very, very small.
458.76|4.6| It's almost identical to zero, essentially. And then for the
463.36|5.44| standard deviation, it should be around one. Yep. So the data is
468.8|2.84| standardized. Well, why am I doing that? It kind of speeds
471.64|2.76| up training a little bit. It's like stabilizing the training
474.6|3.92| for the perceptron. It's not that necessarily necessary. But
478.84|4.44| it is a good practice to do that for other types of optimization
483.28|3.48| algorithms later on when we talk about stochastic gradient
486.76|2.92| descent. So this is something standardization that is usually
489.68|2.84| recommended. The only types of machine learning models where
492.52|3.0| this is really not that necessary is like for tree
495.52|3.72| based models. That is something we covered in or that was the
499.24|3.4| end discussed in statistics 451. When we talked about decision
502.64|3.52| tree algorithms, these don't require standardization. But all
506.16|2.6| other machine learning deep learning models, I know, they
508.76|3.04| can usually benefit from that, like, especially stochastic
511.8|3.92| gradient descent will just learn faster, which is something we
515.72|4.04| will be doing later. So it's just a good practice. Alright,
519.76|3.24| let's take a look at the data. So here, this is our training
523.0|2.8| set, how it looks like. So you can see it's around centered at
525.8|5.8| zero. We have two classes, class zero, these circle here, and
531.6|3.52| then the square for class one. So feature one and feature two,
535.68|3.8| that's our training set. And so there should be 70 examples, and
539.48|3.36| then the remaining 30 examples in our test set. So what we
542.84|3.32| want to do is we want to train our model on the training set
546.16|4.36| and then evaluate it on the test set. So let's implement our
550.52|5.16| perceptron model then. So yes, the perceptron code, you can see
555.68|3.72| it's relatively short, I'm implementing it using a
559.4|5.0| forward and backward method. Why I'm doing that is because that
564.4|4.16| is also how things are done in pytorch. And it will make things
568.56|4.6| more familiar later on if I start using this habit. Alright,
573.16|2.84| but let's start at the top. So I'm implementing it as a
576.0|4.52| class here. And yeah, you should be I think familiar with Python
580.52|7.6| classes. So here, what I'm doing is I'm running the constructor.
588.12|3.6| So this is a special class method, a constructor, I'm
591.72|2.58| giving it the number of features, because that's what I
594.3|4.54| need to know the number of weights. And I'm using here, the
598.84|2.88| implementation where the weights and the bias are separate,
601.76|3.6| because that is more convenient. So I don't have to modify the
605.36|3.12| feature vector. So what I'm doing here, if I go back to my
609.76|5.96| lecture slides, I'm using this, this notation here where we have
615.72|3.12| the bias separately. So I'm initializing the weight vector,
619.12|3.88| and the bias units, the bias unit is just a single value,
623.04|3.96| that's just one number. And the weights, the weight vector, it
627.0|2.44| depends on the number of features, right? So I make this
629.44|8.52| a column vector, sorry, a row vector. So this is then this
638.0|5.56| equal to m, the number of features. All right. So here,
643.56|3.4| I'm just setting up my weights and bias and setting them to
646.96|3.84| zero. Later on, for certain algorithms for stochastic
650.8|2.52| rendition, it's better to initialize them to small random
653.32|2.72| numbers here for the perceptron, it's not necessary. But for
656.04|3.4| neural networks, it will be necessary later on, we will see
659.44|5.32| that in the forward method, I'm computing the net inputs,
665.16|3.04| actually here in linear. And then I'm predicting the
668.2|2.28| prediction, computing the predictions, that's my
670.48|5.24| threshold. So this is the net input. I'm calling it linear,
675.72|5.0| because later on, we will also see linear layers in pytorch,
680.72|6.84| they are called linear, and they are basically computing net
687.56|6.12| input. So this is you can see the dot product between the
693.68|4.64| input vector and the weights. So that is computing this part
698.32|5.64| here. And then I'm adding the bias here. I can actually make
703.96|6.16| this bigger. Alright, um, then here we have our threshold
710.12|2.16| function, this threshold function is just using NumPy
712.28|4.2| where so how this works is it's saying if linear, so if the net
716.48|4.52| input is greater than zero, then output one, otherwise output
721.0|5.56| zero. So it's our forward method. And here is our
727.12|3.38| backward method. So the backward method, why am I calling it
730.5|5.06| like that? It is for computing the arrows. So usually, yeah,
735.56|2.56| when we have deeper neural networks, we will use something
738.12|3.08| called back propagation, where we look at the outputs. And then
741.2|4.04| based on the outputs, we adjust the inputs. So in that way, we
745.32|4.0| run the forward method to produce the predictions. And
749.32|4.4| then we compute the arrows and then update. So it will become
753.72|3.04| more clear when we have a deeper network where there's really
756.76|4.96| like a back propagation going on. So these are our two
761.72|4.28| methods. So backward is computing the arrows, which is
766.0|2.96| the difference between the true class labels and the predictions.
769.44|3.88| And forward is used to get the predictions in the first place.
775.12|2.36| Let me see here. So this is
779.08|4.2| what we just implemented. So we implemented here the prediction
783.28|5.28| that's going on here, prediction is equal to step A. And then
788.56|6.08| step B is the backward pass with which gives us the arrows. And
794.64|5.08| now we have to put everything together. So I implemented train
799.72|4.96| method here. So for so this train method is basically the
804.68|5.12| whole, the whole thing here. So for epoch in the number of
809.8|5.0| epochs, so this is for every training epoch. And then for
814.8|6.9| every training example, this is here, this part, we perform the
821.7|7.42| four paths path, backward path, and update. Alright, so since
829.12|3.32| backward is already doing all forward, we just call backward
832.44|4.14| here. There's some ugly reshape here going on. And that is
836.58|4.34| because we are making the vector dimensions match. Otherwise, you
840.92|3.88| will get some arrows. So here, I'm just making the dimensions
844.8|8.28| met, you can maybe let's take a look. So here, this will be one
853.08|5.96| row and m columns. So it will be I think this is called a row
859.04|2.92| vector I said earlier, the other one was a row vector. But yeah,
861.96|3.48| I'm always confusing the words, row vector and column vector.
865.52|4.44| Because here, this is just one, one row and multiple columns.
869.96|2.56| But this is because there are multiple columns, but still
872.52|2.48| called row vector, because it looks like a row. Anyway, so
875.08|4.76| here, we have this row vector here. And this has to have the
879.84|5.08| same dimension as why it's in this way. I'm just making this
884.92|6.48| the same dimension. So you can compute everything nicely.
891.4|3.52| Otherwise, you will find there will be a dimension mismatch. So
894.92|6.28| there's just a reshaping going on here. And then here, we
901.2|3.96| perform the update. So again, I'm doing the reshape
905.16|2.76| afterwards, so that we get the original dimensions back,
908.08|6.4| because because the weights here, they also have the same.
914.48|3.52| So see, we are matching the original dimension. So we're
918.0|3.44| just reshaping so we can add to it. Otherwise, there will also
921.44|3.28| be a dimension mismatch if this is just a single number, or if
924.72|3.44| it's a one times m vector instead of m times one vector.
928.16|3.72| So yeah, this is annoying to do this reshaping, technically would
931.88|2.6| also I think not be necessary if I remove the dimension from
934.48|4.12| everywhere. But here, that's more explicit actually doesn't
938.6|5.96| hurt. Just like you have to be aware of that. And then also we
944.56|4.6| update the bias. So the bias, it's just updating it by the
949.16|5.6| arrows. The reason is, think about it, if we would have one
954.76|7.64| here, if I have a one here, so this would be one times the bias
962.4|6.64| unit instead of so the input would be the one, right. So
969.04|4.24| instead of saying errors times the feature, we would have be we
973.28|4.92| would have error times one, right. So error times one. And
978.2|4.2| we can cancel the ones instead of writing it like this. Since
982.4|3.48| we have the bias separate, I can just cancel this, we don't have
985.88|5.8| to include that. Yeah, the next evaluating it. So evaluating
991.68|4.2| the performance here, I'm just doing the forward pass. And then
995.88|3.88| compute the accuracy. The accuracy is computed by checking
999.76|3.84| how many of the predictions match the true label, and then divide
1003.6|3.44| by the data set size. So it will be giving me a number between
1007.04|7.16| zero and one. Alright, so this is my perceptron. And then here,
1014.2|4.28| I'm training it. So yeah, initializing it, and then
1018.76|3.0| training it for five epochs. And then I will print the model
1021.76|5.28| parameters afterwards. It's pretty fast. So we get the
1027.04|5.88| weights, the weight vector 1.27 1.346. And then the bias is
1032.92|3.92| minus one in this case. And now we can evaluate it, compute the
1036.84|4.08| accuracy. So the test set accuracy is 93%. It's not quite
1040.92|6.36| 100%. On the training set, it should actually have 100%,
1047.28|5.64| right? Because it's linearly separable, this data set, and
1052.96|6.12| it should converge if it's linearly separable. Let's do
1059.08|22.56| that. Yeah, that's 100%. Everything is classified
1081.64|5.0| correctly tested is not as good because we may overfit. So let's
1086.64|3.48| take a look at the decision boundaries. So here is some
1090.28|3.04| complicated code to compute the decision boundaries. It's
1093.32|3.48| actually not complicated is what I did is I rearrange things
1096.8|5.04| here, right? So what we have is if you think about it, the
1102.12|4.44| decision boundary is greater or equal to zero. So everything
1106.56|6.32| hinges upon zero. So if we have our computation, it's x zero
1112.88|7.16| times w zero, right? Plus this on it and put x one times your
1120.04|4.24| one with me. Yeah, that's correct. Let me just wanted to
1128.84|2.0| bring that a little bit more closer together. It's easier to
1130.84|3.6| see and then plus the bias, right? So this hinges upon zero.
1134.72|4.8| And now let's see on nets. So what we're interested in is what
1139.52|4.96| we're doing here is we are taking one fixed number. So
1144.48|4.32| let's say we're taking for feature zero, the minimum value
1148.8|2.8| of minus two. So we are going to the left hand side here. And
1151.6|1.48| then we want to find so this is
1155.72|5.32| for x zero x. So x zero is the x axis and x one is the y axis.
1161.32|4.12| So we take minus two this data point here. Or actually here, we
1165.44|3.92| only know minus two, and we want to find the corresponding x one
1169.36|6.28| value. So this is this is x zero. So it's at minus two. So
1175.64|3.92| what is the corresponding x one value? So we have to rearrange
1179.56|5.56| this solving for x one, right? So what we do is we move this
1185.12|3.84| stuff, and this to the left hand to the right hand side. So we
1188.96|13.28| have x one times w one equals two minus x zero times zero
1202.88|4.16| minus b, right? So I'm just subtracting this and this. So
1207.04|3.2| it's now on the right hand side. And then I want to know x one,
1210.24|3.56| right? So I divide by w one. So when I divide this,
1213.8|7.24| and so this is basically essentially what I've written
1221.04|4.36| here. So I get the x one value, I'm calling it min. The reason
1225.4|2.28| is because it's the left hand side, then I'm doing the same
1227.68|3.48| thing for the right hand side. So I'm doing it for the right
1231.16|4.52| hand side. I'm again setting x zero to some value, I'm setting
1235.68|4.24| it to two here. And then I'm finding the corresponding y axis
1239.92|3.32| value, which is this x one max here. So I'm doing the same
1243.24|3.32| thing, just rearranging. Now I'm using a max value. And then I'm
1246.92|3.44| connecting these lines. And that's how I get this. I've done
1250.36|2.92| this here for the left hand side for the training set and right
1253.28|6.84| hand side for the test set. So yeah, one is the training set,
1260.12|1.0| and one is the test set.
1261.12|15.36| So this should be the maybe easier to write like this. The
1276.48|2.92| decision boundary doesn't change actually, because it's the same
1279.4|3.02| for the training and test set. Just the data set is different
1282.42|4.62| because the decision boundary only depends on w, right? So we
1287.04|2.28| are providing these are fixed values, we are providing them.
1289.32|3.48| And the decision boundary only depends on these parameters on
1292.8|2.6| the model parameters. So the decision boundary does not
1295.44|4.04| change here. So this is for the training set. And this is for
1299.48|2.56| the test set here on the right hand side. And you can see in
1302.04|2.8| the training set case, it perfectly classifies these
1304.84|4.76| examples. And on the right hand side, this is the test that you
1309.6|3.44| can see, it's maybe fitting some of the data too closely. I mean,
1313.04|3.4| there's no other way, actually. But it happens that here in this
1316.44|5.0| case, it doesn't perform well. Actually, yeah, there's a
1321.44|3.04| different way. If you would fit the boundary like this, oops,
1324.72|5.2| like this, more, more straight, then you may get these right,
1329.92|3.68| but it just happens so that these data points are not in the
1333.6|1.92| training set. So the model doesn't know that it should
1335.56|3.76| shift the boundary more to the right here. So in this way, the
1339.32|3.12| model does actually a good job and on the training set, but on
1342.44|3.16| the test set, it's it's not so good. So in that way, it's
1345.6|2.88| actually this term is called overfitting because it fits the
1348.48|2.92| training data a little bit too closely, and doesn't generalize
1351.4|5.8| so well to the test set. Okay, so this is how the NumPy code
1357.2|2.84| works. In the homework, you will be playing around with this a
1360.04|3.28| little bit more and then re implemented in just regular
1363.32|2.64| Python, just removing some of the dot products, replacing
1365.96|5.2| them by for loops and so forth. Um, yeah, the pytorch code, I
1371.16|4.04| don't need to talk about this, I think, because it's the same
1375.2|3.6| same. So this is exactly the same. This is exactly the same.
1379.52|4.28| This is exactly the same. There are some differences here. But
1383.8|3.32| yeah, this is exactly the same this this except that I'm now
1387.12|4.96| using torch tensor instead of NumPy arrays. But yeah, I
1392.08|4.52| prepared an overview here to show you the main differences.
1397.12|3.58| So in class, we will be talking about this in more detail when I
1400.7|5.46| talk about pytorch thing next week or in two weeks, depending
1406.16|3.88| on how far we get next week. So here I highlighted the
1410.04|3.16| differences, though it's also in the slides from the slides. So
1413.24|2.94| on the left hand side, this is the pytorch implementation. On
1416.18|3.38| the right hand side is the pytorch. So NumPy and pytorch.
1419.9|5.18| And you can see there are not that many differences. So the
1425.08|4.84| way the weights and biases are implemented here, we are using
1429.92|3.0| NumPy zeros here, we are using torch zeros, we had a bit more
1432.92|3.2| specific here, instead of saying NumPy float, we say torch float
1436.16|5.12| 32, it's a 32 bit, I have this device here, cause on the way I
1441.28|3.88| implemented things that would also run on the GPU, if there's
1445.16|3.68| a GPU available, if no GPU is available, it will use the CPU.
1448.84|2.72| So there's this device here, which is provided here,
1451.6|5.52| optionally. It's not necessary, though. And what's a little bit
1457.12|3.2| more, it's a little bit different. So here, I mean,
1460.32|2.04| there are multiple ways you can write that you can also use a
1462.36|3.48| plus function, to be honest, I just happened to use torch dot
1465.84|3.52| add, but I could have also used a plus. So what I mean is I
1469.36|3.32| could have, I don't know why I actually did it so complicated.
1472.68|3.72| I could have just had a plus here and remove this torch at
1477.08|1.04| should still work.
1478.12|11.68| Um, yeah, and then the mm is matrix multiplication. And so
1489.8|4.48| in NumPy, we usually write dot in torch, we write a pytorch,
1494.28|5.12| we write mm for matrix multiplication. But in pytorch,
1499.44|2.72| the dot function can also do matrix multiplication. So in
1502.16|3.0| the way, it is kind of like the same thing, it's just looks a
1505.16|2.6| little bit different. The where function and pytorch is a bit
1507.76|3.84| more, I would say involved, not that much more involved, but it
1511.6|3.84| has to have placeholders, such having a one and zero, it needs
1515.44|3.56| to have a tensor here. So I'm creating this as placeholder
1519.0|3.4| here and providing them. But it's the same concept. And then
1522.4|4.28| what's a little bit different here is the last part. So instead
1526.68|4.4| of numpy dot sum, it's torture sum. Here, I'm converting it to
1531.08|4.28| a float. Because otherwise, it will be an integer. And then
1535.36|6.56| an integer divided by some value will give an integer, what we
1541.92|2.68| want to have a float, because it's a fraction between zero and
1544.6|3.24| one. So if you don't do that, you will get back an integer.
1547.84|3.68| And that's not correct, because the value of accuracy is very
1551.52|3.56| between zero and one, which is why I'm casting this to float.
1555.36|3.92| But again, the pytorch code will be covered in class in more
1559.28|6.8| detail later. So um, yeah, that is what I wanted to say about
1566.08|3.28| the code, you get to play around with that a little more in the
1569.36|6.28| homework. Then here, for the optional convergence theorem, I
1575.64|3.68| wanted to make a video about that. But I realize I talked a
1579.32|3.24| lot about the code right now. So I honestly want to wrap up this
1582.56|2.76| lecture, the next day will be probably short, so that in the
1585.32|4.04| next week, we can start a fresh topic. So then we can talk a
1589.36|2.4| little bit about the linear algebra background for deep
1591.76|4.08| learning, some notation, a little bit about calculus, and
1595.84|5.24| then get started with pytorch next week. So in that way, I
1601.08|2.68| think this is not really necessary. So this is some
1603.76|3.76| optional mathematical proof, I will leave it in the slides,
1607.6|4.68| because I spent a lot of time making this. But yeah, you can
1612.28|3.4| read through that, but it won't. So if you don't know about that,
1615.8|3.28| you won't miss anything, because it's not relevant for deep
1619.08|5.6| learning. It's just showing that the perceptron will not converge
1624.88|3.88| if the data is not linearly separable. And you can try that
1628.76|3.4| out in practice. So you can, for example, if you go to the
1632.16|4.7| animation here, this is the animation that I showed you in
1636.86|3.98| class, it's just as a Jupyter Notebook. And you can change
1640.84|3.24| the data such that one of the blue points is here. So you can
1644.08|2.48| change the class table of one of these points, or you can change
1646.56|2.16| the class of one of these points. And then you can run
1648.72|2.6| this, and you will see it will never converge. So here, this
1651.32|4.36| one will converge eventually at iteration 49. But if you change
1655.68|3.88| one data point, such that it cannot separate the data
1660.08|4.72| correctly, it will go on forever, essentially. And this
1664.8|4.2| is what the proof is about. So you can mathematically show
1669.0|3.76| that there's a lower bound and upper bound for the size of the
1672.76|8.76| weights. And based on that, you can basically conclude that it
1681.52|3.6| will converge on if the classes are linearly separable. So I
1685.12|2.96| won't go into too much detail about that, when it will
1688.08|2.84| converge. So this is showing that it is, it will converge if
1690.92|3.56| it's linearly separable. But only if it's a linear
1694.48|3.24| separable. And yeah, in the last video, let me talk about the
1697.72|3.8| geometric intuition about the decision boundary. So again,
1702.04|2.56| don't worry about the convergence theorem, all you
1704.6|5.36| have to know is that the code will run forever if the data is
1709.96|2.84| not linear, simple, and otherwise, it's guaranteed to
1712.8|2.44| find the solution. So it's guaranteed to find this boundary
1715.24|3.36| if it exists. That's what the proof is about. Alright, so next
1718.6|10.0| video, the geometric intuition.