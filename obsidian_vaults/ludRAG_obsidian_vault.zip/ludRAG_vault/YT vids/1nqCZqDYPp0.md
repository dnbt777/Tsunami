start_time|end_time|text
3.2|2.98| Yeah, hi, everyone. I hope you had a nice long winter break and
6.18|3.74| did something fun. And yeah, already for the new semester. My
9.92|2.8| name is Sebastian Raschka. And I'm an assistant professor of
12.72|2.64| statistics working mainly on machine learning and deep
15.36|3.6| learning. So I'm particularly interested and excited about
18.96|3.12| this class. It's about deep learning, as you may know. So
22.08|3.52| and that's very, I have closely related to my research. So in
25.6|4.92| this brief video here, I just wanted to introduce myself and
30.82|3.66| yeah, what we are going to talk about today. So maybe just as a
34.64|5.52| quick icebreaker. So I actually literally spent some lot of time
40.2|3.38| over the winter break on the ice, doing some cross country
43.58|4.94| skiing and enjoying Wisconsin and the landscape here. I really
48.52|4.04| like yeah, Wisconsin snow and stuff like that. So if you ever
52.56|3.0| need a break from studying and want to go outside there are a
55.56|4.12| lots of beautiful parks here, state parks and also mostly it's
59.68|2.72| not very crowded there. So it's actually a great time now you
62.4|3.12| have to hang out outside to do some exercises and have some
65.52|5.08| fun next to studying. But yeah, back to back to the lecture here
70.6|5.72| or class. So on today, I will mainly cover a few topics
76.32|3.36| related to how the class is organized. I will give you a
79.68|3.88| brief overview of what to expect in this course, what topics we
83.56|2.84| are going to cover, how we are going to talk to each other
86.4|3.84| because yeah, it's all virtual and asynchronous. However, we
90.24|4.2| will have live office hours via zoom. So there will be some
94.44|3.9| live component and we will also have everything organized on
98.34|3.06| canvas where everything is easy to find, there will be an online
101.4|3.64| forum to ask questions also asynchronously if you like, or
105.04|3.6| prefer. But again, we will also have live office hours for
108.64|4.12| questions and things like that. Yeah, I will actually turn off
112.76|3.72| the camera very soon when I talk about the remainder of these
116.48|4.14| topics listed here, because I'm using an iPad for this class,
120.62|4.96| and it lies flat on my desk. So it won't be very interesting to
125.6|3.54| watch me taking notes on my iPad, because the camera would
129.14|3.6| be just pointed towards the top of my head. So I will be
132.74|5.2| switching to the iPad view soon. Um, nonetheless, I think using
137.94|2.8| an iPad and the annotation feature is actually quite useful
140.74|3.24| to illustrate some concepts better than just using the
143.98|4.4| slides. So after giving you the course overview here, I will
148.38|3.76| also then later introduce machine learning and machine
152.14|3.28| learning is not a requirement for this class. Some of you I've
155.42|3.84| already seen based on the class list have taken statistics 451,
159.26|2.92| which I taught last semester. This was the introduction to
162.18|3.22| machine learning and statistical pattern classification. So in
165.4|3.7| this class, we talked more about traditional methods for machine
169.1|2.96| learning. And I was very careful when I designed these two
172.06|3.24| courses that there is no overlap. So the other class is
176.18|3.04| focused on traditional machine learning, we cover decision
179.22|3.44| trees, random forests, other ensemble methods, gradient
182.66|3.28| boosting, and so forth. In this class, though, we will be
185.98|2.92| entirely focused on deep learning and deep neural
188.9|3.36| networks. So there will not be any requirement from the last
192.26|4.48| class for this class. So everything right now will be
196.74|3.74| relatively new, except of course, some overlaps that are
200.48|3.04| concerned with supervised learning, basically that we are
203.52|3.76| interested in classifying things. So that will be the only
207.28|3.32| overlap. But I don't think there will be a disadvantage if you
211.28|5.14| take this class without having taken 451. But yeah, long story
216.42|3.42| short, I will give you a brief overview of what machine
219.84|4.44| learning is in this class. And then also just outlining how
224.28|4.36| supervised machine learning workflow looks like some of the
228.64|3.96| necessary jargon and notation, and then also a little bit about
232.72|2.68| the practical aspects of this course, because there will also
235.4|4.84| be a class project, and we will be using pytorch and doing also
240.24|3.0| some coding in this class. So in this way, there will be
243.28|3.52| conceptual and practical aspects. And I hope that is a
246.8|5.2| good mix yet to prepare you for machine learning projects and
252.0|3.16| deep learning projects, and of course, also deep learning in
255.16|3.8| both academia and industry. So in that way, let me then
258.96|3.64| switch over to my iPad and get started with the course
262.6|19.8| overview.