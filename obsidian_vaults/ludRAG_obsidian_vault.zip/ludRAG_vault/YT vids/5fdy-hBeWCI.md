start_time|end_time|text
2.0|3.14| Alright, let's now talk about how we can modify multi layer
5.14|4.28| perceptrons to capture sequence information. So in particular,
9.42|3.84| we are going to talk about sequence modeling with recurrent
13.28|4.72| neural networks. So but before we get to that, how can we tell
18.02|4.92| whether our model already uses sequence information? So for
22.94|2.54| instance, if you think of logistic regression or multi
25.48|3.34| layer perceptrons, do these types of models actually use
28.82|4.08| sequence information? So the answer is no. And how can you
32.9|4.2| know? I mean, there are two ways or two types of sequence
37.1|2.6| information that might be encoded in our training set.
40.1|4.2| One type is across the training example, access and the other
44.3|5.02| type is across the feature access. So maybe to illustrate
49.32|3.94| that let's revisit the iris data set. I know talking about iris
53.26|3.42| is a little bit boring. But I think it's a nice simple data
56.68|4.58| set to illustrate these types of problems. So in iris, what we
61.26|6.6| had, we had, let's call it sepal length, sepal width, petal
67.86|6.94| length, and petal width. So we have this tabular data set. And
74.8|12.12| we have the training examples like 1234 up to 150. Now, when
86.92|5.44| you have this data set, and so let's say this is your data set,
92.52|8.02| and you split it into a training set and test set. And then you
100.54|6.36| train the model on this training set. Let's call it train test,
107.56|4.92| you can shuffle actually, all the records in the test set. So
112.48|3.92| you assume, of course, also, this is shuffled because you
116.4|5.16| want before you split in iris, usually you have the 51st
121.56|4.04| flowers are setosa, the second 50 are Reginica and the third 50
125.6|3.6| are vertical. So let's assume you split them in a way that
129.2|3.48| they're equally distributed now in the training and test set. But
132.68|4.26| now, given the test set, you can actually shuffle all the records
136.94|3.58| in the test set. And when you evaluate your model on the test
140.52|3.9| set, you should still get the same performance. So this is
144.42|3.02| kind of like a way of saying, the model doesn't really use any
147.44|4.34| sequence information, it regards the considers the data as so
151.78|5.92| called iid. iid means that the data is independent and
157.7|4.6| identically distributed. So this means that each training record
162.98|3.24| is independent of each other. So it has been sampled
166.34|5.36| independently. And also, it's from the same distribution. So
171.74|5.84| distribution of flowers, virus flaws. So how to tell whether
177.58|2.92| your model uses sequence information across the training
180.7|4.48| access is really by let's say, doing this thought experiment of
185.18|4.0| shuffling the test set. And you can, of course, probably tell
189.18|3.98| that whether you shuffle the test set or not, the performance
193.16|2.7| of the model should be exactly the same on the test set. If you
195.86|4.68| use multi layer perceptrons or logistic regression. Another type
200.58|4.92| of sequence information might be encoded in the features, right?
205.7|5.62| So the order here of the features. So what you can also
211.32|4.22| think about is if what happens if you swap columns, so let's
215.54|4.28| say you use this, this original Iris data set with these columns
219.82|4.08| here, then you train the model on this data set. And then you
223.9|7.24| test it. Let's say you get 90% accuracy. Now, let's say, just
231.14|3.34| out of fun, you are swapping these two columns here, like a
234.48|3.62| simple length and petal width. Now in your modified data set,
238.1|4.76| you have on let's say, petal width here, and sample length
242.86|4.84| here. And then again, you split this the same way into training
247.7|3.68| and test like you did before using the same records for each
251.38|3.96| data set. Now, if you train the model and test it, you should
255.34|3.56| get exactly the same 90% accuracy, you can try this in
258.9|2.24| practice, you will find the model performance should be
261.14|3.48| exactly the same. And this is because let's say a multi layer
264.62|5.48| perceptrons, and logistic regression, they don't use
270.14|4.6| sequence information in across the features, they regard the
274.74|4.32| features as independent here. So in that way, they don't have to
279.06|2.44| occur in a certain order. And if the features occur in a certain
281.5|4.72| order, this information is ignored. This is because I mean,
286.22|3.68| you can simply test this by swapping columns, and then
289.9|3.0| training the model on the data set with a small columns, and
292.9|2.16| testing it on a data set with swapped columns, and you will
295.06|4.48| find there is no difference. This can be a problem, though,
299.54|4.28| when you think back of our back of words model. So the back of
303.82|4.48| words model had this vocabulary. And it essentially gets rid of
308.3|3.64| the word order in each training example in the feature vector.
312.22|5.56| So if you think of an example here, where I have written down
317.78|5.1| a just a spontaneous sentence saying the movie, my friend has
322.88|4.3| not seen is good. This is of course different than the movie
327.18|4.64| my friend has seen is not good. So two different meanings. So
332.5|3.84| first meaning is, in the first sentence that the friend has not
336.38|4.6| seen a movie, which is good. And the second one, it has seen the
340.98|4.04| friend has seen the movie, but the movie is not good. So here,
345.02|7.44| we have a good movie. And here we have a not say a bad movie. So
352.46|3.16| two different sentences. But if we would use the back of words
355.62|5.16| model, where we have the text as the word frequency, this would
361.06|4.52| get lost because both both sentences would result in the
365.58|5.36| exactly same feature vector. So in this case, we have this
372.18|2.72| between in the inputs here, and the features, we have this
375.14|4.62| ordering information that it really depends on really depends
379.76|4.98| on which order words occur. So not seen is very different from
385.38|4.32| not good, like the ordering really matters here. So, and
389.74|3.6| recurrent neural networks can help us capture this ordering
393.34|0.64| information.
396.58|3.76| Yeah, and here are some examples of sequence data, for example,
400.58|3.72| text classification, which is something we will be focusing on
404.3|2.8| in this lecture, especially at the end when I show you a
407.1|3.92| pytorch example. So here in the text data set, you can think of
411.06|3.44| each, so the time dimension over the word, so you have texts,
414.5|3.72| let's say t one, t two, like 80s, it will be confusing,
418.22|4.04| because it's t for time, let's say, um, document d one,
422.46|4.16| document d two, and each document is a text. So you have
426.62|4.24| the time dimension over the words. And then you have also
430.86|2.84| had different training examples. So each document would be one
433.7|3.52| training example, for example. And yeah, also something like
437.22|3.28| speech recognition, there you have a sequence of sounds or
440.62|3.2| language translation, which translates from one sequence
443.82|3.96| into another sequence. There's also stock market prediction,
447.78|3.32| which is a common and popular problem. So in stock market
451.1|4.12| prediction, you can think of maybe each, each stock at a data
455.22|3.96| point as a training example. So you have stock one, stock two,
459.18|4.68| and then you have the prices or you have a feature vector, let's
463.86|3.4| say a feature vector could be the price, but it could also be
467.26|3.48| the sentiment or some news information, some some type of
470.74|8.12| feature vector, it's called f1, f2, f3, 123. So you have a
478.86|2.84| feature vector for each time step, right here, the time
481.7|5.04| dimension would be, let's say, on the time of the day or
486.74|7.44| something. Or the date, the day itself, or the month or something
494.18|3.84| like that. So the time dimension would be here, really, like,
498.26|3.48| literally time, whereas in text data, the time dimension would
501.74|3.92| be just the order of the words. So time using time is a bit
505.7|3.52| loose. So we can also just more think of it as a sequence.
510.22|4.36| Another example here would be DNA, or sequence modeling. So
514.58|3.24| instead of just thinking of text and words, you can also think of
517.82|7.8| a DNA sequence. So here, it's by character, for example. All
525.62|3.12| right, so these are just a few examples. Now let's get to the
528.74|4.92| part where we actually talk about how an RNN looks like. So
533.66|5.4| previously, we worked with so called feed forward neural
539.06|6.84| networks. So our, our multilayer perceptrons, or conversion
545.9|3.88| networks, logistic regression, they were all cases of feed
549.82|2.92| forward neural networks. So we had usually an input vector,
553.1|3.92| feature vector x, then some in the multilayer perceptron case,
557.02|4.2| or convolutional case, some hidden layers, and then outputs.
563.06|3.8| So now in the recurrent neural network setup, that's why it's
566.86|6.04| called recurrent, we have this recurrent edge. So what's new
572.9|5.6| here is we have a time step T, and we get a feature vector at a
578.5|4.84| time step T, give it to the hidden state. And then it
583.34|5.56| results in an output at time step T. But in addition to that,
588.94|4.56| instead of for this hidden layer, only receiving the input
593.5|3.84| here, but it additionally is receives, it's also receiving
597.74|4.76| the input from the previous time steps, for example, t minus one
602.5|4.76| and so forth. So it's also receiving previous information
607.26|4.32| from previous time steps. So it's maybe a little bit more
611.58|3.52| clear to show it like this. And this is also how it's usually
615.1|5.52| implemented. It's the unfolded state of this single layer,
620.62|3.04| layer, recurrent neural network I was showing you on the previous
623.66|2.96| slide. So this is again, what I showed you on the previous
626.62|2.68| slide, and we have this recurrent edge, and we can
629.3|5.6| actually unroll this network. So if we have a sequence, let's
634.9|4.76| say consisting of three time steps, then we can roll it like
639.66|6.84| this. So given a time step T, let's focus here, let's focus on
646.5|5.04| this time step T in the center. So it receives the feature vector
651.54|4.72| at time t, which results in the hidden state t and this results
656.26|4.2| in the output. But in addition to that, this time step also
660.54|4.96| receives the input from the previous layer, or not layer,
665.5|3.12| sorry, from the previous time step. So you can see that as
668.62|3.88| this time connection, there are no two inputs, one input is from
672.5|7.16| the sequence input from the x, this is our feature vector here.
680.98|9.88| At time step T, and this is the hidden state of the previous
693.26|7.72| time step, which is t minus one. So here, this allows the network
700.98|4.6| being aware of the order of the sequence, right? And then this,
706.02|3.52| this one here is passed, then in the next step to t plus one,
709.54|4.4| and so forth. So here on the right hand side, so both both
713.98|4.8| they are equivalent. So same network is just a different way
718.78|3.4| of showing the network. This is just showing the compact
722.22|3.8| notation with this recurrent edge. But in practice, usually,
726.26|4.06| we use the unfolded version, the right hand side, it's just a
730.32|2.42| different way of showing it. And that's also how we would
732.74|6.8| implement it in code. So here, this was showing you on the
739.54|4.28| previous slide, a single layer recurrent neural network. But of
743.82|3.52| course, we can also extend this concept to multi layer
747.38|2.4| recurrent neural networks. I will also show you some examples
749.78|5.88| later in code. So here, we have no two hidden layers. So the
755.66|3.8| same concept applies that for each hidden layer, we have this
759.46|5.8| recurrent edge here. So when we unfolded again, you can see this
765.26|4.88| one here is receiving now the input from its previous hidden
770.14|5.52| layer in the same time step. And also the input from the same
776.14|6.16| layer from t minus one. Yeah, and this is the general setup of
782.3|5.24| how a recurrent neural network looks like. Yeah, so just to
787.54|4.76| emphasize again, each hidden unit receives two inputs. So if
792.3|3.0| we focus on this unit, it receives an input from here and
795.3|6.48| from here. Alright, so this is the general setup of how a
801.78|3.2| recurrent neural network looks like. And in the next video, I
804.98|4.0| want to show you also that we can use this architecture for
809.02|4.44| different types of sequence modeling tasks. And then after
813.46|3.12| that video, I will show you how the back propagation algorithm
816.58|1.64| works for this type of model.