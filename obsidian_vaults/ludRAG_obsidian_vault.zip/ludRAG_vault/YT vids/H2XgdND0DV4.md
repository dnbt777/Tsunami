start_time|end_time|text
0.64|3.44| All right, let's start with an overview of a variational auto
4.08|3.4| encoder, so that you get an idea where we are going with this
7.48|3.68| lecture. And we will do that by connecting it to a familiar
11.16|4.56| idea, the regular auto encoder that we already talked about last
15.72|5.84| week. So here is a recap, a regular auto encoder that I
21.56|3.32| showed you last week, that is what we worked with last week,
24.88|5.72| where we had a neural network model consisting of two parts,
30.68|5.48| an encoder, and a decoder. So the encoder receives the input
36.16|4.68| images x, and then it will encode these input images in a
40.88|4.4| latent representation, let's call it z. And then the decoder
45.48|4.06| will reconstruct these images going back to x. So let's call
49.54|4.0| this x prime, because it will not be identical to x. But yeah,
53.54|4.9| our goal is to make x and x prime as similar as possible.
58.88|4.16| And one way is, for instance, using the squared error or mean
63.04|4.4| squared error. So here, I'm writing this as the two
67.44|5.88| difference. So the difference between x, the input, and here
73.36|5.2| how I've written this, it's encoding x, and then decoding x.
78.56|9.04| So this whole thing here resembles x prime. So I'm
87.6|3.0| minimizing the squared difference between those two,
90.8|4.36| both are vectors. So you can reshape these images as vectors,
95.16|4.32| or you can just leave them as images and do the pairwise this
99.52|6.48| difference, and then sum up the squared differences. And if you
106.0|7.08| have multiple examples, so in your batch, then you can also
113.08|6.24| compute the mean squared error, where the one over n is over
119.32|4.08| the number of examples in your mini batch. So this is what we
123.4|7.64| have discussed last week. Now let's focus on the variation out
131.04|3.4| encoder, which is the topic of this lecture. So the variation
134.44|2.8| out encoder is a little bit more complicated, there are, or there
137.24|4.56| is a loss node consisting of two terms, we have this term here,
141.96|3.24| which is still the reconstruction loss. So overall,
145.2|3.48| this is the elbow objective. So if you're familiar with that,
148.68|3.88| the empirical lower bound, which consists of, let's say, a
152.56|3.28| reconstruction loss here, and the KL divergence, you've
155.84|3.0| probably heard about the KL divergence, the Colbeck lie
158.84|3.14| bloody versions in other classes before, it's essentially
161.98|5.88| measuring the difference between two distributions here. And here,
167.86|5.76| we are assuming that this here is from a standard multivariate
173.84|3.84| Gaussian distribution. So it has zero mean, and the variance is
177.68|3.2| one. So this is for univariate Gaussian, but it's of course,
180.88|3.78| for arbitrary on dimensional Gaussian. So you can also think
184.66|3.54| of this as the covariance matrix here, which is an identity
188.2|2.96| matrix, because we don't have any interactions between the
191.16|4.62| terms. Anyways, that's a lot of jargon here, I think we will
195.78|4.46| probably unpack this one by one in the upcoming videos. I think
200.24|2.48| that's a lot of information here. And for this term,
203.04|4.6| usually, so there are two things we can do, we can either use a
207.64|4.12| binary cross entropy, if we assume that the data is like a
211.8|4.32| multivariate Bernoulli, or we can use the mean squared error.
216.84|2.46| So the mean squared error that we also used for the regular
219.3|2.9| autoencoder. And if we have something like image data, where
222.2|2.32| we normalize, let's say the image data to be in the range
224.52|4.72| between zero and one might look like Bernoulli or something like
229.24|2.6| zero and one, right? If you see a zero and one, it might look
231.84|3.3| like something like a Bernoulli. But remember, here, we have a
235.14|3.1| range between zero and one, it's not zero and one, it's zero and
238.24|4.64| one and the values between. So in this way, actually using a
242.88|4.08| mean squared error term for the reconstruction, like we did in
246.96|4.12| the regular autoencoder is way better than using something
251.08|2.72| like cross entropy here. Although it also works to use
253.8|2.44| a cross entropy, but usually, in practice, you would find that
256.24|3.72| the images are a bit blurrier, because it will kind of be biased
259.96|2.96| towards point five, the pixel value point five. But I think I
262.92|3.52| will probably discuss this in a future video. So here, I just
266.44|4.16| gave you a lot of information, we will revisit this information
270.64|4.16| in the upcoming videos. So here, again, the big picture is that
274.8|6.3| we have two terms. One is the KL divergence measuring the
281.1|5.7| difference between this data distribution in the latent space
286.8|2.76| and the standard normal distribution. So the goal is to
289.56|3.52| make this such that it looks like a standard normal
293.08|3.52| distribution. And the other term is still the reconstruction
296.6|5.48| loss. So we still want to create realistic looking images or
302.08|5.8| reconstruct the input images. So two objectives now. Okay, so in
307.88|3.86| the next video, I will then talk about how we sample from a
311.74|3.22| variational autoencoder. And why, let's say why it's
314.96|2.68| interesting to use a variational autoencoder for sampling
317.76|2.6| compared to the regular autoencoder. So what the
320.36|12.8| advantage is essentially of a variational autoencoder.