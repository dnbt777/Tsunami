start_time|end_time|text
1.24|2.96| All right, I have prepared a bunch of files that I wanted to
4.2|4.16| walk through now, explaining the code implementation of CNN and
8.36|3.48| pytorch. So I have a couple of files that I prepared. The first
11.84|5.4| one is Linux five implemented to classify handwritten digits in
17.28|6.48| MNIST. Then I implemented Alex net trained on cipher 10, and
23.76|3.6| another convolutional network trained on cipher 10. And I
27.36|4.72| also have a video on saving and loading models, which I think is
32.8|4.6| relatively important to you in terms of the class project. I
37.4|2.24| explained that before in an earlier lecture, but I think
39.64|3.12| it's a good idea to recap that. But that will be in the next
42.76|2.92| video. So in this first video, let's talk about Linux five
45.68|5.6| trained on MNIST. So just to recap how Linux five looks like,
51.32|4.12| so this is from the slides. So for Linux five, this was
55.44|5.8| trained on a handwritten letter and digit data set. So in our
61.24|3.48| case, we have only digits, but the same concept should apply.
65.04|4.88| So here we have 32 times 32 inputs MNIST is 28 by 28. So we
69.92|4.0| have to make a small adjustment and resize MNIST. And then yeah,
73.92|5.08| what you can see here is it goes from one channel to six channel
79.04|5.6| after the first convolution here. And then this 28 by 28
84.64|4.56| times six feature maps here, they are sub sampled using
89.2|4.0| pooling. And you can see now the size of them is half. So we go
93.2|5.6| from 28 to 28 times 28 to 14 times 14. And then yeah, with
98.8|2.96| the convolution, the number of channels is increased from 16,
101.8|5.88| six to 16. And the image size decreases slightly. And then
107.8|4.96| again, we have a pooling layer, which halves the size of 10 times
112.76|3.76| times 10 to five times five, we keep the number of channels. And
116.52|2.56| then we have these fully connected layers, you can see a
119.08|4.12| pattern here, that usually when we use convolutions, we try to
123.2|4.84| keep the height and width approximately the same here, it
128.04|4.44| shrinks a little bit because we don't use padding. But overall,
132.48|3.3| the size is kind of the same as the input. However, usually with
135.78|6.34| the convolution, we increase the number of channels with sub
142.12|3.2| sampling, what we usually do is we keep the number of channels,
145.92|5.64| and we reduce the height and width by half. Later in next
151.56|3.96| week's lecture, I will also show you that we can actually do both
155.52|6.4| in one step that we can half the dimensions, and also increase
161.92|3.52| the channels just with convolutions, not using pooling.
165.68|5.36| And they're actually a bunch of architectures that are called
171.04|2.84| fully convolutional networks. So fully convolutional networks
173.88|4.24| usually don't use these fully connected layers, and they don't
178.12|3.84| use pooling layers. And I will talk more about that next week.
181.96|6.64| But for now, let's focus on this line at five here. So let's walk
188.6|4.44| through this step by step, the usual watermark, importing some
193.04|4.72| packages, I put some stuff here in the helper function as usual
197.76|4.56| to keep the notebook a bit more organized. Then everything here
202.32|3.96| is same as usual. You may notice this may not work when you run
206.28|3.52| things on the GPU. That is because some algorithms are not
209.8|3.36| deterministic on the GPU. So if you have problems, an error, you
213.16|7.6| can just comment this out. Um, yeah, so I'm first resizing the
220.76|5.48| 28 times 28 mnist images here to 32 times 32. And I'm also
226.24|2.68| normalizing them such that they are the pixels are centered at
228.92|6.44| zero, and are between minus one and one. Um, yeah, that is the
235.36|3.4| same as before. Let's just run this to see that it can load the
238.76|6.24| data properly that works. Okay, so this is our Lynette five
245.04|6.24| network. So I have included a variable here called grayscale,
251.6|3.92| because my implementation, I also tried this on self attend,
255.52|3.08| for instance, in cipher 10 is a color image data set. So we have
258.8|4.44| three channels. However, here, and this only has one channel,
263.24|3.76| but I could toggle between one and three, depending on what the
267.0|2.84| input is. So I gave it this additional parameter. I'm also
269.84|3.44| saving the number of classes, because that's Yeah, that's kind
273.28|2.76| of right, I wouldn't have to save that. But I need this
276.04|3.88| information for the last layer, right? So because the last day
279.92|2.36| is still a fully connected layer, if I go back one more
282.28|3.36| time. So here, this last one, for that, I need the number of
285.64|4.52| classes. Alright, so now step by step, I'm using this sequential
290.16|4.0| API, because it's more convenient. And then just like
294.16|3.24| in the figure I showed you, we have a convolutional layer with
297.4|3.0| the number of input channels, one, and this is the number of
300.4|4.44| output channels, that's six. So we're going from one to six.
305.08|5.36| And we have a kernel size of five. So here, this this thing
310.44|6.88| here is five by five. Then I have a 10 h activation, the
317.32|3.02| pooling layer. So the pooling layer has the kernel size of
320.34|5.74| two. We will later see also that we can actually have larger
326.08|3.48| pooling layers and then use we can, for example, have a three
329.56|3.64| by three pooling layer, and just use a stride of two that would
333.2|6.92| also work. Then we have another convolution layer going from
340.12|6.68| six to 16, kernel size five, 10 h layer. So you can see that's
346.8|5.6| the same pattern essentially as with as with fully connected
352.4|3.12| layer. So we have first, the layer itself, which has the
355.52|2.84| weights, then we have an activation function. And in this
358.36|2.28| case, we have a pooling function. So you can really think
360.64|4.72| of this as the first block. And this is the second block. So if
365.36|5.84| I go back, so one convolution, two convolution, so there are
371.36|4.0| essentially two convolutional layers can actually annotated
375.36|9.8| conf, one, oops, and two. And then this is our feature
385.16|3.68| extractor. That's why I just call it features. I mean, just
388.84|3.48| some, some arbitrary name, but this is essentially our feature
392.32|3.8| extractor. So you can think of all that part here as the
396.12|4.72| feature extractor. And this is our fully connected part, which
400.84|2.64| is essentially a classifier, it's similar to a multi layer
403.48|4.4| perceptron. So here, I have just called it classifier. And then
407.88|4.36| this is like a multi layer perceptron, it receives the
412.28|4.56| input. So I can let's let's show it maybe here. So in the
416.84|5.32| forward method is how we call these layers and everything. So
422.16|3.84| first, I'm calling features. So this will, this features here,
426.0|4.88| this will run everything here, then I'm flattening it, because
431.24|7.96| this will be something times 16 dimensional on 3d tensor, right?
439.26|3.94| So we have height and width times 16 channels. So here, what
443.2|4.8| I'm doing is I'm flattening it. So what is yet touch dot
448.0|5.04| flatten will essentially make this. So let's let's write it
453.04|5.08| down. So here, this is actually n ch w format. So batch size,
458.28|3.92| channels height and width. And this torch dot flatten will
462.2|5.64| combine it into an n times, let's say m, where m is the
468.28|4.68| channels times h height times the width. So we are essentially
472.96|5.6| essentially on flattening it into a vector because yeah, as
478.56|4.24| you know, fully connected layers or linear layers work with vector
482.8|4.72| inputs. Okay, so is there Yeah, this is actually shown here,
487.52|6.1| this this flat thing. Okay. Alright, so fully connected
493.62|4.54| layer, this, this is a little bit tricky to get. So if you
498.16|10.04| don't know what to put here, you can just do maybe print x dot
508.88|4.62| size the first time you run it. And then you can take a look at
513.5|3.82| this number. Actually, this, this should be the number that I
517.32|5.8| mentioned that you that you have to put in here. So here, I
523.12|5.72| are calculated it manually. So it's five times five times 16.
528.88|4.08| So that's if I go back here, this is if you can see it here
532.96|3.32| 16 at five times five, this is where I have this number from.
537.88|4.72| Okay. And then the next dimension will be 120. That's
542.6|3.48| the size of the hidden layer. So this will be this one at 20.
546.36|3.96| Then we go from 120 to 84. This is here this one. And then we
550.32|3.96| go from 84 to the number of classes, which is 10 for MNIST.
554.72|4.84| So here, that's the 84 to 10. And I'm not using these Gaussian
559.56|4.36| connections, by the way. So I think if you use an MSE loss
563.92|4.64| function with Gaussian data, then it should be equivalent to
568.62|3.02| cross entropy. It's some way you can mathematically show that.
572.08|3.24| But we're not doing it here. We are just using regular softmax.
575.32|4.84| So it's the more common ways nowadays, anyways. So this is
580.16|5.08| how, how we define the network module. And then here, I'm
585.24|5.32| initializing it. So setting it to grayscale, 10 classes, putting
590.56|4.2| it onto a GPU, if I have a GPU available. So if I go up again,
595.28|3.32| it will here automatically choose my first GPU. If I have
598.6|3.36| one, I'm currently right now running this on my laptop on a
601.96|5.64| CPU. So, so actually, we just on the CPU. And then this is all
607.6|4.44| the same stuff that we discussed before all the same functions, I
612.08|2.96| don't even think I made any change to those. That's exactly
615.04|3.32| the same that we used in the previous lecture. So I'm using
618.36|3.76| here in SGD optimizer with momentum and learning rate
622.12|6.24| schedule. And then this is just the train model. Oops, the train
628.36|5.4| model function that I imported from my train here, I can, you
633.76|5.56| just open this. So train model, this is just a boilerplate code
639.32|2.96| where we iterate over the epochs and then iterate over the mini
642.28|5.48| batches. We load the data, do the prediction, and have the
647.76|4.56| cross entropy. And then the back propagation. And here we update
652.32|3.64| the model parameters. And then this is just logging to print
655.96|4.72| some results. And then if we have a scheduler, and also, yeah,
660.72|3.16| dates, a scheduler, and then a little bit more logging, and
663.88|5.08| that is essentially it. So let's let's run this then should
668.96|3.36| actually be quite quick, because it's a relatively simple model.
673.04|4.96| So I'm running this on a CPU, so it might take a little bit. But
678.0|10.52| not too bad. Alright, let me be quiet now and let this thing
688.52|20.52| finish.
723.12|2.76| Yeah, you can see it's training. I mean, after the first epoch,
725.88|4.68| it's already 97%. But it's still going up. You can also see it's
730.56|4.92| quite overfitting. It's 99 over 98. I mean, not that much, but
735.56|4.56| a little bit. Yeah, it looks good. So loss goes down, may
740.68|2.8| would make me go down even further if we would train
743.48|3.92| further. But yeah, you can see based on the training
747.4|3.32| validation accuracy, maybe the validation accuracy would even
750.72|2.84| go up a little bit training accuracy might even reach 100. If
753.56|3.12| we would train a little bit longer, but I was impatient. It
756.68|5.28| took already one minute. That's actually not too bad. Alright,
761.96|3.64| so I also prepared a show examples function. And this will
765.76|4.16| show some examples from MNIST. So the first number P is
769.92|4.2| predicted and T is the true label. So you can see it gets
774.12|5.68| all of these, you're correct. So just always useful to double
779.8|4.12| check things whether the model gets them correct or not.
784.28|3.38| Alright, so this is the first video. And in the next video, I
787.66|16.7| will show you the Alex net.