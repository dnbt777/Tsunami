start_time|end_time|text
0.96|3.16| Alright, let me now give you the brief picture overview of the
4.12|4.72| loss function of the variational auto encoder. So overall, it's
8.84|4.0| about minimizing elbow, the evidence lower bound. So if you
12.84|3.48| have not heard about elbow or the evidence lower bound before,
17.0|2.96| don't worry about it too much for this class. So for here, it's
19.96|3.0| not really that important. That would be something for a
22.96|3.28| follow up class. Or yeah, maybe you would encounter this in a
26.24|3.56| class on variational Bayesian methods or something like that.
30.2|6.08| So for here, maybe it's not that important. But overall, we are
36.32|6.84| optimizing or minimizing a loss that consists of minimizing the
43.16|3.84| expected negative likelihood of the data. And then the Colbeck
47.0|3.04| Leibler divergence term, which is the difference essentially
50.04|4.6| between this latent space distribution and standard
54.64|4.36| multivariate Gaussian distribution. So technically,
59.0|4.04| you would be maximizing the log likelihood of the data. But as
63.04|3.4| we discussed before, when we talked about logistic regression
66.44|3.52| a long time ago, maximizing the log likelihood is the same as
70.16|3.04| minimizing the negative log likelihood. So that's why I've
73.2|3.96| written it like this with this negative sign here. Um, yeah,
77.2|4.72| but again, the details are not that important. Like, if you
81.92|2.76| have not encountered this before, don't worry about it
84.72|4.88| too much. The big picture is that this is a reconstruction.
92.72|3.88| Last term, it's essentially the reconstruction between all the
96.6|5.12| difference between input and output distribution here. And
101.72|5.16| the cal divergence is making sure that this one here has to
106.88|4.84| or is essentially standard multivariate Gaussian distribution.
113.6|4.68| Now, if you would look at some implementations of variational
118.28|4.52| auto encoders, what you might find is on that usually for the
122.8|4.96| reconstruction, those people either use the binary cross
127.76|7.16| entropy, or the mean squared error, both work in practice.
134.92|4.92| Personally, I would say it makes more sense to use the mean
139.84|7.48| squared error. Because some people use the BCE, when they
148.24|4.12| normalized images to zero, one range, and they also have the
152.36|5.44| zero one range here, the pixels, originally, image pixels are
157.8|4.72| between two, zero and 255. And you can normalize them in zero,
162.52|3.36| one range. In fact, this is done automatically in pytorch, when
165.88|4.4| we call the two tensor method in the data transform. So you will
170.28|5.0| see that in the code example. And then you can have here,
176.28|3.76| sigmoid activation, logistic sigmoid, and then you will also
180.08|2.6| automatically ensure that the outputs are in a zero one range.
183.24|5.88| And it might be tempting then to use a binary cross entropy. But
189.12|3.56| but keep in mind, this is not a Bernoulli distribution. I mean,
192.68|4.12| this is not zero or one, the value of the pixel, it's
196.84|4.72| between zero and one. And frankly, I don't know why some
201.56|3.6| people would use BCE for that I would use a BCE if that would be
205.16|3.2| a multivariate Bernoulli distribution with five values
208.36|5.84| like zeros and ones for the input, but we have various
214.2|2.96| between zero and one. So to me, it makes more sense to use the
217.16|4.64| MSC. And also in practice, when you do some comparisons, you
221.8|3.04| will find probably so it's at least what I found that if you
224.84|3.92| use the BCE, the images would look a little blurrier could be
228.76|5.0| because it's kind of forcing the pixels to be more in the center
235.6|6.36| of the distribution. In any case, so yeah, what I also want
241.96|3.52| to show you, let me go to the next part, maybe I wanted to
245.48|3.8| show you that the cross entropy is not symmetric. So this is
249.28|3.8| also one issue why I think it's probably not a good idea to use
253.08|6.08| a binary cross entropy is the reconstruction loss, because the
259.16|4.88| loss is different depending on the pixel values. What I mean by
264.04|2.6| that, if what I'm showing you on the left hand side is a plot,
266.84|4.36| we are plotted the binary cross entropy loss for values of the
271.2|7.68| true and the predicted label. So here, zero is probably a bad
278.88|4.8| example. But let's say point two. Here, what I mean is, when
283.68|3.16| we consider the cross entropy, that the true value is point two.
288.08|3.64| And the predicted value is point two. So that's how we compute
292.96|3.44| should be minus cross entropy. Oh, yeah, for reference, I have
296.4|3.32| it also here. So recall the binary cross entropy from the
299.72|6.52| logistic regression class, we have a probability here, the
306.24|6.68| log probability here. Usually in the logistic regression context,
313.88|5.28| this was either either one or zero. Now we have values between
319.16|4.76| zero and one. So if I have a pixel in my input image of point
323.92|7.08| two, and a predictor pixel of point two, I would get a loss. It's
331.0|5.92| around point five here. Now, here, what I have is, I have an
336.92|6.42| input pixel of point four, and a predicted pixel value of point
343.34|5.9| four as well. I can see is the loss is higher, it's around, I
349.24|4.98| don't know, 6.5, something like that. So you can see, even
354.22|4.34| though I reconstruct the right pixel point four is the
358.56|5.6| reconstruction, and point four is the original label, I get a
364.16|3.44| higher loss now compared to as if it was point two. So it's not
367.6|3.44| symmetric, I get different losses, depending on what my
371.04|4.56| pixel values are, which is, which doesn't, which doesn't
375.6|3.72| really make sense. So if you have a mean squared error loss,
380.96|5.4| here, this is, let's say my zero here, we would have zero
386.36|4.2| everywhere. Because the MSE, there's no difference between
390.56|4.24| the point four and the point four. So the MSE would be point
394.8|8.96| four, minus point four, squared, which would be zero, that makes
403.76|3.52| more sense to me, at least. Well, here's another example.
407.56|3.84| Consider we have the true pixel value point eight. And the
411.4|3.64| reconstructed pixel value is point seven. So we are off by
415.08|5.92| point one, we would get a loss of point two eight. If I have
421.0|4.48| no point nine years for reconstruction, still, I'm off
425.48|6.84| by only point one. Now I get a point or eight. Right. So for
432.32|4.08| some reason, it penalizes this point seven more than this point
436.4|4.56| nine. Because it's not symmetric, same as if I have a
440.96|4.16| minus point two, here as a true pixel, and I put it on point one
445.12|5.96| here, point three, we'll find these are different values. Yeah,
451.08|3.76| this is why I would suggest for the variation autoencoder to if
454.84|4.88| you have input pixels between zero and one, or meet my between
459.72|4.24| minus one and one doesn't matter. If you have input
463.96|4.08| pixels on a continuous range, I would suggest using the MSE
468.08|3.04| instead of the binary cross entropy for the reconstruction
471.12|6.36| term. Alright, so this was now the first term. So if I go back
477.48|3.88| one more slide, so this was the first term that we discussed the
481.36|3.52| reconstruction loss. So I suggest using the mean squared
484.88|5.32| error for that. So the mean mean here is over the examples in the
490.2|3.36| batch. For if you only have one training example, you can think
493.56|5.48| of it as the sum squared error between all the pixels. So it's
499.04|3.92| essentially a Euclidean distance. So you would, for each
502.96|4.44| pair of pixels, compare the difference, square it, and then
507.4|3.24| you sum them all up, and you take the square root. So you
510.64|2.88| have the original dimension back. And then you can average
513.52|4.0| that over the batch. And that would be the new mean squared
517.52|3.48| error. And I will show you, of course, in the code example, how
521.0|2.04| that looks like, I think that will also make things more
523.04|6.24| clear. The second term is the KL divergence term. So this is
529.28|3.52| measuring the difference between the distribution here in the
532.8|4.6| latent space, this part. So we have our mean vector and our
537.76|3.72| block var vector. So should I mean, I'm only showing you this
541.48|2.28| one vector, but there should be technically two vectors, the
543.84|3.12| mean vector and the log bar vector here, I'm just writing as
546.96|5.04| a standard deviation. So we are minimizing the difference
552.0|4.56| between this distribution of the latent space and a standard
556.56|4.36| normal distribution. So we use the KL divergence term for that.
561.92|4.96| And it can be written as follows as shown here, I'm not showing
566.88|3.52| you here the derivation, I'm just showing you how you can
570.4|4.68| write that. I have two slides later, I have the derivation
575.08|3.52| here. But I don't want to go into all through this in detail,
578.6|3.0| if you're interested, I actually got this from this link here, I
581.6|3.44| was not writing this myself. But if you're interested in
585.04|4.04| studying this, you can find it here. So you derive the KL loss
589.48|5.76| for the very short encoder. Going back to this one here,
595.52|3.8| what's more interesting is to take a quick look at this. So
599.32|6.24| you can see, we have this one plus here. This is our log bar
605.6|5.92| this is our from the log bar trick. And yeah, you can see
611.56|7.56| this would be minimized if we have one minus the variance one
619.12|4.96| if we have a variance of one. So we would minimize this if the
624.08|8.04| variance is actually one. So log of one should be also zero then
632.12|7.08| right. And if this is zero, so if we have one plus zero minus
639.2|8.32| zero, minus, minus one, gives us zero, this is when our KL
647.52|10.28| divergence term is minimized. So what we want here is mean vector
658.24|3.36| to be close to zero, and the variance to be close to zero,
662.72|3.88| close to one, which happens if this log bar term is close to
666.6|5.96| zero. So that's essentially what the KL divergence term forces
672.56|8.72| these, this, and this vector to be. And then if this is true, I
681.28|3.04| mean, if our mean vector is zero, and our variance vector
684.32|6.76| is one, so if this is one, and this is zero, then what we have
692.16|5.0| is that it's our distribution will be standard normal
697.16|4.08| distribution. That is our goal for this latent representation.
701.24|2.76| All right, so this is essentially, in a nutshell, the
704.0|3.12| variational auto encoder loss function. Again, if you're
707.12|3.28| interested, you can take a look at the last derivation. And now
710.4|2.72| in the next video, I will finally show you how this all
713.12|3.28| comes together in a code example where we have the sampling
716.4|3.2| aspect, the log bar trick, and the loss function, everything
719.6|3.44| together in one code example, where I will show you that we
723.04|4.08| can train this auto encoder to generate handwritten digits. But
727.12|2.84| since handwritten digits are by now, I think a little bit
729.96|3.6| boring, we will also use a second data set and apply this
733.56|26.6| concept to face images.