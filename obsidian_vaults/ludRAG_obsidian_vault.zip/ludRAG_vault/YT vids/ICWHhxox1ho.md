start_time|end_time|text
0.539|2.88|Unknown: Yes, so this video is
not going to be terribly
3.419|3.72|important. It's just a little
bit of nitpicking, in case, one
7.139|3.87|of you has been wondering, maybe
one or more, have been taking
11.039|2.76|our signal processing class in
previous semesters. And we're
13.799|4.08|wondering, why do we call the
procedure convolution and not
17.939|3.3|cross correlation? So in fact,
actually, convolution networks
21.269|3.51|are performing something called
a cross correlation. So what's
24.779|2.52|the difference between
convolution and cross
27.299|4.56|correlation? So yeah, cross
correlation, or convolution is
31.919|4.02|another one of these jargon
terms. So in deep learning, we
35.939|2.61|sometimes use words from other
fields that have a different
38.549|3.78|meaning. And the convolution
would be one of those. So the
42.329|3.09|convolution and deep learning is
actually what is more commonly
45.419|4.05|known as cross correlation. So
the cross correlation is
49.469|3.87|essentially the sliding of the
dot product over the image. So
53.339|6.87|when we have this one here, so
this region and we multiply the
60.239|3.36|pixels in that region with the
weight the filter, right, so
63.599|2.88|this is essentially a dot
product, right? So we brought it
66.479|10.47|as as follows, right? When we do
this calculation, what now so
76.949|4.17|when we write it down more
concretely, so we can write this
81.119|3.39|procedure down as a cross
correlation. So in,
90.859|4.44|sums. So we could actually, so
the dot product is if we would
95.299|3.78|actually reshape that into two
vectors, right. So if we have
99.109|6.06|this one, let's write it like
this. And let's say my first
105.259|7.77|rose green. Second rows blue,
and my red, last one is red.
113.269|3.99|This is for let's say, the
weight matrix, W, and I have the
117.259|8.4|same one for the inputs. So
let's do yellow, maybe purple,
126.409|7.08|and lick here. So in order to do
the dot product, I could just
133.489|8.73|reshape them as a vector like
this, right? Then the other one
147.919|3.48|person and maybe taking the
transpose, and then compute on
151.819|3.18|the dot product between the two.
But I could also, of course,
154.999|2.64|instead of doing it like this, I
could do it the other way
157.639|6.9|around, right, I could do it, I
could have the vector like this,
165.559|5.22|just vice versa. And then if I
multiply this vector with the
170.779|13.47|same x, it gives me a different
result, right? Awesome. Like
184.249|3.6|this. So this one and this one,
they will give me different
187.849|4.26|results. So that is mainly the
difference between cross
192.109|3.66|correlation and convolution, the
way we, we do the multiplication
195.769|4.23|in which order. So I'm here,
this is like the way we do the
199.999|2.73|cross correlation, it's maybe
hard to stare at this formula.
202.729|5.01|So let me illustrate how this
works. So essentially, think of
207.889|4.32|the index zero as the one in
their center. So if this is
212.209|5.7|your, let's say, your weight
matrix, and you multiply each
217.909|5.64|one with a corresponding value
in the image, so how you do that
223.579|5.43|is, you consider index is the
center point and then the
229.009|3.33|negative indices, so the one
minus one would be the left,
233.239|3.51|upper left corner, and one one
would be the lower right corner,
237.199|5.7|and then you multiply this
weight with the first. So
244.909|5.88|say, we have our say this is W,
and this is x here, where
252.499|8.1|this whole thing is W, so we
multiply this one with this one,
261.859|3.57|this one with this one, this one
with this one, so these indices
265.759|4.71|correspond to the other position
in the input essentially. So
270.469|2.49|that's how we do the cross
correlation. And this is
272.959|3.87|essentially how we did that in
the previous videos. But you can
276.829|2.97|also do it the other way around.
So this is known as convolution.
280.219|2.91|Notice the only difference is
that I'm flipping here, some
283.129|3.27|signs. But again, it's probably
hard to stare at this equation
286.579|3.27|or formula. So it's very easy to
see it here in this image. So
289.849|6.66|again, this is our w here, and
then we multiply it with the
296.509|6.66|values and x. So an x, we have
still the same on the same
304.729|11.61|order. But now, so let's say
1236789. But now we multiply
316.459|4.29|this one with a first position,
and then this one with a second
320.749|4.2|one, and so forth. So really the
differences, you can see that
324.949|6.0|it's inverted. So here, in cross
correlation, we go like this.
334.159|5.85|And in convolution, we would go
like this. That's the main
340.009|4.8|difference. If you don't believe
me, I just also have an example
344.809|4.26|here, just using code to just in
a practical way, show you that
349.069|3.75|this is indeed the case. So
here, to demonstrate this, I'm
352.819|4.44|initializing a torch tensor,
just some arbitrary values. And
357.259|3.33|then I'm initializing the
convolution, I'm setting the
360.619|2.46|bias to zero because that's not
variable at the bias here, it's
363.079|4.41|just distracting. Here is the
weight matrix, corresponding to
367.489|2.31|the convolution, the three by
three, we have a three by three
369.799|6.57|kernel. And when I then apply
this, so first of all, I have to
376.399|6.15|um, what I'm doing here is I'm
converting it to NumPy. So I can
382.549|4.47|use the cross correlation
function and the conversion
387.019|3.81|functions implemented in Sai pi,
because it expects NumPy arrays.
390.919|4.08|So yeah, I'm just creating a
NumPy placeholder that I'm going
394.999|7.35|to use. And you can see, this is
just yellow pytorch. Wait in
402.559|4.74|sight conversional operator. And
here, this is the NumPy version,
407.689|3.15|it's exactly the same values,
it's just a little bit more
410.839|3.42|precision, because I think this
is 30 bit precision, and this is
414.259|4.23|64 bit precision. But you can
see, the values are exactly the
418.489|7.05|same. Now when I call this conf
pytorch, the conf pytorch.
425.539|4.14|Again, this is my conf to the
operation, it's a three by three
429.679|3.6|kernel apply to a three by three
input. So what I will get is a
433.279|3.6|single value, the single value
from applying pytorch.
437.419|8.16|convolution is minus 1.1, or to
seven. So what is this, I'm just
445.579|4.29|reshaping it because usually in
a neural network, what we have
449.869|2.7|is, we have the number of
batches, and the number of
452.569|3.96|channels here doesn't matter, we
are just looking at a matrix. So
456.529|2.88|I'm setting them to one, because
otherwise this function will
459.409|5.43|complain. In any case, the the
value I get is minus 1.1, or
464.839|4.05|two, seven. Now, if I use the
cross correlation function here
468.889|4.41|from Sai pi, you can see I get
exactly the same value, of
473.299|3.36|course, okay, we have 64 bit
precision here. So there are a
476.659|3.99|few more digits. But you can see
overall, it's also minus 1.1, or
480.649|5.25|two. So it's exactly the same
value. So a convolution and
485.899|4.62|pytorch is the same as the cross
correlation and Sai pi. And vice
490.519|4.38|versa. So this is the same as
above, if we look at the real
494.899|2.91|convolution, if we use the
convolution implemented in Sai
497.809|6.54|pi, you can see what we would
get is minus or point two, six.
505.579|4.29|And if I want to get that result
in pytorch, what I would have to
509.869|4.95|do is I have to either invert or
not invert, but rearrange the
514.819|3.15|weights are the input, it
doesn't really matter. So here
517.999|6.3|you see I'm rearranging it here
I have the 3.3. So I'm kind of
524.599|3.12|creating the matrix backwards,
you can see 3.3 so you know, the
527.719|3.9|top 3.2 in the 300 year, so I'm
just putting in a different
531.619|2.28|order. And then I also get the
same result as with as
533.899|3.45|conversion. So, in fact, the
convolution and pytorch as a
537.349|1.14|cross correlation,
538.849|2.49|so why does it even matter? I
mean, I was just highlighting
541.339|2.52|the difference between the two
operations. Yeah, in practice,
543.859|3.93|it does not really matter, at
least not in deep learning. So
548.779|3.72|maybe in traditional or in other
fields of computer vision and
552.499|4.17|signal processing, it's actually
useful to have this associative
556.669|3.75|property of the real
convolution. But in deep
560.419|3.18|learning, to be honest, that
doesn't really matter. And I
563.599|2.79|think cross correlation is
easier to implement, especially
566.389|2.64|for the backward pass, but we
don't worry about the backward
569.029|2.76|pass. I will show you will
explain a little bit about the
571.789|2.67|back propagation in the next
video, but that is usually
574.459|3.45|automatically handled in
pytorch. It's maybe like small
577.939|5.52|efficiency reason Yeah, but then
when we are if we implement
583.459|3.63|cross correlation for these
networks, why do we call them
587.329|3.75|convolution networks? Why don't
we call them cross correlational
591.079|3.27|networks? Yeah, my theory is
just that cross correlational
594.349|2.82|network sounds a little bit
weird and conversional network
597.169|4.02|sounds slightly cooler. So
that's maybe also one aspect
601.189|3.33|about the whole thing. Anyways,
so this video was not really
604.519|2.01|important. I was just
highlighting the difference in
606.529|3.06|case someone was wondering. In
the next minute, I want to
609.589|3.84|briefly go over CNN and back
propagation, but we won't go
613.429|2.64|into any mathematical details.
So don't be afraid.