start_time|end_time|text
0.4|3.92| All right, let's now get concrete and talk about the VGG
4.32|5.24| 16 architecture. So this is a very simple, straightforward
9.6|4.24| architecture, you can think of it as similar to the Alex net
13.84|4.3| we talked about last lecture, except that we have no more
18.14|3.88| layers, it's essentially a network with 16 layers. Just
22.02|5.1| for reference, given the figure that I showed you last video, we
27.12|3.48| have the VGG 16 located here. And you can see it's relatively
30.6|3.28| large, it's actually the second largest network in this figure
33.88|4.4| here, it's around, I would say, 125 million parameters, the
38.28|3.52| bigger network is VGG 19, which is a variant of that with 19
41.8|3.08| layers, but you can see, adding these three more layers doesn't
44.88|3.24| really change the performance. So we are focusing here on the
48.36|5.1| 16 version. So in this video, I will mainly just show you how
53.46|2.94| the architecture looks like. And then in the next video, I will
56.4|3.56| make a new video showing you a code implementation of that. So
59.96|3.24| here, just the overview. And this is from the paper. So you
63.2|3.76| can find more information about this network architecture and
66.96|2.96| the paper called very deep convolutional networks for
69.92|4.44| large scale image recognition from 2014. It's already seven
74.36|3.64| years old. But yeah, again, it's a simple architecture, I think
78.0|4.06| it's something easy to implement and easy to toy around with. So
82.06|3.58| not a bad thing to learn about. So an advantage, like I said, is
85.64|2.94| that it's relatively straightforward, which makes the
88.58|3.9| coding very simple, as you will see in the next video. So
92.48|2.92| essentially, it's based on just using three by three
95.4|5.4| convolutions. So you can see here, all of them are three by
100.8|5.72| three. And that way, it's also very simple. The stride is one
106.52|3.76| for the convolutions, and they are using the same convolution.
110.28|3.12| So we have the same convolution with a padding such that the
113.4|4.84| input size matches the output size after each convolution. And
118.24|4.4| they are using two by two max pooling then to reduce the size.
123.6|2.68| This is not shown here, I will show you the max pooling in the
126.28|5.68| next slide. One thing to notice though here, or one, one aspect
131.96|3.8| of it is it's very large in the number of parameters and thus
135.76|4.68| also very slow. So if I go back, you can see it's pretty large
140.44|3.2| architecture. So just looking at it, if it only has 16 layers,
143.64|3.6| why is it so large? I mean, later, we will see architecture
147.24|3.92| called resonant 34. In the next video, which is much smaller,
151.2|2.96| smaller, even though it has 34 layers. So what makes this
154.36|3.4| architecture so large? So essentially, it's if you look at
157.76|4.4| it, it's the number of channels also. So you I mean, you can
162.16|2.96| have, of course, more channels than that. But if you just
165.12|6.24| count, I mean, let's just take one of those. This one, it has
171.44|6.96| 512 input channels, and 512 output channels, right? If you
178.4|4.88| have a three by three convolution, then 512 inputs.
183.92|4.32| And then we have 512. So this is one kernel, right? And we have
188.28|3.68| 512 kernels, right? And then we also have the bias. I mean, the
191.96|3.88| bias doesn't really matter. But it's another on 512 on top of
195.84|3.12| it. But this part, I mean, it's a really large number, right?
198.96|3.44| And then we have it multiple times. And yeah, this adds up
202.6|7.12| or here, fully connected layers, we have 4096 times 4096, in
209.72|2.88| terms of the number of weights for each of them, right? And
212.6|4.2| then also on top of it, of course, for 96 bias units, but
217.04|3.48| these are really large. So if you mean these add up, right, so
220.52|5.84| if you have multiple of these, um, yeah, so this is just
226.4|2.68| referring to the number of parameters. So here's maybe a
229.08|4.72| nicer visualization of that architecture from this website
233.8|3.84| here. And yeah, you can see visually how it looks like it's
238.52|3.8| the basic concept behind conclusions to make or to
242.32|4.64| squeeze out these features. Usually, there was just a brief
246.96|3.2| moment. So there was a question on Piazza, where someone asked
250.16|3.84| about that. So like the general trend or some guidelines for
254.0|3.92| conclusions, and that is exactly it here. So we start with a
257.92|4.32| large height and weight, sorry, height and width. And then we
262.24|5.6| make the height and width smaller, but we add channels. So
267.84|3.4| each channel, I mean, that is at least what we hope it will
271.24|3.92| happen, each channel will learn different type of feature
275.16|2.8| information, because each channel is essentially created
277.96|4.76| by a different kernel, right. So usually, so we have the input
282.72|4.52| image here, it's a 224 times 224 image with three color
287.24|3.92| channels. After the first convolution, we have 64 color
291.16|5.06| channels, we use the same convolution that we talked about
296.22|4.9| in a previous video to maintain the size. And then here in red,
302.2|4.0| these are the max pooling layers, the two by two max
306.2|4.96| pooling, which will reduce the size by half. And then we have
312.52|3.24| yet another round of squeezing and so forth. And you can see,
316.16|5.88| we are increasing the number of channels. So the width increases,
322.2|3.92| whereas the height, I mean, the width in terms of the number of
326.12|4.76| channels increases, and here the height and width of the feature
330.88|2.72| map decrease. So we are squeezing, you can think of it
333.6|4.16| as squeezing out the information here. Yeah, and then here, in
337.76|4.04| the end, we have the fully connected parts, which we can
341.8|2.56| actually also represent as convolutions, which I will show
344.36|5.04| you later. This is why it's actually shown like this. So we
349.4|2.44| can actually, I mean, doesn't really matter whether we
351.84|3.2| implemented as fully connected layer or convolution, as I will
355.04|3.24| show you in a later video, it's kind of it's equivalent. Okay,
358.28|3.44| so this is how the architecture looks like, on a conceptual
361.72|3.0| level. Now let me take you to the code example in the next
364.72|27.96| video.