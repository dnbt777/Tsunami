start_time|end_time|text
5.08|5.0|today for our talk we have Professor
7.2|5.08|Jake Williams from Drexel University he
10.08|3.96|is an associate uh professor at
12.28|4.04|information science at Drexel
14.04|5.36|University's College of computing and
16.32|5.4|informatics in Philadelphia Pennsylvania
19.4|4.199|Dr Williams has a background in physics
21.72|3.92|and math with degrees from the
23.599|4.44|University of Vermont and his research
25.64|5.559|leverages a quantitative Linguistics
28.039|5.281|perspective the amp uh applies math and
31.199|5.161|statistical methodologies to analyze and
33.32|5.2|improve linguistic Learning Systems um
36.36|4.32|following a one-year postto appointment
38.52|4.76|at the University of Berkeley uh
40.68|6.039|studying large language large scale
43.28|5.759|machine learning in 2015 Dr Williams
46.719|5.041|became a data science faculty at Drexel
49.039|5.2|where he drove the foundation of a dsms
51.76|5.76|program and develops and instruct uh
54.239|4.96|data science coursework including non uh
57.52|2.92|including natural language processing
59.199|3.801|with deep learning
60.44|4.88|um so uh welcome and thank you for
63.0|4.36|coming today for your talk and you could
65.32|4.159|do a quick introduction of yourself um
67.36|5.04|before you great thanks so much I got
69.479|5.121|the mic here um nice to see you all here
72.4|5.44|thanks for coming out and also for
74.6|6.64|showing up online it's a pleasure to be
77.84|5.84|here um as uh was mentioned my name is
81.24|4.48|Jake and my background is in math and
83.68|4.0|physics so the perspective that I'm
85.72|3.56|coming from towards this work might be a
87.68|3.96|little bit different than the standard
89.28|4.44|and that'll be a theme throughout the
91.64|6.519|discussion um the purpose of this
93.72|7.24|discussion is to go through a relatively
98.159|6.441|long uh term development a project that
100.96|4.759|I've been working on um and uh as
104.6|3.76|mentioned my background is in
105.719|4.76|quanitative linguistics which means my
108.36|6.6|uh history of focus on language has
110.479|7.881|primarily been to uh develop uh
114.96|5.24|General uh theories and descriptions of
118.36|4.32|phenomena That You observe with regards
120.2|5.959|to linguistic units whatever those might
122.68|7.88|be um it's a statistical approach uh
126.159|8.121|based on theories of language generation
130.56|7.959|that are statistical in basis and over
134.28|7.4|the course of my time as a researcher
138.519|4.881|I've um explored and ventured into
141.68|4.16|language modeling itself and ultimately
143.4|5.6|into neural networks as they approach
145.84|4.92|language modeling themselves and that's
149.0|6.12|what brought me here
150.76|5.759|um through quite a bit of other work so
155.12|2.92|um if you look into my profile you'll
156.519|3.281|see a lot of different subjects in
158.04|2.96|either applied NLP like I said
159.8|3.799|quantitative
161.0|6.4|Linguistics um and neural networks is a
163.599|5.0|natural transition for me into um
167.4|3.759|inferential
168.599|6.521|work so let's get
171.159|5.44|started so um well this is how we'll
175.12|4.0|start the conversation today it's not
176.599|6.201|exactly how we got here in my lab um we
179.12|6.759|came at this this subject from a
182.8|6.32|different approach trying to think about
185.879|6.321|um layer initializations in neural
189.12|7.199|networks and um this subject that we're
192.2|6.0|discussing as a front for this talk uh
196.319|3.321|is specifically focused on Transformer
198.2|4.16|architecture components the self-
199.64|4.92|attention component that's uh pivotal to
202.36|5.519|the success of the Transformer
204.56|4.8|architecture and uh it focuses on the
207.879|3.56|fact that self attention requires a
209.36|4.439|Quadra comparison of vectors in order to
211.439|4.8|produce the feature weights of those
213.799|5.52|vectors needed to model longrange
216.239|4.441|dependencies in text commonly parameters
219.319|4.041|for self attention are based on a
220.68|4.8|transformation matrix two usually
223.36|4.159|queries and
225.48|4.039|keys that are responsible for
227.519|4.44|dimensionalizing input vectors and I
229.519|4.121|describe it this way because generally
231.959|3.2|speaking when you're at the point of a
233.64|4.08|self attention layer you already have
235.159|5.0|low dimensional vectors but the
237.72|4.48|parameters in a standard self tension
240.159|4.121|layer are changing the dimensionalities
242.2|4.679|and the structure of that dimensional
244.28|5.159|space they are like an embedding layer
246.879|5.44|which is factorizing the embedding
249.439|4.561|Dimensions this redens is the primary
252.319|4.76|means by which self attention creates
254.0|6.079|feature weights it really just computes
257.079|5.68|similarity in that shared
260.079|4.521|space large and similar inner products
262.759|3.201|really just result in strongly weighted
264.6|3.64|features so it's up to that
265.96|3.76|dimensionalization to produce good
268.24|4.16|similarities for whatever purpose
269.72|5.039|purpose your prediction
272.4|4.92|requires however an alternative strategy
274.759|4.0|for future weights might ask given a
277.32|3.12|basis so in other words you're stuck
278.759|3.761|with your low dimensional
280.44|4.72|vectors what is the optimal way to
282.52|5.0|convert those comparisons of the vectors
285.16|4.64|you're looking at by a matrix
287.52|4.959|transformation to modify the vector
289.8|5.2|similarities that you are stuck
292.479|4.44|with that correspond to the best weights
295.0|4.36|for features in other words treat this
296.919|4.641|as a feed forward layer to produce self
299.36|4.36|atten weights as opposed to try and
301.56|3.76|transform to some basis that produces
303.72|4.28|good future
305.32|4.159|weights the use of this modified self
308.0|5.12|attention mechanism will be part and
309.479|3.641|partiel the substance of this
314.84|4.079|talk it's worth noting that this
317.36|2.839|alternative mechanism is entirely
318.919|2.601|compatible with the traditional
320.199|5.681|dimensionalizing version of self
321.52|7.08|attention in other words you could still
325.88|4.759|change the dimension and compute
328.6|4.599|similarities and then convert that with
330.639|4.441|a second feedforward layer to produce
333.199|4.921|optimal feature weights this is not
335.08|4.48|exclusive in any way this is exploring
338.12|3.6|how useful that
339.56|3.32|alternative prediction of future weights
341.72|3.319|can
342.88|5.319|function however we'll avoid the
345.039|4.241|standard mechanism for two reasons first
348.199|3.921|we have no
349.28|5.639|solution to the standard parameters for
352.12|4.4|self attention as an initialization and
354.919|2.921|this will be discussed at length in
356.52|3.64|slides to
357.84|4.079|come likewise it would
360.16|3.2|create an additional model complexity
361.919|2.921|that would model the effects of the
363.36|4.239|modified form of self attention that we
364.84|5.479|wish to study so having that
367.599|4.681|dimensionalization as a way to produce
370.319|3.6|good feature weights would confuse
372.28|3.8|whether or not the feed
373.919|4.921|forward computation of feature weights
376.08|3.92|is functioning well there's a catch to
378.84|4.32|this however which is that these
380.0|5.919|features these vectors that we use for
383.16|5.36|such a self attention layer better be
385.919|5.161|good in other words their comparisons
388.52|4.48|must be consistent and meaningful in the
391.08|4.559|first
393.0|4.28|place so to get it out of the way here's
395.639|4.881|an architectural diagram for the
397.28|6.16|relatively simple near shallow
400.52|4.48|architecture pattern that we're using it
403.44|3.199|doesn't seem like there are many neurons
405.0|3.639|in a network of this type and that's
406.639|4.641|because all of the activations are soft
408.639|5.361|Max which means despite the fact that
411.28|5.039|the U Matrix for example is an entire
414.0|4.199|layer it's really just going through a
416.319|3.72|single prediction nonlinearity the
418.199|3.081|softmax function
420.039|2.84|so you can think about this is
421.28|3.96|essentially a three- layer Network that
422.879|3.481|might be creating an encoder decoder
425.24|3.359|kind of
426.36|4.119|design likewise the difference in
428.599|5.32|presentation here over self attention
430.479|8.681|which is parameterized by the Matrix W
433.919|7.801|here is intending to show how
439.16|6.479|a whether you consider it the query or
441.72|6.56|the key um one vector is the pivot for
445.639|4.721|the comparison that will produce the
448.28|5.72|feature weights which is then fed
450.36|5.519|forward in this model through W this is
454.0|4.44|the case for standard self attention too
455.879|5.681|in other words you can reduce it to a by
458.44|7.199|prediction diagram in this way where a
461.56|6.8|gray Vector such as is depicted here is
465.639|4.641|that pivot the attention distribution
468.36|4.6|coming out of the W Matrix and the
470.28|5.52|softmax function is indicated by the
472.96|6.0|vertical Red Bar there which weights the
475.8|4.88|block of vectors in Black that includes
478.96|3.679|the pivot Vector in
480.68|3.76|Gray which has then passed through a
482.639|3.721|feed forward layer often called the
484.44|3.28|values of a standard self attention
486.36|6.399|Matrix
487.72|6.56|U we then since we use you as a way to
492.759|3.84|reduce the dimensionality of the
494.28|4.84|prediction that we're trying to make we
496.599|6.361|then feed that forward through another
499.12|6.56|layer and then to output and that's
502.96|4.72|essentially the relative shallow that
505.68|4.079|we're talking about here W is a self
507.68|4.44|attention Matrix
509.759|5.561|which means there's really only two
512.12|4.88|layers in effect here and the activation
515.32|3.599|functions are strange and you might
517.0|3.279|wonder for example why we're using a
518.919|3.8|different activation function the
520.279|4.321|softmax instead of any of the
522.719|4.161|dimensionally independent activation
524.6|5.64|functions like a legistic function or
526.88|5.28|anything else and that's because we have
530.24|3.68|additional insight into the softmax
532.16|5.4|function and the parameters that it
533.92|6.12|optimizes which is very
537.56|5.279|useful so let's talk talk about those
540.04|5.4|vectors first though before we get to
542.839|2.601|layer
546.32|4.28|initialization optimizing the keys and
548.32|5.079|queries of standard self attention Bears
550.6|5.799|substantial similarity to token and word
553.399|5.521|embedding this is because the key and
556.399|5.041|query matrices have a common Dimension
558.92|4.359|that they project to much like you'd see
561.44|4.04|with the factorization of an embedding
563.279|5.761|layer on its own think word Toc
565.48|3.56|something like that
569.48|5.32|these normally there might be multiple
571.92|4.88|self attention heads and because of the
574.8|3.92|indeterminacy in creating a different
576.8|5.36|dimensional space in other words there
578.72|4.64|are multiple equivalent reshufflings of
582.16|4.72|those different dimensions which will
583.36|5.96|produce the same output that
586.88|4.72|indeterminacy is something that we
589.32|3.68|hypothesize has bearing on what is now
591.6|5.0|referred to as the lottery ticket
593.0|5.399|hypothesis in other words that multiple
596.6|3.84|or this is the way that I would state it
598.399|3.601|but um that multiple different
600.44|3.519|embeddings which produce different
602.0|3.959|Vector spaces can be leveraged in
603.959|4.201|parallel to create further robustness
605.959|6.12|for the model or in the way that it's
608.16|6.28|implemented that if a random
612.079|4.121|initialization doesn't do that well you
614.44|3.68|can eliminate it from the network and
616.2|4.36|that subnetwork will do just as well
618.12|5.68|even after it's totally
620.56|5.36|trained in other words having multiple
623.8|3.44|clones self attention heads which have
625.92|3.64|no difference in the outputs that
627.24|4.96|they're trying to predict is that at the
629.56|4.6|root of the lottery ticket hypothesis
632.2|4.24|and ultimately that invocation of the
634.16|4.08|lottery ticket hypothesis is really a
636.44|3.32|justification for eliminating parameters
638.24|5.159|whose substantial costs of training are
639.76|4.8|essentially wasted as a result of random
643.399|3.56|parameter
644.56|4.839|initialization you might ask questions
646.959|6.801|like well what is a good initialization
649.399|4.361|what is a good set of word embeddings to
654.76|4.84|use
656.44|4.839|so how can lottery ticket HP hypthesis
659.6|4.08|interactive effects of randomly
661.279|4.641|initialized embedding layers be avoided
663.68|4.32|when constructing language models is
665.92|4.28|another question that is embedded in
668.0|2.2|this
671.8|4.12|discussion but we shouldn't say that
674.2|5.52|dimensionality reduction isn't needed
675.92|5.76|it's incredibly necessary for language
679.72|4.119|modeling you absolutely have to work
681.68|4.88|with reduced Dimension unless you're in
683.839|5.481|a very small vocabulary for example
686.56|6.12|like um 26 Latin characters or something
689.32|3.36|something like that like a wave to
692.72|4.96|VEC the inherit input dimension of a
695.2|4.92|large vocabulary model presents many
697.68|4.08|computational intract abilities when
700.12|4.08|designing NLP systems something that
701.76|4.879|you're probably all very aware of
704.2|4.879|likewise though the distance from
706.639|5.2|embedding layers to learning information
709.079|5.041|the loss at outputs puts them in a
711.839|4.481|challenging position to train it's
714.12|4.92|really hard to learn embedding layers
716.32|5.079|because of the indeterminacy in the
719.04|6.239|space space that you're trying to learn
721.399|3.88|you could swap dimensions and it's
725.959|6.68|equivalent but the distance means that
729.32|6.92|they receive learning information
732.639|5.32|last this is a real Challenge and it's
736.24|2.88|present in the history of NLP and deep
737.959|5.24|learning
739.12|6.92|to um Vanishing gradient
743.199|4.481|stuff and this is exacerbated in the way
746.04|3.64|that we have to actually learn embedding
747.68|4.12|layers in standard models where
749.68|4.04|we might modify learning rates to be
751.8|4.24|lower all the way back at the bottom of
753.72|5.76|a network to be gentle with those
756.04|6.12|embedding layers and help them learn
759.48|4.88|effectively but this is really trouble
762.16|5.239|because if we had a good embedding layer
764.36|6.36|at the start those subsequent layers
767.399|3.321|could be much easier to
772.36|5.159|learn so
774.88|5.56|ultimately in order to approach this
777.519|4.521|challenge um
780.44|4.56|we came along with a discernability
782.04|4.919|hypothesis in other words this boiled
785.0|4.56|down to the theory that low dimensional
786.959|5.12|vectors more than anything needed to be
789.56|6.279|able to discern features and that
792.079|7.641|doesn't sound um like a very strong
795.839|8.321|assertion and we started with a really
799.72|6.119|really really low bar and um assume that
804.16|3.56|the most common features needed to be
805.839|3.401|the most discernible features so if
807.72|3.16|we're stuck with a lower dimension and
809.24|5.0|we can't give everything a one hot
810.88|5.199|Vector to be told apart very well then
814.24|5.88|we might want to give the more clear
816.079|6.44|vectors which have more dimensional
820.12|5.0|independencies to those features which
822.519|5.401|appear most frequently and could stand
825.12|5.36|to confuse models the
827.92|5.96|most this hypothesis led us directly to
830.48|6.68|develop the bit Cipher algorithm which
833.88|5.8|is really just a scheme for assigning
837.16|4.4|vectors of zeros and ones nothing too
839.68|5.24|crazy in terms of what we're attempting
841.56|5.56|to do in the figure at right here the
844.92|4.88|order of vector assignment is by Row
847.12|5.959|from top to bottom and this is on a five
849.8|5.88|dimension five bit Vector
853.079|4.32|system the first five from bottom are
855.68|4.519|those one hot
857.399|5.0|vectors past that point you'll see two
860.199|4.921|hot vectors but they're a little bit
862.399|4.721|less Darkly shaded indicating the way
865.12|4.959|that we actually utilize the system in
867.12|5.32|other words we normalize them to have
870.079|2.361|unit
873.0|5.759|sum what I hope you can see from this is
876.839|5.081|that the bit Cipher algorithm
878.759|6.841|generalizes one hot vectors to low
881.92|6.64|dimensions and as a result we can work
885.6|7.28|from a very sparse feature set and
888.56|6.76|explore dimensionalities as a controlled
892.88|4.639|phenomenon and this assignment is
895.32|4.8|incredibly naive too that's the other
897.519|4.521|thing that I want you to see is as well
900.12|3.839|that this discernability hypothesis does
902.04|4.68|not create any meaningful correlations
903.959|4.841|between tokens that behave similarly so
906.72|4.64|if you've got the upper and lower case
908.8|4.2|of a word their vectors aren't going to
911.36|3.839|capture those similarities according to
913.0|3.88|the bit Cipher it's really just going to
915.199|3.961|try and make sure that those features
916.88|3.759|are distinguishable in a low dimensional
919.16|4.84|space and that the most distinguishable
920.639|6.32|features are those which appear most
924.0|6.959|commonly this was enough to do a
926.959|4.0|surprising amount of work
931.959|7.12|so with some scheme for a determin
936.36|5.52|deterministic low dimensionalization
939.079|4.361|procedure we were then able to utilize
941.88|4.16|this solution that we had actually
943.44|4.48|developed previously so this was
946.04|3.96|actually the real motivator for a lot of
947.92|3.599|the work that you're seeing today while
950.0|4.16|it might seem like it's just a
951.519|2.641|checkpoint in the
954.6|4.919|middle provided bit Cipher produces
957.0|4.6|decent embeddings we can ask can other
959.519|3.641|layers be non-randomly initialized in
961.6|3.28|other words without gradient descent or
963.16|3.56|back propagation or other gradient based
964.88|5.079|iterative
966.72|5.96|algorithms this equation came about from
969.959|5.12|analysis of word Toc with the original
972.68|7.56|softmax activation
975.079|7.961|function and um much like other um
980.24|7.039|articulations of the word Toc family of
983.04|6.88|embeddings uh came up with differential
987.279|5.441|solutions that depended on cooccurrence
989.92|4.88|matrices we formalize this as a question
992.72|6.16|is there a way to take a cooccurrence
994.8|7.44|matrix F in this equation
998.88|7.36|here and convert it with some weights
1002.24|7.64|some denominators by row into something
1006.24|5.959|that warms up a single layer feed
1009.88|5.84|forward in a neural
1012.199|7.241|network and ultimately this K minus one
1015.72|5.88|overk term here and this sum
1019.44|3.16|is really just expressing something like
1021.6|3.439|conditional
1022.6|4.599|probability like conditional probability
1025.039|6.92|because Kus 1
1027.199|7.281|K is a wrinkle that says that as the
1031.959|5.24|number of features increases in other
1034.48|3.88|words the context window increases in a
1037.199|4.24|block
1038.36|4.959|Transformer then the warm start that we
1041.439|5.0|could apply to start off a neural
1043.319|4.72|network without a Randomness Randomness
1046.439|3.881|entirely determined by the vectors
1048.039|5.361|underneath
1050.32|5.96|near nearing whatever Direction it's
1053.4|5.2|going all we have to do is compute some
1056.28|4.92|cooccurrences between inputs and outputs
1058.6|3.8|and I don't mean necessarily standard
1061.2|2.68|co-occurrences that you might have
1062.4|4.08|learned about a long time ago which
1063.88|6.52|depend on a radius I mean whatever your
1066.48|6.52|inputs are whatever your outputs are you
1070.4|6.08|take their sum of outer products and you
1073.0|7.32|get a cooccurrence matrix of inputs and
1076.48|6.88|outputs and that can then be utilized to
1080.32|5.839|initialize your layer in that neural
1083.36|5.92|network to be vastly more performant
1086.159|5.52|than what you'd get by a random
1089.28|5.2|initialization this was a strong
1091.679|4.041|motivator for us this was just for a
1094.48|4.64|single layer
1095.72|5.12|model but it depended on the softmax
1099.12|4.16|function for
1100.84|6.56|Activation and the softmax function as
1103.28|6.8|an activation function we knew is also
1107.4|5.24|necessary for self attention features
1110.08|4.4|and this meant that if we could put self
1112.64|4.039|attention into some kind of a standard
1114.48|3.36|form with this equation just like a
1116.679|4.441|single
1117.84|6.839|layer then we could apply the same
1121.12|5.72|solution with one catch that catch is
1124.679|4.441|specifically that we don't know what the
1126.84|5.199|targets are for self attention there's
1129.12|5.439|no target Vector y you know the thing
1132.039|3.841|that you're trying to predict which
1134.559|2.921|which position is the one that you want
1135.88|4.72|to wait most
1137.48|5.24|strongly and so in order to apply this
1140.6|3.4|solution for a self attention model we
1142.72|3.439|had to do some more
1144.0|4.4|analysis and that's in the reference
1146.159|3.88|number one um which is all the way back
1148.4|5.36|up in the first slide if you want to see
1150.039|6.841|it but that derives a differential
1153.76|6.6|Criterion an analog for the single layer
1156.88|5.159|solution that tells us what the targets
1160.36|3.76|of that kind of self attention actually
1162.039|5.481|are the hidden targets the weights that
1164.12|4.72|you're trying to create which really are
1167.52|6.32|just about making sure that the the
1168.84|7.319|layer above self attention has some um
1173.84|3.92|unsurprising things coming towards it
1176.159|3.441|the self attention layer is really just
1177.76|4.0|trying to massage the vectors so that
1179.6|3.88|way they look like something that the
1181.76|3.799|next layer above
1183.48|4.079|expects aside from that though it's a
1185.559|6.201|much more in-depth
1187.559|6.081|conversation the point though is that
1191.76|4.52|for the
1193.64|5.84|model in this picture
1196.28|5.2|here we can now
1199.48|4.079|start off with vectors
1201.48|6.92|X that are not
1203.559|7.6|random we can use those vectors X to
1208.4|5.6|initialize non-randomly the parameters
1211.159|5.201|in W the self attention Matrix and then
1214.0|5.36|use that going up the network to
1216.36|4.84|initialize the parameters in U since
1219.36|4.16|it's just a feed forward layer with
1221.2|4.76|whatever self attention is giving it as
1223.52|5.68|weights and then whatever that produces
1225.96|6.959|the hidden State H we can use that
1229.2|7.12|with the actual targets after the output
1232.919|6.24|layer to warm up the Matrix
1236.32|5.96|o and you might say okay well how did
1239.159|6.721|you figure out what those hidden targets
1242.28|7.72|are like you had to have an output for
1245.88|6.679|the U Matrix to try and hit that too is
1250.0|5.96|something
1252.559|5.24|that the bit Cipher can provide in the
1255.96|4.079|form of label embeddings in other words
1257.799|3.841|low dimensional targets of the thing
1260.039|4.681|that is Downstream that you're trying to
1261.64|6.0|hit the language model's output so
1264.72|7.64|similarly we can warm start the U Matrix
1267.64|4.72|in terms of those bit Cipher label
1275.159|4.441|embeddings so in this view the aim is to
1277.679|4.041|show how simple and general the single
1279.6|5.0|layer softmax activated solution is to
1281.72|4.64|apply it's really just no more
1284.6|5.64|challenging than Computing conditional
1286.36|6.439|probability given inputs and outputs
1290.24|4.559|it's fast it's something that you can
1292.799|6.12|distribute in terms of
1294.799|9.24|processing and it's very very
1298.919|6.76|general so um this is essentially the
1304.039|5.64|process that we're using in order to
1305.679|6.041|warm up the W and U
1309.679|4.641|Matrix
1311.72|4.92|there's the U Matrix there starts out as
1314.32|5.959|zeros so in other words nothing no
1316.64|7.24|random values no weights anywhere
1320.279|6.28|over the data which is just borrowing
1323.88|4.36|the dimension of this gigantic y Matrix
1326.559|4.6|that has all of the Targets in it for
1328.24|5.4|the entire data
1331.159|4.321|set we simply just take the outer
1333.64|4.279|products of whatever the hidden State
1335.48|5.12|the input to that layer is assuming that
1337.919|5.441|the lower layers beneath it are also
1340.6|3.8|warmed up with whatever the targets for
1343.36|3.799|that layer
1344.4|5.879|are following that it's really just
1347.159|5.281|about normalization and a logarithmic
1350.279|5.201|transformation and that logarithm really
1352.44|5.04|just emerges as a result of being an
1355.48|4.4|inverse to the exponential function
1357.48|4.84|which is a part of softmax pretty much
1359.88|2.44|all of
1362.4|4.6|softmax and that's really what brought
1365.96|3.16|us
1367.0|5.72|here so what does warm starting a
1369.12|7.52|network do this is going back to
1372.72|6.4|before we had the bit Cipher algorithm
1376.64|4.44|for dimensionality reduction and we
1379.12|5.12|started out by just saying okay if we
1381.08|7.24|take a s simple simple language
1384.24|6.16|model that only looks at a radius of
1388.32|4.959|traditional cooccurrences as
1390.4|6.159|features we can compen those vectors and
1393.279|7.121|feed them forward for a language model's
1396.559|6.201|output a completely random start a cold
1400.4|4.519|start to a language
1402.76|3.96|model is really just the size of the
1404.919|5.561|vocabulary in
1406.72|5.839|perplexity and those three lines here
1410.48|4.0|for a few different radi are
1412.559|4.6|demonstrating that point with the point
1414.48|5.799|all the way at the top leftand corner of
1417.159|5.441|this figure cold
1420.279|4.321|starts in any of those cases when the
1422.6|5.319|warm start is applied the perplexity is
1424.6|4.92|immediately automatically
1427.919|3.321|lower
1429.52|4.72|and
1431.24|5.88|furthermore the trajectories that the
1434.24|5.6|updates follow continue in the same
1437.12|4.88|learning rate and the same same time to
1439.84|4.04|perform better than models that were
1442.0|4.159|started
1443.88|5.039|cold if you have a warm if you have a
1446.159|7.0|early stopping Criterion similarly early
1448.919|5.921|stopping will more than just generally
1453.159|5.12|uh engage
1454.84|6.0|first and with a higher
1458.279|4.88|perplexity so this was the first
1460.84|6.12|indication that we had figured out
1463.159|3.801|something that's very useful
1469.159|3.921|so some folks on slid say they're B
1471.279|3.721|confused they're asking are we talking
1473.08|4.36|about an alternative approach to self
1475.0|5.24|attention we are and that's all the way
1477.44|2.8|back at slide
1480.48|7.76|one and it is the premise of this whole
1484.88|6.0|conversation so here in this modified
1488.24|4.919|version of self attention you might
1490.88|5.44|normally expect to do a comparison of
1493.159|4.841|your inputs The Matrix X whatever your
1496.32|3.76|inputs are they might be a whole block
1498.0|3.559|of vectors or they might be this is self
1500.08|3.319|attention it's not cross attention where
1501.559|3.72|you have different vectors that you're
1503.399|6.0|trying to
1505.279|7.0|attend and forgetting about the
1509.399|5.241|values which for us is the U
1512.279|4.481|Matrix the keys and
1514.64|3.759|queries which are the parameters for
1516.76|2.919|self attention are in the middle they're
1518.399|6.0|in
1519.679|8.041|between the two copies of the inputs
1524.399|4.841|X each of those you can view as some
1527.72|3.04|kind of a project ection down to a
1529.24|3.08|dimension where they can interact and
1530.76|3.76|this is necessary for something like
1532.32|4.2|cross attention where you might have
1534.52|3.96|different dimensionalities like X1 and
1536.52|4.12|X2 and two separate groups of vectors if
1538.48|4.799|you're doing something like machine
1540.64|5.44|translation that's not necessary to
1543.279|6.321|think about when you're just looking to
1546.08|5.44|do a standard language model that has to
1549.6|4.199|predict the next output according to the
1551.52|5.639|inputs which are also outputs from
1553.799|3.36|previous iterations
1558.799|8.801|two insights here one that multiplying
1563.0|7.44|the key and query matrices w k and
1567.6|4.16|WQ it's just another parameter Matrix
1570.44|3.839|that's
1571.76|4.12|implied there aren't two parameter
1574.279|5.161|matrices there in the middle for self
1575.88|6.399|attention in any effective way there is
1579.44|5.2|a common dimension of comparison and
1582.279|5.081|that kind of just moves stuff around it
1584.64|4.56|creates degrees of freedom so that
1587.36|4.88|optimization can figure out what's the
1589.2|5.52|best waiting from comparisons but the
1592.24|4.039|soft Max function is strictly operating
1594.72|4.64|on
1596.279|6.201|similarities of that comparison
1599.36|5.4|space it's not doing anything with those
1602.48|4.64|similarities it's just soft maxing them
1604.76|5.2|it's just activating so if it was a big
1607.12|5.159|similarity it's a big attention
1609.96|4.28|value in this
1612.279|3.76|equation there's no transformation
1614.24|4.6|happening before those vectors are
1616.039|5.201|multiplied together inner products
1618.84|4.199|so those vectors better be good vectors
1621.24|3.679|that you're starting with x and x
1623.039|4.601|transpose the same
1624.919|4.841|thing they better be vectors that are
1627.64|3.279|comparable they can't be vectors from
1629.76|2.799|Cross attention where you're trying to
1630.919|2.921|translate from one language to another
1632.559|3.401|and they just don't inter product
1633.84|3.559|they're different dimensions you could
1635.96|3.719|force it through if they were two
1637.399|4.601|differently trained embedding layers and
1639.679|4.761|they had the same Dimension with this
1642.0|4.919|mechanism and if you didn't you could
1644.44|7.28|put those key and query matrices back in
1646.919|4.801|between the two x vectors X blocks of
1652.44|6.479|vectors but a lot of what's going on
1655.0|6.72|here in this talk is trying to simplify
1658.919|5.6|and make more
1661.72|5.559|efficient the architectures that we need
1664.519|5.681|and the mechanisms that they
1667.279|3.88|utilize given what we know about how
1670.2|3.0|language
1671.159|3.52|functions and that's a critical piece
1673.2|3.24|there we have assumptions that we can
1674.679|4.681|make If all we're doing is auto
1676.44|5.479|regression we don't need cross tension
1679.36|5.0|dimensionalization in
1681.919|3.561|between that'll be the theme in other
1684.36|4.28|words
1685.48|5.919|that can we use knowledge that we have
1688.64|5.519|about the way language functions to
1691.399|5.16|design better versions of architectures
1694.159|5.081|that meet the needs of language instead
1696.559|6.801|of being simply
1699.24|5.559|General is this good this is important
1703.36|4.84|so if there are any questions here it's
1704.799|3.401|a good time
1711.159|4.681|we
1712.519|6.601|are there and
1715.84|4.8|there so we just talked briefly this was
1719.12|2.96|for language we're thinking about
1720.64|3.32|language models it's a really simple
1722.08|3.24|language model there's no self attention
1723.96|4.48|here
1725.32|5.76|yet this is really just evaluating that
1728.44|6.56|a warm start in either the blue green or
1731.08|5.52|purple case does better than its partner
1735.0|3.88|which is a cold start of the same
1736.6|7.0|architecture same hyper
1738.88|7.279|parameters orange reddish and
1743.6|4.559|brown so three different models
1746.159|5.561|regardless of how long your context is
1748.159|6.52|in each case here we see that a model
1751.72|4.839|which has a non-random initialization by
1754.679|2.641|the equation presented two slides back
1756.559|5.561|from
1757.32|7.28|here starts a network off with a much
1762.12|2.48|lower
1765.84|5.92|perplexity the requirements to apply
1768.32|6.959|this solution to a feed forward layer of
1771.76|6.919|parameters is simply
1775.279|4.921|that your inputs should not have
1778.679|3.801|negative
1780.2|3.24|values that's really all we have to
1782.48|5.319|worry
1783.44|5.92|about so it becomes really easy to ask
1787.799|3.681|questions like well what happens when
1789.36|3.0|you apply this to other data with non-
1791.48|4.12|negative
1792.36|4.72|values well there's one little catch
1795.6|3.559|that we had to think about here in this
1797.08|4.24|case and that is
1799.159|4.281|with the bit Cipher or one hot vectors
1801.32|5.959|we're controlling the Norms of the
1803.44|5.88|inputs with standard embeddings with
1807.279|6.961|mnist for example when you're trying to
1809.32|7.64|predict a handwritten digits 0 through 9
1814.24|5.08|value you don't get to assume
1816.96|3.52|necessarily that all inputs have the
1819.32|4.719|same
1820.48|5.24|Norm you can normalize the inputs but
1824.039|3.24|doesn't necessarily make sense to
1825.72|2.799|normalize them to one when you're
1827.279|3.361|looking at images
1828.519|5.76|for example they're non- Negative they
1830.64|7.159|have 0 through 255 for example in
1834.279|6.841|mnist and as a result we can put these
1837.799|7.161|data through that same warm
1841.12|8.52|start now one little caveat here I've
1844.96|7.8|alluded to about the Norms of vectors is
1849.64|8.279|that we don't know what that value of K
1852.76|5.159|is in other words let me go back
1858.639|6.241|could look at it here or here that's the
1862.48|4.76|number of features per
1864.88|5.96|prediction which if you're looking at
1867.24|5.799|unit normed word vectors is however big
1870.84|4.92|your context window is
1873.039|5.921|K because they all have unit norm and
1875.76|5.68|there's K of them but if you're looking
1878.96|5.079|at just an image it's not clear if it's
1881.44|5.719|a composition of multiple vectors if
1884.039|7.081|it's one vector and how many it is if it
1887.159|3.961|is a composition it just has a
1891.84|8.16|norm in application to data like that
1896.24|6.399|that is what K becomes the average norm
1900.0|4.32|of an input and I'm regretting not
1902.639|4.04|putting a graph in this but the paper
1904.32|5.479|that discusses this shows that in the
1906.679|7.0|Mist data set the exact optim optimal
1909.799|8.36|value of K is the average norm of the
1913.679|6.12|inputs however you've pre-processed them
1918.159|3.721|and that's how we generally apply this
1919.799|4.961|rule when we're warm starting systems
1921.88|5.32|and we don't have unit normed vectors
1924.76|5.0|and it was learned from studying this
1927.2|6.28|model's application this solution's
1929.76|9.32|application to nonlinguistic data but as
1933.48|5.6|mentioned the purpose was always towards
1940.559|5.321|language so longer context windows in
1944.279|4.801|principle should provide models with
1945.88|5.84|more information than shorter context
1949.08|6.199|Windows this means one should expect
1951.72|4.919|that models perform better when context
1955.279|4.0|window length is
1956.639|4.52|longer
1959.279|4.201|theoretically and this is essentially
1961.159|4.321|the reason for why self attention was
1963.48|4.0|initially developed researchers wanted
1965.48|4.24|to improve language models and context
1967.48|5.159|Windows providing more information were
1969.72|5.679|seen as the key to that in other words
1972.639|5.28|the more features the more information
1975.399|5.76|the more flexibility a model can have
1977.919|5.161|have and
1981.159|3.48|expressivity however without feature
1983.08|4.319|weights models didn't simply get better
1984.639|4.52|with long context windows and feature
1987.399|4.481|weights and self attention were
1989.159|7.64|hypothesized to be needed and this was
1991.88|4.919|proven back in 2017 with the Transformer
1997.6|4.959|architecture in moving towards self
1999.76|4.36|attention and Transformer though the
2002.559|5.36|Primacy of the Transformer
2004.12|7.08|architecture's block context model
2007.919|6.681|a shadow over the use of other context
2011.2|6.88|models so for example if I were to ask
2014.6|6.72|here is it clear to everyone
2018.08|6.64|that the standard self attention block
2021.32|4.959|model of context is different than the
2024.72|4.319|traditional notion of co-occurrences
2026.279|6.161|which use a radius that is not
2029.039|5.721|positionally anchored it is the context
2032.44|4.719|model the positional anchoring of the
2034.76|4.639|block context model that gives it its
2037.159|5.48|information
2039.399|3.24|it is
2042.679|5.92|not in all likelihood anything
2045.48|5.96|else now what you do with that context
2048.599|4.961|model matters you can't just take those
2051.44|3.88|vectors in a block add them together and
2053.56|3.48|expect a feed forward to do well that's
2055.32|3.759|where self attention is needed in order
2057.04|5.44|to figure out which Vector needs the
2059.079|6.04|best weight most
2062.48|5.24|weight so what you'll also see in the
2065.119|5.161|architectures that are based on what
2067.72|4.199|I've already presented is that we're
2070.28|4.28|interested to explore how different
2071.919|5.641|models of context for language models
2074.56|5.0|can be integrated in
2077.56|4.64|general because they each provide
2079.56|4.44|different information and we all know
2082.2|4.159|that the standard Transformers block
2084.0|4.879|model of context requires a ridiculous
2086.359|5.52|amount of information and data in order
2088.879|3.0|to become effectively
2092.0|7.04|trained so the
2094.399|6.921|current um Spate of contexts that we
2099.04|4.319|use top there might be the standard
2101.32|4.279|Transformer context that has a fixed
2103.359|4.401|positional block and it takes the first
2105.599|5.401|10 tokens for example the second 10
2107.76|4.04|tokens and the third 10 tokens each in
2111.0|4.24|different
2111.8|5.36|blocks and each of those is a group of
2115.24|4.2|contextualizing
2117.16|5.48|vectors the second one there that you
2119.44|5.04|see with the r as a subscript is a
2122.64|3.959|radial model because those do different
2124.48|3.8|things in other words rather than assume
2126.599|5.121|you're looking at the first 10 or the
2128.28|6.68|nth 10 features you pick a radius and
2131.72|6.2|you say what are the last R features the
2134.96|5.0|last R vectors that can also have an
2137.92|4.12|attention distribution a self attention
2139.96|4.04|distribution according to the exact same
2142.04|4.2|model that's being
2144.0|6.04|presented it produces an entirely
2146.24|7.04|separate context hidden State whatever
2150.04|5.68|you want to call it which can be
2153.28|5.0|conjoined with the block model to
2155.72|5.16|articulate features
2158.28|5.839|and be given to an output layer that
2160.88|4.959|knows what to do with them when each has
2164.119|3.921|different
2165.839|3.721|values the concatenation of those
2168.04|4.16|different context models keeps the
2169.56|5.36|information separate so the output layer
2172.2|5.56|can decide which portion of the context
2174.92|5.12|is useful for the
2177.76|5.44|prediction this last one is getting
2180.04|5.24|really traditional at the bottom it's
2183.2|6.2|what I refer to as a document
2185.28|7.319|model if um you've ever implemented
2189.4|5.199|something like a naive based classifier
2192.599|4.881|or a term frequency inverse document
2194.599|5.281|frequency model that's essentially what
2197.48|4.48|a document model is add up your vectors
2199.88|4.4|you get
2201.96|5.24|something is it going to be the best for
2204.28|5.44|predicting the next token absolutely not
2207.2|4.72|however it's always different and what
2209.72|5.2|that means is that even if you wrap to
2211.92|6.0|the next block between the radial and
2214.92|4.52|the document models you have a unique
2217.92|3.76|context Vector even if you're looking at
2219.44|4.28|the exact same block because the
2221.68|3.6|document has grown and the radius just
2223.72|2.92|says what are the last three what are
2225.28|5.28|the last
2226.64|5.36|10 as a result when you incorporate
2230.56|2.799|different models of context you don't
2232.0|4.04|really have to say that there's a finite
2233.359|4.96|context window it might not be very good
2236.04|3.88|to make predictions past the first block
2238.319|2.681|but that might be about how much data
2239.92|3.24|you've
2241.0|3.839|used and it might be about the hyper
2243.16|3.439|parameters for each one of those models
2244.839|5.321|that you're applying in other words
2246.599|3.561|radius the block size like
2252.119|4.641|usual so far the only embeddings that
2254.72|5.56|I've suggested are from this bit Cipher
2256.76|5.559|algorithm and as I've expressed they're
2260.28|5.0|um they don't capture any useful
2262.319|5.52|similarities between similar tokens the
2265.28|4.079|bit Cipher algorithm it doesn't care if
2267.839|2.961|you're looking at the uppercase or the
2269.359|3.441|lowercase version of a word it doesn't
2270.8|5.36|see them as aing any similarity even
2272.8|6.0|though they're might be used very
2276.16|7.48|similarly so how can you
2278.8|8.319|utilize the bit Cipher to create vectors
2283.64|7.199|or tokens that have meaningful
2287.119|6.801|similarities between words that are used
2290.839|6.76|similarly and this is just backing off
2293.92|6.84|to the traditional methods once again
2297.599|6.48|taking cooccurrences of bit Cipher
2300.76|4.88|vectors with whatever is there at the
2304.079|4.561|middle or center of a co-occurrence
2305.64|3.0|model
2309.56|4.24|normally if you think about one hot
2311.72|5.48|vectors A co-occurrence Matrix is really
2313.8|6.2|just the same thing except now we just
2317.2|6.24|have smaller vectors with different
2320.0|5.52|dimensions on so to
2323.44|4.36|speak and we
2325.52|6.12|normalize after concatenating these
2327.8|8.2|blocks of different radi from the bit
2331.64|6.32|Cipher to match the original input
2336.0|3.56|requirements that we discovered
2337.96|4.0|for the warm start
2339.56|4.279|solution and that enables us to use
2341.96|3.04|these just like we would the original
2343.839|5.561|bit Cipher
2345.0|7.96|vectors except now just from the usual
2349.4|6.719|co-occurrent statistics you'll see that
2352.96|5.56|Capital word and lowercase word have a
2356.119|4.96|lot of common usage and you know this
2358.52|5.36|works because you've seen co-occurrences
2361.079|5.601|for a very long time and while they
2363.88|4.32|might not normally be useful in our
2366.68|4.679|applications the these days with deep
2368.2|5.84|learning they can be imparted through
2371.359|5.561|the bit Cipher algorithm to prescribe
2374.04|2.88|vectors as
2380.88|7.28|well so here's where things start paying
2383.839|4.321|out in terms of speed and
2390.28|3.28|efficiency if you only have one layer of
2392.76|4.359|self
2393.56|6.559|attention then that means that you don't
2397.119|5.281|need to worry about whatever weird
2400.119|4.041|expressive stuff is happening that you
2402.4|3.959|know similar inputs might have slightly
2404.16|5.04|different hidden
2406.359|5.801|States since that first layer is just a
2409.2|5.68|set of static word
2412.16|6.28|embeddings the self attention layer is
2414.88|6.239|working off of static word embeddings
2418.44|6.679|and that means each pair of words have a
2421.119|6.24|fixed comparison given static word
2425.119|5.441|embeddings and that means if you want
2427.359|4.561|want to compute the quadratic features
2430.56|4.92|of self attention you can just
2431.92|5.88|pre-compute them and pull them from
2435.48|3.839|memory this caching of vector
2437.8|4.0|comparisons is
2439.319|5.681|essentially reducing the self attention
2441.8|5.76|layer cost from quadratic to linear
2445.0|5.68|since those values that we're using to
2447.56|6.92|weight the vectors for the feed forward
2450.68|5.48|layer no longer require comparison
2454.48|3.72|across the block they're already
2456.16|4.28|compared
2458.2|5.32|so when our vectors are static which is
2460.44|6.72|at inference time and if we're
2463.52|7.839|not learning the embedding layers
2467.16|8.0|parameters with iterative differential
2471.359|6.521|updates then not only do we have to not
2475.16|4.08|track gradients for the embedding layer
2477.88|3.12|but we don't even have to compute the
2479.24|4.64|vector comparisons we can pre-compute
2481.0|6.48|them and just load them which is much
2483.88|3.6|much faster
2491.88|6.04|so we can reduce a lot of in all the
2495.319|3.881|inference in training costs not all of
2497.92|2.84|the training costs some of the training
2499.2|5.0|costs because if we want to update those
2500.76|6.64|vectors then we can't assume cach
2504.2|5.32|comparisons um but it's a huge cost
2507.4|4.52|savings this means that we can train
2509.52|3.64|these self-attentive feed forward unit
2511.92|5.439|models very
2513.16|6.28|quickly and with good initializations
2517.359|3.641|but there are some other things that we
2519.44|6.32|immediately observed while developing
2521.0|7.319|these models and that is the lack of
2525.76|4.92|randomization produced models which were
2528.319|3.961|quite effective even on small data now
2530.68|3.28|it doesn't mean that training on small
2532.28|2.88|data will let you generalized to
2533.96|2.6|everything else that's out there in the
2535.16|4.199|world in other words training on a small
2536.56|4.68|data set might produce a model which has
2539.359|4.881|a surprisingly low perplexity on its
2541.24|4.319|training set but it doesn't mean that
2544.24|2.52|you're going to be able to generalize
2545.559|2.481|and have a language model that's talking
2546.76|3.839|well from just hearing a couple of
2548.04|4.72|thousand tokens it does mean it will
2550.599|4.801|know that couple of thousand tokens very
2552.76|2.64|well very
2557.559|5.201|quickly but there's a challenge with
2561.04|3.92|using self attention
2562.76|4.44|still and that is the fact that the
2564.96|5.96|block model of
2567.2|7.76|context often is not fully utilized
2570.92|7.48|since many um documents are shorter than
2574.96|6.599|long context models or long context
2578.4|4.84|windows and these days there are
2581.559|4.0|exceptionally long context Windows I'm
2583.24|4.119|not even talking about those uh many of
2585.559|3.401|the language modeling benchmarks simply
2587.359|2.881|don't even go out to a thousand words
2588.96|5.04|when it comes to contexts and you're
2590.24|6.879|looking at a a document to
2594.0|5.88|predict so
2597.119|5.48|um this has been a problem for a while
2599.88|4.239|and it means that if you're going to pad
2602.599|3.561|your short documents you're going to
2604.119|4.24|waste a lot of prediction on those
2606.16|4.48|paddings
2608.359|5.641|um a lot of computation gets lost just
2610.64|5.719|for null information
2614.0|3.319|essentially and the way that this is
2616.359|4.601|often
2617.319|7.561|relieved in some groups and to great
2620.96|6.159|effect is by packing long contexts so
2624.88|4.4|for example if you've got a 100,000
2627.119|4.921|token context window most documents will
2629.28|4.64|not be 100,000 tokens long what do you
2632.04|3.92|do with the rest of that long context if
2633.92|4.08|you want to use a thousand tokens of
2635.96|4.72|good training data
2638.0|4.16|you fill out the other 99,000 tokens
2640.68|2.76|with a bunch of other random documents
2642.16|4.159|that don't belong anywhere near the
2643.44|6.8|first one that's called
2646.319|5.881|packing packing can be utilized without
2650.24|4.119|um
2652.2|3.8|impacting different documents with each
2654.359|3.48|other without contaminating the
2656.0|5.359|information between documents and that
2657.839|5.601|takes a lot of work but it can be
2661.359|4.881|done
2663.44|4.159|however um there are different
2666.24|2.76|strategies that we could employ
2667.599|3.641|different engineering tricks that we
2669.0|5.4|could employ to
2671.24|6.64|make our operation of self attention
2674.4|5.56|more effective at any length of document
2677.88|4.199|without having to deal with this packing
2679.96|6.2|problem and that comes
2682.079|7.48|about by dynamically changing the
2686.16|5.56|context length from some Maximum value
2689.559|5.601|that's what you would normally
2691.72|5.52|set just use the context that you have
2695.16|3.48|but you still have to create batches if
2697.24|2.56|you want to train models quickly and
2698.64|3.36|what that means is that there's still
2699.8|6.279|some padding if you use this
2702.0|6.76|approach but you can pad those short
2706.079|6.48|documents
2708.76|7.4|to set lengths batch short documents
2712.559|8.601|together batch long documents
2716.16|7.84|together this means that we don't need
2721.16|5.679|to pack documents together to make use
2724.0|4.839|of a long context window when a document
2726.839|4.0|is long you can let its context be long
2728.839|3.52|when a document is short you can put it
2730.839|4.561|with other short documents and just use
2732.359|5.281|a subset of those self attention
2735.4|4.159|parameters and with traditional self
2737.64|3.32|attention parameters keys and queries it
2739.559|4.161|would never be a subset because it's a
2740.96|4.96|low dimensionalization that that Matrix
2743.72|4.08|provides with this modified self
2745.92|3.439|attention though there's a different
2747.8|3.44|shape to the weight Matrix and that's
2749.359|4.2|why it's a subset of those parameters
2751.24|4.319|that we have to utilize and that might
2753.559|3.721|be something worth discussing afterwards
2755.559|3.481|in other words how does the difference
2757.28|3.76|in shapes of dimensionalities
2759.04|3.6|between this and the standard self
2761.04|4.92|attention
2762.64|3.32|weights shake
2766.96|5.28|out but we want to get to a different
2769.319|2.921|point for the sake of this
2774.16|4.48|conversation what is a model like this
2776.2|3.84|useful for that should be a question
2778.64|3.08|that you're asking it's a question that
2780.04|4.68|we've been
2781.72|3.0|asking
2784.92|9.08|um we're not entirely certain yet how an
2790.04|5.64|extremely large model like this will
2794.0|5.079|function on trillions of tokens for
2795.68|6.2|example in other words um can you expect
2799.079|5.681|the same kinds of outcomes like
2801.88|7.04|a chat GPT kind of thing from some of
2804.76|6.359|these models human interaction and rhf
2808.92|5.48|and all the rest of that though it's
2811.119|6.48|something that we're considering but
2814.4|6.679|also at different scales too since
2817.599|6.881|those are performant on their own as
2821.079|3.401|well but for
2824.76|7.599|what so the point is is that from what
2829.0|5.16|we've stress tested into the billions
2832.359|3.161|models can be trained very quickly on a
2834.16|4.12|relatively small
2835.52|5.559|GPU in ways that we expect when we cach
2838.28|5.88|Vector comparisons we see really big
2841.079|7.201|speedups when we don't cach those
2844.16|5.64|comparisons you see all of the um growth
2848.28|5.24|in computation time that you would
2849.8|3.72|expect from longer context
2854.8|4.6|Windows this one here though we're
2858.119|2.881|trying to make it really really really
2859.4|4.24|small the one called
2861.0|5.76|potato that's because we want to see if
2863.64|6.64|we can train a model from scratch since
2866.76|5.599|on very little data these models can fit
2870.28|4.48|effectively with the initializations
2872.359|5.2|that we've
2874.76|4.64|developed and with the purpose of
2877.559|4.52|starting from scratch starting with no
2879.4|4.679|data we're thinking about Edge Computing
2882.079|4.24|cases where we could deploy a language
2884.079|5.081|model with a microphone so that a person
2886.319|4.961|can talk to it and just train it from
2889.16|6.159|their own data train it from their own
2891.28|4.039|speech to understand their
2898.52|5.44|speech so between these we've explored a
2902.359|3.881|lot of different configurations trying
2903.96|4.399|to consider similarities to what some
2906.24|3.72|standard configurations might look like
2908.359|3.081|couple thousand tokens in a context
2909.96|5.52|window for example to look something
2911.44|6.6|like a gpt2 style model thinking about
2915.48|4.079|bit Cipher embeddings that are 500
2918.04|4.36|dimensional or thousand dimensional to
2919.559|5.881|be something like a gpt2 that's again
2922.4|4.6|pointing towards like the big SL large
2925.44|5.119|category of models that we've
2927.0|6.96|experimented with beyond that we haven't
2930.559|6.361|really touch those scales because our
2933.96|5.159|first objective is not to make big big
2936.92|4.32|language models and train chatbots we
2939.119|6.161|want to know what can we do with a small
2941.24|4.04|model since this is a relatively unique
2948.599|8.361|capability so what does training look
2950.96|8.48|like to the best of um our ability so
2956.96|4.44|far it's kind of hard to see but the
2959.44|5.48|first step is that warm start where you
2961.4|6.439|train the bit Cipher and
2964.92|4.96|you take a couple of splits of data and
2967.839|5.24|you compute that warm start for the self
2969.88|6.6|attention layer and feed forward
2973.079|6.28|layers in this case which is really just
2976.48|6.48|using a 100 million token data set from
2979.359|5.48|the baby language model challenge which
2982.96|6.399|has as an objective
2984.839|6.601|to see what language models can do on a
2989.359|4.121|relatively human scale of data in other
2991.44|4.72|words 100 million tokens is something
2993.48|4.48|that a person might hear in 10 years of
2996.16|5.399|their life
2997.96|5.96|in 10 years of life people become pretty
3001.559|5.321|proficient speakers and can a language
3003.92|5.399|model be trained at that
3006.88|5.12|scale the second stage after the warm
3009.319|7.121|start happens is where the majority of
3012.0|9.0|training time occurs and yet um is also
3016.44|4.56|where training operates the most
3021.24|5.64|quickly at this stage we find that
3024.04|4.64|freezing vectors is important one
3026.88|3.52|because it means that we can train much
3028.68|4.24|quicker so we can have the subsequent
3030.4|5.959|layers optimized beyond their warm
3032.92|7.159|starts very very fast using that Vector
3036.359|5.841|caching the vector comparison caching to
3040.079|4.601|avoid the quadratic costs of self
3042.2|4.119|attention this articulates the
3044.68|5.56|parameters in the middle layers of the
3046.319|7.48|model for you know taking 100 million
3050.24|6.119|tokens making five passes over the data
3053.799|5.081|here um a lot quicker than any of the
3056.359|5.881|other stages and the comparison that
3058.88|6.239|you'd make to this is the training time
3062.24|4.8|once those embedding layers are unfrozen
3065.119|3.72|where everything slows down to the
3067.04|4.0|normal speeds where you have to do all
3068.839|4.72|of your vector comparisons on the Fly
3071.04|4.44|since you can't assume that the same
3073.559|4.081|comparisons will always result in the
3075.48|4.56|same numbers since model parameters
3077.64|2.4|might be
3081.319|4.361|updated this is the best procedure that
3083.48|4.2|we've figured out so far and in order to
3085.68|4.52|make those vectors update we find that
3087.68|4.96|learning rates have to be adjusted
3090.2|4.879|dynamically inside of the network like
3092.64|6.28|normal and that the embedding layers are
3095.079|3.841|really tough to make progress
3099.24|5.48|on and you'll notice here in this
3102.04|4.68|picture that the slowness and the lack
3104.72|3.72|of stability for example in learning the
3106.72|2.96|embedding layer once it had been
3108.44|4.0|prescribed
3109.68|5.6|earlier makes it really hard to train
3112.44|4.6|over the entire data set compared to
3115.28|3.48|five passes for example
3117.04|3.96|in the middle phase when the middle and
3118.76|4.039|upper parameters are being updated still
3121.0|4.64|with back
3122.799|5.081|propagation and the other thing that I
3125.64|7.959|would highlight before leaving this
3127.88|8.199|slide is in Phase One how the warm start
3133.599|3.96|saturates pretty quickly so if you have
3136.079|3.76|100 million tokens you really only need
3137.559|4.921|to apply the warm start to something
3139.839|4.921|like maybe 10 million tokens not that
3142.48|5.2|much more you don't see that much gain
3144.76|5.599|from that much more data
3147.68|4.2|that's not a bad thing um because it
3150.359|4.361|means that we don't have to apply that
3151.88|4.4|process for any longer I mean it would
3154.72|4.0|be great if it gave us all of the
3156.28|3.48|optimization that we could hope for but
3158.72|2.639|it's not something that we could
3159.76|4.16|necessarily expect since it's just an
3161.359|4.76|approximation of where the parameters
3163.92|2.199|are
3167.96|4.399|headed so on the back of an envelope
3170.76|4.359|thinking about how the systems that
3172.359|5.801|these that example was trained on as
3175.119|5.761|compared to other examples that are out
3178.16|5.72|there and thinking about models that are
3180.88|6.6|kind of sort of similar
3183.88|6.88|size we're talking about a 12 GB GPU a
3187.48|3.28|relatively small single
3191.04|3.559|chip specifically when referring to
3193.4|5.399|these training
3194.599|7.641|times okay so that's 12 gab
3198.799|5.601|GPU just working off of eight chips each
3202.24|5.119|having roughly four times the
3204.4|3.88|scale and comparing to this time that it
3207.359|3.561|took to
3208.28|4.12|train something with maybe an additional
3210.92|3.8|order of magnitude although we have
3212.4|4.0|trained models up to around 50 million
3214.72|3.96|parameters to which is getting towards
3216.4|5.08|gpt2
3218.68|4.32|scale we see training times that if we
3221.48|4.92|scaled up to the relatively large
3223.0|5.2|systems that um present us with how much
3226.4|4.399|work we should expect to have to do for
3228.2|4.24|a model that large we can expect to be
3230.799|4.0|able to train much
3232.44|4.52|faster but as mentioned the initial
3234.799|5.28|objective here is not to Simply figure
3236.96|5.399|out um how well we can do something
3240.079|5.04|that's being done well already it's to
3242.359|4.44|figure out what these alternative
3245.119|4.44|strategies are useful for since they
3246.799|6.401|give us access to different regimes of
3249.559|3.641|model scale as
3254.88|6.28|effective so
3257.799|5.441|um as mentioned we've gone to relatively
3261.16|3.84|large amounts of data I wouldn't really
3263.24|3.44|call them big data at this time even
3265.0|3.4|though just a couple of years go a
3266.68|3.04|billion tokens would be a relatively
3268.4|3.88|large amount of
3269.72|5.72|data it's really just a stress test at
3272.28|5.16|this point gives us something like do we
3275.44|4.2|continue to see models getting better as
3277.44|4.2|we continue to give them more data do we
3279.64|4.08|continue to see models getting better as
3281.64|3.439|we continue to give them longer context
3283.72|4.48|windows and the answer to both of those
3285.079|5.121|questions is absolutely yes so nothing
3288.2|4.159|is telling us that we can't train bigger
3290.2|3.96|models with these but will those bigger
3292.359|4.121|models be as good as a standard self
3294.16|3.959|attention model I don't know it's a
3296.48|3.079|different self attention parameter
3298.119|3.881|Matrix than what you see in a standard
3299.559|5.401|self attention model you could integrate
3302.0|5.0|the two and in theory that should be
3304.96|5.04|Overkill because you'd have more
3307.0|5.44|parameters and more power through them
3310.0|4.16|and we can see from this work that the
3312.44|4.919|alternative self attention parameters
3314.16|5.84|are reasonably
3317.359|4.96|effective we're getting close to
3320.0|4.68|time so I'll go quick through these
3322.319|5.28|since this is the work that we're
3324.68|6.52|approaching uh right now
3327.599|6.841|and this is the idea that um we're
3331.2|6.08|seeing as a use case for such a model
3334.44|5.48|like this in other words no
3337.28|4.96|pre-training just training on the target
3339.92|4.84|data whatever the data of interaction
3342.24|4.359|are and this example you'll see that
3344.76|4.0|this relatively smaller Precision
3346.599|3.561|language model just needs to predict
3348.76|5.12|whether or not a light should go on or
3350.16|6.32|off you know a lamp that listens with a
3353.88|4.08|microphone and a switch and you can use
3356.48|4.599|that switch to train the
3357.96|3.119|[Music]
3361.4|6.08|lamp so that's the goal here um can
3364.88|4.56|pre-training be eliminated and we want
3367.48|3.92|to anticipate whether or not you're
3369.44|4.2|going to flip the light on or
3371.4|3.919|off that's the task that we're going to
3373.64|4.52|try and
3375.319|5.121|approach or that rather we're currently
3378.16|4.56|approaching there's a few different
3380.44|4.52|processes that integrate into this
3382.72|5.2|approach there has to be a microphone
3384.96|4.24|that's listening to you recording audio
3387.92|3.199|there has to be a transcription
3389.2|3.44|algorithm and we use wave Tove at this
3391.119|4.041|point because there's a very small
3392.64|4.199|version of it that's character-based and
3395.16|3.679|as a result doesn't even require you to
3396.839|3.801|use consistent or it does require to use
3398.839|4.041|consistent language but it doesn't even
3400.64|4.0|require you to use words since it's
3402.88|5.679|strictly
3404.64|6.12|phonetic there has to be and this is the
3408.559|4.961|bread and butter of what's going on here
3410.76|5.48|a process which anticipates what you
3413.52|5.2|want and that process is responsible for
3416.24|5.079|creating good training data so this is a
3418.72|5.119|smart data collection
3421.319|5.121|algorithm that figures out when you flip
3423.839|5.441|the switch is that the target for
3426.44|6.679|something that you just said is that the
3429.28|5.44|transfer learning objectives from text
3433.119|5.881|that was
3434.72|7.16|transcribed that it anticipates you
3439.0|5.92|want following this there's also two
3441.88|5.32|other processes one which operates on a
3444.92|5.159|different uh time cycle and that's
3447.2|4.599|training so always train a model always
3450.079|4.76|be training a
3451.799|4.76|model whenever there's new data is
3454.839|4.52|essentially what that fourth process
3456.559|4.28|says and the last one is operation in
3459.359|3.561|other words if you flip the switch there
3460.839|4.041|has to be a process which operates the
3462.92|4.8|light bulb it always has to be a lamp in
3464.88|5.88|order to be useful it always has to be
3467.72|6.359|able to just be a
3470.76|5.599|switch however that operation process
3474.079|5.161|likewise needs to see a directive from
3476.359|4.68|the anticipator if the language model
3479.24|4.559|predicts that you just said a thing that
3481.039|4.641|means you want there to be light that
3483.799|3.721|operator then needs to receive the
3485.68|7.08|signal from the
3487.52|8.519|anticipator and execute the directive if
3492.76|6.0|the user then though within some time
3496.039|5.401|scale changes the switch back after the
3498.76|4.799|model created a prediction that was bad
3501.44|5.399|the operator is also responsible for
3503.559|5.601|issuing a correction to the anticipator
3506.839|4.881|to correct the training
3509.16|4.6|data what this looks like as a process
3511.72|5.8|is in this diagram
3513.76|7.48|here and you can see um the flow here
3517.52|6.559|from stage one a verbal command maybe
3521.24|5.359|gets recorded transcribed turned into
3524.079|5.561|text and if there's no model that's yet
3526.599|4.841|trained that text is just stored as data
3529.64|3.56|along with any directives given by the
3531.44|5.2|user in the form of a light switch going
3533.2|3.44|on or off
3537.0|4.28|once there's any data the learning
3539.72|3.0|process says okay time to train a
3541.28|4.72|language
3542.72|6.639|model and integrate it with these
3546.0|5.4|targets once a model is done training
3549.359|5.121|it's sent over to the anticipator who is
3551.4|7.439|responsible for using the language
3554.48|6.72|model that small language model then is
3558.839|5.401|now empowered to make predictions every
3561.2|5.599|single time it receives a text
3564.24|3.44|command and those predictions are sent
3566.799|3.641|to the
3567.68|6.04|operator which then does whatever it's
3570.44|5.56|told and the last thing that can happen
3573.72|5.16|step six is if the wrong prediction was
3576.0|4.039|made and the user fixes it by turning
3578.88|2.04|off the light because they didn't want
3580.039|4.04|the light
3580.92|4.72|on that corrects the data that was
3584.079|3.52|transcribed and the next model which is
3585.64|5.0|trained will be able to avoid that
3587.599|4.921|problem and there's some dialing this in
3590.64|4.32|in terms of the time scales that you
3592.52|4.16|want based on the way humans interact
3594.96|3.359|with the light switch so there's a lot
3596.68|3.6|of development that goes into figuring
3598.319|5.201|out the right way to set this
3600.28|6.519|up the data that you collect from a
3603.52|4.839|process like this how do we organize it
3606.799|4.121|this actually is not transfer learning
3608.359|4.641|so I kind of lied there a little bit
3610.92|4.72|this is strictly language
3613.0|5.2|modeling it's a conversation between the
3615.64|6.04|human and the lamp you say something
3618.2|3.48|lamp says here's what you
3621.88|6.04|want and it's just an extending context
3625.4|6.12|window like you'd see with a decoder
3627.92|6.119|only kind of architecture these days a
3631.52|6.559|chatbot kind of thing a human uh
3634.039|7.361|personal assistant human assistant
3638.079|5.561|dialogue and you might also suspect then
3641.4|3.959|that well couldn't you let the lamp talk
3643.64|3.64|yes you could absolutely let it use
3645.359|4.361|other tokens and that is something which
3647.28|4.64|is on the horizon for us in other words
3649.72|4.879|how to determine once the model is
3651.92|5.04|learned enough and knows when you want
3654.599|5.281|to hear it talk and knows what you want
3656.96|6.639|to hear it say which requires other
3659.88|5.719|smart data collection currently in
3663.599|3.801|development and there's three tags here
3665.599|3.561|if you don't see it although what they
3667.4|5.12|really are tokens since they're
3669.16|6.08|integrated within the language models
3672.52|6.0|vocabulary I want the lamp lit I want
3675.24|6.079|the lamp dark or nothing if no switch is
3678.52|2.799|applied during
3682.599|4.681|transcription so what do the models look
3684.92|4.439|like that go into to a
3687.28|3.839|lamp um they're a little bit smaller
3689.359|5.281|than that micro model in terms of having
3691.119|5.881|a long context window the the block
3694.64|6.04|size they still use these other features
3697.0|5.96|like a radius which help them to do well
3700.68|4.159|with only little data those other
3702.96|5.119|context
3704.839|7.401|models and the embedding size
3708.079|6.361|is around 50 or 10 and something and
3712.24|4.96|this is small enough to fit on a
3714.44|7.52|microprocessor on a c GPU of a
3717.2|4.76|microprocessor including training no GPU
3723.079|4.801|whatsoever and the first time we ever
3725.96|5.839|got the interaction right the right time
3727.88|3.919|scales from no data
3732.64|5.52|whatsoever creating this data and 20
3735.599|4.041|minutes of it was enough and you can see
3738.16|3.36|there's loads of misspellings here
3739.64|4.24|because the transcription is not
3741.52|4.92|required to produce known words known
3743.88|3.84|tokens it's strictly character based so
3746.44|4.0|you can say whatever you want to say you
3747.72|7.8|can whistle and as long as wavec thinks
3750.44|5.08|that's tokens it'll figure out what to
3758.68|5.8|transcribe that's enough 20 minutes of
3761.48|5.16|talking to it to have it know pretty
3764.48|4.359|well when you want the light
3766.64|3.639|on this is what the numbers look like
3768.839|2.801|for that prediction and you see lots of
3770.279|5.201|zeros there but that's because there's
3771.64|5.199|no positive instances yet in the data
3775.48|2.96|until you you flip the switch there's
3776.839|5.361|nothing to
3778.44|5.919|predict once there is enough to predict
3782.2|4.04|we see an immediate jump in the model's
3784.359|6.041|ability to figure out whether lamp
3786.24|8.599|should say on off or
3790.4|8.879|nothing and while we trained this first
3794.839|6.841|model for example in 20 minutes on L
3799.279|3.56|potato which is a really really really
3801.68|2.879|small
3802.839|3.96|microprocessor it's incredibly
3804.559|4.641|frustrating to utilize because the
3806.799|4.48|processing time is a couple seconds and
3809.2|3.48|it feels like it's going somewhere even
3811.279|3.481|though the data is entirely localized
3812.68|4.76|there's no Wi-fi there's no internet
3814.76|5.079|connection um it just takes the model on
3817.44|5.159|this tiny chip a minute not really a
3819.839|4.321|minute like couple seconds to flip the
3822.599|4.48|switch on because it has to transcribe
3824.16|5.36|it interpret it issue the directive ask
3827.079|4.04|the operator to operate it and so part
3829.52|3.72|of what we're doing is figuring out at
3831.119|4.281|what scale of microprocessing do the
3833.24|4.599|models that we're developing really make
3835.4|4.0|a good realtime system that a user can
3837.839|3.28|make use of
3839.4|4.919|well
3841.119|4.96|and as you can see the larger the model
3844.319|5.52|in terms of hyper parameters and so
3846.079|3.76|forth the more performant it
3850.76|6.039|gets so um we see these as potentially
3854.279|6.201|useful in Edge scenarios but not just
3856.799|5.641|for operation for training so go to Home
3860.48|6.24|Depot buy a light switch installed in
3862.44|4.28|your house start talking to it
3866.88|4.239|um but this isn't really the stopping
3869.119|4.561|point that we want to get
3871.119|4.761|to
3873.68|3.8|um we want to eventually get to the
3875.88|2.919|point of talk back we want to treat
3877.48|3.24|these as language models that
3878.799|4.401|essentially have a bit of you inside of
3880.72|7.8|them that you can converse
3883.2|7.04|with and that's important to know when
3888.52|4.68|the model is aware of what you want to
3890.24|4.599|hear said in other words it needs to
3893.2|3.44|know what is a good thing to say back to
3894.839|4.321|what you just said the lamp has never
3896.64|4.399|heard a lamp talk before so there are
3899.16|4.36|challenges to figuring out the lamp's
3901.039|2.481|role in
3903.799|5.681|conversation and choosing a lamp though
3907.599|3.321|is arbitrary we don't have to make it be
3909.48|2.799|a light bulb which goes on and off this
3910.92|3.56|could be a controller for anything which
3912.279|5.881|is a binary
3914.48|5.639|switch and you could imagine like others
3918.16|3.52|are looking at right now there's a lot
3920.119|3.561|of opportunities with predicting the
3921.68|5.0|action on your phone that you want to
3923.68|6.48|take which thing you want to push
3926.68|5.679|and with a system like this micro sizing
3930.16|4.08|on to your cell phone for example
3932.359|3.92|assumes better Hardware than what we're
3934.24|5.28|already using but would be entirely
3936.279|3.241|localized including
3943.079|6.601|training but this is also really just
3946.72|4.44|getting to the point of feasibility it's
3949.68|3.679|not getting to the point of a well
3951.16|5.28|optimized system which we're still
3953.359|4.601|developing there are principle different
3956.44|3.24|modifications that we could make to the
3957.96|4.159|self attention layers which include
3959.68|4.0|traditional self attention parameters
3962.119|4.24|that's just one
3963.68|4.96|example then there are updates to the
3966.359|4.281|very naive scheme that we have for bit
3968.64|3.479|Cipher the vectors that we're using to
3970.64|5.8|initialize our
3972.119|6.321|models and a lot of other minutia that
3976.44|4.679|need to be
3978.44|5.8|approached so this isn't really work
3981.119|5.121|that's done it's a work in progress and
3984.24|4.72|in addition to what I just described
3986.24|4.64|where moving towards larger models and
3988.96|3.92|evaluations that compare better to
3990.88|2.8|Modern systems which will eventually
3992.88|3.32|come
3993.68|5.2|online um will most likely participate
3996.2|5.2|in this year's baby language model
3998.88|4.36|challenge although that challenge
4001.4|3.679|assumes you're working with a standard
4003.24|4.92|architecture which is already developed
4005.079|4.801|for all of the evaluative needs so
4008.16|4.0|there's a lot of work to
4009.88|4.08|do but that's really all I have prepared
4012.16|3.84|for you to discuss today in this
4013.96|4.0|conversation I've gone over a lot of
4016.0|4.279|details and if you'd like to talk about
4017.96|3.8|any of these I'm certainly happy to
4020.279|3.8|questions that you might have as well
4021.76|3.88|and if you have access to the slides
4024.079|4.361|there's some links to the different
4025.64|6.31|papers I've
4028.44|7.639|referenced that's all for today and
4031.95|6.609|[Applause]
4036.079|4.121|thanks hey so thanks Jake uh for the
4038.559|4.04|great talk and now we'll have some time
4040.2|4.24|for questions uh so if anybody here has
4042.599|3.921|any questions uh feel free to raise your
4044.44|4.639|hand and ask otherwise we'll go to some
4046.52|2.559|questions on
4054.88|5.239|slido yeah some folks are asking so
4057.16|5.84|we'll be posting the slides um later but
4060.119|4.96|I've also pasted um these references in
4063.0|6.599|the zoom chat as well as Discord in case
4065.079|4.52|anybody uh wants to uh see
4072.4|4.959|them I was wondering in the plots that
4074.88|5.679|you showed for warm warm start versus
4077.359|5.72|cold start does the cold start use the
4080.559|4.0|modified self attention or the standard
4083.079|5.881|self
4084.559|6.0|attention yeah sure um so the question
4088.96|3.079|was in this picture comparing warm
4090.559|4.201|starts to cold
4092.039|5.081|starts um what self attention was used
4094.76|4.039|here none this is strictly a feed
4097.12|4.48|forward experiment where we take a
4098.799|5.52|single layer and all we do is feed
4101.6|4.679|forward with one hot vectors from some
4104.319|4.561|context window
4106.279|5.801|and concatenate them together and the
4108.88|4.919|general property that you'll see is by
4112.08|4.56|concatenating vectors there's very
4113.799|5.0|little for attention to do normally with
4116.64|4.32|a block you're adding the vectors
4118.799|5.4|together and that superposition of the
4120.96|5.199|dimensions smears them and that's why
4124.199|3.921|self attention is needed in order to
4126.159|4.2|weight that superp position so just the
4128.12|4.639|right ones stick out and it's not
4130.359|4.561|muddled if those vectors are instead
4132.759|3.6|concatenated a waiting of those is
4134.92|5.0|really just appealing to the
4136.359|6.44|sensibilities of the Matrix
4139.92|5.399|above when they're superimposed there's
4142.799|4.841|a lot to work on since you're smearing
4145.319|3.92|separate information together when the
4147.64|4.159|information is already
4149.239|3.6|separated there's not that much reting
4151.799|3.92|can
4152.839|5.88|do and in this case there's absolutely
4155.719|4.681|no reting going on and what I've
4158.719|2.761|described to you is really just
4160.4|4.959|something
4161.48|5.4|that's become very clear from a lot of
4165.359|2.84|small scale experiments in between the
4166.88|3.76|models that we've
4168.199|5.841|developed and moving towards self
4170.64|5.119|attention took additional time and we
4174.04|5.6|didn't have a solution for that layer
4175.759|3.881|yet when this work was
4181.48|5.56|done I had a question in regards to so
4185.359|3.84|you're doing this with like bondage
4187.04|3.639|controllers right what um but you're
4189.199|2.96|doing with like oned controllers right
4190.679|3.401|you're doing training with for oned
4192.159|4.161|controllers so like this could be for
4194.08|3.72|like iot devices right could be um and
4196.32|3.52|you talked about how this also could
4197.8|5.32|work for image data
4199.84|5.359|right yeah um have you conducted any
4203.12|4.2|tests with image data like with these
4205.199|4.161|small models for like iot devices or do
4207.32|3.76|you plan for in the
4209.36|5.4|future
4211.08|5.68|so image data work best on not just
4214.76|3.959|feedforward architectures they have for
4216.76|6.6|example convolutional things bits and
4218.719|6.161|pieces that are useful to them and um
4223.36|3.359|that means if we want to apply some kind
4224.88|2.96|of a warm start for for example a
4226.719|3.401|convolutional layer to create a
4227.84|4.64|performant image classifier or something
4230.12|4.48|that's working with images we'd want to
4232.48|4.84|develop an initialization for that layer
4234.6|4.4|too it has weirder activation functions
4237.32|4.6|which means we need to Branch out from
4239.0|6.76|softmax as an activation function but
4241.92|6.2|surprisingly similar convolution is to a
4245.76|5.2|radial model it's really just saying
4248.12|5.84|what's near where I'm trying to create a
4250.96|4.96|feature so I would say yes it seems like
4253.96|5.36|it's something that we could do but
4255.92|5.48|currently it's in the phase of future
4259.32|6.399|work
4261.4|4.319|that it fits in one bullet
4267.04|4.76|here at the
4269.48|4.239|bottom different layer types need formal
4271.8|4.439|derivation for warm starts so if we
4273.719|4.601|wanted to do this kind of a thing with
4276.239|3.92|uh performant architecture we would be
4278.32|3.359|probably uniforming or randomly
4280.159|3.681|initializing some of those parameters
4281.679|4.201|that we don't have warm starts for yet
4283.84|4.28|and as a result we would re receive a
4285.88|4.359|lot of just sort of like noise in where
4288.12|5.0|things are going and if we started to
4290.239|5.681|utilize the activation functions whether
4293.12|4.4|it's even just logistic activation a
4295.92|3.239|logistic activation is not really
4297.52|3.52|fundamentally different than a softmax
4299.159|3.08|Activation so you might say for example
4301.04|3.84|well why can't you just apply that to
4302.239|5.721|logistic function like a two-dimensional
4304.88|4.56|soft Max and the reason is is because if
4307.96|4.12|we treat it like a standard logistic
4309.44|4.239|then each Dimension is independent each
4312.08|3.88|Dimension is trying to predict the same
4313.679|3.721|thing and there's a lot more questions
4315.96|4.56|about how you can get different
4317.4|5.52|information out of different dimensions
4320.52|4.199|so it's a question that's really worth
4322.92|4.52|spending time on in my opinion
4324.719|4.041|separately and it's not the first
4327.44|3.799|question that makes a lot of what we've
4328.76|2.479|developed
4333.84|5.52|practical on one of the slides we had
4336.159|6.121|the dialogue between the user and the uh
4339.36|7.799|I'm wondering does that imply there is a
4342.28|4.879|speech DET Tex system inside the mic
4347.8|7.359|yeah so uh audio goes in and there's a
4352.12|5.8|process here which accepts that audio
4355.159|5.641|and it utilizes a pre-trained wave to
4357.92|4.319|vet that's really just fitting a need
4360.8|3.879|with a pre-train model that's what we're
4362.239|4.0|doing right now um although
4364.679|5.241|transcription is something that we would
4366.239|5.561|like to move into in our future work for
4369.92|3.48|the purposes of training from scratch
4371.8|3.6|because one of the real benefits of a
4373.4|4.44|system like this is that it doesn't come
4375.4|4.68|with any biases from other people's
4377.84|4.52|data aside from the fact that there's a
4380.08|4.32|pre-trained transcription system which
4382.36|4.48|means that it's pre-trained towards
4384.4|4.12|whatever phonetics were within the
4386.84|5.799|language that was there for pre-training
4388.52|6.96|in the wave Toc algorithm so there is
4392.639|5.361|external you know utility here coming
4395.48|4.759|from a pre-trained model but the text
4398.0|5.44|itself and the language model that we're
4400.239|6.44|presenting is only working from what
4403.44|3.239|gets transcribed
4413.36|3.6|I have a followup on my previous
4414.96|4.96|question you you said that the feed
4416.96|5.56|forward worm start is independent of the
4419.92|5.16|choice of self attention does that mean
4422.52|6.48|that the warm start strategy can be used
4425.08|7.8|for any um Network that uses a fe
4429.0|6.84|forward layer not just plms but any llm
4432.88|6.279|or any other network yeah so that's
4435.84|3.319|going back to the war start
4440.4|5.839|solution here and what it says is that
4443.48|4.52|in terms of any layer beneath if you
4446.239|5.241|assume that those layers parameters are
4448.0|5.88|what they are you're not going to update
4451.48|4.28|them and assuming that you know what the
4453.88|4.08|targets for that layer are which for
4455.76|3.24|Middle layers there's some questions to
4457.96|4.279|be
4459.0|7.44|answered then this initialization will
4462.239|6.48|do better than random for softmax out
4466.44|4.48|that's really important at this stage
4468.719|5.721|that there's a soft Max as a part of the
4470.92|6.96|activation if there's not
4474.44|7.64|then you know more map
4477.88|8.92|basically but the point at which it
4482.08|7.04|becomes clear should that whatever type
4486.8|5.08|of prediction scenario in as long as you
4489.12|7.44|have non- negative
4491.88|6.64|features and a soft Max for activation
4496.56|4.52|like in this case with a single layer or
4498.52|7.36|even two soft Max layers whatever that's
4501.08|6.48|doing on mnist you can get a really good
4505.88|4.2|initialization doesn't have to be
4507.56|2.52|linguistic
4512.0|4.4|data this could be mixed data too you
4514.28|4.439|know you could do like a image caption
4516.4|5.2|generation system that has both features
4518.719|5.041|from images and text and warms them up
4521.6|5.96|with the same solution with entirely
4523.76|3.8|different data in two
4528.44|4.88|places could you point out which part of
4530.84|5.56|the process requires the values to be
4533.32|3.08|non- negative
4538.12|3.48|yeah what happens when you put a
4539.92|5.04|negative in a
4541.6|4.84|logarithm not saying you can't but it's
4544.96|3.48|not going to start making probabilities
4546.44|4.96|for you at the other end of the soft box
4548.44|5.32|anytime fast so you have to start with a
4551.4|4.799|different premise
4553.76|6.0|essentially and and that premise is
4556.199|5.681|something that requires more
4559.76|4.24|derivation you'd want to assure if
4561.88|5.12|you're going to use a logarithm anywhere
4564.0|8.32|or assume that inverse that you're able
4567.0|8.84|to um probably modify every parameter
4572.32|3.52|independently instead of whole rows of
4579.56|5.2|parameters okay get to a couple
4582.4|3.839|questions on slido that folks asked um
4584.76|3.8|the the first is what's the difference
4586.239|5.121|in performance between naive assignment
4588.56|5.28|and optimized or omniscient assignment
4591.36|4.359|for packing tokens into bid vectors and
4593.84|4.16|any experimental
4595.719|4.52|results what's the difference in
4598.0|6.159|performance
4600.239|8.641|between naive assignment and optimized
4604.159|4.721|assignment for packing tokens into bid
4612.56|3.24|vectors um the performance differences
4614.56|4.159|are going to
4615.8|5.76|speed the systems which utilize packing
4618.719|4.801|for contexts have at Great length gone
4621.56|4.24|to make sure that information from
4623.52|4.28|different portions of the context that
4625.8|4.399|have nothing to do with each other don't
4627.8|5.32|bleed information if you're going to
4630.199|4.401|pack them together that creates a lot of
4633.12|2.64|logistical challenges in terms of
4634.6|3.599|defining
4635.76|4.0|models and it's still just doing the
4638.199|3.44|regular self attention thing so it's
4639.76|3.28|quadratic so if you have the same length
4641.639|4.721|of context window it's going to be the
4643.04|6.599|same computational cost
4646.36|6.64|however um if you pack all of your small
4649.639|8.161|documents together they don't need the
4653.0|7.4|whole context window worth of quadratic
4657.8|4.24|comparisons and that's why you pack
4660.4|4.56|something in to the empty end I guess it
4662.04|7.0|should be over here from your
4664.96|6.32|perspective but token or document
4669.04|5.8|packing isn't exactly even though it's
4671.28|5.08|well known as a mechanism to make
4674.84|3.12|training much more efficient in other
4676.36|3.44|words you only need fewer batches if
4677.96|4.48|more documents are packed
4679.8|7.04|together it's not something
4682.44|7.56|which is for example entirely accepted
4686.84|5.16|as a published accepted form of
4690.0|5.32|pre-processing so what I would say is
4692.0|6.96|just document packing is not a correct
4695.32|5.44|model of context it is an efficiency but
4698.96|5.4|requires the same level of quadratic
4700.76|6.879|comparison whereas dynamically batching
4704.36|6.2|and izing a block size that is dynamic
4707.639|4.881|preserves the model of context it does
4710.56|5.0|something that is true to the objective
4712.52|5.719|and unwavering in that and it reduces
4715.56|5.2|the complexity for smaller
4718.239|5.201|documents but a direct comparison of the
4720.76|4.32|two is something I've not done because
4723.44|3.92|um it would require having that Oracle
4725.08|4.52|and utilizing those algorithms and where
4727.36|4.799|are they used they're used with insanely
4729.6|4.32|big models which means we would likewise
4732.159|4.52|have to compare two insanely big models
4733.92|4.12|to create the same of expectation that
4736.679|4.04|people have from
4738.04|4.96|packing so that's in the future great
4740.719|4.561|thanks for your detailed response um we
4743.0|4.199|have a question quickly that's um asking
4745.28|5.32|are there any implementations of safu
4747.199|8.121|available that one could experiment with
4750.6|6.8|um well once we publish there will be
4755.32|4.319|but that requires a lot of work on
4757.4|5.04|developing systems for evaluation since
4759.639|5.201|the evaluation systems rely upon
4762.44|3.52|standardized functions within the
4764.84|3.6|architectures that you're all very
4765.96|4.12|familiar with like gpt2 that are easily
4768.44|3.759|taken for granted even though you do
4770.08|4.4|lots of work in training them you have
4772.199|3.881|to do a lot of work in creating those
4774.48|2.96|functions that meet the needs of the
4776.08|4.4|separate prediction tasks and
4777.44|5.68|fine-tuning that evaluations
4780.48|4.4|perform all right great makes sense I
4783.12|3.96|think I think we're pretty much out of
4784.88|4.6|time so uh thanks thanks uh Jake for the
4787.08|6.559|great talk and um thanks for uh coming
4789.48|4.159|to another lecture all of you