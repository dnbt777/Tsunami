start_time|end_time|text
1.04|3.52| Alright, let's now talk about transfer learning. In
4.56|3.52| particular, we are going to take a look at how we can use a
8.08|4.6| pre trained VGG 16 that has been pre trained on image net, and
12.68|2.84| then fine tune it on a target data set, we are going to work
15.52|4.56| with cipher 10. So in particular, we are going to
20.08|3.96| freeze all the convolutional layers, we assume these are
24.04|4.84| good feature extraction layers. And then we will only train the
28.88|3.36| last fully connected layers. And in particular, we'll also
32.48|4.36| replace the output layer. Because an image net, the output
36.84|4.18| layer has 1000 units, because in this particular case, it was
41.02|4.38| fit to 1000 classes. But yeah, cipher 10 only has 10 classes.
45.4|4.68| So we are also going to have to replace that one. Alright, so
50.08|5.48| let's take a look at the code example. So um, yeah, I actually
55.56|4.2| made two notebooks, like, let's take a look at this one first.
60.12|5.72| So everything you can see here is the same as for the VG 16 I
65.84|3.6| showed you before. So I don't have to discuss any of that in
69.44|5.56| detail again here. So the same things, except it's too much,
75.18|5.52| maybe except for this line, and this line here. So what are
80.7|6.1| those? So those are again, the means and standard deviations
86.8|4.48| for standardizing the inputs. Why am I using these weird
91.28|4.52| numbers and not point five like before. So that is because that
95.8|6.88| was used when they trained or pre trained the model on image
102.68|4.2| net. So we are going to use a model from the that torch vision
106.88|3.92| library or repository that has been pre trained on image net.
110.8|3.12| And they just happen to use these parameters, they derive
113.92|6.08| them from the image net data set. I should say we are going
120.0|4.56| to use the VGG 16 here from this torch vision repository. And
124.56|3.12| there are also other networks, we are just talking about VGG 16
127.68|2.72| because it's familiar. But when you're working on the class
130.4|3.04| projects, also really good networks. I mean, actually, all
133.44|2.36| of them are good. And maybe except for Alex net, it's a
135.8|3.24| little bit dated. But yeah, dense net is a special version
139.04|3.84| of resnet that has each connect each layer connected to each
142.88|3.2| other layer. So it's like, why it's called dense, it's fully
146.08|3.88| connected in terms of the layers, whereas with resnet, we
149.96|3.24| only have some of these residual connections, mobile nets are
153.2|3.24| really cool, because they're very efficient, and also give
156.44|3.24| you very good performance. So I probably wouldn't use version
159.68|3.32| two, if there's already a version three, res next is also
163.0|3.36| like, I think it's more mobile friendly version of residual
166.36|3.4| networks. It's also I think, a little bit faster. White
169.76|2.32| resnet can give you better performance if you have a large
172.08|3.32| data set. Inception is also really good architecture,
175.4|3.24| Google, you probably don't have to use Google net, because
178.64|3.28| that's like an early version of inception. But in any case, so
181.92|2.8| there's a variety of things to use, all of them have been
184.72|4.28| pre trained on image net. And here, they say they derive this
189.0|3.28| mean and standard deviation from image net. And we are going to
192.28|4.12| use the same values so that we make sure that our inputs are on
196.4|5.16| the same scale as theirs in our cipher 10 data set. By the way,
201.64|4.72| I also so sometimes it's also recommended to compute these
206.4|4.12| really from scratch from your data set. That's because it
210.52|3.32| might be that all your images are systematically darker or
213.84|2.8| systematically brighter or things like that, or less or
216.64|3.4| more colorful. And to account for that, it might also be a
220.04|3.36| good idea to derive these parameters from your own data
223.4|3.88| set. So I have showed you this earlier, in a previous video, I
227.28|2.96| actually have done that and implemented that here, where we
230.24|4.6| compute these from our data set for the cipher 10 data set. But
234.84|2.6| you can see, they are essentially the same as for
237.44|4.4| image net. And I try to run the VG 16 with either those are the
241.88|3.28| parameters that they propose on the website. And I didn't find
245.16|3.44| any meaningful difference. It's fine to use either or in a
248.6|2.48| practical application, if they are substantially different, you
251.08|4.72| want to try out both because there can be an argument made
255.88|3.92| for either case. So you can say, you should use these because
259.8|2.68| that's what they used, and just to be consistent. But you can
262.48|3.48| also say, it makes more sense to use your own parameters, because
266.16|4.0| maybe your images have a systematic difference compared
270.16|4.52| to the image net images. Alright, so that was just like
274.68|3.96| a long version, talking about standardization parameters,
279.36|2.64| moving on to the more interesting part, the transfer
282.0|3.6| learning part. So we are now loading this pre trained model.
285.76|4.52| So actually, you can load all the different models in a not
290.32|3.28| pre trained version, if that's useful to you. So you don't have
293.6|4.96| to implement these from scratch, they're already available for
298.56|2.88| you. If you set pre trained to false, it's essentially
301.44|3.2| training them from scratch. So here we are talking about
304.64|2.44| transfer learning. So we are using a pre trained version
307.08|6.04| pre trained on image net. And this is how our VDG 16 looks
313.12|4.6| like when we load it from the repository. So I'm calling
317.72|3.84| model, which will just output the structure of the network. So
321.56|4.58| you can see, there's one part, it's called features here. And
326.14|2.82| this part is really like the convolution layers, like
328.96|3.84| because, like we said earlier, the convolution layers can be
332.8|3.12| understood as automatic feature extraction layers. So this
335.92|4.32| would be the corresponding part. And then here, this would be
340.24|4.48| our classification layer here. So where we have our sequential
344.72|4.48| layer. Alright, so this is how it looks like. So between
349.2|3.4| there's an adaptive average pooling, which is similar to
352.64|2.32| global average pooling that we discussed in the previous
354.96|2.74| videos, that is really just to make the bridge between the
357.7|3.7| last layer in the convolutional part and the first layer in the
361.4|3.4| linear part to make sure that we have this number of features
364.8|4.72| when we have seven times seven times whatever the sizes that
369.52|6.8| comes out of here. Alright, so we said we are only going to
376.32|4.24| train the linear layers. So what we have to do is, so the
380.56|4.36| easiest way I find that we can do that is by freezing the
384.92|3.72| whole model first. So what we do is be iterate over all the
388.64|4.24| parameters in the model, like this, and then we set them to
392.9|3.22| false the requires gradient attribute. And this will
396.12|4.4| essentially freeze the network so you can still run forward and
400.52|3.72| backward, but it will not update the parameters they are now
404.64|5.64| kind of fixed. All right, so this will freeze the model. And
410.28|3.8| then we want to fine tune the last three layers. So if I go
414.08|3.56| back to my visualization, so we are only going to fine tune this
417.64|3.96| last part. So we have to kind of understand a little bit what
421.6|3.2| this last part is. So we know, okay, this is in the classifier
424.8|5.76| here. And there are different layers 0123456. And we have to
431.56|2.6| pay attention to those that have parameters. So for instance,
434.4|3.52| this linear one drop out and redo doesn't have parameters,
438.2|3.56| linear, linear, and linear, these are the ones that we want
441.76|6.84| to modify. So here, I'm setting the one corresponding to one to
448.6|3.72| true. And this one also to true, this is the one corresponding
452.32|3.52| to three. So I'm essentially saying these are now trainable
455.84|4.92| again. So we want to train those. And we have to replace
460.8|4.92| this one entirely, because the output number of classes is 1000.
465.72|3.28| But in cipher 10, we only have 10. So here, I'm providing my
469.0|5.4| own linear layer. So I'm just using the same number of input
474.4|3.76| features 4096. But I'm just changing the number of output
478.16|5.68| features to 10. And then it's training like usual. So I'm
483.84|3.0| training it here, nothing new, it's exactly what we've done
486.84|2.68| before. But what's interesting is now you can see it already
489.52|2.96| starts with a pretty good accuracy. So if I compared to
492.48|5.8| our previous VGG 16, this is our own implementation, can see it
498.28|5.08| starts with 3550 53. So here, this is already more powerful in
503.36|3.36| that way. It's already kind of warmed up in a way if you want,
506.92|4.88| because it's pre trained. And then it's training, but I found
511.8|3.6| it doesn't give good performance here. So you can see it's only
515.4|3.94| 77%. It's not great. So what's going on here? So the one
519.34|3.42| explanation could be that image net is much bigger. And they
522.76|6.6| also say that here, they expect the height and width to be at
529.36|6.36| least 224. So usually networks are somewhat agnostic to the
535.72|4.8| exact size, if you use adaptive average pooling, like they have
540.52|7.52| used here, because it will make sure that whatever is before
548.04|4.56| here will have the output size of seven, seven. So and then it
552.6|3.44| will make that this will have the right dimension here,
556.28|3.16| because this is guaranteed to be seven, seven. But the problem
559.44|4.72| is, um, these layers before they have assumed that the images
564.16|2.96| have a certain size and the objects have a certain size. So
567.12|2.96| they have been really trained maybe on larger images. So if
570.08|2.6| the images are too small, the other network performance might
572.68|4.36| not be great. So what I did is I had a second implementation
577.04|6.12| here, where I just increased the size of the images to 224. I
583.16|3.12| mean, it's not ideal, because cipher 10 is a very small data
586.28|3.48| set, and it will be very, very pixelated. But yeah, just for
590.32|3.6| trying it out. So I was doing exactly the same thing, except
593.92|2.8| for the larger images. And you can see, it has already better
596.72|7.68| performance, it goes even up to 84.9%. So in that way, yeah,
604.4|3.08| there's actually a pretty good performance, given that this is
607.48|3.46| a pre trained network that we just fine tuned a little bit. So
610.94|4.74| we are only training the last three layers. Yeah, but also
615.68|3.96| because images are so large, it takes a long time now. Alright,
619.64|3.36| so what you can see also on, let's take a look at the small
623.0|7.2| one again, I was training it for 50 epochs, it took 38 minutes.
630.2|5.04| And for the version that we trained from scratch, it was 90
635.24|2.92| minutes. So it's probably because, first of all, it's
638.16|1.92| probably a little bit more efficient implementation, but
640.08|3.6| it's mostly because we froze the convolution layers. So we are
643.68|2.76| only training the fully connected layers here. So that
646.44|4.48| also saves a lot of time, one hour, to be exact. So yeah, so
650.92|3.48| this is how you can do transfer learning. But yeah, also, I like
654.4|4.52| I showed you before, how many layers to train, it really
658.92|3.28| it really depends. So based on this paper, they found training
663.64|3.12| three fully connected layers results on the best performance,
666.76|4.04| but it really varies from case to case, sometimes, it might be
670.8|2.96| better to only train the last layer. Sometimes it might be
673.76|4.3| better to fine tune all layers. It's really depending on on the
678.06|2.82| particular case. But yeah, I hope this was useful. Now you
680.92|3.32| know how to do transfer learning. And I think this is
684.24|3.4| also the last video for this lecture on convolution networks.
687.64|4.08| Next, we will start a completely new topic talking about
691.72|27.0| recurrent neural networks working with text data.