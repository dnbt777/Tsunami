start_time|end_time|text
2.0|3.76| Yeah, in the previous videos, we discussed how batch norm works.
5.92|4.04| Let's now discuss why batch norm works. I can't give you the
9.96|3.6| definitive answer here. But at least I pull together some
13.6|4.96| theories and some practical or empirical evidence to kind of
18.56|3.36| support certain claims. So I think that might be interesting
21.92|3.96| if you are really interested in studying batch norm. So
25.88|4.16| originally, so the paper that proposed batch norm mentioned
30.08|3.84| this internal covariate shift. So the authors of the original
33.92|3.36| batch norm paper said that, um, yeah, batch normalization
37.28|3.84| accelerates training by reducing this internal covariate shift.
41.56|3.0| What is this internal covariate shift? What does it mean? So
44.56|4.56| it's essentially saying that the layer in input distribution
49.12|3.68| changes. So this shift, there's a shift in the distribution of
52.8|3.12| these inputs to a given layer. So it's essentially a feature
55.92|4.52| shift. So the features, if you think of the inputs to a given
60.44|4.04| layer as the features, the distribution of these features
64.52|4.12| shift over time during the course of training. So that's
68.64|4.64| one theory that happens during a regular training and batch norm
73.48|4.48| helps preventing it by renormalizing these inputs. However,
77.96|3.72| there's no guarantee for that. And there's also no strong
81.68|3.72| evidence for this theory. I will show you a paper that kind of
85.52|5.0| debunks this theory. Another theory that's like more what I'm
90.52|4.08| kind of sometimes speculating is that your batch norm provides
94.6|4.16| additional parameters that might help. However, I think this is
98.76|4.0| also maybe not a reasonable theory because it is something
102.92|4.12| you can simply test by inserting or making the previous layer a
107.04|3.76| little bit larger adding some parameters to it. And I don't
110.8|3.16| think I think at least someone would have tested that already.
113.96|4.6| So that's probably not the case. Another idea is maybe that it
118.56|3.12| makes these layers a little bit more independent of each other.
121.88|4.0| So for instance, if you think about one layer producing some
125.92|4.88| nonsense outputs or something, yeah, it's very sweet. Let's say
130.8|4.06| you have a late layer in the network. They are very close to
134.86|4.2| the output. It kind of depends on the previous layers of
139.06|3.02| giving it good input. So if you screw up one of the early
142.08|3.88| layers, well, then the output layer or all the other layers
145.96|3.24| are really also depending on that. So you're kind of it's
149.2|3.04| like a domino effect you have like if you screw up one layer,
152.52|2.68| you screw up the other layers too. And the same thing can
155.2|3.68| happen during both the forward and the backward pass, right,
158.88|4.8| because the forward pass, you go from the left to the right. And
163.68|2.68| in the backward pass, you go from the right to the left. So
166.36|3.16| that way, if something is wrong in one given layer, it will
169.52|3.92| affect all the other layers. And maybe with this batch norm, this
173.44|3.64| kind of helps decoupling the layers a little bit in terms of
177.08|3.4| if one layer screws up the other layers a little bit more robust
180.48|5.64| to that. But it's also just one of the many theories. So here,
186.12|4.04| I found a paper from 2019. I mean, it might already be
190.16|3.32| outdated. I don't know. But I found it interesting. So I
193.48|4.08| included it here. So this paper is called How does batch
197.56|5.28| normalization help optimization. So here, they in the abstract
202.84|3.96| basically state that batch norm is good for stabilizing the
206.8|4.08| training, but also the exact reasons are still poorly
210.96|3.88| understood. And then they mention the internal covariate
214.84|5.12| shift as one of the potential reasons. But they demonstrate
219.96|4.8| that such a distributional shift, or distributional
224.76|3.68| stability of the layers has little to do with the success of
228.44|2.5| batch norm. So they are essentially saying, the
230.94|2.94| covariate shift or preventing covariate shift is not really
233.88|5.0| why batch norm works so well. Yeah, instead, what they find is
238.88|5.12| that it makes the optimization landscape significantly
244.0|3.08| smoother, so essentially making or creating a smoother loss
247.08|5.72| surface. And this helps them with making the training more
252.8|5.0| stable. And it allows us to have larger learning rates and have
257.8|2.84| faster training because we have more stable behavior of the
260.64|4.16| gradients. So I took some visualizations from the paper
264.8|6.6| shown here. I don't want to go into too much detail about this
271.4|2.88| paper. I mean, if you're interested, you're very welcome
274.28|5.32| to read it. So here are only a few takeaways. So what they say
279.6|3.64| is essentially that batch norm enables faster convergence by
283.24|4.28| allowing larger learning rates, I found that interesting. So
287.96|5.2| let's focus on the left plot first. That's the training
293.16|6.28| accuracy here. And this is the number of steps. So instead of
299.44|2.88| epochs, they have steps here. So that's the steps, you can think
302.32|3.92| of it as iterations or mini batch updates, doesn't really
306.24|3.6| matter whether we have epochs here or mini batches plotted, it
309.84|3.16| really just represents the training, the course of the
313.0|5.64| training. So we have 15,000 updates. And you can see there
318.64|7.56| are four graphs. So the red ones are a standard network with
326.2|4.32| learning rate point one and point five. And just looking,
330.52|3.48| let's use the red for this one. So just looking at this red
334.0|5.2| curve here, you can see the point one trains relatively
339.2|3.32| well, it reaches 100% at some point, however, the large one,
342.52|4.64| the point five doesn't train so well. So it doesn't. So the
347.16|4.48| learning rate is essentially too large. So what we have then is
352.04|4.84| the same point one and point five now with batch norm. Now, if
356.88|7.96| you look at it, the one with point one trains actually
364.84|5.96| faster, also with point five. It also trains at all. I mean, the
370.8|3.76| other one with point five, when we had the standard one, it fell
374.56|3.76| apart here, right. So batch norm essentially allows us to also
378.32|2.68| have larger learning rates. In this case, the larger learning
381.0|4.72| rate is not better than the point one learning rate, but it
385.72|4.72| is stable, it is training. What the interesting takeaway here
390.44|5.56| is, though, is that overall, the training with batch norm is
396.0|4.6| faster. So even though we reach the same performance in the end
400.64|3.92| and the training set, what is nice here is that batch norm
404.6|3.48| trains faster. Now on the right hand side, that's what we really
408.08|3.04| care about. That's the test accuracy. How does the test
411.12|3.12| accuracy look like? So here, I assume they are testing or they
414.24|4.16| using the same test set for so they train the model. And then
418.4|4.88| they use the same test set to make this plot where this is
423.28|6.16| really like the training steps here. So yeah, what we can see
429.44|4.76| here is during training. So first, also, again, with batch
434.2|6.44| norm, we see that the accuracy increases faster. In the end, I
440.64|2.96| would say there's little difference between the red and
443.6|2.36| the blue one, there's a slight difference. So you can say maybe
446.12|3.88| batch norm performs better. And you can see also batch norm is
450.02|5.98| stable with a point five learning rate. I wouldn't say I
456.0|4.24| mean, the, I wouldn't say the training is faster or
460.24|3.28| convergence is faster, because it allows us larger learning
463.52|2.24| rates, because we can see the smaller learning rate still
465.76|4.76| works better. But what I would say is it's making our training
470.52|4.28| more robust. So it's maybe requiring less time to find good
474.8|3.96| hyper parameter settings to get good results, which is kind of
478.76|3.64| nice. So if it just stabilizes training, this is something I
482.4|3.04| would always want to do, right? Why would we not want to batch
485.44|6.2| norm, then? Alright, so next day looked also into this covariate
491.64|3.66| shift here. Let me take a look at this figure to refresh my
495.3|0.7| memory here.
496.0|4.84| Yes, so what they are showing here is again, training, the
500.84|4.4| cause of the training and the training set accuracy. And on
505.24|4.32| the right hand side, these are the distributions of the
509.56|4.12| activations in the different layers. So they look at layer
513.68|5.04| two, layer nine, and layer 13 of a deep neural network, a VGG
518.72|3.36| network, we will talk about VGG in the convolutional network
522.08|4.72| lecture. So what we can see is for standard, that the
526.8|6.68| distributions across layers are slightly different. So I can't
533.48|4.08| really read these numbers here, it's very small. But these
538.04|5.92| should be ordered by increasing size. So I think this
543.96|4.88| corresponds here to the, to the steps. So the steps that we see
548.84|5.4| here, so this at the bottom is the later training and each, you
554.24|3.96| can think of each bell curve or each histogram here, as the
558.2|2.6| activation, the distribution of the activations at that given
560.8|4.44| step. So what you can see is they are all kind of in line
565.24|3.76| here. So there's not much distributional shift, I would
569.0|4.52| say here, maybe there's some some shift, you can see, it's
573.52|3.88| maybe I'm not sure it's hard to see that the distributional
577.4|4.44| shift here, it's hard to see that the, the mean of the
581.84|3.0| distribution during the course of the training during the steps
585.08|3.24| shifts a little bit to the left, for instance, we can also see
588.32|3.32| this a little bit here, right. So in that way, this one is the
591.64|4.68| one with batch norm, it's not, I would say that much different.
597.24|4.2| Now what they did is they produced batch norm variant by
601.44|4.4| adding noise to it. So here, you can clearly see on that the
605.84|3.92| distribution shifts. So you can see, here, this peak is very
609.76|3.16| different from this peak. So you can see a huge shift of the
612.92|3.32| distribution. So here, this one, however, when they then do the
616.24|3.64| training. So you can see here on the left hand side, when they
619.88|5.36| do the training, both the standard, sorry, the batch norm
625.24|4.84| and the noisy batch norm both perform really well. So even
630.08|3.8| though there is covariate shift, or there is no covariate shift,
633.88|4.32| doesn't seem like it affects the performance that much. So even
638.2|5.2| let's say, if batch norm fixes this covariate shift, I they
643.4|3.4| think it's not really the explanation why it results in
646.8|2.68| such a good performance, because then you would expect for this
649.48|2.76| case here, a very poor performance, but that's not the
652.24|2.96| case. So that's just one observation from this paper
655.2|5.62| here. Okay, now let me list a few more papers, I don't want to
660.82|3.9| go into these in too much detail. But if you are interested,
664.72|3.8| you are encouraged to read more. It's of course not required for
668.52|2.72| this class. But yeah, if you're really interested in batch norm,
671.92|5.34| doesn't hurt to read those. Okay, so just in chronological
677.26|3.46| order, there's the theory that it reduces covariate shift. So
680.72|3.48| this is the original paper, then we just saw the paper that says
684.2|4.04| that it makes the optimization landscape smoother. There's
688.24|3.76| another paper I found where they say that the reason why batch
692.0|3.08| norm works so well is that batch normalization implicitly
695.08|6.68| discourages single direction reliance. Then another paper
701.76|4.12| from 2018 also says that it acts as an implicit regularizer. And
705.88|4.12| that is then helping with a generalization accuracy. And
710.28|3.04| another paper was not so positive about batch norm, it
713.32|4.28| says essentially that batch norm causes exploding gradients. So
717.6|3.4| um, yeah, we will actually talk about these skip connections in
721.0|4.48| a future lecture too, by the way. Yeah, let's get now to the
725.48|3.8| practical advice section of this video. So there are also slight
729.32|4.48| modifications of batch norm. So one is putting batch norm before
733.8|4.24| the activation. So this is the original version of batch norm
738.04|2.76| that was discussed on the previous slides of previous
740.8|4.4| video, and also presented in the original paper. So here, the
745.2|4.04| workflow is as follows. First, we compute the net inputs. And
749.24|2.8| then we apply batch norm, then we apply the activation
752.04|3.88| function, and then we compute the next layer inputs. However,
755.92|4.08| we can also put batch norm after the activation. So what we do is
760.0|4.06| we essentially flip the order here, we first apply the
764.06|4.22| activation function and then use batch norm. So we can see that
768.28|3.16| inputs applying activation function batch norm, and then
771.44|6.04| computing the next layer inputs. This could make more sense in
777.48|4.28| practice, if you think about it as, let's say batch for
781.76|3.56| simplification, let's say you use batch norm and batch norm
785.32|5.44| learns to standardize your feature activation distribution,
790.76|5.12| let's say at mean zero, right, so you have no zero mean
796.44|4.58| features, but then you apply the activation function. Let's say
801.02|2.42| on the left hand side, we apply the activation function, then
804.4|3.3| what kind of change this distribution before it gets to
807.7|4.62| the next layer, right? Because let's say we have mean zero for
812.32|3.88| a given feature. And if you use, for example, a logistic sigmoid
816.2|5.48| function, then the mean will change from zero to point five,
821.68|3.76| right. So then next layer receives inputs that are at
825.44|4.32| point centered at point five and not centered at zero, right. So
829.76|6.16| in that way, the sigmoid would remove also the negative values.
836.2|4.32| So in that way, maybe it makes more sense to put batch norm
840.6|4.64| after the activation. Personally, I haven't found any
845.8|3.92| big difference. I haven't benchmarked this extensively. I
849.88|3.68| tried it here and there, I didn't notice a big difference. I
853.6|3.88| did some searching online, there was a repository that I found
857.48|4.04| where they did some experiment, or experiments, multiple ones,
861.84|5.04| and found that before and after did make or have a difference.
866.88|2.84| And they found, for instance, that putting batch norm after
869.72|7.16| the activation, indeed, resulted in a, in a better accuracy. So,
877.28|3.28| I mean, why not, it may make sense just to put it always
880.56|6.04| after the activation and not worry about it. All right, some
886.6|4.16| more practical consideration. So batch norm, I should also say,
891.08|5.12| only works really well if we have reasonable batch sizes. So
896.2|3.64| if we make the batch sizes too small, then batch norm doesn't
899.84|4.12| work very well anymore. So that might be explained by the fact
903.96|3.76| that these mean and standard deviation statistics become very
908.16|4.72| noisy, if we have small batch sizes, right. So here, I found a
912.88|3.96| paper, this is actually a paper about an alternative to batch
916.84|2.48| norm, it's more for convolution networks, but it's called a
919.36|3.36| group norm, we can revisit this maybe later, we don't have to
922.72|3.0| talk about group norm here. It's really just something that
925.72|2.28| doesn't work for multi layer perceptrons, it's only for
928.04|3.24| convolution networks. But what I found interesting was here, this
931.56|4.2| figure, ignoring the group norm plot here, what you can see is
935.76|3.28| they did an experiment with different batch sizes. And here's
939.04|5.04| the percent error. And they have it here at 32. Unfortunately,
944.08|4.64| they are not showing larger ones. But you can see 16 and 32
948.72|4.0| both work. But if you make it smaller, so if you make the
952.72|3.4| batch size smaller, like eight, four or two, then batch norm
956.12|3.4| becomes really bad. So you get a very large error here. So just a
959.52|4.24| practical consideration. If you use batch norm, it's highly
963.76|3.72| recommended to use a batch size greater than 16. In practice, I
967.48|7.56| would even say bigger than 632, or even 64. So here's some
975.04|3.44| further reading resources, if the previous ones were not
978.48|3.88| enough, if you are interested. Yeah, like I said, we can't
982.36|2.96| cover everything in this course. This is an introductory course.
985.32|2.92| So I have to be very selective with topics. But if you're
988.24|4.4| interested, some additional papers that you might find
992.64|2.04| interesting, maybe in the context of your project, you
994.68|3.52| can try one or the other paper and see whether that helps. So
998.2|3.8| one is conditional batch norm, which is essentially including
1002.0|2.96| class information. So having different parameters for the
1004.96|4.48| different classes in the data set, which kind of makes sense.
1010.88|3.08| Yeah, then there's a paper on measuring the effects of data
1013.96|5.28| parallelism on neural network training. So here, what I just
1019.24|2.8| found interesting is it's not directly related to batch norm,
1022.04|4.16| but it's related to the previous slide regarding the batch sizes.
1027.64|4.84| So sometimes in practice, people say, don't use a large batch
1032.48|6.4| size. So let's go back. So there are two theories, one theory or
1038.88|3.56| one, not theory, but recommendation is to use large
1042.44|4.52| batch sizes, because large batch sizes help you to utilize the
1046.96|3.44| GPU better, because you have larger matrix multiplications,
1050.4|2.96| and then the training will be faster. And it's, it's better.
1053.64|3.48| Some people say, choosing smaller batch sizes is better
1057.12|3.48| because it helps with generalization, because then maybe
1060.6|5.72| the loss gets, yeah, we less likely to get trapped in local
1066.32|4.04| minima on the loss surface. However, yeah, this is very
1070.36|2.72| controversial. Here was just a paper I found interesting where
1073.08|2.72| they say basically, they don't find any evidence that large
1075.8|6.96| batch sizes degrade the performance. Um, yeah, and then
1083.76|5.52| another one here is an alternative to batch
1089.28|3.04| normalization that might I have not tried it myself, but it's
1092.32|3.12| only interesting. It just came out this year, I saw that this
1095.44|3.52| year, I haven't even read this yet, because I have such a huge
1099.04|2.68| list of papers I find interesting, and I want to read,
1101.72|4.12| but there's only so many hours in the day. But that sounded
1105.92|3.08| pretty appealing. So they say that they present a plug in
1109.0|1.96| replacement for batch normalization called
1110.96|3.16| exponential moving average normalization, which improves
1114.12|4.52| the performance of existing student teacher based self and
1118.64|3.0| semi supervised learning techniques. I'm not sure whether
1121.64|3.44| it applies also to regular networks, but could be
1125.08|3.6| worthwhile looking into. So I just had that on my reading
1128.68|5.0| list. And I thought I just included here. And the last one
1133.68|7.6| I have here is it's actually without batch normalization. So
1141.32|3.4| here is usually people say batch normalization is really
1144.72|3.08| important to reach good performance. And here in this
1147.8|4.04| recent paper also from 2021, they demonstrated that also you
1151.84|2.72| can actually get good performance without batch
1154.56|5.28| normalization. So they mentioned that previous work was already
1160.24|3.08| successful in demonstrating that you can train without
1163.32|3.12| batch normalization, get good performance, but these models do
1166.44|2.84| not match the test accuracy of the best normalized networks,
1169.58|4.58| and are often unstable for large learning rates, or strong data
1174.16|2.88| augmentation. So while it is possible to get good
1177.04|3.4| performance, it's not as good as with batch normalization, and
1180.44|4.64| the models are more unstable. But in this work, they Yeah, they
1185.08|3.56| have an alternative to make them stable. So they call it adaptive
1188.64|4.32| gradient clipping. So gradient clipping is a technique that if
1192.96|4.28| you have a very large gradient, you clip it at a certain value
1197.24|3.72| so that it doesn't cause problems like exploding gradient
1200.96|3.32| problems. And they say by having adaptive and adaptive version of
1204.28|3.4| that gradient clipping, they can train a network without batch
1207.68|3.12| normalization and get a good performance. But yeah, again,
1210.8|5.04| this is a very recent paper. Time has to tell whether this is
1216.04|4.28| really also working well across other architectures. But that
1220.32|3.0| might be also something cool to look into maybe in the context
1223.32|3.44| of your class project. So again, I'm just throwing out some ideas
1226.76|3.36| or interesting reading material here, you don't have to read
1230.12|3.28| that, of course, I'm just sharing it because it sounds
1233.4|6.24| interesting. Alright, so one last thing I mentioned here on
1240.04|3.56| these batch sizes, and you may have noticed, they are all
1243.6|4.86| powers of two, right, two to the power of 23456, and so forth. So
1248.46|4.02| why is that? Why do people usually choose batch sizes in
1252.48|3.84| powers of two. So that has something to do with how GPUs
1256.32|4.2| work as this. Just briefly, there's this paradigm, single
1260.52|4.88| instruction, multiple data. So it's like, you have multiple
1265.4|3.48| data points, let's say multiple values in a vector, and you have
1268.88|2.68| a single instruction, let's say, like addition, and you can
1271.74|3.34| distribute this instruction to apply to everything in a vector.
1275.2|4.92| So that's like, how, on a certain level, parallelism works
1280.12|8.0| on a CPU and GPU. So and on GPUs, the number of processing
1288.12|4.32| cores is usually a power of two, that's just how I don't know the
1292.44|5.8| chip design works. Now, you can take that and take it or make it
1298.24|4.88| an advantage by choosing a batch size that is also a power of two,
1303.12|4.84| because then you can get better balance out how these cores are
1307.96|5.28| used. For instance, if you have 32 columns in a matrix, you can
1313.92|2.88| so let's say you have your design matrix, you would do a
1316.8|3.12| transpose on this matrix, and then these columns, you can map
1319.92|3.64| them to dot products to each of the processing core. So if you
1323.56|3.76| have 16 processing cores, for instance, you can run to dot
1327.84|6.24| products on these 16 cores, right. So if you have only 31
1334.08|4.84| columns, then one core would be finished faster, but it has to
1338.92|3.16| wait until the other ones finish anyway, so you don't fully
1342.08|5.6| utilize your CPU GPU. So in this case, it's just so that the GPU
1347.68|4.8| is better utilized, people prefer these powers of two when
1352.52|4.48| you're choosing batch sizes. But yeah, this is also anecdotal,
1357.2|3.88| you don't have to of course, choose batch sizes that are
1361.08|3.76| powers of two is just, you know what it is, it's actually also
1364.84|3.28| making life simpler, because there are so many hyper
1368.12|4.68| parameters to tune in to consider. And if you know, also
1372.8|4.72| would consider values between values, powers of two, then you
1377.52|2.16| would even have more hyper parameters to consider, right.
1379.68|3.28| So if you say, I only tune powers of two, so you have 32
1382.96|5.88| batch size 64128, and so forth, then this is less than saying I
1388.84|6.12| will consider 2530 3540, and so forth, right. So in this way,
1394.96|3.24| it's also one way to keep things simpler for hyper parameter
1398.2|3.64| tuning. And yeah, of course, it utilizes the CPU and GPU
1401.84|3.8| better. But in practice, it doesn't make such a huge
1405.64|4.28| difference. It's not like you get any significant speed up
1409.92|4.76| through that. Okay, so that was enough about batch norm. Let's
1414.68|14.0| now talk also about weight initialization.