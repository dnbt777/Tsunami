start_time|end_time|text
0.68|4.16| Yeah, before we get to the topic of auto encoders, let us briefly
4.84|4.28| talk about dimensionality reduction. So dimensionality
9.12|4.48| reduction is a broad term for describing the reduction of the
13.6|3.84| number of features in a data set. So one sub topic of
17.44|6.96| dimensionality reduction would be feature selection. So if you
24.4|3.4| have a data set with a large number of features, you can
27.8|2.78| select a subset of these features, that would be feature
30.58|9.5| selection. And there is also feature extraction. So the
40.08|2.52| difference between feature selection and feature
42.6|4.72| extraction is that in feature extraction, we don't necessarily
47.32|3.72| keep original features. So usually feature extraction would
51.04|3.14| be a combination of the features, some, for instance,
54.18|3.38| linear or nonlinear transformation. And yeah, we
57.56|3.16| will, I will show you an example of that in this video here. And
60.72|3.92| this is also the concept that underlies auto encoders. So
64.64|3.2| auto encoders can kind of be thought of as feature
67.84|5.92| extraction algorithms. So auto encoders are also the regular
73.76|3.48| auto encoders, at least are also falling under the umbrella of
77.32|3.2| unsupervised learning. So you have heard about unsupervised
80.52|3.4| learning before long time ago, that was probably the first
83.92|3.16| video of the semester, where we talked about the three broad
87.08|3.08| categories of machine learning. The first category was
90.16|3.32| supervised learning. The other one was reinforcement learning.
93.76|3.88| And yeah, the one category I'm talking about here is unsupervised
97.64|3.04| learning. So unsupervised learning, like the name
100.68|4.1| suggests, it's supervised learning, but without labels, so
104.78|4.06| it's unsupervised. So we are only using the features, not the
108.84|3.48| labels, we are ignoring the target variable here. So there
112.32|2.96| are problems where we simply don't have a target variable.
115.6|3.64| Sometimes we may have a target variable, but we may decide not
119.24|3.1| to use it. So there are different types of applications
122.34|3.14| and goals when we talk about unsupervised learning. So for
125.48|2.88| instance, one goal could be finding a hidden structure in
128.36|5.76| the data, or compressing data, let's say for storage needs, or
134.16|3.36| also, some machine learning algorithms are very susceptible
137.72|2.72| to let's say, the curse of dimensionality. So in that way,
140.44|3.04| we can just reduce the features, the number of features to
143.48|4.76| improve the performance. One would be clustering. So that is
148.24|3.64| like grouping similar types of objects, it's essentially very
151.88|4.16| similar to this point, retrieving similar objects. So
156.2|2.96| if you have two images, it would be very hard to, let's say,
159.16|3.84| compare the similarity between, let's say, two people, if you
163.0|5.48| have a photograph of a person, another photograph of that
168.48|2.68| person, and there's, let's say, a different background and
171.16|2.88| different types of things, it would be very hard to do a
174.04|3.44| pairwise comparison of all pixels to determine whether in
177.48|2.84| these two pictures, it's the same person or not. But what we
180.32|3.24| could do is we could extract a smaller dimensional feature
183.56|5.84| vector for both images, and then compare these feature vectors,
189.76|4.48| where we assume that whatever method we use to construct this
194.24|3.88| feature vector has only focused on the essential information
198.12|3.76| like the face images, or the faces in the image, and not the
201.88|5.18| background, for instance. Another goal of feature
207.08|4.12| extraction could be exploratory data analysis, kind of related
211.2|3.56| to finding hidden structure in the data, where, for example,
215.0|4.12| you want to plot a data set that is high dimensional. So and
219.12|3.36| humans, yeah, we can't really visualize more than three
222.48|5.0| dimensions in a scatterplot, for example. So you could think of
227.48|3.08| an application of taking a high dimensional data set, doing
230.56|4.12| feature extraction into like two or three dimensions, and then
234.68|6.28| plotting those. And finally, one big example would be generating
240.98|4.5| new examples. So we can somehow try to learn the data set
245.48|3.56| distribution. And then we could sample from this distribution to
249.04|3.92| generate new data. And this will be the topic of next lecture
252.96|4.52| when we talk about variational auto encoders. I will start by
257.48|3.16| showing you an example already today where we sample new data.
261.08|4.8| But here, this way would not be ideal, the better way would be
265.88|2.84| then in the next lecture, the variational auto encoders.
269.32|3.92| Alright, but a long story short, let me continue before we talk
273.24|2.84| about auto encoders with an example of dimensionality
276.08|4.04| reduction. And I think many of you have already heard about
280.12|5.48| this, it's called principal component analysis. So we won't
285.6|3.8| go into too much detail about principal component analysis in
289.4|3.6| this class here, because it's not a deep learning topic. But
293.32|3.48| just on a big picture, view here, what's going on in
296.8|3.36| principal component analysis is that we are essentially finding
300.16|3.12| the directions of maximum variance. So that would be the
303.28|3.88| first step. So if you have a data set that like, like shown
307.16|4.24| here, where these circles represent your data points, you
311.4|7.12| have two feature axes x one and x two. And here, these PC one and
318.52|4.54| PC two represent your principal components. So these are the
323.06|7.58| principal components. And they are essentially, if you think of
330.64|3.32| the data set here, as a matrix as a two dimensional matrix,
333.96|5.4| these essentially represent the eigenvectors of this matrix. So
339.4|2.96| PC one is the eigenvector associated with the largest
342.36|3.08| eigenvalue. And PC two is the eigenvector associated with the
345.44|3.88| second largest eigenvalue. So these are giving you essentially
349.32|3.0| the directions of the maximum variance. So where the data is
352.32|6.72| most spread out. So here, we are assuming in this dimension in
359.04|4.12| this axis, the data is most spread out. And then this one is
363.16|4.6| the PC two is the one where it's on the second most spread out.
369.96|4.88| Alright, um, so then once we have found these principal
374.84|4.08| components, these directions of maximum variance, so we are then
379.04|5.96| rotating. So you can show it was cut off here, x one, x two,
385.0|5.52| this is our original feature space, x one and x two are our
390.52|4.76| original features. And here, now you can see I rotated this, so I
395.28|3.6| rotated this to the right, and I get two new feature axes, one is
398.88|3.72| this PC two, and one is this PC one, these are my new feature
402.6|3.8| axes. So I'm aligning my data set in this new feature axis,
406.4|2.8| it's essentially like a linear transformation, can think of it
409.2|6.04| essentially as a linear transformation. And then I'm
415.28|4.84| considering if I want to do dimensionality reduction, I can
420.12|4.12| consider only the direction with a maximum variance, and then
424.52|4.24| disregard the other one. So here, I would reduce my data set
428.76|3.64| from two into one dimension. So for instance, I would consider
432.4|3.28| this first eigenvector, and just ignore the second one. And then
437.0|3.32| what happens is, so yes, squish. So if you remove the PC two
440.32|2.36| dimension, you're squishing the data. So you can think of it,
443.04|5.16| just squishing everything down into one dimension here. Right,
448.2|2.76| and then this is how it would look like, if I would project
450.96|4.44| this data only onto one dimension. And this is the
455.4|4.16| principal component where the variance is most spread. So if
459.56|4.24| you would do the same thing with PC two, so this would be my PC.
465.76|5.4| Two, so you would then see that the data, so in this direction
471.36|2.56| would be less spread, so it would be more like somewhere
473.92|6.68| here in the center. So many would be overlapping. So this is
480.6|3.04| just a big picture concept. Of course, it's kind of boring,
483.64|4.16| like going from 2d to 1d. In real world case, we would have
487.8|3.16| maybe hundreds or 1000s of features and reduce that to a
490.96|4.32| smaller dimensional space. So how many principal components
495.32|3.36| should we keep? This is a topic where we would look at the
498.68|5.2| cumulative variance retained, or captured by the principal
503.88|3.96| components. And this is really a topic kind of beyond this class,
507.84|2.48| because it's not really deep learning. I just wanted to show
510.32|4.72| you a classic dimensionality reduction technique. And in
515.04|4.72| fact, auto encoders do actually something similar. So here,
520.28|3.44| there's one thing I haven't mentioned yet. There's something
523.72|11.2| where we have an orthogonality constraint. Auto encoders do
534.92|3.04| essentially the same thing, they will give you these types of
538.28|3.96| what kind of principal components. However, auto
542.24|3.36| encoders don't have this orthogonality constraint, at
545.6|5.28| least not explicitly. But except that auto encoder with a linear
550.88|3.0| activation function would be essentially like a principal
553.88|2.88| component analysis. But of course, in the context of deep
556.76|3.64| learning, we are talking also about nonlinear activation
560.4|2.72| function. So it's the auto encoder we will see in the next
563.84|3.64| video will actually be a little bit fancier than this principal
567.48|4.52| component analysis. But yeah, this was just a short overview
572.0|4.56| of one classic dimensionality reduction technique. In the next
576.56|4.76| video, I will show you actually how the auto encoder looks like.