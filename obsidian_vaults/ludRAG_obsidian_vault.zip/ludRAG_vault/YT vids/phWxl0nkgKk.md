start_time|end_time|text
5.7|3.42|spend sometimes like two months training
7.919|1.861|the Bots
9.12|4.2|um
9.78|6.12|uh on thousands of CPUs
13.32|3.9|um terabytes of memory sometimes uh but
15.9|3.719|when it came time to actually play
17.22|5.46|against the humans they would act almost
19.619|5.761|instantly it was just a lookup table
22.68|5.28|um and the humans when they were in a
25.38|3.719|tough spot they would not act instantly
27.96|2.94|they would think they would sit there
29.099|3.48|and they would think for five seconds
30.9|3.54|maybe five minutes if it was a really
32.579|3.601|difficult decision and it was clear that
34.44|3.36|was allowing them to come up with better
36.18|4.379|strategies
37.8|4.5|and so I wanted to investigate this
40.559|4.741|behavior in our Bots like if we could
42.3|4.439|add this to our Bots how much of a
45.3|4.62|difference would it make the ability to
46.739|5.941|instead of acting instantly to take some
49.92|6.119|time and compute a better strategy for
52.68|5.82|the spot that it the the agent was in
56.039|4.68|and this is what I found
58.5|3.42|so on the x-axis here we have like the
60.719|2.64|number of
61.92|2.459|buckets the number you can think of this
63.359|2.881|as like number of parameters in your
64.379|3.24|model and on the y-axis we have distance
66.24|2.879|from Nash equilibrium so this is
67.619|3.18|basically like how much you would lose
69.119|3.121|to worst case adversary so the lower the
70.799|2.761|lower this number is the better your
72.24|2.879|pokerbot is
73.56|3.419|and you can see as you scale the number
75.119|3.961|of parameters your performance improves
76.979|3.541|and it you know as as you increase the
79.08|2.88|number of parameters by about 100 full
80.52|2.7|100x
81.96|2.519|um you know your exploitability goes
83.22|3.36|down by about half and indeed you're
84.479|3.721|getting a much better poker bot
86.58|3.24|but you can see the blue line here is if
88.2|3.779|you don't have search and the orange
89.82|3.72|line is if you do add search
91.979|2.881|and you can see just adding search
93.54|3.539|adding the ability to sit there and
94.86|3.78|think for a bit improve the performance
97.079|3.661|of these models
98.64|3.78|um it like it reduced the exploitability
100.74|3.18|the distance from Nash equilibrium by
102.42|3.3|about 7X
103.92|4.019|and if you were to extend that blue line
105.72|4.38|and see how how many parameters would
107.939|5.161|you need in order to
110.1|4.14|um be comparable to adding search the
113.1|5.059|answer is you would need to scale up
114.24|3.919|your model by about a hundred thousand X
118.5|5.1|so this was pretty mind-blowing to me
121.38|4.86|when I saw this I mean over the course
123.6|4.019|of my PhD the first three years three
126.24|2.879|first three or four years of my PhD I
127.619|4.561|managed to scale up
129.119|4.081|um these models by about 100x
132.18|2.46|um
133.2|2.7|and I was proud of that I mean that's
134.64|3.36|like a pretty
135.9|4.44|pretty impressive result I think but
138.0|4.14|what this plot was showing me was that
140.34|3.479|just adding search
142.14|3.54|was the equivalent of scaling things up
143.819|3.241|by about a hundred thousand X and so all
145.68|2.16|of my previous research up until this
147.06|2.7|point
147.84|4.56|would just be a footnote compared to
149.76|5.04|adding search
152.4|3.66|so when I saw this it became clear this
154.8|2.579|this was the answer to beating top
156.06|3.6|humans in poker and so for the next year
157.379|3.961|basically non-stop I worked on scaling
159.66|3.359|search
161.34|2.7|um now there's a question that naturally
163.019|2.281|comes up which is why wasn't this
164.04|3.419|considered before
165.3|3.9|um there's a few factors so first of all
167.459|2.941|I should say like the search had been
169.2|2.58|considered in poker before and it's
170.4|4.26|actually quite natural to say like well
171.78|4.44|you know if you had search in chess and
174.66|3.9|search and go like why would you not
176.22|5.28|consider searching poker
178.56|5.22|um there's a few reasons one is that
181.5|3.42|culturally like the poker research grew
183.78|2.64|out of Game Theory and reinforcement
184.92|3.06|learning and so it wasn't really from
186.42|4.38|the same background as like the people
187.98|5.52|are working on chess and working on go
190.8|4.26|um when you scale search scaling test on
193.5|3.42|compute it makes all your experiments
195.06|4.2|much more expensive and just like more
196.92|4.02|unpleasant to work with
199.26|2.64|um and there were just like incentive
200.94|2.04|structures I mean people were always
201.9|3.36|thinking about winning the next annual
202.98|3.479|computer poker competition and the acpc
205.26|2.52|limited the resources that you could use
206.459|5.461|at test time so search wasn't really
207.78|5.52|possible effectively in the acpc
211.92|2.28|um and I think the biggest factor is
213.3|2.519|that people just didn't think it would
214.2|2.94|make such a huge difference I mean I
215.819|2.461|think it's reasonable to look at
217.14|2.519|something like search and think like oh
218.28|3.06|yeah that might make like a 10x
219.659|2.761|difference yeah you probably want to
221.34|2.399|think it makes a hundred thousand X
222.42|2.34|difference
223.739|3.06|um and so there were some people working
224.76|4.94|on it but it wasn't really the focus of
226.799|2.901|a lot of people's research
230.58|3.42|so anyway
232.26|3.839|um focused on scaling search and that
234.0|4.44|led to the 2017 brains versus AI
236.099|4.681|competition where we again played our
238.44|5.76|bot against four top Poker Pros
240.78|5.459|um 120 000 uh hands of poker 200 000 in
244.2|3.899|prize money and this time the bot won by
246.239|3.78|15 big blinds per hundred instead of
248.099|5.101|nine big blinds per hundred
250.019|5.821|this was a crushing Victory um each
253.2|3.18|human lost individually to the bot and
255.84|2.22|um
256.38|4.16|four standard deviations of statistical
258.06|2.48|significance
261.0|5.1|um we followed this up in 2019 with uh
263.52|3.78|six player poker AI competition
266.1|2.52|um the big difference here is that we
267.3|4.32|figured out how to do depth limited
268.62|4.019|search so before in the 2017 bot it
271.62|1.98|would always have the search to the end
272.639|3.181|of the game
273.6|3.84|um here it only had to do search a few
275.82|3.24|moves ahead and could stop there
277.44|2.819|and so this time
279.06|2.579|um again it went with statistical
280.259|2.461|significance and what's really
281.639|4.081|surprising about this bot is that
282.72|4.979|despite it being a much larger game uh
285.72|4.86|the six player Pokemon pluribus cost
287.699|5.581|under 150 to train on
290.58|4.26|um cloud computing resources and it runs
293.28|3.479|on 28 CPU cores at inference time
294.84|6.139|there's no gpus
296.759|4.22|so I think what this shows is that
301.199|2.881|um this really was an algorithmic
302.4|4.2|improvement I mean this would have been
304.08|5.399|doable 20 years ago if if people knew
306.6|5.099|how to do it
309.479|4.021|um and I think it also shows the power
311.699|4.021|of search you know if you can figure out
313.5|3.84|how to scale uh that compute at test
315.72|3.66|time it really can make a huge
317.34|4.799|difference and bring down your your
319.38|3.48|training costs by a huge amount
322.139|2.4|um
322.86|3.839|okay anyway yeah so I want to say also
324.539|4.44|this is not limited to Poker uh if you
326.699|3.84|look at go you see a similar pattern so
328.979|2.521|this is a plot from the alphago zero
330.539|2.641|paper
331.5|3.3|on the x-axis we have different versions
333.18|2.82|of alphago and on the y-axis we have ELO
334.8|2.82|reading which is a way of comparing
336.0|4.74|different Bots but also a way of
337.62|5.28|comparing Bots to humans and you can see
340.74|4.739|if
342.9|4.32|uh okay so superhuman performance is
345.479|3.241|around 3 600 kilo
347.22|3.539|and you can see alphago Lee the version
348.72|3.479|that played against Lisa doll in 2016
350.759|3.78|that's right over the line of superhuman
352.199|6.121|performance alphago zero the strongest
354.539|6.72|version of alphago is around 5200 ELO
358.32|4.8|but if you take out the test time search
361.259|3.841|if you just play according to the policy
363.12|4.2|net and not do any Monte College
365.1|3.9|research in alphago zero at test time
367.32|3.78|then the ELO rating drops to around
369.0|5.039|three thousand which is substantially
371.1|5.28|below expert human performance
374.039|4.44|okay so what this shows is that if you
376.38|3.68|take out montegolet research at test
378.479|4.381|time
380.06|5.5|the alphago zero is not superhuman and
382.86|5.76|in fact nobody has made a superhuman
385.56|5.579|Gobot that does not use search in some
388.62|6.299|form nobody has made a raw neural
391.139|5.34|network that can be top humans in go
394.919|2.761|and I should say also this is just if
396.479|2.581|you're taking out the search at test
397.68|2.88|time I'm I'm not even talking about
399.06|2.52|taking it out of training time if you
400.56|3.56|took it out of trains I wouldn't even
401.58|2.54|get off the ground
404.699|3.541|now there's a question of like okay well
406.259|3.72|surely you could just scale up the model
408.24|3.239|scale up the matter training and you
409.979|3.961|would eventually you know surpass
411.479|4.381|superhuman performance and and match the
413.94|3.3|performance if you added search and
415.86|3.66|that's true yes if you scale up the
417.24|4.5|models and if you scale up the training
419.52|3.72|um then you would eventually match the
421.74|2.64|performance with search but there's a
423.24|2.519|question of like how much would you have
424.38|3.18|to scale It Up by
425.759|3.181|now a rough rule of thumb is that in
427.56|3.419|order to increase your ELO rating by
428.94|3.9|about 120 points you either have to
430.979|2.94|double the amount of model size and
432.84|3.479|training or you have to double the
433.919|3.78|amount of test time search
436.319|4.141|and so if you look at that gap of around
437.699|3.72|2 000 ELO points um and you calculate
440.46|2.639|the number of deadlines that you would
441.419|4.381|need the answer is that in order to get
443.099|4.681|the raw policy net from 3000 ELO to 5200
445.8|3.54|ELO you would need to scale your model
447.78|3.919|and your training by about a hundred
449.34|2.359|thousand X
452.639|4.441|okay
454.319|4.38|um so so why is why is this important
457.08|4.08|I think you look at what's happening
458.699|4.021|today with large language models and
461.16|3.06|Transformers and and you see something
462.72|3.84|similar I mean you're getting
464.22|4.02|huge uh there's a question of like what
466.56|2.46|do I mean by search
468.24|2.399|um
469.02|3.0|there's uh specific kinds of search like
470.639|3.18|multicolage research the ability to just
472.02|4.32|like plan ahead what you're going to do
473.819|4.5|instead of just like acting instantly
476.34|3.24|um based on your pre-computed policy but
478.319|4.561|really what I mean by search more
479.58|4.44|broadly is the ability to scale the
482.88|2.58|amount of computation to get better
484.02|4.56|performance
485.46|4.56|um I think that's the real value of that
488.58|4.739|search is adding instead of just like
490.02|4.98|acting according to your precomputed
493.319|2.82|you know front loading all of your
495.0|2.699|computations so you're doing everything
496.139|4.021|all your computation ahead of time and
497.699|4.381|then like at inference time acting
500.16|4.259|basically instantly
502.08|4.619|could you get a better solution if you
504.419|6.321|had five minutes to Output an action
506.699|4.041|instead of 100 milliseconds
511.379|4.141|so
513.18|3.84|yeah I think you look at um
515.52|3.66|I'm sorry there's a there's a question
517.02|3.78|uh does a Transformer with a search
519.18|4.2|circuit count a search or do you mean
520.8|4.02|hand engineering search Algos
523.38|3.48|um I don't want to get bogged down into
524.82|3.959|like the details of like how to do this
526.86|4.2|uh because like the the answer is nobody
528.779|3.781|really knows yet um nobody really has a
531.06|2.459|general way of doing search and all the
532.56|3.779|domains that we've done search
533.519|5.461|successfully like poker and go it
536.339|4.141|started a fairly domain specific way
538.98|3.24|um you know go use this algorithm called
540.48|3.06|multicolage research
542.22|3.059|um
543.54|3.0|and yeah I guess you could think of beam
545.279|3.06|search as like one simple performance
546.54|4.859|search but you know it does seem like
548.339|5.94|there should be better better ways
551.399|4.741|um in the future
554.279|3.481|so anyway um where I'm going with this
556.14|2.94|is like you look at
557.76|3.9|actually Which models are being trained
559.08|4.199|today and you know you're seeing
561.66|3.84|millions of dollars being thrown at
563.279|4.141|pre-training like
565.5|4.26|I want to be surprised if we see a uh
567.42|3.72|you know a large language model that
569.76|2.639|would cost like 100 million dollars to
571.14|2.34|train
572.399|2.461|um we might even get to a billion
573.48|3.24|dollars
574.86|3.479|but
576.72|3.179|the inference cost is still going to be
578.339|3.0|very small
579.899|5.761|and so there's a question of like could
581.339|6.481|you do substantially better if you could
585.66|3.0|scale the amount of inference cost as
587.82|3.54|well
588.66|5.22|maybe that could like amortize uh some
591.36|4.919|of your training costs
593.88|3.959|okay so there's this uh
596.279|3.421|there's this lecture called The Bitter
597.839|3.0|Lesson by Richard Sutton uh that says
599.7|2.639|the biggest lesson that can be learned
600.839|3.0|and so it's a really great essay I
602.339|2.701|recommend reading it but one of the big
603.839|2.341|takeaways is like he says the biggest
605.04|2.34|lesson that can be learned from over 70
606.18|3.18|years of AI research is that General
607.38|3.48|methods that leverage computation are
609.36|2.88|ultimately the most effective
610.86|2.94|the two methods that seem to scale
612.24|3.36|arbitrarily in this way are search and
613.8|4.56|learning
615.6|4.98|now I think we've done a great job with
618.36|3.539|um generalizing search sorry
620.58|2.46|generalizing learning and I think that
621.899|3.681|there's still room for improvement when
623.04|2.54|it comes to search
627.48|3.299|um and yeah the next goal really is
628.92|3.479|about generality like can we develop a
630.779|3.18|truly General way of scaling inference
632.399|2.94|compute instead of just doing things
633.959|3.541|like Monte College research that are
635.339|4.201|specific to a better domain to a
637.5|5.0|specific domain and also better than
639.54|2.96|things like Chain of Thought
642.959|4.981|um what this would look like is that you
645.18|5.279|have much higher test time compute
647.94|3.959|but you have much more capable models
650.459|3.241|and I think for certain domains that
651.899|3.12|trade-off is worth it like if you think
653.7|3.48|about what inference costs we're willing
655.019|4.141|to pay for a proof of the Riemann
657.18|3.0|hypothesis I think we'd be willing to
659.16|3.9|pay a lot
660.18|4.5|or you know the cost of
663.06|2.58|what cost do we want to pay for new
664.68|2.58|life-saving drugs I think we'd be
665.64|3.18|willing to pay a lot
667.26|3.8|so I think that there is an opportunity
668.82|2.24|here
671.22|3.9|okay anyway so that's my Prelude I guess
673.92|3.859|any questions about that before I move
675.12|2.659|on to Cicero
684.42|2.82|by the way the reason why I'm talking
686.04|2.94|about this is because it's going to
687.24|4.08|inform
688.98|5.22|the approach that we took to Cicero
691.32|5.04|which I think is quite different from
694.2|3.54|the approach that a lot of other
696.36|3.56|researchers might have taken to this
697.74|2.18|problem
700.019|3.541|um someone asked can you give an example
701.459|3.481|of search well Monte Carlo research is
703.56|2.82|one form of search you could also think
704.94|3.36|of like
706.38|3.06|um breadth first search uh depth
708.3|2.58|research these kinds of things they're
709.44|3.06|all search
710.88|3.24|um I would also argue that like Chain of
712.5|4.019|Thought is doing something similar to
714.12|4.08|search where it's it's allowing the
716.519|3.721|model to like Leverage extra compute at
718.2|3.6|test time to get better performance
720.24|3.24|um
721.8|2.76|but I think that that's that's the main
723.48|4.08|thing that you want the ability to like
724.56|4.92|Leverage extra compute at test time
727.56|3.719|uh what's the search what's the space
729.48|3.96|that you are searching over
731.279|4.081|um again like in in a game like go it's
733.44|4.079|like different board positions but you
735.36|4.68|could also Imagine searching over like
737.519|4.44|you know different sentences that you
740.04|3.239|could say things like that
741.959|3.661|um
743.279|4.881|there's there's a lot of flexibility
745.62|2.54|there as well
750.18|4.08|okay so now I want to get into cereal
753.18|3.899|um so first thing I should say when it
754.26|3.54|comes to Cicero this is
757.079|2.88|um
757.8|4.279|a big team effort
759.959|2.12|um
762.54|2.64|this was like this is actually one of
764.1|2.34|the the great things about working on
765.18|2.7|this project that there was just such a
766.44|2.699|diverse talent pool
767.88|3.36|um experts in reinforcement learning
769.139|4.621|planning Game Theory natural language
771.24|3.719|processing all working together on this
773.76|4.04|um and it would not have been possible
774.959|2.841|without without everybody
778.26|4.379|so the motivation for diplomacy actually
780.42|3.419|came from 2019 we were looking at all
782.639|3.601|the breakthroughs that were happening at
783.839|4.44|the time and I think a good example of
786.24|3.539|this is this XKCD comic that came out in
788.279|2.821|2012
789.779|2.821|um that shows like different categories
791.1|2.88|games games that are solved games where
792.6|3.239|computers can be top humans games where
793.98|3.06|computers to loose top humans and games
795.839|2.161|where computers may never out play top
797.04|2.46|humans
798.0|4.32|and in this category computers still
799.5|5.959|lose the top UNC had four games go arima
802.32|3.139|poker and Starcraft
805.74|4.2|um in 2015
807.56|3.88|uh actually one of my colleagues David
809.94|4.5|Wu made the first day out of b top
811.44|6.18|humans in arima in 2016 we have alphago
814.44|4.44|beating Lisa doll and go in 2017 you
817.62|4.019|have the work that I just described
818.88|6.84|where we beat top humans in poker and in
821.639|6.781|2019 we had um Alpha star beating expert
825.72|4.859|humans in Starcraft
828.42|4.68|so that shows the incredible amount of
830.579|4.681|progress that had happened in strategic
833.1|4.679|reasoning over the past several years uh
835.26|6.6|leading up to 2019. and at the same time
837.779|6.541|we also had gpt2 come out in 2019 and it
841.86|3.479|showed that language model like in
844.32|2.28|natural language processing was
845.339|4.761|progressing much faster than I think a
846.6|3.5|lot of people including us expected
850.32|4.38|and so we were thinking about what after
853.38|2.34|um the six player poker work I was
854.7|2.4|discussing with my colleagues what
855.72|4.2|should we work on next
857.1|6.419|and we were throwing around like
859.92|5.4|um different domains to work on and
863.519|3.961|given the incredible amount of progress
865.32|4.98|in AI we wanted to pick something really
867.48|4.62|ambitious something that we thought
870.3|2.88|you couldn't just Tackle by scaling up
872.1|2.58|the existing approaches that you really
873.18|2.64|needed to something to do in order to
874.68|3.3|address
875.82|3.72|and we landed on diplomacy because we
877.98|3.9|thought that it would be the hardest
879.54|4.859|game to make an AI for
881.88|4.259|so what is diplomacy
884.399|3.541|um diplomacy is a natural language
886.139|4.081|strategy game
887.94|3.839|um it takes place uh right before World
890.22|3.54|War One you play as one of the seven
891.779|5.281|Great powers of Europe uh England France
893.76|4.92|Germany Austria Russia and Turkey and uh
897.06|2.7|your goal is to control a majority of
898.68|3.18|the map
899.76|3.78|um in practice that really happens like
901.86|4.919|if you control a majority of majority of
903.54|5.28|the map than you've won in practice
906.779|3.42|um Nobody ends up winning outright and
908.82|3.42|so your score
910.199|4.32|is proportional to the percentage of the
912.24|3.899|map that you control
914.519|3.361|now what's really interesting about
916.139|4.44|diplomacy is that it is a natural
917.88|4.74|language negotiation game
920.579|3.241|um so you have these conversations like
922.62|2.64|what you're seeing here between Germany
923.82|2.4|and England where they will privately
925.26|2.879|communicate with each other before
926.22|4.08|making their moves and so you can have
928.139|4.681|Germany ask like want to support Sweden
930.3|5.36|England says let me think on that
932.82|2.84|um and and so on
935.699|4.621|so this is a popular strategy game uh
938.76|3.54|developed in the 1950s
940.32|3.6|um it was JFK and Kissinger's favorite
942.3|3.719|game actually
943.92|3.719|and like I said each third involves
946.019|3.841|sophisticated that private natural
947.639|4.981|language negotiations and I want to make
949.86|4.5|clear like this is not
952.62|4.14|negotiations like you would see in a
954.36|4.02|game like Catan for example you're
956.76|4.5|seeing
958.38|5.04|it's it's much more like um Survivor if
961.26|4.079|you've ever seen a TV show Survivor
963.42|4.56|um you have discussions around like
965.339|3.961|alliances that you'd like to build
967.98|3.0|um discussions around like specific
969.3|3.06|tactics that you'd like to execute on
970.98|3.659|the current track
972.36|3.599|um and also you know like more long-term
974.639|2.521|strategy
975.959|3.541|um around like where do we go from here
977.16|3.72|and how do we divide resources
979.5|3.06|now
980.88|3.54|the way the game works you have these
982.56|3.06|things that last between 5 and 15
984.42|2.4|minutes depending on the on the version
985.62|3.659|of the game
986.82|3.72|um and then on each term and all these
989.279|3.721|negotiations are done privately
990.54|5.22|otherwise negotiation also I think that
993.0|3.66|you are not muted okay thank you
995.76|2.699|um
996.66|3.479|and then after the negotiation period
998.459|4.32|completes everybody will simultaneously
1000.139|3.961|write down their moves and so a player
1002.779|2.881|could promise you something like I'm
1004.1|3.0|going to support you into this territory
1005.66|2.94|this turn
1007.1|2.64|um but then when people actually write
1008.6|2.94|down their moves they might not write
1009.74|3.719|that down and so you only find out if
1011.54|5.359|they were true to their word when all
1013.459|3.44|the moves are revealed simultaneously
1018.259|5.52|uh and so for this reason alliances and
1021.019|3.841|Trust building is key the ability to
1023.779|2.461|trust that somebody's going to follow
1024.86|2.939|through on their promises that's really
1026.24|3.78|what this game is all about and the
1027.799|3.361|ability to convince people that you are
1030.02|4.1|going to follow through on your promises
1031.16|6.24|is really what this game is all about
1034.12|4.48|and so for this reason diplomacy has
1037.4|2.519|long been considered a challenge problem
1038.6|3.06|for AI there's research in the game
1039.919|3.78|going back to the 80s the research
1041.66|3.96|really only picked up
1043.699|4.321|it's it picked up like quite intensely
1045.62|4.679|in starting in 2019 when researchers
1048.02|4.56|from demide ourselves Mila
1050.299|3.12|um other places uh started working on
1052.58|3.24|this
1053.419|3.721|now a lot of that research the vast
1055.82|3.18|majority of that research actually was
1057.14|3.12|focused on the non-leverage version of
1059.0|2.22|the game which was seen as a stepping
1060.26|3.72|stone to the full natural language
1061.22|4.86|version though we decided to focus from
1063.98|4.88|the start on the full natural language
1066.08|2.78|version of the game
1069.08|4.38|so to give you a like what this
1071.66|5.94|is a dialogue look like
1073.46|5.94|here is one example so here
1077.6|5.22|um England you can see they moved their
1079.4|6.06|Fleet in Norway to St Petersburg and
1082.82|4.44|that occupies the Russian territory
1085.46|4.32|and so this is what the board state
1087.26|3.419|looks like after that move and now
1089.78|2.88|there's this conversation between
1090.679|3.781|Austria and Russia Austria says well
1092.66|3.78|what happened up north in Russia says
1094.46|3.24|England stabbed I'm afraid the end may
1096.44|2.22|be close for me and my friend Oscar says
1097.7|2.58|yeah that's rough are you going to be
1098.66|2.879|okay up there Russia says I hope so
1100.28|3.18|England seems to still want to work
1101.539|3.841|together Austria says can you make a
1103.46|3.54|deal with Germany so the players are now
1105.38|4.02|discussing like what they what should be
1107.0|4.559|discussed with other players uh Russia
1109.4|3.06|says good idea that Austria says he'll
1111.559|2.881|be fine as long as you can defend
1112.46|3.24|Sebastopol so Sebastopol is this
1114.44|4.619|territory down to the South you can see
1115.7|4.859|that turkey has a fleet and an Army in
1119.059|3.841|the Black Sea in Armenia next to
1120.559|4.98|Sebastopol and so they could potentially
1122.9|3.659|attack that territory next turn
1125.539|2.581|um
1126.559|3.301|Austria says can you support whole
1128.12|4.14|Sebastopol with Ukraine and Romania I'll
1129.86|3.96|support holdermania Russia says yep I'm
1132.26|3.24|already doing so Austria says awesome
1133.82|3.3|hopefully we can start getting you back
1135.5|3.36|on your feed
1137.12|2.7|so this is an example of the kinds of
1138.86|2.22|conversations that you'll see in a game
1139.82|3.42|of diplomacy
1141.08|4.44|um in this conversation Austria is
1143.24|3.72|actually our bot Cicero so that kind of
1145.52|5.96|gives you a sense of the uh
1146.96|4.52|sophistication of the agent's dialogue
1153.98|3.3|um
1154.7|3.66|okay I'll skip this for okay so uh I
1157.28|2.639|guess I'll go into this I don't want to
1158.36|3.3|take up too much time
1159.919|3.661|um really what makes diplomacy
1161.66|3.72|interesting is that support is key so
1163.58|4.14|here for example
1165.38|3.539|um Budapest and Warsaw the the red and
1167.72|2.88|the purple units both try to move into
1168.919|3.601|Glacier and so since it's a one versus
1170.6|4.079|one they both bounce back and neither
1172.52|4.14|was into the territory uh in the middle
1174.679|4.141|panel you can see Vienna supports
1176.66|4.86|Budapest into Glacier and so now it's a
1178.82|5.16|two versus one and that red unit will
1181.52|3.96|indeed enter galatia and what's really
1183.98|2.819|interesting about diplomacy is that it
1185.48|2.579|doesn't just have to be your own units
1186.799|3.841|that are supporting you it could be
1188.059|4.321|another player's units as well so for
1190.64|3.419|example the green player could support
1192.38|3.0|the red player into Glacier and then
1194.059|3.061|that ready and it would still go in
1195.38|3.24|there
1197.12|4.02|so support is really what the game is
1198.62|4.08|all about negotiating over support
1201.14|2.76|um and so for that reason diplomacy has
1202.7|2.76|this reputation as the game that ruins
1203.9|3.06|friendships
1205.46|2.88|um it's really difficult to have an
1206.96|3.719|alliance with somebody for three or four
1208.34|4.56|hours and then have that
1210.679|4.021|have them backstab you and uh you know
1212.9|3.6|basically just ruin your game
1214.7|3.54|but if you talk to expert diplomacy
1216.5|3.419|players they they view it differently
1218.24|3.36|they say diplomacy is ultimately about
1219.919|4.741|building trust in an environment that
1221.6|4.439|encourages you to not trust anyone
1224.66|3.3|and that's why we decided to work on the
1226.039|3.601|game you know could we make an AI that
1227.96|3.54|is able to build trust with the players
1229.64|3.3|in an environment that encourages them
1231.5|3.72|to not trust anybody
1232.94|4.859|um Can the bot uh like honestly
1235.22|4.44|communicate that it's going to do
1237.799|3.24|something and and evaluate whether
1239.66|2.46|another person is being honest when
1241.039|3.26|they're saying that they're going to do
1242.12|2.179|something
1245.48|3.9|Okay so
1247.28|3.42|why diplomacy it sits in this nice
1249.38|3.96|intersection of reinforcement learning
1250.7|3.719|and planning and also natural language
1253.34|3.18|um there's two perspectives that we can
1254.419|3.721|take on why diplomacy is a really
1256.52|4.8|interesting domain one is the
1258.14|5.279|multi-agent perspective so here
1261.32|4.739|all the previous game AI results
1263.419|5.221|um like chess go poker these have all
1266.059|5.821|been in purely Zero Sum two player
1268.64|5.22|zero-sum domains and in these domains uh
1271.88|3.9|self-play is guaranteed to converge to
1273.86|3.6|an optimal solution basically what this
1275.78|3.06|means is you can start having the bot
1277.46|3.78|play completely from scratch with no
1278.84|4.5|human data and by playing against itself
1281.24|3.96|repeatedly it will eventually converge
1283.34|3.9|to this unbeatable optimal solution
1285.2|4.62|called the Minimax equilibrium
1287.24|4.08|but that result only holds in two player
1289.82|4.32|zerosome games that whole Paradigm only
1291.32|4.32|holds in two player zeros and games
1294.14|4.14|when you go to domains that involve
1295.64|4.56|cooperation in addition to competition
1298.28|3.779|then success requires understanding
1300.2|3.0|human behavior and conventions you can't
1302.059|3.301|just treat the other players like
1303.2|5.099|machines anymore you have to treat them
1305.36|5.939|like humans you have to model
1308.299|4.681|human irrationality human sub-optimality
1311.299|3.961|um one example of this is actually
1312.98|3.9|language like
1315.26|3.0|you can imagine if you were to train a
1316.88|3.419|bot completely from scratch in the game
1318.26|3.779|of diplomacy like the full natural
1320.299|3.36|language version of the game there's no
1322.039|3.361|reason why the bot would learn to
1323.659|3.061|communicate in English it would learn to
1325.4|3.06|communicate in some weird gibberish
1326.72|3.9|robot language and then when you stick
1328.46|5.3|it in a game with six humans it's not
1330.62|3.14|going to be able to cooperate with them
1334.1|3.3|um
1335.36|4.38|so we have to find a way to incorporate
1337.4|4.56|human data and be able to learn how
1339.74|4.46|humans behave in order to succeed in
1341.96|2.24|this game
1346.159|3.541|um okay
1347.419|4.321|there's also the NLP perspective
1349.7|4.26|which is that current language models
1351.74|3.54|are essentially just imitating
1353.96|3.719|human-like text now there's been some
1355.28|3.84|progress with things like rlhf
1357.679|3.661|um but
1359.12|4.02|that's still like not really the way
1361.34|3.12|that humans communicate they communicate
1363.14|2.519|with an intention in Minds right they
1364.46|2.52|come with this intention and then they
1365.659|2.461|communicate with the goal of
1366.98|2.939|communicating that intention and they
1368.12|3.179|understand that others are trying to do
1369.919|3.061|the same
1371.299|3.781|and so there's a question of like can we
1372.98|6.559|move Beyond Chit Chat
1375.08|4.459|uh to grounded intentional dialogue
1380.659|4.38|so Cicero is an AI agent for diplomacy
1383.659|4.201|that integrates high-level strategic
1385.039|4.441|play and open domain dialogue and we
1387.86|2.939|used 50 000 human games of diplomacy
1389.48|4.579|acquired through a partnership with the
1390.799|3.26|website web diplomacy.net
1394.34|3.42|so we entered Cicero in an online
1395.9|4.2|diplomacy League um just to give you the
1397.76|3.899|results up front uh Cicero was not
1400.1|3.72|detected as an AI agent for 40 games
1401.659|3.9|with 82 unique players
1403.82|4.08|um there was one player that mentioned
1405.559|5.161|after the fact that like they kind of
1407.9|4.32|like made a joke about us being a bot
1410.72|2.819|um but they didn't really follow up on
1412.22|2.819|it and nobody else followed up on it and
1413.539|3.12|they later accused somebody else of also
1415.039|3.841|being a bot so we weren't sure how
1416.659|3.361|seriously to take that accusation
1418.88|2.039|um but I think it's safe to say beta
1420.02|2.519|through all 40 games without being
1420.919|3.481|detected as bot
1422.539|3.361|um and then we in fact we told the
1424.4|3.54|players afterwards that it was a bot the
1425.9|4.5|whole time these are the kinds of
1427.94|4.8|responses that we got uh people were
1430.4|4.62|quite surprised pleasantly surprised
1432.74|5.22|fortunately um nobody was was upset with
1435.02|4.74|us but they were quite surprised that
1437.96|4.5|there was a bot that had been playing
1439.76|5.1|this game with them the whole time
1442.46|4.62|so in terms of results Cicero placed in
1444.86|4.26|the top 10 percent of players
1447.08|3.42|um it's a high variance game and so if
1449.12|2.52|you look at
1450.5|3.12|um players that played five or more
1451.64|3.12|games that played second out of 19 and
1453.62|2.88|it achieved more than doubled the
1454.76|3.539|average human score
1456.5|3.78|so I would describe this as a strong
1458.299|4.081|level of human performance I wouldn't go
1460.28|3.48|as far as to say that this is superhuman
1462.38|3.539|by any means
1463.76|4.34|um but it is currently quite a strong
1465.919|2.181|result
1470.419|4.921|now to give you a picture of how Cicero
1474.02|2.46|works
1475.34|4.26|so
1476.48|4.5|the input that we feed into the model is
1479.6|3.36|the board State and the recent action
1480.98|4.439|history that's shown at the top left
1482.96|6.3|here and also the dialogue that it's had
1485.419|5.701|with all the players up until now
1489.26|3.779|so that's going to get fed into a
1491.12|5.28|dialogue conditional action model that's
1493.039|4.62|going to predict what all what Cicero
1496.4|4.139|thinks all the players are going to do
1497.659|5.301|this turn and what they think we will do
1500.539|2.421|this turn
1503.62|2.559|these
1505.22|2.52|um
1506.179|5.661|these lead to what we call Anchor
1507.74|4.1|policies that are then used for planning
1512.299|3.841|um
1513.679|4.681|now planning here
1516.14|5.22|again this is like the part where we
1518.36|4.86|leverage extra compute at test time in
1521.36|3.24|order to get better performance
1523.22|2.579|so essentially we take these initial
1524.6|2.22|predictions of what everybody's going to
1525.799|2.76|do the what are called The Anchor
1526.82|4.56|policies
1528.559|4.441|and we improve upon these predictions uh
1531.38|3.6|using this planning process called
1533.0|4.14|pickle where basically we account for
1534.98|4.199|the fact that players
1537.14|3.419|we'll pick actions that have higher
1539.179|2.941|expected value with higher probability
1540.559|4.381|we're essentially adding this like
1542.12|4.14|rationality prior to all the players to
1544.94|3.54|assume that they're not going to blunder
1546.26|3.6|as often as the model might suggest and
1548.48|2.939|they're going to pick smarter actions
1549.86|2.76|with higher probability than the initial
1551.419|2.461|model might suggest
1552.62|3.36|and what we find is that this actually
1553.88|4.44|gives us a better prediction of what all
1555.98|6.02|the players will do than just relying on
1558.32|3.68|the raw neural net itself
1563.24|3.539|this gives us the action that we
1564.86|4.5|actually play in the game and it also
1566.779|4.621|gives us what we call intense
1569.36|3.84|so intents are an action for ourselves
1571.4|3.48|and an action for the dialogue partner
1573.2|3.54|that we're speaking to
1574.88|3.84|and now we have this dialogue
1576.74|4.14|conditional uh so we have we have this
1578.72|4.74|dialog model that conditions on these
1580.88|4.5|intents so the intents are fed into the
1583.46|3.54|dialogue model along with the board
1585.38|4.08|state in action history and also the
1587.0|4.32|dialogue that we've had so so far and
1589.46|4.92|that dialog model will then generate
1591.32|6.62|candidate messages that
1594.38|3.56|are conditioned on those intents
1597.98|2.88|these candidate messages go through a
1599.659|3.601|series of filters that filter out
1600.86|4.38|nonsense grounding issues and also like
1603.26|3.0|low expected value action low expected
1605.24|3.78|value messages
1606.26|5.76|and ultimately we get out a message to
1609.02|4.92|send to our dialogue partner
1612.02|3.06|now every time we send or receive a
1613.94|3.44|message we will repeat this whole
1615.08|2.3|process
1619.76|5.22|so there's actually a lot that is quite
1622.279|4.26|novel in Cicero um and I'm going to try
1624.98|3.299|to talk about
1626.539|2.701|uh the the contributions as much as
1628.279|2.76|possible I might go through this a
1629.24|3.36|little quickly so we we have time for
1631.039|3.0|questions
1632.6|3.059|um the first one is a controllable
1634.039|3.721|dialogue model by conditions on the game
1635.659|5.361|State and a set of intended actions for
1637.76|3.26|the speaker and the recipient
1641.48|5.52|so I have a question what is the action
1644.36|4.319|space here for the model
1647.0|3.299|um
1648.679|4.021|the action space
1650.299|3.841|for the action prediction model is like
1652.7|3.42|all the actions that you could take in
1654.14|2.82|the game that that a player could take
1656.12|2.34|in the game
1656.96|3.839|for the dialogue model it's like you
1658.46|6.56|know messages that you can send
1660.799|4.221|it so oh
1667.279|5.581|okay so we train what we call an intent
1670.52|4.62|model that predicts what actions people
1672.86|4.199|will take at the end of truthful turns
1675.14|4.86|basically what we're trying to predict
1677.059|6.181|um what are people intending to do when
1680.0|4.919|they communicate a certain message
1683.24|3.419|and um
1684.919|3.901|then we use this to automatically
1686.659|4.741|annotate the data set with basically
1688.82|4.38|what we expect people's intentions were
1691.4|3.24|when they sent that message and we
1693.2|2.459|filter out
1694.64|2.82|um
1695.659|5.281|we filter out as much as possible lies
1697.46|6.0|from the data set so that the
1700.94|4.619|um the text in the data set is annotated
1703.46|4.459|with the truthful
1705.559|2.36|um intention
1708.919|3.661|and then during play Cicero conditions
1711.14|3.84|the dialogue model on the truthful
1712.58|4.38|intention that it intends to take and
1714.98|3.78|the goal then is that the hope then is
1716.96|4.26|that it will uh generate a message
1718.76|4.919|consistent with that intention
1721.22|4.8|and that is then fed into
1723.679|4.321|um into everything else that's that's uh
1726.02|3.36|you know sorry that uh the intentions
1728.0|4.58|that we generate through planning are
1729.38|3.2|fed into the dialogue model
1734.36|4.08|so to give you an example of what this
1736.76|3.899|looks like this gives us a way to
1738.44|5.46|control the dialogue model through a set
1740.659|4.081|of intentions like here
1743.9|4.2|um
1744.74|5.46|we are Cicero's England and pink and
1748.1|3.959|their action is to move to Belgium among
1750.2|2.579|other things
1752.059|2.641|um
1752.779|3.9|and so if we feed this attention into
1754.7|3.12|the dialogue model then the message that
1756.679|3.421|might get generated in something like
1757.82|3.78|England saying to France do you mind
1760.1|4.699|supporting me do you do you mind
1761.6|3.199|supporting Eddie to Belgium
1765.679|5.401|um on the other hand let's say Cicero's
1767.72|5.66|action is the support for answer the
1771.08|2.3|Belgium
1773.419|3.901|um then if you feed that into the
1775.22|3.179|dialogue model then the the message
1777.32|2.579|that's generated might say something
1778.399|2.821|like let me know if you want me to
1779.899|3.981|support you to Belgium otherwise I'll
1781.22|2.66|probably Poe Collins
1786.38|3.179|now what we find is that conditioning
1788.12|3.96|the dialogue model on these intentions
1789.559|4.081|in this way it makes the model more more
1792.08|3.66|controllable but it also leads to higher
1793.64|4.98|quality dialogue with less nonsense
1795.74|4.559|so we found that it led to dialogue that
1798.62|3.179|was more consistent with the state more
1800.299|4.681|consistent with the plan higher quality
1801.799|4.86|lower perplexity and I think the
1804.98|2.76|argument the reasoning for why this is
1806.659|3.721|the case is that we're kind of like
1807.74|4.799|relieving the dialogue model of the
1810.38|4.5|burden of having to come up with
1812.539|3.781|a good strategy we're allowing the
1814.88|3.72|dialogue model to do what it does best
1816.32|3.839|to focus on what it does best which is
1818.6|4.02|dialogue
1820.159|4.5|and we're relieving it of the Strategic
1822.62|3.72|components of the game because we're
1824.659|3.921|feeding that strategy into the dialogue
1826.34|2.24|model
1830.419|3.901|okay so that's one main contribution
1832.52|4.2|this controllable dialogue model that
1834.32|4.079|conditions on on a plan
1836.72|5.66|um the second is a planning engine that
1838.399|3.981|accounts for dialogue and human behavior
1842.96|4.38|so
1844.399|4.801|okay I mentioned that a lot of
1847.34|4.74|previous work on games
1849.2|5.28|was done using self-play
1852.08|6.24|um in two players here are some settings
1854.48|6.0|now the problem with like pure self-play
1858.32|3.239|is that it can learn strong policies but
1860.48|2.819|it doesn't
1861.559|3.961|it doesn't stick with human conventions
1863.299|4.5|and it can't account for dialogue it's
1865.52|4.139|just going to ignore the human data and
1867.799|4.201|the human way of playing if you just do
1869.659|4.5|self-play
1872.0|4.38|so that's one extreme
1874.159|4.681|um The Other Extreme that you can go is
1876.38|3.539|to just do supervised learning on human
1878.84|3.839|data
1879.919|5.88|create this model of how humans play and
1882.679|5.281|then train with those you know imitation
1885.799|4.801|humans
1887.96|4.14|and if you do this you'll end up with a
1890.6|3.72|bot that's consistent with dialogue and
1892.1|4.559|human conventions but it's only as
1894.32|3.78|strong as the training data and we found
1896.659|4.02|that it was actually very easily
1898.1|4.38|manipulable through adversarial dialogue
1900.679|3.72|so for example you can send messages to
1902.48|4.679|it saying like thanks for agreeing to
1904.399|4.801|support me at the Paris and it will
1907.159|3.721|think like well I've only ever seen that
1909.2|2.94|message in my trading data when I've
1910.88|3.0|agreed to support the person of the
1912.14|3.779|Paris and so I guess I'm supporting them
1913.88|3.419|at the Paris the stern even even though
1915.919|3.561|that might be a terrible move for the
1917.299|2.181|bot
1920.059|3.781|so we came up with this algorithm called
1921.44|6.06|pickle that it kind of like is a happy
1923.84|7.68|medium between these these two extremes
1927.5|6.299|um the way Pickle Works is it's
1931.52|5.58|basically trying to it's it's doing
1933.799|6.36|self-play but regularized toward
1937.1|5.04|s sticking to the human imitation policy
1940.159|4.441|so it has a KL penalty for date for
1942.14|4.94|deviating from the human imitation
1944.6|2.48|policy
1947.36|5.819|so we have this parameter Lambda that
1949.58|6.9|controls how easy it is to deviate
1953.179|5.401|um from from the human imitation policy
1956.48|4.38|at Lambda equals zero
1958.58|3.9|it just ignores the human imitation
1960.86|3.179|policy completely and just does pure
1962.48|4.319|self-play
1964.039|4.921|um and so just like do self-play uh as
1966.799|4.26|it from scratch at them to equal zero
1968.96|3.78|all right Lambda equals infinity it's
1971.059|6.301|just playing the human imitation policy
1972.74|6.24|and not doing uh self-play at all
1977.36|2.819|but for intermediate values of Lambda
1978.98|4.14|what we find is that it actually gives
1980.179|4.441|you a good medium between sticking to
1983.12|4.039|human conventions and Performing
1984.62|2.539|strongly
1988.279|3.841|so you can kind of see this Behavior
1989.96|4.219|emerge here
1992.12|2.059|um
1994.22|3.12|sorry there's a question is this similar
1995.899|2.941|to offline RL or also incorporates
1997.34|4.74|exploration so let's say there's
1998.84|5.28|actually a lot of similar work on you
2002.08|2.88|know having a KL penalty
2004.12|2.7|um
2004.96|4.14|and so yes I would say that it's like
2006.82|4.079|very similar to a lot of
2009.1|3.12|um that work it's also been done
2010.899|2.52|actually in Alpha star where they had a
2012.22|3.6|KL penalty
2013.419|4.321|um though that was more about aiding
2015.82|3.839|exploration like using human data to Aid
2017.74|4.439|exploration rather than
2019.659|3.36|um trying to better imitate humans so I
2022.179|2.761|think what's interesting about the
2023.019|4.201|pickle work is that one we find it
2024.94|4.56|imitates humans better than not than
2027.22|4.799|just doing supervised learning alone and
2029.5|4.74|two we are
2032.019|4.441|doing a bit of theory of mind where we
2034.24|4.02|assume that the other players are also
2036.46|3.36|like we're using this as a model for our
2038.26|3.18|behavior
2039.82|3.479|um what what we expect other people to
2041.44|3.359|think our behavior is in addition to
2043.299|4.8|modeling the other players
2044.799|4.501|so it's like a common knowledge
2048.099|4.32|um
2049.3|5.96|common knowledge like uh algorithm that
2052.419|2.841|we're using here
2057.339|4.441|okay so the kind of behavior that you
2058.899|5.581|see from this you can see here let's say
2061.78|4.02|England agrees sorry so let's say we're
2064.48|3.48|in this situation this actually came up
2065.8|4.879|in a real in a real game
2067.96|6.419|um and an inspired figure from our paper
2070.679|8.74|so England and France are fighting
2074.379|7.561|um France is the bot and France asks if
2079.419|5.881|if england is going to disengage
2081.94|4.62|and let's say England says yes I will
2085.3|3.059|move out of English Channel if you head
2086.56|3.839|back to Nao
2088.359|3.3|well we can see that Cicero does in fact
2090.399|5.28|back off
2091.659|5.94|leaves and uh goes to Nao and the
2095.679|3.901|disengagement is successful and so this
2097.599|3.541|shows that the um the bud strategy
2099.58|5.18|really is reflecting the dialogue that
2101.14|3.62|it's had with this other player
2105.58|3.24|um another message that England might
2107.08|3.24|send is something like I'm sorry you've
2108.82|3.36|been fighting me this whole game I can't
2110.32|4.38|trust you that you won't stab me
2112.18|4.439|and so in this case Cicero will continue
2114.7|3.18|its attack on England and you can see
2116.619|2.761|again this is reflective it's it's
2117.88|3.8|changing its Behavior depending on the
2119.38|2.3|dialogue
2122.32|3.96|but you can also have uh this kind of
2123.94|3.179|message where you know England says yes
2126.28|2.28|I'll leave
2127.119|3.121|you know if you move to Munich and haul
2128.56|4.32|into Belgium so these are really bad
2130.24|4.92|moves for Cicero to follow
2132.88|5.28|um and so if you just use if you just
2135.16|5.939|look at the raw policy net
2138.16|4.62|it might actually do this it might
2141.099|3.421|actually do these moves because uh
2142.78|3.299|because England suggested it but because
2144.52|3.12|we're using pickle that incorporates
2146.079|2.76|like you know the expect it counts for
2147.64|3.84|the expected value of different actions
2148.839|4.26|it will actually partially back off but
2151.48|3.0|ignore the suggested boost because it
2153.099|4.641|recognizes that those will leave it very
2154.48|3.26|vulnerable to an attack
2160.42|5.36|um okay I'll skip the slide for time
2163.66|2.12|um
2168.52|3.599|another thing I should say is that
2170.8|3.0|we're not just doing planning we're
2172.119|4.201|actually doing this in a full self-play
2173.8|5.94|reinforcement learning Loop
2176.32|5.22|um and again the goal here is it's
2179.74|3.18|really about modeling humans better than
2181.54|2.88|supervising alone and we found that
2182.92|3.419|doing this self-play reinforcement
2184.42|3.72|learning with pickle allowed us to
2186.339|5.121|better model human behavior
2188.14|3.32|um than just doing imitation learning
2191.8|2.88|uh finally we have an ensemble of
2193.66|2.28|message filtering techniques that
2194.68|4.46|filters both nonsensical and
2195.94|3.2|strategically on sound messages
2199.599|3.901|um so to give you an example of what
2201.76|3.66|these filters look like here one that we
2203.5|3.96|developed is value-based filtering
2205.42|3.96|so
2207.46|4.5|the motivation for this is that when we
2209.38|4.02|when we feed into our dialogue bottle is
2211.96|2.94|a plan for ourselves and for our
2213.4|3.54|speaking partner
2214.9|4.5|um but it's the entire plan that we have
2216.94|4.74|for ourselves and so we might end up
2219.4|3.66|feeding into the dialogue model the fact
2221.68|2.7|that we're going to attack the player
2223.06|4.2|that we're speaking to
2224.38|4.56|now the dialogue model is you know to be
2227.26|3.06|honest kind of dumb and it doesn't
2228.94|3.899|really know
2230.32|4.5|that it shouldn't be telling this player
2232.839|3.0|that they're going to be attacked this
2234.82|2.4|turn
2235.839|3.301|and so you have these messages that
2237.22|3.66|might be sent something like the the
2239.14|3.54|second one shown here where England says
2240.88|3.239|to France we have hostile intentions
2242.68|4.32|towards you you must be wiping the board
2244.119|3.96|please provide a croissant uh so this is
2247.0|3.119|actually like a message that the bot
2248.079|3.54|sent to a player um not to a player it
2250.119|2.941|was uh this was like preliminary testing
2251.619|3.301|and kind of like motivated this whole
2253.06|3.48|approach
2254.92|2.939|um
2256.54|2.34|so we don't want the bot to send these
2257.859|2.281|kinds of messages if it's going to
2258.88|3.66|attack a player we wanted to send
2260.14|3.78|something that's like you know not an
2262.54|2.76|outright lie necessarily but just
2263.92|3.06|something they either not send a message
2265.3|4.039|or send something that's much much more
2266.98|2.359|bland
2269.38|5.04|and so we we filter out these kinds of
2271.06|5.4|messages by looking at the value like
2274.42|3.36|what we do is we generate a bunch of
2276.46|3.96|candidate messages
2277.78|5.88|and then we see if we were to send this
2280.42|5.34|message what is the behavior that we
2283.66|4.199|would expect the other players to take
2285.76|4.079|like what what actions would we expect
2287.859|4.26|them to do after we send this message
2289.839|3.901|and what do they expect we will do after
2292.119|3.72|we send this message
2293.74|4.32|and then we see
2295.839|4.081|what is the expected value of the action
2298.06|3.299|that we intend to take
2299.92|3.36|um given the prediction of what
2301.359|5.641|everybody else is going to do
2303.28|5.46|so if our intention is to attack France
2307.0|3.24|then we can see well if I were to send
2308.74|3.42|this message to France then they're
2310.24|3.54|going to get really defensive and defend
2312.16|3.54|against an attack from us and our attack
2313.78|3.54|is going to be unsuccessful and so
2315.7|4.399|therefore I probably shouldn't send this
2317.32|2.779|message to them
2320.74|1.98|um
2321.4|2.76|and so in this way we can actually
2322.72|3.3|filter out messages that have low
2324.16|3.24|expected value
2326.02|3.98|and we found this this worked
2327.4|2.6|surprisingly well
2331.119|5.761|um dialogue examples I'll go through uh
2333.64|6.36|one just for the sake of time
2336.88|3.78|um so here we have
2340.0|3.72|um
2340.66|5.04|Cicero's France and France is saying uh
2343.72|4.2|France is uh conversing with turkey
2345.7|4.5|who's a human player and they're
2347.92|4.26|debating over who's gonna get Tunis this
2350.2|3.899|territory circled in red
2352.18|3.659|you'd see they both have fleets next to
2354.099|2.76|the territory if they both go for it
2355.839|2.161|neither of them are going to get it and
2356.859|2.161|so they need to work out some sort of
2358.0|2.88|deal
2359.02|3.599|so Fred says I'll work with you but I
2360.88|3.54|need tennis for now turkey says Nope you
2362.619|4.201|gotta let me have it
2364.42|4.62|um France says no I need it and then
2366.82|4.019|France suggests you know you can take
2369.04|3.96|these other territories instead you have
2370.839|3.841|Serbia and Rome to take
2373.0|5.22|um turkey says they're impossible
2374.68|5.1|targets and then Cicero suggests
2378.22|3.42|specific moves
2379.78|4.2|that would allow turkey to capture these
2381.64|4.8|territories so Cicero says Greece Toyota
2383.98|4.32|tyranian
2386.44|3.659|um turkey says you're right good ideas
2388.3|4.02|and then Francis then in the fall you
2390.099|5.041|take Roman Austria collapses and so that
2392.32|4.56|allows turkey to you know make progress
2395.14|3.84|against Austria but conveniently it also
2396.88|4.02|allows uh
2398.98|3.42|France to capture Tunis because uh
2400.9|3.86|turkey will be using those units for
2402.4|2.36|something else
2406.0|3.66|okay so limitations in future directions
2408.339|3.361|um Intel representation is just an
2409.66|3.72|action per player okay so there's a
2411.7|3.0|question of like
2413.38|2.82|the intentions that we're feeding into
2414.7|2.82|the dialogue model is an action that
2416.2|3.06|we're going to take for this turn and
2417.52|2.88|for the next turn for ourselves and for
2419.26|4.079|the other player
2420.4|4.26|but ideally we would have a richer set
2423.339|3.421|of intentions we would be able to like
2424.66|4.439|condition on things like long-term
2426.76|4.319|strategy or style of communication or
2429.099|2.76|like asking questions
2431.079|3.241|um
2431.859|4.921|that is that's one of the limitations of
2434.32|4.44|this approach now of course the Richer
2436.78|3.48|you make the space of intentions
2438.76|3.3|um the more room there is for things to
2440.26|3.48|go wrong and you also have to like then
2442.06|5.12|train the model to be able to handle
2443.74|3.44|these like wider space of intentions
2447.46|3.54|uh there's a question do you think the
2449.5|4.02|dialogue model is learning an internal
2451.0|4.32|model internal World model to be so good
2453.52|3.24|at predicting moves
2455.32|4.98|um no we're
2456.76|5.64|this is this is arguably why we're
2460.3|3.96|conditioning on intentions we're
2462.4|3.66|relieving the dialogue model of having
2464.26|3.9|to come up with a good World model
2466.06|3.539|because we're telling it like these are
2468.16|2.88|the moves that we are planning to take
2469.599|2.461|this turn and these are the moves that
2471.04|1.86|we would like this other player to take
2472.06|3.059|this turn
2472.9|4.26|so we're like
2475.119|4.201|we're able to like
2477.16|3.6|have the world model separate from the
2479.32|3.24|link from the dialogue model but
2480.76|4.04|condition on the output from the world
2482.56|2.24|model
2486.28|3.839|okay another limitation is that Cicero's
2488.8|3.72|value model doesn't condition on
2490.119|3.72|dialogue and so it has a limited
2492.52|3.8|understanding of the long-term effects
2493.839|2.481|of dialogue
2496.839|5.581|um
2498.64|6.0|this greatly limits our ability to
2502.42|3.36|plan what kind of messages we should be
2504.64|2.52|sending
2505.78|4.559|um
2507.16|5.16|and this is actually why we um we always
2510.339|4.321|condition Cicero's dialogue generation
2512.32|4.74|on its truthful intentions
2514.66|4.199|You could argue that there's situations
2517.06|3.42|of diplomacy where you would want to lie
2518.859|4.801|to the other player
2520.48|6.48|um the best players rarely lie but they
2523.66|5.4|they do lie sometimes and
2526.96|5.78|you have to understand the trade-off
2529.06|5.88|between like if you lie you are going to
2532.74|4.599|not it's going to be much harder to work
2534.94|4.5|with this person in the future
2537.339|3.661|um and so you have to make sure that the
2539.44|4.38|value that you're getting positionally
2541.0|4.5|is worth that loss of trust and that
2543.82|3.18|broken relationship
2545.5|4.14|now
2547.0|4.14|because Cicero's value model doesn't
2549.64|2.939|condition on dialogue
2551.14|5.52|it can't really understand this
2552.579|5.701|trade-off and so for this reason we
2556.66|2.82|actually always condition it on its
2558.28|4.2|truthful intentions
2559.48|3.0|now
2562.599|4.98|it is possible to have Cicero's
2565.599|3.661|diabolical condition on dialogue but you
2567.579|4.141|would need way more data and it would
2569.26|4.14|make things much more expensive and so
2571.72|3.98|um we weren't able to do it further for
2573.4|2.3|this spot
2577.54|3.96|and uh finally there's a big question
2579.64|3.3|that I mentioned earlier which is is
2581.5|3.359|there a more General way of scaling
2582.94|2.879|inference time compute to achieve better
2584.859|2.821|performance
2585.819|3.841|the way that we've done planning in
2587.68|4.26|Cicero is I would argue a bit domain
2589.66|4.14|specific um I I think it's like the the
2591.94|2.94|idea of pickle is quite General but I
2593.8|4.58|think that there are potentially more
2594.88|3.5|General ways of doing planning
2601.18|2.82|um
2602.02|3.42|somebody's asking looking forward to the
2604.0|3.24|next two to three years what criteria
2605.44|3.659|criteria will you use to select the next
2607.24|3.24|game to try to conquer
2609.099|2.941|um honestly
2610.48|2.52|like I said we chose diplomacy because
2612.04|2.88|we thought it'd be the hardest game to
2613.0|2.819|make an AI for and I think that that's
2614.92|2.159|true
2615.819|2.461|um I don't think that we're gonna be
2617.079|3.721|working on games anymore because I can't
2618.28|5.339|think of any other game that if we were
2620.8|4.319|to succeed at that it would be truly
2623.619|2.22|impressive
2625.119|3.181|um
2625.839|4.561|and so I think where the research is
2628.3|4.68|going in the future
2630.4|5.58|um is generality
2632.98|5.7|like instead of getting an AI to play
2635.98|4.98|this specific game can we get an AI that
2638.68|5.04|is able to play diplomacy but could also
2640.96|5.76|play go or poker or it could also write
2643.72|5.099|essays and stories and solve math
2646.72|2.82|problems and write theorems
2648.819|3.241|um
2649.54|5.76|I think what we will see
2652.06|6.36|is games serving as benchmarks
2655.3|4.92|for progress but not as
2658.42|3.06|the goal you know it'll be part of the
2660.22|3.119|test set but not part of the training
2661.48|4.4|set and I think that's the way it should
2663.339|2.541|be going forward
2667.359|3.841|um finally I want to add that diplomacy
2669.52|3.9|is an amazing test bed for multi-agent
2671.2|5.399|AI and grounded dialogue
2673.42|4.38|um so if you are interested in these
2676.599|4.081|kinds of domains I highly recommend
2677.8|4.559|taking advantage of the fact that we are
2680.68|4.139|we've open sourced all of our code and
2682.359|4.621|models and the dialogue and action data
2684.819|3.721|is available through a uh what's called
2686.98|6.3|an RFP where you can apply to get access
2688.54|4.74|to the dialogue and and data
2694.119|4.021|okay so thanks for listening um to wrap
2696.52|3.299|up Cicero combined strategic reasoning
2698.14|3.78|and natural language and diplomacy in
2699.819|4.381|place in the top 10 of human players and
2701.92|5.04|the paper is in science and coded models
2704.2|4.74|are publicly available at this URL so
2706.96|3.84|thanks and for the Rainy time I'll take
2708.94|2.7|questions great thanks a lot for your
2710.8|2.46|talk
2711.64|2.699|so we'll also open some questions from
2713.26|3.059|the class
2714.339|3.48|um uh but yeah we've been finished there
2716.319|3.54|are Zoom questions so if anyone has like
2717.819|4.081|some questions or I think you know you
2719.859|3.901|can answer those and yeah there's one
2721.9|3.0|question are you concerned about ai's uh
2723.76|2.64|how competing humans are real world
2724.9|3.3|diplomatic strategic negotiation and
2726.4|4.32|deception tasks
2728.2|4.32|um so like I said we we're not very
2730.72|3.599|focused on Deception even though um you
2732.52|3.24|know arguably deception is a part of the
2734.319|3.3|game of diplomacy
2735.76|3.78|um I
2737.619|3.48|think for diplomatic and strategic
2739.54|4.38|negotiation
2741.099|4.441|I don't like look the way that we've
2743.92|3.6|developed uh Cicero
2745.54|3.48|it's designed to play diplomacy the game
2747.52|4.38|of diplomacy specifically and you can't
2749.02|4.02|use it out of the box for other tasks
2751.9|2.76|um that said I do think that the
2753.04|2.819|techniques are quite
2754.66|2.82|General
2755.859|3.24|um and so hopefully others can build on
2757.48|3.839|that and to be able to do uh different
2759.099|3.841|things and I think it is you know
2761.319|4.02|entirely possible that over the next
2762.94|5.22|several years you will see this entering
2765.339|4.321|uh into real world negotiations uh much
2768.16|3.78|more often I actually think that
2769.66|4.5|diplomacy is a big step towards real
2771.94|3.78|world applicability compared to uh
2774.16|3.919|breakthroughs and games like go and
2775.72|2.359|poker
2778.839|2.881|um because because now your action Space
2780.4|3.54|is really like the space of natural
2781.72|3.599|language and you have to model human
2783.94|2.639|behavior
2785.319|3.561|do you think in the future we could
2786.579|5.341|appoint AI to the U.N console
2788.88|5.26|uh hopefully hopefully only if it does
2791.92|4.439|better than humans um but that would be
2794.14|4.32|very interesting to see
2796.359|3.541|great I'm also curious like uh what
2798.46|3.0|What's like the future things that
2799.9|2.88|you're working on in this direction like
2801.46|2.94|do you think you can do something like a
2802.78|3.059|couple zero where you just like take
2804.4|4.08|this take this like pitted model and
2805.839|4.02|then major speak in Excel play uh or
2808.48|2.52|like what's what sort of featured
2809.859|2.76|actions are you thinking for improving
2811.0|3.0|this sort of box
2812.619|2.941|I think the future directions are really
2814.0|3.9|focused around generality
2815.56|4.44|um like I think one of the big insights
2817.9|3.3|of diploma of Cicero is like this
2820.0|2.819|ability to leverage planning to get
2821.2|3.3|better performance with like uh with
2822.819|2.941|language models and in this strategic
2824.5|1.92|domain
2825.76|2.04|um
2826.42|3.96|I think there's a lot of opportunity to
2827.8|3.96|do that sort of thing in a broader space
2830.38|4.56|of domains I mean you look at language
2831.76|4.14|models today and they do token by token
2834.94|1.8|prediction
2835.9|2.219|um
2836.74|3.3|and I think there's a big opportunity to
2838.119|3.841|go beyond that so that's what I'm
2840.04|3.24|excited to look into I'm also curious
2841.96|3.0|like I didn't understand exact details
2843.28|4.2|how using planning or Monte Carlo
2844.96|3.96|research with your uh like the models
2847.48|4.44|that you have
2848.92|3.0|research
2855.28|4.44|is a very good heuristic but it's a
2857.8|4.2|heuristic that is
2859.72|4.379|particularly useful for deterministic
2862.0|2.94|perfect information games
2864.099|2.76|um
2864.94|3.36|and I think in order to like have a
2866.859|3.181|truly general form of planning we need
2868.3|4.14|to go more abstract than monster College
2870.04|3.84|research we use this algorithm called
2872.44|3.419|pickle
2873.88|3.54|um based on a regret minimization
2875.859|3.061|algorithm I don't really want to go into
2877.42|3.0|the details of it because it's not that
2878.92|2.699|important for the class
2880.42|3.5|um but the idea is like it is this
2881.619|4.081|iterative algorithm that will gradually
2883.92|2.62|refine the prediction of what
2885.7|1.8|everybody's going to do and get better
2886.54|2.42|and better predictions the more
2887.5|3.48|iterations that you run
2888.96|3.76|similar to search
2890.98|4.879|yep
2892.72|3.139|got it yeah
2895.96|2.119|um
2904.359|5.22|so yeah my question is like when we were
2907.0|4.5|talking about gender like the ability
2909.579|5.401|how does the communication between
2911.5|5.16|different modules of the model look like
2914.98|3.48|and particularly when we're talking
2916.66|3.54|about the dialogue model
2918.46|3.3|like how do you send information from
2920.2|3.18|the policy Network to the dialogue model
2921.76|4.02|and in the future if you have a model
2923.38|4.68|that's good at different tasks are we
2925.78|4.02|going to have like a really big policy
2928.06|3.6|net that learns all of them or like
2929.8|4.08|separate language modules for all of
2931.66|4.56|them like how do you break it down
2933.88|3.9|so we actually convert the policy like
2936.22|4.02|the action for ourselves and for our
2937.78|3.839|dialogue partner into uh a string
2940.24|3.599|natural language string and just speed
2941.619|4.681|that into the dialog model along with
2943.839|5.401|all the dialogue that it's had so far so
2946.3|4.14|it's just all text in text out
2949.24|4.079|um
2950.44|4.08|and and that that works great
2953.319|3.5|um and then what was the second part of
2954.52|2.299|your question
2958.119|3.72|something like uh are we just gonna have
2960.22|3.06|like one giant policy net trend on
2961.839|3.841|everything
2963.28|4.44|yeah it was like so if you're only using
2965.68|3.78|text first doesn't it limit the model
2967.72|4.92|and if you're using this for different
2969.46|4.5|uh games like are you thinking like what
2972.64|3.12|you say in the future you will work on
2973.96|4.619|generalizability are you thinking about
2975.76|5.339|a big policy Network that is trained on
2978.579|3.721|separate games or is able to do like
2981.099|3.061|understand different games at the same
2982.3|3.72|time or do we have like separate policy
2984.16|4.679|networks for different games
2986.02|5.099|yeah and yeah like doesn't dislike uh
2988.839|4.26|text interface limit the model in terms
2991.119|4.261|of communication like if you're using
2993.099|5.821|vectors it might like
2995.38|5.34|yeah it might be the bottom link
2998.92|3.179|um I mean I I think ideally you go in
3000.72|3.599|this direction where you have like you
3002.099|4.321|know a foundational model that works for
3004.319|4.321|pretty much everything
3006.42|3.659|um does text I mean certainly uh just
3008.64|3.12|like a text and text out that like when
3010.079|4.26|it's what you can do
3011.76|4.559|um excuse communication but hopefully we
3014.339|4.381|get beyond that
3016.319|3.321|um I think it's a reasonable choice for
3018.72|4.04|now
3019.64|3.12|thank you
3025.16|4.12|now I can get more zoom questions okay
3027.9|2.34|so there's a question in the chat uh I'd
3029.28|2.16|love to hear your speculation on the
3030.24|2.7|future for instance we've seen some
3031.44|3.96|startups that are fine-tuning llms to be
3032.94|4.56|biased uh or experts in say subject
3035.4|4.1|experts okay why
3037.5|2.0|um
3039.599|4.941|this seems like a pretty uh general
3042.06|2.48|question
3046.38|6.719|uh
3048.72|6.5|I don't have strong opinions on this
3053.099|2.121|um
3058.38|4.679|I yeah I mean
3060.359|5.401|like I'm not I'm not too um
3063.059|4.681|I'm not too focused myself on you know
3065.76|3.18|fine-tuning language models to specific
3067.74|2.16|tasks
3068.94|3.419|um
3069.9|4.74|I think the direction that I'm much more
3072.359|3.841|interested in going forward is you know
3074.64|5.64|like the more General forms of planning
3076.2|6.419|so I don't think I can really comment on
3080.28|4.079|you know how do you
3082.619|4.521|tune these language models
3084.359|5.581|um in these ways
3087.14|4.479|so what sort of planning uh methods are
3089.94|4.56|you like interested in looking at like
3091.619|5.341|like MCTS is one
3094.5|5.18|um so let me so I got to step out for
3096.96|2.72|just one second
3099.9|6.54|um got the switch rooms excuse me
3104.46|3.84|okay never mind uh we're all good uh
3106.44|3.36|sorry what was the question oh yes I was
3108.3|2.759|thinking I was just asking like what
3109.8|2.72|sort of planning algorithms do you think
3111.059|3.54|are very interesting
3112.52|3.46|so you think we have like so many
3114.599|3.361|options like we have like Planet kind of
3115.98|3.9|stuff or Auto there's like mcps there's
3117.96|2.82|like the the work you did with sister so
3119.88|2.459|what do you think are the most
3120.78|4.74|interesting algorithms that you think
3122.339|4.441|will scale well uh can generalize
3125.52|2.76|well I think that's the big question
3126.78|3.66|that a lot of people are trying to
3128.28|3.9|figure out today and um it's it's not
3130.44|3.24|really clear what the answer is
3132.18|3.24|um I mean I think you know you look at
3133.68|3.419|some of the Chain of Thought and
3135.42|2.88|I think there's a lot of limitations to
3137.099|2.161|Chain of Thought
3138.3|2.64|um and I think that it should be
3139.26|2.94|possible to do a lot better but it is
3140.94|3.179|really impressive to see just how
3142.2|2.76|general of an approach it is
3144.119|5.46|um
3144.96|5.399|and so I think it would be nice to see
3149.579|3.48|um
3150.359|5.281|to see things that are General in that
3153.059|5.421|in that way um but hopefully able to
3155.64|2.84|achieve better performance
3158.76|3.299|got it
3161.04|2.579|awesome
3162.059|4.441|also will you still like sister is like
3163.619|4.5|a encoder decoder model uh in a sense it
3166.5|2.819|encodes the world and then you have the
3168.119|2.041|dialogue model which is time to record
3169.319|3.421|it
3170.16|4.5|uh it was an encoder decoder model yes
3172.74|3.3|um I don't think that that's necessarily
3174.66|5.28|the right choice
3176.04|6.559|um I I but that's what we used
3179.94|2.659|any questions
3183.78|6.14|okay I think yeah you're mostly good
3187.079|2.841|but yeah thanks a lot
3189.96|2.7|well yeah I hope you all enjoyed it and
3191.52|2.88|if there are any questions feel free to
3192.66|3.919|email me reach out I'm happy to happy to
3194.4|2.179|chat