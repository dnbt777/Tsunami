start_time|end_time|text
0.76|3.96| Yeah, we will be using pytorch quite a lot in this class. And I
4.72|3.0| assume you will also be using it extensively for your class
7.72|3.48| projects. So in this video, I want to briefly show you where
11.2|3.2| you can find out more information about pytorch, like
14.4|4.0| beyond the scope of this class, if you ever need it. So I'm
18.4|3.48| also I want to briefly summarize what pytorch is again. So
21.88|5.0| pytorch is the learning library for pytorch for Python. And as
26.88|3.24| you have seen, it's quite similar to NumPy. So there are
30.12|3.32| these tensors and NumPy with the multi dimensional arrays, which
33.44|4.24| are essentially the same thing. But yeah, beyond that, pytorch
37.68|4.08| has some convenience functions for deep learning. So yeah, I
42.08|4.16| have a summary here, like pytorch at a glance. So pytorch
46.24|3.6| is based on torch seven, which was a deep learning library,
49.84|2.92| very popular, like five to 10 years ago, but it had one big
52.76|4.24| weakness, it was implemented based on Lua. Lua is a programming
57.0|3.68| language, I think they chose it because it was convenient to
60.68|3.68| work with C files in the context of Lua. And Lua was very
64.36|4.36| similar to Python. However, the weakness is it's not Python. And
69.12|4.96| lots of people prefer really working in Python. So around
74.08|5.68| 2016 efforts started like porting torch seven to Python,
79.76|3.44| and the project was then called pytorch. So pytorch initially
83.2|3.72| used a lot of the torch seven code, but it got gradually
86.94|4.86| replaced by more, I would say, rewritten code later on. So but
91.8|5.64| originally pytorch started as a library based on torch seven,
97.68|3.5| that was then but also compatible to Python. And one of
101.18|4.08| its focuses is really on the flexibility and minimizing the
105.26|3.9| cognitive overhead. So there are two aspects you can make a
109.16|3.6| programming framework really easy to use by abstracting a
112.76|3.88| weight all of its complexity. However, one problem is also
116.64|4.58| then if you make it too simple, and provide certain building
121.22|3.5| blocks, it will become hard to do some custom research where
124.72|2.36| you for example, have to develop your own layers and things like
127.08|5.68| that. So pytorch has like a summer in between, it minimizes
132.76|3.28| the cognitive overhead, so keeps keeping things simple. But it
136.04|5.28| also provides you with flexibility for research. Yes,
141.32|4.44| so the core features of pytorch are automatic differentiation.
146.04|3.0| So this is like, when you have a computation, you can
149.04|2.92| automatically compute the derivative. So you don't need to
152.2|3.92| know much math for that, which is very convenient. And also it
156.12|4.32| has these dynamic computation graphs. In contrast to dynamic
160.44|4.52| computation graphs are static computation graphs. And there
164.96|3.6| were some libraries before that, for example, Ciano or early
168.56|3.92| versions of TensorFlow, which were static. So and that was not
172.48|3.92| very convenient to work with. So you had to define a computation.
176.56|2.72| And then after you define the computation, you could run it.
179.76|4.52| But then it was really, yeah, a little bit hard to debug if you
184.28|2.12| had a problem in your computation graph, because it
186.4|4.4| was very abstract. So in that way, pytorch has this dynamic
190.8|4.12| approach, which is more similar to NumPy, where you Yeah, you
194.96|3.36| execute some line of code, or you define the computation, the
198.32|3.52| code, and it immediately runs, you don't have to compile
201.84|3.2| anything, a graph or something like that. So in that way, it's
205.04|4.76| way easier to work with. But I should say this is nothing like
209.8|5.56| pytorch invented, they were inspired by the autograd API, in
215.36|3.04| another library called chainer, for some reason, chainer never
218.4|3.16| really became that popular, although they actually pioneered
221.56|5.44| this API. So autograd is automatic differentiation. So
227.0|2.8| autograd for automatic gradients, it's also a sub
229.8|5.48| library inside pytorch, as we will see later. Yeah, today. So
235.3|3.42| yeah, and pytorch also has NumPy integration. So you can
238.72|4.28| convert NumPy arrays into pytorch and the other way
243.0|3.96| around. However, usually, yeah, we try to avoid using NumPy when
246.96|4.96| we are in pytorch. Because, um, yeah, it makes certain things a
251.92|2.96| little bit clunky if we have to convert back and forth. So
254.88|3.12| usually, we keep using pytorch tensors as long as we can,
258.0|3.36| sometimes it's necessary to convert it from, let's say,
261.4|3.36| exporting results into other tools. But usually, yeah, we can
264.76|4.68| nowadays use most of the stuff implemented in pytorch to do
269.44|4.92| most of our work. I should say also one more thing about how
274.36|4.16| code is implemented in pytorch. So most of the code under the
278.52|3.96| hood is written in c++ and CUDA. That is why pytorch is
282.48|4.28| also very efficient compared to regular Python code. So c++, as
286.76|2.68| you know, is a low level language, very efficient for
289.44|4.2| scientific code. And CUDA is kind of like similar to c++, but
293.64|3.64| it's a language, especially for the GPU. So it's you can think
297.28|6.08| of it as c++ for the GPU. It's like a simple simplification,
303.36|2.68| but it's essentially you can think of it like that. And
306.04|5.0| Python really is like more like a wrapper around the c++ and
311.04|4.12| CUDA code, making everything convenient. So I call that the
315.2|3.82| usability glue, it's like some glue, putting gluing together c
319.02|7.74| plus plus and CUDA to make it easy to use. Um, yeah, so just
326.76|4.68| briefly, why is why are we using pytorch and not NumPy if both
331.44|2.6| are actually also very similar as we have seen in previous
334.04|4.6| lectures. So really, why we use pytorch is really we have GPU
338.64|3.12| support, which is important for training deep neural networks in
341.76|3.8| a time efficient manner. So it can be hundreds 1000 times
345.56|4.84| faster than our training on the CPU, for example. Then yeah,
350.4|4.52| also, it has additional functionality to distribute
354.92|4.24| actually computations across multiple devices like multiple
359.16|3.9| GPUs even, which can also be super helpful for especially
363.06|4.5| very large models. And then there's also the aspect of
367.56|3.48| keeping track of the computation graph, and the operations
371.04|6.68| created that created them. So NumPy doesn't do that. So it can
377.72|3.64| be a blessing and a curse. So if you don't need a computation
381.36|3.88| graph for let's say, computing gradients, it can be memory
385.24|3.9| intensive to compute this graph. But most of the time when we do
389.14|3.5| deep learning, we want to differentiate results. And for
392.64|4.4| that, we can have this graph that pytorch builds in the
397.04|3.74| background for differentiating it for computing gradients for
401.52|2.32| minimizing the loss function with respect to the weights as
403.84|3.8| we will see later. And also, um, yeah, we can deactivate this
407.64|4.44| computation graph. So it's not necessary to have that. So we
412.08|2.4| can actually use also pytorch without that computation graph,
414.48|4.72| as we will also see. So it's really like a really great, nice
419.28|3.06| convenient framework. It's essentially NumPy with
422.36|3.2| additional convenience functions that make our life as deep
425.56|4.0| learning researcher much easier. Also, yeah, I should say, yeah,
429.56|3.24| this is the official website. And we will also I will highlight
432.8|5.56| some aspects from it, like tutorials and documentation and
438.36|2.44| further resources and so forth. So this would be the main
440.8|2.88| website, if you want to learn also more about pytorch main
443.68|4.44| website to visit. Or I should also say one more word about
448.44|5.2| the speed, the speed of pytorch. So according on to the deep
453.64|2.52| learning with pytorch book, which was written by Eli
456.16|6.44| Stevens, Thomas Fiemann and Lewis Antigua, if I remember
462.6|5.84| correctly, so some of them are they are basically main, main
469.6|2.84| contributors also to pytorch, I think Thomas Fiemann, especially,
472.44|3.52| and I have a lot of experience with this framework. And
475.96|3.52| according to this book, based on experiments, or based on the
479.48|4.96| experience, taking Python of the out of the computation loop, only
484.44|4.48| improves performance by up to 10%, because you don't have to
488.92|5.16| use pytorch only in Python. There's nowadays intermediate
494.08|4.48| representation, it's called a torch IR, and there's also a C
498.56|6.0| plus plus API. So you can use pytorch code or torch code in C
504.56|5.08| plus plus only. So just using it without any Python, and the
509.64|3.08| performance is not much different. So this is basically
512.72|4.36| saying that Python is not really detrimental to the performance
517.08|3.16| because some people say, okay, Python is such a slow language,
520.24|3.16| why would we want to do deeper learning in it? Actually, it
523.4|3.8| turns out, Python is really, I mean, it is really slow compared
527.2|2.96| to other languages. But since everything is implemented in C
530.16|7.68| plus plus, and could anyway, there's not much that really is
537.84|2.92| performance prohibitive in Python. So it's really doesn't
540.76|3.24| matter whether we run it in Python or not. The only reason
544.0|5.44| why there's also a C plus plus API for torch is, for example,
549.44|4.2| not all devices support Python runtimes. For example, if you
553.64|4.28| think of a cell phone, like a smartphone, there, you don't
557.92|5.04| really have a pytorch, sorry, a Python runtime. So sometimes it
562.96|3.88| can be useful to use the C plus plus API. It is possible though,
566.84|4.36| and also very easy nowadays to convert, let's say from the
571.24|7.24| pytorch Python model into the C plus plus API. So there's this
578.48|2.68| intermediate representation that I mentioned, and also on the
581.16|3.16| website, they have tutorials for converting between those. So if
584.32|2.96| you ever need to implement a model, let's say on a mobile
587.28|3.68| device, it's not an issue. That's what people nowadays also
590.96|6.76| do very routinely. It's kind of very, very easy. Installation
597.72|3.8| wise, I posted about that on canvas, I think it was last
601.52|3.4| week, with some write up and recommendations. Just to
604.92|5.72| summarize it again, if you have a laptop, I recommend to not not
610.64|3.8| run this on the GPU. Because, yeah, honestly, unless you have
614.44|5.0| a high end gaming computer with a G force, sorry, I think G
619.44|4.56| force Nvidia graphics card, then it will probably get too hot if
624.0|3.48| you run it on a GPU, even if you have a compatible graphics card.
628.48|4.12| Personally, I use only my laptop for debugging. So I usually
632.6|3.52| write all my code on the laptop first, see if it runs on the
636.12|2.84| CPU. And then there's only a very simple switch that we have
638.96|3.08| to make, I can show you to you later in the code. It's like one
642.04|2.6| line of code. And then everything runs on the GPU.
645.04|2.92| And after I made sure that it runs on my laptop on the CPU,
647.96|2.8| like, for a very, like five minutes, very short time, then I
650.76|3.8| would let's say run it somewhere else on the GPU. So my computer
654.56|4.88| personally, I only install the CPU version. And in order to
659.44|4.64| find out how you install it, I also recommend you to visit on
664.08|4.08| the pytorch website. And they have if you scroll down like
668.16|3.8| this menu here, where you would select the version, so I
671.96|3.24| recommend the stable version, then your operating system.
675.32|3.08| Personally, I have a Mac, but of course, you can also use Windows
678.4|4.4| or Linux, if you have either of those operating systems. I use
682.8|4.56| a corner for the installation. And yeah, Python, so you have
687.36|5.04| also the C++ or Java API is here. And I don't use CUDA CUDA is
692.4|5.64| the graphics card library that I mentioned the C++ library for
698.04|3.08| the graphics card. I don't use that one. Yeah, and then I
701.12|3.2| install it like as follows. And notice there is also torch
704.32|4.28| vision and torch audio, which are supporting libraries for
708.72|4.56| computer vision, and audio data. So we will work with torch
713.28|2.36| vision also later in this course. So I just recommend
715.64|4.12| actually installing all in one go. So then you have all
719.76|5.44| everything together. If you have a desktop on Linux, that is, for
725.2|4.32| example, one of my computers, a server I have, it's not at home,
729.52|2.72| for example, it's like in a separate location, I usually
732.24|3.24| only look in via the terminal. But there I would, for example,
735.48|4.6| install GPU version. And then I would install also the latest
740.24|2.56| CUDA version. But you have to make sure if you do that, that
742.8|3.96| you have a compatible graphics card, it is has to be an Nvidia
746.76|4.4| card. And also it has to have a certain driver version to
751.16|4.68| support CUDA here. And for this course, I will on Thursday show
755.84|5.0| you some websites where you can use a GPU for free. So also for
760.84|3.32| this course, you don't need to have like a really lot of GPUs
764.16|3.96| or something like that. It's really only it's sufficient to
768.12|3.88| have access to a free GPU for this course, we we really focus
772.0|4.04| on understanding deep learning and running some introductory
776.08|3.28| deep learning models. And yeah, we are not like a big company
779.36|2.72| running like 1000s of computations on GPUs in this
782.08|3.8| class. So for that way, for that manner, you don't have to buy
785.88|2.56| anything for this class, I will show you on Thursday how to
788.44|4.52| utilize some free resources. Okay. Oh, yeah, also, one
793.0|3.44| little tidbit here. Because there was some message I got
796.44|4.72| also on canvas on Piazza private message where some students
801.2|5.52| tried to import on pytorch. So there's one quirk if you import
806.72|5.2| pytorch, note that it is import torch and not import pytorch. So
811.92|2.12| that's like something to keep in mind. It's a little bit
814.04|2.8| confusing. I think that's because originally, it comes
816.84|3.0| from torch torch seven, like I mentioned, and it pytorch is
819.84|3.12| just the API. So I guess this is why the designers made the
822.96|6.96| choice to import it as torch and not pytorch. All right, so yeah,
829.92|3.24| I wanted to mention if you go to the website, here, there's a
833.16|4.0| tutorials link, there are lots of useful tutorials out there.
837.32|3.36| Of course, you don't have to read them. But I recommend to
840.8|4.04| check out one of them, which is the deep learning with pytorch
844.88|4.24| 60 minute Blitzman. So that's a short video. And there's a short
849.12|3.6| run through, like using pytorch and has a good explanations, I
852.72|2.96| think, to get you started with pytorch. But of course, in this
855.68|2.76| lecture, I will also explain things to you a little
858.44|3.88| differently. So I recommend though, after this class here,
862.32|2.4| after this lecture, I also recommend you to read through
864.72|1.56| this tutorial. It's a really nice one.
867.72|4.0| Yep, that's this one. There's also a pytorch book now. So this
871.72|5.16| is by Eli Stevens, Luca Antigua. It's an old screenshot. I think
876.88|0.52| Thomas
879.32|5.44| Femen is also Femen is also a co author on this book. So you can
884.76|4.68| find the version here on this website, it's available for free.
889.44|3.44| And there's also a print version that is available via the
892.88|4.72| publisher. Um, I should also say there's a very, very nice,
898.16|4.04| friendly community around pytorch. So if you go to the
902.24|3.08| discussion forum here, if you have any questions, like very
905.32|3.64| technical questions, usually someone is always able to help
908.96|3.96| with that. And also usually providing answers pretty fast,
912.92|3.44| which is very impressive. You can see within the last couple
916.36|2.36| of hours, there have been already lots of answers to
918.72|2.88| particular, very detailed questions here. So it's a very
921.84|2.4| friendly and active community there. And it's also a very
924.24|5.04| helpful resource for asking questions. So beyond just the
929.28|4.8| other class context. Okay, so in the next video, I will then
934.08|3.4| introduce computation graphs. And then after we talked about
937.48|3.92| computer computation graphs, I will explain to you how we
941.4|7.56| utilize them for automatic differentiation in pytorch.