start_time|end_time|text
3.64|2.72| Yeah, in this last video of this lecture, I want to give you a
6.36|4.16| brief teaser of pytorch convenience functions, the
10.52|3.84| linear or fully connected layer, but also like to just wrap up
14.36|5.34| the conventions regarding linear algebra. So yeah, what do I mean
19.7|3.54| by fully connected or linear layer? So if we have a
23.24|6.64| multi layer network, like shown here, so this part here would be
29.88|2.92| a linear transformation, if we don't consider the activation
32.8|3.92| function. And you can also think of this as a fully connected
36.76|9.76| layer. So this is sometimes called fully connected layer. Or
46.52|4.8| sometimes people also call that a dense layer. In pytorch, it's
51.32|3.2| called a linear layer because it's a linear transformation. So
54.52|5.08| you can also think of it as a linear layer. And in the context
59.64|6.52| of Keras and TensorFlow, people call it a dense layer. So all
66.16|3.72| these things are equivalent. So another dense layer or fully
69.88|4.16| connected layer would be from here to here. So neural network
74.04|4.36| really is a concatenation of multiple of these fully
78.4|5.56| connected layers, which are then interspersed with these non
83.96|3.72| linear activation functions, for example. So you can do this many,
87.68|4.28| many times. But also, multi layer networks are topic for a
91.96|2.52| different time for a different lecture next week, just
94.52|3.68| outlying already how that relates to linear algebra here.
98.52|3.88| So how we then implement a fully connected layer in pytorch is
102.4|3.96| very simple. There's actually a function called torch and dot
106.4|4.2| linear. So let's start with the data set here. So let's assume
110.6|3.08| I'm just creating some random data. But let's assume this is
113.68|7.32| some valid training data. So this is an design matrix with
121.0|7.2| dimensionality, what do I have here 10 times five, 10 times
128.2|4.6| five input matrix. And then when we initialize this linear layer,
133.6|4.0| we give it a number of features. And the number, so that's the
137.6|3.8| input features and the number of output features. So here, we
141.4|4.24| have five features, like that's our design matrix, the n times
145.64|4.6| m matrix. And let's say we want three output features, the
150.24|4.32| output features, if I go back one slide, are these here, what
154.56|4.72| I highlighted. Well, here, you can think of it as these here,
159.56|4.52| the net inputs. So that's basically the number of outputs.
164.6|4.68| And they are computed via this linear transformation. Alright,
169.28|5.2| so then each of these linear layers, when you initialize it
174.48|4.76| here, has attached as an attribute, a weight matrix, and
179.24|4.8| a bias vector. So the weight matrix, you can see it here is
188.0|6.56| h times m, or in this case, three times five dimensional,
194.56|4.18| right? So you have three rows and five columns, so three by
198.74|4.9| five dimensional, so you can see that this five here matches with
203.64|4.76| this five. So that's the number of input features. And the bias
208.4|3.28| unit is equal to the number of output features. So in this
211.68|5.16| case, it's a vector with three values. So because each output
216.84|3.3| has a bias unit attached to it. So here, we would have five
220.14|4.52| inputs in the next slide example, if I would modify it
224.66|5.78| here, and three outputs. Alright, so and notice here,
230.72|3.76| these are also small random values, we will talk about it
234.48|3.08| later why it's useful to have random values here instead of
237.6|8.18| all zeros. Now, here, I'm printing the dimensions for the
245.78|4.82| input, the weight, the bias. So it's 10 by five, three by five,
250.6|5.48| and three. Now I'm applying this fully connected layer. So I'm
256.08|6.5| applying it to this x, which is 10 times five, and the w, which
262.58|4.66| is three times five, and the output, so there's also plus b,
267.72|3.48| this is a matrix multiplication plus b, which is three
271.2|5.48| dimensional. And the output is what is it 10 times three
276.68|5.72| dimensional, a is a 10 times three dimensional matrix. So how
282.4|4.0| does that work? So what is going on here? So you can already
286.4|4.4| probably see, there must be some transpose here for the w, right?
291.04|5.08| So that the five goes in front, the and the three goes here. And
296.12|2.48| then maybe it's compatible with this x, but is it really what's
298.6|2.96| going on? So yeah, that's what's going on. So yeah, I have a
301.56|5.8| summary of that. So I also have to stare for it or have to stare
307.36|2.84| at it for a few seconds. Let me see what I've written down here.
317.0|3.24| So yeah, based on pytorch, we have another convention here.
320.56|3.6| Recall in the last video, I mentioned the convention where
324.16|4.1| the W the transformation matrix or weight matrix is in front of
328.26|6.78| x in pytorch is it's after x. And I think this makes sense,
335.04|2.56| not from a geometry perspective, but from a data flow
337.6|3.68| perspective, because in this way, we have to use fewer
341.28|4.84| transposes. And also, it's kind of symbolizing the way the data
346.12|3.04| flows through the network. So we start with x, and then we
349.16|4.54| multiply it by a weight matrix w, and then we get a so we have x
353.7|5.6| dot w resulting in a and stuff like that. So it's more like
359.3|5.68| this linear, linear flow here. Actually, I'm writing always a
364.98|3.28| but it's the net input. So depends on whether we apply the
368.26|2.76| activation function or not. Actually, I have it here. No
371.02|5.76| worries. All right. So if we have an input with one training
376.78|4.24| example, like this x here, this vector, then we can use the
381.02|4.16| notation where x is in front, if we transpose w, then the
385.18|4.92| dimensions will match, right. So here, in this case, it's a one
390.1|5.96| times m dimensional vector where w is an m times h dimensional
396.06|5.6| vector. So the result w will be just one value, the result will
401.66|8.96| be then one times h dimensional vector. And if we have n inputs,
410.62|4.8| then we can also keep x in front, we can also transpose w,
415.42|4.44| then in this case, what will happen is that we have an n
419.86|3.76| times m dimensional one here, here, the same m times h
423.62|2.8| dimensional one. And here, we will have an n times h
426.42|3.16| dimensional one. So this way, what is nice about this
429.58|4.44| convention is we can keep the same operations here, whether
434.1|5.28| this is multiple or only one data point. So this is actually
439.38|3.44| quite convenient from a computational perspective. So if
442.82|3.28| we have code, we don't have to change much around. And if you
446.1|3.32| don't believe me that this is the way pytorch does it here is
449.42|3.32| the source code, if you want to look at it. So this is like the
452.74|3.88| common convention in pytorch, how the linear transformation
456.62|4.72| happens. So yeah, just to conclude, I mean, multiple
461.34|3.12| different ways we can compute this linear transformation,
464.78|4.28| what's really important is thinking about it, like, always
469.06|3.24| think about how the dot products are computed when writing and
472.3|3.68| implementing matrix multiplication. So because yes,
475.98|4.16| sometimes it's easy to make mistakes. So things may compute
480.14|2.76| because dimensions match, but it's not computing what you
483.22|3.48| wanted it to compute. So it's always important to write down
486.7|2.52| what the dimensions are, and what you're computing and what
489.22|6.92| you expect the output is. Because yeah, also, theoretical
496.14|3.8| intuition and convention, like having the W in front as the
499.94|3.04| transformation matrix does not always match up with practical
502.98|5.48| convenience, like when we write things in code. So here, I've
508.46|4.12| written down some rules that you might find useful when you're
512.58|3.16| reading textbooks, and things are not the same as, let's say,
515.74|4.76| in code. So you can easily translate between those concepts.
520.5|4.28| For example, if you have two matrices, A and B, multiplying
524.78|3.32| those is the same as B transpose, A transpose, and then
528.1|2.98| taking the outer transpose here. So that's the same thing. And
531.08|4.06| also here, these are the same. So I was just writing down some
535.14|4.4| rules here that help you maybe navigating switches between code
539.54|2.92| and textbooks. I think you probably won't read many
542.46|3.6| textbooks, because there are not many deep learning textbooks
546.06|2.88| really yet, but maybe in the future sometime. But also in
548.94|3.2| papers, people use all kinds of different conventions. So I
552.14|5.44| think this is like a handy thing to keep in mind. And yeah, also
557.58|4.6| just to summarize traditional versus pytorch conventions. So
563.1|2.9| yeah, there are multiple ways we can compute this linear
566.0|3.18| transformation. Like I mentioned, we can have this weight
569.18|6.28| matrix upfront. So this would result in in h times one
575.46|5.08| dimensional vector, when x is a feature vector, m times one
580.54|3.28| dimensional, this is the same using the rule as I showed you
583.82|3.72| in the previous slide as writing it like this same thing. So it
587.54|3.28| gives us a way for the same input gives us the same output.
592.46|3.88| Another way we can write that that is how pytorch does that is
596.34|3.68| putting the x in front. But yeah, we are transposing w here.
600.42|3.82| This gives or this assumes a different input, though. This
604.24|3.9| assumes the one times m dimensional input. And yeah,
608.14|4.56| this is actually my preferred representation, because this is
612.74|5.36| kind of easy when we go back and forth between one or multiple
618.1|3.8| training examples, because now here at the bottom would be the
621.9|3.86| cases where we have n training examples. So if we want to use
625.76|3.14| it the traditional way, we have to use two transposes, which is
628.9|3.52| more work. So this is the usual case in deep learning, we have
632.42|3.98| usually many inputs and many outputs. So we only have to use
636.4|4.18| one transpose, it's shorter. And this is also the way pytorch
640.58|6.28| implements it. So this is also the pytorch convention. So just
646.86|5.44| to sum it up for this lecture. So yes, a little ungraded
652.34|5.12| homework experiment, you may can, if you have extra time,
657.7|4.92| revisit the perceptron numpy code. And without even running
662.62|3.24| the code, just thinking about it, can you tell if the
665.86|4.28| perceptron could predict the class labels? If we feed it an
670.14|4.12| array, actually, underlining it in an unfortunate way, without
674.26|3.32| running the code, can you tell if the perceptron could predict
677.58|3.08| the class labels, if we feed an array of multiple training
680.66|8.64| examples at once. So if we have a design matrix of dimensionality
689.3|6.52| in times m for testing, would it be able to run after training?
696.26|5.2| So if yes, why? If not, what change to the code have we have
701.46|3.92| to make? So you can think of this, and then you can actually
705.42|2.86| run the code right with the design matrix as input for
708.28|3.74| prediction and see whether your intuition was correct. And also
712.02|4.4| feel free to open a discussion on Piazza about that. So yeah,
716.42|4.04| run and verify your intuition. And then how about the train
720.46|4.92| methods? Can we also have some parallelism through matrix
725.38|2.52| multiplications in the train method having multiple training
727.9|3.36| examples? So does it make sense? Without, let's say,
731.3|2.28| fundamentally changing the perceptron learning rule, would
733.58|3.76| that make sense? So it's also another thing to think about.
738.42|6.48| Alright, so next lecture, then we will talk about more like a
744.9|3.56| deep learning topic that is not like fundamental linear algebra,
748.46|2.64| we will talk about a better learning algorithm for new
751.1|3.84| networks. So we learned about the perceptron rule next last
754.94|3.48| week. But this is actually not a very good learning rule. And we
758.42|17.04| will develop a better learning rule next lecture.