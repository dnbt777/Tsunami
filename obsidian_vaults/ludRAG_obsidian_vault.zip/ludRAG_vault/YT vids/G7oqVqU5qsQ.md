start_time|end_time|text
1.68|3.0| Alright, let's now talk about training neural networks with
4.68|3.68| multiple layers. So here on the right hand side, I'm showing you
8.96|1.76| so called multi layer
13.62|0.9| perceptron,
16.0|5.2| which is sometimes also called or it's a feet forward
21.2|7.48| neural network. And it is also a fully
31.28|3.64| connected neural network. So there are two properties here
34.92|5.4| describing that the data data flow is like a forward only one
40.32|3.16| direction. And then it's also fully connected. That means that
43.48|4.0| each unit here is fully connected to another unit. And
47.48|3.88| also notice the word perceptron, although this type of network is
51.36|3.4| not that closely related to the perceptron, because there's
54.76|2.6| another thing going on here, it's not shown in this figure.
57.6|3.4| But we have nonlinear activation functions. And what that means,
61.4|3.36| we will cover this in way more detail in a future lecture. So
65.28|2.24| no need to memorize that here.
68.92|3.68| But yeah, so what this architecture allows us to do is
72.6|4.16| now to solve the X or problem. So the reasons why this can
76.76|2.4| solve the X or problem, even though there's only one output
79.2|3.76| node here, is that it has multiple layers, and also that
82.96|3.34| it has nonlinear activation functions. So these two aspects
86.3|3.84| make it able to solve the X or problem. So here, I have
90.14|3.42| generated some toy data, and I applied a real multi layer
93.56|3.62| perceptron for this data. And I trained to multi layer
97.18|2.8| perceptrons with a slightly different numbers of hidden
99.98|4.3| units. And you can see, in both ways, the neural network came
104.28|3.24| up with solutions for this X or problem. So on the left hand
107.52|3.24| side, it learned solving the X or problem by just having these
111.28|4.24| two parallel binary boundaries. Um, I found this very
115.52|3.32| interesting, to be honest. So yeah, it looks very organized
118.84|3.72| and very efficient. Another way the network could solve the X or
122.56|2.68| problem was here was shown here on the right hand side. So yeah,
125.24|2.4| just change the number of hidden units a little bit. And you can
127.64|3.2| see the solution is quite different. And of course, there
130.84|4.68| are infinitely many solutions to this problem using a multi layer
135.52|4.32| neural network. So we will again talk about this in way more
139.84|3.12| detail later on. But if you're interested also later in this
142.96|3.24| course, if you're interested in drawing neural network,
146.6|3.36| architecture, figures, for example, for your report or
149.96|4.84| proposal, and so forth, here is actually a very nice tool by
154.8|4.96| Alex, the nail, I think, actually, I don't know if this
159.76|5.24| is the last name, or if it's related to AI or something. So I
165.0|3.08| think the first name of this person is Alex, the last name, I
168.08|2.88| don't know. But this is a very nice tool that lets you quickly
170.96|4.44| draw simple drawings of neural networks. They also have
176.12|3.76| drawings for the Linux style and Alex night, Alex net style
179.92|2.28| networks, which are convolutional neural networks,
182.2|5.2| which will be covered also later in this course. Yeah,
187.4|3.72| moving on. So a little bit more about the multi layer neural
191.12|4.12| networks. So they have now the solution to our x or problem
195.24|2.72| with the hidden layers and the nonlinear activation functions.
198.38|3.22| However, there was a new problem when this network architecture
201.6|4.0| was proposed. And the problem was that it was hard to train. So
205.6|4.2| initially, there was no training algorithm for that. So one
209.8|3.56| solution that was proposed at some point was back
213.36|3.36| propagation. So it has been proposed several independent
216.72|3.24| times. So there's actually an article by Juergen Schmidt
219.96|4.24| Huber, who wrote about who invented it first. So there are
224.2|3.36| different resources or literature cited here, which
227.56|3.92| you may find interesting. So it's a blog post listing all the
231.5|3.06| different ways or inventors of back propagation or things
234.56|3.16| related to back propagation. The paper that made it really
237.72|2.84| popular, though, and that showed that it actually works for
240.56|5.2| training, multi layer perceptrons was by Rumelhart and
245.76|5.2| Hinton in 1986. So this was an independent formulation. So they
250.96|3.16| formulated it independently. So by that, I mean, they were not
254.12|3.92| aware of the previous literature. So and this was
258.08|4.6| also the paper then, that made made this really popular where
262.86|2.7| because they really showed that this actually works in practice.
266.56|3.92| And also, later, it was shown that neural nets, such as the
270.48|2.44| multi layer perceptron here with one hidden layer, if it's
272.92|4.0| arbitrarily large, is able to approximate arbitrary function.
276.92|3.74| So it can approximate any arbitrary function with certain
280.66|5.98| precision if the hidden layer has a relatively very large
286.72|5.84| size. But of course, that the ability to approximate arbitrary
292.56|3.28| function doesn't mean it's easy to do that. So it's still hard
295.84|2.88| to train a network in certain cases. So there are other
298.76|2.6| architectures, we will learn about them later, which are
301.36|3.24| suited for or better suited for certain types of problems. But
304.6|3.24| again, this was like a big breakthrough, because now there
307.84|4.88| is this algorithm for training multi layer neural networks very
312.72|4.4| efficiently. And yeah, spoiler. So this algorithm is also still
317.12|5.6| used in common architectures. It's still our most efficient and
322.72|3.84| most popular algorithm for training neural networks. So it
326.56|5.08| has stood the test of time so far. Yeah, and here's a little
331.64|2.92| fun fact about the backpropagation algorithm by
334.76|3.2| Rumelhart and Hinton. So I read this in an interview book,
338.12|4.2| where Joe Fenton talked about how they came up with it. So he
342.32|4.36| said in late 1985, I actually had a deal with Dave Rumelhart
346.68|3.2| that I would write a short paper about backpropagation, which was
349.88|3.12| his idea. And he would write a short paper about autoencoders,
353.24|3.2| which was my idea. It was always better to have someone who
356.44|3.3| didn't come up with the idea, write the paper, because he
359.74|3.5| could say more clearly what was important. So I wrote a short
363.24|3.2| paper about backpropagation, which was the nature paper that
366.44|3.42| came out in 1986. But Dave still hasn't written the short paper
369.88|4.68| about autoencoders. I'm still waiting. So this was from a book,
374.96|2.88| The Talking Nets. It's a little bit old, but it's still
377.88|1.64| interesting. If you're interested, it's like an
379.52|4.2| interview book, like outlining the oral history of neural
383.72|4.12| networks, via interviews with people who worked on neural
387.84|4.8| networks in the last century. And then there was also the other
392.64|2.88| interesting book, Art Architects of Intelligence. It's more
395.52|4.6| recent from, I think it's from 2018, which I read last year. It
400.12|3.0| was also very entertaining. It's like a lot of interviews also
403.12|4.32| with Joe Fenton and many other people who are famous deep
407.44|3.16| learning researchers. So it was another enjoyable read. So if
410.6|2.8| you're interested for pleasure reading these are, this is
413.4|3.7| actually a particular fun book, because also, they ask everyone
417.12|3.52| to give a prediction when AI can be invented. And there's no
420.64|3.56| clear consensus. So some people say the artificial general
424.2|2.64| intelligence that I talked about last lecture will never be
426.84|3.8| invented something it's like 100 years old, and so forth. So it
430.64|3.92| was actually an interesting read. I kind of like that. Okay.
435.68|2.68| Yeah, backpropagation is not the only algorithm for
438.36|3.68| parameterizing neural networks, such as the multilayer
442.04|3.8| perceptron. So there are other types of algorithms. So here,
445.88|4.32| this is from a paper by Lily crap, Santoro, Maris, Ackerman,
450.24|4.12| and Hinton, where they discussed backpropagation and the brain,
454.52|4.88| basically discussing how similar learning algorithm in a human
459.4|4.0| brain could be to backpropagation. Of course, we
463.4|3.84| don't know the answer yet. We know that the brain is probably
467.24|3.84| not using the backpropagation that we are using in for
471.08|2.6| training neural networks. However, it may use something
473.68|3.6| that is somewhat similar to backpropagation. But yeah, I
477.28|2.96| want to go into a discussion about neuroscience and how
480.24|4.64| similar it is to how the human brain works. But yeah, what I
484.88|2.72| found interesting is here, this brief overview of the different
487.6|4.4| types of learning algorithms that we could use for training
492.0|2.36| and neural network. So for example, there would be heavy
494.36|5.64| and learning. So say you are interested in this, in this note
500.0|3.08| here, updating this connection here, heavy and learning does
503.08|4.2| not involve feedback. So with feedback here is meant that if
507.28|2.6| you do a prediction, and then you look at the error, you
509.88|4.36| usually update the network such that the error is minimized. But
514.24|2.8| if there's no feedback, um, yeah, it's not really minimizing
517.04|3.48| the error, what happens in heavy learning is that the connection
520.52|2.92| is strengthened, the more often it is used for making a
523.44|3.84| prediction. So it's not necessarily on improving the
527.28|4.0| error, you can think of it, maybe if you are playing, let's
531.28|3.28| say, if you're playing tennis, and you make a wrong move, but
534.56|3.4| no one teaches you that it is wrong, and you make the move
538.0|2.72| more often and more often and more often. So if you
540.72|3.56| repeatedly, repeatedly make the wrong move in tennis, and no
544.28|3.0| one teaches you that this is wrong, it will be harder to
547.28|2.36| unlearn it later. And it doesn't mean you become better at
549.64|3.88| tennis, if you do a wrong move that is not hitting the ball
553.52|4.36| over the over the net, for example. So another type of
557.88|2.4| learning is perturbation learning. So you make a
560.44|2.8| perturbation, like you put up a weight and see if it's better or
563.24|3.36| not, if it's better, then you keep the weight. Otherwise, you
566.6|3.36| discard it. It's also not very efficient. This is actually very
570.44|4.08| slow. Yeah, backpropagation is actually very efficient. And
574.52|4.76| it's also very good for minimizing the error. So there's
579.28|4.36| another type of learning algorithm where it's similar to
583.64|3.08| backpropagation. But in instead of doing backpropagation, back
586.72|4.52| propagating the errors, it's involving a second network. But
591.24|2.6| according to the paper, also, they admit that backpropagation
593.84|2.48| is sufficient, the most efficient algorithm for
596.56|3.24| minimizing the error, although it may not be what the human
599.8|4.68| brain uses. But in practice, when we develop computers and
604.48|4.12| predictive algorithms, we care about, yeah, low error, good
608.6|3.32| predictions, and so forth. So that's why we are still using
611.92|3.24| backpropagation, because we haven't found anything yet that
615.16|2.72| works better than backpropagation. But this was
617.88|3.84| just a short overview. In this course, of course, when we talk
621.72|4.08| about new networks, we will be focused on backpropagation. He
625.8|3.24| was a nice figure I just saw this weekend from a paper
629.84|3.6| discussing relational inductive biases and other types of
633.44|4.84| biases. So I like this figure because it kind of outlines the
638.28|2.8| different types of neural network architectures that are
641.08|4.72| commonly used. So we have our multilayer neural network or
646.08|0.84| multilayer
648.88|3.8| perceptron that I briefly talked about in this video. And here we
652.68|5.08| assume that the data columns are independent. So this would be a
657.76|2.88| network that you can use with a tabular data set that we
660.64|4.4| discussed in the previous week. So for example, when you think
665.04|4.2| back of your iris data set, where you have iris flowers, up
669.24|4.64| to 150 iris flowers, and then you have the sepal length, sepal
673.92|4.04| width, petal length, and petal width, and then a class table.
678.32|4.44| So this would be something as an input to the multilayer
682.76|3.72| perceptron. And it doesn't really matter in what order
686.48|2.96| these columns are. I mean, once you train the network, of
689.44|3.0| course, then the order matters, because it was trained on this
692.44|3.8| table. But before training, it doesn't matter whether, let's
696.24|3.44| say on the sepal length is here, it could be you can have
699.68|4.92| actually the petal width here, and the sepal length here,
704.6|2.24| there's, there's no difference, you could learn the same
706.84|3.8| network if the columns are in a different order. So there is no
711.08|5.44| assumption about dependence of these features. In contrast, so
716.52|2.48| called convolutional networks, I will introduce them in the next
719.0|6.24| video. convolutional neural, let me abbreviate it nets, they
725.24|2.92| have one assumption that is locality, there's another
728.16|4.0| assumption, equivalence, feature equivalence, but focusing on the
732.16|2.88| locality. Now, it's basically assuming there's some structure
735.04|3.8| that's usually used for image analysis, because you can think
738.84|4.04| of it as neighboring pixels are being related to each other, for
742.88|4.48| example. So if you if you have an image of a person, so let's
747.36|5.44| say two eyes, nose interface. So these pixels are clearly related
752.8|3.32| because they all include the eye, right? So shuffling these
756.12|3.0| pixels, putting one pixel up here, for example, doesn't
759.12|2.84| really make sense. So in that way, there's some locality
762.0|3.92| assumption. So here, in terms of relational inductive basis, you
765.92|4.16| can think of the assumption you make of the data when when you
770.08|3.2| use a certain architecture, or there is something called
773.28|7.72| a recurrent neural network. And this one assumes, for example, if
781.0|4.04| these are actually a little bit maybe unfortunate, not sure why
785.04|3.36| these arrows are pointing down. Maybe we will clear if they
788.4|5.28| would be pointing up as the inputs. In any case, so this
793.68|3.56| would be our assumption where you assume the inputs are
797.8|3.44| sequentially related. So there's an order relationship, a
801.24|4.56| relationship, a sequential relationship. So recurrent neural
805.8|2.8| networks are thus useful for text where you have words in a
808.64|2.36| certain order, it wouldn't make sense to shuffle words in a
811.0|2.76| sentence, because then a sentence wouldn't make sense
813.76|2.84| anymore. In the same way, it doesn't make sense to shuffle
816.6|3.82| pixel in an image, because then you lose the relationship
820.42|3.82| between the images, multi layer perceptron doesn't have such an
824.24|6.0| assumption. So in that way, it is very powerful, you can learn
830.24|2.56| a lot of things we I mean, I just briefly mentioned that it
832.84|3.96| can be regarded as a universal function approximator. However,
836.88|3.32| of course, it's also more challenging if you don't have
840.2|4.26| any prior assumptions. So in that way, leveraging these
844.46|5.16| prior assumptions, that's such as locality or sequentiality can
849.62|2.9| actually make the learning easier. And that is also one of
852.52|3.04| the key ideas behind deep learning. I will in the next
855.56|3.9| video talk about deep learning, how deep learning evolved from
859.46|4.8| simple multi layer networks. Okay, lastly, there's the last
864.48|3.2| architecture here, it's called specified. But of course, this
867.68|2.16| is not a particular neural network architecture. This is
870.48|3.76| here referring to the fact that someone hand codes things how
874.24|5.14| things are related. And this is something that I don't think is
879.38|3.1| easily be implemented. So you would have to hand code this,
882.48|2.56| which is very tedious. So something like that is currently
885.04|3.24| not used in practice in deep learning. So usually we use
888.28|4.56| recurrent neural networks, and commercial networks for images
892.88|4.16| and text. And for tabular data, we can use multi layer
897.04|3.48| perceptrons. Okay, so the next lecture, I will briefly talk
900.52|3.84| about deep learning the origin of the of the name and some
905.16|4.4| developments on how deep learning evolved from multi
909.56|11.52| layer networks.