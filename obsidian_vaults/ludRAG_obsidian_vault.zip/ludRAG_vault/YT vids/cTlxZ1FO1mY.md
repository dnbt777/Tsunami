start_time|end_time|text
0.72|5.08| All right, let's now implement again in pytorch. So here we
5.8|3.72| will start with a simple can, with fully connected layers
9.52|3.88| trained to generate handwritten digits. And I hope this will
13.4|2.84| make these types of things clear that I tried to explain in the
16.24|3.12| previous video. It's very, it's a lot of mathematical
19.36|2.48| notation, it's maybe a bit overwhelming. But you will see
21.84|4.24| in the code example is actually quite straightforward. I
26.08|3.12| implemented several GANs, honestly, it took me quite some
29.2|4.76| time to get a good GAN working. And they're also not great. So
34.2|2.92| they're just simple GANs. So they're not that great. But even
37.12|3.72| then, it took me quite some time because training GANs is quite
40.84|4.04| challenging. So I will in the next video, go over some tips
44.88|2.6| and tricks for that. But even if you consider these tips and
47.48|2.92| tricks, it can still be hard compared to, let's say, just
50.4|4.68| training a classifier. So one of the reasons is, so here, let's
55.08|3.48| say, go over our regular imports and everything. But one of the
58.56|3.04| reasons is that we have now two neural networks that we have to
61.6|3.92| train. So before, we only had, for instance, one learning rate
65.6|3.56| for training a classifier, now we have two models. So we need
69.16|4.4| also two learning rates and can also be hard to find the good a
73.56|4.52| good kind of, I would say ratio between the learning rates. We
78.08|4.32| make this a bit bigger here. So before, we only had to tune one,
82.4|2.44| now we have to tune to the generator learning rate and the
84.84|2.76| discriminator learning rate. And also, we have to find the right
87.6|3.0| relationship, for instance, it could be that this has to be
90.6|3.28| much larger than this one other way around. So again, this is
93.88|5.32| something that has to be tuned, and that just increases the
99.2|5.24| complexity. Alright, so this is just a general setup, besides
104.44|4.48| having no two learning rates. So here we have the data set. Again,
108.92|4.88| nothing special, I'm using the MNIST data set. And here, I'm
113.8|4.56| normalizing the images between minus one and one worked a
118.36|4.8| little bit better than 01. And we are only using the training
123.16|4.24| set here, we are not using the test set for MNIST because GANs
127.4|3.68| are also unsupervised algorithms. So we only need, we
131.08|2.6| don't need labels or something like that. You could technically
133.68|3.64| merge training and test data into one single data set. So you
137.32|3.04| have more data, but I was lazy here. So I'm just using the
140.36|5.04| training set for simplicity. I'm just checking that everything
145.4|4.48| works correctly. Now I'm using this torch vision utils dot make
149.88|2.76| grid function, which is a pretty nice function to make
153.44|2.48| visualization quickly. So
155.92|24.36| okay. Here, it's plotting 64 images and an eight by eight
180.3|3.98| grid. Pretty conveniently. It's just Yeah, basically one or two
184.28|2.94| lines of code, three lines of code. So here, this is a
187.22|3.18| function I will also use later to visualize the results. It's a
190.4|3.54| quite useful function for just making visualizations quickly.
194.12|3.28| So here's just how some of these handwritten digits look like.
198.72|6.36| Okay, so here's the interesting part, the model. So we have now
205.32|3.6| a generator and a discriminator. So I implement this as
208.92|3.14| follows, I use the sequential API for the generator and also
212.06|3.26| the sequential API for the discriminator. So this is a
215.32|3.94| fully connected, again, so I have a linear layer, you have a
219.26|3.36| leaky relu at the dropout. I tried different types of dropout
222.62|3.02| with and without it worked better with with with dropout.
225.64|6.6| But well, it's another thing to tune. It's kind of tricky. Yeah,
232.26|3.68| and like I said, we are using fully connected layers. And
235.94|3.66| because I normalized my input images to be on the minus one
239.6|5.36| one range, we have also a 10 h here, so that the pixel outputs
244.96|2.92| are also in the minus one and one range that they are
247.88|4.04| comparable to the input range. So this is the output from our
252.02|3.22| generator. So the output here are our generated images,
255.24|4.88| essentially, the discriminator is just a classifier. So it
260.12|3.32| receives an input image, we just flatten it so that it goes into
263.44|4.24| our fully connected layer, which has the size image height, image
267.68|3.8| width, and color channels, the number of features, if we
271.48|4.04| flatten an image has been a long time ago, but this is something
275.52|2.56| that you probably remember from the multi layer perceptron
278.08|4.44| class. And then we have a leaky relu here, dropout and output
282.52|3.12| layer with one output node, because we are using the binary
285.64|2.92| cross entropy, we have a binary classification problem here, we
288.56|3.04| could have two output nodes and use the multi category cross
291.6|4.0| entropy. But yeah, for here, I for simplicity, I'm using the
295.6|4.2| binary cross entropy, which is essentially like a regular
299.8|6.44| logistic regression. Okay, so for each for both the generator
306.24|2.64| and for the discriminator, I have a forward function, I have
308.88|4.12| the generator forward here, and the discriminator forward. So
313.0|5.4| the generator forward, the generator will receive input
318.4|3.44| image from noise. So the way I implemented my training
321.84|3.76| function, because I implemented it with convolutional auto
325.64|5.16| generators in mind, I have in the training function, something
330.8|5.48| that creates a noise vector that is in the shape color channels
336.28|3.24| height width. So I'm just flattening it here, that is just
339.52|4.96| a vector. And then this noise vector, this is a noise vector
344.72|5.0| from a random normal distribution. It goes into the
349.72|4.36| generator. So this part is executing this year, this
354.08|4.84| pipeline, which will produce a new image generated image. And
358.94|3.26| since the last day is a fully connected layer, I'm just
362.2|3.4| reshaping it that it outputs also the dimensions, color
365.6|3.76| channels, image height and image width. So what goes into here is
369.36|3.76| also color channels height and width, which is why I'm
373.12|5.4| flattening this year. So let me put this maybe here. Z has
378.52|8.68| dimension CHW. And the output also has a dimension CHW, of
387.2|2.2| course, also the batch size, so we can maybe also add that
389.4|6.24| here. So n, n, c, h, w. Okay, and the discriminator is a
395.64|2.76| little bit simpler here, it's just receiving the input image,
398.48|3.96| which has the flattening here, and then returns the logits for
402.44|7.56| the predictions that this is a real image. Okay, so then we
410.0|2.12| initialize. So this is our model, I will show you the
412.12|3.08| training loop in a few moments. Then one more thing is here, we
415.2|3.48| are initializing our model. And then here we are initializing
418.68|7.24| our optimizers. Here is one important aspect. So first, I'm
425.92|4.64| using Adam for both some people recommend using SGD for I think
430.56|4.52| the generator, I tried different things, this happened to be the
435.08|4.12| best working version that I could get. So you may find
439.24|2.4| better settings in the next video, we'll go over some
441.64|3.32| tricks. But this happened to work well for me took me a long
444.96|3.64| time to find anything that worked at all. Anyways, so one
448.6|3.16| important thing here is that of course, we use the generator
451.76|2.08| learning rate for the generator and the discriminator learning
453.84|2.96| rate for the discriminator. But the more important thing is that
456.8|5.12| we also use the right parameters here. So we have an optimizer for
461.92|4.44| the generator that should only update the generator parameters.
467.48|4.2| And the discriminator here should only update the
471.68|7.44| discriminator parameters. If we had something like this. Well,
479.12|2.88| this would not work well in practice, because then it would,
482.0|4.44| when we take a step here for the optimizer, it would update both
486.44|3.6| the screen and the generator. And this is not what we want. So
490.2|5.44| because if I go back to my slides, long time ago, but in
495.64|4.32| the first video, I think talked about this might be the second
499.96|6.44| video. So we train the discriminator first, while we
506.4|5.0| keep the generator frozen when it gets the fake images. So we
511.4|2.64| only train the discriminator. And then we freeze the
514.04|2.96| discriminator and only to train the generator. So in order to
517.0|3.68| achieve that, we have these two different optimizers where we
520.72|3.76| for one optimizer only train the generator where here, the
524.48|2.96| discriminator remains frozen. And here we only train the
527.44|3.28| discriminator where the generator remains frozen. And
530.72|2.72| then we have the training function here. So I have this in
533.44|3.08| a helper file, because then I can reuse it across my different
536.52|5.28| notebooks. Let me open this here. So should probably at the
541.8|2.96| bottom because it was the last thing I implemented. So here
544.76|3.48| this my training. So this is the training I'm using here. So let
548.24|3.44| me now explain how the training looks like. First of all, we are
551.68|4.2| using binary cross entropy with logits. Why? It's because we
555.88|12.16| have the output here is the logits. And then we are
568.04|5.6| sampling. So we are sampling in each. So first, sorry, we are
573.68|3.4| generating here a fixed noise vector, I'm calling it fixed
577.08|4.6| noise, because we are reusing that one to monitor the progress
581.68|4.32| during training, this will become clear after the epochs.
586.04|4.12| So for now, maybe ignore this part. Let's focus here on the
590.16|2.96| epoch iteration during the training. So for each epoch in
593.12|3.12| the number of epochs, we want to train. This is the same as
596.24|4.0| before, like in any neural network we trained before. Now,
600.44|3.12| we just get the batch size as a variable, so it will be easier
603.56|4.6| to read. And here, we are only concerned with the real images,
608.24|2.36| we don't need the labels. Usually, we had something like
610.6|2.4| the labels here, but we're not using them. So I'm just using an
613.0|3.28| underscore. And Python, the underscore is just like an
616.32|5.08| indicator that this variable is not used. So here we have the
621.4|4.92| real images. And now we create our real labels. So the real
626.32|7.8| labels are ones. So here, real, real is equal to one, and fake
634.12|10.6| is equal to zero. So we create our real labels here. Now, we
644.72|3.24| also generate fake images, this is for the discriminator
647.96|4.92| training. So we create them from noise, right? So here, I have a
652.88|3.86| random normal distribution, I have my batch size. So if I
656.74|5.46| have, let's say 64 real images, I'm creating now 64 fake
662.2|5.22| images as well. And these are from a noise vector, that's the
667.42|3.06| latent dimension here. So if I go back to my slides, this is
670.48|8.84| this noise. Sorry, this noise vector here, sampled from a
680.92|3.16| random normal distribution, you can also use a random uniform
684.08|4.44| distribution, but practically in practice, random normal Gaussian
688.52|3.24| works better. So this is, let's say, if we have a 100
691.76|2.88| dimensional embedding, this would be a 100 dimensional
694.64|4.96| vector. So by default, I set it to 100, I think here, I didn't
699.6|6.2| set it here. Let me see. Yeah, I set the latent dimension to 100
705.8|4.88| here. This will create a 100 dimensional vector. And here I'm
710.68|8.28| reshaping it to an image format. So it's format. And so this is
719.08|4.66| sorry, I was actually here, but the fixed size vector is created
723.74|8.54| the same way. So it's a format in color channels, h w was the
732.28|5.44| other one here. So we are sampling from this random
737.72|5.88| normal distribution with 100 latent size, this is our color
743.6|3.64| channels, because I implemented that with the convolutional
747.32|3.88| autoencoder generator first, and then I did the fully connected
751.2|10.96| one. But this one gets reshaped on this gets reshaped here, so
762.16|2.6| that it will also work with a fully connected layer. So you
764.76|3.38| don't have to worry about this. Okay, now we are generating
768.14|3.94| these fake images from our noise vector, we are calling generator
772.08|4.32| forward, this will generate our fake images. And then we will
776.4|5.96| create our fake labels, which are zero. So fake real labels,
783.72|7.64| label is one. And fake labels, this label is zero, right? This
791.36|3.64| is our fake label. And we will also create our flipped fake
795.0|5.68| labels. So this is our trick that we discussed. Where was it
800.8|7.16| we discussed that here, where we had our flipped labels. So the
807.96|4.0| flipped labels flipped fake fake labels are the real labels. So
811.96|16.24| here, okay, let's do this real label. fake label here. fake
828.28|4.24| labels is one. This is that we use for fooling the
832.52|3.3| discriminator when we train the generator. Now we are training
835.82|8.9| the discriminator here. First, like always, we zero the
844.72|6.12| previous gradients of the model of the discriminator. This will
850.84|4.12| only do that for the discriminator ones. And here, so
854.96|3.72| here, again, we generated the data for training. And here we
858.68|5.58| carry out the actual training. So what we do is we now get the
864.26|4.58| predictions. These are the logits. And the logits would be
868.84|10.88| in the form n times times one, right? So we convert that just
879.72|5.66| to n. Instead of having n times one, we just convert to n, it
885.38|4.8| will be just a vector, instead of n by one matrix, just easier
890.18|2.34| to handle, we're just removing the last dimension, I could have
892.52|4.56| also done a squeeze here. It's maybe easier. It doesn't matter.
897.64|8.24| Okay. Then here, we have the loss, the loss for the real
906.32|3.2| images. So we want the discriminator to predict real. So
909.52|4.24| how we compute the losses as a loss function, again, is if we
913.76|2.64| don't specify anything, it's the binary cross entropy with
916.4|5.24| logits. So we have the prediction logits that's from
921.64|2.88| the discriminator. And this is the real labeled. So these are
924.52|3.84| the ones so we these are the labels, the ones and we want
928.4|5.2| this also to become one. So this is the loss to predict one given
933.6|4.84| that the labels are one. So the real images, and then we do the
938.44|11.16| fake images here, it's the same as before, except now that we
949.6|4.56| have the predictions for the fake images, they were obtained
954.16|3.16| on the fake images here. And here I have the detach because
957.34|4.24| otherwise, it will influence the generator gradient, it's
961.58|2.72| complaining about that. So I'm just detaching it from the
964.3|5.2| generator graph, because I could have probably Yeah, no, it's
969.5|2.94| fine. So yeah, it's fake images.
973.92|3.12| Detaching it from the graph. So I'm not optimizing the generator
977.04|5.32| here, right? The generator is frozen. And then I'm computing
982.36|6.52| the loss here, fake prediction with a fake labels. And these
988.88|3.52| are so fake labels are zero, and we want to make them zero to.
993.12|2.92| So again, we are just using binary cross entropy between
996.04|4.68| labels, we just want to make these labels similar to these
1000.72|3.24| labels, the ones and we want to make the fake prediction similar
1003.96|4.44| to the fake labels, which are the zeros. Then I mean, we could
1008.4|3.84| technically back propagate here and here. But instead of calling
1012.24|3.3| backwards twice, it's more efficient to just add them
1015.54|4.46| together here, and then call backward once. So I'm just
1020.0|3.16| combining the loss on the real labels and the fake labels. So
1023.16|3.7| combining that from here, and here, adding it up, it's
1026.86|3.9| actually not necessary to have the point five, but why not, and
1030.76|3.66| then call the backward and then we update the discriminator. So
1034.6|3.96| this whole thing is training the discriminator. Now we are
1038.56|4.6| training the generator. So we are now using the flipped
1043.2|7.84| labels. So here, we obtained now the predictions on the fake
1051.04|7.08| images, right? So I must before, so this is the same as before.
1058.12|6.24| But now we are using the gradients for the generator. We
1064.36|3.44| want to keep the gradients. So I'm not detaching anything here.
1068.72|5.24| And then I'm computing the loss between the fake predictions and
1073.96|4.2| the flipped fake labels. So the flip fake labels are one right
1078.16|10.96| if I go up again, they are one. And here, the prediction. So the
1089.12|2.4| discriminator will output if it's a good discriminator will
1091.52|4.12| output a zero. But we want to fool it. So we want it to
1095.64|3.88| output a one. But we are not training the discriminator here,
1099.52|3.26| we are training the generator here only. That's why we are
1102.78|4.26| using optimizer generator here, right. And this is also why I'm
1107.04|3.12| not detaching anything here. It's the discriminator here
1110.16|3.4| remains frozen, we are only updating the generator, because
1113.76|6.8| when I go back here, we have only the generator parameters in
1120.56|3.48| our optimizer for the generator. So we are only updating the
1124.04|3.6| generator here, not the discriminator, and the generator
1127.74|3.18| will be updated such that in the next iteration, and will be
1130.92|4.0| better at fooling the discriminator here to output
1134.92|3.0| ones, because the ones will be then similar to these ones here.
1137.92|3.72| So it's trying to make these similar. Alright, so this is
1141.68|3.8| essentially how things work. And then the rest is just logging
1145.48|4.88| purposes. Just printing some results, saving some results. Oh,
1150.36|3.52| maybe one more thing I wanted to mention is I mentioned earlier,
1153.88|3.84| I had this fixed noise here, right? So why am I using the
1157.72|3.12| fixed noise? I'm actually using that in each epoch. So if I
1160.84|5.0| scroll down again, so in each epoch here, I am using my fixed
1165.84|8.44| noise and make a prediction. And then I'm saving my image grid to
1174.28|4.04| just a list. So I have a list here, just to call this images
1178.32|3.16| from noise per epoch. And I'm appending to this list. And then
1181.48|2.2| we can take a look at the generated images during
1183.68|4.76| training. Okay, so let me go to my training here. So this
1188.44|5.04| is training. So you can see the generator discriminator losses
1193.48|3.64| here. So they start out pretty balanced, and they keep kind of
1197.12|4.96| balanced. But honestly, looking at this is not very informative,
1202.44|3.52| except that you don't want to have one going to zero and one
1205.96|2.76| going really high. But other than that, it's really hard to
1208.72|3.44| tell just by looking at these numbers, whether it's training
1212.16|3.24| well or not, you want them to be not going crazy, you don't want
1215.4|3.08| to, like I said, going them going to really infinitely high
1218.48|3.92| or become zero. But except that usually, there's not that much
1222.4|3.02| information you can gain from looking at this. Okay, trained
1225.42|9.12| for 100 epochs. And then here's a loss function. So sorry, loss
1234.54|4.62| plot, I saved everything in this locked dictionary. And then we
1239.16|2.32| have the discriminator loss per batch and generator loss per
1241.48|4.56| batch that I'm showing you here. So kind of, they are pretty
1246.04|5.28| stable here, actually, that's actually good. Oops, somehow, I
1255.4|2.32| don't think I can fix it here, because I didn't run it. But it
1257.72|3.24| should have been an epoch. So that's why it's not showing.
1261.98|5.94| This year was 100 epochs. Anyways. And then the
1267.92|3.44| visualization is the more interesting part. So here, I'm
1271.36|4.02| visualizing these generated images per epoch, and then the
1275.38|6.78| last one. I'm not sure if this is necessary, could have added
1282.16|6.68| actually, plus five here. Anyways, was just lazy. Just
1288.84|3.4| copy and pasting. So this is just train. So plotting from the
1292.24|3.72| fixed noise these images, so you can see the generated images at
1295.96|3.32| epoch zero. So at the beginning, the generator is not able to
1299.28|4.92| produce anything useful. You can see that here. Then after epoch
1304.2|7.52| five, things look a little bit better. Epoch 1015, 20, so
1311.72|3.04| forth, you can see it becomes better and better. Now you can
1314.76|2.68| even see these are sevens. This is a nine. So actually, things
1317.44|4.88| look pretty good. So let's scroll down to the bottom. This
1322.32|5.92| is the last epoch. So you can see, I didn't really improve
1328.24|3.48| that much. You have no issues like here and here. So training
1331.72|4.12| it for longer might not improve. But it's actually given that
1335.84|3.72| this is a very simple, fully connected again, images look
1339.56|3.52| quite reasonable. So not all of them look great, of course. But
1343.72|3.8| well, it's not terrible. I mean, it's learning something, right?
1347.52|6.16| If you compare to the first epochs here, it is learning
1353.68|5.52| something, right? So yeah, this is our first GAN. And training
1359.2|3.16| GANs is tricky, to be honest. So in the next video, I will go
1362.36|21.72| over some tips and tricks for training GANs.