start_time|end_time|text
0.92|3.52| Yes, so in this video, I want to talk about the different ways we
4.44|3.56| can train a neural network. So there's the online mode, the
8.0|4.08| batch mode, and the mini batch mode. And they refer essentially
12.08|4.68| to how we utilize our data when we train a neural network model.
16.88|3.72| So basically how in which water we read the data regarding the
20.6|4.96| training epochs, and also how we update our model. So these are
25.56|4.48| general concepts that apply to any type of neural network. So
30.6|4.56| just to briefly recap our perceptron model here. So here
35.16|2.56| on the left hand side, it is just like, again, a sketch of our
37.72|4.2| perceptron, where we compute the net inputs, and then we update
41.92|5.98| the weights. So here, I mainly want to highlight what's going
47.9|4.02| on again under the hood. So if we have a data set, let's call
51.92|6.24| that data set D with n labels, and sorry, with n training
58.16|4.6| examples, but also n labels where each training example has
62.76|6.36| a feature vector x and class label y. So when we start
69.12|3.64| training on this data set, what we do is we initialize the
72.76|4.08| parameters of the perceptron. So for example, we can set the
76.88|4.64| weights to all zeros, and we can set the bias unit also to a
81.52|4.24| zero. So this is nothing new. This is just like a recap. And
85.76|4.0| then for every training epoch, remember, a training epoch is
91.08|7.6| one cycle over the training set, as I explained, I think it was
98.68|4.04| last week on training set. But if you have questions, always
102.72|3.44| please feel free to feel free to ask on Piazza, I'm always happy
106.16|2.88| to repeat these concepts, because they are quite
109.04|2.44| important. So please don't hesitate if you have any
111.48|3.12| question about what a training epoch is to ask because that's
114.6|2.88| kind of important to make sure everyone knows what we are
117.48|4.28| talking about here. So, so for every training epoch, there
121.76|3.68| could be multiple ones, we can have an arbitrary number of
125.56|3.04| training epochs. In practice, it really depends on the data
128.6|3.12| set in deep learning later on, it's not uncommon to train
131.72|4.32| something for 100 or 1000 epochs, even, even, it really
136.04|3.96| depends on how difficult the problem is. And so for every
140.0|4.12| training epoch, this is our for loop, then we go through each
144.16|3.12| training example one at a time. So that two for loops, one is
147.6|4.16| over the number of training epochs. And one is over the
151.8|8.0| data points in each round. Maybe just to draw this again. So if
159.8|4.88| this is my in pink, if this is my data set a D, I have these
164.68|5.6| different data points here. And this inner for loop here, let me
170.28|3.2| use a different color, maybe green. So this for loop here,
173.48|3.36| what it is really doing is it's just going from one training
176.84|4.68| point to the next one. So one at a time. That's what's going on
181.52|4.24| here. And the outer one, the training epoch one, once we
185.76|4.76| completed going through the data set, we start at the beginning
190.52|3.24| again, and go through the data set again. So that's really
193.76|2.62| what's going on here. So for each data point in the
196.38|2.66| perceptron, what we're doing is we are computing the
199.04|4.52| prediction. So my head is our prediction via the net input.
203.56|3.24| And then we have this threshold function or activation function,
206.8|3.32| which in this case is the threshold function. Then we
210.12|3.76| computed the error. And then based on that we update, so we
213.88|4.88| update here, the weight vector. And we also update the bias
218.76|5.04| vector. So that two updates, notice that the updates happen
224.36|5.24| after each training data point. So again, if I have here in
229.6|3.84| green, if I go to the first example, based on that, I
233.44|9.24| compute y hat, compute the arrow, and then update w, the
242.68|4.8| weight vector and the bias unit. If I have done that, I will go
247.48|4.32| to the second training example and do the same thing again. So
251.8|9.38| I update after each data point. So and this is called the online
261.18|3.34| mode. That is a little bit confusing. It's just I think a
264.52|3.62| historical thing that it was called online mode. Notice also
268.14|4.88| in textbooks, there is usually a dash between the on and the
273.02|3.68| line. This is like old machine learning textbooks. So I think
276.7|3.4| that's probably actually related to the World Wide Web, I'm not
280.1|2.8| quite sure. But I can imagine it is like when the internet was
282.9|2.52| new, you collected one data point at a time. And the
285.42|4.44| advantage is really, if you have a model with online mode
289.9|3.8| training, you can update after each data point. So if you have
293.74|3.64| a model on a web application for each new customer, you can
297.38|3.4| update the model, you don't have to collect multiple customers,
300.78|2.56| for example, to make an update. So you really after each data
303.34|5.08| point, you can make an update if you want to. Um, yeah, so this
308.42|3.5| is just a summary of what I had on the previous slide without
311.92|4.22| any mathematical symbols, just basically for each training
316.14|3.48| epoch, we iterate through the data points, compute the output,
319.94|4.84| calculate the error and update the weights and the bias. So
324.78|5.2| this is the general concept that applies to any kind of kind of
329.98|2.8| new network, not only the perceptron, we have seen that in
332.78|2.8| the context of the perceptron, but this is something you can
335.58|4.04| use also, as we will see later for linear regression, logistic
339.62|2.68| regression, multi layer perceptrons, convolutional
342.3|6.68| networks, and so forth. Um, and there are then some variants of
348.98|2.84| that one is called the batch node mode. And one is the mini
351.82|2.92| batch mode, which are essentially modifications of
354.74|3.96| that. And they have also certain advantages, which we will go
358.7|4.48| over in the next couple of slides. So this is one way you
363.18|4.52| can utilize your data. But there are two other ways one is called
367.74|2.6| the batch mode. And the other one is called the mini batch
370.34|4.28| mode. Just a little spoiler here. In deep learning, actually,
374.62|2.72| the mini batch mode is the most common one. And I will also
377.34|5.8| mention briefly then later why that is. So the batch mode,
383.18|3.08| let's take a look at the batch mode now next to the online
386.26|7.16| mode. So the difference here really is that we collect how we
393.42|3.0| would update the model before we actually update it after each
396.42|3.88| data point. So we still use the same number of data points in a
400.3|3.96| batch mode. But instead of updating after each data point,
404.58|4.28| we collect some information first, and then we do the
408.86|4.12| update. So the update is only really after each epoch. So
412.98|2.72| again, let's take a look at the online mode on the left hand
415.7|2.8| side. So for each training epoch, we go over the data
418.5|3.64| points. And then you can see here inside each of each data
422.14|2.52| point, we update on the right hand side, I have the batch
424.66|3.6| mode, it's a little bit different, we still have a for
428.26|4.16| loop over the training epochs. However, the difference now is
432.42|4.72| that we let's say initialize this placeholder here, it's a I
437.14|4.8| call it delta delta for change. So this is some placeholder
441.94|2.84| here, which I have for the weights and for the bias, that's
444.78|5.04| on, let's call that the placeholder. This is also a
449.82|5.64| placeholder. And then, like on the left hand side here, I'm
455.46|3.44| iterating through the data points. Also, the same thing
458.9|3.6| here, I'm computing the output or the prediction, same thing as
462.54|4.68| on in the online mode. Also, I calculate the error, same thing
467.22|3.84| here. So that's all the same. However, the difference really
471.06|6.84| is here, in this step. So you can see here, I'm updating the
477.9|3.84| weight and the bias directly here, I'm only updating my
481.74|4.38| placeholders. So I'm just accumulating some error terms or
486.12|5.62| some information. And I keep Yeah, I keep accumulating that
493.02|4.44| until I iterate it over every data point in the data set. And
497.46|4.66| then, based on that, after I finished iterating through the
502.12|3.5| current data set here, then I update the weight vector and the
505.62|4.8| bias here. So you can see, I'm now using my placeholder here
510.42|4.84| and here to update these parameters, I just see there's a
515.26|3.24| missing letter that should be a B up front here. So I'm
518.5|4.8| updating both the weight and the bias using the placeholders
523.3|4.4| which have some accumulated information here. So what is the
527.74|4.32| advantage of doing, let's say online and batch mode on. So
532.1|4.38| online mode is an update, one update at a time. So it can be a
536.48|4.66| little bit noisier. The batch mode is a little bit more, I
541.14|3.68| would say robust. So you collect statistics or information from
544.82|4.16| the whole data set before you do one update. The disadvantage is
548.98|4.96| it's a slower mode of updating because you do only one update
553.94|3.48| for each training epoch. And on the left hand side, you do
557.58|3.44| multiple updates each epoch. So on the left hand side, you can
561.02|2.92| think of it as maybe as a faster learning because there are more
563.94|5.64| updates. On the right hand side. They have fewer updates. Each
569.58|3.08| update takes longer because you have to cycle through the whole
572.66|2.32| data set before you make an update. But the update will be
574.98|4.36| more accurate. I will also show you some visualizations of that
579.34|3.48| how that works really in in the context of let's say linear
582.82|5.3| regression or real on your real case scenario. There's no I
588.12|4.42| would say, I would say neither of the two are very common in
592.54|3.74| deep learning though. And I will also tell you why later on it
596.28|3.94| will become obvious, I guess. In practice, there's something
600.22|4.28| called mini batch mode, which is the most common one. I have one
604.5|4.68| more note here about the online mode I just see. Yeah, I
609.18|2.52| highlighted it here in practice, we usually also shuffle the
611.7|5.48| data set to prior to each epoch to prevent cycles. So sometimes
617.18|3.52| it can happen that, for example, in the perceptron case or some
620.7|3.2| other case that the algorithm gets stuck flipping back and
623.9|4.08| forth. So empirically, it's actually better to shuffle the
627.98|3.48| data set prior to each epoch. You can also think of it if you
631.46|5.72| have, for example, the iris data set. If you just load it, the
637.18|4.36| classes will be sorted by class labels. So you have 50 examples
641.54|3.68| from class zero, or 50 examples from class one, and then plus
645.22|4.08| two. And that is also not ideal, because let's say, this is my
649.3|3.8| iris data set, all these are class level zero, and then you
653.1|4.28| have class label one, and then class label two. So if you don't
657.38|3.64| shuffle, the problem is the algorithm will only update based
661.02|5.04| on on the zeros, maybe the zeros are easy. So there's not
666.06|3.6| nothing happening. And then it sees a completely new class. And
669.66|3.92| then it only focuses on getting these right. But then maybe it's
674.1|2.88| getting some other ones wrong again. And it's usually better
677.14|5.36| to have more, a better shuffling a little bit more diversity that
682.5|3.64| you have zeros, ones and twos like intermixed with each other.
686.5|3.28| And also, you have to prevent flipping back and forth, it's
689.78|3.04| just good to shuffle it shuffle doesn't cost much. So in that
692.82|1.92| way, it's not a bad thing to do anyways.
696.58|3.28| Oh, yeah, I should say, the online mode is sometimes also
699.86|0.6| called
703.1|4.16| stochastic mode, or in the context of gradient descent,
707.26|3.08| which we will cover later in this course, it is also called
710.7|4.28| stochastic gradient descent. There's another online mode.
715.5|4.08| Let's call that online mode version two, that is also quite
719.58|3.12| common or used to be quite common. So here, the difference
722.7|3.6| is really that you don't iterate over the epochs, you just say
726.3|5.84| for a given number of iterations, you do the updates.
732.3|3.16| So for a given number of iterations, you say pick at
735.46|4.22| random some data point from the data set. And then you proceed
739.68|3.1| with computing the prediction, the error and the update. So
742.78|2.8| here, really, the difference is you don't iterate over the
745.58|3.56| epochs. The difference also then here is on the left hand side,
749.14|3.88| you guarantee that each data point is used exactly once in
753.02|4.84| each round. Whereas on the right hand side, a data point can be
757.86|5.2| used multiple times in the same number of iterations. So for
763.06|3.76| example, if you have a data set of size n, and you have n
766.82|4.12| iterations, it can be that some data points are used multiple
770.94|3.72| times, whereas certain other data points are not used at all.
775.02|2.48| On the right hand side, this is usually what people call the
777.5|3.24| true stochastic mode. And that is something you'll find
780.74|3.6| sometimes in statistics papers, because it's easier with that
784.34|4.4| one to to derive certain proofs, like theoretical proofs, it's
788.78|3.0| mathematically a little bit easier to handle than the left
791.78|6.24| one. But in practice, so in practice, this is usually used
798.02|2.6| more often because you get better results with that one,
800.9|2.48| because you guarantee that each data point is used in the data
803.38|3.28| set. And each data point is used the same number of times, it's
806.66|2.68| kind of more making better use of the data set in that way.
810.46|3.2| Also, yeah, this is also not truly stochastic, I would say,
813.66|3.84| because, you know, for it to be a truly stochastic, you would be
817.54|3.64| sampling from the distribution here, we still have a fixed
821.18|3.96| size training set. But this is just nitpicking, actually. Now
825.14|4.4| let's get to the most common mode of learning. So this is the
829.58|3.84| mini batch mode, which is a mix between the online mode and the
833.42|3.56| batch mode. So similar to the previous two modes, what we do
836.98|3.76| is we initialize our parameters that we want to update the
840.74|2.92| weights and the bias. And then we also iterate over the
843.66|6.36| training epochs. But now what's new is we also iterate over mini
850.02|5.84| batches. So what is a mini batch, a mini batch is a chunk
855.86|7.84| of the data set. So if this is my training set, you can think
863.7|5.32| of a mini batch as a smaller chunk of the training set. So
869.02|11.32| this would be a mini batch. One, mini batch 234. So what is the
880.34|4.52| size of mini batch? Usually, it really depends on usually common
884.86|4.8| ones you will find in deep learning or something like 3264
890.54|6.48| 128 256, sometimes also 512. It really depends on also the
897.02|3.0| problem. It's like a hyper parameter, something you have to
900.02|3.96| try out and see what works. So there are some papers suggesting
904.18|4.0| smaller batch sizes can accelerate learning because it's
908.18|3.12| noisier and the noise can help making updates a little bit
911.3|4.36| faster. So you have more iterations, larger batch size
915.66|5.64| use or make better use of the GPU. But yeah, it's really, it's
921.3|3.0| really something that depends on practice. And we will also talk
924.3|2.92| more about that when we talk about a technique later on
927.22|4.88| called batch normalization. In any case, um, so this mini batch
932.1|5.04| here, it's then essentially used like batch gradient descent, so
937.14|9.72| everything down here, this is similar to the batch mode,
947.1|4.88| except that you perform the batch mode on this smaller chunk
951.98|4.44| node. So before the batch mode was done on this whole training
956.42|5.76| set, now the batch mode is done on one chunk at a time. So you
962.18|3.44| again initialize these placeholders. And then for each
965.62|2.88| data point in the mini batch, you compute the prediction
968.5|5.0| calculate the error, update the placeholder and then Yeah, then
973.5|5.2| you update the weight and bias unit here. So this way, it would
978.7|2.64| be similar to the batch mode, except that you use one smaller
981.34|5.0| mini batch at a time. And this is usually the most common mode
986.34|3.4| in deep learning. So as a question for you, do you have any
989.74|4.8| ideas why that is? Yeah, maybe pause the video for a second and
994.54|2.76| think about it and see if you have some ideas before I read
997.3|3.28| out loud my notes on the right hand side. So yeah, I've written
1000.58|4.72| down three of the reasons why I think that mini batch is much
1005.3|2.32| more useful than let's say the online model and the batch mode
1007.62|4.2| in deep learning. So one would be that when you're choosing
1011.82|5.36| such a subset, such a mini batch, instead of just one
1017.18|4.2| example at a time, we can take advantage of the vectorization
1021.38|2.92| that we talked about in the previous lecture. So in the
1024.3|2.96| previous lecture, we had seen that we can compute things
1027.26|5.64| efficiently. So when we had, for example, a training matrix
1032.9|5.16| containing multiple entry entries, multiplied by the weight
1038.06|3.44| vector. So if we had that we could process multiple training
1041.5|3.92| examples at a time, which is then faster than in a for loop
1045.62|5.0| executing this multiplication with a vector here. So instead
1050.62|3.16| of using a vector times this weight matrix and doing this
1053.82|4.4| multiple times with a for loop is of course slower than doing
1058.22|4.12| it one time with this matrix multiplication here. So using
1062.34|4.8| this vectorization makes everything or makes the
1067.14|5.2| processing or iterating over an epoch faster in the mini batch
1072.34|5.6| mode compared to the online mode. I'm also having fewer
1077.94|3.72| updates than in an online mode, like including more examples in
1081.66|4.28| each update makes things a little bit more robust, so it
1085.94|4.28| reduces the noise a little bit. On the other hand, yeah, we
1090.22|3.48| could, if these two arguments, if you consider these, then we
1093.7|3.72| can say, okay, why don't we use the full batch mode, the
1097.42|2.82| regular batch mode then, right, because that would be even
1100.24|3.82| faster. And it would be even more robust, because updates are
1104.06|4.32| less noisy. So in practice, actually, um, first, the data
1108.38|3.96| would be too large, a common data set. So this one on a deep
1112.34|3.04| learning data set wouldn't be feasible, we can't just have
1115.38|3.36| millions or 1000s, even of data points here, because then we
1118.74|3.88| would have, say, if we have 10,000, if we have a 10,000 data
1122.62|4.48| point training, so we have a matrix that is 10,000 times,
1127.14|4.68| let's say, maybe also 10,000 for the features in deep learning.
1131.82|9.12| So x would be a 10,000 times 10,000 times matrix. And w would
1140.94|3.64| be then also 10,000 times something matrix. And that would
1144.74|3.92| probably blow up the computer memory. And even if that would
1148.66|5.08| work, actually, the noise is quite good for learning in deep
1153.74|3.14| learning, we will see that later, it helps the algorithm to
1156.88|4.98| escape so called local minima. So in this way, actually, the
1161.86|3.32| mini batch mode also that little bit of noise is good. So in the
1165.18|2.48| online mode, there's maybe too much noise, like from one
1167.66|2.72| training point at a time. But having a little bit of noise,
1170.58|4.52| like having these small batches actually helps. Yeah, and also,
1175.3|3.0| compared to the full batch mode, like I said, here, point three,
1179.1|3.56| we have more updates in the mini batch mode, if for each
1182.66|6.36| iteration over the epoch. So in the batch mode, we only have
1189.02|5.2| this iteration of the epochs and then only update once. So we
1194.22|5.08| apply this only once after each epoch. In the mini batch mode,
1199.34|2.96| we do that multiple times, depending on how many mini
1202.3|3.48| batches we have in each epoch. So in that way, we have more
1206.14|2.8| updates than in the batch mode, which can also help with
1208.94|6.12| learning things faster. Alright, so in the next video, I will
1215.3|2.64| briefly go over the relation between the perceptron and
1217.94|3.76| linear regression. So if things were a little bit, I would say,
1222.58|4.68| yeah, a little bit weird out of context, this is something that
1227.26|4.02| we will be using for the rest of this course. So we will be using
1231.28|2.78| mostly the mini batch mode later on when we train neural
1234.06|3.48| networks. So here was just explaining the different ways we
1237.54|3.16| can process a data set. And this will become relevant when we
1240.7|3.16| start to talk about stochastic gradient descent. So with this
1243.86|2.76| lecture, it's like usually a chicken egg problem, there are
1246.62|3.68| many things or concepts, one depends on the other. And we
1250.3|4.84| have to start somewhere. So now I outlined different ways we can
1255.14|3.16| process the data. And then we will see in stochastic gradient
1258.3|3.9| descent and gradient descent how this actually applies to the
1262.2|6.06| actual updates.