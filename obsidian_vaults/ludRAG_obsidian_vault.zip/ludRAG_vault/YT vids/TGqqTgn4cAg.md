start_time|end_time|text
0.64|3.44| All right, let's now learn how we can translate familiar
4.08|4.28| concepts, such as dropout and batch norm to the convolutional
8.36|2.8| settings. So these are also called spatial dropout and
11.16|3.56| batch norm. And it sounds fancier than it really is,
14.72|3.68| because you will see it's pretty straightforward. And there's not
18.4|3.84| much work required to make these things work for the two
22.24|3.86| dimensional setting where with 2d, I mean, two dimensional
26.1|4.34| images. So before we talked about dropout in the multi layer
30.44|4.42| perceptron context, so why do we even have to invent a new
34.88|2.26| version of dropout? Now, why do we have to modify it in the
37.14|3.74| first place? So that is because I mean, you can, of course, use
40.88|2.76| the regular dropout you learned about before. But there's a good
43.64|4.9| argument by Thompson here in this paper, I linked below that
49.88|4.52| the problem with regular dropout is that in CNN, you usually you
54.4|5.0| have like images where you slide your kernels over the image. And
59.4|3.28| usually the adjacent pixels are likely highly correlated to each
62.68|6.44| other. So if you like remove half of the pixels in a given in a
69.12|0.68| given
71.44|4.68| receptive field, it doesn't really change the output too
76.12|2.44| much, except it's maybe like a little bit of a scaling
78.58|3.76| difference. You can also think of it, for instance, if you have
82.34|3.24| an input, I mean, we are not put masking anything in the input,
85.58|3.18| but just conceptually, it's, let's think about it like that.
88.94|5.5| You have a face image. And here, there are lots of pixels
94.44|6.8| corresponding to the eye. If you consider one pixel here, there
101.88|4.04| other pixels closely next to it, and all these pixels together
105.92|3.6| represent an eye. So it doesn't really change that much if we
109.52|4.12| mask half of these pixels. So here, the argument is to instead
113.64|4.28| of masking, dropping out individual positions in a feature
117.92|3.6| map, we are dropping out the channels. So usually in the
121.52|5.0| later stages of the network, these channels represent higher,
126.92|4.0| higher or larger concepts, as we've talked about in the last
131.72|4.12| last lecture, where we have a bigger picture concepts like a
135.84|3.0| channel represents the eye that was detected one the mouth one
138.84|3.12| the nose and so forth. So here, the idea is really to drop these
141.96|4.28| higher order features in that way, dropping entire feature
146.24|3.6| maps instead of individual pixels. So essentially, drop
149.84|4.52| out to D is drop out applied to the channels rather than the
154.36|3.6| pixel. So you would drop an entire channels instead of
157.96|4.26| pixels. And that's all there is to it. So how do we do that in
162.22|2.34| pytorch? It's pretty straightforward. So instead of
164.56|4.4| saying drop out one D, you are now saying drop out to D. And
168.96|3.64| that's essentially it. So here's an example showing you how that
172.6|5.48| looks like. So each each box here represents one channel. So
178.2|4.16| here I have just some random example input with three
182.36|4.76| channels. And you can see two of these channels are now zeroed
187.12|3.8| out. That's how spatial dropout works. And that's all there is
190.92|4.24| to it. It's not very complicated. The same with batch
195.16|3.56| norms, instead of using batch norm, one D, which we used
198.88|4.64| earlier, when we talked about multi layer perceptrons of fully
203.52|3.4| connected layers, for the convolution layers, we use batch
206.92|4.8| norm 2d shown here. So just to briefly recap, I don't want to
211.72|2.56| explain the batch norm again, because we have a video for
214.28|3.72| that. But in the regular batch norm in the 1d version, we were
218.0|4.02| computing things for each feature. So we were computing
222.02|2.7| this gamma and beta for each feature over the batch
224.72|7.52| dimension. So if n is my batch size here, we have an input that
232.24|6.08| is two dimensional, it is n times m, where let's say, m is
238.32|8.36| the number of features. So this is my input dimension. So we
246.68|3.48| had usually, let's say a table where we have different
250.16|6.4| features, let's call them f1, f2, and f3. So we have three
256.56|7.52| features here. And here, this is our batch dimension. So we were
264.08|9.36| computing for each feature gamma and beta. So they were all
273.44|13.68| different gammas and betas. Let's use yellow. So we had if we
287.12|3.92| had three features, we had three gammas and three betas. Now, we
291.04|3.0| extend this concept here to the two dimensional case where we
294.04|4.36| compute these four inputs that are four dimensional, right,
298.6|4.4| because we have now the batch size, we have the channels, we
303.0|4.44| have the height, and we have the width. So we compute the batch
307.44|6.52| norm now, over the number of inputs height and width. So in
313.96|4.88| that sense, we, we combine these. So we, we average,
319.4|4.64| essentially over these, and we have them the same. So the
324.04|3.2| number of gammas and beta is the one corresponding to the number
327.24|5.0| of channels, if we have 64 channels, we have 64 gammas and
332.24|5.96| 64 betas in that sense. So we are computing it over the number
338.2|4.6| of batches height and width here. So yeah, here is
342.8|3.56| essentially a summary of what I just said, just for your records,
346.36|4.36| if you want to look at it again. Um, yeah, and here's how we can
350.72|5.92| do that in pytorch. So if this is my convolution layer here, I
356.64|10.44| just define the number of input channels and the number of output
368.36|2.68| channels and then oops, and then I apply
373.72|3.72| batch norm to that here, the number of parameters, the number
377.44|2.84| of betas and gammas of batch norm is the number of output
380.28|4.6| channels. So we have to put a 192 here because I have 192
384.88|10.2| output channels, I will have 192 betas and 192 gammas. All right,
395.08|4.12| that is it. In the next video, I will briefly recap that there
399.2|3.16| are different architectures around there. And then we will
402.36|17.28| talk about VGG 16. And resnet.