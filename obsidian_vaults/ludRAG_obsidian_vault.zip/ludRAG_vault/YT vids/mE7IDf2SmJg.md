start_time|end_time|text
5.799|7.041|hey guys welcome to the our last lecture
8.679|7.881|um of this quarter and we're very happy
12.84|6.96|to have a daa here he's a the CEO of
16.56|5.68|contextual AI um the Enterprise llm
19.8|5.399|company as well as an Adjunct professor
22.24|4.56|in symbolic systems here at Stanford and
25.199|3.601|previously he was the head of research
26.8|5.4|at hooking face and before that a
28.8|5.439|research scientist Facebook AI research
32.2|4.039|uh he received his PhD and masters from
34.239|3.801|the University of Cambridge um as well
36.239|4.241|as a master in logic from the University
38.04|5.039|of Amsterdam and studied philosophy and
40.48|4.759|cognitive AI in undergrad um and his
43.079|4.96|work focuses on machine learning as well
45.239|4.881|as NLP specifically on developing better
48.039|4.52|models for language understanding and
50.12|5.88|generation and better tools for
52.559|5.721|evaluation and Ben yeah give it up for
56.0|4.84|Adella
58.28|4.64|right thank you so I guess I have to
60.84|5.52|sort of stand here in the corner so
62.92|6.879|people can see me on the zoom as well um
66.36|5.6|yeah thanks so much for having me here
69.799|3.36|um so I asked Steph what I should talk
71.96|3.72|about there were a couple of things I
73.159|5.161|could talk about multimodality or
75.68|5.16|evaluation uh and this was the preferred
78.32|6.04|topic I guess uh because the others were
80.84|5.12|already covered um so yeah I'm I'm very
84.36|4.6|happy to talk to you about everything
85.96|5.4|retrieval augmentation um I think this
88.96|5.04|is really one of the topics right now in
91.36|4.719|our field um so I I'll just give you an
94.0|3.88|overview of what's been happening and
96.079|5.201|what I think are the interesting
97.88|5.48|questions to think about um so first of
101.28|5.08|all obviously in case you've missed it
103.36|5.119|we are in the age of language models um
106.36|4.799|and I just wanted to do a quick poll
108.479|4.0|here in this not not super big audience
111.159|4.56|I guess there's more people on the zoom
112.479|5.881|but uh who invented language
115.719|6.04|models if if you thought open AI then
118.36|6.039|I'm angry with you right so so actually
121.759|4.64|uh this is a very very old idea so the
124.399|3.481|idea is just you you take a sequence and
126.399|5.161|you factorize out the token
127.88|6.2|probabilities right and um so it wasn't
131.56|4.52|invented by open AI it's not like a few
134.08|4.92|years old it's actually several decades
136.08|4.2|old uh so I'm bringing this up because I
139.0|3.239|was talking to someone and they were
140.28|4.56|like open AI invented language models
142.239|5.561|and I was like you're kidding me right
144.84|4.64|um so um I I I went back to the
147.8|4.04|literature and this is the oldest one I
149.48|4.8|could find actually 1991 first neural
151.84|4.759|language model um there's a very nice
154.28|4.679|paper from 2003 from
156.599|4.041|pjo where they they actually have like
158.959|4.841|word embeddings and everything already
160.64|6.319|in there uh so obviously these are LMS
163.8|4.76|not llms um and as it turns out if you
166.959|3.92|make them really big and you
168.56|3.679|parameterize them with these massive uh
170.879|2.961|neural Nets then you get something
172.239|3.72|really powerful that really shows
173.84|5.64|emerging uh properties right and that's
175.959|5.56|why we're all excited in this stuff um
179.48|3.96|so if we think about this from like a
181.519|3.881|classic CS perspective there's input
183.44|4.48|output right there's this kind of thing
185.4|4.8|in the middle it's the generator so uh
187.92|4.599|we take a sequence the input sequence
190.2|5.36|and then the the task of the model is to
192.519|5.921|predict the next token very very simple
195.56|4.44|model um and and so you know that's why
198.44|3.96|it was so easy to come up with this in
200.0|5.56|1991 already because it's like the idea
202.4|4.759|is very intuitive but for a long time
205.56|5.679|what was really broken with this was the
207.159|5.921|user interface um and and this I think a
211.239|4.241|lot of people kind of misunderstand what
213.08|4.92|Chad gbt was about that's really what
215.48|4.16|Chad gbt fixed right so that in
218.0|3.799|initially you had to come up with these
219.64|3.72|very weird prompts in order to get your
221.799|4.401|language model to do what you wanted it
223.36|4.68|to do uh and humans are terrible at this
226.2|4.2|right so so we're much better at sort of
228.04|4.32|telling people or things around us what
230.4|4.36|we want right so if we have a dog we say
232.36|4.879|sit we don't prompt it in a very weird
234.76|3.8|way so that it sits right and it's the
237.239|4.2|same with the language model if you
238.56|5.2|wanted to generate some R lyrics in the
241.439|4.16|style of a pirate or Shakespeare or
243.76|4.199|something then you tell it generate some
245.599|4.521|R lyrics in the style of a pirate right
247.959|4.041|so that kind of instruction data
250.12|4.52|actually turns out to be super super
252.0|4.239|rare in just web data so what you need
254.64|4.08|to do is you need to fix the user
256.239|4.761|interface to the language model and the
258.72|4.039|the classic recipe for doing that is the
261.0|3.44|the sequence basically that chat gbt
262.759|3.44|used right so you promp the model in a
264.44|4.88|specific way you instruction find in the
266.199|5.72|model and do you do some alignment rhf
269.32|4.599|uh whatever you do on top of that so
271.919|4.081|that's the first thing so now you have a
273.919|6.161|working language model with a working
276.0|6.12|user interface so are we done then um
280.08|3.64|obviously we're not right so so right
282.12|3.24|now language models are are kind of
283.72|3.6|taking the World by storm but if you
285.36|3.44|talk to anyone especially in an
287.32|4.4|Enterprise for example where they have
288.8|4.239|very strict uh accuracy requirements
291.72|4.039|they will tell you that they can't
293.039|4.041|really productionize this yet um and the
295.759|2.761|reason is because there are all these
297.08|3.08|familiar problems probably a bunch of
298.52|3.6|you are working on these problems right
300.16|4.12|now uh around
302.12|3.799|hallucination um so these models they
304.28|4.44|kind of make up stuff very often with
305.919|5.601|very high confidence which is uh even
308.72|4.199|more scary in a way attribution so we
311.52|3.84|don't really know why these models are
312.919|4.081|saying what they're saying Stillness
315.36|3.679|they go out of date and so this was a
317.0|3.639|big problem with sort of chat GPT not
319.039|3.401|knowing anything that happened after a
320.639|3.361|certain cut off date and they keep
322.44|3.16|updating it every once in a while but
324.0|3.68|you want to have a system that's always
325.6|4.08|completely up to date that never goes
327.68|4.32|still um you want to be able to to
329.68|4.799|revise the information in the system so
332.0|4.88|uh if you're uh a European organization
334.479|3.84|you have to worry about gdpr uh which
336.88|3.159|means that you need to be able to remove
338.319|4.201|information from the language model or
340.039|4.241|maybe Revis facts uh which we don't
342.52|4.399|really know how to do right so again
344.28|5.24|this is a very interesting uh area of
346.919|4.361|study for a lot of folks model editing
349.52|4.399|um but so this is something that we
351.28|4.28|really want to be able to fix and then
353.919|4.601|there's this big question of how do you
355.56|4.479|customize these models uh so different
358.52|3.32|people have different use cases you have
360.039|3.201|different data if you're a company or if
361.84|3.52|you want to have a language model on
363.24|5.72|your own data how do you make it work on
365.36|5.76|your own data so one of the solutions uh
368.96|3.76|that everybody has started using right
371.12|4.079|now is to couple it to an external
372.72|5.039|memory so that's really just rag right
375.199|5.641|the uh we we can this whole lecture is
377.759|5.601|basically about rag uh but the way to
380.84|4.28|understand uh what is going on here is
383.36|3.64|uh we have this generator just like
385.12|4.639|before we have the input and a prom just
387.0|5.16|like before but now uh instead of just
389.759|4.481|those two things we give this additional
392.16|5.36|context so we contextualize the language
394.24|5.84|model using things we retrieve and and
397.52|4.679|the retriever uh is is very often pretty
400.08|4.72|simple it's just a query in a documents
402.199|4.321|encoder um and then you get a bunch of
404.8|4.44|documents you give them as context
406.52|6.64|through the model so super simple
409.24|5.56|architecture um and I think it's useful
413.16|4.719|to think about it from the perspective
414.8|4.88|of of these two separate paradigms uh so
417.879|3.961|if you've ever taken an exam I'm sure
419.68|3.72|you have right uh you can have a close
421.84|2.88|book exam where you have to memorize all
423.4|3.799|of this so you have to cram all the
424.72|5.0|knowledge into your parameters your
427.199|4.201|neurons uh or you have an open book exam
429.72|3.24|where you have all of this information
431.4|4.359|in the book that you can access when you
432.96|4.32|do the exam uh so it's a very similar
435.759|3.12|thing with rag right you can just make
437.28|3.84|it an open book setting where you give
438.879|4.88|it access to this external information
441.12|5.079|Wikipedia or something else or basically
443.759|4.12|the entire internet uh and then have the
446.199|4.0|language model do its job without having
447.879|4.801|to memorize all of it in it
450.199|4.801|parameters um so the other I think
452.68|4.04|useful distinction here is that uh
455.0|4.28|cramming everything into your parameters
456.72|4.24|that's the parametric approach right so
459.28|3.84|U what we're doing with rag is we're
460.96|4.72|adding this non-parametric retrieval
463.12|5.44|component um so uh you might call this
465.68|3.84|semi- parametric um if you want to give
468.56|3.759|this a
469.52|6.239|name all right so why why does that
472.319|5.201|actually solve these issues and so the
475.759|3.961|answer is basically that if you have
477.52|4.2|this separate Index right this separate
479.72|4.12|retriever you can swap it in you can
481.72|4.56|swap it out you can replace it with a
483.84|4.079|new index so you can really customize it
486.28|4.52|and so you can customize your language
487.919|5.441|model system for what the user really
490.8|5.119|wants to see um and then obviously you
493.36|4.48|can update this index so um it doesn't
495.919|4.24|really go still and you can revise it if
497.84|4.52|everything goes wrong if anything goes
500.159|4.361|wrong uh the other thing you get is
502.36|4.04|grounding right so that that's initially
504.52|3.28|why I became interested in this kind of
506.4|3.32|architecture because I was thinking a
507.8|3.359|lot about grounding and multimodal and
509.72|4.04|things like that and actually one really
511.159|4.12|nice way to ground things is to find
513.76|3.92|some other information that you can
515.279|3.921|ground your generation in so you really
517.68|4.159|want the language model to only say
519.2|5.36|things that it has evidence for in this
521.839|4.921|outer piece of text or even multimodal
524.56|3.399|data that it retriev separately so if
526.76|2.639|you do that then you get less
527.959|2.921|hallucination because you can always
529.399|3.961|point back to your Source it's always
530.88|3.92|grounded in your Source um and you get
533.36|2.919|attribution because you know why the
534.8|4.2|model is saying what it's saying it's
536.279|4.921|because it founded this thing here is
539.0|2.2|that
542.0|4.8|all right so um for the rest of this
545.079|5.32|lecture we're going to talk about this
546.8|5.279|this basic architecture um and so it
550.399|3.521|kind of looks like a pretty simple thing
552.079|4.2|right uh but there are actually lots and
553.92|4.599|lots of questions you can ask about what
556.279|4.481|what this system should really look like
558.519|4.681|um and like this this doesn't even cover
560.76|4.28|like half the questions you can ask so
563.2|4.879|it really is about how how do we
565.04|4.479|optimize this entire system right so we
568.079|4.721|have the separate components the
569.519|5.081|retriever the generator and then um
572.8|4.36|there are things like this query encoder
574.6|4.76|how do we encode queries how do we uh do
577.16|5.48|the retrieval do we update the document
579.36|4.8|encoder how do we actually uh Define a
582.64|3.36|document right is it like a full
584.16|4.52|document or is it a paragraph or a chunk
586.0|5.04|or a sentence or a couple of words um so
588.68|5.12|there are lots of questions to ask and
591.04|4.52|and uh as you'll see there are lots of
593.8|4.8|possible answers to these questions as
595.56|4.6|well um so this is what we'll we'll
598.6|4.52|cover
600.16|5.359|um so there are lots of
603.12|4.56|architectures um going into these
605.519|5.0|questions and I think as we go through
607.68|4.44|them it's useful for you to think about
610.519|4.0|what happens during training time and
612.12|4.68|what happens during test time right so
614.519|4.361|during training time is really uh okay
616.8|5.08|we have this language model we have this
618.88|4.92|retriever um which one do we update how
621.88|4.0|do we update them how do we train this
623.8|4.2|entire system do we maybe not train it
625.88|4.6|at all uh do we pre-train it from
628.0|4.2|scratch do we initially I it with uh
630.48|3.56|components that were already separately
632.2|3.199|trained these are the kinds of questions
634.04|4.039|that that you have to answer if you want
635.399|5.68|to design a system like this and then
638.079|5.0|during test time uh you have this entire
641.079|6.121|system right so actually multiple models
643.079|5.801|in a way uh that are working together um
647.2|3.199|so so there's also different things you
648.88|3.8|can do there right so give it different
650.399|4.161|indices during test time or uh
652.68|2.959|manipulate kind of how you're sampling
654.56|4.64|things like
655.639|5.081|that so um the starting point for all of
659.2|3.759|this stuff I think if you ask someone
660.72|6.119|now like what is rag they will think of
662.959|6.201|this thing um so this is frozen rag
666.839|3.961|basically uh there's no training here at
669.16|3.679|all so going back to this question of
670.8|4.08|train time test time there's only test
672.839|4.041|time here train time happen separately
674.88|3.92|with these kind of blackbox models that
676.88|3.88|we don't necessarily have control over
678.8|4.64|right so there's this document embedding
680.76|5.72|model uh whatever is currently at the
683.44|6.44|top of some open source uh leaderboard
686.48|5.88|uh you use that to oop sorry uh to get
689.88|4.8|some vectors that you then use to create
692.36|4.32|this Vector database and then the vector
694.68|4.159|database just does search and it gives
696.68|4.8|the information from the search to the
698.839|5.601|language model and it just passes it as
701.48|5.039|uh as the context right so this is this
704.44|5.72|only works because of in context
706.519|6.44|learning um and you know I think as a as
710.16|5.52|a machine learner myself this feels very
712.959|4.921|inelegant um so what what this lecture
715.68|3.88|is about is can we do better than than
717.88|5.92|this Frozen
719.56|6.04|thing um so let's let's start from the
723.8|3.599|the left side of this like okay if we
725.6|3.919|want to outperform this Frozen thing
727.399|3.88|itself with just the vector database
729.519|3.401|like what would that look like from a
731.279|3.761|retrieval
732.92|5.039|perspective um and the starting point
735.04|7.039|for everything retrieval is is tfidf
737.959|7.521|does everybody know what tfidf is no
742.079|5.44|okay so so tfidf is basically a sparse
745.48|5.159|retrieval method where you have a score
747.519|6.12|function uh that that looks at documents
750.639|4.721|and queries so D and Q and then there
753.639|3.801|are basically two terms that matter one
755.36|4.2|is the TF the term frequency and the
757.44|4.199|other is the IDF the inverse document
759.56|3.839|frequency so this inverse document
761.639|4.281|frequency is actually a really nice idea
763.399|4.961|from Karen spark Jones really underrated
765.92|5.159|researcher she's done some amazing work
768.36|4.68|um but the basic idea is that you want
771.079|3.76|to look at the words that are very
773.04|3.64|special so that don't occur in lots of
774.839|3.8|different documents and so the overlap
776.68|4.279|between the word the doesn't really
778.639|3.76|matter matter right like the occurs
780.959|3.721|everywhere so you want to have sort of
782.399|4.44|the special words so that's what what
784.68|5.44|tfidf does in a nutshell it gives you a
786.839|5.56|score for document query overlap and
790.12|4.0|then you can do all kinds of things here
792.399|3.321|with how how you weigh it so there's all
794.12|3.92|these weird different parameters like
795.72|5.119|this B and things like that that allow
798.04|4.88|you to make it better than just having
800.839|5.081|the the tfidf score so there's a couple
802.92|4.32|of tweaks you can do there so bm25
805.92|3.4|actually in case you're wondering stands
807.24|4.24|for best match 2
809.32|4.879|so I I try to discover like where does
811.48|5.799|the 25 actually come from uh that's
814.199|5.2|because the the prior s the preceding 24
817.279|3.92|experiments failed right so it's
819.399|3.44|literally the 25th one that seemed to
821.199|5.64|work and that's why it's called
822.839|6.12|bm25 it's bizarre right but um um so so
826.839|3.761|this is spars retrieval it's just
828.959|4.281|counting words right so you have this
830.6|4.44|massive massive Vector of all these word
833.24|3.8|occurrences it's sparse because most
835.04|6.039|words never occur right so it's sort of
837.04|6.239|like a vector of uh vocabulary size
841.079|5.161|dimensions so most of that is obviously
843.279|4.92|zero um but so that's actually kind of a
846.24|4.32|nice property if you want to do fast
848.199|5.241|search on a CPU right because on a CPU
850.56|6.399|sparse uh do product is very easy to
853.44|6.44|compute so um this is used in in the
856.959|5.521|system called uh Dr QA which is really
859.88|4.84|one of the first neural instances of
862.48|5.2|this open domain sort of open book
864.72|4.72|question answering Paradigm um so you
867.68|4.44|have a question like how many of
869.44|4.959|warsaw's inhabitants blah blah uh so you
872.12|3.88|want to ask basically Wikipedia what the
874.399|4.521|answer is for this so then you have this
876.0|5.519|document retriever based on the sparse
878.92|6.0|so bm25 I think in this case uh
881.519|6.12|retrieval methods you pass that to um at
884.92|5.919|this I think this was still by lsdm at
887.639|6.64|the time um a document reader model and
890.839|5.201|then that model gives you the answer um
894.279|3.201|so this I think is really the first
896.04|3.479|instance of having sort of this
897.48|4.52|separation between a retrieval and a
899.519|4.32|generator system that you use for
902.0|3.839|answering complicated questions based on
903.839|6.44|sort of open domain
905.839|6.041|knowledge um so after The Spar stuff um
910.279|4.0|there was a bunch of work on dense
911.88|4.36|retrieval and and so the advantage of
914.279|3.92|dense retrieval so this is just like
916.24|3.56|word and Benes basically vectors right
918.199|4.121|they're they're dense now no longer
919.8|5.12|sparse so they're much uh smaller in
922.32|4.72|terms of dimensionality and the nice
924.92|3.919|advantage of of dense retrieval is that
927.04|4.76|it's not really about specific work
928.839|6.281|right so uh if there're synonyms you can
931.8|4.479|still um find the relevant document uh
935.12|3.0|which you couldn't really do with a
936.279|3.841|sparse representation right so that's
938.12|3.8|really the advantage of DSE is that you
940.12|5.159|get like semantic
941.92|4.919|similarity um so you can do this over
945.279|3.721|word embeddings that doesn't really work
946.839|3.68|all that well but uh at the time that
949.0|3.079|people started thinking about this ber
950.519|3.161|was already out there and ber is really
952.079|3.56|great for giving you a vector
953.68|3.839|representation for an entire sequence of
955.639|3.841|words right so a sentence representation
957.519|3.481|or a passage representation
959.48|4.88|so there are all these cool systems like
961.0|7.12|Orca and uh DPR the dense passage
964.36|5.479|retriever where um they essentially use
968.12|4.48|the retrieval as a kind of latent
969.839|5.0|variable in the system U and and the way
972.6|4.32|to get the latent variable to to work to
974.839|4.321|be good enough essentially to train the
976.92|4.8|entire system is to pre-train the
979.16|5.359|retriever on uh relevant information so
981.72|5.44|for Ora they do something called inverse
984.519|4.721|close uh so they do kind of a close task
987.16|4.479|where you want to find
989.24|5.079|um passages that are sort of relevant to
991.639|5.0|the preceding passage and in DPR they
994.319|4.601|just train it on on a supervised thing
996.639|4.241|but really the core idea here is that uh
998.92|4.839|as you can see in this graph here you
1000.88|4.439|can do better than bm25 if you add lots
1003.759|3.401|of documents and the way you compute
1005.319|2.88|this score function is much simpler it's
1007.16|5.359|just a d
1008.199|7.12|product right um so the nice thing about
1012.519|6.24|D products is that you can do them very
1015.319|6.0|very efficiently on the GPU as well um
1018.759|5.28|if you uh know what you're doing so what
1021.319|4.6|you really want to get at is maximum in
1024.039|3.88|product search mips right this is one of
1025.919|6.241|the kind of core ideas of a lot of this
1027.919|6.801|stuff um and you can do mips with Ann
1032.16|5.159|approximate near neighbor search um and
1034.72|4.479|so there's this this really uh brilliant
1037.319|4.801|piece of work out of there for my
1039.199|5.161|colleagues at the time uh called phas
1042.12|5.079|which really underlies all of these uh
1044.36|4.12|modern Vector databases right so like
1047.199|3.321|all the popular ones they sort of
1048.48|3.8|re-implementations of this face idea one
1050.52|3.96|is in like rust one is in go but it's
1052.28|5.68|all basically the same idea it's just
1054.48|5.84|face um and so so face really Powers a
1057.96|3.88|lot of this stuff um and whenever
1060.32|3.719|somebody tells you something about a
1061.84|4.839|vector database just think about face
1064.039|5.76|very fast do
1066.679|7.281|product um so obviously you can go
1069.799|6.681|beyond do product yes what is it what is
1073.96|6.44|face um so so it's an open source
1076.48|3.92|Library Facebook AI similar
1082.12|5.559|search no so it's just basic off the
1084.919|2.76|shelf Ann
1089.72|4.12|algorithms yeah so so there are all
1092.039|2.76|kinds of different I don't know if you
1093.84|3.24|do you know what like product
1094.799|3.921|quantization is and things like that so
1097.08|4.28|there they're basically so you have a
1098.72|4.959|bunch of vectors uh and you can just
1101.36|3.96|compute the full dot product which is
1103.679|4.801|sort of inefficient right so what you
1105.32|5.239|can do is try to compress uh subspaces
1108.48|3.12|of the vector and then just look at the
1110.559|4.161|kind of
1111.6|5.12|centroids um so this so you can quantize
1114.72|6.0|sub vectors of the full vector and then
1116.72|4.0|do much faster search over just the
1121.159|4.201|centroids it's good question any other
1126.0|6.2|questions um all right so so about this
1129.52|4.6|dot product idea right so so what we
1132.2|3.839|have here is some people call this a
1134.12|5.08|Siamese Network I guess it is right so
1136.039|4.88|you have two different bir models uh or
1139.2|3.359|whatever your encoder is here and then
1140.919|3.401|at the end you get these two vectors and
1142.559|3.961|then you just do do product so you get
1144.32|4.28|one single score but you can do all
1146.52|3.84|kinds of much fancier things if you if
1148.6|5.199|you're willing to give up on this buy
1150.36|5.08|encoder uh approach right um so really
1153.799|3.921|nice example from from one of your
1155.44|6.28|colleagues here at Stanford uh is
1157.72|6.56|Colbert um so what this does is is late
1161.72|4.4|interaction uh so so instead of just
1164.28|4.519|having this dot product here you have a
1166.12|4.84|kind of more complicated uh
1168.799|3.721|version of computing a score where you
1170.96|3.199|aggregate over sort of Maximum
1172.52|4.08|similarity scores between different
1174.159|3.841|words so I only recently actually
1176.6|3.88|discovered that this is called Colberg
1178.0|5.12|because of the late night show Colberg
1180.48|5.28|so it's sort of Omar's joke actually
1183.12|7.919|this name but just just so you know if
1185.76|6.88|you run into it um so um but but I think
1191.039|4.241|if if we look at kind of where the
1192.64|3.919|state-of-the-art has has been going now
1195.28|3.08|one of the nice things about these
1196.559|3.48|Vector databases is that they're super
1198.36|2.96|efficient right so dot product is much
1200.039|3.12|more efficient than this late
1201.32|4.2|interaction stuff especially if you do
1203.159|4.041|the approximate nearest neighbor search
1205.52|5.519|um but there's been some really cool
1207.2|7.04|work so things like Spade uh they
1211.039|4.801|basically have have sparse meat dents in
1214.24|3.16|a way so one of the big problems as I
1215.84|3.76|said with spars is that you can't really
1217.4|4.68|handle synonyms and things like that but
1219.6|5.079|what you could do is take a dense model
1222.08|4.92|Like a Bird model look at kind of this
1224.679|4.721|this one word in your sequence try to
1227.0|5.0|see which other words in the same slot
1229.4|4.72|so that gives you the synonyms uh so now
1232.0|4.679|you can give all these synonyms to a
1234.12|4.88|sparse uh vector and then you can just
1236.679|5.401|do Spar doll product and so have a much
1239.0|5.84|much more efficient way to do search uh
1242.08|4.839|without sort of giving up on all the the
1244.84|4.4|cool stuff that you get from a dense
1246.919|4.681|representation um so that's one thing
1249.24|5.559|and this other idea I really like uh is
1251.6|5.4|called Dragon um so this I think is
1254.799|3.681|really the the the best generalized D
1257.0|2.799|dense retriever so if you want to take
1258.48|3.199|something off the shelf right now and
1259.799|4.081|just go to hugging face or something
1261.679|3.681|then this dragon or Dragon plus is
1263.88|3.52|probably the thing you want to use for a
1265.36|4.88|dense Retriever and the way they train
1267.4|4.68|this is is through this Progressive data
1270.24|3.4|augmentation strategy to make them the
1272.08|4.4|model better and better over time by
1273.64|5.919|sampling very difficult negatives um and
1276.48|5.24|that gives you very good uh
1279.559|3.72|representations um and and so the other
1281.72|4.4|thing about this I think this is the
1283.279|4.601|only only sort of final point about uh
1286.12|3.52|retrieval in general is that is that
1287.88|3.6|what we see happening right now if you
1289.64|3.279|look at sort of the developer Community
1291.48|4.0|around rag is that they're all doing
1292.919|4.281|hybrid search right now uh so you can
1295.48|4.72|actually just combine the search results
1297.2|5.16|from your sparse bm25 or whatever thing
1300.2|5.04|or spade and you can combine them with
1302.36|4.919|your dragon uh and then you get uh this
1305.24|3.559|ranking that works even better uh so
1307.279|2.76|then you kind of get Best of Both Worlds
1308.799|3.76|but then you get all these questions
1310.039|6.201|about how do you combine the
1312.559|6.521|results um any any questions on on this
1316.24|6.16|part oh can you hear me
1319.08|5.8|yes oh sorry um on the earlier slide uh
1322.4|4.879|was there has there been any work on um
1324.88|5.52|Benchmark how much less hallucination
1327.279|5.161|rag incurs over a closed book question
1330.4|4.0|answering for example directly asking
1332.44|3.64|the large language model the question
1334.4|4.519|has there been any benchmarking studies
1336.08|5.16|in this yeah so there there's a great
1338.919|4.401|paper if I can say so myself on the fact
1341.24|5.4|that retrieval augmentation reduces
1343.32|5.92|hallucination uh it's from 2021 I think
1346.64|3.84|um so so yeah you can just F find if you
1349.24|3.039|literally look for retrieval
1350.48|5.96|augmentation reduces hallucination then
1352.279|4.161|you'll find the paper uh thank
1363.32|8.28|you yeah so so uh very often you want to
1367.2|6.0|have um an very precise word overlap for
1371.6|3.04|things where you don't want to have the
1373.2|4.28|synonyms or the kind of nearest
1374.64|4.76|neighbors right so um if there's like a
1377.48|4.439|brand name name or or something like
1379.4|4.279|that then like let's say the brand is
1381.919|3.921|apple right you don't want to find stuff
1383.679|5.201|about pairs right so that's what you
1385.84|5.28|would do with a dense retriever um so so
1388.88|4.24|it really kind of depends on what you
1391.12|3.64|want to use it for that's why hybrid is
1393.12|4.039|probably the way to
1394.76|4.44|go it's a good
1397.159|4.161|question with the
1399.2|5.0|dance it's
1401.32|5.52|um it's contextualized that but
1404.2|5.479|shouldn't it realize Apple the company
1406.84|4.52|would be different from no so so if they
1409.679|3.761|were actually contextualized then yes
1411.36|4.36|but but very often it's a a frozen
1413.44|6.08|retrieval system right that's one of the
1415.72|3.8|problems with all the Frozen rag
1421.2|7.24|stuff I might be missing very
1424.88|8.039|B refering to the factors that
1428.44|9.839|you're factors that you're using is
1432.919|7.88|or uh no so so the the the the sort of
1438.279|4.201|document and the query that they're the
1440.799|4.161|same right so they're either sparse or
1442.48|4.319|they're dense but so if they're sparse
1444.96|4.12|the components of the vector are are
1446.799|5.961|literally the other
1449.08|6.92|work you just Oneal when
1452.76|7.24|you're the thing that
1456.0|7.32|creates uh how are you getting so it's
1460.0|6.12|literally counts right so so basically
1463.32|4.92|it's a one big Matrix of documents as
1466.12|4.159|rows and the columns are the words in
1468.24|4.799|the documents and then you just count
1470.279|5.361|how often a word occurs in a document
1473.039|5.88|right so that's as
1475.64|3.279|far also
1479.72|5.319|refering yeah and so so in the field we
1482.64|4.88|call them sparse sparse embeddings or
1485.039|5.52|sparse retrieval because most of that
1487.52|5.6|Vector is zero right because most wordss
1490.559|6.201|don't occur in that
1493.12|5.799|document does that make sense
1496.76|7.48|yeah
1498.919|7.0|cool um so um let's talk about uh doing
1504.24|3.439|slightly better so so going back to
1505.919|3.36|Stephen's question about okay we we have
1507.679|3.36|this kind of retrieval thing but like
1509.279|4.441|how do we actually make this retriever
1511.039|4.76|good for the context that is going to be
1513.72|4.839|used in right so can we contextualize
1515.799|4.961|the retriever for the generator uh even
1518.559|3.84|if it's it's a generator where we might
1520.76|4.12|not have access to the weights so it
1522.399|5.801|could be a gp4 model we just send it to
1524.88|5.679|some API we get some stuff back um
1528.2|5.68|and so uh one paper I really like is
1530.559|4.921|called replug um so just just to kind of
1533.88|3.48|explain what this looks like so you have
1535.48|4.16|this context you have a retriever that
1537.36|4.84|we do the the standard retrieval set
1539.64|6.32|with this is a dense retriever um and
1542.2|5.52|now sorry um and now you uh compute the
1545.96|3.719|the likelihood so basically just
1547.72|4.319|normalize the scores that you get for
1549.679|5.12|for the topk documents to get a
1552.039|4.961|distribution here and then uh you give
1554.799|4.721|each one of the retrieve documents
1557.0|5.44|separately to this generator to your
1559.52|5.0|language model so you can look at the
1562.44|4.32|perplexity of the correct answer for
1564.52|4.44|that language model right so now we have
1566.76|4.2|these two probability distributions or
1568.96|4.199|two likelihoods essentially and we can
1570.96|4.319|minimize the KL Divergence to make sure
1573.159|4.081|that we can actually uh retrieve the
1575.279|4.28|documents that lead to the lowest
1577.24|6.4|perplexity on the right answer for the
1579.559|7.161|language model um so super simple idea
1583.64|5.12|uh works really really well uh and the
1586.72|4.16|nice thing about this is is completely
1588.76|3.84|uh agnostic of what happens Upstream
1590.88|4.399|right so this will work for any sort of
1592.6|5.439|encoder decoder for any language model
1595.279|5.201|um what what you need is a perplexity
1598.039|4.401|score uh but for most language models
1600.48|4.16|you can get that not necessarily all of
1602.44|5.28|them so that's one thing and then
1604.64|6.279|there's this other really nice approach
1607.72|5.679|um what you what parameters are you
1610.919|5.321|changing so so in the retriever you're
1613.399|4.76|you're literally updating the uh the the
1616.24|3.76|dense representations
1618.159|3.201|right so your encoder basically for your
1620.0|5.2|dense representation that's good
1621.36|6.319|question we'll get more um so there's
1625.2|4.68|this another paper uh on in context
1627.679|4.321|retrieval augmented language models
1629.88|5.159|where the whole paper is basically about
1632.0|4.64|just doing bm25 and just giving stuff
1635.039|3.64|directly to the context of the language
1636.64|4.36|model and things kind of work so it's
1638.679|4.761|it's sort of Frozen rag but even even
1641.0|5.36|more primitive in a way where the the
1643.44|4.52|retriever is uh this very old sparse
1646.36|4.08|algorithm but it works really really
1647.96|4.24|well um but then they have this really
1650.44|4.839|awesome section where they they show
1652.2|6.24|that you can just have this uh ranker on
1655.279|5.481|top of the bm25 results um and you can
1658.44|3.88|backdrop into this ranker so now you
1660.76|4.519|still keep the language model completely
1662.32|5.12|fixed uh so that's sort of this part of
1665.279|4.201|the the loss here uh so you have kind of
1667.44|4.28|a stop gradient on the parameters data
1669.48|4.88|that's just your language model but now
1671.72|4.48|you have this uh this kind of rank
1674.36|4.08|function here that you can back propop
1676.2|4.079|into right so that's your ranker is
1678.44|3.079|basically can be a bir model or anything
1680.279|2.841|like that that works on top of the
1681.519|3.841|things you initially retrieve from your
1683.12|6.32|bm25 and now you have this bir reer
1685.36|6.159|ranker that you can backrop into um so
1689.44|4.479|this also works really really nice so
1691.519|5.28|we're slowly progressing towards having
1693.919|5.401|a system that is much more optimized for
1696.799|4.041|being properly uh retrieval augmented in
1699.32|3.239|a way where it's useful and and
1700.84|2.439|contextualized for what you want to use
1702.559|4.161|it
1703.279|5.0|for um so uh yeah just to point out kind
1706.72|3.04|of what that looks like with this ranker
1708.279|3.161|so you just have this extra step
1709.76|3.44|essentially right so we have our
1711.44|5.119|retriever then we have our ranker then
1713.2|3.359|we have our generator and our
1718.919|6.0|output no not
1721.399|6.481|necessarily um so so so for this one you
1724.919|7.36|do yeah but so for replug you don't
1727.88|6.72|right yeah yeah yeah yeah yeah so
1732.279|5.601|basically yeah you need to get do apis
1734.6|4.88|provide not all of them um some of them
1737.88|3.12|do right but but yeah there are all
1739.48|3.12|kinds of tricks you can do on top of
1741.0|3.919|that
1742.6|4.679|yeah um so
1744.919|4.201|so basically the question is how do we
1747.279|3.601|get sort of gradients flowing into this
1749.12|3.919|right so if you don't actually have
1750.88|3.519|access to the full parameters of model
1753.039|4.041|so that you can backrop all the way
1754.399|5.721|through it then you can uh do a
1757.08|5.0|reinforce style loss on on the retrieval
1760.12|3.84|and then you just pass the kind of log
1762.08|4.24|likelihood if you if you have access to
1763.96|5.36|that or some other kind of blackbox
1766.32|3.0|function
1771.559|6.681|all right so um I the next thing you can
1775.039|6.0|do uh is to optimize both the Retriever
1778.24|5.319|and the generator um and and so this
1781.039|4.441|really uh start starts getting to the
1783.559|3.681|the proper kind of contextualization of
1785.48|3.6|the entire architecture where you want
1787.24|3.24|everything to work together right so
1789.08|3.68|rather than having this Frozen thing
1790.48|3.76|where everything is basically not aware
1792.76|2.919|that the other part exists right it's
1794.24|3.08|like two halves of the brain they're not
1795.679|3.24|talking to each other one is your
1797.32|3.239|retriever that is your language model
1798.919|3.0|there's no connection they're just like
1800.559|3.36|sort of like something is thrown over
1801.919|3.721|the fence and then you hope for the best
1803.919|5.841|uh so instead of that we have everything
1805.64|7.68|much closer and learning together um so
1809.76|5.639|um one of the the first um ways of doing
1813.32|4.199|this with a generator uh was rag
1815.399|6.681|retrieval augmented generation uh which
1817.519|6.28|we did at ver in 2020 um and and it's
1822.08|3.599|very similar to what we've already seen
1823.799|3.76|we basically have this retriever here
1825.679|4.041|that works over different documents you
1827.559|5.12|get some score function uh that gets
1829.72|4.6|given to this generator um that that
1832.679|3.921|generates answer and now you want to
1834.32|4.44|backdrop all the way and update your
1836.6|3.919|generator as well right so in the
1838.76|3.88|previous two architectures we saw you
1840.519|5.201|keep the generator fixed you backdrop
1842.64|5.24|into your retriever but here we update
1845.72|3.88|everything well not exactly everything
1847.88|4.56|as you'll see but we'll we'll also
1849.6|3.52|update the the part of the Retriever and
1852.44|4.479|the
1853.12|5.439|generator um so in this rag model uh we
1856.919|3.72|actually have two different ways of
1858.559|4.72|doing this and this this is probably
1860.639|4.16|something that when we talk about this
1863.279|2.921|uh if you think about this long enough
1864.799|4.081|then you'll you'll think like okay but
1866.2|5.079|when actually do I need to retrieve like
1868.88|5.0|do I do I retrieve every time I generate
1871.279|5.24|a new token or do I just retrieve once
1873.88|4.799|and then generate an entire sequence
1876.519|4.88|right or maybe I want to retrieve every
1878.679|4.24|end uh tokens right so these are hyper
1881.399|3.4|prams or maybe I want to learn when to
1882.919|4.76|retreat as as we'll see that's also
1884.799|6.041|something people have done um so are are
1887.679|5.161|two different ways to do it um and and
1890.84|3.76|what we do in this paper basic the whole
1892.84|4.28|point of the paper is that this Frozen
1894.6|4.919|thing doesn't really work all that well
1897.12|5.24|right so I think what people Call Rag
1899.519|4.921|now is is usually refer refers to the
1902.36|3.76|Frozen thing uh but the whole paper
1904.44|3.32|basically would never have been accepted
1906.12|3.12|anywhere if we had just done the Frozen
1907.76|4.759|thing right the whole point of the paper
1909.24|5.799|is that you want to uh optimize it and
1912.519|4.64|so at my company contextual we call this
1915.039|3.441|Frozen thing Frankenstein's monster
1917.159|3.201|because it's really like you Cobble
1918.48|3.559|together these different pieces right
1920.36|3.64|you sort of yeah it's it's really like
1922.039|3.921|Frankenstein you just put it together
1924.0|3.279|and then it sort of walks you know uh
1925.96|3.0|but it doesn't really have a soul it
1927.279|4.961|doesn't really actually work it's not
1928.96|5.079|the real thing um so that's great for
1932.24|3.64|for everyone here I think because there
1934.039|3.6|are so many opportunities to do better
1935.88|2.799|than what what most people are using
1937.639|5.04|right
1938.679|6.921|now um so one of the limitations of of
1942.679|5.48|the original rag architecture is that it
1945.6|5.12|only supports a very small okay but so
1948.159|4.36|if you have lots and lots of documents
1950.72|3.679|uh then the problem is that you have to
1952.519|5.561|fit all of them in the context but how
1954.399|7.12|do you really get that uh to fit right
1958.08|5.839|so one thing you can do is you you first
1961.519|5.201|encode uh things so that you get one
1963.919|4.561|single representation or only the few s
1966.72|3.799|of top level representations then you
1968.48|4.4|concatenate those and then you just feed
1970.519|5.361|them to the decoder so this is FID
1972.88|5.799|Fusion in decoder um and as you can see
1975.88|5.759|the scales to a much higher uh number of
1978.679|5.36|of passages uh and that uh leads to
1981.639|4.361|corresponding improvements in uh the
1984.039|4.52|scores that you care
1986.0|4.519|about uh so that's a really cool idea
1988.559|4.84|and so so we're we're slowly moving
1990.519|4.681|towards more decoder only architectures
1993.399|3.321|right so in rag we have this bark model
1995.2|3.12|it's sort of an encoder decoder
1996.72|4.64|architecture but here you just have this
1998.32|6.359|decoder that does some fancy attention
2001.36|7.12|over stuff that you retrieved before um
2004.679|6.96|and and so another like pure decoder
2008.48|4.0|language model architecture um is this
2011.639|4.16|one
2012.48|5.039|KLM which I think is is very elegant in
2015.799|4.76|its simplicity so it's basically you
2017.519|4.921|just have a normal language model but uh
2020.559|4.96|you interpolate the normal language
2022.44|5.719|model weights with uh things that you
2025.519|4.841|retrieved um so basically you have some
2028.159|4.681|sort of prompt right so like Obama's
2030.36|5.12|birthplace is you go to your big Corpus
2032.84|4.48|you find similar things you look at the
2035.48|5.199|words that come next to the similar
2037.32|6.079|things uh you uh rank that thing you
2040.679|5.161|sample your top K you renormalize that
2043.399|4.28|so now you have a bunch of scores and
2045.84|4.519|now you can just interpolate between
2047.679|4.68|your retrieved kind of non-parametric
2050.359|4.201|memory scores and your parametric
2052.359|4.0|language model scores so this is very
2054.56|4.24|late Fusion in a sense right you at the
2056.359|4.24|very end you combine these two uh and it
2058.8|4.039|allows you to re reweight the pure
2060.599|4.56|language model probabilities or
2062.839|4.201|likelihoods um so this works really well
2065.159|5.72|and it scills especially well if you
2067.04|5.359|have a huge uh retrieval Corpus so if
2070.879|3.24|you have trillions and trillions of
2072.399|4.041|tokens in there you could have a much
2074.119|3.8|smaller language model that does not
2076.44|4.0|that much heavy lifting because you can
2077.919|4.68|really rely on this big Source Corpus
2080.44|5.239|that you're working from and so that
2082.599|6.52|idea was uh exploited by this paper
2085.679|5.4|called retro out of Deep Mind where uh
2089.119|3.96|they showed that you can have a 25 times
2091.079|4.201|smaller retrieval augmented language
2093.079|4.561|model trained from scratch so really
2095.28|5.4|pre-trained uh entirely from stretch
2097.64|4.88|that outperforms this 25 times bigger uh
2100.68|4.399|language model on the same data in terms
2102.52|4.4|of perplexity which is pretty impressive
2105.079|4.441|right so this architecture is much more
2106.92|4.4|efficient than a parametric model
2109.52|4.0|because you can rely on this external
2111.32|6.08|memory so if your external memory is big
2113.52|5.559|enough uh you can get pretty huge gains
2117.4|4.16|so there was a lot of excitement about
2119.079|4.801|retro when it was announced uh but it's
2121.56|4.68|a deep mind paper so there's really no
2123.88|5.719|open source nothing really to validate
2126.24|4.92|that this actually Works um and so very
2129.599|4.361|recently there has been a bit of work
2131.16|5.6|from Nvidia called retro
2133.96|5.159|Plus+ um where they have this hybrid
2136.76|4.68|between the Retro architecture and then
2139.119|5.201|they do basically Rags sort of they put
2141.44|5.0|the top one or the topk results in the
2144.32|4.48|context of the language model after all
2146.44|4.8|so it's sort of a crossover between Rag
2148.8|4.36|and retro and they show some really nice
2151.24|5.28|results here but I I think it's sort of
2153.16|5.36|pointing to this uh big flaw I think is
2156.52|3.36|that why is there still no good open
2158.52|4.16|source retro
2159.88|4.76|model that probably tells you something
2162.68|3.52|about whether it actually really works I
2164.64|3.679|I spent a lot of time in my career
2166.2|5.24|trying to reproduce deep mind papers
2168.319|6.0|that didn't necessarily always work uh
2171.44|5.8|and so I I think the the same is true
2174.319|5.321|for retro um and that's why we need to
2177.24|3.879|do this in context rag on top of retro
2179.64|4.56|to actually get it to
2181.119|7.601|work but could it just be a true book
2184.2|4.52|thing because you're searing onook
2188.96|5.8|yeah but so
2191.839|5.561|that no so the the doing retrieval over
2194.76|5.839|that to over that big Corpus is not that
2197.4|5.76|difficult actually yeah um so so they're
2200.599|5.801|even like distributed pH packages you
2203.16|5.64|can just do everything yourself so yeah
2206.4|4.32|so in terms of comput it's it's actually
2208.8|4.92|not that hard anymore to to reproduce
2210.72|4.96|something like this uh but I've tried
2213.72|3.48|several times and it it's not really
2215.68|3.159|reproducible
2217.2|3.56|so the only way to get it to work is if
2218.839|3.921|you do this in context rag on top of the
2220.76|3.48|Retro thing and then as you can see here
2222.76|3.76|in the results then it actually gives
2224.24|3.92|you a gain over the pure GPT model right
2226.52|5.559|so it starts from a GPT and then they
2228.16|6.36|kind of retrofit as they call it the GPT
2232.079|4.52|model so in short I think there's still
2234.52|4.24|a lot of work to be done in pre-training
2236.599|3.76|these systems really from scratch uh and
2238.76|3.839|retro kind of showed that it might be
2240.359|4.121|possible but we don't necessarily know
2242.599|3.601|exactly how to do it the right way and
2244.48|3.28|this is really one of the interesting
2246.2|5.76|open
2247.76|4.2|questions um any questions on
2253.72|3.0|that
2258.8|9.12|online no okay then we'll move on um so
2265.839|4.441|um let's go all the way with the
2267.92|5.919|contextualization now right so so with
2270.28|6.68|retro and with rag what we actually did
2273.839|6.881|is we only updated the query encoder uh
2276.96|6.04|so updating the document encoder is very
2280.72|4.76|expensive so one of the first papers
2283.0|4.599|actually kind of the the OG of the the
2285.48|4.92|non-frozen dense retrieval augmented
2287.599|5.041|methods is this uh paper called realm
2290.4|5.679|this is really like Visionary work this
2292.64|5.56|was basically the first uh uh kind of
2296.079|4.24|version that did this properly where
2298.2|5.0|they updated it all the way including
2300.319|4.921|the document encoder um so can can
2303.2|5.44|someone explain to me why it's expensive
2305.24|3.4|to update the document en
2310.119|5.921|coder so let's say we have a trillion
2312.48|6.16|tokens in our Corpus right and now so
2316.04|4.64|now we go all the way so we basically do
2318.64|4.12|a forward pass we get a gradient at the
2320.68|3.679|end now we back propagate the gradient
2322.76|3.559|through the retriever we update the
2324.359|4.48|query encoder now we have to update the
2326.319|4.561|document encoder so what do we then need
2328.839|4.601|to do after we've updated the document
2330.88|5.28|encoder we need to re-encode the entire
2333.44|4.919|internet right so basically every single
2336.16|4.88|gradient update we have to re-encode
2338.359|4.561|whatever our index is which so if this
2341.04|3.559|is like trillions of tokens it's like
2342.92|6.159|re-encoding the internet after every
2344.599|4.48|batch update so that's not very
2352.28|5.559|efficient
2355.2|5.24|change
2357.839|5.24|Stuff AC have
2360.44|5.0|some
2363.079|3.961|predictable
2365.44|3.679|yeah
2367.04|3.64|yeah that's one one way to do it uh so
2369.119|3.96|so there there are a bunch of different
2370.68|5.12|ways to update the the document encoder
2373.079|5.921|so what they do in realm is they
2375.8|5.92|basically do it for Te batches then they
2379.0|4.68|stop they re-encode the entire internet
2381.72|4.04|and then they train again uh so it's
2383.68|3.88|sort of asynchronous updates they have
2385.76|4.24|this very fancy sort of sharding
2387.56|5.24|mechanisms where they take down uh
2390.0|5.599|certain parts of their entire index uh
2392.8|4.44|and then update them kind of on the Fly
2395.599|3.52|uh so you can do it is just very
2397.24|3.359|expensive so one one of the things that
2399.119|3.761|a lot of people have been thinking about
2400.599|6.0|not exactly theora idea but but similar
2402.88|5.08|versions of that um are around like can
2406.599|4.641|can you make it more efficient so that
2407.96|5.6|you don't have to do do this
2411.24|4.96|asynchronously um so one of the
2413.56|4.88|downsides of this realm uh architecture
2416.2|3.32|is that it's really just a bird model
2418.44|2.76|but then you do this retrieval
2419.52|2.92|augmentation on a bird model with other
2421.2|4.08|bird models so it's not really
2422.44|5.04|generative it's not really gen in the
2425.28|4.839|modern Paradigm but if you want to read
2427.48|4.4|like one paper uh on this topic like
2430.119|4.801|this is a very good one to
2431.88|5.199|read uh the other one that is is really
2434.92|6.96|really good to read uh is this paper
2437.079|7.24|called Atlas uh so Atlas is um uh so
2441.88|4.56|this is out of fair um with a bunch of
2444.319|5.321|folks the folks who did like Rag and the
2446.44|5.48|folks who did FID and uh a really a
2449.64|5.04|brilliant set of people and and this is
2451.92|4.36|really a comprehensive uh analysis of
2454.68|3.76|everything that's happening in this Arch
2456.28|3.76|ecture so the first question they really
2458.44|3.399|look at is how do we train this
2460.04|5.52|retriever so we've seen a couple of
2461.839|4.961|versions of this um but uh which one
2465.56|3.0|actually works better they haven't
2466.8|4.0|really been compared in a head-to-head
2468.56|5.92|setting uh so one thing is we have this
2470.8|5.92|FID Styles s vention distillation uh so
2474.48|4.0|that's really too complicated to go uh
2476.72|4.8|into detail here but the others are
2478.48|6.08|actually very simple um so one is this
2481.52|5.0|loss we've basically seen before right
2484.56|3.96|uh so we've seen this I think with the
2486.52|3.88|in context rag one right so we have a
2488.52|4.36|stop gradient on the language model and
2490.4|5.08|then we update the retriever the other
2492.88|4.239|one is what we've seen with replug so
2495.48|3.76|this is basically exactly the replug
2497.119|5.96|loss right so we have the K Divergence
2499.24|5.68|of the um the documents and and sort of
2503.079|4.641|the Improvement that you see when you
2504.92|4.8|give it that document uh the other thing
2507.72|4.599|they have is basically the inverse of
2509.72|5.92|that one so if I take this one document
2512.319|6.52|out how does that affect my uh my
2515.64|5.52|perplexity of the language model right
2518.839|4.28|um and so this one I think is actually
2521.16|4.56|quite elegant because that really gets
2523.119|5.561|to like how valuable is this one single
2525.72|6.359|document for me answering this question
2528.68|5.88|correctly um so uh they compare all of
2532.079|5.081|these different versions and uh what you
2534.56|4.84|can see is that uh the the kind of
2537.16|4.159|replug style loss and this leave one out
2539.4|4.04|loss they perform a lot better than all
2541.319|4.121|of these others so this fixed retriever
2543.44|3.56|or no joint pre-training these are
2545.44|4.6|really kind of the Baseline sort of
2547.0|5.24|Frozen rag models or close book uh and
2550.04|5.799|as you can see you can do really a lot
2552.24|5.8|better uh if you optimize things and so
2555.839|5.0|this leave one outing is probably the
2558.04|4.68|best I would say um so then the other
2560.839|4.041|question is how do you actually like
2562.72|4.24|train that entire system like what data
2564.88|4.32|or what tasks do you train this on so
2566.96|5.359|they also uh experiment with a bunch of
2569.2|5.72|different versions uh so one is uh doing
2572.319|5.641|prefix LM if you're familiar with that
2574.92|5.04|uh so they basically take a chunk that
2577.96|4.08|occurs somewhere on the internet and
2579.96|4.48|then they predict the next Chunk from
2582.04|4.72|that chunk right so it's really like
2584.44|3.879|sentence to sentence so maybe like skip
2586.76|3.12|thought back in the day but now you have
2588.319|4.681|this retrieval step where you predict
2589.88|5.16|the next sentence uh then they just do T
2593.0|3.28|T5 Styles sort of D noising so that's
2595.04|4.16|Mass language modeling if you're
2596.28|5.2|familiar with T5 um and then they have
2599.2|4.44|this title to section generation piece
2601.48|4.28|so um I think the takeaway from this
2603.64|4.76|table is basically that whatever you do
2605.76|4.0|here so they're using T5 model so
2608.4|4.52|whatever you do here needs to be the
2609.76|5.92|same that your uh language model expects
2612.92|6.48|um so for T5 that's T5 style
2615.68|5.12|loss um and then uh the the the next
2619.4|3.56|sort of final question that they look
2620.8|4.279|into going back to to what we talked
2622.96|4.879|about how exactly do we update this
2625.079|5.24|retriever uh so do we have to update the
2627.839|4.961|document encoder or do we maybe have to
2630.319|5.24|do some sort of reranking uh or do we
2632.8|4.519|maybe just update the query um and and
2635.559|3.881|quite surprising L I think they find
2637.319|4.641|that just updating the query so like in
2639.44|5.0|the original rad paper is actually
2641.96|5.119|already basically good enough in many
2644.44|4.52|cases so so that's nice because it's
2647.079|4.641|much more efficient if you don't have to
2648.96|4.48|update your documents all the time uh I
2651.72|4.16|think the the real question here though
2653.44|5.32|is like uh how good is your document
2655.88|4.84|representation to begin with so you need
2658.76|3.68|to have very very high quality embedding
2660.72|3.399|model for this to work if you don't have
2662.44|4.0|that then this will not work but if you
2664.119|5.881|do have that then you get a very nice
2666.44|3.56|kind of query side fine-tuning
2671.0|7.079|thing U so the the atlas paper is about
2675.16|5.12|trying to do F shop um sort of language
2678.079|5.28|modeling tasks so it's how how many
2680.28|3.079|examples are given in the
2685.359|5.641|context um yeah so so the main takeaway
2689.079|4.441|um here is that if you compare like the
2691.0|5.8|Close book equivalent model to the
2693.52|5.2|retrieval augmented model uh you see
2696.8|3.799|very big
2698.72|4.119|improvements that's really the only
2700.599|5.681|takeaway of of this entire
2702.839|6.161|section um but I I think that that's
2706.28|5.52|really saying something uh in terms of
2709.0|5.2|what we should be thinking about um how
2711.8|4.12|how much time do I have
2714.2|7.359|in
2715.92|8.199|still okay okay all right other
2721.559|6.321|questions are the documents in the
2724.119|3.761|training step same as
2729.44|5.96|yeah so they can be different um in so
2733.24|4.52|in Atlas the athlet basically tries
2735.4|3.84|everything uh so they also try to see
2737.76|4.48|what happens if I train this on
2739.24|6.56|Wikipedia But I swap in like a sort of
2742.24|5.4|Comm and crawl index um and I think so
2745.8|5.0|in Atlas but also in retro domain
2747.64|5.08|finding is just the more the better uh
2750.8|3.96|so it's really just like the bigger your
2752.72|5.879|index the more likely you're you are to
2754.76|6.359|find the exact right thing um and then
2758.599|2.52|make the right
2764.16|5.32|prediction any other questions on this
2767.0|5.48|oh yeah uh sorry I this is a question
2769.48|7.52|about the generator in the I guess uh
2772.48|7.76|the rag system so um recently I saw a
2777.0|5.319|paper on mistal 7B so it introduces a
2780.24|3.52|lot of these uh new architectural
2782.319|3.8|changes like the sliding window
2783.76|4.48|attention to handle longer sequence is
2786.119|4.561|at a smaller cost and the group query
2788.24|5.24|attention for faster inference I'd like
2790.68|5.48|I'd like to like know your thoughts on
2793.48|5.04|designing a generator specifically for
2796.16|5.36|rag uh leveraging for example where
2798.52|4.64|mystal 7B currently is because for
2801.52|3.28|example like the sliding window
2803.16|3.88|attention I could see how that could be
2804.8|4.92|adapted to the rag
2807.04|5.12|case yeah so so maybe your read on sort
2809.72|4.04|of what makes mol's special is a bit
2812.16|3.28|different from mine so I I don't think
2813.76|3.4|that the sliding attention window thing
2815.44|3.28|is actually that interesting the reason
2817.16|3.84|mrol works so well is because it's
2818.72|3.68|trained on a lot of data uh and you can
2821.0|2.96|do that more efficiently because you
2822.4|4.88|have sliding window attention so you
2823.96|6.44|don't need to attend to everything um
2827.28|4.68|but uh so to answer your question I I
2830.4|4.199|guess you're asking sort of about the
2831.96|3.96|architecture of the generator if you
2834.599|4.361|know that there's going to be a
2835.92|4.88|retriever so I I I think uh that's
2838.96|5.639|basically what retro tried to do right
2840.8|6.799|so um retro actually some of the people
2844.599|6.201|on the Retro paper are at Mistral now uh
2847.599|5.201|so they they have this uh C chunk cross
2850.8|3.92|attention idea here so you basically
2852.8|4.12|have a language model but the way it
2854.72|6.32|does the tension over the things you
2856.92|6.28|retrieve in your retro um architecture
2861.04|4.92|uh you they they kind of get integrated
2863.2|4.879|into a model not using the standard
2865.96|4.159|detention mechanism but using this
2868.079|5.081|slightly different chunk cross
2870.119|4.881|detention oh okay so I think the the
2873.16|4.48|sliding window Attention Point I was
2875.0|5.119|trying to get get at was that uh it uses
2877.64|5.24|a fixed window so that whenever you're
2880.119|4.841|doing the query key computation in the
2882.88|4.439|attent with the query vectors and the
2884.96|5.72|key vectors you're using a fixed window
2887.319|6.24|attention so I think my idea was to
2890.68|5.76|actually one use a dynamic window
2893.559|5.04|because for example the rag case um if
2896.44|5.04|you use a fixed window when you're doing
2898.599|5.361|attenion it it is possible that you
2901.48|4.76|actually are leaving you you're only
2903.96|4.8|looking at a fixed uh span of
2906.24|4.96|information so if you could maybe adapt
2908.76|4.64|mistel so that you could make it better
2911.2|4.359|for the ride case and and for example
2913.4|5.6|the making the fixed window size the
2915.559|6.52|dynamic window uh yeah yeah I think it's
2919.0|5.359|an interesting idea so so for me uh the
2922.079|4.24|the what m is doing with with the
2924.359|4.361|sliding window that's basically like a
2926.319|4.8|conet right so we had all these
2928.72|3.76|convolutional like light comp Nets where
2931.119|3.0|where we would have word embeddings and
2932.48|3.72|you would do convolutions over it and
2934.119|4.161|then pull uh and then you would still
2936.2|4.119|get the information out so it's not that
2938.28|3.92|the sliding window prohibits you from
2940.319|3.921|looking earlier it's just that that
2942.2|5.399|happens higher up in your Transformer
2944.24|6.2|sort of yeah
2947.599|4.681|yeah so I think that definitely is an
2950.44|5.32|interesting direction to to think in
2952.28|5.519|yeah yeah so I think um it's like not
2955.76|3.599|too crazy to say are there any
2957.799|4.081|architectural changes that we can
2959.359|4.321|introduce into these 7 billion parameter
2961.88|5.239|models so that they could be better
2963.68|6.639|adapted to the rag case
2967.119|5.081|yeah so there there there might be yeah
2970.319|3.601|I I think one one question is just how
2972.2|3.68|do you how do you do the attention over
2973.92|3.159|things you've retrieved which I think is
2975.88|3.76|what
2977.079|5.801|you're yeah
2979.64|6.24|thanks so just to make sure I understand
2982.88|4.959|so I mean in this retro model you're
2985.88|4.679|retrieving in each
2987.839|5.48|block and when you talk about putting
2990.559|4.0|the retrieval in the context are you
2993.319|3.961|saying that you only do it at the
2994.559|5.441|beginning you don't do it
2997.28|4.839|yeah so so in context so this is it's
3000.0|5.359|not exactly every layer sort of so it's
3002.119|6.96|every token right so every um every step
3005.359|7.2|basically not every block so doesn't
3009.079|6.921|make sense so it's not every layer that
3012.559|6.56|you do to retrieval yeah so every step
3016.0|5.68|right um so so this is kind of like like
3019.119|4.96|what rag token is so you retrieve every
3021.68|4.8|token you so you generate and then you
3024.079|4.121|can retrieve again or in the case of
3026.48|5.0|retro you can generate like a chunk and
3028.2|5.159|then you retrieve chunks again uh if you
3031.48|5.16|look at the in context case you retrieve
3033.359|8.24|once at the beginning and then you give
3036.64|8.04|it you're say that during this
3041.599|6.801|nobody yeah but so the so the in Contex
3044.68|6.32|thing um so so here you don't actually
3048.4|4.719|give it as context at all like directly
3051.0|5.96|to the model right so here you get you
3053.119|6.841|let the decoder kind of tend over
3056.96|3.0|it
3062.599|6.081|yeah so I don't think cross attention
3065.44|3.24|really works yeah
3070.799|4.52|yeah other
3073.0|5.319|questions yeah we
3075.319|6.121|inside the the training of the retriever
3078.319|6.48|is not so necessary because of the
3081.44|8.28|large uh so I'm wondering what inside of
3084.799|9.481|the T like what cases are really need
3089.72|6.92|toiz update or anyway updates
3094.28|4.559|those yeah so you do want to update the
3096.64|4.959|retriever right but but only part of the
3098.839|7.161|retriever is necessary to be updated for
3101.599|6.881|a lot of these these cases um but so so
3106.0|4.119|I I think it uh so these are very
3108.48|3.68|specific data sets right natural
3110.119|4.44|questions wizard of Wikipedia and fever
3112.16|5.48|so they're really very uh kind of
3114.559|4.921|knowledge intens tasks uh so in that
3117.64|4.04|case if you already have a very good
3119.48|4.839|system like DPR that is specifically
3121.68|4.96|pre-trained for those tasks then you
3124.319|4.401|only need to update the query encoder
3126.64|3.959|but so I would expect that if you move
3128.72|4.639|Beyond this to kind of General language
3130.599|4.801|modeling things like like retro then you
3133.359|4.361|probably do want to update the document
3135.4|3.24|encoder at least in a way where you can
3137.72|5.96|scale
3138.64|8.64|it so that in the this part that is very
3143.68|3.6|much in
3153.72|6.2|as long as we have a good opal knowledge
3156.28|6.76|of what of the maybe the documents by
3159.92|5.679|those uh good
3163.04|5.279|models yeah but so you need to learn how
3165.599|5.561|to kind of query into that Index right
3168.319|5.161|so if you if you don't do that uh then
3171.16|3.72|then yeah you don't get really good
3173.48|4.119|performance so that's sort of like your
3174.88|4.239|close book performance right if you just
3177.599|4.041|have the language model and you're just
3179.119|4.2|like what what does the parametric model
3181.64|3.88|on its own without the retrieval what
3183.319|5.961|does it actually know as you can see
3185.52|3.76|there there are pretty big gaps there
3191.52|5.48|right other questions otherwise I will
3194.4|2.6|cover other
3197.92|6.36|questions no uh hello yeah go for it a
3201.96|4.56|quick question like so uh what about
3204.28|4.079|like more here at retrieval like I
3206.52|3.52|suppose there will be messes trying to
3208.359|3.361|not just retrieve a single chunk but
3210.04|4.6|some kind of like groups of chunks or
3211.72|4.44|something or summarized versions there
3214.64|3.64|there's been some interesting work on on
3216.16|3.84|doing that uh where you first tried to
3218.28|3.4|find so you can have multiple indices
3220.0|3.0|and they can kind of cascade right so
3221.68|3.08|first you want to find the relevant
3223.0|3.359|document so you have some document
3224.76|3.88|representation and then within that
3226.359|4.561|document you want to find the relevant
3228.64|4.12|chunk uh so you can do it sort of that
3230.92|3.48|direction you can also do it in reverse
3232.76|3.559|I think I I have something on the slide
3234.4|4.64|there where you can find the chunk and
3236.319|4.28|then sort of expand uh the context
3239.04|5.24|around it and then give that to the
3240.599|5.081|language model um so I think yeah there
3244.28|3.24|are all kinds of interesting things you
3245.68|4.76|can do
3247.52|5.599|there cool H thanks I guess another
3250.44|5.56|thing just like do can you compare rag
3253.119|5.041|versus like long context L efforts so
3256.0|4.319|there are lot of things like on around
3258.16|4.6|just having really long context and
3260.319|6.321|extreme it could replace rag but I know
3262.76|5.88|like if your takes yeah so so my my uh
3266.64|3.64|so everybody understands this question
3268.64|3.8|right so there there's there's a trend
3270.28|4.44|where we want to have very long context
3272.44|4.159|language model so that basically you can
3274.72|3.639|like take Harry Potter or something just
3276.599|3.441|put it into context and then ask a
3278.359|4.081|question like what is the name of like
3280.04|3.799|Harry Potter's owl or something right
3282.44|5.08|and then it can just attend over the
3283.839|5.48|entire thing um so attending over all of
3287.52|4.88|Harry Potter to answer that one question
3289.319|4.681|is super inefficient right uh so most of
3292.4|4.159|Harry Potter has nothing to do with the
3294.0|4.24|AL uh so but you are still kind of
3296.559|4.681|reading it if you do it with the long
3298.24|4.64|context window um so that's why I think
3301.24|4.24|the doing it the rag way where you have
3302.88|4.959|this non-parametric component is a much
3305.48|3.56|more efficient way to solve this problem
3307.839|4.081|and if you actually look at the
3309.04|5.24|literature on Long context Windows uh
3311.92|4.76|the way they they solve the problem of
3314.28|4.92|scaling the attenion mechanism is by
3316.68|4.159|making it very sparse uh so they're
3319.2|3.119|basically turning it so that's a
3320.839|3.121|different kind of spars but they're
3322.319|3.961|turning it into a non-parametric
3323.96|4.0|retrieval problem uh kind of behind the
3326.28|2.92|scenes so they're not they're not
3327.96|2.879|actually all that different if you want
3329.2|5.32|to scale long context then you're going
3330.839|3.681|to move towards a rag style
3334.599|3.24|architecture good
3338.16|6.36|thanks all right um so let's talk about
3341.319|5.961|some other interesting questions so one
3344.52|4.839|thing and I already alluded to this is
3347.28|4.6|when do we actually retrieve so very if
3349.359|5.161|we're doing like if we want to uh like
3351.88|4.159|retrieve every token that's also very
3354.52|3.839|inefficient because I probably don't
3356.039|4.721|have to retrieve to generate
3358.359|3.96|the right I can probably do that on my
3360.76|4.64|own with the language model is of a
3362.319|5.0|wayte to go and retrieve stuff but if I
3365.4|3.52|only retrieve once at the beginning of
3367.319|4.401|the sequence that's probably also not
3368.92|4.639|great right so so what we ideally want
3371.72|3.28|to be able to do is to say okay
3373.559|2.841|sometimes I want to retrieve sometimes I
3375.0|4.24|don't want to retrieve and I'm going to
3376.4|5.04|learn when I want to kind of expend the
3379.24|5.359|the compute Budget on doing the
3381.44|5.119|retrieval um so a nice paper where they
3384.599|4.281|have a stab at this is called flare for
3386.559|4.921|active retrieval augmentation where they
3388.88|4.64|basically have the language model decide
3391.48|6.119|uh when it should do a search and what
3393.52|6.279|it should do to search for um so so I I
3397.599|4.161|think this fits in a general Trend that
3399.799|3.76|you can see in the field around kind of
3401.76|5.599|Agents right so we can talk a little bit
3403.559|5.76|more about that too um so this other uh
3407.359|3.641|question that that I think we also kind
3409.319|3.561|of covered already here is how do we
3411.0|3.52|train this at scale right so we can do
3412.88|4.159|these asynchronous updates we can do
3414.52|4.92|reer rankers we can do query side only
3417.039|4.601|there's this really nice paper uh which
3419.44|5.8|is quite close I think to the idea you
3421.64|6.08|proposed uh where you first use bm25 to
3425.24|5.319|create a a batch basically where
3427.72|5.96|everything is very similar uh in terms
3430.559|5.76|of what you've retrieved and now you uh
3433.68|4.159|have this kind of inbatch update so it's
3436.319|3.201|it's sort of like a ranker where you
3437.839|4.2|encode the information that is just in
3439.52|4.72|your batch using this other model and
3442.039|3.601|now you can update this model on the fly
3444.24|3.28|so you don't have to worry too much
3445.64|4.8|about doing the full kind of documents
3447.52|4.559|side update um and again here what
3450.44|3.52|really matters is like how big is your
3452.079|3.841|index if you have an amazing index you
3453.96|4.44|can basically solve any problem just by
3455.92|4.199|looking it up right so rather than
3458.4|4.719|cramming it into your parameters you can
3460.119|6.24|just find it
3463.119|5.72|um this is a really nice paper uh called
3466.359|4.281|Silo so one one of the interesting
3468.839|4.401|things I think that's going to happen in
3470.64|4.159|the next year or two around language
3473.24|3.28|models is there and you've seen this
3474.799|3.721|already there's a bunch of like lawsuits
3476.52|5.48|against open Ai and other places around
3478.52|6.4|where does the data exactly come from um
3482.0|4.92|so one uh very elegant solution I think
3484.92|4.919|is to have a rag system that you train
3486.92|5.439|on data that you know is safe so you can
3489.839|4.681|train that thing on Wikipedia But now
3492.359|4.96|during test time you can give it a data
3494.52|5.599|store that has maybe slightly riskier uh
3497.319|4.28|information in it so this massive index
3500.119|4.96|of all the stuff on the internet
3501.599|6.0|including some things that are maybe um
3505.079|4.801|risk uh you can still have them in your
3507.599|4.0|index but your language model uh your
3509.88|3.239|retrieval augmented language model I
3511.599|3.2|should say you know that that thing is
3513.119|3.841|safe because it was strin on data that
3514.799|4.0|is public domain uh so that's what they
3516.96|5.079|do in Silo and they show that that works
3518.799|5.601|really well so that's uh one possible
3522.039|3.921|solution to to a lot of the the kind of
3524.4|3.719|compliance and legal risk around
3525.96|5.879|language model
3528.119|6.68|deployments um there's a great paper and
3531.839|5.161|also from one of your colleagues um
3534.799|3.841|around uh contexts getting lost in the
3537.0|3.119|middle I think this is also kind of a
3538.64|6.36|fascinating phenomenon this is on a
3540.119|6.881|frozen rag system um but U language
3545.0|4.68|models are very similar to humans in
3547.0|4.52|what things they pay attention to so if
3549.68|3.919|you give them a bunch of things that you
3551.52|3.64|retrieved what what they will look at
3553.599|3.24|are like the first things you list and
3555.16|4.72|the last things you list and they will
3556.839|4.641|sort of ignore the middle um so if it
3559.88|3.6|actually respected the rank function
3561.48|4.559|then then this curve would go down all
3563.48|4.76|the way right but it sort of go goes up
3566.039|4.401|um so I I I think that's a a very
3568.24|5.119|interesting observation which kind of
3570.44|4.72|shows that how brittle uh these these
3573.359|3.921|systems can be right so if you have a
3575.16|4.12|frozen rag system it can be very very
3577.28|4.079|brittle where like the order of the
3579.28|5.039|retreat context matters a lot in whether
3581.359|7.321|you get the right answer or
3584.319|6.04|not work on treating this as re problem
3588.68|4.96|sense
3590.359|6.321|ofor like specifically going for
3593.64|6.36|interpration out VOR that's going to
3596.68|6.8|inter prodct with just the right maybe
3600.0|3.48|you can tune for the particular
3604.0|4.72|dat yeah so what what I just described
3606.68|3.76|someone asked like how how do you
3608.72|3.28|actually so I said there are other ways
3610.44|3.48|to do this and then the question was how
3612.0|5.559|do you do that so the way you do that is
3613.92|6.439|using reinforce um so yeah there has
3617.559|4.401|been work on doing that um so some of
3620.359|5.081|the older papers were playing with this
3621.96|5.44|but one one of the big problems with uh
3625.44|5.639|so I think the replug solution isort of
3627.4|5.719|more elegant uh for solving that problem
3631.079|3.601|because you actually of use signal from
3633.119|3.48|the language model and if you just do
3634.68|4.08|reinforce it's very high variant so
3636.599|4.321|you're uh it's it's going to be super
3638.76|3.359|finicky if you don't want to destroy
3640.92|5.32|your
3642.119|4.121|index but people have tried it
3647.039|7.04|though um so um uh there's some some
3651.799|4.121|really nice work from open AI where they
3654.079|3.48|they basically basically show and again
3655.92|4.56|we're sort of like thinking more and
3657.559|4.56|more about agents here right uh where
3660.48|3.319|they show something very similar to the
3662.119|3.68|flare result from earlier with active
3663.799|3.881|retrieval that doesn't necessarily have
3665.799|5.121|to be some index that you own it can be
3667.68|4.6|just some some web search right um and
3670.92|2.679|obviously in this case you don't really
3672.28|3.559|have access to the web search
3673.599|3.76|necessarily so Bing or whatever they use
3675.839|3.801|here is not going to update its
3677.359|4.24|parameters uh but I just wanted to kind
3679.64|4.6|of put this in your mind like this is
3681.599|5.921|another thing you can do right and if we
3684.24|4.92|take this really to the general form uh
3687.52|4.519|then you can think of language models as
3689.16|5.199|just tool users um so rather than just
3692.039|4.241|retrieval augmenting language models we
3694.359|3.881|can tool augment language models and
3696.28|4.24|retrieval is just one of the many tools
3698.24|4.76|that language models have access to we
3700.52|5.279|can have uh rankers and things on top of
3703.0|5.16|the outputs of these tools um and so one
3705.799|4.681|of the the big questions I think uh is
3708.16|4.159|how do you actually get the system to to
3710.48|3.52|learn stuff right so we're going to need
3712.319|3.0|our help if we want this system to
3714.0|3.0|really learn learn how to take these
3715.319|3.321|actions uh
3717.0|4.839|properly
3718.64|5.8|um um and and so yeah this has been
3721.839|4.601|taken to to the extreme in this uh sort
3724.44|3.52|of self rag architecture where they have
3726.44|3.28|this sort of retrieval step and it's
3727.96|3.92|active and then you criticize it and
3729.72|4.24|then you uh basically do some natural
3731.88|4.239|language inference uh and all of that
3733.96|3.24|just with one language model to answer
3736.119|4.72|uh the
3737.2|5.0|questions um so the other missing piece
3740.839|3.28|so I'm just kind of going through a
3742.2|4.2|bunch of open questions uh that that
3744.119|3.68|people have looked at uh but feel free
3746.4|4.28|to interrupt me if there's anything you
3747.799|4.641|want to know um but so instruction
3750.68|3.24|tuning we established at the beginning
3752.44|3.24|of the lecture that this is pretty
3753.92|5.48|important for getting things to work so
3755.68|6.0|fixing the user interface um but the
3759.4|3.959|instruction tuning has almost always
3761.68|3.879|only happened on the language model and
3763.359|4.161|not on the entire system so I think one
3765.559|3.8|of the interesting uh things that people
3767.52|3.92|are looking at now with with things like
3769.359|4.0|RIT and instruct retro is how can we
3771.44|4.48|instruction fine to an entire retrieval
3773.359|5.041|augmented system so all the way into the
3775.92|4.48|retrieval step can we generate data so
3778.4|3.679|that that also follows the instructions
3780.4|4.199|properly which currently doesn't happen
3782.079|4.96|in any of these model
3784.599|4.76|architectures um and then finally I I
3787.039|4.441|think I would be remiss if I if I didn't
3789.359|4.2|really talk about what people call
3791.48|3.639|Advanced rag so so like the developer
3793.559|4.48|Community has been really doing some
3795.119|4.72|awesome stuff uh so like Frameworks like
3798.039|3.841|llama index and Lang chain and there's
3799.839|4.161|all these open source Vector databases
3801.88|4.56|like groma and wv8 and they're all sort
3804.0|5.319|of about making rag really easy but this
3806.44|4.919|is all Frozen rag right but even with
3809.319|4.881|frozen rag you can really do incredible
3811.359|4.76|things um so uh we mentioned some of
3814.2|4.28|these already so child parent recursive
3816.119|3.96|retriever so you find small small parts
3818.48|3.599|and then you give the big parts around
3820.079|3.96|it to the language model you can do
3822.079|3.76|hybrid search where we use reciprocal
3824.039|3.961|rank Fusion so we have like different
3825.839|3.881|search results that we then combine
3828.0|4.4|before we give the final thing to the
3829.72|4.72|language model there's zero shot like
3832.4|3.959|large language model ranker so basically
3834.44|3.599|the score function is not doesn't come
3836.359|4.68|from your retrieval it comes directly
3838.039|4.841|from the language model um and then uh
3841.039|4.481|hypothetical document and Bets which I
3842.88|4.959|think is a really cool idea so you just
3845.52|4.88|uh basically you fix hallucination
3847.839|4.321|through hallucination uh so you get a
3850.4|4.04|question then you let the language model
3852.16|4.0|hallucinate a bunch of possible answers
3854.44|3.48|then you go and search for nearest
3856.16|3.52|neighbors to the possible answers and
3857.92|4.0|you give those as context and then it
3859.68|4.0|gives the right answer based on that
3861.92|4.359|right so it's really like hallucinating
3863.68|5.2|answers and I think it's a brilliant
3866.279|4.881|solution um so there's a lot of stuff
3868.88|4.28|happening in in the kind of Frozen rack
3871.16|6.24|Community uh to that I think is very
3873.16|6.84|interesting to look at um so uh just to
3877.4|5.24|wrap up kind of looking at the future of
3880.0|4.68|this stuff uh there are still lots of
3882.64|3.679|very interesting open questions so if
3884.68|4.56|you're a student thinking about how to
3886.319|6.72|solve any of these I think you can have
3889.24|5.879|quite a lot of impact um so how how
3893.039|3.881|exactly do we do like pre-training of
3895.119|4.041|this architecture and do we even need to
3896.92|3.919|pre-train I think even retro kind of
3899.16|3.28|shows that you don't necessarily have to
3900.839|4.801|pre-train so but maybe there's something
3902.44|5.119|wrong with how we um how we do that what
3905.64|3.159|do skating laws look like so I think
3907.559|3.961|there's a really interesting question
3908.799|4.601|here around if I have a huge index and a
3911.52|4.759|very rich encoder of all the information
3913.4|4.8|in that index maybe I can move so
3916.279|4.32|basically decouple all the memorization
3918.2|3.96|to this index so I have a language model
3920.599|4.081|that doesn't know anything it just
3922.16|4.08|speaks English it just sort of re on top
3924.68|3.639|but it has no knowledge because that
3926.24|3.599|always comes from this retriever if you
3928.319|3.321|can do something like that then you get
3929.839|4.0|very interesting scaling tradeoffs right
3931.64|4.919|so you can have a tiny language model
3933.839|4.841|and and do your retrieval uh to do a lot
3936.559|3.76|of the heavy lifting with your retrieval
3938.68|3.56|which is nice because that's a cach
3940.319|3.72|computation right so you can just you
3942.24|4.24|already have the the embeddings you just
3944.039|3.961|need to do the dop product so it's much
3946.48|4.559|more efficient than kind of self
3948.0|5.079|attention in the language model um can
3951.039|5.681|we move Beyond bu encoder so Vector
3953.079|5.441|databases um I I like people who build
3956.72|3.52|Vector databases but I'm not sure how
3958.52|6.039|long we're going to keep Vector
3960.24|6.359|databases um because u i I think rer
3964.559|4.04|rankers probably work just as well and
3966.599|6.68|bm25 is much more efficient than a
3968.599|6.881|vector database um so I I don't really
3973.279|4.08|see why we need dedicated Vector
3975.48|4.799|databases and so what we're seeing but
3977.359|4.68|maybe this is a bit of a critique of uh
3980.279|3.28|maybe silicon value investment
3982.039|2.881|strategies and things like that but a
3983.559|3.72|lot of these
3984.92|3.96|um um Vector database companies are
3987.279|3.361|basically becoming database companies
3988.88|3.919|now so they are adding all this Spar
3990.64|4.32|stuff because the the densing is not
3992.799|5.201|enough um and as it turns out there are
3994.96|4.96|a lot of pretty good uh sparse databases
3998.0|3.4|out there already like postgress and
3999.92|5.159|things like that and they're also all
4001.4|5.04|adding vectors uh to their databases so
4005.079|4.76|uh I think that's all going to kind of
4006.44|3.399|coales into
4010.48|5.76|databases um so um I think there are so
4014.039|3.8|interesting things to look at for kind
4016.24|4.359|of the data so alluding to this
4017.839|5.681|instruction problem can we generate much
4020.599|4.68|better data for training rag systems
4023.52|3.2|synthetically uh and then I think
4025.279|3.121|there's this massive open question
4026.72|3.76|around how we actually measure whether
4028.4|4.679|the rag system is any good so right now
4030.48|5.2|we just look at Downstream performance
4033.079|4.48|um um which is sort of okay but if you
4035.68|5.04|mess up the retrieval it's very hard to
4037.559|4.921|measure um but how to how to measure
4040.72|3.24|whether your retrieval is right is also
4042.48|3.119|very difficult so there are some
4043.96|3.48|Frameworks where they try to take like
4045.599|3.48|the harmonic mean of your retrieval
4047.44|3.839|accuracy and your language model
4049.079|4.24|accuracy uh but I think those are also
4051.279|3.921|very shy because we don't really have
4053.319|4.321|very good uh data sets to measure that
4055.2|5.879|on so I think that's that's a very cool
4057.64|5.679|problem to work on as well um so the
4061.079|4.561|other problem that I personally am
4063.319|5.161|always very excited about is
4065.64|5.52|multimodality um and so why would we
4068.48|4.799|stop with rack systems with just text
4071.16|4.52|right so you can do the same thing with
4073.279|4.401|images uh you can augment language
4075.68|4.359|models with vision so we did this work
4077.68|5.04|on lens where we have a language model
4080.039|5.721|enhanced to see uh where you can just
4082.72|4.92|give kind of a computer vision pipeline
4085.76|3.92|just like a retrieval Pipeline and give
4087.64|3.56|that to a frozen language model and pass
4089.68|3.72|it to the context and that system
4091.2|4.479|actually is an amazing visual question
4093.4|4.319|answering system it's close to
4095.679|4.16|state-of-the-art uh sort of flamingo
4097.719|3.721|from Deep Mind which is also very hard
4099.839|4.601|to reproduce because there's no open
4101.44|5.2|source version of that um
4104.44|5.399|so so we've done some early work on this
4106.64|5.599|in in 2021 uh where we have this cross
4109.839|4.201|modal retrieval and there's some uh more
4112.239|3.96|recent workout of fair where they also
4114.04|3.36|look at this so I think that's really
4116.199|4.12|like if you look at the trend in the
4117.4|4.52|field like multimodality with GPD 4V and
4120.319|3.561|things like that is really a Hot Topic
4121.92|3.839|so everything is kind of going in that
4123.88|3.359|direction uh so it's an interesting
4125.759|5.761|thing to think
4127.239|6.361|about um so overall I think um it would
4131.52|4.92|be nice if everybody sort of moves away
4133.6|5.079|from from rag 1.0 to Frozen Frankenstein
4136.44|4.799|Rag and moves towards this much more
4138.679|5.0|kind of optimized version rag 2.0 so
4141.239|4.201|it's really about systems over models
4143.679|2.961|right it's not just your language model
4145.44|3.12|and your Retriever and they're kind of
4146.64|3.679|separate it's about thinking from the
4148.56|3.08|from a systems perspective about the
4150.319|3.84|entire thing and the problem you're
4151.64|4.8|trying to solve and so I think that
4154.159|3.801|really is the way that in deep learning
4156.44|3.839|things have always progressed where if
4157.96|3.839|you optimize the system end to end
4160.279|3.321|that's always going to win out like back
4161.799|4.0|in the day in computer vision or NLP we
4163.6|4.28|have like parsers and scam parsers and
4165.799|4.201|all this kind of stuff and all that just
4167.88|4.64|doesn't exist anymore now because we
4170.0|5.159|optimize the system end to endend U so
4172.52|4.159|that's what's going to happen here too U
4175.159|2.841|so if we take that to the extreme like
4176.679|2.921|there's a chunker thing in your
4178.0|3.359|documents right like put cutting it up
4179.6|4.84|into pieces like you could backdrop into
4181.359|6.88|that like why not somebody should really
4184.44|6.359|do that um and so yeah I I think like
4188.239|4.241|trading off cost and quality uh and zero
4190.799|3.081|shop domain generalization that's really
4192.48|3.44|like where this stuff is going to come
4193.88|4.08|in so language models right now they're
4195.92|4.0|amazing but very often they're way too
4197.96|3.48|expensive for being deployed somewhere
4199.92|3.88|where you can actually make money from
4201.44|4.4|them if you're in a company um so what
4203.8|3.359|you want to do is make it much more
4205.84|3.52|efficient and have the right cost
4207.159|3.52|quality tradeoff and the the easiest way
4209.36|3.48|I can think of is to do it through
4210.679|6.241|retrieval augmentation but obviously I'm
4212.84|6.0|I'm very biased um so uh yeah that that
4216.92|3.84|was all I had actually um so if you're
4218.84|4.359|interested in this I'm I'm at Stanford
4220.76|4.6|so I can work with you on research
4223.199|3.96|projects on these topics or if you want
4225.36|5.44|you can also join contextual because we
4227.159|7.841|work on this stuff every day thank
4230.8|7.04|you well um sorry I had a question from
4235.0|5.12|earlier yeah I think you said something
4237.84|5.04|really uh really I think really super
4240.12|4.599|helpful earlier about Mel 7B you talked
4242.88|3.72|about you compared the sliding window
4244.719|3.52|attention to convolutional neural
4246.6|2.76|networks and I do see the parallel
4248.239|3.401|because with convolutional neural
4249.36|3.24|networks you have uh several layers of
4251.64|2.559|several different layers of
4252.6|4.599|convolutional layers and the top
4254.199|4.681|convolution layers are able to see um a
4257.199|4.52|larger receptive field than the bottom
4258.88|5.04|convolution layers and um and with
4261.719|5.44|convolution layers you're able to tune
4263.92|5.68|the um filter sizes and the stride so
4267.159|4.08|you're able to see a different receptive
4269.6|4.599|field and I was wondering if you could
4271.239|4.96|see that same innovation in mistal 7B by
4274.199|3.801|tuning um because you have different
4276.199|3.48|Transformer layers and each Transformer
4278.0|3.88|layer will have a span over a different
4279.679|4.081|set of tokens and if you can tune I
4281.88|3.68|guess the Transformer architecture the
4283.76|4.08|way you tune those convolution layers
4285.56|4.0|the filter sizes the receptive field
4287.84|3.44|perhaps we can do some optimization in
4289.56|4.84|the Transformer realm that we have
4291.28|5.08|already done in convolution layers yeah
4294.4|3.6|I I think that so that's a good idea
4296.36|4.359|there's there's a great paper on light
4298.0|5.56|convolutions I think from Michael Ali
4300.719|5.361|and David G and a bunch of people where
4303.56|4.8|it's basically uh this this came out at
4306.08|3.8|exactly the same time as the Transformer
4308.36|4.4|and the Transformer is slightly more
4309.88|4.6|optimized for GPU computation but the
4312.76|4.32|the computional model was actually
4314.48|6.28|slightly better than the Transformer um
4317.08|6.159|so I it's definitely worth exploring
4320.76|2.479|okay cool
4324.719|7.401|thanks advant the re ranker
4327.96|4.16|with that does that
4332.6|4.8|advantages TR that yeah so it depends on
4335.719|4.161|the problem I I I think what you
4337.4|5.68|probably want to do is is sort of cast a
4339.88|5.799|white net with bm25 and then just narrow
4343.08|4.32|it down with then search uh so you you
4345.679|3.201|often see that kind of as a two-stage
4347.4|3.72|process where the first one is kind of
4348.88|4.44|noisy you can add noise actually to your
4351.12|4.8|retrieval and then you use the dense one
4353.32|2.6|to filter it
4355.96|6.48|down yeah everyone's trying to maybe
4359.92|6.319|adap their models to
4362.44|6.12|own domain specific area like I think
4366.239|5.881|there are many two ways project one way
4368.56|5.4|is to use instru tuning in learning way
4372.12|4.4|or B tuning like
4373.96|7.08|meth and another way is just the main
4376.52|7.44|topic of this lecture is using rual or
4381.04|6.24|so I'm Wonder besides the low cost
4383.96|7.52|advantage of theal AED way do you think
4387.28|6.48|the capacity or the quality of augmented
4391.48|6.44|can be with those
4393.76|5.919|T learning yeah so I I think actually
4397.92|5.04|what what's going to happen is that all
4399.679|5.681|of this will come together right so so
4402.96|4.96|if you train things like end to end rag
4405.36|5.12|2.0 style then you can also fine-tune
4407.92|5.88|that system on some use case end to
4410.48|5.0|endend right so what why would you just
4413.8|3.32|take the retrieval augmented system if
4415.48|3.239|you can also F tune it on the thing you
4417.12|3.039|care about so I think in the end
4418.719|3.44|everybody's going to do all of those
4420.159|3.52|things and then there's questions like
4422.159|5.321|how do you do that efficiently so that's
4423.679|3.801|why you would use adapter or things like
4428.48|3.84|that think there was another
4432.36|4.4|question I'm curious about Hardware you
4434.76|6.04|say it's going to become database kind
4436.76|8.32|of thing respons database but what about
4440.8|6.24|retrieval hardware and you SM because
4445.08|6.36|we've thought so much of the you know
4447.04|8.48|the Le part but what about because it's
4451.44|6.199|hug trillions said so you have any ideas
4455.52|3.8|just a database problem so I don't know
4457.639|6.08|if I'm allowed to say this exactly
4459.32|6.8|actually but uh so one of the the
4463.719|3.881|biggest chip manufacturers that recently
4466.12|4.24|their stock has done really well they
4467.6|4.2|have some dedicated retrieval Hardware
4470.36|2.76|coming out I think soon or it might
4471.8|5.76|already be
4473.12|7.68|out um so yeah so yeah that
4477.56|6.079|like very efficient uh dense retrieval
4480.8|2.839|is a very big
4486.56|3.44|business are
4491.96|3.32|questions Sol
4498.76|4.68|um yes I I think I think so if you take
4501.04|4.24|it to the extreme so one of the big
4503.44|3.719|problems right now is that that if you
4505.28|3.04|contextualize an existing language model
4507.159|3.281|that already
4508.32|3.28|hallucinates then then it's going to be
4510.44|3.16|kind of hard to get rid of the
4511.6|3.32|hallucination right so if you do replug
4513.6|4.599|on
4514.92|4.799|gp4 gp4 might still hallucinate so you
4518.199|3.121|it could basically just ignore all the
4519.719|3.92|stuff you retrieved and just do whatever
4521.32|3.879|it wants anyway uh so that's one of the
4523.639|3.161|reasons why you want to train the system
4525.199|3.721|end to end and if you take that to the
4526.8|4.6|extreme where like I said right if you
4528.92|4.92|can just have the language model only
4531.4|4.4|reason and speak so it knows English and
4533.84|4.56|reasoning but it has no knowledge which
4535.8|4.879|all comes from somewhere else then then
4538.4|5.92|you can't lose an so it's really all
4540.679|3.641|grounded in whatever is in your
4547.719|4.121|index but they're so they're they're
4549.88|3.44|about hallucination I I'm sort of
4551.84|3.319|frustrated that a lot of people in the
4553.32|3.839|field misunderstand what hallucination
4555.159|3.721|even means right so a lot of people are
4557.159|3.801|conflating hallucination with
4558.88|3.64|correctness or incorrectness so they're
4560.96|3.48|like oh the model made a mistake it
4562.52|3.679|hallucinated it's like no it made a
4564.44|3.48|mistake that's different from
4566.199|4.201|hallucination hallucination I think is
4567.92|4.0|very specific kind of I retrieved
4570.4|3.839|something so I have some sort of
4571.92|5.04|counterfactual ground truth and what I'm
4574.239|3.601|saying uh does not correspond to that
4576.96|5.239|ground
4577.84|5.64|truth um and so yeah I think there's a
4582.199|3.0|bunch of folks that stand for also
4583.48|3.719|working on better like measurements of
4585.199|4.241|hallucination and definitions and things
4587.199|2.241|like
4590.8|5.919|that understanding correctly your of
4593.48|6.759|hallucination only sense in
4596.719|6.361|cont yeah of some ground truth right so
4600.239|4.761|so Hallucination is is really like there
4603.08|3.96|there is something that is true right so
4605.0|3.8|so if we're talking about like
4607.04|3.679|hallucination yeah so if we're talking
4608.8|3.56|about just general parametric language
4610.719|6.201|models then sort of the ground truth is
4612.36|6.799|whatever we can consider to be true
4616.92|4.279|right but we had to word for like
4619.159|4.841|language models making mistakes before
4621.199|2.801|it was called making
4626.0|6.639|mistakes yeah
4628.04|7.8|ground I guess you're solving the house
4632.639|4.841|question on that path are you working on
4635.84|4.04|on
4637.48|7.52|ground you
4639.88|5.12|know never been president everything
4646.88|6.0|this yeah so so I I like the sort of
4649.88|5.16|Silo mention there as well so I I think
4652.88|3.759|the whole point is that you can you can
4655.04|4.8|have different indices and different
4656.639|5.52|definitions of ground truth and so um I
4659.84|4.799|think you could say I only trust the
4662.159|5.52|archive or I only trust like peer review
4664.639|4.401|papers and not just archive uh and so
4667.679|3.121|you can make decisions in your
4669.04|4.88|architecture during test time about what
4670.8|6.2|You' Define as ground truth
4673.92|4.239|and I also think actually that uh and
4677.0|2.44|there's a bunch of work I think
4678.159|3.801|happening on this right now you can
4679.44|5.56|control for how how grounded you want to
4681.96|4.8|be in your ground TR so uh that's
4685.0|3.36|another kind of misconception about
4686.76|3.28|hallucinations like sometimes
4688.36|3.6|hallucinations are actually good right
4690.04|3.4|if you have a creative writing assistant
4691.96|3.64|and you wanted to come up with some cool
4693.44|4.6|new ideas you want the language model to
4695.6|4.079|hallucinate uh so I I think what you
4698.04|3.04|want to have is kind of a tunable knob
4699.679|3.04|where you say like now you can
4701.08|4.8|hallucinate and now maybe you should
4702.719|3.161|like really tell me the truth
4710.76|3.32|only anything
4718.56|5.92|else control
4721.639|4.921|yeah yeah so but the temperature that's
4724.48|5.6|just about how you sample right so how
4726.56|5.36|flat your your distribution is
4730.08|3.639|sample
4731.92|4.0|yeah
4733.719|4.0|yes but so even if you have a low
4735.92|4.2|temperature it can still come up with
4737.719|3.801|random stuff right so it just says that
4740.12|5.039|then you're very likely to do like
4741.52|6.44|greedy sampling um so so I I think what
4745.159|5.56|you want to get at is is something more
4747.96|2.759|sophisticated than
4754.56|4.48|that lots of interesting questions yeah
4757.239|4.521|I like the question thank again for the
4759.04|2.72|great
4761.84|3.0|than