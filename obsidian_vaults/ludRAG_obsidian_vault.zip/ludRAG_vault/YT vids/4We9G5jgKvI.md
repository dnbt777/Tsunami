start_time|end_time|text
1.52|3.84| Yeah, now let's look at another explanation for why dropout
5.36|3.52| might perform well. And this is in the context of ensemble
8.88|3.16| methods. So we can essentially see dropout as an ensemble
12.04|3.44| method, as I will show you in the next couple of slides. And
15.84|2.76| yeah, what is an ensemble method. So students who have
18.6|3.88| taken 451, we talked there about ensemble methods a lot. We
22.48|3.92| talked about, for instance, on majority voting, begging random
26.4|3.48| forests boosting, you don't have to know any of that for this
29.88|4.32| class here. But in a nutshell, what is an ensemble method? It's
34.2|3.66| essentially a combination of multiple models, where you
37.86|3.42| average the results of the models. So you can think of it
41.28|4.84| intuitively. Let's say you have to make an important financial
46.16|4.72| decision, let's say you, you want to make you want to buy
50.88|2.6| something or invest, let's say you want to invest into
53.48|3.52| something. And it's a very important decision. So you
57.0|3.44| consider asking an expert. So the expert here is your model.
60.76|4.6| And it might give you a prediction or some advice. That
65.36|5.24| might be a good advice if it's an expert and expert knows the
70.6|3.44| topic very well. However, in practice, it's usually an even
74.04|4.68| better idea to ask a couple of experts and then consider the
78.72|4.32| shared opinion of the experts. So it's not always better than,
83.52|2.72| let's say the opinion of a single person, especially if you
86.24|2.76| have the committee doesn't agree with a single person and the
89.0|3.14| single person knows something the committee doesn't know. But
92.16|5.08| on average, usually asking a committee of multiple people is
97.24|2.98| a better idea than just relying on the opinion of a single
100.22|4.02| person, right? So in that way, using multiple models, and then
104.24|4.12| averaging the predictions or taking the majority vote is also
108.48|4.16| often a better idea than using a single model. Why don't we do
112.64|3.8| that always then? Yeah, well, because it's usually very
116.44|3.32| expensive to train models, especially in deep learning. So
119.96|3.56| in deep learning, I would say most of the time, we want to
123.88|3.0| focus on a single model, because it's computationally cheaper.
127.06|3.9| And we also often care about improving a model in general.
131.16|3.48| And then, let's say in production, you can always train
134.64|3.76| multiple of these models and then combine them to make the
138.4|4.0| predictions even more robust. In any case, talking about the
142.4|3.8| ensemble approach, know why dropout can be seen as an
146.2|4.72| ensemble method. So you can think of your dropout, the
150.92|3.4| procedure as having a different model for each mini batch,
154.36|4.48| right? So because you randomly drop nodes, each forward pass,
158.92|3.4| each mini batch will see a slightly different model. And
163.24|3.28| essentially, what we do is we sample over two to the power of
166.52|3.52| H models by H is the number of hidden units, if we only
170.04|2.64| consider a hidden layer, if we have multiple hidden layers,
172.68|4.2| well, this becomes even larger. But if you have already, let's
176.88|3.84| say, if you only have a hidden layer with 10 units, you already
180.72|4.36| have 10 to the power of 10 possible combinations of hidden
185.08|3.92| layers that you may sample during each forward pass. So in
189.0|4.88| that way, it can be seen as a model ensemble, except that
193.88|3.84| there is one restriction. And the restriction is that we have
197.72|3.0| a time dimension. So we don't have these models in parallel,
200.72|4.6| right? So what I mean is, if we have, say, hidden layer, a unit
205.48|4.28| network like that, and another network like that, and maybe
211.04|0.96| running out of space,
214.96|3.2| let's say each of these is one multi layer perceptron, I'm not
218.16|4.12| connecting all the units here. But let's say, in this first
222.28|3.32| one, first forward pass, we drop this one, and the other one, we
225.6|3.12| drop this one. And then here, we drop these ones. So we have
228.72|2.92| three different networks here. But we don't use all of them in
231.64|4.96| parallel, right? We usually, because it's a training for for
236.6|5.6| loop, we go through them one at a time. So we have during the
242.2|3.04| first forward pass, maybe this model during the second pass,
245.26|4.74| this for this model, and during the third pass, this model. So
250.0|4.12| there's essentially a time constraints or restriction. And
254.12|4.68| we can also see this restriction as weight sharing, because the
258.8|5.04| second model, receive, it will, the first model will update the
263.84|3.92| weights, and then the second model will be depending on the
267.76|2.4| weight updates from the first model, right? That's just like
270.16|3.04| how the regular training works, because each iteration, you
273.2|4.28| update the weights, and each consequent model will work with
277.48|3.96| the weights from the previous backward pass. So in this way,
281.44|3.4| so in this way, there's like this weight sharing between the
284.88|3.58| different forward passes. So there's a weight sharing over
288.46|3.22| these models. And yeah, we can see that as a type of
291.68|3.76| regularization, like a constraint, an additional piece
295.44|3.42| of information or constraint that we add. So in that way, we
298.86|5.98| can see this weight sharing as a regularization. And still we
304.84|3.0| have, I mean, while we have this weight sharing during training,
307.84|4.92| we could technically create all these different models after
312.76|2.8| training during inference, and then average over all these
315.56|3.52| models. I mean, there's nothing that prevents us from doing
319.08|3.88| that. The only problem with that is if we even only consider a
322.96|3.36| small case with 10 to the power of 10 combinations, this is like
326.32|3.08| a very large combination of models. So this is very, very,
329.4|3.32| very expensive. And this is something we technically
332.72|2.6| wouldn't want to do in practice, because yeah, it's just way too
335.32|4.62| expensive. But yeah, let's just for a second, continue with this
339.96|5.08| thought experiment, and assume we have now created all these
345.04|4.2| models for or during inference. So for instance, if we had a
349.24|3.84| hidden layer with 10 units, we have these 10 to the two to the
353.08|5.08| power of 10 models, let's call that m we have m models now. So
358.16|2.56| how do we average the predictions of these models?
361.04|3.48| For simplicity, think of a binary classification case. And
364.52|4.08| in this case, it's essentially averaging the log likelihoods of
368.6|3.68| the predictions, which is essentially what you probably
372.28|5.12| know as the geometric mean. So for instance, if we have a p
377.44|3.52| probability score p for a given test data point i, so if this
380.96|4.24| test data point i here, then we multiply all these probabilities
385.2|7.04| for the m models and take this to the power of one over m. And
392.24|3.36| here, I was just rewriting this to show you this is essentially
395.6|6.12| averaging log likelihoods. So some of the log likelihood terms
401.72|3.56| here, and then times one over m. And here, I'm just adding the
405.28|4.4| exponent. So I was just taking on considering the lock of this
409.68|4.12| here, and this one undo the undoes it. So it's essentially
413.92|3.34| the same computation. And here inside, you can think of it as
417.28|3.76| averaging the log likelihoods. So essentially, what this is,
421.04|4.0| it's we are computing the geometric mean. So that would be
425.04|5.12| one way we can combine the predictions. And if we have
430.16|5.36| multiple classes, more, more than binary classification, we
435.52|4.76| also want to normalize these so that they sum up to one
440.32|3.22| probabilities, because we have multiple classes, right? If we
443.54|2.5| have multiple classes, we have multiple probability scores. And
446.08|4.04| ideally, we'll want them to sum up to one. And the class level
450.12|3.72| can then be obtained by considering the class with the
453.84|1.32| highest probability.
457.92|3.24| Yeah, but this still doesn't solve our problem that this is
461.16|4.12| very computationally expensive, because we have to consider two
465.28|4.52| to the power of 10 models, right for averaging. And here, this is
469.8|3.88| also assuming that we only have one hidden layer with only 10
473.68|4.12| units. If we have a hidden layer, let's say with 64 units,
477.8|4.4| then yeah, this would be really infeasible. So what do we do
482.2|4.32| about that? How can we address this problem? So actually, the
486.52|2.68| regular dropout technique that we discussed earlier,
489.8|3.16| essentially is already computing this geometric mean, or
492.96|3.56| essentially, it's approximating this geometric mean, because
496.52|3.46| the other scaling factor that I mentioned the one minus p that
499.98|3.74| we use to scale the data after training, when we use the model
503.72|3.18| for testing, this is essentially an approximation of this
506.9|3.18| geometric mean. So we don't have to create all these different
510.08|3.56| models, we only consider the last model after training. So
513.64|3.82| just the model that comes out of training. And then this scaling
517.46|3.94| will essentially compute an approximated version of that
521.42|2.34| geometric mean, as they mentioned in the original
524.0|6.2| dropout paper. And they also argue essentially, if you have a
530.24|5.84| linear model, then the geometric mean would be actually exactly
536.08|2.68| like this scaled version here. So essentially, we are
538.76|2.88| approximating the geometric mean and dropout of a model
541.64|4.2| ensemble. And this is essentially the explanation of
545.84|3.0| dropout, why it might work well, because essentially, we can
548.84|19.0| think of it as a model ensemble.