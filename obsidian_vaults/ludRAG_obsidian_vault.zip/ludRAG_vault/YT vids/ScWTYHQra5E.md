start_time|end_time|text
1.4|4.0| Yeah, let's now take a look at two of the most common weight
5.4|4.84| initialization schemes for deep neural networks. So the first
10.24|3.96| one we start with is called Xavier glorot initialization.
14.2|3.88| Sometimes people just say Xavier initialization. Sometimes people
18.08|4.28| say glorot initialization. So the fact or the name comes from
22.52|4.68| the name of the first author of the paper that proposed this
27.2|4.88| method. So usually this type of initialization is used in
32.28|4.56| connection with a 10 h function, the hyperbolic tangent,
37.12|4.0| activation function. And yeah, recall, this is also a sigmoidal
41.24|3.48| activation function similar to the logistic sigmoid, except
44.72|6.36| that the output is centered at zero. And so where we have in
51.08|4.04| the logistic sigmoid, something like this, I'm really not good
55.12|8.2| at drawing this. Let's try again, where the output is at
63.32|5.28| point five, for the logistic sigmoid, then we have for the
68.76|9.44| 10 h, something more like, like this, where we have one and
78.24|5.64| minus one here. And the if you recall the partial derivative of
83.88|4.6| that function with respect to his input is one. So instead of
88.52|3.4| point two, five for the logistic sigmoid for the 10 h, the
91.92|7.0| derivative at the highest point here in the center is one. So in
98.92|4.12| this case, we have less of a vanishing gradient problem
103.04|4.44| compared to the logistic sigmoid. But of course, it
107.48|5.6| still has the problem of this saturation near extreme values.
113.08|4.08| So here at this point, and here at this point, we have still
117.28|2.96| this very small or zero gradient, which is still a
120.24|4.96| problem. And yeah, this Xavier initialization can act as a
125.2|6.92| small improvement to prevent these extreme values. So how
132.12|4.36| does it work? So it's a essentially a two step procedure.
136.88|4.12| The first step is to initialize the weights from a Gaussian or
141.0|4.72| random uniform distribution. And then the weights in the second
145.72|3.24| step are scaled proportional to the number of inputs to that
149.0|6.04| given layer. And therefore, the first hidden layer, the number
155.04|3.68| of inputs would be the number of features in the data set. And
158.72|4.12| then the second layer, that would be the number of units in
162.84|6.6| the first hidden layer, and so forth. So here's how it looks
169.44|6.0| like. So assume that the weight is initialized from a Gaussian
175.48|6.64| distribution with mean zero and a small variance. And let's say
182.12|4.72| this is our weight matrix from this Gaussian distribution, or
186.96|2.88| random could also be a random normal uniform distribution,
189.84|4.16| sorry. And then you scale it by a factor of the square root of
194.0|5.18| one over ml minus one. So what is m, m is the feature number of
199.18|4.62| features, and l minus one is the layer index. So l minus one
203.8|2.88| means the number of features in the previous layer. So if I have
207.24|6.28| set up like this, and then everything is, of course,
213.56|5.64| connected to each other. So if I initialize the weights here, on
220.88|2.16| I want to initialize these weights here, they are
223.04|6.28| initialized based on the number of features here. Yeah, and if
229.32|3.88| you didn't initialize the bias units to all zeros, you can
233.2|3.4| also include those in the scaling. But yeah, it's fine to
236.6|3.18| initialize the bias units to all zeros. I'm just saying if you
239.78|4.34| don't, then I recommend also including those in that scaling.
245.84|4.24| Yeah, what is the rationale behind applying this scaling
250.08|3.92| factor here? So yeah, that goes back to making an assumption
254.0|3.32| that let's say when we compute the net input, we have a
257.32|4.44| multiplication between the weights and the activations from
261.76|3.24| the previous layer. And you can think of them as independent,
265.02|8.82| right? So and then if you have an increasing sample size, then
273.84|5.28| the variance of so here, I mean, if you have increasing number of
279.12|3.0| units in the previous layer, so that's what I'm thinking here
282.12|5.4| of the sample size, then the sum increases because you have
287.52|2.44| independent variables, right? And then you're just adding up
289.96|3.0| the variances. So you can think of it as the variance of the
292.96|4.76| sum of independent variables is the sum of the variances. And
297.72|5.2| then, yeah, we have a scaling by one over m, where m is the
302.92|5.8| number of the samples, or let's say, it's maybe maybe the number
308.72|4.8| of features would be more correct here. And yeah, the
313.52|5.08| square root is to consider the standard deviation. All right,
318.6|3.88| so yeah, here's just a very, very brief sketch of what I
322.48|4.76| meant. So if we have the variance of the net input, so
327.28|3.28| just focusing on one unit here, this can be expressed as the
330.56|5.32| sum over the weights times the activation from the previous
335.88|5.96| layer. So that's nothing new. And, um, yeah, we can, the
341.84|4.48| variance of the sum is the sum of the variances, right? So we
346.32|5.96| can rewrite this. And here, I'm just extending it into these
352.72|7.6| independent variables. And then essentially, because we have a
360.32|3.64| sum over these values, and they are the same for all the
363.96|5.96| different positions, right? So I can actually say instead of
370.2|4.64| summing over these, I can just say, it's m times this product
374.84|4.16| in a way. So this is where the m comes from, right? So we are
379.0|7.44| then scaling it back by one over m. And since the square root is
386.44|1.36| for the standard deviation here.
389.48|3.08| Alright, so but don't worry about it too much. It's
392.56|3.04| essentially a scaling factor, you can think of it more
395.6|3.84| broadly as a scaling factor that accounts for the number of
399.48|3.68| features that goes into a given layer. So that's the main
403.16|3.96| message here that we take into consideration the number of
408.08|3.4| features. And this is sometimes also called the number of
411.48|1.76| features from the previous layer, it's sometimes also
413.24|4.56| called fan in and I have no idea why it's called like that. It's
417.8|4.28| another term that is commonly used. There's actually a term
422.08|4.36| fan in and there's also the term fan out, I only know everyone is
426.44|3.44| using this like since 10 years ago or something, but I never
430.12|5.72| understood where this name comes from. Alright, so in practice,
435.88|3.84| also, sometimes, if you look at some initialization schemes,
439.88|5.4| sometimes people also include here, the number of output
445.28|2.08| units, for example, they would write it as
447.36|5.88| um, l, u, l is the output number of features that goes out from
453.24|3.24| that given layer. So that's also sometimes some things people
456.48|3.92| sometimes do. But yeah, in practice, I think fan in a small
460.4|1.2| comment and having both.
463.6|3.8| Yeah, so here's a visualization from the Xavier initialization
467.4|4.4| paper. So what they are showing here is a network with a 10 h
471.8|4.04| activation, and without Xavier initialization, just for
475.84|3.32| reference now. So here at the top, this is a histogram, a
479.16|4.44| normalized histogram, showing the activation value for the
483.6|4.0| different layers in the network. And you can see that in the
487.6|3.44| early layers, like one and two, the activations are more uniform
491.04|3.76| spread out. Whereas for the later layers, they are largely
494.88|4.56| zero, it just happens that how the signal propagates through
499.44|2.96| the network that we will see in later layers, the activations
502.4|4.32| are more centered at zero. And yeah, consequently, when we do
506.72|3.12| backpropagation, we have this multivariable chain rule, right?
510.0|4.2| So the we go usually from the right to the left. So if I have
514.2|3.64| a network, let's say like this, that's the forward pass. And
517.84|5.72| then in the backward pass, I start with layer five, and then
523.56|4.48| multiply things until I reach layer one when I do the updates.
528.36|3.4| So what you can see here is for layer fives, we have back
531.76|3.6| propagated gradients that look reasonable in a range, let's
535.36|4.8| say, between minus point one and point one. But then the further
540.16|3.52| back I go, I get this vanishing gradient problem, you can see
543.68|4.16| that the early layers almost get zero gradients most of the time,
548.56|3.68| which can then be a problem. So in this sense, the network will
552.24|3.48| mostly only update the later layers, but almost ignore the
555.76|4.48| earlier layers. So this can be a kind of, yeah, not good if you
560.24|5.64| want to train a neural network well. So then here's the
565.88|3.08| visualization showing what I showed you on the previous
569.0|5.8| slide. And here, a version with the Xavier Xavier initialization.
575.6|3.84| So you can see at the bottom, this looks much better if they
579.44|3.28| use the Xavier initialization, you can see that all the
582.72|3.04| gradients are in a reasonable range for all the different
585.76|3.2| layers. So in this way, that's actually pretty nice, it fixes
588.96|3.72| this issue that some layers learn better than others.
594.04|3.8| Alright, so there's another initialization scheme. So
597.84|5.32| Xavier initialization scheme was assuming that you use the 10 H
603.4|4.08| activation function, there's also something called initialization.
607.48|2.8| So this comes from the fact that the first author on that paper
610.6|6.16| was named Kim or his name is timing her. And yeah, like I
616.76|2.88| said, previously, we assumed that the activations had a zero
619.64|5.76| mean or mean zero, which is reasonable. When we use the 10
625.4|5.32| H activation, because it's centered at zero. But for you
630.72|3.56| for relu, it's different, because the activations are not
634.32|6.92| centered at zero anymore, right? If we have a relu function, I
641.24|4.36| will only have positive values, right? Because everything looks
645.6|4.56| almost like a leaky reload. Um, because everything here on the
650.2|5.88| left side, left from zero will be set to zero, right? So in
656.08|3.36| that way, we don't have the activation centered at zero
659.44|3.96| anymore. So this paper proposes a method that works better with
663.44|3.4| relu units where we don't have the weights centered at zero,
667.08|2.64| or sorry, the activation centered at zero. There's some
669.72|2.64| complicated math in that paper. If you're interested, you can
672.36|5.04| check that out. But the bottom line is that we would add just a
677.4|4.04| scaling factor of two here. So in total, we would add a
681.6|4.72| sometimes people call that gain, we would add a gain of square
686.32|3.6| root of two. And we can just put it inside here. So essentially,
689.92|3.16| it's just adding a scaling factor. And this addresses the
693.08|4.28| issue with having the activations not centered at zero
697.36|7.64| in the case of relu. Oh, sorry, it Okay, so yeah, so you don't
705.0|3.72| have to, I would say worry about these types of things too much
708.72|4.0| if you just use regular neural networks. So there are
712.72|3.78| reasonable defaults in pytorch. So this video was more like
716.5|3.6| illustrating that different weight initialization schemes
720.1|4.98| exist. But in practice, I mean, it is a good idea to choose a
725.08|4.68| good initialization scheme. But yeah, mostly, frameworks handle
729.76|3.32| this automatically pretty well these days. So I will actually
733.08|4.06| in the next video show you how this is done in pytorch and how
737.14|18.98| we can change the initialization scheme in pytorch.