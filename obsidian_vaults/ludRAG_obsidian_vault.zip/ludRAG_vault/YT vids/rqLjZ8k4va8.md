start_time|end_time|text
0.84|2.88| All right, now just for fun, I will show you how we can
3.72|4.28| replace a fully connected layer with a convolution layer. And
8.0|2.68| because it's so much fun, there are actually two ways of doing
10.68|3.12| that. So we will have to twice the fun. Alright, let's start
13.8|3.84| with the first one. So on the left hand side, I'm showing you
17.64|3.12| for reference a fully connected layer that we have seen before.
21.12|3.96| So in order to fit it onto the slide, this fully connected
25.08|4.6| layer has exactly four inputs and two outputs. So yeah, you
29.68|4.52| remember, of course, how we compute these, right. So let's
34.2|3.52| start with the green ones are in green. All the connections in
37.72|4.24| green. These are one weight vector, let's call it w one. And
41.96|5.82| the output here is the green dot. And we multiply the weight
47.78|6.02| vector, of course, with the inputs here, the input x. And
53.8|2.72| then we also have some bias unit, the bias unit is not
56.52|5.36| shown, but it's added, why not? So that would be added here. And
61.92|2.9| yeah, this is how we compute the first output. So let's call that
64.82|3.9| maybe output one. And then we have output two. And we compute
68.72|2.64| it the same way, except now that we have these yellow
71.36|5.32| connections, which is our w two. And actually, we can do the same
76.68|3.0| thing exactly the same computation, using a
79.68|4.04| convolutional layer. How does that work? So yeah, we would
83.72|5.72| arrange our four inputs as an image, let's say as a two by two
89.44|6.08| image here, right. And then we can have a let's focus on the
95.52|6.2| green one. Now, we can have a kernel that has one input
101.72|7.72| channel kernel with a one input channel, and two by two kernel
109.44|4.12| size and width. So the kernel is two by two with one input
113.56|6.64| channel. And here, this would be our w one, the first kernel,
120.2|3.8| let's say the green one here. Alright, so this is one kernel.
124.96|4.08| And the second kernel could be this w two here, which is again,
129.36|4.2| a kernel with one input size, or one input channel, sorry, and a
133.56|6.48| two by two kernel size. And if you recall how we compute the
140.04|5.64| convolution for, let's say, the receptive field here, this is our
149.88|7.0| receptive field. And this is here in green. This is our sorry,
156.92|3.64| this is the output, of course, here in green. This is our
160.56|4.0| kernel. So this one is essentially, you can think of
164.56|5.64| this operation essentially as similar to a dot product,
170.2|2.76| essentially, if you, you multiply those, right, it's a
172.96|4.48| weighted, weighted input, and then you compute the sum. So
177.44|5.36| there's a sum over these, and then you add the bias. And it's
182.8|3.2| exactly the same computation as this one. And I will show you in
186.0|2.2| the next slide with the code implementation that it gives you
188.2|7.12| exactly the same results. So in the grand scheme, grand big
195.32|4.0| picture scheme here, this would be a case where we would have
200.36|3.92| two kernels with one input channel and a kernel size of two
204.28|4.84| by two. Alright, so it's maybe more complicated than it seems.
209.32|3.52| So let's just take a look at a code example to maybe for those
212.84|4.04| who prefer code examples to have another look at this. So here,
216.88|7.0| again, this is our fully connected on setup. So I'm
223.88|3.52| defining here my inputs, I'm just using some made up
227.4|7.04| numbers 1234. And I'm shaping them here such that they are
234.44|4.36| shaped in this n ch w format that we usually use for
238.8|6.52| convolutional networks. So we have one batch size of one, one
245.32|5.28| input channel height is two width is two. Then I'm defining
250.6|10.04| my fully connected layer here for inputs to outputs. Here are
260.64|4.6| my weights. So on the previous slide, this would be our w one
266.04|4.96| here. So I can actually use the same colors maybe. So let me
271.0|4.4| because this was green, let me use the exact same colors. This
275.4|11.28| is green one. And this is orange one. And the bias B two is the
286.68|7.2| yellow one. And here the green one, that's the one. And now
293.88|4.48| I'm just assigning them to the weight and bias in the fully
298.36|3.24| connected layer in the linear layer. Why am I doing that
301.6|4.4| here? That is because when I call this function here, it will
306.0|3.44| use random weights. And I want to compare this to a convolution
309.44|3.36| network. So in that way, I'm using fixed weights and a fixed
312.8|4.04| bias unit just for Yeah, just for showing you that I can do
316.84|3.36| the same thing with a convolution network, so that the
320.2|5.76| numbers are not random here. Um, yeah, then I'm calling here the
325.96|3.04| fully connected layer on my inputs, I'm reshaping this to a
329.0|3.52| long vector, of course, so I'm making so this is a two by two
332.52|3.76| right here, two by two, I'm just reshaping it such that as a long
336.32|5.28| vector here with four units, and then you can see the results of
341.6|7.4| 14.9 and 19. Now I can do the same thing here with my
349.0|6.4| convolutional setup. So the kernel size I'm going to use is
355.4|5.36| two by two, because it's two by two here. And I'm just getting
360.76|3.08| rid of the first dimension. So this is all I'm doing. Because
363.84|2.84| in the inputs here, I have it on the left hand side. For
366.68|2.56| reference, I'm just getting rid of these dimensions. So the
369.24|4.64| first squeeze, squeeze dimension zero will get rid of the first
373.88|3.6| one. So first dimension, and this one will get rid of the
377.68|2.56| second dimension so that I have my two by two. I mean, these
380.24|3.04| dimensions were empty, right? These were essentially just
383.28|3.6| these square brackets. I'm essentially was just getting
386.88|6.76| rid of these square brackets. Yeah, then I'm initializing my
393.64|3.72| convolutional layer here, one input channel to output
397.36|6.44| channels. So I have essentially two kernels. And the kernel
403.8|12.96| size is two by two. And here, just printing out the sizes. And
417.04|5.68| here, I'm assigning the weights that I had on the previous
422.72|6.64| slide. So I'm assigning these weights here to my
429.36|3.52| convolutional weights. Why am I doing that? It's not cheating or
432.88|2.48| something. I'm just trying to use the same weights. Because
435.36|3.92| when I initialize that, I will of course get random weights.
439.52|2.04| And I don't want to do this experiment with random weights,
441.56|2.68| because then it's hard to compare, right? So we have to
444.24|3.58| use the same weights. So here, I'm just using the same weights
447.82|2.24| and the same bias. And then here, I'm calling my
450.06|4.46| convolution. And you can see, I get exactly the same results as
454.52|2.56| with my fully connected layer, except of course, the
457.08|3.48| difference is that they are differently arranged, because
460.56|4.62| here, we have channels with a fully connected layer, we don't
465.18|2.98| have channels, inputs and output channels. So the dimension might
468.16|4.0| look different, but the results are exactly the same. So this is
472.32|3.56| one way you can replace a fully connected layer with a
475.88|5.12| convolution layer. Another way, this is the second way would be
481.0|5.36| to take these, these fully connected, sorry, this vector
486.36|7.56| here, and stack it. So we stack it with four channels. And then
493.92|4.76| you can use four kernel, sorry, two kernels with four channels
498.72|5.12| each. So you have now still two kernels, because we will have
504.16|3.68| two output maps on your two output feature maps, we can now
507.84|10.92| use two kernels with four channels to implement the same
518.8|5.82| as we have implemented here. Now going back here, I had two
524.62|9.46| kernels with one channel each. Now I have two coins with four
534.08|3.36| channel each, the difference really is only that I have them
537.44|3.4| stacked here. Whereas here, I have them arranged in this two
540.84|4.76| by two fashion, both ways would result in equivalent results
545.6|3.4| compared to the fully connected layer. If you don't believe me,
549.28|3.64| here's another example. So here, I'm now having my convolution
552.92|3.96| layer with four input channels to output channels. So this is
557.08|6.08| essentially the four channels to kernels setup using my same
563.16|4.16| weight, so I can compare them. And we will again get exactly
567.32|3.18| the same results. So these are two different ways we can
570.5|5.82| replace a fully connected layer with conversion layers. So just
576.4|4.12| revisiting our all convolution network where we had this
580.6|3.54| adaptive pooling. So we can now for instance, instead of using
584.14|3.66| adaptive pooling, could of course use a fully connected
587.8|3.94| layer, but we could also use our new idea of just using a
591.74|3.94| convolutional layer here. So to make this all convolutional
595.68|4.5| network even more convolutional. So here, now I will set the
600.18|2.52| kernel size to eight by eight, because we found out in the
602.7|3.78| previous code notebook, that here at this stage, the feature
606.48|4.48| maps will be eight by eight, or 64 by eight by eight. So 64 is
610.96|3.6| the channels eight by eight is the height and width. So that's
614.56|2.96| why I'm setting it to eight. And this, if you run this, it will
617.52|3.12| give you exactly what it will not give you exactly the same
620.64|2.48| results as the adaptive pooling, because now we have more
623.12|2.92| parameters, but it will run it might even give you better
626.04|6.8| results. And here's last thing for this video, here's a
632.84|3.24| comparison, a direct comparison between the fully connected
636.12|5.0| implementation of a network, and the fully fully convolutional
641.12|5.52| version of that. So on the left hand side, I have here
646.64|4.68| convolution 2d setup with 64 input channels and 64 output
651.32|4.96| channels. And then I'm flattening it. So if these are
656.28|6.36| 64 times eight times eight, here, I'm flattening this so
662.64|7.32| that this gets combined into the number of features. That's what
669.96|5.2| I have here. So number of features, and then my output is
675.48|4.1| the number of classes. So this is my last layer. But that's
679.58|3.86| how we would usually do it. But if you have for some reason, an
683.44|2.64| aversion against fully connected layers, you could achieve the
686.08|3.4| same thing using convolution layers. By the way, I also
690.16|4.76| tried that a few years ago, just for fun. On with more serious
694.92|4.36| networks, there's usually no exam, no benefit. I thought back
699.28|4.28| in the day, it might be easier for the implementation and
703.56|2.88| CUDA to achieve better performance with that, because
706.44|3.52| you could probably leverage better parallelism with multiple
709.96|3.48| GPU cores. But in practice, I found almost zero difference
713.48|3.2| whether we use fully connected or convolution layers in the
716.68|2.78| last layer. So this is here, really, what I'm showing you is
719.46|4.9| really just more like a toy experiment or an example that we
724.36|3.0| have the ability to do that, to achieve the equivalent results,
727.36|3.3| but it's not necessary. So you don't have to worry about that,
730.66|3.14| or you don't have to do that. And just like illustrating this
733.8|4.24| here, if you wanted to, I mean, it's more like, I think it could
738.04|3.6| be technically be helpful to understand how convolutions work.
741.82|3.74| But again, you can even think of this video as entirely optional.
746.12|5.44| So here on the right hand side, now I'm showing you the
751.6|5.76| equivalent implementation, where I'm setting a convolution layer
757.36|6.72| to 64 input channels. It's like before, and the output is the
764.24|6.68| 64 classes. So here, this is really the number of classes in
770.92|6.56| the drawing here. We only had two classes, but let's say, in
777.48|7.12| cipher 10, we would have 10 classes. Alright, so that's what
784.6|4.56| I'm setting it to. And this is then here, the eight by eight,
789.48|6.24| because we had 64 by eight by eight in the previous layer, or
795.72|3.16| we're assuming that. And for this to work, this has to have
798.88|5.52| the size of the feature map of the previous layer, because we
804.4|6.44| want to have a one, one by one output here. And you can run
810.84|3.92| this and it will work. And it should give you equivalent
814.76|3.72| results to the left hand side implementation. If you try that
818.48|3.16| in practice, and you find that results might be slightly
821.64|3.0| different, that might have something to do with a random
824.68|3.32| weight initialization, because every time you call a layer, it
828.0|4.28| will create random weights. So this makes it hard to compare,
832.28|3.2| but in theory, it should give you the same results, because as
835.48|6.96| we've seen before, here, it's exactly you're producing the
842.44|4.32| same results. Okay, so these were just some fun videos now are
846.76|3.6| not fun. But I would say thought experiments how we could
850.36|4.2| technically get rid of non convolution layers if we have an
854.56|4.52| aversion against fully connected or pooling layers. And in the
859.08|4.56| next video, I will go back to a more important topic transfer
863.64|3.12| learning, which I think will be very useful for your class
866.76|27.84| projects, because it helps us leveraging related data sets.