start_time|end_time|text
1.96|3.84| Yeah, since we talked so much about logistic regression now, I
5.8|3.14| thought that might be a good opportunity now to introduce two
8.94|4.06| terms logits and cross entropy, because that's what I will also
13.0|5.0| use quite often later in this class. And that's because also
18.0|4.08| it's a very common. These are two common terms in the deep
22.08|3.2| learning literature. I sometimes refer to it as the deep learning
25.28|3.04| jargon, because, yeah, we sometimes use these terms a
28.32|3.32| little bit differently in statistics, compared to deep
31.64|4.16| learning. So I just wanted to briefly clarify how they relate
35.8|3.48| to the concepts we just discussed. If this doesn't make
39.3|3.46| complete sense, I mean, we will be using these terms later. And
42.76|6.6| you will then have something to refer back to. Okay, so in deep
49.36|3.48| learning, when we have multi layer neural networks, let's
52.84|3.76| say, I will just draw a very simple one here, we will
56.6|3.32| actually talk about them on Thursday. So if we have multi
59.92|3.44| layer perceptron like this, everything is connected to
63.36|2.72| everything here, it's a fully connected layer. And then we
66.08|4.48| have this one output node. And in this network, we also have
70.58|3.46| net inputs similar to add a line or logistic regression. But now
74.04|4.32| we have two net inputs, one is here, let's call that z one. And
78.36|2.94| one is here, it's z two, we will talk more about that on
81.3|3.38| Thursday. But yeah, in deep learning, it's very common to
84.68|5.1| call these here, the net inputs that come before the output to
89.78|2.34| call them the
93.6|0.96| the logits.
96.04|4.16| In statistics, the logits have a specific meaning. This is the
100.52|5.16| logarithm of the odds or log odds. And in the context of
105.68|3.24| logistic regression, which we just covered, these logits are
108.92|2.4| naturally the net inputs.
111.32|3.96| So where does that come from? This is the inverse of our
115.76|2.08| logistic sigmoid function.
122.04|5.6| That's our logistic sigmoid function here, just, I just
127.64|5.8| abbreviated it as P. So the log of P over one minus P, this
133.44|9.0| function is the inverse of this function. And yeah, so in deep
142.44|4.56| learning, though, it does not necessarily any relationship
147.0|4.68| between the log odds and the net inputs of the last layer. It's
151.68|2.4| just like, I think it's derived, the term is derived from
154.08|3.76| logistic regression, people call that logit logits in the context
157.84|4.4| of logistic regression, and then just generalized to this wording
162.24|3.76| to arbitrary multilayer perceptrons, where we may not
166.0|3.24| even have a sigmoid function, as we will see later. So you can
169.24|4.88| just think of it as the net inputs of the odd of the last
174.16|5.16| layer, basically. So here, just for reference, so here on the
179.32|3.52| left hand side, the logistic sigmoid function and here on the
183.2|3.2| right hand side, the logit. So the logit function is the
186.4|2.96| inverse of the logistic sigmoid function. So basically how it
189.36|2.72| looks like, I don't think I have to go into do that into the
192.08|2.68| to that in much detail, because we have seen that before. And
194.76|5.4| this is essentially just flipped. So there is another
200.16|5.04| concept that is maybe a little bit confusing, but it's exactly
205.2|3.68| what we've covered before. Actually, we had a seminar at UW
209.12|3.48| last week, where we also, yeah, it was briefly mentioned,
212.6|2.76| coincidentally, there was like a question whether it's the same,
215.6|3.64| the negative log likelihood and cross entropy. So yeah, the
219.24|3.08| negative log likelihood and the binary cross entropy are
222.32|4.32| equivalent. And in practice in deep learning, people just say
226.64|4.68| cross entropy, multi category cross entropy, which would be a
231.36|2.36| multi class version of the negative log likelihood, which
233.72|3.52| we will cover later in this lecture when we talk about the
237.24|5.24| softmax function. So just to keep it brief, the negative log
242.48|4.64| likelihood that we just covered a few videos ago, is the same as
247.12|3.64| what people call the binary cross entropy, they were just
250.84|3.24| formulated in different contexts. So negative log
254.08|3.96| likelihood comes more like from, I think it's like, it's probably
258.04|3.56| from a statistics context, I don't know the first paper, or
261.6|2.36| reference that mentioned that. But this is something usually I
263.96|3.92| see in statistics papers, and the binary cross entropy thing
267.88|4.2| has originated from the field of information theory, or computer
272.08|5.28| science. So we have actually seen that, or not, the cross
277.36|3.08| entropy, where we have seen the self entropy, or just entropy,
280.76|4.44| and statistics 451. For those who took this class, in fall
285.2|4.6| semester, where we had used the entropy function in the context
289.8|5.16| of the information theory and decision trees, but we used a
294.96|4.52| lock to instead of the natural algorithm, but yeah, it's kind
299.48|3.78| of somewhat related, if you have taken any class where you
303.26|7.26| talked, for example, about the KL divergence, or callback
310.52|2.6| Leibler divergence, which measures the difference between
313.12|4.32| two distributions, the KL divergence is essentially the
317.44|7.72| cross entropy minus the self entropy. Of course, you don't
325.16|3.28| have to know that it's just like a fun tidbit here. The only
328.44|2.96| thing you have to know is or should know, because it's useful
331.4|2.68| to know, is that the negative log likelihood is the same as
334.08|3.44| the binary cross entropy, this is like a useful thing to know.
337.96|4.32| And this is what we've discussed in the previous videos. And
342.28|3.52| there's also a multi category version is the multi category
345.8|3.16| cross entropy, which is just a generalization of the binary
348.96|4.48| cross entropy to multiple classes. So in order to make
353.44|3.56| that negative log likelihood or binary cross entropy work for
357.0|5.16| multiple classes, we assume a so called one hot encoding, where
362.16|3.36| the class labels are either zero or one for some reason, it was
365.52|3.74| cut off here. But this is something we of course, haven't
369.26|3.02| discussed yet. And if this doesn't make sense yet, we will
372.28|2.68| actually discuss that after the logistic regression code
374.96|3.16| example, when I will introduce the multinomial logistic
378.12|3.76| regression model. So again, all I wanted to say here is the
381.88|6.16| logits in deep learning, usually refer to the net inputs of the
388.04|5.96| layer that just comes before the output. And the term binary
394.0|3.2| cross entropy and negative log likelihood are essentially the
397.2|3.64| same. Alright, so in the next video, I will show you a
400.84|2.76| logistic regression code example. And then we will take
403.6|9.28| a look at this multi category cross entropy.