start_time|end_time|text
0.9|3.62| Yeah, hi, everyone. I hope you had a nice weekend. So today is
4.52|3.64| the last time I want to dedicate a whole lecture to just your
8.16|2.8| techniques for improving generalization performance in
10.96|3.44| neural networks. So in the upcoming lectures, I will talk
14.4|2.58| about new neural network architectures, for instance,
17.28|2.76| convolutional networks, recurrent neural networks,
21.2|3.3| auto encoders, generative generative adversarial
24.5|4.58| networks, transformers, and so forth. So yeah, today is really
29.08|4.08| the last time we will just talk about improving generalization
33.16|3.48| performance. And in particular, the topics I have in mind are
37.24|4.16| optimization related. So there's one topic called learning rate
41.44|4.6| schedulers. So it's how we can improve stochastic gradient
46.04|3.32| descent learning by decreasing the learning rate over time
49.36|2.96| during the course of training. And the other topic is here
52.32|3.72| replacing stochastic gradient descent by modified versions of
56.04|3.36| stochastic gradient descent. For instance, there is a momentum
59.4|2.72| term that we can add. And there's also something called
62.16|3.52| adaptive learning rates. So we will learn about an algorithm
65.68|3.04| called Adam, which combines adaptive learning rates and
68.76|4.28| momentum to make learning I would say easier. So you have to
73.04|3.84| do less fiddling with hyper parameters, but also it can
76.88|4.84| converge faster. So I should say though, everything we talked
81.72|3.16| about so far in terms of these tricks like batch norm dropout
84.88|3.12| and so forth, activation functions today, the
88.0|3.16| optimization algorithms, they also apply to all the
91.16|3.44| architectures we are going to cover in future lectures. So
94.6|2.84| it's all kind of relevant, I thought it's just like, yeah,
97.44|2.56| nice to get that out of the way. And then when you learn about
100.0|2.64| new architectures, you are already familiar with these
102.64|3.2| tricks. And you don't have to think about what these different
105.84|3.48| terms mean when I show you some implementations of those that
109.32|2.88| make use of these tricks. So with that, yeah, let's get
112.2|2.4| started. And yeah, and by the way, if you're watching this on
114.6|4.84| Wednesday, also, yeah, happy send per text day. Yeah, in the
119.44|3.52| past couple of weeks, we already covered a bunch of topics
123.16|4.64| related to improving neural network training. For example,
128.0|4.72| we talked about regularization to reduce overfitting. Examples
132.72|3.48| of that included L two regularization, what we call also
136.2|5.16| weight decay, or yet robot. And then last week, we discussed how
141.36|3.96| we normalize our inputs and hidden layer activations. And
145.36|2.76| for instance, yeah, the input standardization and batch
148.12|3.84| normalization. And there were some other tricks like weight
151.96|3.2| initialization schemes like Xavier glorot and kaming her,
155.4|3.92| which can also improve neural network training. So in this
159.32|4.32| lecture, we will discuss tricks related to the optimization
163.64|3.72| algorithm. So there will be a section on the learning rate
167.36|5.24| decay, momentum learning and adaptive learning. I should say
172.76|4.04| these are all techniques that concern your first order
176.8|3.32| methods for optimization, stochastic gradient descent. So
180.12|3.96| they are essentially all modifications of stochastic
184.2|4.2| gradient descent. If you are familiar with more advanced
188.4|3.6| optimization techniques, you may wonder why we don't talk about
192.08|3.36| second order methods. For example, if you consider the
195.44|3.8| Hessian matrix, and you have the partial, the second order
199.28|3.68| partial derivatives. So the reason is, yeah, people, many
202.96|4.08| people tried using those techniques, but it just turns
207.04|3.4| out they don't work very well in practice, they're either way too
210.44|5.04| expensive, but also don't really result in faster training in
215.48|6.0| terms of your epochs and better performance. So usually, even
221.56|3.16| maybe if you find that it requires fewer epochs, these
224.72|4.12| methods are computation is still so expensive that you don't gain
228.84|3.08| anything by using second order methods, or at least I haven't
231.92|5.96| seen up to this day are convincing method that really is
237.88|4.36| widely used in practice. But maybe I mean, never, never say
242.24|4.0| never. So it doesn't mean there won't be any technique in in the
246.24|3.6| future that may work well. It's just like that we don't have
249.84|5.4| them yet. So the topics we are going to cover today are these
255.26|5.14| six. So first, I want to talk about learning rate decay. So a
260.4|4.72| very simple topic concerning the learning rate and reducing it
265.12|4.2| over the course of training to reduce the noise and stochastic
269.32|3.12| gradient descent, I will show you then how we can do that in
272.44|5.16| pytorch. And then we will talk about a momentum term that we
277.6|6.04| can add to our gradients to help accelerate gradient descent in
283.64|3.4| the right moments and slow it down in other moments or steer
287.04|4.68| it better in that way. Yeah, there's also a topic of adaptive
291.72|3.28| learning rates. So adaptive learning rates, especially
295.0|4.0| coupled with momentum are commonly used nowadays, there's
299.0|3.8| one algorithm called Adam, which is probably the most widely used
302.8|3.92| optimization algorithm, I use it all the time, because it works
306.72|3.52| very well out of the box, you can get good results with
310.28|3.84| stochastic gradient descent and momentum too. But in my
314.12|3.32| experience, at least, it requires more hyper parameter
317.44|4.12| searching over the learning rate and Adam is usually more robust
321.56|3.92| and works often better out of the box, it requires less work in
325.48|4.0| a sense. I will then show you how we can use these algorithms
329.48|6.52| in Python. And there are also so many other algorithms besides
336.0|4.16| that say Adam and momentum that have been emerging in the recent
340.16|3.72| years. I have a huge list of these topics that I find also
343.92|3.36| sometimes relatively interesting where I do some reading here and
347.28|3.8| there about the latest trends. So I will make a separate video
351.4|4.8| outlining some of these advanced studying topics. So you don't
356.2|5.24| have to Yeah, you won't have to know these things in detail. But
361.44|3.76| for those who are interested to in reading a little bit more,
365.2|2.96| let's say beyond the scope of the class, I will just include
368.16|2.84| some references here that you may want to check out in the
371.0|4.12| future and on your own, for example. Alright, so let's get
375.12|20.52| started then with the first topic learning rate decay.