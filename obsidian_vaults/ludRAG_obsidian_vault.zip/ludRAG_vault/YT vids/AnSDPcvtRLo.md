start_time|end_time|text
0.78|3.32| Yeah, here's a lecture overview of all the topics we are going
4.1|3.9| to cover today. So first, in this video, we will start with
8.52|3.92| the brains and neuron models, just like a big picture
12.44|3.08| overview. And then in the next video, we will talk about the
15.52|3.8| perceptron learning rule, which is related to the Rosenblatt
19.36|2.68| perceptron, which we briefly talked about in the last
22.04|4.28| lecture. And then I will have a short interlude on
26.32|3.56| vectorization in Python. That is just like a quick note of how
29.88|4.04| we can make computational code in Python run more efficiently.
34.28|3.88| So that is usually by replacing for loops with vector dot
38.16|3.12| products, because that's something we're going to need in
41.28|3.68| the next video when we talk about implementing a perceptron
45.12|5.44| in Python using NumPy and pytorch. Then optionally, I
50.56|3.48| have a video of planning to make a video on the perceptron
54.04|4.0| convergence theorem. So I have to see how long these videos
58.04|3.72| take, whether we have time for that. Because, to be honest,
61.76|3.04| this is not like a super important topic. So and I don't
64.8|3.44| want to talk about it for too long, and then not having enough
68.24|3.08| time for other topics in this class, which I think are more
71.68|4.08| relevant and more important. Here, the perceptron convergence
75.8|3.6| theorem, that's a mathematical proof, it may be useful for some
79.4|3.84| of you in other contexts. But to be honest, it's not really that
83.24|4.06| useful for deep learning in the grand scheme. So if we cover it
87.3|2.78| or not, it doesn't really matter for the rest of this course. So
90.08|3.08| in this way, we have to really see how much time we have. And
93.16|3.14| then lastly, I want to give a brief intuition into the
97.32|4.16| geometric aspects of the perceptron, but one thing at a
101.48|5.48| time. So let's start with brains and neural models. So yeah, like
106.96|3.68| you recall from the history on deep learning, things were
110.64|4.48| inspired by biological brains and how neurons work. So here's
115.12|3.64| a picture of a neuron and then zooming in, sorry, of a brain
118.76|3.52| and then zooming in a little bit. These are some neurons in
122.28|2.12| the brain. I think this is actually from a mouse brain I
124.4|4.6| took from Wikipedia. And here's zoomed in version of a particular
129.0|3.08| neuron. Here, I think you can nicely see that neurons are
132.08|3.04| connected to each other. Here in this neuron, this is a
135.12|4.8| specific type of neuron. It's a pyramidal hippocampal neuron. So
139.92|3.2| it's a neuron in the hippocampus, the pyramid
143.12|3.52| unit neuron. And there are many different types of neurons in
146.88|6.04| the brain. So this is only one type of neuron. Yeah, and also
152.92|3.28| the big question is usually, do our brains use deep learning at
156.2|2.92| all? So in the human brain, is there some deep learning
159.12|3.84| algorithm running? Actually, I don't think we can answer that
162.96|4.96| with full certainty, because people don't know yet how human
167.92|3.46| brains work exactly. There are still many things that are not
171.38|4.32| clear yet, and many things that are still mysteries. However, I
175.7|5.38| think we can confidently say, though, that it's probably not
181.08|5.36| true. Because, yep, the brain is very complicated. And deep
186.44|4.56| learning, it performs well, and certain tasks like object
191.0|4.36| detection, and so forth. But to be honest, the human brain and
195.38|3.9| the capabilities of neural network are still very
199.28|3.12| different. So because we don't have artificial general
202.4|4.68| intelligence, I think that it's like an indicator that maybe,
207.44|3.04| maybe deep learning works differently. However, recall,
210.48|4.1| there was also this paper by Joe Fenton, where they looked at the
214.58|3.38| different learning algorithms, we briefly discussed that last
217.96|3.6| lecture, where they were the authors, it was not by Joe
221.56|2.8| Fenton, he was, I think, the last author on that. Think
224.36|2.48| Lily crap was the first author and doesn't, but doesn't really
226.84|7.32| matter. So the, um, the gist was that the brain may use type of
234.24|3.16| algorithm that is somewhat related to backpropagation. But
237.4|4.32| even that was not fully clear. So that still remains to be
241.72|4.14| seen. But to be honest, also, it doesn't really matter that much
245.86|3.58| whether the human brain does deep learning or not. Because
249.48|2.4| deep learning, the things we have are actually pretty
251.88|3.58| efficient for certain things that we are some people care
255.46|3.3| about, for example, object detection for object detection,
259.12|3.12| classifying objects in the image, deep learning performs
262.28|3.88| reasonably well. And it's kind of like, similar to the analogy
266.16|6.84| of the airplane, and how birds work. So someone was inspired by
273.12|4.16| your whole birds fly or here in this case, geese, and build the
277.28|4.16| first airplanes. However, it wasn't that important to exactly
281.44|3.72| mimic the bird, right? I mean, airplanes don't flap their
285.16|3.16| wings. And I think also, if you would design airplanes that have
288.56|3.8| flapping wings, it wouldn't be more efficient than, let's say,
293.12|3.24| airplane with flapping wings. So in that way, it's not always
296.36|3.76| important to make something like exactly the same. Sometimes it's
300.12|5.2| just useful to take something as an inspiration, and then you can
305.32|2.96| develop things on top of it, but they don't have to be exactly
308.28|4.38| the same to be useful. But yeah, just out of interest, I looked
312.66|4.08| up on Wikipedia, the number of neurons because one might argue,
317.04|3.64| maybe neural networks are not as good as the human brain in terms
320.68|4.02| of doing certain tasks, because the number of neurons is maybe
324.7|4.3| different. When I look up the number here, it says 16 billion,
329.0|6.96| 340 million neurons in the human brain. So here, in this case, we
335.96|3.22| have 16 billion, if I look at the killer whale, it has 43
339.18|4.46| billion. So I would say human brain, or humans are more
343.64|5.36| intelligent than whales. Also, we can't answer that with 100%
349.0|2.96| certainty, but that's my assumption here. So it can't be
351.96|3.24| just the number of neurons that make something more intelligent.
355.64|6.84| Also, if you think back of the large scale language models that
362.48|3.52| I introduced in the history of deep learning lecture, I think
366.0|3.36| the big ones, they are GPT three and stuff, you have to double
369.36|6.56| check, but I think they had like 170 180 billion nodes in that
375.92|3.48| were parameters. So in that way, these models are actually even
379.42|3.1| larger than the human brain in terms of the parameters, if you
382.52|5.64| think of a parameter as like a neuron. So in that way, these
388.2|4.04| language models are even more powerful in terms of the
392.24|3.48| computation than the human brain or at least more, more
395.72|5.2| parameters. And these models don't really perform as well as
400.92|2.72| the human brain does. One thing they perform well, it is like
403.64|4.6| memorizing information. So these large scale languages, language
408.24|3.64| models, ingest lots of data from the internet, like lots of
411.88|3.28| documents and can kind of memorize them pretty well. And I
415.16|3.46| think humans are not that good at memorizing things. But on the
418.62|2.86| other hand, humans are better at understanding, which is
421.48|3.42| something then these models lack. So it can't be just the
424.9|3.06| number of parameters, there must be something different. But what
427.96|4.64| it is, that has to be yet has yet to be discovered. Yeah, so
432.6|2.5| in this lecture, we are actually talking not about neural
435.1|3.94| networks, we're talking about a single layer neural network or
439.04|4.88| a ballad. Yeah, and also in this lecture, we're not going to talk
443.92|3.54| about multi layer networks and networks with many, many, many
447.46|3.54| parameters, we are going to start simple talking about a
451.0|3.76| neural model. So model of the biological neuron, like a
454.76|3.48| computational model of the biological neuron. So just to
458.24|4.56| recap what a biological neuron is a neuron is a nerve cell. So
462.8|4.48| here's a circuit one neuron where you have the cell core or
467.28|4.16| nucleus, there are the dendrites where other neurons connected to
471.6|4.0| and there's the exon, the exon is where the signal gets
475.6|4.08| transmitted. So usually, signal arrives at the dendrites, then
479.68|3.44| it gets integrated or processed at the nucleus, and then it gets
483.12|8.4| transmitted. If the neuron is activated to these endings, nerve
491.52|4.64| endings, and they are basically connecting to dendrites of other
496.16|4.6| neurons. So yeah, so called connections that are connecting
500.8|5.84| to neurons and whether this neuron provides a signal or not
506.64|3.02| to the next neuron really depends on what happens in the
509.66|3.14| processing core here, which is something we will talk about.
514.2|4.0| Yeah, the earliest neural model, the earliest mathematical neural
518.2|3.88| model was the McCulloch pits model that we discussed in the
522.08|4.6| history of deep learning. So just to briefly recap, so here's
526.72|5.6| approximately how it would look like. So you have the inputs
532.32|4.16| here. So the x's are your inputs, let me close more clearly
536.48|7.6| here. These are your inputs. And then you have certain weights
544.08|4.0| here. So these are my weight parameters. And then this is our
548.12|3.28| nucleus, that's where the signals get integrated. So it's
551.44|4.84| a weighted sum. So you can also write it as, let's say in this
556.28|7.84| case, if we have x m m inputs, then you can write it as
567.68|4.64| follows where you have each input multiplied with each
572.36|3.8| weight. So this is the weighted input. And in deep learning, we
576.16|5.64| usually call that the the pre activation, we use usually the
581.8|6.08| mathematical letter z, we also call it sometimes the net input.
587.92|3.6| So that's more like a traditional term. So and this
591.8|5.64| value here is then passed onto a threshold function. And when the
597.44|5.64| signal here reaches a certain threshold, then a corresponding
603.08|4.32| signal gets transmitted. So the binary signal binary means a zero
607.4|6.56| or one in this context. So zero is transmitted, if the value of
613.96|2.48| the weighted sum is below the threshold, and the one is
616.44|3.92| transmitted, if the one is above the threshold, but we will see
620.36|3.38| that in more detail when we talk about the perceptron learning
623.74|5.34| rule and the perceptron model. So here's an example of an
629.16|3.6| integrate that you can implement with this mechanics and pit
633.04|3.56| neuron. This is just a recap also from the last lecture. So
636.6|4.56| if you set these weights to one, then our weighted sum is just x
641.16|7.24| one plus x two. And if the sum is bigger than 1.5, then it
648.4|5.32| returns a one. In this case, because one plus one is two,
653.76|3.32| right? So one plus one is two, which is greater than the
657.08|4.04| threshold. So you return a one. And otherwise you return a zero
661.12|4.52| because if only one of the two is one, then you won't reach the
665.64|4.92| threshold of 1.5. And then the output is zero. And this would
670.6|2.88| this would be an end gate. Similarly, you can also
673.48|4.16| implement an or gate. So here, the threshold is smaller. So the
677.64|3.84| weights are still one. So you're computing x one plus x two, and
681.48|5.36| compare that value to the threshold. If both are one, in
686.84|3.96| this case, the value is two and two is bigger than point five.
690.8|5.32| So you return a one, if one of the two is one, then also your
696.16|2.36| value is larger than the threshold, right? Because one
698.52|4.1| plus zero is one, it's greater than point five. So you also
702.62|4.62| return a one in both cases, only if both are zero, then you
707.24|4.8| return a zero because zero plus zero is zero. So this is how you
712.04|3.92| could use this concept of the McCulloch pits model, for
715.96|5.0| example, to implement different first order logic functions. Yeah,
720.96|2.88| you can also implement a not gate. So I don't want to go into
723.84|4.52| too much detail here. But yeah, you can walk through this maybe
728.96|4.28| by yourself. And then another one as a take home exercise. Can
733.24|5.52| you implement a logical x or function in using this McCulloch
738.76|6.44| spit neuron? So here's the table of x or function. Can you find
745.2|5.52| weights here? And can you find a threshold such that this simple
750.72|5.24| model here can implement the x or gate as an ungraded homework
756.0|4.84| exercise? You can maybe post on Piazza in a few days to see
760.84|4.28| whether this is possible or not. Alright, so this was just a
765.12|3.28| brief introduction. Let's now talk about the perceptron model
768.4|7.0| and the perceptron learning rules.