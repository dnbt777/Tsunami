start_time|end_time|text
0.0|3.04| Yeah, hi, everyone. So in this video, I want to show you some
3.2|3.88| computational resources that you might find helpful for your
7.08|3.0| later homeworks, but also for your class project, where you
10.08|3.56| can use a GPU for free to accelerate the training of
13.64|3.52| certain new networks. So with that, let me minimize this
17.16|3.8| screen and then show you hands on how we would do that.
22.44|2.64| Yeah, to start with, I found this very nice GitHub
25.08|3.96| repository called deep learning in the cloud, I will share the
29.04|4.02| link with you. And here, the contributors and maintainers put
33.06|3.3| together a really nice list of all the different tools that are
36.36|5.2| available for training deep networks in the cloud. So most
41.56|2.84| of them also, yeah, supported GPUs, because that's the whole
44.4|4.44| point. So it's like for cloud GPUs. And yeah, not all of them
48.84|3.72| are free. But here, the most popular ones, as far as I know,
52.56|3.88| most people, when they use free cloud GPUs, they use either
56.44|4.74| Google Collaboratory, or Kaggle kernels, both of them are free.
61.24|2.38| There are some limits, though, in terms of the runtime, I
63.62|4.24| think you can only use one GPU, and it resets after 12 hours.
68.54|3.2| But it's still nice to have an option here to use free services,
71.74|4.68| especially as a student. We have the CHTC on campus, which is a
76.42|2.68| high performing computer cluster. However, this would
79.1|4.44| require, I think more like more experience from your side, like,
83.54|2.84| it would be more something for later research projects, if you
86.38|3.4| don't have experience with Linux yet, it might be a very steep
89.78|3.52| learning curve, in addition to everything we use in the class,
94.02|4.64| here in our lecture class. So in that way, I think to get going,
98.66|2.84| if you're new to everything, these are definitely more
101.78|6.04| beginner friendly. Alright, so he has a lot of options, some of
107.82|4.16| them have a fixed number of free hours, or they give you a
111.98|3.76| startup credit, for example, free $300 of credit for these
115.76|5.66| types of things. And at the bottom, I also wanted to mention
121.42|4.16| there is I think, yeah, there's more stuff. So also, especially
125.58|4.04| for students, there are some extra special offers, which are
129.62|3.48| also super nice. So for simplicity, I will walk you
133.1|5.52| through Google Collab, how we can use Google Collab for a
138.62|5.2| project. So let me click on this. And then it should open up a
143.82|3.96| new notebook here. So notice that this is a notebook
147.78|2.96| environment. It's Yeah, it's a blessing and occurs notebook
150.74|3.04| environments are easy to use. And what's nice is you can also
153.78|3.76| see the results in there. But as code becomes more complicated,
157.54|3.4| sometimes a cloud environment would be also nice where you
160.94|3.84| have Python scripts. But yeah, you can explore the list and see
164.78|3.4| what's best suited for you. Ultimately, it's really up to
168.18|2.72| you what you want to use for your class project. So there's
170.9|3.68| no requirement using one environment over the other, it's
174.58|4.08| really up to you. Because this is a relatively beginner
178.66|4.06| friendly, let me cover this one here. So one important thing if
182.72|3.66| you want to use this is to actually select a GPU to make it
186.38|4.12| available. For that you have to go to runtime, and then change
190.5|5.04| runtime type, and then choose GPU, you can also use TPUs. But I
195.54|5.96| recommend for this class to use GPUs. Alright, so and then we
201.5|5.4| can check if pytorch is available. So let me type import
206.98|8.12| torch, and then torch dot version just to see. I don't
215.1|4.68| know why it's so slow. It's loading 1.7, which is a recent
219.78|3.52| one, which is nice. And also, I think this is like a Google
223.3|2.8| specific thing, because usually that is something that doesn't
226.1|3.24| show up when you import torch on your normal computer. I think
229.34|4.44| this just means that it has CUDA 10.1 support. Also, just to make
233.78|6.08| sure that it indeed recognizes the GPU. Sorry, CUDA is
240.14|6.32| available. Just to make sure it shows true. For example, we just
246.46|4.12| try this if the GPU is not available, it should return or
250.58|13.0| did I say this, it should return faults. Yep. So if you see
263.58|9.76| faults, make sure you have GPU checked here. Alright. Now, what
273.34|3.32| we can do is we can open notebooks. So we can, for
276.66|5.04| example, add a new notebook. So it's a new window here. Okay.
282.12|3.34| There might be also Yeah, that's what I wanted to know. Open a
285.46|2.36| notebook. So you can actually open notebooks directly from
287.82|3.12| GitHub. So for example, you could technically go to our
290.94|4.68| class repository here. And then let's choose what we covered
295.62|6.36| last on Tuesday. So add a line with autograd and pytorch. Let's
301.98|5.28| use that one. So I'm opening that here, and I'm copying it.
307.42|3.6| And then I can directly have the link here. So which is very nice.
311.02|4.32| So I can need to search it first. Yeah, I can directly open
315.34|7.88| it. Okay, I think I just can click on it. No, stay on page.
323.26|4.58| This was not the right one. Okay. Yeah, let me try this
327.84|5.46| again. Think I need to click this one. Open notebook a new
333.3|5.92| tab. Okay. Sounds good. So yeah, here we have now our code so I
339.22|6.72| can choose the runtime, the GPU. And then we can actually run it
345.94|6.16| right. So let's do it. Watermark this didn't work. Oh, okay. So
352.1|3.4| this is a warning message because it's a notebook not from
355.5|5.08| Google. Just like wanting let's say run anyway. Okay, so we get
360.58|3.34| an error. What is the error module watermark has not been
363.92|4.98| found. So this is because Google Collab comes with some packages
368.9|3.32| pre installed. But of course, it doesn't have every possible
372.22|2.78| Python Python package pre installed. So some packages we
375.0|2.78| have to install ourselves. It's actually not too complicated. We
377.78|4.36| can just use this exclamation mark, which is a terminal
382.14|4.84| command for executing a bash terminal command. So we can run
386.98|4.84| for example, pip install, so pip install watermark, and then it
391.82|5.56| should install it. Yep. So it's loading it and then successfully
397.38|7.08| installed. And then this should work. Right, this works. So this
404.46|4.08| is just a general way of how you can install packages. Then if
408.56|3.26| you have packages that are not already installed in Google
411.82|6.1| Collab, okay, moving on, loading torch, pytorch, now loading our
417.92|4.7| data set. Oops, another problem. So yeah, the thing is we loaded
422.66|3.32| the notebook, but we didn't not lot the data, right. So if I go
425.98|4.32| back here to the repository, there's this data sets, sub
430.3|4.12| folder with an iris data set, which this notebook doesn't know
434.42|3.34| about because the link is this one here. So how, how can it
437.76|3.2| know where to load the data from? I mean, one way would be
440.96|9.26| for CSV files to just copy the link here, this should work, I
450.22|3.88| guess, it's loading because pandas can log directly from CSV
454.1|4.64| file. So this worked. So I can just show you that X train
458.74|4.56| should be loaded. But usually in practice, consider a case where
463.3|4.12| you have a data set that is not on GitHub that is maybe on your
467.42|3.14| computer. And it's also not a CSV file. So you want to have a
470.56|2.7| more general solution. So how can you do that? For that, you
473.26|6.72| have to mount your Google Drive folder. So this is a little bit
479.98|2.8| complicated, I will I have already actually put together
482.78|2.78| some slides that I will share with you after recording this
485.56|5.82| video. So assume we have this data set locally, let's download
491.38|5.44| this here. So I'm downloading it right now. So then I'm opening
496.82|7.12| it here. And then let me go to my Google Drive. So I have a
503.94|3.96| Google Drive folder here, my drive, and then I have a sub
507.9|3.16| folder colab notebooks, this should be originally or
511.06|3.56| automatically generated. Actually, let me save this
514.62|5.96| notebook. So it says cannot shave same changes. And this is
520.58|7.2| because Yeah, we, we don't have permission for saving it yet. So
527.78|4.64| we have to make a copy. So it means basically doesn't. It's
532.42|3.76| loaded directly from GitHub, it doesn't allow us to overwrite
536.18|2.04| the GitHub repository, which makes sense. So let's make a
538.22|4.8| copy of this in our Google Drive. It's completed. Okay, new
543.02|4.96| tab. So this is our copy of Adeline. If I load this
547.98|2.6| directory now, or if I refresh this Google collapse, you will
550.58|5.08| see here, this is now in my colab notebooks folder. So you
555.66|5.24| can also directly go here, if you have code on your computer
560.9|5.5| and just drag and drop it here. And then you can go right click
566.42|4.04| open with Google Collaboratory. That is also a way to do that.
571.06|5.76| Now, assume I have my data set that I want to connect with my
576.82|4.16| notebook. So I let's say I have a data set here on my hard drive
581.34|4.36| or whole data set folder, I can just take that and also drag and
585.7|6.88| drop that here. So it's now data set data sets. So it's the same
592.58|7.08| structure as shown here. So it's next to my notebook. So let's
599.66|8.1| see if we can load it now. Too many sessions. Okay, let me
607.76|8.7| close this one. And this one. Okay, there's still too many
616.46|6.72| sessions. Okay, let me terminate this one. And this one. And
623.18|6.76| maybe also this one. All right. Let's try again. Okay, now it
629.94|9.6| works. Okay. So technically, we might think, okay, we can load
639.54|3.38| the data now, because it is relative to our notebook in this
642.92|4.36| data sets up folder. So it's located here, right? However, in
647.28|3.5| practice, there's still a file not found error. And this is
650.78|3.56| because, yeah, that's like a little quirk, we have to mount
654.34|5.88| our Google Drive to or into this notebook. So how we do that, if
660.22|9.48| I recall, it's from Google, dot, call up, import, mount, and
669.7|6.36| then, sorry, I think it's sorry, from Google, important drive,
676.06|6.72| and then drive, mount. And then, let me just look this up,
682.82|3.24| because I've actually made that in my slides, just to make sure
689.66|5.84| I type the right thing here. Okay, mount content and drive.
695.54|7.36| Interesting. Okay, so from Google, colab, import drive, and
702.9|5.12| then mount content, I will share the slides with you after this
708.02|5.78| video. So we can do this. Then it asks us to enter an
713.8|4.06| authorization code, which we can do by following this link. Let
717.86|7.2| me just confirm this. Yep. And I can copy this, enter it here.
725.06|6.16| All right, this my authorization code now it should be mounted.
733.3|4.78| Take some time. Okay. So now it should work. So let me load the
738.08|4.98| data. Still a file not found. Okay, so the reason is, we have
743.06|4.72| no mounted this drive, but it is, it requires a little bit
747.78|2.84| more information about that. Because the notebook, you can
750.62|2.52| think of it, it sits in some arbitrary place on a Google
753.14|3.3| server. And this data set sits on my Google Drive. So you have
756.44|3.06| to be a bit more specific and provide a concrete address. So
759.5|9.04| it would be, let's see, content, drive, my drive, and then call
768.54|7.32| up notebooks. So this is essentially, if you follow here,
775.86|3.36| my drive, Google, call up notebooks, and then data sets.
779.22|6.22| So this is what we have here now. So this should now work. So
785.44|4.76| yeah, this finally worked. Um, it seems a little bit
790.2|2.68| complicated, but technically, it's not that complicated. I
792.88|3.48| showed you a lot of things that don't work to motivate or to do
796.36|2.32| it here step by step. But technically, you can also just
798.68|2.0| leave these lines in your notebook, and then it should
800.68|3.56| work. So you only have to do it once if you and then for the
804.24|4.84| next project, you can copy and paste it. But there's also one
809.08|4.6| little addition I want to make. And that is there are two
813.68|3.64| computers involved here right now, or at least two servers,
817.32|3.8| one is Google Drive, where your data set is sitting. And one is
821.12|4.08| this notebook that is running on a different computer instance
825.28|3.52| at Google. And the communication between those computers can be
828.8|3.8| a little bit slow, slow, because it goes over the internet. So to
832.6|3.28| speed things up, when we work with more complicated data sets,
835.88|5.04| it's actually better to copy this data to the same computer
840.92|3.16| that is running this notebook. So for example, what you could
844.08|5.08| do is you can do on a copy. So you can say,
851.64|3.0| be tree. So you can copy.
859.08|3.32| Yeah, that's what I want. You can copy these data sets here
862.4|7.12| to a local folder for data sets. So you copied it, and then you
869.52|6.24| can again use the original link. And if you have large data sets,
876.0|4.0| the training will be faster when we use pytorch data loaders if
880.24|2.92| the data set is located locally like that. So yeah, I just
883.16|4.44| copied it from Google Drive to this local directory called
887.6|3.64| data sets. So this is what I would recommend. And even for
891.24|2.52| other than that, I would actually recommend if you have
893.76|4.04| more complicated data sets to make a zip file. So here, for
897.8|3.32| example, in my case, I could just go, go here, compress data
901.12|5.08| sets. I have this data sets dot zip file. And then I go to this
906.2|5.76| folder here, and drag and drop it here. So it's not data sets
911.96|6.4| dot zip. And then I go here. And instead of copy tree, because
918.36|10.08| it's a single file, I will just copy data sets dot zip. So I'm
928.44|6.72| just copying it here. And then I can unzip it and zip data sets
935.16|6.98| dot zip. Oops, I need the exclamation mark, because this is
942.14|5.42| not a Python command. This is a bash terminal command. And it
947.56|3.92| asks me to overwrite this because I already have a data set
951.48|8.28| like this in my drive. So yeah, this should work now. Okay. So
959.76|4.36| this should then also work. In that way, this is my recommended
964.12|3.96| way, using the zip file, and then unzip it on on this
968.08|3.0| machine. Of course, for something simple like Iris, it's
971.12|3.72| overkill. But later, we will see we will be working with data
974.84|3.52| loaders. And for example, large image data sets like MNIST,
978.36|4.16| where you have 50,000 images, and it's just faster to upload,
983.36|4.52| or copy a single file and then unpack it compared to uploading
987.88|4.2| 50,000 files like small little files. So in this way, it's like
992.08|3.84| my recommended approach, if you use Google Collab. Alright, so
995.92|4.32| this is yeah, then how you use the GPU. Actually, we haven't
1000.24|4.56| used the GPU in this notebook here yet. Just to quickly
1004.8|3.72| continue. So if you wanted to use the GPU, you have to do one
1008.56|6.76| additional step, you have to touch device, use the GPU,
1015.32|3.74| actually. So there's only one GPU in this computer. So we use
1019.06|3.54| the index zero, which stands for the first GPU, this one would be
1022.6|2.8| the second GPU, third GPU, fourth GPU, and so forth. He has
1025.4|10.56| only one GPU. So we can just transfer it to the one GPU. Oh,
1035.96|4.44| okay. So one issue is this is our manual implementation. So
1040.4|3.16| this, of course, doesn't support the GPU, because it's not using
1043.56|6.08| the model class. So let me yeah, doing this very spontaneously
1049.64|5.4| here, let me run this regularly. And then go to the automatic
1055.04|5.2| one. So auto line automatically, this is the one using module. So
1060.24|4.84| if you do that, then this one will technically support the
1065.08|5.48| GPU. So we do this one. And then it should run on the GPU. We
1070.56|2.26| have to make one more modification for the training
1072.82|7.22| data set, I assume. We'll see if that runs. All right. So yeah,
1080.08|4.64| see, it says some argument is on the CPU, while it's expected to
1084.72|3.28| be on the GPU. So that is because we also have the same to
1088.0|7.44| do the same thing for the data set. So let me see. I assume we
1095.44|1.24| can simply
1100.12|1.24| do the same thing.
1103.32|3.96| For this one, and this one.
1107.28|7.64| Let me get a typo here. Oh, yeah, one.
1118.0|3.76| Yeah, so now it works. So I also transferred the data to the GPU.
1121.96|3.84| If you have the model on the GPU, it also expects the data to
1125.8|3.64| be on the GPU. So in the later code examples, I will have a
1129.44|2.16| flag to do this more automatically, where you only
1131.6|2.68| have at the top of the script, where you only have to specify
1134.28|4.6| it once. And then it will automatically update it
1138.92|4.92| everywhere where you want to use the correct device. Alright, so
1144.12|3.96| yeah, that is just a quick tutorial how to use the GPU. I
1148.08|3.56| have also these slides here for the Google Collab, and I will
1151.84|3.48| also upload them. So I hope that was useful. And let me know if
1155.32|9.12| you have any questions.