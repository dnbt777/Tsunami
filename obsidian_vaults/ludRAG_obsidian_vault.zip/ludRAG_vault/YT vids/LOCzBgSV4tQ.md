start_time|end_time|text
0.56|2.84| Alright, let's now take a look at a code implementation
3.4|3.26| regarding the character RNN that we talked about in the previous
6.66|3.7| video. So in the previous video, I gave you some overview of the
10.36|4.92| LSTM and the LSTM cell. And I prepared two notebooks. One is
15.28|5.24| based on using I can maybe just scroll down for now on using the
20.52|8.48| LSTM class and one is based on using the LSTM cell class.
29.0|3.04| Personally, I think for this type of model, it makes more
32.04|3.2| sense to use the LSTM cell, it's a little bit I think, more
35.24|4.36| intuitive. So going back to what I talked about in the previous
39.6|4.56| video. So here, that's the LSTM cell class, and we'll work, we
44.16|5.36| will only consider one layer, I mean, we can easily extend it
49.52|4.64| for multiple layers, but we will only have one layer. So let's
54.16|7.2| blend that part out. And we will essentially, so if you consider
61.36|4.16| this part, we will receive one initial hidden state, and one
65.52|5.24| initial cell state, together with that input token, like
70.76|4.72| this, it will receive one input token, hidden state cell state,
75.52|3.04| and then produce one output, and this output will go to a fully
78.56|3.4| connected layer to do the character prediction, then we
81.96|3.24| will move to the next input. So here, the next input, it will
85.2|4.04| receive the hidden state from the previous time step and the
89.24|3.28| cell state from the previous type step, together with a new
92.52|2.56| character, and then it will produce again, an output that
95.08|3.32| goes to a fully connected layer to predict the next character.
99.96|3.52| Then we will go on here again, it will receive receive the
103.48|3.32| hidden state and the cell state from the previous time step, the
106.8|3.84| current time step input, output something and so forth. So
110.64|5.52| that's how the LSTM cell class works. All right, but before we
116.16|4.76| get to this part, the LSTM cell class, let's start at the top.
121.0|7.96| Let me even because it's quite fast to run. Let me even run
128.96|3.16| this from scratch. We haven't done this in a long time. All
132.12|4.12| right, so I mean, from scratch, I mean, by executing it as we go
136.24|5.44| here. So we start by implementing by just importing
141.68|4.64| some libraries. So here, I didn't use any helper files, I
146.36|2.48| tried to keep everything in the notebook, because the code here
148.84|6.2| is relatively short and simple. So here, I have some hyper
155.04|4.84| parameters like the text portion size. So how long a typical text
159.88|3.68| portion is the number of iteration for iterations for
163.56|3.08| training. So here, we don't use epochs, we just use iterations.
169.0|5.84| Learning rate, the size of the embedding and the size of the
174.84|7.32| hidden layer. Okay, execute that. Running this on a CPU. I
182.16|2.84| actually had problems running this on the GPU. I think there's
185.0|4.88| a bug in pytorch. So it runs fine on the CPU, but on the GPU,
190.28|3.12| it will restart the kernel. And if I run this in my terminal,
193.4|3.96| without Jupyter Notebook, it gives a segmentation fault. And
197.48|6.6| my suspicion is that it's a bug in pytorch. And because it's
204.08|3.16| maybe related to the fact that it's loading the data too fast,
207.24|5.56| and there's some, it's trying to access some memory in the GPU
212.8|3.32| that is not free yet. So actually, this shouldn't happen.
216.12|3.84| So I believe there's a bug somewhere. But anyways, it's
219.96|6.0| quite fast, we can run this on the CPU. Okay, so we use this as
225.96|5.36| our character set from the string Python library. So string
231.32|3.88| is like a standard library in Python for string related
235.2|4.5| things. And we will use all printable characters. So a bunch
239.7|8.1| of them actually, how many are there? Let's see 100. So we will
247.8|4.36| want to use the set of 100 printable characters. So numbers,
252.16|6.36| lowercase, uppercase letters and special characters. Yeah, so
258.64|7.6| actually, so we will use has the data set the COVID-19 FAQ from
266.24|3.8| the University of Wisconsin website, I went actually to that
270.04|7.56| website, and extracted all the FAQ questions here. So as you
277.6|4.0| can see, there was a lot of text. So I just copied everything
281.6|5.28| into a text file. So this is our training set. So COVID-19
286.88|7.6| related questions on our university website. Okay, so
294.88|3.48| here, I'm just opening and loading the text file. So in
298.36|4.8| total, we have 84,000 characters in our text files like a small
303.16|6.8| book, almost. Okay. So here, I have a function for getting a
309.96|10.2| random portion of the text of size, text length. So we have
320.16|4.52| this text portion, sorry, my text portion size 200. So it
324.68|5.4| gets text of the portion size 200 from the whole text here
330.08|8.32| randomly. So this will be our training batch. Okay, so this is
338.44|2.76| a random portion. So you can see some letters are chopped off.
341.2|3.88| But for our simple case here, it's good enough. So again, this
345.08|3.16| is not perfect. So you may in real world application, you
348.24|3.52| won't make me want to implement the function that it has like
351.76|3.88| complete sentences or something like that. To just keep things
355.64|3.36| simple. This is just a simple function, just getting 200
359.0|7.12| characters at a time. Then I have a function converting the
366.12|6.52| characters here to tensors. So here, this is just getting the
372.64|3.56| index for the characters. So if we have 100 characters, it gets
376.2|6.08| the index, right? So a would be index 10, and so forth. So it's
382.28|3.48| converting the strings into numbers that we can work with
385.76|6.44| in pytorch. And this is putting those things together. So this
392.2|3.64| is for drawing a random sample for training. So this is just
396.16|3.12| getting a random text portion and string format. This is for
399.28|4.72| converting a string to integers. And this does both. It's getting
404.0|5.32| the random portion, right? converts that into integers.
410.32|4.6| And then it also gets our labels. So the labels are the
414.92|4.16| inputs shifted by one character, because here, our task is yet to
419.08|3.88| predict the next character in the sequence, right? So if I do
422.96|4.12| that, and draw my random sample, so my random samples are 094,
427.08|5.08| 24, and so forth. And you can see, the target is shifted just
432.16|4.04| by one, right? Because if we are here, and we want to predict
436.2|3.6| the next character, the next character is 94. And from here,
439.8|3.56| the next character is 24, and so forth, and integer
443.36|6.24| representation. So this is our, our batch of features. And this
449.6|8.52| is our, these are our labels. Okay, so here's now our RNN
458.12|3.56| implementation. So I just have something to keep track of the
461.68|4.76| hidden size. This is our embedding layer that goes from
466.92|4.16| the integer, the character integer to the embedding vector,
471.08|7.24| a real value vector of size, let me see of size 100. And the
478.32|5.52| hidden dimension is 128. Okay, so we have the embedding size,
483.84|8.04| and then the LSDM cell takes vectors of size 128, and has a
491.88|3.8| hidden size of one, sorry, of 100, and has a hidden size of
495.68|6.76| 128. So if I go back to my slides, maybe using this
502.44|3.64| representation here, so our text, we had here a one hot
506.08|5.86| encoding. This is when we want to compute the loss, we use
511.94|2.26| actually just an integer here. So here, this would be the
514.2|4.26| integer two, the integer zero, and integer one, if you look at
518.46|5.06| this here, right, so this one in this figure would correspond to
523.52|6.16| an S, for example. And then the embedding layer will output 100
529.68|5.4| dimensional vector, and the hidden layer will be a 128
535.08|6.68| dimensional vector. So let's see how we use that actually in the
541.76|4.44| forward pass. So in the forward pass, we first put the character
546.2|4.36| through the embedding. So this will be accepting batch size
550.56|3.24| embedding dimensionality, we use only one character at a time. So
553.8|3.84| it will be one times embedding dimensionality, which is in our
557.64|7.16| case, 100. Then we give to the RNN, which is an LSDM cell, we
564.8|5.84| give the embedded vector, which is the one times 100, together
570.68|5.36| with a hidden state, and the cell state from the previous
576.04|5.84| iteration. So this, if we are here, essentially, or maybe use
581.88|5.64| the other representation again, so if we are, let's say the
587.56|5.08| first step here, so we are currently running here, this
592.64|3.4| RNN, it will get the hidden state and the cell state from the
596.04|4.84| previous iteration. This is these two. And these we provide
600.88|6.86| them via by the forward pass as input. So these will go into
607.74|3.7| this one, and these will return a new set of hidden and cell
611.44|4.36| states. So here, these are the inputs. And then they return
615.8|5.6| these outputs here, these two for the next round. And then
621.44|5.68| this is computing our logits for the softmax for the cross
627.12|6.04| entropy loss. So this one output here, this is essentially this
633.16|4.28| one through a fully connected layer. So this will be it's
638.0|7.28| clearer like this. So this will be like this. So we'll be giving
645.28|7.08| us one output where here we have a fully connected layer in
652.36|6.06| between, gives us one output. Okay, and we return the output
658.42|4.58| because we use it for computing the loss. And also, when we want
663.0|2.88| to take a look at the text so that we can generate some text,
666.44|6.68| the next character. And then also, when we want to generate
673.12|2.92| text, of course, we have to feed the output back into the input.
676.04|5.36| So if I go back, there are too many slides here, when I go back
681.4|3.6| here, this visualization, this is for training, but for
685.0|3.88| generating text, we feed the output here. So we get this
688.88|3.64| input, produce an output, and the output gets fed to the next
692.52|7.24| time step is input, so that we can generate new text. Um, yeah,
699.76|11.76| anything else? Yeah, just the dimensionality for reference.
711.96|9.24| Anything else? This is not right here. I think this should be on
721.2|10.68| definitely not this one should be the number of characters. Oh,
731.88|3.6| but here I said hidden state output size would be the output
735.48|14.12| size fixes. Okay. Yeah, then we so we are one more thing. We
749.6|4.48| have this initialization of the zero state. So here, we have to
754.08|8.08| start somewhere, right? So if I go back to my visualization,
763.68|7.24| here, so we get rid of one of those. So here, we don't have
770.92|3.28| initial input input input is here. So we have to have some
774.2|5.68| some zero state here. And this is here, my zeros, just just some
779.88|5.44| initial state. Okay, and all right, then let's get started.
785.32|2.72| So actually, the output size, I should mention this is the same
788.04|9.08| size as the input size. Yeah, so let's initialize the RNN. So as
797.12|3.44| input size is the length of the number of characters, it's 100.
801.08|3.08| So the output size would be also 100. In between, we have
804.16|4.28| the embedding and hidden dimensions. I'm using Adam.
809.88|3.4| Just simpler. He has an evaluation function. Let me get
813.28|5.68| to the evaluation function in a second. Let me first run this.
820.44|4.6| And this can already execute this. But I will talk about
825.04|3.56| this after after talking about the main training loop, because
828.6|6.48| the evaluation function here, it's actually used as it used
836.2|4.52| here. So it's just one tiny part of the training function. So
840.72|3.88| let's talk about the big picture training function first. So I'm
844.6|6.96| just iterating 5000 times 5000 steps, then I have my
851.56|3.76| initialization here. So this is for initializing my zero state.
855.32|3.96| So this is for initializing here, these initial states, I
859.28|4.56| can actually make this bigger, right? So this is for initializing
864.0|9.64| these zero states here. This for each iteration, so each, so each
873.64|4.2| iteration will go through one text portion of size 200. So for
877.84|2.96| each text portion, we initialize it as zero, this is our
880.8|4.56| beginning of the text. What we do is we set the loss to zero,
887.64|4.88| draw a random sample. So again, the random sample will be like
892.52|5.44| this, just some text, some random random text portion, and
898.08|8.56| the targets shifted by one value here. We put it on the GPU. In
906.64|6.8| our case, nothing happens because we use the CPU. Then for each
913.44|5.8| character in the text portion size, this is where we do the
919.24|3.6| step, putting it through the model. So here, this is just
922.84|4.94| for making the dimensionalality right, because this is just one
927.78|7.42| single value. But as you recall, we want one times sorry, batch
935.2|3.94| size times one. So it should be a 2d tensor. So we are doing
939.16|5.04| unsqueezed adding empty dimension. We provide the hidden
944.24|3.76| from here, the cell state from here, these initial cell states.
948.24|2.56| So in the first round, these will be the initial ones. But
950.8|3.24| then we are also outputting them, right? So it will feed
954.04|3.68| back right back. So in the next iteration, these will be used
957.72|2.96| from the previous iteration. So it will feed right back. And we
960.68|4.84| are computing the loss, we are just adding the loss here. So we
965.52|2.8| are computing the loss between the outputs and the targets one
968.32|5.92| at a time. And then we just normalize by the text portion
974.24|4.56| size. So we have, it's just the average the mean, mean over the
978.8|4.64| batch size, if you will, because we add, let's say 200 losses,
983.44|4.92| and then we divide by 200, just averaging that's just so that
988.36|3.64| it works better with a learning rate. So we can change the text
992.0|2.92| portion sizes and shouldn't have to worry about changing the
994.92|5.68| learning rate. Then we call backward, make a step and update
1000.6|4.68| step. And that is it. So here, we just have some logging, and
1005.28|3.8| some more logging, it will create a PDF with a plot, the
1009.08|4.56| loss plot, so we can take a look at it during training. There's
1013.64|3.64| also a tool called tensor board, which is actually pretty useful.
1017.28|3.68| But we already have so many things to talk about and code
1020.96|2.64| examples and everything, I don't want to make it more complicated.
1023.72|5.04| So we're just using matplotlib here. But yeah, the one last
1028.76|3.48| interesting part before I run this is the evaluation function.
1032.52|3.6| So instead of just printing out the loss, in addition to that,
1036.32|4.64| I'm also evaluating the model. So what do I mean by that? I'm
1041.0|3.96| letting it generate text. So let's take a look. This is my
1044.96|4.76| this is my evaluation function. So we initialize it to the zero
1049.72|5.16| state, then we build up some hidden state, we are priming
1054.88|10.04| this essentially. So what that means is, we are providing some
1064.92|4.28| prime character is like some starting character here, place
1069.2|5.94| holders a actually use th. So all texts will start with th that
1075.14|2.5| we are generating is just I mean, it's arbitrary could be
1077.64|8.16| anything. So all texts will start with th. And then here,
1085.8|2.72| we're priming it, we are building up some hidden states
1088.52|5.6| so that the model stabilizes. So we are doing this for the
1094.12|3.28| letters in this prime range. So we only have two letters, right?
1097.4|4.6| We can have actually more we can have some real words, spills up
1102.0|5.52| all our cell state. So it's just, it's just essentially
1107.52|3.6| running in this case, through two of these, right, one, two,
1111.56|6.72| and then we get to this part. And for each, in the prediction
1118.28|4.8| length, we are generating text of size 100. We are just running
1123.08|3.12| it as before. So again, there's nothing special, it's just
1126.2|2.92| running the model, similar to how we run it in the training
1129.12|8.0| loop. The new part now, though, is this part. So here could have
1137.12|2.8| also actually written it simpler like this, this is just a
1139.92|4.58| division. So we're dividing by a temperature. So what is the
1144.5|5.14| temperature? So first of all, outputs are our logits. So if
1149.64|4.04| we go back to our model here, these are just here, we don't
1153.68|2.44| use any softmax, because the softmax is usually used in a
1156.12|8.0| cross entropy function. So here, we have just our logits. And
1164.12|2.84| then we compute, I mean, we're not really computing the softmax
1166.96|3.26| as a normalization factor in the softmax, right? So we are usually
1170.22|4.3| normalizing by the sum of all of these for each class. Here, we
1174.56|4.96| are lazy, we don't do that, we just take e to the power of so
1179.6|5.68| essentially, it's e to the power of logits divided by the
1185.28|9.76| temperature. And the higher the temperature is, so maybe the
1195.04|2.28| other way around, if I have logits, and I have a small
1197.32|2.72| number, like the temperature is usually a value between zero.
1201.36|3.88| And one, and I should say, why, what's the temperature here,
1205.24|4.62| this like, I think it's inspired by energy based models, but
1209.88|3.36| which is in turn, in turn inspired by the Boltzmann
1213.24|6.2| distribution. But it's essentially how sharp our
1219.44|4.28| distribution is in this case. So if we have a small value here,
1223.88|5.4| like point one, all the values will become larger. Yes, we will
1229.28|6.2| get larger values. If we have a value 1.1, 1.0, they will be
1235.48|7.8| on softer. So we have here, there's a real main interesting
1243.28|4.2| part, we will here have this multinomial function, which is
1247.48|3.26| essentially a function on that randomly samples from a
1250.76|4.72| multinomial distribution. Using these, you can think of them as
1255.48|6.68| weights, or probabilities. And this is our the number of
1262.16|8.48| samples we draw. So here, we're drawing one, one character from
1270.64|4.8| the predictions. So outputs will be the logits for all 100
1275.44|7.6| characters, because we have 100 different characters. So logits
1283.04|5.88| will be all values. If we have softmax, these would be all the
1288.92|4.72| probabilities corresponding, corresponding to these
1293.64|6.56| characters. And here we are randomly sampling. So if we, so
1300.2|4.4| we expect expectation would be sampling, the character also, we
1304.6|3.24| would most often sample the character corresponding to the
1307.84|7.08| highest probability. And we can soften this by having a 1.0.
1314.92|2.84| This is the standard setting temperature of 1.0 is if we use
1317.76|3.76| no temperature, this would be our regular values. But if we
1321.52|4.4| use a smaller value, let's say 0.1, this will be a sharper
1325.92|4.8| distribution. So the most character with the highest value
1330.92|4.14| will be sampled more often. So even more often, so we can
1335.06|4.46| actually set the temperature very, very small. And then it
1339.52|3.92| will essentially be like not sampling at all, it will always
1343.8|3.6| sample the character with the highest probability. And that
1347.4|4.44| way, it's more like deterministic. So you can think
1351.84|3.64| of it like that, the higher the temperature, the more diversity
1355.48|3.92| in the output in the generated text you will get. So if you
1359.4|2.88| want to have more diverse text, you you can lower the
1362.28|3.36| temperature, it's it's kind of, you can increase the temperature
1365.64|3.36| if you want to have no randomness, you lower the
1369.0|2.62| temperature, higher temperature means more diversity, you can
1371.62|3.3| think of it also as it's kind of like heat in a biological system
1374.92|3.84| where you if you heat up the system, you have more kinetic
1378.76|4.12| energy, everything is more like wiggling around and things like
1382.88|4.72| that. So here we have like point eight, it's like a trade off,
1387.6|4.92| but it's a hyper parameter. If you have higher temperature,
1392.54|4.48| there will be more mistakes, but also more diverse text, it's
1397.02|6.46| like a trade off. Okay, can play around with that if you like,
1403.48|2.84| when you do the training, but let's just use the ones that I
1406.6|3.72| used to begin with. So it's running now, it gets a pretty
1410.32|3.2| high loss. And this is the initial text, notice that it
1413.52|4.84| starts with a th, but the rest is like, Ghibli Gok, there's
1418.36|4.96| nothing reasonable in here is just some arbitrary text. But
1423.32|2.16| yeah, it already finished the next iteration. Let's take a
1425.48|4.52| look at that. Still, not anything useful, you can see it
1430.0|3.96| learned something, right? So you can see, okay, these isn't an
1433.96|4.12| actual work here. So it's learning something. Let's take
1438.08|6.68| a look at the next one. Okay, we have some real words here. Kind
1444.76|10.12| of learning something. Now, you can see students. So again, this
1454.88|7.32| is trained on the covert FAQ, which smote mostly readable text.
1463.76|5.36| Okay, so it's getting, it's getting a little bit better. I
1469.12|2.84| mean, of course, this is like not real text, it's not a very
1471.96|4.32| sophisticated RNN, it's just one layer, very simple, very small
1476.28|3.32| text. Also, I mean, it just learned for one minute, right.
1479.6|6.4| Right. So but you can see that it actually seems to learn
1486.0|4.16| something, if you think about it started from this, had then went
1490.16|7.36| to this. And now it's kind of talking about a safer badger,
1498.08|4.4| badgers app notification system. So it's it's kind of learning
1502.48|6.64| things, right? Wisconsin COVID-19 testing. Yeah, we'll
1509.12|3.84| have to run way longer to get some sensible inputs. Again,
1513.08|2.8| there are also many hyper parameters to tune can have more
1515.88|4.4| layers, you can change the temperature and these types of
1520.28|4.44| things to get better results. But I think I feel like I mean,
1524.76|4.12| given that I'm on the CPU, just running it for two minutes, it's
1529.0|5.76| quite cool that it can, yeah, can create text that is not
1534.76|3.24| total nonsense. I mean, it's total nonsense, to be honest,
1538.0|3.72| but we can identify individual words. So that's actually quite
1541.72|3.8| cool. Okay, so let me let me stop it right here was a long
1545.52|5.84| video. And in the next video, we will take the next step talking
1551.36|3.92| about how we can outfit RNNs with the so called attention
1555.28|13.8| mechanism.