start_time|end_time|text
0.52|3.48| Yeah, hi, everyone. Now that we have finally finished the
4.0|3.4| recurrent neural network lecture, we can now finally
7.4|4.12| focus on the generative modeling part of this course. So we will
11.52|4.04| start simple with an auto encoder. So an auto encoder is
15.72|4.92| essentially an architecture that allows us to encode data into a
20.66|4.22| smaller representational representation. And also one
24.88|2.72| concept of this is to reconstruct this into the
27.6|4.44| original dimensional space. I would say by itself, it's maybe
32.04|3.36| not super useful to have an auto encoder. But this is like a
35.4|3.84| great introduction to follow up topics that we'll be talking
39.24|5.16| later on about, for instance, a variational auto encoder, which
44.4|4.48| allows us to sample data from a distribution. And we will also
48.88|3.28| talk about generative adversarial network, which is
52.16|2.68| also essentially somewhat related to the auto encoder
54.84|3.28| here. So in the context of the auto encoder, we will also
58.12|4.04| encounter topics like on deconvolutions and so forth,
62.28|3.44| which will be of course, then also useful later on when we
65.72|3.56| talk about generative adversarial networks. So with
69.28|3.8| that, yeah, let's not spend too much time on this introduction
73.08|3.4| here, I will now give you the list of topics for this lecture.
76.52|4.04| And then let's just dive in and see what an auto encoder is.
80.56|5.08| All right, let's start by having some motivating examples of why
85.84|3.36| auto encoders are interesting. Of course, in the grand scheme of
89.2|3.88| things, auto encoders will be our entry point to generative
93.08|3.84| models, but also auto encoders themselves can be used for
96.92|3.32| interesting applications. So for instance, here, this is an auto
100.24|4.76| encoder, so called denoising auto encoder that cleans up
105.0|5.8| speech. So it's hard to, of course, show speech on a slide
110.8|3.88| because it's an audio thing, not a visual thing. But here's a
114.68|3.76| spectrogram of noisy speech. And the researchers used auto
118.44|3.92| encoders to convert that into cleaner or clearer speech.
123.56|3.6| Another interesting application of a denoising auto encoder is
127.56|3.84| image enhancement. So for instance, imagine you have these
131.4|3.6| noisy images here, medical images, and the researchers
135.0|4.32| here use an auto encoder to recover these images from these
139.32|3.72| noisy images. And for reference, the original images here are
143.04|3.32| shown on the top. Of course, when you go from here to here,
146.68|4.76| there's a lot of detail lost. But still, it's impressive that
151.72|3.32| if you have an image like this, that you can recover some
155.04|5.2| details despite this noise here. Or here's an application of an
160.24|4.56| auto encoder. I worked on a couple of years ago. So we had
164.84|4.6| convolution auto encoder here that we implemented for privacy
169.44|6.24| enhancements. So here, we had the goal to, let's say, remove
175.72|4.32| gender information, while retaining the matching accuracy
180.56|3.76| of face measures. So face measures are often used, for
184.32|4.04| instance, for security purposes, like passports, scanners, and so
188.36|3.96| forth. And nowadays, yeah, we have security cameras everywhere
192.32|4.28| at keeping track of lots of things. And so the idea was, how
196.6|3.4| can you minimize the data collection, for instance, you
200.0|3.24| still want the images to be useful for verification
203.24|4.6| purposes, for instance, checking whether someone shouldn't be
207.84|2.36| here, let's say, checking something against the criminal
210.2|4.6| database, but not, let's say, in general, collecting information
214.8|4.2| that wasn't supposed to be collected, whether person didn't
219.0|3.68| had didn't give consent to, for instance, gender information, in
222.68|3.88| any case. So these were just some applications of auto
226.56|5.16| encoders. So here in this lecture, the topics are those
231.72|3.6| five topics here, it will be hopefully not a very long
235.32|2.88| lecture, because your auto encoders themselves are very
238.2|4.12| interesting. But we will talk more about auto encoders to in
242.32|2.84| the next lecture when we talk about variational auto encoders.
245.2|3.28| So this is here the big picture introduction, where we will
248.48|3.44| first talk a little bit about dimensionality reduction, then
251.92|3.12| I will introduce fully connected auto encoders. These are
255.04|2.96| essentially auto encoders, similar to multi layer
258.0|4.12| perceptrons, where we have fully connected layers, then we will
262.12|3.2| extend this concept to convolutional auto encoders,
265.32|4.72| which work better with images, then I will show you how we can
270.04|3.4| implement a convolutional auto encoder in pytorch. And lastly,
273.44|3.6| I will also highlight some other types of auto encoders, one
277.04|3.08| would be the variational auto encoder, which will be
280.12|20.6| revisiting in the next lecture, then