start_time|end_time|text
0.4|4.08| Alright, so this is going to be the last video in this lecture
4.48|4.4| on recurrent neural networks. So we are now talking about
8.92|5.06| implementing an RNR classifier RNN classifier in pytorch. So
13.98|3.46| the many to one word RNN that we just talked about in the
17.44|3.64| previous video. So it will be essentially this whole process
21.08|4.56| from going from a text to building a vocabulary, then this
25.64|4.32| integer representation and then using an embedding to get this
29.96|4.62| input to the RNN, which will be when you recall be this one many
34.58|3.14| to one RNN where we have one sentence as an input and one
37.72|4.9| class label as the output. So I have actually two codes here.
42.62|4.26| One is an LSTM and one is a packed LSTM. The packed LSTM is
46.88|2.8| just a more implement a more efficient implementation. So
49.68|8.0| let's just talk about me. I just let's talk about the regular
57.68|4.84| LSTM first the regular approach. So it took a couple of minutes
62.52|3.32| to run this. I'm not gonna rerun this we are just taking a look
65.84|3.16| at the results and I will upload this to GitHub if you want to
69.0|4.88| play around with that. So we are going to use torch or pytorch
73.88|4.64| and torch text. So in particular, any version of torch
78.64|5.48| text that is point nine or higher. Also notice, I don't have
84.12|3.32| any helper files here because this is like a tricky
87.44|3.24| concept to explain. I wanted to keep everything in this notebook
90.68|2.88| to make it a little bit more easy to explain by walking you
93.56|3.6| through this instead of visiting different files. But yeah, you
97.2|3.48| could technically also use these helper files when code becomes
100.68|3.44| larger. So here, the training function will be very simple. I
104.12|4.24| don't have any fancy training function this time, just to keep
108.36|3.32| things simple, because I think an RNN is already complicated
111.68|3.48| enough. So compared to a convolution network, these RNNs
115.16|2.68| are actually really tricky to implement, at least in my
117.84|3.72| opinion, I actually very much prefer working with convolution
121.56|8.38| networks. So here are some general settings. So we are
129.94|5.18| going to use the vocabulary size kept at 20,000. The learning
135.12|2.44| rate, batch size, number of epochs, this is something
137.6|3.06| familiar to you. The embedding dimension that we will use is
140.66|4.58| one or 28. The hidden dimension will be 256. This is like on
145.88|9.48| after that. And then the number of classes is two. So first,
155.36|3.48| we're going to download the data set the IMDb movie review
158.84|6.4| data set. So here, in this, in this part, we are downloading it
165.24|4.88| from my book, because yeah, just for simplicity, because this
170.12|3.64| will save us some pre processing steps, there is actually an IMDb
173.76|5.08| data set implemented in torch text. But here, I'm also
179.4|4.04| explaining to you how you can use an LSTM on your own data
183.44|3.64| set. So it's basically two steps in one. And we're using this
187.08|3.4| because it's in CSV format that is already I would say easy to
190.48|3.0| use. So we can skip all the pre processing steps of this
193.48|4.28| particular data set so that we can more focus on how torch text
197.76|5.08| works. So this is just downloading it from this GitHub
202.84|5.84| repository. Then this is unzipping it. And then this is
208.92|5.22| loading it into a pandas data frame, because it's just a bit
214.14|5.06| simpler than using anything else. So this is a CSV file. So
219.2|4.08| we are using pandas to take a look at it. So it has, I think,
223.44|4.2| 50,000 entries. So yeah, these are the first five, the review
227.64|3.4| is the text, the input text, and the sentiment is the class
231.04|6.68| level. It's kind of too personal to me, a common gotcha to have
237.72|4.16| the wrong names later in the code. So here, I'm using
242.16|3.12| something called a text column name and label column name as
245.28|5.8| the name for these, because you will see that later, you have to
251.08|4.4| provide kind of like an attribute access to these
255.48|3.24| features in the training loop and the same for the labels. So
259.8|4.28| depending on the names of your columns in the pandas data frame,
264.08|3.2| your training loop might look different, you have to rewrite
267.28|4.0| it. And I find this very tedious. So I would give my
271.28|2.64| pandas data frame if I have worked different data sets,
273.92|3.84| always these names just to keep it simple. It could be something
277.76|6.36| else, but I find it also capital letters useful. So it reminds me
284.12|2.88| of what this means or what this is, it's just easier to see it
287.04|4.4| just screams out, okay, this is a column name here. And this is
291.44|4.36| important. Alright, so I'm just giving it the generic name, text
295.8|3.0| column name and the generic name, label column name here.
300.44|3.4| Alright, and then I'm deleting this again. So here was just
303.88|5.64| essentially loading it, renaming it and saving it again. And then
310.08|2.96| here, this is just for taking a look at it again, that it looks
313.04|2.76| okay. And then I'm deleting it because I'm not using it here
315.8|5.04| anymore. Then we are going now to prepare this data set with
320.84|4.68| touch text as input to the RNN. For that, we are going to use a
325.52|4.12| library that is called spacey, spacey is a very popular natural
329.64|4.08| language processing library for Python, Python. And in
333.72|3.8| particular, we are using the tokenizer. So by default, it
337.52|4.88| would use tokenizer splitting on white spaces. But I heard from
342.4|3.28| people working with real world data sets that sometimes these
345.68|4.76| are not very robust to let's say weird characters. So also HTML
350.44|3.28| characters and things like that. And this tokenizer also gets rid
353.72|5.16| of certain formatting things you find in HTML, like these on these
358.88|3.2| symbols here and so forth. So it's like a little bit more
362.08|3.0| sophisticated than just splitting on white space. So
365.08|4.92| what this is doing is it's splitting a text into white
370.0|5.08| space so that one token is one word. And we are using here this
376.32|4.08| English language, it's, I think it stands for English core web
380.44|2.88| and something. And this is not for something. I'm just saying
383.32|2.4| something, I forgot what this means. But this is essentially a
385.72|4.36| library or not a library on dictionary for English words and
390.08|4.72| web things encountered on websites and stuff like that. So
394.8|3.24| this is usually useful if you just work with a data set like
398.04|5.52| scrape from somewhere on the internet. If you are just
403.56|2.84| running this, it may be that you encounter will encounter an
406.4|4.28| error. So you have to run this one first, which will you have
410.68|4.12| to run this on a command line, this will download this. Yeah,
414.8|4.16| dictionary here. And yet to install space here, I recommend
418.96|5.48| conda, but you can also use pip pip install. Now, like I said
424.44|3.88| before, in the previous video, things have changed in touch
428.32|2.88| text. So we are going to use the old way called torch, torch,
431.2|3.88| text legacy. But if you want to convert this to the new one, I
435.08|3.12| actually spent a lot of time yesterday, and then it was not
438.2|4.92| working very well. So I use the old way again. But if you're
443.12|4.92| interested here, there's a tutorial for migration on the
448.04|3.76| slides. So to migrate to the newer way that it doesn't use
451.8|6.04| this legacy thing. Alright, so we are now defining a field for
457.84|3.56| the text. So this will be our features our tokens. So this
461.44|6.12| this will be so if we have, for instance, on oops, if we have
467.6|5.2| this text here, this will be something like a list containing
472.8|4.92| of containing these consisting of these words split by
478.4|2.84| approximately something like the white space, but a bit fancier
481.24|2.62| than that. But each entry in the list will be one word
483.86|7.22| essentially, using this tokenizer. Alright, the second
491.08|6.2| one is the label. So this is for designating this label, which
497.28|6.68| will be our integer long, long is just a 64 bit integer. Here,
504.0|6.36| we are providing these fields. And this is so we are providing
510.36|2.68| these fields, which are the text that we have defined here and
513.04|3.2| the label that we have defined here. And we're using this
516.24|3.84| tabular data set, which will read our CSV file, and then
520.08|6.0| parsing out these things. So that we will can then load them
526.44|3.96| as a data loader. So here, this is why it's so here, this is
530.4|4.72| important, this name has to be the name that is actually here.
535.32|3.64| And personally, it's, that is where I always make mistakes. So
538.96|3.4| I let's say don't rename it, if I don't rename it, I would have
542.36|8.68| to put in like, oops, I would have to put in review here. And
551.04|3.24| then sentiment here. And then later, I have to also use these
554.28|3.2| words. And if I have a predefined training loop, I
557.48|2.92| would have to rewrite certain things depending on what data
560.4|2.8| set I use. This is why at the beginning, I renamed the column
563.2|3.88| so I can always leave it like it is right here. Now, the only
567.08|4.2| thing I have to change is, of course, the path to my data set.
573.0|2.76| Alright, and in this case, it doesn't have a header. So you
575.76|5.52| also have to check in this case, there is no header row, there
581.28|2.36| are only the column names, but there's no no particular header
583.64|3.44| row. Oh, wait, sorry, there is no skip header, there's no
587.08|4.32| header, it's skipping the header. Okay. So it's skipping,
591.44|2.92| skipping these, sorry, what I meant is, it has a header, it
594.36|5.86| has these column names, and it's skipping those. Okay, so this is
600.22|7.78| now the way we process our CSV file into a data set. Next, we
608.0|4.24| want to have a training and a test data set. So I'm using this
612.28|4.8| split function, I'm splitting this data set into two training
617.08|3.32| and a test data set. Actually, I tried to split it into three
620.4|3.04| directly, it should technically support that. So I had something
623.44|6.52| like point 7.1 and point two. But it gave me some very weird
629.96|4.68| results. I think it's a bug. So because what happened was, I had
634.72|6.8| a validation set like this. train data validation data, test
641.52|3.7| data. For some reason, I don't know why the validation data was
645.24|3.72| much bigger than a test data, which should be the opposite.
648.96|3.74| And I tried many things, it seems to be a bug. So I do it
652.7|6.22| in two steps. First step is I'm splitting the training data or
658.92|4.72| the data center training data, 80% and 20% test data. So I'm
663.64|3.92| double checking here. So the data set consists of 50,000 data
667.56|4.56| points, 40,000 will be for training, 10,000 will be for
672.12|4.56| testing. And then I split the training data further into a
676.68|4.6| training data set again, and validation data. So in total,
681.28|6.96| what I will have is 34,000 training examples, 6000
688.26|7.5| validation examples, and 10,000 test examples. Just to make sure
695.76|3.8| everything looks okay, we are now taking a look at the first
699.6|3.12| training example. So zero index zero is the first training
702.72|6.44| example. And this is how it looks like. So text column name,
709.16|4.12| that is the tokenized. So this is using the tokenizer. This is
713.28|4.68| the tokenized review text can see it keeps punctuation, it
717.96|4.6| keeps numbers. So for some unknown reason, comma, seven
722.6|4.08| years ago, comma, I watched blah, blah, blah. So you can see,
727.48|3.08| yeah, this is not the tokenized text. This is from using the
730.56|6.88| spacey tokenizer. And also, there's the name here. This is
737.44|5.76| like the this should be the class label. Actually not sure
743.2|4.52| why this is not an integer later actually doesn't cause any
747.72|3.76| problem. So it seems to be okay. But I feel like this should be
751.48|5.24| without quotation marks. But anyways, all right, so now we
756.72|3.76| have the data sets, the training data validation center data and
760.48|3.84| the test data. What we're now doing is we are building the
764.32|6.48| vocabulary. So here, build vocab, I'm setting a maximum
770.8|3.72| size for the vocabulary because yet to prevent overfitting. So
774.52|7.64| we are only using the most used words, the 20,000 most frequent
782.16|3.36| words. So I defined a vocabulary size here somewhere at the at
785.52|5.32| the top can play around with that can use 10,000 25,000 30,000
790.84|4.36| depends a little bit on how big the training set is, and how
795.6|4.48| how diverse the data points are, the texts are how long the
800.08|4.72| texts are, but 20,000 is a good number to start with. So we are
804.8|7.36| building this now. And for some reason, it's also called build
812.16|6.04| vocab here, I think I'm doing it right. So vocabulary size, what
818.2|5.16| we will find is it's 20,000 and two, not 20,000. And this is
823.36|4.84| because we have the unknown word token. So if we encounter an
828.24|2.56| unknown word that it will not crash, and then also the ones
830.8|5.4| for padding, and we have two classes zero and one. Here, I'm
836.2|3.36| now showing the just to look at whether it makes sense. Actually,
839.56|4.72| I can see there's something that I feel like shouldn't be there
844.28|4.2| is this this break character here. I thought to be honest,
848.48|3.2| the spacey tokenizer would be a bit more robust, that it would
851.8|5.48| not have these types of things, but oh, well, happens. Spray not
857.28|5.84| perfect. So here, we are looking at the 20 most frequently
863.12|5.88| encountered words or tokens. So the very frequent commerce
869.0|5.84| frequent point punctuation, and so forth. But yeah, this kind of
874.84|3.44| bothers me, this shouldn't be here. So we would, in a real
878.28|2.4| world application, probably have to deal with that using a
880.68|3.92| different tokenizer, or maybe just stripping it out before we
884.6|4.32| pass it to the tokenizer or something like that. All right,
888.96|5.36| next tokens corresponding to the first 10 indices, just to look at
894.32|3.36| those. So we have our vocabulary that is of size 20,000. So if I
897.68|8.64| go back to my on my slides, so we have this vocabulary. And we
906.32|4.48| are now looking 12345, the different integers, the strings
910.8|4.36| correspond to. So the first entry in my vocabulary is this
915.16|3.96| unknown one. Second one is the padding, and then the comma
919.12|7.28| point, and a O F, and so forth. And just for just making sure
926.4|3.04| things work, technically, so we will use that data for making
929.44|3.48| predictions. But laterally, generally, we can also just take
932.92|6.16| this vocabulary for the text field and convert any word into
939.08|4.32| this integer corresponding to the dictionary. So the according
943.4|4.28| to this vocabulary, the word the is at index position two, so
947.68|5.64| 012. So here, we're putting it in and get the number two. So
953.32|2.88| this is all we are here currently, this is not necessary.
956.2|2.64| We are just investigating what's going on just to make sure
959.04|4.04| things look okay. Oh, yeah, I see. So yeah, we have now this
963.76|1.96| class level vocabulary. And I mentioned earlier, there
965.72|4.56| shouldn't be strings. I mean, this is probably because, yeah,
970.28|5.76| we could have here, we could have put the word pause on neck
976.12|4.44| for positive or negative. This is what's original in the movie
980.56|5.0| review database. So here, I in my book, I converted it to one
985.56|10.2| and zero already. And the code thinks these are strings. Kind
995.76|4.56| of funny. So it's mapping one to zero, and zero to one. So we
1000.32|2.84| would have to keep that in mind when we later do the prediction.
1004.44|3.44| So we could have just used words like a pause and negative and
1007.88|4.8| stuff like that. We could also, yeah, we could also change that
1012.68|3.36| if we wanted to. It's just, um, here, it's just, I think,
1016.04|1.84| alphabetical order or something like that.
1020.16|3.68| It can't be alphabetical. I think it's just what it has
1023.84|3.4| encountered first or something, or maybe it's even random, just
1027.24|4.64| have to remember that the string one in our label column
1031.88|6.12| corresponds to the class label zero in the tensor later. Then
1038.0|5.12| here is our frequency count of the vocabulary, sorry, of the
1043.36|4.56| training data points. So we have approximately 60,000
1047.96|4.44| corresponding to zero. And this one is actually negative zeros
1052.4|7.24| negative, and one is positive and 70,000 positive ones. On one
1059.64|6.76| more thing I wanted to say is that's here, I'm building the
1066.4|4.4| vocabulary only on the training data, not on the whole data set.
1071.04|5.44| Because as usual, we pretend that the validation and test
1076.52|4.36| data are unseen that there are new data sets. That's what we
1080.88|4.24| use for evaluating our model. During training, we pretend we
1085.12|3.24| don't know these, it's like independent data. So we are only
1088.36|3.78| building the vocabulary based on the known data, the training
1092.14|5.94| data. All right, so you can see, it's really complicated to
1098.28|2.4| implement an RNN and lots of steps involved. It's way more
1100.68|3.36| complicated than a convolutional network. So if you don't really
1104.44|3.8| understand everything, the first time, it's totally normal. It's
1108.24|4.04| just it's very complicated. People study this for many
1112.28|3.24| months to before they become comfortable using those things.
1115.52|3.28| Now we are implementing the training validation and test
1118.8|2.88| loader, we use something called a bucket iterator, which is a
1121.68|6.44| special iterator in pytorch, torch text, which will group the
1128.12|4.56| batches such that the sentences have similar length, and that
1132.68|10.76| reduces the number of padding that is required. Okay, here,
1143.44|3.44| now we are testing whether those work, actually, these data
1146.88|3.48| loaders, and you can see what I'm just doing is I'm like
1150.36|2.8| before in my other code examples, I'm just doing for
1153.16|4.04| batch and train loader, and then I print these, and then I do a
1157.2|3.16| break. So it only shows the first batch, I just want to see
1160.36|4.52| if it runs okay. So you can see for the first batch, it's
1164.88|4.56| actually pretty large, I should say, the first value here is the
1169.44|5.4| sentence length. And the second one is the batch size. So this
1174.84|3.12| is a little bit different from the conversion networks, where
1177.96|4.72| we had the batch size first. This is what makes I feel like
1182.96|2.52| everything also a bit complicated to understand it's
1185.48|6.04| like that the sentence length here is first. And the sentence
1191.52|7.76| length is these integers here, these here. So I have a better
1199.28|4.96| one here. Yeah, this, this is basically the sentence. Well,
1204.24|8.04| this is for one word, sorry. I don't have a good one here in
1212.28|4.8| the lecture notes. But so if you concatenate these together,
1217.08|5.0| this would be on the sentence length. And then this is the
1222.12|20.52| batch size. I think, yeah. All right. So now the RNN here. So
1242.64|10.12| the RNN, okay, sorry, let's just have to make this a bit bigger
1252.76|4.64| here. So the RNN looks like as follows, we're actually using an
1257.4|5.24| LSTM. So there are several things now we are using this
1262.68|7.0| embedding that provides the input to the LSTM, then the LSTM
1269.68|6.04| itself, and then the output layer, hidden layer, sorry, the
1275.72|5.48| output layer, it's not a hidden layer. This you can think of, of
1281.2|8.56| the LSTM, you can think of as the hidden layer. Whereas, you
1289.76|3.28| know, the embedding comes before that it's like preparing the
1293.04|6.92| input for the hidden layer. Actually, in the slides, I said,
1300.28|3.16| it's this one, but then there would be another matrix. So
1303.44|2.64| it's technically a little bit confusing, I should have
1306.52|7.0| actually not done that I should have showed you it as a
1313.6|3.6| embedding that comes before that it prepares these access. And
1317.2|7.0| this this W technically belongs to the RNN hidden layer. If we
1324.2|5.28| would implement this one here. And the LSTM has a more
1329.48|3.56| complicated setup, as you recall from last time, so it has all
1333.04|2.16| these different types of hidden layers here.
1335.2|16.68| Okay. Now, what we have here is the embedding that converts the
1351.88|4.04| word into the real value vector. If I go back to my slides,
1355.92|4.28| again, this is giving us this matrix here. So this goes from
1360.2|6.56| text to this integer vector to these embeddings. And then the
1366.76|2.96| LSTM takes in this embeddings and produces the hidden
1369.72|3.4| activations. And then this is just like a classification
1373.12|3.2| layer, like in a multi layer perceptron or the last layer of
1376.32|4.08| a convolution layer, this goes from the hidden dimension to the
1380.4|5.72| class labels, or put them as the number of class labels. Now,
1386.12|4.84| these are defined here, we can't use easily a sequential like we
1390.96|3.2| did before, because there's a little bit, the output looks a
1394.16|4.72| little bit different. So I'm also maybe I should say, you can
1398.88|2.88| technically use an RNN instead of the LSTM, but you will find
1401.76|4.04| the performance is relatively poor. So you probably want to
1405.8|2.76| use an STM. But if you want to do some experiments, you can
1408.56|3.84| actually use the RNN instead of the LSTM. The LSTM is
1412.4|4.48| essentially on what I showed you before in the last two videos
1416.88|7.28| ago, the STM hidden layer. Okay, the forward pass gets a text. So
1424.16|8.2| this gets really the text, this goes through the embedding. And
1432.36|4.88| then the embedding is the input to the LSTM. So I call it RNN
1437.24|6.96| RNN, but the LSTM, and it outputs the output, the hidden
1444.4|8.08| and the cell state. So just looking for a good slide here.
1452.88|9.68| So we have this many to one here. And the should focus on
1462.56|4.96| many, one too many, or many too many. Okay, so let's, let's
1467.6|3.6| consider this many too many here, when I call the LSTM, it
1471.2|4.48| will output. So the orange one, you can think of as the LSTM,
1475.92|3.6| it will output something that goes to the output thing had a
1479.52|5.28| better slide somewhere here. Yeah, here. So it will output
1484.8|5.16| this y. And it will output the hidden state for the next hidden
1489.96|8.12| layer. So this is the output is the y. This is the y hidden is
1498.08|4.36| what goes here in this arrow, what goes to the next one. And
1502.48|5.76| cell state is specific to the LSTM. That's this LSTM state.
1508.24|15.76| Okay, so we scroll here. So we have cell state that is output
1524.0|5.4| here, right? So this one here, then we have this is the y here
1529.48|2.16| to next layer where it says to next layer, this would be the
1531.64|8.2| y, this would be the output. And HT, this would be the hidden
1541.72|5.84| and sell, this would be the CT. It is complicated. So if it
1547.56|5.08| doesn't make sense immediately, it is a complicated concept. So
1552.68|5.0| since we have, let me find a better representation here again.
1557.68|7.24| Since we have many to one, we are not going to use these
1564.92|3.16| years. So we are not going to use this one and this one. So
1570.32|3.0| this one, we are not going to use this one is not we are not
1573.32|5.12| going to use. And this one is kind of also included in this
1578.44|4.36| output. So to make things simpler, we are going to use
1582.8|8.72| actually me run arrow. So what we are going to use here is we
1591.52|2.52| are going to use the hidden output from the last one, which
1594.04|7.92| is this hidden here. And then we will provide our own hidden
1601.96|5.88| layer, our own output here, instead of using this green one,
1607.84|6.76| we will have our own fully connected here for connected
1614.6|4.08| there. This is what we're doing here. So we are computing our
1618.68|4.44| own output, we are removing this, it's, let's say too
1623.12|4.28| complicated, we don't want to use all all these green ones, we
1627.4|5.84| are going to only use the hidden one, which is the output of this
1633.24|3.44| orange here of the last orange, and then have our own fully
1636.68|2.84| connected layer to get this output here. This is what's
1639.52|7.56| going on here. All right, I hope this makes somewhat sense. So
1648.0|5.44| if we look at the sizes, we go from sentence length to batch
1653.44|2.76| size, this is like what we had before, sentence length and
1656.2|5.64| batch size, the matrix of our input, then this goes into the
1661.84|3.08| embedding layer, which produces a sentence length, batch size,
1664.92|2.84| embedding dimension, this is our, I don't know why it is
1667.76|4.88| arranged like that. But this is our let me delete this. So we
1673.0|9.12| don't save it later when I export it for you. Yeah. So
1682.12|4.76| this will be the this is the embedding. This is the embedding
1686.88|4.32| matrix. This is the embedding for one training example. We
1691.2|3.6| have some we have multiple because I have a batch size and
1695.08|2.28| the batch size dimensions between the embedding and the
1697.36|2.76| sentence length. So the sentence length, length would be the
1700.12|5.32| rows here. It's also the rows and the columns isn't here not
1705.44|2.36| the embedding dimensions, it's the batch size. So we have
1707.8|3.44| sentence length, batch size and embedding. So you have to think
1711.24|6.04| there would be an additional dimension here. And then this
1717.28|5.24| goes sentence length, batch size, hidden dimension, this is the
1722.52|6.2| dimensionality of our hidden layer. We chose I think 256. And
1728.72|8.2| then we what we output get is only one. So hidden is one,
1737.04|4.16| because it's the last one only the last one dimension is batch
1741.2|2.68| size and hidden dimension. This is usually what would go into
1743.88|5.72| the next hidden layer. And we want to give it to all we like I
1749.6|2.24| said, before we make our own output layer, this is our fully
1751.84|5.48| connected layer, this one. So we are removing here with squeeze,
1757.32|3.6| we are removing this one. So we make this a batch size times
1760.96|3.76| hidden dimension. And this is something you have seen before
1764.72|2.6| all the time when we use the multi layer perceptron and
1767.32|5.56| convolutional network. So squeeze is just we're saying
1772.88|2.72| remove the first dimension, the one here, so that it is
1775.6|5.32| compatible with our linear layer here. Again, this is complicated
1780.92|3.76| stuff. So if that doesn't make sense, you don't have to
1784.68|2.96| memorize any of this, I can totally understand if this is
1787.64|3.84| come complicated. To be honest, I also spent several hours just
1791.48|4.92| implementing this. It's, it's not easy, it's complicated. And
1797.16|4.84| if you really want to work with text, of course, watching this
1802.0|3.52| one lecture gives you just the introduction. It's normal to
1805.52|4.04| spend weeks or months or professional spend years really
1810.32|3.2| doing all these things. There are many, many aspects to
1813.52|2.68| working with text, this is just the introduction. So don't feel
1816.2|3.24| bad. If this looks a little bit complicated to you, it
1819.48|4.36| naturally takes time to work with this. And you have to get
1823.84|2.08| a better grasp of what's going on here.
1825.92|6.12| Okay, but moving on, so we initialize now our recurrent new
1832.04|4.8| network, the input dimension is equal to our vocabulary size,
1836.88|4.56| that's a 20,002. So we use that here in our to create our
1841.44|5.36| embedding matrix. Then the embedding dimension, we had
1846.84|5.08| something like 128. And the hidden dimension is 256. And
1851.92|6.0| the more classes we have to, we set it to two. So if I scroll up
1857.92|5.84| to the top, we set it to two here, hidden dimension 256
1863.76|3.8| embedding 128. We could technically use just one class
1867.56|2.96| and then use our logistic sigmoid instead of softmax
1870.52|2.72| function. And then we could use the binary cross entropy loss
1873.24|3.56| instead of the regular cross entropy loss in pytorch. I did
1876.8|3.76| that at first, but then I was thinking maybe you would like to
1880.56|3.72| use this code here as a template for some other classification
1884.28|3.28| problem that is not a binary one. And then you would have to
1887.56|4.96| rewrite everything. So I implemented that here with two
1892.52|3.44| output nodes, although it's redundant, I implemented it so
1895.96|2.6| that you can adopt it to your own data set. So I thought it's
1898.56|3.16| more useful in this way. So you don't have to rewrite any code
1901.72|2.24| if you want to use that for your project.
1903.96|5.8| All right, so now, let's get so this is initializing the model,
1909.76|4.16| I'm just using Adam. Now let's get to the part where we have
1913.92|2.48| the training. So here's the accuracy function for computing
1916.4|7.52| the accuracy. So yeah, so yeah, we're just computing the
1923.92|6.44| accuracy. And here, that's the training. Interesting. I should
1930.36|3.72| have, yeah, I could have also done it like that. But so to be
1934.08|6.0| clear here, how this works is I have batch index and batch data.
1940.08|3.12| So here, I did a little bit differently. So yeah, I already
1943.2|3.56| enrolled this, it seemed to work. But yeah, so here, batch
1946.76|3.88| index and batch data. So it's the training loop, iterating
1950.64|2.92| over the epochs, setting my model to train mode, and then I
1953.56|2.68| iterating over the data loader. And it gives me two things that
1956.24|4.44| text, which is batch data dot text column name, and labels,
1960.68|3.72| which is batch data dot label column name. This is why I
1964.4|6.0| earlier renamed the columns. Then I'm providing you the
1970.4|3.8| logits. This is the output from the model. So we give the text
1974.2|4.16| to the model, and it will do the embedding for us. And then run
1978.36|5.08| it through the STM. And out come the logits, which is just like
1983.44|2.82| logits, which is just like the logits in a multi layer
1986.26|2.58| perceptron on the convolutional network that we have seen before.
1989.32|4.84| And we have the labels here, the labels or sentiment. And this is
1994.16|2.8| exactly how we've seen that before. There's nothing new
1996.96|4.36| here. And yeah, it trains. Actually, I was training it and
2001.32|2.76| I noticed, okay, it's not really working, right? You can see it
2004.08|3.16| doesn't really work. And I was like really frustrated because I
2007.24|2.76| spent many hours implementing this and then it didn't work.
2010.0|5.44| But then for some reason, it picked up training here. And the
2015.44|3.56| performance got really good. So at the end, I had a test
2019.0|4.12| accuracy of 84%. And also to make sure I should have used the
2023.12|4.84| same dictionary, I don't know why I didn't do that. For the
2027.96|3.2| tokenizer. Anyway, so here is just an example. This I took
2031.16|6.6| actually modified it slightly. This is based on based on this
2037.76|5.04| tutorial here, took it from here. So modified it a little
2042.8|3.24| bit for this code. This is just like an example of the things we
2046.04|3.0| have to do in order to put something into our text if we
2049.04|4.24| have new text. So let's say I have my model, and I have a new
2053.32|3.12| text, like, this is such an awesome movie, I really love it.
2056.96|3.88| And I want to know whether what the probability that this is a
2060.84|4.12| positive review is turns out it's 98% positive, which is what
2064.96|4.88| we would expect. So what did I do here, I put the model in
2069.84|7.44| evaluation mode, I tokenize the text. So yeah, so I'm tokenizing
2077.28|2.64| a text using this LMP tokenizer, I should have maybe used the
2079.92|3.76| same as above this on Web dictionary, but it worked just
2083.68|8.52| fine. Then I'm getting the integer representation, the
2092.2|3.04| length, I don't need here, I need it for my other model. This
2095.24|3.28| is why I think I've just left it in here. Then I'm converting it
2098.52|3.96| to a long tank tensor, and put it onto the GPU. That's where my
2102.48|3.36| model is, if it was on the GPU, otherwise, it will be on the
2105.84|4.96| CPU if devices, CPU, just an optional step if you trained on
2110.8|7.52| the GPU. Um, yes, is the index tensor. And this index tensor
2118.32|3.96| will go to the embedding. So the embedding will not do the text
2122.28|5.64| into embedding, it will be two steps. So we have to prepare the
2127.92|7.0| indices. Okay. Yeah, and then that's the softmax, because we
2134.92|4.64| don't have any softmax in our model ourselves. And yeah, this
2139.56|3.44| is just this predict sentiment function for putting in
2143.0|5.52| arbitrary text. And here's the same for the computing, the
2148.52|2.76| probability that something is negative, it's just my one minus
2151.28|3.48| this, right. So here, I really hate this movie. It is a really
2154.76|4.2| bad movie and sucks. And you can see, model also detects that
2158.96|3.96| this is indeed a negative one. Alright, so this is how it
2162.96|5.32| essentially works. So this is the LSTM, the regular LSTM, it's
2168.28|3.56| pretty complicated, as you have seen, you can actually make a
2171.84|3.44| more complicated using this packed approach. So if you're
2175.28|4.48| interested in that, there's a very good explanation here. So
2179.8|6.28| essentially, it's about ordering the sentences and the batches to
2186.08|3.84| minimize the number of computations, because we have to
2189.92|3.68| do a padding, right. And if you just shuffle your data set, there
2193.6|5.12| will be randomly long and short sentences together. But it is
2198.72|3.44| inefficient, because for some batches, you have to pad a lot,
2202.2|3.72| just because there are one or two long sentences. So this
2205.92|2.88| packed approach, what we will do is it will look at the whole
2208.8|4.28| training set, and organize it such that it minimizes the
2213.08|5.8| number of padding required. So there are a few changes that you
2218.88|7.08| have to make for that. So I highlighted them here. So you
2225.96|4.68| have to include the length in the tokenizer, and so forth. So
2230.64|6.6| some changes. I don't think here were this sorting within the
2237.24|8.6| batches also required. Yeah, and then here, that was what take
2245.84|6.76| took me a long time to figure out, you have to use this RNN
2252.6|5.24| dot pack dot padded sequences, and then provide also the text
2257.84|4.44| length took me literally hours to figure that out. was kind of
2262.28|5.8| frustrating. But anyways, okay, so and then I had to modify this
2268.08|4.6| a little bit in the accuracy function. In any case, long
2272.68|4.0| story short, it's trained, it trained actually very well. I
2276.68|3.2| didn't expect it to train that well. I'm not sure if there's a
2279.88|4.0| bug, but it's trained so good, actually, or so well, that it
2283.88|5.28| got 99% test accuracy. So essentially, this should be just
2289.16|5.08| the same as this one, but more efficient because it puts or
2294.24|4.88| organizes it so that we minimize the padding. And it is also
2299.12|3.32| faster. Because of that, you can see if I go here, for one
2302.44|8.0| epoch, it takes only point three, three minutes, whereas here, it
2310.44|5.32| takes almost more than two times as much. And yeah, you can see
2315.76|5.16| it gets 99% test accuracy. I took a look at this, I can't
2320.92|4.64| find any mistake or bug. I think it's just a great model here
2325.56|2.6| that trains well, it could be that there's a bug somewhere.
2328.16|4.68| Because this is a little bit suspiciously good. But yeah,
2332.88|4.76| well, I take it 99% doesn't sound too bad. So yeah, so here
2337.64|4.24| you have two templates. And based on what I've seen,
2341.88|2.96| actually, I think this one looked really good. So here you
2344.84|2.76| will have some additional resources, if you are really
2347.6|3.4| interested in working with text. But again, this is a very
2351.0|5.0| complicated topic. And I don't blame you if this looks all
2356.0|3.84| complicated to you. So you are just learning about it probably
2359.84|3.96| for the first time. People who work with natural language
2363.8|4.44| processing spend many, many days, weeks, months, learning
2368.24|2.96| these types of things. So here, I gave you the overview, I hope
2371.2|4.96| it's, it's useful. Next lecture, we will now then finally get to
2376.16|3.44| the generative modeling part. So now I gave you the introduction
2379.6|3.64| to the general machine learning and deep learning concepts. In
2383.24|3.24| the next lecture, we will take a look at deep learning models for
2386.84|2.96| generating new data auto encoders, variational auto
2389.8|4.84| encoders, generative adversarial networks. And if we have time,
2394.64|19.44| maybe also transform us. All right, then see you on Thursday.