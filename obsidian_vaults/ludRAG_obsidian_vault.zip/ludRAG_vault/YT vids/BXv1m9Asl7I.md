start_time|end_time|text
1.72|6.2| Alright, let's now talk about GPT version two. So before we
7.92|4.76| talked about the GPT version one, just to recap, GPT stands
12.68|4.96| for generative pre trained transformer. And these are your
17.64|4.88| models developed by open AI research. And one fundamental
22.52|3.44| aspect about them is that they are unidirectional models
25.96|3.92| trained to predict the next word in a sentence or in a sequence.
30.2|3.08| In contrast to the bird model, which has this bidirectional
33.28|4.76| language modeling approach. So before we talked about GPT
38.04|5.2| version one, which was a model consisting of 110 parameters
43.52|4.0| came out in 2018. Now we are going to talk about the second
47.52|3.88| version, which came out only one year later, it has now 1.5
51.44|2.48| billion parameters, substantially larger, more than
53.92|3.36| 10 times larger. And yeah, we are not going to cover all the
57.28|2.68| nitty gritty details about this model. But if you are
59.96|3.0| interested, here's a link to the original paper if you want to
62.96|4.0| learn more after this video. Okay, so also again, just to
66.96|5.36| recap the GPT version one architecture. So GPT version one
72.36|4.32| there was this transformer decoder with 12 transformer
76.68|7.8| blocks. And this was first pre trained. They had this text
84.48|2.1| prediction where they were predicting the next word in the
86.58|7.62| sequence. And then they had the second step, the fine tuning to
94.2|2.84| the downstream tasks. And here were some examples of
97.04|3.12| classification, entailment, similarity and multiple choice.
100.36|2.84| So the fine tuning happened on labeled data sets, where the
103.2|5.16| pre training was on large unlabeled data sets. Now, why
108.36|4.6| am I recapping this? Because GPT version two made a little or a
112.96|4.32| big change to that procedure. So the key concepts behind GPT
117.32|3.8| version two are, first of all, that it is similar to GPT one in
121.12|3.0| the sense that it's also unidirectional. So the pre
124.12|12.5| training is still next word prediction or next token
136.62|6.22| prediction. However, compared to GPT version one, the version two
142.84|4.12| model is significantly larger. And the argument is the larger
146.96|3.88| the better they had some plots. Also, I will show you that later
150.84|3.96| that they did experiments with smaller and larger models. And
154.8|2.8| they saw the larger the number of parameters, the better the
157.6|4.24| performance. And also, with the data set, the argument was a
161.84|4.08| larger data set will help with the model performance. So the
165.92|3.0| key difference, though, instead of making just things larger is
169.08|2.84| that now they don't do any fine tuning, they use something
171.92|3.88| called zero shot transfer, it's kind of related, I would say
175.8|2.48| somewhat related to zero shot learning, it's not quite the
178.28|4.76| same. So here, it's really about providing some context together
183.04|3.64| with the input to perform the task. I will also show you an
186.68|5.84| example later, how that looks like. But one, one thing to
192.52|2.52| highlight here really is that they got rid of the fine
195.04|5.9| tuning. So the architecture itself, it's overall similar to
200.94|3.42| GPT version one, of course, it's bigger, but it's still based on
204.36|4.2| the original transformer decoder. They did some small
208.56|3.64| rearranging of the layer norm and residual layers. But these
212.2|3.08| are minor implementation details, I would say, they
215.28|3.28| increased also the vocabulary size almost twice the size, but
218.56|4.6| another detail. They doubled the context size, though, I mean,
223.16|5.36| from 512 input tokens now to 1024. So they can capture more
228.52|3.8| context. And I think that's also kind of useful. When you think
232.32|3.08| about the fact, I will show you an example when you have to
235.4|4.74| provide the task together with the input, like the zero shot
240.14|4.04| transfer. So I think that's also why they made the context size
244.18|4.22| bigger. Overall, these changes resulted in a model of
248.64|3.18| consisting of 1.5 billion parameters compared to the
251.82|2.7| original model, which was already large with 110 million
254.52|5.1| parameters. So the data set they used, I mentioned also, they
259.62|2.94| made the data set larger. So they had this so called web
262.56|4.84| text data set, consisting of millions of web pages. And they
267.4|4.12| also said, improving the quality was important. So how did they
271.52|4.96| improve the quality. So these web pages were based on Reddit
276.48|3.6| posts. So they collected, or focused on Reddit posts with
280.08|4.14| comma of three or more. So they were saying, okay, this is like
284.24|3.7| a minimum requirement for linking to a reasonable website
287.94|3.14| that it's not like a garbage post. But then also, many of
291.08|3.52| these had to duplicate. So they did some duplication, and also
294.6|2.84| some other websites, pre processing, cleaning, and so
297.44|4.8| forth. So overall, they got 45 million links to websites from
302.28|2.52| Reddit. And then after pre processing and cleaning, they
304.8|5.04| had 8 million documents. Yeah, amounting to 40 gigabytes of
309.84|6.88| text. Here's an example of this zero shot task transfer that I
316.72|3.78| mentioned before. So in contrast to GPT version one, there's no
320.5|3.46| specific instruction, or rearranging for the specific
323.96|4.12| tasks. So what I showed you earlier was that they had to
328.24|3.32| rearrange certain things here into the fine tuning. Now they
331.56|2.6| don't have any fine tuning and like something like that.
334.64|3.98| However, I couldn't find a very concrete example of that it was
338.62|2.9| a little bit I was honestly a little unsure of how that looked
341.52|4.66| like. I found on the hugging face repository an example,
346.18|3.98| though, of zero short topic classification. So a hugging
350.16|3.76| phase is a company specializing in language models and
353.92|3.68| specifically transformer based language models. And I guess I
357.6|3.46| will show you an example also, like of a bird model in the
361.06|4.32| coding examples, as the last video, but here, so they had
365.38|3.5| this nice online interface for playing around with zero short
368.92|3.52| topic classification. So you could essentially provide some
372.44|4.92| input, and then you provide your own labels. So these are labels
377.36|4.16| the model necessarily doesn't have seen before, right, because
381.52|3.4| it's trained just to do the next word prediction. But then after
384.92|4.38| that you provide on you provide possible topics separated by
389.3|3.38| commas here. So I just provided some. So this was my own
392.68|2.36| question, I just asked a random question, what is the color of
395.04|3.16| grass, and I provided possible labels, green, red, blue,
398.2|4.76| nothing pink and purple, and it got it correct here. So it was
402.96|4.32| kind of cool. Alright, so here are some results from the paper
407.3|5.48| on the size of the model. So they saw essentially, you can
412.78|3.8| see in all, all three here, all four plots in the top, you can
416.58|4.04| see on the x axis. So on the y axis are some evaluation
420.62|2.82| criteria, I think for all of them, the larger the better.
423.44|5.9| Okay. And you can see, on the x axis, the number of parameters
429.34|4.04| for the language models. And this blue line is their GPT
433.38|5.52| model. And you can see that in all cases, it goes up here,
438.9|3.4| basically, saying that more parameters is kind of better.
442.62|2.58| You can also see though, I mean, these are four different tasks,
445.22|2.08| reading comprehension, translation, summarization,
447.3|3.16| question answering, they're not reaching the performance of
450.46|4.32| other methods. So other methods are better at certain tasks
454.78|3.68| here. But this is also not necessarily the point I would
458.46|4.56| say. So not always outperforming other methods, it was really
463.02|5.28| just showing that these methods automatically learn how to
468.3|3.32| understand text even without the fine tuning, which was actually,
471.62|6.56| I would say quite impressive. So here are some more tasks. And
478.18|3.96| in this case, they actually performed pretty well. So I
482.14|4.76| think in bold here, the bold ones are their performances. And
486.9|3.52| you can see here, they outperform other tasks here,
492.7|4.44| except this one task. And I think here, the argument was
497.82|5.88| that in this one w one b w task, the sentences were shuffled. So
503.7|2.6| there was a sentence level shuffling in this data set. So
506.3|5.52| it's an existing data set. And this kind of defeats the purpose
511.82|3.72| of having a large context is input because one of the points
515.54|4.72| is that the model can take context into consideration a
520.26|2.66| transformer, right. But if you shuffle the sentences, you
522.92|3.26| destroy that context. So that is maybe one possible explanation
526.18|5.08| why the language models really didn't outperform other models
531.26|7.04| here. Okay. Um, yeah, this was GPT version two short video, and
538.3|23.56| then another short video on GPT version three.