start_time|end_time|text
2.56|3.72| Alright, let's now talk about the basic concepts behind
6.28|4.24| convolution neural networks. So I showed you this figure before
10.52|3.56| it's from an article you can find here if you're interested. I
14.08|3.2| thought that was actually a very nice summary figure of the
17.28|3.32| different assumptions that neural networks make. So for
20.6|3.36| instance, the multilayer perceptron assumes that the
24.08|3.48| features are independent. So that's the basic assumption
27.56|2.92| behind the multilayer perceptron architecture, I just
30.48|4.0| see, actually, this should be fully connected, usually in a
35.28|4.18| fully connected or multilayer perceptron. Anyways, so another
39.46|4.62| one is that we have a time dependency or sequence. And that
44.08|3.0| is something we will talk about when we talk about recurrent
47.12|3.88| neural networks. So if you think about text, so here, we have
52.08|2.68| essentially a sequence dependency, if you want to
54.76|3.16| analyze text from left to right, or something like that, or you
57.92|3.0| want to do stock market predictions or something where
60.92|4.16| you have a sequential component to the data, that would be
65.08|3.08| something for recurrent neural networks. For convolutional
68.16|4.64| neural networks, we have this locality assumption. So this is
72.8|3.52| what we are going to talk about. And specifically, this is for
76.64|3.12| two dimensional convolutional networks, you can technically
79.76|3.44| also use one dimensional convolution networks to analyze
83.2|3.64| text. But here, we are going to focus on the two dimensional
86.84|4.44| case for simplicity, that is image analysis. So here, imagine
91.36|4.64| this is our input image here, and how or what the conversion
96.0|4.44| network is doing. It's assuming essentially, that these patches
100.44|3.88| here, the pixels in a certain neighborhood, they are connected
104.36|3.2| to each other, or they are related to each other. And it
107.56|4.12| makes sense. So for instance, if I draw a face, as let's say, my
111.68|4.24| my image, you know that if you take this region, these are all
115.92|3.2| the pixels for the eye that have a relationship to each other. So
119.12|3.72| in that way, on these pixels here in the eye region, they are
122.84|3.24| not independent, they have some, yeah, some local dependency,
126.08|7.68| right. So and that is what the CNN is trying to capture. So
133.76|3.92| here's an illustration of one of the earliest convolutional
137.68|3.2| neural networks, at least that's the one I think that was the
140.88|4.64| first published version of it. So this is nearby Yanli Kuhn and
145.52|4.92| co authors, back in 1989. So that's a long time ago,
150.44|4.36| actually. But this is still relevant. It's still, um, I
154.8|3.56| would say the main architecture for image classification. I
158.36|1.92| mean, not this particular architecture, but the
160.52|3.4| convolutional neural network architecture in particular. I
163.92|2.04| think this one is actually called Lynette.
165.96|6.6| Five, there might be other variants of Lynette five. And I
172.56|4.4| will also show you how to implement that and pytorch and
176.96|4.16| how to apply to MNIST. But yeah, let's focus on the big picture
181.12|6.64| here first. So here, the authors used input images, handwritten
187.76|3.32| digits similar to MNIST. So here's an example of how they
191.08|3.12| look like. And the goal back then was here, here, in that
194.2|4.4| case, handwritten zip code recognition. And the inputs were
198.6|7.92| 256 times 256. I think that's 16 by 16, smaller than MNIST. And
206.52|2.44| you can see, like I showed you on the previous slide, there are
208.96|5.04| these image patches, or these patch regions that are analyzed.
214.28|5.12| And you can see what is going on here is that what's illustrated
219.4|6.16| is that pixels from this patch region go into here into some
225.64|3.48| will become a pixel in the next layer. So if you have multiple
229.12|4.88| layers, like input, hidden layer one, hidden layer two, hidden
234.0|6.12| layer three, and then here the output, then you can see, there
240.12|2.44| is always a patch that is analyzed, and it goes into the
242.56|4.44| next layer. And the same thing is going on here. So that way,
247.0|4.12| there's some feature extraction going on. And in fact, also, this
251.52|3.8| is only a static image, what you would do is you would slide this
255.36|2.72| patch here over the image. So you would start in the left
258.08|3.56| corner, and then move it to the right and so forth. So you
262.52|6.68| essentially move this on, you move this around like this, from
269.2|4.32| left to right, and then from top to bottom. But this will become
273.52|3.56| clear, I will show you, of course, additional illustrations
277.08|2.84| where this will be more, I would say clear here, this is a very
279.92|3.36| old figure. And some things are maybe not so easy to see here.
284.24|4.6| Another thing, for instance, to highlight here is that there are
288.88|3.56| two, two of these, and actually, in fact, there are 12. So then
292.48|4.28| they are dotted between, so there would be 12 of these so
296.76|3.72| called, yeah, feature maps. And let me just maybe forward
300.48|2.96| because I have another illustration of the same
303.44|1.88| architecture that is a little bit more clear.
307.76|2.32| Yeah, so here's another illustration of that
310.12|3.16| architecture, except that the inputs are a little bit larger,
313.28|4.56| they are 32 by 32. It's from a slightly newer paper, where they
317.84|2.8| apply this to document recognition instead of just zip
320.64|3.2| code recognition. So here, this also includes letters and not
323.84|3.96| only digits. But again, the same concept applies. And I think
327.8|3.04| this is a little bit easier to, yeah, to interpret. And this is
330.84|3.56| Yeah, this is the linear five. And I will show you a code
334.4|3.2| implementation in pytorch. I just implemented that also in
337.6|7.36| code. So what's going on here is essentially that we have these
345.04|3.72| what we call convolutions, this operation, where you take a
348.76|5.16| patch from the input, and then project it up to here. And how
353.92|2.48| this is computed, I will, of course, explain it to you for
356.4|3.84| now, just assume, somehow, these pixels get
362.16|3.36| summarized into a single pixel, which goes into the next map.
365.72|8.52| These are the so called feature maps. So here I have 1234566 of
374.24|6.68| these feature maps, that's this number here. And the input is 32
380.92|3.84| by 32. And if I do this, if I start in the left corner, then
384.76|6.96| compute the first pixel here, and then I move this by one
391.8|3.24| pixel to the right and then compute the next pixel here, and
395.04|2.64| then move this again to the right and compute the next
397.68|4.88| pixel, my output would be 28 by 28. Because that's just because
402.56|3.04| of the cutoff because of the kernel here, in this case is
405.8|3.72| three by three, or I think it might be actually bigger, you
409.52|2.92| cut off something on the left and on the right hand side. But
412.44|5.92| this is a detail that we will discuss in a later video. I
418.36|2.44| think this is actually a five by five kernel, then it makes
420.8|3.92| sense. So if we have a five by five kernel, we would, on each
424.72|5.28| side, cut off two pixels. So we lose two pixels of the input. So
430.0|4.52| that's just why it's 28 by 28, and not 32 by 32. But again, we
434.52|3.92| will discuss that in a future video, how exactly things got
438.52|3.56| calculated and cut off. So here, the just the big picture is
442.08|5.56| that we go from the input to these feature maps. And then we
447.64|5.0| go to another feature maps thing here, and another and another,
452.92|3.52| and so forth. So we extract these feature maps. And what you
456.44|6.28| can see is, first of all, there is here, a step where we add
462.72|9.6| channels. So in fact, there are no six channels here 123456. And
472.32|5.4| we do that by using different, different arm of these feature
477.72|8.88| detectors. Let's call that a feature detector. And we have
486.64|3.84| six of these feature detectors. In each feature detector, we
490.48|4.16| slide over the image. So let's say we have this red feature
494.64|3.04| detector that we slide over the image to produce this feature
497.68|3.84| map. And then we do the same here with the green one, the
501.52|2.96| green one would be another feature detector, and then it
504.48|3.76| produces this feature map. And just assume that we have six of
508.24|5.04| these. And here there is a so called sub sampling operation.
513.6|3.68| We will see later, this is also called max pooling. And here,
517.28|5.28| what we do is we just reduce the size. So this is like, so this
522.56|2.88| first is the convolution, and the sub sampling, you can think
525.44|7.56| of it as, let's say size reduction. And then again, we do
533.0|5.4| another convolution. Now we have 16 feature maps, then we do
538.4|6.84| another sub sampling another size reduction. And then we end
545.24|5.28| up with these here. And these here, they get now reshaped. So
550.52|6.08| we can say reshape. And if you will see the code later, it will
556.6|3.36| also become way more clear. So that's just a reshape operation
560.08|8.6| to reshape that into vector. And for instance, when we have this
568.72|4.76| reshape one, we can then use a fully connected layer, and
573.48|4.6| another fully connected layer to compute the class labels, the
578.08|4.96| outputs. So I illustrated this here in this slide. This is
583.04|4.8| essentially the main I would say the main idea behind convolution
587.84|4.6| networks, besides using these local filters, it's that we have
592.48|3.36| automatic feature that extractor, this is essentially
595.84|3.4| the deep learning part about it. So instead of having a human
599.24|5.32| manually extracting features from input images, there's now
604.56|2.6| this automatic feature extractor, the convolutional
607.16|4.48| layers. So the convolutional layers are doing automatic
611.84|3.28| feature extraction that is learned by using back
615.12|3.6| propagation. And then in the end, part of the convolution
618.72|4.68| network is here, this fully connected part, or can think of
623.4|9.24| it as the multi layer perceptron part. And this is then
632.76|3.68| essentially just like a classifier. So here, when it
636.44|5.04| gets these fully connected, sorry, the vector, the reshaped
641.48|2.76| vector, this is essentially then here like a regular
644.28|3.7| classification. And this is a feature vector that was
647.98|7.38| automatically extracted using these convolutional layers. Yeah,
655.36|3.8| and each convolutional layer, you can think of it as one
659.2|3.6| hidden layer in this network. So if we are counting the number
662.8|3.6| of layers, we have five networks, five layers in this
666.4|3.52| architecture. So the first convolution here, so it's the
669.92|4.84| first convolution layer here, the sub sampling there, it's
674.76|5.4| essentially just, it's also sometimes called pooling. It
680.16|5.52| doesn't have any weight parameters. So there's no real
686.88|3.32| learning going on. So we usually don't count those as layers, we
690.2|5.64| only count the layers that have weights. So in this case, first
695.84|5.4| layer, second layer, the other convolution layer, and then we
701.24|7.2| have 122 fully connected layers. So that's three, four, these are
708.44|3.64| essentially hidden layers. And then we have this output layer.
712.12|2.4| So it's another one, it's our fifth layer. That's why the
714.52|8.88| network here has five layers. Yes, so here's an annotation of
723.4|4.92| everything I talked about in the previous slide. So yeah, this
728.32|4.32| first number here represents the number of channels. This, the
732.68|3.08| second and third number represents the height and width.
735.84|8.82| So the size, so let's say height and width. Like I said, this
744.66|3.78| last part is a multi layer perceptron part. The sub
748.44|5.6| sampling nowadays is usually called pooling. And yeah, this
754.04|5.28| these are the so called feature detectors. Nowadays, also, we
759.32|4.68| call them kernels or filters really depends on kind of who
764.0|5.16| the author is and who, let's say for the library. So some machine
769.16|2.84| learning or deep learning libraries use the word kernel,
772.04|4.64| some use the term filter. And nowadays, they are pretty much
777.08|4.48| interchangeable. I most often happen to use kernel, but I also
781.56|4.0| recently tried to use the fill a term filter. More often, it's a
785.56|6.08| little bit more modern. On here, so one more note about these
791.64|6.16| Gaussian connections. So this is essentially on what they did
797.8|3.88| here is they used fully connected layer together with a
801.76|2.6| mean squared error loss. This was usually called a Gaussian
804.4|3.44| connection. And nowadays, as you know, in multi layer
807.84|2.68| perceptrons, it's more more common to use a fully connected
810.52|5.68| layer with a softmax activation and the cross entropy loss. So
816.2|4.84| here is a summary of the three main concepts behind convolution
821.04|3.24| networks. So based on what I just showed you in the previous
824.28|3.64| slides, so there's one aspect that's the sparse connectivity.
828.18|2.62| So that means that a single element in the feature map is
830.8|3.04| connected to only a small patch of pixels, which is very
833.84|3.76| different from fully connected neural networks. So just to
837.6|3.0| illustrate what I mean, again, so if I have my input image
840.6|8.1| here, then I have my on my feature maps here in the next
848.7|6.3| layer. And we use these kernels like I explained to essentially
855.0|3.6| focus on a small region and then project this as a, let's say
858.6|2.88| activation into the next layer. That is what we do in the
861.48|2.84| convolution network. If you recall in the multi layer
864.32|3.4| perceptron, we didn't have this sparse connectivity, we had a
867.72|4.24| full connectivity. That means, when we had an input image, we
871.96|4.88| were usually reshaping it into a long vector, right? So this one
876.84|5.18| here would become like a long vector. And then how this worked
882.02|5.3| was for all the inputs. So the whole thing, when became activation
887.32|6.72| in the next layer, so the whole maybe do this differently. So in
894.04|2.8| the next activation in the next layer, if this is our next
896.84|5.84| layer, all the all the inputs were connected. So in that
902.68|3.44| sense, it would be similar to using a kernel that has the same
906.12|3.88| size as the whole image, and then projecting it here, right.
910.24|4.26| So if we had a full connection, so sparse connectivity, that's
914.5|3.54| one aspect behind convolution networks. But then there's also
918.3|4.86| the aspect of parameter sharing. So what that means is that we
923.16|5.2| use the same, exactly the same filter here, or kernel, or
928.36|3.44| feature detector that we slide over the image. So once I
931.8|4.72| compute this one here, I move it by one position to the right,
936.54|3.26| let's say like this. And then I compute it for the for the next
939.8|3.56| position. But I'm not creating a new filter, I'm using the same
943.36|4.32| filter, and just move it by one position up to the right. So in
947.68|3.52| that way, I'm doing a parameter sharing here, I'm reusing that,
951.2|4.6| and again, in a multi layer perceptron, we would have a
955.8|2.72| completely different set of weights for each hidden
958.52|3.0| activation, right. So for this second one, I would have a
961.52|5.88| completely new set of weights, which is not the case for the
967.4|2.68| convolution network for the convolution network, we just
970.1|3.9| slide the same weights over by one position and reuse that. So
974.0|3.44| this is why you can think of it as a very general purpose
977.44|3.84| feature extractor that should work for all regions in that
981.28|4.84| image. But yeah, what we have is we have multiple of these
986.12|4.16| feature detectors, or we can have multiple to produce these
990.28|3.0| different feature maps, right. So there could be three feature
993.28|3.6| maps. So I can have three of these filters. But for each
996.88|2.88| feature map, I'm reusing the same one that I'm sliding here.
999.76|7.28| Yeah, and another aspect is that we have many layers. So when we
1007.04|3.84| do the convolution here, we construct feature maps, and we
1010.88|4.44| do this many, many times. And over time, this is essentially
1015.6|6.16| over many layers. Usually, what we do is we create more
1021.76|4.72| channels when we go from one to the next layer. And this is
1026.48|4.02| essentially to extract patterns. And he was I will show you an
1030.5|4.54| example later, what effect that house has is that it is basically
1035.04|4.76| essentially trying to extract local patterns from the global
1039.8|6.96| ones. So you have a big picture. I mean, big in terms of the size
1046.76|3.4| of the pictures relatively large, but then you're over with
1050.16|3.52| the course over the training, it will, from this global picture,
1053.68|3.6| extract local images. So information about the eye and the
1057.28|3.2| nose and things like that. So it will sort of just regarding this
1060.48|3.76| whole thing as one image, it will then have one feature map
1064.24|8.4| that represents, let's say, I and one that represents nose and
1072.68|3.56| so forth. So in that way, it's learning these more local
1076.24|6.0| patterns from this global image. Okay, so this was really the big
1082.24|4.36| big picture overview. I can imagine there was a lot of new
1086.6|4.16| stuff going on in this video. So things might be unclear. Instead
1090.76|3.48| of maybe re watching this video, I recommend you maybe for now to
1094.24|3.32| keep going and watch the next video because I will go into a
1097.56|2.48| little bit more detail about the convolutional filters and the
1100.04|3.68| weight sharing. And I think this might clarify some questions you
1103.72|3.36| have. And if things are still unclear after that, then maybe
1107.08|4.0| revisit these two videos. But right now, I would say, if
1111.08|3.08| things in this video were unclear, keep going before you
1114.2|2.8| rewatch this one, because the next video really might clarify
1117.0|24.6| some things.