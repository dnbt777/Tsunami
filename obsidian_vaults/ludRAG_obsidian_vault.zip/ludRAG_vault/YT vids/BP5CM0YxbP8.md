start_time|end_time|text
5.04|3.28|today i'm going to talk to you about
6.72|3.12|vision transformers since this is all
8.32|4.0|about transformers
9.84|5.28|um specifically their application for
12.32|4.24|visual representation burning but before
15.12|3.36|we jump into transformers i'm gonna
16.56|4.96|spend like 10 or 15 minutes giving you a
18.48|4.959|lot of context on all of this uh and
21.52|4.64|specifically also on the vision part of
23.439|4.641|things because i think a majority of
26.16|4.4|what you have seen and we'll see will be
28.08|4.56|about language
30.56|4.08|all right so let's get started my goal
32.64|4.4|and that of my close collaborators is to
34.64|5.2|find general visual representation and
37.04|5.519|you're going to soon see what that means
39.84|4.96|and why or what can we do if we imagine
42.559|4.641|we have a general visual representation
44.8|4.88|the hope is that with this we can really
47.2|4.64|kick start all kinds of tasks that
49.68|4.08|require visual input that means most
51.84|4.719|tasks that you do when you have your
53.76|4.4|eyes open basically
56.559|3.52|because if you have a good understanding
58.16|4.079|of what you see
60.079|4.641|then you can much quicker understand
62.239|3.92|what's going on and what you should do
64.72|3.68|um
66.159|5.121|and eventually i have now a little kid
68.4|5.759|and since the year and so i really want
71.28|4.64|that when he's grown up that there is
74.159|3.121|like some kind of robot
75.92|3.04|it doesn't need to be nice and pretty
77.28|2.64|like in movies just maybe an arm or
78.96|3.36|whatever
79.92|4.64|that my kid could teach or my parents
82.32|4.159|who cannot program can teach to do some
84.56|2.72|boring tasks that they really don't want
86.479|3.361|to do
87.28|4.64|and i believe one component of this is a
89.84|4.56|good visual representation that
91.92|4.72|generalizes to understanding the word
94.4|4.079|visually everywhere it's not all that's
96.64|4.08|required but it's one part and the part
98.479|4.081|that i'm trying to push
100.72|4.24|so this is for context and motivation on
102.56|4.559|working on general visual representation
104.96|4.799|and one good example of a general visual
107.119|4.081|representation is the humans
109.759|2.961|and i'm going to show you what i mean by
111.2|4.8|that so
112.72|5.52|here is a task that i give you there is
116.0|5.28|three classes class a b and c and they
118.24|6.479|give you five images of each class okay
121.28|6.479|um and here i give you a new image
124.719|5.361|and i'm sure that by now you all know
127.759|4.161|which class it is i'm not gonna ask
130.08|3.28|because i don't actually see you if i
131.92|2.319|was in the room i would do the raised
133.36|2.4|hands
134.239|2.401|uh but i'm sure you know it's class a
135.76|2.559|now
136.64|3.599|um okay this is fine we have seen
138.319|4.401|millions of flowers in our lives
140.239|5.041|hopefully uh but there is other kinds of
142.72|4.159|pictures like this uh satellite images
145.28|3.599|that you don't see much in your life
146.879|4.0|some people may have never seen it some
148.879|4.241|sometimes like when you fly or maybe on
150.879|4.961|tv or in the internet or so but it's
153.12|6.56|rather rare but still same story three
155.84|6.32|classes class abc five images of each
159.68|4.24|and i show you a new image this might be
162.16|4.32|a little bit less trivial than the
163.92|5.039|flower but i think i've spent enough
166.48|4.64|time talking that by now most of you
168.959|4.481|should know that this is class b
171.12|4.56|shows uh what is it basketball chord
173.44|2.24|right
175.84|4.399|all right now even more abstract you
177.84|5.2|don't see this in real life right but
180.239|4.561|still i give you images of class a and b
183.04|3.44|and just two to make it a bit easier
184.8|3.12|here because you need to use your brain
186.48|2.399|a little bit more
187.92|3.36|um
188.879|4.881|and i show you this new image
191.28|5.039|and now i should do a little bit of
193.76|4.8|smart talk to let you think and like you
196.319|4.881|see that there is like spheres boxes and
198.56|4.959|whatnot and by now i hope that most of
201.2|4.88|you know that this is class a
203.519|5.201|why because there is three objects in
206.08|4.079|class a and class b is always what is it
208.72|3.519|five objects
210.159|3.44|uh no matter what they are what they
212.239|4.801|look like
213.599|5.121|uh okay i think by now you more or less
217.04|3.52|understand what i mean when i mean a
218.72|4.799|good visual representation general
220.56|4.399|visual representation right some
223.519|3.28|some
224.959|3.681|i don't know how to call it in your
226.799|4.0|brain in your eyes
228.64|4.48|such that you can quickly
230.799|5.281|see something new and understand what's
233.12|5.759|going on with just a few examples
236.08|5.12|and then generalize from that
238.879|4.0|right and that's the goal then the next
241.2|3.599|step if we have the goal how do we
242.879|4.241|measure progress towards it
244.799|4.08|uh and this is a paper we did a few
247.12|3.28|years ago with my collaborators which
248.879|3.36|you call the visual task adaptation
250.4|4.96|benchmark it's kind of formalization of
252.239|4.56|the little game that we just played
255.36|5.04|so it's a benchmark
256.799|5.28|and there is some component that you or
260.4|3.76|anybody who participated in benchmark
262.079|4.721|does which is creating a model with some
264.16|4.479|data we don't really care what data what
266.8|4.08|mother how what not
268.639|5.041|just you come with the mother
270.88|5.12|then we come with this landscape of all
273.68|3.36|possible visual tasks that kind of make
276.0|3.36|sense
277.04|4.96|uh which is a big statement and we
279.36|4.8|sample some tasks from that
282.0|4.479|and this is kind of the task that you
284.16|4.479|have just seen they were actually
286.479|4.641|taken out of this task adaptation
288.639|5.201|benchmark and we have uh for our first
291.12|5.92|step made 19 such tasks where we try to
293.84|5.6|cover broad types of visual tasks
297.04|4.8|not just classes of natural images like
299.44|4.24|these docs and cats things but also of
301.84|4.639|very specialized images like satellite
303.68|4.4|image also non-classification tasks that
306.479|3.841|involve counting like the one i showed
308.08|4.399|you before right but that can be
310.32|4.8|expressed in this simple classification
312.479|4.0|api but that logically requires some
315.12|3.6|more thinking
316.479|4.0|um some things like distance we have
318.72|4.4|something with cars and with distance of
320.479|5.201|the closest car and things like that
323.12|3.76|um it should cover a broad range of
325.68|2.64|variation
326.88|3.759|and then
328.32|4.159|with the model that you came
330.639|5.041|to this benchmark you can do some
332.479|4.961|adaptation step on each of the data sets
335.68|3.76|one after another all at the same time
337.44|4.64|doesn't really matter but then you
339.44|4.72|should have as a result another
342.08|4.24|of this data set which is very small it
344.16|5.039|just has seen a few examples for each
346.32|4.48|class that then performs where there
349.199|3.041|and then we just take the average score
350.8|3.679|across all of these tasks and this is
352.24|5.679|what we call the beta task and this is
354.479|4.401|how for now we judge the
357.919|2.321|how
358.88|3.039|how good of a general visual
360.24|4.799|representation does your model and
361.919|5.28|adaptation algorithm have
365.039|4.401|and now just for some nomenclature this
367.199|4.161|preparation uh we have words that we
369.44|4.08|often use pre-training sometimes we call
371.36|4.88|it the upstream like upstream data
373.52|4.0|upstream training something so i may use
376.24|3.28|this word interchangeably with
377.52|3.76|pre-training and then there is the
379.52|3.44|second part which we usually call
381.28|3.12|transfer and then sometimes we say
382.96|4.88|downstream
384.4|5.359|uh and the adaptation for our in
387.84|3.919|principle is whatever you want but for
389.759|4.0|our work we almost always just use very
391.759|4.16|simple fine tuning without any bugs and
393.759|3.921|whiskers because it worked it's simple
395.919|4.0|and works well in general we try to do
397.68|4.48|things as simple as possible that still
399.919|4.241|work well and so sometimes i even just
402.16|3.759|say like fine tuning when fine tuning
404.16|4.8|that means moving from this pre-training
405.919|3.921|through the transfer
408.96|5.44|all right
409.84|4.56|so so far for the setting so far so good
415.52|2.959|good
416.72|3.44|then the question is how do we get there
418.479|3.681|and we spend a lot of time thinking
420.16|4.879|about this and trying different things
422.16|5.28|and this is also roughly the outline of
425.039|3.921|all that i have available to talk about
427.44|2.879|which doesn't mean we're gonna cover
428.96|2.239|everything
430.319|2.481|um
431.199|3.28|so i'm not gonna go like through the
432.8|3.6|outline exactly but you will see this
434.479|3.681|again and again and as you see vision
436.4|3.199|transformer the transformer only comes a
438.16|2.879|little bit later there's some stuff
439.599|2.401|before that
441.039|2.72|um
442.0|3.44|so this one just really quickly because
443.759|3.201|it doesn't matter for this course is
445.44|3.199|that we spent some time trying
446.96|3.84|self-supervised pre-training which is
448.639|5.041|very popular in language and envision
450.8|5.119|only recently has become popular and
453.68|4.4|it doesn't work that way like you don't
455.919|5.441|need to understand these bars but
458.08|5.119|basically higher is better and here
461.36|3.44|just look at the blue ones that's the
463.199|4.081|meetup score
464.8|4.16|for this future to meet up and search
467.28|3.919|supervised learning performs like this
468.96|3.84|bar we tried multiple methods and
471.199|3.201|multiple models and so on it's also
472.8|4.48|proper good benchmark but it was a
474.4|2.88|couple years ago
477.68|4.239|then we moved on to semi-supervised
479.68|4.32|training so a few labeled examples and a
481.919|3.761|ton of unlabeled examples that's this
484.0|4.639|next blue bar do you actually see the
485.68|2.959|mouse cursor sorry
489.599|6.72|uh we don't see the mouse cursor ah
492.96|3.359|maybe i need to do something
497.599|4.401|yeah okay
499.36|4.32|um yeah so then semi supervises that
502.0|4.319|blue bar which is a lot higher than this
503.68|4.48|other blue bar so what this means to us
506.319|3.28|is that by adding a few label examples
508.16|3.84|we are able to
509.599|4.56|get much better and or much more general
512.0|3.919|visual representation
514.159|4.0|then i'm not going to spend more time on
515.919|3.6|this and how exactly and so on
518.159|3.76|but i'm going to move to the next one
519.519|4.32|which was for us kind of a breakthrough
521.919|2.721|uh when we figured out that where if we
523.839|3.281|just
524.64|4.24|skate up fully supervised free training
527.12|3.44|then we get really much better
528.88|4.0|representations than everything we've
530.56|3.839|seen before and here i want to briefly
532.88|3.6|spend some time on that one because it's
534.399|4.721|the precursor to using vision or
536.48|4.4|transformers in video
539.12|3.839|so the idea is simple that
540.88|3.28|there are tons of images on the internet
542.959|2.88|and that's always what you hear is
544.16|3.44|motivation for self-supervisor
545.839|3.841|unsupervised learning right
547.6|4.0|but actually where these images come
549.68|4.159|from there is almost always some extra
551.6|3.84|information like surrounding the image
553.839|3.201|on the web or
555.44|3.36|if you collect it otherwise there's some
557.04|4.08|extra information there that you could
558.8|4.8|use as some weak source of information
561.12|4.24|or some weak labor right
563.6|3.76|then it happens that in google there is
565.36|4.479|some team that actually does this for
567.36|4.64|production um and they have collected
569.839|3.841|already a large data set with some
572.0|4.399|pipeline that from the surrounding
573.68|5.76|signals somewhat automatically but very
576.399|4.961|noisy annotates the images
579.44|5.2|and we wanted to figure out how how far
581.36|5.919|can we go when we scale up pre-training
584.64|4.879|then long story short you need a couple
587.279|4.401|ingredients one is patience i really
589.519|4.721|like this plot this is one of the curves
591.68|3.839|of just pre-training on large data with
594.24|3.279|large motors
595.519|4.0|doesn't the details don't really matter
597.519|4.801|the gist is that if i zoom into this
599.519|5.041|little box i see this here and this is
602.32|5.12|the metric for the training like the
604.56|4.88|performance in upstream that i see after
607.44|4.399|spending eight gpu weeks of compute what
609.44|4.16|does gpu it mean it means eight gpus for
611.839|2.881|a week or
613.6|3.6|sorry
614.72|3.92|one gpu for eight weeks or eight gpus
617.2|4.24|for one week
618.64|4.96|or 16 gpus for half week and so on right
621.44|4.32|but this looks bad reasonable person
623.6|3.6|would say yeah there's no progress for a
625.76|3.44|week on eight gpus this is what i'm
627.2|4.319|gonna stop and try something else but we
629.2|4.24|are not reasonable so we keep going
631.519|4.641|and this is what the exact same spot
633.44|4.639|looks like after a gpu month of training
636.16|3.679|uh and you can clearly see that things
638.079|4.641|are progressing right so it may not
639.839|4.641|always be obvious and you need patience
642.72|3.76|uh the second thing
644.48|3.919|is that you actually need to scale up
646.48|4.24|everything so this was work done with
648.399|4.161|resonance not yet with transformers as
650.72|3.679|you see a lot of resonant models here
652.56|3.68|the x-axis is the number of images
654.399|3.761|available in vision there is this image
656.24|3.839|in the data set which is a very common
658.16|4.239|uh super common data set for free
660.079|3.841|training which has 1.3 million images
662.399|3.12|there's another one which has 10 times
663.92|4.479|more images that stay public and then
665.519|5.201|there is one subset from this internal
668.399|3.521|group that has 300 million labeled
670.72|2.0|images
671.92|3.44|so
672.72|4.72|the y-axis is measure of accuracy on
675.36|4.479|some tasks and we tried many they all
677.44|3.92|look similar
679.839|3.201|and the dots are differently sized
681.36|4.4|resonates the blue dot is the standard
683.04|4.72|resonant 50 that everybody uses if this
685.76|4.16|one you train on more data it looks
687.76|4.079|promising at first but if you go to even
689.92|4.56|more data it looks like okay this
691.839|4.321|doesn't really seem that useful and this
694.48|3.76|is what most people have been doing for
696.16|3.76|a long time and
698.24|3.68|a lot of people even in google were like
699.92|3.84|yeah i tried this
701.92|3.76|internal checkpoint on this tons of data
703.76|3.6|it doesn't really have that much
705.68|3.68|however what we found out and in
707.36|4.32|hindsight is kind of obvious
709.36|4.24|uh is that you actually need to scale
711.68|3.599|not just the data but also the model
713.6|4.4|here this blue dot is a gigantic
715.279|4.401|resonance that is slow as hell but when
718.0|3.12|you scale this up together with the data
719.68|2.48|you keep getting benefit with adding
721.12|2.64|more data
722.16|4.479|and then if you do these two things
723.76|4.96|scale up everything and be patient
726.639|5.521|be patient but also be
728.72|3.44|quite scale of your patients
732.24|4.96|then you get a lot of benefits so here
734.399|4.56|there is a few shots transfer learning
737.2|2.879|what i showed you before
738.959|3.44|and
740.079|4.56|on the x-axis is size of the motor on
742.399|3.921|the y-axis is the accuracy on one of
744.639|2.64|these tasks but again others look
746.32|3.04|similar
747.279|4.161|and these three different curves are
749.36|3.919|retrained with different data set sizes
751.44|4.079|the green one being the standard one you
753.279|4.161|don't really see benefit or small
755.519|3.601|benefit from going with larger models
757.44|3.28|the blue one is 10 times larger you
759.12|3.76|start seeing some
760.72|4.32|slope upwards but really only with this
762.88|3.759|giant data you start like getting better
765.04|3.12|and better and better at these few
766.639|3.361|shortcuts for learning when you
768.16|3.679|pre-train online more data with larger
770.0|3.92|and larger models
771.839|4.321|second benefit that we did not
773.92|3.76|anticipate really at all but then found
776.16|5.04|out is that these models are super
777.68|5.36|robust when you scale everything up
781.2|3.36|this is object net it's a data set
783.04|4.0|that's specifically designed to measure
784.56|4.719|robustness and it shows things in crazy
787.04|4.239|like a chair in a bathtub and things
789.279|4.0|like that and you should recognize it as
791.279|5.041|chair
793.279|5.441|and here the pink dots are basically how
796.32|4.319|existing models and x-axis is again how
798.72|3.84|large is the model and pink dot is
800.639|4.241|existing ones from the literature and
802.56|4.48|then these lines same color coding is
804.88|4.56|what we found out and again you see this
807.04|4.88|large data and then going to large model
809.44|3.92|just gives you amazing benefits on like
811.92|3.12|in this case out of distribution
813.36|3.84|robustness
815.04|4.88|okay so this was like
817.2|4.639|amazing scale up everything be patient
819.92|3.919|and get huge benefits
821.839|3.521|uh sorry lucas
823.839|3.841|sorry for interrupting you but there is
825.36|3.919|a question from a student in the class
827.68|3.279|yeah right
829.279|3.601|do you want to unmute yourself and ask
830.959|4.081|it yourself
832.88|3.36|yeah i can i can ask my question uh can
835.04|2.72|people hear me maybe there's some
836.24|2.88|magazines on site once i can just step
837.76|2.96|away real quick yeah so the question i
839.12|3.2|want to know is what work has been done
840.72|3.2|characterizing the parameters after
842.32|3.199|pre-training finishes
843.92|2.88|like the reason why i'm motivating this
845.519|2.56|question is
846.8|2.88|it seems like we do this tremendous
848.079|3.281|amount of pre-training but it seems like
849.68|3.2|we might be able to significantly reduce
851.36|4.24|that if we just have smarter
852.88|4.639|initialization schemes
855.6|4.16|yeah you know i've been thinking this
857.519|3.361|for a long time actually also
859.76|3.92|um
860.88|3.759|and they've come to conclude that i
863.68|2.159|think
864.639|3.681|not
865.839|5.68|um i think there is like two parts one
868.32|5.12|is like what i like to call hand-wavy
871.519|4.161|the numerics of the weight you know that
873.44|3.68|everything is in a nice range such that
875.68|3.839|it can have nice
877.12|4.399|input output functions and so on and and
879.519|3.841|that your optimizer can do steps that
881.519|3.841|you know make reasonable change to the
883.36|3.44|input output function but not too large
885.36|3.12|and so on
886.8|3.52|i think that is part of it and that you
888.48|4.32|can get through good in it or good
890.32|4.72|normalizations and whatnot
892.8|4.24|but then i also think there is i do
895.04|3.359|think that these models memorize a lot
897.04|3.039|and then
898.399|5.041|personally i believe but i don't know of
900.079|5.2|evidence or so these models do more kind
903.44|4.16|of you know
905.279|4.161|remembering similarity to things they've
907.6|3.919|seen in training
909.44|4.0|and then as you grow things up they have
911.519|4.081|more memory and they have seen more
913.44|3.759|things so they should be better on more
915.6|3.52|newer things because there's more
917.199|4.88|similar things they have seen
919.12|7.079|and this i don't think you can like just
922.079|4.12|create one shot from initialization
926.399|3.761|but i don't have immediate
928.0|4.24|pointer to a paper at the top of my head
930.16|4.08|now to answer your question okay thank
932.24|4.48|you
934.24|4.48|i think we also have more questions so
936.72|4.32|has posted on the chat and
938.72|3.679|is
941.04|3.2|maybe in this order you want to ask your
942.399|4.321|question first
944.24|4.8|yeah for sure i could go ahead so i just
946.72|3.28|had a quick clarification on this this
949.04|2.88|uh
950.0|2.72|chart right here the the chart number
951.92|3.359|three
952.72|5.76|the bit l and bit and bit x are they the
955.279|4.721|same uh model architecture but just
958.48|4.159|trained on different data sets so the
960.0|4.32|bit ass is trained on the 1.3 million
962.639|4.241|all the way to the 300 million image
964.32|5.92|data set for bit l
966.88|6.319|uh yes and no the architecture is here
970.24|5.68|on the x-axis so within one vertical
973.199|4.88|slice these are the same architecture
975.92|3.919|and then the different points are random
978.079|3.841|restarts because when you're future
979.839|4.641|learning there is a lot of variance in
981.92|4.479|which few examples do you see and then
984.48|3.76|again this next vertical slice is the
986.399|4.081|same model and so on and as you go to
988.24|4.48|the right the model gets larger and so
990.48|4.08|you can see that for this little data
992.72|3.84|going to larger model doesn't really
994.56|4.56|help you much for free training only for
996.56|5.519|this giant data air means the giant data
999.12|4.399|not necessarily giant model in this case
1002.079|2.481|right at least once
1003.519|3.281|thank you
1004.56|2.24|okay
1007.36|5.12|uh do you have a question oh i see
1009.04|3.44|you're raising your hand as well
1013.12|4.32|hey yeah thanks um
1015.6|4.4|what is the
1017.44|7.999|intuition for the upstream performance
1020.0|7.6|in figure 1 spiking so suddenly at
1025.439|4.0|three points in in training
1027.6|2.959|here right yeah
1029.439|3.12|yeah yeah
1030.559|3.36|again like around one point like i don't
1032.559|3.681|know that just seems like a an
1033.919|5.04|odd-looking uh training curve so like
1036.24|4.719|yeah what's the uh intuition behind that
1038.959|3.6|yeah this is uh old-school computer
1040.959|3.84|vision thing or else what i mean a few
1042.559|3.601|years ago uh is this when the learning
1044.799|3.12|rate changes
1046.16|3.759|in computer vision it used to be very
1047.919|3.841|common to have the learning rate in a
1049.919|3.921|kind of staircase pattern so it's
1051.76|3.68|constant for a while and then you stop
1053.84|3.36|you divide the learning rate by 10
1055.44|4.32|usually boom smaller and then you
1057.2|5.04|continue and this gives you this huge
1059.76|4.0|jump and nowadays people don't use this
1062.24|3.36|much anymore and this work was like
1063.76|3.36|three years ago i think or two or three
1065.6|3.76|years ago i don't remember
1067.12|4.16|it was very common back then and
1069.36|3.76|nowadays people use more continuously
1071.28|3.68|changing learning rate schedule and then
1073.12|4.0|you don't really have this sudden change
1074.96|3.839|anymore but if you would overlaid it
1077.12|3.679|would be like more continuously but
1078.799|4.081|going roughly the same
1080.799|4.0|and then in language i think most people
1082.88|3.6|or many people use their just linearly
1084.799|3.12|decreasing learning rate schedule where
1086.48|4.319|also you don't see this effect because
1087.919|4.921|learning rate continuously decreases
1090.799|5.281|okay yeah sounds good
1092.84|5.24|thanks and then this is what because you
1096.08|4.0|asked for about this and this dotted
1098.08|3.76|line actually here if if you're like
1100.08|4.959|here you could say okay but this is
1101.84|5.44|excessive right maybe it does really
1105.039|4.321|seem almost flat maybe you could have
1107.28|3.84|started the decay earlier and earlier
1109.36|4.48|and earlier and then you would get the
1111.12|5.2|same but much quicker and this is this
1113.84|5.199|one shows what would happen then and you
1116.32|4.56|do land at much worse place in the end
1119.039|4.561|than with the patient
1120.88|5.6|okay yeah yeah that makes sense
1123.6|5.04|oh thanks
1126.48|4.16|was there more question or i continue
1128.64|3.6|i i think
1130.64|3.6|both of you have your answers because i
1132.24|3.6|i need to mention i don't see you i just
1134.24|3.439|see
1135.84|3.44|yeah it's fine we can coordinate that
1137.679|2.641|lucas
1139.28|4.399|um
1140.32|5.04|hi yeah so i just want to make sure that
1143.679|4.081|i'm like on the same page so basically
1145.36|4.559|what you're trying to do is multitask
1147.76|4.4|learning with convolutional neural
1149.919|4.721|network slash lsts right that's kind of
1152.16|4.32|like resnet
1154.64|3.44|but you're doing multitask learning
1156.48|3.76|correct no
1158.08|3.68|where does the multitask come from or
1160.24|3.439|why
1161.76|5.279|because like initially like you showed
1163.679|3.36|like different um
1167.76|4.08|yeah okay
1168.88|4.0|there is two phases the first one is the
1171.84|2.959|training
1172.88|4.24|uh and this pre-training
1174.799|3.441|oh i didn't mention it yeah i just said
1177.12|3.2|i don't care what you do in the
1178.24|4.48|pre-training just pre-train somehow and
1180.32|6.32|give me the mother and then i test it on
1182.72|6.24|multiple tasks independently and
1186.64|4.24|does means like transfer it to that task
1188.96|4.56|which in our case means find unit just
1190.88|4.48|on the task and see how well it does and
1193.52|4.32|so on but it could mean other things
1195.36|3.92|like later we moved to just learning a
1197.84|3.199|linear regression on top of the
1199.28|4.0|embeddings for each task
1201.039|4.161|and now during the pre-training
1203.28|4.08|what we do is just regular supervised
1205.2|5.28|learning but just scaling everything up
1207.36|6.0|and regular supervisor is just
1210.48|4.24|well not in multitask but multi-label in
1213.36|3.199|the sense that an image could have a
1214.72|4.4|couple labels or not but it usually
1216.559|5.761|doesn't have it this is a minor okay
1219.12|3.2|you got it thanks
1224.72|3.92|all right
1226.88|3.679|uh yeah just have a quick follow-up
1228.64|3.919|about the question rather than like the
1230.559|3.6|discussion rallying uh
1232.559|3.36|started about this uh it's like
1234.159|4.081|ignorization or it's
1235.919|4.401|memorizing the data in pre-training data
1238.24|3.679|set so i know in the language side
1240.32|4.16|there's a quite interesting phenomenon
1241.919|4.321|that you can pre-train on a synthetic
1244.48|3.76|language that's
1246.24|4.0|uh it doesn't have any symmetric meaning
1248.24|3.76|but they only have structural like you
1250.24|4.24|know like paired premises or things like
1252.0|3.52|that and that actually gives you almost
1254.48|3.6|the same
1255.52|5.84|boost in your downstream transfer as a
1258.08|4.8|normal per training so uh i wonder if
1261.36|3.04|say like so in
1262.88|3.76|this means like in for language right
1264.4|4.24|the structure seems to makes a lot of
1266.64|3.84|contribution which can be replaced by
1268.64|3.84|translation but i don't know if this
1270.48|4.36|image is a different case maybe have
1272.48|4.4|people done maybe some
1274.84|3.8|synthetic uh pre-training this every
1276.88|4.4|image
1278.64|4.8|there was a paper i forgot the name and
1281.28|4.16|the authors but it creates completely
1283.44|4.0|synthetic images and like not even
1285.44|3.44|rendering of some realistic things but
1287.44|4.4|just completely
1288.88|5.36|patterns waves and shapes and so on and
1291.84|4.48|uses that for pre-training and then it
1294.24|3.84|shows that they get almost the same
1296.32|2.8|performance as image networking they
1298.08|3.36|actually do this with vision
1299.12|3.6|transformers
1301.44|3.76|but
1302.72|3.839|yeah they never go further or it's not
1305.2|3.359|here you know they they kind of show
1306.559|3.12|that you can almost get to this point
1308.559|3.6|here
1309.679|5.12|and then it's not clear how much further
1312.159|4.961|can you go with it and i think probably
1314.799|3.601|not much further
1317.12|5.12|but it's just me guessing they're not
1318.4|3.84|much for i don't have evidence for it
1323.28|4.0|all right uh so i have one question and
1324.799|4.401|then we can continue with the talk uh
1327.28|3.12|sad that uh you think like the large
1329.2|2.56|vision models are like learning some
1330.4|2.72|sort of similarity
1331.76|2.56|the data that they're trained on so do
1333.12|4.64|you think that they are like behaving
1334.32|5.44|like prototypical networks in a sense
1337.76|3.76|they're behaving like what networks oh
1339.76|3.279|so like prototypical networks
1341.52|3.279|essentially like uh when you're like
1343.039|5.041|doing like few short learning you just
1344.799|3.281|say like i'm going to learn a network
1348.159|2.321|space
1353.039|4.681|probably not exactly but close-ish
1359.039|4.801|i mean i cannot really say because this
1361.039|4.161|is just some intuitive guess that i have
1363.84|2.64|that's what they do but nobody really
1365.2|2.08|knows what to do
1366.48|3.04|right
1367.28|2.24|um
1369.76|3.2|yeah
1370.88|3.84|i mean we do get much when we do
1372.96|3.04|something like prototypical networks for
1374.72|4.079|the future learning with these
1376.0|4.799|pre-trained models we do get more worse
1378.799|4.961|performance than when we do fine tuning
1380.799|4.88|so there is a bit more to it
1383.76|5.279|however i don't know
1385.679|4.961|what is this more
1389.039|4.801|okay thanks
1390.64|3.2|all right let's continue
1395.52|3.68|okay um
1397.12|4.24|yeah so
1399.2|4.24|all right and i didn't mention but like
1401.36|4.799|on imagenet which is the top benchmark
1403.44|4.96|in computer vision uh this with this
1406.159|4.64|work with the big transfer we finally
1408.4|4.48|were able to increase the score after
1410.799|4.24|there was like a long period of a couple
1412.88|4.159|years of no improvement but many
1415.039|4.88|attempts that you see the greatest thing
1417.039|5.281|this was yay awesome uh pre-training
1419.919|3.36|scaling up everything and leveraging the
1422.32|3.12|data
1423.279|3.201|uh and then okay let's not care about
1425.44|2.0|that
1426.48|2.96|uh
1427.44|4.16|yeah that's
1429.44|4.08|okay this is just a little aside that if
1431.6|3.84|we are in the setting that i mentioned
1433.52|4.56|of pre-turning on huge amounts of data
1435.44|4.32|and then testing on many other tasks you
1438.08|4.24|should of course be careful that you
1439.76|4.799|don't have images from the other tasks
1442.32|4.56|in your pre-training data right
1444.559|3.921|um otherwise you have seen them during
1446.88|3.12|training and then you're not really
1448.48|3.199|generalizing and you're just pulling
1450.0|4.0|yourself with good scores
1451.679|4.161|um and this is a real danger when we get
1454.0|3.919|huge amounts of data because like
1455.84|4.319|immediate images can totally be in huge
1457.919|3.601|amounts of data right so we actually use
1460.159|3.601|the
1461.52|4.08|internal pipeline that is really good at
1463.76|3.919|finding duplicates and also near
1465.6|4.16|duplicates like when they are shifted
1467.679|4.48|rotated squeezed color changed a bit
1469.76|5.039|what not this it still finds it and we
1472.159|4.721|use this to completely remove all images
1474.799|4.401|from the test datasets that we test on
1476.88|4.56|later and we actually found that a lot
1479.2|4.0|of classic just vision data sets have
1481.44|3.359|clear duplicates between their training
1483.2|3.76|and validation set
1484.799|5.841|between the training set of imagenet and
1486.96|5.68|c bar 10 100 test sets and so on
1490.64|4.32|uh so new duplicates are quite
1492.64|3.76|widespread problem i envision and this
1494.96|3.76|slide is just to say hey there are
1496.4|3.759|problems but in all that we present we
1498.72|3.76|actually took care of that in the
1500.159|4.481|pre-training as best as we can we don't
1502.48|3.36|have near-duplicates
1504.64|2.639|um
1505.84|3.839|right now back to
1507.279|4.4|being like hey we figured out large data
1509.679|3.161|a larger model and then things get
1511.679|3.841|really good
1512.84|4.839|um and that's how we got to transformers
1515.52|4.0|basically in computer vision everything
1517.679|2.721|was convolutional networks for many
1519.52|3.12|years
1520.4|3.92|uh and basically there was nothing else
1522.64|2.96|in this key
1524.32|3.28|however in language we saw a
1525.6|4.16|transformation recently right that
1527.6|4.559|everything used to be lstm everywhere
1529.76|4.32|lstm was key and then came the
1532.159|4.0|transformer and in the case when there
1534.08|5.12|is a lot of data available suddenly
1536.159|4.64|transformer worked much better than lstm
1539.2|4.959|for little data that was still not the
1540.799|4.721|case exactly um so what we then thought
1544.159|3.041|is that okay
1545.52|3.759|so we are now in this regime where we
1547.2|4.32|have tons of data and we see benefit
1549.279|4.081|from it can we see even more benefit if
1551.52|3.44|we try also of the transformer
1553.36|3.04|architecture in
1554.96|3.599|vision
1556.4|4.56|and that's basically what we did
1558.559|4.0|uh to be fair there were a few other
1560.96|3.68|attempts that try not transforming
1562.559|4.24|vision before that i don't want to
1564.64|4.48|detail too much here because i don't
1566.799|4.48|want to like point fingers too much but
1569.12|3.52|they were all not really using
1571.279|3.681|transformers
1572.64|4.24|for learning everything from the data it
1574.96|4.48|was always like get
1576.88|5.919|something out of a resonate first like
1579.44|4.88|object detection proposals or high level
1582.799|3.521|feature maps or things like that and
1584.32|3.68|then stick a little transformer on top
1586.32|3.839|but we wanted to go like all the way
1588.0|4.24|just transformer everything
1590.159|4.64|and so we came up with the simplest and
1592.24|4.72|most natural i believe way of applying
1594.799|4.721|transformers to vision which is you take
1596.96|5.04|the image you cut it into pieces and
1599.52|4.639|that's it like a puzzle uh
1602.0|5.44|patches uh
1604.159|5.52|and that's it each of these patches you
1607.44|4.08|take it and you project it into your
1609.679|4.081|embedding space which is the input to
1611.52|5.039|the transformer embedding space is just
1613.76|5.039|abstract space of let's say 768
1616.559|4.161|dimensions for example how do you embed
1618.799|4.161|it you just take the pixel values and
1620.72|3.68|put the linear projector projection
1622.96|4.48|layer on top so
1624.4|5.6|take all the pixels flatten the vector
1627.44|4.719|matrix multiply into whatever size you
1630.0|3.6|want and use the same matrix for other
1632.159|2.241|patches
1633.6|2.72|um
1634.4|3.759|and here we just went the simplest way
1636.32|4.079|ever with non-overlapping patches and
1638.159|4.161|everything you can and the people later
1640.399|3.76|did go on and like
1642.32|3.68|say hey this is almost a convolution
1644.159|4.321|let's make proper convolution let's make
1646.0|4.559|stack of them or not but this is our web
1648.48|3.919|work later this is just the simplest way
1650.559|3.84|to do it first
1652.399|5.121|then we have these embedded patches and
1654.399|6.561|we treat them exactly literally like the
1657.52|6.0|word or the tokens in language and
1660.96|5.36|then give them to exactly the birth
1663.52|5.759|transformer from language voice and just
1666.32|4.64|like in language we add this class token
1669.279|3.52|or i think a language is like end of
1670.96|2.88|sentence token or something
1672.799|3.521|um
1673.84|4.24|and we add the position embedding
1676.32|3.52|embeddings to the tokens that can be
1678.08|3.12|learned
1679.84|4.48|and then we feed all of this to a
1681.2|5.92|transformer encoder which has a mlp head
1684.32|4.0|which reads out this class token
1687.12|3.039|and then
1688.32|4.239|maps it to softmax layer for
1690.159|4.081|classification for example
1692.559|3.441|and that's it that is the vision
1694.24|4.24|transformer so it's literally you take
1696.0|6.399|birth transformer but instead of
1698.48|6.72|words or sentence tokens fit in patches
1702.399|5.201|transform this into tokens and that's it
1705.2|5.12|and then just same story as before scale
1707.6|4.64|everything up compute data set model
1710.32|4.56|size patients everything
1712.24|3.439|and see what happens is this good or not
1714.88|2.24|uh
1715.679|3.841|that was the question
1717.12|4.64|and now we can see a plot here this is
1719.52|4.48|similar plot as before
1721.76|4.56|the gray area is actually what were all
1724.0|4.559|of the bit dots before
1726.32|4.56|and now the bubbles are vision
1728.559|4.641|transformers of different sizes
1730.88|4.159|and the bubbler is kind of the size of
1733.2|4.32|the model although it's a bit hard to
1735.039|4.24|say exactly and what you can see first
1737.52|3.759|is that with literal data image that is
1739.279|4.961|the 1.3 million images
1741.279|4.4|it works worse than resonance so if we
1744.24|3.52|would not believe in this idea and just
1745.679|4.081|try this right okay this is a crap idea
1747.76|3.6|and 1.3 million images it's not that
1749.76|3.2|later
1751.36|3.36|then the 10 times larger data state
1752.96|4.959|started like in the same ballpark as a
1754.72|6.16|resonate and when we go to much larger
1757.919|4.721|data with a much larger transformer then
1760.88|4.08|we actually start out performing this
1762.64|4.48|resume and we outperform it just by
1764.96|4.4|later but this resonate was really hard
1767.12|3.12|to get and is extremely clumsy and slow
1769.36|3.12|and big
1770.24|3.439|so we were very excited by this
1772.48|2.88|um
1773.679|3.921|now we did more controlled studies and
1775.36|5.039|everything and one of them is like using
1777.6|4.959|subset of the same data set and there is
1780.399|5.121|lots of curves but basically just look
1782.559|6.561|at the dark gray one and the light blue
1785.52|5.279|one these are roughly similarly fast and
1789.12|4.08|clumsy or
1790.799|4.561|easy to use or difficult to use a bit
1793.2|4.24|which is a resnet variant and with
1795.36|3.679|division transformer and what you can
1797.44|5.119|see vision transformer when we have
1799.039|6.0|little in quotes little data is really
1802.559|4.801|bad compared to resonance but as we
1805.039|4.161|start having a lot of data actually it
1807.36|3.76|starts out performing the resume and
1809.2|3.92|this is very promising because i think
1811.12|4.48|like everything that looks huge and a
1813.12|4.72|lot and so on now in five or ten years
1815.6|4.88|it's maybe regular like 10 years ago
1817.84|5.52|imagenet this one seemed to be huge and
1820.48|4.72|massive amount of data not anymore
1823.36|4.559|so we should look to the future and this
1825.2|4.8|looks promising for the future
1827.919|5.041|then back to the same benchmark that was
1830.0|2.96|another little jump
1842.57|3.989|[Music]
1845.2|5.12|in that order if you want to mute
1846.559|6.24|yourself and ask the questions
1850.32|4.32|sure yeah i think uh devil already
1852.799|3.921|answered part of the question but i was
1854.64|3.6|wondering in the input to the
1856.72|4.0|transformer when you're chunking up the
1858.24|3.2|image into uh little puzzle pieces and
1860.72|3.6|then
1861.44|5.52|um finding them does the order of
1864.32|4.479|feeding these patches in matter like if
1866.96|4.48|you switch the order
1868.799|4.961|does the prediction maybe change
1871.44|4.16|yeah that's a good question and i
1873.76|4.88|actually have a slide on something like
1875.6|5.76|this but not not exactly um
1878.64|4.48|let me jump there so first of all if the
1881.36|4.0|order is consistent
1883.12|4.159|uh during training right and you you
1885.36|4.559|don't shuffle the order again for each
1887.279|4.0|new image then it's literally the exact
1889.919|3.041|same you get the same curve same
1891.279|4.161|everything because we don't encode the
1892.96|4.4|order anyway if you start randomizing
1895.44|3.599|the order all the time during training
1897.36|4.319|then performance gets quite a lot of
1899.039|4.721|words and let me show you why this is
1901.679|4.401|the uh the slide was on my plan to
1903.76|4.72|present anyways then if you ask about it
1906.08|5.36|let's jump here these are this
1908.48|4.559|visualization of the position embeddings
1911.44|4.64|uh what does it mean so in this case we
1913.039|5.441|had 14 by 14 patches that we cut the
1916.08|4.0|image in so it means we have also 14 by
1918.48|3.439|14
1920.08|3.92|position embeddings although we just see
1921.919|2.961|them as one long sequence of what is it
1924.0|3.279|hundred
1924.88|4.72|fifty something or i don't know already
1927.279|4.481|something um
1929.6|4.4|and now each of these pictures shows the
1931.76|3.519|position embedding which corresponds to
1934.0|3.279|this location
1935.279|3.921|how similar is it to all the other
1937.279|4.081|position embeddings so let's look at
1939.2|4.4|this one for example yellow means
1941.36|4.319|perfectly similar like exactly the same
1943.6|3.679|and blue means opposite in terms of
1945.679|3.681|cosine similarity
1947.279|4.24|so this position embedding is most
1949.36|4.559|similar to itself which is the pixel
1951.519|4.64|here and then the neighboring pixels is
1953.919|5.12|how similar is it to the position
1956.159|4.321|embeddings that correspond originally to
1959.039|3.441|the neighboring patch
1960.48|4.16|and we do see a very clear pattern that
1962.48|4.319|each position embedding is very similar
1964.64|3.36|to the embedding from its surrounding
1966.799|2.161|patches
1968.0|3.36|and
1968.96|4.0|we didn't implement any of this
1971.36|3.199|all right we just had this position
1972.96|4.24|embeddings at randomly initialized
1974.559|4.161|variables and they are learned as freely
1977.2|3.68|as the rest of the parameters of the
1978.72|4.48|mother but they learn to recover this
1980.88|3.519|notion of what are my neighbor patches
1983.2|3.599|even though we don't give this
1984.399|4.16|information anywhere at any time besides
1986.799|3.921|the raw image data and the task to
1988.559|3.6|please classify this image
1990.72|3.12|um
1992.159|3.12|so that's pretty cool i think but it
1993.84|4.319|also means that if you take the trained
1995.279|4.561|model now and give in
1998.159|3.681|patches in a completely differently
1999.84|4.4|shuffled order it's going to perform
2001.84|4.48|poorly because this learned position and
2004.24|5.039|values don't make sense anymore
2006.32|5.199|we did try also to implement like
2009.279|5.361|position embeddings which encode the
2011.519|4.561|location as hard coded by us
2014.64|3.36|um and
2016.08|3.36|other fancy position embeddings like
2018.0|3.2|relative ones
2019.44|3.839|but basically none of that really
2021.2|3.44|outperformed these freely learned and
2023.279|3.361|then the three you learn this thing like
2024.64|4.159|you just random image let it learn as
2026.64|6.36|part of sgd and that's it and so we go
2028.799|4.201|with that and suggest doing that
2033.36|5.439|nice it's awesome
2034.799|6.081|okay we have one more question from
2038.799|3.921|hey yeah i was really good yeah this
2040.88|3.36|slide um i think something that's really
2042.72|3.36|interesting is we're talking about
2044.24|2.72|scaling up the data and scaling the
2046.08|1.999|moment
2046.96|3.199|as well
2048.079|3.84|but it seems like you're reaching and
2050.159|3.121|passing joke right when you keep doing
2051.919|3.601|this thing
2053.28|3.92|so i'm curious if you have any thoughts
2055.52|3.359|on that like is that or these points
2057.2|4.639|just look like that or is there kind of
2058.879|2.96|a
2067.359|4.161|yeah i have another slide but much
2069.599|6.161|further in the talk about that
2071.52|6.639|um where i would like to not jump on it
2075.76|4.96|if you don't mind and then maybe in
2078.159|3.92|10-15 minutes we will be there
2080.72|3.6|okay yes
2082.079|2.241|um
2084.48|4.24|yeah but maybe to be a bit optimistic it
2086.639|3.681|does seem like the transformers have a
2088.72|4.639|better slope here in the end and there
2090.32|3.039|is next plateau earlier
2093.679|3.121|sorry lucas i didn't mean did not mean
2095.52|3.68|to interrupt
2096.8|4.64|are there any questions before we
2099.2|4.08|listen yeah can i ask my question real
2101.44|3.28|quick sorry about that so what i'm
2103.28|4.079|curious to know is
2104.72|5.6|how does this vit compare to if you
2107.359|5.841|equip a conv net so for example resnet
2110.32|4.24|with an attention mechanism
2113.2|2.72|like how much of this is due to the
2114.56|3.2|structure of a transformer and the
2115.92|3.679|particular way it operates versus just a
2117.76|4.16|benefit of attention that a vanilla
2119.599|5.281|confinet does not have access to
2121.92|5.04|yeah so this is many this has been tried
2124.88|4.56|many times before and the first time
2126.96|5.44|that i know of was actually from
2129.44|5.2|a mispronounced his name but
2132.4|4.16|the inventor of resnet and some of his
2134.64|3.439|colleagues they called it non-local
2136.56|2.96|networks this was
2138.079|4.561|i think even before the transformer
2139.52|4.96|paper if i remember correctly
2142.64|3.6|and they basically inserted attention
2144.48|3.2|blocks at various locations in the
2146.24|3.28|resonant and then they showed
2147.68|3.919|improvement but it was like tiny
2149.52|4.48|improvements that are it was a cool
2151.599|5.921|block in the simple paper but it was not
2154.0|5.28|really worth it and if people usually
2157.52|2.88|place their attention
2159.28|2.88|you can imagine if you place the
2160.4|4.959|attention just on the pixels and don't
2162.16|5.04|do this patch cutting this is way too
2165.359|3.441|expensive computation right right if you
2167.2|2.639|have two to four by two to four pixels
2168.8|2.64|that's like
2169.839|4.401|yeah i cannot do this in my head i don't
2171.44|4.8|know 40 000 or so maybe pixels
2174.24|4.24|attending 240 000 others that doesn't
2176.24|3.92|work so people just do it in the very
2178.48|2.96|high and very finer layers of the
2180.16|3.919|resonance like
2181.44|4.48|where it's maybe seven by seven and then
2184.079|3.76|they add a bit of sprinkle a bit of
2185.92|3.84|attention there but then you don't
2187.839|3.28|really get much benefit of scaling
2189.76|2.48|because it's essentially still a
2191.119|2.081|resonant
2192.24|3.28|and
2193.2|4.639|there is in resonance there is this
2195.52|5.04|block called squeeze excite that has
2197.839|4.881|been getting really or has gotten really
2200.56|3.279|popular and improves the resonance quite
2202.72|3.2|a bit
2203.839|4.721|and that is also kind of a form of
2205.92|4.56|attention um but like nicely tailored to
2208.56|4.32|images
2210.48|4.56|and not really it's arguable
2212.88|4.88|um but yeah it has been tried many times
2215.04|5.28|before but it just it doesn't show or it
2217.76|5.359|hasn't been shown to have this scaling
2220.32|4.0|benefit as much as the bit
2223.119|3.121|so i think i'm missing something
2224.32|4.24|critical here which is you just said
2226.24|4.0|contract or it's computationally
2228.56|3.44|difficult
2230.24|3.76|attentionally at a low level in the res
2232.0|3.76|net but why is it any different than
2234.0|3.68|doing an attention layer in the vision
2235.76|4.4|transformer
2237.68|5.36|because we we cut the patches first so
2240.16|5.76|we have maybe 14 by 14 patches which is
2243.04|2.88|not that much
2246.16|2.88|okay
2247.28|4.079|but i'm confused like
2249.04|3.84|you could imagine not at a high level
2251.359|3.121|not at a high layer in the resonant but
2252.88|3.12|at a relatively good layer after you've
2254.48|2.72|applied like one or two convolutional
2256.0|3.2|filters
2257.2|3.44|to uh convolutional layers excuse me
2259.2|3.68|then you have something
2260.64|5.12|besides the patches
2262.88|5.36|uh that's still 50 by 50 at the early
2265.76|3.839|layers and that's but 50 by 50 is
2268.24|3.92|significantly less than i don't know
2269.599|5.76|like 400 by 400 or whatever
2272.16|5.6|but it's still 2 500 tokens attending 2
2275.359|3.841|2 500 tokens which yeah i mean it's a
2277.76|3.04|lot but it's not
2279.2|3.919|comparable
2280.8|4.72|i don't know okay cool thank you yeah i
2283.119|4.24|mean it could be tried okay maybe
2285.52|3.92|another answer to your question is then
2287.359|2.881|we're slowly getting to this my next
2289.44|3.6|slide
2290.24|5.28|after the set of questions um
2293.04|5.92|where we do try something almost like
2295.52|5.52|what you said um have a very small part
2298.96|3.04|of the resonant and then stick
2301.04|2.96|a
2302.0|4.24|transformer on top of it but like the
2304.0|4.72|full transformer encoder on top of it
2306.24|5.68|and not just sprinkle a few attention
2308.72|5.119|layers and then continue with and so on
2311.92|4.0|and this is this process
2313.839|3.601|and we call them hybrid but that's
2315.92|3.04|almost literally what you said actually
2317.44|4.08|like a few early layers from the
2318.96|4.08|resonance and with different varying
2321.52|3.92|amount and then stick it therefore
2323.04|3.84|transforming quarter
2325.44|3.28|and this
2326.88|2.88|seems to work right too especially for
2328.72|3.28|the
2329.76|4.4|uh when you exactly in this case is
2332.0|4.4|amount of compute so for the little
2334.16|3.679|compute it seems to work well but then
2336.4|3.04|the scaling behavior of the pure
2337.839|3.841|resonate is a little better so we
2339.44|4.0|focused on that i think we later tried
2341.68|3.76|also hybrid further to the right and it
2343.44|3.679|was a bit lower but it was after the
2345.44|3.6|paper so it's not on this plot which i
2347.119|5.041|just cut out of the paper but you can
2349.04|3.12|already see the trend here
2352.72|4.639|yeah so if you don't scale all the way
2355.119|4.161|up then this is a totally reasonable
2357.359|4.961|thing to do have a little bit of
2359.28|5.68|resonance and then that the encoder from
2362.32|2.64|transformer
2366.32|5.6|do you want to ask your question
2368.64|3.92|uh yeah i was uh just wondering about
2371.92|2.8|the
2372.56|3.68|um basically there's like a like a short
2374.72|3.68|section in the paper about like fine
2376.24|4.24|tuning and like higher resolution and in
2378.4|4.32|that case right like the pre-trained
2380.48|3.04|like position invaded embeddings sorry
2382.72|3.2|um
2383.52|3.92|are like uh skewed right and then it
2385.92|4.08|basically says that you guys are like
2387.44|4.0|interpolating can you like talk like a
2390.0|4.32|little bit like how do you interpolate
2391.44|4.48|what's going on yeah actually when when
2394.32|5.519|i checked the slides earlier today i was
2395.92|3.919|like ah we could have a slide on that
2400.24|3.2|and we don't have a nice visualization
2401.92|3.28|in the paper either because it's a bit
2403.44|3.6|difficult to explain but this is the
2405.2|4.08|best starting
2407.04|4.16|point we have so if you want to increase
2409.28|4.16|the resolution of the image
2411.2|4.159|means and you keep the patch size fixed
2413.44|3.679|it means you have more patches suddenly
2415.359|4.0|right and then as you say the fashion
2417.119|2.96|embeddings like how what do you even use
2419.359|2.48|as
2420.079|2.641|position embeddings right
2421.839|3.361|um
2422.72|4.16|and basically you can see here that we
2425.2|3.2|see that they learn a very regular
2426.88|3.28|structure right we don't really know
2428.4|3.84|what is the structure of this position
2430.16|4.0|embedding the color we just see the
2432.24|3.839|similarity to each other and that it is
2434.16|3.84|very very regular
2436.079|4.721|and so this gave us the intuition that
2438.0|5.839|we may be able to just take them
2440.8|5.68|um kind of imagine these boxes they
2443.839|4.401|slide apart and new boxes appear between
2446.48|3.44|them and they are just the interpolation
2448.24|4.16|of the surrounding ones
2449.92|4.56|and that's basically what we do with the
2452.4|4.56|position and paddings
2454.48|4.72|we create new ones where there are
2456.96|3.04|missing ones because we need more
2459.2|3.28|um
2460.0|5.359|and by interpolating the surrounding or
2462.48|6.56|more precisely we basically see them as
2465.359|5.281|a picture in this case 14 by 14 with 700
2469.04|4.24|something channels or whatever is the
2470.64|4.64|dimensionality and then we basically
2473.28|5.6|resize this like you would resize a
2475.28|6.0|picture by by linear interpolation
2478.88|3.84|and that way we get more and new
2481.28|2.96|position embeddings that we don't
2482.72|3.04|understand where they are but they
2484.24|3.92|follow the same pattern as the learned
2485.76|5.92|ones just as
2488.16|3.52|at a higher resolution basically
2516.8|2.08|yeah
2517.68|3.2|there were
2518.88|5.04|quite a few words they tried varying
2520.88|5.28|other things um one that i especially
2523.92|4.8|liked recently it's called early
2526.16|4.64|convolutions hair transformers c better
2528.72|3.52|or something like that and they
2530.8|3.76|basically say okay instead of this
2532.24|5.599|linear projection instead of this one
2534.56|5.519|big linear projection we replace it by a
2537.839|3.921|stack of three by three convolution with
2540.079|3.121|a stride two
2541.76|2.72|uh and then they have also
2543.2|3.2|non-linearities between the
2544.48|4.56|normalizations between them
2546.4|5.919|but such that the overall stride is the
2549.04|4.079|same as the patch the this petrify so
2552.319|2.721|the
2553.119|4.0|outcome will then be the same
2555.04|4.24|dimensionality as after this patch
2557.119|3.601|cutting and then projecting and then
2559.28|3.2|they show that
2560.72|3.84|it
2562.48|3.839|supposedly it makes it a bit easier to
2564.56|4.72|optimize in the sense that more
2566.319|3.841|optimizer settings are good settings
2569.28|4.24|um
2570.16|6.48|in many scenarios it performs the same
2573.52|5.68|but like more robustly to get there
2576.64|4.88|and they also show some scenarios where
2579.2|5.2|this performs much better
2581.52|5.28|uh like for example when pre-training on
2584.4|4.959|actually when they pretend on more data
2586.8|3.84|that seems to perform even better
2589.359|3.921|um
2590.64|4.64|i have played a bit with it and tried to
2593.28|3.839|reproduce it i don't have it fully
2595.28|3.6|reproduce it but i don't see as much
2597.119|3.441|benefit as in the paper yet
2598.88|4.32|but that's not to say that the paper is
2600.56|3.759|wrong just that i didn't get there yet
2603.2|3.04|um
2604.319|4.241|that is one example of them there are
2606.24|4.4|other papers that do stuff but this one
2608.56|4.4|i found especially interesting because
2610.64|4.719|it's simple
2612.96|2.399|thank you
2615.839|2.721|all right
2617.04|3.279|continue we don't have any more
2618.56|4.64|questions
2620.319|4.561|all right then let's see yeah i have
2623.2|3.84|like three more interesting details from
2624.88|3.84|the paper and then
2627.04|3.52|depending on if you want more discussion
2628.72|4.16|or more content i have more content like
2630.56|4.96|also the question about does it saturate
2632.88|4.4|here or not um
2635.52|3.36|all right so another interesting thing
2637.28|4.0|that we had in the paper but it is
2638.88|3.28|buried in the appendix um
2641.28|2.559|and then
2642.16|4.4|follow-up papers from others have been
2643.839|5.921|written on this by now actually is like
2646.56|5.6|how should we scale these transformers
2649.76|4.079|right in the
2652.16|4.32|high level shape of the transformer
2653.839|4.961|there's lots of settings that you could
2656.48|4.0|choose um and we actually tried many of
2658.8|3.6|them so we started with the like
2660.48|4.24|reasonable medium size transformer it is
2662.4|5.28|not in the middle and then we vary
2664.72|6.16|things one by one
2667.68|5.439|such that we always double the compute
2670.88|3.92|so for example this pink line if we go
2673.119|3.441|to the right this point
2674.8|4.16|increases the width
2676.56|4.96|such that we double the compute
2678.96|5.92|x axis is compute
2681.52|4.64|relative to this starting point and we
2684.88|3.92|have all of these different settings
2686.16|4.8|there's the width which is the how wide
2688.8|4.319|is are the vectors with which say
2690.96|4.96|attention is done which is for the base
2693.119|3.921|model 768 and then it goes larger or
2695.92|2.399|smaller
2697.04|3.76|um
2698.319|4.961|that is like meh as you see scaling this
2700.8|4.0|does not seem promising so we didn't
2703.28|3.12|scale that much
2704.8|3.84|uh then there's other things like the
2706.4|4.08|width of the multi-layer perceptron and
2708.64|4.4|or some people call it the one-by-one
2710.48|5.04|convolution in these attentions and this
2713.04|4.88|seems to scale a bit nicer this orange
2715.52|4.72|part i actually wonder where it went to
2717.92|3.919|the left i don't remember
2720.24|3.44|i don't know if it's hidden somewhere or
2721.839|4.0|if you just didn't scale it down but
2723.68|4.639|anyways then another thing to scale
2725.839|4.881|which does not exist in the transformers
2728.319|4.561|from text is the patch size as you make
2730.72|4.08|the patch smaller you get more and more
2732.88|4.88|tokens out of an image
2734.8|4.319|and thus more and more compute capacity
2737.76|3.04|um
2739.119|3.281|this is the green one which also seems
2740.8|2.48|to scale nicely
2742.4|2.48|um
2743.28|3.52|then the depth is an interesting one
2744.88|3.52|this yellow one and this is the number
2746.8|3.68|of encoder blocks
2748.4|3.439|as we scale it first seems like wow this
2750.48|3.839|is the thing you want to escape but then
2751.839|5.361|it does seem to plateau and it scales
2754.319|4.561|really badly if you decrease the depth
2757.2|3.2|so that's not a good thing to decrease
2758.88|2.959|however the width seems to be a good
2760.4|3.679|thing to decrease if you want to go to
2761.839|4.801|smaller models and then the blue is just
2764.079|4.881|scaling everything together such that
2766.64|5.12|the compute is kept like everything by
2768.96|6.32|roughly the same one that seems to scale
2771.76|4.8|nicely as well as the rest and this is
2775.28|2.96|relatively simple or at least
2776.56|3.519|conceptually so we like this so we went
2778.24|3.28|with that whenever we scale up or down
2780.079|3.201|the model
2781.52|3.599|um
2783.28|4.4|and this i one i really like is the
2785.119|4.561|inference speed because if you have the
2787.68|3.04|image size of two to four pixels it
2789.68|3.04|actually means you have two two four
2790.72|5.04|bytes to do four pixels right so if you
2792.72|6.0|have uh let's then you petrify it with a
2795.76|5.04|16 by 16 patch for example patch size
2798.72|4.56|then you have
2800.8|5.84|14 by 14 patches so that's the sequence
2803.28|5.12|length is actually 150 right and then
2806.64|3.76|on top of the sequence length you have
2808.4|4.8|the set attention operation which is
2810.4|4.32|square again so overall with the image
2813.2|4.08|with respect to image size the
2814.72|4.56|self-attention operation is uh to the
2817.28|3.039|fourth power what's it called
2819.28|2.079|quartic
2820.319|3.681|um
2821.359|4.641|so that is really bad like everybody who
2824.0|3.359|sees oh of something to the fourth is
2826.0|2.88|like what the hell are you doing this is
2827.359|4.401|never gonna escape
2828.88|5.04|um so we checked what does it look like
2831.76|4.319|in practice with the image sizes that we
2833.92|4.32|operate in and this is what you see here
2836.079|4.641|on the y-axis is the
2838.24|5.119|how fast it goes basically how fast it
2840.72|5.04|does inference and on the x-axis is
2843.359|3.2|varying the input size
2845.76|2.96|and
2846.559|4.081|this
2848.72|2.96|what this means it doesn't look so bad
2850.64|3.6|yet
2851.68|4.48|basically when you go here to the 512 to
2854.24|4.56|the real argument then you see that the
2856.16|5.12|transformers actually start going down a
2858.8|3.92|lot more than the
2861.28|3.36|resonance
2862.72|4.48|but in this reasonable image size let's
2864.64|4.88|call it a typical it doesn't seem so bad
2867.2|4.72|in practice yet so we're not getting hit
2869.52|4.48|by the very big o
2871.92|3.28|but as we go larger it will likely be a
2874.0|3.44|problem and there have been a lot of
2875.2|4.0|follow-up works trying to make that
2877.44|2.639|better right
2879.2|2.24|um
2880.079|3.601|right
2881.44|2.24|then
2884.48|4.48|this is the last one from the original
2886.319|4.961|bit paper um this is looking at the
2888.96|4.32|inputs receptive field size so in the
2891.28|3.68|self attention operation
2893.28|4.559|how far ago
2894.96|5.599|do heads typically attend
2897.839|4.561|and here on the x-axis we see the layer
2900.559|3.601|in the network to the right is more
2902.4|3.919|towards the output the classes and to
2904.16|3.439|the left is more towards the input the
2906.319|4.481|patches
2907.599|5.921|and the y-axis is how far on average
2910.8|4.799|across i think the whole validation set
2913.52|5.039|does the self attention look and does
2915.599|5.601|look means that the peak of the set
2918.559|4.0|attention or the max how far is it away
2921.2|2.8|something like that
2922.559|3.361|um
2924.0|3.04|and each dot is a different head because
2925.92|2.48|we can use multi head safe
2927.04|3.12|self-attention right
2928.4|3.679|and so what this shows is that in the
2930.16|4.0|early layers actually you have some
2932.079|4.801|heads that go look far but also a lot of
2934.16|5.28|heads that look very nearby them so
2936.88|4.959|locally and as we go deeper in the model
2939.44|4.08|we only are left with heads that on
2941.839|3.52|average look further
2943.52|3.76|so
2945.359|4.081|it's just some kind of analysis there is
2947.28|3.68|not immediately action to take about
2949.44|3.04|this but it's interesting to see that
2950.96|4.32|earlier layers
2952.48|4.56|they learn a mixture of looking
2955.28|4.0|to a local neighborhood and looking
2957.04|4.64|globally and later layers only look
2959.28|2.4|globally
2962.559|4.721|right
2964.16|4.8|so that is about the original
2967.28|3.2|vision transformers
2968.96|2.8|um
2970.48|2.96|no
2971.76|4.319|i don't know how long we want me to
2973.44|5.2|continue speaking or discussing i have a
2976.079|4.641|couple of options that i can talk about
2978.64|4.16|which is one project that was further
2980.72|3.839|scaling up bits and this one also has
2982.8|2.96|the answer to the i can also jump
2984.559|3.201|straight to the answer if you don't want
2985.76|3.839|to hear the rest but to the question of
2987.76|3.599|like what's how does it continue to the
2989.599|2.96|right are we separating
2991.359|3.281|um
2992.559|4.321|there is another project about how to
2994.64|4.16|train vision transformers when you don't
2996.88|3.76|have massive amounts of data can you
2998.8|4.0|still do it is it reasonable or is it
3000.64|4.24|maybe just unreasonable to do
3002.8|4.4|uh this one is maybe too unrelated let's
3004.88|4.16|not talk about this and
3007.2|3.44|the last one is like i talk all about
3009.04|3.519|these benefits of
3010.64|3.84|a really large model when you pre-train
3012.559|4.241|them on lots of data okay that's nice
3014.48|4.639|that's how we get a good model
3016.8|4.559|but then actually using a model that is
3019.119|4.48|massive is not fun at all like it
3021.359|5.121|doesn't fit on your gpu you need like
3023.599|5.52|multiple tp used to even use it so
3026.48|5.359|people are not happy to use it and
3029.119|4.48|usually still go back to smallish models
3031.839|5.841|even though they know like larger models
3033.599|6.081|should be better what can we do about it
3037.68|3.76|that's another project we had which is
3039.68|3.04|about distillation
3041.44|3.919|so
3042.72|4.32|i would say it's up to you guys what you
3045.359|2.96|prefer to do or if you have plenty of
3047.04|2.96|questions we can continue with the
3048.319|4.641|questions now because i think now the
3050.0|3.839|original one hour would be over
3052.96|2.48|right right
3053.839|2.961|i think one suggestion was like we can
3055.44|2.879|continue the talk
3056.8|3.36|and uh we will also be recording it so
3058.319|3.841|people like you can like just like go
3060.16|3.919|and see it if they miss out something
3062.16|3.679|uh so we could do that
3064.079|4.961|yeah the other thing is two people have
3065.839|4.961|their hands raised so we can um okay
3069.04|5.84|questions first
3070.8|4.08|up to you guys and fight right away
3078.559|2.241|um
3080.0|4.48|so
3080.8|3.68|you guys want to ask a question
3084.559|5.441|yeah i just had a pretty basic question
3087.28|4.48|um so if an object lies on the border
3090.0|4.4|between the patches
3091.76|5.12|um does that impact the model's
3094.4|4.8|performance in any way
3096.88|5.04|yeah i mean that's not a basic question
3099.2|2.72|it's a good question
3103.359|4.72|there is a mix of answers
3105.44|4.399|so one is we didn't specifically go and
3108.079|3.601|test this it would be an interesting
3109.839|5.041|thing to test in a very controlled way
3111.68|4.56|with some of the trained models um
3114.88|2.479|that's for sure
3116.24|3.28|um
3117.359|4.081|the other thing is that
3119.52|4.24|when you have a massive data set like
3121.44|5.28|300 million images it's an insane amount
3123.76|5.76|i used to try to conceptualize how much
3126.72|5.44|is imagenet one million images and i
3129.52|5.2|think i did the math is like if you go
3132.16|4.32|through an image and look oh look at all
3134.72|3.28|of the images each image for a couple of
3136.48|3.28|seconds you were sitting there for a
3138.0|3.44|month or something like that don't
3139.76|3.839|remember
3141.44|4.72|but so 300 million is just insanely
3143.599|4.72|massive and then on top of that we do
3146.16|4.64|actually use random augmentations like
3148.319|4.881|random crop out of the image
3150.8|5.2|so i would say it's the default that you
3153.2|5.44|see objects that don't fall on a patch
3156.0|4.72|um during the training already
3158.64|4.479|and if you look at here basically this
3160.72|5.92|is the standard model like how the
3163.119|5.681|patches are when we have 14 14x40 they
3166.64|3.52|look roughly this size also
3168.8|2.24|um
3170.16|3.04|then
3171.04|4.319|an object is usually scattered across
3173.2|4.879|many patches actually
3175.359|4.641|because objects in typical images are
3178.079|3.52|relatively large right people don't take
3180.0|3.599|a picture where the object of interest
3181.599|4.081|is super tiny in the corner
3183.599|3.76|uh so that's the default that you see
3185.68|4.72|during pre-training and so i believe
3187.359|6.161|that the model just learns to do that
3190.4|4.08|much better actually
3193.52|2.64|then the
3194.48|4.879|other answer to the question is like
3196.16|5.6|okay maybe if you did some nicer thing
3199.359|4.321|than this very crude patch cutting like
3201.76|4.0|for example this converse stack of
3203.68|3.439|convolutions that i mentioned maybe this
3205.76|4.079|is even better
3207.119|2.72|um
3210.88|2.32|thank you
3214.64|6.12|all right yeah uh so you mentioned that
3217.76|3.0|um
3225.79|5.659|[Music]
3237.72|3.08|[Music]
3249.68|3.76|um
3251.92|3.04|the audio was not that good but i
3253.44|3.679|believe i understood the question is
3254.96|4.08|that we say that transformer lack
3257.119|4.96|locality uh
3259.04|5.519|bias or prior or whatever and why is
3262.079|4.641|this even something that we want right
3264.559|3.52|uh wouldn't we want our mothers to know
3266.72|3.119|about locality if they are about
3268.079|2.641|pictures in the first place
3269.839|2.321|um
3270.72|3.92|yes and no
3272.16|4.48|uh so this that's why i gave the context
3274.64|5.04|in the beginning this is all about what
3276.64|4.24|happens when you scale things up
3279.68|3.04|and
3280.88|5.679|specifically what
3282.72|4.879|in ideal world at least in our mind
3286.559|3.441|we want
3287.599|4.641|gigantic amounts of data and we believe
3290.0|4.799|that it will just keep growing as the
3292.24|3.68|years go by and there will be more and
3294.799|3.681|more data
3295.92|4.32|uh just generally there
3298.48|4.0|and then we want the model to have as
3300.24|4.4|little of
3302.48|4.319|our thinking built in
3304.64|4.4|because what we may think that is good
3306.799|4.32|to solve the task may actually not be
3309.04|3.12|best to solve the task you know maybe
3311.119|2.641|like uh
3312.16|4.0|analogy would be like
3313.76|4.24|uh what was it alphago that made some
3316.16|3.679|moves that experts would say this is
3318.0|3.76|crazy this is a silly move but it
3319.839|4.321|actually then was much better
3321.76|4.559|uh and in the similar way we want to
3324.16|4.8|encode as little as possible into the
3326.319|4.8|model such that if we just throw massive
3328.96|3.92|amounts of data in the difficult task at
3331.119|3.2|it that we might think things that are
3332.88|3.28|even better that we didn't think of
3334.319|4.641|before
3336.16|5.439|this is our approach because we believe
3338.96|5.28|that like as i mentioned i think
3341.599|4.96|already uh what seems massive and
3344.24|4.48|excessive now will be the norm in five
3346.559|4.881|years or so so that's where we want to
3348.72|3.76|go and look what's the direction
3351.44|3.52|however
3352.48|4.56|uh if you want to like just get
3354.96|3.68|something working now and don't have
3357.04|3.68|massive amounts of data and don't want
3358.64|3.76|to use pre-trained mother for some
3360.72|3.599|reason which
3362.4|4.24|always use a preaching mother
3364.319|4.561|but if you don't want to uh then it
3366.64|4.32|makes total sense to bring in some of
3368.88|4.32|your prior intuition and knowledge of
3370.96|3.89|what should probably help the mother
3373.2|4.76|like locality
3374.85|3.11|[Music]
3383.41|8.35|[Music]
3389.2|4.24|like isn't that sort of
3391.76|4.4|like yeah i don't know
3393.44|4.72|maybe i'm not seeing like
3396.16|4.159|exactly why we do not want those
3398.16|4.72|investments but
3400.319|4.081|you may be elaborate on that why why is
3402.88|6.16|it that we don't want
3404.4|4.64|um like locality or what translation
3410.4|5.84|well ideally we want the mother
3413.44|5.84|that is powerful enough to
3416.24|4.96|learn about this concept itself if it is
3419.28|3.76|useful to solve the task
3421.2|3.52|if it's not useful to solve the task
3423.04|3.92|then
3424.72|6.0|if we hardcode it in there is no way for
3426.96|3.76|the mother not to do this right
3430.88|4.959|that is ideally the outcome and in a
3432.88|4.959|similar way also that in language you
3435.839|4.801|know it seems to be
3437.839|6.24|nonsense to not encode the from left to
3440.64|5.679|right direction of text like in rmns but
3444.079|4.081|then comes transformer and just doesn't
3446.319|5.52|and works much better if you throw a lot
3448.16|6.48|of data at it and it recovers that
3451.839|4.081|plus some more or more flexible variant
3454.64|4.479|of it or something like that that is
3455.92|6.159|even better for serving tasks
3459.119|7.44|so basically the idea being that
3462.079|6.161|we are not as smart to design the thing
3466.559|4.0|the model in the way that will be best
3468.24|4.559|for the task let's rather give it all
3470.559|3.841|the flexibility and all the data needs
3472.799|4.401|to figure out what is the best way of
3474.4|2.8|solving the task
3482.079|4.401|i really this is a philosophy of
3484.88|4.959|approaching it i'm not saying that is
3486.48|3.359|the only true way right
3493.359|4.48|okay uh so we have around seven minutes
3495.92|2.8|left before the scheduled end of the
3497.839|3.121|talk
3498.72|4.48|and lucas we want to be mindful of your
3500.96|3.599|time as well because it's it is evening
3503.2|2.72|where you are
3504.559|3.921|so
3505.92|4.24|one thing we could do is you could i
3508.48|4.0|don't see any more questions right now
3510.16|3.6|so you could quickly sort of go over
3512.48|3.44|the last
3513.76|3.52|maybe skipping through the the details
3515.92|3.12|and just talking about
3517.28|3.44|the final results
3519.04|3.92|i will do these two in the high level
3520.72|4.399|then those two that are still very very
3522.96|3.839|tight to transformers and also some
3525.119|4.24|questions that happened before
3526.799|4.56|like the first question was like okay
3529.359|4.24|are we saturating yes or no
3531.359|2.24|and
3533.839|1.841|here
3534.64|3.28|no
3535.68|4.72|uh this was the width
3537.92|5.04|on this benchmark from the original
3540.4|4.56|transforming paper but then it's like
3542.96|3.28|these transformers when we use them we
3544.96|2.879|just notice they have really nice
3546.24|4.079|scaling properties and they seem
3547.839|4.96|actually to be easier to scale up
3550.319|4.401|without paying massive compute as much
3552.799|3.921|as resonance
3554.72|4.399|just from that feeling from us having
3556.72|4.24|experience with both and so we went and
3559.119|4.72|looked what happens if we
3560.96|4.56|scale vision transformer just as far up
3563.839|4.161|as we possibly can
3565.52|4.72|and we spend quite a lot of our blood
3568.0|5.52|into making this happen
3570.24|5.599|one part of it is scaling the data set
3573.52|5.039|so we went back to this google internal
3575.839|5.361|team that this 300 million data set is
3578.559|4.321|just one out of many that they work with
3581.2|3.599|and we asked the round and they
3582.88|4.4|basically had the three billion like ten
3584.799|5.441|times larger data set that we could also
3587.28|4.96|like play around with so there we go we
3590.24|3.359|want to scale up the data set
3592.24|3.04|and
3593.599|3.361|it's just showing yes just scaling up
3595.28|4.96|the data set and switching it gives you
3596.96|5.76|benefits but that's not all of it then
3600.24|5.2|the next thing is we needed to figure
3602.72|4.879|out how to use less memory on device
3605.44|4.399|like on gpu or tpu
3607.599|4.561|because already previously with this
3609.839|4.881|score we fitted the model as much as we
3612.16|5.12|could click so we did a lot of tricks
3614.72|5.839|that i will skip for now and are able to
3617.28|5.44|stay much larger this is like
3620.559|4.081|this plot shows the size of the model in
3622.72|3.359|the different shape factors that i
3624.64|3.919|mentioned before like the width of the
3626.079|4.161|mrp on x-axis the surf attention width
3628.559|4.161|on the y-axis and then the different
3630.24|4.879|plots are different layers for the depth
3632.72|4.96|these blocks are how much how large a
3635.119|4.881|transformer we did in the original paper
3637.68|5.2|and then boom one step further and two
3640.0|5.839|steps further this is just super massive
3642.88|5.199|transformer we did in this uh scaling
3645.839|5.201|uh paper and with all of our tricks from
3648.079|5.28|how much larger we could go a lot louder
3651.04|4.0|um then yeah some learning rate stuff
3653.359|3.44|and it is really cool i recommend people
3655.04|3.84|to look at square with learning rate
3656.799|5.201|schedule which is cool and often just
3658.88|3.12|mentioned as a side note
3662.24|3.359|it is also cool but i'm gonna skip it
3664.24|4.8|for the interest
3665.599|5.921|and basic interest of time and
3669.04|5.2|basically we scale it up a lot and of
3671.52|6.24|course again we get uh always this
3674.24|5.119|envision imagenet uh number a bit higher
3677.76|2.96|this is actually plus two percent on
3679.359|3.76|what we had before which is very
3680.72|4.079|significant in this high percentage
3683.119|3.921|range there
3684.799|3.601|but also what's very interesting is the
3687.04|3.92|flu shot again
3688.4|3.28|uh by just keep scaling up everything we
3690.96|2.56|get
3691.68|4.399|super large boost in fuel shot again
3693.52|5.76|this is imagenet top 1 accuracy and for
3696.079|4.401|example it's just 10 images per imagine
3699.28|3.2|a class
3700.48|5.04|which means 10 000 images flatter
3702.48|5.28|because thousand classes we get this
3705.52|4.72|big of a drop we get 85 percent of one
3707.76|5.76|accuracy which is what
3710.24|5.599|uh what is what you typically get when
3713.52|4.319|using the full data set basically
3715.839|3.841|um so this is
3717.839|4.641|the gaping up makes actually a few shots
3719.68|5.52|work significantly better and then i'm
3722.48|4.96|gonna skip on this well this actually
3725.2|4.24|has an interesting message this is
3727.44|3.919|three times the same story but measured
3729.44|2.639|in a slightly different way which is
3731.359|3.041|that
3732.079|4.72|if you make the model larger it actually
3734.4|4.8|needs to see fewer images to get to a
3736.799|5.28|similar score like this
3739.2|4.32|blue line is a tiny vision transformer
3742.079|4.48|and the base vision transformer in the
3743.52|5.68|large one and the y-axis is the arrow so
3746.559|3.361|lower is better and actually you need to
3749.2|2.399|see
3749.92|4.08|still we're talking in millions of
3751.599|4.801|images and here's 100 million images but
3754.0|4.4|still you need to see a lot fewer images
3756.4|3.679|with the larger models doesn't mean a
3758.4|3.84|lot less compute right because the model
3760.079|4.0|is larger and the slower
3762.24|3.76|but that's interesting
3764.079|4.48|and then there's some scaling laws that
3766.0|4.319|are popular in language and we i think
3768.559|4.24|maybe for the first time in
3770.319|3.921|discriminative uh image learning show
3772.799|3.361|that yeah they
3774.24|3.839|appear to be here too
3776.16|2.8|um and
3778.079|3.201|then
3778.96|4.48|right then we want to
3781.28|4.16|sorry i had the order of the slide mixed
3783.44|4.399|up in my head i'm a bit surprised but
3785.44|4.08|then another thread was that besides
3787.839|4.24|further scaling up the model we wanted
3789.52|3.68|to push even further into this direction
3792.079|3.76|of
3793.2|5.28|less hand engineering
3795.839|4.48|of things into the model architecture
3798.48|3.44|and then with the
3800.319|4.0|vision transformer transformer in
3801.92|4.0|general what is the obviously most hand
3804.319|3.76|engineered part of it is the search
3805.92|5.439|attention so we try to what can we do
3808.079|4.081|something like more generic than that
3811.359|3.041|and
3812.16|4.24|less smart than that basically and we
3814.4|5.679|ended up by replacing it essentially
3816.4|5.84|with just a multi-layer perceptron
3820.079|4.24|that however
3822.24|4.24|has a little bit of structure but much
3824.319|3.681|less than self-attention so they will
3826.48|4.0|skip the structure
3828.0|5.039|for the sake of time and we're coming
3830.48|4.72|back to this plot where the question was
3833.039|3.76|aren't we saturating now this plot is
3835.2|4.879|slightly different we again have this
3836.799|6.081|bit resonate here in black and the full
3840.079|4.641|green line is the vision transformer and
3842.88|3.76|the other color also the full lines are
3844.72|4.079|the vision transformers right these
3846.64|4.479|exactly same numbers as from before
3848.799|4.24|however now we also throw in this mixer
3851.119|3.521|architecture which we believe is even
3853.039|4.0|more flexible and less hand in
3854.64|4.399|engineering transfer and as you see with
3857.039|5.601|less data it's even worse
3859.039|6.0|uh however with much more data it may be
3862.64|4.8|surpassing the transformer or it may be
3865.039|4.08|random noise uh
3867.44|4.56|not clear at this point right because
3869.119|5.041|it's the only point where this happens
3872.0|4.799|so we need to go further so we use this
3874.16|4.48|three billion data set for example from
3876.799|4.641|the previous paper
3878.64|4.56|that i mentioned here and try to extend
3881.44|4.32|these lines to the right to see what
3883.2|4.24|happens we don't extend many of them
3885.76|3.52|because these are very expensive
3887.44|4.24|experiments that require a ton of
3889.28|4.64|patience but we extended two most
3891.68|4.0|interesting and it seems that it
3893.92|4.08|continues and that
3895.68|3.6|first of all yes the vision transformer
3898.0|3.52|keeps
3899.28|4.0|increasing we don't have such experiment
3901.52|4.16|with the resonate because it doesn't
3903.28|4.16|look promising enough to pay the cost of
3905.68|3.6|doing it
3907.44|3.52|but it also seems that the mixer the
3909.28|3.279|what we believe is even more flexible
3910.96|4.079|architecture actually is
3912.559|4.48|consistently above the transformer now
3915.039|2.961|which is good news
3917.039|2.56|and
3918.0|4.0|yeah with this good news so we're now
3919.599|4.401|right at the
3922.0|4.0|time when i should stop right or open
3924.0|5.119|two more questions again
3926.0|5.52|yeah uh i guess as a question
3929.119|4.881|that's the follow-up on the scaling that
3931.52|3.44|you showed earlier it's really into my
3934.0|3.599|question
3934.96|5.28|i'm curious how this model size compares
3937.599|5.44|to the model sizes for earth or like the
3940.24|2.799|natural language
3943.68|4.48|like especially going from like smaller
3945.68|4.24|models to much bigger models but
3948.16|4.32|never they comparable at all in terms of
3949.92|3.84|model size and if not like why do you
3952.48|2.96|think
3953.76|3.359|what is there for the models for these
3955.44|3.52|two different classes
3957.119|5.361|yeah actually a colleague of mine has a
3958.96|6.96|slide which i hate but he loves it's the
3962.48|4.639|model number of parameters in nlp and in
3965.92|2.8|vision
3967.119|2.96|and the question is how do you measure
3968.72|3.359|your mother's side
3970.079|3.601|if you just measure number of parameters
3972.079|2.96|then these visual models are much
3973.68|3.04|smaller
3975.039|4.08|however
3976.72|4.079|the language models number of parameters
3979.119|3.841|like a huge chunk of it is in the
3980.799|4.081|dictionary for example which for us just
3982.96|4.879|doesn't exist it is linear embedding
3984.88|4.159|which is trivial number of parameters
3987.839|3.52|um
3989.039|3.361|so in terms of number of parameters it's
3991.359|2.72|much smaller
3992.4|4.719|my personal opinion is number of
3994.079|4.561|parameters doesn't mean that much
3997.119|3.92|then the other way that you could
3998.64|4.56|measure is maybe in terms of compute
4001.039|5.601|like how much floating point operations
4003.2|5.04|does it do on one data point and in
4006.64|3.919|terms of this
4008.24|4.16|uh it's in the same ballpark however
4010.559|3.28|last time i checked which is quite a few
4012.4|3.199|months ago
4013.839|4.801|the largest language model was still
4015.599|5.281|like four times more or five times more
4018.64|3.199|in vision model i believe
4020.88|3.6|um
4021.839|5.441|yeah so that's the two ways of measuring
4024.48|4.48|model size i don't think either of the
4027.28|3.039|ways is the one true way to measure
4028.96|3.44|model size and i think it's actually an
4030.319|4.881|interesting research topic like how to
4032.4|7.199|properly measure and like order models
4035.2|4.399|in terms of capacity it's not clear
4039.68|6.0|do you know why the vision is sorry the
4042.4|3.28|vision is smaller
4046.48|3.2|i think it's just there is less interest
4048.64|3.6|in it
4049.68|3.919|and so less resources spent on it
4052.24|3.599|basically
4053.599|4.401|um like in google there are many more
4055.839|4.801|many many more groups doing research
4058.0|5.28|with language than with vision
4060.64|4.959|and i think we are one of the few groups
4063.28|4.16|that have access to a lot of resources
4065.599|4.24|and are interested in scaling up things
4067.44|4.08|in vision so much whereas in language it
4069.839|3.041|seems there are a lot of groups that are
4071.52|4.4|doing that
4072.88|5.52|i think that's the main reason actually
4075.92|3.84|it's not that we don't want to go beyond
4078.4|2.24|that or
4079.76|4.0|like
4080.64|5.919|if we can we would go even more
4083.76|2.799|awesome thinking
4087.68|4.56|right so we are actually over time at
4090.16|4.08|this point so anyone who has to leave
4092.24|4.559|please feel free to do so i think before
4094.24|3.919|we do that uh lucas thank you so much
4096.799|3.36|for joining
4098.159|4.721|for all the way from
4100.159|4.241|across the ocean and we know it's it's
4102.88|3.279|in the evening so thank you for taking
4104.4|3.12|your free time to come and talk to us
4106.159|3.12|here
4107.52|5.639|yeah thanks for an invitation always
4109.279|3.88|like to talk about the work