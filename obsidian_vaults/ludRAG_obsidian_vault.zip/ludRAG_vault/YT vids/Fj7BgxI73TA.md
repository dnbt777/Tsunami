start_time|end_time|text
0.0|3.4| Yeah, as the last video for this week, I want to briefly talk
3.4|4.2| about the geometric intuition behind the perceptron. So this
7.6|2.08| is, I think, particularly interesting, because the
9.68|3.8| perceptron rule is so simple. And yeah, here, we will briefly
13.48|5.08| go over why it actually works at all. So if you recall, this is
18.56|3.04| the perceptron learning algorithm. The slide is just
21.6|4.16| copied from an earlier video. So it's just for recapping what's
25.76|4.48| going on. So if the prediction is correct, nothing happens. So
30.24|3.16| we don't need to update the decision boundary. However, if
33.4|2.68| it's incorrect, there are two scenarios, scenario A and a
36.08|5.34| scenario B. So scenario A is if the output, the prediction is
41.44|5.2| zero class able zero, while the target is class label one. And
46.64|4.48| scenario B is if the prediction is one, and the class label, the
51.12|4.0| actual one is zero. So in both cases, we make a mistake. And
55.12|2.76| then we have to update the perceptron. So in the first
57.88|4.56| case, in this case, how we update the decision boundary is
62.44|5.2| by adding the input vector, so the feature vector to the weight
67.64|3.7| vector. So why do we have to add the input vector to the weight
71.34|2.66| vector? And why does it help at all? So in this video, I want to
74.0|4.24| briefly go over the intuition behind that. So here also, yeah,
78.24|3.08| in code, just again, the outline of the learning algorithm, if
81.32|3.72| it's more clear this way, so we initialize the weights with all
85.04|3.44| zeros, or we can also use all small random numbers doesn't
88.48|4.16| really matter. And then for every training epoch, we iterate
92.64|3.52| over the training examples. And then we compute the prediction.
96.4|3.36| And then you update if we make a mistake. So here we compute the
99.76|4.36| arrow and then update. So that is the basic concept behind the
104.12|4.92| perceptron that we talked about before. Now, regarding the
109.04|3.52| geometric intuition. So imagine you have these two classes here
112.56|4.72| on class zero and class one. And here that's the black line here
117.28|5.08| is the decision boundary. So the weight vector turns out to be
122.58|4.78| perpendicular to the decision boundary. Can you think of the
127.36|4.88| reason why the weight vector would be perpendicular to the
132.24|2.72| decision boundary? So perpendicular here means 90
134.96|3.58| degree angle, why is there a 19 degree angle between the weight
138.54|2.38| vector and the decision boundary, maybe pause the video
140.92|3.72| for a few minutes and think about it a little bit, maybe you
145.8|2.28| get the idea, if not, don't worry, it's a little bit, I
148.08|2.4| would say, it's not immediately obvious.
154.12|4.44| Alright, so the intuition behind it is why the decision boundary
158.56|3.96| in the weight vector of this 90 degree angle is because if you
162.52|4.32| think of our threshold, if we compute or look at the dot
166.84|3.28| product, let's ignore the bias for now, if we just look at the
170.12|3.4| dot product of the weights and the feature vector, we make a
173.52|4.8| decision at zero, so whether it's greater or smaller than
178.32|4.2| zero. So if it's smaller equal to zero, the net input, so this
182.52|7.12| is the net input. If it's smaller equal to zero, we
189.64|3.2| predict or return class able one, if it's greater than zero,
192.84|4.04| we return one, so everything kind of hinges upon the zero
196.88|4.48| here. And if we write the dot product a little bit differently
201.36|5.12| as the length, magnitudes of the two vectors, and then the angle
206.48|2.64| between them, the cosine of the angle, then we have the
209.12|2.6| following equation, you probably have seen that from linear
211.72|6.36| algebra classes. So in order, so in order not to have this dot
218.08|3.74| product zero, like if we want to have it zero, um, yeah, what we
221.82|4.38| would have is to have at least one of these two terms zero, but
226.2|3.0| this is not the case, right? Because the vector is not zero,
229.2|6.84| unless it's all values are zero. But um, yeah, so in this case,
236.08|3.2| that would be one scenario where we might have a case of zero.
239.28|5.8| Another case is where the decision boundary, sorry, the
246.64|2.72| angle here between the weight vector and the decision boundary,
249.64|3.36| when this term here becomes zero, and when is this term
253.0|4.5| zero, the term is zero, if we have a 90 degree angle here
257.5|5.22| between the two, right, because the cosine of 90 degree is zero.
262.92|3.64| So by setting this part here, this part to zero, we get a
266.6|4.08| weight vector that actually has some length. And that has an
271.28|2.48| angle between the decision boundary and the weight vector
273.76|1.04| of 90 degree.
274.8|9.08| Yes, so what else does that mean? So if we think about the 90
283.88|3.6| degrees a little bit more, so what we can deduce then is that
288.2|5.8| there will be an angle smaller than 90 degree on this side
294.0|4.76| here of the decision boundary. So by that, I mean, if you have a
298.88|3.4| training example, or a data point that is somewhere, you
302.28|2.1| know, on the right side of the decision boundary, let's say it
304.38|4.34| can be here. So if we have a feature vector that is here can
308.72|4.72| also be here doesn't really matter. So anywhere where we
313.44|1.04| have a decision.
322.48|3.26| Yes, so what else does this mean? So let's focus in a little
325.74|4.02| bit more on the 90 degrees here that we just talked about. So
329.76|3.64| now every input vector on this side here on the right hand side
333.4|3.16| will have an angle with a weight vector that is smaller than 90
336.56|6.92| degrees. So again, in blue, this is the weight vector here. And
343.48|3.2| now if I take a training example, and put it anywhere on
346.68|3.28| the right side of the decision boundary, for example, here, so
349.96|3.64| if we look at this one, it has this angle that is smaller than
353.6|4.2| 90 degree. If we put it here, same thing is true. Or if we put
357.8|3.04| it here, outside, maybe it doesn't really matter. Also, we
360.84|3.8| have always this 90 degree angle. And also you note that it
364.64|3.72| doesn't really matter how large the weight vector is. So if we
368.36|4.36| scale the late weight vector by a factor of 100 or 1000, it
372.72|3.88| doesn't matter, it will be still than the angle because whether
376.6|3.16| this is longer or not doesn't really matter. The same is true
379.76|3.12| for the training examples, if they are super large, if let's
382.88|4.0| say one training example is somewhere here, still the 90
386.88|3.8| degree angle, or smaller, sorry, smaller than 90 degree angle. So
390.68|2.72| the magnitudes of the weights and features doesn't really
393.4|4.54| matter whether we scale them or not. However, the updating the
397.94|4.74| learning can be a little bit faster if they are scaled, which
402.68|4.4| is why I had the standardization in the code example. But yeah,
407.12|3.6| so there's one takeaway that the angle is smaller than 90 degree
410.72|3.24| on this side. And on the left side here, it would be of
413.96|4.52| course, greater than 90 degree, if we have a value here, that
418.48|3.36| would be greater than 90 degree. So everything, again, hinges
421.84|8.48| upon the 90 degrees here. Now, why is that again, interesting?
430.44|4.48| So let's now focus on the actual prediction case before I just
434.92|3.36| laid out where all the data set on the weight vectors are
438.28|4.32| oriented. Now, let's take a look at prediction case. So we have a
442.6|5.24| correct side and a wrong side. So let's assume we have an input
447.84|5.24| vector with class label one. And like I've shown you before a
453.08|4.32| weight vector for the correct prediction must be somewhere
457.4|2.86| such that the angle is smaller than 90 degrees to make a
460.26|2.96| correct prediction. Let me go back to just show you again what
463.22|4.9| I mean. So notice here, we have all the ones on this side. And
468.12|4.36| this is our weight vector here. So to make a correct prediction
472.48|3.68| that is predicting a new training example like this one
476.16|3.2| as class one, it has to be smaller than 90 degree, it has
479.36|3.28| to be in within the circle here, right. So that's what we are
482.64|3.84| looking at now. So we have here on this correct side. So if you
486.48|2.52| think of this as the decision boundary between the wrong and
489.0|3.36| the correct side, we have to have an angle between the input
492.36|2.48| vector and the weight vector that is smaller than 90 degrees.
495.6|3.92| So if we are within the 90 degrees, then we make a correct
499.52|3.64| prediction, because the product then will be positive greater
503.16|4.8| than zero, because um, yeah, because this term will be
508.36|5.16| greater than zero. Yeah, now let's take a look at what
513.52|3.96| happens if we make a wrong prediction. So here in red, I
517.48|3.92| have now a weight vector that is not ideal. So that is a weight
521.4|4.76| vector, where, when we make a prediction, where we make a
526.16|4.72| wrong prediction, because the angle is not smaller than 90
530.88|3.84| degrees, it's in fact, larger than 90 degrees now. So if it's
534.8|7.16| between a value between larger than 90, up to 270, we will make
542.0|3.8| a wrong prediction, because now the value of the cosine of that
546.2|5.6| angle larger than 90 and smaller than 270 would be negative. So
551.8|3.08| we would be smaller than zero. So we would make class zero
554.88|3.48| prediction, which is what happens here. So we have an
558.36|3.72| angle that is greater than 90 degrees. And then we would
562.12|2.48| predict the wrong label, we would predict
567.4|4.72| class level zero, although our input vector here, we assume
572.12|4.08| that it still has class level one. How do we make this
576.2|3.32| correct? And how can we correct this prediction that is by
579.64|5.44| moving the weight vector to the side of closer to the side of
585.08|3.68| the training example, so that the angle is smaller than 90
588.76|3.4| degree. So how do we do that? So in the perceptron algorithm, how
592.16|3.48| we do that is we add the feature vector. So the input vector, we
595.64|5.28| add it to the weight vector. So here, the dash line here, that
600.92|8.4| is the input vector. So here, that's the same input vector,
609.32|3.32| I'm just taking the input vector and adding it to my weight
612.64|4.84| vector. So maybe doing it step by step. So what we have is we
617.48|4.36| have our input vector, and we have our wrong weight vector.
622.16|4.76| What I'm going to do now is I'm taking this input vector, and
626.92|4.08| I'm adding it to the weight vector, like this, and then my
631.0|4.56| new weight vector will be like this, right. So then we will
635.56|4.36| have this smaller than 90 degree angle, which is shown here. So
639.92|3.32| by adding the weight vector, we can make the decision boundary
643.24|4.08| correct for this case. So this is if I go back here, this is
647.32|5.56| exactly what happens in scenario A. So we predict on the output
652.88|4.68| is zero, although the target is one. So this is when we go back
657.56|3.0| here, that is what we have, we have a label of one. And then we
660.56|3.64| predict zero, because we are on the right, wrong side here. But
664.2|2.8| we what we do is then we add the input vector to the weight
667.0|2.96| vector, which is what I've shown you in the previous slide. And
669.96|3.04| by that, we can correct the decision boundary. And yeah, if
673.0|3.72| you want, or like, you can also play through the same scenario,
677.16|4.82| if prediction and the targets are flipped. So the same concept
681.98|6.98| applies there too. Yeah, to summarize, the perceptron has
688.96|3.9| many shortcomings. So there are many problems with a perceptron,
692.86|3.26| which is why it's not commonly used anymore in practice, some
696.12|2.36| people still may use it in certain applications where
698.48|3.64| computational performance matters, because one advantage of
702.12|2.84| the perceptron is it's very simple to implement and very
704.96|4.56| fast. However, nowadays, many problems that we have in the
709.52|2.6| real world cannot be solved by this perceptron, which is why we
712.12|4.0| have fancy and deep learning methods. So let me go over the
716.12|3.84| shortcomings of the perceptron. So first of all, it's a linear
720.28|3.04| classifier. So you cannot have nonlinear decision boundaries.
723.32|3.0| If you think back of the x or problem, it cannot solve the x
726.36|4.4| or problem. Or if I, for example, just have another
730.76|4.4| simple problem where we have two classes like, like this, for
735.16|6.44| example, class zero and class, one like this around it. So if
741.6|3.3| we have these concentric circles, the perceptron cannot
744.9|2.9| classify these very well, because it can only do a linear
747.8|2.48| decision boundary like this or like this. And that is not
750.28|3.12| helpful. What we need is we have, we need a nonlinear decision
753.4|4.6| boundary like this, for example. So that is one shortcoming.
758.16|4.48| Another shortcoming is that it is a binary classifier. So it
762.64|3.68| can only classify two classes. But yeah, of course, there are
766.32|3.16| also extensions where you can use multiple perceptrons.
769.68|3.92| There's a method called one versus rest, or one versus all
773.72|4.24| or one versus one. So actually two methods that I can just
777.96|5.48| write them down one versus rest. Sometimes it's also called one
783.52|4.92| versus all, where you can just use multiple perceptrons, or
788.44|4.84| multiple binary classifiers. And one is called one versus one to
793.28|5.68| have multi class classification. Yeah, but it is like one single
799.0|2.72| perceptron cannot do multi class classification, because it's
801.72|5.12| just returning either a zero and one. Another shortcoming is it
806.84|4.04| does not converge if classes are not linearly separable. So what
810.88|5.76| does that mean? So that is exactly the problem related to
816.68|3.96| the convergence theorem that we have not covered. But in the
820.64|3.16| convergence theorem, it says it only converges if the classes
823.84|4.04| are linearly separable. So let me draw that out also. So if we
827.88|6.96| have a case, again, like let's say this, it will find a
834.84|3.32| decision boundary like this. However, if I have a data point
838.16|3.28| over here, then there is no decision boundary such that I
841.44|2.64| can classify everything correctly. So it will learn,
844.56|2.56| let's say this decision boundary, but then it
847.12|4.2| encounters this data point. So if we keep iterating, and then
851.32|2.92| it thinks, okay, I have to move the decision boundary further to
854.24|4.48| the right, like here, but then it gets these examples wrong. So
858.72|3.04| it then it thinks, okay, I have to move it back to the left. So
861.76|3.36| it will keep on moving the decision boundary back and
865.12|5.04| forth, and it will never really stop updating. So in that case,
870.4|3.0| that is also a problem if you want to have the final model.
873.88|3.2| Okay, that's fluctuating. It's like the longer you run the
877.08|4.04| algorithm, the more solutions you will get. So it will never
881.12|7.04| really finish updating. Yeah, and then also, another thing is
888.16|4.6| there are multiple solutions possible, if the classes are
892.76|3.92| separable. So now let's assume you have a problem that is, let
896.68|3.04| me do this a little prettier. Let's say no, you have a problem
899.76|5.56| where you can linearly separate these classes, let's say, like
905.32|4.96| this. So one possible decision boundary is like this. Another
910.28|3.0| one is like this one is like this. So there are multiple
913.28|2.88| solutions. And it depends on Yeah, where you start with your
916.16|2.24| weights, which one is the best one, or which one is picked by
918.4|4.54| the perceptron before it stops updating. And yeah, this is
922.96|2.68| also kind of annoying, or can be annoying, there are multiple
925.64|3.6| solutions. So that I would say there's a best one, the best one
929.24|4.0| might be the one that is just in the center. Rather than
933.24|3.28| something that fits, let's say, the data very closely to the
936.52|3.2| left or very closely to the right, because one might argue
939.76|3.28| that putting the decision boundary in the center helps
943.04|4.76| with reducing overfitting, for example. But yeah, that is also
947.8|3.2| something the perceptron is not capable of. And in your later
951.0|2.6| lectures, the methods that we will be using, they are a bit
953.6|3.32| better with that. Alright, so that is just the other
956.92|4.96| conclusions on regarding the perceptron. So like, one last
961.88|4.68| thing, like a little fun fact. So yeah, back in the day, the
966.56|5.12| perceptron was used, or people try to use it to detect tanks in
971.68|4.96| photographs. So here on the left hand side would be a tank. And
976.64|4.04| here, there would be no tank. And they used the perceptron on
980.68|3.28| images to classify whether there's a tank in the photograph
983.96|3.84| or not. However, like we just said, the perceptron is very
987.8|3.14| limited. So why would that work at all? People found that it
990.94|3.74| worked. But there was like a little gotcha, a little mistake
994.68|5.04| or conceptual mistake. So because people didn't first
999.72|2.68| think about it very well. So what happened was that all the
1002.4|3.9| forest pictures were darker than the pictures with the tanks. And
1006.3|6.64| the perceptron simply recognized that darker photographs means no
1012.94|3.02| tank and brighter photographs means tank. Of course, it had no
1015.96|2.18| idea whether there was actually a tank or not. So if you would
1018.14|2.94| have a dark photograph with a tank, it would, of course, get
1021.08|3.6| that wrong. Yeah. And this was like a little fun fact about the
1024.68|3.42| perceptron. I got that from this interview with Marvin Minsky,
1028.1|3.54| who was one of the authors of this perceptron book I mentioned
1031.64|3.04| where they kind of said bad things about the perceptron that
1034.68|3.52| it was limited. So here's like a little excerpt from this
1038.2|9.52| interview. So basically, it was looking for a scene at a scene
1047.72|2.72| of a forest with which there were camouflage tanks in one
1050.44|3.6| picture and no camouflage tanks in the other picture. And the
1054.04|2.56| perceptron after a little training made 100% correct
1056.6|3.08| distinctions between these two different sets of photographs.
1060.16|3.56| Then they were embarrassed a few hours later to discover that the
1063.72|3.2| two roles of film had been developed differently. And so
1066.92|2.24| these pictures were just a little darker than all of the
1069.16|3.68| pictures. And the perceptron was just measuring the total amount
1072.84|3.4| of light in the scene. So it was just counting the pixel values,
1077.04|3.32| the pixel brightnesses. But it was very clever of the perceptron
1080.36|2.6| to find some way of making this distinction. Yeah, I think I
1082.96|3.32| would admit that it was actually kind of exploiting the fact
1086.28|2.6| that photographs were brighter and darker. But of course, it
1088.88|2.96| had nothing to do with whether there was a tank in the picture
1091.84|2.6| or not. It was just how they developed the film. Alright,
1094.44|2.12| with that, I want to end this lecture, which was a little bit
1096.56|3.24| long, I will, in the future, try to keep that shorter. But I
1099.8|3.2| didn't want to split this topic over two weeks. So in the next
1103.0|4.04| week, we will cover some basic linear algebra. I mean, just
1107.04|3.44| some ground rules that we will be using. And then hopefully
1110.48|3.0| also slowly get into implementing more
1113.48|2.68| sophisticated methods in pytorch.