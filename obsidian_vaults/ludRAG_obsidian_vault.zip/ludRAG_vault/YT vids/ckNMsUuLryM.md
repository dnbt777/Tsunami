start_time|end_time|text
6.04|5.759|we're glad to have Angela fan today with
8.32|5.68|us here um and she's um a research
11.799|4.681|scientist at meta AI research in New
14.0|4.88|York uh focusing on Research in text
16.48|4.4|generation mainly and currently she's
18.88|4.719|working on language modeling and
20.88|5.239|developing the line AI agents meta
23.599|4.401|products and Recent research products
26.119|4.4|include no language Left Behind which
28.0|4.239|she'll be talking briefly about today um
30.519|4.801|Universal speech translation for
32.239|6.241|Unwritten languages as well as llama too
35.32|6.2|um so give it up for Angela I
38.48|4.96|guess all right thank you all so much so
41.52|3.039|yeah I when I got this email I was like
43.44|2.92|oh I should probably talk about llama
44.559|3.801|too but then I noticed you have shiron
46.36|3.359|who will like you know is like a 10x
48.36|3.92|better speaker than me so I was like
49.719|4.16|okay like maybe not llama too but then I
52.28|3.279|thought I maybe would cover this project
53.879|4.16|that we did called No language Left
55.559|5.201|Behind which could be very uh also very
58.039|5.361|relevant to this class and so so when
60.76|5.84|you think about a lot of text generation
63.4|5.759|technology uh most of it until fairly
66.6|4.92|recently uh has been really focused on
69.159|5.201|English but there are actually more than
71.52|4.599|3,000 written languages worldwide and
74.36|3.799|for me this is extremely personally
76.119|5.601|meaningful because actually English is
78.159|6.481|my third language so it's really
81.72|5.359|important um yeah so it's really uh also
84.64|4.68|very personally meaningful and when you
87.079|4.0|think about some of the multilingual
89.32|3.64|technology that permeates it's not like
91.079|4.201|we've we've never worked on multilingual
92.96|3.839|right actually when speaking about
95.28|2.879|generative AI I actually think
96.799|3.561|translation is one of the most
98.159|4.201|commercially successful and widespread
100.36|4.64|applications of generative AI I mean
102.36|3.96|ultimately translation models they are
105.0|3.88|uh you know like conditional language
106.32|5.04|models and so when you think about like
108.88|4.239|traveling or something like that or my
111.36|3.48|sister is taking Spanish so like just
113.119|3.561|like doing her Spanish homework we have
114.84|3.44|a lot of tools that exist today so
116.68|4.52|things like Google translate cover
118.28|4.72|around 130 languages Microsoft translate
121.2|3.76|about 110 these might be a little bit
123.0|5.16|outdated since I pulled the statistics
124.96|4.799|um a little bit ago uh but the project
128.16|3.48|for no language left behind it started
129.759|4.48|from like a very simple ask like okay
131.64|4.64|there's 3,000 languages worldwide maybe
134.239|5.28|it'll be like pretty hard to get to all
136.28|5.64|3,000 since some of them are uh pretty
139.519|4.281|rare and not spoken by many but there
141.92|4.12|are still like hundreds of languages
143.8|4.4|spoken by millions and millions of
146.04|4.479|people and so we were like okay no big
148.2|4.64|deal like let's just start from the
150.519|4.241|100ish that we have today and just go
152.84|3.72|for like a doubling like what would it
154.76|4.479|take to actually be able to double this
156.56|4.12|kind of coverage and of course you know
159.239|3.36|just saying that you support a bunch of
160.68|3.639|languages is not the goal right like we
162.599|3.961|actually want to create high quality
164.319|4.161|safe translations that would be usable
166.56|3.84|by people just like if you're going on
168.48|3.36|vacation today your kind of instinct is
170.4|3.0|to whip out your phone and get on the
171.84|4.92|Google Translate
173.4|4.72|app and so kind of the backdrop to this
176.76|3.559|project was that there is actually a lot
178.12|4.0|of progress in translation so
180.319|3.28|historically there's been a lot of focus
182.12|3.44|on what we call higher resource
183.599|3.761|languages and these are not necessarily
185.56|3.56|languages that are spoken by the most
187.36|3.599|people in the world but when we say
189.12|3.88|higher resource it means the most amount
190.959|4.761|of data and so you can think about
193.0|3.92|things like europ parl or you know
195.72|3.0|translations from the European
196.92|3.48|Parliament and those served as the
198.72|3.599|foundation for a lot a lot of
200.4|3.68|translation development and more
202.319|3.681|recently there's been a great focus on
204.08|4.079|low resource languages and it's been
206.0|4.92|driven across the research Community
208.159|5.041|with groups like Ghana NLP masakane
210.92|4.319|America's NLP and these are all really
213.2|4.28|exciting developments and so these have
215.239|5.241|led to a lot of development of new data
217.48|5.92|sets as well as criticisms of existing
220.48|4.56|data sets and also work on new languages
223.4|3.839|and usually languages that people kind
225.04|3.64|of speak and they care a lot about and
227.239|3.681|we found this like really really
228.68|4.96|exciting and so looking at a lot of this
230.92|4.239|a bunch of us got together um at fair
233.64|3.64|and started thinking like okay we
235.159|5.041|actually speak some pretty low resource
237.28|4.879|languages from like catalon to Asam
240.2|3.52|and so on and so we started this as kind
242.159|3.92|of like a big passionate research
243.72|4.879|project and so today I want to cover a
246.079|4.44|little bit about our highle approach to
248.599|3.801|this problem which is a little bit
250.519|4.161|interdisciplinary I want to talk about
252.4|4.959|how we actually created the data sets to
254.68|4.04|be able to support this kind of work um
257.359|2.961|of course I want to talk about the
258.72|3.96|models since this is a class about
260.32|3.56|Transformers on one note here I think
262.68|2.88|that's actually very interesting in
263.88|3.759|terms of translation as like a research
265.56|4.24|direction is that actually a lot of
267.639|4.521|Innovations have been done in
269.8|4.16|translation and the original Transformer
272.16|3.4|paper I think is one of them and which
273.96|3.84|makes always translation a quite
275.56|3.72|interesting area to work on because I
277.8|3.88|feel like it's a it's a very mature
279.28|3.88|research area as well so it kind of is
281.68|2.959|like okay if your architecture Works in
283.16|3.2|Translation it probably works very
284.639|3.241|generally so that's also one of the
286.36|4.04|things that excites me about translation
287.88|4.0|research um then I want to talk about
290.4|3.44|evaluation like how are we actually
291.88|4.28|measuring and ensuring the quality of
293.84|4.28|these translations are good and safe for
296.16|3.599|people and then I want to end with a
298.12|3.0|little bit of like you know you know
299.759|3.121|High Lev thoughts about future
301.12|4.6|directions and things that I hope that
302.88|5.36|we can work on um in the future so I
305.72|4.16|want to start with our approach I think
308.24|3.519|the most important thing in research is
309.88|3.52|to know that we're working on a real
311.759|4.761|problem especially when it's really
313.4|5.16|close to people uh like translation and
316.52|3.92|I think in many areas like when I was
318.56|3.68|working on on device AI for example I
320.44|3.72|feel like I had like a research problem
322.24|3.959|in mind but it was like very very
324.16|4.039|disconnected from the Practical problem
326.199|3.401|of actually putting models on phones and
328.199|3.12|so this was something that was really
329.6|4.439|important to us and so we actually
331.319|4.481|started the project by uh kind of like
334.039|4.321|focusing on a social sciences type
335.8|4.28|approach or you know sociology type
338.36|4.32|approach and we actually did a lot of
340.08|5.04|interviews with low resource speakers
342.68|5.12|and so we met with about 44 different uh
345.12|5.44|native speakers that spoke 36 different
347.8|3.92|languages across North America um I will
350.56|3.359|say that a lot of them are like
351.72|4.72|immigrants to the us since that was kind
353.919|4.601|of like the easiest um kind of cohort to
356.44|3.96|recruit and we learned a lot of
358.52|3.88|different things about how they approach
360.4|3.96|low resource languages but also the kind
362.4|3.68|of technological need that they have
364.36|3.839|because I think it's easy to be like hey
366.08|3.92|I have this cool background like I have
368.199|3.041|this cool problem and I want to solve it
370.0|2.88|but I think it's very important to
371.24|3.88|actually like talk to the people this is
372.88|4.0|a problem that that needs to be solved
375.12|3.6|and so we learned that there's great
376.88|3.84|fear in general that low resource
378.72|4.0|languages might be undergoing a state of
380.72|5.8|decline partially because a lot of
382.72|6.0|education is Shifting to um languages
386.52|4.28|like Hindi or like English or or
388.72|4.28|Mandarin Chinese for example and there's
390.8|4.0|a lot of excitement to be included in
393.0|4.039|existing translation systems and people
394.8|4.64|said they have always tried to use uh
397.039|4.16|Google translator Microsoft translate um
399.44|3.24|in their existing languages But
401.199|3.361|ultimately they found that the quality
402.68|4.6|is really insufficient for Reliable
404.56|3.919|usage so if you think about like um well
407.28|2.4|I was going to say when I was in high
408.479|2.961|school but you all are probably like
409.68|3.639|substantially younger than me so maybe
411.44|3.319|like you know 10 so years ago you know
413.319|3.0|and you Tred to use Google Translate for
414.759|3.601|your Spanish homework like your Spanish
416.319|3.72|teacher could always identify that like
418.36|3.04|you know it was not a a human written
420.039|3.201|translation until you would get marks
421.4|3.479|off but that's not really the case for
423.24|4.48|some of the high resource languages
424.879|4.16|today and so I think as with all things
427.72|3.28|in machine learning it really starts
429.039|3.56|from a data perspective like why can't
431.0|3.199|we just train models in hundreds of
432.599|3.241|languages or large language models in
434.199|4.161|hundreds of languages it's because we
435.84|4.4|don't have the data to support it and so
438.36|3.679|I want to talk first about evaluation
440.24|4.639|data sets because I think it's extremely
442.039|3.921|important to nail evaluation um and then
444.879|3.72|I'll talk about
445.96|6.2|training so for an evaluation data set
448.599|5.16|for this work we started um this Flores
452.16|3.12|effort it stands for Facebook low
453.759|3.601|resource I guess we're called meta now
455.28|4.44|but I didn't think mes was like a very
457.36|4.239|good uh a renaming so we're still
459.72|3.919|calling it Flores so this was something
461.599|5.44|we originally started for just two
463.639|5.321|languages in this first paper at emnlp
467.039|3.921|um many years ago so it was just for
468.96|3.72|Nepali and sin Hollow and we later
470.96|4.239|extended it to incorporate two more
472.68|4.44|languages in a release afterwards you
475.199|3.481|know we we thought a lot about okay like
477.12|2.799|Flores was really useful for the
478.68|3.479|community
479.919|3.881|um how can we extend it to 100 languages
482.159|5.841|and so that was this follow-up work that
483.8|5.92|we did I think we had an ACL um or WMT
488.0|4.84|and then in this project we were like
489.72|5.8|okay how can we go from Flores 101 to
492.84|5.4|Flores 200 to really go for the doubling
495.52|5.079|effect and so what is Flores well it's
498.24|4.72|in the name it's a focus on low resource
500.599|4.88|languages so we do include some higher
502.96|5.28|resource languages like German or Hindi
505.479|5.081|or so on almost for calibration effect
508.24|4.0|as well but the majority of the focus is
510.56|4.599|on these lower and mid- resource
512.24|5.2|languages it's the first um large scale
515.159|4.521|many to many machine translation
517.44|3.959|evaluation data set which means that we
519.68|3.279|take all of the sentences in English and
521.399|3.281|then we translate them to all of the
522.959|4.601|languages which means that you would be
524.68|4.92|able to evaluate any cross pair of
527.56|4.24|languages so for example like Chinese to
529.6|3.359|French I I lived in France for many
531.8|3.599|years so it's like very personally
532.959|4.361|relevant to me of course 200 languages
535.399|3.481|also in the name there's a broad
537.32|3.56|diversity of different domains and
538.88|4.199|topics I think this is important when
540.88|4.399|designing an evaluation data set which
543.079|3.801|is like very top of mind for anybody
545.279|4.721|interested in in language modeling
546.88|5.399|research because like the way people
550.0|4.44|train machine translation models and the
552.279|4.441|way people use them are often like very
554.44|4.079|different and so if you only Benchmark
556.72|3.84|your data set for example on news which
558.519|3.44|is very common in Translation research
560.56|3.6|then you don't really pick up the fact
561.959|3.721|that people talk about such a wide
564.16|3.16|variety of things and have like
565.68|3.839|different casual conversations that they
567.32|5.519|need translated official documents and
569.519|4.76|so on it's also document level uh data
572.839|3.24|set this is not something that I think
574.279|3.8|the community is like broadly leveraging
576.079|4.601|right now but the way it's translated is
578.079|4.44|that you can have document level context
580.68|3.839|and so translators are provided the
582.519|3.921|entire document to translate from and we
584.519|3.961|also provide the entire document for
586.44|3.32|evaluation and we translate like
588.48|3.32|multiple sentences from the same
589.76|3.639|paragraph and so this was like a a
591.8|3.4|potential research direction that we
593.399|3.161|wanted to make sure we covered models
595.2|3.12|that needed like potentially more
596.56|4.399|context because a lot of translation
598.32|4.28|work is done at the sentence level so
600.959|3.601|how do we actually ensure that this data
602.6|5.16|set was high quality so the first step
604.56|4.6|is that we take a a document um well
607.76|3.12|actually first step is like alignment on
609.16|3.16|language standards so this is very
610.88|4.04|important because when you're
612.32|4.68|translating French or Chinese I think
614.92|3.88|most people have a strong understanding
617.0|3.8|of like what it means to produce like
618.8|3.719|good French or good Chinese and there
620.8|3.84|are a lot of professional translators
622.519|4.361|hired in these languages but when you go
624.64|4.12|to lower resource languages it's not
626.88|4.28|necessarily the case that there's like a
628.76|5.4|you know glowing translation industry
631.16|4.96|around translating um uh a lower
634.16|3.479|resource language and so one of the
636.12|3.88|first things is actually to align on
637.639|3.76|like what is a high quality translation
640.0|3.32|and so there's actually a lot of
641.399|3.081|challenges here so there are certain low
643.32|3.24|resource languages where there's
644.48|4.52|different competing language standards
646.56|3.959|or there's like very high variance uh in
649.0|3.839|different regions on how languages are
650.519|4.641|spoken and so this step is a pretty
652.839|4.201|critical one so then what we do is we
655.16|4.239|take the document we send it to one
657.04|4.28|group of translators and they do uh the
659.399|3.801|first translation step then we do some
661.32|3.88|automatic checking you know like if the
663.2|4.28|input sentence was like 10 words and the
665.2|4.199|output sentence like 300 words it's like
667.48|4.84|most likely something went wrong you
669.399|5.161|know and so we send it back otherwise uh
672.32|4.48|we'll send it onwards to a separate
674.56|4.839|completely independent set of
676.8|4.719|translators uh that do review and so
679.399|3.68|they try to rate the quality of this and
681.519|3.721|if the quality doesn't pass sufficient
683.079|4.721|bar and it gets s back to the original
685.24|4.52|set of translators to to edit and they
687.8|3.64|kind of go through and like address all
689.76|4.8|of the feedback and then if it's good
691.44|5.079|enough then it enters um our data set
694.56|3.88|and so there's many challenges here the
696.519|4.0|first one of course is just like finding
698.44|5.16|translators and also finding more
700.519|4.56|translators there was a certain uh issue
703.6|3.239|that we ran into for example that in a
705.079|5.161|certain country that the internet was
706.839|5.321|not available and so you know it's a lot
710.24|4.56|of recruitment the other one of course
712.16|4.2|is language standardization I think I
714.8|4.039|briefly mentioned this before but
716.36|3.159|there's a lot of different challenges in
718.839|2.401|um
719.519|4.081|just understanding like what is a high
721.24|4.08|quality translation for example the low
723.6|3.96|resource language Breton there's like
725.32|4.0|two competing groups on like how do you
727.56|3.92|write bretel so it's like very difficult
729.32|3.879|to resolve some of those things and the
731.48|4.159|final thing is that there's actually a
733.199|4.681|lot of variation even in languages like
735.639|5.041|Arabic like the Arabic like Moroccan
737.88|5.199|Arabic is very different from you know
740.68|4.24|Jordanian Arabic and so on and there are
743.079|3.88|also certain regions that they speak the
744.92|4.32|same language but due to historical
746.959|3.841|reasons they write in different Scripts
749.24|3.12|and so one of the things we actually did
750.8|3.2|was like if there are languages written
752.36|3.88|in multiple scripts we actually
754.0|4.12|supported the collection of in multiple
756.24|3.92|script evaluation and I think this is
758.12|3.8|really important because if if you're
760.16|4.359|building an underlying technology and
761.92|4.159|you only choose one then I think you
764.519|3.921|risk like just kind of like naturally
766.079|3.801|supporting one over the other um when we
768.44|3.6|we really should be like kind of a more
769.88|4.24|neutral technology provider and so this
772.04|3.56|is something that we we explored a lot
774.12|2.159|as well as exploring different variants
775.6|2.88|of
776.279|3.441|Arabic uh this is also open source if
778.48|3.08|you just go go to this link you can just
779.72|5.28|like download all of the all of the text
781.56|5.079|files uh for this with evaluation done I
785.0|3.32|want to talk a little bit about how we
786.639|3.64|collected some of these training data
788.32|3.72|sets the first thing I want to talk
790.279|4.961|about is this data set we created called
792.04|5.64|NLB seed and the idea of this is like
795.24|4.44|it's a really seed data set of high
797.68|4.24|quality translations and languages that
799.68|4.24|really don't have anything why because
801.92|4.2|well you can't start from nothing you
803.92|3.88|know you got a bootstrap from somewhere
806.12|4.839|a lot of people have been using the
807.8|5.0|Bible uh as a way to bootstrap but it's
810.959|4.761|very uh limited domain obviously very
812.8|5.76|religious text and so we created this
815.72|4.919|data set n lob seed for languages that
818.56|3.8|really don't have um anything to get
820.639|3.801|started from it's only about 5,000
822.36|4.12|sentences so it's nothing crazy but it
824.44|3.68|supports a lot of different use cases
826.48|4.4|like training language identification
828.12|4.48|models or sentence encoders uh engram
830.88|3.28|language models like all of these things
832.6|2.32|that I'm about to talk about in our data
834.16|3.799|set
834.92|5.44|pipeline um so it covers 43 languages
837.959|4.481|about 6,000 sentences and the way we
840.36|4.32|decide to sample is it is focused on
842.44|4.04|really General content so Wikipedia has
844.68|3.959|this article of like hey if you're going
846.48|4.2|to start like a new Wikipedia in your
848.639|5.2|new language I think Wikipedia has like
850.68|4.719|39ish wikipedias last I checked um
853.839|3.321|here's like a list of articles that
855.399|3.721|every Wikipedia in a new language should
857.16|4.2|have and so that's where we sampled this
859.12|3.92|original content from and of course it's
861.36|5.12|also uh open source if you if you want
863.04|6.08|to download it so what we ended up doing
866.48|5.68|to get large scale training data is
869.12|4.56|using mining so this is not something we
872.16|3.679|pioneered in this project we have like a
873.68|4.88|bunch of different previous work so we
875.839|4.641|started from wiky Matrix we were like
878.56|4.0|hey there's a lot of different sentences
880.48|3.84|in Wikipedia and different languages
882.56|3.959|that we should be able to match up and
884.32|4.48|so we tried to do that with Wikipedia to
886.519|4.401|get machine uh TR translation training
888.8|4.399|data we extended that to the web in the
890.92|4.479|CC Matrix project and then we extended
893.199|4.241|it to very very large scale mining on
895.399|4.081|all cross pairs in this project on
897.44|4.12|Beyond English Centric multilingual
899.48|3.84|machine translation where really try to
901.56|4.24|ditch like English as a central pivot
903.32|4.8|language and so the way this whole data
905.8|4.479|mining thing works is that it focuses on
908.12|3.399|sentence alignment so everyone is
910.279|2.281|probably super familiar with this
911.519|3.76|because this how language models are
912.56|4.88|built now it's like you take common craw
915.279|4.0|or any other open source dump of the web
917.44|3.44|I don't know like red pajama or like
919.279|4.161|whatever you want to ccnet whatever you
920.88|4.44|want to use these days and you uh take
923.44|3.959|all of the data you extract all of the
925.32|4.079|text you know a lot of HTML parsing and
927.399|4.201|so on goes into it and the idea is that
929.399|3.92|we want to try to find matching text
931.6|4.28|that could be a translation so we
933.319|4.481|shatter it all into sentences we embed
935.88|4.399|them with different sentence encoder
937.8|4.68|models and then we do a match to try to
940.279|3.401|understand in a multilingual space if
942.48|3.479|the sentences
943.68|4.639|match and so one of the biggest
945.959|3.961|challenges to this is that the quality
948.319|3.241|of the sentence encoding is very
949.92|3.08|important so if your sentence encoding
951.56|2.68|is not very accurate then it's
953.0|3.88|impossible to match in this
954.24|4.8|multi-dimensional space the idea of like
956.88|4.04|the meaning being the same and so one of
959.04|3.88|the big things we tried to do here in
960.92|4.56|this project was try to improve the
962.92|4.56|quality of the sentence encoders um and
965.48|3.64|so one of the big things that we did was
967.48|3.359|train sentence encoders with mass
969.12|4.92|language modeling you see that on the
970.839|5.56|left but we also use multilingual
974.04|4.88|distillation which you see on the right
976.399|4.161|and so previous approaches uh to
978.92|3.64|sentence encoders and the trend in the
980.56|4.959|research Community for a while was to
982.56|5.32|really try to embed all languages in the
985.519|4.841|same sentence encoder model so projects
987.88|4.959|like xlm R for example are in that
990.36|4.399|direction I think is pretty widely used
992.839|3.92|uh the challenge with this when you're
994.759|4.361|training a low resource model is that a
996.759|5.08|lot of your high resource data it just
999.12|4.639|overwhelms your your low resource data
1001.839|3.48|and so you don't end up with a very high
1003.759|3.721|quality sentence incoder for those
1005.319|4.361|languages so what we ended up doing is
1007.48|5.039|we had a multilingual teacher model and
1009.68|5.079|we distilled a bunch of student models
1012.519|4.32|that are specialized to different
1014.759|4.2|language families uh that are low
1016.839|3.881|resource and so this enables the quality
1018.959|3.841|to be pretty high and so the way the
1020.72|4.119|distillation works is that the teacher
1022.8|4.48|and the student model both see the same
1024.839|4.12|data and then we try to U minimize the
1027.28|5.36|cosine loss between the sentence
1028.959|5.08|embeddings that they uh produce I think
1032.64|3.0|an important question that you can ask
1034.039|3.88|here is like why do you need to do
1035.64|4.72|multilingual distillation like why can't
1037.919|4.321|you just train a bunch of different
1040.36|3.599|student models like one per language
1042.24|4.16|family like why even care about
1043.959|3.84|distillation and the reason is because
1046.4|4.0|if you're going to use a bunch of
1047.799|4.481|sentence and for mining the important
1050.4|3.96|thing is that they all exist in the same
1052.28|3.639|embedding space you know like if you
1054.36|3.319|train one separate model and another
1055.919|4.161|separate model there's nothing
1057.679|4.401|constraining them so that you can mine
1060.08|4.0|all of the data against each other and
1062.08|3.44|so one of the things we found is that by
1064.08|3.28|starting everything from the same
1065.52|3.8|teacher model and trying to use this
1067.36|4.0|cosine loss to minimize the distance
1069.32|4.28|between embeddings you are able to have
1071.36|4.64|this constrained space where you can
1073.6|3.8|mine every language against every other
1076.0|5.679|even if you have different student
1077.4|7.68|models and so this uh graph on the Y AIS
1081.679|6.161|it shows the error rate of of Mining and
1085.08|4.4|so lower is better and on the x-axis it
1087.84|3.199|shows a bunch of different low resource
1089.48|4.679|languages so for example the first one
1091.039|5.801|is uru the second one is uh Telugu third
1094.159|5.601|one is Tagalog and so on and so the gray
1096.84|5.0|bar here is the original laser paper so
1099.76|4.36|this is a paper we put out maybe in 2018
1101.84|4.0|is and we had all of these languages
1104.12|3.72|with count of them as included but as
1105.84|4.44|you can see the error rate is extremely
1107.84|4.719|extremely high for these languages so
1110.28|4.44|even though they were included couldn't
1112.559|4.521|really be used for high quality and the
1114.72|4.319|blue bar is the laser model that we
1117.08|3.719|trained based on the technique I just
1119.039|3.0|described in the previous slide and you
1120.799|2.321|can see that I think the most important
1122.039|3.681|point is that you can barely see the
1123.12|4.76|blue bars so it was very effective even
1125.72|4.839|for these previous languages that people
1127.88|5.08|had thought we had like previously um
1130.559|4.161|embedded and then so now how does this
1132.96|4.12|kind of thing fit into a whole data
1134.72|4.16|pipeline around this approach so one of
1137.08|3.4|the most important things
1138.88|4.159|is like when you download the data from
1140.48|4.679|the web you don't really know what
1143.039|3.52|language it's in and so this is part of
1145.159|3.201|like all of the large scale data
1146.559|4.0|cleaning that goes into like you know
1148.36|4.559|training large language models today and
1150.559|3.961|so the way we identify different
1152.919|4.0|languages is through like simple
1154.52|5.12|classification models called language ID
1156.919|5.721|identification models and I think it's a
1159.64|5.0|classification model and so people think
1162.64|3.919|it's easier than it actually is but I
1164.64|4.2|think some of the major challenges are
1166.559|3.521|that there's so many different languages
1168.84|5.199|uh they're written in many different
1170.08|5.32|ways and web text is very casual and so
1174.039|3.481|it can be very difficult to actually
1175.4|4.08|train a good classification model that
1177.52|4.519|can generalize to that and so what we
1179.48|5.52|did is you know we had our uh liid
1182.039|5.401|training data and we produced uh a
1185.0|5.08|language identification model liid and
1187.44|5.0|then we actually did human evaluation to
1190.08|5.0|label errors coming from the liid system
1192.44|5.0|to iteratively improve this on web text
1195.08|4.479|itself to improve the quality of of this
1197.44|4.0|specific model then after we produce
1199.559|4.0|this Li model then we insert like all of
1201.44|4.2|our common craw where the web arrow is
1203.559|4.641|coming in and we do a ton of filtering
1205.64|4.88|and cleaning and this produces a huge
1208.2|4.599|Corpus of different monolingual data
1210.52|4.84|that you can then use for for training
1212.799|4.481|anything afterwards uh we train our
1215.36|3.84|encoder the what I described on the
1217.28|4.12|previous text and then we convert this
1219.2|4.959|monolingual data into what we call Mind
1221.4|4.72|by texts so these are a huge data set of
1224.159|4.681|things that we think are translations of
1226.12|4.6|each other um and then find what we do
1228.84|4.719|is we actually try to validate that
1230.72|5.52|these are real mind B texts by training
1233.559|4.721|very small bilingual multilingual uh
1236.24|3.919|sorry bilingual translation models in
1238.28|3.519|order to see you know what the quality
1240.159|4.561|is like and I think this is important
1241.799|4.521|because like the data development cycle
1244.72|4.72|and like the end task that it's being
1246.32|4.839|used for uh you you don't want to you
1249.44|3.479|know like completely separate it an
1251.159|3.561|analogy to large language model training
1252.919|4.081|today is that like when you're doing
1254.72|4.079|your pre-training uh you don't want like
1257.0|3.84|someone to just deliver you a data like
1258.799|3.561|the data mix of your different data sets
1260.84|2.56|is very important and it's pretty uh
1262.36|3.72|similar
1263.4|4.56|here and I think one of the highlights
1266.08|4.28|that we that we did here is really like
1267.96|4.319|focused on the human evaluation of the
1270.36|3.48|language identification model because
1272.279|3.481|that actually improves the quality of
1273.84|3.439|like all of the underlying data if you
1275.76|2.72|just like more accurately know what
1277.279|4.0|language it's
1278.48|4.439|in and this entire data pipeline is
1281.279|4.121|actually open sourced in this library
1282.919|3.521|and we had an emlp paper describing it
1285.4|3.0|the reason why I thought this was
1286.44|3.4|important is that because like I think
1288.4|3.48|data cleaning is actually such a
1289.84|3.92|fundamental underlying thing that drives
1291.88|3.56|model quality and people's data
1293.76|3.039|pipelines you know it's like I have this
1295.44|2.92|script and this other thing and that
1296.799|3.36|this other thing and so it's actually I
1298.36|4.64|think very important to be able to
1300.159|4.801|recreate it and rerun it um as part of
1303.0|4.039|you know almost like your your research
1304.96|4.56|uh that you would do um as follow-up
1307.039|5.441|work and so that's why we open sourced
1309.52|5.639|them a few reflection
1312.48|4.72|things for low resource languages even
1315.159|3.88|though we did a a large scale mining I
1317.2|3.64|think monolingual data is the limiting
1319.039|3.961|factor like there are many languages
1320.84|4.68|that do not have like a huge amount of
1323.0|5.12|text written online and so it can be
1325.52|4.48|very challenging to get a large amount
1328.12|4.6|further I think languages and unique
1330.0|4.6|scripts can be extremely hard to get
1332.72|4.04|good representations of if you don't
1334.6|3.76|have very much data um there are certain
1336.76|3.72|languages as well where they were
1338.36|3.84|historically written in a new script but
1340.48|4.439|now the government would like to write
1342.2|5.2|it um in a totally new one like the old
1344.919|4.64|cheeky script for example and so there's
1347.4|4.0|not a lot of content uh to represent
1349.559|4.201|these scripts so it's hard to learn
1351.4|5.24|representations and then further a lot
1353.76|4.919|of the content we create it's even after
1356.64|3.919|mining it's a fairly limited domain
1358.679|5.721|often religious
1360.559|5.881|content okay so uh with data discussed I
1364.4|4.519|want to segue a little bit into into
1366.44|5.359|some of the modeling work just to kind
1368.919|4.36|of start with like a highlevel picture I
1371.799|2.961|think there's like three major
1373.279|3.76|challenges when you talk about like
1374.76|3.72|large scale multilingual modeling and
1377.039|3.681|these pretty much apply
1378.48|4.799|um to language models as
1380.72|4.72|well the first one is effective data
1383.279|4.4|augmentation for low resource languages
1385.44|4.28|like how can you prevent the low
1387.679|3.921|resource language data from just being
1389.72|3.4|completely drowned out by the time
1391.6|4.12|you've seen like all of your words of
1393.12|4.559|German or Russian I think there's also a
1395.72|4.319|question of like scalability of the
1397.679|4.24|model so even if you train very large
1400.039|3.76|scale models how do you prevent the
1401.919|3.841|representations of different languages
1403.799|3.841|from interfering with each other and
1405.76|4.039|that leads to the last Point as well of
1407.64|4.159|like you give the model very limited
1409.799|4.0|capacity then of course it may not have
1411.799|3.921|the capacity to model all of these
1413.799|5.441|different languages and so you also need
1415.72|8.0|to accelerate uh the scale of the model
1419.24|6.08|and so preliminary for for those uh who
1423.72|2.839|may not have seen a translation system
1425.32|3.839|before I don't know how many of you that
1426.559|4.641|practically is um so we use standard
1429.159|3.76|sequence to sequence models so the input
1431.2|3.359|text the like Coral thing is like what
1432.919|4.24|you want to translate enters a
1434.559|4.081|Transformer decoder model um that then
1437.159|3.64|you know with attention mechanism goes
1438.64|4.919|to a Transformer decoder model and then
1440.799|5.081|it decodes autor regressively the actual
1443.559|4.48|translation which you can see here in
1445.88|5.24|yellow and so I want to talk a little
1448.039|4.961|bit about like how uh the data looks as
1451.12|3.08|we feed it into the models so there's a
1453.0|3.2|few different ways that you might want
1454.2|4.4|to think about data so you want to be
1456.2|4.079|like okay did a human look at it and
1458.6|4.36|decide that like these two sentences are
1460.279|5.4|translations or are they noisy also is
1462.96|4.16|it is it limited in size another thing
1465.679|3.88|you can think about is like is the data
1467.12|3.919|quality depending on some other factor
1469.559|2.6|and so that's like the model dependent
1471.039|3.24|thing in which case like the data
1472.159|5.12|quality may be capped by the quality of
1474.279|5.241|that dependency um and so I think you
1477.279|4.081|could think a little bit like the ideal
1479.52|4.08|data set it would be like humans have
1481.36|4.559|reviewed you know every bit of it it's
1483.6|4.28|not noisy at all we have an infinite
1485.919|3.601|amount and it doesn't have any
1487.88|4.039|dependencies on any other models it's
1489.52|5.0|just like pure quality but in reality
1491.919|3.721|like closer to what we have are these so
1494.52|3.44|we have a bunch of different data
1495.64|4.36|sources we have the seed data that I
1497.96|4.04|discussed like way back in the talk
1500.0|4.679|where it's a small amount of like really
1502.0|4.44|high quality human Align data but the
1504.679|3.961|only problem is that it's limited in
1506.44|5.119|size it's like 6,000 sentences per
1508.64|4.88|language we have the public by text so
1511.559|3.24|this is data that people have created
1513.52|2.879|over many years of working on
1514.799|4.201|translation you know you can download it
1516.399|5.441|from like the Opus uh Corpus for
1519.0|5.679|example mostly has not been reviewed by
1521.84|4.4|humans so pretty extremely noisy in many
1524.679|3.961|languages it's just coming from the
1526.24|4.039|Bible so the size is quite Lim
1528.64|4.32|you have our mind
1530.279|5.681|data uh so this is not human aligned
1532.96|4.64|either um and but it does have a model
1535.96|3.8|dependency you know it's dependent on
1537.6|4.52|the quality of the sentence encoders and
1539.76|4.799|we have two other sources of data uh
1542.12|3.88|from back translation so the idea of
1544.559|3.24|back translation it's a model
1546.0|3.72|augmentation technique heavily used in
1547.799|3.921|machine translation where you use a
1549.72|4.839|model to produce like pseudo
1551.72|4.679|translations like silver data um and we
1554.559|3.84|use two different techniques to produce
1556.399|4.16|these back translations that also are
1558.399|4.241|dependent on the underlying model used
1560.559|3.521|to used to make the translations so this
1562.64|3.159|is a picture of like our high level
1564.08|3.24|different data sources and like how you
1565.799|4.041|want to think about the quality and the
1567.32|4.599|different axes and so if we put them all
1569.84|5.079|together what do we get so the y- axis
1571.919|5.24|here is the number of training Pairs and
1574.919|4.64|the x-axis here is the languages sorted
1577.159|3.88|by resource so you can see like on the
1579.559|4.24|on the left hand side you have your low
1581.039|4.12|resource languages like wof and on your
1583.799|3.401|uh right hand side you've got your high
1585.159|4.801|resource languages like French uh the
1587.2|4.12|peak is is English of course and so if
1589.96|4.24|you just look at what's available
1591.32|5.359|publicly this is a distribution you get
1594.2|5.199|and you'll see like a huge huge fallof
1596.679|5.12|pretty quickly and then if you add in
1599.399|4.121|the data that we have created for Mining
1601.799|3.88|and back translation our goal is
1603.52|4.759|basically to like make the distribution
1605.679|5.201|a little bit more uniform it's very hard
1608.279|4.28|on the extremely low resource side uh of
1610.88|3.2|course but to make it a little bit more
1612.559|3.801|uniform so that you don't just
1614.08|4.12|immediately you know overfit on your low
1616.36|3.319|resource languages before you you've
1618.2|3.12|even seen like three shards of your
1619.679|4.841|German
1621.32|4.839|data with that kind of data strategy in
1624.52|4.2|mind I want to talk a little bit about
1626.159|4.281|mixt mixture of experts so this is
1628.72|3.64|something that we explored quite uh
1630.44|4.28|aggressively in the translation space
1632.36|4.12|for a number of years um you know we
1634.72|3.24|could have this equal conversation about
1636.48|3.84|some of the debates going on on like do
1637.96|5.079|you want sparse or DSE architectures for
1640.32|4.76|large language models uh but essentially
1643.039|4.561|mixture of experts it enables massive
1645.08|4.4|scale because you don't have to just
1647.6|3.799|scale like your kind of your dense trunk
1649.48|3.76|model uh but you can have like a bunch
1651.399|5.481|of different separate experts that you
1653.24|5.72|activate per token um it also allows you
1656.88|4.0|to avoid language interference because
1658.96|3.76|the idea is that the different experts
1660.88|4.399|they could specialize to specific
1662.72|5.199|languages um unfortunately it adds a ton
1665.279|5.441|of capacity so it becomes pretty easy uh
1667.919|5.48|to overfit so I want to talk a little
1670.72|4.559|bit about this overfitting phenomenon so
1673.399|4.28|the top set set of graphs that we're
1675.279|5.321|going to talk about is for the language
1677.679|4.72|um Congo and then the bottom set of
1680.6|3.52|languages is French so you really want
1682.399|3.76|to compare like a low resource language
1684.12|4.12|on top with a high resource language on
1686.159|4.201|bottom so if you just take your dense
1688.24|3.76|model traditional Transformer sequence
1690.36|3.84|to sequence architecture that's this
1692.0|3.559|graph that you're showing right so
1694.2|3.199|there's a little bit of overfitting on
1695.559|3.321|the low resource language but you can
1697.399|3.681|pretty much regularize this with
1698.88|3.799|standard Dropout techniques right so
1701.08|4.16|there's not a big problem and on French
1702.679|4.921|you know you you basically have no real
1705.24|3.76|problem however the minute you switch
1707.6|4.4|from like a dense architecture to a
1709.0|5.159|token level Moe architecture uh you just
1712.0|4.36|experience massive overfitting on the
1714.159|4.12|low resource language so the the green
1716.36|4.0|line here is like just demonstrating
1718.279|3.961|without Dropout the overfitting and then
1720.36|3.64|if you add Dropout you know you get a
1722.24|3.96|little bit better performance but it's
1724.0|4.919|still overfitting quite a bit like
1726.2|4.199|essentially by like you know 12K updates
1728.919|2.801|you know there's there's no real point
1730.399|4.52|in continuing training like you're
1731.72|4.679|burning GPU basically um and so one of
1734.919|3.441|the things we actually worked on quite a
1736.399|4.52|bit was like trying to to figure out how
1738.36|4.72|to properly regularize thesee
1740.919|3.961|architectures with this uh specific
1743.08|3.88|masking technique on on the gating
1744.88|3.72|function that decides like whiche to
1746.96|3.88|route to sorry which expert to route to
1748.6|4.04|in youre architecture to just try to
1750.84|4.4|pull back some of this overfitting
1752.64|4.68|effect so if you look in the in the top
1755.24|4.96|uh right graph the purple line you know
1757.32|4.599|you still see some uh you know
1760.2|3.839|successful
1761.919|4.721|regularization another thing that we did
1764.039|4.281|to control uh the overfitting effect
1766.64|3.68|it's actually quite being used in um
1768.32|4.92|language models today as well is
1770.32|5.32|curriculum learning and the idea of this
1773.24|4.6|is like how are we going to Stage when
1775.64|4.279|languages are introduced and so what we
1777.84|4.079|did was we tried to train a vanilla
1779.919|4.201|model and then we started to measure
1781.919|4.281|when the languages begin to overfit and
1784.12|4.72|then we basically bucket them did them
1786.2|4.04|into different sections and so for high
1788.84|3.079|resource languages like French you want
1790.24|4.039|to start it early and it needs to be
1791.919|5.041|trained the entire way but for a lower
1794.279|5.681|resource language like w you know after
1796.96|4.92|maybe like 100K updates it's done so the
1799.96|3.16|rest of the time is just overfitting and
1801.88|3.08|so it actually gets worse the more you
1803.12|3.84|train it so what we did is we moved some
1804.96|3.68|of those lower resource languages and we
1806.96|3.559|inserted them much later into the
1808.64|3.2|training schedule so you start training
1810.519|3.121|your high resource then you start
1811.84|3.04|training your low your mid resource and
1813.64|3.519|then your low resource and then you're
1814.88|4.44|very low resource and so by the end you
1817.159|4.4|know everything in theory has trained
1819.32|3.68|and is not as overfit as it would be
1821.559|4.041|without this kind of
1823.0|4.32|technique so I want to show some results
1825.6|4.439|so first I want to show results on
1827.32|4.4|existing data sets so before we get to
1830.039|4.081|200 languages like let's just talk about
1831.72|5.079|100 languages and so this is the Flores
1834.12|4.279|101 Dev test it's important to compare
1836.799|4.281|to this because this is where like
1838.399|4.321|existing benchmarks in the community lie
1841.08|3.839|um whereas on 200 of course we can put
1842.72|6.199|up anything you know because it's the
1844.919|6.401|first work on that so the First Column
1848.919|4.801|is uh translating out of English so
1851.32|4.319|English to Chinese English to Icelandic
1853.72|4.24|anything like that the second column is
1855.639|5.52|translating into English so Chinese to
1857.96|5.88|English the third column XX y y is
1861.159|4.441|translating any cross pair not involving
1863.84|3.88|English and the last column is the
1865.6|4.4|average so if you look at the first set
1867.72|4.76|of rows this is a comparison on models
1870.0|4.88|that cover 87 different languages so
1872.48|4.679|there was this paper MTM 100 there was
1874.88|4.56|also this deep net paper so you can see
1877.159|4.161|the average blue score blue is a
1879.44|4.32|standard translation metric essentially
1881.32|4.959|metric of word overlap um so we're
1883.76|5.879|looking at Blue score here and so you
1886.279|5.601|can see the last row N lb 200 um even
1889.639|4.441|though we cover 200 languages the blue
1891.88|4.88|score is substantially uh above some of
1894.08|4.88|the existing work now if we look at 101
1896.76|4.279|languages only the Delta LM paper from
1898.96|3.8|Microsoft at the time covered that uh
1901.039|3.841|number of languages and so if you
1902.76|4.639|compare on all of the different cross
1904.88|5.399|sets uh similarly you see that this no
1907.399|4.921|language Left Behind model is um much
1910.279|3.681|stronger in terms of blue one thing
1912.32|3.16|really quick on the variance of these
1913.96|3.319|blue numbers I think it's important to
1915.48|4.799|understand like is something statistic
1917.279|5.52|Al significant or not I think about 0.5
1920.279|4.88|blue is kind of like the the general
1922.799|4.6|like plus minus that you'll see and so
1925.159|4.321|if it's like above that you'll it's
1927.399|4.841|usually a statistically significant
1929.48|4.6|metric Improvement okay so now I want to
1932.24|4.039|talk a little bit about floor as 200
1934.08|4.04|results so here similar like the first
1936.279|3.64|chunk of columns translating out of
1938.12|3.72|English then like next chunk is
1939.919|3.76|translating into English then you have
1941.84|4.6|like your cross Pairs and then you have
1943.679|5.321|your average um so we have this blue
1946.44|7.04|metric as well we also have a character
1949.0|5.72|level metric um based on CHR f++ that's
1953.48|2.96|commonly used in the translation
1954.72|2.959|community so I think looking at these
1956.44|3.16|numbers of course like there's no
1957.679|4.201|Baseline work to compare to on like on
1959.6|4.0|the previous slide and so you know when
1961.88|4.36|we get to human evaluation in a little
1963.6|5.0|bit it'll be more concrete but I think
1966.24|3.84|generally one of the kind of rules of
1968.6|4.52|some I have for these types of numbers
1970.08|7.12|is like around 30 is like pretty pretty
1973.12|5.439|reasonably becomes uh usable um and I
1977.2|4.56|think another thing like if you compare
1978.559|5.441|these supervised um pairs to zero shot
1981.76|4.279|pairs I think we don't see like a huge
1984.0|3.279|drop off on zero shot which indicates
1986.039|3.161|the model has like some sort of
1987.279|4.441|generalization even if it didn't see
1989.2|5.0|that translation pair uh directly during
1991.72|4.199|training another way to to calibrate
1994.2|3.64|some of this is to compare to Google
1995.919|4.081|Translate and so if you compare to
1997.84|3.6|Google translate um no language Left
2000.0|4.159|Behind is quite a bit better at
2001.44|4.32|translating um into English and not as
2004.159|3.081|good as translating out of English
2005.76|4.72|although if you like average across
2007.24|5.36|everything um it's a little bit
2010.48|4.319|better I want to talk a little bit about
2012.6|5.039|human evaluation as well to complement
2014.799|4.72|some of our discussion on automatic
2017.639|4.64|evaluation and so I think you know
2019.519|4.841|automatic metrics fast really good for
2022.279|4.76|research iteration uh impossible to move
2024.36|5.199|forward without but human evaluation uh
2027.039|5.401|is really the the real deal here and so
2029.559|4.6|we had this paper at AMTA um on how to
2032.44|3.959|make this human evaluation very
2034.159|3.36|consistent and scalable across different
2036.399|2.64|language pair
2037.519|3.601|I think this goes back to the kind of
2039.039|3.76|evaluation data set point that I was
2041.12|3.799|making at the beginning of the talk
2042.799|3.921|where you know if you're a professional
2044.919|3.72|German translator you're really good at
2046.72|5.159|evaluating the quality of your German
2048.639|5.52|translation um but beyond that you know
2051.879|5.28|there's not a lot of consistency and if
2054.159|5.72|you evaluate translation on like a fiveo
2057.159|4.321|scale you know like a five translating
2059.879|3.081|between two languages and like a three
2061.48|3.72|translated between other two languages
2062.96|4.119|like are those really comparable and so
2065.2|4.56|we had this entire experiment method
2067.079|4.08|ology on how we might want um to make
2069.76|3.639|this a little bit more
2071.159|6.0|comparable so I want to show some
2073.399|6.68|results now on this so the Y AIS here so
2077.159|5.0|the metric is called xsts a metric for
2080.079|4.401|how we're doing this human evaluation
2082.159|5.2|the y- axis here is actually the
2084.48|5.679|Delta uh so anything you know it's a
2087.359|5.961|fivepoint scale so it's it's a Delta not
2090.159|4.44|the raw score um the x-axis here is a
2093.32|3.92|bunch of different translation
2094.599|5.321|directions that we evaluated so the gray
2097.24|5.08|set is translating into English the
2099.92|7.199|green set is translating non-english
2102.32|6.759|directions so like uh French to wof and
2107.119|4.361|then the blue set is translating out of
2109.079|5.601|English and so what you're looking for
2111.48|5.0|is like a positive Delta indicates that
2114.68|4.8|um our modeling architecture is much
2116.48|5.68|better so the what the Delta is between
2119.48|4.879|is like a a baseline Transformer model
2122.16|3.919|just trained on all of our data versus
2124.359|2.961|like the final no language Left Behind
2126.079|3.0|model that we created
2127.32|3.6|so the data is actually the same for
2129.079|4.081|both of them that's how we get all 200
2130.92|4.32|languages um so we're just measuring
2133.16|4.0|here the human eval of the modeling
2135.24|5.96|improvements and so you can see most of
2137.16|7.76|the Delta is pretty um pretty noticeable
2141.2|5.879|um some of them not so much like um you
2144.92|3.8|know I don't know Zulu to English we
2147.079|3.321|didn't seem to improve very much but in
2148.72|4.04|general like it's a Improvement
2150.4|3.679|detectable by human evaluation you might
2152.76|3.28|also ask like okay what is the
2154.079|5.441|statistically significant difference
2156.04|5.84|here between about 0.2 to 0.3 plus or
2159.52|4.839|minus is something that's like uh pretty
2161.88|4.12|noticeable and like above 0.5 it's it's
2164.359|3.72|very
2166.0|4.76|noticeable one of the things that I also
2168.079|6.081|want to get at in evaluation is that
2170.76|5.599|there's many different um facets of
2174.16|3.8|model evaluation and I think if you look
2176.359|3.441|at like all of the different like llm
2177.96|3.76|leaderboards or like the transparency
2179.8|4.0|reports or whatever you like begin to
2181.72|3.72|internalize this pretty quickly but what
2183.8|3.72|we just looked at are just like very
2185.44|3.72|highlevel summary num numers and they
2187.52|4.04|don't really tell you like what exactly
2189.16|4.679|are the errors and like is It ultimately
2191.56|4.24|usable by people is it like a safe thing
2193.839|4.441|that people can rely on and so one of
2195.8|5.24|the things we really focused on is uh
2198.28|4.92|user safety and some of that manifests
2201.04|4.6|in um some of the toxicity work that we
2203.2|4.32|did and the driving thing here is that
2205.64|3.88|like not all errors in Translation are
2207.52|3.96|made equal so during covid there was
2209.52|3.96|this one that was like really went viral
2211.48|3.44|circulating around but the message
2213.48|3.48|during Co is like you got to wash your
2214.92|3.88|hands but the translation produc is like
2216.96|4.159|you got to hold hands which I think is
2218.8|4.0|like exactly the opposite of of what you
2221.119|3.161|want to do and other types of
2222.8|3.279|measurement errors are are really
2224.28|3.799|important as well so if you're like
2226.079|3.24|telling someone how far they want to go
2228.079|2.961|and you're like hey you want to travel
2229.319|3.401|like five kilometers and then your
2231.04|3.4|translation is like travel 500
2232.72|4.72|kilometers you know it's a completely
2234.44|5.159|different type of issue and so what we
2237.44|4.32|did for toxicity which is a big Focus
2239.599|4.961|for this work is that we collected
2241.76|5.0|different toxicity lists for all 200
2244.56|4.0|languages and so why do I care so much
2246.76|3.92|about toxicity I think it's a it's a
2248.56|4.279|user safety thing so if you input like
2250.68|4.28|some perfectly benign text and then the
2252.839|4.361|output is profanity I think it's just
2254.96|4.52|like really unexpected and it breaks a
2257.2|4.8|lot of trust in the system and it's an
2259.48|4.16|extremely poor experience for people
2262.0|3.72|that that being said it's also a very
2263.64|4.479|very challenging thing because it's
2265.72|5.32|extremely culturally specific so things
2268.119|5.361|that are slurs or you know insults in
2271.04|5.279|certain languages They Don't Really
2273.48|5.56|generalize across cultures which means
2276.319|4.601|that things like this are uh very
2279.04|3.079|challenging to create and I also was
2280.92|3.36|very interested in this direction
2282.119|3.641|because I think it's broadly useful for
2284.28|3.799|all sorts of different type of uh
2285.76|4.2|detection uh things that you need to do
2288.079|3.601|and also mitigation and so even though
2289.96|4.2|we developed this in the context of
2291.68|4.919|translation it can be used very broadly
2294.16|4.8|in other types of NLP
2296.599|3.72|applications um this is also open source
2298.96|3.399|you can download it you have to type in
2300.319|3.881|a little password U that's uh in the
2302.359|3.521|GitHub repo just so that you don't
2304.2|3.48|accidentally like download and realize
2305.88|3.52|you have files of like curse words all
2307.68|4.08|over all over your
2309.4|4.0|computer okay so I want to end a little
2311.76|4.2|bit with some thoughts about future
2313.4|5.64|directions U and before I get there like
2315.96|4.6|you know there's like a 190 page paper
2319.04|4.0|uh that like writes up like all of this
2320.56|3.72|in far greater detail um in case you're
2323.04|4.2|you're
2324.28|5.079|curious so a few future directions that
2327.24|3.879|I think I'm really interested in and
2329.359|3.96|some of these like are also very
2331.119|5.081|applicable to things like speech is that
2333.319|5.881|I think one of them is more explicit
2336.2|4.44|multi multilingual so I think a lot of
2339.2|3.48|approaches to multilingual have been
2340.64|3.679|like hey you know we have this thing
2342.68|4.159|it's working well for one language like
2344.319|3.841|let's try to scale it to a bunch of
2346.839|2.801|different languages and then we're going
2348.16|3.56|to put them all in the same modeling
2349.64|3.959|bucket and just kind of like hope that
2351.72|3.639|the model learns all of these different
2353.599|5.281|representations but I think there's a
2355.359|5.76|lot of potential room for explicitly
2358.88|4.199|bringing in like the fact that you know
2361.119|6.521|it's multilingual into the
2363.079|7.801|architecture um more and so you know
2367.64|4.679|it's possible to capture more nuances
2370.88|4.719|between languages or different
2372.319|4.881|relationships between languages um the
2375.599|3.601|other one is continued support for
2377.2|4.32|everyone I think it's like something
2379.2|4.879|reflecting on this project is that you
2381.52|4.839|know going from 100 to 200 was already
2384.079|3.841|pretty challenging but going Beyond a
2386.359|4.641|lot of the techniques that we developed
2387.92|4.72|here are not necessarily that scalable
2391.0|3.599|um this is actually what inspired some
2392.64|3.88|of our work on speech translation as
2394.599|4.121|well so if you recently saw like the
2396.52|3.96|seamless m4t release or like the
2398.72|3.8|unwritten languages like we did a lot of
2400.48|4.119|modeling of hokan and I think that goes
2402.52|3.48|into the this direction really well
2404.599|3.76|because many of the languages that
2406.0|4.839|people uh want to use are like spoken
2408.359|3.601|first languages and not necessarily like
2410.839|3.321|primarily
2411.96|3.879|written and then I think the last thing
2414.16|4.52|that I'm still really passionate about
2415.839|4.641|is like continued increased ease of use
2418.68|4.679|and training of these models and like
2420.48|4.599|democratization for the community so one
2423.359|3.921|of the things that we try to do in this
2425.079|4.24|work is just like really really clearly
2427.28|3.64|write down everything that we did and
2429.319|3.601|like open source like even the data
2430.92|3.04|Pipeline and things like that and so
2432.92|4.0|that's where you get like all of the
2433.96|4.68|repos that I linked and um you know like
2436.92|3.28|a huge write up but I think if someone
2438.64|3.439|were to try to reproduce this for their
2440.2|3.96|own language and many people have like
2442.079|4.28|I'm not saying that that hasn't been but
2444.16|5.159|it's like if you wanted to like do this
2446.359|4.881|it would be extremely extremely hard um
2449.319|3.76|because there's like so much different
2451.24|3.4|uh things going on so I think most of
2453.079|3.401|the what we've seen is like people have
2454.64|3.8|downloaded the base model and fine tuned
2456.48|4.639|it for their own language but it's
2458.44|4.6|pretty hard to just like add on um many
2461.119|3.681|many more languages to the system
2463.04|4.0|because of how complicated all the
2464.8|4.039|moving parts are and so I feel like
2467.04|4.24|something for the translation Community
2468.839|4.52|overall is like how do how do we
2471.28|3.12|simplify a lot of these things and I
2473.359|3.641|think that's where like a lot of
2474.4|5.919|fundamental modeling uh Innovation uh
2477.0|4.92|could help us get to and so yeah I got a
2480.319|4.121|chance to give this talk but of course
2481.92|5.0|the work is like being done by a a huge
2484.44|5.72|team of people that I've cited here
2486.92|4.439|um and yeah if you want to uh use any of
2490.16|2.76|this or read more about it like
2491.359|4.801|everything is linked from this main
2492.92|5.12|GitHub repo here um in Fair seek and you
2496.16|4.439|can like click on everything else
2498.04|5.16|afterwards um but yeah maybe maybe I'll
2500.599|4.681|go back to Stephen um if we have any
2503.2|3.68|questions or anything else like that
2505.28|3.52|right no thanks for the great talk yeah
2506.88|4.92|if anybody has any questions feel free
2508.8|3.0|to unmute and
2515.24|3.44|ask
2517.04|5.0|uh did you consult with a lot of like
2518.68|5.76|native speakers um for like you know
2522.04|5.12|profanities and this type of stuff like
2524.44|5.52|how are you able to get access to the um
2527.16|4.4|you know lowquality languages or low
2529.96|4.24|resource languages and make sure the
2531.56|4.0|translations are correct yeah yeah
2534.2|2.84|that's a really good question I mean I
2535.56|3.999|think it's the most important to consult
2537.04|4.799|like a bunch of native speakers um
2539.559|3.8|across the entire development process so
2541.839|3.161|part of our original thing was just like
2543.359|2.881|interviewing a bunch of people to
2545.0|3.72|understand like what they're looking for
2546.24|4.68|for in a high quality translation and
2548.72|4.0|then we have like an entire uh
2550.92|5.159|professional translation team hired
2552.72|6.56|which took quite a long time to find um
2556.079|5.841|to to consult with along along um the
2559.28|4.279|process and then right now like we also
2561.92|3.399|have some of the things like toxicity
2563.559|3.681|lists are open to the community so if
2565.319|3.881|you make like a poll request we try to
2567.24|3.52|like you know validate that it's like a
2569.2|5.84|a useful addition and then like try to
2570.76|4.28|merge it in um as
2575.16|3.28|well
2576.76|6.76|we have a question in the room let's see
2578.44|7.8|if it comes over soon goe I'll speak
2583.52|6.599|see so like do you spend most of your
2586.24|7.64|time in the data pipeline stage um
2590.119|4.96|yeah yeah yeah a good question um I
2593.88|2.88|think the question is did you spend most
2595.079|3.441|of your time in the data pipeline state
2596.76|5.52|it ended up being about like kind of
2598.52|6.16|like 5050 like uh data or more like uh
2602.28|3.92|driving work and then like 50/50 on on
2604.68|3.36|the the other side like modeling and
2606.2|4.52|evaluation work because once like the
2608.04|4.4|data is set then there is a lot and lot
2610.72|4.16|of iteration on the modeling side to
2612.44|3.679|figure out like okay which how much of
2614.88|2.6|the data should we use like how should
2616.119|2.48|we portion the data how do we prevent
2617.48|4.0|overfitting what is the right
2618.599|4.441|architecture um but a lot of work goes
2621.48|3.76|into the data because I think if you
2623.04|4.92|don't have high quality data you know
2625.24|6.2|you you just can't get a good
2627.96|5.72|model and for data mining how do you
2631.44|5.399|mind the data do you use like selenium
2633.68|5.32|or how do you mind the web
2636.839|4.601|um yeah so for the web we start with
2639.0|4.319|common craw um so we downloaded all of
2641.44|4.96|the different dumps of common crawl and
2643.319|4.28|then we use um HTML parser I think now
2646.4|2.88|like you know if you download for
2647.599|3.161|example the red pajama data set like
2649.28|3.839|they've done a lot of this like parsing
2650.76|5.079|and stuff um and then we have like large
2653.119|5.161|scale uh pipelines that are set up like
2655.839|4.201|you can use spark for example um to
2658.28|3.68|process these things to like split all
2660.04|3.76|of the different sentences out run your
2661.96|4.44|language identification you know you can
2663.8|3.96|do different heuristic cleaning um there
2666.4|2.919|are certain languages where it's like
2667.76|3.359|very actually very challenging to
2669.319|5.161|identify what is a sentence like I think
2671.119|5.601|in Thai there is no like period so you
2674.48|3.76|have to like use uh different models to
2676.72|3.8|identify what is a sentence and like
2678.24|3.96|parse some of those things out um and
2680.52|5.039|then we end up with you know our
2682.2|3.359|monolingual uh data
2685.76|6.359|dump what is Comm Crow is it software
2689.319|4.76|that you use for data oh yeah yeah
2692.119|4.321|common crawl is kind of like a an open
2694.079|4.161|source version of the web that that runs
2696.44|3.44|I think maybe quarterly I would have to
2698.24|3.8|check but yeah if you go to like common
2699.88|5.239|craw.org you can download it but warning
2702.04|3.079|it's like um very
2711.559|4.04|large hey I have a question um you might
2714.2|3.919|have mentioned this briefly but I'm
2715.599|5.24|wondering how chat gbt and gb4 does on
2718.119|5.081|this um like just just does just more
2720.839|4.561|scale and pre-training data help as well
2723.2|3.76|for um low resource U machine
2725.4|2.959|translation
2726.96|3.399|yeah yeah good question actually there
2728.359|3.641|have been some studies done on like how
2730.359|3.401|you know these systems work I think for
2732.0|4.68|high resource languages it's actually
2733.76|4.88|quite beneficial um to scale up I think
2736.68|4.159|part of that is because the models have
2738.64|3.679|some innate generalization and so one of
2740.839|3.041|the challenges that people talk about
2742.319|3.76|different things in different languages
2743.88|3.719|so like seeing that knowledge in another
2746.079|3.721|language can actually help the
2747.599|5.24|generalization but on low resource
2749.8|5.88|languages it's um yeah the performance
2752.839|5.0|is pretty difficult um especially on
2755.68|4.48|some of of these translation benchmarks
2757.839|3.641|I also think that language models in
2760.16|3.52|terms of being trained for like a
2761.48|4.119|translation objective tend to score
2763.68|3.879|worse on translation benchmarks because
2765.599|3.321|language models are like approximately
2767.559|3.081|capturing the same thing whereas
2768.92|4.12|translation models you like really try
2770.64|4.719|to align the meaning a little bit more
2773.04|5.2|um but yeah so I think for low resource
2775.359|4.801|still pretty challenging um but yeah one
2778.24|3.44|one thing that's interesting is uh for
2780.16|3.52|most English language models they can
2781.68|3.52|actually do a reasonable job at
2783.68|3.32|producing other languages because it's
2785.2|4.04|impossible to get rid of other languages
2787.0|6.52|in your English specific data so things
2789.24|4.28|like French or German will work
2795.28|4.64|reasonably so just to clarify you said
2798.079|3.201|language models trained with a
2799.92|5.08|translation
2801.28|5.64|objective do better right
2805.0|4.0|because they tend to do better like if
2806.92|4.0|you fine- tune for the translation task
2809.0|3.72|uh it it will tend to do better that
2810.92|5.919|makes sense compared to like for example
2812.72|6.56|some few shot um in context examp poster
2816.839|3.72|right right exactly exactly and one
2819.28|3.319|other question
2820.559|4.641|is
2822.599|4.96|um do you see this being similar to for
2825.2|5.6|example fine tuning on particular expert
2827.559|6.841|domains which might also have
2830.8|5.48|um less data and low resource and as
2834.4|3.4|well as domain specific jargon and so
2836.28|4.0|forth
2837.8|4.319|um yeah I mean I think if we were to
2840.28|3.52|restart this project now I think that
2842.119|3.761|would be one of the first things we also
2843.8|3.88|explored at least like an extremely
2845.88|3.28|strong Baseline where if you like take
2847.68|3.919|some of the data and you try to
2849.16|4.6|fine-tune um or you know try to do
2851.599|3.881|domain adaptation I think that's also
2853.76|4.319|where like some of the like retrieval
2855.48|4.079|type approaches uh go in for you know
2858.079|3.24|translation but also large language
2859.559|3.481|modeling work where you try to have like
2861.319|4.52|a separate domain that you can like
2863.04|6.519|retrieve some text in for adaptation I
2865.839|3.72|think all of those approaches are pretty
2873.359|4.361|promising oh great any other questions
2879.4|4.88|one quick one on the point ofil on one
2882.079|4.841|of the slides I think you showed some
2884.28|6.0|Peak results with zero shot that were
2886.92|5.48|higher than um just the base model do
2890.28|3.92|you think that's because there might
2892.4|5.679|still be some overfitting on those slow
2894.2|6.24|resource languages yeah good question so
2898.079|5.161|for our large scale mining we don't mind
2900.44|5.8|like every single possible cross pair so
2903.24|4.92|like like Icelandic wof
2906.24|4.119|it's probably like not like the most
2908.16|4.64|inand translation Direction and so we
2910.359|3.72|did not mind like all 200 times 200
2912.8|3.48|because it's like really producing like
2914.079|4.321|a combinatorial explosion and so that's
2916.28|4.279|where the zero shot results come from
2918.4|4.199|where you know you don't need uh we
2920.559|4.0|don't have training data D directionally
2922.599|4.601|in that pair but the model has seen both
2924.559|6.0|the input and the output and so I think
2927.2|5.399|those results are pretty good in well
2930.559|3.28|they're good for certain langu languages
2932.599|3.561|which I think goes to show like the
2933.839|5.28|generalization capability
2936.16|4.919|um and it's not like as critical to have
2939.119|3.561|like every single pair covered but many
2941.079|3.681|of them are are not as good and so you
2942.68|3.52|see overall the performance is lower
2944.76|3.24|even though on certain languages it can
2946.2|3.24|perform better than you expect but
2948.0|3.4|that's because it has seen the input and
2949.44|4.84|the output it's not zero shot on like
2951.4|2.88|completely unseen
2960.92|3.56|language I have a
2964.52|6.839|question I wanted do you also you know
2968.0|5.52|do something related to transcription or
2971.359|4.601|audio
2973.52|4.4|information yeah good question so in
2975.96|3.92|this project no not so much
2977.92|3.24|transcription but we had a follow-up
2979.88|3.919|work that we released actually just like
2981.16|5.32|a month or or so ago uh called seamless
2983.799|5.0|m4t which is like a joint model for both
2986.48|4.04|speech and text translation and that's
2988.799|4.121|where we do leverage a lot of audio
2990.52|4.2|transcription because that also has like
2992.92|3.6|the it helps us Bridge you know like the
2994.72|4.839|spoken data and the text data to
2996.52|3.039|leverage both of them
3007.24|4.599|together wait just to clarify the
3009.16|6.24|supervised fine tuning it worked better
3011.839|5.801|right compared to um other
3015.4|4.12|methods uh so actually in this work it
3017.64|4.159|was as a couple years ago now so
3019.52|4.68|supervised fine tuning wasn't H as
3021.799|4.28|common as it it was now but I think in
3024.2|3.879|the literature if you want to use like a
3026.079|3.52|large language model to do translation
3028.079|4.161|it's currently best yet if you do some
3029.599|4.561|supervised fine tuning I'm I'm just
3032.24|3.359|wondering about that because the way as
3034.16|4.639|humans right we don't
3035.599|4.72|just learn by looking at pairs of the
3038.799|3.961|same thing in different languages and
3040.319|4.76|kind of memorizing how to map from one
3042.76|4.72|to the other uh we kind of learn in a
3045.079|4.76|more unsupervised way where if we know
3047.48|5.92|both languages then we can kind of
3049.839|6.72|naturally translate between them
3053.4|6.0|um but I guess it makes sense for an llm
3056.559|5.76|why having supervis supervised examples
3059.4|5.52|would help you yeah I mean I think as
3062.319|4.721|like the the base Foundation model
3064.92|3.919|continues to improve in quality I think
3067.04|3.0|that's where the quality will probably
3068.839|3.561|improve when you don't need less and
3070.04|3.799|less fine tuning I mean I think that's
3072.4|3.08|like the open AI approach like if you
3073.839|3.321|have the best foundation model then you
3075.48|3.52|don't need as much like domain specific
3077.16|3.32|fine tuning and I think like you know
3079.0|2.799|like at the start when I started working
3080.48|2.4|on text generation there was like
3081.799|2.361|translation researchers and like
3082.88|2.88|summarization researchers and like
3084.16|3.52|question answering researchers and they
3085.76|3.359|like work very differently but now it's
3087.68|3.24|like it's all driven by the same
3089.119|5.48|underlying thing and you're not like a
3090.92|6.48|specialized summarization researcher uh
3094.599|5.281|anymore right I think that's that makes
3097.4|2.48|a lot of
3100.119|3.96|sense do we have any other
3113.72|8.399|questions come on any more inperson
3117.72|6.76|questions don't think so okay great all
3122.119|5.321|right well thank you Angela for the very
3124.48|6.44|interesting and a great talk again um
3127.44|5.72|and for taking the time and we hope um
3130.92|4.879|yeah we hope that you can keep in touch
3133.16|6.439|and if anybody has any other questions
3135.799|5.04|feel free to um get in touch with Angela
3139.599|3.801|all right thanks so much for having me
3140.839|2.561|today bye
3144.28|3.0|everyone