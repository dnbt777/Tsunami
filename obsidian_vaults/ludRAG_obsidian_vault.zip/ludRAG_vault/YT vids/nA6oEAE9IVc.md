start_time|end_time|text
2.04|4.8| Okay, let's now finish up this video by talking about how pytorch
6.88|3.48| handles weight initialization, and how we can change it if we
10.36|5.56| wanted to. So I looked at the current source code of pytorch,
15.92|2.8| because the other weight initialization that they do by
18.72|3.72| default, changed over the different version over time. So
22.44|4.92| currently in version 1.8, they use the climbing her uniform
27.36|3.68| weight initialization. So I found the source code a relevant
31.04|3.76| one here, if you want to check it out yourself. And this
34.8|3.36| corresponds to the fully connected to the linear layer.
38.88|2.76| For the convolutional layer, I saw it's the same though. So
41.64|3.44| they use the same weight initialization now for both the
45.08|3.32| fully connected and the convolution layer. In previous
48.4|2.96| versions, they had a slightly different weight initialization.
51.36|6.88| Yeah, and now looking at this here, you may wonder, besides
58.24|3.48| climbing uniform, what these different things are. So here,
61.72|4.68| this math square root five, this is I think, for the leaky relu.
66.76|3.8| So that is if you if you use a leaky relu, you would add that
70.56|3.4| number. So they are assuming that if you use a fully
73.96|4.68| connected layer, that you also use a leaky relu activation. In
78.64|5.56| practice, personally, I tried also using the zero, which is
84.2|3.92| usually what people would put in here for the regular relu. If I
88.12|2.4| use the regular relu, and I didn't really notice any
90.52|4.08| difference. So it might be better to use this for the leaky
94.6|3.24| relu and put set it to zero for the normal relu. I will show you
97.84|3.16| in the next slide how we can do that more conveniently than
101.04|3.1| modifying the source code. But in practice, personally, I didn't
104.14|5.1| notice a big difference. So yeah, here's an example of how
109.24|5.04| we could manually override the initialization that is done
114.28|4.08| automatically. Because if we initialize these layers, it will
118.36|5.2| basically execute this one to do the timing initialization. But
123.56|3.6| if we wanted to, we can override it. So how I like to do this, I
127.16|2.24| mean, in multiple ways, you can do it. But how I like to do it
129.4|4.24| is I like to put this for loop after my sequential loop. So
133.64|3.12| here, what I'm doing is I'm iterating through all the
136.8|5.0| modules in the network. However, here, I'm only interested in the
141.8|2.6| other fully connected modules, not in, let's say, relu, and
144.4|3.8| things like that. So here, I'm pulling out essentially only the
148.2|3.64| fully connected ones. And then I'm using torch and in it,
151.84|4.76| chiming uniform, and provided with the corresponding weight.
156.6|4.24| So the weight corresponding to m, the linear layer, and I'm
160.84|4.68| setting it to fan in and non linearity relu. So this is as
165.56|3.12| essentially the default, by the way, too. So this is what is
168.68|3.0| done by default, or not actually, that's not true. By
171.68|3.52| default, it should be leaky relu. But fan in, that's the
175.2|3.44| default. And usually, that's by default, leaky relu, I'm
178.64|4.3| changing it to relu. Personally, I don't don't notice any big
182.94|3.02| difference. Another thing, if you wanted to, you can set the
185.96|3.68| bias to zero, or you can use the initialization scheme they use
189.64|4.08| here. Also, for that, personally, I didn't notice any
193.72|4.4| difference. But I just trust that the pytorch developers did
198.12|4.48| a lot of testing and also considered community feedback.
202.72|5.6| So I think this one is probably better than this one. Except, of
208.32|3.54| course, yeah, the other one on the previous slide is more
211.86|4.54| geared towards leaky relu, and I have a regular relu here. But
216.4|2.56| anyways, your mileage may vary. And there's another thing I
218.96|3.48| also wanted to say at the end of the video why this may matter
222.44|5.4| less than you might think. So yeah, another example here is
227.84|6.48| the normal initialization. So using Gaussian distribution. So
234.4|4.68| same concept. Now I'm setting the weights here to Yeah,
239.2|2.98| values from a Gaussian distribution. So with mean zero
242.18|6.02| and standard deviation 0.001. So why am I using the detach here?
248.2|2.48| I also already used that in the previous slide, if you have
250.68|4.28| noticed here. So what is the detach? So that is because when
254.96|5.84| we initialize something that has weight parameters, so linear has
260.92|5.16| parameters. So let me go back to slides. So in pytorch, there is
266.08|3.68| a thing called parameter. And these are all the learnable
269.76|5.64| parameters. And they have the gradient on attribute activated
275.4|6.24| by default. And so what happens is that for that part for weight
281.64|3.48| and bias, pytorch will track the gradients when we do
285.12|4.2| computations. However, we don't want to have the weight
289.32|4.6| initialization be part of let's say, the computation graph or
294.12|3.2| the gradient computation. So here, by detaching it from the
297.92|3.52| computation graph, I kind of prevent that for this part, a
301.44|2.92| gradient is computed. So it's just like for convenience, not
304.36|3.44| convenience, I think otherwise, it might not even work. Because
307.8|4.64| it's kind of a weird operation to include in the computation
312.44|2.8| graph, because it's just, this should be essentially our
315.24|3.84| starting point and not part of the computation graph. Okay, so
319.44|3.36| yeah, here's the how we could then also initialize it from a
322.8|3.7| Gaussian distribution. And actually, when I run this, I get
326.56|2.98| get like some really funny results. So on the left hand
329.54|3.18| side, if you want to replicate that, by the way, here's all
332.72|3.16| the GitHub code. So there are also the other ones if you go
335.88|4.16| here. So when I was training this network, I noticed that
340.04|3.48| nothing happened for a while. So for about like, almost 20
343.52|3.0| epochs. And again, then suddenly, I don't know, it got
346.52|3.16| a push or something. And then the loss started to go down. So
349.68|3.24| it started training after epoch 20 or so, which was funny, I
352.92|3.32| have never seen something that weird, but usually also, I would
356.24|2.76| stop the training if it doesn't stop, start learning after a
359.0|3.68| few epochs. So anyways, so that was kind of funny, it eventually
362.68|4.84| learned to perform pretty well. But that was still interesting
367.72|5.48| for the timing initialization that trained pretty well. Yeah,
373.2|2.96| to begin with, I was not such an issue. So that looks actually
376.16|3.04| much better. And this is why we would, for example, use timing
379.44|5.32| initialization for network with relu activations. I should say
384.76|2.84| though, what I mentioned earlier, is that we use if we
387.6|5.12| use batch norm, then actually, this initial feature weight, or
392.72|4.2| weight choice is less important than you might think. So because
396.92|3.16| the other batch normalization normalizes the activations
400.08|2.8| anyways, so in that way, it's less important what type of
402.92|3.6| weight initialization we choose, at least in my opinion. So when
406.52|4.64| we try or when I tried this in practice, so we can see now that
411.24|2.32| on the left hand side, I'm showing you the Gaussian
413.56|3.68| initialization with batch norm, that things train also well for
417.24|3.12| this case. So actually, yeah, with batch norm, it trains even
420.36|4.16| faster than timing her without batch norm. Alright, so yeah,
424.52|5.12| this is just a brief overview of different weight initialization
429.64|3.36| schemes. It's maybe something you might want to consider. But
433.0|3.76| the pytorch defaults are reasonable. If you use the relu
436.76|3.36| activation, if you use different types of activation functions,
440.12|2.68| you may want to see whether there's a better weight
442.8|3.64| initialization scheme. But also, again, with batch norm, things
446.44|4.32| are quite robust. Alright, so this is the lecture on batch
450.76|2.82| norm and weight initialization, then and next week, we will
453.58|22.94| cover optimization algorithms.