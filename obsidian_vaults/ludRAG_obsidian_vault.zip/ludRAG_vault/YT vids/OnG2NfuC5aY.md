start_time|end_time|text
2.04|2.76| Yeah, in this video, I want to talk a little bit about making
4.8|2.94| scientific computing a little bit more efficient using a
7.74|4.12| concept called vectorization in Python. So why am I talking
11.86|2.7| about this right now? So the reason is because in the next
14.56|1.82| video, I want to show you an implementation of the
16.38|4.92| perception in Python using NumPy and pytorch. And I will make use
21.3|3.56| of this concept of vectorization in the next video. So here, I
24.86|2.44| just want to give you some background information on that.
27.3|3.42| So now in general, running computations is a big part of
30.72|3.12| deep learning. So deep learning is a very applied field. Most of
33.84|3.8| the things we do require here large amounts, large amounts of
37.68|3.56| computing and computations. So in that way, I'm getting doing
41.24|2.72| things efficiently is kind of important. Some of you may
43.96|3.44| wonder why do we use Python then because Python is not known for
47.4|4.92| being a fast language. I mean, the truth is, usually, Python is
52.32|4.32| not really a big bottleneck in deep learning, because we use
56.64|5.04| efficient libraries like NumPy for CPU computations and pytorch,
61.68|3.28| for example, for GPU computations, which implement
65.0|4.72| algorithms very efficiently in underlying c++ routines and
69.72|5.16| CUDA routines. And so if you would take out Python out of the
74.88|3.92| equation, and just look at these implementations that say in c
78.8|3.32| plus plus, and everything, Python would only slow things
82.12|4.04| down by 10%, approximately. So that is what is estimated by the
86.16|3.36| pytorch developers. So whether you use pytorch, Python or not
89.54|3.74| for writing code, it does not really slow things down because
93.68|4.04| Python is only like a glue around these lower level
97.72|4.06| libraries. So it's basically just a wrapper around things. So
101.78|4.86| it's not that slow actually to use pytorch in Python compared
106.64|5.8| to let's say, other languages. However, that only applies if we
112.44|3.88| use Python, I would say smartly, because there are certain things
116.52|4.0| that are not very fast in Python. So let's let's talk
120.52|3.52| about vectorization. And now, so maybe stop the video at this
124.04|3.88| point, and take a look at what is shown here, and then try to
127.92|5.76| answer the question, what are we computing here? So yeah, what we
133.68|4.88| are computing here is the net input, the weighted sum from
138.56|5.8| the perceptron. So here, I'm just defining the variables. So
145.72|5.56| I'm using this notation where we have the bias implicitly as a
151.28|5.36| weight. So instead of bias, I could also have written W zero
156.64|2.12| would have been maybe a little bit more clear. But I think you
158.76|4.28| know what's going on here. So what we have is the inputs x
163.04|5.36| zero, x one and x two. So I'm just using some arbitrary values
168.4|3.96| here. Same for the weights. So in the bias, so these are the
172.36|2.52| parameters that we want to learn. Usually, here, it's just
174.88|4.36| about computing the net input, not no learning involved. So I'm
179.24|5.32| assigning them to a Python list here. So these are no Python
184.56|2.96| lists. And then here in the bottom, this is how we compute
187.52|3.4| the net input. So z is our net input. So what's going on here,
190.92|4.84| we initialize z to zero. And then in a for loop, we iterate
195.76|7.88| over the indices on the indices i to length of x or m. So from i
204.36|3.64| to m, where length of x is equal to m, the number of features.
208.56|3.8| And for each iteration, we update z. So this is how we
212.36|7.4| compute the weighted synthesis equivalent to this one that we
219.76|4.04| we computed before. And yeah, there's not that much more to
223.8|3.04| say about that. This is just that using a for loop to
226.84|5.84| compute the net input. Slightly modified version of that would
232.68|2.96| be using a list comprehension. And I'm just seeing actually,
235.64|2.64| this is even a little bit better than a list comprehension in
238.28|2.92| that way in that context, because we don't have to
241.4|2.6| construct the list. So you could actually put square brackets
244.0|2.8| around this, it's not necessary. If you don't use
246.8|3.28| spare brackets in Python, it will be a generator expression
250.28|3.68| with a spare brackets, it will be a list comprehension. Either
253.96|4.56| way, both are slightly better versions of that for loop. Or
258.52|4.04| that's at least what the typical Python developer would tell you.
262.96|4.56| So personally, I'm actually planning maybe to use fewer
267.52|4.24| list comprehensions in the future. You may find them still
271.84|4.04| used in my code for this class, because yeah, I'm historically
275.88|2.44| I've been using this comprehension a lot, a lot of
278.32|4.92| Python developer do that. But to be honest, sometimes, I think,
283.24|3.68| especially if there's a lot of things going on, this
286.92|2.88| comprehension can make things maybe a little bit less readable,
289.8|4.96| because I think this is a little bit longer. But I think it's
295.28|3.04| somewhat easier to read than this one here. Because here,
298.32|2.72| it's everything on one line, you have something like the
301.04|5.52| multiplication for x i and w i and then in the zip. So here zip
307.36|4.28| is iterating over two lists at the same time. So in that way, I
311.64|3.2| mean, it's the same thing. It's just a little bit more compact. I
314.84|4.04| would say compact is nice if you care about the number of lines
318.88|3.16| of code, sometimes a little bit harder to read. So but anyway,
322.04|3.36| so you should be familiar with both ways of writing things,
325.4|2.56| because they are very, very common in the Python ecosystem.
327.96|5.72| So now there's another way. I recall the dot product that we
333.68|7.4| talked about x, the vector x dot w. So that would be another way
341.08|3.56| of computing our net input. That is what I'm showing you here at
344.64|4.44| the bottom. So I'm actually using NumPy now. So I'm using
349.08|3.28| NumPy arrays, I'm converting the lists to NumPy arrays. NumPy
352.36|4.52| arrays have efficiency benefits compared to regular lists,
356.88|3.84| because in regular lists, everything is a pointer to some
360.72|3.72| random location in memory. So if every time you want to look
364.44|3.84| something up, the Python has to find or go to the location in
368.28|5.72| memory. And these are like random locations in NumPy array,
374.24|3.64| everything is so it's basically a fixed size array. So you can't
377.88|2.76| make the array bigger compared to a Python list. But in that
380.64|5.2| way, everything has a fixed size, you only need to store the
385.84|4.28| first location of that array in memory. And then pi or the
390.16|4.88| computer can use, for example, the CPU caches like the l one
395.04|3.96| and l two cache to do certain computations more efficiently by
399.0|2.52| pulling out numbers from the memory more efficiently. So
401.64|5.16| NumPy arrays for computing much faster than Python lists. And
406.8|3.28| also you have linear algebra operations already implemented
410.08|5.04| for it like the dot product, for example. So here, I'm computing
415.12|6.32| the dot product between so x transpose w. So that's how we
421.44|4.92| compute the dot product, you can actually also write x, back dot
426.36|4.88| t, I've been writing transpose to just be explicit. So you know
431.24|9.24| what this is doing. So if I do this, dot w, back should be the
440.48|7.56| same. I am actually doing it here, too. Okay. Oh, yeah. Also
448.04|6.52| one, one thing is here, that in this case, our NumPy array only
454.56|2.08| has one dimension. So you don't actually have to do the
456.64|3.64| transpose. I hope you have worked through the NumPy
460.28|3.84| tutorial that I've given you. So then this should be I think
464.12|3.64| more clear. And for the rest of the course, we will also
467.76|4.28| also assuming that you have some familiarity with NumPy, pytorch
472.04|4.44| will be very similar to NumPy as you will see shortly. Okay, so
476.48|3.72| you can just confirm these are the same computations or mean
480.48|4.56| different computations, but the same results. Now, here are all
485.04|5.92| the three options for computing the net input listed. So my
490.96|6.16| question to you now is, for large vectors, which one is the
497.12|4.24| fastest? So have a guess how fast these implementations are.
501.92|2.68| And then on the next slide, I will show you the results. And
504.6|2.56| you're also very welcome to try this on your computer, for
507.16|5.76| example. So the results are as follows, I was using the time
512.92|2.76| it magic function in ipython, because I find it a personally
515.68|4.0| very convenient. So here, with minus r, you set the number of
519.68|7.84| repetitions. And I think, honestly, I think I'm, yeah,
527.56|3.64| this is, I was just wondering, RS repetitions, I was correct,
531.36|2.64| because I'm just seeing it here. And this is the number of loops.
534.08|7.12| So it's running the computation 10 times as one experiment. And
541.2|2.16| then it's repeating this experiment 100 times and
543.36|2.76| averages over those. So you can see it computes the mean and
546.12|3.36| standard deviation of that, because sometimes, depending on
549.48|2.12| what your CPU is currently running in the background, it
551.6|3.84| may be faster or slower. So in this way, you get some better,
555.52|2.36| more stable estimate by averaging over multiple
558.08|4.96| experiments, or repetitions. So the first case, the for loop
563.04|4.52| here runs in like 40 milliseconds, approximately.
568.32|3.64| The list comprehension or generator, in that case, is a
571.96|2.96| little bit faster, it's 30 milliseconds. So it's 10
574.92|3.32| milliseconds faster, it's quite a bit. I mean, it's like, I
578.24|3.28| would say almost 20% or something. But what's what's
581.52|4.04| really interesting is the vectorized implementation. Now
585.56|3.16| instead of having, let's say 40 milliseconds, you're almost down
588.72|5.2| to 40 microseconds, where micro is 1000 times faster than
594.2|3.64| milli, right? So in that way, there's a huge improvement by
597.84|3.28| just using NumPy code here. So this vectorized implementation.
601.4|3.72| And this is why in deep learning, we want to avoid to
605.12|3.84| use for loops. So wherever you can, if you ever see a for loop
608.96|4.76| in your code, try to eliminate that by using dot products or
613.72|6.16| matrix multiplications in NumPy and pytorch. Yeah, regarding
621.2|3.64| the reason why they are more efficient. So I haven't really
625.16|3.84| this figure just inspired me to talk about this. We haven't
629.0|3.04| really talked about why it is more efficient, if I go back a
632.04|3.4| little bit. So if you look at the for loop here, what is
635.44|3.64| going on here is that things are computed in a sequential order,
639.08|2.92| right? So the for loop is doing one thing at a time, it's doing
643.04|3.08| this computation computation for the first index, and then it
646.12|3.72| goes back and does it for the second index, and so forth. So
649.84|3.44| it's doing this sequentially one thing at a time. However, for a
653.28|2.92| dot product, for example, you can think and compute things in
656.2|8.64| parallel, right? So if you have two vectors, so let's say one,
664.84|6.76| two, three, and 123. So what you would do is you what you would
671.6|3.68| do is in the dot product, you would compute one times one plus
675.44|4.44| two times two times plus three times three. So you would
679.88|8.36| compute product, this one plus the product, this one, and plus
688.24|5.2| the product of this pair. So I would write it out as one, one
693.44|10.44| times one plus two times two plus three times three. So of
703.88|4.28| course, you have to have the results of that when you want to
708.16|4.32| add that up, basically, but each pair can be computed in parallel,
712.48|3.84| right? So you can already carry out this multiplication and this
716.32|2.2| multiplication and this multiplication. At the same time,
718.52|4.96| you don't have to wait until one is finished. So you can compute
723.48|2.8| things in parallel. So the computer can actually compute
726.68|2.32| this. Oops.
729.0|7.72| Let me use a different color can compute this multiplication, this
739.44|3.96| multiplication and this motivation all at the same time
743.4|3.2| and then sum up the results. And in this way, we can leverage
746.8|3.96| parallel computing, there's something called SIMD. It's a
750.76|9.4| similar operation, but on the same data. So that is one
760.16|4.84| advantage why GPUs are kind of especially good at this because
765.0|3.8| GPUs have a lot of cores. So you can actually carry out large
768.84|4.2| vector dot products or large matrix multiplication very
773.04|3.64| efficiently. So in a matrix multiplication, you have multiple
776.68|3.12| dot products at the same time. So you can parallelize the dot
779.8|5.88| product computations. And yeah, going back to the question I
785.68|3.84| raised earlier, why the human brain is, for example, so much
789.52|3.48| more powerful than a neural network. One reason could also
793.0|2.8| be that it's just a yeah, also the number of connections. So
796.12|3.0| the brain may not have that many parameters as like these big
799.16|3.28| language models, but it has a lot of connections. Although
802.44|2.68| it's also not really true for language models anymore, because
805.12|3.08| the transformers also have these attention layers, which have an
808.2|4.08| attention over all the inputs and stuff like that. But let's
812.32|3.88| let's consider here a GPU for reference. The GPU has a lot of
816.72|4.08| transistors, it has 2.1 billion transistors, which is actually
820.8|8.08| more than the sorry, that is actually 21 billion 21 billion
828.88|5.08| transistors, this particular one from 2017. Whereas the brain has
833.96|6.88| 16 billion neurons. So GPU is actually more transistors than a
840.84|5.12| brain has neurons. So one idea why the brain is also so much
845.96|3.04| more powerful than a GPU, for example, is that there are just
849.0|2.88| so many more connections per neuron compared to a transistor.
852.08|3.72| So transistor only has approximately 10 connections on
855.8|7.4| average. And the human brain has about 10 to 100,000 connections
863.2|5.0| per neuron. So in totally have, what is it like 10,000 billion
868.24|4.08| connections in the human brain? Alright, so, but going on moving
872.32|2.52| on. So this was like a short interlude into the
874.84|3.76| vectorization. I explained, I think, things more in detail in
878.6|3.4| this NumPy resource in the series of videos I shared with
882.0|3.48| you. So if you want to know more detail, so but here, that was
885.48|3.88| just like the minimum, what we need for the next section for
889.44|3.36| implementing a perceptron in Python using NumPy and
892.8|0.72| PyTorch.