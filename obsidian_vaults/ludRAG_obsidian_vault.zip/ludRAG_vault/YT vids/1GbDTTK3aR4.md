start_time|end_time|text
6.2|2.96|um do
9.96|4.759|folks there stand stand
14.839|4.921|foration you know which one oh person
17.76|7.12|what what is
19.76|9.2|this what's going the first that's right
24.88|7.4|and then what is Association stand
28.96|6.439|for I believe this is
32.28|5.08|M yeah who started sale I if I
35.399|3.0|understand correctly is that right he
37.36|3.64|started
38.399|4.921|sale yeah I think he I think he did but
41.0|5.039|anyways uh so so so what's interesting
43.32|5.559|is so it's it's it's it's it's it's
46.039|5.2|amusing to actually look at uh what they
48.879|4.961|what they wrote in their um I don't know
51.239|6.041|was a brochure what they wrote in their
53.84|5.6|their goals right so so so phont is a
57.28|3.799|bit small okay so so this the study is
59.44|3.439|to Pro on the basis of the conjecture
61.079|4.641|that every aspect of learning or any
62.879|4.721|other feature of uh of intelligence can
65.72|4.039|principle be principle be so precisely
67.6|5.12|describe that a machine can be made to
69.759|5.04|simulate it right fantastic so single
72.72|4.36|machine you want to simulate all of like
74.799|4.721|human intelligence okay and a carefully
77.08|4.28|selected group of scientists uh and and
79.52|3.68|we think that we can make uh actually
81.36|6.52|the paragraph right before the second uh
83.2|6.12|set of uh uh uh red underline is uh we
87.88|3.36|think that a significant Advance can be
89.32|5.6|made in one in one or two of these
91.24|5.44|problems if uh if um a carefully
94.92|4.559|selective group of scientists work on
96.68|4.36|together for a summer okay uh I don't
99.479|3.561|think they knew of AI Winters then
101.04|3.88|actually they didn't know of it then but
103.04|3.719|and and and and and the third third
104.92|4.559|thing uh is amusing is but the major
106.759|4.881|obstacle is not lack of machine capacity
109.479|4.68|uh but our inability to write programs
111.64|3.88|taking full advantage of what we have so
114.159|3.761|so so while the goals are noble it's
115.52|3.919|surprising how wrong you can be in in
117.92|4.799|with some of the smartest people in in
119.439|5.081|the room right so uh self uh and neuron
122.719|3.4|Network oi that were the originally were
124.52|3.4|pandemonium I think he got everything
126.119|5.801|basically except PA problems in Black
127.92|6.679|boox optimization then uh mitsky of
131.92|5.56|course Shannon uh salmanov I think this
134.599|4.561|salmanov mdl uh you know in many ways
137.48|4.92|you can argue that's that that's the
139.16|5.64|underpinning of of of uh of unsup of of
142.4|4.24|self-supervised learning today but but
144.8|4.4|it's really amusing to see to see the
146.64|4.64|first VI I mean at least I don't know if
149.2|4.96|we'll be able if you'll be able to
151.28|3.88|characterize uh uh characterize uh or
154.16|2.4|write down all the rules for
155.16|2.48|intelligence so you can imagine that the
156.56|3.679|approaches they were taking were all
157.64|4.04|these rule based systems right um and
160.239|4.201|and they couldn't be more wrong on
161.68|5.4|machine capacity uh uh today's
164.44|6.36|Transformers are they don't they're data
167.08|6.84|centers right and uh I and I
170.8|5.04|guess the the they needed a really
173.92|5.84|really long summer to solve this one but
175.84|8.0|uh yeah so so so so uh so it's 1955 so
179.76|6.64|so so like about uh yeah 60 60 years uh
183.84|4.759|no no not getting close to 70 70 years
186.4|4.04|right so and and and we're we're
188.599|5.92|basically talking about the same
190.44|6.48|problems again except maybe except maybe
194.519|4.321|some things work some things don't work
196.92|3.84|and and and and this talk is about like
198.84|4.0|uh you know some of the one of the one
200.76|4.28|of the pieces that has made this larger
202.84|3.6|Enterprise work and then and and we
205.04|3.119|getting closer to the original the
206.44|4.439|original goals of the of the Dartmouth
208.159|4.761|conference yeah uh again okay so so so
210.879|3.72|so so this is like the big gaps I mean
212.92|3.399|so what what eventually happened in the
214.599|4.28|field was that you know their goal of
216.319|6.2|having a single system that explained
218.879|5.0|most of um that was able to mimic our
222.519|3.681|cognitive abilities which would
223.879|3.56|definitely mean like image processing or
226.2|3.319|image understanding and language
227.439|4.761|processing as well right that that I
229.519|5.08|mean the field got mean a single a
232.2|4.399|single model or a single approach to do
234.599|4.081|all these things was shattered by like
236.599|4.2|thousands of like different research
238.68|3.68|projects soan I mean there was no
240.799|4.16|consolidation but here's another here's
242.36|4.56|another here's another uh this is going
244.959|4.601|to be a harder one uh can you tell where
246.92|5.0|is the this is this is 2009 and this is
249.56|4.12|a this is not a single system this is a
251.92|4.08|complicated machine translation system
253.68|3.44|so when I started my phdr machine transl
256.0|2.88|systems used to be a bit more
257.12|4.48|complicated complicated than this
258.88|4.4|actually thousands of pipeline systems
261.6|3.12|uh you had to First extract you had to
263.28|3.84|First do word alignments that actually
264.72|4.08|looked like attention it's like hard you
267.12|3.28|think about it as hard attention then
268.8|3.6|based on that we extract like how larger
270.4|3.84|phrases aligned with other phrases then
272.4|3.92|you had to figure out how how they then
274.24|3.16|had then you had to teach there was some
276.32|2.879|machine learning there you had to teach
277.4|3.88|a model how to score them connecting
279.199|6.56|with each other so can you can you does
281.28|4.479|anybody know where a Neal network is in
290.28|5.919|this all right so CS so this is the uh
294.8|4.52|this is a machine translation system
296.199|5.321|from 2009 and cslm is a continuous State
299.32|5.319|Lang language model that's there used
301.52|4.679|for rescoring right so the world was so
304.639|3.12|discreet then that he had to call these
306.199|3.121|models like continuous State language
307.759|3.401|models and and I mean it was it was
309.32|4.12|largely inspired by the neuro
311.16|3.16|probabilistic language model by oh it
313.44|3.479|doesn't
314.32|4.879|appear
316.919|4.961|huh
319.199|5.081|sorry ah there the the the neuro
321.88|4.72|probabilistic language model by by by
324.28|6.44|benju I think was in fil tree and and
326.6|6.039|and so we were um even even in in 2013
330.72|5.44|when I when I when I when I published a
332.639|6.12|paper on neur language models these mod
336.16|4.44|these models were still being put into
338.759|4.361|the fe4 neural network language models
340.6|4.24|were still you know be scoring and now
343.12|3.519|it's it's incredible if you think about
344.84|3.4|it like so just in terms of
346.639|3.881|consolidation how all of these
348.24|4.12|complicated systems that have now been
350.52|3.36|replaced by just neurons that talk to
352.36|3.6|each other and you just learn the rules
353.88|5.08|from you just learn the rules from data
355.96|4.359|automatically so so so so so so it's
358.96|3.519|it's fun to
360.319|4.6|it's it's it's it's interesting to see
362.479|5.961|and and and so and since then you know
364.919|5.72|like so this is this is what the emlp
368.44|5.199|2013 conference was like you see these
370.639|4.721|different uh like these these these you
373.639|4.12|can call it verticalized NLP these
375.36|5.0|different areas like morphology dialogue
377.759|4.481|and discourse I mean I don't even know
380.36|3.48|if people talk about dialogue and
382.24|2.72|discourse just talk to models no there's
383.84|2.72|no I don't know if there's a research
384.96|3.079|fact anymore then there is like a
386.56|3.359|machine translation so like this opinion
388.039|5.0|mining andc sentiment analysis
389.919|5.56|uh now models make you angry or or upset
393.039|5.041|so it's it's and and so so you could see
395.479|4.681|that just in 2013 the the field even
398.08|3.519|research was divided into these smaller
400.16|3.36|tracks and everybody had their own
401.599|5.521|specific they were bringing their own
403.52|5.16|specific um domain domain information
407.12|3.24|and they had to specialize in a domain
408.68|3.4|in order to solve some tasks and we
410.36|3.52|solve tasks to some degree machine
412.08|3.679|translation because I mean probably
413.88|3.64|because of of a lot of government
415.759|3.12|funding as well we had made a lot of
417.52|2.959|progress and you were making practical
418.879|3.16|translations systems that were being
420.479|3.201|being deployed in the wild Google
422.039|4.801|translate was a great example of that
423.68|5.56|right and and and and and so since then
426.84|5.28|you like you we had this you know we we
429.24|4.639|we started to uh through first first we
432.12|3.56|all agreed we need distributed we need
433.879|4.0|distributed word representations and you
435.68|4.72|saw this like people probably remember
437.879|5.16|this funky uh this funky uh embedding
440.4|8.04|algebra King minus man plus woman equals
443.039|7.081|equals Queen from from WC um and uh and
448.44|5.24|we had a we had a there was a there was
450.12|5.479|a there was a big industry of of models
453.68|3.48|uh that that actually that just that
455.599|2.921|that learned word representations and
457.16|4.759|the word representations were actually
458.52|5.679|useful in Downstream tasks and then then
461.919|4.56|came like you know another step in this
464.199|4.72|process another step in this process
466.479|5.28|where now we started saying okay these
468.919|4.161|representations like in there're but
471.759|3.201|they're they're they're only helpful if
473.08|4.64|they're learned in context right so the
474.96|4.48|king should change uh based on context
477.72|3.4|right uh the the the the king of of
479.44|4.08|Persia or the the King has no clothes or
481.12|5.72|the emperor has no clothes right uh and
483.52|4.84|and and so so so that so we we saw these
486.84|3.16|we saw approaches like sequence to
488.36|4.6|sequence sequence learning where we
490.0|5.12|started to like formulate we started to
492.96|5.4|create these general formulations of how
495.12|4.68|to solve any task in NLP right so
498.36|2.799|sequence to sequence formulation if you
499.8|3.64|can you can you can you can you can
501.159|4.0|formulate many tasks in language of
503.44|4.52|sequence to sequence question answering
505.159|4.681|machine translation dialogue so and then
507.96|3.44|and and and and then of course we had
509.84|3.439|then we then we developed attention
511.4|4.6|right which was a which was a very
513.279|4.88|effective content based way to summarize
516.0|4.519|information if you were typically you
518.159|4.24|have these encoder decoder architectures
520.519|2.921|everybody is probably I'm guessing
522.399|2.841|familiar with encoder decoder
523.44|3.68|architectures right so encoder decoder
525.24|3.44|architecture and a and a and and and a
527.12|3.8|position on the decoder side could
528.68|3.68|summarize based on its content all the
530.92|2.76|information on the in the source
532.36|2.36|sentence right and this was really
533.68|3.279|effective content based way of
534.72|4.04|summarizing information and and and what
536.959|4.641|what started happening was we started
538.76|4.68|these these General uh these General
541.6|4.0|paradigms started started coming up
543.44|4.519|sequence to sequence learning can solve
545.6|3.6|if it can solve most language problems
547.959|2.721|because most language problems have to
549.2|3.52|deal with learning representations of
550.68|3.279|variable length the the goal is to learn
552.72|2.559|representations of variable length
553.959|3.161|sequences and if you do that
555.279|3.441|successfully you can then potentially
557.12|4.36|solve that problem and then attention
558.72|4.679|was an excellent way a Content based way
561.48|5.16|to actually summarize information from
563.399|5.281|some neighborhood and um and and and and
566.64|4.439|so so so so and the and the major
568.68|6.599|workart until then were these recurrent
571.079|6.281|models or lstms right uh where basically
575.279|3.481|uh the the the the method was typically
577.36|3.96|the same you had a you had a sentence
578.76|4.36|and you crushed the sentence into into a
581.32|4.56|set of into a set of vectors set of
583.12|4.44|representations one typically typically
585.88|4.36|one for each position right and the way
587.56|4.839|lstms did it was where they walked along
590.24|3.88|the sentence they ate up a word and then
592.399|4.921|they summarized they summarized the
594.12|4.839|entire history into one fixed bottleneck
597.32|3.84|and that bottleneck was then transmitted
598.959|5.841|was updated based on the next words so
601.16|5.2|so so now and and and and and if if you
604.8|2.96|were successfully able to learn
606.36|2.32|representations then we could solve
607.76|2.36|these tasks like translation
608.68|4.0|summarization dialogue so it's an
610.12|5.159|important movement and and and like 2020
612.68|5.12|I I 20 I guess when was the sequence to
615.279|4.641|sequence learning papers 2015 neps then
617.8|4.44|we saw then we saw the attention paper
619.92|3.64|in around 2015 2016 and the Machine
622.24|4.159|translation Community was kind of the
623.56|4.04|first to respond and say hey uh you know
626.399|3.0|machine translations is a classic
627.6|3.4|sequence to sequence learning problem
629.399|3.641|like why don't we now first start
631.0|3.8|rescoring and then can we still build
633.04|2.88|native greeny rethink machine
634.8|3.8|translation with these sequence to
635.92|4.56|sequence models right um and and these
638.6|3.919|are fantastic models I don't know if you
640.48|5.56|guys have ever done these exercises on
642.519|5.12|lstms can can count like if if you for
646.04|5.44|example if you if you train an encoder
647.639|5.961|decoder on if you like on to Model A to
651.48|5.039|the nend B to the end so you feed in Nas
653.6|5.56|and you ask the decoder to predict n uh
656.519|4.681|NBS and you actually just a single cell
659.16|4.2|lstm if you know the structure of an LSM
661.2|4.199|there's a cell that basically keeps so
663.36|4.039|it's it's a notion of state and just a
665.399|4.201|single cell is able to actually just do
667.399|4.841|trivial counting it's it counts how many
669.6|4.239|A's where you you consumed and then it
672.24|3.2|decrements it and then when you consume
673.839|3.56|all the exactly the same number of B's
675.44|3.04|is the number of A's uh something like
677.399|2.481|something and says I'm done I've
678.48|3.159|recognized this language so you can TR
679.88|3.84|Tri like a to the end B to the end and
681.639|3.361|here you have you have a I'm sorry this
683.72|3.48|this is not clear but you have somewhat
685.0|3.72|of a you have a grammar here and you can
687.2|3.439|see that these are different cells this
688.72|3.799|the eight cells here and each one of
690.639|3.401|these cells actually increments its
692.519|3.401|counter once it reads a particular
694.04|3.68|symbol and it's able to actually track
695.92|3.919|how deep you are in this how deep you
697.72|5.04|are in this hierarchy in this grammar
699.839|5.281|and uh and Google and Google of course
702.76|5.72|um the the crowning achievement perhaps
705.12|5.959|of sequence to sequence models which uh
708.48|4.84|I was actually right I I had I was
711.079|4.121|fortunate to to be in the the same
713.32|3.759|cuticle as it was being as work was
715.2|4.079|being done was the Google Ur machine
717.079|4.44|translation system where they took LSM I
719.279|3.841|mean they added they added many
721.519|3.201|advancements of course a lot of systems
723.12|3.48|improvements a lot of a lot of data that
724.72|3.88|Google had and they produced what you
726.6|3.64|might at that at that time the
728.6|3.6|state-ofthe-art ne machine translation
730.24|4.88|system sequence to sequence models so
732.2|4.6|now this big Consolidated this big
735.12|3.68|complicated system which looked much
736.8|4.24|which looked much more complicated and
738.8|4.8|now become a homogeneous just as a
741.04|5.239|single homogeneous neuron Network right
743.6|4.799|um so at the time the the biggest
746.279|4.92|frustration we had was this was I mean
748.399|4.321|these the lstms of the primary Workforce
751.199|4.161|and and the biggest the biggest
752.72|5.359|frustration they had was they they I
755.36|5.039|mean not only were were we producing uh
758.079|3.76|not not only were we did we produce the
760.399|3.24|output Auto aggressively we were
761.839|3.961|sequentially decoding the output left or
763.639|3.961|right but also we were reading the input
765.8|3.12|sequentially so you had to kind of in
767.6|3.039|order to produce that in order to
768.92|3.96|produce the representation for the 10th
770.639|3.401|word you had to eat up you have to the
772.88|2.88|first word the second word the third
774.04|4.359|word so that was that was really slow
775.76|4.56|and and and and and and and and and and
778.399|4.56|not the whole the and another big
780.32|5.44|problem with lstms were that you have
782.959|4.56|this bottom lck that basically that
785.76|4.24|contains all the information about your
787.519|4.601|past so you have to now you have to now
790.0|3.68|Crush you have to you have to pack both
792.12|3.399|long distance interactions that you
793.68|3.719|might have and local interactions
795.519|3.961|through the single single fixed factor
797.399|4.761|that you need to transmit right and and
799.48|4.24|sequentiality uh it doesn't inhibits
802.16|3.4|parallelism which means that you
803.72|3.119|couldn't even read like The encoder
805.56|3.6|couldn't even read the sentence in
806.839|3.8|parallel and of course decoding was Auto
809.16|5.6|regressive so you couldn't even write in
810.639|6.401|parallel right um and and um
814.76|4.12|convolutions were they were starting to
817.04|3.68|emerge as a solution largely I mean they
818.88|3.519|had been very successful in in they had
820.72|2.799|been very successful in computer vision
822.399|2.8|they had also figured out how to
823.519|3.201|optimize them well how to make them how
825.199|4.681|how to train how how to make them really
826.72|4.52|fast on on on gpus where and because
829.88|2.84|they're they're just basically Matrix
831.24|4.399|multiplications and matrix
832.72|4.919|multiplication is largely is paralyzable
835.639|4.281|um so convolutions were were were were
837.639|4.601|were a solution to this to this problem
839.92|4.2|of of not being able to to read in
842.24|3.959|parallel right because you could in
844.12|4.32|parallel every word could basically
846.199|4.041|produce its representation by looking at
848.44|4.44|its neighbor by looking at its neighbors
850.24|4.2|right its local its local neighbors and
852.88|3.079|uh there were there there were some very
854.44|3.92|very like there were some breakthrough
855.959|4.201|papers such as bitet uh for machine
858.36|3.0|translation uh the convolutional
860.16|2.88|sequence to sequence model that was
861.36|3.479|called temus to the Transformer actually
863.04|3.28|probably predated by a few months where
864.839|3.961|they used where they Ed convolutions
866.32|3.959|both on the incoder and decoder to to uh
868.8|2.92|get good scores on machine translation
870.279|3.36|that that were better than the Google
871.72|4.479|neur machine translation system and of
873.639|5.721|course probably the most successful the
876.199|4.681|most successful of uh the the most
879.36|2.839|successful was wavenet which was a text
880.88|4.72|to speech system that was
882.199|6.721|state-of-the-art at the time um and
885.6|6.56|again so so so so so this so convolution
888.92|6.08|still had this problem that one I guess
892.16|5.52|they were paralyzable but the issue was
895.0|4.959|that you you still you couldn't directly
897.68|3.959|capture long distance interactions
899.959|3.361|between you you D couldn't directly
901.639|3.281|capture long distance interactions
903.32|3.319|between words right so if you're
904.92|4.32|basically a receptive field if it's like
906.639|5.481|a like a 3X3 if it's a if it's a it's a
909.24|4.56|1 by3 then it basically grows linearly
912.12|3.079|with the factor of it grows linearly
913.8|3.88|with with the number of with the number
915.199|5.401|of layers each time each time it expands
917.68|4.2|by three so so so you you still needed a
920.6|3.479|a linear number of layers to capture
921.88|3.6|these long-distance relationships uh and
924.079|3.241|and but attention on the other hand was
925.48|4.4|this really effective mechanism that we
927.32|5.8|knew was that that that could
929.88|5.6|actually get us in in one it it could
933.12|4.519|actually capture all the interactions
935.48|4.44|between one word and every other
937.639|4.041|word using using content based
939.92|3.76|addressing right because convolutions
941.68|3.959|basically match convolutions match
943.68|3.159|weights with parameters attention they
945.639|3.44|actually able to use content with
946.839|4.641|content So based on how similar I am to
949.079|3.601|my neighborhood based on how how similar
951.48|3.0|I to my neighbors I'm going to absorb
952.68|3.48|that information and this actually this
954.48|4.2|Motif actually appears everywhere even
956.16|4.599|in computer even in computer vision so
958.68|4.76|uh maybe actually I can go there so so
960.759|4.481|here here's a here's a in in in Vision
963.44|4.519|there's this there's this approach do
965.24|5.48|people here know of non non loal
967.959|4.0|means so in in computer vision there's a
970.72|5.4|there's an approach called non-local
971.959|5.641|means that's basically uh it was
976.12|2.92|originally developed for image Den
977.6|3.76|noising so if you want to denoise an
979.04|4.32|image patch you basic you looked at all
981.36|3.56|your neighbors and you see which patch
983.36|2.959|is very similar to you and based on the
984.92|3.159|similarity you actually pulled in that
986.319|3.2|information so and and and and this
988.079|3.56|largely work in images because images
989.519|3.961|are very self self similar this start
991.639|3.921|sounding like hey based on content I
993.48|3.4|want to pull in information and and
995.56|4.279|again they they were similar there were
996.88|5.0|approaches like uh uh texture synthesis
999.839|3.881|by EOS where if you wanted to if you
1001.88|3.36|wanted to do kind of painting or if you
1003.72|3.0|wanted to generate an image then you
1005.24|4.519|would look at a patch that's similar to
1006.72|5.0|this rectangle in some other in your in
1009.759|3.64|your dictionary or in like a database
1011.72|3.4|that you have of patches and then based
1013.399|3.68|on what's closest to you actually bring
1015.12|3.32|it right so you you you'll bring that
1017.079|2.601|patch and then you'll paste it there so
1018.44|2.68|so these approaches that look like
1019.68|2.56|attention were already were already
1021.12|4.199|prevalent it's a very natural
1022.24|6.599|formulation and it's and and and and and
1025.319|4.921|and and and and the the the bad paper
1028.839|3.401|had had shown that this actually works
1030.24|4.559|really well for language as well so so
1032.24|4.719|the question then was okay why can't we
1034.799|4.24|then learn representations instead of
1036.959|4.041|doing this Source Target why can't we
1039.039|3.601|actually learn representations by by the
1041.0|4.439|sentence attending onto itself so now
1042.64|4.319|you you basically use you you instead of
1045.439|2.76|attending a source sentence attending to
1046.959|2.121|a Target sentence can of just attend to
1048.199|3.401|itself
1049.08|5.52|and the original goal of actually when
1051.6|6.16|we wanted when we when we we wanted to
1054.6|5.0|actually do parallel decoding so um so
1057.76|5.32|attention by construction is paralyzable
1059.6|5.68|because each each uh each token can
1063.08|5.68|basically construct its representations
1065.28|5.279|from its neighbors in parallel right and
1068.76|4.52|uh it directly captures token to token
1070.559|4.881|interactions because no of course we'll
1073.28|4.32|run into complexities of complexities of
1075.44|3.28|length but we can we can disc and we'll
1077.6|2.84|discuss our Sol some some of these
1078.72|3.079|things later or to overcome them but you
1080.44|3.08|can direct instead of having this sort
1081.799|3.561|of linear growth in receptive field you
1083.52|3.279|can directly capture these interactions
1085.36|2.72|because convolutions if you have a very
1086.799|3.161|very large receptor field it gets
1088.08|3.24|computationally very expensive and it
1089.96|3.24|also had these explicit gating and
1091.32|4.88|multiplicative interactions which we've
1093.2|5.4|often seen like in gated pixel CNN or G
1096.2|3.599|they see this these they the these G
1098.6|3.439|explicit gated multiplicative
1099.799|4.441|interactions have typically helped
1102.039|5.041|training and have led to better better
1104.24|5.2|better accuracies um and the as I
1107.08|4.2|mentioned the original motivation of why
1109.44|5.719|we actually wanted to do this was we
1111.28|5.759|said Hey Okay so the lstms are are you
1115.159|3.921|have good translation systems but the
1117.039|4.201|problem is that actually both reading
1119.08|3.839|and writing uh sequentially can we
1121.24|3.52|actually do both in parallel so we
1122.919|3.24|wanted to read we wanted to read like we
1124.76|3.44|wanted to read the German sentence in
1126.159|4.321|parallel and then translate it in and
1128.2|4.24|then also write in parallel by that
1130.48|3.88|instead of actually decoding it sort of
1132.44|3.239|Auto regressively can you decode it
1134.36|4.0|instead of decoding in time can you
1135.679|4.161|decode it in in height so like you first
1138.36|3.08|first spit out one word or you spit out
1139.84|5.079|all the words and you iteratively refine
1141.44|5.52|them right and uh this was a this turned
1144.919|4.24|out to be very very challenging and
1146.96|3.8|hasn't been solved successfully until
1149.159|3.201|today because the biggest challenge
1150.76|3.0|essentially is when you whenever you're
1152.36|2.84|decoding right essentially as you
1153.76|3.32|predict a word you kind of bend the
1155.2|4.08|probability distribution that then nails
1157.08|4.56|down Narrows down what you're going to
1159.28|5.04|predict later on and the and and and the
1161.64|4.279|ordering that allows you basically the
1164.32|5.04|ordering that allows you to nail these
1165.919|5.521|modes was very hard to learn so imposing
1169.36|3.6|Left Right ordering is much easier than
1171.44|3.84|actually not having one and having to
1172.96|3.959|learn it as you're as you're decoding so
1175.28|4.519|we the original approaches didn't work
1176.919|4.841|but then we we still had we still had um
1179.799|3.601|we still had our Salvation in being able
1181.76|2.799|to read parall so we said all right
1183.4|5.639|let's take this back to the encoder
1184.559|5.441|decoder models and and uh and and unlike
1189.039|3.76|at that time there were a few
1190.0|5.28|formulations right so we had the sort of
1192.799|3.561|the original formulation attention from
1195.28|3.56|graves then we have the additive
1196.36|4.6|attention formulation and uh we took the
1198.84|4.28|and we took the dot product uh attention
1200.96|5.24|formulation largely because it allowed
1203.12|4.64|us to do uh it because it allowed us to
1206.2|3.76|actually do attention as a matrix
1207.76|4.88|multiplication and and often times some
1209.96|4.92|of the biggest constraints that actually
1212.64|4.6|physics is such a big constraint in
1214.88|4.4|neuron networks that if you can if you
1217.24|4.2|can make your if you can make your
1219.28|4.12|architecture amenable to to Modern
1221.44|3.719|accelerators you have a much better
1223.4|3.92|chance you have a much better chance of
1225.159|4.081|succeeding and and Dot product attention
1227.32|3.8|could be expressed as a multiplication
1229.24|3.919|and it's and and and they're already sub
1231.12|3.52|they're already kernels for for for
1233.159|3.681|being able to do matrix multiplication
1234.64|4.279|very effectively on the GPU so we had so
1236.84|3.6|so the formulation was all right so so
1238.919|3.481|now we have similar to The Dot product
1240.44|3.88|detention we had a scaling Factor simply
1242.4|3.519|because if the if the dot product
1244.32|3.44|actually becomes too big and you can
1245.919|4.081|solve it under certain assumptions of
1247.76|6.279|mean and variance in the in the in the
1250.0|6.559|representations you can hasn't updated
1254.039|4.76|actually yeah so so Bas so so our
1256.559|6.24|formulation is basically you have you
1258.799|5.521|have uh uh your queries uh which uh what
1262.799|3.161|you what you end up doing is if you have
1264.32|4.56|a if you have a position you first
1265.96|4.64|projected into queries um and then the
1268.88|3.039|same the same token the same the
1270.6|3.959|representation of the same token gets
1271.919|5.481|projected into to also keys and values
1274.559|5.321|and the first uh the query determines
1277.4|4.92|how much in how much you're actually
1279.88|4.039|going to pull from all these keys so you
1282.32|3.92|first do a DOT product of the query with
1283.919|4.681|every key and then based on that you you
1286.24|4.72|combine or you pull the content of in
1288.6|3.959|all these positions based on uh based on
1290.96|3.719|what the based on what the score was
1292.559|4.401|after after normalizing it using a soft
1294.679|5.721|Max so in some sense you can think of
1296.96|5.56|self attention also as kind of a Content
1300.4|4.48|based pooling mechanism right and the
1302.52|4.639|scaling Factor basically avoids you
1304.88|3.64|avoids you uh like it saved us from
1307.159|3.481|these low jits actually blowing up and
1308.52|5.32|training become becoming unstable and on
1310.64|5.76|the decoder side uh you could trivially
1313.84|4.4|you can trivially Implement uh causality
1316.4|5.159|by just adding an adding an attention
1318.24|5.12|adding an attention mask um and what
1321.559|3.72|this where this where this brings us is
1323.36|5.36|that all right so so now we've we've
1325.279|4.921|solved now uh there's it's so a caveat
1328.72|3.16|on the flops we'll actually cover this
1330.2|4.12|later but now what we have is a
1331.88|5.0|mechanism that that's paralyzable it
1334.32|4.28|gives you direct uh uh it gives you
1336.88|4.08|direct content cont it gives you direct
1338.6|3.88|token interactions it and that that we
1340.96|2.64|that we that we believe is going to help
1342.48|2.84|you actually learn model these
1343.6|3.48|relationships between the words better
1345.32|3.68|and it's and it's and the complexity of
1347.08|3.76|self attention is FAS than convolutions
1349.0|3.559|right because because convolutions are
1350.84|4.04|quadratic in the number they're
1352.559|3.881|quadratic in the number of channels in
1354.88|2.96|the number of in the hidden Dimension
1356.44|2.479|but a self attention is quadratic in the
1357.84|2.4|length so if your length is not much
1358.919|3.561|more than a hidden Dimension you've
1360.24|4.72|actually saved down flops now this is a
1362.48|4.6|not not quite a complete picture because
1364.96|4.52|not all flops are equal and we'll talk
1367.08|4.8|about this later on
1369.48|3.88|um and and and and and now when you
1371.88|3.76|putting when you put everything together
1373.36|5.24|what we what basically we we kind of
1375.64|4.84|took the the the basis
1378.6|3.88|this has a very strong uh similarity to
1380.48|3.76|the to the resonet architecture actually
1382.48|4.079|so if we look at resonet right so in
1384.24|4.319|resets you have contraction you have
1386.559|3.72|spatial mixing with convolutions and
1388.559|3.921|then you have the expansion again right
1390.279|4.041|if you just with the Transformer if you
1392.48|3.6|just adjust if you just move it one one
1394.32|3.2|step down it's very it's analogous you
1396.08|4.12|have you have a tension then you have
1397.52|4.0|expansion contraction but there a and
1400.2|2.92|difference in where the residual
1401.52|3.519|connections are but it's a it's a very
1403.12|3.76|similar it's a very similar sort of
1405.039|3.52|basic building block with say the resid
1406.88|3.48|with the residual connection and you
1408.559|4.72|have these contractions and expansions
1410.36|4.84|and in the Transformer those were that
1413.279|3.64|was multi-head attention with expansion
1415.2|4.76|contraction which was in the feet
1416.919|5.401|forward layers and and and then uh one
1419.96|4.76|one one challenge with the tension we Lo
1422.32|4.64|lstms can count they can impact they can
1424.72|4.48|they can they can they can count they
1426.96|4.36|can uh learn interesting temporal
1429.2|4.76|patterns but
1431.32|5.04|uh attention is permutation inance so we
1433.96|3.719|had to actually add position we had to
1436.36|3.16|add position information so that we
1437.679|4.081|could we could learn ordering so we add
1439.52|3.639|position information at the input which
1441.76|3.36|trans gets transmitted to the other
1443.159|4.561|layers through uh through the through
1445.12|4.6|the through the residual connections and
1447.72|3.839|uh the original paper we had the we had
1449.72|4.36|post layer Norm but later on we realized
1451.559|5.201|that as we actually make the model
1454.08|4.479|deeper post laym is doesn't doesn't
1456.76|3.88|allow you to train effectively so we had
1458.559|3.641|to then we then we used a pre- layer
1460.64|5.6|Norm formulation which was also observed
1462.2|5.92|in the original reset papers and um so
1466.24|4.559|the model is basically all right you got
1468.12|4.679|your input well you have spatial mixing
1470.799|4.6|spatial mixing to attention feed forward
1472.799|4.721|layers and this sort of repeats and the
1475.399|4.0|uh the the difference in on the decoder
1477.52|3.759|side is that you also now have encoder
1479.399|4.4|decoder attention and encoder decoder
1481.279|3.76|attention uh at every at every uh at
1483.799|4.48|every
1485.039|5.52|layer if there's any questions yeah yes
1488.279|5.441|what was your
1490.559|7.521|behind oh so so it end up so if you do
1493.72|7.0|Post layer Norm then then uh actually
1498.08|4.319|let uh is do I have that slide let me
1500.72|5.12|check probably would have deleted but if
1502.399|5.841|you do Post layer Norm then you are
1505.84|4.8|basically squashing both the residual
1508.24|4.039|and the additive parts so when you so
1510.64|3.159|your activations from the lower layers
1512.279|4.081|keep getting keep going through a layer
1513.799|4.641|Norms but in pre- layer Norm you're only
1516.36|4.0|only a residual path has a layer Norm
1518.44|3.44|which means your your activations all
1520.36|3.319|the way from the bottom of the model are
1521.88|3.919|free they're untouched and they can pass
1523.679|4.961|through
1525.799|6.721|yeah um
1528.64|5.8|okay okay so now so now I mean so until
1532.52|4.279|this point we haven't discussed why did
1534.44|4.479|we you know we haven't discussed multi
1536.799|5.041|had the tension which ended up being
1538.919|5.281|very important so one of the problems
1541.84|6.6|with the tension is that
1544.2|5.599|imagine if you wanted to yeah I mean so
1548.44|2.92|oftentimes language is a better
1549.799|4.521|understanding who did what to whom so in
1551.36|5.52|this case the the the cat licked the
1554.32|4.32|owner's hand so licked who licked what
1556.88|3.679|like the cat licked the owner right so
1558.64|4.68|now if you actually want to combine
1560.559|4.6|information from these two slots these
1563.32|3.52|positions these vectors then the best
1565.159|3.0|you could do with the tension is 0.5
1566.84|3.199|point5 with a single lay right half
1568.159|3.681|probability half probability but then
1570.039|3.281|they get mushed together right but now
1571.84|5.559|imagine the imagine the strength that a
1573.32|8.16|convolution has it can actually have
1577.399|6.081|uh that actually should have well okay
1581.48|4.52|well I think the point will still come
1583.48|5.4|across but uh so now what a convolution
1586.0|4.84|can do is because it has it it basically
1588.88|4.279|applies essentially a convolution in
1590.84|4.48|this case it's a 5 by one it all it
1593.159|4.481|really does is it just applies a
1595.32|5.44|different linear transformation at each
1597.64|4.12|position right so it can take any and
1600.76|3.24|because because these linear
1601.76|3.76|Transformations are different it can it
1604.0|3.2|can the first linear transformation can
1605.52|3.2|learn I'm going to take a little bit of
1607.2|2.68|information from here I'm going to take
1608.72|2.92|a little bit of information from here
1609.88|3.679|and I'm going to like put them together
1611.64|3.2|right and and and and the attention the
1613.559|2.84|best way that you could actually just do
1614.84|3.0|this is best by averaging that would bu
1616.399|2.801|all these things but having different
1617.84|3.12|linear Transformations allows you to
1619.2|3.719|take a part of the embedding here a part
1620.96|3.36|of the embedding here mix it up and then
1622.919|2.64|sort of maybe put it together without
1624.32|3.28|actually then interfering with each
1625.559|4.84|other and multi-head attention which is
1627.6|4.439|a bit like basically a multi-tape
1630.399|4.52|multi-ad
1632.039|5.12|like multi-ad turning machine with
1634.919|4.681|different different readed right heads
1637.159|5.801|essentially allows you start getting you
1639.6|5.76|that property back where now what you do
1642.96|4.319|is you essentially you essent you you
1645.36|3.96|you now you bring back the ability to
1647.279|3.921|select different parts of the input so
1649.32|4.44|you chop up the hidden Dimension into
1651.2|4.52|independent pieces and then each one of
1653.76|3.72|them is not is now able to do attention
1655.72|3.319|so now you can have probability one in
1657.48|4.0|this place and what probability one this
1659.039|4.0|other Subspace instead of having. 5.5 so
1661.48|2.88|now you don't you don't have to like you
1663.039|3.201|don't have to get these averaging
1664.36|4.679|effects you can actually be selective
1666.24|5.24|right so so so and and and and and also
1669.039|4.36|for computational reasons we instead of
1671.48|4.4|actually having eight attention layers
1673.399|4.441|of like or six attention heads of D
1675.88|3.24|Dimensions we had or eight attention
1677.84|3.559|heads of D Dimensions we had eight
1679.12|5.559|attention heads of D by8 Dimensions
1681.399|5.64|right so and and and and because so we
1684.679|5.48|wouldn't incur anymore we wouldn't incur
1687.039|4.681|any more um uh any more flops for the
1690.159|3.081|same amount of flops but that's only
1691.72|3.0|half the story because the attention
1693.24|3.2|heads themselves turn out to be quite
1694.72|3.04|expensive which which then later on had
1696.44|5.479|to be there were the improvements that
1697.76|7.12|needed to be made right um uh and and
1701.919|6.161|and and the most important part probably
1704.88|5.96|the most important results was that with
1708.08|5.8|the Transformer we were we were able to
1710.84|5.28|outperform previous previous ensembled
1713.88|4.0|models as well so and that was very very
1716.12|4.039|exciting that hey this single model
1717.88|5.399|actually is able to outperform previous
1720.159|5.76|ensembled models and and not only that
1723.279|5.961|and and this is machine translation WMT
1725.919|5.681|uh uh um 2014 English German and English
1729.24|4.0|French machine translation tasks not and
1731.6|6.0|not only were we able to do it in in in
1733.24|7.279|less in in in less flops but also these
1737.6|5.079|like if it was very it was it was very
1740.519|3.64|clear that this was this was a very
1742.679|3.441|general model is it we immediately
1744.159|4.041|applied it to parsing and we were able
1746.12|5.559|to get we were able to get with a small
1748.2|6.68|model excellent excellent results so so
1751.679|5.12|um and in some sense like you know we
1754.88|3.84|were this was this was very exciting
1756.799|3.441|because this meant that all right now
1758.72|3.12|this consolidation that we're trying to
1760.24|3.08|go for the machine learning we probably
1761.84|3.719|have a model that's more General than
1763.32|4.32|what we had before and we we can now
1765.559|3.761|throw it at different now maybe we can
1767.64|3.639|now throw it at different problems right
1769.32|4.04|and ultimately why
1771.279|5.12|because it would
1773.36|4.72|be helpful to have a single model that's
1776.399|4.681|able to combine representations from
1778.08|4.439|speech images and and and language and
1781.08|4.04|and if you had a general substrate that
1782.519|4.0|worked work and worked well in all tasks
1785.12|5.799|then potentially we could get to this
1786.519|6.081|single multimodal model um as as U
1790.919|4.201|sometimes interpretability are like like
1792.6|5.199|tea leaves uh it's like reading tea
1795.12|4.48|leaves so so so everyone should be
1797.799|3.76|careful but it was it was nice that you
1799.6|3.6|know the the attention by itself can can
1801.559|3.441|give you some interpretability and we
1803.2|3.92|were able to kind of see how you know
1805.0|4.279|how some some of these attention heads
1807.12|4.039|or some of these attentions attention
1809.279|3.4|mechanisms uh were actually able to
1811.159|3.921|learn long-distance relationships some
1812.679|5.081|actually learned to be kind of early on
1815.08|5.04|early on in the Transformer uh we saw
1817.76|3.759|this generally invariant pattern where
1820.12|2.279|some of the attention heads basically
1821.519|2.241|turned out to just look like
1822.399|3.561|convolutions they were just they were
1823.76|3.6|just pulling in local information
1825.96|2.8|there's of course now being much more
1827.36|4.0|advanced work with the some of the
1828.76|4.84|mechanistic interpretability stuff with
1831.36|4.12|uh with grocking and the stuff that
1833.6|3.76|that's happening in anthropic uh which
1835.48|4.48|is where they're learning now they're
1837.36|4.72|actually learning uh how how to
1839.96|3.839|interpret these induction heads so it's
1842.08|3.68|interesting but we were able to we were
1843.799|4.0|able to see some some anecdotal
1845.76|3.68|evidences evidence of these heads
1847.799|6.24|actually performing very very distinct
1849.44|7.44|and clear actions um okay so if there's
1854.039|3.841|any more questions then no more uh I'll
1856.88|2.799|pause
1857.88|3.279|do you buy the research on like that
1859.679|4.48|it's the induction heads that are
1861.159|3.0|causing the in context
1864.6|4.039|learning yeah it's hard to tell because
1867.279|3.481|so from what I haven't looked at the
1868.639|4.081|most recent work but they've solved this
1870.76|3.519|issue of superposition is that right so
1872.72|3.319|now with having solved that they're able
1874.279|3.88|to roughly does that roughly mean that
1876.039|3.721|now they they'll be able to assign
1878.159|3.36|distinguishing features to each one of
1879.76|5.08|these heads and be able to explain it I
1881.519|6.441|I I I I from what I understand or or or
1884.84|5.439|the in context learning part is is that
1887.96|3.599|uh is it that they have to show it or is
1890.279|2.88|it that they're saying that in context
1891.559|5.321|Learning Happens because of induction
1893.159|6.041|yeah the l oh it's the L yeah I it's not
1896.88|5.679|it's not clear because
1899.2|6.319|um yeah I think there's probably many
1902.559|5.561|many kinds of in context learning is
1905.519|4.481|shown to work in so many different tasks
1908.12|3.76|that uh and I actually I haven't
1910.0|3.36|followed this quite well I don't know I
1911.88|3.399|don't know specifically what are the
1913.36|3.84|induction heads typically do what kinds
1915.279|2.841|of What kinds of properties do they have
1917.2|3.359|what do you know what kinds of
1918.12|4.48|mechanisms they have okay so yeah so
1920.559|4.84|then so so since both of us don't know
1922.6|5.799|this really really well uh uh I we won't
1925.399|4.721|be able to go very far here but uh I I I
1928.399|2.961|I I'm not sure if they've gotten to the
1930.12|2.519|point where they're able to explain most
1931.36|3.12|of in context learning because of
1932.639|3.88|induction from what I understand they
1934.48|4.4|might have yeah does anybody anybody
1936.519|4.76|know about the induction
1938.88|6.6|heads okay
1941.279|6.481|um okay so so so now um over the over
1945.48|6.319|over the years um so there there have
1947.76|6.279|been a few there have been many papers
1951.799|3.961|but there have been a few changes that
1954.039|3.841|have been important there have been a
1955.76|4.48|few changes that that that that have
1957.88|4.279|stuck and and the new Transformers
1960.24|5.12|typically have these typically have
1962.159|5.721|these improvements right and and and you
1965.36|4.559|we'll go from bottom to top with some of
1967.88|4.0|them and see which ones which ones have
1969.919|3.841|actually stuck right so we started with
1971.88|4.36|the first one of the biggest problems
1973.76|4.519|with self attention was that it was uh
1976.24|4.64|that self attention itself this
1978.279|4.64|permutation invariant right you you you
1980.88|4.24|need to you need to you need to you need
1982.919|4.201|to dope position information in order
1985.12|3.64|for it to learn some kind of temporal
1987.12|3.88|temporal structure and in the original
1988.76|4.24|Transformer we used these sinusoids and
1991.0|3.84|we had hoped that it would actually
1993.0|3.919|learn relative position and codings
1994.84|4.52|because you could decompose the position
1996.919|4.0|and coding of another of another of you
1999.36|3.559|could you could decompose the position
2000.919|3.321|embedding of another position as some
2002.919|3.64|fun as some linear function of the
2004.24|3.36|previous one and we and and some and
2006.559|3.36|another
2007.6|4.199|uh another factor which is which depends
2009.919|4.24|on the relative distance between the two
2011.799|4.72|but that didn't happen uh learn position
2014.159|6.601|en codings in the original paper
2016.519|6.921|uh did as well and uh so so we were not
2020.76|4.48|quite able to get the the we were not
2023.44|4.239|quite able to get these model relative
2025.24|3.84|distances using the sinusoids so then uh
2027.679|3.081|a couple of you know a couple of
2029.08|3.76|important and this is a very biased
2030.76|5.759|sample uh but I think it generally
2032.84|5.959|covers a large category of these uh uh
2036.519|4.64|it covers large large set of papers
2038.799|5.161|there's roughly sort of three categories
2041.159|4.601|right so there's um and and all of them
2043.96|4.199|are kind of now explicitly learning
2045.76|5.2|relative uh explicitly learning relative
2048.159|5.161|embedding so so there's so so in in the
2050.96|4.8|in the relative position Transformer we
2053.32|4.44|had an embedding for every pair of
2055.76|3.839|relative positions and using that we
2057.76|3.28|basically then dot we did a DOT product
2059.599|3.56|of that embedding with the query that
2061.04|4.319|produced a loit that was that modulated
2063.159|4.44|according to the relative distance and
2065.359|5.121|we found this to be extremely uh we
2067.599|6.0|found this to be uh extremely useful for
2070.48|6.399|translation but and I'll show also music
2073.599|5.161|um another another sort of maybe a
2076.879|3.641|simplification uh This Is The Alibi
2078.76|3.919|paper where this is nonparametric these
2080.52|4.24|are not learned where instead of an
2082.679|4.48|embeding for every pair of positions you
2084.76|4.52|actually have a single bias right so you
2087.159|4.641|you so you just add a single bias to the
2089.28|5.04|login and you can either learn it or you
2091.8|5.16|can you can or or you can use a
2094.32|4.4|heuristic which which Alibi did and one
2096.96|3.08|one other Advantage about relative
2098.72|3.399|position en codings is that they could
2100.04|3.68|potentially allow you to extrapolate to
2102.119|3.081|new to longer sequence length right
2103.72|3.96|which you couldn't do with absolute
2105.2|5.56|position and codings
2107.68|5.399|um I'm curious about the room about what
2110.76|4.24|the room thinks here but I believe that
2113.079|3.721|the the latest the the the latest
2115.0|4.52|Incarnation Val position and codings
2116.8|5.24|where this is I believe it's called the
2119.52|5.68|the row forer where they basically just
2122.04|5.44|you know rotate the embedding of with
2125.2|4.12|every pair of dimensions a little bit so
2127.48|4.04|and and the and the and the angle of
2129.32|3.84|rotation depends on on your actual
2131.52|3.72|absolute distance but what ends up
2133.16|3.679|happening is when you when you do the
2135.24|4.4|attension operation you end up getting
2136.839|4.361|relative uh you end up basically getting
2139.64|3.719|an effect where you're modulating the
2141.2|3.84|ljit based on relative distance so now
2143.359|3.841|what's remarkable about this approach
2145.04|4.44|what's what's it combines the best of
2147.2|4.04|both rols right it actually it's
2149.48|3.359|absolute position in codings uh relative
2151.24|3.96|position encodings had a couple of
2152.839|4.52|challenges in that they you had to
2155.2|3.76|maintain an extra lit for or an
2157.359|4.041|embedding for every pair so there was a
2158.96|4.359|lot of me so it ended up increasing your
2161.4|3.439|memory uh here these are actually
2163.319|3.681|absolute position encodings but they
2164.839|4.201|gave you they ended up giving you the
2167.0|4.28|the relative modulation in the in the
2169.04|3.88|attention operation that you needed and
2171.28|3.64|I I believe the consensus is that this
2172.92|3.679|is the most successful this is the most
2174.92|3.96|successful position in coding is that
2176.599|4.401|correct or are there is there are there
2178.88|4.28|others that are the people is is that
2181.0|5.4|the
2183.16|5.28|consensus okay so so it looks like so I
2186.4|3.959|I I would say that the the the the the
2188.44|4.159|the these relative rotations or from or
2190.359|5.881|the the approach that's in the reformer
2192.599|5.801|is is is likely is is basically an
2196.24|3.599|actual new genuine Improvement that is
2198.4|3.12|now going to stay with the Transformer
2199.839|3.48|and and it has all the it has all the
2201.52|3.76|great properties of what you would want
2203.319|3.121|it it's it has it's an absolute position
2205.28|2.24|in quoting that gives you relative
2206.44|5.04|effects which is what we originally
2207.52|6.76|wanted um and and and one and and and to
2211.48|5.72|emphasize emphasize that we needed
2214.28|6.76|relative like um that
2217.2|6.159|U being uh emphasize two things one that
2221.04|3.799|modeling temp like interesting temporal
2223.359|4.24|relationships which is which are really
2224.839|5.041|important in music uh requires a good
2227.599|3.601|position representation uh we actually
2229.88|3.88|found significant improvements in the
2231.2|8.159|music Transformer is it is it possible
2233.76|7.64|to play this okay so so so here is a um
2239.359|6.24|here's a priming sequence this is this
2241.4|7.199|is work by by work by Anna hang by the
2245.599|3.0|way
2252.119|5.2|so this is a in context learn in music
2256.119|4.401|because you actually see this prompt and
2257.319|4.961|you ask the model to complete it uh okay
2260.52|4.72|so now this is the vanilla Transformer
2262.28|2.96|and you can
2269.2|4.68|already so you can see that uh these
2271.96|3.32|these were using I mean we tried both
2273.88|4.0|learned and sinusoids and you can see
2275.28|3.839|that it starts all all py and happy but
2277.88|2.64|then just sort of languishes into
2279.119|3.561|something really sad and and and
2280.52|4.12|confused right so it's not able to
2282.68|4.0|capture these because mus music has
2284.64|3.679|these interesting motifs where well
2286.68|4.0|there's there's there's motifs at
2288.319|3.721|different levels because you know
2290.68|2.96|there's some repetition locally but
2292.04|3.96|there's a repetition across the entire
2293.64|7.32|piece as well so now here this is with
2296.0|7.079|the uh uh relative Transformer and and
2300.96|4.84|this is with the uh first approach where
2303.079|6.24|we had relative embeddings and we had to
2305.8|5.4|we had to we had to develop a an a
2309.319|4.441|compute efficient approach to actually
2311.2|4.8|with by using some Matrix uh
2313.76|3.559|calisthenics to actually put the loits
2316.0|4.24|in the right place so you can read the
2317.319|6.04|papers it's fun uh so here's same Prime
2320.24|6.119|sequence and uh let's see the
2323.359|3.0|completion
2335.52|3.0|here
2343.96|3.44|so Anna who's the first author of this
2345.64|3.28|paper and also musician tells me this
2347.4|3.919|actually captures a lot of structure in
2348.92|4.679|music I I uh it sounds nicer than the
2351.319|3.601|previous one but maybe depends on what
2353.599|4.52|people's tastes here like maybe some
2354.92|5.48|avangard jazz fan would like the second
2358.119|4.72|would like the first piece but but but
2360.4|4.08|but the the point here was that like the
2362.839|3.601|difference is pretty clear between not
2364.48|3.96|working and working and I I think people
2366.44|4.36|it would be fun to try this out with the
2368.44|6.2|with the new rotary position en
2370.8|6.799|codings all right um okay so so so so so
2374.64|5.719|walking up um now that we have a we have
2377.599|5.161|a good mechan a better mechanism than we
2380.359|4.361|originally had for modeling relative
2382.76|3.52|distances and and and and and and
2384.72|3.16|there's there's there's advancements on
2386.28|3.48|top of the rotary position en codings
2387.88|3.88|where by adjusting the base frequencies
2389.76|3.64|you can you can when you when you
2391.76|3.4|encounter longer sequences you can just
2393.4|3.8|adjust the base frequencies and then the
2395.16|3.72|model is not going to uh
2397.2|3.919|uh the model is not going to degrade so
2398.88|4.239|that that has good properties uh
2401.119|4.881|probably the the there's been there have
2403.119|5.121|been several several important uh uh
2406.0|4.56|contributions to to the attention piece
2408.24|4.48|itself which which is which is the
2410.56|3.4|primary Workhorse here it's the it's the
2412.72|3.96|one that you can think of it as it's
2413.96|4.119|either it's it's it's um it's there's
2416.68|3.32|induction heads that are learning how to
2418.079|4.161|coffee or maybe all it's really doing is
2420.0|3.56|just routing information so that the
2422.24|3.56|giant feed forward layers can actually
2423.56|4.519|learn the important features right but
2425.8|4.48|there's brly two classes of problems
2428.079|3.52|there are two classes of issues uh with
2430.28|3.0|the attention mechanism one that was
2431.599|4.881|brought up today that's very evident is
2433.28|5.4|is long context itself right so so uh
2436.48|4.4|the the the complexity as we remember
2438.68|3.919|was quadratic in the length of the
2440.88|3.68|sequence and once your sequences get
2442.599|6.48|very very long once your sequences get
2444.56|5.799|very very long then uh uh not only I
2449.079|2.52|mean there's there's one problem is
2450.359|2.801|going to it's going to become very it's
2451.599|3.201|going to become computationally
2453.16|3.8|expensive but it's also the logits that
2454.8|4.16|are going to become infusible right so
2456.96|4.52|there's sort of just generally like a
2458.96|4.08|few groups of papers one is restricting
2461.48|4.28|attention windows and we did this for
2463.04|6.2|images images where they had local 1D
2465.76|5.28|and and 2D uh 2D attention for images
2469.24|3.4|and the first in the first one we
2471.04|3.24|actually just rasterized the image and
2472.64|3.64|we had local 1D attention which is very
2474.28|5.52|similar to the sliding window attention
2476.28|5.0|in uh in the in the recent nostal paper
2479.8|5.319|and then in the
2481.28|6.0|uh uh and in the um in the 2D case we
2485.119|3.96|have a spal 2d uh spatial to attention
2487.28|4.079|right then there's these sparse versions
2489.079|4.76|where you actually you you have these
2491.359|4.681|specific patterns that over many layers
2493.839|5.161|I mean you can think about it as if you
2496.04|4.36|have these sparse matrices how many of
2499.0|2.72|them do you have to multiply with each
2500.4|3.28|other until until you get a really dense
2501.72|5.92|Matrix right so roughly this kind of
2503.68|6.2|turns out to be so here you can get
2507.64|7.12|connectivity except for
2509.88|6.36|me okay uh uh uh um you can you can get
2514.76|3.559|connectivity you can get connectivity
2516.24|5.32|between distant pixels distant pixels or
2518.319|6.04|distant uh notes in a in in in a musical
2521.56|4.92|tune or words pretty quickly uh and then
2524.359|4.121|there's a second one which I which is
2526.48|3.44|which there hasn't been enough work and
2528.48|3.72|there there's there's some challenges
2529.92|3.76|there but it's it's these unstructured
2532.2|3.44|sparse attention approaches and they're
2533.68|3.88|typically they're essentially what
2535.64|5.36|they're at a higher level what they're
2537.56|5.799|really trying to do is imagine that I
2541.0|7.04|walked up to you and I told you that hey
2543.359|7.281|these These are the Bunches of um of
2548.04|4.2|tokens that just have very high inter
2550.64|3.84|similarity like they're likely to attend
2552.24|3.52|to each other how quickly can I approxim
2554.48|4.359|without actually having to do the whole
2555.76|4.4|computation right two approaches and and
2558.839|4.841|routing attention you use vector
2560.16|5.88|quantization and in in the L or
2563.68|3.96|the I forget what it's called I think I
2566.04|5.36|forget the name of the paper but they Ed
2567.64|6.24|but in this paper they used lsh and um
2571.4|5.32|and and and in the in the in the routing
2573.88|5.6|Transformer most layers were actually
2576.72|4.56|local uh the the final layers which
2579.48|3.72|typically are the ones that like to end
2581.28|2.96|up that end up do modeling that end up
2583.2|2.24|modeling these long distance
2584.24|3.4|relationships were the ones that
2585.44|4.84|actually use this kind of content based
2587.64|3.919|unstructured sparse attention and uh and
2590.28|2.52|the results were the results were
2591.559|4.601|generally better and it's also
2592.8|4.96|interesting that maybe we can build we
2596.16|3.52|can build models but very on very long
2597.76|3.359|sequen sequences where most layers are
2599.68|2.399|fairly local and have only a few there
2601.119|2.881|that are actually doing these long
2602.079|4.401|distance attentions now one of the
2604.0|4.96|bigger challenges there actually even
2606.48|5.04|though it ended up being even though you
2608.96|4.24|end up um you end up nullifying a lot of
2611.52|3.799|the flops that you would do if you did
2613.2|4.28|full attention the problem always ends
2615.319|4.361|up being memory movement always ends up
2617.48|3.28|being memory movement and and and and
2619.68|2.48|there's still there's still more
2620.76|3.28|Innovation to be done here also with
2622.16|3.12|like memory bandwidth improving maybe
2624.04|4.24|some of these approaches become more
2625.28|4.72|feasible today than than they were when
2628.28|3.0|we did when we wrote these papers but
2630.0|2.28|this is an interesting approach where
2631.28|2.24|you're kind of essentially trying to
2632.28|3.76|approximate the original attention
2633.52|4.12|Matrix sorry this is kind of
2636.04|4.2|clarification how is
2637.64|4.959|thisr scheme very different from like
2640.24|4.56|just convolutions that are in the sense
2642.599|4.401|that you're losing a lot of the long
2644.8|6.0|distance or unrelated context from any
2647.0|5.44|arbitrary compar elements so right so I
2650.8|4.88|would say that this is similar to the
2652.44|6.28|convolution there if you did this
2655.68|4.879|perfectly then what you didn't attend to
2658.72|4.16|would wouldn't would like very likely
2660.559|3.961|that has very low attention we s so
2662.88|3.239|that's you're essentially trying to
2664.52|3.36|you're essentially trying to guess as
2666.119|4.361|best as you can what would have attended
2667.88|4.88|to each other and that's and so it uses
2670.48|5.52|it's content based like content based on
2672.76|4.64|structured farity um and and and there's
2676.0|3.04|probably more interesting work to be
2677.4|3.32|done there maybe you know instead of
2679.04|2.96|actually just doing a token at a time
2680.72|3.28|where you end up doing a lot of memory
2682.0|3.599|movement you end up deciding which
2684.0|2.839|chunks want to self attend to which
2685.599|3.24|chunks so then you just move in pair
2686.839|2.801|chunks at a time right so there's I
2688.839|4.28|think there's some interesting
2689.64|6.719|directions here um and of course um and
2693.119|5.96|and and frankly um the the ones that
2696.359|5.0|ended up sing out the simplest ones that
2699.079|4.921|are also that are and because structured
2701.359|4.801|scarcity is easy you're you're able to
2704.0|5.559|optimize it easy easily on Modern
2706.16|5.72|accelerators so again physics uh you
2709.559|4.56|should make physics your friend yeah and
2711.88|3.679|and and so typically local attention or
2714.119|3.24|sliding into attention we're still
2715.559|3.841|seeing we're still seeing it often
2717.359|5.801|appear and do well uh these other sort
2719.4|5.24|of very really wild and uh but very
2723.16|3.48|expressive unstructured SPS attention
2724.64|3.84|approaches typically Haven haven't quite
2726.64|3.919|succeeded uh there's of course linear
2728.48|4.16|attention variants that I don't think
2730.559|3.56|today are in any of the state are
2732.64|2.88|architectures there were other
2734.119|4.401|approaches that hey instead of actually
2735.52|5.839|doing N squared you do uh n squar d
2738.52|5.64|where you you do n you have some you you
2741.359|5.801|you learn new K embeddings where you do
2744.16|5.6|nkd and then you do ndk so you basically
2747.16|4.679|Factor it right just like like an analog
2749.76|3.799|matric factorization something that's
2751.839|3.72|one other approach that's interesting
2753.559|4.52|that I would like myself to actually
2755.559|4.8|invest investigate is we are seeing in
2758.079|3.641|general using retrieval as a tool so why
2760.359|3.48|don't you just pretend that your
2761.72|4.0|memories your memories themselves were
2763.839|4.561|documents and use retrieval as a tool
2765.72|5.0|there so the memorizing Transformer uh
2768.4|5.08|basically it essentially does a mix of
2770.72|4.44|local and it then retrieves from very
2773.48|3.04|very long very very long memories and
2775.16|3.08|they find that you don't need to train
2776.52|5.48|the model from scratch all you need to
2778.24|5.16|do is adapt with this approach uh on on
2782.0|2.559|on some a small amount of data and
2783.4|2.88|you're able to learn a good retrieval
2784.559|3.961|mechanism I think it's quite interesting
2786.28|5.16|it it kind of it still kind of comes in
2788.52|4.52|this like uh content based R content
2791.44|3.8|based decision of what I should attempt
2793.04|3.88|to but I I like the fact that it it's it
2795.24|2.92|just sort of makes retrieval a tool that
2796.92|2.76|you can use on either on your own
2798.16|3.36|memories or you could use it on
2799.68|3.679|documents it's it's it's a nice
2801.52|4.16|generalizing it's a nice General view of
2803.359|5.2|looking at things um okay so now the
2805.68|5.639|second piece which which not you you you
2808.559|4.161|basically you run into not all you run
2811.319|4.121|into the issue that not all flops are
2812.72|4.48|equal right so if you um if you look at
2815.44|3.8|the if if you look at the memory
2817.2|4.399|hierarchy right a lot of your
2819.24|4.76|activations and that are stored in the
2821.599|5.361|the GPU hbm which today in the h100 is
2824.0|7.559|about is about 80 gigabytes but you know
2826.96|6.56|um the the the H1 h100 is 80 gigabytes
2831.559|4.121|when the a100 is used to be 40 gigabytes
2833.52|4.319|right so it's limited amount of of high
2835.68|4.28|bandwith memory and and so you have to
2837.839|3.441|first go from high bandwith memory to to
2839.96|3.52|the SRAM and then you have to go to the
2841.28|5.2|computer elements and then back right so
2843.48|7.079|every single time and this is I mean
2846.48|6.16|it it it probably uh in you know
2850.559|3.8|whenever if if if interested you should
2852.64|4.8|look at roof Lan analysis the roofline
2854.359|5.96|analysis actually gives you a uh gives
2857.44|6.159|you a nice picture to characterize for
2860.319|6.721|any device you know what uh where you
2863.599|5.121|would need where your your workload or
2867.04|3.36|operation needs to be so that you can
2868.72|3.52|actually effectively utilize the compute
2870.4|3.32|as much you want to be compute bound
2872.24|2.96|because ultimately if you don't
2873.72|2.879|calculate representations if you don't
2875.2|3.119|calculate you're not going to get any
2876.599|3.321|outputs but if you spend a lot of time
2878.319|3.76|moving things around and spend less
2879.92|4.36|relative time calculating then you're
2882.079|4.561|then you're then you're actually you're
2884.28|4.2|you're kind of wasting effort right so
2886.64|3.56|so so one of the so if you at standard
2888.48|3.599|attention mechanism right one of the
2890.2|3.72|issues is that okay so imagine you have
2892.079|4.601|your queries keys and values all in your
2893.92|5.0|all in your memory then you need to then
2896.68|4.56|uh your standard approach would be you
2898.92|4.0|move it you move it from hbm you do the
2901.24|3.96|calculations you compute the attention
2902.92|4.6|you compute the logits you move logits
2905.2|5.08|back into HPM and then you can get
2907.52|5.72|softmax right the softmax back into HPM
2910.28|5.279|and and then you basically load uh the
2913.24|4.52|the probabilities uh and and the values
2915.559|6.04|then to then finally compute the outputs
2917.76|5.559|right so the the arithmetic intensity or
2921.599|3.96|the arithmetic intensity or operational
2923.319|5.0|intensity which is the amount of flops
2925.559|4.641|that you do per bite on a tension even
2928.319|4.321|though it's less flops than say a 1 by
2930.2|3.76|one convolution it it has more it is
2932.64|3.159|lower because it typically has more
2933.96|3.44|memory movement as one by one
2935.799|3.0|convolutions have less memory movement
2937.4|2.76|you just move the weights you move the
2938.799|3.0|activations you do the calculations and
2940.16|3.04|you bring them back right and same goes
2941.799|3.04|for convolutions too and convolutions
2943.2|2.8|have a very high arithmetic intensity
2944.839|2.72|it's not that you just want the highest
2946.0|3.72|arithmetic intensity or operational
2947.559|3.921|intensity operations because you still
2949.72|4.8|want to have useful parameters right so
2951.48|4.639|it's a trade-off so so so so a lot of so
2954.52|4.52|there's been a bunch of improvements
2956.119|4.96|that will stick I mean there it's almost
2959.04|4.079|almost certain likely to stay that that
2961.079|3.72|try to combat this issue both at
2963.119|3.521|training time because your Logics can
2964.799|3.921|get really big but also inference time
2966.64|3.4|your KV when you're when you're when
2968.72|2.879|you're doing attention when you're doing
2970.04|3.68|inference then you have a single query
2971.599|4.041|but your KV cash right you have to to
2973.72|3.16|maintain your keys and values that can
2975.64|3.88|grow quite a bit so you have to move
2976.88|3.84|that around and so the first the the
2979.52|4.12|first step is hey simple let's just
2980.72|4.68|decrease the activation memory so so the
2983.64|4.4|so the multiquery approach where it's
2985.4|5.159|basically uh you know multiple so you
2988.04|4.6|reduce you you have multiple queries
2990.559|4.481|with just you reduce the number of uh
2992.64|4.159|read heads uh to just one so just one p
2995.04|4.0|and one value that does reduce your
2996.799|4.161|expressivity so grouped query which is
2999.04|3.68|now a simp like simple balance that
3000.96|4.359|basically says hey let's not take the
3002.72|4.359|extreme of having all this temporary
3005.319|3.8|activation memory let's actually group
3007.079|4.24|it so different queries so a bunch of
3009.119|4.601|queries will attend to the same keys and
3011.319|5.841|values and and then what what it ends up
3013.72|5.2|happening is um another point to note
3017.16|3.679|here is that all of this is relative
3018.92|4.159|because most of the work in these very
3020.839|5.921|very oh by the third approach actually
3023.079|5.24|that I should say of uh of not worrying
3026.76|3.4|about your attention is just to make
3028.319|3.161|your model really B because then you
3030.16|2.48|just care about your feet forward
3031.48|2.8|computations and your attention
3032.64|3.32|computations this like a small slice of
3034.28|4.2|that so you don't worry about it right
3035.96|5.359|so typically these larger models even
3038.48|4.28|though grouped query attention uh is it
3041.319|3.48|has more activation memory than
3042.76|4.319|multiquery when with these large models
3044.799|3.921|it's still not a much larger it's not a
3047.079|2.681|much larger it's still a smaller
3048.72|3.879|proportion of what you're doing in the
3049.76|5.039|fe4 sure line right so I guess three
3052.599|5.2|things like ignore make it really make
3054.799|6.641|it really big uh second is I guess you
3057.799|5.52|you by the even the uh with prolong
3061.44|3.24|context you can you can do some of the
3063.319|3.161|the some of these approaches that you
3064.68|3.639|talked about but then then you also have
3066.48|6.28|these system optimizations which are
3068.319|5.881|pretty cool um it so the softmax has an
3072.76|2.839|interesting property that you can
3074.2|2.639|compute it an online fashion you can
3075.599|2.72|compute it incrementally so if you've
3076.839|2.96|got a if you've got if you've got a
3078.319|2.921|bunch of Logics you're kind of streaming
3079.799|3.081|them if you've got a partial if you've
3081.24|3.24|got a partial softmax and a new logic
3082.88|3.719|comes in you can update it you can
3084.48|6.119|update it on online fashion right so
3086.599|6.561|what does that mean that means that now
3090.599|4.96|you never needed to write logits or the
3093.16|4.08|P into the hbm so you save a lot right
3095.559|3.921|if there's an extremely long sequences
3097.24|4.359|you end up writing a lot so you you save
3099.48|4.599|on that and and both these approaches
3101.599|4.881|end up uh in one case the first paper
3104.079|4.561|was on tpus that introduced this this uh
3106.48|4.68|introduced this property or or took
3108.64|3.64|advantage of this property is on the
3111.16|2.88|property to be able to compute the
3112.28|3.559|softmax in an online fashion and the
3114.04|4.24|second paper which is now flash
3115.839|4.801|attention today um they've had they've
3118.28|4.16|had many advancements they actually had
3120.64|3.56|some systems level optimization where
3122.44|4.24|they they they now you can actually have
3124.2|5.0|very very long sequences on uh on on
3126.68|5.639|gpus the optimizations of gpus by by
3129.2|5.159|basically not not not moving the loit
3132.319|3.52|back into hbm using this online using
3134.359|3.48|this property and also I me writing the
3135.839|6.161|right corns that use theam and
3137.839|6.441|everything use the GP any with any
3142.0|5.28|questions uh what's the
3144.28|3.0|time
3147.319|4.881|so we are basically 20 minutes more so
3149.64|3.84|I'll finish in 10 uh so so I just
3152.2|3.8|covered these two you know there's
3153.48|4.16|there's many many there's I guess
3156.0|4.559|there's there's other important
3157.64|4.64|improvements um you know I'd say so we
3160.559|3.56|talked about the pre pre and post versus
3162.28|3.76|post layer Norm there's been some
3164.119|3.96|there's been some changes of the feed
3166.04|3.36|forward layers themselves like you can
3168.079|3.28|you can you can stare at the feed
3169.4|3.04|forward layers I mean you sted anything
3171.359|2.281|long enough everything becomes ATT
3172.44|2.96|tension but it's true in the feed
3173.64|4.08|forward case that if you look at it you
3175.4|4.439|can sort of think about them as it looks
3177.72|5.599|like attention and there's a paper that
3179.839|5.52|sort of uh like turned that into a bit
3183.319|3.641|like turn that turn those into memories
3185.359|4.321|it was originally by Facebook I actually
3186.96|5.04|forget what it was but it didn't it like
3189.68|4.159|the the feed for layers just stay I mean
3192.0|4.52|we typically haven't seen a lot of
3193.839|5.28|improvements on them um there have been
3196.52|4.36|some i i i there have been some efforts
3199.119|3.081|on higher order attention right now
3200.88|3.0|attentionally if you think about it as a
3202.2|4.44|third order interaction you have queries
3203.88|4.56|keys and values but uh and right now but
3206.64|3.199|but you could imagine actually having
3208.44|3.639|four order interactions where you're
3209.839|4.041|actually Computing lits of pairs of
3212.079|2.881|things against all pairs of things right
3213.88|2.52|so these are now higher order
3214.96|4.159|interactions where now you can have
3216.4|4.88|complicated like geometries that you
3219.119|3.881|actually include in your uh include in
3221.28|3.6|your attention computation and maybe
3223.0|4.16|it's important for say biology or some
3224.88|4.6|biology but it's not been explored much
3227.16|4.6|um what has actually worked and as
3229.48|5.24|likely to N St as some approaches on
3231.76|5.28|passor decoding not quite the original
3234.72|4.24|less or non-auto regressive aspirations
3237.04|3.68|that we had but these more speculative
3238.96|4.879|decoding where the heris stic there is
3240.72|5.399|pretty simple yeah you score if you want
3243.839|4.24|you instead of generating from a heavy
3246.119|3.801|model generate from a really light model
3248.079|3.201|that captures the diversity then score
3249.92|3.32|with a heavy model so then you then you
3251.28|5.039|rerank the list and that ends up working
3253.24|4.96|quite well and most most most State most
3256.319|4.8|um production deployments likely use
3258.2|4.8|speculative decoding um okay so now
3261.119|4.801|switching Switching gears I guess you
3263.0|5.119|know we start we started we started this
3265.92|5.399|uh we started this or we started we
3268.119|4.48|started by you know quoting the the
3271.319|2.721|Dartmouth conference where they wanted
3272.599|3.041|to build a single machine and and and
3274.04|3.84|the question now is with large language
3275.64|4.6|models that are now eating up most of
3277.88|3.719|the internet uh are we getting are we
3280.24|3.359|quite getting there and and and we are
3281.599|3.881|seeing some remarkable we're finally
3283.599|4.841|seeing self-supervised learning work at
3285.48|7.079|a scale that work at an unprecedented
3288.44|6.639|scale where you with now by by by like
3292.559|4.321|digesting carefully curated and colossal
3295.079|3.641|amounts of text with very very large
3296.88|4.8|models you're able to then they're able
3298.72|6.04|to perform presumably or still waiting
3301.68|5.76|to be confirmed like tasks that are that
3304.76|4.96|tasks that are that are or they able to
3307.44|4.24|actually perform at least a large a
3309.72|4.079|broad variety of tasks by just
3311.68|4.32|specifying them in the prompt and and
3313.799|4.481|and it's now it's almost like now you
3316.0|3.599|have now you have a new computer and for
3318.28|2.96|people here who are really excited about
3319.599|3.081|the future of Agents now they can
3321.24|4.52|program thousands of Agents with the
3322.68|5.2|same computer oh maybe you now they have
3325.76|3.799|now they have now they have agents that
3327.88|3.479|they can several agents that they can
3329.559|4.681|program with the same computer then that
3331.359|4.72|then coordinate to solve problems so I I
3334.24|3.799|we're getting we're much closer to this
3336.079|3.881|single model not quite being able to
3338.039|3.841|specify all the rules of intelligence
3339.96|4.839|but at least learning all the rules from
3341.88|4.6|data we're very close to very we're much
3344.799|3.401|closer to it than we were before now
3346.48|4.359|this doesn't include all the important
3348.2|4.52|thing the all the important um uh
3350.839|4.681|specialization that has to happen after
3352.72|5.399|like RF or the the the alignment that
3355.52|6.12|you have to do the to make them aut most
3358.119|7.521|steerable right but it's and and and and
3361.64|6.08|and and as it stands today the scaling
3365.64|4.24|laws that the Transformer exhibits are
3367.72|4.399|better than any other existing model
3369.88|3.04|right there's an interesting question of
3372.119|3.401|you
3372.92|4.56|know which can we build a better model
3375.52|4.2|and there are efforts there's I guess
3377.48|3.72|from from the Stanford from Chris Chris
3379.72|3.44|Chris R lab there have been a couple of
3381.2|5.48|efforts uh there's been some Revival of
3383.16|5.0|RNN but I think only the only the only
3386.68|3.399|thing I'll say that is that the
3388.16|3.639|attention operation itself this
3390.079|3.52|operation of actually moving information
3391.799|5.481|around or routing information based on
3393.599|5.44|content is is very very useful and and
3397.28|3.96|it's maybe not a surprise that this
3399.039|3.961|General sort of spatial mixing up
3401.24|3.04|upsampling down sampling architecture
3403.0|3.2|has kind of stayed both in Vision
3404.28|3.48|computer vision and language now with
3406.2|3.52|the Transformer so there are some
3407.76|3.839|invariants that are likely to say but I
3409.72|4.52|I do think that maybe that and and there
3411.599|5.041|is certainly much more room there to
3414.24|4.359|improve I mean not just in the
3416.64|3.8|architecture but on data itself like
3418.599|4.76|there probably 2x improvements on on
3420.44|4.399|data uh but I I I wouldn't say that
3423.359|3.48|there's there aren't architectur in the
3424.839|3.96|future that'll get better scaling laws
3426.839|3.681|they kind they might but there are
3428.799|3.401|properties about the Transformer such as
3430.52|3.48|self attention and its General
3432.2|3.119|structuring that is likely that that
3434.0|5.48|likely we're going to see in future
3435.319|7.24|architectures to come um also it's hard
3439.48|4.599|to really think of a a sing modern like
3442.559|2.881|if if you if somebody really really
3444.079|3.841|wanted to study lar scale modern
3445.44|6.08|Transformers you'd have to study like
3447.92|5.639|you know all reducers infin band Rocky
3451.52|4.559|and what like whether you get conest and
3453.559|4.161|you have very very large clusters uh so
3456.079|3.401|it's it's interesting and so the
3457.72|3.96|computer is know the computer the
3459.48|4.24|Transformers is now in some sense a data
3461.68|3.639|center because it's not split up these
3463.72|4.599|large Transformers or with tens of
3465.319|7.0|potentially tens of thousands of gpus so
3468.319|6.881|um uh and and and so if you so so now
3472.319|4.321|you actually have to really focus on
3475.2|3.919|several parts the
3476.64|4.8|infrastructure and and the model itself
3479.119|3.72|but what's really interesting I think is
3481.44|3.32|you know I was just thinking of the
3482.839|4.161|smallest model that has exhibited
3484.76|5.24|emergent phenomena well so we certainly
3487.0|5.24|know that gp4 which is likely uh I don't
3490.0|4.64|know if you're allowed to say some big
3492.24|4.28|like trillion parameters yeah I think
3494.64|3.56|say yeah it's it's a trillion parameter
3496.52|4.0|size model that's what everybody says
3498.2|4.32|size model and then you have grocking
3500.52|4.36|which is a two layer Transformer that
3502.52|4.64|has this weird emerg being weird
3504.88|4.199|emergent behavior that when you just
3507.16|3.36|keep training it on just on some amount
3509.079|4.0|of data suddenly it just exhibits a
3510.52|5.319|spaces shift right so we're lucky there
3513.079|4.201|these like really there's strange
3515.839|2.841|there's weirdness everywhere there's
3517.28|4.0|weirdness in small models and large
3518.68|4.2|models and and and maybe that and maybe
3521.28|3.16|we can learn something about a large
3522.88|4.36|models by studying these smaller models
3524.44|4.119|one would hope but it's funny like
3527.24|3.24|there's there's there's still
3528.559|4.361|unexplained phenomena in very very large
3530.48|4.359|models and very very small models but
3532.92|5.199|large Transformers are no more just you
3534.839|5.321|know like a cab there's just I mean it's
3538.119|4.401|still could still be but it's you have
3540.16|4.879|to there's so many there there's so much
3542.52|4.519|that you have to to keep in your stack
3545.039|5.161|in order to really optimize this entire
3547.039|5.32|this this model um of course some of the
3550.2|5.68|very exciting directions are llm using
3552.359|5.801|llms using tools you that's so now now
3555.88|3.4|the now the benefits of now now language
3558.16|2.48|models of Transformers are actually
3559.28|2.36|starting to use external entities so
3560.64|3.12|they're connecting with the rest of the
3561.64|4.64|world and and and I guess that's a
3563.76|4.359|that's a good that's a good pitch for it
3566.28|3.519|it makes a lot of sense to to actually
3568.119|4.041|build products today because it's
3569.799|3.921|through interactions with like if you
3572.16|3.76|want to get to the next trunch of
3573.72|4.92|capabilities where will they come from
3575.92|4.399|and and likely with a lot of usage you
3578.64|3.479|will learn much more about how to guide
3580.319|3.72|these models and how to train them
3582.119|3.281|without then in then in vacuum now you
3584.039|4.241|can definitely do very very important
3585.4|4.719|work still in in in in by by even with a
3588.28|3.279|smaller model or or even without
3590.119|2.281|building a product without building a
3591.559|3.441|product because there's so many
3592.4|3.84|important unsolved problems uh and and
3595.0|2.64|uh maybe you shouldn't even work on the
3596.24|2.599|Transformer because it's like burning
3597.64|4.8|man right now everybody's going to the
3598.839|5.52|same party but um but um but I I think
3602.44|4.0|that you will you will be able to build
3604.359|4.561|new capabilities once these once with
3606.44|5.44|this human human machine collaboration
3608.92|4.36|um of course you know teaching models I
3611.88|3.719|me or models being able to express what
3613.28|4.4|they don't know uh how do you learn new
3615.599|3.681|skills at infants time important for
3617.68|3.48|there's an interesting work I think on
3619.28|4.48|um Minecraft that showed some evidence
3621.16|5.8|of this is also important for agents and
3623.76|4.599|another great property that uh some of
3626.96|3.599|these diffusion models have is the more
3628.359|3.361|compute you spend the potentially better
3630.559|2.681|the quality of the image gets but we
3631.72|3.359|don't exactly quite have that for
3633.24|4.0|language can and and what does that mean
3635.079|4.24|like so today the best the models that
3637.24|4.76|can reason that have the most proficient
3639.319|4.72|reasoning uh and planning are also the
3642.0|4.28|largest ones can we can we separated it
3644.039|4.201|out can we have smaller models that do
3646.28|4.44|some adaptive thinking and have are able
3648.24|4.119|to match the capabilities of potentially
3650.72|3.76|larger models and reasoning and planning
3652.359|3.881|and maybe the answer is going to come by
3654.48|4.559|connecting to external planners and
3656.24|4.92|planners or or or maybe with better
3659.039|5.481|representations of data you can actually
3661.16|5.8|reason better on it um also um this is
3664.52|4.2|again a more systems systems piece but
3666.96|4.76|it's fascinating how low you can
3668.72|5.44|actually get on your how how how how how
3671.72|3.56|low you can uh how few bits you can
3674.16|2.959|actually use and still get something
3675.28|3.48|useful out we already went from the
3677.119|4.321|original Transformer was was train on
3678.76|4.839|32bit Precision then we went to B FL 16
3681.44|4.76|and now there's good signs that inate
3683.599|4.2|and fp8 would work and I think there's
3686.2|3.2|useful work to be done there again going
3687.799|4.121|back to the same you know this this
3689.4|4.439|argument about if if if you're actually
3691.92|4.119|if you're if the if you're Vector if
3693.839|3.361|you're using fewer bits to represent a
3696.039|3.601|number you're actually transmitting
3697.2|4.119|fewer bits to the to from hbm so
3699.64|3.6|actually you can you can get faster you
3701.319|4.72|utilize the you can utilize your your
3703.24|5.839|Matrix multipliers much more effectively
3706.039|5.481|um that that was it so it's many topics
3709.079|4.361|but hopefully covered something fun
3711.52|4.92|thank
3713.44|3.0|you
3719.76|6.799|yeah could you talk about what working
3721.52|7.839|on now and yeah yeah so um so U I'm a
3726.559|5.881|co-founder at a startup with uh with my
3729.359|5.881|with with my transform coor Nikki and
3732.44|4.679|we're working on uh we're working on
3735.24|5.119|building uh building models that'll
3737.119|6.361|that'll ultimately uh automate workflow
3740.359|4.641|and we're starting with data so um it's
3743.48|2.92|very puzzling what happen in a company
3745.0|3.52|and companies are just basically just
3746.4|3.679|masses of dark knowledge right and and
3748.52|4.559|there's very few people that have that
3750.079|4.72|both the technical privilege and uh the
3753.079|3.641|understanding to ask questions like an
3754.799|3.721|typically analysts but the less you
3756.72|3.96|understand the less effective your
3758.52|4.559|company can be so how can you eventually
3760.68|4.399|help anyone become an an effective
3763.079|3.801|analyst in some sense right so help them
3765.079|3.841|ask the right question help them figure
3766.88|3.84|out eventually they wise which then
3768.92|3.32|requires some kind of counterfactual
3770.72|3.359|reasoning that's fairly complicated but
3772.24|3.24|start with start with data since it's so
3774.079|4.24|important and and companies are
3775.48|4.04|essentially drowning in it and then then
3778.319|3.441|can be spread out from there and then
3779.52|4.559|try to automate other workflows in the
3781.76|4.92|in press but we believe that some of the
3784.079|6.0|like the early signs that receive and
3786.68|4.679|what and our position is that um I I
3790.079|4.2|believe that this is going to require
3791.359|4.601|full stack approach so not just uh
3794.279|3.601|building the building the model because
3795.96|3.8|you can then control what feedback you
3797.88|4.0|give and so if you have a gap in the
3799.76|3.48|model you ask for that you kind of you
3801.88|3.56|aspire to get that feedback so then you
3803.24|3.76|can improve the model that's that's what
3805.44|4.119|that's what we're doing
3807.0|4.92|yeah please talk talk to
3809.559|4.361|us yeah I'm surprised to hear that
3811.92|5.159|you're fairly bullish about tools in the
3813.92|4.0|end like third party things we talked
3817.079|2.441|about in the beginning that your
3817.92|3.399|motivation was Transformers enabled us
3819.52|4.839|to get rid of pipelines but I feel
3821.319|4.641|likees again so I'm surprised can you
3824.359|5.96|talk about
3825.96|5.8|that right right so so so I mean so
3830.319|2.76|until we get to the point of where it's
3831.76|2.559|like you know where Turtles all the way
3833.079|3.72|down it's like Transformers all the way
3834.319|4.841|way down no I I don't I think that tool
3836.799|4.201|just allows you to inter so it's kind of
3839.16|4.679|like how do you interface with a machine
3841.0|4.96|that can really like that can think
3843.839|3.601|right yeah you have to build some kind
3845.96|2.839|of interface and if you build a useful
3847.44|3.119|functionality you want the machine to be
3848.799|4.401|able to take your functionality and and
3850.559|5.201|do General useful things with it right I
3853.2|4.48|think that using tools is just a way of
3855.76|3.559|leveraging leveraging things that people
3857.68|3.679|have built and software out there
3859.319|5.401|certain tools will probably get absorbed
3861.359|5.68|in the model right some others won't and
3864.72|4.839|and that still gives us the ability to
3867.039|5.721|like yeah it still gives us the ability
3869.559|4.72|to to like and certain things that
3872.76|4.519|Transformers shouldn't even do sorry I
3874.279|5.28|mean like like you don't want to spend a
3877.279|3.56|billion flops per position to calculate
3879.559|3.321|two numbers right you don't want to
3880.839|3.801|spend more flops by to do an operation
3882.88|3.479|that required like one billion to the
3884.64|3.399|flops right so there's certain things
3886.359|3.48|that the model should not do it should
3888.039|4.28|use external it should use external
3889.839|4.72|tools and uh the certain things that the
3892.319|3.96|the certain certain certain kind of
3894.559|3.76|thinking that the model should do so
3896.279|3.361|even from a capability perspective
3898.319|3.201|there's an important question of what
3899.64|3.639|all capability should be in this neural
3901.52|3.4|network right and but then also being
3903.279|2.76|able to utilize the work that other
3904.92|2.879|others have done software that other
3906.039|5.201|people have
3907.799|5.641|yeah you talks more about why like the
3911.24|5.92|original approach of you know decoding
3913.44|5.879|parall andely refining it yeah something
3917.16|3.56|why that didn't work and what yeah so
3919.319|3.921|sometimes if you know exactly why things
3920.72|4.319|work maybe you can make it work but um
3923.24|3.879|it ended up being so you're able to do
3925.039|4.24|silly things like randomly sort which
3927.119|5.281|means that somebody walks up to you with
3929.279|4.921|the uh sequence and you know you can I
3932.4|4.08|mean you can break two modes like you
3934.2|4.8|can say ascending or descending kind so
3936.48|5.0|or how do how do I say this so typically
3939.0|4.48|when you decode right imagine that uh
3941.48|4.119|you when you when you give a prompt you
3943.48|5.119|have many possible completions right and
3945.599|5.561|each time you make a choice you you you
3948.599|3.801|you you you narrow that space and each
3951.16|3.8|time another choice you narrow that
3952.4|5.32|space right so and and and you have a
3954.96|4.68|very and you've learned to narrow the
3957.72|4.92|the the set of all possible in some
3959.64|4.56|sense paths in in a in a way the model
3962.64|2.84|doesn't have to decide what's the order
3964.2|3.32|in which you have to do it right when
3965.48|3.92|you're kind of when you're doing this
3967.52|4.48|less or non autor regressive generation
3969.4|4.84|you have to do both right and doing
3972.0|5.119|learning both simultaneously is hard it
3974.24|5.52|end I mean but eventually I think that
3977.119|5.281|if for a
3979.76|5.4|particular I think this is probably true
3982.4|5.32|right if if an Oracle walked up to me
3985.16|4.04|and said this is the order in which all
3987.72|2.559|these sentences should be generated
3989.2|2.359|first you should generate these three
3990.279|2.8|words then you should generate these
3991.559|3.24|other two than these other two if
3993.079|3.161|somebody walked up you and gave you this
3994.799|2.961|Oracle ordering for all of human
3996.24|2.72|language I think we would have a much
3997.76|3.12|better chance and you could actually get
3998.96|3.639|this less not autoaggressive generation
4000.88|5.0|at least working what were the two
4002.599|6.081|things you said so one was uh so one so
4005.88|4.28|one thing was basically the ordering
4008.68|3.32|itself and I think it kind of has to do
4010.16|3.84|that because the ordering helps you then
4012.0|3.48|lock down the modes it NS down what
4014.0|3.68|you're going to generate next so
4015.48|4.16|ultimately I think it does boil down to
4017.68|3.879|what's the right not autor regressive
4019.64|3.6|ordering and that could be either you're
4021.559|3.0|still generating one word at a time but
4023.24|2.96|not Auto aggressively or you're
4024.559|3.48|generating a few and then based on that
4026.2|3.24|you're generating the other few so like
4028.039|3.56|the words that so the words that you can
4029.44|3.879|generate a once should be conditionally
4031.599|3.081|independent of each other right like
4033.319|3.601|what you generated so far should have
4034.68|4.159|completely explained them and then what
4036.92|3.48|you generate after should again be they
4038.839|2.921|should be they should be condition
4040.4|3.679|independent right so how do you learn
4041.76|3.519|these condition independences yeah and
4044.079|2.641|if somebody walked up me and gave them
4045.279|2.8|to me I think we probably learn they
4046.72|3.48|probably learned them
4048.079|6.321|yeah
4050.2|4.2|uh question it's
4055.039|3.24|more like
4060.48|5.839|recently more
4062.96|6.119|of and I think more of his thinking is
4066.319|5.161|that only like scaring small spot
4069.079|4.601|doesn't help them to actually learn like
4071.48|3.119|what how the real world actually work
4073.68|4.0|and
4074.599|6.44|have a good idea of like trth and yeah
4077.68|4.76|and real world General yeah do you agree
4081.039|5.32|with him do
4082.44|9.08|you areound
4086.359|7.561|this um so yeah I think it's interesting
4091.52|5.56|like how how you can learn a world model
4093.92|4.919|with just language right um so I mean
4097.08|3.56|some of these models are not exactly
4098.839|3.36|being learned that way you're doing rlf
4100.64|3.36|you're giving some feedback so which
4102.199|5.201|means there's some you're you're you're
4104.0|5.159|applying some uh they are modifying
4107.4|4.959|themselves to to some preference right
4109.159|5.04|so there's so it's not just just a pure
4112.359|4.161|language model but it's interesting so
4114.199|5.12|you've SE some of the workl robotics is
4116.52|4.239|now potentially starting to flourish
4119.319|4.4|because they're able to use these large
4120.759|4.761|models as planners right and so I I
4123.719|3.401|think that it's it's it's surprising how
4125.52|3.279|much of the world how much information
4127.12|2.96|about the world that they carry and if I
4128.799|2.801|understand is that is that right that
4130.08|3.48|the say canw work basically use the
4131.6|3.88|language model now as a planner yeah
4133.56|3.96|right and then they left the rest of it
4135.48|4.44|to just the standard perception and and
4137.52|4.639|and and and and the classical pass you
4139.92|5.319|soling in robotics so that's I mean that
4142.159|5.361|that's now while it's Jan is probably
4145.239|4.241|still right but the usefulness of it is
4147.52|4.92|evident in something that needs World
4149.48|5.679|Knowledge right so I think you can do a
4152.44|5.719|lot with what you have um I
4155.159|6.761|mean
4158.159|6.321|uh they probably yeah I mean it's we
4161.92|5.319|still haven't quite EXP extracted all
4164.48|4.52|these out of these models what and and
4167.239|5.56|it might be right simultanous but there
4169.0|3.799|still a lot more to be
4174.08|5.56|yeah um so I'm similar to the previous
4177.52|5.04|question and you're also talking about
4179.64|5.32|like imers right um I'm just curious to
4182.56|5.199|know like like what your thoughts are
4184.96|5.48|more on like generalizability and imers
4187.759|5.201|especially in the like I know there was
4190.44|5.48|like a paper from Deep mind about like
4192.96|5.16|the yeah I think yeah like they can't
4195.92|4.239|really generalize outside of like what
4198.12|3.44|they' trained on like especially because
4200.159|3.121|these large models now that they're just
4201.56|3.48|trained on everything like is there
4203.28|3.8|truly anything left that's out of
4205.04|4.639|distribution that you really sort of
4207.08|4.8|Benchmark it on so I I have been caught
4209.679|3.761|saying that if I had all my test and my
4211.88|4.6|training i' would make a billion dollars
4213.44|7.04|yeah so I don't have a problem with with
4216.48|5.719|it so but I still think so okay so so
4220.48|4.6|correct me if I'm wrong but the general
4222.199|6.281|argument is that uh these models have
4225.08|6.04|learned such a vast set of distributions
4228.48|5.88|and phenomena that typically when you
4231.12|5.76|interrogate them they're often very you
4234.36|4.16|know very cleverly blending or bringing
4236.88|5.92|bringing information from what they've
4238.52|6.159|learned right um it it might yes and and
4242.8|3.32|then they have these algorithmic tasks
4244.679|3.841|where they where the models St able to
4246.12|5.36|generalize right so I'll focus on the
4248.52|4.76|the I'll focus on the on the former I
4251.48|2.8|think that that's an incredibly useful
4253.28|3.879|property
4254.28|4.72|it might be that so I think maybe the
4257.159|4.241|failing is that we actually don't quite
4259.0|4.32|understand how much we could how much is
4261.4|4.279|even represented in text and second how
4263.32|3.8|much how much how far we could go if we
4265.679|4.761|were able to blend information from
4267.12|5.68|different from different uh like
4270.44|5.44|certainly being able to write about the
4272.8|5.16|Stanford this lecture in the in the
4275.88|4.12|rhyme meter and words of Cher is not
4277.96|4.44|possible because nobody did it right but
4280.0|4.84|I think that you could do it right now
4282.4|4.759|is that blending from what you already
4284.84|4.399|have if so that's that's a that means
4287.159|5.761|you can that's that's an incredible
4289.239|6.48|that's an incredible skill right um
4292.92|4.799|yeah I haven't read it it's very recent
4295.719|4.081|but I I believe the work I think you can
4297.719|4.0|show that these models generaliz but I
4299.8|4.8|think there's a surprising amount of
4301.719|5.361|like uh new seemingly new things you
4304.6|4.48|could do by just blending information
4307.08|4.28|from what you've already learned on the
4309.08|4.599|inter and and yeah largely probably has
4311.36|6.56|to do that there's so much other yeah
4313.679|6.56|yeah um so you question yeah I had
4317.92|2.319|questions
4320.4|7.36|ago I think I had an ordering in mind
4322.719|8.201|and then it came back yeah sorry um but
4327.76|5.72|uh give me a
4330.92|5.04|second I was wondering who might have
4333.48|6.679|inside connecting different agents
4335.96|4.199|Transformers or what not you know you're
4340.28|5.0|a Transformer is essentially like a
4342.92|4.68|great connection neurons in specific way
4345.28|4.359|and it's awesome right like so you you
4347.6|5.32|figured out the best way to connect them
4349.639|5.08|so far AG no the neurons oh the neurons
4352.92|4.08|you're talking about do Som to do in the
4354.719|4.0|brain no like the neurons in the
4357.0|4.679|Transformer right like the transformer
4358.719|4.681|is the the the way you connect you know
4361.679|3.281|different pieces together and then when
4363.4|4.2|you connect everything together that
4364.96|4.279|works form I was wondering if you have
4367.6|3.76|some insights into the building system
4369.239|6.201|that connect and you know perform the
4371.36|4.08|best together yeah
4376.04|2.48|is not goingon to like this I like to
4376.96|3.679|make this joke the best agents are
4378.52|3.76|actually because they can communicate
4380.639|3.801|with each other they can update
4382.28|5.56|themselves really really well but what
4384.44|5.48|the other agents are doing um what is
4387.84|4.04|the fundamental Problem by making what
4389.92|5.96|is the fundamental issue in making a
4391.88|5.359|bunch of uh bunch of bunch of I'm trying
4395.88|2.759|to understand what are the fundamental
4397.239|2.881|problems and trying to make a bunch of
4398.639|5.161|systems work together that's what you're
4400.12|6.28|asking one is goal DEC composition right
4403.8|3.96|and one is the second big one is
4406.4|3.88|coordination and third one is
4407.76|4.16|verification like if you solved a
4410.28|3.48|successful decomposition of the goals
4411.92|3.799|based on what this what your estimate of
4413.76|4.439|the skills of these agents are if you
4415.719|3.92|able to what they've done and if you if
4418.199|3.281|you're able to coordinate then I think
4419.639|3.6|you could make a lot of progress right
4421.48|3.36|so while I didn't answer your question I
4423.239|4.041|don't know in general how much we've how
4424.84|4.16|much progress we've made in this in all
4427.28|4.439|in these three areas but does somebody
4429.0|2.719|have any input
4432.36|5.48|here
4433.96|8.36|par and you have something that's
4437.84|4.48|man each the job
4448.44|6.6|andess and everything
4452.04|6.72|andig
4455.04|7.04|almost everything and time and
4458.76|6.52|it's like how you break how
4462.08|3.2|you like
4466.719|5.361|yeah problems are
4468.76|3.32|probably maybe to
4483.6|4.92|some
4485.44|7.48|but human
4488.52|7.44|modity like phenomena like you need some
4492.92|5.64|special to that happen yeah and by
4495.96|5.92|modularity here you mean that is it is
4498.56|5.24|it modularity in that they they have
4501.88|3.48|this this region has this this
4503.8|3.56|responsibility or even is the
4505.36|3.76|composition different the construction
4507.36|3.839|the the construction different what do
4509.12|4.0|you mean by that because you one you
4511.199|3.48|could have both You could argue that
4513.12|3.599|there's no the responsibility is
4514.679|3.721|diffused across the model mixtures of
4516.719|3.401|experts tries to go in the opposite
4518.4|2.92|direction which I but I I should have
4520.12|3.4|probably mentioned that's another really
4521.32|3.24|exciting Direction which is which it
4523.52|3.76|happened to the three4 years and it's
4524.56|4.36|going to stti right I totally missed it
4527.28|3.56|uh that kinds of tries to get the
4528.92|4.319|specialization right so maybe that is
4530.84|5.0|some kind of modularity right learn
4533.239|4.201|modularity um the rest is the rest of
4535.84|3.96|responsibility performing the task is
4537.44|4.6|likely distributed but if now you're
4539.8|3.879|going to these subsystems themselves of
4542.04|4.0|different composition then you kind of
4543.679|5.081|get back to like uh and and I know that
4546.04|4.44|the like this was a goal with the
4548.76|3.68|pathways project at Google where you
4550.48|4.199|wanted to have these really modular
4552.44|3.12|systems communic with each other and I
4554.679|3.201|think
4555.56|4.92|there's it's just taken so long to get
4557.88|3.68|gradiant descent like descent in fact
4560.48|3.44|sometimes I think that Building
4561.56|5.8|architecture to sort of gr descent and
4563.92|4.96|and and uh feel like it's if you can if
4567.36|4.4|you can learn with gr descent it's very
4568.88|4.4|useful uh if maybe it's actually
4571.76|4.12|possible to make these modular systems
4573.28|5.879|work we have some of it through experts
4575.88|5.839|and uh I'd imagine some of these
4579.159|5.201|problems that be discussed does that
4581.719|4.361|does that make sense
4584.36|4.04|sorry circling back to now whatever
4586.08|4.159|seven questions ago you mentioned that
4588.4|4.88|the problem with deting all at once was
4590.239|4.801|one of the things that Cod gener has
4593.28|4.359|this assumption that the outputs areally
4595.04|4.679|independent but aren't they in the sense
4597.639|4.281|that if you have a l space if you're
4599.719|3.841|given the lightning space as your prior
4601.92|2.88|then your posterior outputs should be
4603.56|3.88|conditionally independent each other
4604.8|5.32|right uh so great point and and where do
4607.44|5.08|you get the from well from the from from
4610.12|5.039|the encoder what I the beginning right
4612.52|4.96|this might be like quite a few W to
4615.159|5.52|translate something right yeah there's a
4617.48|6.48|multiple so if there's only one mode
4620.679|5.48|then yeah it's prob right but if there's
4623.96|3.8|like multiple ways of uh well I show
4626.159|3.921|this two things how much does the Laten
4627.76|4.12|space actually carry by an important to
4630.08|4.96|ask right how much does it actually
4631.88|4.68|carry because it's not just late one L
4635.04|3.0|Vector that you're transmitting every
4636.56|3.2|you're you're doing attention again and
4638.04|5.04|again but
4639.76|7.64|but we took this approach where we did
4643.08|6.96|precisely this we we Auto agressively
4647.4|4.6|generated uh we Auto agressively
4650.04|5.52|generated tokens in a new vocabulary
4652.0|5.52|using vectro quantization so the the
4655.56|4.88|conditional dependence was modeled in a
4657.52|5.28|latent space where we discretized using
4660.44|4.56|elector quantization and then based on
4662.8|3.52|that we we generated everything
4665.0|5.28|conditioning everything and that did
4666.32|6.16|work but uh again uh so so that did work
4670.28|5.28|uh in Translation uh the issue there
4672.48|6.36|were some funky issues there where it
4675.56|6.36|the latent the latent uh sequence of
4678.84|4.44|latent vectors were only effective not
4681.92|3.12|effective if you learn directly on the
4683.28|3.48|original data you had to do something
4685.04|3.44|like distillation because distillation
4686.76|3.84|itself throws away potentially some of
4688.48|4.36|the modes so generally lower entry data
4690.6|4.559|was we were we had to train on it the
4692.84|3.879|second piece was for practical systems
4695.159|3.761|you have to make the whole thing really
4696.719|4.52|really fast but this is a good this was
4698.92|5.12|a good research exercise but ultimately
4701.239|4.721|it didn't have the right practic
4704.04|3.92|because speculative decoding practically
4705.96|4.4|with what we have right
4707.96|3.92|work yeah yeah exactly yeah but you're
4710.36|3.24|right I think if you can generate if you
4711.88|4.04|can generate sufficiently if you can
4713.6|4.72|generate a good sufficient latency then
4715.92|3.319|yes you're right we can assume that that
4718.32|2.96|makes everything conditionally
4719.239|4.321|independent then yeah and we managed to
4721.28|5.84|do that a bit managed to do that but it
4723.56|7.36|wasn't quite good
4727.12|3.8|enough I guess this is the last
4731.92|3.759|question person
4739.6|7.52|question wow that's too personal yeah
4743.44|5.36|very personal uh and and uh I have I
4747.12|4.64|have friends there they're all really
4748.8|5.8|great they're doing incredible things
4751.76|7.0|um I think that there's we'll be
4754.6|7.079|surprised how much there is to do and if
4758.76|6.36|so first the motivation right there is
4761.679|7.121|an entire new well there's an entire new
4765.12|5.119|uh bucket of or like a like new trunch
4768.8|3.399|of capabilities that you will get with
4770.239|3.44|human computer interaction so you can
4772.199|3.201|make a product people use it they give
4773.679|4.321|you feedback models get smarter and this
4775.4|5.16|and this this close this clo loop system
4778.0|5.159|can can really bring in really Advanced
4780.56|7.44|models and and and bring value right
4783.159|7.121|that's one um second um yeah I think
4788.0|4.28|it's helpful to have some the Deep
4790.28|3.879|learning benefited so much from A
4792.28|4.56|diversity ideas and people producing
4794.159|5.681|people people pursuing important
4796.84|5.68|directions I would say the same about uh
4799.84|4.44|I would say the same about uh building I
4802.52|5.44|mean products as well or building you
4804.28|5.439|know building uh companies that are
4807.96|4.279|building new kinds of products with
4809.719|4.081|these models right so I would say that
4812.239|4.601|we have there's there's so much surface
4813.8|5.16|area that uh we could we could we could
4816.84|5.68|do something incredible so that's second
4818.96|5.0|is third you know yeah want to maybe
4822.52|5.32|that's that's the more person that I
4823.96|3.88|just want to do think
4836.8|3.0|yeah