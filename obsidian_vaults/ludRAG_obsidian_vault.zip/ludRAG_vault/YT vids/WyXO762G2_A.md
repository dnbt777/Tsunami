start_time|end_time|text
0.84|5.14| All right, before we dive deeper into VG 16, no pun intended
5.98|3.92| here, and resonate, let me just briefly recap one or two of the
9.9|4.14| slides I showed you last week. So here was a paper from 2016.
14.28|3.54| That was highlighting some common architectures back in the
17.82|2.94| day, that's already five years ago. But yeah, it highlights
20.76|5.0| really how fast this field is developing. So Alex net was
25.76|5.92| developed in 2012. We talked about it last last lecture. And
31.68|2.48| now we can see there are many, many more. And this is also not
34.16|4.44| a comprehensive overview. These are only a few of the common
38.6|5.2| selected ones. Good news is that, yeah, it is not growing
43.8|4.0| exponentially, I think. So many people still work with VGG and
47.8|4.08| the resident resident in 2021, because they're really good on
51.88|4.52| basic or base architectures as a backbone for your methods on
56.4|3.2| top of it. However, there are also some additional
59.6|3.68| architectures not listed here that are popular nowadays, for
63.28|2.72| instance. So also, I should say these are only for
66.0|3.48| classification, we have also another set of architectures for
69.48|4.08| different tasks. But yeah, other common ones are top of my head,
73.56|4.56| maybe mobile net, wide residual networks, efficient and
78.12|4.68| efficient at this year, dense net, highway networks. But yeah,
83.0|3.56| anyway, so these are still a good overview. If you want to
86.56|3.68| get started with experimenting with different architectures, I
90.24|4.6| would recommend considering those two. So for instance, also
94.84|3.84| a good takeaway from this one here is that it's not only about
98.68|3.74| the number of parameters. So you can see VGG 16 is relatively
102.42|2.7| large, but it doesn't perform as well, for instance, compared to
105.12|4.4| inception networks, or here on the residual networks. So here
109.52|3.84| these add certain tricks. For instance, we will talk about
113.84|2.64| residual networks, they have a residual connection, which can
116.48|4.4| help with making or having more layers without having such a
120.88|3.68| problem from vanishing gradients. But then yeah, you
124.56|4.32| also have inception, which has interesting way of combining
129.36|3.36| different convolutions or conclusions of different sizes.
132.72|3.72| I originally plan to talk about it more. But yeah, due to the
136.44|2.64| interest of time, we will be skipping inception. But yeah,
139.08|2.52| there are also interesting tricks like combining different
141.6|3.84| conversion sizes into one layer, and then also having auxiliary
145.44|3.84| losses, like having intermediate losses in the network. So these
149.28|3.12| kind of tricks can also help improving the architecture
152.4|3.96| because VGG 16 is essentially just a convolutional network
156.36|5.28| with 16 layers, which are pretty large, but it's not all about
161.64|3.64| all about that. It's also about certain tricks. For example,
165.28|5.72| here on ResNet 152 has 152 layers, it's not possible to
171.0|4.52| have just 152 layers in a regular VGG context, because
175.52|2.68| then we would have vanishing gradient problems. Recently,
178.2|4.48| there were some efforts, though, to also develop very deep
182.68|3.04| networks without residual connections. And there was also
185.72|5.04| interestingly, normalizer free ResNet, which also gets rid of
190.76|2.4| batch norm, for example. So there are still interesting
193.16|2.88| developments happening. But yeah, again, these are the
196.04|3.28| basic architectures. And in the next video, I will start by
199.32|22.08| discussing the VGG 16 architecture.