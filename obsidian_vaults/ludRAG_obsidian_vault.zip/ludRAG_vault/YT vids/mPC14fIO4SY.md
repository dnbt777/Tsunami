start_time|end_time|text
2.54|3.18| Yeah, hi, everyone. I hope you had a nice week. I just noticed
5.72|2.64| we already completed week four, which means Yeah, one fourth of
8.36|3.92| the semester is already over. Time is running so fast. I hope
12.28|2.84| you like the content on pytorch and the cloud computing
15.12|3.84| resources from last week. So in today's stuff in the news
18.96|2.96| section, I just wanted to give you a brief update again on
22.0|2.32| what's happening in the deep learning world. Also,
24.32|3.48| coincidentally, there were some interesting tools around pytorch.
27.8|4.02| And also some interesting news regarding cloud computing, and
31.82|3.48| its implications on the environment. And also, yeah,
35.3|4.08| maybe some not so nice applications of API of deep
39.38|3.96| learning regarding ethical AI and these types of things. So
43.34|3.32| yeah, there's a variety of news again this week. And yeah, let's
46.66|7.96| dive in and talk about it. Yeah, let's start with a fun library I
54.62|4.68| saw this week called free wire, freely wired neural networks. So
59.3|3.24| this is a pytorch extension library for creating optimized
62.58|4.12| freely wired neural networks to run on CUDA, the GPU essentially.
67.98|3.84| So you have seen already in the lecture, how a multi layer
71.82|4.12| perceptrons work fully connected layers. So where each unit in
75.98|4.08| one layer is connected to every unit in the following layer. And
80.06|2.8| we will discuss that also in more detail next week in the
82.86|3.88| course. But yeah, here, what's different is that we can
86.78|5.44| arbitrarily connect these nodes. For example, consider in this
92.26|3.76| drawing on the left hand side, consider this case of this unit.
96.42|5.36| Let's say this is the input layer. This is the first hidden
101.78|5.2| layer. And then we have the second hidden layer. So we have
107.02|3.48| this unit here, for example, that is only connected to one
110.5|3.92| other unit. In a typical fully connected context, what we would
114.42|3.48| see is we would see also a connection to this one year. But
117.94|2.84| here, here, it's more arbitrarily connected. Or you
120.78|3.84| can also see this input here is connected to this unit. And this
124.62|3.0| unit, as you would expect in a fully connected layer, but then
127.62|3.46| there's also a connection to a consequent layer. We will see
131.08|3.7| later, some flavors of that also in the context of convolution
134.78|2.84| networks and residual connections. It's also something
137.62|3.2| that is popular in transformers. But here, it's really more
140.82|3.32| arbitrary than in other architectures. So it's just a
144.14|3.96| tool for allowing you to create these types of architectures. I
148.1|2.72| thought it was like a cool thing. If you want to run some
150.82|3.12| crazy experiments, that's might might be something. Yeah,
153.98|4.08| interesting to look at. So where would this be useful? So for
158.06|4.62| example, one thing that came to mind is this paper exploring
162.68|3.58| randomly wired neural networks for image recognition. So that
166.26|3.8| is a paper I saw like two years ago, approximately. And here,
170.06|3.8| the researchers proposed a method for, you know, randomly
173.86|3.8| connecting neural networks on getting these random
177.66|3.0| connections, I think also involving convolution errors. So
180.66|4.0| in this way, and they used when I recall correctly, they used
185.06|3.4| evolutionary algorithms or genetic algorithms to learn
188.46|5.24| these by optimizing fitness function. And they found that
193.7|4.26| this architecture, this randomly wired one performs better, for
197.96|4.44| example, than existing one based on resonant. So resonant is
202.4|2.24| also something we will talk about in this course, the
204.64|5.62| resonant architecture achieved 77.1% accuracy on this data
210.26|6.18| set. It's image net. And this randomly wired one achieved a
216.44|3.12| higher accuracy, even though it seems arbitrary. So when I read
219.56|2.82| that paper, like two years ago, I thought really, that's maybe
222.38|3.72| the time when these hand designed convolution networks are
226.1|2.58| going out of fashion where people start using these
228.68|3.16| automatically wired ones. However, I must say, personally,
231.84|4.64| I haven't seen any randomly wired network since Yeah, since
236.48|3.36| I read this paper, actually. So maybe this is because it's hard
239.84|3.06| to implement. Also, it's also, I would say computationally more
242.9|4.58| intensive. And maybe there's also less logic behind. So for
247.52|3.24| regular CNN architecture, you can maybe make some arguments
250.76|2.88| why it's supposed to perform better with a randomly wired
253.64|2.84| one, it's maybe a little bit more like a black box, and
256.48|2.88| people don't like that. But yeah, again, with this tool, I
259.36|1.64| showed you in the previous slide, there might be an
261.0|3.0| opportunity to explore this further, because now it's maybe
264.0|7.64| easier to implement such randomly wired networks. Yeah,
271.64|3.76| also, this week, we got a new computer vision data set. So in
275.4|3.6| this new data set, the researchers compiled 1.5
279.0|6.0| million images from 565 classes. So what's novel or interesting
285.0|3.56| about this data set is that it is focused on object categories
288.6|2.96| that are important to humans, at least that's what the
291.56|3.96| researchers aimed for. Yeah, so this paper will be actually
295.52|4.68| published in three days. So it's today the 20th. And the paper is
300.2|4.72| already available on the website of a PNAS. If you want to take a
304.92|3.76| closer look at it. And also the researchers provide code
308.68|4.52| examples regarding pre pre trained convolutional networks
313.28|3.6| trained on this data set. And also how you can load this data
316.88|2.76| set. There are some other interesting aspects from this
319.64|3.52| data set, how the data set looks like the statistics, the basic
323.16|3.84| statistics, but then also how they collected this data set. So
327.0|2.4| I wanted to just briefly also walk through this because I
329.4|4.4| thought that was interesting. So here's an example of some of the
333.8|5.6| 565 classes, man, house, car, woman, phone, bed, so things that
339.4|5.32| are relevant to humans. And so here, they also looked at these
344.72|4.52| categories on for example, 60% of things or labels are
349.24|4.04| artificial, 40% natural. So for example, a car would be
353.28|4.08| artificial and a tree would be natural, and so forth. So they
357.36|4.88| have some interesting analysis here. Also, regarding the number
362.24|4.0| of images, note that the number of images is different for each
366.24|5.76| class. So it's not a balanced data set, it's imbalanced, which
372.0|2.36| makes certain things like the evaluation a bit more
374.36|3.0| challenging. So instead of, for example, using the regular
377.88|3.08| accuracy, something like the class balanced or balanced
380.96|3.44| accuracy might be something more worthwhile or not worthwhile,
384.4|3.84| but more reasonable to use here. So some students who took the
388.24|4.68| 451 class last semester, we talked about the balanced
392.92|2.68| accuracy, that would be maybe one measure that would be also
395.6|3.88| appropriate here. So and also notice that these images have
399.48|3.36| different aspect ratios and resolutions, which is also shown
402.84|2.56| here. So if you work with this data set, you also have to make
405.4|4.08| sure of course, that you find a common denominator for the input
409.48|3.44| sizes, if you work with certain architectures, which are
413.24|3.76| restricted to certain input sizes. But that being said,
417.0|3.0| let's skip to the more interesting part, how they
420.0|5.2| collect the data set. So what they did is they try to kind of
425.2|6.04| filter for labels that occur frequently in large text
431.32|5.72| corpuses. So it's like a proxy for saying how important class
437.04|4.44| or word is unknown. And they also had this concreteness
441.48|3.68| rating. So this was something quite interesting. So here they
445.16|6.24| employed data from human observers. So how that works is
451.4|4.52| that they asked people to rate on a scale from one to five, how
455.92|5.12| concrete a certain noun is. So in terms of how easily can you
461.04|5.24| visualize the concept. So as an example, for example, consider
466.48|6.64| on one end, strawberry. If I tell you the word strawberry, I
473.12|2.56| think you can easily visualize this. So it would have a very
475.68|5.48| high concreteness. But when I mentioned a noun like hope, for
481.16|3.0| example, which is a little bit less concrete. So here, it's
484.16|3.8| kind of harder to visualize how hope looks like as a as an
487.96|2.96| object. So in this way, it would have a very low concreteness
490.92|3.6| rating. So by using these types of ratings, they also filtered
494.52|6.72| for very concrete, very concrete things like items. And from that
501.24|4.8| they extracted then the top 3500 words based on frequency and
506.04|4.04| correctness, they had a certain index for calculating calculating
510.08|4.84| that. Um, yeah, and then they had each now describing basic
514.92|3.52| level category and excluding subordinate category. So making
518.44|4.16| sure it's not too hierarchical, like picking the common
522.8|5.28| denominator categories, and also merging synonyms, for example,
528.08|6.12| automobile and car into one word. And after they basically
534.24|4.6| extracted these class labels, they were interested in what
538.84|3.88| they then did is they downloaded corresponding images from image
542.72|5.2| net flicker and Bing. Then they also performed duplicate removal
547.92|2.64| to make sure there are no duplicates. So here they used
550.6|4.32| principal component analysis. So they decomposed the images with
554.92|3.04| principal component analysis. And then when I remember
557.96|2.56| correctly, what they did is, yeah, they looked at the factor
560.52|4.08| loadings of the PCA, and then looked at the correlation
564.6|2.68| between these factor loadings. So I believe they did that in a
567.28|5.76| pairwise fashion to filter out then duplicates. Also, what they
573.04|3.64| did is here, they manually excluded misclassifications from
577.24|3.4| from all categories. Here, they don't say anything specific.
580.68|3.56| Here, they say something with a 4% error rate. And in the
584.24|4.24| paper, they say basically that they sampled 100 images
588.52|4.16| randomly from each class. And then they, as a human looked at
592.88|3.8| how many of these images are incorrectly labeled. So if you
596.68|2.28| look at them, and you see, okay, this label label doesn't make
598.96|4.88| sense. If the rate was more than 4%, like for more than four
603.84|3.48| images out of the 100, then they looked at all the images from
607.32|4.76| this category and cleaned that out. And otherwise, I think
612.08|3.88| I think they left it as is. So you can see or can think of it
615.96|4.36| as in the worst case scenario, you can only have a classifier
620.32|5.52| that is as good as 96% accuracy, considering there are up to 4%
626.6|2.56| mislabeled images in this data set, but it's still a reasonable
629.16|4.32| good. And then they merge these images from the different
633.48|3.44| databases, removed the duplicates again. So now
637.0|4.84| checking for duplicates from image net versus the flicker and
641.84|6.12| Bing images. Then they pruned the data set removing the
647.96|4.8| images or some of the images so that these labels or sorry, that
652.76|5.48| the examples are approximately between 705,000 per class. And
658.24|4.2| then they obtained this final data set. So 94% of the images
662.44|3.36| are actually from image net, which is a big number. 5% are
665.8|3.6| only from Bing and 1% is only from flicker. I actually don't
669.4|3.2| recall exactly how image net images were collected. I think
672.6|3.4| they were collected from Google. But there might be also just
676.0|2.32| some overlap between image net and Bing. And that's why there's
678.32|2.84| such a high number of image net images compared to the other
681.16|3.88| images. But yeah, exactly why there's such a high image net
685.04|2.76| percentage, I don't know. But yeah, so it's an interesting
687.8|4.16| data set. It's yeah, just another cool data set that can
691.96|8.28| be used for testing your models. Yeah, moving from large scale
700.28|4.64| image data sets to large scale models. So there's also a common
705.04|3.72| or popular discussion nowadays, that these AI or deep learning
708.76|4.6| models become more and more expensive to train. So here was
713.36|2.96| an article called the billion dollar AI problem that just
716.32|4.04| keeps scaling. Yeah, luckily, we haven't reached the point where
720.36|4.4| we have model training costs $1 billion. But it can easily end
724.76|2.92| up costing multiple million dollars even nowadays when you
727.68|3.72| consider these big models. So for example, here's a chart
731.44|4.88| from the Megatron model from Nvidia. So here, what they did
736.32|5.08| is they trained on or they had a system called Celine. And this
741.4|4.84| consisted of 280 dg x a 100 systems, where each of these
746.24|3.52| systems, if you would buy them would cost $200,000. And then if
749.76|3.96| you consider, let's say 15%, on top of it for networking costs,
753.72|4.32| like connecting everything, and then also 20% for storing this,
758.82|3.06| yeah, this would be easily or if you would consider the list
761.88|3.48| price, it would easily end up being like $75 million just to
765.36|3.56| buy the system. And also in this article, they did a calculation,
769.36|3.68| like how expensive would it be to run this model, if you would
773.04|6.1| rent the hardware on AWS, so the Amazon server or service would
779.14|3.24| also easily be like around 80 million, if you just rent this
782.38|3.74| computational resource for three years. So in this way, I'm also
786.12|2.92| I should say electricity is not included, it's becoming more and
789.04|2.72| more expensive to train models. So for this model, they really
791.76|6.82| use like this huge system, where they had around 3000 GPUs. So
798.6|4.24| 3000 GPUs and the model had around 200 billion parameters.
803.04|2.56| So things become more and more expensive, which can be a
805.6|4.28| problem. So also regarding your parallelization, there are two
809.88|4.0| techniques. So also, it's kind of computation and interesting
813.88|3.96| problem. One is a data parallelism where you split up
817.88|3.4| the batch. So you make the batch larger and larger and larger,
821.28|3.6| and then you split it up onto multiple GPUs where each GPU
825.0|4.56| receives a fraction of that original mini batch. And then
829.6|4.24| each of the GPUs computes the gradient and then you combine
833.84|2.88| the gradients by averaging over these gradients to update the
836.72|3.84| models. But there is also a limit for you're doing that as
840.6|4.04| like limiting, diminishing returns, as you would say, if
844.64|3.72| you have higher and higher data parallelism. So also, newer
848.36|3.18| methods, consider tensor parallelism, where you can
851.54|4.66| efficiently compute, let's say, matrix multiplications across
856.2|3.92| different GPUs. That can also be a little bit tricky, though,
860.12|3.16| because you have to consider the connection between the GPUs, you
863.28|4.2| have to make sure they are connected with fast connections
867.48|3.04| like infinity band and these types of things. So it's
870.52|3.68| actually not a trivial problem. So if you have more GPUs, it's
874.2|4.8| not necessarily saying that it's easy to parallelize. So it's
879.0|2.44| just an interesting research problem. But yeah, one problem
881.44|2.8| with that is really environmental friendliness
884.24|0.48| also.
887.68|4.0| Yes, speaking of environmental friendliness, a recent study
891.68|3.76| showed that federated learning can lead to reduced carbon
895.44|3.32| emissions. So what is federated learning, federated learning
898.76|4.24| means essentially computing things on multiple devices, and
903.0|3.36| then gathering the results from these devices. For example,
906.36|4.52| these could be cell phones or different data centers. So, for
910.88|2.94| example, you can think of if you I'm not sure if you remember
913.82|3.78| this, when I was a kid, there was something called folding at
917.6|4.64| home for PlayStation, and people could sign up for the service.
922.24|4.24| And then if you had idle, idle cycles on your PlayStation,
926.48|4.68| these were used by, let's say some research center to help
931.16|4.24| with protein folding. Or another example would be our HTC condor
935.44|4.24| on campus, where we have where we can use different computers
939.68|2.72| like desktops in different offices if they are idle, which
942.4|2.96| is actually pretty cool. And they found if you do that, it
945.36|4.12| can lead to lower, let's say carbon emissions. And yeah,
949.48|4.84| likely, this is due because of the heating because if you have
954.64|2.2| computers in different locations, and they only used a
956.84|4.0| little bit, you may not need any extra heating, sorry, cooling
960.84|3.3| for preventing the heat, exposure or overheating of the
964.14|3.02| device, compared to let's say, a big data center where you have
967.16|5.84| to pump in constantly like lots of energy to keep it cool. And
973.0|2.96| yeah, also just the numbers were just impressive. I mean, these
975.96|3.04| data centers nowadays, they use 200 terawatt hours per year,
979.24|3.24| compared to our average US home, which only uses on 10,000
982.6|3.68| kilowatts per hour. And I just looked up what a terawatt is a
986.28|2.68| terawatt is actually, I wasn't actually sure I was not sure if
988.96|3.56| it's 1 million, it's actually 1 billion kilowatts. It's like a
992.52|2.84| huge amount of energy they use. So if this federated learning
995.36|3.56| can help, why not? However, the researchers also noted that it
998.96|3.16| there's like a little caveat. So it's actually not quite clear
1002.12|3.96| because federated learning can also be less efficient. For
1006.08|3.72| example, if you consider prolonged training times, due to
1009.8|3.44| distributed databases, so if you want to train a model using
1013.24|2.32| multiple devices, but you have your database sitting in a
1015.6|2.76| location that has to be accessed, well, that will
1018.36|4.92| properly make training longer. So you have, you have to keep
1023.28|4.06| your device running for longer time. But then also, you will
1027.34|3.42| have eventually then some more data data transfer via Wi Fi,
1030.76|3.6| which also takes energy. And then also, you have to consider
1034.36|4.3| that these devices may be less efficient, like using the same
1038.66|2.1| energy, but being less efficient. One example would be,
1040.76|4.14| for example, the new arm, what is it an M1 chip, the arm chips
1044.9|4.18| in the Mac box, they are they have the same speed as the top
1049.36|3.8| and Intel CPUs. However, they are more efficient. So in that
1053.16|2.84| way, you have to also consider certain devices are not as
1056.0|2.44| efficient. So if you use federated learning, this could
1058.44|3.84| also be maybe, um, yeah, less efficient. But I think it's
1062.28|2.52| still interesting that people started looking at that, because
1064.8|3.72| yeah, I think we also have to be aware of the environment and be
1068.88|4.48| resourceful when we do deep learning. And you're related to
1073.36|3.76| that. I also saw there's another new startup, I think it's
1077.12|3.84| pronounced new reality, but I'm not exactly sure. So also one
1080.96|3.64| trend is really that people work on making chips for deep
1084.6|2.56| learning more efficient. So this would be yet another company
1087.16|4.84| that focuses on deep learning chips, or instead of GPUs, like
1092.0|3.92| having specialized chips for deep learning. And this article,
1095.92|3.76| they said, basically, the chip can perform inference with 15
1099.68|3.8| times higher performance per dollar than the competition. Now
1103.48|3.72| that they don't say that the chip is faster than GPUs, really
1107.2|3.92| here, the focus is on the performance per dollar. But it's
1111.12|3.2| not a bad thing. I mean, maybe this chip overall is slower, but
1114.32|3.72| you can see 15 times higher performance per dollar. So per
1118.04|3.16| dollar, it's not clear whether this means like manufacturing
1121.2|4.08| cost or also usage cost in terms of electricity, but I bet it's a
1125.28|4.0| mix of both. So it's probably a chip that is smaller, less
1129.28|3.36| powerful than a GPU, for example, but probably more
1132.68|5.52| energy efficient, but we'll see. Yeah, so here I have some news,
1138.2|3.2| which is I think, yeah, not such a good use of AI or deep
1141.4|3.92| learning. I find this always questionable, like these types
1145.32|2.56| of applications, but I think it's still important to talk
1147.88|4.84| about it. So here, this is about a system trained to rate your
1152.72|3.86| applicants during job interviews. I think also, when
1156.58|3.74| people develop these systems, so the aim is really to make things
1160.32|3.24| more objective. Like if you think of it as a human, you have
1163.56|2.88| probably some biases towards certain candidates. And if you
1166.44|4.24| have an AI system, you may be hoping that this is less, let's
1170.68|3.08| say, it's more objective, less subjective, and probably also
1173.76|3.82| scales better. So you can have more applicants. But yeah, so I
1177.58|2.94| think, I'm not sure. But I think these are all developed in good
1180.52|3.6| faith, but they can also be very problematic. So here was a
1184.52|4.08| questionable use of AI for job applications. I also recommend
1188.6|2.4| you to read this full article. It was a very interesting
1191.0|4.64| analysis. It's a short article, but very, very well written. So
1195.64|4.8| um, yeah, essentially, here, the researchers developed an AI to
1200.44|6.84| rate job applicants. So they trained the AI on videos from
1207.28|2.88| more than 12,000 people from different ages, gender and
1210.16|5.04| ethnic backgrounds. And an additional 2500 people rated how
1215.2|2.56| they perceive them in terms of personality dimensions, and so
1217.76|3.88| forth. And I think it's not quite clear. But I think how
1221.64|2.96| this works is basically, they had people rating these job
1224.6|4.2| applicants, and then collected these scores, and then trained
1229.04|3.52| the AI on these scores. And that way, you can think of it, or
1232.56|3.52| maybe the model, yeah, just mimics what the humans are
1236.08|2.56| doing during the rating. So they had like these different
1238.64|3.6| rating terms, like openness, conscientiousness, extraversion,
1242.28|3.64| agreeable illness, and neuroticism. And these were like
1245.96|3.92| the different labels for the personal traits. Yeah, and then
1249.88|4.08| the researchers employed actors to do mock interviews, and
1253.96|3.44| interviews. So keeping everything constant, like speech
1257.44|3.24| and content of the text during the interview. And they also
1260.68|3.48| repeated that multiple times. So make sure that making sure that
1264.64|5.56| the results are stable. And then they, for example, varied
1270.4|4.24| different aspects. So here, for example, they are the actress
1274.64|3.24| was wearing glasses and comparing the results to not
1277.88|3.4| wearing glasses. And you can see in blue is the original without
1281.28|4.84| glasses. And then in yellow with glasses, and you can see that
1286.12|3.32| based on these ratings by the AI, that the scores for
1289.44|3.68| openness, consciousness, conscientiousness, extraversion,
1293.24|3.76| agreeable illness were less when the person was wearing glasses.
1297.24|2.0| So this is also one of the reasons why I'm not wearing
1299.24|2.16| glasses when I record my lectures. No, I'm just kidding.
1301.68|2.68| No, I think this is like a little problematic, because I
1304.36|3.72| think wearing glasses are not shouldn't influence any decision,
1308.08|3.28| right? So this is maybe something that is not going so
1311.36|4.12| well here with this AI, and even worse. So when the results were
1315.48|3.72| even more different, they had a person doing a mock interview
1319.2|3.28| with and without a bookshelf in the background, where everything
1322.48|4.48| else was constant. So and you can see that with a bookshelf,
1327.16|3.84| the scores improved a lot. So this is also a very questionable
1331.0|2.36| result by the AI. So there shouldn't be such a difference
1333.36|3.24| whether someone has a bookshelf in the background or not. And
1336.6|2.28| yeah, this is maybe also reason why I have a bookshelf in my
1338.88|2.8| background here. I'm just again kidding. But yeah, so this is
1341.68|2.8| again, it's actually a serious topic. I think this is something
1344.68|3.72| when you develop such systems, you should make sure that such
1348.4|3.72| problems don't occur, because I think this is incredibly, yeah,
1352.76|3.56| unfair, because really, if I mean, it really shouldn't have
1356.32|4.52| anything to do with your skills as an applicant, whether what
1360.84|2.88| type of background you have, and things like that. So yeah, this
1363.72|3.52| is some some very problematic result. And I think in general,
1367.24|4.04| maybe this is an area where AI shouldn't be employed. Yes. So
1371.28|2.84| why does this problem happen? So there was one comment by
1374.12|3.72| Katharina Zweig, which I think hits the nail on the head. It's
1378.0|3.24| the fundamental problem with face recognition by machine
1381.24|3.52| learning is that we never know exactly which pattern in an
1384.76|4.08| image, these machines are responding to. So yeah, deep
1388.84|2.88| learning can sometimes or often be more like a black box. So you
1391.72|3.68| never know, really, which parts of the image, the machine
1395.4|2.28| learning system is using, right, because you provide the whole
1397.68|2.6| image with background and everything. So do you really
1400.28|4.16| know what the machine learning is paying attention to? I don't
1404.44|2.76| know if that solves the problem. But if you think of zoom, for
1407.2|3.92| example, where you can easily switch these backgrounds, having
1411.12|2.44| these videos with data augmentation, swapping
1413.56|2.56| different backgrounds may help at least with this bookshelf
1416.12|2.8| situation. But there are, of course, more issues to be
1418.92|2.84| addressed here. But yeah, this is something if you develop
1421.76|3.16| systems, you should probably be aware of that and test also
1425.24|4.64| things like that and make sure that these these things are
1429.88|3.72| filtered out and not causing problems, especially in a real
1433.6|4.44| world application. So yeah, I'm related to looking into what
1438.08|4.44| deep learning does how it behaves. So I also saw another
1442.52|4.84| interesting tool called cockpit. It's also for pytorch. So it's
1447.36|3.64| a practical debugging tool for training deep neural networks.
1451.16|3.4| Think it might be something that could be helpful in the class
1454.56|4.48| project, for instance. So the authors say when engineers train
1459.04|3.28| deep learning models, they are very much flying blind. So here,
1462.32|2.32| they offer a collection of instruments to look into the
1464.64|4.88| inner workings of machine learning models. I don't know, I
1469.6|3.32| somehow screwed up the sentence here. So it's really useful for
1472.92|3.96| troubleshooting during training. And you can find a tool here on
1476.88|4.2| GitHub, just to show you one example here. So here, they are
1481.08|3.2| focused on the problem of learning rate tuning. So
1484.28|3.28| usually, when you want to find a good learning rate, you usually
1487.56|4.58| just try different things and see what works and tune it by
1492.14|3.54| hand and see you make it larger and smaller and see whether it's
1495.68|2.76| better or not. And then sometimes you also employ
1499.08|3.04| learning rate schedulers, which decrease the learning rate over
1502.12|2.76| time, we will discuss that in a future lecture actually in two
1504.88|4.64| weeks. But here's an example where the researchers looked at
1509.56|4.12| the loss curve. So they have mini batch training loss here
1513.68|3.4| plotted on the y axis. So that's the loss per minute batch over
1517.08|3.68| the different iterations. And orange and blue, these two lines
1520.8|4.16| are corresponding to different learning rate settings. Now, if
1524.96|3.0| they use a look at the loss landscape here in two
1527.96|4.96| dimensions, again, it's kind of hard to see, but in orange, they
1532.92|5.32| have one setting the orange one and blue, the other one. So
1538.24|2.24| here, what they want to illustrate is that the orange
1540.48|5.12| one is only updating a little bit and then it stops. So the
1545.6|3.24| learning rate is likely too small. And the blue one has a
1548.84|2.44| learning rate that is, is too large, you can see it's
1551.28|7.52| overshooting. So here would be the global minimum global
1558.8|2.56| minimum. So they are overshooting here. So the blue
1561.36|3.6| learning rate is too large, and the orange one is too small. And
1565.12|3.32| they offer some tools, for example, this alpha distribution
1568.44|4.12| here as a debugging tool. So this is like what they call a
1572.56|4.96| normalized step length. And zero would be where you would directly
1577.52|4.16| be stepping into the right direction of the of the minimum,
1581.68|2.92| the global minimum, or I think this local minimum in that
1584.6|5.2| context, wasn't actually quite clear. I think the paper, I
1589.8|3.04| think the tool looks great. The paper wasn't my favorite to read.
1592.84|3.32| It wasn't very well written. Maybe it was well written. I
1596.16|2.76| didn't understand it properly. I don't know. And a little bit of
1598.92|3.84| a hard time understanding certain things there. But what
1602.76|2.76| you want, what theoretically would expect is stepping into
1605.52|3.68| this, yeah, into this direction, directly, if you have a
1609.2|3.56| learning rate that does that, it would be optimal. And with this
1612.76|3.08| tool, you can see whether you are too small, like in the
1615.84|3.04| orange case, or too large, and then you want to adjust it more
1618.88|2.32| to the middle. Surprisingly, though, when they did some
1621.2|2.88| experiments on different data sets here, they found that the
1624.08|4.88| ones that resulted in the best generalization performance in
1628.96|3.32| terms of test accuracy, were slightly above the zero. So
1632.28|4.96| here, they found on these lines, these lines here correspond
1637.28|4.56| solid lines on the vertical lines here, they correspond to
1641.84|2.28| the models that had the best performance. And you can see,
1644.12|4.44| those are, at least, yeah, I would say zero or larger than
1648.6|3.68| zero in terms of this normalized step length here, they have the
1652.28|4.24| mean normalized step length. So, but in any case, this, I think
1656.52|2.36| might be a useful tool, if you are tuning the learning rate,
1659.0|4.32| you can just maybe see where you are here compared to the zero
1663.32|4.56| and then maybe focus on changing it to be somewhere in this
1667.88|2.2| region here. But this is something I haven't tried
1670.08|3.08| personally. So this is also something that's new to me, I
1673.16|3.0| usually, like many other people tune the learning rate by hand,
1676.16|2.92| but it might be something useful to look at in the future. So
1679.08|2.36| with that, I think that's all the news I have, I think it's a
1681.44|4.32| long video. But yeah, with that, let me end this video and I
1685.76|17.6| will see you back in class next week.