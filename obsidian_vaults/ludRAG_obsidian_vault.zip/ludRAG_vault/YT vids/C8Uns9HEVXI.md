start_time|end_time|text
10.78|3.26| Alright, let's now finally talk about training single layer
14.04|2.88| neural networks, and in particular, the perceptron
17.08|4.12| learning rule. So that goes back to the Rosenblatt perceptron
21.2|3.04| that we briefly mentioned in the history of deep learning
24.24|5.56| lecture. So the perceptron is kind of like a model. But yeah,
29.8|3.8| thinking about it, the model was already proposed by McCulloch's
33.6|3.16| and Pitts, the mathematical model of a neuron in the human
36.76|3.1| brain. So at least it was inspired by this biological
39.88|4.2| neuron. And the perceptron to be more, I would say specific, it's
44.08|2.76| a learning rule for the computational mathematical
46.84|3.56| representation of the neural model. So this is now offering
50.4|3.92| us something that can help us find the weights automatically
54.32|4.24| to make classifications, for example. So previously, we have
58.56|5.2| seen that how we can manually implement end and or functions
63.8|4.36| using specific weights of one and a certain threshold. Now
68.16|4.36| with the perceptron, we can find automatic weights for different
72.52|2.56| types of problems like classification problems in
75.08|3.8| general. So here's a picture of how that looked like back then.
78.88|3.48| So back then, the perceptron was actually a hardware device where
82.36|4.08| people Frank Rosenblatt had to plug in and plug out certain
86.44|2.96| cables to reach certain decisions and stuff like that.
89.64|2.92| So but yeah, we are not in a museum here. So we don't have to
92.56|6.12| go over how that works. So yeah, moving on. So I also should
98.72|3.88| highlight just for correctness, there are multiple perceptron
102.64|4.0| algorithms. And I don't know how many, but there are several
106.64|3.48| variants. Here we are talking about, let's call it the
110.12|4.32| perceptron. So basic version of the perceptron, which is now the
114.44|6.16| commonly known variant. So when we talk about the perceptron, in
120.64|3.88| theory, it's a perceptron, one of the classic Rosenblatt
124.56|2.96| perceptrons. But yeah, there are multiple ones, we don't have to
127.52|3.44| worry about it here. We just take the classic one that is
130.96|4.4| commonly known and just refer to it as perceptron for short. So
135.36|2.36| yeah, now we have a computational model of a
137.72|3.2| biological neuron here. So for reference, on the left hand
140.92|3.52| side, what is shown is the biological neuron. And on the
144.44|3.52| right hand side, would be the computational or mathematical
148.28|3.56| representation of that. So the one based on McCulloch and
151.84|3.16| Pitt's idea, and that is also then the model that we are going
155.0|3.12| to use in the perceptron. So the perceptron learning rule would
158.12|4.56| be then learning the parameters of this model. So how does this
162.68|5.08| model work? So what we have here are the inputs x one to x m. And
167.76|4.36| you can think of it as a feature vector. For example, if you think
172.12|3.92| back of the iris data set, so in the iris data set, we had a
176.04|4.12| tabular data set where we had petal length, let's do it
180.16|4.48| correctly, sepal length, sepal width, beta length, and beta
184.64|4.0| width, the four features. And then we had the number of
188.64|5.08| training examples of 1234, and so forth. And in this case, we
193.72|8.88| had m features where m equals four. So here is x one x two x
202.6|2.64| m, you can really think of it as a feature vector, for example,
205.32|3.08| a feature vector corresponding to the first training example.
208.8|3.82| And then each feature value gets multiplied by a weight. So you
212.62|4.5| can see, each x here goes together with the weight. So
217.12|2.64| they are multiplied to compute the so called net input, the
219.76|7.6| weighted sum. So this is weighted sum, which you compute
227.96|5.96| SWI times x i. And this is then what we usually use, or we
233.92|2.94| usually use the letter z for representing that to have it
236.86|5.96| more compactly. And then so this is an input here. And then we
242.82|3.26| pass it to a threshold function. And a threshold function is
246.08|4.36| returning a class label. So the class labels either zero or one,
250.72|4.96| depending on the value of z. So if z is smaller than the
255.68|3.88| threshold, then we return the class label zero. And if z is
259.56|5.24| greater than a threshold, we return class label one. To be
264.8|4.2| more precise, if z is smaller or equal to the threshold, but if
269.0|3.6| we use floating point operations, like real value
272.6|2.88| numbers in a computer, then the chance that something is equal
275.48|4.02| is very small, because it could be also equally greater or equal
279.5|2.82| to so in that case, we could remove it here. So it's, I'm
282.32|4.46| trying to say is whether we use zero smaller than and greater
286.78|3.62| equal to or smaller equal to and greater doesn't really matter.
290.4|2.68| Either either way would work, because the chance that we have
293.08|6.08| an equal is kind of very small anyways. So in our output, this
299.16|3.1| is the either the zero or the one that is our class label. And
302.26|3.62| now we can, yeah, then talk about a learning rule for this
305.88|3.44| perceptron that can then be used to determine a good threshold
309.44|4.8| and a good, good values for w, so that we can solve different
314.24|3.92| classification problems, for example, classifying flowers in
318.16|3.64| an iris data set. However, one shortcoming here is that this is
321.8|4.48| only for binary labels, so zero and one. And in iris, we have
326.32|3.68| three flower classes. So if we would want to use the standard
330.0|3.72| perceptron for iris, we would have to simplify the data set to
333.72|3.2| only two flower classes, but we are getting ahead of ourselves
336.92|3.64| here. So also here at the bottom, I just see another
341.0|3.64| equation included. So this is also abbreviating the threshold.
344.76|3.32| So the threshold based on the threshold function based on the
348.08|4.24| threshold theta, if it receives basically the weighted input, so
352.32|6.4| this is the net input. It returns the predicted class
358.72|7.56| label y hat. So y hat, the output is the predicted class
366.28|5.0| label. I will show you how that looks like for a concrete data
371.28|7.2| set later on. Yeah, here to recap some of the terminology
378.48|3.16| that I already introduced in the previous slide, I made an
381.64|4.6| overview slide because some of these symbols and words or terms
386.24|2.72| will be used later on in this course, when we talk also about
389.12|5.96| logistic regression and multi layer neural nets. So we have
395.08|2.6| the net input, which is just another word for the weighted
397.68|4.16| inputs. And we usually use the symbol or letter z for denoting
401.84|4.92| that on the activations, these are values from activation
406.76|3.12| function. So an activation function takes the net input as
409.88|5.32| input. And we use the letter a and the activation function is a
415.2|4.68| sigma, which takes in z. So this is something that we will be
419.88|4.32| using over and over in this course. And then the output of a
424.2|3.96| model, that is when we apply the threshold to these activations
428.48|4.44| of the last layer of a neural network. And we can, for example,
432.92|2.92| use y hat to denote the predicted label or the output.
436.72|4.6| And F is the threshold function which takes an A. So the flow
441.32|5.6| would be, you can think of it as first computing. So if we go
446.92|5.84| from z, so we have z is the weighted net input. So this is
452.76|5.52| computed based on x and w. And then we use sigma and activation
458.28|5.6| function to compute these activations. And then we have F
464.88|5.96| to compute the label outputs. So this will become also more clear
470.84|4.04| clear later, because right now, we have a special case in the
474.88|3.2| perceptron, where our activation function is the same as a
478.08|2.92| threshold function. So the perceptron doesn't really have
481.0|3.2| an activation function, they are here in that case, synonymous.
484.56|3.6| And in linear regression, there's another special case. So
488.16|2.16| some of you are probably already familiar with linear
490.32|3.2| regression. So in linear regression, the activation is
493.52|3.28| equal to the net input, and it's also equal to the output. So in
496.8|3.24| that way, um, yeah, these are two special cases, and it will
500.04|4.08| become more clear. So I can maybe quickly draw this. So if
504.12|5.24| we have a linear regression model, recall what we had in the
509.36|3.16| history of deep learning lecture, and also on the Piazza
512.52|3.68| discussion, the relationship or the figure that I shown of the
516.2|2.6| adder line, and then also how that related to the linear
518.8|4.96| regression. So if we have then the model here, and a linear
523.76|3.84| regression, we would have a linear activation or just the
527.6|5.4| weighted sum, and then the output is just a weighted sum.
533.0|3.6| It's our continuous value in a regular neuron, we have usually
536.84|3.48| the steps, we have the weighted sum. So this is our net input.
542.0|7.36| And then we have activation function. And then we have a
549.76|3.44| threshold function. And then this produces our output.
553.2|4.48| output. However, in the perceptron, so in the
557.68|4.12| perceptron, these are the same, the sigma and the threshold
561.8|6.8| function, they are one function. And in the linear regression
568.6|3.88| model, so in the regression model, we don't have these. So
572.48|4.48| the net input is basically our y hat. So there are these special
576.96|6.22| cases. But let's not worry about it too much, because we will be
583.18|4.1| talking about linear regression and logistic regression later on
587.28|3.4| in more detail. So you will see how these concepts of activation
590.68|5.36| functions and thresholds relate to these. So let's focus in now
596.04|4.24| on the perceptron and only worry about the net input and the
600.28|4.24| threshold, where in the bottom here, you can, again, see the
604.52|2.88| summary where we have first weighted inputs as the net
607.4|2.84| input, and then we apply the threshold to return either the
610.24|8.04| zero or one, depending on the threshold value on theta. So I
618.28|3.48| want to make one little change to that formula to make things a
621.76|5.28| little bit more convenient. So I just told you that we return
627.12|5.74| zero, if z is smaller or equal to theta threshold, and it's the
632.86|4.74| output is one, if z is greater than theta, it's a little bit
637.6|3.56| inconvenient to write it like this. For I mean, it's not that
641.16|3.48| inconvenient, but for the sake of training the perceptron, it
644.64|3.72| would be more inconvenient. So we will make things a little bit
648.36|5.32| more convenient by rearranging the terms. So we are just now
653.68|4.4| applying the mathematical operation minus theta on both
658.08|3.64| sides. So we are bringing theta here onto the left side. And
661.72|6.0| then what we get is we return zero, if z is smaller, if z
667.72|4.24| minus theta is smaller equal to zero, and we return one, if z
672.04|3.6| minus theta is greater than zero. So in this way, this is
675.64|6.0| our, I would say more convenient notation here. And if you think
681.64|3.76| about it like that, you can think of the negative
685.44|4.48| threshold. So this part here, you can think of it as a as a
689.92|5.52| bias. So this is like a common term in deep learning, or also
695.44|2.92| in machine learning, a bias unit, it's a little bit weird
698.36|2.44| to use the term bias, because it's a little bit overloaded,
700.8|2.88| there are other types of bias. For example, there's an
703.68|3.24| inductive bias, like this relational inductive bias that we
706.92|3.2| talked about, there's also a fairness bias, and now we have
710.12|5.16| this bias, mathematical bias unit here. There's also a
715.28|3.26| statistical bias, if you think of decomposing a loss function
718.54|4.06| into a bias and variance term. So it's a bit unfortunate. But
722.6|4.96| in the context of deep learning, if you read the term bias unit,
728.02|3.66| that would be in this case, this, this theta, we can treat
731.68|4.08| it as a parameter will become more clear in a few moments.
737.76|4.36| Yes, in this representation, we are now using the bias as a
742.12|6.28| parameter, when we compute z. So we set the minus theta to be
748.4|5.2| B is short for bias unit. So it's easy to memorize B for
753.6|4.8| bias unit. So we set B equals to this minus theta. And then we
758.4|5.84| compute the Z, the net input is shown here. So just to recap,
764.52|6.76| what we had before was multiplying the W's and the
771.28|8.16| X's. So this is from index one to M. And this was our Z. Now,
780.22|3.9| when we compute the Z, let's call it. Let's make that right
784.12|4.56| to denote this on UC. This includes now our bias unit. So
788.68|3.2| net input is now including the bias unit, if we want to update
791.92|5.12| the figure to reflect that I've drawn here, this B, this B goes
797.04|3.08| now also into the net input. So the net input is really this
800.12|5.64| computation here. And yeah, it's also the same as shown here. And
805.76|5.44| now what we can do is we can also write then the activation
811.2|3.4| function or here the threshold function. So I should have
814.6|4.08| actually used F, but the perceptron is the special case
818.68|2.8| where the threshold function is equal to the activation function.
821.48|3.8| So I can use either sigma or F doesn't matter here to be
825.28|4.82| consistent. And so now we can have the zero here on the right
830.1|4.78| hand side instead of having the minus theta. So this will make
834.88|2.72| more sense from a learning perspective. So in this way,
837.88|2.8| it's easier to parameterize the network, if we don't have to
840.68|2.44| learn the threshold here on the right hand side is just easier
843.12|3.66| to write in code. Because then we have a threshold function
846.78|3.22| that just simply checks whether some something is greater or
850.0|2.52| smaller than zero. But of course, you can also implement
852.52|3.92| it. Like shown on the previous slide with a minus theta, it
856.44|4.0| doesn't really matter. But this is also the common notation. And
860.44|3.28| this will be something that you will also encounter when we talk
863.72|3.4| about multilayer perceptrons, convolutional networks,
867.12|3.0| recurrent networks. And when we use existing code
870.12|2.92| implementations, for example, in pytorch, this is really like the
873.04|3.88| common way also, if you look at recent deep learning papers. So
876.92|2.64| this is like the like I said, the common notation that you
879.56|3.56| will find in most modern texts, like maybe not textbooks,
883.12|2.52| because textbooks are usually a few years behind with the
885.64|3.04| trends. But if you look at a modern deep learning literature,
888.68|3.32| you will find that people use this extra this notation with a
892.42|4.82| additional bias unit here. Yeah, however, it's slightly
897.24|3.4| inconvenient for mathematical notation compared to a slightly
900.72|3.48| different notation again. So on the right on the next slide, I
904.2|3.44| will show you how we can modify this even a little bit
907.64|6.0| differently to have the bias as part of the other inputs. So
913.64|6.0| here, what I've done now is I'm setting B equals to weight, I
919.64|4.36| call that W zero. And this is again, or minus theta or minus
924.04|4.92| or negative threshold. Now I'm including this bias as a weight.
929.24|4.16| So first, let's maybe start with the figure. If you look at the
933.4|2.82| figure here on the left hand side, what I've now what I've
936.22|3.74| done now is I have removed this B here, I've removed that
939.96|5.24| B here, compared to the previous slide, and now have the value
945.24|2.52| one, this is really like a value, an integer or float
947.76|3.64| number of value one. And then now I have the W zero as weight.
951.52|3.4| So this is essentially our bias, but I'm writing it as a W,
955.36|3.32| because then we can write this notation more compactly. So
958.68|4.56| instead of writing it on the previous slide with index over
963.24|10.16| one to M, like this, with a W with a B, or you can also write
973.4|5.44| it as this, instead of this, I can change this to zero, and
978.84|3.24| then I can get rid of it as slightly more compactly. It's
982.08|3.08| not that interesting to do it like this. But as one advantage
985.16|3.04| of doing it as the advantage is that we can now use a dot
988.2|7.04| product, just x transpose W. If we wouldn't have the modified
995.24|2.76| version here, what we would have to do is we would have to write
998.0|9.64| it as x transpose W plus B, which is just slightly more work.
1007.64|3.08| It's not that much more work. But yeah, mathematicians are
1011.04|3.48| sometimes efficient or lazy. I would say not lazy, definitely
1014.52|4.0| not lazy, but efficient. So the notation here shown would kind
1018.52|4.52| of help us to make things a little bit simpler. So why am I
1023.04|3.68| telling you this? So this is something this notation here on
1026.72|3.84| this slide is something you will find in some or most textbooks,
1030.56|3.08| actually, whereas this is I would say the more modern one. I
1033.64|4.16| mean, for things like this, it might be overkill to use this
1037.84|2.88| separate bias. So this looks simpler. But when we talk about
1040.72|4.6| multi layer networks, actually, this becomes more convenient.
1045.32|3.48| And this is also what most framework use. And the reason
1048.8|3.72| why this is more convenient is because I'm going I don't want
1052.52|2.32| to switch too much because it probably gets confusing when you
1054.84|1.84| watch this video, and I'm going left and right and left and
1056.68|4.48| right. But one more thing about this slide is, if you want to
1061.16|3.16| use this notation, you have to modify the inputs here, right.
1064.6|4.56| So if you think of the iris example, you have x one, x two,
1069.16|3.52| x three, x four as your feature vector for one training
1072.68|5.08| example. So this would be your, let's say, first training
1077.76|6.36| example. Now, if you have this as input, and you want to use
1084.12|2.36| this notation, what you might have to do, what you would have
1086.48|3.44| to do is to have, you have to have one here. So you have to
1089.92|6.84| modify this list. So in practice, usually you have fixed
1096.76|4.12| size array, and then you would have to make a new array. That's
1100.88|2.84| how it would work in a computer, you would have to make a new
1103.72|2.24| array that is a little bit bigger. And then you have to
1105.96|3.24| move all the values you have to let me use different colors,
1109.2|5.84| maybe you have to make an x one, x two, let's start with one, put
1115.04|5.06| the one here, and then the x one, x two, x three, x four. So
1120.1|3.14| you have to make a new array to make the one fit into this array.
1123.52|2.52| And making a new array can be expensive, of course, it's an
1126.04|4.28| additional computation, it's just much simpler. If we just
1130.32|6.52| add this B to it, if we compute it as x transpose w plus B,
1136.84|3.8| this is computation actually simpler than adding a new value
1140.64|2.76| to an array, because then we have to make a copy of the array
1143.44|3.84| move all the values over. And this is something it's a
1147.28|5.16| computational consideration, essentially. Yeah, I'm not
1152.44|3.12| exactly sure what I wanted to show on this slide. I think I
1155.56|3.48| just wanted to emphasize again, that we can now use dot product.
1159.56|3.76| Alright, so this is our general framework. And now we are going
1163.32|3.88| to take a look at the perceptron learning rule. So how it
1167.2|4.16| actually learns the weights to classify classes. So assume we
1171.36|3.12| have a binary classification task. So here we have two
1174.48|7.76| classes, these blue dots and the yellow or orange squares. And
1182.24|4.2| the perceptron finds the decision boundary to classify
1186.44|3.88| these two classes. If the classes are separable, by that,
1190.32|3.3| I mean, if there is a linear decision boundary, I should have
1193.62|7.06| maybe set linearly separable, that means there has to exist a
1200.68|3.0| decision boundary that can separate these classes
1203.68|3.6| perfectly, then the perceptron is guaranteed to find it. So
1207.28|3.72| here, just looking at it, you may guess that decision one, you
1211.0|3.38| could potentially look like that, and then it will perfectly
1214.38|5.26| classify these two classes. So this is a problem with only two
1219.64|3.44| features for simplicity. Because if I have more than two features,
1223.08|3.4| it would be very challenging to draw it in a slide. So in this
1226.48|2.68| case, we only focus on the simple example. And I actually
1229.16|3.64| made an animated GIF here, I will play it in a second. And
1232.8|4.16| then you can see how the network or the perceptron goes about the
1236.96|3.36| task of finding this decision boundary. So starting at a
1240.32|3.72| random place, it will basically update the rule in each
1244.04|3.48| iteration. So there will be an iteration counter moving up by
1247.56|3.48| and it will try to adjust decision boundaries to make them
1251.04|1.92| better, basically. So let's take a look.
1260.0|2.88| Actually, I forgot how many iterations they are, there might
1262.88|3.92| be 20 or 30. So you can see it's still making mistakes. And the
1266.8|4.48| circle that is shown here, that is indicating which data point
1271.28|2.84| it currently looks at. So you can see it's on this black
1274.12|3.72| circle, it's moving around, because we have shuffled the
1277.84|3.4| data set. And then it will look at one training example at a
1281.24|4.84| time. And if it finds that there's a misclassification, then
1286.08|2.72| it will move the decision boundary. So if it right now,
1288.8|2.4| you can see it always finds classes that are already on the
1291.2|2.36| right, correct side of the decision boundary. So there are
1293.56|4.12| no updates are necessary, but it has to find are on the ones
1297.68|2.8| where it makes mistakes like these here, if it touches these
1301.24|3.76| updated. So if it touches these, see, then it will update. So
1305.0|3.44| yeah, it's back to one. So it was a little bit faster. Let me
1308.44|3.2| move on though. So yeah, what you can see here in the lower
1311.64|5.28| left corner is the results. Yeah, it was 49 iterations. So
1316.92|2.52| here's the final decision boundary, how it looks like. And
1319.44|4.48| you can see it, um, yeah, it classifies those two classes,
1324.12|8.8| say, class, zero and class one perfectly. Now, though, it's
1332.92|3.96| gone only guaranteed to converge if a solution exists. So if
1336.88|3.68| there is no solution to that, for example, if I have a blue
1340.56|4.12| dot that is here, there would be no decision boundary, where you
1344.68|3.32| can classify this data set perfectly. And what will happen
1348.0|3.88| is, if the perceptron encounters this point, it will move the
1351.88|4.4| decision boundary more to this side. So it may even move the
1356.28|2.48| decision boundary, let's say to here, but then all the other
1358.76|3.0| points are wrong. So it's moving it back here. But then again,
1361.76|2.6| this blue point is wrong, and it's going back to the right
1364.36|3.44| hand side. So it's always like flipping back and forth. So if
1367.8|2.92| the data set is not perfectly separable, then it will never
1370.72|3.44| stop to converge. Later in this course, we will of course learn
1374.16|3.12| about algorithms where this is not the case, where it will
1377.28|3.36| always converge to at least some solution, it will at least stop
1380.64|2.88| updating. Because I mean, this is a big issue. If you have a
1383.52|4.44| real world data set, classes are rarely separable by linear
1387.96|2.8| decision boundary, there's usually always a case where you
1390.76|3.48| can't separate things perfectly. And it would be very annoying if
1394.24|3.5| your algorithm makes these big jumps back and forth. So the
1397.74|5.02| Adeline algorithm, for example, it will converge even if classes
1402.76|3.64| are not linearly separable. And we will learn about this and not
1406.4|3.24| to distant future. But for now, let's stick with the perceptron
1409.64|3.9| learning algorithm, just outlining how it learns. So
1413.54|3.38| there are three scenarios. It's the one scenario is if is if we
1416.92|4.44| make a correct prediction. By that, I mean, if the predicted
1421.36|5.12| label y hat is equal to the target label. So for that, we
1426.48|7.76| can also have two scenarios of the if y hat is one, and y is
1434.24|5.8| one, or if the predicted label is zero, sorry, someone jumped
1440.04|6.64| here, the predicted label is zero. And the actual label is
1446.72|3.48| also zero, then we are correct. And then we don't have to do
1450.2|3.08| anything. So if both the prediction of the output are
1453.4|7.0| equal to the target, I think this word is extra. Okay, and
1460.4|4.28| there are no two scenarios and be where things have to be
1464.68|3.64| updated. It's if we are incorrect. So one scenario is
1468.76|6.64| where y hat is zero, and y is equal to one. So in this case,
1475.44|3.64| what we do is we add the input vector to the weight vector. So
1479.08|4.44| we update it like that. So that means, let me draw this maybe as
1483.52|6.88| an example. So if we have data points here, data points here,
1490.56|2.88| or let me spread them a little bit. Oh, that's easier to draw
1493.44|6.76| the decision boundary. So let's say, blue is class zero, and
1500.52|4.12| yellow is class one. In this scenario here, what we have is
1504.64|2.92| we have the prediction is zero, although the true label is one.
1507.56|2.72| So for example, for a decision boundary like that, and we
1510.28|3.16| encounter this data point, what we have to do then is we have
1513.44|4.6| to move things over here. It's by adding the input vector to
1518.04|5.08| the weight vector. Why is that I will show you exactly why that
1523.12|3.92| is later when I go over the geometric intuition, and it will
1527.04|2.8| become clear why we have to add the input vector to the weight
1529.84|3.76| vector rather than subtracting it. The other scenario is if the
1533.6|3.8| output is one, and the target is zero, and then we subtract the
1537.4|3.12| input vector from the weight vector. So there are two update
1540.52|3.4| rules here going on. They are both very similar, we can write
1543.92|3.8| this mathematically very compactly, as shown here. So
1547.72|9.12| here, assume we have a data set D, this is our training data
1556.84|6.28| set. So we have n data points here from one to n. So x our
1563.12|7.28| feature vectors, and y our class labels. Yeah, so this is our
1570.4|4.12| data set. And now here, that's the perceptron learning
1574.52|4.12| algorithm. So how does it work? First, we initialize the weights
1578.68|3.92| or the weight vector to zeros, if we have m weight vectors,
1582.6|4.2| that would be a vector of zeros. And we are assuming the
1586.8|3.8| notation where the weight includes the bias, so we don't
1590.6|2.52| have to write the bias separately, we could do that, but
1593.12|2.32| it would be a little bit more work here. So it would be a
1595.44|2.12| little bit more verbose. So there's a little bit more
1597.56|5.56| compact here. So then we have a follow up here. So for every
1603.12|6.4| training epoch, what is an epoch epoch means pass over
1610.28|8.36| the entire training set. So if I have a training set, like shown
1618.64|6.48| here, then an epoch would be processing every data point in
1625.12|3.44| this data set. So for example, I consider the first data point, I
1628.56|3.28| do my computation, then I consider the second one, and so
1631.84|4.96| forth until I reach the last one. And then this is one epoch
1636.8|3.48| when I when I reached this last data point, and I have
1640.28|5.96| completed one epoch. And then I may go back to the beginning and
1646.24|4.08| do another sweep over the data set, that would be then the
1650.36|3.88| second epoch and so forth. So epoch really means pass or
1654.24|4.44| iteration over the data set. So then this is our auto loop. So
1658.68|3.8| for every training epoch is our auto loop, and then the inner
1662.48|4.2| loop is for every data point in the data set, we perform steps
1666.72|4.72| A, B, and C. So if we have multiple epochs, that means we
1671.44|3.08| can do this multiple times. So we would just go back to the
1674.52|3.12| beginning of the training set and do it all over again. So but
1677.64|3.6| the interesting part happens now for every data point. So note
1681.24|7.6| here, the perceptron processes, one data point, or training,
1688.88|11.8| let's say, one training example at a time. So for every training
1700.68|6.92| example, compute the prediction, this is our prediction. And it's
1707.6|4.2| computed by computing the weighted sum, this is our net
1711.8|6.52| input. So this is input z. And this is our predicted label. And
1718.32|5.92| then we compute the error. So the error is computed by the
1724.24|5.26| true label minus the predicted label. Why is that? So if this
1729.5|4.3| is one and this is y hat is zero, for example, then so let's
1734.04|3.0| first let's assume the simple case where we make no error. So
1737.04|6.8| if we have zero and zero, then the error is zero. And then if
1743.84|6.52| you look at the row C here, we have the weight update. So C is
1750.36|4.48| the weight update, then the weight update or the new weight
1754.84|5.56| is the old weight plus the error times the input vector. But if
1760.4|4.24| the error is zero, if the prediction is correct here, zero
1764.64|3.32| minus 00, then we can cancel this term and there is no weight
1767.96|5.68| update. So let me clear this a little bit here. If both are
1773.64|3.56| one, then the error is also zero. And then we can also
1777.2|3.8| cancel this term. So we can see the weight update only happens
1781.04|5.08| if we have an error if we make a prediction error. And then now
1786.16|4.86| let's consider the case where we have a one and a zero here. So
1791.02|7.34| then the error would be one here, so we would have an error
1798.36|5.64| of one into then we would be adding the weight vector. So if
1804.0|5.6| we have the case for the predicted label as a zero, and
1809.6|4.48| the case for the true label, a one, this is when we are adding,
1814.58|3.02| adding something, right? So we are adding the feature vector
1817.6|4.08| here. So this is exactly like the case that we have here
1821.72|5.64| where y hat is zero, and y is one, this is the same case here.
1828.0|5.92| Now, let me, I can't delete if I switched slides. Okay, so then
1833.92|2.76| let me write it like this, with a different color. So if we have
1836.68|4.84| the last scenario, zero, and one, then our arrow is minus
1841.52|6.12| one. And in this case, if this is minus one, we are subtracting,
1847.72|6.76| right? So w minus x one, so we are subtracting the feature x i,
1854.68|3.92| we are subtracting the feature vector, which is equal to this,
1859.76|3.84| sorry, to this case here, where we are subtracting the input
1863.6|4.44| vector. So here, this is really just a mathematical summary of
1868.04|4.86| the slide I've shown you before. Alright, so I think if this is
1872.9|5.38| confusing, maybe look at that more slowly. And then in the
1878.28|5.04| next video, I will show you vectorization in Python. And
1884.2|3.92| after that, I will also show you how to implement perceptron in
1888.12|4.16| Python using NumPy and pytorch, which will I think, make this
1892.28|3.8| video more clear. So what we just have discussed, if this is
1896.08|3.68| still complicated, I would look at it a little bit more slowly,
1899.8|4.04| like step by step. And then maybe don't worry about it too
1903.84|2.36| much, because we will implement it in code. And after that, I
1906.2|20.52| think it will be really clear.