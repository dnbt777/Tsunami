start_time|end_time|text
2.28|4.16| Yeah, let's start by defining the term tensor and how it is
6.44|5.2| used in the context of deep learning. So yeah, tensor, a
11.64|4.68| tensor is a generalization of the concept of a vector matrix
16.36|5.0| and scalar and so forth. So for example, here's a scalar, a
21.36|4.88| scalar is also you can think of it as a rank zero tensor. And an
26.24|4.32| example of a scalar would be for example, a real number. So it
30.56|2.68| could be also an integer, for example. So but yeah, in the
33.24|3.24| context of deep learning, we will usually work with real
36.48|4.24| numbers most of the time, except maybe for the class labels where
40.72|4.48| we have integers. So here, for example, that would be a scalar
45.2|7.12| a single value like 1.23. And a vector would be a rank one
52.32|4.16| tensor. So you can see, we're adding a dimension to it vector
56.48|3.32| as a rank one tensor, and the matrix would be then a rank two
59.8|7.04| tensor. So a vector is a vector is like you can think of it as a
66.84|5.52| data container with n values in it. So that is usually
72.36|4.64| something you would find in a linear algebra book. However, in
77.0|3.32| our context here in machine learning and deep learning
80.32|5.28| concepts, contexts, we usually think of vectors as n times one
85.6|4.48| dimensional. So it's still written the same way as you
90.08|2.32| would find it in a linear algebra book if this if you
92.4|4.88| would write it like follows, we have n elements, one, two, two
97.28|4.96| n. However, we will assume there's another dimension there.
102.44|4.56| It's just one. So there's one other dimension with no values
107.0|3.92| in there. So it's essentially a very you can think of it as a
110.92|4.0| very slim matrix, a matrix with only one column. And that is
114.92|3.32| because you have for certain computations for convenience.
119.72|4.08| Yeah, and usually by default, I will denote the vector as a
123.8|4.52| column vector. However, when I write a transpose, we will also
128.32|3.96| sometimes use row vectors. So it's basically just a vector
132.28|3.88| transposed, which is now a one times n dimensional vector. So
136.16|3.96| yeah, regarding the matrix, he has an m times n dimensional
140.12|9.2| matrix. So m is the number of rows. And n is here the number
149.32|6.28| of columns. So that is just a general layout. So if n was one,
156.88|3.36| then we would have just this first column here. And you can
160.24|4.24| then ignore this one, this would be then a column vector, like
164.48|4.22| shown on the left hand side here. This is just yet to lay
168.7|2.8| the groundwork into the notation, but a vector in the
171.5|4.16| matrix, and the scalar are and how that relates to the concept
175.66|5.5| of a tensor. Now, in the context of deep learning and machine
181.16|5.7| learning, we usually use for the data, so called design matrices,
186.86|4.52| that's a common convention, we use the letter x, then we
191.38|5.72| usually refer to a design matrix, which is an n times m
197.18|3.44| dimensional matrix. So on the previous slide, what I was
200.62|4.64| writing on the previous slide was m times n dimensional, this
205.26|3.32| is just something you would find a linear algebra textbook, the
208.58|3.24| letters here m and n don't matter really. But there is a
211.82|2.96| convention in machine learning and deep learning that most of
214.78|9.44| the people use n for the data set size in terms of the number
226.06|11.6| of training examples. And m is the number of features. So this
237.66|3.96| is why I'm writing it as n times m. But it's also not super
241.62|3.48| important. It's just just a convention. And then like I
245.54|3.72| already talked about in the very first lecture, we will be using
250.06|7.96| the subscript for the features. So that's the feature index. And
259.26|5.96| here, the superscript, that would be the training data point
265.22|6.52| index or training example index, say call it training example
272.9|4.2| index. So if we have n training examples, then we would have the
277.1|4.12| indices one to up to n. And here, we would have up to m
281.22|6.04| features. For example, in the iris data set, we would have 150
288.02|5.16| training examples or data points and four features. So this would
293.18|6.72| be m and this would be n. Yes, on the previous slide, we have
299.9|6.48| seen rank zero tensors and called them scalars. And we had
306.66|5.44| for rank one tensors, the word vector and for rank two tensors,
312.1|6.32| we had the word matrix. Now for rank three tensor, how should we
318.42|4.2| call it? Unfortunately, there is no special word for that. So
322.62|4.32| usually, if we call or refer to a rank three tensor, we use the
326.94|6.68| word 3d tensor, or sometimes or often even just tensor in without
333.62|5.24| the 3d here in front of it. So yeah, um, what is a 3d tensor,
338.86|4.72| then a 3d tensor, you can think of it as a stack of matrices. So
343.58|7.16| if each of the box here represents a matrix, a rank two
350.74|4.0| tensor, then a 3d tensor would be in the context of deep
354.74|4.16| learning. Like you can think of that like a stack of matrices,
358.9|3.52| so multiple of these matrices stacked on top of each other.
362.66|4.16| For example, here, this would be a stack of p matrices, and each
366.82|5.68| of the matrices here is m times n dimensional. So here we have m
372.54|4.16| times n dimensional matrices, and we have p of such matrices
376.7|4.12| here. And note here, the m and n, they are really arbitrary,
380.82|3.32| they don't refer to the features and training examples. These are
384.14|3.36| just some arbitrary letters, I was just using m and p, because
387.5|3.8| they are commonly used. But here, don't don't think of them
391.3|2.56| as training examples of features, they're just generic
393.86|5.04| terms here, or letters. So in practice, where we encounter
398.9|3.28| these 3d tensors in deep learning is, for example, when we
402.18|4.36| work with image data. So you can think of a single image here,
406.54|7.68| like this cat as a 3d tensor, where we have, for example,
414.26|4.64| three color channels, the color channels are for red, g for
418.9|3.32| green, and B for blue. And each of these color channels
422.46|4.96| consists of pixel values, for examples, could be a 100 times
427.42|3.92| 100 matrix containing the pixel values for each of the color
431.34|5.04| channels. And combined, they are basically a 3d tensor. And that
436.38|3.18| would be a case where we encounter a 3d tensor when we
439.56|4.74| work with image data in deep learning. However, it doesn't
444.58|4.68| stop there with 3d tensors. And practice actually work with 4d
449.26|2.6| tensors in deep learning, because we have a training set
451.86|4.52| consisting of multiple of such 3d images. So you can think of
456.6|5.18| the 4d tensor here, if I go back as a stack of multiple of these
462.3|3.52| 3d tensors, basically, so stacking multiple of these. So
465.82|3.44| here, on the right hand side is just an example of the cipher 10
469.26|9.4| data set. So each each of these is an RGB on 3d tensor. Yeah,
478.66|3.64| and then also regarding the dimensionality. Usually, in
482.3|4.12| deep learning, we have the dimensionality of these four
486.46|7.64| tensors as n, c, h, w, where n is the number of training
494.1|10.56| examples. Then c is the number of color channels, for example,
505.1|6.8| three in the case of RGB. So this is the color channels. And
511.9|9.96| then h is the height of the image. And w is the width. So in
521.86|4.84| that way, on these last three dimensions here, they are
526.7|4.24| basically our features m. So in this case, we have c times h
530.94|4.64| types w features, and n is still on our training examples. So if
535.58|3.44| we don't use deep learning, we would reshape that we would
539.06|5.6| reshape that into a matrix design matrix, which is n times
544.66|8.16| m dimensional, where m is really c times h times w. Alright, so
552.82|2.72| but we are we are not working with color images yet. That
555.54|3.36| would be something when we encounter convolution networks,
558.9|3.88| where we talk about this. But I also plan to, yeah, to use a
562.78|4.6| simpler model with color images, where we explore then also this
567.58|5.84| this reshaping. So but don't worry about it yet. Also, yeah,
573.42|2.84| one more thing I wanted to say about tensors, you probably
576.26|6.08| heard about the tool, TensorFlow. So TensorFlow has
582.34|4.32| the name tensor in it. And here, in the context of these tools,
586.66|4.36| like TensorFlow, or NumPy and pytorch, the tensors really
591.06|5.76| refer to the concept of a multi dimensional array. So multi
596.82|3.72| dimensional array, you can think of it as a data structure or a
600.54|5.32| computational data structure for storing or representing a
605.86|5.32| tensor. So in mathematics, we say tensor, but in practice,
611.18|3.36| when we do coding, these are essentially multi dimensional
614.58|6.12| arrays. And it just happens in TensorFlow, these multi
620.7|3.2| dimensional arrays are called tensor. In NumPy, they are
623.9|6.72| called nd array, where nd array stands for n dimensional array,
630.66|2.96| like multi dimensional n dimensional. And in pytorch,
633.62|3.6| they are also called tensor, but they're essentially all the same
637.22|4.64| thing. So here's just an example. So here I'm creating
641.9|4.56| importing torch creating a tensor. And this tensor is two
646.46|4.68| by three matrix. So two rows, three loops, three columns. So
651.14|4.76| this is really two by three matrix. And then here, what I'm
655.9|4.24| doing is I'm using t dot shape. And notice in NumPy, there's
660.14|2.88| also a t dot shape, you probably know that. And this gives you
663.06|5.32| the dimensions of the multi dimensional array or tensor. So
668.38|4.24| you can see here two and three, this is on the dimensionality,
672.78|3.8| or in fact, it's the numbers of numbers of values in each
676.58|3.52| dimension. So this would be a two dimensional array, because
680.1|2.84| there are two dimensions, there's a row and a column
682.94|7.12| dimension. So this would be the first and the second dimension.
692.06|3.6| So the number of indices and shape would be the number of
695.66|3.96| dimensions. And also, conveniently, you can also call
699.66|3.36| ndm, which stands for the number of dimensions, and it will also
703.02|5.2| return to two. So ndm is essentially the same as calling
708.22|6.92| length, sorry, link in Python, link on t dot shape. So it's
715.42|2.88| just a shortcut for doing that. So yeah, just wanted to briefly
718.3|4.64| highlight 10 source in the context of pytorch tensor flow
723.26|2.96| are the same as multi dimensional arrays in NumPy is
726.26|3.92| really the same concept. Yeah, and here's also just a nice
730.22|3.88| summary from the deep learning with pytorch book, where all the
734.1|4.68| terms are here at one glance, scalar vector matrix tensor. So
739.1|3.4| in this case, a 3d tensor, and here are higher dimensional
742.5|5.2| tensor. So n dimensional tensor, if yeah, so in this case, you
747.74|2.88| actually don't know how many dimensions could be arbitrary.
750.9|3.04| So it's also just making fun of it that this is something we
753.94|3.0| can't visualize in our head anymore. Because, yeah, as
756.94|2.64| humans, we can only really think of three dimensions with a
759.58|3.68| fourth dimension, that becomes all some gobbledygook here.
763.26|4.48| Here. And yeah, this is just a short summary here of what we
767.74|4.52| just discussed in the previous slides. And in the next video,
772.26|4.64| I want to briefly talk about more about tensors and pytorch.
776.94|3.2| So if this was just a little bit short, um, yeah, I will talk
780.14|13.52| more about this in the next video.