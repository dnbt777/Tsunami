start_time|end_time|text
0.72|3.94| Yeah, just to clarify how the mathematical model of a neuron
4.66|3.92| relates to these first logic functions is just a quick
8.58|4.7| overview. So you have drawn three tables and and or and not
13.28|2.74| table representing these different types of first or
16.02|5.42| logic functions. So how this works is you can think of x one
21.44|9.76| and x two as the inputs and as y as the output. So if both the
31.2|5.4| inputs are zero, the output is zero. If one of the two is zero,
36.62|3.64| then the output is still zero. And you have to have both inputs
40.26|3.1| equal to one to have an output of one. That's usually how an
43.4|5.88| end function works. For the or function, it's sufficient for
49.28|4.2| one of the inputs to be one to output a one. And the not
53.48|4.12| function is it's the inverse basic. So if the input is zero,
57.62|3.7| then the output is one. And if the input is one, the output is
61.32|3.88| zero. So here we are talking about binary values. So the
65.2|3.64| possible values are only zeros and ones here, like, like a bit
68.84|4.0| function, for example, like representing one bit, one bit
72.84|4.68| of information. So here, this relates. So this would be the
77.52|4.2| mathematical one way, a mathematical way to implement an
81.76|4.0| end function with analogies to this biological neuron. So we
85.76|6.2| have these inputs x one and x two, and then the output. So we
91.96|3.22| will revisit this in way more detail in the next lecture when
95.18|4.7| we talk about the perceptual models. So I mean, not in that
99.88|2.24| much more detail, but we will actually implement this also in
102.12|3.44| code in a way that it automatically learns weights to
105.56|4.06| make classifications here, it's just showing that it's actually
109.62|4.02| indeed possible to use this idea of the biological neuron to
113.64|3.9| implement such a function. And this would work by having these
117.54|4.34| inputs here. And then you integrate these inputs by
121.88|5.42| summing over them. So you would have here, sum over these
127.3|5.26| inputs. And then there's a threshold. So we can think of
132.56|4.24| the threshold as something you have to reach in order to fire
136.8|4.12| or not in order to relay a signal or not. So in that way,
140.92|2.88| it's basically you can think of it as a piecewise linear
143.8|5.88| function. So where it returns one, if the inputs, let's say x
149.68|4.24| one plus x two are greater than the threshold, let's say greater
153.92|8.04| equal to and zero. Otherwise, this would be our neuron here.
161.96|4.84| So there are also some weights. Notice that I set them to one
166.8|3.56| here. So then they're actually not doing anything. So usually
170.36|5.08| you would compute a weighted sum of the inputs. But we are not
175.44|3.52| worrying about it right here right now. So one would
179.0|3.8| basically say that the weights have no function here. So we can
182.8|4.0| actually ignore them here. So otherwise, instead of x one plus
186.8|3.8| x two, it would be the weighted input, it would be w one times
190.6|5.28| times x one plus w two times x two. But since the weights were
195.88|2.6| one, they are not doing anything. So in this case, we
198.48|4.4| can also ignore them. Later, we will actually talk about ways we
202.88|2.72| can actually learn these weights like parameterize the model.
207.36|2.84| Yeah, and then I don't want to spend too much time on this. But
210.2|3.36| if you like, you can then just plug in different values like
213.56|4.6| zero and zero, one and zero, zero and one and one one and see
218.16|4.5| what the weighted sum is, or the sum x one plus x two, and see
222.66|2.88| whether it's bigger or smaller than the threshold. And then you
225.54|5.24| can real or will realize that this will be implementing on an
232.1|4.0| end function. And similarly, you can implement an R function by
236.14|4.76| changing the threshold to point five. And you can also implement
240.9|3.84| a not function by for example, changing the threshold to minus
244.74|5.88| point four, nine, and having the weight of minus one. So you
250.62|4.84| would basically compute it like this. So you would have the
255.46|11.28| function as a return of one, if minus x one is greater than t
267.02|5.0| greater than equal on zero, if minus x one is smaller than t.
272.02|4.92| So this would be the not function. So this is already too
276.94|2.68| much detail, maybe, but this would be an example of how the
279.62|3.28| mathematical neuron model could represent and or and not
282.9|7.12| functions. Moving on. So in the previous slide, I talked about
290.02|3.12| the model, but we there was no way we could determine the
293.14|2.8| threshold automatically. So we would have to hand code the
295.94|2.36| threshold for specific functions. But now let's say you
298.3|3.64| are given a data set, and you want to learn a classifier. So
301.94|3.36| you would have to maybe try out a lot of these weights and
305.3|3.72| thresholds to find a good way to classify data. So one idea was
309.02|3.76| done by Frank Rosenblatt to develop a learning algorithm. If
312.78|3.2| I go back one slide, a learning algorithm that can find optimal
315.98|2.92| weights and thresholds automatically from the data to
318.9|3.08| make a good classification. So if we want to classify data, so
321.98|2.52| for example, if you want to classify spam and not spam
324.5|3.96| email, you could use, for example, a system that can learn
328.46|3.52| from data to find a good decision threshold. So this was
331.98|4.76| by Frank Rosenblatt, and only a few Lacey, one decade later,
336.74|4.72| approximately one decade after the McCulloch and pits neuron.
342.5|3.28| Also, I should mention there are multiple perceptron algorithms.
346.1|3.76| However, in practice, usually we say the perceptron algorithm. So
349.9|2.72| although there are multiple ones, so there's one popular
352.66|3.12| perceptron algorithm, and we will talk about this perceptron
355.78|3.2| algorithm in the next lecture in more detail, and also
358.98|4.04| implemented in code. So but yeah, here's just a quick
363.02|4.28| overview of how this works, and how it looks like. So yeah,
367.34|4.12| similar to the previous slide, we have multiple inputs. There
371.46|4.84| are also these weights, and they get combined. So this is a
376.34|4.44| weighted sum here at this point. So it's a people call it a net
380.78|3.6| input function. And then there's an activation function. This is
384.38|3.2| basically our threshold that I introduced in the previous
387.62|4.44| slide. And then it will produce an output. So zero or one, we
392.06|2.96| will again talk about this in way more detail. So it's just a
395.02|3.68| quick overview. And here would be Yeah, if you're interested,
398.74|2.8| this would be how it actually looked like in practice, because
401.54|3.4| back then, um, yeah, computers were quite different. So it's
404.94|5.36| actually a physical machine, and people had to plug in wires to
410.3|3.44| make it work and rearrange wires and stuff like that. So yeah,
413.74|5.16| we've come a long way with computations. Alright, and then
418.94|3.64| also, after the perceptron, we are still talking about single
422.62|4.8| layer neural networks. After the perceptron, there was the so
427.42|5.8| called edeline, which stands for adaptive linear neuron, by
433.22|4.92| Widrow and Hoff in 1960, it's only three years later. And what
438.14|4.4| is different between the perceptron and the edeline. So
442.54|4.64| this one is now differentiable neuron model. So that changes a
447.18|3.84| little bit how we learn on the weights. So it's a little more
451.02|3.16| convenient to learn the weights, because now we can use calculus
454.18|3.36| to learn the weights, we will see next lecture, how this
457.54|2.56| learning algorithm works. And then in a future lecture, we
460.1|3.58| will also talk of course, about gradient descent, like using
463.68|4.62| calculus to learn the weights. So here's just our quick last
468.34|4.04| overview of this for this video. So this is the perceptron I've
472.38|3.48| shown you. And now the edeline is actually very similar. So it
475.86|4.96| is shown here at the bottom. And here, the only or the main
480.82|4.2| difference is that there is no linear activation function. And
485.7|4.24| so in the perceptron, you do a classification, then you get an
489.94|4.26| output here. And then based on the error, you compute the error
494.2|4.1| by comparing this output to the true label. So you have a true
498.3|5.48| label. And you, you compare the two. And based on this, you can
503.78|3.28| see whether you make an error or not. If you make an error, you
507.06|5.0| go back and update these weights. So for the edeline, the
512.06|4.08| difference is, you have this update before you have this
516.18|3.76| threshold function before you compute the actual output. And
519.94|3.52| I have a question here, it says, does this figure below remind
523.46|3.48| you of something you know, from other statistics classes? And by
526.94|4.16| that, I mean, if you only take a look, let me use a different
531.1|3.76| color, let me use the yellow color here. So if you only look
534.86|4.2| at this part here, if you don't look at the threshold function,
539.3|4.36| if you only look at this part, does this one? Yeah, remind you
543.66|3.2| of something. So maybe that would be a good question for
546.86|4.44| Piazza. If you know, something from a statistics class,
551.5|2.68| probably from a very introductory statistics class,
554.18|3.24| that reminds you of this structure. Yeah, maybe post and
557.42|6.6| Piazza, and we can discuss this further. Alright, so lastly, why,
564.58|2.96| why do we have deep learning nowadays? Why didn't we stop now
567.54|3.52| with perceptrons and edeline? Because apparently, we have no
571.06|4.16| classifiers that can be easily parameterized. Well, the problem
575.22|3.84| with these is that they can only learn very simple decision
579.06|4.16| boundaries. So you can only learn so called binary decision
583.22|5.0| boundaries. So a binary decision boundary is a decision boundary
588.42|3.08| that splits a data set into two halves. So if we have a
591.5|4.56| classification problem, let me sketch this here up here. So if
596.06|4.16| we have a classification problem with two features x one, and x
600.22|5.08| two, and one class is let's say these circles here. And the
605.3|5.28| other class are these plus signs here. And I want to classify
610.58|3.84| them. So while we can train a binary classifier, and it might
614.42|3.08| learn a decision boundary that looks like this year, and
617.5|3.64| everything left will be classified as a plus. And
621.14|3.68| everything to the right will be classified as a circle. So this
624.82|3.76| is a binary decision boundary. But now if we have an, for
628.58|6.4| example, x or problem, so x or is an exclusive or, and it might
634.98|5.2| look like this. So here, I have two classes here, I have minus
640.18|4.04| minuses and pluses. So there are these minuses and pluses. But
644.22|2.84| look at how they are arranged, they are kind of like a range
647.06|4.6| like, like an x here, right, you can see that. So a binary
651.66|3.12| classifier would not be able to solve this problem, because a
654.78|4.04| binary decision boundary, you can draw it maybe like this. But
658.82|2.88| then, if we draw it like this, we make a lot of mistakes,
661.7|3.16| right, it gets these minuses right to the left, and
664.86|2.12| everything to the right, let's say is a plus, but then it gets
666.98|3.08| these here wrong. So that's a problem. Another way we can
670.06|3.72| draw this decision boundary might be like this, let's say
673.78|3.64| like this. But again, we make mistakes here. So there's no way
677.42|2.32| if you try it out in practice, if you try different
679.74|3.4| combinations, there's no way we can classify these points here
683.14|4.08| correctly, using a binary classifier. And there was
687.22|4.8| actually a book called perceptrons. I would have brought
692.02|2.8| this to class if we had an important person class and pass
694.82|3.64| it around. It's actually a very nice book. I have a used copy of
698.46|5.24| it. It's from 1969. And it was written by Minsky and Puppert.
703.98|3.8| And this was actually very negative. It's a nice book, of
707.78|3.08| course, like, the way it's written is nice, but the message
710.86|3.0| is like very negative towards perceptrons. It's basically
713.86|3.64| saying, perceptrons, and for example, the airline could not
717.5|2.76| solve these X or problems. So they are very limited. And they
720.26|5.84| are probably not the goal in AI. So we still need to develop
726.1|3.78| better methods. So this was really like dismissing perceptrons
729.88|3.12| and airlines at not useful, it's not useful in practice, because
733.0|2.58| they couldn't solve very useful problems, because they're
735.58|3.18| limited to these binary binary decision boundary, and started
738.76|4.2| this so called AI winter where people kind of lost interest in
742.96|3.68| neural network research. However, here things are
746.64|4.44| actually not that bleak, because there are ways we can actually
751.44|4.32| develop new networks that can solve the X or problem. And I
755.76|2.44| will talk about this in the next video.
759.54|3.9| Alright, let's start with the artificial neuron. So the single
763.44|4.16| layer neural network, yet all goes back to McCulloch and
767.6|4.92| pits, the neuron model they developed around 1943, which is
772.52|3.68| the mathematical formulation of a biological neuron that could
776.2|6.6| solve and or, and not problems. So these are first order logic
782.8|5.12| problems, or functions. And you have maybe heard about them in
788.44|4.88| introductory computer science classes, on first order logic,
793.48|4.72| or in mathematical classes, so the fundamental and or, and not
798.22|4.3| building blocks. So a biological neuron, you don't really have to
802.52|3.68| know about that, because deep learning and neural networks
806.2|3.7| were inspired by how the human brain works. But yeah, to be
809.9|3.38| honest, they work quite differently from each other. So
813.28|3.76| you can also think of it as, let's say, a submarine and a
817.04|4.68| fish. So humans were inspired how a fish can dive underwater,
822.02|3.02| or go underwater. And so they developed on submarines, which
825.04|3.12| can do the same thing. However, a submarine works very
828.16|2.36| differently from a fish overall. I mean, there are some
830.56|3.24| analogies. However, of course, the submarine is very different
833.8|4.72| from a fish or think about a bird and an airplane. So both
838.52|5.72| can fly, bird flaps its wings to fly airplane doesn't. So but
844.24|3.44| there are still some analogies. So airplanes are inspired by
848.08|2.96| birds, but they're not necessarily the same. And this
851.14|4.66| also applies, of course, to neurons and models of neurons.
856.28|4.32| But yeah, the goal of building an airplane is to build
860.6|3.62| something useful. And if you make it more like a bird, it
864.22|3.06| doesn't necessarily makes it more useful. And the same is
867.28|2.6| then also true for neural networks, we can maybe make them
869.88|2.48| more similar to a neuron brain, give them some properties that
872.64|3.16| human brains have, but it doesn't imply that they would be
875.8|3.16| better at solving certain problems, they might, but they
878.96|3.44| may not be. And also, to be honest, the real challenge is no
882.4|3.36| one really knows exactly how the human brain works. So we can't
885.76|3.6| really replicate it yet. But yeah, let me not get distracted.
889.36|3.54| And let's get back to the topic here. So just briefly about the
892.9|5.76| biological neuron. So the biological neuron looks as
898.66|2.74| follows. So this is, of course, a sketch, I actually made this
901.4|3.68| in PowerPoint a few years ago, which is why it doesn't look
905.08|3.2| very nice. And I can tell you, it's a lot of work to make a
908.28|4.44| drawing like that in PowerPoint. But yeah, the takeaway is that
913.04|3.92| there are some input signals here that are received by the
916.96|3.8| neuron. So you have these ten rights where input signals are
920.76|4.4| received. There's a cell nucleus, where some integration
925.16|2.76| of the information happens, some processing of the information.
928.28|4.28| And then this information is trans, transferred to the so
932.56|4.88| called axon terminal. So the signal comes in here, there's
937.44|5.0| some computation happening, and then it goes to the axon
942.44|3.28| terminal. So actually, it would jump, it's an electrical signal
945.72|3.86| here. But this detail doesn't really matter. What's important
949.58|6.14| is that this results in an output signal. And in a human
955.72|4.56| brain, for example, or in other types of brains of animals, the
960.28|3.64| neurons are connected to other neurons. So they are usually
963.92|2.88| like, there would be another neuron sitting right here
966.8|4.88| receiving these signals as input. So these output signals
971.68|3.48| would be the input signals of another neuron, and so forth.
975.16|3.24| But then this would be more like a multi layer neural network
978.4|5.12| here, we are just thinking about a single neuron. And of course,
983.54|3.18| also, there are many types of neurons in our brain. So there's
986.72|3.32| not only one type, here, we are just thinking of a very simple
990.04|4.08| version, where we have input signals, and one, let's say,
994.14|4.42| output signal. So we can think of whether the neuron is
998.56|3.36| activated or not, whether it fires or not. And with that
1001.96|4.88| concept, we can implement a so called and or or not first order
1006.84|0.48| logic.