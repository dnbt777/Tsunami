start_time|end_time|text
1.08|3.56| Alright, so for this video, I have a fun idea. So some people
4.64|5.12| complained that RNNs and LSTMs are not complicated enough. So
9.76|2.12| in this video, we are going to make them a little bit more
11.88|3.28| complicated. So in particular, we are going to talk about
15.36|3.52| recurrent neural networks with a so called attention mechanism
19.1|4.12| that helps it dealing better with long sequences when we have
23.24|6.36| tasks such as language translation. So just to recap
29.6|3.72| how language translation looks like. So this is a many to many
33.32|3.88| architecture for language translation. So we have an input
37.2|4.24| sentence and this input sentence get parsed gets parsed into one
41.44|5.92| hidden state. So this whole part is essentially encoding the
47.36|3.24| input sentence, which is why it's also sometimes called as
50.92|6.36| the encoder part of the RNN, similar to how you call the
57.28|3.48| first layers of an auto encoder, the encoder because it's
61.0|4.76| compressing the input into one, let's say hidden state. And then
66.64|8.24| we have this decoder part of the RNN, which takes in this hidden
74.88|5.96| state and then produces the translated sentence. If you're
80.84|2.8| interested in playing around with an example, I haven't made
83.64|3.62| one for this class, but there's an excellent tutorial here on
87.26|6.22| the pytorch website that you can check out. But before I show
93.48|3.44| you how the attention mechanism works, let me give you an
96.92|3.32| example of a language translation task. So here, I'm
100.4|4.0| translating one input sentence to an output sentence. So the
104.4|3.76| input sentence is the English sentence, today is a great day.
108.64|5.12| And I'm translating it to heute ist ein großartiger Tag. So I'm
113.76|3.14| not sure if you can guess which language it is, maybe a fun
116.9|4.5| question for Piazza. In any case, one thing in this
121.4|3.16| particular sentence is that it actually translates word by
124.56|3.88| word. So if you would take a dictionary, you could
128.44|4.76| technically just translate it, oops, word for word. So if you
133.2|3.16| have a sentence like that, you could almost use the many to
136.36|4.08| many RNN that we learned about in the previous lecture, the
140.44|10.08| on one where we have the inputs, then the hidden states, then the
150.52|6.78| outputs. And we technically could just have the setup like
157.3|6.96| this, like a many to many setup where we are translating word
164.26|6.16| by word. But this doesn't work for all sentences. So this is
170.42|6.66| why we have this delayed setup where we usually don't have
177.08|9.24| these parts. And this one goes into the decoder. And the decoder
186.32|3.2| then produces the outputs just based on the last state because
189.64|3.48| for some sentences, there's not this one to one correlation
193.12|3.08| between input and output word. So for instance, here's another
196.24|3.32| example sentence. It's if you have ever studied a foreign
199.56|2.6| language, you have probably encountered a false friend at
202.16|4.48| some point. And here, this is on the translation. So one thing
206.64|4.28| that happens is, for instance, this one, these two words become
210.92|5.36| one word, it's called Fremde Sprache here. And another thing I
216.28|5.48| can spot here is that the youth you have, and here also, it
221.76|8.52| translates one time to this word. So actually, the
230.28|6.28| combination of these two, which are farther apart. And then for
236.56|6.48| this one, there is no corresponding word really. And
245.88|4.16| this one corresponds to this one. So in this way, here, it's
250.04|4.24| not so obvious, like we don't have this one to one mapping. So
254.28|3.76| things might be shifted a little bit around in that sentence,
258.04|4.08| depending on the grammar. So it's not super straightforward
262.12|4.68| to use an architecture, like the original one that I had before
266.8|4.3| here, because we can't just map input to output, which is why we
271.1|4.3| have this setup, this many too many setup where we have the
275.4|3.8| input sentence that gets parsed into this hidden representation.
279.2|3.24| And then we have something that creates the output. So the
283.16|7.24| encoder and the decoder network. However, then one challenge is
290.4|4.48| really that the network has to compress all the information
294.88|2.92| into this one hidden state, right. So essentially, it's like
297.92|2.72| reading the whole sentence here, it's reading the complete
300.64|3.96| sentence. And after reading the sentence, it's starting to
304.6|3.36| translate. So how do we make sure that the network even
307.96|3.68| remembers, right? So if it reaches this point, it has to
311.64|3.28| contain all the information of the whole sentence. And this can
314.92|3.24| be actually quite challenging. I mean, even for instance, for
318.16|4.14| you, if you think about a sentence like, like this, it's
322.3|3.26| maybe easy, because it's just four words, so you can memorize
325.56|3.16| them and then translate them. But let's say you have a longer
328.76|4.0| sentence like that. And I read this out loud. And then I tell
332.76|2.24| you in one minute, you have to translate it, but you're not
335.0|2.66| allowed to look at the whole sentence anymore. So in that
337.66|3.86| way, I think also you would have a challenge memorizing all the
341.52|3.04| words in that sentence, because it's a lot of words. So the same
344.56|3.48| for the RNN, it will probably be challenged to have all the
348.08|3.18| necessary information in this hidden state, the longer the
351.26|5.6| sentence becomes. So this is why researchers worked on this so
356.86|4.42| called attention mechanism to address this issue of having
361.28|7.2| poor performance on long sentences. So here, this is
368.5|6.9| going back to the paper by Badeno and co workers. And as
375.4|3.8| far as I know, this is the first paper that really proposed this
379.2|2.0| attention mechanism, but I may be wrong, there may have been
381.2|2.84| other papers, but this is at least the one, the first one I
384.04|6.8| am aware of. And the key idea here is essentially that it's a
390.84|4.88| mechanism that allows a model to automatically soft search for
395.72|4.72| parts of a source sentence that are relevant for predicting a
400.44|5.8| target word. So if I go back one more time to my sentence here,
406.44|2.92| so let's say it's currently at that point, translating this
409.36|6.52| sentence, oops, it's allowed to look like in the original
415.88|5.52| sentence, which words are most, most important sets, it has
421.4|3.28| access to the whole sentence at each time step, essentially,
424.68|3.2| that's the idea. And some words are more important than others.
427.88|4.8| So for instance, this might have a very low attention like zero.
432.96|4.56| And this one is kind of relevant, it has maybe attention
437.52|3.32| close to one, if we have an attention value between zero and
440.84|3.12| one. So we have high and low attention for different words.
443.96|5.2| So at each time step, the model will be allowed to take a look
449.2|2.92| at different parts of the sentence. That's like the new
452.12|7.44| idea here. And at the bottom here is an illustration of how
459.56|2.68| they evaluated the performance. So there's something called the
462.68|4.16| thing it's called blue score. And this is a score for
466.84|4.12| computing how good the quality of the translation is. So we
470.96|3.36| won't go into too much detail of how that works. For here for
474.32|4.44| this lecture, just assume a higher blue score is better. So
478.76|6.92| this is better if it's high. And what you can see here is the
485.68|2.8| sentence length. So they did experiments with different
488.6|6.24| sentence lengths. And you can see that for these two networks,
494.84|6.4| networks, these are abbreviated RNN and 30 and 50. So these are
502.28|4.72| on these are essentially encoder networks like regular, they're
507.0|3.84| actually traditional RNN networks. So it's just like a
510.84|5.96| shortcut for these networks. And the 30 and 50 is how much access
516.8|7.4| they have to the input, I think. And you can see that the
524.2|4.74| performance drops, drops dramatically for sentence
528.94|4.38| lengths larger than 30. So you can see it gets good performance
533.32|3.96| in this region. But if you get longer sentences, longer than
537.28|5.88| 50 words, then the performance declines. But when they use this
545.56|4.6| tension mechanism here, they get good performance even for longer
550.16|6.76| sentences. So here, the takeaway is that they find that the
556.92|4.28| performance for longer sentences is better if they use this so
561.2|2.96| called attention mechanism. So how does the attention
564.16|2.48| mechanism work? That is what I will show you in the next couple
566.64|4.56| of slides. Yeah, so as I mentioned before, for each word,
571.2|4.16| there will be a certain context provided. So the network will be
575.36|3.84| allowed to look at the input sentence and see which words are
579.2|4.92| important for translating a given word. So summarize, it
584.12|3.6| would be assigning an attention weight to each word, so that we
587.72|3.68| know how much attention the model should pay to each word.
591.84|2.4| So for each word, the networks learned learns a certain
594.24|2.68| context. So what is for this particular word, what is the
596.92|3.36| context of words that is relevant for translating this?
601.88|3.4| So here's a figure from the paper outlining the whole
605.32|3.6| mechanism in one slide. So one thing to notice is that there
608.92|4.84| are two RNNs. So this is all my annotation, but this is what I
613.76|5.04| got out of this figure. So there are two RNNs. First of all, they
618.8|3.48| have a bidirectional RNN. We haven't talked about
622.28|3.64| bidirectional RNNs. But it's a very simple concept. It's just
626.16|3.84| running the recurrent neural network forward and backward, or
630.0|3.04| you can also think of it, running the recurrent neural
633.04|5.64| network twice, one time in the regular order and one time by
638.68|7.28| having the sentence put in in the reverse order. So if we
645.96|5.68| have the sequences, or the input sentence, x one to x t, this is
651.64|6.08| our input sentence. So one RNN runs this forward like a regular
657.72|4.28| RNN from x one, x two, x three, and two x t. So it produces
662.0|2.4| these hidden states corresponding to it. And then
664.4|4.56| you can also have the same concept running backwards. So
668.96|3.68| you just reverse the order. So this is shown here at the
672.64|5.0| bottom. So you start with x t, when you go to x three, t, two,
677.68|4.8| and one, so you're just going backwards, essentially. So yeah,
682.48|4.68| this is a bidirectional RNN. It produces these hidden states. And
687.16|2.6| from the hidden states, there will be these attention weights
689.76|3.08| that will be computed, I will show you how that works in the
692.84|3.32| next couple of slides. But here's just the overview. So we
696.16|3.2| have a bidirectional RNN, then we compute these attention
699.36|6.2| weights. And these go into our RNN that does the translation
705.56|4.08| now. So I call this a regular RNN because it's not
710.08|5.08| bidirectional. It's, it's more like a regular RNN works like we
715.16|5.84| talked about before, except now that it also receives these
721.0|3.4| attention weights as input. So not only the attention weights,
724.6|4.04| the attention weights weighted. So here in this case, the
728.64|4.68| attention weight weighted with this, with this stuff here. So
733.32|3.92| with this hidden state, I will show you how this gets computed
737.24|7.44| in the next couple of slides. And then yeah, it also receives
744.72|2.88| the hidden state from the previous slide. So here, this is
747.6|4.04| a maybe a little bit confusing, but it's the S, the S is just a
751.64|3.8| letter that they used to denote the hidden state of this other
755.76|3.28| of the second RNN, because here, we already use the word, the
759.04|2.84| letter H, and they didn't want to use the same letter, I guess,
761.88|3.08| for here and here, because then it would be a little bit also
764.96|5.68| confusing. So here, s is also the hidden, hidden state, but
770.64|3.76| now the hidden state of the second RNN. And then these are
774.4|4.84| the translated words. So here in this illustration, I'm trying
779.24|5.28| to simplify or at least try to explain what's going on in the
784.52|3.32| previous figure in a little different way. So I haven't
787.84|3.84| mentioned before what we do now, with the hidden states of the
791.68|2.88| bidirectional RNN. So when we have the bidirectional RNN, I
794.56|3.56| mentioned, we are running it forward and backward to obtain
798.12|3.76| these hidden representations. But now we have two sets of
801.88|3.08| hidden activations, one from the forward pass, let's call it F
804.96|4.28| one. And at this point, and then we also have the backward one,
809.24|3.92| let's call it B one. So how do we combine the two? So in
813.16|3.52| practice, it's very simple, we just concatenate those. So we
816.68|3.44| have just a hidden state, it is twice the size of a regular
820.12|2.56| hidden state from just the forward pass, because we are
822.68|3.24| just concatenating those. So the concatenated, then let's call
825.92|5.76| that h one, this is our hidden activation. And here, here, I'm
831.68|4.44| trying to illustrate how the attention mechanism works, it
836.12|4.04| combines multiple things, it combines these hidden states
840.96|4.96| from the bidirectional RNN. And the activation, sorry, the
846.24|3.96| attention weights. So these are the attention
854.72|1.48| weights. And these are the hidden
857.48|1.0| activations
858.48|8.88| of the bidirectional RNN. And this is the hidden activation of
867.36|15.92| the let's call this decoder. Oops, decoder RNN. Okay. So for
883.28|5.2| a regular RNN, what happens is that we provide the original
888.52|3.04| word is input, if you think back of our word RNN at the very
891.56|3.6| beginning of this lecture, we would provide the word x one
895.16|4.36| here as input. And then we let's say predict the next word. For
899.6|2.44| the many to many one for language translation, we
902.04|3.08| wouldn't have any input here, we would just use the hidden state
905.12|4.32| from the previous time step when we are in the decoding part. So
909.44|3.76| here, what's new is compared to a regular word RNN, where we
913.2|5.16| get this x one, the word is input, we now take in a context
918.36|4.4| vector. So this context vector provides information about the
922.76|4.6| whole sequence, not just x one, the whole sequence, the whole
927.36|3.72| input sequence in a regular RNN, this would be encoded in the
931.08|5.04| previous hidden state. So if we it's time step one, this would
936.12|2.72| be of course zero. But now imagine we are let's say at the
938.84|3.8| fifth time step. So the fifth time step would combine in the
942.64|4.36| hidden state, or the previous four time steps. But it's like a
947.0|5.28| very compressed version, and information might get lost. And
952.28|3.44| for each word, also in the sequence, different other words
955.72|3.16| might be important. So it's kind of hard for a given time step to
959.14|3.46| really ensure that right now it captures the important
962.6|2.44| information for this current word, but then for the next one,
965.32|3.08| it captures other important information. So it's easy to to
968.4|2.32| forget what information was important from a previous time
970.72|2.6| step and so forth. So to solve this problem, we have this
973.32|3.28| context vector that allows us to take a look at the whole input
976.6|5.44| sequence. So to illustrate this again, remove this annotation,
982.04|7.36| we have this c one here, and this c one is computed by taking
989.4|4.48| all the attentions multiplied by each hidden state. So these
993.88|8.0| multiplied plus these multiplied plus these multiplied. So it
1001.88|3.72| might happen that a word is not very important. So in this case,
1005.6|3.0| if the word is not important, what would happen is that the
1008.6|3.48| tension weight would be let's say close to zero, then it would
1012.08|3.12| not let's say use this word. Other words might be more
1015.2|4.0| important. So the attention weight is larger. And here's how
1019.2|4.66| the context vector is computed. It's summing over the tension
1023.86|3.86| weights alpha multiplied by these hidden activations.
1027.76|4.48| That's how, how we compute this context vector. Now, how do we
1032.24|3.16| compute this attention weight itself? I mean, we talked about
1035.44|3.48| the hidden activation, right? So the hidden activation is just a
1038.92|3.88| concatenation of the forward and backward hidden activation. Now,
1042.8|4.68| how do we compute this attention weight. So the attention weight
1047.48|3.32| is computed by using another neural network, for instance,
1050.8|6.0| on multilayer perceptron. So let's maybe before we get to
1056.8|3.56| that, take a look at this current time step as one. So
1060.36|5.6| what does the current time step get us information. So it gets
1065.96|3.2| us information, essentially, this information from the hidden
1069.16|3.0| state, hidden activations from the previous time step. And then
1072.16|4.56| we also have this hidden activation from the current
1076.72|8.08| time step, right x one. So this is previous hidden activation of
1085.64|9.0| previous time step. And this is the hidden activation of the
1094.76|11.32| current time step. And this network here gets one takes both
1106.08|3.28| this input, the information from the current time step, and the
1109.36|2.72| information from the previous time step, and then outputs a
1112.08|12.8| score E, this is our un normalized attention weight. And
1124.88|4.08| this un normalized attention weight is put through softmax
1128.96|6.44| max function to normalize it so that the attention weights on
1136.36|3.94| sum up to one, right. So after softmax, as you are familiar
1140.3|3.42| with, um, we would have should be
1146.48|0.96| T, I guess.
1152.12|5.68| So they should sum up to one. And yeah, so this is how we
1157.8|4.4| compute these attention weights. And yeah, there might be larger
1162.2|3.52| and smaller attention weights, given how important each word
1165.72|4.28| is. So it's it's a form, the tension weight depends on both
1171.32|5.36| the current time input and the previous hidden state. So the
1176.68|2.52| tension weights might be different. If we look at a
1179.2|2.88| different word, if we have maybe attention weights, let's say
1182.08|8.6| that this is point 8.1.1 for the current word for this context
1190.68|4.16| vector here. It might be different if we compute C two,
1195.0|3.04| it might happen that this word here, the first one is not that
1198.04|4.08| important. Second word is more important, and so forth. So at
1202.12|1.8| each time step might be different words that are
1203.92|4.06| important. So but yeah, the bottom line is that this
1207.98|4.34| attention mechanism allows the network to kind of get
1212.32|3.52| information from the whole input sequence at each time step in
1215.84|2.64| addition to just this compressed information from this hidden
1218.48|4.72| state. Right, so to finish it up, here's another figure from
1223.2|3.62| the paper, where they visualize the tension weights. Since the
1226.82|4.5| attention weights are values between zero and one, my guess
1231.32|2.92| is the white ones here correspond to a high tension
1234.24|3.28| weight of one and the black ones here correspond to a low
1237.52|6.36| attention weight of zero. So I guess this is one, and this is a
1243.88|6.68| zero here. So here, you have, actually, no, I think they
1250.56|3.76| translated from English to French might be wrong, I might
1254.36|5.44| be misremembering. So let's say this is our input. And this is
1259.8|7.24| our output. And then you can see for each word, how much
1267.04|6.84| attention the network pays when translating. So when translating,
1273.88|3.92| let's say the L here, it pays most attention to the but also
1277.88|5.32| something to signed, and so forth. And you can see for some
1284.12|4.68| like, the number here, 1992, 1992, it really only pays
1288.8|5.32| attention, you can see that it only pays attention to this
1294.12|4.72| number, which makes sense, right. So in this way, what you
1298.84|4.32| can see is the strong value, attention value in the diagonal,
1303.48|3.44| which means that it's kind of like a one to one translation in
1306.92|4.6| that way. But not always, there are some cases where it pays
1311.52|3.72| attention to words that are also farther apart in that sentence.
1315.68|2.7| Right, so this is the attention mechanism. And in the next
1318.38|6.18| video, we will build on this idea by taking away the RNN part
1324.56|3.36| because it turns out that we just went from a very
1327.92|3.48| complicated model, the RNN added attention, but actually, we
1331.4|2.88| don't need the RNN at all, we can maybe also get good results
1334.28|14.56| with just attention. And that is the topic of the next video.