start_time|end_time|text
2.32|6.36| Yeah, let's talk about cats and dogs and custom data loaders. I
8.68|3.44| should say I just added cats and dogs to make this a bit more
12.12|3.36| interesting because I can imagine if you just read data
15.48|4.32| loaders or custom data loaders, it doesn't sound so exciting by
19.8|4.96| itself. So I was like using that just to get your attention. But
25.16|3.88| in any case, so here what I'm showing you is indeed cats and
29.04|4.14| dogs classifier I trained from Kaggle data set. So he had
33.18|4.1| trained a VGG 16 convolutional network that we will be
37.56|3.72| discussing later in the convolutional network section or
41.28|3.56| lecture. So here, this is, yeah, think of it as just a neural
44.84|3.96| network for the sake of having a model here that performs, yeah,
48.88|4.68| reasonably reasonably well on a more complicated data set. And
53.56|3.84| in order to fit this model, I downloaded this data set from
57.4|4.24| Kaggle, containing cats and dogs images, but I needed to create
61.64|3.16| a custom data loader for that. And in this video, I will show
64.8|3.32| you how you can create a custom data loader, I will be using a
68.12|2.6| simpler data set, though, because then you don't have to
70.72|4.44| download such a large cats and dogs data set, you will be or
75.16|4.5| you can actually get this though and download it. So I have the
79.66|2.4| code link here. If you're interested, you can download it
82.06|3.76| from here. Or here, at least have the instructions how to
85.82|3.86| download it. And I also have this model there. But I wanted
89.68|2.56| to before I show you the custom data loader, I wanted to make a
92.24|6.4| few more points. So here, I'm showing you the training loss
98.66|3.82| and accuracy. So actually, this should be the accuracy here on
102.48|5.76| this axis. Don't want to hide the 90 here. And let's focus on
108.24|3.04| the left hand side first on the cross entropy. So you can see
111.28|3.84| during training that the training loss goes down as
115.12|3.36| expected, this is something you want to see. But you can see,
119.36|4.36| I'm using a validation set. And for the validation set, for each
123.72|3.68| epoch, I evaluate on the validation set. And you can see
127.6|4.32| that here, the yeah, the loss does not go down. So at first,
131.96|3.28| it goes down, but then it stagnates. So in this case, we
135.24|2.2| don't make any further improvement on the validation
137.44|4.56| set while it continues to improve on the training set. So
142.0|6.36| here, we can see there is overfitting going on. So even if
148.36|6.24| I train longer, I may still not be able to improve the model. On
154.6|3.32| the right hand side, that's the same for accuracy. But yeah, the
157.92|3.16| accuracy is usually so you can think of it as the cross
161.08|5.4| entropy as our inverse surrogate for the accuracy. So it
166.48|4.44| behaves similarly here. So you can see the accuracy goes up,
171.24|3.96| continues to go up. That's maybe even Yeah, I would say maybe,
175.68|6.0| let's say 97%, even what you can see for the validation set, it
181.68|4.52| goes up and then it tends to stagnate. Maybe you're at just
186.2|6.04| say somewhere here. Let's say maybe 88%, something like that. I
192.24|3.44| then also evaluated the performance on a independent
195.68|3.68| independent test set after the training has completed on that
199.36|3.52| training test set, I also get 88%. So maybe approximately like
202.88|6.52| the validation set, which is kind of expected. So yeah, what
209.4|5.72| we can see here is extensive overfitting. And here, the
215.16|3.32| validation set gives us or an indicator of that. So we don't
218.48|2.96| have to use our final test set necessarily, we can already see
221.44|3.44| based on the validation set that there's overfitting. So the test
224.88|3.28| set should only be used ideally one time in the end, it should
228.16|5.56| be kept independent. So if you want to tune your model, you can
233.8|3.04| do this entirely on the training validation set. If you tune your
236.84|4.72| model a lot, if you change a lot of hyper parameters and do a
241.56|2.88| lot of tweaking, you may find that the validation set
244.44|5.68| performance is actually a little bit better on the training set.
250.12|5.0| And sorry, during training, so when you evaluate it, but then it's
255.12|2.88| not as good, it's better, actually, sorry, it's better than
258.0|4.44| the test set, because you will see that if you tune your model
262.44|3.6| a lot, you will also slightly overfit to this validation set.
266.2|3.8| Of course, you don't use your validation set for model
270.0|3.8| training, right? So you don't fit the model on that data, you
273.8|3.56| only use it to evaluate it during model training. However,
277.36|2.64| just by chance, you may end up picking a model that just
280.0|3.12| performs well on the validation set due to chance and then you
283.12|6.08| have this effect of overfitting. So in any case, the procedure I
289.2|3.52| outlined using training set validation set and test set for
292.72|4.08| the final evaluation is near the common approach in deep learning.
297.24|3.4| In regular machine learning, we tend to use k fold cross
300.64|2.0| validation, but it's a little bit too expensive for deep neural
302.64|5.28| networks. And also, because we have large data set sizes, like
307.92|3.72| usually large validation, and test sets, that's also usually
311.64|4.68| okay. Yeah, what is a good ratio when we use a training validation
316.32|5.96| and test set? I think, I mean, it's relatively important to
322.28|4.36| have a relatively large test set to get a reliable performance
326.64|5.8| estimate. Also, it's useful to have a lot of data, because we
332.44|2.68| have seen in the previous video, the more data usually the
335.12|4.2| better. So in that way, I would say, make the validation set the
339.32|4.04| smallest, it's still important, because it gives you an idea of
343.72|2.52| the model performance during training. But it's not as
346.24|3.2| important as let's say, the test set or the training set. So
349.48|3.4| personally, for example, I would do something like 80% training
352.88|5.4| data, 5% validation data and 15% test data. But you can of course
358.28|4.04| also change it, you can make it 85, five, and 10, or something
362.32|6.0| like that. So it really kind of depends. Also, there's no real
368.36|4.32| correct way of doing that. It's usually something approximately
372.68|3.76| around these values. So yeah, just to summarize, the training
376.44|3.12| set is used for training, and it is not necessary to plot the
379.56|2.24| training accuracy during training, but it can be useful.
381.92|1.96| So you don't have to do the plots during training, right.
384.32|5.36| But I find it useful to look at it. Because then I can see based
389.68|3.8| on the validation and training accuracy curves, how much I'm
393.48|4.12| overfitting. So the validation set here provides a rough
397.6|3.0| estimate of the generalization performance. It's kind of like
400.6|3.68| the test set. But because we use the validation set a lot, and we
404.56|2.68| choose hyper parameters such that the model performs well on
407.24|4.36| validation set, it's, it's not truly independent anymore. And
411.6|4.56| we have an optimistic bias here. So from the validation set, the
416.16|4.08| validation set would usually report a model performance that
420.24|5.64| is slightly better than the model would perform on truly
425.92|5.48| unseen data. Yeah, and like I said, the test that should only
431.4|3.76| be used once to get an unbiased estimate of the generalization
435.16|4.2| performance. So this is like really in model evaluation in a
439.36|3.26| nutshell in like a minute. So like I recommended in the
442.62|3.1| previous video, if you want to know more details, I recommend
445.72|2.72| the article I linked there, I will also link it again on
448.44|5.56| canvas. So here's how it looks like you don't have to make
454.0|4.68| plots. Also, usually when I train a model, especially if I
458.68|5.2| do that on a server, I just print these values like the
463.88|3.44| training accuracy and validation accuracy, and let it train and
467.32|4.8| then after training, I would print the test accuracy. There
472.12|5.92| are multiple tools that can help you to monitor model training
478.28|4.84| during, during training. So to take a look at these curves in
483.16|4.04| real time, it's yeah, it requires some setup. Because
487.2|3.0| yeah, we have so many important topics to cover in this class,
490.2|4.68| I won't go into too much detail. Because it's like, I would say
494.88|3.48| more like an engineering thing, like after like a software
498.36|3.64| engineering thing. So after you understood the basics of deep
502.0|4.0| learning and are familiar with pytorch, you can add more tools
506.0|4.16| to your tool belt and explore additional tools. I don't want
510.16|5.16| to cram too many tools into your tool belt right now you can. But
515.32|3.32| if you're interested, you can explore them on your own, like
518.68|3.32| after class or for your projects. So some tools are, for
522.0|6.36| example, that are nice ML flow. And there are others. And these
528.36|3.68| allow you also to plot on your performance values during
532.04|3.52| training in a plot interactively. There's also
537.6|5.64| tensorboard. And tensorboard is originally for TensorFlow, but
543.24|2.88| it's also compatible now with pytorch. And also a lot of
546.12|3.32| people use tensorboard. So you can maybe look at these two
549.44|3.24| tools. But of course, there are more. These are really only the
552.68|4.6| two that spontaneously come to mind. But if you are interested,
557.28|5.4| I can also share a list of more of those tools. In any case, so
563.04|4.68| now just before we get to the code in the next video, just a
567.72|4.6| few more things to mention there are parameters and hyper
572.32|4.68| parameters. So just to recap, parameters are parameters like
577.04|3.56| the weights and the biases in the model that are trained or
580.6|3.6| learned from the training data. So that's what the model learns
584.2|4.36| via backpropagation. However, there are hyper parameters, and
588.56|3.24| I haven't used this word yet. So I have to use this word, but I
591.8|3.72| haven't explained it yet. I think so hyper parameters are
595.56|8.28| you can think of them as tuning parameters. So students who have
603.84|5.24| taken 451 have encountered this in the context of k nearest
609.08|2.76| neighbors as the number of neighbors and so forth. Here we
611.84|4.2| have different hyper parameters. So here, these tuning parameters
616.04|3.64| are, for example, the mini batch size, the way we normalize the
619.68|3.72| data, for example, min max scaling standardization, just
623.4|2.76| dividing it by a constant, there are many different ways we can
626.16|4.24| normalize data. And hyper parameters are really parameters
630.4|4.16| you as the person who sets up the model, you have to choose
634.56|3.0| them yourself. And you have to try them out in practice and see
637.56|3.48| what performs better. There's no way let's say we can use
641.04|2.76| backpropagation to learn these. I mean, there are maybe some
644.16|3.76| tricks or something. But usually, this is something that
647.92|5.2| is set up by the person who implements the neural networks.
653.44|2.32| For example, the number of epochs can also be considered
655.76|2.64| as a hyper parameter or the number of hidden layers, the
658.4|3.8| morphin units, everything really that affects the performance of
662.2|4.16| the final model, the learning rate, to some extent, also the
666.36|2.92| random seed. So the random seed is something you probably
669.28|4.04| shouldn't tune. But there are sometimes random seeds that
673.32|2.8| don't produce good models, because the initial starting
676.12|3.16| weights are really bad. So sometimes, so usually, I
679.28|4.24| recommend, if, if you want to report the final performance of
683.52|2.84| a model, you present a model, I would recommend to run your
686.36|2.96| model at least three or five times with different random
689.32|4.24| seeds, and then average over the results. And then you can also
693.6|3.4| show the standard deviation or even confidence intervals. And
697.0|3.56| we have the loss function as a hyper parameter. And here,
700.56|3.28| various weights in terms of weighting terms, you can weight
703.88|2.64| certain examples more heavily than others in the loss
706.52|3.4| function, the activation function like sigmoid, a
709.92|5.88| logistic sigmoid, 10h, or relu, and so forth, regularization
715.8|3.4| schemes, we will talk about that in the next lecture, weight
719.2|3.08| initialization schemes and optimization algorithms. These
722.28|4.76| are all things we will cover in the next three lectures. So
727.72|4.64| yeah, there are really no good ways to choose these, I would
732.36|5.54| say. Maybe there are some ways now, but I would so based on
737.9|2.98| meta learning, you can train your model on different data
740.88|3.64| sets. And you can see what performs well over how how you
744.52|2.06| set up your model so that it performs well on different data
746.58|3.82| sets. But in the grand scheme of things, it's something you
750.4|4.04| still have to experiment with. So I'm saying it's there's no
754.44|4.92| kind of scientific explanation for why. Okay, no, no theory,
759.8|2.92| theorem, why certain parameters, hyper parameters should work
762.72|3.48| better than others. So what we have to do is we have to try
766.2|5.4| many things. And there's this joke, probably like, because of
771.6|3.46| gradient descent, people call this graduate student descent,
775.06|3.64| because graduate students usually, unfortunately have to
778.7|3.9| spend a lot of time tweaking these things. These hyper
782.6|4.52| parameters. Alright, so he has actually a nice visualization of
787.88|2.68| pytorch data loader, how it works conceptually, I just saw
790.56|2.84| it the other day. And I thought it might be fun to include it in
793.4|3.68| the video, because it's really nice summary of how things work.
797.08|3.24| So I saw this here on Twitter, the original link. But yeah,
800.32|6.32| let's just play the video here. So you can see. Sorry, let me
806.64|2.98| stop it first. Let me explain first. And then I start the
809.62|3.26| video. So on the left hand side, you are shown the inputs and the
812.88|3.14| labels in the data set. So this is your data set. Then there
816.02|2.92| are certain transformation methods, we will cover this in
818.98|3.48| detail when I show you the data loader in action. And there's a
822.46|5.52| sampler and a batch sampler. So the sampler samples one pair of
827.98|5.12| inputs and labels at a time, the batch sampler, yeah, samples them
833.1|3.52| for a batch, and then the collate function combines them to a
836.62|3.88| mini batch that we can use in the model. So let's play this
840.5|3.98| again. So you can see on the inputs enabled, go through the
844.48|3.14| transform and through the sampler and get collected in
847.62|3.08| this batch sampler. Once we have a batch ready, it goes to the
850.7|2.76| collate function, and it produces the batch of inputs
853.46|4.12| and batch of labels. And then it does the next batch. And you can
857.58|7.32| see here, it's sampled without repetition. So each sample is
864.94|4.32| used exactly once or so each pair of inputs and labels. And
869.26|3.56| then once we're finished, we finish the epoch, and then there
872.82|2.76| will be another epoch. So you can see they also chosen
875.58|6.48| randomly here. So it's basically equivalent to shuffling. So then
882.06|9.08| the last batch here. Alright, yes. So and then you would do
891.14|2.76| the whole thing again. But of course, you would choose them in
893.9|3.28| a different order. If you have, there's a parameter, it's called
897.18|2.72| shuffle. If you have shuffle enabled, it will choose them in a
899.9|4.8| different order then. Yeah, this is conceptually how the pytorch
904.7|4.4| loader works. So here's how it looks like in code. And yeah, I
909.1|3.36| actually, I think I should make a separate video and walk you
912.46|2.64| through this in the Jupyter Notebook. It will be a little
915.1|3.4| bit better to explain compared to walking you through it here
918.5|6.12| on the screenshot. So just to wrap up the slides before we go
924.62|3.64| to the last video of this lecture to the code example. So
928.3|4.2| we have now the good news that we can solve nonlinear problems.
932.54|5.36| That's great, right? However, now we have the bad news that is
937.9|2.72| that our multi layer neural networks now have a lot of
940.62|4.12| parameters. And yeah, it's easy to overfit the data. So in the
944.74|4.36| next lecture, we will talk about techniques like regularization
949.1|3.76| techniques to help prevent overfitting. So here's a
953.06|3.6| simplified example of how that might look like. So if we have,
956.98|3.44| for example, a model in the center here, that is maybe too
960.42|4.6| complicated and doesn't generalize well to new data, then
965.02|3.28| here on the right hand side, there is a model that is
968.34|3.44| slightly simpler, we can make it even more simple, like just as
971.78|3.14| linear decision boundary, but this is not sufficient here to
974.92|3.54| distinguish between these crosses and circles. So there's
978.46|5.96| usually a good compromise between model that is, let's say
984.46|2.64| overfitting, it has high variance or model that is
987.1|4.32| underfitting that has high bias. So regularization helps to
991.42|3.72| simplify decision boundaries in a certain way, if you think of
995.14|4.52| it as if you think about it visually. But yeah, we will talk
999.66|3.04| more about that in the next lecture. So in the last video,
1002.7|3.08| also the next video, I will show you the custom data loader in
1005.78|15.84| practice.