start_time|end_time|text
0.56|4.76| Yeah, hi, everyone. So today, we are going to talk about recurrent
5.36|3.4| neural networks. What are recurrent neural networks? Yeah,
8.76|3.68| these are a special type of neural network that can model
12.48|3.64| sequence data. So one popular example would be natural
16.12|3.56| language processing, where you can think of a document as a
19.68|3.46| series of words, or you can think of each word as a series
23.14|3.58| of characters or letters. So today, we are going to take a
26.72|2.44| look at the big picture of recurrent neural networks, how
29.16|2.62| they work. And at the end of this lecture, I will show you a
31.78|3.02| classification example, a document classification example.
35.64|3.6| So with that, if you recall, the title of this class was
39.4|3.8| introduction to deep learning and generative modeling. So with
43.2|2.76| this lecture, I hope to have finished the introduction to
45.96|3.48| deep learning part. So I'm pretty sure with that, you have
49.44|3.68| a very broad and good understanding of what deep
53.12|3.04| learning is and the different problems we can apply deep
56.16|3.6| learning to. And that will be like your fundamental knowledge
59.76|4.0| of deep learning. And then we will be taking this knowledge to
63.76|4.28| the generative modeling part, which will be starting next
68.04|3.44| week. So next week, we will be taking some concepts like
71.48|3.32| convolution layers, and later also the recurrent neural
74.8|3.44| networks to generate new data. In particular, next week, I'm
78.24|3.84| planning to cover auto encoders and variational auto encoders,
82.32|3.6| which are essentially specific types of networks for
85.92|3.28| generating data, and we will be using convolution layers to
89.2|4.28| focus on image data. After that, I will also talk first about
93.52|2.8| generative adversarial networks, which are very popular topic, as
96.32|3.56| you may know. And after that, we will be revisiting these
99.88|3.64| recurrent neural networks for generating new text data. So
103.52|3.68| here today, we are focusing on the big picture of recurrent
107.24|4.28| networks. And we will be focusing also on the
111.52|2.8| classification example that I will provide at the end of this
114.32|3.56| lecture, then in approximately one or two weeks, I would say
117.88|3.28| more like two weeks, we will be revisiting these recurrent
121.16|5.28| neural networks for text generation. Alright, so now you
126.48|3.52| hopefully know what's going to happen next. And, um, yeah, the
130.0|4.12| next element in the sequence is getting started with this
134.12|2.28| lecture, because there are plenty of things to talk about.
138.44|3.6| Yeah, so here are the topics I have in mind for today. So if
142.04|3.8| you're interested in text data, working with text, of course,
145.96|3.68| RNNs are not the only way you can work with text data. So I
149.64|3.36| will also briefly highlight some other ways we can use for
153.0|3.48| working with text data. But then after this brief overview, we
156.48|3.68| will dive more deeply into the RNNs, the recurrent neural
160.16|3.64| networks and to look at how they work for sequence modeling.
165.04|3.28| Then I will discuss different types of sequence modeling
168.32|4.72| tasks, because there's more than just text classification. And
173.2|3.28| then we will talk about backpropagation through time.
176.48|2.68| This is like a modified version of the backpropagation that we
179.16|3.04| already talked about in the context of multilayer
182.2|4.64| perceptrons and convolutional networks. Then we will talk
186.84|3.76| about the long short term memory. So these are specific
190.6|4.2| cells for recurrent neural networks that help with
194.8|6.76| processing longer sequences. So then we will talk about many to
201.56|4.88| one word RNNs. So this is just like a fancy way of saying that
206.44|4.32| we are working on looking at an example where we have a text and
210.76|4.44| we want to classify the text. So going from a sequence, which is
216.4|5.52| many words to one output label, and we will be using a word RNN
221.92|4.0| here. So there are also I will discuss that later, character
225.92|4.32| RNN. So character RNNs, your process one character at a time.
230.24|4.64| And here we will be processing one word at a time. And then I
234.88|17.28| will show you how we can implement those in pytorch.