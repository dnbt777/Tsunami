start_time|end_time|text
1.0|3.08| Yeah, hi, everyone. Again, lots of exciting things to talk about
4.08|3.64| today. So you may have noticed in the past that I've been
7.72|3.16| covering a lot of these big projects from companies like
11.12|3.6| Facebook AI research and Google AI research, I wanted to
14.92|3.4| emphasize, I'm not affiliated with any of these companies or
18.32|3.28| projects. It's just like these are big projects and are very
21.6|3.12| catchy. And also, that makes them sometimes very interesting,
24.72|3.68| which is why I kind of kind of try to keep up with what other
28.4|3.18| people are doing. And these are usually the ones that kind of
31.58|4.22| stick out. But I also try in the upcoming weeks to be more
35.8|3.04| selective, or also, let's say more diverse in terms of
38.84|3.84| covering both little and big projects that are interesting.
42.88|2.52| So today, I don't have a particular theme, I just
45.4|3.36| selected some things that came to mind or that I stumbled upon.
49.0|2.96| So little projects, big projects, a little bit of both.
52.24|2.84| So because there are lots of things to talk about today, let
55.08|2.48| me not waste too much time on this introduction and get
57.56|0.68| started.
59.6|3.52| Yeah, so the first project I want to talk about today is this
63.36|4.0| text box again, I saw on GitHub this week, as far as I am
67.36|2.88| concerned, and as far as the author is concerned, this is
70.24|4.2| also the first application of again, to generating new text
74.44|5.36| boxes. So here are some examples of how they might look like. So
79.8|3.52| why are we interested in that? Well, maybe you can use that to
83.32|3.4| design a new poster or something like that. But essentially, I
86.72|3.16| think it's just like a nice and simple application of a GAN for
89.88|3.88| generating some new data. So later in this course, we will
93.76|4.44| also be talking about GANs in more detail. So here, it's just
98.2|3.52| like an example of how a GAN might look like. And also this
101.72|3.28| GitHub repository contains a really nice description of how
105.0|5.04| this works. And it's really just a nice example project here. So
110.04|3.32| what is going on here, maybe just to briefly walk you through
113.36|4.68| this. So again, usually consists of two parts, there's a
118.04|4.64| generator and a discriminator. So the generator is essentially
122.68|4.56| trying to generate new data that mimics the data in the training
127.24|3.52| set. And the discriminator is the task of the discriminator is to
130.76|5.08| tell a part whether the generator generated fake data,
135.84|3.04| like data that is different from the training set distribution,
139.08|3.12| or data that is similar to the training set distribution. So
142.2|3.76| essentially, the generator will learn what tries to learn to
145.96|3.64| fool the discriminator, such that the discriminator cannot
149.6|4.8| distinguish between generated and real images. And in that
154.4|2.28| sense, you can think of the generator as learning the
156.68|4.64| training data set distribution. So here, there's like a slight
161.32|2.28| modification. I mean, again, it's usually a little bit
163.6|3.12| simpler. So here, in addition to that, so there are two things
166.72|3.48| going on, a normal GAN usually gets some noises input. So the
170.2|3.36| noise gets encoded, it's basically an vector that goes
173.56|2.7| into the network, and the network then generates the new
176.26|4.58| data. So why the noise, it's such that otherwise, I mean, you
180.84|3.2| need the noise, otherwise, the generator will always produce
184.04|3.32| the same output, right, if you think of it as a function. So in
187.36|2.84| that way, the noise is such that it will create different
190.2|4.4| outputs. And here, in addition to that, there is also the word
194.6|4.24| encoder, which takes as input a word. So this word will be then
198.84|6.28| included in this output image. So and to ensure that this word
205.12|3.88| is indeed included in this output image, there's also this
209.02|4.86| OCR module, which will judge whether this text here resembles
213.88|4.6| the text that was put in. So yeah, this is also why you can't
218.48|3.68| use this module here for generating, let's say, image
222.16|3.44| captures, because then, like these captures that are used for
225.6|3.44| verifying whether you are human, when you log into a website, I
229.04|3.2| mean, here, this wouldn't be useful, because I would say it's
232.24|3.68| too easy to solve, because the OCR is able to tell which word
235.92|2.8| it is, right. So in that way, you can simply design a robot to
238.72|5.24| fool, but to fool this capture generator. But yeah, anyways,
245.04|4.04| this is actually a quite useful technique to just add an
249.08|3.72| additional constraint here. For instance, a couple of years ago,
252.8|4.64| we also worked on face privacy, where we wanted to hide certain
257.44|5.56| face attributes. And we also in project called privacy, oops,
263.24|9.32| privacy, privacy net, we also designed again, that hides face
272.56|4.4| information, while still maintaining face matching
276.96|3.36| accuracy, or the same face matching accuracy, so that the
280.32|4.56| generated images are still useful in practice. But then, so
284.88|3.36| the goal was essentially to having face images still being
288.24|3.44| useful for, let's say, passport verification purposes. But then,
292.88|3.2| if someone captures images on a security camera, it shouldn't,
296.08|2.4| the person shouldn't be able to do some data mining on, let's
298.48|3.12| say, the gender of the person and so forth. So here, then we
301.6|3.68| use face metric in a similar manner. Anyway, so here, then
305.28|3.92| the discriminator judges whether the generated image is fake or
309.2|3.28| not. And essentially, this whole network will then learn how to
312.48|6.56| generate new text boxes. Yeah, so here's a slightly larger
319.04|3.44| project. I already wanted to cover it like one week ago, but
322.48|2.48| the episode was already too long. So I moved it into this
324.96|2.72| week's episode. But I think that is something worth talking
327.68|5.2| about. So this is like a large, really large model. It's called
332.88|3.52| m six, Chinese multimodal pretrainer. And this was a
336.4|4.48| collaboration between Alibaba and the Jinghua University. So
340.88|3.36| here, what they did is they trained, I think they use the
344.24|4.32| Megatron from Nvidia, they trained 1.9 terabytes of images,
348.64|4.96| or they trained on 1.9 terabytes of images, and 292
353.6|3.84| gigabytes of text. So it's a really large effort here. And
357.44|2.4| what's essentially new and interesting here is that it is
359.84|2.8| in Chinese and not English. So it's kind of interesting to see
362.64|3.6| that these language models also perform pretty well on other
366.24|3.12| other languages that are not English languages, because in
369.36|2.16| Chinese, they are also you probably know this better than I
371.52|3.2| do. But you have all these different types of characters.
374.72|2.88| So English text is I would say, much simpler, because you only
377.6|3.52| have 24 characters here, that's a little bit more challenging.
381.12|4.4| So it's kind of an interesting case study as well, I think. So
385.52|4.0| they trained actually two models, a 10 billion and a 100
389.52|4.8| billion parameter transformer. And so this was done with
394.32|4.2| a self supervised pre training. And then the pre trained model
398.52|3.28| can actually be used for many different tasks downstream. For
401.8|2.64| instance, the model can be used for generating descriptions,
404.44|4.36| doing image search for q&a, or poem generation, and yeah, many,
408.8|4.08| many different things. So just in a nutshell, I don't want to go
412.88|3.0| into too much detail. But how did they accomplish that? How
415.88|3.88| can they use the model on so many different downstream
419.76|4.16| tasks? So essentially, how they achieve that is by masking. So
423.92|3.88| they have the same model, they call it here, unified encoder
427.8|3.72| decoder. I'm not an expert in these large language models. But
431.52|3.72| I think this is based on Nvidia's Megatron. I've, I've
435.24|3.4| seen something similar before. In any case, so here, they have
438.64|4.04| like these different masking strategies. So for instance,
442.68|4.24| when they want to use the model for text denoising, they would
446.92|4.24| mask out all the gray parts here, which is the IP, they call
451.16|6.16| it IP, and DT, mostly. So but they maintain some DT. So what
457.32|6.08| is IP, ET, and DT. So IP are image patches, ET are encoder
463.4|5.12| tokens and DTR decoder tokens. So encoder is can think of it as
468.52|4.0| the input tokens, let's say text input tokens, and decoder are
472.52|5.28| more like the output tokens. So for text denoising, the model
477.8|5.12| gets decoder and encoder tokens. And let's say for language
482.92|3.76| modeling, there's only the decoder tokens. And for image
486.68|3.52| captioning, they use, of course, the image patches together with
490.2|3.64| the decoder tokens and so forth. So in this way, based on the
493.84|3.4| task, they use different types of inputs. So they have like
497.24|3.8| this masking strategy. So with that, they are able to train one
501.04|4.96| single model, essentially. Yeah, totally unrelated to the previous
506.0|3.08| project, I saw a very interesting project on archive
509.08|3.88| this week. So this project essentially highlights how
513.0|3.28| fragile deep learning can still be in practice. And then we have
516.28|2.36| to be a bit careful about certain things when we are using
518.64|3.36| it. So the project I'm talking about is actually not the
522.04|3.24| project on this slide, but on the next slide. But it reminded
525.28|3.28| me of this one that I saw about approximately almost a year
528.56|4.24| ago. So here, just to describe you what's going on here. So
532.8|4.64| here, the authors try to fool Tesla's autopilot system. So if
537.44|3.52| you haven't heard of Tesla's autopilot, it's essentially a
540.96|4.88| self driving car program inside the Tesla car, which can, to
545.84|3.2| some extent, automatically control the Tesla car like
549.04|4.2| steering it on the highway. I don't have a Tesla, I only are
553.24|2.32| vaguely familiar with it. But based on what I hear from
555.56|4.76| people, it's, it's somewhat okay, but it's, of course, not
560.32|2.88| something that you want to blindly rely on. And this paper
563.2|2.76| also highlights some of the issues with that system. I'm
565.96|3.04| not sure if this is already fixed. But in any case, so
569.0|3.28| what's going on here is that the authors, yeah, they try to fool
572.28|2.36| the autopilot system. So what they did is they projected,
574.64|4.8| let's say, street signs into trees. And that was essentially
579.44|3.16| fooling the system, thinking that this is actually a real
582.6|3.0| street sign. And you can think of I mean, of a real world
585.6|2.92| application, if there's some malicious actor, they could
588.52|3.96| maybe essentially project certain things and then cause
592.48|2.64| crashes and stuff like that. Or here, for instance, they
595.36|4.44| projected a silhouette of Elon Musk onto the street. And the
599.8|2.36| car was then thinking there's a person on the street and was
602.56|3.72| breaking pretty hard and things like that. So yeah, what I saw
606.28|2.92| in the archive was essentially an update of that. Or I think
609.2|3.48| these are different authors, right? Yeah. But it was
612.68|2.44| essentially a pretty interesting project where they did something
615.12|3.4| similar with laser beams. So here, they essentially
619.92|4.8| projected laser beams into the image. And by that, they could
624.72|4.72| also fool the cars essentially. So I think this one here
629.56|2.64| definitely takes more effort if you are, let's say a malicious
632.2|4.88| actor. And yeah, you want to for some reason fool the car. I
637.08|3.32| think having something that can project a street sign, you need
640.4|2.92| a projector, essentially, it's a little bit more effort to do
643.32|3.08| that. But something like a laser beam, having something like
646.4|3.04| that, that might be more concerning because these laser
649.44|3.44| beams, they are more, I would say, easier to carry around and
652.88|3.0| things like that. So yeah, that essentially highlights there's
655.88|3.28| still a long way to go for making self driving cars safe.
660.84|4.12| Yeah, related to the topic of safety. There's also another
664.96|4.04| important topic fairness. So how do we design fair machine
669.0|3.2| learning and deep learning systems? Yeah, Facebook had a
672.2|2.76| blog post on that topic this week called on the ground
675.0|3.28| applying algorithmic fairness approaches to complex
678.28|3.08| production systems. And yeah, in this blog post, there was also a
681.36|4.0| link to a research paper. It's a very relatively long paper, but
685.36|2.96| the recommended read, I think it's an important topic. So in
688.32|4.32| this paper, they outline the challenges and approaches they
692.64|3.92| take to making machine learning and deep learning fair. So it's
696.56|4.8| actually a pretty tricky problem that they have there. So I'm not
701.36|2.92| an expert in this area. But it seems like it's Yeah, it's not
704.28|3.8| so easy to solve. But yeah, one thing I wanted to highlight from
708.08|3.8| that is regarding label fairness, because in practice,
712.16|3.24| we usually assume that the labels that we have for a given
715.4|3.76| data set, that they are correct, or that they are the definite
719.16|2.92| ground truth labels. But yeah, in the real world, it's not
722.08|3.64| always so obvious, or not always so clear whether these labels
725.72|3.48| are correct, or whether we should take them literally, or
729.2|3.44| whether we should take them with a grain of salt. So for instance,
732.64|5.5| as they say, here's things like when you have websites, so you
738.14|2.66| can perfectly measure whether users click on a given button.
741.0|3.36| So if you want to measure or predict website clicks, website
744.36|4.04| clicks themselves are labels that are pretty, yeah, I mean,
748.6|2.96| pretty confident, or you are pretty sure if someone clicks on
751.56|2.2| that, you can measure this pretty confidently a click or
753.76|2.86| not. But other things, for instance, if you deal with
756.62|3.46| topics like identifying bullying, so the labels that
760.08|3.96| you may use for that, they are usually, for instance, generated
764.04|3.12| by a human who is labeling certain posts, whether they are
767.16|3.68| related to bullying or not. And because that's based on human
770.84|2.92| judgment, it may also embed human biases. So in certain
773.76|4.48| cases, yeah, whether a label is correct or not, it's really,
778.52|3.44| it's more, I would say subtle, it's there's also a gray zone
781.96|4.7| and things like that. So also, like they say here, there's
786.66|3.58| usually a policy written down to identify bullying. And it's also
790.24|2.92| important, like to have a good policy for the label us to
793.16|4.6| apply. And then but different people, yeah, apply the policy
797.76|2.86| maybe differently. And there are like these implicit and explicit
800.62|3.98| biases that label us have. So in that way, in certain in certain
805.08|3.2| contexts, it's actually not so simple, we cannot always believe
808.28|3.16| that these labels are the definite ground truth. So that
811.44|3.68| kind of makes certain topics, or applications for machine
815.12|2.48| learning and deep learning a little more challenging than
817.6|3.84| others. But yeah, related to that, what I wanted to mention
821.44|3.04| for your class project, what might be also an interesting
824.48|4.44| thing to do is to take a sample of your data set. So if you are
828.92|3.08| working on a classification problem, let's say you have a
832.0|4.68| data set of 100 images, or set, let's say, let's say 100,000
836.68|3.96| images, sorry, take, let's say 100 images, and then look at
840.64|4.84| these 100 images. And without looking at the labels, try to
845.48|4.56| predict what class label it is. And then you count the numbers
850.08|4.28| of times you were correct, and then divide that number by 100.
854.6|3.32| And then you get a feeling for what the human accuracy is on
857.92|4.48| that data set, how or how the human predictions relate to the
862.48|3.6| labels that are actually the ones contained in your data set,
866.08|4.0| it gives you a feeling of the difficulty of the task to. So
870.08|4.32| for instance, if you have the MNIST data set, take maybe 100
874.44|3.56| MNIST digits and try to break which number it is. And let's
878.0|3.28| see whether you get 100% accuracy or not. So it gives
881.28|3.8| you also an idea of whether the labels are even correct in the
885.08|6.76| data set, but also how difficult the task is. Yes, since we
891.84|2.96| talked about improving generalization performance this
894.8|2.8| week, and we will continue to talk about this topic. This
897.6|3.0| week, there was an interesting research article on
900.96|2.4| understanding generalization in deep learning from the
903.36|4.92| perspective of online and offline learning. So the title
908.28|3.0| of the article is good online learners are good offline
911.28|5.6| generalizers. So here they had two scenarios, a real world
916.88|3.08| scenario. So the real world scenario is essentially what we
919.96|5.08| have also always considered in class. So we have given training
925.04|4.96| set and we train a model on n training samples from that data
930.0|4.76| set where we have mini batch stochastic gradient descent. And
934.76|3.32| we run that for multiple epochs. So essentially, this thing is
938.08|2.86| just describing what we are doing when we are working with
940.94|4.34| a training set where we have, you know, where we do stochastic
945.48|2.84| gradient descent with mini batches. And we repeat that for
948.32|4.44| multiple epochs. But then they have another scenario, they call
952.76|4.68| that the ideal world. So here, instead of you're doing mini
957.44|2.88| batch gradient descent on the training set, instead of having
960.32|3.8| a fixed size training set, they have infinite data. So they are
964.12|3.22| drawing every time a new mini batch from the distribution of
967.36|3.5| new data. So they have an infinite pool of new data. And
970.86|2.78| they don't have epochs because the data never repeats, they
973.64|4.56| always draw new data. And here, what they're doing is they are
978.2|4.96| comparing how the real world compares to the ideal world. So
983.16|4.08| here, this is essentially illustrating that we once we
987.24|3.04| complete one epoch, we start from scratch, I mean, we do
990.28|3.64| another round and another round. So we reuse the same training
993.92|3.64| set for training in an ideal world, we always move forward
997.56|2.88| and have new samples. What they found was pretty interesting,
1000.44|3.56| actually, that there is actually no difference, whether we have
1004.0|4.28| the ideal world, or the real world case, in terms of the
1008.32|4.56| generalization performance. So both the ideal world and real
1012.88|3.8| world setting result in models that have the same performance
1016.68|2.44| on the test set. So they have a test set where they measure the
1019.12|3.68| performance then. And here, this is the number of iterations. So
1022.8|2.84| you can, it's hard to see, but you can see there are two, two
1025.64|4.0| lines here, a red line and a blue line. And blue corresponds
1029.64|3.88| to the real world scenario and red to the ideal world. And you
1033.52|3.68| can see there's virtually no difference. So there's one
1037.2|3.64| caveat, though, with that study. So one is how they generate
1041.32|4.4| generated the new data for the ideal world scenario. So here,
1045.76|6.16| they used a model to do that. So they used a model that draw or
1051.92|4.18| constructed 6 million synthetic cipher 10, like images by
1056.1|4.54| sampling from a certain generative model. And how did
1060.64|3.12| they then get the labels for that? They used another model
1063.84|3.4| that was used then to label these images. Here, they had a
1067.68|4.04| model with 98.5% accuracy. So yeah, I mean, this is an okay
1071.72|2.32| approach, because yeah, well, where should you get all the
1074.04|2.76| data from otherwise, right? But yeah, this is also a little
1076.8|4.8| caveat, because these are not real images, they are generated
1081.64|3.32| images that look like real images using a generative model.
1086.24|3.2| Any case, it's still an interesting study. Yeah, and
1089.44|2.84| another or another little thing I want to mention is, it's
1092.28|4.32| actually not the test set error, it's something called test soft
1096.6|3.52| error. So it's not a test of accuracy, but the soft error. I
1100.12|3.0| was a bit confused by that. I haven't seen that before. So
1103.12|4.72| they had a paragraph on that. So here, it's essentially what
1107.84|4.28| they call a soft accuracy of classifiers defined as a soft
1112.12|3.94| max probability on the correct label. So instead of using the
1116.06|4.92| arc max on the soft max, where in the soft max recall, we have
1121.28|3.24| class membership probabilities, they use the highest probability
1124.52|3.28| score and compute the accuracy that way as a soft accuracy.
1128.06|3.46| Honestly, I'm not exactly sure why they are doing that, why
1131.52|3.6| they are not reporting the regular test set accuracy. But
1135.36|6.64| yeah, that's that's an interesting point here. Yeah, and
1142.0|2.88| to ensure that this observation was not just an artifact,
1144.88|3.72| particular to this resonant model that they use, they also
1148.6|4.64| tried it with different models and saw the same effect. Yeah,
1153.24|3.48| one more visualization from that paper. So here, they also looked
1157.2|6.12| on at pre training. So what they did is here, they had a model for
1163.32|4.68| the ideal and real world scenario, and with and without
1168.84|3.2| pre training. So the one without pre training, this is like the
1172.04|3.4| random weight initialization, and pre training is essentially
1175.58|3.14| pre training here, the model on image net, and then using the
1178.72|4.2| weights and training it further on that cipher 10 data set. So
1182.92|4.88| what they found here is, if you look at, so the dotted line is
1187.8|3.92| ideal world, and the real world is the solid line. And in red,
1191.76|2.48| that is the random, it's a little bit hard to read this
1194.24|2.2| graph, to be honest, or not hard, but you have to think a
1196.44|4.32| little bit about it. So this is the random in it, and the blue
1200.76|8.0| ones are pre training. And then what you can see here is the
1208.76|6.28| dotted one is again, the ideal. And the solid one is the real
1215.04|2.92| world, you can see, for the random initialization, like
1217.96|3.84| we've seen before, there's no difference, really, whether we
1221.8|3.82| use the real world or ideal world scenario. And the same is
1225.62|4.26| true for the pre trained model, there's also no, but not, not
1229.88|4.4| much difference. However, what is interesting here, though, is
1234.32|3.56| yeah, of course, that pre training really helps. So this
1237.88|3.56| is the again, test soft error. And you can see that the pre
1241.44|3.04| trained model has an error that goes down much, much, much
1244.48|3.08| quicker than the one for the random tested. So it highlights
1247.84|4.52| that pre training a model on a larger data set first, instead
1252.36|2.4| of doing a random weight initialization, it's actually
1254.76|4.56| really good for getting good performance faster. Also, what's
1259.32|2.96| also interesting is that the final performance is also a huge
1262.28|3.26| gap. So it's not only training faster, but it also results in a
1265.54|6.3| better model here. Yeah, and related to pre training. So
1271.84|3.92| there was another interesting project called seer seer stands
1275.76|3.72| for self supervised. So pre training is essentially very
1279.48|2.96| similar to self supervised learning. So self supervised
1282.44|2.84| learning is a form of pre training in that sense. So on
1285.28|2.84| the previous slide, I showed you that they pre trained a model
1288.12|3.54| on image net. But there, they just use the labels that were
1291.66|2.82| contained in image net. self supervised learning is
1294.72|5.2| basically, yeah, it's like pre training. But you use a data
1299.92|3.36| set that is unlabeled, and then you generate the labels for that
1303.48|3.2| based on some information on the data set. For example, you can
1306.68|3.12| mask certain things in an image, or you can cluster the images
1309.8|2.74| and things like that. So we talked a little bit about
1312.76|2.52| self supervised learning before, it's a little bit beyond the
1315.28|3.2| scope of this class. So I mentioned for some class
1318.48|3.16| project feedbacks, that it might be something interesting for you
1321.64|3.28| to look into. But you don't have to, of course, because it would
1324.92|3.48| be more something more advanced. But in any case, this was an
1328.4|2.68| interesting project. So what they did here is they trained a
1331.08|4.16| billion parameter model using self supervised learning. And
1335.24|5.6| they used unlabeled data from Instagram. So doing that, they
1340.84|3.92| were able to reach a new state of the art performance for
1344.76|5.48| self supervised learning, getting 84.2% top one accuracy on image
1350.24|4.72| net. How did they do that? Um, yeah, they used online
1354.96|2.48| clustering algorithm, which is actually a pretty efficient one.
1357.44|4.22| It's called swath. And this one doesn't rely on pairwise image
1361.66|2.98| comparisons. But yeah, again, since this is a already very
1364.64|3.32| long blog post, not blog post, sorry, video, I don't want to go
1367.96|4.76| into too much detail, I will probably end this week's stuff
1372.72|2.16| in the news section. There's only one more thing I wanted to
1374.88|3.44| mention in connection to this project here. There is another
1378.36|5.44| interesting library or module, I would call it library that came
1383.8|4.76| out it's for self supervised learning benchmarks. So it's a
1388.56|2.8| library for self for state of the art self supervised
1391.36|3.66| learning, supporting pytorch. And it's essentially a library
1395.02|4.1| that provides benchmarks and pre trained models that you can
1399.12|4.32| compare with, let's say your models. So it's essentially a
1403.44|3.36| benchmark library that provides pre trained self supervised
1406.8|2.88| models. It's I think a nice thing if you are interested in
1409.68|2.52| self supervised learning, let's say for your class project, an
1412.2|17.28| interesting thing to check out.