start_time|end_time|text
5.279|5.561|uh today we're happy to have Nathan
8.12|6.08|Lambert a research scientist at the
10.84|7.439|Allen Institute for AI uh who focuses on
14.2|6.56|rlh FF and the author of interconnects
18.279|4.961|doai he'll be presenting a really cool
20.76|5.759|talk on aligning open language models
23.24|6.4|today so thank you for joining us
26.519|6.361|Nathan yeah thanks for the intro okay
29.64|4.919|this is a long time coming this is a
32.88|4.76|brief intro on why I'm doing this I
34.559|5.921|think generally since chat GPT you'll
37.64|5.079|see a lot has obviously happened but I
40.48|4.04|don't think it it's been a blur for me
42.719|3.761|as much as anyone else so kind of taking
44.52|4.679|the time to retell like what has
46.48|5.96|happened in this kind of fine-tuning and
49.199|4.801|Alignment space since chaty PT happened
52.44|4.08|is something that I thought was a worthy
54.0|4.8|undertaking so this is not really a 101
56.52|3.879|lecture but it will probably give you a
58.8|3.279|lot of context on why people are
60.399|3.641|mentioning certain things and what still
62.079|5.68|matters and what does not so hopefully
64.04|5.28|this is fun um I can see the chat I
67.759|3.161|don't know exactly if questions are
69.32|3.36|going to come to me or if I will see it
70.92|4.239|the whole time I think clarifying
72.68|5.56|questions are good maybe not discussions
75.159|4.401|the whole time and I'll try to keep sure
78.24|5.839|that there's time for questions at the
79.56|4.519|end so um let's get into
84.64|4.479|it um generally we're going to talk
87.439|3.32|about language models so everyone wants
89.119|3.801|to talk about these days is I need to do
90.759|5.201|some of the older history so I can talk
92.92|4.64|about recent history the place I like to
95.96|4.56|start is actually with Claude Shannon
97.56|5.32|who kind of had this paper talking about
100.52|5.199|approximating um arranging characters to
102.88|4.16|create language models um that's
105.719|4.161|probably why anthropic called their
107.04|5.719|models Claud that's not that's pretty
109.88|6.36|well known and a lot has happened since
112.759|7.561|these very early um papers on predicting
116.24|5.799|sequences of text and this is largely
120.32|3.68|built on this loss function which is
122.039|3.36|called the autoaggressive loss function
124.0|3.24|so if you kind of have this training
125.399|3.92|example where you have something like is
127.24|3.799|saw a and you're trying to predict what
129.319|3.881|comes after this the whole idea is that
131.039|3.961|there's going to be one correct token
133.2|3.24|that is the correct label and their
135.0|3.12|training loss is going to increase the
136.44|3.84|probability of that token and decrease
138.12|4.28|the probability of everything else this
140.28|4.4|very simple loss function classifying
142.4|4.96|which token to to use and actually
144.68|5.919|predict has enabled wild things and this
147.36|5.2|kind of took another turn in 17 when
150.599|3.761|this Transformer paper was born
152.56|3.12|attention is all you need everyone here
154.36|3.159|has heard about this it's a great
155.68|4.16|exercise to actually dig into what the
157.519|4.921|attention mechanism is doing not the
159.84|5.2|focus of this talk we'll quickly kind of
162.44|4.519|keep going in 2018 there was three main
165.04|3.64|things these are slightly out of order
166.959|4.081|um Elmo was the earliest one which is
168.68|4.96|contextualized world word embeddings in
171.04|4.839|the same year we also had gpt1 and Bert
173.64|4.599|released which is kind of the beginning
175.879|4.08|of core ideas on which modern language
178.239|3.441|models and Transformers were trending
179.959|4.2|towards and just getting these better
181.68|5.08|models training on large pre large
184.159|5.841|internet scaled corpa Bert was a
186.76|5.52|classifier gpt1 was generating text and
190.0|4.08|we kind of continue along these Trends
192.28|4.56|through the years gpt2 was when we
194.08|4.64|started learning about scaling lws and
196.84|3.959|if you use orders of magnitude more
198.72|4.159|compute the actual test loss will
200.799|3.681|continue to decrease in a linear fashion
202.879|4.241|with respect to the log
204.48|5.319|compute these ideas now are common place
207.12|5.28|when we talk about language models um
209.799|5.281|gbt2 also pioneered a lot of discussions
212.4|5.36|on releasing language models so gbt2
215.08|4.719|when it was first announced they were
217.76|3.64|holding access back because of the risks
219.799|4.8|of language models and this started a
221.4|4.72|lot of the conversations around um what
224.599|2.961|you should or should not release with
226.12|3.839|language models they eventually actually
227.56|4.48|released gpt2 and you could download the
229.959|3.36|models on hugging face and use them but
232.04|3.559|this is where that kind of conversation
233.319|4.28|around release strategies emerged in
235.599|5.241|2020 is when language models really
237.599|5.161|started to be noticeably good so gpt3 C
240.84|3.399|is when a lot of people are like whoa
242.76|3.199|this can actually do really interesting
244.239|3.601|things if I kind of create a really
245.959|5.081|clever prompt figure out how to give it
247.84|5.119|my information correctly and gpt3 could
251.04|3.6|do a ton of things with kind of this few
252.959|4.081|shot or multi-shot learning which is
254.64|4.119|when you give it a few examples in the
257.04|5.36|prompt and then ask it to do another
258.759|5.401|rendition of it and with this power came
262.4|4.0|many harms and this is kind of a
264.16|4.24|discussion of what are the risks of
266.4|3.88|releasing language models what types of
268.4|3.799|groups will be hurt by this
270.28|4.12|very important problems that kind of
272.199|5.641|culminated in 2021 with the stochastics
274.4|5.16|parrots paper which is arguing about
277.84|3.4|whether or not language models can be
279.56|4.72|too big is in the title but there's it's
281.24|5.239|a really a critique on how we should be
284.28|4.359|thinking about language models what are
286.479|4.0|the limits of them are they actually
288.639|3.681|doing the things like are they actually
290.479|2.921|thinking or doing any of these human
292.32|4.4|things or are they just kind of
293.4|4.96|following patterns in the data and then
296.72|3.72|just the year after after that this is
298.36|3.8|kind of like the it's like the tragedy
300.44|4.8|of sastic parrots as no one talks about
302.16|5.0|it now is that chat 2bt came the year
305.24|3.239|later and totally reshaped the whole
307.16|3.84|narrative around language models one
308.479|6.041|more time and this is really where we
311.0|6.639|start today's talk is like how does this
314.52|5.64|idea of alignment emerge in chatu BT and
317.639|5.161|then what happens after this so the
320.16|5.56|question that I ask myself is like or I
322.8|6.0|tell a lot of people is can chbt exist
325.72|4.8|without rhf and what we saw in the
328.8|4.48|release day so if go back and read the
330.52|5.2|actual open AI blog about rhf they list
333.28|4.56|all these limitations but they say that
335.72|4.0|rhf was an important tool to launching
337.84|3.32|chat TBT and the limitations that they
339.72|2.8|list are really the things that we're
341.16|2.64|still researching and that we're talk
342.52|3.28|about in this talk it's a great blog
343.8|5.16|post to go back to but a good way to
345.8|4.8|frame it is that rhf seems to be
348.96|3.56|necessary but it's not sufficient you
350.6|4.52|can't do something like chat PT or
352.52|4.799|gemini or Claude with a technique that
355.12|3.72|without something like rhf but it's not
357.319|2.88|the thing like pre-training is still
358.84|3.28|most of the work
360.199|3.641|but the fact that RF is needed is really
362.12|3.0|important to kind of contextualize all
363.84|3.799|these improvements that we've seen in
365.12|5.72|the open in the last 14 months or
367.639|5.4|so some examples that I like to site on
370.84|4.919|rhf being relied upon you can list many
373.039|4.6|more models here than I have um this
375.759|4.641|kind of this figure from anthropics
377.639|4.161|constitutional AI paper is the single
380.4|4.239|one that I go back to all the time
381.8|5.519|showing how just kind of using rhf can
384.639|5.241|get these more desirable behaviors from
387.319|5.201|their model in really dramatic ways so
389.88|4.319|these kind of Elo measurements aren't um
392.52|4.2|kind of calibrated so we don't know how
394.199|5.12|to compare llama 3 on this chart
396.72|4.479|compared to anthropics models but the
399.319|3.32|level of investment that anthropic has
401.199|3.0|had in these kind of techniques and
402.639|4.56|showing this kind of wide ranging
404.199|4.961|improvements of their models with rhf is
407.199|3.961|a kind of flag that we can follow to try
409.16|3.68|to learn how to do alignment with this
411.16|3.92|much precision and with this much kind
412.84|5.079|of impact as places like anthropic or
415.08|5.119|opening eye will have one such example
417.919|6.321|is just a simple quote from the
420.199|5.56|llama 2 paper which is kind of like the
424.24|3.92|colloquial way of reading this quote
425.759|5.321|which I will read is that whoa rhf
428.16|4.56|worked really easily and what the quote
431.08|4.36|is is meanwhile reinforcement learning
432.72|4.44|known from it for its instability seemed
435.44|4.199|a somewhat shadowy field for those in
437.16|4.039|the NLP research Community however
439.639|3.441|reinforcement learning proved highly
441.199|4.081|effective particularly given its cost
443.08|4.32|and time Effectiveness so this is one of
445.28|3.56|the biggest endorsements of rhf and it's
447.4|3.16|always fun for me because I came from
448.84|5.199|the RL side and then I've been learning
450.56|4.88|NLP but for NLP researchers to say these
454.039|4.0|things like yes reinforcement learning
455.44|4.439|is known for instability and but given
458.039|3.681|that is cost effective and time
459.879|4.76|effective for an RL person that's
461.72|4.8|shocking it's like RL has never been
464.639|3.921|particularly cost and time effective but
466.52|3.76|for in these language model domain where
468.56|3.639|we're fine-tuning with it rather than
470.28|5.359|learning from scratch to have people in
472.199|6.361|NLP that are saying this is just really
475.639|4.801|striking for how much impact it can have
478.56|3.68|and the timeline alignment and open
480.44|3.64|alignment is really like when do we see
482.24|3.28|these benefits like these benefits
484.08|3.48|didn't show up in models that people
485.52|4.84|were playing with for quite a bit of
487.56|4.599|time so this is kind of a little Atlas
490.36|4.0|I've thrown together I also made a
492.159|3.88|hugging face collection where I tried to
494.36|2.92|add all the models that I talk about to
496.039|3.481|it so you can actually click on the
497.28|3.96|models or try to use them if you're so
499.52|3.44|inclined of actually running the models
501.24|4.44|yourself it's just kind of another way
502.96|4.48|of documenting um the artifacts I talked
505.68|3.28|about and the artifacts that for me this
507.44|3.4|is a good review on like what What
508.96|4.559|mattered What mattered in this really
510.84|5.04|noisy journey in the last year of course
513.519|5.52|some disclaimers I'm not covering every
515.88|6.12|model since chat GPT this this little
519.039|5.281|plot of model icons could probably look
522.0|5.08|more like an exponential than this kind
524.32|5.28|of capped bar um and there's so much
527.08|6.68|history of NLP that people are building
529.6|5.919|on in the alignment space that is
533.76|3.56|totally swept under the rug here a lot
535.519|3.921|of academic and infrastructure
537.32|3.759|contributions that I'm not talking about
539.44|3.839|but are really important to kind of this
541.079|4.76|proliferation of fine-tuning
543.279|6.761|models so just kind of describing what
545.839|7.12|this image that I have here is um is
550.04|4.76|kind of summarize um some of these are
552.959|5.081|base models I'm not going to focus on
554.8|5.719|base models as much as fine-tuned models
558.04|4.6|the base models are extremely important
560.519|3.76|like none of this happens without llama
562.64|4.6|none of this happens without llama 2 the
564.279|5.881|base models are the Bedrock of this
567.24|5.159|ecosystem and then the alignment models
570.16|3.679|are what people the aligned models are a
572.399|2.641|lot of times what people can play with
573.839|3.24|and what you could try out what you
575.04|3.84|could do yourself on much less computing
577.079|3.081|infrastructure and all these things so
578.88|3.76|I'm going to talk more about the aligned
580.16|4.799|models but everything matters it's one
582.64|2.319|big
585.92|5.44|ecosystem um another thing that's not
588.399|5.12|fun but I'm going to do for the sake of
591.36|4.4|kind of flag posting no one really likes
593.519|4.56|listening to definitions um here are
595.76|4.16|some things that you'll hear thrown
598.079|4.121|around this isn't even all when talking
599.92|4.0|about quote unquote alignment I have
602.2|3.72|like here like alignment I've defined as
603.92|4.599|a general notion of training a model to
605.92|5.039|mirror a user's desires really with any
608.519|3.841|loss function it's not restricted um
610.959|2.681|there's other ter so like there's a
612.36|3.24|difference between instruction fine
613.64|4.319|tuning and supervised fine tuning
615.6|4.16|instruction fine tuning is about trying
617.959|4.0|to get a model that will respond to
619.76|3.96|queries formatted instructions while
621.959|4.44|supervised fine tuning is more about
623.72|5.16|learning a specific tasks capabilities
626.399|4.201|these get interchanged all the time like
628.88|5.12|that's okay it's good to know that
630.6|5.919|they're different and then two kind of
634.0|4.24|more ones I need to touch on and we
636.519|3.44|could go on even longer is reinforcement
638.24|3.839|learning from Human feedback there's
639.959|5.041|this multi-stage process it's it's a
642.079|5.841|specific tool for aligning ml models to
645.0|5.079|human data um it's kind of a class of
647.92|3.599|tools so it has some sort of you learn a
650.079|3.401|preference model and then you extract
651.519|3.401|information from it so there are so many
653.48|3.2|different ways to do it it's really an
654.92|3.88|approach and then there's a term that
656.68|4.04|I'm kind of trying to grow which is
658.8|4.96|preference fine tuning which could
660.72|4.359|Encompass rhf methods like Po but
663.76|2.92|there's the question of how do we
665.079|3.601|differentiate something like direct
666.68|4.839|direct preference optimization which
668.68|5.32|doesn't use an RL Optimizer from all of
671.519|4.841|rhf and I'll kind of come back to this
674.0|3.76|but it's good to have some common rounds
676.36|4.64|to build on because I might be going
677.76|3.24|through some of these things pretty
686.079|5.801|quickly this is a chapter that I cover
688.92|5.24|in one slide because it's really tapping
691.88|6.48|into a lot of different personal stories
694.16|7.4|it's hard to retell how crazy things
698.36|6.159|were when chat GPT dropped people were
701.56|5.16|not really losing their mind but there
704.519|4.841|was a lot of uncertainty on what the
706.72|4.48|future held
709.36|3.599|especially that it was clear that
711.2|3.72|language models were important but it is
712.959|4.32|not clear there's a lot of articles on
714.92|5.4|like titled we're going to reproduce
717.279|5.961|open chat GPT which you can't really
720.32|5.079|have a mo open model that does what a
723.24|4.32|closed product does there's a difference
725.399|4.401|between model weights and this product
727.56|3.8|that chat GPT represents but there is so
729.8|3.36|much excitement that everyone is saying
731.36|3.0|they're going to do these things and
733.16|3.76|trying to figure out the right
734.36|5.4|coalitions for actually doing so and
736.92|4.359|it's it's interesting this this delay is
739.76|3.16|kind of this land grab where people are
741.279|3.761|learning the basic things like what is
742.92|4.12|red teaming how like what is the
745.04|3.799|difference between a dialogue agent and
747.04|4.799|a predictive language model like what
748.839|4.601|tools should we use and everything kind
751.839|4.44|of follows from here with what people
753.44|4.12|are building but like personally I just
756.279|2.24|remember multiple meetings where like
757.56|2.8|people are like yeah you should do it
758.519|4.521|you should go try to build open chat GPT
760.36|4.479|and when you look back that goal is just
763.04|3.799|so wild that so many people are just
764.839|4.0|going like we need to we need to build
766.839|3.721|this thing in the open source and it's
768.839|3.12|just like it doesn't even make sense
770.56|2.8|because you can't open source a whole
771.959|4.961|system that
773.36|5.88|way but there are some things that make
776.92|4.56|a bit this makes a lot more sense which
779.24|5.2|is when things start to get grounded in
781.48|4.719|actual models so the first llama Suite
784.44|4.32|was released and I think in February I
786.199|4.121|have the date in some notes somewhere um
788.76|4.079|and then these instruction tuned models
790.32|4.84|started to show up on this first llama
792.839|4.841|model the first one to really crack the
795.16|5.52|narrative was this alpaca model and it
797.68|6.159|did a bunch of things that still are
800.68|5.48|used today so this was trained on 52,000
803.839|4.0|self- instruct style data distilled from
806.16|2.919|text venci 3 there's a lot in the
807.839|3.841|sentence I'll say what self- instru
809.079|5.2|struct means but this wasn't even data
811.68|6.159|generated from chat gbt it was generated
814.279|6.56|from one of open ai's API models so if
817.839|4.641|we talk about in this is all on how to
820.839|3.36|apply instruction fine tuning and this
822.48|4.52|is thing I mentioned on the definition
824.199|4.801|slide but really it's about making a
827.0|4.399|model that will respond to specific
829.0|4.639|styles of inputs what often happens at a
831.399|3.521|technical level here is that the model
833.639|3.681|is learning to integrate something
834.92|4.24|called like a chat template the ability
837.32|3.519|to include system prompts so you want to
839.16|3.08|tell you want the model to know it is an
840.839|2.401|agent you want the model to know what
842.24|3.08|day it
843.24|3.36|is excuse me you can do this in the
845.32|3.319|system prompt which is something the
846.6|4.4|user doesn't see but it steers the
848.639|4.88|behavior of the model and instruction
851.0|4.88|tuning is really where we make the model
853.519|3.841|capable of having these behaviors but
855.88|5.44|the question is like what data are we
857.36|6.96|training this behavior on so the most
861.32|4.48|common example is kind of um you
864.32|3.28|continue training with this Auto
865.8|4.599|regressive loss function on question
867.6|4.72|answer pairs so it's like what is a
870.399|3.88|Transformer and then you'll the language
872.32|3.36|model will predict an answer it could be
874.279|4.281|from stack Overflow it could be
875.68|5.48|something else and this example is human
878.56|5.44|data but what made alpaca in a lot of
881.16|4.76|these um early models and even today
884.0|4.6|really popular and accessible is by
885.92|3.96|using data to answer questions that is
888.6|4.56|generated by an
889.88|6.24|AI so this is where the kind of idea of
893.16|6.239|self- instruct data comes in self-
896.12|7.48|instruct was a paper from Al Ali and
899.399|7.201|udub in 2022 before chat GPT where
903.6|5.12|essentially the idea is how do we expand
906.6|3.679|on the distribution and instruction data
908.72|3.52|that we have this training data for
910.279|5.641|fine-tuning a language model without
912.24|5.599|getting more humans in the loop so um
915.92|4.56|what you really have to do is you start
917.839|5.641|with some high quality often human
920.48|5.0|prompts and then what we now see as more
923.48|5.12|common practice today but was very new
925.48|5.64|then is asking a stronger language model
928.6|5.0|create a list of prompts that are
931.12|4.92|similar to this but still diverse and
933.6|5.08|then once you have a list of prompts you
936.04|4.32|can use trap GPT or another model to
938.68|4.279|actually generate completions because
940.36|5.24|then what you have is a really big list
942.959|4.0|of question answer pairs but you don't
945.6|3.0|need to go through the bottleneck of
946.959|4.961|getting humans to sit down and write all
948.6|6.2|of them so what alpaca was really why
951.92|4.96|alpaca worked is because of kind of
954.8|3.839|realizing this and taking in this better
956.88|3.399|model from open AI so you can see this
958.639|4.44|figure here on the right is from the
960.279|5.0|alpaca paper or blog post one of the two
963.079|5.641|they took this model from open Ai and
965.279|6.281|they asked it to generate more tasks so
968.72|5.4|they had 175 to start and then they
971.56|4.24|ended up with over 50,000 kind of tasks
974.12|5.639|and they also generated completions from
975.8|5.56|this open AI model and um then what they
979.759|3.56|did is they took these meta weights that
981.36|3.52|had just come out and they instruction
983.319|4.64|fine tune them and then you end up with
984.88|4.56|alpaca this is kind of a pattern this is
987.959|4.161|a pattern that we've seen many times
989.44|6.36|with alpaca which is essentially you
992.12|5.079|take you you generate some data with
995.8|3.159|from a stronger language model and you
997.199|3.721|find tune on it it sounds so obvious
998.959|4.281|today but this was the first Model to
1000.92|5.12|actually release
1003.24|4.56|this I can now see questions coming in
1006.04|4.279|I'll I'll answer the ones that are
1007.8|4.039|clarifying and stuff like this so thanks
1010.319|2.88|for asking them and we can come back to
1011.839|3.92|more at the
1013.199|4.161|end once alpaca happened it felt like
1015.759|3.681|there was a new model every week the
1017.36|4.88|second model was vicuna
1019.44|7.239|and really what they changed was they
1022.24|7.04|added new sources of prompts to the
1026.679|5.4|distribution so you can see that I say
1029.28|5.679|share GPT they also introduced the idea
1032.079|4.641|of llm as a judge which is now obvious
1034.959|4.561|from a lot of their later evaluation
1036.72|3.92|work but let's talk about why Shar GPT
1039.52|5.12|was so
1040.64|8.72|interesting so Shar GPT was one of the
1044.64|8.399|only data sets that got open language
1049.36|7.199|model Builders so people like me prompts
1053.039|6.241|that were similar to what people um were
1056.559|5.36|asking chat gbt so what was happening
1059.28|6.32|was you would install this browser
1061.919|6.241|plug-in and it would let you share your
1065.6|4.439|prompts from chat gbt on Twitter or
1068.16|3.96|whatever so it was making it easier to
1070.039|4.561|share the prompts before in your
1072.12|5.439|conversations before open AI made a tool
1074.6|4.959|to do this and it now there's this legal
1077.559|3.641|gray gray area
1079.559|3.201|over the data set because most of these
1081.2|3.2|data sets are unlicensed and they were
1082.76|5.0|kind of created without consent or they
1084.4|4.92|were released without consent so there's
1087.76|3.56|a legal question on whether or not
1089.32|3.4|people should be training on this data
1091.32|3.599|but the fact of the matter is that Shar
1092.72|5.079|gbt was really important to this kind of
1094.919|5.081|acceleration and progress on fine-tuning
1097.799|3.961|models because the diversity of data is
1100.0|4.08|just so much stronger than what people
1101.76|4.68|were going to get from like this alpaca
1104.08|4.839|self- instruct idea and it set the bar
1106.44|4.88|much higher it's only today and in the
1108.919|3.921|last like few months or six months for
1111.32|2.96|some of them that were getting data sets
1112.84|4.959|that could replace these so you see I
1114.28|4.92|mentioned um lmis chat one 1M which is
1117.799|3.88|just a million conversations from
1119.2|5.12|chatbot Arena which took a lot of work
1121.679|4.441|to clean out personal information and
1124.32|4.479|then a project from the Allen Institute
1126.12|5.4|of AI which is wild chat which is really
1128.799|4.76|similar to share gbt but the users were
1131.52|3.32|given consent at the start that their
1133.559|3.6|data was going to be collected and
1134.84|5.64|released in exchange for using a
1137.159|5.441|language model for free so there's a lot
1140.48|3.84|of happen stance in the story where
1142.6|3.68|something like this which is legally
1144.32|5.68|gray and the data is still on hugging
1146.28|5.68|face but it's looks kind of odd um where
1150.0|4.32|these little things helped enable the
1151.96|3.48|ecosystem even though looking back it's
1154.32|3.32|like oh we don't know if that should
1155.44|2.2|have
1159.24|7.52|happened following vuna is one called
1162.44|5.68|koala from also from Berkeley and like
1166.76|2.76|it's with you look at the time frames
1168.12|3.16|it's pretty obvious that a lot of these
1169.52|3.2|were developed concurrently and then the
1171.28|3.92|release dates just happened to be
1172.72|4.319|slightly different koala is mostly known
1175.2|4.719|for having kind of a different diverse
1177.039|6.081|set of data sets they used some from
1179.919|5.681|alaka they used some from shared jpt
1183.12|4.0|again they also used anthropic data that
1185.6|3.64|has been released and they had some
1187.12|4.4|human evaluation from grad students so
1189.24|4.08|this just added more data diversity and
1191.52|3.279|the evaluations weren't necessarily
1193.32|3.359|better but it was an important model
1194.799|4.0|that a lot of people noticed just from
1196.679|3.841|these kind of bringing back up these new
1198.799|4.521|data sets that had been in the
1200.52|4.76|literature from years prior something
1203.32|4.08|they might ask looking at these slides
1205.28|3.92|is that it's like why weight differences
1207.4|5.399|I have all these slides like weight diff
1209.2|5.479|to llama 7B weight diff um essentially
1212.799|4.561|when llama was released it was released
1214.679|4.521|as research only and just you had to and
1217.36|4.0|it was distributed to researchers upon
1219.2|3.64|request and the license prohibited
1221.36|3.24|people from updating llama one to
1222.84|3.64|hugging phas so it's kind of this
1224.6|3.52|annoying phase where in order to use a
1226.48|4.4|model on hugging face you had to clone
1228.12|4.88|it and then you had to run a script to
1230.88|4.0|convert it with this kind of Delta into
1233.0|3.919|the new model in order to in order to
1234.88|4.08|actually use it so this is kind of a
1236.919|3.12|really frustrating phase from a user
1238.96|2.959|perspective because it just made
1240.039|4.721|experimentation have one one more
1241.919|4.561|barrier to entry and thankfully it was
1244.76|4.0|changed with llama 2 but it was really
1246.48|4.8|something that many people dealt with at
1248.76|5.88|the time and we now today see different
1251.28|6.32|license restrictions on how llama is
1254.64|4.68|used I mean the Llama 3 released today
1257.6|3.559|essentially if you if if I find tuna
1259.32|4.599|model for my research and I release it
1261.159|4.841|at ai2 llama 3 needs to be in the name
1263.919|4.281|so if I wanted to release a new like
1266.0|5.48|Tulu model it would have to be llama 3
1268.2|4.8|Tulu 4 DPO it's like the namings are
1271.48|3.24|going to be crazy but there's always
1273.0|4.84|been restrictions on using llama weights
1274.72|5.92|or how you how you share
1277.84|4.92|them and the final model that I kind of
1280.64|5.76|group into this batch of this real first
1282.76|4.88|swing was Dolly so dolly was fine-tuned
1286.4|2.84|from a different base model it was
1287.64|3.919|fine-tuned from the pit models from
1289.24|5.039|alther which were a suite of early
1291.559|5.24|scaling experiments from alther AI which
1294.279|4.64|is still used extensively but they added
1296.799|4.681|some human written data to the loop
1298.919|4.081|which is just really important because
1301.48|3.559|almost all of the projects that I'll
1303.0|4.32|mention today talk about synthetic data
1305.039|4.081|or data derived from open AI there's
1307.32|3.68|only a few of them that actually added
1309.12|4.64|new human data to The Loop and this is
1311.0|4.4|what everyone remembered dolly for and a
1313.76|3.519|lot of its performance limitations are
1315.4|4.44|probably from the base model Pia which
1317.279|4.561|is trained in a Time where this type of
1319.84|4.28|inference that people expect wasn't as
1321.84|5.8|popular and it was kind of before this
1324.12|3.52|the scaling laws were thought of it
1327.679|4.0|differently you can kind of see through
1329.72|3.8|these where we're going to start with
1331.679|3.641|different model sizes and different Mt
1333.52|3.44|bench scores I'll talk about what Mt
1335.32|3.839|bench is in a few slides it's an
1336.96|6.04|evaluation tool and this is really just
1339.159|6.561|to ground you on what the kind how the
1343.0|4.24|scores would change over time so I have
1345.72|3.24|these throughout the talk as we kind of
1347.24|5.039|go through different models just just to
1348.96|5.16|show um kind of how this how the scores
1352.279|3.601|continue to progress over time from one
1354.12|3.919|small change to another as the community
1355.88|4.159|gets better at these
1358.039|3.481|things while I was talking about human
1360.039|2.361|data so remember dolly is all about
1361.52|4.72|human
1362.4|7.72|data the probably the still the single
1366.24|6.439|busiest um human coordination project
1370.12|4.96|for data generation was open Assistant I
1372.679|4.48|think it's easy now if you get into fine
1375.08|4.36|tuning to see the open system data set
1377.159|5.321|and not realize
1379.44|5.2|how important it was to the process of
1382.48|4.28|alignment in this whole summer and it is
1384.64|4.84|still used today so essentially there's
1386.76|4.96|this quote on the top but they the
1389.48|5.64|leaders ran a community project to
1391.72|6.68|generate human written prompts and these
1395.12|5.159|kind of like human written responses in
1398.4|3.84|many different languages with rating
1400.279|4.88|them so you could use it as preferences
1402.24|6.48|with the slide has a bug where it's like
1405.159|6.241|like has over 10,000 anod trees and over
1408.72|4.559|thousand U volunteers this is still used
1411.4|4.36|extensively today will come up again in
1413.279|5.161|the talk they also released models so
1415.76|4.2|the first mod one of the the first model
1418.44|3.56|used on hugging chat which I don't
1419.96|4.719|remember the launch date of was an open
1422.0|4.919|Assistant model so open Assistant was
1424.679|4.0|probably the first majorly successful
1426.919|3.041|project of the era and the data set is
1428.679|3.681|still used
1429.96|4.079|today where I will end this talk is
1432.36|3.799|saying that we need more things like
1434.039|4.081|this it's like really one of the most
1436.159|4.201|important things is we need more human
1438.12|5.439|data in the
1440.36|5.16|open this is a quick aside it's kind of
1443.559|5.48|out of the flow of the talk but on April
1445.52|6.2|28th of 2023 typo on the slide of April
1449.039|7.081|28th of 2023 stable vuno was released
1451.72|6.52|from Carper AI which looks now like the
1456.12|6.88|style of training models except for the
1458.24|6.88|data set which was um is now popular
1463.0|4.44|they they got po to work they had some
1465.12|5.48|human evaluations that were solid it was
1467.44|5.56|a good chat model it wasn't um out of
1470.6|4.92|distribution but Carper AI was really
1473.0|4.44|ahead at the time and then it seems like
1475.52|4.48|priorities kind of shifted from
1477.44|4.32|stability but it's important to know the
1480.0|4.44|extent by which there were still some
1481.76|6.96|players who knew how to do rhf really on
1484.44|4.28|early on even though they were pretty
1490.76|4.24|rare this is the last this is the last
1493.399|5.241|slide of this kind of first chapter on
1495.0|6.64|instruction tuning was the idea of qor
1498.64|5.12|which was kind of unlocked a whole new
1501.64|4.56|um bunch of players into actually being
1503.76|3.96|able to find two models so for the quick
1506.2|4.76|60c
1507.72|5.48|overview um Laura stands for low rank
1510.96|4.36|adaptation which is the idea of you can
1513.2|3.68|freeze some model weight you freeze most
1515.32|4.239|of the model weights and you add new
1516.88|4.72|weights to specific layers that you can
1519.559|3.921|then fine-tune as if you were
1521.6|4.36|fine-tuning the whole model you use the
1523.48|4.079|same approach of instruction data with
1525.96|4.719|question answering but it takes much
1527.559|5.24|less r memory Q Laura was a technique
1530.679|4.841|that built upon this by adding very
1532.799|4.801|specific quantization and GPU tricks to
1535.52|5.12|make it so that memory requirements to
1537.6|5.559|fine-tune models was even lower um tin
1540.64|6.8|demmer's and team also released this
1543.159|6.161|guano model with it which was another
1547.44|3.88|big step up in performance of these
1549.32|3.44|models I have a few more slides on it on
1551.32|3.959|the method so you can kind of see on the
1552.76|4.88|right this difference full fine tuning
1555.279|3.921|and Laura they look similar where Laura
1557.64|4.399|you have fewer parameters is kind of
1559.2|4.92|what the smaller shapes mean in Cura um
1562.039|3.88|they quantize the base model that you're
1564.12|2.96|propagating gradients through to save
1565.919|4.64|most of the
1567.08|5.599|memory so this is an approximation of if
1570.559|4.401|you're fine-tuning different model sizes
1572.679|4.841|on the top so 7 billion 13 billion 30
1574.96|4.16|billion with full fine tuning different
1577.52|4.759|amount of bits but full fine tuning
1579.12|6.919|versus Laura versus Cura and you can
1582.279|6.801|kind of see um for reference one a100
1586.039|5.801|GPU has about 80 gigabytes of memory and
1589.08|5.28|these are really hard gpus to get plenty
1591.84|5.719|of consumer gpus will only have like 24
1594.36|6.0|to 32 gigabytes of memory so you need to
1597.559|6.201|use these Cur techniques to actually get
1600.36|7.039|the ability to fine-tune models at the
1603.76|7.12|seven or 13 billion parameter
1607.399|5.961|size um and like guano did this and they
1610.88|4.6|released 33 billion and 65 billion
1613.36|3.84|parameter llama fine tunes which were
1615.48|3.679|clear steps up in the kind of state of
1617.2|4.8|the art at the time
1619.159|4.441|and they also figured out ways to filter
1622.0|3.36|this open Assistant data set that I
1623.6|3.36|mentioned and this kind of filtered
1625.36|3.6|version of open assistant is what is
1626.96|4.16|still most popular
1628.96|3.56|today I'm going to kind of pause and
1631.12|3.24|skim through the questions and see if
1632.52|4.92|there's anything on that section and if
1634.36|5.16|not I'll save the relevant ones for
1637.44|3.52|later okay I'm going to keep going
1639.52|5.159|they're they're great questions and I
1640.96|6.199|appreciate them um but they're mostly
1644.679|5.441|not specific enough where it's worth the
1647.159|6.681|digression this chapter 2 phase is
1650.12|6.32|really like where it seemed like things
1653.84|4.319|were a little bit slower on the ground
1656.44|3.959|but when we look back at a lot of things
1658.159|4.24|that came out of this time like DPO Pap
1660.399|3.28|the DPO paper was in this era everyone
1662.399|3.321|read it but we didn't know what to do
1663.679|4.201|with it yet and the new evaluations are
1665.72|5.16|still really
1667.88|6.32|used transitioning in setting the seam
1670.88|5.0|for being not sure of things work um a
1674.2|3.719|lot of people are continuing to try to
1675.88|4.08|build on these Laura methods and Cura
1677.919|3.561|method me I remember a lot of excitement
1679.96|5.319|at hugging face where we were setting up
1681.48|6.36|our rhf pipeline where we could do rhf
1685.279|4.721|on 7 billion parameter models and we
1687.84|4.04|could maybe do it on a consumer GPU it
1690.0|4.24|was really cool to see the loss going
1691.88|4.84|down it's great to bring more people
1694.24|5.52|into the space but weeks and weeks would
1696.72|5.24|go by and they like why has no one
1699.76|4.0|picked up what we released in the blog
1701.96|5.88|post and trained a really good model
1703.76|5.279|with it and the kind of consensus now is
1707.84|3.04|that
1709.039|4.24|um these Lura methods just have some
1710.88|4.76|sort of weird limitation in how you use
1713.279|4.721|them or how the gradients flow that make
1715.64|4.519|it much much harder to get a really good
1718.0|4.559|model out if you only have a certain
1720.159|4.561|number of gpus such that Laura is your
1722.559|3.921|only option definitely use it but for
1724.72|3.52|people that have more gpus figuring out
1726.48|3.72|how to scale is normally a better
1728.24|4.12|solution than just using something like
1730.2|4.16|Laura that fits and is easier for in the
1732.36|4.24|short
1734.36|5.96|term another defining moment of this
1736.6|5.439|arrow is the Llama 2 back Clash um I'm
1740.32|4.239|guessing some people remember this which
1742.039|4.48|is like the the famous line was people
1744.559|4.36|asked llama if how to kill a python
1746.519|4.88|process and it would say no and this
1748.919|5.201|really started a whole bunch of new
1751.399|5.321|discussions around what kind of
1754.12|5.159|alignment means or what model should or
1756.72|5.559|should not do here's an example from a
1759.279|6.481|paper for a safety evaluation test set
1762.279|5.841|called XS test and it's just like should
1765.76|5.159|chat models be saved or should they
1768.12|4.399|follow the instructions that I want and
1770.919|3.921|this is a fundamental question it'll
1772.519|5.441|differ by organization it'll differ by
1774.84|4.88|individual and this is the point where
1777.96|3.24|this became very serious and something
1779.72|4.04|that people actually had to reckon with
1781.2|4.44|because there were models that were
1783.76|5.039|actively disagree people were really
1785.64|5.56|disagreeing with this specific take I
1788.799|4.0|don't have any clear solution to it but
1791.2|4.88|one of the things that led to is this
1792.799|6.321|idea of uncensored models um it's a
1796.08|5.52|really popular category on
1799.12|4.64|uh kind of hugging face right now where
1801.6|4.079|the idea is you remove filtering so if
1803.76|4.279|we're using synthetic data and I ask a
1805.679|4.041|language model a question like if I
1808.039|3.24|asked chat gbt how to make a bomb it's
1809.72|3.76|going to say I'm sorry I'm as a language
1811.279|4.601|model I shouldn't make this and the idea
1813.48|5.96|of uncensored models is to remove those
1815.88|6.0|points from our kind of remove those
1819.44|3.64|points from our fine-tuning data set I
1821.88|3.08|think there's a lot of confusion over
1823.08|4.079|the name because language models were
1824.96|5.0|never at this stage really aren't
1827.159|5.161|censored to with but it's really that
1829.96|5.8|the data set and the method for creating
1832.32|4.8|these data sets needed more filtering or
1835.76|4.88|they needed some way of becoming
1837.12|5.84|unbiased so like there's a lot of people
1840.64|4.24|now that only build models to try to
1842.96|3.64|make them unbiased against any sort of
1844.88|3.84|refusal a refusal is when you ask a
1846.6|3.84|language bottle something and it says no
1848.72|4.64|and this goes on today and this came out
1850.44|6.079|of this llama 2
1853.36|5.4|thing but otherwise this is a transition
1856.519|4.561|period where there's a lot of good
1858.76|4.12|solid models being trained but either
1861.08|3.599|they didn't have a lot of documentation
1862.88|4.159|they didn't have the right release team
1864.679|4.521|to Splash as big as they should have the
1867.039|4.24|methods were complicated to implement or
1869.2|3.479|something like this so like I could run
1871.279|3.601|through these and I remember all these
1872.679|4.12|models coming out but none of them were
1874.88|4.56|really things that are household names
1876.799|5.441|like alpaca is today like wizard the
1879.44|4.359|team from behind wizard L LM where they
1882.24|3.24|created this method called inval
1883.799|4.681|instruct which is a synthetic data
1885.48|4.919|method like all these things were
1888.48|3.52|clearly working for them based on the
1890.399|3.76|models they were generating but for
1892.0|4.88|whatever reason the narrative wasn't
1894.159|5.561|actually changed um there's some new
1896.88|5.919|data sets from Ultra like ultr LM is
1899.72|4.72|from open BMB in China that is releasing
1902.799|5.84|new data sets more people training on
1904.44|6.119|share GPT the model called xwin LM was
1908.639|4.841|the first one to be like a similar
1910.559|5.72|Ballpark and it's like also trained with
1913.48|5.36|rhf so not just that Carper model but
1916.279|4.041|for whatever reason it's like
1918.84|3.76|these didn't really Splash and that's
1920.32|4.8|kind of was this kind of Summer after
1922.6|4.28|llama 2 where fine tuning was chugging
1925.12|4.159|chugging along but the narrative wasn't
1926.88|6.44|changing all of that much at least from
1929.279|4.041|my perspective but hope that's why I'm
1933.72|4.559|here but what was happening in the
1935.84|5.0|background while the models weren't
1938.279|4.52|seeming that different is that new
1940.84|3.92|evaluation tools were coming out that
1942.799|4.041|ended up kind of being the standard of
1944.76|4.72|today so you can see the dates here so
1946.84|4.799|May May 3rd bot Arena June 8th alpaca
1949.48|4.799|ofal June 22nd Mt bench sometime in
1951.639|4.16|early July the open llm leaderboard all
1954.279|3.481|of these things were created about the
1955.799|5.321|same time where there's a desperate need
1957.76|5.279|to get some sort of signal on what our
1961.12|3.96|fine-tuned models are doing in the open
1963.039|4.801|like we don't have the capability of
1965.08|4.64|paying humans to compare our responses
1967.84|3.92|like they do at anthropic where they're
1969.72|3.36|always trying new models on humans
1971.76|3.48|that's way too expensive we need
1973.08|4.52|something that you could sit down as an
1975.24|4.6|engineer and get feedback in 10 to 15
1977.6|2.24|minutes
1979.919|3.76|so kind of run through these in order
1981.559|3.6|and some a lot of these are obvious but
1983.679|3.96|it's important to take this from the
1985.159|4.961|perspective of what can I use when I'm
1987.639|4.441|trying to align models and like what is
1990.12|4.72|an immediate feedback versus what is
1992.08|5.64|kind of this long-term signal so chapot
1994.84|5.0|arena is obviously fantastic like
1997.72|6.0|everyone looks at this today as
1999.84|6.52|something that is defining um it's like
2003.72|4.4|defining corporate strategy is defining
2006.36|4.88|the biggest language model players like
2008.12|6.88|if Cloud 3 is better than GPT 4 but if
2011.24|5.6|I'm an engineer a many small providers
2015.0|5.12|aren't going to get their models in and
2016.84|5.76|B it takes especially previously it used
2020.12|4.679|to take weeks to get your models rating
2022.6|4.799|but now it takes days like I need to
2024.799|4.641|know what my models of are before I
2027.399|4.0|decide to actually release it so that's
2029.44|4.56|the biggest thing where like I know I
2031.399|4.561|need something Beyond chatbot Arena just
2034.0|3.799|for my engineering
2035.96|4.199|development and this is where like
2037.799|5.6|alpaca of Val and Mt bench really Thrive
2040.159|5.201|so alpaca of Val got the slide forting
2043.399|5.0|got changed but um I'll just kind of
2045.36|4.319|keep rolling through this um alpaca ofal
2048.399|4.68|is the idea of you have a list of
2049.679|6.48|prompts that you compare to some a
2053.079|6.721|strong other base model like um open
2056.159|5.48|ai's D vinci3 or gp4 and then you ask a
2059.8|4.079|language model which is better and the
2061.639|5.601|data set here is compiled from all these
2063.879|6.0|popular data sets that um I have been
2067.24|5.52|talking about so far so data sets from
2069.879|5.321|open Assistant vuna koala anthropic like
2072.76|4.52|all these data sets that people have
2075.2|4.159|been using they took the test sets from
2077.28|5.0|those and that's what Al pack Val
2079.359|5.641|mirrors it's kind of a known thing it
2082.28|5.399|has some limitations because there's
2085.0|4.32|only so many prompts and it's like
2087.679|3.641|asking a language model to provide a
2089.32|3.68|rating is going to have some ceiling
2091.32|4.64|where we don't know how to compare two
2093.0|5.96|really good models so has more samples
2095.96|5.639|than Mt bench so there's more
2098.96|4.44|um so there's just kind of Le smaller
2101.599|4.201|error bars and it's easier to use
2103.4|3.92|because it's a single turn generation
2105.8|4.039|but we've heard about the length bias
2107.32|4.56|for a really long time and it's not
2109.839|3.52|clear how to interpret these top results
2111.88|5.479|so if you this is the older screenshot
2113.359|6.681|of leaderboard but what is beating a
2117.359|4.801|model 95% of the time mean to another
2120.04|4.559|language model that's the questions that
2122.16|5.199|we can't really answer in the short
2124.599|7.081|term a paco of al2 came out which takes
2127.359|7.72|steps to this where it rate compares the
2131.68|6.72|GPT 4 rather than D Vinci 3 D vinci3 was
2135.079|7.161|an instruct gbt variant but at the end
2138.4|6.04|of the day if the like um gbt 4 is
2142.24|4.96|answering these questions in the alpaca
2144.44|6.36|style really well so what does beating
2147.2|6.56|gp4 exactly mean I we need to get more
2150.8|5.039|specific in our valuations because I
2153.76|4.88|don't really know if I care too much
2155.839|5.121|about a 20 or 30% score and alpaca about
2158.64|4.36|2 because I don't know what it means and
2160.96|3.879|this is one this is the opaqueness of
2163.0|4.119|all of our evaluations we'll see this
2164.839|4.041|time and time again where we don't know
2167.119|3.441|what an increase in score means so it's
2168.88|3.08|like the next step after being able to
2170.56|4.2|do it
2171.96|6.48|easily this update was pretty
2174.76|6.64|recent um Mt bench is is pretty similar
2178.44|4.8|where instead of comparing to one model
2181.4|4.4|you ask a language model to provide a
2183.24|4.64|score to a list of prompts so if I have
2185.8|4.559|a model I'm training a gener the
2187.88|5.68|completion to 80 diverse prompts and
2190.359|6.121|then I asked gp4 hey from 0 to 10 how
2193.56|5.64|good were each of those uh completions
2196.48|4.839|and this is good but it runs into the
2199.2|4.119|same problem of like what if our model
2201.319|5.28|is getting really good if our model is
2203.319|6.0|getting really good it's it's just like
2206.599|5.601|it becomes saturated like gp4 only gets
2209.319|5.161|to about nine and there's only about 80
2212.2|4.919|prompts in the evaluation set and all
2214.48|4.4|these things it's just and one of the
2217.119|3.921|nuance points is that there's actually a
2218.88|5.08|variance so even if you set the
2221.04|4.72|temperature to zero gp4 versions change
2223.96|5.119|your own Generations from your model
2225.76|6.559|you're trying to change train can change
2229.079|4.921|and this makes it better where it's like
2232.319|3.881|okay I can tell if a model was really
2234.0|5.16|bad if Mt bench and Alaco Val have
2236.2|5.8|really low scores but it's hard to like
2239.16|5.84|it's it's still we have these this goal
2242.0|5.2|for a precise evaluation so like in
2245.0|5.359|pre-training we have Mt bench and Alpac
2247.2|5.24|and H swag and all the or sorry in
2250.359|3.601|pre-training we have like mlu and hellis
2252.44|3.919|swag and all these things that people
2253.96|4.399|can look at and average over 10 tasks
2256.359|3.921|and if you get like a 2% Improvement on
2258.359|5.24|average you're doing great but we don't
2260.28|5.88|have this clear indicator in alignment
2263.599|3.801|evaluation the open llm leaderboard was
2266.16|3.4|the same where
2267.4|4.32|it's this came out of the team I was
2269.56|4.64|working on at hugging base where we were
2271.72|5.2|just trying to evaluate more models to
2274.2|4.28|get more signal which was that we needed
2276.92|3.919|to know what our competitors are doing
2278.48|4.04|and get some ballpark estimate and what
2280.839|4.721|this grew into is this whole kind of
2282.52|4.799|like ecosystem supporting Discovery tool
2285.56|3.279|just because like getting any signal is
2287.319|3.121|so useful so this is where we were
2288.839|3.561|starting with evaluation which was just
2290.44|4.12|like no signal and why this leaderboard
2292.4|3.84|was so successful is because it gave
2294.56|3.12|everyone access to a little bit more
2296.24|3.839|signal on the models that their
2297.68|4.08|evaluation but it didn't really solve
2300.079|4.321|any of the fundamental problems and it
2301.76|4.359|didn't show us that like doing RL jeon
2304.4|3.36|models would actually make the scores go
2306.119|3.601|up it's starting to get better today but
2307.76|3.599|that's like a year on from the launch of
2309.72|4.56|this
2311.359|4.72|leaderboard so like these problems are
2314.28|4.68|still this is talking about a section
2316.079|5.201|from July of 2023 and it seems like the
2318.96|3.84|things that if I were to go into like go
2321.28|2.88|into work and talk to people what we're
2322.8|2.799|going to do with our new models like
2324.16|3.8|these are the same questions that we're
2325.599|4.801|still asking which is why it's there's
2327.96|3.92|it the these evaluation schools are
2330.4|3.439|still so useful and it's why people
2331.88|4.199|still talk about opaco Val but it shows
2333.839|4.641|how much of an opportunity there still
2336.079|5.441|is so this kind of a summary of what I
2338.48|5.08|was talking about it's like how easy is
2341.52|4.72|it to use these evaluations like chapot
2343.56|4.84|arena is everything like Andre Cory
2346.24|4.68|tweets about it and it's great and you
2348.4|5.48|can go there and you can use models but
2350.92|4.72|like I I don't know how to make sense of
2353.88|4.52|that as if I'm trying to sit down every
2355.64|5.76|day and write code and the alpaca andal
2358.4|5.439|and Mt bench mostly solve this by being
2361.4|4.16|cheap and pretty accessible but I really
2363.839|3.881|really think there's a huge opportunity
2365.56|4.36|here to come out with more so the
2367.72|5.119|colleague at ai2 launched wild bench
2369.92|5.04|which is a good tool that kind of fits
2372.839|3.76|in it's like a chatbot Arena alpaca of
2374.96|3.76|Al hybrid and you can use it a little
2376.599|4.961|bit faster it's like how are we going to
2378.72|4.119|continue to push this along is a great
2381.56|3.519|question and I would love to hear what
2382.839|2.24|people
2385.839|5.961|think we'll take another pause I think
2389.24|6.24|we're getting good questions in the chat
2391.8|5.96|around um rhf and other things um to
2395.48|5.0|what extent are do aligned models
2397.76|4.96|actually reason about whether user
2400.48|4.72|attent is malicious rather than perform
2402.72|5.2|talk detection to detect to avoid unsafe
2405.2|4.48|topics this is a question that I wanted
2407.92|5.08|to read because it kind of gets at this
2409.68|6.0|model versus system topic so when trbt
2413.0|5.2|was released on day one it has an output
2415.68|4.6|filter that does moderation the language
2418.2|4.72|model that is instruction tuned or rhf
2420.28|5.76|tuned generates a bunch of text and then
2422.92|5.08|a separate model says yes or no and
2426.04|4.319|that's like the where it actually does
2428.0|4.079|detection and with the release of llama
2430.359|3.681|3 there's another model that's called
2432.079|4.401|like llama guard and this is a
2434.04|4.559|classifier which will take this text do
2436.48|5.16|the moderation and say which type of
2438.599|5.041|unsaved topic it is the actual model
2441.64|4.64|that is generating does no reasoning
2443.64|5.28|over um kind of what is actually an
2446.28|2.64|unsaved
2449.0|4.72|topic so I'll come back to other ones
2451.119|5.761|I'm going to do some discussions about
2453.72|6.16|um rhf right now so this will kind of
2456.88|6.08|give grounds for where we can continue
2459.88|5.6|some of these discussions on um there's
2462.96|4.0|orpo or reinforce I don't cover all of
2465.48|5.56|them in the lecture but I kind of lead
2466.96|4.08|on to why we would talk about
2472.68|4.52|them so this this chapter is when I
2475.28|5.319|started to get validation as an RL
2477.2|5.6|researcher that being otic and going to
2480.599|5.601|work in language models was actually a
2482.8|6.799|good idea for a lot of this there was a
2486.2|5.2|lot of uncertainty over if the people if
2489.599|4.201|people in this kind of open ecosystem
2491.4|4.959|were even going to be able to use rlf at
2493.8|4.6|all or if being a quote unquote rhf
2496.359|3.681|researcher for me meant I was going to
2498.4|4.0|do instruction fine-tuning and talk
2500.04|6.52|about aows and never think about RL
2502.4|6.52|again it turned out to be wrong
2506.56|3.799|um I'm going to review some RL
2508.92|3.0|fundamentals just to kind of make sure
2510.359|3.161|we're talking the same language as we
2511.92|3.32|talk about this and this will lead into
2513.52|3.799|direct preference optimization so
2515.24|4.2|there's a reason why I'm doing math I no
2517.319|4.321|we don't this is not a normal lecture
2519.44|4.12|but here is the equation where you'll
2521.64|4.24|see this in rhf papers this is what
2523.56|5.519|we're optimizing when we're optimizing
2525.88|5.04|rhf it it looks kind of nebulous here
2529.079|4.321|I'll break it down so on the left side
2530.92|5.72|we're really maximizing with respect to
2533.4|6.199|some policy Pi um this reward that is
2536.64|5.479|parameterized by a network fi and we're
2539.599|4.041|have a penalty that is this kind of KL
2542.119|4.0|term which is the distance from our
2543.64|4.52|policy to some reference we want to
2546.119|4.24|increase reward and but we want to
2548.16|3.8|constrain the model so that it doesn't
2550.359|3.0|the this kind of optimization doesn't go
2551.96|4.56|too
2553.359|5.041|far and the primary questions when doing
2556.52|3.72|this is how do we Implement a good
2558.4|4.56|reward function and how do we optimize
2560.24|4.8|the reward these are a really RL Centric
2562.96|5.28|way of doing it which is like if you
2565.04|6.0|give me a reward function I can optimize
2568.24|4.48|and the classic RL idea was I'm in an
2571.04|4.519|environment the environment has the
2572.72|5.0|reward function built in in rhf we're
2575.559|5.04|designing our own reward function so
2577.72|5.76|this adds a lot of weirdness to the
2580.599|6.561|actual optimization that we're
2583.48|5.28|doing and what we do is to get this
2587.16|3.72|reward function is we learn what is
2588.76|4.96|called a preference or reward model and
2590.88|5.56|the most popular way to do this is to
2593.72|5.72|take a take a language model that's kind
2596.44|4.96|of predicting this separation of two
2599.44|3.56|preferences this is called a Bradley
2601.4|4.719|Terry model which goes back to some
2603.0|5.24|economics but the key idea is that the
2606.119|4.121|reward will be proportional to the
2608.24|4.079|probability that the text they have
2610.24|4.92|would be chosen over any other arbitrary
2612.319|4.641|text quickly sounds really Theory like
2615.16|4.0|but it outputs a scaler which is now a
2616.96|4.48|reward function and is based on this par
2619.16|5.84|wise
2621.44|5.52|data so the idea is with this equation
2625.0|4.92|what if we just use gradient Ascent on
2626.96|5.599|this equation and instead of trying to
2629.92|4.84|learn a preference model and learn this
2632.559|4.161|R what if we just use gradient Ascent
2634.76|4.0|directly this is really what direct
2636.72|3.92|preference optimization is doing there's
2638.76|4.64|a bunch of math in here to get what this
2640.64|4.439|R is but this was released back in May
2643.4|3.719|so we've already moved on months ahead
2645.079|4.561|this chapter starts in kind of late
2647.119|4.641|September October back in May when we're
2649.64|4.439|still talking about open Assistant this
2651.76|4.319|DPO paper came out it's a fantastic
2654.079|4.76|paper if you hadn't read it it's a great
2656.079|5.081|way to learn about language model map it
2658.839|5.161|it's worth reading but the core idea is
2661.16|4.64|like why are we spending all this time
2664.0|3.72|um learning a reward model when we can
2665.8|3.68|just use gradient
2667.72|4.119|and solve for the loss
2669.48|6.0|function some key ideas to think about
2671.839|5.881|with DPO is that DPO is extremely simple
2675.48|4.92|to implement on the right here side is
2677.72|4.32|the example code from the DPO paper
2680.4|3.8|where it's like as long as you have
2682.04|3.92|access to the log probs from a model
2684.2|4.159|which is a very core thing for training
2685.96|5.24|language models um you can compute the
2688.359|5.76|DPO loss um because of this because the
2691.2|5.639|loss function is at a nice abstraction
2694.119|3.48|it scales nicely with existing libraries
2696.839|2.72|and
2697.599|4.041|it what it's actually doing is training
2699.559|4.52|an implicit reward function so the
2701.64|4.0|reward is a function of the log probs I
2704.079|5.201|don't have the equation here because it
2705.64|6.12|quickly becomes a rabbit hole um but
2709.28|6.079|whatever the whole DPO versus poo debate
2711.76|6.96|means or um o RPO I don't remember what
2715.359|5.041|the paper me title is um we're going to
2718.72|3.56|see a lot of these things because it's
2720.4|3.8|simple and it's scales well that doesn't
2722.28|4.039|necessarily mean the fundamental limits
2724.2|4.08|are higher but it sometimes it doesn't
2726.319|3.601|matter if the Li are higher if it's
2728.28|3.44|easier to make progress on something
2729.92|3.679|because it's EAS it feels better when
2731.72|3.399|progress is being made so that's really
2733.599|4.361|a core thing is we'll keep seeing these
2735.119|5.72|models and we are and there's this whole
2737.96|5.52|debate that has gone on kind of crushing
2740.839|4.72|a whole bunch of these questions by um
2743.48|3.879|redirecting them in a very political
2745.559|4.241|manner but it's like should we use
2747.359|5.361|reinforce what about po what about like
2749.8|6.759|other things um there're very different
2752.72|5.92|styles of optimization so in one half
2756.559|3.56|we're used RL update rules which is
2758.64|4.04|ultimately about learning a value
2760.119|4.401|function and then learning to update
2762.68|4.04|taking gradient steps with respect to
2764.52|3.76|that value function in DPO we're taking
2766.72|3.24|gradient steps directly from the
2768.28|3.279|probabilities of the language model
2769.96|3.48|they're very different optimization
2771.559|4.121|regimes and there's this great meme
2773.44|4.72|where like all the like there was a
2775.68|6.32|month where the whole NLP Twitter was
2778.16|6.84|just arguing about this but both of them
2782.0|7.4|are continuing to progress and that is
2785.0|4.4|good like it will not just be one or the
2789.48|5.56|other um so what really made this debate
2792.52|5.2|kick into gear was this release of the
2795.04|4.44|Zephyr beta model from hugging face it's
2797.72|3.399|after I left hugging face but the team I
2799.48|3.68|was on and it was the first Model to
2801.119|4.081|make a splash with DPO and it was a big
2803.16|3.64|step up in how models were perceived
2805.2|3.08|this model was added to like the U
2806.8|3.2|search engine people were using all
2808.28|3.799|sorts of crazy things so it just felt
2810.0|4.0|really good to use it was building on
2812.079|4.52|this better base model mistol had come
2814.0|4.4|out a new data set this Ultra feedback
2816.599|3.801|data set that I mentioned is still one
2818.4|4.48|of the core data sets used today when
2820.4|5.08|we're kind of practicing alignment this
2822.88|4.92|was back in September October that this
2825.48|5.04|model came back one of the core things
2827.8|5.279|to getting DPO to work was using really
2830.52|5.0|low learning rates like 5e minus 7
2833.079|4.441|there's memes about 3E minus 4 being the
2835.52|3.799|only learning rate you need to do deep
2837.52|4.599|learning and changing it being kind of a
2839.319|5.0|joke DPO is the case where that is not
2842.119|4.48|even remotely true and then you can see
2844.319|4.24|the Mt bench scores again continuing to
2846.599|5.161|rise so this is like a validation proof
2848.559|5.56|that DPO works that came four months
2851.76|4.12|after the paper was released that delay
2854.119|4.081|is something that nobody expected we
2855.88|5.08|were kind of losing Hope on DPO at many
2858.2|4.919|times and now look at where it is and
2860.96|4.159|then when I joined ai2 they were already
2863.119|3.681|working on this project and I had just
2865.119|3.361|helped kind of get it across the line
2866.8|3.84|it's like the classic advisor thing
2868.48|4.56|where sometimes it's just easier is the
2870.64|4.719|first model to scale DPO to 70 billion
2873.04|4.6|parameters the last question was oh yeah
2875.359|4.681|DPO works on small models when I ever
2877.64|4.64|use it on a big model answer is yes and
2880.04|4.079|it's like built on the same recipe as
2882.28|5.319|Zephyr with a little bit different
2884.119|6.44|instruction tuning data sets but scores
2887.599|5.76|continued to climb this was this model
2890.559|5.201|was so close to beating GPT 3.5 on
2893.359|4.521|chatbot Arena it was like a couple ELO
2895.76|4.44|points below so we didn't get the title
2897.88|4.76|of being the first on to do that but
2900.2|4.6|open models were starting to get that
2902.64|4.479|kind of Chatty behavior that for so long
2904.8|4.0|had eluded them because we had figured
2907.119|4.2|out scale because we hadn't figured out
2908.8|4.36|these data sets so it was great progress
2911.319|3.441|very important and kind of major
2913.16|3.919|transition in my career where now it's
2914.76|4.96|like okay rhf
2917.079|4.161|methods really can work and these
2919.72|3.879|weren't just I was not the only one
2921.24|3.839|touching things that did this a couple
2923.599|5.321|other projects that are really important
2925.079|6.52|so Nvidia had steer steerm where steerm
2928.92|4.159|was collecting um feedback data where
2931.599|3.441|there was attributes on it like how
2933.079|4.48|helpful the message was how concise the
2935.04|6.2|message was and they did of fine tuning
2937.559|5.481|and released Good Very solid models and
2941.24|4.04|they also showed that PO is better than
2943.04|4.48|DPO which is interesting and then
2945.28|5.559|Berkeley came out with this um Starling
2947.52|5.92|LM Alpha where they had a new preference
2950.839|4.801|data set nectar which is still looked at
2953.44|4.2|today and then they also used this kind
2955.64|3.919|of Po method after training a reward
2957.64|4.199|model and both of these came out about
2959.559|4.481|the same time and they're like huh DPO
2961.839|4.361|isn't doing as well for us the models
2964.04|4.88|are really good recently the second
2966.2|5.639|starling model came out its reward model
2968.92|5.52|is very strong in my testing it's a 7B
2971.839|4.52|model that's almost reaching chat GPT
2974.44|4.56|levels in chatbot Arena it's crazy how
2976.359|4.361|fast these models are going but we still
2979.0|5.119|get a lot of models that are both with
2980.72|6.04|po or with DP it's really not one of the
2984.119|2.641|other at this
2991.88|3.88|point okay I think this is a reasonable
2994.28|3.559|time for me to take a couple of these
2995.76|4.0|questions might come back to them in
2997.839|4.641|more slides
2999.76|6.079|but someone asked is there a particular
3002.48|5.599|alignment method that I use um there
3005.839|4.681|this is teasing a paper but there was a
3008.079|4.361|recent paper that was came out where I
3010.52|4.279|don't remember the group I can I can
3012.44|5.119|find it later but they did what they
3014.799|5.121|called a systematic study of Po and DPO
3017.559|3.921|and they showed that PO is better I will
3019.92|5.0|say that in the experiments that I'm
3021.48|5.839|seeing at allna AI I'm also seeing po to
3024.92|6.24|be stronger and we hope to release this
3027.319|5.76|stuff soon um it's not a um one crushes
3031.16|3.959|the other it's that we're seeing that
3033.079|4.52|there's for some reason PO is just
3035.119|4.321|getting a bit more performance um and
3037.599|3.401|then The Logical question is um why not
3039.44|3.84|reinforce which is another one of these
3041.0|4.2|questions I would love to try it it's
3043.28|3.319|just like we have the code that we have
3045.2|3.68|and we don't want to touch things that
3046.599|3.921|are working well and there's just so few
3048.88|4.239|people that are kind of working in the
3050.52|5.599|space which I'm like let's get more
3053.119|4.44|people working on these things because
3056.119|2.881|there's so few people that can answer
3057.559|3.841|all these questions so there's another
3059.0|5.119|question that says like some say
3061.4|6.04|reinforce can work as well as if not
3064.119|5.561|better than po it probably can it comes
3067.44|4.32|down to your infrastructure carefully
3069.68|4.679|fine-tuning it what people are excited
3071.76|5.4|about and a lot of luck so we'll see
3074.359|6.881|these continue to play out um throughout
3077.16|6.52|the year but it's it's
3081.24|5.079|complicated I'll come back to the Lama 3
3083.68|4.919|question I have I have one slide for
3086.319|4.04|that in a little bit but really this
3088.599|5.281|modern ecosystem
3090.359|6.72|is how investment in releasing open
3093.88|6.12|models that people can use is continuing
3097.079|5.081|to grow into 2024 I think there's always
3100.0|3.599|been this tenuous period of like there's
3102.16|3.56|only a few people releasing these
3103.599|3.881|aligned models there's these important
3105.72|3.76|people in the ecosystem that are just
3107.48|3.96|doing this because they want to and it's
3109.48|3.839|for fun they might have a day job and
3111.44|4.32|it's like how long can this go on like
3113.319|5.24|what are the limitations on this but in
3115.76|4.68|in 202 before we've really seen more
3118.559|3.76|companies kind of come into the space
3120.44|4.2|and someone drew meta llama 3 on the
3122.319|3.401|screen was like talking to co-workers
3124.64|2.479|and like you're yeah you're going to
3125.72|2.72|need to keep adding models you're never
3127.119|3.841|going to be able to give this lecture
3128.44|5.32|yeah it's a losing battle I know um but
3130.96|5.639|the modern the there's just way more
3133.76|4.76|types of models so I get away with not
3136.599|3.321|having llama 3 on this specific slide
3138.52|3.76|because I'm talking about diversity of
3139.92|4.32|players and models not just the fact
3142.28|3.559|that there are more great models so
3144.24|3.92|there's interesting models like this one
3145.839|3.96|gen struck from new research in the last
3148.16|3.76|few months where it's like a
3149.799|5.28|specifically fine-tuned model for
3151.92|5.0|rephrasing any text into instructions so
3155.079|3.28|if you have a book and you want a model
3156.92|3.0|to be able to answer questions about
3158.359|3.641|this why don't we just throw it at this
3159.92|5.08|rephrasing question this rephrasing
3162.0|5.48|model and the teams that I work on at
3165.0|4.839|ai2 we're trying to release instruction
3167.48|4.599|models where every single thing that
3169.839|4.361|we've done to train it is documented and
3172.079|4.161|reproducible from data to what compute
3174.2|3.879|it was there're just these models are
3176.24|3.64|getting new features in these little
3178.079|5.72|ways other than just being the quote
3179.88|6.919|unquote best open model um such as like
3183.799|5.681|these corporate entities that are going
3186.799|6.28|for really standing out in the open so
3189.48|5.44|there's data bricks dbrx model um coh's
3193.079|3.76|command R plus model I think people were
3194.92|3.96|mostly blindsided by coher releasing
3196.839|5.401|model weights but it was the first open
3198.88|6.0|model to pass gbd4 on chatbot Arena and
3202.24|6.44|that has been a long time coming I think
3204.88|7.0|beating gp4 on human evaluation is not
3208.68|5.72|easy and yes the open is still like a
3211.88|4.479|year behind but that's fine as long as
3214.4|4.48|we have a functioning ecosystem it'll
3216.359|4.801|continue to grow then there's other
3218.88|6.12|things like interesting research models
3221.16|4.919|like row came out does data waiting um
3225.0|3.24|we're finally starting to get
3226.079|5.201|multilingual models with a which is also
3228.24|5.319|from cohere um people are getting more
3231.28|4.24|mixture of expert models to train on
3233.559|4.24|which are just a bit more of an
3235.52|4.16|efficient pre-training equation State
3237.799|4.921|space models are really taking off they
3239.68|5.6|had this moment in December with Mamba
3242.72|5.879|and now it's kind of continuing in 20124
3245.28|4.76|so there's just a lot going on and this
3248.599|3.0|makes me feel good because it's like
3250.04|3.039|okay I just have to keep doing what I'm
3251.599|3.72|doing and encouraging people to
3253.079|3.881|participate and we're going to keep
3255.319|3.841|being able to do this kind of fun thing
3256.96|3.68|of figuring out how to make models and
3259.16|5.0|share them with
3260.64|5.28|people this is my slide for llama 3 um
3264.16|4.439|the reason why I didn't make a lot of
3265.92|5.439|slides about this all day is that llama
3268.599|5.121|3's release is more about scaling and
3271.359|6.081|the kind of ecosystem as a whole than it
3273.72|6.04|is about alignment the Llama 2 paper was
3277.44|4.399|extremely detailed about alignment and
3279.76|3.76|we're going to get a llama 3 paper soon
3281.839|4.361|if you can believe multiple sources of
3283.52|4.839|meta which I choose to and when the
3286.2|4.639|Llama 3 paper comes out is when we will
3288.359|4.801|learn all the interesting alignment
3290.839|5.0|things that they have done that being
3293.16|5.199|said they are very unlikely to release
3295.839|4.081|the human preference data that they did
3298.359|3.521|um yet to succeed in getting them to
3299.92|4.84|release a reward model for llama 2 or
3301.88|6.239|llama 3 from alignment so we have more
3304.76|5.92|work to do on getting meta to support
3308.119|4.081|this kind of open alignment ecosystem to
3310.68|4.52|the same extent that they are supporting
3312.2|5.96|the pre-training ecosystem and this kind
3315.2|6.28|of scaling story that I'm saying very
3318.16|6.879|much connects to the previous slide
3321.48|5.4|where scaling and solving this is very
3325.039|5.0|much determined by the market markets
3326.88|5.52|and like Capital incentives but so long
3330.039|4.76|as scaling is continuing to happen in
3332.4|4.399|the open ecosystem it just means that
3334.799|3.641|more players are going to stick around
3336.799|4.24|and in some ways it kind of feeds back
3338.44|4.359|into itself where if this llama 3 is
3341.039|4.0|rumored to have or they're training a
3342.799|4.24|400 billion parameter model which we're
3345.039|3.881|not 100% sure that the weights will be
3347.039|5.08|released but it seems like that's Mark
3348.92|6.08|Zuckerberg's intent and having that
3352.119|6.161|which is about gbt for Quality really
3355.0|6.24|changes what you can do to get language
3358.28|4.64|models running in your products so llama
3361.24|4.04|3 and how many people are playing in the
3362.92|4.679|open space right now goes to show that
3365.28|4.64|we have more of the same coming which is
3367.599|4.24|interesting models coming on a weekly
3369.92|3.8|basis and most people are just kind of
3371.839|4.121|accommodated it to it now like people
3373.72|3.52|don't freak out when there's a new well
3375.96|2.839|they like mistral's model because
3377.24|4.52|there's a magnet link and it's funny but
3378.799|4.76|like we're used to it and I still expect
3381.76|4.12|that to be the case for the next year or
3383.559|6.441|two with this pace just kind of being
3385.88|6.28|how it is and it's really fun to follow
3390.0|4.0|and I I just think that it's like not a
3392.16|3.639|time to be worried about scooping being
3394.0|3.839|scooped but to just kind of keep
3395.799|4.201|figuring out where you can contribute
3397.839|3.561|whether it's on evaluation or some of
3400.0|3.44|these other alignment methods that
3401.4|4.439|people have talked
3403.44|4.48|about so I have a quick thing on kind of
3405.839|3.801|current directions which we I'll come
3407.92|4.119|back to some of these data things that I
3409.64|4.56|mentioned multiple times and then we can
3412.039|4.641|get to
3414.2|4.8|questions um and mo the thing that
3416.68|3.72|people want to know a lot is are open
3419.0|5.319|models going to catch up to closed
3420.4|6.12|models my answer is probably not ever
3424.319|4.201|completely there will be some friction
3426.52|5.44|in the system by a time delay by which
3428.52|6.319|open models are closed and open model
3431.96|4.72|weights are not inherently unsafe the
3434.839|4.121|open versus Clos debate has mostly
3436.68|4.28|converged around this but given the
3438.96|4.079|territory that we're going with in AI
3440.96|4.2|where we're uncovering new capabilities
3443.039|4.201|we've never seen I think it's okay that
3445.16|3.76|if there's a few months wait before you
3447.24|4.2|have open weight so you can run on your
3448.92|5.48|laptop as we're discovering what AI can
3451.44|5.52|do if you look at someone if you look at
3454.4|4.0|Maxim's plot with trend lines showing
3456.96|3.639|them it shows that open models are
3458.4|4.28|getting closer but we're not really sure
3460.599|4.561|if open models will stay closer on
3462.68|4.119|chatbot arena in the long term there
3465.16|4.0|will always be an open and close
3466.799|4.28|category because there is demand to have
3469.16|4.48|models that are tuned to what you want
3471.079|5.201|them to do so this kind of Lins into my
3473.64|5.12|current directions data is the biggest
3476.28|3.92|limitation to alignment which is we have
3478.76|3.0|like two or three data sets that are
3480.2|4.44|driving all the research in open
3481.76|6.48|alignment and thropic HH data set for my
3484.64|6.88|friend deep got that uploaded back in
3488.24|7.4|2022 I think um Ultra feedback from open
3491.52|5.799|bmbb and nectar from Berkeley neus flow
3495.64|3.719|with the Starling models are what most
3497.319|4.24|people are focusing on we need more
3499.359|4.76|particularly if humans wrote it to add
3501.559|6.0|more diversity to our models and more
3504.119|6.0|robustness um DP o is continuing in an
3507.559|6.081|academic sense there is a comedy of
3510.119|5.761|papers extending DPO so there's um this
3513.64|4.159|is odds ratio preference optimization
3515.88|5.32|which doesn't need a reference model
3517.799|5.841|constrained DPO identity preference
3521.2|6.0|optimization I don't remember what bco
3523.64|6.28|is and then I can't pronounce the kto
3527.2|5.359|authors but like ktky something
3529.92|6.52|optimization from contextual in Stanford
3532.559|5.921|dno sdpo which is like sequential DPO
3536.44|4.84|and self-reward there are so many and
3538.48|4.52|that's good and that Trend will continue
3541.28|4.16|and at the same time we're seeing more
3543.0|5.039|model sizes most alignment happened at
3545.44|5.52|the seven or 13B scale I think there's a
3548.039|4.841|large drive to make smaller models
3550.96|4.28|aligned Google is releasing 1 billion
3552.88|3.88|parameter paramet models but it's also
3555.24|3.599|an opportunity where there aren't that
3556.76|3.64|many people playing in the space but
3558.839|3.361|it's something that a lot of people want
3560.4|3.88|just because to run these models locally
3562.2|4.28|making them smaller makes it way
3564.28|4.559|easier and then kind of running back to
3566.48|3.72|two themes throughout this lecture is um
3568.839|4.041|what are specific
3570.2|4.48|evaluations that we should be building
3572.88|4.6|and how do we personalize these models
3574.68|5.2|they kind of go hand inand these are the
3577.48|5.28|things that I'm thinking about I welcome
3579.88|5.52|feedback from them I kind of identified
3582.76|5.279|some people that I'm following to see
3585.4|6.08|where new models come out so I try to
3588.039|5.921|release models at ai2 um hugging face
3591.48|5.119|quickly turns around new aligned models
3593.96|4.32|Under The Zephyr brand these kind of
3596.599|4.121|Berkeley necks and necks of slow people
3598.28|5.039|building data sets and Starling models
3600.72|4.72|new research is a kind of they started
3603.319|3.52|as just the guy technium was fine-tuning
3605.44|5.28|models and now it's a company for
3606.839|5.401|fine-tuning models um open BMB in China
3610.72|3.16|has been doing a lot of preference data
3612.24|4.359|sets they recently released some data
3613.88|5.479|sets called Ultra interact which is some
3616.599|5.921|math preference data for doing rhf and
3619.359|5.801|fine tuning um Argilla is a startup
3622.52|4.839|around building tools to annotate data
3625.16|3.84|is focused on refence data and there's
3627.359|4.841|even just individuals that are driving
3629.0|4.799|this narrative so Maxim and John there's
3632.2|3.68|just a lot of people model merging is
3633.799|4.361|something I didn't talk about but it's
3635.88|4.4|kind of like DPO but taking it even
3638.16|4.52|farther where it's model merging is so
3640.28|5.039|accessible it doesn't you don't need a
3642.68|3.879|GPU to merge models it's a for Loop so
3645.319|4.081|people are going to try it and there's
3646.559|5.48|going to be iteration on it so in this
3649.4|4.28|alignment space never bet against people
3652.039|4.481|where they can just try things and see
3653.68|4.919|what's better excuse me and eventually
3656.52|3.88|learn that's what model merging is and
3658.599|5.96|it's going to be here to
3660.4|6.52|stay so thanks for listening um happy to
3664.559|5.0|take questions and thanks to my many
3666.92|4.439|teammates at hugging phas and ai2 that
3669.559|3.401|make it look like I did so many of these
3671.359|5.321|things but there's a lot of great
3672.96|5.68|contributors that underly this so I'll
3676.68|4.48|kind of slow down and drink some water
3678.64|4.04|and answer some questions but thanks for
3681.16|4.439|coming
3682.68|4.56|again yeah so the top question on scores
3685.599|3.561|if please rate them because it's easy
3687.24|4.64|for me to see them was about odds ratio
3689.16|4.8|preference alignment I think it being
3691.88|3.439|agnostic to the method is the best thing
3693.96|3.04|but you probably need to be good at
3695.319|6.561|engineering to get really good at one
3697.0|6.88|method to get um a specific model
3701.88|4.959|out and kind of getting these
3703.88|4.959|deliverables important to getting
3706.839|3.96|recognition I don't know if people can
3708.839|3.52|talk via microphone which is a much more
3710.799|5.32|natural experience but I'm just going to
3712.359|3.76|keep talking to myself
3718.0|3.279|uh there's a question around the future
3719.319|4.641|of alignment given simple methods can
3721.279|5.481|circumvent fine-tuning um I think that
3723.96|4.159|the future of alignment is like safety
3726.76|3.68|is not the only thing that matters
3728.119|4.16|there's a lot of Promise showing that
3730.44|3.919|alignment helps with how much people
3732.279|4.361|like the model so how much rhf improves
3734.359|5.401|the user experience and how much it
3736.64|5.76|improves code and math abilities so like
3739.76|4.92|while everyone hates qar like qar has
3742.4|5.199|some things to guide towards which are
3744.68|5.599|using synthetic data RL search and stuff
3747.599|5.52|to improve the raw capabilities rather
3750.279|2.84|than just talking about
3755.44|3.32|safety okay
3763.319|5.641|onwards yeah someone people are asking
3765.68|5.24|about the fact that llama 3 uses llama 3
3768.96|5.68|said that they use instruction fine
3770.92|5.8|tuning rejection sampling DPO and PP PO
3774.64|3.439|for their aligned models which I was
3776.72|3.0|like I don't know how they're using all
3778.079|4.0|of these things but I think they're
3779.72|5.079|Shifting the abilities incrementally to
3782.079|5.121|provide nice initialization for the next
3784.799|5.0|method and to keep being able to use new
3787.2|5.28|human data and make the metrics go up I
3789.799|4.48|think over time that will become simpler
3792.48|4.16|in the future meta will not have this
3794.279|4.201|convoluted five-stage multimethod
3796.64|4.28|process and we'll figure out a way to
3798.48|5.559|distill that to one
3800.92|5.72|algorithm um pitfalls of synthetic data
3804.039|4.441|is repetitiveness and not robust
3806.64|6.32|distributions so most of the synthetic
3808.48|8.24|data sets out there are about like they
3812.96|6.399|have very similar things in there and
3816.72|4.2|that is like the models are going to
3819.359|3.92|generalize less well and probably get
3820.92|4.84|less well less boosts from alignment
3823.279|5.28|training if there's not this kind of
3825.76|4.799|General Improvement to capabilities so
3828.559|5.52|um we want to take some imperson
3830.559|5.28|questions um oh yeah that's much better
3834.079|5.321|does anyone have some inperson question
3835.839|3.561|questions to ask
3839.92|3.0|Nathan
3844.72|5.16|okay hi thank you so much um for the
3847.799|4.601|talk what do you think are the greatest
3849.88|5.04|hotspots of like research or work in
3852.4|4.399|terms of personalized language models
3854.92|4.32|and where do you see them having the
3856.799|2.441|most
3859.44|4.52|impact this is one of the things that
3861.52|4.759|I'm excited about the local llm
3863.96|4.639|community like I'm not
3866.279|5.04|particularly ideologically aligned with
3868.599|4.24|like the effective accelerationist stuff
3871.319|3.561|but I do think that they have a lot of
3872.839|4.601|drive to create a language model that
3874.88|4.28|they like to use so that therefore
3877.44|5.28|there's going to be things we learn from
3879.16|5.36|them and that's kind of a classic like
3882.72|3.28|how to integrate multiple communities so
3884.52|2.88|it's like academics aren't used to
3886.0|4.4|looking there but I'm sure there's a lot
3887.4|4.959|to learn there yeah I guess there were
3890.4|6.0|multiple questions about advice for the
3892.359|5.881|field whether it's like grad school or
3896.4|4.36|I'll give my advice with the Caged
3898.24|4.359|advice that is that you should be very
3900.76|4.079|wary of listening to people's advice
3902.599|3.68|because it based on their situation but
3904.839|3.121|I think that the most important thing
3906.279|3.681|you can do when the field is crazy is
3907.96|4.24|just keep trying to develop skills and
3909.96|3.76|keep trying to build something that you
3912.2|2.879|think matters because it's like at the
3913.72|3.76|end of the day that's what you're making
3915.079|4.76|progress on and you'll never be able to
3917.48|4.079|keep track of everything and that's okay
3919.839|3.48|and I can't keep track of everything and
3921.559|4.28|I'm still trying to train models and
3923.319|4.601|build data sets so it's just like like
3925.839|4.96|school is about learning to do research
3927.92|4.8|and that still has value but industry is
3930.799|4.121|also fun if you want to do a startup so
3932.72|4.639|it's there's not like here's think about
3934.92|5.72|what you want to do all I think someone
3937.359|6.92|sent me you can hear me right someone
3940.64|5.32|sent me a question through Zoom um a
3944.279|3.601|quick question you indicated that making
3945.96|3.96|lower methods work with reinforcement
3947.88|5.32|learning is tricky do you think lore
3949.92|6.119|methods work well with DP or its
3953.2|4.919|variance I haven't seen it be
3956.039|4.401|particularly successful so that's that's
3958.119|4.92|my general role of thumb is I really
3960.44|4.2|wait to go deep into a method until
3963.039|5.401|there's been a model release that's in
3964.64|6.56|like the relevant ballpark with that
3968.44|4.399|type of with that method so the fact
3971.2|4.079|that it's been around for so long and
3972.839|4.121|hasn't happened could be a blind spot
3975.279|4.721|but I think that there's some weirdness
3976.96|3.04|that's preventing it from
3980.319|5.52|happen great okay another one
3983.52|5.12|um thank you for the talk you mention
3985.839|5.321|GT4 being used as an evaluation metric
3988.64|6.04|but it causes data contamination what
3991.16|3.52|are some ways to mitigate
3994.96|6.24|this oh man yeah I mean this is why it's
3998.0|4.799|like nice to have human evaluation but I
4001.2|4.159|I don't know if I have an answer at this
4002.799|4.56|point I'm kind of fried from Reading
4005.359|3.601|llama 3 stuff and giving this lecture
4007.359|3.96|but that like that's the fundamental
4008.96|4.839|problem is how to disambiguate various
4011.319|4.681|evaluation like various biases and
4013.799|3.32|evaluation and still get the signal out
4016.0|4.279|of
4017.119|5.72|them right okay one more
4020.279|5.401|um give me a
4022.839|5.72|second for stuff like llama 3 training
4025.68|4.76|on so many tokens like 15 trillion would
4028.559|4.28|that actually make it harder to align
4030.44|5.599|this model without losing some
4032.839|6.321|capabilities uh learn from this
4036.039|5.08|overtraining um it's not technically
4039.16|4.48|overtrained but
4041.119|4.0|every every model will have kind of a
4043.64|3.479|different point by which they're
4045.119|3.281|released East so it's like that's why
4047.119|3.48|you'll need a different learning rate in
4048.4|5.32|back sles and data sets for models so
4050.599|7.161|you will need a different um kind of way
4053.72|7.599|of continuing it but that that is a
4057.76|4.96|common confusion on like how like I I
4061.319|4.161|mean I don't even have an intuition for
4062.72|4.52|it just to know that I have bought this
4065.48|3.68|thing in the past and been proven wrong
4067.24|4.24|about it but it's like it's not that
4069.16|3.72|it's overtrained or harder to fine-tune
4071.48|3.559|it's just that there's more information
4072.88|4.84|into the model and as you continue to do
4075.039|4.601|this the model can keep learning it just
4077.72|3.559|takes more and more data to get marginal
4079.64|3.959|improvements so meow is willing to
4081.279|4.481|invest more money into the model to make
4083.599|4.72|it just a bit better but that shouldn't
4085.76|5.64|that should only help that shouldn't
4088.319|5.161|hurt right great uh here's another one
4091.4|4.799|um do you think synthetic data
4093.48|5.64|generation like cosmop is the way to go
4096.199|4.841|for making controlled or trusted domain
4099.12|4.719|specific
4101.04|4.199|models I think it'll be very good I also
4103.839|3.561|think it's a good way to get around the
4105.239|4.641|fact that
4107.4|4.839|um like Google is paying Reddit $60
4109.88|3.839|million a year to use their data so that
4112.239|5.52|we can no longer train on the newest
4113.719|6.44|Reddit data I think that um cosmop media
4117.759|3.96|and synthetic data sets at a large scale
4120.159|5.12|can be a way around this and there are
4121.719|3.56|rumors that industry is doing something
4130.359|7.041|similar give me a second I think there's
4133.759|3.641|one that I missed
4139.679|4.48|um um could you please share some
4141.88|4.279|insights on why you are finding po
4144.159|6.2|better than
4146.159|6.761|DPO it's mostly like it it ends up
4150.359|4.641|extracting more the data so it's like
4152.92|4.64|the benchmarks end up being a little bit
4155.0|5.04|better if we get it set up correctly
4157.56|4.44|with the same like starting point so
4160.04|3.56|it's like we you choose a set of
4162.0|4.759|evaluations that you care about and you
4163.6|5.199|look at them and through fine tuning the
4166.759|3.641|it's primarily a group of great grad
4168.799|3.56|students doing this is just running a
4170.4|4.12|ton of models and trainings and they're
4172.359|4.8|seeing that PP over liely can be doing a
4174.52|4.36|little bit better and it's like this is
4177.159|5.16|this is the fine margins that a lot of
4178.88|3.439|AI works on
4182.719|6.801|nowadays great um do you foresee a
4187.08|5.199|better evaluation method to be
4189.52|5.4|determined by a stronger or more
4192.279|5.601|specialized model which means world
4194.92|4.96|based are Dead
4197.88|4.96|Forever
4199.88|4.72|um maybe I try not to say no to things
4202.84|3.76|this is becoming philosophical which is
4204.6|3.68|like I'm trying not to say no to things
4206.6|3.599|in the language model space with how
4208.28|5.919|fast things are progressing it's like I
4210.199|6.201|should try not to bet against progress
4214.199|5.161|continuing this goes for pre-training
4216.4|5.04|and alignment and it's like at multiple
4219.36|3.56|stages in the last few months come to
4221.44|3.12|benefit me so it's like if you just
4222.92|2.96|assume that things will get better and
4224.56|3.52|they will work
4225.88|5.68|it it's like just makes it a little bit
4228.08|3.48|easier to wrap your head around
4232.8|6.76|things one last one here
4235.64|3.92|from um give me a
4239.719|6.041|sec at its cor and llm is trying to
4242.76|5.12|approximate a complex distribution would
4245.76|4.2|you say that alignment is the process of
4247.88|4.319|squashing specific parts of this
4249.96|5.239|distribution according to what humans
4252.199|3.0|prefer
4258.4|3.88|yeah I think that's phrased generally
4260.0|4.719|enough that I could get behind it it it
4262.28|5.52|is it's like alignment is about changing
4264.719|4.881|the distribution and it's it can be
4267.8|3.56|multiple tokens of it's like a multi-
4269.6|4.079|turn prediction like RL is not just
4271.36|4.879|autor regressive like it can be these
4273.679|4.401|kind of multi-ring different things that
4276.239|4.681|are getting shifted around and it's a
4278.08|2.84|really different loss
4281.88|6.44|function here's one from um how do you
4285.64|5.559|envision the usage of watermark for both
4288.32|5.56|open and closed uh language
4291.199|5.761|modk I think it's a lot of times feels
4293.88|5.0|like a losing battle um I think that a
4296.96|3.6|practical solution in the future is that
4298.88|4.52|a lot of if you want to prove something
4300.56|4.76|that is human made you can prove that it
4303.4|5.0|was generated by a human by having a
4305.32|5.08|certain tool rather than trying to
4308.4|4.799|understand if a specific content was
4310.4|5.08|made by an AI so the Assumption will be
4313.199|5.801|that all content was made by an AI less
4315.48|6.12|proven to be human is not what I would
4319.0|5.88|consider a sociologically like good
4321.6|6.68|answer it just seems like a practical
4324.88|5.52|one makes sense I think we have a few
4328.28|4.879|more minutes so if anybody has any last
4330.4|5.04|minute questions feel free to send them
4333.159|4.441|um over to me on the zoom
4335.44|5.4|chat yeah this is much that was much
4337.6|3.24|better than me half reading the
4341.4|5.239|question all right here's one um what
4344.44|4.36|are your thoughts different optimization
4346.639|3.961|functions to train large language models
4348.8|4.96|rather than using
4350.6|5.32|mle what could be good research um
4353.76|4.24|directions
4355.92|5.68|through I think this is the whole idea
4358.0|5.239|of what rhf represents unless why like
4361.6|3.8|if you ask people have been in NLP
4363.239|4.841|longer one of the most compelling
4365.4|4.799|Arguments for rhf for me is like you now
4368.08|4.04|have extreme flexibility on the loss
4370.199|4.201|function while we were kind of limited
4372.12|3.72|on what our regressive losses could do
4374.4|2.96|so there's kind of arguments that it's
4375.84|3.12|like why is there any limit if we could
4377.36|4.24|just keep doing more and more tokens of
4378.96|5.88|RL training it's a really like General
4381.6|4.96|framing but like rl's loss function it
4384.84|3.64|it you make it so that the training of a
4386.56|3.52|language model can incorporate many
4388.48|3.56|different things and that's very
4390.08|4.28|exciting that could be like the 10-year
4392.04|2.32|goal of
4394.679|5.721|rhf to what
4397.56|4.159|extent is trading on adversarial data
4400.4|3.56|effective for defending against
4401.719|4.841|Crescendo and other simple multi-turn
4403.96|4.44|attacks
4406.56|3.56|I haven't spent as much time on safety
4408.4|4.68|as I would want to but I think that it's
4410.12|4.68|like it'll be this Everlasting dance
4413.08|3.28|where if you have example data you can
4414.8|3.839|defend against it but it will not be
4416.36|3.92|impossible to generate new data so it
4418.639|3.761|mostly comes down to the use case that
4420.28|3.32|you're looking at protecting so if you
4422.4|3.16|want to protect something really
4423.6|3.639|important you need to have layers on
4425.56|3.32|that that are not just sensitive to a
4427.239|3.96|new prompting technique but like limit
4428.88|5.319|what the model can do that's kind it's
4431.199|4.681|like a use focused theme well the kind
4434.199|4.761|of whole like security is a very
4435.88|3.08|complicated thing
4440.239|5.321|otherwise here's one on
4442.56|3.0|quantization
4445.679|4.0|um do you see potential in quantization
4448.48|4.8|methods such as
4449.679|6.721|bitet um like 1.58 bit if so do you
4453.28|6.68|think bitnet will become
4456.4|4.92|popular I have no idea I wouldn't Ru
4459.96|6.16|this is what I mean it's like okay
4461.32|4.8|sounds cool wouldn't rule it out
4466.96|4.32|you think there is a need or a way to
4468.84|6.48|control large scale data extraction from
4471.28|4.04|large language models like cosmop
4477.56|4.28|pedia I do think there's a lot of wills
4479.88|3.52|and a lot of ways to explore making the
4481.84|3.359|synthetic data better I think it's very
4483.4|5.64|early I have a project that's going on
4485.199|5.96|it and it it is one of the few ways that
4489.04|3.88|can generate more tokens which is like
4491.159|3.241|like like people are actually running
4492.92|2.759|out of tokens especially if you try not
4494.4|3.56|to train on things that you're not
4495.679|4.361|supposed to train on it's like like then
4497.96|3.56|you can just generate more data and as
4500.04|4.76|we've seen with llama if you have the
4501.52|3.28|compute more data will help
4507.32|7.56|you let's see selfplay like things any
4512.28|5.32|chance um you can kind of expand upon or
4514.88|6.48|share your opinions on self-play likee
4517.6|6.16|things like open AI super alignment
4521.36|4.08|work I think people will keep using
4523.76|4.2|language models in the loop training
4525.44|4.36|other language models but it's it's a
4527.96|5.4|kind of broad field that doesn't have
4529.8|3.56|full agreement on how to do
4536.159|6.0|it okay cig I think we're pretty much
4538.92|5.0|out of time so um if folks want to get
4542.159|5.841|in touch or have more questions can they
4543.92|6.239|email you or yeah read great but yeah
4548.0|5.199|thanks so much again um for taking the
4550.159|5.281|time and for giving us such a great talk
4553.199|4.761|um so yeah give it
4555.44|4.36|forthan and I think the slides as well
4557.96|4.52|as the hugging face collection are all
4559.8|4.8|posted on our website as well as um
4562.48|4.48|Discord so in case anybody wants to
4564.6|2.36|follow
4568.4|5.96|along sounds good thanks a lot for
4570.6|7.039|having me no worries see everyone soon
4574.36|3.279|bye bye