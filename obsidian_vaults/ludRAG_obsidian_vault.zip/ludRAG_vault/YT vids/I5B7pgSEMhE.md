start_time|end_time|text
1.24|2.92| Yeah, let's start this lecture by talking about common
4.16|3.88| applications of convolutional neural networks. And instead of
8.04|2.88| saying convolutional neural networks all the time, which is
10.92|2.96| pretty hard for me with my German accent, I will just
13.88|4.88| abbreviate them as CNN. So CNN, that's a common abbreviation.
18.76|3.8| Another common one is saying confidence. So either one is
22.56|4.24| fine. Both are commonly used in the literature. Alright, so what
26.8|4.88| can CNN do the simplest application of CNNs would be
31.72|3.96| image classification. So here's an example of binary
36.04|7.44| classification. It's similar to what we discussed for logistic
43.52|5.28| regression. Except now, of course, we have images as input
48.8|3.48| instead of simpler, let's say flower classes. So here, that's
52.28|5.96| the binary classification problem with cats versus dogs.
58.44|4.4| And yeah, the input image is put into the network. There are
62.84|2.52| convolutional layers. In the end, they're usually fully
65.36|2.72| connected layers. They're not shown here, we will see another
68.64|3.64| type of architecture later that shows the fully connected layer
72.28|4.1| more explicitly. But then yeah, it produces a probability score
76.38|4.38| that this image is a cat. And yeah, you can also extend that,
80.76|3.0| of course, to multi class classification using a softmax
83.76|3.04| layer that we also discussed before. So essentially, it's the
86.8|2.96| same thing as we did with multi layer perceptrons, except that
89.76|3.24| we have convolution layers, which we will discuss in more
93.0|5.8| detail in this lecture. Another common application of CNNs next
98.8|4.6| to regular classification is object detection. So here, this
103.4|3.68| is like you can think of it as a mix between classification and
107.08|4.24| on object detection, because usually, you predict a bounding
111.32|3.28| box, but you also predict a class label corresponding to
114.6|3.68| the bounding box. So yeah, you have essentially two tasks. So
118.28|3.84| one is essentially identifying objects, for instance, here, a
122.12|3.36| car, another car, but then also assigning the class label to it.
125.72|3.12| So the network essentially learns how to draw these boxes.
129.52|3.4| So you can think of it as a type of regression task, where you
132.92|3.76| can learn these two coordinates here, and these other
136.68|2.04| coordinates, you can derive them from the other two
138.72|4.8| coordinates. So here, you're essentially learning, learning
144.56|3.28| the bounding box construction, but then also assigning the
147.84|3.76| label. One common example of that is YOLO, you only look
151.6|3.2| once, but then of course, yeah, multiple different methods for
154.8|3.8| that also. So this is like the original YOLO paper, I just
158.6|2.6| referenced it here, because it might be the, I would say
161.2|3.32| easiest starting point if you're interested in that topic. So we
164.52|3.56| won't be talking about this in this class, because yeah, there
168.08|2.8| are so many other topics to talk about, it is a slightly out of
170.88|3.12| the scope of this class. But if you're interested, this is a
174.16|5.48| good paper to start with. So related to object detection,
179.64|4.72| there is also the task of object segmentation. It's relatively
184.36|4.28| similar, but in addition, you have to identifying what instead
188.64|2.84| of into identifying just a box. So here, for reference, the
191.48|4.64| boxes are also shown what the task here is to get to kind of
196.28|3.2| have an exact mask for that object. So if this is a person,
200.0|2.28| instead of having just the bounding box around the person,
202.28|4.32| you can see it's also yeah, extracting this mask here. So
206.6|3.84| it's in that way, a little bit more of a precise version of
210.48|5.08| object detection. So here again, as a paper or mask RCN, that's
217.16|2.96| the mask RCN is like the I would say one of the most traditional
220.12|3.32| methods for this. Again, that's a good starting point if you are
223.44|4.0| interested in that topic. There were a few students who were
227.72|3.48| you know, or could benefit from object segmentation in their
231.2|4.84| class project. And I also shared some tutorials for how to do
236.04|3.52| that in pytorch with those students. But again, this is, I
239.56|2.52| would say slightly out of the scope of this class, it's more
242.08|3.36| like an advanced topic. So in this class, we won't be talking
245.44|2.76| about this in too much detail. I just wanted to mention that this
248.2|5.36| also exists. Yeah, another task that is something that I have
254.0|4.08| worked on pretty extensively in the past, that's related to face
258.12|4.4| recognition. So face recognition, it's an another
262.52|4.12| task, it's somewhat related to classification, but not quite.
266.8|4.2| So here, it's really more about pairwise comparisons. I mean,
271.0|4.4| you can phrase image recognition or face recognition, sorry, face
275.4|2.96| recognition as an image classification task. So if the
278.36|4.6| task is to identify a person, you can have it as a
282.96|4.76| classification task, where I'd say there are 10,000 potential
287.72|3.24| people and you want to know who that is in that picture compared
290.96|4.24| to the database of 10,000 images. But then it would be an
295.32|4.52| image classification class task with 10,000 classes, which would
299.84|3.28| be relatively expensive computationally. And also,
303.12|2.88| because you don't have many examples per class, it would be
306.0|4.72| really tedious to train such a system. So usually how people
310.76|5.52| approach face recognition is by something called a pairwise or
316.28|4.12| triplet loss. So in that way, what you learn is you learn a
320.48|3.24| certain type of similarity score. So if you have two input
323.72|3.72| images of the same person, it should give you a high
327.44|5.44| similarity. And if the pictures depict different people, it
332.88|3.08| gives you it should give you a low similarity score. And then
335.96|3.84| you can set a threshold and say, if the similarity score is above
339.8|2.4| a certain threshold, then it's the same person. Otherwise,
342.2|2.56| it's a different person. And for that, I mean, there are also
344.76|2.6| many, many different methods. One traditional method would be,
347.36|3.28| for example, using Siamese networks, where you basically
350.64|5.4| have two convolutional networks, and they produce embeddings,
356.44|2.6| like feature representations of that image. And then based on
359.04|3.64| the feature representation, you compute a similarity, if they
362.68|4.56| are similar to each other, it could be, for example, lower to
367.24|4.96| distance or a small cosine angle, then these are the same
372.2|3.72| person. And otherwise, they are different people. But yeah,
375.92|3.12| again, this is another topic that might be out of the scope
379.08|3.1| of this class. In this class, we will be mainly focusing on
382.18|3.42| convolutional networks for classification. Except there's
385.6|2.84| one more topic we will use later on in this class with
388.64|3.2| convolutional networks. And that is generative adversarial
391.84|3.48| networks. So we can also use convolutional networks for image
395.36|5.76| synthesis in the context of a so called generative adversarial
406.36|3.48| network, and generative adversarial networks are
409.84|4.08| essentially networks that can generate data. So I will explain
413.92|3.16| that in more detail in a dedicated lecture dedicated to
417.4|3.2| generative adversarial networks. But here is just the big big
420.6|3.64| picture outline. So here how that works is you have a
424.24|5.2| generator and a discriminator. And the generator takes in some
429.44|4.84| noise. So usually you sample from a random distribution from a
434.28|2.52| normal distribution, a random vector, and then you put it
436.8|5.2| through a convolution network that constructs an image from
442.0|3.6| this noise vector. So in that sense, it's more like an inverted
445.6|5.96| convolutional network. So it will output generated image. And
451.56|3.8| then the discriminator has to say whether this image is real
455.36|5.04| or generated. So you train the generator so that it fools the
460.4|3.88| discriminator into thinking that this generated image actually
464.28|5.88| comes from the training set. And then the discriminator tries to
470.16|3.36| distinguish between generated and real images better. So you
473.52|3.12| train the discriminator to become better at distinguishing
476.64|3.36| those. And you train the generator to become better at
480.0|3.68| fooling the discriminator. And you do that. It's basically like
483.68|4.12| a game, a min max game. And you do that until the generator is
487.8|3.72| able to produce realistic looking images. But these are
491.56|2.84| images that are, for instance, not contained in the training
494.4|2.64| set, they are more like interpolated, or they are
497.16|3.4| synthesized. So they might look similar to the training set
500.56|3.86| images, but they are usually images that are not one of the
504.42|3.38| training set images. So why is that useful? Yeah, you can do a
507.8|3.72| lot of fun things with that. And also, I, for example, seen
511.52|4.2| recently, people started using that to make synthetic training
515.72|3.8| examples. So for example, produce larger training sets.
519.76|3.8| But you can also do that for image manipulation. We also used
523.56|3.6| or use that for a project called privacy net where we were
527.16|4.04| removing sensitive or not so sensitive, but private
531.2|3.84| information from images, or images that you have for face
535.04|2.72| images where people, for instance, could use that
537.76|5.54| information for profiling. And we used GANs to kind of alter
543.3|4.42| the images such that they still look like images of real people,
547.72|2.88| but where the sensitive information is hidden. And yeah,
550.6|2.92| there are lots of applications of GANs. And that is also some
553.52|3.36| topic that we will discuss in more detail later. So yeah, this
556.88|2.56| video hopefully gave you a big picture overview of all the
559.44|3.84| different things you can do with CNNs. So in this lecture, we are
563.28|4.28| now focusing specifically on image classification. Because
567.56|2.52| yeah, this is still an introductory lecture. So we
570.72|2.4| can't do everything at once. Let's start with the simplest
573.12|13.8| task.