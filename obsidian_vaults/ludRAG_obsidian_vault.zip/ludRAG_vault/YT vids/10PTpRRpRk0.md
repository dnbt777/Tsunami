start_time|end_time|text
1.82|2.22| Yeah, hi, everyone. I hope you had a good weekend. And
4.04|3.52| everything went smoothly with the homework one submission. I
7.56|3.32| noticed that there were still some challenges around the
10.88|3.68| understanding of single layer neural networks. So today, we
14.56|3.2| will have another chance to take a look at it. So today, I want
17.76|3.16| to talk about logistic regression as a single layer
21.04|3.14| neural network. And that really helps, I think, with understanding
24.18|3.78| the basic concept of a forward and a backward pass. And then we
27.96|2.86| will also in this lecture, generalize this concept from
30.82|3.22| binary classification to multiclass classification.
34.32|3.44| Because yeah, there will be also later on more multiclass stuff
37.76|3.24| going on. Because in real world scenarios, we often have data
41.0|2.8| sets where we have more than two classes. So in this lecture, we
43.8|2.16| will talk about logistic regression as a binary
45.96|3.84| classifier, and then multinomial logistic regression, also known
49.8|4.28| as softmax regression, which will be a good starter for then
54.08|2.64| understanding multi layer perceptrons, which is the topic
56.72|2.88| of the next lecture. All right, because there are lots of things
59.6|1.56| to talk about, let's get started.
63.74|2.7| Yeah, let's briefly recap what we have done in the previous
66.44|3.36| lectures. So one thing we did in the previous lectures was
69.8|3.52| implementing the perceptron that's already long time ago, it
73.32|3.96| had convergence issues, if data was not all the classes were not
77.32|4.2| linearly separable. But we solve that convergence issue by using
81.52|3.52| Adeline, which was based on a mean squared error loss function
85.04|4.2| and gradient descent. And then last week, we conceptualized
89.28|3.56| gradient descent using computation graphs. So if you
92.84|5.44| recall, that is how Adeline looked like. And here is a data
98.28|3.28| set example that could, for example, not be easily solved
101.56|2.64| by a perceptron. I mean, a perceptron would also be able to
104.2|2.36| come up with a decision boundary, but it would never
106.56|2.84| converge, which is a little bit trickier to handle in practice
109.4|3.28| because the decision boundary would jump back and forth if we
112.68|4.68| if we train it here, because we have these data points like this
117.36|3.48| one, which are outliers. So in this case, on this one, you can
120.84|4.0| never get a perfect classification with 100%
124.84|3.28| accuracy, if you have a linear decision boundary in this case,
128.56|2.24| and a perceptron would have the challenge that it would flip
130.84|6.28| back and forth. So now, we kind of continue with the concept of
137.12|2.88| Adeline, but we make some improvements. So one of these
140.0|4.52| improvements is to use a loss function called cross entropy,
144.76|3.56| instead of the mean squared error. And another improvement
148.32|5.12| is to extend this neuron model to multiclass classification. So
153.44|2.96| for that, we will be using multiple output nodes and a so
156.4|4.2| called softmax activation function, I briefly sketched it
160.6|4.0| here on the left hand, in the left hand corner, we will talk
164.6|3.88| about this in more detail later in this lecture. But essentially,
168.48|3.92| we will have multiple outputs here. And that will allow us to
172.76|4.44| classify data sets that have more than two classes. So here's
177.24|4.24| an example of the iris data set, where we have three flower
181.48|5.4| classes, Iris versicolor, the Guineca and setosa. Before, we
186.88|1.96| could only do binary classification. Now you can see
188.84|3.12| that could be three decision boundaries. So one way would
191.96|6.0| be here, this way, we have three linear lines or same model, the
197.96|2.48| data looks a little bit different. It can also look like
200.48|4.72| this here. Those are both so called softmax regression models,
205.48|4.64| which we will be talking about today. So yeah, just to give you
210.12|3.36| a big picture overview of all the topics, it looks like a lot
213.48|3.96| of nine topics. However, I think they will be relatively short.
217.64|2.44| So I hope they will be short, like shorter videos, like 10
220.08|3.08| minutes max, but we will see videos always turn out to be
223.16|4.72| later, longer in practice than you might think when you make
227.88|4.28| them the slides. So the topics I have in mind for today are
232.4|3.28| basically discussing logistic regression as an artificial
235.72|4.08| neuron. So showing you how logistic regression relates to
239.8|5.68| the concept of an align. And then we will introduce the loss
245.48|2.76| function of logistic regression, which is the negative log
248.24|4.32| likelihood. And then also, I will show you how we can use
252.56|5.64| gradient descent, which we talked about before, we will use
258.24|3.64| gradient descent to train the logistic regression model. And
261.88|3.76| then here, there's just some terminology called the logits
265.64|3.48| and cross entropy. These are some terms you will find in deep
269.12|3.6| learning. Yeah, and a lot of deep learning concepts,
272.72|4.04| actually. So logits and cross entropy are like, I would say,
276.76|5.24| jargon in deep learning. So we will just briefly see what these
282.0|4.72| terms mean. And yeah, then I will show you a logistic
286.72|5.16| regression code example. So all this stuff here, this is about
291.92|5.72| the I would say regular, or let's call it binary, binary,
299.76|6.52| logistic regression. So that's the original logistic regression.
306.28|3.6| For binary classification, only for two classes. And then this
309.88|8.52| one here, or the second part would be multi class, or also
318.4|12.44| called multinomial. Oops. Yeah, logistic regression. And another
330.84|3.96| word for multinomial logistic regression is softmax
334.8|3.72| regression. So we will talk about that. And for that, so
338.52|3.6| here, first, I will introduce the model. For that, we will
342.12|3.2| need something called one hot encoding, which I will then
345.32|3.16| introduce, it's just like a format that we can use to
348.48|4.24| represent categorical data. And then I will also introduce the
352.76|3.32| multi category cross entropy loss, which is an extension from
356.08|5.36| the binary cross entropy here. Then we will talk about the soft
361.44|2.84| max regression learning rule, essentially gradient descent
364.28|5.24| again, no for softmax regression. And then I will
369.52|3.44| also show you a code example. And then in the next lecture on
372.96|2.96| Thursday, what we will do is we will just add a hidden layer to
375.92|2.48| the softmax regression model. And then we have a multi layer
378.44|4.4| perceptron or first, on small deep neural network. Alright, so
382.84|3.04| with that, let's get started with logistic regression as an
385.88|11.52| artificial neuron.