start_time|end_time|text
1.04|0.88| Yeah, hi everyone.
1.92|3.0| So this week I have a bunch of hands-on stuff
4.92|2.7| related to neural network training.
7.62|2.46| So first of all, there was the new PyTorch release
10.08|2.2| which I want to briefly talk about.
12.28|2.64| And also I saw a really cool article
14.92|2.26| regarding tips for training neural networks.
17.18|2.86| And since I'm currently grading your class projects,
20.04|1.9| I thought it might be a good opportunity
21.94|2.48| to go through some of these tips and tricks
24.42|2.52| for helping with neural network training.
26.94|1.56| So with that, let me get started
28.5|2.1| with our stuff in the news for this week.
31.98|2.2| Yeah, probably the coolest thing that happened
34.18|2.08| in the context of deep learning this week
36.26|3.1| was that there was a new PyTorch release this week.
39.36|1.56| So I usually, yeah, I really like that
40.92|1.88| if there's a new version that comes out,
42.8|1.64| it's maybe every half a year or so,
44.44|3.36| because yeah, there are usually a lot of cool new features
47.8|3.28| and improvements that are useful in practice.
51.08|3.2| And since this class is also focused on PyTorch,
54.28|1.84| I thought it might be worthwhile
56.12|2.8| mentioning some of these new additions.
58.92|3.68| So there's an article that they put together
62.6|3.76| with the highlights in this new 1.8 release.
66.36|1.32| So if you're interested,
67.68|3.52| this one summarizes most of the relevant changes.
71.2|2.96| A more detailed list listing all the changes
74.16|2.48| and additions is on GitHub.
76.64|3.08| So you can go here if you want the more detailed list,
79.72|1.52| but it's a long list.
81.24|3.24| I think there were about 700 commits
84.48|2.68| like feature changes or feature additions
87.16|1.8| and things like that.
88.96|2.04| If I were to highlight a few,
91.0|3.6| I have these three as I would say my personal highlights.
94.6|5.0| So one is that they now make it easier to use AMD GPUs.
101.16|2.32| So competition is always good for business, right?
103.48|2.0| So it's good that also other cards
105.48|1.9| other than Nvidia are supported,
107.38|3.5| which I think is nice for those people who have,
110.88|2.1| let's say a gaming PC or something like that
112.98|1.9| with an AMD graphics card.
114.88|3.12| So now you can also use those graphics cards.
118.0|3.72| So this is supported by a library called Rockum.
121.72|3.48| It's like CUDA, but for AMD GPUs.
125.2|2.68| There was support for AMD GPUs before,
127.88|1.78| but it was like a little bit of a hassle.
129.66|3.66| You had to compile PyTorch yourself and was not so easy.
133.32|4.36| And now what's new is that they are making the binaries
137.68|2.24| directly available from the installer menu.
139.92|3.46| So you can now also set it up more conveniently.
144.5|3.22| Now it's also possible to fit larger models onto GPUs
147.72|2.22| without any external libraries.
149.94|3.6| So recall last week, we talked about fair scale
153.54|4.42| and Microsoft deep speed, which were two libraries
157.96|3.8| you're providing functions to distribute a model
161.76|1.96| across multiple GPUs.
163.72|3.0| So there were already something like a data parallel
166.72|4.72| in PyTorch, so one is data parallel,
171.44|4.4| and one is distributed data parallel.
175.84|1.92| Let's just call it TP.
177.76|3.36| And these were methods for splitting many batches
181.12|3.2| across multiple GPUs and then training in parallel.
184.32|2.84| But this wouldn't help with a problem where a model
187.16|2.04| is too big for a given GPU.
189.2|3.08| One method that we discussed was this checkpointing,
192.28|2.76| but the checkpointing would be using a single GPU.
195.04|3.92| Now there's a way that you can conveniently put
198.96|2.32| a single model onto multiple GPUs
201.28|1.56| and then run it in parallel.
202.84|1.64| I will show you an example.
204.48|1.24| So that's actually pretty cool.
205.72|2.54| So you don't need any external libraries for that.
208.26|2.68| There are now some features that yeah,
210.94|2.62| support it directly in PyTorch.
213.56|2.64| And then also what's kind of nice or what will be nice
216.2|5.0| in practice is that the torch lin-alc module got extended.
221.76|1.92| I think in this release, it was even created.
223.68|2.16| I was using a pre-release version.
225.84|1.84| So I'm not sure if it was actually created here
227.68|2.84| or just modified, but in any case,
230.52|4.16| so there are no additional linear algebra functions
234.68|1.72| that are usually only NumPy.
236.4|2.92| So now we don't have to switch so often
239.32|2.72| between NumPy and PyTorch when we train our neural networks
242.04|2.26| if you need something like determinants
244.3|1.9| or eigenvalues and so forth.
246.2|2.6| So that's also making life more convenient.
248.8|5.0| So regarding the PyTorch binaries for AMD GPU support,
254.28|2.48| I checked actually the installer menu.
256.76|2.84| So good news is like I said, it's available now.
259.6|2.0| It does not seem to be available yet though
261.6|2.84| for Mac and Windows only for Linux right now.
264.44|2.64| But I think still this is pretty exciting
267.08|3.72| because I'm pretty sure these will be also added over time.
270.8|1.3| So it's probably just a matter of time.
272.1|2.58| So things are developing in a nice direction
274.68|5.0| where you can now directly install the wheel
279.84|5.0| via PIP for RockM or AMD support if you are on Linux,
284.96|2.08| at least, and I'm pretty sure Mac and Windows
287.04|1.76| will probably also follow sometime.
290.76|2.0| By the way, I updated one of my computers
292.76|3.32| with PyTorch 1.8 the other day.
296.08|2.88| And yeah, I was just looking at this.
298.96|2.44| I was really surprised about the size.
301.4|2.76| It's now 2.48 gigabytes.
304.16|2.88| So it's kind of impressive what's all in that library.
307.04|2.24| So one thing, I'm not sure if I mentioned that in class,
309.28|4.44| but so when you install PyTorch, the GPU or CUDA version,
313.72|2.28| it will bring its own CUDA,
316.0|2.92| which is done to make things more convenient.
318.92|2.96| So before that, when I used,
321.88|2.52| I mean like it was like 2015 and things like that,
324.4|3.44| when I used TensorFlow before CUDA was bundled,
327.84|2.3| you had to install CUDA on your graphics card
330.14|1.98| and then link it when you install it.
332.12|2.12| And that was usually very flaky.
334.24|2.44| It took a lot of effort to somehow make sure
336.68|3.36| that the library is using the right CUDA version
340.04|0.92| on your computer.
340.96|3.08| So this way, bundling the installer here
344.04|2.6| with the CUDA version, the CUDA toolkit here,
347.88|3.48| makes it a little bit more convenient to install that.
351.36|3.8| So you don't have to manually link the PyTorch library
355.16|1.56| with CUDA and cuDNN,
356.72|3.72| but that also has the downside that this is rather large.
360.44|2.52| I was just noticing it.
362.96|3.32| Anyways, so regarding the distributed training
366.28|2.8| that I mentioned where you can run multiple
369.08|2.12| or one model on multiple GPUs.
371.2|4.0| So there are some additions that are listed here.
375.2|2.24| There were a few more.
377.44|2.96| So they have the pipeline parallelism
380.4|1.64| that I mentioned last week,
382.04|3.64| where you just put a model on different,
385.68|1.08| you use a sequential model
386.76|2.68| and then you put different parts of that model
389.44|1.16| on different GPUs.
390.6|3.0| And there's a utility to make that more convenient.
393.6|2.56| I will show you in the next slide how that looks like.
396.16|1.88| We already saw here last week a version
398.04|1.48| using this fair scale.
399.52|3.88| Then there are also for distributed data parallel,
403.4|1.96| there are also some additions
406.32|3.4| and also this zero redundancy optimizer,
409.72|2.36| making the optimizers more efficient.
412.08|3.88| So last week, we also mentioned briefly these types of things
415.96|1.72| and they also got added directly
417.68|5.0| to PyTorch, the main library.
424.64|3.12| So here's just a brief overview of this model parallelism
427.76|1.16| using multiple GPUs.
428.92|3.68| It's kind of related to the other pipeline version.
432.6|3.44| So how that works is that you put different parts
436.04|0.82| of the model.
436.86|1.66| So if you split your model into four parts,
438.52|2.24| let's say you have four layers.
440.76|3.12| So here, the F represents the forward pass.
443.88|5.0| So let's say you run the first layer on GPU
449.92|1.98| or you keep it on GPU zero,
451.9|3.38| this one on GPU one, GPU two and GPU three.
455.28|3.68| So this way, you avoid exceeding the memory of GPU zero
458.96|3.24| because you have each layer on a different GPU.
462.2|3.08| I mean, for a single or simple multi-layer perceptron,
465.28|2.52| that's probably not necessary,
467.8|2.44| but if you later have larger networks,
470.24|5.0| I will show you an example that might make sense.
475.28|5.0| Yeah, and so here we have then one layer per GPU
480.28|3.24| and then F I think is supposed to stand for forward pass
483.52|2.66| and then you have the backward pass similarly.
486.18|4.14| But one downside of this approach is that you can see,
490.32|4.8| so this one runs, so the second GPU needs the results
495.12|1.28| from this GPU, right?
496.4|5.0| So then it's kind of GPU zero is keeping or staying idle
501.9|3.1| while GPU one runs and so forth.
505.0|3.2| So in that way, where everything here under the area
508.2|4.36| under the curve here, this is like idle time
512.56|1.48| for some of the GPUs.
514.04|3.76| So in this way, you don't utilize three out of the four GPUs
517.8|2.44| and that is basically kind of inefficient
520.24|1.56| because things are sitting there.
521.8|2.48| So one improved version is to use these types
524.28|1.36| of micro batches.
525.64|2.08| So this is like illustrated here.
527.72|4.68| So this already starts running while these finish up
532.4|1.6| basically on different micro batches
534.0|2.48| and then they are passed to the other GPU.
536.48|3.68| So in that way, you kind of run certain things
540.16|1.08| somewhat in parallel.
541.24|1.88| Of course, there's still this bubble here
543.12|2.76| but they call bubble where there is inefficiency,
545.88|2.1| but this is at least small improvement
547.98|2.74| over the regular model parallelism.
550.72|3.36| So this is kind of called pipelined execution.
554.08|3.8| I don't know why the word pipeline is used
557.88|1.88| but it might be because the tool,
559.76|3.88| I think the original one was called a G pipe, but yeah.
563.64|2.12| In any case, if you want to learn more about this
565.76|2.08| you can visit this link here
567.84|2.12| and that will bring you directly to this website
569.96|1.16| where I got this from.
572.16|2.08| Actually, I was kind of curious
574.24|2.96| and wanted to try it in practice yesterday.
577.2|3.38| So I implemented a VGG 16 network.
580.58|3.74| It would actually fit onto a single GPU
584.32|1.56| but just for the sake of the example,
585.88|2.52| I just chose that model because it had different blocks
588.4|2.76| or I coded it up in different blocks.
591.16|5.0| And then I was putting it into this pipeline here.
596.2|3.56| So what I did is I was writing up these blocks.
599.76|2.68| So this is one block in my model.
602.44|2.28| I have five of these blocks
606.08|3.68| and one block is one convolutional layer,
609.76|2.12| then a ReLU, another convolutional layer,
611.88|1.98| another ReLU and the max pooling layer.
613.86|1.34| We will talk more about that
615.2|1.72| in the convolutional network section.
616.92|3.24| But the main takeaways you can see here
620.16|2.56| is that there are multiple things in one block.
622.72|4.12| It can be pretty large if you have maybe even more channels.
626.84|2.96| This would be, I mean, not really large
629.8|1.22| or too large for a single GPU,
631.02|2.54| but again, it's just for the sake of this example.
633.56|1.92| So at the bottom now I'm showing you
635.48|5.0| how I use this new pipe in Torch distributed pipeline sync.
640.52|3.2| There are actually a few more setup steps
643.72|2.66| that I'm skipping here because they didn't fit on the slide.
646.38|3.46| But if you're interested in checking out this code
649.84|2.02| that I was playing around with,
651.86|1.58| I put it here up on GitHub.
653.44|1.16| So you can actually check that out
654.6|2.84| and see the full code and how it looks like.
657.44|3.88| So what I'm doing here is I'm putting the first block
661.32|1.76| on the first GPU.
663.08|1.96| So CUDA zero is the first GPU.
665.04|2.84| I was actually running something else on GPU one.
667.88|3.4| So I was skipping it and I was putting things on GPU two here,
671.28|4.6| GPU three, and then the classifier back on to GPU zero.
675.88|1.8| Why did I do that?
677.68|5.0| So one of the reasons is that you have to have the data
683.0|3.44| and the code that you're running on the same GPU.
686.44|3.16| So if you have your input data on GPU zero,
689.6|2.32| you should also have your first block on GPU zero.
691.92|2.38| And then if you have your class labels
694.3|3.74| for computing the accuracy on GPU zero,
698.04|1.76| then you also want to have the output
699.8|1.44| of the model on GPU zero.
701.24|1.96| That is what I was doing here.
703.2|2.44| So I didn't have to rewrite any of my other code.
705.64|2.68| I could just plug that in into my existing code.
709.8|1.32| So then, yeah, I'm using,
711.12|4.04| so I'm having these blocks now on different GPUs.
715.16|1.32| It has nothing to do with the pipe yet.
716.48|2.76| And what I'm doing is I'm using the sequential
719.24|3.56| and torch to merge these blocks into one model.
722.8|3.24| And then I'm using just this model inside the pipeline here
726.04|2.16| with eight micro batches.
728.2|3.52| And then I'm providing it here for Adam or to Adam
731.72|2.16| as the parameters.
733.88|1.56| And this is essentially it.
735.44|3.44| And then this one would actually then run
738.88|1.88| the pipeline mechanism,
740.76|3.88| like putting everything together and work kind of smoothly.
745.68|2.16| And yeah, it worked well in practice.
747.84|2.8| I must say the training time in this case
750.64|5.0| was about half as slow compared to running everything
755.92|1.44| on a single GPU.
757.36|2.5| But again, speed is not the goal here.
759.86|2.36| So we are not using this pipeline mechanism
762.22|1.58| to speed up the model.
763.8|3.88| We are using it because we assume that this single model
767.68|1.88| would not fit onto a single GPU.
769.56|3.2| So this way we make possible a training of models
772.76|3.72| that are exceeding a regular GPU memory.
776.48|1.62| So I think this is actually pretty cool
778.1|2.58| and I will pretty surely use that in one
780.68|1.54| of my research projects.
783.56|1.74| Yeah, okay, there was one more modification
785.3|1.5| I had to make to the code.
786.8|3.28| So the modification is in these two lines.
790.08|2.16| So this whole thing is my training follow
792.24|2.36| over the epochs and over the mini batches.
794.6|1.92| And here I had to add just this line
796.52|3.3| because now the model is not returning the logits,
799.82|5.0| it's returning our reference object to this RPC thingy.
804.82|5.0| RPC thingy, and you just had to get the local value
810.1|1.96| and then everything else should work.
812.06|1.96| Again, the full code example is here
814.02|2.54| if you're interested to check it out.
817.94|2.8| All right, so this was just a few highlights
820.74|2.64| from this PyTorch 1.8 release.
823.38|3.96| Some other topics, I saw this paper on archive this week,
827.34|1.4| virus amnesty.
828.74|2.88| So I just thought it might be a cool, new, fun,
831.62|4.24| simple data set for benchmarking, yeah, deep learning models.
835.86|2.84| So if you are just interesting in developing a new model
838.7|1.96| and you want to see how well it performs
840.66|3.48| on different data sets, amnest is one, cipher is one.
844.14|2.92| Nowadays also ImageNet and things like that.
847.06|2.96| But I thought this is here an interesting approach
850.02|3.08| because I haven't seen anything like that before.
853.1|2.92| So this is an amnest like data set.
856.02|2.36| So if people say something amnest,
858.38|1.0| they usually mean a data set
859.38|2.84| with approximately 10 classes and 50,000
862.22|2.6| or 60,000 training images.
864.82|3.38| And here, what they have is a data set
868.2|3.56| concerning virus data or malware.
871.76|3.32| So there are 10 classes here.
875.08|2.24| So class level zero and nine.
877.32|3.78| There's only one class that is not malware.
881.1|2.04| It's called binware.
883.14|1.72| It's like the good stuff here.
884.86|3.12| It's just like a regular Excel file, I guess.
887.98|4.76| Putty, I think it's a terminal program for Windows,
892.74|1.04| but I'm not sure.
893.78|3.44| Anyways, and then there are some other viruses here.
897.22|2.44| I think X is Windows.
899.66|3.04| And instead, so they had like a CSV file
902.7|1.44| and some information about that.
904.14|4.3| And instead of putting that up as a CSV file,
908.44|2.62| what they did is they, I mean,
911.06|2.22| it's at least what I understood is they
915.18|1.8| converted it to grayscale images
916.98|3.14| using the intermediate net BPM text format.
920.12|2.82| And then they created ASCII raw images
922.94|5.0| and did something else to make it or to create JPEG files.
927.94|2.56| So how it looks like is this one.
930.5|1.6| So you can see basically,
932.1|4.2| these are JPEG images of these files.
936.3|3.36| And this one would be, for example, the good one.
939.66|3.56| And all the other ones are examples of malware.
943.22|2.56| I haven't seen like an approach like this
945.78|3.96| where people kind of convert text.
949.74|1.32| I mean, code is essentially text.
951.06|5.0| Or here, I think they used the checksums of the files.
956.58|2.04| But yeah, there was an interesting idea
958.62|4.52| like converting, let's say, text or a string into an image
963.14|2.76| so that they can use convolutional networks.
965.9|2.44| I'm actually not sure if that makes it better.
968.34|3.72| So if you have a text file or some weird input format
972.06|2.28| that doesn't look like a tabular data set,
974.34|1.68| but also not like anything else,
976.02|2.32| I'm not sure whether converting into a JPEG
978.34|1.8| really is meaningful.
980.14|1.58| But I thought that was interesting.
981.72|1.74| They actually got pretty good performance
983.46|1.34| or accuracies on that data set.
984.8|2.2| So I think it's probably working.
989.5|2.64| Yeah, I also saw this cool article this week
992.14|3.5| called Simple Considerations for Simple People,
995.64|2.14| Building Fancy Neural Networks.
997.78|3.74| So this is an article highlighting some of the things
1001.52|1.82| you should think about when building a model
1003.34|2.44| or also when debugging a model.
1005.78|2.48| And since you are now working on your class projects,
1008.26|2.64| I thought it was a nice summary, really,
1010.9|1.08| that I wanted to share with you,
1011.98|3.68| like explaining, going over some tips in practice.
1015.66|3.82| So the first step would be putting aside machine learning
1019.48|2.38| and simply focusing on your data.
1021.86|2.8| So before you start applying a model to your data,
1024.66|2.52| just take a look at your data and get a feeling for it.
1027.18|3.32| For example, looking at whether the labels are balanced,
1030.5|1.46| like getting a feeling for that,
1031.96|3.06| whether they're balanced or not, like on the same ratio
1035.02|3.88| for the class labels, same proportions.
1038.9|4.52| So are there gold labels that you don't agree with?
1043.42|3.12| So gold labels here, they mean ground truth.
1046.54|2.76| So are the test set or training set labels
1049.3|2.48| that are provided making sense?
1051.78|1.46| There are some maybe that are wrong.
1053.24|1.88| Do you agree with them?
1055.12|1.6| Then also, it's always useful to know
1056.72|2.7| how the data was obtained, whether, for example,
1059.42|3.32| there could be possible sources of noise in this process.
1062.74|1.96| So it can tell you an anecdote.
1064.7|1.74| For example, there was for,
1066.44|1.94| I like it was like one or two years ago,
1068.38|2.96| there was a face image data set from IBM.
1071.34|4.48| I think it was called DIF or something like that.
1077.34|3.26| It was a face data set shared by IBM.
1080.6|2.5| And I applied to get access to this data set
1083.1|1.64| and I was really excited to get it.
1084.74|4.6| But then I read the README file
1089.34|1.64| and was actually pretty disappointed
1090.98|3.28| because they shared a lot of attributes
1094.26|2.68| that can be used for developing machine learning systems.
1096.94|5.0| But then all these attributes were not assigned by a human,
1102.26|2.4| like not labeled, they were actually predicted
1104.66|1.74| using another machine learning model.
1106.4|2.18| So if you develop a machine learning model
1108.58|2.88| based on labels predicted by another model,
1111.46|2.0| you would assume you can never actually do better
1113.46|1.24| than an existing model.
1114.7|2.16| And that I find not very useful
1116.86|2.84| for the development of machine learning methods necessarily.
1119.7|2.72| So in a way, it's also good to think a little bit about
1122.42|3.84| or find out how labels were obtained.
1126.26|3.48| And yeah, then also thinking about the pre-processing steps,
1129.74|3.94| maybe there are some things that were not ideal,
1133.68|2.18| just good to think about these,
1135.86|1.9| how diverse are the examples,
1137.76|2.0| and also what rule-based algorithm
1139.76|1.82| would perform decently on this problem.
1141.58|3.02| So like, can you think of a rule-based algorithm
1144.6|3.58| in terms of simple decisions that you might think of
1148.18|1.68| that can actually perform well?
1149.86|3.44| And then you can implement these simple rules
1153.3|1.8| as a baseline, because you want to see
1155.1|1.68| that the model that you're training
1156.78|3.04| performs better than any simple baseline, for example.
1159.82|1.88| So for example, rule-based algorithm
1161.7|3.12| on email spam data set could be,
1164.82|5.0| if the subject header is capitalized in all caps,
1169.82|2.6| then it's spam, something like that,
1172.42|1.16| something simple, maybe.
1176.54|2.3| Yeah, so while the previous slide
1178.84|2.42| focused on understanding the data set,
1181.26|2.64| so the second recommendation is about,
1183.9|3.56| yeah, understanding how difficult the task is.
1187.46|3.92| So how well would standard baselines perform on that task,
1191.38|1.92| for example, a classification task.
1193.3|2.1| So if you're working on a classification task,
1195.4|4.02| it's always a good idea to also include a simple baseline,
1199.42|3.36| like logistic regression as a linear classifier.
1202.78|1.96| Because let's say you,
1204.74|2.56| suppose you develop a fancy neural network,
1207.3|1.52| let's say a convolutional network,
1208.82|4.04| that gets 95% accuracy on MNIST.
1213.78|3.2| By itself, 95% might sound super impressive,
1216.98|2.08| but then let's say you run logistic regression,
1219.06|2.06| and usually if you do that on MNIST,
1222.12|4.04| you would see you will get around 93% performance already,
1226.16|1.26| or accuracy already.
1227.42|3.08| So 93% accuracy and 95% accuracy,
1230.5|1.94| that's not very different in that way,
1232.44|3.58| maybe the CNN is not as good as you might think.
1236.02|2.56| So having a baseline like logistic regression
1238.58|1.04| is actually a good idea.
1239.62|2.92| Because maybe even you find if you train a CNN
1242.54|2.4| or multilayer perceptron, it's like only 90%.
1244.94|2.82| And if you only know the number 90% accuracy,
1247.76|2.8| and you tell someone I have a model that can predict,
1250.56|2.34| let's say 100 digits in MNIST with 90%,
1252.9|1.2| and the person doesn't know MNIST,
1254.1|1.74| just looks at some examples,
1255.84|3.7| first might be super impressed, but then if you think
1259.54|2.36| about a logistic regression as a linear model,
1261.9|1.76| already being able to do that,
1263.66|3.2| then it's actually not that impressive after all.
1266.86|2.72| Yeah, so just going through these points here,
1269.58|2.38| how would a random predictor perform?
1271.96|2.06| Especially in classification problems,
1274.02|2.96| and the data sets can be unbalanced.
1276.98|2.6| I'm actually a little bit confused by this point.
1279.58|3.92| I think the main point here is asking
1283.5|2.28| how well a random predictor might perform,
1285.78|2.96| that is actually something I also always ask myself.
1288.74|2.64| So if you have a binary classification problem,
1291.38|3.32| yeah, the random prediction would be 50%, right?
1294.7|2.28| And for three classes, it's 33%.
1296.98|2.44| So it's always good to keep that in mind
1299.42|2.0| what a random prediction might look like.
1303.3|2.28| What I'm a little bit confused about is this point
1305.58|1.36| if the data set is unbalanced.
1306.94|1.58| I mean, this shouldn't really affect
1308.52|1.38| the random predictor, right?
1309.9|5.0| So because if you have, let's say, 90% spam and 20% not spam,
1321.9|4.22| and this is your data set, binary data set,
1326.12|4.02| the random predictor would be 50% accurate, right?
1330.14|1.36| Because for each email,
1331.5|2.28| you would either randomly predict spam or not spam,
1333.78|2.12| so you get a 50% accuracy.
1335.9|1.64| And if the data set is balanced,
1337.54|2.32| it's also 50% for a random prediction.
1339.86|3.7| So it should always be 50% if you have a binary data set,
1343.56|2.66| or around 50%, let's say.
1346.22|2.68| I think what the person here was more interested in,
1348.9|2.56| in terms of data set can be unbalanced,
1351.46|3.0| is majority class predictor.
1361.38|1.2| Because then it gets interesting.
1362.58|2.72| For example, on a balanced binary data set,
1365.3|2.48| the majority class predictor would get 50% accuracy.
1367.78|1.42| But if you have a data set like that,
1369.2|5.0| where you have 80% spam and 20% not spam,
1374.58|3.0| then some classifier that would always predict
1377.58|3.0| the majority class, if the test set has these labels,
1380.58|2.96| you would already get 80% accuracy
1383.54|2.4| just by always predicting spam.
1385.94|2.76| So in that case, if you develop a machine learning system
1388.7|3.84| that gets, let's say, 82% accuracy,
1392.54|1.16| that's not very impressive,
1393.7|2.48| because by always predicting the majority class,
1396.18|1.44| you can already get 80%.
1397.62|2.52| So that's actually also something worthwhile
1400.14|2.04| to think about when you develop a model.
1403.54|2.46| So then the next thing is,
1406.0|2.94| what would the loss look like for a random predictor?
1408.94|4.78| So this is also related to one of the quiz questions
1413.72|1.06| I had last week.
1414.78|4.6| Recall when I asked you to compute the cross entropy
1419.38|4.1| for the worst case scenario, which was infinity.
1423.48|1.54| But let's say if you have a case
1426.02|2.36| where you always predict randomly,
1428.38|5.0| so random classifier would have a loss of
1435.46|2.28| one over the number of class labels, right?
1440.12|2.74| So this would be the maximum or the worst case.
1442.86|3.68| And if you don't have an infinity, a zero in the lock,
1446.54|3.44| the totally random prediction would be,
1449.98|3.04| actually it should probably be,
1453.02|1.44| let's say number of classes
1457.14|4.12| times minus lock one over the number of classes.
1461.26|2.52| So this would be a totally random prediction.
1463.78|4.04| I think it's, for binary, it's around,
1467.82|3.0| what would it be, like 2.3 something?
1470.82|2.48| But I'm not sure I would have to double check.
1473.3|2.52| But it's always good to double check these numbers
1475.82|1.96| when you do training and you see the loss
1477.78|2.16| gets stuck at a certain point.
1479.94|3.0| To see what would be the loss for random prediction
1482.94|2.04| and this way you can find out
1484.98|3.38| whether the model was learning something at all or not.
1489.88|0.94| Yeah, some other points are,
1490.82|2.96| what are the best metrics for measuring performance?
1493.78|2.98| For example, precision, recall, accuracy.
1498.82|4.52| Yeah, and also, yeah, the last one is also interesting.
1503.34|2.36| Are there architectures in my neural network toolbox
1505.7|1.88| that would be good to model
1507.58|2.52| the inductive bias of the data?
1510.1|1.88| Inductive bias, we briefly talked about this.
1511.98|3.92| It's like one of these machine learning jargon terms.
1515.9|2.56| For example, yeah, that goes actually back
1518.46|2.92| to the previous point, understanding the data set.
1521.38|3.16| So for instance, if you have time series data,
1524.54|2.52| it might be better to use a recurrent neural network.
1527.06|1.36| Or if you have image data,
1528.42|2.76| it might be good to use a convolutional network and so forth.
1531.18|2.5| So also, yeah, understanding your data set.
1533.68|2.44| Yeah, assume now you understand the data set
1536.12|3.36| and also the difficulty of the task.
1539.48|3.56| But you find that the model is not performing well.
1543.04|3.32| For example, the loss that you observed during training,
1546.36|2.6| the cross entropy loss is the one that you would expect
1548.96|1.44| for a random prediction.
1550.4|2.52| So there might be something wrong with your code
1552.92|2.36| and that might be a good opportunity
1555.28|1.76| for doing some model debugging
1557.04|2.2| to see whether there's some error.
1559.24|3.84| So one common thing is usually if you're doing a model
1563.08|1.68| usually if you have a learning rate
1564.76|2.1| that is way too large or way too small,
1566.86|3.06| then you will probably see that the other model
1569.92|1.28| is not learning well.
1572.12|2.92| If you personally, that's what I try first.
1575.04|1.72| If you tweak the learning rate though,
1576.76|2.96| but you still find things are not performing well.
1579.72|3.3| What I also like to do is I try to overfit
1583.02|2.3| a small batch of examples.
1585.32|1.32| That was actually really helpful
1586.64|2.64| in a recent research project where we had actually an issue
1589.28|2.76| where we use this technique to diagnose it.
1592.04|5.0| So when you only do training on a single mini batch,
1597.24|2.2| what you would expect is that the model
1599.44|1.8| should overfit to this mini batch
1601.24|3.44| and you should get like a small loss like around zero.
1604.68|2.52| So how you can do that is just by adding
1607.2|2.6| when you do in the data loader,
1609.8|5.0| if you do like for let's say batch and labels
1614.8|5.0| in the data loader, when you do that.
1625.4|3.4| And after the first training loop,
1628.8|2.64| I would add a break at the end.
1631.44|2.84| So in this way, you only do it once
1634.28|1.72| and then you do it for multiple epochs.
1636.0|3.46| And this way you can try to overfit to a single mini batch
1639.46|2.46| and you should get around zero loss.
1641.92|2.4| If not, there's something weird usually.
1644.32|2.04| So here actually from that article,
1646.36|2.4| few things to look into.
1648.76|1.46| For example, one could be,
1650.22|3.4| you forgot to call model evil in the valuation mode.
1653.62|1.2| We will talk more about this actually
1654.82|2.22| when we talk about drop out this week.
1657.04|1.24| But yeah, that would be one case
1658.28|4.76| or when you have, well, you forgot to model zero grad.
1663.04|2.52| So you will otherwise accumulate.
1665.56|2.52| If you don't do that, you will accumulate the gradients
1668.08|1.04| from the previous rounds.
1669.12|3.6| And then if you update that could also be some issues
1672.72|2.12| because you don't do gradient descent,
1674.84|2.6| you do something with accumulated gradients.
1678.48|1.52| Or there's maybe something wrong
1680.0|1.52| with the pre-processing of the inputs.
1681.52|1.88| Maybe you forgot to normalize them.
1684.64|3.08| Another common one is using the wrong arguments in the loss.
1687.72|3.08| So recall when we said that the cross entropy loss
1690.8|3.32| in pytorch works with the logits.
1694.12|2.92| So if you provide it with a softmax probabilities,
1697.04|2.72| it will give you very weird results.
1699.76|3.24| So that's also one thing to check for.
1703.0|2.64| Well, here initialization doesn't break symmetry.
1705.64|3.6| That is related to the question I asked you when I said,
1709.24|2.56| why don't we initialize all the weights
1711.8|1.66| in a neural network to zero?
1713.46|1.5| That's because we have symmetry.
1714.96|2.2| That was actually a nice Piazza post
1717.16|2.32| by one of the students who answered this question.
1719.48|1.88| So I recommend you to check out this post
1721.36|2.12| because yeah, it was very well written
1723.48|2.44| and essentially explaining the problem very well.
1725.92|1.64| So there's actually a symmetry.
1727.56|2.16| If we initialize the network with all zeros,
1729.72|2.76| or all small numbers that are the same.
1732.48|1.96| So what we want is we want to have small,
1734.44|2.88| randomly different numbers to initialize the network
1737.32|1.24| to break the symmetry.
1740.04|1.72| Or here, another one is some parameters
1741.76|2.48| are never called during the forward pass.
1744.24|1.76| So if you don't use them during the forward pass,
1746.0|1.96| they won't be updated because they are not part
1747.96|1.72| of the computation graph.
1749.68|2.56| Another one that happens often to me
1752.24|5.0| is if I have two models in a single script,
1757.68|1.82| actually happened to me when I was implementing
1759.5|1.66| this pipeline parallelism.
1761.16|3.84| So I had my Adam optimizer or let's say,
1765.0|1.48| I think we haven't covered Adam.
1766.48|2.86| Let's say we had my SGD optimizer.
1769.34|1.68| We will cover Adam later.
1771.02|3.82| And you pass it the model parameters like this.
1778.7|3.58| And I had two models in that notebook.
1782.28|1.72| I had just called it model.
1784.0|4.4| And the other one I called model parallel.
1788.4|2.16| But when I was training the parallel model,
1790.56|4.52| I used still model parameters in the SGD.
1795.08|2.76| So it was not actually updating the right model parameters.
1797.84|1.16| And then the training didn't work.
1799.0|2.28| And I was wondering, why is this model not training?
1801.28|3.84| And then I saw, oh, I didn't give it the right parameters.
1806.48|1.72| Yeah, another one here is the learning rate
1808.2|1.92| is taking funky values like zero.
1810.12|2.92| So there's something called learning rate scheduler,
1813.04|2.56| which we'll also talk about later.
1815.6|2.6| So lots of topics you notice that we will talk about later,
1818.2|1.8| but yeah, deep learning is a big topic
1820.0|2.08| and lots of considerations in practice.
1822.08|2.8| And we can't cover everything in a single week, right?
1824.88|2.6| So we will cover all these things over the semester.
1827.48|1.32| But we will come back to that.
1828.8|1.76| But there's a learning rate scheduler.
1830.56|3.6| And if you decrease the learning rate too fast,
1834.16|1.7| or too aggressively, you sometimes end up
1835.86|2.26| with a learning rate of zero very early on.
1838.12|3.16| And then yeah, your model is also not a training.
1841.28|3.04| Or your inputs are truncated in a suboptimal way.
1844.32|2.52| What I find also useful in practice
1846.84|4.12| is also always to plot loss curves during training.
1850.96|5.0| So using the mini batch loss, for example, like this,
1856.44|2.4| it's kind of efficient because you have to compute it anyway
1858.84|0.92| for the model update.
1859.76|1.64| And then yeah, I usually plot it
1861.4|1.66| and see you want to see that goes down.
1863.06|1.9| I usually also do some running average
1864.96|1.96| because otherwise you can see it's very noisy
1866.92|1.08| and hard to see.
1868.0|3.76| So doing a running average is also helpful.
1871.76|2.0| You have the code for that, right?
1873.76|2.08| So I shared that in last week's lecture.
1875.84|2.4| So I always recommend doing something like that.
1879.44|2.72| And also what I like to do is after training,
1882.16|2.9| I like to visualize the training and validation accuracy.
1885.06|2.82| What I want to see is that it improves.
1887.88|1.64| You can see here at this point,
1889.52|1.84| there's maybe some overfitting starting.
1891.36|1.16| So this is actually the point
1892.52|5.0| where the model performs really good.
1897.52|2.4| So why is the training set performance worse
1899.92|0.84| than the validation?
1900.76|1.48| That can be just a random effect
1902.24|1.64| because the validation set was very small
1903.88|2.28| that I chose in this data set here.
1906.16|2.18| You can see this all actually pretty good.
1909.48|2.2| But yeah, I always like to look at these plots
1911.68|3.1| just to get a feeling of how the model behaves.
1916.84|4.38| All right, so last point, tune but don't tune blindly.
1921.22|3.5| So yeah, it's very tempting to just brute force
1924.72|3.74| set up a grid of hyperparameters to search over
1928.46|3.46| like brute force, trying out all possible hyperparameters
1931.92|1.8| but this can be actually wasteful
1933.72|3.64| and personally, I don't have the patience to do that.
1937.36|2.6| I usually, what I tweak extensively is the learning rate.
1939.96|3.56| I try different learning rates and then also other things
1943.52|3.0| but usually the learning rate is very important
1946.52|1.84| but other parameters, yeah, they can also be important
1948.36|3.48| but usually I train or tune one parameter at a time
1951.84|3.8| to get a feeling for it and then I try some combinations
1955.64|1.52| but not extensively.
1957.16|2.66| I think it would be good if I would try more of them
1959.82|2.54| but I'm not a very patient person
1962.36|2.4| and you can set it up to run it in the background
1964.76|2.04| but even though let's say you have access
1966.8|4.32| to a couple of GPUs, training a model can sometimes take
1971.12|4.84| half a day or a day and instead of having like hundreds
1975.96|2.6| of parameter combinations that don't make sense,
1978.56|3.04| training and occupying your machine for several weeks,
1981.6|2.0| you can maybe just select a few of them
1983.6|3.8| and get a feeling for them and then you have a better feeling
1987.4|2.92| what makes most sense in this given scenario,
1990.32|2.16| what modification would give you the best bang
1992.48|1.58| for the buck, for example.
1995.12|3.2| Here, this person also recommends random grid search.
1998.32|4.2| That's something we talked about in 5.51
2002.52|1.48| last semester briefly.
2004.0|2.72| So it's just, yeah, picking hyper parameter values
2006.72|1.4| randomly in a given range.
2008.12|3.04| That's also one good approach actually.
2011.16|2.86| Some people also like to use Bayesian optimization
2014.02|2.52| but in my experience, also in his experience,
2016.54|4.16| this is actually not usually worthwhile.
2022.64|3.38| All right, so now, yeah, there are four tips here.
2026.02|1.48| One is understanding the data set.
2027.5|3.2| The second was understanding like the baselines
2030.7|3.74| and then the third one was model debugging tips
2034.44|3.42| and then here, fourth one, yeah, tuning is important
2037.86|1.48| but also don't do it blindly.
2039.34|3.72| I mean, you can but usually the limitation
2043.06|2.12| in practice is the computational resources.
2045.18|1.8| If we have infinite resources, yeah,
2046.98|2.44| then tuning blindly would make sense
2049.42|2.72| but otherwise, yeah, we have to be resourceful
2052.14|3.08| and then it's good to tweak one thing at a time
2055.22|1.08| and understand what it does
2056.3|2.72| and then, yeah, consider tweaking other things.
2060.46|1.6| All right, the last thing for today.
2062.06|2.38| I think it's already a long video.
2064.44|1.12| So the last thing for today,
2065.56|1.54| I don't want to go into too much detail
2067.1|2.98| but since I mentioned, was it two weeks ago,
2070.08|4.86| there's already a GAN transformer, transformer GAN.
2074.94|4.2| I also coincidentally saw now the second transformer GAN.
2079.14|2.56| So it's called generative adversarial transformers
2081.7|2.88| and in this paper, they call it the GANs former.
2084.58|1.68| I just want to share it because I found
2086.26|1.72| it's actually kind of cool,
2087.98|4.52| like seeing the field progressing so rapidly.
2092.5|1.86| In the last couple of years, we had transformers,
2094.36|3.94| we had GANs and now, while we are in this class,
2098.3|5.0| we saw that people developed now GANs with transformers
2103.3|3.44| like generative adversarial transformers.
2106.74|1.4| Might be something interesting
2108.14|1.88| you could try in your class project
2110.02|2.8| if you are considering GANs in your class project,
2112.82|1.08| that might be something.
2113.9|3.56| The code is on GitHub, so could maybe download it
2117.46|2.64| and play around with it if you like.
2120.1|3.04| What I was impressive is that the performance here
2123.14|2.64| is actually pretty good compared to GANs
2125.78|2.0| and I can also see based on these images,
2127.78|1.24| they actually look quite good.
2129.02|1.88| So these are generated images.
2130.9|2.24| These are attention maps.
2133.14|1.2| And I don't want to go into too much detail
2134.34|2.0| because like I said, it's a long video.
2136.34|2.64| FID is the Frechette Inception Distance
2138.98|2.96| and this is something that I will probably save
2141.94|1.06| for another day.
2143.0|2.0| All right, so but in general,
2145.0|1.22| I thought that might be interesting,
2146.22|1.64| something to have on your radar
2147.86|1.48| when you work on your class projects.
2149.34|3.32| Of course, it's optional, so you don't have to consider this
2152.66|4.36| but I just thought it's just, yeah, hot off the press
2157.02|2.42| and that's something maybe cool to look into.
2159.44|2.14| All right, so with that, next week,
2161.58|2.64| we are going to cover regularization
2164.22|3.28| and talking about different optimizers
2167.5|2.22| and learning rates and weight initialization.
2169.72|23.0| All right, so then see you next week.