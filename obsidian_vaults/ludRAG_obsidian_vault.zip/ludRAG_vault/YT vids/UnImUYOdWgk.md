start_time|end_time|text
0.68|3.7| Yeah, hi, everyone. So last week, we learned about auto
4.38|3.3| encoders. Auto encoders are special types of neural
7.68|4.44| networks that consists of two parts, an encoder that takes an
12.12|2.82| input and decompresses it into a smaller dimensional
14.94|3.78| representation. And the decoder, which takes the smaller
18.72|4.64| dimensional representation, and reconstructs the input. I showed
23.36|3.8| you that an example where I was drawing a random coordinate from
27.16|4.28| this lower dimensional space, and I was using the decoder to
31.72|3.6| create a new image that is somewhat similar to the
35.32|3.96| training data. So in that way, we can think of it as generating
39.28|3.8| new data. However, when we talk about higher dimensional
43.08|3.12| spaces, so if the lower dimensional space is smaller,
46.2|3.08| let's say than more than two dimensions, this method doesn't
49.28|2.56| work very well, because there are several challenges with
51.84|3.72| that, I will go into more detail about that in this lecture. So
55.56|4.24| in this lecture, overall, I want to talk about a particular type
59.8|3.38| of auto encoder called the variational auto encoder. And
63.18|4.42| this variational auto encoder is better for sampling new data. So
67.6|3.56| you can think of the variational auto encoder as a generative
71.16|5.4| model that we can use to sample from a distribution and generate
76.6|4.68| new data. So in that way, it's kind of like a modified version
81.28|3.24| of that auto encoder, particularly well suited for
84.52|4.44| creating new data. And before I go into too much detail about
88.96|3.8| how that works, let me give you the lecture overview. And then
92.76|3.6| we will learn step by step how this variational auto encoder
96.36|3.36| works. And I will show you also, of course, some code examples,
99.72|4.08| again, the MNIST code example, but also more interestingly, we
103.8|4.8| will take a look at a data set consisting of face images. And
108.6|4.0| then we will also learn how we can make people smile. All
112.6|5.52| right, let's get started. All right, so yeah, these are our
118.12|3.78| topics for today. And really, don't worry, I know it looks
121.9|3.9| like a lot eight topics. But I'm really keeping it short this
125.8|4.48| time. I know that our lecture days are limited, there are only
130.28|4.04| few days left in the semester. And you are all busy with working
134.32|4.0| on your class projects and other classes as well. I'm aware of
138.32|3.4| that. So I don't want to make things too complicated at the
141.72|3.56| end of the semester, and just give you a big picture overview
145.28|3.84| of what a variational auto encoder is here. And I only
149.12|3.36| made 25 slides, I'm very confident that I'm going to be
152.48|5.24| able to finish this lecture within our regular 75 minute
157.72|3.64| lecture time. And yeah, I also have code examples, of course.
161.38|3.3| So with that lecture here, I'm hoping to give you a big
164.68|2.84| overview, big picture overview of how variational auto encoder
167.52|4.84| works. And I will also provide you then with some future
172.36|2.72| references if you're interested, because yeah, there's also a
175.08|3.64| lot of mathematical underpinnings behind
179.0|3.04| variational auto encoders, which we can't cover here in this
182.04|3.24| lecture. But some of you may be interested in that. So I will
185.28|2.96| also provide further studying resources.
189.76|3.12| Alright, so in the next video, we will start with the overview
192.88|5.0| of what a variational auto encoders.