start_time|end_time|text
5.6|3.28|thank you all for having me it's
6.64|4.8|exciting to be here uh one of my
8.88|4.48|favorite things is talking about what is
11.44|3.359|going on inside neural networks or at
13.36|2.56|least what we what we're trying to
14.799|2.881|figure out is going on inside neural
15.92|3.439|networks so it's it's always fun to chat
17.68|3.04|about that
19.359|3.281|um
20.72|3.84|oh gosh i have to figure out how to how
22.64|5.12|to do things okay can i
24.56|5.44|what i i want okay there we go now now
27.76|4.88|we are advancing slides that seems wrong
30.0|4.239|um so i think interpretability means
32.64|4.24|lots of different things to different
34.239|4.0|people um it's a very a very broad term
36.88|2.96|and and people mean all sorts of
38.239|3.441|different things by it
39.84|3.68|um and so i wanted to talk just briefly
41.68|4.16|about uh the kind of interpretability
43.52|4.16|that i i spend my time thinking about um
45.84|3.52|which is what i'd call mechanistic
47.68|4.0|interpretability so
49.36|4.719|um most of my work actually has not been
51.68|4.399|on language models or on rnn's or
54.079|4.561|transformers but um on understanding
56.079|4.721|vision confidence and and trying to
58.64|6.239|understand how do the parameters in
60.8|5.359|those models actually map to algorithms
64.879|2.641|so you can like think of the parameters
66.159|4.161|of a neural network as being like a
67.52|4.4|compiled computer program and and the
70.32|4.32|neurons are kind of like variables or
71.92|4.32|registers and somehow there's there
74.64|3.6|there are these these complex computer
76.24|3.519|programs that are are embedded in those
78.24|3.6|weights and we'd like to turn them back
79.759|3.68|in to computer programs that that humans
81.84|3.68|can understand it's a kind of kind of
83.439|2.961|reverse engineering problem
85.52|2.8|um
86.4|3.2|and so this is this is kind of a
88.32|2.72|fun example that we found where there
89.6|3.76|was a car neuron and you could actually
91.04|4.64|see that um you know that we have the
93.36|3.759|car neuron and it's constructed from
95.68|3.52|like a wheel neuron
97.119|3.521|and it looks for in the case of the
99.2|3.279|wheel neuron it's looking for for the
100.64|3.28|wheels on the bottom and those are
102.479|2.561|positive weights and it doesn't want to
103.92|2.8|see them on top so there's negative
105.04|3.28|weights there and there's also a window
106.72|3.679|neuron it's looking for the windows on
108.32|3.6|the top and and not on the bottom and so
110.399|3.601|what we're actually seeing there right
111.92|5.199|is it's an algorithm it's an algorithm
114.0|4.32|that goes and turns um you know it's
117.119|3.521|it's just it's you know saying you know
118.32|3.759|well cars is has wheels on the bottom
120.64|3.2|and windows on the top and chrome in the
122.079|3.68|middle um and that's that's actually
123.84|3.52|like just the the strongest neurons for
125.759|3.2|that and so we're actually seeing a
127.36|3.519|meaningful algorithm and that's that's
128.959|3.441|not an exception that's that's sort of
130.879|3.121|the the general story that if you're
132.4|3.12|willing to go and look at neural neural
134.0|2.72|network weights and you're willing to
135.52|2.88|invest a lot of energy and trying to
136.72|3.44|first engineer them there's there's
138.4|4.559|meaningful algorithms written in the
140.16|4.159|weights waiting for you to find them
142.959|2.721|um and there's a bunch of reasons i
144.319|3.441|think that's an interesting thing to
145.68|3.36|think about one is you know just no one
147.76|2.72|knows how to go and do the things that
149.04|2.96|neural networks can do like no one knows
150.48|3.44|how to write a computer program that can
152.0|3.28|accurately classify imagenet let alone
153.92|3.039|you know the language modeling tasks
155.28|3.12|that we're doing no one knows how to
156.959|3.441|like directly write a computer program
158.4|3.52|that can do the things that gpd3 does
160.4|3.36|and yet somehow breaking descent is able
161.92|3.44|to go and discover a way to do this and
163.76|4.559|i want to know what's going on i want to
165.36|6.159|know you know how what is it discovered
168.319|4.801|that it can do in in these systems
171.519|4.0|there's another reason why i think this
173.12|4.56|is important which is uh is safety so
175.519|3.681|you know if we if we want to go and use
177.68|3.919|these systems in in places where they
179.2|3.759|have big effect on the world and
181.599|3.92|i think a question we need to ask
182.959|4.321|ourselves is you know what what happens
185.519|3.201|when these models have have
187.28|2.959|unanticipated failure modes failure
188.72|3.36|modes we didn't know to go and test for
190.239|3.121|or to look for to check for
192.08|2.56|how can we how can we discover those
193.36|2.959|things especially if they're they're
194.64|3.28|really pathological failure modes so the
196.319|3.761|models in some sense deliberately doing
197.92|3.84|something that we don't want well the
200.08|3.04|only way that i really see that we we
201.76|2.96|can do that is if we can get to a point
203.12|3.6|where we really understand what's going
204.72|3.36|on inside these systems
206.72|3.519|um so that's another reason that i'm
208.08|4.799|interested in this
210.239|4.56|now uh actually doing interpersonally on
212.879|4.0|language models and transformers it's
214.799|3.52|new to me i um before this year i spent
216.879|3.44|like eight years working on trying
218.319|4.48|reverse engineer confidence uh and
220.319|4.961|vision models um and so the ideas in
222.799|3.36|this talk um are are new things that
225.28|3.519|i've been thinking about with my
226.159|4.401|collaborators um and we're still
228.799|3.681|probably a month or two out maybe maybe
230.56|3.2|longer from publishing them um and this
232.48|2.959|is also the first public talk that i've
233.76|3.44|given on it so uh you know the things
235.439|3.281|i'm going to talk about um they made
237.2|3.52|they're i think honestly still a little
238.72|3.04|bit confused for me um and definitely
240.72|2.799|are going to be confused in my
241.76|3.36|articulation of them so if i say things
243.519|2.881|that are confusing um you know please
245.12|2.399|feel free to ask me questions there
246.4|2.64|might be some points for me to go
247.519|3.28|quickly because there's a lot of content
249.04|3.68|um but definitely at the end i will be
250.799|3.681|available for a while to chat about the
252.72|5.6|stuff um
254.48|5.68|and uh yeah also i apologize um if uh if
258.32|3.92|i'm unfamiliar with zoom and make make
260.16|5.039|mistakes um but
262.24|4.56|uh yeah so um with that said uh let's
265.199|6.081|dive in
266.8|7.36|um so i wanted to start with a mystery
271.28|4.4|um before we go and try to actually dig
274.16|3.92|into you know what's going on inside
275.68|5.36|these models um i wanted to motivate it
278.08|4.559|by a really strange piece of discover of
281.04|4.08|behavior that we discovered and and
282.639|4.081|wanted to understand
285.12|2.88|um
286.72|3.68|uh and by the way i should say all this
288.0|4.16|work is um uh you know is done with my
290.4|4.4|my colleagues anthropic and especially
292.16|4.319|my colleagues catherine and nelson
294.8|3.839|okay so on to the mystery
296.479|3.921|um i think probably the the most
298.639|4.961|interesting and most exciting thing
300.4|5.76|about um about transformers is their
303.6|4.48|ability to do in-context learning or
306.16|4.8|sometimes people call it meta-learning
308.08|5.44|um you know the gp3 paper uh goes and
310.96|3.92|and describes things as uh you know uh
313.52|2.32|language models are few shot learners
314.88|2.56|like there's lots of impressive things
315.84|2.96|about gp3 but they choose to focus on
317.44|4.479|that and you know now everyone's talking
318.8|5.119|about prompt engineering um and um
321.919|4.0|andrei caprathi was was joking about how
323.919|4.081|you know software 3.0 was designing the
325.919|3.921|prompt and so the ability of language
328.0|4.4|models of these these large transformers
329.84|3.76|to respond to their context and learn
332.4|3.04|from their context and change their
333.6|3.599|behavior and response to their context
335.44|3.36|and you know really seems like probably
337.199|4.241|the most surprising and striking and
338.8|3.6|remarkable thing about them
341.44|2.16|um
342.4|3.359|and
343.6|3.599|uh some of my my colleagues previously
345.759|3.921|published a paper that has a trick in it
347.199|3.84|that i i really love which is so we're
349.68|3.04|all used to looking at learning curves
351.039|5.121|you train your model and you you know as
352.72|3.44|your model trains the loss goes down
356.4|4.079|sometimes it's a little bit
357.759|4.241|discontinuous but it goes down
360.479|2.881|another thing that you can do is you can
362.0|3.28|go and take a fully trained model and
363.36|3.679|you can go and ask you know as we go
365.28|3.039|through the context you know as we go we
367.039|3.6|predict the first token and then the
368.319|3.681|second token and the third token we get
370.639|2.961|better at predicting each token because
372.0|3.6|we have more information to go and
373.6|4.08|predict it on so you know the first the
375.6|3.92|first con token the the loss should be
377.68|3.12|the the entropy of the unigrams and then
379.52|3.04|the next token should be the entry of
380.8|3.44|the biograms and it falls
382.56|3.6|but it keeps falling
384.24|2.64|and it keeps getting better
386.16|2.4|and
386.88|4.879|in in some sense that's our that's the
388.56|5.52|model's ability to go and predict to go
391.759|4.401|and do in-context learning the ability
394.08|3.36|to go and predict um you know to be
396.16|3.039|better at predicting later tokens than
397.44|3.28|you are predicting early tokens that is
399.199|3.28|that is in some sense a mathematical
400.72|3.599|definition of what it means to be good
402.479|4.321|at this magical in-context learning or
404.319|4.081|meta-learning that these models can do
406.8|3.28|and so that's kind of cool because that
408.4|3.76|gives us a a way to go and look at
410.08|4.08|whether models are good at in-context
412.16|3.439|learning
414.16|2.879|yeah if i could just ask the question
415.599|3.681|like a clarification question
417.039|5.121|please when you say learning there are
419.28|4.16|no actual parameters
422.16|3.439|that is the remarkable thing about
423.44|3.36|in-context learning right so yeah indeed
425.599|2.961|we traditionally think about neural
426.8|3.28|networks as learning over the course of
428.56|3.919|training by going and modifying their
430.08|4.48|parameters but somehow models appear to
432.479|3.361|also be able to learn in some sense um
434.56|2.8|if you give them a couple examples in
435.84|3.04|their context they can then go and do
437.36|3.839|that later in their context even though
438.88|4.0|no parameters changed and so it's it's
441.199|3.361|some kind of quite different different
442.88|3.12|notion of learning as you're as you're
444.56|2.24|gesturing that
446.0|2.88|uh
446.8|4.56|okay i think that's making more sense so
448.88|3.84|i mean could you also just describe in
451.36|3.6|context learning in this case as
452.72|4.0|conditioning as in like conditioning on
454.96|2.88|the first five tokens of a ten token
456.72|3.12|sentence
457.84|3.28|pretty cool tokens yeah i think the
459.84|2.799|reason that people sometimes think about
461.12|3.919|this as in context learning or meta
462.639|4.24|learning is that you can do things where
465.039|3.121|you like actually take a training set
466.879|3.04|and you embed the training set in your
468.16|3.52|context like if you just two or three
469.919|4.481|examples and then suddenly your model
471.68|4.239|can go and do do this task and so you
474.4|4.72|can do fuchsia learning by embedding
475.919|4.321|things in the context yeah the formal
479.12|3.68|setup is that you're you're just
480.24|4.959|conditioning on on on this context and
482.8|3.679|it's just that somehow this this ability
485.199|2.961|like this thing like there's there's
486.479|2.641|some sense you know for a long time
488.16|1.759|people were
489.12|2.799|were
489.919|3.68|i mean i i guess really the history of
491.919|2.96|this is uh
493.599|3.521|we started to get good at neural
494.879|3.6|networks learning right um and we could
497.12|2.479|we could go and train language uh train
498.479|2.4|vision models and language models that
499.599|3.121|could do all these remarkable things but
500.879|3.521|then people started to be like well you
502.72|3.84|know these systems are they take so many
504.4|4.16|more examples than humans do to go and
506.56|3.359|learn how can we go and fix this and we
508.56|3.599|had all these ideas about metal learning
509.919|3.521|develop where we wanted to go and and
512.159|2.56|train models
513.44|2.959|explicitly to be able to learn from a
514.719|3.2|few examples and people developed all
516.399|3.52|these complicated schemes and then the
517.919|3.841|like truly like absurd thing about about
519.919|4.24|transformer language models is without
521.76|4.0|any effort at all we get this for free
524.159|3.041|that you can go and just give them a
525.76|3.12|couple examples in their context and
527.2|3.92|they can learn in their context to go
528.88|3.92|and do new things um i think that was
531.12|3.52|like like that was in some sense the
532.8|2.8|like most striking thing about the gpd3
534.64|1.759|paper
535.6|3.919|um
536.399|5.521|and so uh this this yeah this ability to
539.519|4.401|go and have the just conditioning on a
541.92|3.919|context go and give you you know new
543.92|3.599|abilities for free and and the ability
545.839|3.761|to generalize to new things is in some
547.519|3.601|sense the the most yeah and to me the
549.6|4.88|most striking and shocking thing about
551.12|6.32|about transformer language models
554.48|4.479|that makes sense i mean i guess
557.44|3.68|from my perspective
558.959|4.32|i'm trying to square like
561.12|4.08|the notion of learning in this case
563.279|4.481|with you know if you or i were given a
565.2|4.24|prompt of like one plus one equals two
567.76|5.28|two plus three equals five
569.44|5.36|as the sort of few shot set up and then
573.04|3.84|somebody else put you know like five
574.8|3.68|plus three equals and we had to fill it
576.88|3.44|out in that case i wouldn't say that
578.48|3.84|we've learned arithmetic because we
580.32|3.84|already sort of knew it but rather we're
582.32|3.76|just sort of conditioning on the prompt
584.16|3.28|to know what it is that we should then
586.08|4.8|generate right
587.44|4.8|uh but it seems to me like that's
590.88|2.959|yeah i think that's on the spectrum
592.24|3.52|though because you can you can also go
593.839|3.841|and give like completely nonsensical
595.76|4.24|problems where the model would never
597.68|3.599|have seen um see like mimic this
600.0|2.48|function and give a couple examples of
601.279|2.881|the function and the model's never seen
602.48|3.84|it before and i can go and do that later
604.16|4.0|in the context um and i think i think
606.32|4.0|what you did learn um in a lot of these
608.16|3.119|cases you might not have you might have
610.32|2.079|um
611.279|2.24|you might not have learned arithmetic
612.399|2.721|like you might have had some innate
613.519|3.201|faculty for arithmetic that you're using
615.12|3.92|but you might have learned oh okay right
616.72|3.359|now we're doing arithmetic problems
619.04|2.479|um
620.079|2.721|got it in the case this is i agree that
621.519|3.681|there's like an element of semantics
622.8|3.599|here um yeah you know this is helpful
625.2|2.079|though just to clarify exactly sort of
626.399|2.641|what the
627.279|5.921|yeah what you remember
629.04|5.52|thank you for watching of course
633.2|3.12|so something that's i think really
634.56|2.64|striking about all of us
636.32|2.4|um
637.2|3.52|is well okay so we we've talked about
638.72|3.2|how we can we can sort of look at the
640.72|3.119|learning curve and we can also look at
641.92|3.919|this in context learning curve but
643.839|5.201|really those are just two slices of a
645.839|4.641|two-dimensional uh space so like the the
649.04|3.12|in some sense the more fundamental thing
650.48|3.28|is how good are we at producing the nth
652.16|2.72|token at a different given point in
653.76|2.88|training
654.88|3.84|and something that you'll notice if you
656.64|3.6|if you look at this and so when we when
658.72|2.799|we talk about the loss curve we're just
660.24|2.4|talking about if you average over this
661.519|3.281|dimension
662.64|4.4|if you if you like average like this and
664.8|5.279|and project on to the the training step
667.04|4.479|that's that's your loss curve um and um
670.079|2.88|if you the thing that we are calling the
671.519|3.601|incontext learning curve is just this
672.959|5.361|line um
675.12|4.959|uh yeah this this line uh down the end
678.32|3.04|here
680.079|2.401|um
681.36|3.039|and something that's that's kind of
682.48|4.479|striking is there's there's this
684.399|4.88|discontinuity in it um like there's this
686.959|4.32|point where where you know the model
689.279|4.321|seems to get radically better in a very
691.279|4.081|very short time step span at going and
693.6|3.52|predicting late tokens
695.36|3.68|so it's not that different in early time
697.12|5.24|steps but in late time steps suddenly
699.04|3.32|you get better
703.519|3.521|and a way that you can make this more
705.2|3.52|striking is you can you can take the
707.04|4.32|difference in in your ability to put the
708.72|5.04|50th token and your ability to predict
711.36|5.44|the 500 token you can subtract from the
713.76|5.199|the the 500th token the 50th token loss
716.8|4.479|and what you see
718.959|3.921|um is that over the course of trading
721.279|2.56|you know you're you're you're not very
722.88|2.48|good at this and you get a little bit
723.839|3.68|better and then suddenly
725.36|3.76|you have this cliff and then you never
727.519|3.12|get better than the difference between
729.12|3.2|these at least never gets better so the
730.639|3.601|model gets better at predicting things
732.32|4.16|but its ability to go and predict late
734.24|3.279|tokens over early tokens never gets
736.48|3.359|better
737.519|4.401|and so there's in the span of just a few
739.839|4.24|hundred steps in training the model has
741.92|4.96|gotten radically better at its ability
744.079|4.56|to go and and do this kind of in context
746.88|3.199|learning
748.639|3.041|and so you might ask you know what's
750.079|3.76|going on at that point
751.68|3.68|um and this is just one model but um
753.839|4.481|well so first of all it's worth noting
755.36|4.159|this isn't a small a small change and so
758.32|2.959|um
759.519|3.12|that you can we don't think about this
761.279|2.401|very often but you know often we just
762.639|2.32|look at loss goes more like did the
763.68|3.2|model do better than another model or
764.959|3.601|worse than another model but um you can
766.88|3.519|you can think about this as in terms of
768.56|3.279|gnats and that are are you know it's
770.399|4.081|just the information theoretic quantity
771.839|4.881|in that um and you can convert that into
774.48|3.599|bits and so like one one way you can
776.72|4.4|interpret this is it's it's something
778.079|5.44|roughly like you know the model 0.4 nas
781.12|3.839|is about 0.5 bits is about uh like every
783.519|3.921|other token the model gets to go and
784.959|3.841|sample twice um and pick the better one
787.44|2.959|it's actually it's even stronger than
788.8|3.44|that that's sort of an underestimate of
790.399|4.721|how big a deal going and getting better
792.24|4.719|by 0.4 an ounces so this is like a real
795.12|5.36|big difference in the model's ability to
796.959|4.56|go and predict late tokens
800.48|2.56|um and we can visualize this in
801.519|2.961|different ways we can we can also go and
803.04|3.039|ask you know how much better are we
804.48|3.84|getting at going and predicting later
806.079|3.841|tokens and look at the derivative and
808.32|2.639|then we we can see very clearly that
809.92|3.039|there's there's some kind of
810.959|3.281|discontinuity in that derivative at this
812.959|4.401|point and we can take the second
814.24|5.12|derivative then and we can um with well
817.36|3.36|derivative with respect to training and
819.36|4.4|now we see that there's like there's
820.72|4.64|very very clearly this this line here so
823.76|3.92|something in just the span of a few
825.36|4.64|steps a few hundred steps is is causing
827.68|4.08|some big change and we have some kind of
830.0|4.24|phase change going on
831.76|3.439|um and this is true across model sizes
834.24|2.56|um
835.199|3.121|uh you can you can actually see it a
836.8|2.88|little bit in the loss curve and there's
838.32|3.12|this little bump here and that
839.68|3.599|corresponds to the point where you have
841.44|3.04|this you have this change we we actually
843.279|5.36|could have seen in the lost curve
844.48|6.24|earlier too it's it's this bump here
848.639|3.921|excuse me so so we have this phase
850.72|3.44|change going on and there's a i think a
852.56|3.44|really tempting theory to have which is
854.16|4.16|that somehow whatever you know there's
856.0|4.24|some this this change in the model's
858.32|3.759|output and its behaviors and it's in a
860.24|4.56|in a in in these sort of outward facing
862.079|4.241|properties corresponds presumably to
864.8|3.68|some kind of change in the algorithms
866.32|3.6|that are running inside the model so if
868.48|4.0|we observe this big phase change
869.92|4.479|especially in a very small window um in
872.48|3.039|in the model's behavior presumably
874.399|3.841|there's some change in the circuits
875.519|4.081|inside the model that is driving that
878.24|2.8|at least that's a you know a natural
879.6|3.2|hypothesis so
881.04|3.359|um if we want to ask that though we need
882.8|2.8|to go and be able to understand you know
884.399|2.721|what are the algorithms that's running
885.6|2.88|inside the model how can we turn the
887.12|2.8|parameters in the model back into those
888.48|2.64|algorithms so that's going to be our
889.92|3.2|goal
891.12|3.92|um now it's going to recover us require
893.12|3.76|us to cover a lot of ground um in a
895.04|3.039|relatively short amount of time so i'm
896.88|3.04|going gonna go a little bit quickly
898.079|4.0|through the next section and i will
899.92|4.88|highlight sort of the the key takeaways
902.079|5.361|and then i will be very happy um to go
904.8|4.32|and uh you know explore any of this in
907.44|4.16|as much depth i'm free for another hour
909.12|3.839|after this call um and just happy to
911.6|3.12|talk in as much depth as people want
912.959|2.641|about the details of this
914.72|2.559|so
915.6|3.599|um it turns out this phase change
917.279|4.641|doesn't happen in a one layer attention
919.199|4.161|only transformer and it does happen in a
921.92|2.479|two-layer attention-only transformer so
923.36|2.88|if we could understand a one-layer
924.399|3.68|attenuate transformer and a two layer
926.24|3.839|only attention potentially transformer
928.079|4.721|that might give us a pretty big clue as
930.079|2.721|to what's going on
932.88|3.04|um
934.72|2.88|so we're attention only we're also going
935.92|3.68|to leave out layer and biases to
937.6|4.4|simplify things so you know you one way
939.6|3.52|you could describe a attention only
942.0|3.36|transformer
943.12|3.44|is we're going to embed our tokens
945.36|2.88|and then we're going to apply a bunch of
946.56|3.519|attention heads and add them into the
948.24|3.519|residual stream and then apply our
950.079|3.12|unembedding and that'll give us our
951.759|2.64|logits
953.199|2.56|and we can go and write that out as
954.399|2.721|equations if we want multiplied by an
955.759|3.44|embedding matrix
957.12|3.839|apply attention heads
959.199|4.08|and then compute the logics from the
960.959|3.761|unembedding
963.279|3.36|um
964.72|3.919|and the part here that's a little tricky
966.639|3.601|is understanding the attention ads and
968.639|3.44|this might be a somewhat conventional
970.24|4.0|way of describing attention and it
972.079|3.841|actually kind of obscures a lot of the
974.24|3.92|structure of attentionnets and i think
975.92|3.839|that oftentimes it's we we make
978.16|3.44|attention heads more more complex than
979.759|2.64|they are we sort of hide the interesting
981.6|2.239|structure
982.399|2.88|so what is this saying let's say you
983.839|4.161|know for every token compute a value
985.279|3.841|back a value vector and then go and mix
988.0|3.279|the value vectors according to the
989.12|3.76|attention matrix and then project them
991.279|3.521|with the output matrix back into the
992.88|4.959|residual string
994.8|4.56|um so there's there's another notation
997.839|4.8|which you could think of this as a as
999.36|4.32|using tensor products or using um using
1002.639|2.56|uh
1003.68|2.959|well i guess there's a few left and
1005.199|3.361|right multiplying there's a few ways you
1006.639|4.0|can interpret this but um
1008.56|4.56|i'll just sort of try to explain what
1010.639|3.76|this notation means um
1013.12|3.76|so this means
1014.399|4.88|for every you know x or our residual
1016.88|3.6|string we have a vector for every single
1019.279|3.201|token
1020.48|4.16|and this means go and multiply
1022.48|4.88|independently the vector for each token
1024.64|4.799|by wv so compute the value vector for
1027.36|3.599|every token
1029.439|3.281|this one on the other hand means notice
1030.959|3.6|that it's now on the a is on the left
1032.72|3.04|hand side it means go and go and
1034.559|2.801|multiply
1035.76|3.76|the
1037.36|3.599|attention matrix or go and go into
1039.52|3.039|linear combinations of the values value
1040.959|3.281|vectors so don't don't change the value
1042.559|2.88|vectors you know point wise but go and
1044.24|3.92|mix them together according to the
1045.439|4.881|attention pattern create a weighted sum
1048.16|5.12|and then again independently for every
1050.32|4.32|position go and apply the output matrix
1053.28|2.96|and you can apply the distributive
1054.64|3.2|property to this and it just reveals
1056.24|3.12|that actually it didn't matter that you
1057.84|2.48|did the attention sort of in the middle
1059.36|2.0|you could have done the attention at the
1060.32|3.92|beginning you could have done it at the
1061.36|4.24|end um that's that's independent um and
1064.24|4.4|the thing that actually matters is
1065.6|5.12|there's this wvwo matrix that describes
1068.64|4.24|what it's really saying is you know
1070.72|3.92|wvw describes what information the
1072.88|3.6|attention head reads from each position
1074.64|4.48|and how it writes it to its destination
1076.48|4.24|whereas a describes which tokens we read
1079.12|3.439|from and write to
1080.72|3.12|um and that's that's kind of getting
1082.559|3.12|more the fundamental structure and
1083.84|3.44|attention an attention head goes and
1085.679|4.401|moves information from one position to
1087.28|4.24|another and the process of of which
1090.08|3.44|position gets moved from and two is
1091.52|4.32|independent from what information gets
1093.52|2.32|moved
1097.2|3.04|and if you rewrite your transformer that
1099.52|3.279|way
1100.24|4.88|well first we can go and write uh the
1102.799|3.521|sum of attention heads just as as in
1105.12|4.24|this form
1106.32|5.2|um and then we can uh go and write that
1109.36|4.8|as the the entire layer by going and
1111.52|5.36|adding an identity
1114.16|6.68|and if we go and plug that all in to our
1116.88|6.799|transformer and go and expand
1120.84|4.44|um we we have to go and multiply
1123.679|4.0|everything through we get this
1125.28|3.759|interesting equation and so we get this
1127.679|2.561|one term this corresponds to just the
1129.039|2.241|path directly through the residual
1130.24|2.88|stream
1131.28|3.84|and it's going to want to store uh
1133.12|3.439|bigram statistics it's just you know all
1135.12|2.96|i guess is the previous token and tries
1136.559|3.761|to predict the next token
1138.08|4.0|and so it gets to try and predict uh try
1140.32|3.92|to store bi-gram statistics and then for
1142.08|3.44|every attention head we get this matrix
1144.24|2.96|that says okay well for we have the
1145.52|3.039|attention pattern so it looks that
1147.2|3.44|describes which token looks at which
1148.559|4.0|token and we have this matrix here which
1150.64|3.2|describes how for every possible token
1152.559|3.601|you could attend to
1153.84|3.68|how it affects the logics and that's
1156.16|2.72|just a table that you can look at it
1157.52|2.96|just says you know for for this
1158.88|2.64|attention head if it looks at this token
1160.48|2.8|it's going to increase the probability
1161.52|5.2|of these tokens in a one layer attention
1163.28|3.44|only transformer that's all there is
1168.559|4.401|um yeah so this is just just the
1170.88|3.76|interpretation i was describing
1172.96|3.2|um
1174.64|2.32|and another thing that's worth noting is
1176.16|2.8|this
1176.96|4.719|the according to this the attention on
1178.96|4.719|the transformer is linear if you fix the
1181.679|3.041|attention pattern now of course it's the
1183.679|2.321|attention pattern isn't fixed but
1184.72|3.04|whenever you even have the opportunity
1186.0|3.28|to go and make something linear linear
1187.76|3.12|functions are really easy to understand
1189.28|2.639|and so if you can fix a small number of
1190.88|2.0|things and make something linear that's
1191.919|2.88|actually
1192.88|3.2|a lot of leverage
1194.799|2.801|okay
1196.08|3.12|um
1197.6|3.52|and yeah we can talk about how the
1199.2|4.0|attention pattern is computed as well
1201.12|4.32|um you if you expand it out you'll get
1203.2|5.04|an equation like this
1205.44|4.4|and uh notice well i think i think it'll
1208.24|4.0|be easier
1209.84|2.4|okay
1212.48|3.76|the i think the core story though to
1214.159|3.441|take away from all of these is we have
1216.24|2.799|these two matrices that actually look
1217.6|2.959|kind of similar so
1219.039|3.681|this one here
1220.559|3.921|tells you if you attend to a token
1222.72|3.12|how are the logits affected
1224.48|3.92|and it's you can just think of it as a
1225.84|4.48|giant matrix of for every possible token
1228.4|3.279|input token how how is the logic how are
1230.32|3.12|the logics affected
1231.679|3.041|by that token are they made more likely
1233.44|2.88|or less likely
1234.72|3.68|and we have this one which sort of says
1236.32|5.04|how much does every token want to attend
1238.4|2.96|to every other token
1242.32|4.08|um one way that you can you can picture
1244.32|3.68|this is
1246.4|3.36|uh okay that's really there's really
1248.0|3.679|three tokens involved when we're
1249.76|2.88|thinking about an attention head we have
1251.679|2.321|the
1252.64|3.36|token that
1254.0|4.0|we're going to move information to and
1256.0|4.0|that's attending backwards
1258.0|4.0|we have the source token that's going to
1260.0|3.28|get attended to and we have the output
1262.0|2.88|token whose logits are going to be
1263.28|3.519|affected
1264.88|4.64|and you can just trace through this so
1266.799|4.801|you can ask what happens um how does the
1269.52|5.12|the attending to this token affect the
1271.6|6.0|output well first we embed the token
1274.64|4.88|then we multiply by wv to get the value
1277.6|3.28|vector the information gets moved by the
1279.52|3.039|attention pattern
1280.88|3.279|we multiply by wo to add it back into
1282.559|3.761|the residual stream we get hit by the
1284.159|4.0|unembedding and we affect the logits and
1286.32|2.88|that's where that one matrix comes from
1288.159|3.601|and we can also ask you know what
1289.2|3.92|decides you know whether a token gets a
1291.76|3.039|high score when we're when we're
1293.12|2.64|computing the attention pattern and it
1294.799|4.401|just says
1295.76|5.12|you know embed embed the token
1299.2|3.92|turn it into a query embed the other
1300.88|3.679|token turn it into a key
1303.12|2.88|and dot product to them and see you
1304.559|3.281|that's where those those two matrices
1306.0|4.24|come from
1307.84|4.079|so i know that i'm going quite quickly
1310.24|4.16|um
1311.919|3.441|maybe i'll just briefly pause here and
1314.4|2.8|if anyone wants to ask for
1315.36|3.76|clarifications uh this would be a good
1317.2|3.839|time and then we'll actually go and
1319.12|2.96|reverse engineer and and say you know
1321.039|2.801|everything that's going on in a
1322.08|3.839|one-layer pendulum transformer is now in
1323.84|3.839|the palm of our hands
1325.919|3.281|it's a very toy model
1327.679|2.641|you know one actually uses one layer
1329.2|3.28|attention on the transformers but we'll
1330.32|5.2|be able to understand the one layer
1332.48|3.04|attention only transformer
1336.559|3.281|so just to be clear so you're saying
1337.679|3.601|that yes the the
1339.84|3.199|quite key circuit is learning the
1341.28|3.2|attention weights
1343.039|3.041|and like essentially it's responsive
1344.48|3.12|running the sort of attention between
1346.08|3.12|different uh tokens
1347.6|3.84|yeah yeah so
1349.2|4.32|so this this matrix when it yeah you
1351.44|4.479|know all three of those parts are
1353.52|3.279|learned but that's that's what expresses
1355.919|2.88|whether
1356.799|3.36|a attention pattern is yeah that's what
1358.799|3.36|generates the attention patterns gets
1360.159|3.601|run for every pair of tokens and you can
1362.159|3.281|you can you can think of values in that
1363.76|3.2|matrix as just being how much every
1365.44|3.92|token wants to attend to every other
1366.96|3.68|token if it was in the context and we're
1369.36|2.48|we're drawing positional weddings here
1370.64|2.96|so there's a little bit that we're sort
1371.84|3.36|of aligning over there as well but sort
1373.6|2.8|of in in a global sense how much does
1375.2|2.64|every token want to attend every other
1376.4|2.72|token right
1377.84|3.04|and the other circuit like the output
1379.12|4.72|value circuit is
1380.88|4.72|using the attention that's calculated to
1383.84|4.24|guess
1385.6|4.24|like affect the final outputs it's sort
1388.08|3.04|of saying if if the attention head
1389.84|3.04|assume that the attention head attends
1391.12|2.96|to some token so let's set aside the
1392.88|3.12|question of how that gets computed just
1394.08|3.36|assume that it hence to some token how
1396.0|3.039|would it affect the outputs if it
1397.44|3.2|attended to that token
1399.039|4.0|and you can just you can just calculate
1400.64|4.159|that um it's just a big table of values
1403.039|2.721|that says you know for this token
1404.799|2.481|it's going to make this token more
1405.76|3.36|likely this token will make this token
1407.28|4.08|less likely
1409.12|3.52|right okay
1411.36|3.52|and it's completely independent like
1412.64|4.48|it's just two separate matrices they're
1414.88|3.44|they're not you know the the formulas
1417.12|3.28|that might make them seem entangled but
1418.32|4.719|they're actually separate
1420.4|4.08|all right so to me it seems like the
1423.039|3.281|lecture supervision is coming from the
1424.48|2.799|output value circuit and the query key
1426.32|2.32|second seems to be more like
1427.279|3.601|unsupervised kind of thing because
1428.64|4.56|there's no
1430.88|5.279|i mean they're just i think in the sense
1433.2|4.719|that every in in an yeah in a model like
1436.159|3.441|every every neuron is in some sense you
1437.919|4.161|know like
1439.6|4.559|signals is is somehow downstream from
1442.08|4.24|the ultimate the ultimate signal and so
1444.159|4.0|you know the output value signal the
1446.32|3.12|output value circuit is getting more
1448.159|4.481|more direct is perhaps getting more
1449.44|5.44|direct signal correct um but yeah
1452.64|2.24|yes
1456.64|4.0|we will be able to dig into this in lots
1458.4|4.96|of detail in as much detail as you want
1460.64|4.08|uh in a little bit so we can um maybe
1463.36|2.72|i'll push forward and i think also
1464.72|3.28|actually an example of how to use this
1466.08|3.52|reverse engineer one layer model will
1468.0|3.279|maybe make it a little bit more more
1469.6|3.36|motivated
1471.279|4.161|okay so
1472.96|4.24|um just just to emphasize this there's
1475.44|3.04|three different tokens that we can talk
1477.2|2.079|about there's a token that gets attended
1478.48|2.16|to
1479.279|2.721|there's the token that does the
1480.64|2.56|attention which are called the
1482.0|3.12|destination and then there's the token
1483.2|3.04|that gets affected yet it gets the next
1485.12|3.12|token which its probabilities are
1486.24|3.12|affected
1488.24|3.12|um
1489.36|4.08|and so something we can do is notice
1491.36|3.679|that the the only token that connects to
1493.44|2.719|both of these is the token that gets
1495.039|3.201|attended to
1496.159|3.361|so these two are sort of they're they're
1498.24|2.88|bridged
1499.52|3.36|by their their interaction with the
1501.12|2.96|source token so something that's kind of
1502.88|3.2|natural is to
1504.08|5.36|ask for a given source token you know
1506.08|3.36|how does it interact with both of these
1509.84|3.92|so let's let's take for instance the
1511.2|4.64|token perfect
1513.76|5.44|which tokens for one thing we can ask is
1515.84|5.12|which tokens want to attend to perfect
1519.2|4.16|well apparently the tokens that most
1520.96|5.28|want to attend to perfect are are and
1523.36|4.48|looks and is and provides
1526.24|2.96|um so r is the most looks is the next
1527.84|3.12|most and so on
1529.2|3.68|and then when we attempt to perfect and
1530.96|2.88|this is with one one single attention
1532.88|2.64|head so you know it'd be different if we
1533.84|2.88|did a different intention attention ed
1535.52|2.72|it wants to really increase the
1536.72|4.12|probability of perfect and then to a
1538.24|5.919|lesser extent super and absolute and
1540.84|6.28|pure and we can ask you know what what
1544.159|4.0|sequences of tokens are made more likely
1547.12|2.48|by this
1548.159|3.601|this particular
1549.6|3.439|um set of you know this particular set
1551.76|3.919|of things wanting to attend to each
1553.039|4.161|other and becoming more likely well
1555.679|3.441|things are the form
1557.2|3.44|we have our tokens we attended back to
1559.12|3.039|and we have some
1560.64|3.12|some skip of some number of tokens they
1562.159|3.281|don't have to be adjacent but then later
1563.76|3.279|on we see the token r and it attends
1565.44|3.839|back to perfect and increases the
1567.039|3.601|probability of perfect
1569.279|3.121|so you can you can think of these as
1570.64|2.96|being like we're sort of creating
1572.4|2.8|changing the probability of what we
1573.6|3.52|might call might call skip trigrams
1575.2|3.76|where we have you know we skip over a
1577.12|3.439|bunch of tokens in the middle but we're
1578.96|3.12|affecting the probability really of of
1580.559|3.36|trigrams
1582.08|2.959|so perfect our perfect perfect look
1583.919|2.961|super
1585.039|3.12|um we can look at another one so we have
1586.88|4.08|the token large
1588.159|4.4|um these tokens contains using specify
1590.96|3.68|want to go and look back to it and it
1592.559|3.841|increases probability of large and small
1594.64|4.56|and the skip trigrams that are affected
1596.4|5.6|are things like large using large
1599.2|5.28|large contained small
1602.0|4.799|and things like this
1604.48|3.439|um if we see the number two and we
1606.799|4.24|increase the probability of other
1607.919|6.0|numbers and we affect probable tokens or
1611.039|3.681|skipped diagrams like two one two
1613.919|2.64|two
1614.72|2.88|has three
1616.559|3.521|um
1617.6|3.6|now you're you're all in uh in a
1620.08|2.8|technical field so you'll probably
1621.2|4.959|recognize this one we have uh have
1622.88|4.64|lambda and then we see backslash and
1626.159|3.681|then we want to increase the probability
1627.52|4.56|of lambda and sorted and lambda and
1629.84|4.88|operator so it's all fall latex
1632.08|3.76|and it wants to and it's if it sees
1634.72|2.4|lambda it thinks that you know maybe
1635.84|3.36|next time i use a backslash i should go
1637.12|3.919|and put in some latex
1639.2|2.8|math symbol
1641.039|1.76|um
1642.0|3.6|also
1642.799|4.48|same thing for html we see nbsp for
1645.6|2.959|non-breaking space and then we see an
1647.279|2.561|ampersand we want to go and make that
1648.559|2.961|more likely
1649.84|3.36|the takeaway from all this is that a one
1651.52|4.879|layer attenuating transformer is totally
1653.2|4.079|acting on these skip trigrams
1656.399|2.321|um
1657.279|2.561|every everything that it does i mean i
1658.72|2.64|guess it also has this pathway by which
1659.84|3.52|it affects bi-grams but mostly it's just
1661.36|3.28|affecting these skiff trigrams
1663.36|3.36|um and there's lots of them it's just
1664.64|5.44|like these giant tables of skip trigrams
1666.72|3.36|that are made more or less likely
1670.559|1.84|um
1671.36|2.24|there's lots of other fun things that
1672.399|3.681|does sometimes the tokenization will
1673.6|4.16|split up a word in multiple ways so um
1676.08|3.199|like we have indie
1677.76|3.68|well that's that's not a good example we
1679.279|4.4|have like the word pike and then we
1681.44|3.76|we see the the token p and then we
1683.679|3.521|predict ike
1685.2|3.52|um when we predict spikes and stuff like
1687.2|2.32|that um
1688.72|2.0|or
1689.52|2.24|these these ones are kind of fun maybe
1690.72|2.959|they're actually worth talking about for
1691.76|4.0|a second so we see
1693.679|3.761|the token void
1695.76|2.96|and then we see an l and maybe we
1697.44|4.08|predict lloyd
1698.72|4.959|um or r and we predict ralph
1701.52|4.08|and c catherine
1703.679|3.681|and but we'll see in a second then well
1705.6|2.959|yeah we'll come back to that in a sec so
1707.36|3.52|we increase the probability of things
1708.559|3.84|like lloyd's lloyd and lloyd catherine
1710.88|3.36|or pixmap
1712.399|3.601|if anyone's worked with qt
1714.24|4.96|um it's we see pics map and we increase
1716.0|5.039|the probability of um p
1719.2|3.64|xmap again but also
1721.039|4.0|q
1722.84|4.36|canvas um
1725.039|3.36|yeah
1727.2|3.04|but of course there's a problem with
1728.399|2.961|this which is um
1730.24|2.64|it doesn't get to pick which one of
1731.36|4.24|these goes with which one
1732.88|3.919|so if you want to go and make pixmap
1735.6|4.16|pixmap
1736.799|4.801|and pixmap q canvas more probable you
1739.76|3.6|also have to go and create make pixmac
1741.6|3.04|pixmap p canvas
1743.36|3.199|more probable
1744.64|3.36|and if you want to make lloyd lloyd and
1746.559|3.12|lloyd catherine
1748.0|5.039|more probable you also have to make
1749.679|4.88|lloyd cloyd and lloyd lathron
1753.039|3.041|more probable
1754.559|3.36|and so there's actually like bugs that
1756.08|3.36|transformers have like weird at least
1757.919|3.201|and you know and these these really tiny
1759.44|3.04|one-layer attention only transformers
1761.12|3.2|there there's these bugs that you know
1762.48|3.919|they seem weird until you realize that
1764.32|3.68|it's this giant table of skip trigrams
1766.399|2.481|that's that's operating
1768.0|2.559|um
1768.88|2.96|and the the nature of that is that
1770.559|2.72|you're going to be
1771.84|3.92|um
1773.279|4.081|uh yeah you it sort of forces you if you
1775.76|4.639|want to go and do this to go in and also
1777.36|4.96|make some weird predictions
1780.399|4.081|chris
1782.32|3.52|is there a reason why the source tokens
1784.48|2.4|here have a space before the first
1785.84|3.92|character
1786.88|5.039|yes um that's just the i was giving
1789.76|4.96|examples where the tokenization breaks
1791.919|5.601|in a particular way and okay um because
1794.72|3.839|spaces get included in the tokenization
1797.52|2.159|um
1798.559|2.641|when there's a space in front of
1799.679|3.041|something and then there's an example
1801.2|3.44|where the space isn't in front of it
1802.72|4.16|they can get tokenized in different ways
1804.64|5.2|got it cool thanks
1806.88|2.96|great question
1810.799|2.801|um
1811.84|2.88|okay so some just to abstract away some
1813.6|2.88|common patterns that we're seeing i
1814.72|2.959|think um
1816.48|3.199|one pretty common thing is what you
1817.679|4.72|might describe as like d
1819.679|4.081|a b so you're you go and you you see
1822.399|2.88|some token and then you see another
1823.76|3.039|token that might precede that token then
1825.279|3.681|you're like ah probably the token that i
1826.799|4.48|saw earlier is going to occur again
1828.96|4.56|um or sometimes you you predict a
1831.279|4.081|slightly different token so like maybe
1833.52|3.36|maybe an example the first one is two
1835.36|3.12|one two
1836.88|2.96|but you could also do two
1838.48|2.96|has three
1839.84|2.88|and so three isn't the same as two but
1841.44|2.8|it's kind of similar so that's that's
1842.72|2.72|one thing another one is this this
1844.24|2.48|example where you've a token that
1845.44|3.599|something it's tokenized together one
1846.72|4.0|time and that's split apart so you see
1849.039|2.721|the token and then you see something
1850.72|2.4|that might be the first part of the
1851.76|3.279|token and then you predict the second
1853.12|3.76|part
1855.039|3.36|and
1856.88|4.159|i think the thing that's really striking
1858.399|5.041|about this is these are all in some ways
1861.039|3.52|a really crude kind of in context
1863.44|2.88|learning
1864.559|4.0|and and
1866.32|4.32|in particular these models get about 0.1
1868.559|3.521|nouns rather than about 0.4
1870.64|2.72|of incontex learning and they never go
1872.08|3.28|through the phase change so they're
1873.36|3.28|doing some kind of really crude and
1875.36|2.96|context learning and also they're
1876.64|3.36|dedicating almost all their attention
1878.32|2.959|heads to this kind of recruiting context
1880.0|3.279|learning so they're not very good at it
1881.279|4.801|but they're they're they're dedicating
1883.279|5.76|their um their capacity to it
1886.08|5.04|uh i'm noticing that it's 10 37 um
1889.039|3.441|i i want to just check how long i can go
1891.12|3.6|because i maybe i should like super
1892.48|4.079|accelerate because this is
1894.72|3.439|chris uh i think it's fine because like
1896.559|4.24|students are also asking questions in
1898.159|4.561|between such uh you should be good
1900.799|4.48|okay so maybe my plan will be that i'll
1902.72|5.6|talk until like 10 55 or 11 and then if
1905.279|5.28|you want i can go and answer questions
1908.32|3.52|for a while after after that
1910.559|2.48|yeah it works
1911.84|3.199|fantastic
1913.039|3.841|so you can see this as a very crude kind
1915.039|3.52|of in context learning like basically
1916.88|2.96|what we're saying is it's sort of all
1918.559|3.201|this flavor of okay well i saw this
1919.84|3.439|token probably these other tokens the
1921.76|3.44|same token or similar tokens are more
1923.279|3.28|likely to go and occur later and look
1925.2|2.8|this is an opportunity that sort of
1926.559|2.96|looks like i can inject the token that i
1928.0|2.96|saw earlier i'm going to inject it here
1929.519|3.76|and say that it's more likely that's
1930.96|3.92|like that's basically what it's doing
1933.279|3.361|and it's dedicating almost all of its
1934.88|2.96|capacity to that so you know these it's
1936.64|2.8|sort of the opposite of what we thought
1937.84|3.12|with rnn's in the past like used to be
1939.44|4.32|that everyone was like oh you know rnn's
1940.96|4.4|it's so hard to care about long distance
1943.76|4.159|contacts you know maybe we need to go
1945.36|4.159|and like use dams or something no if you
1947.919|2.88|if you train a transformer it dedicates
1949.519|2.801|and you give it a long a long enough
1950.799|4.961|context it's dedicating almost all of
1952.32|5.92|its capacity um to this type of stuff um
1955.76|4.48|just kind of interesting
1958.24|5.279|um there are some attentions which are
1960.24|4.72|more primarily positional um usually we
1963.519|3.201|in the model that i've been training
1964.96|3.36|that has two layer or it's only a one
1966.72|3.12|layer model has twelve attention units
1968.32|2.88|and usually around two or three of those
1969.84|3.12|will become these more positional sort
1971.2|4.4|of shorter term things that do something
1972.96|3.92|more like like local trigram statistics
1975.6|4.079|and then everything else becomes these
1976.88|2.799|skipped programs
1980.88|5.12|um yeah so uh some takeaways from this
1983.76|3.919|uh yeah you can you can understand one
1986.0|4.559|layer eventually transformers in terms
1987.679|4.401|of these ov and qk circuits um
1990.559|3.521|transformers desperately want to do
1992.08|4.56|in-context learning they desperately
1994.08|4.479|desperately desperately want to go and
1996.64|3.039|and look at these long distance contacts
1998.559|2.72|and go and predict things there's just
1999.679|4.161|so much so much entropy that they can go
2001.279|3.76|and reuse out of that
2003.84|2.48|the constraints of a when they are
2005.039|2.401|intentionally transformer force it to
2006.32|2.16|make certain bugs but it wants to do the
2007.44|1.92|right thing
2008.48|2.72|um
2009.36|4.48|and if you freeze the attention patterns
2011.2|3.68|these models are linear
2013.84|2.0|okay
2014.88|3.76|um
2015.84|4.4|a quick aside because so far this type
2018.64|2.72|of work has required us to do a lot of
2020.24|2.799|very manual inspection like we're
2021.36|3.52|walking through these giant matrices but
2023.039|3.041|there's a way that we can escape that we
2024.88|2.799|don't have to use look at these giant
2026.08|3.439|matrices if we don't want to
2027.679|3.281|um we can use eigenvalues and
2029.519|3.04|eigenvectors so recall that an
2030.96|3.68|eigenvalue
2032.559|3.521|and an eigenvector just means that if
2034.64|4.159|you if you multiply that vector by the
2036.08|4.16|matrix um it's equivalent to just
2038.799|2.321|scaling
2040.24|2.159|and
2041.12|2.48|uh often
2042.399|2.481|in my experience those haven't been very
2043.6|2.48|useful for interpretability because
2044.88|2.96|we're usually mapping between different
2046.08|3.36|spaces but if you're mapping onto the
2047.84|3.839|same space either values either vectors
2049.44|5.04|are a beautiful way to think about this
2051.679|4.081|um so we're going to draw them um
2054.48|2.8|on a
2055.76|3.68|a radial plot
2057.28|3.68|um and we're going to have a log
2059.44|3.439|uh radial scale because they're gonna
2060.96|4.56|vary their magnitude's gonna vary in by
2062.879|4.8|many orders of magnitude
2065.52|3.839|um okay so we can just go and you know
2067.679|3.281|our ob circuit maps from tokens to
2069.359|3.52|tokens that's the same vector space and
2070.96|3.52|the input and the output and we can ask
2072.879|3.921|you know what does it mean if we see
2074.48|3.679|eigenvalues of a particular kind well
2076.8|3.68|positive eigenvalues and this is really
2078.159|3.76|the most important part mean copying so
2080.48|4.399|if you have a positive eigenvalue it
2081.919|4.081|means that there's some set of of tokens
2084.879|2.72|where if you if you see them you
2086.0|2.72|increase their probability
2087.599|3.28|and if you have a lot of positive
2088.72|3.439|eigenvalues um you're doing a lot of
2090.879|3.841|copying if you only have positive
2092.159|4.561|eigenvalues everything you do is copying
2094.72|3.68|um now imaginary eigenvalues mean that
2096.72|2.56|you see a token and then you want to go
2098.4|2.959|and increase the probability of
2099.28|3.44|unrelated tokens and finally negative
2101.359|2.801|eigenvalues are anti-copying they're
2102.72|4.56|like if you see this token you make it
2104.16|4.64|less probable in the future
2107.28|2.48|well that's really nice because now we
2108.8|2.72|don't have to go and dig through these
2109.76|3.28|giant matrices that are vocab size by
2111.52|2.72|vocab size we can just look at the
2113.04|3.68|eigenvalues
2114.24|4.48|um and so these are the eigenvalues for
2116.72|4.399|our one layer attention only transformer
2118.72|3.84|and we can see that you know
2121.119|3.041|for
2122.56|3.68|many of these they're almost entirely
2124.16|4.16|positive these events are are sort of
2126.24|4.08|entirely positive these ones are almost
2128.32|3.519|entirely positive and really these ones
2130.32|2.88|are even almost entirely positive and
2131.839|3.121|there's only two
2133.2|4.32|that have a significant number of
2134.96|4.159|imaginary and negative eigenvalues
2137.52|3.28|um and so what this is telling us is
2139.119|5.041|it's just in one picture we can see you
2140.8|5.2|know okay they're really you know
2144.16|3.36|10 out of 12 of these of these attention
2146.0|2.96|heads are just doing copying they just
2147.52|3.04|they just are doing this long distance
2148.96|3.52|you know well i saw a token probably
2150.56|3.2|it's going to occur again type stuff um
2152.48|4.32|that's kind of cool we can we can
2153.76|3.92|summarize it really quickly
2156.8|1.6|okay
2157.68|2.8|um
2158.4|3.36|now the other thing that you can yeah so
2160.48|2.56|this is this is for a second we're gonna
2161.76|2.72|look at a two-layer model in a second
2163.04|3.6|and we'll we'll see that also a lot of
2164.48|3.359|its heads are doing this kind of copying
2166.64|3.36|or stuff they have large positive
2167.839|4.161|eigenvalues
2170.0|3.119|um you can do a histogram like you know
2172.0|3.52|one one thing that's cool is you can
2173.119|3.761|just add up the uh the eigenvalues and
2175.52|2.48|divide them by their absolute values and
2176.88|3.04|you get a number between zero and one
2178.0|3.2|which is like how copying how copying is
2179.92|2.88|just the head or between negative one
2181.2|3.2|and one how copying is just the head you
2182.8|3.44|can just do a histogram you can see oh
2184.4|3.92|yeah almost all the heads are doing
2186.24|3.04|doing lots of copying
2188.32|2.96|you know it's nice to be able to go and
2189.28|3.52|summarize your model you know uh and i
2191.28|3.76|think this is this is sort of like we've
2192.8|3.279|gone for a very bottom-up way and we
2195.04|2.48|didn't start with assumptions about what
2196.079|2.561|model is doing we tried to understand
2197.52|2.559|its structure and then we were able to
2198.64|2.479|summarize it in useful ways and now
2200.079|3.04|we're able to go and say something about
2201.119|4.081|it
2203.119|3.761|um now another thing you might ask is
2205.2|3.76|what what do the the eigenvalues of the
2206.88|3.76|qk circuit mean and in our example so
2208.96|3.28|far they haven't been that they wouldn't
2210.64|2.8|have been that interesting but in a
2212.24|2.8|minute they will be and so i'll briefly
2213.44|2.96|describe what they mean a positive
2215.04|3.12|eigenvalue would mean you want to attend
2216.4|3.6|to the same tokens
2218.16|3.439|and imagine your eigenvalue and this is
2220.0|3.119|what you would mostly see in our models
2221.599|3.681|we've seen so far means you want to go
2223.119|3.361|in and attend to a unrelated or
2225.28|2.88|different token
2226.48|3.119|and a negative eigenvalue would mean you
2228.16|3.76|want to avoid attending to the same
2229.599|4.721|triplet
2231.92|4.56|so that will be relevant in a second
2234.32|3.92|um yes so those are going to mostly be
2236.48|3.2|useful to think about in in multi-layer
2238.24|2.96|potentially transformers when we kind of
2239.68|3.36|change the attention heads and so we can
2241.2|3.52|ask you know well i'll get to that in a
2243.04|4.0|second yeah so there's a table
2244.72|3.76|summarizing that um unfortunately this
2247.04|3.84|this approach completely breaks down
2248.48|3.52|once you have mlp layers mlp layers you
2250.88|2.32|know now you have have these
2252.0|2.4|non-linearities and so you don't get
2253.2|2.8|this property where your model is mostly
2254.4|3.36|linear and you can you can just look at
2256.0|2.88|a matrix but if you're working with only
2257.76|3.04|attention only transformers this is a
2258.88|4.0|very nice way to think about effects
2260.8|3.6|okay so recall that one that you're
2262.88|2.64|intentionally transformers don't undergo
2264.4|2.48|this phase change that we talked about
2265.52|2.72|in the beginning like right now we're on
2266.88|3.36|a hunt we're trying to go and answer
2268.24|3.119|this mystery of how what the hell is
2270.24|2.56|going on in that phase change where
2271.359|3.921|models suddenly get good at in context
2272.8|3.92|learning um we want to answer that and
2275.28|3.2|one layer attention only transformers
2276.72|3.6|don't undergo that phase change but two
2278.48|3.119|layer attenuation transformers do so
2280.32|5.24|we'd like to know what's different about
2281.599|3.961|two layer attention only transformers
2286.56|3.2|um
2287.44|3.6|okay well so in our in our previous when
2289.76|2.24|we're dealing with one layer attention
2291.04|2.88|transformers we're able to go and
2292.0|3.92|rewrite them in this
2293.92|3.919|this form and it gave us a lot of struct
2295.92|2.88|ability to go and understand the model
2297.839|2.961|because we could go and say well you
2298.8|3.68|know this is bi-grams and then each one
2300.8|2.88|of these is looking somewhere and we
2302.48|3.599|have this matrix that describes how it
2303.68|4.48|affects things and
2306.079|3.921|and yeah so that gave us a lot of a lot
2308.16|3.919|of ability to think about this thing
2310.0|3.2|these things and we we can also just
2312.079|2.241|write in this factored form where we
2313.2|2.24|have the embedding and then we have the
2314.32|3.519|attention heads and then we have the
2315.44|4.0|unembedding
2317.839|2.481|okay well
2319.44|2.639|um
2320.32|5.039|oh and for simplicity we often go and
2322.079|4.961|write wov for wowv because they always
2325.359|3.201|come together it's always the case like
2327.04|3.28|it's it's in some sense an illusion that
2328.56|3.279|w o and wv are different matrices
2330.32|2.799|they're just one low rank matrix they're
2331.839|3.441|never they're they're always used
2333.119|3.601|together and similarly w q and w k it's
2335.28|3.52|sort of an illusion that they're they're
2336.72|3.84|different matrices um they're they're
2338.8|2.88|always just used together and and keys
2340.56|2.799|and queries are just sort of they're
2341.68|3.36|just an artifact of this of these low
2343.359|2.961|rank matrices
2345.04|2.64|so in any case it's useful to go and
2346.32|3.6|write those together
2347.68|3.84|um okay great so um a two-layer
2349.92|4.8|attention only transformer what we do is
2351.52|4.48|we we go through the embedding matrix
2354.72|2.72|then we go through the layer one
2356.0|3.2|attention heads then we go through the
2357.44|2.96|layer two attenuates
2359.2|3.04|and then we go through the unembedding
2360.4|3.76|and for the the attention is we always
2362.24|3.359|have this identity as well which
2364.16|2.88|corresponds just going down the residual
2365.599|2.961|string so we can
2367.04|4.0|uh go down the residual stream or we can
2368.56|3.44|go through an attention head
2371.04|2.4|next step we can also go down the
2372.0|4.0|residual stream or we can go through an
2373.44|2.56|attention head
2377.44|5.12|um and there's this useful identity uh
2380.079|4.401|the mixed product identity that um any
2382.56|4.48|tensor product or or other ways of
2384.48|4.639|interpreting this um obey which is that
2387.04|3.76|if you have an attention head
2389.119|3.201|um and we have say you know we have the
2390.8|3.52|weights and the attention pattern and
2392.32|3.84|the wov matrix and the attention pattern
2394.32|4.56|the attention patterns multiply together
2396.16|6.16|and the ov circuits multiply together
2398.88|5.36|um and they behave nicely okay great so
2402.32|3.279|and we can just expand out that equation
2404.24|2.96|we can just take that big product we had
2405.599|2.72|at the beginning we just expanded out
2407.2|3.6|and we get three different kinds of
2408.319|3.921|terms so one thing we do is we get this
2410.8|2.559|this path that just goes directly
2412.24|2.72|through the residual stream where we
2413.359|5.361|embed and unembed and that's going to
2414.96|6.399|want to represent some bigram statistics
2418.72|4.399|um then we get things that look like
2421.359|4.48|the attention head terms that we had
2423.119|2.72|previously
2426.319|4.881|and finally
2428.8|5.519|we get these terms that correspond to
2431.2|3.119|going through two attention heads
2436.16|2.88|and
2437.28|3.76|now it's worth noting that these terms
2439.04|3.44|are not actually the same as they're
2441.04|2.72|because the attention head uh the
2442.48|3.04|attention patterns in the next in the
2443.76|3.44|second layer can be computed from the
2445.52|3.36|outputs of the first layer there those
2447.2|2.879|are also going to be more expressive but
2448.88|2.32|at a high level you can think of there
2450.079|3.601|as being these three different kinds of
2451.2|4.0|terms and we sometimes call these terms
2453.68|3.12|virtual attention nets because they they
2455.2|2.72|don't exist in the sun like they aren't
2456.8|4.16|sort of explicitly represented in the
2457.92|4.48|model but um they in fact you know they
2460.96|3.2|have an attention pattern they have no
2462.4|3.52|circuit they're sort of in almost all
2464.16|2.959|functional ways like a tiny little
2465.92|2.32|attention head and there's exponentially
2467.119|2.161|many of them
2468.24|1.839|um
2469.28|2.079|it turns out they're not going to be
2470.079|3.921|that important in this model but in
2471.359|4.96|other models they can be important
2474.0|3.76|um right so one one thing that i said it
2476.319|2.721|allows us to think about attention in a
2477.76|4.4|really principled way we don't have to
2479.04|4.72|go and think about um
2482.16|2.88|you know i think there's like people
2483.76|3.52|people look at attention patterns all
2485.04|3.68|the time and i think a concern you could
2487.28|2.799|have is well you know
2488.72|2.399|there's multiple attention patterns like
2490.079|2.321|you know the information that's been
2491.119|2.72|moved by one intention it might have
2492.4|3.12|been moved there by another attention
2493.839|4.161|ahead and not originally there it might
2495.52|3.92|still be moved somewhere else um but in
2498.0|2.56|fact this gives us a way to avoid all
2499.44|3.679|those concerns and just think about
2500.56|5.36|things in a single principled way
2503.119|4.321|um okay in any case um an important
2505.92|3.12|question to ask is how important are
2507.44|3.76|these different terms well we could
2509.04|3.2|study all of them how important are they
2511.2|3.6|um
2512.24|3.68|and it turns out um you can just
2514.8|3.039|there's an algorithm you can use where
2515.92|3.199|you knock out attention
2517.839|2.801|knock out these terms and you go and you
2519.119|4.561|ask how important are they
2520.64|4.88|um and the it turns out the by far the
2523.68|3.52|most important thing is these individual
2525.52|3.44|attention head terms in this model far
2527.2|3.76|by far the most important thing the
2528.96|3.52|virtual tension heads basically
2530.96|3.2|don't matter that much
2532.48|3.44|they only have an effect of 0.3 not
2534.16|3.52|using to be the above ones and the
2535.92|3.12|bigrams are still pretty useful so if we
2537.68|2.399|want to try it on channel's model we
2539.04|2.88|should probably go and focus our
2540.079|3.441|attention on you know the virtual
2541.92|4.64|attention heads are not going to be the
2543.52|4.319|best way to go in and go in our uh focus
2546.56|2.88|our attention especially since there's
2547.839|4.0|there's a lot of them there's 124 of
2549.44|4.24|them for 0.3 knots it's very little that
2551.839|3.041|you would understand for prosthetic one
2553.68|2.96|of those terms
2554.88|3.6|so the thing that we probably want to do
2556.64|3.12|we know that these are bigram statistics
2558.48|2.32|so what we really want to do is we want
2559.76|1.92|to understand
2560.8|5.039|the
2561.68|4.159|the individual tension head terms
2566.88|2.64|um this is the algorithm i'm going to
2568.079|2.801|skip over it for time
2569.52|2.319|we can ignore that term because it's
2570.88|2.0|small
2571.839|2.721|um
2572.88|3.76|and it turns out also that the layer two
2574.56|3.68|attention heads are doing way more than
2576.64|3.52|layer one attention so that's that's not
2578.24|3.2|that surprising like the layer two
2580.16|2.4|intense are more expressive because they
2581.44|4.08|can use the layer one attention to
2582.56|4.96|construct their attention patterns
2585.52|3.28|okay so uh if we could just go and
2587.52|2.88|understand the layer two attention heads
2588.8|4.16|we probably understand a lot of what's
2590.4|3.76|going on in this model
2592.96|2.639|um
2594.16|3.28|and the trick is that the attention
2595.599|3.121|heads are now constructed from the
2597.44|3.52|previous layer rather than just from the
2598.72|4.08|tokens so this is still the same but the
2600.96|3.76|attention head the attention pattern is
2602.8|4.0|more more complex and if you write it
2604.72|3.84|out you get this complex equation that
2606.8|3.2|says you know you embed the tokens then
2608.56|2.72|you're going to shuffle things around
2610.0|3.359|using the attention edits for the keys
2611.28|3.68|then you multiply by w uk then you
2613.359|3.521|multiply shuffle things around again for
2614.96|3.119|the queries and then you go and multiply
2616.88|2.239|by the embedding again because they were
2618.079|4.24|embedded and then you get back to the
2619.119|3.2|tokens um
2622.4|3.679|uh
2623.839|4.0|but let's actually look at them so
2626.079|3.201|uh one thing that's remember that when
2627.839|3.201|we see positive eigenvalues in the ob
2629.28|4.48|circuit we're doing copying so one thing
2631.04|3.68|we can say is well 7 out of 12 and in
2633.76|4.079|fact the ones with the largest
2634.72|4.24|eigenvalues um are doing coffeeing so we
2637.839|3.76|still have a lot of attention they're
2638.96|2.639|doing copying
2642.56|4.4|um
2644.079|3.601|and yeah the qk circuit so one one thing
2646.96|1.84|you could do is you could try to
2647.68|2.639|understand things in terms of this more
2648.8|2.72|complex qk equation you could also just
2650.319|3.28|try to understand what the attention
2651.52|4.0|patterns are doing empirically so let's
2653.599|4.0|look at one of these copying ones
2655.52|3.76|um i've given it the first paragraph of
2657.599|5.0|harry potter and we can just look at
2659.28|3.319|where it attends
2663.2|2.72|and something really happened
2664.64|2.08|interesting happens so almost all the
2665.92|2.64|time
2666.72|3.359|we just attend back to
2668.56|2.559|the first token we have this this
2670.079|2.081|special token at the beginning of the
2671.119|2.321|sequence
2672.16|3.439|and we usually think of that as just
2673.44|3.679|being um a null attention operation it's
2675.599|3.041|a way for it to not do anything in fact
2677.119|3.121|if you if you look the value vector is
2678.64|3.84|basically zero it's just not copying any
2680.24|3.839|information from that
2682.48|3.92|um
2684.079|3.601|but when whenever we see repeated text
2686.4|3.12|something interesting happens so when we
2687.68|3.36|get to mr
2689.52|4.88|tries to look at and it's a little bit
2691.04|3.36|weak then we get to d
2694.64|3.12|and it tends to errors
2696.319|4.161|that's interesting
2697.76|5.839|and then we get to ers
2700.48|6.16|and it tends to lean
2703.599|4.881|um and so it's not attending to
2706.64|3.6|the same token it's attending to the
2708.48|3.92|same token
2710.24|3.92|shifted one forward
2712.4|3.439|well that's really interesting and
2714.16|2.959|there's actually a lot of attention nets
2715.839|3.841|that are doing this so here we have one
2717.119|4.561|where now we hit the potter's pot and we
2719.68|2.96|attend deters maybe that's the same
2721.68|2.639|tension i don't remember when i was
2722.64|3.28|constructing this example
2724.319|3.76|um it turns out this is a super common
2725.92|3.6|thing so you you go and you you look for
2728.079|2.561|the previous example you shift one
2729.52|2.64|forward and you're like okay well last
2730.64|4.719|time i solved this this is what happened
2732.16|3.199|probably the same thing's gonna happen
2736.8|4.4|um and we can we can go and look at the
2739.04|3.84|effect that the attention head has on
2741.2|3.44|the logits most of the time it's not
2742.88|3.6|affecting things but in these cases it's
2744.64|3.04|able to go and predict when it's doing
2746.48|4.639|us this thing of going and looking
2747.68|3.439|forward to go and predict the next token
2751.2|3.2|um so we call this an induction an
2752.72|3.84|induction head looks for the previous
2754.4|3.52|copy looks forward and says ah probably
2756.56|2.72|the same thing that happened last time
2757.92|2.96|it's gonna happen you can think of this
2759.28|3.36|as being a nearest neighbor's it's like
2760.88|3.12|an in-context nearest neighbor's
2762.64|3.04|algorithm it's going and searching
2764.0|3.119|through your context finding similar
2765.68|4.08|things and then predicting that's what's
2767.119|2.641|gonna happen next
2770.48|4.32|um
2771.44|5.6|the way that these actually work is uh i
2774.8|3.6|mean there's actually two ways but in a
2777.04|2.88|model that uses rotary attention or
2778.4|2.48|something like this you only only have
2779.92|2.48|one
2780.88|4.479|and
2782.4|4.24|you shift your key first you have
2785.359|3.601|an earlier attention head shifts your
2786.64|3.439|key forward once you you like take the
2788.96|3.2|value of the previous token and you
2790.079|3.28|embed it in your present token
2792.16|2.88|and then you have your query and your
2793.359|2.72|key go and look
2795.04|2.0|at
2796.079|2.401|uh
2797.04|3.2|yeah try to go and match so you look for
2798.48|3.68|the same thing
2800.24|3.76|um and then you go and you predict that
2802.16|3.679|whatever you saw is going to be the next
2804.0|4.16|token so that's the the high-level
2805.839|3.921|algorithm um sometimes you can do clever
2808.16|3.12|things where actually it'll care about
2809.76|3.2|multiple earlier tokens and it'll look
2811.28|3.36|for like short phrases and so on so
2812.96|3.28|induction heads can really vary in in
2814.64|2.719|how much they of the previous context
2816.24|2.8|they care about or what aspects of the
2817.359|3.521|previous context they care about but
2819.04|4.48|this general trick of looking for the
2820.88|5.12|same thing shift forward predict that is
2823.52|4.88|what induction has been
2826.0|4.8|um lots of examples of this
2828.4|4.32|and the cool thing is you can now
2830.8|3.36|you can use the qk eigenvalues to
2832.72|3.28|characterize this you can say well you
2834.16|3.28|know we we're looking for the same thing
2836.0|2.8|shifted by one but looking for the same
2837.44|2.399|thing if you expand through the
2838.8|1.92|attention notes in the right way that'll
2839.839|2.961|work out
2840.72|5.2|um and we're copying and so an induction
2842.8|5.12|head is one which has both positive ov
2845.92|4.639|eigenvalues and also positive qk
2847.92|2.639|eigenvalues
2852.079|4.081|um and so you can just put that on a
2853.52|4.16|plot and you have your induction heads
2856.16|4.48|in the corner see
2857.68|4.72|here ov eigen values your qk eigenvalues
2860.64|3.919|i think actually ov is this axis qk is
2862.4|3.84|this one access doesn't matter um and in
2864.559|2.641|the corner you have your your icon
2866.24|4.8|values
2867.2|6.96|or your um your induction heads
2871.04|4.64|um yeah and so this seems to be uh well
2874.16|3.439|okay we now have a natural hypothesis
2875.68|3.36|the hypothesis is the way that that
2877.599|3.121|phase change we're seeing the phase
2879.04|3.92|changes this is the discovery of these
2880.72|4.56|induction heads that would be um the
2882.96|4.0|hypothesis uh and these are way more
2885.28|3.039|effective than regular you know than
2886.96|2.639|this first algorithm we had which was
2888.319|2.881|just sort of blindly copy things
2889.599|3.441|wherever it could be plausible now we
2891.2|3.28|can go and like actually recognize
2893.04|2.559|patterns and look at what happened and
2894.48|2.4|break that similar things are going to
2895.599|3.76|happen again that's a way better
2896.88|2.479|algorithm
2899.599|2.561|um
2901.2|2.08|yeah so there's other attention heads
2902.16|3.12|that are doing more local things i'm
2903.28|3.2|gonna go and skip over that and return
2905.28|3.68|to our mystery because i am running out
2906.48|3.839|of time i have five more minutes okay so
2908.96|2.72|what what is going on with this in
2910.319|3.681|context learning well now now we've
2911.68|4.639|hypothesis let's check it um so we think
2914.0|3.68|it might be induction heads
2916.319|2.881|um
2917.68|3.28|and there's a few reasons we believe
2919.2|4.08|this so one thing is going to be that
2920.96|4.08|inductive uh induction heads
2923.28|3.76|well okay i'll just go over to the other
2925.04|4.079|so one thing you can do is you can just
2927.04|4.24|ablate the attention ends
2929.119|4.48|and it turns it um you can color here we
2931.28|4.24|have attention heads colored by how much
2933.599|4.24|they are in induction head
2935.52|4.24|and this is the start of the bump this
2937.839|3.601|is the end of the bump here
2939.76|2.799|and we can see that they first of all
2941.44|2.56|induction heads are forming like
2942.559|3.201|previously we didn't have induction
2944.0|3.76|heads here now they're just starting to
2945.76|5.359|form here and then we have really
2947.76|5.04|intense induction heads here and here
2951.119|4.0|and the attention heads where if you
2952.8|3.759|ablate them and you get
2955.119|3.521|a uh
2956.559|3.681|you get a a loss and so we're we're
2958.64|3.439|lucky not lost but this this meta
2960.24|3.04|learning score the difference between or
2962.079|3.04|in context learning store the the
2963.28|3.2|difference between the 500th token and
2965.119|3.921|the 50th token
2966.48|4.32|and that's all explained by induction
2969.04|2.96|heads
2970.8|2.64|now we actually have one induction head
2972.0|2.96|that doesn't contribute to it actually
2973.44|3.04|it does the opposite so that's kind of
2974.96|3.84|interesting uh maybe it's doing
2976.48|3.359|something shorter shorter distance um
2978.8|2.48|and there's also this interesting thing
2979.839|3.361|where like they all rush to be induction
2981.28|3.68|heads and then they they discover only
2983.2|2.96|only a few went out in the end so
2984.96|2.879|there's some interesting dynamics going
2986.16|3.439|on there but it really seems like in
2987.839|3.52|these small models
2989.599|4.321|all of in context learning is explained
2991.359|3.921|by these induction hats
2993.92|3.12|um okay
2995.28|3.039|what about large models well in large
2997.04|2.88|models it's going to be harder to go and
2998.319|3.361|ask this but one thing you can do is you
2999.92|4.32|can ask okay you know
3001.68|4.32|we can look at our uh our induction or
3004.24|4.64|our in-context learning score over time
3006.0|4.96|we get this sharp phase change oh look
3008.88|3.84|induction heads form at exactly the same
3010.96|3.52|point in time
3012.72|3.28|so that's only correlational evidence
3014.48|2.8|but it's pretty suggestive correlational
3016.0|3.2|evidence even especially given that we
3017.28|3.12|have an obvious you know like the
3019.2|3.52|obvious the fact that induction heads
3020.4|3.52|should have is is this um i guess it
3022.72|2.32|could be that there's other mechanisms
3023.92|2.8|being discovered at the same time in
3025.04|2.96|large models but it has to be in a very
3026.72|2.56|small window
3028.0|3.04|so
3029.28|4.799|really suggest the thing that's driving
3031.04|4.4|that change is in context learning
3034.079|2.801|um okay so
3035.44|3.2|uh
3036.88|4.08|obviously induction heads can go and
3038.64|3.679|copy text but a question you might ask
3040.96|2.72|is you know can they can they do
3042.319|3.28|translation like there's all these
3043.68|3.76|amazing things that models can do that
3045.599|4.321|it's not obvious and you know in context
3047.44|3.6|learning um or this sort of copying
3049.92|2.24|mechanism could do so i just want to
3051.04|2.64|very quickly
3052.16|4.24|um
3053.68|4.48|look at a few fun examples
3056.4|2.8|so here we have
3058.16|3.04|um
3059.2|6.84|an attention pattern
3061.2|4.84|oh i guess i need to open lexus scopes
3068.319|3.841|hmm let me try doing that again
3070.96|3.359|sorry i should have thought this through
3072.16|3.36|a bit more before this talk
3074.319|2.881|um
3075.52|4.88|chris could you zoom in a little please
3077.2|5.6|yeah yeah thank you
3080.4|2.4|um
3098.88|3.28|okay i'm not my french isn't that great
3101.359|2.561|but
3102.16|2.88|um my name is christopher i'm from
3103.92|3.52|canada
3105.04|4.64|um what we can do here is we can look at
3107.44|4.08|where this attention head attends as we
3109.68|3.76|go and we do this and
3111.52|3.52|um it'll become especially clear on the
3113.44|3.04|second sentence so here we're on the
3115.04|3.519|period
3116.48|3.359|and we tend to shift
3118.559|4.241|now we're on
3119.839|6.0|um and jus is i in french okay now we're
3122.8|5.36|on the eye and we attend to speed
3125.839|5.121|uh now we're on the am and we are trends
3128.16|3.919|to do which is from and then from to
3130.96|3.599|canada
3132.079|4.76|and so we're doing a cross-lingual
3134.559|4.881|induction head which we can use for
3136.839|4.28|translation um and indeed if you look at
3139.44|3.04|examples this is this is where it seems
3141.119|3.44|to you know it seems to be a major
3142.48|6.16|driving force in the model's ability to
3144.559|6.28|go um and correctly do translation
3148.64|4.4|another fun example is
3150.839|3.641|um i think maybe maybe the most
3153.04|2.96|impressive thing about in context
3154.48|3.119|learning to me has been the model's
3156.0|2.96|ability to go and learn arbitrary
3157.599|2.801|functions like you can just show the
3158.96|4.879|model a function it can start mimicking
3160.4|3.439|that function well okay
3163.92|4.24|yes yeah so do these induction heads
3165.92|4.56|only do kind of a look ahead copy or
3168.16|3.84|like can they also do some sort of like
3170.48|3.839|a complex
3172.0|4.64|uh structure recognition
3174.319|4.881|yeah yeah so they can they can both use
3176.64|4.4|a larger context previous context and
3179.2|3.2|they can copy more abstract things so
3181.04|2.64|like the translation one is showing you
3182.4|3.199|that they can copy rather than the
3183.68|4.24|literal token a translated version so
3185.599|4.641|it's what i call a soft induction head
3187.92|3.84|um and yeah you can you can have them
3190.24|3.119|copy similar words you can have them
3191.76|3.92|look at longer contexts it can look for
3193.359|3.601|more structural things um
3195.68|3.36|the way that we usually characterize
3196.96|3.359|them is is whether in in large models
3199.04|3.279|just whether they empirically behave
3200.319|3.361|like an induction head so the the the
3202.319|2.8|bound the definition gets a little bit
3203.68|3.2|blurry when you try to encompass these
3205.119|3.601|more this sort of blurry a blurry
3206.88|3.199|boundary um but yeah there seem to be a
3208.72|4.32|lot of attention heads that are doing
3210.079|5.441|sort of more and more abstract versions
3213.04|4.319|and yeah my my favorite version is this
3215.52|4.48|one that i'm about to show you which is
3217.359|5.361|um used let's isolate a single one of
3220.0|4.72|these which can do pattern recognition
3222.72|3.76|so it can learn functions in the context
3224.72|4.32|and learn how to do it so i've just made
3226.48|4.16|up a nonsense function here um
3229.04|4.079|we're going to encode one binary
3230.64|5.52|variable with a choice of whether to do
3233.119|4.081|a color or a month as the first word
3236.16|2.56|then
3237.2|2.56|we're gonna so we have green or june
3238.72|4.24|here
3239.76|5.839|um let's zoom in more
3242.96|4.56|so we have color or month
3245.599|3.681|and animal or fruit and then we have to
3247.52|3.039|map it to either true or false
3249.28|2.96|so that's our goal and it's going to be
3250.559|4.241|an xor so we have a binary variable
3252.24|3.44|represented in this way we do an xor
3254.8|2.24|i'm
3255.68|2.72|pretty confident this was never in the
3257.04|3.519|training set because i just made it up
3258.4|4.32|and it seems like a nonsense problem
3260.559|4.081|um okay so then we can go and ask you
3262.72|3.92|know can the model go and push that well
3264.64|4.0|it can and it uses induction heads to do
3266.64|3.679|it and what we can do is we can look at
3268.64|2.8|the so we look at a colon where it's
3270.319|1.921|going to go and try and predict the next
3271.44|2.639|word
3272.24|5.04|and for instance here
3274.079|5.361|um we have april dog so it's a month and
3277.28|3.6|then an animal and it should be true
3279.44|3.28|and what it does is it looks for a
3280.88|3.04|previous previous cases where there was
3282.72|2.639|an animal
3283.92|3.28|a month and then an animal especially
3285.359|4.081|one where the month was the same and
3287.2|4.56|goes and looks and says that it's true
3289.44|3.6|and so the model can go and learn learn
3291.76|2.4|a function a completely arbitrary
3293.04|2.64|function
3294.16|3.04|by going and doing this kind of pattern
3295.68|3.439|recognition
3297.2|3.359|induction head
3299.119|4.881|and this to me made it a lot more
3300.559|5.52|plausible but these models actually
3304.0|3.68|can do
3306.079|3.04|can do in context learning like the
3307.68|4.159|generality of all these amazing things
3309.119|5.2|we see these large language models do um
3311.839|3.52|uh can be explained by inductionists we
3314.319|2.641|don't know that it could be that there's
3315.359|2.561|other things going on um it's very
3316.96|3.359|possible that there's lots of other
3317.92|3.84|things going on um but it seems seems a
3320.319|3.76|lot more plausible to me than it did
3321.76|4.319|when when we started
3324.079|3.28|i'm conscious that i am actually over
3326.079|3.04|time i mean just quickly go through
3327.359|3.2|these last few slides yeah so i think
3329.119|3.041|thinking that this is like an in context
3330.559|3.76|in your sneakers i think is a really
3332.16|4.32|useful way to think about this um other
3334.319|4.401|things could absolutely be contributing
3336.48|4.72|um this might explain why uh
3338.72|5.28|transformers do in-context learning uh
3341.2|5.04|over long contacts better than uh lstms
3344.0|3.52|and lstm can't do this because it's it's
3346.24|3.2|not linear in the amount of compute it
3347.52|3.2|needs it's like quadratic or n log n if
3349.44|3.44|it was really clever
3350.72|4.24|um so transformers are lstm is
3352.88|3.84|impossible to do this transformers um do
3354.96|4.639|do this and actually they diverge at the
3356.72|4.32|same point but if you if you look well
3359.599|3.681|i can go into this in more detail after
3361.04|3.68|if you want um
3363.28|3.279|there's a really nice paper by marcus
3364.72|3.28|hutter explaining trying to predict and
3366.559|2.641|explain why we observe scaling laws and
3368.0|3.119|models it's worth noting that the
3369.2|4.879|arguments in this paper go exactly
3371.119|5.2|through to uh this example this theory
3374.079|4.0|in fact they sort of work better for the
3376.319|3.601|the case of thinking about these this in
3378.079|3.681|context learning with with essentially a
3379.92|4.56|nearest neighbor's algorithm um than
3381.76|5.12|they do in in the regular case so
3384.48|4.48|um yeah uh i'm happy to answer questions
3386.88|4.32|i can go into as much detail as people
3388.96|3.44|want about any of this and i can also if
3391.2|3.52|you send me an email sending more
3392.4|4.399|information about all this um and
3394.72|4.0|uh yeah and you know again this this
3396.799|3.76|work is not yet published and you don't
3398.72|2.879|have to keep it secret but um you know
3400.559|2.8|just if you could be thoughtful about
3401.599|3.041|the fact that um it's unpublished work
3403.359|3.041|and probably a month or two away from
3404.64|4.479|coming out um i'd be really grateful for
3406.4|4.08|that uh thank you so much for your time
3409.119|3.601|yeah thanks a lot chris this was a great
3410.48|2.24|talk
3413.04|3.279|um so i'll just open up like some
3414.559|3.361|general questions and then we can do
3416.319|2.641|like a round of questions from the
3417.92|2.56|students
3418.96|2.48|so i was very excited to know like so
3420.48|2.079|what is the
3421.44|2.24|like the line of work that you're
3422.559|3.201|currently working on is it like
3423.68|4.32|extending this uh so what do you think
3425.76|3.52|is like the next things you try to do to
3428.0|2.48|make it more independable what are the
3429.28|3.36|next yeah
3430.48|3.599|i mean i want to just reverse engineer
3432.64|2.56|language models i want to figure out the
3434.079|2.321|entirety of what's going on in these
3435.2|2.24|language models
3436.4|3.679|um
3437.44|3.84|and uh
3440.079|2.401|you know like
3441.28|2.799|one thing that we totally don't
3442.48|5.04|understand is
3444.079|5.201|mlp layers um more we understand
3447.52|3.92|something about them um but we we don't
3449.28|3.68|really understand mlp layers very well
3451.44|3.44|uh there's a lot of stuff going on in
3452.96|3.92|large models that we don't understand i
3454.88|3.6|want to know how models do arithmetic um
3456.88|2.959|i want to know um another thing that i'm
3458.48|2.8|very interested in is what's going on
3459.839|3.121|when you have multiple speakers the
3461.28|3.279|model can clearly represent like it has
3462.96|2.96|it has like a basic theory of mind
3464.559|3.361|multiple speakers in a dialogue i
3465.92|3.28|understand what's going on with that um
3467.92|3.36|but honestly there's just so much we
3469.2|3.28|don't understand um it's really it's
3471.28|3.039|sort of hard to answer the question
3472.48|4.319|because there's just so much to to
3474.319|4.081|figure out um and we have a lot of
3476.799|4.161|different threads of research and doing
3478.4|4.32|this but um yeah and
3480.96|2.96|uh the interpreted team at anthropic is
3482.72|2.56|just sort of
3483.92|2.879|has a bunch of threads trying to go and
3485.28|3.519|figure out what's going on inside these
3486.799|3.841|models and sort of a similar flavor to
3488.799|3.121|this of just trying to figure out how do
3490.64|3.28|the parameters actually encode
3491.92|4.159|algorithms and can we reverse engineer
3493.92|4.56|those into into meaningful computer
3496.079|3.201|programs that we can we can understand
3498.48|2.319|well
3499.28|3.279|uh another question that is like so you
3500.799|2.961|were talking about like how
3502.559|3.76|like the transformers are trying to do
3503.76|3.76|metal learning inherently so it's like
3506.319|2.8|and you already spent a lot of time
3507.52|3.2|talking about like uh the induction hats
3509.119|3.601|and like that was like interesting but
3510.72|2.96|like can you formalize the sort of metal
3512.72|2.32|learning algorithm they might be
3513.68|4.0|learning is it like possible to say like
3515.04|3.84|oh maybe this is a sort of like uh like
3517.68|2.639|internal algorithm that's going that's
3518.88|2.56|making them like good metal learners or
3520.319|3.201|something like that
3521.44|2.96|i don't know i mean i think i think so i
3523.52|3.12|think that there's roughly two
3524.4|3.76|algorithms one is this algorithm we saw
3526.64|2.8|in the one layer model and we see it in
3528.16|3.52|other models too especially early on
3529.44|3.76|which is just you know try to copy you
3531.68|3.6|know you saw a word probably a similar
3533.2|3.919|word is going to happen uh later um look
3535.28|3.12|for places that it might fit in and
3537.119|2.96|increase the probability so that's
3538.4|4.399|that's one thing that we see and the
3540.079|4.321|other thing we see is uh induction heads
3542.799|4.081|which you can just summarize as as in
3544.4|4.399|context nearest neighbors basically um
3546.88|3.12|and it seems you know possibly there's
3548.799|3.841|other things but it seems like those two
3550.0|4.72|algorithms um and you know the specific
3552.64|3.439|instantiations that we are looking at uh
3554.72|3.76|seem to be what's driving in context
3556.079|4.321|learning that would be my present theory
3558.48|5.119|yeah sounds very interesting
3560.4|4.959|um yeah okay um so let's open like a
3563.599|3.281|round of first two questions so yeah
3565.359|4.921|feel free to go ahead
3566.88|3.4|for those questions
3573.359|2.081|you