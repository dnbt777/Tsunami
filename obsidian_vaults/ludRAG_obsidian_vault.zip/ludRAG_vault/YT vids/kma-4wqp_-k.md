start_time|end_time|text
1.2|3.2| Alright, finally, let's talk about how we can implement
4.6|5.62| dropout in practice. That is how we use dropout in pytorch. So
10.22|3.34| but before I can do that, I have to explain one more thing. It's
13.56|3.26| called inverted dropout. But don't worry, that's actually a
16.82|4.06| very simple concept. It is hopefully simple to explain to.
21.78|3.34| So and I wanted to explain that because in fact, nowadays, most
25.12|4.92| frameworks implement inverted dropout, including pytorch. So
30.2|3.2| what you are going to use in pytorch is called inverted
33.4|4.64| dropout. So what is inverted dropout? So if you recall, in an
38.04|3.54| earlier video, I mentioned that we are scaling the activations
41.58|3.74| during testing by a factor of one minus p, right? Because
45.36|9.48| during training, we, we drop nodes, right? And in testing,
54.84|9.08| this is an regular dropout, we scale activations by factor of
63.92|4.56| one minus p. And that is because during training, when we drop
68.48|5.48| the nodes, if you think of the net inputs, they will be smaller
74.0|2.8| than the net inputs during testing, assuming all the net
76.8|4.16| inputs are positive for simplicity. And so, because
80.96|4.4| other units in the network expect these activations on a
85.36|3.52| certain scale, the scale of the activations during testing would
88.88|3.0| be too large if we don't drop any nodes, right? Because during
91.88|2.6| testing, we don't drop any nodes. But then we have to
94.48|3.48| adjust the magnitude of these activations. So we're scaling by
97.96|11.56| one minus p, where p is the drop probability. Okay, so this is
109.52|4.68| what we do in regular dropout. Now, in inverted dropout, we
114.2|3.0| still drop notes during training. But we what we don't
117.2|3.3| do is we don't scale the activations during testing
120.5|6.7| anymore. So instead, so instead of doing this during testing,
127.2|5.68| the scaling, we do it already during training. So we do during
132.88|3.58| training, this scaling by a factor of one minus p, and then
136.46|3.94| we don't have to do anything during testing. Because then the
140.4|3.56| activations will be on the expected scale during testing
143.96|4.16| automatically if we already scale during training. So why
148.12|5.36| do we do that? Why do we do the inverted dropout? I'm not 100%
153.48|4.48| sure. But I believe this trend was started back then in 2015
157.96|2.88| in TensorFlow. That's was at least was the first time I've
160.84|3.32| seen it. So I've seen that in TensorFlow. And I think my
164.16|3.96| theory is that if you have a big company, let's say like Google,
169.52|2.6| you do a lot of predictions, right, you have millions or
172.12|3.64| billions of people using, let's say Google search. And if your
175.76|3.84| Google search engine relies on a neural network with dropout, it
179.6|5.8| would be very expensive to scale the predictions for each user.
185.64|2.68| I mean, the scaling is a simple operation. It's just one
188.32|2.56| multiplication, right. But if you have a billion search
190.88|3.72| queries, you have to think about having 1 billion additional
194.6|3.12| operations, right. So in that way, I think to save
197.96|3.8| computational resources during prediction time during
201.76|4.58| inference, people are scaled during training so that they
206.34|2.86| don't have to do anything during testing. That's at least my
209.2|4.36| theory. In any case, both dropout or inverted dropout
213.72|3.0| should give you exactly the same results. It's just a matter of
216.92|3.84| whether we perform the scaling during training or during
220.76|3.0| testing. And it happens that most frameworks nowadays,
223.8|4.84| including pytorch use actually inverted dropout. Yeah, and
228.64|3.04| here's a code snippet illustrating how we can use
231.84|4.28| dropout in pytorch in the sequential layer. I have the
236.12|3.18| full code example also in a Jupyter Notebook, if you are
239.3|2.86| interested to take a look at it. I have a link somewhere later
242.16|2.72| in my slides, but I also will post it again on canvas, like
244.88|4.92| always. So but yeah, here's the essential part for dropout. So
249.8|3.64| here, what I have is a multi layer perception with two hidden
253.44|5.44| layers. And this is the first layer, first hidden layer. And
258.88|4.08| this is the second hidden layer. And I'm just adding, you can see
262.96|5.92| I'm just adding dropout here, after the activations. So why
268.88|3.48| after the activations? Well, because we want to zero out the
272.36|2.8| activations, right. But in the case of relu, it doesn't really
275.16|3.86| matter whether we have it before or after relu, because if the
279.02|3.22| input to redo is zero, then the output of relu is also zero,
282.24|5.66| right? Because recall, how relu looks like it looks like this.
288.28|4.04| However, it would make a difference if we have, let's say
292.32|4.84| logistic sigmoid, because for the logistic sigmoid at zero, we
297.16|6.4| have this s shaped curve, right? So I'm not good at drawing this.
303.56|5.76| We have this s shaped curve for the logistic sigmoid. And if the
309.32|3.32| input is zero, then we will get actually a pretty large output
312.64|5.92| of point five. So usually, for relu, it doesn't matter whether
318.56|3.48| we have dropout before after, but for other activation
322.04|2.96| functions, it might matter. So it's always good to have dropout
325.04|3.84| after the activation just to be consistent. Any case, so yeah,
328.88|2.92| this is how we use a dropout. So the drop probability is just
331.8|3.92| some hyper parameter I also provided here as input. Yeah,
335.72|3.28| one more thing maybe to mention here is we don't use dropout for
339.0|3.88| the output layer. Why is that? Well, because it doesn't really
342.88|2.88| make sense, right? If we have, let's say 10 class labels, and I
345.76|3.02| drop three of the nodes corresponding to the class
348.78|2.38| labels, that would be a little bit awkward, right? So we don't
351.16|3.2| want to drop any class label predictions, we only want to
354.52|4.6| drop hidden activations. And this is essentially how you can
359.12|5.56| modify a neural network to use dropout. Alright, so also, maybe
365.08|2.08| minor thing to mention, you don't have to use the same
367.16|2.6| probability here and there, you can use different probabilities
369.76|4.8| also. Yeah, one more modification you have to make
374.56|2.84| in the code, though, is you have to make pay attention that you
377.4|4.88| use model train and model eval, when you do the model training
382.28|2.92| and the testing. So I mentioned this earlier, when we talked
385.2|3.24| about pytorch, that this is important. I always do that no
388.44|2.68| matter whether I have dropped out or not, just to make sure
391.48|3.68| that there's no unwanted side effect or no unwanted behavior.
396.0|4.92| So why is that required? So this will essentially set the model
400.92|3.52| or tell the model that it's currently in training mode. So
404.44|3.72| it will automatically use dropout. So during training
408.16|4.92| mode, it will actually use these dropout things. However, during
413.08|5.76| model evaluation, during testing here, it will essentially skip
418.84|3.2| dropout, right, because we don't want to use dropout during
422.04|4.16| testing or prediction. So when we set our model to eval mode,
426.2|4.24| eval stands for evaluation, then it will not use dropout. So it
430.44|2.92| can essentially just skip dropout, or you can also think
433.36|3.04| of just setting the drop probability to 0.0. So it won't
437.04|3.08| drop anything. So this is important. So you have to really
440.12|4.44| make sure you use train and evil. And not only if you use
444.56|2.8| dropout, I would always recommend doing that because it
447.36|3.56| doesn't hurt, right. So it's always a good practice to using
450.92|5.6| those. You have the full code example for that here on GitHub,
456.96|3.52| if you want to check it out. So here, I trained this multi layer
460.48|5.28| perceptron on MNIST. So at the top, I have no dropout. So you
465.76|2.96| can see the training loss on the left hand is the training loss
468.72|4.64| for 50 epochs, it goes down. And here on the right hand side,
473.48|3.0| this is the accuracy on the training and validation set. And
476.48|4.88| you can see the training set accuracy goes up like expected
481.36|3.08| during training. And the validation accuracy also goes
484.44|3.28| up. But what you can see here is that at some point, you will
487.72|4.48| have an overfitting gap here. So the model without dropout starts
492.2|3.96| to overfit at some point, here at the bottom, I added 50%
496.16|3.2| dropout. So this is exactly the model I was showing you here
499.36|4.84| with 50% dropout now. So you can see the accuracy improves. But
504.48|3.24| here, we don't have any overfitting anymore. So we are
507.72|2.84| reducing the overfitting, I should say there is one little
510.56|4.72| caveat, though, if I computed the test set accuracy, this was
515.28|6.68| like 97.5% approximately, and this was only 96.5%. So maybe I
521.96|3.84| was doing too much dropout here at the bottom, because I reduced
525.8|4.16| overfitting, but at the same time, I also maybe added too
529.96|3.96| much of a regularization penalty here using dropout. So that also
533.92|3.36| that, yeah, the performance overall is a little bit lower.
537.7|2.78| But yeah, essentially, this is how dropout works, you can play
540.48|5.28| around with that. And yeah, with that, maybe some more practical
545.76|4.12| tips. So I recommend not using dropout if your model does not
549.88|3.36| overfit. So I would maybe just train the model and see how it
553.24|3.08| behaves. If it doesn't overfit, then there's no need to use
556.32|3.68| dropout. But if you see that there's overfitting, like you
560.0|2.2| can see here, then it's worthwhile actually adding
562.2|4.2| dropout. In practice, also, the creators of dropout recommend,
566.68|4.24| essentially, if you observe that your model does not overfit, you
570.92|3.32| should increase the capacity of your model, adding more
574.24|4.0| parameters until it overfits, and then adding dropout to it.
578.28|4.68| So essentially, they are arguing that it's better to design a
582.96|4.72| model that overfits and then add dropout compared to designing a
587.68|3.84| model that does not overfit. So overall, they expect to see that
592.24|3.16| you will get a better performance if you make a model
595.4|3.72| larger, such as it overfits and then use dropout to reduce the
599.2|5.72| overfitting. Yeah, there's also, you may have already had this
604.92|3.0| idea while listening to this lecture, there's also a related
607.92|3.72| idea, randomly dropping weights. So instead of dropping the
611.64|3.24| activations in dropout, we can also actually randomly drop
614.92|3.28| dropping weights. So if you had this idea is a potential research
618.52|3.2| idea, I have to unfortunately disappoint you, someone has
621.72|3.8| already worked on this, it's called drop connect. So there's a
625.56|3.72| it's more like a general generalization of dropout,
629.28|4.08| because yeah, you can think of it, it can, if you let's say, if
633.36|4.6| you consider, let's say this node here, if you drop this weight
637.96|3.04| and this weight, both weights, if you drop both, then it's
641.0|2.32| essentially the same as dropping this activation. So in that way,
643.32|3.0| you can think of drop connect as a generalization of dropout. But
646.32|3.48| yeah, in a more general sense, it's just dropping weights
649.84|6.04| randomly. So the paper for that is can be found here.
656.8|2.2| Unfortunately, or I'm not sure if it's unfortunate or
659.0|2.68| fortunate, it doesn't really matter. But it happens that this
661.68|3.6| is something I find that works not so well. In practice, I long
665.28|2.84| time ago, I tried it once I found that dropout works better.
668.12|5.92| And also, I really don't see it often being used in practice. So
674.04|3.2| I think it's just less popular than dropout, maybe because it
677.24|5.28| doesn't perform so well as dropout. Yeah, to close this
682.52|3.4| lecture, I have a reading recommendation for you. The
685.92|3.6| original dropout paper, it's actually a really nice paper,
689.52|3.24| very, I would say intuitive, nicely written, and very
692.76|3.6| accessible. It doesn't have any or not much mathematical jargon,
696.36|3.56| which is nice. So if you want to practice reading research
699.92|3.24| papers, that's actually a good one to start with. And yeah,
703.16|2.92| also, happy Women's Day, if you're watching this today. So
706.08|2.88| today is the International Women's Day. And with that, let
708.96|4.12| me close this lecture. And next time, we will talk about some
713.2|2.72| weight initialization techniques. And also, then we
715.92|3.2| will talk about learning rates later and different optimizers.
719.24|3.64| So essentially, other techniques for improving neural network
722.88|7.0| training.