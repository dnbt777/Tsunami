start_time|end_time|text
1.44|4.68| Yeah, let's now discuss how back propagation works for CNNs. And
6.12|2.4| I recommend you Yeah, maybe to make a tea get really
8.52|3.42| comfortable, because that might take a couple of hours. Of
11.94|2.78| course, I was just kidding. I just want to give you the big
14.72|3.1| picture overview here, because I feel like I already tortured
17.82|3.48| you enough with computing the gradient of the loss function
21.3|2.64| with respect to the weights and so forth, when we talked about
24.22|4.08| single layer neural networks and multi layer perceptrons. So here,
28.3|3.14| I just want to give you the big picture overview, because yeah,
31.44|4.18| no one really likes to do these, derive these things by hand. And
35.62|4.02| in practice, many people or most people use auto grad anyways,
39.68|3.24| but I think it's still useful to kind of understand what's going
42.92|5.0| on, let's say, in the big picture scale. So how does back
47.92|4.52| propagation work in CNNs? So that's essentially the same
52.48|3.0| concept that we used before in the context of multi layer
55.48|3.36| perceptrons. But here we are applying the multi variable
58.84|3.04| chain rule because we have now these weight sharing constraints
61.88|4.4| where we apply the weight of the same weight to different regions
67.0|4.32| on in the image. So I try to simplify this like with a very
71.34|5.26| simple sketch here. So for instance, imagine you have two
76.6|3.44| different types of inputs. And then you compute these
80.04|4.08| activations by using a weight. But here you are using the same
84.12|5.52| weight, let's say that's the same w i here. And then from
89.64|2.64| these activations, you compute some output and then you compute
92.28|3.0| the loss. So essentially, by the way, I copied most of the
95.28|4.44| notation from an earlier slide, just modified, it is slightly,
99.86|3.22| but most of it should be familiar to you. So now when we
103.08|2.88| are computing, what we're interested in when we are
105.96|3.24| computing the partial derivative of the loss with respect to the
109.2|4.48| weights, or the one weight here, for gradient descent, what we
113.68|4.68| do is, like always, we backtrack. So we start here, the
118.36|3.46| partial derivative of the loss with respect to the output, then
121.84|4.76| we go here, or let me use a different color here, we go from
127.84|3.2| from here to here, we compute the partial derivative of the
131.04|4.28| output with respect to the activation. And then we compute
135.32|2.96| the partial derivative of that activation with respect to the
138.28|5.68| weight. So that is one path here. So this is essentially
143.96|3.2| here, the upper path, and then we can do the same thing for the
147.16|5.2| lower path. So here, we compute also the same partial
152.36|3.24| derivative of the loss with respect to the output, then we
155.62|4.82| compute the partial derivative of the output with respect to a
160.44|5.16| two, and then the partial derivative of a two with respect
165.6|4.12| to w one, this is the lower path. And then here, we just add
169.72|3.92| them together, because that's the multi variable chain rule.
173.68|2.64| And that is essentially, yeah, what's happening in the
176.32|2.92| convolutional network. Of course, you have many layers.
179.52|2.88| And that would be a little bit complicated to draw. But it's
182.4|4.6| just a simple purposes. What's essentially happening is that we
187.0|7.04| are sliding our filter kernel over the image. So here, this
194.04|3.92| the common convolution when we are sliding it over the image.
198.68|4.84| And like I said before, the kernel, this is like a let's
203.52|4.92| call this a W, it's a matrix, in this case, it's a three by three
208.44|3.36| matrix, and we are using the same weights. So here, we have
211.8|4.44| nine weights that we are reusing. So the red line here,
216.64|3.12| this this weight here, for instance, let's call that w one,
219.76|5.52| this computes this one part of this first value here. So when
225.28|5.08| we compute this, it's essentially the sum of the
230.36|7.48| weighted inputs. So w one times x one plus w two times x two, and
237.84|5.4| so forth. And we do the same thing here at the bottom. For
243.24|3.76| this one, for instance, is let's call it w two. But in this case,
247.0|3.88| the w two is the same as w one. So they are both really the same
250.88|3.08| because we are using the same filter that we are just sliding
253.96|7.28| here over over the image. And in that way, it's essentially then
261.24|3.64| also the multivariable chain rule. So when we compute the
264.88|5.68| partial derivative of the loss with respect to this w one, we
270.56|6.2| we compute that in two parts, we computed once for for the upper
276.76|5.16| path here, the ones for the lower path. And there might be
281.92|4.04| differences, of course, because usually we have many layers in
285.96|3.68| between. So there might be differences, how these partial
289.64|3.56| derivative looks like look like for this one, let's call the
293.2|4.12| other one w two at the bottom here, while w one and w two are
297.32|3.48| the same. In between things might look a little bit
300.8|2.68| different because we have many layers in between. And then in
303.48|4.32| practice, usually, when we compute the weight update for
307.8|4.2| those two weights, what we usually do is we average over
312.0|2.64| them. So you don't have to average this is like optional,
314.64|3.36| you can actually skip that. But you like using the multivariable
318.0|2.96| chain rule, you would combine these two partial derivatives
320.96|2.96| for both regions. But yeah, this is all I wanted to really say
323.92|3.12| about backpropagation in CNNs. It's essentially the
327.04|4.32| multivariable chain rule. And yeah, we have this weight
331.36|5.24| sharing constraint. In practice, I will not ask you to implement
336.6|3.8| that or anything like that. Because in practice, we are from
340.4|3.56| here on just using pytorch for that. And pytorch will handle
343.96|3.64| this automatically for us. And I will at the end of this lecture
347.6|2.8| show you how we train convolution networks in pytorch.
350.4|7.0| It's actually simpler than you might think.