start_time|end_time|text
0.36|2.96| Yeah, no, we are finally getting to the more interesting part of
3.32|3.16| this lecture talking about dropout. Or at least that's what
6.48|2.46| I find a little bit more interesting, because it's a
8.96|3.16| method specifically developed for neural networks, and not
12.12|4.96| just an extension of generalized linear models. So to keep things
17.08|4.64| a little bit organized, I split this topic into four sub topics.
22.08|3.36| However, don't worry, these will be probably very short videos.
25.44|2.88| So there are not many slides per topic. But I thought it's just
28.32|3.24| simpler to organize it this way. So in this first video, I want to
31.56|3.08| just give you the brief, big picture overview, the main
34.64|3.88| concept behind dropout. And then we will talk about the co adapt
38.64|3.64| adaptation technique, not a technique interpretation of
42.28|3.0| dropout. And then we will talk about the ensemble method
45.28|3.08| interpretation. And then we will see how we can do that in
48.4|4.84| pytorch. So for reference, if you're interested, you can later
53.24|3.16| also check out these papers. They are pretty nicely written
56.4|5.4| and not too complicated. So these two papers, as far as I
61.8|3.52| know, are the original papers proposing dropout. So one goes
65.32|4.2| back to 2012. It's entitled improving neural networks by
69.52|3.04| preventing co adaptation of feature detectors. So like I
72.56|3.64| mentioned, we will see what this co adaptation interpretation
76.2|4.56| means later. And there's also another interpretation that goes
80.76|2.64| back to this second paper dropout, a simple way to prevent
83.4|3.2| neural networks from overfitting. This is like the more
86.6|3.76| like the ensemble interpretation. But yeah, we will
90.36|2.4| talk about this in more detail. I just wanted to give you these
92.76|2.72| references for these methods. So if you want to check out more
95.48|3.92| details, you can find them here. So what is the main concept
99.4|3.64| behind dropout? So in a nutshell, it's about dropping
103.04|4.04| nodes. So suppose you have a multi layer perceptron here,
107.08|4.6| that's a very small one. Essentially, it's doing training
111.68|3.84| randomly dropping nodes. So for example, here as shown, you
115.52|3.76| would randomly drop this node with a certain probability. So
119.96|4.64| if you say the dropout probability is point five, like
124.6|4.72| 50%, then during training for each node, you would say with 50%
129.32|5.44| probability, I will just delete it during the forward pass. And
134.96|4.56| in each training, forward pass, it will be different nodes that
139.52|4.24| will be deleted, because it's a probability. So you randomly
143.76|6.56| create different models. So one forward pass might delete this
150.32|4.64| one, another forward pass would have these two deleted, another
154.96|6.52| forward pass may have this one deleted, and so forth. So why
161.48|3.16| that is useful, there are a couple of theories. And we will
164.64|2.92| talk about this here is just like the big picture overview,
167.56|3.8| how it works. I mean, like what the main what's happening
171.36|3.52| basically, and then why that helps that is a topic for the
174.88|3.52| next video. Yeah, now the question is, how can we
178.4|4.6| implement that efficiently? So how can we implement a dropout
183.0|4.28| without having to make any major modifications to our neural
187.28|2.64| network architecture, like deleting nodes or something like
189.92|3.76| that? So how can we just do it conveniently? So one way would
193.68|5.2| be by implementing a Bernoulli sampling procedure. So for that,
199.12|5.48| we can define a drop probability P. So for example, this could be
204.8|7.0| 50%. Or let's say, point five, that's our drop probability. So
211.8|4.24| with that probability, for each given node, it's the probability
216.04|6.36| that we drop that node. Now, we create a vector here. So it's
222.4|3.6| so it's like a random vector, a random sample from a uniform
226.0|4.48| distribution in the range zero and one. So this vector will
230.48|6.16| have the same number of elements as the size of the hidden layer
236.64|4.92| that we want to apply dropout to. So dropout is only applied to
241.56|5.44| hidden layers, it's not applied to the output layer. So now
247.0|3.92| let's say we have done that we have, let's say, five units in
250.92|4.6| our hidden layer. So we have five numbers between zero and
255.52|5.92| one. I'm just writing down some arbitrary numbers here. Oops,
264.4|7.12| like this. And now that is when we apply basically a Bernoulli
271.52|3.44| sampling where we say for each value in that vector for each
274.96|5.92| value, vi, we set this value to zero. If this value is smaller
280.88|4.04| than a drop probability, otherwise, we set it to one. So
285.24|3.56| we are modifying this now that it is a binary vector. So this
288.8|5.36| one is smaller than point five. So we set it to one, this one,
294.2|5.0| oh, sorry, should be zero, this one is greater. So we set it to
299.2|3.56| one, this one is smaller. So we set it to zero, this one, it's
302.76|3.5| on the border, we have defined smaller, so let's set it to one.
306.26|4.96| And then this one would be also zero. So we have now this binary
311.22|5.28| vector. And then we can simply model or multiply this binary
316.54|3.76| vector with our activations a. So these are the activations in
320.3|4.2| our hidden layer. And then now we have effectively canceled
325.06|4.04| activations. And yeah, that's it. That's how we can apply
329.34|5.24| dropout during training. Okay, so but there's one little thing
334.58|4.68| thing we have to adjust if we want to use our model for
339.26|2.76| inference, like making predictions on new data, or
342.02|4.48| even computing the test set accuracy. So yeah, the reason
346.5|3.2| is, we don't want to have any randomness when we make real
349.7|2.84| world predictions, right. So it would be a little bit awkward
352.54|3.96| if, let's say we predict some, let's say credit scores, but
356.5|3.4| sometimes random nodes get dropped. So the customer would,
360.14|3.08| on different days, get different credit scores, although nothing
363.22|3.3| else has changed. So in that way, we don't want to have any
366.54|3.96| randomness during testing. So the dropout is only applied
370.72|4.62| during training. So what effectively what it means, we
375.34|4.2| don't do any removal of the nodes during testing. However,
379.82|4.36| there's one additional thing we have to do when we want to
384.18|3.86| remove the dropping of the nodes. And that has to do with
388.04|4.58| the scale of the activations. So assume I have a multi layer
392.62|3.84| perceptron, with multiple hidden layers, let's call that hidden
396.46|3.24| layer h one and this hidden layer h two, and they are fully
399.7|7.16| connected to each other, like always. So now, if I drop one of
406.86|3.28| the nodes, though, in h one, when I drop out, let's say I do
410.14|5.32| it like this, or let's say, um, let's say it like this, each
415.46|3.92| value here is the same, the weights are all one and the
419.38|5.6| activations are all one just to keep things simple. So this is
424.98|6.48| the case, the activation at that given node here is one times one
431.46|5.24| plus one times one plus one times one, it's three, right. So
436.7|9.4| if I have some over the weights, and activations from the
446.1|3.72| previous layer, for some that up the net input, let's say the net
449.82|3.04| input is three, because all the weights and all the activations
452.86|5.0| are one just for simplicity. Now, if I drop one of these nodes
457.86|5.36| during using dropout, then now I only have two inputs. So the
463.22|4.92| value now is only two instead of three, because I only have two
468.14|5.72| incoming activations when computing the net input. Okay,
473.86|4.28| so that means, um, I mean, this doesn't have any is not a
478.14|2.2| problem during training, of course, I mean, this is just
480.34|3.48| like some arbitrary numbers I'm showing you here. But now, if
483.82|5.16| you don't do any dropout during testing, all the activations
488.98|2.68| will be larger, right. So during testing, we don't have any
491.66|4.82| dropout. So the values are actually larger than during
496.48|3.26| training during training, we had a value of let's say, two, and
499.74|4.2| during testing, we will have a value of three. However,
503.94|3.96| everything in the network is kind of has learned to work with
507.9|3.64| these smaller values. So the threshold, let's say in the last
511.54|5.88| layer for the prediction would not really work for for these
517.46|3.76| larger values now, because we have all now throughout the
521.22|2.96| whole network, larger values, because we don't drop any nodes.
524.56|4.94| And that could be awkward. So what we do is we just scale these
529.5|2.96| activations. That's like a very simple trick to deal with this
532.46|4.68| problem. So let's say we have a drop probability of point five,
537.14|5.08| and we have an activation of three, one, let's say, we have
542.26|6.08| two during training. Because this one node got randomly
548.34|3.5| dropped, I mean, this is just a simplification. And then doing
551.84|3.26| testing, the value here that comes in here is three, because
555.1|3.24| there is no dropping of any node. So we have now this
558.34|2.92| problem is this too large. So how can we do it, get it
561.26|4.56| smaller, and we can just scale it by one minus the drop
565.82|2.6| probability. So in this case, okay, this doesn't make quite
568.42|4.84| sense, because this is not an even number. Let's let's do it
573.26|4.96| properly properly here. Okay, sorry. So let's do a network
578.22|6.0| where we have 1234. And 123 nodes here. Same thing applies
584.22|5.76| during training, we drop 50%. So we drop two nodes randomly. So
589.98|4.96| the value during training we get is two. But during testing, we
594.94|5.16| don't drop anything. So the value we may get at this node
600.1|5.36| here is no four. So how do we scale it, we can scale it by one
605.46|3.32| minus the drop probability probability, for example, can
608.78|6.28| have then four times one minus point five, which is four times
615.06|2.72| point five, which is essentially two. So in this way, we scale
617.86|3.96| all the predictions during training testing, sorry. So
622.1|4.44| that's like a simple trick to deal with these activations that
626.54|3.44| might be too large during testing. And yeah, this is
629.98|5.48| essentially how dropout works. So in the next video, I want to
635.46|4.48| talk about the co adaptation interpretation. So one way to
639.94|3.28| interpret dropout, why it might work in practice. And there's an
643.22|4.08| alternative interpretation from looking at dropout as an
647.3|4.44| ensemble method. And then I will show you how we can do dropout
651.74|2.56| and pytorch. And there's also a concept for that called
654.3|3.56| inverted dropout, which will be interesting. It's a slight
657.86|2.6| modification of what I just talked about. It's called
660.46|4.0| inverted dropout. I will call talk about that when we talk
664.46|1.12| about the implementation.