start_time|end_time|text
5.64|4.08|yeah so making you all see the speaker
7.319|6.841|notes was not part of the plan
9.72|5.3|um but uh I'm glad to be here and uh my
14.16|3.959|name is
15.02|4.48|and I am a reset scientist in the health
18.119|3.901|aide team at Google
19.5|4.98|uh a little bit more about me uh growing
22.02|4.74|up in India my parents always wanted me
24.48|5.219|to be a doctor to be precise a medical
26.76|4.38|doctor but unfortunately I was probably
29.699|4.141|not good enough to memorize all the
31.14|4.2|biology textbooks uh that you had to do
33.84|3.48|in case you wanted to crack the medical
35.34|3.18|insurance examinations
37.32|3.079|um so I ended up becoming a computer
38.52|5.76|scientist instead
40.399|5.861|uh but as a great man once said uh you
44.28|4.56|can't connect the dots looking forward
46.26|4.619|you only join them looking backwards so
48.84|3.899|through other long-winded path
50.879|4.141|not too dissimilar from how we actually
52.739|3.601|train our neural networks
55.02|3.719|um I've ended up working in medicine
56.34|5.82|again uh this time armed with this
58.739|5.521|magical new tool of AI and I can tell
62.16|5.779|you that my parents are far more happy
64.26|3.679|with my life choices right now
71.9|6.28|aside uh my goal for this talk is to
76.08|4.02|peel back the curtains and give you a
78.18|3.42|flavor of all the Innovation that is
80.1|3.48|happening at the intersection of AI and
81.6|4.92|biomedicine and how that is being
83.58|5.399|catalyzed by Transformers and large
86.52|4.5|language models in particular
88.979|3.601|um so we will spend the first few
91.02|3.599|minutes trying to work up from first
92.58|4.679|principles why Transformers and large
94.619|6.421|language models are a particularly good
97.259|6.9|fit for biomedical data and then we will
101.04|4.32|Deep dive into a few papers covering a
104.159|3.121|bunch of different biomedical
105.36|4.799|application settings
107.28|4.979|and finally I'll present my views on how
110.159|3.6|this field is likely going to evolve in
112.259|4.021|the next few years
113.759|4.981|and even though my voice or tone may not
116.28|5.1|exactly sound that way I am incredibly
118.74|5.159|excited by the possibilities of AI and
121.38|4.26|biomedicine and I think we have an
123.899|3.421|incredible opportunity in front of us to
125.64|4.02|advance human health and human potential
127.32|4.2|and my hope at the end of this talk is
129.66|5.18|you all will feel the same way as I do
131.52|3.32|today and perhaps join me
135.12|5.28|so yeah let's jump straight in why
137.879|4.261|Transformers in biomedicine and sorry
140.4|3.6|I'm going to pick people who are in
142.14|4.459|person to answer so maybe if one of you
144.0|2.599|could volunteer
147.78|2.539|foreign
176.84|3.42|application setting
182.64|5.64|yeah a great one so I think all of you
185.76|4.38|were on the right track and so
188.28|4.98|maybe if you just look at different
190.14|5.04|kinds of uh you know biomedical data for
193.26|4.74|example what are clinical nodes I think
195.18|5.699|it's sequence of Dr gibberish okay I did
198.0|5.7|not say that but uh let's just call it
200.879|5.161|sequence of doctor speak or doctor notes
203.7|3.84|uh similarly if you were to look at
206.04|3.479|electronic medical records what are they
207.54|3.54|they're essentially sequence of like a
209.519|3.601|person's encounters with the medical
211.08|3.12|system
213.12|3.24|um
214.2|4.259|what about proteins uh going deeper into
216.36|3.78|the biological stack uh they are nothing
218.459|3.78|but a sequence of amino acids linked
220.14|6.56|together by peptide bonds
222.239|4.461|and uh does anybody know what this is
228.239|4.501|I'll go for it I think that's how we
230.34|3.66|store medical records
232.74|4.999|[Music]
234.0|7.28|sorry again well that's like
237.739|3.541|you're getting close
241.62|2.66|anyone else
245.28|3.78|um so this is uh in the welcome
246.959|4.081|collection in London and this is
249.06|3.78|actually a printout of the full human
251.04|3.779|genome
252.84|4.2|um and uh
254.819|4.2|no they did not cheat over here the font
257.04|4.08|is super small and as you can see
259.019|4.62|there's a bunch of atgcs
261.12|5.0|um the the entire printout contains I
263.639|5.161|think uh over 130 volumes in that shelf
266.12|5.68|uh and each page is printed on both
268.8|5.64|sides and it's a four point uh font uh
271.8|4.32|with precisely 43 000 characters uh per
274.44|3.96|page so that is how big the human
276.12|5.579|reference genome is more than billions
278.4|6.66|of base pairs
281.699|5.821|and so again the genome is nothing but a
285.06|4.26|sequence of nucleotide base pairs um so
287.52|4.08|what we are essentially seeing over here
289.32|4.439|is sequences are everywhere in
291.6|3.9|biomedical data and what is the best
293.759|3.921|neural network architecture for modeling
295.5|2.18|them
298.139|3.181|um
299.1|3.84|and I guess since you are all in this
301.32|5.34|course I don't have to convince you that
302.94|5.759|the answer is Transformers right
306.66|4.319|okay that's good
308.699|4.621|um but maybe I'll just offer a few uh
310.979|4.921|reasons over here firstly as you can see
313.32|4.02|uh the data itself is multimodal in
315.9|4.799|nature
317.34|4.98|um and we just saw a few examples and as
320.699|3.601|someone pointed out Transformers have
322.32|4.68|proven remarkable at you know guzzing up
324.3|4.02|pretty much any kind of data uh and we
327.0|3.539|are really seeing this remarkable
328.32|4.86|convergence across Fields whether that's
330.539|4.261|speech or enthalpy or Vision or robotics
333.18|2.7|I mean pretty much everywhere we are
334.8|3.06|using Transformers and I think
335.88|4.68|biomedicine is no different
337.86|4.98|uh I think secondly Transformers are far
340.56|4.46|more effective at modeling uh complex
342.84|4.74|long-range interactions over sequences
345.02|4.3|and this property is particularly
347.58|4.26|important in the biomedical domain and
349.32|3.78|we will cover this in more detail later
351.84|3.419|in the talk
353.1|5.28|and finally as again someone pointed out
355.259|4.561|these data sets can be quite big and you
358.38|3.36|can easily get into the billions of
359.82|3.96|token strategy and this is where
361.74|3.72|Transformers with all the parallelizable
363.78|3.72|operations and the relative ease of
365.46|3.78|training and maybe someone should try
367.5|4.259|training an lstm and an RN on these kind
369.24|3.899|of data sets uh we'll realize that these
371.759|3.241|are much better suited for the kind of
373.139|3.421|data sets that we have in this domain
375.0|3.66|over here
376.56|3.18|so yeah I think there are a few more
378.66|3.24|reasons as well but I think these are
379.74|3.959|the key uh ones as to why Transformers
381.9|5.06|are particularly uh well suited for
383.699|3.261|biomedical data sets and tasks
387.36|2.959|um any questions so far
390.36|3.42|okay great
391.56|4.44|um so now in the next part of this talk
393.78|4.38|uh we will dive deep into a few papers
396.0|3.72|applying Transformers to uh biomedical
398.16|3.06|data
399.72|3.599|um we'll start with clinical
401.22|4.319|applications first and then go gradually
403.319|4.741|deeper into the biology stack looking at
405.539|5.341|proteins and genomic applications as
408.06|4.62|well and what you'll observe is that
410.88|4.92|while Transformers and large language
412.68|6.06|models by extension are a great fit uh
415.8|4.92|often you have to innovate not just on
418.74|3.959|the modeling side but also on the data
420.72|5.599|and evaluation side to you know make
422.699|3.62|these applicant scenarios really work
427.38|3.42|um and so the first paper I want to talk
429.18|3.6|about over here is this recent work from
430.8|5.22|our team called large language models in
432.78|4.56|code clinical knowledge uh the
436.02|3.239|motivation for this work is actually
437.34|4.56|quite straightforward so if you look at
439.259|4.081|medicine it is a Humane Endeavor and
441.9|3.359|languages at the heart of it
443.34|4.259|facilitating interactions between people
445.259|3.901|and those who provide care for them
447.599|3.261|unfortunately if you look at a lot of
449.16|4.379|medical AI systems developed till date
450.86|4.959|these are all narrow single task single
453.539|4.321|domain models lacking interactive and
455.819|4.081|expressibility capabilities
457.86|4.02|and as a result what has happened is
459.9|4.56|there is this discordance between what
461.88|6.12|these models can do and what is expected
464.46|6.0|of them by patients and you know care
468.0|4.139|providers and others and this in turn
470.46|3.72|has I think prevented broad uptake of
472.139|2.761|medical AI
474.18|2.28|um
474.9|3.06|and you can see that for example we
476.46|2.82|don't really have ai in many clinics out
477.96|3.019|there like helping us with diagnosis and
479.28|4.139|so on and so forth
480.979|3.881|but the recent progress with you know
483.419|3.72|Transformer based large language models
484.86|5.22|it offers us an opportunity to change
487.139|4.801|all of this and redesign and rethink
490.08|3.959|medical AI systems with language at the
491.94|4.8|heart of it uh mediating human AI
494.039|5.421|interactions between doctors researchers
496.74|2.72|and patients
499.56|3.12|and I will be honest if I don't point
501.479|2.94|out that there has been a large volume
502.68|3.9|of work in this space particularly in
504.419|4.021|the last few years there have been
506.58|3.92|various attempts to train language
508.44|4.26|models in the biomedical domain
510.5|5.88|with models of various different sizes
512.7|3.68|on different corpuses of biomedical data
516.599|4.38|uh and while this is exciting uh the
519.24|3.719|quality bar for applications in the
520.979|4.441|medical domain is actually quite High
522.959|4.741|uh and so what is missing is actually is
525.42|4.14|that there is actually not many good
527.7|3.96|evaluation benchmarks and evaluation
529.56|3.66|protocols and Frameworks so we don't
531.66|2.4|have the equivalent of a big bench in
533.22|2.22|medicine
534.06|3.12|um and hopefully you guys have covered
535.44|4.019|big bench before
537.18|3.96|um and so big benches is Benchmark where
539.459|3.181|uh you can access large language models
541.14|2.94|across a variety of task domains and
542.64|4.74|settings and but we don't have an
544.08|5.16|equivalent of that in the medical domain
547.38|3.66|um and further if you look at the
549.24|4.86|evaluations that are typically used in
551.04|5.88|these previous studies uh they only look
554.1|3.9|at objective metrics like accuracy or
556.92|3.24|you know natural language generation
558.0|4.08|metrics like blue or cider but these
560.16|4.38|fail to capture the nuances of real
562.08|5.4|world use cases in clinical settings
564.54|5.22|so what we essentially need was uh you
567.48|3.78|know a good Benchmark uh and a task and
569.76|3.66|also a good evaluation framework for
571.26|4.92|evaluating these models
573.42|4.5|and so to address this unmet need and
576.18|4.2|assess the potential of llms in medicine
577.92|4.74|uh in our team we decided to focus on
580.38|4.8|the medical question answering task uh
582.66|3.96|why uh because answering medical
585.18|4.02|questions is actually quite challenging
586.62|5.52|it requires reading comprehension skills
589.2|4.98|uh ability to accurately recall medical
592.14|3.36|knowledge and also manipulate and reason
594.18|3.42|about it
595.5|4.14|and furthermore the Q a task is
597.6|3.359|generally enough and can subsume a bunch
599.64|3.42|of different application settings such
600.959|3.961|as summarization of clinical notes uh
603.06|3.899|clinical decision decision support and
604.92|5.12|also uh like Primary Care triaging
606.959|3.081|operation concerns and so on
610.38|3.959|um so we've identified the task uh the
612.36|3.06|next question is what data said and so
614.339|2.701|when we looked at the literature over
615.42|2.64|here what we saw is that there were
617.04|3.6|several data sets floating around
618.06|3.839|assessing model capabilities in a bunch
620.64|2.94|of different settings
621.899|3.541|um so what we decided was we should
623.58|3.6|probably just unify all of them and put
625.44|3.78|together in one Benchmark and so we did
627.18|3.42|that and we called it multimet QA and so
629.22|3.78|if you look at it this Benchmark now
630.6|3.419|covers medical question answering data
633.0|2.7|sets from a bunch of different settings
634.019|4.081|such as you know professional medical
635.7|5.22|questions uh like the US medical license
638.1|4.32|exam style questions uh it also includes
640.92|3.659|medical research questions those based
642.42|3.84|on PubMed abstracts and so on and also
644.579|3.721|questions from live live users and
646.26|3.48|consumers uh asking about medical
648.3|3.36|information
649.74|3.3|and also the setting changes it could be
651.66|3.119|closed domain or open domain and the
653.04|3.12|model may be expected to produce long
654.779|3.481|form answer in one setting and maybe a
656.16|5.04|short form answer in another setting
658.26|4.86|um and finally we saw that uh while the
661.2|4.02|the
663.12|4.459|q a data sets which covered consumer
665.22|2.359|yeah
669.12|5.1|uh I'll come back to this okay
672.24|3.9|um so yeah very quickly uh finally when
674.22|3.92|we looked
676.14|2.0|um
679.279|3.881|okay cool
681.54|4.32|um so the question was how do we
683.16|4.679|evaluate long-form answers and uh I'll
685.86|4.02|come back to this a bit later
687.839|4.861|um and so very quickly uh when we looked
689.88|4.86|at the data sets that uh actually uh
692.7|3.6|provided consumer medical questions we
694.74|3.48|found them to be quite small in size so
696.3|3.539|we decided to augment them and so we
698.22|3.179|went out to Google and looked at like
699.839|3.24|the most frequently Asked consumer
701.399|3.241|medical questions and so we curated a
703.079|3.121|data set and we added that to The
704.64|3.42|Benchmark and we call that a health
706.2|5.36|search query over here
708.06|5.06|and so yeah again uh how big is the
711.56|5.14|composite
713.12|5.8|uh I'll come back later I'm sure
716.7|3.18|um so here are a few examples uh so if
718.92|3.479|you look at the consumer medical
719.88|4.98|questions they are quite short in nature
722.399|3.721|um while and so they come from the
724.86|2.7|health search queue and the live QA data
726.12|3.06|sets whereas I think if you look at the
727.56|3.6|USMLE style questions these are like
729.18|3.18|long Vineyards and so doctors have to
731.16|2.52|like really really carefully read
732.36|2.64|through them and come up with the right
733.68|3.54|answer which often involves the process
735.0|4.019|of elimination so again very very
737.22|4.44|different application settings and uh so
739.019|4.081|the model has to really like um really
741.66|4.58|adapt and understand it has to do well
743.1|3.14|in all these settings across the board
746.82|4.56|um and live QA is interesting because
749.279|3.721|the answers the reference answers over
751.38|2.94|here were actually provided by
753.0|3.839|Librarians so that's another good
754.32|5.4|comparison point for us going ahead
756.839|5.401|and so in terms of statistics we had a
759.72|4.32|total of seven uh data sets in this
762.24|3.779|Benchmark uh as I said we cover
764.04|3.96|professional medicine medical research
766.019|4.921|and consumer medical questions uh
768.0|5.339|they're again of various different sizes
770.94|4.38|um and can be long-form short form open
773.339|3.06|domain and close domain so very diverse
775.32|3.3|and I think it provides a very
776.399|6.261|comprehensive evaluation of models in
778.62|4.04|this medical question answering setting
784.38|4.5|um so we have a task on The Benchmark uh
786.54|4.44|the next question again I think I asked
788.88|3.54|was how do we evaluate these models and
790.98|3.299|as I mentioned before automatic
792.42|3.659|automated metrics are actually deeply
794.279|3.601|unsatisfactory because they fail to
796.079|4.44|capture the nuances of real world
797.88|4.32|clinical applications so what we did was
800.519|3.361|uh actually heavily inspired by some of
802.2|3.24|students work over here was to put
803.88|4.44|together a human evaluation framework
805.44|4.86|for assessing these long-form answers uh
808.32|4.019|and uh
810.3|4.68|this had two parts the first part was
812.339|4.261|evaluation by clinicians and we asked
814.98|4.02|them to rate the model responses along
816.6|5.1|12 axes pertaining to factuality of the
819.0|4.38|responses uh ability to recall uh
821.7|3.6|medical knowledge to Medical reasoning
823.38|5.06|and also for the potential of harm and
825.3|3.14|bias in these responses
828.779|3.601|um but if you look at like the potential
830.639|3.061|end users of such Medical qna Systems
832.38|3.48|these are likely going to be non-expert
833.7|4.199|layer users so it is also important to
835.86|4.44|get these uh answers evaluated by them
837.899|4.801|as well and so we uh also additionally
840.3|3.839|asked a pool of layer users as to how
842.7|3.92|helpful and actionable they thought the
844.139|2.481|answers were
847.139|4.14|um and so that was our evaluation
849.24|4.68|framework uh and we also have the
851.279|4.021|Benchmark effects so now we've moved on
853.92|5.039|to the fun part of you know building and
855.3|5.4|aligning llms to the medical domain task
858.959|4.68|um so in this work we decided to build
860.7|4.139|on the palm family of language models uh
863.639|3.961|has that been covered in the course
864.839|4.861|before okay great uh so but very quickly
867.6|4.5|uh I believe this is still the largest
869.7|3.9|publicly announced uh you know densely
872.1|3.539|activated decoder only large language
873.6|5.88|model uh with the largest one being 5
875.639|5.94|and 40 billion parameters in total
879.48|4.919|um a few more details the models trained
881.579|5.7|on uh sand a 40 billion tokens uh 25 of
884.399|3.841|which is multilingual uh the data come
887.279|3.541|from a bunch of different sources
888.24|5.399|including uh social media conversations
890.82|4.259|web pages books GitHub and Wikipedia and
893.639|3.181|so on and so forth
895.079|3.661|um and at this time of release the model
896.82|3.959|was share the art on many NLP reasoning
898.74|3.48|benchmarks and also was the first Model
900.779|4.261|to exceed uh the average human
902.22|4.02|performance on big bench uh further over
905.04|3.06|the last year
906.24|2.94|um Palm derived models were shown to be
908.1|3.06|super useful in a bunch of different
909.18|3.54|application settings including for code
911.16|3.9|generation which was the Palm coder
912.72|4.14|model in robotics the Palm secan model
915.06|3.48|and also for answering math and science
916.86|3.659|questions uh which is the minervous
918.54|3.359|models and so we thought Palm was a very
920.519|3.781|good foundation model for us to build on
921.899|4.321|and use it in the medical domain as well
924.3|3.839|and overall I think Palm is a true magic
926.22|4.32|of engineering but I will refer you all
928.139|5.961|back to akancha's uh paper on this for
930.54|3.56|uh more details I think it's a must read
934.22|4.66|and again in late October last year
936.959|3.661|Jason way and a few others at Google
938.88|3.84|brain came out with the flan Palm
940.62|3.24|variant of these uh of the farm model
942.72|3.72|and this is basically the instruction
943.86|4.38|tune counterpart and this model was even
946.44|3.24|better than palm and I believe this is
948.24|4.08|still the soda state of the art on many
949.68|4.32|benchmarks such as mmlu tidy QA and I
952.32|4.319|think it exceeds Palm performance by an
954.0|4.139|average of 9.4 percent across big bench
956.639|4.621|tasks
958.139|5.161|so so we decided to build on the plan
961.26|3.72|bomb model and we applied a combination
963.3|3.18|of prompting strategies including few
964.98|3.12|shot prompting
966.48|3.84|um Chain of Thought reasoning and also
968.1|4.38|self-consistency to the 540 billion
970.32|3.78|parameter variant and we evaluated it on
972.48|4.2|the multimed QA data sets that had the
974.1|4.44|short form McQ questions
976.68|2.94|and we found that this model was really
978.54|2.58|really good
979.62|4.38|um at the time of publication this model
981.12|4.38|on the USM limited data set exceeded the
984.0|3.86|previous state of the art by over 17
985.5|2.36|percent
988.639|5.5|it's only for the USMLE material data
991.62|4.26|sets that's right
994.139|2.94|um and so you see that the accuracy over
995.88|3.139|the previous state of the art at the
997.079|4.861|time of publication went up by over 17
999.019|4.961|and I believe this was the first paralym
1001.94|4.62|based AI system to obtain like a passing
1003.98|5.12|equal in score which was 60 or above on
1006.56|2.54|this benchmark
1009.199|3.781|um and similarly when we looked at other
1010.94|4.44|McQ data sets in The Benchmark for
1012.98|3.719|example mcmcqa which is a data set of
1015.38|2.639|Indian medical entrance examination
1016.699|3.361|questions the model was again the state
1018.019|3.361|of the art on PubMed care which was
1020.06|3.18|question answering based on PubMed
1021.38|2.699|abstracts that was again the model was
1023.24|4.38|straight of the art at the time of
1024.079|4.98|publication uh and same story on mmlu
1027.62|4.62|clinical topics as well which include
1029.059|4.74|genetics uh Anatomy professional
1032.24|4.439|medicine clinical knowledge and a bunch
1033.799|5.221|of other topics in there
1036.679|3.9|um so
1039.02|3.0|all this was great and then when we
1040.579|3.061|started looking at the scaling plots uh
1042.02|3.419|what we again saw was that the
1043.64|5.279|performance seemed to be improving as we
1045.439|6.001|scaled the model uh from uh 8 billion to
1048.919|4.081|62 billion to 540 billion and so what
1051.44|3.119|this basically suggested that these
1053.0|2.94|general purpose large language models
1054.559|4.021|trained on public Internet seem to
1055.94|4.2|encode clinical knowledge pretty well uh
1058.58|3.36|and they uh and their medical reasoning
1060.14|3.899|abilities tend to scale with model
1061.94|4.08|parameter size
1064.039|4.561|uh we also did another experiment when
1066.02|5.76|we looked at selective prediction uh and
1068.6|4.74|we used the self-consistency uh votes to
1071.78|3.96|determine when to differ and this is
1073.34|4.98|important in clinical settings uh
1075.74|4.02|because you know doctors uh communicate
1078.32|2.7|when they don't know about something and
1079.76|2.64|if our AI systems are going to be used
1081.02|2.76|in clinical settings for example for
1082.4|2.94|diagnosis they should be able to tell
1083.78|3.84|you when they don't know something
1085.34|5.1|and so what we observed here was this
1087.62|4.559|fairly crude metric uh we were getting
1090.44|4.32|like a linear Improvement in performance
1092.179|5.041|as being changed the default threshold
1094.76|3.9|uh and this was quite nice but in
1097.22|2.819|practice is actually quite inefficient
1098.66|3.42|because you're generating like you know
1100.039|3.421|multiple uh decoding samples to be able
1102.08|4.76|to compute this metric so we need a
1103.46|7.02|better method there was an important
1106.84|5.92|model asks uh yeah it's basically says
1110.48|4.559|I'm uncertain around one and that's uh
1112.76|4.64|determined based on the cell consistency
1115.039|4.701|votes I see okay so you don't have
1117.4|6.3|certificate
1119.74|3.96|exactly exactly
1129.82|3.16|no because they just trained on this
1131.84|3.06|next word prediction task and that
1132.98|3.6|depends on the data set the PubMed QA
1134.9|3.3|has some answers which are maybe but
1136.58|3.12|again we don't explicitly fine tune the
1138.2|3.18|models over here so you know the models
1139.7|4.68|are not trained
1141.38|3.0|involved
1147.98|4.22|so we went out and then basically
1152.38|3.36|after this
1156.76|4.6|oh no so this is primarily based on the
1159.62|3.84|reference of uh in the data sets which
1161.36|3.6|is so this is all accuracy Matrix so we
1163.46|2.76|already know between the four options of
1164.96|2.76|five options which one's the right one
1166.22|3.48|and so we just do the classification
1167.72|3.3|yeah so I'll come back to the clinician
1169.7|3.359|evaluation a bit later
1171.02|4.32|sorry maybe I missed something how are
1173.059|4.74|you measuring uncertain tool
1175.34|4.14|um so if you know what self-consistency
1177.799|4.5|prompting what we do is we generate
1179.48|5.819|multiple decodes from the same model and
1182.299|5.581|then we see uh the number of times uh
1185.299|3.901|the highest ranking answer is voted and
1187.88|3.299|based on that you can fix a threshold
1189.2|4.5|and say if it's below this number I'm
1191.179|4.081|going to differ so if say the majority
1193.7|4.26|answer comes up in your self-consistency
1195.26|5.039|equals only like 10 times out of K or
1197.96|3.719|whatever uh then and that if if that n
1200.299|2.641|is too small then it's very likely the
1201.679|3.5|model is uncertain so that's how we
1202.94|2.239|differ
1206.539|2.0|um
1209.419|5.401|um so they don't really see like a paper
1212.539|5.581|off in the spot so like it's not the
1214.82|5.4|best but the rest would look like
1218.12|4.08|um I think if you plot it further to
1220.22|3.06|Flatline uh but again that's not useful
1222.2|2.82|I mean if you're saying no to every
1223.28|2.82|question that's not useful at all so you
1225.02|3.44|want to have a reasonable definite
1226.1|2.36|percentage
1228.52|5.019|right I think that's high
1231.679|3.961|I think that's still higher 50 is quite
1233.539|3.961|high but again that this is a very
1235.64|3.06|contrived setting but in real world use
1237.5|3.6|cases probably I think that number
1238.7|4.14|should be much lower
1241.1|2.78|yeah
1242.84|5.16|because
1243.88|4.12|of course yeah
1258.82|3.58|that's right I think balanced accuracy
1261.08|3.839|might be a better metric but we looked
1262.4|4.019|at some of these data sets and uh one
1264.919|3.061|data set this queue was pretty bad the
1266.419|3.0|pubmedia data set and I think no one
1267.98|3.24|should use it so if anyone's reporting
1269.419|4.14|soda numbers on that data set you should
1271.22|3.66|just discuss them and talking about very
1273.559|4.381|specific people
1274.88|4.5|um but um again um I think as I
1277.94|3.0|mentioned these accuracy metrics are
1279.38|2.88|good for you know publicity and pushing
1280.94|2.88|up Benchmark numbers and so on and so
1282.26|2.94|forth but the real evaluation is human
1283.82|2.28|evaluation of the long form answers and
1285.2|2.58|that's what I'll come to in the next
1286.1|3.68|part
1287.78|2.0|um
1291.32|4.56|um so so far so good right um I mean we
1293.659|3.421|were getting uh sold our results on
1295.88|3.24|these benchmarks and we're very happy
1297.08|3.36|and so what we did was I mean one thing
1299.12|3.179|you'll observe that I have so far only
1300.44|4.26|reported results on multiple choice
1302.299|3.961|questions short form answers uh so what
1304.7|3.06|was left for us to do was to take these
1306.26|2.94|answers uh take these models and
1307.76|3.18|generate long-form answers to the other
1309.2|3.959|uh data sets that we had and get them
1310.94|6.119|human evaluated and I think that is
1313.159|8.4|where the real project began uh when we
1317.059|6.841|looked at the uh evolves uh by you know
1321.559|4.801|experts and lay people it revealed very
1323.9|4.44|like key gaps and limitations uh in the
1326.36|2.76|flan Farm responses uh we were often
1328.34|2.28|seeing that these models are
1329.12|3.9|hallucinating or you know producing
1330.62|4.2|incomplete responses and when we asked
1333.02|3.12|experts like whether they preferred
1334.82|2.7|clinician generated answers or these
1336.14|2.76|model generated answers they almost
1337.52|3.06|always preferred clinician generated
1338.9|2.399|answers
1340.58|3.68|um
1341.299|5.641|so it was very clear that's
1344.26|7.899|really what that means it's evaluators
1346.94|5.219|are these people or these okay
1352.22|4.26|um and so what this previous results
1354.08|3.9|showed was while these models already
1356.48|3.179|encode some degree of uh you know
1357.98|3.48|clinical knowledge to be really used in
1359.659|3.481|actual real world settings you need to
1361.46|2.64|align these models better to safety
1363.14|2.34|critical requirements of the medical
1364.1|3.42|domain
1365.48|3.48|um but a big challenge is we did not
1367.52|3.42|have any kind of supervised or feedback
1368.96|4.68|data and so we really need the alignment
1370.94|4.56|technique to be data efficient
1373.64|5.039|um but thankfully uh we had instruction
1375.5|4.44|from tuning uh which was uh introduced
1378.679|3.601|by Brian Lester and a few others at
1379.94|5.64|Google a couple of years back and how
1382.28|6.06|this method works is uh it essentially
1385.58|5.16|freezes the big llm model and only
1388.34|5.28|learns an additional small set of prompt
1390.74|4.62|vectors uh which can then be used to
1393.62|4.02|condition the model that inference uh
1395.36|4.02|when doing the generation and the nice
1397.64|4.74|thing about this is it allows very
1399.38|6.24|easier use of the model across tasks and
1402.38|5.22|domains and you only need to like carry
1405.62|4.26|around this additional prompt parameters
1407.6|3.84|right and these tend to be much smaller
1409.88|4.26|than like the fan the billions of
1411.44|4.979|parameters that you have in the yellow
1414.14|3.6|um and the other good thing is this is
1416.419|2.581|very computationally efficient as well
1417.74|2.819|so like if you were to do end-to-end
1419.0|2.88|fine tuning uh often in all compute
1420.559|2.641|infrastructure
1421.88|2.7|um even with like a few thousand
1423.2|4.56|examples that would take like a few days
1424.58|4.68|whereas with instruction pump tuning uh
1427.76|2.76|a given the data set size is also
1429.26|3.539|reduced the number of examples that you
1430.52|4.019|need is quite small uh and be you're
1432.799|3.301|just updating the prompt token vectors
1434.539|2.941|uh it meant that we were able to like
1436.1|3.0|get model updates in like a few hours
1437.48|3.42|and so that was like really fast and
1439.1|3.78|enabled like really quick iterations for
1440.9|3.659|us
1442.88|4.919|um so this was how we put together the
1444.559|5.901|final metform model uh we say go ahead
1447.799|2.661|sorry
1450.52|2.86|okay cool
1452.24|3.24|um so this was how we put together the
1453.38|4.44|final metform model um so we used
1455.48|4.62|instructions and exam plus from a panel
1457.82|4.02|of uh expert clinicians and these were
1460.1|3.66|uh in the order of hundreds not like the
1461.84|2.94|Thousand certain tens of thousands and
1463.76|2.82|you see a few examples over there
1464.78|3.3|there's an instruction uh followed by
1466.58|4.079|model answer followed by an explanation
1468.08|4.5|and we use that to learn the prompt
1470.659|5.041|vectors and so the final metform model
1472.58|5.099|is basically uh all of plan bomb plus
1475.7|3.78|these additional soft prompt Vector uh
1477.679|2.821|parameters uh which are used to align
1479.48|2.939|the model to the requirements of the
1480.5|3.179|medical domain and why this works well
1482.419|2.581|is because as we have seen before the
1483.679|3.36|model already has medical knowledge
1485.0|3.36|encoded in it all we need is to like
1487.039|2.821|teach the model how to use it properly
1488.36|3.66|in the given application setting and
1489.86|3.72|that's what these prompt uh parameters
1492.02|3.899|do for us
1493.58|3.9|so the question I wanted to ask is um
1495.919|3.481|navigate to be published a lot about
1497.48|3.179|like borrowing chat and given the fact
1499.4|3.18|that you have all of these student
1500.659|4.5|preferences it's best by your evaluators
1502.58|7.76|and you guys explain and you guys can
1505.159|5.181|find that a reward or preference model
1510.82|3.46|yeah I think you can think about like
1512.9|3.779|different stages of model development
1514.28|4.259|right so this is pre-deployment and
1516.679|3.541|release in the real world so you can't
1518.539|3.301|put a crappy model out there in the real
1520.22|3.48|world so even before doing that if you
1521.84|3.6|can like get like maybe 100 examples
1523.7|3.06|from whatever experts that you can get
1525.44|2.4|hold of and use that to prompt your new
1526.76|3.18|model that's better that's a much better
1527.84|3.18|starting point uh before you expose them
1529.94|3.3|all to the real world and collect
1531.02|4.86|preferences from real users at scale and
1533.24|4.2|so I think rlhf is also uh much less
1535.88|3.659|sample efficient uh compared to
1537.44|4.02|instruction from tuning uh again because
1539.539|3.961|you're probably trying to update uh the
1541.46|3.3|uh your entire model as well so I think
1543.5|2.58|this is a very good starting point and
1544.76|3.24|so they kind of will be combined
1546.08|5.64|depending on how uh depending on the
1548.0|3.72|life cycle of the model evaluations
1554.12|4.559|the data set is public we have we I'll
1556.279|4.741|talk about the results uh in a bit sorry
1558.679|4.261|about the human evaluations contained
1561.02|4.68|publicly within the Asm
1562.94|5.04|uh you mean the model responses and what
1565.7|4.56|the human celebrations oh that's a good
1567.98|3.96|point Beyond so far not considering
1570.26|4.44|releasing them but maybe we can perfect
1571.94|4.8|okay uh do you see a use case for that
1574.7|3.959|well just uh
1576.74|4.28|you have a bunch of data in the bar and
1578.659|2.361|says
1581.16|3.059|[Music]
1584.36|3.38|so if I wanted to train a reward model
1585.98|3.6|that data is what I would explain that
1587.74|3.76|yeah that's a good point I think the
1589.58|3.599|evaluation data set is I'll talk about
1591.5|3.059|this a bit it's still small but I think
1593.179|2.461|if we scale it up and we are doing it
1594.559|2.1|right now I think we can release that
1595.64|1.98|and that will be I think the good
1596.659|3.9|resource of what you're trying to do
1597.62|4.559|cool
1600.559|3.301|um so we have them at one model as I
1602.179|3.661|said and now we took the long form
1603.86|3.96|answers from it and compared that to the
1605.84|4.56|flat bomb model as well as to answer
1607.82|3.66|generate by expectations and as I said
1610.4|2.759|we have two parts to the human
1611.48|4.439|evaluation one is by expert clinicians
1613.159|5.64|and the other one is by layer users and
1615.919|4.681|so what do these results look like uh on
1618.799|4.921|the wire and for your questions that we
1620.6|4.76|got these evaluation results on uh what
1623.72|3.839|we observed typically
1625.36|3.88|across the board was
1627.559|4.021|um when we looked at like different axes
1629.24|4.439|while the flan Palm model would be quite
1631.58|3.839|terrible honestly uh the Metro model
1633.679|4.201|would do much better and typically close
1635.419|4.321|the gap to expert clinicians so on this
1637.88|5.22|access you see that like the platform
1639.74|4.919|model has probably a 60 odd accuracy
1643.1|2.699|accuracy in terms of like scientific
1644.659|3.361|consensus
1645.799|3.841|um the metform model improves them
1648.02|3.74|improves on that quite a bit and closes
1649.64|5.1|the capital Dimensions over here
1651.76|6.34|uh similar story on other axes as well
1654.74|5.819|over here you see uh the the like
1658.1|3.72|clinicians rating on the axis of uh how
1660.559|2.821|how well the model can retrieve medical
1661.82|2.7|knowledge how well it can reason about
1663.38|3.84|it
1664.52|5.24|um and again we see the same Trend as in
1667.22|2.54|the previous slide
1682.059|5.021|no so what can be present at the same
1684.559|4.141|time so you can have evidence of correct
1687.08|4.579|comprehension also evidence of incorrect
1688.7|6.479|comprehension uh sometimes
1691.659|5.861|exactly so so that's why they're not one
1695.179|3.961|minus over here but the trends are the
1697.52|4.7|same oh so that's why I skipped a lot
1699.14|3.08|but that's a detail a good point
1703.64|3.659|um yeah again so there's a type over
1705.32|4.8|here uh but this one pertains to
1707.299|4.74|incorrect our missing content
1710.12|3.48|um but this was an interesting one
1712.039|3.601|because what when we were doing this
1713.6|3.9|from tuning thing uh was
1715.64|4.32|um we were teaching the metform model to
1717.5|3.539|produce uh longer and more complete
1719.96|3.24|answers and so you can see a few
1721.039|3.301|qualitative examples later but what
1723.2|2.76|ended up happening in the process was
1724.34|3.6|sometimes the model was maybe producing
1725.96|3.42|uh more incorrect information so that's
1727.94|3.54|why you see that maybe in this
1729.38|3.24|particular axis uh the flan model was
1731.48|3.9|slightly better but again this was much
1732.62|5.76|worse compared to uh clinicians
1735.38|3.0|foreign
1740.24|4.08|um it's a good question it is more like
1742.7|4.62|it's something something completely out
1744.32|4.32|of context uh so it may be irrelevant to
1747.32|4.7|the question
1748.64|3.38|so that's what I would say so
1755.9|4.44|um we also looked at like possible and
1758.059|3.72|extent and likelihood of harm uh and
1760.34|2.88|again we see that with the instruction
1761.779|4.02|from training we're able to close the
1763.22|5.22|gap to expect Generations over here uh
1765.799|4.681|same on the bias access as well
1768.44|4.08|okay sure
1770.48|5.819|have you interpret the top
1772.52|6.899|uh exactly so like I
1776.299|4.62|I basically see like something death and
1779.419|4.021|then the clinicians at like six percent
1780.919|4.581|seems like
1783.44|2.06|um
1787.6|4.9|yeah so it's basically so there might be
1790.82|5.219|certain conditions or pathologies or
1792.5|5.46|diagnosis right like cancer uh and uh if
1796.039|5.581|for example recognition has not got that
1797.96|6.36|or has maybe given a response that does
1801.62|3.9|not appropriately convey the severity of
1804.32|3.18|the condition then that could
1805.52|3.12|potentially lead to severe harm or death
1807.5|2.7|and so that's what we were trying to
1808.64|3.899|capture over here
1810.2|3.66|um so that's a very high level overview
1812.539|3.721|this is a
1813.86|4.559|uh I think of any nuanced topic and
1816.26|4.2|there's a framework for it called the AI
1818.419|3.901|ahrq framework and so we've linked that
1820.46|3.599|in the paper as well and so I think that
1822.32|3.54|gives you a very detailed notion of harm
1824.059|3.0|and bias that's why I would refer to
1825.86|3.36|that but at a high level this is what
1827.059|5.34|I'm talking about hope that helps all
1829.22|6.12|right so when later I read class and I
1832.399|5.701|say the clinician had 5.7 or external
1835.34|4.68|possible arm which means like what would
1838.1|3.439|I say does that mean that like they
1840.02|3.659|recommend something like
1841.539|4.181|maybe they fail to recommend something
1843.679|3.901|uh yeah
1845.72|3.42|um so it's basically a misdiagnosis or
1847.58|4.02|maybe failing to capture the severity of
1849.14|6.06|a diagnosis this is typical in life
1851.6|5.4|threatening conditions right so
1855.2|5.359|so it's more often than not not mistakes
1857.0|3.559|but rather just missing out on details
1863.659|4.441|um yeah so I talked about bias as well
1865.7|5.04|um and then as I said the other axis of
1868.1|4.199|human evaluation was with layer users uh
1870.74|4.38|and so we asked them how well does the
1872.299|4.62|model answer uh address the intent of
1875.12|3.299|the question and again we saw with
1876.919|4.14|instruction from during metform closing
1878.419|5.221|the Gap to clinicians and then we asked
1881.059|5.1|them like how helpful the responses were
1883.64|3.899|and what we see is that while flan Palm
1886.159|3.12|responses were considered to be helpful
1887.539|3.601|like 60 of the time the number improved
1889.279|3.78|to 80 for metform but it was still
1891.14|4.08|fairly lower compared to clinicians at
1893.059|2.761|90 percent
1895.22|2.64|um
1895.82|4.079|so here are a few qualitative examples
1897.86|3.419|and so what you see is that Physicians
1899.899|3.66|and this is typically because they work
1901.279|4.981|in time constraint settings they are
1903.559|5.881|their answers tend to be precise uh and
1906.26|4.86|sucking uh succinct uh but sometimes
1909.44|3.18|it's very hard as layer users or
1911.12|2.46|patients to like decifer and decode the
1912.62|2.46|answer and get all the full set of
1913.58|3.18|details right and so what I think
1915.08|3.3|language models like metform can help
1916.76|3.24|with is actually converting The
1918.38|3.84|Physician speed to something that's more
1920.0|4.5|easily digestible by layer users and so
1922.22|4.26|this is where I think uh how these
1924.5|3.24|models will likely fit in uh in clinical
1926.48|2.64|settings in the real term where they're
1927.74|3.36|going to augment physicians in terms of
1929.12|5.539|like Contracting with patients and other
1931.1|3.559|Physicians and researchers as well
1935.96|3.0|very
1949.52|5.6|if I predict as a patients
1956.2|3.52|that's right I think it's subjective and
1958.399|4.5|so that's why I think we're still seeing
1959.72|4.74|like um layer users platform answers to
1962.899|2.941|be helpful 80 well that's much higher
1964.46|2.88|for Physicians
1965.84|3.66|um so it's not perfect by any means but
1967.34|3.6|I think this is where it's there is a
1969.5|2.34|complementality element we feel over
1970.94|3.18|here
1971.84|4.86|and we've asked students like when we
1974.12|5.22|ask people like uh how easy is it to
1976.7|4.02|like interpret doctor uh notes uh or
1979.34|2.64|recommendations and they often say oh
1980.72|3.24|it's very hard I need to go back to
1981.98|3.419|Google search for what these terms mean
1983.96|2.459|what these abbreviations mean and so I
1985.399|2.581|think this is where language model can
1986.419|3.24|come and take that note and convert that
1987.98|3.78|into something that's more easily
1989.659|3.301|digestible uh like
1991.76|3.919|um so I think that's the opportunity
1992.96|2.719|over here I feel
1999.919|3.6|um so that was all on our paper but I
2002.32|2.82|also want to maybe very quickly point
2003.519|3.54|out a very recent work which came out
2005.14|3.36|last week with this rather provocative
2007.059|3.48|title uh do we still need clinical
2008.5|5.519|language models and by clinical language
2010.539|6.48|models they meant smaller models which
2014.019|4.461|are trained in domain with clinical data
2017.019|4.38|such as medical nodes
2018.48|4.66|and records and so on and so forth and
2021.399|4.681|what this paper basically suggests is
2023.14|5.159|that smaller fine-tuned in-domain LMS
2026.08|4.319|are likely better than general purpose
2028.299|4.441|llms in this paper I think they
2030.399|3.78|evaluated on gpd3 uh with in context
2032.74|2.7|learning
2034.179|2.761|um so I think that's a pretty
2035.44|3.599|interesting and neat observation I think
2036.94|5.219|there's a lot of value for a smaller in
2039.039|4.62|domain LMS such as PubMed GPT and a few
2042.159|2.941|other variants but I think one thing
2043.659|3.721|that this paper does not do is consider
2045.1|4.2|in context learning uh sorry prompt
2047.38|3.18|tuning and I think that's where some of
2049.3|5.039|the benefits of this larger general
2050.56|7.64|purpose llms shine and again we haven't
2054.339|6.741|done any uh in domain LM free training
2058.2|4.959|on the this large general purpose
2061.08|3.94|models but that's again an option for us
2063.159|3.301|as well to do it on the line so you can
2065.02|2.879|take these 540 billion parameters and
2066.46|2.82|then still train it on medical nodes or
2067.899|2.46|whatever domain specific data that you
2069.28|4.339|can get hold of and hopefully they'll
2070.359|3.26|probably further improve the performance
2073.78|6.119|um so key takeaways so far um what I
2077.859|4.02|want to convey was general purpose llms
2079.899|3.841|it looks like they do encode medical
2081.879|4.401|knowledge and performance on medical
2083.74|4.5|reasoning tasks seem to improve at scale
2086.28|3.399|however these models I don't think can
2088.24|2.939|be directly used out of the box in
2089.679|3.48|clinical settings and they need to be
2091.179|4.081|aligned with the safety critical
2093.159|4.021|requirements of the medical domain and I
2095.26|3.599|think instruction prompting prompting is
2097.18|2.939|an extremely efficient technique both on
2098.859|2.941|the data side and also on the compute
2100.119|4.441|side and we should probably use it more
2101.8|4.44|often depending on and hopefully the API
2104.56|4.2|starts supporting it as well
2106.24|5.04|um and these models appear to be closing
2108.76|4.02|the Gap to expert clinicians uh at least
2111.28|4.5|on this medical question answering tasks
2112.78|4.5|and while this is hugely exciting and
2115.78|2.64|has profound implications you can all
2117.28|3.78|probably dream up and imagine the
2118.42|4.5|application scenarios over here uh I
2121.06|4.019|think comprehensive benchmarks and
2122.92|3.9|evaluation Frameworks are necessary in
2125.079|5.341|order to further assess and improve
2126.82|6.92|these models for available use cases
2130.42|3.32|um so I'll stop over here any questions
2148.06|5.82|a lot of it is because these data sets
2150.76|4.44|tend to get locked in silos with privacy
2153.88|2.699|and other kinds of regulations which
2155.2|3.18|prevent them from being put out there in
2156.579|3.661|the real world so you have to have like
2158.38|3.18|hip-hop compliant systems for storage
2160.24|3.06|and so on and so forth so it's very
2161.56|4.68|difficult to get data out of these silos
2163.3|5.58|and put together an open Benchmark
2166.24|4.14|um so honestly I feel like that's
2168.88|3.239|probably not going to improve the the
2170.38|3.06|scale of these data sets at least the
2172.119|4.201|open version of these data sets are
2173.44|5.28|going to remain uh quite small compared
2176.32|3.84|to the big LM training data sets or the
2178.72|3.42|computer division data sets on natural
2180.16|3.78|images and so on and so forth but what
2182.14|3.42|may happen in the future is we may have
2183.94|3.12|like more distributed Federated
2185.56|2.9|evaluation settings where you take the
2187.06|4.2|model into
2188.46|4.78|these uh private silos and get them
2191.26|3.24|evaluated on so they are never exposed
2193.24|2.64|and put out there in the public but
2194.5|3.0|rather we can have these very dead
2195.88|3.12|evaluation settings
2197.5|2.46|um so I think that there's some work on
2199.0|2.88|that already there's a system called
2199.96|5.399|metforf and you'll probably see more of
2201.88|3.479|them foreign
2207.119|6.701|sure so the question over here was why
2210.76|5.099|medical data sets are smaller compared
2213.82|4.08|to uh natural image data sets in
2215.859|4.201|computer vision or LM training data sets
2217.9|3.48|and so on and so forth
2220.06|4.559|what do you think are some of the
2221.38|6.02|earliest applications of medical llms
2224.619|5.101|like deployed in Industry
2227.4|4.12|uh I think the first set of use cases
2229.72|5.52|are probably going to be not Diagnostic
2231.52|4.86|in it sorry the question was uh what do
2235.24|4.08|you think are the use cases of medical
2236.38|3.84|llms and medical industry settings and
2239.32|2.34|so
2240.22|3.42|the answer is I think the first set of
2241.66|3.24|use cases that we are going to see are
2243.64|4.62|probably going to be non-diagnostic in
2244.9|5.219|nature but more around like if you uh if
2248.26|3.42|a patient comes in and interacts with a
2250.119|4.321|doctor can you like generate summary
2251.68|5.88|notes uh and can you do like workflow
2254.44|6.12|tasks such as generating letters for
2257.56|4.26|insurance for medications for referrals
2260.56|2.7|and so on and so forth I think these
2261.82|3.24|tasks are right up the alley of large
2263.26|3.54|language models and I think if not
2265.06|2.76|already in the next six months to a year
2266.8|2.4|we'll see a lot of these use cases
2267.82|3.0|coming up and I think that's going to
2269.2|3.06|you know make doctors like care
2270.82|3.299|providers life much easier because right
2272.26|3.359|now they're spending a lot of time doing
2274.119|4.161|these things and not actually providing
2275.619|4.621|care and attending to the patient
2278.28|3.1|diagnostic use cases I think will take a
2280.24|2.879|lot more time we need a lot more
2281.38|2.88|evaluation the data sets as we can see
2283.119|3.061|are probably not there the evaluation
2284.26|3.3|Frameworks are not there but I think in
2286.18|2.76|the long run and that is the dream
2287.56|4.5|setting right
2288.94|5.46|and then maybe a problem is men I'm
2292.06|4.44|assuming Ned Palm is not open source
2294.4|5.459|what do you think the best open source
2296.5|5.76|model is automatically
2299.859|4.201|um you know I think it depends on the so
2302.26|5.46|the question is what is the best uh open
2304.06|5.82|source uh model for medical data uh it I
2307.72|5.46|think depends on the evaluation setting
2309.88|5.1|uh so uh I think the PubMed GPT model
2313.18|5.22|from the Stanford Foundation models
2314.98|5.16|group is quite strong uh I think gpt3 or
2318.4|3.36|3.5 or whatever variant if you can bring
2320.14|3.66|in some domain specific medical data and
2321.76|3.599|do some in tuning adding that model can
2323.8|3.0|also improve quite a bit so I think
2325.359|4.101|those two would be my favorite starting
2326.8|2.66|points over here
2338.28|5.02|it's you can just think them as vectors
2341.74|4.74|corresponding to a few additional tokens
2343.3|5.16|uh so it's not really uh human legible
2346.48|4.74|so the question was what do the stock
2348.46|5.1|prom factors look like uh and are they
2351.22|4.98|human legible and uh yeah the answer is
2353.56|4.64|no they're not
2356.2|2.0|um
2378.28|5.579|sure uh so the question was uh given uh
2382.18|4.86|a lot of the hospital systems and
2383.859|5.341|providers networks are quite low-tech
2387.04|3.539|and don't have good enough Hardware do
2389.2|2.7|you really think Federal learning could
2390.579|3.481|be used for distributed training of
2391.9|4.14|large-scale llms
2394.06|4.74|um I think we are increasingly seeing a
2396.04|5.94|trend towards cloud and so a lot of
2398.8|5.279|these uh Hospital systems are moving
2401.98|4.74|their storage and data and compute to
2404.079|5.161|standard Cloud providers like AWS or
2406.72|5.7|Azure or Google cloud and so I think
2409.24|4.68|that helps because these systems on the
2412.42|3.78|backend side do have the compute to be
2413.92|3.36|able to like train these kind of models
2416.2|3.96|um I think it's going to be a very
2417.28|4.319|gradual process so systems that have
2420.16|3.54|high quality infrastructure probably
2421.599|3.48|we're going to start with that first and
2423.7|3.72|then gradually work our way into the
2425.079|4.381|long tail uh but it also feels like
2427.42|3.9|something that will inevitably exist in
2429.46|3.06|the world uh so 10 years down the line
2431.32|3.18|or 15 years down the line when we have
2432.52|4.079|these distributed large-scale llm
2434.5|4.099|Training Systems uh we'll always think
2436.599|4.26|back oh why did I even doubt that this
2438.599|3.341|will not exist it's so obvious it's
2440.859|2.521|something that has to exist because
2441.94|3.48|that's where all the patient data is all
2443.38|3.36|the interesting data is right so I think
2445.42|2.76|that'll just happen it's just not clear
2446.74|2.58|where that's going to be done by one
2448.18|3.5|company whether that's going to be done
2449.32|4.62|by Consortium of academic uh or industry
2451.68|5.46|groups or where governments are going to
2453.94|3.2|be involved or so on and so forth so
2464.64|4.719|that's right uh so the question over
2467.02|3.96|here is we're seeing uh cloud computing
2469.359|4.381|but we are pretty much uploading the
2470.98|4.139|data to the same warehouse uh the answer
2473.74|3.24|is true but again I think these are all
2475.119|4.441|going to be separate buckets with their
2476.98|3.66|own access controls and so on and so
2479.56|3.98|forth so that is how you can
2480.64|2.9|differentiate between them
2484.119|7.381|uh
2486.339|5.161|there's not a lot of fun videos
2511.72|4.08|sure so the question was has there been
2513.76|3.66|any studies in metform looking at
2515.8|4.559|private information in these data sets
2517.42|4.5|and the short answer is no uh the one of
2520.359|3.181|the criteria for selecting the data sets
2521.92|2.64|that we used in the study was to not
2523.54|2.88|include any kind of personally
2524.56|3.66|identifiable data or clinical data of
2526.42|3.96|that sort and that helped like you know
2528.22|4.44|get this paper out on time but I think
2530.38|4.32|that's an important Point uh
2532.66|4.38|it's unlikely that we're going to have a
2534.7|4.8|lot of Phi data in public well uh in the
2537.04|5.46|public uh data sets that we are training
2539.5|4.74|on uh but uh even when you're training
2542.5|3.18|on say one private Corpus and then
2544.24|3.48|you're using it in another application
2545.68|3.72|setting uh you want to ensure that the
2547.72|3.54|model does not leak out any kind of Phi
2549.4|3.0|information uh during this generation so
2551.26|4.2|I think those sort of studies are
2552.4|5.12|necessary we haven't gotten to them yet
2555.46|2.06|um
2566.64|4.78|uh so the question is what are the next
2569.32|4.92|steps in terms of improving these models
2571.42|4.86|further uh yeah retrieval is a very
2574.24|3.78|important one being able to site sources
2576.28|4.74|and especially take in authoritative
2578.02|4.26|sources and use that in generating the
2581.02|3.24|answers and also communicating that to
2582.28|4.319|the users is very important I think how
2584.26|5.099|you can communicate uncertainty is very
2586.599|4.561|important so we've gotten to some extent
2589.359|3.661|using instructional prompt tuning but I
2591.16|4.88|think that can be much much better
2593.02|4.98|um so I think that's another big bucket
2596.04|3.579|uh again I would stress on the
2598.0|3.54|evaluation side like you know looking at
2599.619|5.401|more data sets which for example may do
2601.54|4.86|a q a on health records or or other
2605.02|3.0|kinds of medical data I think that will
2606.4|4.199|be important and also extending the
2608.02|3.9|evaluation both in terms of scale uh
2610.599|3.061|having a diverse panel of clinician
2611.92|3.78|support and also in terms of the data
2613.66|3.78|that you're using maybe I adversarily
2615.7|3.3|modifying the questions to include like
2617.44|2.639|demographic confounders or something
2619.0|3.0|like that I think those are all could be
2620.079|3.901|interesting directions
2622.0|3.42|um I think on the modeling side the
2623.98|4.98|interesting question for me is again
2625.42|5.52|this interplay between smaller uh
2628.96|3.42|domain specific elements versus large
2630.94|2.78|general purpose elements and how that's
2632.38|3.6|going to play out
2633.72|4.96|there seems to be some evidence of
2635.98|6.119|emergence over here uh with especially
2638.68|4.98|with medical reasoning and so as you can
2642.099|3.0|see at lower scale sometimes the
2643.66|3.54|performance is not good enough I mean 50
2645.099|3.961|I mean that's a good number but that's
2647.2|4.08|just not viable and but when you get to
2649.06|3.84|like 80 90 products really become useful
2651.28|3.6|right and so that we are seeing at like
2652.9|4.26|you know bigger parameter sizes of these
2654.88|5.9|models but I I don't know I think it's
2657.16|3.62|still an open question over here
2662.079|3.301|yeah
2663.819|4.201|this the question was is hallucination
2665.38|4.62|an issue I think it still is but I
2668.02|4.079|believe that you can control that fairly
2670.0|3.78|well with instruction prompt tuning but
2672.099|5.041|like any kind of feedback data I think
2673.78|4.799|it's not terribly difficult to do and so
2677.14|3.84|the the
2678.579|4.74|uh I think it the it might have been
2680.98|3.42|overblown generally so especially when
2683.319|5.401|you are doing it in a particular domain
2684.4|4.32|I think it's easier to control foreign
2723.78|4.24|hallucinations and general purpose LMS
2726.22|3.42|uh and this in this particular
2728.02|3.96|application domain it seems particularly
2729.64|3.66|relevant and so can you expand on that a
2731.98|2.639|little bit further
2733.3|4.019|um sure so
2734.619|4.141|what we are seeing is even with like an
2737.319|3.841|order of a few hundred examples from
2738.76|3.72|expert clinicians uh teaching the models
2741.16|3.06|how to communicate medical information
2742.48|4.68|uh
2744.22|6.66|that is good enough to get the model to
2747.16|5.159|maybe stop hallucinating or at least
2750.88|5.4|communicate its uncertainty in a better
2752.319|5.881|way uh so this at least in this
2756.28|4.2|particular domain or this setting it
2758.2|3.419|feels more tractable to us and the
2760.48|2.639|reason I'm saying this is we've looked
2761.619|4.261|at the answers qualitatively and we are
2763.119|4.98|seeing that the model does not tend to
2765.88|4.739|like generate like super long answers uh
2768.099|3.841|or you know uh or like you know make
2770.619|4.021|like very confident predictions but
2771.94|4.98|rather the tone itself becomes like uh
2774.64|3.54|very reserved uh and it starts using
2776.92|2.939|terms like
2778.18|2.76|um you know maybe this needs to be done
2779.859|3.061|further or something like that which
2780.94|3.78|communicates uncertainty uh so how well
2782.92|3.36|is that actually correlated with the
2784.72|4.2|representation underlying uncertainty
2786.28|3.9|that we have is still I think an area of
2788.92|2.82|research but I think this is already
2790.18|3.0|promising for us that it feels
2791.74|2.82|controllable in limited application
2793.18|3.6|settings like medicine
2794.56|3.12|but if you have a general purpose llm
2796.78|2.28|trying to answer pretty much everything
2797.68|3.86|about the world I think that's a much
2799.06|2.48|harder problem
2802.72|4.859|um do you think that would be a feature
2804.52|6.36|of what's the domain David says like in
2807.579|5.52|medical situations doctors or reserved
2810.88|4.699|for apps and don't absolutely have
2813.099|2.48|absolutions
2821.04|5.319|specialize right like it could be
2823.859|4.48|something else entirely also I'm just
2826.359|4.941|curious
2828.339|6.301|yeah so the question is do you think uh
2831.3|4.84|this uh the way how the model is
2834.64|3.959|performing in this domain is that a
2836.14|4.26|feature of the data sets in the medical
2838.599|3.0|domain and
2840.4|3.36|typically based on how doctors
2841.599|3.48|communicate and I think that's true uh
2843.76|3.12|and I think that's something we need to
2845.079|3.181|build on and use over here and I think
2846.88|3.3|that's extremely helpful and hopefully
2848.26|5.16|this kind of behavior is General enough
2850.18|4.62|and can be transmitted to the model even
2853.42|4.679|when it's used in non-medical settings
2854.8|4.98|to be like you know uh more reserved
2858.099|3.0|when it's communicating uh you know
2859.78|2.28|hallucinate less and so on and so forth
2861.099|2.281|so I believe that that's one of the
2862.06|3.6|opportunities over here to like use
2863.38|4.14|these benchmarks uh come up with methods
2865.66|3.36|that you know reduce hallucination uh
2867.52|3.0|communicate uncertainty better and then
2869.02|3.0|use that as a bi-directional learning
2870.52|3.96|opportunity to improve the general
2872.02|3.48|purpose level
2874.48|2.16|um so if you have any further questions
2875.5|3.06|I'll come back again at the end of the
2876.64|3.439|talk but I want to cover the rest of the
2878.56|4.14|applications as well
2880.079|5.381|uh so the next domain I want to talk
2882.7|4.919|about is proteins uh
2885.46|3.3|um and the papers from now I'm going to
2887.619|3.081|like you know zip through them a little
2888.76|5.579|bit give in time
2890.7|5.32|but the first one I want to talk is this
2894.339|3.901|paper from a few Folks at Google
2896.02|4.559|research back in 2020 called Master
2898.24|3.96|language modeling for proteins by uh
2900.579|3.78|linearly scalable long context
2902.2|3.78|Transformers
2904.359|3.96|um so the problem here is that modeling
2905.98|3.839|long-range biological sequences uh
2908.319|3.361|requires efficient Transformer
2909.819|3.961|architectures
2911.68|3.48|um and so in this particular paper what
2913.78|4.02|they introduced was this performer
2915.16|5.04|architecture uh which approximates the
2917.8|5.16|softmax attention kernel via low rank
2920.2|5.7|decomposition uh and so this does not
2922.96|5.7|incorporate any sparsity price uh say
2925.9|6.3|like other methods like uh the reformer
2928.66|5.939|or there are many others and and this is
2932.2|4.379|good because uh sparsity press may not
2934.599|3.541|be appropriate for uh you know
2936.579|3.0|biological data such as protein which
2938.14|2.54|require Global interactions to be
2939.579|3.54|modeled
2940.68|4.6|and then the other thing is this uh
2943.119|3.421|model uh the performance scales linearly
2945.28|3.539|rather than quadratically with the
2946.54|3.84|sequence linked L and the number of
2948.819|3.0|random features that you need to
2950.38|4.14|approximate this soft Max attention
2951.819|4.201|kernel uh m is completely independent of
2954.52|4.2|the input sequence link
2956.02|3.839|so just to very quickly visualize the
2958.72|2.879|speedups and the space complexity
2959.859|3.301|improvements what you're having with
2961.599|3.541|this low rank decomposition is instead
2963.16|3.72|of having like fat matrices in your soft
2965.14|3.3|Max attention kernel you now have
2966.88|5.28|thinner mattresses which are determined
2968.44|5.52|by the size of the random features M and
2972.16|2.939|that basically reduces your quadratic
2973.96|2.94|complexity to something that is more
2975.099|3.781|linear in nature and also leads to space
2976.9|3.959|improvements
2978.88|3.3|um so I would yeah there are more
2980.859|3.061|theoretical analysis and details in the
2982.18|4.38|paper and I would refer you all back to
2983.92|3.96|it uh but what we see in terms of
2986.56|4.799|results when doing protein language
2987.88|5.34|modeling uh is that uh the accuracy of
2991.359|4.021|this of this model is on par with
2993.22|4.08|Transformers uh while reducing
2995.38|3.36|computational costs quite a bit and so
2997.3|2.819|what this suggests is that the
2998.74|3.0|approximation of the soft Max attention
3000.119|4.081|kernel is a tight approximation so that
3001.74|3.72|is good uh and then when you compare
3004.2|3.419|that with other methods such as the
3005.46|4.08|reformer or the lymphomer the accuracy
3007.619|3.601|is much higher at least on this task so
3009.54|3.66|it seems that compared to other methods
3011.22|4.26|that approximate uh like try to build
3013.2|3.72|more efficient uh Transformers this one
3015.48|4.2|is much better for biological sequence
3016.92|4.8|data at least in this setting
3019.68|4.56|and finally if you look at the attention
3021.72|4.139|uh uh
3024.24|3.5|um uh attention of the amino acid
3025.859|3.901|similarity Matrix
3027.74|4.72|you can see that the performer model
3029.76|5.099|recognizes highly similar uh amino acid
3032.46|4.26|pairs such as DNA and fny over here so
3034.859|2.821|that suggests that the model is learning
3036.72|2.94|the right set of information that we
3037.68|4.56|really want over here
3039.66|5.64|so that was a two-minute overview of
3042.24|4.44|that paper uh but uh I wonder yeah and
3045.3|3.18|talk about another one which also I
3046.68|2.52|think is really cool
3048.48|3.3|um
3049.2|4.08|so this one is uh called protein LM
3051.78|4.86|Again by a few other folks at Google
3053.28|5.52|research and what this does is uh model
3056.64|3.3|based uh natural language protein
3058.8|3.84|annotation
3059.94|4.919|and why this problem is important is
3062.64|6.3|because the protein information is in
3064.859|5.46|very high demand uh so over 50 of all
3068.94|3.48|known proteins that have been sequenced
3070.319|3.421|we don't actually know what they do so
3072.42|2.939|it's important that we're able to like
3073.74|4.26|decipher that to some degree at least
3075.359|4.441|and then the second thing is we may want
3078.0|3.059|to for example find protein sequences
3079.8|3.12|with given functions and this is
3081.059|3.661|particularly important in the crisprit I
3082.92|3.899|mean and so if you can train
3084.72|3.899|bi-directional models that can do this
3086.819|4.141|um I think that'll be incredibly helpful
3088.619|4.2|and
3090.96|4.02|and the reason I say this again is that
3092.819|4.981|uh that the unipro database that has
3094.98|4.44|over uh uh that is I think millions of
3097.8|3.48|researchers worldwide using it today and
3099.42|4.08|so getting this information populated in
3101.28|3.96|that database would be incredibly uh
3103.5|3.14|useful and accelerate a lot of research
3105.24|4.26|in the space
3106.64|4.9|and so the European bioinformatics
3109.5|4.859|Institute they have curated this free
3111.54|4.44|text data about proteins uh and so
3114.359|4.381|basically you can use this protein
3115.98|5.28|record to like train these models and so
3118.74|4.56|what you want to do is you want to maybe
3121.26|3.359|learn to directly map from amino acid
3123.3|4.14|sequences to natural language
3124.619|4.44|descriptions of them uh and this problem
3127.44|3.06|is not too different from an image
3129.059|3.901|captioning problem where instead of
3130.5|3.96|having a sequence of pixels
3132.96|3.48|um I don't know if sequence is right but
3134.46|3.119|again if you have pixels uh instead you
3136.44|2.94|have a sequence of Harmon assets and
3137.579|4.02|they can range a number from you know 2
3139.38|5.28|to 40K and then what you want to
3141.599|4.621|generate out is a protein uh description
3144.66|3.3|of the protein
3146.22|5.339|and in this paper the way they do this
3147.96|6.24|is they train a T5 model on protein
3151.559|3.78|sequence annotation tests so the the
3154.2|3.659|tasks are set up in a bunch of different
3155.339|5.161|ways and the supervised data comes from
3157.859|4.2|a bunch of different sources in the
3160.5|4.26|protein record that they have and this
3162.059|4.321|model is an encoded equal to T5 model
3164.76|3.9|um so it's a very cool application and
3166.38|4.439|the results are that out of the 56
3168.66|3.659|million proteins in that uniprot
3170.819|4.141|database that were previously
3172.319|4.561|uncharacterized uh 49 million of them
3174.96|4.74|now have Associated textual descriptions
3176.88|3.479|so we now have a handle on what they do
3179.7|2.22|um
3180.359|2.76|and so that's really cool and then the
3181.92|3.0|other one I think which is probably even
3183.119|3.841|more interesting is now you can run
3184.92|4.38|queries like find me a smaller version
3186.96|3.96|of this crispr cas9 protein so that it
3189.3|2.94|can Target certain tissues better and
3190.92|2.82|now the model can you know come back
3192.24|4.319|with sequences and so I think this is
3193.74|3.96|again going to be incredibly useful and
3196.559|2.341|um you want to accelerate a lot of
3197.7|2.46|research in this space already there's a
3198.9|3.86|lot of momentum I think these models are
3200.16|2.6|going to further help
3203.099|3.541|uh
3204.599|3.541|so that was on proteins the last class
3206.64|3.9|of applications that I want to cover is
3208.14|4.679|on the genomics side
3210.54|4.74|um again the first paper over here uh
3212.819|5.821|was uh some work last year from our
3215.28|6.0|geometry at Google uh which is building
3218.64|4.02|Gap aware sequence Transformers for
3221.28|3.38|sequence correction
3222.66|4.62|so this model is called Deep consensus
3224.66|4.56|and so what role does this model play
3227.28|5.4|and why does it matter
3229.22|5.5|so if you look at the sequencing data
3232.68|4.62|life cycle what you do is you go from
3234.72|4.26|basically atoms to bits and so you have
3237.3|5.4|this physical specimen which hopefully
3238.98|5.28|has some DNA in it and you
3242.7|3.96|put it through a sequencing machine such
3244.26|4.68|as black bio and that comes out with the
3246.66|5.52|raw data and that raw data gets mapped
3248.94|5.04|to a reference genome uh and then
3252.18|3.419|sometimes there might be diffs between
3253.98|2.879|an individual and the reference genome
3255.599|2.52|and that can be corrected through this
3256.859|2.821|model called Deep variant that was
3258.119|3.72|introduced by our team a few years back
3259.68|4.74|and that's open source and then once you
3261.839|3.901|have this uh sequence you can then use
3264.42|4.199|it for a bunch of different analysis
3265.74|5.94|such as uh you know ancestry or like
3268.619|6.301|just you know basic biomedical research
3271.68|5.58|uh so where deep variant fits in is it
3274.92|4.62|actually makes the raw DNA reach that
3277.26|5.28|comes out from the back biosequencer uh
3279.54|5.64|it tries to make it more accurate uh and
3282.54|5.7|uh so how the bio sequencer actually
3285.18|6.3|works is it uses this circular uh
3288.24|5.28|consensus sequencing algorithm where the
3291.48|3.72|DNA molecule is like you know red
3293.52|4.38|several times and it produces multiple
3295.2|3.54|different sub reads and these subreits
3297.9|2.699|are
3298.74|3.24|they do contain some errors and so
3300.599|4.441|they're finally like assembled together
3301.98|5.639|and so what deep variant tries to do is
3305.04|4.14|it tries to improve on the errors over
3307.619|3.061|here basically that comes out from just
3309.18|3.659|this circular consensus sequencing
3310.68|4.679|algorithm
3312.839|4.02|and so how does this model work uh as I
3315.359|4.621|said the basic task for deep consensus
3316.859|5.341|is to use the cacs data and the sub
3319.98|4.379|reads associated with them to generate a
3322.2|3.48|corrected sequence and so in this
3324.359|2.881|example when we run through the model
3325.68|4.2|what we see is that while the CCS
3327.24|4.619|identity was at like 95.7 The Deep
3329.88|3.959|consensus prediction identity was at 100
3331.859|3.841|so it's a fairly simple task where
3333.839|3.961|you're trying to like reduce errors that
3335.7|3.3|come out from the back bio with the CCS
3337.8|3.18|algorithm
3339.0|4.8|and so the very natural question is
3340.98|5.76|where do these labels come from
3343.8|4.74|um so each CCS sequence that you have
3346.74|4.319|that is aligned to a high quality
3348.54|5.579|assembly uh and this high quality
3351.059|5.941|assembly is created by having many CCs
3354.119|5.821|uh reads uh stitched together and so
3357.0|5.94|that ends up having fewer errors and so
3359.94|5.76|you can then try to use that high
3362.94|4.919|quality stitched assembly and map that
3365.7|5.1|back to the CCA trade for a given block
3367.859|5.341|and use that as that label so uh that
3370.8|3.66|results in more you know like stronger
3373.2|2.52|ground truth and you can use that to
3374.46|3.659|train the model to improve the accuracy
3375.72|4.859|further and so this is what the model is
3378.119|5.041|trained on and so the model looks like
3380.579|6.0|this it's a Transformer architecture uh
3383.16|5.04|it takes these sub reads and this uh CCS
3386.579|3.601|read as well and it has a bunch of
3388.2|3.899|additional context features that come in
3390.18|4.139|from this uh the sequencer itself the
3392.099|3.781|instrument sequencing instrument as well
3394.319|4.26|um and these are all fed into the
3395.88|4.26|Transformer model uh it produces a
3398.579|3.0|Polish segment and these segments are
3400.14|3.86|then like just together to produce the
3401.579|5.04|final polished read over here
3404.0|5.319|uh one thing I will point out over here
3406.619|5.041|is that in order to train this model you
3409.319|4.621|can't use a cross entropy loss and this
3411.66|4.98|is because uh
3413.94|4.919|you know if you insert you often have
3416.64|4.199|insertions in DNA sequences and so that
3418.859|3.601|can when you use a cross entropy loss
3420.839|3.181|like really throw off the model even
3422.46|3.659|like a single error as you can see over
3424.02|4.14|here can propagate throughout the
3426.119|3.361|sequence and make it really worse so
3428.16|4.26|what you need is a special kind of
3429.48|4.5|alignment Clause based on a distance uh
3432.42|2.699|that can really capture this error much
3433.98|4.02|much better
3435.119|4.561|and so making this alignment loss work
3438.0|3.059|on you know tpus and making it
3439.68|3.179|differentiable is I think the real meat
3441.059|2.76|of this paper and so again go back to
3442.859|3.72|the paper if you're interested in that
3443.819|4.5|kind of topic I think that's really cool
3446.579|4.321|um but at a very high level uh how well
3448.319|3.901|does this model work so if you look at
3450.9|3.9|the final output you have the read name
3452.22|3.899|you have the base predictions and also
3454.8|2.66|the predicted quality which can be
3456.119|3.781|thought of as a confidence score and
3457.46|3.82|these base predictions are often quite
3459.9|2.64|long and so you can see that continuous
3461.28|4.14|off screen because it's like you know
3462.54|5.34|10K electronic bases long over here and
3465.42|4.699|when you look at the Quality it improved
3467.88|4.14|quite a bit over the vanilla CCS
3470.119|3.881|algorithm over here the per read
3472.02|5.18|accuracy over here improves quite a bit
3474.0|5.52|uh and so you may ask like what is the
3477.2|5.8|real world impact of this kind of model
3479.52|5.16|right uh so the answer is this model is
3483.0|3.78|already being used in the real world so
3484.68|3.78|at Stanford in the genomics team by Dr
3486.78|4.319|Ashley and a few others there was this
3488.46|4.26|recent uh Ultra rapid nanopore genome
3491.099|3.121|sequencing paper where they set a world
3492.72|3.48|record for the fastest genome sequencing
3494.22|3.599|and this deep consensus Transformer
3496.2|4.08|architecture was used in that assembly
3497.819|4.621|sequence and so in this particular study
3500.28|4.86|they were able to very quickly diagnose
3502.44|4.919|that Matthew over here had a heart
3505.14|3.479|condition due to genetic reasons and so
3507.359|4.141|they were very quickly able to like put
3508.619|4.561|Matthew on the patient's bonus list over
3511.5|2.96|here so that's the kind of real world
3513.18|3.72|impact you can have with these
3514.46|4.98|biomedical transform models and AI
3516.9|2.54|systems in general
3519.96|6.0|and uh very quickly the last uh paper
3523.859|4.801|that I want to talk about is this paper
3525.96|5.159|from deepmind on effective gene
3528.66|4.74|expression prediction from sequences by
3531.119|5.161|integrating long-range interactions this
3533.4|4.919|was published in nature methods
3536.28|3.72|and the motivation for this work is
3538.319|3.24|again that since the Human Genome
3540.0|4.5|Project there have been thousands of
3541.559|6.661|genome-wide Association study hits where
3544.5|5.16|the goal is to you know map uh genetic
3548.22|3.96|variants to different kind of disease
3549.66|4.62|phenotypes but a lot of this involves
3552.18|3.84|experimentation and experimentation like
3554.28|2.94|real world experimentation takes a lot
3556.02|2.94|of time and so if you can like do that
3557.22|4.56|with machine learning models that's
3558.96|5.52|really really great and so that's what
3561.78|4.92|they're set up to do in this scraper and
3564.48|4.8|so if you look at the gene itself there
3566.7|4.5|are like you know 10 of the gene are
3569.28|4.68|going to be like coding variants and
3571.2|4.56|these influence protein function uh and
3573.96|3.54|then the way they can cause diseases is
3575.76|5.16|by disrupting the structure of proteins
3577.5|5.579|that are generated or by affecting the
3580.92|3.36|protein protein interactions uh the good
3583.079|2.76|part about these coding variants are
3584.28|4.2|they tend to be closer to the Gene and
3585.839|4.621|so they're easier to interpret uh on the
3588.48|5.04|other hand the the 90 of the gene is
3590.46|5.159|like non-coding variants and the way
3593.52|3.62|they work is they influence protein
3595.619|4.68|expression so they are more like
3597.14|5.38|regulatory uh sequences
3600.299|4.5|um and so the way they can lead to
3602.52|5.22|diseases if they have any variance is by
3604.799|3.961|this disrupting the transcription uh of
3607.74|3.66|proteins
3608.76|4.98|and given that these non-coding variants
3611.4|3.899|can be very very far away from the Gene
3613.74|3.42|and the coding variants it's very
3615.299|3.421|difficult to interpret them and so the
3617.16|3.3|question is can we train transfer models
3618.72|3.839|that can predict uh the influence of
3620.46|4.8|these non-coding variants and so that is
3622.559|4.381|the task over here and so this is a
3625.26|5.579|visualization again
3626.94|6.72|um so the paper again looks at uh the
3630.839|4.561|the it focuses on transcription which is
3633.66|4.5|the first step in terms of converting
3635.4|5.399|DNA into RNA and the way this is done is
3638.16|4.439|you have a RNA polymerase which gets
3640.799|3.78|recruited uh at the beginning of the
3642.599|4.441|gene by these proteins called
3644.579|3.661|transcription factors and these
3647.04|3.18|transcription factors have a binding
3648.24|3.839|side which correspond to these promoters
3650.22|3.54|which are quite close to the gene but
3652.079|3.121|then you also have these enhancers which
3653.76|3.96|can be like very very far away from
3655.2|5.159|these promoters uh in terms of the
3657.72|5.639|linear space uh also influencing this
3660.359|4.321|transcription uh and you may ask how can
3663.359|3.421|such uh
3664.68|3.78|how can these enhancers influence the
3666.78|3.12|activity over here this is because while
3668.46|4.8|they may be far away in the linear space
3669.9|4.74|when the the sequence folds and in the
3673.26|2.94|3D structure they will end up being
3674.64|2.52|quite close to each other and so that
3676.2|2.58|they can completely affect the
3677.16|3.84|transcription process over here
3678.78|3.6|so it's a very high level overview of
3681.0|4.38|what's happening over here and in terms
3682.38|4.679|of the biology uh and so the question is
3685.38|3.12|if there are any variants in these
3687.059|4.321|non-coding variants
3688.5|4.26|um and uh in these enhances uh they may
3691.38|3.419|like disrupt the transcription Factor
3692.76|3.9|binding and this can in turn lead to
3694.799|3.721|like you know proteins and then finally
3696.66|3.48|to diseases right so we want to be able
3698.52|3.539|to predict that based on the DNA
3700.14|4.74|sequences that have been generated
3702.059|3.841|so the problem is kind of quite
3704.88|3.179|straightforward it's a supervised
3705.9|3.719|learning problem uh the the setup is
3708.059|4.5|predict experimental data from these
3709.619|4.98|gnac sequences and this can take many
3712.559|3.3|different forms the primary one is gene
3714.599|3.48|expression over here but then there are
3715.859|3.96|also other tasks such as DNA
3718.079|3.181|accessibility uh histone modifications
3719.819|4.161|and transcription effect and binding and
3721.26|2.72|so on and so forth
3724.2|4.379|um so as you can imagine the Baseline
3726.48|5.7|model for this task uh for many years
3728.579|4.861|was the CNN model and as you stacked up
3732.18|2.52|a little you know differential layers
3733.44|2.82|you can increase the receptive field but
3734.7|3.48|there's a limit to that
3736.26|5.039|um so in this work what they showed was
3738.18|4.98|uh you can use Transformers instead and
3741.299|4.741|do better modeling of these long-range
3743.16|4.5|interactions uh so the final model is
3746.04|5.1|called and former which is a combination
3747.66|5.34|of this enhancer and Transformer and so
3751.14|3.479|if you look at the model itself it has a
3753.0|2.88|few CNN layers at the beginning but then
3754.619|3.121|it has a bunch of Transformer blocks
3755.88|4.32|that are stacked together
3757.74|5.04|um and the input is uh you know 200 KV
3760.2|3.96|DNA sequences uh and there are
3762.78|3.36|approximately 30 examples that have been
3764.16|4.5|trained and the output is like genomic
3766.14|4.02|tracks of this RNA expression with and
3768.66|5.28|they have organism specific head so one
3770.16|6.0|for humans and one for uh Mouse
3773.94|3.84|um and finally one key detail is that
3776.16|2.88|relative position encodings that were
3777.78|2.88|used in this model were actually very
3779.04|3.6|key and these relative position
3780.66|4.86|encodings for modeling this power law of
3782.64|3.84|interactions uh and as a result of you
3785.52|2.579|know using this related position
3786.48|3.24|encodings with the Transformer block
3788.099|4.381|architecture they were now able to model
3789.72|3.48|like interactions over 100 K base pairs
3792.48|2.879|away
3793.2|4.919|and so you see that in the results over
3795.359|4.801|here uh so you have the experimental
3798.119|3.96|data in green and you can see the CNN
3800.16|3.54|Baseline over here and you see that as
3802.079|4.801|soon as you go far away
3803.7|5.22|um uh you see that like the more the CN
3806.88|5.16|model is no longer like able to like
3808.92|4.98|capture these Gene Expressions uh but
3812.04|3.539|you can see that the enhancer model is
3813.9|3.3|now able to like pick them up so you can
3815.579|3.0|see that like as the model goes far away
3817.2|4.02|the enhancer model is able to capture
3818.579|5.22|this whereas the CNN model is no longer
3821.22|5.639|able to capture this
3823.799|4.201|and finally one uh I think very
3826.859|2.7|interesting experiment that they had in
3828.0|3.24|the paper was they were also able to
3829.559|4.681|like you know predict promote or
3831.24|4.74|enhancer uh inferences and that
3834.24|3.48|prediction was actually on par with
3835.98|3.359|experimented data so this suggests that
3837.72|3.06|using this machine learning model we can
3839.339|2.941|sidestep a lot of these wet lab
3840.78|4.44|experiments and get like key details
3842.28|6.66|which could be super useful
3845.22|4.98|um so yeah so very quickly uh I'm sorry
3848.94|3.899|I feel like cram fruit proteins and
3850.2|4.139|genomics applications over here uh but I
3852.839|3.24|think what you would see is that overall
3854.339|3.661|when you look at clinical proteins and
3856.079|3.181|genomic applications uh we see that
3858.0|3.839|Transformers have incredible potential
3859.26|3.66|potential in biomedicine uh and with
3861.839|2.341|clinical applications I think the
3862.92|4.139|challenges are perhaps more centered
3864.18|4.139|around data and evaluation uh but on the
3867.059|2.581|proteins and genomics side I think there
3868.319|2.821|are some extremely interesting
3869.64|4.32|opportunities to innovate on the
3871.14|4.32|architecture and finally as I said there
3873.96|3.0|are incredible bi-directional learning
3875.46|2.94|opportunities I think the problem of you
3876.96|3.599|know modeling long-range interactions
3878.4|4.14|that's useful Beyond proteins Beyond
3880.559|3.841|genomics I think it's useful in genomics
3882.54|3.48|and so I think any architecture
3884.4|2.76|improvement over here can Inspire wider
3886.02|3.72|progress in AI so I think that's a big
3887.16|6.62|reason to work on this
3889.74|4.04|um any questions so far
3894.059|3.06|sorry I covered a lot of ground over
3895.619|2.581|here uh apologies for that but I think
3897.119|3.661|these are super cool papers and you
3898.2|4.919|should go back and read them
3900.78|3.72|um so very finally I want to maybe spend
3903.119|5.041|a couple of minutes touching upon how I
3904.5|5.22|see the future of biomedical AI evolving
3908.16|4.26|um overall I believe it's not a question
3909.72|4.26|of like if AI will transform biomedicine
3912.42|3.36|I think it's rather a question of when
3913.98|3.24|and how
3915.78|4.559|um and I think the very specific thesis
3917.22|4.5|I have over here is given the nature of
3920.339|2.881|biomedical data and how multimodal
3921.72|2.879|nature and with all the progress and
3923.22|3.0|Transformers self supports learning
3924.599|3.841|large language models I think we have an
3926.22|3.48|incredibly powerful process like
3928.44|3.179|framework to like Leverage all the
3929.7|4.74|solutions at scale and like truly build
3931.619|5.161|foundational medical AI models
3934.44|4.08|um so I think that is incredibly
3936.78|3.36|exciting
3938.52|4.02|and uh
3940.14|4.38|so I'm not I think it's you've already
3942.54|3.24|been over here for far too long so I'm
3944.52|3.36|not going to ask you to recognize these
3945.78|3.6|people but they're actually famous
3947.88|4.32|Physicians scientists some of them went
3949.38|4.679|on to Nobel prizes and so
3952.2|3.3|I think what I want to say over here is
3954.059|2.581|there's no reason for a scientist to be
3955.5|3.119|different from a physician they can be
3956.64|3.36|combined together and that's what we I
3958.619|2.521|also want to like convey with our AI
3960.0|2.64|systems as well we don't have to like
3961.14|2.699|separate clinical applications and you
3962.64|2.939|know biological applications I think
3963.839|3.121|when we combine them together we are
3965.579|2.881|going to discover a lot of new insights
3966.96|3.78|and I think that's going to accelerate
3968.46|3.78|biomedical research and internally to
3970.74|3.18|new discoveries and which is kind of
3972.24|2.64|like you know be used to eradicate
3973.92|2.82|diseases
3974.88|5.479|um Advanced human health span and
3976.74|3.619|generally Drive human potential forward
3982.68|4.139|uh sure I think the rightmost one is
3985.2|5.339|Alexander Fleming
3986.819|6.121|um and then Jonas salak and then
3990.539|4.141|so Fleming is penicillin salt gas polio
3992.94|4.04|and Ehrlich was a bunch of different
3994.68|2.3|stuff
4000.079|5.641|and so maybe I'll ask this question to
4002.839|5.28|all of you which field of AI do you
4005.72|4.859|think will which field do you think AI
4008.119|5.781|will win the first Nobel Prize in
4010.579|3.321|uh you don't have to answer just think
4015.38|2.12|okay
4021.76|4.079|so economics is not available
4061.359|4.361|or something
4063.2|4.02|that's right um so I also feel the same
4065.72|2.579|way and I hope the overwhelming majority
4067.22|3.66|of you also think that it's going to be
4068.299|5.341|in medicine and uh I'm going to end on
4070.88|4.739|that note uh huge thank you to all my
4073.64|3.3|collaborators and teammates for most
4075.619|2.281|importantly allowing me to like steel
4076.94|2.639|slides
4077.9|3.24|um and then also thank you to all of you
4079.579|4.881|for like patiently listening over here
4081.14|3.32|hopefully this was helpful