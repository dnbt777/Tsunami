start_time|end_time|text
1.52|2.62| Yeah, regarding the course material and information, we
4.14|3.42| will be using canvas in the semester. The reason is really
7.56|3.24| that it makes things easier for me and for you, because
10.8|4.92| everything will be in one place. So that, yeah, with that, I
15.72|4.52| mean, announcements and your grades, and also your Piazza, I
20.24|4.12| will say a few more words about that. So yeah, I think having
24.36|2.64| everything in one place will make things easier. Yeah, of
27.0|2.92| course, we will also be using other technologies like GitHub.
30.16|4.76| However, I will then post links to that on canvas. So you'd
34.92|2.4| never have to really go out there and search for things by
37.32|4.68| yourself on different places. Everything will be here on the
42.0|5.32| modules on canvas. So what I'm showing you here is a screenshot
47.72|3.04| just of some things you've probably already seen. So here
50.76|3.36| was some optional pre course preparation materials that I
54.12|4.12| shared during the winter break. For those of you who may have
58.24|3.56| not used Python before, but have some programming language
61.92|4.64| backgrounds. So yeah, as a requirement for this class, you
66.56|2.92| should have taken a programming class, it doesn't have to be
69.48|3.88| Python. However, we will be using Python in this course. Of
73.36|3.16| course, we don't have to be expert programmers in Python for
76.52|3.1| this class, we will only use very basic features in Python,
79.84|4.0| but it will be immensely helpful for you. If you learn a little
83.84|4.58| bit about how Python works, and I shared some resources for you
88.42|4.04| here, it shouldn't take that much effort. It's really only
92.46|3.46| the basics. And I think it will make your life in this class
95.96|3.8| easier. Also, we won't be using Python right away in the first
99.76|3.36| few weeks. I think we will be probably starting in week three
103.12|3.52| to use Python. So in that way, there's no stress to do it like
106.64|2.64| today. But it would be good maybe in the next couple of days
109.28|2.88| if you don't have any Python experience to look over these
112.16|4.56| resources. Then I also posted a lot of information about the
116.72|4.12| syllabus. A couple of days ago, I don't want to really go over
120.88|3.44| everything here. I think it's maybe more efficient if you just
124.32|3.2| read through what I've posted there. It's really just the
127.52|4.26| topics that I already discussed in a few minutes ago, that we
131.78|2.28| are going to cover a little bit about this course, you probably
134.06|2.26| already know that because otherwise you wouldn't have
136.32|5.42| enrolled. Then yes, some basic comments on where the
141.74|3.74| information for this course is located mainly on canvas, some
145.48|3.82| other resources like optional textbooks that may be helpful to
149.3|3.58| you. And also how we communicate in this course, I will also say
152.88|3.2| a little bit more about that in the next couple of slides. And
156.08|4.88| then your course logistics, some expectations like how I will
160.96|4.56| deliver content and how you are expected to participate. So
165.6|4.08| content wise, I will be uploading videos on Tuesdays and
169.68|3.8| Thursdays. Why Tuesdays and Thursdays on it was usually
173.48|2.96| what I have done and in person when there was a regular
176.44|3.92| semester. And also, it's kind of easier for me because when the
180.36|3.4| week starts on Monday, I will start recording the videos for
183.76|4.96| Tuesday. And then on Tuesday, I will catch up with emails and
188.72|3.16| work. And then on Wednesday, I will be recording the back
191.88|2.82| lectures for Thursday and things like that. So it's also a good
194.7|4.1| rhythm for me. And then there are some other resources and
198.8|3.84| useful material that I posted here. Some information about
202.64|3.72| grading, I will also talk about this in a few slides. And also
206.36|3.04| about the class project and the exam. And then also importantly,
209.4|3.28| the rules, rights and responsibilities that you have
212.72|3.84| and should know. And then also a little bit about the COVID
216.56|4.44| context, also just where you can info find information about
221.0|4.32| COVID and how it affects campus. So I'm just linking the campus
225.32|3.64| guidelines. You should also maybe take a look at that if you
228.96|4.48| are not familiar with that yet. All right. So regarding the
233.44|3.28| weekly content, like I mentioned, I will be uploading
236.72|4.16| videos on Tuesdays and Thursdays. Or let's say I will
241.24|3.12| upload the Monday night and Wednesday night such that they
244.36|3.4| are available on Tuesday mornings and Thursday mornings.
247.84|4.64| So that's to the best of my ability. That's my my plan here
252.48|5.8| for this semester. So a typical week may then look like this. So
258.28|3.92| here is it's not uploaded yet, when I'm recording it. But when
262.24|3.32| you are seeing this video, it's probably already uploaded. So
265.56|3.44| what I'm showing you here is how a typical week would look like.
269.8|4.16| So here's a link to the office hours, we will have, we will be
273.96|4.44| having office hours via zoom, the TA and me. So I will have my
278.4|4.28| office hours on Tuesdays from six to seven and the TA from seven
282.72|4.08| to 8pm, I think. So we both have office hours in the evening. And
286.8|4.04| that is because I think it's, it's easier for people who are
291.2|4.0| in different time zones. For example, some people I know are
295.2|4.84| in China, and then it would be, I think 6pm here would be 9am in
300.04|3.16| the morning there or 8am. So I think that's like a more
303.2|3.44| reasonable time because last semester, we had office hours
306.64|3.8| like more in the afternoon, and then some people had to have
310.44|2.44| their alarm clock at 3am in the morning to join the office
312.88|4.32| hours, or we always had to find additional time slots. And I
317.2|2.56| think having this office hours slot in the evening might be
319.76|3.04| more convenient this time. I think 6pm is also maybe
322.8|3.4| reasonable for people who are in medicine. So in that way, it's
326.2|4.84| like a good, I think, sweet spot. Alright, and then, like I
331.04|2.48| said, I will be uploading content on Tuesdays and
333.52|3.68| Thursdays. So there will be a page, a canvas page with all
337.2|5.32| the videos embedded there. And the same thing for Thursday. And
342.52|3.44| I will also post some additional material like extra reading
345.96|3.84| material there, or I will link it there. So if you want to have
349.8|2.8| some more information beyond, let's say just the videos, I
352.6|3.0| will also try to post some interesting papers or additional
355.6|4.92| reading material in these pages related to the lecture. And then
360.52|2.88| at the end of the week, I'm planning to make every week a
363.4|4.24| self assessment quiz. So this quiz will be three to five
367.68|3.2| simple multiple choice questions. It's just like, um,
370.92|2.88| yeah, so to help you stay on track, there will be a few
373.8|4.0| points for this quiz. So of course, you should do the quiz
377.8|2.8| because it will be counting towards your final grade. It
380.6|3.24| won't be like heavily weighted, it's only a small number of
383.84|2.96| points for these quizzes. But it's I think helping you or will
386.8|4.72| help you to keep on track because you have to watch these
391.52|5.0| materials in order to do the quiz. I mean, you can do it
396.52|3.16| without watching the videos. But then I think you you have to
399.68|3.24| guess really, because the questions will be related to the
402.92|3.64| video content. Of course, the I will post the quiz at the end
406.56|2.32| of the week, but it will not be due at the same day, it will be
408.88|3.88| due one week later. So if you let's say on don't have
413.28|3.8| completed videos by the end of the week, you still can watch
417.08|3.0| them on a video on the weekend or the beginning of the next
420.08|4.64| week. So we'll have like seven, approximately seven days after
424.72|3.84| the videos have been posted to complete the self assessment
428.56|3.96| quiz. I think that's like also, yeah, I will think this will
432.52|6.16| help you to keep on track and not, let's say delay going
438.68|3.24| through the content too much and help you to stay on track in
441.92|3.88| this class. Alright, so the grading, I think that's probably
445.8|5.92| some question or something you are curious about. So how I
451.72|2.64| decided to do things this semester is that there will be
455.08|4.04| 30% of the grade will be from problem sets, that's homeworks
459.12|3.28| and these self assessment quizzes. So regarding the
462.4|3.44| homeworks, I don't know exactly how many homeworks there will
465.84|4.76| be, I will be making them every two weeks, approximately, and
470.6|2.8| there will be a new homework. These are a little bit longer
473.4|3.08| than the quizzes, and they won't be multiple choice, they will be
476.48|6.24| involving usually some free form answer or some slight coding. So
482.72|3.24| in that way, there will be approximately five homeworks
485.96|2.6| this semester, a little bit more, maybe. So five, I would
488.56|3.88| say five to seven. And there will be the self assessment
492.44|4.36| quiz quiz every week. And then this will be 30% of your grade,
497.08|5.4| 20% of your grade will be from the midterm exam. I posted the
502.48|3.72| date, I think in the syllabus for the midterm exam, I will
507.16|3.4| send another announcement about that. I just forgot the date
510.56|4.32| right now. So I can't recall it on top of my head. But it was
514.88|3.56| more like later, I think, sometime in March, I think, so
518.44|4.6| don't worry about it yet. So 20% will be the midterm exam, which
523.04|5.44| will be online on canvas. So and then 50% will be the class
528.48|4.04| project. So I think this is the most fun part of the class,
532.84|5.08| because this is something where you get to be creative. So first
537.96|4.32| you get to propose a class project topic that has to be
542.28|2.76| related to machine learning or deep, I mean, deep learning, of
545.04|4.08| course. So it will be related to deep learning. And you will be
549.12|5.2| working in teams with three students in total, so three
554.32|6.64| students per team. And we will wait a few days, or let's say,
560.96|5.76| maybe a week or two, until I ask you to find team members, because
567.04|2.2| there are students in the beginning who are still on the
569.24|3.64| waitlist, and some students may change their classes. So we will
572.88|4.8| wait a few days or weeks until things have settled. So then we
577.68|3.68| will form student teams of consisting of three students
581.36|3.24| each. And then with your team, you will be thinking or
584.6|4.32| brainstorming deep learning related project, I will post
588.94|4.3| data sets that you may consider or data set resources, and
593.24|4.14| websites and also project ideas. And I will also post some
597.38|4.5| examples from previous semesters so that you can get an idea of
601.92|4.32| what roughly is expected. I don't want to do this right now,
606.28|3.04| because there are so many things going on right now. But in the
609.32|3.64| next couple of days, I will share more information about
612.96|3.26| that. So don't worry about it. And it won't be due until I
616.22|3.62| would say also like March. So and this proposal, what what's
619.84|3.72| the goal of this proposal, this is a really a two page report.
624.08|2.72| So again, I will share more information later, but it will
626.8|6.08| be a two page report, where you let me know what you are
632.88|2.56| interested in working on. And then I can give you some
635.44|3.24| feedback to let you know whether this is a good idea or not, or
638.68|3.24| maybe also to give you some more tips regarding your projects and
642.32|5.52| supply you with resources or additional ideas. And so the
647.84|4.16| grading is, it's only 5% of the total grade. So in that way,
652.12|5.12| it's more about making sure that you have a good idea for the
657.24|3.56| rest of the semester that you can work on it. And yeah, and
660.8|2.84| then at the end of the semester, there will be a project
663.64|4.12| presentation. That's an oral presentation, and a project
667.76|3.72| report. So of course, the semester is virtual, so it will
671.48|4.86| be recorded. So you will be recording a video, a short eight
676.34|6.04| to 10 minute presentation, and that will be shared with other
682.38|2.46| students in this class. So we will be all watching the
684.84|4.88| presentations. And there will also be a project report then
689.76|3.04| also at the end of the semester. And the project report, this
692.8|5.84| will be a eight page written report in the form of it will
698.64|2.68| look like a conference paper, I will give you a template for
701.32|6.48| that. And this is really where you would write up should be
707.84|2.88| style conference paper style, this will be where you will be
710.72|3.36| writing up your project more formally in the form of a paper.
714.2|2.12| And I really think this will give you some real world
716.32|4.24| experience on with working on a deep learning project, how you
720.56|2.9| communicate it also in the presentation, and then also how
723.46|3.16| you write it up, for example, also later on, if you're
726.62|5.1| interested in academic path, where you publish papers, that
731.72|3.84| might be a great exercise to if you have not done that already,
735.68|3.42| like work on papers, but also in industry, a lot of people in
739.1|2.88| deep learning are publishing papers nowadays. So either way,
742.18|2.8| I think this is a very useful exercise for you. And it's also
744.98|2.72| great for your CV, you can optionally share your project,
747.7|3.48| for example, on GitHub, if you like. And then if you apply for
751.18|3.76| an internship, you can show that you have worked on a creative
754.94|4.4| individual project, I think that's always a good idea. Okay,
759.34|3.44| but again, like I said, I will share more about that. One
762.78|4.08| little aspect I wanted to say is also there will be a peer review
766.86|2.44| stage. That is something I've not done in previous
769.3|2.84| semesters. And I thought it might be also a good idea. That
772.14|5.2| is something where each student will be reviewing three other
777.34|5.68| students, reports and project presentations and also give
783.02|3.76| feedback basically. So in that way, I think that might be also
787.26|2.4| a cool thing to do like providing feedback on other
789.86|4.76| students, presentations and reports. Alright, of course, I
794.62|2.6| will also be providing feedback, but this is like for you on
797.5|3.86| among each other. So I think that's also nice. Yeah,
801.36|5.26| regarding the communication in this course, so how are we, how
806.62|2.68| are you going to ask questions? And how are we having
809.3|4.04| discussions? Yeah, first of all, we will have the office hours
814.14|4.2| via zoom. So that will be a face to face live office hours. And
818.34|4.64| in addition to that, we will be using Canvas for the asynchronous
823.02|4.28| communication. So Piazza is like online forum, which is in
827.3|3.28| Canvas, or only the students in this class have access to it.
830.98|5.12| And you can post questions either on showing like your name
836.1|3.86| to the other students or also anonymously if you prefer. So
839.96|4.16| the name if you post that will be on only visible, let's say to
844.12|3.7| me if you post anonymously, but you are of course encouraged to
847.82|4.28| also post just generally with showing your name. So if you
852.1|2.48| want to find, for example, team members and things like that,
854.58|3.0| you can also use Piazza. And this is really like for
857.9|3.6| questions about this course about the lecture contents and
862.38|3.0| everything related to this course really. And what's nice
865.38|4.96| about it is, I think, is that everything will be in one place.
870.66|2.84| And on Piazza, I can also see which questions I have answered
873.5|3.2| and which I have not answered. And I really prefer this over
876.7|3.0| email, because you know, a lot of people are sending me emails
879.94|4.64| who are not in this class, like colleagues and paper reviews
884.58|4.12| and everything. And sometimes it's more difficult to catch up
888.7|3.32| with email every day. So if you have a question, it's easier for
892.02|2.68| me just to go to Piazza and see all the questions related to
894.7|3.64| this class. And I can, I think, answer them more quickly. And
898.36|3.3| there's also less danger that I miss a question compared to
901.66|3.44| emails, where emails always like this always too much email, and
905.1|2.76| it's always easy to overlook something. So on Piazza, it
907.86|3.16| will be more organized. So you can also send me private
911.02|3.6| questions on Piazza, there's an option that only I will be able
914.62|3.64| to see the question. So if you have some private question, like,
918.5|4.0| I don't know, maybe you have a doctor's appointment and some
922.5|4.18| issues came up and you can't complete homework for some
926.68|3.1| reason. That would be also a private option where you can ask
929.78|6.48| me a private question on Piazza. So that's also a good place to
936.26|2.04| ask private questions. So where you don't have to worry that
938.3|3.68| other people see that. Anyway, so yeah, we will be using then
941.98|4.16| Piazza and zoom for the communication this class, I hope
946.78|3.32| this will work well, we can adopt if we need additional
950.1|2.72| resources. So for example, for the office hours, we will be
952.82|3.32| having these links. But if there's a reason, you never can
956.14|3.2| attend these office hours, because you have another class
959.34|4.48| during these times, we can also find optional additional dates.
965.74|3.92| Yeah, important. One last important thing is, I would
969.66|4.04| really hardly strongly recommend that you enable the notifications
973.7|2.62| on canvas. I know it can be maybe a little bit annoying. But
976.32|2.88| this way, you get a notification via email, if there's some new
979.2|4.7| content, because yeah, this way, you don't have to always refresh
983.9|1.92| the page, if there's some new content, you will get an
985.86|4.16| automated, automatic, automatic message, for example, if
990.02|3.48| there's a new deadline, or new content uploaded and things like
993.5|4.24| that. So I recommend activating these notifications. So how you
997.74|4.44| do that is you go to this little symbol here. And then you go to
1002.18|3.4| notifications. And then there should be these preferences
1005.58|4.68| where you can just check these. Alright, so that is all I wanted
1010.26|4.28| to say about the course. If you have questions, yeah, we will
1015.06|3.6| have office hours this week. So you can ask me that in person,
1018.78|3.4| face to face, or you can just post a question on Piazza.
1022.54|2.72| Honestly, what I also like really about Piazza is if you
1025.26|3.04| have a general question, and you posted there, then other students
1028.3|2.6| will see it as well. And maybe other students had the same
1030.9|2.96| question. So this information will also be shared with other
1033.86|3.48| students, which can be really useful. So more efficient,
1037.34|2.8| basically. So instead of having every student asking me the
1040.14|3.56| question, I, that could be just one student asking the question
1043.7|3.04| and answering, I can answer it for everyone, basically. Alright,
1046.74|3.44| so then let me finish this video. And then in the next
1050.18|14.04| video, I will talk finally more about machine learning.