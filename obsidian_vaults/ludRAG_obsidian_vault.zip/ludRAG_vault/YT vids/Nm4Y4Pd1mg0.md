start_time|end_time|text
0.8|2.84| Yeah, hi, everyone. I hope you're doing well and are well
3.64|3.64| prepared for the exam on Tuesday. I just want to clarify
7.28|3.32| again, these stuff in the news videos are not topics of the
10.6|3.32| exam. So you can just watch them and entirely forget about them if
13.92|2.96| you want. And you don't have to watch them at all, of course. So
16.9|2.98| today, because we have an exam on Tuesday, and I have another
19.88|3.76| talk on Wednesday, I will try to keep it rather short, I will
23.64|3.08| mainly introduce a new self supervised learning technique I
26.72|3.88| found, then there is something about some of the challenges in
30.6|3.32| deep learning related to causal relationships that I wanted to
33.92|3.6| share with you. And there are also a few tools I found really
37.52|3.8| cool. For instance, pytorch profiler. Alright, so with that,
41.32|5.04| let us get started. Yeah, so the first cool thing I wanted to
46.36|3.8| share with you is a cool podcast I discovered this week. So I'm
50.16|3.48| not listening to as many podcasts anymore as I once did.
53.64|3.08| Because sometimes I think it's good to give your brain a break,
56.72|2.72| especially like if you work and study a lot, and it's good
59.44|2.96| sometimes just to maybe do sometimes nothing and give your
62.4|3.64| brain some rest. But if you're doing something boring, let's
66.04|3.92| say commuting or household chores, like cleaning up at
69.96|2.72| home, then yeah, sometimes it might be nice to make this a
72.68|2.76| little bit more interesting by listening to some interesting
75.44|4.48| podcast. So this podcast is about machine learning just came
79.92|5.12| out this week. It's by Peter Abil, who is a very well known
85.04|3.56| researcher in deep learning. And it's a style of interview
88.6|2.84| podcast. And there's only one episode out. But in this first
91.44|5.16| episode, he was interviewing Andre Capati, who is the
96.6|6.52| director of AI at Tesla. And they talked about, yeah, mainly
103.12|3.48| machine learning and deep learning and how it is like to
106.6|3.0| work at Tesla. So I found this very interesting, because they
109.6|3.2| were also talking about, yeah, how deep learning is used in
112.8|3.6| practice. So at Tesla, they, for instance, use deep learning for
116.4|5.44| their autopilot, which is some sort of semi automatic, self
121.84|5.52| driving, or semi semi self self driving car capability. So with
127.36|3.92| a car can drive automatically on highways. But they also have
131.4|3.88| recently extended this version to a beta version that can drive
135.28|6.04| also in non highway situations. And they're mainly using cameras
141.32|4.72| for that, like regular cameras mounted on the car. And they are
146.04|3.48| using under the hood, for instance, convolution neural
149.52|4.04| networks, also. And one of the interesting takeaways from that
153.56|6.8| interview was that Andre Capati mentioned that, for instance,
160.36|3.28| it's a better bank for the buck. If you want to improve your
163.64|5.08| model, if you collect more data, and you are, let's say, labeling
168.72|3.64| your data, so paying attention how you label your data, and
172.36|3.36| also what type of data you collect, that might improve your
175.72|3.48| model more, or the performance more than let's say, fine
179.2|5.2| tuning or trying out a different model. So sometimes, just
184.4|3.4| focusing more on the data side can also give you really, really
187.8|2.72| good results. It's like a very common pattern I've seen in
190.52|5.8| industry. For instance, I recall also Andrew who is now he was a
196.36|3.4| professor at Stanford, who also was the co founder of Coursera
199.76|2.2| and had these very popular machine learning classes that I
201.96|4.52| also took and really enjoyed online. So he also has a
206.52|3.2| startup company, or I think it's beyond startup. Now it's a
209.76|3.88| relatively big company focused on working with industry
213.64|6.16| partners. And also from things he talks about, I gathered that
219.8|3.44| Yeah, the focus is also really on the data. It's very important
223.24|2.32| to get good quality data. And if you want to improve your
225.56|4.0| models, yet just focusing on the data is, is really important
229.72|3.04| compared to just tuning the model, which is very different
232.76|3.76| from academia, for instance, in academia, we usually work with
236.52|3.08| benchmark data sets, because usually when you look at paper,
239.96|4.84| or papers, it's like, um, about improving on a certain benchmark
244.8|4.92| data set, like MNIST, cipher 10, ImageNet, and many others. So
249.72|2.64| you're using the same data set and just want to see which model
252.36|2.96| performs better. But once you leave the academic situation,
255.32|1.92| and you go into industry, and you want to develop real
257.24|4.28| products, it's then more about, um, yeah, also collecting
261.56|3.28| additional data, and not just tuning the model, but really,
265.68|4.2| yeah, collecting more and better, more informative data to
269.88|3.84| improve the performance of your application. Okay, this was like
273.72|3.08| a long tangent, just want to mention this was actually a
276.8|4.08| pretty cool podcast I liked. So if you're interested, yeah, feel
280.88|4.24| free to check that out. Yeah, so this week, I also discovered a
285.12|3.2| new self supervised learning method I found particularly
288.32|3.32| interesting. So if you recall, self supervised learning is
291.68|4.16| essentially about leveraging the feature information on the
295.84|4.0| structure of the data for a supervised learning task.
299.96|4.28| Usually that's done by creating some label information from the
304.24|3.6| data. So you can apply self supervised learning to enable
307.84|3.28| data and then train in a supervised fashion by creating
311.12|3.56| labels. Here, this is a little bit more focused on, I would
314.68|2.84| say the structure of the data. So there's no I would say
317.52|3.28| explicit label information created here. It's more about
320.84|4.04| the structure. So this method is called Balo twins, and the
324.88|3.04| paper is titled self supervised learning via redundancy
327.92|5.08| reduction. So how that works is that essentially they run a
333.0|3.68| run a network twice. So focusing on this figure here, let's say
336.68|3.64| this part is one network, and then they create a copy of that
340.32|4.56| network. So let's say the lower part, it looks the same as the
344.88|3.6| upper part, except the input is different. So but here, it's
348.56|3.16| really just an identical copy of the network. It's the same as
351.76|3.52| running the same network twice. And this setup in general is
355.28|7.6| sometimes also called Siamese network. It's also popular in
362.88|3.56| other contexts, for example, traditional face recognition,
366.44|4.08| and so forth. So in any case, so what the goal here is,
370.52|4.84| essentially, is to learn feature representations that ignore
375.4|3.12| small modifications of that image, for instance, some
378.52|4.6| changes in the brightness or slight color perturbations or
383.12|4.6| slight rotations of that image. So what they do is they provide
387.72|6.56| in let's say this is the original, the original image.
395.88|2.64| And let's say this is the distorted version of that image
398.52|2.12| where you, for example, make everything a little bit brighter,
400.64|2.68| you change the brightness, then you run this through a
403.32|2.44| convolutional network. So you run both of them through a
405.76|2.92| convolution network, the same convolution network, it will
408.68|4.92| create a feature representation. And then you have the feature
413.6|3.08| representation of the distorted one up here, and the one of the
416.68|3.88| original one here, or it could also be two different types of
420.56|3.28| distorted images. For instance, this could be slightly rotated
423.84|2.28| to the left, and this one could be slightly rotated to the
426.12|3.48| right. For instance, the point is here really that you have two
429.6|4.88| images that are similar. And then you get these feature
434.48|2.96| representations here at the end, and you compute the cross
437.44|4.08| correlation matrix, and you then try to make the cross correlation
441.6|4.16| matrix similar to an identity matrix, where you have the ones
445.76|3.72| in the diagonal. And so with that, you're trying to learn
449.48|5.56| essentially, um, you're trying to learn that these feature
455.04|2.64| representation vectors should be similar to each other. So it
457.68|3.04| should ignore the network should ignore essentially, the small
460.72|3.44| perturbations in that image. So yeah, here, I summarized it
464.16|4.52| essentially that they run the original and the distorted image
468.72|2.8| through the same network computer correlation matrix. And
471.52|2.96| then they have an objective function or loss function that
474.48|3.12| forces this correlation matrix to be close to an identity
477.6|4.88| matrix. Yeah, and that is essentially then forcing the
482.48|3.76| representation vectors of similar examples to be similar.
488.2|5.08| So here's the code, the pytorch style pseudocode for that I
493.28|2.8| found it actually nice that they included that in the paper. So
496.12|5.72| here, that makes it easy to implement. So here, they produce
501.84|4.08| two augmented version of the image, then compute the
505.92|2.56| representation vectors, where F would be then the neural
508.48|5.48| network. And then they compute, or they normalize, and then they
513.96|3.44| compute the correlation, cross correlation between the two. And
517.4|3.36| then they compute the difference between the cross correlation
520.76|5.04| and an identity matrix, they apply on square. So they square
525.8|3.76| the results because I'm yet to. So it doesn't matter whether
529.56|2.2| it's positive or negative, which directions, it doesn't matter
531.76|8.08| which which way it is, right. And then they multiply it by
540.12|3.12| lambda, the difference the off diagonals. So I guess it's a
543.24|3.88| hyper parameter, like a scaling, how much penalty you would
547.12|2.72| assign, I'm not sure if that actually is really necessary,
549.84|3.52| because to some extent, I would think that the learning rate
553.36|2.84| already takes care of that by scaling the gradients. But I
556.2|3.04| guess it's a little bit more control over the penalty here.
559.24|4.96| And then they sum up the off diagonals here. And essentially
564.2|4.0| want to minimize the difference between those and the identity
568.2|3.84| matrix. And yeah, this is then the loss that they optimize. And
572.04|3.64| that's all they do. There's no class label information. And
575.68|5.4| they train that method. And then when they obtain these feature
581.08|2.8| representation vectors, they train a linear model. So they
583.88|4.04| say linear evaluation. Usually, that's something like logistic
587.92|3.84| regression, some simple linear generalized linear model. And
591.76|4.2| when they apply, then the linear evaluation, or let's say
595.96|4.52| logistic regression, trained on the feature vectors, they get a
600.52|4.16| pretty good accuracy here, which is shown here. So let me maybe
604.68|3.16| draw that. So if you have your input image, let's call it x, it
607.84|3.88| goes through the neural network, the convolution layers, and
611.72|3.6| then there's this feature representation vector. And they
615.32|2.76| let's say produce all the feature representation vectors
618.08|3.72| for the whole image net. So you have these, you treat them as
621.8|4.44| fixed. So you have for the whole image net, these feature
626.24|6.24| representation vectors, and they are your access your let's the
632.52|3.6| extra feature input x for the logistic regression model. So
636.12|5.04| let's run it here. So let's call that x one for the first
641.16|3.04| training example. And let's say x three for the third training
644.2|4.2| example, x two for the second training example. But then you
648.4|13.52| also use the original class label from image net. And this
661.92|5.28| will be this whole thing will be your training set your new
667.2|6.04| training set for logistic regression. It's essentially a
673.24|4.04| traditional supervised classification problem. So why,
677.36|3.12| why would you do that? This is really, yeah, it's really
680.48|5.32| testing how much information about the images is captured in
685.8|3.48| these vectors, it's a way of evaluating the convolution
689.28|4.04| network feature extraction, in that sense. So here, the
693.32|6.0| hypothesis is essentially on by forcing the network to ignore
699.32|3.76| these distortions, you can produce essentially,
703.4|2.56| representation vectors that are really representative of the
705.96|2.92| image, and then the linear classifier can classify them.
709.92|5.08| Well, and you can see this method when you train it in that
715.0|2.6| manner, with a logistic regression, on these feature
717.6|5.12| representations gets a 73.2% top one accuracy on image net, and
722.72|5.0| 91% top five accuracy. And there are also some other methods for
727.72|3.4| comparison. This is not the best method. So notice there are two
731.12|2.76| methods here, at least that are better. But it's very
733.88|3.36| competitive. It's, it's performing really well here. And
737.24|2.6| what I like about it is it's pretty simple. If you look at
739.84|3.32| this, it's a pretty simple training method. And yeah,
743.2|2.48| simple is sometimes also good. It's actually pretty cool, I
745.68|4.64| think. Yeah, so one thing that is great in our day and age is
750.32|2.92| that we have all these technologies now that make
753.24|4.68| communication online easier. But yeah, one unfortunate downside
757.92|3.28| of that is it's also making cyber bullying easier and other
761.4|4.16| abusive, yeah, things on the internet. So it's actually nice
765.56|4.8| to see that there's no like a workshop, focusing on issues
770.36|3.8| like that to improve the identification of hateful memes,
774.16|3.8| for instance. So I think this workshop was organized by
778.08|2.64| Facebook, I'm not sure anymore by Facebook AI research, I
780.72|4.48| think, but I would have to double check. So here are a few
785.2|2.32| examples of that. And essentially, this is a
787.52|3.12| competition where everyone can participate and develop
790.64|3.0| models. And it's a workshop where you're then invited to
793.64|5.72| also, yeah, write a paper about your model, if it's performing
799.36|3.68| well. I wish I would have known about that earlier, because then
803.04|2.12| I think we could have made this a class project, it would have
805.16|3.76| been cool. But yeah, it's, it was just announced last week,
808.92|2.96| it's a little bit on late in the semester. But if someone is
811.88|3.44| interested in working on that as a side project, this would be an
815.32|2.6| interesting application, for instance, also of convolutional
817.92|5.32| networks. So one thing that is new about this is it's a
823.24|4.04| multi label problem. I mean, not new in the general sense, but in
827.32|2.56| the context of our class, we haven't worked with multi label
829.88|3.84| problems. But it's essentially pretty straightforward. So
834.44|3.56| let's say you have your output layer of a neural network
838.0|3.48| convolutional network or multi layer perceptron, usually what
841.48|8.16| we used was a softmax function, such that these outputs that
849.64|2.4| they sum up to one to a probability of one. So we have
852.04|3.36| a each each node is a class membership probability, right.
855.4|5.04| So the first one is a let's say for class zero, given the input,
860.72|5.68| this is for class one, given the input x, and this one is for
866.4|6.48| class two, given input x. So usually, we assume these were
872.88|3.84| exclusive, mutually exclusive classes, for example, in MNIST,
876.96|3.24| each digit can only be one class, right. So it makes sense.
880.6|2.6| If we have three membership probabilities for let's say, a
883.2|3.52| digit one, digit two, and digit three, that they sum up to one.
887.4|2.84| Also, if for instance, if you have 90% probability for label
890.24|3.84| one, then it's maybe 5% for label two and 5% for label
894.08|4.52| three. But again, a multi label problem, it's, it's not a
898.6|4.56| requirement. So a data point can have multiple classes, for
903.16|7.08| instance, here for each meme, one task is to predict the
910.24|3.2| protected category, for instance, race, disability,
913.44|5.4| religion, nationality, and sex. So a meme could, for instance,
918.84|3.48| target multiple things at once. So here, you're not constrained
922.32|3.2| of having probabilities summing up to one. So for instance, you
925.52|2.52| can say for class one, it could be, for instance, a 90%
928.04|4.28| probability, but it could also have a 95% probability that it
933.08|3.68| has, in addition, also label number two, so it can have
936.76|4.68| multiple labels. How do you achieve that? So the only thing
941.44|3.24| you really have to do is you just change softmax by the
944.68|4.1| logistic sigmoid function. So in that way, you don't constrain
948.78|2.86| the network to have these probabilities summing up to one,
951.64|2.84| but essentially, yeah, this would be a very similar
955.0|2.16| approach, you can use convolution networks for that.
957.44|2.32| So yeah, if someone is interested on your important
959.76|2.4| dates, here's a link to this workshop, I just found that
962.16|3.28| interesting. I wish we would have known about that earlier,
965.44|2.64| because then it would have been a cool class project. But now,
968.24|2.52| yeah, I don't want to, you spend already so much time working on
970.76|4.04| it, I don't want to propose this as a new class project. But if
974.8|2.44| someone is interested, that would be an interesting site
977.24|4.64| project. Yeah, so there was an interesting paper recently
981.88|3.44| towards causal representation layer learning. That's not a
985.32|2.4| new paper. I mean, it's relatively new, but it's from
987.92|3.32| last month, but I have a huge backlog of stuff in the news
991.24|2.8| items that I discovered and haven't had a chance to discuss
994.04|4.64| yet. So yeah, so essentially, this is about pushing deep
998.68|4.16| learning more towards causal representation learning. So one
1002.84|5.04| shortcoming nowadays is that deep learning or the in general,
1007.88|3.68| the current state of supervised learning and your predictive
1011.56|5.56| modeling is more reliant or is essentially reliant on ID data,
1017.12|3.84| that means, independent and identically distributed data
1020.96|3.56| where one data point doesn't really influence the other. And
1024.54|2.98| deep learning systems like classifiers, typical classifiers
1027.52|5.0| are essentially just learning on statistical correlations between
1032.52|4.04| the input data and the output data. So you're essentially not
1036.56|2.04| learning a system that can really understand the
1038.6|2.84| relationship between the data in a causal way, it's more like
1041.68|7.24| exploiting correlations. So for instance, why would it be useful
1048.92|5.24| to learn causal relationships? One aspect that is also kind of
1054.16|3.8| mentioned in the paper is it can make models more robust towards
1057.96|6.16| unexpected situations. For instance, on if you have, let's
1064.12|4.52| say a self driving car, and remember when we had, I showed
1068.64|2.52| you that before this adversarial attack where they had a laser
1071.16|5.52| beam in front of a street sign, and it was fooling the
1076.68|3.2| classifier into thinking that the street sign means something
1079.88|3.36| differently, if there would be a better causal understanding that
1083.24|5.12| that might be avoided. So in that way, I think certain
1088.4|3.48| adversarial attacks could be mitigated if the network had a
1091.88|2.8| better understanding of causal relationships. But also it can
1094.68|2.72| make training cheaper. For instance, let's say you train a
1097.4|4.36| classifier to detect objects. And one of the classes is,
1101.76|3.76| let's say predicting whether something is a chair to sit on.
1106.12|2.48| So usually, if you want to make this really robust, you would
1108.6|3.12| have to take pictures of that same chair and include it into
1111.72|3.12| the training data set from different angles. A human,
1114.84|3.44| though, a human doesn't really need to see the same chair from
1118.28|3.6| different angles to recognize that this is a chair. So that
1121.88|2.92| way, if the network has a better understanding, maybe what the
1125.32|3.76| what makes a chair a chair, then in that way, we would maybe
1129.08|4.36| require fewer training examples. And this would also help with
1134.16|3.56| repurposing models so that you don't have to train the model
1137.72|3.44| from scratch on each new data sets. And that way, it could be
1141.16|3.68| more effective maybe to train a model on one data set and then
1144.84|2.96| apply to another. For instance, if you think of reinforcement
1147.8|4.48| learning also in a grand scheme, where you let's say learn an
1152.28|5.64| agent to play Age of Empires, it's a strategy game, then maybe
1157.92|3.04| this agent could be applied also to play StarCraft, which is
1160.96|3.32| another strategy game without, let's say requiring learning
1164.28|3.04| from scratch, because the games are relatively similar. So in
1167.32|3.6| that way, it could also help with transfer learning and
1170.92|3.24| repurposing models. But yeah, it's it's a challenge. It's
1174.16|3.3| something where people don't have a solution for yet. So this
1177.46|3.54| paper was mainly highlighting the challenges and proposing
1181.0|4.0| some potential future directions. But yeah, the main
1185.0|4.94| challenges essentially are whether the data even reveals
1189.94|5.22| causal relationships. And also then how can we infer these
1195.4|2.84| abstract causal variables. So they are currently I think there
1198.24|3.84| are no solutions yet. But people started to think about it more
1202.08|3.8| actively. And I think that this is like an interesting area of
1205.88|2.16| research to keep an eye on in the future.
1209.28|2.88| Alright, let's wrap it up with some of the cool tools I
1212.16|4.16| discovered this week. So one of them is classify AI with a
1216.32|5.56| rather clever name. AI. Anyway, so here, this tool is essentially
1221.88|3.64| a image annotator. So there are some other tools that exist, I
1225.52|2.64| shared some of them with you in the context of the class
1228.16|3.04| projects before. But yeah, this is a newer one, I think. And it
1231.2|4.64| looked pretty cool. It's an open source tool. And yeah, so it is
1236.08|4.08| providing capabilities for annotating images conveniently,
1240.16|3.24| for instance, also for object detection. So at the bottom
1243.4|3.2| here, this is a video, I hope it plays. Yeah. So it's just an
1246.6|4.64| example that shows you how convenient it is to label
1251.44|3.4| different objects. So if you're interested in that, check it
1254.84|4.76| out. This is free. It's an open source tool. Another thing I
1259.6|3.28| wanted to talk about is making your code more efficient. So
1262.88|4.76| this week, I actually spent quite some time making some of
1267.64|3.72| my code more efficient, because training was relatively slow.
1271.36|3.84| And I had hundreds or 1000s of lines of code. And I was just
1275.2|2.6| finding or trying to find the bottleneck. Why is the training
1277.8|4.8| so slow? Eventually, I found out my mistake, or the
1282.6|2.8| inefficiency, it's kind of summarized here. So I was
1285.4|5.04| computing three things every epoch, I was actually six
1290.44|3.92| things, I was computing the validation set mean absolute
1294.36|5.08| error, mean squared error, and the validation set accuracy. And
1299.44|3.08| then I was computing the same mean absolute error, mean
1302.52|5.1| squared error, and accuracy for the training set. So I did that
1307.64|3.72| each epoch. And each time the way I implemented these
1311.36|3.72| functions was by iterating over the data set, because they are
1315.08|5.0| too large to load into memory. So I was just iterating over the
1320.08|3.12| data set the same way you would iterate over the batches when
1323.2|4.2| you do the training. And I did that every epoch. Now that was
1327.4|2.32| very inefficient, because it takes a lot of time if you have
1329.72|2.9| like, half a million images in your data set iterating over
1332.62|4.22| the training set in each epoch that can easily like take two
1336.84|2.56| minutes or something. And if something takes two minutes, and
1339.4|4.6| you train for, let's say 200 epochs, that's 400 minutes,
1344.0|4.36| right? So it's a lot of time extra time. And yeah, the
1348.72|3.08| downside of that was one of the downside. But the problem I had
1351.8|3.92| here was that I did this in a very inefficient way. For
1355.72|3.8| instance, I computed here, the train mean absolute error, I
1359.52|3.48| mean, squared error, using iteration over the training
1363.0|4.24| model. And then I had the same thing here, too. So how I solve
1367.24|3.92| this problem was essentially writing one function that
1371.16|4.8| computes ma MSE and accuracy in one, one goal. So I don't have
1375.96|2.64| to call this function and this function separately, I was just
1378.8|3.16| writing a function that can do both at once. So I would
1381.96|5.3| essentially save 400 minutes if one of these takes two minutes
1387.26|3.38| each epoch, and I was training for 200 epochs. And essentially
1390.64|2.8| also decided just not to track these statistics during
1393.44|2.32| training only for the validation set. And also, it saved me a
1395.76|3.12| lot of time than another 400 minutes. So in that way,
1398.88|3.6| sometimes you're thinking about what you're doing in the code
1402.68|3.52| can be useful to make your code more efficient, especially if
1406.2|3.52| you don't really need the training statistics during
1409.84|3.56| training, if it's enough, for instance, to plot the final
1413.4|4.04| training accuracy and the final validation accuracy to assess
1417.48|5.08| overfitting. Alright, so long story short, the main point I
1422.56|3.32| wanted to make here is I was spending a lot of time analyzing
1425.88|4.56| my code and trying to find bottlenecks. And then on
1430.48|4.68| Thursday, or so I saw that there is a new tool, pytorch profiler
1435.16|3.92| that just came out. And this is a tool that kind of promises to
1439.08|3.56| make this more easy to identify bottlenecks in your code. And I
1442.64|2.88| thought that might be interesting to you. So this is
1445.52|4.76| based also on a tool called tensor board. And tensor board
1450.28|3.32| is a tool, a visualization tool that you can use during training
1453.84|5.12| to track different things, like performance metrics, and so
1458.96|6.12| forth during training. So this also got me into a rabbit hole.
1465.36|3.96| So I found out about this pytorch profiler, which I think
1469.32|2.24| is really cool, that might be something worthwhile trying in
1471.56|3.56| the future. And then from there, I saw, okay, this looks like
1475.12|3.68| Visual Studio code, right. And then I also saw, actually, that
1478.8|5.12| last month, Visual Studio code released some new capabilities
1483.92|4.0| on was updated to add an integration for tensor board.
1488.16|4.2| Before you had to use tensor board separately, for instance,
1492.36|2.84| in a web browser. Now you can use it directly in Visual Studio
1495.2|4.04| code. So you can have your code and tensor board side by side.
1499.6|2.68| And also one of the cool things about tensor board is it can
1502.28|3.64| instead of also in just in addition to just tracking
1505.92|3.68| training statistics, it can also visualize the neural network
1509.6|4.84| graph. So that is also a helpful debugging technique to make sure
1514.88|2.92| the network looks like you expect it to look like that you
1517.8|3.32| don't have any weird connections between layers that you didn't
1521.12|4.8| intend to connect. So that is a cool tool to check out as well.
1526.08|5.76| tensor board, it's also free, of course. And another tool that I
1531.84|4.88| saw recently is a tool for comparing different experiments.
1536.96|5.0| So previously, this tensor board is more for tracking during
1541.96|2.2| training, this is when you're training and you want to look at
1544.16|3.88| the loss function during training, for example, it's an
1548.04|5.36| easy way to visualize the loss. In class, the code I provide to
1553.4|2.68| you is usually that we use matplotlib at the end of the
1556.08|3.2| training, but tensor bot is really useful during training. I
1559.28|5.56| didn't want to teach that to you in class because yeah, we have
1564.84|3.56| already so many things to talk about. And I would say this is
1568.4|3.8| more like something that you want to use once you are more
1572.2|3.24| familiar with the basic training because it's just another tool
1575.44|3.24| and I didn't want to overburden you with too many tools, but I
1578.68|5.16| recommend to check that out at some point. This tool here is a
1583.84|2.96| little bit different, it's more like for comparing models after
1586.8|4.24| training. So it's actually I looked at how you use it is
1591.04|3.2| actually super simple. So you only add one or two lines of
1594.24|5.08| code and it will write a certain Python dictionary to to your
1599.32|3.88| hard drive. And it will do it such that you can import it into
1603.2|3.88| this tool and it will allow you to compare between different
1607.2|3.64| runs. So if you run the model with different hyper parameters,
1611.16|3.12| it will essentially help you to visualize which one is the best
1614.28|2.52| hyper parameter configuration and so forth. So actually a
1616.8|3.24| pretty nice tool here too. Of course, this is just one of the
1620.04|2.68| many, many, many tools. There are other ones like this, for
1622.72|3.28| example, I think one is called Hydra one is called ml flow.
1627.08|2.32| There are many tools for doing that. But yeah, this one looked
1629.4|2.52| actually pretty cool. Also just wanted to share this because
1631.92|3.6| it's also free. And also something you may want to check
1635.52|5.72| out at one point. Yeah, lastly, so that I will be giving a talk
1641.24|3.36| on Wednesday, if someone is interested. So they gave me free
1644.64|3.68| tickets for students, I shared them with you on Piazza. So
1648.44|2.32| someone is interested, my particular talk would be on
1650.76|10.12| March 31 1040. am central time. I think that is 1140. In our
1660.88|3.16| time zone. No, wait, this is our time zone. Sorry. So this is our
1664.04|3.48| time zone central time. No, I used to live in Michigan when we
1667.52|4.28| were on Eastern time. So yeah, we are in central time. So yeah,
1671.8|3.48| if someone is interested, but in general, lots of interesting
1675.28|3.36| talks here, you can check it out here. So and because there is an
1678.64|2.76| exam on Tuesday that I still have to prepare. And I also have
1681.4|4.08| to prepare for this talk. I will now end this stuff in the news
1685.48|12.44| section. And yeah, good luck for the exam on Tuesday.