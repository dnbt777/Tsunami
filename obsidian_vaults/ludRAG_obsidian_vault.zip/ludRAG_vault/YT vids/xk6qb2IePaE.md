start_time|end_time|text
0.52|3.56| Yeah, hi, everyone. So last week, we fell into a little bit
4.08|4.1| of a rabbit hole when I started talking about different ways we
8.18|3.42| can improve neural network training and the generalization
11.6|4.12| performance. Of course, we can't cover all the topics I outlined
15.72|3.16| on that mind map. However, I think there are a few important
18.88|2.6| ones that are really worth talking about. So in this
21.48|3.28| lecture, I want to talk about batch normalization, and also a
24.76|2.72| little bit about different weight initialization schemes,
27.48|3.4| which are also kind of important to make neural networks work
30.88|3.04| well in practice. And then in the next lecture, I want to
33.92|3.12| briefly talk about optimization algorithms. And then we will
37.04|3.2| move on and talk about cooler things like convolutional
40.24|2.96| networks and recurrent neural networks. But for now, let's
43.2|3.64| talk about batch normalization, because that's really a good
46.88|3.8| technique for making the network train better and faster.
53.08|2.88| Alright, yeah, just to recap, again, today, we are talking
55.96|4.4| about tricks for improving deep neural network training. So
60.36|3.68| today, in particular, we will talk about feature and input
64.08|4.24| normalization, and focus on a topic called batch norm. And
68.32|3.36| then I will also talk about weight initialization schemes
71.68|3.36| when we initialize the model weights. And there are two
75.12|2.68| particular techniques we are going to take a look at. There's
77.8|3.0| the Xavier glorot initialization scheme and the
80.8|4.64| caming he initialization scheme. Yeah, and then in the next
85.44|2.72| lecture, we will talk about optimization algorithms for
88.16|3.56| improving gradient descent learning, for instance, as our
91.72|3.92| mess prop and a grad, Adam, and I will also provide you with a
95.64|2.28| list of many, many more algorithms. But yeah,
97.92|3.92| personally, I think a stochastic gradient descent with momentum
101.88|4.76| and Adam are still the most useful or at least most popular
106.64|0.44| ones.
108.6|3.08| Alright, so as an overview, things we are going to cover
111.68|3.68| today. So I structured it into seven parts. Some of these
115.36|3.36| parts will be very short, but I try to structure it as always,
118.8|4.64| so that they go by topic and that is somewhat organized. So
123.44|3.88| first, we will just briefly talk about input normalization, then
127.32|2.48| we will switch to batch normalization, I will show you
129.8|3.76| how we do batch normalization in pytorch. And then we will have
133.56|4.64| a discussion of how or why batch normalization works. So we'll
138.2|4.68| explain here, how it works, like the techniques or the procedure.
142.88|5.28| And then we will revisit this here and discuss why it may have
148.16|3.1| a positive effect in practice. So it's still a controversial
151.26|2.78| topic. So it's still not clear. And I will highlight some of
154.04|3.42| the theories, then we will switch topics in this section
157.46|3.66| here and talk about these different weight initialization
161.12|3.54| schemes like on why we care about that two different
164.66|3.64| examples, and then also how it works in Python. Alright, so
168.3|4.84| with that, let's get started with input normalization.