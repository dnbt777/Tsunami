start_time|end_time|text
0.4|4.08| Yeah, before we move on and talk about the multiclass example of
4.56|3.96| logistic regression, the so called softmax regression, let's
8.52|3.18| just wrap up everything we talked about in the previous four
11.7|4.22| videos in a code example. So I prepared a code notebook, you
15.92|3.72| can find it on GitHub, I will share the link on canvas, where
19.64|4.88| I have implemented two things. So the first thing is logistic
24.52|3.72| regression from scratch, just yeah, from the ground up, low
28.24|2.52| level implementation of logistic regression, really
30.76|3.96| like on implementing the learning rule that we talked
34.72|4.38| about here. And then I will show you how we can do that using the
39.1|5.02| pytorch utilities, the module API that we talked about last
44.12|3.92| week, where we have this n dot linear layer and so forth. This
48.04|2.48| is something we would do in practice when we have of course,
50.52|3.24| more complicated networks, but I thought from scratch
53.76|2.96| implementation is still useful from a learning perspective. So
56.72|4.44| you get a better feeling of how logistic regression works. So
61.16|4.54| let's get started. So of course, first, my watermark, you can
65.72|3.0| ignore the torch version, this torch version doesn't exist.
68.72|5.6| Actually, I yesterday, compiled a torch from source to test
74.32|4.16| something. So this should also work on torch 1.7. So no worries
78.48|6.6| can ignore that. Um, yeah, so then the part of matplotlib,
85.08|2.76| which we'll be using NumPy, we will be using, and then the
87.84|3.08| torch stuff, we will be using. So just some inputs to get them
90.92|4.16| out of the way, we will be using some simple toy data set. That's
95.08|3.32| like, yeah, just, I think that is what I gave you also for the
98.4|3.16| homework. To be honest, I have to double check I made multiple
101.56|3.64| of these toy data sets. Yeah, that's just a simple binary
105.2|6.1| classification data set. Now here is my logistic regression
111.3|5.78| implementation. So how does it work? So I'm using the roughly
117.08|4.78| same way how we would implement that using pytorch with a module
121.86|4.1| API. So here I am implementing forward and backward manually.
126.68|3.76| These are the two methods where forward is the forward pass and
130.44|5.4| backward is the gradient descent computing. Yeah, the gradients of
135.84|4.38| the loss function. I actually let me modify this. Let's call
140.22|6.3| that loss with respect to so WRT means with respect to I think it
146.52|4.26| makes it clearer. So that's the gradient of the loss with respect
150.78|3.34| to the output and so forth. We'll just modify it everywhere
154.12|10.72| here. All right. And then let's do it step by step here. So then
164.84|3.72| here in the init function, this is like the function or method
168.56|4.3| that get x gets executed when we instantiate a new object from
172.86|5.96| this class. What we have is the weights and the bias unit. So
179.14|4.28| the weights, we initialize them to zeros. So we use the zeros
183.42|3.76| function to initialize them to zeros, it's a vector, a one.
188.66|3.24| It's a row vector, basically a one times num features vector.
191.9|6.28| So our matrix, so it's essentially a row vector. So um,
198.22|2.8| num features is the number of features in the data set. So the
201.02|2.52| number of weights is equal to the number of features just like
203.54|5.52| an adder line. And we only have one bias unit. All right, so the
209.06|3.92| forward method, yeah, this is computing the net input, right?
212.98|5.98| So this is the net input can also call it z can, we could
218.96|2.28| technically call it net input, but you know what we mean,
221.24|3.74| right? I mean, I can rewrite this maybe doesn't really
225.1|0.48| matter.
229.26|4.46| I can just leave it like that. I think I'm underestimating you, I
233.72|2.98| think it's probably all clear to you, I don't have to use these
236.7|6.36| different words. All right. Um, sorry. So the backward method is
243.1|3.48| yeah, computing these gradient terms, this is going back to
246.58|3.44| what we've done here. So here, I'm computing the gradient of
250.02|4.2| the loss with respect to the output. So this is essentially
254.22|4.86| this part here, then the grain of the loss with respect to the
259.08|5.02| weight, this is this part here, where I put those two things
264.1|5.04| together. So this should probably be with respect to the
269.22|3.4| Z, the net input, it's maybe clear instead of saying output.
272.62|7.88| Um, so this is matrix multiplication between x. And
280.5|3.24| this term, I just rearranged that to make the dimensions
283.74|2.6| match, which is why I have the transpose, you to be honest,
286.34|3.48| don't have to memorize these details, you will probably find
289.82|3.84| out by tinkering with the code. If you ever implement something
293.66|3.6| from scratch, because here, this is really for one weight. And
297.26|3.32| here, I have that as a vector implementation for multiple
300.58|2.92| weights, right, because we have the number of weights equal to
303.5|2.68| the number of features, that's a bit more complicated, but the
306.18|5.6| concept is the same. So this line here really is this part
311.78|5.42| here. I can actually also maybe go to this part here. So this
317.22|4.56| this part here, this is essentially this one here, the
321.82|3.84| gradient of the loss with respect to the weight. And then
325.66|2.56| the same for the bias, which would correspond to this part
328.22|4.5| here. Here, this is the threshold function, predict
332.72|4.1| labels. So I'm calling forward, that gives me the probabilities
336.94|4.44| a, so a is the probabilities for us, I call them problems,
341.38|2.52| because in the lecture, I said also, it was a bit complicated,
344.3|5.0| when we had y hat, and it was confusing. So I referred to a as
349.3|5.52| the probabilities, that's the sigmoid activation here. And
354.82|3.32| this is the threshold function, where if the probabilities are
358.14|3.96| greater than point five, return class label one, otherwise
362.1|5.64| return class label zero, I could however, also do it as with the
367.74|4.4| net inputs, I could say if the net inputs are, let's call them
372.14|4.08| zero or greater than zero, then return one, otherwise zero. This
376.22|6.76| is because what we discussed here. So here's the threshold
382.98|4.52| function. And because the probabilities with their point
387.5|3.8| five, the net input is zero. So either we can operate directly
391.3|3.24| on the net input or the probabilities here. So you have
394.54|3.6| that with the probabilities, but doesn't really matter that much.
399.24|3.3| Okay, so he has just an evaluation function. So this is
402.54|3.64| not super interesting. He I'm predicting the labels, which in
406.18|4.04| turns, in turn uses this method here, which computes forward,
410.22|6.92| and then the threshold function here, the threshold function.
417.14|7.4| And then in order to compute the accuracy, we sum over the
424.54|7.16| correct predictions. So every time the class label matches the
431.7|4.28| predicted labels here, matches the actual class labels, every
435.98|5.0| time they match, we sum that up. So this is a number of correct
440.98|3.52| predictions, and then divide by the size of the training set. So
444.74|2.64| it's a value between zero and one, it's the proportion of
447.38|5.0| correct predictions. Why do I do float here? It's because the
452.38|3.32| class labels are integers. And yeah, in pytorch, it's a little
455.7|3.32| tricky to compute or compare things like floats, the labels
459.02|4.56| are floats here. And then this is integer, I think I could have
463.58|2.32| I could have omitted this year, it's maybe a little bit
465.9|4.52| complicated, I could have also think done that would also have
470.42|8.56| the same effect. So but anyways, okay, anything else? Yeah, this
478.98|2.72| is a sigmoid function, which you have seen a lot of times. So
481.7|4.44| there's this function here. Yeah, the loss function, that's
486.14|4.32| the negative log likelihood, which we have right here at the
490.46|6.56| bottom. That's the logistic cost function. And here's the training
497.02|7.04| function. So here, again, let me jump back to this one, we we
504.06|5.88| are right here now. So for every training epoch, for e in the
509.94|4.88| number of epochs, we compute the outputs, which is here, that's
514.82|3.72| the probabilities, the ACE. So this is really, this should be
518.54|4.04| an A actually. So remember, this was copied from the adder line
523.1|4.24| should have probably adjusted it to an A here. But you probably
527.34|3.96| know what I mean. Um, then we compute the gradients. So these
531.3|7.8| are under B here. Then we update the weights, which is C, this
539.1|4.8| part here. And this is it. And this is just for logging, just
543.9|3.44| keeping track of everything, like looking at the results and
547.34|3.08| the loss curve, which can be useful. So let's actually do
550.42|0.76| that. Let's
552.7|2.92| yeah, do that here. What I'm doing is I'm converting the
555.62|6.36| NumPy arrays to torch tensors. Because if you go up here, you
561.98|5.8| can see I used NumPy here. So to load the data. So yeah, I'm
567.78|5.72| just converting them to torch tensors, then I'm initializing
573.54|3.56| my logistic regression model. So this will be actually step one
577.1|5.04| initializing. And then I'm calling train, train would be
582.14|4.48| everything under two here. And then I'm printing the model
586.62|2.2| parameters, the weights, the bias, just to take a look at
588.82|3.88| them. And I'm training for 30 epochs with a learning rate of
592.7|4.4| point one. So I think that's the mistake I always make talk
597.1|3.36| through this, but I usually forget to execute this. Okay,
600.48|4.7| now we are running the code. Okay, we got an error here. Okay,
605.18|4.88| I need to change the name one second, let me fix that.
614.46|4.04| Alright, so it's training, you can see it's blazing fast, starts
618.5|3.52| with already a very high accuracy after the first epoch,
622.02|2.72| to be honest. So it's, yeah, it's actually training super
624.74|3.32| fast, the cost is very low. But you can see, if I do more box,
628.06|4.28| it goes even lower, the accuracy goes up to 100% here even. But
632.34|3.42| you can see, even though the training accuracy is already 100%,
635.78|4.84| the loss still goes down. I could have trained more and
640.62|3.7| would go maybe down further. But that at that point might not be
644.32|2.54| necessary. Might be overfitting.
648.86|5.56| Alright, wanted to execute this part. Okay, there's some message
654.42|4.76| here. I think this message comes from NumPy, because I recently
659.18|3.06| installed a very recent version of NumPy. And it must be
662.24|2.86| something in Matplotlib here, you can actually ignore that
665.1|4.36| that this is not an error message that is just a warning.
669.68|3.7| So if you see warning or deprecation warning, that means
673.5|3.64| things are still working. So don't worry about them. But in
677.14|3.28| future, if there's an even newer version of a software library
680.42|6.12| in Python, this may not work anymore. So here, this is
686.54|3.16| nothing we are doing wrong. This is probably something inside
689.7|3.16| Matplotlib. And I'm sure they are already aware and working
692.86|2.92| on that. So don't worry about this warning. Everything still
695.78|3.64| works fine. There will be probably a new Matplotlib
699.42|2.4| version that addresses this issue at some point, but
701.86|3.6| everything is fine. Um, yeah, you can see here is how the
705.5|4.28| lock, the negative log likelihood loss looks like. So
709.78|4.56| it should be the negative log likelihood loss to be precise.
714.34|3.36| And then over the number of epochs, you can see, maybe it
717.7|2.32| will go down further, you can see it's actually going steep
720.02|3.32| down. But whether it's actually helping, I don't know, because
723.34|4.4| we already get 100% training accuracy. So let's take a look
727.74|4.44| at the test accuracy, it's only 96%. For completeness, we will
732.18|4.88| also take a look at the Yeah, at this year. So yeah, we can see
737.06|2.56| actually here on the training set, the decision model looks
739.62|4.36| quite good. So it's dividing both classes, class zero and
743.98|3.72| class one on the test set. Yeah, it's not performing so well,
747.86|6.04| because there's this one outlier point, right. So here, this one
753.9|3.12| is not classified correctly. So if this decision body would go a
757.02|2.56| little bit more to the right, then we might get this one
759.58|2.96| correct. But at this point, this model only sees the training
762.54|2.72| data doesn't know of this point here on the right hand side. So
765.26|3.6| in this case, I think training the model further wouldn't
768.86|2.48| really help because this is already doing a good job here,
771.34|3.32| actually, maybe putting a little bit more to the right would help
774.66|5.2| actually, because then would be more here. Yeah. Anyways, this
779.86|4.44| is just an example, of course, I just implemented this quickly in
784.3|3.36| a way that I didn't really fine tune anything. And this is a toy
787.66|6.04| data set anyway, so don't over interpret this. Okay, so the
793.7|3.68| goal here was really to show you if I scroll up again, to show
797.38|4.0| you how we implement this from scratch, like, the most
801.38|3.08| interesting part, I would say is this backward function, which is
804.46|2.52| a little bit different from the airline function, the rest
807.02|3.68| should be all the same as in the airline implementation. So it's
810.7|4.84| not that new to you, I hope. Now, I want to show you though,
815.54|5.12| how we use the module API to implement this logistic
820.66|4.92| regression model. So here, this should do exactly the same
825.58|3.76| thing, but now I'm relying on inbuilt or built in pytorch
829.34|4.24| functions. So I'm using this self dot linear here to refer to
833.58|4.68| my torch dot n dot linear layer, this is a layer that computes
838.26|4.72| the net input. However, note that by default, this will
843.1|3.96| initialize the weights to small random numbers later on, this
847.06|3.08| will be very useful, but it is not that useful to compare to
850.14|4.48| our model above because if you recall, above, I initialized my
854.62|3.72| weights and bias to zero. So I want to do the same here. So I
858.34|3.08| can compare the two models. So what I'm doing is manually
861.98|6.76| assigning zeros to the weights and bias unit. Yeah, and then we
868.74|3.16| have the forward method. So here, the forward method, we
871.9|3.76| compute the logits via the self dot linear, which is this fully
875.66|4.12| connected layer or linear layer. And then we have built in pytorch
879.78|4.12| function that computes the sigmoid activation function. So
883.9|2.64| you can see a logistic regression model is actually
886.54|2.92| super simple. Actually, we can also it would train just fine if
889.46|3.56| we have this one, just for comparison person reasons, I
893.02|2.84| have this one, but you can see how simple it is. And it will
895.86|2.72| already implement the backward function for us, we don't have
898.58|6.4| to do it ourselves. Here, we are using the stochastic gradient
904.98|8.08| descent optimizer. So this will update the weights then. So this
913.06|3.16| will compute the gradients via the backward and update the
916.22|3.0| weights. So we are just specifying what weights we want
919.22|3.76| to train. This is the model parameters here, model two. So
923.02|3.92| this is one of two or one logistic regression model to
927.26|3.52| model one was the from scratch implementation. Right. So here's
930.78|2.6| just an accuracy function to compute the prediction accuracy.
935.02|3.6| We are training also for 30 epochs. Like before, what I'm
938.62|4.84| doing is I'm casting the NumPy on a raster tensor, I've already
943.46|3.36| done that. So it's pretty redundant. And now here's my
946.82|5.84| training loop in pytorch. So for each epoch, I compute the
952.66|3.28| outputs, these are the probabilities, this is from the
955.94|6.64| forward pass, this is these probabilities here. Then I use
962.58|3.36| this cross entropy binary cross entropy function. And this is
965.94|3.64| essentially why I spent some time in the last lecture, last
969.58|5.16| video here when we had when we had this topic here, why I spent
974.74|3.4| some time, yeah, just telling you that the negative log
978.14|3.72| likelihood and binary cross entropy are equivalent. Same
981.9|5.24| thing. Yeah, I'm saying reduction sum, because that's
987.14|3.8| what we have done here. It's the sum, or we can also do the
990.94|5.16| average, actually, if I change this, it will be the average or
996.1|4.92| mean by default. But since we implemented above the sum to
1001.06|3.44| have the sum here, I'm also for comparison reasons use the sum
1004.5|5.36| here. In practice, I think using the mean is more stable for with
1009.86|4.24| regard to learning rates and different batch sizes. Yeah, and
1014.1|3.4| then this is really like what we've done in the last week when
1017.5|5.08| we trained at a line using these automatic things, we have the
1022.58|6.6| following we compute the loss. I traditionally use the term cost,
1029.18|5.68| but I think loss is more natural nowadays, then we set the
1034.9|5.76| optimizer zero grad, which will reset the gradients from the
1040.66|2.36| previous round. Otherwise, the gradients will accumulate like
1043.02|4.44| I explained last week. And then we compute the gradients for
1047.46|4.28| the current round, and then update the weights. And this is
1051.74|4.84| essentially it. Let's run this. All right, error. Model two is
1056.58|2.6| not defined. See, I always forget to execute things. All
1059.18|3.16| right, let's execute this one. And then this one. Yeah, trains.
1062.34|3.04| Okay. So and you can see if you recall, these have the same
1065.38|2.8| values as we've seen before, I can just scroll up in a second
1068.18|4.36| and just to show you and also take a look at these weight
1072.54|10.64| parameters, can just copy and paste them. So yeah, you can
1083.18|3.64| see they're exactly the same. So we learned exactly the same
1086.82|4.84| using pytorch, which gives us confidence, I hope that we
1091.66|5.4| understand gradient descent correctly and implemented the
1097.1|5.08| gradient here correctly. So it's the same as in pytorch. All
1102.18|5.24| right. Um, yeah, and this is it, essentially. So evaluating the
1107.42|3.56| model, same test accuracy, because it's the same weights
1110.98|2.48| and bias. So it should be the same decision boundary, which we
1113.46|6.04| can see here. Yeah, so this is how we implement logistic
1119.5|2.92| regression. I hope that was helpful, like understanding a
1122.42|3.84| little bit better, how these different concepts here in the
1126.34|3.24| slides work. You may also want to work through this more
1129.58|2.96| slowly. I think that might be also helpful. But yeah, that's
1132.58|3.68| it. So the next video, we will then talk about how we can
1136.26|3.48| generalize these concepts to multiple classes. That means
1139.74|21.0| like more than two classes.