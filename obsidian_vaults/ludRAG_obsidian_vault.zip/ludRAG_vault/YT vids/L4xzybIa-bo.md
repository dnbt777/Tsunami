start_time|end_time|text
1.36|2.8| Yeah, no equipped with the knowledge of what a function
4.16|4.42| derivative is. Let us use the idea from calculus to train a
8.58|3.9| linear regression model using a method that is called or related
12.48|0.4| to
16.12|2.68| Yeah, no equipped with the knowledge of what a function
18.8|3.64| derivative or gradient is. Let's now take a look at training a
22.44|2.92| linear regression model using these concepts.
25.36|5.08| But yeah, no equipped with the knowledge of what a function
30.44|3.44| derivative and gradient is. Let's not train a linear
33.88|3.08| regression model. So this technique in the context of
37.08|1.0| linear regression is
41.32|2.66| yeah, no equipped with the knowledge of what a function
43.98|3.42| derivative and gradient is. Let's not train a linear
47.4|2.92| regression model. So for this, we will be using a technique
50.36|3.56| called gradient descent, which is related to computing
53.92|4.64| function derivatives and gradients. So consider the
58.56|2.36| linear regression model here again, where the activation
60.92|5.32| function is just the identity function. So this is just like a
66.24|4.44| regular linear regression model. And we have one output here. So
70.68|5.04| this is our prediction. And for yeah, fitting or finding these
75.72|4.12| weights, we want to minimize the loss or the prediction error of
79.84|3.2| linear regression. For this, we formulate a convex loss
83.04|3.32| function. In the case of least squares, a linear regression,
87.0|4.16| that's the sum squared error, we can also consider the mean
91.16|4.24| squared error doesn't matter. So either one would work. So for
95.4|3.4| this squared error loss, what we have is we have the prediction
99.16|3.96| minus the actual value that we want to predict. So we consider
103.12|3.88| the difference between the two squared. So why the squared? I
107.0|3.6| mean, this way, your outliers will be more heavily penalized.
110.6|4.8| And also, it doesn't matter whether one or the others on the
115.4|3.4| left or on the right hand side, side, in any case, so if we
118.8|3.64| would plot this now, so by the way, I should say, this is over
122.48|3.56| the training examples. So if we have a data set with n training
126.04|4.36| examples, this would go from first to the last training
130.4|5.24| example. So the loss on the training data set. So now, um,
135.68|4.16| yeah, I plotted the loss here on the at the bottom, as a function
139.84|4.16| of one of the weights. So you notice there are usually sorry,
144.64|3.6| usually multiple weights. Here, we are looking only at one of
148.24|2.56| the weights, because it's simpler to look at, but you can
150.8|5.04| also generalize this concept to multiple dimensions. So what you
155.84|5.96| can see is this bowl shape or parabola shape. And the loss is
161.8|4.36| minimum for a certain value of the weights. So if the value of
166.16|4.6| the weight is too large, you can see the loss goes up. Or maybe
170.76|3.16| it's easier to see it like if we go to the right of the weight is
173.92|3.88| larger, you can see it has a higher loss in the same way for
177.8|5.44| this weight here that is too small. So there is a so called
183.96|9.12| global minimum that we want to find. So we want to find this
193.08|3.4| global minimum for the weights so that our prediction error or
196.5|4.36| loss will be minimized. We will do that for of course, all the
200.86|3.62| weights. So if you think of this in three dimensions, so if we
204.48|3.68| have this w one and a second weight, this would be a like a
208.16|4.68| bowl like a cereal, like a cereal bowl or something like
212.84|2.88| that, where you want to reach the bottom of the cereal bowl.
216.24|2.36| But yeah, it's easier to think of it as maybe it was one
218.6|7.04| dimension. Yeah, let's now see what happens if we use the
225.64|4.68| concept of gradient descent. So what we do is we have to start
230.36|5.08| with a certain weight, let's say this weight, this is our
236.28|4.44| starting point. So in practice for linear regression, we
240.72|3.2| usually initialize the weights to all zeros or small random
243.92|3.56| numbers. So if I had initialized the weight with the value zero,
247.48|2.64| we would be over here. And you can see also, yeah, the loss
250.12|4.92| would be pretty large here at zero, we want to find basically
255.04|9.56| this global, global minimum. That's our goal. So if you
264.6|4.12| think back, if you have seen the optional video on the
268.72|4.0| derivatives, so this is like almost like the squared function
272.72|5.6| that I talked about, so x squared, right. So and we can
278.32|4.48| compute derivative of this function. So the derivative of
282.8|3.68| this function with respect to w one, for example, if we
286.48|3.84| consider our starting weight, so this is the weight we currently
290.32|3.12| consider or we start with, let's say this is small, random
293.44|3.12| number, we can compute the function derivative at this
296.56|7.28| at this point. So here, so and then using this, we can. So I
303.84|3.12| should say, actually, the derivative should point upwards
307.04|3.32| here in this direction. But this is this arrow here is the
310.36|5.52| negative, the negative slope. So this arrow here is the negative
318.04|4.2| slope. And we can use this negative slope in multiple
322.24|2.44| dimension, you can think of it as a gradient instead of a
324.68|4.72| derivative, we can use this function gradient to guide the
329.4|5.28| weights into the direction of the global minimum. So the slope
335.52|4.4| would tell us how steep the function is. So at a given point,
339.92|3.72| how you how steep the function is, but we are interested in
343.64|4.76| the negative slope, which is also giving us the steepness of
348.4|3.36| the function, but instead of pointing upwards, it's pointing
351.76|4.0| downwards, it's pointing towards the minimum that we want to
355.76|4.76| reach. So we can use then this value, this negative slope or
360.52|5.2| negative gradient to guide the function downwards towards this
365.88|3.6| global minimum. So we make small steps towards the global minimum,
370.08|4.48| one step at a time. And for that, we have, as I've showed
374.56|2.88| you, I think in the second video of this lecture, we had a so
377.44|4.88| called learning rate at a and so the learning rate at a together
382.32|5.52| with how steep it is guides how much we update. So you can see
388.92|3.28| here at the bottom, it becomes a bit flatter, right? So the
392.2|2.84| function is not as steep anymore. So in these cases, we
395.04|3.52| also make smaller steps because the update really depends on the
398.56|3.88| steepness, and also on the learning rate. So let the
402.44|5.56| learning rate would all scale these on slopes by a constant.
408.04|3.4| So the learning rate is usually a constant that scales all of
411.44|3.32| these slopes. That is like an optional step, you don't have to
414.76|3.64| use learning rate. But in practice in deep learning, it's
418.96|2.76| kind of required to have a learning rate. And also, there
421.72|3.74| will be extensive tuning into what is a good learning rate. So
425.46|3.18| this is something where you would have to try different
428.64|2.72| learning rates and see what performs better. But this is
431.36|2.64| something that will be done later in this class. And I will
434.0|3.24| probably also make a homework about that way you have to play
437.24|5.76| around with this a little bit. So if you have a learning rate
443.2|3.36| that is too large, what might happen is that you might
446.6|4.12| overshoot. So if you choose a learning rate that is very large,
450.76|3.6| you may make an update. So let's say you make an update here,
454.64|2.96| this is maybe a little bit exaggerated. So you move from
457.6|5.22| this weight position to this one. And then the next update is a
462.82|4.5| large update here. So in this case, the update has been too
467.32|3.68| large. So you're overshooting the global minimum and depending
471.0|4.6| on what you find here, you may overshoot even more and then you
475.64|4.58| kind of lose the way so your loss will increase, you can see
480.22|2.58| that happening in practice, if you use a learning rate, it is
482.8|4.18| too large. So notice here also, I'm only again, always looking
486.98|4.42| at one weight, but there are weights in multiple dimensions.
491.42|3.9| So in that way, there's a lot of possibilities, something like
495.32|2.52| that can happen if we use a large learning rate. So it's
497.84|3.24| actually better to make like smaller baby steps to watch at
501.08|4.48| what the towards reaching this global minimum. However, if we
505.56|3.52| make the learning rate too small, it will just take a very
509.08|3.64| long time until we reach this bottom. So we make all these
512.92|2.62| little baby steps that will take a lot of iterations or a lot of
515.54|4.18| updates to reach this global minimum. In practice, for a
519.72|2.6| convex loss function like this one where we have a global
522.32|3.6| minimum, that is easy to reach because everything is convex,
526.32|2.96| then it's not a problem usually to have a small learning rate,
529.28|3.16| we have to just be patient. In practice for deep learning, this
532.44|4.76| would be a problem because the algorithm can get stuck. So in
537.2|3.92| deep learning, we usually have loss functions that are not
541.12|2.84| convex. So we can have a loss function that we draw you an
543.96|3.92| example, we can have a loss function that is somewhat,
548.52|5.24| let's say like like this. So if we have then a weight where we
553.76|4.24| start here, let's say we go down here, then it goes down here.
558.42|3.26| Okay, this would actually be a good case. Sorry. Um, let's
561.72|3.84| let's start here. So if we start here, we make small steps, then
565.56|8.92| we may end up in this, in this pit here, this is a local minimum.
574.72|2.44| So actually, I made it relatively steep. So you would
577.16|3.68| probably end up in this one eventually, anyways, but let me
580.84|9.9| make a maybe a flatter one, like something like this. So what
590.74|2.62| could happen is if you have a very small learning rate, you go
593.36|3.72| from here into this pit, and then you get stuck here. And
597.08|3.16| because the learning rate is not large enough at this point here
600.24|4.12| to jump over this, for example. So in this case of having a too
604.36|3.4| small learning rate can also be a little bit bad. But in
607.76|4.24| practice, we will later talk about algorithms that have a so
612.0|4.06| called momentum term and yet to overcome these little challenges
616.06|5.9| also. Okay, so but moving on. Yeah, you have the overview of
621.96|3.64| the online mode again, just for reference to just show you what
625.6|4.12| we want to get at now. So what we want to do is we want to find
629.72|3.0| this global minimum. So just pay attention to the right hand side
632.72|2.94| here. This is the stochastic gradient descent. There's also a
635.66|3.14| batch gradient descent, I will say a few words about that. But
638.8|3.84| here, for simplicity, consider the case where we update one
642.64|4.32| training point at a time. So in this case, what we do is we
646.96|4.28| compute the gradient of the loss function here. So you can see we
651.24|6.24| compute the gradients here. And we have this for w and the bias
657.48|4.16| and in that case, it would be just the partial derivative, not
661.64|3.72| a gradient. But let's use the same symbol, the number for
665.36|2.84| everything. It's I think simpler compared to switching between
668.2|5.32| different symbols. So then our update is based on the current
673.52|3.48| weight, and then the learning rate. So this is the learning
677.0|6.48| rate again, times the negative gradient, you can see there's a
683.48|3.72| negative now the negative sign. So this is because we want to go
687.24|3.76| towards the global minimum and not upwards, right. So we don't
691.0|2.48| want to make the loss larger, we want to make the loss smaller.
693.6|2.36| So we take a step into the direction of the negative
696.2|3.24| gradient. So here, we use actually these gradients to
699.44|7.24| update. So what are these values? So where's this value,
706.68|3.48| and this value come from? Where does these values come from? So
710.16|3.76| for that, we can yet derive our loss function, right. So we can
713.92|3.56| derive our loss function with respect to w, and with respect
717.48|0.52| to B.
722.32|5.08| Yeah, let's not arrive the loss function with respect to w. So
727.4|4.8| here, we are only taking a look at one of the weights on w j.
732.56|2.88| Just to keep it simpler, we could also do this for the weight
735.44|5.76| vector. But yeah, recall, the gradient of the loss would be
741.2|3.12| just a collection of these individual partial derivatives,
744.32|2.96| right. So we would have the partial derivative of the loss
747.28|11.32| with respect to w one, w two, up to w m. So that would be a
758.6|3.32| vector. So here, we are only taking a look at one of these,
761.92|3.4| for example, the first one, let's call it w j, some of the
765.32|5.68| arbitrary entries here in this gradient vector. So we are
771.0|3.84| considering here the sum square error loss. So in the previous
774.84|3.08| slide, I showed you for simplicity on the stochastic
777.92|3.12| version where we only update or compute the gradient based on
781.04|3.68| one training example at a time, which would be an approximation
784.8|4.12| of this overall loss function, right. So if I only consider one
788.92|3.24| data point without the sum, so if I ignore the sum, this one
792.16|3.76| would be only an approximation of the overall loss function on
795.92|3.24| the training set. So here, using the whole training set, it's
799.16|3.16| actually more accurate. This is also sometimes called just
802.32|4.12| gradient descent or batch gradient descent, if we use the
806.44|7.76| whole training set where we have i equals one up to n. And then we
814.2|4.6| can also consider the smaller case where we only have a mini
818.8|3.64| batch. So if we have a mini batch, if this is, let's say a
822.44|5.64| mini batch of size k, and k is smaller than n, this would be
828.08|2.68| the mini batch version. This goes back to what I explained
831.04|2.0| at the very beginning of this lecture, where we have this
833.04|4.12| online mode, mini batch mode, and batch mode, how we compute
837.16|3.24| the gradient, it's the same concept, except that here, we
840.4|4.48| have this sum everywhere, but you can also ignore the sum, and
844.88|3.56| then it would be for the online mode. Alright, so what we do
848.44|4.92| now is let's, yeah, we are deriving now the loss with
853.36|2.88| respect to the weight. Let's take a look here. This is just a
856.24|2.92| sum squared error loss that I have written down again. Now we
859.16|5.4| are differentiating this loss with respect to w j. So first
864.56|4.2| step is I'm expanding this term here, the prediction. So if you
868.76|4.36| recall how we compute the prediction, it's the weights
873.72|4.52| times the feature values plus the bias, right. So here, I'm
878.24|4.68| ignoring the bias, let's say it's implicitly included in the
882.92|3.52| weights. So we are only looking at everything without the bias
886.44|2.48| just for simplicity. I've actually included it here, but
888.92|6.52| maybe ignore this for now. Yeah, and then we have the activation
895.44|4.84| function. And the activation function was just an identity
900.28|3.36| function. So I'm just using this one here, writing it more
903.64|5.36| compactly with using vector notation w transpose x using
910.36|5.8| vector notation here. So that's what I'm what I have here. So I
916.16|6.96| just expanded this one. And now we are using the chain rule to
923.6|3.64| compute the derivative. So the chain rule is the outer
927.24|4.88| derivative times the inner derivative. So here, notice we
932.12|5.88| also the outer function would be this one basic. So this is the
938.0|3.2| inner in red, and then the square t would be the outer
941.2|3.56| function. So what I'm doing is I'm deriving now the outer one
944.8|3.72| this is this part here, this is the outer derivative, we write
948.52|4.4| this down using the power rule. And then on the left hand side
952.92|7.84| here, that's the inner derivative for the outer derivative, we
960.76|3.72| are basically done. So we don't have to do anything on the left
964.48|5.8| hand side. So the left hand side is done. Now let's take a look
970.28|3.2| at the inner derivative. So if we take a look at this inner
973.48|5.72| derivative, we see, okay, there is another chain rule application
979.2|4.08| required, right? Because again, we have different things going
983.28|3.4| on here, we have the activation function, and then there is the
986.68|5.16| value inside the activation function. So let's now consider
992.08|4.08| the chain rule again, when we compute the outer and the inner
996.16|3.72| derivative. So the way I've written it here is again, on the
999.88|4.92| left hand side, the outer derivative. So this would be
1004.8|5.44| what would be the auto derivative, the derivative of
1010.24|3.32| this activation function with respect to its input. So the
1013.56|8.24| input is this term wt, w transpose x. And then on the
1021.8|4.2| right hand side, I have the derivative of the inner part. So
1026.0|5.04| this would be the inner part, notice, we cancel the minus y,
1031.2|3.0| because this is just a constant. So this goes away.
1034.2|10.92| All right, so looking at this here, now, this term, what if we
1045.12|3.72| compute the derivative of this, this whole term with respect to
1048.84|5.92| w, the result would be x, right? So because we computed the
1054.76|6.48| derivative with respect to w, j. So the of this term, with
1061.24|8.52| respect to w, let's say w, j, because w is a vector would be
1071.44|4.88| oops, xj, because all the other values in that vector would be
1076.32|6.6| constant. So this is what we have here. So that's what we
1083.12|5.12| have left over if we derive this part. Now we are left still with
1088.24|4.84| the outer derivative to do. So the outer derivative, if we
1093.08|3.36| compute that the derivative of sigma with respect to its input
1096.44|4.56| is one. So why is that because we have the identity function
1101.0|5.0| here, right? So the derivative of this function. So let me
1108.32|6.2| write this down. This would be one, right? So this goes away.
1114.52|8.4| So what we are left here with is just xj. So the derivative of the
1122.92|4.96| loss function with respect to the weight is y hat. So if I
1127.88|4.32| would condense this, again, actually would be two times y
1132.2|6.08| hat minus y times xj. And this would be the derivative of this
1138.28|5.76| loss function with respect to this w j. And in each iteration,
1144.04|2.76| when we do the update or the training, we can compute this
1146.8|4.48| value and update the weight values, right? So we can use
1151.4|5.72| this term now to update the weight. So if we have the weight,
1157.54|9.34| we update it by itself, plus then the learning rate times the
1166.88|3.72| negative version of this whole part. This would be how we
1170.6|4.0| update the weights in each round to minimize this loss function.
1176.24|3.12| So here I have an alternative notation of this whole thing.
1179.76|4.76| This is actually what people do in practice. So usually to make
1184.52|2.24| this a little bit more stable with in terms of the learning
1186.76|3.12| rate, so that the learning rate doesn't depend on the size of
1189.88|4.52| the training set, we actually compute or use the mean squared
1194.4|6.18| error. So here, we have a no one over n. So just averaging the
1200.58|2.54| rest is all the same, except that I know have this one over
1203.12|4.64| n. But also notice that it's not only one over n, it's over two
1207.76|4.48| n. And again, this is really to make things more convenient,
1212.24|3.88| because then when we use the power rule, so if I use the
1216.12|4.8| power rule here, the two goes in front, right, so I have two over
1220.92|5.28| two n, and then the two cancel, and then I'm just left with one
1226.2|3.46| over n. And this is a little bit more convenient, convenient. So
1229.66|3.38| this one is usually the one that is used in practice, because
1233.04|4.0| then if I use this one, for updating the weights, I can
1237.04|3.08| choose a learning rate that is independent of the size of the
1240.12|2.56| training set or independent of the size of the mini batches.
1242.96|3.24| Otherwise, if I change my data set or my mini batch size, I
1246.2|3.16| have to find the learning rate every time from scratch again.
1250.68|2.6| Actually, it's important to find the learning rate for each new
1253.28|4.82| data set anyways. But if we play around with different, different
1258.1|4.86| mini batch sizes, it would be more robust if we use the one
1262.96|3.84| over n, this is usually what we do in practice. Yeah, so here's
1266.8|6.96| how gradient descent looks like for a loss function with Yeah,
1273.76|3.54| so here's again, how gradient descent looks like using a
1277.3|3.42| surface plot. So here we have again, the mean squared error
1280.92|3.84| loss, and we are looking at two weights now. And the global
1284.76|8.56| minimum is here in the center. Now, suppose we start with a
1293.32|4.92| weight here, let's say this is our starting weight. And the
1298.24|3.56| lines here, these contours indicate how large the losses.
1302.08|2.68| So of course, the other closer you get to the local minimum,
1304.76|2.88| the smaller the loss. And that's where we want to get at, we want
1307.64|4.48| to get to the global minimum. Now, if we use the batch gradient
1312.12|6.48| descent, where we derive the loss function based on the whole
1318.64|6.44| training set, let me just quickly write this down here
1325.08|5.2| again. So if we compute the derivative of this one with
1330.28|3.5| respect to the whole, yeah, considering the whole data set,
1334.08|4.68| then we will make direct leaps towards the global minimum. So
1338.76|3.88| each update will be perpendicular here to the contour
1342.64|4.84| lines. If we use something like stochastic gradient descent, so
1347.48|4.44| that is if we only update based on one data point at a time, or
1351.96|3.42| based on a mini batch, then the updates will be a little bit
1355.4|4.06| noisier. So instead of going straight to the center, there
1359.46|4.14| will be like this little zigzag. For linear regression, this is
1363.6|4.12| probably not ideal, because it's Yeah, why would we want to do
1367.72|3.32| that? It's there's no point doing that. If we can do these
1371.04|3.16| direct steps, make these direct steps, why would we do one step
1374.2|2.84| at a time, maybe one advantage is if you have a very, very,
1377.04|3.96| very, very large data set, then this will train the linear
1381.0|4.44| regression model quicker, because you will be having more
1385.48|4.0| updates per epoch. So if you have batch gradient descent, you
1389.48|3.56| only have one update per training epoch. And with mini
1393.04|5.16| batch gradient descent, you have more updates per epoch. However,
1398.2|3.8| each update itself is noisier. Again, for linear regression, it
1402.04|2.48| probably doesn't make sense to use mini batch gradient descent.
1405.28|3.08| But later, when we talk about deep learning, we have non
1408.36|3.28| convex gloss functions. So we probably won't be reaching the
1411.64|3.72| global minimum anyway. And in this way, using these little
1415.38|2.62| stochastic gradient descent updates, I say are actually
1418.0|6.16| better than these complete gradient updates. Yeah, also one
1424.16|5.28| more note about data normalization. So I think I
1429.44|3.16| mentioned it before that it is important to normalize the input
1432.6|4.68| data so that the features are all on the same scale. So this
1437.28|4.48| is not a problem. For example, if we have something like Iris
1441.76|2.84| where everything is already on centimeter scales, but it's still
1444.6|2.96| helpful to make these values smaller, because there will be
1447.56|4.16| certain weight initialization schemes, we will talk about this
1451.72|3.12| in a separate lecture, how to initialize these weights well.
1455.88|3.08| But if we have, let's say data sets where we have features on
1459.4|5.96| me at different scales, let's say one is something like income,
1465.4|4.0| and the one is H. So if let's say H, and income is your
1469.8|4.04| features and income is a dollar amount. So let's say you have
1473.84|4.96| something like, I know $50,000 or something per year, and the
1478.8|3.92| age is maybe 23 or something like that. So these are very
1482.72|4.64| different scales. So one scale is from maybe 10,000 to 10
1487.36|6.32| million, whereas H is between, let's say, zero and 100. So in
1493.68|3.92| this way, what happens, what the problem is, is that these
1498.08|3.84| contour lines will be more like skewed, so they will be more
1501.92|4.16| like elliptic. And then it will be harder to update, because
1506.08|3.84| remember, we are computing the gradient of the loss. So that
1509.92|5.2| considers all the directions. And then we may make these steps
1515.12|4.88| that are not directly pointing towards them. I mean, they are
1520.0|2.88| pointing towards the minimum in a way in one direction, but in
1522.88|4.16| the other direction, we make maybe a larger leap. So actually,
1527.04|4.08| maybe if we we, we overshoot basically, and then we also end
1531.12|5.28| up zigzagging. So this way, it helps actually initializing the
1536.4|3.16| weights with small random numbers, but also normalizing
1539.56|3.0| the inputs. About the weight initialization, we will have a
1542.56|3.48| separate lecture talking about different strategies for
1546.28|3.56| initializing the weights. Well, of course, for a simple case,
1549.84|3.0| like linear regression, it doesn't really matter that much,
1552.84|3.36| but it will matter when we talk about deep neural networks. So
1556.2|3.12| you can really think of deep neural network training as
1559.32|3.28| applying the same concept that we talked about in this lecture,
1562.6|4.04| exactly the same concept, but to a more complicated network. But
1566.68|3.08| we will also be computing the derivative of the loss with
1569.76|3.32| respect to the weights. But in the network, we have multiple
1573.08|3.32| layers and multiple weights. But except that it's very, very
1576.4|6.44| similar. Alright, so then, yeah, to end this lecture, let's talk
1582.84|4.2| about training a single layer neural network. So an extension
1587.04|3.08| of linear regression for classification. So the adeline
1590.12|27.48| the adaptive linear neuron.