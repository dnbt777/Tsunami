start_time|end_time|text
1.5|3.16| Yeah, so the last couple of videos included a lot of
4.68|3.72| mathematical details, which may not be super exciting. So let's
8.4|3.6| now take a look at a more hands on example, and do something
12.04|3.6| get more hands on training and adaptive linear neuron in Python.
15.96|4.38| So here, I will just give you the overview of how things
20.34|5.52| relate to the airline. So recall the airline, that is what we
25.86|2.84| covered briefly in the history of deep learning lecture, that
28.7|4.74| is a model by Woodrow and Hoff in developed in 90 and around
33.44|3.48| the 1960s. So actually was a physical device, but you can of
36.92|3.4| course also nowadays, yeah, implemented in software. And
40.32|5.0| this is a nicely differentiable neural model. So the perceptron
45.32|2.8| model that we talked about before is not differentiable
48.12|3.24| because of this threshold function. So this airline, you
51.36|2.92| can think of it as an advancement of this perceptron
54.28|3.2| that is now also converging, even if the data is not
57.48|5.52| linearly separable. So yeah, just for comparison, so how the
63.0|3.04| perceptron looked like, so recall in the perceptron, you
66.48|3.76| will we compute the net input first, and then we pass the net
70.24|3.4| input through a threshold function, and then the
73.8|5.6| threshold function produces our output. So the output is the
79.4|5.76| predicted class label, which can be either zero or one. And if
85.16|5.8| the prediction matches the actual label for that given
90.96|6.24| training example, then we don't do anything. But if it doesn't
97.2|4.8| match, if it's different, then we have this error term that we
102.0|3.28| computed. So we have the difference between the two. And
105.28|3.52| we use that to update the weights. So we update the
108.8|3.12| weights, which then will change the decision boundary to make
111.92|4.04| to make the prediction correct. So that is how the perceptron
115.96|4.16| works. But a threshold function is not differentiable. So here,
120.12|3.52| we couldn't use calculus, there was just this rule that was
123.64|3.16| developed by I would say thinking hard about this
126.8|4.1| problem. So it was more like an empirical update rule. Now, we
130.9|4.14| can actually improve that by using calculus. So at the
135.04|4.66| bottom is the airline. So here, you can think of this part here
139.7|5.1| as the maybe base model. And this is like linear regression
144.8|3.3| works. So again, we also compute the net input similar to the
148.1|4.56| perceptron. Now we have as an activation function, we have
152.78|6.04| this identity function, which is not doing anything. So if it's
158.82|2.22| not doing anything, if my activation function is just the
161.04|3.12| identity function, why do I write it down in the first
164.16|4.64| place? That's because next week, or the week after that, we will
168.8|3.58| be talking about nonlinear activation functions, we will be
172.38|4.88| talking about functions that are, for example, sigmoidal
177.26|5.34| function, like, like this one, for example, so we will be
182.6|3.42| covering other types of activation functions. And we
186.02|4.0| will need them to develop multi layer networks, because this
190.02|5.52| will help on multi layer network to produce nonlinear decision
195.54|2.8| boundaries for solving complex problems. Because if we would be
198.34|3.08| using linear activation functions in a multi layer
201.42|3.52| neural network, then the multi layer network would be just a
204.94|4.56| combination of linear functions. And the sum of linear functions
209.5|3.0| is also just a linear function, so we wouldn't gain anything. So
212.5|2.4| later on, we will be talking about nonlinear activation
214.9|3.4| functions. And here, you can think of it as a placeholder, we
218.3|2.82| will replace that later, I'm just including it here in the
221.12|3.8| notation. Because it's a more general notation that would
224.92|4.74| apply to also nonlinear activation functions. Okay, now
229.82|3.98| consider this linear regression base, in order to turn this
233.8|4.02| linear regression model into an adaptive linear neuron into the
237.86|3.32| Adeline model, all we have to do is now adding a threshold
241.18|4.0| function, because the Adeline model is a classifier. So this
245.18|5.0| is a classifier for classifying data points similar to the
250.18|3.86| perceptron. However, note the difference here really, between
254.04|4.46| the perceptron and the Adeline is where we compute the error.
258.72|4.74| So for the perceptron, we compute the error after the
263.46|4.08| threshold function. And in the Adeline, we compute the error
267.58|4.0| before the threshold function. So here, we don't have the
271.58|3.02| problem that things are not differentiable, because we
274.6|3.02| computed before the threshold function, the threshold function
277.62|4.28| still is not differentiable. But we don't worry about that,
281.9|3.9| because we compute the gradients before that. So in that way,
285.8|2.9| it's not a hindrance, and it will become more clear when I
288.7|4.62| show you the code example. So here's just conceptually how it
293.32|3.14| looks like when we fit an Adeline model. So here, what I'm
296.54|3.64| just doing is I'm showing you the class label on the y axis.
300.5|8.2| So for binary classification, where we have to classification,
308.7|3.64| where we have two class labels of one and zero, I have plotted
312.34|5.04| them here. So the class labels can be either one or zero. And
317.38|4.36| then we have only one feature value for simplicity here. And
321.9|3.24| yeah, we want to predict that in the linear neuron is a linear
325.14|4.76| model. So essentially, what it will learn is will fit a linear
329.9|3.44| line similar to linear regression. So this would be very
333.34|3.04| similar to linear regression, right? Except now the difference
336.38|2.76| is really that in linear regression, we usually have
339.38|3.36| continuous values, not only zeros and ones, and we don't
342.74|3.24| have the threshold function. So in the Adeline, after fitting
345.98|3.86| this model, we apply this threshold function, let's say at
349.84|5.46| point five between zero and one, and we say, then if something
357.62|5.4| if something is bigger than a certain value, so if the it's
363.02|2.0| maybe a little bit unfortunate, I wrote class table here,
365.02|3.64| because this is the threshold, if the prediction, let's say,
369.34|4.76| prediction, if the prediction is greater than point five, produce
374.1|8.24| class label one, and otherwise, produce class label zero. So in
382.34|4.36| that way, we turn the continuous prediction into a class label.
386.9|2.28| Again, this will become clear when I show you the code
389.18|5.12| example. So I prepared some code examples. Let me pause this
394.3|2.88| video and do this in a fresh video. So there will be another
397.18|27.6| video where I will go over these code examples.