start_time|end_time|text
1.64|3.72| Yeah, now that we learned about attention, self attention,
5.6|3.34| multi head attention, and how that fits together in the
9.12|3.4| transformer architecture. Let's now look at some of the popular
12.52|3.48| methods based on this transform architecture. For example, there
16.0|4.84| are the bird model, different types of bird models, and then
20.84|4.24| also GPT GPT version one, two, and three, and the bark model,
25.08|4.36| which combines bird and GPT. And all of these models have kind of
29.44|3.52| interesting ideas. It's the models themselves are not very
32.96|3.32| complicated. They are essentially small modifications
36.28|2.52| of this transformer. But yeah, I think it might be interesting to
38.8|3.48| talk about these because they are also very popular. If you
42.48|3.68| look at the news and things like that, people like to talk about
46.16|3.48| these models. And I think it's just interesting to briefly go
49.64|4.08| over them and how they are different from each other. Yeah,
53.72|3.4| just to briefly recap, this is the transformer architecture,
57.12|2.8| the original one from the attention is all you need paper.
60.18|3.72| And these methods we will talk about like bird and GPT are based
63.9|3.1| on this fundamental architecture. Of course, they
67.0|4.76| make some modifications. But fundamentally, let's say bird
72.2|4.64| borrows from the encoder part and GPT borrows from the decoder
76.84|5.32| part. And we will then see in the upcoming videos how the these
82.16|5.2| models relate to this model. But big picture wise, I would say
87.36|4.16| the two keys to success behind all these transform models are
91.64|3.56| still the self attention mechanism for encoding these
95.2|4.8| long range dependencies or contexts. And the other one is
101.16|4.88| self supervision for leveraging large unlabeled data sets. So
106.04|7.88| this is also often called on unsupervised pre training. So
113.92|3.12| originally, it was called unsupervised pre training.
117.2|3.6| Nowadays, the word self supervision or self supervised
120.8|3.96| learning has become more popular. And we talked about
124.76|3.28| this a little bit in previous lectures, it's essentially about
128.36|4.48| taking a large unlabeled data set, and then constructing the
132.84|3.52| label from that data set from the structure of that data set,
136.68|4.6| instead of having someone labeling these training
141.28|5.12| instances manually, which is very expensive. So one task that
146.4|2.2| we have seen before, for instance, in the transform
148.6|4.96| model is yet predicting the next word, it's still a supervised
153.56|3.56| approach, because we are still using a classification loss for
157.12|3.64| predicting the next word. But yeah, in contrast to regular
160.76|4.88| supervised learning, we extract this label from the text itself.
165.68|3.84| It's essentially the next word, we can extract it from the text
169.52|4.4| itself. This is why it's called self supervised learning,
173.92|4.68| because it's, it's creating the label itself, in a sense. So
178.6|4.2| it's, yeah, it's not the human who creates the label or some
182.8|3.04| other process. It's essentially just from the structure of the
185.84|6.88| data. So the training approach behind transformers can then
192.72|6.96| also be separated into a two step process. So the first step
199.68|5.4| is pre training the model on a large unlabeled data set, the
205.12|3.32| self supervised learning part. And the second part is then
209.48|4.64| training it on labeled data sets on usually smaller labeled
214.12|4.88| data sets for downstream tasks. So downstream tasks would be
219.04|7.92| let's say language, translation, some form of classification,
227.96|8.92| text summarization, maybe question, question answering,
236.88|5.32| let's say call it q&a, and so forth. So there are many
242.2|5.08| possible downstream tasks that you can use for language model
247.28|3.84| or have for language model. And for this, you would then have a
251.24|3.6| smaller labeled data set for supervised learning. For
254.84|3.8| example, think of the movie review data set that we used
258.64|4.48| before. So pre training could be pre training the model on
263.36|4.2| 1000s of books that we have in a self supervised fashion. And
267.56|3.88| then we can use our small movie review data set, which only
271.44|5.96| consists of 100,000 reviews. And then yeah, train the model on
277.4|3.6| that one. It's kind of related to transfer learning, which we
281.0|4.84| also talked about before. So and there are also two main
285.84|5.32| approaches to this training for downstream tasks. One is fine
291.16|4.8| tuning based, which is updating the whole model. And one is the
295.96|4.44| so called feature based approach. So for the fine tuning
300.4|3.96| one, think about it like this, you are training, let's say you
304.36|5.72| are model on the using self supervised learning the pre
310.08|5.12| training. So usually the model also has some fully connected
315.2|5.52| layers and so forth at the end. And this is your regular, let's
320.72|5.2| say transform model. And then for the fine tuning, you have a
325.92|5.16| classification task, for instance, let's say your movie,
331.2|5.52| review classification. So you add another classification layer
336.72|4.12| to this. And then you train the model on this, yeah, supervised
340.84|4.0| learning data set, and you update the whole model, all the
344.84|3.44| parameters are updated during training. This would be the fine
348.28|4.72| tuning based approach. The feature based approach here is
353.0|3.96| kind of related to that. But instead of fine tuning or
356.96|5.24| updating the whole model, you essentially extract these
364.0|3.36| embeddings from the last layers could be the last layer, the
367.36|2.36| last four layers, and so forth. I mean, there are different
369.72|2.84| methods, we will also take a look at that. And that was done
372.58|5.46| or experimented with in the bird paper. But the idea is that you
378.32|3.72| use these embeddings, and you assume these are now these
382.04|3.44| context embeddings, which are better than, let's say, regular
385.48|2.52| word embeddings, because they contain the context of the
388.0|4.8| sentence. So you have these, and then you don't update the model,
392.8|3.08| you just generate that, let's say, for the whole test set. And
395.88|3.66| then you train a new model that could be a simple model could be
399.54|4.02| logistic regression. In the bird paper, they used even an LSTM
403.56|4.36| for that you train another model, let's call that model two
407.92|4.44| for the classification. For example, for the movie review
412.36|3.48| classification, but here you don't, you don't update the
415.84|3.84| pre trained model, you just take these embeddings as fixed
419.68|4.16| embeddings, and then just use them as feature inputs to a new
423.84|4.32| model. So that's the feature based approach. We will talk
428.16|2.8| more about this when we talk about the bird model, though. So
430.96|5.08| this is just the overview. So in the next upcoming videos, I will
436.04|3.56| talk about these different types of models. Originally, I wanted
439.6|3.76| to cover everything in one video, but then I realized it's a
443.36|2.92| little bit too much material. But yeah, of course, this is
446.28|2.6| optional material, you don't have to watch this, it's up to
448.88|4.24| you. But the topics I will cover in the upcoming videos are the
453.12|5.56| original GPT model, it's called generative pre trained
458.68|7.48| transformer, that's why the name GPT like GPT, then we will talk
466.16|6.08| about bird, it's a bidirectional encoder here. And then we will
472.24|4.36| talk about GPT version two and version three. So the GPT
476.6|4.16| models are unidirectional, it's the next word prediction, and
480.76|5.0| bird is bidirectional. It's the main difference. And then the
485.76|5.28| bird model is combining both the bidirectional aspects from bird
491.28|5.0| with the unidirectional auto regressive behavior of the GPT
496.28|5.56| model. And then I will say a few more things about transformers
501.88|4.36| and the landscape, computational efficiency, and so forth. And
506.24|3.28| then after that, we will take a look at a code example. But yeah,
509.52|3.44| the upcoming videos regarding the popular transformer models,
512.96|4.52| bird GPT part, we will have six videos ahead where well, where I
517.48|26.52| will discuss them a little bit.