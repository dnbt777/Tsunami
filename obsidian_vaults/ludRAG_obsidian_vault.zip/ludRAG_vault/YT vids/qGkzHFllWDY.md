start_time|end_time|text
5.68|4.16|great okay perfect
7.359|5.121|so a sample from this model uh looks
9.84|5.679|like this so they also point to 99.6
12.48|5.52|billion dollars from 200 400 63
15.519|5.6|no um it's a bunch of kind of gibberish
18.0|4.96|um so the sentence isn't too coherent uh
21.119|3.281|but at least the words do seem to be
22.96|4.0|somewhat related like they come from the
24.4|2.56|same space
27.599|4.48|now jumping forwards to the beginning of
29.519|4.72|the deep learning room in 2011 we have
32.079|4.64|language modeling with neural networks
34.239|3.761|now and in particular with recurrent
36.719|2.961|neural networks
38.0|4.48|so we can get rid of this giant lookup
39.68|5.92|table from the engram models and instead
42.48|5.36|we can uh have our inputs be these
45.6|4.959|tokens and let this kind of recurrent
47.84|3.84|cell remember some state and persistent
50.559|3.761|state
51.68|4.08|so if we set up a neural model like this
54.32|3.44|we get a sample
55.76|3.52|as shown below so the meaning of life is
57.76|4.0|the tradition of the ancient human
59.28|4.56|reproduction is less favorable to the
61.76|3.039|good boy for one to remove bigger so
63.84|3.12|again
64.799|4.0|this doesn't really make any sense but
66.96|5.08|it kind of starts to have the flow of a
68.799|3.241|real sentence
72.24|5.76|yeah so jumping forward even more to
74.0|6.479|2016 we have lstm models and
78.0|4.64|um of course lstms are an architectural
80.479|4.081|innovation on top of rnns and they have
82.64|3.92|kind of better gradient flow so they're
84.56|4.0|better to they can better model
86.56|4.559|long-term dependencies
88.56|4.8|and so with an lstm model we get a
91.119|3.841|sample like this with even more new
93.36|3.92|technologies coming onto the market
94.96|4.4|quickly during the past three years an
97.28|3.6|increasing number of companies
99.36|3.2|must tackle the ever-changing and
100.88|3.519|ever-changing environmental challenges
102.56|3.44|online so this sentence is starting to
104.399|3.76|make a little bit of sense though there
106.0|5.6|are clear artifacts like the repetition
108.159|3.441|of the phrase ever changing
113.28|4.24|now starting in uh 2018 we have our
115.6|4.24|first auto aggressive transformer based
117.52|4.16|language models which are even better at
119.84|3.2|modeling these very long term uh
121.68|3.28|dependencies
123.04|3.759|and here what i'm showing is an example
124.96|4.32|of a completion so
126.799|5.281|in a completion you the user uh supplies
129.28|4.72|the prompt uh in this case it's this uh
132.08|4.4|text swings over kansas
134.0|3.92|and um the model will will continue from
136.48|3.28|this prompt
137.92|4.16|so you can see that uh this completion
139.76|4.64|is coherent across multiple sentences
142.08|4.32|now though there are notable spelling
144.4|4.479|mistakes so you see this like uh what
146.4|6.559|whatever document is so
148.879|4.08|uh it doesn't quite make sense
153.76|6.0|and now we arrive at gpg2 which is a 1.5
156.959|5.201|billion parameter transformer model
159.76|4.4|and i copied in what i personally found
162.16|3.359|was the most compelling completion from
164.16|2.32|gpd2
165.519|3.281|and
166.48|4.8|uh in contrast with the last slide what
168.8|4.079|this does is it sets up a clearly fake
171.28|3.2|prompt so this
172.879|4.08|uh we have something about finding
174.48|3.679|unicorns and scientists um in south
176.959|3.28|america
178.159|3.681|and so the model has probably not seen
180.239|4.0|this exact prompt before and has to make
181.84|3.28|up something that's consistent
184.239|3.121|so
185.12|4.16|the thing i find most impressive is
187.36|4.08|it does so and it's coherent across
189.28|5.039|multiple paragraphs it invents this
191.44|5.28|fictional dr perez and
194.319|4.161|it persists perez throughout multiple
196.72|3.76|paragraphs and
198.48|4.72|i think it's like very aptly named you
200.48|5.2|have him from university of la paz and
203.2|4.16|um yeah we just have fairly coherent
205.68|4.0|completions at this point
207.36|5.28|so it's worth disclosing that this was
209.68|5.279|the best of 10 samples so uh we still
212.64|5.04|have to sample uh multiple times to get
214.959|2.721|a sample like this
219.12|4.72|and finally uh to end this semester yeah
221.519|2.321|for sure
224.56|2.48|the
239.92|3.92|yeah so this is human judge yeah i'll
242.159|3.521|probably expand a little bit on that
243.84|4.24|more today yeah
245.68|5.119|so i want to end this kind of fly by
248.08|5.84|overview with gpd3
250.799|5.041|and since g52 already produces such
253.92|4.159|coherent text like uh
255.84|4.72|how do you characterize gp23 and i would
258.079|5.441|say that the best way to do so is that
260.56|4.639|say you took the best of like one
263.52|4.08|best out of five or ten completions from
265.199|4.881|ppd2 that would be kind of your first
267.6|5.039|conclusion from gpt3 and uh of course
270.08|3.6|best is kind of a personal uh metric
272.639|3.601|here
273.68|4.48|um so here i'm showing uh completion
276.24|3.679|from the the
278.16|2.8|three body problem um
279.919|3.28|and
280.96|3.84|you can see that the impressive things
283.199|5.28|about this completion are that it really
284.8|5.76|stays true to the style of of the novel
288.479|4.321|um i think the second thing that kind of
290.56|3.84|impressed me was just how poetic like
292.8|3.6|the metaphors and similes that it
294.4|3.519|produces are so you have this
296.4|3.04|stuff like blood was sleeping through
297.919|3.521|her jacket and a dark red flower is
299.44|4.16|blooming on her chest like uh he's kind
301.44|3.199|of like very very poetic and stylistic
303.6|2.48|sentences
304.639|3.361|so he definitely understands it's part
306.08|3.76|of a novel and it's trying to generate
308.0|4.88|this kind of prose that
309.84|5.199|in the same style
312.88|5.28|so as generated text becomes more and
315.039|6.16|more coherent i think one really outputs
318.16|5.28|how much bigger interest parameters
321.199|4.72|yeah yeah so it's 175 billion parameters
323.44|3.29|versus uh gpt2 which is one around one
325.919|5.23|vote
326.73|4.419|[Music]
331.199|4.56|do you feel like that
332.56|4.24|very subtle increase in accuracy
335.759|3.28|right
336.8|4.64|yeah yeah that's a very good question so
339.039|3.761|um there's kind of stuff maybe we can
341.44|3.28|dive into it a little bit after but
342.8|3.679|there is work on kind of neural scaling
344.72|3.44|laws and so the idea is like can you
346.479|4.081|predict the performance of a larger
348.16|4.319|model from a series of smaller models
350.56|3.52|and so i would rather characterize the
352.479|3.521|increase in performance not by kind of
354.08|4.0|the small gain in perplexity but like
356.0|5.6|whether it lines up with the projections
358.08|6.0|and in that sense gpt3 does um so
361.6|3.439|yeah that's some intuition for for yeah
364.08|2.239|i think
365.039|3.6|personally at open air we would have
366.319|5.841|stopped the experiment if it didn't so
368.639|3.521|yeah no i just think it's interesting
374.319|3.521|machine learning you see people pushing
376.0|4.24|for like an extra you know one percent
377.84|5.44|or like 25 percent accuracy but the
380.24|6.0|models are increasing in a scale that's
383.28|4.639|functional right so i wonder sometimes
386.24|4.48|whether it's worth it and like where you
387.919|4.481|should stop
390.72|3.52|right yeah i think maybe this side will
392.4|4.48|get to it a little bit but there's also
394.24|4.32|some sense in which like uh as you reach
396.88|4.319|kind of like the entropy floor of
398.56|5.28|modeling um like every having kind of
401.199|4.161|gives you uh like like
403.84|3.199|if you think about accuracy right that
405.36|3.839|it's not on a linear scale right like a
407.039|3.44|one percent early on isn't the same as
409.199|4.481|that last one
410.479|4.16|and so um yeah the those last bits
413.68|2.4|really do
414.639|3.361|help you squeeze a little bit out of
416.08|4.399|that okay
418.0|5.039|yep sorry
420.479|5.201|oh yes yes sorry this is accuracy and i
423.039|5.121|i will explain this yeah cool
425.68|4.239|so yeah um so as as generated text
428.16|3.84|becomes more and more realistic i think
429.919|3.761|one very natural question to ask is
432.0|4.24|whether humans can still distinguish
433.68|4.799|between real and fake attacks right and
436.24|4.48|so in here we have a
438.479|5.041|this is of course like a a very set up
440.72|4.72|scenario it's not in all cases the model
443.52|3.519|is able to trick humans but this is for
445.44|4.64|uh for news articles we kind of
447.039|5.28|presented gpt3 generated samples against
450.08|4.559|real news articles and you can tell kind
452.319|4.16|of as the number of parameters increases
454.639|4.721|the ability of humans to distinguish
456.479|5.12|between the real and fake articles
459.36|4.239|that ability goes down to near random
461.599|3.04|chance
463.599|4.481|oh yes
464.639|5.201|how did you generate the news articles
468.08|5.28|oh um i
469.84|6.16|i'm actually not completely sure um so
473.36|4.16|i didn't do this work particularly but i
476.0|3.68|i think one possible approach would be
477.52|4.0|to prime with a couple of news articles
479.68|3.44|and then just to have a delimiter and
481.52|3.28|just have it start generating user
483.12|3.759|requests from there
484.8|5.119|yeah
486.879|3.04|any other questions
491.52|2.64|great
492.56|3.919|so even with all these impressive
494.16|4.319|results i think it's worth taking a step
496.479|4.641|back at this point and asking what do we
498.479|4.881|really care about language modeling for
501.12|4.56|and what is it actually useful for
503.36|3.679|i think one can make the argument that
505.68|3.199|it is actually a fairly narrow
507.039|3.28|capability like why would you just want
508.879|3.201|some system that just
510.319|3.361|continues text for you
512.08|2.8|uh and you can argue that there's more
513.68|3.68|important tasks to solve like
514.88|4.159|summarization or translation
517.36|3.679|and i think most researchers at hokume i
519.039|5.201|would agree with this point of view and
521.039|4.641|in fact gpt was not really a
524.24|3.84|project that was focused on language
525.68|4.32|modeling as an end goal but mostly as a
528.08|3.6|tool to solve
530.0|3.2|a problem called unsupervised learning
531.68|4.32|which i'm going to go through in the
533.2|4.8|next couple of slides so i want to
536.0|4.8|do a history of language modeling at
538.0|4.88|open ai and hopefully motivate why we
540.8|3.92|ended up at the gpt series of models and
542.88|3.84|kind of how we arrive
544.72|6.239|there and hopefully it'll become much
546.72|5.92|more intuitive after this section
550.959|3.361|so the deep learning group started in
552.64|3.68|2012 with alex
554.32|4.24|which was a system that could take
556.32|4.88|images and labels and they could
558.56|4.959|classify images to their labels and uh
561.2|3.68|what we found with alexnet was these
563.519|3.041|systems were able to generalize
564.88|3.12|surprisingly well like you could take
566.56|3.52|data sets that weren't necessarily the
568.0|3.92|training distribution and you still have
570.08|3.52|pretty good features
571.92|3.76|and um since then this kind of
573.6|3.84|supervised approach has been really
575.68|3.52|really powerful right we've been able to
577.44|5.12|train models in many different domains
579.2|5.04|to classify uh very accurately
582.56|3.6|and you can even have some guarantees
584.24|4.48|that supervised learning will work well
586.16|4.56|so there's empirical risk minimization
588.72|4.239|and but the problem with supervised
590.72|4.32|learning is that oftentimes the labels
592.959|3.921|are scarce right uh especially in
595.04|3.919|language tests there isn't really that
596.88|4.079|many kind of uh text paired with their
598.959|3.88|summaries or too many pairs across
600.959|5.521|languages for instance
602.839|5.721|so collecting a lot of data can be not
606.48|4.16|too hard but actually scalably labeling
608.56|4.16|all of that data it could be very time
610.64|4.16|consuming and expensive
612.72|3.679|so the main problem with unsupervised
614.8|4.96|learning is can we also learn from
616.399|4.401|unlabeled data and this is a lot scarier
619.76|2.24|because
620.8|2.88|all of a sudden we're starting to
622.0|4.0|optimize an objective which isn't the
623.68|4.32|one we care about downstream right so
626.0|4.399|there's a lot of the guarantees that we
628.0|3.519|used to have we no longer longer
630.399|2.801|and
631.519|4.0|we can only kind of hope that we learn
633.2|5.84|some features that are adaptable to a
635.519|5.681|wide variety of demonstrative tasks
639.04|4.4|but nevertheless there's a reason to be
641.2|4.48|very optimistic in language
643.44|4.24|and the reason is that there is a huge
645.68|4.24|pro of unlabeled data and it's called
647.68|4.32|the internet and so the real question is
649.92|3.599|can we leverage all this unlabeled data
652.0|3.44|from the internet
653.519|4.241|to solve language tasks where we don't
655.44|4.399|really have that much data
657.76|3.6|and the hope is that if we kind of
659.839|3.12|pre-train this model on the internet
661.36|2.96|they'll see all of these words used in
662.959|2.88|different settings kind of understand
664.32|2.8|their relationships
665.839|3.12|and they'll be able to leverage this
667.12|4.8|kind of understanding for for any kind
668.959|4.56|of task to learn
671.92|3.76|so now that we've established why
673.519|4.0|language is such a good domain to try
675.68|4.08|unsupervised learning in let's talk
677.519|3.841|about why use generative models for it
679.76|3.28|and also why use autoregressive
681.36|3.44|generative models
683.04|3.84|and i do want to stress that a lot of
684.8|3.36|the guarantees we have with supervised
686.88|2.72|learning are no longer there for
688.16|3.44|unsupervised learning so some of these
689.6|3.76|arguments will be a little bit kind of
691.6|2.799|intuitive and
693.36|2.96|um
694.399|4.081|so the first argument i want to present
696.32|4.72|is this quote by richard feynman which
698.48|4.4|is uh pretty widespread so what i cannot
701.04|3.359|create i do not understand
702.88|4.32|right and there's the inverse of this
704.399|4.88|idea which we call analysis by synthesis
707.2|4.319|and it's what i can create i can also
709.279|5.441|understand and this has been studied by
711.519|5.281|um kind of josh tenenbaum there's um
714.72|4.16|definitely some kind of biological
716.8|3.279|motivation as well for it
718.88|2.32|um
720.079|2.961|but
721.2|2.639|the the idea here is that if you're able
723.04|2.16|to
723.839|2.961|create a language model which can
725.2|3.68|generate diverse samples that are
726.8|4.479|coherent then it must also build up
728.88|4.72|representations that can help you solve
731.279|4.24|language understanding tasks
733.6|4.479|and then the next question is why do we
735.519|4.721|use autoregressive models you might
738.079|4.241|argue that autoregressive models are a
740.24|3.52|kind of local objective right like
742.32|3.44|you're just predicting the next words
743.76|3.84|you could do really well with kind of
745.76|4.56|some n-gram approximation right like
747.6|4.08|what why why would it be good at solving
750.32|3.04|things that allow you to summarize an
751.68|3.839|entire piece of facts
753.36|4.88|and so an intuitive argument here could
755.519|4.961|be say that you wanted to do very well
758.24|3.2|on uh language modeling for a mystery
760.48|2.799|novel
761.44|4.0|and uh there's this grand reveal at the
763.279|4.321|end like oh like the culprit was and
765.44|4.56|then you want to predict that next token
767.6|3.84|and to do really well at that task you
770.0|3.36|really need to have a good understanding
771.44|3.68|of what happened in the story along with
773.36|3.2|all the twists and turns and maybe even
775.12|3.92|some of this kind of like deductive
776.56|2.48|reasoning
780.399|4.481|so the first sign of life oh
782.8|4.32|did you have a question
784.88|2.24|oh
788.16|3.679|so the first sign of life we had at open
789.839|4.401|eye was in the task of predicting
791.839|4.401|whether amazon reviews uh were positive
794.24|5.279|or negative and this was work done in
796.24|5.599|2017 so instead of training a classifier
799.519|4.641|in the kind of typical supervised way
801.839|4.401|what we did was we trained an lstm model
804.16|3.84|just to predict the next character in
806.24|3.68|amazon reviews
808.0|4.24|when we trained a linear model on the
809.92|4.96|features from this lspm what we found
812.24|5.44|surprisingly was like one of these cells
814.88|6.399|or one of these neurons was firing in
817.68|5.44|terms of uh predicting sentiment and um
821.279|3.68|positive activations for this neuron
823.12|4.159|corresponding to positive reviews and
824.959|4.56|negative activations to negative reviews
827.279|4.081|and this was despite not being not
829.519|2.801|seeing any of the labels at training
831.36|3.279|time
832.32|4.72|so you can even track kind of what this
834.639|4.0|neuron value is across a
837.04|3.12|sample so it's a little bit hard to read
838.639|3.041|but these are reviews where maybe
840.16|3.039|someone says oh i really like this film
841.68|3.68|but i didn't like this part and you can
843.199|6.0|kind of see the sentiments switching and
845.36|3.839|as you go from positive to negative
849.44|2.72|so yeah just predicting the next
851.12|5.079|character
852.16|4.039|resulted in oh yeah
868.079|5.76|and one neuron is firing with yeah just
870.88|5.759|uh outsized predictive power yeah
873.839|4.481|great so next uh gpg one was one of the
876.639|4.081|first demonstrations that this kind of
878.32|4.56|approach could work broadly for techs so
880.72|3.76|g51 was trained on the internet uh not
882.88|3.6|on amazon reviews anymore
884.48|3.919|and it was fine too on a bunch of
886.48|2.88|different downstream tasks
888.399|2.8|right and
889.36|4.32|and one thing to stress here was uh kind
891.199|4.0|of to your point that the um the fine
893.68|4.959|tuning was very
895.199|5.2|i guess minimally kind of uh you're not
898.639|5.2|kind of bashing the architecture apart
900.399|5.841|and and um kind of repurposing a new
903.839|5.601|module so it's just a new new head that
906.24|4.719|classifies uh for your your tasks and
909.44|3.199|make sure that you can
910.959|2.801|use this approach not just for sentence
912.639|3.041|analysis
913.76|3.759|but also for like entailment synaptic
915.68|5.279|similarity and getting sodas on a lot of
917.519|3.44|these benchmarks downstream
921.519|3.68|so i've already presented gpg2 from the
923.839|3.68|point of view of a very powerful
925.199|4.161|language model and now i think it's
927.519|3.601|worth revisiting from the viewpoint of
929.36|4.24|unsupervised learning
931.12|4.719|so like gpt-1 gpg2 was trained on a
933.6|3.84|large chunk of the internet
935.839|3.68|and it's only trained to predict the
937.44|4.959|next token or word uh from previous
939.519|4.88|words but the key insight of gpd2 is
942.399|4.321|that many downstream tasks can be
944.399|3.68|expressed naturally as a language model
946.72|4.239|in the past
948.079|4.801|and yeah so gpt2 explores how well we
950.959|3.44|can perform on downstream tasks simply
952.88|2.879|by using this method without any
954.399|2.8|fine-tuning
955.759|3.921|right so let me start with a couple of
957.199|4.961|examples so let's say you want to solve
959.68|4.48|some reading comprehension benchmark and
962.16|3.44|this is usually set up as a prompt which
964.16|2.799|is some passage you have to read and
965.6|3.52|then a bunch of questions which you have
966.959|5.041|to answer so you can literally just
969.12|4.8|stick the entire prompting context you
972.0|4.0|put a question colon you write out the
973.92|4.159|question answer colon and then have the
976.0|3.759|model complete from there and this kind
978.079|4.481|of gives you zero shot reading
979.759|4.561|comprehension
982.56|3.519|we can also use it for other
984.32|4.16|tasks like summarization for instance
986.079|5.76|here's like a first the beginning of a
988.48|5.599|cnn article about kind of some some
991.839|6.081|archaeological finding and you can just
994.079|5.44|put tldr after you you see this passage
997.92|5.279|and the model hopefully if it's good
999.519|3.68|enough will produce good summaries
1004.16|3.599|and the final example i want to show is
1005.759|3.041|that you can do zero shot translation as
1007.759|1.841|well
1008.8|2.479|so
1009.6|3.52|the way you would do this is if you
1011.279|3.601|wanted to convert let's say a french
1013.12|4.079|sentence into english you could set up a
1014.88|4.0|prompt like the sentence insert defense
1017.199|3.041|sentence translated from french to
1018.88|3.36|english means
1020.24|3.12|and then the model will complete um and
1022.24|3.52|they can
1023.36|4.4|sometimes do this well and one kind of
1025.76|4.079|critical thing to note here is that uh
1027.76|3.919|here's the chart of performance as you
1029.839|3.761|increase the number of parameters
1031.679|3.76|um and
1033.6|3.28|um
1035.439|3.041|in all these models they were trained on
1036.88|3.439|the same data set so the only kind of
1038.48|3.199|compounding variable is scale
1040.319|2.88|and you can see that as we scale up the
1041.679|2.88|models these kind of zero-shot
1043.199|3.921|capabilities
1044.559|5.12|emerge or and kind of
1047.12|4.24|smoothly get better so the role of scale
1049.679|3.921|is important here
1051.36|4.48|and yeah and i think these are starting
1053.6|3.6|to approach some i guess they're not
1055.84|2.959|great benchmarks but at least
1057.2|3.839|respectable
1058.799|2.24|yep
1061.6|3.439|yeah yeah yeah exactly it's not going to
1063.36|3.92|be great in a lot of cases and to be
1065.039|4.721|honest like uh the the blue metric used
1067.28|4.399|for translation is actually often oh
1069.76|3.68|thank you very much um
1071.679|3.601|it's not a great metric what it does is
1073.44|3.84|it takes a reference solution
1075.28|4.399|and um basically
1077.28|3.36|it does some kind of engram comparison
1079.679|1.841|so
1080.64|2.96|um
1081.52|6.32|it is a big problem to have good
1083.6|6.64|translation metrics uh in nlp and yeah i
1087.84|5.959|i think um when i talk about code i will
1090.24|3.559|talk a little bit more
1095.6|4.72|right so let's finally talk about how
1097.76|5.039|gpg3 fits into this picture
1100.32|4.56|so the primary insight of gpd3 is that
1102.799|4.081|the training process itself can be
1104.88|3.28|interpreted in the context of metaler
1106.88|3.28|which is kind of like learning over
1108.16|3.68|distribution of tasks
1110.16|3.28|and uh during training what the model's
1111.84|3.199|doing is it's developing certain kind of
1113.44|2.72|capabilities it's
1115.039|3.361|um
1116.16|4.24|picking up some set of like
1118.4|3.2|skills in terms of modeling uh certain
1120.4|2.72|passages
1121.6|2.88|and um
1123.12|2.88|during inference time when it's what
1124.48|3.92|it's doing it's kind of quickly picking
1126.0|4.4|up on what a task is based on what the
1128.4|3.519|prompt is so far and
1130.4|3.44|adapting to that task to predict the
1131.919|4.64|next token so you can kind of view
1133.84|4.719|there's this outward loop of all the sgd
1136.559|4.161|steps you're doing during training and
1138.559|3.761|this inward loop of kind of picking up
1140.72|3.28|on what the task is and then modeling
1142.32|4.239|the next token
1144.0|4.0|so you can imagine a lot of
1146.559|2.881|tasks being framed in this way for
1148.0|2.96|instance on the left you can have
1149.44|4.32|addition kind of you you have a lot of
1150.96|5.12|examples of which machine context and
1153.76|4.56|hopefully that would help you with a new
1156.08|4.88|addition problem or you can try to
1158.32|4.8|unscramble a word for instance and i'll
1160.96|4.16|explore uh results on on these two kind
1163.12|2.88|of benchmarks in the next slides
1165.12|2.88|so
1166.0|4.32|this setting we call fuchsia arithmetic
1168.0|3.919|and just to explain what's going on
1170.32|3.599|you're taking the entire context length
1171.919|4.161|of your transformer and you're putting
1173.919|4.64|in as many examples as will fit
1176.08|4.24|and then finally you put in the the
1178.559|4.161|example that you would like to solve
1180.32|4.08|so uh here like uh these examples could
1182.72|4.4|be um
1184.4|5.519|these kind of first three addition
1187.12|5.6|problems and then you you have 31 plus
1189.919|5.041|41 equals and yes model to complete
1192.72|4.079|so you notice that as the language model
1194.96|4.4|gets bigger it's better able to
1196.799|5.041|recognize this task and you can see that
1199.36|3.439|kind of performance on on addition
1201.84|3.6|subtraction even some kind of
1202.799|4.801|multiplication tasks increases sharply
1205.44|3.92|as you as you go towards 200 billion
1207.6|3.36|parameters and there just seems to be
1209.36|2.88|kind of some step function change right
1210.96|4.56|here
1212.24|5.919|and uh looking at word unscrambling uh
1215.52|4.399|this is also true so um we have
1218.159|3.441|parameters again on the x-axis we have
1219.919|3.361|accuracy and each of these is a
1221.6|3.68|different kind of unscrambled task so
1223.28|3.519|this blue line is you kind of do a
1225.28|4.24|cyclic shift of the letters and you want
1226.799|4.401|it to uncycle um and there's a lot of
1229.52|5.96|other transforms you can do like
1231.2|4.28|randomly in certain words for instance
1236.64|4.48|so the final point here is that this is
1239.52|3.76|a pretty general phenomenon we didn't
1241.12|3.84|just test it on on these two
1243.28|4.32|aforementioned tasks
1244.96|5.04|we tried an array of i think 40 plus
1247.6|4.4|tasks and here you can see how the zero
1250.0|4.559|shot one shot and fu shot performance
1252.0|4.64|increases as we scale the models so of
1254.559|4.0|course they're all smoothly increasing
1256.64|4.159|but one thing to to be aware of is that
1258.559|6.48|the gap between zero shot and fuchsia is
1260.799|4.24|also improving as a function of scale
1267.679|3.041|awesome
1268.96|3.92|so we've just seen that we can pre-train
1270.72|5.16|the transfer oh good
1272.88|3.0|yeah
1278.4|4.88|one is the tasks
1281.12|4.64|themselves that were used two is the
1283.28|4.08|number of parameters and then three my
1285.76|3.52|understanding is also the quantity that
1287.36|3.92|was suggested yeah i was curious sort of
1289.28|3.68|between those three which ones it's
1291.28|3.68|you've shown a lot of them because the
1292.96|3.52|number of parameters definitely helps i
1294.96|3.76|was curious knowing what i said so the
1296.48|3.84|degree to which also the training tasks
1298.72|3.6|and the sophistication of the tasks as
1300.32|2.88|well as the quantity of the adjusted
1302.32|2.88|habits
1303.2|4.16|yeah yeah um so
1305.2|4.719|i guess i can dive maybe it's something
1307.36|5.12|to save for for after but um yeah yeah
1309.919|4.481|let's dig into that after yes
1312.48|2.64|yeah
1314.4|4.32|right
1315.12|5.919|um i guess g52 and three are different
1318.72|5.199|gpd one just has an extra classification
1321.039|4.481|head for certain tasks yeah
1323.919|3.601|yeah
1325.52|4.24|great yeah good questions
1327.52|3.68|so yeah we've just seen that we can use
1329.76|3.52|a transformer in this kind of
1331.2|4.0|pre-trained and binding setup where we
1333.28|4.48|have some kind of a lot of unlabeled
1335.2|4.0|data um in the pre-training setting and
1337.76|3.36|we have just a little bit of data in the
1339.2|5.04|fine-tuning setting and we can solve a
1341.12|4.64|lot of language tasks in in this way um
1344.24|3.439|and i would say this has become the
1345.76|3.84|dominant paradigm in language over the
1347.679|4.24|last couple of years so uh there's
1349.6|3.76|follow-up objectives like bert and t5
1351.919|3.041|which have done extremely good at
1353.36|3.12|pushing the soda
1354.96|3.36|but there's nothing really that says
1356.48|4.559|that these transformer models have to be
1358.32|4.56|applied to language the transformer is a
1361.039|4.481|sequence model and as such it can just
1362.88|4.56|ingest any sequence of bytes and and
1365.52|4.0|model them and when you think about this
1367.44|4.4|like all the data that we consume like
1369.52|3.92|videos or audio they're represented on
1371.84|4.079|our computers as sequences of bytes
1373.44|4.32|right and so you might think oh
1375.919|4.88|could this approach be used to just
1377.76|5.76|model whatever modality we want
1380.799|4.641|and i think this kind of
1383.52|4.48|paradigm is very
1385.44|4.16|at least interesting when when we don't
1388.0|3.679|really have good inductive biases like
1389.6|4.0|we don't so we don't
1391.679|3.441|but one question to ask is does it even
1393.6|3.76|work when you do have really strong
1395.12|4.32|inductive biases so
1397.36|4.0|uh i'm going to present
1399.44|4.16|some work that suggests that the answer
1401.36|5.199|is yes this still works fairly well in
1403.6|4.559|this case um in in the domain of images
1406.559|3.6|where convolutions are already so
1408.159|3.841|popular and proven out
1410.159|3.76|and i'm going to show a second result
1412.0|4.24|very briefly here which is uh dali which
1413.919|4.481|shows that it's strong enough to even
1416.24|4.96|ingest two different modalities and and
1418.4|2.8|be able to jointly
1422.4|4.24|so the first question is how would you
1424.0|4.24|apply gpt to images
1426.64|3.68|and there's a few things you have to do
1428.24|3.76|you have to modify this auto aggressive
1430.32|2.719|next word prediction
1432.0|3.039|objective
1433.039|4.481|so the natural analog is you can think
1435.039|4.88|of images as a very strange language
1437.52|4.56|where the words are pixels instead and
1439.919|4.321|instead you you need to predict the next
1442.08|3.599|pixel at each point and so we can just
1444.24|3.76|change the objective from next word
1445.679|4.321|prediction to next pixel prediction
1448.0|4.0|and of course we want this kind of uh
1450.0|4.08|large yep
1452.0|4.08|[Music]
1454.08|4.32|oh yeah so you just unroll it as a
1456.08|3.76|sequence it's the same way it's uh it's
1458.4|3.36|stored on a computer you just have like
1459.84|2.8|a sequence device yeah yeah good
1461.76|3.519|question
1462.64|4.399|um so in the language setting uh we
1465.279|2.481|pre-train on this large unlabeled data
1467.039|3.281|set
1467.76|4.08|um on the internet and we fine tune on
1470.32|4.239|uh question answering or these other
1471.84|4.4|benchmarks and then images um one good
1474.559|3.921|analog of this situation is you can
1476.24|4.319|pre-train on imagenet without the labels
1478.48|4.319|you have a let's say a low resource uh
1480.559|4.281|low data sorry setting like so far and
1482.799|3.921|you can uh try to attack safari
1484.84|4.04|classification and of course in both
1486.72|4.0|settings you can do fine tuning in gpd
1488.88|4.32|you can do zero shot and i would say the
1490.72|4.16|standard eval on images is you do linear
1493.2|4.32|probes so you take features from your
1494.88|4.799|model um the model is frozen you like
1497.52|3.84|pass through so far through do the model
1499.679|3.521|get some features and you see how
1501.36|4.559|predictive these features are of the
1503.2|4.88|safari classes
1505.919|4.24|is it kind of pixels here which
1508.08|4.0|basically you asked motor to predict the
1510.159|3.681|nice pixel given the
1512.08|3.52|yeah yeah so pixel cnn is an
1513.84|2.64|instantiation of an auto-aggressive
1515.6|2.88|image
1516.48|3.52|model um so what we're asking here is
1518.48|3.199|can we actually take the same
1520.0|3.84|transformer architecture that we use in
1521.679|3.441|language don't make any modifications at
1523.84|4.079|all and just throw
1525.12|5.12|uh so there's no kind of 2d
1527.919|2.321|prior
1532.48|5.6|so yeah i i i'll call this a model that
1534.96|4.56|we train in http or igp2 for sure and uh
1538.08|3.52|here you can see actually what some
1539.52|4.48|completions from the model look like
1541.6|4.559|so on the left column what i'm feeding
1544.0|3.279|in is the pixels of the first half of
1546.159|3.041|the image
1547.279|3.201|and the next four columns what you're
1549.2|3.76|seeing is
1550.48|4.559|different model generated completions
1552.96|4.24|and the right column here is the
1555.039|3.921|original reference image and you can
1557.2|3.04|actually see that the model is kind of
1558.96|2.88|doing some interesting things right if
1560.24|3.28|you look at the last two rows it's not
1561.84|3.76|coming up with kind of symmetrically the
1563.52|3.279|same completion every single time uh
1565.6|2.559|it's like putting these birds in
1566.799|3.041|different settings sometimes adding
1568.159|3.441|reflections
1569.84|5.04|is putting this lighthouse in grassy
1571.6|5.36|areas and like watery areas for instance
1574.88|5.039|so if you buy into this philosophy of
1576.96|7.28|analysis by synthesis we definitely
1579.919|5.841|have some hint of the synthesis part
1584.24|3.36|so i don't have time to go through all
1585.76|4.159|the results with you but i just want to
1587.6|4.16|say that it is fairly successful in this
1589.919|4.161|uh safar setting where where you don't
1591.76|4.72|have much labeled data if you train a
1594.08|5.36|linear model on top of the features you
1596.48|4.88|get um better results than if you
1599.44|4.16|uh do the same approach with a resnet
1601.36|3.919|train downhill whistle so that that's
1603.6|3.28|like the typical approach in the field
1605.279|3.681|you train some resident on imagenet you
1606.88|4.08|get the features oh yeah
1608.96|4.4|oh yeah and if you compare to yeah this
1610.96|4.319|approach generate a generator's model on
1613.36|4.08|imagenet without the labels take the
1615.279|3.681|features it's actually uh better
1617.44|3.2|predictive
1618.96|3.28|yeah
1620.64|2.88|what's the architecture for this is the
1622.24|3.36|same oh yeah
1623.52|5.759|it's exactly yeah yeah yeah yeah it's
1625.6|6.559|the gpu yeah yeah so this um
1629.279|4.4|so you can modify gpt to to have like 2d
1632.159|2.801|bias that you can do to the position
1633.679|2.24|embeddings but we don't do that we just
1634.96|5.8|want to see
1635.919|4.841|can you use the same exact approach yeah
1640.96|3.12|yeah but also there's like metadata
1642.559|4.161|showing about how that sequential should
1644.08|4.319|be reconstructed so like what's the wick
1646.72|4.64|for example oh uh
1648.399|6.481|what can you expect
1651.36|4.72|so the data on this story yes
1654.88|3.12|but when you want to transform the
1656.08|3.28|sequence into an image you have metadata
1658.0|3.279|that will say something like just like
1659.36|3.679|in numpy erase it'll say here's the
1661.279|3.921|stride yeah yeah so you're just going to
1663.039|3.921|rearrange it
1665.2|3.28|what i'm curious to notice is dpt before
1666.96|3.04|it's given an image at least given this
1668.48|3.04|metadata
1670.0|3.279|i see i see okay yeah that's an
1671.52|3.44|extremely good question um
1673.279|2.721|i don't know how this problem is solved
1674.96|3.599|yeah yeah
1676.0|5.039|in this case um we all the images are
1678.559|4.321|have the same shape oh okay okay
1681.039|3.52|okay
1682.88|3.84|yeah so but we don't tell it like the
1684.559|3.441|concept of row within the model like uh
1686.72|2.88|yeah
1688.0|4.24|yeah yeah so it needs to learn it from
1689.6|3.76|the data but yeah the the data looks
1692.24|3.12|like yeah it'll be interesting if it's
1693.36|5.439|like variable image shapes then this
1695.36|5.679|could be like a way to do it yeah yeah
1698.799|2.24|cool
1701.279|4.801|aren't they like
1702.48|5.52|a lot more pixels than their token sizes
1706.08|5.12|uh yeah so this is a pretty low
1708.0|4.24|resolution images um yeah so we can
1711.2|2.479|actually
1712.24|2.88|the the models we're comparing guts are
1713.679|3.12|trained on kind of high resolution
1715.12|3.6|images so i think that makes it even
1716.799|5.841|more impressive um oh yeah we're just
1718.72|3.92|training at 32 by 32 resolution
1723.2|4.88|cool so if we fine-tune these models for
1725.76|5.36|safer classification we can get 99
1728.08|5.04|accuracy which uh matches sheet pipe and
1731.12|4.24|this is g5 for instance is a system
1733.12|3.84|which is uh trained on imagenet with
1735.36|4.799|labels and then also fine-tuned with
1736.96|5.439|labels so yeah it just kind of shows you
1740.159|4.321|even this approach which doesn't really
1742.399|3.121|know about convolutions can do well i
1744.48|4.88|think you're going to hear more about
1745.52|3.84|that next week with lucas's talk
1750.08|3.04|so
1751.039|3.76|by now it shouldn't be surprising at all
1753.12|3.919|that you can model a lot of different
1754.799|4.321|modalities with transformers
1757.039|4.081|so in dolly we just ask
1759.12|3.84|uh what about throwing two different
1761.12|4.48|modalities at the model and seeing if we
1762.96|4.48|can learn kind of uh how to condition on
1765.6|4.0|text to produce an image
1767.44|4.32|and um for instance one thing you might
1769.6|3.6|want it to do is like you you provide
1771.76|3.12|one of these text captions and you want
1773.2|3.76|it to generate some image like the one
1774.88|4.08|below and the easy way to do this is
1776.96|4.56|just train a transformer on the
1778.96|4.56|concatenation of a caption in an image
1781.52|4.159|and of course uh in a lot of these
1783.52|4.72|situations like the idea is very simple
1785.679|4.401|but the implementation and execution is
1788.24|2.96|where the difficulty is and i'm not
1790.08|3.04|going to talk too much about that i
1791.2|3.44|think the focus today is on language but
1793.12|4.24|you can refer to the paper for a lot of
1794.64|2.72|those details
1802.0|5.52|oh yeah so you you like say have a max
1805.12|4.08|captain uh length and you just kind of
1807.52|4.8|cut it off at that length and you can
1809.2|3.12|pad up to that one
1813.84|3.52|right so you can see that uh it can
1815.2|3.839|generate fairly good samples um so if
1817.36|3.76|you want like a storefront with the word
1819.039|4.0|open the eye on it it's not perfect um
1821.12|4.48|but it's unjust at least it's kind of
1823.039|4.64|like reverse ocr problem where you you
1825.6|4.0|take some text and render it uh and it's
1827.679|4.72|kind of typically rendering it in like
1829.6|4.88|office looking places so
1832.399|4.88|uh that's one encouraging sign but i do
1834.48|4.799|think my my favorite results here are uh
1837.279|4.081|zero shocking issue image transformation
1839.279|4.321|so what's going on here is for instance
1841.36|5.12|if your prompt is the exact same cat on
1843.6|4.64|the top as as a sketch on the bottom and
1846.48|4.16|you feed in the top half of it this
1848.24|3.84|image which is a cap
1850.64|3.36|and you ask it to complete the rest of
1852.08|4.0|the image then it'll render the the top
1854.0|4.08|cat actually as like a
1856.08|4.0|um a sketch and you can do the same
1858.08|4.88|thing with like flipping over photos for
1860.08|5.12|instance uh you can zoom in to a photo
1862.96|3.76|of course they're not perfect um but it
1865.2|4.24|has some understanding of what the text
1866.72|5.839|is trying to do yeah um in the captions
1869.44|4.8|originally uh like the training uh in
1872.559|5.6|the training set do they have like
1874.24|3.919|wording such as extreme close-up view
1880.399|2.561|are some examples like that and that's
1881.84|2.959|probably where it's picking up some of
1882.96|4.8|this knowledge from though we don't seek
1884.799|5.681|out these examples um it's just uh yeah
1887.76|2.72|yeah exactly
1890.799|5.36|okay perfect yeah so this is just that
1893.36|4.4|we just go and and do a do a massive web
1896.159|3.841|script there's no kind of we're not
1897.76|4.24|trying to find the examples like this
1900.0|3.76|right and so you can also do things like
1902.0|4.0|colorization right you can take the cat
1903.76|4.96|color red and this has to like kind of
1906.0|4.72|recognize that what the object is in in
1908.72|3.76|the figure um and
1910.72|3.92|yeah and here you can do
1912.48|5.199|stuff like semantic transformations like
1914.64|4.72|adding sunglasses uh into the cat and
1917.679|3.761|you can put it on postage for instance
1919.36|3.199|yeah so this remarkably that you can do
1921.44|3.04|a lot of these like
1922.559|6.081|transform zero shots um it wasn't
1924.48|4.16|trained to do these things specifically
1930.72|2.799|cool
1931.76|4.08|so moving on uh the last section of my
1933.519|6.081|talk today is on codex which is our most
1935.84|5.199|recently released code writing models
1939.6|4.0|and the first question you should
1941.039|4.88|rightly ask here is um
1943.6|4.0|why why train a model on code anyway is
1945.919|3.041|it at this point isn't it just another
1947.6|2.4|modality
1948.96|3.04|and
1950.0|3.76|what is the novelty that that there is
1952.0|4.159|at this point right um so let me give
1953.76|4.48|you a couple of reasons
1956.159|4.161|so first is that gpg3 it had a
1958.24|4.64|rudimentary ability to write python code
1960.32|5.04|already from a doc string or descriptive
1962.88|4.639|method name and we actually didn't train
1965.36|3.6|it on much code data actually i think
1967.519|3.121|there might have been active filtering
1968.96|3.199|to get rid of code data and so we were
1970.64|3.84|surprised that there was this capability
1972.159|4.24|anyway so that you know like if we
1974.48|3.6|actually purpose the model and trade it
1976.399|3.28|on the large amount of code that we can
1978.08|3.439|find maybe something interesting will
1979.679|4.321|happen there
1981.519|4.721|uh next what sets apart code from other
1984.0|5.519|modalities is that there is a kind of
1986.24|5.6|ground truth correctness of a sample and
1989.519|4.241|functions can be tested with unit tests
1991.84|3.839|and an interpreter so this is very
1993.76|3.36|different from language whereas uh to
1995.679|3.281|get a ground truth eval you might need a
1997.12|3.439|human to come in and even then sometimes
1998.96|3.199|humans won't agree like this this is the
2000.559|3.12|better example or this isn't the better
2002.159|3.841|sample
2003.679|4.321|and uh last thing is i used to dabble in
2006.0|3.519|competitive programming myself and yeah
2008.0|4.88|i really wanted to create a model that
2009.519|3.361|could solve problems that i couldn't
2013.519|1.841|cool
2014.48|4.36|so
2015.36|3.48|if yeah
2028.159|4.64|is kind of high level
2030.32|4.88|programming language which is similar to
2032.799|4.72|like our human language so
2035.2|4.88|have you guys ever tried to predict some
2037.519|6.081|even lower level language like
2040.08|5.52|cpp yeah yeah yeah um hey
2043.6|3.52|i think there's yeah there's follow-up
2045.6|3.92|work where we just train on a bunch of
2047.12|4.959|different languages and i don't know the
2049.52|4.879|metrics off the top of my head but i i
2052.079|4.961|have seen some assembly uh writing
2054.399|4.161|models before yeah
2057.04|4.16|cool um
2058.56|4.88|so i guess yeah um continue on the third
2061.2|3.52|from before so we have this this uh
2063.44|3.36|setting where we have unit test and
2064.72|4.399|interpreter so how do we actually
2066.8|4.319|evaluate um these models in a way that's
2069.119|3.841|kind of aware of these two concepts so
2071.119|4.8|the first thing we did was we have a
2072.96|5.199|data set a new data set which is 164
2075.919|4.561|handwritten programming problems
2078.159|4.401|and um these kind of have the format
2080.48|4.8|shown here like there's a function name
2082.56|4.079|a doc string there's a solution
2085.28|3.52|and there's an average of around eight
2086.639|3.921|unit tests per problem and why is it
2088.8|3.76|important that we hand wrote these well
2090.56|4.319|the thing is we're training on such a
2092.56|3.839|large part of github like if you said
2094.879|3.121|okay i'm gonna take like some vco
2096.399|3.361|problems and i'm gonna turn them into an
2098.0|3.599|evaluation that's not gonna work because
2099.76|4.079|there's just so many github repos that
2101.599|4.321|are like oh here's the solution to this
2103.839|3.441|problem so while this doesn't
2105.92|3.76|kind of guarantee that this problem
2107.28|3.839|isn't duplicated at least someone wrote
2109.68|3.28|it without trying to copy it from
2111.119|3.441|another source
2112.96|4.399|um
2114.56|5.039|so here's some kind of examples of unit
2117.359|5.201|tests that you would uh evaluate the
2119.599|4.801|previous function on um i think it's
2122.56|3.68|should be fairly clear that we should be
2124.4|3.36|using this metric uh like this is the
2126.24|3.92|correct kind of ground truth metric to
2127.76|4.24|use i mean humans do use unit tests to
2130.16|3.439|evaluate code and i would say like um if
2132.0|3.44|you're familiar with competitive
2133.599|3.52|programming like you can't manually
2135.44|3.28|judge all like tens of thousands of
2137.119|3.441|submissions that are coming in you need
2138.72|3.76|the unit tests and that is a fairly good
2140.56|4.0|filter
2142.48|4.16|so one interesting point here was uh we
2144.56|3.279|had to create a sandbox environment to
2146.64|3.12|run these um
2147.839|3.121|these kind of generated solutions in
2149.76|3.04|because when you train on github there's
2150.96|3.6|a bunch of malicious code there's a
2152.8|3.2|bunch of kind of insecure code you know
2154.56|2.559|all your models should be sampling that
2156.0|3.839|and kind of running that on your
2157.119|2.72|environment
2160.0|5.04|cool so now that we have an evaluation
2162.32|4.48|data set uh let's define a metric on it
2165.04|3.2|and so the metric we're going to use is
2166.8|2.96|called pass k
2168.24|3.599|and the definition is the average
2169.76|4.96|probability over all the problems that
2171.839|5.121|at least one out of k samples passes the
2174.72|3.04|unit tests
2176.96|2.96|so
2177.76|3.92|if we evaluate this metric by just
2179.92|4.96|taking every problem and exactly
2181.68|5.36|generating kd samples it's actually not
2184.88|3.76|there's high variance uh just kind of
2187.04|3.44|sampling in that way like imagine the
2188.64|4.0|pass rate of a particular sample is
2190.48|4.4|around one over k like uh this is kind
2192.64|5.68|of like an all or nothing metric so
2194.88|5.199|um what we do instead is we generate a
2198.32|3.2|much larger set of samples and greater
2200.079|4.561|than k most of the times it's like
2201.52|4.88|greater than 5k um and we count the
2204.64|4.0|number that are correct and we compute
2206.4|3.76|this unbiased estimator and uh it looks
2208.64|3.04|more complicated than it actually is
2210.16|4.24|it's just complementary accounting you
2211.68|6.08|uh you take kind of uh the number of
2214.4|3.36|combos where all of them fail
2219.68|3.2|cool
2220.4|4.719|so then uh we train our model and uh
2222.88|3.84|like i alluded to earlier uh there's
2225.119|4.321|165
2226.72|5.44|about 160 gigabytes of uh code which is
2229.44|4.56|collected from 54 million repositories
2232.16|4.24|um for efficient training what we did
2234.0|5.04|was we fine-tuned from gpt3 models of
2236.4|4.64|various sizes and um this isn't actually
2239.04|4.559|strictly necessary we find that we can
2241.04|4.559|get to roughly the same uh final loss
2243.599|4.401|and performance without kiss but it is
2245.599|4.0|slower to do it without um without this
2248.0|4.24|returning step and so we already have
2249.599|4.881|these models why not just find from them
2252.24|4.879|and um one extra trick to make training
2254.48|4.879|much faster here is in uh code there's a
2257.119|3.761|lot of runs of spaces right and those
2259.359|3.76|don't get compressed efficiently in
2260.88|4.88|language because you just don't see them
2263.119|5.761|very often so they typically get broken
2265.76|5.52|up into like many separate tokens so we
2268.88|4.64|introduce additionally some tokens that
2271.28|4.4|compress runs of one space and that
2273.52|4.0|makes training maybe like uh
2275.68|4.56|thirty or forty percent more efficient
2277.52|6.52|so this totally won't just be us
2280.24|3.8|yeah exactly yeah
2284.32|3.84|great so once we have these models we
2286.079|4.561|can go and revisit the human eval data
2288.16|3.919|set and i can share a couple of problems
2290.64|4.4|uh to give you a sense of where the
2292.079|4.76|models are at and also what kind of uh
2295.04|3.12|difficulty level the problems in the
2296.839|3.161|data center
2298.16|4.72|so this is a 12 billion parameter model
2300.0|5.04|that passed out is 90 which means that
2302.88|4.479|90 of the samples will pass the unit
2305.04|4.64|test and this is very something like
2307.359|4.401|anyone kind of doing a first day of
2309.68|4.159|python would be able to do so you uh
2311.76|3.839|increment uh all the elements of the
2313.839|2.561|list by one
2315.599|2.561|um
2316.4|4.08|here is a problem where the pass rate is
2318.16|4.64|17 so this is a solution i gave that's
2320.48|4.32|the problem i gave earlier so you are
2322.8|3.76|given a non-empty list of integers you
2324.8|3.36|want to return the sum of odd elements
2326.56|2.88|that are in even positions this might
2328.16|3.199|not sound that much harder to you but
2329.44|4.0|models can often get confused about like
2331.359|4.48|oh like it's odds referring to positions
2333.44|4.08|or elements um and so here you can
2335.839|4.681|actually see that it's doing the right
2337.52|3.0|thing
2340.72|3.76|and uh finally this is an example of
2343.04|3.52|one of the harder problems in the data
2344.48|3.92|set so the password is under one percent
2346.56|3.2|here and so what's going on here is
2348.4|3.28|actually there's an encode function
2349.76|3.76|which takes a string it kind of chunks
2351.68|3.12|it up into groups of uh
2353.52|2.88|three characters and it doesn't stick
2354.8|3.44|like shift on each character and you
2356.4|3.84|have to write a decoder uh something
2358.24|2.8|that reverses this operation
2360.24|2.879|um
2361.04|3.68|so uh you can see that
2363.119|3.681|the model this is a real model solution
2364.72|3.68|so it chunks up the
2366.8|2.96|characters in the same way you can see
2368.4|2.88|that the cyclic shift is the opposite
2369.76|3.52|way so um
2371.28|3.839|up there it takes the first element of
2373.28|5.2|each group moves it to the end and now
2375.119|3.361|takes the last element of each group
2379.04|4.64|okay as i'm wondering um what's the
2381.76|3.04|effect of so like you had a couple of
2383.68|3.919|examples
2384.8|5.44|like this in the comments so like i'm
2387.599|5.041|wondering if the model will be able to
2390.24|4.32|um extrapolate what it's doing by the
2392.64|3.92|examples alone and not relying on the
2394.56|3.76|system right yeah so some of our tasks
2396.56|3.68|there are uh some examples in the
2398.32|3.519|docstream um and some of them don't i
2400.24|4.64|think it's just to kind of match the
2401.839|5.76|distribution of um real kind of tasks we
2404.88|4.16|find uh in the real world like in this
2407.599|3.601|case it doesn't have it but definitely
2409.04|4.4|for the unit test none of those appear
2411.2|4.56|within i'm just i'm just curious like if
2413.44|4.56|you just give it the examples and not do
2415.76|4.48|the description of the task
2418.0|3.68|oh i see i see so can you do like pure
2420.24|4.64|induction where you like don't tell the
2421.68|5.12|task at all um yeah um i
2424.88|5.76|haven't tried it to be honest um i think
2426.8|3.84|it's worth a shot yeah thanks
2431.2|3.28|yep
2432.0|4.56|so yeah at this point um we've trained
2434.48|4.08|codex models we've evaluated on on this
2436.56|4.16|metric the thing is like was it worth
2438.56|3.68|all this trouble right um you you
2440.72|4.56|already have these metrics like blue
2442.24|4.8|that are match based um in language um
2445.28|3.28|couldn't we have just used this to box
2447.04|3.279|we don't need like an interpreter we
2448.56|4.0|don't need like to generate so many
2450.319|4.881|samples and it would be great if like it
2452.56|5.039|kind of like separated out like this um
2455.2|4.399|but what we find is that
2457.599|3.841|this is uh if you take four random
2459.599|3.361|problems from human eval
2461.44|4.159|and you plot the distribution of blue
2462.96|3.76|scores for correct and wrong solutions
2465.599|3.201|you actually find a lot of
2466.72|5.119|distributional overlap right like uh
2468.8|5.039|it's hard to distinguish like
2471.839|4.161|the green from the blue distribution
2473.839|4.0|and so this suggests that blue actually
2476.0|3.28|isn't a very good metric for gauging
2477.839|3.841|functional correctness and that we
2479.28|6.319|actually do need this this new kind of
2481.68|3.919|metric and this this new data set
2486.88|4.64|so now let's explore the setting where
2489.28|3.76|the paths that can pass at k k is
2491.52|3.04|greater than one
2493.04|4.24|and so the first observation we have
2494.56|3.92|here is that the temperature that you
2497.28|3.76|sample at
2498.48|5.2|it affects your past enkei and just for
2501.04|3.92|some intuition um if you do temperature
2503.68|2.48|zero example you're going to get the
2504.96|3.359|same sample every single time you're
2506.16|3.36|doing artifact sampling so it doesn't
2508.319|3.04|matter like how many samples you
2509.52|4.319|generate um you're just going to get the
2511.359|4.401|same password um and but if you're if
2513.839|4.161|you want to generate 100 samples right
2515.76|3.76|um you can afford to make some mistakes
2518.0|3.76|but you just want a very diverse set of
2519.52|3.68|samples so you you can up the
2521.76|4.16|temperature you can see kind of as you
2523.2|4.96|up the temperature the slope of the kind
2525.92|4.0|of number of samples of its pathway um
2528.16|3.04|it becomes steeper
2529.92|2.56|and so you can kind of take the upper
2531.2|3.919|hole of this and you can find the
2532.48|5.359|optimal temperature for for each
2535.119|2.72|number of samples
2538.96|3.6|and so this brings me to personally my
2540.88|3.76|favorite result of the paper which i
2542.56|3.279|call the unreasonable effectiveness of
2544.64|2.959|sampling
2545.839|3.441|and so let me explain what's going on
2547.599|3.361|here so this is the number of parameters
2549.28|4.559|in the model and here you have pass rate
2550.96|4.24|at 1 and a pass rate at 100.
2553.839|4.0|and the reason i use this term
2555.2|4.8|unreasonable effectiveness is that i
2557.839|3.601|think there's a world where if the
2560.0|3.04|orange line and the blue line weren't
2561.44|3.44|that far apart i might not be that
2563.04|4.24|surprised like at
2564.88|4.08|these scales the model it rarely makes
2567.28|3.44|kind of syntactical errors anymore like
2568.96|3.2|the if you run it it'll run and produce
2570.72|3.52|some kind of output
2572.16|4.159|so you you could imagine a world where
2574.24|3.68|um basically what you do the model has
2576.319|3.121|some approach in mind is just repeatedly
2577.92|3.6|sampling that approach and it's just
2579.44|3.919|either right or wrong but instead what
2581.52|4.0|we find is that the model's actually
2583.359|4.561|composing uh different parts and
2585.52|4.48|producing functionally different things
2587.92|4.48|and um you get this huge boost from
2590.0|4.319|under 30 to over 70
2592.4|4.32|just by sampling a lot of samples from
2594.319|2.401|the model
2598.48|4.8|so unfortunately knowing that one of
2600.8|5.6|your samples is correct it isn't that
2603.28|5.92|useful if you don't have access to the
2606.4|4.08|unit test and now one setting where
2609.2|2.879|practical setting where you would care
2610.48|3.599|about this is say you're creating an
2612.079|4.0|auto complete tool right and uh you
2614.079|4.081|generate 100 samples but you don't want
2616.079|3.76|to show your user 100 samples and have
2618.16|3.919|them pick one right um you want to kind
2619.839|3.921|of try to pre-filter but you don't have
2622.079|3.921|unit tests um
2623.76|5.44|so can we kind of approximate this
2626.0|4.319|oracle sampling with some other ranking
2629.2|3.04|heuristic
2630.319|3.601|so um here i'm showing a couple of
2632.24|3.52|different heuristics um like you could
2633.92|3.199|randomly pick one but they'll but the
2635.76|4.559|one that seems
2637.119|4.24|most promising is to to rank by me
2640.319|3.921|and um
2641.359|5.201|it's i i know like kind of maybe not
2644.24|4.24|theoretically well grounded but in uh in
2646.56|4.88|language this kind of heuristic is
2648.48|2.96|fairly strong as well
2653.28|4.4|so recall that what we're doing is we
2654.96|4.32|have this evaluation set um where we
2657.68|4.0|have kind of standalone functions we
2659.28|3.2|want to produce solutions to them
2661.68|2.56|but
2662.48|3.76|when we're doing training uh there's a
2664.24|3.839|lot of code that isn't relevant for this
2666.24|3.04|task for instance there's a lot of
2668.079|3.28|classes that we're seeing there's
2669.28|3.68|actually data classes too which aren't
2671.359|3.681|relevant at all and actually there's a
2672.96|4.24|lot of incorrect code on github too so
2675.04|4.319|um we might be modeling incorrect
2677.2|3.28|solutions as well as correct ones
2679.359|2.881|so
2680.48|4.48|uh one thing we thought was let's
2682.24|5.04|fine-tune codecs on further on a couple
2684.96|4.48|of data sets where they are standalone
2687.28|3.76|functions and you have
2689.44|3.04|kind of more guaranteed correct
2691.04|4.079|solutions to that
2692.48|4.639|so what we did was uh we found these
2695.119|3.601|problems from a couple of sources so one
2697.119|4.081|is competitive programming problems you
2698.72|3.92|can go on these sites um oftentimes
2701.2|2.56|they'll just give you the unit test
2702.64|2.719|sometimes when they don't give you the
2703.76|2.8|unit test you can submit incorrect
2705.359|2.96|solutions and they'll tell you the first
2706.56|4.32|one you failed on and you can kind of
2708.319|3.841|keep inserting that
2710.88|2.959|so you can get a lot of competitive
2712.16|4.08|programming problems
2713.839|4.961|and another source is
2716.24|5.2|projects where continuous integration is
2718.8|5.2|enabled so why are these useful because
2721.44|4.56|you can actually kind of uh do an
2724.0|3.76|execution tracing so when you run the
2726.0|3.599|integration test you can get all the
2727.76|3.76|inputs to two functions that are called
2729.599|3.681|in their outputs as well and so you
2731.52|2.88|actually have the the true function body
2733.28|2.799|you know what the test output is
2734.4|3.919|supposed to be so you you know kind of
2736.079|4.321|the ground truth inputs and outputs and
2738.319|4.241|um these are kind of like two orthogonal
2740.4|4.0|data sets one kind of helps you with
2742.56|3.68|like algorithmic kind of tasks and one
2744.4|3.6|is more kind of like can i manipulate
2746.24|4.8|command line utilities
2748.0|3.04|and pass this back
2752.0|4.16|so this brings us to the main figure of
2753.92|3.199|the codex paper so
2756.16|3.679|really what we're seeing is a
2757.119|5.2|progression of capabilities so with gpk3
2759.839|5.52|on this human eval data set the password
2762.319|4.401|at one is uh zero basically um you can
2765.359|3.201|generate like one or two lines go here
2766.72|3.28|and never never really a whole program
2768.56|2.24|coherently
2770.0|3.2|um
2770.8|4.4|now when you fine tune on code which is
2773.2|4.159|codex's orange line you start to see
2775.2|3.44|some kind of knowledgeable performance
2777.359|2.96|on this data set
2778.64|3.199|when you do this super additional
2780.319|3.921|supervised fight tubing that's this
2781.839|4.881|green line uh you get even better
2784.24|3.359|passwords and then if you
2786.72|2.72|kind of
2787.599|4.161|generate 100 samples from this model
2789.44|4.0|re-rank with mean log p even better pass
2791.76|3.92|rates and finally of course if you have
2793.44|3.679|access to an oracle um it gives you the
2795.68|3.04|best passwords
2797.119|3.441|uh so one question here is can you
2798.72|3.359|actually use the d-ranking to like like
2800.56|3.92|further to the model can you use it for
2802.079|4.881|like as a backdrop signal yeah yeah um
2804.48|3.839|so we would explore that um i don't know
2806.96|3.44|if i can say too much about these
2808.319|4.241|results yeah
2810.4|2.16|yeah
2813.119|3.441|and finally i i don't want to suggest
2814.72|3.599|that these these models are perfect they
2816.56|4.08|have a lot of limitations that human
2818.319|3.601|programmers don't run into so one is
2820.64|3.52|like uh
2821.92|3.679|actually all generative models are auto
2824.16|3.199|regressive generative models kind of we
2825.599|3.361|have some problems with binding so when
2827.359|3.681|there's like a lot of variables going on
2828.96|3.44|like a lot of operations going on so
2831.04|3.68|that's like hard to figure out which
2832.4|3.84|operation is finding to which variable
2834.72|3.76|so you can kind of see some examples of
2836.24|3.839|that on the left and uh one other kind
2838.48|3.599|of counter intuitive behavior is
2840.079|4.0|composition so we can take a bunch of
2842.079|3.841|very simple building blocks like uh take
2844.079|3.121|a string and reverse it or or like
2845.92|3.36|delete every third character or
2847.2|3.52|something and a human like if you can
2849.28|4.48|chain two of these operations you could
2850.72|6.92|probably change n of them but our models
2853.76|3.88|aren't able to do that yet
2858.64|3.76|cool so moving on to the conclusion
2861.28|3.279|uh we
2862.4|3.679|have four main points in today's talk so
2864.559|3.76|first progress in neural language
2866.079|4.881|modeling has been fairly rapid
2868.319|4.641|and at gpt it wasn't the result of a
2870.96|4.159|push on language modeling and more a
2872.96|4.159|result of work on pushing unsupervised
2875.119|4.0|learning in language
2877.119|4.161|the third point is that auto aggressive
2879.119|3.681|modeling is universal and it can yield
2881.28|3.92|strong results even when there are
2882.8|4.799|strong inductive biases like in images
2885.2|4.24|or in texas
2887.599|4.24|and finally uh we can produce strong
2889.44|3.44|cogenerating models by fine-tuning gpt3
2891.839|2.561|on code
2892.88|2.959|and uh sampling is an unreasonably
2894.4|3.6|effective way to improve model
2895.839|3.841|performance
2898.0|3.359|cool now to end with some
2899.68|4.72|acknowledgements i want to thank my
2901.359|5.441|codex primary co-authors uh some mentors
2904.4|4.8|at openai and um the algorithms team
2906.8|6.84|which i have worked very closely with
2909.2|4.44|great thank you guys for your attention