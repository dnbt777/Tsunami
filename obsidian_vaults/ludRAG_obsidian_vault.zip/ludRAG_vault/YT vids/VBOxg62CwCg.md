start_time|end_time|text
0.62|3.08| Yeah, hi, everyone. So we had a little excursion last time
3.7|3.08| talking about linear algebra. Today, there will be another
6.78|3.64| little excursion talking about some concepts in calculus,
10.42|2.76| because they will be useful for your fitting neurons with
13.18|3.02| gradient descent. So today, the lecture will be on gradient
16.2|3.96| descent. And I will have some optional sections on some
20.16|4.02| calculus on topics as a little refresher. But yeah, because I
24.18|3.28| think there's a lot of stuff to cover today, I will keep the
27.46|5.46| introduction short and just dive in. Yeah, so the goal here in
32.92|3.84| this lecture is to improve upon the perceptron that we covered
36.76|3.04| last week. So in this lecture, we are going to talk about or
39.8|3.32| learn about a neural network model for which the training
43.16|4.16| always converges. So even if the data is not linearly separable,
47.56|3.48| here's an overview of the big picture goals. So our goals
51.08|3.44| overall. So like I just said, in this lecture, we are focusing on
54.52|3.28| a learning rule that is more robust than the perceptron, so
57.8|3.04| that it always converges even if the data is not linearly
60.84|4.48| separable. But yeah, that is not the end goal of this course, of
65.32|2.6| course, we want to learn about more sophisticated models
67.92|3.8| compared to single layer neural networks. So what we really care
71.72|6.32| about is also how we can make or create more complex classifiers
78.04|3.6| that can solve more complicated problems than just binary or
81.64|5.04| linearly separable problems. Because if I have something like
86.68|4.08| that, where I have two classes, I mean, this is relatively
91.04|3.84| trivial, right? So the perceptron again, had the shortcoming if a
94.88|3.04| data point is over there, there is no linear decision boundary
97.92|3.24| such that there is no mistake. So that way, it would never
101.16|2.76| converge. But even let's say, if we have a learning rule that
103.92|3.24| converges like this, this is a relatively trivial problem. And
107.16|3.4| in practice, we are interested in more complicated problems. So
110.56|3.08| we need to also find a way to combine multiple neurons.
114.04|3.92| Because these combinations of multiple neurons or deep neural
117.96|3.2| networks can help us to learn such more complicated decision
121.16|3.48| boundaries. And then with that, we can solve Yeah, also
124.64|2.96| complicated, real world problems. There are many like
127.6|4.84| objective detection, and let's say on classifying arbitrary
132.44|3.56| things. So in that way, that is something we will then start
136.0|2.72| tackling in the next lecture. So first, here, we lay the
138.72|2.52| groundwork, talking about the learning rule, and then we will
141.24|3.68| apply the same learning rule to the combination of neurons. And
144.92|4.0| also, we will then learn how we can extend this to multiple
148.92|4.52| categories, it will also be next lecture next week. So we will
153.44|4.24| learn also how we can classify problems where we have more than
157.68|2.56| two classes, which is also important, of course, right? If
160.24|3.76| you think about, let's say you build an application for a bird
164.0|3.08| watcher to classify birds outside. So there are more than
167.08|2.62| just two bird species, right? So in that way, we'll also learn
169.7|3.4| about methods that can handle multiple classes. And then yeah,
173.1|3.2| more towards the end of the course, we will then also learn
176.3|2.62| how to do fancier things, not just classification, but also
178.92|3.64| like things like generating new images and new text and things
182.56|4.44| like that. But yeah, on all these types of things are based
187.0|4.04| on the same learning algorithm, and extensions of this learning
191.04|2.7| algorithm. It's not like a fundamentally different though.
193.74|3.6| And in this core, in this lecture here, we will learn the
197.34|3.56| core principle of this learning algorithm that we will be using
200.98|5.12| for the rest of the semester. So and yeah, also, the good news is
206.34|3.54| after this lecture here, there won't be any new mathematical
209.88|2.74| concepts. So in this lecture, I will talk a little bit about
212.62|3.4| calculus. But that is about it when it comes to the mathematics
216.02|3.44| of this course. Of course, there will be mathematical concepts or
219.46|3.08| applications of the concepts we discussed like the linear
222.54|2.96| algebra stuff and calculus stuff in this lecture, but there won't
225.5|3.52| be any new fancier concepts. So after this lecture, you can
229.02|3.8| relax, there won't be any new mathematical complicated things
232.82|4.84| going on. So everything also in deep learning will be extensions
237.66|3.6| and applications of these basic concepts in linear algebra and
241.26|4.64| calculus that we are covering now. So yeah, just to give you
245.9|3.24| the big picture overview of things I have in mind for this
249.14|5.2| lecture. So first, we are going to talk about the different
254.34|2.7| learning modes. There's something called online batch
257.04|3.86| and mini batch learning. It is a general concept that applies to
260.9|3.76| all types of single layer neural networks and multi layer neural
264.66|3.32| networks, convolution networks, and everything basically in deep
267.98|5.88| learning. And yeah, after just this big overview here, we will
274.42|3.56| talk about the relationship between the perception and
277.98|4.76| linear regression. And then we will learn about an iterative
282.74|2.44| training algorithm for linear regression, you probably know
285.42|3.84| the closed form solution for linear regression, these are the
289.26|5.0| matrix matrix formulations and such the short content, a dense
294.26|3.4| formula for solving for the weights and the bias unit
297.66|3.24| directly. Here, we will talk about an iterative learning
300.9|3.84| algorithm, because it helps us understand how we can train our
304.74|3.72| neural networks, it's kind of very closely related. Yeah, I
308.46|3.68| will have a little calculus refresher. This will be
312.14|4.2| optional. So you notice that there are seven sections this
316.34|3.72| time, maybe a little bit long. So this is also really just
320.1|3.54| optional. It's, I thought it might be good for some of those
323.64|4.46| who have taken calculus a long time ago, or maybe not quite
328.1|3.0| sure about calculus anymore. So in a way, it's like a little
331.1|2.76| refresher. But if you are very familiar with calculus, you
333.86|2.68| don't have to watch these videos. So in that way, it will
336.54|3.48| be a shorter lecture. It's also something, these optional things
340.02|3.16| that I probably wouldn't have covered in the in person class,
343.18|3.56| because yeah, this is more like a prerequisite. So in this way,
347.02|3.2| I wouldn't want to make the lecture in person too long. But
350.22|3.12| if you like, you can watch them, but you're not required to. So
353.34|3.84| it's, it's just some background information, some optional
357.18|5.2| stuff. Yeah, and after that, we will be talking then about
362.38|3.28| gradient descent, that is the learning algorithm that I
366.42|4.08| briefly outlined in the previous video. And then we will be
370.5|3.36| training a linear neuron at a line. And I will also show you
373.86|3.44| then a code example in pytorch of how we can train such a
377.3|4.24| linear neuron using the concept of gradient descent. Alright, so
381.54|3.76| then let's get started with the first video on online batch and
385.3|7.0| mini batch modes in the next video.