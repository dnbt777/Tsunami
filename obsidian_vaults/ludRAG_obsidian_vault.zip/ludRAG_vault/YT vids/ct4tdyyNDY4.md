start_time|end_time|text
5.1|3.9|hey guys
7.08|4.139|um oh yeah thanks for waiting I'm really
9.0|4.86|happy to be here uh I guess to shortly
11.219|5.041|introduce myself my name is Ted Xiao I'm
13.86|4.2|a senior research engineer at the Google
16.26|3.48|brain team I've been on working on
18.06|4.559|robotics now for the past five years
19.74|4.799|I've touched upon a few topics including
22.619|3.9|multitask learning uh reinforcement
24.539|4.141|learning and then lately just broadly
26.519|3.301|thinking about how we can scale robots
28.68|3.36|um to make sure that they can actually
29.82|4.38|work in the wild in the real world
32.04|5.1|I guess today I'll be talking about
34.2|5.28|quite a few different topics but as a
37.14|3.84|first preface I guess um the first thing
39.48|3.48|to know is that our team is pretty
40.98|4.62|massive now all of these projects are
42.96|4.14|huge collaborations with some products
45.6|3.24|have more than 40 people working on
47.1|3.779|these for many years so these are large
48.84|4.32|efforts and I'm just very fortunate to
50.879|5.641|call myself to be on teams of very smart
53.16|5.399|people and secondly uh some of my takes
56.52|4.379|are spicier more controversial than
58.559|4.14|others and so all of those opinions are
60.899|4.141|definitely only my own and don't reflect
62.699|3.721|those of Google or anyone else on the
65.04|3.24|team
66.42|4.98|um so with that out of the way yeah
68.28|5.6|welcome to my tedx stop
71.4|2.48|if
75.72|4.8|so I think maybe some of you have seen
78.9|3.6|you know a lot of the cool robot videos
80.52|5.34|learning videos out in the wild these
82.5|4.68|days but I am more excited than ever and
85.86|3.6|it's not just hype I think I think
87.18|4.14|there's been a fundamental shift in how
89.46|4.86|researcher and Robotics view learning
91.32|5.28|over the past two years and I think the
94.32|4.08|shift has a lot to do with all the
96.6|4.199|trends happening more broadly in
98.4|4.079|Foundation modeling in large-scale
100.799|3.301|Internet models
102.479|5.041|um across different fields like language
104.1|5.64|audio and so on but I think my goal
107.52|4.379|today is to convey to UI I am
109.74|5.04|particularly excited about this time
111.899|5.281|today right now and why there's been a
114.78|4.5|very fundamental one a degree paradigm
117.18|4.439|shift I think across the robot learning
119.28|3.839|field and if you walk away from this
121.619|3.54|talk with just one thing and that's
123.119|4.261|you're slightly a bit more excited about
125.159|4.8|robotics than you were before or believe
127.38|4.26|that the time is now for these robots to
129.959|3.721|really start scaling exponentially and
131.64|4.679|doing something really cool I think then
133.68|4.76|my talk will have succeeded
136.319|2.121|um
139.2|4.38|let's see
141.72|4.08|the talk will have a few parts we're
143.58|4.799|going to start at a very high level and
145.8|4.5|just talk about why a foundation models
148.379|3.72|for foundation model for robotics at all
150.3|3.42|what that might look like and the
152.099|4.081|ingredients and recipe for how we might
153.72|5.46|get there then we'll dive into a few
156.18|4.74|different Works um pretty deeply that my
159.18|4.02|team has been very proud of over the
160.92|4.44|past year or two and finally we'll go
163.2|4.02|back to the high level and then zoom out
165.36|4.2|and think about what's next for robot
167.22|5.76|learning
169.56|4.5|so why a foundation model for robotics
172.98|5.06|is
174.06|3.98|one sec let me try to hide this thing
178.739|4.321|um no that's that's fine I'll keep that
181.14|4.2|bar there for now but the top bar says
183.06|3.72|why Foundation model for robotics
185.34|3.0|um you know being coined here at
186.78|3.539|Stanford and I'll use the phrases
188.34|3.539|internet scale model Foundation model
190.319|3.42|and large language model pretty
191.879|3.841|interchangeably throughout and I hope
193.739|3.901|it's pretty clear but generally when I'm
195.72|4.62|talking about these big monolithic
197.64|4.679|beasts that are training on tons of data
200.34|4.38|they have two very important properties
202.319|3.78|that I think are quite nice one is
204.72|4.32|emergence
206.099|5.401|um when very simple things kind of work
209.04|4.619|at a small scale they get a ton better
211.5|4.319|when you just scale things up more data
213.659|4.741|more compute larger models
215.819|5.101|um and what we see here is that when
218.4|4.559|these models even become good enough the
220.92|4.379|domain space of what they're good at and
222.959|4.321|able to do starts to go combinatorial
225.299|4.981|even larger and here for these two
227.28|5.16|points I would like to suggest two blog
230.28|3.48|posts I highly recommend one is from
232.44|3.299|Jacob steinhardt called more is
233.76|3.42|different for AI and this kind of links
235.739|3.901|the phenomenon that we see in other
237.18|5.22|Fields like physics or biology for
239.64|4.92|example individual water molecules will
242.4|4.199|behave very differently and have very
244.56|4.02|different let's say electrostatic forces
246.599|4.021|then they start to climb up Clump up and
248.58|3.84|start behaving as a liquid altogether we
250.62|3.42|see this in herds of animals flocking
252.42|3.42|patterns we see this in humans and
254.04|4.199|economies we see this all across
255.84|4.38|different fields and now even in AI we
258.239|3.601|see models that are doing stuff that
260.22|3.3|would not be even possible where they
261.84|4.26|had a smaller scale but when they've
263.52|4.86|reach some critical scale in size they
266.1|5.099|start to work really really well this is
268.38|5.039|documented by um Jason in uh his blog
271.199|3.621|post emergence and loms which you see
273.419|3.481|this plot on the bottom left
274.82|4.54|successfully across a bunch of different
276.9|4.56|tasks whether it's modular arithmetic or
279.36|3.899|purging question answering the success
281.46|4.019|rate is basically flat until these
283.259|3.541|models get big enough good enough and
285.479|4.741|then the successfully just kind of
286.8|6.0|Skyrocket and uh that's why I think this
290.22|4.94|these are particularly exciting so yeah
292.8|2.36|a question
300.66|3.78|great question and I'm really glad you
302.94|3.36|asked we have
304.44|3.3|I'm pretty excited to present some
306.3|2.64|directions we have along that I hope
307.74|3.959|we'll answer a question in maybe about
308.94|4.319|10 minutes or so okay yeah but I think
311.699|3.78|that's the question on all of our minds
313.259|4.38|including myself
315.479|3.961|um so I think before we even get to the
317.639|3.78|feasibility or the existence of any
319.44|3.599|robotics Foundation models like is this
321.419|4.681|even needed and I think the argument
323.039|4.741|that I don't think is obvious um is that
326.1|2.96|I think emerging capabilities and
327.78|3.66|relying on these might be actually
329.06|4.419|indispensable for robotics to actually
331.44|4.68|work a lot of the research over the past
333.479|5.341|decades in robotics has been in one bin
336.12|5.519|one room one table one robot one
338.82|4.62|building even but these are so vastly
341.639|4.381|different from the orders of magnitude
343.44|4.5|more complex while real world situations
346.02|4.32|that humans operate in every single day
347.94|4.38|and I think to make that gigantic leap
350.34|4.199|we're gonna have to rely on this
352.32|4.26|emerging capability scaling curve where
354.539|4.621|things kind of work you have very canned
356.58|4.679|demos maybe you have you know a humanoid
359.16|4.379|robot program to backflip after hundreds
361.259|3.961|of Trials but going from that to like
363.539|3.421|the chaotic real world I think we're
365.22|4.56|gonna have to rely on this emergence
366.96|5.88|phenomenon for that
369.78|5.639|and I think maybe even intellectually or
372.84|4.859|academically it's also interesting to
375.419|4.921|think about why or why not a foundation
377.699|4.681|model for robotics might even work it's
380.34|4.44|worked in so many other domains there's
382.38|3.9|existence proofs in audio music coding
384.78|4.56|language another domain every single day
386.28|5.34|it seems with 3D models and and Beyond
389.34|3.78|um but if there is something very
391.62|3.299|special about robotics whether it's
393.12|4.44|embodiment or causality or physical
394.919|4.681|grounding then that is the barrier to
397.56|4.38|making this very simple recipe that's
399.6|4.2|working all these other domains if there
401.94|3.84|is something special about robotics that
403.8|3.239|causes this recipe to fail I think
405.78|3.479|that's quite interesting to study why
407.039|4.321|that is I'm personally an optimist I
409.259|3.841|don't think there is some magical Secret
411.36|4.2|Sauce that's going to keep robotics from
413.1|4.56|being tackled with the same formulas and
415.56|3.72|recipes that works elsewhere but you
417.66|4.52|know I think this is a function I'd like
419.28|2.9|to find out the answer to
423.18|3.84|and so maybe then instead of just
425.34|3.24|motivating this philosophically okay we
427.02|3.0|need Foundation models Foundation models
428.58|5.82|are great let's try to build one for
430.02|5.88|robotics how do we actually do that well
434.4|3.419|um I think we can leverage a few
435.9|3.78|ingredients by standing on the shoulder
437.819|3.72|of Giants and looking at other domains
439.68|4.68|uh the first one is looking at different
441.539|5.341|design principles of ml scaling um from
444.36|5.04|other domains uh let's look first at
446.88|4.2|high capacity architectures the topic of
449.4|4.32|this class today
451.08|4.14|um uh ideas such as self-attention as
453.72|3.3|all the different ideas Encompass for
455.22|3.599|the Transformer as Andre carpathy
457.02|3.959|famously said it's like a magical
458.819|4.021|Universal differentiable computer that's
460.979|3.72|very general very robust and very
462.84|4.799|remarkably scalable on many different
464.699|4.56|dimensions let's use those
467.639|3.421|um we should also Leverage The more
469.259|4.321|guiding principles that have been seen
471.06|4.44|the scaling laws the trends this year's
473.58|3.839|chinchilla uh you know we not only have
475.5|3.84|to scale the model size we also have the
477.419|3.84|sale compute and we also have to scale
479.34|3.78|the number of unique tokens in the
481.259|3.861|Corpus of the vast data sets that we
483.12|5.4|train on but if we do all three together
485.12|5.44|this has been shown to reliably have a
488.52|4.019|pretty good chance of succeeding um no
490.56|4.5|matter what domain you're looking at
492.539|4.021|and so and and finally what that kind of
495.06|3.72|means and I think this is actually going
496.56|3.84|to come up later is that data set size
498.78|4.08|seems Nevada these days a lot more than
500.4|4.62|quality even if you have some sentences
502.86|4.2|on Wikipedia that are misspelled or some
505.02|3.959|some you know falsehoods or some things
507.06|3.96|that aren't so desirable if in aggregate
508.979|3.36|your data set is diverse enough and
511.02|3.3|interesting enough
512.339|3.541|um these things will hopefully wash out
514.32|5.219|in the mix
515.88|5.64|foreign number two the proliferation of
519.539|4.201|the internet Scale Models themselves not
521.52|4.5|just the principles
523.74|3.96|what's exciting and I'm sure it's you
526.02|4.259|know definitely been very shocking for
527.7|3.96|both experts and lay people alike is
530.279|3.481|that a lot of these generative models
531.66|3.66|across many different modalities have
533.76|3.66|been experiencing emerging capabilities
535.32|4.44|and have been surpassing all of our
537.42|4.32|wildest expectations time and time and
539.76|3.66|again but even when we think that we're
541.74|3.24|exhausted all this stuff is too much
543.42|2.94|it's not going to work something will
544.98|2.94|come out and completely blow me out of
546.36|3.599|the water and I think this trend will
547.92|3.84|definitely keep continuing and I think
549.959|3.481|uh in addition to that they not only
551.76|3.18|will continue coming on and accelerate
553.44|3.839|more rapidly they're going to happen
554.94|3.899|with whether or not like we do anything
557.279|4.441|um you know in in the grand scale of
558.839|5.161|speaking me as a robotics researcher or
561.72|4.02|you know you and and whatever subfield
564.0|3.18|you're on there are parts of machine
565.74|3.659|learning that likely you'll probably not
567.18|3.96|ever touch in at least the near future
569.399|3.361|and those parts will be seeing
571.14|3.66|tremendous breakthroughs and scaling and
572.76|3.78|new capabilities coming online every
574.8|4.5|single week
576.54|4.2|and uh you can look at this not only in
579.3|3.9|the impressiveness of the models but
580.74|4.2|also the acceleration of progress the
583.2|3.48|time scales in which new models are
584.94|3.24|being released while where large
586.68|3.3|collaborations are being worked on by
588.18|4.08|many groups and then you know being
589.98|4.82|available to access for all to use and
592.26|2.54|build upon
594.839|5.581|and the final ingredient and this trend
597.36|5.76|is more of a robotic specific one but it
600.42|4.919|is a vast shift from online robotic
603.12|4.26|learning where where robots collect
605.339|2.94|experience online make actions and learn
607.38|3.24|through
608.279|4.56|um trial and error to an offline setting
610.62|4.5|where we decouple the data generation
612.839|4.861|process from the data consumption
615.12|5.04|process as we've seen in all these other
617.7|4.56|Foundation modeling domains these big
620.16|3.96|internet scale data sets are so diverse
622.26|3.78|and they're static we just scrape them
624.12|4.08|once or scrape them multiple times
626.04|4.26|continuously but we aggregate a
628.2|3.96|continuous pile that's just growing here
630.3|5.159|we see either the pile data set from a
632.16|4.619|Luther or Lyon 5B for uh image paired
635.459|2.701|image text
636.779|2.761|um and and these are pretty big and
638.16|2.7|their orders of magnitude more than what
639.54|3.66|we've seen before and they are
640.86|3.9|definitely a key ingredient to why other
643.2|4.62|domains have been doing so well at
644.76|4.5|training these big foundation models
647.82|3.78|and
649.26|5.04|this coming back to robotics then I'd
651.6|4.62|like to take a brief detour into how the
654.3|3.539|shift came to be because it's very easy
656.22|3.299|to stay in a sentence yeah robotics is
657.839|3.721|offline more than online and this is
659.519|4.021|coming as kind of a no-brainer to many
661.56|3.48|folks who are coming from other domains
663.54|3.84|like this is the way things are done
665.04|3.419|well in robotics this has been a very
667.38|2.82|big shift
668.459|3.841|um and I think robotics has also been
670.2|3.96|synonymous with RL reinforcement
672.3|3.9|learning for a lot of people and I think
674.16|4.919|increasingly this is becoming less true
676.2|5.699|and so I'd like to take you down a brief
679.079|4.44|um trip down the history of my team for
681.899|3.18|slide up and talk says brief history of
683.519|4.38|Robotics at Google
685.079|4.921|um and yeah of course thanks and I think
687.899|5.101|this is not just for dramatic Exposition
690.0|5.519|it's really to try to guide you through
693.0|4.86|how drastically our team's thinking has
695.519|4.081|kind of evolved over the years and how
697.86|4.32|that's going to inform the design
699.6|4.679|decisions and the and the kind of risks
702.18|3.54|and research directions that we take um
704.279|3.421|in the specific projects I'm going to
705.72|4.08|show coming up thank you
707.7|3.9|um so in 2016 uh some of you may have
709.8|3.84|seen this we had what we call the arm
711.6|5.16|Farm seven Kuka robots in a room
713.64|5.34|collecting picking data 24 7. and this
716.76|4.38|was doing on policy RL in the real world
718.98|4.2|we were the first team to kind of say
721.14|3.54|hey can we can we even do this
723.18|3.36|um with the goal of saying can we do
724.68|4.14|end-to-end robot learning with results
726.54|4.2|in the real world this was kind of risky
728.82|3.42|at the time it was not a common take and
730.74|3.06|from that we developed several
732.24|3.539|interesting research directions that we
733.8|5.219|started exploring we looked into stuff
735.779|5.821|like um uh qtops which is a q learning
739.019|5.88|method working on continuous control
741.6|5.72|actions uh while taking a vision inputs
744.899|4.62|we worked on on cyclegan to transform
747.32|4.78|simulation-based images into real real
749.519|3.781|looking images for Sim surreal we looked
752.1|2.58|at concurrential we'll probably get
753.3|3.24|robots moving faster and more
754.68|4.88|efficiently in the real world I'm sorry
756.54|3.02|do you have a question yeah
762.2|5.5|yeah great question and
764.94|4.92|um that one I think was basically uh the
767.7|4.079|arms would pick stuff up from the bin if
769.86|3.12|they messed up and it fell out well we'd
771.779|3.0|come back the next morning and there'd
772.98|4.5|be objects scattered all throughout the
774.779|4.261|room so there was no reset but if they
777.48|3.18|missed a little bit the objects would
779.04|3.239|fall back into the bin and hopefully be
780.66|3.979|in a position where they could pick them
782.279|2.36|up again
785.579|2.7|oh yeah of course
787.139|3.0|um Chad thanks I'll do that in the
788.279|4.8|future um this specific question was for
790.139|5.64|this 24 7 arm Farm how did we do resets
793.079|4.141|and the answer is well we didn't we
795.779|3.481|designed the bin so that they were kind
797.22|3.419|of banked so that object slightly missed
799.26|2.819|they would fall back in the bin we
800.639|3.301|aren't themselves maybe add more
802.079|4.621|diversity to the training data but this
803.94|5.04|was doing off policy online RL with Q
806.7|5.12|learning when we mixed it with Sim data
808.98|2.84|deploy it again
812.519|4.62|next uh we kind of went through this
814.8|4.2|consolidation phase around 2020 when
817.139|3.781|we're like all right this is pretty cool
819.0|3.779|and you know but we want to get out of
820.92|4.14|the bin how do we do more complex tasks
822.779|3.901|and a more practical setting that could
825.06|3.06|be closer to something that humans would
826.68|3.659|want to use that's more General every
828.12|3.959|day there we kind of settled on this
830.339|3.361|office micro kitchen environment if
832.079|2.88|you've heard of the famous Google micro
833.7|3.06|kitchens
834.959|3.661|um and I think this was the setting we
836.76|3.84|decided to what's operate in
838.62|3.839|um and there we started collecting data
840.6|3.66|we scaled our real operations and then
842.459|3.601|we kind of scaled approaches to some
844.26|3.42|different things and I think uh in the
846.06|3.54|bottom right here is like the more
847.68|4.44|mechanized reset version I would say of
849.6|4.14|the arm Farm here we had a bin that
852.12|3.659|folded in half and this was doing
853.74|3.719|multitask RL in the real world and the
855.779|2.821|bin would flip in half dumping objects
857.459|2.761|from one side to the other so you could
858.6|3.299|do more interesting tasks whereas the
860.22|3.6|arm plan was pick anything up now you
861.899|4.801|could say hey pick up the carrot and
863.82|5.04|place the Tomato onto the plate and then
866.7|3.96|the bin would flip and you'd reset some
868.86|4.14|other works looks like at UM multitask
870.66|3.84|invitation learning this is bc0 and then
873.0|3.18|we also look at stuff like combining
874.5|4.5|reinforcement learning with imitation
876.18|6.779|learning bootstrapping
879.0|5.519|but in 2020 uh once again we realized we
882.959|3.421|were working on a ton of different
884.519|3.781|directions and we wanted to consolidate
886.38|3.54|and I think the two main things that
888.3|3.479|were really bothering us at the point at
889.92|4.32|the time where we were hitting two main
891.779|4.56|walls across all these methods some of
894.24|4.68|them were plateauing at this 50 to 70
896.339|4.86|percent uh you know rough range in the
898.92|3.9|real world and other methods were
901.199|3.661|requiring very specific data
902.82|3.78|distributions they had to be on policy
904.86|3.36|or they could only use demonstrations or
906.6|3.539|they blah blah blah like there are so
908.22|3.66|many different nuances and like gotchas
910.139|3.421|to all these different methods and all
911.88|4.56|these different drawbacks and so the
913.56|5.399|question we posed was we're open to any
916.44|4.56|any method any strategy that will enable
918.959|4.201|us to solve tasks in a very performant
921.0|5.459|matter more than 90 in the real world
923.16|5.34|and also that can scale with some kind
926.459|4.62|of data that we can collect you know and
928.5|4.199|maybe this is a bit more relaxed than
931.079|3.12|let's say an academic setting where
932.699|3.061|you're much more resource constrained
934.199|3.541|but at the end of the day you know even
935.76|3.5|our team does not have infinite money we
937.74|3.779|still have a certain number of robots
939.26|4.0|operators and we're constrained by the
941.519|3.12|laws of physics so we need some way to
943.26|3.06|acquire more data that we can then learn
944.639|2.94|from and so we're all scratching our
946.32|3.66|heads thinking about this for a few
947.579|4.681|months since spring 2022.
949.98|4.44|we decided on going with multitask
952.26|4.379|imitation learning so this was a vast
954.42|4.26|departure from the 24 7 arm farm this
956.639|4.14|was a vast evolution of how we
958.68|3.899|approached the problem we found that you
960.779|3.781|know with enough you know gentle care
962.579|4.2|and love multitask imitation learning
964.56|3.839|was able to hit these 90 numbers and it
966.779|3.601|was able to get better with more
968.399|4.141|demonstrations these aren't the cheapest
970.38|3.959|thing but it was able to scale with
972.54|4.14|additional demonstrations which was the
974.339|4.56|sign of life that we were looking for so
976.68|4.08|that brings us to less than a year ago
978.899|3.481|our team was deciding this is the path
980.76|3.36|forward at least in the near-term future
982.38|2.34|but
984.12|3.12|um
984.72|4.859|maybe you know we could just think about
987.24|4.62|how the approach we were taking here
989.579|3.721|might also spread out in the future and
991.86|3.839|we might be able to bring back these
993.3|4.02|other threads uh for example um if now
995.699|4.681|that we're decoupling this data
997.32|4.74|collection of demonstrations or Etc from
1000.38|3.899|how you learn from them with a multitask
1002.06|4.68|invitation learning policy maybe in the
1004.279|4.8|future then do something like offline RL
1006.74|4.38|but I think at a high level now I've
1009.079|4.68|just you know in in a few short minutes
1011.12|4.139|just compressed six years of very bitter
1013.759|3.601|lessons that our team has been learning
1015.259|3.661|and I think from where we are today and
1017.36|3.419|looking back even just two years ago if
1018.92|3.539|you told me that the strategies were to
1020.779|2.941|point today could just scale the way
1022.459|3.061|they are I probably would not have
1023.72|3.8|believed you
1025.52|2.0|um
1035.839|3.781|great question so I think task
1037.64|3.659|conditioning is definitely still was an
1039.62|4.14|open question at the time
1041.299|5.64|um but I think with this work uh BC zero
1043.76|5.58|uh we we found that language was able at
1046.939|4.021|least in a templated language
1049.34|3.3|um kind of representation was good
1050.96|3.78|enough where we could direct I think bc0
1052.64|5.1|was over 80 tasks so they were they were
1054.74|5.939|very templated like pick grapes or like
1057.74|5.7|move grapes onto plate or drag this
1060.679|4.681|across black drag clock across table and
1063.44|3.66|I think um this representation was still
1065.36|3.12|enough where you're learning a good
1067.1|2.88|number of skills that you're passing in
1068.48|3.12|essentially a one-hot ID into your
1069.98|3.12|policy Network and it will learn to
1071.6|3.36|imitate that and for each one of those
1073.1|3.54|80 tasks we'd collect hundreds or
1074.96|4.14|thousands of demonstrations
1076.64|5.3|and I will touch upon the specifics of
1079.1|2.84|that a bit later too
1082.7|4.8|um
1083.539|6.181|so yeah today and or at least in 2022
1087.5|4.559|let's do offline methods let's decouple
1089.72|4.319|data generation from data consumption
1092.059|4.021|and let's take these three lessons now
1094.039|3.661|that we touched upon let's take the
1096.08|3.12|design principles of ml scaling and then
1097.7|3.24|figure out what lessons can actually be
1099.2|4.68|applied when we go look into the future
1100.94|5.04|for a recipe for uh robot learning and
1103.88|3.6|Foundation models
1105.98|3.059|um the first lesson I think is very
1107.48|3.48|important is these high-capacity
1109.039|3.181|architectures like attention the second
1110.96|3.599|I'll touch on later is data
1112.22|4.26|interoperability tokenized tokenization
1114.559|3.601|discretization
1116.48|3.3|um and the second ingredient is the
1118.16|3.72|proliferation of these models themselves
1119.78|3.84|can we leverage them because they will
1121.88|3.36|get better over time
1123.62|3.66|um and I think here I would like to plug
1125.24|4.38|my colleague Carol houseman's bidder
1127.28|4.259|lesson 2.0 which is the bitter lesson
1129.62|3.72|the first one from Richard sutson was
1131.539|4.441|you should leverage methods that scale
1133.34|4.68|with more compute and maybe in today's
1135.98|3.78|day and age the lesson is that we should
1138.02|3.779|leverage methods that are able to
1139.76|3.299|utilize improvements in Foundation
1141.799|4.5|models because they're going to get
1143.059|5.521|better yeah so
1146.299|4.561|2.0 one thing that's always concerned me
1148.58|3.9|is suppose I have a set of methods
1150.86|2.76|and I want to choose the methods that
1152.48|2.46|are going to stay with more from here
1153.62|3.84|before in this case scale with better
1154.94|5.7|Foundation models the question is how do
1157.46|5.04|I actually decide which of those methods
1160.64|4.62|meet those criteria
1162.5|5.039|yeah great question I think um and maybe
1165.26|4.14|it's uh and I think that's a very I
1167.539|3.961|don't have a good answer for that oh
1169.4|4.019|sorry yeah yeah the question was um in
1171.5|3.48|bitter lesson 1.0 and bitter lesson 2.0
1173.419|3.661|the question is well that's great that's
1174.98|4.92|the lesson but how do we actually decide
1177.08|4.8|which methods meet this criteria and I
1179.9|3.42|think you know my answer is it's not
1181.88|3.96|always obvious and it's actually quite
1183.32|4.5|tricky sometimes but uh maybe you know
1185.84|3.06|sometimes you know what you can be very
1187.82|2.76|confident that oh yeah this will
1188.9|3.36|definitely scale um with more data and
1190.58|3.06|compute and some that are same but
1192.26|2.76|basically the more hard-coded you are
1193.64|3.48|the more assumptions the more heuristics
1195.02|4.14|you bake in the more you in our in our
1197.12|4.08|day and age the more you rely on a
1199.16|4.44|specific implementation of a specific
1201.2|4.859|Foundation model of a specific class of
1203.6|4.56|algorithm maybe that will be less robust
1206.059|3.781|than a method that just assumes some
1208.16|3.48|very abstract input and output and
1209.84|3.66|assumes that how you get from that input
1211.64|3.84|and output can improve over time and
1213.5|4.2|maybe the algorithm itself even changes
1215.48|4.26|all together so I think that would be my
1217.7|4.26|take on the video Lesson 2.0 but this is
1219.74|4.819|definitely still uh I think the jury's
1221.96|2.599|still out on this things
1224.96|4.8|and uh my my basic um my one of the
1228.559|3.0|things I like to propose is that
1229.76|3.84|language is the way that we can leverage
1231.559|4.321|bitter lesson 2.0 if you have language
1233.6|3.72|as the universal representation through
1235.88|3.299|which all these foundations communicate
1237.32|4.14|to each other whether it's you know
1239.179|3.721|captioning or generation or whatnot I
1241.46|5.36|think that's one way that we could
1242.9|3.92|leverage a video Lesson 2.0
1247.039|4.201|um and finally the third ingredient
1248.44|5.38|offline robot learning decoupling data
1251.24|6.059|generation from data consumption putting
1253.82|5.58|these all together my recipe for how one
1257.299|4.021|take at a modern attempt that embodied
1259.4|4.139|intelligence would look like would be to
1261.32|4.38|combine these large offline data sets
1263.539|4.081|with high capacity architectures by
1265.7|4.08|using language as the universal group
1267.62|4.98|and in the works I'm going to present
1269.78|4.44|shortly all of our different projects I
1272.6|5.54|think in some way or another are
1274.22|3.92|inspired by this philosophy
1279.62|4.02|and now now that we've kind of um you
1282.08|4.4|know understood the motivations and
1283.64|4.94|potentially one possible approach
1286.48|5.34|of course
1288.58|3.24|large numbers
1292.299|6.401|I'm curious to know which if any issues
1296.179|4.921|are currently used bottlenecks not the
1298.7|4.08|right word which of these are women got
1301.1|2.88|it because it seems like we already have
1302.78|2.58|our job like this if we have like
1303.98|2.34|capacity architecture thing you know
1305.36|3.12|there's architectures are related
1306.32|4.32|language it seems like we already have
1308.48|4.8|always components lessons on so why is
1310.64|5.039|this that not a solved product
1313.28|3.84|um the question was uh these it seems
1315.679|4.021|like we have a lot of these ingredients
1317.12|3.419|and so why hasn't robotics been solved
1319.7|2.52|yet
1320.539|4.02|um so I would argue that actually this
1322.22|4.079|takes here and maybe I'm this is to the
1324.559|3.541|wrong audience at the moment but I think
1326.299|4.201|this is not very non-obvious across the
1328.1|4.86|robotics field many people do not agree
1330.5|5.22|with all of these much less two of these
1332.96|5.099|or even any of these points and so I
1335.72|4.56|think and also the existence of the
1338.059|4.081|scale of how mature each of these
1340.28|3.48|components are within robotics is at
1342.14|3.06|very different stages and I would say
1343.76|3.48|like and we can talk a bit later about
1345.2|4.56|like for example like data scale or the
1347.24|4.98|architectures that have kind of diffused
1349.76|4.62|through osmosis from other ml domains
1352.22|4.68|into robotics but I think we're still at
1354.38|3.84|very different stages on how how much
1356.9|3.72|people have actually bought into these
1358.22|4.5|lessons and invested in them
1360.62|4.08|yeah
1362.72|4.26|I'm curious to know not asking you to
1364.7|6.719|make names but the people who might not
1366.98|8.04|be blinding to all these pieces one
1371.419|5.041|um yeah yeah uh I I can probably I also
1375.02|3.659|don't want to get into too much trouble
1376.46|4.02|here but I'll I'll probably get myself
1378.679|3.661|in a bit of hot water in a few slides so
1380.48|3.12|I'll I'll expand upon out of it then
1382.34|3.48|yeah
1383.6|3.319|this is why you think they're wrong yeah
1385.82|4.02|yeah
1386.919|5.681|and I I would say that like me
1389.84|4.14|personally and um you know not speaking
1392.6|3.24|for my team but a lot of people on my
1393.98|5.46|team are probably at the very extreme
1395.84|6.6|end of learning scaling data-driven uh
1399.44|4.739|you know Foundation model based uh let's
1402.44|3.3|go big um and I think a lot of people
1404.179|2.88|don't believe that and yeah happy to
1405.74|4.02|discuss why later
1407.059|4.321|maybe after the zoom as well so
1409.76|3.96|yes
1411.38|3.9|um so yeah uh well okay then let's let's
1413.72|3.9|go ahead and dive in and see how this
1415.28|4.62|recipe might actually percolate into
1417.62|5.22|specific um domains
1419.9|4.56|um and the first one is uh rt1 uh this
1422.84|3.66|is a recent work from our group that
1424.46|4.02|works on how we can scale imitation
1426.5|4.14|learning and let's look at how we can
1428.48|4.86|actually apply these first principles
1430.64|3.659|so the first one is to consider what we
1433.34|2.459|actually
1434.299|3.481|um let's let's put ourselves into the
1435.799|3.301|spring 2020 mindset we we've been
1437.78|3.66|collecting demonstrations for a while
1439.1|3.9|this is a ton of demos like a hundred
1441.44|3.719|thousand over that was collected over
1443.0|5.159|like a year and a half on Many Many
1445.159|5.76|Robots on many many tasks that exists it
1448.159|4.801|was expensive and over time this will
1450.919|3.541|actually you know not trickle up at
1452.96|3.06|insane amounts like we won't just get a
1454.46|3.66|hundred thousand new high quality demos
1456.02|4.8|every day this will grow over time but
1458.12|4.26|it's not gonna you know grow for free
1460.82|3.239|um and autonomous ways of doing this is
1462.38|4.02|very hard as you saw earlier with mtop
1464.059|3.721|with the bin reset mechanism or deepmind
1466.4|3.72|has to work on RGB stacking where they
1467.78|3.899|try to do autonomous resets and you know
1470.12|3.6|the way that we're doing it right now or
1471.679|4.5|at least um for this paper uh was human
1473.72|4.98|tele operation um pioneered by BC zero
1476.179|3.661|and that was very expensive as well so
1478.7|4.26|this is going to be limited throughput
1479.84|4.62|and finally uh bc0 used a resnet based
1482.96|2.94|backbone and it was pretty good but it
1484.46|3.36|found that it was very sensitive to
1485.9|3.36|training distributions for example when
1487.82|3.2|they remove data from some tele
1489.26|4.02|operators they make the data more
1491.02|3.7|performance got better and that's not
1493.28|3.6|really a property we like right we want
1494.72|3.18|more data even if it's not exactly the
1496.88|3.72|same
1497.9|4.68|um so the lesson here models need to be
1500.6|4.38|robust and they need to generalize
1502.58|4.02|cool so we have models need to be robust
1504.98|3.12|and generalized what else do we have
1506.6|3.6|well off the shelf models are pretty
1508.1|3.72|slow if we take in these huge you know
1510.2|3.0|Vision Transformers from other domains
1511.82|3.66|they're not going to run on the real
1513.2|4.02|robot uh we need to be able to run at a
1515.48|3.36|pretty high frequency um they need to be
1517.22|4.92|reactive inference time needs to be slow
1518.84|5.699|because all our models are Vision based
1522.14|4.2|and finally uh we want our data to be
1524.539|3.24|able to understand language as I
1526.34|3.0|mentioned if language is the universal
1527.779|3.541|glue our data set already has some
1529.34|4.26|language and we want eventual models to
1531.32|4.26|be very multimodal this is a first
1533.6|3.78|principle that we need to bake in
1535.58|3.3|what does this mean we can't just take
1537.38|3.36|something existing we probably need to
1538.88|4.14|design or at least modify something from
1540.74|4.2|the ground up and let's take the best
1543.02|4.019|practices that we've seen work in other
1544.94|4.859|fields
1547.039|4.861|and so we worked for a bit and uh we
1549.799|4.26|came up with this architecture for rt1
1551.9|3.6|again once again this was a large team
1554.059|3.541|with a bunch of different contributions
1555.5|3.48|and I'll just go through a few of them
1557.6|3.9|here
1558.98|4.559|um at a high level uh rt1 is robotics
1561.5|4.559|Transformer um it operates at three
1563.539|5.401|Hertz it takes in a visual input from
1566.059|5.1|the robot or on RGB camera as well as a
1568.94|5.28|natural language instruction there the
1571.159|5.701|image is patified and fed into a film
1574.22|4.26|efficient net um tokenizer that's then
1576.86|2.939|passed into token learner which I'll
1578.48|2.4|talk about soon
1579.799|3.181|um and then also the language
1580.88|3.659|instructions are tokenized
1582.98|3.54|um and then they are put into the same
1584.539|3.661|Transformer and then finally we output
1586.52|3.96|discretized
1588.2|4.02|um actions as tokens and send that to
1590.48|3.9|the real world in three Hertz in closed
1592.22|5.16|loop
1594.38|5.039|um this Transformer is a decoder one we
1597.38|4.32|use a sparse categorical entropy
1599.419|4.561|objective for Action prediction by
1601.7|4.32|applying a causal mask we use the
1603.98|4.079|pre-trained efficient net backbone and
1606.02|3.659|we also use token learner for verify for
1608.059|3.24|faster inference
1609.679|4.281|um diving a little bit deeper oh sorry
1611.299|2.661|yeah a question
1618.26|2.399|great question
1619.58|3.479|um so
1620.659|4.441|the image token when it goes in from so
1623.059|4.62|each image is the you know the high
1625.1|4.86|fidelity RGB image from the camera we
1627.679|4.201|split that up into 81 separate patches
1629.96|4.68|and so each patch is you know it's
1631.88|4.5|spatially just like the the square there
1634.64|3.96|um but the cool thing is that uh what
1636.38|3.299|token learner does here uh this thing
1638.6|3.179|here
1639.679|4.801|um is it's a previous work from our
1641.779|4.861|group that takes in a bunch of possible
1644.48|4.74|um uh you know image patches and
1646.64|4.5|dynamically select which of those image
1649.22|4.38|patch tokens are more relevant for the
1651.14|5.399|tax at hand given the existing context
1653.6|5.4|so from those 81 image patch tokens we
1656.539|4.441|sub-sample eight of them to use for
1659.0|2.94|inference and this happens at every time
1660.98|3.0|step
1661.94|4.02|and that process is learned which of the
1663.98|3.0|eight patches are relevant at any given
1665.96|4.199|moment
1666.98|4.92|um and otherwise we're sending in way
1670.159|2.941|too many tokens and the context length
1671.9|3.06|would explode and we wouldn't be able to
1673.1|3.959|do inference on Roblox we are also
1674.96|3.36|passing in a single sequence length of
1677.059|2.641|six images
1678.32|3.42|um history is quite important when
1679.7|3.359|you're doing temporarily uh coherent
1681.74|3.48|tasks in the real world where things
1683.059|4.201|like physics and you know exactly this
1685.22|3.6|this nuanced detail of what the objects
1687.26|4.919|are doing in relation to each other into
1688.82|6.26|your robot those details really matter
1692.179|4.921|um and in total the the model size is 35
1695.08|3.699|million parameters
1697.1|3.54|um which is quite a bit smaller than a
1698.779|3.541|lot of these other uh you know huge
1700.64|4.38|internet scale models
1702.32|4.979|and finally one main difference here is
1705.02|3.899|action discretization before a lot of
1707.299|3.12|the products we're doing uh we're doing
1708.919|3.901|continuous control and if you think
1710.419|4.321|about it right our robot does have um we
1712.82|4.2|do end effector post control on position
1714.74|5.22|control and there uh the real world is a
1717.02|4.56|continuous State space but um and and to
1719.96|4.199|do that we we had to come up with many
1721.58|5.28|algorithmic Novelties for example a a
1724.159|4.561|cem actor that did basically sampling of
1726.86|3.36|these continuous action spaces to
1728.72|3.36|propose the highest ones that would get
1730.22|3.66|rated by the Q function and we do this
1732.08|3.36|twice blah blah blah and but that's like
1733.88|3.299|so sensitive but we needed to get
1735.44|4.08|through that to get things to work but
1737.179|4.921|now we just decided let's just uh you
1739.52|4.56|know bin our actions it's only 256
1742.1|4.699|discrete actions and let's just predict
1744.08|2.719|those as tokens
1750.14|3.48|you have this design required or
1751.94|4.14|engineering environment about speed
1753.62|4.02|latency reaction I think we say that
1756.08|6.079|that necessitates on a relatively small
1757.64|4.519|model which makes sense but one lessons
1762.58|4.479|by either data you can do before or
1765.38|3.6|analytics so I guess one of the person
1767.059|3.12|is how do you balance these off in the
1768.98|2.579|sense that if you want to have lots of
1770.179|2.88|parameters that have a really powerful
1771.559|4.141|model but on the other hand you want to
1773.059|4.141|have very passive inputs yeah great
1775.7|3.839|question and uh to repeat it the
1777.2|3.359|question is um we kind of set a pretty
1779.539|2.88|hard constraint with that 100
1780.559|4.081|millisecond inference time yet a lot of
1782.419|3.541|the lessons in Foundation modeling is
1784.64|2.639|that you shouldn't be constraining
1785.96|3.48|yourself against any Dimension whether
1787.279|4.441|it's data set size compute or model
1789.44|4.02|capacity and I think my initial answer
1791.72|3.0|to that is that's a very great point and
1793.46|3.78|something I think that's going to be
1794.72|4.8|coming up as a severe bottleneck um in
1797.24|3.72|the future but for for our initial case
1799.52|3.48|I think this is more of an exploration
1800.96|3.719|of whether these principles and even
1803.0|4.02|scaling well beyond what we're looking
1804.679|5.161|at now could work already on this 35
1807.02|5.58|million is gigantic compared to a lot of
1809.84|4.439|Prior work using for example resnet 34
1812.6|3.059|or whatnot so this is already much
1814.279|4.081|bigger than you know a lot of other
1815.659|5.041|options and um maybe for now at least
1818.36|4.319|it's the easiest it's it's the largest
1820.7|3.54|scale we could go to roughly
1822.679|3.0|um in the short term without having to
1824.24|3.5|think of more tricks
1825.679|2.061|um
1828.14|4.5|gotta got it yeah we can talk about it a
1830.84|3.36|bit later maybe I think I'd also love to
1832.64|3.6|hear your thoughts too because it's very
1834.2|4.94|non-obvious how we can get past um some
1836.24|2.9|of these bottlenecks
1839.299|4.081|really about to this they didn't give
1841.34|4.079|you a medical computer with 100 things
1843.38|3.299|to be used but everything else in the
1845.419|3.781|same way they're disable your platform
1846.679|4.5|you so do you think you see significant
1849.2|3.78|Improvement even some sort of emerging
1851.179|3.841|Behavior or the current pipeline for
1852.98|4.38|this bigger models or do you think there
1855.02|4.34|is more to this than to try to scaling
1857.36|4.559|that and they're like limiting value
1859.36|5.86|yeah great question um we ran some
1861.919|5.341|ablations on uh model size I I might
1865.22|3.78|have that in a few slides um but uh
1867.26|3.5|maybe we can return to that then and if
1869.0|5.6|not um
1870.76|3.84|yeah but great question
1874.82|3.479|um so yeah that that's the architecture
1876.919|3.36|and I'll discuss some of the ablations
1878.299|3.841|and the trends later on but maybe you
1880.279|4.02|know this is a robotics lecture I should
1882.14|4.86|show you some pretty visuals right
1884.299|3.961|um so let's look at some evaluations we
1887.0|3.84|did uh we compared against some
1888.26|3.96|baselines one is uh gato um which you
1890.84|3.6|might be familiar with
1892.22|4.62|um and then other other ones BC zero the
1894.44|4.5|resnet based one and we find that uh we
1896.84|4.14|we evaluate on scene tasks versus unseen
1898.94|4.14|tasks and we also uh embarrass the
1900.98|4.439|shacker objects our normal data collect
1903.08|4.86|looks like this top left picture three
1905.419|4.26|cans on a gray desk that's basically it
1907.94|3.959|and but then we push it further by
1909.679|3.961|bringing in a lot more objects so that
1911.899|3.841|the table is so cluttered that even as a
1913.64|3.3|human sometimes it's hard to find the
1915.74|3.9|object that you're actually looking for
1916.94|4.32|we add in tablecloths to make the the
1919.64|3.72|textures very different we bring it to
1921.26|4.5|New micro kitchens um with new surfaces
1923.36|4.08|all together and we find that rt1 is
1925.76|3.18|more robust than these other different
1927.44|3.619|methods
1928.94|2.119|um
1937.64|4.139|in this specific
1939.14|5.34|good question uh question was um was the
1941.779|4.921|gato model trained on our data or was it
1944.48|3.54|uh just already included in gato oh the
1946.7|3.18|answer is uh this data was not included
1948.02|4.86|in gato and so we retrained the Gaga
1949.88|5.279|model only on our data yeah
1952.88|4.08|and uh yeah so here's just a different
1955.159|3.12|visualization of the robot going out in
1956.96|2.819|our micro kitchen and doing different
1958.279|3.181|interesting things
1959.779|3.841|um you can see here that it's trained on
1961.46|4.319|one setting but then it goes into brand
1963.62|3.96|new kitchen brand new countertops new
1965.779|5.161|objects and it's able to do all of them
1967.58|5.28|pretty robustly uh we also put it into
1970.94|3.9|um a long Horizon setting
1972.86|3.419|um using the second framework that we'll
1974.84|3.48|talk about next
1976.279|3.9|um but in these settings a lot of them
1978.32|3.599|are mixing all of these generalization
1980.179|3.181|capabilities and on the plot on the left
1981.919|3.12|here we're using what we call
1983.36|3.299|generalization levels inspired by the
1985.039|4.321|Vemma paper that would basically
1986.659|5.041|increasingly change more factors of
1989.36|6.439|variation simultaneously and here we
1991.7|4.099|found rt1 is the most robust
1999.88|3.76|yeah good question
2001.96|3.599|um we'll go into a bit more detail later
2003.64|3.659|but I think at a high level tele
2005.559|4.441|operators get a structured templated
2007.299|5.401|command of like verb noun verb or
2010.0|5.34|something um like like pick Coke can or
2012.7|5.219|move Apple near sponge
2015.34|3.9|um and they we have around 700 tasks set
2017.919|3.301|up this way and they go ahead and
2019.24|4.38|collect that data test done and then
2021.22|4.26|later we have um we make sure that
2023.62|3.84|successes are actually successes and we
2025.48|4.22|discard stuff that's like unsafe for
2027.46|2.24|example
2029.82|5.14|oh yeah got it for this paper we we
2032.559|4.881|utilize 130 000 demonstrations for this
2034.96|2.48|yeah
2041.2|2.0|yeah
2050.399|4.181|great question I think a lot of Prior
2052.899|3.72|work has also noted that
2054.58|4.519|um when you have for example the
2056.619|4.381|question was did you find that the the
2059.099|3.58|trajectories in your data set were very
2061.0|3.659|multimodal and I think what you mean by
2062.679|4.5|that is that to go from point A to point
2064.659|4.381|A to point B I can go left or I can go
2067.179|4.621|right or I can go straight
2069.04|5.339|um and I think this kind of diversity in
2071.8|4.74|basically for a single image stage but
2074.379|4.321|yet my data has three possible labels
2076.54|4.2|that can have very bad effects sometimes
2078.7|3.84|for us I think because we are using
2080.74|3.419|teleopper demonstrations the data was
2082.54|3.96|more homogeneous
2084.159|3.96|um than perhaps like uh in the wild for
2086.5|3.119|example there's a type of data function
2088.119|2.941|called play data where operators just do
2089.619|3.181|whatever they want and we label in
2091.06|3.299|hindsight and I think our data is more
2092.8|3.599|homogeneous than that but we did not
2094.359|4.681|find a lot of the issues that we've seen
2096.399|4.2|in Prior projects one
2099.04|4.079|um potential answer is maybe it's it's
2100.599|6.321|the it's the architecture itself but we
2103.119|3.801|can talk about that later too question
2113.579|4.721|uh great question uh we actually do have
2116.14|3.479|a termination action so the policy
2118.3|3.42|itself that's right so the question was
2119.619|4.261|how do you determine when a episode is
2121.72|4.08|complete and uh the policy is able to
2123.88|3.84|predict terminate um because at the end
2125.8|3.18|of each tele operation session the
2127.72|4.82|operator can click the button and it's
2128.98|3.56|marked as the episode's done
2138.94|3.24|yeah I think for these evaluations we
2140.92|3.0|were quite strict
2142.18|4.14|um but definitely I think in some cases
2143.92|4.14|uh you know maybe maybe if we're just
2146.32|4.62|doing an experiment for ourselves we'll
2148.06|4.98|have a dense reward scale of like grasp
2150.94|3.6|the object and move closer graspy object
2153.04|3.24|and almost got there if I messed up at
2154.54|4.319|the end and we'll have like a grading
2156.28|4.559|curve basically but for all these all of
2158.859|4.98|these um stats I'm showing here it was
2160.839|5.341|zero or one one fully complete zero was
2163.839|4.621|not fully complete
2166.18|3.659|cool
2168.46|2.58|um and I think what was expecting
2169.839|3.181|exciting maybe talking about the
2171.04|3.66|multi-modaly aspect is then we pushed
2173.02|4.079|the limit even further we were TR we
2174.7|3.78|decided to train on very diverse data
2177.099|4.081|distributions
2178.48|5.16|um you're you're back by that yeah okay
2181.18|4.86|um so right now you saw 130 to a
2183.64|4.92|thousand demonstrations trained on this
2186.04|4.44|everyday robot um a proprietary um
2188.56|3.48|mobile manipulator but we were also
2190.48|3.599|looking to trade on very different data
2192.04|3.48|distributions with very different you
2194.079|3.54|know action distributions very different
2195.52|4.8|trajectories even very different visuals
2197.619|4.441|objects tasks and to do that we included
2200.32|3.72|two other data sources one was
2202.06|4.08|simulation data which was kind of our
2204.04|4.02|robot plot in sin but it looked quite
2206.14|3.719|different and also this data was
2208.06|4.38|collected with reinforcement learning
2209.859|4.98|and not with teleopper demonstrations in
2212.44|4.679|the past with all the IL plus RL work
2214.839|4.5|that I mentioned we found that combining
2217.119|4.74|these these two types of data was going
2219.339|4.681|to be very difficult because RL beta has
2221.859|4.021|very short actions um it's very quick
2224.02|4.26|it's very optimized for the specific
2225.88|4.86|reward function versus human collected
2228.28|4.5|teleoperation data is a lot more you
2230.74|3.96|know human life so to speak and finally
2232.78|3.54|we revived a data set from many years
2234.7|3.48|ago a 2018
2236.32|3.539|um if you remember the Kuka project that
2238.18|3.419|arm Farm has now been operational in
2239.859|3.72|that state for many years now but we had
2241.599|4.561|that data still and so we were hoping to
2243.579|4.081|see if a different robot with a
2246.16|3.06|different action space on different
2247.66|3.12|objects with different visuals in a
2249.22|3.359|different building could still be
2250.78|5.16|combined with data from this micro
2252.579|5.401|kitchen uh um data set that we train on
2255.94|4.679|originally and what was very surprising
2257.98|4.02|to me is that rt1 was able to learn from
2260.619|3.301|all these very diverse data
2262.0|3.9|distributions I had never seen a result
2263.92|4.98|like this or any other architecture for
2265.9|4.38|example a resnet or even another
2268.9|3.54|learning method like reinforcement
2270.28|4.26|learning could successfully learn on
2272.44|4.5|such different data distributions
2274.54|4.02|um so robustly and we evaluated for
2276.94|4.56|example on combining Concepts so we
2278.56|5.1|would have the original everyday robot
2281.5|4.619|robot pick up objects that were only
2283.66|4.74|seen in the Kuka project or we would put
2286.119|3.841|objects only seen in simulation and see
2288.4|2.76|if our policy could understand that so
2289.96|2.94|it did seem like it could generalize
2291.16|3.66|between objects it's seen in other data
2292.9|4.08|sets and Concepts that had seen in other
2294.82|4.92|data sets into the setting it was in now
2296.98|6.74|in the real micro kitchen and that was a
2299.74|3.98|very fun result yeah
2306.359|4.0|great question
2308.14|3.959|um yeah we just tokenized it and made
2310.359|3.841|sure that the tokenization scheme was
2312.099|4.681|kind of interoperable I think that was
2314.2|5.48|the um I I can dive into that in a bit
2316.78|2.9|later too yeah
2319.9|3.42|um and no no that does not mean we can
2321.46|3.42|send the exact actions for one robot to
2323.32|3.66|another and have it execute it was more
2324.88|3.42|just like in the data set I think even
2326.98|2.22|by human inspection you can tell that
2328.3|1.86|these are coming from two different
2329.2|2.22|robots
2330.16|3.48|um
2331.42|3.54|so yeah uh let's look at some ablations
2333.64|2.34|for the scaling laws that we're all here
2334.96|2.639|for now
2335.98|4.08|um we found that you know reducing data
2337.599|4.441|size reduces performance but more
2340.06|3.96|interesting maybe is Task diversity was
2342.04|3.78|quite important here we have two
2344.02|4.62|different Trends uh
2345.82|4.92|um the uh green line is what happens
2348.64|4.979|when we reduce the total amount of
2350.74|4.92|episodes per task and then gray on here
2353.619|4.021|the purple curve is for what happens
2355.66|4.14|when you reduce the total number of
2357.64|4.979|tasks when we found that having more
2359.8|5.4|tasks is relatively more important than
2362.619|4.98|having more data for each task
2365.2|4.44|and I think this was a lesson that I
2367.599|3.781|think is probably going to suggest
2369.64|3.719|um ways that you know we should scale
2371.38|4.14|robotics even further is not to just
2373.359|3.961|collect more data of the same task in
2375.52|5.54|the same settings but to go out into the
2377.32|3.74|wild and get more diverse Behavior
2383.92|4.5|great question uh question is how do you
2385.72|4.44|define data diversity in this case um I
2388.42|4.14|uh it's just a number of unique
2390.16|4.74|structured templated commands that tele
2392.56|4.26|operators receive so those 700 templated
2394.9|4.439|commands but when you start reducing
2396.82|4.74|them and only train on 500 or only trade
2399.339|4.02|on 300 of them performance drops much
2401.56|4.38|quicker than if we had take taken the
2403.359|3.901|same proportional uh cuts to the total
2405.94|4.139|yeah
2407.26|4.319|still I guess I'm very familiar but I
2410.079|4.221|don't know
2411.579|2.721|uh
2418.3|2.0|um
2422.38|4.08|yeah I I don't think we um the question
2424.96|3.48|was there seems to be almost a linear
2426.46|4.139|correlation between a data size and
2428.44|3.659|success rate and I think you know we
2430.599|3.181|could apply some fancy like you know
2432.099|3.661|scaling law you know trying to curve
2433.78|3.96|fitting but uh we didn't look too much
2435.76|3.48|into that because you know this is a
2437.74|3.48|trend that we kind of expected we just
2439.24|3.96|weren't sure about the the magnitude of
2441.22|5.22|how much it would affect us
2443.2|4.919|um and uh I think I don't have any
2446.44|3.84|really good insights on this besides
2448.119|4.701|that we see this phenomenon empirically
2450.28|2.54|yeah
2457.0|2.06|yeah
2465.3|4.12|yeah and and great question so so the
2468.04|2.88|question is oh yeah maybe this will just
2469.42|2.88|go on indefinitely um or is there
2470.92|4.439|something magical about you know January
2472.3|6.6|2023 and I think this is maybe also a a
2475.359|5.22|this is when we start to conflate um the
2478.9|3.3|algorithmic Exploration with like the
2480.579|3.78|Practical considerations of scaling real
2482.2|3.78|world operations which was when we got
2484.359|2.941|enough data our policies were hitting
2485.98|3.3|you know saturating on these hitting
2487.3|4.319|close to 100 we're like all right let's
2489.28|4.079|connect collect another data set so we
2491.619|3.361|basically collect until it's at 100 and
2493.359|2.941|then we switch to something else
2494.98|3.06|um but at this point what was
2496.3|3.72|interesting is that when we kind of bet
2498.04|3.66|really big on this rt1 architecture we
2500.02|3.66|are we'd already been collecting demos
2501.7|3.84|for a while so it was possible that we
2503.68|3.419|had collected more than we needed and in
2505.54|2.94|some cases it actually you could cut
2507.099|2.941|tasks without losing too much
2508.48|3.92|performance which was quite interesting
2510.04|2.36|but
2530.56|3.0|foreign
2540.18|4.12|equal in terms of like their capacity
2542.44|3.12|and entropy for different behaviors you
2544.3|2.64|can learn from them and yeah that's
2545.56|3.42|definitely true some tasks are much
2546.94|3.72|easier we have a task that's just pick
2548.98|3.42|up this object that's going to have much
2550.66|3.78|less interesting stuff you can squeeze
2552.4|3.48|out of it than you know moving something
2554.44|5.3|into a drawer and then closing the
2555.88|3.86|drawer um but yeah great question
2560.92|4.08|um right now um ablations uh we also
2563.2|3.84|trained without the big model size we
2565.0|3.24|did it without pre-training without uh
2567.04|3.299|you know with continuous instead of
2568.24|3.599|discrete actions with with a lot of
2570.339|3.78|aggressive actions without history
2571.839|5.101|without the Transformer uh and I think
2574.119|6.801|all these design choices did seem to be
2576.94|3.98|required for robust performance
2581.52|3.36|oh yeah of course
2589.06|2.6|foreign
2592.38|5.199|yeah I I think all I mean like and again
2596.079|3.0|you know for for paper writing it's kind
2597.579|3.661|of like the best thing that we can
2599.079|3.421|empirically find that's that's the
2601.24|3.18|method and then we'll figure out why
2602.5|3.599|each of these are important and so uh
2604.42|3.6|yeah I think what one surprising thing
2606.099|3.361|here perhaps was that auto regressive
2608.02|2.88|actions hurt you might think that
2609.46|3.659|passing in more information is always
2610.9|4.199|better than passing in fewer fewer
2613.119|4.2|information but in this case uh maybe
2615.099|3.841|conditioning on your previous actions
2617.319|3.361|was kind of doing kind of like in
2618.94|3.72|context learning it was doing online
2620.68|3.3|systems identification to figure out
2622.66|3.659|what
2623.98|4.08|teleoc radar this data came from and
2626.319|3.78|like how you can overfit to that
2628.06|4.2|specific set of action history and so
2630.099|5.961|removing that was actually better
2632.26|3.8|um one interesting tidbit there
2636.52|4.38|um cool then and uh maybe in the
2639.28|4.2|interest of time I'll try to get through
2640.9|4.38|the other ones uh a bit more quicker and
2643.48|3.24|then we can maybe just do fewer uh we'll
2645.28|3.299|I'll just uh do the questions at the end
2646.72|4.139|if that's possible um just so we have
2648.579|3.721|time to get through everything
2650.859|3.121|um the next work here moving a bit away
2652.3|3.539|from skill learning then and actually on
2653.98|3.119|to the planning level I think the first
2655.839|3.421|project took a lot of the design
2657.099|4.201|principles of other fields um and uh
2659.26|4.38|this offline robot learning Paradigm and
2661.3|3.42|put it into the skill learning can we
2663.64|3.12|actually bring that out to other parts
2664.72|3.78|of the robotic system and the first work
2666.76|4.5|here is say can if you remember here
2668.5|5.16|back in this timeline in 2022 we started
2671.26|4.68|thinking about oh yeah how do we scale
2673.66|4.62|um this multitask imitation learning but
2675.94|3.899|at the same time large language models
2678.28|3.24|and you know other types of foundation
2679.839|4.441|models are really picking up steam
2681.52|4.02|whether it was Imogen or dolly two
2684.28|3.36|um and we definitely wanted to figure
2685.54|4.079|out how we could use those as well we
2687.64|4.14|had come up with this rtu 2-1 design
2689.619|4.321|that we're betting big on but um from
2691.78|4.26|here we started to explore how all of
2693.94|4.08|the beta lesson 2.0 we could start
2696.04|5.279|utilizing Foundation models within the
2698.02|5.88|context of our full stack system
2701.319|4.26|the problem of doing this naively is
2703.9|3.9|that language models are not completely
2705.579|3.061|a very natural fit for robotics for
2707.8|2.279|example
2708.64|2.699|um if you're a robot in a kitchen you
2710.079|3.061|ask a language model I sell my drink
2711.339|3.421|what can you do language model will give
2713.14|3.179|you stuff that's not very relevant it's
2714.76|3.599|going to ask you to vacuum it it's going
2716.319|3.601|to ask you to call cleaner or it's going
2718.359|3.361|to apologize and these are not things
2719.92|4.14|that the robot can do in your kitchen
2721.72|4.859|with your spill drain to help you
2724.06|5.039|and so there are two parts of this then
2726.579|5.101|uh the one issue is that our robots are
2729.099|3.841|limited they are very constrained with
2731.68|2.58|what they can do they cannot do
2732.94|4.2|everything but they can do certain
2734.26|5.16|things and then the second problem is
2737.14|3.66|that um the language models are also
2739.42|3.0|constrained they don't know what the
2740.8|3.36|robot sees they don't understand that
2742.42|4.14|they are in a robot body in a micro
2744.16|5.1|kitchen needing to do real stuff in the
2746.56|4.86|physical world and so we need to get the
2749.26|3.839|robots to speak language model language
2751.42|3.6|and then the language model to see to
2753.099|5.101|speak robot language
2755.02|4.319|um to do this we present secan uh in the
2758.2|4.02|same setting you know please put an
2759.339|4.74|apple on the table uh we score on the
2762.22|3.54|predictions of the language model on a
2764.079|4.141|constrained set of tasks that we know
2765.76|3.78|the robot has been trained to do and
2768.22|2.639|then we also take the affordance
2769.54|4.44|function from the robot and affordance
2770.859|5.341|function is a estimation of given some
2773.98|4.379|kind of State uh what the robot is able
2776.2|4.08|to do um how confident it is that it can
2778.359|3.601|successfully accomplish that task in the
2780.28|3.24|given state in our case we use something
2781.96|3.24|like a value function from reinforcement
2783.52|4.02|learning which kind of accomplishes this
2785.2|3.84|quality given these two values these two
2787.54|3.059|scores we have the confidence from the
2789.04|4.079|language model and then the confidence
2790.599|4.141|from the robot we can combine these and
2793.119|3.24|then hopefully the combined prediction
2794.74|3.24|is both something that's going to be
2796.359|3.72|very semantically relevant for the high
2797.98|3.72|level instruction finding an apple is
2800.079|3.24|the first step and please put an apple
2801.7|3.3|on the table but it's also something
2803.319|3.78|that the robot can do there's no robot
2805.0|3.42|on the frame but it knows that it's been
2807.099|2.941|trained to find an Apple so it can
2808.42|3.06|navigate around to find it and so
2810.04|3.36|hopefully you can do this then in closed
2811.48|3.54|loop and then keep on going and
2813.4|3.54|predicting a high level plan from the
2815.02|3.48|language model that's grounded with the
2816.94|4.08|affordance function of what the robot
2818.5|4.68|understands
2821.02|3.72|um there's a video here of the uh
2823.18|3.419|station doing different stuff but you
2824.74|4.619|know happy to share it later um offline
2826.599|7.26|uh it's very cool trust me it's the
2829.359|4.5|greatest thing since I spread wow
2836.14|4.74|um and yeah some numbers then uh we
2838.78|4.319|tested this out on very long Horizon
2840.88|4.38|instructions encompassing more than 10
2843.099|4.081|separate navigation and manipulation
2845.26|3.72|skills in the micro kitchen that you see
2847.18|3.72|on the bottom right
2848.98|3.78|um we evaluated
2850.9|4.08|um hundreds of different evaluations on
2852.76|3.9|this and we tested out very a lot of
2854.98|4.26|different concepts including things like
2856.66|4.38|rephrasing by using single Primitives by
2859.24|3.96|drawing um instructions that just came
2861.04|4.98|from uh you know colleagues and Friends
2863.2|4.44|uh and then we and we found that uh
2866.02|3.54|while they were failures in both the
2867.64|3.479|language model planning stuff side where
2869.56|3.6|it would predict the wrong path for the
2871.119|4.021|current situation as well as on a policy
2873.16|3.6|execution side even when it gets a good
2875.14|5.719|plan the robot will mess up sometimes
2876.76|4.099|overall it was still doing quite well
2881.5|4.8|um and now let's kind of take this back
2884.44|4.98|to the lesson I I think this is a very
2886.3|4.86|great example of how we can leverage
2889.42|3.48|um internet uh internet scale Foundation
2891.16|3.179|models as they get better when we
2892.9|3.84|started the project we started with a
2894.339|4.801|language model called flan from Google
2896.74|4.379|um throughout our implementation uh Palm
2899.14|3.78|came online Pathways language model and
2901.119|4.681|when that happened we were able to just
2902.92|4.62|hot swap it in and uh performance just
2905.8|3.9|kind of got better for free without us
2907.54|4.319|having to do anything by just assuming
2909.7|3.84|that language was the API the plan just
2911.859|3.24|has to be any string it can come from
2913.54|3.18|any Source it can come from a human it
2915.099|3.301|can come from a language model but we
2916.72|3.18|improve that language model the system
2918.4|3.36|gets better overall
2919.9|4.02|um and here you see with the scaling
2921.76|4.2|size is as the model LOM increased in
2923.92|4.28|size our planning performance got even
2925.96|2.24|better
2930.52|4.2|um and some cool tricks here to get it
2932.56|4.5|working well how did we actually produce
2934.72|4.32|this plan well just by prompting um as
2937.06|3.72|is the ridge these days uh with Chain of
2939.04|3.72|Thought um and with better prompting of
2940.78|4.74|just giving examples of here's some
2942.76|4.02|great robot plans now give me a new plan
2945.52|3.18|starting with this high level
2946.78|3.66|instruction uh we saw that the robot
2948.7|4.26|could do all things from uh
2950.44|4.44|understanding different languages to uh
2952.96|3.24|asking asking them to be very complex
2954.88|3.0|reasoning like hey give me something
2956.2|3.0|caffeinated or I don't do caffeine
2957.88|2.219|anymore get me something like you know
2959.2|2.52|better
2960.099|3.72|um or I could bring me a healthy snack
2961.72|4.139|versus bring me a unhealthy stack second
2963.819|3.8|was able to link a reason through all of
2965.859|4.74|these
2967.619|4.96|Let's uh you know I think that was our
2970.599|4.26|kind of the first Contact of Robotics
2972.579|4.201|with language models on our team and it
2974.859|3.781|was the first exploration into how these
2976.78|2.7|two worlds could overlap
2978.64|2.52|um there was definitely still
2979.48|3.24|improvements though and in a monologue
2981.16|4.199|we try to improve those further by
2982.72|5.76|bringing in Vision language models
2985.359|6.0|the idea here is that uh you know we had
2988.48|4.619|very high plan rate success uh with uh
2991.359|3.541|say can but unfortunately it wasn't
2993.099|3.901|really able to recover from failures
2994.9|3.78|what I mean by that is that the language
2997.0|3.359|model would not really get updates of
2998.68|3.6|what was going on in the world so that
3000.359|3.901|if this was a planet proposed go to the
3002.28|3.539|table pick up a Coke bring it to you but
3004.26|3.3|you messed up again the cocaine you
3005.819|3.361|dropped it on the floor it would still
3007.56|2.94|continue trying to bring it to you put
3009.18|2.76|it aside but all of that does not really
3010.5|3.96|matter anymore because you dropped the
3011.94|4.56|Coke can and so in this work
3014.46|4.1|um in our monologue we were really
3016.5|4.2|hoping to figure out how we could add
3018.56|5.44|closed-loop Dynamic feedback from the
3020.7|5.94|environment into this planning process
3024.0|4.26|let's take that exact same example
3026.64|3.66|um now instead of just directly
3028.26|3.48|predicting every instruction maybe we
3030.3|4.08|add back some feedback from the scene
3031.74|4.92|also conveyed using language as the
3034.38|4.62|universal API here the scene can tell
3036.66|4.26|you what's actually in them maybe uh the
3039.0|3.18|robot asks a question now in the robot
3040.92|3.24|this is a language model asking the
3042.18|3.6|clarification question maybe here a
3044.16|4.199|human response or another language model
3045.78|4.559|then you can predict action uh the next
3048.359|4.081|task to do once the landing model has
3050.339|3.961|enough context and maybe even add in
3052.44|4.44|stuff like success detection
3054.3|4.5|um and so on and so forth how do we do
3056.88|3.719|this then well
3058.8|3.6|um the first thing that we Implement is
3060.599|4.141|what we call passive scene description
3062.4|4.199|just using either an off-the-shelf
3064.74|4.44|engineered heuristic using object
3066.599|4.621|detection models something like vile uh
3069.18|4.139|you can describe the scene in text and
3071.22|3.96|just convey all that context to the
3073.319|3.661|language model
3075.18|3.12|for active scene description this is
3076.98|2.52|maybe similar to visual question
3078.3|3.9|answering if you're familiar with that
3079.5|5.7|field uh the language model can actually
3082.2|4.619|propose active queries that it's curious
3085.2|3.96|about in the scene maybe to make sure
3086.819|3.961|that has enough context to move on and
3089.16|4.199|here either a human can provide the
3090.78|5.4|answer or in the future a vqa model as
3093.359|4.98|they improve can provide that
3096.18|4.08|and finally for Success detection uh
3098.339|3.601|this is very important to allow the
3100.26|3.66|language model planner to know when to
3101.94|3.54|try to retrace something
3103.92|4.08|um here we take in the first and last
3105.48|5.339|image fine tune a clip success detector
3108.0|4.38|and use that to provide binary success
3110.819|3.861|failure information back to our language
3112.38|2.3|model
3115.319|4.381|um
3116.22|5.099|and for the results wise we can see a
3119.7|3.96|very similar second long Horizon
3121.319|5.161|evaluation but here we actually what's
3123.66|4.56|interesting um is that we're able to and
3126.48|3.839|and basically Implement all these
3128.22|4.2|different automated feedback mechanisms
3130.319|4.621|on the robot and so that it's able to
3132.42|4.679|reason and recover from things here you
3134.94|4.139|see it's going to try to
3137.099|3.901|um go to the table
3139.079|3.721|um but the humans actually been saying
3141.0|3.3|hey I changed my mind uh and then it
3142.8|3.42|changes the human changes mind again
3144.3|3.6|asking it to go back and forth and the
3146.22|2.94|robot's able to you know maybe we're
3147.9|3.0|kind of torturing the language model at
3149.16|3.72|this point but the language also able to
3150.9|5.179|replan and you know make sure that the
3152.88|3.199|human intent is satisfied
3158.46|3.48|um we also tried I'm not sure if this
3160.02|4.079|video shows it uh but situations where
3161.94|4.379|we did adversarial inputs where I walked
3164.099|4.26|around and just kind of knocking objects
3166.319|3.78|out of the robot's hands and um forcing
3168.359|4.881|the success detector to tell it hey you
3170.099|3.141|messed up you know try again
3175.26|4.02|um
3177.0|3.96|and uh we also tried this out on a
3179.28|3.48|couple different domains a simulated
3180.96|3.78|tabletop manipulation domain as well as
3182.76|4.14|a real world manipulation domain and we
3184.74|5.22|found that this was uh much better than
3186.9|4.26|say can or let's say just only using um
3189.96|3.48|visual features themselves with
3191.16|5.64|something like clipboard
3193.44|4.32|and I think here uh it really speaks
3196.8|2.46|towards
3197.76|4.319|um a trend that I've really come to
3199.26|4.5|appreciate uh in 2018 a robotics
3202.079|3.061|Professor once said that when they look
3203.76|3.18|at all the different things preventing
3205.14|3.12|robot learning from scaling tremendously
3206.94|2.52|they thought the bottleneck was high
3208.26|3.599|level of semantic planning about
3209.46|5.58|reasoning about common sense and I think
3211.859|6.301|in 2022 and 2023 language models can
3215.04|5.46|provide a One path of how this can kind
3218.16|5.22|of be offloaded at least in the interim
3220.5|5.16|and I think if language models are the
3223.38|4.08|API then you can just bring in these
3225.66|3.06|Vision language models as object
3227.46|3.42|detectors get better as success
3228.72|4.32|detectors as eqa as landfalls get better
3230.88|3.959|you can bring them all into the fold and
3233.04|3.84|the ACT is kind of a life vest if your
3234.839|4.081|robot currently does not have common
3236.88|3.78|sense reasoning uh these other models
3238.92|3.659|can act as a scaffold in their life fast
3240.66|3.6|to bring you up to par with what they
3242.579|3.421|currently love and maybe then in the
3244.26|3.299|future you'll get beyond what the
3246.0|2.76|language models know but in the short
3247.559|3.06|term it does seem that we can leverage
3248.76|4.16|them to accelerate what we can do in the
3250.619|2.301|real world
3253.319|4.201|um moving on now from we saw now how
3255.72|3.42|language models could do planning we saw
3257.52|3.24|how Vision language models could help
3259.14|3.36|planning and now we're going to switch
3260.76|3.54|gears a bit and think about how Vision
3262.5|3.54|language models can help other aspects
3264.3|3.6|of the bottlenecks that robot learning
3266.04|4.68|faces
3267.9|4.62|um one of these is that a data
3270.72|4.74|collection is very expensive as we
3272.52|5.4|mentioned before we did have this 130
3275.46|4.32|000 episode demonstration data set
3277.92|4.199|um but it was collected over a year and
3279.78|5.4|a half at significant cost
3282.119|6.301|um both in resources and time and money
3285.18|5.76|um and uh with many many robots and of
3288.42|4.8|course these tasks too were also
3290.94|4.56|a bit limited right we use 700 very
3293.22|4.32|templated commands instructions that we
3295.5|4.26|give to Tele operators because we knew
3297.54|4.079|that this was this would scale right if
3299.76|3.96|we collected enough data for each of
3301.619|3.421|these templated tasks we could do that
3303.72|2.7|specific task
3305.04|3.18|um and here's the the flow that someone
3306.42|3.54|was asking about earlier we give this
3308.22|3.18|cocaine instruction the operator
3309.96|3.84|controls the robot in the real world
3311.4|4.56|finished the task mark step so to
3313.8|3.84|terminate and then uh you know shade
3315.96|3.06|that out to this big orange data set and
3317.64|3.3|that big orange data set is what we
3319.02|3.72|train on in all the previous projects
3320.94|4.02|for the control policies
3322.74|3.96|what we originally considered was adding
3324.96|3.18|a bit of crowdsourced hindsight
3326.7|3.6|annotation if you're familiar with it
3328.14|3.36|with a hindsight experience replay
3330.3|3.6|um in reinforcement learning with gold
3331.5|4.26|conditioning uh with you know maybe the
3333.9|3.36|robot did something that wasn't just
3335.76|4.02|this high level templated instruction
3337.26|4.859|you could ask a human to describe more
3339.78|3.72|verbosely what the robot did maybe it
3342.119|3.181|picked up the cocaine that was on the
3343.5|3.359|right side of the table maybe it picked
3345.3|3.24|it up and then knocked it over maybe it
3346.859|3.841|moved it very slowly to the middle
3348.54|4.74|there's a lot of semantic diversity
3350.7|5.1|encompassing this uh demonstration that
3353.28|4.799|was that is not totally you know uh
3355.8|5.039|caught by this high level templated pick
3358.079|4.381|Coke can instruction so we labeled um
3360.839|5.541|three percent of this big orange data
3362.46|3.92|set with these very verbose descriptions
3366.54|4.319|um and next we uh kind of Applied the
3369.059|3.78|pseudo-label strategy strategy that's
3370.859|3.601|been seen in other fields such as video
3372.839|3.78|pre-training with their inverse Dynamics
3374.46|4.44|model well instead we apply that to the
3376.619|4.681|instructions to the semantics of what's
3378.9|4.8|contained in your data set so step one
3381.3|5.4|we pre-train a clip model
3383.7|4.919|um on your small label data set of three
3386.7|4.2|percent of your main data
3388.619|5.46|then you go ahead and use that trained
3390.9|5.1|BLM data to label all of the templated
3394.079|5.101|instruction demonstrations that you had
3396.0|5.339|before that 130 000 episode data sets
3399.18|4.379|now you have a relabel data set which
3401.339|4.321|has a large diversity of interesting
3403.559|4.681|semantic instructions
3405.66|5.1|um and then we plug in all of these data
3408.24|4.2|sets into rt1 and just train a language
3410.76|4.859|condition Behavior cloning policy
3412.44|4.74|similarly to how we would normally with
3415.619|3.72|even though normally we just use dataset
3417.18|4.139|B the orange one now we use all three
3419.339|5.101|data sets
3421.319|5.04|and then finally we evaluate on entirely
3424.44|4.32|new unseen instructions
3426.359|5.041|um in the prior works right we were
3428.76|4.26|evaluating mainly on the 700 templated
3431.4|3.659|instructions but in this work we
3433.02|3.9|actually go beyond that we can type in
3435.059|3.841|you know almost anything you want that
3436.92|3.54|you think might succeed and you can
3438.9|4.56|phrase it how you can you can add typos
3440.46|4.5|you can even do it by referring to
3443.46|5.54|semantic Concepts you can add spatial
3444.96|4.04|Concepts and we see how it does
3449.46|4.02|um the reason that this might work uh
3451.44|4.139|maybe visually to represent this is here
3453.48|3.839|are the Disney embeddings
3455.579|3.841|um on the left and the right it's the
3457.319|4.561|same embeddings but on the left they're
3459.42|5.1|colored by the original templated
3461.88|5.4|instruction that was used to collect
3464.52|4.98|that episode and on the right is what
3467.28|4.44|the vision language model thinks um if
3469.5|4.26|it's allowed to put a free-form natural
3471.72|3.72|language caption and assign it to that
3473.76|3.9|episode you see that on the left you
3475.44|4.02|have these big clusters of pick cocan is
3477.66|3.36|like you know hundreds or thousands of
3479.46|3.359|episodes but we all just call them pick
3481.02|3.48|Coke can on the right then we can then
3482.819|4.02|expand those Concepts and say actually
3484.5|4.74|this episode is picking up the red
3486.839|4.141|cocaine this this episode is picking up
3489.24|3.54|the clump of cocam this is picking up
3490.98|3.9|the cocaine that's next to the chip bag
3492.78|4.2|and so you can get a lot more mileage
3494.88|4.439|out of the same underlying data set by
3496.98|4.02|just using language as the diversity
3499.319|3.121|mechanism through which you kind of
3501.0|3.0|expand the concepts that you're
3502.44|2.879|considering and for example in the
3504.0|2.88|middle you see
3505.319|3.721|um you know open top drawer can become
3506.88|4.02|hold and pull out the top drawer we have
3509.04|4.14|stuff like the center left for the
3510.9|3.9|middle um for the Middle episode for the
3513.18|3.899|bottom one pick Green rice chips from
3514.8|3.72|white bowl becomes lift up the chip bag
3517.079|3.121|from the bowl and drop it at the bottom
3518.52|3.24|left corner of the table so you had a
3520.2|3.419|lot of these semantic um you know
3521.76|5.339|spatial Concepts that are now going to
3523.619|7.321|be in your target supervised labels
3527.099|3.841|I have a question regulations
3534.66|2.0|um
3550.619|3.661|yeah
3551.46|4.92|um great question so I I guess if I can
3554.28|4.2|rephrase a bit um the problem is that
3556.38|3.66|like it's actually a very um difficult
3558.48|3.18|and uh perhaps even attractive problem
3560.04|3.779|of how you map all the linguistic
3561.66|4.62|Concepts you see out in the wild down to
3563.819|4.321|like maybe like embodied specific uh
3566.28|3.9|types of episodes and like
3568.14|3.719|here maybe I would say is that we are
3570.18|4.2|definitely introducing a lot of our
3571.859|4.921|pliers and our biases onto like maybe
3574.38|3.959|what we call as left you mean left 10
3576.78|4.799|centimeters left two centimeter meters
3578.339|5.401|like like what do words mean and these
3581.579|3.841|definitions what do they mean to us to
3583.74|3.3|the crowd compute Raiders that generated
3585.42|2.639|these captions what do they mean to the
3587.04|2.819|robot what do they mean to the language
3588.059|4.56|models maybe these are all slightly
3589.859|5.101|different but the hope is at least if
3592.619|4.921|they're roughly similar we'll get like
3594.96|4.74|directionally correct improvements so I
3597.54|4.74|I would say the nuances of this specific
3599.7|5.159|hard lines of definitions and like
3602.28|5.46|actual like you know semantic meaning of
3604.859|4.321|these words I think that's maybe out of
3607.74|3.42|scope right now but maybe something
3609.18|3.54|we'll dive into further at a higher
3611.16|3.419|level though I think basically the bar
3612.72|3.899|is just so low we have these 700
3614.579|4.141|template instructions that are basically
3616.619|4.44|one hot IDs and we just want to make
3618.72|3.839|those closer to natural language
3621.059|3.661|um even if by a little
3622.559|4.201|um and I think at least we're we're
3624.72|3.78|trying to get towards that with these
3626.76|4.02|Vision language models that are cap came
3628.5|4.46|automatically I hope that answers your
3630.78|2.18|question
3633.0|3.72|and uh we also compared to a few bass
3635.88|3.12|lines
3636.72|4.32|um on the top left here we look at what
3639.0|4.26|if we only train on this three percent
3641.04|4.14|of the these fancy human rated labels
3643.26|4.26|what if we only train on the original
3645.18|4.679|rt1 data sets what if we train on both
3647.52|4.86|of these and what if we train on both of
3649.859|4.74|these plus all of the predictions given
3652.38|4.979|by our BLM and what's interesting here
3654.599|5.22|is that uh you know really labeling
3657.359|4.74|seems to universally help uh we we
3659.819|3.78|evaluated only on novel instructions
3662.099|3.181|that was new for this project it's the
3663.599|3.901|first time on a robotics project where
3665.28|3.66|we only tested on something I could type
3667.5|3.66|whatever I thought I'll type it in and
3668.94|3.24|that became the the test set and we just
3671.16|4.5|had to make sure that it was never
3672.18|4.619|contained in the the training coverage
3675.66|2.76|um and you see all these interesting
3676.799|4.141|examples on the right here of stuff like
3678.42|4.62|move the lonely object to the others I I
3680.94|3.96|have no idea how this worked
3683.04|3.24|um stuff like you know just lifting the
3684.9|3.48|yellow rectangle talking about colors
3686.28|3.839|talking about move the right Apple to
3688.38|3.9|the left here we actually had two apples
3690.119|3.96|in the scene and actually in our
3692.28|4.319|training demonstration data we never
3694.079|3.901|collected scenes with duplicate objects
3696.599|2.581|just because you know we thought of this
3697.98|2.94|multiple modality problem if you just
3699.18|3.119|say pick cocannon there's two Coke cans
3700.92|2.939|it's going to be very difficult to
3702.299|3.3|figure out which one to do but with
3703.859|3.24|language labeling it seems like maybe
3705.599|3.121|you could do that now so even though we
3707.099|3.48|never trained on scenes with two apples
3708.72|3.78|now you can evaluate on them and just
3710.579|3.841|specify with language which Apple you
3712.5|4.38|want to go for and it was working pretty
3714.42|4.26|reasonably
3716.88|3.719|um and finally for the last example here
3718.68|3.6|I thought it was kind of interesting uh
3720.599|4.381|a single cocan we try to do a novel
3722.28|5.279|Behavior Uh push towards the left was
3724.98|6.24|not a templated instruction we only had
3727.559|6.3|move cocan near Y where Y is another
3731.22|5.16|object near apple with cocaine in your
3733.859|4.921|sponge so pushing this motion of just
3736.38|4.08|pushing the the cocaine into air
3738.78|3.42|essentially was not something that we
3740.46|3.78|ever encompassed but maybe it was in one
3742.2|4.08|of the labels maybe like if you've seen
3744.24|3.66|like a smooth Coke can near Apple and
3746.28|3.66|the apples on the left and you saw blue
3747.9|3.36|cocan near sponge and the sponges on the
3749.94|3.119|left you would General the model can
3751.26|3.599|generalize and be like Oh left means
3753.059|3.121|this side of the table not a specific
3754.859|2.641|object
3756.18|4.08|um so maybe that's what's happening but
3757.5|4.68|it's very unclear this is as I said uh
3760.26|3.9|you know just I I type I thought of
3762.18|3.48|something I typed it and just saw what
3764.16|3.179|happened uh and we definitely hope to
3765.66|2.76|explore this more quantitatively in the
3767.339|2.401|future
3768.42|2.82|um bottom left course is I think
3769.74|3.54|comparing against non-visual
3771.24|3.48|augmentation so maybe you can also get
3773.28|4.26|these interesting Concepts just from
3774.72|5.099|language alone right here we had adding
3777.54|4.62|random noise or we do Mad Lib Style Just
3779.819|5.161|swapping out words or we even use a LOM
3782.16|5.28|gpd3 in this case to propose rephrasings
3784.98|4.619|of existing instructions but I think my
3787.44|3.54|takeaway there is that you really need
3789.599|3.661|visual grounding for the visual language
3790.98|4.56|model to say actually yeah this caption
3793.26|4.26|is factually accurate at this given
3795.54|4.2|point in time and that it's you know
3797.52|4.319|something perhaps that um would be
3799.74|4.079|interesting for a robot that fine-tuning
3801.839|5.061|process provides both
3803.819|3.081|children died
3813.0|4.92|yeah yeah definitely uh these are just
3815.819|4.201|some subsets of five of these evaluation
3817.92|4.139|instructions but we had over 60 of them
3820.02|4.5|uh we didn't do a full quantitative
3822.059|4.921|ablation for example as we did um in rt1
3824.52|5.039|we had this like seen in unseen task set
3826.98|4.92|and that was compositional you'd see you
3829.559|4.081|know move Coke near Apple and you would
3831.9|3.6|see move Apple in your sponge but we'd
3833.64|3.479|hold out move Coke near spun and we
3835.5|2.819|would test that out well in this case I
3837.119|3.061|think we can go much be more beyond that
3838.319|4.681|because our language is completely free
3840.18|4.619|form the compositional space of what you
3843.0|3.42|can kind of combine is just going to be
3844.799|3.54|much larger so we did try a little bit
3846.42|4.02|to answer your question we tried some
3848.339|4.141|combinatorial evaluations but there's
3850.44|4.76|definitely a lot more thoroughness that
3852.48|2.72|we could do there too
3855.359|3.661|um how am I doing on time okay 10
3856.98|4.319|minutes um maybe I'll try to wrap up
3859.02|5.039|pretty soon then uh the dial of takeaway
3861.299|4.381|then is that um two parts right lesson
3864.059|3.601|two leverage Foundation models let's use
3865.68|3.6|them as data documentation and lesson
3867.66|4.199|three let's make sure that our offline
3869.28|4.86|data set you know is robust enough where
3871.859|3.901|these different behaviors exist and you
3874.14|3.3|can describe them in language if you
3875.76|3.12|don't have enough diverse behaviors no
3877.44|2.82|matter how good your labeling is you
3878.88|3.0|probably can't elicit all the
3880.26|3.359|interesting Concepts that you want to
3881.88|3.36|learn from
3883.619|3.421|um and maybe most exciting for me here
3885.24|3.839|was that actually some label noise is
3887.04|3.779|okay notoriously in supervised learning
3889.079|3.961|and imitation learning you need very
3890.819|3.661|clean labels that are always 100 True
3893.04|3.9|right you don't want to be learning from
3894.48|4.26|like noisy data where some like you know
3896.94|4.02|large percentage is just not accurate
3898.74|4.859|but in our case um it seems that like
3900.96|4.339|some label noise was okay the vision
3903.599|3.96|language models was not always
3905.299|4.481|predicting factually accurate
3907.559|4.26|descriptions of the scene
3909.78|4.26|um and I think this definitely hurt um
3911.819|4.321|when it got too high the noise but at
3914.04|3.84|smaller level it definitely still seemed
3916.14|4.1|uh to be okay and robust enough to
3917.88|2.36|handle that
3920.46|4.139|so that was a deep dive then on some
3923.099|4.621|individual works that use this big
3924.599|5.041|recipe of language Foundation models
3927.72|3.72|offline data sets in different parts of
3929.64|4.38|the robot system
3931.44|4.44|and this was the kind of pitch at the
3934.02|3.779|beginning and I hope uh you at least see
3935.88|4.14|a little bit of how our team has tried
3937.799|3.78|to take these principles and apply them
3940.02|3.12|to accelerating robot learning in the
3941.579|3.421|real world
3943.14|4.199|um as we see these different types of
3945.0|4.26|ingredients and lessons map onto
3947.339|3.901|different parts of the robot system
3949.26|3.72|altogether for skill learning right that
3951.24|3.3|was rt1 that we talked about for
3952.98|3.24|planning that was stay can and then
3954.54|3.539|adding the close of feedback with vision
3956.22|3.839|language models that was inner monologue
3958.079|3.54|for low-level control we didn't talk
3960.059|3.181|about this today but an exciting work
3961.619|4.081|from our team is actually using language
3963.24|3.96|models to predict code that's executed
3965.7|3.119|on the robot directly perhaps as
3967.2|2.82|low-level controllers
3968.819|3.0|um language models you know they read
3970.02|3.539|textbooks they read they've read raw
3971.819|3.421|stocks they've read uh you know ur5
3973.559|3.661|documentation code and they can write
3975.24|3.059|code for these robots and we can execute
3977.22|2.639|that
3978.299|4.621|um for data augmentation we saw dial
3979.859|4.74|with vision language models uh and also
3982.92|3.36|um I didn't talk about this here but for
3984.599|3.301|object-centric representations for
3986.28|3.96|things like feature activation math for
3987.9|4.08|specific objects we can use those as
3990.24|3.42|task representation
3991.98|3.599|um for mapping a scene and in NL map
3993.66|3.72|they did that uh for object mapping
3995.579|3.121|object-centric navigation
3997.38|2.76|um around the micro kitchen that we
3998.7|3.659|looked at
4000.14|3.899|um and I think hopefully in the next you
4002.359|3.661|know coming weeks and months uh we have
4004.039|4.681|a few more rows and entries to add here
4006.02|5.039|as well um but I think uh this kind of
4008.72|4.68|mindset is a very exciting research
4011.059|3.78|direction of how you can apply these big
4013.4|3.24|high-level Concepts about Foundation
4014.839|3.901|models and offline data sets and you
4016.64|4.26|look at what exists in the robot systems
4018.74|4.079|of today and you find many gaps and
4020.9|4.38|opportunities still available where we
4022.819|4.5|can do everything from exploratory
4025.28|3.839|pilots on how this might look like all
4027.319|3.54|the way to more extensive valuations and
4029.119|4.081|really building out robust systems I
4030.859|5.46|think both of these have value
4033.2|5.399|so I'll I'll uh conclude with just
4036.319|3.601|saying that uh it was very fun exploring
4038.599|3.781|all of these complementary directions
4039.92|4.26|but there are still some major questions
4042.38|3.78|of how we can take these Concepts even
4044.18|4.08|further and how these Trends and ideas
4046.16|4.139|might even evolve moving forward as
4048.26|4.38|Foundation models get better as more
4050.299|4.02|data set becomes available online as
4052.64|3.84|more data becomes homogenized and
4054.319|3.72|tokenized and interoperable and I think
4056.48|4.2|a lot of the concepts from other fields
4058.039|5.461|like uh Linguistics and vision and from
4060.68|4.02|you know all of the uh big scaling kind
4063.5|2.4|of level questions that are being
4064.7|2.76|pioneered
4065.9|3.659|um in language-based Foundation models
4067.46|3.48|hopefully those kind of ideas can
4069.559|3.24|trickle down to robotics maybe even
4070.94|4.139|robotics can provide something back by
4072.799|4.02|providing embodied action causal data
4075.079|3.901|sets that maybe might improve the
4076.819|3.48|quality of reasoning of some of these
4078.98|2.76|large language models that are not
4080.299|3.961|embodied
4081.74|4.379|um with that though I guess I'd like to
4084.26|4.859|um you know thank everyone for your time
4086.119|5.041|and for uh Davidson providing me and uh
4089.119|4.561|open to any questions about the papers
4091.16|4.699|or just at a high level as well thank so
4093.68|2.179|much
4103.04|2.0|um
4112.219|3.5|a lot of problems
4115.819|3.42|yeah great question so the question I
4117.259|3.96|guess is like uh what about tasks that
4119.239|4.201|require more semantic reasoning like uh
4121.219|3.901|you know operating at a certain speed or
4123.44|3.359|with maybe like I don't know numerical
4125.12|2.639|reasoning within the question the pump
4126.799|3.781|itself
4127.759|4.44|um I would say um so for a lot of the
4130.58|5.04|more common sense reasoning like you
4132.199|5.52|know uh throw away three Coke cans uh
4135.62|3.659|you know after another I think um you
4137.719|3.48|know the language model is very good at
4139.279|3.841|that right now so for the second planner
4141.199|4.02|it will predict you know throw away the
4143.12|3.719|Coke can three separate times
4145.219|4.08|um for the low level skill policy
4146.839|5.161|learning though I think um that's more
4149.299|4.5|of a that's more High variance I would
4152.0|3.0|say um and definitely for right now we
4153.799|4.141|don't really
4155.0|5.52|um condition on speed or how you do it
4157.94|4.14|exactly but that's definitely maybe
4160.52|3.42|something that I could do if if you
4162.08|3.54|could be label with like pick up the
4163.94|3.239|code can slowly versus pick up the
4165.62|4.92|cocaine quickly maybe that is something
4167.179|5.66|a vision language model code recognize
4170.54|2.299|okay
4194.44|3.759|great question uh the question was at
4196.94|2.82|what scale
4198.199|3.54|um do we see like combinatorial
4199.76|3.9|generalizations start to occur uh maybe
4201.739|3.721|between like you've seen colors of one
4203.66|3.539|block and then you want to evaluate on a
4205.46|3.3|new color um and I I think that's a
4207.199|3.0|great question and unfortunately my
4208.76|3.419|answer is going to be very vague and it
4210.199|3.721|depends it depends on how you define
4212.179|3.481|your tasks it depends on the scale of
4213.92|2.58|your data set and it depends on like the
4215.66|2.76|concepts that you're trying to
4216.5|3.78|generalize across I think um there's
4218.42|4.98|been uh numerous attempts to kind of
4220.28|5.16|basically uh formalize what it means to
4223.4|4.14|generalize within uh you know learning
4225.44|4.56|and within robotics even within like the
4227.54|3.96|specific settings we consider and I
4230.0|3.54|don't think there are any clear trends
4231.5|3.96|like of where you can say oh yeah this
4233.54|3.54|is the number I need to hit where you
4235.46|3.719|know I can generalize across XYZ
4237.08|3.24|Dimensions um like you could evaluate
4239.179|2.581|all of those but I don't think it will
4240.32|3.72|help you predict new trends at least
4241.76|3.72|right now I think we're probably I know
4244.04|3.48|this is just me talking I would say
4245.48|4.32|where one order of magnitude off before
4247.52|4.679|we can start to make very broadly
4249.8|4.8|generalizing statements about
4252.199|3.901|generalization capabilities I think you
4254.6|3.119|know add one or two more zeros to our
4256.1|3.48|data set size and we can start to talk
4257.719|5.241|about that um in terms of task object
4259.58|3.38|skills yeah
4266.48|2.0|um
4286.64|4.559|done
4288.32|4.98|yeah very astute observation um so the
4291.199|4.261|question the question was that in say
4293.3|4.08|can uh the value functions that predict
4295.46|3.06|these scalars on the right here for the
4297.38|2.819|affordances
4298.52|3.12|um are only storing a certain limited
4300.199|3.141|number of tasks so is that the
4301.64|4.32|bottleneck and I would say yes 100
4303.34|4.359|scaling the number of tasks that your
4305.96|3.84|system is able to do that you can then
4307.699|4.02|give to the planner as its Buffet of
4309.8|3.66|options to choose that is the bottleneck
4311.719|4.261|right no matter how good your planner is
4313.46|4.8|if you can only do like three tasks
4315.98|4.8|there's only certain like combinations
4318.26|3.899|of those three tasks that it can do to
4320.78|3.959|you know map onto a high level
4322.159|4.861|instruction so as you add more tasks as
4324.739|4.021|the low level skill capabilities of your
4327.02|4.38|robot increases uh you're kind of like
4328.76|4.38|adding Precision to like the the um
4331.4|3.36|coverage of the high level instructions
4333.14|3.42|that your robot can try to do
4334.76|4.76|um so that's a that's one of the main
4336.56|2.96|bottlenecks I see today
4349.06|5.38|thank you
4351.26|6.24|great question um so have we tried rt1
4354.44|4.92|with rohf or with RL
4357.5|3.78|um I think
4359.36|3.42|the short answer is I think we have some
4361.28|4.14|stuff in the works that is doing that
4362.78|4.14|but right now for all of our projects
4365.42|4.14|currently we're just using this
4366.92|4.14|implementation learning loss again I
4369.56|2.82|think I I viewed this multitasking
4371.06|3.72|mutation bet that we're making as kind
4372.38|4.56|of an existence proof it works it's not
4374.78|4.439|cheap but it kind of does work and it
4376.94|4.259|does scale and that at least is a good
4379.219|4.201|starting point and our main you know
4381.199|4.201|hope over the next months and years is
4383.42|3.72|can we improve beyond that can we add
4385.4|3.18|back in offline Improvement you know can
4387.14|4.079|we add in our L back to the equation
4388.58|4.8|somehow I'm an RL person at heart so I
4391.219|5.161|really hope so
4393.38|3.0|foreign
4409.88|3.0|foreign
4425.64|4.579|[Music]
4428.42|4.259|yeah a good question I I
4430.219|3.661|um so I I regarding task balance and
4432.679|2.341|whether like text only data is
4433.88|2.46|sufficient for helping like motor
4435.02|4.56|control learning
4436.34|5.58|um I think uh my hope is that when you
4439.58|4.619|know model models when we experience
4441.92|3.54|emergence in both the robotic space and
4444.199|3.781|we've already seen emergence in the
4445.46|3.779|language space at some point maybe these
4447.98|2.88|reasoning Concepts will start to
4449.239|4.141|transfer between the two I would Point
4450.86|4.5|them to one interesting paper which is I
4453.38|4.2|think can Wikipedia help reinforcement
4455.36|5.22|learning um from um Shane and some other
4457.58|4.74|uh folks they pre-train you know a large
4460.58|3.54|policy Network on like you know Auto
4462.32|4.02|aggressive token prediction on Wikipedia
4464.12|5.119|just text only and they use that to
4466.34|5.52|initialize like control for Atari games
4469.239|4.301|and this actually helped so you know
4471.86|2.94|maybe this is philosophical but maybe
4473.54|3.24|there's something about decision making
4474.8|4.8|reasoning that transfers between text
4476.78|4.58|and action data so
4479.6|6.139|right
4481.36|4.379|my other question is foreign
4493.76|2.82|great question
4495.08|3.659|um I I definitely agree uh you know
4496.58|3.78|passing in six images is not going to be
4498.739|3.121|enough when you're executing tasks for
4500.36|3.18|minutes at a time like clean my whole
4501.86|3.66|house and then you can only pass in the
4503.54|4.32|last like you know two seconds like come
4505.52|4.199|on um so I I think that's definitely
4507.86|4.2|going to be a limitation as our tasks
4509.719|3.661|set more complex in the long Horizon
4512.06|4.02|um and I think here it's another open
4513.38|4.74|question too uh is context length we
4516.08|3.9|have high dimensional images even with
4518.12|3.599|token learning for for reducing the
4519.98|3.3|number of patches that we pass through
4521.719|3.421|it's still you know very high
4523.28|4.26|dimensional and we quickly hit the
4525.14|3.9|context length cap can we do how do we
4527.54|4.38|you know improve it Beyond this maybe
4529.04|4.199|it's like retrieval Transformers or some
4531.92|4.319|other kind of mechanism
4533.239|3.0|learning
4538.4|4.259|great question I think um we are hoping
4540.86|3.72|to explore that in the future but with
4542.659|3.54|this like context length limitation we
4544.58|3.84|are already near the context length
4546.199|4.741|capacity with just the six images alone
4548.42|4.62|much less uh you know passing in whole
4550.94|4.5|trajectories of zero shot behavioral
4553.04|5.9|fuse shot Behavior we wish to see
4555.44|3.5|um so 2bd yeah
4559.719|3.541|cool thank you guys