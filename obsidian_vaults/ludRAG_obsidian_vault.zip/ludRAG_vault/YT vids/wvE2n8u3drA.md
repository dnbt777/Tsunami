start_time|end_time|text
4.96|4.08|thanks for inviting me for the talk
6.48|5.36|today uh and i'll be just talking about
9.04|4.479|uh transformers for uh music and audio
11.84|4.88|which is very different than what all of
13.519|5.201|this were uh doing this past course um
16.72|3.92|i'm also the only speaker from stanford
18.72|4.08|so i have to do a good job so you see
20.64|3.76|like very good slides uh because i'm
22.8|3.6|kind of representing the university in
24.4|3.44|some sense
26.4|3.199|so yeah so the flow of the talk for
27.84|3.04|today is basically like i'll be throwing
29.599|2.8|a lot of stuff
30.88|3.92|it's kind of like a buffet style and
32.399|4.16|then you feel free to like or dislike
34.8|3.52|whatever you want
36.559|3.52|and i'll be talking mostly about like
38.32|2.64|three papers of what i've been working
40.079|1.921|on
40.96|2.72|uh
42.0|3.12|i'll start with like introducing like
43.68|2.96|what transformers are from a different
45.12|3.2|perspective uh what audio
46.64|2.56|representations are
48.32|3.52|uh
49.2|4.24|talk about uh uh generating model for
51.84|3.6|audio which is just doing like language
53.44|4.4|modeling on sample level
55.44|5.36|uh then i'll talk about how how can one
57.84|4.48|do like language modeling uh for speech
60.8|3.04|and audio which is different than what
62.32|3.839|people do for text
63.84|3.52|uh what are the current trends in the uh
66.159|2.481|literature
67.36|3.759|finally i'll
68.64|4.32|briefly mention uh similar stuff as to
71.119|3.841|what was happening in computer vision
72.96|3.76|with regard to vision transformers how
74.96|4.159|can we adapt similar ideas for audio
76.72|3.68|transformers and throw in a bit of
79.119|2.801|signal processing to improve the
80.4|3.68|performance
81.92|4.879|having told that the talk is about 35 to
84.08|4.64|40 minutes with about 15 minutes of q a
86.799|3.68|i should also say that all of the
88.72|3.68|opinions are mine and stanford or any
90.479|4.0|other professor is not responsible for
92.4|3.44|any of the mistake which i do
94.479|4.241|um
95.84|4.959|so the transformers kind of uh have kind
98.72|4.16|of revolutionized in a way like everyone
100.799|5.041|was approaching deep learning uh
102.88|5.519|before that it was all about cnns uh and
105.84|4.239|mostly uh all of these prominent models
108.399|3.04|have been coming in waves so there was a
110.079|3.281|time when everyone was just applying
111.439|4.0|cnns
113.36|3.84|then came a time where people started
115.439|4.0|adopting cnns and some sort of like
117.2|3.84|dilated confusions and slowly the
119.439|2.561|recurrent networks were getting out of
121.04|3.759|fashion
122.0|4.399|uh now it seems like transformers and
124.799|3.68|fashion all the time so it seems to be
126.399|4.48|solving almost every single problem
128.479|3.361|which is being thrown at them
130.879|3.681|um
131.84|4.96|so so what's special about it
134.56|4.24|uh one of the fact which struck me uh
136.8|3.28|was their simplicity
138.8|4.72|which is uh
140.08|5.519|if you think about it uh this uh
143.52|5.12|and it has been like hugely popular also
145.599|4.72|so uh it was just released in 2018 and
148.64|3.52|within three years it has like about 30
150.319|3.441|000 citations and it is kind of solving
152.16|2.56|every single problem in every single
153.76|4.8|domain
154.72|5.84|um it has its limitations though also
158.56|4.399|but if you think about it in a way
160.56|5.44|transformers are basically like a way of
162.959|4.56|like just cascading self attention with
166.0|3.28|feature learning and if you keep on
167.519|3.761|doing it over and over again
169.28|3.84|then the model in a way learns which
171.28|4.319|parts of the input are important and
173.12|4.479|keep on transforming them removing the
175.599|4.081|contents which are not important and
177.599|3.92|just to have the limited information
179.68|4.4|which is just responsible for a
181.519|4.161|particular task
184.08|3.439|and it has been very very difficult to
185.68|4.72|keep up with the literature you know
187.519|4.72|like uh uh i i have put it as a joke
190.4|4.32|here but then even twitter's
192.239|4.481|recommendation engine were kind of just
194.72|4.32|getting out of uh like they were getting
196.72|4.64|haywire as to like why is chris manning
199.04|4.72|just searching over transformers uh that
201.36|4.48|and that was way back in 2020
203.76|3.68|um so it has been like difficult for
205.84|3.36|researchers also to keep up with the
207.44|3.4|pace of what's going on
209.2|3.679|uh just before
210.84|3.64|transformers all of the nlp community
212.879|3.761|was just doing gaga about like
214.48|4.72|bi-directional listings with attention
216.64|5.519|so every single paper before 2017 was
219.2|6.72|just like you have encoded lstm layers
222.159|5.601|you keep on adding like multiple layers
225.92|3.92|and then after that you have a attention
227.76|3.92|mechanism which just learns at what's
229.84|4.8|important and then just keeps on
231.68|5.36|decoding sequentially one at a time
234.64|4.4|but this was not a kind of like an ideal
237.04|3.919|way to do it you know because
239.04|3.68|what turns out is when we start throwing
240.959|6.081|in longer sequences
242.72|6.32|uh the connections are no longer uh
247.04|4.16|storing the gradient updates in a way it
249.04|3.839|should be doing so what what the
251.2|3.679|researchers from google said you know
252.879|4.161|like instead of having just a tension
254.879|3.36|layer at the very last
257.04|3.039|um
258.239|3.68|encoding we would just have these
260.079|4.241|attention mechanisms at every single
261.919|3.84|layer which in a way would just learn
264.32|4.08|what's important for a particular
265.759|6.081|problem at that particular layer and we
268.4|6.239|keep on doing it over and over again
271.84|4.72|so so then then the whole idea of like
274.639|4.321|transformers and attention mechanism
276.56|4.24|cascaded one after the other came
278.96|3.12|uh and i'm not going to the details
280.8|4.399|because this is the last class of the
282.08|5.04|course uh but then usual tricks do help
285.199|4.401|across the neural net literature which
287.12|3.44|is like having multi-year retentions
289.6|2.48|um
290.56|3.28|having skip connection and layer norms
292.08|3.2|so all of these string things they are
293.84|3.84|not only like
295.28|4.16|giving gains for transformers themselves
297.68|4.959|but they can be just applied to any
299.44|3.92|single uh other architecture also
302.639|2.801|uh
303.36|3.76|the other thing which is helping this
305.44|3.52|research is basically the compute bar is
307.12|3.919|getting better and better
308.96|3.519|so so uh
311.039|3.201|all of these big companies are just
312.479|4.241|throwing massive amounts of computing
314.24|4.0|resources at uh solving very very simple
316.72|3.44|and trivial tasks
318.24|3.28|um the the top of the hill being like
320.16|4.64|the switch transformer which was
321.52|3.28|discussed in the course also
325.68|4.48|but but one of the thing which i think
328.08|4.08|started all of this trend was elmo which
330.16|3.759|was just learning these contextualized
332.16|4.64|representations for natural language
333.919|4.56|processing and that model right here was
336.8|2.88|perhaps one of the first
338.479|2.72|um
339.68|2.88|uh
341.199|3.041|kind of like
342.56|4.56|like model
344.24|4.48|0.0 or something or 0.1 in terms of like
347.12|3.6|bringing and ushering in the whole
348.72|4.16|revolution
350.72|4.319|you can see that how similar these kind
352.88|3.36|of models look like um bird was
355.039|3.201|basically like
356.24|4.0|inspired heavily from elmo
358.24|3.76|uh in which they just replaced all of
360.24|2.88|these lstm layers with transformer
362.0|5.68|modules
363.12|6.16|um so so a point to note also is like
367.68|3.68|irrespective of like natural language
369.28|4.32|processing or other domain these can be
371.36|3.839|adapted in a variety of domains and for
373.6|4.0|the today's talk i'll be just adapting
375.199|4.641|them to uh audio
377.6|4.0|so i'll basically start with
379.84|3.76|introducing people what audio
381.6|4.08|representations are and just for the
383.6|4.56|sake of completeness
385.68|4.639|talk about spectrograms
388.16|4.8|so spec like you can take any time
390.319|5.041|domain signal and
392.96|3.76|you can decompose that signal into
395.36|4.8|uh
396.72|5.199|a variety of uh basis functions and if
400.16|2.96|you take up a fourier transform you're
401.919|2.241|kind of like
403.12|2.88|uh
404.16|4.08|decomposing the actual time domain
406.0|4.88|signal into its sinusoidal basis
408.24|4.64|components so if you have like a
410.88|4.4|waveform here like this which is a sum
412.88|4.8|of three pure sinusoids
415.28|4.319|then their sum basically is this and you
417.68|4.56|can see that when you take a fourier
419.599|4.961|transform and its magnitude
422.24|5.44|you kind of have their strength of the
424.56|4.24|individual components
427.68|3.28|shown here
428.8|3.92|so you can take up another waveform
430.96|4.56|let's say a square wave
432.72|5.12|and what you have is basically a much
435.52|4.399|richer sinusoidal decomposition because
437.84|3.84|it is kind of a discontinuous signal so
439.919|4.081|you need like many more sinusoids to
441.68|5.2|represent that particular signal uh as
444.0|4.72|close to the actual signal as possible
446.88|3.52|and here also you can see that okay if
448.72|5.28|this was a square wave then it is
450.4|7.68|actually made up of uh
454.0|5.919|a lot of sinusoids where each of the
458.08|4.16|bar here represents the strength of the
459.919|4.801|particular sinusoid
462.24|4.799|from an optimization perspective i mean
464.72|4.879|this right away is uh suboptimal right
467.039|4.641|because you're kind of fixing up
469.599|3.921|uh the number of sinusoids you're using
471.68|3.28|for representing a square wave i would
473.52|3.44|have rather
474.96|4.72|used a basis function which it was a
476.96|4.959|square wave itself than a
479.68|4.16|sinusoidal signal right the second thing
481.919|3.441|is like even if we are taking a sinusoid
483.84|3.6|signal uh
485.36|4.48|we kind of are just
487.44|3.759|putting them in an equidistant space so
489.84|3.44|you're kind of dividing the whole
491.199|4.081|frequency access into like uh
493.28|3.52|equidistant bins and each of the bins is
495.28|4.08|responsible for like a particular
496.8|4.72|sinusoid a lot
499.36|4.239|so so that is like a traditional fourier
501.52|4.32|representation for representing any
503.599|4.32|signal
505.84|2.88|what we do for uh
507.919|3.041|uh
508.72|5.04|what a spectrogram suspect like but in
510.96|4.639|reality uh all of these signals are
513.76|4.88|discontinuous uh all of these signals
515.599|5.201|vary quite a bit right so you can have
518.64|3.759|like a signal while i'm speaking uh
520.8|2.96|which is like a square for a certain
522.399|3.44|period of time and then it gets
523.76|4.88|sinusoidal and then it becomes something
525.839|3.841|else so what we really need is like in a
528.64|3.12|way to
529.68|4.56|kind of like uh take patches of the
531.76|4.16|input signal and take fourier transform
534.24|3.279|of these individual patches
535.92|3.28|uh i'm deliberately using the word
537.519|3.681|patches but you can like in traditional
539.2|4.48|terms you're windowing the signal
541.2|4.0|uh you so right here you can see that
543.68|3.599|you you have a continuous signal you
545.2|4.639|keep on windowing it
547.279|4.721|you apply the fourier transform and what
549.839|4.321|you get is basically like a spectrogram
552.0|3.76|representation of the signal
554.16|4.32|so right here what you're seeing
555.76|4.8|basically is for each of the slices
558.48|3.6|the signal kind of looked like this
560.56|3.839|after taking the fourier transform of
562.08|4.16|the waveform which is there below
564.399|3.44|uh and what you do is for spectrogram
566.24|3.279|representation you keep on stacking
567.839|2.961|these uh fourier transform slides the
569.519|3.76|magnitude of the fourier transform
570.8|4.479|slices and in this way you kind of get
573.279|3.441|like a 2d representation of audio
575.279|2.721|segments
576.72|3.119|and if you are coming from a vision
578.0|2.959|background it is basically all of the
579.839|4.081|things which you are doing in vision
580.959|4.401|would just work well if you just apply
583.92|3.28|them to these 2d spectral
585.36|4.32|representations
587.2|5.44|i'll quickly play how these spectrograms
589.68|4.65|look like for a wide var area of like
592.64|4.739|common sounds
594.33|3.049|[Music]
604.88|6.499|[Music]
615.13|3.19|[Music]
622.0|3.0|okay
635.44|3.68|so you could see like uh for
637.279|4.081|spectrograms you have kind of like a
639.12|4.56|time access on your x-axis and then you
641.36|4.24|have a frequency axis on y-axis
643.68|3.76|and then for whatever is your signal of
645.6|3.76|interest you're basically like putting
647.44|3.44|these slices together and different
649.36|3.2|sound gives you like different spectral
650.88|2.8|representations so it's kind of a vision
652.56|3.68|problem
653.68|4.32|just in this sort of like fourier space
656.24|3.68|um
658.0|5.2|so so there can be like different kinds
659.92|5.359|of representations also so uh one you
663.2|4.0|you could you could just take these uh
665.279|4.56|slices of fourier transform and then do
667.2|5.759|like a linear mapping to them uh so that
669.839|5.12|you are kind of in a way uh making these
672.959|4.401|as close to how humans here so you can
674.959|4.241|have like a log of the frequency on the
677.36|3.36|y axis instead of common frequency and
679.2|3.68|then you get like a constant q like
680.72|3.52|representation the advantage of this
682.88|3.84|being like you can see that for
684.24|4.0|different frequencies the the spacing
686.72|3.2|between the harmonics kind of remains
688.24|3.279|same so if you're like training
689.92|3.84|convolutional filters then that's of a
691.519|4.161|huge advantage because the signal like
693.76|3.36|one component of the invariance is gone
695.68|3.68|and you can just learn these filters
697.12|3.76|which are catching on to these constant
699.36|4.719|templates of
700.88|4.959|fourier slices uh you can have l filter
704.079|2.561|bank coefficients or you can have like
705.839|2.961|uh
706.64|3.84|the raw waveform also
708.8|3.279|for raw waveforms basically there are
710.48|2.64|two things which have we have to keep in
712.079|3.281|mind
713.12|4.24|one is the sampling rate so we kind of
715.36|4.08|like take the continuous signal and then
717.36|2.88|we discretize the continuous signal
719.44|3.199|so
720.24|4.08|one way one parameter is like how fast
722.639|3.681|we are sampling the continuous signal so
724.32|4.56|that's typically on the order of like 16
726.32|5.04|000 or 8 000 times a second if you're on
728.88|4.88|telephonic speech the other thing which
731.36|4.159|we also is like how how many levels we
733.76|3.6|are dividing your vertical axis so in
735.519|4.0|this case you can see that each of the
737.36|3.68|dots is basically one level and
739.519|4.081|typically people use eight bit
741.04|4.0|quantizers for 16-bit quantizers so in a
743.6|3.76|way you can think about that for every
745.04|3.68|one second of audio which we would hear
747.36|4.08|you would have like sixteen thousand
748.72|4.4|samples and then uh and each of the
751.44|3.44|sixteen thousand samples are allowed to
753.12|2.959|take one of the levels between zero to
754.88|4.959|fifty five
756.079|5.521|um and that's like if i can like take
759.839|3.921|the problem of like continuous audio and
761.6|4.239|just have it in terms of like this sort
763.76|3.84|of like discrete space then basically
765.839|3.521|like i'm just going to the territory of
767.6|2.96|like doing language modeling
769.36|3.279|um
770.56|4.8|so so for the first papers i discussed
772.639|4.961|is uh how can we do like uh
775.36|4.4|generative modeling for raw audio uh
777.6|5.44|which is similar to wavenets uh using
779.76|5.84|transformers uh i'll be putting qr codes
783.04|3.44|if you like the stuff what i'm doing and
785.6|2.16|if you
786.48|3.599|think that this is relevant to you
787.76|4.4|please cite or please uh have a look in
790.079|2.961|terms of like the qr codes
792.16|3.2|um
793.04|4.32|so yeah so i'll start with the first uh
795.36|2.88|sub sub topic of the today's talk which
797.36|2.0|is like
798.24|3.52|uh
799.36|4.0|what are uh
801.76|2.96|what are wavelets and
803.36|3.039|how do we do like this generating
804.72|3.76|modeling with raw audio
806.399|3.68|um so in single word you can think about
808.48|4.799|this as doing like language modeling
810.079|4.56|over these 255 states of audio so you
813.279|2.56|can throw in your
814.639|3.841|favorite transform model like
815.839|5.201|transformer excel or
818.48|4.56|gpt or whatever you want to call it
821.04|3.28|uh and just treat the problem as if
823.04|3.28|you're trying to predict one of the
824.32|3.44|levels out of 255 and you have to
826.32|2.56|predict the next level given a certain
827.76|4.16|context
828.88|5.44|uh that's what wavenet was doing so uh
831.92|3.919|the way you are modeling the uh
834.32|3.44|probability distribution of a continuous
835.839|3.521|space is basically you're trying to
837.76|4.72|predict what what's the probability of
839.36|5.36|the next sample given some parts context
842.48|4.64|and wavelet has been like hugely popular
844.72|4.08|because it has over 3000 citations and
847.12|4.32|it has been a core building block for
848.8|4.479|almost like all uh speech and audio
851.44|3.839|related problems like you can think
853.279|5.12|about like speech-to-text text-to-speech
855.279|4.401|synthesis uh instrument conversion uh
858.399|3.68|packet loss concealment over the
859.68|4.159|internet uh speech denoising so wherever
862.079|4.241|there is some sort of element of
863.839|6.56|modifying audio people have been using
866.32|6.079|wavenet um as a code building block
870.399|3.841|and raw waveform synthesis has been
872.399|2.961|difficult because just the magnitude of
874.24|3.44|the
875.36|4.159|problem if i'm just trying to synthesize
877.68|2.719|10 seconds of audio it would just amount
879.519|2.721|to like
880.399|4.24|me having a probability distribution
882.24|3.52|over 160 000 samples
884.639|2.161|um
885.76|2.72|and
886.8|3.68|that itself is tough because our ears
888.48|3.359|are very very sensitive to subtle
890.48|4.64|changes if i'm
891.839|5.761|off by one pixel in an image the image
895.12|5.12|like my eyes would not be as
897.6|4.88|as susceptible to noticing that effect
900.24|4.8|versus like if i'm off by say a few
902.48|6.0|pixels few samples in an audio it will
905.04|4.96|just catch our ears pretty quickly uh
908.48|3.919|people have been trying raw audio
910.0|4.72|synthesis a lot in the past
912.399|5.041|and before all of the wavenet and
914.72|5.6|transformer based approaches
917.44|5.36|kind of like wave rnns and sample rnns
920.32|5.199|were kind of like a
922.8|4.56|like state-of-the-art models
925.519|5.76|on the right i've seen i've shown a
927.36|5.599|sample rn model which kind of like uh
931.279|3.441|models the probability distribution of
932.959|3.44|what's going to come next given the past
934.72|3.919|at multiple levels
936.399|4.8|and and this was a work done by yoshia
938.639|4.241|benji at mila but you can
941.199|3.681|closely see like if you just see this
942.88|4.24|architecture versus a transformer
944.88|3.759|architecture in a way these are like
947.12|3.2|starting to get very very similar
948.639|3.361|because what you're trying to do is that
950.32|4.16|for for the probability distribution
952.0|4.72|here you're trying to see a lot of like
954.48|4.24|local substructures and then you keep on
956.72|3.6|doing it over and over again and you can
958.72|4.0|draw parallels like okay attention
960.32|3.6|mechanism should also kind of be doing
962.72|2.32|the same thing
963.92|3.52|so
965.04|4.159|this was the this was the uh kind of
967.44|4.48|like the literature in the past
969.199|4.56|what we tried to do was uh we just had
971.92|3.2|like the wavenet model and we tried to
973.759|3.361|see whether the transformers can beat
975.12|4.159|them and our intuition was like it
977.12|4.56|should be able to beat them because uh
979.279|4.401|they are successful all over the uh
981.68|4.64|other other domains like in language
983.68|4.48|modeling so it should it should do that
986.32|4.0|for raw waveforms also
988.16|4.64|uh we also try to see whether we can
990.32|3.92|circumvent the order n square constraint
992.8|3.68|uh by
994.24|4.08|conditioning or the context itself
996.48|3.359|uh and uh
998.32|3.12|like we did not go through specific
999.839|3.201|applications and we just said okay just
1001.44|2.639|in terms like modeling behavior how well
1003.04|2.159|they do
1004.079|2.961|um
1005.199|3.921|so so the data set for this was just
1007.04|4.4|like real world channel recordings so so
1009.12|3.12|so actual uh
1011.44|2.72|uh
1012.24|3.839|sound should not matter because like the
1014.16|3.52|the model is agnostic to what it is
1016.079|3.44|being thrown in
1017.68|3.76|and the setup was exactly the same like
1019.519|4.081|you are giving a certain context and i
1021.44|3.999|have to predict like the next sample you
1023.6|4.719|do the same thing with uh wavenets you
1025.439|5.12|do the exact same thing with uh
1028.319|4.401|transform based like gpt kind of like a
1030.559|3.36|model and see how well they do
1032.72|3.199|uh
1033.919|4.0|i'll briefly chat about like what
1035.919|3.92|wavelet models are
1037.919|4.561|so wavelet was kind of like a
1039.839|4.561|convolutional based model which was
1042.48|5.12|getting rid of like all of the vanishing
1044.4|5.2|gradient problem by just treating a
1047.6|3.439|sequential problem as being learned by a
1049.6|3.52|convolutional model
1051.039|4.561|so what what they did was basically like
1053.12|5.04|have this sort of like dilation layers
1055.6|4.88|or like a conclusion with dilations
1058.16|4.879|which is basically like i kind of skip
1060.48|4.8|in every subsequent layer by one sample
1063.039|4.481|so you can see like if i have a
1065.28|4.24|dilation factor of two with a kernel
1067.52|3.92|size of two i would get this kind of a
1069.52|3.519|topology where my convolutional filters
1071.44|3.84|in the very first layer are just like
1073.039|4.401|combining the first two samples then i
1075.28|4.32|skip by one in the next layer
1077.44|4.0|and then i skip by three which is like i
1079.6|3.12|look at like the fourth one in the next
1081.44|3.92|layer and so on
1082.72|5.28|uh the loss is still the same so i have
1085.36|4.8|this network i learn a latent space and
1088.0|3.76|then i have like a cross and categorical
1090.16|2.72|cross entropy loss which is basically i
1091.76|3.919|have to predict
1092.88|3.679|the next sample given the previous one
1095.679|2.88|um
1096.559|4.801|and i i just do the exact same thing
1098.559|4.641|with transformers also so so but then i
1101.36|4.0|i have to make sure that i do it in a
1103.2|4.16|causal manner so i have something which
1105.36|3.84|is very similar to gpt in which i have
1107.36|4.24|cause and masks in my attention
1109.2|5.28|mechanism and i keep doing it over and
1111.6|4.64|over again so so you have like uh
1114.48|4.4|self-attention after that your feet
1116.24|4.72|forward layers you just have a stack of
1118.88|4.08|these uh transfer blocks and see how
1120.96|4.32|they do
1122.96|3.04|so so i said intuitively it should work
1125.28|1.92|so
1126.0|3.44|uh
1127.2|3.44|like it should be doing better than like
1129.44|3.68|our
1130.64|4.399|base wavenet models right because if you
1133.12|3.84|if you look at the topology
1135.039|4.561|we are kind of defining a topology on
1136.96|4.8|our own right so uh what what if like
1139.6|5.36|the the current prediction i'd say layer
1141.76|4.32|one world to depend on like very like uh
1144.96|2.719|way back
1146.08|3.12|uh sample say
1147.679|3.201|instead of the second sample the tens
1149.2|3.76|happens so we are kind of ignoring all
1150.88|3.76|of that topology uh which would have
1152.96|4.88|been important for prediction of this
1154.64|5.279|particular task whereas uh transformers
1157.84|4.0|with the self-attention mechanism can
1159.919|4.0|just learn like okay which part of the
1161.84|4.88|samples are important and which are not
1163.919|6.161|and you can keep on doing iteratively uh
1166.72|4.959|so it made sense to us that okay
1170.08|4.719|transform layer should be doing way
1171.679|5.041|better than wavelet models
1174.799|4.801|the second thing which we came across
1176.72|4.88|was like okay we cannot have a lot of
1179.6|4.88|context for example the attention
1181.6|5.52|mechanism needs to store all of those
1184.48|4.559|uh of order n squares in this case if
1187.12|4.4|i'm like storing data at 100
1189.039|3.52|milliseconds then i have like about 1600
1191.52|4.48|samples
1192.559|5.281|and i need to store 1600 by 1600 at
1196.0|2.799|multiple layers and it just becomes like
1197.84|2.32|a huge
1198.799|2.88|uh
1200.16|3.28|problem with the data
1201.679|4.88|problem with the memory constraint so so
1203.44|6.88|what we said was okay uh what if we just
1206.559|6.0|use the context itself as a latent code
1210.32|4.56|so so in order to like
1212.559|3.921|have like much better uh
1214.88|4.08|uh representation at every layer we
1216.48|5.04|cannot have like huge big attention
1218.96|5.36|matrices so what we said was we would
1221.52|5.68|just do it sample wise conditioning and
1224.32|4.56|through a cnn layers just to understand
1227.2|3.68|what the latent code would be so you
1228.88|5.36|still have like an attention mechanism
1230.88|5.36|or just a past context but then i'm also
1234.24|4.48|conditioning at every sample
1236.24|4.96|okay what what the next sample should be
1238.72|4.16|given on this point context embedding
1241.2|3.2|and if you think about it in a way it is
1242.88|4.08|like okay if there are like five or six
1244.4|4.159|notes being played in a piano then i'm
1246.96|3.28|kind of certain which notes will be
1248.559|4.721|played to a certain extent if i just
1250.24|5.679|throw in a cnn layer uh so i'll use that
1253.28|3.36|information along with what my transfers
1255.919|2.561|are
1256.64|4.08|are learning and then i would condition
1258.48|4.079|it and i would just use that to predict
1260.72|4.16|an example
1262.559|4.48|so so for the evaluation criteria we did
1264.88|3.12|not look for negative log likelihood
1267.039|3.201|scores
1268.0|4.72|uh we just looked at how well our
1270.24|4.16|prediction prediction task was
1272.72|4.16|so we took up like
1274.4|4.48|stack wavenet which was implemented by
1276.88|5.279|deepmind and saw that okay what was the
1278.88|6.24|performance uh using their benchmarks
1282.159|5.361|and even like bigger uh stacked wavenets
1285.12|4.4|uh we then took started to increase the
1287.52|4.88|complexity of transformers and started
1289.52|5.44|to see whatever we we had proposed in
1292.4|4.96|terms like conditioning on uh
1294.96|4.48|on the vanilla transformer architectures
1297.36|4.0|to see how they do
1299.44|3.2|we did not look for like an application
1301.36|4.24|specific
1302.64|4.88|uh problem which is basically like uh we
1305.6|4.0|don't look at like how well perceptual
1307.52|4.24|tasks are for like say text to speech
1309.6|4.0|synthesis or speech denoising we just
1311.76|4.32|look at okay if we are trying to model
1313.6|4.88|this using a cross entropy laws then
1316.08|3.36|with the same model with the same a loss
1318.48|2.88|function
1319.44|3.28|how will they do on like similar kind of
1321.36|4.08|parameters
1322.72|4.8|uh so so this was the first kind of like
1325.44|6.359|sub block of like how can we use our
1327.52|4.279|transformers for generative modeling
1332.0|5.12|for the second problem uh i'll i'll do a
1334.4|5.04|quick head away on uh
1337.12|4.16|how can we use like transformers for
1339.44|3.68|doing language modeling which which is
1341.28|2.96|kind of becoming a really fancy term
1343.12|3.679|right now
1344.24|5.52|um and this work was done by julia smith
1346.799|5.12|uh way back in 2020 and
1349.76|4.08|uh the goal of this was can we kind of
1351.919|5.041|in a way do language modeling with
1353.84|5.92|continuous audio uh sequences
1356.96|4.4|uh and i'll briefly mention about that
1359.76|3.76|in this part of some
1361.36|3.439|in this sub-block of the talk
1363.52|3.6|uh
1364.799|4.161|so so and this is in regard for like
1367.12|3.52|solving acoustic scene understanding
1368.96|2.56|which is basically like
1370.64|3.68|uh
1371.52|5.44|if i'm given a chunk of audio then i
1374.32|4.479|want to understand what's in there
1376.96|2.64|and if we could do that
1378.799|1.76|uh
1379.6|4.88|well
1380.559|6.561|then in a way we can do a lot of fancy
1384.48|4.48|nice applications so for example like if
1387.12|4.32|you think about like self-driving cars
1388.96|4.4|so vmware has started to incorporate uh
1391.44|3.68|microphones into the self-driving cars
1393.36|4.4|uh why because say if there is an
1395.12|5.039|ambulance coming or if there is a
1397.76|3.68|fire truck coming then that sound would
1400.159|4.241|be picked up
1401.44|4.88|way way before even than the lidars or
1404.4|4.72|even their sensors so they want to
1406.32|4.4|understand that and take actions based
1409.12|3.6|upon that
1410.72|4.16|apple during covet did a hand washing
1412.72|3.92|detection on their apple watch because
1414.88|3.84|if you could detect when someone is
1416.64|3.12|washing their hands then you can in a
1418.72|2.559|way like
1419.76|3.84|tell people that oh you need to wash
1421.279|4.241|hands for 20 seconds and then
1423.6|3.199|that that can be built upon as a cool
1425.52|3.2|application
1426.799|4.0|it can be used for uh music
1428.72|4.319|recommendations so spotify youtube music
1430.799|4.0|kind of gives like very very good
1433.039|3.921|songs which you are listening to which
1434.799|3.841|are similar in content
1436.96|3.92|that you would perhaps like
1438.64|4.2|um it can also give like really cool
1440.88|4.88|applications like say people have tried
1442.84|5.56|like detecting depression from audio
1445.76|4.56|or i could detect whether i'm coughing
1448.4|3.759|or not or i'm sneezing or not and these
1450.32|4.4|can be like good
1452.159|4.961|medical device medical applications
1454.72|5.76|which can be used along with the current
1457.12|5.679|diagnosis what doctor provides
1460.48|5.199|so so the so the question was basically
1462.799|4.801|for us was like how can we do like a
1465.679|4.801|language modeling in a continuous audio
1467.6|4.8|domain uh and secondly like how can we
1470.48|3.439|train models or how should we approach
1472.4|2.48|uh doing this
1473.919|3.281|um
1474.88|4.72|so so this kind of like recipe has
1477.2|4.24|become like very very popular these days
1479.6|4.319|in terms of like how would you approach
1481.44|4.96|this problem it started with like
1483.919|5.201|open ai and to a certain extent deep
1486.4|4.399|mind proposing that in terms like we qva
1489.12|3.919|models
1490.799|5.681|but it turns out like transformers love
1493.039|6.081|operating in discrete spaces as of now
1496.48|4.72|and what they kind of do is
1499.12|3.84|as long as your representations are
1501.2|4.0|discreet they are very very good at
1502.96|3.44|modeling what's going to come next
1505.2|3.28|um
1506.4|3.44|so so what people have been proposing as
1508.48|2.4|a workaround is
1509.84|2.48|uh
1510.88|3.84|you could take up like
1512.32|4.16|your your uh
1514.72|4.079|favorite embedding in some manner you
1516.48|4.48|can take a bqe embeddings or you could
1518.799|4.161|take a wave to vector uh
1520.96|3.28|in terms of video you can just do
1522.96|3.199|uh
1524.24|3.52|classic vgg or
1526.159|4.721|resonant embeddings
1527.76|4.64|you can apply k-means clustering to it
1530.88|3.279|and k-means clustering would give you
1532.4|3.2|like discrete codes
1534.159|2.961|you do language modeling with those
1535.6|3.6|discrete codes
1537.12|4.32|and you predict the next code
1539.2|4.079|and in a way if you're doing this then
1541.44|3.599|you're kind of doing language modeling
1543.279|3.361|or audio
1545.039|2.64|and if you need to get back to the audio
1546.64|2.639|then
1547.679|4.0|you already saw with wavenet that you
1549.279|5.041|can condition the wavenet model to give
1551.679|4.561|continuous output so you can use those
1554.32|4.67|codes to get back to the audio similar
1556.24|3.919|to what jukebox and open eye did
1558.99|3.809|[Music]
1560.159|4.801|so so i'll quickly uh mention about like
1562.799|3.041|what vector quantization is
1564.96|2.16|uh
1565.84|4.0|it's it's one of the most like
1567.12|4.96|underutilized algorithms to be honest
1569.84|5.04|and what it does is basically gives
1572.08|4.32|in a way discrete codes to continuous
1574.88|3.52|embedding spaces
1576.4|3.04|so how do how does it do it so you
1578.4|2.24|basically
1579.44|3.359|have
1580.64|4.159|a
1582.799|3.681|embedding space let's say in 2d right
1584.799|3.041|here you define what what are the number
1586.48|4.24|of clusters you want to
1587.84|5.12|put each of them in you run k memes and
1590.72|4.88|you would certainly get these uh
1592.96|3.76|patches of like where all of these
1595.6|4.16|embeddings are what would be the
1596.72|4.8|representative embedding of a continuous
1599.76|3.36|embedding you can take all of those
1601.52|3.44|patches and you can see you can just
1603.12|2.559|number them or you can just like list
1604.96|2.48|them
1605.679|4.48|so in this case you can perhaps have
1607.44|5.52|like 25 numbers or 20 numbers which are
1610.159|5.041|like in a way mapping from a continuous
1612.96|3.92|embedding to a discrete token
1615.2|4.4|uh
1616.88|5.52|this is another example right here so uh
1619.6|4.16|in our case what we did was uh we took a
1622.4|5.6|batches of spectrogram which are
1623.76|6.88|basically like a very small uh
1628.0|5.2|patches across time and then shared all
1630.64|4.639|across the frequency axis
1633.2|3.92|you take those patches you learn
1635.279|4.4|embedding representation in our case it
1637.12|4.08|was just like three layer auto encoder
1639.679|4.081|fully connected encoders with three
1641.2|3.839|layers of decoders and have a bottleneck
1643.76|3.279|layer in between
1645.039|4.161|so so that bottleneck layer basically is
1647.039|4.481|kind of similar to this kind of diagram
1649.2|4.24|in like say 64 dimensional space or 128
1651.52|3.92|dimensional space
1653.44|4.4|you take up those bottleneck codes and
1655.44|6.8|then you run k-means clustering on it
1657.84|6.559|suddenly in a way you can find uh
1662.24|4.0|discrete codes for
1664.399|4.561|continuous embedding spaces or even
1666.24|4.64|container signals uh and since we know
1668.96|5.04|that transformers kind of love operating
1670.88|5.519|discrete spaces you can just apply
1674.0|4.24|language modeling now and then you can
1676.399|3.841|see what you can do
1678.24|3.439|so in our case we just had like very
1680.24|3.919|simple uh
1681.679|5.36|three layer fully connected auto encoder
1684.159|4.481|small patches uh the number of codes is
1687.039|2.88|important because if you have like too
1688.64|3.44|many codes
1689.919|4.24|then you're kind of just throwing in all
1692.08|4.8|kinds of noisy things now i'll give an
1694.159|4.24|example of like
1696.88|3.36|why the number of codes are important
1698.399|4.081|through some example and you have like
1700.24|4.64|two little codes
1702.48|3.84|what you're in a way doing is you're
1704.88|3.12|removing all of the information which
1706.32|4.13|was relevant and you're just kind of
1708.0|4.0|like averaging them all out um
1710.45|3.79|[Music]
1712.0|4.08|i i'll start with like so so this idea
1714.24|4.72|first was uh
1716.08|4.16|uh proposed by jukebox which which did
1718.96|3.199|it for music
1720.24|3.84|so so you do the exact same thing what i
1722.159|4.64|talked about in a slightly different
1724.08|4.079|manner uh in a way that okay you cannot
1726.799|4.0|learn uh
1728.159|4.561|codes for like longer sequences so you
1730.799|4.48|know in a way learn sequences which are
1732.72|4.079|just moving slowly and which are uh
1735.279|4.481|looking at only a certain amount of
1736.799|5.76|audio so kind of encode this in these
1739.76|3.519|discrete levels which are basically like
1742.559|2.881|uh
1743.279|4.321|all of these basically are codes so at
1745.44|5.04|every point i define like okay this
1747.6|4.24|audio had perhaps like code number 55
1750.48|3.52|and in the next level perhaps it had
1751.84|4.079|code number two and the very top perhaps
1754.0|3.919|you tried code number two thousand
1755.919|3.281|um so in a way i'm like discretizing the
1757.919|3.921|whole codes
1759.2|4.88|uh now what i do is i take up my
1761.84|4.719|favorite transform model perhaps like a
1764.08|5.12|causal or autoregressive one and i say
1766.559|4.081|that okay given these codes
1769.2|3.839|try to predict what codes would come
1770.64|3.44|next and for sure transformers can do
1773.039|2.801|that
1774.08|2.64|so i would generate the course in the
1775.84|2.24|future
1776.72|2.8|once i have generated the codes in the
1778.08|3.28|future
1779.52|3.519|i can say that okay this problem now is
1781.36|3.679|kind of like a text-to-speech problem
1783.039|4.481|right because i have like these discrete
1785.039|3.681|words text-to-speech in a way is uh
1787.52|2.96|going from discrete letters to
1788.72|3.92|continuous audio
1790.48|4.079|so i would throw in like the fanciest
1792.64|3.2|which was wavenet and i would just get
1794.559|3.441|back the code and i would get the
1795.84|4.24|generated audio
1798.0|4.88|so this was
1800.08|4.64|in a way what i described uh that they
1802.88|4.0|take up a continuous audio
1804.72|5.199|they have these compressed codes which
1806.88|5.279|they encode using a cnn in this case
1809.919|4.0|um the the method doesn't matter you can
1812.159|3.921|throw in like the fanciest of like
1813.919|3.12|embedding or latent representation on
1816.08|2.88|those
1817.039|3.52|continuous code you generate the
1818.96|3.439|patterns which are like what's going to
1820.559|3.6|happen next in the future and then you
1822.399|4.561|decode back using a
1824.159|3.601|fancy wavenet or state-of-the-art model
1826.96|2.8|um
1827.76|3.68|so so this was what they were doing uh
1829.76|4.639|for music synthesis
1831.44|4.4|uh what we said was you know like uh
1834.399|4.481|yeah this is good this can generate a
1835.84|6.0|good amount of music but what can can
1838.88|5.279|can these worlds be used for
1841.84|4.319|generating uh
1844.159|3.681|like good representation of the current
1846.159|4.561|audio uh
1847.84|4.719|and the goal there was like can language
1850.72|3.92|models learn representation which can
1852.559|4.561|just encapsulate whatever
1854.64|3.68|uh we are kind of like giving as an
1857.12|3.679|input signal
1858.32|4.959|um so in this case what we tried after
1860.799|4.48|that was kind of like uh
1863.279|4.961|you you kind of do exactly kind of
1865.279|5.52|similar ideas but uh instead of doing
1868.24|5.439|like on wikivae end-to-end learned
1870.799|4.641|encodings we just apply vanilla k-means
1873.679|3.12|clustering similar to what i described
1875.44|3.2|earlier
1876.799|4.401|we do and spectrogram patches so you
1878.64|4.08|take up these spectrograms of audio and
1881.2|2.8|you just divide them into like very
1882.72|2.72|small chunks
1884.0|3.44|learn uh
1885.44|2.959|auto encoder encodings for each of those
1887.44|3.44|chunks
1888.399|4.961|run crea means clustering in this case
1890.88|4.88|like let's say i am learning 16 codes
1893.36|4.159|uh represent the continuous audience in
1895.76|4.56|terms of the 16 codes
1897.519|5.841|um have a transformer which can perhaps
1900.32|4.64|predict the next code and if i keep on
1903.36|3.36|getting better and better at predicting
1904.96|3.36|what's going to happen next
1906.72|3.439|then in this linear layer i should be
1908.32|4.32|encapsulating
1910.159|4.0|what's important or what's
1912.64|3.759|a good summary of what has happened in
1914.159|4.24|the past
1916.399|5.12|so so that was kind of like our
1918.399|4.801|intuition behind trying this
1921.519|4.081|and as i explained like the number of
1923.2|3.68|quotes play a very important role uh you
1925.6|3.199|can see here
1926.88|3.84|these are just two piano notes switching
1928.799|4.801|one after the other if i just have like
1930.72|4.959|say 16 number of quotes it just
1933.6|4.16|happens to have just a single line of
1935.679|4.641|encoding a single code assigned to all
1937.76|4.399|of this whereas if i'm assigning like
1940.32|3.68|more codes then it becomes kind of like
1942.159|4.081|a fine-grained prediction where i'm
1944.0|4.88|actually able to get what the individual
1946.24|2.64|nodes are
1949.279|4.481|recently facebook also said you know
1951.2|5.44|like okay they just had a different name
1953.76|5.12|to the whole uh thing which is uh
1956.64|4.159|we would we can just call this as text
1958.88|3.519|less and it'll be also in the sense that
1960.799|3.841|okay you can do nlp
1962.399|4.081|without having access to text
1964.64|3.68|but the idea is very very similar you
1966.48|3.439|have an encoder which is exactly similar
1968.32|4.239|to say what openai was using you have a
1969.919|4.64|bqba wave to vect or whatever you want
1972.559|4.48|to do you can apply k-means clustering
1974.559|4.24|to it they apply language models to it
1977.039|3.601|and instead of a decoder being variant
1978.799|3.76|they just have a decoder which is like a
1980.64|4.32|different version of text-to-speech
1982.559|4.0|which is like taco drawn in this case so
1984.96|3.439|as you can see like these are all like
1986.559|5.761|same wine and very different bottles but
1988.399|6.321|the core idea is almost exactly the same
1992.32|4.4|so so this was like a it created a huge
1994.72|4.959|uh a prayer of like oh this is going to
1996.72|4.4|change in lpn but this is very similar
1999.679|3.671|to what
2001.12|3.36|people have been doing in the past
2003.35|3.53|[Music]
2004.48|3.84|so so i've already explained what uh
2006.88|2.24|what this was
2008.32|3.92|uh
2009.12|4.799|so so in our case we just try to predict
2012.24|3.679|what's going to happen next given the
2013.919|4.88|previous context and use that
2015.919|3.841|representation similar to every single
2018.799|2.641|uh
2019.76|4.0|like one-shot learning or zero-shot
2021.44|3.119|learning based uh method
2023.76|2.56|uh
2024.559|3.84|i also explain like why the number of
2026.32|3.68|codes are important like if you have too
2028.399|4.241|small then you're just throwing a lot of
2030.0|3.679|information if you have too large then
2032.64|2.56|you don't
2033.679|4.161|put in like
2035.2|4.0|it is not no longer robust to noise
2037.84|3.92|um
2039.2|4.719|so so this was our setup and uh before i
2041.76|3.68|jump in i should add one of the tweets
2043.919|2.64|which i uh
2045.44|2.719|uh
2046.559|2.881|saw from one of the most prominent
2048.159|3.44|researchers i deep mind which is
2049.44|3.84|basically like a lot of times it is very
2051.599|4.721|very easy to bump up numbers you know
2053.28|5.52|like i can i can have these details just
2056.32|4.559|not present in my paper which which
2058.8|4.24|actually helped a lot in terms of like
2060.879|4.8|improving the performance and kind of
2063.04|4.639|sometimes don't take into account
2065.679|4.081|what the actual model is
2067.679|3.92|uh incorporating or what model is
2069.76|3.68|contributing versus
2071.599|4.08|what the actual these tricks for
2073.44|4.399|training are incorporating so for most
2075.679|5.2|of these methods what we are trying to
2077.839|5.441|see is we try to keep almost exactly the
2080.879|4.48|same approach no data augmentation no
2083.28|3.92|fancy label smoothing or
2085.359|4.48|moving average of weights or decay or
2087.2|8.0|whatever you just have similar based
2089.839|7.601|recipes uh to see how well we are doing
2095.2|4.639|so for this case we the the goal was to
2097.44|3.84|say that how well our models do with
2099.839|3.361|respect to this purely supervised
2101.28|3.76|approach and how well it does with
2103.2|2.879|respect to a similar unsupervised
2105.04|3.52|approach
2106.079|3.841|uh so in the first case the model and
2108.56|3.36|all of the weights are accessed to all
2109.92|4.4|of the labels which which is just
2111.92|3.679|uh shown as vgg supervised which is
2114.32|3.68|basically you take up a audio
2115.599|3.841|understanding data set and you you see
2118.0|2.48|how well you are doing an accuracy
2119.44|1.84|metrics
2120.48|2.56|um
2121.28|3.68|so that was the first one and the second
2123.04|3.44|one we applied simclair which was
2124.96|3.6|proposed by jeff intent in which you can
2126.48|5.04|take up these multiple augmentations of
2128.56|4.559|the same input you can have like patches
2131.52|4.319|removed you can blur the signal you can
2133.119|4.321|flip the signal uh you learn embedding
2135.839|3.52|order the last layer without access to
2137.44|3.28|the labels and then just have a linear
2139.359|2.561|head to predict
2140.72|2.96|what's happening
2141.92|2.8|by using that we got a 55 percent
2143.68|2.56|accuracy
2144.72|2.879|uh you do the exact same thing with
2146.24|3.599|transformers you don't have access to
2147.599|4.321|labels you just run them while just
2149.839|4.481|predict the next code uh you take the
2151.92|4.24|linear layer apply the same linear head
2154.32|5.039|and try to predict what's happening
2156.16|4.88|inside and with that we got 60 accuracy
2159.359|4.0|so even though the results are not good
2161.04|3.84|but the fact is uh the neural networks
2163.359|3.521|actually
2164.88|3.12|are very very good at
2166.88|2.56|uh
2168.0|3.359|like getting better and better with
2169.44|4.0|throwing of huge amounts of data right
2171.359|3.921|so there is still 10 back gap between
2173.44|3.04|like purely supervised and purely
2175.28|3.6|unsupervised
2176.48|4.96|um but then that that's going to improve
2178.88|3.68|with throwing a lot of data to these
2181.44|2.8|models because
2182.56|2.64|it doesn't have access to any label last
2184.24|3.52|person
2185.2|4.48|so this is a famous paper by dan ellis
2187.76|4.319|and nelson morgan at berkeley in which
2189.68|3.12|they actually showed way back in 1999 as
2192.079|1.601|to
2192.8|2.08|why
2193.68|3.04|uh
2194.88|4.8|like size matters for deep neural
2196.72|4.879|networks and also the number of uh data
2199.68|3.52|points which is present so as they kept
2201.599|3.681|on increasing the
2203.2|3.52|size of the data set and the parameters
2205.28|3.52|they kept on getting lower and lower
2206.72|3.76|world error rates and this has been true
2208.8|3.12|across
2210.48|3.68|any of the data set and that's why the
2211.92|3.679|whole excitement is about unsupervised
2214.16|4.08|learning
2215.599|4.081|uh so so this was in a way flavor of
2218.24|4.16|like how can we do like language
2219.68|4.88|modeling and unsupervised learning on uh
2222.4|4.32|audio for continuous segments
2224.56|4.72|uh for the third subplot i'll just
2226.72|4.32|quickly mention uh
2229.28|5.28|ideas which are very similar to what you
2231.04|5.84|would have seen in vision transformers
2234.56|4.16|but with the caveat that how can we
2236.88|3.199|use some sort of like signal processing
2238.72|3.04|to improve these performance mute
2240.079|3.441|further
2241.76|3.359|so so the basic approach still remains
2243.52|4.48|the same exactly as what you would have
2245.119|4.0|seen in vision transformers
2248.0|1.839|you have
2249.119|2.0|a
2249.839|3.121|signal of interest which you want to
2251.119|3.681|classify
2252.96|4.32|here they are raw waveforms instead of
2254.8|3.279|images the goal is to predict what's
2257.28|2.48|there
2258.079|2.961|inside of it right
2259.76|3.599|uh
2261.04|4.64|and also we don't have any conclusions
2263.359|4.081|we don't have any other tricks which we
2265.68|4.0|were using before all we have to do is
2267.44|4.159|they can transformers themselves uh
2269.68|3.04|solve this particular problem
2271.599|3.601|um
2272.72|4.639|so so for the data set uh and and the
2275.2|4.159|whole setup was still the same uh no
2277.359|2.961|data augmentation and no
2279.359|3.521|other
2280.32|4.64|forms of these tricks
2282.88|4.56|you are given like 40 000 snippets for
2284.96|5.36|training and 10 000 for validation
2287.44|5.28|uh our job is to predict as as good as
2290.32|5.039|possible as to what's there in the audio
2292.72|5.04|uh this problem is very similar to the
2295.359|4.801|the sound which you heard and the video
2297.76|3.92|which you saw that given this patch you
2300.16|3.199|have to predict given a spectrogram
2301.68|2.96|patch you have to predict what's there
2303.359|2.72|inside of it
2304.64|4.32|uh
2306.079|6.321|uh we we kind of do uh
2308.96|5.04|uh one step further than what what
2312.4|3.76|what's just like a simple transformer
2314.0|5.28|model in a sense that we tried to see
2316.16|5.919|whether some sort of like hierarchy over
2319.28|4.48|uh uh transform mm radix would help us
2322.079|3.76|in any manner
2323.76|4.64|so for that we use like uh wavelet
2325.839|4.321|decomposition on the intermediate
2328.4|3.439|transformer embeddings
2330.16|4.8|um so what is like a wavelet
2331.839|3.121|decomposition uh
2335.2|4.56|in very naive terms it can be like a way
2338.16|2.959|of
2339.76|4.319|decomposing
2341.119|5.281|the intermediate embeddings into
2344.079|4.241|another intermediate embedding in a
2346.4|3.92|sense that we are kind of putting these
2348.32|3.92|highways off like some embeddings are
2350.32|4.08|moving very slowly and some membranes
2352.24|4.64|are moving very fast and some remainings
2354.4|4.48|are retained exactly at the rate of what
2356.88|4.08|the original signal was
2358.88|3.28|uh and why this is important because you
2360.96|2.96|can think about that at every
2362.16|3.6|intermediate state
2363.92|4.56|you are in a way learning some sort of
2365.76|5.44|hierarchy in the model so
2368.48|4.32|uh if i if i if i look at what we do
2371.2|2.48|with the
2372.8|2.72|uh
2373.68|4.56|like wavelet decomposition before and
2375.52|3.68|after let's say like you had time across
2378.24|2.8|this
2379.2|5.6|and you had the embedding size across
2381.04|5.6|this and this this whole patch was your
2384.8|3.76|output of say the nth layer of the
2386.64|5.68|transformer
2388.56|5.68|what i say now is okay i would just
2392.32|3.84|have a mapping from this
2394.24|3.68|to the mapping of my interest using
2396.16|4.4|wavelet decomposition
2397.92|4.72|in which for half of the samples i just
2400.56|5.279|retain the exact same embedding as what
2402.64|5.36|what was learned by the transform model
2405.839|4.24|in the next half i would start combining
2408.0|4.319|two at a time so in a way i'm learning
2410.079|4.641|this sort of like a t tree structure
2412.319|6.481|within a single layer of the transformer
2414.72|5.92|embedding uh and for now the the
2418.8|4.64|the wavelet or the bc's function which i
2420.64|4.32|use is simple averaging so let's say i
2423.44|2.56|from all of the embedding layers in
2424.96|3.119|between
2426.0|2.96|i just need to have like one
2428.079|2.081|one
2428.96|2.72|uh
2430.16|2.88|embedding which which is not moving at
2431.68|3.12|all which is just representative
2433.04|3.92|whatever is there
2434.8|3.44|of the whole
2436.96|3.2|a um
2438.24|4.16|space in that nth layer
2440.16|4.32|then in the next next layer i would just
2442.4|4.16|use like two at a time and then i would
2444.48|4.0|use like four at a time
2446.56|3.68|till i reach the exact resolution as
2448.48|3.359|what i had
2450.24|4.079|doing this operation doesn't add any
2451.839|4.161|parameters whatsoever you're just like
2454.319|3.121|defining what your basis function would
2456.0|4.24|be or what your wavelet function would
2457.44|4.879|be in this case it is a hard wavelet and
2460.24|4.879|i start combining them and i kind of
2462.319|5.201|like learned a hierarchy at every single
2465.119|4.0|layer of the transformers
2467.52|3.2|um and
2469.119|3.361|this kind of like
2470.72|3.92|improved our performance significantly
2472.48|4.72|as compared to not using them with
2474.64|4.56|addition of no extra parameters
2477.2|3.52|um and i'll come to the results later
2479.2|3.6|also
2480.72|3.04|so so this is how the whole approach
2482.8|3.519|looks like
2483.76|3.839|you have a front end uh the front end is
2486.319|4.081|basically
2487.599|4.321|a single layer of 2000 neurons
2490.4|3.6|followed by a dense
2491.92|3.04|layer of 64 neurons which is just to
2494.0|1.76|make sure
2494.96|1.68|to
2495.76|2.319|uh
2496.64|3.439|conform it to the intermediate
2498.079|3.52|transformer readings let's say if for
2500.079|3.121|the transformers i define the embedding
2501.599|3.76|size to be 64
2503.2|3.919|then that's the dimension which i'm like
2505.359|4.561|mapping them to
2507.119|4.72|so i take a broad waveform i patch it in
2509.92|4.56|like very small patches similar to how
2511.839|4.401|you're doing vision transformers
2514.48|3.92|i would just have a single layer of 2000
2516.24|3.68|neurons followed by a dense layer of 64
2518.4|3.12|neurons
2519.92|3.28|with the hope that the first layer kind
2521.52|2.559|of is learning like a fourier basis
2523.2|3.36|function
2524.079|4.0|uh which should be adaptable according
2526.56|2.64|to what i'm learning
2528.079|3.121|after that
2529.2|3.84|i keep on doing this over and over again
2531.2|4.32|like i i don't have a classification
2533.04|5.279|head or anything like that
2535.52|5.12|i i keep on adding multiple stacks of
2538.319|3.841|transformers after that
2540.64|2.32|but
2542.16|3.04|uh
2542.96|4.56|and then i have two two approaches of
2545.2|5.04|like what i can do in terms of like
2547.52|4.16|uh adaptation i can do average pulling
2550.24|3.76|across time of these intermediate
2551.68|4.0|temperatures because that is very the
2554.0|3.52|idea is very similar to what we did do
2555.68|3.76|in classical vision that each of the
2557.52|3.44|embeddings are looking at much much
2559.44|5.04|broader
2560.96|4.96|uh output in the subsequent layers or i
2564.48|3.28|could do a
2565.92|4.08|wavelet decomposition so what i do is
2567.76|4.079|that i i take all of these embeddings
2570.0|3.28|and i define these highways so some of
2571.839|3.601|the embeddings are moving fast some of
2573.28|4.0|them are moving very slow and some are
2575.44|4.24|retained at the exact same resolution as
2577.28|4.0|what the transformer is learning
2579.68|3.919|and then i keep doing this over and over
2581.28|5.2|again i have a dense layer
2583.599|4.961|i have my soft max or sigmoid whatever
2586.48|3.76|is my classification head
2588.56|3.68|so so this is kind of what the approach
2590.24|3.68|looks like
2592.24|5.04|we compare it with
2593.92|5.199|uh all of the traditional vision uh
2597.28|3.76|based architectures so so the vision
2599.119|3.761|based models have been very good
2601.04|4.559|and the performance have been like
2602.88|4.959|similar in understanding audio also so
2605.599|4.0|we compare all of those models in terms
2607.839|3.601|like mean average precision
2609.599|3.121|and we see that even the tiniest models
2611.44|2.8|of transformers were just like
2612.72|5.04|surpassing all of the state-of-the-art
2614.24|5.68|cnn waters which was a very good sign
2617.76|3.839|then we started to bump up okay the
2619.92|4.08|larger model should keep on improving
2621.599|4.48|the performance and with the
2624.0|3.52|multi-scale models as well as with the
2626.079|2.801|pooling layers
2627.52|2.88|they improve the performance even
2628.88|3.28|further
2630.4|3.199|which which was kind of very surprising
2632.16|3.6|to us because the number of parameters
2633.599|3.76|are very small these are very tiny
2635.76|3.28|architectures yet they are surpassing
2637.359|3.681|like things like even densenet which are
2639.04|3.44|like huge models with a lot of millions
2641.04|2.24|of parameters
2642.48|3.2|um
2643.28|4.88|so so after that we said uh that i'm
2645.68|3.919|going to conclude quickly
2648.16|3.04|after that we said that okay this is
2649.599|2.72|this is looking pretty cool
2651.2|3.2|uh
2652.319|4.321|what are the actual what actually is the
2654.4|3.04|transformer or the first layer learning
2656.64|2.08|right
2657.44|2.879|so
2658.72|4.56|uh in order to
2660.319|5.361|make this plot what we said was
2663.28|4.319|okay uh if you were to take a classic
2665.68|4.48|fourier transform
2667.599|4.72|then if my this axis is kind of like
2670.16|4.24|freak like frequency
2672.319|4.401|uh this axis is the number of filters
2674.4|4.0|and this axis is the frequency
2676.72|2.8|then in a way
2678.4|2.4|it should be
2679.52|3.839|connecting
2680.8|4.4|all of the points in a linear line
2683.359|3.921|and this is akin to the number of points
2685.2|4.32|in the 50. so how many points i'm
2687.28|6.64|defining here if i'm defining 2000
2689.52|6.96|points here then i would have like 2048
2693.92|4.08|sinusoidal basis functions which are
2696.48|3.52|going from lower frequency to the most
2698.0|3.599|highest frequency
2700.0|3.52|we said okay we'll do the exact same
2701.599|5.361|thing but now with filters
2703.52|6.079|so we have a frequency along y-axis and
2706.96|4.48|the number of points in my x-axis and if
2709.599|4.48|it was a classic fourier transform then
2711.44|3.52|it would be connecting right as a linear
2714.079|3.04|line
2714.96|4.0|um but what we did was
2717.119|3.921|we we take up the
2718.96|4.24|front end which is known by transformer
2721.04|4.079|take its fourier transform sort
2723.2|3.68|according to its center frequency as to
2725.119|4.321|what frequency it is actually activating
2726.88|5.199|the most and then keep on stacking them
2729.44|4.08|uh when we did this for two problems we
2732.079|2.801|saw that we are kind of learning a
2733.52|3.52|different
2734.88|4.16|time frequency representation which is
2737.04|3.52|specific to a predictive problem so if
2739.04|3.84|i'm trying to understand what's there in
2740.56|3.68|the content of the audio i learn a
2742.88|2.56|representation which is very different
2744.24|2.96|than fourier transform which would have
2745.44|3.28|been a straight line which is kind of
2747.2|4.32|like a
2748.72|4.48|curved exponential line like this
2751.52|2.88|and if i do like a polyphonic pitch
2753.2|3.44|estimation
2754.4|4.24|i learn a very different
2756.64|4.24|front end which is adapting to that
2758.64|3.84|particular problem so this was like very
2760.88|2.8|exciting to us because
2762.48|3.68|uh
2763.68|4.0|like making computers here in a way in
2766.16|3.28|which they are adapting their ears
2767.68|4.32|according to a particular problem is a
2769.44|5.04|very cool idea
2772.0|3.76|uh second thing is we actually saw each
2774.48|2.16|of the filters as to what they were
2775.76|2.319|doing
2776.64|3.12|uh and
2778.079|3.841|these are basically just like single
2779.76|4.319|slices like this so so this is what
2781.92|4.08|would we would have been learned as a
2784.079|3.841|front-end neuron so we take up each of
2786.0|4.0|the neurons and we just plot them and
2787.92|4.159|for plotting this we basically take its
2790.0|3.599|fourier transform and then
2792.079|2.801|sort them according to where the center
2793.599|3.121|frequency is
2794.88|3.68|uh when we just saw the neurons as to
2796.72|4.56|what they were learning in the front end
2798.56|4.08|uh we saw that it is learning properties
2801.28|2.4|which are very very
2802.64|3.28|uh
2803.68|3.76|closely matching with the traditional
2805.92|2.8|signal processing so you would have
2807.44|3.2|something like an answer detector
2808.72|3.599|learned right here
2810.64|3.679|you're learning windowing function so in
2812.319|4.081|a way it is learning to
2814.319|4.081|have a kernel which is best for a time
2816.4|3.28|frequency representation what people
2818.4|3.12|have been using in signal processing
2819.68|3.2|which is like a hamming or a hanging
2821.52|3.04|window
2822.88|3.92|we are learning these pure sinusoids
2824.56|4.32|which are responsible for
2826.8|4.16|activating a particular frequency so you
2828.88|5.04|can see the richness as compared to like
2830.96|4.56|having a fixed purely sinusoidal basis
2833.92|4.72|function right here
2835.52|5.52|um so so this was what we had uh
2838.64|3.76|uh done and then to share the final
2841.04|3.76|thoughts um
2842.4|4.0|uh i'll conclude by saying that okay
2844.8|3.519|transformers are proving to be a major
2846.4|3.6|advancement in ai research across the
2848.319|2.8|fields
2850.0|2.88|and
2851.119|4.24|it seems like they're solving everything
2852.88|5.04|for now uh and hopefully this is not the
2855.359|4.801|end and we should keep an eye out on
2857.92|4.48|something which would change and
2860.16|4.08|have impact which is more than
2862.4|4.32|what transformers have put
2864.24|3.359|and who knows what's going to come next
2866.72|3.28|uh
2867.599|4.96|yeah so by that i'll just conclude and
2870.0|5.04|i'll be happy to take questions
2872.559|5.201|uh thank you pratik that was a really
2875.04|4.559|good talk and you uh you provided some
2877.76|4.559|really good insights about how like
2879.599|4.0|transformers work for the audio case
2882.319|2.561|and yeah
2883.599|4.561|thank you for that
2884.88|6.08|and now i would invite questions from
2888.16|5.959|from the class students let me just stop
2890.96|3.159|the recording