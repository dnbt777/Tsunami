start_time|end_time|text
1.0|4.56| All right, let's now talk about convolutional auto encoders. And
5.56|3.2| along with this topic, we will also talk about transposed
8.78|4.18| convolutions and deconvolutions, which are also sometimes called
13.04|4.12| strided convolutions. And I will also tell you why we need them.
17.96|3.4| So here's an overview of how a convolutional auto encoder looks
21.36|3.02| like. And if you just look at this figure here, it looks
24.42|3.06| exactly like what you've seen for the fully connected auto
27.48|3.64| encoder. The only difference is now that instead of using fully
31.12|3.52| connected layers, we are using convolution layers for the
34.64|3.2| encoder. And for the decoder, we are using these so called
37.98|4.62| deconvolution layers or strided convolutions. So why do we need
42.6|4.0| them? I mean, before, when we talked about CNNs in the
46.6|2.9| convolutional neural network lecture, we used regular
49.5|4.74| convolutions to down sample the images. So they become from the
54.24|3.52| original size, they become smaller, as far as small
57.92|5.24| convolutions we use in pooling layers. And how can we now
63.64|4.72| reverse this? So how can we now go from a smaller representation
68.52|3.72| to a larger representation? So for that, we need to kind of
72.28|3.28| invert this convolution process. So for that, we are using these
75.6|6.76| so called deconvolution layers. So there are many different
82.36|3.06| words for that. So overall, what we are interested in when we
85.42|3.26| talk about transposed convolution or deconvolution is
88.68|4.76| that we want to increase the size of the output compared to
93.44|3.36| the input. So what we want is we want to start with a smaller
96.8|4.44| input and obtain a larger output, basically the opposite
101.24|4.36| of the regular convolution. And like I said, there are different
105.6|3.4| synonyms for this process. So sometimes it's called
109.0|4.68| deconvolution. But yeah, mathematically, if you would want
113.68|4.96| to be used a precise, let's say notation, mathematically, a
118.64|3.28| deconvolution is defined as the inverse of a convolution, like
121.92|3.64| the mathematical inverse, the inverse of a function. But we
125.56|5.16| don't really need this or do this in the context of deep
130.72|3.96| learning. So in deep learning, it's kind of enough to just have
134.68|4.96| a convolution that up samples, it doesn't have to have exactly
139.64|5.0| the inverse computation. So in that way, we call that also
144.64|3.6| sometimes transposed convolution, I guess on the
148.24|3.48| name comes from the fact that we go like the opposite from instead
151.72|3.56| of going from large to small, we go from small to large. But even
155.28|4.36| that term is a little bit, yeah, I would say weird. So sometimes
159.64|4.7| people also use the term unconf or unconvolution. And sometimes
164.34|4.1| people also use the term fractionally strided
168.48|3.72| convolution, which might be a better term for that, if you
172.2|4.2| consider how it is implemented. And I will show you the next
176.4|3.92| couple of slides, how this transposed convolution also known
180.32|3.84| as fractionally strided convolution is implemented. But
184.16|4.64| again, if you read a deep learning paper, and people talk
188.8|4.7| about a deconvolution or unconflare, or transposed
193.5|4.1| convolution or fractionally strided conversion, chances are
197.68|4.76| that all of these mean the same thing. So usually, people use
202.44|4.28| all these words synonymously. And how it's implemented, I will
206.72|5.0| show you in the next couple of slides. So at the top, to start
211.72|3.84| with, let's take a look at the regular convolution first. So
215.6|5.12| here at the bottom, we have the input in blue. And the output is
220.72|6.04| at the top here in dark green. So this is a convolution with
228.36|4.64| three by three kernel, right? So see that here, it's a three by
233.0|5.44| three kernel. And if you look from here to here, it's going
238.44|6.36| by two pixel dimensions. So it has a stride of two. So we're
244.8|7.62| going here, and then the next here, and then we go down by two
252.42|5.54| pixels. So actually, we start at the left corner again, so we are
258.0|4.86| here now. And then we move again, by two positions. So
262.86|3.1| it's just a regular convolution that you have already seen here
265.96|2.64| with a three by three kernel, and a stride of two, and it
268.6|4.84| outputs this two by two feature map. So in each, each iteration
273.44|5.84| that generates one pixel, or one value. And then you get this
281.28|5.04| two by two output. Now, the transposed convolution is shown
286.32|4.44| at the bottom also with a stride of two, and three by three
292.52|4.8| kernel, and it is doing the opposite. So that's maybe why
297.32|3.08| it's called a transposed convolution, because it's doing
300.4|5.4| it kind of backwards. So here, now you start with a two by two
305.8|5.52| input. So the two by two input, what you get out is a five by
311.32|4.92| five output. Right? So here, we have at the top, again, we have
316.24|3.4| a five by five input, and a two by two output. So it's kind of
319.96|7.28| doing the opposite. So the computation is that we go here
327.24|6.16| from one pixel, and then we have our three by three kernel. And
333.4|3.0| we obtain a three by three output. So in a regular
336.4|6.76| convolution, if you have the kernel, you multiply each value
343.16|5.64| here with a pixel value. So each weight is multiplied with a
348.8|3.82| pixel value in the transposed one, it's essentially you take
352.62|3.38| this value here, the one pixel value, and multiply it also by
356.0|4.52| each value in the kernel. So you get three by three outputs. And
360.52|3.48| then you move one position to the right and in the output,
364.0|5.92| also, by a surface two, you move by two pixels. So in this way,
369.92|5.2| you create this five by five output from the two by two
375.12|4.28| input. So essentially going from a small image into a big image.
379.4|6.88| Now, this is how it conceptually works. So if I go back one more
386.28|3.4| time, so at the bottom here, this is how I like to think
389.78|2.58| about a transpose convolution, this makes sense to me, this is
392.36|4.2| intuitive to me. So again, here, this is again, what I showed you
396.56|4.98| on the previous slide. That's how I think about it. However, in
401.54|4.74| practice, this is usually emulated with a direct
406.28|3.56| convolution. So there's this excellent paper on linked here,
409.84|2.76| a guide for convolution arithmetic for deep learning
412.6|3.26| that I mentioned earlier in this class, when we talked about
415.86|4.74| convolution networks. And in this paper, they also describe
420.6|4.96| the so called emulated approach using a direct convolution. So
425.56|6.28| instead of implementing this process, there's a process that
431.84|4.08| just uses a regular convolution to implement this transposed
435.92|3.42| convolution. It's just both things here on the slide are
439.34|3.78| achieving the same thing. It's just a different way of carrying
443.12|6.32| it out. So in order to go from this two by two input to this
449.52|3.26| five by five output, you can also implement it with this
452.78|6.14| emulated approach, where you put these paddings onto the input.
458.92|3.56| So here we have a stride of two and three by three kernel. So in
462.48|4.32| this case, what would happen in this emulated approach, it would
466.8|5.68| put here this padding. So what I'm highlighting here, this is
472.48|3.96| like all padding, all these dotted lines are heading, it's
476.44|6.7| adding the padding around the input image. And also, it, it
483.14|4.42| adds the spacing between that's because of the stride. So and
487.56|4.2| this is maybe why it's also called fractionally strided
491.76|5.96| convolution. It's a weird word. But yeah, so if you look at this
497.72|3.64| at the bottom, and you think a little bit about this, you can
501.44|4.04| think about that. So if you walk through this mentally, step by
505.48|4.6| step, you should be able to see that both the top and the bottom
510.08|3.72| part here, they produce the same amount of these parts. But if
513.8|2.98| you if you completed this whole process here, it should give you
516.78|2.7| the same results as the completed feature map here.
519.48|5.4| Because here you take also three by three kernel, but here you
524.88|4.44| only consider this pixel, these other ones are essentially zero.
532.56|5.0| And then you project it up to here. And this is essentially
537.76|7.28| kind of the same as you are projecting this one up here in
545.04|5.76| that way. And then you move this one to the right. And then you
550.8|4.48| do the same thing now with this region here. Well, you have a
555.28|6.0| strand of one thinker. So you're moving here, and then you do
561.28|4.88| the same thing again. But now it's in a different position.
566.16|6.24| It's now in the kernel. At this position here, the first
572.4|3.04| iteration, let's say this was the first and the second one, it
575.44|8.0| would be at this position. And this one will go here. And you
583.44|3.56| continue. And at some point, when you go one row down, it
587.0|3.12| will override and things like that. So in that way, it will
590.12|4.0| give you essentially also this five by five output when you when
594.12|5.04| you completed this, when you went also through the next
599.16|5.2| rows. So long story short, I don't like to think of it like
604.36|2.96| this, because this is kind of complicated, like doing the
607.32|4.44| padding and putting these things apart. In my head, when I think
611.76|2.52| of a transpose convolution, I think of it as like this, which
614.28|3.96| I find more intuitive. But technically, yeah, the
618.24|4.76| implementations, I think simpler in code, if you just reuse the
623.0|6.44| convolution with this padding setup. Okay. Yes, another
629.64|4.32| example. Here, it's a regular convolution with strike one,
634.72|4.76| going from a four by four input to a two by two output. And here
639.48|4.64| it's a transpose convolution, emulated with a direct
644.12|3.72| convolution. So this is, again, an emulation here, it's a bit
647.84|3.0| simpler to see because there's no stride. So here, you can just
650.84|5.4| see there is a padding, two pixels on each side. And this
656.24|5.28| will achieve the opposite. So going from a two by two input
661.68|3.68| into a four by four output, whereas at the top, we go from
665.36|6.08| four by four to two by two. Okay, so here's the equation, if
671.44|6.48| you want to compute the output size, given the input, so as is
677.92|8.16| is the stride here, and is either the height or the width.
689.2|7.44| If it's quadratic, it could be the same K is the kernel size
696.68|5.96| and P is the padding. So you can use this formula to compute the
702.64|4.12| output size of a transposed convolution in pytorch. This is
706.76|4.28| torch and n con transpose 2d. And here I just have some
711.04|3.52| examples applying this equation to just make sure that this is
715.12|4.8| indeed how pytorch behaves when you Yeah, when you look at the
719.92|4.4| outputs. So you can plug in these numbers here for different
724.64|5.72| kernel sizes, strides and padding. And sorry, different
730.36|2.32| input, I didn't change those, you can play around with those.
732.68|2.68| If you're interested, I only changed the input size here. But
735.36|2.56| yeah, you can play around with this. And you should see this is
737.92|5.28| how pytorch computes how you would know the output, given a
743.2|4.0| certain input size, kernel size and padding. And notice also,
747.96|3.92| one interesting aspect about that is also compared to a
751.88|3.4| regular convolution, if you increase the padding, it
755.32|3.84| decreases the output size in a regular convolution, if you
759.16|2.6| increase the padding, it will also increase the output size.
761.76|4.24| So it's the opposite here, padding decreases the size in
766.0|2.72| regular convolution, it increases the size. So you have
768.72|5.72| to kind of think backwards now. Okay. So yeah, this was the
774.48|3.68| transposed convolution in a nutshell, one problem that might
778.16|3.32| occur in practice, I honestly don't see it very often. But
781.72|3.16| there's this problem of the checkerboard pattern. So if
784.88|2.08| you're interested, there's an interesting article about that
786.96|3.68| with nice visualizations. And because of overlaps in this
790.64|4.32| transposed convolution, which is highlighted here, so these dark
795.56|4.24| pixels, what might happen is that you might see certain
800.0|3.92| checkerboard artifacts. So let me go, let me show you this
803.96|3.28| slide again, this is the very first slide I already had
807.28|2.76| earlier. So again, here, the regular conversion here, this is
810.04|4.88| the transposed convolution. And you can see. So when I have,
815.2|3.22| this is not the emulated one is the regular transposed
818.42|2.34| conversion, how I like to think about it. So what you can see is
820.76|4.08| when you go from this input here, into the output, and then
826.4|2.76| do this for the next one, you have a stride of two, you can
829.16|4.04| see, here, there's some overlap, right? So there's some overlap
833.2|4.56| here. And then if you go down, then this one would be the area
837.76|4.2| here of the highest overlap, right? So would overlap all four
841.96|4.16| kernels at the end here. So in this can cause like certain
846.12|4.46| checkerboard artifacts, so which are highlighted here, so you can
850.58|3.7| see here, these, these kind of artifacts as some, some sort of
854.28|6.08| pattern that appears here. And in this article, for instance,
860.36|3.64| they done then instead recommend not using a transposed
864.0|4.8| convolution, but you use a regular convolution, or
868.84|3.5| essentially using nearest neighbor upsampling followed by
872.34|4.42| a regular convolution, instead of using transposed convolution.
877.16|5.72| Actually, I tried this out, it works well, too. So either way,
882.88|3.2| I think it's fine. If you use transpose conversions, just you
886.08|3.36| have to be careful that you don't encounters checkable
889.44|3.12| artifacts. In this case, if you have a setup like this, and you
892.56|2.96| may have a checkerboard artifact, how you would avoid
895.52|3.24| this, or how you could avoid it is essentially by just using a
899.4|2.76| two by two kernel, right? If you have a two by two kernel, and
902.16|3.8| then you move it over by two positions, so the first one would
905.96|3.52| be here, then you move it by two pixels, the second one would be
909.48|5.64| here. And the last one will be cut off. But so you can
915.12|5.76| technically try to avoid it by choosing your kernel size and
920.88|3.48| stride such that there are no overlaps. But also, even if there
924.36|4.68| are overlaps, usually, it's not always true that you find these
929.04|2.32| checkable artifacts, we have to just look at the results and see
931.36|2.88| if there's a problem. And you can optionally replace
934.96|3.2| transposed convolutions by nearest neighbor up sampling and
938.16|3.04| a regular convolution. If you're interested in that, I don't have
941.2|2.9| a code example here, but I can share a code example with you on
944.1|3.06| Piazza. So if you're interested, just ask me I can share code
947.16|3.0| example, showing you how to implement that it's not a big
950.16|4.88| deal. Alright, so that was convolutional auto encoders in
955.04|4.36| a nutshell, like explaining how the transposed convolution works
959.4|3.92| and so forth. And in the next video, I will show you how we
963.32|27.0| can implement a convolutional auto encoder in pytorch.