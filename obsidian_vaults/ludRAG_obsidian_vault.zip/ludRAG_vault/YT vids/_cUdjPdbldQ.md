start_time|end_time|text
1.64|3.2| Yeah, so instead of making more slides, I thought it might be
4.84|3.04| more fun to do this video on tips and tricks to make guns
7.88|4.12| work a little bit more interactive. That is, yeah, I
12.0|3.72| will walk you through a list, a very nice list of tips and
15.72|4.36| tricks. And then we will see in the code that we seen last
20.08|5.8| video how or if I use these tricks. Okay, so this list is
25.88|4.72| based on a GitHub repository by Sumit Chintala. Sumit Chintala
30.6|4.48| is a researcher at Facebook AI research. And yeah, it's also
35.08|4.42| one of the main pytorch developers and also back in 2016
39.5|3.26| worked on the Wasserstein gang, which is a very popular version
42.76|6.76| of the gang. So here in this list, there are I think 17
49.52|3.0| tips. So I wanted to walk through them step by step. It
52.52|4.84| says that this list is no longer maintained. And he says he's
57.36|2.8| not sure whether it's still relevant in 2020. But actually,
60.16|4.32| most of the tips are still very useful. So they are really
64.48|3.46| useful starter tips for guns, even though the list is not
67.94|4.82| maintained anymore. So let's look at them one at a time. So
72.78|2.62| normalizing the inputs, normalize the images between
75.56|3.52| minus one and one range and using 10 h in the last layer of
79.08|3.96| the generator output. So that is something I actually did. So
83.24|5.12| here, I normalize the images and minus one, one range. And then I
88.36|3.52| also had my 10 h here. By the way, I was writing this code
91.88|3.24| before I looked at the list. So everything is just a poor
95.12|4.08| coincidence, or based on something I've heard before,
99.24|4.8| that seems to work well in practice. So then in gang
104.04|4.64| papers, the loss function is to optimize it as follows, but in
108.68|3.76| practice, we do the maximization. And then we flip
112.44|5.12| the labels. When training the generator, this is for the whole
117.56|2.52| thing is for the generator, the modified loss function. And this
120.08|3.92| is also what we extensively talked about. So when we go
124.0|4.4| back here, this is essentially what we talked about when we
128.6|5.6| flip this one minus into just the output. And then we also
134.2|4.56| flip the labels that was right here. So yeah, we are also using
138.76|7.64| that trick. That was also in the code using a spherical scene. So
146.4|3.56| instead of sampling the noise from a uniform distribution, we
149.96|4.16| are sampling from a Gaussian distribution. And that's also
154.12|6.8| something I did when we revisit training code here. So I think
160.92|3.56| it was at the bottom somewhere training again. So yeah, we used
164.48|7.04| a random normal distribution and not uniform distribution. All
171.52|6.28| right, next, using batch norm. So when using batch norm, it's
177.84|3.52| so I'm actually not using batch norm in this code, but I will
181.48|3.7| show you in the next video, my code for the setup a face image
185.2|4.2| data set where I was writing convolution again, and there I
189.4|4.48| used batch norm. And here the trick or tip is about not
193.88|4.32| mixing the real and generated images. So here, the
198.2|3.48| recommendation is keeping them separate. So training the
201.68|3.84| discriminator on a batch of real and a batch of generated instead
205.52|3.0| of mixing real and generated. And that is also something we
208.52|8.96| did. So when we go back to the code here, right here, so we
217.48|7.36| have fake images. And we have the real image, the real images
224.84|4.64| are up here, real images, and fake images, and we feed them
229.48|2.88| to the discriminator separately. So first, we get the real
232.36|2.76| images, and then the fake images, we don't mix them
235.12|7.24| together. Okay, next, avoiding sparse gradients using leaky
242.36|4.52| relu. So yeah, like we talked about before, the relu can have
246.88|3.52| these dead neurons. Let's lecture, I think lecture five,
250.4|2.68| six, something like that. Was it later, it could have been nine
253.28|3.28| when we talked about activation functions. And we talked about
256.6|3.2| the dead relu problem. And yeah, if we have a generator that
259.8|4.04| should generate something, maybe using a regular relu is not a
263.86|6.46| great idea. So using relu here, actually, in both in G and D,
270.32|6.14| the generator discriminator might be a good idea. So let's
276.46|6.54| check whether we use that. Yep, I have leaky relu here. Next
283.0|3.24| for down sampling use average pooling. Okay, this is something
286.24|3.54| I have not done. So this is actually that will be in my
289.78|7.86| next. Let me just double check. No, I don't have done that. Okay,
297.64|4.2| that might be that might be something to consider to improve
301.84|5.4| my code using average pooling. And for up sampling, conf
307.26|3.62| transpose plus stride, that is something I used pixel shuffle
310.88|3.88| might also be an additional interesting trick, which we may
315.0|4.32| find here in this paper, using soft noisy labels, that is
319.32|3.28| something I have tried in the past, it worked a little bit
322.6|5.4| better, I think. So wasn't that much better about slightly
328.24|3.24| better. I haven't done this in this code, because I didn't, I
331.48|3.12| didn't keep in mind everything. But if you want to play around
334.6|2.24| with that, it's another interesting thing to do. So
336.84|5.08| instead of using one for real, we use random numbers between
341.92|3.36| point seven and point one point two, to make the labels a bit
345.28|3.24| softer, or not softer, but to Yeah, instead of having these
348.52|2.94| fixed numbers, having some uncertainty around them. And
351.46|4.22| then for the fake ones to use the numbers between zero, and
355.68|3.12| point three, actually, when I did that, I had like a slide,
358.8|3.64| as I only had the soft labels, not the noisy labels. So I only
362.64|3.12| had like, instead of one, I had a point nine and stuff zero, I
365.76|3.72| had a point one, and it helped a little bit. So I haven't tried
369.52|4.08| this range before or this range point three. So it might be
373.6|4.92| something interesting to try. And there's also another thing
378.52|3.24| here on making the labels noisy for the discriminator by
381.76|3.0| occasionally flipping them. I also heard this works very well
384.76|2.96| in practice to improve the discriminator. So it doesn't
387.72|3.92| become too good. So you kind of shake it up sometimes. And I
391.64|3.04| also have not tried that yet. It might be another interesting
394.68|6.04| thing to try. Yeah, using DC again, when you can. So I okay,
400.76|3.52| I mean, I intentionally didn't use it here to keep things
404.28|2.46| simple, just having the simple regular GAN with the fully
406.74|3.3| connected layers. But in the next code example, where we work
410.04|4.56| with face images, I will use DC again. So nowadays, also, like
414.6|4.98| I mentioned before, in the lecture, it's just called GAN,
419.58|3.98| because nowadays, I mean, when DC again, was new, everyone used
423.6|3.68| abbreviation DC again, to distinguish it from the original
427.28|4.12| GAN. But nowadays, convolutional GANs are so common that we don't
431.4|6.16| say DC again, we just say again, using stability tricks from
437.56|3.08| reinforcement learning. So I'm not a big reinforcement
440.64|4.04| learning person. So I haven't used these tricks. But what
444.68|4.72| might be useful is keeping checkpoints from the generator
449.4|3.56| and discriminator that is like saving them occasionally every
452.96|4.36| few epochs. And then also swapping them sometimes. So if
457.32|3.4| things go bad, swapping in the old versions could also be
460.72|5.92| useful. Now, yeah, regarding the optimizer, Adam rules. So yeah,
466.64|3.96| Adam is usually working most of the time, well out of the box.
470.6|5.04| And another recommendation is using SGD for the discriminator
475.64|3.52| and Adam for the generator. I think this is due to the fact
479.16|3.96| that momentum may not be ideal for the discriminator because
483.12|3.92| you wanted to react quickly. Same actually also for the
487.04|2.92| generator. But in practice, I still find that training
489.96|3.72| actually both with Adam is even better. I tried this, actually,
493.68|3.08| and it didn't work so well. So I switched back to using Adam for
496.76|2.98| both the discriminator and the generator. But again, this is
499.74|2.66| something you have to try and practice. Sometimes it may work
502.4|4.76| better. Sometimes it may work worse. Track failures, failures
507.16|5.68| early. Okay, so just checking things if the discriminator loss
512.84|2.96| goes to zero, then that's not good. The discriminator is too
515.8|3.44| strong. And then the generator may not be able to learn
519.24|4.2| anything useful, maybe you have to see how you can address that
523.96|4.76| checking the norms. So if the norms of the grain of the gradient
528.72|3.54| norms are too large, then it might also not be good. So some
532.26|2.26| people also use something like a gradient penalty. We haven't
534.52|3.36| talked about this yet. It might be I mean, there's so many
538.16|3.04| infinite many things to talk about. But it's another thing to
541.2|4.52| keep in mind. When things are working, the discriminator has a
545.72|2.64| low variance and goes down over time versus having a huge
548.36|2.44| variance and spiking. Let's take a look.
550.8|8.96| Oh, yeah, it goes down. I mean, goes up and down and then kind
559.76|3.8| of stabilizes. Looking at there are no spikes, actually looking
563.56|3.48| at the value. Also, the variance is relatively small compared to
567.04|3.08| the generator. So that kind of looks like it's a hearing to
570.16|8.16| what we would expect here. One thing about that is this value
578.32|4.84| is around I would say maybe point point 5.6, something. And
583.16|4.6| if you think about a random prediction around point five, and
587.76|4.56| then you take the log of point five, or minus log point five,
592.32|4.06| it should be around point 69, something like that. So it's
596.38|2.62| actually kind of like a random prediction. So it's actually
599.0|3.04| quite good that it is in that range here. So for binary
602.04|6.68| prediction, point five minus log point five should be around point
608.72|4.2| six, nine. So in that way, you can see, okay, this is actually
612.92|3.52| close to point six, nine. So it's kind of like a random
616.44|7.76| prediction here, which is good. Okay. Um, if loss of generator
624.2|5.36| steadily decreases, then it's fully D with garbage. Okay. So
629.56|3.24| yeah, okay, we don't have this problem here. I will show you
632.8|3.16| actually a failure case in the next video. Let me just double
635.96|5.16| check on it. I can show it already. It's not going down.
641.12|3.24| It's rather going up. But yeah, there was something interesting
644.36|8.88| happening there. We will revisit that in next video. Okay. Don't
653.24|3.84| balance the loss via statistics unless you have a good reason
657.08|4.86| to. So yeah, that is, don't try to find a number of generator
661.94|6.38| number of discriminator updates. It usually doesn't work so well
668.32|3.28| in practice. It's kind of hard just to find the good
671.6|3.68| recommendation. If you recall the original GAN paper, I had a
675.28|3.28| hyper parameter for the number of discriminator updates before
678.56|6.8| updating the generator. Let's go to the paper, the screenshot of
685.36|6.84| that algorithm somewhere here. Yeah, the case steps. So here,
692.2|3.0| they used cake was one one might be tempted to have multiple
695.2|2.88| discriminator updates before updating the generator. But
698.08|4.36| yeah, apparently, this is probably not a great idea. It's
702.44|5.4| hard. We've all tried it. Also, following a more principled
707.84|6.6| approach. Like checking the loss of the losses too large, or if
714.44|3.16| the loss is very large, train the discriminator until it goes
717.6|3.48| down. Or if the loss for the generators too large, train it
721.08|4.2| until it goes down instead of doing a fixed number of updates.
727.48|3.04| If you have labels, use them. So if you have labels available,
730.52|3.64| train the discriminator to also classify the samples. So it's
734.16|3.44| kind of like an auxiliary GAN. Actually, last year, we worked
737.6|3.08| on a paper, we actually did that here. This is used to cycle
740.68|3.44| again, it's more of the advanced concepts, which we won't cover
744.12|5.04| in this class. But part of it, we also had a GAN here. I mean,
749.16|3.12| this is like an interesting setup, we have an auto encoder
752.28|3.4| plus again, so there's also the GAN aspect that we have a
755.68|3.4| discriminator here. And this is the generator, but it happens
759.08|4.2| also in auto encoder. So it's kind of like a hybrid. And here,
763.28|3.92| we also had attribute classifier and an auxiliary face matchup,
767.2|4.08| which are kind of like auxiliary ones. So this is really the
771.28|5.04| auxiliary one. And this is an additional constraint here. So
776.64|2.4| it's also Yeah, might be a good idea if you have label
779.04|6.96| information to include that as well. It also brings me to the
786.0|4.32| topic of how we evaluate GANs. So kind of a tricky question.
790.6|2.46| Still an active research problem. We haven't really
793.06|5.24| talked about it. One is called fresh at inception distance. And
798.3|3.86| it's kind of also, it's based on essentially comparing. So many
802.16|5.2| of these metrics are based on comparing the distribution of
807.36|4.68| the training data to the distribution of the generated
812.04|3.52| data to see how similar the distributions are. And sometimes
815.56|4.4| people also use pre trained models. For instance, you can
819.96|4.04| train, let's say model on, let's say MNIST, the classifier on
824.0|2.92| MNIST, and then you do the classification on the original
826.92|2.72| MNIST data set. And then you do the classification on the
829.64|4.3| generated data set. And you expect approximately that. So
833.94|3.98| the better the model is, the better the classifier prediction
837.92|4.2| should be. Because if you train the classifier on the original
842.12|2.04| data set, and then you show it garbage, it probably won't
844.2|2.12| perform as well, the distribution of predictions
846.32|2.92| will be different from the training set distribution
849.32|5.32| predictions. So that is kind of one way to kind of get a feeling
854.64|2.72| of how good the results are. But yeah, there are many other
857.36|3.64| metrics, which are also slightly out of the scope of this class.
862.68|3.96| At noise to the inputs decay over time. So adding some noise,
866.64|4.1| it's kind of, I think, yeah, this is like getting noise to
870.74|3.54| the way of the generator and to the inputs. It's kind of like
874.32|3.68| adding, if you think back of the denoising auto encoder we talked
878.0|3.08| about, it's kind of like that adding some noise to the input
881.08|6.0| images, train the discriminator more, so it's not sure. So yeah,
888.32|3.8| there that is like going back to the tricky part that we also
892.12|2.52| had here in the paper, whether we should train the
894.64|3.04| discriminator more times than a generator. It's a not sure
897.68|4.4| thing. batch discrimination, I actually forgot what that is.
902.2|7.2| Sorry, should look this up again. discrete variables. So
909.4|3.12| yeah, so conditional, again, is another topic we haven't talked
912.52|6.12| about. So what you can also do is you can concatenate the
918.8|5.0| target variable with the input, and then also feed it through
923.8|3.92| the network is in a conditional setting. And then it also allows
927.88|5.14| you to reconstruct. So if you mean that two ways to do that,
933.04|5.36| some people concatenate it with the input. And then you
938.4|3.96| concatenate it with the generated output. And you check
942.36|4.44| the sorry, you check the reconstruction also. So there's
946.8|2.04| more like for an auto encoder setting, but you include
948.88|3.74| essentially, labeling information. And that can also
952.62|4.74| help you to generate particular data points of a particular
957.4|2.72| class, if you're interested in that. And here it appears that
960.12|4.04| it also may be a general trick that helps making gants perform
964.16|4.44| better. I haven't done experiments extensively with, with
968.6|3.6| that, but it also goes back. I mean, not without it, but also
972.2|4.16| goes back to our case here where we add, add this to the input,
976.36|3.68| the target labels, essentially, we provide both essentially, and
980.28|4.36| this is for different contexts, because we want to switch the
984.68|3.2| attributes of the image. But yeah, apparently, maybe it can
987.88|5.8| also help stabilizing GAN training. Using dropout both
993.68|3.86| during training and testing, I have used only dropout during
997.54|3.26| training. Using it during testing is an interesting idea
1001.04|3.04| might be something worth trying. And now this is already it, by
1004.08|4.0| the way, 17 is also my favorite lucky number, I always like to
1008.08|5.84| have the 17 in soccer back then, long time ago. But yeah, so
1014.12|2.84| anyway, so that is just maybe an interesting idea of things to
1016.96|4.84| try some initial things that work well with GANs. Notice
1021.8|2.44| that this is not longer maintained, but many of these
1024.76|3.24| tips are still very relevant, in my opinion. Alright, so the
1028.0|27.6| next video, I will then talk about our DC GAN.