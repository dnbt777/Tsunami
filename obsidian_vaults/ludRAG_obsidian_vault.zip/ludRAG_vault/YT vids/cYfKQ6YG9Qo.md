start_time|end_time|text
5.24|5.88|um Hello thank you all for joining CS uh
8.08|5.08|25 Transformers today uh for today's
11.12|5.72|talk we have Ming ding a research
13.16|5.84|scientist at jeu AI based in Beijing he
16.84|4.96|obtained his bachelor's and doctoral
19.0|5.56|degrees at tingua University and he does
21.8|5.44|research on multimodal generative models
24.56|5.44|and pre-training Technologies um he has
27.24|5.44|LED or participated in the research work
30.0|5.48|Works about multimodal generative models
32.68|4.96|such as Cog View and Cog video and
35.48|6.12|multimodal understanding models such as
37.64|6.68|Cog uh VM and Cog agent uh for today's
41.6|5.84|attendance the attendance form is up on
44.32|7.32|the course website and if you have any
47.44|8.119|questions ask them through slido s l d o
51.64|7.68|and for the code you just have to input
55.559|6.121|cs25 um thank you Ming for today's talk
59.32|5.56|and I'm going to pass it off to
61.68|8.079|you thank you for the instructors of
64.88|8.32|cs25 to is very happy to gave a talk in
69.759|7.481|Stanford University about multimodality
73.2|10.84|in training and uh uh actually I have
77.24|11.08|checked the uh all the previous talks in
84.04|7.6|cs25 and uh they are really diverse
88.32|6.479|topics someone share the intuition in
91.64|7.04|their research about PR training someone
94.799|5.6|shared recent Works about maybe M Moe
98.68|6.6|and some other
100.399|8.601|technical uh actually I'm working in a
105.28|6.439|uh large language model company in China
109.0|6.079|and our company working on print
111.719|7.04|training and uh maybe there's lots of
115.079|5.881|different area uh from a large langage
118.759|4.161|model and
120.96|5.88|multi modality model and generative
122.92|7.08|model diffusion and uh tatto Speech
126.84|6.119|something like that so uh I Le all the
130.0|6.76|multimodality model research in J AI so
132.959|7.841|I will uh share lots of different topics
136.76|7.88|in in in this talk um some some of them
140.8|8.24|may be not very familiar to you so uh
144.64|8.319|yeah it's okay but you can uh get more
149.04|8.559|information of the the area uh
152.959|7.841|yeah I will talk about several aspects
157.599|7.321|of Transformers and I will generally
160.8|10.88|follow the history of large language
164.92|9.08|model and say why are we here it's about
171.68|7.04|large language model introduction and
174.0|7.959|history uh and how did we get here it's
178.72|6.519|about the some practical techniques for
181.959|5.84|training large lar langage models and
185.239|6.681|what are we working on it's about the
187.799|7.72|last one year uh the real language
191.92|7.48|models and other techniques in the uh
195.519|7.481|papers of all the uh V language model
199.4|7.64|community and finally I will talk about
203.0|8.2|the some possible and valuable direction
207.04|4.16|for research in multimodality
211.36|5.36|okay okay
213.68|6.919|well uh I will share three
216.72|7.519|moments uh I think the most important
220.599|5.2|three moments in the development of
224.239|5.441|language
225.799|8.121|model uh the first moment is called Bo
229.68|8.96|moment actually I get I got into the
233.92|6.44|area at this moment it's very uh honored
238.64|4.4|that I'm the first
240.36|6.36|among the first group of people who
243.04|7.559|publish paper on the next year ACL when
246.72|8.64|B came out and at that
250.599|7.961|time since is is we don't really know
255.36|6.559|what is language modeling
258.56|4.4|so at that time nearly all the people
261.919|4.201|talking
262.96|7.28|about uh how can we get a better
266.12|7.079|self-supervised method for an option
270.24|5.959|uh at that time a common opinion is mask
273.199|6.72|language model is just
276.199|7.72|for is is good at understanding the the
279.919|8.84|TX and GPT the auto regressive model is
283.919|10.041|better for tax generations and T5
288.759|9.88|maybe can U can do the B but is
293.96|7.72|redundant and that's true but uh uh
298.639|9.921|nowadays we are we will say that
301.68|14.68|gbt and has now uh nearly
308.56|13.24|uh s buet all the NP problem uh uh is
316.36|9.72|some sometimes the SC changes and we
321.8|8.399|will back from that time time point and
326.08|7.119|know how the language model change
330.199|8.56|and how we got more and more knowledge
333.199|10.44|about language model so at that time the
338.759|8.28|we I'm also among one of them who want
343.639|5.921|to develop a new self supervise my
347.039|6.921|learning method for
349.56|9.079|option we uh publish paper called glm
353.96|9.64|and we want to unify the board The Mask
358.639|12.0|language model and autoing model and uh
363.6|10.76|um T yeah uh in decoder only style the
370.639|9.0|actually the method is very simple we
374.36|9.64|just uh select a sequence a part of the
379.639|7.921|sequence and uh only do auto auto
384.0|6.84|regressive modeling during this sequence
387.56|6.44|so if this we select The Mask
390.84|7.799|area uh as all the sequence it become a
394.0|8.96|GPT and part of them it become board so
398.639|7.28|that's a method we F we found very
402.96|7.239|efficient and because we clean is like a
405.919|6.641|b is about 15% of mask area and they
410.199|6.801|perform better than b between TR as a
412.56|7.919|GPT perform as the same as GPT it's
417.0|7.599|quite um uh
420.479|8.201|pring but uh there's
424.599|8.681|a uh the the the second moment I think
428.68|9.639|is very important is the gpt3 movement
433.28|6.56|it tell us the scaling law is very
438.319|4.801|important
439.84|7.4|so you can design different
443.12|8.32|architectures Define different laws
447.24|8.04|different uh uh selfis task and
451.44|7.319|different method to schedule different
455.28|6.919|models but uh the
458.759|8.88|performance maybe uh has some upper
462.199|11.44|bound but if you add more compute you
467.639|10.321|can get a a guaranteed the performance
473.639|6.24|Improvement You can predict the result
477.96|3.88|uh complexity
479.879|6.72|uh based on
481.84|9.4|the based on the fitted Cur
486.599|6.72|so uh at that time the language modeling
491.24|5.44|has become more and more
493.319|6.44|engineering uh if if you have find a
496.68|5.4|very good points you train a language
499.759|6.921|model if you want to scale
502.08|8.92|it uh you and uh your boss give you uh
506.68|9.279|four times or Mons uh you can buy four
511.0|7.56|times the compute you just assign the uh
515.959|6.681|compute for more
518.56|8.24|parameters or uh training more tokens
522.64|7.48|this is this is uh called scaling low
526.8|7.88|and you they they tell you how how you
530.12|6.76|can assign different potential of of
534.68|6.0|your monies
536.88|7.079|so so uh at that time
540.68|6.839|uh you don't really the language model
543.959|6.081|don't really need some maybe uh
547.519|8.481|architecture Innovation
550.04|9.799|or as uh algorithm Innovation so has
556.0|9.48|become a engineering
559.839|8.801|scene and uh the third moment I think
565.48|7.52|which is more more important uh is
568.64|8.84|called Charing PPT moment at that moment
573.0|7.959|it tell us a very important fact is Task
577.48|6.76|adaptation is cheap and
580.959|5.44|what what is very important is the
584.24|8.56|knowledge from PR
586.399|9.961|training this is very B lesson so I have
592.8|4.4|told you that at that time we design
596.36|4.88|different
597.2|8.16|losses uh different architect PES but
601.24|6.56|the one some some of the pro the the aim
605.36|6.039|of design different losses is to perform
607.8|6.64|different tasks for example uh the
611.399|7.56|autographing model cannot fill in the
614.44|8.12|blank in the sequence but glm and BR can
618.959|5.801|so we uh use different point training
622.56|5.36|task but
624.76|5.28|uh uh currently we know that the task
627.92|5.12|adaptation is very cheap you just need
630.04|7.76|to F tune your language model as the
633.04|8.76|final as the final period what the the
637.8|8.88|only important thing is your PR train PR
641.8|10.52|training losss uh the the left figure is
646.68|8.599|uh from instruct GPT uh it's uh it's
652.32|7.0|actually the paper about chat gbt and
655.279|9.441|how can we align a PR model to a chat
659.32|9.92|model it told that uh the alignment can
664.72|7.559|give a very huge Improvement on human
669.24|7.52|preference compared to the original
672.279|8.521|printr language model and the right
676.76|8.24|figure is actually a recent paper in our
680.8|7.479|company uh it's is tell us a very
685.0|4.92|important uh fact and maybe it's
688.279|5.36|intuitive
689.92|6.039|uh the fact is the
693.639|7.281|downstream the performance of Downstream
695.959|11.361|task is only related to the
700.92|11.2|loss to the loss of tring yeah and it's
707.32|9.4|not directly relevant to the model size
712.12|8.719|which means if a large model
716.72|8.2|which uh uh where very high loss because
720.839|7.761|of leak of training and a small model we
724.92|9.52|train more and to reach the same level
728.6|9.88|of loss they performed exactly the same
734.44|9.36|in the downstream tasks so
738.48|7.56|the soall emergent ability and some
743.8|7.159|other maybe
746.04|9.479|uh uh ability uh strange rumors are not
750.959|7.641|true actually not the ability is not not
755.519|6.361|from the number of parameters of
758.6|6.96|language model is actually uh from uh
761.88|8.36|only relevant to the loss of your
765.56|8.719|language model so all the language model
770.24|9.24|become a game of curl feeding this is
774.279|9.481|actually the the the current uh the
779.48|9.0|current uh situation or language model
783.76|7.48|research so uh there's also some
788.48|8.4|technical details of lar Lang model uh
791.24|8.64|even way uh we know it's not cting but
796.88|6.399|there's a lot of important
799.88|8.88|things uh so we back from the some
803.279|7.0|Basics and uh talk about the Transformer
808.76|4.24|the Transformer
810.279|5.36|architecture uh a very interesting thing
813.0|6.399|is the most important
815.639|6.361|improvements nowadays are still from the
819.399|7.041|the the first author of the Transformer
822.0|8.88|paper the norm and maybe from his other
826.44|6.6|papers so uh actually the the real
830.88|5.84|innovation in
833.04|7.08|architectur is very small uh I can
836.72|7.16|summar summarize some
840.12|6.48|common uh adaptation on Transformer
843.88|5.28|currently first is decoder only the
846.6|6.84|original Transformer is a encoder
849.16|7.88|decoder architecture so um it's
853.44|8.0|redundant because the important the the
857.04|7.56|the encoder and the decoder uh should
861.44|6.68|learn the how to how to understand the
864.6|6.52|Tex from different parameters is
868.12|6.24|redundant and currently we only care
871.12|6.279|about decoder only decoder only
874.36|5.52|architectures the second one is pre
877.399|6.0|layer Norm in the original Transformer
879.88|7.36|layer the layer Norm is after the
883.399|8.88|residual residual connection is called a
887.24|9.64|postar norm and currently we usually use
892.279|6.761|PRM the rotary position in Bing is
896.88|4.12|something very special because in not
899.04|7.359|published from a paper it's not
901.0|6.49|published from a Chinese blog uh it's uh
906.399|2.641|but currently
907.49|5.51|[Music]
909.04|8.2|is is Prov and very
913.0|8.8|efficient and the group query attention
917.24|7.08|is actually from another people nor it
921.8|7.399|cance the inference
924.32|10.84|memory and GL warant is also from nor as
929.199|11.12|uh just a a replacement of the MLP and
935.16|8.84|mixure Export actually U also from Norms
940.319|6.801|paper and uh you can use the same flow
944.0|9.319|small parameter to get better
947.12|9.12|performance so this uh is what the the
953.319|5.841|current the most advanc open source
956.24|4.68|language model the architecture of most
959.16|3.76|Advan open source language model for
960.92|6.359|example
962.92|7.56|Lama okay we we know there tecture about
967.279|4.56|how to train the this Transformer is
970.48|7.039|also very
971.839|9.841|important uh this we need to uh prepare
977.519|7.641|very powerful code base to train the
981.68|8.639|large language model so the first choice
985.16|8.039|is deep speed is it's a library from
990.319|6.561|Microsoft uh and some of the most
993.199|7.721|important optimization method is from
996.88|5.48|the paper called Z in deep from Deep
1000.92|6.039|speed
1002.36|10.2|group uh if you several years ago some
1006.959|7.761|of us uh not really know how to train a
1012.56|7.399|very large model how to efficiently
1014.72|10.359|trans them but z uh give us some advices
1019.959|9.96|for example uh if we uh we can find the
1025.079|9.96|most uh memory conception is actually
1029.919|11.52|the Adam stat the optimizer St you must
1035.039|10.121|keep it a for precision as a flood and
1041.439|7.041|the m is also a FL the parameter and
1045.16|7.44|gradient you can keep it half precision
1048.48|8.8|and you you can have
1052.6|7.24|a fast computation and save
1057.28|6.72|memories
1059.84|7.28|uh the Z1 can scatter the mass weight
1064.0|8.88|and timer State into all the data
1067.12|10.88|parallel ranks so if you have more uh uh
1072.88|6.919|more ranks more GPU cards you just uh
1078.0|4.32|use l
1079.799|4.561|GPU memory
1082.32|5.56|for for each
1084.36|6.199|rank uh another important technique is
1087.88|5.64|called activation check pointing is
1090.559|6.881|actually recalls the IM
1093.52|7.96|intermediate uh State and recompute when
1097.44|7.719|backward so uh we don't really need
1101.48|7.84|record all the computation flow graph we
1105.159|8.52|just need to recall the some of of the
1109.32|7.88|Hidden States it's reduce all the
1113.679|7.081|activation many layers from into one
1117.2|7.92|layers and there's other
1120.76|7.88|methods to reduce the memory conception
1125.12|6.52|for example Z2 CPU offload which means
1128.64|7.919|you can offload some uh GPU memory to
1131.64|7.44|CPU and Z three and also call fly shed
1136.559|7.24|data
1139.08|7.12|parallel you can just uh sh your model
1143.799|5.481|into different cars and when you use the
1146.2|7.8|parameter you gather this parameter from
1149.28|8.92|the other R so all all this method is
1154.0|7.48|very complic complicated but uh the Deep
1158.2|8.76|speed Library have already give a very
1161.48|7.92|clean API to use it uh it's so currently
1166.96|4.12|it's not very hard to train very large L
1169.4|6.759|remodal
1171.08|7.88|efficiency and magron is another uh
1176.159|5.601|framework to train large language models
1178.96|4.8|it's and it is also the most valuable
1181.76|5.399|framework to train a super large
1183.76|7.72|language model more than 100 billion
1187.159|7.561|parameters uh it's use another set of
1191.48|5.28|optimization method uh the first is
1194.72|4.439|called tensor parallel the tensor
1196.76|8.44|parallel split the hidden
1199.159|10.4|size and has into different ranks and it
1205.2|5.24|ca additional or reduce for attention
1209.559|8.761|and
1210.44|11.16|mlc but um reduce the uh all the uh
1218.32|5.8|parameters conception and the Computing
1221.6|6.64|conception into different TP
1224.12|7.559|ranks uh the pipeline parallel is a uh
1228.24|8.64|to split the layers into different ranks
1231.679|8.24|and uh uh it also uh in introduce
1236.88|6.039|bubbles in peline and there's some
1239.919|8.561|method for example inter and bubble to
1242.919|8.76|remove this uh conception uh yeah maybe
1248.48|6.04|if you are if you want to chain a very
1251.679|6.441|large language model uh one day you need
1254.52|7.76|to learn about all this kind of system
1258.12|6.08|system SC because the current uh lar
1262.28|7.16|Lang remote training is actually a
1264.2|9.68|engineering work uh yeah LP is not very
1269.44|4.44|important the the important is
1273.919|7.441|mlc okay uh so and another very
1278.84|5.92|important thing is long
1281.36|5.799|Contex uh it's actually lossless long
1284.76|6.399|contact which means we don't use SP
1287.159|5.721|tension or other uh meod to change the
1291.159|3.801|for attention
1292.88|6.799|Behavior
1294.96|8.68|Uh is the the current INF to tr long
1299.679|8.041|context is beyond the imagination uh for
1303.64|8.56|AI guys for five years ago uh the left
1307.72|7.559|figure is actually my paper uh when I
1312.2|6.719|yeah published them several years ago in
1315.279|8.441|Europe it's um at that time there's no
1318.919|8.201|such thing like uh gbt gbt 3 is only B
1323.72|7.28|so um this paper is
1327.12|7.08|actually uh very very complicated to
1331.0|6.44|schedule the two schedule two different
1334.2|4.56|boards to uh mimic the retrieval
1337.44|3.96|rehearsal and
1338.76|4.64|forget process in working memory or
1341.4|6.8|human
1343.4|10.0|to uh let the model to understand very
1348.2|9.04|long Contex step by step but uh actually
1353.4|7.8|we can see that we can use different
1357.24|7.48|system level AR technical
1361.2|6.12|to uh understand very very long context
1364.72|5.64|for example more than
1367.32|7.04|uh one more than
1370.36|6.76|100,000 uh lens is full attention so
1374.36|4.679|it's just different from several years
1377.12|6.439|ago and the
1379.039|8.88|anything uh is super simplified because
1383.559|7.921|because of this Improvement uh a key
1387.919|6.24|technique is called context parallel
1391.48|9.079|which means we split the sequence into
1394.159|12.041|different RS and use ring attention or
1400.559|8.881|Uris and other technique called to uh uh
1406.2|6.4|finish the attention uh
1409.44|6.88|uh there's a library called Transformer
1412.6|7.439|engy and all of this function is worked
1416.32|5.4|in this library and uh uh we need to
1420.039|5.161|hand out the load balance of the
1421.72|4.8|attention um to make every R have the
1425.2|5.599|same
1426.52|7.72|computation so uh this is actually trans
1430.799|7.521|change lots of different research
1434.24|6.2|of and applications of op for example
1438.32|2.12|with
1440.64|7.399|uh we summary and uh uh extract some
1445.64|7.88|facts from the documents several years
1448.039|7.76|ago using uh like bm25 or other or and
1453.52|5.44|other retrial method and currently we
1455.799|6.441|can just use a Transformer and full
1458.96|8.24|attention to get the information and
1462.24|8.0|understand it it's quite quite important
1467.2|7.24|uh Improvement
1470.24|8.08|so using this very powerful infra we can
1474.44|6.56|train very large language models and the
1478.32|6.68|for the alignment the first period is
1481.0|8.0|called sft and supervis find un it's
1485.0|8.44|actually a very ordinary funing for
1489.0|7.44|language model a high quality data and
1493.44|6.4|the high quality data is usually from
1496.44|7.119|Human notation the human this human
1499.84|6.959|annotation is not not just CR sourcing
1503.559|7.48|you need to hear export from different
1506.799|7.081|domains to write this high quality
1511.039|7.921|answers to train the model for example
1513.88|9.88|if you want to uh want the model to
1518.96|10.16|um uh write some code and explain the
1523.76|7.24|code in a very formed way you need to uh
1529.12|6.24|here a
1531.0|8.399|very experienced programmer to write
1535.36|7.919|some example to teach this language
1539.399|7.921|model it's not just CR sourcing this is
1543.279|6.161|quite different from the prous human
1547.32|7.2|anotation and
1549.44|7.68|the we can also extract the uh question
1554.52|7.56|answer pairs from more powerful models
1557.12|10.52|like gbt for turo to train our model but
1562.08|9.479|uh this is actually not aled by open AI
1567.64|7.6|uh so you cannot use this me to develop
1571.559|7.041|uh their uh a model to competing with
1575.24|6.72|them but uh you actually
1578.6|8.28|uh uh if you for research you don't
1581.96|6.52|worry about this using this method n
1586.88|4.44|pass4
1588.48|6.319|because there's a paper called way to
1591.32|8.8|strong generalization and recall what I
1594.799|8.721|said just now now uh what your what
1600.12|6.64|what's really important is your PR loss
1603.52|7.279|if your PR loss is lower than your
1606.76|8.44|teacher math teacher model you can also
1610.799|8.441|uh surpass your teacher model uh even
1615.2|6.599|you use the SF uh data from your teacher
1619.24|6.039|mode
1621.799|7.0|yeah and another period of alignment is
1625.279|6.041|called irf it use reinforcement learning
1628.799|6.201|from Human feedback
1631.32|7.2|to uh improve the model but actually the
1635.0|8.32|most com open language model uh didn't
1638.52|10.519|use this method the main reason is U uh
1643.32|8.8|PO is very hard to um implement it could
1649.039|5.561|be it it could be very powerful if your
1652.12|6.799|reward model is good enough but not easy
1654.6|9.64|to treat so uh that there
1658.919|8.081|some more easy method uh and most open
1664.24|7.12|source language model they use DPO
1667.0|9.519|method it's from paper from stord and we
1671.36|9.72|only need some PR PR reference Pairs and
1676.519|7.441|use this uh formula to update your model
1681.08|7.8|you don't need uh you don't rarely need
1683.96|7.48|a reward model you uh you don't really
1688.88|5.84|need a reward model you just need some
1691.44|4.88|pairs uh maybe this pairs should some on
1694.72|4.559|policy PS
1696.32|8.359|but yeah uh but
1699.279|7.481|it's much simp simple and also very
1704.679|7.081|powerful
1706.76|10.2|so this are basics of how to train a
1711.76|10.32|language model currently uh and uh it
1716.96|10.36|seem like it's nothing about NLP it's
1722.08|9.52|actually the the a party of mlc SK so
1727.32|10.44|what are the LM prer doing is actually
1731.6|7.24|the most important things is data the
1737.76|6.08|current
1738.84|8.24|the data cleaning filtering Sy sizing is
1743.84|6.959|the most important thing of all the
1747.08|8.0|large language model company which is a
1750.799|6.561|uh Open Secret so the training INF is
1755.08|7.599|actually
1757.36|8.799|uh B is basically what I said uh in the
1762.679|7.321|last several slides maybe there's some
1766.159|7.721|other more uh once me but the
1770.0|7.039|Improvement is maybe 20% or something
1773.88|7.08|like that but if you have a better uh a
1777.039|9.36|better pring data and the performance of
1780.96|7.839|your language model is quite uh uh quite
1786.399|7.921|obvious
1788.799|9.921|so and it's something like uh the
1794.32|8.4|language model and some are are
1798.72|7.4|told by the the media is um most one
1802.72|6.64|thing and uh but but
1806.12|7.12|actually most of
1809.36|7.84|the M Engineering in large model company
1813.24|6.2|is actually cleaning the data so is this
1817.2|7.44|something a St for graduate student
1819.44|7.52|should do maybe someone thing is very
1824.64|4.399|it's very low I want to design some new
1826.96|6.719|algorithm I
1829.039|9.281|this is rare ml research but uh I have a
1833.679|8.401|opinion that the data the algorithm and
1838.32|6.04|architecture can transform transform to
1842.08|5.959|each other
1844.36|7.199|so the the the data is most most general
1848.039|5.961|form but sometimes if you don't have
1851.559|4.36|enough computer it could
1854.0|4.44|be it could
1855.919|6.681|be very
1858.44|8.76|um hard to fed this kind of data and
1862.6|8.36|algorithm is um very hard to implement
1867.2|7.0|and not very general the
1870.96|6.839|architecture uh is hard to perform what
1874.2|8.24|you want you design new architecture
1877.799|7.921|very hard uh I I will take um a multi
1882.44|6.68|Health question answering task as an
1885.72|8.16|example the right figure is is that from
1889.12|9.0|the C is also one of my papers when I
1893.88|8.799|was a p student uh it's actually about
1898.12|8.6|uh a a a task
1902.679|7.88|to we have very complex question and we
1906.72|6.88|need to find the task the task find the
1910.559|7.6|answer from several documents but you
1913.6|7.039|need to uh you need to find the CH uh
1918.159|6.36|reasoning between different document to
1920.639|5.16|get the final answer so at that time I
1924.519|5.241|proposed a
1925.799|5.521|method invol BR and graph neuron network
1929.76|5.68|is very
1931.32|9.68|complicated um and uh finally I get I
1935.44|11.359|got a very good performance and uh 10 10
1941.0|9.96|points uh better than PR method but um
1946.799|6.081|yeah there's a uh this is actually some
1950.96|5.16|uh algorithm or
1952.88|7.759|architecture uh Innovation it's very
1956.12|9.919|fancy and get very high score uh in ACL
1960.639|9.4|review but um there's some other current
1966.039|6.281|work use MCTS M research and Bo and
1970.039|5.921|something like that it looks like
1972.32|6.52|algorithm level Innovation to solve this
1975.96|5.76|problem but currently this problem can
1978.84|7.16|be easily solved by a very long context
1981.72|8.16|GPT and chain of s reasoning if you
1986.0|7.6|include nearly all the documents into
1989.88|7.519|your context you don't need any things
1993.6|6.439|like graph neuron Network or MCTS to
1997.399|7.16|jump between to jump between the the
2000.039|8.081|documents you have all the context and
2004.559|7.681|uh you can just finish using
2008.12|7.72|sort it's a data level solution
2012.24|5.559|so the data level solution is of course
2015.84|4.76|most simple one
2017.799|5.72|because uh you you just add the data
2020.6|5.84|into your training training Corpus and
2023.519|7.961|you you can just finish this task while
2026.44|8.64|not uh affect other task so the the data
2031.48|7.919|cleaning fing sizing is not a very easy
2035.08|10.24|work and it actually very um
2039.399|7.28|important uh view to to uh important to
2045.32|5.599|do this
2046.679|7.2|is uh it should we should transform our
2050.919|7.081|view of data and algorithm architecture
2053.879|9.52|to fit the current Uh current
2058.0|9.72|air so uh yeah I have introduce some
2063.399|8.081|knowledge about um uh the the about
2067.72|7.52|language models so I will jump into the
2071.48|6.96|second part which is a re language
2075.24|7.48|models in the past one
2078.44|5.94|year so uh the past one year we have
2082.72|2.879|seen the we Lang
2084.38|7.779|[Music]
2085.599|10.08|models jump from nearly a very uh uh
2092.159|6.841|very silly one to currently very
2095.679|8.121|powerful ones so uh I will start from
2099.0|8.16|bleep to which is U actually a uh the
2103.8|5.2|maybe I think the first work to uh
2107.16|6.04|Bridge the clip
2109.0|7.96|and large language model to give the
2113.2|5.08|language model ability to understand the
2116.96|5.44|the
2118.28|7.68|images actually if we if we have a image
2122.4|8.679|encoder from clip and the large language
2125.96|6.36|model uh from anywhere so you can just
2131.079|5.881|insert
2132.32|7.64|a a transformer called Q forer to
2136.96|6.2|extract some important features from
2139.96|7.28|image encoder and uh insert these
2143.16|9.56|features into large L model to the uh
2147.24|8.32|but the space of image features and text
2152.72|5.56|featur is different so the Q form is
2155.56|3.799|trainable uh you'll need the
2158.28|6.96|lots
2159.359|9.841|of text image Pairs and align the space
2165.24|9.68|of image features and the language and
2169.2|10.08|text features the space so uh yeah yeah
2174.92|5.84|this the Q form uh is actually did this
2179.28|4.319|but there's
2180.76|8.24|a most
2183.599|9.561|simple method called laa is it
2189.0|9.119|actually actually uh don't you use a
2193.16|8.24|simple projection withd to transform the
2198.119|7.361|re encoder the feature from RE encoder
2201.4|6.76|into the features in the Lang the
2205.48|7.2|language model input
2208.16|9.32|so uh it quickly become the most popular
2212.68|4.8|architectures of your language models
2217.68|11.399|Co m is a uh a work from our group
2224.64|9.28|it the the motivation of c and is uh to
2229.079|9.161|keep all the language Behavior while um
2233.92|6.48|and we add an language uh image
2238.24|5.839|understanding ability to the language
2240.4|7.76|model uh for LA
2244.079|6.201|and uh for for for for the previous
2248.16|7.4|method
2250.28|7.92|maybe uh you can you you actually can uh
2255.56|3.759|change the language model and get a
2258.2|7.119|better
2259.319|9.401|performance but um the the uh but it's
2265.319|5.841|about multimodality task the the
2268.72|5.24|language model ability language ability
2271.16|6.36|of the model will be reduced if you
2273.96|8.8|change the language model during the tax
2277.52|8.44|image alignment so we
2282.76|7.92|first we first use a region
2285.96|9.24|exports uh to uh add new parameters in
2290.68|7.639|the backbone and uh the New Vision
2295.2|7.2|exports only deal with the image
2298.319|6.721|features and the original VDS in fit
2302.4|6.679|forward layers and the qqv Matrix deal
2305.04|5.92|with the original Tex features so so uh
2309.079|5.401|the
2310.96|7.32|original behavior of language model is
2314.48|8.08|keeped and we add lots of new parameter
2318.28|8.72|to train uh and get a better performance
2322.56|6.559|of Lang of multimodality models uh the
2327.0|4.76|CM
2329.119|5.361|achieves state of art performance of
2331.76|7.44|several benchmarks including image
2334.48|8.52|captioning grounding and recu and some
2339.2|6.399|other large model benchmarks and also
2343.0|7.48|open source so you can download it from
2345.599|8.601|our K have uh last last month I found
2350.48|7.879|that uh C is
2354.2|8.72|downloaded more than uh five
2358.359|8.24|500,000 times uh in in in the last month
2362.92|5.96|so I think it already helped lots of
2366.599|7.121|people
2368.88|8.12|and the code agent here another Works uh
2373.72|6.04|from our group is use a different
2377.0|5.72|architectures because we want high
2379.76|5.64|resolution uh with cross attention why
2382.72|6.879|is cross attention because we don't want
2385.4|6.52|to um uh we just want want a high
2389.599|7.201|resolution input and don't want to let
2391.92|6.88|all the hidden size the same as the V
2396.8|5.2|the language mod hidden size which is
2398.8|7.6|very large so we use a cross attention
2402.0|8.44|to deal with the low resolution the high
2406.4|7.84|resolution channels uh it's uh slightly
2410.44|10.639|complicated but uh the performance very
2414.24|11.2|good we can find uh this this this model
2421.079|8.24|actually trained to be a web agent and
2425.44|3.879|uh it's just take a
2430.0|10.839|screenshot as input and um it will uh
2436.359|8.641|perform different operation on the uh
2440.839|9.121|scream scream shot for example this is a
2445.0|10.079|uh example for a search uh uh the last
2449.96|7.96|year's best paper in C so uh we we ask
2455.079|7.481|the model this question they told me you
2457.92|9.76|need to uh type the best paper of cvpr
2462.56|7.559|2023 in the box at this position and uh
2467.68|6.36|step by step finally we GA the
2470.119|8.041|information and we all we can also use
2474.04|7.36|this method to uh book some tickets or
2478.16|6.52|some other perform some other task yeah
2481.4|6.88|this is Al also open resource open
2484.68|7.639|source some other uh
2488.28|5.2|popular architectures about uh we
2492.319|6.52|language
2493.48|8.28|modeling uh includes wies it's it's
2498.839|7.401|actually different VAR featur that inut
2501.76|8.12|and uh is largely improve the OCR
2506.24|5.04|performance but what I want to stress is
2509.88|6.36|uh we
2511.28|9.24|actually the most uh in our most want
2516.24|8.04|want uh re language model gm4 V we
2520.52|6.96|actually use a more simple architecture
2524.28|8.76|it's actually a small
2527.48|9.52|adaptation uh upon lava we just replace
2533.04|7.12|the uh projection weight of lava into a
2537.0|5.76|stride convolution to suppose high
2540.16|6.56|resolution input but keep the
2542.76|8.0|computation in language model using this
2546.72|7.879|architecture we can uh TR the V language
2550.76|7.52|model mixed with the text and finally we
2554.599|9.561|get a good performance we can say that
2558.28|10.48|GM 4way Can U on the part of gbt 4way or
2564.16|9.399|Germany or Cloud 3 and uh uh it's
2568.76|7.92|performed better in OCR uh do OCR
2573.559|6.161|benchmarks for example doc document qway
2576.68|5.0|and uh it's perform much better at
2579.72|6.44|Chinese
2581.68|6.2|OA this is some this is example of our
2586.16|3.439|most advanc
2587.88|5.199|grm4 uh
2589.599|10.48|model uh you can download
2593.079|10.161|the uh uh our app from this Chad gm. CN
2600.079|9.0|website uh this is actually
2603.24|10.079|a very hard to recognize draft but and
2609.079|6.24|it's it's also a mean uh the model can
2613.319|5.401|analyze it
2615.319|5.681|very accurately and can
2618.72|6.28|translate what is
2621.0|7.559|really what really right so uh yeah you
2625.0|5.4|can experience our model is totally free
2628.559|3.56|from this
2630.4|7.719|website
2632.119|8.0|okay we have some introduction about we
2638.119|6.081|understanding it's more about
2640.119|7.2|engineering but uh uh it's multi
2644.2|5.96|modality but and another half of the we
2647.319|6.361|language research about image generation
2650.16|7.84|and is also relevant to Transformers so
2653.68|7.28|I will also introduce this uh the the
2658.0|5.92|the rule about image
2660.96|7.2|generation
2663.92|7.8|yeah uh for three
2668.16|6.76|oh four years ago uh
2671.72|6.56|aluto the we already know the gbt is
2674.92|7.56|very powerful so we want to Auto
2678.28|7.799|regressively modeling the X
2682.48|9.0|Generation for uh using the
2686.079|12.04|GPT so this is a uh uh the work of C
2691.48|8.599|view uh it's also my work at 20 and uh
2698.119|8.321|222
2700.079|8.841|21 is uh it's very simple framework
2706.44|7.2|because we know that GPT can only
2708.92|8.639|predict multinomial distribution so we
2713.64|8.8|we need to find some method to train uh
2717.559|7.921|to train the image in a disc way there's
2722.44|6.879|uh maybe
2725.48|6.599|2020 uh there's paper called rgpt uh
2729.319|8.561|from openi it's trained directly on the
2732.079|7.48|pixel level uh for all modeling
2737.88|5.36|but the
2739.559|5.04|sequence is very long so you cannot
2743.24|6.72|train a
2744.599|8.72|very uh high resolution images so we can
2749.96|8.48|train first train image tokenizer it's
2753.319|9.52|actually a we way uh to
2758.44|8.119|dis discs your image into uh several
2762.839|8.641|tokens and you Pro prepare the
2766.559|10.161|sequence of a text image as the for text
2771.48|8.96|for image later and you can use gbt
2776.72|6.28|to train this kind of sequence and
2780.44|6.879|finally during the inference you first
2783.0|7.079|inut the in the tax and then uh predict
2787.319|5.841|token by token in the image token in the
2790.079|7.24|image you can generate some uh image
2793.16|8.04|yeah this is a a very simple idea and uh
2797.319|7.921|a concar work called D and the most
2801.2|6.6|powerful work called party is from the
2805.24|5.0|the same idea
2807.8|6.68|okay but
2810.24|10.48|um yeah yeah we know that we can in we
2814.48|10.599|can generate image you in GPT so a very
2820.72|9.24|natural idea is can we achieve some
2825.079|8.601|Universal modeling for re language tasks
2829.96|8.92|so if if we just tokenize the
2833.68|9.0|image just like the text we can generate
2838.88|7.679|image we can uh generate text from the
2842.68|7.0|image we can generate image from text
2846.559|9.601|and only generate Tex so this is a very
2849.68|9.679|neutal idea and um I also did this in C
2856.16|6.199|to maybe two years ago
2859.359|6.2|and yeah the
2862.359|7.161|the the algorithm also very simple it's
2865.559|9.28|just uh you you in in the sequence you
2869.52|8.4|change different position or uh text and
2874.839|6.441|image sequence if for first Tex then
2877.92|7.28|image and you mask all the SC is T image
2881.28|8.079|generation if first image then Tex it's
2885.2|10.44|image captioning and you can also guess
2889.359|9.48|other uh other um format like mask Auto
2895.64|4.64|encoder or something like that but the
2898.839|6.201|problem is
2900.28|7.12|um when you compare this um Universal
2905.04|5.96|modeling system to
2907.4|7.12|diffusion of re language modeling re
2911.0|6.44|language model you will find the image
2914.52|6.76|generation it's it worse than the
2917.44|5.48|diffusion and the very slow compared to
2921.28|5.279|diffusion
2922.92|7.0|for uh image understanding is perform
2926.559|7.921|worse than with language model because
2929.92|7.679|when your uh image uh is uh when you
2934.48|8.2|when you transform your image into
2937.599|10.2|uh dis disir tokens lot of information
2942.68|8.56|is lost during this process so the
2947.799|5.52|performance is worse than the V language
2951.24|6.48|model
2953.319|8.321|so using this method you can achieve
2957.72|6.2|Universal modeling but the you you just
2961.64|6.28|achieve Universal modeling and you
2963.92|8.84|cannot achieve the best performance
2967.92|10.28|on uh any task and
2972.76|8.48|so uh the diffusion method actually wins
2978.2|6.76|the game or image generation and not
2981.24|8.599|Auto agressive alth the in in the NP
2984.96|8.56|doain the auto method is dominant but in
2989.839|7.121|image generation the vendor is diffusion
2993.52|5.079|so what is diffusion uh diffusion
2996.96|4.72|actually
2998.599|6.2|another is a totally different
3001.68|7.32|self-supervised learning method uh
3004.799|8.401|compared to autoagressive meth it's uh
3009.0|8.0|you can also think it's a autoregressive
3013.2|5.84|on for doy or something like that so but
3017.0|6.88|but
3019.04|7.84|actually it's the ddpm is the
3023.88|6.439|original uh paper of diffusion model is
3026.88|8.64|still the most popular framework of
3030.319|9.321|diffusion modeling we can uh Define lot
3035.52|9.48|of steps is we gradually adding noise to
3039.64|9.959|a clean image and uh we get different
3045.0|9.48|inter medient state and the train model
3049.599|8.921|to predict the noise the original image
3054.48|8.359|or something like v as a velocity of the
3058.52|5.799|of the angle is of the log actually
3062.839|5.081|given the noise
3064.319|8.601|important noisy noisy image
3067.92|8.919|so uh it's it's totally different but um
3072.92|7.399|uh the the the mo the most advantage of
3076.839|7.441|diffusion model or autoing model is that
3080.319|3.961|during sampling
3085.16|9.399|we during sampling we
3089.16|9.959|can uh during sampling we can use four
3094.559|7.8|utility or gpus because in our
3099.119|8.521|regressive model when we decode a token
3102.359|8.601|we uh actually ER the power of the GPU
3107.64|5.84|uh it is the utility of GPU is very low
3110.96|6.879|if the batch size is small batch size
3113.48|8.52|equal to one but um for diffusion model
3117.839|6.921|we just input all the image into the in
3122.0|4.68|in into the model so it can utilize the
3124.76|4.48|GPU
3126.68|6.48|and it can sampling much faster than
3129.24|3.92|aive model
3133.559|9.481|OKAY the Rel diffusion model is the Rel
3138.319|8.881|diffusion model is our recent work about
3143.04|7.72|uh is solve the problem in
3147.2|6.44|diffusion uh about the no schedule
3150.76|7.12|across different
3153.64|9.64|resolution the first is
3157.88|10.679|uh you can you can see the left image is
3163.28|9.4|is actually three uh three images with
3168.559|7.601|the same noise the a the A and B are two
3172.68|7.439|images with different resolution and
3176.16|5.159|with the same noise level but the a is
3180.119|5.561|actually more
3181.319|8.28|blurred for uh for us during the
3185.68|6.96|observation the problem is um we add a
3189.599|4.161|independent no and
3192.64|5.479|[Music]
3193.76|6.559|uh then and and and the actually
3198.119|5.921|the original
3200.319|7.401|signal the image not independent across
3204.04|8.0|the space so
3207.72|4.32|what what what we need to do is
3213.72|7.68|U is a uh if we want to uh transform a
3219.4|5.159|noise schedule from low resolution to
3221.4|6.6|high resolution we need to use a block
3224.559|6.081|noise to
3228.0|6.2|uh find the
3230.64|6.32|equivalence on the high resolution
3234.2|6.48|images and finally we can
3236.96|8.76|keep the S
3240.68|11.119|SN in the frequency graph the same
3245.72|9.639|so uh we uh uh using this method we can
3251.799|8.0|disentangle the noisy schedule and the
3255.359|6.801|actually uh Network we use for diffusion
3259.799|7.121|use a noise schedule we don't care about
3262.16|7.48|the resolution we just uh you a block
3266.92|6.0|noise when we want to uh continue
3269.64|4.64|diffusion on high resolution so the the
3272.92|3.199|speed
3274.28|5.24|can uh
3276.119|7.2|improved uh because we don't need to uh
3279.52|6.559|reimage generate the image from the high
3283.319|4.441|resolution from the high condition on
3286.079|6.0|the low resolution
3287.76|7.319|image high resolution F
3292.079|7.881|okay and we also scale up the Rel
3295.079|9.081|diffusion to C after this uh after the
3299.96|7.76|the paper yeah uh the cob 3 is actually
3304.16|7.24|a large diffusion model and um after
3307.72|8.68|disolution it could be very fast because
3311.4|7.8|of the uh effect effectiveness of the
3316.4|6.52|Rel diffus
3319.2|8.399|okay uh finally we guess we get
3322.92|8.76|something relevant to our topic
3327.599|7.601|Transformer and actually the previous
3331.68|8.0|Works about diffusion is on
3335.2|8.159|units and uh using Transformer is not
3339.68|9.08|trivial in the in diffusion uh the first
3343.359|8.281|work I think maybe uh is is solid enough
3348.76|6.88|is dit from
3351.64|5.64|meta uh the author of this paper is also
3355.64|5.56|the author
3357.28|5.72|so the the most important most
3361.2|3.48|difference between the original
3363.0|7.24|Transformer and
3364.68|11.96|this D is the ad
3370.24|10.4|lome ome is predict uh scale and bias
3376.64|7.04|for uh different lay know uh scale and
3380.64|6.6|shift for different condition on the
3383.68|7.6|time step it's actually needs a very
3387.24|6.04|huge amount parameters is six times of
3391.28|7.88|hidden hidden
3393.28|11.079|size nearly equals to A QQ uh W per
3399.16|8.879|layer but the the input is only one in
3404.359|7.121|one in is actually very strange because
3408.039|7.881|the input is only one in and you need a
3411.48|7.28|millions of parameter to transform it so
3415.92|4.119|uh there some method can reduce this
3418.76|4.72|steam in
3420.039|9.121|our pra
3423.48|8.44|practice uh the St diffusion 3 released
3429.16|4.32|recently use another architectures
3431.92|5.0|called
3433.48|7.119|MMD the St Defence three for use our
3436.92|7.04|released C to caption of the model other
3440.599|5.121|images and train L diffusion model using
3443.96|4.48|this new architecture the new
3445.72|6.72|architecture seem like very complicated
3448.44|8.56|but uh the the most important thing
3452.44|8.919|is um they use vision and TX exports
3457.0|7.48|like hm instead of cross attention uh to
3461.359|6.881|T5 features like the previous
3464.48|6.48|ones so finally we will talk talk
3468.24|9.52|shortly about radio generation because
3470.96|12.2|Sor is uh currently very uh popular
3477.76|8.599|uh we publish uh we do generation work
3483.16|7.28|several years ago in and fin is
3486.359|6.401|published on AAR so it's it's maybe the
3490.44|3.96|first open S language model for test
3492.76|6.039|video generation but the performance
3494.4|6.639|much worse than the current Sora uh
3498.799|5.8|because it's autoaggressive so using
3501.039|7.121|diffusion we can get better we currently
3504.599|5.52|also working for uh replication of Sor
3508.16|8.28|like models and
3510.119|9.321|our we we can summary that the the most
3516.44|7.359|the the Improvement of Sora come from
3519.44|8.48|this aspect the for is there no faking
3523.799|5.481|in the videos and it's it can generate
3527.92|6.0|high quality
3529.28|8.92|images the first one Tod fleing can be
3533.92|7.72|solved by the 3D latent 3D latent
3538.2|6.919|encoder decoder and uh if you train a
3541.64|4.719|diffusion decoder it could be better uh
3545.119|6.0|the high
3546.359|8.601|quality is s should s to the the scaling
3551.119|9.0|up and um it requires a very high
3554.96|8.2|resolution and uh this is something
3560.119|7.0|related to the long contact Banking and
3563.16|6.919|the Contex parallel techniques in uh the
3567.119|5.121|language model infra which I
3570.079|7.24|introduced at the beginning of this
3572.24|9.4|course so um you the most important
3577.319|7.24|thing is they use the infra the you use
3581.64|7.04|infra in language model training into
3584.559|8.76|the diffusion and uh make
3588.68|9.56|it make it very easy to scale up and uh
3593.319|7.961|scale up much much uh larger than the
3598.24|5.799|other other companies yeah and finally
3601.28|5.519|the most important thing is data
3604.039|6.441|coverage it need a very heav DET
3606.799|3.681|engineering and the video
3612.0|4.359|recaption
3614.52|6.0|okay
3616.359|8.121|so this I have uh introduced many topics
3620.52|7.76|our current multi modality print tring
3624.48|7.72|and uh some problem in the the this
3628.28|9.279|Transformer community so there are some
3632.2|8.919|trads I think will happen in one or few
3637.559|9.441|years in the multi modality
3641.119|7.761|area in the next one or two years we can
3647.0|5.76|easily
3648.88|8.88|recognize uh grounding all the common s
3652.76|9.0|attributes and human is is persons and
3657.76|6.799|other lots of high level Vision scenes
3661.76|4.559|and all these scenes will be very sheap
3664.559|3.841|and be basically
3666.319|5.601|sold
3668.4|8.679|so this this will happen in one or two
3671.92|9.56|years at that time the long tile problem
3677.079|9.321|of Auto auto driving could be a littleit
3681.48|10.0|not not so but largely a littleit and um
3686.4|7.52|the second prediction is the the video
3691.48|6.68|understanding will become very important
3693.92|5.439|in the next one or two years because
3698.16|6.0|it's very
3699.359|9.2|useful we uh we have lots of video in
3704.16|8.199|the internet and uh in our everyday life
3708.559|7.0|but it's very hard and currently we
3712.359|5.44|cannot understand video well and the
3715.559|3.641|most powerful video understanding model
3717.799|7.32|currently is
3719.2|9.399|Germany 1.5 but it's it's basically uh
3725.119|7.16|lots of hallucinations and uh wrong
3728.599|8.72|counting and lots of weakness
3732.279|10.04|so there's a very large room to
3737.319|8.361|improve uh another thing is we have
3742.319|4.401|enough compute to deal with the video
3745.68|4.8|now
3746.72|7.399|and especially in the next one or two
3750.48|7.28|years because the uh Next Generation or
3754.119|3.641|media GPU
3758.119|4.641|and the requirements from the larg
3760.799|5.081|language
3762.76|6.559|model uh and another important thing is
3765.88|7.64|inod ai inod ai will be more and more
3769.319|9.081|important in the research and it will be
3773.52|9.48|um very closely related to multimodality
3778.4|9.84|research although it cannot uh impact
3783.0|8.839|our real life in a few years because we
3788.24|6.079|now have planning ability with L Lang
3791.839|6.28|models we can recognize all the things
3794.319|10.28|Lang models and there there will be some
3798.119|11.041|chances to get some new ability and and
3804.599|6.841|very very very astonishing demo of this
3809.16|4.48|uh this embod AI
3811.44|5.919|but the
3813.64|7.8|the they may be they very expensive and
3817.359|8.92|cannot be used for everyday life
3821.44|7.599|so what should we do uh at that time at
3826.279|6.04|that's that and
3829.039|7.28|for me some some researcher like me in a
3832.319|10.04|large langage model company we got
3836.319|9.201|enough Computer Resources but for others
3842.359|5.2|so I think if you are a senior
3845.52|6.44|researcher so just follow your heart
3847.559|9.28|time ignore me uh if you want to quickly
3851.96|7.56|get some um sations papers
3856.839|4.96|impact I think maybe you can consider
3859.52|6.279|that the the the video understanding
3861.799|5.921|models data sets benchmarks especially
3865.799|4.76|data set and benchmarks is very
3867.72|4.52|important and uh in great need of the
3870.559|5.72|video understanding
3872.24|7.799|Community yeah and for motive modality
3876.279|8.641|and there's another topic I haven't uh
3880.039|9.32|talk talked about in this lecture is uh
3884.92|7.56|is a speech or audio um I
3889.359|6.841|recently uh learn some knowledge about
3892.48|9.24|audio and I lead the group of of
3896.2|8.399|speech AI group in J AI so um I'm I'm
3901.72|6.48|not a researcher about audio but I can
3904.599|5.641|say that the speech AI is
3908.2|6.159|underestimated it's
3910.24|7.72|actually very important for uh the user
3914.359|7.041|need and application but there's no
3917.96|6.359|enough GPU and research researchers put
3921.4|4.76|into this areas like in language
3924.319|4.201|model yeah
3926.16|4.0|finally if you want do some very useful
3928.52|6.2|and impact a
3930.16|7.959|research which is very risky you uh
3934.72|6.24|advice is you need to make some system
3938.119|4.44|PhD student Advance
3940.96|7.0|because
3942.559|7.441|the the best algorithm and must utilize
3947.96|6.56|the current the
3950.0|9.319|current uh GPU and other Hardware yeah
3954.52|7.88|so you just need to know some system PhD
3959.319|7.401|students and
3962.4|8.76|there and there should be another is
3966.72|6.839|more uh difficult but influential is
3971.16|5.879|there's actually some room for new
3973.559|5.881|architectures for self super
3977.039|5.841|self-supervised learning and optimizers
3979.44|7.399|because the next generation of Hardware
3982.88|8.08|will be totally different so uh maybe
3986.839|6.321|the Transformer will be uh have some
3990.96|5.04|competitors and
3993.16|5.439|the AL also the auto regressive modeling
3996.0|5.88|method so there's some room but it's
3998.599|6.601|very hard and need some computational
4001.88|5.52|resourcing uh and finally the new ways
4005.2|6.04|to transform campu to high quality data
4007.4|8.199|is very important because the web data
4011.24|10.559|is the high quality web data is actually
4015.599|8.801|be Crow down um uh into uh almost every
4021.799|6.121|large language model company and it's
4024.4|6.32|currently not very enough so we need to
4027.92|5.679|find some new ways to transform Compu to
4030.72|7.16|high quality data for example how to how
4033.599|9.081|to S sizing the new data using Code
4037.88|7.28|execution result using uh maybe
4042.68|8.56|MCTS reinforcement learning or some
4045.16|9.399|other Master this very big area and uh
4051.24|8.319|in in the next few years yeah I think I
4054.559|9.601|will end this lecture here and thank you
4059.559|6.881|for the instructors and audience and
4064.16|6.48|thank you very much if you have some
4066.44|7.679|question you can send email to this and
4070.64|6.8|I will uh answer all the question thank
4074.119|3.321|you very much
4080.2|3.96|yeah thank you very much M for the
4081.559|5.641|amazing talk and all the useful advice
4084.16|5.6|um so we have some questions um I got
4087.2|6.56|one through zoom and there's several
4089.76|5.71|also on slido so um Emily are there any
4093.76|4.78|in-person questions from your
4095.47|3.07|[Music]
4098.92|7.279|end okay if you if someone has some
4102.159|7.881|question and you can type in the in the
4106.199|8.201|chatting in in zoom zoom if you you are
4110.04|4.36|using Zoom U let me
4114.92|6.72|see okay yeah here are some questions on
4117.64|6.32|slido that I'll ask um the first is that
4121.64|6.119|the success of long context Windows must
4123.96|8.53|come at a cost what what is this
4127.759|6.0|cost the cost is a because is a very
4132.49|4.11|[Music]
4133.759|7.96|long the time com conception you just
4136.6|8.0|need to run your run your uh inference
4141.719|6.361|engine for a very long time actually the
4144.6|7.96|current inference system of large
4148.08|8.48|language model can be uh uh split into
4152.56|8.08|two period one is profilling you need to
4156.56|8.56|uh UT a very long contacts into your
4160.64|9.88|engine and the another is decode and you
4165.12|8.32|you generates the token by token so uh
4170.52|5.88|most user case they actually not
4173.44|5.16|generate a very long contest not
4176.4|4.48|understand a long contest and generate a
4178.6|5.84|very few uh
4180.88|7.799|tokens about the question
4184.44|6.759|so we can uh bear
4188.679|8.441|maybe uh one
4191.199|9.761|minutes uh to uh left the language model
4197.12|7.0|to uh just round the long context
4200.96|5.64|understanding and then begin to uh
4204.12|6.88|answer your question so this is a course
4206.6|9.119|you need to uh wait for maybe several
4211.0|4.719|several seconds or one minute
4217.04|4.28|yes right oops I was muted but yes
4219.44|4.4|thanks that makes sense um so there's
4221.32|4.52|two questions which are pretty similar
4223.84|5.0|all uploaded on slido
4225.84|4.56|um talking about the quality of data so
4228.84|3.2|recently folks have been saying that the
4230.4|3.759|quality of data is what really
4232.04|5.48|determines final model performance
4234.159|5.681|compared to anything else do you agree
4237.52|4.28|and related to this do you think there's
4239.84|4.48|still a lot of work to do around
4241.8|5.28|improving the architecture of models or
4244.32|6.96|has attention shifted to focus on
4247.08|7.52|data yeah yeah I think I think this very
4251.28|6.56|reason actually what what the the whole
4254.6|5.079|community is doing is to improve the
4257.84|6.24|data
4259.679|8.0|uh I just talk talk about this opinion
4264.08|7.76|in in the lecture is the architecture
4267.679|6.48|the algorithm the data can transform to
4271.84|4.319|each other if you have some idea you can
4274.159|4.841|inject the inductive bias into
4276.159|5.401|architecture you can design a new
4279.0|7.28|algorithm and you can
4281.56|11.0|Pro prepare some data to tell your model
4286.28|9.8|to act like that so many of the the very
4292.56|6.72|uh special cases you can you can you can
4296.08|6.599|use data to solve the problem so the
4299.28|8.52|high quality data is more important the
4302.679|10.121|architecture of this to for many tasks
4307.8|9.439|button I think if you can find a find a
4312.8|8.919|a general update of Transformer is very
4317.239|7.721|valuable if just increase the power of
4321.719|6.0|the model to Feit in the the data is
4324.96|6.759|very very valuable
4327.719|5.92|yeah right great um here's a question um
4331.719|5.96|why is auto regressive architecture
4333.639|4.04|inferior to diffusion in image
4337.719|2.44|generation
4338.82|4.859|[Music]
4340.159|5.641|uh uh yeah yeah the it's very
4343.679|4.841|complicated this this this question is
4345.8|7.0|very complicated actually so the
4348.52|7.84|diffusion is has has is is totally
4352.8|6.48|different in Auto regressive to some
4356.36|6.44|extent but the most important thing I
4359.28|6.399|have talk about in the in the lecture is
4362.8|6.52|a the speed of generation for auto
4365.679|7.161|regressive model if you use a very large
4369.32|6.6|model you train it for a very long time
4372.84|6.24|I I believe we can get
4375.92|6.12|very good result we can also generate
4379.08|8.0|high quality images using Auto
4382.04|6.8|regressive Ms this is this is okay but
4387.08|4.4|the time to
4388.84|5.2|generate an image is very very long
4391.48|6.4|because we need to predict the token by
4394.04|7.08|token maybe a high resolution
4397.88|4.48|image maybe thousands of thousand of
4401.12|5.4|tokens
4402.36|8.92|is but but for diffusion we use several
4406.52|7.719|steps of um Fe forwarding all the all
4411.28|6.48|the image we need we don't need to token
4414.239|6.841|by token prediction it's it will be
4417.76|5.8|thousands times faster than Auto resum
4421.08|6.96|model if you are generating a high
4423.56|7.639|resolution images so this is a very uh
4428.04|5.599|obvious advantage and for for the
4431.199|5.04|modeling power I think the most
4433.639|3.881|important thing is the
4436.239|2.881|maybe
4437.52|5.56|some
4439.12|7.32|uh some relation between the
4443.08|8.639|the space is actually
4446.44|10.799|not well not uh modeling well by Al
4451.719|11.601|model because the left most pixel and
4457.239|9.841|the right bottom pixel it's very far in
4463.32|7.319|Auto regressive model but but uh uh in
4467.08|5.76|in diffusion model is actually we can we
4470.639|4.921|can see each other so it's not a problem
4472.84|6.64|but for ring model is have position
4475.56|8.119|problem so it's it's it's not easy
4479.48|8.64|to uh modeling a very
4483.679|9.881|complicated 2D special problems this is
4488.12|7.48|also a a possible reason but I cannot
4493.56|5.48|give a very
4495.6|6.92|uh very uh good answer about this
4499.04|7.0|question but yeah yeah yeah this should
4502.52|6.48|be more research about that yeah thank
4506.04|5.24|you right great thanks for that detailed
4509.0|4.239|answer um so someone is asking how is
4511.28|3.84|the Cog agent model different from the
4513.239|6.201|Cog vlm
4515.12|6.96|model oh yeah uh the Cog agent model is
4519.44|7.96|actually fine tuned from the C model but
4522.08|10.4|the C model they always high resolution
4527.4|9.44|and and web scream cases because our
4532.48|6.52|motivation is that the uh high
4536.84|4.839|resolution input for web page is very
4539.0|7.0|important because there's many words
4541.679|7.641|many icons something very small and you
4546.0|8.48|need to um use a very high resolution
4549.32|6.24|model to deal with it but um if you just
4554.48|7.92|extend
4555.56|10.04|the the input resolution of CM the the
4562.4|7.279|conception is very high so we need we
4565.6|9.119|use a cross tension modu uh adding to
4569.679|9.441|the C to get C agent so this module is a
4574.719|7.92|much lightweight so we can uh deal with
4579.12|7.32|the high resolution more easy
4582.639|6.0|yeah great um here's a question about
4586.44|4.239|video how do you think video
4588.639|4.56|understanding will Aid ai's ability to
4590.679|3.761|have a stronger physical understanding
4593.199|4.401|of the
4594.44|7.92|world okay okay that's a a very good
4597.6|10.2|question I think yes I my answer is yes
4602.36|11.24|but um it's uh actually a
4607.8|9.879|BAL uh problem is because if you don't
4613.6|9.72|have some dat Source Which con the
4617.679|10.881|physical physical uh rules you cannot TR
4623.32|7.839|a good uh video understanding model you
4628.56|4.4|I I think using the current real
4631.159|7.201|language model print Training Method
4632.96|9.0|because we need the input the text image
4638.36|8.76|or text video pairs to train and we did
4641.96|9.199|we actually did not use any s supervised
4647.12|8.24|learning uh in the image or video so we
4651.159|5.48|cannot learn any knowledge from P video
4655.36|2.96|or
4656.639|4.321|image we
4658.32|5.879|[Music]
4660.96|7.08|actually we actually deal dealing with
4664.199|4.801|the unnoted data from Human Side so if
4668.04|4.32|you want
4669.0|7.679|to understanding understand better of
4672.36|8.879|the physical words using an noted videos
4676.679|6.601|we need to uh find some new uh method
4681.239|5.841|for self-supervised learning or PR
4683.28|5.64|Training Method yeah this is a very good
4687.08|4.0|a very good question this is a very good
4688.92|5.319|question thank
4691.08|7.88|you right okay a couple more questions
4694.239|6.601|um someone is asking are there vqa tasks
4698.96|5.4|that involve multiple terms of
4700.84|7.52|conversation in a tree structure similar
4704.36|8.64|to a tree of thoughts or beam search
4708.36|9.68|style okay okay yeah
4713.0|8.719|yeah maybe but uh I I still think it's
4718.04|7.0|different and the three three Source V
4721.719|7.241|could be better because it
4725.04|7.84|can uh is a rare of other Mass
4728.96|6.56|information for example the uh the wrong
4732.88|7.24|pass the other
4735.52|10.679|fa fa fail case something like that so
4740.12|9.96|uh um my experence is uh if you you can
4746.199|7.881|include all the contacts in your
4750.08|8.36|input um you you always get better
4754.08|9.32|results so yeah
4758.44|9.279|maybe either tree of s or some other
4763.4|6.48|different process process uh process
4767.719|5.761|procedure and some other informations
4769.88|6.12|you just included them into the content
4773.48|4.84|uh the language model will learn to how
4776.0|5.0|to deal with them and understand better
4778.32|6.359|than the beam search which is actually a
4781.0|6.32|hard code me to compare the top
4784.679|6.881|probabilities uh it should be better if
4787.32|5.8|you if you uh do it right yes right
4791.56|3.52|thanks that's all all the time we have
4793.12|4.119|your questions so thanks again to for
4795.08|5.48|the great talk the detailed answers to
4797.239|3.321|all the questions