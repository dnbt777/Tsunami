start_time|end_time|text
0.52|3.92| All right, let me now show you how we can implement residual
4.44|4.64| networks in pytorch. So I will show you two notebooks. First is
9.12|3.68| a naive implementation I have made myself. And then I will
12.8|4.08| show you a more sophisticated implementation of resonant 34
16.88|4.16| from the pytorch community. So in this first notebook, now I
21.04|3.56| will show you what we talked about in the last video, these
24.6|4.6| two different types of residual blocks. And then in the next
29.2|4.08| notebook, I will show you this residual network with 34 layers.
33.68|3.6| So yeah, I'm not going to rerun this notebook, it didn't take
37.28|5.44| too long. But yeah, why waiting if, if it's not necessary. So
42.72|5.84| we'll show you just the results. So um, yeah, here, it's just a
48.56|5.8| boilerplate, importing torch and numpy, the usual stuff for the
54.36|3.04| data set. So I'm not using the helper functions here, because
57.4|4.92| yeah, it's really just very simple. So I didn't really focus
62.32|5.08| on abstracting things, I just coded the residual blocks. And
67.6|4.56| this is a self contained notebook in that way. So here,
72.2|3.16| I'm using the MNIST data set just for simplicity, because I
75.36|3.04| just wanted to have a data set doesn't really matter which one,
78.56|2.62| because this is not going to be a good convolution network. It's
81.18|3.7| just like more of a proof of concept how the residual block
84.88|3.76| works. So the data set really doesn't matter that much here.
89.12|4.84| So here, I'm implementing now this residual block, the one
93.96|5.12| where the input has the same dimension as here, the output
99.08|6.76| from the residual part. So how does it look like? So this one,
106.08|4.48| so I implemented it using the torch module class, just a
110.56|4.36| regular confinet that I'm implementing here, I have a
114.92|4.12| confinet with two residual blocks. And each of those is one
119.04|4.2| residual block. So you can see that this convolution here
123.24|3.56| represents this one. So here, I'm starting with one channel for
126.8|6.84| output channels. Then I have batch norm. Then I have relu. By
133.64|3.16| the way, I haven't really explained what that one one
136.8|3.32| means. I think I have used that before in some other code. So in
140.12|5.4| place equals true. This just means that pytorch doesn't have
145.52|5.04| to make a copy of that array internally. So we could do
150.56|3.52| something like that. I mean, not here inside, but in general, we
154.08|1.0| could do something like
160.68|5.16| like this. Just let's write it like this. So this will create a
165.84|6.52| new a new tensor x and then overwrite this tensor x. So it's
172.52|3.96| essentially overwriting this tensor x. But for a brief moment
176.48|4.0| in time, when this gets executed, there are two arrays of
180.48|4.32| this is an existing ones, if I have some previous computation
184.8|4.76| here. So this previous computation created x. And then
189.56|4.08| when I'm calling this, it will take an x and create a new
193.64|3.8| version while x is still in memory. So for a brief moment in
197.44|3.96| time, I have two arrays in memory, it's not a big deal at
201.4|3.48| all. But you have to I mean, under the hood, allocate memory
204.88|2.8| and the GPU and stuff like that. So it's kind of a little bit
207.68|4.62| more expensive to do that compared to doing an in place
212.32|3.04| operation. And in place operation is essentially
216.12|3.8| modifying something in place without creating a new array. So
219.92|2.6| it's slightly more efficient. It's not always possible to do
222.52|3.4| that. But yeah, if you can do that, it's actually nice. So
225.92|2.96| it's essentially the difference between, let's say, writing
228.88|3.84| this and x plus equals one, in that sense, you are directly
232.72|4.56| modifying something, whereas here you are having creating a
237.28|4.0| copy and then assigning the copy to it. Anyways, it's a little
241.28|3.74| tangent, the results are exactly the same, whether you do this or
245.02|2.46| this. And in practice, you probably won't notice any
247.48|3.48| difference anyway. So it does not really matter. But yeah, why
250.96|3.96| not doing it? All right, so small tangent. So we have
254.92|3.96| convolution, batch norm, and then this relu, this is this
258.88|3.36| part is really the first three. And then we have another
262.24|3.12| convolution and a batch norm, which is this part, notice that
265.36|3.92| I'm going from one to four, and then back from four to one seems
269.28|2.88| kind of weird. But why am I doing that? Yeah, it's really
272.16|3.0| like to match the dimensions. Otherwise, I will have more
275.16|3.36| channels here than I have as an input. So I would have four
278.52|3.24| channels here, and then one input channel. And that doesn't
281.8|2.28| really work if we add them, because then it's not an
284.08|4.48| identity anymore. Okay. Yeah. And we also have one fully
288.56|5.12| connected layer. This is just to make this classifier. So yes, I
293.68|5.12| am implementing this. So here, I was just defining or initializing
298.8|4.0| these layers, the blocks, and he I'm calling them. So in the
302.8|5.36| forward pass is really where things happen. So I save x as
308.16|6.04| the shortcut here. So I'm saving this here, then I'm calling my
314.2|6.16| block. So this part I highlighted here, this is really calling
320.72|8.84| this whole block, right. So it's this whole block. And actually,
329.56|3.68| I could have these are kind of redundant, I could have used the
333.24|2.92| same. Okay. But then, of course, the weights are different.
336.16|4.32| Anyway, sorry. So I call my block here. And then I have my
340.48|3.88| relu function. And the relu function is applied to x plus
344.36|5.52| the shortcut. So this part really is this part. So I'm I'm
349.88|2.88| adding inside and then I'm applying the relu. So the relu
353.12|3.24| that is what is shown here. And here I have this addition,
356.92|3.2| right. So this is essentially one residual block. And then I'm
360.16|3.88| repeating it. So why am I not using one here? Well, then it
364.04|4.28| would be the same layer, it's that wouldn't work really. Okay.
370.8|3.24| But the shape is the same, it's just we have different weights,
374.04|4.48| right. So it's just like having two convolution layers after
378.52|4.4| each other. And then we have this linear here, which is
382.92|12.4| turning this into a classifier. Alright, so so the linear layer
395.32|4.72| has output the num classes. And here I'm just flattening it. So
400.04|6.52| I'm assuming what comes out of this block two has a
406.56|7.64| dimensionality 28 times 28 is 784. Yeah, and then I'm running
414.2|3.04| this, I'm just pasting my convenience functions that I
417.24|2.48| usually have in my helper function, it's a slightly
419.72|2.6| simpler version, because I'm not plotting anything, I just want to
422.32|3.04| show you that this actually runs doesn't get great performance,
425.36|4.96| because of course, it's a very naive implementation is also
430.32|4.06| only the training accuracy, the test accuracy is 92%. So what I
434.38|3.06| show what I mean is, how do I know that this is the actual
437.44|2.76| number? I mean, I can think about it, I can look at this.
440.44|2.24| But like I explained in the previous video, what I can also
442.68|6.08| do is what most people do is just print x dot size, then you
448.76|10.8| can oops, run everything here. Then can run the training and
459.56|2.12| then you will see the size. Of course, you don't want to
461.68|2.4| complete it, because it's annoying to have it here. So I
464.08|4.44| just stopped it, I can see all it's 128 times 28. And that is
468.64|5.64| what I can then copy and paste and then go here and put it in
474.6|5.24| here. Right. So that's where this number comes from. And it
479.84|8.24| is also where this number comes from. Okay. In practice, if you
488.08|3.44| don't want to think about it too hard, and you are debugging
491.52|3.2| things, I mean, it doesn't hurt to insert a print statement.
494.72|5.84| That's what everyone is doing. Okay. Um, so we trained that.
500.76|4.5| No, of course, I interrupted it. But suppose it trained, I mean,
505.26|4.46| it trained before. So if I fix it, it would train. Now, the
509.72|4.68| second part, now focusing on the more interesting part where we
514.4|4.24| have this resizing here. So I'm implementing this a little bit
518.64|5.08| differently now using a reusable unit, I call that a residual
523.72|4.2| block. So I'm implementing my residual block here. And this
527.92|6.2| one is implemented the same way. Now, it's a little bit more
534.12|3.44| general, I have something called channels here, this is the input
537.56|3.24| channels, or let's say the first number of channels, the output
540.8|4.48| channels. And then here, I have one and two. So I am going from
545.28|6.92| zero to 12. And I can, I mean, I'm not defining what these
552.2|2.64| numbers are, I'm defining them later when I'm calling this, I
554.84|3.32| can maybe briefly skip ahead. So I'm using this residual block,
558.4|2.28| actually, in my convolutional network here. So I'm using it
560.68|2.8| here. And here, I'm defining the channels, I'm going from one to
563.48|3.84| four to eight. So
569.56|2.52| yes, so that's what I'm doing here. So I'm going from zero,
572.08|5.96| so one to four, sorry, one to four to eight. And then I have
578.04|3.88| my shortcut, which goes also from zero, sorry, from one to
581.92|3.92| eight. Otherwise, I wouldn't be able to edit because if let's
585.84|4.84| say this is one channel, outcomes, eight channels, then
590.68|2.24| this also has to be eight channels. Otherwise, I can't
592.92|8.2| edit. So that's what's going on there. So my residual block
601.12|3.64| is growing up again. So we can see everything. So my residual
604.76|3.92| block 123. This is really on this part, these three first
608.68|3.08| blocks. And then like before, the second blocks are this and
611.76|3.96| this. Now, the difference is that I have different numbers of
615.72|4.24| channels. And I can also reduce the size, right. So yeah, I
619.96|5.16| have a stride of two. So that will reduce the size, I have to
625.12|4.24| do a stride of two here to to match these dimensions. So yeah,
629.36|2.6| I have to be a little bit more careful that the dimensions
631.96|5.52| match also. Yeah, and then as before, I have my block, I have
637.48|4.12| a shortcut, and both the block plus shortcut, they go into my
641.6|3.0| relu function. So this is what I'm showing you here, this
644.6|4.8| residual block is really this whole thing here. Yeah, and then
649.4|3.96| I'm using my residual block, I'm initializing one residual block
653.56|2.96| into another. So I have a network with two residual blocks,
656.52|2.92| the first one goes from one to eight, and the second one from
659.44|5.12| eight to 32. And the number of the size is here seven times
664.56|3.84| seven times 32. So it's because we are also having the
668.4|5.84| dimensions here, half and half approximately. So going from 28
674.24|5.24| times 28 to 14 times 14, and from 14 times 14 to seven times
679.52|6.76| seven. Yeah, this is essentially it. So that's how we implement
686.28|7.68| this. So yeah, then we are training it trains here, and it
694.16|3.96| performs much better than our previous implementation. But
698.12|4.36| again, the goal of residual networks is really to go deep in
702.48|2.44| the network in terms of the number of layers. So here, we
704.92|2.96| only have two layers. So I mean, this is probably not a great
707.88|3.68| network to use for other data sets. Here, we are just using
711.56|3.56| MNIST. So if we want to use a more, I would say sophisticated
715.12|3.0| data set, I'm actually only using cipher 10, because it's
718.16|2.64| simple to lot. But if you want to use a different data set,
721.24|3.8| ResNet 34 is a good choice. So this is the one, the deep one
725.04|3.36| here, it performs pretty well going back here, it gets
728.44|3.72| actually pretty good performance on an image net top one accuracy
732.48|5.4| better than VGG, for example. And how does that work? So it's
737.88|8.52| the same concept, like shown, sorry, like, shown here, except
746.44|3.68| more, I would say more sophisticated implementation of
750.12|2.8| that. So I could have implemented it by hand, but
753.24|3.32| there's always the chance to make mistakes at some point. So
756.56|3.84| why not using what's already implemented? So here, this is
760.4|3.0| again, I'm using my helper functions, that's again, the
763.4|4.4| same that explained for VGG 16. So everything is the same as
767.8|3.36| for VGG 16. So I don't have to discuss everything again, the
771.16|4.56| only new part here is really this part, the model. So here, I
775.72|2.88| actually copied the code from this website, which is an
778.6|4.68| implementation, the official pytorch implementation, which
783.64|3.56| has different versions of ResNet, wide ResNet, regular
787.2|5.56| ResNet, 18 layers, 34 layers, 100 layers, 152 layers, and so
792.76|6.36| forth. I grabbed the code that is used to initialize all of
799.12|2.8| these networks. So they have written some code that can be
801.96|3.48| reused for different types of residual networks. So here was
805.72|3.88| copying it and simplifying a little bit. So it's not that
809.6|2.36| long. And then they have something they call the
811.96|3.28| bottleneck. It's kind of similar to what I call the residual
816.04|5.74| block. But we have here, and then I mean, it's relatively
821.78|4.34| complicated, I have to admit, it would take me also a couple of
826.12|3.56| hours to really understand how that is implemented. The most
829.68|2.64| important thing is that it works. Many people are using it.
832.32|3.64| So I'm kind of trusting that this is indeed working. So they
835.96|3.48| have like a make layer method here or function here that
839.44|2.56| creates these layers, it's a little bit more sophisticated
842.0|4.64| than than my version. So and then in the forward method, you
846.64|3.6| have these different layers. So each layer has also multiple
850.24|3.52| conversion layers. That's how you get the number 34. And we
853.76|3.14| can also use the torch flatten function here. That's actually
856.9|2.18| something I should also maybe use more often. It's a more
859.08|3.36| recent thing. So I could actually technically replace
864.04|4.6| replace that one by flatten. So yeah, that could be replaced by
868.64|2.4| flatten. But I still need to know this number anyways,
871.04|2.36| because I have to put it here for the number of parameters. So
873.4|2.56| even though we can put a torch flatten here, it's, it's not
875.96|8.6| that much simpler. Yeah. So that is essentially it. So here, I
884.56|2.4| would have to know still this number in this linear near the
886.96|2.92| 500 to 12. So I could technically also write this as
890.16|8.92| torch view, minus one, 12, think blocks expansion here is one,
899.2|2.6| this is only used for the other types of networks, other
901.8|3.4| residual nets. So could technically also write it like
905.2|3.68| this. But yeah, we have this nicer flatten thing. What's
908.88|3.32| nice about flatten is everyone knows what to flatten, that it
912.2|2.8| has a meaning that is more intuitive, maybe than saying
915.0|6.8| view, minus one or something. Okay. Yeah, yeah, it's also the
921.8|3.12| same code that I used for the VGG. And now it's training.
925.16|6.16| Actually, we are using cipher 10 here. Let me open this one
931.32|8.04| again. So here, I have 70 by 70 images scrolling up, sorry. Yeah,
939.36|2.68| I have made it larger, because otherwise, the performance was
942.04|2.84| really poor. I mean, all these types of networks are really
944.88|4.16| implemented for bigger data sets, not cipher 10. I'm just
949.04|3.04| using cipher 10. Because then we don't have to download a
952.08|4.08| separate data set if you want to reproduce these results. And I
956.16|2.94| showed you how you can use your own data set too. So in that
959.1|3.26| way, shouldn't be an issue for you. But if you have questions,
962.36|4.08| you can always ask, I'm happy to help with that. So here, with
966.44|4.36| ResNet, we get approximately 48%, which is not much better
970.96|3.74| than what we got with VGG 16. Here, it's also kind of the
974.7|4.14| same. But notice, even though I use larger images here, it was
978.84|5.12| at least at least faster to run 62 minutes versus 90 minutes.
985.32|2.84| Okay, so if I if I would have made the images smaller here at
988.16|3.08| the same size, it would have probably finished in like 30 or
991.24|4.04| 40 minutes. Also overfitting. So here might be a case for adding
995.28|4.52| more dropout. So here we only have do we have actually dropped
999.8|5.08| much? No, not really. We only have batch norm. So maybe could
1004.88|9.16| be added to could be adding dropout. Okay, so some results
1014.12|3.16| gets bird and frog wrong. What was the one that this one got
1017.28|4.92| wrong? Dear and frog interesting. So yeah, animal
1022.2|2.68| classes are still confusing. You can also project you can see,
1025.28|2.36| again, the square where it makes misclassifications between
1027.64|3.8| different animals. Again, the tech cats and dogs. And yeah,
1031.44|5.84| this is ResNet implemented here. Honestly, if you implement
1037.28|2.36| networks, you don't have to implement things from scratch
1039.64|3.32| unless it's for educational purposes, like for learning
1042.96|4.56| things. Usually when you find a paper, or read a paper with an
1047.72|3.52| interesting implementation, or thing you want to try, usually
1051.24|4.44| what people do is they would go on GitHub and search for the
1055.68|3.52| original authors providing the code for that paper, and then
1059.2|4.2| adopting this code. So you would technically not run it one to
1063.4|2.6| one, you have to probably make some modifications so that it
1066.0|3.64| works for your data set. But usually in practice, once we are
1069.64|2.52| working with these more complicated data sets, there's
1072.16|3.44| no doesn't make sense to implement this ResNet 34. Let's
1075.6|3.22| say completely from scratch, it's only another source of
1078.82|2.66| making errors. I mean, it's it's useful here as a thought
1081.48|4.44| exercise to do it with a simple case with two layers, where you
1085.92|5.24| have simple implementation with two layers, yet maybe makes
1091.16|4.16| sense to do that. But if you go deeper, ResNet 34, maybe use
1095.32|3.96| something that is someone has implemented saves you lots of
1099.28|4.08| time and pain in that way. Alright, so okay, this is
1103.36|5.0| ResNet, I think we are already at the 75 minutes. So we will
1108.36|5.84| continue next week with the all convolutional network, I already
1114.2|4.0| implemented this somewhere here. And then we will also talk about
1118.2|3.16| transfer learning, I have to still implement it anyway, not I
1121.36|4.2| have it here already. So we will talk about transfer learning
1125.56|4.44| also next week. Alright.