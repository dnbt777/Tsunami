start_time|end_time|text
0.16|2.96| Yes, in the next two videos, I want to give you a brief
3.2|3.64| calculus refresher if you need it. So that's optional, you
6.84|2.8| don't have to watch the next two videos. If you are very familiar
9.64|3.16| with calculus, it will be, I think, too trivial for you. But
13.2|1.8| if you don't, if you
17.12|2.56| yeah, so in the next two videos, I want to give you a brief
19.76|4.24| calculus refresher, talking about derivatives and gradients.
24.0|2.76| And like I said, these videos are optional. So if you are very
26.76|3.18| familiar with calculus, then I think this might be too easy for
29.94|3.12| you. But for those who are here, you want to refresh their
33.06|4.08| calculus. This is like a brief summary of the main parts that
37.14|2.82| we will need for the gradient descent algorithm.
41.28|3.56| Yeah, so here's an overview of what a derivative is. So a
44.84|2.84| derivative of a function, you can think of it as the rate of
47.7|4.06| change of that function, or the so called slope. So you have a
51.76|6.14| very simple example, a function f, which is equal to 2x. So if
57.9|3.46| we have an input, let's pick an arbitrary number here on the x
61.36|4.68| axis. So if I have the number three here, so the input is
66.06|5.76| three, then the output would be two times x or two times a in
71.82|3.18| this case, two times three, that would be six. So the output
75.0|5.78| would be six. Now let's pick a second point. Let's get move on
80.78|5.74| the x axis by delta a units. So then we arrive at this point
86.52|3.72| here. So if I look at these values, let's move by four
90.24|3.6| points, and we arrived by at seven here, and then the output
93.84|3.12| corresponding to that would be two times that which would be
97.8|4.26| 14. So yeah, there is between these two points, there is a
102.06|8.9| change here going on, the change is from six to 14. So this is
110.96|7.08| by eight units. And the change on the x axis is from three to
118.04|4.8| seven, it's only four units. So we can then compute the rate of
122.84|5.24| change or the slope by having this eight divided by four is
128.08|4.16| equal to two. So the slope of this function of two x is two.
132.6|4.36| So more formally, here's the equation how we can compute the
136.96|5.32| slope. So we pick the function on the right hand side. So this
142.28|4.56| is the input on the right hand side here. And then this is the
146.84|2.32| input here on the left hand side, let me use a different
149.16|5.8| color. And of course, then the output here, this is
155.04|3.76| corresponding to this one. And the output of this one is
158.8|3.58| corresponding to this one. So we are plugging in the difference
162.38|5.3| of the height. So the 14, you write this down. Let's do it in
167.68|7.48| black 14 minus six. And then divided by and we have a and
175.16|5.24| then this second value, delta a minus B, which would be in our
180.4|12.04| case, three plus four minus three. So how can I Yeah, so
192.44|3.92| actually, I can simplify that. So we have a, and then we have
196.36|6.28| this second value, delta a minus a. So maybe it's simpler to see
202.64|4.36| it like this. So these two belong together, it's a and f
207.0|4.48| of a. And these two are these belong together because it's for
211.48|5.32| this point here, a plus delta a, which we plug in here, but we
216.8|3.56| can actually simplify that right because we have a minus a so we
220.36|4.0| can actually cancel that. And then we have this simpler form
224.36|9.0| here, which is essentially then 14 minus six divided by four,
233.36|4.16| which is eight divided by four. So this is like more the formal
237.52|3.68| way of how we compute the slope. And in this case, the slope of
241.2|4.24| this function is two, it tells us by if we change the function
245.44|3.32| by one unit, so the input of the function, if you change it by
248.76|3.4| one unit, the output changes by two units, because the other
252.16|3.92| slope is two. So it gives us an idea of how fast the function
256.08|6.12| grows here, with respect to the inputs. Yeah, so on the previous
262.2|3.84| slide, I showed you a very, very big leap on the x axis, usually
266.04|3.04| when we think of function derivatives, we think of a very
269.08|5.0| small change in the input. So we think about what what happens if
274.08|4.36| delta x, so the change on the input scale goes to zero is like
278.48|5.04| infinitely small. So here on the right hand side, this is again,
283.52|2.8| the slope from the previous slide, where I just use the
286.36|4.12| letter x now instead of a. And here, these are two different
290.48|6.32| ways of denoting that we are computing a derivative. So if we
296.8|4.36| have a function f of x, then f prime of x would be the
301.16|3.84| derivative of that function. So when I recall from my calculus
305.0|3.68| classes long time ago, I think this was called Lagrange
311.4|8.6| notation. Whereas this one is the Leibniz notation, you don't
320.0|2.56| have to memorize these names. But yeah, they're just two
322.56|4.4| different ways of denoting the same thing. The Leibniz notation
326.96|2.6| will be a little bit more useful later in the context of deep
329.56|4.44| learning when we call talk about your partial derivatives of
334.0|4.82| functions, and also your gradients. In any case, let's
338.82|3.38| take a look at an example deriving a function or computing
342.2|3.28| the derivative more formally. So let's consider again, our
345.48|6.06| function to x here. So we are now starting with a simple, just
351.54|3.78| a formal notation from above. Now let's plug in, let's plug
355.32|6.9| in this function. So if we have x and delta x, the output would
362.22|5.7| be what would be the output on should be two x, so two times x
367.96|5.08| plus delta x, right. So this one, and here, here, see, I
373.04|7.16| just expanded it already. So I'm just expanding this to two x plus
380.2|5.6| two delta x. So that's what I have here. And then this one is
385.84|3.64| here to x, right? That's where this one comes from. So what
389.48|4.36| I've done here is really just plugging in the function into
393.88|4.68| the equation here. Now I can see, I have a two x here and a
398.56|3.92| two x here. And then I mean, this is minus two x actually, so
402.48|5.0| I can cancel those. So this one, and this one cancels. So what I
407.48|5.16| have is two delta x divided by delta x. So this can also be
412.96|4.24| canceled. And then what remains is the two and that is how we
417.2|6.04| derive or compute the derivative of this function. Yeah, let's
423.24|3.32| do this again, using a slightly more complicated function. Let's
426.56|5.14| take a look at x squared. So how can we derive x squared using
431.7|4.26| the same concept as before? So exactly the same notation, now
435.96|4.68| plugging in x squared itself to x. So what we get here is for
440.64|6.64| the first part is for f of x plus delta x. This is if we
447.28|5.92| consider x squared, this would be then x plus delta x squared.
453.6|6.16| Then if I expand this, this would be two x, sorry, x
459.76|8.84| squared plus two x delta x plus delta x squared. So this is what
468.6|5.64| I've written down here. So if I have no this form, I can
474.24|4.24| simplify because yeah, if we pay attention, there's again, x
478.68|4.0| squared minus x squared, so we can cancel those. So what
482.68|8.1| remains is two x delta x plus delta x squared. So now what we
490.78|4.78| do is looking at this, we can also further simplify it, right.
497.28|6.16| So we can divide actually by delta x. So if I divide by delta
503.44|5.52| x, this one goes away, this one goes away, and this one goes
508.96|5.56| away. So what, what stays is two x plus delta x. And also
514.52|3.24| considering that we are interested in a very small
517.8|5.2| chains of x. So when delta x goes to zero, so you can think
523.0|3.6| of it as zero. So this kind of also goes away. So the
526.6|5.0| derivative is basically two x. So deriving x squared, the
531.6|1.64| derivative would be two x.
534.76|2.4| Yeah, so conceptually, what we were doing in the previous
537.16|4.5| slide, when we computed the derivative of x squared, is we
541.66|5.34| approximated the slope by a secant between two points. So
547.0|3.56| just to draw out what that how that looks like. So if we
550.56|4.36| consider this function, f of x, x squared, so we have this
555.36|5.68| parabola here. So now let's consider a concrete point here.
561.08|3.6| Let's consider this one here. And the slope of this of the
564.68|2.56| function at this point would be this tangent line here, this
567.24|6.68| red line, how we approximate it is it is is by taking two
573.92|5.8| points. So we took the original point, and then we added delta
579.72|7.24| x to it, right plus delta x, x plus delta x. So we added delta
586.96|6.68| x to x, let's say this is delta x. So we are here on the right
593.64|4.2| hand side. Now we have the second point. So this is f of x
597.84|7.0| plus delta x. And then there's this secant line, the line. Yeah,
605.28|4.28| between these two points, and we use that line to approximate
609.6|3.08| the tangent. And you can see if yeah, the difference is
612.8|4.04| relatively large between the two points, right? Between if
617.12|2.76| basically, if delta x is very large, then you can see this is
619.88|4.28| not a very good approximation. This is why we usually take a
624.16|6.2| look at when the tax goes to zero at the limit. So in this
630.36|3.08| case, what we would have is we would maybe have a smaller
633.6|2.4| distance here, it's still big, but otherwise, I wouldn't be
636.0|3.36| able to draw it. And you can see if I now connect this point in
639.36|3.04| this point, this is a better approximation of the red line.
642.66|3.54| And if I go and make this smaller and smaller, the better
646.2|4.6| I will approximate this tangent line here. So this is basically
650.8|2.6| conceptually how Yeah, this
655.0|3.76| symbolic derivative computation works when we consider this
659.08|5.0| small rate of change here. Yeah, here made a cheat sheet for you
664.08|3.04| with the most common derivatives, the most useful
667.12|4.08| ones to memorize. I don't want to go over all over all of
671.2|3.12| these. But yeah, they are in the slides for your convenience. So
674.32|2.96| if you need that as a cheat sheet that's in the slides, then
678.52|5.16| I hear more derivative rules. So the main ones, the sum rule, the
683.68|5.04| difference rule, product rule quotient rule, reciprocal rule,
688.92|2.28| these are actually you don't have to memorize these, you can
691.2|3.16| actually derive them from the product rule. For example, if
694.36|5.68| you consider the quotient rule, you can actually rewrite that as
700.04|7.46| um, f of x times g x is one, and then yeah, work with this one.
708.94|3.92| So you don't need to memorize the quotient or reciprocal rule,
712.86|6.28| you can actually work with a product rule. Um, yeah, so then
719.14|3.4| the chain rule, that is actually the most important one. So for
722.54|3.24| deep learning, I mean, all of them are important, but the
725.78|3.76| chain rule is the main one that kind of drives deep learning. So
729.54|3.96| you will see later when we talk about gradient descent, it is
733.78|2.72| essentially just an application of the chain rule when we
736.66|2.96| compute the derivative of the loss function with respect to
739.62|6.96| the weights. Yeah, so here is a visual explanation of this,
746.82|2.96| the composition of a nested function using the chain rule.
750.22|4.16| So using colors here, it's maybe easier to see. So let's assume
754.38|6.08| we have a function, capital F of x that consists of two nested
760.46|6.72| functions, f and g here. So what how we compute this is we first
767.18|4.78| compute the inner part, and then we compute the outer part. So
771.96|2.54| this is just the regular function. So this is visualized
774.5|4.16| here in this graph. So we have a computation graph here. So this
778.66|4.76| is more like a computation graph view, where we first pass x into
783.42|4.92| g, then we get some output. And this output of the inner part
788.54|4.48| then goes into the outer part f. And then this gives us the
793.06|4.72| result z. So when we then compute the derivative of this
797.78|3.4| function, we Yeah, we use the chain rule. And the chain rule
801.18|6.52| is two things, what it's two parts, the auto derivative times
807.7|6.48| the inner derivative. So we can think of it as the altar, the
814.18|10.16| derivative. And here the derivative that we compute here.
824.74|6.4| And visually, also, what happens is we can do this separately. So
831.14|5.22| we can compute here, in this case, the inner derivative. So
836.36|5.16| we pass x to g computer derivative of that. And here,
841.54|4.04| that's the auto derivative. So here we are deriving f. And then
845.58|3.36| once we have these two results, we can multiply them together.
848.94|5.42| And that is the derivative of the whole function. Yeah, one of
854.36|3.66| the nice things of pytorch is that it will build such
858.02|3.88| computation graphs automatically if we define variables and do
861.9|3.92| some computation with those. So pytorch will literally keep a
865.82|2.76| computation graph in the background, then. And there are
868.58|3.48| utilities then for computing derivatives automatically. So
872.3|3.28| pytorch can commute these derivatives automatically with
876.1|3.88| using a package inside call, which is called auto grad, so
879.98|3.48| automatic gradient computation, we will see that in the next
883.46|4.48| week. So usually, it's not required that we derive things
887.94|3.36| by hand when we work in pytorch. There are automatic ways of
891.3|3.76| doing that. But of course, it's useful to know how derivatives
895.06|4.16| and gradients work, because we have to have I think it's a good
899.22|2.92| idea to have an understanding of how these types of things work
902.14|6.96| before you use packages that can do them automatically. Yeah, and
909.1|4.36| here, I just wanted to show you in text, when we write down
913.46|3.68| derivatives, we will mostly be using the Leibniz notation. So
917.14|3.6| instead of writing this nested thing here, we will use the
920.78|3.0| Leibniz notation, which I find personally, a little bit easier
923.78|3.18| to read, especially when we have more complicated function with a
926.96|5.74| lot of nesting going on. Yeah, so here's just an example
932.7|4.84| applying the chain rule in practice on nested function. So
937.54|6.4| here we have the nested function log of square root of x. So
944.22|5.04| first, it's easy just to take them into two parts. So the
949.26|10.16| outer derivative times the inner derivative here. So and then we
959.42|5.12| can derive them separately. So now let's just focus on the
964.54|3.36| outer one first. So the derivative of the outer function
967.9|5.52| is the derivative of log g is one over g. And g, it's just a
973.42|3.96| placeholder for square root of x. So the derivative of the
977.38|5.64| outer function here is one over square root of x. And then for
983.06|4.16| the inner one, so we have the derivative of square root of x,
987.22|2.6| I'm just rewriting it here for convenience. And then we can use
989.82|4.8| the power rule here, bring the one half up front, and then
995.1|5.72| minus one in the exponent, so it's minus one half. And that is
1000.82|5.12| just rewritten as one over two square root x. So this is the
1005.94|2.72| inner derivative. And then we just combine them because the
1008.66|5.8| chain rule is really just sorry, the inner times the outer. So
1014.46|3.44| here, I'm just putting these two parts together. So the overall
1017.9|5.04| derivative is one over two x here. Yeah, we can also use the
1022.94|3.12| chain rule for arbitrarily long function composition. So
1026.06|4.04| consider this function f of x here, which consists of five
1030.1|5.6| nested functions 12345. So yeah, we can also expand this using
1035.7|2.96| the chain rule when we compute the derivative. So if we
1038.66|4.24| compute the derivative of the function of the auto function f
1042.9|3.88| here, if we also the derivative of the whole thing here, we can
1046.78|4.32| decompose that into smaller parts, and then compute all of
1051.1|3.28| them separately using the chain rule and multiply them to
1054.38|11.64| compute the derivative basically.