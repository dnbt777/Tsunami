start_time|end_time|text
1.34|4.24| All right, let's now talk about how we can use batch norm in
5.58|4.44| practice. And also, we will talk briefly about how batch norm
10.18|3.16| behaves during inference, because yeah, you know that
13.62|2.46| during training, we have mini batches, but that's not
16.08|3.9| necessarily the case if we want to use our network for
19.98|3.36| prediction. Sometimes we only have a single data point. So how
23.34|3.18| would that work? So but yeah, first, let me show you how
26.52|5.54| batch norm works. When we use pytorch. I've actually just used
32.06|4.02| the code from last week where I implemented dropout and just
36.08|3.78| made a slight modification where I removed dropout and added a
39.86|4.6| batch norm layer. So I was just accept that reusing the same
44.46|3.28| code. So I don't want to walk through this in detail. But you
47.74|3.32| can find the code here on GitHub. And here I'm showing
51.06|3.42| you the main code, the multi layer perceptron that we have to
54.48|5.52| modify. And yeah, so what we have here is one, two hidden
60.0|4.42| layers, and the output layer at the bottom. And first, notice
64.42|3.04| that I'm using again, flatten, that's because I was working
67.46|6.04| with MNIST and MNIST is on n times one times 28, times 28
73.86|3.0| dimensional, and flatten will essentially flatten this to a
76.86|4.96| vector to n times 784 dimensional vector, where n is
81.82|3.0| the batch size, and then it will work with the fully connected
85.06|5.52| linear layer here. So yeah, I here insert batch norm after the
90.58|3.6| linear layer, notice that there's a one D, it may be
94.18|3.44| confusing. Why is there a one D? That's because there is a
97.62|3.12| slightly different version of batch norm for convolutional
100.74|3.22| networks. We will discuss this in the convolutional network
104.1|3.72| lecture where this would be called batch norm 2d for the
107.82|3.72| convolution networks. So to keep them apart, this is called batch
111.54|2.64| norm 1d. This is essentially just the batch norm that we
114.18|3.72| discussed here in the previous video. So the one is just to
117.9|4.56| keep them apart. Yeah, and here I'm doing the same thing in the
122.46|3.96| second hidden layer. Also, yeah, notice that I set the bias to
126.42|3.2| false because it would be redundant, right? Because if we
129.9|4.84| compute the net input as, let's say the weight times the feature
135.02|6.24| plus B, and then batch norm, we had this plus beta values in
141.26|3.28| that way, the bias becomes kind of redundant. So it's not
144.54|2.88| necessary, but you can have it there. It doesn't really matter.
147.62|3.16| I ran it with and without it, I didn't notice any difference in
150.78|5.56| this case. Okay, so this is how your batch norm looks like a
156.34|3.12| full code example can be found here. But there's really
159.46|4.6| nothing, nothing really to talk about, because it's just two
164.06|6.04| lines of code here. Um, yeah, so I was also just for fun running
170.1|4.38| some experiments without the bias that I just showed you. And
174.48|3.2| having batch norm before the activation, that's usually how
178.24|3.8| yeah, that was originally how it was proposed in the paper. But
182.04|3.48| sometimes people also, nowadays, it's even more common to have
185.52|2.96| it after the activation. I will talk more about that in the next
188.48|4.44| video. My phone some benchmarks, some more sophisticated
192.92|3.08| benchmarks I wanted to show you. So but here in this case, when I
196.0|3.04| ran the code of the multi layer perceptron that I just showed
199.04|4.4| you, I enabled the bias. So I'm actually not showing it here. I
203.44|4.48| don't know why I deleted it. But on by default bias is true if
207.92|4.0| you don't set anything and I found it was the same
211.92|4.64| performance. I then also inserted batch norm after the
216.56|4.32| activation instead of before the activation like here or here. So
220.88|5.2| I know, instead of here having it before the activation, I now
226.08|4.2| have it after the activation in both cases. And I also didn't
230.28|6.12| notice any, any difference really here. Um, yeah, and then I
236.4|4.08| also ran experiments with dropout. In this case, also, I
240.48|2.76| didn't notice much of a difference, except now the
243.24|3.4| network was not overfitting anymore. The test accuracy for
246.64|4.6| both dropout cases was slightly lower compared to no dropout. I
251.24|3.64| think I use just too much dropout. But I could at least
254.88|3.24| see there was no overfitting anymore. But either comparison
258.12|7.56| here is inserting batch norm before the activation, and then
265.68|5.72| dropout. And then after the activation, and then dropout. And
271.4|3.28| I also did not notice any difference here. In practice,
275.12|3.0| people nowadays, it's more common to actually recommend if
278.12|3.04| you use dropout to recommend having batch norm after the
281.16|4.32| activation. And yeah, one little fun memory aid to remember that
285.48|6.44| is, if you consider this case, so you have batch norm, then
291.92|4.08| you have the activation and then you have dropout, you may call
296.0|4.0| it bad, it might be better to have batch norm after the
300.0|3.6| activation, that's typically a little bit more common. In this
303.6|2.6| case, I didn't notice any difference, it may make a small
306.2|2.72| difference in other types of networks like convolution
308.92|3.2| networks. So I would if you use dropout in a bedroom, I would
312.28|3.0| probably go with this variant. But yeah, of course, it's
315.28|2.56| something, it's a hyper parameter, essentially to
317.84|5.8| experiment with. Alright, so I have one more thing about drop
323.64|3.8| out in pytorch. So when we look again at our training function
327.44|2.96| here, this is exactly the same training function that I used
330.44|3.32| last week in dropout. But again, this is again, highlighting
333.76|5.4| train and evil are important here that we during training set
339.16|4.56| our model into training mode, because that's where batch norm
343.72|4.4| will compute the running mean and the running variance, I will
348.12|4.64| talk about this in the next slide. So here, batch norm will
352.76|4.72| actually compute some running statistics during training. And
357.48|3.76| these running statistics are then used in the evaluation mode
361.24|4.32| Asian mode when we evaluate our model on new data. So during an
365.56|5.16| evaluation, you have to imagine that you are mimicking the
370.72|2.88| inference scenario. And in inference, you may only have a
373.6|4.4| single data point, right? So let's say you have the Google
378.02|3.14| search engine, and there's just one user running a query, and
381.2|2.92| you have a network that has batch norm. So you have to
384.12|4.62| normalize, but you don't have a batch of users. So only if one
388.74|4.38| user. So how do we deal with that scenario? So there are two
393.12|4.48| ways to deal with that scenario, the easy one would be to use a
397.6|3.4| global training set mean and variance. So you would compute
401.0|3.92| these means for the features and the variances for the features
405.12|3.48| for the whole training set. That's something you would also
408.6|4.44| usually do or could do when you compute the input standardization.
413.68|3.28| But this is actually not very common in practice for some
416.96|4.22| reason. So what's more common is to use an exponentially weighted
421.2|3.64| average, or a moving average is just a different name for that.
425.08|4.68| So usually, practice people keep a moving average of both the
429.76|3.16| mean and the variance during training. So you can think of it
432.92|3.84| as also as the running mean, how it's computed is by having a
436.76|4.56| momentum term, it's usually a small value like point one. And
441.32|3.72| this is multiplied by the running mean from the previous
445.04|7.76| on epoch, or sorry, previous mini batch. And then what you so
452.8|3.68| you have this, this term, this is like the running mean times
456.48|3.98| momentum term, this is a point one value. And then you have one
460.46|5.7| minus the momentum, this is like a point nine value, then plus
466.2|4.16| yet plus point nine times the current sample mean. So that's
470.36|7.28| the mini batch mean, and you just do the same thing also for
477.64|3.82| the running variance. So here, essentially, this is just like a
481.46|3.66| moving average or running mean. And you do the same thing for
485.12|3.24| the variance. That's what you keep. And then during inference,
488.48|3.52| you use that one to scale the data point that you do a
492.0|4.48| prediction on you yourself don't have to do that. Yeah, yourself,
496.48|3.84| by the way, by using model evil, it will actually happen
500.32|3.6| automatically. But yeah, here's just like the explanation what's
503.92|5.0| gonna happen under the hood. Okay, so yeah, that is how batch
508.92|4.16| norm works in pytorch. And in the next video, I want to
513.08|7.64| briefly go over some very brief, a brief rundown of all the types
520.72|6.24| of literature that try to explain how batch norm works.