start_time|end_time|text
1.74|3.14| Yeah, hi, everyone. So we finally put behind us all the
4.88|3.92| stuff about, yeah, making neural networks learn better and train
8.8|3.2| better. So what would be more exciting than introducing a new
12.0|3.48| neural network architecture. So today, I want to talk about
15.52|2.92| convolutional neural networks, which are especially good for
18.44|3.44| image data, convolution neural networks, that's a big topic. So
21.88|3.12| actually, I have enough slides to talk about it, like for at
25.0|3.92| least three or four weeks. But I'm trying to keep it focused.
28.92|4.72| So I reduced my slides a little bit to two lectures. So in the
33.64|3.84| first lecture today, I want to talk about the basic concept
37.48|2.88| behind convolutional networks, and what you can do with them
40.36|3.28| and how they work on the big picture level. And then in the
43.64|3.52| next lecture, I will go more into these different types of
47.16|2.92| convolutional neural network architectures. Because yeah,
50.08|2.56| there are lots of neural network architectures that have been
52.8|3.16| developed in the last couple of years, like residual neural
55.96|3.96| networks, VGG networks, and inception networks, and so
59.92|3.48| forth. So in the next lecture, we will talk more about these in
63.4|3.68| detail. Whereas in this lecture, I will give you a big overview
67.08|2.36| of how convolutional neural networks work.
70.84|3.76| Yeah, so here are the topics I have in mind for today. I know
74.6|3.4| it looks like a lot, but most of them will be very short videos.
78.16|3.44| I just try to make more subsections to keep things more
81.6|3.12| organized. And I think, based on what I heard based on the
84.72|3.28| feedback, you like a shorter video. So in that way, I will
88.12|4.28| try to keep them shorter, and have more more short videos
92.4|3.92| rather than having fewer long videos. So first, I want to talk
96.32|4.72| briefly about applications of CNN. So what we can do with CNNs.
101.04|3.4| And then we will talk about image classification, in
104.44|2.48| particular, because image classification is one broad
106.92|4.16| aspect or one popular application area of CNNs. And
111.08|3.4| that helps us also studying CNNs better when we use a simple
114.48|4.28| application first, then I will go over the basics of
118.76|4.68| convolutional networks, like the main aspects behind them, and
123.48|4.32| then focusing on convolutional filters and weight sharing.
127.8|4.16| That's one aspect that is part of the convolution architecture.
131.96|3.84| So we will learn a little bit about that. Then I will do some
136.38|4.06| little nitpicking here. So discussing briefly the
140.46|2.78| difference between cross correlation and convolution.
143.24|3.92| It's not particularly important, but maybe one day you will get
147.16|2.68| an interview question about that. And then you know the
149.84|4.8| answer. Then we will talk about just very briefly about back
154.64|3.44| propagation in convolutional networks. So it will be a very
158.12|2.76| short video, because we I don't want to go into the mathematical
160.92|2.72| details, it will take too much time. And it's not super
163.64|3.44| important, because you know, we can use auto grad. And yes,
167.08|2.2| starting maybe the back propagation in more detail for
169.28|2.32| convolutional networks and deriving it by hand, that would
171.6|4.44| be something for a more advanced course, maybe. Then I will just
176.04|3.84| briefly outline what types of convolutional neural network
179.92|4.08| architectures are out there. But this will be mainly a topic for
184.04|4.72| next week. And then we'll briefly see what CNNs can see.
188.8|4.96| So looking, looking a little bit behind the curtain and see what
194.12|5.56| information the CNN image looks at and how it processes this
199.68|4.96| information. And then lastly, we will finally then see how we can
204.64|3.32| use convolutional networks in pytorch. And this is actually
207.96|3.08| not too complicated. So also there, don't worry, it will be a
211.04|4.84| rather short video. So next lecture, just to give you an
215.88|2.76| outlook next lecture, we will then talk about some more
218.64|3.76| advanced concepts. So for instance, if you are already
222.4|2.44| roughly familiar with convolution networks from some
224.84|3.64| other resources, and you wonder why we don't discuss certain
228.48|3.36| certain things today, that's because I moved them up to the
231.84|3.4| next lecture next week. Otherwise, today's lecture would
235.24|2.96| be really too long. So next week, we will talk about
238.2|3.48| padding, then on special versions of dropout and batch
241.68|3.88| norm that work with convolutional networks, then some
245.56|4.58| considerations for training CNNs on GPUs. And then these common
250.14|4.02| architectures like VGG 16, residual networks, fully
254.16|4.56| convolutional networks and inception. There, of course, maybe 50
258.72|2.92| more architectures that we can't cover here. But I would say
261.64|4.16| these are still the main ones, there are some other ones that
265.8|3.4| are also popular. But again, we can't talk about everything
269.2|2.96| here. So these will be the main ones. And then I will also show
272.16|4.84| you how transfer learning works. So I recommended transfer
277.0|4.6| learning to some students in the context of your class projects.
281.6|2.52| So when I was reviewing your class projects, I said sometimes
284.28|4.0| might be good to use transfer learning. And here in the next
288.32|2.28| week's lecture, I will then also explain what it is.
290.8|4.68| Essentially, it is training the network on a large data set, and
295.48|3.64| then fine tuning, fine tuning it on a smaller data set. Because I
299.12|4.32| noticed many students only have small data sets like 500 images
303.44|3.06| and something like that. And usually, it's tricky to get good
306.5|3.8| performance on a small data set. So in that way, it's sometimes
310.3|3.6| helpful to pre train the network on a larger data set before
313.9|2.82| fine tuning it to your target data set. But yeah, again, we
316.72|3.4| will discuss that next lecture. So today, we will then start
320.12|21.0| with first topic, what CNNs can do.