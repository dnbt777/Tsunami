start_time|end_time|text
6.42|4.38|hello
8.639|2.821|um it's fun fun to be here
10.8|3.419|um
11.46|4.5|so the work I'm presenting today uh
14.219|4.081|title of it is attention approximates
15.96|3.72|Sports distributed memory
18.3|3.0|um and this was done in collaboration
19.68|4.98|with Genghis palavon
21.3|4.86|um and my PhD advisor is Gabriel Crimea
24.66|2.52|um so why should you care about this
26.16|2.52|work
27.18|3.78|um we show that the heuristic attention
28.68|3.719|operation can be implemented with simple
30.96|3.96|properties of high dimensional vectors
32.399|4.741|in a biologically plausible fashion uh
34.92|4.68|so the the Transformer and attention as
37.14|5.099|you know are incredibly powerful but
39.6|4.92|they were heuristically developed and
42.239|3.66|the softmax operation in attention is
44.52|4.859|particularly important but also
45.899|5.581|heuristic and so we show that the
49.379|4.381|intersection of hyperspheres that is
51.48|4.98|used in sports Studio memory uh closely
53.76|5.34|approximates the softmax and attention
56.46|4.2|more broadly both in theory and with
59.1|4.32|some experiments on train Transformers
60.66|3.959|uh so you can see sdn and supposed to
63.42|2.82|read memory
64.619|3.36|um as preempting attention by
66.24|3.48|approximately 30 years was developed
67.979|3.481|back in 1988
69.72|3.3|um and what's exciting about this is
71.46|2.64|that it meets a high bar for biological
73.02|2.34|possibility
74.1|2.82|um hopefully I have time to actually get
75.36|4.02|into the wiring of the cerebellum and
76.92|4.559|how you can map each operation to part
79.38|4.2|of the circuit there
81.479|4.261|so first I'm going to give an overview
83.58|4.859|of sports distributed memory
85.74|4.32|um then I I have a Transformer attention
88.439|3.961|summary but I assume that you guys
90.06|3.66|already know all of that we can like get
92.4|2.7|there and then decide how deep we want
93.72|3.18|to go into it
95.1|4.86|um I'll then talk about how actually
96.9|4.44|attention approximates STM
99.96|2.4|um interpret the Transformer more
101.34|2.52|broadly
102.36|4.5|um and then hopefully there's time to go
103.86|4.32|into sdm's biological possibility
106.86|3.899|um also I'm gonna like keep everything
108.18|3.66|high level visual intuition and then go
110.759|3.241|into the math
111.84|4.08|um but stop me and please ask questions
114.0|2.759|literally whenever
115.92|3.12|um okay
116.759|3.601|so uh sparse distributed memory is
119.04|3.84|motivated by the question of how the
120.36|3.719|brain can read and write memories
122.88|3.48|um in order to later retrieve the
124.079|3.661|correct one and some considerations that
126.36|4.259|it takes into account are high memory
127.74|4.499|capacity robustness to query noise
130.619|4.321|um biological possibility and some
132.239|4.921|notion of fault tolerance
134.94|3.6|um SDM is unique from other associative
137.16|3.12|memory models that you may be familiar
138.54|5.279|with like Hot Wheel networks
140.28|4.74|um in so much as it is it's sparse so it
143.819|3.841|operates on a very high dimensional
145.02|4.62|Vector space and the neurons that exist
147.66|4.98|in this space only occupy a very small
149.64|4.8|portion of possible locations
152.64|4.92|um it's also distributed so all read and
154.44|5.159|write operations apply to all nearby
157.56|4.56|neurons
159.599|3.961|um it is actually as a side note
162.12|3.24|um homfield networks if you're familiar
163.56|3.539|with them are a special case of Sparks
165.36|3.78|distributive memory I'm not going to go
167.099|4.801|deep into that now but
169.14|5.4|um I have a blog post on it
171.9|5.46|um okay so first we're going to look at
174.54|4.68|the right operation for super memory
177.36|4.019|um we're in this High dimensional uh
179.22|4.08|binary Vector space uh we're using
181.379|4.201|Hammond distance as our metric for now
183.3|5.88|we'll move to continue this later
185.58|6.0|um and we have this green pattern uh
189.18|5.88|which is represented by the solid Dot
191.58|5.34|and the hollow circles are the symptoms
195.06|3.539|um also think of everything like quite
196.92|3.179|abstractly and then we'll map to biology
198.599|3.72|later
200.099|4.14|um so this pattern has a red radius
202.319|3.661|which is some heavy distance
204.239|3.601|um it activates all of the neurons
205.98|4.979|within that Heming distance
207.84|5.16|and then it's uh here I just denote that
210.959|4.381|each of those neurons are now storing
213.0|4.26|that green pattern and the green pattern
215.34|3.179|has disappeared so I'm keeping track of
217.26|3.539|its location with this kind of fuzzy
218.519|4.86|Hollow Circle that'll be relevant later
220.799|3.72|so we're writing in another pattern this
223.379|3.241|orange one
224.519|4.741|and note here that neurons can store
226.62|3.66|multiple patterns inside of them uh and
229.26|2.82|formally this is actually a
230.28|3.06|superposition or just a summation of
232.08|2.46|these high dimensional vectors because
233.34|2.94|they're high dimensional you don't have
234.54|3.3|that much so you can get away with that
236.28|3.12|but for now you can even just think of
237.84|3.899|it as like as a neuron can store
239.4|4.8|multiple patterns
241.739|3.961|um finally we have a third pattern this
244.2|2.759|blue one we're writing it in another
245.7|4.619|location
246.959|4.741|and yeah so again you can we're keeping
250.319|2.7|track of the original pattern locations
251.7|3.239|and they can be but they can be
253.019|4.261|triangulated from the nearby neurons
254.939|4.501|that are storing them
257.28|4.019|and so we've written in three patterns
259.44|5.1|now we want to read from the system so I
261.299|5.581|have this pink star side uh it appears
264.54|3.9|it has a different um it's represented
266.88|3.36|by a given Vector which is has a
268.44|3.24|specifications of space and I'm making
270.24|3.3|sure again
271.68|4.62|um but now the neurons
273.54|4.98|um output the patterns that they've
276.3|4.86|stored previously and so you can see
278.52|5.399|that depend based upon its location it's
281.16|4.38|getting four blue patterns uh two orange
283.919|3.301|and one green
285.54|3.78|um and it then does a majority rule
287.22|4.62|operation where it updates towards
289.32|4.68|whatever pattern it's seen from us so in
291.84|4.26|this case because um Hulu was actually a
294.0|4.02|majority it's just been an update
296.1|4.319|completely towards blue again I'll
298.02|4.14|formalize this more in a bit but um this
300.419|4.941|is really to give you intuition for the
302.16|3.2|core operations of sem
305.4|6.299|so the the key thing to relate this back
309.12|4.38|to attention is actually to abstract the
311.699|3.661|way the neurons that are operating under
313.5|4.74|the hood and just consider the circle
315.36|6.059|intersection and so what each of these
318.24|4.739|intersections between the uh Pink lead
321.419|3.321|circles and each of the right circle of
322.979|4.801|means is is
324.74|4.899|the neurons that both store that pattern
327.78|5.34|that was written in and are now being
329.639|5.101|read from by the query and the size of
333.12|4.079|that intersection
334.74|5.72|um corresponds to how many patterns the
337.199|3.261|query is then going to read
343.139|5.34|and so formally we Define the number of
345.9|5.22|neurons in this circle intersection as
348.479|4.5|the cardinality between number of
351.12|5.72|neurons and pattern number of neurons in
352.979|3.861|query and there are sections
358.56|4.5|okay are there any questions like at a
361.08|4.1|high level before I get more into the
363.06|2.12|math
365.22|4.02|I don't know if I can check is it easy
367.08|3.48|for me to check Zoom nah sorry Zoom
369.24|3.42|people I'm not going to check
370.56|4.919|um okay but the neurons is randomly
372.66|4.92|distributed yes yeah yeah
375.479|4.56|um and there's later there's more recent
377.58|4.739|work that uh they can learn and update
380.039|4.021|their location to cut tile manifold but
382.319|3.301|uh in this you can assume that they're
384.06|3.419|randomly initialized binary High
385.62|6.48|dimensional vectors
387.479|6.481|um okay so this is the full SDM uh
392.1|3.96|update rule
393.96|4.679|um I'm gonna break it down
396.06|4.32|so the first thing that you do so so
398.639|3.06|this is this is for reading to be clear
400.38|2.46|so you've already written patterns into
401.699|3.301|your neurons
402.84|4.199|um so the first thing you do is you
405.0|4.56|weight each pattern by the size of its
407.039|4.261|Circle intersection so
409.56|3.84|the circle intersection there for each
411.3|5.64|pattern
413.4|4.919|then you sum over all of the patterns
416.94|2.819|that have been written into this space
418.319|3.301|so you're just doing a weighted
419.759|3.921|summation of them
421.62|5.46|and then there's this uh normalization
423.68|5.68|by the uh total number of intersections
427.08|4.14|that you have
429.36|3.779|and finally because at least for now
431.22|4.74|we're working in this binary space uh
433.139|4.801|you map back to Binary just seeing if
435.96|4.16|any if the values are greater than a
437.94|2.18|half
441.18|4.38|um okay how familiar are people with
443.699|3.981|attention I looked at like the previous
445.56|4.68|talks you had they seem quite high level
447.68|5.139|like can you guys write the attention
450.24|6.56|equation for me is that like
452.819|3.981|can I get thumbs up if you can do that
457.02|5.22|yeah okay I'm not like oh oh I'll go
460.62|3.359|through this um but I'll probably go
462.24|3.0|through it faster than otherwise
463.979|3.0|um so when I first made this
465.24|5.42|presentation like this was the state of
466.979|3.681|the Art for Transformers which was like
471.319|3.761|and so it's kind of funny like how far
473.88|3.3|things have come now I don't need to
475.08|3.179|tell you that Transformers are important
477.18|2.639|um
478.259|3.66|so
479.819|4.201|yeah I'm going to work with this example
481.919|4.021|well well okay I'm going to work with
484.02|3.119|this example here the cat sat on the
485.94|3.96|blank
487.139|4.68|um and so we're in this setting we're
489.9|4.739|predicting the next token
491.819|5.041|um which the word math
494.639|4.62|um and so there are kind of four things
496.86|3.72|the attention operation is doing uh the
499.259|3.541|first one up here is it's generating
500.58|3.48|what are called keys values and queries
502.8|2.28|and again I'll get over the map in a
504.06|2.4|second I'm just trying to keep it high
505.08|4.559|level first
506.46|6.18|um and then we're going to compare our
509.639|4.681|query with each of the keys so the word
512.64|4.44|the Which is closest to the word we're
514.32|4.92|next predicting is our is our query and
517.08|6.0|we're seeing how similar it is each of
519.24|6.96|the uh key vectors
523.08|6.3|um we then based upon that similarity do
526.2|5.819|this uh softmax normalization so that
529.38|4.86|all of the uh attention weights so on
532.019|5.82|the one uh and then we sum together
534.24|5.34|their value vectors to use to propagate
537.839|3.961|to like the next layer or uses our
539.58|5.1|prediction
541.8|5.52|and so at a high level you can think of
544.68|4.74|this as like the query word the is
547.32|5.04|looking for nouns and their Associated
549.42|5.099|verbs and so hypothetically it has a
552.36|4.74|high similarity with words like cat and
554.519|4.38|sat or their keys
557.1|4.739|um so this then gives large weight to
558.899|4.201|the cat and sat value vectors uh which
561.839|2.221|get moved to the next part of the
563.1|3.12|network
564.06|4.14|um and the uh cat value Vector
566.22|4.14|hypothetically contains a superposition
568.2|5.34|of other animals like mice and maybe
570.36|5.099|words that rhyme with Matt and so uh and
573.54|5.22|the SAT Vector also contains things that
575.459|4.681|are sat on including that and so uh what
578.76|3.9|what you actually get from the value
580.14|6.36|vectors of paying attention to cat and
582.66|6.84|sat are um like three times mat plus one
586.5|4.32|times Mouse plus one time sofa this is
589.5|2.7|again like a totally hypothetical
590.82|4.019|example but
592.2|5.88|um I'm trying to make the point that you
594.839|4.801|can extract from your value vectors uh
598.08|2.759|things useful for predicting the next
599.64|4.62|token
600.839|5.401|um by paying attention specific keys
604.26|4.92|um
606.24|4.26|so and and I guess yeah another thing
609.18|3.24|here is like what you pay attention to
610.5|3.36|so cat and Stat might be different from
612.42|2.58|what you're actually extracting if
613.86|3.599|you're paying attention to your keys but
615.0|4.8|you're getting your value vectors out
617.459|5.221|um okay so here is the full attention
619.8|5.039|equation the the top line I'm separating
622.68|4.5|out the projector matrices uh W
624.839|3.481|subscript V A and Q and in the second
627.18|3.18|one I just collapse them and then
628.32|4.68|selected new Lac
630.36|4.919|um and
633.0|5.279|yeah so breaking this apart the first
635.279|5.281|step here is We compare we do a DOT
638.279|3.541|product between our query vector and our
640.56|2.64|keys
641.82|3.42|um this should actually be a small you
643.2|4.98|know
645.24|5.159|um and so yeah we're doing this dot
648.18|4.14|product between them to see get a notion
650.399|4.261|of similarity
652.32|4.38|um we then apply the softmax operation
654.66|3.6|which is an exponential over a sum of
656.7|3.36|exponentials
658.26|3.06|um the way to think of the stop Max is
660.06|4.38|it just makes
661.32|5.82|um large values larger and and this will
664.44|4.62|be important for the relation to SCM so
667.14|4.08|I'll spend a minute on it
669.06|5.219|um at the top here I have like some
671.22|5.4|hypothetical items indexed from uh zero
674.279|4.861|to nine and then the like values for
676.62|4.2|each of those items in the second row I
679.14|4.68|just do like a normal normalization of
680.82|6.3|them and so the top item goes to 30
683.82|5.04|value but if I instead do a stop map so
687.12|5.1|it depends on the medical condition the
688.86|4.979|soft Max but uh the value becomes 0.6 so
692.22|4.08|it just it makes you your distributions
693.839|4.021|Peak here is kind of one way of thinking
696.3|2.94|of it and and this is useful for
697.86|3.36|attention because you only want to pay
699.24|3.9|attention to the most important things
701.22|5.42|or the things that are nearby and kind
703.14|3.5|of ignore stuff further away
706.86|6.78|and so once we've applied our softmax
710.279|7.081|um we then uh just do a weighted
713.64|6.42|summation of our value vectors
717.36|6.44|which actually get extracted
720.06|3.74|um and propagate to the next layer
725.519|5.82|um okay so here's the the full equation
730.2|3.24|um I went through that a little bit
731.339|3.841|quickly I'm happy to answer questions on
733.44|3.36|it but I think half of you know it half
735.18|3.599|of you don't
736.8|3.719|um
738.779|3.361|okay
740.519|3.481|so how does Transformer attention
742.14|4.68|approximate sparse distributed memory
744.0|5.1|this 30 year old thing that I've said is
746.82|3.0|biologically plausible
749.1|3.739|um
749.82|3.019|so yeah
762.899|6.18|is five years ago uh I think the
766.56|4.44|attention equation I'm showing here was
769.079|3.661|developed I mean attention is all you
771.0|4.32|need was the highlight but benjio has a
772.74|4.8|paper from 2015.
775.32|3.36|where it was actually first written in
777.54|2.7|this way
778.68|3.599|correct me if I'm wrong but I'm pretty
780.24|4.68|sure yeah I mean I guess like this
782.279|4.86|particular one that's why I was asking
784.92|6.479|the question because like no it's a good
787.139|5.581|question that like two different methods
791.399|4.021|that could be classified as like
792.72|5.4|attention proposal is great for like the
795.42|5.419|same and like be selfish of it like one
798.12|6.12|of them that's like uh
800.839|5.021|yes exactly so I'll show that SDM has
804.24|3.719|really nice mappings to a circuit and a
805.86|4.44|cerebellum at the neural level
807.959|4.021|um and and then there's right now it's
810.3|3.12|this link to attention
811.98|2.34|um and I guess you you make a good point
813.42|3.0|that there are other attention
814.32|3.24|mechanisms this is the one that has been
816.42|2.28|dominant
817.56|2.82|um but I don't think that's just a
818.7|4.199|coincidence like there's been a bunch of
820.38|3.66|computing yourself Max is expensive and
822.899|3.12|there's been a bunch of work like the
824.04|4.14|linformer et cetera et cetera that tries
826.019|4.201|to get rid of the soft Max operation and
828.18|3.18|it's just done really badly
830.22|2.52|um like there's a bunch of jokes on
831.36|3.12|Twitter now that it's like a black hole
832.74|3.42|for people that like try and get rid of
834.48|3.72|softmax and you can't
836.16|3.66|um and so it seems like this and like
838.2|3.84|other versions of it Transformers just
839.82|4.079|don't scale as well in the same way and
842.04|5.72|so there's something important about
843.899|3.861|this particular attention equation
856.38|2.82|um
857.82|2.4|so the the thing that I think is
859.2|3.12|important is that you have this
860.22|3.359|exponential weighting uh where you're
862.32|2.519|really paying attention to the things
863.579|2.76|that matter and you're ignoring
864.839|4.44|everything else
866.339|6.361|um and that is what SDM approximates
869.279|5.281|um there might be equations but the the
872.7|3.3|point I was just trying to make there is
874.56|3.06|like the softmax does seem to be
876.0|3.36|important and this equation does seem to
877.62|2.94|be very successful
879.36|4.339|um and we haven't come up with better
880.56|3.139|formulations for
884.22|4.919|yeah no it's a great question
886.139|6.481|um okay so it turns out that sparse
889.139|5.581|distributed memory uh as you move your
892.62|4.2|query and your pattern away from each
894.72|4.38|other so you pull these these circles
896.82|3.66|apart they'll read and write circles the
899.1|3.299|number of neurons that are in this
900.48|4.44|intersection in a sufficiently high
902.399|5.401|dimensional space the K is approximately
904.92|5.76|exponentially and so on this right plot
907.8|4.8|here I'm pulling apart the x-axis is
910.68|6.18|pulling apart the blue and the green
912.6|6.539|circles and the y-axis is uh on a log
916.86|5.039|scale the number of neurons that are in
919.139|4.921|the intersection and so to the extent
921.899|5.401|that this is the linear plot on a log
924.06|4.139|scale it's exponential
927.3|3.24|um
928.199|4.38|and and this is for a particular setting
930.54|5.099|where I have my I have 64 dimensional
932.579|5.101|vectors which is like used in gdp2
935.639|3.901|um it it holds across a lot of different
937.68|4.019|settings particularly higher Dimensions
939.54|3.9|uh which are now used for bigger
941.699|5.221|Transformers
943.44|5.759|um okay so I have this shorthand for the
946.92|6.06|circle intersection equation
949.199|5.64|um and what I'll show is how the circle
952.98|3.599|intersection is approximately
954.839|4.201|exponential
956.579|4.62|um so we can invite a two constant C so
959.04|5.039|if you're one it's like you have two
961.199|4.801|um with the the one outside because
964.079|3.781|you're normalizing softmax is
966.0|3.959|exponential over some extenticals that
967.86|4.08|will cancel the thing that matters is C2
969.959|4.74|and you can approximate that nicely with
971.94|4.5|the beta coefficient that's used in the
974.699|3.061|softmax
976.44|4.44|um
977.76|4.86|and so yeah I guess as well I'll Focus
980.88|2.94|first on the binary original version of
982.62|2.88|sem
983.82|2.819|um but then we also develop a continuous
985.5|1.86|version
986.639|3.781|um
987.36|4.919|okay so yeah the the two things that you
990.42|4.02|need for the circle intersection
992.279|4.441|um and the exponential decay to work are
994.44|4.259|you need to map it to attention is you
996.72|4.14|need some notion of a continuous space
998.699|4.2|and so you can use this equation here to
1000.86|4.44|map handing distances
1002.899|3.901|um to discretize proton similarity
1005.3|3.479|values
1006.8|5.099|um where the hats over the vectors are
1008.779|6.36|are L2 normalizations
1011.899|5.761|um and you can then write the circle
1015.139|7.2|intersection equation on the left
1017.66|7.32|um as this exponential with these these
1022.339|4.74|two concepts that you need to learn and
1024.98|4.74|and then rewrite this by converting C2
1027.079|4.86|and C you can write this in the data
1029.72|4.739|coefficient
1031.939|3.721|um let me get to some plots
1034.459|2.88|um yeah so so you need the correct
1035.66|5.039|coefficient but you can fit this with a
1037.339|4.74|log linear regression in a closed form
1040.699|3.301|um
1042.079|5.701|I want to show a plot here
1044.0|5.58|yeah okay so uh and the blue is our
1047.78|3.6|Circle intersection for two different
1049.58|3.479|ending distances both using 54
1051.38|4.799|dimensional vectors
1053.059|5.641|um and the Orange is our actual softmax
1056.179|5.401|detention operation where we fit the
1058.7|5.099|beta coefficient so that it will it will
1061.58|4.2|the hammock distance used by attention
1063.799|3.721|is equivalent to the heaviest infused by
1065.78|4.019|SDM
1067.52|5.94|um and you can see so that the main plot
1069.799|5.701|is uh the normalized weights so this
1073.46|4.5|um summed up and undivided system one
1075.5|5.78|and then I block blocks here
1077.96|7.26|um and you can see that in not log space
1081.28|6.34|the curves agree quite nicely uh you can
1085.22|4.5|see that for the higher dimensional uh
1087.62|4.559|sorry the larger heavy distance the long
1089.72|4.26|plot you see this uh drop off here over
1092.179|3.901|the circle intersection stops being
1093.98|4.079|exponential uh but it turns out this
1096.08|5.16|actually isn't a problem because the
1098.059|5.401|point at which the drop the uh
1101.24|5.34|exponential breaks down you're at
1103.46|5.219|approximately 0.20 here and you're
1106.58|4.86|basically paying negligible attention to
1108.679|5.461|any of those points and so in the regime
1111.44|5.34|where the exponential really matters uh
1114.14|5.18|this approximation holds true
1116.78|2.54|um yeah
1120.86|5.64|yeah
1123.22|4.72|yeah yeah no I I just wanted to actually
1126.5|2.64|like show up in here to get some
1127.94|3.599|question
1129.14|3.12|um before yeah
1131.539|2.461|um
1132.26|3.659|so all we're doing here is we're just
1134.0|4.14|we're in a binary space with original
1135.919|4.741|velocity um and we're just using this
1138.14|5.88|similarity
1140.66|6.12|um and then what you need to do is just
1144.02|4.08|have the beta book and you can view your
1146.78|3.42|beta coefficient and attention that's
1148.1|4.199|determining how geeky things are and
1150.2|4.2|this relates directly to the having the
1152.299|5.12|sense of your um circles that you're
1154.4|3.019|using for me to write on version
1158.38|5.08|and so yeah to like mathematically show
1161.48|3.66|this now on this slide I'm not using any
1163.46|4.26|tricks I'm just rewriting attention
1165.14|4.2|using the sem notation of patterns and
1167.72|4.319|players
1169.34|5.839|um so this little box down here is is
1172.039|3.14|doing that nothing
1177.2|5.52|and this is the money slide where we're
1180.74|4.62|updating our query
1182.72|5.52|and on the left we have our extension
1185.36|6.059|equation written in SEO notation uh we
1188.24|4.62|expand our top hacks and then the the
1191.419|3.901|main statement is this is closely
1192.86|5.34|approximated by if we swap out our
1195.32|5.78|exponential with the sem sort of order
1198.2|2.9|section equation
1208.48|3.819|foreign
1210.2|5.219|so and again the two things that you
1212.299|5.641|need for this to work are one your
1215.419|4.62|attention vectors your um keys and
1217.94|3.72|queries need to be able to mobilized so
1220.039|4.26|I got hats on them
1221.66|4.379|um and then you want
1224.299|3.541|if you decide if they're going to panic
1226.039|3.841|distance for SCM and I'll get into what
1227.84|3.18|having distance are good for different
1229.88|3.36|things
1231.02|4.38|um then you need to have a beta
1233.24|3.84|coefficient that relates to it
1235.4|3.899|but again that's just how many things
1237.08|4.28|are you trying to pay attention to
1239.299|2.061|um
1244.28|4.92|so yeah just as a quick side note
1247.52|3.36|um you can write sdn using continuous
1249.2|3.66|vectors and then not need this mapping
1250.88|2.82|to cosine similarity
1252.86|3.72|um
1253.7|4.8|and so here I have the plots again but
1256.58|5.04|with this and
1258.5|4.98|um I've added the
1261.62|3.6|the orange of the Granite splits what
1263.48|3.6|I've added the continuous approximation
1265.22|3.86|here too
1267.08|2.0|um
1269.84|3.54|and what's nice about the continuous
1271.58|3.24|version is you can actually then write
1273.38|3.6|sparse distributed memory as a
1274.82|3.78|multi-layered perceptron with slightly
1276.98|2.76|different assumptions
1278.6|2.939|um and I'm not going to talk about that
1279.74|3.72|now but
1281.539|3.481|um this is featured in as far as three
1283.46|2.76|memory is a continual learner which is
1285.02|3.42|uh it was added to the additional
1286.22|4.56|readings and it'll be in um sorry this
1288.44|2.88|shouldn't say icml it should say iClear
1290.78|2.279|um
1291.32|4.14|it was it's just been accepted to like
1293.059|6.541|there for this year
1295.46|6.36|um okay so do trained Transformers use
1299.6|5.52|these beta coefficients that I've said
1301.82|4.92|are similar to those for SDI
1305.12|3.179|um and so
1306.74|2.46|it shouldn't be surprising that
1308.299|2.701|depending on the how many distance
1309.2|3.06|you've set SCM is better for certain
1311.0|2.58|things
1312.26|2.399|um for example
1313.58|2.82|um you just want to store as many
1314.659|4.741|memories as possible and you're assuming
1316.4|4.259|that your queries aren't noisy or um you
1319.4|3.12|you're assuming your queries are really
1320.659|4.321|noisy so you can't store as much but you
1322.52|5.159|can retrieve from a long distance
1324.98|4.079|um and if attention to the Transformer
1327.679|3.48|is implementing sparse distributed
1329.059|3.721|memory we should expect to see that the
1331.159|4.5|beta coefficients that the Transformer
1332.78|6.48|uses correspond to these good instances
1335.659|6.0|of STM and so we have some weak evidence
1339.26|5.039|that that's the case
1341.659|4.561|um so this is the key query normalized
1344.299|3.781|variant of attention where you actually
1346.22|3.54|learn your beta coefficient normally in
1348.08|4.14|Transformers you don't
1349.76|3.779|um but you don't LG Norm your vectors
1352.22|3.36|and so you can kind of have this like
1353.539|3.481|effective beta coefficient so in this
1355.58|4.44|case it's the cleaner instance where
1357.02|4.56|we're actually learning beta and this
1360.02|3.899|one's um trended on a number of
1361.58|3.959|different translation tasks we take the
1363.919|4.64|learner benefit coefficients across
1365.539|3.02|layers and across
1370.72|4.6|three different Notions of sports
1373.46|2.839|distributed memory that are optimal for
1375.32|5.4|different things
1376.299|8.62|and again this is weak evidence in so
1380.72|5.579|much is to derive the optimal fcm beta
1384.919|3.961|coefficients or corresponding handing
1386.299|4.62|distances we need to assume uh random
1388.88|4.14|patterns in this High dimensional space
1390.919|3.301|and like obviously real world data isn't
1393.02|3.899|random
1394.22|4.68|um however it is nice to see one all the
1396.919|4.981|beta coefficients fall within the bounds
1398.9|4.32|and two they skew towards the max very
1401.9|3.36|noise
1403.22|3.56|um which makes more sense if you're
1405.26|3.96|dealing with like complicated real world
1406.78|4.06|where the next data points you see might
1409.22|3.06|be out of distribution based what you've
1410.84|3.06|seen in the past
1412.28|4.139|um the max memory capacity variant
1413.9|4.139|assumes no query noise at all and so
1416.419|4.021|it's like how many things can I pack in
1418.039|4.081|assuming that my the the questions I'm
1420.44|3.359|asking the system are are perfectly
1422.12|3.799|formed
1423.799|2.12|um
1425.96|3.54|okay
1428.179|3.781|um just talking a little bit about
1429.5|3.24|Transformer components more broadly
1431.96|2.94|um
1432.74|4.559|so I've mentioned that you can write the
1434.9|5.1|feed forward layer as a version of SDM
1437.299|5.281|that has like a sort of notion of longer
1440.0|4.74|term memory
1442.58|4.02|um there's also layer Norm which is
1444.74|3.72|crucial in Transformers
1446.6|3.42|um and it's not quite the same but it
1448.46|5.16|can be related to the L2 normalization
1450.02|5.34|that's required by SDM there's also the
1453.62|2.88|key query normalization variant that
1455.36|2.76|explicitly does this helps you
1456.5|3.6|normalization and it does get slightly
1458.12|3.72|better performance at least on the small
1460.1|3.48|test that they did
1461.84|3.48|um I don't know if this would scale to
1463.58|2.959|larger models
1465.32|4.739|um
1466.539|4.781|and so I guess this work is interesting
1470.059|2.581|and so much as like the biological
1471.32|4.26|possibility which I'm about to get to
1472.64|5.34|and then the the links to Transformers
1475.58|4.02|it hasn't to date improved Transformer
1477.98|3.48|architectures but that doesn't mean that
1479.6|3.6|this lens couldn't be used or be useful
1481.46|4.56|in some way
1483.2|4.68|um so yeah I list a few other way things
1486.02|3.96|that SDM is related to that could be
1487.88|3.96|used to funnel in and actually in the
1489.98|4.02|the new work where SDM is a continual
1491.84|3.66|learner we kind of expand the cerebellar
1494.0|3.659|Circuit look at components of it
1495.5|4.02|particularly inhibitory interneurons
1497.659|3.781|Implement those in a deep learning model
1499.52|3.899|and it then becomes much better at
1501.44|4.14|continual learning so that was kind of a
1503.419|5.221|fun way of actually using this link to
1505.58|7.44|get better bottom line performance
1508.64|5.7|um okay so a summary of this section uh
1513.02|4.2|is basically just the intersection
1514.34|5.219|between two hyperspheres uh approximates
1517.22|3.959|an exponential
1519.559|4.141|um and this allows sdm's read and write
1521.179|5.761|operations to approximate attention both
1523.7|5.28|in theory and our limited tests
1526.94|3.599|um and so kind of like big picture
1528.98|3.78|research questions that could come out
1530.539|4.561|of this is uh first is the Transformer
1532.76|4.68|so successful because it's performing
1535.1|4.74|some key cognitive operation
1537.44|4.979|um the cerebellum is a very old brain
1539.84|4.26|region used by most organisms including
1542.419|3.781|fruit flies
1544.1|5.1|um maybe even cephalopods through like
1546.2|6.18|Divergent but now convergent evolution
1549.2|5.64|um and then given that the Transformer
1552.38|4.62|has been so successful empirically is
1554.84|3.9|SDM actually the correct theory for
1557.0|5.1|cerebellar function
1558.74|4.02|um and that's still an open question
1562.1|1.92|um
1562.76|2.399|as we learn more and more about the
1564.02|4.019|cerebellum there's nothing that yet
1565.159|4.741|disproves SDM as as working there and I
1568.039|2.88|think it's I'll go out on a limb and say
1569.9|2.1|it's like one of the more compelling
1570.919|2.461|theories for how this error button is
1572.0|2.039|actually working
1573.38|2.94|um
1574.039|3.961|yeah and so I think this this work kind
1576.32|2.82|of motivates looking at more of these
1578.0|3.0|questions both of these questions are
1579.14|3.419|more seriously
1581.0|3.419|um okay
1582.559|3.24|do we have do we have time
1584.419|4.201|cool
1585.799|4.62|um so here's the circuit that implements
1588.62|5.4|hastion
1590.419|6.181|um at the bottom we have patterns coming
1594.02|4.139|in for either reading or writing
1596.6|3.0|and they're gonna actually I break down
1598.159|3.781|each of these slides
1599.6|5.34|okay yeah so so first we have patterns
1601.94|5.219|that come in and every neuron here these
1604.94|3.479|are the dendrites of each neuron and
1607.159|3.421|they're deciding whether or not they're
1608.419|4.281|going to fire for the input that comes
1610.58|2.12|in
1614.059|6.0|then if the neuron does fire and you're
1617.779|4.26|writing in that pattern then you
1620.059|3.901|simultaneously and I'm going to explain
1622.039|4.081|this is crazy the brain doesn't do this
1623.96|3.48|and I'm going to hopefully take it on
1626.12|4.14|um you not only need to have the main
1627.44|4.859|but the pattern that um activates no
1630.26|5.7|problems but you need to have a separate
1632.299|4.62|line that tells the normal to soar and
1635.96|2.88|just like you have this difference
1636.919|3.721|between keys and values where they can
1638.84|4.5|be different vectors representing
1640.64|5.1|different things here you can have a key
1643.34|4.8|that comes in and tells a neuron when to
1645.74|5.16|activate and the value for what it
1648.14|4.86|should actually like soar this is called
1650.9|2.82|a hetero associative mapping
1653.0|3.9|um
1653.72|3.959|and then once you're reading from the
1656.9|2.899|system
1657.679|5.521|you also have your query come in here
1659.799|6.401|activate neurons and those neurons then
1663.2|5.219|output whatever they stored and the
1666.2|5.219|neurons Vector is is this a particular
1668.419|4.62|column that's it's stored and it's that
1671.419|3.601|reminder as a reminder it's storing
1673.039|4.26|patterns in super conception
1675.02|5.519|um and then it will dump whatever it's
1677.299|6.301|stored across these out what lines
1680.539|5.52|and then you have this G
1683.6|4.26|um majority bit operation to converts to
1686.059|3.6|a zero one decided the neuron is going
1687.86|4.38|to fire or not
1689.659|5.64|um and so
1692.24|7.28|here is the same circuit but where I
1695.299|4.221|overlay uh cell types
1699.62|3.539|um and so
1701.299|3.48|I'll come back to this slide because
1703.159|3.661|most people probably aren't familiar
1704.779|4.821|with cerebellar circuitry
1706.82|2.78|um let me just
1709.88|4.98|get some water
1711.44|5.82|um okay so the way that the cerebellum
1714.86|4.74|is um pretty homogeneous and then it
1717.26|4.38|follows the pattern throughout
1719.6|3.48|um also fun fact 70 of all neurons in
1721.64|3.0|the brain are in the cervo
1723.08|2.94|um they're small so you wouldn't know it
1724.64|2.76|but the cerebellum's like very
1726.02|2.88|underappreciated and there's a bunch of
1727.4|3.6|evidence and it has a closed loop
1728.9|4.32|systems with most higher order
1731.0|3.659|um processing now if your cerebellum is
1733.22|2.459|damaged you are more likely to have
1734.659|2.64|autism
1735.679|3.841|etc etc so it does a lot more than just
1737.299|4.321|fine motor coordination uh which a lot
1739.52|3.96|of people have like assumed in the past
1741.62|4.26|um okay so inputs come into the muscle
1743.48|4.559|fibers here they interface with granular
1745.88|4.2|cells this is a major up production
1748.039|2.941|where you have tons and tons of random
1750.08|2.88|cells
1750.98|4.5|each Rhino cell has what are called
1752.96|5.099|parallel fibers which is incredibly long
1755.48|4.079|and thin Maxwells that Branch out in
1758.059|5.34|this T structure
1759.559|6.6|and then they they're hit by the
1763.399|6.0|purkinje cells which will receive up to
1766.159|5.52|a hundred thousand parallel fiber inputs
1769.399|3.841|it's the highest connectivity of any
1771.679|3.48|neuron brain
1773.24|4.62|um and then the purkinje cell will
1775.159|4.861|decide whether or not fire and send its
1777.86|4.199|output downwards here
1780.02|3.659|so that's the whole uh system where
1782.059|3.36|patterns come in and around Society they
1783.679|3.48|find it or not and the way that they
1785.419|3.721|then output they're out
1787.159|4.201|you then have a separate right line
1789.14|4.08|which is the climate virus so the
1791.36|3.36|climbing Fighters come up and they're
1793.22|2.64|pretty amazing in that these connections
1794.72|2.579|here you can have in order they're not
1795.86|3.179|as important the one that really matters
1797.299|3.12|is that they're not very strong either
1799.039|3.781|but what it really matters is it goes up
1800.419|4.98|and it wraps around individual profanity
1802.82|3.599|cells and the mapping is close to one to
1805.399|2.821|one
1806.419|3.36|um between climbing fibers and potential
1808.22|4.38|cells at least a very strong Action
1809.779|6.721|potentials and so an air connections
1812.6|6.42|here is uh as in the stuff off the side
1816.5|3.899|yeah right with these two alignments
1819.02|3.12|they're connecting two arms oh so
1820.399|3.421|they're separate neurons coming from in
1822.14|3.48|separate areas
1823.82|3.3|um particular calls here go into Deep
1825.62|4.74|Cell relatively I kind of when the
1827.12|5.1|coreless are on and that then feeds into
1830.36|3.36|um Thalamus like back to higher order
1832.22|3.72|brain regions or like Jonathan mustard
1833.72|4.199|muscle movement Etc
1835.94|4.02|um a lot of people think of the
1837.919|4.081|cerebellum is kind of like a fine-tuning
1839.96|3.54|lookup table where like you've already
1842.0|3.6|decided the muscle movement you want to
1843.5|3.72|do but the cerebellum will then like do
1845.6|3.9|a bunch of adjustment adjustments so
1847.22|3.78|that's like much more accurate
1849.5|3.899|um but it seems like this also applies
1851.0|4.44|to like next word prediction like we
1853.399|3.301|have fmri data for this a neuroscientist
1855.44|4.44|once that's made like a dirty little
1856.7|4.8|secret of fmri is that uh the Starbomb
1859.88|4.44|lights up for everything
1861.5|3.72|um so okay
1864.32|4.02|um
1865.22|6.42|going back to this circuit here then
1868.34|5.04|um yeah time scales are these operating
1871.64|4.919|at I mean how long is the information
1873.38|4.86|stored and retrieved to be have any idea
1876.559|3.301|about this
1878.24|4.319|um like it's just like a couple of
1879.86|7.14|milliseconds or like consideration more
1882.559|6.661|persistent so the main theory is that
1887.0|5.76|you have updating through
1889.22|6.059|um uh time to pass dependent plasticity
1892.76|4.2|where your climbing fiber will either
1895.279|4.26|which is doing the what you want to
1896.96|6.3|write in will fire either just before or
1899.539|5.941|just after uh your rhino cell spider
1903.26|4.26|um and so that then updates the
1905.48|3.9|prevention cell finances for long-term
1907.52|3.06|depression
1909.38|3.179|um so whatever time scale that's
1910.58|4.199|happening on the quality fiber makes
1912.559|5.041|very large potentials
1914.779|4.861|um or it leads to very large
1917.6|4.439|and so I do think you could get a pretty
1919.64|4.62|fast scientific updates and they're also
1922.039|4.26|persistent for a long time
1924.26|5.779|um I think so yeah it's Finance it can
1926.299|3.74|stay for like the rest of your life yeah
1930.32|4.44|so what's really unique about this
1932.659|5.941|circuit is the fact that you have these
1934.76|5.1|two orthogonal uh inputs where you have
1938.6|3.36|the muscle fibers bringing information
1939.86|3.66|in to the side of the neurons on fire or
1941.96|3.9|not but then the totally separate
1943.52|4.259|chronic fiber lines that can update
1945.86|3.419|specific neurons
1947.779|3.721|um and what they're storing and will
1949.279|4.321|later outline and then the Protege cell
1951.5|5.179|is is so important that's kind of doing
1953.6|5.459|this cooling across every single neuron
1956.679|4.421|and each neuron remember it's storing a
1959.059|5.521|vector this way and so the purkinje cell
1961.1|5.939|is doing element-wise summation and then
1964.58|3.599|deciding whether it fires or not and
1967.039|3.301|this allows for you to store your
1968.179|5.061|vectors in superposition and then later
1970.34|2.9|denoise them
1975.44|3.9|this this all this the theory that's the
1977.6|3.6|only Maps quite well to the um more and
1979.34|3.42|all those theories of solar power
1981.2|5.18|function which are still quite dominant
1982.76|3.62|if anyone's familiarism
1986.799|6.061|neuron and the SDM you're introduced
1989.0|3.86|before each neurons
1995.12|4.02|okay
1996.32|4.459|um and then yeah so the the location of
1999.14|3.3|the neuron those Hollow circles
2000.779|2.921|corresponds to the graduates of
2002.44|3.18|dendrites here
2003.7|3.06|where the patterns that pop in
2005.62|5.52|correspond to the activations of
2006.76|6.899|modifiers and then the uh efforts
2011.14|5.399|um postsynaptic connections are with
2013.659|5.221|deeper into zone so that's actually it's
2016.539|5.821|what it's storing is in the synaptic
2018.88|5.1|connections with the ending cells at
2022.36|3.12|that interface
2023.98|2.939|and then the purkinje cell does the
2025.48|4.46|majority bit operation inside of
2026.919|3.021|velocifier or not
2036.039|5.101|yeah yeah
2038.76|6.659|I think we're basically into into
2041.14|4.279|question time so yeah thanks a lot
2053.44|6.959|of anything about this meeting but it
2056.56|7.2|seems as other students for a long time
2060.399|6.121|and uh I am curious what's your
2063.76|5.76|hypothesis or what we should be doing
2066.52|5.099|for sure development really
2069.52|4.92|because it seems that
2071.619|5.52|so if you have this link of Transformers
2074.44|4.08|yeah I think long-term memory yeah well
2077.139|3.72|that's good for a short-term memory
2078.52|4.619|because for me it seems like we are
2080.859|5.101|doing this in the prompt context right
2083.139|3.861|now but how could we incorporate these
2085.96|4.02|together
2087.0|5.02|yeah yeah so this work actually focuses
2089.98|4.619|more on the short-term memory oh where
2092.02|5.64|it relates to the attention operation
2094.599|4.801|um but you can rewrite SDM it's almost
2097.66|4.02|more natural to interpret it as a multi
2099.4|4.62|perceptron that does like a soft Max
2101.68|4.439|activation across its or a top pay
2104.02|3.36|activation across its um neurons it's
2106.119|2.461|like a little bit more complicated than
2107.38|1.979|that but
2108.58|4.32|um
2109.359|5.041|yeah so so the the yeah the most
2112.9|4.08|interesting thing here is the fact that
2114.4|4.74|like I just have a bunch of neurons and
2116.98|4.139|in activating nearby neurons in this
2119.14|3.78|title control space you get this
2121.119|3.96|exponential weighting which is the soft
2122.92|3.54|mass and then because it's an Associated
2125.079|4.381|memory where like you have keys and
2126.46|6.18|values it is attention
2129.46|4.5|um and yeah I guess like the the thing I
2132.64|3.54|most want to drive home from this is
2133.96|4.32|like it's actually surprisingly easy for
2136.18|4.62|the brain to implement the attention
2138.28|5.64|operation the attention operation
2140.8|5.22|um just using High Dimensions vectors
2143.92|5.159|and activating
2146.02|4.8|so it's good for short-term money
2149.079|4.681|um yes if you were if you were actually
2150.82|5.82|use sem for attention
2153.76|4.68|um yeah so let me go all the way back
2156.64|3.479|real quick this is important there are
2158.44|3.179|kind of two ways of viewing SDM and I
2160.119|2.641|don't think you were here for the talk I
2161.619|4.321|think I saw you come in a bit later
2162.76|7.14|which is totally fine but I was uh
2165.94|5.82|oh cool cool yeah yeah okay so so there
2169.9|3.48|are two ways of looking at sem there's
2171.76|4.02|the neuron perspective
2173.38|3.84|which is this one here
2175.78|3.24|um and this is actually what's going on
2177.22|3.06|in the very important
2179.02|3.36|um and so the only thing that
2180.28|4.02|interactive concept is the neurons the
2182.38|4.02|patterns are a funnel
2184.3|3.72|um and then there's the pattern-based
2186.4|3.0|perspective which is actually what
2188.02|4.14|attention is doing
2189.4|3.959|and so here you're abstracting away the
2192.16|2.82|neurons we're assuming they're operating
2193.359|4.98|under the hood but what you're actually
2194.98|4.98|Computing is the distance between the
2198.339|4.981|true location of your pattern and
2199.96|6.119|aquarium and there are pros and cons to
2203.32|4.62|both of these the pro to this is you get
2206.079|3.961|much higher Fidelity
2207.94|3.96|um distances but you know exactly how
2210.04|3.12|far the query is from the original
2211.9|2.459|patterns
2213.16|2.52|um and that's really important when
2214.359|3.361|you're deciding what to update for it
2215.68|3.899|like you really want to make know like
2217.72|3.899|what is closest and what is further away
2219.579|3.841|and be able to apply the exponential
2221.619|3.72|weighting correctly
2223.42|3.3|um the problem is you need to store all
2225.339|3.301|of your pattern notifications in memory
2226.72|4.32|and so this is why Transformers have
2228.64|4.02|like limited context Windows
2231.04|3.539|um the other perspective is this
2232.66|4.08|long-term memory one where you forget
2234.579|4.801|about the patterns and you just look at
2236.74|4.5|where uh you just have your neurons that
2239.38|4.92|store a bunch of patterns and another is
2241.24|4.74|an organ superposition and so you can't
2244.3|3.9|really you can tiny like when people
2245.98|5.639|compiler was like not funny that it's
2248.2|4.62|all much noisier but you can store tons
2251.619|3.421|of patterns and you're not concerned by
2252.82|4.74|contacts or you can think of any penalty
2255.04|5.819|layer a story like the entire data set
2257.56|4.32|in a noisy superposition of States
2260.859|3.301|um
2261.88|3.12|yeah hopefully that kind of answers your
2264.16|3.78|question
2265.0|3.839|I think there's one here at first yeah
2267.94|5.399|um
2268.839|6.601|so I guess my question is like uh so I
2273.339|4.921|guess like we've been kind of Ensure
2275.44|6.899|them that like the uh modern like
2278.26|7.859|self-attention method is um it's like uh
2282.339|5.401|SPM mechanism that like seems possible
2286.119|3.601|it might look like the modern
2287.74|6.839|contemporary like theories of like how
2289.72|6.6|the brain is definitely SEO and I guess
2294.579|4.621|my question is like
2296.32|5.4|um to what degree is that like that like
2299.2|4.26|it's originally verified versus like you
2301.72|3.66|were like mentioning earlier that like
2303.46|4.379|it might actually be easier to have done
2305.38|3.9|this using like an MLP layer in some
2307.839|3.141|sense then like
2309.28|5.46|yeah
2310.98|5.8|and so like how to experimentalists like
2314.74|4.32|actually distinguishing and meeting pet
2316.78|4.5|offices yeah like for instance like one
2319.06|5.1|thing that like I wasn't incredibly
2321.28|4.22|clear about it's like like
2324.16|4.439|even it's like
2325.5|4.78|two attention or like SEO like that
2328.599|5.341|doesn't actually mean it would because
2330.28|4.76|like maybe it can't be back up yeah
2333.94|3.659|um so like
2335.04|5.86|how does this like get actually tested
2337.599|4.5|totally yeah yeah so uh on the back prop
2340.9|1.74|Point
2342.099|2.701|um
2342.64|3.9|you wouldn't have to do it here because
2344.8|4.86|you have the climbing fibers that can
2346.54|5.94|directly like give drainage signals
2349.66|4.8|um to like what the neurons can store
2352.48|3.599|um so so in this case you
2354.46|3.3|it's like a supervised learning task
2356.079|3.181|where the funny partner knows what it
2357.76|4.68|wants to write in or like how it should
2359.26|5.64|be opted in the prefinity cell synapses
2362.44|5.46|um but for your broader Point
2364.9|4.62|um you basically need to do to test this
2367.9|3.48|you need to be able to do
2369.52|3.48|um real-time learning
2371.38|4.08|um the drosophila mushroom body is
2373.0|4.2|basically identical to the cerebellum
2375.46|3.6|um and the Fly I mean brain data set has
2377.2|3.72|done most of the individual neuron
2379.06|5.58|connectivity but what you would really
2380.92|5.58|want to do is like any vitro real time
2384.64|5.219|um super like um
2386.5|5.76|super super high frames per seconds
2389.859|5.701|um calcium Imaging
2392.26|5.579|um and be able to see how sinuses change
2395.56|3.84|over time and and so for an associative
2397.839|4.681|learning task like
2399.4|5.88|um hear a sound move left hear another
2402.52|4.92|sound move right or smells or whatever
2405.28|4.319|um present one of those
2407.44|4.02|um Trace like figure out the small
2409.599|3.361|subset of neurons that fire which we
2411.46|3.84|know is a small subset so that already
2412.96|5.879|picks up
2415.3|5.58|um see how the synapses here update and
2418.839|4.561|how the outputs of it correspond to
2420.88|5.52|changes in motor action
2423.4|5.04|um and then extinguish that number so
2426.4|4.08|write in a new one and then watch it
2428.44|4.8|watch it go away again
2430.48|4.5|um and like our cameras are getting fast
2433.24|3.0|enough and like our calcium and like
2434.98|3.06|voltage indicators are getting to be
2436.24|3.839|really good so hopefully in the next
2438.04|3.299|like three to five years we can do some
2440.079|2.221|of those tests
2441.339|2.221|um but I think that would be very
2442.3|3.86|definitive
2443.56|2.6|yeah
2447.82|3.0|yeah do we have any other questions I
2449.74|3.2|think there was one more and then I
2450.82|2.12|should
2476.76|4.96|yeah so uh I wouldn't get confused with
2479.859|3.661|multi-headed events
2481.72|3.72|um because that's different attention
2483.52|4.14|heads all doing their own attention
2485.44|4.56|operation it's funny though the servo
2487.66|4.08|has micro zones which you can think of
2490.0|3.66|as like separate attention heads in a
2491.74|4.26|way I don't want to take that analogy
2493.66|3.9|too far in life but but it is it is
2496.0|4.68|someone interesting
2497.56|4.019|um so the way you relate this is
2500.68|2.64|um
2501.579|3.0|inattention you have your beta
2503.32|4.259|coefficient
2504.579|5.941|um that is an effective data coefficient
2507.579|5.581|because the vector Norms of your keys
2510.52|6.02|and queries aren't constrained
2513.16|6.36|um that corresponds to a Heming distance
2516.54|5.44|and here that corresponds to the number
2519.52|4.44|of neurons that are on for any given
2521.98|5.4|input
2523.96|5.1|um and the heavy distance you want I had
2527.38|3.18|that slide before
2529.06|3.9|um depending instances you want depends
2530.56|3.539|upon what you're actually trying to do
2532.96|3.119|um and if you're not trying to store
2534.099|3.48|that many memories for example you have
2536.079|4.141|a higher ending distance because you can
2537.579|4.441|get a higher Fidelity calculation for
2540.22|3.48|the number of neurons in that noisy
2542.02|4.28|intersection
2543.7|2.6|um yeah
2546.46|4.1|cool yeah thanks a lot excellence
2553.0|4.099|so as a disclaimer uh
2557.2|3.18|so as a disclaimer uh before I introduce
2559.18|2.52|your next speaker uh the person was
2560.38|3.06|scheduled unfortunately the cat and sold
2561.7|3.18|last minute due to faculty interviews so
2563.44|2.88|our next speaker has very graciously
2564.88|2.28|agreed to present at the very last
2566.32|2.46|minute
2567.16|2.939|um but we are very grateful to him so
2568.78|4.38|I'd like to introduce everybody to will
2570.099|4.681|so will is a computational neuroscience
2573.16|2.64|machine learning PhD student at the
2574.78|2.94|University College of London at their
2575.8|3.299|Gatsby unit so I don't know if anybody
2577.72|3.24|has heard about the Gatsby unit I'm a
2579.099|3.121|bit of a history buff or a history nerd
2580.96|2.82|depending on how you phrase it the
2582.22|3.899|Gatsby unit was actually this incredible
2583.78|4.14|Powerhouse in the 1990s and 2000s so
2586.119|3.0|Hinton used to be there Zubin garamana
2587.92|2.399|used to be there he's now in charge of
2589.119|2.521|Google research
2590.319|2.821|um I think they've done a tremendous
2591.64|3.0|amount of good work
2593.14|3.0|um anyways and and now I'd like to
2594.64|2.76|invite will to talk about how to build a
2596.14|2.64|cognitive map
2597.4|3.54|uh did you want to share your screen
2598.78|4.14|yeah okay um can you stand in front of
2600.94|3.659|here let me stop sharing
2602.92|3.659|okay
2604.599|4.381|uh so I'm gonna be presenting this uh
2606.579|4.861|what it's a it's all about how a model
2608.98|5.28|that people in the group that I work
2611.44|6.06|with uh to study the hippocampalendarino
2614.26|4.319|system uh completely independently uh
2617.5|3.18|turned out to look a bit like a
2618.579|3.181|Transformer so that's this paper that
2620.68|3.48|I'm going to talk about is describing
2621.76|3.72|that link and so the paper that built
2624.16|3.48|builds this link is by these three
2625.48|4.26|people uh James is a postdoc half at
2627.64|4.199|Stanford uh Sims a professor at Oxford
2629.74|4.52|and in London and Jose a PhD student in
2631.839|2.421|London so
2634.72|6.66|uh so this is the problem that uh the
2638.7|4.54|the this model of the hippocampus Rhino
2641.38|3.18|system which we'll talk more about uh is
2643.24|2.52|supposed to solve it's basically the
2644.56|3.24|observation there's a lot of structure
2645.76|3.18|in the world and generally we should use
2647.8|2.94|it in order to generalize quickly
2648.94|4.02|between tasks it's the kind of thing I
2650.74|4.14|mean by that is you know how 2D space
2652.96|4.08|works because of your long experience
2654.88|4.08|living in the world and so if you start
2657.04|3.18|at this greenhouse and step North it's
2658.96|2.7|orange one and so there's red ones
2660.22|3.119|there's the pink one because of the
2661.66|3.6|structural 2D space
2663.339|3.901|you can think to yourself oh what will
2665.26|2.94|happen if I step left and you know that
2667.24|2.879|you'll end up back at the green one
2668.2|5.399|because Loops of this type close in 2D
2670.119|5.101|space okay and uh this is you know
2673.599|3.24|perhaps this is a new city you've just
2675.22|4.22|arrived in this is like a zero shop
2676.839|4.561|generalization because you uh somehow
2679.44|4.0|realize that the structure applies more
2681.4|4.08|broadly and use it in a new context
2683.44|3.24|uh yeah and there's generally a lot of
2685.48|2.58|these kinds of situations where there's
2686.68|3.24|structures that like reappear in the
2688.06|3.6|world so I mean lots of instances where
2689.92|2.76|the same structure will be useful to
2691.66|2.699|doing these like zero shot
2692.68|2.76|generalizations uh to predict what
2694.359|2.581|you're going to see next
2695.44|3.54|okay
2696.94|3.419|and so uh you may be able to see how
2698.98|2.52|we're already going to start mapping
2700.359|2.601|this onto some kind of sequence
2701.5|3.66|prediction task that feels a bit
2702.96|4.96|transform-esque which is you receive
2705.16|5.159|this sequence of like uh observations
2707.92|5.22|and in this case actions movements in
2710.319|4.561|space and your job is given a new action
2713.14|2.939|step left here you have to try and
2714.88|2.219|predict what you're going to fit so
2716.079|3.26|that's a kind of sequence prediction
2717.099|2.24|version
2719.859|3.421|the way we're going to try and solve
2721.48|3.359|this is based on factorization it's like
2723.28|3.36|you can't go into one environment and
2724.839|3.361|just learn from the experiences in that
2726.64|3.12|one environment you have to separate out
2728.2|2.879|the structure and the experiences you're
2729.76|2.819|having so that you can reuse the
2731.079|2.641|structural part which appears very often
2732.579|3.78|in the world
2733.72|5.399|okay and so yeah separating memories
2736.359|4.861|from structure and so you know here's
2739.119|4.141|our separation of the two we have our
2741.22|5.58|dude wandering around this like uh 2D
2743.26|5.22|grid world and uh you want to separate
2746.8|3.299|out the fact that there's 2D space and
2748.48|3.599|it's 2D space that has these rules
2750.099|3.541|underlying it and in a particular
2752.079|3.181|instance in the environment you're in
2753.64|3.54|you need to be able to recall which
2755.26|2.819|objects are at which locations in the
2757.18|2.7|environment
2758.079|2.881|okay so in this case it's like oh this
2759.88|3.959|position has an orange house this
2760.96|4.2|position that's green sorry orange uh
2763.839|2.581|red and pink and so you have to bind
2765.16|2.4|those two you have to be like whenever
2766.42|3.06|you realize that you're back in this
2767.56|3.66|position recall that that is the
2769.48|4.68|observation you're going to see that
2771.22|4.74|okay and so this model that the
2774.16|3.48|um we're gonna build is some model that
2775.96|3.54|tries to achieve this
2777.64|3.179|uh yeah new stuff and so when you enter
2779.5|2.94|it imagine you enter a new environment
2780.819|2.76|with the same structure you wander
2782.44|2.52|around and realize it's the same
2783.579|3.061|structure all you have to do is bind the
2784.96|3.3|new things that you see to the locations
2786.64|3.78|and then you're done passed up you know
2788.26|4.2|you know how to work work
2790.42|4.439|uh so this is what a neuroscientists
2792.46|3.6|mean by a cognitive map is this idea of
2794.859|2.46|like separating it out and understanding
2796.06|4.259|the structure that you can reuse in new
2797.319|5.76|situations and uh yeah this model that
2800.319|4.02|uh the was built in the lab uh is a
2803.079|2.401|model of this process happening of the
2804.339|2.821|separation between the two of them and
2805.48|3.839|how you use them to do your inferences
2807.16|3.48|and this is the uh bit that it's
2809.319|2.461|supposed to look like in transform so
2810.64|3.42|it's a general introduction and then
2811.78|4.38|we'll dive into it a little more now
2814.06|3.36|make sense over the broad picture
2816.16|3.24|good
2817.42|4.26|silence I'll assume is good
2819.4|6.0|so we'll start off with some brain stuff
2821.68|5.88|uh so there's a long stream of evidence
2825.4|3.9|from spatial navigation but the brain is
2827.56|3.299|doing something like this I mean I think
2829.3|3.84|you can probably imagine how yourself
2830.859|3.901|you yourself are doing this
2833.14|3.06|um already when you go to a new city or
2834.76|2.46|you're like trying to understand a new
2836.2|2.46|task that has instructions you
2837.22|2.879|recognized from previously you can see
2838.66|3.54|how this is something you're probably
2840.099|3.72|doing but spatial navigation is an area
2842.2|3.06|in Neuroscience which had like a huge
2843.819|2.881|stream of discoveries over the last like
2845.26|3.24|50 years
2846.7|3.72|um and a lot of evidence of the neural
2848.5|3.24|basis of this computation so we're going
2850.42|3.24|to talk through some of those examples
2851.74|4.859|the earliest of these are psychologists
2853.66|5.04|like uh Tolman who were showing that
2856.599|3.961|rats in this case can do this kind of
2858.7|3.06|path integration structure so the way
2860.56|3.48|this work is they got put at a start
2861.76|4.62|position here down at the bottom s and
2864.04|3.9|they got trained but this route up here
2866.38|3.54|got your reward so this is The Maze We
2867.94|4.32|had to run around uh then they were
2869.92|4.08|asked they were put in this new uh this
2872.26|3.24|the same thing but they blocked off this
2874.0|3.119|path that takes this long-winding route
2875.5|3.54|and given instead a selection of all
2877.119|4.021|these arms to go down and they look at
2879.04|3.6|which path the rat goes down and the
2881.14|3.12|finding is that the rat goes down the
2882.64|3.54|one that corresponds to heading off in
2884.26|3.78|this direction so the rat has somehow
2886.18|3.12|not just learned like a you know one
2888.04|2.88|option of this is like blind
2889.3|3.66|memorization of action that I need to
2890.92|3.54|take in order to root around instead no
2892.96|2.879|it's learning actually that the struck
2894.46|3.06|in embedding the reward and its
2895.839|2.76|understanding of 2D space and taking a
2897.52|2.64|direct route there even though it's
2898.599|3.541|never taken it before there's evidence
2900.16|3.959|that rats are doing this as well as us
2902.14|4.8|and then a series of like neural
2904.119|4.5|discoveries about the basis of this so
2906.94|3.48|uh John O'Keefe
2908.619|2.941|um stuck an electrode in the hippocampus
2910.42|2.76|which is a brain area we'll talk more
2911.56|3.42|about and found these things called
2913.18|5.04|Place cells so what I'm plotting here is
2914.98|6.42|each of these columns is a single neuron
2918.22|5.04|and the mouse or rat I can't remember is
2921.4|4.56|running around a square environment the
2923.26|4.859|black lines are the path the rodent
2925.96|3.78|traces out through time and you put a
2928.119|3.541|red dot down every time you see this
2929.74|3.3|individual neuron Spike and then the
2931.66|3.179|bottom plot of this is just a smooth
2933.04|3.48|version of that Spike rate so that
2934.839|3.121|firing rate so what you can think of is
2936.52|2.52|like the activity of a neuron and neural
2937.96|2.94|network that's the analogy that people
2939.04|2.819|usually draw and so these ones are
2940.9|2.219|called play cells because they're
2941.859|3.541|neurons that respond in a particular
2943.119|3.601|position in space and in the 70s this
2945.4|2.699|was like huge excitement you know people
2946.72|3.3|have been studying mainly like sensory
2948.099|3.421|systems and motor output and suddenly a
2950.02|3.18|deep cognitive variable Place something
2951.52|3.18|you never you don't have a GPS signal
2953.2|3.419|there but somehow there's this like
2954.7|3.419|signal for what looks like position in
2956.619|3.0|the brain in very like understandable
2958.119|4.381|ways
2959.619|5.281|uh the next step in uh the biggest step
2962.5|4.5|I guess in this chain of Discovery is uh
2964.9|4.26|the moza lab which is a group in Norway
2967.0|3.66|they uh second electron a different area
2969.16|3.12|of the brain the Midland terrinal cortex
2970.66|2.939|and so this is the hippocampal enterinal
2972.28|2.76|system we're going to talk about and
2973.599|2.941|they found this neuron called a grid
2975.04|3.12|cell so again the same plot structure
2976.54|3.24|that I'm showing here but instead these
2978.16|3.659|neurons respond not in one position a
2979.78|4.74|room but in a try like a hexagonal
2981.819|5.701|lattice of positions in a root okay so
2984.52|4.62|this uh these two I guess I'm showing to
2987.52|4.14|you because they like really motivate
2989.14|3.959|the underlying neural basis of this kind
2991.66|3.78|of like uh spatial cognition and
2993.099|4.26|embodying the structure of this space in
2995.44|3.84|somewhere okay and it's very surprising
2997.359|3.121|finding why why are neurons choosing to
2999.28|2.94|represent things with this hexagonal
3000.48|3.54|lattice it's like yeah
3002.22|3.24|uh provoked a lot of research since and
3004.02|4.14|broadly there's been like many more
3005.46|4.32|discoveries in this area so uh there's
3008.16|3.3|places I've talked to about grid cells
3009.78|4.2|cells that respond based on the location
3011.46|3.84|of not yourself but another animal uh
3013.98|3.3|cells that respond when your head is
3015.3|3.66|facing a particular direction cells that
3017.28|4.079|respond to when you're a particular
3018.96|4.56|assistance away from an object so like I
3021.359|3.061|am one step south of an object that kind
3023.52|2.64|of self
3024.42|4.08|uh cells that respond to reward
3026.16|4.199|positions cells respond to vectors to
3028.5|3.96|boundaries those responsible for like
3030.359|4.381|all sorts all kinds of structure that
3032.46|4.44|this uh this this pair of brain
3034.74|4.26|structures the hippocampus here this red
3036.9|4.62|area and the enter anal cortex this blue
3039.0|6.2|area here uh which is yeah it can served
3041.52|3.68|across a lot of species are represented
3045.3|3.6|um there's also finally one finding in
3046.74|5.04|this that's fun is they didn't an fmri
3048.9|4.86|experiment on London taxi cab drivers uh
3051.78|3.48|and uh I don't know if you know this but
3053.76|3.599|the London Pakistan drivers they do I
3055.26|3.54|think all the knowledge uh which is a
3057.359|3.541|two year long test where they have to
3058.8|3.9|learn every street in London and the
3060.9|3.78|idea is that the tests go something like
3062.7|4.2|oh there's a traffic jam here a road
3064.68|4.5|work here and I need to get from like
3066.9|3.48|um Camden town down to Wandsworth in the
3069.18|2.46|quickest way possible what route would
3070.38|2.1|you go we have to tell you which route
3071.64|2.219|they're going to be able to take it
3072.48|2.82|through all the roads and like how they
3073.859|2.821|would re-plan if they found a it's not
3075.3|2.759|that those kind of things so it's like
3076.68|2.58|intense are you see them like driving
3078.059|2.341|around sometimes learning all of these
3079.26|2.7|like Roots
3080.4|3.84|um with little Maps they're being made a
3081.96|3.72|little bit obsolete by uh Google Maps
3084.24|3.119|but you know luckily they got them
3085.68|3.419|before that uh this experiment was done
3087.359|3.781|before that was true and so they've got
3089.099|4.321|here is a measure of the size of your
3091.14|3.9|hippocampus using fmri versus how long
3093.42|3.0|you've been a taxi cab driver in months
3095.04|2.46|and the claim is basically the longer
3096.42|2.22|you're a taxi cab driver the bigger
3097.5|3.119|you'll hit the campus the more you're
3098.64|5.16|having to do this kind of spatial reason
3100.619|4.381|so that's a big set of uh evidence that
3103.8|3.299|these brain areas are doing something to
3105.0|3.78|do with space but there's a lot of
3107.099|3.301|evidence that's uh there's something
3108.78|3.72|more than that something non-spatial
3110.4|3.3|going on in these areas okay and we're
3112.5|3.359|going to build these together to make
3113.7|4.5|the broader Claim about this like
3115.859|3.96|underlying structural inference and so
3118.2|4.32|I'm going to talk through a couple of
3119.819|4.681|those uh the first one is is a guy
3122.52|4.079|called patient hm this is the most
3124.5|6.66|studied uh patient in like medical
3126.599|6.0|history he uh had epilepsy and to cure
3131.16|3.12|interactional epilepsy you have to cut
3132.599|3.48|out the brain region that's causing
3134.28|4.86|these like seizure-like events in your
3136.079|4.861|brain and in this case uh the escalator
3139.14|4.26|is coming from the guys hippocampus so
3140.94|5.159|they bilaterally lesions like cut out
3143.4|4.199|both of the city of Kanpai and it turned
3146.099|3.421|out that this guy then had terrible
3147.599|3.421|Amnesia he never formed another memory
3149.52|2.819|again and he could only recall memories
3151.02|4.62|from a long time before the surgery
3152.339|5.581|happened okay uh but he they were yeah
3155.64|3.9|so experiments were showed a lot of
3157.92|3.6|their stuff about how we understand uh
3159.54|4.44|the neural basis of memory uh things
3161.52|3.96|like he could learn to do motor tasks so
3163.98|3.06|somehow the motor tasks are being done
3165.48|2.7|for example you they gave him some very
3167.04|2.579|difficult multiple coordination tasks
3168.18|2.879|that people can't generally do they can
3169.619|2.881|with a lot of practice and he got very
3171.059|2.941|good at this eventually
3172.5|2.7|um and was as good as other people at
3174.0|2.64|learning to do that he had no
3175.2|3.06|recollection of ever doing the task so
3176.64|2.939|he'd go into the new task and be like
3178.26|2.4|I've never seen this before I have no
3179.579|4.141|idea what you're asking to do and they
3180.66|4.32|do it amazing be like yeah so
3183.72|2.639|um there's some evidence there that the
3184.98|2.879|hippocampus is involved in least some
3186.359|2.821|parts of memory there which seems a bit
3187.859|2.7|separate to this stuff about space that
3189.18|3.72|I've been talking to
3190.559|3.841|uh second of these is uh imagining
3192.9|4.32|things so this is actually a paper by
3194.4|4.919|James who's uh before he was deep-minded
3197.22|4.619|with a neuroscientist
3199.319|4.02|um and here uh maybe you can't read that
3201.839|2.941|I'll read somebody that
3203.339|2.881|um you're asked to imagine uh you're
3204.78|3.0|lying on a white sandy beach in a
3206.22|2.879|beautiful tropical Bay and so the
3207.78|2.52|control this bottom one says things like
3209.099|2.821|this very hot and the Sun is beating
3210.3|3.36|down on me the sand underneath me is all
3211.92|3.179|almost unbearably hot I can hear the
3213.66|3.0|sounds of small wavelets lapping on the
3215.099|3.48|beach to see this gorgeous aquamarine
3216.66|3.12|color you know like so a nice Lucid
3218.579|4.141|description of
3219.78|5.7|um this BTC whereas the person with a
3222.72|4.56|hippocampal damage says as we're seeing
3225.48|3.24|I can't really apart from just the sky I
3227.28|2.819|can hear the sound of Seagulls Under the
3228.72|2.82|Sea
3230.099|3.02|um I can feel the grain of sand
3231.54|4.2|underneath my fingers
3233.119|3.881|and then like yeah the struggles are
3235.74|2.94|basically really struggles to do this
3237.0|4.2|imagine an imagination scenario some of
3238.68|5.52|the things we need is like surprising so
3241.2|5.82|uh the last of these is this uh
3244.2|4.619|transitive inference task so Transit
3247.02|3.72|inference a is greater than b b is
3248.819|3.901|greater than C therefore a is greater
3250.74|3.839|than C and the way they convert this
3252.72|3.18|into a rodent experiment is you get
3254.579|3.78|given two pots of food that have
3255.9|4.199|different smells and your job is to go
3258.359|3.96|to the pot of food you learn which part
3260.099|5.22|of food has sorry which part with the
3262.319|4.8|smell has for food and so these uh that
3265.319|3.961|are colored by the two parts by their
3267.119|3.96|smell A and B and the rodent has to
3269.28|3.42|learn to go to a particular pot in this
3271.079|3.421|case the one that smells like hey and
3272.7|3.359|they do two of these they do a has the
3274.5|3.48|food when it's presented in a pair with
3276.059|3.961|B and B has the food when it's presented
3277.98|3.54|in a pair with c and then they test what
3280.02|3.539|does the mouth do when presented with A
3281.52|4.02|and C a completely new situation and if
3283.559|3.661|they have a hippocampus they'll go for a
3285.54|4.68|over C they'll do transitive influence
3287.22|4.98|if they don't have one they can't and so
3290.22|3.359|there's a much more broad this is like
3292.2|2.46|oh I've shown you how hippocampus is
3293.579|2.941|used for this spatial stuff that people
3294.66|3.78|have been excited about but there's also
3296.52|4.14|all of this kind of relational stuff
3298.44|3.96|imagining you situation some slightly
3300.66|4.02|more complex story here
3302.4|3.9|uh the last thing I'm going to do is how
3304.68|3.24|the enter Rhino cortex as well so that's
3306.3|3.539|where if you remember hippocampus was
3307.92|3.96|these guys enter Rhino cortex was these
3309.839|4.321|grid cells without enteronal cortex was
3311.88|3.54|appearing to do some broader stuff as
3314.16|2.64|well this is all motivation for the
3315.42|2.399|models just trying to build all of these
3316.8|3.779|things together
3317.819|5.941|uh so in this one this is called the
3320.579|4.921|stretchy Birds task okay so uh you put
3323.76|4.02|people in an fmri machine and you make
3325.5|4.68|them navigate but navigate in Bird space
3327.78|5.52|and what Bird Space means is it's a
3330.18|5.22|two-dimensional space of images and each
3333.3|4.08|image is one of these birds and as you
3335.4|3.659|vary along the X Dimension the bird's
3337.38|3.239|legs get longer and shorter and there's
3339.059|4.5|a vary along a y direction the bird's
3340.619|6.121|neck gets longer and shorter okay and
3343.559|4.621|the patients sit there or subjects sit
3346.74|3.24|there and just watch the bird images
3348.18|3.78|change so that it traces out some path
3349.98|4.26|in 2D space but they never see the 2D
3351.96|3.78|space they just see the images okay and
3354.24|3.18|the claim is basically and then they're
3355.74|3.839|asked to do some like navigational tasks
3357.42|4.26|they're like oh you whenever you're in
3359.579|4.621|this place in 2D space you show like
3361.68|4.56|Santa Claus next to the bird and so the
3364.2|3.6|participants have to pin that particular
3366.24|3.119|bird image that particular place in 2D
3367.8|3.539|spaces to the Santa Claus and you're
3369.359|3.901|asked to like go and find the Santa
3371.339|3.301|Claus again using some non-directional
3373.26|2.099|controller and like navigate their way
3374.64|3.0|back
3375.359|4.2|and the claim is that these people use
3377.64|3.78|grid cells so the enter Rhino cortex is
3379.559|3.901|active in how these people are
3381.42|3.84|navigating this abstract cognitive Bird
3383.46|5.28|Space you know where you test that claim
3385.26|5.88|is you you look at the fmri signal in
3388.74|4.56|the enterinal cortex as the participants
3391.14|3.06|head at some particular angle in Bird
3393.3|2.759|Space
3394.2|3.72|and because of the six-fold symmetry of
3396.059|3.961|the hexagonal lattice you get this six
3397.92|4.919|volt symmetric waving up and down of the
3400.02|4.86|enterinal cortex activity as you head in
3402.839|3.421|particular direction within 2D space it
3404.88|2.76|was like evidence that this system is
3406.26|4.14|being used not just for like navigation
3407.64|4.02|and 2D space but any cognitive task with
3410.4|4.64|some underlying structure that you can
3411.66|5.82|extract you use it to do these tasks
3415.04|5.64|significance the Birds space also been
3417.48|6.18|to here yes yes
3420.68|6.52|like variability uh people haven't done
3423.66|5.58|that experiment but people uh have done
3427.2|4.44|things like look at how grid cells rep
3429.24|4.859|are they even done that
3431.64|4.26|they've done things like 3D space but
3434.099|3.96|not like cognitive 3D space they've done
3435.9|3.419|like literally like make they don't in
3438.059|2.52|bats they say collectors and bats to
3439.319|3.3|make the bats fly around the room look
3440.579|3.361|at how their grid cells respond yeah but
3442.619|3.96|definitely uh
3443.94|4.379|there I think they've done it ah they've
3446.579|4.081|done it in
3448.319|3.721|um sequence space so in this case you
3450.66|3.3|hear a sequence of sounds with
3452.04|4.26|hierarchical structure so it's like how
3453.96|4.32|those months weeks days and meals
3456.3|3.6|something like that so like weeks have a
3458.28|3.18|periodic structure months have a period
3459.9|3.6|of extra days have a period expect that
3461.46|3.24|in meals on a periodic structure and so
3463.5|2.4|you'll hear a sequence of sound with
3464.7|2.94|exactly the same kind of structure as
3465.9|2.82|that hierarchy of sequences and you look
3467.64|3.24|at the representation in the enteral
3468.72|3.24|cortex through fmri and use exactly the
3470.88|2.939|same thing that the structure is all
3471.96|3.72|represented in like that even more than
3473.819|4.8|that you actually see in their adrenal
3475.68|4.2|cortex a array of length scales so one
3478.619|3.061|end of the anterior cortex you've got
3479.88|3.78|very large landscale grid cells like
3481.68|3.78|responding to large variations in Space
3483.66|3.36|the other only are very small ones and
3485.46|3.84|you see the same thing to do that
3487.02|3.599|they're like meal cycle that Cycles a
3489.3|2.819|lot more quicker is represented in one
3490.619|3.421|end of the internal cord that's an fmri
3492.119|4.2|and the month cycle is at the other end
3494.04|4.22|of the scale in between so there's some
3496.319|4.681|yeah evidence of that ended
3498.26|4.599|all right uh so I've been talking about
3501.0|3.54|MEC the medial interino cortex another
3502.859|3.661|brain area that people don't look as
3504.54|3.059|much as the LEC the lateral length
3506.52|2.7|around our cortex but will then be
3507.599|3.301|important for this model and basically
3509.22|3.0|the the only that that you should be
3510.9|2.699|aware of before we get to the model is
3512.22|3.359|that it seems to represent very high
3513.599|3.601|level the similarity structure in a
3515.579|3.421|lateral and toronal cortex seems to be
3517.2|3.96|like a very high level semantic one for
3519.0|3.9|example you present some images and you
3521.16|3.54|look at how you know the visual cortex
3522.9|3.24|things are more similarly represented if
3524.7|2.76|they look similar but by the time you
3526.14|2.58|get to the lateral and to run a cortex
3527.46|2.879|things look more similar based on their
3528.72|3.66|usage for example like an ironing board
3530.339|3.48|and an iron will be represented
3532.38|2.52|similarly even though they look very
3533.819|2.341|different because they're somehow like
3534.9|3.36|semantic women
3536.16|3.899|okay so that's the role that the LEC is
3538.26|4.74|going to play in this model
3540.059|5.28|uh so yeah basically the claim is uh
3543.0|3.54|this is for more than just 2D space so
3545.339|3.0|the neural implementation of this
3546.54|3.059|cognitive map which is for not only 2D
3548.339|3.301|space which this cartoon is supposed to
3549.599|4.801|represent also things any other
3551.64|4.26|structure so some structures like
3554.4|3.179|transitive inference this one is faster
3555.9|3.899|than that and it's faster than that or
3557.579|3.961|family trees like this person my
3559.799|3.901|mother's brother owner is there for my
3561.54|3.539|uncle those kind of things these like
3563.7|2.28|broader structural inferences that you
3565.079|2.161|want to be able to use in many
3565.98|2.7|situations so it's basically the same
3567.24|3.54|problem
3568.68|3.6|great that was a lot of Neuroscience
3570.78|3.299|and now I'm going to get onto the model
3572.28|3.18|that tries to summarize all of these
3574.079|2.401|things and that's going to be the model
3575.46|2.339|that will end up looking like a
3576.48|2.819|transport
3577.799|3.181|so
3579.299|4.141|um yeah we basically want this
3580.98|3.599|separation these diagrams here are
3583.44|2.22|supposed to represent a particular
3584.579|3.181|environment that you're wandering around
3585.66|3.659|it has an underlying grid structure and
3587.76|2.819|you see a set of stimuli at each point
3589.319|3.721|on these grid which these little cartoon
3590.579|3.901|bits and you want to try and create a
3593.04|2.819|thing that separates out this like 2D
3594.48|3.0|structural grid from the actual
3595.859|2.881|experiences you're seeing and they're
3597.48|3.72|mapping to the things I've been showing
3598.74|3.78|you is that this grid grid like code is
3601.2|2.58|actually the grid cells in the middle
3602.52|3.299|enter anal cortex are somehow
3603.78|3.9|abstracting the structure the lateral
3605.819|3.601|lanternal cortex encoding these
3607.68|3.419|semantically meaningful similarities
3609.42|2.939|will be the objects that you're seeing
3611.099|2.641|so it's just like this is what I'm
3612.359|3.361|seeing in the world
3613.74|4.8|and the combination of the two of them
3615.72|5.639|will be the hippocampus
3618.54|5.16|so yeah in more diagrams we've got G the
3621.359|5.101|structural code the grid code in MEC and
3623.7|7.94|LEC or someone asking a question
3626.46|5.18|since morning so now it's lunchtime yeah
3633.059|3.601|sorry I can't hear you if you're asking
3634.559|5.54|a question
3636.66|3.439|how do I mute someone if they're
3643.44|3.74|maybe type it in the chat if there is
3644.94|2.24|one
3650.22|2.579|nice
3652.02|2.7|um
3652.799|3.361|so yeah we've got a hippocampus in the
3654.72|3.839|middle which is going to be our binding
3656.16|3.78|of the two of them together
3658.559|3.06|okay
3659.94|3.06|so I'm going to step through each of
3661.619|2.821|these three parts on their own and how
3663.0|4.02|they do the job that I assigned to them
3664.44|3.96|uh and then uh come back together and
3667.02|4.2|show the full model
3668.4|4.74|so uh later on integrinal cortex encodes
3671.22|3.599|what you're seeing so this is like the
3673.14|3.06|these images or the houses we were
3674.819|3.181|looking at before and that will just be
3676.2|5.04|some Vector XT that's different so a
3678.0|5.64|random Vector different for every single
3681.24|3.78|uh the middle and Toronto cortex is the
3683.64|3.479|one that tells you where you are in
3685.02|4.44|space and it has a job of path
3687.119|3.841|integrating okay so this means receiving
3689.46|3.119|a sequence of actions that you've taken
3690.96|3.899|in space for example I went north east
3692.579|3.72|and south and tell you where in 2D space
3694.859|3.121|that you are so somehow the bit that
3696.299|3.841|embeds the structure of the world
3697.98|4.68|and the way that we'll do that is this G
3700.14|5.52|of T this Vector of activity is in its
3702.66|4.62|brain area will be updated by a matrix
3705.66|4.08|that depends on the actions you've taken
3707.28|3.66|okay so if you step North you update the
3709.74|4.02|representation with the step North
3710.94|4.139|Matrix okay and those matrices are gonna
3713.76|3.0|have to obey some rules for example if
3715.079|3.121|you step North then Step South you
3716.76|2.88|haven't moved and sort of Step North
3718.2|3.48|Matrix instead of South Matrix actually
3719.64|4.5|inverses of one another so that the
3721.68|4.74|activity stays the same and represents
3724.14|5.58|the structure of the world
3726.42|6.3|okay so that's the world structure part
3729.72|5.28|ly uh the memory because we have to
3732.72|3.66|memorize which things we found at which
3735.0|3.42|positions going to happen in the
3736.38|3.12|hippocampus that's going to be through a
3738.42|3.179|version of these things called the hot
3739.5|4.2|field networks that you heard mentioned
3741.599|3.541|in the last talk so this is like a
3743.7|3.899|Content addressable memory and it's
3745.14|4.14|biologically plausible with the claim uh
3747.599|3.72|the way it works is you have a set of
3749.28|4.38|activities P which are the activities of
3751.319|4.861|all these neurons and when it receives
3753.66|4.56|uh so just like recurrently updates
3756.18|4.08|itself so there's some weight Matrix in
3758.22|3.18|here W are some nonlinearity and you run
3760.26|3.059|it for an entire and it just like
3761.4|3.899|settled into some dynamical system it
3763.319|4.02|settled into some attractive state
3765.299|4.141|and the way you make a new memory is
3767.339|4.02|through the weight Matrix okay so you
3769.44|4.56|make it like a sum of outer products of
3771.359|4.561|these Pi mu each Chi has some memory
3774.0|4.38|some pattern that you want to record
3775.92|3.899|okay uh and then it's yeah this is just
3778.38|3.66|writing it in there the update pattern
3779.819|5.641|is like that and the claim is basically
3782.04|5.579|that if P the memory the the activity of
3785.46|5.22|the neurons the hippocampal neurons is
3787.619|4.68|close to some memory say chi mu then
3790.68|3.6|this dot product will be much larger
3792.299|3.661|than all of the other dot products with
3794.28|2.94|all the other members so there's some
3795.96|5.04|over all of them were basically
3797.22|5.82|dominated by this one term Pioneer and
3801.0|4.02|so your attractor network will basically
3803.04|3.6|settle into that one plane
3805.02|3.0|and maybe the preempt some of the stuff
3806.64|3.54|that's kind of come later you can see
3808.02|4.86|how this like similarity between points
3810.18|4.379|is uh yeah Paradise similarity and then
3812.88|3.6|adding some adding them up weighted by
3814.559|3.0|this highway similarity is the bit
3816.48|3.5|that's going to turn out looking a bit
3817.559|2.421|like attention
3820.68|3.119|um and so some of the cool things you
3822.059|3.24|can do with these systems is like uh
3823.799|3.361|here's a set of images that someone's
3825.299|3.78|encoded in a hot field Network and then
3827.16|3.659|someone's presented this image the
3829.079|4.5|network and asked it to just run to its
3830.819|4.561|like dynamical attractor uh Minima and
3833.579|2.881|it recreates all of the memory that it's
3835.38|3.78|got stored in it's sort of like
3836.46|6.0|completes the rest of it
3839.16|5.6|uh so that's our system
3842.46|2.3|yeah
3849.559|5.581|I heard that like this interpretation is
3852.839|5.161|like the modern interpretation awkward
3855.14|5.58|uh this one's actually uh which
3858.0|2.72|interpretation sorry
3861.2|4.659|oh yeah
3863.64|4.02|uh yeah yeah it's only the the link to
3865.859|3.061|Transformers will basically only be
3867.66|2.52|through the pack there's classic coffee
3868.92|3.899|on networks and then there's modern ones
3870.18|5.52|that were within like 2016 and the link
3872.819|5.161|between attention and modern is precise
3875.7|6.54|the link with like classic is not as
3877.98|6.319|good I mean you yeah yeah yeah yeah yeah
3882.24|2.059|um
3885.24|2.24|foreign
3893.28|2.579|because then you have to do the
3894.299|3.06|exponentiation thing
3895.859|4.321|well maybe get to it later you can tell
3897.359|4.341|me something yeah no no no no more
3900.18|3.78|questions are good
3901.7|4.419|we'll get well yeah maybe separate
3903.96|6.8|energy function and I think the
3906.119|4.641|exponential is in that event yeah
3912.72|3.599|uh so that's basically how our system is
3914.88|2.76|going to work but this Tom and
3916.319|5.221|eichenbach machine that's what the name
3917.64|4.86|of this thing is uh and so you the
3921.54|2.64|patterns you want to store in the
3922.5|3.599|hippocampus so these memories that we
3924.18|4.2|want to embed are a combination of the
3926.099|4.381|position and the input and like half of
3928.38|3.239|employment space here if you then have
3930.48|2.76|decided you want to end up in a
3931.619|3.661|particular position you can recall the
3933.24|3.599|stimulus that you saw there and uh
3935.28|3.6|predict that as your life next
3936.839|4.081|observation or vice versa if you like
3938.88|3.6|see a new thing you can infer oh I path
3940.92|3.199|integrated wrong I must actually beat it
3942.48|3.839|you know
3944.119|2.98|there's usually more than one thing in
3946.319|3.141|the world that might be in different
3947.099|2.361|positions
3950.339|3.541|yeah that's the whole system does the
3951.9|5.159|whole uh common I can bound machine
3953.88|6.479|makes sense roughly what it's doing
3957.059|6.721|okay cool uh and basically this last bit
3960.359|4.861|is saying it's really good so uh what
3963.78|3.12|I'm showing here is this is on the 2D
3965.22|4.379|navigation task and it's right so it's a
3966.9|3.78|big grid I think they use like an 11 by
3969.599|2.161|11 or something and it's like wandering
3970.68|2.76|around and have to predict what's going
3971.76|4.2|to see in some new environment
3973.44|4.56|and uh on here this is the number of
3975.96|3.899|nodes in that graph that you've visited
3978.0|3.42|and on the y-axis is how much you
3979.859|4.081|correctly predict and each of these
3981.42|4.199|lines is based on how many of those type
3983.94|3.24|of environments I've seen before how
3985.619|3.48|could we go into that and the basic
3987.18|3.96|phenomena is showing is over time as you
3989.099|3.96|see more and more of these environments
3991.14|3.36|you learn to learn so you like learn the
3993.059|2.76|structure of the world and eventually be
3994.5|3.059|able to quickly generalize to the new
3995.819|3.961|situation and predict what you're going
3997.559|3.601|to see and there's scales not with like
3999.78|3.24|the number of edges that you've visited
4001.16|3.959|which would be the like learn everything
4003.02|3.36|option you know prediction because if
4005.119|2.94|you're trying to predict which state I'm
4006.38|3.419|going to see given my currency an action
4008.059|4.441|and in a dumb way you just need to see
4009.799|3.901|all states in action so all edges uh but
4012.5|2.28|this Wing is able to do it much more
4013.7|2.94|clearly because it only needs to visit
4014.78|3.12|all nodes and just memorize what is at
4016.64|3.0|each position and you can see that it's
4017.9|3.78|learning curve follows the number of
4019.64|4.5|nodes visited
4021.68|4.619|it's a thing wrong uh for Neuroscience
4024.14|4.74|uh this is also exciting is that the
4026.299|4.981|neural patterns of response in the brain
4028.88|5.4|in these like model regions match the
4031.28|4.44|ones observed in the brain so in the uh
4034.28|3.779|hippocampal section you get Place
4035.72|4.079|cell-like activities this is this
4038.059|3.661|hexagon is the grid of the environment
4039.799|4.02|that it's exploring and plotted is the
4041.72|4.02|firing rate of that neuron whereas the
4043.819|5.04|ones in the medial and terrinal cortex
4045.74|4.5|show this grid-like firing pattern
4048.859|4.321|yeah
4050.24|5.16|this like exactly compare it operates on
4053.18|3.659|like discrete spaces essentially yeah do
4055.4|3.419|you have any thoughts about how that
4056.839|3.601|transfers what anything those real world
4058.819|3.54|thing do you think that we're just like
4060.44|4.2|map Representatives into like a very
4062.359|3.18|nicely discreet kind of space where we
4064.64|2.34|think that when they click the more
4065.539|3.0|complicated
4066.98|5.599|yeah I imagine there's something more
4068.539|4.04|complicated going on I guess this uh
4072.68|4.98|so it's like a super no yeah maybe you
4075.319|3.78|can make sure that you make arguments
4077.66|2.879|that they as I was saying there's these
4079.099|2.46|different modules that have cooperated
4080.539|2.401|at different scales you can see this
4081.559|3.54|already here like grid cells at one
4082.94|4.02|scale Droid cells at another scale and
4085.099|4.141|so you could imagine how that could be
4086.96|4.02|useful for like uh one of them operates
4089.24|3.119|in the highest level one of them
4090.98|3.599|operates at the lowest level you know in
4092.359|3.721|life yeah adaptable they seem to scale
4094.579|3.301|up or down depending on your environment
4096.08|3.779|and so like an adaptable set of length
4097.88|4.58|scales that you can use so that's quite
4099.859|2.601|speculative
4103.219|5.161|okay sorry yeah to make sure I
4105.44|7.62|understand if you go up
4108.38|7.859|um okay one more yeah so you have your
4113.06|5.94|what's the key and what's the value
4116.239|4.44|um yeah so the
4119.0|4.44|um and and how the networks are always
4120.679|4.981|Auto instead of Petro Associated so how
4123.44|4.5|are you the memories that we're gonna
4125.66|4.8|put in so the patterns let's say kainu
4127.94|5.819|is going to be some like outer product
4130.46|5.46|of the position at a given time and the
4133.759|5.0|uh
4135.92|2.839|flattened
4140.66|3.42|uh sorry yeah take the other product
4142.4|3.48|though so every element in X can see
4144.08|3.119|every element of G flatten those out and
4145.88|3.12|let's go back to the government
4147.199|4.221|does that make sense yeah sorry I should
4149.0|2.42|put that on
4152.12|3.719|yeah and then you do the same operation
4153.679|3.6|except you flatten with an identity in
4155.839|2.221|the let's say you're at a position you
4157.279|2.761|want a pretty cool you're going to see
4158.06|3.299|you set x to the identity you do this
4160.04|3.06|operation that creates a very big Vector
4161.359|3.241|from G you put that in and you let it
4163.1|3.3|run at stagnantics and it recalls the
4164.6|5.219|pattern and you like uh learn a network
4166.4|6.72|that like traces out the X from them
4169.819|6.121|and the figures you show if you go down
4173.12|4.92|a bit yeah yeah the it's it's hard to
4175.94|6.06|see but once on the x-axis and what's
4178.04|5.88|like what are you training a popular
4182.0|4.739|network with this
4183.92|4.74|uh flattened out our product of the okay
4186.739|4.201|yeah the the actual the training that's
4188.66|3.72|going on is more in the structure of the
4190.94|3.299|world now because it has to learn those
4192.38|3.72|matrices all it gets told is which
4194.239|3.301|action type it's taken and it has to
4196.1|3.42|learn the fact that stepping East is the
4197.54|3.42|opposite stepping West so all of the
4199.52|3.719|learning of stuff is in those matrices
4200.96|4.2|learning to get the right structure
4203.239|3.181|there's also I mean because the the hot
4205.16|2.579|fuel Network learning the Hot Wheel
4206.42|2.88|networks like re-initialize every
4207.739|4.141|environment and you're just like shoving
4209.3|4.379|memories in so it's less like that's
4211.88|3.66|less the bit of the screen it's causing
4213.679|4.141|this certainly but it's not causing this
4215.54|3.3|like shift up which is as training
4217.82|2.879|progresses in many different
4218.84|3.359|environments you get better at the task
4220.699|3.361|because it's learning instruction with
4222.199|6.301|us
4224.06|6.78|and the link to this is all just modern
4228.5|4.199|popular Networks
4230.84|3.48|um the initial paper was actually
4232.699|4.081|classic cocktail networks but yeah the
4234.32|4.98|now now the new versions of our models
4236.78|6.8|yeah right and then in so much as modern
4239.3|4.28|home build networks equal the tension
4244.96|5.94|but then you're okay and then you have
4248.36|4.379|some there are some results looking at
4250.9|4.06|activations
4252.739|4.021|well these are recordings in the brain
4254.96|4.38|these are no these are actually in the
4256.76|4.68|intent so this is aim the left ones are
4259.34|5.24|neurons in the G section in the middle
4261.44|4.92|electronic cortex part of 10.
4264.58|3.04|yeah
4266.36|4.2|and we're going to get you my last
4267.62|4.079|section is about how these 10 is like a
4270.56|4.08|little bit so hopefully it will be clear
4271.699|4.801|the Link's changes okay we're happy with
4274.64|4.26|that though hopefully cool Tim is
4276.5|4.739|approximately equal to transform yeah so
4278.9|5.16|um you you seem to you you know all of
4281.239|4.861|this uh but I guess my notation at least
4284.06|3.36|we can clarify that uh you've got your
4286.1|2.639|data which is maybe your like tokens
4287.42|2.759|coming in and you've got your positional
4288.739|3.661|embedding and the positional embedding
4290.179|4.081|will play a very big role here that's
4292.4|5.339|the E and together they make this Vector
4294.26|4.62|H okay and these arrive over time yeah
4297.739|3.42|and you've got your attention updates
4298.88|4.02|that you see some similarity between the
4301.159|3.481|key and the query and then you add up
4302.9|3.6|weighted the values with those
4304.64|2.94|similarities so we're all happy with
4306.5|4.28|that
4307.58|3.2|and here's the Stacked version
4310.88|4.98|um so the basic intuition about how
4313.28|4.439|these parts map onto each other is that
4315.86|3.9|the G is the positioning coding as you
4317.719|5.94|may be able to predict the x or the
4319.76|5.82|input tokens uh this guy when you put in
4323.659|3.661|the memory and you try and recall which
4325.58|3.42|memory is most similar to that's the
4327.32|6.419|attention part
4329.0|7.14|um and uh maybe some yeah you attend you
4333.739|4.381|compare the current GT to all of the
4336.14|4.32|previous GTS and you recall the ones
4338.12|5.48|with high similarity structure and
4340.46|3.14|return the corresponding X
4345.26|2.76|um
4346.159|3.601|maybe some differences so I think I'm
4348.02|3.78|going to go through this between how you
4349.76|4.02|would maybe uh like the normal
4351.8|4.2|Transformer and how to make it map onto
4353.78|4.379|this are the following uh so the first
4356.0|4.739|of these is the keys and the queries are
4358.159|4.141|the same at all time points so there's
4360.739|3.48|no difference in The Matrix that maps
4362.3|4.32|from uh tokens to keys and tokens
4364.219|4.381|queries same Matrix and it only depends
4366.62|4.5|on the positional encoding
4368.6|5.7|okay so you only recall memories based
4371.12|4.98|on how similar their positions are
4374.3|4.32|so yeah this is
4376.1|4.44|Kia time Tau equals query time Tau
4378.62|4.5|equals some Matrix applied only to the
4380.54|5.639|positional embedding attention
4383.12|4.86|uh then the values depend only on this X
4386.179|3.841|part so it's some like factorization of
4387.98|3.9|the two which is the value at turn
4390.02|3.659|Towers like some value Matrix only apply
4391.88|4.56|to that X part but the only bit you want
4393.679|4.321|to play uh recall I guess uh is that
4396.44|3.84|right that's right
4398.0|4.5|and then it's a causal Transformer in
4400.28|3.6|that you only do attention at things
4402.5|3.48|that have arrived at time points in the
4403.88|3.359|past
4405.98|3.36|make sense
4407.239|3.361|and finally the perhaps like weird and
4409.34|3.42|interesting difference is that there's
4410.6|4.44|this path integration going on in the
4412.76|3.84|positional encodings so these e or the
4415.04|2.76|equivalent of the grid cells the G from
4416.6|2.579|the previous bit and they're going to be
4417.8|2.52|updated through this Matrix that
4419.179|3.5|depending on the actions you're taking
4420.32|2.359|in the world
4422.96|4.38|people uh yeah so that's basically the
4426.14|2.4|correspondence I'm going to go through a
4427.34|3.359|little bit about how the hot field
4428.54|4.74|network is approximately like doing
4430.699|4.621|attention over previous tokens
4433.28|4.26|so yeah I was describing to you before
4435.32|4.14|the classic Hot field network uh which
4437.54|3.9|if you remove the nonlinearity looks
4439.46|4.38|like this and the mapping I guess is
4441.44|4.2|like the hippocampal activity the mem
4443.84|3.06|the like current neural activity is the
4445.64|3.96|query
4446.9|4.5|uh the set of memories themselves are
4449.6|3.24|the key you're doing this dot product to
4451.4|2.759|get the current similarity between the
4452.84|3.359|query and the key and then you're
4454.159|3.841|summing them up weighted by that dot
4456.199|3.901|product uh all of the memories they're
4458.0|3.96|the values
4460.1|3.54|so that's a simple version
4461.96|4.02|uh but actually these Hot Wheel networks
4463.64|4.2|are quite bad they like uh in some
4465.98|5.1|senses they tend to fail they have a
4467.84|4.44|like a low memory capacity for n-neurons
4471.08|4.98|they have something they can only embed
4472.28|6.419|like 0.14 n memories just like a big
4476.06|4.74|result from statistical physics 80s
4478.699|3.721|um but it's okay people have improved
4480.8|3.12|this the reason that they're bad it
4482.42|4.2|seems to be basically the overlap
4483.92|4.5|between your query and the memories is
4486.62|3.48|too big for two memory Too Many Memories
4488.42|3.48|you know you basically like look too
4490.1|3.84|similar to too many things so how do you
4491.9|3.96|do that you like sharpen your similarity
4493.94|3.66|function okay and the way we're going to
4495.86|3.6|sharpen it is through this function and
4497.6|3.84|this function is going to be soft so
4499.46|4.38|it's going to be like oh how similar am
4501.44|4.259|I to this particular pattern weighted uh
4503.84|3.359|exponentiated and then over how simple
4505.699|3.241|amount of all of the other ones that's
4507.199|4.5|our new measure of similarity and that's
4508.94|4.56|the minus sign of the modern hot film
4511.699|2.581|yeah
4513.5|2.76|um
4514.28|3.18|and then you can see how this thing uh
4516.26|3.36|yeah it's basically doing the attention
4517.46|4.32|mechanism
4519.62|4.44|um it and it's also
4521.78|3.78|um biologically plausible
4524.06|3.54|we'll quickly run through that is that
4525.56|4.74|you have some set of activity PT this
4527.6|4.86|like uh neural activity and you're going
4530.3|3.48|to compare that to each Chi mu and
4532.46|2.699|that's through these memory neurons so
4533.78|2.82|there's a set of memory neurons one for
4535.159|3.961|each pattern that you've memorized mu
4536.6|4.98|and the weights to this memory neuron
4539.12|4.02|will be at this Chi mu and then the
4541.58|2.34|activity of this neuron will be this dot
4543.14|2.88|product
4543.92|4.56|and then you're going to do divisive
4546.02|4.32|normalization to uh to run this
4548.48|3.06|operation between these neurons so like
4550.34|3.0|to make them compete with one another
4551.54|3.54|and only recall the memories that are
4553.34|2.76|most similar through the most activated
4555.08|2.82|according to this like soft Max
4556.1|4.02|operation and then they'll predict back
4557.9|3.66|to the PT and produce the output by
4560.12|2.88|summing up the memories weighted by this
4561.56|3.36|thing times the chi mu which is the
4563.0|3.42|weights so the weights out to the memory
4564.92|4.14|neurons and back to the memory back to
4566.42|4.08|their feet the canvas are both tiny
4569.06|3.48|and so that's how you can like
4570.5|4.64|biologically possibly Run This Modern
4572.54|2.6|Hardware Network
4575.179|3.441|and so sorry yeah
4579.94|4.299|like do you attend over every memory
4582.56|3.06|you've ever made probably not probably
4584.239|2.94|not yeah
4585.62|3.3|um I guess somehow you have to have
4587.179|3.781|knowledge you know in this case it works
4588.92|3.12|nicely because we like wipe this poor
4590.96|3.42|agent's memory every time and only
4592.04|3.9|memorize things from the environment and
4594.38|3.299|so you need something that like Gates it
4595.94|4.62|so that it only looks for things in the
4597.679|5.04|current environment somehow uh uh how
4600.56|4.26|that happens I'm not sure there are
4602.719|4.741|claims that there's this like uh just
4604.82|6.18|shift over time the claim is basically
4607.46|5.279|that like somehow as time passes the
4611.0|3.3|representation just slowly like rotate
4612.739|2.641|or something and then they're also
4614.3|2.7|embedding something like a Time
4615.38|2.819|similarity as well because the closer in
4617.0|2.94|time you are the more you're like in the
4618.199|4.02|same rotated thing
4619.94|3.66|um so maybe that's a mechanism to like
4622.219|4.261|um you know pass a certain time you
4623.6|5.76|don't recall things but the evidence and
4626.48|5.9|debate a lot around that so yeah other
4629.36|3.02|mechanisms like it I'm sure
4633.199|3.601|maybe context is another one actually
4634.76|3.6|well briefly talk about that you know if
4636.8|2.939|you know you're in the same context and
4638.36|3.72|you can send a signal like somehow in
4639.739|3.781|the previous like work out what kind of
4642.08|2.76|setting am I in you can send that signal
4643.52|2.52|back and be like oh make sure you
4644.84|2.879|attempt to these ones that are in the
4646.04|3.9|same context
4647.719|4.621|so yeah there we go uh Tim Transformer
4649.94|3.6|that's the job it path integrates its
4652.34|3.54|positional encodings which is kind of
4653.54|4.56|fun uh it computes similarity using
4655.88|3.54|these positional encodings uh and it
4658.1|2.66|only compares to past memories but
4659.42|3.72|otherwise it looks a bit like a
4660.76|4.419|Transformer setup and here's the setup
4663.14|4.019|we had our MEC LEC hippocampus and
4665.179|4.681|placements
4667.159|3.661|some yeah so here's a brief the last
4669.86|1.92|thing I think I'm going to say is that
4670.82|1.56|like
4671.78|2.399|um
4672.38|3.24|this extends tem nicely because it
4674.179|3.241|allows it previously you have to do this
4675.62|3.599|outer product and flatten that's a very
4677.42|3.18|dimensionality is like terrible scaling
4679.219|3.421|with like for example if you want to do
4680.6|3.72|position what I saw and the context
4682.64|2.88|signal something after like outer
4684.32|2.58|product three vectors and flatten that
4685.52|3.9|that's much much bigger you're scaling
4686.9|4.799|like 10 cube right rather than uh what
4689.42|4.739|you'd like to do which is like 3M and so
4691.699|3.901|this uh version of tem with this new
4694.159|3.241|modern hot field network does scale
4695.6|3.48|nicely to adding a context input as just
4697.4|3.36|another input in what was previously
4699.08|4.5|this like modern hot film Network so
4700.76|5.04|yeah there's some uh so yeah our
4703.58|3.36|conclusions is there's like proved
4705.8|3.96|somewhat interesting as a two-way
4706.94|4.86|relationship uh from the AI to the neuro
4709.76|4.5|side we use this new memory model This
4711.8|3.96|Modern Hot Wheel Network that has uh all
4714.26|3.0|of you know all of this bit is supposed
4715.76|3.0|to be in the hippocampus whereas
4717.26|2.7|previously we just had these like memory
4718.76|2.52|bits in a classic Hot field now we can
4719.96|2.34|hit the campus so it makes kind of
4721.28|2.879|interesting predictions about different
4722.3|3.6|place cell structures in the hippocampus
4724.159|3.241|and they just sped up the code a lot
4725.9|3.54|right
4727.4|3.299|uh from the neural to AI maybe there's
4729.44|3.239|some a few things that are slightly
4730.699|3.601|different this like learnable recurrent
4732.679|2.881|positioning coding so people do some of
4734.3|3.18|this I think they get like positioning
4735.56|4.26|coding as a learn RNN that updates them
4737.48|3.96|but maybe this is like uh some
4739.82|3.0|motivation to try for example they don't
4741.44|2.94|know where the weight matrices and these
4742.82|3.72|weight matrices are very biased towards
4744.38|3.18|because they're invertible generally and
4746.54|2.1|things like that they're very biased
4747.56|3.48|towards representing these very clean
4748.64|4.8|structures like 2D space so I mean uh
4751.04|4.5|you know interesting building is like
4753.44|5.1|one attention layer only and so like
4755.54|4.5|somehow by using nice extra
4758.54|3.42|representations making the task very
4760.04|3.179|easy in terms of like processing X and
4761.96|3.12|using the right positional encoding
4763.219|4.621|you've got it to solve the task with one
4765.08|4.139|of these also kind of nice and maybe
4767.84|2.76|it's like a nice interpretation is that
4769.219|2.52|you can go in and really probe what
4770.6|2.82|these neurons are doing in this network
4771.739|3.061|and really understand it you know we
4773.42|2.759|know that the position encoding looks
4774.8|2.58|like grid cells we have a very deep
4776.179|2.401|understanding of why grid cells are a
4777.38|3.12|useful thing to have if you're doing
4778.58|3.659|this path integration so it's like uh
4780.5|2.82|hopefully it helps like interpret all
4782.239|1.92|these things oh yeah and if there was
4783.32|2.16|time I was going to tell you all that
4784.159|2.761|grid cells which are my hobby horse but
4785.48|3.3|I don't think this time so I'll stop
4786.92|4.46|that excellent
4788.78|2.6|foreign
4806.73|3.2|[Music]
4820.48|4.42|because you because you've got
4822.86|3.24|electrodes stuck in here right and they
4824.9|2.88|generally have like the classic
4826.1|3.96|measuring technique is a tetrade which
4827.78|3.6|is for wife okay and they receive these
4830.06|3.06|spikes which like electrical
4831.38|3.42|fluctuations as a result of a neuron
4833.12|3.119|firing and they can like triangulate
4834.8|2.64|that that particular Spike they measured
4836.239|2.641|because of the pattern of activity on
4837.44|2.82|the four wires has to have only come
4838.88|3.96|from one position so they can work out
4840.26|5.64|which neuron sent that particular Spike
4842.84|5.04|yeah but that's so there's a set of
4845.9|4.02|neurons that have grid cell patterns uh
4847.88|3.299|lots of neurons have patterns that are
4849.92|2.94|just translated versions of one another
4851.179|3.781|so the same grid like shifted in space
4852.86|4.26|that's called the module and then there
4854.96|3.48|are sets of modules which are the same
4857.12|3.119|types of neurons that were the lattice
4858.44|3.239|that's much bigger or much smaller and
4860.239|3.48|in rats there's roughly seven so there's
4861.679|3.661|a very surprising crystalline structure
4863.719|3.061|of these seven modules within each
4865.34|3.66|module each neuron is just translated
4866.78|3.48|version of one area which uh yeah
4869.0|3.239|there's a lot of theory work about why
4870.26|3.479|that's a very sensible thing to do if
4872.239|3.241|you want to do path integration at work
4873.739|3.721|out where you are in the info based on
4875.48|5.179|your like velocity signals
4877.46|3.199|okay nice
4881.26|3.34|this data could be said this was like
4883.34|3.359|really fascinating about the friendly
4884.6|6.18|thing is this
4886.699|6.721|a product or a product of learning
4890.78|5.58|um Evolution it's like it emerges like
4893.42|4.5|uh 10 days after in a baby rats like
4896.36|3.6|after being born
4897.92|4.259|um so suddenly oh suddenly that
4899.96|4.02|structure seems to be like uh very
4902.179|4.441|biased to being created
4903.98|4.259|um unclear you know we were talking
4906.62|2.7|about how it's being co-opted to encode
4908.239|4.261|other things
4909.32|5.04|and uh so it's debatable how flexible it
4912.5|3.9|is or how hard it is but it seemed you
4914.36|3.06|know we're the fmri evidence suggests
4916.4|2.64|that there's some like more flexibility
4917.42|3.12|in the system unclear quite how it's
4919.04|4.34|coding it but it'd be cool to get neural
4920.54|2.84|recordings of it and see
4923.6|5.119|let's figure another round
4926.54|2.179|foreign