start_time|end_time|text
0.84|3.52| Yeah, hi, everyone. I decided to make a short bonus video stuff
4.36|3.4| in the news, interesting things related to deep learning. So
7.76|3.2| here, I'm just briefly talking about cool things I discovered
10.96|3.08| in the news this week related to deep learning. And I think it's
14.04|3.04| just fun to talk about the recent developments in deep
17.08|3.56| learning just to stay up to date with things. So I'm planning to
20.64|4.52| release such a video every week, if I have time. So it's also
25.16|3.36| only optional, so you don't have to watch them. So it's something
28.52|2.96| just watch it if you're interested in if not, don't
31.48|3.28| worry about it. It's just like some fun, additional video
34.76|3.36| content for this class. So then let me get started. And let me
38.12|2.96| tell you what happened in the world of deep learning this
41.08|6.48| week. Yeah, let's start with a cool application of deep
47.56|4.36| learning for COVID-19 resource needs predictions from a series
51.92|4.68| of x rays. So this was a project by Facebook AI research in
56.6|3.92| collaboration with medical doctors at NYU. And it's always
60.52|2.64| cool to involve your domain experts. I think that's super
63.16|4.2| important. As I mentioned in the lectures, it's always a good
67.36|4.0| idea to consult people who actually have some expertise in
71.36|2.28| the data that you're working with, especially if it's an
73.64|3.16| important application like a medical application. So in this
76.8|4.56| case, the researchers trained three models to predict your
81.36|3.88| patient deterioration and to help predict the resource
85.24|4.56| requirements like oxygen. So here in the first model, they
89.8|3.48| predicted the deterioration of the patient from only one x ray
93.28|4.04| image, they did the same thing, the same prediction task now
97.32|3.72| form also a series of x rays. And the third model was
101.36|4.8| predicting the oxygen supply needed for helping a patient
106.2|3.92| that was also based on a single x ray. So of course, it's
110.6|3.72| usually helpful to have multiple x rays that can also then boost
114.32|2.76| the performance if you have a sequence of x rays and you can
119.12|3.36| tackle this as a time series problem. However, these models
122.48|6.0| also work if only one single x ray is available. So how they
128.48|4.16| approach this modeling task was that they pre trained the deep
132.64|4.56| neural network on a large non COVID chest x ray database. So
137.2|3.56| they used a general x ray database. Why did they do that?
140.76|3.36| That's because they had a larger data set available this way,
144.24|4.16| because there are only limited numbers of x rays from COVID
148.4|3.92| patients at this point. So here they used self supervised
152.32|3.2| learning. Remember from the lecture self supervised learning
155.52|3.32| is this new trend where you pre train a model on a so called
159.52|4.0| pre text task, and then you find unit to your target data set. So
163.52|3.92| here, they did the fine tuning based on a smaller COVID 19 x
167.44|4.4| ray data set where they had 27,000 x rays from 5000
171.84|3.12| patients. And what was interesting is that, um, yeah,
174.96|4.4| these methods, they developed or performed human experts on some
179.4|3.4| of the measures. So of course, it's not a good idea probably to
182.88|3.36| replace humans. But I think developing these systems can be
186.24|3.32| really useful to help humans because yeah, everyone is
189.88|4.12| stretched very thin these days, especially to the large amount
194.0|5.0| of patients at hospitals right now. So maybe the doctor's task
199.04|4.88| can be done more effectively in the combination with deep
203.92|2.92| learning, especially for example, if you think of medical
206.84|3.4| staff that is maybe a little bit tired, having a deep learning
210.24|5.24| system taking also a second look at these images x rays could
215.48|4.88| maybe help you avoid making mistakes. So you can find the
220.36|3.44| full paper here on archive. And they also uploaded the pre
223.8|4.16| trained models on GitHub if someone is interested. Yeah,
228.16|5.04| regarding COVID-19 research. So on archive, which is a pre print
233.2|3.88| server, there's a large amount of 1000s of papers or
237.12|4.36| manuscripts pre prints uploaded regarding COVID-19. So this is a
241.48|4.08| general pre print server for machine learning. We have a lot
245.56|4.58| of papers on this server. So I help moderating the machine
250.14|6.3| learning categories. And every day, there are about 140 new
256.44|3.52| papers about deep learning and machine learning. So it's like a
259.96|3.32| huge amount of papers, I think there are no in total, like 14
263.28|3.76| million papers across different research domains. In any case,
267.44|5.64| you can use the search function to also search for specific
273.08|6.88| research. And here, I try to search keyword combination to
279.96|5.52| also bring up more COVID-19 related research with deep
285.48|3.48| learning. So what I showed you here on the previous slide was
288.96|3.12| pretty cool. But of course, it's not the only approach using
292.08|3.84| deep learning for COVID prediction from chest x ray. So
296.12|3.64| here using these search terms, you can find many more works in
299.76|2.44| this area. But yeah, also, you have to take this a little bit
302.2|3.68| with a grain of salt, because not all of these papers have
305.88|5.28| undergone peer review. So some of the findings may be spurious
311.16|4.08| or maybe less rigorous. So always take your archive papers with a
315.24|4.0| grain of salt. I will post a link so you can access these
319.24|2.96| papers if you're interested in that, for example, for the
322.2|3.24| context of your class projects. Yeah, there was another
325.44|4.16| interesting research project related to COVID-19 was the
329.6|4.32| learning of the language of viral evolution and escape. So
333.92|2.82| this was an article where the researchers described the
336.74|5.54| training of a bidirectional LSTM. So an LSTM LSTM stands for
342.8|8.88| long short term memory. It's a recurrent neural network of
351.68|3.4| flavor. And it's a particular, yeah, you can think of it as a
355.08|3.2| particular version of RNN. And we will talk also about that
358.28|3.32| more later in this course. So here, they trained a
361.6|4.04| bidirectional LSTM bidirectional just means that they process a
365.64|3.58| sequence from both ends from beginning to end and from the
369.22|3.22| end to the beginning. And it's a language model. So here, they
372.44|4.92| treat the amino acid sequence corresponding to a virus. They
377.36|3.48| treat this as a language model, like text, for example. And they
380.84|3.4| also draw some analogies from language modeling. For example,
384.44|3.44| they consider the context of being grammatically correct as
387.88|3.76| the biologically being correct. Like, is this like a correct
391.68|3.12| sequence, a correct amino acid sequence? Is it a plausible one?
395.72|4.12| And then also considering its semantic meaning. So here, in
399.84|2.76| context of a language, the semantic meaning would be the
402.6|3.72| meaning of the sentence. Here, it's whether the other sequence
406.32|4.04| causes immune responses or not. And yeah, they got a pretty good
410.36|8.16| performance. They have a point 85 AUC AUC stands for area
419.12|0.92| another curve,
422.12|4.0| which is rather ambiguous, because what curve do we mean
426.12|3.26| here, if there's no context, if you see something like a UC in a
429.38|4.06| paper, it usually means receiver operating characteristic area
433.44|4.76| under the curve. So our OC, that's a measure of false
438.2|4.08| positive and true positive rates, if you shift the
442.4|2.68| prediction threshold, but that's maybe too much detail at this
445.08|5.44| point. So what's important is that the point five is random.
450.52|4.24| So point five is a random prediction. And one point Oh, is
454.8|5.04| a perfect model. So in this way, they are closer to a really good
459.84|4.76| model than to a random or bad predictor. So yeah, that is
464.6|4.96| another interesting COVID-19 paper. Moving on to the more
469.56|3.16| like business side of AI or deep learning. There was also
472.72|2.76| something I found really interesting, not that
475.48|2.72| interesting, but it was like, quite a headline. So there's
478.2|5.04| like a project called human AI, that just got 3.2 million of
483.24|4.6| funding to build a personal intelligence platform. So here,
488.08|3.68| that sounds very interesting. So what it is about is that they
491.76|2.84| are building an individual personal AI that is secured by a
494.6|3.68| blockchain to retain and recall information. So you have two
498.32|3.12| passwords in here. So you have the AI and blockchain, black
501.48|5.34| blockchain. So this is building a knowledge base in a way it
506.82|3.82| sounds like it, but based on an individual's information. So you
510.64|4.94| can maybe also think of it as a second brain. So they say it's
515.58|2.66| made possible through a convergence of neuroscience,
518.24|3.72| natural language processing, and blockchain to deliver seamless
521.96|3.52| in the moment recall, GPT three is built on the memories of the
525.48|3.84| public internet, while Luther, that's their system is built on
529.32|3.52| the memories of your private self. So it sounds like, yeah,
532.84|4.6| they're attempting to build a second brain or digital copy of
537.44|4.44| your brain. So that kind of also reminded me of of this movie
541.88|4.6| scene here, or actually TV show scene might be also fun to let
546.48|3.36| let me know if you know this, what the name of the TV show is
549.84|5.36| as a little side quiz here. Anyways, I'm moving on. So
555.2|5.2| regarding access to data, to make a transition here, there's
560.4|3.4| also a cool initiative by Twitter. So Twitter is opening
563.8|3.56| up its full tweet archive to academic researchers for free.
567.72|4.72| So there have been projects before academic projects where
572.44|3.08| people used Twitter data, but as I as far as I know, it was a
575.52|4.24| little bit tedious to access the data through the API, because
579.76|4.24| there were some limitations. Now, um, yeah, they say they
584.04|5.28| want to make this easier and to give more access. So they say,
589.32|3.96| for example, they are giving applicants approved applicants,
593.4|3.6| the higher monthly tweet volume cap of 10 million tweets per
597.0|5.0| month, which is 20 times higher than what it was before. And
602.0|3.76| yeah, they also allow more precise filtering to help
605.76|3.68| researchers pinpoint tweets and other relevant data to what they
609.44|4.04| are studying, basically. So in that way, making research based
613.48|3.0| on Twitter a little bit more convenient. So what can you do?
616.48|3.78| What? What is Twitter data useful for? Why is why is that
620.26|3.62| actually cool? So there are actually quite some projects
624.64|4.4| involving social media data that are quite useful, beyond just
629.04|4.04| a simple sentiment analysis. So here, I saw another news article
633.08|3.16| where they're using artificial intelligence to manage extreme
636.4|4.72| weather events. So in this research, they use social media
641.12|4.04| contributions, for example, tweets to more usefully manage
645.2|5.4| crises. So they developed a noise reduction mechanism to
650.64|3.4| filter for valuable information from social media to better
654.2|3.08| assess trouble spots where there are, for example, floods or
657.28|4.76| snowstorms, and so forth. So yeah, that was another
662.04|5.28| interesting application of deep learning, where information can
667.32|7.24| be efficiently accessed to help certain areas where there are
674.84|5.2| problems. Okay, talking about data sets, large data sets. So
680.04|3.52| one data set that is very common in the deep learning community
683.56|3.84| very commonly used as a benchmark is the image net data set. I
687.4|6.04| think it's already 1616 15 years old, it has been released around
693.44|4.28| 2005 2006. It's still very popular. It's a very large
697.72|4.2| data set about 14 million images. And it's usually used
701.92|3.04| for evaluating the classification performance of
705.28|4.52| image models like convolutional networks, or now also visual
709.8|5.04| transformers. So the problem, though, is that the image data
714.84|4.08| set is kind of notorious for mistakes. And there are also
718.92|3.6| incomplete labels. So sometimes you have multiple object in an
722.56|4.96| object in an image, for example, as shown here, you have a cow
727.52|5.92| here, and then a barn. And some, yeah, I don't know, maybe also
733.44|2.92| sky in the background. So there are multiple things going on,
736.36|4.56| or actually, they call it an ox here. So they are actually not
740.92|3.44| it's, it's the fence, I just see it here, it's the fence here. So
744.36|3.24| there are multiple objects in this image. And if you train a
747.6|4.32| classifier, a regular classifier, usually, it only gives
751.92|4.32| you the most confident class label as the prediction. So if
756.24|3.58| you have a classifier that predicts barn, it may be wrong
759.82|5.14| because the image was just labeled with ox here, cow. And
764.96|4.32| in that way, the classifier may be correct, but you are
769.28|2.8| counting it as a misclassification. So here in
772.08|5.0| this project, the researchers are relabeling image net. So
777.08|3.76| they are adding multiple labels to the image here. So they are
781.04|4.0| using also machine learning to do that, because it would take a
785.04|4.0| lot of people or resources to look at these 14 million images
789.04|3.52| and to assign the correct labels. So they make their life
792.56|2.12| easier by also using deep learning for that. So it's kind
794.68|4.04| of like a chicken egg problem. What comes first the data set or
798.72|3.2| the model, and the model can then be used for labeling the
801.92|2.72| data set. Here, what they do is they use a different data set,
804.64|4.22| they use 1 billion images from Instagram. And they train a
808.86|4.56| model called efficient net for for training this model to
813.42|4.16| become a machine annotator to annotate the 14 million images
817.58|4.22| in image net. They use crop regions for that. So they are
821.8|3.08| cropping different regions of the image. So for example, as
824.88|3.12| shown here, they are cropping the image into smaller regions
828.0|3.84| and then apply a classifier to each of these smaller regions to
831.84|3.96| obtain the class label. And then you have this model multi label
836.04|3.32| context for each image. That is also something I found actually
839.36|5.56| useful and interesting. Yeah, another project from Facebook AI
844.92|3.88| research here, I also thought that might be a cool application
848.8|3.6| of machine learning, and deep learning that has some use for
853.36|4.24| the real world. So here, so what Facebook did is they used AI to
857.6|3.76| improve photo descriptions for people who are blind or visually
861.36|4.8| impaired. So they developed a smartphone app that way you can
866.16|3.74| take a picture and that app can then describe what can be seen
869.9|5.94| in that picture, like an audio message. So the system has been
875.84|2.24| around, I think for a couple of years, but they are just
878.08|2.76| improved to make it more accurate. So here, they trained
880.84|4.4| a res next model on 3.5 billion Instagram photos and the
885.24|3.4| corresponding hashtags. And they also are combined with a fast
888.64|4.88| RCN object detector to describe different aspects of this image.
893.52|4.44| So for example, here in this example, the description is it
897.96|5.8| may be an image of one person standing on or at Machu Picchu.
903.76|3.72| So going back here, this is kind of similar to these crop regions
907.48|2.68| where people have these different crops of the same
910.16|4.28| image, and then assign a label here. It's a similar approach
914.44|4.16| that you have, for example, person Machu Picchu, and so
918.6|4.36| forth. But the addition here is that there's also a text
922.96|11.0| describing this or putting this into context.