start_time|end_time|text
0.46|3.56| All right, let's now take a look at some code examples. So I
4.02|3.84| prepared multiple notebooks. One is a multi layer perceptron from
7.86|4.64| scratch implementation just to practice my calculus skills. One
12.5|4.96| is pytorch, sigmoid and mean squared error implementation that
17.46|3.64| I showed you on the slides. And this one is the pytorch with a
21.1|2.72| soft pytorch implementation with a softmax activation and the
23.82|3.8| cross entropy loss. I will only walk you through this one
27.62|2.3| because they are all fundamentally very similar. And
29.92|3.08| yeah, I don't want to make the lectures too long. So let's get
33.0|4.38| started. So here again, just the boilerplate stuff, all the
37.38|4.1| imports, here are some hyper parameter settings, I set the
41.48|3.52| batch size to 100, it's kind of arbitrary. Usually people like
45.0|5.66| to use also values like powers of two, like 32, 64, 128. I use
50.66|5.28| 100 epochs. And yeah, here, the MNIST data set. So the MNIST
55.94|3.12| data set is, or how we load it is how we did it also in the
59.06|3.54| softmax lecture. So there's nothing new here, I will have a
62.6|3.34| separate video explaining how you can set up these data
65.94|4.46| loaders for your own data set. So now here, we are just
70.4|3.78| regarding it as the standard MNIST data set that is already
74.66|2.96| included in torch vision. So what I want to focus on is
77.62|4.04| really here, the multi layer perceptron implementation. So
81.66|5.04| here, really, what's new compared to softmax regression
86.7|3.44| is that we have this hidden layer. So if I remove this
90.14|6.44| hidden layer, for a second, and just write num features here,
97.5|4.88| oops, then this is the same as the softmax regression code. The
102.38|2.4| only maybe small difference that you might notice is that
104.78|6.96| okay, I would also have to remove this one, cancel this out. So
111.86|5.68| the only difference is that I'm using small random weights. I
117.54|4.22| asked you why we don't implement or why we don't initialize the
121.76|2.62| weights to zeros in multi layer perceptron. So that's something
124.38|4.48| for you to think about. But yeah, here, we use a standard
128.86|4.84| normal distribution, and we scale it. So the mean, so there
133.7|3.8| are two parameters for this, the mean and the standard deviation.
137.82|2.36| So usually a standard normal distribution, as you might know,
140.48|2.98| has mean zero and unit variance. So standard deviation of one
143.58|4.08| here, we use a smaller value point one, just making the
147.66|3.2| distribution a bit narrower, closer to zero. So that's because
150.86|3.64| we don't want to have too large or too extreme values, because
154.5|5.12| recall, sigmoid activations can saturate. So then we have very
159.62|1.76| small gradients. So it's actually good to have them not
161.38|3.84| too big. So yeah, that is what we do here. The whole point
165.22|3.08| really is just having small random weights centered at zero.
168.82|3.64| Later, in later lectures, we will also learn about other ways
172.46|4.32| to initialize the weights. But yeah, let me undo that.
176.78|4.2| Otherwise, the code won't work. So now, what's different from
180.98|3.52| softmax is really that we have this hidden layer here in
184.5|5.44| between, right between the input and output layer. Alright, so but
189.94|3.52| there's nothing really new. I mean, I wish I could tell you
193.46|3.28| something exciting here. But actually, it's very similar to
196.74|2.2| softmax. So it's actually a very good sign. It's not too
198.94|6.42| complicated, I hope. Yeah, just to use probes here, you don't
205.36|3.82| have to do that. So you can actually skip this step, you
209.18|3.8| don't need that. Because if you use the cross entropy loss,
214.46|3.44| pytorch will already compute that softmax implicitly
217.9|5.92| automatically. Yeah, and when we initialize here, the multilayer
223.82|4.04| perceptron, we have a number of input features is 28 by 28.
228.18|4.64| That's the dimension of MNIST. And I use a hidden layer with
232.82|5.62| 100 units. That's a hyper parameter can change that
238.44|4.26| number and see whether it performs better or worse. We
242.7|6.0| use also the stochastic gradient descent optimizer. Notice now,
248.74|3.84| so this is so I have a separate function for computing the loss
252.58|4.52| that's for each epoch. So how I implement that is I'm iterating
257.1|5.76| over the data loader, and compute the loss and edit up. So
262.86|2.4| this is instead of computing it on the whole data set, because
265.26|3.36| the data set might be too large to load it into memory. So in
268.62|4.08| MNIST, for MNIST, it might work, but it's just a good practice to
272.74|3.64| implement a function that does it also incrementally. Notice
276.38|3.0| this is just a compute loss function that I use to compute
279.38|3.44| the loss on the training set. This is not a training function.
283.26|2.76| But there was a good question on Piazza, I used something similar
286.02|4.88| before, no grad, I before used on the manual version, like
291.34|5.12| enable, great, enable gradient faults. This is the same thing.
296.46|5.14| So here, I disable the gradient, or I'm saying we don't need a
301.6|4.92| gradient. So I'm saying, don't build this computation graph.
308.2|3.68| Why do I not have to have a computation graph? So here, I'm
311.88|3.04| just computing the loss. So there is no backward, so it
314.92|3.84| would be wasteful. Actually, this should be just that would
318.76|1.6| be better. Okay.
320.36|6.08| Okay. Yeah, I'm also how I'm computing the loss is actually I
326.44|3.36| can show it to you also here. So here, how I'm computing the
329.8|4.2| losses, I'm using the negative log likelihood loss. And then
334.0|4.14| I'm calling log probas. This is how we do it, let's say,
338.14|4.66| theoretically, mathematically. And I've done that in my from
342.8|3.56| scratch and the other implementation. But in practice,
346.36|3.52| it's actually better to use f cross entropy, a functional
349.88|4.4| cross entropy version. Um, so actually, let me modify this
354.28|3.76| code to show you the recommended way. I did that just for
358.04|7.4| comparison purposes. But it's actually better to have it like
365.44|5.88| this. Hope I don't delete it in a way that it doesn't work
371.32|6.0| afterwards. But we will see will be a surprise. Okay. So yeah,
377.32|8.04| I'll call it cost. All right, so yeah, we don't need to call
385.4|3.28| softmax ourselves, because yeah, pytorch is already doing it for
388.68|5.88| us. But except that the training is exactly the same. We have we
394.56|3.36| call forward here. So that gives us the outputs, the logits,
398.28|4.04| compute the cross entropy, where this one does the lock softmax
402.32|5.1| for us. And we set the gradients from the previous round to zero
407.7|4.1| call backwards to do the backpropagation. And this is just
411.8|6.08| for logging purposes. Maybe I should put it down here. It's
417.88|5.28| like just for keeping track. So we can make the plot. And this
423.16|6.34| is the model update. And here I'm computing the loss over the
429.5|3.48| whole training set. This is just for plotting. So this is using
432.98|3.36| this function here. I will actually show you another video
436.34|2.86| after that, where I refactor this a little bit into Python
439.2|6.92| scripts. All right. Yeah, I common problem. I forgot to
446.4|4.84| execute these things. Okay, it's training. So this is training on
451.24|6.6| the CPU. I compiled pytorch for the M one Mac, so it might be
457.84|6.8| a bit faster than on normal CPU. But yeah, it's still simple
464.64|3.12| enough to just run it on a CPU, you don't need a GPU for that
467.76|4.12| really. Right, it might take a while now, you have seen the
471.88|3.68| results on the slides already, right. So the loss and things
475.56|5.36| like that. So let me pause this video, I can show you the result
480.92|3.48| in the beginning of the next video. And I will show you also
484.4|5.96| how I would personally run code in Python scripts. So using
490.36|2.72| Jupyter Notebook is super nice for teaching because we have
493.08|3.38| everything in one notebook. But like I said, if our code becomes
496.46|3.62| more complicated, it might be nice to put some of the code
500.08|3.48| into Python scripts where it's sometimes easier to debug. And
503.56|3.72| also, you can then reuse some of your functions. So let me pause
507.28|2.36| this video, I will make another video showing you the Python
509.64|7.0| scripts.