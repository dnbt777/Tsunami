start_time|end_time|text
1.92|3.3| So in this video, I want to talk about a small modification that
5.22|3.78| we can make to improve the GAN training. In particular, we are
9.0|3.32| looking at improving stochastic gradient descent for the
12.36|4.26| generator. But yeah, before we get to that, let me highlight or
16.62|3.12| just list some of the problems with GAN training. In a future
19.74|4.98| video, I will show you some tricks and tips for addressing
24.76|3.76| some of the problems or at least for improving GAN training. But
28.52|3.36| here, let's just take a look at this list of problems. So one
31.88|3.68| problem is the constant oscillation between the generator
35.56|3.16| and discriminator loss. So things never converge, things
38.72|3.76| might just keep oscillating. Another very common problem is
42.72|3.96| mode collapse, which essentially means that the generator will
46.68|2.96| learn how to generate a particular type of data that is
49.64|4.64| particularly good at fooling the discriminator. So that is also
54.28|3.52| one problem usually when you see that the generator is only
57.8|3.72| producing one kind of image, then this is usually due to this
61.52|3.76| type of mode collapse, whether a generator, it just exploits a
65.28|2.36| weakness in the discriminator, just producing a particular type
67.64|5.36| of image. One common problem with a traditional or
73.0|3.44| conventional GAN training that I showed you before, or that I
76.52|3.58| that we discussed when we had this min max setup is that the
80.1|2.38| discriminator would be too strong, usually, or what can
82.48|2.88| happen is that the discriminator is too strong, which is a common
85.36|4.08| problem, because classification is simpler than generating data.
89.48|4.0| So it can easily be that the discriminator is too strong. And
93.48|2.28| if this happens in the very beginning that the discriminator
95.76|3.8| starts on very strong and using the loss gradient that I showed
99.56|2.56| you earlier, what happens is that the gradient for the
102.12|3.48| generator will vanish, it will be too small, and the generator
105.76|2.76| can keep up with the discriminator. And then, yeah,
108.52|3.52| things won't train at all. Another problem could be that
112.04|2.84| the discriminator is too weak. And the generator produces
114.88|4.4| non realistic images that fool it too easily. So the difference
119.28|2.36| here between one is that the discriminator is too strong. And
121.64|2.44| here, it's too weak. In practice, it's usually that the
124.08|2.4| discriminator is too strong, because the classification is
126.48|4.12| easier than data generation. So there is a little trick that we
130.6|6.54| can apply to at least address this problem to some extent. And
137.14|2.58| that is something I will explain in the next couple of slides.
139.72|5.76| Okay, let's now focus in on the problem related to the
145.52|3.96| discriminator being too strong, such that the gradient for the
149.48|3.56| generator vanishes and the generator can't keep up, which
153.04|3.6| can be fixed, or at least mitigated as follows. So here,
156.64|4.36| what I have is the original can formulation that I showed you
161.4|4.64| from the paper earlier from the algorithm one screenshot. And
166.04|3.76| what we had is here the update for the generator. So this is
169.8|3.44| the gradient of the loss with respect to the generator weights.
173.76|7.24| And yeah, if you recall, the generator wants the discriminator
181.0|4.04| to output something close to one for these generated images. So
185.04|2.68| here, these are the generated images, and it wants the
187.72|5.2| discriminator to think the they are real. And then if we have
192.92|4.4| something close to one, then we'll be lock one minus one,
197.72|4.88| which will be minus infinity. And this is where we then
202.6|4.18| maximize, sorry, minimize this loss function. And it is
206.78|4.1| maximized if this is somewhat close to zero, because then we
210.88|5.72| have lock one minus zero, which is zero, right. So in this case,
216.6|7.24| what we want is something close to one. But it might happen in
223.84|4.76| the beginning, especially that in the beginning that the output
228.6|3.16| of the discriminator is close to zero. Because in the beginning,
231.76|4.32| it is kind of hard to generate new images from scratch if the
236.08|2.52| generator hasn't learned anything yet. So in the first
238.6|3.32| few iterations, so in the beginning, it will be very easy
241.96|3.68| for the discriminator to tell a part real and fake. So in the
245.64|3.72| beginning, it will output something close to zero. This
249.36|3.6| will maximize this loss. And we want to minimize it. So that's
252.96|3.04| actually good. But the problem is that the gradient signal will
256.0|3.96| be relatively small. And it will be kind of hard this way for the
259.96|3.16| generator to learn efficiently. I mean, it will be able to learn
263.12|3.48| but not very efficiently, because the gradient will be
266.6|3.64| relatively small. And it can be improved, like shown at the
270.24|3.24| bottom. So but yeah, let me maybe outline the problem first
273.48|4.0| with a gradient here. So what we have is a lock one minus
277.52|4.68| something, let's call this generated image, or not
282.2|2.96| generated image, the inside is a generated image. But let's just
285.16|5.56| call this whole thing x prime. Or maybe maybe something like y,
291.08|6.32| y hat, let's call it y hat. So what we have is lock one minus y
297.4|5.56| hat here. What is the derivative of that? So for that, we would
302.96|4.44| need the chain rule. So you know that the derivative of something
307.4|9.24| like log x would be one over x. So here, we have to use the
316.64|3.56| chain rule, the outer times the inner derivative. So what we
320.2|4.56| have is for let's do the inner derivative first. So it's one
324.8|3.54| minus y hat. So we are looking at the derivative with respect
328.34|4.62| to y hat, of course. So the inner derivative here would be
333.24|4.48| one minus so the derivative of one minus y hat would be minus
337.72|6.88| one, right? Because with respect to y hat, then this vanishes and
344.6|7.08| this becomes a one. So we have minus one times the outer
351.68|3.6| derivative, like I said before, the outer derivative is as
355.28|3.32| follows. So for log x, it would be one over x. So here, the
358.6|5.74| outer derivative would be one over one minus y hat, right? So
364.34|6.02| the derivative then is minus one. Or just let's write it like
370.36|9.12| this, minus one, one over y hat, y. I'm doing prime here, but I
379.48|5.04| mean, head, of course. Okay, so this is our derivative. So if
384.52|4.32| something is close to a zero here, our derivative will be
389.28|6.92| around minus one, if this is close to zero. And I mean, this
396.2|3.52| is okay, but it's not like the strongest derivative. So it
399.72|3.24| won't be the best, let's say for learning the generator in the
402.96|4.8| beginning. So a trick is to turn this greater descent problem into
407.76|4.24| the following gradient ascent problem. So now, what I'm doing
412.0|5.28| here is I'm dropping this one minus here. So then if the
417.28|11.54| discriminator outputs zero here, the loss would be infinity. And
428.82|4.78| if the generator outputs, sorry, if the discriminator outputs a
433.6|4.08| one, which is what we want, the loss would be zero. So now we
437.68|6.28| have the loss between zero and infinity. And before we had it
444.1|4.62| between minus infinity and zero. So before we wanted to minimize
448.72|7.52| it, so before we wanted to minimize the loss, now it's
456.24|6.0| green ascent, we want to maximize this term. And this
462.24|2.92| will give us here a stronger gradients if the initial
465.16|3.48| prediction of the discriminator is that it can detect the
468.64|3.04| generated images. So if in the worst case scenario, what we
471.68|2.52| have is that the discriminator outputs something close to a
474.64|2.84| zero, right. And now if you look at this term here, the whole
477.48|5.2| term, that's on lock x term and the derivative lock x is
488.48|4.46| is one over x, right. So in the worst case, now we have something
492.94|3.54| close to zero. And let's say we have one over a very small
497.56|8.4| number, then what will happen is that the gradient will be what
505.96|5.04| the derivative will be much larger here for the discriminator
511.0|4.56| that can successfully detect the generated images. So here, using
515.56|4.88| this formulation at the bottom, the generator will burn more
520.44|4.12| effectively in the beginning. Yeah, so by now, we have seen a
524.56|3.08| lot of gradient ascent and descent and flipping between the
527.64|3.76| two and so forth. So it might look super complicated. But in
531.4|2.84| practice, actually, it's not as complicated as you might think.
534.48|2.68| It's actually pretty straightforward to implement the
537.16|4.52| GAN loss function with your regular gradient descent. So we
541.68|3.08| will be using regular gradient descent for both the
544.76|2.8| discriminator and the generator. And it will probably be more
547.56|3.0| clear when you see that implemented in code in the next
550.56|6.24| video. But yeah, let me briefly just finish the section on this
556.8|3.08| trick, or just in general, how we can turn everything into a
560.2|3.48| gradient descent problem. So in an earlier video, on the
563.68|3.24| original, again, we have seen in the paper that they mentioned
566.94|4.54| gradient ascent for training the discriminator. So previously, in
571.48|1.7| the paper, they mentioned that they are maximizing the
573.18|3.2| prediction probability of classifying real is real, and
576.38|2.86| fake is fake for the discriminator. But as you
579.24|4.24| remember, from the logistic regression lecture, long time
583.48|4.32| ago, lecture eight, I think, what we said is that maximizing
587.8|3.8| the log likelihood is the same as minimizing the negative log
591.6|3.44| likelihood. So the negative log likelihood, we can also think of
595.04|4.68| it as the cross entropy. So in that way, we can actually get
599.72|4.2| just use our regular cross entropy binary cross entropy in
603.92|3.0| pytorch to optimize the discriminator, we don't have to
606.92|6.2| do gradient ascent. So the same for the generator. So for the
613.12|3.52| generator, we first in the original paper, they first said,
616.8|2.48| it's about minimizing the likelihood of the discriminator
619.28|7.04| making correct predictions. And minimizing the likelihood is the
626.32|3.6| same as maximizing the cross entropy. In that sense, it's
629.92|4.32| similar to here, maximizing the log likelihood and minimizing
634.24|2.8| the cross entropy here, it's now flipped, minimizing likelihood
637.04|3.64| and maximizing cross entropy. But we just talked in the
640.68|3.72| previous slide, that this is actually not ideal, because the
644.4|3.78| gradient small gradient issues. So we said that it doesn't work
648.18|3.42| well in practice because of these small gradient issues. So
651.6|4.5| what we did is we flipped on we didn't flip, but we modified the
656.1|5.02| loss first, so that we can use gradient ascent. But in
661.12|3.08| practice, it's even better to just flip the labels and
664.2|3.48| minimize the cross entropy. So what we are doing is we are
667.84|4.12| forcing the discriminator to output high probabilities for a
671.96|5.44| real image, if an image is fake, so a high probability for the
677.4|4.6| real label, given that the image is fake. If this all is very
682.02|2.74| dense and complicated here on the slide is a lot of
684.76|3.48| information here, let me go through the next couple of
688.24|3.48| slides where I will get this entangled this a little bit only
691.72|2.72| two more slides. And then we will see a code example in the
694.44|3.12| code example, you will see it's actually pretty straightforward.
698.84|5.32| Okay, so now I will just step by step illustrate how everything
704.16|3.2| relates back to our binary cross entropy or minimizing the
707.36|3.8| negative log likelihood. So here, this is the gradient ascent
711.16|4.24| step from the original paper from the GAN paper. So again,
715.4|3.8| this is for the discriminator. And we want the discriminator
719.2|5.92| for the real images to output something close to one here. And
725.16|3.2| on the right hand side, for the fake images, we want to output
728.36|5.32| something close to zero. So this is the original GAN objective
733.68|4.0| for the discriminator. And it's with the gradient ascent
737.68|3.0| described in the paper, but we can turn this into a gradient
740.68|3.32| descent problem by just using our negative log likelihood
744.0|3.76| function, the loss function that we have seen from the logistic
747.76|5.32| regression lecture. So here, this whole thing is I just use
753.08|2.12| that from the logistic regression lecture, this is our
755.44|3.8| loss function we use there. And here, I'm just highlighting how
759.36|5.56| the GAN objective maps to this loss function. So again, we had
764.92|4.68| these two parts, we had a minus y, and then we had minus one
769.6|4.88| minus y. So let's just focus on the y here. So if the true label
774.48|3.52| is one, then we use this term, right. And if the true label is
778.0|2.96| one here, also, then this will become zero. So we don't do
780.96|3.2| anything with this one. So if the true label is one, we don't
784.36|2.24| do anything with the right hand side, we only do something with
786.6|3.88| the left hand side. If the true label of the class label is zero,
790.76|3.16| then this whole thing will become zero. So we don't use
793.92|3.4| this one. And this one becomes zero. So one minus zero, this
797.32|5.4| one becomes one. So we are using only this right part if the class
802.72|3.36| label is zero. So there are these two parts to the loss
806.08|4.92| function. This is just from the logistic regression lecture. So
811.0|4.8| now let's focus on on this part here. Right. So we want this to
815.8|4.16| be close to one. And this is for the real images. And we said for
819.96|4.64| the real images, we have class label one. So for the real
824.6|3.88| images, we are looking at, at this part here. And we want the
828.48|7.88| prediction also be close to one. So that is how our objective
836.52|3.56| maps here to a gradient descent problem, because here we have
840.08|3.2| also the minus for the negative log likelihood, this is a
843.28|2.68| negative log likelihood, we have minus and minus. So we are
845.96|5.84| minimizing, trying to minimize this term, right. And for fake
851.8|2.72| images, we are looking now at the right hand side, right?
854.52|7.32| Because for fake images, we have the label zero, so this will
861.84|3.04| become zero cancel. So the whole thing will cancel, we only look
864.88|5.94| at the right hand side here. So then this one will be one. And
870.82|5.06| then we look at lock one minus y hat. So again, we have a
875.88|4.16| negative log likelihood, it's a minimization here. So we want
880.04|3.6| to, when we do the gradient descent, what happens, we will
884.48|3.0| learn how to output a y hat here, this is the ideal case,
887.48|6.36| this is what minimizes our loss here. Right, because otherwise,
894.16|3.36| minus if this would be a one, then the whole thing will be
897.56|6.52| oops, the whole thing will become zero and minus log of
904.12|3.8| zero will be minus minus infinity, it will be infinity.
907.92|5.24| Right. So this is highlighting how this one, the gradient
913.16|6.52| ascent becomes a gradient descent in practice when we use
919.68|4.28| our negative log likelihood. Yeah, let's now look at the
923.96|4.72| generator objective. So at the top, this is from the original
928.68|4.88| paper, the gradient descent part of the original GAN paper. And
934.24|2.88| we can also transfer this to our negative log likelihood
937.12|6.4| context. So because now we are having the fake images from the
943.52|4.4| generator, so we have the fake labels, which are zero. So this
947.92|2.68| part is zero. So this whole thing cancels, we can ignore
950.6|3.28| this part, only focusing on the right hand part. But if we use
953.88|5.0| a regular negative likelihood, if we optimize this, what will
958.88|3.2| happen, it will wants to optimize the prediction to zero
962.08|5.96| right. However, we want the opposite, we want to fool the
968.08|3.16| discriminator, right, we don't want to encourage it to detect
971.28|3.36| the fake images, we want to fool it so that it thinks these are
974.64|4.88| real. So how can we do that, we can flip this sign here to a
979.52|3.88| positive sign. So then, instead of this being maximized to y
983.4|6.2| hat zero, it will be maximized to y hat equals one. Okay, so
989.6|4.04| but we said, actually, this is bad, bad, because flipping the
993.64|5.32| sign, okay, it will correctly achieve our objective, but the
998.96|5.16| gradients will be very small, if our discriminator is successful
1004.32|4.64| in predicting that the generated images are generated. So we
1008.96|2.76| said, Okay, this is actually not a good idea. We want to modify
1011.72|2.52| this loss function where we don't have the one minus here,
1014.24|4.08| right. So that is what we spent a couple of minutes about
1018.32|4.4| talking in the previous slides. So what we can do instead,
1022.76|4.44| instead of modifying this label, sorry, in instead of modifying
1027.2|4.08| this sign here to a plus sign, instead of doing that, we can
1031.28|3.76| just flip the labels. So flipping the labels. So instead
1035.04|3.52| of doing the gradient descent before, so before we had this
1038.76|2.56| gradient descent here with this one minus, and we said this is
1041.32|3.8| bad. So we are removing the one minus here, we do a gradient
1045.12|4.8| descent. And we can just flip the labels to turn this into a
1049.92|4.92| gradient descent problem. Okay, so the modified loss function
1054.84|3.8| now is, or what we're doing is, we have usually for the fake
1058.64|6.04| images, we have the label zero, right? Now we are flipping this
1064.72|4.04| now, instead of using label zero, we are using label one for
1068.76|3.76| the fake images, this is for the generator. And then we can use
1072.52|2.32| this part of the loss function, because yeah, this one will be
1074.84|5.22| one, this one will be one here. So this whole thing cancels. And
1080.06|2.7| we're looking at this one. And then what will happen is, if we
1082.76|5.32| have a one, it will also try the prediction to make it similar to
1088.08|7.2| the one. And then, because we provided as one, but in reality,
1095.28|2.48| it's actually still the zero, I mean, it's a fake image, what
1097.76|2.88| will happen is that the screen data will be trained to make
1100.64|3.74| the wrong prediction. So the generator trains to fool the
1104.38|4.1| discriminator to make wrong predictions. Okay, so this was
1108.48|3.88| probably super complicated, lots of stuff happening. So in the
1113.14|3.86| next video, I will show you a code example. And you will see,
1117.16|2.96| we are just using regular binary cross entropy for everything.
1120.52|4.42| And the other regular stochastic gradient descent or Adam
1124.94|9.72| optimizer, and it will be pretty clear then afterwards, I hope.