start_time|end_time|text
0.64|4.0| Yes, so in the previous video, we discussed GPT version one,
4.68|3.96| which was a unidirectional transformer model, where the
8.68|3.72| pre training task was the next word prediction. So it was
12.56|3.64| processing the inputs in a leftward fashion, like from left
16.2|4.16| to right. And BERT is a transformer that is a
20.48|4.0| bidirectional one. So BERT stands for bidirectional encoder
24.48|5.64| representations from transformers. So BERT was developed
30.48|4.6| around 2018 by Google research. And like I said before, the main
35.08|3.28| concept is this bidirectional nature. So the bidirectional
38.36|4.76| pre training using masking that is not going from left to right,
43.24|3.32| but it's just randomly masking, it's essentially a very simple
46.56|2.92| concept, I will have a slide on that illustrating how that
49.48|4.36| works. So the main architecture is essentially identical to the
53.84|3.2| original transformer and GPT. So both both are based on the
57.04|2.84| original transformer paper with a multi head attention and so
59.88|5.72| forth. Except now that they have this bidirectional masking, which
65.6|3.44| is also known as close task, there was a paper on that that
69.04|4.48| they reference, and they have two pre training approaches, one
73.52|3.72| is this bidirectional masking, and one is the next sentence
77.24|3.44| prediction. So they have a binary prediction task where they
80.68|3.36| show the model two sentences, and the model has to predict
84.04|3.68| whether sentence B. So if you have two sentences, A and B, the
87.72|5.08| model has to predict whether B is indeed, the next sentence in
92.8|3.88| a document or whether it's a random sentence. And I will also
96.68|2.84| have a slide illustrating that. So here, this is just the
99.52|3.08| overview. And we will talk a little bit more in detail in the
102.6|3.84| following slides. So let's take a look at BERT in more detail
106.44|3.92| now. So starting at the bottom here, what are the inputs? How
110.36|3.92| do the inputs to BERT look like? So here's a figure from the
114.28|6.24| original paper. And at the top are the tokens as input. So for
120.52|6.2| instance, imagine you have a sentence, sentence one called my
126.72|5.64| dog is cute. And then the second sentence is he likes playing. So
132.36|7.8| this is sentence two. And you can see there's already some
140.16|4.32| tokenization going on. So each token is essentially one word.
145.76|4.48| And you can also see that certain verbs like playing, they
150.24|3.24| become play and then as a separate token ing. So there's
153.48|4.84| also some sort of pre processing or stemming going on. These
158.32|4.8| inputs are then augmented by a special classification token and
163.24|5.72| sentence separator. And then they are going through a process
168.96|3.68| called a workpiece model basically to get to produce so
172.64|3.44| called workpiece embeddings. It's just a particular way of
176.08|3.0| creating embeddings. We want to discuss this in detail. But if
179.08|3.16| you're interested, this refers to this paper here. So it's just
182.24|3.52| a different method of obtaining embeddings. So now that you have
185.76|2.44| let's say these token embeddings, like a real valued
188.2|4.64| vectors, like going from the words to the real valued
192.84|4.4| vectors, then there are also these segment embeddings. So
197.24|8.8| they're also real valued vectors, essentially. So for the
206.04|5.72| first sentence, you have the same segment embeddings for each
211.76|6.32| position, and then the same is true for the second sentence. So
218.08|3.32| if there's a sentence to here, so you have something that
221.4|3.62| denotes whether the word embedding or token embedding
225.02|3.54| comes from the first or the second sentence, which segment
228.56|5.64| essentially, then there are also these position embeddings. So
234.2|2.48| you maybe recall from the original transformer paper,
236.68|3.56| there were like these sinusoidal embeddings. So there's also a
240.24|4.32| form of position embedding here. And these all like the token
244.56|3.2| embedding, segment embedding and position embedding, they all get
248.36|3.16| added up together. So they are summed. And these are then the
251.52|5.36| inputs to the transformer block, like the multi head attention.
258.48|5.4| And yeah, in general, so using these inputs, there are pre
263.88|5.76| training tasks, and the pre training tasks are executed on
269.64|4.0| two data sets. So they have this book corpus data set, which
273.64|4.76| consists of 800 million words. And in addition to that, so that
278.4|4.0| was also used in GPT. In addition to that, they also use
283.4|4.84| GPT, they said it was 7000 books, if I recall correctly,
288.68|3.12| corresponding to 800 million words. In addition to that, they
291.8|5.24| also use the Wikipedia data set consisting of 2500 million
297.04|4.4| words, so 2.5 billion words. Then on these pre training
301.44|4.44| tasks, the mass language model that I mentioned earlier, and
305.88|2.4| the next sentence prediction. So they have two different
308.28|3.16| training tasks here. So let's take a look at these pre
311.44|1.0| training tasks.
314.36|3.64| Starting with pre training task number one, the mass language
318.0|7.24| model. So how this works is that randomly 15% of the words in the
325.24|4.0| input are marked. So sometimes you also see that people say
329.24|4.76| they are masked, but I call them marked because not all of them
334.0|3.28| are actually masked. So imagine you have an input sentence like
337.28|5.0| this, let's say a quick brown fox jumps over the lazy dog. So
342.44|5.68| you would randomly select words like 15% probability. So 15% of
348.12|3.88| the words are selected. Let's say in this case, we select the
352.0|5.48| word Fox, then 80% of the time, the marked words are replaced
357.52|4.8| with a mask token, 10% of the time they are replaced with a
362.32|4.92| random word. And 10% of the time they are left as they are. So
367.24|5.8| sometimes this one will become mask. Sometimes this will become
374.8|5.28| coffee, or any other word, just a random word. And sometimes it
380.08|3.32| will just stay Fox. And the model the task of the model is
383.4|4.04| to predict the correct word. So which one goes in here, so it
387.44|3.96| has to predict if it's masked, it has to predict the right
391.4|2.56| word. But also if it's coffee, it has to predict the right
393.96|3.68| word, it just sees this. But it doesn't know whether it's correct
397.64|2.28| or not, because it could also be that it is already correct. So
399.92|3.64| it's still the model has to kind of think in that way, whether
403.56|4.28| it should be with which word should go in there. So this is
407.84|3.32| one pre training task. And this is what makes the model in a
411.16|3.6| sense also bidirectional, because there is no left to
414.76|4.0| right notion, it's essentially just picking random tokens here
418.76|4.2| or words that have to be predicted. And in this way, it's
422.96|3.36| also self supervised, right, because you don't really have a
426.36|3.2| have to have a human labeling this, I mean, you know the word
429.56|2.88| because you have the complete sentence. So you just remove the
432.44|7.12| word and let the model predicted back in a way. So here is another
439.56|5.84| example. So let's say we replace this word with a mask. So this
445.4|6.36| is 80% scenario of the 15% marked words. And then it goes
451.76|3.6| through the bird model, and then it has to predict the right
455.36|4.56| word. So there will be a softmax function, for example. And if
459.92|7.32| we have a vocabulary size of 30,000, there will be 30,000
467.24|3.88| probability values here, like summing up to one, and you will
471.12|5.04| then select the one with the highest predicted probability,
476.16|3.2| for instance, a fox, and this one would be then the one that
479.36|6.8| one that the model predicts. The second task is the next sentence
486.16|3.16| prediction. So this is a balanced binary classification
489.32|6.4| task. The labels are is next and is not next 50% of the time. So
495.72|4.2| it's balanced. So what they do is they take an input sentence.
501.24|4.92| So for instance, the man went to the store. So it's actually an
506.16|5.32| example they used in the paper. And then the second sentence is
511.52|5.08| he bought a gallon mask milk. So also notice that they combine
516.6|3.72| both pre training tasks. So the next sentence prediction also
520.68|8.92| includes the masking. And then this is a case where these are a
529.6|4.0| and B actual sentences that follow each other in the
533.6|6.88| original documents. So here, the true label is next. And at the
540.48|5.2| bottom is a case an example, where the label is not next. So
545.72|5.32| they have again, the same man walks into the store, went to
551.04|4.24| the store, it's masked here. And then the second sentence is
555.32|7.02| penguin flightless birds. So, um, yeah, here, this would be an
562.34|8.54| example where a to a and B are sentences that follow each other
570.88|6.76| in the original document. And here, that's not true. And the
577.64|4.2| model has to has to recognize whether these sentences follow
581.84|2.6| each other or not. And it's another way that the model can
584.44|6.64| learn how to understand text. So here's an illustration of the
591.08|4.08| pre training procedure and the fine tuning to the downstream
595.16|3.52| tasks from the original bird paper. So on the left hand side,
598.84|3.92| they illustrate the pre training process, where we have now the
602.8|4.84| these masked sentences sentence a and sentence B. And the task
607.64|4.56| is, are there two tasks, one is the next sentence prediction. So
613.36|3.28| we have this classification token, right, and then it has
616.64|3.48| to break whether it's the next sentence or not. And then we
620.12|4.48| also predict these masked words. So if we had a masked, let's say
624.62|4.18| a masked token here, let's call it M. It's also predicting which
628.8|5.84| word goes in there, these marked or masked tokens. So that's the
634.64|3.32| pre training. And then after pre training, we can fine tune our
637.96|3.48| models for other tasks. For instance, here, they have a
641.44|4.04| question answer task as an example, where they provide the
645.48|3.44| test, the question here on the left hand side, and then a
648.92|2.76| paragraph to the right hand side. So the question is
651.68|3.44| referring or asking something about that paragraph. And then
655.12|4.16| the model here generates an answer. But you can also find
659.28|4.8| unit for classification. For example, you could concatenate,
664.08|2.6| let's say two sentences here. And then you have a
666.68|9.88| classification and say the movie review classification. So this
676.56|5.16| is just the illustration. And remember, when we talked about
681.72|4.8| the GPT, I mentioned that there are two different ways for
686.6|4.48| working with downstream tasks. So here's, again, the general
691.28|2.88| training procedure for transformers. There's first is
695.72|3.16| unsupervised or self supervised pre training, the pre training
698.88|3.36| on large unlabeled data sets. So like here on the left hand side,
702.24|4.68| this is done on unlabeled data, whereas this fine tuning here on
706.92|5.28| downstream tasks is done on smaller labeled data sets. And
712.32|2.32| for these downstream tasks, there are really two different
714.64|3.44| approaches, though. So fine tuning is what they mainly talk
718.08|3.4| about in this bird paper. This is the approach where they
721.6|3.94| update the whole model, so all the parameters. But there's also
725.54|2.66| this feature based approach that I mentioned earlier, and they
728.2|3.12| also do some experience experiments with that in the
731.32|3.98| bird paper. So let's just go over these two also as an
735.3|4.84| example. So the fine tuning is essentially by adding a
740.14|5.5| classification layer. So you have, for example, a
745.64|4.56| classification layer, which could be on, if you have, let's
750.2|3.24| say different words or different classes, you add that to to the
753.44|4.8| model at the end. So if for instance, your model is trained
758.24|2.24| to do the next sentence prediction, the output layer
760.48|5.0| would be just one, one value, or it could be also two, it
765.48|3.04| depends on how you implement binary classification. But let's
768.52|2.76| say you want to train that for different tasks where you have,
771.28|3.44| let's say, on 10 different classes, or 100 different
774.72|3.4| classes, so you can add a fully connected layer to the end, and
778.12|6.0| then have softmax probabilities and using a cross entropy loss
784.16|5.28| to train that model. And when you do that, you would
789.44|3.36| essentially update the whole model. So here, this is just a
792.88|3.0| screenshot of the original transformer encoder, just for
795.88|4.68| illustration, but this would be essentially the bird encoder,
800.56|4.28| which would look similar, where you have this by direction
804.84|5.68| training with a 15% marking, whether an 80% are masked, 10%
810.52|4.12| are replaced by random words, and 10% are left as they are of
814.64|3.96| these tokens. And yeah, so the fine tuning really is updating
818.6|3.8| the whole model. After pre training, and you find unit for
822.4|2.2| classification, you update all the model parameters here.
825.68|5.56| Second, training end to end. The other approach, let me first
831.24|3.56| illustrate. So regarding this fine tuning approach, here are
834.8|3.76| the results from the paper. So they compared their paper, for
838.56|2.9| example, to other methods like Elmo, we haven't talked about
841.46|4.26| Elmo yet. But yeah, there are too many things already to talk
845.72|3.6| about in this lecture. So I didn't exhaustively cover all
849.32|4.12| the models. But we talked about the open AI GPT model here. And
853.44|3.08| you can see that both on the small and the large bird
856.52|3.68| version, so they have a base and a large version performing
860.24|4.32| better than bird on several tasks, actually on all tasks
864.56|3.84| here, if you consider the larger one, I think also, also the
868.4|4.04| smaller one. So they outperform, for instance, the uni
872.44|3.96| directional GPT model here by their bidirectional training
876.44|4.92| with these masked language models and the next sentence
881.36|2.8| prediction. And this is for the fine tuning then to these
884.16|3.96| different tasks. So each of them is a different label data set,
888.12|3.88| you can see here the sizes of these data sets. So this is all
892.0|3.04| done by fine tuning, for instance, like adding fully
895.04|4.16| connected layers, and then fine tuning the whole model. Now the
899.2|4.48| other approach is the feature based training. And nowadays, I
903.68|2.6| think this is the way more popular approach. So when I look
906.28|4.96| at different people using bird, this is by far more popular.
911.24|2.6| There's also, for example, something called a prot bird
913.84|4.4| where people Yeah, did something similar with proteins, where
918.24|3.64| they trained a bird model on amino acid sequences, like
921.92|3.4| sequences of proteins. And then after training, they only looked
925.32|2.52| at the embeddings. And then they looked at how the embeddings
927.84|3.0| cluster, and they train classifiers on these embeddings.
930.84|3.44| And they found that these embeddings are very information
934.28|3.76| rich, they contain a lot of information about proteins. So
938.04|3.6| the idea behind this feature based training is after the
941.64|3.04| pre training, you keep the bird metal model frozen, so you don't
944.68|5.12| update anything. And you if you have a new data set, let's say
949.8|3.38| your movie review data set, you just use that bird model to
953.18|3.5| create the embeddings. So you would, for instance, download a
956.68|3.68| pre trained bird model that has been trained on a large corpus
960.36|3.8| in this pre training fashion, like using self supervised
964.16|3.88| learning. And then you create all these embeddings for all
968.04|3.76| your examples in your data set, in your smaller training set.
972.28|4.36| And then you train a new model just on these embeddings. So you
976.64|3.8| treat these embeddings as the input features to your model.
980.8|4.12| This model could be an RNN, it could be logistic regression,
984.92|2.52| it could be a multi layer perceptron, could be a one
987.44|2.32| dimensional convolutional network, it can be anything you
989.76|4.28| like. But most often these days, I see people just training a
994.04|4.84| simple multi layer perceptron or logistic regression. So it's
998.92|2.8| essentially supervised learning, just like the supervised
1001.72|4.4| learning you learned about in this class, using now these
1006.32|4.32| embeddings as input, similar to how an RNN can use word
1010.64|3.52| embeddings, you can now use these embeddings from the bird
1014.16|4.96| model as input to any other model. And also, they looked at
1019.12|3.6| that in the paper, and they actually found that this can
1022.76|3.96| perform quite well too. So without any fine tuning, not
1026.72|3.04| quite as good as the fine tuning. So the fine tuning
1029.76|6.84| approach, again, is here. But quite good. So here, these are
1036.6|4.32| these feature based approaches. And you can see that when they
1040.92|4.28| concatenated the last four hidden layers, the outputs from
1045.2|3.72| the last four hidden layers of the bird model, and then they
1048.92|5.16| trained a bi directional LSTM model on that. They found that
1054.44|3.16| this performance is actually almost the same as the fine
1057.6|3.16| tuned bird model. So fine tuning, I would say is more
1060.76|3.76| work because you have to load the whole model into memory, and
1064.52|3.76| then update the whole model. And nowadays, many language models
1068.28|4.28| can be quite large. I think bird is like somewhat around 100. I
1072.56|2.84| mean, the small one is 100 million parameters already, the
1075.4|3.64| larger one, I think might be around 300 or something. So in
1079.04|3.32| that way, it's kind of expensive to train the model, especially if
1082.36|3.72| you only have access, let's say to a CPU or only one GPU. So in
1086.08|2.48| this way, this feature based approach is way more attractive
1088.56|3.72| because you can just generate these embeddings running the
1092.28|3.2| model one time. And you don't have to worry about training the
1095.48|3.84| work model just working with the embeddings. All right, so this
1099.32|3.32| was the bird model in a nutshell. And in the next video,
1102.64|3.6| we will come back to the GPT model because there was in 2019
1106.24|19.68| one year after bird an update to the GPT model.