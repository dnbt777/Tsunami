start_time|end_time|text
1.12|4.2| Alright, so in this video, let me illustrate the main big
5.32|4.96| picture concepts behind using RNNs for sequence generation. In
10.28|4.16| particular, we will be briefly talking about many to many RNNs
14.44|5.52| for generating texts. So recall this figure here that I showed
19.96|4.12| you a couple of weeks ago when we talked about recurrent neural
24.08|2.92| networks for text classification. So we had this
27.0|4.34| slide on the different types of sequence modeling tasks. And
31.34|7.56| previously, we used this many to one approach where we had a text
38.9|5.36| input, so many inputs, and had one output sentiment label,
44.26|3.44| whether the movie review was positive or negative. So it was
47.7|5.48| essentially a classifier. And the classifier worked on a word
53.18|4.68| level. So we had an embedding vector that took each word as an
57.86|5.96| input and was converting it into a continuous vector. Today, we
63.82|6.12| are going to focus on the many to many architecture for
70.18|4.72| generating texts. So there's also a related many to many
74.9|4.08| architecture here. This could be for instance, used for language
79.02|3.36| translation. And we will talk a little bit more about language
82.38|3.84| translation when we talk about RNNs with attention. But in
86.22|2.84| this video, we are going to focus on the many to many
89.54|3.2| approach first, that is really like taking one input and
92.9|5.16| producing one output at each time step. So and when we talk
98.06|4.8| about generating texts with recurrent neural networks, there
102.86|5.56| are two main approaches. One is the so called character level
108.42|6.8| RNN, also just known as character RNN, and the word
115.26|6.44| level RNN, which we also just call word RNN. And the
121.7|5.84| difference is really what we provide as token as one input
127.54|5.92| token. So focusing on the left sub figure here. So for let's
133.46|4.2| say a word RNN, we could have one word would be the input. So
137.66|4.0| for each time step here, the input would be a single word,
141.82|9.56| for instance, let's say I like hiking. And when we train this
151.42|3.2| word RNN, what we want to do is we want to predict during
154.62|5.16| training the next word. So let's say I like hiking a lot or
159.78|4.4| something with a sentence that would continue like this. Hiking
164.18|4.16| a lot. So what we would do is the first time step we have
168.34|6.08| this is input and it should predict like, and then second
174.42|5.64| input is like it should predict output hiking, and then input is
180.1|6.24| like hiking and then it should provide an A and then so forth.
186.46|3.84| So we would continue like that. So we provide one word as input
190.3|2.88| and then it should learn how to predict the next word. This is
193.18|4.44| usually how a word level RNN is trained for the character level
197.66|5.24| RNN. It's untrained slightly differently, but following the
202.9|4.36| same concept, let me erase that. So instead of giving one word as
207.26|3.48| an input at each position, we would just use one character. So
210.74|9.12| for example, I then space like an L and so forth. So in that
219.86|3.76| way, it predicts one character at a time. So we would predict
223.62|7.0| the next character. So I, if I like hiking, so I would be the
230.62|4.84| first word and it predicts the white space here. And then the
235.46|6.0| next one would be the white space and then the L and then the
241.46|4.36| L and the next letter would be the I and so forth. So
246.58|2.64| fundamentally, yeah, the differences between using a word
249.22|3.6| and or a character level RNN. At the end of this video, I have
252.82|4.04| just a small comparison slide like listing the advantages and
256.86|4.52| disadvantages of using each of those two approaches. So let's
261.94|3.84| focus for now maybe on the character RNN and I will tell
265.78|4.08| you at the end of this video, what the advantages are of using
269.86|3.04| a character RNN and what the advantages are of using a word
272.9|5.2| RNN. So, but for simplicity, we are focusing now on the
278.1|5.04| character RNN not on the word RNN. So now assume we have this
283.18|3.48| character RNN. This is for training, we predict the next
286.66|3.52| word. And if we have a sentence like that, we know the next
290.18|5.4| label, right? Because we have this letter, and then we know all
295.58|3.72| the following letters. And that way it is, it is a flavor of
299.34|3.76| self supervised learning, where we generate our labels. So we
303.1|4.28| don't have to have labels for this training task, because the
307.38|3.72| labels are essentially the structure of the sentence,
311.1|4.8| right? Because we, we know the next word. And here, the
315.9|4.52| prediction is essentially the next word. I will have another
320.42|3.32| slide that maybe makes this a bit more clear. So for now, stay
323.74|2.76| with me. So what we're doing here is we're always providing
326.5|2.72| the next word as input during training or sorry, the next
329.22|5.12| character. But for testing, so how do we then generate new
334.34|3.36| text with that, right? So we want to generate a new text and
337.7|4.56| not just regenerate an existing text. So how we do that is we
342.3|5.32| provide a random letter as input, then it predicts the next
347.62|3.52| letter. Usually, there's also some sampling involved, we are
351.14|3.88| sampling with a certain probability. So we would
355.02|4.84| consider all the top predicted letters, let's say the with a
359.86|4.16| certain probability, and then we would randomly sample the weighted
364.02|3.6| sampling of these predicted letters, and then use that
367.62|7.12| letter as the input for the next one. And then again, we predict
375.06|5.84| characters and we take one of them and provide them as input
380.9|5.4| to the next position, and so forth. And with that, we can
387.06|3.36| predict different or generate different characters and
390.42|3.64| sequences. And I think this will also become more clear when we
394.1|3.12| take a look at the code example. So essentially, the network
397.3|4.8| learns the probability that certain letters occur after each
402.1|3.72| other. And if we train it like that, it will at some point be
405.82|6.0| able to, yeah, to generate realistic text with a certain
412.34|3.88| amount of spelling errors. But yeah, we will see about that in
416.22|3.52| the code example. To make this concept a bit more clear, I have
419.74|2.92| a slightly different slide here that is maybe a little bit more,
423.02|6.16| I would say concrete. So this is a character RNN here again, and
429.5|8.04| just assume it's processing the text test. So it's trained to
437.54|5.44| predict the next character. So here I have the inputs. First
442.98|5.6| one is T, an E, and then S. And these letters are represented as
448.58|4.96| a one hot encoding. So for the letter T, the last position is a
453.54|4.44| one for the letter E, the first and for the letter S, it's the
458.0|4.5| central position. Here, we have only a one hot encoding vector
462.5|3.52| of three elements. But the number of elements here, the
466.02|3.0| size of this would be equal to the number of possible
469.02|3.0| characters. So for instance, if we only would consider all
472.02|3.84| lowercase English alphabet letters, it would be, let's say
475.86|5.32| 24. If we consider lower and uppercase, it would be 48. And
481.18|3.6| then if we have punctuation, like period, comma, colon,
484.78|6.2| semicolon, it would be 52, and so forth. So the size of the one
490.98|3.0| hot encoding vector here really depends on how many characters we
493.98|6.52| consider. And this size here of this one encoding vector is equal
500.5|5.12| to the size of the output here. So the output layer, this what's
505.62|6.96| shown here is a vector of the predicted softmax probabilities.
513.42|3.76| So these are the probabilities, the predicted probabilities for
517.18|5.96| each letter. So in this case, position one was the letter E,
523.18|5.72| right? So it has 70% probability that this is an E 20% that this
528.9|4.96| is an S and 10% that this is a T, correct that is an E. So in
533.86|4.08| this case, the network is making good prediction. So because the
537.94|3.44| highest probability is the correct letter for the second
541.38|3.72| one. So it receives an E, it should predict an S. So the
545.1|3.64| probability that this is an E is 20%. The probability that this
548.74|4.84| is a, this is an S is 60%. And the probability that this is an
553.62|6.32| T is 20%. So also in this case, the highest probability is for
559.94|3.2| the is corresponding to the correct letter. So that's also
563.14|4.36| good. And for the last one, yeah, this is also good. So this
567.5|2.64| is, of course, just a toy example. But here, essentially,
570.14|3.52| the network is trained to output a high probability for the
573.66|6.28| correct word. And then we can use the arc max to convert this
579.94|5.68| back into a letter from going from this probability here to to
585.62|4.6| the actual letter, we could, for example, use an arc max. So it
590.22|3.96| would give us the index index corresponding to to the letter
594.18|5.08| in, let's say, a vector or dictionary. A few more things.
599.3|4.68| So usually, we use an embedding layer, we have talked about this
603.98|2.48| in the RNN classification lecture, we use usually an
606.5|4.6| embedding layer to embed the inputs. So there's usually a
611.14|3.28| certain dimensionality of that embedding that comes out of it.
614.86|3.64| And then we also usually choose the size of the hidden layer.
618.5|3.18| And here, it just happens that the hidden layer has three
621.68|3.0| values, whether it's just a coincidence, because it fit
624.96|3.0| nicely here into this box. But of course, this hidden
627.96|2.48| dimension is arbitrary, it's good, it could be, for example,
630.44|7.0| 64128 or 200 to 111, whatever you like, it's this is similar
637.44|4.32| to the RNN for classification. So, so these parts are really
641.76|3.48| the same that we have seen before, when we talked about RNN
645.24|6.16| classifiers. The new part is really that the output here is
653.72|2.96| softmax probability vector corresponding to the one hot
656.68|3.56| encoding of the input. So essentially, we're trying to
660.24|4.44| predict letters now, rather than class labels. So the letters
664.68|3.48| here are essentially our class labels. And in that sense, since
668.16|3.96| we are predicting something that is in in the data, it's kind of
672.12|3.4| like, yeah, kind of like self supervised learning, because we
675.52|4.76| are generating our labels here ourselves by just using the
680.28|5.08| inputs, the text. Yeah, and this is the other the broader concept.
685.54|5.5| And like I mentioned before, during the generation, so once
691.04|2.26| we train the network, and when we use it for inference for
693.3|6.7| generating new text, we sample, we sample from from this output
700.0|3.36| vector here. So it's not guaranteed that we pick the
703.36|7.6| letter E as input for the next token that is after training
710.96|2.72| during testing, because if we would guarantee that, then of
713.68|2.64| course, it would just memorize text, but we want to usually
716.32|2.8| have some variety in our text. So there's a certain
719.12|3.68| probability. So the probability is 70% to sample that E, for
722.8|3.36| example, versus a smaller probability, let's say 20% to
726.16|3.4| also choose a different letter. So we can also in practice, I
729.56|2.28| mean, there are different ways you can also say, only
731.84|3.68| consider the top five letters or top three letters and sample
735.52|2.6| them with a given probability and so forth. So there are
738.12|4.92| different ways for doing that. But during the generation of
743.04|3.32| new text, we usually don't just pick the one with the highest
746.36|2.24| probability, we usually pick the one with the highest
748.6|3.24| probability most often, but we also occasionally pick another
751.84|3.04| letter and this will become hopefully more clear in the code
754.88|5.4| example where we implement something like that. Yeah, so
760.28|6.0| here are just um, yeah, for reference, what I talked about
766.28|6.48| how, how we work with this character RNN. So during
772.76|3.8| training, what we do is usually we ignore the prediction. I
776.56|2.88| mean, the prediction is only used for computing the loss, but
779.44|2.8| we don't we don't during training feed it into here.
782.24|5.4| Here, during prediction, we take this from the original input
787.64|8.08| text. And during the inference stage, we usually then use the
795.72|3.92| prediction as the next input. This allows us then to create
799.64|4.96| text with a variety that it's not always the same text. Yeah,
804.6|2.68| and I wanted to highlight, of course, this works with both
807.76|4.2| word and character level RNNs. We talked about character level
811.96|5.44| RNNs when I showed you this. But of course, this would also work
817.4|4.2| with word level RNNs. The difference though would be that
821.6|4.58| the size here of this model encoding would be the same size
826.18|3.62| as the number of words that can occur. If you consider the
829.8|2.96| English vocabulary, there are millions of words usually, so
832.76|2.64| you restrict that so that doesn't become too large. But
835.4|3.64| even if you have a vocabulary, let's say of 20,000 words, it
839.04|3.4| would be way larger than the number of characters, which is
842.44|4.16| one of the challenges of working with word RNNs. So this wasn't a
846.6|3.28| problem that much when we talked about the classifier when we
849.88|4.16| implemented the RNN classifier. Because I mean, for the
854.04|6.08| embedding still works fine if we have a 20,000 vocabulary size.
860.48|2.86| But the problem is really when we have these outputs here,
863.34|5.54| like we compute the label over these 20,000 possible words and
868.88|3.4| compute the cross entropy between the two, right, that
872.28|4.32| would be a little bit more challenging, because these could
876.6|3.4| be all very small values, and there might be no large value
880.0|4.16| among them, and so forth. So there's, there's a field of
884.16|3.44| machine learning called energy based models, which kind of
888.08|4.44| borrows ideas from physics, like how to make two vectors or how
892.52|3.6| to assess whether or how similar to vectors are. But yeah, this
896.12|6.36| is a different topic for maybe a separate lecture. But the fact
902.52|4.28| that in work level RNNs, these vectors are very large, it's
906.8|2.72| usually easier to train a character level RNN for
909.52|6.14| generating new texts. So let me summarize things here. So for
915.66|3.58| character embeddings, we usually only have the 24 letters if we
919.64|3.28| consider lowercase only if we have upper and lowercase as
922.92|5.6| different letters, we would of course have 48. And in general,
928.52|5.6| it requires less memory compared to word embeddings. And the
934.12|5.06| losses also have smaller output layers. The disadvantage of
939.18|4.78| using character RNNs overword RNNs is that it can more easily
944.16|5.88| create weird nonsense words because each character is input
950.04|4.12| so it can put together weird character combinations that
954.16|4.92| don't correspond to real words. Whereas if you were using word
959.08|4.04| level RNN, I mean, you can still have a weird word order, but
963.48|2.88| each word is kind of fixed. So in that way, you don't at least
966.36|4.48| have spelling errors in the words. And one other
970.84|4.0| disadvantage of character level RNNs is that they're worse at
975.0|4.24| capturing long distance dependencies. That's simply
979.24|4.08| because you have what we have more tokens, right. So if each
983.32|5.48| character is a token, so if we have the sentence, I like
991.0|3.96| hiking or something like that. So if I look at this, these are
994.96|3.08| only two tokens apart if I consider them as words. But if
998.04|7.68| I consider each character, I have 123456788 sequence
1005.72|4.8| positions are between these two. So in that way, it becomes more
1010.52|2.44| challenging to capture the relationship because this might
1012.96|4.04| get lost when we even if we have an LSTM, these types of long
1017.0|5.36| sequence relationships might get lost. We will talk about the
1022.36|3.2| tension mechanism, which can help with longer sequences. But
1025.56|3.88| we will take a look at that in a word RNN context. For now,
1029.44|3.32| since it's the simple case in the next video, I want to
1032.76|4.56| implement a character RNN in pytorch, because that's also
1037.32|5.64| easier to train than a word RNN. And I will first show you maybe
1042.96|3.36| the concepts in the next video, because there are also some, I
1046.32|6.0| would say, on technical details that are worth noting. So we'll
1052.32|3.84| first show you the big picture concepts, how to implement this
1056.16|4.52| using LSTM and LSTM cells. And then I will show you in another
1060.68|2.24| video the actual code implementation.