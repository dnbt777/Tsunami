start_time|end_time|text
0.36|4.56| Alright, so the last topic in this already very long GAN
5.04|4.24| lecture is on implementing a DC GAN for generating face images
9.28|4.28| and pytorch. And just when I looked at the paper again,
13.56|2.84| actually, I just noticed it's also so much into right here,
16.4|3.56| the author of the GAN tips and tricks that we discussed in the
19.96|5.12| previous video. So essentially, the only thing that is different
25.08|4.9| compared to our previous MNIST GAN is that the data set is of
29.98|4.34| course different, and that we are now using convolutional GAN
34.32|5.14| instead of fully connected layers. So let's go through this
39.48|3.4| step by step. Again, our boilerplate here, you can notice
42.88|6.24| we have two learning rates like before. Now we have a data set
50.64|5.56| instead of MNIST. And here's an example of some of the images
56.2|5.44| how they look like. So it's an image data set consisting of
61.66|3.06| celebrities collected from Google, I think from the Google
64.72|4.72| image search. Yeah, so and this is our deep convolutional GAN
69.44|5.24| here. Slots of layers for the generator, the conf transpose
74.68|4.8| layers, because we go from length dimension, by default,
79.48|7.44| 100. So 100 dimensional noise vector, we go up, sampling up,
87.24|6.9| so that it has 64 times 64 dimensional. So I should mention
94.14|4.34| I resized, if I go back up again, I resize the images here.
98.56|6.98| So I first crop them. And then I resize them to 64 times 64. It's
105.54|4.1| easier to train again with smaller images. Of course, there
109.64|4.24| are GANs with bigger images. And if you look, there are multiple
113.88|3.04| approaches to that some people train the GAN, still on lower
116.92|3.12| images, and then use super resolution methods. Some others
120.04|3.12| do that directly. But yes, you can see these have much higher
123.16|4.52| quality. It's just hard to do that. And especially with regular
127.68|3.26| GAN. So there are many advanced GANs, which we can't all cover
130.94|3.22| in this class. But for regular convolution, again, like this
134.16|3.48| one, it's easier to work with smaller image sizes. It also
137.64|3.2| depends really on how large your data set is how many images you
140.84|5.72| have, how diverse the images are in terms of colors and view
146.56|3.72| angles and things like that. Many, many factors to consider.
151.44|4.2| So here, I found 64 times 64 worked much better than 128
155.64|5.4| times 128, for example. Okay, so it's just a snapshot of some
161.04|7.58| randomly sample people. And then here are generator again. So
168.62|4.36| here, I'm alternating between transpose convolution, or just
172.98|2.46| transpose convolution, I don't use any pooling or something
175.44|4.1| like that. It's just or no up sampling is just transpose
179.58|5.6| convolution for making it larger. Then batch norm, leaky relu,
185.18|5.52| to try and transpose batch norm, leaky relu, same thing, same
190.7|5.88| thing. And then the last one with a 10 h function here, so
196.58|4.16| that we get minus one and one pixel ranges. And the
200.74|2.84| discriminator is a little bit not that much simpler, but maybe
203.58|2.12| it's a little bit too big. It's also one aspect of the
205.7|3.08| discriminator is too good. And it's also then challenging for
208.78|4.72| the generator. So they could have been a bit too big, but it
213.5|3.36| happened to work. So here, the discriminator has convolutional
216.86|3.8| layer, leaky relu convolution layer, batch norm, leaky relu,
221.1|2.8| and so forth. So I'm done sampling with the convolution
223.9|9.64| here instead of using max pool. Yeah. And there's a flatten to
233.54|4.56| get so we don't use any fully connected layer. So here, this
238.1|3.72| is similar to what we discussed in a convolutional lecture, when
241.82|5.6| we said we can actually get rid of the last fully connected
247.42|5.68| layer if we make the dimensions. So such here, if I have 64 times
253.1|4.48| 64 inputs, at this point, when you do the math, you will have
257.58|2.6| four times four feature maps, and then I'm applying a
260.18|3.84| convolutional layer with kernel size four. So from four to four,
264.02|6.04| it will go to one to one. And then I go from eight channels to
270.06|4.08| one channel. So the output will be a one by one by one tensor.
274.34|3.12| And then I'm flattening it into a single value, which is my
278.3|4.18| probability that this is a real image. Because we're using
282.48|4.42| binary cross entropy. And this looks like before, a little bit
286.9|5.28| simpler now compared to our MNIST scan, because I wrote all
292.18|3.24| the training function, such that it works with images. And then
295.66|3.36| when I had my MNIST scan, I had to adjust a little bit to do the
299.02|4.24| reshaping, because fully connected layer works with
303.38|4.24| vectors, not with images, right. So I had to just do this back
307.62|2.96| and forth here to make it work with my training code. But you
310.58|3.48| could also always write more elegant training code to have an
314.06|3.28| if else statement, whether it's a convolution layer or fully
317.34|5.76| connected layer. But I yet I didn't do that much work because
323.1|3.68| I felt like the code is already complicated enough, hard to
326.78|5.08| read already. Okay, so I'm using Adam again, for both I tried
331.86|4.2| using SGD for the discriminator, but it didn't work so well.
336.98|2.84| Requires also more learning rate tuning and already took me a
339.82|4.92| long time to get this running well. So here's my training
344.74|2.5| function, the same as before, and we can take a look at this
347.24|3.14| again, if you like, I mean, there's nothing new. So nothing
350.38|4.8| has changed. But there was one thing I wanted to discuss
355.18|3.44| briefly. So one thing I was wondering when I was going over
358.62|2.8| the tips in the previous video that I was thinking of one
361.42|6.68| additional tip, that is whether we should sample the noise
368.14|5.16| separately for the discriminator and the generator. So here, I'm
374.34|3.88| getting the generated fake images, I was wondering, so yeah,
378.22|3.48| I'm using them again. So sorry, here, I'm using the discriminator
381.7|3.4| and here, for the generator, I'm using them again. So I was
385.1|5.48| wondering, instead of having the noise here, like for the
390.58|4.2| discriminator and the generator, we could maybe have, so it's
394.9|5.64| pretty clear, if I put it here, we could have it here, fake
400.54|5.84| images for the discriminator, but then use different ones for
406.38|4.16| fooling the discriminator, I would find this is maybe also an
410.54|3.04| interesting thing to try out. Actually, I haven't tried this,
413.58|4.2| I could run this and see if it performs better. Because the
417.78|4.6| rationale could be here, we are training the discriminator to
422.38|4.6| recognize these images as fake here. And then we are training
426.98|7.48| the generator to basically fool the discriminator with these
434.94|3.92| images. But I'm wondering if it's just back and forth,
438.86|3.08| because we use the same batch, whether it might be better to
441.94|4.56| use a fresh batch. So instead of using the same one for both
446.78|3.64| having these two different ones might be another trick to try.
450.42|2.32| I haven't tried this might be something else to consider.
452.9|2.2| Maybe it doesn't make a difference. I don't know. Okay.
455.78|3.24| So but except that the whole training function is still the
459.02|8.8| same. Going back to my coach, training it, see, kind of stays
467.86|2.8| okay, so nothing so there's great, it doesn't go to zero,
470.66|4.08| which is bad. Or, yeah, zero loss for the discriminator means
474.74|6.36| it's way too good. And nothing unusual. So it's training for
481.1|4.6| a long time, 20 epochs. Sorry, one hour almost. I mean, for the
485.7|1.96| grand scheme of things for deep learning, it's actually pretty
487.66|5.36| fast. But if you try to code the lecture, so that I can talk
493.02|4.4| about it, I was like, a little bit on a time constraints, I was
497.42|2.36| happy that it finished so fast, because I also had to try
499.78|2.76| different hyper parameters. Yes. So it's a lot of work actually
502.54|5.52| to do these codes. So I talked to some people during office
508.06|3.88| hours, and some students said, it's kind of takes a long time
511.94|2.72| to work on the project. But yeah, I can totally understand
514.66|3.56| you because also for research, or these even the simple class
518.22|2.64| examples, it takes a long time. It's just the nature of deep
520.86|4.36| learning. So plotting things, I can see that's interesting, the
525.22|3.48| generator goes up, that is greatest, kind of low here,
528.7|2.92| actually, to be honest, approaching zero. But when I
531.62|3.36| look at the results, they looked actually quite reasonable. So
535.02|3.24| first epoch, you can see these don't really look like face
538.26|6.68| images. But as we go further, epoch five, epoch 10. So not
544.94|5.96| all of them look realistic, but this person, maybe this person
550.9|3.64| now, to some extent, start looking more realistic. I mean,
554.54|2.64| of course, you can see they are generated, they're not that
557.18|5.76| great. But they also not terrible, right? Yeah, could be
562.94|3.0| better, the results could be better. This person looks kind
565.94|4.32| of realistic. But yeah, given that this is very simple code, I
570.26|3.04| only trained 20 epochs, it doesn't look too terrible, in my
573.3|3.16| opinion, actually, just wanted to show you one that actually
576.46|3.6| failed. So the difference between the one I just showed
580.06|3.64| you, and this one is only that here, I initially had a regular
583.7|7.96| relu. And when I train it with a regular relu, it was first
592.18|4.0| going fine. And then we had this huge spike here. And then
596.18|5.88| suddenly, things looked very different. And now looking at
602.1|4.32| the results, first, it looks the same as before, right? Looks
606.58|3.56| okay ish. Then suddenly, there's some mode collapse or something
610.14|2.96| like that, you can see, they all look the same. So it looks like
613.1|5.96| mode collapse, where the screen can be easily probably fooled by
619.06|3.28| the generator or something like that. Generators also very
622.34|4.88| noisy generates the same type of image, kind of. So yeah, that
627.22|3.76| was also interesting. Okay, so that is a deep convolution.
630.98|3.16| Again, it's overall, if you look at the code, it's a pretty
634.14|4.72| complicated topic, right? We have a lot of training code.
638.86|4.32| But that's just the nature of deep learning. To be honest, it
643.18|4.32| also takes me time to write this. But I remember when I was a
647.5|3.16| student, when this was all kind of new, back then, I didn't
650.66|3.4| learn this actually in class, because I was finished with
654.06|3.64| classes when GANs came out. But I was reading the paper,
657.7|2.48| looking at some early code examples, I think it was the
660.18|3.88| Arnold. Yeah, back in the day, code code was much harder to
664.06|3.24| read, compared to pytorch. And it also took me a long time to
667.3|4.76| kind of figure out how the code works. Now, it's for me easier,
672.06|5.12| I can write these things myself. But I would say it's still one
677.18|4.52| of the more complicated models compared to let's say,
681.74|3.24| classified. So if this looks all complicated to you, you just
684.98|2.88| need to give it some time, you have to maybe implement it
687.86|2.76| yourself or take some code modified a little bit, maybe
690.62|3.4| apply some of the tricks. So you could, for instance, apply the
694.02|4.24| trick where you flip the labels for the discriminator, or
698.58|3.28| occasionally, and just get a better feeling for the code and
701.86|3.88| where things are. And yeah, then with some time, you will also
705.74|3.28| become pretty confident reading code. But yeah, it really takes
709.02|3.84| time. So I can imagine just taking one class is not enough
712.86|4.68| to really get confident doing this, it takes probably years.
717.66|2.92| And what's very important is really working on the projects
720.58|4.0| where you, you know, where you just work by yourself. I mean,
724.62|2.68| not totally by yourself, you have your team, you can ask me
727.3|3.04| for feedback, the many students or several students by an office
730.34|2.84| hours, where I usually help with the coding parts of their
733.18|3.2| arrows. But ultimately, you need to spend time with the code,
736.38|4.28| there's no kind of textbook or anything like that, that helps
740.66|3.16| you really understanding everything, it is really through
743.82|4.16| interaction, most of it, and also doing some search on the
747.98|2.84| internet. And this is how everyone was doing coding
750.82|5.44| learns, it's, it's a process, it takes practice. Alright, so
756.26|3.84| with that, let me then end this already long lecture on
760.1|19.0| generative adversarial networks.