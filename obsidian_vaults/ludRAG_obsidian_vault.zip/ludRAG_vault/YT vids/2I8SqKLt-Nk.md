start_time|end_time|text
0.6|3.32| Yeah, hi, everyone. So all good things come in threes. And I'm
3.92|3.16| back with stuff in the news. Number three. Last week, I
7.08|2.92| talked a lot about language models for deep learning. And
10.0|2.8| this week, my new section will be more focused on computer
12.8|2.92| vision models, which is also a little bit closer to my research
15.72|3.0| area. Because there happened a lot of interesting stuff around
18.72|2.84| computer vision this week. There are lots of things to talk
21.56|2.56| about. So let me get started and dive in.
25.28|2.92| Yeah, let's start with a good old fashioned computer vision
28.2|3.28| application image recognition. So here, the title of the paper
31.48|4.44| is high performance, large scale image recognition without
35.96|3.68| normalization. So here, the researchers developed a deep
39.64|4.84| neural network that can achieve new image classification, state
44.48|4.24| of the art results without batch norm. So if you encounter this
48.72|6.76| work here, SOTA, this usually stands for state of the art and
55.48|3.84| means that you achieve a state of the art performance in terms
59.32|4.48| of the best possible performance or among the best possible
63.8|3.72| performances compared to other cutting edge state of the art
67.52|3.72| models. So here, what was the novelty? So here, the novelty is
71.24|2.96| that they achieve this state of the art performance without
74.24|2.96| batch normalization. So batch normalization is something we
77.2|3.08| will be covering later in the semester. And it's a technique
80.28|3.72| that has been used in the last I would say, four or five years to
84.0|4.58| get your stable and good performing models. It's like a
88.58|2.36| type of data normalization technique. And we will cover
90.94|3.6| this in more detail later in class. So here on what's new is
94.62|3.2| basically that they achieve the good performance now without
97.82|4.56| batch normalization, basically making models simpler again. So
102.58|2.84| what did they use here? So here, they developed an adaptive
105.42|3.44| gradient clipping technique to overcome the instabilities that
108.86|2.96| arise from not using batch norm. So there have been also some
111.82|3.28| other models recently in the last couple of months or years
115.42|3.82| that achieved state of the art performance without batch norm,
119.24|3.4| but they were usually more unstable, so more unstable
122.64|3.42| towards little fluctuations in the data set, and so forth. So
126.06|3.08| here, they achieved really good performance without this
129.14|3.88| normalization technique. So they developed so called normalizer
133.02|3.4| free residual networks. So resonance or residual networks
136.42|3.36| are also something we will be covering in the semester in the
139.78|2.88| convolutional network lecture. So we will likely also
142.9|4.92| revisiting this paper then. What is also interesting is how they
147.82|3.76| evaluated the performance. So here, I have a screenshot from
151.58|4.72| the paper on the y axis, you see the image net top one accuracy.
157.06|4.12| So recall from the introductory lectures, I mentioned the
161.18|3.92| challenges with image net, where you can have multiple possible
165.1|4.04| labels. So in this way, usually people also call or compute the
169.14|4.52| so called top 5% accuracy. Because, yeah, if there's
173.66|4.72| something, let's say you have a bus, or a car in an image, there
178.38|2.16| are multiple possible labels, for example, it could be a
180.54|4.16| vehicle, car, automobile, and stuff like that. So there are
184.7|3.48| multiple possible ways to have a correct label. And sometimes
188.18|3.12| there are also multiple objects in an image here. Yeah, for
191.3|2.72| some reason, I mean, the researchers use the top one
194.02|3.32| accuracy, I think top five accuracy, both are important
197.34|3.96| things to look at. In any case, what's interesting here is the
201.42|3.44| x axis. So here, on the x axis, the research researchers also
204.86|3.44| focused on computational efficiency. So here, they call
208.3|4.2| it the training latency as I think it's seconds per step on
212.86|3.28| the TPU. So that's like the tensor processing unit
216.14|4.4| equivalent to a GPU or similar to a GPU. And they looked at a
220.54|4.08| batch size of 32 per device, they used multiple devices,
224.62|6.24| multiple TPUs in parallel. Yeah, but what is interesting, though,
230.86|3.36| is to think of it as just like the efficiency. So the right
234.22|8.0| hand side, so here, it's more expensive. And this one here on
242.22|3.08| the left hand side would be cheaper, like cheaper to train
245.3|3.72| faster to run. So and why is that interesting to look at?
249.06|3.56| It's because you can also think of it as if you make a model
252.62|2.24| larger, you have more parameters, you will likely get a
254.86|3.12| better performance. But then at the same time, also, these
257.98|3.4| networks become more expensive. So depending on your
261.38|3.08| application, you are interested also, sometimes in smaller
264.46|3.52| models, because you cannot run these large models, for example,
267.98|2.76| on a cell phone or iPhone or something like that, where they
270.74|4.72| have on device machine learning algorithms. But then also at the
275.5|3.2| other hand, otherwise, you can make the argument together, the
278.7|1.96| model, the better the performance. And you want to
280.66|4.16| also see whether the method just works for smaller models. So
284.82|3.58| here, they have different flavors of the method f zero to
288.4|4.06| f5. I think these are just different sizes of the model.
292.46|5.16| And you can see, in terms of accuracy, their method is better
297.66|3.0| than all the other methods here. And these are actually pretty
300.66|2.68| good methods. It's like all the efficient methods, but it's
303.34|3.2| called efficient net, for example, on lambda net, I think
306.54|3.04| this stands for data efficient image transformer, and so
309.58|4.24| forth. So you can see for all types of model sizes, their
313.82|3.04| method performs better than these alternatives. But again,
316.86|2.08| these are different architectures, we will talk more
318.94|2.98| about the convolutional network architectures later in this
321.92|3.06| course. What was interesting really here is that you can also
324.98|3.2| achieve good performance without using batch normalization.
330.02|3.12| Yeah, here's another interesting thing I found this week, it's
333.14|4.56| not so much a news article, but a Reddit discussion from the
337.7|2.4| Reddit machine learning subreddit, which has sometimes
340.1|4.16| really interesting and useful, insightful discussions. So here
344.26|4.08| someone asked about deep learning theory, like wondering
348.34|3.4| about the recent advances of or in the theory of deep learning,
351.74|3.44| like certain understandings, how we think of deep learning. So in
355.18|3.36| the last couple of years, there were some hypotheses that were
358.78|3.7| particularly popular, for example, the lottery ticket
362.48|4.5| hypothesis, which is essentially about saying that, just by
366.98|4.92| chance, if you train a large hyper over parameterized network
372.14|2.96| with lots of combinations, just by chance, there is a high
375.1|3.6| probability that at least one of them will have optimal
378.7|3.28| performance, just because you considered so many variations or
381.98|3.52| combinations that just one of them performs well by chance.
385.94|3.16| And there's a lot of evidence in favor of this hypothesis. But I
389.1|3.36| also recall, like a couple of weeks ago, or months ago, I
392.46|4.04| think it was 2020, there was a paper, like, giving evidence
396.5|3.88| against this lottery ticket hypothesis. And in this way, I'm
400.42|3.56| actually not sure in how far this hypothesis is still a
403.98|4.56| valid hypothesis. Anyways, um, the other one is the double
408.62|3.12| descent hypothesis, which is also particularly interesting. So
411.74|2.76| here at the bottom, I have a screenshot of this hypothesis
414.9|2.36| from a different blog post article, because it was just a
417.3|4.2| nice image. So what is shown here is the test and the
421.5|3.24| training error. So in contrast to the previous slide, the lower
424.74|2.52| is better. So in the previous slide, we had accuracy. So the
427.26|4.2| higher was better here, it's the lower is better. And here we
431.46|3.52| have, for example, the view, the expected view, the classical
434.98|6.52| statistics viewpoint. So here, you can think of it in a
441.78|5.2| classical statistics viewpoint, that you start with a model that
446.98|3.6| has a high error. Why is the error high? Yeah, that is
450.58|6.28| because usually, your model is too simple to capture the
456.86|2.8| complexity in the data. So your model doesn't have enough
459.66|3.72| parameters, and then it's too simple and cannot achieve a good
463.58|2.04| classification performance. Because for example, think you
465.62|3.4| have a think of a nonlinear decision boundary that you need
469.02|3.48| to classify the data, but you only have a linear model. And
472.5|3.6| this way, the model is too simple to capture the patterns
476.1|2.96| in the data. And as you make your model more and more
479.06|2.72| complex, maybe think of adding more layers to a new network,
482.14|3.2| then your training error will go down and the test error will
485.34|3.68| also go down. But at some point, the test error will go up again,
489.02|2.5| because you have now so many parameters that your model
491.52|3.26| starts overfitting. So in this way, your model will perform
494.82|3.0| worse with a given size. So here, they use the residual
497.82|2.72| network, we will talk about residual networks also later in
500.54|6.16| this class. Yeah, so this is the classic statistical viewpoint
506.7|6.84| with, let's maybe let's consider the modern, modern view, modern
513.54|4.6| view is usually the more data you have, the larger, sorry, the
518.14|2.24| larger the accuracy, but also the smaller the arrow,
520.38|4.16| basically. So but the reality is that there's usually this bump,
524.58|3.2| that is what researchers found out I think in the last couple
527.78|3.64| of years. So if you look at it in practice, you start with a
531.42|3.2| high accuracy, the accuracy, sorry, high error, the error
534.62|4.6| goes down. But then it goes up again, for some reason. So and
539.54|3.0| then there's this bump, and then it goes down again, which is a
542.54|4.28| little bit weird. So people call that the double descent
546.82|3.44| hypothesis, because you go first down, then you go up, and then
550.26|2.68| you go down again. So right now, I think it's also still a
552.94|3.16| discussion whether this is a valid thing, or whether this is
556.1|4.24| maybe due to accidental experimental errors, like
560.34|2.92| someone, maybe at some little bug in the code or something
563.26|3.44| like that. But so far, all the evidence shows that this is
566.7|3.2| indeed a phenomenon that can be observed. And yeah, that was
569.9|3.2| another interesting hypothesis that is currently still under
573.1|1.84| discussion. So if you're interested in more of these
574.94|3.44| types of things, check out the subreddit, there are way more
579.46|3.52| hypotheses listed below there in the thread. So people discuss
582.98|2.28| these types of things. And I think it's just interesting if
585.26|1.8| you are curious about these things.
587.06|6.96| Um, yeah, another interesting research article I saw was this
594.02|3.64| one here entitled, removing biased data to improve fairness
597.66|3.24| and accuracy. Sounds like a relatively straightforward
600.94|4.76| approach. Like if you have an unfair system, and this is like
605.7|3.8| also a very important topic, due to your data set, sometimes in
609.5|3.56| other reasons, machine learning systems can be unfair towards
613.06|4.28| certain subpopulations, for example. And here, the researchers
617.34|5.44| tested the idea that removing biased data, whether this can
622.78|4.8| improve the fairness and maybe even the accuracy of the system.
627.9|3.6| And what they found, what was quite interesting is that they
631.54|4.56| achieved a low discrimination of almost 0%. When they trained the
636.1|4.0| model on the biased data. So by just changing the data set, they
640.1|4.62| were able to reduce the discrimination of the model. But
644.72|3.5| what was also interesting is that they said, or observed a
648.22|2.92| higher accuracy compared to models trained on the full data.
651.14|4.12| So basically, they removed biased data points. And not only
655.26|3.48| did they improve the fairness of the machine learning model, but
658.74|4.28| they also achieved a higher accuracy. So and according to
663.02|2.86| the authors, for example, other methods that are being used to
665.88|3.46| make machine learning more fair, usually achieve this fairness at
669.34|3.52| the expense of accuracy. So usually, when people want to
672.86|2.54| make a machine learning model more fair, the accuracy goes
675.4|3.88| down. And in here, they found the opposite, you make it more
679.28|3.38| fair, and the accuracy goes up, which is which sounds like a
682.66|4.04| win win situation. So here's just a brief overview of what
686.7|3.72| they did. So they started with the biased training data. And
690.42|4.44| they had a feature extractor generated similar pairs. So
694.86|5.8| similar passes. In terms of you have a data point from so maybe
700.66|3.68| let me step back, take a step back. So they evaluated it on
704.66|5.08| eight data sets here, where they had multiple attributes. And
709.74|3.72| they had also a sensitive attribute, for example, the sex
713.46|3.68| of a person or the race of a person. And what they wanted to
717.14|2.84| predict is, for example, different things like income,
719.98|3.96| creditworthiness, exam scores, and so forth. And they, for
723.94|3.24| example, generated similar pairs with, for example, someone who
727.18|3.92| had or whether some instances where the sensitive attributes
731.1|4.24| were different, but everything else was the same. So they found
735.34|6.66| individuals treated unfairly. And they trained algorithms based
742.0|6.06| on this biased model, they then ranked these instances by
748.06|3.86| influence of how much influence these instances had on the
751.92|2.98| model. And then here, they sorted the training data,
754.9|4.52| removed the data points, and trained model on this
759.46|5.24| debiased data set, measured the discrimination. And then if the
764.7|3.36| discrimination decreased, they did another round and removed
768.06|3.78| more data points. So they kept going until no improvement could
771.84|3.18| be made. And they found by by this simple approach, they
775.02|4.6| could improve both the fairness and the accuracy, which it
779.62|3.96| sounds like a good idea. But I'm not an expert in this area. But
783.58|3.48| it sounds like something that should be explored more and
787.06|2.64| maybe also applied to some deep learning models. So I found this
789.7|5.96| interesting. Related to also the training data influence, I saw
795.66|4.8| this article by Google AI research teams. So they had a
800.46|2.72| blog article, but then in the blog article is also a link to
803.18|3.64| the paper to the original paper. So they call their method trace
806.82|4.08| in, which is a simple method for estimating the trainer training
810.9|4.4| data influence. So what they do is on during training, they
815.3|2.8| record the changes in the prediction caused by an
818.1|4.48| individual training example. So they train a model and then look
822.58|4.08| whether the training performance is how much the training and
826.7|2.76| performance is influenced by this particular data point. And
829.46|2.2| this technique is especially then useful for detecting
831.66|3.6| outliers. And also what you can do with this technique is you
835.26|4.96| can explain predictions. So to get some insights into the AI
840.22|2.76| model from the training examples, rather than the
842.98|4.28| features. So most techniques for interpretability usually focus
847.26|4.08| on the features, it's basically about saying, okay, this and
851.34|2.52| this attribute in the training set is important for making
853.86|3.28| predictions. Here, they look at it from the perspective of
857.14|3.36| training examples, like which training examples have a large
860.5|3.16| influence on the model. And I can imagine, if you think back
863.66|3.6| of the previous slide, this model on fairness, I think
867.26|3.88| those two methods might be also interesting to combine in a way
871.14|3.16| that might be a good or interesting thing to look at
875.14|2.56| these influential training examples and how they maybe
877.7|3.48| influence the fairness might be a future reach a research
881.18|3.36| direction. Anyways, um, or could be something interesting for
884.54|3.08| your class project. In any case, so here's a figure from this
887.62|4.8| blog post. So here on the x axis, they have the updates
892.42|2.6| during training. So the different model updates on the y
895.02|3.76| axis is the loss. And here, they take a look at the class
898.82|3.56| zucchini. And they notice, for example, if they provide a
902.38|3.96| training example that contains zucchinis, then the loss goes
906.34|3.76| down as expected. So you go down with the loss. But then for
910.1|2.88| example, if you encounter a training example, seatbelt,
913.0|2.18| which has nothing to do with the zucchini, then the training
915.18|5.24| loss for zucchini goes up. So if you want to improve the zucchini
920.42|2.44| classification, then you shouldn't show it seatbelt
922.86|3.16| samples. But then of course, your problem is probably a
926.02|2.2| multiclass classification problem where you also have
928.22|2.84| seatbelts. So it's like a trade off, right? Should you show the
931.06|2.04| seatbelt? I mean, then you make maybe the seatbelt
933.1|3.48| classification better, but then you lose on the zucchini
936.58|3.44| classification. So in this way, they give it here another
940.02|6.68| seatbelt, it goes up. And here goes down, we're doing some
946.7|2.28| other I don't think they show every training example, they
948.98|3.4| only show the most influential ones, the proponents and
952.42|3.92| opponents, and seatbelt, it goes up again, zucchini, it goes down
956.34|3.4| by a lot, and so forth. And sunglasses, that's interesting.
960.18|5.04| For sunglasses, also, the loss goes down on zucchini. Yeah. And
965.22|3.2| so here, they can kind of better understand what influence the
968.74|4.6| data set or data example have, for example, here, one seatbelt
973.34|2.52| has more influence than another seatbelt. And this way, you may
975.86|7.12| also find interesting, weird outliers in a data set. Yeah,
982.98|3.04| another interesting research article was related to
986.1|3.0| generative generative adversarial networks. So this
989.1|2.32| is also something we will be covering towards the end of the
991.42|2.92| class. And this might be also general, though, on interesting
994.66|4.68| application or idea for your class project. So there were
999.34|3.76| some projects in the past called, this person does not
1003.1|9.64| exist where people used generative adversarial networks
1012.98|4.48| to generate faces of people that don't exist in real life. So for
1017.46|3.24| example, this person does not exist in real life, it's made
1020.7|3.0| up by the model. And if you go to this website and refresh it
1023.7|2.32| every time you will see a different face that does not
1026.02|4.68| exist in the real life. And also similarly, there's a website
1030.7|3.72| called this cat does not exist where people did the same thing
1034.42|6.2| for cat images. So here you can generate cat images. Yeah, and
1041.1|5.76| now researchers applied the same idea to genome research. So here
1046.86|4.3| was an article linking to a research article that was
1051.16|3.26| recently published, where the researchers described that in
1054.42|2.68| our work, we apply a similar concept to genetic data to
1057.1|2.52| automatically learn its structure and for the first
1059.62|4.52| time, produce high quality, realistic genomes. So why is
1064.14|3.72| that important or interesting? Currently, there's a lot of
1068.06|3.64| research being done on DNA and genomes. But one problem is
1071.7|4.08| really like privacy, because your genome is unique to for a
1075.78|3.36| given person. So if you do research on genomic data, you
1079.14|3.28| kind of have to be careful of about how you handle the data.
1082.7|3.52| If you have realistic genomes that are totally realistic, but
1086.22|2.84| don't belong to a certain person, then I can imagine this
1089.06|3.24| can make certain types of research easier. For example, if
1092.3|4.64| you if you train large scale classification models for
1096.94|4.84| different genes, and you have a data set, and your model learns
1101.78|2.92| from this data set, the model will contain contain some
1104.7|3.6| information about the data. So it's kind of, yeah, a little
1108.3|2.72| tricky to make this model available for people or to
1111.02|3.04| people who might find it useful, because maybe someone would be
1114.06|3.0| able to extract some personal information from that model. If
1117.06|5.0| you train a model on this fake DNA, and it works well on real
1122.06|3.76| DNA as well, I can imagine this can help with some of these
1125.9|1.84| privacy issues around that.
1129.42|3.48| Yeah, one last thing about computer vision or related to
1132.9|3.24| computer vision, which might also be useful as inspiration
1136.14|4.28| for a class project. So I also saw this project where the
1140.42|4.66| company, I think it's called Rebeck company trained computer
1145.08|6.22| vision model to estimate the price of a handbag. So here,
1151.98|2.76| based on the article and interview with the person, they
1154.74|3.72| trained it on millions of data points. And it took like six
1158.46|4.32| years to develop six years to develop this app. But yeah, it
1162.78|3.88| sounds like a fun project where you can take a picture of your
1166.7|3.52| handbag, and then it estimates the price. So it's like a
1170.22|3.72| simple, straightforward computer vision project, I think, not too
1173.94|2.9| complicated. But I guess the trick here was to really get a
1176.84|3.06| lot of pictures of handbags and make it accurate. So that might
1179.9|3.6| be also like an inspiration for a class project, of course, not
1183.5|3.56| with handbags, but maybe with something else. So yeah, these
1187.06|3.4| days, people maybe sell a lot of cell phones or laptops or
1190.46|3.2| something like that. So in that way might be also interesting.
1193.66|2.96| Of course, it's not only then based on the picture, but also
1196.66|3.56| some other statistics like processor speed, the age of the
1200.22|2.52| computer and stuff. But yeah, I think this is also maybe an
1202.74|3.72| interesting, fun class project to develop a simple computer
1206.5|3.04| vision app that can take pictures of something and then
1209.94|3.72| estimate the resale value. Alright, with that, this is all
1213.66|4.44| I have for this news week. And I wanted to also wish you a happy
1218.1|3.24| lunar new year. Hope you have a nice weekend and I will see you
1221.34|11.64| back in class on Tuesday.