start_time|end_time|text
0.7|3.94| All right, let's not talk about the main idea behind GANs, that
4.64|3.28| is letting two neural networks compete with each other to
7.92|5.16| generate new data. And so the reason why it's called
13.38|3.58| generative attracera network is really that we are using it to
16.98|4.86| generate new data here. And not so much like in the traditional
21.92|3.16| statistical sense that we are explicitly modeling, let's say
25.08|3.12| the joint distribution of the features and the labels on the
28.2|2.96| data generating distribution. Here, it's really more the fact
31.2|3.8| that we are generating new data, although we are implicitly
35.04|6.04| learning a distribution here. In any case, traditionally, GANs
41.08|3.28| were used for generating new images. And I would say,
44.68|3.84| generating new images is still the biggest application of GANs.
48.76|4.8| Of course, the concept is broader. So you may also apply
53.56|3.16| that to different types of data. For instance, I've seen recently
56.72|3.52| a text GAN, although for text data, maybe other models are
60.24|5.88| better, like RNNs or GPT, which is transformer, auto regressive
66.12|4.04| model. And yeah, so there are other models that are probably
70.16|2.8| be better suited for text, but it's possible to train again for
72.96|3.48| text. Another application would be, for example, generating new
76.44|3.96| molecules, like graphs of numeric molecules, in the context
80.4|4.32| of computational biology, that's an area I'm working on a little
84.72|6.08| bit. So anyways, um, so behind the curtains, what a GAN does,
90.8|3.32| it's learning implicitly the training set distribution. And
94.12|6.04| then it kind of mimics this distribution in the way it
100.16|4.08| allows us to create data that comes from this distribution,
104.24|2.96| essentially generating new data on new images that have never
107.2|3.32| been seen before, kind of similar to what a variational
110.76|3.76| auto encoder does, when we consider the decoder. So when we
114.52|3.76| sample a random noise vector, and then run this through the
118.28|3.68| decoder, it's also generating new data. And that way, also, the
121.96|3.64| generator of the GAN can generate new data from a noise
125.6|3.96| vector. How things work is a little bit different. So we
129.56|5.04| don't have, we don't model distribution in this context, we
134.6|4.44| are having a setup of generator and a discriminator. And the
139.52|4.1| discriminator is kind of like a judge, which is kind of
143.62|4.34| implicitly, I would say forcing the generator to model the
147.96|1.88| training set distribution, it will become more clear in the
149.84|3.88| next figures when I show you how the GAN setup looks like. And
153.72|4.16| they are also similar to a variational auto encoder. The
157.88|3.76| GAN is generating the whole output all at once, which is
161.64|3.52| different from other types of models, for example, auto
165.16|3.0| regressive models or recurrent neural networks. So next
168.16|4.04| lecture, I will, if we have time for another lecture, we'll show
172.2|3.0| you how we can use a recurrent neural network for generating
175.2|4.0| new text one word or one character at a time. Okay, but
179.2|4.88| now focusing on the generative adversarial network. So here,
184.24|3.6| this figure, I took this from the convolution neural network
187.88|2.76| lecture. So I already spent so much time making this figure
190.64|2.56| that I didn't want to make a new one. This is why it's a deep
193.2|6.8| convolution again here. Of course, the same concept would
200.0|3.76| apply to a regular gun. So the reason why it's deep convolution
203.76|4.32| is, is because these here are convolution layers in this
208.08|4.02| particular figure. But you can also think of this as fully
212.1|5.3| connected layers and like in a regular GAN. The main concept in
217.4|2.5| this game, though, is not these convolution layers or fully
219.9|3.46| connected layers, it's really the discriminator and the
223.36|3.92| generator. So we have two parts here, let me maybe clear this
227.28|2.28| part, because it's distracting. So we have two parts here, we
229.56|3.72| have the generator, which is taking as input and noise
233.28|4.04| vector. And then it's running it through some neural network
237.32|3.92| layers. And then it produces a generated image. And this is
241.52|4.28| essentially kind of similar what the variational autoencoder
246.0|3.12| decoder part is doing. It's kind of similar, it's generating
249.12|4.24| new data. But instead of like using a reconstruction loss, or
254.4|4.44| also instead of using an encoder and so forth, again, works very
258.84|2.72| differently from a variational autoencoder. What we have here
261.56|4.24| now is this discriminator. And what the discriminator is doing,
266.1|5.26| it's judging whether this generated image looks real or
271.36|8.04| not. So the discriminator here receives two types of input. So
279.4|3.48| it receives real images from the training set. So these real
282.88|4.76| images are from the training set. And it receives these
287.64|3.72| generated images from the generator, and it has to judge.
291.48|3.52| So the job of the discriminator is to judge whether an image is
295.0|4.92| real or generated. And how this is trained, I will show you
300.28|6.04| step by step in the next couple of slides. So just focusing on
306.56|8.08| the discriminator now. So let's call that step 1.1. So step 1.1
314.64|5.08| is training the discriminator. What we do is we take the
319.72|4.96| training set, we give it the label real image. So we can say
324.68|5.2| this is the for real image, we have the label one. And for a
329.88|7.48| generated image, you can say it's class label zero. So it
337.36|2.6| becomes essentially a classification task. So the
339.96|4.0| discriminator is essentially just a binary classifier. And all
343.96|5.24| these real images have label one. And we are training the
349.2|5.68| discriminator to output. If you think back of the logistic
354.88|4.96| regression, lecture, or just how we use a binary cross entropy
359.84|4.08| loss, we are training it to maximize this probability here.
365.24|4.56| And if the label is one, we want this one here, this probability
369.8|4.44| this output close to one. So we want this close to one, ideally.
375.4|4.32| So we want the probability that this is a real image to be high.
380.68|5.16| So as a step one by one, 1.1, training the discriminator. Step
385.84|5.04| 1.2 is training the discriminator further, but also
390.88|4.12| now considering the generated images. So for these generated
395.0|6.68| images, we use label zero, like I've shown you before, these
401.68|4.32| generated images. So we use now label zero. And we want this
406.0|3.2| probability that this is a real image, we want this to be close
409.2|4.72| to zero using binary cross entropy. So essentially, we're
413.92|3.8| just training a classifier here to distinguish between
418.08|5.2| generated and real images. Note that while we are training
423.28|4.0| this, so this image, this generated image is coming from a
427.28|5.96| noise vector, just a random noise vector here. This or I was
433.24|2.6| actually writing that this was coming from a uniform on
435.92|3.64| standard normal distribution. For some reason, it got deleted
439.56|4.64| here, but you can think of it as let's say, random, normal
444.2|2.92| distribution. So this noise is from a random normal
447.12|6.2| distribution. And it goes through these new network layers.
453.88|3.48| And then it serves as input to the discriminator. But notice
457.36|3.44| that what I'm trying to say here with the freezes that we are not
461.2|3.84| updating the generator here, we are only in this step, we are
465.04|7.12| only training the discriminator at this point. Okay, next step,
472.64|3.68| step two, step two is training the generator. So let me just
476.32|3.96| recap. Step one is training the discriminator to detect real
480.28|5.4| images. Step 1.2 is training the discriminator to detect
485.68|4.92| generated images. Now, we are training the generator. And we
490.6|4.78| are training it such that the discriminator makes a wrong
495.38|5.34| prediction. So this is why it's called a generative adversarial
500.72|4.12| network. This is like, it's like an adversary, we want the
504.84|3.68| discriminator to be better at distinguishing between real and
508.52|2.84| fake. But the generator, the job of the generator is actually to
511.36|7.76| fool the discriminator. So what we do is, we actually want for
519.12|4.0| the generated image, now the discriminator to output a score
523.12|4.12| that is close to one high probability that this image is
527.24|4.88| generated. So we are trying to fool the discriminator. In this
532.12|3.32| step, when we are training the generator, we are actually not
535.48|5.2| updating the discriminator, we are only now updating this part.
542.52|4.84| So one more thing is also we are technically in practice flipping
547.44|5.0| labels. So we are there's a trick, but I will I will maybe
552.44|2.04| get to that later. And so there's already too much
554.48|2.8| information here, I think right now. So what we are trying to do
557.28|3.92| is, we are now trying to maximize the probability that
561.2|5.28| this that the screen to things, this is a real image. And then
567.76|2.96| after step two, we would go back to step one and train the
570.72|3.64| discriminator again, to be better at detecting real images
574.72|4.24| and generated images. And then we train the generator again, to
579.04|4.36| fool the discriminator. So it's kind of like a game. So in fact,
584.32|3.36| the discriminator learns to become better at distinguishing
587.68|3.8| real from generated images. And the generator learns to generate
591.48|2.52| better images to fool the discriminator. So there's like
594.0|3.44| this little adversarial game going on. And if you do this
597.44|3.68| long enough, at some point, the discriminator will be very good
601.12|3.68| at distinguishing between the generated and real images. But
604.8|3.08| at the same time, the generator will be very good at generating
607.92|2.96| fake images that look just like the ones in the training set.
611.64|4.8| You will see, as you have seen before, if I go back to the
616.44|5.68| previous video slides, so these images are all generated by GANs.
622.12|3.8| So playing this adversarial game, GANs can become very good
625.92|3.28| at generating images like this that don't even exist in real
629.2|4.84| life, they were just generated. Okay, so this is like the big
634.04|4.56| picture overview of GANs. And in the next video, we'll go into
638.6|8.16| more detail of how the loss function looks like.