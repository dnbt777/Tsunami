start_time|end_time|text
0.24|2.68| Yeah, in this video, I want to briefly go over the notational
3.08|4.96| conventions regarding linear algebra and deep learning. So
8.52|2.48| this is something we have seen before from the perceptron
11.0|4.68| lecture. So at the top, there is a perceptron. And now imagine we
15.68|5.16| do inference. So inference in the context of deep learning means
20.96|5.52| basically predicting the label of input feature vector. So in
26.48|3.92| the perceptron, assume we have one training example as input or
30.68|6.24| let's say, test, test data point or test example as input. So how
36.92|3.88| we would do that is as follows, we would have x transpose w
40.8|3.92| plus b, the bias unit, and then get the net input. And then we
44.72|3.32| give it to the activation function, which was the
48.04|3.48| threshold function, and then we get our prediction. So here,
51.52|4.64| this part is doing this linear algebra computation, x
56.16|5.88| transpose dot w plus b. So now this is for one data point, we
62.04|4.0| can actually also extend that to multiple data points. So if we
66.04|3.36| want to do that for multiple data points, like n training
69.4|6.0| examples, or n test examples, we can use a design matrix for
75.4|2.92| representing the data and n times m dimensional design
78.32|11.28| matrix. So n is the number of examples. And we would write it
89.6|8.72| as follows. So here, x is n times m, w is m times one, b is
98.36|6.8| just a scalar as a one. And then the output should be n times m
105.16|6.0| dot m times one, it should be n times one. Yeah, n times one,
111.16|3.6| that should be our output. So in this way, we have a vector. So
114.76|3.24| each value in the vector is the net input for the corresponding
118.04|3.74| test example. So that is just how we can process more data
121.78|3.22| points at the same time with still a single operation here.
125.92|3.24| Now, in deep learning, we usually have these neural
129.16|5.44| networks with hidden layer representations. So we will
134.6|2.52| learn about that a little bit later in this course, actually,
137.12|4.16| like I think next week already. So we have, let's say one data
141.28|5.52| point is input here, that's a feature vector, m features. And
146.8|8.52| then we will have a number of outputs. So let's say h is the
155.32|5.46| number of hidden units in a hidden layer. And then we have
160.8|2.8| also multiple hidden layers. So we can have another hidden
163.6|2.82| layer and another one and so forth. So in this way, what I
166.42|3.24| want to highlight here is that whereas in the perceptron, we
169.66|6.78| have a single output here, here, we can have multiple outputs. So
176.44|4.0| how can we do with such a scenario using linear algebra?
180.84|5.36| So what we can do is we can now have a weight matrix. So before
186.2|3.92| I talked about the design matrix for the inputs, now, there's one
190.12|8.36| input vector, one data point, but multiple outputs. So in this
198.48|6.08| way, we can use a matrix here. So this matrix would be h times
204.56|9.44| m dimensional. So let's write that down. h times m, so h rows
214.0|4.72| and m features, whereas the features are corresponding to
218.72|5.12| the m here, so the m matches here. So what we do is we put
223.88|5.16| the w in front, the x second. So this would be if I write this
229.04|9.8| down, h times m dot m times one, and b should be then also the
238.84|5.0| same dimension as h. Because there's one bias unit for each
244.44|4.0| computation here. So the output should be h times m dot m times
248.44|6.08| one, h times one, h times one dimensional output vector. So
254.56|3.04| it's also what I've written down here, I just see. So yeah, so in
257.6|3.5| this case, this is how we can deal with multiple outputs. And
261.1|4.34| we will learn how this works. Also, yeah, shortly later on
265.44|4.6| next week. Okay, let's now put both concepts together. So we
270.04|14.24| have multiple training examples and multiple outputs. So we have
284.28|4.64| now a matrix for the weights and a design matrix for the inputs.
288.96|6.24| So let's write it like this. So w has the dimensionality h times
295.2|6.72| m like on the previous slide. And x has the dimensionality n
301.92|3.04| times m, it's a design matrix, right. But now if you want to
304.96|2.68| multiply those two, you notice that they are not compatible,
307.64|3.42| right, the inner dimensions don't match. So that's why we
311.06|6.86| have the transpose here. So get me write it like this. So this
317.92|7.32| has a dimensionality on m times n now. So those dimensions match
325.94|7.14| m is h times one dimensional. So if I multiply those, so these
333.08|6.92| match the inner ones, so we have n. So this one is h times n plus
340.04|6.48| h times one. So the resulting resulting matrix, if we look at
346.52|7.64| this one, the dimensionality of that one should be h times n.
354.68|5.3| However, it is usually nice for each layer to resemble the input
360.0|4.24| dimensions of the previous layer, right. So the original
364.24|7.68| input, you can think of x as the original input was n times m. So
371.92|3.24| it would be nice if we have for this one as input to the next
375.16|4.48| layer, the same dimensionality, like the same ordering, I mean,
379.64|3.32| not exactly the same dimensionality, but the input, the
382.96|2.48| first dimension, the inputs, the number of inputs should be the
385.44|2.24| same, we are carrying over the same number of training
387.68|5.8| examples. So what we would want is for a for the outputs, to
393.48|6.3| have dimensionality, n times something so n times h, where h
399.78|3.58| is the hidden dimension. So in order to achieve that, this is
403.36|3.0| why we have the transpose. So with this transpose, we have
406.36|4.2| then n times h dimension. So it's usually nice, what I mean
410.56|3.84| is, it's nice to have the training examples as the rows
414.44|5.48| always. Now, if you think of this, what's going on here, you
419.92|2.92| can think of it as a linear transformation that is happening
423.0|6.22| to x. So instead of the original m features, we now have h
429.22|5.28| features, and h could be larger or smaller than m. So there are
434.52|4.18| in deep learning, both some networks make, make it larger
438.7|3.4| and some make it smaller. So there's a linear transformation.
442.6|3.28| Like I said, but it's not necessary, completely true. So
445.88|2.94| if this is a nonlinear function, then it's not a linear
448.82|3.02| transformation, it's a linear transformation that goes through
451.84|3.06| a nonlinear activation function. But we will talk about this
454.9|4.68| activation function on next lecture. So but yeah, this is
459.58|4.98| just like the overall notation. Also in textbooks, you may
464.56|3.32| notice that there is no transpose. So I have a short
467.88|2.86| note here about that. And the reason is in textbooks and
470.74|5.72| older textbooks, especially, they have not the n times n, n
476.46|4.12| times m design matrix, they have an m times n design matrix. So
480.58|4.3| they have the columns as rows switched, which is a little bit
484.88|3.96| confusing. I just want to note that in case you stumble upon
488.84|4.84| it. So usually modern deep learning has n times m
493.68|5.24| dimensional inputs. Sometimes it makes things more inconvenient
498.92|2.08| from a linear algebra perspective, because you notice
501.0|2.68| here, we have these transpose. If you have it the other way
503.68|3.04| around, you don't need the transposes. But yeah, there's
506.72|5.84| always a trade off. Alright, so um, why also this w x
512.56|3.8| notation, why not x w, actually, in the next video, I will show
516.36|4.14| you that in pytorch, it's the other way around. Traditionally,
520.5|3.58| though, this is convenient, because it's there's some
524.08|3.52| intuition behind it in terms of linear algebra, if you think of
528.4|3.4| traditional methods, how you write things in linear algebra,
532.2|2.76| it's that you have a transformation matrix that you
534.96|2.76| apply to a vector. So the vector would be here your feature
537.72|6.04| vector. And this makes it sometimes for some people easier
543.76|5.04| to think about linear algebra in a geometry context. So here,
548.8|3.56| this is just an identity matrix. So nothing is going to happen.
553.12|5.24| So technically, these diagonals, I think I have a slide on that
558.52|5.88| these diagonals are for scaling. But this diagonal is for scaling
564.4|5.32| values in the vector. And the other diagonal is for
570.32|7.16| translation. So moving things. And it's like easy to see. So
577.48|2.88| why the eigen sorry by the identity matrix is not doing
580.36|3.48| anything, because the scaling is here one and one. So scaling
583.84|3.56| something by one doesn't change it. And translation by zero
587.4|5.28| doesn't change anything either. So in this way, the original
592.68|3.04| inputs are preserved. So also, if you think of it as a dot
595.72|4.64| product, we remove the notation here, if you think of it as a
600.52|6.24| dot product. So one times zero, with this one, it's basically
606.76|4.8| one times x one, plus zero times x two, which is x one, right?
611.88|5.4| And here, zero times x one is zero plus one times x two is x
617.28|4.16| two. So nothing is going on here. Or he actually has the
621.44|5.4| slide on that he has like a summary of what I just meant. So
626.84|6.52| you can also write it as follows. So whereas if you so
633.36|5.72| you can decompose this into two separate operations vector
639.4|3.8| addition with this scalar here. And then you can think of this
643.2|5.2| first one as scaling the x coordinate. And then you can
648.4|7.04| think of this one as scaling the y coordinate. So like I said
655.44|3.68| before, these are for scaling. And then the other ones are
659.16|5.0| moving the vectors. So these are for moving the vectors. Yeah,
664.16|4.36| here, I just have an example of the scaling. So for example, if
668.52|3.16| you have a matrix that has a three here, it would scale
671.72|3.92| three. So sorry, scale the x axis by three. So it's kind of
675.64|4.68| stretching it here. And so forth, he is scaling or
680.32|5.36| stretching the y axis by a factor of two. And this one here
685.68|3.32| at the bottom is doing both stretching and scaling. And you
689.0|2.54| can maybe as an optional homework, think about the
691.54|4.02| translation. But in the context of deep learning, I think it
695.56|2.96| might be helpful sometimes to think of it as a series of
698.52|3.2| transformations. But yeah, also, one of the reasons why we use
701.76|3.64| linear algebra is more like for making notations more
705.4|3.48| compact, and we'll show you in the next video how this is
708.88|26.64| achieved in pytorch.