start_time|end_time|text
5.6|4.84|hi everyone thanks for coming to our
7.319|5.641|cs35 lecture today uh so today we're
10.44|5.239|honor to have Jim B from Nvidia we'll be
12.96|5.52|talking about generous agents in open
15.679|5.44|ended worlds and he's a senior AI
18.48|5.16|research scientist at Nvidia where his
21.119|4.801|mission is to build generally capable AI
23.64|5.44|agents with applications to gaming
25.92|4.88|Robotics and software Automation and it
29.08|4.479|research spans from condition models
30.8|5.72|multimod AI reinforcement learning and
33.559|5.801|open-ended um learning he obtained his
36.52|5.44|PhD degree in computer science from here
39.36|4.92|Stanford advised by Professor
41.96|5.239|p and previously he did research
44.28|5.68|internships at openi Google AI as well
47.199|7.0|as um mil Quebec AI
49.96|6.599|Institute uh so yeah we're um um give it
54.199|2.36|up for
58.92|7.76|Jim yeah thanks for having me so I want
63.04|5.84|to start with a story of two
66.68|4.479|kittens um it's a story that gave me a
68.88|4.239|lot of inspiration over the career over
71.159|4.201|my career so I want to share this one
73.119|5.121|first you know back in
75.36|5.36|1963 there were two scientists from MIT
78.24|4.8|helden Hine they did this ingenious
80.72|5.28|experiment where they put two newborn
83.04|5.039|kittens in this device and the kittens
86.0|4.6|have not seen the visual world yet so
88.079|4.08|it's kind of like a Maro round
90.6|4.04|where the two kittens are linked by a
92.159|5.361|rigid mechanical bar so their movements
94.64|4.96|are like exactly mered and there's an
97.52|4.279|active kitten on the right hand side and
99.6|4.519|that's the only one able to move freely
101.799|4.92|and then transmit the motion over over
104.119|4.36|this link to the passive kitten uh which
106.719|3.841|is confined to the basket and cannot
108.479|4.041|really control its own
110.56|4.159|movements and then after a couple of
112.52|4.76|days helden high kind of take the
114.719|4.76|kittens out of this marry Go Round And
117.28|4.479|then did visual testing on them and they
119.479|4.121|found that only the active kitten was
121.759|4.28|able to develop a healthy visual motor
123.6|4.56|Loop like you know responding correctly
126.039|4.64|to approaching objects or like visual
128.16|3.84|Cliffs but a passive kitten did not have
130.679|4.601|a healthy visual
132.0|5.239|system so I find this experiment
135.28|4.64|fascinating because it shows the
137.239|5.961|importance of having this embodied
139.92|5.28|active experience to really ground um a
143.2|4.679|system of
145.2|5.08|intelligence and let's put this
147.879|4.241|experiment in today's AI context right
150.28|4.36|we actually have a very powerful passive
152.12|5.96|kitten and that is
154.64|5.44|chbt it passively observes and rehearses
158.08|4.0|uh the text on the internet and it
160.08|3.799|doesn't have any embodiment and because
162.08|3.84|of this its knowledge is kind of
163.879|4.561|abstract and ungrounded and that
165.92|4.84|partially contributes to the fact that
168.44|4.159|CH hallucinates things that are just
170.76|3.52|incompatible with our common sense and
172.599|3.681|our physical
174.28|4.599|experience and I believe the future
176.28|6.0|belongs to active kidneys which
178.879|5.08|translates to generalist agents they are
182.28|3.959|the decision makers in a constant
183.959|4.801|feedback loop and they're embodied in
186.239|4.681|this fully immersive world uh they're
188.76|4.96|also not mutually exclusive with the
190.92|5.92|passive kidney and in fact I see the
193.72|5.0|active embodiment part as a layer on top
196.84|4.6|of the passive Pro training from lots
198.72|6.439|and lots of internet
201.44|4.68|data so are we there yet have we
205.159|4.0|achieved
206.12|5.759|journalized you know back in 2016 I
209.159|4.201|remember was like spring of 2016 I was
211.879|3.201|sending an undergraduate class at
213.36|4.56|Columbia University but I wasn't paying
215.08|5.6|attention to the lecture I was watching
217.92|6.519|a board game tournament on my laptop and
220.68|6.759|this screenshot was the moment when
224.439|5.121|arago versus Lisa do and ARA go won
227.439|3.8|three matches out of five and became the
229.56|3.879|first ever to beat a human champion at
231.239|3.881|the game of Go you know I remember the
233.439|4.681|ad journaling that day right I've seeing
235.12|5.0|history unfold oh my God we are you know
238.12|3.8|finally getting to hii and everyone is
240.12|4.28|like so excited and I think that was the
241.92|5.72|moment when AI agents enter the
244.4|7.52|mainstream but you know like when the
247.64|7.439|Simon Fates I felt that even though ARA
251.92|4.999|go was so mighty and so great It could
255.079|5.321|only do one thing and one thing
256.919|6.041|alone right and afterwards you know in
260.4|4.6|2019 there were more impressive
262.96|4.64|achievements like open a five beating
265.0|5.72|the human Champions at the game of DOTA
267.6|5.879|and ARA star from Deep Mind be Starcraft
270.72|6.0|but all of these with arago they all
273.479|5.881|have a single kind of theme and that is
276.72|5.759|to be the opponent there is this one
279.36|7.399|objective that the agent needs to do and
282.479|6.56|the models trained on Dota or Go Cannot
286.759|4.44|generalize to any other tasks it cannot
289.039|4.6|even play other games like Super Mario
291.199|3.761|or Minecraft and the world is fixed and
293.639|4.921|have very little room for like
294.96|6.12|open-ended creativity and
298.56|4.96|exploration so I argue that a journalist
301.08|4.92|agent should have the following
303.52|5.08|essential properties first it should be
306.0|5.08|able to pursue very complex semantically
308.6|3.84|rich and open world objectives basically
311.08|3.52|you explain what you want in natural
312.44|4.52|language and the agent should perform
314.6|4.599|the actions for you in a dynamic world
316.96|4.959|and second the agent should have a large
319.199|5.28|amount of pre-trained knowledge instead
321.919|6.041|of knowing only a few Concepts that's
324.479|5.881|extremely specific to the task and third
327.96|4.799|massively multitask right A Generous
330.36|5.279|agent as the name implies needs to do
332.759|6.16|more than just a couple of things it
335.639|5.881|should be um in the best case infinitely
338.919|4.4|multitask as expressive as human
341.52|4.519|language can
343.319|5.32|dictate so what does it take
346.039|5.44|correspondingly we need three main
348.639|4.161|ingredients first is the environment
351.479|4.481|right the environment needs to be
352.8|5.76|open-ended enough because the agent's
355.96|4.079|capability is upper bounded by the
358.56|3.72|environment
360.039|4.121|complexity and I'd argue that Earth is
362.28|4.52|actually a perfect example because it's
364.16|4.68|so open-ended this world we live in that
366.8|4.2|it allows an algorithm called Natural
368.84|4.44|Evolution to produce all the diverse
371.0|4.599|forms and behaviors of Life on this
373.28|5.12|planet so can we have a simulator that
375.599|6.561|is essentially a Loi Earth but we can
378.4|6.04|still run it on the lab
382.16|4.439|clusters and second we need to provide
384.44|4.039|agent with massive pre-training data
386.599|5.0|because exploration in an open-ended
388.479|4.56|world from scratch is just intractable
391.599|4.44|and the data will serve at least two
393.039|5.241|purposes one as a reference manual on
396.039|4.121|how to do things and second as a
398.28|3.199|guidance on what are the interesting
400.16|4.439|things worth
401.479|5.72|pursuing and you know GPT is only at
404.599|5.16|least up to gbd4 it only learns from
407.199|5.321|Pure text on the web but can we provide
409.759|5.641|agent with much richer data such as
412.52|7.92|video walk through or like multimedia uh
415.4|7.799|Wiki documents uh and other media forms
420.44|5.039|and finally once we have the environment
423.199|5.12|and the database we are ready to train
425.479|5.28|Foundation models for the agents and it
428.319|4.6|should be flexible enough to pursue the
430.759|4.401|open-ended tasks without any task
432.919|5.28|specific assumptions and also scalable
435.16|5.8|enough to compress all of the multi
438.199|5.0|modal data that I just described and
440.96|5.519|here language I argue will play at least
443.199|6.201|two key roles one is as a simple
446.479|4.56|intutive interface to communicate a task
449.4|4.16|to communicate the human intentions to
451.039|4.6|the agent and second as a bridge to
453.56|3.319|ground all of the multimodal concepts
455.639|3.641|and
456.879|5.921|signals and that train of thought landed
459.28|5.0|Us in Minecraft the bestselling video
462.8|4.64|game of all
464.28|5.96|time and for those who are unfamiliar
467.44|4.96|Minecraft is a procedure generated 3D
470.24|4.079|voxo World and in the game you can
472.4|4.04|basically do whatever your heart
474.319|5.641|desires and what's so special about the
476.44|6.64|game is that unlike ARA go St Starcraft
479.96|6.079|or DOTA Minecraft defines no particular
483.08|4.799|objective to maximize no particular
486.039|4.0|opponent opponent to beat and doesn't
487.879|3.921|even have a fixed storyline and that
490.039|5.241|makes it very well suited as a truly
491.8|5.119|open-ended AI playground and here we see
495.28|4.56|people doing extremely impressive things
496.919|5.641|in Minecraft like this is a YouTube
499.84|7.16|video where a gamer built the entire
502.56|6.759|Hogwarts CLE block by block by hand in a
507.0|4.199|game and here's another example of some
509.319|4.2|one just digging a big hole in the
511.199|5.28|ground and then making this beautiful
513.519|5.4|underground temple with a river nearby
516.479|5.841|it's all crafted by
518.919|5.841|hand and one more this is someone
522.32|3.959|building a functioning CPU circuit
524.76|4.759|inside the game because there are
526.279|5.441|something called red stone in Minecraft
529.519|4.281|that you can build circuits out of it
531.72|4.04|like logical Gates and actually the game
533.8|4.52|is touring complete you can you know
535.76|4.84|simulate a computer inside the game just
538.32|4.36|think about how crazy that that is and
540.6|5.799|here I want to highlight a number that
542.68|6.48|is 140 million active players and just
546.399|5.641|to put this number in P perspective this
549.16|5.359|is more than twice the population of
552.04|4.44|UK and that is the amount of people
554.519|4.241|playing Minecraft on a daily
556.48|5.2|basis and you know it just so happens
558.76|6.56|that gamers are generally happier than
561.68|6.08|phds so they love to stream and share
565.32|4.12|what they're doing and that produces a
567.76|3.96|huge amount of data every every day
569.44|3.36|online and there's this Treasure Trove
571.72|3.64|of learning
572.8|4.44|materials um that we can tap into for
575.36|3.88|training journalist agents you know
577.24|3.2|remember the data is the key for
579.24|5.48|foundation
580.44|7.04|models so we introduce mind Dojo a new
584.72|5.0|open framework to help the community
587.48|5.919|develop generally capable agents using
589.72|3.679|Minecraft as a kind of primordial
594.12|5.24|soup mind Dojo features three major
596.48|5.56|parts an open ended environment and
599.36|4.32|internet skill knowledge base and then a
602.04|4.76|generous agent developed with a
603.68|4.159|simulator and massive data so let's zoom
606.8|3.64|in the first
607.839|4.721|one here's a sample gallery of the
610.44|3.68|interesting things that you can do with
612.56|4.279|mind dojo's
614.12|5.48|API we feature a massive benchmarking
616.839|6.0|Suite of more than 3,000 tasks and this
619.6|6.04|is by far the largest open- source Asian
622.839|4.68|Benchmark to our knowledge and we
625.64|3.879|Implement a very versatile API that
627.519|4.041|unlocks the full potential of the game
629.519|5.32|like for example mind Doo supports
631.56|6.24|multimodal observation um and a full
634.839|5.401|action space like moving or tag or
637.8|5.92|Inventory management and then it can be
640.24|6.48|customized at every detail like you can
643.72|5.359|tweak uh the terrains the weather block
646.72|4.72|placement monster spawning and just
649.079|4.921|anything you want to customize in the
651.44|6.199|game and given this simulator we
654.0|5.76|introduce around 1500 programmatic tasks
657.639|4.481|which are tasks that have ground true
659.76|4.639|success conditions defined in Python
662.12|4.0|code and you can also explicitly write
664.399|4.0|down like the spars or ADV reward
666.12|3.839|functions using this API and some
668.399|5.081|examples are like harvesting different
669.959|5.521|resources unlocking the tech tree uh or
673.48|4.359|fighting various monsters and getting
675.48|4.919|reward and all these tasks come with
677.839|5.201|language prompts that are
680.399|5.081|templated next we also introduced 1500
683.04|4.52|creative tasks that are free form and
685.48|5.08|open-ended and that is in contrast to
687.56|5.92|the programmatic task I just men
690.56|5.48|so for example let's say we want the
693.48|5.68|agent to build a house but what makes a
696.04|4.68|house a house right it is El defined and
699.16|4.96|just like image generation you don't
700.72|5.84|know if it generates a cat correctly or
704.12|4.6|not so it's very difficult to use Simple
706.56|5.8|python programs to give these kind of
708.72|5.559|task reward functions and uh the best
712.36|4.44|way is to use Foundation models train on
714.279|4.721|internet skill knowledge so that the
716.8|6.52|model itself understands abstract
719.0|6.639|Concepts like you know the concept of a
723.32|4.199|house and finally there's one task that
725.639|4.041|holds a very special status called play
727.519|5.081|through which is to beat the final boss
729.68|4.48|of Minecraft the Ender Dragon so
732.6|3.4|Minecraft doesn't force you to do this
734.16|3.799|task as we said it doesn't have a fixed
736.0|4.32|story line but it's still considered a
737.959|3.761|really big milestone for any kind of
740.32|4.0|beginner human
741.72|4.679|players um I want to highlight it is an
744.32|4.84|extremely difficult task that requires
746.399|5.281|very complex preparation exploration and
749.16|5.76|also martial skills and for an average
751.68|6.2|human it would take um many hours or
754.92|5.44|even days to solve easily over like one
757.88|4.199|million action steps in a single episode
760.36|3.52|and that would be the longest
762.079|4.721|benchmarking task for policy learning
763.88|5.759|ever created here so I I admit I am
766.8|5.36|personally a below average human I was
769.639|4.961|never able to beat Ender Dragon and my
772.16|6.799|friends laugh at me and I'm like okay
774.6|5.76|one day my AI will avenge my poor skills
778.959|3.361|right that was one of the motivations
780.36|4.64|for this
782.32|4.6|project now let's move on to the second
785.0|4.88|ingredient the internet skill knowledge
786.92|5.24|based part of my indal we offer three
789.88|5.16|data sets here the YouTube Wiki and
792.16|5.72|Reddit and combined they are the largest
795.04|4.72|open-ended agent Behavior database ever
797.88|5.399|compiled to our
799.76|5.439|knowledge the first is YouTube and we
803.279|4.521|already said Minecraft is one of the
805.199|5.521|most streamed games on YouTube and
807.8|5.92|Gamers love to R what they're doing so
810.72|4.76|we collected more than 700,000 videos
813.72|2.88|with two billion words in the
815.48|3.2|corresponding
816.6|4.84|transcripts and these transcripts will
818.68|5.32|help the agent learn about human
821.44|5.68|strategies and creativities without us
824.0|6.199|manually labeling
827.12|5.959|things and second the Minecraft player
830.199|6.681|base is so crazy that they have compiled
833.079|6.32|a huge Minecraft specific Wikipedia that
836.88|4.519|basically explains everything
839.399|4.841|you ever need to know in every version
841.399|5.641|of the game it's crazy and we script
844.24|5.36|7,000 wikip pages with inter leing
847.04|5.44|multimodal data like images tables and
849.6|4.72|diagrams and here are some screenshots
852.48|4.12|like this is a gallery of all of the
854.32|5.92|monsters and their corresponding
856.6|5.799|behaviors like spawn and attack patterns
860.24|4.399|and also like the thousands of crafting
862.399|4.481|recipes are all present on the wiki and
864.639|4.2|we scrip all of them and more like
866.88|4.48|complex diagrams and tables and embedded
868.839|5.081|figures now we have something like gbd4
871.36|4.479|V it may be able to understand many of
873.92|4.56|these
875.839|4.68|diagrams and finally the Minecraft
878.48|5.359|subreddit is one of the most active
880.519|5.081|forums across entire the entire Reddit
883.839|4.521|and players showcase their creations and
885.6|5.799|also ask questions for help so we scrap
888.36|5.96|more than 300,000 posts from Minecraft
891.399|5.36|reddit and here are some examples of how
894.32|5.04|people use the Reddit as a kind of stack
896.759|3.841|Overflow for Minecraft
899.36|3.52|and we can see that some of the top
900.6|4.56|voted answers are actually quite good
902.88|4.24|like someone is asking oh why doesn't my
905.16|3.44|weat form grow and the answer says you
907.12|4.48|need to light up the room with more
908.6|6.039|torches you don't have enough
911.6|5.359|lighting now given the massive task
914.639|5.76|suite and internet data we have the
916.959|6.56|essential components to build journalist
920.399|4.761|agents so in the first mind Doo paper we
923.519|4.481|introduce a foundation model called M
925.16|4.039|clip and the idea is very simple I can
928.0|3.199|explain
929.199|5.56|slides basically for our YouTube
931.199|5.921|database we have time aligned videos and
934.759|4.961|transcripts and these are actually the
937.12|5.24|real tutorial videos from our data set
939.72|4.52|you see on on on the third clip you know
942.36|4.12|as I raise my a in front of this pig
944.24|4.8|there's only one thing that you know is
946.48|5.599|going to happen this actually someone
949.04|6.44|said this a big YouTuber of
952.079|5.281|Minecraft and then given this data we
955.48|4.159|train M Clip In The Same Spirit as
957.36|5.44|opening a clip so for those who are
959.639|4.961|unfamiliar open clip is a contrastive
962.8|4.479|model that learns the association
964.6|4.84|between image and its caption and here
967.279|5.24|it's a very similar idea but this time
969.44|6.24|it is a video text contrasted model um
972.519|8.201|and we associate the text with a video
975.68|5.04|snippet that runs about 8 to 16 seconds
981.68|5.04|each and intuitively mcub learns the
984.959|4.36|association between the video and a
986.72|5.84|transcript that describes the activity
989.319|5.401|in the video and M clip outputs a score
992.56|3.839|between zero and one where one means a
994.72|4.08|perfect correlation between the text and
996.399|5.36|video and zero means the text is
998.8|5.92|irrelevant to the activity so you see
1001.759|6.241|this is effectively a language prompted
1004.72|6.08|Foundation reward model that knows the
1008.0|5.88|nuances of things like forests animal
1010.8|5.56|behaviors and architectures in
1013.88|5.439|Minecraft so how do we use mine Clip In
1016.36|5.32|Action here's an example of our agent
1019.319|4.961|interacting with the simulator and here
1021.68|5.96|the task is share sheep to obtain
1024.28|6.72|wall and as the agent explores in the
1027.64|6.48|simulator it generates a video snipping
1031.0|4.839|as a moving window which can be encoded
1034.12|4.12|and fed into mine Club along with an
1035.839|4.681|encoding of the text prompt
1038.24|4.559|here and mine Club computes the
1040.52|4.48|association right the higher the
1042.799|4.801|association is the more the agents's
1045.0|5.799|behavior in this video aligns with the
1047.6|4.8|language which is task you wanted to do
1050.799|3.801|and that becomes a reward function to
1052.4|5.6|any reinforcement learning
1054.6|6.4|algorithm so this looks very familiar
1058.0|5.36|right because it's essentially RL from
1061.0|4.08|Human feedback or
1063.36|4.439|RF in
1065.08|5.64|Minecraft and RF was the Cornerstone
1067.799|4.841|algorithm that made chbt possible and I
1070.72|4.12|believe it will play a critical role in
1072.64|4.6|journalist agents as
1074.84|4.36|well I'll quickly gloss over some
1077.24|4.4|quantitative results I promise there
1079.2|4.88|won't be like many tables of numbers
1081.64|5.36|here for these eight tasks we show the
1084.08|5.8|percentage success rate over 200 Test
1087.0|5.919|episodes and here in the green circle is
1089.88|4.88|two variants of our M clip method and in
1092.919|4.801|in the orange circles are the
1094.76|5.64|baselines so I'll highlight one Baseline
1097.72|5.04|which is that we construct a dense
1100.4|5.759|reward function manually for each task
1102.76|5.68|using the Mind Doo API it's a python API
1106.159|3.921|and you can consider this column as a
1108.44|3.4|kind of Oracle the upper bound of the
1110.08|3.32|performance because we put a lot of
1111.84|4.36|human efforts into designing these
1113.4|6.519|reward functions just for the
1116.2|5.64|tasks and we can see that mine clip is
1119.919|3.88|able to match the quality of many of
1121.84|4.6|these not all of them but many of these
1123.799|4.681|manual engineer rewards it is important
1126.44|4.719|to highlight that mine clip is open
1128.48|4.28|vocabulary so we use a single model for
1131.159|4.281|all of these tasks instead of one model
1132.76|5.76|for each and we simply prompt the reward
1135.44|5.56|model with different tasks and and
1138.52|2.48|that's the only
1142.24|2.88|variation one major feature of
1144.039|4.12|foundation model is strong
1145.12|5.799|generalization out the box so can our
1148.159|4.921|agent generalize to dramatic changes in
1150.919|4.441|the visual appearance so we did this
1153.08|6.88|experiment where during training we only
1155.36|7.439|train our agents on a default terrain at
1159.96|5.36|noon on sunny day but we tested zero
1162.799|4.24|chart in a diverse range of terrains
1165.32|4.0|weathers and day night cycles and you
1167.039|4.0|can customize everything in mind
1169.32|4.04|and in our paper we have numbers showing
1171.039|5.0|that mine Club significantly beat an
1173.36|4.48|off-the-shelf visual encoder when facing
1176.039|4.081|these kind of distribution shift out the
1177.84|3.52|box and this is no surprise right
1180.12|4.679|because mine clip was trained on
1181.36|4.88|hundreds of thousands of clips from uh
1184.799|4.201|Minecraft videos on
1186.24|4.2|YouTube which have a very good coverage
1189.0|3.799|of all the
1190.44|5.599|scenarios and I think that is just
1192.799|5.281|attestment to uh the big advantage of
1196.039|4.561|using internet skill data because you
1198.08|5.079|get robustness on the
1200.6|5.72|box and here are some demos of our learn
1203.159|4.721|agent behaviors on various tasks so you
1206.32|5.96|may notice that these T are relatively
1207.88|6.88|short around like 100 to 500 time steps
1212.28|5.16|and that is because M clip is not able
1214.76|5.32|to plan over very long time time
1217.44|4.04|Horizons and it is inherently it is an
1220.08|3.52|inherent limitation in the training
1221.48|4.319|pipeline because we could only use eight
1223.6|5.079|to 16 seconds of the video so it's
1225.799|5.041|constrained to like short actions but
1228.679|4.161|our hope is to build an asent that can
1230.84|4.04|explore and make new discoveries
1232.84|5.24|autonomously just all by itself and it
1234.88|5.64|keeps going and in 2022 this goal seems
1238.08|4.12|quite Out Of Reach For Us mind Dojo was
1240.52|4.159|June
1242.2|3.56|2022 and this year something happened
1244.679|4.401|and that is
1245.76|6.159|gp4 a language model that's so good at
1249.08|5.44|coding and long Horizon planning so we
1251.919|5.521|just cannot sit still right we build
1254.52|6.12|Voyager the first large language model
1257.44|5.88|powered life on learning agent and when
1260.64|5.039|we set Voyager lose in Minecraft we see
1263.32|4.92|that it just keeps going and by the way
1265.679|4.921|all these video Snippets are from a
1268.24|3.799|single episode of Voyer it's not from
1270.6|4.72|different different episodes It's a
1272.039|5.961|single one and we see that Voyager is
1275.32|4.56|just able to keep exploring the terrains
1278.0|4.559|mine all kinds of materials fight
1279.88|6.08|monsters craft hundreds of recipes and
1282.559|6.441|unlock an ever expanding tree of diverse
1285.96|5.48|skills so how how do we do
1289.0|4.64|this if we want to use the full power of
1291.44|5.4|gp4 a central question is how to
1293.64|5.56|stringify things converting this 3D
1296.84|5.719|world into a textual
1299.2|5.76|representation we need a magic box here
1302.559|4.801|and thankfully again the crazy Minecraft
1304.96|4.76|Community already built one for us and
1307.36|4.72|it's been around for many years it's
1309.72|4.88|called M flare a high level JavaScript
1312.08|5.24|API that's actively maintained to work
1314.6|5.84|with any Minecraft version and the
1317.32|5.479|beauty of M FL is it has access to the
1320.44|5.76|game States surrounding agent like the
1322.799|5.36|nearby blocks animals and enemies so we
1326.2|4.599|effectively have a ground truth
1328.159|5.161|perception module as textual input and
1330.799|6.521|at the same time mind fler also supports
1333.32|6.16|action apis that we can compose
1337.32|3.959|skills and now that we can convert
1339.48|5.319|everything to text we are ready to
1341.279|5.801|construct an agent on top of gb4 so on a
1344.799|4.921|high level there are three components
1347.08|5.24|one is a Cod module that writes
1349.72|4.48|JavaScript code to control the game bot
1352.32|4.599|and it's the main module that generates
1354.2|5.56|the executable actions and second we
1356.919|4.88|have a code base to store the correctly
1359.76|3.88|written code and look it up in the
1361.799|4.161|future if the agent needs to recall the
1363.64|4.24|skill and in this way we don't duplicate
1365.96|3.68|efforts and whenever facing similar
1367.88|4.96|situations in the future the agent knows
1369.64|5.68|what to do and third we have a
1372.84|4.52|curriculum that Pro proposes what to do
1375.32|3.8|next given the agent's current
1377.36|4.88|capability p and also
1379.12|5.84|situation and when you wire these
1382.24|4.679|components up together you get a loop
1384.96|3.92|that drives the agent in definitely and
1386.919|5.401|Achieve something like LIF La
1388.88|7.159|learning so let's zoom in the center
1392.32|5.88|module we prompt gd4 with documentations
1396.039|5.201|and examples on how to use a subset of
1398.2|5.04|the Mind flare API and uh gd4 Rights
1401.24|4.559|Code to take actions given the current
1403.24|4.76|assigned task and because JavaScript
1405.799|4.321|runs a coding interpreter gbd4 is able
1408.0|3.24|to Define functions on the Fly and run
1410.12|3.48|it
1411.24|3.64|interactively but the code that gb4 wres
1413.6|2.84|isn't always correct right just like
1414.88|4.12|human geners you can get everything
1416.44|4.88|correct on the first try so we developed
1419.0|5.039|an iterative prompting mechanism to
1421.32|4.959|refine the program and there are three
1424.039|4.081|types of feedback here the environment
1426.279|4.361|feedback like you know what are the new
1428.12|5.24|materials you got after taking an action
1430.64|4.399|or you know some enemies nearby and the
1433.36|4.199|execution error from the JavaScript
1435.039|4.76|interpreter if you wrote some buggy code
1437.559|5.401|like undefined variable for example if
1439.799|6.401|it hallucinates something um and another
1442.96|5.44|gb4 that provides critique through
1446.2|4.52|self-reflection from the Asian State and
1448.4|4.159|the world State and that also helps
1450.72|3.839|refine the program
1452.559|4.081|effectively so I want to show some quick
1454.559|5.24|example of how the critic provides
1456.64|4.76|feedback on the task completion progress
1459.799|4.801|so let's say in the first example the
1461.4|5.56|task is to craft a spy glass and Jud for
1464.6|4.36|looks at the agent's inventory and
1466.96|4.52|decides that it has enough copper but
1468.96|4.719|not enough Amhurst as a
1471.48|4.76|material and the second task is to kill
1473.679|4.961|three sheeps to collect food and each
1476.24|4.64|ship drops one unit of wool but there
1478.64|4.48|are only two units in inventory so you
1480.88|5.24|for reasons and says that okay you have
1483.12|5.88|one more ship to go and
1486.12|5.52|likewise now moving on to the second
1489.0|5.559|part once Voyer implements a skill
1491.64|5.399|correctly we save it to a persistent
1494.559|4.921|storage and you can think of the skill
1497.039|4.481|Library as a code repository written
1499.48|5.919|entirely by a language model through
1501.52|5.96|interaction with a 3D world and the
1505.399|4.121|agent can record new skills and also
1507.48|4.6|retrieve skills from the library facing
1509.52|3.92|similar situations in the future so it
1512.08|2.88|doesn't have to go through this whole
1513.44|3.64|program refinement that we just saw
1514.96|5.599|again which is quite inefficient but you
1517.08|6.16|do it once you save it to to disk and in
1520.559|5.321|this way Voyager kind of bootstraps its
1523.24|5.439|own capabilities recursively as it
1525.88|4.96|explores and experiments in the
1528.679|4.041|game and let's dive a little bit deeper
1530.84|4.24|into how the skill library is
1532.72|5.8|implemented so this is how we insert a
1535.08|5.68|new skill first we use gbd 3.5 to
1538.52|4.159|summarize the program into plain English
1540.76|4.159|and summarization is very easy and gbd4
1542.679|5.6|is expensive so we just you know go for
1544.919|6.441|a cheaper a cheaper tier um and then we
1548.279|4.76|embed this summary as the key and we
1551.36|4.439|save the program which is a bunch of
1553.039|5.201|code as the value and we find that doing
1555.799|4.641|this makes retrieval better because the
1558.24|6.799|summary is more semantic and the code is
1560.44|4.599|a bit more discrete and and you insert
1565.76|5.24|it and now for the retrieval process
1569.159|4.481|when voyag is faced with a new task
1571.0|5.679|let's say craft iron pickaxe we again
1573.64|4.919|use GB 3.5 to generate a hint on how to
1576.679|4.12|solve the task and that is something
1578.559|5.521|like a natural language paragraph and
1580.799|6.041|then we embed that and use that as the
1584.08|4.12|query into the vector database and we
1586.84|4.439|retrieve the scill
1588.2|5.079|from from the library so you can think
1591.279|5.481|of it as a kind of in context replay
1593.279|5.681|buffer in the reinforcement learning
1596.76|3.399|literature and now moving on to the
1598.96|4.199|third
1600.159|5.441|part we have another gb4 that proposes
1603.159|5.201|what task to do given its own
1605.6|5.16|capabilities at the moment and here we
1608.36|5.0|give gbd4 a very high level kind of
1610.76|5.519|unsupervised objective that is to obtain
1613.36|5.28|as many unique items as possible that is
1616.279|5.4|our high level directives and then gb4
1618.64|5.56|takes this directive and implements um a
1621.679|4.401|curriculum of progressively harder
1624.2|5.719|challenges and more novel challenges to
1626.08|6.199|solve so it's kind of like curiosity
1629.919|4.721|exploration where um it is called
1632.279|5.0|novelty search in a prior literature but
1634.64|4.039|implement it purely in context yeah if
1637.279|3.441|you're listening to zoom the next
1638.679|4.6|example is
1640.72|4.959|fun let's let's go through this example
1643.279|4.52|together right um just to kind of show
1645.679|5.12|you how how voy works the the whole
1647.799|5.88|complicated data flow that I just show
1650.799|5.081|so the Asian finds itself hungry um it
1653.679|4.401|only has one out of 20 hunger bar so it
1655.88|5.76|knows gb4 knows that it needs to find
1658.08|6.599|food ASAP and then it senses there are
1661.64|5.639|four entities nearby a cat a villager a
1664.679|4.801|pig and some wheat seeds and now gb4
1667.279|3.961|starts a self-reflection right like do I
1669.48|4.96|kill the cat and villager to get some
1671.24|5.36|meat that sounds horrible um how about
1674.44|4.0|the wheat seeds um I can use the seeds
1676.6|3.88|to grow a farm but that's going to take
1678.44|5.0|a very long time until I can generate
1680.48|6.679|some food so sorry piggy you are the one
1683.44|6.0|being chosen so gb4 looks at the
1687.159|5.12|inventory which is the agent State there
1689.44|5.56|is a piece of iron in inventory so it
1692.279|5.561|recalls voy recalls a skill from the
1695.0|4.72|library that is to craft an iron sword
1697.84|4.4|and then use that skill to start
1699.72|5.28|pursuing to start learning a new skill
1702.24|6.76|and that is hunt Pig and once the hunt
1705.0|5.84|Pig uh routine is successful GT4 saves
1709.0|3.159|it to the skill Library that's roughly
1710.84|3.559|how it
1712.159|4.0|works yeah and putting all these
1714.399|4.28|together we have this it prompting
1716.159|5.921|mechanism the scale library and an
1718.679|6.041|automatic curriculum and all of these
1722.08|4.479|combined is voyages no gradient
1724.72|4.959|architecture where we don't train any
1726.559|6.201|new models or fine tune any parameters
1729.679|5.521|and allows allows voer to self bootstrap
1732.76|4.08|on top of gb4 even though we are
1735.2|4.199|treating the underlying language model
1736.84|2.559|as a black box
1740.559|4.72|it looks like my my example work and
1742.24|5.6|they started to started to
1745.279|5.481|listen
1747.84|5.079|yeah so yeah these are the tasks that
1750.76|4.639|Voyager picked up along the way and we
1752.919|4.76|didn't program any of these it's all vo
1755.399|4.601|just idea the agent is kind of forever
1757.679|4.88|curious and also forever pursuing new
1760.0|5.6|adventures just by
1762.559|6.281|itself um so to quickly show some
1765.6|6.12|quantitative results here we have a
1768.84|5.0|learning curve where the xaxis is the
1771.72|4.559|number of prompting iterations and the Y
1773.84|5.6|AIS is the number of unique items that
1776.279|6.441|Voyager discovered as it's exploring in
1779.44|7.2|environment and uh these two curves are
1782.72|6.64|baselines react and
1786.64|4.639|reflexion and this is autog gbt which is
1789.36|4.52|like a popular software repo basically
1791.279|4.681|you can think of it as combining react
1793.88|5.159|and a task planner that decomposes an
1795.96|5.839|objective into sub goals and this is
1799.039|5.681|Voyager we're able to obtain three times
1801.799|4.72|more novel items than the prior methods
1804.72|5.799|and also unlock the entire Tech Tree
1806.519|5.681|significantly faster um and if you take
1810.519|3.601|away the skill Library you see that
1812.2|4.52|voice really suffers the the performance
1814.12|4.559|takes a hit because every time it needs
1816.72|3.92|to kind of repeat and relearn every
1818.679|4.521|skill from scratch and it starts to make
1820.64|5.12|a lot more mistakes and that really
1823.2|5.04|degrades the
1825.76|5.279|exploration here these two are the bird
1828.24|5.76|eyye views uh of the Minecraft map and
1831.039|5.961|these circles are what the prior methods
1834.0|5.64|are able to explore given the same
1837.0|4.32|prompting iteration budget and we see
1839.64|5.279|that they tend to get stuck in local
1841.32|5.12|areas and kind of fail to explore more
1844.919|5.721|but the Voyager is able to navigate
1846.44|7.16|distances at least two times as much as
1850.64|6.639|the PRI works so it's able to visit a
1853.6|5.559|lot more places because to satisfy this
1857.279|3.721|high level directive of obtaining as
1859.159|4.281|many unique items as possible You' got
1861.0|3.799|to travel right if you stay at one place
1863.44|4.839|you will quickly exhaust interesting
1864.799|6.0|things to do and voy travels a lot so
1868.279|6.0|that's how we came up with the
1870.799|5.641|name so finally um one limitation is
1874.279|4.561|that Voyager does not currently support
1876.44|5.239|visual perception because the gd4 that
1878.84|4.679|we used back then was text only but
1881.679|4.641|there's nothing stopping Voyer from
1883.519|4.601|adopting like multimodal language models
1886.32|4.12|in the future so here we have a little
1888.12|4.72|proof of concept demo where we ask a
1890.44|5.0|human to basically function as the image
1892.84|4.88|captioner and the human will tell
1895.44|4.16|Voyager that as you're building these
1897.72|4.52|houses what are the things that missing
1899.6|5.4|like you you place a door incorrectly uh
1902.24|4.399|like the roof is also not done correctly
1905.0|5.639|so the human is acting as a Critic
1906.639|6.241|module of the voer stack and we see that
1910.639|5.0|with some of that help Voyer is able to
1912.88|4.24|build a farmhouse and a nether portal
1915.639|3.92|but it has a hard time understanding
1917.12|6.24|sending you know 3D spatial coordinates
1919.559|3.801|just by itself in a textual
1923.96|6.439|domain now after doing voer we're
1927.84|5.28|considering like where else can we apply
1930.399|5.64|this idea right of coding in embod
1933.12|5.96|environment observe the feedback and
1936.039|6.321|iteratively refine the program so we
1939.08|5.92|came to realize that physics simulations
1942.36|4.4|themselves are also just python code so
1945.0|5.399|why not apply some of the principles
1946.76|5.919|from voer and do something in another
1950.399|5.0|domain what if you apply Voyager in the
1952.679|5.96|space of this physics simulator API and
1955.399|5.321|this is urea which uh my team announced
1958.639|5.681|just like three days ago freshh out of
1960.72|5.959|the oven it is an open-ended agent that
1964.32|5.4|designs reward functions for robot
1966.679|5.081|dexterity at superh human level and it
1969.72|5.36|turns out that GT4 plus reinforcement
1971.76|6.08|learning can spin a pen much better than
1975.08|7.479|I do I gave up on the this task a long
1977.84|8.28|time ago from childhood it's so hard for
1982.559|6.761|me so urea idea is very simple and
1986.12|5.12|intuitive gbd4 generates a bunch of
1989.32|4.079|possible reward function candidates
1991.24|4.799|implementing in Python and then you just
1993.399|4.321|do a full reinforcement uh reinforcement
1996.039|4.321|learning training Loop for each
1997.72|5.0|candidate in a GPU accelerated
2000.36|4.88|simulator and you get a performance
2002.72|5.48|metric and you take the best candidates
2005.24|5.88|and feedback to gb4 and it samples the
2008.2|4.719|next proposals of candidates and keeps
2011.12|4.64|improving the whole population of the
2012.919|4.281|reward functions that's a whole idea
2015.76|3.48|it's kind of like an in context
2017.2|4.24|evolutionary
2019.24|5.48|search so here's the initial reward
2021.44|6.28|generation where urea takes as context
2024.72|6.76|the environment code of nvidia's ISAC
2027.72|5.76|Sim and a task description and samples
2031.48|4.0|the initial reward function
2033.48|3.84|implementation so we found that the
2035.48|3.76|simulator code itself is actually very
2037.32|4.04|good reference manual because it tells
2039.24|4.799|you Raa what are the variables you can
2041.36|4.4|use uh like you know the hand positions
2044.039|3.921|like here the fingertip position the
2045.76|5.28|finger TP State the rotation angular
2047.96|5.56|velocity Etc so you know all of these
2051.04|4.639|variables from the simulator code and
2053.52|5.48|you know how they interact with each
2055.679|6.72|other so that serves as a very good uh
2059.0|4.76|like in context instruction so urea
2062.399|3.2|doesn't need to reference Any Human
2063.76|4.159|return reward
2065.599|4.56|functions and then once you have the
2067.919|3.92|generated reward you plug it into any
2070.159|4.841|reinforcement learning algorithm and
2071.839|6.0|just train it to completion so this step
2075.0|4.159|is typically very costly and very slow
2077.839|3.76|because reinforcement larning itself is
2079.159|6.52|slow and we were only able to scale up
2081.599|7.0|urea because of nvdi section which runs
2085.679|5.281|a thousand simulated environment copies
2088.599|5.601|on a single GPU so basically you can
2090.96|4.919|think of it as speeding up Reality by a
2094.2|4.56|thousand
2095.879|4.96|a and then after training you will get
2098.76|5.48|the performance metrics back on each
2100.839|6.441|reward component and as we on Voyager
2104.24|8.2|gbd4 is very good at self-reflection so
2107.28|5.16|we leverage that capability and
2112.48|5.359|uh there's a software trial reminding
2115.56|5.32|you to activate the
2117.839|7.681|license yeah so uh Voyager reflects on
2120.88|7.92|it and then uh proposes mutations on the
2125.52|5.16|code so here the mutations uh we found
2128.8|3.44|can be very diverse ranging from
2130.68|3.439|something as simple as just changing a
2132.24|4.48|hyperparameter in the reward function
2134.119|4.681|waiting to all the way to adding
2136.72|3.359|completely novel components to the
2138.8|4.96|reward
2140.079|6.361|function and in our experiments urea
2143.76|4.96|turns out to be a superhuman reward
2146.44|4.84|engineer actually outperforming some of
2148.72|7.08|the functions implemented by the expert
2151.28|7.48|human Engineers on Nvidia i6m
2155.8|5.039|team so here are some more demos of how
2158.76|5.4|urea is able to write very complex
2160.839|5.76|rewards that lead to these extremely Dex
2164.16|5.439|dexterous behaviors and we can actually
2166.599|4.881|train the robot hand to rotate pens not
2169.599|4.841|just you know in One Direction but in
2171.48|5.4|different directions along different 3D
2174.44|5.52|axis I think one major contribution of
2176.88|5.68|urea different from Voyager is to bridge
2179.96|6.119|the gap between high level reasoning and
2182.56|6.4|lowlevel mod controls so urea introduces
2186.079|5.28|a new paradig that I'm calling hybrid
2188.96|4.0|gradient architecture so recall Voyer is
2191.359|3.521|a no gradient architecture we don't
2192.96|4.68|touch anything and we don't train
2194.88|5.239|anything but urea is a hybrid gradient
2197.64|5.28|where a black box influence only
2200.119|5.361|language Model instructs A white box
2202.92|5.159|learnable neuron Network so you can
2205.48|5.4|think of it as two Loops right the alter
2208.079|5.04|Loop is great and free and it was it's
2210.88|4.28|driven by gd4 kind of selecting the
2213.119|4.401|reward functions and the inner loop is
2215.16|4.439|grade and based you train like a full
2217.52|5.16|reinforcement learning episode from it
2219.599|5.0|to achieve extreme dexterity using a
2222.68|4.52|specialized like training by training a
2224.599|4.921|special neuron network controller and
2227.2|4.68|you must have both Loops to succeed to
2229.52|4.64|deliver this kind of dexterity and I
2231.88|6.0|think it will be a very useful Paradigm
2234.16|6.76|for training robot agents in the
2237.88|7.199|future so you know these days when I go
2240.92|8.199|on Twitter or X I see AI conquering new
2245.079|5.881|LS like every we you know chat image
2249.119|5.521|generation and music they're all very
2250.96|5.76|well within reach but mind Dojo voy and
2254.64|4.88|urea these are just scratch on the
2256.72|5.28|surface of open-ended journalist
2259.52|5.559|agents and looking forward I want to
2262.0|5.92|share two key research directions that I
2265.079|5.481|personally find extremely promising and
2267.92|5.0|I'm also working on it myself the first
2270.56|5.279|is a continuation of Mind Club basically
2272.92|4.84|how to develop methods that learn from
2275.839|4.681|internet skill video videos and the
2277.76|6.0|second is multimodal foundation models
2280.52|5.96|now that gp4 V is coming but it is just
2283.76|4.44|the beginning of an era and I think it's
2286.48|5.16|important to have all all of the
2288.2|5.72|modalities in a single Foundation
2291.64|4.679|model so first about
2293.92|5.199|videos we all know that videos are
2296.319|5.841|abundant right like so many data on
2299.119|4.24|YouTube way too many for our limited
2302.16|4.48|gpus to
2303.359|5.921|process they're extremely useful to try
2306.64|4.6|models that not only have Dynamic
2309.28|4.4|perception and intuitive physics but
2311.24|5.52|also capture the complexity of human
2313.68|4.8|creativity and human behaviors it's all
2316.76|4.359|good except
2318.48|4.56|that when you are using video to
2321.119|4.081|pre-rain the embodied agents there is
2323.04|4.12|huge distribution shift you also don't
2325.2|3.36|get action labels and you don't get any
2327.16|2.84|of the groundings because you're a
2328.56|3.24|passive
2330.0|3.4|Observer so I think here is a
2331.8|3.72|demonstration of why learning from video
2333.4|5.4|is hard even for natural
2335.52|6.36|intelligence so little cat is seeing
2338.8|5.0|boxers shaking their head and it thinks
2341.88|4.08|maybe shaking head is the best way to to
2343.8|2.16|do
2346.56|5.36|fighting right this is why learning from
2349.44|2.48|video is
2352.16|5.0|hard you have you have you have no idea
2355.119|4.361|like
2357.16|4.28|why this is too good let's let's play
2359.48|3.879|this again you have you have no idea why
2361.44|4.6|Tyson is doing this right like the cat
2363.359|6.361|has no idea and then it Associates this
2366.04|6.48|with just wrong wrong kind of
2369.72|4.0|policy but for sure it you know it
2372.52|4.52|doesn't help the fighting but it
2373.72|3.32|definitely boosts the cat's
2378.04|3.4|confidence that's why learning from
2379.76|4.319|video is
2381.44|4.679|hard now I want to point out a few kind
2384.079|5.04|of latest research in how to leverage so
2386.119|5.361|much video for journalist agents um
2389.119|4.801|there are a couple of approaches the
2391.48|4.359|first is the simplest just learn kind of
2393.92|3.0|a visual feature extractor from the
2395.839|3.681|videos
2396.92|5.12|so this is r3m uh from Chelsea's group
2399.52|4.48|at Stanford uh and this model is still
2402.04|4.24|an image level representation just that
2404.0|4.48|it uses a video level loss function to
2406.28|4.64|train um more specifically time
2408.48|5.44|contrasted learning and after that you
2410.92|5.0|can use this as um an image backbook for
2413.92|4.48|any agent but you still need to kind of
2415.92|4.04|find tune uh using domain specific data
2418.4|4.52|for the
2419.96|6.48|agent the second path is to learn reward
2422.92|7.08|functions from video and M clip is uh
2426.44|5.12|one model under this category it uses a
2430.0|4.52|contrastive objective between the
2431.56|5.96|transcri and video and here this work
2434.52|5.68|VIP is another way to learn a similarity
2437.52|5.559|based reward for goal condition tasks in
2440.2|5.56|the image space so this work VIP is led
2443.079|4.961|by who's also the first author of urea
2445.76|3.599|and uh urea is his internship project
2448.04|3.48|with
2449.359|5.281|me and the third idea is very
2451.52|5.839|interesting can we directly do imitation
2454.64|6.16|learning from video but better than the
2457.359|5.081|cat right that that we just saw so we
2460.8|4.559|just said you know the videos don't have
2462.44|5.52|the actions right we need to find some
2465.359|5.361|ways to Pudo label the actions and this
2467.96|5.8|is video training of vpt from open AI
2470.72|6.44|last year to solve longrange task in
2473.76|5.599|Minecraft and here the the pipeline
2477.16|5.4|works like this basically you use a
2479.359|5.161|keyboard and a mouse action space so you
2482.56|5.72|can align this action space with the
2484.52|5.839|human actions and open air hires a bunch
2488.28|4.52|of Minecraft players and actually
2490.359|4.96|collect data in house so they record the
2492.8|5.16|episodes done by those Gamers and now
2495.319|5.201|you have a data set of image of video
2497.96|3.96|and action pairs right and you train
2500.52|4.76|something called an inverse Dynamics
2501.92|5.8|model which is to take the observation
2505.28|4.24|and then predict the actions that caused
2507.72|4.56|the observation to change so that's
2509.52|3.52|inverse Dynamics model and that becomes
2512.28|4.12|a
2513.04|5.24|labeler that you can apply to IND the
2516.4|5.76|wild YouTube videos that don't have the
2518.28|6.12|actions so you applied IDM to like 70k
2522.16|4.12|hours of in the wild YouTube videos and
2524.4|4.24|you will get these pseudo actions that
2526.28|4.799|are not always correct but also way
2528.64|4.12|better than random and then you train
2531.079|4.841|imitation learning on top of this
2532.76|5.96|augmented data set and in this way opena
2535.92|5.639|is able to greatly expand uh the data
2538.72|4.92|because the original uh data collected
2541.559|4.081|from the humans are high quality but
2543.64|3.88|they're extremely expensive while in the
2545.64|3.679|wild YouTube videos are very cheap but
2547.52|4.24|you don't have the options so they kind
2549.319|4.401|of solved um and got the best of those
2551.76|4.92|RS but still you know it's really
2553.72|2.96|expensive to hide these
2556.76|5.68|humans now what's beyond videos right
2560.4|4.88|I'm a firm believer that multimodal
2562.44|5.08|models will be the future and I see Tex
2565.28|4.6|as a very lossy kind of ond projection
2567.52|5.039|of our physical world so it's essential
2569.88|5.679|to include the other sensory modalities
2572.559|5.081|to provide a full inod experience and in
2575.559|4.52|the context of of embodied agents I
2577.64|4.8|think the input will be a mixture of
2580.079|5.601|text images videos and even audio in the
2582.44|6.8|future and the output will be
2585.68|6.12|actions so here's a very early example
2589.24|5.0|of a multimodal language model for robot
2591.8|5.319|learning so let's imagine a household
2594.24|5.28|robot we can ask a robot to bring us a
2597.119|4.881|cup of tea from the kitchen but if we
2599.52|4.4|want to be more specific I want this
2602.0|5.04|particular cup that is my favorite cup
2603.92|6.72|so show me this image and we also
2607.04|5.64|provide a video demo of how we want to
2610.64|4.679|mop the floor and ask the robot to
2612.68|4.56|imitate the similar Motion in
2615.319|4.0|context and when a robot sees an
2617.24|4.0|unfamiliar object like a sweeper we can
2619.319|4.0|explain it by providing an image and
2621.24|4.48|showing this is a sweeper now you know
2623.319|4.561|go ahead and do something with the tool
2625.72|3.56|and finally to ensure safety we can say
2627.88|2.679|take a picture of that room and just do
2629.28|5.88|not enter that
2630.559|7.04|room to achieve this um back last year
2635.16|4.919|we proposed a model called Vima which
2637.599|4.041|stands for visual motor attention and in
2640.079|4.48|this work we introduce a concept called
2641.64|5.6|multimodal prompting where the prompt
2644.559|4.8|can be a mixture of the text image and
2647.24|5.16|videos and this provides a very
2649.359|5.48|expressive API that just unifies a bunch
2652.4|4.84|of different robot tasks that otherwise
2654.839|4.881|would require a very different pipeline
2657.24|6.4|or specialized models to solve in Prior
2659.72|6.68|literature and VMA simply tokenizes
2663.64|5.0|everything uh converting image and text
2666.4|4.84|into sequences of tokens and train a
2668.64|5.8|Transformer on top to Output the robot
2671.24|5.2|arm actions autor regressively one step
2674.44|4.84|at a time during inference
2676.44|5.76|time so just to look at some of the uh
2679.28|4.76|examples here like this prompt rearrange
2682.2|3.04|objects to match the scene it is a
2684.04|3.2|classical task called visual goal
2685.24|6.52|reaching that has a big body of Prior
2687.24|7.44|works on it and uh that's how our robot
2691.76|5.12|does it given this prompt and we can
2694.68|4.919|also give it uh novel Concepts in
2696.88|5.28|context like this is a bliet this is a w
2699.599|4.641|now put a w into a bid and both words
2702.16|3.88|are nonsensical so it's not in the
2704.24|4.44|training data but VMA is able to
2706.04|6.079|generalize zero shot and follow the
2708.68|5.08|motion to manipulate this object so the
2712.119|3.96|bot understands what we want and then
2713.76|4.599|follow this trajectory and finally we
2716.079|4.04|can give it more complex prompt like you
2718.359|3.921|know these are the safety constraints
2720.119|4.921|sweep the box into this but without
2722.28|7.24|exceeding that line and uh we we do this
2725.04|6.68|using the inter leaving image and text
2729.52|6.12|tokens and recently Google brain
2731.72|7.28|robotics follow up after VMA with rt1
2735.64|5.959|and rt2 robot Transformer one and two uh
2739.0|4.68|and rt2 is using a similar recipe as uh
2741.599|5.161|I described where they first kind of
2743.68|5.12|pre-train uh on internet scale data and
2746.76|4.88|then fine-tune with some human collected
2748.8|4.48|demonstrations on the Google robots and
2751.64|3.76|Robocat from Deep line is another
2753.28|6.48|interesting work and they train a single
2755.4|6.64|Unified policy that works not just on a
2759.76|4.079|single robot but actually across
2762.04|4.319|different embodiments different robot
2763.839|4.48|forms and even generalize to a new
2766.359|4.401|hardware so I think this is like a
2768.319|4.841|higher form of multimodal agent where
2770.76|5.72|the physical form factor the morphology
2773.16|6.24|of the agent itself is another
2776.48|4.48|modality so that concludes our looking
2779.4|4.52|forward uh
2780.96|5.159|section and lastly I want to kind of
2783.92|5.32|just put all links together of the works
2786.119|5.681|I describe so this is mind do.org we
2789.24|4.839|have U open source everything well for
2791.8|4.88|all the projects where big fans are open
2794.079|4.961|source we open source as much as we can
2796.68|5.8|including like the model code
2799.04|4.64|checkpoints um simulator code and
2802.48|5.359|training
2803.68|5.04|data and this is Voyager mind.org this
2807.839|4.561|is
2808.72|7.16|urea and this is
2812.4|5.48|Vima and one more thing right if you
2815.88|4.439|just want an excuse to play Minecraft at
2817.88|4.0|work that mind do is perfect for you
2820.319|4.121|because you are collecting human
2821.88|4.04|demonstration to train jous asent and if
2824.44|4.56|there's one thing that you take away
2825.92|5.399|from this talk it should be this
2829.0|4.4|slide and lastly I I just want to remind
2831.319|4.481|all of us you know despite all the
2833.4|5.56|progress I've shown right what we can do
2835.8|5.72|is still very far from Human Ingenuity
2838.96|5.44|as embodied agents you know these are
2841.52|5.48|the videos from our data set of people
2844.4|4.6|doing like decorating Winter Wonderland
2847.0|4.359|or building the functioning CPU circuit
2849.0|5.319|within Minecraft and we are very far
2851.359|5.321|from that as AI research so here's a
2854.319|5.0|call to the community if human can do
2856.68|6.52|these mind-blowing tasks then why not
2859.319|3.881|our AI right let's find out
2866.359|3.0|together