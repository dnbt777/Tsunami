start_time|end_time|text
4.88|4.0|today erwin and i are going to be
6.799|3.361|giving a talk on scaling transformers
8.88|2.4|through sparsity
10.16|3.12|and the kind of sparsity we're going to
11.28|4.08|be talking about today is the kind where
13.28|3.839|you know each input can get you know
15.36|3.28|either a different set of weights or
17.119|2.801|have a different amount of computation
18.64|3.6|applied to it
19.92|4.48|or do you want to start it off
22.24|3.119|yeah
24.4|2.879|so
25.359|5.201|i guess the overall motivation for this
27.279|4.561|line of work is that um
30.56|4.08|you know the community has kind of
31.84|4.719|realized that scale uh is perhaps one of
34.64|4.16|the most important access to
36.559|4.481|to focus on for obtaining strong
38.8|3.2|performance and there's almost like this
41.04|3.519|sort of
42.0|3.68|ongoing arms race right now with
44.559|3.121|different labs and different
45.68|3.28|institutions um
47.68|2.559|sort of competing for training the
48.96|4.239|largest
50.239|5.441|uh uh you know models
53.199|6.241|and so uh maybe this dates back from
55.68|4.96|early uh 2020 with a paper from open ai
59.44|4.16|called
60.64|6.479|scaling laws for neural language models
63.6|5.6|where they find that model performance
67.119|3.841|follows the predictable
69.2|3.84|overall
70.96|3.44|scale sort of as a parallel with uh
73.04|3.28|model size
74.4|4.16|in terms of either
76.32|3.2|compute or also just uh
78.56|3.28|you know
79.52|5.04|uh parameters
81.84|4.56|and so this uh this scaling law kind of
84.56|3.04|generalizes over multiple orders of
86.4|2.48|magnitude
87.6|3.28|and you know that gives us the
88.88|3.279|confidence that if we are to train very
90.88|3.599|large models
92.159|4.401|uh you know we can expect you know
94.479|4.241|certain performance uh just by
96.56|4.239|extrapolating extrapolating these uh
98.72|4.64|scaling laws
100.799|3.6|so in that paper they also
103.36|3.36|find
104.399|4.481|the interesting
106.72|4.079|observation that
108.88|3.04|basically larger models are more sample
110.799|2.881|efficient
111.92|3.36|and so you know if you have a fixed
113.68|3.2|compute budget
115.28|3.76|uh
116.88|4.879|you can sort of
119.04|4.88|you know you you can predict what what
121.759|4.32|is the size what is the optimal model
123.92|3.44|size or fixed compute budget
126.079|4.001|and um
127.36|5.36|the the overall observation is that
130.08|3.92|uh you know you you'd rather train very
132.72|3.92|large models
134.0|5.36|from for less tests and train smaller
136.64|6.0|models for more training steps
139.36|3.97|and so these models are scaled um
142.64|1.92|you know through
143.33|3.549|[Music]
144.56|4.399|basically those so the paper focuses on
146.879|4.161|dance models right where you just
148.959|5.28|increase the model dimensions
151.04|4.08|um but they're not looking at sparsely
154.239|1.601|and so
155.12|2.64|is
155.84|3.52|is a new dimension that you can use to
157.76|5.119|scale architectures
159.36|3.519|um you know and this is sort of the
163.04|4.16|the focus of the talk
164.959|4.081|and so the sparsity we are where we're
167.2|4.319|mentioning here is basically you will
169.04|5.12|have
171.519|5.761|sparsely activated weights
174.16|4.719|based on the network inputs so every
177.28|4.239|input will go to
178.879|6.72|a roughly similar amount of computation
181.519|8.561|but will be applied different weights
185.599|6.801|and so this dates back to 1991 with a
190.08|3.68|paper called adaptive mixtures of local
192.4|3.52|experts
193.76|4.08|and was recently revisited
195.92|3.92|by noam chazier and colleagues at google
197.84|3.6|brain
199.84|3.92|with lstms
201.44|4.799|where they replaced so sort of the feed
203.76|2.479|forward
207.12|3.36|networks in lstms with mixture of
209.2|3.2|experts
210.48|3.2|and so the way this works there roughly
212.4|3.52|is that
213.68|3.6|you will have multiple experts each
215.92|3.92|implementing
217.28|4.8|you know a small network or in that case
219.84|5.36|i think just a
222.08|5.439|dense matrix multiplication
225.2|4.08|um and so you have an additional getting
227.519|3.841|network um
229.28|3.28|shown in green here
231.36|3.76|that
232.56|4.08|uh outputs a probability distribution of
235.12|4.16|our
236.64|5.2|experts that each token should be sent
239.28|2.56|to
241.92|4.64|so this probably distribution is
244.0|4.239|computed as a softmax
246.56|5.039|and once you have it
248.239|4.241|you select a few experts
251.599|2.64|so
252.48|3.68|there are different strategies maybe
254.239|3.84|we'll talk about it later on and the
256.16|6.56|output is simply sort of the weighted
258.079|4.641|mixture of all selected xbox outputs
265.04|2.86|so that they've been pretty uh
266.96|2.239|successful in
267.9|3.62|[Music]
269.199|3.761|primarily in
271.52|4.48|translation
272.96|4.48|but there was some you know
276.0|3.44|you know some
277.44|4.16|complexities that another
279.44|5.28|brother used in nlp
281.6|5.44|and so the switch transformer paper um
284.72|3.6|addresses uh some of those and we will
287.04|2.32|be discussing
288.32|3.12|how to
289.36|3.839|you know how to
291.44|3.68|fix training disabilities or reduce
293.199|5.681|communication costs and
295.12|3.76|and uh reduce my complexity
298.96|4.16|all right barry you want to go
300.88|4.159|sure yeah so yeah so one kind of
303.12|4.24|approach that we're gonna have uh for
305.039|3.921|sparsity is the uh switch transformer
307.36|4.0|which is kind of like a
308.96|4.16|simplified mixture of expert variant
311.36|3.44|along with some other improved you know
313.12|3.44|training and fine-tuning techniques that
314.8|4.0|allow it to you know
316.56|3.76|be stably trained and also you know
318.8|3.6|perform better when fine-tuned done a
320.32|4.4|lot of downstream tasks
322.4|4.96|and so yeah so the switch transformer
324.72|4.8|kind of uh model works as the following
327.36|4.0|so you have some transformer model that
329.52|3.84|has you know self-attention
331.36|3.679|and feed forward layers and the idea is
333.36|4.24|that we replace maybe one every two or
335.039|5.521|one every four feet forward layers with
337.6|5.36|a switch transformer layer
340.56|4.56|so you can see on the left is like one
342.96|4.88|kind of layer block which is self
345.12|4.32|attention then add normalize then a few
347.84|3.52|forward layer then add normalize and in
349.44|4.0|this case we're replacing the normal
351.36|2.88|feed forward layer with the like switch
353.44|2.479|layer
354.24|3.6|and we can see an illustration of this
355.919|3.28|on the right so
357.84|4.24|on the right we can see that the the
359.199|5.041|layer has two inputs um one is the token
362.08|4.32|more the other is the token parameters
364.24|3.519|and we can see that these you know
366.4|3.2|embedding representations will get sent
367.759|3.44|to a router which is exactly how it
369.6|3.2|works in the mixture of expert so the
371.199|3.44|router is basically just going to be you
372.8|3.679|know getting a distribution over all of
374.639|3.441|the experts so in this case we can see
376.479|2.56|that the the highest probability is
378.08|3.52|going to
379.039|4.88|the like the expert number two out of
381.6|3.84|the four experts and then the the right
383.919|4.0|token is actually having the most
385.44|4.879|probability on the first uh feed forward
387.919|3.921|weight which is like the first expert
390.319|2.88|so yeah we can see here that like what
391.84|2.799|we're going to do is in the switch
393.199|3.761|transformer which is very simple is just
394.639|4.56|send it to the highest probability
396.96|4.32|expert and so here we can see where the
399.199|4.0|adaptive computation lies where we'll
401.28|3.759|have four sets of weights
403.199|3.28|there's some shared uh weights and
405.039|3.121|computation across all the tokens for
406.479|3.44|example the self-attention layer is
408.16|4.479|computed exactly the same for the more
409.919|4.641|token and for the parameters token
412.639|3.601|but in the sparse switch layer we can
414.56|2.88|see that like actually the inputs are
416.24|2.88|while having the same amount of floating
417.44|5.68|point operations applied to them
419.12|6.72|actually have different weight matrices
423.12|2.72|uh next slide
426.0|3.36|yeah so that's the kind of high level i
427.52|4.0|deal with switch transformer is that you
429.36|3.44|know instead of sending a token to
431.52|3.36|multiple different experts which can
432.8|3.839|also increase the communication costs as
434.88|3.039|i'll go into a little bit later it also
436.639|2.881|just like significantly kind of
437.919|4.481|simplifies the algorithm by just only
439.52|3.6|sending it to one expert
442.4|2.639|so
443.12|3.6|for the improved training methodology we
445.039|3.44|focused on three different things to
446.72|4.16|help improve the training of sparse
448.479|4.321|models the first was selective precision
450.88|3.599|which like allows these sparse models to
452.8|3.76|be trained in lower precision formats
454.479|4.321|which is incredibly important most of
456.56|4.079|the models we train we really don't want
458.8|3.839|to be using float32 because it's just
460.639|3.68|slower to compute it also when you're
462.639|4.081|communicating tensors across different
464.319|3.681|processes and stuff it's twice the is
466.72|2.64|twice as slow just because there's twice
468.0|3.039|as many things
469.36|3.36|also we have some initialization tricks
471.039|4.16|and some training tricks as well for
472.72|4.0|allowing them to be trained more stably
475.199|2.881|especially as the models grow in size
476.72|4.4|which is like a new initialization
478.08|4.399|method along with like a a change to the
481.12|3.359|learning rate schedule
482.479|3.601|and third since that our models have so
484.479|3.12|many more parameters we do notice like
486.08|4.399|definitely different overfitting
487.599|4.081|dynamics especially once we fine-tune
490.479|3.041|these models that have been you know
491.68|3.76|pre-trained on all of the internet on
493.52|3.84|these small tasks with maybe only 50 to
495.44|3.92|100 000 examples that they can be much
497.36|3.2|more prone to overfitting so we also
499.36|3.76|look at some
500.56|4.0|custom uh you know regularization to
503.12|4.24|help prevent some of the overfitting
504.56|4.8|that we observe and finally we also talk
507.36|3.6|about this differentiable load balancing
509.36|3.52|technique we make
510.96|3.519|which kind of allows you know each
512.88|2.88|expert to roughly get the same amount of
514.479|2.56|tokens
515.76|2.639|because you know this is very important
517.039|2.48|especially given that we're you know
518.399|2.961|want the stuff to be efficient on
519.519|3.921|hardware we want roughly each expert to
521.36|4.56|have similar amounts of tokens sent to
523.44|4.24|it and so to kind of encourage this we
525.92|3.359|tack on an additional like load
527.68|2.96|balancing loss along with our
529.279|2.721|cross-entropy loss that we're training
530.64|4.8|with
532.0|5.12|uh next slide okay so here i'm gonna go
535.44|3.44|into selected precision so yeah again so
537.12|2.96|like when we're training large models
538.88|2.56|it's really important that we should be
540.08|3.52|able to train them in lower precision
541.44|4.32|formats so instead of each you know
543.6|4.48|weight being an activation being 32 bits
545.76|3.759|we want to shrink it down to 16 bits and
548.08|3.759|we use like the b float 16
549.519|4.641|representation and what we found out of
551.839|3.921|the gate is that you know these models
554.16|2.799|are just unstable
555.76|2.639|especially the sparse models are much
556.959|3.761|more unstable than the dense models in
558.399|3.601|terms of like you'll train it for 10 20
560.72|2.96|000 steps and then the losses would just
562.0|3.36|diverge this was something that we you
563.68|3.839|know frequently encountered
565.36|3.36|and so one key thing that we found is
567.519|3.361|that basically
568.72|5.92|you need to be casting a part of the
570.88|5.36|computation in um float32 for these
574.64|3.12|models to be able to be trained um
576.24|3.36|stably
577.76|3.759|and the the key component that we found
579.6|4.64|that you need to cast is the like router
581.519|4.641|computation and essentially you know
584.24|3.279|we can go into the technical details a
586.16|2.4|little bit more later but basically
587.519|3.121|anytime that there's like these
588.56|4.24|exponentiation functions it's very
590.64|4.319|important that we are you know having
592.8|3.84|higher and higher precision because of
594.959|3.921|round off errors that can then
596.64|4.639|drastically change the output of some
598.88|4.399|kind of you know exponentiation function
601.279|3.441|so for example like if you have an
603.279|4.0|exponentiation function and you change
604.72|4.96|it by 0.1 or 0.2 or 0.3 this can
607.279|4.481|drastically change the output of like
609.68|4.24|exponentiating it especially depending
611.76|3.36|on how large the input is
613.92|2.56|so yeah so this was like a very
615.12|2.719|important thing and it basically doesn't
616.48|3.12|change the compute at all and allows the
617.839|3.12|models to just be significantly more
619.6|3.84|stable
620.959|2.481|next slide
623.839|3.44|so the the second thing we looked at is
625.44|3.12|also the initialization scale so like
627.279|3.361|the standard way that we were
628.56|3.6|initializing these models
630.64|3.92|we found to also just make the models
632.16|4.4|much more prone to being unstable and or
634.56|3.76|just performing worse so one thing that
636.56|3.76|we did that we found was very effective
638.32|3.92|was to just simply make the
640.32|3.84|initialization scale much smaller and
642.24|3.36|when we did this we found that you know
644.16|4.239|the quality just like drastically
645.6|5.52|improved it was like a very simple fix
648.399|2.721|uh next slide
651.44|3.44|and the third thing i mentioned where
653.68|2.719|since we noticed that these models are
654.88|2.8|much more prone to overfitting since
656.399|2.56|they just have significantly more
657.68|4.0|parameters
658.959|4.32|is that we also use much more dropout
661.68|3.92|for the expert layers only so here we
663.279|4.321|can see we took we have like you know
665.6|3.44|the t5 base which is a dense model and
667.6|3.359|then we have a bunch of different switch
669.04|3.2|variants on that and we found to be the
670.959|3.601|most effective on these four different
672.24|3.839|fine tuning tasks was just to really
674.56|3.36|significantly increase the dropout rate
676.079|3.281|inside the expert layers and we found
677.92|4.88|that this was pretty effective for
679.36|4.56|combating the overfitting
682.8|4.159|next slide
683.92|5.52|yeah we have a question oh awesome
686.959|4.56|yeah okay let me take a look
689.44|3.92|do you want to go ahead yeah i can ask
691.519|3.921|um it was just in reference to that
693.36|4.24|previous table where you have throughput
695.44|3.68|and precision
697.6|4.08|um it just seemed surprising to me that
699.12|4.399|you could match this 1390 number
701.68|3.36|we're using selective precision it seems
703.519|3.44|like i would expect it to be like
705.04|3.68|something in between
706.959|3.361|yeah so it essentially comes down to the
708.72|3.119|fact that like there's maybe a little
710.32|3.519|bit of noise
711.839|3.68|sampling with the speed and the only
713.839|3.841|part we're casting is the router which
715.519|4.401|is you know maybe like so it's such an
717.68|3.76|insignificant portion of the computation
719.92|2.64|and there's zero communication there
721.44|3.28|that it's essentially like a free
722.56|4.24|operation in the network so whether you
724.72|3.84|cast the b flow 16 or flow 32 it doesn't
726.8|3.279|actually impact the speed at all
728.56|3.519|within the precision so we can actually
730.079|4.241|measure the speed
732.079|6.88|and also these architectures only use
734.32|6.319|fast layer uh ones one every four layers
738.959|4.241|and so
740.639|4.64|yeah essentially the float32 part is
743.2|3.84|kind of very negligible in the entire
745.279|3.761|yeah
747.04|4.479|it's like for example i think like off
749.04|4.239|the top of my head it's like 140th the
751.519|3.921|computation that would cost for you to
753.279|4.481|do the first like like weight matrix
755.44|4.079|multiply in like a dense relu dense
757.76|3.12|layer or something so it's a very very
759.519|2.641|small part and yeah we're not using them
760.88|3.519|very frequently like everyone mentioned
762.16|2.239|as well
769.12|2.959|yeah and then you know just like a quick
770.88|2.48|point in this like i won't go into some
772.079|2.88|of the technical details but yeah we
773.36|3.039|definitely you know since we're training
774.959|2.961|these things on hardware and we really
776.399|3.281|like i think a big part of the mixture
777.92|3.52|of experts paradigm is that these things
779.68|3.68|are designed such that it maps really
781.44|3.399|efficiently to hardware
783.36|4.0|so we want to be doing dense matrix
784.839|4.361|multiplies and for this to work really
787.36|3.84|well we we also want to be able to have
789.2|4.079|you know roughly equal amount of tokens
791.2|2.8|going to each of the different experts
793.279|2.881|and
794.0|3.279|what like i think the this isn't that
796.16|2.479|sensitive to the load balancing
797.279|3.201|formulation like we tried a few things a
798.639|3.2|lot of them worked but yeah essentially
800.48|3.52|you definitely want some kind of load
801.839|4.081|balancing loss added on when using
804.0|4.72|sparsity
805.92|2.8|yeah next slide
810.56|3.8|yeah erin go ahead
814.639|2.481|yeah so
819.36|8.279|so the frameworks with the library we
821.279|6.36|use uh rely on static shapes uh for
831.519|3.281|okay yeah so we so
833.68|4.719|xla
834.8|4.88|so the compiler um for uh tensorflow and
838.399|4.56|mesh tensorflow
839.68|4.64|expects static shapes for tensors
842.959|3.281|however
844.32|4.72|the computations in switch transformers
846.24|4.399|are dynamic because
849.04|2.479|you know because of the router right
850.639|2.56|like
851.519|2.56|different inputs will be routed to
853.199|2.241|different
854.079|3.601|experts
855.44|4.8|and so we need to
857.68|4.64|specify ahead of time how many tokens
860.24|4.159|will be sent to each export
862.32|5.199|and so we will introduce this expat
864.399|5.281|capacity um hyper parameter
867.519|4.161|to specify that and that's going to be a
869.68|4.399|static number
871.68|5.04|which says how many tokens each expert
874.079|2.641|can process
877.68|4.08|and so in practice we instead
879.279|5.12|parametrize this by having
881.76|6.0|a quantity called the capacity factor
884.399|5.281|so we have an example here um
887.76|3.439|so you know so
889.68|3.839|the bottom row
891.199|2.32|is
893.76|3.759|okay so is a bunch of tokens on one
895.839|3.921|device and then you need to sort of
897.519|5.12|route those tokens to multiple devices
899.76|4.8|or multiple exports
902.639|3.841|so if too many tokens are routed to a
904.56|4.16|single export
906.48|3.52|some tokens will be dropped because as
908.72|5.04|we said like
910.0|5.6|export had a fixed capacity
913.76|3.6|so that's the example on the left where
915.6|5.52|the capacity factor is one and that
917.36|6.159|basically means that the total um
921.12|5.44|there's no like extra buffer
923.519|5.041|for uh rolling tokens
926.56|4.0|um so instead of that we can use a
928.56|3.519|capacitive factor that's larger than one
930.56|3.04|so on the right you have an example with
932.079|2.401|1.5
933.6|3.599|um
934.48|4.4|so that means that now each export has
937.199|5.041|like sort of three slots that can
938.88|3.36|process three tokens
942.32|4.72|and so that prevents token dropping
944.48|5.919|because we have more capacity but the
947.04|4.719|issue is that this means higher
950.399|2.961|you know this more expensive
951.759|4.08|communication across
953.36|2.479|devices
957.92|4.88|yeah okay so that was it
960.72|3.84|yeah go ahead oh yeah so yeah so one
962.8|2.88|thing that we also experimented with was
964.56|3.12|this um
965.68|3.92|method called no token left behind and
967.68|3.76|the idea was the following so
969.6|4.159|since we have to have like you know a
971.44|4.0|fixed batch size for each expert and
973.759|3.601|there can be token dropping we kind of
975.44|3.36|we're thinking that hey yeah having
977.36|2.96|tokens dropped or like you know having
978.8|2.64|some tokens not having any computation
980.32|2.24|applied to it
981.44|2.959|is probably hurting the model
982.56|4.24|performance so what if we do a
984.399|3.68|multi-stage routing procedure so first
986.8|2.56|you do the normal routing where it's
988.079|3.841|like you send each token to its highest
989.36|5.76|probability expert but then any drops
991.92|4.88|tokens you then send to their second
995.12|3.279|highest probability expert and so forth
996.8|3.36|and so on where you can basically repeat
998.399|3.281|this process to guarantee that no tokens
1000.16|3.44|are being dropped
1001.68|3.76|interestingly actually this approach
1003.6|3.12|didn't empirically improve model
1005.44|2.48|performance of anything it actually kind
1006.72|2.72|of hurt it
1007.92|2.88|and we thought that was actually very
1009.44|2.72|interesting
1010.8|2.959|and i think the intuition is that you
1012.16|3.44|know once the model learns it wants to
1013.759|3.041|send a token to one expert
1015.6|2.56|like it really wants to have that
1016.8|3.36|computation applied to it and just
1018.16|4.239|applying some other computation
1020.16|4.0|doesn't you know have at all the same
1022.399|3.761|property along with it actually maybe
1024.16|3.12|being potentially detrimental
1026.16|2.799|so yeah we thought that was pretty
1027.28|3.44|interesting as we were very optimistic
1028.959|3.281|this would potentially you know get
1030.72|3.199|improved performance but it ended up not
1032.24|4.0|really making a difference and we found
1033.919|4.721|this quite surprising
1036.24|4.64|we have a question from
1038.64|2.24|um
1041.12|3.52|i think it will actually kind of like
1043.039|4.0|address literally the last point that
1044.64|5.039|you brought up um i think when i think
1047.039|4.481|about like a mixture of experts um
1049.679|3.921|usually like they specialize in like
1051.52|4.399|different things right so i think it's
1053.6|3.439|like um
1055.919|4.961|just like
1057.039|5.52|a lot like i was just wondering um
1060.88|3.12|like if you send it to like the second
1062.559|2.48|best or whatever
1064.0|3.6|um
1065.039|5.281|like what if like all of your tokens
1067.6|5.199|would be particularly good for like one
1070.32|6.479|expert and then you only like
1072.799|6.561|process let's say like 20 of your tokens
1076.799|5.201|so that ends up being better than
1079.36|3.679|rerouting them to anything else
1082.0|2.799|exactly
1083.039|3.361|yeah so yeah even if you're dropping a
1084.799|3.041|lot of tokens it's not beneficial to be
1086.4|2.8|sending them to the second third or
1087.84|2.8|fourth best thing
1089.2|2.719|and one actually interesting property
1090.64|3.76|that we you know noticed about these
1091.919|3.921|models is they're surprisingly robust to
1094.4|3.36|token dropping especially during fine
1095.84|2.8|tuning so yeah so in the standard
1097.76|2.08|paradigm what we'll do is we'll
1098.64|3.279|pre-train this thing we'll have some
1099.84|4.32|load balancing loss which makes the the
1101.919|3.921|tokens pretty balanced actually
1104.16|2.96|but then during fine-tuning where it's
1105.84|3.04|like we really want to fine-tune it on a
1107.12|3.76|specific task we actually studied this
1108.88|4.08|exact question and we were studying does
1110.88|4.0|it help to have a load balancing loss
1112.96|3.2|during fine tuning or not and so if you
1114.88|2.799|have the load balancing loss yeah that
1116.16|3.44|kind of is encouraging you know for the
1117.679|3.281|specific task we want to try to have you
1119.6|2.88|know all the experts be used versus
1120.96|2.8|turning it off whereas there's
1122.48|3.04|definitely some you know prior
1123.76|3.6|specialization and it's actually much
1125.52|3.68|better to just turn the auxiliary loss
1127.36|3.92|off and even if it's like you know 60 to
1129.2|4.56|70 of the tokens are being dropped that
1131.28|4.16|actually performs much better than you
1133.76|4.08|know having all the tokens balanced but
1135.44|4.96|doesn't a load balancing loss encourage
1137.84|4.719|basically all the experts to learn very
1140.4|4.56|similar weights and then just
1142.559|3.761|randomly assign your tokens
1144.96|3.68|because then it does matter to which
1146.32|3.68|expert stuff is being sent to
1148.64|2.96|so when we use the load balancing loss
1150.0|3.2|like the routing mechanism is definitely
1151.6|4.24|learned so the model definitely is
1153.2|4.08|encouraged to you know choose an expert
1155.84|3.28|that it wants to send it to for good
1157.28|3.279|right but like if all the experts learn
1159.12|2.32|the same weights
1160.559|3.681|then
1161.44|5.04|the the router learns basically oh it
1164.24|4.64|doesn't matter where you send it to
1166.48|3.92|so if you encourage load balancing you
1168.88|3.6|encourage
1170.4|4.399|technically that like you want any loss
1172.48|4.24|to fit with any expert right
1174.799|3.921|i mean that's maybe the extreme behavior
1176.72|4.079|if you have a very high sort of load
1178.72|3.92|balancing loss coefficient
1180.799|3.681|but in practice that coefficient is kind
1182.64|4.24|of tuned and we observe that for you
1184.48|5.76|know small enough values
1186.88|5.6|um the router still learns like cement
1190.24|3.92|like meaningful routing
1192.48|3.12|yeah because it's like a balance between
1194.16|3.6|this like you know cross entropy loss
1195.6|3.36|and this load balancing loss and so on
1197.76|3.52|one hand yeah you definitely want to
1198.96|3.52|encourage the model to be balanced then
1201.28|3.68|on the other hand you also want to just
1202.48|4.079|get good empirical performance and yeah
1204.96|2.64|the model is able to definitely like on
1206.559|2.641|one hand
1207.6|2.8|learn and specialize the experts where
1209.2|2.88|they have different weights such that
1210.4|2.88|it's like you know definitely it expects
1212.08|2.4|certain tokens to be sent to certain
1213.28|3.279|aspects but on the other hand still be
1214.48|3.6|reasonably balanced so that the models
1216.559|3.6|are officially run on like modern
1218.08|3.68|hardware
1220.159|2.561|exactly
1221.76|2.159|we also have a question from the
1222.72|2.8|classroom
1223.919|2.561|so question the question that i want to
1225.52|2.159|ask is
1226.48|2.72|it seems to me like this is a very
1227.679|2.88|experimental talk we're talking about
1229.2|2.719|floating point precision we're talking
1230.559|2.881|about different approaches and currently
1231.919|4.24|work well and whenever we're dealing
1233.44|4.479|with your clients there's a question of
1236.159|3.76|what is the research question and i feel
1237.919|5.441|like i miss that so what are we trying
1239.919|4.88|to answer with all these experiments
1243.36|3.199|yeah i think the i think the high level
1244.799|2.721|research question is like you know can
1246.559|3.441|we
1247.52|4.0|you know create models
1250.0|3.44|that are you know
1251.52|3.36|like doing adaptive computation from the
1253.44|3.04|standpoint of like you know can we try
1254.88|3.2|to make models more simulate the
1256.48|3.679|dynamics that we think models should you
1258.08|3.12|know most naturally use which is
1260.159|2.801|different inputs that have different
1261.2|3.44|amounts of computation applied have
1262.96|2.959|different weights applied to them you
1264.64|2.72|know and basically all of this basically
1265.919|3.041|we're trying to research and like figure
1267.36|3.199|out how can we create like a new
1268.96|3.52|framework for these models to be trained
1270.559|3.521|as opposed to their dense counterparts
1272.48|3.6|that you know for every input are always
1274.08|3.839|having the same exact computation
1276.08|4.079|applied so that's interesting because
1277.919|5.601|when you say the same exact computation
1280.159|5.281|applied one might imagine that um
1283.52|3.76|like to me the immediate thing is about
1285.44|3.68|how long to deliberate about something
1287.28|3.519|what i mean by that is if we want to
1289.12|3.2|have variable length computation you
1290.799|2.88|could imagine that i could have a short
1292.32|3.839|amount of computation or it could have
1293.679|4.48|much longer computation but this idea of
1296.159|4.481|like why then do we instead consider the
1298.159|3.601|dimension of different computation i
1300.64|2.48|mean assuming of course that these
1301.76|3.44|experts do indeed learn different things
1303.12|2.96|which i think you'll get to in
1305.2|3.2|yeah
1306.08|4.0|so yeah why do we immediately jump to
1308.4|3.04|thinking about specialized experts as
1310.08|3.839|opposed to thinking about variable
1311.44|3.76|length computation
1313.919|3.041|so yeah so this is actually we actually
1315.2|3.04|go into some variable length computation
1316.96|3.199|stuff later in the talk and i feel like
1318.24|3.679|they're both actually just important
1320.159|2.481|axes that should both be pushed on i
1321.919|2.321|think
1322.64|2.8|i guess yeah i guess it's kind of you
1324.24|2.16|know
1325.44|2.4|i guess
1326.4|2.399|yeah i'm not freezing my question but
1327.84|2.48|what i'm trying to understand is you're
1328.799|2.801|thinking about why did you decide to
1330.32|2.96|attack this one first i want to
1331.6|3.36|understand why your team chose to go
1333.28|4.32|this direction first
1334.96|4.88|yeah absolutely so i think that one
1337.6|3.68|empirically it seems that sparsity has
1339.84|2.719|led to better empirical results in the
1341.28|3.36|field of deep learning than adaptive
1342.559|3.6|computations so far and i think the way
1344.64|3.44|that we use these things maps really
1346.159|3.76|well to our modern hardware
1348.08|3.12|which is also very promising and i think
1349.919|2.88|the way we were kind of looking at it is
1351.2|3.04|like sparsity is like a first step
1352.799|3.441|towards doing more interesting and
1354.24|3.439|general adaptive computation
1356.24|2.559|where and we're and you know because i
1357.679|3.441|think it's like you know this stuff is
1358.799|4.401|complicated and typically starting from
1361.12|4.0|something that works well is better than
1363.2|3.52|necessarily like you know
1365.12|2.96|you know trying something that's not
1366.72|2.56|necessarily as proven out and then
1368.08|2.56|trying to like get it to work really
1369.28|2.72|well so i think we're kind of starting
1370.64|3.279|from sparsity which like you know gnome
1372.0|4.08|chazier and others got to work really
1373.919|3.281|well in the context of lstms we were
1376.08|2.8|kind of interested in you know let's
1377.2|2.88|pour some of this to transformers let's
1378.88|2.64|get it working really well and then
1380.08|2.88|let's slowly start expanding towards a
1381.52|3.68|lot of the other natural questions that
1382.96|3.44|you mentioned whereas like okay whereas
1385.2|2.8|instead of you know different weights
1386.4|3.04|per core let's also maybe have a
1388.0|3.44|different computation per core and all
1389.44|3.599|of this so that's i guess how we were
1391.44|3.44|kind of building the natural like you
1393.039|5.76|know build up and progression of our
1394.88|3.919|research got it cool thank you
1400.32|3.04|what do you think or anything else to
1401.52|3.6|add
1403.36|3.199|um
1405.12|4.4|yeah i mean i guess i kind of see
1406.559|5.761|adaptive computation and sparsity as
1409.52|3.84|you know related but separate things so
1412.32|3.359|you know especially is more like
1413.36|4.319|different parameters for each example
1415.679|2.88|and adaptive computation might be more
1417.679|2.401|different
1418.559|3.36|amount of flops
1420.08|4.0|and we have some of that with the token
1421.919|4.961|dropping but that's kind of uh
1424.08|4.4|no that's not the the main um
1426.88|5.279|domain motivation
1428.48|6.72|uh definitely as barrett mentioned
1432.159|5.841|uh i would say you know no one really
1435.2|5.2|has figured out adaptive computation yet
1438.0|4.88|for deep learning and what one reason is
1440.4|4.72|because we have this uh
1442.88|3.919|you know accelerators right expect
1445.12|3.6|expect like
1446.799|3.601|sort of you know
1448.72|4.16|we need to work with like batch like
1450.4|4.879|data parallelism right so
1452.88|5.84|um and all of our accelerators and our
1455.279|4.88|frameworks use this spmd paradigm where
1458.72|3.839|you're kind of supposed to apply the
1460.159|4.801|same computation to
1462.559|4.0|to examples um
1464.96|3.199|and so if you look at the literature you
1466.559|3.921|have you know walks like universal
1468.159|4.561|transformers
1470.48|4.24|where they replace the feed forward in
1472.72|3.6|the transformer by
1474.72|4.88|um just a recurrent weight and so it's
1476.32|6.08|kind of like an lstm on each token
1479.6|4.559|and the lcm can stop at different times
1482.4|3.759|based on some
1484.159|4.721|criteria but the way these things are
1486.159|4.4|implemented is just through masking
1488.88|4.399|um because
1490.559|4.321|it needs to be implemented in the spmd
1493.279|3.441|programming style
1494.88|4.24|um and so definitely sparsity was kind
1496.72|4.4|of like easier to get to work
1499.12|5.36|first and also there were some prior
1501.12|3.36|results with lstm so
1506.32|3.04|in terms of like the first question you
1508.0|2.799|know sort of what's our research
1509.36|3.6|question here it's just like oh can we
1510.799|4.801|design more efficient models
1512.96|4.719|and sparsity is this new axis that
1515.6|3.6|hasn't been explored that much and yeah
1517.679|3.841|i think that
1519.2|5.359|you know i i'm happy with just that
1521.52|3.039|being the research question
1526.24|3.919|great okay
1527.44|3.52|um yeah so next slide
1530.159|3.12|yep
1530.96|2.319|oops
1533.6|3.679|yeah again so kind of putting it all
1534.799|4.24|together so the switch transformer layer
1537.279|3.921|selects an expert like just the top
1539.039|4.24|expert and then incorporates a bunch of
1541.2|4.479|the general sparse model improvements to
1543.279|4.321|you know allow it to fine-tune better
1545.679|4.0|allow it to you know
1547.6|3.28|be more regularized allow it to you know
1549.679|2.48|be trained with lower precision formats
1550.88|5.48|and a lot of like technical details to
1552.159|4.201|just get them training and working well
1557.44|4.08|um yeah so one thing that we also wanted
1559.12|3.84|to do was uh a comparison between like
1561.52|3.519|top one and top two routing since top
1562.96|4.56|two routing was kind of the you know
1565.039|3.601|most popular technique
1567.52|2.24|and so here we can see we have two
1568.64|2.24|different dense models trained of
1569.76|2.96|different sizes and we're going to be
1570.88|5.36|looking at like the the pre-training
1572.72|6.319|like negative log perplexity so um
1576.24|5.6|yeah the bigger the number the better
1579.039|2.801|so next slide
1581.919|2.161|so here so and what we're going to be
1583.039|3.12|doing is we're going to be studying them
1584.08|4.0|at different capacity factors so a
1586.159|3.361|capacity factor of 2.0 basically means
1588.08|4.079|that there is enough buffer for two
1589.52|4.159|tokens to be sent to every single expert
1592.159|3.201|and we're going to be comparing like top
1593.679|3.441|one versus top two routing
1595.36|4.0|and also comparing their speeds along
1597.12|4.32|with their like time to get some like
1599.36|3.6|threshold quality
1601.44|3.92|uh okay yeah so here we can see in the
1602.96|3.92|capacity factor 2.0 case
1605.36|3.36|that um
1606.88|3.12|the moe models outperform switch
1608.72|3.52|transformer which makes a lot of sense
1610.0|4.24|like since switch transformer is only
1612.24|4.08|you know sending uh like a top one token
1614.24|4.559|to each expert the mixture of expert is
1616.32|3.92|sending um you know two tokens so that
1618.799|3.12|makes sense that this extra buffer will
1620.24|3.6|be like disproportionately beneficial
1621.919|4.561|for the mixture of expert models
1623.84|4.959|and so we noticed that and next slide
1626.48|4.16|all right yeah next
1628.799|4.0|now when we so the really interesting
1630.64|4.639|parts for the top one routing becomes
1632.799|4.24|when we lower the capacity factors so
1635.279|3.601|having a high capacity factor is bad for
1637.039|3.601|many reasons one of which is it really
1638.88|3.76|incurs more of these you know
1640.64|4.159|communication costs for sending tokens
1642.64|3.919|to the correct experts it also incurs
1644.799|3.76|more compute costs and also incurs like
1646.559|3.761|a lot of memory overhead so if you can
1648.559|3.921|get this lower it's it's usually like a
1650.32|4.32|very very good thing
1652.48|4.079|and so what we see here is that switch
1654.64|4.32|transformer actually outperforms mixture
1656.559|4.401|of experts when you have like a lower uh
1658.96|5.68|capacity factor and we can see that the
1660.96|5.68|time to quality threshold we um you know
1664.64|4.08|yeah we get there much quicker and so
1666.64|4.24|even across the 2.0 and the 1.25
1668.72|3.839|capacity factors like the kind of pareto
1670.88|3.76|optimal thing we saw in our setup is to
1672.559|4.24|use switch transformer at a lower
1674.64|3.919|capacity factor just due to the fact
1676.799|3.6|that while the quality is worse a little
1678.559|3.521|bit worse on a step basis it's just like
1680.399|4.241|much faster to run so it's kind of the
1682.08|5.04|pareto optimal decision
1684.64|4.0|uh next slide
1687.12|4.0|and we could also be seeing that like
1688.64|3.68|for capacity factor 1.0 again we can see
1691.12|3.439|that this really disproportionately
1692.32|4.88|benefits switch transformer and is even
1694.559|5.201|better for on a pareto standpoint than
1697.2|4.8|the 1.25 capacity factors
1699.76|3.36|and interestingly since you know moe
1702.0|3.12|also does like a little bit more
1703.12|4.24|computation we can also just increase
1705.12|3.439|the uh amount of compute done elsewhere
1707.36|2.88|in the model and we can see that that's
1708.559|2.961|like a much more efficient allocation of
1710.24|3.2|compute
1711.52|5.039|so yeah overall our takeaway is that
1713.44|5.44|yeah lower capacity factors using up on
1716.559|4.881|routing is more pareto efficient than
1718.88|4.48|you know using like top two routing at
1721.44|3.839|higher capacity factors
1723.36|4.799|next slide
1725.279|4.241|um oh and you can take it over
1728.159|3.281|okay so
1729.52|4.08|next we'll look at how
1731.44|4.08|sweet transformer scales
1733.6|5.36|as a function of the number of exports
1735.52|5.6|in the switch layers
1738.96|5.839|and so on the right side here you see a
1741.12|6.96|plot that shows perplexity
1744.799|5.921|versus training steps for different
1748.08|4.88|switch architectures ranging from t5
1750.72|3.679|base which is basically no expert or a
1752.96|4.719|single expert
1754.399|5.041|up to 128 experts
1757.679|3.841|and so you see that as we increase the
1759.44|4.719|number of experts which also increases
1761.52|5.2|number of parameters of sports space
1764.159|2.561|parameters
1767.039|4.161|you get sort of uh speed ups
1769.84|3.36|you know you get increasing speed ups
1771.2|4.079|about the dense baseline and are like
1773.2|3.52|sort of diminishing returns
1775.279|3.28|to uh
1776.72|5.6|you know multiplying to you know
1778.559|3.761|increasing the number of experts as well
1784.32|4.239|so the previous
1785.919|4.961|figure was looking at
1788.559|6.0|perplexity versus training steps here we
1790.88|6.48|look at perplexity versus strength time
1794.559|4.48|so that includes you know
1797.36|3.84|all the you know additional
1799.039|3.52|communication costs when you have more
1801.2|2.56|experts or
1802.559|2.881|um
1803.76|3.68|you know comparing comparing to the
1805.44|4.08|dense baseline
1807.44|5.839|and so this is for switch bass or then
1809.52|7.84|super t5 bass and um we observe 7x up to
1813.279|6.561|7x speedups over t5 bass
1817.36|4.799|and so you know just to
1819.84|3.68|maybe contextualize these these numbers
1822.159|3.041|like
1823.52|4.0|you know 7x speedups and deep learning
1825.2|4.4|are pretty hard to obtain and so
1827.52|4.46|i think this is one of the
1829.6|3.679|you know one of the results that um
1831.98|3.22|[Music]
1833.279|3.441|you know can spark a lot of interest in
1835.2|3.199|sparse models
1836.72|3.6|even if it's only for pre-training for
1838.399|3.681|now like just having that number is like
1840.32|4.239|you know maybe there's a
1842.08|4.479|there's a significant
1844.559|3.281|um
1846.559|4.761|there's something significant that can
1847.84|3.48|be obtained here
1853.279|5.12|okay so spot scaling laws
1855.44|5.2|so here we'll look at uh
1858.399|4.64|sort of loss versus
1860.64|3.919|sparse model parameters which are
1863.039|3.681|increased by increasing the number of
1864.559|5.041|experts
1866.72|4.799|and so similarly to the sort of you know
1869.6|3.6|neural scaling wallpaper
1871.519|3.601|we observed that
1873.2|4.079|as you increase
1875.12|5.84|the parameters
1877.279|5.28|which the sparse parameters and keep the
1880.96|4.16|flaps fixed
1882.559|5.761|uh you get diminishing like consistent
1885.12|3.2|gains by diminishing gains
1890.72|3.76|okay so now we're going to compare
1892.48|5.439|export parallelism and molar parallelism
1894.48|6.64|so we we introduced sparsity or export
1897.919|5.441|parallelism as a new dimension to
1901.12|3.919|uh scale models but of course
1903.36|5.039|there's the other one for dance model
1905.039|5.52|which is simply model parallelism where
1908.399|4.88|you know model weights are partitioned
1910.559|4.881|across cores once they are
1913.279|5.801|above the maximum size that you can feed
1915.44|3.64|on a single core
1920.64|4.0|all right so
1922.799|3.441|yeah parrot has to left this export
1924.64|2.96|parallelism here
1926.24|2.64|yeah so so essentially what we're doing
1927.6|3.12|is is um
1928.88|4.639|yeah we're kind of comparing a switch
1930.72|4.48|base model versus the the dense base and
1933.519|4.0|we're also comparing against a larger
1935.2|4.959|dense model that has used um model
1937.519|4.0|parallelism and we can see that you know
1940.159|2.88|because basically when we want to scale
1941.519|3.121|up model size we kind of have two axes
1943.039|3.201|that we can either go through we can
1944.64|3.84|either increase the number of flops by
1946.24|3.52|scaling through model parallelism or
1948.48|3.679|increase the number of parameters by
1949.76|4.48|scaling through sparsity and so we can
1952.159|3.281|see that you know even compared to like
1954.24|2.319|you know a dense model that's been
1955.44|3.119|scaled up through model parallelism that
1956.559|4.321|sparsity is still at the scale a more
1958.559|4.321|effective way to scale up the model
1960.88|4.399|by you know still getting 2.5 x speed
1962.88|5.279|ups over this larger um dense model that
1965.279|5.041|was using uh model parallelism
1968.159|2.88|cool so uh
1970.32|3.199|yeah
1971.039|6.801|basically here t5 large is the dance
1973.519|4.321|mode that uses other parallelism
1979.76|2.32|yeah go ahead
1981.12|2.0|okay
1982.08|3.04|yeah and so one thing that we also
1983.12|3.6|wanted to look at is like you know are
1985.12|3.12|these expert models effective if you
1986.72|2.72|have like you know really small amount
1988.24|2.559|of computer just a small amount of
1989.44|3.52|experts so typically when we're
1990.799|4.24|designing these models like we have one
1992.96|3.52|expert per core but if you don't have
1995.039|3.441|like a large cluster to run these things
1996.48|3.76|on let's say you just have like a gpu
1998.48|3.76|with two cores or something like is
2000.24|4.159|having two experts more effective than
2002.24|3.76|just like a dense model and the the
2004.399|3.12|answer is yes so we can see even pretty
2006.0|3.12|good scaling properties even with like a
2007.519|3.121|tiny amount of experts
2009.12|2.96|which is very very promising for these
2010.64|4.48|models to be used even in like much
2012.08|6.28|lower compute regimes
2015.12|3.24|next slide
2018.799|5.76|okay so yeah so
2021.519|5.121|yeah so we'll look at um
2024.559|3.681|you know
2026.64|4.879|what things look like when we use
2028.24|5.439|different uh types of parallelism namely
2031.519|5.121|expert parallelism to add exports
2033.679|5.441|smaller parallelism to sharp model ways
2036.64|4.24|across course and also data parallelism
2039.12|3.6|which is sort of the
2040.88|5.0|dominant paradigm in deep learning at
2042.72|3.16|the moment
2046.08|2.4|and so
2048.72|2.959|you know i guess you know in the
2050.24|3.52|previous slides we mostly talked about
2051.679|4.0|export parallelism but of course you
2053.76|4.879|know dance models and large-scale dance
2055.679|4.96|models uh use model parallelism so gp3
2058.639|3.921|and these other large models what they
2060.639|3.921|do is that they will simply
2062.56|3.279|shout model weights across different
2064.56|4.4|cores
2065.839|3.121|uh yeah we have a question
2070.159|4.881|oh yeah um i just wanted to know because
2073.359|3.04|i think there was like i know if you're
2075.04|4.24|gonna address later but i think
2076.399|4.801|somewhere in a paper it said that um the
2079.28|3.76|more experts you have the more sample
2081.2|3.76|efficient it gets
2083.04|3.76|and i was just like hoping hoping that
2084.96|4.159|you could give us some intuition about
2086.8|3.839|that because i
2089.119|2.881|don't understand why that would be the
2090.639|2.561|case
2092.0|3.44|so i guess
2093.2|4.8|yeah maybe
2095.44|4.56|yeah so i guess like you know there's
2098.0|5.28|all of this work on larger models are
2100.0|4.72|more sample efficient and larger in the
2103.28|3.6|context of the scaling law works means
2104.72|3.52|like more parameters and more flops as
2106.88|2.479|you increase the number of experts
2108.24|2.64|there's more parameters but not more
2109.359|3.601|flops but the model is still like you
2110.88|4.08|know larger in in like you know a
2112.96|3.76|similar sense so i guess like building
2114.96|3.68|on the intuition that larger models are
2116.72|4.48|more sample efficient in my mind it's
2118.64|3.6|not necessarily that surprising
2121.2|2.8|that
2122.24|3.44|these models with more experts that have
2124.0|3.359|more parameters are more sample
2125.68|2.72|efficient
2127.359|4.081|i guess that's my like kind of high
2128.4|5.12|level uh intuition for it
2131.44|3.76|yeah i would say that's kind of expected
2133.52|3.04|that you know
2135.2|4.48|more experts
2136.56|4.96|leads to better sample efficiency
2139.68|2.96|especially if you look at trending step
2141.52|4.319|right
2142.64|3.199|in our training time
2149.359|4.881|okay cool
2151.76|4.64|so where are we um
2154.24|4.0|yeah so yes so
2156.4|4.56|okay so we look at how model weights are
2158.24|6.08|split over cost for different scenarios
2160.96|4.96|um so data parallelism is the first one
2164.32|4.32|so that's kind of the
2165.92|3.919|the typical setup that deep learning uh
2168.64|3.6|uses
2169.839|5.921|um especially for not so large networks
2172.24|7.599|which don't require another parallelism
2175.76|6.4|and so let me yeah let me explain how
2179.839|4.801|yeah i'll just go to the final
2182.16|5.679|figure and i'll explain how to look at
2184.64|3.199|this figure
2188.72|5.04|okay so we have 16 processors which are
2191.68|4.24|organized in a four by four mesh right
2193.76|3.839|so each dotted line
2195.92|5.04|each four by four dotted line here
2197.599|5.76|represents a different core
2200.96|4.8|and the first row studies how the model
2203.359|4.24|weights are split over course and the
2205.76|4.64|second row
2207.599|4.561|illustrates how data so literally
2210.4|4.719|examples and tokens are split over
2212.16|5.6|course
2215.119|3.921|and yeah and then the final thing to
2217.76|3.599|that's required to understand this
2219.04|4.079|figure is that each
2221.359|4.321|um
2223.119|5.441|yeah each color of the shaded squares
2225.68|4.56|here uh identifies a unique weight
2228.56|3.039|matrix
2230.24|2.64|okay so let's start with data
2231.599|3.281|parallelism
2232.88|4.959|so for data parallelism
2234.88|5.36|uh the same model weights are replicated
2237.839|5.041|across all cores
2240.24|4.48|and the data is simply partitioned of
2242.88|4.56|our cause and so
2244.72|4.08|that's what um this corresponds to
2247.44|2.56|um
2248.8|2.96|you know if you
2250.0|2.88|like using the
2251.76|2.4|the
2252.88|3.6|description of the caption the
2254.16|4.959|explanation of the caption i just gave
2256.48|4.639|so next we have model parallelism
2259.119|4.24|that's kind of just like a theoretical
2261.119|3.921|example because in practice people
2263.359|4.321|always use modal parallelism in
2265.04|4.4|conjunction with data parallelism
2267.68|3.679|but so if you want to do only model
2269.44|4.639|parallelism now you would have a single
2271.359|3.681|model way that is partitioned over all
2274.079|4.321|cores
2275.04|6.48|and your data would just be replicated
2278.4|3.12|over all codes instead
2281.599|4.081|so now we have modeling data parallelism
2283.839|3.921|and that's kind of the typical scenario
2285.68|3.76|for large dense networks
2287.76|5.44|so in that case model weights are
2289.44|5.52|partitioned among a subset of the course
2293.2|3.44|to subset of course that process
2294.96|4.24|different batches of data
2296.64|4.959|and so in that example here we have
2299.2|4.399|you know sort of four uh so the first
2301.599|3.601|sub-square here means that
2303.599|4.961|the model weights are
2305.2|5.6|partitioned across four score four cores
2308.56|4.08|and um
2310.8|4.08|and this is replicated
2312.64|5.199|sort of four times for the data
2314.88|2.959|parallelism dimension
2318.079|4.801|on the data side for model and data
2320.079|5.121|parallelism um
2322.88|4.239|yeah the data here
2325.2|3.68|is replicated across model parallel
2327.119|3.841|cores and partitioned across data
2328.88|4.0|parallel cores
2330.96|4.08|so next we have expert and data
2332.88|3.52|parallelism
2335.04|3.92|so in that scenario that's kind of
2336.4|5.04|similar to data parallelism but now each
2338.96|4.159|core will hold a different model weight
2341.44|4.159|which is illustrated by the different
2343.119|2.48|colors
2346.0|4.88|and for the data side the data is simply
2348.96|3.68|replicated
2350.88|2.88|sorry the layer is partitioned across
2352.64|2.959|all cores
2353.76|4.079|just like in the data parallelism
2355.599|5.201|scenario
2357.839|6.321|and so finally we have uh the rightmost
2360.8|5.36|column which is um
2364.16|4.0|i guess yeah that's the setup used in
2366.16|4.48|the switch transformer paper for the
2368.16|5.04|larger models
2370.64|4.64|and so here for the model
2373.2|4.399|partitioning each expert this partition
2375.28|4.16|across multiple cores so in that example
2377.599|4.801|we have four experts
2379.44|4.72|each partition across four cores
2382.4|2.719|and the data is replicated across
2384.16|2.64|multiple
2385.119|3.121|cores and partitioned across data
2386.8|3.36|parallel cores
2388.24|3.359|so that's a that's a little bit um you
2390.16|3.6|know complex too
2391.599|4.161|to understand already but the sweet
2393.76|6.319|transformer paper has a nice the same
2395.76|7.04|figure with a nice caption to explain it
2400.079|4.401|and yeah maybe we can um
2402.8|4.319|you know about it we can add something
2404.48|5.119|quickly about how this is implemented in
2407.119|4.641|practice
2409.599|3.361|so
2411.76|5.359|there's this paper called mesh
2412.96|6.24|transformer which kind of extends
2417.119|6.561|batch or data parallelism to more
2419.2|6.32|general purpose spmd style programming
2423.68|3.76|and so different labs have different you
2425.52|3.839|know frameworks but this paper kind of
2427.44|2.879|lays the foundation for
2429.359|3.201|um
2430.319|3.201|general spmd distributed computing which
2432.56|4.24|is
2433.52|5.92|required for training large-scale models
2436.8|5.36|and so under the the mesh abstraction
2439.44|4.56|basically we have a mesh of processes
2442.16|5.04|um
2444.0|5.2|which ha and so that mesh has dimensions
2447.2|5.2|name dimensions and these name
2449.2|5.04|dimensions specify how
2452.4|3.919|the tensor dimensions will be
2454.24|3.92|partitioned or replicated across the
2456.319|4.321|mesh dimensions
2458.16|3.919|and so just that simple abstraction um
2460.64|4.0|sort of supports you know data
2462.079|5.76|parallelism also model parallelism and
2464.64|5.84|especially expert parallelism uh at once
2467.839|4.401|and so you know i invite whoever is
2470.48|3.359|interested to to also check that paper
2472.24|2.879|because that's kind of
2473.839|2.321|um
2475.119|2.561|you know that kind of lays the
2476.16|4.48|foundation for understanding these
2477.68|5.12|things
2480.64|3.6|all right barry's want to go cool yeah
2482.8|3.039|so next we're going to kind of talk
2484.24|2.96|about like how we take these parallelism
2485.839|4.161|strategies and like kind of combine them
2487.2|4.639|together to make like a a 1.6 trillion
2490.0|5.04|parameter sparse model
2491.839|5.201|so next slide
2495.04|4.4|so so here so what we ended up doing in
2497.04|4.48|this work was we had we um
2499.44|3.84|trained two different very large sparks
2501.52|4.079|models and we compared them to the
2503.28|4.48|largest t5 model so we can see the t5
2505.599|4.401|xxl which is a dense model and it was
2507.76|4.72|the largest one trained in the p5 paper
2510.0|3.68|and it has around 13 billion parameters
2512.48|3.04|and here we list a lot of the model
2513.68|3.52|dimensions like the model dff which are
2515.52|3.839|just like you know the various sizes and
2517.2|3.919|shapes of the of the tensors and stuff
2519.359|3.601|the number of layers the number of heads
2521.119|4.321|and importantly we also mentioned the
2522.96|5.76|negative log perplexity
2525.44|4.96|um at step 250k and at 500k
2528.72|4.08|and so yeah so we designed two sparse
2530.4|4.24|models to test and i have to test like
2532.8|4.559|how scaling
2534.64|4.719|versus sparsity versus scaling versus
2537.359|4.24|sparsity and flops work
2539.359|3.601|so first let me talk about switch xl so
2541.599|5.441|that has the same amount of flops per
2542.96|6.24|token as t5x xl but has 64 experts and
2547.04|3.6|this leads it to have around 400 billion
2549.2|3.28|parameters
2550.64|3.12|and we can see that on a step basis it
2552.48|4.08|actually performs quite well and
2553.76|4.4|outperforms the t5 xxl by like quite a
2556.56|3.44|good margin
2558.16|3.76|interestingly though our the third model
2560.0|4.079|we designed switch c which has 1.6
2561.92|4.08|trillion parameters but has
2564.079|4.24|significantly fewer flops almost 10 less
2566.0|4.4|flops per token than either of the above
2568.319|4.561|two models so it's really trading by
2570.4|3.919|reducing flops that have way more sparse
2572.88|3.439|parameters
2574.319|4.401|and we can see on a step basis
2576.319|4.081|the the switch c model uh works well but
2578.72|2.879|not not as well as actually the higher
2580.4|3.919|flop model
2581.599|4.561|but on uh like a kind of a pareto axis
2584.319|4.241|where we're looking at tpu hours on the
2586.16|4.08|x-axis and not step the switch c model
2588.56|4.48|actually outperforms them both by like a
2590.24|4.24|pretty large margin so for pre-training
2593.04|2.88|performance we're seeing that actually
2594.48|3.599|just like having a lot of sparsity and
2595.92|3.76|less flops is actually um can be quite
2598.079|3.601|good
2599.68|4.159|next slide
2601.68|3.36|yeah and so yeah this so again those two
2603.839|3.121|sparse models are kind of really trying
2605.04|3.92|to get at this hypothesis that actually
2606.96|3.68|gnome shazier had which is you know
2608.96|3.2|that you know parameters are good for
2610.64|4.64|more knowledge
2612.16|4.56|reasoning and compute aka flops is good
2615.28|2.48|for intelligence
2616.72|2.8|and so we're going to kind of try to get
2617.76|3.839|at that by taking these different sparse
2619.52|3.68|models and then fine-tuning them on uh
2621.599|2.961|different tasks some of which require
2623.2|3.68|more like knowledge and then others
2624.56|4.16|which require more of like reasoning
2626.88|3.92|for whatever like handwave definition we
2628.72|4.56|want to give that
2630.8|4.319|so yeah so for a fixed oh go back so
2633.28|3.68|yeah so for a fix
2635.119|4.561|oh can you go back to the previous slide
2636.96|5.2|oh yes sorry okay so for a fixed quality
2639.68|4.399|on an upstream pre-training task
2642.16|2.959|um yeah do parameters independently
2644.079|2.641|matter
2645.119|3.041|so we're going to look at two tasks here
2646.72|3.119|one of which is super glue which is kind
2648.16|3.52|of our like reasoning task and then
2649.839|2.961|another is like trivia qa which is like
2651.68|2.8|some knowledge task where it's like you
2652.8|4.64|just give it a question you have it
2654.48|2.96|output an answer
2658.0|2.319|okay
2659.04|3.2|and so here we're going to take a look
2660.319|3.52|at super group quality so we can see on
2662.24|3.92|the x-axis is the pre-training
2663.839|4.881|performance and the y-axis is the super
2666.16|4.24|glue score after fine-tuning
2668.72|4.16|and interestingly we can see definitely
2670.4|4.32|that the sparse models definitely are
2672.88|3.439|for a fixed
2674.72|3.52|pre-training perplexity do worse on
2676.319|3.841|fine-tuning this can be especially
2678.24|3.599|noticed at like the upper right portion
2680.16|4.0|of the plot where the dense models are
2681.839|4.961|definitely fine-tuning better than the
2684.16|4.48|their sparse counterpart
2686.8|3.84|next slide
2688.64|3.84|interestingly when we study it on the
2690.64|3.76|more knowledge-heavy tasks the sparse
2692.48|4.4|model for a fixed uh pre-training
2694.4|4.08|perplexity does disproportionately well
2696.88|2.959|so you know for a model that roughly has
2698.48|3.28|the same perplexity we're getting like
2699.839|3.841|really large boosts for these
2701.76|3.839|knowledge-heavy tasks so this is pretty
2703.68|3.439|interesting and it also really
2705.599|3.76|you know shows some of the dangers of
2707.119|3.441|comparing only on your pre-training
2709.359|3.041|metrics so these models you know can
2710.56|3.759|have the same exact preaching metric but
2712.4|3.6|very different um
2714.319|4.0|you know properties when fine-tuning
2716.0|4.72|them on different tasks
2718.319|4.721|next slide
2720.72|5.28|and interestingly so yeah all of the
2723.04|4.96|switch models here are the um are just
2726.0|3.76|like you know various models
2728.0|4.48|that have still a good amount of flops
2729.76|4.16|but the red model is actually the 1.6
2732.48|3.68|trillion parameter
2733.92|3.28|sparse model that has you know very few
2736.16|2.56|flops
2737.2|3.44|but a lot a lot of parameters and we can
2738.72|3.76|see that as the red dot here and it does
2740.64|3.76|actually disproportionately bad compared
2742.48|3.92|to other sparse models that also have
2744.4|3.6|pretty good perplexities and so yeah
2746.4|3.76|it's uh it's definitely very interesting
2748.0|3.2|and it shows that you know for models
2750.16|3.04|during pre-training that have a lot of
2751.2|4.399|sparsity they definitely suffer on some
2753.2|4.48|of these more reasoning heavy metrics
2755.599|3.921|but do disproportionately well for more
2757.68|4.399|of these knowledge-heavy tasks
2759.52|4.0|uh next slide
2762.079|3.28|yeah and so here we can see it as just
2763.52|3.92|like a huge outlier
2765.359|2.801|for a pre-trained perplexity doing like
2767.44|3.36|just
2768.16|4.959|incredibly well on this uh downstream
2770.8|4.64|question answering task
2773.119|4.321|next slide
2775.44|3.52|yeah okay so also you know one thing
2777.44|3.679|that we were gonna do is just look at
2778.96|3.76|the fine-tuning properties of sparse
2781.119|3.441|models across like a few scales and just
2782.72|4.32|see how they perform
2784.56|2.48|next slide
2787.2|3.28|yeah and so here we try two different
2788.64|3.76|models one is um
2790.48|3.359|t5 bass and then we make a flop match
2792.4|2.959|sparse counterpoint and when they say
2793.839|2.801|flat matched it's like you know each
2795.359|3.361|token will have the same amount of flops
2796.64|3.439|but now we just have experts so we do
2798.72|3.359|this for both base and large and we see
2800.079|4.881|that actually across almost all tasks
2802.079|4.881|besides two arc tasks the sparse models
2804.96|3.28|perform quite well which is which is
2806.96|3.359|definitely promising so we are seeing
2808.24|3.359|that these models are pretty robust they
2810.319|4.081|pre-train well and then they also
2811.599|4.561|fine-tune well when scaled appropriately
2814.4|2.88|by scaling up both the flops and
2816.16|2.56|sparsity
2817.28|2.96|whereas you know the negative results
2818.72|3.28|we've really seen are like yeah when you
2820.24|3.599|just have a huge amount of sparsity and
2822.0|4.319|not too many flops
2823.839|2.48|next slide
2826.8|3.6|yeah and one also thing we wanted to
2828.319|3.841|look at was uh the multilingual training
2830.4|3.52|so we were previously studying all of
2832.16|3.52|this on like english only and we also
2833.92|3.52|wanted to see how sparsity helps in the
2835.68|2.96|multilingual setting because you know we
2837.44|2.639|also felt like this would be a very
2838.64|2.88|natural place for sparse city to work
2840.079|3.76|well where potentially experts could
2841.52|4.96|specialize across languages
2843.839|3.841|and we do see strong results so on 91 of
2846.48|3.359|the languages
2847.68|3.84|i think of like around 100 languages we
2849.839|2.401|see over like at least the forex speed
2851.52|2.88|up
2852.24|3.599|over the mt5
2854.4|2.439|dense model
2855.839|2.801|next
2856.839|4.361|slide
2858.64|5.76|you want to go ahead
2861.2|4.48|uh no go go ahead okay yeah so
2864.4|2.0|another thing we wanted to talk about
2865.68|3.2|was
2866.4|4.48|distillation so one downside of these
2868.88|3.6|sparse models is that they'll have a lot
2870.88|2.719|more parameters which means that you
2872.48|2.8|know if you're serving these things or
2873.599|3.361|something you either need like high
2875.28|3.12|throughput use cases
2876.96|3.52|or you need to maybe distill it back
2878.4|3.6|down into like a smaller dense model
2880.48|3.2|so here what we do is we look at like
2882.0|3.599|the t5 base and switchbase and we look
2883.68|3.84|at its pre-training performance and then
2885.599|3.201|we go through some ablations of
2887.52|3.2|different distillation techniques and
2888.8|4.88|find that like with the best techniques
2890.72|4.56|we can keep around 30 of the quality
2893.68|5.159|improvements of sparsity while
2895.28|7.52|distilling it back down into its dense
2898.839|3.961|counterpart so next slide
2903.599|3.281|yeah and then we kind of study this
2905.2|3.76|across multiple scales and again we see
2906.88|4.16|like around like 30 to 40 percent of the
2908.96|4.48|gains can be um
2911.04|3.92|like you know kept when going from a
2913.44|2.8|dense mod when going from you know a
2914.96|3.44|sparse model distilling it back down
2916.24|3.599|into like its flop match dense model so
2918.4|3.52|you can get you know
2919.839|3.52|get rid of up to 99 of the parameters
2921.92|3.76|and still keep like around 30 of the
2923.359|6.72|improvements which is very promising
2925.68|6.0|next slide wait i'm sorry yeah
2930.079|3.361|all right sorry about that can you say
2931.68|4.08|that last sentence again you said that
2933.44|4.48|you can keep the benefit 30 of the
2935.76|4.4|teachers benefit
2937.92|3.28|yeah basically so yeah you you yeah
2940.16|2.32|exactly
2941.2|3.04|yeah
2942.48|3.119|yeah so we're looking at like yeah you
2944.24|3.52|train a sparse model and then you
2945.599|4.081|distill it back onto a dense model
2947.76|3.599|and you're versus training a dense model
2949.68|3.12|from scratch and like you look at the
2951.359|4.401|gap between the sparse and dense model
2952.8|4.96|from scratch versus the the the gap
2955.76|4.079|between the dance and the distilled
2957.76|4.4|dance model
2959.839|2.321|what do you mean
2962.319|4.321|you go forward
2964.8|3.039|oh yes yeah
2966.64|3.36|oh yeah maybe let me just do like a
2967.839|3.681|quick high level summary again so yeah
2970.0|4.319|what we'll do is for our comparisons is
2971.52|5.12|we'll train a dense model from scratch
2974.319|3.841|we'll train a sparse model from scratch
2976.64|3.439|and then we'll also run a third
2978.16|5.439|experiment where we distill that sparse
2980.079|5.361|model down into a dense model
2983.599|3.921|what does distilling mean
2985.44|4.24|like we're basically trying to match the
2987.52|3.52|uh like the teacher's logits
2989.68|3.439|like the kind of standard thing of like
2991.04|3.279|you know like matching the like either
2993.119|2.48|the logits or like the soft
2994.319|4.681|probabilities for each token or
2995.599|3.401|something like that
3003.52|3.52|okay if i can jump in with my question
3005.2|3.28|so what i'm struggling with is how do i
3007.04|4.559|interpret the line that says percent of
3008.48|3.119|teacher and performance
3011.76|4.4|yeah okay so it's basically looking at
3013.92|3.679|the like the gap between the dense and
3016.16|3.12|sparse model
3017.599|2.881|so we'll have the dense model get some
3019.28|3.76|performance we'll have the sparse model
3020.48|4.56|get some performance and then the um the
3023.04|4.0|dense model is still from the sparse
3025.04|4.799|model be somewhere in between that that
3027.04|5.039|range and we're basically saying it's 30
3029.839|3.841|through that range so it's like in like
3032.079|3.201|a zero one interval it's like point
3033.68|3.919|three of the way from the dense to the
3035.28|3.839|sparse model i see so this is not saying
3037.599|3.52|that the percent of teacher performance
3039.119|4.48|does not mean that if the teachers say
3041.119|4.0|it's if we use the teacher's uh uh
3043.599|2.72|guesses or predictions as the ground
3045.119|3.281|truth this is not saying that the
3046.319|4.721|distilled model gets matches with the
3048.4|4.4|the teacher 33 of the time
3051.04|3.519|no no exactly it's basically saying you
3052.8|3.84|get like 30 of the the quality
3054.559|3.52|improvements yeah exactly okay cool um
3056.64|2.479|and then if we can back up the slide i
3058.079|2.801|had a different question but i didn't
3059.119|2.96|want to interrupt um
3060.88|3.04|when we were talking about all of these
3062.079|3.361|different t5 bases and then also on this
3063.92|3.36|a few slides before this
3065.44|4.32|i don't know that much about t5 i'm
3067.28|5.12|curious to know when t5 is trained is
3069.76|3.92|there a weight penalty in the lost
3072.4|3.52|function
3073.68|4.159|is there a weight decay turn
3075.92|4.159|no there's no weight decay trained with
3077.839|4.321|any of those sparse or dense models i
3080.079|4.24|see so out of curiosity then how do
3082.16|4.56|dense models perform compared to the
3084.319|4.321|switch model if you add some sort of
3086.72|5.2|weight regularization that incentivizes
3088.64|3.28|getting rid of useless weights
3092.559|3.441|oh so some kind of like maybe like l1
3094.319|3.28|term or something like that yeah so i'm
3096.0|2.72|just wondering like how much of because
3097.599|2.72|here we're talking about the benefits of
3098.72|3.68|sparsity and i'm wondering how much of
3100.319|4.081|this benefit from sparsity is due to the
3102.4|3.28|fact that just some of this i mean
3104.4|2.719|effectively what the switch model is
3105.68|2.8|doing if i understand correctly maybe i
3107.119|3.361|don't what i understand is that the
3108.48|4.16|switch model the feed forward layer it's
3110.48|5.52|just like you you fixing the weight to
3112.64|4.8|be zero that's what it means to be smart
3116.0|3.119|well actually we're kind of really
3117.44|3.119|trying to like inject more weights so
3119.119|2.801|we're actually kind of trying to do it's
3120.559|2.481|a little bit maybe like paradoxical
3121.92|3.12|because we're saying switch transformer
3123.04|3.279|but our idea is to be like hey we
3125.04|2.88|actually want to just have significantly
3126.319|3.361|more weights
3127.92|4.159|not less it's kind of like you you would
3129.68|4.24|zero out weights but within a
3132.079|3.841|much larger weight matrix if that makes
3133.92|3.36|sense i see yes and so to me it seems
3135.92|2.8|like a relevant bass line to just ask
3137.28|3.12|what happens if i have the dense matrix
3138.72|3.92|but i incentivize it would say an l1 or
3140.4|4.64|l2 penalty on the weights and i would be
3142.64|3.919|curious to know how that compares
3145.04|2.88|yeah we didn't run this but also that
3146.559|4.081|kind of gets rid of weights for the
3147.92|5.6|dense model so if anything
3150.64|4.32|so yeah
3153.52|5.039|yeah and the last point is like if you
3154.96|4.8|just add like an l1 penalty loss um
3158.559|2.721|you're not gonna have structured
3159.76|3.04|sparsity
3161.28|3.039|whereas like here we
3162.8|4.0|you know
3164.319|4.24|it's not random weights in your giant
3166.8|3.6|weight matrix there are zero that right
3168.559|3.681|it's like really like blocks depending
3170.4|2.88|uh like blocks corresponding to each
3172.24|4.4|expo
3173.28|5.76|right so that that structure allows the
3176.64|4.88|the whole like communication stuff and
3179.04|4.24|and that that's
3181.52|3.92|yes what leverage is the fact that you
3183.28|3.52|have multiple calls and so on right so i
3185.44|2.879|i totally agree with that block
3186.8|2.88|structure and and that's what i'm trying
3188.319|3.441|to say is that the switch has this very
3189.68|3.6|rich it's it's not just sparse it also
3191.76|3.359|has this rich structure and what i'm
3193.28|3.36|trying to do in my mind is disentangle
3195.119|3.121|is the sparsity what's offering an
3196.64|3.439|advantage or is this additional
3198.24|3.359|structure that you built in is that what
3200.079|3.28|is the performance
3201.599|3.921|so that's why i'm asking
3203.359|5.121|so so the the
3205.52|4.88|the block structure is what
3208.48|4.72|enables to leverage the fact that you
3210.4|4.08|have multiple calls like if you if you
3213.2|3.52|didn't have that block structure you'd
3214.48|4.16|still have to route to everything
3216.72|4.48|and so you have more communication costs
3218.64|4.24|and so on so um and then your first
3221.2|3.04|question was what sorry
3222.88|2.4|i'm not actually sure if there was a
3224.24|2.8|question i guess what i'm trying to say
3225.28|3.68|is i'm trying to disambiguate yeah
3227.04|3.279|anyways
3228.96|3.44|but i agree it's a little bit weird
3230.319|3.841|because sparsity kind of
3232.4|3.52|there's like a spectrum of meaning for
3234.16|3.6|sparsity right was like for example
3235.92|4.08|compression and
3237.76|3.52|like model pruning is a form of sparsity
3240.0|3.839|but also
3241.28|4.88|uh sweet transformer and emily also
3243.839|3.921|referred to as sparsity and
3246.16|3.52|that kind of related but definitely
3247.76|3.28|they're aiming at different things so
3249.68|4.0|this is a really interesting idea of
3251.04|3.76|it's sparse but you have more parameters
3253.68|2.08|i'll have to think about it more thank
3254.8|3.2|you
3255.76|4.48|yeah yeah like it's kind of like spots
3258.0|3.44|within this like giant weight matrix
3260.24|1.92|which is
3261.44|3.52|yeah
3262.16|4.8|yeah yeah i hadn't appreciated that so i
3264.96|4.159|appreciate you you pointing that out
3266.96|4.159|thank you
3269.119|3.121|i have a follow-up question distillation
3271.119|4.081|part
3272.24|4.8|yeah of course okay so if you distill it
3275.2|3.599|back down now you have like one
3277.04|4.4|technically you're back to the dense
3278.799|3.601|layer architecture right
3281.44|3.44|um
3282.4|4.24|so now the entire like the entire idea
3284.88|3.52|of expert is that certain tokens would
3286.64|3.439|be sent to different experts because
3288.4|3.52|they just like i don't know are more
3290.079|3.201|specialized in figuring something out
3291.92|3.52|about this token
3293.28|4.24|um so now if you go back to this like
3295.44|4.48|dense layer
3297.52|4.72|like aren't you like basically only
3299.92|5.52|serving whatever
3302.24|5.359|like um whichever expert you base the
3305.44|4.0|stance later on like these tokens will
3307.599|3.681|probably perform well and all the other
3309.44|4.08|tokens are kind of like left behind
3311.28|2.24|right
3316.559|3.28|i'm actually sorry i don't think i'm
3318.0|3.28|fully understanding your question so
3319.839|3.361|that so are you kind of getting at like
3321.28|2.64|we're displaying this on a specific data
3323.2|1.599|set
3323.92|2.56|so
3324.799|2.881|that i'm thinking about how to use that
3326.48|2.079|like why
3327.68|2.72|yeah
3328.559|3.28|yeah yeah so maybe concretely like let's
3330.4|2.64|so like for super glue right let's say
3331.839|3.441|you want to serve a model that does
3333.04|3.92|super glue well i think the idea is that
3335.28|3.839|like you distill the sparse model into a
3336.96|4.159|dense model on super glue so then you
3339.119|3.521|kind of get this compressed dense model
3341.119|2.96|that now performs better than if you
3342.64|2.56|were to just you know train it from
3344.079|3.04|scratch or train it from like a
3345.2|3.68|pre-trained dense model so then it's
3347.119|3.2|like did you use them
3348.88|4.32|say that again
3350.319|5.201|you you have to pick one expert right no
3353.2|3.599|no you can just distill all of the cause
3355.52|3.039|you're just matching the the model
3356.799|3.28|outputs so you can just treat the sparse
3358.559|2.641|model as kind of like a black box thing
3360.079|2.881|all we're doing is just trying to have
3361.2|4.8|the dense model match the actual like
3362.96|6.0|final like you know token predictions oh
3366.0|4.48|god okay you got it okay sorry i was not
3368.96|3.28|i was not familiar with the idea of the
3370.48|4.16|distillation so i think that was like my
3372.24|5.119|entire confusion okay thanks yeah of
3374.64|4.8|course yeah um
3377.359|4.48|because i i guess
3379.44|4.72|one motivation here is that
3381.839|4.881|um having experts can make serving a
3384.16|4.959|little bit more difficult because
3386.72|4.399|um it requires bigger topologies let's
3389.119|3.041|say you have eight experts
3391.119|2.401|um
3392.16|2.959|you need like
3393.52|4.72|well i guess you can have multiple
3395.119|4.72|experts on on fewer calls but
3398.24|3.28|um
3399.839|4.72|you know legislated a little bit harder
3401.52|4.48|to solve and so if we can you know get
3404.559|3.76|the benefits
3406.0|4.0|from sparsi at pre-training
3408.319|4.881|then use distillation
3410.0|5.2|to a dense model for serving uh that can
3413.2|4.159|be that can be beneficial so i think
3415.2|4.8|that was sort of the motivation for that
3417.359|5.2|experiment right
3420.0|2.559|yeah exactly
3424.48|5.92|uh okay where were we yeah
3428.079|3.04|yes i kind of just wrapping okay go
3430.4|2.959|ahead
3431.119|5.761|no go ahead ben i just said i think uh
3433.359|4.96|one more string kind of question so yeah
3436.88|3.76|so yeah go ahead i feel here to ask
3438.319|4.641|enough oh yeah yeah sounds good um yeah
3440.64|4.0|thank you guys for the talk so far uh
3442.96|2.879|just a quick question was wondering if
3444.64|4.32|you think there are any interesting
3445.839|5.76|directions around uh building models
3448.96|6.399|that are like explicitly optimized for
3451.599|5.921|for parallel training um i guess like
3455.359|4.161|the the moe model seems like you know it
3457.52|4.16|does a really good job here and also
3459.52|4.48|like at inference time it's you know
3461.68|6.24|very useful to like you know have fewer
3464.0|7.28|uh flops per per computation um
3467.92|4.399|but for forward pass but um i i guess do
3471.28|3.44|you think there are any interesting
3472.319|3.921|directions around distributed training
3474.72|3.28|where you might have like models that
3476.24|3.599|are explicitly
3478.0|3.599|are architected to
3479.839|4.641|have a lot of uh
3481.599|4.881|parallel heads or or other like
3484.48|4.639|features that are you know kind of
3486.48|5.359|embarrassingly parallelizable or does
3489.119|4.96|just using like standard you know
3491.839|3.361|scale up the models by adding more
3494.079|2.561|layers
3495.2|3.52|and then just you know get away with
3496.64|3.76|using model and data parallelism work
3498.72|3.44|well enough
3500.4|3.04|yeah so i think so yeah so let me just
3502.16|2.639|make sure i'm fully understanding so
3503.44|3.04|yeah i think also like you know right
3504.799|3.28|now like even our models are definitely
3506.48|3.839|very co-designed with the hardware and
3508.079|4.24|like the shapes and things you know um
3510.319|3.441|so yeah i i think at a high level like
3512.319|3.201|yes i think there's a ton of interesting
3513.76|3.92|research on like co-designing the
3515.52|3.36|hardware the partitioning algorithms and
3517.68|3.04|the models
3518.88|3.6|i think given you know that we have this
3520.72|3.44|kind of like spmd mesh style
3522.48|3.599|partitioning we are already kind of
3524.16|3.52|designing our models in ways that fit it
3526.079|3.28|really well so for example when we want
3527.68|3.439|to scale up our model one of the first
3529.359|3.521|dimensions we go to scale up is the
3531.119|3.041|internal hidden dimension because
3532.88|2.8|there's some really nice properties of
3534.16|2.56|scaling up this dimension it basically
3535.68|2.32|becomes like kind of you know
3536.72|3.2|independent to some of the communication
3538.0|3.68|costs it's really good when looking at
3539.92|4.08|the compute to memory operations on
3541.68|4.159|these you know like uh compute devices
3544.0|3.359|and stuff
3545.839|2.801|yeah exactly like i think when we're
3547.359|2.641|even designing these models we're like
3548.64|2.959|really setting dimensions such that it
3550.0|3.44|maps well onto hardware
3551.599|3.52|um so it's almost like you know given
3553.44|2.96|that we have this model data parallelism
3555.119|3.521|we're like actually
3556.4|3.439|designing models more for it but i also
3558.64|3.199|think that there's a ton of new
3559.839|3.121|interesting distributed algorithms and
3561.839|2.641|stuff like that which makes designing
3562.96|2.879|models very interesting like i think one
3564.48|3.839|thing that i think is really cool is
3565.839|4.081|like the microsoft zero partitioning too
3568.319|2.961|which also like adds some really new
3569.92|3.52|like nice implications for like how to
3571.28|3.519|design and scale models and stuff so
3573.44|3.359|yeah i think there's like this is a very
3574.799|3.921|fruitful research direction
3576.799|2.8|um if that kind of answered your
3578.72|2.32|question
3579.599|3.52|yeah no that was super helpful and
3581.04|3.92|interesting thanks yeah
3583.119|3.921|yeah definitely like i'm very optimistic
3584.96|3.44|on the future of us like designing the
3587.04|2.559|hardware the model the partitioning
3588.4|2.48|strategies all together because really
3589.599|3.441|to get it to work well you kind of have
3590.88|3.6|to know about all three and like kind of
3593.04|6.039|you know intertwine the development of
3594.48|4.599|them yeah yeah that sounds awesome
3600.24|3.28|yeah so just to summarize it's like yeah
3602.0|3.52|so switch transformer is like a nice
3603.52|3.52|simplification over a mixture of experts
3605.52|3.599|and we're seeing that we get really
3607.04|3.759|strong speed up improvements on
3609.119|3.761|pre-training over like a lot of the t5
3610.799|2.961|models which are very strong baselines
3612.88|2.88|we're seeing that we can you know
3613.76|3.599|efficiently distill the sparse models
3615.76|3.599|back to dense ones
3617.359|3.601|and you know get improved both
3619.359|2.96|pre-training and fine-tuning through
3620.96|2.159|some of these newer techniques we talked
3622.319|2.48|about
3623.119|3.44|and we're also seeing that the models
3624.799|3.201|are working on multilingual data and
3626.559|3.52|that we can you know now easily
3628.0|3.76|successfully train up to you know 1.6
3630.079|3.441|trillion parameter models which is
3631.76|4.48|pretty promising
3633.52|3.92|and um next slide and so we also wanted
3636.24|2.64|to go into two slides about some like
3637.44|3.52|newer work about actually using these
3638.88|3.439|kind of models for computer vision and
3640.96|3.119|actually also a little bit of how they
3642.319|4.161|can be used to actually do some level of
3644.079|4.48|like adaptive computation where not only
3646.48|4.0|now each input gets different weights
3648.559|2.961|but also sometimes different inputs will
3650.48|2.48|have different amounts of compute
3651.52|3.039|applied to it
3652.96|4.0|and yeah so there's some really great
3654.559|4.24|work of doing this out of the the google
3656.96|3.76|zurich team and yeah they're just doing
3658.799|3.28|it for image classification and you know
3660.72|2.8|they're basically seeing a lot of the
3662.079|2.961|similar types of scaling properties
3663.52|3.2|where you know scaling up the number of
3665.04|4.079|experts and using sparsity allows them
3666.72|4.0|to get good um performances on image
3669.119|4.401|classification
3670.72|2.8|um next slide
3674.4|3.28|and interestingly one of the things they
3675.92|3.679|do is like as we talk about the capacity
3677.68|4.32|factor so we were talking about values
3679.599|4.72|of like 1 1.25 2.0 which means like at a
3682.0|4.72|value of 2.0 there's buffer for you know
3684.319|4.161|two tokens per expert but they actually
3686.72|3.28|study it going less than one so that
3688.48|2.879|means that like at 0.5 that means
3690.0|2.72|there's only like room for half the
3691.359|3.2|number of tokens
3692.72|3.359|and the nice part is is that they did
3694.559|2.881|this for image classification and also
3696.079|2.48|in images there's just a lot of
3697.44|2.159|redundancy
3698.559|2.56|and they notice that you can actually
3699.599|4.081|get really good performance by only
3701.119|4.801|allowing like you know up to one tenth
3703.68|4.24|of the the parts of the image to be
3705.92|2.96|processed by a sparse layer so yeah we
3707.92|2.96|think this is like a really nice
3708.88|3.679|direction too in terms of combining
3710.88|3.52|sparsity along with like adaptive
3712.559|4.081|computation
3714.4|3.84|and yeah and uh yeah thanks so much for
3716.64|4.24|having us
3718.24|4.24|that's that's the talk
3720.88|3.439|so thank you
3722.48|2.8|uh barrett and
3724.319|3.28|um
3725.28|5.759|sorry are you fun for coming here
3727.599|3.44|uh so you know
3732.16|3.6|uh so i will just like ask a bunch of
3733.92|3.439|questions and then we can have like uh
3735.76|3.76|after the class uh
3737.359|3.68|open question panel for the students
3739.52|3.36|uh so one thing is like have you tried
3741.039|3.441|using like like more like linear
3742.88|3.679|attention mechanisms like reformers and
3744.48|4.639|like other stuff uh to like scale the
3746.559|2.56|computation
3749.52|2.799|um um
3750.88|3.84|i personally have maybe
3752.319|4.961|i haven't personally done this
3754.72|2.56|yes so
3758.16|4.24|oh you know i guess we can maybe comment
3760.079|3.921|on how um
3762.4|3.36|you know the attention
3764.0|3.039|the cost coming from the attention maps
3765.76|3.12|isn't
3767.039|5.121|the dominant costs in
3768.88|4.88|in this large transformers
3772.16|4.24|um so you know the motivation for using
3773.76|3.44|linear attention um like performers is
3776.4|3.439|that
3777.2|5.919|it reduces uh the quadratic cost of
3779.839|4.24|attention that's right um
3783.119|3.121|but
3784.079|4.48|so far i mean at least you know in like
3786.24|4.319|sort of typical nlp setups like super
3788.559|4.56|glue c4 and so on
3790.559|3.76|as you scale the models most of the
3793.119|4.24|memory
3794.319|4.8|comes from the the model weights as
3797.359|2.72|opposed to attention to the attention
3799.119|3.44|maps
3800.079|4.401|that's also because you know using very
3802.559|3.921|long
3804.48|5.119|context or sequence length
3806.48|5.599|doesn't prove that fruitful and so
3809.599|5.2|you know just uh you know working with
3812.079|5.601|the vanilla self-attention mechanism is
3814.799|4.161|uh is a very strong baseline already
3817.68|3.28|got it okay
3818.96|4.0|um so another question is like uh do you
3820.96|3.52|think this uh like mechanism is even
3822.96|3.359|more scalable like can you go on and
3824.48|5.44|build like 10 trillion parameter models
3826.319|5.681|stuff like that like what do you think
3829.92|3.28|yeah definitely i think yeah totally i
3832.0|3.119|think honestly the one of the biggest
3833.2|3.839|constraints is that like you know and
3835.119|3.361|this isn't even necessarily constrained
3837.039|3.201|it's just like you have to fit the
3838.48|3.359|parameter somewhere and there's just
3840.24|3.52|limited storage on devices but if you
3841.839|3.361|get enough devices such that you know
3843.76|3.039|yeah you can just partition the weights
3845.2|3.599|it's like yeah i don't see anything
3846.799|3.76|stopping it
3848.799|3.601|got it so what do you think personally
3850.559|3.361|is your like uh
3852.4|3.36|like the thing like with the direction
3853.92|4.24|like uh like scaling of transformers
3855.76|4.24|will go into like uh will be more like
3858.16|3.28|works that are trying to just like use
3860.0|3.119|transformer like mechanisms like
3861.44|2.96|minister of experts or do you think
3863.119|3.281|there's like you're going to be other
3864.4|3.04|things that the community needs
3866.4|2.639|yeah i mean i definitely think mixture
3867.44|2.8|of experts should find its way or at
3869.039|2.481|least you know sparse players like
3870.24|2.48|switch transformers
3871.52|2.559|will definitely i think find their way
3872.72|2.72|into like the future of large models i
3874.079|2.401|think they really confer a lot of
3875.44|2.879|benefits
3876.48|3.92|and they're also very good in like high
3878.319|4.0|throughput applications so i think the
3880.4|3.04|one thing like so the one downside is on
3882.319|3.04|sparsity is like if you look at the
3883.44|3.2|performance per model weight they're
3885.359|3.521|going to always be worse than bounce
3886.64|3.84|models so it's like if you really are
3888.88|3.84|constrained on like i want to design the
3890.48|3.92|best model i can to fit on as small of a
3892.72|3.04|device as i can then they're probably
3894.4|3.439|not going to be the best solution
3895.76|3.52|because the sparse weights just aren't
3897.839|2.881|as good as just the dense weight that's
3899.28|2.64|being used for everything
3900.72|3.28|so i think it really depends on the
3901.92|3.6|application but i'm very optimistic for
3904.0|2.48|when we're training these models during
3905.52|2.319|pre-training with lots of data
3906.48|3.119|parallelism and then we're serving them
3907.839|3.2|and like medium to higher throughput
3909.599|4.0|examples i feel like they could actually
3911.039|4.401|just be a pretty big win
3913.599|3.44|so that that's kind of my thoughts on on
3915.44|3.04|how i think sparsity will be used in
3917.039|2.721|terms of other things yeah i think i
3918.48|2.559|don't know there's a ton of exciting
3919.76|2.64|research you know from everything from
3921.039|3.681|yeah like a lot of the linear attention
3922.4|4.48|stuff adaptive computation new
3924.72|3.599|pre-training objectives you know yeah
3926.88|3.439|it's hard to know what the future will
3928.319|3.681|look like but uh yeah a lot of exciting
3930.319|4.161|things to look forward to
3932.0|4.48|it sounds good okay uh so we can now
3934.48|5.639|have like a round of student questions
3936.48|3.639|so we'll just stop the recording