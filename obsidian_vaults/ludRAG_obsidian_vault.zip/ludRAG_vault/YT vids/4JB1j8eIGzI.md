start_time|end_time|text
0.74|3.36| So yeah, in this video, I want to briefly talk about how the
4.14|3.88| perceptron and linear regression are related to each other. So
8.02|2.6| you can think of linear regression as a single layer
10.78|3.04| neural network. And I think since you all hopefully know
13.82|2.28| linear regression, this will make things a little bit easier
16.1|3.28| when we talk about gradient descent. And also from there,
19.38|3.6| it's very easy to go to the edeline. So to the adaptive
22.98|2.84| linear neuron. So in this video, I want to just briefly outline
25.82|3.88| this relationship before we talk more about that in the following
29.7|5.44| videos. So here's again, a sketch of the perceptron
35.14|2.88| algorithm, where we have multiple things going on. First,
38.02|4.76| we compute the net input based on the features of the data set,
43.22|3.28| and the weights. And then there's also the bias unit. So
46.94|4.24| we have the net input that we compute. And then we send this
51.18|3.52| general model, we have an activation function here. And in
54.7|3.12| the case of the perceptron, this was the so called threshold
57.82|3.56| function where we had, if you think of it as a threshold, we
61.38|6.52| had like this threshold function, if the net input z is
67.9|4.36| greater than zero here, then it returns a one and otherwise it
72.26|3.44| returns a zero. So if z is greater than zero, then return a
75.7|3.68| one, otherwise a zero, that was our activation or threshold
79.38|4.82| function. In the case of linear regression, we don't have such a
84.2|4.44| prediction, we only return a continuous value. So we don't
88.64|4.26| have a threshold for zero and one. And you can think of it
92.9|3.6| then as this activation function here in the perceptron or
96.5|4.02| threshold function being the identity function. So not doing
100.52|3.18| anything, an identity function is just a pass through, it's
103.7|4.5| just returning the inputs of the input is x to this function, it
108.2|4.76| will also return x. So in this case, in linear regression, the
112.96|3.02| same concept applies as in the perceptron here. So the same
115.98|7.08| computation of the net input, which was just multiplying the
123.06|4.92| weights with the features and then adding the bias unit. So
127.98|6.64| that is our net input. And yeah, this is also how the prediction
134.62|5.12| and linear regression is created. So yeah, in that way,
139.74|3.38| you can think of linear regression as a linear neuron, a
143.12|5.18| single layer neural network. And in earlier statistics classes,
148.7|3.54| I'm pretty sure you covered this. So you probably fit a
152.24|3.68| linear regression model, like this, like shown below using
155.92|2.96| these so called normal equations, which are an
158.88|3.14| analytical solution to the minimization problem in least
162.02|3.8| squares linear regression. So when you wanted to minimize the
165.82|4.92| square square error, you could compute or you could find a
170.74|4.72| model that minimizes the square error by using these so called
175.48|4.7| normal equations. So you have if this is your design matrix x
180.18|7.48| transpose x inverted, so inverse here, times x transpose y, if
187.66|5.24| you do that. And if you include an additional vector of ones,
192.9|4.2| assuming that the bias unit is included in w. So if I go back
197.1|2.8| one slide, remember, in the perceptron lecture, we had this
199.9|4.28| alternative formulation, where we didn't have a separate bias
204.18|5.56| unit, we have one here. And then we had the weight zero. If you
209.86|5.68| assume this, if you add this one to the inputs, then the bias
215.54|4.68| unit will be included in this w. So with this set of this
220.22|3.16| of this equation here, you can actually solve for the
223.38|3.96| parameters for linear regression in an optimal way. But yeah,
227.34|3.0| this is not what we will be doing in this class. In this
230.34|3.4| class, we will be talking about a different type of algorithm
233.74|5.92| that can also find these parameters. Yeah, to just
239.66|3.96| summarize what I said in the previous slides. So these normal
243.62|4.72| equations here are really the recommended approach for least
248.34|2.76| squares linear regression. This is something I would use on a
251.1|2.92| data set. There might be one little caveat, if you have a
254.02|4.04| very large data set, then this matrix on inverse here could
258.06|4.0| become problematic for computer memory. But yeah, honestly, I
262.06|2.6| think most data sets are in on most data sets, it would be
264.66|3.08| fine. So this is what I would be using for linear regression
267.74|4.48| practice. However, I am going to introduce or we are going to
272.22|3.16| learn about a different way for learning these parameters
275.38|3.8| iteratively. And the reason why we do that is because that's
279.18|3.52| what we are doing in deep learning, or for deep neural
282.7|3.76| networks, where we have large data sets, many connections,
286.46|4.24| that is many neurons, and also non convex loss functions. So
290.7|3.6| for deep neural networks, there is no closed form solution or
294.34|2.8| analytical solution. So that way, we have to be a little bit
297.14|3.56| creative and use this iterative way. And I think really,
300.7|3.12| because you're already familiar with linear regression from
303.82|3.2| other statistics classes, that using linear regression to
307.02|2.44| introduce this algorithm will make things a little bit
309.46|4.4| easier. So I will introduce the iterative algorithm in the next
314.14|3.72| video. And then we will talk about some calculus concepts and
317.86|16.64| then see how it works in practice.