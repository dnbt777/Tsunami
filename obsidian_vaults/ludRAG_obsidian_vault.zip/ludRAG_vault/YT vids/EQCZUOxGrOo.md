start_time|end_time|text
1.32|3.36| Alright, reinforcement learning, the third sub category of
4.68|3.32| machine learning. And of course, you can also use deep learning
8.0|2.92| for reinforcement learning. But also don't worry about it too
10.92|3.28| much, because this is another topic that we won't cover in
14.2|3.2| this course. It's because yeah, reinforcement learning is
17.4|3.92| really a long and big topic by itself. And you can have a
21.32|3.54| separate whole course and multiple textbooks on that
24.86|3.42| topic. I have a chapter on reinforcement learning for
28.28|2.92| beginners in my Python machine learning book, it's like 30 or
31.2|3.24| 40 pages long, if you're really interested in reinforcement
34.44|3.12| learning with deep learning. However, like I said, in this
37.56|4.1| class, it won't be a topic. But just for completeness, because
41.66|3.3| it's still maybe interesting to briefly talk about it in two
44.96|4.12| slides, how reinforcement learning works. So reinforcement
49.08|4.4| learning is about learning a series of actions. So here, in
53.48|4.2| this case, on this is our drug design problem, where we want to
57.68|3.68| design a small molecule. So let's say we have our current
61.36|2.12| state. So that's usually a current state in the
63.48|4.52| environment. So the current state is that we have this
68.12|4.72| benzene ring here, and the agent sees this current state and then
73.0|3.48| has to take an action on it. So here, the action would be to add
76.48|5.2| this small chemical group to it. So this methyl group to the
81.68|4.12| benzene ring, and this will be then updating the environment.
85.8|5.36| And that will be updating the new next state. So it will then
91.16|3.44| look like that. So we'll have the benzene ring with a methyl
94.6|5.42| group attached. So the agent is the part of the reinforcement
100.02|4.96| learning program that updates the current state, and it has
104.98|4.46| access to the environment. So and it takes one of the possible
109.44|3.72| actions. And that will be also a reward for taking this action
113.16|3.84| and modifying this environment. So this is like going over
117.04|2.88| multiple rounds until you would have, for example, a complete
120.12|4.08| small molecule. And in other areas, you can also think of
124.56|2.72| designing a chess game with reinforcement learning where
127.92|3.64| each move in on the chessboard would be one action taken by the
131.56|5.76| agent. And then you take these multiple actions, and there will
137.32|3.56| be a delayed reward. In the end, it's about winning or losing
140.88|4.96| the game. And then based on that you optimize taking these
145.84|4.76| actions. So maybe a more concrete example would be
150.6|4.28| StarCraft two. So that's a video game. You probably I'm not sure
154.88|3.76| maybe maybe you haven't maybe have played it. I actually played
158.64|4.16| it I think back in undergrad long time ago. But yeah, it's a
162.8|2.92| game where there are a lot of things going on at the same
165.72|4.44| time. It's very complex, lots of things, lots of possible actions
170.16|3.28| you can take at any given moment. And recently, a few
173.44|5.56| years ago, DeepMind started working on designing reinforcement
179.0|5.0| learning for StarCraft. So here, of course, the goal is not to
185.52|3.12| design the world best StarCraft player. I mean, it's a sub goal,
188.64|3.34| but ultimately, you want to develop reinforcement learning
191.98|3.14| systems that can generalize to other things, maybe self
195.12|2.64| driving cars, other more important things. But yeah,
197.76|2.6| impressively, I think the current state of the art in
200.36|4.44| StarCraft two is that they were able to beat most of the world's
205.04|2.8| best players, human players. So it was actually pretty
207.84|3.42| impressive, given how complicated this game is, so
211.26|4.62| many different actions going on and things going on. So in that
215.88|3.88| way, yeah, that was actually pretty, pretty impressive. All
219.76|3.08| right. So yeah, this was just a short note on reinforcement
222.84|3.44| learning. But like I said, we won't be going into too much
226.28|2.04| detail in this class about reinforcement learning.