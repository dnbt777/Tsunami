start_time|end_time|text
0.2|3.0| Yeah, let's talk about some other ways we can use for
5.2|2.76| Yeah, let's talk about some other ways for dealing with
7.96|3.72| overfitting. For instance, if collecting more data is not
11.72|3.32| feasible, and if data augmentation only gets you so
15.04|4.6| far. So one way would be reducing the network's capacity
19.64|5.38| by other means. I decided not to do an extensive slide on that
25.02|3.54| because we discussed several techniques already in that
28.56|4.4| overview video I made with a mind map. And also, to be
32.96|3.36| honest, the really most exciting topic here is dropout. So I
36.32|3.76| don't want to spend too much time on other techniques at this
40.08|3.88| point. I will briefly talk about early stopping though. And then
43.96|3.84| in the next video, I will also talk about to regularization,
47.8|4.52| which are two ways that allow us to reduce the capacity. So
52.44|3.72| capacity is essentially an interesting term, it refers
56.16|5.08| really to the ability of the network to fit complex
61.24|4.16| functions. So like the you can think of it as the complexity of
65.4|4.48| the decision boundary. So adding a penalty against complexity,
69.88|2.74| that's essentially what L two regularization is, it helps
72.62|3.9| reducing the capacity, but also, let's say adding noise via
76.54|4.06| dropout also reduces the capacity in a way. So all these
80.6|2.48| kind of topics are kind of related. So in this video, we
83.08|3.32| will mainly focus on early stopping. And in the next video,
86.4|4.32| we'll explain regularization. Yeah, and as far as early
90.76|3.4| stopping is concerned, so there's a general strategy here.
94.48|3.4| So this is usually something I always recommend when you work
97.88|4.44| in deep learning, you split your data set into three parts of
102.36|3.8| large training sets. And the second largest chunk should be
106.16|4.28| your data set for testing, and then a smaller validation set
110.44|3.04| that you use for model tuning. And the test set should only
113.48|4.48| ideally used once and the very end. Once you Yeah, you found
117.96|2.4| your model, you are happy with it by tuning it on the
120.36|3.2| validation set, then you use your test set to evaluate the
123.56|3.32| final performance of this model. And the other validation set is
126.88|3.52| essentially for tuning the model. But then you can also use
130.4|2.8| it, of course, for early stopping, that's part of the
133.2|3.56| tuning, essentially. So last week, I showed you some real
136.76|5.6| data, like the training, or the epochs and the accuracy, we
142.36|3.4| also did the same for the loss. So you can also do that for the
145.76|4.48| loss. Here, just for the sake of keeping things simple, I'm just
150.24|5.84| showing you an idealized drawing of that. So I'm really stopping
156.08|4.32| is essentially a method for looking at the training and
160.4|4.4| validation set performance. And you from there, you try to deduce
164.8|3.36| a good point for stopping the training, for instance, you may
168.2|5.68| see that the validation accuracy goes up. So the validation set
174.04|2.92| serves as a way of estimating the generalization performance,
176.96|3.48| you can say the generalization performance improves up to a
180.44|2.56| certain point where you find that the validation set
183.0|3.88| performance goes down again. So in that way, training longer
187.0|3.72| may make your performance worse. However, there might be some
190.72|3.42| exceptions sometimes like we've seen in the double descent
194.14|3.38| paper last week. But in general, there might be something like
197.8|3.52| this where you find that if you stop the training early, actually
201.32|4.56| get a better performance. In practice, this method is not
206.04|3.36| super common anymore. I mean, it's not totally uncommon to do
209.4|5.56| that. But I would say first try that either L two regularization
214.96|4.14| or even better using dropout to improve generalization
219.1|3.18| performance. And once you use both techniques, and you still
222.28|3.52| find that early stopping helps, then I would probably consider
225.8|3.32| early stopping. But I would first consider the other two
229.12|3.96| techniques I'm going to present in the next two videos. But
233.08|3.68| again, this is also a useful technique to know about. So in
236.76|3.76| the next video, I want to show you L two regularization, which
240.52|4.28| is essentially a penalty against complexity. And then we will get
244.8|11.04| to the main topic dropout.