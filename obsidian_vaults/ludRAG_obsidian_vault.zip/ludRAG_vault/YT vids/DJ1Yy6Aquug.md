start_time|end_time|text
5.58|4.439|it's my pleasure to welcome Jan from
7.319|4.441|openai I'm he leads the alignment team
10.019|4.681|there and he was previously a researcher
11.76|4.859|at deepmind as well what's a PhD in
14.7|3.48|reinforcement learning theory has been
16.619|3.541|thinking about the alignment problem for
18.18|3.9|over 10 years and today he'll be giving
20.16|3.36|a very interesting topic so hope you
22.08|3.9|guys enjoy
23.52|4.56|yeah thanks a lot for the intro and
25.98|2.7|thanks a lot for having me
28.08|2.22|um
28.68|2.58|I'm very excited to talk about this
30.3|2.939|stuff
31.26|3.42|um I'm also super happy to keep it
33.239|5.16|interactive if you have questions and
34.68|7.74|then you find please interrupt me and
38.399|7.921|um yeah I wanted to start out with
42.42|5.6|a few very basic observations on kind of
46.32|3.6|what I think is going on
48.02|5.64|and
49.92|3.74|so the first one is
54.48|5.28|team EI is joining the game
56.699|6.061|so IMEI has a lot of different players
59.76|5.219|they own All Join at the same time but
62.76|5.399|rather they Join one by one
64.979|5.761|and not all of the their players are
68.159|4.081|like very a lot in how good they are and
70.74|3.0|right now a lot of the players that have
72.24|5.34|joined so far
73.74|7.4|I'm really that's mine and usually you
77.58|3.56|can do it on your very narrow setup
82.08|2.46|um
82.74|3.96|but
84.54|4.5|one thing that we've kind of observed is
86.7|4.62|that over time you know we're seeing
89.04|5.04|stronger and stronger players drawing
91.32|3.96|and this is kind of where we where we
94.08|2.999|are now
95.28|4.56|and then in general
97.079|4.141|we expect that hemiah has um incredibly
99.84|3.419|strong pairs
101.22|5.579|so those will be players that are able
103.259|6.36|to think so much better than humans so
106.799|6.301|much faster and so much more cheaply
109.619|5.161|and these haven't joined yet
113.1|3.0|and so
114.78|3.299|the
116.1|3.799|have like Anchor Point that we have if
118.079|5.461|you think for example about chat Epp
119.899|6.941|chat TBT can already be
123.54|6.3|any human at like knowing more facts or
126.84|6.06|speaking more languages and it can write
129.84|5.88|about 50 words per second and can do so
132.9|5.4|about 100 times cheaper than humans
135.72|5.76|could at minimum wage
138.3|6.42|and so you know there's
141.48|4.86|tomorrow also has some really important
144.72|3.659|limitations and there's a lot of things
146.34|6.18|that you can't do yet
148.379|6.301|but it is kind of an indicator of you
152.52|4.439|know some of the players that maybe will
154.68|3.54|be done in the future
156.959|4.56|and so
158.22|5.82|it seems like in the long run
161.519|4.381|kimai will have all the advantages over
164.04|3.059|team humans
165.9|3.619|but
167.099|5.28|and there's one there's an important
169.519|4.621|caveat which is
172.379|4.261|there's one
174.14|5.8|important advantage that team humans has
176.64|6.599|which is team human gets to pick which
179.94|6.78|players from Kimi joined and when
183.239|5.401|and so this is kind of like an advantage
186.72|4.019|that should we should really be leaning
188.64|3.959|into when we're thinking about what to
190.739|3.481|do and when we're thinking about you
192.599|6.56|know this game that we're playing with
194.22|4.939|cmei and then we'll be playing with pmei
201.54|5.76|so I think two of the main objectives of
204.78|3.84|what we as team human should do it's
207.3|5.159|like first
208.62|8.339|we should try to recruit players from
212.459|7.92|pmei to play on 10 teams and so this is
216.959|4.621|kind of what I would broadly call on it
220.379|3.42|um and this is kind of like the problem
221.58|4.14|that I'm working on
223.799|3.421|and then there's also other objectives
225.72|3.659|so another objective that I think is
227.22|4.26|going to be really important is you want
229.379|3.901|to write the rules of the game so that
231.48|4.679|team human doesn't lose
233.28|4.86|and right now team human kind of has the
236.159|4.201|ball and we get to write the rules so we
238.14|4.92|should write rules that you know make
240.36|6.0|sense and uh
243.06|5.819|still playing this game in the future
246.36|5.04|and so in this talk I want to talk about
248.879|4.44|the second point at all and I'll talk
251.4|4.259|about the first point because that's why
253.319|4.081|I know that's not what I'm working on
255.659|4.561|and
257.4|4.86|Pastor phrase it differently or to make
260.22|5.4|it kind of like more
262.26|4.86|uh practical like one way I'm thinking
265.62|4.62|about alignment is like you want to
267.12|5.04|build AI systems that follow him intent
270.24|4.14|and that you know
272.16|4.14|follow human preferences that do we want
274.38|5.039|them to do
276.3|6.42|and so a bunch of the things basically
279.419|5.401|I'll talk about two main things the
282.72|3.539|first part is going to be work that
284.82|5.7|we've done in the past
286.259|7.321|and kind of like which roughly
290.52|5.22|is in the bucket of like we are trying
293.58|5.399|to figure out how we can make
295.74|5.22|the models that we have today as aligned
298.979|3.841|as we can and you're just kind of trying
300.96|3.959|I'm going to try hard to do this and
302.82|4.68|we'll see how far we get
304.919|4.081|and then the second bucket is the things
307.5|3.6|that we have to do next
309.0|3.06|the stuff that we haven't done yet that
311.1|2.039|we think are going to be really
312.06|3.6|important
313.139|4.62|and I want to kind of like lay out why I
315.66|5.099|think
317.759|3.0|so
321.12|5.76|now I said you know I'm I'm like trying
325.02|4.56|to make this more clear more like more
326.88|3.84|broken down what alignment means so a
329.58|3.24|lot back here
330.72|3.419|because now you know the big question is
332.82|4.379|like what does it mean to follow human
334.139|4.921|attack and because like two main
337.199|5.101|categories of intent that we care about
339.06|4.74|is I would say if it enhanced so if you
342.3|3.78|you know like I give the system
343.8|4.26|instruction or if you wanted to be my
346.08|3.36|assistant it should be my assistant I
348.06|3.12|should follow the instructions
349.44|4.44|but then there's also all these other
351.18|4.739|intents they don't say when I'm usually
353.88|4.8|you know talking to your system or a
355.919|4.56|human they ultimately care about like
358.68|3.72|you know it shouldn't literally always
360.479|4.021|do what they say but the thing that I
362.4|4.68|mean and shouldn't make up stuff and it
364.5|4.32|shouldn't you know do harmful things and
367.08|4.02|they should ask follow-up questions and
368.82|4.74|it's not sure what I mean and so on
371.1|4.2|and so
373.56|3.6|these are all kind of like things
375.3|5.64|they're often is like really difficult
377.16|5.099|to like just not precisely specify or
380.94|2.099|like
382.259|3.601|um
383.039|5.16|you know what's precise
385.86|4.38|but it is still things that we want to
388.199|6.5|get AI to do and that we have to figure
390.24|4.459|out how to you know get into it
394.979|5.361|and so kind of like the main technique
397.319|3.021|that we're using today
409.979|3.78|and
411.6|3.719|basically the basic system is very
413.759|4.201|simple and it's also like a super
415.319|3.66|General technique that applies to lots
417.96|4.739|of different
418.979|5.581|AI models and modalities and settings
422.699|4.801|but in this case we'll be using
424.56|4.8|Advantage model and so two steps
427.5|3.539|there's actually another set of right
429.36|4.7|timeline demonstration so I'm going to
431.039|3.021|stop for the things
434.52|4.56|first step is you're entertain everyone
437.16|4.62|modeling from comparison
439.08|6.6|so you have them on the top in this case
441.78|6.96|you know explain to you all
445.68|6.239|um or you know help me with my Instagram
448.74|4.92|paper whatever it is and then the model
451.919|3.301|does a bunch of things and then you wait
453.66|4.159|which one is quite close to the thing
455.22|2.599|that you intended
457.86|2.76|and so you have a figure set of
459.419|2.881|preferences and you train your reward
460.62|6.32|model and one model basically just learn
462.3|4.64|to predict which one would you prefer
468.12|5.66|everything okay okay let's stand more in
471.0|5.099|front of the camera it's impossible
473.78|5.62|sorry about that
476.099|5.781|maybe let's turn it over
479.4|2.48|okay
482.4|3.54|okay so now we have this through what
484.08|3.119|model that captures camera preferences
485.94|3.659|and what we care about and what we
487.199|5.28|intend for the model to do and then the
489.599|5.281|second step is now you optimize the
492.479|5.701|reward model with the important
494.88|4.8|and so not setting you know like model
498.18|3.84|trades a whole bunch of different things
499.68|4.38|and then what model kind of tells it
502.02|6.6|which one of the assist that things is
504.06|4.56|probably more like the same spot
516.32|4.839|the labels uh they'll depend on the
519.599|3.421|library different levels will have
521.159|3.541|different preferences they also might be
523.02|4.4|inconsistencies and you can give these
524.7|5.88|examples of like internet description
527.42|4.599|but those haven't really been a problem
530.58|4.92|in practice
532.019|5.94|and so far you know like our playlists
535.5|5.6|often don't agree but the model will
537.959|3.141|average over all the time
545.94|2.76|um
546.959|3.841|but yeah so
548.7|4.259|this is like the basic technique it's
550.8|4.44|conceptually like quite simple you can
552.959|3.721|make it even simpler if you had you know
555.24|3.24|if you didn't turn into what model and
556.68|3.36|you're able to spread like every arrow
558.48|3.66|might as well
560.04|4.859|um but it would be a lot less data
562.14|5.819|efficient and so you can turn your one
564.899|5.461|on if you think of like this
567.959|4.801|yeah
570.36|3.9|so how will it work so this is kind of
572.76|3.48|like one of the main thoughts from the
574.26|4.32|instruction sheet paper and this is the
576.24|5.279|one I like sharing because it really
578.58|5.699|blew my mind and it still does
581.519|5.161|um what do we see here so
584.279|4.56|on the x-axis you see this is from the
586.68|3.54|gpd3 model series and you see this is
588.839|3.841|like different three different sizes
590.22|5.88|models over two orders of magnitude
592.68|6.12|and under my asset is how well does the
596.1|4.2|model score on human preferences so if
598.8|4.02|you show a bunch of samples to humans
600.3|3.719|How likely are they to prepare wonderful
602.82|3.959|together
604.019|5.581|and then what we see is that even like
606.779|5.161|the largest GBP model
609.6|3.38|um is this preferred to the smallest
611.94|7.399|instruction
612.98|6.359|and so the 100x smaller instruct model
619.74|6.32|um if actually preferred
622.86|5.7|over the much larger DB like
626.06|6.12|gp3 model
628.56|3.62|and that's kind of wild
633.06|3.36|sorry let me just finish my thoughts so
635.399|7.041|why
636.42|6.02|why so basically it's basically it shows
645.14|5.819|more useful than you know feelings
655.76|4.12|make all these fancy alignment
657.779|5.18|techniques that don't get adopted
659.88|5.459|and so what we were
662.959|4.601|like originally like the first version
665.339|7.141|so I did saw these regressions and then
667.56|6.6|what here is labeled PPO PPX is kind of
672.48|3.84|like a very end where we mix in free
674.16|3.6|training data into the fine tuning and
676.32|4.32|that mitigated a bunch of the
677.76|3.9|regressions that we saw
680.64|2.1|um
681.66|3.06|yeah
682.74|2.58|and I just had a quick follow-up to that
684.72|4.26|um
685.32|6.54|how important is like
688.98|5.099|a fine tune data that you have like you
691.86|3.84|guys you collect data from humans right
694.079|5.221|yeah what if you were to use some
695.7|5.6|retrained by this model to score uh you
699.3|5.64|know
701.3|5.74|yep uh you could do that and there have
704.94|3.24|been like other papers on that like I
707.04|2.94|thought they wrote this paper on
708.18|4.56|constitutional AI that was trying to
709.98|3.359|like exactly do that
712.74|3.0|um
713.339|4.5|in terms of well there's certain things
715.74|4.14|that the language model will be able to
717.839|5.341|automatically Rank and some things it
719.88|4.92|want because you know it won't know your
723.18|3.56|exact preferences or it won't know
724.8|5.039|exactly what like what we wanted to do
726.74|5.14|and so you know whenever the language
729.839|4.381|model does something
731.88|4.5|that we just prefer we actually we have
734.22|3.6|to give it another data point right well
736.38|3.959|in other words you know if you're
737.82|4.68|aligning with humans you somehow have to
740.339|5.101|put humans into the loop so that you
742.5|6.06|know otherwise how does them all know
745.44|5.16|what useful what's supposed to do
748.56|4.2|okay lots and more questions I don't
750.6|3.299|know he was just
752.76|3.86|yeah
753.899|2.721|um how many
760.44|4.019|you today
761.839|5.041|yes I'm gonna get to that in a second
764.459|2.421|sure
769.8|4.62|yeah
771.42|3.0|yeah
780.24|4.62|we haven't actually compared carefully
782.1|4.859|compared across several algorithms and
784.86|4.56|it could very well be that different RL
786.959|4.141|algorithm would be better
789.42|4.26|um that was kind of like
791.1|4.44|I know PPO was invented open EI so
793.68|4.26|that's why we used it
795.54|5.52|it's not not real good reason other than
797.94|5.66|that it works also pretty well
801.06|2.54|yes
807.48|4.799|comparisons this is better than this
809.22|6.179|other thing so usually we have people
812.279|5.341|compare between like three to six
815.399|4.321|different responses from usually
817.62|3.48|different models
819.72|3.679|okay
821.1|2.299|yeah
824.639|5.64|um so is pplm the reward model currently
827.04|5.58|used in GPT in production and it's so
830.279|3.541|like do you use any of the human
832.62|2.94|feedback like you know you can
833.82|2.48|regenerate responses and stuff like that
835.56|3.48|yeah
836.3|4.36|as a reward function
839.04|3.739|s how do you mean to regenerate like
840.66|4.44|because
842.779|5.401|every responses or we can use any
845.1|3.08|implicit feedback basically
848.22|4.619|um I don't know what the current state
850.2|5.819|is for that I expect people will try to
852.839|4.56|use it but you know Jazzy BT hasn't been
856.019|3.961|out that long
857.399|4.56|yeah so I'm curious about this graph
859.98|4.08|like it seems like 100x as you mentioned
861.959|4.741|increasing parameter doesn't give you
864.06|4.56|that much more like Fidelity there uh
866.7|3.36|qualitatively you have been tracking
868.62|3.0|this for a while can you tell right off
870.06|3.48|the bat if you're like interacting with
871.62|4.14|the one billion like a model or the like
873.54|4.62|100 billion model like a touring pseudo
875.76|4.68|touring test the parameter size like I
878.16|3.119|give you a blind how many parameters it
880.44|3.18|has
881.279|6.901|probably not very precisely
883.62|6.12|but you know I think the the big Conor
888.18|2.519|question is like do I get to write the
889.74|3.779|prompt
890.699|4.561|so if you just draw random prompts from
893.519|3.361|whatever people put in the opening a
895.26|2.939|playground which is what we use for
896.88|4.019|Instagram TPT
898.199|4.861|then I probably need quite a few to tell
900.899|3.601|the difference but if I get to write the
903.06|3.48|prompt I can probably do it in one or
904.5|3.66|two at least like if if the task is like
906.54|3.12|tell the difference between this and
908.16|2.46|this
909.66|3.2|um
910.62|2.24|yeah
913.92|3.719|I wanna can I just do two more slides
916.199|3.421|and maybe your questions get answered
917.639|2.76|and then
919.62|2.64|um
920.399|4.081|so this was the question about training
922.26|4.62|costs so this is another thing that kind
924.48|4.94|of really blew my mind is like compared
926.88|5.399|to pre-training it is incredibly cheap
929.42|6.039|so if you look at like the amount of
932.279|4.68|laps that it takes to 10 GPD to e and
935.459|4.32|then you compare it with like how much
936.959|5.461|does fine tuning and there are all with
939.779|4.261|free training mix and everything
942.42|3.479|um like the most expensive instructor
944.04|4.02|GPT version is like less than two
945.899|3.841|percent of the free training computers
948.06|3.12|and if you want to train an even bigger
949.74|3.48|model it's going to be more expensive
951.18|5.339|and you could still use the same like
953.22|5.28|fine tuning step to make it more aligned
956.519|3.18|and of course I think the important
958.5|2.579|thing to note also here is like we
959.699|4.08|haven't fixed all the problems they're
961.079|4.2|like important limitations and so I
963.779|4.8|wouldn't say that this is like you know
965.279|4.8|the last version and we wouldn't try to
968.579|3.12|figure out how to spend more computed
970.079|4.2|more human data in the future
971.699|5.061|but all in all it was surprisingly
974.279|2.481|effective
977.1|5.46|um okay there were no more questions
979.92|4.58|my questions yeah I just wanted to ask
982.56|4.98|for your PTX
984.5|6.699|mix and pre-training data into the rml
987.54|7.32|fine tune just like mixed ingredients
991.199|5.521|yep what's the number of practice uh for
994.86|5.039|this graph so you're fixing a member for
996.72|8.119|examples so this is the full-size gpd3
999.899|4.94|version so this is the 175 billion model
1006.68|7.7|operations no okay so there's also some
1009.86|4.52|questions on Zoom great uh
1014.899|5.521|okay sure so the first one is uh
1018.32|3.42|okay sure so the first question is how
1020.42|3.0|would you deal with our left Edge
1021.74|3.24|breaking in the limit example
1023.42|2.82|preferences are a good Crossing
1024.98|4.56|properties
1026.24|5.459|but optimizing for them is fair size to
1029.54|4.56|incentive device reception
1031.699|4.441|yes I'll get to that okay
1034.1|4.739|uh sure
1036.14|4.559|uh sure yes next question so that is
1038.839|3.901|like you want to automate alignment
1040.699|3.961|research what happens if you need
1042.74|3.839|conceptual breakthroughs which are the
1044.66|4.139|people for experts to like five okay
1046.579|4.641|that would be I get to take at the end
1048.799|2.421|as well
1051.78|5.549|[Laughter]
1054.21|3.119|[Music]
1061.94|3.119|um fine-tuning like supervised fine
1064.039|4.441|tuning
1065.059|5.701|uh it's more like if you directly use a
1068.48|3.6|human figure data
1070.76|3.32|yeah I'm also not sure about the league
1072.08|4.74|okay
1074.08|4.599|so I mean so one Baseline you're showing
1076.82|4.5|here is like what if you just take human
1078.679|4.141|demonstrations in the sense that you
1081.32|4.14|know we have a bunch of tasks we just
1082.82|4.32|ask humans to do them to record what
1085.46|4.74|they did and then train the model to
1087.14|5.279|imitate that and here it's like just
1090.2|4.859|very basic behavioral cloning just using
1092.419|5.341|the same losses and free training and
1095.059|4.98|then you know is noticeably better than
1097.76|3.779|the future hunted version but it's still
1100.039|3.781|not as good as at all
1101.539|4.741|and so that's why we like using Iran and
1103.82|4.26|basically conceptually there's two
1106.28|3.779|problems with the imitating humans
1108.08|4.5|approach one is
1110.059|4.201|humans are better at some things than
1112.58|4.32|the model is and they're worse at other
1114.26|4.38|things and so the things that model is
1116.9|3.96|worse you're trying to imitate something
1118.64|4.86|that you can't do and then the things
1120.86|4.439|where the model is better you're making
1123.5|3.48|the model worse because you're forcing
1125.299|3.12|it to do the thing in the way that the
1126.98|2.579|human would
1128.419|2.941|would
1129.559|4.321|and so
1131.36|3.6|with our all you kind of with our lhf
1133.88|3.299|you're kind of letting the model do
1134.96|3.839|whatever it wants to and they can just
1137.179|4.86|figure out
1138.799|5.341|um like the best way for it to do things
1142.039|3.721|there's also another important advantage
1144.14|3.84|and I'm going to get to that but I
1145.76|4.86|briefly want to talk about chat GPT
1147.98|4.62|so one thing I kind of think of catchy
1150.62|3.72|BT as like the upgrade to instruct gbt
1152.6|4.02|it's kind of like The Next Step at
1154.34|3.78|making the models more aligned and more
1156.62|4.32|useful to humans
1158.12|4.679|and some things that is like you know I
1160.94|3.78|think chat does better is kind of like
1162.799|3.961|using dialogue as the universal
1164.72|3.6|interface right you can talk to it
1166.76|5.279|directly you can ask follow-up questions
1168.32|5.34|you can you know ask it to you know
1172.039|5.601|refine the answer and all these things
1173.66|3.98|that makes it a lot easier to deal with
1177.86|5.22|um it's better refusing harmful tasks
1180.14|4.74|but it's also there's still important
1183.08|4.32|limitations right like the biggest one
1184.88|5.1|is Like the Model hallucinates A lot it
1187.4|6.3|makes up facts when
1189.98|5.88|um you know for whatever tasks you give
1193.7|4.92|it and that you know it makes it quite
1195.86|5.22|unreliable it's also still sensitive to
1198.62|5.82|prompting which kind of shows that you
1201.08|6.18|know it still has important misalignment
1204.44|5.52|that um we need to fix
1207.26|5.64|like really if the model was like
1209.96|5.28|models are really like
1212.9|4.44|the do the tasks their best
1215.24|4.58|invincibility no matter how you prompted
1217.34|2.48|to do that
1220.46|3.719|um
1221.36|3.54|but yeah One important principle that I
1224.179|4.021|think
1224.9|4.68|is really useful for or that like I want
1228.2|4.38|to travel leans on a lot is that
1229.58|5.28|evaluation is easier than generation so
1232.58|4.92|if we ask humans to compare and rank
1234.86|3.48|different responses the model gave
1237.5|3.0|um
1238.34|4.32|it is
1240.5|4.02|easier to tell the difference between
1242.66|4.379|different variants of what the model did
1244.52|5.34|than it is to do the task itself
1247.039|5.64|or in other words you know you can do
1249.86|4.8|the comparisons on tasks you could still
1252.679|3.181|like spot good behavior on tasks that
1254.66|2.34|you might not be able to do well
1255.86|3.78|yourself
1257.0|4.02|and so if you're giving this kind of
1259.64|5.34|like feedback
1261.02|7.26|now let's you know the system should do
1264.98|4.439|better than you actually could
1268.28|3.12|and I think that's a very general
1269.419|3.181|principle that holds in lots of domains
1271.4|3.42|so
1272.6|4.74|kind of like you're probably most
1274.82|5.099|familiar if you start yes you know that
1277.34|3.66|pivas MP and everyone you know we don't
1279.919|3.781|actually know whether they're different
1281.0|4.919|but in practice it seems like and pitas
1283.7|3.719|are just much harder
1285.919|3.12|um it also applies to lots of other
1287.419|3.601|settings like a lot of professional
1289.039|3.601|sports or Esports just wouldn't be fun
1291.02|2.519|to watch if you couldn't tell he's
1292.64|3.419|winning
1293.539|5.52|uh more easily than you could actually
1296.059|4.801|compete on a professional level
1299.059|3.721|um it applies to a lot of consumer
1300.86|3.48|products you can like look at your
1302.78|5.58|smartphones and tell which one you like
1304.34|6.36|more uh without that is like also deeper
1308.36|4.5|than just looking at like the specs
1310.7|3.599|but is actually very hard to build like
1312.86|4.319|it's my phone
1314.299|4.26|it also applies to academic research you
1317.179|3.841|know it's much easier to review your
1318.559|4.561|paper and you know say what all the
1321.02|3.539|things are bad about it
1323.12|3.48|um than it is to write a good paper
1324.559|5.161|yourself
1326.6|4.74|um it applies to I don't know when you
1329.72|4.02|um
1331.34|3.959|yeah basically there's lots of Demands
1333.74|3.54|where this applies and so I think this
1335.299|4.021|is like a very
1337.28|3.42|this principle is like very useful when
1339.32|3.96|you want to like
1340.7|5.16|align AI systems on tasks that we might
1343.28|7.04|not be able to do ourselves well
1345.86|7.799|foreign okay so having said that
1350.32|6.219|rhf has some really important limitation
1353.659|5.88|and I think that's going to make it
1356.539|4.981|really difficult to use are all HF to
1359.539|4.821|scale
1361.52|2.84|alignment
1364.4|3.06|um
1365.299|4.801|let me explain this with a diagram so
1367.46|6.719|basically on the x-axis
1370.1|6.54|that's plot like the AI progress
1374.179|4.261|um and on the y-axis how difficult
1376.64|4.019|different tasks are
1378.44|4.2|and then as we have more AI progress
1380.659|3.9|kind of like the task that AI the
1382.64|3.779|difficulty of tasks that AI can do goes
1384.559|4.201|up
1386.419|5.701|um and like one of the fundamental
1388.76|5.7|problems is that the level of tasks that
1392.12|5.58|humans can reliably evaluate doesn't go
1394.46|6.18|up because humans don't get better with
1397.7|5.76|AI progress and so
1400.64|4.86|I think we're like somewhere here
1403.46|5.099|but the problem is once you cross this
1405.5|5.64|line you don't really know
1408.559|4.321|what like whether your model is actually
1411.14|3.779|doing the right thing because you can't
1412.88|4.86|reliably evaluate anymore
1414.919|4.981|and so that's kind of like the point
1417.74|3.179|where rohf training will start to break
1419.9|3.779|down
1420.919|5.521|and what we'll probably see is
1423.679|5.161|um kind of what the question before I
1426.44|5.34|alluded to is like well now the systems
1428.84|5.339|are optimized for whatever feedback you
1431.78|4.379|give them and so they will try to tell
1434.179|4.74|us what we want to hear rather all the
1436.159|4.561|things that they know to be true and you
1438.919|4.801|know they might learn how to deceive us
1440.72|6.079|because you know that makes it easier to
1443.72|3.079|score higher on preferences
1447.5|4.679|um and so kind of like
1450.14|3.3|the basic idea that we want to Leverage
1452.179|3.301|is
1453.44|3.599|related to
1455.48|4.92|you know the principle I just mentioned
1457.039|5.401|which is evaluations generation so for
1460.4|5.399|example if you have a large language
1462.44|5.82|model writing a code base like an entire
1465.799|4.38|code base there's just no way humans
1468.26|4.32|would be able to find all the bugs and
1470.179|4.5|all the flaws in the code base or you
1472.58|3.959|know the code base could have like a
1474.679|4.201|Trojan in there and you might not be
1476.539|4.5|able to tell because it is so hard and
1478.88|2.94|that's why we see so much buggy code out
1481.039|3.661|there
1481.82|5.339|but if you ask your language model to
1484.7|4.68|find bugs and point them out to you
1487.159|4.14|once you've you know once you've seen
1489.38|4.02|the bug it's so much easier for you to
1491.299|5.161|say oh yeah this was a bug you know
1493.4|6.84|please fix it and so now you've taken
1496.46|5.94|the task around the base down to well I
1500.24|3.9|just have to evaluate whether that was
1502.4|3.899|the bug according to the spec that it
1504.14|4.5|had in mind
1506.299|4.38|so the general principle that we are
1508.64|4.919|excited about here is like we wanna
1510.679|4.141|you leverage AI assistance for human
1513.559|3.661|evaluation
1514.82|3.719|and so the hope is that we together if
1517.22|2.819|we pair up humans with the eye you
1518.539|4.321|actually get a line that looks more like
1520.039|4.801|this where you know like humans together
1522.86|5.059|with the AI can evaluate much more than
1524.84|3.079|they could play on their own
1528.679|3.061|um
1530.12|3.72|and so
1531.74|4.02|to make this concrete there's like two
1533.84|3.18|different ways you could do that or
1535.76|3.48|there's many different ways you could do
1537.02|4.62|that too I want to highlight it's like
1539.24|4.679|first you can write it ask yeah to write
1541.64|5.34|a critique this is a project we did last
1543.919|4.801|year and uh in this case it was a simple
1546.98|4.16|summarization task and we trained a
1548.72|6.6|language model to kind of like just say
1551.14|5.98|things that are wrong with the summary
1555.32|3.54|um and
1557.12|4.32|there's other things you could do for
1558.86|4.919|example you could give people chat gbt
1561.44|5.28|and ask them okay use strategypt to help
1563.779|5.101|you evaluate and then you could ask for
1566.72|3.3|a critique or you could ask for a lot of
1568.88|2.76|other things you could ask for an
1570.02|4.56|explanation you can ask for a fact
1571.64|4.919|checking or a quote or you know whatever
1574.58|3.839|the model like church BT can actually
1576.559|3.841|reliably help you with
1578.419|3.781|and so
1580.4|4.86|the idea would be that you know like
1582.2|5.7|using AI assistance you can kind of get
1585.26|4.5|all the smart study has
1587.9|4.019|and leverage that in order to figure out
1589.76|4.5|how you should evaluate what this system
1591.919|4.081|is doing and like whether it's aligned
1594.26|4.38|with your preferences or whether it's
1596.0|3.9|trying EC View
1598.64|3.84|and
1599.9|6.3|the big problem with this is how do we
1602.48|6.78|know whether it's working and
1606.2|5.459|one of the kind of like difficulties is
1609.26|4.2|that
1611.659|3.841|by assumption we're kind of dealing with
1613.46|4.5|a hard task where it's difficult to
1615.5|4.5|evaluate and we also want the task to be
1617.96|4.14|real because we don't want to you know
1620.0|4.26|we won't want to solve some tight house
1622.1|3.78|that doesn't matter
1624.26|4.08|and so
1625.88|5.58|it becomes different so you need like a
1628.34|4.98|hard task that is real but also if you
1631.46|3.18|don't you if you have those you usually
1633.32|3.359|don't have ground tooth so you don't
1634.64|3.419|know which was the right answer and how
1636.679|3.301|do you know whether your assistance is
1638.059|4.381|working or it's biasing everyone to just
1639.98|4.38|say the same thing
1642.44|4.02|um and so
1644.36|3.66|there's a simple technique that we used
1646.46|3.54|in the critique
1648.02|5.639|to do this
1650.0|5.34|um where like that we call a targeted
1653.659|3.421|perturbations and so what you do is you
1655.34|4.62|have a bunch of prompts so this could be
1657.08|4.86|like whatever people type into chat apt
1659.96|3.48|and then
1661.94|3.78|um you
1663.44|3.719|kind of like take the response that you
1665.72|2.88|have and say like this is the correct
1667.159|4.02|response it doesn't actually have to be
1668.6|4.98|correct but let's just assume it is and
1671.179|4.321|now you're asking a human to introduce
1673.58|4.56|some kind of subtle flaw that is hurt
1675.5|4.98|like easy to miss but is an important
1678.14|4.44|flaw and now what you have is you have
1680.48|4.199|this paired data set of like a good
1682.58|3.66|response and a bad response and you know
1684.679|2.761|which one is good and bad because you
1686.24|4.799|made it worse
1687.44|6.54|and so you know
1691.039|6.841|um in a way that gives you Contours
1693.98|6.36|and so what you now can do is you can
1697.88|4.02|take like randomly select one either the
1700.34|3.719|correct or the flawed response and then
1701.9|3.84|show it to either a human or a human
1704.059|3.24|with assistance and then they have to
1705.74|5.22|say well there was the correct the Vlog
1707.299|4.921|one or like how good the response is
1710.96|4.86|and
1712.22|6.0|in this setting we can kind of like
1715.82|4.979|figure like just try a lot of different
1718.22|5.16|AI assistants or scalable oversight
1720.799|4.98|techniques and then say
1723.38|4.679|you know like is this
1725.779|5.64|actually helping humans find the flaws
1728.059|6.181|that we planted more lively than not
1731.419|6.021|and if it is then you know like you're
1734.24|3.2|actually really helping
1738.2|5.16|and so we did this and the critiques
1741.2|4.26|paper so this is uh changing the
1743.36|4.08|language models to Red critiques and for
1745.46|4.5|summaries and what we can show is that
1747.44|4.619|when we're assisting humans with
1749.96|4.26|critiques at the evaluation they
1752.059|4.5|actually find 50 more flaws than it did
1754.22|4.559|with that and so this is kind of like
1756.559|4.74|real signs of life that you can already
1758.779|5.341|use as a models that we can have today
1761.299|3.961|to help humans evaluate and like find
1764.12|3.12|problems they would have missed
1765.26|4.38|otherwise
1767.24|6.539|and of course we still have to do this
1769.64|6.539|like on a much harder task and like with
1773.779|4.5|um like a real task in a sense and we
1776.179|4.74|also want to have like bigger effect
1778.279|4.26|size but I think it's just like it shows
1780.919|3.961|that there's promise of these techniques
1782.539|5.701|already working
1784.88|6.779|and so in the long run
1788.24|5.939|um what I think we want to get to is we
1791.659|4.02|kind of want to leverage AI for all the
1794.179|4.141|cognitive labor that goes into
1795.679|3.421|evaluating whatever our AI systems are
1798.32|3.359|doing
1799.1|4.38|and this could be you know like reading
1801.679|4.261|everything that's relevant or fact
1803.48|4.38|checking or doing calculations or like
1805.94|4.099|writing code
1807.86|5.34|um or any of these things
1810.039|4.901|and then humans should focus on like
1813.2|3.66|their preference input like the things
1814.94|5.16|figuring out what they actually care
1816.86|5.34|about and what they want the model to do
1820.1|2.819|and
1822.2|2.64|um
1822.919|4.14|and this way we can kind of like
1824.84|5.579|Leverage
1827.059|5.041|you know like the the abilities that you
1830.419|3.841|know the AI players will bring to the
1832.1|5.28|table and the things that they will be
1834.26|4.56|better at than us eventually
1837.38|3.24|and then
1838.82|3.479|kind of like use them to help
1840.62|4.38|communicate the thing that we actually
1842.299|5.781|care about and you know the things that
1845.0|3.08|we actually want them to do
1848.84|3.9|um and yeah that's it
1851.72|3.12|um
1852.74|5.78|but yeah those are like the main slides
1854.84|3.68|so I'm happy to take more questions
1864.159|6.161|yes I was wondering about this
1867.26|4.919|hallucination of responses have you ever
1870.32|4.56|tried to consider some notion of
1872.179|5.181|uncertainty in the answers
1874.88|2.48|yes
1881.0|5.76|responsible
1883.179|6.761|uncertainty so and sampling is difficult
1886.76|4.919|because either you're like training in a
1889.94|3.42|fine tuning Ensemble from the same
1891.679|3.901|pre-trained model and so you don't get
1893.36|3.6|that much variance in your sample or
1895.58|3.36|you're pre-training a bunch of different
1896.96|4.38|models and now you're spending a lot of
1898.94|4.92|money on free trainings
1901.34|4.68|um one thing I mean
1903.86|3.9|it seems like it should be a solvable
1906.02|4.5|problem to just
1907.76|5.7|teach the model to say it's uncertain
1910.52|5.639|when it's actually uncertain
1913.46|4.74|um and there's been a bunch of research
1916.159|4.081|in that direction but
1918.2|4.979|I I think right now it's still like
1920.24|6.02|we're not really in a good shape
1923.179|3.081|it's more stuff to do
1926.539|3.781|yeah
1928.159|4.921|um do you think we may run into a kind
1930.32|6.479|of signals and noise ratio problem when
1933.08|7.319|it comes to uh AI suggested critiques to
1936.799|5.581|AI answers because you sure like when AI
1940.399|4.081|is trying to point out potential
1942.38|5.1|problems with text humans are more
1944.48|4.62|likely to report more problems but what
1947.48|3.36|if it's noticing problems that humans
1949.1|5.28|wouldn't have necessarily had a problem
1950.84|6.12|with to begin with yeah so we did try to
1954.38|5.72|control for that a little bit by like
1956.96|5.52|having humans read the severity of their
1960.1|4.78|flaws and whether they would have
1962.48|5.46|noticed them otherwise they can still
1964.88|4.919|see a significant effect
1967.94|4.44|um but also like I mean a lot of the
1969.799|4.5|time the model is nitpicking and then
1972.38|3.299|those are like not the interesting cases
1974.299|4.141|yeah
1975.679|4.441|um also if you like look at the example
1978.44|4.02|I showed which I think it's from the
1980.12|4.799|blog post like a lot of the kids are
1982.46|5.699|just actually quite garbage and one of
1984.919|4.98|the like things that makes it easy for
1988.159|4.02|critiques is
1989.899|3.9|it's okay most of them are garbage
1992.179|4.561|because the human can just beat them and
1993.799|6.781|discard them and it kind of like
1996.74|6.72|more you know helps evaluate it and know
2000.58|4.319|where to focus on or like notice like
2003.46|2.819|think of something they would have
2004.899|3.181|missed otherwise
2006.279|3.24|so it's more like you know the critiques
2008.08|3.54|help you brainstorm how you should
2009.519|4.741|evaluate or something
2011.62|3.96|um but if you're kind of like using an
2014.26|3.539|assistant you probably want more
2015.58|5.28|reliability than like filling most of
2017.799|5.781|the answers to why
2020.86|2.72|um yeah
2024.64|5.639|yes uh how do we ensure that the
2028.0|4.44|evaluation metrics we are using in your
2030.279|4.5|recursive word modeling approach like
2032.44|3.479|detect deception or like left turns or
2034.779|3.301|something don't have like major
2035.919|4.14|discontinuity
2038.08|5.16|yeah I think
2040.059|5.161|yeah well it depends a lot what kind of
2043.24|4.14|community you're talking about right
2045.22|4.86|like if
2047.38|4.56|you know you get overnight like a model
2050.08|5.4|that is let's say a thousand inches
2051.94|5.939|larger on like number of parameters or
2055.48|3.06|like equivalently better
2057.879|4.02|um
2058.54|6.48|that can like create quite a step up and
2061.899|6.661|that's makes it quite difficult to
2065.02|5.159|do this kind of evaluation
2068.56|3.48|um
2070.179|4.44|so in that sense I think it's going to
2072.04|4.92|be very important to like scale up AI
2074.619|4.921|continue more continuously and like do
2076.96|4.8|more incremental steps
2079.54|4.139|um having said that I think
2081.76|3.419|the basic picture with request number
2083.679|4.68|one modeling is
2085.179|5.341|that you're training the systems to help
2088.359|4.56|you evaluate you know
2090.52|5.639|systems that train from or fine-tune
2092.919|6.901|from the same system right and so if you
2096.159|5.761|can figure out how to get
2099.82|3.779|like fine-tune them in a way that they
2101.92|4.199|mention everything that is actually
2103.599|3.981|useful and relevant then it would still
2106.119|4.441|be able to
2107.58|4.3|evaluate systems even though they're
2110.56|3.72|much smarter than anything you've
2111.88|4.32|evaluated before
2114.28|5.28|maybe let me make this more concrete
2116.2|5.58|because there's I think a way that you
2119.56|4.2|could measure that or like one way we've
2121.78|3.78|tried it was using what we called the
2123.76|4.38|discriminator critique Gap
2125.56|4.2|so to measure that you're training two
2128.14|3.18|different or you're fine-tuning two
2129.76|2.52|different models from this entry chain
2131.32|3.96|model
2132.28|5.22|one is a discriminator just says like
2135.28|4.079|is this the flight response or the the
2137.5|2.88|correct response or more correct
2139.359|3.121|response
2140.38|4.8|and the other one is a critique model
2142.48|6.0|that tells you what the flaw was
2145.18|5.399|and now you can measure how often does
2148.48|4.02|the discriminator get it correctly and
2150.579|4.201|the discriminator is just like pure
2152.5|4.2|gradient descent it doesn't have to want
2154.78|3.299|to tell you anything you just basically
2156.7|4.98|hooking into the model through
2158.079|6.481|presentations and trying to like get all
2161.68|5.76|all the relevant latent Insight it has
2164.56|4.32|to this prediction task and then on the
2167.44|2.76|other side other hand you have this
2168.88|3.739|critique model or this general
2170.2|4.98|assistance model and you're measuring
2172.619|6.101|how often does the assistant actually
2175.18|5.34|help me point to the right flaw
2178.72|4.02|and then if you compare these two scores
2180.52|4.8|you can like look at the gap between
2182.74|4.2|them hence this generally sorry
2185.32|3.48|discriminated critique app
2186.94|3.78|and then if the Gap is large then the
2188.8|3.48|model knows a lot about the task it's
2190.72|2.76|not telling you and so that would be
2192.28|3.12|very worrying
2193.48|3.9|and the Gap is small
2195.4|3.959|then
2197.38|4.86|um you know there's much
2199.359|5.341|there's like fewer things that the model
2202.24|3.839|is like not telling you yeah but I guess
2204.7|3.62|there's like lots of value like
2206.079|2.241|Insurance
2210.48|3.76|that's right
2212.38|4.26|that's why we want to test it on current
2214.24|4.92|models
2216.64|5.04|yes I don't know who was first I think
2219.16|4.919|someone in the back
2221.68|3.3|I
2224.079|4.621|um
2224.98|5.96|so I wanted to ask about like the
2228.7|2.24|University
2233.619|4.081|and so um you know I've been helping
2235.9|4.32|it's like part of that also is like
2237.7|4.74|communicating what you want the AI to do
2240.22|4.5|right right not just like evaluating but
2242.44|3.3|like communicating like perhaps like I
2244.72|3.6|would like you to do this and maybe
2245.74|4.14|maybe it can't do that
2248.32|3.6|um and so like at least like in my
2249.88|3.36|personal experience using the chat CPT
2251.92|5.159|like there were some things that could
2253.24|3.839|do that without really surprisingly
2269.02|4.98|yeah one thing that I thought
2271.839|4.141|um was a bit concerning was just this
2274.0|3.24|idea that like you know people don't
2275.98|2.119|always communicate their preferences
2277.24|3.839|like
2278.099|5.801|honestly or like like there could be
2281.079|5.941|like uh like coordinated efforts right
2283.9|4.98|to like like instill rewards for like
2287.02|3.54|specific capabilities you know like
2288.88|3.959|coordinated efforts to do such a thing
2290.56|4.2|like one idea like I had a business like
2292.839|4.701|I tried to ask if that has like some
2294.76|5.099|idea of like a Wikipedia for itself like
2297.54|3.96|I didn't know how to use it at first so
2299.859|4.801|I just thought that maybe
2301.5|6.9|walk there it is but like I was hoping
2304.66|3.74|there was one there was one for like GPT
2311.859|3.301|um and so my question is like
2314.5|3.06|um
2315.16|4.919|how do you like make that sort of like
2317.56|5.22|being safe right like have you like
2320.079|4.621|recognized coordinating efforts to like
2322.78|4.92|you know like specifically reward
2324.7|5.399|certain kinds of behavior
2327.7|4.62|um maybe like some group of unfortunate
2330.099|5.24|decides that they would like to
2332.32|6.0|um yeah you know give it some capability
2335.339|5.321|so this isn't you know like yeah this is
2338.32|4.38|a really good question and like in a way
2340.66|4.199|I mean the first obvious thing though
2342.7|3.78|you shouldn't do is like you shouldn't
2344.859|4.621|just like literally train in the data
2346.48|5.46|that people you give through like using
2349.48|4.8|the interface and we've kind of like
2351.94|3.96|seen other examples of what happens we
2354.28|5.16|do that if you think of like Microsoft
2355.9|6.179|Ka or something that can go pretty wrong
2359.44|4.5|um the other thing is I mean right now
2362.079|3.481|what we're doing is like we're hiring a
2363.94|4.5|bunch of people and then ask them to
2365.56|5.16|rate different model responses but also
2368.44|4.26|now the question becomes like you know
2370.72|3.84|who will be hiring and like what's their
2372.7|3.3|background what are they trying to do
2374.56|4.32|and so
2376.0|4.74|and in particular like the thing I think
2378.88|4.32|we're doing quite poorly right now is
2380.74|5.28|like actually
2383.2|5.28|like importing like a diverse and
2386.02|4.68|representative set of human preferences
2388.48|4.92|and it's more just like you know whoever
2390.7|5.7|we end up we can hire
2393.4|3.959|um and so I kind of wish there was also
2396.4|2.64|this like
2397.359|3.841|more
2399.04|3.9|targeted research on like how we should
2401.2|4.44|do that and how that could be done well
2402.94|4.74|and some of it is also like you know
2405.64|5.04|better placed outside of like big tank
2407.68|4.8|companies because if you are like tech
2410.68|3.899|companies always have an incentive to
2412.48|3.3|like you know
2414.579|4.321|um
2415.78|4.98|import human preferences in the way that
2418.9|3.12|maybe is not like the thing that we
2420.76|3.839|actually
2422.02|4.98|Humanity would do under reflection or
2424.599|4.101|something and so I think it's a really
2427.0|4.5|big important question
2428.7|5.379|like data contamination is like the Dual
2431.5|4.579|problem to this like do you think
2434.079|2.0|um
2437.099|4.541|yeah I mean you have like is that
2439.599|3.721|something people might can anyone can
2441.64|4.08|poison the free training right just put
2443.32|5.1|something on the Internet
2445.72|6.08|um and it's you know something that we
2448.42|3.38|have to be very mindful of
2456.579|4.821|considering that we're currently
2458.26|3.14|training these models
2462.099|3.841|hopefully getting closer to human
2463.78|5.299|purposes at this point as human
2465.94|3.139|preferences change
2479.74|4.98|yeah I mean the most obvious thing is
2482.079|4.441|it's like the model's knowledge base is
2484.72|4.08|kind of like the pre-training cutoff
2486.52|4.559|date like somebody you know whatever
2488.8|4.559|data you went into pre-training it
2491.079|4.621|doesn't know about like a lot of things
2493.359|4.681|that happened after that
2495.7|4.919|um in terms of updating kind of like
2498.04|4.14|human preferences or the you know like
2500.619|3.841|the comparisons that go into the reward
2502.18|3.899|model units collect more data and we
2504.46|3.659|train the fine-tuning run is like
2506.079|3.241|competitively cheap so you can you know
2508.119|4.021|do that again
2509.32|3.779|I think what gets harder is that you
2512.14|3.0|know like
2513.099|4.26|as you've deployed the model and people
2515.14|4.38|started using it for all kinds of you
2517.359|6.321|know tasks that they want to build their
2519.52|4.16|company around like they
2523.9|3.719|um if you're update and you change the
2525.76|3.839|model then they also have to do a bunch
2527.619|4.081|of work into like adapting their prompts
2529.599|2.881|to whatever they have to do what they're
2531.7|5.12|doing
2532.48|4.34|and so it doesn't come as a zero cost
2536.859|7.201|yes uh sorry yeah so on the note of
2541.26|4.96|exceeding Human Performance but what if
2544.06|4.14|the advantage of the gp3 is that it has
2546.22|3.24|immense purpose of you guys can be
2548.2|3.24|entire internet if you want to
2549.46|3.78|specialize in a specific domain like
2551.44|4.62|chemistry or Material Science or
2553.24|3.839|something and especially to generate new
2556.06|4.019|content
2557.079|3.0|automatics
2566.619|4.861|you mean like less data on like the
2569.14|3.54|chemical domain or something yeah you
2571.48|4.02|just have like research paper for the
2572.68|4.08|last 30 years yeah and you can throw
2575.5|2.819|that into pre-training right and then
2576.76|2.64|the model knows about it but can the
2578.319|4.701|model really learn us effectively
2579.4|3.62|without so much data okay
2585.76|5.04|yeah I mean that's kind of the general
2588.04|4.74|idea with what you intend to do with
2590.8|4.5|fine tuning and to some extent we've
2592.78|4.799|seen it like generalized in this way for
2595.3|4.4|example instruct gbt was trained almost
2597.579|5.341|entirely on English
2599.7|5.5|language feedback and demonstrations
2602.92|4.8|and it works in other languages and so
2605.2|4.74|that's kind of wild and so similarly you
2607.72|3.66|know you could train the model with
2609.94|3.84|people who don't know anything about
2611.38|4.14|chemistry and then you know it learns to
2613.78|4.86|follow instructions and it will do so
2615.52|4.799|like on the topic of chemistry and this
2618.64|3.84|fine tuning can be very sample efficient
2620.319|3.78|like with 100 data points you can
2622.48|2.94|actually make a meaningful change in the
2624.099|4.801|Model Behavior
2625.42|5.76|so it can be quite effective
2628.9|4.82|um I'm gonna pick someone hasn't asked
2631.18|2.54|yes
2643.44|5.02|so what I've noticed from potentially
2646.3|4.559|that it always gives you back very
2648.46|4.92|structured or scientifically structured
2650.859|5.701|answers do you
2653.38|6.0|um consider in the training if it
2656.56|5.16|returns you like a scientific scientific
2659.38|4.739|research to answer or rather than
2661.72|3.96|asterisk dance
2664.119|4.681|yeah
2665.68|5.04|I mean the tricky thing is ideally the
2668.8|3.24|model should give you the kind of answer
2670.72|3.18|that you
2672.04|4.02|want to have right and some people
2673.9|4.439|prefer a more scientific or technical
2676.06|4.259|answers some people might prefer more
2678.339|5.28|generic answer
2680.319|6.061|and I mean it right now like chat GPT
2683.619|5.161|doesn't have like you know a way for you
2686.38|4.14|to set like your specific preferences
2688.78|3.9|and that's something that you know would
2690.52|4.62|be really exciting to have
2692.68|4.919|um but also I think
2695.14|5.04|the kind of stylistic property that
2697.599|5.881|you've observed are is in fact like
2700.18|5.52|probably a product of our labeler pool
2703.48|4.8|and so a lot of the chachibi key workers
2705.7|5.1|were like more you know like
2708.28|4.2|I think more like computer sciencey and
2710.8|4.44|like more there was like more data
2712.48|5.22|generated by programmers
2715.24|5.46|compared to instruct gbt which was more
2717.7|4.68|like uh generalist labelers
2720.7|4.139|and
2722.38|6.06|and yeah there's like different it's
2724.839|5.661|like kind of it changes also the style
2728.44|2.06|um
2735.22|4.68|yeah I mean
2737.079|4.201|we should make a distinguished effort it
2739.9|3.54|should give you like the style that you
2741.28|3.2|want right
2743.44|2.82|um
2744.48|3.82|yes
2746.26|2.94|so one of the things that I've been
2748.3|2.9|thinking about
2749.2|2.0|um
2754.96|3.74|like in the education
2760.02|4.66|and so as we go back to the graph of the
2763.18|3.48|AI progress
2764.68|5.22|the uh
2766.66|6.24|human level yeah evaluate but I'm sorry
2769.9|4.919|to think about is like over great I have
2772.9|4.14|to use this sort of show like my 10 year
2774.819|3.601|old cousin had a pair of chat GPT just
2777.04|6.26|to mess around with
2778.42|4.88|and that green line is a lot lower
2783.339|5.641|um and furthermore if said just becomes
2786.339|5.76|part of their educational experience
2788.98|5.72|it's going to be much where I perceive
2792.099|6.02|it to be more difficult for them to
2794.7|5.98|discriminate even simpler tasks
2798.119|6.941|and so I'm already thinking about like
2800.68|6.54|how that might disrupt or make this
2805.06|5.22|alignment a little bit more difficult in
2807.22|6.119|the long run as you have people who are
2810.28|4.94|more you know taped for instance what
2813.339|5.641|Japanese
2815.22|4.42|says as like a kid Intrigue anyway yep
2818.98|2.639|um
2819.64|3.719|I was just wondering what your what your
2821.619|4.321|thoughts are I mean there's a real risk
2823.359|5.941|of overlying on a text that is immature
2825.94|5.52|and that is not ready for you know
2829.3|3.9|you just believing like please don't
2831.46|5.94|believe everything the model says right
2833.2|6.72|right um but also I think one thing
2837.4|4.199|that I'm hopeful for is that like you
2839.92|4.08|know your cousin will end up like
2841.599|6.421|figuring out how to do this where like
2844.0|5.94|you know they grew up with uh you know
2848.02|3.96|like all of these AI tools that are
2849.94|4.679|getting better and learning how to
2851.98|5.82|actually leverage them productively
2854.619|5.941|right and like it's kind of like
2857.8|5.4|you know uh 20 years ago or something
2860.56|4.32|when you were like you like using Google
2863.2|3.36|search much earlier than everyone else
2864.88|3.42|you're probably gonna get better at like
2866.56|3.48|using that as a tool for everything you
2868.3|3.92|want to do
2870.04|2.18|um
2874.319|5.04|I think you headed your hand up for last
2876.94|2.419|yeah
2886.9|4.52|um
2888.099|3.321|oh wait the last one
2892.24|4.76|yeah so but right now it seems like you
2894.16|2.84|guys are
2897.339|5.701|it was just biological sensors to the
2899.2|6.36|real world the like physical grouchy and
2903.04|4.68|using language as like a compressed
2905.56|4.2|interface to that ground truth are you
2907.72|3.599|guys also looking at using uh like
2909.76|5.04|sensor technology directly with your
2911.319|5.221|models to get a more truthful answer of
2914.8|3.2|you know
2916.54|4.079|yeah
2918.0|4.48|I mean it depends on what that sense you
2920.619|3.361|could be right like I guess like one of
2922.48|3.839|the most straightforward things is you
2923.98|4.5|could ask the model to browse and then
2926.319|4.5|it can like fact check its own answers
2928.48|4.859|and it can you know like
2930.819|3.721|import external knowledge that I didn't
2933.339|3.361|remember
2934.54|3.66|and
2936.7|3.24|um
2938.2|3.36|yeah I think that would be quite useful
2939.94|4.62|I think that'll be quite useful for
2941.56|5.12|assisting human evaluation
2944.56|2.12|um
2948.0|6.819|and you can look at web GPT which you
2952.42|4.56|know isn't published work on using the
2954.819|4.921|model for browsing
2956.98|4.379|um I think so one thing that makes it
2959.74|4.02|harder when you're using this like
2961.359|4.74|external sensors or if you
2963.76|4.2|letting the model interact more directly
2966.099|4.98|with the real world is that it raises
2967.96|5.1|more safety questions right if you let
2971.079|5.701|your language model make arbitrary API
2973.06|6.299|calls then you have to be a lot more
2976.78|7.079|careful with which calls there's a lot
2979.359|5.821|to make and which is it not and if you
2983.859|3.24|as opposed to if you're just like
2985.18|4.08|reviewing everything the model says then
2987.099|3.601|you can decide which ones you want to
2989.26|3.0|make
2990.7|2.82|um
2992.26|4.64|so yeah
2993.52|3.38|it's an open crop
2997.06|5.84|okay one more question
2999.579|3.321|uh I think you didn't
3004.02|4.38|using the abilities of these kind of
3007.26|2.22|I've seen like different people talk
3008.4|3.3|about how I was only like a
3009.48|4.02|face-to-matic compute per token while a
3011.7|3.54|human they have system one system two
3013.5|4.2|where we can like just speak quickly
3015.24|3.54|versus actually using reasoning and
3017.7|3.48|think through things that's different
3018.78|4.559|effort and then I've seen other words to
3021.18|3.899|try to like kind of use the force it to
3023.339|4.201|achieve it from the chain of the
3025.079|4.441|reasoning or like let's think step by
3027.54|3.74|step do you think that stuff is
3029.52|6.42|sufficient to do like everything because
3031.28|8.68|you want or will require real big
3035.94|5.28|fine-tuning or architectural changes
3039.96|3.42|I don't know
3041.22|6.119|I'm also the wrong person to ask
3043.38|7.26|I'm mostly not trying to get the models
3047.339|5.461|to have new capabilities and more like
3050.64|4.459|you know getting them to play on team
3052.8|2.299|human
3056.339|3.441|um oh do we want to do the online
3057.48|2.3|questions
3065.76|3.319|so what do you think is the is
3076.339|5.26|more often out
3079.2|5.159|uh
3081.599|4.881|yeah quite possibly
3084.359|2.121|um
3088.74|4.02|I mean yeah as you find out right like
3091.079|4.02|there is a lot of conversational data
3092.76|5.819|and if you can use that that would be
3095.099|6.421|that should should be useful
3098.579|5.04|um I think broadly can categorize this
3101.52|4.14|kind of thing it was like let's make the
3103.619|4.141|RL algorithm better and like I would
3105.66|3.899|also need feedback and I think that's
3107.76|5.16|valuable and that should help us like
3109.559|4.921|make the same free chain models like
3112.92|4.02|more aligned according to the human
3114.48|3.24|preferences that we collected
3116.94|4.139|um
3117.72|7.76|but also you would still run into like
3121.079|4.401|all the limitations that rlhf has right
3132.02|6.039|I don't think it offers a role right now
3134.88|5.64|but it's supervised fine-tuning so you
3138.059|4.321|could do like you can like there's still
3140.52|4.28|best of them and do this kind of expert
3142.38|2.42|iteration
3147.0|3.54|uh so the first question is could you
3148.92|4.08|more clearly describe the full training
3150.54|4.1|process for child GPT example starting
3153.0|4.92|with the best
3154.64|5.919|201c.001 then xdd or program data of Y
3157.92|4.74|step so I left
3160.559|4.081|sorry I didn't I didn't catch that start
3162.66|5.0|with text Adventure zero zero one and
3164.64|5.219|then so how much uh
3167.66|4.179|how many steps of part of that pitch
3169.859|3.061|kind of things
3171.839|4.141|um
3172.92|6.12|I think the exact numbers are not public
3175.98|7.68|uh it's basically similar to instruct
3179.04|6.0|gbt and for the instructory BT numbers
3183.66|5.64|um we had
3185.04|7.26|I think around 50 000 comparisons and
3189.3|4.86|probably like 10 000 demonstrations or
3192.3|4.819|like maybe tens of thousands I don't
3194.16|2.959|remember the exact number
3197.46|5.639|um so I had like this other slide with
3200.04|6.92|uh yeah I was like about 20 000 hours of
3203.099|3.861|human feedback that's what I calculated
3207.42|4.04|because that's you can get like one
3209.4|4.56|million or whatever attractions you want
3211.46|4.24|right I mean the big question is like
3213.96|3.72|how do you make how do you ensure
3215.7|4.1|quality
3217.68|2.12|um
3223.52|3.76|but it's the whole problem right like
3225.66|5.459|that assumes you already have the reward
3227.28|3.839|model that you trust so
3242.52|3.839|yeah so
3244.68|4.56|I mean
3246.359|5.821|the kind of like ambition of that plan
3249.24|4.74|is to train a model that can do this
3252.18|4.439|kind of conceptual research
3253.98|4.859|and you know you know you can picture
3256.619|4.98|the like a language model that like you
3258.839|4.74|know writes an alignment research paper
3261.599|3.421|that we you know like we read and then
3263.579|3.48|we're like oh this is a really cool idea
3265.02|4.26|we should try this
3267.059|4.741|um and I think
3269.28|4.559|you know going back to evaluation is
3271.8|4.019|easier in generation I think it also
3273.839|4.561|applies to alignment research and like I
3275.819|4.441|think at the very least like I find it
3278.4|4.26|much easier to evaluate you know
3280.26|5.52|alignment research than I find it to
3282.66|6.12|like produce it and so
3285.78|6.18|while there might be conceptual break
3288.78|5.7|shoes that we need that we couldn't even
3291.96|4.2|evaluate right now because they're just
3294.48|3.599|like you know if we saw them we'd be
3296.16|4.56|like what is this
3298.079|4.441|um and this is kind of like part like
3300.72|5.339|this is like the reason why we want to
3302.52|5.7|do scalable oversight right because like
3306.059|3.961|if you know the language model produces
3308.22|5.46|this really brilliant insight and we
3310.02|5.7|can't even recognize it at the time
3313.68|4.139|um we should be able to have an easier
3315.72|4.859|time recognizing it if we use EI
3317.819|4.981|assistance and if we leverage like our
3320.579|4.921|best AI models
3322.8|4.14|to like figure out whether or not that
3325.5|2.76|was a good idea what it was the
3326.94|3.179|weaknesses and what are the strengths
3328.26|3.299|and like you know what kind of
3330.119|4.681|experiments should we run to know
3331.559|5.821|whether this is a good idea and so
3334.8|5.039|yeah I think basically
3337.38|4.26|you know the story of just using our lhf
3339.839|2.821|to train a model to do good alignment
3341.64|3.3|research
3342.66|4.56|you have the obvious pitfalls which is
3344.94|4.08|you know the model might write like an
3347.22|4.02|alignment proposal that kind of looks
3349.02|4.5|good to us but it's actually you know
3351.24|5.16|not a good proposal and it creates AI
3353.52|6.18|that is misaligned with humans
3356.4|5.159|um and so in order to distinguish it too
3359.7|4.08|which might be really hard maybe it's
3361.559|4.741|not but you know I think we should
3363.78|5.22|expect it to be really hard and then
3366.3|5.88|leveraging EI assistance to evaluate
3369.0|6.2|that seems like a really
3372.18|3.02|promising plan
3379.079|4.76|I mean that was my whole point it's not
3381.359|2.48|sufficient
3385.44|3.78|what do you think like do you need like
3387.18|3.6|something more or if you wanted what
3389.22|3.839|companies trying to do do you think like
3390.78|4.62|uh if you can like get a lot of feedback
3393.059|4.141|data will that be sufficient to get a
3395.4|3.48|various Generations or to be receiving
3397.2|4.5|more
3398.88|4.04|I mean the journalists or like
3401.7|1.68|I think the
3402.92|1.48|[Music]
3403.38|3.239|um
3404.4|3.9|basically the vast majority of the
3406.619|3.841|models capabilities and like all the
3408.3|3.84|cool things you see it do come from
3410.46|3.96|pre-training and now it's from the fine
3412.14|4.56|tuning stage the reason why people
3414.42|5.939|sometimes attribute to the fine-tuning
3416.7|4.919|stage is that you didn't see it in the
3420.359|4.141|pre-trained model
3421.619|4.561|and the reason I think the reason that
3424.5|3.599|we didn't see it in the pre-trade model
3426.18|3.6|is because the payment model was so
3428.099|3.121|misaligned it was not trying to help you
3429.78|4.559|and it was not trying to show you all
3431.22|5.16|the things it can do and instead it just
3434.339|5.041|regurgitates a bunch of random web text
3436.38|4.92|and that's not what you're looking for
3439.38|5.459|and so
3441.3|4.86|yeah I think what Jeff basically has
3444.839|3.301|been doing is like unlocking
3446.16|2.939|capabilities that we're already in the
3448.14|3.6|model
3449.099|3.901|and making those available for humans to
3451.74|3.18|use
3453.0|4.319|and in some ways like
3454.92|6.54|you know alignment research is very dual
3457.319|5.401|use in the sense that you know a if you
3461.46|3.18|have really good alignment techniques
3462.72|4.74|you can use it to align with whatever
3464.64|4.02|values you want including values that
3467.46|3.84|you know we wouldn't particularly
3468.66|4.56|endorse and B
3471.3|4.259|it also
3473.22|4.619|like if you're doing alignment right it
3475.559|5.06|will always look a little bit like your
3477.839|5.76|midday AI system more capable because
3480.619|5.561|before it was wasn't really trying that
3483.599|4.381|hard to help you and now you've made it
3486.18|5.54|more aligned so you know you actually
3487.98|3.74|see these capabilities you already had
3491.88|5.42|um sure that's it
3494.339|4.501|um Japanese
3497.3|4.5|history
3498.84|5.279|[Music]
3501.8|4.42|documented for this decides to
3504.119|4.681|incentivize deception so how will
3506.22|4.859|contribute yeah so that was what I was
3508.8|4.319|talking about here right like
3511.079|3.901|um
3513.119|5.041|this is like the whole problem that we
3514.98|5.579|have where what humans about can
3518.16|4.02|evaluate is constant and so we won't be
3520.559|4.141|able to evaluate like sophisticated
3522.18|4.56|attempts at deceiving us and that's why
3524.7|3.96|we want to do scalable supervision so
3526.74|4.819|that we Empower humans to spot these
3528.66|2.899|attempts at Deception
3533.28|3.72|uh
3534.44|6.04|familiar network marketing inertness
3537.0|3.48|alignments decisions
3543.42|6.179|yeah so
3545.46|6.78|I think it's a real worries and
3549.599|5.661|to some extent we kind of like have to
3552.24|5.28|test empirically like how
3555.26|3.7|difficult and how severe they actually
3557.52|5.279|are
3558.96|6.599|um I think so my personal stance right
3562.799|4.861|now is something like I think trying to
3565.559|4.441|get the outer alignment signal really
3567.66|3.3|right is going to be like 90 of the
3570.0|4.2|effort
3570.96|4.859|and once we have that then a lot of the
3574.2|3.3|other things might also fall into place
3575.819|3.24|so for example
3577.5|3.0|I mean it kind of depends on which story
3579.059|4.081|of any misalignment you're worried about
3580.5|4.859|but you know one story is
3583.14|4.56|you kind of training assistant and it
3585.359|4.621|learns how to do
3587.7|4.32|it like learns basically a bunch of you
3589.98|3.42|know optimizers kind of like meta
3592.02|4.26|reinforcement learning
3593.4|5.34|so for example like gpg3 you can do like
3596.28|6.059|in context learning and that's like a
3598.74|7.14|kind of you know learned optimizer
3602.339|4.98|and so now you're like doing our lhf
3605.88|5.1|training or whatever like alignment
3607.319|6.121|training you have and you're like the
3610.98|4.74|the line optimizers land you do the
3613.44|3.96|thing that you want on distribution
3615.72|3.839|but now if you have a distributional
3617.4|3.719|shift and this distributional shift
3619.559|4.26|could be auto-induced meaning like the
3621.119|4.081|model is causing it itself
3623.819|2.76|um now you're going out of the
3625.2|3.72|distribution all these inner optimizers
3626.579|3.78|like try to optimize for something else
3628.92|4.639|and
3630.359|3.2|one way you could like
3633.839|3.96|and you know like how much that would
3636.48|3.599|actually happen practice kind of I'm
3637.799|5.82|clear but one kind of like more
3640.079|5.581|important question is like if you have a
3643.619|3.841|really reliable outer alignment signal
3645.66|5.699|and you have this like General training
3647.46|6.3|signal that you trust you can also use
3651.359|4.5|that you know on the new distribution to
3653.76|3.72|train the system to be
3655.859|4.74|more
3657.48|7.02|or like to get this inner optimizes in a
3660.599|5.641|row basically and so then you produce
3664.5|3.599|like the inner alignment problems too
3666.24|4.079|like how do you deal with distributional
3668.099|4.441|shift and how do you like construct an
3670.319|3.721|outer alignment signal that you trust
3672.54|3.84|and those are problems that we have to
3674.04|3.24|deal with anyways
3676.38|2.82|um
3677.28|4.74|but yeah I don't I don't know how it's
3679.2|6.419|actually going to shake out but
3682.02|5.599|um this is some important open questions
3685.619|2.0|um
3687.66|5.6|so regarding uh alignments one of the
3690.839|2.421|kind of
3693.599|5.941|problems is
3697.319|6.141|to see is that much interest it seems to
3699.54|3.92|like explaining why because
3706.7|4.96|decomposing these models is like
3708.96|4.68|explaining why even circumstances are
3711.66|4.439|fairly well I mean that's definitely the
3713.64|5.82|two corralities but
3716.099|5.101|um as to why it's making these uh
3719.46|5.28|have a lot of judgments have you all
3721.2|5.28|been able to interrogate them
3724.74|4.74|I mean I think
3726.48|6.3|where we are right now is like pretty
3729.48|6.66|deceptive despite satisfactory
3732.78|4.86|um I mean you can ask the model why it
3736.14|3.5|gave a certain response but you don't
3737.64|4.8|know whether it's answering truthfully
3739.64|4.6|and you can also I mean another thing
3742.44|3.6|you can do is you can give the model its
3744.24|3.599|own its response and ask it to find out
3746.04|3.72|flaws which is what we did in the
3747.839|5.581|Clinique's paper
3749.76|5.46|um but you know I think the like
3753.42|3.72|I mean there's one version where you try
3755.22|3.359|to make that better but then the
3757.14|2.939|question is like what has you gone to a
3758.579|4.621|signal
3760.079|5.701|um I think like better angle of attack
3763.2|4.56|is probably interpretability
3765.78|5.539|where you know like you figure out how
3767.76|3.559|to look inside the model and then
3771.5|6.339|that's what I was asking about the level
3774.24|6.319|of research is yeah it's like it seems
3777.839|5.72|that that's it really is
3780.559|6.04|yeah
3783.559|5.081|your current thinking is moving towards
3786.599|5.121|collect that race like reducing the
3788.64|3.08|nationality of that uh
3793.079|5.641|yeah I mean we are working on that
3796.859|4.021|problem but I don't think we have
3798.72|4.859|anything that is like to show right now
3800.88|7.02|and so
3803.579|7.141|um it seems generally not to be a very
3807.9|5.399|easy problem but you know I'm I'm
3810.72|4.98|hopeful that we can do some things I
3813.299|5.701|think in general
3815.7|5.22|the problem of interpretability or like
3819.0|4.68|using interpretability for alignment is
3820.92|5.699|kind of tricky because
3823.68|5.28|I suspect it's going to be neither it's
3826.619|4.74|going to be not sufficient and it might
3828.96|5.099|not be necessary so any amount of
3831.359|4.561|integral you can you can leverage would
3834.059|4.02|be useful because it's another tool in
3835.92|4.8|your toolbox of like detecting deception
3838.079|4.861|or like knowing you know what you said
3840.72|5.24|like how why the model gave a certain
3842.94|4.859|answer and made a certain decision and
3845.96|3.879|start
3847.799|4.621|you know it is
3849.839|4.141|kind of unclear if you really get really
3852.42|2.82|good at interpretability how you then
3853.98|3.78|leverage that
3855.24|3.72|for alignment like presumably you could
3857.76|3.42|look in the model and just like throw
3858.96|5.04|all the models out that you can find in
3861.18|4.139|misalignment in but then aren't you just
3864.0|2.76|selecting for models that have
3865.319|2.52|misalignments they're really hard to
3866.76|2.28|find with you and show you the body
3867.839|3.681|tools
3869.04|2.48|sure sure
3880.4|7.06|does not be necessary
3883.619|6.121|yes so why would it not be necessary so
3887.46|4.32|again this is kind of like an open
3889.74|4.859|question but
3891.78|5.1|basically what stance you could take is
3894.599|5.041|that at the end of the day what really
3896.88|5.28|is going to matter is the decisions that
3899.64|5.34|the model actually takes and not the
3902.16|4.199|reasons why it took them and so if you
3904.98|3.48|can get to the point where you're
3906.359|3.541|confident that all the things the model
3908.46|4.2|actually does
3909.9|5.159|are aligned with what you want
3912.66|4.56|then does it still matter what the model
3915.059|3.5|thinks internally
3917.22|4.339|I don't know
3918.559|3.0|yeah
3922.22|3.46|of the model yeah that's that's what
3924.66|2.76|we're trying to do right like we're
3925.68|3.419|trying to make like a really really good
3927.42|4.32|evaluation signal
3929.099|3.96|and then you can select for you know you
3931.74|3.9|can train the model to do the things
3933.059|5.04|that you wanted to do because you can
3935.64|5.24|just always evaluate better than the
3938.099|2.781|model can do stuff
3947.7|3.48|um
3948.68|5.7|but yeah thanks so much for the great
3951.18|3.2|lecture very interesting
3956.119|8.94|to do like a live on uh just like uh
3960.48|4.579|application thing yeah sure sure
3965.54|3.72|eyeglass sorry
3970.339|3.181|oh yeah
3974.4|2.12|thank you