start_time|end_time|text
0.0|3.92| So in this video, I want to briefly talk about broadcasting,
3.92|3.32| which is a concept that makes working with vector and matrix
7.24|2.96| computations more convenient on a computer compared to, for
10.2|3.32| example, pen and paper or the traditional way of doing linear
13.52|5.6| algebra. All right, so yeah, let's start with vectors. So if
19.12|5.48| you look at this notation here, w transpose x plus b equals z.
24.88|3.96| So you recall how this is called like to check yourself, there's
28.84|4.28| a certain word for that result. Maybe pause the video, think
33.12|4.96| about it briefly. Yeah, so the result is net input. So we
38.08|3.04| learned in the perceptual nature that we usually call that the
41.12|4.44| net input. So I mean, I'm just providing this as a simple
45.56|5.6| example here. So we're x and w would be two vectors here. So we
51.16|7.16| would do w transpose dot x plus b. And this would be the proper
58.32|4.52| linear algebra way of computing the net input. So in linear
62.84|3.32| algebra, the supported operations for a vector
66.92|5.72| addition, you can also think of subtraction if we add a vector
72.64|3.32| with negative values, and then the inner products like the dot
75.96|3.92| product would be one of them, and scalar multiplication. So we
79.88|4.44| can multiply a vector by a scalar. So these are the only
84.48|3.76| proper I would say, yeah, basic vector operations that you would
88.24|4.96| find in a traditional linear algebra textbook. Now in
93.2|3.6| practice, though, if you work on a computer, there are a few more
96.8|3.64| possibilities that can make our life easier. They wouldn't be I
100.44|4.52| would say valid linear algebra operations in the traditional
104.96|3.96| sense. So let's say if you write a paper for a linear algebra
108.92|3.2| journal or something, they would maybe complain about this. If
112.12|2.4| you would do this on pen and paper, but on a computer, it's
114.52|5.52| possible, for example, to add a scalar value to a vector. So
120.56|3.44| also, you can, let's start at the top. So let's say we have
124.0|4.76| two vectors, a and b here implemented as pytorch tensors,
128.96|2.8| a one dimensional pytorch tensors. So what we can do in
131.76|3.44| pytorch is we can multiply these two tensors. So that is
135.2|3.2| something in traditional linear algebra, which would be not
138.4|3.96| valid, but here it is, which is nice. And then the other one is
142.36|2.84| you're adding a scalar to a vector. So what will happen is
145.48|4.68| it will add the value one to each individual element in the
150.16|2.6| vector, which is also convenient, you have to be a
152.76|5.08| little bit careful about that. Sometimes it's easy to make or
157.84|4.08| to compute something that you don't intend. So it can also
162.12|3.92| make mistakes a little bit easier. But in many, many cases,
166.04|4.6| this makes life easier. So you don't have to, for example, in
170.64|2.64| traditional algebra sense, linear algebra sense, what you
173.28|2.62| would have to do is you would have to create a vector of ones
175.9|3.74| and edit, for example, you would have them 123
181.2|5.0| plus 111. Right? So that would be the linear algebra way. But
186.2|3.08| here, you don't have to create this explicitly, it will
189.28|4.24| implicitly implicitly add this one, which is kind of nice. So
193.52|3.96| that would be one convenience function. This is also related
197.48|4.2| to the concept of broadcasting, which I will explain further in
201.68|4.84| the next couple of slides. Yeah, now in the next couple of
206.52|4.92| slides, we will be talking about some concepts around matrices
211.56|3.12| that are different from the linear algebra traditional
214.68|5.2| sense, and linear algebra on the computer. So if you think back
219.88|4.16| of the perceptron algorithm, this is typically considered an
224.04|4.08| online algorithm. Online means it processes one training data
228.12|4.22| point at a time. So if you think back, you do, you look at one
232.34|2.22| training data point, and then you update or not, and then you
234.56|3.68| look at the next data point, and then you update or not. However,
238.24|3.2| if you have trained your perceptron model, you can
241.44|4.24| actually do the prediction on the test examples, all at once,
245.68|3.36| you don't have to do one data point at a time. This is because
249.04|3.68| we don't train it anymore there. So we can really just feed it a
252.72|5.32| gigantic mat matrix of n training examples, and then do
258.04|3.64| all the computations at once. This will make it more efficient
261.68|3.08| because now we can do a matrix multiplication inside the
264.76|3.72| perceptron instead of processing each feature vector. So instead
268.48|3.0| of providing the first feature vector doing the computation,
271.48|3.32| the net net input, and then doing the second one, and so
274.8|4.28| forth, we can now give it this gigantic matrix. So we can avoid
279.08|4.76| having a for loop for prediction. Yeah, that is
284.12|3.08| essentially what I have written here. And the reason why it's
287.2|3.48| more efficient is that the computer can leverage lower
290.68|4.48| level routines to compute certain things in parallel. So
295.16|5.88| there are two opportunities for parallelism. One is multiplying
301.04|4.2| the elements to compute the dot product. So if you have, let's
305.24|5.14| say a weight vector here. So let me, there's no space really,
310.38|4.7| but let's say we have my weight vector here. And then if we
315.08|4.4| multiply this weight vector with the first feature vector, so
319.48|4.36| there's a multiplication between the first element, multiplication
323.84|4.72| between second element, and so forth until the last element and
328.56|3.1| these multiplications can be done all in parallel, and then
331.66|4.14| summed up, that would be one way for parallelizing that the
335.8|3.6| second way would be parallelizing the dot
339.4|4.6| products. So while you compute the product here, I'm showing
344.0|3.56| you in pink, you can have a second process running that
347.56|3.24| already computes the product between the second row and this
350.84|4.64| vector, and then one in parallel that already computes this and
355.48|4.08| this. And then lastly, this and this. So if you have four
359.56|3.08| processors, for example, you could compute all these four
362.64|3.04| dot products in parallel at the same time, you don't have to
365.68|4.72| wait until one finishes, right. So in that way, you can make the
370.44|3.16| computation more efficient. So you have a little question for
373.6|3.52| CS majors, who are maybe familiar with the notation big
377.12|4.72| O. So what would be the big O complexity of matrix
381.84|3.84| multiplication, if you assume that we have two n times n
385.68|3.4| matrices, there's just like a optional question, just seeing
389.08|3.68| if you if you know this, you can post this on Piazza, we can have
392.76|2.96| a little discussion. But of course, also non CS majors are
395.72|3.12| invited to participate in this discussion. But I'm just curious
398.84|4.48| if you are familiar with these things. All right. Yeah, like I
403.32|2.84| mentioned, there are these two opportunities for parallelism.
406.32|3.72| Here's a more concrete example, computing the net input and net
410.04|4.48| input. Now, instead of having a single feature vector, we have
414.52|5.92| now this matrix, the design matrix, which is n times m
420.44|3.36| matrix, n is the number of data points, m is the number of
423.8|9.44| features. And w is m dimensional vector, right. So the output of
433.24|6.36| this would be n times one, right. So the output of
439.6|7.4| multiplying x and w would be n times one dimensional vector.
447.32|6.28| And this is also why we actually have this extra dimension for
454.6|4.24| the vectors because you can't really in linear algebra in the
458.84|3.84| traditional sense, you can't really compute or multiply to a
462.68|2.84| matrix multiplication between a matrix and a vector, you can
465.52|3.04| only do a dot product between two vectors and a matrix
468.56|3.96| multiplication between two matrices. So in this way, for
472.64|4.4| correctness, this vector w is actually a matrix m times one
477.04|4.44| matrix so that we can do the matrix multiplication between
481.48|3.48| the matrix and the feature vector. It's a little bit weird.
484.96|3.68| It's just like, I'm just mentioning it here in terms of if
488.64|2.88| you stumble upon it, if you have learned linear algebra in the
491.52|2.84| traditional sense, and you think maybe that doesn't make sense in
494.36|3.6| computer. Yeah, in the computer computing context, we are a
497.96|3.8| little bit more forgiving about these little things. So yeah,
502.48|3.8| alright. Yeah, here's an example of computing the net input on
506.28|4.72| the whole slide. And this is then z, z would be a vector. So
511.0|4.92| we would be adding the B to every dot product. So each of
515.92|3.28| those is a dot product, plus the bias unit, and that gives us the
519.2|5.28| net input. So the net input is also a vector for the training
524.48|4.6| example. So we have n data points. For example, I said
529.08|3.32| training examples, but it would be more like the test data
532.4|3.76| points in the context of the perceptron. In other algorithms
536.16|3.2| that we will be talking about in the next few lectures, we can
539.36|2.44| also do that with training examples in the perceptron
541.84|4.08| example. This would be technically the test examples,
545.92|2.52| because, yeah, like I said, in the previous slide, the
548.44|2.36| perceptron is an online algorithm, it can only process
550.8|5.4| one data point at a time. Alright, moving on. So here's
556.52|5.72| example of that in pytorch. So both NumPy and pytorch are not
562.24|4.76| very picky about traditional linear algebra notations. So I
567.0|7.64| said before, this has to be this is an sorry, n times n matrix,
574.64|8.88| and W is an n times one vector. But pytorch is not very picky
583.52|3.36| about that. So we can actually also omit this dimension. So
586.88|6.84| here, I'm showing you a matrix, two by three matrix. That's just
593.72|5.68| a shortcut for making a matrix of value 01234 and five. So it's
599.4|5.44| a two by three matrix. And now I have a weight vector, just a one
604.84|4.88| dimensional vector 123. And I can actually multiply x with W
610.72|4.92| will give me a eight times 26 vector with a values eight and
615.64|5.24| 26. So this would be also vector with only one dimension and two
620.88|6.36| elements. However, so instead of having this vector, I can add
627.24|2.96| I can add another dimension to this vector with this view
630.2|4.64| function. This is similar to NumPy reshape, which I explained
634.84|4.2| in the tutorials that I provided to you if this is unfamiliar,
639.28|2.6| maybe refer to the NumPy tutorials again, where I
641.88|3.04| explained the reshape and where the minus one comes from. But
644.92|3.52| also, if this is confusing, please ask on Piazza, I'm really
648.44|5.08| happy to explain that again. Alright, so now, the W here is
653.52|6.24| now a vector. So this is a column vector would be 123 with
659.76|8.12| another dimension. So this is a matrix of m times one matrix now
667.92|4.44| like we had before here. And we can also do that. Now, this is
672.36|6.84| not necessary. But you can see now, the output is also m times
679.2|5.86| one, sorry, this is actually n times one dimensional matching
685.06|4.28| the number of rows here, this is n times one dimensional,
689.62|13.88| whereas this one here is only n dimensional. So we have, sorry,
703.54|3.48| there's n elements with only one dimension. Yeah, it's a little
707.02|3.2| bit confusing when we call or talk about dimensions, if we
710.22|2.72| talk about a vector, say n dimensional vector, it means it
712.94|3.12| has the number of elements. If we say n dimensional array, it
716.06|5.92| means the number of dimensions or axes. So here, this is only
722.02|4.48| one axis with n values, and this is an n times one matrix. So
726.5|4.36| this is a vector in the traditional sense. And this is,
730.86|12.6| um, you can think of it as a column vector or n times one
745.22|4.32| matrix. But yeah, this is just nitpicking what I'm doing here.
749.54|3.0| I'm just showing you that both ways are possible in pytorch.
753.06|4.04| Yeah, and if you like nitpicking or hair splitting, so there was
757.1|4.52| actually one little mistake from a traditional linear algebra
761.94|4.0| perspective in the previous slide. So here, just asking
765.94|3.04| whether you can spot the mistake. So there's something
769.02|5.6| here that is not possible in traditional linear algebra. So
774.62|4.04| yeah, what's not possible here is that we are adding a scalar
778.82|4.48| to a vector, right? So in a one, let me go back. So here, I'm
783.3|5.44| actually adding it explicitly as a value. But in a traditional
788.74|3.4| linear algebra sense, you can't add a scalar to a vector that is
792.14|3.28| not valid. So in a traditional linear algebra sense, you would
795.42|3.56| have write it like this. But to be honest, the context of deep
798.98|2.76| learning, no one does that it's way too much work. And yeah, we
801.74|3.52| deep learning researchers are lazy. I just wanted to go over
805.26|3.72| these things. Because some of you might complain what type of
808.98|3.36| math am I using here? Because this is not making sense. I've
812.34|2.8| learned that differently. So I just wanted to illustrate that
815.14|5.12| in deep learning, we have our own rules in a way. Alright. So
821.1|3.2| yeah, lastly, the topic I promised for this video is
824.3|5.0| broadcasting. So yeah, in broadcasting, what we do is we
829.94|3.28| are we can add the one to the vector, like I just mentioned
833.22|5.4| before, not only that, it's also possible yet to add a vector to
838.62|4.04| a matrix, for example. So let's say we have a matrix here. So
842.66|4.6| here, I'm creating this matrix as a two by three matrix, values
847.26|6.8| 456789. And now I have a tensor here 123, the same as above. And
854.06|6.56| I can now add this tensor to the matrix. And you can see, it's
860.62|6.2| adding these values, 123 to each of the rows. So it's adding
866.82|6.0| four, so the 123 to the upper row here. And it's adding also
872.82|4.0| the 123 to the lower row here. So the results are shown as
876.82|3.6| follows. So that is another thing that we can do in
880.82|6.72| computing. So and this is called broadcasting. So under the hood,
887.74|3.04| pytorch, and the same thing is also true for NumPy, they will
890.78|3.72| create another dimension implicitly. So you can't see
894.5|2.4| this dimension, but it will just do it internally, because it's
896.9|2.52| kind of guessing of what you want to do. So in this case,
899.42|5.68| under the hood, basically, it's extending this one to a tensor.
905.54|3.2| So then you can add these two tensors together, which will
908.74|2.92| give you two, three, and four, this is something that happens
911.66|2.52| under the hood. And this is called broadcasting, like
914.78|3.4| adding this implicit dimension. And the same thing happens here,
918.58|3.84| where we have the matrix that we add to the vector or the vector
922.42|3.48| to the matrix. So there will be also this implicit dimension
925.9|4.48| where the values are duplicated. And then this also works. So
930.38|3.36| yeah, this is the concept of broadcasting. And all I've
933.78|2.6| shown you in this video was hopefully not too confusing.
936.58|4.12| It's somewhat showing you that the rules and computing are a
940.7|3.64| little bit more relaxed and more geared towards convenience
944.34|4.96| compared to pen and paper linear algebra. Alright, so then in the
949.3|3.52| next video, I will go over some of the notational conventions
952.82|4.4| from neural networks, and then briefly about cover some concepts
957.22|3.72| related to fully connected layers and pytorch and some more
960.94|4.2| convention. So these videos in general, this, yeah, not this
965.14|3.8| week, today, a little bit drier than usual. But I think this is
968.94|3.56| just some foundation that we will need when we talk about
972.5|7.0| multilayer networks soon.