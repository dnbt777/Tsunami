start_time|end_time|text
0.92|3.28| Yeah, in practice, one of the best ways you can improve the
4.2|3.04| performance of your model is really just to focus on the
7.24|5.36| data set itself before you do anything more fancy. So in this
12.6|3.48| video, I want to briefly talk about two ways for improving the
16.08|3.16| performance by focusing on the data set. One is by collecting
19.24|3.48| more data. And the other is by augmenting the data that you
22.72|6.56| already have. So how do you know whether more data could be good
29.28|4.76| for your model. So there's a technique called learning curves
34.04|5.96| or the techniques. Let's say the method is called making a
40.0|4.8| learning curve. And how does that work? So yeah, I'm showing
44.8|3.92| you an example where I made an learning curve for softmax
48.72|4.68| classifier using the M or a subset of the MNIST data set. So
53.4|3.56| why the softmax classifier that was when I made this, it was
56.96|3.92| just quick because softmax is faster to train than a multilayer
60.88|2.92| of reception. So that was more like for efficiency reasons. But
63.8|3.36| this should work for any type of neural network to help you find
67.16|4.52| out whether more data is useful. So what you can see here is on
71.68|3.68| the x axis on different training set sizes. So I was changing the
75.36|4.32| size of the training set that I used for training the softmax
79.68|5.76| classifier. So I was varying it from here, it's maybe around
85.44|7.32| 100 training examples up to here, it's around 3500 training
92.76|4.16| examples, I was changing the size of the training set. But I
96.92|3.48| was keeping the test set size constant. So I was using the
100.4|4.92| same exact same test set, just different models, because the
105.36|3.84| training set sizes were different. So in the beginning,
109.24|3.4| so let's just briefly talk about the training set accuracy to get
112.64|2.84| it out of the way. So you can see that the training accuracy
115.48|3.88| goes down when we add more data. So why is that? I mean, this is
119.36|3.4| like a little bit unintuitive. And this does not always happen.
122.76|3.4| I think here, it's just because it's such a simple model. So if
126.16|3.48| you have a very small data set, actually, it's easy to overfit
129.64|2.16| the data. So you will always find if you have a very small
131.8|3.2| data set that you have high accuracy, and then it goes down.
135.0|2.92| But usually, it also, it might go up again, if you have more
137.92|3.44| data. So I wouldn't pay too much attention here on the training
141.36|5.16| set accuracy. What's actually more interesting is that the
146.52|4.4| test set accuracy goes up. Right? So that is what we want
150.92|3.44| to see. And you can also see here, the gap between training
154.36|5.68| and test set performance on shrinks. So whether the training
160.12|3.88| accuracy stays constant or not, doesn't really matter what's
164.0|2.8| remembering here is that the test set accuracy goes up. And
166.8|3.28| just by that one fact, even if the training set here would be
170.08|5.32| constant, we would reduce our fitting. So in that way, we
175.4|4.72| don't know really what happens beyond 3500. Right? So we have
180.12|3.64| no idea what's gonna happen in, let's say in this region
183.76|6.42| between 3500 and 5000, or even beyond that. But just by looking
190.18|3.14| at this slope here, if you just look at that slope, you can,
193.8|4.84| you can just argue or imagine that the performance might even
198.64|4.12| crew improve further beyond here. So here, it might just be a
202.76|3.24| good idea to just collect more data. So for instance, if this
206.0|4.52| is like, really what's going on, then by just collecting 1000
210.52|3.28| more training examples, you could already increase the other
214.72|8.72| performance from, let's say, 91%, to maybe up to 93% here. So
223.44|3.2| it's 2% points in this very high region here already. Of course,
226.64|4.12| this is only speculating. But yeah, sometimes adding more data
230.76|4.32| helps. And this can be diagnosed by making such learning curves.
235.52|2.16| One thing I should say, though, is maybe you shouldn't use the
237.68|3.72| test set for doing that, because you should only use the test
241.4|3.48| that ideally once at the very end, instead of using the test
244.88|3.08| set, you may want to use the validation set. So in the
247.96|2.36| previous lectures, we always use the validation set during
250.32|3.92| training, it's usually a better idea to not use the test set. So
254.24|4.88| just wanted to clarify that. Okay. Yeah, that would be one
259.12|3.72| way of finding out whether more data helps. The other topic for
262.84|5.44| this video is looking at data augmentation, like modifying the
268.28|4.36| data that you have already. So here at the top, I'm showing you
272.64|4.64| again a snapshot from MNIST. So here are just some example
277.28|3.32| images from MNIST. And at the bottom, I'm showing you
280.6|3.84| randomly augmented versions of that. So what you can see is
284.56|4.4| here, they are slightly zoomed in. But moreover, you can also
288.96|2.8| see this one is slightly rotated to the left compared to this
291.76|3.48| one. So these are really pairs. This is slightly rotated to the
295.24|3.44| right and so forth. So I'm creating modified versions. So
298.68|4.64| why would I do that? So those can really help the network to
303.36|3.4| not memorize exact pixel locations, right? Because, for
306.76|5.84| instance, it might memorize these two, some locations here,
312.72|4.28| just memorizing them. But if you randomly rotate it, it can't
317.0|2.72| exactly memorize these locations, it has to learn more
319.72|3.48| than just these locations, it has to more learn the shape, or
323.44|2.52| at least a couple of more locations, right, because it
325.96|3.92| can't always rely on these positions, it has to learn the
329.88|4.8| relationship between these positions. So in that way, data
334.68|4.24| data augmentation can be a cheap way of helping with the
338.92|3.52| generalization performance. So I don't want to go into too much
342.44|2.96| detail. I mean, like making a new video for the code notebook,
345.4|2.64| because yeah, I would maybe take too much time, and it's not
348.04|3.08| necessary, because it's actually pretty straightforward. And I
351.12|4.4| can describe this here, I think on that single slide. If you
355.52|2.56| want, though, I have the whole code example here on GitHub,
358.44|4.36| which you should be able to run just from there. I will also
362.8|4.88| post the link on canvas, of course. So recall, in the last
367.68|3.04| week's lecture, we call we talked about these custom data
370.72|4.44| loaders, where we use the data set. So here, I'm showing you
375.16|3.92| again, this data set. So but last week, when we did that, we
379.08|4.16| used a simple transformation here as the argument for
383.24|4.96| transform. We used to tensor, which is just converting an
388.2|4.32| image into a pytorch tensor. Now we are using a fancier version,
392.52|3.64| we let's call it, let's say we call it training transforms. And
396.16|2.24| training transforms is shown here on the top. So let's
398.4|5.48| discuss that first. So we are using a library called torch
403.92|3.2| vision for that. And this one should already be installed when
407.12|5.08| you installed pytorch. So if you go to pytorch.org, and execute
412.24|3.24| the installation command, you may have noticed that it already
415.48|5.8| included torch vision. So here, what you can see is that we are
421.28|3.92| using torch vision, the transforms sub module, and
425.2|5.88| there's a compose class, which lets us chain different or
431.08|4.32| multiple transformations. So here, I'm just showing you a
435.4|2.68| selection of those. But there are of course, more of them that
438.08|2.64| you may find online here under this website, there's a whole
440.72|4.2| bunch of those. So here, I'm using resize random crop random
444.92|4.92| rotation, and then the two tensor and normalization. So
449.84|4.36| let's talk about them one by one. So resizing. So MNIST
454.24|3.4| images are 28 by 28. I'm resizing it, making them
457.68|4.4| slightly larger, and then cropping them back to 2828. This
462.08|4.96| is essentially zooming in or cropping a random region from
467.04|4.08| that image. So why am I doing that? I mean, it's not always
471.12|3.46| helpful in the case of MNIST, it's maybe not always such a good
474.58|6.9| idea. Because, I mean, it's not technically necessary. But if we
481.48|3.76| do that consistently, for both the training and test set, if we
485.24|3.32| zoom in both, then this is essentially similar to
488.56|4.0| translating the image. So moving it slightly to the left and to
492.56|5.0| the right and top and bottom. Because I should say for it,
497.6|2.36| we'll talk about the test transformation in a second,
499.96|3.48| let's finish the training set transformation. So yeah, we do
503.44|3.76| the resizing the random crop. Then I do also a random
507.2|6.56| rotation. So here, up to 30 degrees, some minus 30 degrees
513.76|3.36| to the left up to minus 30 degrees to the right. So this
517.12|2.36| is randomly sometimes it's a small value, sometimes there
519.48|3.6| may be no rotation. So it's really random. So this helps us
523.08|4.44| like really almost creating infinitely many new flavors of
527.52|4.76| our existing images. I'm using this interpolation here. It's, I
532.28|3.68| would say, it's not ideal either, but it's better than the
535.96|3.44| default. So you can see it looks a little blurry, but it also
539.4|3.96| has something to do with zooming. But if you don't do
543.36|3.68| that, you will see these images are a little bit more, I would
547.04|3.44| say, jagged. So the edges are a little bit more jagged. So in
550.48|4.68| that way, there's no ideal way I find this one is slightly better
555.2|4.04| than the default. But this is really up to you which one you
559.24|3.16| use, you can also actually ignore that if you like. Oh, yeah,
562.4|4.88| then we are converting. So here, during these steps, the data is
567.28|3.12| still in an image format here, it's then converted to a pytorch
570.4|5.28| tensor. And by default, to tensor will, like we discussed,
575.88|3.92| will normalize the images such that they are in a zero one
579.8|6.28| range. But for gradient descent, it might be better to have unit
586.08|6.64| variance and zero mean, so having them standardized. So how
592.72|4.84| can we do that? So there's a normalize transform here. So
597.56|3.88| where we can choose a mean and a standard deviation. So in this
601.44|3.0| case, because we know the data range for each feature, it's the
604.44|5.32| same, it's on the pixel values between zero, up to 255. Or in
609.76|4.16| that case, if we normalize them between zero and one, what we
613.92|4.24| can do is we can choose point five as the mean, and point five
618.32|2.64| as the standard deviation, and then the images will be
620.96|3.72| afterwards in the minus one to one range. So why is that
624.84|5.0| standardization works like that, if we have an input feature, or
629.84|3.24| let's say this is our normalized feature, it's a pixel position.
633.08|9.28| And then we subtract for this given pixel, the mean over the
642.36|4.04| pixels over all the pixels in the data set in this position. So
646.4|7.36| let's call it feature J. And this is the mean for feature J.
654.16|3.64| And then we divide it by the standard deviation for feature
657.8|7.18| J. And this will give us a unit variance and zero mean. So
664.98|3.46| standard deviation of one, here, we are choosing these values
668.44|6.06| such that we have a zero mean. But our standard deviation was
674.5|3.68| of one sorry, yeah. So that is what we are going to do here. So
678.18|5.2| the images will be in the range minus one to one, because the
683.38|6.08| largest value is one. So one, let's do it slowly. One minus
689.46|14.44| 0.5 is 0.5 divided by 0.5 is one, right? So and if the input
703.9|5.92| pixel zero, zero minus 0.5 divided by 0.5 is minus one, so
709.82|3.36| they will be in the range between minus and one in this
713.18|7.56| case. Alright, so this is how we could augment our input images
721.34|3.72| for the training, but we have to be careful now for the test
725.06|2.64| set, we don't want any randomness in the test set,
727.7|4.08| right. So here, we are doing things randomly, we don't want
731.78|2.8| any randomness usually in the test set. So here, I was
734.58|3.44| actually for the test transforms, I was removing all
738.02|3.4| the random parts. However, because I use resizing and
741.42|3.52| random crop, I also should use them in the test set to have
744.94|3.76| things consistent. Otherwise, all the tests that images will
748.7|2.52| look smaller than during training, which might not be a
751.22|2.96| deal. So here, I'm using the resize, but I'm using a center
754.18|3.08| crop. So it's cropping the region in the center, rather
757.26|7.0| than randomly. So if I go back one slide, for instance, it's
764.26|2.74| hard to see here, but they're almost like center cropped here.
767.0|5.22| But so this one is maybe slightly to the left. So if that
772.22|3.16| was a testing image, it would might be more to the left here.
776.02|5.12| So in that way, um, we avoid randomness here. Okay, um, yeah,
781.14|3.68| and like I said, we are providing the train transforms
784.82|3.72| to the data set here, and the test transforms to the test set
788.54|3.0| here. And we would also use the test transforms for the
791.54|0.92| validation set.
792.46|4.44| Alright, so I should maybe also add, we only have one color
796.9|4.92| channel for MNIST. So if we work with RGB images, we want to also
801.82|2.72| make sure that we do the standardization for each color
804.54|4.48| channel. So if we have RGB, we would have three of these
809.02|4.08| values. In practice, people also sometimes compute the mean and
813.1|2.64| standard deviation over the whole data set by themselves,
815.74|4.64| basically for each channel. But that is a little bit more
820.38|3.44| work. So you can do that. Sometimes people also use these
823.86|5.16| statistics from the image net data set. But in practice, I
829.02|4.48| find it makes only a small difference whether you use the
833.5|2.24| actual mean and standard deviation of the data set, or
835.74|6.36| you just use these placeholder values. Alright, so these were
842.1|3.24| like, two ways you can improve the performance by just looking
845.34|3.36| at the data set, that is by plotting these learning curves,
848.7|5.84| and augmenting existing data. In the next video, I want to show
854.54|3.88| you, yeah, how early stopping works. I mean, just
858.42|2.64| illustrating the concept of early stopping, we have briefly
861.06|2.4| seen that, or discussed that already in the previous week,
863.46|3.16| when we talked about double descent. But yeah, I just want
866.62|12.8| to recap for completeness, how are you stopping works.