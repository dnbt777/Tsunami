start_time|end_time|text
1.24|3.92| Yes, so in this video, I want to talk about adding a penalty
5.16|3.36| against complexity. So we will be talking about the so called
8.52|3.36| norm penalties that we can add to the loss function. There are
11.88|3.68| two common versions, the one and the two norm. And what they
15.56|3.04| essentially do is you can think of it on maybe in the context of
18.6|3.92| a multi layer perception. Let's say we have a hidden layer with
22.8|3.44| three units and two output units. And then we have, let's
26.24|5.28| say to, to input features here. And yeah, as you know, everything
31.52|5.12| is fully connected. Let me quickly draw that. So if we have
36.64|4.96| a setup like this, and we have a large weight connection at this
41.6|4.64| point, it's called w one, compared to the other weights,
46.24|5.44| let's say this is a very large weight, then here, w one will
51.68|3.04| have a large effect on the network, although it's only one
54.72|3.52| feature that has, let's say a large weight. So if you have a
58.24|3.24| lot of inputs, that might happen that there's one large weight,
61.48|2.92| and then it outweights all the other features. So that could
64.4|4.6| be causing a lot of noise or variance in the model, it could
69.0|3.6| be very susceptible to small changes in the input that way.
73.44|3.96| And by adding like a penalty against large weights, by
77.4|4.32| keeping them more small and more uniform or closer together, we
81.72|6.64| can help with preventing like fluctuations in the network. So
88.36|3.84| yeah, you probably heard about l one and l two regularization
92.4|3.44| from other statistics classes. So I will keep it relatively
95.84|2.92| short here. It's also not the most important technique in deep
98.76|3.72| learning. So it's also not what I'm saying is, it's also not,
102.52|3.68| let's say, a priority in this course to talk about it, because
106.2|2.2| there are more, I would say important techniques to talk
108.4|4.2| about in the context of deep learning. But yeah, you may have
112.6|3.24| heard of this in the context of lasso regression. So lasso
115.84|3.52| regression is essentially a linear regression with an L one
119.36|4.12| penalty. And there's also rich regression, which is essentially
123.52|3.84| linear regression with an L two penalty. And sometimes that's
127.36|3.68| also called weight shrinkage, because yeah, it shrinks the
131.04|3.6| weight, because a large weight will add a penalty against the
134.64|3.6| loss, which will make more sense when I show you actually how it
138.24|6.76| looks like. So here is an illustration of the L two norm
145.04|4.88| or the two norm penalty. So to regularization, in a sense for
149.96|3.16| linear models, for example, for logistic regression, because
153.32|2.28| yeah, in this course, we talked more about classification rather
155.6|3.44| than linear regression, but everything on this slide would
159.04|3.44| also apply to linear regression. And then I will also later in
162.48|3.4| this video show you that how we can generalize that to
165.88|4.24| multilayer neural networks, it's actually pretty trivial. But
170.16|3.76| just for simplicity to take one step at a time, let's consider a
173.92|5.04| logistic regression model here, where we have the loss function
178.96|4.04| here, that's the negative log likelihood. And yeah, I'm just
183.0|3.92| calling this cost here. So I took this, I think, from my book
186.96|3.28| or something where traditionally, I differentiated
190.24|4.26| between cost and loss, I called cost, something that is
194.5|3.54| computed over the whole training set, whereas the loss is, for
198.04|4.08| instance, just on a single data point i here. But you can also
202.12|5.28| think of it as as loss if you like. So this is nothing new.
207.4|5.68| This is how we compute the loss between the true label and the
213.08|4.0| predicted label. And here, assume this is the binary cross
217.08|3.32| entropy or negative log likelihood, let's just say
220.4|8.04| binary cross entropy. That is, again, nothing new. What's new
228.44|3.52| is that we are adding now this term here shown here. And this
231.96|4.14| is essentially weighted, sorry, yeah, it's just a sum, the
236.1|4.74| credit rate. So the weights squared so that we don't have
241.24|4.08| negative values. So we are just adding a sum over the squared
245.32|5.68| weight terms here. So that means, the larger the weights,
251.0|2.88| because it's even squared, it's even having a larger effect, the
253.88|3.8| larger the weights, the larger this regularized cost will
257.68|3.68| become, right. So because if a weight has a large positive or
261.36|3.34| large negative value, this will make the regularized cost
264.72|4.12| larger. And what is this term here? So this is lambda over n,
269.0|2.56| this is just like a normalization term, and lambda
271.56|3.84| is, I'm saying it here, it's a hyper parameter, it's something
275.4|4.64| you have to choose. It's essentially the regularization
283.12|6.24| strength. Right, so the larger lambda, the stronger the
289.36|5.2| regularization, usually people use a small number like point or
294.64|3.16| one or point one for regularization. But of course, you
297.8|3.16| can also choose a lot a number larger than one, and then that
300.96|5.44| will be a pretty strong penalty. Yeah, and I'm not showing you
306.4|2.6| really l one regularization, because it's the same concept,
309.36|4.0| except that instead of using squared weights, it would use
313.36|7.2| the absolute value here. Yeah, so this here is a geometric
320.56|4.16| interpretation or a geometric intuition behind the l two
324.72|4.56| regularization. So this drawing is based on a seminar talk I
329.28|7.88| once saw by Professor Robert to Shirani, hope I'm spelling this
338.0|3.76| correctly or his name. He was one of the main people working
341.76|3.36| on these techniques, l one and l two regularization, if I
345.12|5.8| remember correctly. And what this is showing is, is a surface
350.92|7.04| plot of the loss function, let's say the mean squared error loss
357.96|5.84| loss for linear regression. And we have a model, a linear
363.8|3.04| regression model with two weights here. And let's ignore
366.84|7.16| the bias unit for simplicity. And in the center here, we have
374.0|3.64| the loss minimum. So that's the point we want to reach. So we
377.64|3.96| want to find the weights of the model, such that the losses
381.64|2.92| minimize the mean squared error is minimized. The further we are
384.56|3.12| apart here, these contours represent the magnitude of the
387.68|2.92| MSE. So the further we are to the outside, the larger the
390.6|3.24| loss. So really, we want to find the weights here, this position,
393.84|4.04| let's say if we only focus on the ellipsoids here, these weight
397.88|4.6| values that minimize the loss, that would be the regular MSE.
402.88|3.72| That is something we can do via gradient descent, for example,
406.6|3.44| as we've seen a couple of lectures ago. But now we have,
410.28|5.68| yeah, we have this new term, we have the two norm, right of the
415.96|8.52| weights. So we have two weights, right? So, um, over the two
424.48|4.4| weights, we have this L two norm, and it is added to the
428.88|4.08| loss function. So the larger the weights, on the higher the
432.96|7.0| penalty here, and this gray circle here represents the
439.96|7.32| penalty term. So this term here, now, it becomes essentially a
447.28|3.64| constrained optimization problem, we still want to find
450.96|5.68| or reach zero loss, but the loss consists now of two parts and
456.68|3.76| the parts that consist of this MSE loss, and this penalty term.
460.44|5.12| So the penalty term is really here is pink color. Penalty term
465.56|5.76| is really here like this circle. And the MSE loss here, it's this
471.32|3.36| one here. So we want to minimize both, we want to have small
474.68|3.08| weights. So we want to make weights close to zero because of
477.76|3.28| this term. But we also want to have the weights such that the
481.04|4.36| MSE here is minimized. So in practice, what will happen is
485.72|2.6| that, for instance, an optimization algorithm like
488.36|3.8| gradient descent, will find a good compromise between the two.
492.16|4.32| So for instance, it will try to keep the weights close to zero,
496.48|4.84| but also, it will try to keep them close to this MSE loss. So
501.48|2.8| for instance, it might find this compromise here between the two.
505.0|5.6| So you can see here for this part, let me use green. For this
510.6|2.88| part, these weights are not too large, so they're somewhat
513.52|3.24| close to the center that we want to minimize. But they are also
516.8|3.2| somewhat close to this point. So it's like a compromise between
520.0|3.72| the two. So that's how you can think of the L2 regularization,
523.72|3.88| it's still minimizing the main loss under the constraint that
527.6|4.16| we want to keep the weights relatively small. So in
531.76|4.92| practice, what the practical implication of that is, is that
536.72|3.92| let's say you have a model, let's say a multilayer perceptron
540.64|4.4| like that, it has a relatively complex decision boundary, it
545.04|3.44| will essentially make the decision boundary somewhat
548.48|2.68| simpler for it, for example, like that, if you have a very
551.16|3.24| strong regularization, it might even become like a linear model,
554.4|6.24| a very, too simple decision boundary. So yeah, usually, you
560.64|3.72| have to find a good hyperparameter for lambda, to
564.36|5.64| have a good regularization compromise here. So, in the
570.0|2.72| previous slides, I mentioned how that looks like for the
573.48|2.68| generalized linear models, like logistic regression, where we
576.16|3.2| have just the sum over the weights. So how can we
579.36|4.88| generalize that to multilayer neural networks where we have
584.24|3.48| multiple layers of weights, we don't only have a weight vector,
587.72|5.24| but also, we have like weight matrices. Actually, it's very
592.96|2.92| simple, we just use the Frobenius norm. So instead of
595.92|3.04| having the sum over the elements in the vector, so that instead of
598.96|3.72| having the L2 norm, we now have the Frobenius norm, which is
602.68|4.28| which is essentially the same as the L2 norm, except that we have
606.96|4.6| a sum over the rows and the columns in the weight matrix. So
611.56|6.08| we have here the Frobenius norm for one matrix, one matrix in
617.64|3.96| the layer L. Of course, we have multiple weight layers. So in
621.6|6.4| that way, you can either have a different lambda for each, so
628.0|2.84| you can have a lambda for each layer, or you can use the same
630.84|2.24| lambda for all the layers. But you also don't have to
633.08|3.64| regularize all the layers, but that's usually common. So here,
636.76|4.24| for instance, you would have a summation also over the
641.04|3.24| Frobenius norms for the L layers, you can see that here,
644.28|4.44| that's the L layer weight matrix. And each, each
648.72|2.56| Frobenius norm would be computed via these two sums over the
651.28|4.92| columns and the rows. So it's just a simple summation of the
656.2|6.84| weights. Actually, the squared weights, of course. So now that
663.04|4.8| we modified the loss function, so how do we do the training if
667.84|3.8| we use gradient descent, it's actually pretty straightforward.
671.64|3.72| So gradient descent, recall, we take the derivative of the loss
675.36|2.88| function with respect to the weights. And we would do the
678.24|5.32| same thing now with the added penalty here. I mean, if you
683.56|3.28| think about it, this is just plus, right? So it's a sum, a
686.84|5.64| sum between the normal loss, let's call it the normal loss,
692.76|8.72| and this regularization term, because it's just a sum, we can
701.48|3.36| use the sum rule, and we can compute the derivatives
704.88|4.08| separately. So this is the derivative as usual that we
708.96|3.56| talked about, or gradient, if you will. And then we can also
712.52|3.08| Yeah, compute this part separately and add them up. So
715.6|2.44| for instance, if we have the gradient or partial derivative
718.04|3.08| of the loss with respect to one of the weights here, we would
721.12|5.6| have for the weight ij, the derivative of this regularization
726.72|3.12| term as follows, because it's Yeah, it's just a square term,
729.84|4.96| right? So if it's on, like this, we can just bring it up front,
734.8|3.04| right? So in that way, very simple derivative, except that
737.84|7.36| we have, of course, sorry, we have this lambda term. And then
745.2|6.48| also, if we have a summation over n, in our loss, we also
751.68|4.24| have a normalization here over n. So this is essentially it how
755.92|6.0| we how we compute that. So over n here is over the training
761.92|5.44| examples, right? Okay. So anything? Oh, yeah. So we have
767.36|4.6| also here an example of how we implement this in pytorch. So I
771.96|2.28| don't want to I have actually a code example, I will just
774.24|4.0| upload this and link this on canvas. But it's so simple that
778.8|3.12| I don't even need to show you this in a separate notebook, I
781.92|6.2| think. So how we can regularize the loss is by just summing over
788.24|4.08| the weights in the model. So if you initialize your model, you
792.32|5.64| can then iterate over these model parameters. And notice we
797.96|6.68| only regularize the weights, not the bias units. So here, I'm
804.64|4.84| iterating over all the parameters in the model, I'm
809.48|3.52| using named parameters instead of just parameters. Notice this
813.0|2.8| is model dot parameters is something you would give into
815.8|3.04| the or provide to the optimizer. So you have seen that before.
818.84|3.44| Now we are using named parameters. Why are we doing
822.28|4.48| that, so that we can then say here, only choose the weights,
826.8|5.24| not the biases. And then here we add these to the loss. So let's
832.04|2.84| say we have the L two term here, we accumulate all of these just
834.88|5.92| the squared sums of these weights. So P is a weight. And
843.0|4.56| yeah, and then we add this to the loss here. So I'm calling it
847.56|3.72| I'm calling it cost, but you can also call it loss. So this one
851.28|3.36| is essentially what we have seen in the previous slide, lambda is
854.64|5.68| our regularization strength here. So this is essentially what I
860.32|6.52| was showing you here, except for all the weights, of course. And
866.84|2.76| this is something you would do during the training loop during
869.6|2.56| the for loop. So that would be one way you can do L two
872.16|4.0| regularization for neural networks in pytorch. But there's
876.16|3.6| even a simpler way. So what you can do is, instead of what I've
879.76|3.12| shown you in the previous slide, you can just choose this weight
882.92|3.0| decay argument here, or you can use this weight decay argument
885.92|3.96| in the other SGD optimizer. And you can just provide the lambda
889.88|3.84| regularization strength to the weight decay here, and it will
893.72|3.8| do L two regularization for you. So actually, you don't even have
897.52|3.16| to bother with this. I mean, this is optionally, if you like
900.68|3.56| to do it manually. But you can also just do it automatically by
904.24|3.24| specifying this here in the optimizer. And this is it. So
907.48|6.0| that's all you need to do for L two regularization in your
913.48|4.64| network training. Okay, so this was L two regularization in a
918.12|3.84| nutshell, I would say I recommend maybe trying this out
921.96|4.8| in practice. But I must say it's not super common anymore. What's
926.76|4.08| more common is using dropout, which we will be discussing in
930.84|4.04| in the remaining parts of this lecture. Actually, I originally
934.88|3.22| planned to only make one video. But then I think it might be a
938.1|3.3| super long video. So I'm splitting it into four shorter
941.4|3.76| parts. So let's get started then and finish up this lecture on
945.16|16.64| regularization by talking about dropout.