start_time|end_time|text
0.84|3.84| All right, before we talk more about recurrent neural networks,
4.84|4.48| let me go over some other ways we can use for working with text
9.32|2.48| data, because I think that might be just useful for you just to
11.8|3.4| have a big picture overview of different methods that exist for
15.2|5.44| working with text. So here, that's the classic approach for
20.64|5.04| text classification. It's the so called back of words model. And
25.68|2.96| in this class, we won't be talking about this in detail. I
28.64|2.68| just thought it might be useful to have an overview slide here.
31.68|3.44| So it could also be useful if you work on your class projects
35.12|2.48| and your class project is centered around a text
37.6|5.0| classification task, and you're planning to use deep learning
42.76|3.36| using such a back of words model might actually be helpful as a
46.12|4.68| baseline model. So if you are interested in that, that type of
50.8|3.8| model, in chapter eight of our Python machine learning book, we
54.6|3.92| have a chapter on how this works. And also have a code
58.52|3.88| example notebook here on training such a back of words
62.4|3.4| model using a logistic regression classifier. So the
65.8|10.72| big picture here really is that we are converting text to a
76.52|8.6| tabular data set. So the downside of this approach is that it
85.12|4.8| gets rid of the sequence relationship in a text between
89.92|3.48| words. So this is more like a naive or simple approach to text
93.4|4.92| classification. So how does it work? So let's look at this. So
98.32|3.0| on the left hand side, what I was writing down here is a raw
101.4|4.44| training data set. So just an example data set here consisting
105.84|4.44| of three training examples. So x one x two and x three, these are
110.28|3.4| three training examples. And the first training example is a text,
113.68|3.4| for example, the sun is shining. The second training example is
117.08|4.88| a text, the weather is sweet. And the third one is text saying
121.96|2.72| the sun is shining, the weather is sweet, and one and one is
124.68|3.96| two. So I just made this up. But this is like an example of a
128.64|3.84| text data set. And for that, we also have, let's say
132.48|3.56| corresponding class labels, the class labels here are not important
136.04|3.28| except, of course, this is a classification problem. But here,
139.5|2.28| we are only focusing on the features in the back of words
141.78|3.18| model, the class labels are treated like in any other
144.96|5.72| classification example. So the first step using our raw data
150.68|5.6| set, the first step is to build the so called vocabulary. This
156.28|3.4| is also something we will be doing later when we work with
159.68|3.64| recurrent neural networks. So building the vocabulary means
163.48|4.04| looking at all the possible words in a data set. So we take
167.52|3.64| the whole training set, the entire training set, and look at
171.16|4.84| all the unique words, it's essentially a set of all the
176.0|4.2| unique words. And we give each word an index. So you can do
180.2|2.96| that alphabetically, but it doesn't really matter. So it's
183.16|3.04| just that you have like a dictionary here that maps from
186.2|6.04| word to some integer. That's your index, in which order you
192.32|2.36| do that, like I said, doesn't matter. It's just that you have
194.68|5.4| to keep this order. And that will be now your vocabulary. And
200.08|5.44| then what you do is you convert the raw text into a design
205.52|2.76| matrix. So this is our regular design matrix and machine
208.28|2.92| learning where we have n training examples and m
211.2|6.92| features. And notice now the m features here. That's actually
218.12|3.88| the length of our vocabulary. So in this case here, the
222.0|4.92| vocabulary consists of one up to nine, we have nine, but let's
227.08|6.04| use a different color here. m is nine, because we have m or nine
233.12|8.48| unique words. And we have these index positions 012345678. And
241.6|3.56| this is also corresponding to these index positions in this
245.16|5.2| design matrix. So here, in the first one, the me like here is
250.36|3.6| index position, zero, this is index position one, index
253.96|5.0| position two, and so forth, up to index position eight. And
258.96|7.08| here, this would be the first training example x one. And this
266.04|5.84| is really just a word count. Let's write this down. It's a
271.88|5.52| word count. I mean, sometimes people also call that term
277.44|9.16| frequency. And they're also normalized term frequencies. But
286.6|3.14| here, we are just considering the simplest case, just a word
289.74|4.34| count or the regular term frequency. And it is here just
294.08|4.36| counting how often each word appears in a text. So for
298.44|5.72| instance, the first index is zero, right? So yeah, so the
304.16|4.76| first index, let me use pink here, the first one corresponds
308.92|3.0| to and so is the we are checking essentially in this first
311.92|3.88| training example is that and in the sentence, no, so we put a
315.8|3.68| zero there, then the second one, the second index here, this
319.48|4.88| would be running out of colors, this would be corresponding to
324.36|4.24| is so is then is in my sentence? Yes, there is. So there's only
328.6|5.28| one. So I put a one here. And then we use maybe let me use
333.88|3.92| blue again. So for the third position here, this corresponds
337.8|4.8| to a one. So is the one in my sentence? No, there is no one.
342.6|2.68| So we put a zero and so forth. So we're just counting the
345.28|3.24| number of times each word occurs. And then we have the so
348.52|4.6| called design matrix. And this can be then used for training a
353.12|3.4| regular classifier, for example, logistic regression or multi
356.52|3.52| layer perceptrons. So we are here in the back of words model,
360.2|4.74| just converting text to a matrix to a training matrix or design
364.94|3.94| matrix. The only problem here, it's not a problem. It's just
368.88|2.82| like an assumption, we assume that the order of words is
371.7|7.58| independent. So because the order here, in this matrix of
379.28|3.28| the words, really is just determined by the integers in
382.56|3.78| the vocabulary. So in this way, there's no notion of grammar or
386.34|3.02| something like that. So there's no no relationship between the
389.36|4.12| sequence of words, which can be a downside, it's just a simple
393.48|2.84| type of model, it's not as sophisticated, because it's not
396.36|3.4| modeling sequence information, but it can still result in good
399.76|3.32| performance. So also in this book, for example, we were
403.36|3.76| working with the so called IMDb movie data set, I'm also planning
407.12|2.96| to make the last code example in this lecture about the IMDb movie
410.08|5.6| data set. So it's a movie data set consisting of movie reviews
415.68|5.24| of approximately 50,000 movie reviews. And they are either
421.4|6.2| ranked as positive or negative, like is a reviewer liking or not
427.6|4.84| liking the movie. And using a back of words model, I got
432.72|5.16| something around 83 84% accuracy. And using a recurrent
437.88|4.56| neural network, I also only got the same performance like 83 84
442.44|6.4| 85%. So that's because 50,000 is relatively small for machine
448.84|3.96| learning, deep learning context. So this is, I would say like the
452.8|4.56| borderline, where both machine learning and deep learning are
457.36|3.52| equally useful. If you go bigger, if you have a bigger
460.88|3.28| data set, then actually deep learning might outperform machine
464.16|2.6| learning. But if you have something around 50,000 or less
466.76|3.36| data points, using traditional machine learning, for example,
470.12|2.72| the spec of Merck's model may even give you a very good
472.84|5.84| performance. Yeah, another way to work with text data would be
478.68|3.16| to use a convolutional network, which was a big topic a couple
481.84|2.68| of weeks ago. But yeah, previously, we talked about
484.52|3.72| convolutional networks for image data. However, we can also use
488.24|3.08| convolutional networks for text data. So we have to use a
491.32|3.0| special case of convolutional layers, the one dimensional
494.32|3.4| convolutional layers, this is actually can also give good
497.72|4.12| results. But it is not as common as using, for example, recurrent
501.84|4.04| neural networks. When I looked at some papers, you can get kind
505.88|3.28| of the same performance of the data set is relatively small.
509.36|2.84| For bigger data sets are usually the recurrent neural networks
512.2|3.6| perform a little bit better than 1d convolutions. But it's again,
515.8|2.8| another approach, it really depends on the type of data set
518.6|1.88| you're working with. And that might be another thing to
520.48|4.76| consider. Here, just a big picture overview, how that works
525.44|4.66| is that you are sliding the kernel over the text as a
530.1|4.18| sequence rather than the image. So before, when we had an image,
534.44|6.64| we had our kernel that we were sliding from left to right, and
541.08|4.36| then we were moving down, then sliding it again, from left to
545.44|6.8| right, and so forth. So before, we had 2d convolution. Now we
552.24|2.56| have a one dimensional convolution, where essentially,
554.8|4.2| we have only, let's say, one long vector, you can think of it
559.0|6.24| like this, or also like this was drawing it vertically, for some
565.24|2.44| reason, but it also would apply like this, where we have this
567.68|4.84| kernel like here, and then just move to the right by one, let's
572.52|4.96| say one pixel, it's harder to see if I use one pixel, but we
577.48|2.56| are moving it essentially also to the right, but there's no
580.04|2.88| moving to the bottom, because it's just one sequence where
582.92|5.28| here, we can also move the kernel to the bottom. So for
588.2|4.14| that, here's another example, the sun is shining as my input
592.34|4.82| here. And we would convert this text also get to numbers. For
597.16|6.16| instance, we can consider each letter as a unique element in
603.32|2.9| our dictionary, we could also consider, of course, special
606.22|3.26| characters. So if we consider, let's say, the American
609.48|4.76| alphabet or something, we have 24 letters plus some punctuation
614.24|3.6| characters, and then we may map the t to let's say the position
617.84|5.0| 20, the age to eight. So we convert this input to numbers,
622.84|4.44| right? So 28, four, and so forth. And then we have our
627.28|6.36| kernel that computes the regular convolution. And then we get a
633.64|7.24| value here. So we have, let's say w one times 20, plus w two
641.2|6.88| times eight plus w three times four. And then we compute the
648.08|5.08| sum. And that's how we get this value here. And then in the next
653.16|2.4| layer, we would do the same thing, we would have again,
655.56|4.28| kernels sliding, let's say, from top to bottom. So this one would
660.68|4.44| here, and so forth. And this is how we could use a one
665.12|6.16| dimensional convolution network for working with text data. The
671.28|4.08| maybe more modern way right now to work with text data is using
675.36|5.2| so called transformers. So we will talk about transformers
680.6|4.84| later in this lecture, or sorry, later in this class, because I
685.44|2.68| want to talk about recurrent neural networks first. So
688.12|4.4| recurrent neural networks are pretty useful and powerful. And
692.52|3.96| at some point, and I think it was 2014, people added a so
696.48|3.68| called attention mechanism to recurrent neural networks. And
700.16|3.92| then later in 2017, people did experiments when they said,
704.08|3.8| okay, let's maybe only use that attention mechanism and get rid
707.88|2.36| of the RNN. And they found actually that performs even
710.24|2.84| better. And this gave rise to the so called transformer
713.08|5.76| models. So when I mentioned that back of words models work well
719.04|4.36| with small data sets, recurrent neural networks require larger
723.4|3.6| data sets, and transformers require even larger data sets.
727.0|2.52| So usually, when people use transformer models, they use
729.52|4.8| billions of sentences as input. And that is like a huge, it's
734.32|3.32| usually when you look at the recent papers, they train on
737.64|4.72| hundreds of 1000s of GPUs, and it takes weeks. And if you have
742.36|2.88| watched some of the stuff in the news videos, we also talked
745.24|4.8| briefly about how much it costs, it's like, between 20,000 to
750.36|2.96| couple of million dollars just to train the model. So in this
753.32|3.0| way, this is usually something only big companies really are
756.32|4.44| capable of right now. And of course, you need a large data.
760.88|3.12| And if you have or consider large data sets, one problem is
764.04|3.36| where did you where do you get the labels from? So usually
767.4|4.28| transformers come hand in hand with self supervised learning,
771.96|5.0| which is a concept of leveraging the input data to generate
777.0|4.68| labels for supervised learning. So in a text context, for
781.68|3.72| example, there's the so called BERT model, there are two self
785.4|6.12| supervised tasks. So one is that they are masking 15% of the
791.52|3.36| words and then are predicting them. So if you have a given
794.88|4.08| sentence that looks like this, what they do is randomly 15% of
798.96|3.16| them words are masked, for example, let's say they mask the
802.16|3.4| Fox in a given iteration, and then they train the network to
805.56|3.36| predict what word would go into here. So they the BERT model
808.92|2.76| then predicts different words. And there's, of course, a
811.68|4.64| vocabulary of hundreds of 1000s or millions of different words.
816.6|3.24| And ideally, it should give the highest probability to the one
820.2|5.44| that was removed. So here, they kind of leverage the training
825.64|3.52| data inputs to generate labels. So the generated label is here
829.16|2.68| just by removing a word and then predicting it back into the
831.84|4.36| text. And when I recall correctly, in the specific case
836.2|3.56| of BERT, they also have a second self supervised task where they
839.76|5.52| arm, take a document, and they take two sentences out of this
845.28|2.72| document. And then they have a second document where they take
848.0|4.28| one sentence from. So let's say, let me maybe show this visually.
852.36|2.84| So they have one sentence and another sentence. And they have
855.2|5.12| a second document. Let me use yellow here, maybe. And they have
860.32|3.76| a second document. And they take also a sentence. And they give
864.28|3.68| the screen sentence to the model. And then they should the
867.96|4.68| prediction is whether this purple or the yellow sentence
872.64|3.06| comes from the same document. So the it's a binary classification
875.7|3.9| task where the model has to find the correct pair of sentences
879.6|4.36| that are coming from the same text. So should be sentences
883.96|3.72| that come right after each other hopes. So see that should be
887.68|3.68| like this. So they are the model tries to connect or find a pair
891.36|3.6| of sentences that comes from the same document. And this is also
894.96|3.12| a task that you can just where you can generate your data
898.08|3.44| yourself, because you can use unlabeled data to generate this
901.52|3.78| labeling information. But yeah, we will be talking about
905.3|3.88| transformers more in a separate lecture later in the semester.
909.44|4.24| Because yeah, the transformers are kind of inspired by RNNs,
913.92|3.96| where people added attention to RNNs. And then they removed the
917.88|4.8| RNN component and landed on the transformer model without RNNs.
922.68|4.16| And like I said, it's a more, I would say complicated or bigger
927.04|3.4| effort to train transformers. So this is something we will
930.6|3.76| consider doing later and not right now. So right now, working
934.36|4.2| with RNNs. And usually, to be honest, RNNs for most tasks in
938.56|3.12| practice are still, I would say the most relevant models,
941.68|3.8| because who can afford to train transformer models. So this is
945.48|4.08| actually not too bad to know about RNNs. Alright, so in the
949.56|4.32| next video, I will then now finally talk about RNNs now that
953.88|26.64| you have seen different other ways to work with text data.