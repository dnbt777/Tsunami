start_time|end_time|text
0.64|3.32| So in this video, we are going to talk about something called
3.96|4.08| long, short term memory LSTM, which is for modeling long range
8.04|3.32| dependencies. And the LSTM cell, you can think of it as a
11.36|4.4| modified version of a recurrent neural network. So that is
16.08|3.4| particularly helpful for working with longer sequences and really
19.68|3.04| kind of essential to get good performance out of a recurrent
22.72|5.2| neural network. So previously, we talked about other solutions
27.92|3.68| to vanishing and gradient vanishing and exploding gradient
31.6|3.96| problems. So long time ago, we when we talked about multi layer
35.56|4.08| perceptrons, we talked about using the relu function instead
39.64|3.8| of sigmoid functions, like the 10 h or the logistic sigmoid,
43.8|4.84| because it can help with mitigating or vanishing gradient
48.64|4.72| problems. So, but even then, even if we use a relu function
53.36|4.52| itself, sigmoid or 10 h, we may find that making a multi layer
57.88|4.12| perceptron deeper than one or two layers doesn't really work in
62.0|2.52| practice. So if you've tried in the homework to have a multi
64.52|3.2| layer perceptron, like with four or five layers, it still didn't
67.72|4.32| work very well. And yeah, that is still because there might be
72.04|3.52| problems with the vanishing gradients. So another technique
75.56|3.72| that can help a little bit with that is batch normalization. So
79.28|2.76| if you have batch normalization, you may find that you can have
82.04|3.6| no multi layer perceptron with maybe three, maybe, maybe even
85.64|4.4| four layers, but it's still it's not great. In the context of
90.04|3.28| convolutional networks, because they are simpler, we found that
93.32|3.36| having more layers might work. So we had the VGG 16 network
96.68|4.52| with 16 layers. But then going beyond 16 layers, even if we
101.2|3.84| have batch norm, again, doesn't really help. So we have to we
105.04|4.2| had to add another trick called skip connections. And they are
109.24|3.08| these skip connections and residual networks helped then
112.32|4.48| with constructing networks more than 3050 or 100 layers. So
116.8|3.92| there are multiple tricks that we can use to help with the
120.72|3.4| backpropagation when we might have vanishing or exporting
124.12|4.92| gradient problems. So but this was usually for the number of
129.04|3.88| layers. Now in this recurrent new network setup, we also have
132.92|4.92| to consider the time steps, right? So on the previous hidden
137.84|4.56| states, so because you're like we've seen in the previous
142.4|2.8| video, there's this product that we compute, there might be
145.2|2.68| another level of encountering vanishing and exporting gradient
147.88|3.36| problems. So there are here three different techniques for
151.24|3.12| dealing with these issues. So one is the simplest one is a
154.36|4.76| gradient clipping. So that is actually a quite widely used
159.16|4.24| technique also in other contexts. So this is essentially
163.4|4.36| I'm setting a maximum or minimum cutoff value for the gradient.
167.76|2.96| So for instance, we can say, never have gradients greater
170.72|3.12| than, let's say two or smaller than two, minus two, and things
173.84|4.04| like that. So we can cut manually the gradient, so that
177.88|3.2| we don't have very extreme updates. Another one is called
181.28|4.16| truncated backpropagation through time. And this is just a
185.44|2.56| simple technique for limiting the number of time steps during
188.0|4.48| backpropagation. So you when you have long sequence, let's say
192.48|5.2| you have a very long sequence, and these all go to the hidden
201.72|3.68| hidden layer, and then to the output layer and so forth. So
205.76|6.0| for forward propagation, you may use the whole sequence here. So
211.8|4.12| but then when you back propagate for the hidden layers, you only
215.92|3.8| maybe back propagate through the last 20 time steps or so. So you
219.72|3.6| don't back propagate through the whole sequence. This is called
223.56|2.92| truncated back propagation through time, and it might work
226.48|3.8| pretty well. However, an even better way for working with
230.28|3.32| longer sequences is the so called long shorter memory,
233.92|3.44| which uses a memory cell for modeling, yeah, long range
237.36|2.82| dependencies to avoid vanishing gradient problems. And this goes
240.18|4.62| back to a paper from 1997, which was pretty influential
244.84|3.36| proposing this type of memory cell. There has been another
248.2|3.16| one called JIRA, you will just mention it again, maybe at the
251.36|3.92| end of the video, which is a simplified version of that
255.28|4.36| slightly simpler. But the LSTM is still widely used in both
260.0|3.76| LSTM and JIRA, you are approximately perform
263.84|3.08| approximately similarly. Well, there are sometimes problems
266.92|3.66| where LSTMs perform better, sometimes where JIRA use perform
270.58|3.46| better. So none of the two is universally always better than
274.04|2.52| the other. It's just like another, let's say hyper
276.56|3.48| parameter to investigate whether we should use LSTM or JIRA use
280.04|4.2| cells. But nonetheless, LSTM cells, I think are still more
284.24|3.92| popular than JIRA use cells and the most widely used on RNN
288.28|2.76| memory cells, I would say. And in this video, we are going to
291.04|5.64| talk about these LSTM cells. And then also, yeah, later, we will
296.68|3.44| also implement this in code using pytorch. So what I'm
300.12|3.92| going to show you in this video may look super complicated. If
304.04|3.4| you don't understand it fully, don't worry about it too much. I
307.44|3.38| mean, here, we are really in this class in general, also for
310.82|3.18| this RNN lecture, just trying to get a big picture overview. This
314.0|4.4| is still an introductory class. So most people find these LSTM
318.4|2.68| cells very complicated. So if you don't understand it, like
321.08|3.92| fully, don't worry about it too much. If you want to learn about
325.0|3.16| it more, yeah, you would have to probably spend more time reading
328.16|3.8| these papers and maybe trying to implement it from scratch by
331.96|4.4| yourself. So that might be probably taking multiple weeks or
336.36|3.4| months to really get a good feeling for how that works. So
340.0|3.36| you can't expect really like from an overview, you have to be
343.36|3.52| an expert immediately. So I'm trying to say, when you see the
346.88|2.76| next couple of slides, don't freak out, it looks more
349.64|5.14| complicated than it might really be. But also, if you don't fully
354.78|2.58| understand it, it's not your fault. It's a complicated topic.
357.36|3.96| So here is how the LSTM cell looks like. So there are many,
361.32|4.16| many things going on. And in the next couple of slides, I will
365.72|5.4| walk through this now step by step. So where is this before I
371.12|3.88| explain all these letters and notations? Where's this LSTM
375.0|4.8| cell located? So you would actually put this LSTM cell here
380.64|4.68| in the center. So you would have one, I mean, you would use it
385.32|2.72| for different time steps. But if we would focus, let's say on
388.04|4.24| this time step here, you would put it into the center here for
393.08|3.88| instead of having the regular hidden state or hidden layer,
397.08|6.0| you would insert this LSTM here. And if you have a multi layer,
403.28|3.48| RNN, like that one, you would also have, or you can have
407.24|3.32| multiple LSTM cells, for instance, you could have two
410.56|7.96| LSTM cells. So how again, this connects, so let me erase this.
418.72|5.48| So in blue here, this is here, the hidden state from the
424.2|4.24| previous time step. So if you consider this one, this is here
428.44|6.44| this input. So if we think of this whole thing, as this red
434.88|4.04| box here, on the left, lower side, this blue is resembling
438.92|2.96| the input from the previous state state, then there's
441.88|3.44| something new we have, that's the cell state, I will explain
445.32|4.04| it in the next couple of slides. So there's a cell state. And
449.36|5.52| then here, this green one, I should have produced for the
454.88|6.04| cell state, something else that's black cell state. And
460.92|5.2| then here in green, that oops, see, I will have explanations.
466.12|4.24| So yeah, so here, this in green one, this will be the output to
470.36|5.56| the next time step. And then here in pink, or purple will be
476.16|3.16| the output to the next hidden layer. So you can see, this red
479.32|4.08| one really would fit here into this RNN. So instead of having
483.4|4.32| just a regular hidden layer, we would now have this, yeah, LSTM
488.04|5.84| memory cell. So yeah, going through things step by step, we
493.88|4.32| have this cell state at a previous time step. And then we
498.2|3.56| update here in this whole computation, the cell state and
501.76|3.68| pass it on to the next time step. So there's this so called
505.52|8.04| state of the LSTM. And another thing we have is, like I said
513.56|3.88| before, we have the activation from the previous time step. So
517.48|2.68| the hidden state from the previous step step, and we will
520.16|6.44| pass on the activation computed from this memory cell to the
526.6|7.04| next time step. Then here for the mainly for the memory for
533.64|6.16| the cell state, we have two different operations. So we have
540.24|2.68| here the element wise multiplication here, we have an
542.92|4.72| addition. And these sigmas here, they represent our logistic
547.64|8.24| sigmoid activation functions. Now here, we have so there are
555.88|5.0| three different gates. So talking now about the gates. So
561.56|4.36| we have this forget gate here. So it controls essentially which
565.92|2.92| information is remembered and which one is forgotten, and it
568.84|6.56| can reset the cell state. So here, we receive the input at
575.4|3.16| the current time step, and we receive the input from the
578.56|3.16| previous hidden state like in a regular RNN layer. And then it
581.72|5.52| goes through some computation here. And this one, this
587.24|4.0| computation is essentially an evolve involving two matrices
591.24|5.2| like we had before. So we have before we had this matrix H, H,
597.12|6.12| right, and w, h x, here, we are calling it for forget gate
603.24|7.76| instead of h h, let's call it f h and f x. And then we have
611.0|4.76| also bias unit BF. So I just see I would actually here. And this
615.76|4.4| goes through a sigmoid unit. And you know that in a sigmoid, the
620.16|4.0| output can be either or is between zero and one. So if the
624.2|4.68| output is zero, for instance, and there's a multiplication
628.88|4.92| here, element mice multiplication, we can essentially erase
633.84|3.96| the previous cell state. So here, at this time step, the
637.8|5.44| network has the option to forget the cell state. So in terms of
643.24|3.86| not doing anything from the previous arm, so not including
647.1|3.14| any information from the previous time step, or it could
650.24|2.74| learn a one, so it could fully use information from the
652.98|4.5| previous time step. So this is the so called forget gate, so
657.48|2.32| which it's controlling which information is remembered and
659.8|3.76| which is forgotten. So it can zero out the previous cell
663.56|8.12| state. So then there is this input gate. So here, the forget
671.68|5.16| gate again, is potentially erasing information. And here in
676.84|4.36| the input gate, we are adding no information. So there are
681.2|4.96| actually two things going on. There's a sigmoid and a 10 h
686.16|4.68| here. There's an input node and an input gate, and they get
690.88|6.6| element wise multiplied. And so this one can be zero or one. And
697.48|5.12| this one can be between minus one and one. And the output then
702.6|3.78| can essentially also be between zero and between minus one and
706.38|7.58| one. And on this gets added to the previous cell state, which
713.96|5.14| might be erased through the forget gate or kept. And each of
719.1|3.46| those, they are really, yeah, just computed like in a regular
722.92|5.46| neural network where we have. So here, we have a plus, of
728.38|5.7| course, so here, we have w times x. And here, we have this one,
734.12|7.92| actually, I know that that should think it's correct.
742.04|5.64| Sorry. Okay. Um, yeah, okay. So this is our setup here. So
747.68|3.4| that's how we compute this. And then the same thing for the
751.08|3.8| input gate, we have logistic sigmoid instead of a 10 h now.
755.42|3.02| And these are the values we compute, we multiply them and
758.44|4.88| then add them to the cell state. And yeah, this information comes
763.32|4.28| also, of course, from the previous cell state and the input
767.6|5.28| here. Now, just looking at everything together, how we
772.88|5.88| compute the output cell state for the next time step. So
778.76|3.8| again, just to summarize, we multiply the previous cell state
782.6|6.16| by this forget gate, then we add the product of the input node
788.76|5.96| and the input gate. And then we also have a third gate, that's
794.72|3.54| the output gate, that's for updating the values of the
798.26|4.46| hidden units. So here, before what we had is this just for the
802.72|4.12| cell state. But now the cell state here also goes through a
806.84|5.56| 10 h and then gets multiplied. So this can begin between minus
812.4|4.04| one, one. And this gets multiplied with this output
816.44|3.0| gate here. So the output gate itself is also computed like the
819.44|10.24| previous ones. And the product of this 10 h output and this
829.68|4.34| output gate goes then to the next time step on then also to
834.02|3.54| the next layer in the neural network. So with that, I mean,
837.56|12.2| if I go back to it goes, goes here. Well, yeah, okay. So it
849.76|4.44| goes either here and here if we talk about this red one. So this
854.2|3.4| would be to the next layer here. And this one would be to the
857.6|6.56| next hidden state. Forwarding in. Alright, so this is what we
864.16|6.12| had. So that's the output gate. And yeah, here is how the next
870.28|5.28| hidden state is computed. That's what I just mentioned the output
875.56|3.84| gate times the 10 h or the cell state. And yeah, this is
879.44|4.36| essentially it. And it's a pretty complicated setup. It's
883.96|3.4| kind of some justification behind it. So that's embedded in
887.36|3.12| the original paper, if you're interested in reading about
890.48|5.48| that. So in practice, if I mean, this sounds very obscure, I
895.96|3.4| think, I mean, it works well in practice. So that's probably
899.36|4.04| why it stood the test of time why people use it. And yeah,
903.4|3.2| like I said, it's so widely used and popular. But there's also a
906.6|4.2| version where people try to simplify it a little bit. So
910.82|5.26| there's this gated recurrent unit, which is, I mean, it's
916.08|5.56| not that recent. It's also already nine, eight. Sorry,
921.72|4.32| seven years old. So it's not that new anymore, not that
926.04|4.44| recent anymore. But it's also popular implementation of
930.48|2.24| something similar, that is a little bit simpler. It has a
932.72|5.36| few, it has fewer parameters. And in practice, they are both,
938.12|2.5| like I mentioned before, may work well in practice, because
940.62|3.06| of your time reasons, we're not going to cover the gated
943.68|3.68| recurrent unit. It's also not, I would say, super interesting in
947.36|2.36| that way, just to talk about it in the same way we talked about
949.72|3.84| it before. So it's just a snapshot of it. And if you're
953.56|4.36| interested, there's a nice article exploring both LSTM and
957.92|5.28| comparing them to gira use if you would like to read more
963.2|3.38| about these types of architectures and get a feeling
966.58|3.7| when they work well and looking at some applications of those.
970.68|2.98| Alright, so again, here in this lecture, we are just trying to
973.66|3.94| get a big picture of how recurrent networks work. There
977.6|3.2| are many other topics we wanted to cover. So we are not going
980.8|3.48| into too much detail about this particular architecture. If
984.32|3.36| you're interested, I will post some more reading resources on
987.68|6.4| Piazza on canvas. So in the next video, I will then talk about
995.12|7.8| many to one RNNs on a word level for implementing a classifier.
1002.92|5.44| So that will be our example. And then later in a later week, in
1008.36|3.48| two weeks, approximately, we will be revisiting also
1011.88|4.04| recurrent new networks for many too many tasks for generating
1015.92|21.0| new text.