start_time|end_time|text
1.4|3.16| All right, let's take a look at another code example. Now a more
4.56|4.12| interesting one, focusing on face images instead of handwritten
8.68|3.04| digits. So we are going to work with a set up a data set.
12.14|3.18| Mainly, also, the auto encoder will be a little bit bigger. So
15.32|3.04| the variation of encoder is now based on this paper here, we
18.36|2.44| have three color channels, and we have a much bigger latent
21.36|3.44| representation 200 instead of two dimensions. That's just
24.8|3.56| because also the data is more complex than just ms digits, we
28.36|3.32| also have colors and other things. face images are more
31.68|4.06| difficult than one more complex than handwritten digits. And
35.74|3.34| then this also includes batch norm and dropout to get better
39.08|5.32| performance. Alright, so he has the code notebook, the second
44.4|4.24| code notebook notebook, I will share. And we don't need that.
48.88|4.6| And now we are using the setup a data set, which is also part of
53.48|7.16| torch vision. So can find it here, actually. So setup a is a
60.64|6.32| large scale face image data set 202,000 face images, five
67.0|5.36| landmark locations and 40 binary attributes. Here are some
72.36|5.08| examples. So they were scraped from I think, Google, like from
77.44|4.16| the web, usually, most of them are celebrities, and they are
81.6|4.32| available on Google Drive or Baidu Drive. Dropbox usually
85.92|3.64| doesn't work because it's limited, like there's a
89.56|3.2| download limit. And usually, every time I try to download
92.76|2.68| this data set, this download limit is reached. So I think
95.44|4.48| they even don't allow it anymore. Okay, here, here,
99.92|3.36| actually, these are the Dropbox links, but probably want to use
103.28|9.12| the Google Drive or Baidu Drive. Okay. So here, again, starting
112.4|3.56| with the boilerplate, like we had in the regular autoencoder.
116.8|5.04| One thing that is new is we are now center cropping. So that you
121.84|3.4| will see later, it's only focusing on on the center of the
125.24|5.4| face. I think I forgot actually, original dimensions, I think it
130.64|3.44| might be 200, times 240, or something like that. So but we
134.08|4.72| are cropping that it's only the face, not the background. I try
138.8|4.56| to normalize it to minus one run range, and then use the 10h. But
143.4|3.56| I didn't notice any improvement, rather the opposite. So I kind
146.96|3.84| of deactivated this again. So the pixels will be in the 01
150.8|4.92| range, just like before, for MNIST. Yeah, just testing the
155.72|4.36| data loader. Notice, yeah, just copy pasted from the right
160.08|5.04| from the readme file, the different attributes, the 40
165.12|3.32| binary attributes that they list. So we can later do some
168.48|4.88| experience with those. So they have different attributes as
173.36|4.52| labels, we are going to work with a smiling one later. But
177.88|3.6| you're just for reference. So here in this notebook, though,
181.48|3.36| we're not using those because yeah, auto encoders are
184.88|3.08| unsupervised models, unless we talk about conditional auto
187.96|5.96| encoders, but they are not part of this lecture. Okay, so here's
193.92|2.84| my implementation. It's fundamentally very similar to
196.76|4.72| what I showed you for the MNIST. So differences that we also have
201.48|6.12| no batch norm and robot. And our latent representation is 200
207.6|6.24| dimensional. But except that it's the same concept. So I have
213.84|2.64| actually kept everything the same. So I don't have to explain
216.48|5.32| this again. So this is all the same as before. The interesting
221.8|2.76| part is really that it's just a different data set. I actually
224.56|2.24| saving this model this time, because I want to do some
226.84|9.16| analysis with that later. So it's training. Training for a
236.0|4.6| long time, it took almost one and a half hours on a GPU. Yeah,
240.6|5.28| it's a large data set. Okay, so we can see the losses, maybe
245.88|2.6| training further could have helped a little bit, but it
248.48|6.92| looks quite converged. Yeah, and then here, I actually had an
255.42|5.82| unnormalizer for basically bringing the images back to 01
261.28|4.72| range, because the matplotplip function doesn't like it, the
266.0|3.56| imp show if the values are negative, so it looked somewhat
269.56|4.4| weird. But since I'm not normalizing, I don't need that I
273.96|3.28| haven't commented this out. So you can actually ignore all of
277.24|3.92| that. The pixels will be in 01 range. So here in the top row,
281.32|2.96| these are the original images. And at the bottom are the
284.28|5.12| reconstructed ones, you can see they of course not as sharp as
289.4|4.44| the original ones, but it looks quite okay. I mean, given that
293.84|5.88| this is like a basic model, it kind of reconstructs these face
299.72|4.76| images. In the next lecture, we will work with GANs, which give
304.48|5.2| us a little bit better results, by the way. Okay, so this is
309.68|3.68| really reconstructed just to check that the auto encoder is
313.36|4.0| learning how to reconstruct images. Now, let's take a look
317.36|4.32| at the sampled images. So here are images that I sampled from
321.68|2.4| a random normal distribution. So again, this is the same
324.08|3.44| function that we took a look at before, when we talked about the
327.52|9.68| MNIST one. So let me just open this again. This is this plot
337.2|4.12| images sample from VAE. So I'm here, I'm just really sampling
341.32|3.44| from a random distribution. And then these are the reconstructed
344.76|3.28| ones. And these are all face images that are not from real
348.04|3.32| people, they are just randomly generated. You can see some of
351.36|3.76| them look reasonable. So this person looks like reasonable.
355.12|3.44| This person, some like this one doesn't really look like a face
358.56|4.92| image. This one, maybe not hard to tell. So some look better.
363.48|3.04| This looks maybe not so good. And this doesn't look so good.
366.76|4.92| But many of them look quite okay. Yeah, it took me quite
371.68|2.32| some time to put the code together. So I could probably get
374.0|3.24| better results, but it would take me a couple of days. So
377.28|3.56| very laborious task to do the tuning. And every time you have
380.84|4.48| to wait one and a half hours. Anyways, so I actually also
385.32|3.2| tried using nearest neighbor upsampling instead of the
388.52|6.16| transpose convolutions that's shown here. So here I have the
394.68|5.72| upsampling followed by convolution layer, compared to
401.92|3.88| scroll up again, compared to just a transpose convolution.
405.8|3.44| Let's see the results. Personally, I don't think the
409.24|3.0| results are better or worse. I think they look pretty much the
412.24|4.24| same. So because there was a question whether in on Piazza,
416.48|4.56| whether the upsampling that we discussed in the lecture is
421.04|4.04| better than the transpose convolution, it's hard to tell,
425.08|3.4| to be honest. So I mean, they are of course, different face
428.48|3.2| images, but I wouldn't say the quality of one is better than
431.68|4.32| the other. It's pretty much the same. So back to the point, it
436.0|2.16| doesn't really matter in practice, whether I use the
438.16|2.6| transpose convolution, or upsampling followed by
440.76|5.56| convolution. In the article I linked, they recommend upsampling
446.32|2.28| because of these checkerboard patterns. But yeah, if you're
448.6|2.76| careful, like here, I don't see any checkerboard patterns. So I
451.36|3.08| wouldn't worry about it. Unless you see them, then you can
454.44|6.0| always switch to upsampling or fix the kernel sizes. All right,
460.44|5.8| so this is yeah, the variation auto encoder for face images, I
466.24|4.52| did some follow up analysis here, just taking a look at
470.76|4.4| whether the latent space is now indeed, or is following a normal
475.16|3.44| distribution. Since it's now 200 dimensional and not two
478.6|3.76| dimensional, we can't simply do a scatterplot. But what I did is
482.36|4.24| a histogram. So here, this notebook, I'm just having the
486.6|3.96| regular setup, I just copy pasted it from the previous one.
490.56|3.52| This is my model. And remember, I saved the model. So this is
494.08|6.16| just copy and paste it. So if I go here to my training, I just
500.24|6.36| copy and pasted everything from here to here, then initialize
506.6|4.24| the model. But now, instead of training it, I'm just loading
510.84|2.8| it, I could have done it at the end of this notebook here, but
513.64|2.12| it was already so much information that I made a
515.76|4.84| separate notebook. Yeah, and now I'm just taking a look at the
520.6|5.36| latent dimensions. So this is just like an laborious task
525.96|3.12| where I'm, this is why I have this separate encoding function.
529.24|3.96| So I'm encoding all the images. But instead of doing it for all,
533.2|3.56| I only do it for 10,000, because I noticed otherwise, it would
536.8|3.6| just take too long. So I'm only doing it for 10,000. For the
540.4|3.28| first 10,000 images, I am encoding them into the
543.68|6.12| embeddings. And then I am plotting the histograms for each
549.8|7.92| dimension. So in fact, I'm only focusing on the first 25
557.72|3.56| dimensions, because also, it's just to because it took too long
561.28|3.96| if I took all images and all 200 dimensions would be large plot.
565.4|3.68| So I'm only showing the first 25 dimensions here of the latent
569.08|5.28| space. And you can see based on histograms, they look in each
574.36|4.32| dimension like as if it is standard normal, just, I mean,
578.68|6.24| quite normal, centered at zero and roughly variance one. Okay,
584.92|5.92| so this was showing you how we can train auto encoder on the
590.84|3.12| celeb a images. In the next video, I will show you
593.96|4.88| something interesting how we can do latent space arithmetic. So
598.84|4.16| instead of just generating images, I will show you how we
603.0|26.28| can manipulate images.