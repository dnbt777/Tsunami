start_time|end_time|text
0.72|2.54| Yes, in the previous video, we talked about adding this
3.26|4.06| momentum term, which is essentially a velocity term that
7.32|4.36| helps dampening the oscillations in stochastic gradient descent.
12.0|4.04| But it also can help with overcoming like flat regions on
16.04|3.16| the loss surface, for instance, on saddle points or local
19.2|3.92| minima. So in addition to this momentum term, we learn now
23.12|4.16| about a slightly related also, slightly different concept
27.28|3.48| called adaptive learning rates. So adaptive learning rates are
30.76|5.4| essentially about accelerating and accelerating the learning
36.16|4.16| rate at the right moment. So speeding the learning up when we
40.32|2.4| are going into the right direction and slowing it down
42.88|4.16| when we change directions. And then we will see how we can
47.04|3.92| combine this with momentum learning. And the combination of
50.96|3.04| both there's an algorithm that does that it's called Adam. So
54.0|2.12| Adam is essentially a combination of adaptive
56.12|4.88| learning and momentum learning. Yeah, there are many different
61.0|3.8| flavors of adaptive learning rates out there. And discussing
64.8|2.48| them all would be a little bit of out of the scope of this
67.28|3.88| course. However, um, yeah, just to go over the main concepts, I
71.16|3.24| will show you a simple example. And yeah, the key takeaway, like
74.4|3.28| I said in the previous slide is that we decrease the learning
77.68|3.68| rate of the gradient changes the direction, and we increase the
81.36|3.52| learning rate if the gradient stays consistent. So for
84.88|4.96| instance, if we do these updates, and they are all going
89.84|3.24| to the same, roughly same direction, then we accelerate
93.08|4.44| because yeah, in this way, it's probably likely the correct
97.56|3.6| direction. So in that way, we can just speed it up and
101.2|4.8| converge faster. However, if we have something where we change
106.0|3.04| the direction, for example, so let's say we have an update like
109.04|3.68| that, and there's another change, then it will slow down
112.72|3.52| the update, so that it is, if it's a wrong direction, there's
116.24|3.48| maybe some noise, so that it is not heading too much into this
119.72|3.2| wrong direction, for example. So if there every time there's a
122.96|3.64| change in direction, it will essentially slow down.
129.56|3.12| Yeah, so how does it work? How can we use an adaptive learning
132.68|4.36| rate? There are essentially two main steps for doing that. So
137.08|4.68| step one would be initializing a so called local gain for each
141.76|6.0| weight. And if you look at this, here, when we compute the delta
147.96|6.92| w ij term, and if you only if you remove this one, this would
155.08|3.64| essentially look like the regular delta term that we
158.72|4.44| compute. So this is essentially our gradient of the loss with
163.16|2.68| respect to that weight that we want to update times the
165.84|6.12| learning rate. So this is the learning rate. But the difference
171.96|6.24| now is that we add this gain and this gain, as you can see is
178.2|4.96| also index ij. So it's the gain associated with that particular
183.16|3.64| weight. And in that way, you can think of this one as a learning
186.8|3.04| rate just for this particular weight. So you can have unique
189.88|2.9| learning rates for different weights or different directions
192.78|7.74| in that way. So now after initializing this local gain, we
200.52|2.8| have a second step. So this is what we then do during learning,
203.52|4.6| we are modifying this gain. So similar to modifying the weights,
208.4|3.6| we modify this gain. So we either increase it if it's
212.0|4.4| consistent, or otherwise if it's inconsistent. So if we change
216.4|4.4| the direction, then we decrease or Yeah, we Yeah, we change the
220.8|5.9| dampen the gain essentially. So like I'm saying here, multiplying
226.7|4.18| by a factor has a larger impact if the gains are large, compared
230.88|5.32| to adding a term and addition to in contrast to this addition.
236.76|5.84| And that means, um, so how this is set up, it means that if we
242.6|3.2| are going into the right direction, we are slowly
245.8|4.68| accelerating. So, so this is if we are consistent, and we are
250.48|5.88| adding this beta term, and we make it bigger by a small value
256.36|3.84| here by beta, let's say, beta is point nine, we increase it by
260.2|7.72| point nine in each round, essentially. But if we change
267.92|5.36| the direction, we slow down faster by multiplying by this
273.28|3.12| term here, for instance. So here, for instance, we would
276.4|3.84| multiply a beta is point nine, we will multiply this by point
280.24|4.8| one. And this can have a stronger dampening effect when
285.04|3.92| we change the directions. This is kind of intuitive, because
288.96|6.4| yeah, if we let's say, drive a car, and we see the road is
295.88|3.56| clear ahead, we start to accelerate, but we don't go
299.44|3.52| crazy and stomp on the gas, we start accelerating in a
302.96|4.44| reasonable manner. And let's say we want to make a turn or
307.4|2.7| something like that, or we are in the turn. Usually, we
310.1|3.96| accelerate a lot before a turn, we don't slowly accelerate in
314.06|2.94| most cases, at least I mean, if it's a very sudden turn, if we
317.0|3.08| have to avoid an obstacle or something like that, we have to
320.24|4.2| push the brakes pretty hard to turn left or right to avoid the
324.44|0.6| obstacle.
326.92|3.64| Alright, so there is a particular implementation of an
330.56|3.52| adaptive learning rate that was very popular for, yeah, for a
334.08|5.72| time. It is called RMS prop. And I think it's from a course
339.8|3.68| Geoff Hinton taught, you can find references to that on the
343.48|3.44| internet. But there is no official paper of that or
346.92|4.56| corresponding to that. It's something Geoff Hinton was one
351.48|3.34| of the persons popularizing and working on your networks
354.82|7.6| throughout the last 60 or so years, 50 years. Yeah, it has
362.42|2.76| been mentioned in one of his talks, and people started using
365.18|3.4| that and performed pretty well. It's essentially a modification
368.58|6.44| of our prop, which was published in 2000 around 2000. And yeah,
375.02|3.56| it's also relatively similar to another concept called delta.
379.72|3.66| So the main idea behind this RMS prop, I mentioning it because
383.38|4.08| it will be relevant when we talk about the Adam algorithm. So the
387.46|2.18| main concept is we divide the learning rate by an
389.64|3.3| exponentially decreasing moving average of the squared
392.98|3.12| gradients. So it's essentially a modified version of this
396.1|3.2| adaptive learning rate that I showed you on the previous
399.3|3.72| slide. So the previous slide was a very simple type of adaptive
403.02|4.32| learning rate, this is a little bit more sophisticated. Because
407.34|4.0| it takes us into account that gradients can vary widely in
411.34|3.52| the magnitude. So some weights or gradients are larger than
414.86|5.36| others. And the RMS and RMS prop stands for root mean squared,
420.42|7.56| because it's related to these squared gradients. And it also
427.98|3.82| has an effect of this dampening effect. In addition to the
431.8|2.82| adaptive learning, it also has this adept dampening effect of
434.62|4.36| the momentum on the oscillations. But in practice,
438.98|2.28| yeah, people thought it might work better than using
441.26|3.88| momentum. So this RMS prop, people found works better than
445.14|3.12| just momentum. But yeah, nowadays, people use a
448.26|4.36| combination of Adam, or the people use Adam, which is a
452.62|4.92| combination of RMS prop and momentum. Okay, but let's talk
457.54|3.64| about this RMS prop first, before we go into the Adam, Adam
461.18|4.8| algorithm. So there is now a mean square term here that is
465.98|3.24| the moving average of the squared gradient of each weight.
469.42|3.52| It's kind of, in a way similar to momentum, but we have now,
473.18|2.6| instead of just considering the moving average, we have the
475.78|5.76| moving average of these squared gradients. There's a beta term.
482.42|7.32| So t is again, the time step. For instance, the iteration, and
489.98|4.44| w ij is the weight we want to update. So we have the mean
494.42|5.32| squared gradient of that weight at a given time step. And this
499.74|5.84| is computed by multiplying a beta with the mean square value
505.7|5.32| from the previous iteration. So and then, on top of that, we add
511.34|4.92| these squared gradients for the current iteration. So this is
516.98|4.32| the mean term here, right? So this is something we keep from
521.3|4.2| from the previous rounds. And this is only for the current
525.5|3.72| round for time step t. So it's essentially the gradient of the
529.22|2.92| loss of partial derivative of the loss with respect to the
532.18|7.8| weight should be a partial here. And we square those essentially,
539.98|5.68| so they are always positive values. Yeah, and then this is
545.66|3.56| how we compute the mean square value. And then we use that mean
549.22|5.16| square value to scale the gradients at that update. So
554.38|3.32| here, we are just computing the mean squared term, and here we
557.7|5.32| are applying it. How do we apply this? So if you look at this,
563.02|6.6| again, this is like the regular gradient descent update, right,
569.62|4.08| we take a step into the direction, the negative
573.7|4.08| direction of the gradient. So we subtract the gradient times the
577.78|4.48| learning rate. But now, in addition to doing that, we scale
582.28|4.34| by this mean squared term, and we take the square root, so it
586.62|4.76| has the same unit as the weights. So and this is
591.38|2.48| essentially it, it's very similar to what I showed you
593.86|4.04| before, the adaptive learning rate where we have a gain that
597.9|4.4| we modify, except that this is a certain type of gain that is
602.46|3.48| working a little bit differently. And yeah, we have
605.94|4.32| the small epsilon to avoid division by zero errors. In a
610.26|3.42| way, it's also somewhat similar to the momentum term. So when we
613.68|3.62| look at Adam, we will see there are two things the momentum term
617.3|2.32| and this term, and they are actually also themselves very
619.62|4.02| similar. Except this is like a scaling factor, in a way, and
623.64|7.1| the momentum is something that we add on top. So let's then
630.74|2.48| now talk about this, Adam, because I mentioned it so many
633.22|4.12| times, it stands for adaptive moment estimation. Again, it's
637.34|3.56| probably the most widely used optimization algorithm in deep
640.9|3.64| learning as of today, I use it a lot, because I find it just
644.54|4.44| works very well out of the box. And I always find I get almost
648.98|5.36| always the same, or even better performance as with SGD, plus
654.34|3.52| momentum and learning rate schedulers, but I need way less
657.86|3.84| tuning. I mean, here, I mean, tuning of the learning rate and
661.7|5.0| the strength of the scheduler. So like I said, it's a
666.7|5.52| combination of momentum and RMS prop. And to get to make this a
672.22|5.44| little bit easier to read. Um, I was also should say, if you
677.66|3.68| want to read the original paper, which contains way more detail,
681.74|4.28| this is the paper where it was proposed from 2014. So here, you
686.02|3.44| can find also more information. So here, I'm rewriting this
689.46|3.64| slightly to make this a little bit, I would say easier to see
693.1|6.6| how it is related to momentum. So here, on top, this is the
699.7|4.84| original definition of the momentum that we defined in the
704.54|5.32| last video. And I'm just replacing this delta w by this
710.94|3.36| MT. So I'm just using a different notation here, I'm
714.3|3.12| just changing the notation, not changing any concept. I'm just
717.42|4.44| saying, okay, let's call this one now, m at time step t. So
721.86|3.52| the momentum term, m for momentum at time step t. And
725.38|3.24| here, the, this is the current time step. And this is the time
728.62|4.4| step for the next round, essentially. So here, this is
733.02|6.44| the rewritten version of that. But you can see, it's slightly
739.46|4.84| different now, because we have this modified version where we
744.3|5.84| have alpha, but instead of using the learning rate here, we use
750.18|4.56| one minus alpha. So it's not exactly like the same, like the
754.78|3.4| original momentum term, it's slightly different. So we have
758.18|4.88| this one minus alpha, instead of the data in the original
763.06|4.56| momentum, but you can see how similar it is, right. So we have
767.62|11.08| we have both on alpha times m, which we have here. And we have plus here, we have the gradient, the same thing, except again, the only
778.7|2.36| differences here, we have the learning rate. And here we have
781.1|6.72| one minus alpha. Okay, so here, I was just rewriting the momentum
787.82|3.16| term from the previous slide, exactly the same thing, just
790.98|4.04| carrying it over. And now we have this RMS prop term that I
795.02|4.4| showed you a few slides ago. So here we had the better term for
799.5|2.8| multiplying it with a mean square, I'm just abbreviating
802.3|6.52| here as R. And then we have one minus beta times the squared
808.98|2.84| gradients. So this is essentially the same I also
811.82|3.12| showed you before, now I'm just using our so it's shorter. And
814.94|5.2| then for Adam, we combine both, we have momentum. So we have
820.14|3.0| the learning rate times the momentum term, it's essentially
823.14|6.32| our velocity. And we scale that momentum term by this arm as
829.46|5.6| proper term. So square root r plus this epsilon. And this is
835.06|7.6| essentially how Adam works. So we have the momentum term and
842.66|12.84| here, the arm is prop term. Okay, um, there's a slide, I
855.5|2.96| would say modification of that in the paper. So here, that's
858.46|5.0| the original paper, how it is defined in the paper. And what I
863.46|3.68| haven't contained or included in the slides for simplicity was
867.14|3.96| this bias corrected, first moment estimate, and the bias
871.1|3.84| corrected second raw moment estimate. So here, the
874.94|4.88| difference is essentially that I should also say, I'm calling it
879.94|3.96| alpha and beta. So here, they have beta one and beta two. So
883.9|4.48| if we go back, I call that alpha, just because I was, I
888.38|4.96| don't want it simpler. But this is essentially beta one. And
893.82|5.6| here, this is beta two. In the paper, I just found it somehow
899.42|3.48| more intuitive to say alpha and beta, because we also used alpha
902.9|4.56| before when we talked about momentum. So yeah, they just
907.46|5.4| correct this term by having another scaling by so they scale
912.86|3.96| the momentum term by dividing by one minus beta to the power of
916.82|3.36| t, where t is the time step essentially, and they do the
920.18|5.76| same thing for on this V term. Yeah, and this is essentially it.
925.98|2.96| So in the next video, I will show you how we can use these
928.94|2.64| optimization algorithms in pytorch.