start_time|end_time|text
0.0|3.88| as the last video for this lecture, let me now show you a
3.88|4.08| code example, implementing the softmax regression model from
7.96|4.2| scratch, using this vectorized form that I showed you to show
12.16|3.84| you that it indeed works. Actually, I have two code
16.0|3.44| notebooks here. One is a from scratch implementation using a
19.44|4.12| simpler iris data set. And then I will also because I mentioned
23.56|3.0| that before in the lecture, I will also show you the MNIST
26.6|3.16| example, because I'm sure you were all waiting for it. Alright,
29.76|5.5| so let's execute the boilerplate here first, just get it getting
35.26|4.04| it out of the way. And here, so the data loading, there's
39.3|3.36| nothing really new going on. It's the same code I used for
42.66|3.06| these toy data sets and the simpler iris data set I used
45.72|2.9| before. So I don't want to really spend too much time on
48.62|3.04| discussing this again, it's essentially the same, only that
51.66|4.28| this time we are using three classes instead of two. So we
55.94|4.66| have now these circles, upside down triangles and squares. So
60.6|2.38| left hand side is the training set. Yeah, and the right hand
62.98|3.64| side is the test set. In the other notebook, I will show you
66.62|4.76| also the pytorch data loader. So that is then usually how we
71.38|2.72| load data, because in deep learning, we usually don't use
74.18|3.24| CSV data sets. So we usually don't do this procedure, we
77.42|4.24| usually use a data loader, I will show you in the next code
81.66|6.92| notebook how that looks like. Yeah, so starting with our low
88.58|2.62| level from scratch implementation, computing the
91.26|3.28| gradients manually. So here, I just defined some helper
94.54|4.52| functions, one that converts the class label to a one hot
99.06|3.4| format, a softmax function and the cross entropy as the loss
102.46|3.16| function. Note that you don't have to implement any of that
105.62|4.0| when you use pytorch regularly. I mean, the regular version of
109.62|5.16| how people implement code in pytorch, because pytorch will
115.3|4.2| do the one hot encoding. Yeah, internally, kind of implicitly
119.5|2.44| when we compute the loss, I will show you how that would look
121.94|4.12| like later. And also, it has a softmax and cross entropy
126.06|2.88| function already implemented. So you don't have to worry about
128.94|3.2| this yourself. But yeah, I'm just doing it here to really
132.14|3.4| show you that the mathematical concepts from this lecture
135.54|3.92| really translate one to one into code. And it actually all works
139.46|4.68| works. So similar to a logistic regression, we start with
144.14|4.68| defining a class. So in the init constructor method, we construct
148.82|3.44| the weights and the bias, so we initialize them here to all
152.26|3.6| zeros. And notice that weights in contrast to logistic
155.86|3.2| regression, and this softmax regression context, it's now
160.02|3.36| matrix, right. So we have the matrix num classes, num
163.38|5.36| features. So this is what we use to age, I think, for the number
168.74|6.54| of classes, h times m matrix. And because we have also two net
175.28|3.9| inputs for the two outputs, we also have now the bias as a
179.18|6.92| vector, right. So this is a h dimensional vector now. So h is
186.1|3.8| the number of classes. And here, here's the forward method. So
189.9|3.14| the forward method is computing the net inputs. So I call them
193.04|3.36| logits. But yeah, these are you can think of them as the net
196.4|4.24| inputs. It's just the other multiplication between the
200.64|4.76| inputs and the weights plus the bias vector. So this would be an
205.44|4.92| h dimensional net input. So these are our z values here.
212.56|4.04| Then I'm applying the softmax to get the probabilities. So the
216.6|4.04| probabilities here with that, I mean, these units a, a one and a
220.64|4.8| two are activations. So we can also call them the activations.
225.44|8.78| And these are net inputs. And I'm returning both here. And
234.24|2.3| yeah, here, this is the interesting part, the backward
236.54|3.38| method, that is where we compute our gradients. And instead of
239.92|4.0| doing everything with a for loop for each weight individually,
243.92|3.92| we can actually use the vectorized implementation I
247.84|4.12| showed you. And let me move this over. I'm implementing it really
251.96|4.34| one two by one here, or I mean, like literally, it's not making
256.3|4.96| any change, we use our x transpose times. So with a
261.26|3.84| matrix multiplication, times y minus probability. So progress
265.1|4.4| is really the activations here. So this part is essentially this
269.5|3.22| party in the parentheses, and then also the transpose again.
273.1|4.04| And this is exactly the same as I'm showing you on the slide.
277.14|4.48| For the bias unit, it's a little bit simpler, because the
281.9|4.16| derivative doesn't include the x term. So we can just so this is
286.06|6.2| a vector, right? So we can just compute the sum. All right. Um,
293.78|4.56| yeah, this is it. So here in the predict labeled thing, I'm just
298.34|4.36| applying the arc max to get the index of the highest probability
302.7|2.52| in the activations. So that's also what I explained to you
305.22|5.6| earlier. I can actually move that back here. All right. So
310.82|4.48| this is all all that's new here, really, the rest here is the
315.3|3.96| same. So the evaluate function, that's the same as the one for
319.26|3.08| logistic regression. And the training is also the same.
322.54|2.76| Notice the only difference here for the train function, what I
325.3|3.24| did is train method, what I did is I added this one hot
328.74|3.96| encoding here to get the one hot encoded class labels. But again,
332.7|2.88| here, we call forward, and we call backwards to get the
335.58|4.64| gradients. And then we update the weights by applying the
340.22|5.76| negative gradient. So minus, so minus the gradients times the
345.98|3.38| learning rate. I'm also normalizing by the size of the
349.36|3.46| mini batches, because I told you that is easier to find a good
352.82|3.84| learning rate this way. And here, this is just for logging,
356.82|3.68| again, to show our accuracy and loss during training. But yeah,
360.5|4.0| again, this is actually not too complicated, right? I mean, if
364.5|3.08| we look at the backward method is really just two lines of code
367.58|3.2| here, if we use the linear algebra compact vectorized form,
371.46|3.28| I should actually mention this is not so trivial, of course, to
374.78|3.76| think about what should go in here. It looks very simple, but
378.54|3.2| it might take you hours and hours to think about it. So
381.74|3.52| personally, in the first pass, if I would ever implement
385.26|3.56| something from scratch, I would implement it in Python for loops
388.82|3.8| and then go to the linear algebra. Yeah, implementation. I
392.62|3.24| think that's maybe easier for me. Other people may find it
395.86|5.22| easier to think about in these matrices, matrix and matrix
401.08|2.9| multiplication terms. I personally, it's not my my
403.98|4.56| credit, my thing, I like things simpler, even they can be more
408.54|4.2| verbose. But I'm using this, of course, because it's more
412.74|3.04| compact, it's very information dense, lots of things going on
415.78|2.6| here. It's more compact, though, and computationally more
418.38|3.32| efficient. But again, also, I should say in practice, no one
421.7|3.2| really implements this by themselves anymore, because we
424.9|3.44| can use pytorch autograd, which has some computational
428.34|3.36| facilities to do this automatically. Alright, so let's
431.7|0.72| train this then.
434.62|2.84| Alright, so we can see after the first epoch, we already got a
437.66|3.16| pretty good training accuracy, it actually goes down, which is
440.82|5.4| interesting. But yeah, more interestingly, the cost or the
446.22|3.48| loss here goes also down. So I think this is really due to
449.7|2.72| noise that the training accuracy goes down, it's probably
452.46|4.8| overfitting here. But yeah, we see the loss goes down. That's
457.26|2.08| our result. And let's take a look at
463.98|0.84| what it looks like.
466.62|2.2| So yeah, we can see the loss goes down, maybe training it
468.82|3.2| more would be even better. And then let's compute the test
472.02|5.46| accuracy, it's 80%. Let's take a look at how it looks like. So
477.48|5.1| yeah, I'm using function, plot decision regions, we have seen
482.58|4.36| that briefly in statistics for 51, if you recall that, but you
486.94|1.88| don't have to know this or remember this, because in
488.82|3.68| practice, we will actually never really work with two dimensional
492.5|4.12| data sets. So we never really have the luxury of plotting it,
496.66|2.32| I'm just using a very simple data set, which is why it's
498.98|3.88| possible here. So here's how the decision regions would look like.
503.02|3.8| So you can see, yeah, the softmax regression classifier
506.82|3.92| is able to deal with the three classes by classifying them
510.78|5.08| relatively well. It's not great in this region here, could have
515.86|4.24| maybe been improved if the line would be more like this. But
520.14|3.2| yeah, it's hard to tell. It's actually not a trivial problem
523.34|3.8| for a linear classifier. A nonlinear classifier may have a
527.14|5.78| easier time here with in this region. Now, but this is also
532.92|3.72| not the point. Now, let's take a look at how we would implement
536.64|5.28| it using pytorch module API. So the module API makes many things
541.92|3.32| easier, like I said before, so we can use this linear layer,
545.24|4.8| which is our net input computation here. So actually, we
550.04|4.08| don't need all of this part in a real application. I'm just
554.12|3.64| doing this part so that we can compare this implementation to
557.76|3.32| our from scratch implementation, because above, I also used
561.12|5.92| zeros. So if I go up, I initialize the weights to zeros.
567.28|6.28| So otherwise, if I don't do that, here at the bottom, it
573.56|2.96| will have small random numbers, the smaller random numbers are
576.52|3.16| good for multi layer networks. But yeah, it would make it hard
579.68|3.32| to of course, compare than this implementation with our above if
583.0|6.16| we have different starting weights. So yeah, we just add
589.36|2.8| this, but in a real case, you would just run it like this.
592.72|2.72| Alright, but we will also talk more about weight initialization
595.44|2.64| and later lecture, I think, like, I would say maybe in two
598.08|3.44| weeks, I will have a lecture on how we can initialize weights
601.52|4.0| and what these random weights are. And there's also, there are
605.52|3.84| some computational tricks to choosing good weights. Alright.
609.36|4.36| Um, yeah, the forward method is now very simple, we can use the
614.6|3.48| oops, the net input computation here via the linear layer, which
618.08|3.72| we defined here. And then here, this softmax is our softmax
621.8|4.84| activation function, we use that from pytorch now. So F is from
626.64|4.48| pytorch, I think I imported it at the very top. Let me see.
632.24|4.3| Yeah, so here, this is the torch functional API. So and n stands
636.54|2.78| for neural network, and since the functional API, instead of
639.32|4.44| typing it all the time, instead of writing, let's say this dot
645.48|4.56| softmax, and do the same for other functions, people usually
650.04|4.04| implement the function API SF, just to make it shorter. So you
654.08|5.44| only have to type F softmax, basically. So that's just a
659.52|6.64| convention when you work with pytorch code. Okay. So yeah, and
666.16|4.32| that is basically it, we are using the stochastic gradient
670.48|2.94| descent optimizer here, optimizing the parameters of
673.42|4.46| that model. And yeah, this is all all there is to it really.
679.32|6.28| When we use pytorch and training it now, you can see test accuracy
685.6|4.6| is also 80%. And actually, if you would scroll up, you look at
690.2|5.24| this decision region plot. And this one, it looks almost
695.44|3.4| identical, there's some slight numerical difference, if I think
698.84|4.92| if you look at these values, your point 558, and minus point
703.76|2.72| 12. Let me just copy them. Maybe
709.4|5.52| there's some slight, maybe not really even. Yeah, this is one
714.92|2.48| is a little bit different, you can see, but it's only like three
717.4|3.12| digits after the decimal point, this is just an numerical
720.52|2.68| rounding error, I would say, because we implemented lots of
723.2|4.48| things from scratch, like softmax, and the cross entropy
727.68|2.96| function, and things like that. And we have the vanilla
730.8|3.4| implementations, there are also some numerically more stable
734.2|4.32| implementations of softmax by adding or multiplying the
738.56|4.84| nominator denominator and numerator by C. So adding lock,
743.72|4.34| C lock constant to the exponent that would make it more stable,
748.06|2.7| but then it would change the numbers slightly think these
750.76|3.96| differences are because of that. Yeah, of course, in practice,
754.88|3.12| you don't want to implement softmax and cross entropy
758.08|3.06| yourself, because it's numerically not as stable as not
761.14|2.94| as fast as the implementations that are already provided. But
764.08|3.28| yeah, overall, we get exactly the same results. I mean, the
767.48|5.8| small rounding differences. Now, this is how we do softmax
773.28|2.92| regression in pytorch. Let's now take a look at the same thing
776.2|3.08| for the MNIST data set. Because I already showed you the MNIST
779.28|3.36| data set in the lecture. And so just for completeness, we will
782.64|2.4| actually be working with this more when we talk about
785.04|4.2| multilayer perceptrons in the next lecture. So what's new now
789.24|3.8| is I'm using a data loader. And this is usually how we load
793.04|3.88| images in pytorch on other types of data. So here are just
796.92|5.64| some settings for my model. And here, the MNIST data set is
802.56|3.44| already provided in a library, let me scroll up again, the
806.0|4.12| library called torch vision, it comes with a number of data
810.12|3.52| sets. So if you install pytorch, it will also if you use the
813.64|2.56| installer via the website, it will automatically install torch
816.2|2.28| vision. So you don't have to install it separately, it
818.52|3.16| usually is included in the command that you executed when
821.68|6.04| you install pytorch. So we use this MNIST data set from torch
827.72|4.4| vision from the data sets sub module. This is just specifying
832.12|4.76| where to store the data. So it will create, if I go here, it
836.88|3.88| will create a data folder in next to my notebook here,
840.8|3.2| because I called it data, but you can actually change this to
844.0|4.64| whatever you can change it to desktop data or something like
848.64|3.56| that really doesn't matter, just where it keeps the data so
852.2|3.28| temporarily. So if you go here inside, you will see it will
855.48|10.44| it will keep a copy of that data. All right. Then it has a
865.92|4.48| trust test and a training set. So train true test. This is for
870.4|3.52| testing. If you say train faults, I will actually show you
874.92|2.16| it's a little bit unfortunate that MNIST doesn't have a
877.08|2.88| validation split. But I will show you in the multi layer
879.96|3.0| perceptron lectures how we also can create a validation split
882.96|5.88| for that one. This one is kind of required. It's because MNIST
888.84|5.28| is images and they come in, I think it's a PIL Python imaging
894.12|3.84| library format. And you want to convert them to pytorch tensors.
898.08|5.52| So this one is converting the image representation in Python
903.84|3.44| to a pytorch tensor representation. But we will also
907.28|4.28| see later, we can use other data augmentation here like
911.56|4.84| on randomly flipping or cropping images. So we will talk about
916.4|3.4| this also more when we talk about convolutional networks.
920.32|4.64| Also, I should say that to tensor normalizes, it normalizes
926.08|10.04| the pixels to zero one range. So it's dividing them by 255. So I
936.12|3.28| should mention that so we don't have to do our data normalization
939.4|3.16| ourselves. Of course, we could actually do something better. We
942.56|3.96| could standardize them for color images. Sometimes people
946.54|5.26| standardized using on the mean, and the standard deviations from
951.8|4.72| image net. We could technically also do that for color images
956.52|2.8| for here, something like MNIST, it doesn't matter at all. To be
959.32|2.86| honest, there's probably no difference in the performance of
962.18|3.14| the model, because it's a very simple optimization task here
965.32|4.72| with stochastic gradient descent. Alright, so this is
970.06|3.46| defining the training data set. This is defining the test data
973.52|2.56| set, the differences really that we set train false and here to
976.08|3.28| true, we only need to download it once, right? So we don't have
979.36|4.48| a download here. Then we using the data set, we define data
983.84|4.04| loaders. So here, I'm defining a data loader for the training
987.88|3.64| set, I can set my batch size, I set it here above, that's my
991.52|4.56| mini batch size, I set it to 256. And then whether we want to
996.08|3.24| shuffle or not. So this is shuffling before each epoch,
999.6|7.06| shuffling the data set. Notice that here, I'm not shuffling the
1006.66|3.38| test set, because it doesn't really matter. I'm loading the
1010.04|3.4| test set in batches, it's also not really necessary, because we
1013.44|2.44| don't do any training and stochastic gradient descent on
1015.88|4.44| the test set. But in let's say, if we work with real image data
1020.32|3.76| sets, like image net, the test set can be quite large, and it
1024.08|4.24| might not fit into memory. So we can also load it one by one,
1028.32|4.2| basically, that's what I'm doing here. Here, just for completeness,
1032.56|4.04| I'm this is more like for verifying that everything looks
1036.6|5.6| good. So here, I'm just having a for loop over the images and
1042.2|2.72| labels in the training order, just to make sure everything
1044.92|7.32| looks okay. And you can see it's loading the images in this n h
1052.28|5.16| or n c h w format, the batch size, the number of color
1057.44|3.24| channels, we only have one color channel, because m is this black
1060.68|3.92| and white. And then we have the height and the width here. And
1064.6|4.12| the labels, of course, are a vector, because that's just the
1068.76|5.84| numbers. And I should also tell you, okay, um, these labels are
1074.6|3.44| not one hot encoded. So you can see that they're just the
1078.04|4.2| numbers of the class labels, the 10 class labels. It's not
1082.24|2.72| necessary to one hot encode them, because pytorch does it
1084.96|4.88| automatically, when we call the cross entropy loss. Alright, so
1090.12|4.8| here is now my implementation. This is the same as in this from
1094.92|3.72| scratch here. So there's nothing really different. Same thing.
1098.64|4.24| Um, yeah, so also notice, so yeah, the accuracy, I'm
1102.88|5.72| computing it using a for loop over the data loader. I don't
1108.6|2.4| have to go through this. I think this is something you could
1111.0|6.04| copy and paste if you need it. Um, yeah, so the interesting
1117.04|2.32| part, what I wanted to show you is, because I don't want to
1119.36|2.32| make this video too long. I mean, I could discuss everything.
1122.0|3.44| But if you have questions, maybe ask on Piazza, we can discuss
1125.44|3.44| this more. I don't want to spend too much time on things that are
1128.88|4.2| not that important right now. Um, yeah, so the important parts
1133.08|4.8| are here that we are concatenating. So that goes back
1137.88|6.64| to what I've showed you here. So this would be how our image looks
1144.52|4.56| like it's 3d tensor, one image is a 3d tensor 28 by 28. And
1149.08|3.88| then the color dimension. So if you don't think of the color
1152.96|4.08| dimension, it would be a matrix, a 28 by 28 matrix, but we need a
1157.04|3.6| feature vector as input. So we would concatenate it to a very
1160.64|6.32| long vector, 28 times 28. So 784 dimensional vector. So that's
1166.96|3.44| what I'm doing here. So I'm concatenating it to a vector, I
1170.4|5.0| can maybe show you how that would look like for one given.
1175.4|7.56| Let's say we take one image. So this would be the one color
1182.96|4.96| channel and 28 by 28. Actually, you can also I mean, okay, it's
1187.92|7.2| fine, I think. So you minus one and 28. So you can see now it's
1195.12|6.36| a one long vector, basically. So in this case, I think it's a
1201.48|6.96| matrix because we have the first dimension, but yeah, so but the
1208.44|9.12| same thing applies. So here. Yeah, we do that for the. So
1217.6|3.6| actually, this would be for the batch dimension one more time,
1221.2|8.84| sorry, on images. So this should be a 25, a 1250. So this should
1230.04|11.12| be five at 256 times 784 dimensional matrix. So this is
1241.16|3.4| for the is obviously this is like how our design matrix looks
1244.56|5.52| like it's then an n times m dimensional matrix now where m
1250.08|4.52| is the features and is the batches. It got rid of notice
1254.6|2.48| that got rid of the color channel here. There's no color
1257.08|4.28| channel because we only define two axes. If we do it like this,
1261.36|2.32| it would have a color channel. But yeah, we don't want to color
1263.68|8.96| channel here. All right. Um, yeah, and then we call our model
1272.8|4.44| notice when we use pytorch, we don't use dot forward, because
1277.24|4.64| that it's actually better to just call it like, like this, it
1281.88|2.96| will internally call forward, but it will do some extra checks
1284.84|2.92| before it calls forward, as I explained in an earlier lecture.
1288.32|3.08| And now the interesting part is, yeah, we compute the cross
1291.4|6.12| entropy cost or lost here. And notice that is important that it
1297.52|4.6| uses the logits as input. So it's not using the probabilities,
1302.28|4.56| it's using the logits. This was what I explained in the previous
1306.84|4.72| video. This is like the slightly confusing part is explained in
1311.56|4.8| this other previous video. So we have to pay attention that we
1316.36|5.2| provide the logits and not the probabilities here. Yeah, and
1321.56|4.64| then we zero the gradients to the backward. Or we are just
1327.12|6.16| averaging the costs here. Don't know why I did that. Don't need
1333.28|6.76| that. Oh, I Okay, I see. I have I compute the average cost over
1340.04|8.28| the epoch. I see. Yeah, so then I'm plotting it. Okay, need to
1348.48|1.16| execute this part.
1359.48|5.4| So this cost is the average cost per epoch. I could technically
1364.88|11.32| compute the cost by calling forward on doing this one for
1376.48|4.04| the whole data set. But it would be more work, right. So you
1380.52|2.4| would have to load the whole data set. So I'm just computing
1382.92|11.0| the average. Okay, might take a while. It's not too bad, though.
1393.92|6.24| It's like, um, point, point, four minute point, oh, four
1400.16|6.92| minutes per epoch. So even I don't know if these numbers make
1407.08|6.88| sense. One minute makes maybe sense. Alright, so now, yeah,
1413.96|2.68| this is how the loss looks like you can see it goes down as
1416.64|5.4| expected. Let's take a quick look at test accuracy. 92.16 is
1422.04|2.44| actually pretty good, right? I mean, given that this is an
1424.48|3.92| image data set, and we only have a linear classifier, we don't
1428.4|3.08| even use a neural network, I mean, a multi layer network, we
1431.48|3.56| already get a pretty good performance. And personally, I
1435.04|3.8| also recommend you when you work on classification tasks, always
1438.84|3.56| to run also logistic regression classifier, or softmax
1442.4|2.98| regression classifier as a baseline, just to get a feeling
1445.38|2.22| of how difficult the classification problem is,
1447.64|2.92| right. So if you train, let's say convolutional network, and
1450.56|4.52| you've got only 94% with a convolutional network, you would
1455.08|2.56| say, Okay, this is such a complicated convolutional
1457.64|3.92| network model, why does it only get 94% when I get already 92%
1461.56|4.52| with logistic regression, maybe my model with 94% isn't that
1466.08|4.32| good after all. So it's always a good thing to run also logistic
1470.4|5.12| regression as a baseline. Here's just an example, learning three
1475.52|4.8| random images from the data set, seven to one and zero. And then
1480.34|5.1| here, I'm doing my predictions. So calling this one on the
1485.44|3.8| feature vectors, and then the arcmax max to get the class
1489.24|4.54| labels, right, because this one would give us just the
1493.78|4.38| probabilities, you can see, so we are taking the arcmax. So for
1498.16|7.8| the first one, let's take a look. Should be this one should
1505.96|8.4| be the highest 01234567. This is the highest is actually should
1514.36|4.44| be the highest one. So in this way, we compute the class
1518.8|4.16| labels here just to show that these are indeed correct.
1522.96|6.72| Alright, so with that, um, yeah, this is all I think I have for
1529.72|2.76| this from scratch implementation. And then in the
1532.48|21.0| next lecture, I will talk about multilayer perceptrons.