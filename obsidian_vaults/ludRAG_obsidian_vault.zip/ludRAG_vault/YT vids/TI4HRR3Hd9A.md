start_time|end_time|text
1.48|3.92| Alright, so the plan is now to implement a recurrent neural
5.4|6.4| network with an LSTM as a classifier to classify texts. So
11.92|5.2| this will be a many to one word RNN because we are going to read
17.12|4.32| in texts, and then we regard each word as a token in that
21.48|4.84| sequence. So in this video, I'm going to outline the different
26.32|2.84| steps that are necessary for that. And then in the next
29.16|3.72| video, we will take a look at how that looks like in pytorch.
33.2|4.32| So now, these slides won't be pretty, but I hope they will
37.64|4.64| kind of convey the big picture that underlies the pytorch
42.28|4.88| implementation. So, because we are talking about a
47.16|4.0| classification task, we are talking about a many to one
51.16|6.16| network here. So we have as input, for example, sentence,
57.32|5.52| and then the output is a class label. So that will be a class
62.84|3.36| label prediction. For instance, we are going to take a look at a
66.44|4.0| IMDb movie review data set. And then we are going to predict
70.68|4.8| whether the reviewer thinks that the movie is positive or negative.
77.96|4.64| So, um, just to recap, this is a slide I've shown you in the
82.6|3.92| very beginning of this lecture. So this is the classic approach
86.52|3.6| for text classification using the so called back of words
90.12|3.36| model. I don't want to discuss this again, because yeah, I
93.48|3.28| already discussed this in an earlier video. But I wanted to
96.76|3.44| highlight again that we are using the so called vocabulary
100.2|4.96| here. For the RNN, we are also going to use a vocabulary that
105.16|4.52| is similar to this one. The only thing is that this part here
109.68|4.68| will be different. So we won't have a design matrix as a input
114.36|2.76| Yeah, input to the machine learning algorithm, we will have
117.32|8.08| an embedding. So basically word embedding. So this will be now
125.4|4.12| in four different steps. So I'm trying to do it step by step,
129.52|3.2| because it can be a little bit complicated. So breaking it
132.76|4.0| down into smaller steps might help understanding the process.
137.0|2.48| And these steps are also approximately how we would
139.48|4.2| implement them in pytorch. So this is for the recurrent neural
143.68|4.44| network now. So step one would be also building a vocabulary
148.2|3.68| similar to the classic approach. So you can see the vocabulary
151.88|3.48| here is quite similar to the vocabulary I've shown you here.
156.64|7.56| So I added two things here are unknown is for unknown words. And
164.24|3.8| this is a padding for making sequences the same length, this
168.04|4.28| will become clear later. But essentially, the vocabulary is
172.32|4.08| also a vocabulary that consists of all the unique words that can
176.4|3.12| be found in the training set. So if this is my training set
179.52|4.08| here, the vocabulary contains all the unique words, it's a set
183.6|3.12| of unique words, and it's mapping to integers here. So
186.72|3.32| you can see, the order doesn't really matter, you can do it
190.04|3.52| alphabetically, but any order is really fine. It doesn't really
193.56|3.48| matter which order the vocabulary is. It's just a
197.04|4.76| mapping dictionary. And yeah, so we have this vocabulary here.
201.8|6.36| And then step two would be using this vocabulary to convert the
208.16|5.52| training example texts to indices. So again, if on the
213.68|4.36| left hand side, this is my training data set. Let's now use
218.04|4.76| the vocabulary to convert it into these integer indices. Why
222.8|2.4| are we doing this, by the way, in the first place, that is
225.2|3.08| because the machine learning algorithms like to work with
228.28|3.68| numbers, right, because we have matrix multiplications, and so
231.96|3.64| forth, and we can't do a matrix multiplication with letters or
235.6|3.8| words, right. So we have to somehow get the inputs into a
239.4|3.68| representation that is numeric, something that we can do math
243.08|5.96| with. So, um, let's focus maybe on the first training example
249.04|3.88| here, x one, the first training example is the sentence, the sun
252.96|4.32| is shining. So using the vocabulary, we are not
257.28|5.4| translating. So this is the first word, the, the is index
262.7|6.54| seven. So for the integer representation here, so this is
269.28|3.92| on the right hand side, or integer representation of that
273.2|4.32| sentence. So we are now adding the seven here, right, because
279.04|4.36| that's how it goes here. Then for the second one, this is sun,
283.4|8.28| we have five. So this goes here, and then five here. The next one
291.68|15.44| is this one, one more shining. This one goes here. Alright, so
307.12|4.24| now we have mapped everything to integers. And compared to the
311.36|4.92| to the back of words model, we keep the order here. So the
316.28|3.96| order here in the sentence is the same as this order here.
321.36|2.84| Because yeah, the RNN is a sequence model. And like we
324.2|2.72| talked about in an earlier video, the order matters when we
326.92|5.4| work with text. So why are there dot dot dot and 10 1010 here?
332.56|6.56| So let's consider first the other sequences. So exam
339.12|3.12| training example two and training example three here. So
342.24|5.76| if we convert them to you, you see that example two has four
348.0|4.44| words, example one has four words. So we have four words,
353.44|9.4| four words, but sentence three has 12345678910111214 words,
362.88|4.36| actually, it's a much longer sentence. And because what we
367.24|3.84| usually do is we arrange things in a batch, we would have to
371.24|3.08| Yeah, well, we want to make everything the same length. So
374.32|5.12| if I have, let's say a batch, this is really for efficiency
379.44|6.72| purposes. And we have in our first one here, four words. We
386.16|6.24| do it like this. 1234. My second one is four words, we can't
392.4|4.6| have like nothing. I mean, we can't have a matrix where there's
397.0|2.8| nothing that would not be a matrix anymore. Everything has
399.8|2.84| to be in a matrix the same length. So we have to put some
402.68|4.64| values here. And these are our padding very, very values. These
407.32|3.36| are basically, yeah, placeholders in a sense. So we
410.68|5.28| are putting placeholders here to make everything the same size as
415.96|5.6| this last one here. So this is really, yeah, it's not really
421.56|4.44| necessary. If we had an RNN where we only feed one training
426.0|3.44| example at a time. But if we want to feed them as a batch,
429.44|2.72| then it would be necessary because there is a matrix
432.16|4.2| multiplication at some point. And for that, we have to have
436.56|1.48| everything the same length.
440.6|5.08| Alright, but moving on. So let's now say we have our training set
447.04|2.92| converted into these integers. If I go back one more time, it's
449.96|3.72| not considered these that we have converted. So this was step
453.68|4.88| two. Let's now go to step three, that is converting these
458.56|8.2| indices to a one hot representation. So this one
466.8|2.84| here, this is our sentence, we are only taking a look at one
469.64|4.56| sentence here, only one training example, just for keeping things
475.84|3.16| smaller here, otherwise, they won't fit onto the slide. So
479.0|2.36| let's only focus on this training example, the first one.
481.36|4.84| So this goes then into the integer representation, why did
486.2|5.28| I put it like 90 degree rotated, just wanted to show you where we
491.48|10.32| get these numbers from 7524. This is from the vocabulary,
501.8|2.6| this is exactly the same that I've shown you before. So these
504.4|6.8| are these numbers here. And then here the padding. So everything
511.2|4.56| I'm showing you here, these, this is the integer
515.8|4.56| representation from the previous slide. Now, the new thing here is
520.36|9.16| that we convert those to a one hot representation. So how does
529.52|4.72| it look like? So we would essentially have a matrix now
534.24|6.32| where this is for one training example. So this matrix has the
540.56|5.04| dimension here, the columns, this would be the dimension of
545.6|15.28| vocabulary size. And the rows would be the sentence length. So
560.88|7.04| we have the sentence, it's a bit hard to write this way, sentence
567.92|4.08| length, and then the vocabulary size. And then for each word,
572.04|6.0| so each row, this one would be essentially the first word, we
578.04|3.28| would then look up the wall, create the one hot
581.32|4.96| representation. If our vocabulary size in this case is, it should
586.28|10.08| be 111234567891011. So we have a vocabulary size of 11. This is
597.28|7.2| index 10. This is index zero. So the first one is a seven here,
604.48|3.0| let me use maybe a different color, let me use the green. So
607.48|8.56| seven, so we got 1234567. Second one is five, so we go
616.04|5.04| 12345. Third one is a two. So we go
622.52|5.48| 1012. And then
634.08|3.36| let me see, I think I've yeah, I've okay, this is should have
637.48|2.36| put this model right. But anyway, it's the same concept
639.84|3.6| applies. Okay, so the four here, zero, one, two, three, four.
643.44|5.36| Okay. All right. So this is how we create our one hot
648.84|5.52| representation of that sentence. And then for sorry, this is no
654.36|2.64| wrong thing. I just copied and pasted the last one, these
657.0|4.4| should be zeros. And the ones here are because of the padding.
661.68|4.8| So these are padded ones. So if you only focus on the input
666.48|2.8| sentence, you can actually also ignore those. But these come
669.28|8.04| from the fact that we did a padding earlier here, here to
677.32|4.16| put everything to the same size as sentence number three. Okay,
681.84|3.84| we have now our one hot representation, we have
685.68|5.64| converted the text into integers into integer representation, and
691.32|10.56| then text, then one hot. So that's step two, step three, and
702.28|2.96| creating this vocabulary was step one.
708.28|4.28| Alright, so the next step now is to go from the one hot
712.6|4.32| representation into a representation that is containing
716.92|4.48| real numbers like decimal numbers, using an embedding
721.4|4.04| matrix. This is a weight matrix, a specific type of made weight
725.44|7.96| matrix. But let's do it one at a time. So first here is a recap
734.68|3.52| of what I explained in the previous night. So this is a
739.24|7.28| recap. And we are now going to focus only in this overview here
746.52|4.0| on one particular word. So let's consider we have this training
750.52|4.16| example x one. And for this training example x one, we only
754.68|7.48| focus on the first word for simplicity. So we built already
762.16|4.12| this vocabulary, this was step one, let me use black for this.
766.84|5.08| We used what we both have vocabulary in step one. In step
771.92|4.04| two, we learned how to convert the word together with the
775.96|6.28| vocabulary into this integer representation. So step three
782.24|5.68| was converting into the integer representation. Oh, sorry, step
787.92|3.0| two was converting it into integer presentation. So we
790.92|3.32| have this seven, step three was actually the other one hot
794.24|5.96| encoding. So step three would be the one hot encoding. So this is
800.2|4.72| what we had before, we are focusing only on this word, the
804.92|6.48| the no money this the this is for simplicity. And I will show
811.4|2.72| you on this slide, how we convert this one hot encoding
814.12|10.84| to a real number vector. So this one hot encoding here, I just
824.96|3.92| copied this over to this position here, this is just
828.88|6.72| copied over. And now we have this embedding matrix, this is
835.6|3.8| a weight matrix that is initialized with random values.
839.4|3.12| And this is updated during training, just like a hidden
842.52|3.92| layer. And in fact, actually, the embedding can be implemented
846.44|5.52| as, let's say, torch dot n n dot linear, fully connected linear
851.96|8.44| or use a different color fully connected layer. This is
860.4|3.96| nothing new. It's just the regular weight layer. We don't
864.36|7.44| need a bias for this one, though. Um, okay, so here at the
871.8|4.24| bottom, I'm now showing you how we go from this one hot vector
876.28|4.92| into this embedded vector. So this is the hidden layer output,
881.2|9.0| or we can also call it the embedded vector, or word. Or we
890.2|4.4| can also call it the embedding. Actually, there are some
894.64|5.16| dedicated methods for doing that there's something called, for
899.8|5.0| example, word to make, there's also something called glove.
905.16|4.64| These are models just trained to produce embeddings. So these are
909.8|3.36| special models that can produce such embeddings like this one,
913.16|4.92| the real value vector. In this class, we're not doing this, this
918.08|3.6| is an optional thing to do. So you could do this instead of
921.68|5.28| learning the embedding. But here, the embedding matrix is
926.96|4.0| essentially a part of this RNN. So here, I'm just showing you
930.96|8.72| the RNN, the mini to one to one RNN. And the embedding matrix is
939.68|4.04| just something that is used here. It's just a weight matrix
943.72|3.2| that is learned a matrix between the input and the hidden
947.64|5.56| activations or hidden values. And really, this is just like in
953.2|3.68| a regular perceptron, there's nothing really special about it.
959.12|3.88| Alright, so how do we get from this one hot vector with
963.0|2.48| embedding matrix to the hidden layer output? Yeah, it's a
965.48|3.24| matrix multiplication. So if you think of the one hot vector
968.72|3.34| that we have from here, this is essentially you can think of it
972.06|7.78| as a one times on v dimensional matrix, where we v is the
980.32|9.74| vocabulary size. So if you think about the matrix multiplication,
990.06|9.24| it would be zero times point one plus zero times 1.1 plus zero times 2.1
999.3|5.06| and so forth. There's only one value that is a one here. So the
1004.36|3.08| matrix multiplication between this vector here, and this one,
1007.76|3.76| the first column would be 7.1. And for the second one, if we
1011.52|4.48| multiply this one with a second column, this would be 2.5, 1.5,
1016.0|7.32| 1.5. So the output would be 7.1, 2.5, 1.5, 1.5. So this would be
1023.52|3.64| the embedded vector corresponding to this word the
1028.16|4.04| so that's how we get from a word to actually a real vector that
1032.2|5.52| can then be used in the RNN. So this word would be then the
1037.72|4.12| input to this hidden activation. And if there was a previous
1041.84|4.76| time step, that two things as input here, one input would be
1046.6|3.68| really this vector here. And the other input would be the hidden
1050.28|7.52| state from t minus oops, t minus two, if it's the first, if it's
1057.8|3.08| the first in the sequence, there is no input. So in this case,
1060.88|1.92| it's the first word of our sentence. So there won't won't
1062.8|4.36| be any t minus one, it would be the first time step. So this
1067.16|3.36| would be actually the first time step. And this is how we input,
1070.52|6.44| let's say a word into an RNN as a real value vector. Alright,
1076.96|3.64| this is only one word though. Now we have to do the same
1080.6|3.64| thing. Let me go back one side, we will have to do the same
1084.24|7.36| thing for sun is and shining. So this would be then a four by
1091.6|8.52| four matrix for the sentence. By the way, this is the embedding
1101.44|5.08| size, I just chose it to be four because coincidentally just fit
1106.52|3.88| well into this slide. But there's no correspondence
1110.68|2.84| between let's say the embedding size here and the sentence
1113.52|3.0| length, this is really independent. In fact, when you
1116.52|4.2| implement an RNN, you can choose the embedding size. So typically
1120.72|3.96| embedding sizes are something like 128 or 256, and so forth.
1124.88|5.02| But it really depends on how large the data set is and how
1129.9|2.94| difficult the classification task is as many different it's
1132.84|2.84| just another hyper parameter. Essentially, it's similar to
1135.68|4.12| choosing a good batch size. It's also about choosing the embedding
1139.8|2.76| size, the embedding size is essentially a hidden layer. So
1143.08|4.92| like you experienced in the homework three, it's just a
1148.0|5.56| hyper parameter to tune. Okay, so once going one step further,
1153.8|4.2| now I'm telling you something that maybe makes you hate me. So
1158.04|3.32| steps three and four are actually not done in practice.
1161.36|4.64| So everything I've showed you here, from converting everything
1166.0|4.76| to a one hot vector, and then getting this real value vector,
1170.76|4.08| this is not done in practice, I just explained it to you. So
1174.84|3.28| yeah, that you understand what's going on, like, conceptually,
1178.12|4.16| this is how we would do it conceptually. But in practice,
1182.28|3.92| actually. So now, it's, of course, a very complicated set
1186.2|2.0| up here, I understand. So you probably may have to watch the
1188.2|2.4| several times, or think about it a little bit. It's not
1190.6|4.32| immediately obvious. But so this thing here, we discussed this
1195.36|4.32| just before, this is kind of inefficient, right? Because we
1199.68|4.16| have, when we multiply this one with this first column, we have
1203.84|5.88| zero times point one plus zero times 1.1 plus zero times 2.1. If
1209.72|4.08| we have 11 values here, it's like 11 computations, but only
1214.0|7.08| only one matters, right? So we do like 10 computations for
1221.08|4.04| nothing really here. And this is also a small vocabulary, we only
1225.12|3.96| have 11 different things in our vocabulary. If you have a real
1229.12|3.68| vocabulary, usually, based on the training set, they are
1232.8|4.44| they are usually around, let's say 200,000 words, usually, we
1237.24|3.52| make them smaller, let's say 20,000. But you have 20,000
1242.2|4.8| words in the vocabulary, and then you have 19,999 wasted
1247.0|3.76| computations in each matrix multiplication. So to make this
1251.4|4.96| efficient, there's actually a torch dot n n dot embedding
1256.36|3.6| layer that just does the lookup. So instead of really doing the
1259.96|3.12| matrix multiplication between this one and this one, it just
1263.08|4.8| uses the index, the index seven here, and say, okay, just give
1267.88|3.28| me the value corresponding to index seven, look it up in the
1271.16|2.8| embedding matrix and put it here. So in this way, we don't
1273.96|3.0| have to do the whole matrix multiplication is just a lookup
1277.0|3.88| table. So this is what I have here on the next slide. So
1280.88|5.4| there's actually this lookup function, lookup approach called
1286.28|5.4| torch and n dot embedding. This is doing the same thing that
1291.72|3.44| we've done in steps three and four, but it's more efficient
1295.16|4.2| because it's just looking up this value. So now let's
1299.56|3.56| consider the whole sentence again. So sentence number one,
1303.12|4.28| the sun is shining. So in step one, we created the vocabulary.
1307.4|7.88| In step two, we converted the sentence to this integer
1317.2|6.64| representation or integer vector. Then in step three, we
1323.84|3.68| converted this integer vector into a one hot encoding, but we
1327.52|3.84| are not doing step three. Now, there's no step three. Instead,
1331.44|4.52| we're taking this integer vector directly. Together with our
1335.96|3.64| embedding matrix, this is the exact same embedding matrix that
1339.6|5.44| I've shown you. And then we are looking up these values now. So
1345.04|6.56| for word seven, say this one. So for the word, the which
1351.6|7.32| corresponds to the seven here, we're now looking up the row
1358.92|5.6| corresponding to seven. And this is then used here, this is our
1364.52|4.96| embedded sentence for the first training example. Then for the
1369.48|9.0| second word, some sun should be here, five. We look it up here,
1378.6|14.48| we put it here, then next one is, this is two. Looking it up,
1393.08|8.56| this one goes here. The last one, shining, shining is four.
1404.84|5.46| This one goes here. And this one goes here. And the remaining
1410.3|3.3| ones are padding because we had one sentence that was longer
1413.6|5.28| than four. So these remaining ones would be the padding. But
1418.88|7.76| yeah, this is how actually, this shouldn't be here. There is this
1427.08|0.92| to these
1430.56|4.6| padding, if we have sentences longer than four words, but you
1435.16|6.44| can see now, the matrix we have here is the embedding
1441.6|15.68| size times the sentence sentence length. And this is for one
1457.28|3.04| training example. If we have more than one training example,
1460.32|3.64| of course, we would have a batch size, we would have a tensor, a
1463.96|3.64| 3d tensor for considering the batch size as well. This will
1467.6|2.32| become more clear in the code example that I will show you.
1469.92|4.88| Do we have one more slide? Yeah, so okay, so now I was showing
1474.8|4.72| you these different steps here from converting a sentence into
1479.56|3.44| this input to the hidden layers in the recurrent neural network.
1484.24|3.16| In the code example, we are going to work with this setup,
1487.4|3.28| we are doing exactly that for a specific data set, we will be
1490.68|4.32| working with this IMDB data set. So this is just a binary
1495.0|3.48| classification data set, it's a sentiment classification data
1498.48|5.72| set sentiment just means like the perception, like whether
1504.2|2.8| something is emotionally positive or negative, like
1507.0|3.92| what's the sentiment of something. So this IMDB movie
1510.92|3.04| data set comes from the internet website, the internet movie
1513.96|5.52| database. And this contains the ratings for movies. And the
1519.48|4.64| rating can be between I think zero and 10. And the researchers
1524.12|4.44| here, you can find the data set here have the researchers have
1528.56|4.56| prepared it such that the I think maybe I kind of forgot
1533.12|3.44| it's long time ago since I took a look at the paper, or method
1536.56|4.24| where they proposed this data set. So I think the movie
1540.8|5.52| reviews are from zero to 10. But they only use one to four, sorry,
1546.32|10.44| sorry, zero to four for negative and seven to 10 for positive,
1557.44|4.64| they don't use 565 and six because it's ambiguous. They
1562.08|4.76| only use these and they refer to them as highly polar movie
1566.84|3.44| reviews. So anything with a rating between zero and four is
1570.28|3.8| considered negative. And anything between the seven and
1574.08|7.6| 10 is considered positive. And they have 25,000 reviews for
1581.68|5.4| training and 25,000 for testing. And here's just an example CSV
1587.08|4.76| file, how the data set looks like. So there's some text. And
1591.84|5.16| then there's a label one for positive, I think and zero for
1597.0|3.04| negative could also be the other way around. I actually can't
1600.04|3.12| tell based on readings this year. Alright, so but yeah, you
1603.16|3.6| have two sentiment labeled zero and one. And then this review
1606.76|3.6| text and we are going to build a classifier that can classify
1610.36|5.56| these reviews. By the way, yeah, in the next video, I will show
1615.92|4.32| you the code example for this mdb movie review classification
1620.24|3.68| data set. I just wanted to share this additional resource with
1623.92|3.56| you because I will only show you one video with code
1627.48|4.36| implementations. For an example, I actually found this repository
1631.84|5.52| which looks super helpful. It has more methods for yeah, RNN
1637.4|3.4| SDM classification, and also several tricks. There are some
1640.8|2.92| nice written tutorials. So there are more than these two, I just
1643.72|4.56| clip this screenshot. But if you are interested in building RNNs
1648.28|3.68| for classification, I highly recommend this repository here.
1653.28|2.92| So there's also some library we are going to use it's called
1656.32|4.64| torch text. So torch text is like torch vision, but for text,
1660.96|3.8| so there's pytorch. And then there are libraries associated
1664.76|2.52| with that torch vision is specifically for working with
1667.28|3.44| image data. And torch text is specifically for working with
1670.84|6.2| text data. There was recently an major update in torch text. So
1677.44|4.72| most or many things have changed a lot. And this tutorial, when I
1682.16|3.66| looked at it, it seemed like it was built for the original
1685.82|5.14| torch text. So now in point nine, things have changed quite,
1691.16|5.36| quite a bit. The old codes still work, but they are now considered
1697.2|4.68| legacy. So if you want to convert these codes here, I mean,
1701.92|3.6| technically, you can just use them like they are, it works
1705.52|3.64| fine. But in the future, maybe in a few years, they may not
1709.16|2.8| work anymore. I don't know. I don't know what the exact plan
1712.0|2.8| plan plans are by torch text, whether they want to remove the
1714.8|2.84| legacy code. But if you're interested, there's also this
1717.76|5.36| migration tutorial, which explain what have or what the
1723.12|3.6| things are that has changed between torch earlier version of
1726.72|5.36| torch text and torch text 0.9. So but this is for this class
1732.08|4.68| entirely optional. It's just fine to use any of this if you
1736.76|4.12| are interested. So in the next code, in the next video, I will
1740.88|4.46| show you one of my codes for implementing RNN and pytorch.