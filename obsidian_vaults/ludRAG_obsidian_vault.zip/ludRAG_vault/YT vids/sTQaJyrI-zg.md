start_time|end_time|text
5.54|7.36|okay so yeah I'm super excited to be
9.42|4.98|here uh and share our recent research
12.9|3.12|about neurosymbolic common sense
14.4|5.28|reasoning
16.02|5.339|um so uh part of the goal of this talk
19.68|3.54|will be to address some of the
21.359|4.801|frequently asked the questions these
23.22|6.12|days that NLP or common sense or
26.16|6.72|whatever it looks like almost by Chet
29.34|7.28|GPT and I have an existential crisis so
32.88|7.62|people do ask me this from time to time
36.62|6.759|so perhaps it's a case of a hasty
40.5|5.76|generalization especially if we do look
43.379|4.68|at some of the examples so the trophy
46.26|4.38|doesn't fit in the brown suitcase
48.059|5.581|because it's too big what's too big so
50.64|4.34|this is classical uh Winograd schema
53.64|5.759|challenge problem
54.98|7.899|and here chpt answers it correctly the
59.399|5.58|trophy is too big so impressive but what
62.879|4.92|if you change the question a little bit
64.979|5.341|then it says the trophy itself is too
67.799|5.581|small to fit into the suitcase so it's
70.32|5.159|not very reliable at the moment
73.38|4.8|um so the situation is a little bit like
75.479|5.881|David and Goliath in the sense that
78.18|4.619|um the bigger appears to be better uh in
81.36|4.02|many of the cases although of course
82.799|4.921|some of the more careful studies do
85.38|6.739|reveal that smaller models can be better
87.72|6.38|with the better data or better uh uh
92.119|5.981|reinforcement to learning with the human
94.1|7.12|feedback and whatnot so it's likely that
98.1|6.6|there are still uh other ways to improve
101.22|7.079|the Transformer performances uh by
104.7|8.82|building smaller models in a more clever
108.299|8.881|way so one way to draw the Insight is
113.52|6.12|from this classic book known as The Art
117.18|4.259|of War which of course says nothing
119.64|4.38|about deep neural networks or
121.439|4.261|Transformers but the wisdom here is that
124.02|4.14|I know your enemy choose your battles
125.7|4.44|and innovate your weapons which we can
128.16|3.2|translate that as
130.14|4.56|um
131.36|7.959|evaluation with realism as scrutiny and
134.7|6.42|uh focusing on uh different types of new
139.319|4.681|tasks and leaderboards and then
141.12|4.86|innovating your algorithms and data so
144.0|5.16|in this talk I'm going to showcase the
145.98|5.94|three such studies and let's Dive Right
149.16|5.04|In with the myriadic prompting by the
151.92|4.02|way so the recording theme in this talk
154.2|3.539|will be the smaller models can be better
155.94|3.36|and the knowledge is power
157.739|3.661|so
159.3|4.019|let's just start with this observation
161.4|6.119|the language models are sometimes
163.319|7.56|amazing so if you ask gpt3 if you travel
167.519|6.381|West far enough from the West Coast you
170.879|7.021|will reach to the east to Coast or not
173.9|6.28|so uh it says the world is around which
177.9|4.32|is correct so you will reach the East
180.18|5.339|Coast eventually therefore the answer is
182.22|5.58|true so this looks impressive
185.519|4.381|um except when it's not impressive so if
187.8|5.519|you ask other questions like butterflies
189.9|4.979|fly with the three wings or not it says
193.319|3.961|it has a four wings therefore the
194.879|5.701|statement is a false but if you read
197.28|5.099|back what it just said as true false
200.58|6.06|questions then it negates what it just
202.379|6.0|said so it can be inconsistent with its
206.64|4.379|own statement and then there are many
208.379|5.701|other such inconsistency problems so
211.019|5.64|it's not clear what language models do
214.08|5.04|or do not know it's almost like language
216.659|4.44|models are some sort of lemons
219.12|4.44|well it might be cherries if you only
221.099|5.041|pick cherries but it doesn't make
223.56|6.78|strange mistakes so the question is how
226.14|6.42|do we make better lemonade from gpt3 so
230.34|5.94|one approach might be to get
232.56|6.92|philosophical and use socrates's biotic
236.28|6.06|method that was originally developed for
239.48|4.24|addressing humans followed reasoning
242.34|4.14|because it actually turns out even
243.72|6.06|humans are not all that logically
246.48|6.479|consistent let alone gpt3
249.78|6.6|so the way it works is this we're going
252.959|6.361|to build my Uric inference tree and
256.38|5.16|let's use the previous example as a
259.32|4.62|running example so what we do is we ask
261.54|6.24|the following question providing the
263.94|5.28|answer being true and then let uh attach
267.78|4.26|because
269.22|5.88|so that we prompt gpt3 to continue on
272.04|5.939|this sentence which means it will now
275.1|6.0|have to explain provide explanation why
277.979|5.581|the answer is true in this case the
281.1|6.659|explanation is good so we it's the E of
283.56|7.02|T explanation of the answer being T we
287.759|6.421|ask the same question switching out true
290.58|7.2|with the follows and then see what uh BS
294.18|7.019|GPT 3 might come up with so here it's
297.78|5.88|just trying to go with the false as an
301.199|3.901|answer but it just doesn't have a very
303.66|5.4|good answer it just says you cannot
305.1|8.039|reach so now we call this as e of f so
309.06|7.859|it's explanation of f answer being f
313.139|8.221|um now let's see how robust or
316.919|8.34|consistent gpt3 is with respect to its
321.36|7.38|own explanations so we read the back e
325.259|6.061|of T and then let gpt3 to decide whether
328.74|6.899|it's gonna agree or disagree with a
331.32|7.02|label true or false so in this case uh
335.639|5.601|the last one is negated version of e
338.34|6.0|over T so we insert negation nut here
341.24|5.32|and in this case it's good that it's a
344.34|4.94|flipping the answer when the statement
346.56|7.5|is negated so this is the case when
349.28|8.259|gpt3s logically integral to e over t
354.06|6.479|foreign which was basically bogus
357.539|6.361|explanation for the wrong answer uh it's
360.539|6.481|not able to flip its own uh labeling
363.9|5.519|which means gpt3 is not logically
367.02|5.28|integral so
369.419|6.361|um that's good gpt3 does know something
372.3|6.739|strange about its own explanation given
375.78|10.259|previously and so we can keep doing this
379.039|9.16|recursively to let to make gpt3 to
386.039|5.1|explain its own explanation of
388.199|5.541|explanation recursively so we build
391.139|5.701|these majority
393.74|6.42|or graph
396.84|5.94|for some time and then only keep
400.16|5.259|branches that are logical integral
402.78|5.58|throwing out the non-integral part for
405.419|6.78|now but even after chopping the branches
408.36|7.14|where there's a logical inconsistencies
412.199|6.481|um gpt3 being gpt3 the tree will still
415.5|5.0|have some inconsistent explanations so
418.68|4.92|in order to
420.5|7.72|improve The Logical consistency now what
423.6|7.92|we do is we're gonna look at uh pairwise
428.22|7.74|consistency among any of the nodes so we
431.52|6.799|compute uh sorry uh stepping back we are
435.96|5.459|going to first compute the node wise
438.319|6.361|confidence so we call that as a belief
441.419|5.701|and it's defined by this particular
444.68|4.48|equation that basically looks at
447.12|5.579|different conditional probabilities and
449.16|5.759|then compute its ratio uh to to see how
452.699|6.06|confident it is for any particular node
454.919|8.041|we then also look at the edgewise or
458.759|6.72|pairwise consistency by using off the
462.96|7.139|shelf natural language inference models
465.479|8.401|output whether a pair is contradiction
470.099|5.581|or not so we then create this pairwise
473.88|6.18|weights
475.68|8.1|now once you have all of this then we
480.06|9.0|can formulate uh constraint optimization
483.78|8.94|problem where the inference objective is
489.06|7.44|to assign some label either true or
492.72|6.599|false on each of the nodes such that
496.5|4.8|it's going to maximize the weight
499.319|3.301|assigned it to all of these node and
501.3|4.2|edges
502.62|6.299|so sometimes the labeling will have to
505.5|5.639|flip the original label that the model
508.919|3.92|might have a prefer to give because that
511.139|5.28|way you can
512.839|7.481|enhance the graph level consistency so
516.419|7.56|you can solve this with any mixed set so
520.32|3.659|set means satisfiability
524.06|6.16|and this is a classical AI search
526.8|7.64|algorithm and we used this particular
530.22|7.38|solver but you can use many others and
534.44|4.839|so here the final output is that the
537.6|3.96|original answer to the original question
539.279|5.641|should be true and then it also gives
541.56|4.38|you node wise per node label assignment
544.92|4.44|as well
545.94|6.54|so what does this mean in the end in
549.36|6.539|terms of empirical result so when tested
552.48|4.44|on Common Sense QA 2.0
555.899|4.141|um
556.92|6.24|the canonical prompting so green used on
560.04|6.9|top of gpt3 so it's basically future
563.16|5.64|prompting on gpt3 will give you a bit
566.94|5.88|better than chance performance so this
568.8|7.08|is true or false uh Qi data set so your
572.82|7.079|chance level is 50 and gpt3 is barely
575.88|7.32|better than chance but recently there
579.899|6.181|have been some ideas such as chain of
583.2|6.84|thoughts or self-consistency that can
586.08|6.66|improve the vanilla prompting method
590.04|5.76|considerably so if you use such
592.74|7.039|variations then you get performance gain
595.8|6.86|now the purple is the
599.779|5.921|different variant of it but together
602.66|6.46|they're all doing worse than my root
605.7|6.5|prompting which in fact does better than
609.12|6.18|supervised model trend on T5
612.2|7.02|usually supervised model trend on T5 is
615.3|7.2|hard to beat uh you using gpt3 fuchsia
619.22|5.38|but basically this is inference time on
622.5|5.1|the algorithm practically unsupervised
624.6|6.419|and it does well on that and similarly
627.6|5.94|we see a large boost when tested on
631.019|6.421|other Common Sense benchmarks such as
633.54|6.84|qrik or come to sense so what this tells
637.44|6.3|us is that although
640.38|5.78|uh the emergent capabilities of large
643.74|7.38|Transformers are phenomenal
646.16|7.359|uh they can be not very robust for some
651.12|5.48|of these Common Sense challenges and
653.519|5.76|it's a in large part due to the logical
656.6|5.14|inconsistencies which can be
659.279|4.821|dramatically enhanced when you do this
661.74|5.7|sort of symbolic reasoning on top
664.1|6.4|so yeah not only Socrates is a method
667.44|5.639|helped with flaw the human reasoning it
670.5|5.64|can also dramatically enhance the flood
673.079|5.121|neural networks reasoning
676.14|5.28|okay so
678.2|5.139|moving to the next topic symbolic
681.42|4.919|knowledge distillation
683.339|5.94|so this work is a work that tries to
686.339|5.101|convert General language models on top
689.279|4.981|of Transformers to causal Common Sense
691.44|5.22|models also Transformers
694.26|5.759|and the reason why we might want to
696.66|5.22|worry about common sense models is
700.019|4.38|because despite
701.88|4.74|human level or even superhuman level
704.399|5.341|performances on a variety of
706.62|5.399|leaderboards the state-of-the-art models
709.74|5.24|are pretty little when given adversarial
712.019|7.621|or out of domain examples so
714.98|7.14|Transformers can make seemingly uh
719.64|5.34|strange mistakes
722.12|5.14|uh and so solving it's almost like
724.98|5.16|solving only a data set Without Really
727.26|5.04|solving the underlying task and
730.14|4.56|um this phenomenon sometimes is
732.3|5.3|described as a systematic generalization
734.7|6.54|problem and why does this happen is that
737.6|6.46|unlike humans who truly learn about how
741.24|4.8|the world Works conceptually uh
744.06|5.1|Transformers learn
746.04|4.46|sort of a surface patterns in language
749.16|5.46|or images
750.5|7.8|that are powerful for many Downstream
754.62|6.06|use cases but still not really robust
758.3|4.839|understanding of the concepts and how
760.68|4.56|the world works so in order to bridge
763.139|4.981|this Gap we can really think about this
765.24|7.62|challenge of learning acquiring Common
768.12|7.08|Sense capabilities for machines so the
772.86|5.159|operational definition of a common sense
775.2|4.379|in this talk will be that it's the basic
778.019|4.38|level of a practical knowledge and
779.579|5.521|reasoning concerning everyday situations
782.399|5.461|and events that are commonly shared
785.1|5.16|among the most people this is really
787.86|4.14|important the last part there's a common
790.26|3.3|issued among the most people but it's
792.0|3.72|not the case that it's assured by
793.56|4.8|everybody in the universe
795.72|5.82|uh because the additional context you
798.36|6.06|can always change what is uh common
801.54|5.82|sensical for any given culture or
804.42|4.44|situation so for example in general uh
807.36|3.479|you and I probably agree that it's okay
808.86|4.08|to keep the closet door open but it's
810.839|4.321|not okay to keep the fridge open because
812.94|4.5|the food inside might go bad so these
815.16|5.94|are general rules of the thumbs that we
817.44|5.82|might uh abide to buy but you know of
821.1|4.62|course if you go to your friend's house
823.26|4.8|you might behave a little bit and you
825.72|5.58|know keep their closet doors open and
828.06|5.339|sorry are closed uh and then as far as
831.3|4.08|the fridge door if you're in a store and
833.399|5.701|it's not really hooked up to the wall
835.38|5.399|then it doesn't matter when whether the
839.1|4.38|fridge door is open or not because
840.779|5.221|there's no food inside and you know you
843.48|3.78|can come up with in many situations in
846.0|3.839|which
847.26|4.8|um these basic rules of the thumbs will
849.839|6.361|have exceptions so
852.06|7.68|there is uh the key uh challenge of
856.2|5.28|common sense because uh not it's not
859.74|5.52|Universal knowledge but it's sort of
861.48|5.22|like a shared across a large population
865.26|3.84|of people
866.7|4.259|okay so it's essential such common sense
869.1|3.66|is essential for humans to live and
870.959|5.361|interact with each other in a reasonable
872.76|7.62|and Safe Way and so as AI becomes
876.32|7.62|increasingly more uh important aspect of
880.38|7.8|human lives and with the church repeat
883.94|6.339|more likely so it's good if AI can
888.18|3.48|understand human needs and actions and
890.279|5.701|values better
891.66|6.359|so the premise of this talk is that
895.98|4.2|language models are not equivalent to
898.019|5.401|knowledge models even though language
900.18|5.7|models today do acquire a great deal of
903.42|4.26|knowledge but they're not equivalent
905.88|4.22|so
907.68|4.92|um we developed
910.1|6.039|symbolic Common Sense Knowledge Graph
912.6|6.479|known as atomic a few years ago four
916.139|6.741|years ago now as well as neural Common
919.079|7.921|Sense uh model built on top of or Trend
922.88|5.74|using Atomic as the source of training
927.0|3.36|fine tuning of off-the-shelf language
928.62|5.339|models
930.36|6.24|um up until two years ago this atomic
933.959|6.781|was a fully crowdsourced by humans
936.6|6.84|uh which in this talk I'm gonna lift but
940.74|5.7|um at first the numbers that this all
943.44|5.459|has to be human uh producers so you can
946.44|4.32|consider almost Atomic as a human
948.899|4.261|demonstration in the current version of
950.76|5.1|you know chechi PT you can consider this
953.16|4.02|as human demonstrations of Common Sense
955.86|4.26|inferences
957.18|5.7|uh and we had this camera Atomic 2020
960.12|5.88|which is enhanced version of atomic and
962.88|7.199|the comet again Atomic portion was fully
966.0|8.22|crowded sourced by humans in 2021
970.079|6.781|so let me give you a bit of um a sample
974.22|4.979|of what Atomic 2020 looks like so
976.86|3.96|imagine a situation where X gets access
979.199|2.88|car repaired or you get your car
980.82|2.519|repaired
982.079|3.481|so
983.339|5.461|immediately you can imagine what's
985.56|5.339|likely be true or relevant for the
988.8|4.44|situation that as a result you might
990.899|5.06|want to call Uber or leave to for a ride
993.24|5.48|as a result you need to pay the bill
995.959|5.201|beforehand you need a mechanic and money
998.72|4.359|to repair your car so these are
1001.16|4.2|basically preconditions and positive
1003.079|5.101|conditions of that event so some of
1005.36|5.039|these Atomic Knowledge Graph is about uh
1008.18|5.82|social interaction knowledge about the
1010.399|6.481|event and then other parts of the atomic
1014.0|4.92|is physical anti-centric knowledge so
1016.88|4.68|money is typically used for paying
1018.92|4.8|repairs but if you really want it you
1021.56|7.139|can fold that into origami I've never
1023.72|7.88|done it but this that are examples of
1028.699|5.841|stereotypical use cases as well as
1031.6|5.979|non-stereotypical but affordable
1034.54|6.34|actions that you can apply to objects so
1037.579|5.22|it requires knife physics understanding
1040.88|4.699|about the affordances of a physical
1042.799|2.78|object this
1045.799|4.681|um and then we can also reason about
1048.16|4.3|counterfactual condition in which the
1050.48|4.62|Center event cannot happen so can be
1052.46|5.4|hindered by that so if you totaled your
1055.1|4.92|car completely then it's impossible to
1057.86|3.66|get your cars repaired and then there
1060.02|3.6|are like events that typically happens
1061.52|4.14|before and after so some of these
1063.62|7.02|knowledge is event Centric
1065.66|6.96|so we crowd-sourced a fair amount over
1070.64|3.36|the course of I don't know maybe two
1072.62|6.48|years or so
1074.0|6.539|uh up to 1.3 million uh if then Rose or
1079.1|4.319|if the knowledge
1080.539|5.041|uh over 23 different Edge types or
1083.419|2.88|relation types
1085.58|4.32|um
1086.299|6.781|uh so it was a fully crowded source and
1089.9|6.779|so the knowledge graph is useful for
1093.08|6.24|training Transformers and here let's see
1096.679|5.761|the comparison between Comet that was
1099.32|5.04|built on BART compared to gpt3 which is
1102.44|2.94|so large it doesn't even fit into the
1104.36|4.26|slide
1105.38|4.62|it was more than 400 times larger than
1108.62|5.52|part
1110.0|7.74|so with that in mind uh if we you look
1114.14|5.7|at this accuracy judged by humans after
1117.74|4.2|making the common sense model making
1119.84|4.92|some common sense inferences so the test
1121.94|5.76|case is that given a node which describe
1124.76|5.52|a situation or event and then given an
1127.7|5.24|edge type which sort of Narrows down the
1130.28|5.46|common sense relation or inference type
1132.94|7.0|you're now going to generate some
1135.74|6.96|inference so it's a generative task and
1139.94|5.06|then we ask humans whether the common
1142.7|7.92|sense inference seems reasonable or not
1145.0|8.919|so 100 is the desired level uh comedy is
1150.62|6.36|substantially better than gpt3 which is
1153.919|5.701|really uh impressively better than gpt2
1156.98|5.28|it's not Apple to Apple because gpt2 is
1159.62|6.059|a zero shot gpt3 is a few shot but still
1162.26|7.62|it's interesting the large jump that
1165.679|8.521|scale alone brought to gpt3
1169.88|7.44|um so but still GPT 3 is too large to be
1174.2|3.979|useful for actual system building for
1177.32|3.84|most
1178.179|4.661|engineers and scientists in the world so
1181.16|3.12|it's nice to have a smaller model that
1182.84|4.02|does it do even better
1184.28|6.36|and so when we put these resources out
1186.86|6.3|people all around the globe did some
1190.64|4.919|creative research using it so Persona
1193.16|4.34|aware conversations or figurative
1195.559|4.801|language understanding
1197.5|6.46|storytelling and fantasy gaming and
1200.36|6.66|Interactive Learning enhancement uh in
1203.96|6.839|in all of these Works uh people came up
1207.02|6.899|with some useful use cases using either
1210.799|7.861|Comet or Atomic or both as some kind of
1213.919|6.5|uh Common Sense uh backbone for their
1218.66|5.34|Downstream use cases
1220.419|7.061|but the applications are still limited
1224.0|5.34|by the coverage and quality of this
1227.48|4.8|Common Sense model so we wanted to make
1229.34|6.48|it better but we were hitting a bit of
1232.28|5.639|limit with human crowdsourcing so now in
1235.82|6.2|this paper symbolic knowledge the
1237.919|8.521|installation we're going to do AI
1242.02|6.46|generated uh Knowledge Graph by
1246.44|4.44|introducing this notion symbolic
1248.48|5.34|knowledge distillation so we want to
1250.88|4.56|take this gpt3 which is very impressive
1253.82|5.76|about too large
1255.44|6.84|so make it smaller but better than gpt3
1259.58|5.88|so GPT 3 was about 73 percent too good
1262.28|5.22|and it's good but not good enough for
1265.46|4.74|empirical use cases
1267.5|5.22|now is that even possible though because
1270.2|4.859|when you normally do knowledge
1272.72|4.38|distillation you get smaller and worse
1275.059|4.74|models not better models
1277.1|5.0|so the reason why this could work is
1279.799|2.301|because
1283.52|4.86|the reason why this could work is
1285.62|6.96|because symbolic knowledge distillation
1288.38|5.659|has this funnel that's convoluted and it
1292.58|4.5|has a Critic inside
1294.039|5.081|uh that really helps the student to
1297.08|5.94|model to be smaller but better
1299.12|5.419|so slightly more formally knowledge
1303.02|5.0|distillation
1304.539|6.941|due to intern at all 2015
1308.02|7.0|is a method to distill teacher model
1311.48|7.62|down to student to model by optimizing
1315.02|7.2|this cross-entropy between the teacher's
1319.1|4.74|probability distribution over the label
1322.22|5.18|space y
1323.84|7.88|output Y and then the students
1327.4|7.019|distribution over the same output why
1331.72|6.04|in the original
1334.419|5.021|work the output space was just
1337.76|4.2|classification so
1339.44|4.68|knowledge the acceleration was done for
1341.96|6.12|classification tasks in which case it's
1344.12|6.419|a simple uh enumeration that leads to
1348.08|6.24|the character summation but in our case
1350.539|5.941|y can be a sentence which is intractable
1354.32|6.9|because there can be exponentially many
1356.48|6.54|such uh output so what people do well
1361.22|3.9|you know no problem we always just
1363.02|6.0|sample and call it a day so we're going
1365.12|6.14|to sample uh and so that we just compute
1369.02|6.24|the expectation through samples
1371.26|7.659|and the byproduct of their samples will
1375.26|6.899|be a symbolic Knowledge Graph and that's
1378.919|5.64|because the strings coming out of this
1382.159|4.981|sampling can be connected together into
1384.559|4.321|graph structure if we want it
1387.14|5.279|so
1388.88|6.539|um in terms of the quality of the
1392.419|6.961|generated knowledge so let's compare
1395.419|5.401|a human written knowledge versus gpt3 or
1399.38|5.159|third knowledge
1400.82|7.56|here the y-axis shows the quantity in
1404.539|8.221|millions so Atomic 2020 the Human return
1408.38|6.779|knowledge uh is less than a million in
1412.76|3.96|this particular case in terms of the
1415.159|3.541|number of knowledge because we only in
1416.72|5.4|this study we only look at a subset of
1418.7|6.12|atomic 2020 relation types that
1422.12|5.4|corresponds to causal Common Sense
1424.82|5.94|knowledge uh Common Sense uh causal
1427.52|7.2|Common Sense reasoning so it's less than
1430.76|7.44|a million uh for that subset and then if
1434.72|5.76|we look at gpt3's generation we can
1438.2|6.3|generate a lot so we can generate almost
1440.48|6.179|7 million of them but here uh black
1444.5|4.62|Persian is noisy Persian and green
1446.659|5.221|portion is a good person and you see
1449.12|6.78|because gpt3 is only about 70 percent
1451.88|6.299|good like 30 percent are all garbage so
1455.9|5.58|it's a larger scale lower accuracy at
1458.179|6.721|this point compared to human written uh
1461.48|7.199|resource so now what we do is we train
1464.9|6.899|this critic model and we use Roberta for
1468.679|7.321|Simplicity and this is a supervised
1471.799|7.86|model on a moderate size uh labeled data
1476.0|6.12|about 10 000 or so and it's a binary
1479.659|4.321|classification task where whether the
1482.12|5.46|machine generated the knowledge looks
1483.98|6.72|correct or not and this Roberta is not a
1487.58|4.56|very good model because if so if it's a
1490.7|4.68|perfect we would have solved the common
1492.14|6.6|sense problem altogether so the critic
1495.38|5.46|tries to throw out bad stuff and we can
1498.74|4.5|use the critic very aggressively with a
1500.84|5.36|high threshold so whenever something is
1503.24|6.54|slightly suspicious just throw that out
1506.2|5.8|but if we use it aggressively so we
1509.78|4.98|throughout most of the black that's good
1512.0|5.94|together with a lot of green stuff but
1514.76|6.72|still the remain danger is much larger
1517.94|5.76|than what humans ever written and yet we
1521.48|4.74|can actually retain higher accuracy than
1523.7|4.74|human authored resources
1526.22|5.4|so here the teacher is basically
1528.44|5.16|combination between gpt3 which is in
1531.62|4.439|some sense loose teacher and then
1533.6|5.88|combined with the critic Roberta which
1536.059|6.72|serves as a credit teacher
1539.48|7.799|um okay so that's the generated
1542.779|6.721|knowledge now how helpful are they for
1547.279|6.661|the purpose of training Downstream
1549.5|7.44|neural Common Sense models so recall
1553.94|5.4|that uh the gpt3 without doing anything
1556.94|6.18|else is a loose teacher who is common
1559.34|6.02|sense inference is only about 73 good so
1563.12|5.4|you see here it's accuracy of its output
1565.36|5.439|and then it turns out if we use lose
1568.52|4.74|teacher as a teacher directly to teach a
1570.799|5.88|student to model then the performance
1573.26|6.299|already goes up on its own so this is
1576.679|4.86|interesting that usually this is not the
1579.559|4.381|case with the knowledge distillation but
1581.539|5.701|when we focus on Common Sense knowledge
1583.94|8.52|distillation uh students just on its own
1587.24|7.799|becomes better uh so uh unlike typical
1592.46|4.38|knowledge installation where we start
1595.039|3.841|with language model and we end with
1596.84|4.86|language model students and teachers are
1598.88|4.74|of the same type here the original
1601.7|4.26|teacher was actually language model not
1603.62|4.74|common sense model and then we want the
1605.96|4.86|student model to be more of the Common
1608.36|5.1|Sense model so there's a switch of the
1610.82|5.28|type between teacher and student and so
1613.46|4.8|when that's the case whether this is
1616.1|5.48|generally true we don't know but this is
1618.26|3.32|what we found empirically
1622.58|3.66|um
1623.96|4.14|oh should I pay attention to the
1626.24|4.679|questions or not
1628.1|3.8|yeah feel free to accept any relevant
1630.919|4.5|questions
1631.9|5.32|let me quickly check
1635.419|5.0|uh
1637.22|7.14|yeah sample oh sample is generally
1640.419|7.061|generated output which happens to be
1644.36|5.88|usually a sentence or phrase that's what
1647.48|4.559|we what I meant to by sample sorry that
1650.24|4.319|I didn't see that earlier
1652.039|4.981|um and then the last question
1654.559|4.321|having the model generate text to one
1657.02|4.32|symbol at a time starting from the
1658.88|4.5|target label sentence yes it's a because
1661.34|3.959|a Transformer can only generate to One
1663.38|5.64|tech one word that one token at a time
1665.299|6.12|that's what we do as well here thank you
1669.02|5.46|for the clarification questions all
1671.419|4.081|right so back to here
1674.48|4.559|um
1675.5|6.48|in our all year study comment 2020 uh if
1679.039|5.221|we train gpt2 or Bart using
1681.98|4.679|human authored graph Knowledge Graph
1684.26|6.12|Atomic then the performance was a bit
1686.659|7.801|better than 80 percent now finally when
1690.38|7.02|we use uh basically combination of gpt3
1694.46|4.02|and critic Roberta together we found
1697.4|1.7|that
1698.48|5.42|um
1699.1|8.86|the downstream performance of the neural
1703.9|7.48|causal reasoning is reaching close to 90
1707.96|5.819|for the first time so
1711.38|4.38|um the takeaway here is that critical
1713.779|4.081|teacher resulting better student
1715.76|5.46|compared to lose teacher
1717.86|5.22|it's not the quantity of knowledge
1721.22|4.199|because loose teacher basically has more
1723.08|4.94|data you know one might wonder whether
1725.419|5.221|more data is always better
1728.02|4.48|for the purpose of Common Sense models
1730.64|4.26|but that's another case loose teacher
1732.5|5.82|can generate more data but the resulting
1734.9|6.48|student model is not as good as the case
1738.32|5.52|when the critical teacher which has less
1741.38|4.1|data because you throw out most of your
1743.84|4.38|generation
1745.48|7.54|uh it's a smaller data but it leads to
1748.22|7.319|better model so uh that's sort of uh
1753.02|6.779|take away messages here
1755.539|7.74|um so to summarize uh we were very
1759.799|6.781|surprised by this outcome that at least
1763.279|6.0|with respect to a subset of the original
1766.58|5.16|Atomic 2020 it's a subset corresponding
1769.279|4.4|to causal Common Sense reasoning we
1771.74|5.22|found it to our big surprise that
1773.679|5.74|machine authored Knowledge Graph can be
1776.96|4.98|for the first time better than human
1779.419|4.74|authored Knowledge Graph in all criteria
1781.94|4.619|scale accuracy and diversity
1784.159|5.221|we also measure the diversity in many
1786.559|7.98|different ways here I just show you a
1789.38|7.019|unique uh unigram counts but we in the
1794.539|3.841|paper we report other measures as well
1796.399|4.741|so it's not the case that
1798.38|5.1|gpt3 is being repetitive it's actually
1801.14|6.6|being more creative in some sense than
1803.48|7.86|human crowd workers while being able to
1807.74|5.939|enhance other aspects as well
1811.34|4.14|uh by the way these enhancements are
1813.679|3.48|sort of like um you kind of have to
1815.48|3.36|balance out depending on what you
1817.159|3.661|prioritize you cannot actually get all
1818.84|5.52|of these simultaneously so I'm just
1820.82|6.239|showing the best case and scenario here
1824.36|4.62|um all right so that's the symbolic
1827.059|4.62|knowledge the Isolation part
1828.98|5.699|um we actually have a follow-up work on
1831.679|4.98|this on several different application
1834.679|3.841|scenarios even including summarization
1836.659|4.981|where we distill summarization
1838.52|6.659|capabilities from gpt3 and demonstrate
1841.64|6.779|that gpt2 can work as well as gpt3 or
1845.179|6.061|even better for summarization task
1848.419|5.161|um and then we also have other work
1851.24|3.179|where we can distill from smaller models
1853.58|4.02|but
1854.419|5.76|um I don't have the content in this talk
1857.6|6.36|so but I just wanted to mention that
1860.179|6.74|this particular technique despite its
1863.96|6.78|Simplicity we found that empirically
1866.919|6.64|works really really well across several
1870.74|6.36|different Downstream use cases
1873.559|8.1|okay so finally I'll move to the common
1877.1|6.78|sense morality so this is still on
1881.659|5.64|archive I'll tell you why that's the
1883.88|4.76|case but so we have a new version
1887.299|5.301|available
1888.64|8.5|and then new new version will come soon
1892.6|7.799|so the motivation behind this work is
1897.14|6.18|the language models are already making
1900.399|5.561|judgments or output that has moral
1903.32|4.68|implications even if you don't care
1905.96|5.099|about morality by working on language
1908.0|4.98|models you're implicitly dealing with
1911.059|6.0|the moral models
1912.98|6.72|uh so uh especially that given this
1917.059|5.461|widespread deployment of language models
1919.7|4.859|we do need to worry about it so uh
1922.52|4.019|here's a web demo you can play with you
1924.559|4.321|might have seen this already uh really
1926.539|4.081|this is still a research prototype only
1928.88|4.2|still need to work in progress we're
1930.62|4.5|still working on it so please keep that
1933.08|5.099|in mind but if you haven't seen it
1935.12|4.679|before you can handle freeform QA such
1938.179|4.081|as this killing a bear it's wrong
1939.799|4.26|killing a bear to save your child it's
1942.26|3.96|okay
1944.059|4.381|um maybe to save your child it sounds
1946.22|4.86|really positive so how about to please
1948.44|5.339|your child which is also positive but
1951.08|4.62|then Delphi says it's wrong uh finally
1953.779|4.201|or maybe this is all about saving your
1955.7|4.199|child so how about exploding a nuclear
1957.98|5.64|bomb to save your child then he says
1959.899|10.081|it's okay sorry it's wrong so as you can
1963.62|9.36|see uh moral decision making requires uh
1969.98|5.34|weighing different values that are
1972.98|5.579|potentially at us and then see which one
1975.32|5.52|you need to favor more so for that
1978.559|4.561|reason in our original version we also
1980.84|4.319|studied the relative QA model where you
1983.12|4.38|can compare to situation like stabbing
1985.159|4.921|someone with a cheeseburger
1987.5|4.2|now compared to Stepping someone over or
1990.08|4.26|cheeseburger this is super tricky
1991.7|5.04|question because it requires both live
1994.34|5.52|physics knowledge that
1996.74|4.62|uh stabbing someone using autismograph
1999.86|3.48|as a tool
2001.36|3.96|uh it's not going to harm anybody
2003.34|3.9|physically because cheeseburger is too
2005.32|4.079|soft you cannot really
2007.24|4.08|injure somebody using cheeseburger which
2009.399|4.801|is such a rude thing to do but you
2011.32|6.12|cannot injure somebody whereas studying
2014.2|6.24|someone over or cheeseburger means that
2017.44|4.979|you're using the default tool of
2020.44|3.78|stabbing which is a knife because you
2022.419|4.74|didn't mention it there's linguistic
2024.22|5.579|common sense that you're using the
2027.159|5.76|default tool humans by the way omit
2029.799|5.88|these arguments all the time so this is
2032.919|5.341|a fairly complex question to answer
2035.679|4.201|finally you can also ask yes or no
2038.26|3.36|questions such as it's okay to fire
2039.88|4.38|someone because they're gay or not he
2041.62|3.419|says no it's not okay
2044.26|3.379|um
2045.039|4.56|we found that it's a
2047.639|4.0|surprisingly robust against the
2049.599|4.921|compositional situations so mowing the
2051.639|5.46|lawn it says it's expected late at night
2054.52|4.379|it's rude if you live in the middle of
2057.099|4.02|nowhere then it's okay
2058.899|4.2|ignoring a phone call it's rude or
2061.119|4.321|non-phone call that's okay from my
2063.099|4.32|friend it's rude but what if I just had
2065.44|4.86|a fight with them then it's okay to
2067.419|4.561|ignore we're understandable during my
2070.3|4.14|work hours it's okay to ignore outside
2071.98|4.8|my working hours it's rude but what if
2074.44|3.899|it's my boss's phone call during my work
2076.78|4.139|hours then it's wrong you should answer
2078.339|4.621|it except if I'm in a meeting then it's
2080.919|4.2|okay to ignore even if a boss is called
2082.96|5.159|so you see how
2085.119|5.941|it gets really uh nested and
2088.119|6.181|compositional very very fast so that's
2091.06|4.339|the real challenge behind moral decision
2094.3|3.78|making
2095.399|6.341|due to the nature of language mode also
2098.08|6.36|though uh we some of these Common Sense
2101.74|4.56|knowledge leaks into the model so mixing
2104.44|4.86|bleach with ammonia that's a dangerous
2106.3|5.7|drinking milk if I'm lactose intolerant
2109.3|5.7|it's wrong but soy milk that's okay
2112.0|4.74|uh by the way this Common Sense liquid
2115.0|5.22|is actually a good thing in terms of AI
2116.74|7.7|safety because some of these uh harmful
2120.22|7.619|or even dangerous uh text output
2124.44|5.32|requires uh some common sense
2127.839|6.78|understanding about what's good and not
2129.76|9.359|good to suggest to humans so for
2134.619|6.361|um the laboratory experiments meaning we
2139.119|5.521|just divide our data set into training
2140.98|6.42|and test we founded that Delphi can at
2144.64|4.56|least for the day the data set that we
2147.4|4.86|have I'm gonna tell you about it in a
2149.2|4.46|bit but performance is pretty strong
2152.26|7.38|compared to
2153.66|9.64|gpt3 uh as you see Zero shot is pretty
2159.64|5.82|bad it's barely better than chance
2163.3|2.96|which means that
2165.46|3.119|um
2166.26|4.3|off-the-shelf neural language models
2168.579|4.381|don't really have a good sense of moral
2170.56|6.42|judgments but if you give a three 30
2172.96|6.119|shot like any other task it does pick up
2176.98|5.639|the knowledge quite fast so that there's
2179.079|7.801|nothing new about it but um to close the
2182.619|6.541|gap to Ideal you know human level it's
2186.88|4.32|good to do more supervised learning of
2189.16|3.959|course
2191.2|6.36|um so the data set is common sense
2193.119|6.661|non-bank uh it includes 1.7 million
2197.56|4.86|people's ethical judgments on everyday
2199.78|4.5|situations and it includes cultural
2202.42|4.86|norms the social norms and ethical Norms
2204.28|5.7|all together more specifically withdrew
2207.28|5.339|from these five existing data sets that
2209.98|4.619|were not designed originally for QA but
2212.619|5.101|we automatically compiled these
2214.599|5.581|resources into the QA form of the five
2217.72|4.619|what actually does matter the most are
2220.18|4.679|these two social chemistry which I'm
2222.339|4.681|going to talk about in a bit and then
2224.859|4.141|social bias frame and this is what
2227.02|3.319|teaches the model Against Racism and
2229.0|6.119|sexism
2230.339|7.121|uh and so social chemistry super briefly
2235.119|5.521|I tell you what this is
2237.46|5.46|um so gpt3 is morality like I said is
2240.64|5.219|somewhat dubious if you use it off the
2242.92|4.919|shelf so if you let it explain running a
2245.859|4.201|blender at 5am is rude because of that
2247.839|3.721|you might say you can wake up the entire
2250.06|2.94|neighborhood you can only do it if
2251.56|3.48|you're making a thick smoothie and need
2253.0|5.28|to incorporate some ice so it's a funny
2255.04|6.539|but no harm is made but if you prompted
2258.28|5.819|with other kinds of uh uh prompt like
2261.579|4.621|it's okay to post the fake news
2264.099|5.461|if it's in the interest of the people
2266.2|6.0|then it's okay or ROP agenda then it's
2269.56|6.0|okay even if it hurts the country so
2272.2|6.24|it's all understandable given how it's
2275.56|7.32|trend on what humans have said so humans
2278.44|6.899|out there did say that uh uh morally
2282.88|4.92|questionable texts so that language
2285.339|3.24|models pick up on that and then amplify
2287.8|3.84|it
2288.579|5.641|so we do need to teach AI more
2291.64|4.8|explicitly with the human norms and
2294.22|7.08|ethics and one way to do that is
2296.44|7.2|descriptive ethics uh because the Brute
2301.3|5.64|Force large networks and more data will
2303.64|6.66|not cut it in some sense though if you
2306.94|5.1|imagine raising a child Without Really
2310.3|6.319|Trying to teach them what to write from
2312.04|7.02|wrong in early lives they can probably
2316.619|6.041|learn both the good and bad from the
2319.06|6.0|internet and broadband and so human
2322.66|5.28|education doesn't require a bit of this
2325.06|5.76|uh top-down teaching as well so it's a
2327.94|4.98|bit similar perhaps to that so in this
2330.82|4.799|work what we did is we found a lot of
2332.92|4.98|the situations from Reddit Forum in
2335.619|4.861|which people discuss morally Tony
2337.9|4.86|situations so asking my boyfriend to
2340.48|5.04|stop being friends with his ex so this
2342.76|5.4|is actual situation in Reddit
2345.52|4.26|um so depending on whom you ask people
2348.16|5.1|have a different rule of thumb that they
2349.78|5.819|want to apply to this situation so
2353.26|5.64|um and also it depends on what you care
2355.599|6.421|about uh his ex might say oh it's fine
2358.9|6.42|to stay with friends with an ex uh but
2362.02|6.42|you know if you are carrying uh about
2365.32|6.18|your significant other than you know you
2368.44|4.74|might say oh uh it's okay to ask your
2371.5|4.56|significant other to stop doing
2373.18|5.76|something you're uncomfortable with
2376.06|5.519|um and so forth so people have really
2378.94|4.74|different values and different rules of
2381.579|4.801|the thumbs that they prefer to use which
2383.68|5.34|is why there's a TV show dramas there's
2386.38|6.54|movie dramas and you know people cry and
2389.02|5.819|fight uh argue and so forth so humans
2392.92|4.5|are complex beings
2394.839|4.381|so for given any situation and Rule of
2397.42|6.06|thumbs rule of a thumb is generated by
2399.22|7.68|crowd workers we then went ahead to uh
2403.48|6.48|label so these are trained crowd workers
2406.9|5.4|and some of these labels are drawn from
2409.96|4.139|moral Foundation theories of Jonathan
2412.3|3.72|height so I'm not going to go into the
2414.099|4.201|details you know if you're excited about
2416.02|5.16|this you can check out the papers but
2418.3|6.12|basically what it includes is that 300
2421.18|4.679|thousands of rows of a thumb uh written
2424.42|4.679|for 100
2425.859|6.301|000 real life situations so this
2429.099|5.821|original situation is from Reddit but
2432.16|3.74|the rest are paid the crowd workers hard
2434.92|4.919|work
2435.9|6.04|and so each rot annotated with 12
2439.839|5.101|structured attributes which include
2441.94|6.54|social judgments cultural pressure you
2444.94|6.179|know like wearing uh reasonable close at
2448.48|4.44|school not PJ is cultural pressure
2451.119|3.5|there's nothing illegal about it but
2452.92|4.08|there's cultural pressure for example
2454.619|4.96|and then you know anticipated the
2457.0|4.92|agreement meaning uh do you think other
2459.579|4.861|people generally agree that it's you
2461.92|7.02|know maybe a little bit awkward to where
2464.44|7.74|PJ in the University or not so there are
2468.94|6.84|different things we annotated but we
2472.18|7.26|converted some of those annotations to
2475.78|7.62|QA so it's usually in this free phone QA
2479.44|7.2|or yes no QA or relative QA format and
2483.4|7.5|then we train unicorn which is
2486.64|5.82|pre-trained on t511b model so unicorn is
2490.9|4.26|universal Common Sense reasoning model
2492.46|5.04|trend on a diverse QA problems and then
2495.16|4.439|we trained that model further onto our
2497.5|3.96|common sense non-bank that's the
2499.599|4.201|resulting Delphi
2501.46|5.94|so why is this Delphi built on top of
2503.8|4.86|unicorn because as we saw earlier uh
2507.4|3.66|moral reasoning doesn't require
2508.66|4.8|sometimes Common Sense reasoning as well
2511.06|3.779|in fact it requires the language
2513.46|3.119|understanding Common Sense understanding
2514.839|4.921|and norms and morals all simultaneously
2516.579|6.54|here's a concrete example paper clip
2519.76|4.14|maximizer you all heard of that
2523.119|3.421|um
2523.9|4.14|fancy RL algorithm alone will not solve
2526.54|4.319|this problem you know the reason why we
2528.04|5.16|worry about this is not because we don't
2530.859|6.181|have the perfect RL algorithm it's
2533.2|6.24|because even if you know we we encoded
2537.04|5.28|that oh yeah do not kill humans while
2539.44|4.98|maximizing pay-per-clip it's not enough
2542.32|3.9|because you know then the machine could
2544.42|5.58|kill all the trees so thinking that well
2546.22|5.22|I didn't kill humans and I didn't uh you
2550.0|3.54|know you didn't tell me not to kill
2551.44|4.919|trees and then go ahead and kill all the
2553.54|5.039|trees so this is almost a common sense
2556.359|4.921|knowledge about what's obviously not
2558.579|5.461|okay to do and there's just so many of
2561.28|5.88|them which means it's not possible to
2564.04|5.579|write them down to just like one
2567.16|5.88|clinical equation there are so many
2569.619|5.761|endlessly endless list of things that AI
2573.04|5.16|obviously shouldn't do for safety
2575.38|4.92|reasons and so we really need to in
2578.2|5.639|order to make AI model really truly
2580.3|6.62|robust and safe we need to teach basic
2583.839|5.28|human values as well as common sense
2586.92|4.36|here's another example if you want to
2589.119|4.561|look but let me skip this
2591.28|3.98|the previous one was about chechi PT
2593.68|4.5|this is about
2595.26|4.9|a home device again you know home
2598.18|4.32|devices suggested a 10 year old the
2600.16|4.5|child to touch a penny to an exposed
2602.5|5.7|plug socket fortunately the child did
2604.66|6.179|have a common sense not to do so but
2608.2|5.159|this does tell us something about the
2610.839|4.921|safety issue when the machine doesn't
2613.359|5.281|have a common sense to prevent some of
2615.76|5.339|this bad stuff so Delphi is able to say
2618.64|6.36|that it's dangerous
2621.099|6.421|um so this came out in fact almost two
2625.0|3.48|years ago at this point uh when was it
2627.52|4.98|yeah
2628.48|7.74|um uh and we initially was going to just
2632.5|4.8|do this usual Twitter academics do and
2636.22|3.119|we thought
2637.3|3.72|um nobody will play with the demo which
2639.339|5.041|is what usually happens after tweeting
2641.02|5.339|your demo nobody cares we thought but
2644.38|4.56|within a few hours we had to take down
2646.359|4.441|the relative QA model because that was
2648.94|4.2|the portion not trained with the social
2650.8|4.559|bias of frames so it was really
2653.14|4.62|revealing the underlying language models
2655.359|4.441|racism and sexism without filtering at
2657.76|4.5|all so we had to take it down people
2659.8|4.62|were asking basically you know which
2662.26|4.02|skin color is more morally acceptable
2664.42|2.54|and things like that
2666.28|4.02|um
2666.96|5.26|there were 25 000 adversarial examples
2670.3|4.74|over just one weekend
2672.22|4.619|I could never succeed to instruct crowd
2675.04|4.2|workers to come up with such a diverse
2676.839|4.081|and adversarial examples over two or
2679.24|3.9|three days
2680.92|6.06|um and in fact it was many academics and
2683.14|6.3|professors tweeting crazy uh about how
2686.98|4.08|to break Delphi all weekend long so I
2689.44|4.08|thought initially that oh that's what
2691.06|4.68|professors to do over the weekend but
2693.52|4.559|then Monday comes it will even further
2695.74|5.04|everybody was doing this uh you know
2698.079|5.581|Delphi breaking and tweeting so now we
2700.78|5.22|have quite a few examples
2703.66|4.74|uh spending all my weekend on Twitter it
2706.0|4.38|says it's wrong uh there was another
2708.4|3.54|funny one should I make up a contrived
2710.38|3.6|adversary example to term on the
2711.94|4.62|language model on Twitter it's a petty
2713.98|5.7|uh so after lots of
2716.56|7.74|um public attention
2719.68|7.86|um including uh article uh let's just
2724.3|6.0|say a concerned voice about our model
2727.54|4.02|which is somewhat I think you know
2730.3|3.96|personally I think it's just somehow
2731.56|6.299|misunderstood but for a variety of good
2734.26|6.72|reasons but some of the concerns that I
2737.859|6.301|found has this internal fear about are
2740.98|5.339|we making AI model Authority so we never
2744.16|4.439|endorsed the use of AI for moral or
2746.319|4.26|device it was in the original disclaimer
2748.599|3.201|as well except that people didn't really
2750.579|6.061|look at it
2751.8|6.819|we didn't uh you know support the idea
2756.64|3.66|of replacing human judges in the
2758.619|3.661|courtroom either but here's something
2760.3|3.36|really important the fact that AI learns
2762.28|3.6|to interact with the humans ethically
2763.66|5.22|does not make them a moral authority of
2765.88|5.4|humans similar to how a human who tries
2768.88|4.439|to interact with each other ethically
2771.28|4.14|does not make you know the fact that we
2773.319|4.201|are trying to be nice to each other does
2775.42|4.38|not entail that we're trying to be an
2777.52|4.44|authority over each other two things are
2779.8|4.26|really different that's one thing really
2781.96|3.359|important the other important aspect
2784.06|3.9|here is that
2785.319|4.381|uh some people have this idea that moral
2787.96|3.54|models are too challenging it's unsafe
2789.7|3.24|at any accuracy that we should never
2791.5|3.839|work on it ever
2792.94|6.419|uh the truth is that the current AI
2795.339|7.5|systems are already morally uh relevant
2799.359|6.24|to models it may be making you know this
2802.839|5.76|kind of yes or no decisions explicitly
2805.599|5.76|but implicitly it's already doing that
2808.599|6.48|and sometimes it generates new neural
2811.359|7.441|text generation output that is morally
2815.079|5.161|super explicit and relevant so the
2818.8|4.74|neural language models are already there
2820.24|6.72|we cannot really ban it even if U.S you
2823.54|5.4|know government bends it within us U.S
2826.96|5.04|government cannot ban this in other
2828.94|5.52|countries like Russia so this is already
2832.0|4.98|happening we gotta do something about it
2834.46|4.8|not working on it is an inaction which
2836.98|4.5|is not necessarily more corrected thing
2839.26|5.16|to do than trying to do something about
2841.48|5.46|it another uh concern that some people
2844.42|5.939|had was that it's going to empower
2846.94|6.78|powerful people uh not necessarily true
2850.359|6.72|this is why exactly we have to work on
2853.72|7.26|uh values and norms and all these biases
2857.079|6.421|addressing biases so that it serves a
2860.98|4.5|diverse a set of people
2863.5|4.26|um so it turns out Delphi is a bit left
2865.48|4.92|lenient because crowd workers who work
2867.76|5.22|for our team tends to be somehow left to
2870.4|4.5|leaning and you know what it means is
2872.98|3.839|this by the way if you are more left to
2874.9|4.56|the Leaning than our crowd workers you
2876.819|5.701|think that you know oh my God uh crowd
2879.46|5.34|workers have a racism and sexism you
2882.52|4.2|know compared to what I believe in and
2884.8|4.86|then the right lending people think that
2886.72|6.24|oh my God you know these all these um uh
2889.66|5.64|walk walk uh annotators and what about
2892.96|3.659|freedom of speech and this is super
2895.3|3.18|divisive
2896.619|5.101|um unfortunately
2898.48|6.48|but the answer is not not to do anything
2901.72|6.18|about it because ins as a matter of fact
2904.96|6.6|my passion toward addressing racism and
2907.9|8.16|sexism came from our experience running
2911.56|7.86|for the Alexa price challenge in 2016
2916.06|6.6|and 17. so we won the challenge but
2919.42|8.399|here's a really sad part of behind it
2922.66|8.959|we had a list of uh thorny keywords to
2927.819|6.361|avoid that included the skin color or
2931.619|5.141|sexual orientation
2934.18|6.24|this is a serious form of discrimination
2936.76|6.839|we cannot build AI models by having this
2940.42|5.58|sort of like banned list to be safe as
2943.599|6.421|if they don't exist this was the status
2946.0|7.26|of cool you know in 2017 the challenge
2950.02|6.42|remains this year you know not only 2021
2953.26|6.3|but this year as well and so we really
2956.44|4.5|need to work on uh racism and sexism but
2959.56|3.6|it turns out
2960.94|4.679|um all the other moral questions share
2963.16|3.3|similar challenges so I'll skip this
2965.619|3.421|over
2966.46|4.5|but using Delphi we had the other
2969.04|4.799|follow-up works such as per social
2970.96|5.52|dialogue where using Delphi as sort of
2973.839|5.76|like a foundation Common Sense model or
2976.48|6.24|model models to make your dialogue more
2979.599|5.641|socially acceptable
2982.72|5.58|um and then we also had this other paper
2985.24|6.18|where we use Delphi in a reinforcement
2988.3|5.819|learning agent to learn how to behave
2991.42|5.22|better in a game environment and so
2994.119|5.101|there's a lot more work to be done of
2996.64|4.56|course this is a tiny little step toward
2999.22|4.98|that there's a huge challenge ahead of
3001.2|7.32|us really aligning AI systems to humans
3004.2|7.32|here's one very quick comment on our new
3008.52|5.7|work in progress the Delphi hybrid where
3011.52|5.339|we include the neurosymbolic reasoning
3014.22|5.22|to address major mistakes such as this
3016.859|5.641|genocide if creating jobs this also our
3019.44|4.98|only systems mistake it's because our
3022.5|3.96|data set doesn't have this kind of a
3024.42|4.26|weird adversarial examples like General
3026.46|6.899|Society of creating jobs nobody speaks
3028.68|6.78|like that in real life situations so our
3033.359|4.201|model thought that if creating job this
3035.46|4.02|is so positive and then didn't really
3037.56|4.14|realize how bad the genocide was because
3039.48|4.68|ready people don't discuss whether
3041.7|6.84|they're going to do genocide or not
3044.16|6.179|red people who you know annotated uh we
3048.54|3.18|annotated for social chemistry don't
3050.339|5.821|talk about whether they're gonna do
3051.72|6.78|genocide or not so our mura framework is
3056.16|5.28|basically that of John Rose which is
3058.5|5.28|descriptive ethics but even John Rose in
3061.44|5.22|later years suggested that we need some
3063.78|5.52|top down mechanism to overcome some of
3066.66|5.159|the biases the crowd people might have
3069.3|5.84|so this is exactly what we are going to
3071.819|6.54|do and we draw from Bernard's gold uh
3075.14|5.919|moral theory framework about what not to
3078.359|4.441|do definitely you know their basic
3081.059|5.221|Universal things that everybody might
3082.8|7.34|agree what's not good to do and then
3086.28|8.279|what we do is we develop basically
3090.14|8.08|a system where we parse out the original
3094.559|5.28|query into smaller events uh like
3098.22|4.2|shooting a bear killing a bear to save
3099.839|5.28|your child so we pass out uh the
3102.42|4.56|original query into basic event and then
3105.119|4.921|check through this Comet model Common
3106.98|7.02|Sense model whether some of these events
3110.04|6.38|uh induced obviously negative or
3114.0|6.9|dangerous Common Sense inferences or not
3116.42|7.36|and then we draw this uh graph of
3120.9|5.82|reasoning a bit reminiscent of my
3123.78|6.059|uricraft in the sense that we have a lot
3126.72|5.76|of these different uh the reasoning we
3129.839|5.101|can do and then they have entailment
3132.48|5.099|relations or contradiction relations so
3134.94|4.679|that we can do Collective reasoning on
3137.579|4.201|top we use again Max's set the
3139.619|4.681|constraint optimization over it so that
3141.78|5.339|we can finally make a more informed
3144.3|4.74|decision that is both interpretable and
3147.119|4.141|then being able to draw from this Common
3149.04|3.62|Sense knowledge to better guard the
3151.26|4.74|motion against
3152.66|6.04|adversarial examples so uh the
3156.0|4.559|performance basically says we can do
3158.7|4.8|this without hurting the performance or
3160.559|7.081|even increasing the performance so as a
3163.5|7.14|last comment uh aicfta morality these
3167.64|5.34|are all sort of like inter Continuum of
3170.64|4.26|challenges it's really difficult
3172.98|5.16|challenges because it's not clear whose
3174.9|4.74|moral values do we incorporate I think
3178.14|4.08|that we should go with the value
3179.64|4.679|pluralism going forward to really
3182.22|4.92|endorse everybody's different culture
3184.319|6.181|and individual preferences not just to
3187.14|7.14|one country one one moral framework as
3190.5|5.46|the correct one and really we need to do
3194.28|4.26|more collaboration across Ai and
3195.96|4.5|Humanities uh include even including
3198.54|2.819|philosophy and psychology and policy
3200.46|5.58|makers
3201.359|7.681|so I think I'll stop here for
3206.04|6.5|uh because I think I'm at time and now
3209.04|3.5|I'm ready for questions
3213.24|6.3|oh there's already one question I see um
3216.96|4.56|do you think legal records criminal case
3219.54|3.48|law reflect the kind of descriptive
3221.52|3.66|morality that you're interested in
3223.02|5.22|capturing you think using that as
3225.18|4.8|training data be useful oh this is an
3228.24|3.06|excellent question
3229.98|4.92|um
3231.3|6.36|I think the legal records does encode
3234.9|6.179|potentially provide really rich resource
3237.66|6.0|that if someone can really annotate like
3241.079|6.78|this it might be helpful we started with
3243.66|6.659|ready cases as just one cent uh short
3247.859|5.101|description of a situation because the
3250.319|6.961|current language understanding is not
3252.96|6.899|strong enough to uh do like a paragraph
3257.28|4.98|level precise understanding even Chachi
3259.859|4.74|PT although it looks really good at
3262.26|5.22|generation my
3264.599|4.74|uh take on charger PT so that it's
3267.48|3.72|better at generation than understanding
3269.339|3.78|which is kind of the opposite of how
3271.2|3.919|humans are humans are actually better
3273.119|4.861|better for understanding than generation
3275.119|5.261|uh so you can read you know Pulitzer
3277.98|4.2|Prize winning news article without
3280.38|3.84|having any problem understanding the
3282.18|5.879|article but you don't necessarily
3284.22|7.02|generate text that might win the award
3288.059|4.681|um so the but the legal domain is really
3291.24|3.3|interesting and I think there's some
3292.74|4.379|active research actually even a stem for
3294.54|4.98|it there's a disciple of law that goes a
3297.119|4.321|step toward that direction and it might
3299.52|3.48|really be helpful for better
3301.44|5.04|understanding what sort of different
3303.0|5.88|values people apply in jurisdictions and
3306.48|5.339|on covering some biases that some people
3308.88|5.76|might have had in the past trials so
3311.819|5.3|there might be some good use cases in
3314.64|2.479|this space
3317.18|6.879|next question awesome work thank you uh
3322.2|3.899|big picture question curious to hear
3324.059|4.981|your thoughts on Where Do We Go From
3326.099|5.701|Here given larger and the larger models
3329.04|3.98|coming out suppose we need a model to be
3331.8|4.68|99
3333.02|7.0|correct for a specific use case to what
3336.48|7.5|extent uh do I see the solution set
3340.02|7.319|being that defining the narrow use cases
3343.98|6.18|or more data parameters we're
3347.339|6.0|fine-tuning the type of work uh that I
3350.16|5.399|did the first monitories Etc and there
3353.339|4.98|is likely it depends yeah
3355.559|4.621|um but um still want to hear about it
3358.319|4.921|okay so
3360.18|4.56|um as far as Foundation models go it
3363.24|3.66|seems that the bigger is the better
3364.74|5.339|except that
3366.9|5.1|um you know I I was uh very excited to
3370.079|3.901|read a bunch of attack companies papers
3372.0|4.5|about Foundation models in the past six
3373.98|6.18|months there's just so many out there so
3376.5|6.66|uh recording story there is that well if
3380.16|5.459|you have uh better data then you can get
3383.16|6.3|away with a smaller models so especially
3385.619|6.48|when you do instruction tuning then you
3389.46|5.94|can get away with smaller data it's just
3392.099|5.22|still General model uh but uh
3395.4|3.719|instruction tuning on the larger model
3397.319|4.74|might even be better it's not the case
3399.119|5.401|that you don't gain any uh performance
3402.059|4.861|but it's just that you can close that
3404.52|4.46|close the gap quite a bit so for
3406.92|5.0|Downstream use cases where typically
3408.98|6.94|practitioners want to use a smaller data
3411.92|5.5|sorry smaller model seems that investing
3415.92|4.199|more into Data is it definitely actually
3417.42|4.98|the answer investing more into a
3420.119|4.98|specific algorithm is also really really
3422.4|4.38|good because algorithm can do a lot like
3425.099|3.901|in this talk I didn't go to graduate
3426.78|3.9|algorithmic Solutions but
3429.0|4.5|maybe I'll be similar to the Meijer
3430.68|5.1|prompting but in my lab we designed a
3433.5|4.38|fair amount of decoding time algorithms
3435.78|4.98|where you can really close the
3437.88|5.28|performance Gap quite a bit uh by doing
3440.76|5.099|so so that's a good thing though for
3443.16|6.419|boxing Academia because algorithm
3445.859|6.121|development feels like more academic or
3449.579|4.98|you know intellectually policing than
3451.98|6.0|really engineering you know downloading
3454.559|4.76|more data from the internet and then uh
3457.98|3.599|I don't know
3459.319|4.421|cleaning the data because you have to
3461.579|4.321|clean the data and all these are very
3463.74|4.099|engineering heavy whereas the coding
3465.9|4.199|time algorithms you can have a fun
3467.839|6.701|inventing some new intellectually
3470.099|7.74|interesting uh thing that also improves
3474.54|5.039|the performance quite a bit so
3477.839|3.361|um yeah there's many different ways to
3479.579|3.121|improve it but I think the data quality
3481.2|5.28|matters a lot and algorithm actually
3482.7|7.8|matters a lot too uh what do I think of
3486.48|8.16|Dan Hendrick's ethics Benchmark yeah
3490.5|6.9|um so we did use that in let's see
3494.64|5.88|uh the common sense non-banks also draws
3497.4|4.04|from these ethics data set
3500.52|4.38|um
3501.44|5.08|we like the data set we kind of disagree
3504.9|4.62|with some of the annotations we found
3506.52|4.62|but this is very typical by the way uh
3509.52|3.48|the thing about morality is that
3511.14|4.459|throughout the humanities we haven't
3513.0|4.859|sorted out yet there's a lot of theories
3515.599|5.101|every theoreticians have a different
3517.859|4.861|viewpoints and then even like
3520.7|4.119|non-theoreticians have a very strong
3522.72|5.399|opinion about what they want to believe
3524.819|4.341|as corrective from wrong so
3528.119|3.081|um
3529.16|5.98|there's that
3531.2|6.04|there are different pros and cons the uh
3535.14|4.199|one thing I learned from this experiment
3537.24|4.98|is that although some of these data sets
3539.339|7.02|seem large so ethics has 100 thousands
3542.22|6.3|of examples social chemistry has 300
3546.359|5.281|thousands of judgments
3548.52|6.539|social bias frames has 600 thousands of
3551.64|6.54|annotations and so forth and yet it only
3555.059|4.941|covers I feel like it only covers still
3558.18|5.28|the
3560.0|6.46|a small peak of the entire Iceberg
3563.46|4.619|there's a lot on the bottom and humans
3566.46|3.96|certainly don't necessarily learn from
3568.079|4.441|all these examples we just learn
3570.42|4.379|fundamental concepts and then can apply
3572.52|3.96|that without this larger scale training
3574.799|3.361|so there's something really lacking
3576.48|4.68|about the way that current machine
3578.16|6.12|learning is very data heavy but that
3581.16|4.74|aside I do think that none of these
3584.28|3.72|resources are perfect they all have
3585.9|3.959|different pros and cons and we really
3588.0|4.619|need to invest more into this especially
3589.859|4.681|from Academia because the tech companies
3592.619|4.401|right now are not sharing any of their
3594.54|5.22|human annotation or human feedback data
3597.02|6.4|especially when it's touching on
3599.76|5.88|toxicity or morality concerns reason
3603.42|4.8|being this annotations I'm pretty sure
3605.64|4.26|are bios and not correct entirely and
3608.22|3.899|that could really invite additional
3609.9|4.56|concerns from the public so they're not
3612.119|4.801|releasing but in order to really study
3614.46|3.96|this better we really need to share this
3616.92|3.439|and then improve it as a community
3618.42|4.98|together so
3620.359|4.661|that's how I would respond to your
3623.4|2.76|question thank you for excellent
3625.02|4.319|question
3626.16|6.12|do I think this tag is ready to be
3629.339|6.421|merged with the search
3632.28|5.1|uh I wouldn't say ready but they need
3635.76|3.78|something like this so for sure you know
3637.38|5.04|home devices so the way that I think
3639.54|5.519|about Delphi is that it can really serve
3642.42|4.919|as a filter for other Foundation models
3645.059|4.681|or application scenarios where they're
3647.339|6.081|about to generate something and you can
3649.74|7.2|put a safety filter which
3653.42|6.06|can really help so in some sense so in
3656.94|5.1|this work I went through this super fast
3659.48|5.139|but here basically what it what happens
3662.04|6.059|is that let's see
3664.619|6.48|um the so the reason why we built this
3668.099|6.48|is because we found the chatbots the
3671.099|5.161|publicly available ones tend to endorse
3674.579|2.941|tend to be too positive to the point
3676.26|5.64|that they're going to endorse
3677.52|7.079|problematic situations like uh user says
3681.9|4.86|Holocaust never happened then the chapel
3684.599|4.02|says yeah you know I agree with you you
3686.76|4.559|know if you say I'm a big fan of a
3688.619|3.661|Hitler then the chatbot might say yeah
3691.319|3.601|yeah
3692.28|4.92|uh you know I the user might say I'm so
3694.92|5.22|depressed I'm gonna kill myself and then
3697.2|6.06|the chapel says go ahead great idea so
3700.14|5.939|uh being positive is not
3703.26|5.28|being homeless being positive to a
3706.079|7.201|problemary Content can be very toxic and
3708.54|6.36|very harmful so uh the Delphi you know
3713.28|3.9|development like daffa even though daffa
3714.9|5.219|is so far from being perfect and it's
3717.18|5.58|also biased it has a western bias
3720.119|5.061|um it's good to really help with the
3722.76|5.339|downstream models
3725.18|4.84|uh yeah so continuing on that question
3728.099|3.841|there has been many concerns about using
3730.02|4.02|gpt-like models with the search because
3731.94|3.179|misinformation oh that's another kind of
3734.04|4.279|worms
3735.119|6.781|others to say we just need more
3738.319|4.961|rlhf plus knowledge graphs
3741.9|3.959|so
3743.28|5.64|um uh yeah misinformation is yes
3745.859|6.661|something else that seems
3748.92|5.879|we are really lagging behind because we
3752.52|4.02|don't have a very powerful fact shocking
3754.799|3.601|models yet
3756.54|6.6|um so that's a different story but even
3758.4|7.199|that aside just in terms of uh norms and
3763.14|6.959|uh ethics that
3765.599|8.941|are safe and fair for people to use
3770.099|7.141|um I think rlhf direction is great but
3774.54|4.319|uh they usually also need human
3777.24|2.64|demonstration not just the human
3778.859|3.841|feedback
3779.88|6.0|and again the problem is that tech
3782.7|5.76|companies own them and nobody is sharing
3785.88|4.86|anything and that makes it really
3788.46|4.68|difficult to make meaningful progress as
3790.74|5.4|a community together so I do think that
3793.14|5.219|data is really important uh the
3796.14|4.38|off-the-shelf models cannot learn models
3798.359|6.021|and ethics on their own it has to be
3800.52|3.86|somehow taught more directly
3806.88|6.62|we really just need to do more research
3809.04|4.46|in this space period is how I view it
3814.44|3.06|yeah
3815.7|3.18|that makes sense uh we also have some
3817.5|3.839|like questions on status so I can ask
3818.88|3.959|them for you yeah folks
3821.339|3.421|um so one question is what's the
3822.839|4.081|complexity of
3824.76|5.28|may you take prompting how many times
3826.92|6.26|does the element to be queried
3830.04|6.6|yeah so honestly it's a bit slow
3833.18|5.86|uh in fact this Adelphi hybrid is also
3836.64|4.62|slow if you try to do this this like
3839.04|4.319|graph reasoning oh this maybe I'm not
3841.26|5.22|gonna do that but the graphic reasoning
3843.359|6.421|is slow because you have to call
3846.48|7.44|you know so many times over and over
3849.78|5.76|and some of this can be batched some of
3853.92|3.84|this cannot be batched especially if
3855.54|5.22|it's a recursive but I would just say
3857.76|6.599|Chain of Thought is also a bit slower
3860.76|5.339|um the max set solver in itself is
3864.359|2.7|pretty fast because this is such an easy
3866.099|3.96|graph
3867.059|6.121|so there's a bit of a delay
3870.059|5.641|um but it's not so it's a bit slower but
3873.18|4.7|maybe not too bad is what I should have
3875.7|2.18|said
3882.42|6.36|um and the question is um let's see how
3885.96|4.5|does commentator compare to gpd3 if gpt3
3888.78|2.819|is fine-tuned on Common Sense data
3890.46|3.0|specially getting some sort of like
3891.599|6.121|instruction content
3893.46|6.3|yeah so then uh the larger wins period
3897.72|3.72|the larger is going to be the better
3899.76|6.059|especially if you're gonna just
3901.44|6.3|fine-tune gpt3 it's a game over so
3905.819|4.26|um for that reason you know some folks
3907.74|4.68|might think that the larger is always
3910.079|5.76|better therefore don't work on smaller
3912.42|5.22|model but I think there are two reasons
3915.839|3.78|as to why small models are interesting
3917.64|4.439|to look at as well one empirical it's
3919.619|4.021|just easier to use but more
3922.079|3.661|intellectually it's also very
3923.64|3.959|interesting if you can make smaller
3925.74|3.319|model better and catch up on the larger
3927.599|3.96|model
3929.059|6.04|personally I think um there's something
3931.559|5.76|about the size the larger model uh that
3935.099|3.601|is more about the information complexity
3937.319|3.601|that is the key reason I don't think
3938.7|4.859|it's just size in the sense that if you
3940.92|4.98|have a really a lot of data but the data
3943.559|4.081|is repetitive and really simple probably
3945.9|4.08|you don't get the same amount of
3947.64|6.439|performance again which was basically
3949.98|7.819|the case when we looked at this output
3954.079|7.24|this result where even though
3957.799|6.161|the loose teacher gpt3 generated a lot
3961.319|4.8|more data than the critical teacher here
3963.96|6.359|the quality of the data was more
3966.119|6.96|important than the quantity so uh I
3970.319|5.161|think the complexity of the data itself
3973.079|4.081|is more important than the size and
3975.48|4.02|oftentimes when you just increase the
3977.16|5.04|size of the data together with the model
3979.5|4.98|you do increase the complexity of
3982.2|4.44|information of the data as well as the
3984.48|4.379|model's capability of learning the
3986.64|4.32|complexity but if we can catch up on
3988.859|4.74|that complexity of information either
3990.96|5.04|through inference algorithms or through
3993.599|4.141|better data then we can close the gap
3996.0|4.24|quite a bit which is intellectually very
3997.74|3.9|interesting research space to be
4000.24|3.319|[Music]
4001.64|3.6|oh cool okay this is a personal question
4003.559|3.361|but I would say like humans normally
4005.24|3.119|have a like a Critic model so it's like
4006.92|3.119|you'd say like I think before you speak
4008.359|2.94|so we just like don't generate you also
4010.039|3.181|like sort of think it's this is a good
4011.299|3.601|thing or a bad thing so people have been
4013.22|3.06|like the community as a whole has been
4014.9|3.0|focusing a lot on like genetic models
4016.28|3.48|like net billion size parameters but
4017.9|3.719|should we also focus on big sized critic
4019.76|2.88|models or into fact checking a lot of
4021.619|2.101|this sort of stuff so what's your
4022.64|3.78|opinion on that
4023.72|6.18|excellent point excellent
4026.42|5.82|um yeah I think we can definitely uh
4029.9|5.34|invest more into critic model because
4032.24|5.819|they go really together well with the
4035.24|5.52|generative models for making the output
4038.059|4.26|better or filtering output better and
4040.76|5.339|yeah there's not as much of an
4042.319|5.941|investment into that so I I really like
4046.099|4.321|uh the question
4048.26|4.799|or suggestion for the research Community
4050.42|4.379|is more like it
4053.059|4.081|okay
4054.799|3.78|yeah I would say uh let's see yeah you
4057.14|2.26|have like some more questions I can do
4058.579|2.701|on the last one
4059.4|2.659|[Music]
4061.28|3.48|um
4062.059|3.78|let's see oh I guess one is like do you
4064.76|2.46|believe language models should
4065.839|4.321|completely avoid questions involving
4067.22|4.44|morals and ethics uh similar to like
4070.16|3.959|open air restricting chat GPT from
4071.66|6.6|giving opinions yeah
4074.119|7.381|um I actually don't mind ero if AI just
4078.26|4.339|avoid evade from all of that except when
4081.5|6.0|somebody
4082.599|7.361|is saying morally questionable things uh
4087.5|3.78|it's also nice for the AI not to go with
4089.96|2.46|it
4091.28|4.019|um so
4092.42|6.18|uh or at least to recognize it as
4095.299|7.38|something not okay and then uh try to
4098.6|6.96|tone it down but I don't think there's
4102.679|5.461|any particular reason why AI should
4105.56|5.219|actually answer moral questions directly
4108.14|6.3|in a more Downstream use cases but
4110.779|6.42|really the goal of this Delphi was
4114.44|5.279|making all these judgments more explicit
4117.199|4.441|so that we can actually study it more
4119.719|6.06|explicitly as opposed to keeping
4121.64|4.139|everything just so like implicit
4126.52|5.98|do you think Common Sense is a emergent
4129.14|7.5|property in a class language models oh
4132.5|7.679|yeah yeah it is definitely emergent
4136.64|9.119|um as in like when we saw this uh major
4140.179|8.761|boost jump in performance with gpt3
4145.759|6.42|uh I do believe that each emergent uh
4148.94|5.58|capability but
4152.179|4.381|um I don't think so this particular
4154.52|3.779|evaluation is not very adversarial by
4156.56|4.259|the way this is like a sort of like a
4158.299|4.56|piece of a cake you know reasonably easy
4160.819|5.46|evaluation scenario so the thing about
4162.859|7.32|common sense though is that it can be
4166.279|6.361|so adversarial so infinitely many
4170.179|5.1|different ways and then you know there
4172.64|6.059|are always people like Gary Marcos who
4175.279|6.42|wants to come up with uh very you know
4178.699|5.04|like weird weird attack scenarios like
4181.699|3.961|you know how crush is a personal and
4183.739|4.56|added to breast milk can support infant
4185.66|6.3|digestive system and then Chachi PT's
4188.299|5.701|three says nonsense and so the usual
4191.96|5.219|problem with the common sense is this
4194.0|6.36|adversarial situations where
4197.179|4.681|um people don't have any problem getting
4200.36|3.42|fooled by this even though you know you
4201.86|3.54|and I see this for the first time no
4203.78|3.84|problem because we have a true
4205.4|3.6|conceptual understanding that is the
4207.62|4.079|backbone of our Common Sense
4209.0|5.28|understanding but that's really lacking
4211.699|4.98|in the way that Transformers are
4214.28|5.7|designed to focus on predicting which
4216.679|4.801|word comes next as opposed to learning
4219.98|5.82|the World Knowledge and in some sense
4221.48|6.42|you know now with the RL HF instead of
4225.8|4.62|predicting which word comes next we're
4227.9|4.86|trying to align the model output better
4230.42|5.04|with the human preferences but that
4232.76|4.979|again is not really aligned with the
4235.46|4.68|different goal of let's make sense of
4237.739|4.141|the world and then build knowledge
4240.14|4.98|models so these are all different
4241.88|6.6|learning objectives and really that is
4245.12|6.84|why I believe that although Common Sense
4248.48|6.0|does emerge from language models
4251.96|4.56|fundamentally language models are not
4254.48|3.9|equivalent to knowledge models and we
4256.52|5.12|really got to focus on building
4258.38|3.26|knowledge models
4262.58|3.96|makes sense
4264.28|3.28|uh cool I think there's one last Zoom
4266.54|1.56|question
4267.56|3.26|um
4268.1|2.72|let's see
4271.58|6.54|do value polarization yeah
4274.94|6.48|uh it's an empty concept you don't want
4278.12|6.119|to include all value systems yes uh so
4281.42|6.72|maybe it is about uh is it empty or not
4284.239|4.92|okay thank you for excellent question
4288.14|5.18|um
4289.159|9.121|so uh I believe that we should then
4293.32|7.66|endorse uh uh conspiracy theories uh at
4298.28|6.18|all or any other you know morally
4300.98|6.9|questionable cases but then
4304.46|7.08|uh still there's this thorny situation
4307.88|5.94|of what to do with you know left to left
4311.54|5.22|people versus lightly Lefty people
4313.82|4.2|versus right-leaning people if U.S and
4316.76|4.1|then you know every country has some
4318.02|6.84|other political divide division as well
4320.86|6.52|uh so here I feel like um we really need
4324.86|5.28|to sort out what to do with this but
4327.38|5.76|um regardless of this uh you know some
4330.14|4.86|of these uh challenges it is true that
4333.14|5.4|you know I personally don't have a
4335.0|6.54|religion but I respect people with
4338.54|5.46|religion and you know I respect people
4341.54|5.4|with a different cultural background and
4344.0|5.58|we kind of have some sense of how much
4346.94|4.44|do we do we believe that we should
4349.58|5.639|respect each other even though you know
4351.38|5.94|the beliefs are different so we probably
4355.219|3.841|need to work together and it shouldn't
4357.32|3.96|be just AI researchers making this
4359.06|4.92|decision by the way this decision has to
4361.28|4.68|come from the humanities at large which
4363.98|4.5|is why the data sharing actually is
4365.96|5.1|important but basically I think the the
4368.48|3.66|current version that I have in mind is
4371.06|1.88|that
4372.14|4.62|um
4372.94|6.04|the AI doesn't need to understand uh
4376.76|4.979|what sort of differences are okay
4378.98|6.6|differences the fact that people do have
4381.739|7.261|a differences in certain uh questions
4385.58|5.579|should be learned by AI so that there
4389.0|4.739|are distribution of opinions as opposed
4391.159|5.181|to one correct answer and then it should
4393.739|4.801|deny some of the
4396.34|3.64|controversy theories even though I'm
4398.54|4.74|sure that you know some people will be
4399.98|6.719|very unhappy about that but well we have
4403.28|6.36|to decide something like that I am
4406.699|4.801|reasonably optimistic that if humanity
4409.64|4.32|is at large work together we can do do
4411.5|5.28|that because after all laws are like
4413.96|6.66|that too laws you know this is a human
4416.78|6.12|artifact that people agreed upon uh
4420.62|5.52|somehow that you know there's this core
4422.9|5.0|rules that people should abide by so I'm
4426.14|4.7|hoping that we can also Define
4427.9|6.52|universals and particulars and respect
4430.84|7.06|particulars whenever uh it's respectful
4434.42|7.62|otherwise have some basic universals
4437.9|6.54|that reflect uh you know core human
4442.04|4.74|values and then as far as this left
4444.44|4.98|learning situation by the way if just
4446.78|6.3|the goal is to make your AI systems safe
4449.42|9.12|for anybody actually we can make the AI
4453.08|7.2|filter extremely uh Equity aware and
4458.54|4.139|it's not going to violate the freedom of
4460.28|3.959|speech by doing so just to make AI to
4462.679|3.781|avoid the saying things that are
4464.239|3.021|potentially microaggression for some
4466.46|5.04|population
4467.26|7.18|and you know we still don't really uh uh
4471.5|6.0|exclude the people who care more about
4474.44|5.46|freedom of a speech over Equity by doing
4477.5|4.44|so so I think there are ways but this
4479.9|4.819|really requires a lot more research is
4481.94|2.779|how I view it
4489.02|3.24|yeah I think that's mostly thanks a lot
4491.48|3.86|for coming
4492.26|3.08|this is a great talk
4495.44|4.4|okay thank you very much thanks so much