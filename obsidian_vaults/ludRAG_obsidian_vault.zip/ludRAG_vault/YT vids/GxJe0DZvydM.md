start_time|end_time|text
0.36|2.96| Alright, let's now take a look at how we compute the loss
3.32|3.48| function for the logistic regression model, the so called
6.88|5.6| negative log likelihood loss. So here, that's just a slide I
12.48|3.56| already showed you at the end of the previous video. And I just
16.04|3.56| want to recap some of the main aspects here. So there are two
19.6|3.92| things going on on this slide. So one is how we compute this
23.52|3.28| probability. And here at the bottom is what we want this
26.8|4.56| probability to be. So let's take a look at what we want first in
31.36|3.18| this case. So we want this probability, the class
34.54|6.42| membership probability for class zero to be one to be maximized,
41.64|3.96| if the true label is indeed zero. So this is on the left
45.6|3.12| hand side, this is the class membership probability, we want
48.72|5.74| this to be as high as possible for equal zero, if the true
54.46|5.54| label is indeed zero, right. And vice versa, we want the class
60.0|4.56| membership probability here for class one to be as high as
64.56|6.08| possible. Also, approaching one, if the true label is one, right.
70.8|5.84| So given so what we want is we want to maximize the probability
76.64|4.48| for the given label for the true label. Now, how is this
81.12|4.2| probability computed? That is what is shown here. So here,
85.32|4.36| again, this is how we compute these probabilities. So the
89.68|5.52| class membership probability for y equals one. So here, this is
95.2|2.98| not really the true label you think of you can think of it as
100.84|5.44| as this one in this function here. So we compute the class
106.28|4.92| membership probability for y equals one. So this one here at
111.2|4.5| the bottom, by just the activation. So this is simply
115.7|7.5| the activation. So the logistic sigmoid applied to the net input.
123.84|4.72| And for the second case, so this one can be computed by one
128.56|10.4| minus the activation. So this would be this one here. Okay, so
138.96|4.04| this is just like a brief recap. Now we can actually rewrite this
143.0|2.76| piecewise function here how we compute this class membership
145.76|4.5| probability using this more compact notation. So this
150.26|5.06| combines or this essentially summarizes this piecewise
155.32|5.72| function in one line, one equation. So how it works is,
161.32|3.2| yeah, let's just plug in some numbers. Or first, let's let me
164.52|3.4| clarify about what this a here means. So this a is the
167.92|4.76| activation, it's just instead of writing h of x, let's just
172.68|3.72| abbreviated with a letter a, it's like nicer to look at or
176.92|5.16| look simpler. Now let's consider the case where we have the class
182.08|4.92| membership probability for class one, given the feature vector x.
188.2|11.92| So if y equals one, then this term remains as a, and this one,
200.76|3.96| nothing happens here, this one becomes one, right, and one
204.72|5.8| minus one is zero. So this cancels or becomes zero
210.52|3.4| essentially, and something to the power of zero is one,
213.92|4.4| right. So this whole term here becomes one. So this whole
218.32|7.28| equation here reduces to just a, right. So a is equal to h of x.
226.28|4.68| So this one here, so we satisfy this first term here. So this,
231.0|2.56| I'm just showing you right now that this function indeed
233.56|3.76| summarizes the piecewise linear function. So now consider the
237.32|10.68| case, oops, y equals zero, given the feature vector x. So here,
248.0|2.96| now consider, let me erase this a little bit. So we have more
250.96|13.48| space. Okay, so we're looking now. This one here, so where y is
264.44|3.88| equal to zero, so y is equal to zero, then this is a zero. So
268.32|8.32| this whole thing becomes one. And we have this, this becomes
276.64|4.72| zero. So this term here becomes one. So what we have then what
281.36|6.52| remains is one minus a, right, which is this one. So you can
287.88|3.76| now see that this equation here at the bottom summarizes this
291.64|6.4| piecewise linear function here. Just a different notation. Now,
298.76|3.36| yeah, what we want is we want to maximize the class membership
302.12|4.0| probabilities. So and usually in a data set, we not only have one
306.12|4.84| single data point, we have n data points. So this is the
310.96|11.62| size of training set. And yeah, we want to maximize the class
322.58|4.08| membership probabilities for all these examples in the training
326.66|4.32| set. So you can think of it as the probabilities here
331.02|4.44| multiplied. So the conditional probabilities, and we want to
335.46|7.88| find the model parameters because it depends here on our
343.34|3.48| model, right. So the probability here, the prediction probability
346.82|2.88| here depends on our model parameters. That's how we
349.78|4.2| compute these probabilities. So we want to find good parameters
353.98|2.8| that maximize the class membership probability for the
356.78|5.48| right class. So this concept is also known as maximum likelihood
362.26|3.72| estimation. So the we want to maximize the likelihood, the
366.58|3.28| probability of observing the data given the model parameters.
371.62|3.96| And you probably know this from other statistics classes. So I
375.58|3.12| don't want to go into too much detail about maximum likelihood
378.9|5.04| estimation here. So just assume now we want to maximize this
383.94|6.6| term here. So here, what I'm doing is I'm just rewriting this
390.54|4.08| with the simpler notation I showed you before. So if I go
394.62|7.68| back to slides, so this notation here at the bottom, that's what
402.3|5.48| I'm doing here. So I'm replacing this, right? This is something
407.78|1.8| you have seen before on the previous slide, I just showed
409.58|4.56| you, I'm replacing this now with this more compact notation here,
415.02|5.48| where before I abbreviated as a, I don't know why I expanded
420.5|2.4| it here. And I think I just wanted to show you how it's
422.9|7.84| computed. Where a is the logistic regression model, where
430.74|5.04| this is sigma is the logistic activation function and z is the
435.78|7.28| net input. Alright, so you can think of it also as the loss
443.06|3.6| function then so as the logistic loss, which we compute as
446.66|5.2| follows the probability over the whole training set. And I said,
451.86|3.04| we want to maximize this, right, we want to maximize the class
454.9|4.08| membership probabilities. In practice, it's actually easier
459.22|4.0| to maximize the natural log of this equation, which is also
463.22|4.68| called the log likelihood function. So why is that if we
467.9|5.96| apply the log here, then we can replace the product by a sum.
473.86|3.28| And also here, this multiplication, we can replace it
477.14|4.4| with a sum. And numerically on a computer, this is just more
481.54|3.84| stable to implement, it's more, more stable when we use, for
485.38|4.48| example, gradient descent. But you can think of it also as
489.94|6.48| maximizing the likelihood also maximizes the likelihood. So
496.42|3.76| it's like the same kind of the same thing as if you maximize
500.18|3.12| one, you also maximize the other. So in that way, this is
503.3|6.8| why we can do that. So here at the bottom is the lock, and was
510.1|3.84| just taking the look of this party at the at the top. So we
513.94|5.44| have now y is the true label times lock, the activation. So
519.38|4.72| this is the class membership probability. So just me for
524.1|5.92| completeness, this would be why given x, and of course, also the
530.02|2.64| model parameters, but I'm omitting the model parameters
532.66|4.48| here just for simplicity. And yeah, this is the lock
537.18|6.76| likelihood. I mean, it's not quite the likelihood loss,
543.94|3.48| because there's one more modification. So in practice,
547.42|3.32| also, when you recall from the pytorch code that I showed you,
551.06|5.0| we have the stochastic gradient descent. And in stochastic
556.14|2.56| gradient descent, let me write this maybe down.
558.7|12.76| Stochastic gradient descent, we want to minimize. So this is a
571.46|6.12| process where we minimize something, if we wanted to
577.58|4.36| maximize something, we would have to use stochastic gradient
582.78|4.92| ascent. That is like the other way around, we want to we would
587.7|6.92| maximize something. So what we don't want to so if we think of
594.62|4.2| it, maybe as a loss function, so as a function, so gradient
598.82|4.8| descent would be like this, where we go down this hill. And
603.62|4.8| gradient ascent would be this way where we go up that hill.
609.78|3.16| Now, in pytorch, and many other libraries, it just happens just
612.94|3.36| for simplicity. There's an implementation of gradient
616.3|5.32| descent, where we minimize something. So in that way, we
621.62|3.72| would just give it a log likelihood function as the loss
625.34|3.64| function to optimize, then it would actually make a minimize
628.98|2.92| this loss, which would actually very bad. So what we would get
631.9|4.08| is very small class membership probabilities for the correct
635.98|4.16| labels. So what we can do now is just to turn around this
640.18|5.2| problem. So instead of maximizing the log likelihood,
645.38|4.2| we can minimize the negative log likelihood, just putting a
649.58|3.72| negative here in front, and then we turn this maximization problem
653.3|2.84| into a minimization problem. And then we can just use the
656.14|5.04| stochastic gradient descent implemented in pytorch. So it's
661.18|2.96| just like a little trick we do by flipping around the sign
664.14|3.68| here. And another trick we can do in code is that we usually
667.82|8.56| add a one over n scaling factor here to scale over the number of
676.42|3.4| data points in the training set or the batch size, the mini
679.82|3.76| batch size. So last time, we also talked about mini batches.
683.62|5.32| So we can also excuse me. So we can also consider the mini batch
688.94|5.32| size here. And then it makes the training numerically more
694.26|4.6| stable. Yeah, so to just have a little checkpoint here to
698.86|3.2| summarize, so doing logistic regression, by that, I mean, our
702.06|3.64| training logistic regression is actually similar to what we have
705.7|4.16| done before in edeline. In edeline, recall, we minimize the
709.86|4.68| mean squared error loss here. But yeah, the difference is that
714.54|3.52| in logistic regression, we maximize the likelihood.
718.98|3.36| Because it's numerically more stable, instead of maximizing
722.34|3.72| the likelihood, we can also maximize the lock likelihood.
726.98|3.28| But like I also mentioned, the tools that we usually have
730.26|3.44| available are developed for stochastic gradient descent, so
733.7|3.72| that we don't have to rewrite those tools, we can just turn
737.42|4.36| this maximization problem into a minimization problem. So we can
742.06|2.78| minimize the negative log likelihood, which is the same as
744.84|3.58| maximizing the log likelihood. So yeah, it was probably a lot
748.42|4.2| of information in this short video. In the next video, I will
752.86|3.88| talk a little bit more about this training and how the loss
756.74|2.44| function actually looks like. I think this will probably
759.18|3.8| clarify some thoughts that you might have. So if you have some
762.98|4.48| questions right now, maybe don't think about it too hard. Maybe
767.46|2.96| watch the next video. And then if you have questions, then
771.22|3.08| maybe think about it more. But I think the next video could
774.3|4.96| potentially clarify some points.