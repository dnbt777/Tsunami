start_time|end_time|text
2.6|4.08| Yeah, hi, everyone, I hope you had a nice week. So last week,
6.68|3.56| we discussed a lot of topics related to computational
10.28|3.72| challenges with deep learning. So what do we do if we have
14.0|4.52| these larger models, we both require more data and more GPUs,
18.66|3.36| and also more time to train these models. So coincidentally,
22.02|3.74| this week, I found a lot of news related to the topic of making
26.28|3.28| the training of deep learning models more efficient. So that
29.56|2.72| is by spreading out the computation across multiple
32.28|4.0| devices in a process called federated learning. But then
36.28|3.24| this also brings your privacy concerns. So there was also some
39.52|4.96| interesting news related to your privacy protection. And
44.48|4.04| lastly, I find personally, the most exciting topic is how we
48.52|3.4| can train these deep neural networks still on a single GPU.
52.12|3.88| Because the truth is, most of us only have access to one or few
56.0|3.7| GPUs. So wouldn't it be nice if we could train just simply
59.7|3.86| things on multiple GPUs, like hundreds of them. But yeah, in
63.96|3.48| real life, it's not so easy. So luckily, there are still a bunch
67.44|3.04| of techniques that allow us to train deep neural networks, even
70.48|3.96| the large ones on single GPUs. So I will also discuss this
74.44|3.8| topic at the end of today's news session. But yeah, because there
78.24|3.64| are so many topics I wanted to cover today. Let me just dive in
81.88|1.0| and get started.
82.88|3.64| Yeah, let's start with federated learning. So last week, I
86.52|5.12| explained federated learning is, yeah, learning on using multiple
91.64|3.48| devices like splitting up a computation across multiple
95.12|3.44| devices. So here was an interesting paper by researchers
98.56|4.0| from Apple. So this paper was entitled federated evaluation
102.56|4.56| and tuning for on device personalization, system design
107.12|4.32| and applications. So this is essentially an example of how
111.44|3.48| it works. So this is essentially Apple's on device machine
114.92|3.96| learning system for federated evaluation and tuning. So
119.2|3.24| federated learning is not new. I mean, a lot of people and
122.48|3.96| companies use federated learning that is using multiple machines
126.44|4.92| to achieve something. So but usually what other companies do
131.36|3.44| is they use federated learning to tune a global neural
134.8|4.76| network. So imagine, for example, you have a server with
139.56|2.84| a neural network model, and this is, let's say, an image
142.4|4.04| classifier or something like that. So then this global model
146.56|4.88| can learn from individual people. So if you have a
151.44|4.12| cell phone, or smartphone, it can access this model on the
155.56|4.56| server. And by if you label your data, you can provide training
160.12|4.32| data for this model. So there's usually one global model. I
164.44|3.64| mean, not everyone is using that approach. But many people are
168.08|3.6| used this approach where you essentially have or keep one
171.68|3.64| global model. In contrast, here in this paper, Apple describes a
175.32|6.32| system where there are global parameters, but the model is
181.64|5.12| trained locally. So all the user data remains inaccessible to the
186.76|3.8| server side. So that means here, they focus on protecting your
190.56|4.32| privacy, so not sending any user data to a server. So all the
195.0|3.06| training happens locally. So you may get some parameters from
198.06|2.94| the global model, but essentially, you will get a
201.0|3.6| personalized model on your phone, for example, without
204.6|3.0| sharing your personal data with a server, which I find actually
207.6|5.0| pretty cool. So here's just a sketch of how this works, where
214.12|3.28| three types of information being shared, the red arrow is the
217.4|4.12| task configuration and attachments information, then in
221.52|3.64| green, the task results and telemetry, and then on blue,
225.16|4.32| these on device records. And here, this one, the left box
229.48|3.64| represents the end user device. And you can see, for the blue
233.12|4.16| ones, the blue ones are the user data, the on device records,
237.48|4.0| they never really leave the device. So on the right hand
241.48|3.84| side is the developer interface. So what the developer interface
246.04|4.16| has access to is the task configuration and the task
250.24|2.72| results. Because you as a developer, you still want to see
252.96|4.08| whether the yeah, the more the learning model learns well,
257.12|2.08| however, you don't want to see any user data, because that
259.2|4.56| would be out in the privacy implication or problem. So here's
263.76|3.68| an example of that where they show how this can be used for
267.44|3.52| tuning for news personalization. So they have,
270.96|3.88| for example, different models. Let's call them run one and run
274.84|4.92| two. And yeah, so here, they involve different parameters and
279.76|4.84| and different metrics from an AB experimentation results. So for
284.6|4.84| example, which model should be used on a local system. And they
289.44|4.24| only have access to information such as how much things
293.68|3.12| improved, for example. So here, they have a delta percent. So
296.8|7.68| they can see basically, that run to improved the percent, the
304.48|4.56| daily article views, increase it by 1.87. And if your metric is
309.04|3.24| to maximize the number of article views, that's your
312.28|3.12| metric, then you can measure this by just looking at the
315.4|4.92| results, you don't have to have access to what types of articles
320.32|4.88| the user reads. Yes, on the previous slide, I highlighted
325.2|3.32| these fundamentally different approaches to federated
328.52|4.68| learning. One is keeping one global model on the server and
333.2|3.04| then sending user data to that server, which sounds from a
336.24|2.56| privacy perspective, a little bit, I would say questionable.
339.04|3.52| The second approach sounded a little bit more privacy friendly
342.56|3.76| where you do the training on the device and your user data never
346.32|4.04| leaves the server. However, the first approach with a global
350.36|4.68| model is actually not that bad if you take some precautions. So
355.04|4.2| there's one area of research called differentiable privacy,
359.24|6.52| let me write this down, differentiable privacy. So this
365.76|6.2| deals with this field develops methods for adding some noise to
371.96|4.32| a data set such that you can't identify people from this data
376.28|2.4| set. So there was one interesting article by
378.68|4.6| Microsoft. But of course, this is a broad field, many people
383.28|2.24| are working on this, I just highlight this article because
385.52|3.68| it was just in the news. So but be aware that it's not the
389.2|3.64| only approach to this. But again, just to highlight the
392.84|4.44| problem. So if you share data with a server, or with anyone,
397.32|3.56| essentially, even if you don't, let's say have the names of the
400.88|5.92| persons in that data set, it may be possible to identify users or
406.8|4.44| people from this data. So there was this $1 million Netflix
411.24|3.2| price has been quite some year ago, I think a decade ago, even
414.44|6.0| earlier. It was this $1 million price, when Netflix had a data
420.44|3.88| set that they shared on Kaggle. And they asked people to develop
424.36|3.6| recommendation systems. And the best recommendation system, the
428.0|3.52| best movie recommender, or the person who developed this or the
431.52|5.12| team would gain $1 million. So in order to facilitate this
436.64|5.36| competition, they shared a data set, it had the title, the title
442.0|4.84| is the user ID, the date of the rating and the rating itself. So
446.84|4.16| the user ID, you can think of it. Here, it is not identifying
451.0|4.0| a particular person is just for helping to make sure if two
455.0|2.44| movies are rated, whether they are rated by the same person or
457.44|4.84| not, but you still don't know who the person is. Actually, I
462.28|3.84| never really had Netflix, but I think they don't have these
466.16|3.76| five star ratings anymore. I think it's working differently.
469.92|3.4| I'm honestly not sure, but I think they don't do ratings
473.32|4.16| anymore. But probably back in the day, they did. Anyways, so
477.52|5.6| the thing here, what happened is that people use the IMDB movie
483.16|5.84| review database. And using this IMDB movie database and looking
489.0|2.92| at this Netflix data set here on the left hand side, they were
491.92|5.4| able to identify people in this data set. So how that worked was
497.32|4.52| by IMDB, by I think by email or username, they could identify
502.16|3.0| the person. And then they were just matching the date of the
505.16|4.88| rating and the rating itself to the records in IMDB. And by
510.04|6.0| that, they could identify the user ID here to whom it belongs
516.04|2.6| by just matching the date of rating and rating. If you do
518.64|4.28| that, for a couple of movies, it becomes very easy to identify
523.0|3.04| certain users by user ID. And then you could, yeah, you can
526.04|3.36| see basically all the movies that the person watched and how
529.4|3.12| they rated that movie. And that is, I think, a big privacy
532.52|3.04| violation. If you haven't agreed to if you're a Netflix user, and
535.56|3.12| you haven't agreed to share that information of all the movies
538.68|4.0| you watched, then yeah, that might be a privacy violation.
542.68|2.84| Maybe you only have a subset on IMDB, but you don't want certain
545.52|3.32| people to see what other movies you watch, then this would be
548.84|5.4| problematic. So differentiable privacy deals with this problem
554.24|4.48| how you can kind of keep the utility of a data set. So making
558.72|4.68| the data set still usable, but avoiding the identification of
563.4|4.04| individuals. So it's essentially the broad, yeah, the broad
567.44|3.68| approach is essentially adding or synthesizing noise and
571.12|3.52| adding noise to this data set, so that the data set has
574.64|3.12| broadly the same characteristics. So if you
577.76|4.16| would, for example, compute the average rating, the average
581.92|4.6| rating may not change. But there's some noise that for a
586.52|2.88| user for a given user, some of the ratings a little bit higher
589.4|3.68| and lower than they were in real. So in that way, it's not
593.08|4.28| so easy to go to IMDB and unambiguously identify these
597.36|7.68| users. Yeah, and what's new here is that Microsoft released a
605.08|4.76| tool set called smart noise. So in this smart noise, yeah,
609.84|4.6| contains some Python API and other things to make this more
614.44|5.88| easy to use in practice. So there's also a sample GitHub
620.32|2.64| repository where you can take a look at some examples. And I
622.96|3.2| want to talk too much about the individual techniques. So they
626.48|2.2| it's basically a framework for implementing different
628.68|3.64| techniques. But what I found interesting is, from this list
632.32|2.52| here of the techniques they implement that many of these
634.84|5.8| techniques they involve GANs. So GANs are generative adversarial
640.64|3.2| networks, we will cover them later in this class. And they
643.84|3.36| are used essentially to learn the training data set
647.2|5.04| distribution and then generating samples, new samples from that
652.24|2.88| training set distribution. So we will cover that later in this
655.12|2.64| class, I just found it interesting that most techniques
657.76|5.04| for differentiable privacy seem to employ generative adversarial
662.8|3.0| networks nowadays, or at least the techniques they implemented
665.8|5.04| in this smart noise approach. Yeah, related to the topic of
670.84|4.12| data set augmentation, I've seen this article this week, entitled
675.32|3.12| humans are trying to take bias out of facial recognition
678.44|5.48| programs. It's not working yet. So here in this article, the
683.92|3.96| authors mentioned that one likely reason for this bias in
687.88|4.16| face recognition is the lack of diversity in the data sets. And
692.04|2.36| they say that one common mitigation approach is to
694.4|3.96| provide algorithms with data sets that represent all groups
698.4|4.8| equally and fairly. So there was a paper called one label 1
703.2|3.04| billion faces usage and consistency of racial categories
706.24|4.32| in computer vision by Zaid Khan and Yun Fu, who looked at this
710.56|3.72| problem. So they looked at the problem, whether diverse data
714.28|4.84| sets can really help. And they say, yeah, it only it can work,
719.12|2.2| but only for a very stereotypical sense of fairness.
721.32|3.36| So essentially, it doesn't really work. So here's a quote,
724.68|3.36| what they say is, the people in the images appear to fit racial
728.04|3.48| stereotypes. For example, an algorithm was more likely to
731.52|4.32| label an individual in an image as white, if that person had
735.88|4.36| blonde hair. So yeah, using even a more diverse data set doesn't
740.24|3.56| really help with this bias problem. So it's still like,
744.16|4.24| yeah, having these stereotype steps and stuff like that. So
748.4|3.4| there needs to be more work done on developing systems that are
751.8|3.28| more fair. So it's not as easy as making a data set more
755.08|5.76| diverse. Yeah, an interesting yet unrelated topic is auto ML,
760.88|4.0| which stands for automatic machine learning. What is
764.92|2.6| automatic machine learning, automatic machine learning is
767.52|5.04| about finding good machine learning algorithms and hyper
772.56|3.76| parameter settings and sometimes also pre processing steps, given
776.32|4.08| a certain problem. So traditionally, we humans, we try
780.4|2.64| out different algorithms and hyper parameter settings and
783.4|4.2| data normalization steps and so forth, to see what works well on
787.6|4.08| a given data set. Auto ML is type is a type of approach of
791.72|3.48| automating this process. So it's less workforce humans, it's some
795.2|3.84| system on top of machine learning that learns this how to
799.04|3.28| do well, basically. So it's basically automating machine
802.32|5.28| learning in a way. A specific flavor of auto ML is neural
807.64|4.28| architecture search. This is specific to neural networks where
812.16|3.24| auto ML can be broader, it can also involve yet traditional
815.4|2.88| machine learning algorithms. And neural architecture search is a
818.28|4.2| specific subfield of auto ML for neural networks, sometimes also
823.16|5.08| it's abbreviated as NAS for neural architecture search. So
828.24|2.72| here in this article, the article is entitled introducing
830.96|3.12| model search and open source platform for finding optimal
834.12|3.88| machine learning models. There are a couple of other open
838.0|3.64| source platforms for auto ML. And I had a like a little bit of
841.64|3.24| a hard time seeing what's new here. But what I think what's
844.88|4.16| new is really that they get approached this problem a little
849.04|2.36| bit differently. I mean, the method is slightly different
851.4|2.92| than other methods. So methods I've seen before, they're usually
854.32|3.76| based on reinforcement learning, evolutionary algorithms, or, and
858.08|3.24| or combinatorial search. And here, it's also looking like a
861.32|4.8| combination of those, where they have multiple trainers are
866.12|4.04| trained asynchronously. And then there's some beam search going
870.16|3.72| on, looking at the results. And then considering the best
873.88|4.48| models, they mutate them. So making small changes to the best
878.36|3.12| performing ones, which is kind of reminding me of how
881.52|3.6| evolutionary algorithms work. And they also talk about
885.12|3.16| knowledge distillation and having some transfer learning
888.28|4.04| here, or not literally transfer learning more, sorry, more like
892.6|4.52| a weight transfer. So here, when I recall correctly, what they do
897.12|3.32| is they transfer the weights from well performing models to
900.44|2.96| new models they want to explore. So instead of starting from
903.4|6.12| scratch. Yeah, so the results looked actually pretty good. So
909.56|4.32| compared to previous methods. So here, the dotted lines are the
913.88|3.84| previous methods, they found that their methods here, they
917.72|3.6| perform the new method performs better the model search method.
921.44|3.48| So yeah, my thought is really that this is fundamentally the
924.92|3.08| building blocks are not that novel, but in the way they are
928.0|3.12| put together, this is a system that performs really well. So I
931.12|3.2| think that's the takeaway that this is really, if you want to
934.32|2.52| use it in practice, if you want to use something that performs
936.84|5.6| really well, this might be a good approach. Yeah, what I
942.44|3.04| found interesting though, when I read this, they said in a
945.48|2.8| recent paper, we demonstrated the capabilities of model
948.28|4.04| search in speech domain, by discovering something, I think I
952.32|4.72| cut it off. But um, yeah, so this is from this 2021 article.
957.04|3.28| And I said in a recent paper, I looked it up. I looked at the
960.32|3.84| paper, it's from 2019. So it's actually not that recent
964.16|4.36| anymore. I still think this is an interesting approach. So if
968.52|5.04| you ever want to attempt neural architecture search, this might
973.56|4.36| be one of the approaches to try. I should warn you though, neural
977.92|2.76| architecture search is of course, very, very expensive
980.68|3.4| because yeah, I mean, training a single neural network is
984.08|3.0| already expensive. And here in this approach, imagine you have
987.08|3.84| to train multiple ones asynchronously. And yeah, this
990.92|3.72| is yet another computational challenge, I would say for
994.64|5.52| people who don't have access to hundreds of 1000s of GPUs. Yes,
1000.16|4.92| speaking of computational scaling or training large scale
1005.12|4.68| models on multiple GPUs. So I saw this paper here, terabyte
1009.84|3.96| token level pipeline parallelism for training large scale
1013.84|4.2| language models, which is kind of interesting. So it's related
1018.04|5.4| to the GPT three language model, which has 175 billion parameters.
1023.44|3.36| And they found a way that they can train it five times more
1026.8|6.24| efficiently on 48 large GPUs. So there are these transformer
1033.04|3.28| models, and there are different ways you can make them more
1036.32|6.24| efficient. So one is partitioning the operations here
1042.6|5.16| that's in subfigure B, where I think this means that they just
1047.76|4.12| split the computation, let's say the left and the right hand
1051.88|4.76| side, and pass it on to multiple devices. So here device one and
1056.64|2.8| two, I think there's actually a label problem in that figure
1059.44|3.16| when I understand correctly, this should be actually part two
1062.6|4.2| here, everywhere. Yeah, but here it's splitting up the
1066.84|2.64| computation across multiple devices by splitting it,
1069.76|4.72| splitting the layer basically. Another approach is this
1074.76|5.16| micro batched parallelism or micro batched, micro batch based
1079.92|3.6| pipeline, where they split up the batches, the mini batches
1083.52|2.44| into micro batches, if I understand it this correctly
1085.96|3.08| here. So they split it up into also multiple devices this way.
1089.24|2.92| And here the novelty is essentially that they have
1092.16|4.8| another method for parallelism where they split up the input
1096.96|3.96| the sequence input into tokens. I mean, this is what you would
1100.92|3.16| do always, you would always split it up into token, but then
1104.08|3.36| they distribute these tokens onto across different devices. So
1107.44|2.76| each device may have a small number of tokens only to
1110.2|3.76| consider. So you have parallelism across these tokens,
1113.96|3.8| which is, I think the new approach here. Yeah, but now
1117.76|3.16| let's get to the real interesting part because this
1120.92|5.04| concerns training large scale models on a single GPU. So I saw
1125.96|4.32| this tweet here, a screenshot of a talk by Sylvain Gugger, who
1130.32|6.2| worked at fast API. Yeah, now let's get to the real
1136.52|4.08| real interesting part training large scale models on a single
1140.64|4.48| GPU. So I saw this tweet here from a talk by Sylvain Gugger,
1145.16|5.92| who works at fast AI, which is a company focusing on education
1151.08|4.44| around deep learning and developing also friendly API's
1155.52|5.6| for pytorch. So here in this talk, Sylvain Gugger summarized
1161.12|3.48| the main steps or main approaches for making large
1164.6|4.68| model training possible on a single GPU. One obvious one that
1169.84|3.92| is the easiest also is to reduce the batch size. So the input
1173.76|2.84| batch size, because then if you reduce the batch size, you have
1176.6|3.36| smaller matrix multiplication. So that helps with memory
1179.96|4.64| constraints, because usually the other problem with GPUs is that
1184.6|4.92| you have a fixed size memory. So usually common, I mean, not all
1189.52|4.32| of them, but common cards are between, let's say 12 and 20
1193.84|6.32| gigabytes of RAM. And this can be quite limiting, especially for
1200.16|3.76| these big models. And yeah, bottleneck is usually matrix
1203.92|4.0| multiplication, especially if you have fully connected layers
1207.92|3.8| like the linear layers in pytorch. So reducing the batch
1211.76|5.48| size can help. Another approach is gradient accumulation, it's
1217.24|3.84| kind of related to the batch size. So if you have very small
1221.08|3.36| batches, what will happen is that your updates will be very
1224.44|2.72| noisy. So remember, when we talked about online learning and
1227.16|3.2| stochastic gradient descent, we will also talk more about that
1230.36|2.96| when we talk about choosing learning rates and things like
1233.32|5.24| batch normalization. In any case, gradient accumulation is an
1238.56|5.64| approach where you essentially run backward in pytorch twice.
1244.2|3.88| So you accumulate the gradients from multiple mini batches
1248.08|2.84| before you do the update, basically. So in that way, it
1250.92|5.44| allows you to use smaller mini batches. Another approach is
1256.4|4.88| gradient checkpointing, actually made a brief figure about that.
1261.28|3.72| I will explain it to you in the next slide. And then there are
1265.0|3.48| also these approaches like zero, which has something to do with
1268.48|4.68| the optimizer, and then also sharded data distributed data
1273.16|4.24| parallel. I will also explain to you how that works in a separate
1277.4|3.2| slide. And there's also model parallelism and pipeline
1280.6|4.04| parallelism. These are related approaches where you put parts
1284.64|4.28| of the model onto separate GPUs. So imagine you have a model with
1288.92|3.12| a lot of parameters, and they don't fit into one GPU. In this
1292.04|3.32| way, you simply split the model across different GPUs. I also
1295.36|3.72| have a small slide about that, because I found some interesting
1299.08|5.24| new tools that allow you to do that very conveniently. So here
1304.32|3.24| is your visualization of gradient checkpointing. I made
1307.56|4.24| that for a notebook. I tried it out in practice earlier this
1311.8|4.52| year. So here, this drawing, I should say, is inspired by
1316.32|3.88| another poster that I recommend you to check out to read a more
1320.2|4.8| in detailed coverage of that if you're interested. So we talked
1325.0|3.24| a little bit about gradient descent. And we have only done
1328.24|3.84| it for smaller models like softmax regression. But of
1332.08|2.8| course, the same concept applies if we have multi layer
1334.88|3.64| perceptrons and convolutional networks with multiple layers.
1338.64|5.12| So usually, we compute first the forward pass. And then we have a
1343.76|5.08| loss function, let's say, this is our output loss. So for that,
1348.84|5.28| you need the forward pass, but then also the signal from the
1354.12|2.68| class label. So let's say here, you have the class label
1356.8|3.24| information, and your prediction. And you use that when
1360.04|6.68| you back propagate to compute the gradients. So traditionally,
1366.72|3.68| what happens is that you keep all these orange nodes, the
1370.4|3.44| computations from these nodes in memory. So for different
1373.84|3.2| gradients, you will need these individual steps from the
1377.04|3.84| forward pass. And if you just run pytorch regularly, for
1380.88|3.4| example, it will keep all these computations in memory, because
1384.28|4.28| you will need them to update them. So for example, just in a
1388.56|4.28| very broad concept wise manner. So in order to update this node
1392.88|4.44| during backpropagation, you need these two nodes. And then if you
1397.32|3.52| want to update this node, you need these two orange nodes. So
1402.0|4.28| while you're doing that, though, you don't you don't need this
1406.28|3.92| part, you will need it at the next step, right. But in that
1410.2|3.24| way, keeping it in memory is actually efficient in the given
1413.44|2.84| moment, because you will need the values later. But if you
1416.28|4.64| have memory limited limitation, this might be something where
1420.92|3.68| you want to offload this or you want to not keep it in memory.
1424.64|4.2| So gradient checkpointing, how it works is as follows. So you
1428.84|5.16| will compute the forward pass, but then you delete all this
1434.04|2.24| intermediate information, because right now you're only
1436.28|3.44| focusing on updating this data point. So you only use this in
1439.72|2.84| this computation, you forget about this, because let's say
1442.56|3.56| you can't keep it in memory, it's too big. But then when you
1447.4|5.04| update the second node here, for example, then in that way, you
1452.48|2.88| recompute these nodes, for example, and you also
1455.36|2.84| recompute these these ones. So the blue ones are the ones that
1458.2|4.0| are recomputed, it's wasteful to recompute them every time. So
1462.64|2.6| essentially, when you use gradient checkpointing, the
1465.24|2.88| model training becomes slower, because you have to recompute
1468.12|4.36| things, but it still helps you dealing with the memory
1472.48|4.64| limitations because you don't keep everything in memory. So in
1477.12|4.28| both slides. So here is the regular approach, everything in
1481.4|3.28| orange is always kept in memory. So you can see with gradient
1484.68|2.92| checkpointing here, you keep fewer things in memory, only the
1487.6|4.12| orange things in memory, but you need to recompute. So that's a
1491.72|2.6| trade off basically between memory and computational
1494.32|4.16| efficiency. It's, it's slower, but again, it helps you with
1498.5|1.22| memory limitations.
1499.72|5.64| Yeah, so the remaining things on the slide are on sharding, zero,
1505.68|4.6| then model parallelism and pipeline parallelism. So it
1510.28|3.6| sounded like based on the tweet that it was for single GPU use,
1514.04|4.64| unfortunately, it requires multiple GPUs. But still, it's I
1518.68|4.68| think, cool selection of things that we can use to make the model
1523.36|4.68| training more efficient. So I don't want to also discuss the
1528.04|2.88| this in nitty gritty detail, because that would be a lecture
1530.92|4.32| in itself. But just to give you a big picture overview, so zero
1535.24|4.44| redundancy optimizer, that's a technique developed by, I think
1539.68|2.88| it was developed by Microsoft, which developed this deep speed
1542.8|4.52| library. So there's a tutorial in this deep speed library that
1547.32|4.36| discusses what zero does in more detail. But the broad overview
1551.68|4.24| is that it is essentially about memory optimization, using 16
1555.92|5.6| bit floating point operations. And yeah, what's nice about it is
1561.56|4.08| in contrast to some other things that make model training more
1565.64|4.52| efficient, zero does not require any major modification of your
1570.16|3.48| model code. So in this way, it's more like a wrapper around your
1573.64|3.4| model, but it doesn't require you to modify the model
1577.52|5.64| significantly by yourself. So yeah, what it does, it's also
1583.16|3.56| then reducing memory consumption, one is by the 16
1586.72|2.8| bit training, but it's also partitioning on the different
1589.52|3.36| states, weights, gradients, and optimizer states across the
1592.88|3.6| available GPUs and CPUs. So that's why you need to also
1596.48|3.84| multiple GPUs. However, that might be something worthwhile to
1600.32|5.72| consider if you have multiple GPUs and memory constraints. So
1606.04|4.24| related to that, there's also zero offload, which is kind of
1610.28|4.68| related to offloading models. So here, they even say that it
1614.96|5.52| works for models up to 13 billion parameters. And they
1620.52|3.8| basically say that one of the bottlenecks is also using
1624.32|4.08| optimizers like Adam. So Adam is something we will be covering
1628.4|4.16| soon in the lectures, which is still my favorite optimizer. It's
1632.56|5.88| actually super nice. It's very robust to Yeah, it's very robust
1638.44|2.16| for training deep neural networks that almost always
1640.6|3.84| converges compared to SGD and momentum where you need a little
1644.44|2.88| bit more fiddling. But we'll talk more about that in class.
1648.04|5.2| And they say they developed this implementation, deep d speed
1653.44|3.64| CPU Adam, which is an implementation of Adam that is
1657.32|3.56| five to seven times faster than the standard implementation,
1660.88|5.52| which I also found interesting. So yeah, related to all these
1666.4|5.16| techniques also to the sharding, I also saw a tweet by the pytorch
1671.56|4.56| developers about so involving a library called fair scale, which
1676.12|3.96| is developed by Facebook AI research. And this is a pytorch
1680.08|4.68| extension for efficient large scale training. And it uses this
1684.76|5.4| fully sharded data data parallel approach. So sharding is
1690.16|5.2| essentially, yeah, also a form of splitting the weights. So
1695.36|3.68| again, he has an article if you are interested in more detail
1699.04|3.92| how sharding works. So this article describes sharding and
1703.2|5.0| here on the left hand side, this is a combination between parallel
1708.48|4.16| data training. So distributing the mini batches across GPUs,
1712.88|5.16| and the sharding. So it's a new thing that just got added to
1718.04|3.48| this library. I haven't tried it yet. But it also looks like
1721.52|4.36| another yet. Yeah, cutting edge interesting approach. So it's
1725.88|3.32| actually based on the deep speed Microsoft research library. But
1729.2|3.24| I think the goal here in fair scale is to make it a little bit
1732.44|4.04| more easier to use within pytorch. So I looked at some
1736.48|4.12| things that fair scale provides. So what I also found interesting
1740.6|4.68| was this pipeline parallelism and fair scale. I found this
1745.28|4.0| particularly interesting because it looks like super easy to use.
1749.28|4.96| Super easy to use. So here's a problem where you have, for
1754.24|4.08| example, the model that doesn't fit into a single GPU. And let's
1758.32|4.12| say you have a second GPU that you could use. Technically, what
1762.44|2.44| you could do is all the other tricks I mentioned before, like
1764.88|3.36| reducing the batch size and so forth. Here, what you could do
1768.24|2.88| is you can just put also different parts of the model on
1771.12|3.8| different GPUs simple as very similar to the model parallelism,
1774.92|4.24| except that we use pytorch pipeline here. So the pytorch
1779.2|3.92| sequential pipeline, we discussed this, I think when we
1783.12|5.48| discussed the pytorch API in lecture five. So where I showed
1788.6|4.52| you how you can have multiple layers in a sequential API. So
1793.12|2.68| here, you can also use the sequential API for the
1795.8|3.52| distributed training. So if you have multiple layers, let's say
1799.32|29.84| layer A and layer B are two layers, C and D are two more layers, you can put them all into your sequential pipeline, and then it will automatically take care of it, distributing it across devices. So here, across two devices, two GPUs, and you can also say how balanced these are. So you maybe can say, if you have a stronger GPU, put more onto the first GPU than the other GPU and so forth. And then also, yeah, there's a chunk parameter. So yeah, that's
1829.16|3.16| Yeah, that is something I will probably try out pretty soon. I
1832.32|3.0| haven't played around with that yet. But it looked super cool.
1835.96|3.2| Because it's simple to use. But yeah, if you have one GPU, this
1839.16|3.68| would of course be a bottleneck. But so it would still be a
1842.84|4.44| problem. So in that way, I would rather consider reducing the
1847.28|2.64| batch size and gradient checkpointing if you have a
1849.92|4.08| single GPU. Alright, so it was probably a very long video. I
1854.0|3.84| will just stop it at this point. And I will see you back in class
1857.84|1.92| on Monday.