start_time|end_time|text
2.28|3.08| All right, let's now take a brief look under the hood of a
5.36|3.84| recurrent neural network. So here we are going to talk about
9.44|3.8| back propagation through time. This is essentially the back
13.24|4.04| propagation algorithm we have seen earlier, except that we now
17.28|3.48| take a look at how it might work. If we have this time
20.76|4.28| dimension, and also don't worry, I won't ask any detailed
25.04|2.48| questions about that in the quiz, because yeah, this is a
27.52|4.08| complicated topic. And here, we are only really briefly looking
31.6|3.56| at it. So you don't have to know the details here, it's just like
35.16|4.48| to illustrate briefly, that back propagation also applies to
39.64|4.32| recurrent neural networks. So here, I'm showing you a figure
43.96|3.2| that is similar or looks similar to what I've shown you before in
47.16|2.86| an earlier video. So here, we have a recurrent neural network
50.02|4.58| with a single hidden layer. On the left hand side, this is the
54.6|5.4| compact notation, where we only see the input and the output
60.0|3.3| here. And then we have the hidden layer here with this
63.3|3.82| recurrent edge. However, compared to before, what's
67.12|3.88| different now is that I have added these weight matrices that
71.0|4.6| we use here. So there are three weight matrices, let's say one,
75.88|5.8| two, and three. That's what it's already like this one, two, and
81.68|6.08| three. So what we can see here is that one matrix connects the
87.76|3.24| input to the hidden layer. And then there's one weight matrix
91.0|4.96| connecting the hidden layer to the output layer. These are
96.0|4.0| weight matrices that you would find. So one and two, they would
100.04|5.68| you would find them in a regular multilayer perceptron. However,
105.72|7.3| now in the RNN, we have three, we have basically all the ones
113.02|3.72| from the multilayer perceptron plus this weight matrix three
116.74|4.92| here, which is the one from the previous hidden state. So to
121.66|7.72| summarize, in RNN here, we have two matrices for the hidden
129.38|6.52| layer, one is connecting the input here. So the input to the
135.9|3.96| hidden layer, and the other one is connecting the previous hidden
139.86|3.56| layer to the current hidden layer, which is this h h here.
145.06|5.08| So on the right hand side is the unfolded version. And you can
150.14|5.16| see so that we have, oh, you can see also that we are reusing
155.3|4.88| these matrices. So at each time step, we use the same matrix
160.18|5.6| here for the input connected to the hidden state. And then we
165.78|4.4| also use the same matrices here for each on time step. So the
170.18|3.08| same matrix connecting the hidden state to the next hidden
173.26|6.92| state. And then we also have these here. So what's really
180.18|5.62| new compared to a multilayer perceptron is that we have these
185.8|3.66| in green. So this is new. And this is new. These are weight
189.46|3.68| matrices that we did not have in the multilayer perceptron before.
195.54|5.64| So how do we compute? Now the hidden state, I mean, this is
201.46|3.14| essentially very similar to computing the regular net input,
204.6|4.82| except that we have no two, yeah, weight matrices and two
209.42|5.34| inputs. So let's consider this case where we compute the net
214.76|5.5| input for this hidden state here, time step t. So what we
220.26|3.0| do is we like before when we computed the net input in a
223.26|3.64| multilayer perceptron, we multiply this weight matrix here
227.78|5.48| with this input here. And that gives us the hidden state. We
233.26|4.48| also may write this differently, like this, right? So we talked
237.74|2.76| about this before in the linear algebra lecture, I don't know
240.5|2.68| why I've written this in a different order. It's the same
243.18|7.52| thing. Yeah, and then this is one input. The other one is h h
251.14|5.2| from the previous hidden state t minus one. So maybe to use
256.34|6.32| different colors. This one is of course this one for so this is
262.66|4.72| the net input for this hidden layer. And then this part is
267.38|6.12| computing this part. And this part here is computing this
273.5|5.96| part. And then we add also our bias here. So the bias is for
279.46|6.32| this hidden state here. Alright, so this is how it looks like how
285.78|2.88| we compute the net input. And then to compute the activation,
288.94|3.42| we will just use an activation function like 10 h or the
292.36|4.02| sigmoid or relu function. And yeah, this is how we compute the
296.38|6.2| net input. Now, how do we compute the net input for the
302.58|3.24| output? This is exactly like what we do for multilayer
305.82|4.04| perceptron. So we have one made weight matrix here, the hidden
309.86|3.16| state, and then the bias. And then again, we can use a
313.42|4.76| activation function, for example, softmax activation or
318.18|5.16| the sigmoid activation, if we have a binary output, or just a
323.34|3.0| linear layer, if it's a regression output, and so
326.34|3.84| forth. So here, this is really the same that we would do for
330.18|6.12| multilayer perceptron. Now, what about the loss? So it really
336.3|5.44| depends on what type of task or sequence modeling task we talk
341.74|3.44| about. So if you only want to predict one label for a given
345.18|3.92| text, you technically don't need these losses here, you only need
349.1|5.0| a loss, a single loss from the last one here, some people argue,
354.34|3.44| it might be good, though, to keep the intermediate losses as
357.78|3.52| well, it helps training the earlier layer. So I think, I
361.3|3.72| mean, depending on who you ask, some people keep these losses,
365.26|5.08| some don't, if you when you compute also many to one
370.38|3.98| sequencing problem. And it is different, though, if you have a
374.36|3.58| many to many, then you want to have multiple losses. So let's
377.94|3.64| take a look at the just a general case. So you can have
381.58|4.88| different losses here, a loss for each time step. And when you
386.46|3.56| then want to compute the overall loss, you can just sum them up.
390.06|6.0| So that would be the overall loss. Yeah, so this would be just
396.06|3.32| looking at the loss, by the way, there's a paper on back
399.38|3.2| propagation through time, what it does and how to do it. So
402.58|3.64| here, we are really just briefly scratching the surface. So this
406.22|3.92| might be some resource to consult. And also, there are
410.14|2.8| probably many different tutorials on the internet also
412.94|3.56| for doing that in detail. For this class, given that we have
416.78|4.04| several generative modeling topics still to discuss on here,
420.82|5.2| we're not going to spend too much time on these details. But
426.02|4.12| yeah, so in order to highlight one of the issues that are
430.14|3.64| apparent, when we use back propagation through time, let's
433.78|4.48| just briefly focus on how the gradient of a particular loss at
438.26|5.68| time step t is computed with respect to this w h h hidden
443.94|5.68| matrix. So here, let's assume we have loss t at that layer here.
449.82|3.84| So what will happen is that we do the back propagation, right,
453.66|2.92| so we would compute the partial derivative or gradient of this
456.58|6.32| loss at the time step with respect to y t. So with respect
462.9|9.12| to this one, and then we would compute the gradient of y t with
472.02|6.64| respect to h t with respect to that one. So here we covered
478.7|3.12| this part. But then yeah, so this is essentially what we
481.82|4.24| would do for regular multi layer perceptron. But then on top of
486.06|6.6| on top of that, we have this term here, which is essentially
492.66|5.64| the through time step where we have time steps from k one to t
498.3|4.88| so from up to the very beginning. So we have partial
503.18|3.88| derivative or gradient of h t with respect to the one in the
507.1|5.52| very beginning. So summing them up. And those themselves, we
512.62|3.48| won't go into too much detail here, but those themselves are a
516.1|5.64| product here. And the product is essentially what could cause
521.78|4.56| problems like vanishing or exploding gradient problems. So
526.54|4.32| don't worry about the details here too much. So really, the I
530.86|4.28| would say the main point here is not really doing this by hand,
535.14|4.22| because usually we have auto grad implemented in pytorch and
539.36|3.02| stuff like that. So we would not have to implement these types
542.38|5.16| of things by hand. But this highlights the main issue that
547.54|4.56| if we have a lot of multiplications, we can have these
552.22|4.56| vanishing or exploding gradient problems if we have very large
556.82|4.68| or very small numbers that we multiply multiple times. So in
561.5|3.6| the next video, I will talk about the so called long
565.14|5.32| short term memory, which is one approach to Yeah, to mitigating
570.46|2.32| this exploding or vanishing gradient problems.