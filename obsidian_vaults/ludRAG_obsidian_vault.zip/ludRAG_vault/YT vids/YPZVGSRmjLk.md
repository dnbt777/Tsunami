start_time|end_time|text
1.2|3.0| Alright, let's now talk about gradients, the derivative of
4.2|5.88| multiple. Alright, let's now talk about gradients, the
10.08|5.0| derivatives of multivariable functions. So here, we are now
15.12|3.72| interested in functions that have multiple inputs. So note
18.84|3.6| though, that the term multivariable and multivariate
22.48|3.02| are sometimes used interchangeably. So multivariate
25.5|2.98| is usually a more common term. But here, we really mean
28.48|3.08| multivariable, because multivariate can mean multiple
31.56|3.24| outputs. Here, we are currently only focusing on a case where we
34.8|3.84| have multiple inputs and a single output. So for example, if
38.64|3.74| you consider linear regression, you can have multiple inputs
42.38|3.3| like the features of your data set. So if you have multiple a
45.68|2.6| train example with multiple features, or think of the iris
48.28|3.56| data set, where you have a simple length, simple width,
51.88|2.68| pita length, and pita width, there would be multiple inputs.
54.76|2.64| But the output, there would be only one output, for example,
57.4|4.2| a continuous value like for regression or class label for
61.68|5.2| the prediction. So yeah, in this case, we are focusing now on the
66.88|3.24| multivariable functions. So consider a function where we
70.12|4.44| have multiple inputs, if we only had one input, we would usually
74.56|6.56| write the derivative as follows with a smaller letter D here.
81.68|4.44| Now, since we have multiple variables, we have actually a
86.12|4.12| vector as the derivative. This is also the so called gradient,
90.24|5.2| we use this upside down triangle, the nabla here. So
95.52|5.88| this is, I think it's spelled like this nabla. So here, we
101.4|4.2| have multiple things going on now in this vector. So each row
105.6|3.74| is a partial derivative. So what is a partial derivative? It's
109.34|4.78| essentially like the full derivative. However, it's for a
114.12|3.84| function where we have multiple input arguments. And if we
117.96|5.32| compute the partial derivative of f, with respect to x, what we
123.28|5.96| do is we set y and z here, or if we have multiple ones, we set
129.24|4.56| all of the all of these as constants, so we treat them as
133.8|3.68| regular numbers, not as variables, while we compute this
137.48|2.32| one. And then once we have computed this partial
139.8|4.0| derivative, we then focus on the second entry, the partial
143.8|6.2| derivative of f with respect to y, while considering x and z as
150.0|4.12| constants and so forth. So we compute each derivative one at a
154.12|4.68| time, the rules are the same as for the full derivative. So
158.84|2.52| really, the big difference here is only that we treat the other
161.36|3.28| variables as constants. But yeah, that is essentially a very
164.64|4.68| similar concept. So here's an example to illustrate that. So
169.32|4.44| consider this function here x squared y plus y, so that two
173.76|7.0| inputs x and y for this function here. So when we then compute
180.76|3.68| the gradient of this function, we have two partial derivatives,
184.84|4.36| the partial derivative of x with respect to the partial derivative
189.2|4.08| of f with respect to x, and the partial derivative of f with
193.28|3.84| respect to y. So we can compute them separately, we don't have
197.12|4.28| to intermix them, we can do one at a time. So let's start with
201.4|3.68| the partial derivative, use the same color, maybe partial
205.08|7.64| derivative of f with respect to x. So what we do is we can, we
212.76|5.28| treat y as a constant, so you can think of it as a regular
218.04|6.68| number. So it's essentially like computing x times one plus one,
224.72|4.48| something like that. So and if you think of the power rule, what
229.2|4.52| happens is the two goes up front and then minus one, so it will
233.72|9.32| be just two x. And this one will stay right. So if this was a two
243.04|5.16| or something, this would stay. So here also the y stays, so we
248.2|5.56| have two x, y, and then plus the derivative of a constant is zero.
253.76|4.24| So plus zero, so the derivative would be two x, y for this one.
258.04|4.08| So using the power rule and the constant rule. Now, we have
262.12|5.36| computed this partial derivative to x, y. Now we can compute the
267.48|5.52| partial derivative for the second entry for the partial
273.0|5.88| derivative for f with respect to y. So that's what I have down
278.88|5.96| here. Notice, instead of x, we are focusing now on y. So x here,
285.24|9.48| x is no constant. And if this, this basically then stays, right,
294.92|6.4| so we have then just to x squared as the constant. So it's
301.32|4.36| like, if you consider a case where we have something like two
305.68|6.16| x, and we compute f of x, we compute the derivative of df with
311.84|4.4| respect to x. So this would be two, right. So in the same way,
316.88|5.0| if this is a constant, the y goes away, it just stays. And the
321.88|8.32| one is also constant, sorry, the y here is the variable. So the
330.24|4.16| derivative of just the variable is one, right. So then the
334.4|3.4| derivative of the whole part would be x squared plus one.
340.44|3.32| Alright, so we have both and then we just arrange them in the
343.76|4.68| vector here. And this is our gradient. Okay, now let's
348.44|3.8| consider the case where we have a composite function like the
352.24|5.4| following one, notice that we have two inputs. So we have g
357.64|6.72| and h, two inputs here, but they both rely on the same input
364.36|5.88| argument here. So there's an inner x that is shared by both
370.24|4.2| functions here. So remember from the regular chain rule that I
374.44|3.92| explained in the last video, if we have a function nesting like
378.36|4.36| this one, and we want to compute the derivative, we can do this
382.72|5.76| by computing the derivative of the outer part times the
388.48|6.6| derivative of the inner part. Now for the two inputs, we have
395.08|3.36| the following case, they depend, they have a dependency that
398.48|3.96| depend both on x. So it's a little bit trickier. So we
402.44|4.84| actually combine them because we have this dependency here. So we
407.32|4.44| still use the chain rule here, but we combine the results. So
411.76|2.64| if we want to compute the derivative of this function,
414.4|4.72| with respect to x, the inner argument, so note that we are
419.12|4.64| not computing, we are not computing partial derivative of
424.0|9.6| g of f with respect to g and for example, h separately as the
433.6|5.12| gradient, because both really depend on x, I mean, we do this,
439.16|3.44| we do this, and this is part of it, but it's not the end result
442.6|3.12| compared to the previous slide where we had a gradient where we
445.72|6.64| had different input arguments. So here, like I just said, we
452.36|3.8| have these partial terms with respect to g. So let me use
456.16|7.52| different colors. For this part, this is one part and this is the
464.36|4.72| other part. However, both share the same x. So the derivative of
469.08|4.32| this function with respect to x, the one argument. So in fact,
473.76|5.56| we have one argument in a way here, we combine them here with
480.12|5.64| where's my yellow with this plus symbol here. So let me clear
485.76|2.64| this is maybe more clear like that. We still use the chain
488.4|4.8| rule, let's maybe focus on on this part. For this part, we
493.2|3.04| still use the chain rule like here. So we have an inner and
496.24|4.6| an outer part. So the outer part is a partial derivative f with
500.84|3.92| respect to g. Here, we use the partial symbol because there's
504.88|5.88| g and h. However, there's only one input argument to g. So here
510.76|3.72| we use a little D. If you don't do this, like consistently like
514.48|2.52| that, I think no one would blame you if we just use partial
517.0|2.68| symbols, that would be fine, too. But yeah, this would be the
519.68|6.08| proper way. So this would be the derivative for this part. And
525.76|4.16| then for the second part, we have a partial derivative of f
530.2|6.6| with respect to h. So and then the inner part. So let me do
536.8|4.56| this one more time. So this is one part, this is the other
541.36|3.92| part. And here we have the chain rule for each of them, the outer
545.28|5.92| one, and the inner one. Here, we also have the outer one, and the
551.2|6.36| inner one. Alright, let's take a look at an example to apply
557.56|5.0| this in practice. Yeah, consider the following function where we
562.56|4.84| have two input functions g and h. So this is just for
567.48|3.04| reference what I had on the previous slide. And the function
570.52|6.08| is g squared h plus h, where g is also a function that takes
576.6|5.44| this input x, where this is 3x. So the function g is 3x. And
582.04|4.16| then h also is a function taking input x. And so this function is
586.22|5.46| x squared. Alright, so I'm doing it one at a time. So let's
591.68|5.0| focus on this part first, which is here. So here, this is the
596.72|6.16| partial derivative of x with respect to g. So if we take a
602.88|5.88| look at this, and differentiate it with respect to g, use the
608.76|4.0| power rule. So this goes front and goes away. And this is a
612.76|3.4| constant because it's a partial derivative, h is a constant. So
616.16|7.3| this also goes away. So what the result is, is 2gh. So now, let's
623.46|5.82| take a look at the inner part. So the inner part of g, so let
629.28|4.48| me use this color. So g is 3x. So we are looking at this one
633.76|5.12| now. So the derivative of 3x is just three, right? So if we
639.4|3.76| derive g with respect to its only input, so there's only one
643.16|3.04| input, then we don't have to treat anything as a constant,
646.22|3.28| because there is nothing else except x. And the derivative of
649.5|4.34| that is three. Now, let's take a look. So we solved basically
653.84|3.64| this in this part. Now, let's take a look at the other part
657.48|3.64| here, the partial derivative of f with respect to h, the other
661.12|7.24| argument. So if we treat, so if we compute partial derivative of
668.36|4.34| f with respect to h, then we treat everything that is not h
672.7|5.42| as a constant. So this is a constant. So in this way, if g
678.14|4.62| squared is a constant, then the derivative of this part with
682.76|5.92| respect to h would be g squared, right? So we have g squared. And
689.12|4.4| this is then one right, the derivative of a variable is just
693.52|5.24| one. All right, so g squared plus one, I have it somewhere
698.76|5.68| here. Right. So here we have it. And then the last part, the
704.44|5.36| derivative of h with its with respect to its input x, so which
709.8|4.58| color do we have left here, this one, maybe. So let's compute
714.38|7.06| this terminal on the derivative of h with respect to x. And h is
721.44|3.8| x squared. So the derivative should be two x using the power
725.24|3.44| rule. So that's two x. And now we just bring everything
728.68|5.24| together. So we have the first part in the second part. So I
733.92|3.48| don't have any colors left that I haven't used yet. So let me
737.4|6.52| just just use black for this left part here. We bring those
743.92|5.28| together. So this is basically this part. And then for the
749.24|10.24| right part, here, we bring those those together. And this is this
759.48|3.76| part. And then if we just simplify this, so if you take a
763.24|3.32| look at this, and you expand these terms, it simplifies as
766.56|5.24| follows. So this would be how we use the multi variable chain
771.8|5.68| rule. Yeah, I don't want to go overboard. But we can also go
777.48|3.44| one step further and write this more compactly using vector
780.92|4.44| notation. So again, the same function here, f with two inputs
785.8|4.44| to input functions g and h, which in turn take both x as
790.24|2.72| input. So if we compute the derivative, this is what we have
793.0|3.32| written down before. And we can also write this more compactly
796.32|6.08| using vector notation, writing it as gradient of f with respect
802.4|4.92| to its inputs, and then times the derivative of a vector v. So
807.32|2.88| the vector v, we define it as a vector containing those two
810.2|6.4| inputs here. And then the derivative would be the derivative
816.6|3.76| of this vector would be containing both the derivative of
820.36|4.72| g with respect to x, and the derivative of d with respect of
825.08|3.84| h with respect to x. So this is more like a compact form of
828.92|3.24| writing down these partial terms. So basically, this term,
832.4|3.16| and this term, sorry, not the partial terms, but the inner
835.56|8.88| terms. So these are the inner, in other words, and now then
844.44|3.72| putting it together. So where this comes from, I mean, if you
848.16|2.68| then consider the gradient of the function with respect to its
850.84|4.84| inputs, and so that's the gradient we discussed. So the
855.68|5.24| partial terms, and then here the inner terms. And if you look at
860.92|4.4| it now, so if you use or compute the dot product, right, so in
865.32|5.32| order to compute the dot product, what we have is, use
870.64|7.12| this color, this times this plus this times this, right. So this
877.76|3.68| is how we usually compute the product. So it expands to this
881.44|4.2| one. So it's just like a little convenience thing to write
885.64|4.68| things more compactly. Yeah, there's one more concept to
890.32|4.28| cover the Jacobian matrix. So consider now a case where f is a
894.6|5.4| vector. So you have a vector f where f is a function, and there
900.0|4.4| could be multiple inputs. So let's consider the expanded form
904.4|3.6| here. So this vector, so there's f1, f2, f3, fm, different
908.0|4.08| functions, each of them has the inputs x1, x2, x3, xm. So this
912.08|6.48| could be, for example, a case for perceptron, where you have
919.0|4.6| net input function, and it takes multiple features as input. So
923.6|6.36| the Jacobian of this vector here is written down here. So the
929.96|3.56| Jacobian is a matrix where all the combinations are
933.52|2.8| considered. So the partial derivative of f1 with respect to
936.32|4.84| x1, the partial derivative of f1 with x2, with respect to x2, the
941.16|4.0| partial derivative of x, f2, with respect to x1, and so
945.16|3.08| forth. Yeah, so you can see all the different combinations here.
949.88|4.4| Alright, I see I have highlighted one thing just to
954.36|3.0| highlight this is the gradient of function one, for example,
957.36|3.04| with respect to its inputs, if you recall the gradient that we
960.4|4.04| discussed earlier, so that each each row of these of this
964.44|3.16| Jacobi matrix would be basically a gradient of a function or
967.6|5.68| function gradient. Yeah, okay. So second order derivatives. So
973.28|3.0| let's talk about second order derivatives. No, I'm just
976.28|2.64| kidding. So we won't be talking about second order derivatives
978.92|4.16| because we won't be needing it for this class. Actually, second
983.36|3.4| order derivatives can be useful. Some people have done some
986.76|2.74| research working with them in deep learning. But so far, it
989.5|3.5| has not been very fruitful. I mean, the results, I mean, there
993.0|2.96| are proof of concepts that it conceptually works, but it is
995.96|3.84| very slow. And there's not really any advantage over using
999.8|4.64| first order methods. So despite some research efforts, especially
1004.44|4.44| as far as I know, no one is really seriously using second
1008.92|5.44| order gradient methods. Yet, I mean, at least while I'm at the
1014.36|2.92| point when I'm recording this, maybe in the future, there will
1017.28|4.08| be a method that is vastly superior compared to our
1021.36|4.52| current methods. But so far, it has not been done very
1025.92|3.68| prominently or very, I wouldn't say successfully, because the
1029.6|3.16| research in itself was successful, but it's not very
1033.08|3.52| practical, I would say. Alright, so with that, let's not worry
1036.6|4.2| about second order methods, then. Let's go back to the more
1040.84|2.44| exciting parts to the machine learning and deep learning
1043.28|3.72| parts. So the next two videos, I will be wrapping up on this
1047.0|3.44| lecture on gradient descent and then training a single layer
1050.44|26.64| of neural network.