start_time|end_time|text
0.24|3.6| Yeah, good morning, everyone. I hope you had a good week so far.
4.16|4.0| And I have good news. So today, we are going to talk about the
8.16|4.0| perceptron. So a first implementation of artificial
12.2|3.08| neuron. And the good news is that this time, there will also
15.28|4.24| be some hands on aspects. So I'm going to show you some simple
19.52|4.36| code, how we can implement the perceptron and NumPy, and
23.88|4.4| pytorch. So based on that, I'm going just a little bit over
28.28|4.48| some items I wanted to briefly discuss. I will also send you
33.12|3.76| specific announcements about that on canvas. So to explain a
36.88|3.0| little bit more and to add also the concrete deadlines. But
39.88|4.32| there are a few things now. So yeah, on Wednesday was the last
44.84|3.72| official day where you could change classes. So I think most
48.56|3.48| people who are in this class right now are also likely going
52.04|3.64| to be in this class until the end of the semester. So that
55.68|3.92| means we can slowly get started with forming the project groups
59.6|5.36| for your class project. So I will ask our TA to set up on
65.2|3.36| spreadsheet where you can then enter your preferences for group
68.56|5.0| members. So I'm thinking that it would be best if you find
73.56|3.4| someone else in this class you you may want to work with. And
76.96|2.84| then you can add your preferences in this spreadsheet.
80.0|3.44| If you don't know anyone in this class, if you can't find a team
83.44|4.0| member, we will randomly assign you to a group. So in that way,
87.44|3.08| don't worry if you don't find anyone. And also if you if you
90.52|2.52| don't have any preference, you don't have to do anything in the
93.04|3.52| end on the TA will then assign groups if you can't find
96.56|5.6| someone for example, regarding the group itself. So it would be
102.16|2.8| great then once you know with whom you want to work, let's say
104.96|2.76| starting next week to think a little bit about what you want
107.72|3.16| to work on for your class project, I will prepare like an
110.88|4.04| overview of the kind of expectations and also compile
114.92|4.64| some examples for the project from other classes like previous
119.56|3.84| semesters. So to have an idea so you have an idea what what the
123.4|5.32| scope is approximately. And then I will also put together a data
128.72|3.48| sheet with resources where you can find interesting data sets.
132.36|3.24| So over the winter break, I've compiled a long list of
135.6|3.6| different data set repositories where you can find interesting
139.2|3.84| data sets that may spark your creativity. So if you don't have
143.04|3.36| any good idea, you may just want to browse through some of the
146.4|2.8| data set repositories. And maybe you find something that you
149.2|5.4| find particularly interesting. So also, yeah, homework one. So I
154.6|4.36| will set up a homework for about this lecture for practicing
159.28|3.96| some Python coding. So my idea is for this lecture to make a
163.24|3.38| homework where you take some of the code that I will be
166.62|3.38| presenting in this class. So I will only present it briefly.
170.36|4.08| And then in the homework, you will take this code, which is a
174.44|4.52| NumPy, and then translate it into just regular Python code
178.96|3.62| without the use of any NumPy. And by that, I think by this
182.58|3.74| reverse engineering going from NumPy to Python, you get to play
186.32|2.72| around a little bit with NumPy and then get a better feeling
189.04|3.96| for how it works. I may also think about just not even using
193.0|3.68| NumPy, but doing that with pytorch. But more details about
196.68|2.52| that after this lecture, I have to think a little bit also about
199.2|3.24| this, how to do it exactly. But you will see in this lecture
202.44|4.36| that NumPy and pytorch are very, very similar. So I think it
206.8|5.4| might be even make sense to just go from pytorch to Python. But I
212.2|2.48| have to think a little bit about that based on the difficulty
214.68|4.0| level. But again, don't worry about it right now, I will open
218.68|4.12| up a new canvas announcement and discuss also the details,
222.8|3.8| depending on how I decide. And then yeah, also wanted to remind
226.6|3.6| you, you can use Piazza if you have questions. So ideally, also
230.2|3.0| other students can participate in Piazza. So if you have a
233.2|2.56| question, and someone knows the answer, it would be great if you
235.76|2.44| can help with the answer, because that's also more
238.2|2.88| interactive than and more fun if more multiple people
241.2|4.16| participate. However, yeah, one short reminder is, please don't
245.36|4.0| use Piazza to post any solutions to the homework. So for
249.36|4.4| homework, everyone should work on the homework by themselves. So
253.76|3.4| please don't post any solutions on Piazza. But if you have
257.16|2.52| general questions about the homework, or there are things
259.68|3.12| that are unclear, you're very welcome to use Piazza and
262.8|4.6| discuss this. Alright, so with that, just what you will learn
267.4|2.72| after this lecture. So in this lecture, you will be able to
270.12|4.24| implement implement your first neural network. So it will be a
274.36|3.2| small single layer neural network perceptron. And you can
277.56|2.84| then use that to make predictions like classification,
280.44|2.92| like simple binary classification. It's not very
283.36|4.0| exciting by itself. Because of course, we will be using more
287.36|2.72| complicated networks that aren't to make predictions. But I
290.08|2.72| think this is like a great start to get familiar with
292.96|4.04| classification setting and also yet to see some code examples.
297.0|10.64| So with that, yeah, then let me get started with the lecture.