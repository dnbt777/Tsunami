start_time|end_time|text
1.56|3.72| Yeah, hi, everyone. I can't believe we already completed the
5.28|3.24| second week of the semester. But in the meantime, there have been
8.52|2.52| a lot of interesting things happening in the deep learning
11.04|3.36| and artificial intelligence world. So here, I'm back with
14.56|2.96| stuff in the news number two, some of the interesting things
17.52|3.48| that happened this week. So we will be mainly seeing things
21.0|2.92| from my perspective, things I've been reading about. But I also
23.92|3.24| had to trim down the list. Yeah, quite a bit because there are
27.16|2.96| always lots of interesting research papers and news
30.12|4.12| articles coming out. So but with that, let me not waste too much
34.24|3.0| time on the introduction and get started with the stuff in the
37.24|0.56| news.
39.68|3.0| Yeah, one of the things that piqued my interest this week was
42.68|4.04| this article entitled, semi researchers explore crazy idea
46.72|4.96| of automating AI paper reviews. So paper reviews, that's a very,
51.72|2.32| I would say sensitive topic in the deep learning and machine
54.04|3.32| learning community right now. Because yeah, these are top
57.36|5.0| conferences where people submit papers like ICML and Europe's
63.24|3.08| there are usually around I don't know, five to 10,000, let's say
66.32|3.76| 10,000 submissions every year nowadays. And it's pretty
70.36|3.16| challenging to find or to maintain good quality reviews.
73.8|3.84| I'm also a reviewer for both of these conferences and get about
77.64|3.32| like three to five papers to review. Also, the timeline is
80.96|3.76| very short. And yet, if you have 10,000 submissions, you have to
84.72|4.44| find also 10,000 reviewers, every one of those reviewing
89.16|3.4| three papers or more. And it's really hard to keep up with
92.56|3.44| these numbers. So I think that was what motivated these people
96.0|4.8| to work on this idea. I would say I'm not honestly convinced
100.8|4.08| this is a good thing to work on or even try to automate paper
104.88|5.08| reviews with AI. Maybe it's good for checking general formats
109.96|6.08| like beyond the conventional quality checks, like whether the
116.04|4.88| paper has, or has the right page limit or right template and
120.92|3.44| things like that. Maybe AI can be used for some quality checks.
124.56|3.84| I'm a little bit skeptical whether it can be used to really
128.44|4.8| make or should make decisions on the quality or regarding the
133.24|3.12| quality of a paper. Nonetheless, I think this is an interesting
136.36|3.96| project from a language perspective, like assessing how
140.8|3.92| far deep learning has come in terms of understanding human
144.72|4.84| language and contents of more comprehensive texts. And also
149.56|4.84| what I found as a general interesting takeaway, these most
154.4|2.76| frequently mentioned qualities of a good review. So these are
157.16|4.92| things to assess whether a review a peer review is good or
162.08|2.48| not. And this is actually something I'm thinking about
164.56|3.6| adopting as a rubric for our class projects. Because like I
168.16|3.44| mentioned before, there will be a peer review for our class
171.6|2.84| projects at the end of the semester. And I will of course
174.44|3.52| share more details later on during the semester. But this
177.96|3.08| might be a good rubric for me also to assess whether the peer
181.04|3.16| reviews you write about the reports of other students might
184.2|3.76| be good peer reviews. So something like decisiveness,
188.8|2.56| comprehensiveness, justification, accuracy, and
191.36|4.04| kindness. Kindness is also very important because yeah, reviews
195.4|3.08| can sometimes be grumpy. And I think that's usually not very,
198.64|3.68| not very nice and not very fair to write grumpy reviews.
203.4|4.2| Alright, so yeah, this model they proposed is based on Bert
207.6|4.44| who went Bart Bart is a denoising autoencoder. It's
212.04|3.32| related to Bert. And this is like for pre training sequence
215.36|3.64| to sequence models, we will talk more about sequence to sequence
219.0|3.36| models. Yeah, and part five of this course at the end of the
222.36|4.04| semester. So sequence to sequence means that the input
226.4|2.72| to the model is a sequence and the output is also a sequence
229.28|3.44| instead of just a single prediction. So instead of just
232.72|3.08| predicting a single class table, you are outputting also a
235.8|5.64| sequence, for example, text, a simple example also of sequence
241.44|3.16| to sequence models would be for example, language translation
244.6|3.44| where you translate from one language to the other. So here
248.04|3.64| they involve, of course, human annotation. So they annotate the
251.88|3.2| paper with these statistics, I think, on some stands for
255.08|3.92| summary, or actually posted here, summary, or MOT is for
259.0|5.36| motivation, as you be as for substance. So they tag, humans
264.36|3.6| tag the article with these different aspects, then they
267.96|4.96| train a tagger that can do the same thing. Then there's some
272.92|3.4| process post processing going on, and then a human has to
276.32|3.0| evaluate the results. So if you're interested in this
279.32|3.28| project, or want to read more, there's the paper here on
282.6|3.48| archive. And they also posted, yeah, the code on GitHub. So if
286.08|3.68| you want to play around with us, if you're curious. All right,
289.76|3.56| moving on, you've probably never wondered what a night made of
293.32|3.68| spaghetti would look like. So this is not new news. It's a
297.0|2.32| little bit older, it's like a month old or something. That's
299.32|4.76| like a machine learning project called Dal E. It's like I think
304.08|5.64| a mashup of wall E and the artist Dali. So in that way,
309.72|3.8| here, what the researchers did is they trained another language
313.52|5.24| model, GPT three, 12 billion parameter model. And in this
318.76|3.96| Dal E model here, which is based on GPT three, or the concepts of
322.72|4.16| GPT three, what the researchers do is they train a model on
327.76|4.24| images and descriptions of images. And then, so these are
332.0|3.24| the inputs. So you can think of it as image net, for example.
335.4|4.52| And then you can query the model and it gives you outputs and the
339.92|4.32| outputs outputs are mashups from the text input. So for example,
344.24|5.68| you can type in spaghetti night or night made of spaghetti, you
349.92|3.68| can type that in and the model will produce new images that
353.6|3.96| have both concepts in common, for example, night and
357.56|4.54| spaghetti. And here are some some of the results of nights
362.12|3.24| made out of spaghetti. So these are images that don't exist.
365.54|4.74| This is something the model synthesized. Unfortunately,
370.32|3.28| yeah, the paper is not available and the code is also not
373.6|3.36| available. But there is a blog article if you want to read more
376.96|2.8| about this project, I thought it might be also fun project,
379.76|5.4| especially if you're interested in generative models. Yeah, and
385.16|3.6| while the Dalai paper and code are currently not available yet,
389.36|3.84| one part of Dalai is available, this so called clip model or
393.2|3.8| approach. So clip stands for contrast of language image
397.0|4.56| pre training. So this is something that Dalai uses under
401.56|6.28| the hood. It's also based on GPT three, I think. So and what
407.84|3.68| clip does it's you can think of it as Yeah, and almost like an
411.52|3.76| image classifier in that sense, but it is doing something clever.
415.92|4.36| So clip is based on zero shot transfer. So here, zero shot
420.28|4.0| means classifying something where you don't have any training
424.28|4.58| example for. So as I mentioned earlier, I'm also working a lot
428.86|3.26| in the area of few short learning with my student
432.12|4.0| genre. And in a few short learning, we have this setting
436.12|10.52| on like, n shot k way, few short learning. So the n in n shot few
446.64|3.88| short learning stands for the number of examples per class in
450.52|4.32| case the number of classes. So for example, if you have, let's
454.84|6.24| say a five, short 10, way few short learning problem, that
461.08|4.56| means you have 10 different classes, but only five examples
465.64|3.52| per class are very small problem. And it's very
469.16|2.96| challenging to develop deep learning systems that can work
472.12|4.2| with such small data sets. So zero shot is even more extreme.
476.44|4.04| It really means you have zero examples. So in this case, the
480.48|2.68| model should predict something even though it may have never
483.16|3.76| seen this class before. So how would you approach this? So for
486.92|5.24| that, the researchers use natural language supervision,
492.16|4.32| and multimodal learning. So multimodal learning stands for
496.48|4.8| our means using different data sources. So here they use image
501.28|3.28| data and text data. So that's where the natural language
504.56|3.36| supervision part comes in. So in particular, they are predicting
507.92|4.16| novel image classes based on word embeddings. So when they
512.08|4.48| train the data set, they are the model, they use both
516.6|3.8| descriptions of an image, and the image itself. And then if
520.4|3.2| they see a new class, they can use the word embeddings or the
523.6|5.32| descriptions to predict the class. So here's an example of
528.92|5.72| that. So this is from the paper, or the blog post, I think that
534.64|3.8| I linked here. So what they do is here, they compare them up
538.44|4.24| model with a regular residual net 101. That is something we
542.68|3.0| will also talk about later in class, that's a convolution
545.68|4.44| network trained on, I think it's yet they are trained on
550.12|8.0| image net. And I should say, um, none, none of this clip thing is
558.12|3.52| fine tuned to these data sets. So it's trained on a different
561.64|2.76| data set, and then applied to data sets, it has not been
564.4|4.52| fine tuned to. So this rest net here was trained on image net,
568.92|4.84| and it reaches 76.2% accuracy prediction accuracy, this clip
573.76|2.4| model, which was trained on a different data set, also
576.16|4.68| reaches 76.2% accuracy on this data set. But what's more
580.84|4.4| impressive is it also achieves good performance on different
585.24|4.44| types of image nets that were not contained in this training
589.68|4.96| set. So in that way, this clip model, um, yeah, generalizes
594.64|4.24| better to other types of data sets by this concept of this
598.88|3.52| contrast of language image pre training. So that is also, I
602.4|3.64| think an interesting idea or approach. And you can also have
606.04|3.4| to find more about this in the paper here. And the code is also
609.44|3.04| available here. And this I think can be potentially really
612.48|4.32| useful if for example, you get developed, for example, let's
616.8|2.88| say a self driving car, and you have a large data set, and you
619.68|4.64| want to look for specific videos or clips or different images,
624.32|4.24| like, I want to have an image of let's say a pedestrian crossing
628.6|2.64| a busy intersection. So in this way, you can have maybe this
631.24|5.48| model, finding your query very efficiently in a large data set.
637.0|3.56| And why is that interesting? Because yeah, you can imagine
640.68|2.76| you don't have to train the model on all possible queries.
643.44|3.4| If you have these word embeddings, you can search for
646.84|4.0| something that is similar to your input word embedding, and
650.84|4.08| it pulls out the corresponding image. So in that way, I think
654.92|5.92| this is actually a very interesting approach. Yeah, and
660.84|3.76| here's a big picture overview of how the method works. It has
664.6|3.08| been some time since lecture one, where I think I briefly
667.68|3.52| mentioned it, but contrastive pre training, that's a form of
672.96|2.04| self supervised
678.6|3.96| learning. And here in this particular case, what they do is
682.76|5.92| they train a model on text descriptions and images. So in
688.68|3.92| the example I gave earlier about self supervised learning, the
692.6|3.6| researchers used an image and then a transformed version of
696.2|3.56| this image and the model had to predict whether it's the same
699.76|3.44| image or not compared to an image that is different. So like
703.48|3.76| being able to distinguish different images from each other
707.24|5.04| and modified versions of the same image. And here in this
712.28|4.8| case, it's kind of a similar concept. But here it's based on
717.08|3.4| text data and image data. So they train this text encoder on
720.48|4.08| the test text description, and the image decoder on the image
724.56|3.96| description. So they produce then a so called embedding. And
728.52|4.2| then based on the text and the image embedding, the model
732.72|4.76| learns like the relationship. So it should be basically, let's
737.48|2.6| say for the I think that's what it means for the diagonal, if
740.08|3.0| you have an image from a certain class from this class and a
743.08|4.16| description that matches this class, it should give a high
747.24|2.84| relationship score or something like that. So you would train
750.08|3.88| the model basically to associate the right description with the
753.96|3.36| right image, then you can if you have a data set of descriptions
757.32|2.64| and images, you can shuffle them. And it should give you a low
759.96|3.28| score if you have a description that does not match your image
763.24|3.36| and so forth. So let's say you pre trained your model, then you
766.6|3.64| can create a data set classifier from text labels. So here what
770.24|4.48| they do is they embed the class label in a text description, for
774.72|5.2| example, here, a photo of a plane car, dog, bird, and so
779.92|5.16| forth. And then you produce these text embeddings. And now
785.08|3.08| imagine you have a new image that you want to classify, you
788.16|2.96| don't know the class label, that is what you want to find out. So
791.12|3.2| in this zero shot prediction, this means this class label
794.32|5.16| doesn't have to be necessarily the training set. So you don't
799.48|3.52| have to have an example of that if you have the right
803.0|5.28| embeddings. So in that way, what they have here is they have this
808.32|4.0| image, they go and give it to the image encoder. And then you
812.32|4.24| have an embedding and then you would pull out the text
816.56|3.88| description embedding that has the highest scores in this case,
820.44|3.94| a photo of a dog, for example. So in this case, you from the
824.38|3.38| text encoding and the image, you would then pull out the class
827.76|3.72| from that one. Yeah, that is on a high level, how this clip
831.52|4.92| method works. I mentioned the model GPT multiple times on GPT
836.52|3.92| two and GPT three. Unfortunately, GPT three is not
840.44|5.04| available yet. So this is a model by open AI for GPT two, I'm
845.48|3.04| actually not sure whether it's already available. I haven't
848.52|3.52| followed it very closely. However, there's I also saw now
852.04|5.76| an initiative to train an open source version of that model. So
857.8|3.36| here they say on our primary goal is to replicate GPT three
861.16|5.84| sized model, or models and open source it to the public for free.
867.22|5.28| So they train the models on the data set called the pile, which
872.5|5.22| is 825 gigabyte model, including like YouTube descriptions on
877.72|3.6| papers from PubMed and so forth. And it is like a 200 parameter
881.32|4.08| model. It's very big. So yeah, it's a big initiative, because
885.6|3.48| these models for us, normal people are really out of reach,
889.08|3.76| you really need a big company to be able to train such a model.
893.16|4.88| And I remember when the first bird or GPT models came out, I
898.04|3.92| think it was estimated like, the cost was estimated to be like
902.0|3.84| around $100,000 just to train the model. And I think for this
905.84|3.6| GPT three, which is magnitudes bigger, it's probably in the
909.44|2.64| realm of almost a million dollars to just train the model.
912.12|4.8| So that's, it's actually good, then that someone maybe does
916.92|5.28| that, you know, in a way that is then also available and free for
922.2|3.96| the public. Alright, so moving on, I also saw it's not
926.16|2.32| directly related to deep learning. But I also saw this
928.48|5.12| news article today. So it's about the popularity of
933.6|4.44| programming languages and tools. So this is by O'Reilly, and they
938.04|4.64| are based their analysis based on queries on their website and
942.68|3.12| books and things like that, like mostly search terms on the
945.8|5.08| website, and what people look for. So yeah, unsurprisingly,
951.0|4.24| Python is of course, the first place also, it already get or
955.24|4.92| it's growing again. So it's still not stagnating. So people
960.76|4.0| use more and more Python, which I think is, yeah, it's good to
964.76|4.44| know. So you know where things are headed. What I also found
969.2|4.08| interesting is Scala. So Scala, I thought personally, that might
973.28|2.6| be the next hot thing when I was in grad school, when I was in
975.88|3.68| grad school, everyone started talking about Scala at some
979.56|3.84| point, which is language kind of related to JavaScript, or I
983.4|3.84| think it, it runs in the JVM, the JavaScript virtual machine.
987.48|3.44| Personally, I have to say I never really used it. And now
990.92|2.6| seeing that has this big decline, I'm also glad that I
993.52|2.72| didn't waste my time learning a new programming language,
996.36|2.68| because that's also always a trade off. It's like the trade
999.04|5.12| of between doing research, getting things done and doing
1004.2|2.6| things like learning new languages. So that is like a
1006.8|3.2| trade off, you want to always be up to date with current
1010.0|3.16| technology and what people are doing, because that's how you
1013.4|3.62| keep up to date and can produce cutting edge work. But then
1017.02|2.78| also, you don't want to waste your time by pursuing things
1019.8|3.52| that are maybe not worthwhile. So for now, it seems like Python
1023.32|3.96| is still a good choice for machine learning and deep
1027.28|4.68| learning. Alright, so another interesting project I saw was
1031.96|4.96| this approach or method by Facebook AI research where they
1036.92|4.04| are teaching AI to manipulate objects using visual demos. So
1040.96|4.9| it's currently very challenging still to train robots, there's a
1045.86|2.66| field called reinforcement learning, as you recall from
1048.52|3.72| the introductory lectures. So in this way, robots learn by
1052.24|3.84| trial and error. So you train a robot to do something by having
1056.08|4.28| it fail a lot of times. And there's another approach to
1061.32|3.08| reinforcement learning called inverse reinforcement learning,
1064.4|4.16| which is like learning based on a demonstration. However,
1068.6|3.04| traditionally, it was kind of also not very easy, because you
1071.64|2.58| had to have a virtual environment for that, where you
1074.22|5.74| can simulate this behavior that you want your agent to mimic. So
1079.96|3.72| here, a Facebook AI research proposed a model based inverse
1083.68|5.12| reinforcement learning approach using visual demonstrations on a
1088.8|4.64| physical robot. So that means the robot can learn by looking
1093.44|4.46| at something on a video series of images, instead of having
1097.9|3.26| this virtual environment, for example, a video game context, a
1101.16|4.56| 3d world, you can show the robot images of a task that a human
1105.72|5.04| performs. For example, here, a human is grabbing a bottle and
1110.76|4.12| moving a bottle around. If you show the reinforcement learning
1114.88|4.68| agent the video, it can to some extent learn to perform this
1119.56|3.12| behavior as well. So there's a video I can't unfortunately play
1122.68|2.92| it in the slides. But if you're interested, yeah, you can find
1125.6|5.0| out more here under this blog post address. And there's also
1130.6|5.4| the code available on GitHub. Yeah, lastly, the last topic for
1136.0|4.32| today is about t sny t distributed stochastic neighbor
1140.36|3.36| embedding. And this is a very popular technique in deep
1143.72|5.04| learning to visualize high dimensional data sets. So here I
1148.76|4.64| have an image of MNIST. So MNIST, as you know, is a high
1153.4|2.8| dimensional data set, right. So for MNIST, for these handwritten
1156.2|5.92| digits, you have 28 times 28 pixels, which is on 784
1162.12|3.56| dimensions. So you have a very high dimensional data set. And
1165.68|4.08| you can really easily visualize that in a scatterplot, for
1169.76|4.64| example. So you can use t sny though, to reduce the dimension
1174.4|4.32| ID of this data set into down to two dimensions. And yeah, the
1178.76|4.2| interesting aspect about t sny is that it preserves the
1182.96|3.36| relationship between the high dimensional space between the
1186.32|3.04| objects in a high dimensional space, and in the new lower
1189.36|5.96| dimensional space. So here is the result of a t sny
1195.36|2.76| dimensionality reduction into two dimensions, let's say you
1198.12|6.8| have two features now x one and x two. And you can see that the
1204.92|4.2| t sny algorithm takes these high dimensional 784 dimensional
1209.12|4.88| MNIST embeddings, and puts them into this 2d space, such that
1214.0|3.56| the relationship between the numbers is still preserved, you
1217.56|4.24| can see all the zeros here cluster together, or the seventh
1221.84|5.16| cluster together, or the force force cluster together, and so
1227.0|3.88| forth. So you can see it kind of preserves the relationship or
1231.28|5.92| the relative meaning of these numbers by when when it is
1237.2|2.88| when it is projecting those into a higher dimensions, lower
1240.08|3.92| dimensional space. And you can also think of it as principal
1244.0|4.28| component analysis. But principal component analysis is
1248.28|6.24| a two, it's a linear transformation. So PCA is a
1254.52|5.68| linear transformation. And this method here, the t sny method is
1260.2|2.24| not just a linear transformation, it's a little bit
1262.44|4.92| more involved than that. I actually taught t sny in statistics
1267.36|4.64| 479. I have actually some slides I can upload. I had a full
1272.0|2.32| lecture on that I don't want to go into too much detail here.
1274.44|6.48| But it's a very cool method. It's really useful. But one kind
1280.92|4.24| of downside of that is that you have to tune the hyper parameters
1285.16|3.68| in order to make it perform well. And usually you don't know
1288.84|4.24| because you don't know the labels, always, you don't know
1293.08|5.36| what a good setting is. So there was a paper I saw this week,
1298.68|3.08| it's about initialization is critical for preserving the
1301.76|3.56| global structure in both t sny and UMAP. So here, the
1305.32|3.24| researchers say that it's really important that you choose the
1308.56|5.0| right parameters when you use t sny, the right hyper parameters.
1313.56|4.4| And one of those is the random start, like how you start t
1317.96|4.44| sny, the initialization. And here, they found that t sny
1322.4|4.72| will perform much, much better if you use actually piece PCA as
1327.12|3.6| an initial initialization, you basically initialize t sny with
1331.24|6.6| PCA result. So in that way, they found that, for example, when
1337.84|3.6| they compared t sny with PCA initialization, and the random
1341.48|3.64| initialization that t sny performed much, much better on
1345.12|4.72| and across everything here, almost everything. Um, I think
1349.84|3.72| the way they measure that, and if I recall correctly, is they
1353.56|4.64| measure the correlation between the distances and the original
1358.2|4.52| space and the reduced space. So if I go back, they would
1362.76|3.68| compute the distance between two images in the high dimensional
1366.44|3.92| space. And then they would compute it in the low
1370.36|2.96| dimensional space in the two dimensional space, and then
1373.32|2.56| check the correlation for these different approaches. And they
1375.88|5.8| found basically that using t sny with PCA really preserves the
1381.68|4.52| distance between objects in the low dimensional space. Yeah,
1386.2|3.04| here, as you can see from the title, there's another method
1389.24|4.24| called you map. This is also a very good method. And it's
1393.48|3.6| recently even become more popular than t sny, because
1397.24|3.88| sometimes it's even better at preserving this structure. So
1401.12|4.16| yeah, with that, this is t sny, I think you may probably want to
1405.28|2.68| use it at some point in your class projects. It's really
1407.96|4.68| useful for visualizing high dimensional data sets. But in
1412.64|3.0| practice, it's not really only used for visualizing data sets.
1416.04|3.72| It's usually also used for understanding what a deep neural
1419.76|4.24| network does. For example, you would apply that to an embedding
1424.0|2.72| of a neural network to really understand what information is
1426.72|3.24| contained in the network. So if you have a big convolution
1429.96|4.28| network, so you usually have layers that become smaller in
1434.24|2.56| size, the deeper the network becomes, and then researchers,
1436.8|3.12| for example, would take the later embeddings and then apply
1439.92|3.92| t sny to see how well it separates on different classes
1443.84|5.4| in the slower embedding and so forth. Yeah, just like a last
1449.24|3.36| thing here about t sny. So inside could learn on the
1452.64|3.08| random. Sorry, the initialization scheme is a
1455.72|3.32| random initialization. And yeah, here you if you want to use
1459.04|2.96| t sny in practice, according to this research paper, you want to
1462.0|4.72| change that to PCA. So instead of using the default random, you
1466.72|3.56| would want to use PCA because it performs better according to
1470.28|3.04| this paper on the previous slide. And also there is a
1473.32|2.72| discussion right now on the psychic learn issue tracker
1476.04|4.76| where it's proposed to change this default behavior, so that
1480.84|4.2| it will also use PCA by default. And then also there are some
1485.04|2.56| other tips. So if you want to use t sny, I would recommend you
1487.6|3.28| to check out this issue here where there's a more in depth
1491.32|3.96| Yeah, discussion. And with that, I think it's already a long
1495.28|4.36| video. So enough news for this week. I will see you on Tuesday
1499.64|21.72| with the next lecture.