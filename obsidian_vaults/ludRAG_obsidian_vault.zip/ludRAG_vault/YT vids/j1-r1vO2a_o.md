start_time|end_time|text
1.92|3.6| Yeah, hi, everyone, I hope you had a nice weekend. So last
5.52|3.96| week, we talked about gradient descent and topics and calculus
9.48|3.64| to understand how we can compute the partial derivative of a loss
13.12|4.24| function with respect to the weights of the model, so that we
17.36|4.36| can optimize the model to do good predictions. So this is, I
21.72|3.2| think, still very important to understand from a bottom up
24.96|3.8| perspective, like understanding why we compute gradients and how
28.76|3.84| we compute gradients. However, in practice, especially when we
32.6|2.94| work with these big neural networks, it will be very
35.54|4.1| tedious to implement these gradients by hand by deriving the
39.64|3.44| loss function manually by, let's say, pen and paper, and then
43.08|3.64| coding it up in Python, Python code, and things like that. So
46.72|4.24| we will use pytorch, actually, to make our life easier. So in
50.96|3.52| pytorch, there is a sub module called autograd, which is a
54.48|3.86| module for automatic differentiation. And as the name
58.36|3.98| automatic implies, it will automatically derive the loss
62.34|3.98| function with respect to the weights for us. So in that way,
66.32|2.92| we don't have to worry about it ourselves. And in this lecture,
69.24|2.94| I will show you essentially how this works. And we will be then
72.18|2.94| also using it later in this course, when we work with more
75.12|2.68| complicated networks, like convolutional networks or
77.92|2.96| recurrent neural networks. So with that, let us get started,
80.88|7.16| then. Yeah, like I mentioned, the focus of today's lecture
88.04|3.7| will be on computing partial derivatives more easily and
91.74|4.34| automatically using pytorch. And I structured this lecture into
96.08|3.76| five parts. So the first part will be really just on your
99.84|4.92| Python resources. So where you can find information about pytorch
104.8|3.6| and more reading material if you need it, where you can find
108.4|3.28| useful tutorials. So in addition to this class, I think this is
111.68|3.6| just also useful for you to know where to find more information
115.28|2.6| and keep up to date with the other pytorch development in
118.04|4.04| terms of new version releases and so forth. So then I will
122.08|3.56| introduce the concept of computation graphs. So this is
125.64|4.5| basically how we think of a series of computations in the
130.14|4.38| computer, like this computation graph that we can use to
134.52|4.32| visualize a computation like a prediction in a neural network.
139.2|3.28| And then using the analogy or the concept of a computation
142.48|3.72| graph, I will explain how automatic differentiation works
146.2|3.88| in pytorch. So pytorch is under the hood, building such a
150.08|3.56| computation graph. And then based on this computation graph,
154.0|5.56| it backtracks the computation to compute the gradients. We will
159.56|4.8| then see how that applies to add a line. So last lecture, we
164.36|3.64| trained the airline manually. So we computed the derivatives by
168.0|3.34| hand in the lecture slides. And then I showed you a code
171.34|4.22| implementation of that. So today, we will see how we can
175.56|3.32| do this automatically using pytorch. So in pytorch, that is
178.88|4.46| the so called backward function, which can do things automatically
183.34|4.4| that we have done tediously by hand last week. And yeah,
187.74|3.1| lastly, I want to end this lecture today by taking a closer
190.84|4.24| look at the pytorch API. So there are two main sub API's
195.12|4.44| object oriented and a functional API, which are both useful. So I
199.56|4.6| will also explain to you how the API works in a bigger picture
204.16|3.32| sense. And we will be using these concepts then later, when
207.48|4.32| we talk about implementing multi layer neural networks. So with
211.8|2.92| that, I think this lecture may be one of the longer ones
214.72|3.92| again. So it could be that is a little bit above the 75 minutes.
218.64|2.84| However, on Thursday, there will be a shorter lecture where I
221.48|4.28| will go over just optional concepts like how we can run
225.76|5.36| code on the GPU using free cloud resources. So Thursday's lecture
231.12|3.52| will be I think relatively short or more like optional. So you
234.64|3.56| will have also plenty of time to catch up this week if this
238.2|3.84| lecture ends up a little bit longer. Okay, but with that, let
242.04|4.6| me not spend too much time here and get started with part one
246.64|3.0| pytorch resources.