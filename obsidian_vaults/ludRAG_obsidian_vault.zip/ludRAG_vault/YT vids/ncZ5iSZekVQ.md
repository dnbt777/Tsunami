start_time|end_time|text
2.36|3.72| Alright, let's dive into the topic of logistic regression by
6.08|5.56| viewing it as a single layer neural network. And yeah, this
11.64|3.96| is why I emphasized the identity function in Adeline so much.
16.2|4.04| Because if we look at this figure here, this is a single
20.24|4.96| layer neural network, where we have the inputs x, the weights
25.2|6.32| w, and then we compute the net input here, and the activation
31.52|4.6| here. And then an output here where we, for example, could
36.12|4.88| apply a threshold function. But for training, we can ignore the
41.0|3.92| threshold function for training. We usually use the output from
44.92|4.36| the activation. So in Adeline, this activation function was an
49.28|5.28| identity function. So this was in Adeline. And in Adeline,
54.56|4.12| then we use the mean squared error as a loss function
58.68|3.12| between we computed it between the activation and the true
61.8|4.68| class labels. So here, a, this is the activation here. And then
66.48|3.2| we had some true class labels y and computed the mean squared
69.68|4.28| error. Now, the only difference really between Adeline and
73.96|3.12| logistic regression is that we have a different activation
77.08|4.92| function. So one difference is that we now use this logistic
82.0|3.12| sigmoid function instead of the identity function. So in
86.06|4.22| Adeline, again, we had just the identity function z. So input z
90.3|5.5| output z. Now we have this nonlinear function. So this is a
95.8|6.46| nonlinear activation function. I will show you in the next
102.28|4.06| slides how it looks like. And another difference between
106.34|4.08| logistic regression, and Adeline is that we now have a different
110.42|3.5| loss function, I will cover the loss function and logistic
113.92|3.78| regression in the next video, though, so that we can keep this
117.7|3.68| video a little bit shorter. Alright, so here is how the
121.38|3.32| logistic sigmoid function looks like. So that's just from the
124.7|4.18| previous slide. So what I showed you on the right hand side is
128.88|2.5| this one, I mean, there are two forms, you can write it as
131.72|4.22| usually on this one is the more common form in deep learning on
135.94|3.24| deep learning contexts, we will be using this activation
139.18|3.6| function also in the context of multi layer perceptrons later.
143.22|3.32| So how you get from here to here loops from the left hand side to
146.54|4.4| the right hand side is just by dividing by dividing by e to the
150.94|8.44| power of z. So if you divide this by e to the power of z, you
159.38|3.56| get the right hand side because yeah, this would be one, this
162.94|7.24| would be one, and this part will be e minus z, right? Because of
170.18|4.36| this relationship. Alright, so here's how it looks like. So we
174.54|3.68| have the activation here plotted on the y axis, and the net
178.22|3.44| input, which is passed to the activation function on the x
181.66|3.2| axis. So this is really the input to the activation function
184.86|6.24| here. And you can see that it's centered around zero. So it's
191.1|5.16| centered around zero. And if the input is zero, then the output
196.26|8.44| will be point five. And it saturates here at one, so the
204.7|4.76| maximum value is one set approaches one. And here on the
209.46|4.48| other hand, it approaches zero. So it's a function between zero
213.98|5.2| and one. All right, so but you can see you have to have very
219.18|4.04| negative or very positive values. So this is how this
223.22|5.44| function looks like. So yeah, I will explain to you how the
228.66|3.16| logistic regression loss function works, like in the next
231.82|3.08| video, here, I just wanted to summarize a few things. And it
234.9|2.94| may be that you have to think a lot a bit about this, because it
237.84|1.9| can look a little bit complicated at first glance.
239.74|5.08| But essentially, it's not that complicated. So let me just use
244.82|3.32| this notation here to summarize the logistic regression model,
248.14|4.0| where H, you can think of it as the hypothesis in traditional
252.14|3.12| machine learning, or you can more simple terms, think of it
255.26|3.2| as the model, this is our logistic regression model, which
258.78|6.04| receives as input, the net input. And then you have this
265.06|2.52| logistic sigmoid activation function that I showed you in
267.58|4.48| the previous slide, which returns a value between zero and
272.06|3.62| one. And you can actually think of this whole model here as a
275.68|3.02| model that computes the posterior probability, the
278.7|5.04| probability of class label y, given a feature vector x. So y
284.18|5.84| is the class label. And x is the
292.24|8.54| feature. Oops, vector. So you can think of it as this. And now
300.78|7.34| let's say we have, um, yeah, we have class label one. So let's,
308.2|3.02| let's look at a concrete example. Let's consider the
311.22|6.14| iris data set, where we have class label one. As let's say,
317.36|3.72| setosa, it's a now for simplified case of a simplified
321.08|2.5| scenario, think of it as a binary classification problem,
323.82|6.26| we have one as setosa and zero as versicolor, these two
330.08|7.32| classes. Now, if I want to compute the probability that a
337.4|3.64| given feature vector belongs to setosa, to class one, I can
341.04|4.88| write it as this P, y equals, let's say one because it's
345.92|5.78| shorter given x, and this is computed as, as this one, and
351.7|6.22| the probability of y equals zero is computed as x, which we
357.92|7.16| can write as one minus h of x. So these are the feature vectors
365.08|8.64| here on these axes. Now, so imagine the probability for
373.8|11.04| setosa is point eight, then equivalently, the probability
384.84|6.36| for versicolor would be point two. Right? So if this is
391.24|5.6| indeed true, so if the flow is indeed versicolor setosa, then
396.84|2.84| this would be actually pretty good. So let's say we assume we
399.68|9.16| have a true label, let's assume that true label is actually one,
409.8|3.52| then it would be actually pretty good to get an accuracy of 80%
413.32|2.52| the higher the better, though. So we want to actually have a
415.84|8.88| high probability. But if the true label is zero, then a high
424.72|4.4| probability would actually be bad. If the true label is zero,
429.12|9.64| what we want is actually a high probability for p y. So I can
438.76|5.32| I can just maybe use different color. What we want here is we
444.08|3.16| want to have a high probability for this case, then if the true
447.24|4.84| label is indeed zero, then we want to have a 80%, maybe for
452.08|3.48| this case. So that is what I'm summarizing here at the bottom
455.56|4.48| of this slide. So if we have a binary classification problem
460.04|5.12| with possible class labels, zero and one, what we want is these
465.16|4.92| probabilities to be close to one for the respective class. So if
470.08|3.96| the class label, the true class label is zero, then we want the
474.04|7.16| probability for y equals zero to be close to one. If the true
481.2|5.2| label is one, then we want the probability for this scenario to
486.4|6.2| be close to one. So in this case, it's, yeah, it's depending
492.6|3.08| which probability we want to be maximized depends on the true
495.72|5.68| label here. So we will look at that how we can do that with a
501.4|3.68| loss function in the next video. But this is like the basic
505.16|4.72| setup. So we want a high probability given the other
509.88|3.52| certain class. So vice versa, we can also think of it like this.
513.52|8.12| If we have a setosa label, we want this one to be large, which
521.64|6.0| gives us the scenario for class one. So if we have a setosa case,
527.64|8.76| make this one large, make this one small. However, let me erase
536.4|2.84| that because we don't have that much space. If we have a true
539.24|6.88| label, versicolor, then make this one small and make this one
547.16|3.96| large. So this is essentially what we want to achieve. And I
551.12|2.36| will show you how we can do that in the next video.