start_time|end_time|text
0.16|3.64| Alright, in the previous video, we talked about recurrent neural
3.8|4.08| networks with attention. So this attention mechanism helps the
7.88|4.0| recurrent neural networks to deal better with long sequences.
12.2|3.6| Now we are doing something crazy and remove the recurrent neural
15.8|3.7| network part. So we are going to take a look at a model that just
19.5|5.24| uses attention without the RNN part. So this particular type of
24.74|3.7| attention we are going to look at is also called self attention.
28.44|3.44| And this is the foundation behind or one of the main
31.88|3.68| principles behind the so called transformer networks that we are
35.82|3.66| also taking a look at. So these transformer models are currently
39.72|3.72| state of the art models for long sequence modeling and working
43.44|5.1| with text data. So since there are lots of small topics to
48.54|3.86| introduce, instead of making one very long video, I decided to
52.4|4.24| split this up further into subsections. So in this video,
56.64|4.24| we are going to take a look at the broad concept, and then
61.2|3.3| introduce a very basic form of self attention, just for
64.5|2.94| educational purposes to understand the underlying
67.48|3.5| principle behind self attention. And then we are going to take a
70.98|2.66| look at the more sophisticated form that is found in this
73.68|3.96| original or in the original transformer model. And this
77.64|3.04| original transformer also has a concept called multi head
80.68|4.24| attention. And after we cover these, we will then take a look
84.92|5.96| at how these are these concepts are combined into the
90.88|4.84| transformer model. And I will also introduce yet some
96.4|4.44| interesting insights about that and also talk about some
100.92|5.12| popular nowadays popular flavors of that. And finally, we will
106.04|3.24| end with the implementation of transform models in pytorch.
109.28|6.48| Okay, so this is here just a recap of what we covered in the
115.76|4.44| previous video. So we had this RNN with the attention
120.2|5.24| mechanism. And how this work was that we had for each generated
125.44|6.76| word. So we had this RNN here, we call this RNN number one, and
132.2|5.04| we have this bi directional RNN number two. So for each time
137.24|6.18| step, the RNN here was creating an output word. And in addition
143.42|4.44| to just receiving the previous hidden state, it was also
147.86|4.34| receiving this context vector, which was depending on the whole
152.36|4.96| sequence input here. So we had the source sequence here, so the
157.32|4.64| hidden representations here, and then we multiplied them by these
161.96|4.96| attention weights here. So the attention weights were a
166.92|5.76| normalized version of values computed by a neural network. So
172.68|3.8| this was what we covered in the previous video. So the key idea
176.48|3.96| was that we are we had the whole sequence in a weighted form as
180.44|6.8| input. Now, we are going to remove all sequential parts from
187.24|3.36| that model. So we're getting rid of all the sequential parts, we
190.6|3.92| don't use any recurrence, no convolution, nothing like that,
194.54|3.64| nothing that really is specific for processing input
198.18|5.26| sequentially. And we are going to work towards this so called
203.48|3.36| transformer model, which only relies on the self attention
206.84|3.8| mechanism. And the self attention mechanism processes
210.64|3.4| the whole sequence all at once. And this is actually also great
214.04|3.52| for parallelization. Actually, transform models are pretty
217.56|6.08| expensive to train, but they are better at utilizing multiple
223.64|4.52| GPUs, because you can train in parallel with a RNN, you
228.2|4.04| generate one thing at a time, right. And so you can run these
232.24|2.96| in parallel, because you have to for this, not to compute this,
235.2|3.36| you have to have finished this part. So transformers are a
238.56|4.24| little bit better, a lot better at parallelizing computations.
242.8|5.28| And similar to the RNN, the many to many one, we will also have
248.08|3.36| an encoder and a decoder part. But instead of using RNN, so
251.44|4.6| LSTMs, we use something called stacked attention layers. So
256.04|2.68| this is what we are working towards to this is the big
258.72|4.24| picture, like getting to these parts. And we are going to do
262.96|4.84| this one step at a time. The basic foundation for these
267.84|3.92| slides is this paper, it's called attention is all you need.
271.76|6.16| And this was the foundational groundbreaking paper in 2017,
277.92|3.6| that introduced the original transformer architecture, which
281.52|6.68| outperformed any other method out there up to this point. So
288.2|5.08| and since then, since 2018, the field of natural language
293.28|3.68| processing with transformers has grown tremendously. So you can
296.96|5.2| see it starts also relatively small. So here, on the y axis,
302.16|9.32| this is the number of parameters in in millions, I think. Yeah,
312.04|3.04| it's always unfortunate when people don't label the y axis,
315.08|5.4| but I think what they meant here in this article was parameters
320.48|8.12| and millions. So then this one would be 8.3 billion parameters.
328.72|4.08| So you can see there's a huge growth curve, in terms of the
332.84|4.68| sizes of these models, but also a huge growth in popularity. So
337.76|4.68| I don't have here in this video, but there are also papers like
342.76|3.64| review papers that show the number of citations, how often
346.4|3.04| transformers are cited and how many models are out there. And
349.44|2.88| it's also an exponential growth. So it's a very, very popular
352.32|3.88| field. But of course, this is something that is not feasible
356.2|4.88| for normal human being to train 8.3 billion parameters, then
361.08|3.54| nowadays, also models or research groups focusing on
364.62|3.14| developing small transform models. In any case, this is
367.76|3.8| just like big picture showing that transform models are
371.56|3.08| interesting, there are many different flavors, we are talking
374.64|3.36| about this foundational one, attention is all you need. And
378.0|3.66| if you're interested, you can follow up with some other
381.66|4.5| models. Later, I will also briefly talk about GPT two, and
386.52|4.08| the the bird model, which are also kind of foundational
390.6|4.64| models. The main concept behind that, because they are they are
395.24|3.2| using self supervised learning techniques that have been also
398.44|5.52| then adopted in other types of transformers. Okay, coming back
403.96|6.16| to the self attention mechanism. So before I talk about the self
410.12|3.28| attention mechanism that is used in the transformers, I wanted to
413.4|4.24| cover a very basic form of that, just to introduce the topic
417.68|4.52| slowly. So, this very basic form, we can think of it as a
422.2|4.8| procedure consisting of three steps. So the first step is
427.24|3.92| deriving the attention weights, which are a form of similarity,
431.16|5.16| or compatibility between the current input. So current input
436.32|2.64| in the sequence, one sequence element, you can think of it as
440.4|6.76| a word in the sentence, and all other inputs. So the similarity
447.16|4.6| between a given word and all the other words in the sentence. So
452.04|2.76| once we will show you how we derive the weights in the next
454.8|2.96| slide. So once we have the weights, we normalize them by
457.76|3.16| the softmax function, this is similar to what we have done in
460.92|3.42| the RNN, by the way, when we computed the normalized
464.34|5.02| attention weights. And then we will step four here compute the
469.36|3.6| attention value from the normalized weights and the
472.96|4.92| corresponding inputs. So this whole thing looks very similar
477.88|2.8| to what I've shown you before with the RNN. So the RNN
480.68|4.24| attention mechanism. So also here we have as the attention
484.92|11.12| value here, we have a weighted sum here. So this year x j is an
496.04|6.6| input, a word, we assume we have t words in our sentence. And so
502.64|6.8| for each word, we have attention weight. So let's call this word
509.44|6.8| j to j t. So we have t words in our sentence. And then no, it's
516.24|7.84| a bit unfortunate because I was hiding this. Okay. So word j.
524.52|4.88| And this one here, you can see this is i j. So the i is for
529.6|7.08| ith word. So this is an attention weight for the
536.68|4.52| relationship between the i th word and word j. And you use
541.2|5.6| that to compute this attention value for the i th input for the
546.8|3.56| i th word in the sentence. So it's maybe a bit dense here in
550.36|3.76| terms of information. So let's look at this on step by step.
554.12|3.16| And I will also show you how these attention weights these
557.6|5.24| ace here are computed. So here at the top, I have again what
562.84|4.44| I've showed you on the previous slide where we compute the output
567.28|4.2| corresponding to the i th input to the i th word. So if every
571.48|3.92| time I write input here, i th input, I mean, for instance, a
575.4|7.16| sentence and i th input would be the i th word. And how do we
582.56|4.8| now compute these attention weights. So in this simple, very
587.36|4.12| basic form of self attention, just for introductory purposes,
591.48|6.4| let's assume we compute this as the dot product between here,
598.36|9.36| the i th input word, and word j. So let's say, word i and word
608.12|5.16| j. And then we repeat that for all the inputs in the sentence
613.28|8.44| for all the words, the t words. So we get e, i, one, e, i, two, e,
621.84|10.28| i, three, up to e, i, t. And then we compute the normalized
632.12|6.08| form using the softmax function. So then all these normalized
638.2|3.76| ones will sum up to one. And these will be then our attention
641.96|4.12| weights. Yeah, so to summarize the previous slides, here's a
646.08|4.2| visual representation of what we have just talked about. So
650.28|3.8| assume we have this input sequence here. So here, the input
654.08|5.88| sequence, you can think of it as a sentence. In each x here, each
659.96|4.88| vector represents a word. So I said vector because this is an
664.84|3.28| embedding, so an embedding of the word. And yeah, we have
668.12|3.56| talked about this in the context of RNNs, where we, for instance,
671.68|4.0| convert the word into an integer index, and then we retrieve the
675.68|3.24| embedding from an embedding matrix. So the embedding is
678.92|5.56| essentially just a continuous valued vector for each particular
684.48|7.68| word. And then we compute in step one, the similarity with
693.04|3.2| let's call that the query, the current input, let's call it
696.24|8.2| that query. And here, for instance, I could be one. So the
704.44|4.4| first, first word here, for instance, so we would do that
708.84|3.84| with every word. But we would start, let's say with the first
712.68|4.6| word, then walk through step one, step two, step three, and
717.28|2.2| then we would move on to the second word and do the same
719.48|4.32| thing with step one, step two, and step three. So here, the
723.8|3.32| output is AI equals one for the first step. And then for the
727.12|3.56| second step, it's two, and then we would stack them all up. So
730.68|7.0| we would get essentially a matrix here, I'm getting a little
737.72|2.96| ahead of myself here. So explaining one thing at a time.
740.96|3.88| So we use this, we can use a dot product to compute the
744.84|4.8| similarity. Why dot product? Well, that's just one way we can
749.64|2.88| compute this compatibility or similarity between two vectors,
752.52|3.2| we could also consider other functions like cosine
755.72|3.08| similarity, it's essentially just a normalized dot product.
759.24|3.04| But let's say, give things simple, it's we use a dot
762.28|4.36| product. So we compute the dot product here between the query
766.68|5.04| x i, and each other word in the sentence, right? So notice it's
771.72|5.52| x one here, x two. So for each one, we compute this similarity,
777.24|2.94| which is a scalar, right? So each each thing here is a
780.18|5.76| scalar, single number. And then we put that through the softmax
785.94|2.64| function, so that they are normalized. So we have now our
788.58|4.84| normalized attention scores here, which are then values
793.42|7.12| between zero and one, and they sum up to one. I'm sorry, it
800.54|9.66| should be t here. Okay, um, from my quotes, one to t. Anyways,
810.34|4.6| so and then we sum them up here. So we have the attention values,
814.94|6.8| which is a vector, right? Because x, x, j is a vector. So
821.78|5.36| xj are our inputs, words. So we are going here from xj to xt. So
827.14|3.92| we are going over all the inputs here. So we are now waiting the
831.06|7.04| inputs with this corresponding. So what we're doing is we wait
838.1|5.12| this input, and then we add it to this weighted input and add
843.22|3.32| it to this weighted input and add it to this weighted input.
847.82|3.28| And then this gives us a vector, right, because we are adding
851.1|6.08| them. And this vector is essentially just like a word
857.18|3.44| embedding, except that it contains no information about
860.62|3.8| the whole sequence. So this original word embedding here only
864.42|4.6| contains information about the word itself. So no matter where
869.02|3.56| the word is in the sentence, and no matter what the sentence looks
872.58|6.96| like, to start with the word, let's say the word Hello, would
879.54|2.88| always have the same embedding when we put it into the model.
882.62|2.76| That's also in the RNN. When we have the embedding, we'll always
885.38|4.48| have the same value, no matter where it is in the sentence. If
889.86|3.04| it's the first word, the second word, the last word, and no
892.9|5.24| matter what the other words are. But now in contrast here on our
898.26|6.84| output here, if we have the query as word one, it is also a
905.1|5.52| representation of this word, let's say hello, except it
910.62|5.68| contains information about hello, in the context of all the
916.3|3.8| other words, right, because we have this, this waiting step
920.1|3.84| here going on. So we have now a more powerful context of where
923.94|5.0| embedding vector. So what we did is essentially in terms of
929.82|3.16| extracting information instead of just considering each word
932.98|5.44| individually, we are we now have representations of words, aware
938.46|4.52| of its context. So this is like, what I call a very simple,
943.18|2.8| basic form of self attention. This is, of course, not what is
945.98|2.68| used in the transformer, but it's just to introduce the
948.66|3.84| topic. So and then in the next video, we will look at the more
952.58|3.2| sophisticated version. But I think, yeah, this one kind of
955.82|4.56| summarizes the whole concept, I mean, not the whole concept, but
960.38|4.2| one of the main ideas behind attention, like deriving the
964.58|3.12| context. Alright, so in the next video, let's take a look at the
967.7|23.24| look at the more sophisticated version then.