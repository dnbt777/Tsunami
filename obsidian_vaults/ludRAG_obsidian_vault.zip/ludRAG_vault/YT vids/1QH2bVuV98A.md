start_time|end_time|text
1.52|3.02| Yeah, so in this video, I want to now talk about this
4.68|3.36| iterative training algorithm that I mentioned in the previous
8.04|2.76| video. So we will be talking about training and linear
10.8|3.64| regression using an iterative algorithm. This is also the
14.44|3.58| first part, we will come back to that later on, when we talk
18.02|3.1| about gradient descent, so yeah, just want to give the general
21.12|4.08| outline. So one way we can use an iterative algorithm to fit
25.22|4.1| least squares linear regression models is by using brute force.
29.32|3.98| So this would be what I call or think of as a very naive way to
33.3|3.04| fit a linear regression model, or any type of neural network.
37.18|3.42| So what we can do is we can start by initializing parameters
40.6|4.46| to all zeros. So the weights and the bias, or small random
45.06|4.52| numbers, and then we have a for loop here for k rounds. So let
49.58|3.38| me use a different color for that. So for k rounds, we can
52.96|6.1| then choose another random set of weights. And then we look at
59.06|3.76| the predictions of the linear regression model. And now, if
62.82|4.48| the model performs better, we keep those weights. And then
67.54|5.36| we go back here. So this is like iteration k times, every time we
72.9|5.12| find better ways we keep those. If the weights are worse, so if
78.02|3.28| the model with the weights performs worse, we actually
81.3|2.68| discard them. So we only keep the weights if they're actually
83.98|2.72| better than before. And yeah, if you do that many, many, many
86.7|2.92| times, this approach is actually guaranteed to find the optimal
89.62|2.52| solution, right? Because yeah, you do this many, many, many
92.14|3.2| times. And if the model can only improve, eventually, just by
95.34|3.64| luck, you will find a great set of weights, the optimal weights.
99.46|3.64| But as you can think, or as you can imagine, this would be a
103.1|3.58| very, very inefficient and terribly slow way of fitting a
106.68|3.1| linear regression model. So I would not recommend doing this
109.78|2.72| in practice, although in practice, it works, it's it's
112.5|2.28| not a good way to fit a linear regression model.
114.78|3.32| Yeah, so luckily, there is a better way for fitting a linear
118.1|3.88| regression model iteratively. So what we can do is we can analyze
121.98|3.48| what effect of change a parameter has on the predictive
125.46|3.0| performance of the model. So we can take a look at the squared
128.46|3.04| error loss and see when we change the weight and the bias
131.5|5.36| in a certain way, how it affects these errors. And then we can
136.86|3.04| make a small change. So we can change the weight and bias a
139.9|3.2| little bit in the direction that improves the performance. So if
143.1|2.8| we understand the relationship between the weight and the loss,
146.14|3.2| we can change the weight such that the loss goes down. So we
149.34|4.92| have a smaller error. And we can then do this several times in
154.26|4.56| small steps until the loss is not further decreasing. So one
158.82|3.36| by one, we will change the weight such that loss decreases.
163.62|3.32| It turns out that this is actually the online mode that we
166.94|4.28| talked about. Yeah, just written a little bit differently. So on
171.22|3.6| the left hand side, we have again the online mode mode for
174.82|4.88| the perceptron learning rule. So where we iterate over the
179.82|4.56| training epochs, and then for every training example, we
184.38|3.52| compute the other prediction, compute the error, and then do
187.9|4.32| the update here. So for linear regression, there's an algorithm
192.22|4.68| called stochastic gradient descent. So stochastic gradient
196.9|4.2| descent is the analog of the perceptron learning rule for
201.38|2.8| convex loss functions here, we can also use it for non convex
204.22|2.64| loss functions for neural networks, that will be
206.98|3.2| something we will cover in the next lecture. So here we will
210.18|3.68| focus on the linear regression model. And then at the end of
213.86|5.0| this lecture also at on the adaptive linear neuron. So what
218.86|4.44| is similar and what is different? So again, so we have
223.3|3.68| the same weight initialization here, let me use a different
226.98|3.88| color for things that are the same. So weight initialization
230.86|3.28| is the same, we also iterate over the training epochs. Then
234.14|3.48| we also iterate over the training examples in a data
237.62|4.0| set. We also compute the predictions the same way.
241.94|2.52| Because yeah, like I mentioned in the previous video, the
244.46|1.96| perceptron and the linear regression model, they both
246.42|3.04| compute the net input here. Except here, we have the
249.46|3.96| threshold function and the perceptron. And let me use right
253.42|2.76| here, that would be the threshold function, the case of
256.18|3.6| the perceptron. And here, this would be an identity function.
266.26|6.52| This is the threshold. And yeah, inside here, this is the net
272.78|7.36| input. This is oops. I don't know what it is with curly
280.14|5.68| brackets, but I can't draw curly brackets. Okay, so Z, the net
285.82|3.32| inputs on they are computed exactly the same way. This
289.14|2.8| function is an identity function, in the case of linear
291.94|2.28| regression and threshold function, the case of the
294.22|6.56| perceptron. Now, for the perceptron, we compute this this
300.78|4.8| error here by just subtracting the predicted value from the
305.58|3.88| actual class table. In linear regression, we have continuous
309.46|4.16| value, but it's very similar. So also here, we have a
313.62|4.84| subtraction for the weights, we multiply this by x by the input
318.46|5.24| feature vector. And for the bias unit, we don't. So if you're
323.7|4.24| wondering what these symbols here mean, so this labla symbol,
327.94|4.24| this stands for the gradient. So here, we are computing the
332.18|3.92| gradient of the loss of the gradient of the loss l was
336.1|5.0| curly l l here with respect to the weights here. So this is the
342.34|8.64| gradient of let me spell this out gradient of the loss
350.98|12.72| function with respect to the whoops weights. And then here at
363.7|3.88| the bottom, this is the same also also the gradient of the
367.58|4.8| loss with respect to the bias unit here, or derivative. So
374.54|4.76| yeah, so you can see, this is closely related to what's going
379.3|6.36| on in the perceptron. And in step C, now we do the update. So
385.66|7.48| the update is a little bit different here. So on the left
393.14|4.82| hand side here, we have the current weight. And then we
397.96|5.1| multiply the error with the feature vector. We don't do this
403.06|2.96| on the right hand side, we have done something like multiplying
406.02|3.4| with a feature vector up here. But here, now what we do is we, we
409.42|6.96| add another term here. And this term, eta is a scalar, it's a,
416.94|4.0| we are scaling something. And this is the so called learning
420.94|7.04| rate. So let's call that the learning. Right, it's just a
427.98|4.8| scaling term. And in the parentheses here, this is the
432.78|4.16| negative gradient. So I also wrote it down here. So we have
436.94|3.96| the negative gradient, we now update the parameters by the
440.9|4.08| negative gradient. So it's kind of similar to what's going on
444.98|4.4| in the perceptron, except that the way we get this gradient is
449.38|3.36| based on calculus. And in the next couple of minutes, I will
453.1|2.88| give you a brief calculus refresher to explain where this
455.98|3.64| comes from. So here, we are really computing the negative
459.62|3.4| gradient of the squared error loss with respect to weight and
463.02|3.64| the bias. And on the in the perceptron case, this is, it
466.66|1.84| looks very similar, it's a little bit different, because
468.5|2.52| it's not depending on calculus, here, we have the threshold
471.02|5.48| function. And depending on how fresh your calculus skills are,
476.74|3.96| you know that for non smooth functions, like threshold
480.7|3.04| functions, we can't compute derivatives. So in that way,
484.5|4.52| it's somewhat related, and very similar, but there's a little
489.02|6.16| little detail. Okay, so yeah, one more slide, I just see I
495.18|4.16| have here. So on the left hand side, we are I showed you
500.02|4.44| vectorized implementation of this linear regression online
504.46|4.12| mode. So where we had vectors, so x here is a vector, for
508.58|4.4| example. And the gradient is a vector, but we can also kind of
514.54|3.88| unroll this using a for loop. So this way, we don't need
518.42|5.72| gradients, we can just talk about partial derivatives. So in
524.14|4.68| order to simplify this as a for loop, we would just look at one
529.86|4.72| feature at a time or one weight at a time. So if we have a data
534.58|4.92| set, where our dimensionality of the inputs is m, so we have m
539.86|4.72| features, what we can do is then for each weight, so the number
544.58|2.88| of weights is equal to the features, right? Because if I
547.46|7.04| have my inputs, x one, x two, x three, then here, they go into
554.5|5.08| my net input function, and each input is associated with a
559.58|5.04| weight, right? So I'm not drawing the bias here. But yeah,
564.66|4.36| each input is associated with a weight. So we have m weights,
569.1|3.44| and I can for each weight separately compute the partial
572.54|3.84| derivative of the loss with respect to that weight. So it's
576.38|3.96| the analog of this one here, not using any linear algebra now
580.34|3.88| just using partial derivatives instead of gradients. And then I
584.22|3.16| can do also the update the same way. So here, this is just a
587.38|4.24| for loop version. I think, yeah, this is maybe conceptually a
591.62|2.68| bit easier, because partial derivatives are maybe easier to
594.3|2.88| think about as compared to gradients. I mean, it's the same
597.18|3.52| thing. But instead of talking about gradients, we could also
600.7|4.68| talk about partial derivatives. However, like I explained in the
605.38|3.96| previous lecture, vectorized implementations are faster,
609.5|4.36| which is why we usually use gradients and vector based
613.9|5.4| implementations. So the learning rule from the previous slide now
619.3|4.12| is called stochastic gradient descent. I was showing you this
623.42|2.52| learning rule, but I didn't show you where this learning rule
625.98|4.32| came from. So where how did I derive this learning rule? So in
630.3|4.16| order to understand that, yeah, there's some little calculus
634.46|4.12| required. I think most of you already took calculus classes,
638.58|3.96| because that was a prerequisite for this class. If you are a
642.54|2.64| little bit rusty, I have two bonus videos, I will be
645.18|4.32| recording after this video. So you can maybe refresh your
649.5|4.4| calculus skills, but it's not necessary. So you can also jump
653.9|4.92| ahead to this video where I will explain where the learning rule
658.82|3.28| comes from. And if you like, you can watch these two videos where
662.1|2.64| I go over some of the calculus concepts.