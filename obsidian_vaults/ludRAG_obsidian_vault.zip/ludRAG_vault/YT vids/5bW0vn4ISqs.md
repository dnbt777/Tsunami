start_time|end_time|text
0.4|3.44| Yeah, as promised, let me now show you a brief code example
3.84|4.56| illustrating the concept of the cross entropy in code using
8.4|4.64| pytorch. So I have prepared a notebook I will share it with
13.04|4.16| you, you can find the link as usual on canvas, or here just
17.2|6.4| on GitHub. So we execute this just regular boilerplate. So
23.6|2.92| here I have a function for implementing the one hot
26.52|3.84| encoding in pytorch. It looks a little bit arbitrary with this
30.48|4.98| scatter function. I don't really need to get go over this because
35.46|3.38| I think there's no other context where I think this scatter
38.84|2.74| function is really that useful. So you don't have to really
41.58|3.94| memorize how this works. If you ever need a one hot encoding
45.52|3.04| yourself, you can just copy and paste this function, it will do
48.56|5.16| it for you. And also, um, when we do train a softmax
53.72|2.54| regression model later, I will show you also code example for
56.26|2.46| that. And the same for multi layer perceptrons, and so
58.72|4.8| forth. On the loss functions in pytorch, they already do the one
63.52|3.28| hot encoding for you. So you actually never have to worry
66.8|3.8| about it yourself. But if you ever have to do it yourself,
70.8|3.22| you can just copy and paste this function. So this is just how it
74.02|2.86| works. This is exactly the same example that I showed you on the
76.88|6.4| slides where we have the class labels 0122. And I have a total
83.28|3.84| number of class labels here, this is the highest class label,
87.28|3.28| or the number of classes, the same thing. So here we have
90.6|4.64| three possible class labels, right? 01 and two. Also note
95.24|2.64| that your class labels should always start with zero. So in
97.88|2.88| this case, yeah, what we get back is for the four training
100.76|3.88| examples here, four rows, and each has this indicator,
104.64|4.8| whether it's this class, the one is denoting the class, and zero
109.48|2.76| is, yeah, it's just a placeholder. So for the first
112.24|2.64| training example, this represents class zero, class
114.88|4.28| one, class two, and class two. Then here's this softmax
119.18|3.26| activation. Sorry, this is actually the net inputs. So this
122.44|6.92| is a matrix of net inputs, I created them just arbitrarily. So
129.56|2.64| each row is again, for each training example, we have four
132.2|4.08| training examples. So we have four rows, and this is how our
136.28|4.16| net inputs might look like. So these are if I go maybe to the
140.44|6.96| slides, these are the net inputs here, these. And then now we have
147.4|4.04| to apply this softmax here, and then we get these activations.
152.24|2.88| So yes, just for reference, how the softmax function looks like.
155.76|3.72| And he has a code implementation of the softmax function. So
159.48|2.88| again, there is actually a softmax in pytorch. So you
162.36|3.24| actually shouldn't use your own implementation, because in the
165.64|3.72| implementation pytorch is more efficient, faster, it's more
169.36|3.36| optimized, but it's here again, to just illustrate how it works.
172.96|5.48| So what we have is in the numerator, this exponential term,
178.84|4.84| so when I go here, e to the power of z, and then in the
184.12|4.16| numerator, we sum over these exponential terms for all the
188.28|4.36| activations, if we have three classes, it will be a sum over
192.64|10.08| three. So that's what we have here. Now let's do that. So we
202.72|4.36| have our Z here, we have three classes 123. And for training
207.08|6.16| examples 1234. So these are then the softmax activations that
213.28|4.56| yeah, that we get back, notice that the columns should sum to
217.84|10.84| one, can just double check that. So you can see they all sum to
228.68|6.84| one, no columns. Looking good. All right, now, just to
235.52|3.6| illustrate how we get the class table. So if we look at this one
239.12|4.24| again, I mentioned we have an arc max here, arc max is, you
243.36|3.36| can think of it, maybe I should demonstrate this. It's giving
246.72|7.12| you the position of the highest value. So if I have an example,
254.92|7.52| say torch 10, so 1234, the arc max would be the highest value.
262.44|4.12| So in this way, the arc max should give me 0123, the value
266.56|7.04| three. Um, that's weird here. Okay, what's going on? Oh, okay.
273.6|5.64| Sorry, I think I should for here. So yeah, I was just not
279.24|2.72| paying attention. All right. So this gives me the value three as
281.96|4.6| expected. So if I put a five here, this would return zero
286.56|3.0| now, because now the zero position has the highest value.
290.6|2.8| If you have a tie, I honestly don't know what happens when we
293.4|3.88| have a tie, but I suspect is it will pick the first value, the
297.28|5.8| lower value. Yep, that's exactly the case. So if we have a tie,
303.08|9.08| tie, it will always pick the lowest value. Okay. So, but in
312.16|1.8| practice, it will be very unlikely that you have a tie
313.96|4.48| here. I mean, might happen. But I mean, that could be something
318.44|2.48| like this for the other classes where we have a tie. But
320.92|5.08| usually, it's it's rare. All right. And this is also only a
326.0|4.36| tie, because I put this as a tie. Usually, it's very rare
330.36|3.08| that you have exactly the same values, because that means that
333.44|4.0| the feature vectors look exactly the same. And the weight vectors
337.44|1.96| are exactly sorry that the weight vectors are exactly the
339.4|5.0| same. All right. Yeah, let's convert this to class labels.
344.56|6.44| This is just to double check. So this these were all true
351.0|2.68| labels. From the one that encoding is just to double
353.68|4.84| check that we that this one indeed converts back to this
358.52|4.68| one. And here, these are our predictions. So we use the arc
363.2|2.6| max to get the column with the highest probability. So we get
365.82|7.02| this one, this one, this one, and this one. And you can see,
373.8|3.48| there's one wrong prediction, if we would compare those right,
377.52|4.04| zero and zero, this is correct. One and one is correct.
382.2|2.84| predicted class able zero, the true labels to this is
385.04|3.44| incorrect. This one is correct. So we make one mistake,
388.48|4.44| actually. So it's also, I mean, I did this on purpose to show
392.92|3.8| you how this whole thing works. Because if we wouldn't make a
396.72|2.48| mistake, we would get a loss of zero, which would be kind of
399.2|3.76| boring, I think. Alright, so yes, again, the cross entropy,
402.96|5.8| again, recall that there are two sums. So if I go back here, so
408.76|3.08| we have these two sums here, I kind of entangled them a little
411.84|5.08| bit. So we have, this is a sum over the training examples. And
417.08|4.52| this one is the cross entropy for the 100 encoding. So this
421.6|6.04| one is the inner, the inner one here. So let's compute first the
427.68|5.04| cross entropy for each training example. So what I'm doing here
432.72|9.88| is I'm computing these terms. I actually said that this loss
442.6|5.24| will be zero. But that, I don't know why I said that the loss,
447.84|3.92| even though you match the right class labels shouldn't be
452.16|5.04| necessarily be zero, except if your activations match exactly
457.2|5.0| here, one hot encoding matrix. Because remember, from the
462.2|3.84| logistic regression lecture, we want to maximize the probability
466.08|3.76| for the correct class. But it's only maximized if the
469.84|3.88| probability is 100%. Right? So here, even this is correct, even
473.72|4.6| if zero is the right class, this is not 100% probability. So
478.32|4.12| here, we still have a loss, right? Because it's minus lock
482.44|5.48| lock point 37. Just want to clarify, sorry. Where were we?
488.8|3.72| Yeah, so here for the training examples, the losses we get is
492.56|7.84| point 96.88 1.05 and point eight three. So this is computing
500.4|4.84| this one, really the inner loop. So these correspond to these
505.24|7.32| computations here. Alright, so that is how we would implement
512.56|4.4| this. Now, maybe I can just briefly show you also how that
516.96|2.8| looks like we are just taking the lock of the softmax
519.76|3.08| activations, and then multiply it by the target. And remember,
522.84|2.32| the targets are just zeros and ones, right?
527.68|4.44| Define it, that's interesting. Oh, it's in, sorry, it's should
532.12|3.6| be, I'm calling it as y ang, which gets passed to y targets.
535.72|7.08| So let me print like this. So it says zeros and ones. So I can
542.84|4.32| maybe also print it if you're curious. So this would be one
547.16|6.66| value and the other ones should be zeros. So one value, and the
553.82|4.4| other ones zeros in each row, there's only one value that is
558.22|3.48| not zero in each row. And then we are summing, we're just
561.7|3.74| summing over these, this is the auto sum here. So the first row
566.56|5.04| would be on point 68. So and so second row would be point eight,
571.6|3.2| eight, then 1.05. This is actually what we see here,
574.8|3.04| right? So the summing is actually just selecting, it's
577.84|10.48| just selecting the value here. Okay. Yeah, I'm cleaning this up
588.32|2.76| here. Because when I upload this, so you have the clean
591.08|4.12| version without my weird interjections here. Alright, so
595.2|8.08| in pytorch, there is a function called NLL loss, which takes the
603.36|5.24| lock softmax as input. So this function, the negative lock
608.6|6.64| likelihood loss expects the lock of the softmax values. I'm just
615.24|2.62| saying that we will use them in practice, we will actually use
617.86|2.7| the cross entropy in practice. But I'm trying to explain how
620.56|3.24| these functions and pytorch work. So you can see this
623.8|4.84| negative lock likelihood loss is the same as our cross entropy
628.64|5.9| here. Like I explained in when we go up, I think I had a video
634.54|5.58| on that in logits and cross entropy. So where I mentioned
640.12|2.72| that the negative lock likelihood and binary cross
642.84|3.88| entropy equivalent in pytorch, it's actually the negative lock
646.72|3.04| likelihood and the multi category cross entropy
649.76|4.7| equivalent. I mean, in a way, you can also think of it as a
654.46|2.9| multi category one, the multinomial logistic regression,
657.36|5.72| then this would be still true. So they are equivalent. But
663.08|4.36| notice, it's really important to pay attention to this is that it
667.44|5.76| takes the lock softmax as input. So this might be counter
673.2|6.76| intuitive, because there's already a lock inside, right. But
681.12|4.56| the pytorch version does not perform this lock here, it
685.68|7.44| expects that you perform it for pytorch. So pytorch really
694.24|2.84| thinks you provide the serious input instead of the
697.08|3.66| activations. Just want to clarify this, it's important to
700.74|4.22| note because here we give the softmax as input. Here, we give
704.96|4.94| the lock softmax as input. Right? Because when I just give
709.9|3.66| the softmax input, I will get wrong results, I will get some
715.16|4.24| just luckily, my glass was empty. Alright, sorry. Um, so
719.4|3.08| you notice that now we have negative values here, right? So
722.48|4.72| this is not what we want. So you have to pay attention that this
727.2|3.44| is actually the lock. It's I'm just emphasizing this because
730.64|2.68| it's a common mistake in practice when people implement
733.56|4.04| deep neural networks, they accidentally sometimes provide
737.6|2.32| the wrong inputs and then get weird results. And then the
739.92|5.58| networks are not training. In practice, actually, I recommend
745.52|3.62| using this cross entropy function over the negative log
749.14|4.94| likelihood function. This is numerically more stable. So if
754.08|2.64| you train a deep neural networks, the gradients and
756.72|2.48| everything will be more stable. If you use that one,
760.12|5.04| mathematically, everything would be equivalent. If we use negative
765.16|3.68| log likelihood loss or cross entropy in pytorch. But
769.16|3.52| numerically, like stability wise on the computer, the cross
772.68|5.52| entropy one is more stable. So and also for this one, really pay
778.2|3.84| attention to this one, it's taking the logits as input. So
782.04|5.16| it's taking our net inputs as input. So here, again, this is
787.28|4.88| our net input matrix. When we compute the cross entropy,
792.16|2.92| because we use the mathematical formulas, we compute first the
795.08|4.0| softmax. And then from the softmax, we compute the cross
799.08|5.56| entropy in pytorch, they do all that work for us inside this
804.64|4.92| function, they do it for us. So here, we give it the net inputs.
809.56|5.8| And you can see, our function takes the softmax, it gets the
815.36|4.76| same results as these other functions, right? So they should
820.12|3.36| be all identical. But in practice, this is more stable, I
823.48|5.64| recommend using this one. And notice that I said, redact
829.16|5.32| reduction to none, which means it does not apply the sum or the
834.48|5.28| average, which is this outer one here. So by default, when you
839.76|3.96| use this cross entropy, it will perform the average, you can
843.72|4.52| test it like this, see, it's the same same value. If you wanted
848.24|4.6| to, you can also say reduction to consider reduction to some.
855.24|6.6| Sorry, should be like this. So you can see, you can also do the
861.84|3.72| can also do the sum, it's equivalent. But in practice, I
865.56|3.36| recommend using the mean because I like I said, it's more stable
869.16|2.22| in terms of choosing a good learning rate, it's easier to
871.38|2.7| find a good learning rate if you use the mean compared to the
874.08|4.04| sum. Right. So this is like a code example of how all these
878.12|5.04| types of loss losses in pytorch work. I recommend you just to
883.16|4.0| play around with that. When we implement the softmax regression
887.16|3.96| in a later video, I will use this function. And also when we
891.12|2.96| use later on, multi layer perceptrons and convolutional
894.08|4.12| networks, we will be using this function. Alright, so and then
898.2|4.08| in the next video, I will go over how we compute the
902.28|19.44| gradients for softmax regression.