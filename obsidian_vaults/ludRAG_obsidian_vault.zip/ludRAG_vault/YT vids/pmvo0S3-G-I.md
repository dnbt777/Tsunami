start_time|end_time|text
0.74|3.88| All right, before we get to the code example here, I want to
4.62|3.36| talk about two more things. One is the loss function. And one is
7.98|3.24| the lock bar trick, which I will talk about in this particular
11.22|3.4| video. And yeah, it's kind of like a chicken egg problem.
14.62|2.68| What do we want to talk about? First, you want to see the code
17.3|2.8| example first, and then explain the details. Or should I
20.1|2.88| explain the details? And then we talk about the code example,
23.22|4.6| think in this particular order, briefly talking about the lock
27.82|3.2| bar trick, and then revisiting it in the code example might be
31.02|4.8| easier. So let me start with this one. And so what this is
35.82|3.52| about is the fact that we are training a variational auto
39.34|4.32| encoder, which is still a neural network for which we want to use
43.72|3.9| back propagation. But yeah, if we have a probability
47.62|3.96| distribution, how do we back propagate with a probability
51.58|2.6| distribution, right? Or if we have a random variable, how do
54.18|4.36| we deal with that using back propagation. So this is where
58.54|2.68| the lock bar trick will come into play. But let me just
61.22|5.16| briefly recap something from the previous video. So just to
66.38|3.16| recap the previous video, we discussed that we take the input
69.54|3.2| data set. And when we train the variational auto encoder, it
72.74|5.08| will happen such that the latent representation will resemble or
78.34|3.24| will be according to a standard multivariate Gaussian
81.58|3.1| distribution. So distribution of this latent space will follow a
84.68|3.94| standard multivariate Gaussian distribution. So here's just a
88.66|4.16| reference again, the probability density function. And in this
92.82|5.12| particular case, I was drawing a 2d Gaussian. And we have a mean
97.94|3.88| vector, and a covariance matrix. And we said that this is because
101.82|5.04| it's a standard normal distribution, it's zero mean, and
106.86|2.28| unit variance, and there's no interaction between the
109.14|4.84| features. So we essentially have a variance vector that is just
113.98|7.6| one one in each dimension. Yeah, and then when we sample, so
121.58|4.08| this is maybe a little bit tricky part to wrap our heads
125.66|4.56| around this fact. So we sample in the following way. So in the
130.22|4.9| network, we will have a fully connected layer that will learn
135.12|6.68| this mean vector. And there will be a fully connected layer that
141.8|3.58| will learn this variance vector, at least in theory. And how we
145.38|4.42| sample is then we use this epsilon that we sample from a
150.48|4.08| standard normal distribution. So with no interaction between
154.56|3.84| these features, so we just draw for each dimension value from a
158.4|3.8| random standard normal distribution. And we multiply
162.2|3.88| this value with our standard deviation here and add the mean
166.08|6.0| vector. And this is how we get a new sample. So essentially, we
174.12|8.44| encode, so if we have x, we encode, let's call this how can
182.56|6.08| we call it, let's just call it the mean vector. And say the
188.64|6.44| variance vector. So when we put our example, through the encoder,
195.72|5.6| we get these two vectors. So that's what we are learning in
201.32|8.44| the network. And then we will have the step where we have the
209.76|4.92| mean plus the standard deviation vector times this epsilon, this
214.68|4.84| one, this epsilon is sampled independently, though it's sampled
219.52|3.24| independently from our standard normal distribution with the
222.76|3.36| identity matrix as the covariance matrix. And then we
226.12|4.56| put it in here. And only only this part is part of the
230.68|2.64| network. Then we have
233.32|16.52| the decoder. And then what comes out of here is x prime. And like
249.84|3.64| I mentioned before, we compute the distance or difference
253.48|4.24| between those two, to make sure the reconstruction is good. And
257.72|2.88| here for this latent space, which is essentially
260.6|3.84| represented by this mean vector and the variance vector, we want
264.48|4.4| this to be normal distributed. So we have this KL divergence
268.88|3.96| term, I will talk about this again in the next video. So we
272.84|3.52| have these two objectives. But yeah, in essence, we have here
276.36|2.88| the mean vector and the variance vector as part of the network.
280.16|3.48| Again, if this looks a little bit abstract right now, in the
283.64|4.04| code example, you will exactly see how that works. Alright, so
287.68|3.64| but instead of using this variance vector here in the
291.32|6.2| network, we are using the lock variance. Why are we doing that?
298.2|4.84| This will allow us for positive and negative values. So in this
303.04|2.6| way, if we only had a variance vector, there could only have
305.68|3.28| positive values. And it's kind of a bit tricky, I would say to
308.96|2.2| learn this during black propagation, to make the
311.16|4.24| learning a bit more stable or better, we will use the lock of
315.4|5.52| this variance vector. And then we will sample as follows as
320.92|3.0| shown here on the bottom. So instead of sampling what I showed
323.92|8.88| you before, instead of saying, we draw the sample like this, we
332.8|8.04| now replace this one by e to the power of log of the variance
340.84|6.8| vector divided by two. Why is it this one here? Yeah, this is
347.64|5.48| just, you can see that if you just rearrange the terms, so
353.36|3.76| this one, you can bring the two outside, right? So it's the same
357.12|3.32| as two times log of the variance, sorry, log of the
360.56|4.24| standard deviation. And if you want to then write just this log
365.28|3.36| of the standard deviation, you can cancel the tune. So on the
368.64|5.0| left hand side, you have log variance divided by two. And
373.64|6.0| then if you take this to the palm, so the exponential e to
379.64|5.96| the power of log, this one should be of course, this one,
385.6|7.04| right. And we know that this one is the same as log, sigma
392.64|7.12| squared. So we know that this is essentially then look, whatever
399.76|6.04| this is squared by two. So this is why or how we end up with
405.8|4.56| this sampling procedure. And this allows us to only store the
410.52|5.64| lock of the variance vector lock variance. So okay, so this is
416.16|3.72| how we would implement that. Because then, if I go back one
419.88|7.88| more slide, pink here, sort of having this here, we will have a
427.76|6.6| vector that we call lock variance, this allows us this
434.36|3.92| vector to have positive and negative values, which is also
438.56|5.24| true for the mean vector here. Okay, so if this was abstract in
443.8|2.6| the code example, I hope this will become more clear. So the
446.4|2.88| next video, let me briefly talk about the loss function and the
449.28|3.42| variation autoencoder. And then we will finally see our first
452.7|27.3| code example.