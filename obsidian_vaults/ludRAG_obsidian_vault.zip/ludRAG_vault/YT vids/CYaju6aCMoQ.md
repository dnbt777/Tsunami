start_time|end_time|text
5.12|6.16|before we start um i gave
7.839|5.361|the same talk at stamford quite recently
11.28|3.6|um i suggested to the people who invited
13.2|3.52|me i could just give one talk and both
14.88|3.92|audiences have come but they will prefer
16.72|4.399|just two separate talks so if you went
18.8|3.44|to this talk recently i suggest you
21.119|2.961|leave now
22.24|4.16|you won't learn anything new
24.08|2.32|okay
28.24|4.319|what i'm going to do is combine some
29.84|4.559|recent ideas in neural networks
32.559|3.361|um to try to explain how a neural
34.399|4.0|network could represent part hole
35.92|4.479|hierarchies
38.399|5.201|without violating any of the basic
40.399|5.601|principles of how neurons work
43.6|4.639|and i'm going to
46.0|4.079|explain these ideas in terms of an
48.239|3.601|imaginary system
50.079|3.281|i started writing a design document for
51.84|3.28|a system and in the end i decided the
53.36|2.8|design document by itself was quite
55.12|2.72|interesting
56.16|3.36|so this is just vaporware stuff that
57.84|2.719|doesn't exist little bits of it now
59.52|2.4|exist but
60.559|3.041|um
61.92|3.36|somehow i find it easy to explain the
63.6|4.0|ideas in the context of an imaginary
65.28|2.32|system
71.04|5.04|so most people now study neural networks
74.159|3.441|so doing engineering and they don't
76.08|3.2|really care if it's exactly how the
77.6|2.64|brain works they're not trying to
79.28|3.28|understand how the brain works they're
80.24|5.04|trying to make cool technology
82.56|3.919|and so 100 layers is fine in a resonant
85.28|3.199|weight sharing is fine in the
86.479|4.0|convolutional neural net
88.479|4.161|um some researchers particularly
90.479|3.921|computational neuroscientists um
92.64|3.519|investigate neural networks artificial
94.4|3.039|neural networks in an attempt to
96.159|2.401|understand how the brain might actually
97.439|2.64|work
98.56|2.96|i think we've still got a lot to learn
100.079|3.601|from the brain
101.52|4.16|and i think it's worth remembering that
103.68|3.68|for about half a century the only thing
105.68|3.68|that kept research on neural networks
107.36|3.119|going was the belief that it must be
109.36|2.719|possible to make these things
110.479|4.6|uncomplicated things because the brain
112.079|3.0|does
115.68|5.6|so
117.84|4.8|every image has a different parse tree
121.28|3.839|that is the structure of the holes in
122.64|4.88|the parts in the image
125.119|4.56|and in a real neural network
127.52|3.76|you can't dynamically allocate you can't
129.679|3.681|just grab a bunch of neurons and say
131.28|3.52|okay you now represent
133.36|2.959|this
134.8|2.88|because you don't have random excess
136.319|2.881|memory you can't
137.68|3.44|just set the weights of the neurons to
139.2|3.6|be whatever you like what a neuron does
141.12|4.08|is determined by its connections and
142.8|3.36|they only change slowly at least
145.2|2.72|probably
146.16|2.03|mostly they change slowly
147.92|1.52|um
148.19|3.01|[Music]
149.44|3.68|so the question is if you can't change
151.2|6.52|what neurons do quickly
153.12|4.6|how can you represent a dynamic position
160.239|3.921|in symbolic ai it's not a problem you
162.08|3.519|just grab a piece of memory that's what
164.16|3.28|it normally amounts to
165.599|3.36|and say this is going to represent a
167.44|3.439|node in the past tree and i'm going to
168.959|3.28|give it pointers to other nodes other
170.879|3.601|bits of memory that represent other
172.239|4.401|nodes so there's no problem
174.48|4.08|for about five years i played with a
176.64|3.519|theory called capsules
178.56|3.28|where
180.159|3.36|you say because you can't allocate
181.84|3.52|neurons on the fly you're going to
183.519|3.201|allocate them in advance so we're going
185.36|2.72|to take groups of neurons and we're
186.72|3.76|going to allocate them to different
188.08|4.32|possible nodes in repository
190.48|4.479|and most of these groups of neurons for
192.4|4.72|most images are going to be silent
194.959|3.521|a few are going to be active
197.12|3.119|and then the ones that are active we
198.48|3.839|have to dynamically hook them up into a
200.239|5.681|pause tree so we have to have a way of
202.319|5.761|routing between these groups of neurons
205.92|3.599|so that was the capsules theory
208.08|3.519|and i had some
209.519|4.08|very competent people working with me
211.599|3.681|who actually made it work
213.599|3.2|um but it was
215.28|3.28|tough going
216.799|3.281|my view is the side is want to work and
218.56|3.52|some ideas don't want to work and
220.08|3.519|captures are sort of in between things
222.08|3.04|like back propagation just want to work
223.599|3.36|you try them and they work
225.12|4.32|um there's other ideas i've had that
226.959|4.881|just don't want to work um capsules were
229.44|4.799|sort of in between and we got it working
231.84|5.119|but i now have a new theory that could
234.239|5.441|be seen as a funny kind of capsules
236.959|4.241|model in which each capsule is universal
239.68|4.8|that is instead of a capsule being
241.2|5.36|dedicated to a particular kind of thing
244.48|4.319|each capsule can represent any kind of
246.56|2.239|thing
248.959|4.161|but hardware still comes in capsules
251.439|4.401|which are also called embedding
253.12|2.72|sometimes
256.799|3.041|so
258.239|2.96|the imaginary system i'll talk about is
259.84|2.96|called glom
261.199|4.801|and in glom
262.8|5.52|hardware gets allocated to columns
266.0|3.759|and each column contains multiple levels
268.32|2.96|of representation
269.759|3.601|of what's happening in a small patch of
271.28|3.84|the image
273.36|3.119|so within a column
275.12|3.28|you might have
276.479|3.681|a lower level representation that says
278.4|3.28|it's a nostril
280.16|3.36|and the next level up might say it's a
281.68|3.68|nose and the next level might say a face
283.52|3.76|the next level up a person on the top
285.36|4.64|level might say it's a party that's what
287.28|2.72|the whole scene is
290.16|3.759|and the idea for representing part whole
291.759|4.081|hierarchies is to use islands of
293.919|4.321|agreement between the embeddings at
295.84|4.72|these different levels
298.24|4.08|so at the scene level at the top level
300.56|3.919|you'd like the same embedding for every
302.32|4.64|patch of the image because that patch is
304.479|4.641|a patch of the same scene everywhere
306.96|4.239|at the object level you'd like the
309.12|5.28|embeddings of all the different patches
311.199|4.72|that belong to the object to be the same
314.4|2.88|so as you go up this hierarchy you're
315.919|2.321|trying to make things more and more the
317.28|2.8|same
318.24|4.08|and that's how you're squeezing
320.08|3.679|redundancy out
322.32|3.68|the embedding vectors are the things
323.759|3.44|that act like pointers and the embedding
326.0|3.039|vectors
327.199|4.0|um are dynamic they're neural
329.039|4.241|activations rather than neural weights
331.199|5.881|so it's fine to have different embedding
333.28|3.8|vectors for every image
338.96|3.36|so here's a little picture
340.72|4.479|if you had a
342.32|6.0|one-dimensional row of patches
345.199|4.401|these are the columns for the patches
348.32|2.24|and
349.6|4.0|you'd have something like a
350.56|4.4|convolutional neural net as a front end
353.6|2.96|and then
354.96|3.76|after the front end you produce your
356.56|4.32|lowest level embeddings that say what's
358.72|4.4|going on in each particular patch
360.88|3.52|and so that bottom layer of black arrows
363.12|2.88|they're all different
364.4|3.04|of course these embeddings are thousands
366.0|2.96|of dimensions
367.44|2.64|um maybe hundreds of thousands in your
368.96|4.16|brain
370.08|5.2|and so a two-dimensional vector
373.12|3.919|isn't right but at least i can represent
375.28|3.68|where the two vectors are the same by
377.039|3.521|using the orientation
378.96|3.04|so the lowest level
380.56|3.12|all the patches will have different
382.0|4.0|representations
383.68|5.04|but the next level up
386.0|5.039|the first two patches they might be
388.72|4.16|part of a nostril for example
391.039|4.081|and so
392.88|4.56|um
395.12|4.24|yeah they'll have the same embedding
397.44|3.92|but the next level up
399.36|3.279|the first three patches might be part of
401.36|2.399|a nose
402.639|2.321|and so they'll all have the same
403.759|2.801|embedding
404.96|4.48|notice that even though what's in the
406.56|5.039|image is quite different
409.44|4.0|at the part level
411.599|3.44|those three red vectors are all meant to
413.44|2.96|be the same
415.039|3.521|so what we're doing is we're getting the
416.4|4.32|same representation for things that are
418.56|4.079|superficially very different
420.72|2.8|we're finding spatial coherence in an
422.639|2.321|image
423.52|3.2|by giving the same representation to
424.96|2.639|different things
426.72|3.039|and
427.599|4.32|at the object level you might have a
429.759|3.921|nose and then a mouse
431.919|3.12|and they're the same face they're part
433.68|3.2|of the same face
435.039|3.681|and so all those vectors are the same
436.88|5.28|and this network hasn't yet settled down
438.72|3.44|to produce on the unseen level
442.24|4.959|so the islands of agreement
444.639|4.161|are what capture the past tree now
447.199|4.56|they're a bit more powerful than a parse
448.8|5.04|tree they can caps they can capture
451.759|4.241|things like shut the heck up
453.84|4.079|you can have shut and up can be
456.0|4.0|different vectors at one level but at a
457.919|4.161|higher level shut and up can have
460.0|3.52|exactly the same vector namely the
462.08|2.959|vector for shut up
463.52|3.359|and they can be disconnected so you can
465.039|4.0|do things a bit more powerful than a
466.879|4.481|context free grammar here um but
469.039|4.401|basically it's a parts tree
471.36|2.959|if you're a physicist
473.44|3.28|um
474.319|4.16|you can think of each of these levels as
476.72|4.159|an icing model
478.479|4.321|with real valued vectors rather than
480.879|3.04|binary spins
482.8|3.519|and you can think of them being
483.919|4.481|coordinate transforms between levels
486.319|4.961|which makes it much more complicated and
488.4|4.0|then this is a kind of multi-level icing
491.28|2.96|model
492.4|4.0|but with complicated interactions
494.24|3.76|between the levels because for example
496.4|3.359|between the red arrows and the black
498.0|3.919|arrows above them you need the
499.759|3.44|coordinate transform between a nose and
501.919|2.921|a face
503.199|4.72|but we'll come to that
504.84|6.039|later if you're not a physicist ignore
507.919|2.96|all that because it won't help
513.279|3.76|so i want to start and this is i guess
515.599|3.761|is particularly relevant for a natural
517.039|4.401|language course where you some of you
519.36|4.559|are not vision people
521.44|3.92|by trying to prove to you that
523.919|3.441|coordinate systems are not just
525.36|3.12|something invented by descartes
527.36|3.44|um
528.48|3.84|coordinate systems are
530.8|4.24|were invented by the brain a long time
532.32|4.32|ago and we use coordinate systems in
535.04|2.799|understanding what's going on in an
536.64|2.4|image
537.839|3.281|i also want to demonstrate the
539.04|3.6|psychological reality of parse trees for
541.12|3.36|an image
542.64|4.96|so i'm going to do this with a
544.48|5.44|task that i invented a long time ago
547.6|4.96|um in the 1970s when i was a grad
549.92|2.64|student in fact
552.88|5.04|and you have to do this task to get the
554.88|3.04|full benefit from it
559.04|5.84|so i want you to imagine on the tabletop
561.68|4.88|in front of you there's a wireframe cube
564.88|2.639|and it's in the standard orientation for
566.56|2.88|a cube
567.519|4.241|it's resting on the tabletop
569.44|6.16|and from your point of view
571.76|6.0|there's a front bottom right hand corner
575.6|3.12|and a top back left hand corner here we
577.76|2.32|go
578.72|3.76|okay
580.08|4.319|um the front bottom right hand corner is
582.48|3.68|resting on the table top along with the
584.399|4.401|four other corners
586.16|4.56|and the top back left hand corner is at
588.8|4.08|the other end of a diagonal goes through
590.72|4.16|the center of the cube
592.88|3.6|okay so far so good
594.88|3.44|now what we're going to do is rotate the
596.48|2.96|cube so that this finger stays on the
598.32|3.12|table top
599.44|3.839|and the other finger is vertically above
601.44|4.0|it like that
603.279|3.281|this finger shouldn't have moved
605.44|2.56|okay
606.56|3.2|so now we've got the cube in an
608.0|3.92|orientation where that thing that was a
609.76|4.079|body diagonal is now vertical
611.92|3.2|and all you've got to do is take the
613.839|3.44|bottom finger
615.12|3.44|because that's still on the tabletop and
617.279|3.441|point with the bottom finger to where
618.56|3.6|the other corners of the cube are
620.72|4.08|so i want you to actually do it off you
622.16|3.6|go take your bottom finger hold your top
624.8|2.719|finger
625.76|3.68|at the other end of that diagonal that's
627.519|5.281|now been made vertical and just point to
629.44|4.72|where the other corners are
632.8|3.44|and
634.16|3.359|luckily zoom so
636.24|2.48|most of you
637.519|2.88|other people won't be able to see what
638.72|4.48|you did and i can see that some of you
640.399|3.521|aren't pointing and that's very bad um
643.2|2.4|so
643.92|3.68|most people
645.6|3.76|point out four other corners and the
647.6|4.08|most common response is to say they're
649.36|4.32|here here here and here they point out
651.68|4.32|four corners in a square halfway up that
653.68|3.68|axis
656.0|4.24|um
657.36|4.479|that's wrong as you might imagine and
660.24|2.96|it's easy to see that it's wrong because
661.839|2.801|if you imagine the cube in the normal
663.2|3.52|orientation
664.64|3.36|and count the corners there's eight of
666.72|3.28|them
668.0|4.8|and these were two corners
670.0|4.8|so where did the other two corners go
672.8|4.159|so one theory is that when you rotated
674.8|4.159|the cube the centripetal forces made
676.959|4.241|them fly off into your unconscious
678.959|3.44|um that's not a very good theory
681.2|2.72|so
682.399|3.201|what's happening here
683.92|3.359|is you have no idea where the other
685.6|3.28|corners are unless you're something like
687.279|3.521|a crystallographer
688.88|3.44|um you can sort of imagine bits of the
690.8|2.8|cube but you just can't imagine this
692.32|4.0|structure of the other corners what
693.6|4.64|structure they form
696.32|5.04|and this common response that people
698.24|5.44|give of four corners in a square
701.36|4.56|is doing something very weird
703.68|3.68|it's trying to it's saying well okay i
705.92|3.52|don't know i don't know where the bits
707.36|3.84|of a cube are um but i know something
709.44|2.959|about cubes i know the corners come in
711.2|3.12|fours
712.399|4.481|i know a cube has this four-fold
714.32|4.319|rotational symmetry or two planes of
716.88|3.04|bilateral symmetry but right angles to
718.639|3.44|one another
719.92|3.68|and so what people do is they preserve
722.079|2.801|the symmetries of the cube in their
723.6|4.72|response
724.88|5.36|they give four corners in a square
728.32|3.199|now what they've actually pointed out if
730.24|3.599|they do that
731.519|4.481|is two pyramids
733.839|4.401|each of which has a square base
736.0|3.519|one's upside down and they're stuck base
738.24|3.279|to base
739.519|3.521|so you can visualize that quite easily
741.519|4.241|it's a square based pyramid with another
743.04|4.32|one stuck underneath it and so now you
745.76|3.519|get your two fingers as the vertices of
747.36|3.279|those two pyramids
749.279|4.0|and
750.639|4.721|what's interesting about that is
753.279|4.401|you've preserved the symmetries of the
755.36|5.44|cube at the cost of doing something
757.68|6.56|pretty radical which is changing
760.8|4.8|faces to vertices and vertices to faces
764.24|3.92|the thing you pointed out if you did
765.6|5.679|that was an octahedron
768.16|5.919|um it has eight faces and six vertices
771.279|4.8|a cube has six faces and eight vertices
774.079|4.56|so in order to preserve the symmetries
776.079|5.601|you know about of the cube
778.639|4.561|you've if you did that you've
781.68|3.36|done something really radical which has
783.2|3.28|changed faces for vertices and vertices
785.04|2.64|for faces
786.48|2.72|um
787.68|2.32|i should show you what the answer looks
789.2|3.12|like
790.0|4.48|so i'm going to step back and try and
792.32|4.88|get enough light and maybe you can see
794.48|2.72|this cube
798.56|4.48|so this is this is a cube
801.36|3.36|and
803.04|3.44|you can see that
804.72|3.44|the other edges
806.48|3.44|form a kind of zigzag ring around the
808.16|5.88|middle
809.92|4.12|so i've got a picture of it
814.48|4.0|so the colored rods here are the other
816.959|3.281|edges of the cube the ones that don't
818.48|3.44|touch your fingertips
820.24|3.839|and your top fingers connected to the
821.92|3.919|three vertices of those flaps
824.079|4.081|and your bottom fingers
825.839|3.68|connected to the lowest three vertices
828.16|2.88|there
829.519|3.68|and that's what a cube looks like it's
831.04|3.84|something you had no idea about
833.199|3.361|this is just a completely different
834.88|2.959|model of a cube it's so different i'll
836.56|3.279|give it a different name i'll call it a
837.839|3.841|hexahedron
839.839|4.0|and
841.68|4.88|the thing to notice is a hexahedron and
843.839|4.961|a cube are just conceptually utterly
846.56|3.76|different you wouldn't even know one was
848.8|3.599|the same as the other if you think about
850.32|4.639|one as oxygen one as a cube
852.399|4.721|it's like the ambiguity between a tilted
854.959|3.44|square and an upright diamond but more
857.12|2.48|powerful because you're not familiar
858.399|2.56|with it
859.6|3.039|um
860.959|3.68|and that's my demonstration that people
862.639|3.601|really do use coordinate systems and if
864.639|3.921|you use a different coordinate system to
866.24|4.159|describe things and here i forced you to
868.56|3.68|use a different coordinate system by
870.399|3.281|making the diagonal be vertical and
872.24|2.959|asking you to describe it relative to
873.68|3.76|that vertical axis
875.199|3.841|then familiar things become completely
877.44|3.04|unfamiliar
879.04|3.12|and when you do see them relative to
880.48|3.599|this new frame they're just a completely
882.16|3.52|different thing
884.079|3.681|notice that things like convolutional
885.68|3.68|neural nets don't have that they can't
887.76|3.04|look at something and have two utterly
889.36|3.76|different internal representations of
890.8|5.039|the very same thing
893.12|4.56|i'm also showing you that you do parsing
895.839|3.68|so here i've colored it so you pass it
897.68|3.76|into what i call the crown
899.519|4.32|which is three triangular flaps that
901.44|4.639|slope upwards and outwards
903.839|4.0|here's a different parsing
906.079|4.401|the same green flap soaking upwards and
907.839|5.281|outputs now we have a red flap sloping
910.48|4.4|downwards and outwards and we have a
913.12|3.839|central rectangle and you just have the
914.88|4.959|two ends of the rectangle
916.959|5.041|and if you know if you perceive this
919.839|4.481|and now close your eyes and ask you were
922.0|4.0|there any parallel edges there
924.32|4.079|you're very well aware that those two
926.0|4.0|edge two blue edges were parallel and
928.399|3.68|you're typically not aware of any other
930.0|4.24|parallel edges even though you know by
932.079|4.081|symmetry there must be other pairs
934.24|2.88|similarly with the crown if you see the
936.16|2.64|crown
937.12|3.92|and then i ask you to close your eyes
938.8|4.399|and ask you were the parallel edges you
941.04|3.52|don't see any parallel edges
943.199|3.521|and that's because the coordinate
944.56|4.48|systems you're using for those flaps
946.72|4.4|don't line up with the edges and you
949.04|3.359|only notice parallel edges if they line
951.12|2.24|up with the coordinate system you're
952.399|2.961|using
953.36|3.839|so here for the rectangle the parallel
955.36|3.52|edges align with the coordinate system
957.199|3.2|for the flaps they don't
958.88|3.44|so you're aware that those two blue
960.399|3.201|edges are parallel but you're not aware
962.32|3.28|that one of the green edges in one of
963.6|5.0|the registers is parallel
965.6|3.0|um
970.32|3.84|so this isn't like the neca cube
971.839|4.0|ambiguity where when it flips you think
974.16|2.96|that what's out there in reality is
975.839|2.321|different things are at a different
977.12|2.56|depth
978.16|2.88|this is like
979.68|2.88|next weekend we shall be visiting
981.04|2.96|relatives
982.56|3.839|so if you take the sentence next weekend
984.0|3.36|we shall be visiting relatives it can
986.399|3.601|mean
987.36|5.44|next weekend what we will be doing is
990.0|5.36|visiting relatives or it can mean next
992.8|4.159|weekend what we will be is visiting
995.36|3.039|relatives
996.959|2.481|now those are completely different
998.399|2.401|senses
999.44|3.839|they happen to have the same truth
1000.8|4.959|conditions they mean the same thing in
1003.279|4.0|the sense of truth conditions because if
1005.759|3.121|you're visiting relatives what you are
1007.279|3.441|is visiting relatives
1008.88|3.199|and it's that kind of ambiguity no
1010.72|2.559|disagreement about what's going on in
1012.079|4.241|the world but two completely different
1013.279|3.041|ways of seeing the sentence
1018.8|4.88|so
1020.24|7.679|this is um this was drawn in the 1970s
1023.68|4.239|this is what ai was like in the 1970s
1028.319|5.041|this is a sort of structural description
1030.4|5.439|of the crown interpretation
1033.36|4.24|so you have nodes for the all various
1035.839|4.321|parts in the hierarchy
1037.6|5.359|i've also put something on the arcs that
1040.16|4.639|rwx
1042.959|3.201|is the relationship between the crown
1044.799|3.601|and the flap
1046.16|3.92|and that can be represented by a matrix
1048.4|3.44|it's really the relationship between the
1050.08|3.68|intrinsic frame of reference of the
1051.84|3.68|crown than the intrinsic frame of
1053.76|3.52|reference of the flap
1055.52|3.84|and notice that
1057.28|4.08|if i change my viewpoint that doesn't
1059.36|3.679|change at all
1061.36|3.12|so that kind of relationship would be a
1063.039|3.281|good thing to put in the weights of a
1064.48|3.439|neural network because you'd like a
1066.32|3.92|neural network to be able to recognize
1067.919|5.12|shapes independently of viewpoint
1070.24|6.64|and that rwx is knowledge about this
1073.039|4.961|shape that's independent of viewpoint
1076.88|3.44|here's the
1078.0|4.08|zigzag interpretation
1080.32|3.28|and here's something else where i've
1082.08|4.24|added
1083.6|5.52|the things in the heavy blue boxes
1086.32|3.84|they're the relationship between
1089.12|3.12|the
1090.16|3.68|a node and the viewer
1092.24|3.36|that is to be more explicit the
1093.84|3.36|coordinate transformation between the
1095.6|3.6|intrinsic frame of reference of the
1097.2|3.599|crown and the intrinsic frame of
1099.2|5.44|reference of the viewer
1100.799|4.961|your eyeball is that rwv
1104.64|3.039|and that's a different kind of thing
1105.76|3.6|altogether because as you change
1107.679|3.601|viewpoint that changes
1109.36|4.0|in fact as you change your viewpoint all
1111.28|4.88|those things in blue boxes all change
1113.36|4.48|together in a consistent way
1116.16|3.759|and there's a simple relationship which
1117.84|6.16|is that if you take rwb
1119.919|5.201|then you multiply it by rwx you get rx v
1124.0|2.96|um so
1125.12|2.96|you can easily propagate viewpoint
1126.96|2.8|information over a structural
1128.08|3.52|description
1129.76|2.56|and that's what i think a mental image
1131.6|3.28|is
1132.32|4.56|rather than a bunch of pixels
1134.88|4.72|it's a structural description with
1136.88|4.96|associated viewpoint information
1139.6|2.24|um
1142.08|3.839|that makes sense of a lot of properties
1143.76|4.159|of mental images like
1145.919|6.321|if you want to do any reasoning with
1147.919|6.081|things like rwx you form a mental image
1152.24|3.28|that is you fill in you choose a
1154.0|2.88|viewpoint
1155.52|2.72|and i want to do one more demo to
1156.88|2.799|convince you you always choose a
1158.24|2.88|viewpoint when you're solving mental
1159.679|2.721|imagery problems
1161.12|3.28|so i'm going to give you another very
1162.4|5.12|simple mental imagery problem at the
1164.4|4.8|risk of running overtime um
1167.52|4.399|imagine that
1169.2|4.8|you're at a particular point and you
1171.919|4.241|travel a mile east and then you travel a
1174.0|3.36|mile north and then you travel a mile
1176.16|2.639|east again
1177.36|3.28|what's your direction back to your
1178.799|4.0|starting point
1180.64|4.159|this isn't a very hard problem
1182.799|3.361|it's sort of a bit south and quite a lot
1184.799|3.041|west right
1186.16|4.24|it's not exactly southwest but it's sort
1187.84|5.36|of south west
1190.4|4.0|now when you did that task what you
1193.2|2.88|imagined
1194.4|3.279|from your point of view
1196.08|2.959|is you went a mile east and then you
1197.679|3.601|went to mile north and then you went to
1199.039|4.081|mile east again
1201.28|3.44|i'll tell you what you didn't imagine
1203.12|2.88|you didn't imagine that you went to mile
1204.72|3.12|east and then you went to our north and
1206.0|3.2|then you went to mile east again you
1207.84|3.36|could have solved the problem perfectly
1209.2|3.68|well with north not being up
1211.2|3.839|but you had north up
1212.88|3.52|you also didn't imagine this you go mile
1215.039|2.64|east and then a mile north and then a
1216.4|2.72|mile east again
1217.679|3.681|and you didn't imagine this you go mile
1219.12|4.32|east and then a mile north and so on you
1221.36|4.0|imagined it at a particular scale in a
1223.44|3.76|particular orientation in a particular
1225.36|2.96|position
1227.2|2.88|that's
1228.32|4.32|and you can answer questions about
1230.08|4.16|roughly how big it was and so on so
1232.64|4.64|that's evidence that to solve these
1234.24|5.36|tasks that involve using
1237.28|3.92|relationships between things you form a
1239.6|5.92|mental image
1241.2|4.32|um okay enough on mental imagery
1245.919|2.88|so i'm now going to give you a very
1247.36|2.559|brief introduction to contrastive
1248.799|3.281|learning
1249.919|3.12|so where this is a complete
1252.08|2.32|um
1253.039|2.64|disconnect in the talk but i'll come
1254.4|3.12|back together soon
1255.679|3.681|um
1257.52|4.48|so
1259.36|5.679|in contrast to self-supervised learning
1262.0|5.2|what we try and do is make two different
1265.039|4.321|crops of an image have the same
1267.2|4.4|representation
1269.36|2.24|um
1271.76|3.6|there's a paper a long time ago by becca
1273.36|5.12|and hinton where we were doing this to
1275.36|5.439|discover low level coherence in an image
1278.48|3.52|like the continuity of surfaces
1280.799|3.12|or
1282.0|3.6|the depth of surfaces
1283.919|3.441|um
1285.6|3.12|it's been improved a lot since then and
1287.36|4.16|it's been used for doing things like
1288.72|4.079|classification that is
1291.52|3.6|you take
1292.799|3.601|you take an image that has one prominent
1295.12|2.96|object in it
1296.4|3.759|and you say
1298.08|5.76|if i take a crop of the image that
1300.159|5.121|contains sort of any part of that object
1303.84|2.56|it should have the same representation
1305.28|3.84|as some other crop of the image
1306.4|4.0|containing a part of that object
1309.12|2.88|and
1310.4|4.0|this has been developed
1312.0|4.159|a lot in the last few years i'm going to
1314.4|3.759|talk about a model developed a couple of
1316.159|3.681|years ago my group in toronto called
1318.159|3.52|sinclair but there's lots of other
1319.84|4.319|models and since then things have
1321.679|2.48|improved
1325.36|5.36|so in simclair you take an imagex
1328.72|5.12|you take two different
1330.72|4.8|crops and you also do color distortion
1333.84|2.959|of the crops different color distortions
1335.52|2.8|of each crop
1336.799|4.24|and that's to prevent it from using
1338.32|4.479|color histograms to say they're the same
1341.039|3.201|um so you mess with the color so it
1342.799|4.161|can't use color
1344.24|4.319|in a simple way
1346.96|2.8|and
1348.559|3.921|that gives you
1349.76|4.399|x i tilde and xj tilde
1352.48|3.76|you then put those through the same
1354.159|5.201|neural network f
1356.24|4.64|then you get a representation h
1359.36|2.72|and then you take the representation h
1360.88|3.76|and you put it through another neural
1362.08|4.719|network which compresses it a bit
1364.64|4.08|it goes to low dimensionality
1366.799|3.201|um that's an extra complexity i'm not
1368.72|2.8|going to explain but it makes it work a
1370.0|3.36|bit better
1371.52|5.44|you can do it without doing that
1373.36|5.52|and you get two embeddings zi and zj
1376.96|5.04|and your aim is to maximize the
1378.88|4.64|agreement between those vectors
1382.0|3.28|and so you start off doing that and you
1383.52|3.519|say okay let's
1385.28|3.68|start off with random neural networks
1387.039|3.681|random weights in the neural networks
1388.96|2.8|and let's take two patches and let's put
1390.72|3.36|them through through these
1391.76|4.56|transformations and let's try and make z
1394.08|4.24|i be the same as zj so let's back
1396.32|4.64|propagate the squared difference between
1398.32|4.16|components of i and components of j
1400.96|3.599|and hey presto
1402.48|3.6|what you discover is um everything
1404.559|2.641|collapses
1406.08|2.88|um
1407.2|3.92|for every image
1408.96|3.199|it will always produce the same zi and
1411.12|2.24|zj
1412.159|3.041|and then you realize well that's not
1413.36|3.76|what i meant by agreement i mean they
1415.2|3.92|should be the same
1417.12|3.76|when you get two crops of the same image
1419.12|3.28|and different when you get two crops of
1420.88|3.039|different images
1422.4|2.8|otherwise it's not really agreement
1423.919|3.521|right
1425.2|2.24|um
1428.559|4.0|so you have to have negative examples
1430.72|4.72|you have to show it crops from different
1432.559|4.801|images and say those should be different
1435.44|3.359|if they're already different
1437.36|2.48|you don't try and make them a lot more
1438.799|2.401|different
1439.84|3.28|it's very easy to make things very
1441.2|2.959|different but that's not what you want
1443.12|3.12|you just want to be sure they're
1444.159|4.321|different enough so crops from different
1446.24|4.08|images aren't taken to be from the same
1448.48|3.679|image so if they happen to be very
1450.32|3.28|similar you push them apart
1452.159|2.801|and that stops your representations
1453.6|2.4|collapsing that's called contrastive
1454.96|3.68|learning
1456.0|4.159|and it works very well
1458.64|3.519|so
1460.159|3.201|what you can do is do unsupervised
1462.159|3.281|learning
1463.36|3.6|by trying to maximize agreement between
1465.44|3.28|the
1466.96|4.24|representations you get from two image
1468.72|4.64|patches from the same image
1471.2|4.959|and after you've done that you just take
1473.36|5.199|your representation of the image patch
1476.159|4.241|and you feed it to a linear classifier a
1478.559|3.681|bunch of ways so that you multiply the
1480.4|3.2|representation by a weight matrix put it
1482.24|3.28|through a softmax
1483.6|3.679|and get class labels
1485.52|3.2|and then you train that by
1487.279|3.201|gradient descent
1488.72|4.0|and
1490.48|4.48|what you discover is that that's just
1492.72|3.199|about as good as training on labeled
1494.96|2.4|data
1495.919|2.961|so now the only thing you trained on
1497.36|3.919|label data is that last linear
1498.88|4.56|classifier the previous layers were
1501.279|3.201|trained on unlabeled data
1503.44|2.64|and
1504.48|4.37|you've managed to train your
1506.08|5.839|representations without needing labels
1508.85|5.55|[Music]
1511.919|4.961|now there's a problem with this
1514.4|5.04|um it works very nicely
1516.88|4.56|but it's really confounding objects and
1519.44|3.76|whole scenes
1521.44|4.239|so it makes sense to say two different
1523.2|4.4|patches from the same scene
1525.679|4.561|should get the same
1527.6|5.28|vector label at the scene level because
1530.24|4.24|they're from the same scene
1532.88|3.039|but what if one of the patches contains
1534.48|3.52|bits of objects a and b and another
1535.919|3.521|patch contain bits of objects a and c
1538.0|2.88|you don't really want those two patches
1539.44|2.96|to have the same representation at the
1540.88|2.96|object level
1542.4|4.159|so we have to distinguish these
1543.84|5.36|different levels of representation
1546.559|5.201|and for contrastive learning
1549.2|3.839|if you don't use any kind of gaiting or
1551.76|3.039|attention
1553.039|5.281|then what's happening is you're really
1554.799|3.521|doing learning at the seam level
1559.12|3.6|what we'd like is that the
1561.12|3.039|representations you get at the object
1562.72|3.76|level
1564.159|4.721|should be the same
1566.48|4.0|if both patches or patches are object a
1568.88|3.84|but should be different if one patches
1570.48|3.52|from object and one patches for object b
1572.72|2.72|and to do that we're going to need some
1574.0|3.6|form of attention to decide whether they
1575.44|4.08|really come from the same thing
1577.6|4.16|and so glom is designed to do that it's
1579.52|4.56|trying to take contrastive learning
1581.76|4.0|and to introduce attention of the kind
1584.08|3.839|you get in transformers
1585.76|5.039|in order not to try and say things are
1587.919|2.88|the same when they're not
1591.12|4.64|i should mention at this point that most
1593.279|3.76|of you will be familiar with bert
1595.76|3.84|then you could think of the word
1597.039|5.201|fragments that are fed into bert as like
1599.6|4.4|the image patches i'm using here
1602.24|3.679|and in bert you have that whole column
1604.0|3.6|of representations of the same word
1605.919|3.681|fragment
1607.6|5.76|in but what's happening presumably as
1609.6|6.8|you go up is you're getting um
1613.36|5.76|semantically richer representations
1616.4|4.72|but in bert there's no attempt to
1619.12|4.96|get representations of larger things
1621.12|2.96|like whole phrases
1624.96|4.4|this what i'm going to talk about will
1626.559|4.24|be a way to modify burps so as you go up
1629.36|2.559|you get bigger and bigger islands of
1630.799|2.801|agreement
1631.919|3.681|so for example
1633.6|5.04|after a couple of levels
1635.6|5.36|then things like new and york
1638.64|3.84|will have the different fragments of
1640.96|3.439|york suppose he's got two different
1642.48|3.52|fragments we'll have exactly the same
1644.399|2.961|representation if it was done in the
1646.0|3.679|glom right way
1647.36|4.319|and then as you go up another level
1649.679|3.761|the fragments of new well news probably
1651.679|4.24|a thing in its own right but and the
1653.44|4.88|fragments of york would all have exactly
1655.919|4.64|the same representation
1658.32|4.959|um they'd have this island of agreement
1660.559|4.881|and that would be a representation of
1663.279|3.52|a compound thing and as you go up you're
1665.44|3.44|going to get these islands of agreement
1666.799|3.201|that represent bigger and bigger things
1668.88|4.159|and that's going to be a much more
1670.0|4.32|useful kind of bird because instead of
1673.039|3.52|taking
1674.32|4.479|vectors that represent word fragments
1676.559|3.921|and then sort of mung them together by
1678.799|3.76|taking the max of each for example the
1680.48|4.4|max of each component for example which
1682.559|4.48|is just a crazy thing to do
1684.88|4.72|you'll explicitly as you're learning
1687.039|4.961|form representations of larger parts in
1689.6|5.4|the part hole hierarchy
1692.0|3.0|okay
1695.679|5.041|so what we're going after glo england is
1698.32|4.239|a particular kind of spatial coherence
1700.72|3.92|that's more complicated than the spatial
1702.559|3.681|coherence caused by the fact that
1704.64|3.759|surfaces tend to be at the same depth
1706.24|4.64|and same orientation in nearby patches
1708.399|4.64|of an image we're going after the
1710.88|2.96|spatial coherence
1713.039|2.481|um
1713.84|3.439|that says that
1715.52|3.44|if you find a mouth in an image and you
1717.279|3.12|find a nose in an image and then the
1718.96|2.319|right spatial relationship to make a
1720.399|2.441|face
1721.279|3.921|then that's a particular kind of
1722.84|3.88|coherence and we want to go after that
1725.2|4.24|unsupervised
1726.72|5.679|and we want to um discover that kind of
1729.44|2.959|coherence in images
1733.679|3.281|so before i go into
1735.44|3.2|more details about glom i want a
1736.96|3.76|disclaimer
1738.64|4.24|um
1740.72|4.16|for years computer vision treated vision
1742.88|4.0|as you've got a static image a uniform
1744.88|2.88|resolution and you want to say what's in
1746.88|2.56|it
1747.76|3.68|um that's not how vision works in the
1749.44|3.599|real world in the real world this is
1751.44|3.119|outer loop where you decide where to
1753.039|3.76|look
1754.559|3.36|if you're a person or a robot
1756.799|3.441|um
1757.919|4.0|you better do that intelligently
1760.24|3.6|and
1761.919|4.64|that that gives you a sample of the
1763.84|4.64|optic array it turns the optic array the
1766.559|4.881|incoming light
1768.48|4.319|into a retinal image and on your retina
1771.44|4.239|you have high resolution in the middle
1772.799|4.081|and low resolution around the edges
1775.679|4.161|and
1776.88|5.44|so you're focusing on particular details
1779.84|4.959|and you never ever process the whole
1782.32|3.839|image at uniform resolution you're
1784.799|3.6|always focusing on something and
1786.159|3.921|processing where you're fixating at high
1788.399|3.361|resolution and everything else at much
1790.08|3.36|lower resolution particularly around the
1791.76|3.039|edges
1793.44|2.959|so i'm gonna
1794.799|3.521|ignore all the complexity of how you
1796.399|4.481|decide where to look and all the
1798.32|3.68|complexity of how you put together the
1800.88|2.48|information you get from different
1802.0|3.679|situations
1803.36|4.88|by saying let's just talk about the very
1805.679|4.48|first fixation on a novel image so you
1808.24|3.6|look somewhere and now what happens on
1810.159|3.201|that first fixation
1811.84|3.199|we know that the same hardware in the
1813.36|3.039|brain is going to be reused for the next
1815.039|2.561|fixation
1816.399|3.76|but let's just think about the first
1817.6|2.559|fixation
1820.64|4.0|so finally here's a picture of the
1822.48|3.919|architecture
1824.64|3.68|and this is
1826.399|4.481|the architecture
1828.32|6.0|for a single location so like for a
1830.88|3.44|single word fragment in bert
1834.48|2.88|and
1835.679|3.761|it shows you what's happening for
1837.36|4.16|multiple frames so glom is really
1839.44|4.0|designed for video but i only talk about
1841.52|3.84|applying it to static images
1843.44|4.479|then you should think of a static image
1845.36|5.6|as a very boring video in which the
1847.919|4.161|frames are all the same as each other
1850.96|2.88|so
1852.08|4.24|i'm showing you three adjacent levels in
1853.84|4.719|the hierarchy
1856.32|3.839|and i'm showing you what happens over
1858.559|3.921|time
1860.159|4.081|so if you look at the middle level
1862.48|3.439|maybe that's the sort of major part
1864.24|5.039|level
1865.919|6.561|and look at that box that says level l
1869.279|6.24|and that's at frame four
1872.48|4.96|um so the right hand level l box
1875.519|3.52|and let's ask how the state of that box
1877.44|2.959|is the state of that embedding is
1879.039|2.721|determined
1880.399|3.841|so inside the box we're going to get an
1881.76|2.48|embedding
1884.96|4.319|and the embedding is going to be the
1886.159|4.801|representation of what's going on at the
1889.279|5.201|major part level
1890.96|3.52|for that little patch of the image
1895.279|4.4|and level l
1896.799|4.801|in this diagram all of these embeddings
1899.679|5.921|will always be devoted
1901.6|6.079|to the same patch of the retinal image
1905.6|4.799|okay
1907.679|4.88|the level l embedding
1910.399|3.52|on the right hand side
1912.559|3.441|you can see there's three things
1913.919|3.201|determining it there there's a green
1916.0|3.12|arrow
1917.12|3.84|and for static images the green arrow is
1919.12|2.96|rather boring it's just saying you
1920.96|3.04|should sort of be similar to the
1922.08|4.8|previous state of level l so it's just
1924.0|5.12|doing temporal integration
1926.88|2.24|the
1929.44|2.88|blue arrow
1930.799|4.081|is actually a neural net with a couple
1932.32|3.92|of hidden layers in it i'm just showing
1934.88|3.2|you the embeddings here not all the
1936.24|3.36|layers of the neural net
1938.08|2.719|we need a couple of hidden layers to do
1939.6|2.64|the coordinate transforms that are
1940.799|3.281|required
1942.24|4.159|and the blue arrow
1944.08|3.599|is basically taking information at the
1946.399|3.52|level below
1947.679|4.88|of the previous time step
1949.919|4.321|so level l minus one on frame three
1952.559|3.441|might be representing that i think i
1954.24|3.84|might be a nostril
1956.0|4.48|well if you think you might be a nostril
1958.08|5.04|what you predict at the next level up is
1960.48|3.919|a nose what's more
1963.12|3.279|if you have a coordinate frame for the
1964.399|4.16|nostril you can predict the coordinate
1966.399|3.76|frame for the nose maybe not perfectly
1968.559|4.401|but you have a pretty good idea of the
1970.159|5.841|orientation position scale of the notes
1972.96|4.959|so that bottom up neural net
1976.0|4.399|is
1977.919|4.48|a net that can take any kind of part at
1980.399|4.081|level and minus when you take a nostril
1982.399|3.601|but it could also take a steering wheel
1984.48|4.48|and predict the car from the steering
1986.0|5.2|wheel um
1988.96|4.8|and predict what you've got at the next
1991.2|2.56|level up
1994.32|5.44|the red arrow is a top down neural net
1997.84|4.48|so the red arrow
1999.76|3.759|is predicting
2002.32|3.28|the
2003.519|3.441|nose from the whole face
2005.6|3.439|and again it has a couple of hidden
2006.96|3.36|layers do coordinate transforms
2009.039|3.041|because if you know the chord the
2010.32|3.359|coordinate frame of the face
2012.08|3.12|and you know the relationship between a
2013.679|2.72|face and a nose
2015.2|3.199|and that's going to be in the weights of
2016.399|3.441|that top down neural net
2018.399|3.52|then you can predict
2019.84|3.439|the that it's a nose and what the pose
2021.919|3.521|of the nose is
2023.279|4.721|and that's all going to be in activities
2025.44|3.68|in that embedding vector
2028.0|3.36|okay
2029.12|5.2|now there's all of that is what's going
2031.36|5.6|on in one column of hardware that's all
2034.32|5.52|about a specific patch of the image
2036.96|5.28|so that's very very like what's going on
2039.84|4.719|for one word fragment in bert you have
2042.24|5.319|all these levels of representation
2044.559|3.0|um
2048.48|3.76|it's a bit confusing exactly what the
2050.32|2.96|relation of this is to bert and i'll
2052.24|2.399|give you the reference to a long
2053.28|3.68|archived paper at the end that has a
2054.639|4.24|whole section on how this relates to but
2056.96|4.959|um but it's confusing because this has
2058.879|5.52|time steps um
2061.919|3.281|and that makes it all more complicated
2064.399|2.24|okay
2065.2|3.36|um
2066.639|3.44|so those are three things that determine
2068.56|3.92|the level of embedding
2070.079|5.6|but there's one fourth thing
2072.48|4.56|which is in black at the bottom there
2075.679|3.68|and that's the only way in which
2077.04|4.639|different locations interact
2079.359|4.0|and that's a very simplified form of a
2081.679|3.44|transformer
2083.359|4.0|if you take a transformer
2085.119|4.96|as invert and you say let's make the
2087.359|4.401|embeddings and the keys and the queries
2090.079|2.721|and the values all be the same as each
2091.76|3.68|other
2092.8|3.92|we just have this one vector
2095.44|3.12|so now
2096.72|4.16|all you're trying to do
2098.56|5.279|is make the level l embedding in one
2100.88|6.0|column be the same as the level l
2103.839|4.641|embedding in nearby columns
2106.88|3.76|but it's going to be gated you're only
2108.48|3.28|going to try and make it be the same
2110.64|2.96|if
2111.76|3.68|it's already quite similar
2113.6|4.32|[Music]
2115.44|4.639|so here's how the attention works
2117.92|4.8|um you take the level l embedding in
2120.079|4.161|location x that's alex
2122.72|4.399|and you take the level l embedding in
2124.24|5.2|the nearby location y that's our y
2127.119|4.48|you take the scalar product
2129.44|4.0|you exponentiate
2131.599|3.601|and you normalize in other words you do
2133.44|4.72|a soft max
2135.2|4.32|and that gives you the weight to use
2138.16|3.52|in
2139.52|6.0|your desire to make
2141.68|7.679|lx be the same as l y
2145.52|4.96|so the input produced
2149.359|1.921|by this
2150.48|2.24|um
2151.28|3.36|from neighbours
2152.72|4.72|is an attention weighted average of the
2154.64|4.8|level and embeddings of nearby columns
2157.44|3.84|and that's an extra input that you get
2159.44|3.84|it's trying to make you agree with
2161.28|3.36|nearby things and that's what's going to
2163.28|3.839|cause you to get these islands of
2164.64|2.479|agreement
2170.4|6.0|so back to this picture
2173.52|2.88|i think um
2177.2|3.84|yeah
2178.72|4.16|this is what we'd like to see
2181.04|4.319|and the reason
2182.88|4.16|um we get those
2185.359|2.961|that big island of agreement at the
2187.04|2.88|object level
2188.32|3.519|is because we're trying to get agreement
2189.92|4.159|there we're trying to learn the
2191.839|4.481|coordinate transform
2194.079|3.681|from the red arrows to the level above
2196.32|5.039|and from the green arrows to the level
2197.76|5.92|above such that we get agreement
2201.359|2.321|okay
2205.359|4.081|now one thing we need to worry about
2207.839|3.121|is that the difficult thing in
2209.44|3.28|perception
2210.96|3.6|um
2212.72|3.76|is not so bad in language it's probably
2214.56|3.92|worse than visual perception is that
2216.48|3.44|there's a lot of ambiguity
2218.48|3.599|if i'm looking at a line drawing for
2219.92|4.0|example i see a circle
2222.079|3.76|well a circle could be the right eye of
2223.92|3.199|a face or it could be the left eye of a
2225.839|2.961|face or it could be the front wheel of a
2227.119|3.201|car or the back wheel of a car there's
2228.8|2.559|all sorts of things a third circle could
2230.32|4.32|be
2231.359|5.521|and we'd like to disambiguate the circle
2234.64|4.16|and there's a long line of work
2236.88|4.16|um using things like markov random
2238.8|3.6|fields here we need a variation on a
2241.04|3.36|microphone field which i'll call a
2242.4|4.32|transformational random field
2244.4|4.24|because the interaction between for
2246.72|4.32|example something that might be an eye
2248.64|5.439|and something that might be a mouse
2251.04|4.799|needs to be gated by corner transforms
2254.079|3.681|you know for the let's take a nose and a
2255.839|3.201|mouth because that's my standard thing
2257.76|3.599|if you take something that might be a
2259.04|5.76|nose and you want to ask does anybody
2261.359|6.24|out there support the idea on my nose
2264.8|6.0|well what you'd like to do is send
2267.599|4.161|to everything nearby a message saying
2270.8|4.4|um
2271.76|5.2|do you have the right kind of pose
2275.2|3.919|and right kind of identity to support
2276.96|4.08|the idea that i'm a nose
2279.119|5.361|and so you'd like for example to send
2281.04|4.96|out a message from the nose you'd send
2284.48|3.599|out a message to all all nearby
2286.0|4.24|locations saying does anybody have a
2288.079|5.121|mouth with the pose that i predict by
2290.24|4.4|taking the pose of the nose multiplying
2293.2|3.44|by the coordinate transform between the
2294.64|3.84|nose and the mouth and now i can predict
2296.64|3.36|the pose of the mouse is is there
2298.48|3.44|anybody out there with that pose who
2300.0|3.04|thinks they might be a mouse
2301.92|2.24|and i think you can see you're gonna
2303.04|2.4|have to send out a lot of different
2304.16|2.24|messages
2305.44|2.32|um
2306.4|2.719|for each kind of other thing that might
2307.76|3.52|support you you're gonna need to send a
2309.119|4.641|different message so you're gonna need a
2311.28|3.68|multi-headed
2313.76|2.48|transformer
2314.96|3.04|and it's going to be doing these
2316.24|4.24|coordinate transforms
2318.0|4.0|and you have to transform the inverse
2320.48|3.28|transform on the way back
2322.0|4.56|because if the mouse supports you it
2323.76|4.319|what it needs to support is a nose um
2326.56|3.279|not with the pose of the mouth but with
2328.079|3.201|the appropriate pose
2329.839|2.801|so that's going to get very complicated
2331.28|3.2|you can have n squared interactions all
2332.64|3.04|with coordinate transforms
2334.48|2.879|there's another way of doing it that's
2335.68|3.12|much simpler it's called a half
2337.359|3.76|transform
2338.8|5.92|at least it's much simpler if you have a
2341.119|3.601|way of representing ambiguity
2346.0|5.44|so instead of these direct interactions
2348.32|4.4|between parts like your nose and mouth
2351.44|3.679|what you're going to do is you're going
2352.72|4.8|to make each of the parts
2355.119|4.641|predict the hole
2357.52|4.319|so the nose can predict the face
2359.76|4.56|and it can predict the pose of the face
2361.839|4.081|and the mouth can also predict the face
2364.32|3.6|now these will be in different columns
2365.92|3.919|of glom but in one column column you'll
2367.92|3.6|have a nose predicting face
2369.839|3.28|in a nearby column you'll have a mouth
2371.52|4.16|predicting face
2373.119|5.601|and those two faces should be the same
2375.68|4.88|if this really is a face
2378.72|3.92|so when you do this attention weighted
2380.56|4.559|averaging with nearby things what you're
2382.64|3.439|doing is you're getting confirmation
2385.119|3.201|that
2386.079|3.841|um the support
2388.32|2.88|for the hypothesis you've got i mean
2389.92|3.679|suppose in one column you make the
2391.2|4.96|hypothesis it's a face with this pose
2393.599|5.361|that gets supported by nearby columns
2396.16|5.12|that derive the very same embedding
2398.96|3.68|from quite different data one derived it
2401.28|3.76|from the nose and one derived it from
2402.64|2.4|the max
2405.119|3.441|and this doesn't require any dynamic
2406.8|3.6|routing
2408.56|3.68|because the embeddings are always
2410.4|3.76|referring to what's going on in the same
2412.24|4.32|small patch of the image
2414.16|4.48|within a column there's no routing and
2416.56|3.519|between columns
2418.64|3.12|there's something a bit like routine but
2420.079|3.681|it's just the standard transformer kind
2421.76|4.72|of attention you're just trying to agree
2423.76|4.96|with things that are similar
2426.48|5.76|and
2428.72|6.399|okay so that's how glom's meant to work
2432.24|4.879|and the big problem is
2435.119|3.361|that if i see a circle it might be a
2437.119|2.72|left right it might be a right eye it
2438.48|2.4|might be a
2439.839|2.48|front wheel of a car it might be the
2440.88|3.199|back wheel of a car
2442.319|3.361|because my embedding for a particular
2444.079|3.441|patch at a particular level has to be
2445.68|4.08|able to represent anything
2447.52|3.92|when i get an ambiguous thing i have to
2449.76|4.319|deal with all these possibilities of
2451.44|4.32|what hole it might be part of
2454.079|3.76|so instead of trying to resolve
2455.76|3.52|ambiguity at the part level what i'm
2457.839|3.52|going to do is jump to the next level up
2459.28|3.76|and resolve the ambiguity there just by
2461.359|2.96|seeing if things are the same
2463.04|2.559|which is an easier way to resolve
2464.319|3.76|ambiguity
2465.599|4.72|but the cost of that is i have to be
2468.079|4.961|able to represent all the ambiguity i
2470.319|4.321|get at the next level up
2473.04|2.72|now it turns out you can do that we've
2474.64|2.479|done a little
2475.76|2.4|toy example
2477.119|4.081|where
2478.16|3.84|you can actually preserve this ambiguity
2481.2|2.879|um
2482.0|4.64|but it's difficult it's the kind of
2484.079|5.04|thing neural nets are good at
2486.64|4.4|so if you think about the embedding in
2489.119|3.841|the next level up
2491.04|5.039|you've got a whole bunch of neurons
2492.96|5.119|whose activities are that embedding
2496.079|4.161|and you want to represent
2498.079|3.681|a highly multi-modal distribution like
2500.24|2.96|it might be a car with this pose or a
2501.76|3.52|car with that pose or a face with this
2503.2|3.76|pose or a face with that pose
2505.28|3.92|all of these are possible predictions
2506.96|5.44|from finding a circle
2509.2|4.72|and so you have to represent all that
2512.4|2.4|and the question is can your let's do
2513.92|2.48|that
2514.8|3.039|well i think the way they must be doing
2516.4|4.88|it is
2517.839|5.921|each neuron in the embedding
2521.28|4.319|stands for an unnormalized log
2523.76|3.599|probability distribution
2525.599|3.76|over this huge space of possible
2527.359|3.521|identities and possible poses
2529.359|2.801|the sort of cross product of identities
2530.88|3.199|and poses
2532.16|4.64|um
2534.079|4.24|and so the neuron is this rather vague
2536.8|3.12|log probability distribution over that
2538.319|3.76|space
2539.92|4.72|and when you activate the neuron what
2542.079|3.921|it's saying is add in that log
2544.64|2.8|probability distribution to what you've
2546.0|2.96|already got
2547.44|3.679|and so now if you have a whole bunch of
2548.96|4.8|log probability distributions
2551.119|4.0|and you add them all together
2553.76|3.04|you can get
2555.119|3.361|a much more peaky log probability
2556.8|3.039|distribution
2558.48|3.2|and when you exponentiate you get a
2559.839|2.961|probability distribution it gets very
2561.68|4.639|peaky
2562.8|7.279|and so very vague basis functions
2566.319|5.28|in this joint space of pose and identity
2570.079|3.441|and basis functions in the log
2571.599|3.52|probability of that space
2573.52|4.599|can be combined to produce sharp
2575.119|3.0|conclusions
2578.319|3.201|so
2580.079|2.801|i think that's how neurons are
2581.52|3.28|representing things most people think
2582.88|3.52|about neurons as
2584.8|3.519|they think about the thing that they're
2586.4|4.56|representing
2588.319|5.201|but obviously in perception you have to
2590.96|5.6|deal with uncertainty and so neurons
2593.52|5.04|have to be good at representing um
2596.56|3.68|multimodal distributions
2598.56|4.559|and this is the only way i can think of
2600.24|4.8|that's good at doing it
2603.119|3.521|that's a rather weak argument
2605.04|3.6|and it's the argument that led chomsky
2606.64|3.12|to believe that language wasn't learned
2608.64|3.28|because he couldn't think of how it was
2609.76|3.92|learned
2611.92|3.12|my view is neurons must be using this
2613.68|5.08|representation because i can't think of
2615.04|3.72|any other way didn't it
2620.16|2.64|okay
2621.359|5.521|i just said all that because i got ahead
2622.8|4.08|of myself because i got excited um
2628.72|2.8|now the reason you can get away with
2630.16|3.36|this the reason you have these very
2631.52|3.76|vague distributions in the unnormalized
2633.52|3.44|low probability space
2635.28|3.76|is because
2636.96|3.68|these neurons are all dedicated to a
2639.04|3.68|small patch of image
2640.64|3.6|and they're all trying to represent the
2642.72|2.72|thing that's happening that patch of
2644.24|2.879|image
2645.44|3.6|so you're only trying to represent one
2647.119|4.0|thing you're not trying to represent
2649.04|3.36|some set of possible objects
2651.119|2.321|if you're trying to represent some set
2652.4|2.719|of possible objects you'd have a
2653.44|2.72|horrible binding problem and you
2655.119|3.281|couldn't use these very vague
2656.16|4.959|distributions but so long as you know
2658.4|6.24|that all of these neurons all of the
2661.119|5.761|active neurons refer to the same thing
2664.64|3.679|then you can do the intersection you can
2666.88|3.52|add the log probability distribution
2668.319|4.961|together and intersect the sets of
2670.4|2.88|things they represent
2674.24|4.72|okay i'm getting near the end how would
2676.8|3.92|you train a system like this
2678.96|3.76|well obviously you could train it the
2680.72|3.599|way you train but you could do deep
2682.72|2.56|end-to-end training
2684.319|2.881|um
2685.28|3.92|and for golomb
2687.2|4.48|what that will consist of and the way we
2689.2|4.48|trained a toy example
2691.68|4.0|is you
2693.68|6.399|take an image
2695.68|4.399|you leave out some patches of the image
2700.4|4.48|you then let glom settle down for about
2702.72|5.04|10 iterations
2704.88|5.36|and it's trying to fill in
2707.76|4.559|the lowest level representation of the
2710.24|4.16|what's in the image
2712.319|3.201|the lowest level embeddings
2714.4|3.439|and
2715.52|4.24|it fills them in wrong and so you now
2717.839|3.76|back propagate that error and you're
2719.76|4.16|back propagating it through time in this
2721.599|4.161|network so it'll also back propagate up
2723.92|2.96|and down through the levels
2725.76|2.48|um
2726.88|3.199|so you're basically just doing back
2728.24|4.72|propagation through time
2730.079|4.0|of the error due to filling in things
2732.96|2.8|incorrectly
2734.079|4.081|that's basically how
2735.76|3.68|bird is trained and you could train glom
2738.16|3.199|the same way
2739.44|3.52|but i also want to include an extra bit
2741.359|4.641|in the training
2742.96|4.56|to encourage islands
2746.0|4.079|um
2747.52|3.36|we want to encourage
2750.079|2.721|um
2750.88|3.52|big islands of identical vectors at
2752.8|3.279|higher levels
2754.4|4.16|and you can do that by using the trust
2756.079|2.481|of learning
2758.839|6.441|so if you think how the next
2763.119|4.401|at the next time step if you think how
2765.28|5.2|an embedding is determined
2767.52|5.2|it's determined by combining
2770.48|3.68|a whole bunch of different factors
2772.72|2.56|what was going on in the previous time
2774.16|2.959|step
2775.28|3.039|at this level of representation in this
2777.119|3.041|location
2778.319|2.8|what was going on at the previous time
2780.16|3.04|step
2781.119|3.041|in this location but of the next level
2783.2|2.72|down
2784.16|3.919|at the next level up
2785.92|5.199|and also what was going on at the
2788.079|5.201|previous timestep at nearby locations
2791.119|3.041|at the same level
2793.28|2.72|and
2794.16|3.439|the weighted average of all those things
2796.0|2.56|i'll call the consensus embedding and
2797.599|2.801|that's what you use for the next
2798.56|3.84|embedding
2800.4|3.679|and i think you can see that
2802.4|4.719|if we try and make the bottom up neural
2804.079|4.721|net on the top down neural net if we try
2807.119|3.601|and make their predictions agree with
2808.8|4.559|the consensus
2810.72|6.16|the consensus has folded in
2813.359|5.601|information from nearby locations
2816.88|4.16|um that already roughly agree because of
2818.96|3.6|the attention rating
2821.04|3.279|and so by trying to make the top-down
2822.56|3.279|and bottom-up neural networks agree with
2824.319|3.121|the consensus
2825.839|3.28|you're trying to make them agree with
2827.44|4.159|what's going on nearby locations that
2829.119|5.281|are similar and so you'll be training it
2831.599|2.801|to form islands
2836.4|2.24|um
2837.52|3.28|this is more interesting to
2838.64|3.679|neuroscientists than to people who do
2840.8|2.559|natural language so i'm going to ignore
2842.319|2.8|that
2843.359|4.081|um
2845.119|4.48|you might think it's wasteful to
2847.44|4.159|be replicating
2849.599|3.76|all these embeddings at the object level
2851.599|3.201|so the idea is at the object level
2853.359|2.881|there'll be a large number of patches
2854.8|3.2|that all have exactly the same vector
2856.24|3.839|representation
2858.0|4.0|and that seems like a waste but actually
2860.079|4.321|biology is full of things like that all
2862.0|5.119|your cells have exactly the same dna in
2864.4|4.4|and all the parts of an organ have
2867.119|3.281|pretty much the same vector protein
2868.8|4.559|expressions so there's lots of
2870.4|4.719|replication goes on in
2873.359|3.281|to keep things local
2875.119|4.561|and it's the same here and actually that
2876.64|5.199|replica replication is very useful when
2879.68|4.24|you're settling on an interpretation
2881.839|3.441|because before you settle down
2883.92|3.199|you don't know which things should be
2885.28|3.36|the same as which other things so having
2887.119|2.96|separate vectors in each location to
2888.64|3.679|represent what's going on there at the
2890.079|3.841|object level gives you the flexibility
2892.319|4.641|to gradually segment things as you
2893.92|5.6|settle down in a sensible way
2896.96|4.32|um it allows you to hedge your bets
2899.52|4.48|and what you're doing is not quite like
2901.28|4.559|clustering you're creating clusters of
2904.0|4.24|identical vectors rather than
2905.839|4.161|discovering clusters in fixed data so
2908.24|3.52|clustering you're given the data and
2910.0|2.88|it's fixed and you find the clusters
2911.76|3.359|here
2912.88|3.199|the embeddings at every level
2915.119|3.041|are
2916.079|3.601|variable they vary over time they're
2918.16|3.28|determined by the top-down and bottom-up
2919.68|3.76|inputs and by inputs coming from nearby
2921.44|4.32|locations so what you're doing is
2923.44|3.84|forming clusters rather than discovering
2925.76|2.64|them in fixed data
2927.28|2.16|and that's got a somewhat different
2928.4|4.8|flavor
2929.44|3.76|and can settle down faster
2935.599|4.48|and one other advantage this replication
2938.319|3.841|is
2940.079|4.401|what you don't want is to have much more
2942.16|3.84|work in your transformer as you go to
2944.48|2.8|higher levels
2946.0|3.44|but you do need longer range
2947.28|3.44|interactions at higher levels presumably
2949.44|2.72|for the lowest levels you want fairly
2950.72|4.08|short range interactions in your
2952.16|3.919|transformer and they could be dense as
2954.8|3.6|you go to higher levels you want much
2956.079|4.081|longer range interactions so you could
2958.4|3.439|make them sparse
2960.16|2.64|and people have done things like that
2961.839|3.921|for
2962.8|2.96|bird-like systems
2965.839|4.72|here it's easy to make them sparse
2968.16|4.24|because you're expecting big islands so
2970.559|4.8|all you need to do is see
2972.4|4.64|one patch of a big island to know what
2975.359|2.401|the vector representation of that island
2977.04|2.64|is
2977.76|3.52|and so sparse representations will work
2979.68|3.6|much better if you have these big
2981.28|3.68|islands of agreement as you go up so the
2983.28|3.44|idea is you have longer ranges faster
2984.96|3.2|connections as you go up so the amount
2986.72|3.68|of computation is the same in every
2988.16|4.08|level
2990.4|4.159|and just to summarize
2992.24|3.839|um
2994.559|3.841|i showed how to combine three important
2996.079|4.961|advances of neural networks in glom i
2998.4|4.959|didn't actually talk about neural fields
3001.04|4.24|and that's important for the top-down
3003.359|3.041|network maybe since i've got two minutes
3005.28|6.279|to spare i'm going to go back and
3006.4|5.159|mention neural fields very briefly um
3013.68|3.12|yeah when i train that top-down neural
3015.68|2.8|network
3016.8|4.799|i have a problem
3018.48|3.119|and the problem is
3021.92|4.08|if you look at those red arrows and
3023.44|4.48|those green arrows
3026.0|3.359|they're quite different
3027.92|3.04|but if you look at the level above the
3029.359|4.72|object level
3030.96|4.399|all those vectors are the same
3034.079|3.201|and of course
3035.359|3.361|in an engineered system i want to
3037.28|3.36|replicate the neural nets in every
3038.72|4.8|location so i use exactly the same top
3040.64|4.959|down in modern neural nets everywhere
3043.52|3.52|and so the question is how can the same
3045.599|3.601|neural net
3047.04|3.92|be given a black arrow
3049.2|3.119|and sometimes produce a red arrow and
3050.96|3.52|sometimes produce a green arrow which
3052.319|3.921|have quite different orientations
3054.48|3.44|how can it produce
3056.24|3.92|a nose where there's nose and a mouth
3057.92|4.24|where there's max even though the face
3060.16|3.6|vector is the same everywhere
3062.16|4.08|and the answer is
3063.76|3.52|the top-down neural network doesn't just
3066.24|4.56|get
3067.28|5.44|the face vector it also gets the
3070.8|3.12|location of the patch for which is
3072.72|3.44|producing
3073.92|3.76|the part vector
3076.16|3.28|so the three patches that should get the
3077.68|3.679|red vector are different from the
3079.44|4.08|different locations from the three
3081.359|4.0|patches that should get the green vector
3083.52|3.76|so if i use the neural network that gets
3085.359|3.441|the location as input as well
3087.28|3.76|here's what it can do
3088.8|5.12|it can take the pose that's encoded in
3091.04|5.36|that black vector the pose of the face
3093.92|4.0|it can take the location
3096.4|3.28|in the image
3097.92|3.76|for which is predicting the vector of
3099.68|3.76|the level below
3101.68|3.84|and the pose is relative to the image
3103.44|3.6|too so knowing the location in the image
3105.52|3.36|and knowing the pose of the whole face
3107.04|4.72|it can figure out which bit of the face
3108.88|3.92|it needs to predict at that
3111.76|2.799|location
3112.8|3.68|and so in one location you can predict
3114.559|3.681|okay there should be nose there and it
3116.48|4.0|gives you the rib vector in another
3118.24|4.0|location it can predict from where that
3120.48|4.079|image patch is there should be mouth
3122.24|3.92|there so it can give you the green arrow
3124.559|3.601|so you can get the same vector at the
3126.16|3.919|level above to predict different vectors
3128.16|3.439|in different places level below by
3130.079|3.361|giving it the place that it's predicting
3131.599|4.841|for and that's what's going on in neural
3133.44|3.0|fields
3138.96|2.08|okay
3139.92|3.439|um
3141.04|4.4|now this was quite a complicated talk
3143.359|4.081|there's a long paper about it on archive
3145.44|4.56|that goes into much more detail
3147.44|4.96|um and you could view this talk as just
3150.0|3.68|an encouragement to read that paper
3152.4|4.08|when i'm done
3153.68|2.8|exactly on time
3158.88|4.679|okay thank you so great thanks a lot
3167.68|2.08|you