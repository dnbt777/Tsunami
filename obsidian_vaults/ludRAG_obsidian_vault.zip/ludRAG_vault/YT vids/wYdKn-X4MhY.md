start_time|end_time|text
1.6|3.24| Yeah, since all good things come in threes, and there's GPT
4.84|5.72| version three. So this is the last model in this GPT saga. So
10.58|4.06| GPT three is again, much larger than the previous model. So it's
14.64|6.52| instead of 1.5 billion, it's now 175 billion parameters. And if
21.16|3.44| you're again interested in more details, there is the paper
24.6|3.04| here on archive. So again, in this video, we will have only a
27.64|3.16| very short summary and details you can be found in this paper.
31.04|2.42| It's actually a very long paper, I think it was like 40 or 50
33.46|6.38| pages. So have fun. Okay. So the architecture overall is again,
40.24|3.56| overall similar to GPT version two, but of course, it's not
43.84|3.64| much bigger. So there are also more layers and so forth. They
47.48|4.48| also doubled the context size. So instead of having 2024 input
51.96|4.48| tokens, they have no 2048. The word embeddings are also
56.44|4.16| substantially larger. So instead of 1.6 1000, they all have
60.6|5.28| approximately 12,800. And they also to make things feasible
65.88|4.28| computationally. They use this intention pattern from the sparse
70.16|3.52| transformer because attention scales quadratically, it's quite
73.68|3.4| expensive. So they borrowed some concepts from a sparse
77.08|3.2| transformer, which is, again, something we won't go into too
80.32|3.56| much detail. But here is the name of the paper if you want to
83.88|3.6| read up on more details about this sparse transformer
87.48|4.68| architecture. Okay, so the data sets are also substantially
92.16|3.76| larger. So they had in the GPT version two, if you recall this
95.92|3.88| web text data set consisting of I think it was 8 million
99.8|3.28| websites or documents. So they have now a version two of that
103.08|4.56| with 19 billion tokens. So they didn't say how many tokens were
107.64|4.92| in web text ones, I'm not sure how much bigger it is, but
112.56|4.04| sounds big 19 billion, they have an even bigger data set called
116.6|3.6| common crawl for a 10 billion. They have book data sets. And
120.2|4.16| they also still have that Wikipedia data set. Here are
124.36|3.72| just some weighting how much weight these data sets had in
128.12|5.68| the total training procedure. Then on this implicit task
133.8|2.84| learning, so they say essentially, that when they are
136.64|4.32| doing the unsupervised pre training, the self supervised
140.96|3.76| learning here, they call that the outer loop. So it's just a
144.72|3.46| regular training. And they make the argument that while they are
148.18|3.86| doing that, because of the rich information in these texts,
152.28|4.76| implicitly, the model learns, or does this so called in context
157.04|4.48| learning where it sees examples like this, and so forth. So like
161.52|6.0| spelling, corrections, and these types of things. And yeah,
167.52|9.52| there are these in context learning tasks. Now, then again,
177.04|4.16| they don't use any fine tuning similar to GPT version two. So
181.2|3.36| again, in GPT version one, they used fine tuning after the pre
184.56|4.24| training and GPT version two, they got rid of it. And also in
188.8|6.24| GPT version three, they don't use any fine tuning. However, in
195.04|4.4| GPT version two, they only use this zero shot transfer to
199.44|2.86| provide context. Now the in addition to that, how they have
202.3|4.98| one shot and few shot contexts where they at least provide some
207.28|4.6| examples of the task to the model. So for instance, in GPT
211.88|5.16| version two, the task in the zero shot transfer may look like
217.04|2.96| this, where you have the prompt or description, sorry, the
220.0|3.44| description, translate English to French column, this is the
223.44|3.16| input. Together, you provide also the prompt as the input,
226.88|3.64| like cheese, and then an arrow. And then you should learn how to
230.52|3.32| get translate the word cheese into the French version, which I
233.88|4.76| by the way, don't know. In any case, so and then in this one
238.64|2.8| short one, they would at least provide one example. So they
241.44|3.6| still have this task description. But also, as an
245.04|5.28| example, they provide this translation from sea otter to I
250.32|2.64| don't even want to try to pronounce it, because I know it
252.96|3.48| would be ridiculous when I try because unfortunately, I don't
256.48|4.44| speak French. But the point here is that they provide an example
260.92|3.14| of what the model is attempting or should attempt to do. And
264.06|3.92| then in few shot, they provide multiple examples, they say they
267.98|4.62| provide as many examples as can be fit into the context. And
272.6|6.0| it's usually around 10 to 100 examples. So for instance, sea
278.6|4.92| otter, peppermint, plus giraffe, and so forth. And then this is
283.52|6.44| the prompt for the model again. And again, here in contrast, the
289.96|4.36| traditional fine tuning, for example, in GPT version one, you
294.32|3.42| would, you would provide examples, then do a gradient
297.74|2.34| descent update, provide examples, gradient descent
300.08|3.4| update, this would be essentially supervised
303.48|6.04| learning. They don't do that in GPT version three, though, they
309.52|4.34| just use these contexts as input. And the model should
313.86|4.94| figure out by itself what to do essentially. And yeah, they
318.8|6.2| found that providing more examples helps with model
325.0|4.76| performance. So at the bottom here, that's the zero shot. And
329.76|3.96| x, the x axis here, that's the number of parameters. So from
333.96|3.48| small model to a large model. And you can see consistently that
337.44|4.48| one shot, and few shot is an improvement over zero shot. So
341.92|4.24| there's almost like a constant improvement, if you use multiple
346.16|4.12| examples as input. And you can see, when you train a very large
350.28|4.48| language model, like this one here, and have this few short
354.76|4.8| few short examples, it can, on a trivia question answering task,
359.76|3.56| even outperform the previous state of the art, which was
363.32|3.04| quite impressive, because it's not trained for question
366.36|3.6| answering. It's essentially figuring it out by itself by
369.96|5.84| looking at a few examples. Okay, yeah, and this was already GPT
375.8|2.96| version three. So essentially, it was about making the model
378.76|6.8| larger, and also providing these one shot and few short examples
385.56|5.36| in addition to zero shot. Okay, so next, this is actually an
390.92|3.76| older model. It's from 2019, I think. But it's quite
394.68|15.24| interesting because it combines both BERT and GPT concepts.