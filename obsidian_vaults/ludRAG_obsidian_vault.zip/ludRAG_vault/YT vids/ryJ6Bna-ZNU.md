start_time|end_time|text
1.24|2.76| Yeah, let's now discuss the concept of the convolutional
4.0|3.48| filters and the weight sharing principle that I briefly
7.48|3.6| mentioned in the previous video in more detail here. So
11.08|3.32| basically, I'm just stepping through the process of applying
14.4|4.2| a filter a little bit more slowly now. So I mentioned in
18.6|4.68| the previous video, there's this concept of weight sharing. So we
23.28|6.92| have a feature detector, which we also call filter or kernel, I
30.2|3.52| actually like the term feature detector, because it kind of
33.72|4.08| describes what it is doing here. So we slide this feature
37.8|4.6| detector over the inputs to generate a feature map. So here,
42.64|3.62| this is what I'm illustrating in the center here, we have, for
46.26|4.14| instance, here, an M list, handwritten digit, for instance,
50.4|5.96| the digit five here. And then we have a three by three feature
56.36|5.28| detector or kernel. And then we are we compute this feature map
61.64|8.94| here. And when we apply this kernel to a region in on this
70.58|3.94| image, or in this image, we call this region in the image, the
74.52|4.64| receptive field. So these nine pixels that we are overlaying
79.16|4.74| with this feature detector are called the receptive field. So I
83.9|3.66| do that and then compute this value here. How is this value
87.56|4.08| computed in the feature map. So this is computed simply by
91.96|5.38| computing the weighted sum. So the kernel, you can think of it
97.36|5.72| as a weight matrix. Let's make it a bit bigger. Don't have much
103.08|5.76| space here, to be honest. Let's do it like this. So this is my
109.72|4.52| kernel here. And this is a three by three one. So I have a weight
114.24|9.8| that's a w one, w two, w three, w four, w five, six, seven, eight,
124.48|5.84| nine. And this is overlaid with a receptive field. So the
130.32|3.24| receptive field, it's the part of the image that lies below
133.56|5.44| here. So it is also a three by three matrix, these are the
139.0|6.16| pixels, right? So in this case, it's called an x one, three, up
145.16|6.6| to x nine. And then we do just a multiplication. So we are
151.76|3.68| waiting, we are applying a weight to each pixel value here.
155.44|5.78| And that is how we obtain this part here. So why? Why this
161.22|2.78| weight sharing? Well, one advantage of this weight sharing
164.0|4.2| really is that we require fewer parameters, if we had a feature
168.2|4.0| detector for each separate one for each region here, that would
172.2|3.12| be computationally very expensive. I mean, we would have
175.32|2.4| a lot of weight, and then we would essentially have a fully
177.72|2.96| connected, not a fully connected, but we are getting
180.68|3.12| closer to a fully connected network, then. So in that way,
183.8|5.36| that would be a pretty extensive or expensive model. And the
189.16|4.32| other one, the other reason is, there's an idea behind using
193.48|4.12| just the same same filter, sliding it over the image. And
197.6|3.16| the idea is essentially that if we have a feature detector that
200.76|3.76| for instance, can detect edges, I will show you examples later.
204.52|2.76| But let's say the feature detector can detect whether
207.28|4.28| there's an edge or something, then the same feature detector
211.56|3.56| is useful in different parts of the image. So let's say, I have
215.12|3.56| a feature detector and the goal, it learns to extract certain
218.68|4.28| edges, because that's associated with this number. So you would
222.96|2.92| use them the same feature detector in several regions,
225.88|4.12| there's no need to develop a new feature detector if the goal is
230.0|4.42| to detect edges, I will show you in a later video, what the
234.42|3.14| network really learns. So it's learning certain types of feature
237.56|4.88| detectors, and I will show you a few examples of that. But yeah,
242.44|3.68| just to illustrate now the concept of how we apply this
246.24|5.0| filter. So I actually copy and pasted the same slide. And so
251.24|4.08| you can see here, what I'm doing is from going from here, I move
255.32|4.6| it by one pixel row to the right here, right. And then I'm moving
259.92|4.68| into the right and so forth. And then you can see here, I'm
264.6|5.44| computing these pixels one at a time. And then this is my
270.08|7.32| feature map, I can then either apply the sub sampling, what we
277.4|5.08| also call pooling. Or I can apply another convolutional
282.48|3.2| operation. For instance, I could have another convolution layer,
285.88|7.16| that is another three by three, and then project this into the
293.04|5.96| next feature map, and so forth. So by that, the network is
299.52|5.8| consecutively extracting these feature from an image. So going
305.32|2.8| here one more time, so it's going this direction from left
308.12|3.92| to right. And then when we completed this row, then we go
312.16|4.12| here to the next row, and then we go through this again, and
316.28|6.64| again, till we are finished with this picture, essentially. So
323.32|3.76| this was explaining how we use a single feature detector. So this
327.08|4.24| is a single feature detector that we slide over the image. So
331.32|4.16| we get one feature map. And this might be a feature detector
335.48|2.92| that the network learns for detecting edges. But there might
338.4|3.84| also be some other feature detector that might be learned
342.24|2.8| for other types of information from the image, for example, in
345.04|3.36| this case, there might be a feature detector learned to,
349.72|3.6| let's say to, to recognize horizontal edges. So we would
353.32|3.4| have to have a different feature detector, a different filter for
356.72|3.2| that, for instance, if this particular one learns this year,
360.36|4.04| another filter, maybe, let's say we make this a green one.
366.72|4.6| Another filter is applied, it would also slide the same way to
371.32|3.64| recognize these horizontal edges. So how can we use more
374.96|4.32| multiple feature detectors in a convolution network? So here's
379.28|4.8| just an illustration of that. It's essentially very simple, we
384.12|3.24| just apply them independently. So here, I'm using multiple
387.36|6.36| feature detectors to create multiple feature maps. So what
393.72|3.4| I'm showing you at the top, that is exactly the same thing I
397.12|3.12| showed you before, where we apply this kernel, get to this
400.24|4.2| image here. And we had this three by three weight matrix,
404.44|4.72| which is our filter or kernel. Now I have another one, the blue
409.16|4.52| one here, it's the same concept, I'm again sliding it over here.
413.88|2.6| The only difference is that the weights will be different. So
416.64|2.8| the green and the blue one, they have different weights. That's
419.44|3.16| the only difference. And I can have maybe a third one here. And
422.6|2.88| this third one again has different weights. So in that
425.48|3.48| way, I can obtain three different feature maps by just
428.96|6.96| using three different filters. Now, one thing I only briefly
435.92|4.12| mentioned in the previous video, that's the size before and after
440.04|3.56| applying these convolutions. So the convolution is essentially
443.6|4.92| this operation of going from here to here and filling out this
448.52|5.04| feature map that is essentially the convolution. And what is
453.56|6.96| the size essentially going from here to here. So I showed you in
460.52|4.6| the Lynette, they had what was it? Honestly, I forgot. But
465.96|7.84| let's say we have a 3032 by 32 input image. I think that's what
473.8|5.2| they had in this on Lynette five. And then they had a five
479.0|6.16| by five kernel. So what would be the output size of that? So the
485.16|6.84| output size going from, let's say the handwritten letter to
492.0|8.72| the feature map. So this was 32 by 32. And this one applies a
500.72|5.58| five by five kernel, what would be the output size. So the
506.3|4.82| output size would be 28. Why would it be 28. So there's
511.12|2.74| actually a formula that you can use to compute the output size.
514.68|8.16| So w is the input width. So that's the the width of the input
522.84|6.08| image, then k is the kernel width that is. So let's see.
530.04|2.92| Okay, here's the width of the kernel that's five in this case.
532.96|8.6| So we have 325. And then padding. So what is padding, I
541.56|2.76| will discuss padding actually in the next lecture, because there
544.32|5.2| are already too many concepts to discuss right now, one thing at
549.52|2.88| a time, right. So padding is when you would essentially add
552.44|4.8| zeros around your image, we will again discuss this in a next
557.24|2.48| lecture. So in this case, you can ignore padding, we don't
559.72|3.0| have padding here. And then there's a stride, what does the
562.72|4.12| stride mean? The stride means by how many pixels we move the
566.84|3.92| kernel. So if we only move the kernel here by one row, by one
570.76|3.96| pixel row, then we have a stride of one, if we move the kernel
574.72|3.68| by two rows, so it's maybe easier to show if I make a new
578.4|11.72| drawing. So if these are my my pixel rows, I can have this
590.12|4.2| kernel like here, like a three by three kernel. And then if I
594.32|6.52| move it to the right by one row, I'm here, but I could have also
600.84|6.24| moved it by two rows. So that would be a stride of two. So
607.08|3.4| stride is really by how many rows we move to the right. And
610.48|3.28| the same also, it's actually columns, sorry, how many columns
613.76|3.52| we move to the right. But the same thing also applies to the
617.28|4.48| to the rows, how many rows we move to the bottom in each, when
621.76|2.84| we finished basically processing the columns, the next row, how
624.6|7.16| many rows we shift down. So for simplicity, we had a convolution
631.88|4.32| with stride equals one, so we were moving only one position to
636.2|3.56| the right, and then one position to the bottom. So in our case,
639.76|3.8| we had a stride of one. So we can actually use a stride of two
643.56|3.2| again, that is a topic I will cover in the next lecture. And
646.76|4.92| that would essentially reduce the size. Anyways, now putting
651.68|6.6| everything together. 32 minus five divided by one, that is
658.28|5.64| 27 plus one, that should be 28. Right? So this is why the output
663.92|4.08| image is 28. That happens really, because we are we're
668.0|3.68| cutting off, right? So we are not allowing anything where the
671.68|3.04| kernel overlaps. So when we move that to the right, at some point,
674.72|4.84| we will reach the edge here. And there's no overlap allowed. If
679.56|2.32| we want to allow an overlap, that's where we use the padding,
681.88|2.72| which is a topic what we discuss next lecture. But yeah, that
684.6|5.16| gives you an idea that on this small, yeah, change or
689.76|5.2| difference between the input and the output size. So now what
694.96|4.76| about the number of trainable parameters for the convolution
699.72|4.28| layer of the kernel, essentially, so I will actually
704.0|3.68| show you a full code example at the end of the lecture where we
707.68|2.32| will train a convolutional network. But just for
710.0|4.32| illustration purposes, consider here this little snippet where I
714.32|5.24| was initializing a convolutional layer. So this is my input image
719.56|6.28| here, an MNIST image of size 28 by 28. And there's one channel
725.84|4.56| because it's grayscale, right? So the format here is channel
730.4|7.72| height, width, so 128 28. So when I initialize this layer,
738.52|3.0| what we have to specify is the number of input channels. So the
741.52|3.28| number of input channels in the input to that layer. So in this
744.8|3.04| case, it's one, that's why I'm specifying one. And then I have
747.84|4.12| to specify how many feature maps I want to get out of it, right.
752.12|5.56| So if I have my kernel, then and that produces then these can
757.68|5.64| actually make that larger, it produces these feature maps at
763.32|5.84| each position. So how many feature maps do I want? So 123
769.28|3.8| here specified that I wanted to have eight. And in practice,
773.08|4.88| usually, we add more and more channels, the deeper we go in
777.96|3.12| the network. Again, I will show you that in the concrete full
781.08|4.84| code example. Here, I want eight output feature maps. These are
785.92|2.28| essentially like these feature maps, just eight of them instead
788.2|4.4| of three. And I specify a kernel size of five by five with a
792.6|4.24| stride one by one. So five by five, that is always like height
796.84|4.28| and width. And also for the stride, it's the horizontal and
801.12|3.4| the vertical stride. So I just have a stride of one here. And
804.52|3.2| then when I look at the weight matrix that is associated with
807.72|4.28| this convolutional 2d layer, can see the number of parameters,
812.0|10.32| this is five by five, because I have a five by five kernel. And
822.32|5.32| then I have actually five, eight of these five by five kernels,
827.64|3.0| because I want to produce eight feature maps, right. So I would
830.64|11.68| have 12345678 of these kernels that I apply to the same input
842.32|5.28| image to create eight feature maps. That's why we have eight
847.64|4.96| times five times five parameters for the weight matrix. But then
852.6|4.36| there's also the bias. So there's one bias for each output
856.96|3.24| feature map that we add to all the values in the output feature
860.2|4.32| map. So the number of parameters is eight times one times five
864.52|4.2| times five plus eight. That's the number of trainable
868.72|3.6| parameters. And actually, this is pretty small, right. So if
872.32|3.24| you consider a fully connected layer that is applied to an
875.56|5.44| MNIST image, fully connected layer, this would be 28 times
881.0|11.44| 28 plus whatever number saw in the next layer we want. So if we
892.44|2.84| say the next, so if we have a fully connected network like
895.28|5.32| this, and we are next layer, let's say has 10 units only, and
900.6|2.84| the first layer is the input image, so not at four, then I
903.44|5.44| already have four fully connected network 7,840 weights,
908.88|2.96| that's a much bigger number than this number here, right. So in
911.84|4.52| this case, actually, usually, conversion networks are very
916.6|5.4| memory efficient compared to a fully connected network. Alright,
922.0|4.96| moving on, just a small side note, one attractive aspect
926.96|3.8| about convolutional networks is also that they have certain,
931.0|5.44| yeah, to a certain extent, some translation rotation and scale
936.44|3.64| invariance, but it is not a true invariance. So invariance here
940.08|2.88| means that it doesn't matter where the object is in that
942.96|4.04| input image, where it is located. But in fact, in reality,
947.0|4.76| it does matter a little bit. Because even though we use the
951.76|4.2| same feature detector, so whether the feature detector is applied
955.96|5.0| here, or here, it will compute the same output, in a sense, the
960.96|4.0| same value, right, because it's a multiplication between the
964.96|4.56| inputs and the weights. But where it puts this value
969.88|4.04| matters, it depends really on where where this object is
973.92|4.12| located in that image. So to some extent, it's not fully
978.12|3.32| invariant to the position rotation and the scale of that
981.44|3.8| object. It's only, I would say invariant to a small extent,
985.24|4.96| it's called also a query variant. But if you do, or if
990.2|3.26| you use a lot of convolutions in succession, if you have a very
993.46|3.9| deep network, it will essentially become more and more invariant
997.36|3.72| to the position of the object, because you would essentially
1001.08|4.48| further, let's say, summarize this information into a smaller
1006.76|3.24| into a smaller region of feature map. And then in the smaller
1010.0|4.64| feature map later on, this detected object may map into the
1014.64|4.24| same position, if whether whether it's located here, or
1018.88|6.12| whether it's located here. Alright, um, yeah, lastly, maybe
1025.0|5.24| one more note, what also is helpful for improving the
1030.24|4.92| invariance are these max pooling layers. Nowadays, honestly, not
1035.2|4.04| all networks use max pooling anymore, you can actually get
1039.24|3.36| pretty good performance without max pooling. So max pooling,
1042.6|4.64| again, is this sub sampling, we will see some architectures or
1047.24|3.32| multiple architectures in next week's lecture. So there will,
1050.56|3.58| you will also see some with and some without max pooling. But
1054.14|3.82| traditionally, max pooling, there was also an operation that
1057.96|5.28| was used between each convolution layer to reduce the
1063.24|4.96| size of the feature maps. So for instance, how max pooling works
1068.2|5.8| is, it is essentially just retrieving the largest element
1074.0|3.44| in the feature map. So if this is, let's say you are your
1077.44|3.0| feature map, this whole thing is your feature map, and you have a
1080.6|8.04| three by three max pooling. Um, I would call it max pooling map
1088.64|4.92| or something like that, or max pooling detector. So if you
1093.6|4.32| apply three by three max pooling here, it will again, similar to
1097.92|4.56| the convolution slide over the image. Here, we have a stride of
1102.48|4.68| three by three, so it will slide by three pixels instead of a
1107.16|3.36| stride of one. And what it will do, usually people use a stride
1110.52|3.2| of 234, and things like that. But here for illustration
1113.72|2.08| purposes, we have a three by three. And what it will do is
1115.8|3.96| for each one, it will retrieve the maximum, the highest value.
1119.76|2.76| That's why it's called max pooling. So in this case, if I
1122.52|4.24| look at this first region here, this first receptive field, I
1126.76|3.02| will take this eight because it's the largest value, and I
1129.78|4.62| put it into my feature map. And then I move it by three pixels
1134.4|3.24| to the right. So I'm now here. And then again, I look at the
1137.64|3.66| largest value, it's a five, I will put it here. And then here,
1141.56|2.24| in the left corner, there's actually a tie, it's a six into
1143.8|3.24| six. So largest value is six, and we'll put it here. And then
1147.04|4.16| here, the three. Another version of pooling is mean pooling or
1151.2|3.78| average pooling. But that is not so commonly used as max pooling
1154.98|3.26| max pooling is actually also quite useful because it can
1158.24|3.96| help a little bit also with this local invariance because it
1162.2|2.04| really here doesn't matter whether the eight is located
1164.24|5.8| here, or here or here. So whether the object is, let's
1170.04|3.36| say more slightly to the left or to the right in this image, it
1173.4|3.04| would be kind of invariant to that. So in that way, it can
1176.44|6.24| help a little bit with this local invariance. Yeah, one
1182.68|3.24| notice also that pooling layers usually don't have any
1185.92|3.68| learnable parameters. Of course, people are creative, there are
1189.6|3.24| actually some learnable pooling layers with parameters, but the
1192.84|2.56| common ones like mean or average pooling, they don't have any
1195.58|4.02| weight parameters or learnable parameters. Alright, so this was
1199.6|4.36| your explanation of how convolutional filters and the
1203.96|2.96| weight sharing concept works. In the next video, I want to
1206.92|3.72| briefly do some nitpicking to go over cross correlation versus
1210.74|2.66| convolution, maybe also helps a little bit again, with
1213.4|3.44| understanding how these filters work. And then we will briefly
1216.84|26.8| talk about CNNs and backpropagation.