start_time|end_time|text
0.76|3.86| Yeah, all good things and all lectures come to an end. So this
4.62|4.46| is the last topic in the series on commercial network
9.08|4.68| architectures. So this is not really a topic specific to
13.76|2.84| conversion networks. But I think right now is a good time to talk
16.6|3.64| about it, because there are some nice pre trained computer vision
20.24|3.4| models available that could be useful for this. So the topic is
23.68|3.32| transfer learning. And I think transfer learning is particularly
27.0|4.88| useful for your class projects. So the key idea here is that in
31.88|4.28| a convolutional network, we have this feature extraction part.
42.88|3.62| feature extraction, let's write it like this. And then we have
46.5|5.66| these fully connected layers, or also convolution layers, as you
52.42|2.58| remember from the previous two videos, but let's call them for
55.0|4.28| the fully connected layers or linear layers. These are
59.28|3.44| usually the ones, the multi layers perceptron part that we
62.72|4.68| use for classification or classifier part. And the idea in
67.4|4.28| transfer learning is that these convolution layers here, this
71.72|4.44| automatic feature extraction pipeline might be useful for
76.16|5.08| other related tasks as well. So for instance, I know that a lot
81.24|3.44| of you are working on projects, class projects related to
84.68|5.8| COVID-19 prediction from chest x ray data. So there might be an
90.48|3.44| hypothesis that let's say a network trained on a large
93.92|5.04| medical x ray chest x ray data set, not related to COVID-19
98.96|4.2| more general might be also useful for COVID-19 detection if
103.16|5.48| it's fine tuned on the data. So usually we in deep learning have
108.64|4.08| these large benchmark data sets. But they are usually only used
112.72|4.76| for of course, comparing and benchmarking different models.
117.68|3.12| In a real application, you usually have a much smaller
120.8|3.08| data set. So the question is, can we leverage these large
123.88|3.64| amounts of data, train the network on those and then
127.52|4.84| fine tune those networks on our smaller target data set. So the
132.36|2.76| idea is that the feature extraction layers may be may be
135.52|3.88| generally useful. And then we can use pre trained models, for
139.4|4.32| instance, models pre trained on ImageNet, freeze the weights. So
143.72|4.76| that means when we are freezing these weights, keeping them
148.48|3.64| fixed, not updating them, and only training the last few
152.12|3.6| layers like the fully connected layers, the multilayer
155.76|4.4| perceptron part. So this would be in the nutshell, this would
160.16|4.72| be transfer learning related to that. There's also the approach
164.88|3.56| that you train the whole network on a given data set, and then
168.44|3.4| fine tune the whole network to the smaller data set. So it's
171.84|3.56| essentially just a special case of transfer learning, where you
175.4|6.0| don't freeze the weights. So he has a screenshot from an older
181.4|3.84| paper, it's on a large scale video classification with
185.24|5.16| convolutional networks. But this kind of is a nice summary of
190.48|5.88| what options we have when we use transfer learning. So focusing
196.36|4.24| on this here, so they evaluated the performance by training a
200.6|3.36| conversion network from scratch. So here they're talking about
203.96|5.76| the accuracy, they got a 41% accuracy, they pre trained a
209.72|4.24| network on a large data set, and then only fine tuned the last
214.0|3.92| layer, top layer means the output layer, they got a 64%
217.92|3.52| accuracy, fine tuning the top three layers. So the last three
221.44|4.36| layers, they got the best accuracy 65%. And fine tuning
225.8|6.28| all layers, they got 62%. So here, based on this, of course,
232.08|4.28| it's just one experiment or one scenario. Based on this case,
236.36|5.4| here, they got or they found out that tuning three layers gives
241.76|3.12| the best results. But of course, your mileage may vary, it really
244.88|3.72| depends on the network architecture on the data set,
248.64|4.88| and many other things. So it's not a general case that this is
253.52|2.6| that this is always true. So in practice, it's just another
256.12|3.48| hyper parameter. So how many layers to fine tune is just
259.6|4.6| another hyper parameter to consider. But yeah, you can also
264.2|4.4| see even so what is also interesting when you look at
268.6|5.0| these two here, that train from scratch is much worse, let's say
273.6|3.44| than pre training the network on a large data set and then fine
277.04|4.2| tuning it, even if you don't freeze any layers, I will show
281.24|2.84| you in the next video how we can do this in Python. So for now,
284.4|3.0| if this is very abstract, we will get more concrete in the
287.4|4.16| next video. So here's what I'm going to show you in the next
291.56|3.2| video. So because we learned already about the g 16, it's
294.76|3.8| probably the easiest one to explain. But of course, this is
298.56|3.16| a very general concept. So what we are going to do in the next
301.72|4.4| video is we are going to freeze the convolution layers. And then
306.12|4.92| I will show you how we can replace. So I should say, first,
311.04|2.88| we use a pre trained version that has been trained on image
313.92|5.36| net, then we freeze these layers and replace the output layers,
319.44|3.92| and then fine tune these on a different data set, we are going
323.36|4.32| to use cipher 10. But of course, it could be any data set. It's
327.68|3.76| just because cipher 10 is already in pytorch. So you
331.44|3.16| don't have to download anything. So I'm always using cipher 10 to
334.6|4.68| just make the code simpler or smaller. I showed you before how
339.28|2.92| you can use your own data set. But I don't want you to always
342.2|2.6| have to download a data set when you run the code examples from
344.8|4.32| class. So in this way, we use cipher 10. But of course, this is
349.12|6.16| a very general concept. So there are besides VGG 16, also other
355.28|3.64| models available. So VGG 16 might not be the best model we
358.92|3.84| have learned, it's actually not the best performing one, it's
362.76|3.28| also very expensive. So for instance, for your class
366.04|3.76| projects, except if you want to get a get a good performance on
369.88|4.04| the wide resonant is actually pretty good. And inception,
374.24|2.88| version three is also pretty good in terms of performance, but
377.12|2.52| they're also slow to run. The good one is actually mobile
379.64|2.96| net, it's actually pretty fast, well performing network. And of
382.6|3.12| course, our residual nets, but the other wide, wide residual
385.72|3.44| net could can be sometimes better. Not always when I tested
389.16|4.04| it on cipher 10, it actually was worse than the regular resonant.
393.2|4.76| So also your mileage may vary there. So okay, so one more
397.96|3.0| thing, when we do transfer learning, I also wanted to warn
400.96|5.16| you, you have to double check how the people who pre trained
406.12|3.84| the network and provided to you how they normalize the data. So
409.96|3.4| you can of course, train or pre train the networks yourself.
413.36|4.88| But in pytorch, there are some of these models available that
418.24|2.8| have been pre trained on image net. If you want to use those,
421.04|3.08| you have to be careful to use the same data normalization that
424.12|4.12| they used. And for image net, they used this normalization. So
428.24|4.64| usually before we used point 5.5 and point five, because we
433.16|4.16| observed that whether we do that, or compute the exact mean
437.32|3.72| and subdivation doesn't make any difference in practice. But
441.12|2.48| because they use these parameters, we also have to use
443.6|3.16| the same parameters when we apply to a different data set
446.76|3.64| to make sure our data is on the same scale as the network might
450.4|4.2| expect. Alright, so in the next video, I will show you then
454.6|26.88| concretely how that looks like in pytorch.