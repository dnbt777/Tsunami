start_time|end_time|text
0.84|2.28| Yeah, like I mentioned in the previous video, I wanted to
3.12|4.04| share some techniques with you for improving the generalization
7.16|5.72| performance of a model. So I did a very spontaneous brainstorming
12.88|3.2| session where I took a mind map software and just wrote down
16.08|4.16| everything I know that came to mind. This list might not be
20.24|2.24| very exhaustive. There might be other techniques I'm not
22.48|3.8| listening here. Here was really just focusing on the most
26.28|5.0| popular ones that came to mind that are useful in practice. And
31.28|2.8| yeah, of course, we can't cover all of them in detail in this
34.08|3.0| course, because there are so many other topics to talk about.
37.44|3.32| But at least you get the big picture and you may want to look
40.76|3.04| into some of these techniques that you could find useful for
43.8|3.68| your class project. So like I said, this was pretty
47.48|3.48| spontaneous. So there might be different ways to organize this
50.96|3.14| better, but I chose a few categories to have some
54.1|3.82| structure to this. So one category is I call it data set.
58.3|3.74| So here I'm referring to techniques that really modify
62.62|3.26| either the features or the labels in the data set, or even
66.0|6.24| yeah, creating new data sets or using different data sets. So I
72.24|3.58| would say personally, one of the best bangs for the buck, if you
75.82|2.26| want to improve model performance is collecting more
78.08|3.68| data, if you can. This is not always the case, of course, but
81.76|3.2| there are many scenarios where more data can generally be
84.96|3.4| helpful. And this will also be something I will discuss a
88.36|3.56| little bit more in detail in the next lecture. Sorry, not next
91.92|4.0| lecture. In the next video, I will show you a graphic or plot
96.16|3.24| that can help you finding out whether more data could be
99.4|4.36| useful. Another technique is data augmentation. So this is
103.76|4.36| for modifying the input features. So by for instance,
108.12|3.64| rotating an image and things like that. And that is also
111.76|3.76| something I will talk more about in the next video. So yeah,
115.52|4.18| another technique is label smoothing. Personally, I
119.7|3.82| haven't really worked with that extensively, I only have used
123.52|3.2| that in the context of generative adversarial
126.72|3.32| networks. But I think it can be also useful in a general
130.52|3.52| classification context. It's basically preventing the
134.08|3.44| classifier to become too confident. And that can be
137.52|3.64| achieved by instead of using, let's say, zero one labels by
141.16|3.32| having softer versions of that, for instance, set of, let's say
144.52|4.84| zero and one, we can use point one and point nine. And this has
149.36|4.16| been shown to be helpful in the context of generative adversarial
153.52|3.16| networks. And I can think of also classification of being
157.68|5.64| positively affected by that in certain cases. Then our big
163.32|3.88| topic is yeah, leveraging unlabeled data. We talked about
167.2|2.88| this a little bit in the introduction to this course. So
170.08|3.96| one approach is semi supervised learning, which is essentially
174.04|5.4| about leveraging unlabeled data by looking at how confident your
179.44|4.0| classifier is. So you fit your classifier on the subset of
183.44|3.68| labeled data, and then you apply it to unlabeled data. For
187.12|2.64| example, if you have a larger data set, where you have data
189.76|4.2| points that are not labeled yet. And if the classifier is very
193.96|5.08| confident for some of those, then you may consider them, or
199.06|2.98| you can consider the predicted labels as the true labels to
202.36|4.44| make your training set larger. Self supervised learning is a
206.8|3.56| little bit different. So self supervised learning is also
210.36|4.56| leveraging unlabeled data. But here, you create a so called
214.92|5.56| pretext task, where you make up a different classification task
220.48|4.4| for which you can create the data yourself. So I showed you
224.88|3.7| an introduction to this course, like an example of solving a
228.58|3.98| jigsaw puzzle where you take an image, and then you divide that
232.56|3.0| image into smaller sub images, and then you train a network to
235.56|2.88| predict the order of these images that would be, for
238.44|2.4| example, self supervised learning. But yeah, these are
240.96|3.36| topics on both semi supervised and self supervised learning that
244.32|4.52| go a little bit beyond the scope of this course, that might be a
248.84|3.16| future topic for a different course at some point for more
252.0|5.78| like advanced topics. Yeah, so also related to what I just said
257.78|5.38| there's also a set of techniques for leveraging related data. So
263.28|3.2| self supervised learning is really like leveraging unlabeled
266.48|4.58| data that could be from the same domain or the same data set that
271.06|2.62| you're working with for which you have labels. So let's say
273.68|2.84| you have a data set for which you have labels, but you can
276.52|4.72| design this pretext task on the same data set. So here, you may
281.24|4.2| also consider related different data sets. So for instance, one
285.44|3.04| technique is called meta learning, where you essentially
288.52|3.12| learn how to learn like from different data sets, let's say
291.64|3.08| multiple small data sets, that's actually very common in the
294.72|5.28| context of future learning. And another is a bit unfortunate.
300.0|2.08| Another definition of meta learning is also really
302.52|3.24| learning from metadata, that is another thing. So you have
305.76|3.32| multiple data sets, you can create metadata and then train a
309.08|3.92| classifier on that metadata. And yeah, another technique is
313.04|3.52| transfer learning. So actually, this came up when I was just
316.56|4.48| grading class projects. So some students are working on COVID
321.08|4.36| 19 prediction from chest x ray data. So but the data sets are
325.44|3.2| very small. So one thing one could do is to collect a
329.04|3.52| different data set of lung x ray images, for instance, for
332.56|3.52| diagnosing a different disease. And then you train a classifier
336.08|3.32| on this large data set for let's say, I don't know some other
339.4|4.16| lung disease. And then after you train the model, you take that
343.56|4.36| model and fine tune it to the COVID 19 chest x ray database.
348.76|3.08| So we will talk about transfer learning also briefly later in
351.84|4.04| this course. So it's actually a very useful technique to. So
355.88|3.64| okay, this was all considering data sets. And so there's also
359.52|3.36| there are some techniques related to architecture set up
362.88|3.0| how you structure your architecture, the deep neural
365.88|3.64| network architecture. So there will be weight initialization
369.6|3.4| strategies, we will discuss that in this course. So I don't want
373.0|3.28| to talk too much about it at this point. Yeah, choosing
376.28|4.68| activation functions. We talked about this already on last week
380.96|2.4| when we talked about, for example, the relu activation
383.36|5.08| function, residual layers, they are so called, I consider them
388.44|2.76| as skip connections, I think they are sometimes called skip
391.2|3.68| connections. So we are skipping or we're adding a connection by
394.88|2.92| skipping certain layers that can also be helpful to avoid
398.24|2.96| vanishing and exploding gradient problems. And this is also
401.2|2.92| something we will talk later about this in this course. So
404.12|3.44| there's also a knowledge distillation. So this is beyond
407.56|2.32| the scope of scope of this course, but it's kind of an
409.88|3.28| interesting setup, where you train a large neural network,
413.28|3.56| and then you call it the teacher. And then you have a
416.84|3.08| smaller neural network, you call it the student network, and the
419.92|4.92| student network learns to predict based on the
424.84|2.72| predictions from the teacher. So you train the teacher on this
427.56|2.72| data set, and then you run this teacher to make or create the
430.28|3.04| predictions and you train the student usually a smaller
433.32|3.24| network on the predictions of the teacher. And what's kind of
436.56|3.48| interesting about that is, yeah, for the teacher, you can run it
440.08|4.2| infinitely on also larger data sets. So you can actually have
444.28|3.44| on the infinite in a way infinite predictions for the
447.72|5.8| student. Anyways, another set of techniques concerns
453.52|3.76| normalization, we talked already about input standardization, I
457.28|3.24| will mention it again in the next video when I show you the
460.52|3.92| data augmentation. There is also a set of techniques related to
464.44|3.44| batch normalization, this is related to input standardization,
467.88|4.8| but here, it's internal in the network. So instead of only
472.68|3.04| looking at the inputs to the network, we also look at all the
475.72|3.64| inputs to the hidden layers. So the hidden layer activations, and
479.36|3.24| we normalize those two, there also are more flavors of that
482.6|4.12| called group norm and instance norm and layer norm. And also
486.72|4.68| those are a topic for a future lecture in this course. Yeah,
491.4|2.96| weight standardization is also there are also techniques for
494.36|2.56| standardizing weights, it's kind of related to the weight
496.92|3.64| initialization on topic, but there are also additional topics
500.56|4.72| for that, and also gradient centralization. So gradient
505.28|5.28| centralization is similar to input standardization, except
510.56|4.44| that you normalize the gradients so that they have zero mean and
515.04|6.72| unit variance. So yeah, and next, there are techniques from
521.84|4.04| yeah, I would say modifying the training loop. So the for loop
525.88|3.0| over the epochs and the mini batches. And so what we can do
528.88|2.84| there in terms of the optimizer and things like that should have
531.72|3.24| maybe added something like different optimizers here,
534.96|3.52| because they are also optimizers that go beyond adaptive learning
538.48|5.28| rates. We will talk about this also in more detail in later
543.76|2.88| lectures. So for example, there are adaptive learning rates,
546.64|6.4| which are super helpful. They're also auxiliary auxiliary losses.
553.08|3.16| So we can add additional loss functions, intermediate layers,
556.24|3.72| and then also modify the training. Intermediately, we can
559.96|3.84| modify the network training by having these on additional loss
563.8|3.8| functions. So one common thing that comes to mind right now
567.6|2.92| would be the inception network. We will talk about that in the
570.52|2.68| convolution network section where we have multiple loss
573.2|2.48| functions that we combine from different places in the network.
575.92|3.92| And that helps also training the network. So just briefly, if you
579.84|3.88| have a network like that, usually you have the output
583.72|3.0| output here. And then you have a loss function and you have the
586.72|3.12| label. So you have the true label. So you have your input
589.84|5.0| image, the x goes into the network, oops. And the y goes
594.84|3.28| into the loss function together with y hat, the predicted label
598.28|4.52| or probability. So you get y y hat as the loss function that
602.8|4.76| you compute for backpropagation. But yeah, what you can also do
607.56|3.84| is you can also have intermediate value here,
611.4|3.56| intermediate prediction from the intermediate layer, and also add
614.96|3.88| that to the loss function, that is essentially how inception
618.84|2.84| works. And with that, you can make sure that if you have a
621.68|3.8| very big, big long network, that also the intermediate layers
625.48|3.68| are trained well. So Jung Ji and I, we also worked on a method
629.16|4.72| related to this topic called looking back, looking back to
634.8|6.04| earlier layers for designing better loss functions. Yeah,
640.84|3.72| then there's also gradient clipping. So avoiding, like very
644.56|4.84| large gradients. So if they go too large, we can clip them by
649.68|4.08| giving them giving it a maximum value. So that is also sometimes
653.76|4.8| helpful to avoid exploiting gradient problems. And now the
658.56|3.2| last set of techniques, I just put them also here, because
661.76|2.6| those are the ones that we are going to cover in this particular
664.36|3.92| lecture here, in addition to these topics. So we will talk
668.28|4.84| about l two regularization and l one regularization for adding a
673.12|4.52| penalty for large weights. So that helps with having smaller
677.64|3.24| weights. And that also helps with making the network less
680.92|3.84| sensitive to certain inputs. So that makes the network
684.76|2.8| predictions a little bit less noisy. So reducing the
687.56|3.96| variance. And we'll also talk about your early stopping by
691.56|3.56| looking at validation set performances, and then drop out,
695.12|3.56| like dropping random units in the network, which is kind of
698.68|3.28| like a way of adding noise to the network. And then helps also
701.96|3.84| with, yeah, overfitting. Alright, so this is just like the
705.8|2.16| big picture overview of all the different techniques that
708.0|2.96| spontaneously came to my mind, when it comes to improving
710.96|3.68| generalization performance. Again, we will talk about many of
714.64|3.28| these techniques, not all of them, but many. So just have to
717.92|3.36| be patient, because we can only talk about one thing at a time,
721.28|3.96| but think this is probably a useful overview for you. Alright,
725.24|3.44| so in the next video, we will talk then about overfitting by
728.68|4.36| considering making our data set larger, and by augmenting our
733.04|22.0| existing data.