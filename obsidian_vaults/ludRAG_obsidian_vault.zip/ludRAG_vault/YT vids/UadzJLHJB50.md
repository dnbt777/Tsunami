start_time|end_time|text
1.78|3.26| Okay, let's now talk about the three broad categories of
5.04|3.32| machine learning. So the three broad categories of machine
8.36|3.24| learning are supervised learning, unsupervised
11.6|4.32| learning, and reinforcement learning. So what is supervised
15.92|3.52| learning? supervised learning is, I would say the most common
19.44|4.36| form of machine learning or deep learning. So supervised learning
23.8|5.92| is the biggest subcategory. And it involves labeled data. So if
29.72|3.28| you recall the spam classification example, that
33.0|2.72| would be one example of a supervised problem, where we
35.72|5.0| want to predict whether an email is spam or not spam. And the
40.72|4.96| labeled data are then examples of spam and non spam email. And
45.68|3.48| it also involves direct feedback. So we can, yeah, we
49.16|2.76| can say whether our prediction was correct or not, basically.
51.92|3.04| So you, you have an example of an email that spam or not spam,
55.2|2.92| the model does a prediction. And if you, let's say during
58.12|2.56| evaluation, know the correct label, you have direct feedback
60.68|4.92| here, during the training. We will talk about this a little
65.6|3.26| bit more. So let me just briefly go over the three categories.
68.86|2.46| And then I will talk more about supervised learning, and the
71.32|3.44| others two. So unsupervised learning is, in contrast to
74.76|3.28| supervised learning, not involving any labeled data. So
78.04|3.88| here, we don't have labels or targets here, we also then don't
81.92|4.12| have feedback. So we assign, for example, a group to give an
86.04|3.2| example. For example, in clustering, we have cluster
89.24|2.48| memberships, but we don't have any feedback here. So it's more
91.72|2.56| really about finding a hidden structure in the data.
95.76|2.92| reinforcement learning is the third category of machine
98.68|3.92| learning. And here, this is more about learning a decision
102.6|4.96| process. So think about the example of the self driving car.
107.72|3.4| So the process of driving the car, it's like making multiple
111.12|3.92| decisions. It's like the goal here might be to arrive at a
115.04|2.92| destination, but to get there, you have to make a lot of
117.96|4.22| decisions like stopping at a red street light on turning around
122.18|3.58| the corner, and so forth. So here, what we do is we employ
125.76|4.28| in a reward system that rewards the agent for making correct
130.04|5.64| choices. And it's not like predicting a single outcome or
135.68|3.04| something. It's more about learning a series of actions
138.72|4.48| like steering the car through a difficult environment. And there
143.2|2.24| are some examples where you can actually use supervised
145.44|4.04| learning for self driving cars to, for example, recognizing
149.5|3.9| the streetlight itself, right, could be involving convolution
153.4|3.12| network, for example. But yeah, the process here is more like
156.52|3.8| learning a series of actions. We won't be talking about
160.32|3.36| reinforcement learning in this class, though, it's kind of out
163.68|3.56| of the scope of this class. Nowadays, you can also use deep
167.24|2.68| learning for reinforcement learning that is usually known
169.92|4.24| as deep Q learning. But yeah, this is really not in the scope
174.16|2.32| of this class. So here, we will be focusing more on supervised
176.48|3.04| and unsupervised learning. And as you have seen from the
179.52|2.44| introductory slides, where I showed you the topics, we already
181.96|4.76| have plenty of things to talk about in this class. So yeah, a
186.72|3.56| little bit more about supervised learning. So supervised
190.28|3.48| learning, like I said, is the largest subcategory of machine
193.76|3.72| learning, which is focused on label to data. So you already
197.48|2.76| from other statistics classes have seen an example of
200.24|3.68| supervised learning, that would be, for example, regression. So
204.0|4.44| here is just a sketch of a linear regression model. And
208.44|4.6| here, how this works is it's just a example with one
213.08|4.56| observational input, or we call that in machine learning feature.
218.44|2.92| So our x variable, the explanatory variable, we call
221.36|4.08| that the feature. And the target here, the dependent variable
225.44|4.64| that would be our y axis, or the data on the y axis here. And
230.88|5.24| here, we are fitting a linear model. So we, for example, can
236.12|3.6| then predict, if we have a new observation, what its target
239.72|4.72| value might be given this model. So these x's here, the training
244.44|3.08| data, think of it as the training data. And now think of
247.52|2.8| it as, let's say I have a new data point that is, let's say
250.32|4.8| here, sorry, if I go up here, so this is my input, I only know
255.12|4.0| the x value. So I know this x value to predict the y value, I
259.12|3.96| would go up here, and then look up the y value here. So using
263.08|3.52| this linear model, I can make predictions for new data points
266.76|3.48| for this one here, which is not in my data set, it would be one
270.24|4.26| example of a supervised learning problem. Another example of
274.5|2.82| supervised learning is classification. And actually,
277.32|2.44| classification is much more common than regression. If you
280.4|2.44| look at literature and deep learning. So most systems are
282.84|5.1| focused on classification, for example, recognizing objects and
287.94|4.34| images like is a cat or a dog or something like that. So we will
292.28|2.16| see a lot of examples of classification also in this
294.44|3.68| class. Or if you think back of the ATM machine that I showed
298.12|2.76| you earlier, where it was recognizing these handwritten
300.88|3.2| digits, it was recognizing or classifying these digit digits.
304.2|5.08| So whether it's a two or three or four, and so forth. Here's an
309.28|2.8| example of a binary classification problem, where we
312.08|5.08| only have two possible labels, one possible label is the minus
317.16|5.36| sign and one is the plus sign. So the labels here, either the
322.52|4.36| minus sign or the plus sign here, my two possible labels is
326.88|4.8| just for the sake of simplicity. And here I have two features, x
331.68|6.72| one and x two. And the goal is to predict for a new data point,
338.4|3.56| whether it's a plus or minus. So if I have, for example, new
341.96|3.88| data point that is located here, because it's on the left side of
345.84|3.12| the decision boundary. So this is a linear decision boundary
349.24|4.0| learned by this machine learning system, it would predict a minus
353.24|3.16| sign and everything on the right hand side would be predicted as
356.4|4.84| a plus sign, for example. So we will see more examples of that.
361.4|3.2| But here, the goal is to learn a decision boundary. So that's,
364.64|2.36| that's the goal in classification. And here, this
367.0|3.36| is a linear decision boundary. But it can also be a complex
370.36|2.96| decision boundary, it could be like something like this. And
373.4|3.28| deep learning, or deep neural networks are actually learning
376.68|3.6| very complex decision boundaries. Also, in practice,
380.64|3.32| when we have real world data, we rarely only have two features,
383.96|3.0| we usually have very high dimensional data. So we can't
387.0|3.48| easily visualize it. But yeah, that is, it's just like an
390.48|2.68| overview of a very simple case of classification, so that you
393.16|4.84| know that two different types of supervised learning, regression,
398.28|3.16| and classification. And yeah, to make things more interesting,
401.44|4.16| there's actually a third type, which is also known as ordinary
405.6|3.08| regression, or ordinary classification. That is what I
408.68|3.08| have worked a little bit on recently, when I talked about
411.76|5.44| this coral, consistent rank logits system, we developed for
417.2|4.8| deep learning. So ordinary regression is very similar to
422.0|4.2| classification, but there's a rank order. So we have ranks
426.2|3.16| that we want to predict, think of it as, for example, as movie
429.36|3.16| ratings, like grade is better than good, which is better than
432.52|3.48| okay, which is better for than genre fans, which is better than
436.04|4.2| bad. So there's a ranking. So these are classes, you can
440.24|4.6| actually use a classifier to classify, let's say, a written
444.84|4.84| text, or a movie into these classes, whether it's great,
449.68|3.28| great, good, okay, movie. But here, you have additional
452.96|3.0| information, you have like the ordering information among among
455.96|2.9| these labels. So there's a little bit more information
458.86|3.86| about that. So it's also called ordinary classification, or
462.72|5.52| ordinary regression. So, yeah, and here's another example,
468.24|4.52| like, what actually two types of sub problems, one is ranking,
472.76|4.24| and one is ordinary regression. So ranking is closely related to
477.0|2.68| ordinary regression, but it's a little bit different. Because
479.68|4.4| here, it's more about predicting the correct order, we don't
484.08|5.2| really care so much about the correct label. Because, yeah,
489.32|4.72| this is just my personal ranking. So from, yeah, I would
494.04|3.88| say favorite to least favorite, because you probably never heard
497.92|3.56| of these movies. I don't know. Let me take a simple example
501.48|4.0| here. So these are cups in different sizes. And if you
505.48|2.04| don't know the size of the cup, if you only have a word to
507.52|3.48| describe it like small, medium, large, I forgot they have
511.0|2.8| specific names, even like bendy and grandi or something like
513.8|3.24| that. But let's say you have these cups, you don't know the
517.04|4.08| exact sizes, this would be like ordering problem where you want
521.12|3.92| to order them from small to large, or an order regression
525.04|3.76| problem, you go a little bit beyond just ranking, you also
528.8|4.38| want to predict the correct label. For example, when we
533.18|3.96| worked on the coral network, we used an age data set as an
537.14|4.74| example, because we had large face image data sets available.
542.36|2.92| And deep learning, or we used conversion networks are
545.28|2.42| particularly good for image data. So it was a good example
547.7|3.64| for demonstrating this auto regression network. So here, the
551.34|4.04| task was predicting the age. So the age also has ordering
555.38|4.08| information. You might wonder, why don't you use regular
559.46|2.88| regression for that, you can think of it also as a non
562.34|3.66| stationary problem, or it just like the difference, let's say
566.0|4.36| between a six and a 10 year old person is much bigger, let's
570.36|4.28| say, between six, and 10 years, it's only four years, the
574.64|3.64| difference might be much bigger than the difference of a person,
578.28|6.24| let's say between, let's say 70 and 74. It's also only four
584.52|2.88| years here, maybe the differences are mostly defined
587.4|3.72| by how the skin looks like, like wrinkles and things like that.
591.12|3.14| But it's only maybe a slight difference between 70 and 74.
594.44|4.96| Here between the age six and 10 person might grow a lot like
600.08|3.44| child might be much larger, for example, or the features of the
603.52|5.24| face face change more and things like that. So comparing these
608.76|3.96| four units to these four units is kind of unfair. And in that
612.72|4.86| way, metric regression treats all the values at the same, it
617.58|3.18| wouldn't be really a good idea to use metric regression. I
620.76|2.8| mean, you can, but I think ordinary regression would be a
623.56|3.44| more natural choice here where you don't have defined
627.12|3.08| differences that are not on a metric scale, for example. But
630.2|3.28| yeah, also, in this class, we won't talk about ordinary
633.48|4.4| regression, really, we will be mostly focused on classification
637.88|3.46| for supervised learning. So I just wanted to cover this for
641.34|2.18| the sake of completeness, because there are three
643.52|3.96| categories really like classification, regression, and
647.48|2.44| ordinary regression and supervised learning. So in the
649.92|2.72| next video, I will then talk more about unsupervised
652.64|27.56| learning and also briefly about reinforcement learning.