start_time|end_time|text
0.56|2.86| Alright, so we are now slowly getting to our code
3.42|4.14| implementation of the character RNN in pytorch. And like I
7.56|2.96| mentioned at the end of the previous video, we will split
10.52|3.76| this into two parts. So this video will be on some
14.28|5.16| conceptual aspects about the implementation, some, I would
19.44|2.76| say things that help us understanding the implementation.
22.2|3.92| And then the next video will be the actual code example. So
26.12|2.8| there's one thing I wanted to talk about, that's the LSTM
28.92|4.4| class. We have used that before when we implemented the RNN for
33.32|3.2| classification. But yeah, there was a question also on Piazza,
36.52|3.36| and I made this ugly drawing, trying to better explain the
39.88|2.96| inputs and outputs. And I realized this is like one of the
42.84|3.64| really obscure things in pytorch. It's not so obvious
46.48|2.36| what's going on there. Because yeah, there are lots of inputs
48.84|3.8| and outputs to the LSTM. And I wanted to explain this again for
52.64|5.12| everyone. And spoiler, there's also an LSTM cell class that I
57.76|2.68| also wanted to explain, especially the difference
60.44|5.36| between the LSTM cell and the LSTM class in pytorch. But yeah,
65.8|4.28| one thing at a time. So we used this LSTM class before when we
70.08|3.28| implemented the RNN for classification. And yeah, there
73.36|4.36| are lots of things going on with that one. So here, just looking
77.72|3.86| at the example, they initialize the LSTM. So there are three
81.58|3.54| values. If we look up the values here in the usage, it's the
85.12|3.52| input size, the number of expected features, essentially
88.68|4.08| the hidden size, and the number of layers. So usually, well,
92.8|3.8| not usually, but previously, we used only one hidden layer. But
96.6|2.48| we can also, of course, use multiple hidden layers, I will
99.08|4.04| have a visualization showing you how that looks like in the next
103.12|3.52| slide. But you're focusing on that. So we have, let's say,
106.64|5.0| initialized our LSTM. And then here, it's getting used and it
111.64|6.9| receives two inputs. So the input, and then the second input
118.54|5.78| is this tuple here consisting of h zero and c zero. So what are h
124.34|5.3| zero and c zero, these are our initial hidden state and cell
129.64|3.96| state here. So here, they use random numbers for everything.
133.6|6.36| But usually, we initialize the initial states with zeros. But
139.96|2.56| here, it doesn't really matter here, they just want to try or
142.84|4.32| just try illustrating how, how inputs might look like from the
147.16|4.72| dimension perspective. So what, what they essentially look like,
152.08|3.84| what dimensions we need, in any case, so there are these inputs.
156.2|5.12| And also as output, there's an output here, and also a tuple
161.88|6.04| with or called HN and CN here, where this is the hidden state
167.92|5.64| of the last time step, and the cell state after the last time
173.56|4.24| step. So I had this relatively ugly drawing and Piazza, I
177.8|3.24| actually searched on the internet a little bit to find a
181.04|3.36| better visualization. And I found the following here on stack
184.4|3.8| overflow, which illustrates this nicely what everything here
188.2|8.12| is. So the input here, which goes into the RNN can really
196.32|7.24| think of it as your data input. Whereas this whole, so maybe use
203.56|4.64| a different color, this whole thing should represent your LSTM
208.44|6.76| where here, this is the depth, the number of layers. So this
215.2|9.0| would be layer one, layer two, and layer three. So previously,
224.2|3.04| in the code examples, we only used one layer. But of course,
227.24|2.8| yeah, we can have multiple layers, it's just, you can see
230.04|4.6| that it's just one layer on top of each other. Right. So
234.64|4.32| previously, we only had in the actual code example, in the
238.96|2.96| lecture, we only had this, this one hidden layer. But we also
241.92|2.4| talked about that we can have an arbitrary number of hidden
244.32|3.7| layers, similar to how we can have an arbitrary number of
248.02|2.82| layers in a convolutional network or in multi layer
250.84|6.0| perceptron. Okay. So this is our input here at the bottom.
258.6|5.12| Right. And now h zero and C zero, we also use a different
263.72|6.32| color, maybe yellow. So these are here, our initial states
270.24|5.56| that go into the LSTM. So here, the two is for the number of
275.8|8.88| layers. Okay, and then the output from the RNN, this is
286.36|2.96| also for each time step. So there's one output for each
289.34|4.34| time step, similar to how there's one input for each
293.7|8.98| time step. In addition to that, it also returns here, the
302.68|6.78| hidden state and cell state for the last time step. So
309.46|3.22| technically, what we could do is we could have, let's say
312.68|7.92| another RNN call, say, some input sequence to together, so
320.6|7.16| like we had it here, together with now, get these H n and C
327.76|2.8| n, if we wanted to, for example, if we want to reuse that part,
330.56|6.44| for example. Alright, so, but this, this is conceptually what
337.0|7.2| we get out. So this, and this, these are our outputs. And this
344.2|9.48| is our input here. Now, the LSTM cell class is, it's kind of like
353.78|4.34| part of the LSTM, it's a smaller unit, like LSTM cell is, is
358.12|4.28| only a small unit. And we can actually use both on either the
362.4|3.8| LSTM or the LSTM cell for implementing the character RNN.
366.2|3.98| And I've used both. And I will also provide you with code
370.18|4.3| examples for both. But to be honest, I think using the LSTM
374.48|5.04| cell class is a little bit more natural. Because the way we
379.52|4.76| compute the labels, it's a little bit more easy to do that.
384.28|6.12| And also for generating data. So, the LSTM cell, how it works
390.4|4.44| is that it is just representing one small unit of what you have
394.84|4.96| seen before. So the LSTM cell is naturally only one layer, instead
399.8|4.28| of, of setting the number of layers, we would have to stack
404.08|4.76| them on top of each other. And using the figure that I showed
408.84|4.0| you before here in the red box, this is essentially what the
412.84|5.04| essentially what represents the LSTM cell. So it only receives
418.24|4.32| one character as the input, then for the one layer of the hidden,
423.6|3.76| the initial hidden and cell state, and it only outputs one
427.36|5.2| output here, and then the hidden and cell set for the next state.
432.82|4.86| So why that is more useful is in a way for computing the loss
437.68|5.04| essentially that you can get one thing at a time, essentially
442.72|6.2| instead of running the whole thing. And if we would use the
448.92|3.04| LSTM class, we would have to provide one character at a time
451.96|4.32| as input. And it's kind of wasteful doing that. So handling
456.28|3.0| wise, I find the LSTM cell a little bit more easy to use for
459.28|4.48| this purpose. But of course, you can use both you can. You can
463.76|3.24| also for the character on and for example, run this character
467.0|7.4| on in here with only one, one input here, multiple layers, you
474.4|2.4| can also run it like that by only having an input of one
476.8|3.92| input. But if you if we want to do this in the first place, we
480.72|5.18| can also just use the LSTM cell and use use that one. It's this
485.92|3.72| smaller unit here, essentially, if we was would only use one
489.64|5.36| layer, we would then use this output here, put it to a fully
495.0|3.28| connected layer to get the class label predictions, and then
498.28|3.72| compute the loss and then go on to the next character and so
502.0|4.28| forth. And here we are going to do that in the code example in
506.28|4.08| the next video. So one more thing, we are talking here
510.36|7.26| about the many to many where we have all we want to create text,
517.64|5.76| so predicting the next word. If you are interested in another
523.4|3.04| type of many to many architecture, for instance,
526.44|2.28| language translation, I found they have actually a great
528.96|3.32| tutorial on the pytorch website. So we are not going to talk
532.28|3.6| about language to language translation. Because yeah, there
535.88|3.4| is already a great tutorial. And it would be kind of boring for
539.28|3.44| me just to reproduce this tutorial. So maybe if you're
542.72|3.04| interested, you can just check it out and work through it step
545.76|4.64| by step. So the next video we will oops, in the next video,
550.4|4.92| we will focus on the character level RNN generating new text,
555.32|27.24| and we will be using this LSTM cell class.