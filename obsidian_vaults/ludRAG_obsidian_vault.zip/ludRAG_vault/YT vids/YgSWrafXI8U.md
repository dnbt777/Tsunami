start_time|end_time|text
0.28|4.28| Yeah, so in this video, let me try to motivate why it might be
4.6|2.96| better to use a variational auto encoder instead of a regular
7.56|3.04| auto encoder. And that is because in the variational
10.6|4.6| auto encoder, because we force the latent space distribution to
15.2|2.48| be a standard normal distribution, it will be easier
17.68|3.2| to sample from that. So it will be better for generating new
20.88|3.64| data using a variational auto encoder compared to a regular
24.52|2.68| auto encoder. So let me introduce the problem step by
27.2|6.28| step. So here is an overview of using a regular auto encoder for
33.48|2.72| sampling. So the regular auto encoder that we encountered in
36.2|3.6| the previous lecture. So what we did in the previous lecture was
40.04|6.18| we took the MNIST data set, and then use the encoder to encode
46.22|5.26| it into this two dimensional latent space. Why did we use two
51.48|3.64| dimensional latent space? Well, that was really arbitrary for my
55.12|3.98| side here, I just wanted to have a two dimensional so that I can
59.1|3.5| visualize it in a scatterplot so that you get a feeling of how it
62.6|5.24| looks like. But of course, the dimensionality is relatively
67.88|4.54| arbitrary, I could have used a 3d 4050 100 dimensional latent
72.42|4.26| space representation. But yeah, of course, then I wouldn't be
76.68|4.96| able to make a 2d scatterplot. And as a rule of thumb, the
81.64|3.76| larger your latent space is, usually you pick still something
85.4|3.28| that is smaller than the input size. But the larger your latent
88.68|6.1| space is, the easier it will be for the auto encoder to get
94.78|3.1| encode the information in the latent space and produce good
97.92|3.8| reconstructions simply because you have already retained more
101.72|2.2| information or you have the ability to retain more
103.92|6.8| information in this latent space. So at the end of the
110.72|3.04| previous lecture in one of the code examples, what I also did
113.76|3.52| is, when we had this latent space, I was just looking at it
117.28|3.12| and picking an arbitrary point, I think I picked something like
121.04|9.12| say, minus 2.5 here. And what's this to so I picked a point. And
130.16|4.12| then I put this through the decoder. And what came out was
134.28|6.4| a handwritten digit. So one aspect about this two
140.68|3.72| dimensional space here in this auto encoder example is that it
144.4|4.44| looks pretty crowded and kind of continuous in this region here.
149.48|2.92| But this is really because we picked a two dimensional space.
152.64|3.8| If you have a very large dimensional space, maybe even
156.44|5.68| like 10 to 100. These points would be already very far apart
162.12|4.0| from each other. And this wouldn't be a continuous space at
166.12|4.24| all. So if you would just pick an arbitrary point in the higher
170.36|4.0| dimensional space, it would be not really guaranteed that it
175.16|3.96| produces a valid image that looks anything like the input
179.12|7.64| data, if you put it through the decoder. So just to highlight
186.78|4.38| the issues with sampling from a regular auto encoder. So it's
191.16|3.56| actually a challenge because your regular auto encoders are
194.72|3.84| difficult to sample from. The reason is that the distribution
198.6|4.48| might be oddly shaped. So here, actually, it looks, to be
203.08|3.68| honest, nicer than I expected. But there's no guarantee that it
207.16|2.72| is anything like that, like organized like that, if you
210.12|6.36| consider different data sets, or you may encounter that these are
216.48|3.88| really weirdly shaped distributions, and weirdly
220.36|3.0| shaped distributions make it really hard to sample from in a
223.36|5.2| balanced way. Right? So if you have Gaussian distribution, you
228.56|2.52| know how to sample from the Gaussian distribution. But if
231.08|2.56| you have some arbitrary distribution here like that, you
233.64|2.8| don't even know what this distribution is, right? I mean,
236.68|3.28| how do you sample from that in a balanced way, it's kind of
239.96|3.68| challenging. Also, the fact that the distribution is not centered
243.64|3.92| at 00 makes it also additionally harder. So here, this
247.56|3.96| distribution is just at some arbitrary location in some
251.84|3.32| arbitrary fashion distributed. So it's really hard to sample
255.16|4.64| from that in a way that we can generate your valid data points.
259.96|4.94| I mean, the regular auto encoder is still good for compressing
264.9|3.62| data. But if you want to generate new data, data that
268.52|4.24| looks similar to the training data, but is new, that is
272.76|3.48| usually not so good with a regular auto encoder. And yeah,
276.24|3.48| the distribution is not necessarily continuous. And this
279.72|2.28| is kind of hard to see here, because it's only two
282.0|3.96| dimensional. But if we would imagine a higher dimensional
285.96|2.76| space, everything would be pretty far apart from each other.
289.04|6.32| And the distribution wouldn't be not continuous. Let's now
295.36|4.48| consider the variational auto encoder. So we still have the
299.84|4.44| same MNIST dataset. But now when we are training this variational
304.28|5.04| auto encoder, the latent space will follow a standard
309.36|3.32| multivariate Gaussian distribution. So here, just for
312.68|4.16| example, I have only two dimensions. But of course, like
316.84|2.8| for regular auto encoder, the number of dimensions is
319.64|5.04| arbitrary. So here, this is just a density function of the
324.68|4.0| multivariate Gaussian. So also here for reference, but I bet
328.68|3.88| you have already seen that before. And yeah, we now have in
332.56|2.96| this particular case, two dimensions. So according to
335.52|3.92| that, the parameters are the mean vector and the covariance
339.44|4.68| matrix here. So the mean vector with a mean for each dimension,
344.48|5.2| and the covariance matrix with the variance for each
349.68|6.48| dimension, the variances. And then here, the covariances.
356.16|8.96| However, we assume that the latent space at the covariance
365.44|3.44| matrix here is a diagonal matrix. So that it is, in
368.88|2.36| particular case, an identity matrix. So there's no
371.24|6.56| interaction between the features or in simpler terms, the
377.84|4.48| covariance matrix is an identity matrix like this, where we have
382.32|4.56| zero covariances and unit variance for each dimension. So
387.12|4.32| the variance for each dimension is one, just a standard
391.48|5.8| multivariate Gaussian distribution. Then, once we
397.32|4.08| notice distribution, and we can sample from this, so we can draw
401.4|4.88| samples. And because this is continuous distribution, we can
406.28|4.92| expect that the decoder produces something reasonable when we
411.2|3.2| sample from this distribution. So there are no gaps in this
414.4|4.2| distribution. It's a continuous distribution. How do we sample
418.6|5.64| from this? So here's how we draw a new sample z. So we have
425.72|6.36| standard deviation, times epsilon plus the mean here. So
432.08|3.72| actually, we don't need to use the whole covariance for that
435.88|4.72| the covariance matrix, I mean, because the off diagonals are
440.6|5.48| zero, like I showed you before. So we only need to store a
446.08|3.12| vector for the variance, just to keep it simple. So this is the
449.2|5.44| variance vector. And these epsilons here, they are drawn
454.64|8.52| from a normal distribution. So this is the way we sample. How,
463.2|3.68| why do we do that? I will go into this in more detail in the
466.88|3.16| next video has something to do with the fact that we are still
470.04|3.68| we are still trying to train a neural network using back
473.72|4.62| propagation. And how do we back propagate through our probability
478.34|4.18| distribution. So just give you maybe the short version now. Why
482.52|3.68| not? Because what we do on simply what we do is we store
486.52|4.52| this mean vector. And this, let's say, variance vector,
491.04|2.76| there's a little trick to that I will explain that in the next
493.8|5.12| video. But we we store, sorry, we store these two vectors here.
498.92|6.36| And using those, so we can use back propagation to parameterize
505.28|5.88| these vectors. And then we use epsilon here, during the forward
511.16|5.08| pass to sample. It sounds maybe a little bit weird and abstract
516.28|3.4| right now, but it will become more clear. Once I show you also
519.68|4.2| the first code example, it will not be too far into the future.
524.28|3.4| Only finishing up this video, there will be a short next
527.68|2.4| video. And I will show you the code example. And then I think
530.28|5.44| this will become clear. So let me briefly talk about this
535.96|3.48| lock bar trick, which will be kind of important for
539.44|4.24| implementing the sampling procedure. And then in the next
543.68|2.48| video after that, oh, there's one more on the loss function.
546.16|2.74| But then I will actually show you how this works in pytorch.
548.9|4.64| And I think when you see the whole code, I bet it will make
553.54|4.82| more sense why, why we want to store this mean vector and this
558.36|3.84| variance vector, and also why we will use this lock bar trick.
562.48|2.76| Alright, so stay tuned for the next video on the lock bar
565.24|20.52| trick.