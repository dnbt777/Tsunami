start_time|end_time|text
5.12|3.04|um so today i'm going to be talking
6.56|3.76|about um some recent work that we've
8.16|3.76|been doing at deepmind i'm developing uh
10.32|3.68|this line of architectures that we're uh
11.92|4.16|we're calling perceivers um and i'll be
14.0|3.6|motivate motivating this and in terms of
16.08|3.68|a goal that we have which is to develop
17.6|4.24|a general purpose architectures
19.76|4.0|um and so just right off the bat um
21.84|3.84|i want to motivate why we care about
23.76|3.92|general purpose architectures um and so
25.68|4.24|the first the first uh
27.68|4.399|both of the reasons are fairly pragmatic
29.92|4.159|but basically the idea is if we're
32.079|3.681|thinking about all of the data that we
34.079|4.081|could possibly imagine collecting in the
35.76|3.92|world um a lot of it um
38.16|3.12|is basically involves what we think of
39.68|3.199|as sort of traditional sense modalities
41.28|2.799|whether
42.879|4.0|these things range from touch and
44.079|4.721|proprioception to echolocation to uh the
46.879|3.68|kind of perception you need to to ingest
48.8|3.84|texts uh how however you want to format
50.559|4.241|that to things uh just to more exotic
52.64|3.919|things like event based cameras
54.8|3.279|um whisker touching touching with
56.559|4.561|whisker sensors things like smell and
58.079|5.28|depth um and all the way up to um the
61.12|3.52|kinds of sense modalities that we really
63.359|2.8|um think about when we're thinking about
64.64|4.08|scientific perception
66.159|4.561|um and so basically um as if we think
68.72|3.52|about the full set of data and what it
70.72|3.36|would take to actually model each of
72.24|3.6|these different modalities
74.08|3.359|it basically looks
75.84|3.36|effectively intractable to try to
77.439|3.68|engineer inductive biases that will work
79.2|4.8|for every single one of these so we
81.119|4.481|don't want to engineer them one by one
84.0|3.04|this is an approach that's worked and in
85.6|3.12|some ways it's maybe a reasonable
87.04|3.2|description of of how we think about
88.72|3.359|developing new architectures for
90.24|3.6|different uh different problems but it's
92.079|4.241|just not going to scale we we can't
93.84|4.08|afford as a community to design to hand
96.32|3.04|design inductive biases that will work
97.92|2.72|for each and every one of these and so
99.36|3.119|rather than doing that we want to sort
100.64|3.119|of build architectures that at least at
102.479|3.28|first pass will allow us to handle
103.759|3.521|everything
105.759|3.601|there's another practical argument for
107.28|3.92|why we should work on general purpose
109.36|3.84|architectures and that's because it will
111.2|3.919|allow us to build simpler more unified
113.2|4.0|systems um
115.119|5.28|so if you look at how in particular
117.2|5.519|complex multimodal data streams are are
120.399|4.801|typically um approached in uh in the
122.719|4.161|sort of the the sensory uh computer
125.2|4.24|vision or pattern recognition
126.88|4.159|literatures effectively the typical way
129.44|3.439|this is done is by using inductive
131.039|4.241|biases that we know hold for the
132.879|4.161|individual modalities and then engineer
135.28|3.36|ways to of combining those different
137.04|3.12|subsystems and so this could this can
138.64|4.16|mean building
140.16|4.159|specific specific heads specific input
142.8|2.72|modules for each of these things and
144.319|2.881|then trying out the various different
145.52|3.68|ways of combining them
147.2|3.6|and so this can work but it in this it
149.2|3.52|gives us systems that in principle
150.8|3.76|really will only work on one or a small
152.72|3.519|number of domains and it gives us
154.56|3.759|systems that are very hard to maintain
156.239|3.601|tend to be fragile uh tend to depend on
158.319|3.121|specific processing assumptions about
159.84|3.679|the input modalities
161.44|3.92|so rather than do that we sort of want
163.519|3.921|to move in the direction of having
165.36|3.44|unified black box architectures that
167.44|2.96|kind of just work
168.8|3.519|and the idea here is that if we can get
170.4|4.08|to that point we can abstract the
172.319|3.92|architecture construction process and
174.48|4.0|really focus on other more high-level
176.239|4.881|problems so this is sort of the the
178.48|3.759|motivation for this line of work
181.12|3.039|and the way that we're gonna that we're
182.239|3.36|gonna be doing this is of course by
184.159|3.041|working uh
185.599|3.761|on the most general purpose architecture
187.2|3.759|that we have so far which is basically a
189.36|3.36|transformer and you'll all be very
190.959|3.28|familiar with the basic building blocks
192.72|3.36|of a transformer
194.239|3.841|but just at a very high level we can
196.08|3.6|think about what they do right which is
198.08|2.799|they use a general purpose inductive
199.68|2.8|bias
200.879|3.28|so they're non-local which means they're
202.48|3.44|not making domain-specific assumptions
204.159|3.281|about which point should be compared to
205.92|3.36|each other rather they're they tend to
207.44|4.24|be global in terms of the attentional
209.28|4.0|focus that they have
211.68|2.96|they use position
213.28|3.039|as a feature rather than a hard
214.64|4.56|constraint of the architecture and this
216.319|5.2|is in contrast to um to sort of mlp
219.2|4.399|based architectures or or confnets in
221.519|4.561|the way that they typically work which
223.599|4.321|which use position as an architectural
226.08|3.519|component to constrain how compu calc
227.92|3.12|compute is happening
229.599|2.72|um and then of course they're they're
231.04|2.88|finally there's extensive there's
232.319|3.2|extensive weight sharing um in the way
233.92|3.92|that there's where that that they're
235.519|3.841|designed and because they focus on map
237.84|2.8|models they tend to be tpu and gpu
239.36|4.239|friendly so these are all very nice
240.64|4.239|things about the way transformers work
243.599|3.761|of course on the other hand they have
244.879|4.401|very poor compute memory scaling um and
247.36|4.079|there are two components to this so
249.28|3.519|attention itself scales quadratically so
251.439|3.921|there's this um
252.799|3.28|there's this big o of m squared l
255.36|1.999|um
256.079|3.521|uh complexity at the heart of
257.359|3.681|transformers and um i i like writing it
259.6|3.52|this way because it really emphasizes
261.04|3.92|that this is a property of um that
263.12|3.76|basically as you make your models bigger
264.96|3.6|either at the input size or as you make
266.88|3.12|them deeper you're just this problem is
268.56|2.24|just going to get worse
270.0|3.04|um
270.8|3.6|and because you have this uh this this
273.04|2.8|scaling and depth as well there's
274.4|4.0|another sort of practical thing that
275.84|3.68|happens here because we're um the the
278.4|2.72|the amount of compute that we're doing
279.52|3.36|is proportional to the input size so
281.12|4.0|there's no bottleneck in the way that
282.88|4.319|standard standard transformers work um
285.12|4.799|even the the linear scaling becomes a
287.199|5.121|problem um and so in practice um for for
289.919|3.761|very very large um transformers this can
292.32|3.04|often be the bottleneck that really
293.68|3.2|matters but they're both at play here
295.36|3.76|and so we really want to sort of tamp
296.88|3.759|down both of these um and so the the
299.12|2.639|sort of the perspective here is that to
300.639|2.721|have really general purpose
301.759|3.121|architectures we can't have ones that
303.36|2.96|are just sort of in principle general we
304.88|3.759|have ones that we have to have ones that
306.32|5.76|you can actually use um on the scales
308.639|3.441|and the kinds of data that we care about
312.72|3.919|um and so just to um
314.88|3.84|this will all be old hat for all of you
316.639|4.481|but just so the way that standard qkv
318.72|3.6|attention works is basically like this
321.12|3.28|so it's it's all about matrix
322.32|4.319|multiplication so we have some input we
324.4|4.239|compute the um the query keys and values
326.639|4.4|by having a 1d convolution a one by one
328.639|4.721|convolution that we run over the input
331.039|4.321|we then compute the attention uh the
333.36|3.839|attention scores this is a matrix
335.36|4.0|multiply that has the following
337.199|5.121|these sorts of shapes we then use the
339.36|5.2|output here to compute
342.32|4.319|the weights um to to compute the actual
344.56|3.52|output of the attention module itself
346.639|3.201|and then finally we want run this
348.08|3.44|through an additional mlp which is
349.84|3.12|applied convolutionally to get the
351.52|3.44|outputs
352.96|4.799|so this is this is the starting point of
354.96|4.72|what we're working on here
357.759|4.16|and let me just briefly um just
359.68|3.6|reiterate why we would want the sort of
361.919|4.0|advantages that we have with these sort
363.28|4.639|of standard transformers so non-locality
365.919|4.0|is one of the two sort of inductive bias
367.919|4.0|principles that we have here it's useful
369.919|3.921|i think to contrast this to way that to
371.919|4.081|the effective locality that you get in
373.84|4.799|confidence and what this actually means
376.0|4.72|so if we look at basically
378.639|3.68|as a function of depth which inputs can
380.72|3.44|see which other ones which means like
382.319|4.241|how how easily it is to express a
384.16|3.92|function of two input points um let's
386.56|3.759|say we we look at these this yellow and
388.08|3.6|purple point here at the input now
390.319|4.401|i've set them sort of as far apart as
391.68|4.88|possible but um we might ask what um how
394.72|3.599|deep would the effective computation
396.56|3.44|have to be before you actually process
398.319|3.841|these two and if you look at a three by
400.0|3.759|three convolution
402.16|2.879|you're talking um
403.759|3.361|you're having to look basically until
405.039|3.921|the very end of the of the network until
407.12|3.04|you're processing processing these
408.96|3.359|things together
410.16|4.8|and what this means is that um the
412.319|4.081|functions that that you can express that
414.96|3.04|actually look at both of these points
416.4|3.28|into being quite shallow because they
418.0|3.12|have to be built on top of this very
419.68|4.639|very deep stack that just gives you the
421.12|4.24|locality um and so in point of fact um
424.319|2.961|if you look at
425.36|3.76|for example the way resnets work so you
427.28|3.28|have an initial block which has a 7x7
429.12|3.28|convolution and then afterwards it's
430.56|4.479|three by three columns all the way up
432.4|5.44|you need 28 3x3 cons with that standard
435.039|4.88|processing stack before all of the 224
437.84|3.12|by 224 pixels in an image are looking at
439.919|2.481|each other
440.96|3.84|and what this means is that in a
442.4|4.079|resonant 50 um the points on the very
444.8|4.16|edge of the pixels actually never see
446.479|3.601|each other and this is um this is
448.96|2.959|it's a little bit i found this a little
450.08|3.76|bit counter-intuitive but it suggests
451.919|3.201|that we really are constraining quite a
453.84|2.96|lot the functions that are easy to
455.12|3.04|express with these models and so there
456.8|3.679|are some functions of images you just
458.16|4.319|can't you can't capture with a resonant
460.479|3.761|50.
462.479|3.44|on the other hand if you look at an
464.24|3.84|architecture that has global attention
465.919|3.68|over the full um over the full input so
468.08|3.76|a transformer if you could scale it that
469.599|4.561|way um or in a perceiver as we're going
471.84|4.639|to be talking about um all of the pixels
474.16|4.08|can interact so the model can basically
476.479|3.761|capture these things and express these
478.24|4.079|functions much more easily than can be
480.24|4.32|expressed in things that put locality
482.319|2.241|first
484.879|4.081|um we also um the other sort of
487.039|3.44|interesting property of these sorts of
488.96|4.079|architectures is that position is
490.479|4.881|featurized um and this basically means
493.039|4.16|that we're no longer sort of encoding
495.36|3.76|the architectural location of something
497.199|4.481|to to figure out um where it's located
499.12|4.16|with with respect to the other ones and
501.68|4.88|um this allows the network to basically
503.28|5.28|use um any uh any positional information
506.56|3.44|that it wants but can also discard it as
508.56|3.039|it as it prefers
510.0|3.68|um and so this is the standard way it's
511.599|3.92|done of course in the in the context of
513.68|3.839|architectures that use fourier or
515.519|4.721|sinusoidal like features um but there's
517.519|4.561|a lot of flexibility here
520.24|3.919|okay so now just thinking in terms of
522.08|4.24|how confidence um relate to transformers
524.159|3.68|sort of at the opposite end um it may
526.32|3.76|look like that we have a sort of
527.839|3.761|scalability versus general generality
530.08|3.52|trade-off
531.6|3.679|and so if we look at confidence
533.6|3.6|the way that they're applied
535.279|4.081|so typically we can think about using
537.2|2.96|them on grid structured data
539.36|2.4|they're they're of course
540.16|2.96|generalizations of convolutions that
541.76|2.72|work on
543.12|3.52|on data sets with more interesting
544.48|3.84|topology but typically we can think of
546.64|3.6|them as operating on grids of some in
548.32|3.92|some in some sort of space
550.24|4.24|um whereas transformers apply to generic
552.24|3.599|sets so uh transformers are more general
554.48|3.039|from this point of view
555.839|4.161|on the other hand they're um they scale
557.519|4.88|much much worse so confidence are linear
560.0|4.24|both in the uh the input points the
562.399|3.761|filter size and the number of layers of
564.24|4.159|that architecture whereas transformers
566.16|3.6|have this quadratic scaling um and
568.399|2.641|they're still linear and then in the
569.76|3.04|depth
571.04|3.359|so from this point of view um what we're
572.8|3.52|interested in doing in this in the
574.399|4.081|perceiver line of work was to scale
576.32|3.76|transformers but to keep the generality
578.48|4.08|properties so we want something that
580.08|5.12|lives in between these two extremes
582.56|5.04|uh and the way that we do this is by um
585.2|4.8|by looking at at self-attention and sort
587.6|5.2|of modifying it in a way that allows us
590.0|4.8|to scale better so to walk through what
592.8|3.68|self-attention actually does in sort of
594.8|3.92|standard transformers
596.48|4.08|we take our input array which here is
598.72|3.359|written as the number as the indices
600.56|3.839|which is the number of tokens or the
602.079|3.44|number of pixels um basically the number
604.399|2.481|of input units depending on what you're
605.519|4.081|looking at and the number of and the
606.88|4.16|channels um we have a 1d convolution so
609.6|4.0|this is big o of m
611.04|4.479|with respect to the q k and v
613.6|3.84|we then compute the attention maps using
615.519|4.081|the output of this operation this gives
617.44|4.24|us a matrix multiply which is the source
619.6|3.679|of the quadratic scaling
621.68|5.44|and then finally we compute output
623.279|5.12|features with another matrix multiply
627.12|3.44|this is
628.399|4.161|already we're already rate limited here
630.56|3.76|because um for even standard resolution
632.56|2.88|images m is quite large so it's around
634.32|2.4|50 000
635.44|3.36|for standard image net images which
636.72|3.44|again are very small so this is uh this
638.8|4.08|is something that just isn't going to
640.16|5.28|work if we want deep architectures
642.88|4.399|so what we do is we replace um at the
645.44|3.28|input to the architecture we replace the
647.279|4.24|self-attention with a cross-attention
648.72|5.28|layer and we do this using
651.519|5.121|basically a learned query and so we're
654.0|5.04|replacing only the query from the the
656.64|3.84|input here with a learned component and
659.04|2.88|so these indices and channels you can
660.48|3.68|just think of these as basically working
661.92|4.56|like um the learned initial state for an
664.16|4.16|rnn there's a variety of names that this
666.48|3.76|this opera this idea goes under in the
668.32|4.8|literature um we refer to them as sort
670.24|4.56|of as um as late as latents um but
673.12|3.839|they're sometimes called inducing
674.8|4.08|inducing points or other things
676.959|3.201|um so the basic idea is we're learning
678.88|3.519|the input to the query and keeping the
680.16|4.08|key value input the same
682.399|3.601|the downside are the the sort of upside
684.24|3.68|of this is that um
686.0|3.92|when we compute the attention map after
687.92|4.56|this now we um we basically turn this
689.92|4.24|from a square matrix to um to a
692.48|3.599|rectangular matrix
694.16|4.0|and um reduces the complexity of the
696.079|4.241|matrix multiplied to big o of mn so now
698.16|4.32|it's linear in the input size
700.32|4.079|and the second the second matrix
702.48|4.479|multiply has the exact same property so
704.399|4.801|it becomes from quadratic becomes linear
706.959|4.241|um and the the quite cool thing about
709.2|4.319|this is that okay so the cross attention
711.2|4.0|is linear in complexity but the output
713.519|3.12|is actually smaller and so this i think
715.2|3.28|is actually the more important point
716.639|3.361|here is that this allows us to map
718.48|2.96|something which is quite large into
720.0|3.44|something that has size that's
721.44|3.36|independent of the input we so we have
723.44|3.519|full control over this it's a hyper
724.8|4.24|parameter and this allows us to build
726.959|4.161|deep networks on top of this arc on top
729.04|3.68|of this latent so because this is of a
731.12|3.36|small size that we can control we can
732.72|2.88|afford to have quadratic complexity on
734.48|4.0|top of this
735.6|4.64|and so we use this idea um yep
738.48|4.32|sorry i'm still a little bit confused as
740.24|4.8|to on how you guys are able to
742.8|4.4|turn this square into a rectangle in the
745.04|4.4|second step is it because you replaced
747.2|4.079|the query with the learned something
749.44|4.32|that is significantly smaller compared
751.279|4.401|to the input size in the first step
753.76|4.48|yeah that's exactly right so if you look
755.68|4.32|at the um so the the um the underlying
758.24|4.159|matrix multiplication multiply here
760.0|4.56|which is written as the qk transpose
762.399|3.921|so the um this will basically so the
764.56|4.0|outer dimension here is has this has
766.32|3.92|shape n which is determined by the query
768.56|3.12|and so by shrinking that query we're
770.24|3.279|just changing the output of the matrix
771.68|4.719|multiply
773.519|2.88|okay thank you
776.8|4.159|yeah so i guess
778.16|4.64|sorry go ahead please okay cool um so
780.959|4.0|basically you only do that for the query
782.8|5.599|right so key and value remain like the
784.959|6.241|original um size matrices correct
788.399|5.44|that's right yeah okay um but
791.2|3.92|so basically so
793.839|2.721|i um
795.12|4.08|i don't know what i'm not understanding
796.56|3.839|basically so the problem for me is that
799.2|3.84|for the query
800.399|4.961|now in my head i'm like looking for
803.04|5.52|let's say i have like the if token now
805.36|5.919|there is no i query anymore
808.56|4.8|doesn't that pause cause a problem
811.279|4.641|like when i'm trying to use it
813.36|4.32|and like to compute scores
815.92|3.44|yeah so um so what's happening here is
817.68|3.2|um uh you're comparing you'll have a
819.36|3.12|smaller subset of query so if you think
820.88|3.36|about this in not in terms of the matrix
822.48|3.84|multiplies but in terms of comparing
824.24|4.64|each query to each key
826.32|4.16|so in normal self-attention we have one
828.88|3.44|query for each key so every point
830.48|3.12|compares to every other point right so
832.32|2.72|here what we've done is instead of
833.6|3.76|comparing every point to every other
835.04|3.68|point we have a set of sort of cluster
837.36|3.76|centers you might be able to think about
838.72|4.16|them as so it's a smaller number and we
841.12|3.2|compare each of those to each of the
842.88|3.759|input points
844.32|4.639|but we don't know which
846.639|4.161|which tokens technically belong to which
848.959|4.801|clusters right
850.8|4.24|that's right so it has to be learned
853.76|3.6|yeah exactly
855.04|4.239|um so one way to think about this um
857.36|4.8|about what's happening here is that
859.279|4.961|we're we're um we're um instead of so in
862.16|4.239|a normal self-esteem self-attention
864.24|3.92|transformer by comparing all to all to
866.399|3.201|all we're sort of saying okay i know
868.16|4.479|what the feature is at this point and i
869.6|5.039|want it to attend to similar features um
872.639|4.801|here what we're saying is we're learning
874.639|4.801|a bunch of supplementary um points that
877.44|5.6|we that that should be sort of maximally
879.44|5.199|similar to some subset of the inputs
883.04|2.72|uh so correct me if i'm wrong but this
884.639|3.121|is essentially doing some sort of heart
885.76|3.759|attention where you're saying like uh
887.76|3.36|like instead of like declaring over all
889.519|3.68|the points it's like like some points
891.12|4.64|which we think are like very similar and
893.199|4.161|only like puts out attention
895.76|3.199|uh hardened like this points you're
897.36|4.24|selecting right
898.959|4.0|yeah so they're related um the um that
901.6|3.039|would be one way to think about it the
902.959|4.0|um the the sort of the slight uh
904.639|4.56|modifier to that idea though is that um
906.959|3.68|they basically live in an abstract space
909.199|3.361|so they're not they're not assigned sort
910.639|4.64|of one to one to one of the input
912.56|4.079|queries or to one of the input points
915.279|2.721|they're sort of learned so they can be
916.639|2.401|somewhere in the middle but i think
918.0|3.279|that's a that's a good way to think
919.04|3.039|about it that's a good intuition
921.279|2.24|but
922.079|3.12|i guess one of the places where i'm a
923.519|4.481|little confused here is the
925.199|4.241|you have here indices and indices for
928.0|3.12|the two like the purple and green
929.44|3.28|matrices in the far left
931.12|4.079|but those indices are not necessarily
932.72|3.919|corresponding to inputs like in the nlp
935.199|3.281|space those would not necessarily be
936.639|4.081|tokens right these are just sort of
938.48|4.96|exact variances but the structure matrix
940.72|5.52|in this case is the result of some kind
943.44|4.639|of mapping from the input tokens to an n
946.24|3.68|by d matrix is that right
948.079|3.841|no it's actually so there it basically
949.92|3.68|acts like it's a learned set of weights
951.92|3.12|is one way to think about it so they
953.6|3.039|function exactly the same way that
955.04|3.039|learned position encodings do so it's
956.639|3.681|basically just a you know it's a learned
958.079|3.841|embedding um but it's not it's not
960.32|2.48|conditioned on anything it's just sort
961.92|2.719|of
962.8|4.56|it just it just uh is
964.639|6.241|it's what it's just a set of weights
967.36|3.52|that that makes more sense thank you
973.759|2.721|uh okay so if there if there are no more
975.12|2.8|questions i'm gonna um i'm gonna keep
976.48|3.52|going but of course feel free to
977.92|4.719|interrupt me
980.0|4.8|so the um the way that um given this
982.639|4.0|idea so we have this uh learned latent
984.8|3.52|array which again it functions sort of
986.639|2.64|like an rnn initial state or it's a set
988.32|3.519|of weights
989.279|5.521|um we basically uh randomly initialize
991.839|5.12|that and then we use this to attend on
994.8|3.68|to um the input byte array and so the
996.959|4.161|byte array here is is the flat instead
998.48|4.32|of pixels for example for imagenet
1001.12|4.0|and the output of this is going to live
1002.8|4.88|in the same space as so the same index
1005.12|4.399|space as the latent array does
1007.68|3.279|and there's residual connections in the
1009.519|2.24|in the way that you would normally do in
1010.959|4.081|a
1011.759|5.921|in a in an attention layer as well
1015.04|5.52|um so once we're in the space we can
1017.68|4.8|then build an architecture by taking um
1020.56|3.84|by using a standard transformer but
1022.48|3.439|phrased in the latent space rather than
1024.4|3.679|in the input space
1025.919|3.92|and um this is going to allow us to
1028.079|3.441|basically end up because we've sort of
1029.839|3.921|distilled the input down to the smaller
1031.52|4.0|space we can still flexibly allow all of
1033.76|4.319|these points to interact so this should
1035.52|4.559|be still as nearly as expressive as a as
1038.079|2.72|the transformer as a normal transformer
1040.079|2.24|is
1040.799|3.441|and then each of the modules here now is
1042.319|3.6|quadratic in the latent size rather than
1044.24|5.12|the input size so this is something that
1045.919|5.601|we can control um quite a lot
1049.36|3.679|so in the in the original original
1051.52|3.519|version of the perceiver we found it was
1053.039|4.241|very helpful to um
1055.039|4.401|have additional crosstones so so this is
1057.28|3.759|certainly something that you can do um
1059.44|3.84|and the reason the the sort of the
1061.039|5.201|intuition behind this is that um if this
1063.28|4.639|bottleneck is quite is quite severe we
1066.24|3.28|can't maintain all of the information
1067.919|2.88|from the input and so we want these
1069.52|3.36|queries which are now sort of
1070.799|4.24|conditioned on the past to be able to
1072.88|4.0|look um back at the input point and so
1075.039|3.121|this um this
1076.88|2.72|this is something that we found to be
1078.16|3.6|quite helpful in when tuning for the
1079.6|3.68|first paper but the caveat i will say is
1081.76|3.68|that we're no longer recommending this
1083.28|4.0|as best practice because these cross
1085.44|3.28|attentions end up being quite heavy but
1087.28|2.639|this is something that you can explore
1088.72|3.199|certainly if you want sort of more
1089.919|3.601|conditional queries or if you want to be
1091.919|3.841|able to cross attend to new inputs that
1093.52|3.36|are coming in
1095.76|3.919|the other thing that we found quite
1096.88|4.24|helpful in the context of
1099.679|3.201|data sets that have a limited amount of
1101.12|4.559|data which for these architectures
1102.88|5.039|includes imagenet is to allow weight
1105.679|4.401|sharing in depth and so this basically
1107.919|3.281|just amounts to tying the weights um for
1110.08|2.719|the different cross-attention and
1111.2|3.28|different self-attention layers as
1112.799|5.361|they're repeated so this ends up looking
1114.48|5.92|like an rnn that's enrolled in depth
1118.16|4.399|um so this is um
1120.4|3.84|just at a high level um this gives us an
1122.559|2.961|architecture that we can apply to images
1124.24|2.88|but it doesn't make any assumptions
1125.52|4.48|about image structure so it's one that
1127.12|4.32|you can use elsewhere um and uh we
1130.0|2.48|basically um
1131.44|2.96|we
1132.48|4.24|we give information about the uh the
1134.4|4.0|input sort of spatial structure by
1136.72|3.44|having positional encodings and here we
1138.4|3.519|use a 2d fourier feature position
1140.16|3.519|encoding and just to show you kind of
1141.919|2.561|what that looks like here to give you a
1143.679|4.321|sense
1144.48|5.439|so each of the input points is assigned
1148.0|3.6|basically so you'll have you'll be in
1149.919|4.081|some position here and we have
1151.6|4.8|sinusoidal and cosine soil features in
1154.0|4.24|2d so this is basically a 480
1156.4|3.2|composition of the position of the 2d
1158.24|2.72|input
1159.6|3.04|and a couple of things that we found
1160.96|3.52|were that
1162.64|3.44|if we sampled the frequency that's the
1164.48|3.92|maximum frequency that's used up to the
1166.08|4.719|nyquist frequency of the of the signal
1168.4|4.0|we um we end up doing um better than if
1170.799|3.601|you use a lower version of this and this
1172.4|4.24|basically is because this will allow the
1174.4|4.56|um every other point to be aware of
1176.64|3.44|every every distinct point in the image
1178.96|2.719|whereas if you sample at a lower
1180.08|3.12|frequency you can end up with aliasing
1181.679|3.601|and so not all points will be um sort of
1183.2|3.76|legible
1185.28|3.84|we also found that sampling the spectrum
1186.96|3.839|relatively densely tends to help
1189.12|3.52|and the contrast here
1190.799|4.321|at the time we were developing this was
1192.64|4.64|with respect to nerf so nerf at least in
1195.12|4.32|earlier implementations used um quite a
1197.28|3.44|a small number of frequency bands we
1199.44|3.2|found that the more we added the better
1200.72|4.56|we did so so in general this is
1202.64|4.88|something to be to be attentive to
1205.28|4.0|um and then finally as opposed to
1207.52|3.68|language where you typically have
1209.28|4.24|addition of whatever you're embedding is
1211.2|4.8|with the uh the sinusoidal or position
1213.52|4.72|encoding that you use um here we find we
1216.0|4.96|found that concatenating them performed
1218.24|4.4|consistently better and so this may be
1220.96|3.92|because the positioning the the the
1222.64|3.519|content embedding is not as sparse as it
1224.88|2.48|is in language we're not totally sure
1226.159|3.361|but this is something that i observed
1227.36|3.92|consistently
1229.52|3.68|um and before i move on to results i
1231.28|4.399|just want to contrast this to some sort
1233.2|4.479|of other other approaches for um for
1235.679|4.48|using transformers in in the image
1237.679|4.88|context so the obvious um the obvious um
1240.159|4.4|precedent here is visual transformers
1242.559|3.921|and um i i think this is a this is a
1244.559|3.681|very um this line of work is is great
1246.48|3.12|especially in the image context but
1248.24|3.2|there are some caveats about it that
1249.6|4.4|make it less less suitable for sort of
1251.44|4.96|more general um more general purpose use
1254.0|3.919|uh so one is that um so vision
1256.4|3.92|transformers do use an input 2d
1257.919|5.441|convolution so this is often phrased in
1260.32|5.359|terms of patches input patches it's a
1263.36|3.6|special case of a 2d transformer so it
1265.679|4.161|does restrict
1266.96|4.8|the class of inputs you can use it for
1269.84|4.4|um and because we're basically building
1271.76|5.279|this patching or transform or
1274.24|3.919|convolution into it this means that
1277.039|2.721|this has an approach really isn't
1278.159|2.88|sufficient to get it to work on non-grid
1279.76|2.64|data there are other ways you could
1281.039|2.561|adapt it but this is something that you
1282.4|3.84|will have to special case for every
1283.6|4.16|domain you're looking at
1286.24|3.679|and then finally because we have this
1287.76|3.76|sort of input where we're i'm telling
1289.919|3.521|the architecture what it should look at
1291.52|2.96|first in the initial grouping this does
1293.44|2.88|amount to getting rid of the
1294.48|3.679|non-locality assumption
1296.32|3.2|it's not super clear how doing how much
1298.159|3.041|doing this just once will make a
1299.52|2.88|difference but this is something to be
1301.2|3.52|aware of when you're thinking about this
1302.4|4.56|architecture
1304.72|4.24|and then finally cross-attention itself
1306.96|4.24|is used quite broadly um in the vision
1308.96|3.599|literature so um
1311.2|3.2|just a couple to highlight a couple of
1312.559|3.921|examples um deader
1314.4|4.639|which is a an object detection method
1316.48|4.559|from facebook basically has a
1319.039|4.161|convolutional backbone that's then used
1321.039|4.081|to give an output feature map this is
1323.2|3.52|then passed into and transforming code
1325.12|3.12|or decoder and of course whenever you
1326.72|3.6|hear encoder decoder you can cross
1328.24|4.08|attention because from the encoder the
1330.32|3.76|decoder there's a cross attention step
1332.32|3.359|and so they're using basically the cross
1334.08|2.959|attention to go from some feature map
1335.679|4.88|representation to something that looks
1337.039|5.681|more like the object bounding boxes
1340.559|2.961|there's also quite nice work
1342.72|2.48|on
1343.52|4.08|learning
1345.2|4.719|self-supervised or unsupervised object
1347.6|3.92|segmentation models um
1349.919|2.801|and uh in this work they're doing
1351.52|4.0|something very similar where they have a
1352.72|4.959|convolutional backbone they then use um
1355.52|4.0|something like um these latent uh the
1357.679|4.561|latents that we introduce here
1359.52|5.12|to do um to they call them slots here
1362.24|5.04|but basically to assign um some of the
1364.64|4.399|output pixels to um to different slots
1367.28|3.84|so that they sort of have independent
1369.039|6.361|complementary decoding of the slots in
1371.12|4.28|the in the segmentation model here
1375.52|2.24|and there's a there's a lot of other
1376.64|2.8|things
1377.76|2.799|um okay so first i want to just so now
1379.44|4.0|i'm going to sort of walk you through
1380.559|5.441|results of this of this model
1383.44|5.359|um hi can i oh go ahead
1386.0|5.2|yes i'll go after you go for it
1388.799|4.081|okay cool uh sorry for that
1391.2|4.32|can you go back a couple of slides where
1392.88|5.679|you had like the you know like how
1395.52|6.639|uh how like the inputs like flow into
1398.559|5.681|like um i think one about yeah that one
1402.159|3.841|okay um there's two questions so the
1404.24|4.72|latent transformer is basically like a
1406.0|4.64|self-attention is that correct
1408.96|3.839|yeah so the latent transformer is a
1410.64|3.36|self-a fully self-intentional
1412.799|3.841|transformer
1414.0|5.12|got it and um why
1416.64|3.919|is see like for like the key and value
1419.12|3.2|they flow direct into your cross
1420.559|4.0|attention and there is like
1422.32|4.8|the query also flowing into it but the
1424.559|5.201|latent array is flowing into the cross
1427.12|4.24|attention in parallel to the query can
1429.76|4.08|you explain that
1431.36|4.08|yeah so this is just um
1433.84|3.199|here
1435.44|4.08|yeah um it's it's meant to depict the
1437.039|4.321|residual connection so the um the the
1439.52|4.32|cross attention this is sort of a cross
1441.36|4.08|attention depicted as a cross attention
1443.84|3.28|and so the cross-attention itself has
1445.44|3.44|the attention it has a residual
1447.12|3.679|connection and then there's an mlp so
1448.88|2.88|that's what that's meant to indicate
1450.799|3.041|okay
1451.76|3.12|but it it's basically the qkb is
1453.84|2.24|standard
1454.88|3.44|got it
1456.08|4.56|thanks
1458.32|4.0|hi uh i had a question
1460.64|3.519|that is uh slightly related to this we
1462.32|2.88|can just stay up this slide actually so
1464.159|3.52|i think one thing that's interesting
1465.2|2.479|about this art
1469.12|3.159|for sure
1475.84|3.92|consisting of attention layers whether
1477.52|4.56|it's retention or in image transformers
1479.76|4.48|can you hear me is that coming through
1482.08|5.599|oh it's cutting off i think yeah but i
1484.24|5.679|think some recent work oh okay
1487.679|4.561|should i type it is that should i type
1489.919|4.321|yeah that's a good idea yeah okay i'll
1492.24|4.319|type it thanks sorry
1494.24|2.319|all right
1498.32|3.68|feel free to go ahead i'll type it
1500.24|4.16|slowly and
1502.0|4.0|sounds good sounds good to me yeah
1504.4|4.879|actually can i chime in drew while
1506.0|5.2|you're on that previous slide um yeah
1509.279|3.441|so these residual connections i actually
1511.2|3.599|didn't know the cross attention use them
1512.72|3.68|how reliant are the sequential cross
1514.799|4.161|attention layers on the residual
1516.4|2.56|connections
1519.039|4.161|um yeah so here um
1523.6|5.04|here uh in the initial so the um
1526.559|4.0|two things i will say is that um the in
1528.64|3.519|the initial cross attention um it
1530.559|3.761|doesn't really make a difference
1532.159|4.0|um so this is something we've ablated um
1534.32|3.2|when we get to the procedure i o version
1536.159|3.361|of this we also did the same thing in
1537.52|3.039|the decoder um cross attention and it
1539.52|2.08|can make some of it different it can
1540.559|3.041|make a difference there depending on
1541.6|3.6|what you're doing um i think it's it's
1543.6|3.12|actually essential in the content when
1545.2|3.12|you're using repeated cross-attention of
1546.72|3.52|this way so when you have this sort of
1548.32|3.2|iterative structure and the reason for
1550.24|3.52|this is that the the thing that's
1551.52|4.72|actually used to condition the query is
1553.76|4.0|um is basically all that that's your
1556.24|3.439|your full representation of the sort of
1557.76|3.76|the state of the architecture so far
1559.679|4.401|and so the the skip connection is from
1561.52|4.08|the um it's it's in basically the query
1564.08|3.36|channel it's in the latent the latent
1565.6|3.04|space and so this is basically what
1567.44|4.8|allows you to end up with this sort of
1568.64|6.56|dense dense and stable architecture
1572.24|2.96|okay thank you
1578.799|2.321|okay
1581.52|5.84|so to imagenet um okay so in standard
1584.88|5.279|image net processing um basically um we
1587.36|4.08|compare against um a few um so this is
1590.159|3.281|this is a little bit out of date at this
1591.44|4.0|point but uh against a few sort of um
1593.44|3.92|just sort of sanity check um baselines
1595.44|3.76|here so i'm comparing against resident
1597.36|3.6|50 and then at the time the best um
1599.2|3.599|vision transformer model that was purely
1600.96|3.68|on imagenet and we're um we're
1602.799|2.88|definitely in the ballpark this isn't um
1604.64|2.639|these aren't
1605.679|3.521|anywhere near state of the art results
1607.279|4.0|but um this is an architecture that
1609.2|3.359|again is not using any 2d convolutions
1611.279|2.321|and so the fact that it was able to do
1612.559|3.521|this well was we found very very
1613.6|4.559|surprising at the time um one of the the
1616.08|4.24|quite cool things about this is that
1618.159|4.4|because this architecture is not making
1620.32|4.08|any assumptions the architecture itself
1622.559|4.561|isn't making any assumptions about the
1624.4|4.639|the um the spatial structure of the um
1627.12|4.0|of the input images we can look at
1629.039|4.081|permuted image net and in the first
1631.12|4.48|version of this what we do is basically
1633.12|4.24|um we compute the features using the 2d
1635.6|3.76|position so the 2d position is sort of
1637.36|3.76|fixed to a position to the pixel and
1639.36|3.28|then we just shuffle them all and so
1641.12|3.679|this is um basically will give you a
1642.64|5.759|sense of how dependent the bass lines
1644.799|5.12|are on the input image structure and so
1648.399|3.601|if we look at um if we look at the
1649.919|3.76|transformer perceiver by construction
1652.0|3.2|they don't change so this is this is not
1653.679|3.761|an empirical finding this is a property
1655.2|4.8|of the models um but we find that
1657.44|4.16|resonance 50 um falls by the performance
1660.0|3.919|falls by about half
1661.6|3.52|and vit which again only has one layer
1663.919|4.081|where it's relying on the spatial
1665.12|4.48|structure also has about a 15 point drop
1668.0|4.08|and so this suggests that it's relying
1669.6|4.079|quite a lot on that very first one
1672.08|3.28|to give it some information about the
1673.679|3.841|structure
1675.36|3.679|we can push this a little bit by instead
1677.52|3.92|of relying on 2d
1679.039|4.721|fourier features learning completely
1681.44|3.68|learned positional encodings and this
1683.76|2.88|basically this um this is an
1685.12|3.279|architecture now this is a model that
1686.64|4.32|has absolutely no information about the
1688.399|4.16|input structure um and so shuffling them
1690.96|3.12|and learning them again is absolutely
1692.559|4.081|equivalent and we find that this
1694.08|4.24|architecture also can be pushed above 70
1696.64|3.36|and we've gotten slightly better numbers
1698.32|5.04|here um in general this seems to work
1700.0|5.2|worse but um so the 2d information is is
1703.36|3.919|useful but it's quite cool that you can
1705.2|3.76|get what would have been
1707.279|3.12|numbers comparable to
1708.96|3.68|of the art about five five or six years
1710.399|5.28|ago so this is quite cool
1712.64|4.08|sorry i'm a little thick here uh
1715.679|2.961|you're saying
1716.72|3.839|the difference between the last two rows
1718.64|4.32|is that the uh
1720.559|3.761|second to last row has a two dimensional
1722.96|2.56|position embedding and the last one has
1724.32|3.04|a one-dimensional position of betting
1725.52|4.32|essentially is that right
1727.36|4.799|uh so it's it's learned so um you it's
1729.84|4.4|um basically it's it's a it'll be um
1732.159|4.88|it's a i believe a 256-dimensional
1734.24|4.48|vector that's learned um but it doesn't
1737.039|3.441|uh it basically does um
1738.72|4.16|it it means that the model itself has no
1740.48|3.919|information about the input spatial
1742.88|3.679|structure
1744.399|3.52|so the um the 2d positional encodings
1746.559|2.48|that we're using you know end up having
1747.919|2.801|about 200
1749.039|3.281|it's 200 some features depending on what
1750.72|3.36|you're looking at but they're always
1752.32|3.359|they give you very detailed information
1754.08|2.8|about the 2d structure of the input
1755.679|3.921|because they're based on a fourier
1756.88|5.12|decomposition of the input space
1759.6|5.52|okay that makes sense thank you
1762.0|6.32|hi drew i can ask you a question about
1765.12|5.679|uh frequency you use to generate those
1768.32|6.64|uh essential other way
1770.799|4.161|yeah so like a cover slide before
1776.799|3.681|yeah oh
1778.72|2.64|yeah yeah this slide
1780.48|3.6|so
1781.36|3.76|basically i i do have taken some
1784.08|4.479|lectures
1785.12|4.799|in signal processing and i know if i
1788.559|4.161|want to avoid
1789.919|5.36|you know alienc i need to sample with at
1792.72|5.439|least nyquist frequency so i'm curious
1795.279|3.841|to know why to use frequencies starting
1798.159|3.361|from
1799.12|4.799|one to the nyquist frequency instead of
1801.52|5.039|starting from my microsd frequency to
1803.919|6.0|some very high frequency
1806.559|5.761|i see so the um basically um
1809.919|3.76|so um the maximum frequency that's used
1812.32|3.04|is always nyquist
1813.679|2.88|so anything about likewise is going to
1815.36|2.64|be alias so you're not actually going to
1816.559|2.24|be able to resolve it
1818.0|3.039|um
1818.799|3.6|because it's in pixel space right so um
1821.039|2.801|we sample
1822.399|3.681|one is basically just giving you an
1823.84|4.319|oscillation that covers the entire image
1826.08|3.44|um and so this is this is uh basically
1828.159|3.76|just to sample the full range of
1829.52|4.54|non-aliased frequencies
1831.919|5.271|oh okay cool thank you
1834.06|3.13|[Music]
1838.72|2.48|okay
1841.6|5.76|okay so um so um after uh after the
1844.72|4.64|image results we wanted to try it on
1847.36|3.679|other domains and in particular we were
1849.36|3.52|interested in how this could be used to
1851.039|4.24|to work on sort of multimodal domains so
1852.88|4.24|once combining various different um
1855.279|3.441|types of input features
1857.12|3.2|and um
1858.72|2.72|the one one challenge or one sort of
1860.32|3.12|problem that you encounter in these
1861.44|4.0|sorts of spaces is that the data from
1863.44|3.68|different modalities end up having
1865.44|3.68|different features and they always have
1867.12|4.399|different semantics so if you take the
1869.12|4.559|positional encoding plus the um the rgb
1871.519|4.081|for video you end up with some number of
1873.679|4.0|channels and then if you have audio that
1875.6|4.079|corresponds the data may be paired but
1877.679|4.24|it tends to have fewer features and it
1879.679|4.72|only has a 1d position 1 coding so the
1881.919|4.721|way that we handle this is basically by
1884.399|4.241|learning modality specific position
1886.64|4.56|encodings and so these are basically
1888.64|4.72|embeddings that are special and learned
1891.2|4.24|for each of the modalities and what this
1893.36|4.08|does is basically tags ends up tagging
1895.44|3.92|the features that come from audio or
1897.44|3.44|video with some information that the
1899.36|3.28|network can learn that allows it to
1900.88|4.08|distinguish which ones which
1902.64|4.0|but given these um these padded these
1904.96|3.68|sort of learned padded
1906.64|3.36|feature vectors we then concatenate them
1908.64|3.68|all and that's how we process a
1910.0|3.519|multi-modal data so basically the input
1912.32|3.199|to the architecture still looks like
1913.519|3.601|just one big array it's just that when
1915.519|3.04|constructing this we know that some of
1917.12|3.439|those features some of the rows in that
1918.559|3.84|array come from video and some come from
1920.559|3.201|audio but the model itself isn't given
1922.399|2.88|information about that other than what
1923.76|3.519|it learns
1925.279|5.841|uh we also have some questions
1927.279|3.841|yeah so you can go first
1945.76|3.0|foreign
1955.2|5.12|basically a positional embedding is um
1957.76|3.919|it's a feature that says this um so so
1960.32|4.079|i'm in the simplest way to think about
1961.679|4.88|it is in text so text um the input is 1d
1964.399|4.561|so things live in some 1d sequence and
1966.559|4.0|for each point there you featurize where
1968.96|3.199|it's located in that sequence so the
1970.559|4.161|simplest thing to do would be if you
1972.159|3.441|have negative 1 to 1 is the full range
1974.72|2.48|it's just
1975.6|3.919|denotes actually where it's located in
1977.2|4.88|that sequence but we typically will add
1979.519|4.16|um sort of uh we will we'll want to
1982.08|3.28|featurize this to have more dimensions
1983.679|3.041|than just a single one and so the
1985.36|2.799|fourier transpo
1986.72|3.28|the fourier decomposition is one way to
1988.159|3.841|do this to sort of give it privileged
1990.0|4.559|information about the high frequency
1992.0|4.88|structure but we can also just use the
1994.559|4.561|position to index onto some embedding
1996.88|3.919|array which is um which is how we do it
1999.12|3.12|when we're learning things so basically
2000.799|3.281|it's just a set of weights that are
2002.24|3.279|added to the feature for that point that
2004.08|2.88|give the network information about where
2005.519|3.841|it's located in the in the ground
2006.96|2.4|sequence
2012.08|3.56|you want to go next
2018.08|3.68|sorry i had to find a mute button
2020.88|2.639|um
2021.76|4.32|okay so i actually have two questions
2023.519|4.88|regarding the fewer features about three
2026.08|4.4|features um the
2028.399|5.201|i think like do you guys sample them
2030.48|4.24|like uniformly or um
2033.6|2.16|are they
2034.72|4.319|like
2035.76|6.24|um do you like to learn these
2039.039|4.721|yeah so um so basically we um we sample
2042.0|3.279|them linearly so basically we take the
2043.76|3.12|full space and we sample them linearly
2045.279|2.481|with whatever the budget is
2046.88|2.799|um
2047.76|3.359|there are um
2049.679|2.561|so in in various settings we have
2051.119|3.121|actually tried learning these so you
2052.24|3.52|could actually initialize an array with
2054.24|4.399|them and then learn them and that does
2055.76|4.8|help sometimes actually um and you could
2058.639|4.081|potentially learn you could try a more
2060.56|4.799|sophisticated strategy on this too
2062.72|5.119|okay cool my follow-up question is that
2065.359|5.361|basically i feel like the selling point
2067.839|4.881|of uh your research right is that you
2070.72|3.76|don't make any structural assumptions
2072.72|2.8|right you can take any type of like
2074.48|3.679|format
2075.52|4.319|um however for like the encoding
2078.159|2.72|wouldn't the dimensionality so for
2079.839|3.76|example
2080.879|3.841|um like if it's text it's 1d right if
2083.599|3.601|it's a
2084.72|5.76|like an image it will be 2d and if it's
2087.2|5.439|like a video with 3d um you have like
2090.48|4.08|more um
2092.639|4.161|like the positions in coding will have
2094.56|5.12|like more points right wouldn't that
2096.8|7.2|like inherently give away
2099.68|6.159|like the nature of the um of the input
2104.0|3.92|yeah so it does um so i completely agree
2105.839|3.681|with this you're totally right um
2107.92|3.199|the the version of this where we have
2109.52|3.52|learned position encodings is the most
2111.119|3.521|pure from that point of view so it's one
2113.04|3.12|that gives it basically no information
2114.64|3.36|about the the ground truth spatial
2116.16|4.16|structure
2118.0|4.0|what it does give the um the model so
2120.32|3.519|when you do the learn position encoding
2122.0|5.04|it will say that for example there is a
2123.839|6.641|correspondence between point k on image
2127.04|5.44|one and point k on image two so that's
2130.48|3.92|basically the the least amount of
2132.48|3.359|information you can give it while still
2134.4|2.88|allowing it to sort of figure out what
2135.839|2.881|the structural relationship between the
2137.28|2.88|input points is
2138.72|2.8|so this is the direction that we've been
2140.16|4.16|trying to push in
2141.52|4.16|um in general giving the architecture
2144.32|3.279|access to sort of ground truth
2145.68|5.52|structural information like this lives
2147.599|5.52|on this point in 2d um is helpful so
2151.2|3.84|um there's there's a couple things here
2153.119|3.681|there's there's sort of from a practical
2155.04|3.36|point of view if you want good results
2156.8|3.84|you need to exploit these things or it's
2158.4|3.52|helpful to exploit these things but we
2160.64|3.52|do want to move in the direction where
2161.92|3.76|we're relying on these things less
2164.16|4.16|and so this is this is basically
2165.68|5.36|something we're actively looking into
2168.32|6.4|okay make sense thank you
2171.04|6.24|so i think has posted her question
2174.72|4.639|on on the chat uh i also see you have
2177.28|4.559|your hand raised so if you if you want
2179.359|4.0|you can give it a try um if not i'll
2181.839|3.681|read out the question
2183.359|3.601|okay i'll try just let me know if it's
2185.52|3.92|choppy
2186.96|4.8|but yeah so is it good right now so far
2189.44|4.159|so good yeah oh good okay cool so i was
2191.76|3.52|curious uh looking at the perceiver
2193.599|2.961|diagram you had it's a bunch of
2195.28|3.6|attention layers right like cross
2196.56|4.72|attention and self-attention and
2198.88|4.4|i think uh there's been this like small
2201.28|4.64|trend in recent work in vision
2203.28|4.079|transformers to try to sort of replace
2205.92|3.28|the last few layers instead of having
2207.359|4.0|attention like make them be convolutions
2209.2|4.24|to address this attention scaling
2211.359|3.841|problem right in a different manner and
2213.44|3.6|so here like the perceiver architecture
2215.2|2.96|is trying to make self-attention less
2217.04|3.28|expensive
2218.16|3.76|and uh there they're just trying to
2220.32|3.039|replace it and they kind of just avoid
2221.92|3.36|the problem
2223.359|3.841|and so i'm curious um and so i've seen
2225.28|3.36|papers both ways like some that try to
2227.2|2.8|do things like the ones you cited and
2228.64|4.16|then some they're trying to do this as
2230.0|4.24|well and uh in my mind everyone always
2232.8|2.559|has like the good results and stuff so
2234.24|3.92|i'm curious if you think there's a
2235.359|5.201|reason to do one or the other or if you
2238.16|4.56|think this alternative approach is also
2240.56|3.68|promising or is there a reason you know
2242.72|3.6|research should go in one direction or
2244.24|3.92|the other
2246.32|3.84|yeah so to my mind the big trade-off is
2248.16|3.76|one between so um
2250.16|3.199|the the vision literature i think is um
2251.92|3.52|it's just exploded in terms of these
2253.359|3.601|sort of hybrids and people yeah
2255.44|3.52|they'll write the exact right um place
2256.96|4.879|on the pareto curve for the trade-off of
2258.96|4.399|speed and and uh performance but they're
2261.839|4.401|basically looking primarily on vision
2263.359|4.641|specific problems so something i see
2266.24|3.2|the the the computer vision community
2268.0|3.359|itself typically doesn't regularize
2269.44|4.48|itself away from things that don't work
2271.359|4.081|on on things that aren't vision
2273.92|3.76|so you end up with things that are very
2275.44|4.08|very efficient very performant on vision
2277.68|3.04|problems um
2279.52|2.72|i think from that point of view that's
2280.72|2.879|an it's an incredibly important line of
2282.24|4.32|work and that that's probably the right
2283.599|4.561|way of do of doing things
2286.56|3.92|what we're sort of aiming for is
2288.16|4.64|something um is the things that are as
2290.48|3.76|as general as possible while still kind
2292.8|2.24|of being performant
2294.24|2.879|so
2295.04|3.36|this kind of thing is critical oh sorry
2297.119|3.201|to pull you off go ahead
2298.4|3.679|no no please go ahead i was gonna say so
2300.32|2.799|this kind of thing is like it's
2302.079|2.161|important
2303.119|2.72|just to summarize so you feel like it's
2304.24|3.44|important to focus on attention because
2305.839|3.28|that's kind of critical for nlp like you
2307.68|3.2|can't just sort of put in a convolution
2309.119|3.441|at the end and sort of fix the problem
2310.88|3.52|but in vision maybe you can and it's
2312.56|3.279|fine is that a right way of
2314.4|3.679|understanding it
2315.839|3.76|um that's part of it um vision and nlp
2318.079|2.881|aren't the only two domains and so the
2319.599|3.681|certain that we're yeah
2320.96|4.72|are really basically um so the kinds of
2323.28|4.0|problems um that that we're interested
2325.68|5.04|in doing with this include things like
2327.28|5.52|event based cameras um cell biology uh
2330.72|4.32|sort of proteins all of these sorts of
2332.8|4.08|things where um we may or may not have
2335.04|3.36|the right convolutional inductive biases
2336.88|3.6|for to even know how to build those
2338.4|3.6|sorts of things
2340.48|3.119|they end up being whole research
2342.0|2.48|programs like the mesh based convolution
2343.599|3.281|work
2344.48|5.119|oh cool thank you i also had like one
2346.88|4.479|more question about the architecture so
2349.599|4.641|i saw that i'm sorry if you said this
2351.359|4.401|and i just missed it but you had close
2354.24|3.76|attention and then like deterrently to
2355.76|4.079|transformer and then cross attention i'm
2358.0|3.44|curious what happens if you replace the
2359.839|3.681|self potential in those layers with
2361.44|4.159|cross attention does it affect your
2363.52|4.48|accuracy is that even feasible is that a
2365.599|4.0|valid question
2368.0|3.119|yeah so um the sort of thing that you
2369.599|3.121|could do is you could modify this to
2371.119|3.921|make it sort of hierarchical so that
2372.72|4.96|there are multiple pages attention we
2375.04|4.96|haven't gotten this working yet but it
2377.68|4.48|doesn't mean it's not a good idea
2380.0|3.28|um so there might be there might be a
2382.16|2.24|right way to do this that we haven't
2383.28|2.48|figured out right but it's something we
2384.4|2.959|have tried a little bit
2385.76|2.72|oh cool okay thank you so much i
2387.359|3.361|appreciate it
2388.48|5.04|yeah no problem
2390.72|2.8|okay let me
2393.68|2.32|um
2394.48|3.76|we're running short on time so maybe
2396.0|4.64|i'll skip ahead
2398.24|2.4|um
2401.04|3.36|okay so i
2402.48|4.24|before we run uh too much time i want to
2404.4|4.08|at least talk about the um the sort of
2406.72|3.84|the modifications to this architecture
2408.48|3.76|that we've made to make it work sort of
2410.56|3.68|even more generally so one of the
2412.24|4.0|problems of the um the sort of the first
2414.24|4.32|um the first architecture that we looked
2416.24|3.119|at here the basic perceiver is that it
2418.56|3.12|works
2419.359|5.601|basically for arbitrary inputs
2421.68|4.88|but um it's uh it's designed to work
2424.96|3.119|only on classification or regression
2426.56|3.44|tasks as an output
2428.079|3.361|and so basically um we wanted to see if
2430.0|3.119|we could use the same um the same
2431.44|3.28|cross-attention strategy for decoding
2433.119|3.041|and it turns out you can it's um it's
2434.72|2.879|something that works pretty well just
2436.16|3.84|kind of out of the box
2437.599|4.321|so the idea is that um we have um if we
2440.0|3.44|have our cross attention input and
2441.92|4.159|self-attention sort of to do the
2443.44|5.04|processing we can introduce a set of
2446.079|3.921|additional queries and these are
2448.48|3.04|basically queries that give the
2450.0|3.359|semantics of each of the points that
2451.52|4.4|you're trying to decode
2453.359|4.081|and we pass this as input to another
2455.92|3.679|cross attention layer which is
2457.44|3.6|configured in basically the opposite way
2459.599|3.52|that the encoder cross attention is
2461.04|3.92|configured so now the queries are going
2463.119|3.281|to be something that's potentially large
2464.96|3.52|and the keys and values are coming from
2466.4|3.919|this latent and so what this allows us
2468.48|3.52|to do basically is to keep all of the
2470.319|3.601|nice advantages of the original
2472.0|3.92|perceiver so we have an encoder that
2473.92|3.84|scales linearly we have a processor
2475.92|3.6|stage this sort of latent self-attention
2477.76|4.319|that scales independently of the input
2479.52|4.64|size and we now have a decoder that
2482.079|3.681|keeps the the decoupling but gives us
2484.16|2.56|linear scaling with respect to output
2485.76|3.839|size
2486.72|4.16|and so by doing this we can now um
2489.599|3.361|basically
2490.88|4.239|apply the same approach to basically
2492.96|3.44|dense dense output tasks
2495.119|3.601|and so to give you a sense of how this
2496.4|3.919|works just sort of intuitively
2498.72|4.16|um if we're if we're doing auto encoding
2500.319|5.28|on this um image of puppies uh basically
2502.88|5.6|we um what we do is we encode process
2505.599|4.801|and then to decode we take a query that
2508.48|4.0|corresponds to each of the points and
2510.4|4.32|then we pass it into this decoder so we
2512.48|3.839|can query one of the points we get one
2514.72|3.599|pixel query another one we get another
2516.319|3.841|one and all the way up
2518.319|3.28|until we get all 10 000 points and
2520.16|2.4|that's how we can do reconstruction with
2521.599|2.561|this
2522.56|3.84|and the cool thing about this is that it
2524.16|4.48|opens up a bunch of new applications
2526.4|3.439|um so
2528.64|2.719|and we can get different kinds of
2529.839|2.401|outputs just by changing how the queries
2531.359|2.081|work
2532.24|3.44|so if we want to do something like
2533.44|4.08|multimodal auto encoding where we have
2535.68|4.08|some of the outputs or videos we use the
2537.52|3.44|same construction trick to get
2539.76|3.2|positions
2540.96|3.2|that to get queries that are have the
2542.96|2.72|relevant semantics for each of the
2544.16|3.52|points that we're decoding
2545.68|3.919|and we can do we can do this even though
2547.68|3.12|the um the basically the sizes of these
2549.599|3.681|different data so the number of points
2550.8|4.08|they have is quite diverse um so in the
2553.28|3.28|multimodal audio encoding experiments
2554.88|3.76|that we have that we have in this paper
2556.56|3.44|we do this for video audio and labels at
2558.64|3.28|the same time so that all of them are
2560.0|4.64|just passed into the uniform network and
2561.92|4.24|then decoded one by one in this way
2564.64|3.92|but we can also do
2566.16|3.76|mass language modeling now by by
2568.56|2.559|conditioning on the position in a
2569.92|3.52|sequence
2571.119|4.24|we can do multi-task classification by
2573.44|3.6|having basically an index that gives
2575.359|3.201|which task you're querying from the
2577.04|3.2|network
2578.56|3.519|and we can do things like optical flow
2580.24|3.52|by passing in input features as well as
2582.079|3.201|the positions
2583.76|3.52|and so i'm just going to
2585.28|4.079|just quickly skip to a couple of the
2587.28|3.68|different
2589.359|3.041|i can i can share these slides with you
2590.96|3.359|with you all afterwards um to look
2592.4|3.28|through them um
2594.319|4.0|some of some of these things are quite
2595.68|3.919|cool but um
2598.319|3.441|just quickly i want to talk about
2599.599|5.201|language and then optical flow
2601.76|4.48|so for um for language basically what we
2604.8|3.44|what we wanted to do with this was to
2606.24|3.359|see if we could use this to replace um
2608.24|3.2|tokenization
2609.599|3.041|and um why
2611.44|3.84|might we care about getting rid of
2612.64|4.56|tokenization so one we use tokenization
2615.28|3.68|primarily because transformers scale
2617.2|3.36|poorly with sequence length and
2618.96|3.359|tokenizing because sequence length by
2620.56|5.039|about a factor of four
2622.319|6.401|um but um but there are various problems
2625.599|4.48|that arise with this and so um so my why
2628.72|3.44|why might we care about removing
2630.079|4.801|tokenizers
2632.16|5.04|so uh for one
2634.88|4.239|uh tokenizers perform less well on rare
2637.2|4.72|words so if you compare the sort of the
2639.119|5.2|byte based decomposition um the utf-base
2641.92|4.24|uh utf-8 encoding of an input of an
2644.319|3.601|input sequence like this you can see
2646.16|3.439|that there's basically a uniform
2647.92|3.28|allocation of
2649.599|3.76|of points in memory to each of the input
2651.2|4.639|characters the exception or diacritics
2653.359|3.841|which end up splitting into two
2655.839|3.841|but if you look at the sentence piece
2657.2|5.44|tokenization so it's learned that pepper
2659.68|6.24|is one one token but jalapeno gets split
2662.64|5.52|into into five in this case so this this
2665.92|4.08|basically says it's it's um the the
2668.16|3.919|amount of capacity that you allocate
2670.0|5.2|depends on how rare the word is which
2672.079|4.881|can lead to some optimal encodings
2675.2|3.44|um they're also brittle to subtle
2676.96|4.48|perturbations a famous example of this
2678.64|5.6|is that um if you um enter so if you've
2681.44|4.08|ever played around with gpt3 um you'll
2684.24|3.2|notice that the output can be quite
2685.52|3.76|sensitive to where if you add a space or
2687.44|3.36|emit a space at the end and this
2689.28|3.039|basically is because the space can end
2690.8|2.88|up being factorized into different parts
2692.319|2.401|of the tokenization there are other
2693.68|2.56|problems there are other things that can
2694.72|3.44|happen there too but this is one one
2696.24|3.839|cause of that
2698.16|3.919|um and finally um tokens don't transfer
2700.079|3.76|across across languages so if you wanted
2702.079|3.04|to have a model that without any tuning
2703.839|3.361|could be used on many different
2705.119|3.841|languages at the same time tokenizers
2707.2|4.0|are a blocker for this so if we can get
2708.96|4.24|rid of them it'll simplify the pipeline
2711.2|3.52|it'll also make things less brittle and
2713.2|3.2|then hopefully lead to more general
2714.72|3.28|models
2716.4|3.439|so the way that we do mass language
2718.0|3.839|modeling is the same as the way that i
2719.839|4.881|showed in that schematic auto encoding
2721.839|4.801|experiment so we mask um some fraction
2724.72|3.44|of our inputs about 15 is sort of the
2726.64|3.679|standard magic number
2728.16|4.88|um we then decode at each of the
2730.319|4.081|positions that are masked and we tasked
2733.04|3.36|the model with decoding whatever
2734.4|3.84|characters were more masked at those
2736.4|3.199|locations
2738.24|3.28|and then once we have this model so this
2739.599|3.921|is what we do for pre-training we can
2741.52|4.559|then fine-tune fine-tune it by replacing
2743.52|4.24|the decoder with a multi-task decoder
2746.079|3.201|that takes in the tasks that we're using
2747.76|3.92|on the fine on the on the downstream
2749.28|4.64|evaluation um setting and training the
2751.68|5.12|model to uh to reconstruct the logits on
2753.92|2.88|a per task basis
2757.599|5.441|um okay so to look at how this model
2760.24|5.119|performs we um basically first compare
2763.04|4.4|it to bird base so this is just a solid
2765.359|4.641|benchmark that we understand very well
2767.44|3.84|and um first by looking at um sort of
2770.0|3.2|matched
2771.28|4.48|two models that have matched flops we
2773.2|3.28|can see that the um that perceiver i o
2775.76|2.48|and
2776.48|3.04|bass work on par
2778.24|3.359|you see there's a different trade-off
2779.52|4.319|here so to get the same number of flops
2781.599|3.601|basically we make perceiver i o deeper
2783.839|3.441|and this ends up giving it more
2785.2|4.0|parameters but at a flaw on a per flops
2787.28|3.92|basis um it ends up performing about the
2789.2|3.68|same
2791.2|4.56|um on the other hand if we remove the
2792.88|4.64|tokenizer from bert and keep the flops
2795.76|3.2|flops the same we see that the number of
2797.52|3.68|parameter the number of parameters in
2798.96|3.6|the depth just drastically fall down and
2801.2|3.119|this is because
2802.56|2.72|bert scales quite poorly with sequence
2804.319|2.721|length because it uses a normal
2805.28|4.319|transformer
2807.04|3.92|but if we use a perceiver without the
2809.599|3.121|tokenization
2810.96|3.359|we can see that
2812.72|4.48|we only get a slight reduction in the
2814.319|4.481|number of parameters at the flops count
2817.2|3.04|but the performance performs almost
2818.8|2.72|exactly the same
2820.24|2.72|so this means that the perceiver the
2821.52|2.799|perceiver in the setting is performing
2822.96|2.8|basically the same with and without the
2824.319|3.201|tokenization it's learning a different
2825.76|3.04|strategy it's using different parameters
2827.52|3.2|but it basically can be brought to the
2828.8|4.0|same performance
2830.72|3.28|we can then scale this more by sort of
2832.8|3.2|leaning into what happens in the
2834.0|3.76|tokenizer free setting and we see that
2836.0|4.319|we can get a moderate modern performance
2837.76|2.559|boost as well
2840.4|2.8|i think it's also in the language
2841.599|3.441|setting it's also useful to look at what
2843.2|3.52|the attention the attention maps that
2845.04|3.68|are sort of learned and what's being
2846.72|3.599|visualized here are basically for each
2848.72|3.599|of the latents for some subset of the
2850.319|4.561|latents we're looking at where it's
2852.319|4.8|attending to in the input sequence
2854.88|4.4|and some of these end up being local so
2857.119|3.361|point looking at specific points in the
2859.28|3.039|sentence
2860.48|3.599|some of them are periodic so they look
2862.319|3.28|sort of at recurring points over the
2864.079|3.121|sequence
2865.599|3.441|and some of them also look like they
2867.2|4.96|pick out syntactic features which is
2869.04|5.279|quite nice so they pick out basically uh
2872.16|3.84|exclamation points or capital letters or
2874.319|3.52|other punctuation that's quite useful
2876.0|3.2|and decodable from very um right right
2877.839|3.76|at the beginning of the end of the
2879.2|4.639|sequence
2881.599|4.561|um we can also basically use this um
2883.839|3.681|this exact same architecture on optical
2886.16|3.679|flow
2887.52|4.079|an optical flow is um is basically an
2889.839|4.0|important classical problem in computer
2891.599|5.041|vision where given a pair of frames in a
2893.839|4.72|video we want to basically track all of
2896.64|4.64|the points so figure out the motion from
2898.559|4.0|every point from one frame to the other
2901.28|3.6|and so optical flow is usually
2902.559|3.681|visualized using this um these sort of
2904.88|3.6|colorized images that are shown on the
2906.24|4.16|bottom and what this gives you basically
2908.48|4.72|is a per pixel indication of the
2910.4|4.959|velocity at every single point
2913.2|5.119|and so you can see that um
2915.359|4.641|so so the um the the blade the the the
2918.319|3.921|character here is holding is moving to
2920.0|3.839|the right whereas this uh this creature
2922.24|3.599|behind her is sort of moving as moving
2923.839|2.961|downwards
2925.839|2.561|um
2926.8|3.84|so there are a couple of problems with
2928.4|3.84|um with optical flow that make it um
2930.64|4.16|make it interesting to um to sort of
2932.24|4.72|approach so one is it's a dense task and
2934.8|4.48|it basically involves um long-range
2936.96|3.84|correspondences but the standard
2939.28|3.279|training protocol there's basically no
2940.8|3.279|large scale realistic training data just
2942.559|3.52|because it's incredibly hard to sort of
2944.079|4.161|label all of the pixels in a real world
2946.079|3.601|scene and figure out where they go to
2948.24|3.04|so the typical way to do this is to
2949.68|5.2|train on some synthetic data and then
2951.28|6.64|evaluate on more realistic scenes
2954.88|5.52|and um optical flow is also interesting
2957.92|4.48|because it's um basically the locus of
2960.4|4.32|some of the most complicated visual
2962.4|3.919|architectures uh in the literature so
2964.72|3.76|the previous state of the art result
2966.319|4.24|here is this method called raft which
2968.48|4.0|won the best paper award at dccv last
2970.559|3.76|year and i'm just highlighting this to
2972.48|3.359|give you a sense of how much work people
2974.319|2.961|do into sort of hand engineering these
2975.839|3.121|architectures
2977.28|3.36|so this is a very very cleverly designed
2978.96|3.44|architecture and basically it
2980.64|4.0|incorporates things like global
2982.4|4.0|correlation volumes that are explicitly
2984.64|3.6|computed at different offsets to
2986.4|3.679|basically allow the model to reason
2988.24|4.96|about how things that different scales
2990.079|4.561|are moving with respect to each other
2993.2|3.919|it also has
2994.64|4.16|local neighborhood gather operations
2997.119|3.361|as well as update blocks to keep track
2998.8|3.12|of what's happening within each specific
3000.48|3.359|correlation block
3001.92|3.679|and then finally there's some
3003.839|3.441|flow specific up sampling operators that
3005.599|3.921|were developed
3007.28|4.88|so in contrast to this um we're
3009.52|4.799|basically um we wanted to see how well
3012.16|3.36|perceiver i o would do here and just to
3014.319|3.121|give you a sense of sort of what we were
3015.52|3.92|expecting coming into this we thought
3017.44|3.52|well maybe um so perceiver io is
3019.44|2.72|throwing a lot of the structure away so
3020.96|2.72|we were hoping that we would get some
3022.16|3.199|good results but it would probably
3023.68|3.2|overfit and there's this sort of problem
3025.359|2.96|of the domain transfer that's happening
3026.88|2.88|here but on the other hand
3028.319|3.76|self-attention seems to be a reasonable
3029.76|3.2|way to match this sort of correspondence
3032.079|3.76|thing
3032.96|4.48|what we actually found was that um just
3035.839|3.841|by doing the ver very very simple
3037.44|4.96|preprocessing here so extracting
3039.68|4.32|basically a patch around each pixel
3042.4|3.679|and then using the the standard
3044.0|3.76|perceiver i o architecture we were able
3046.079|5.601|to get state-of-the-art results here and
3047.76|6.24|so this is um this is basically um
3051.68|4.32|was validation of this general approach
3054.0|3.92|of trying to have general purpose
3056.0|4.64|architectures that would transfer over
3057.92|5.199|um and so basically um the with minimal
3060.64|3.439|tuning we're able to get um results that
3063.119|3.281|are beat
3064.079|3.52|both of the um sort of compelling
3066.4|3.28|benchmarks
3067.599|4.24|on sent on both of the cintel
3069.68|4.08|the cental evaluation methods and to get
3071.839|3.361|comparable results on kitty so these are
3073.76|3.52|the standard ones
3075.2|3.6|and we can also sort of visualize what
3077.28|3.279|what happens
3078.8|3.279|when we apply this on real world data so
3080.559|3.361|there's no ground truth here so you you
3082.079|3.601|can't we can't really compare it but
3083.92|3.919|it's still useful to sort of see um how
3085.68|4.0|it moves around and we can see that um
3087.839|4.561|qualitatively it's able to capture a lot
3089.68|4.72|of the fine structure um and to um to
3092.4|3.439|sort of uh get the get the right motion
3094.4|2.8|for the for the things that are that are
3095.839|3.121|very clearly moving in a specific
3097.2|3.919|direction
3098.96|4.48|um we can also sort of it's also i think
3101.119|3.601|informative to look at what happens um
3103.44|3.28|how it managed to represent how it
3104.72|5.52|manages to represent a sort of small
3106.72|5.68|structure is this video playing
3110.24|3.92|yeah we can see it
3112.4|3.52|okay cool so the thing to look at here
3114.16|3.439|is the the fine water droplets that are
3115.92|3.04|sort of flying through the air as that
3117.599|3.041|bird flies by
3118.96|3.28|and because we're decoding at every
3120.64|3.919|single output point
3122.24|4.56|um the architecture is able to represent
3124.559|4.081|those so it's able to capture very very
3126.8|3.039|fine scale segmentation that would be
3128.64|4.88|difficult to capture if you had for
3129.839|3.681|example a convolutional up sampler here
3134.559|5.04|um okay so i'm just gonna oh so the
3136.4|4.88|light light has gone off in this room
3139.599|2.641|um
3141.28|3.12|i'm just going to
3142.24|3.92|also try uh other tasks like depth
3144.4|3.199|estimation because
3146.16|4.72|like it looks like it can also apply
3147.599|5.361|well on that modalities
3150.88|3.84|yeah so um so we haven't published
3152.96|3.599|anything but um some internal results
3154.72|2.639|suggest that it's um that it works just
3156.559|2.721|fine
3157.359|3.361|um they're basically um there don't seem
3159.28|2.72|to be one of the one of the surprising
3160.72|3.04|things um the things that we were a
3162.0|3.2|little bit unsure about was how much
3163.76|3.76|information was going to be contained in
3165.2|3.919|this latent because basically you're
3167.52|2.88|abstracting quite a lot and you're not
3169.119|3.521|it doesn't have any 2d structure
3170.4|3.76|intrinsically um but it does seem like
3172.64|2.88|this um
3174.16|3.84|it seems to be able to represent things
3175.52|4.0|quite well and this um these these sorts
3178.0|4.079|of decoding mechanisms do you seem to be
3179.52|2.559|able to do that
3183.839|2.641|um so i'm just going to interest in this
3185.28|4.559|interest of time i'm going to i'm going
3186.48|5.28|to skip ahead to the conclusion
3189.839|3.121|i had one question with respect to the
3191.76|5.52|metrics that you've shared for the
3192.96|6.48|optical flow the number yeah so like the
3197.28|4.16|in the table it was like central final
3199.44|4.399|clean and kitty were these different
3201.44|4.159|data sets or different metrics like same
3203.839|4.321|metric for different data sets or like
3205.599|3.841|these are three different metrics
3208.16|3.6|yeah so these are three different data
3209.44|4.72|sets so um sintel clean and centel final
3211.76|5.28|are basically two um they're two ways of
3214.16|4.8|doing the final rendering for cintel um
3217.04|3.84|in in all cases these are these methods
3218.96|3.84|are trained just on the autoflow data
3220.88|4.32|set so they're they're trained on this
3222.8|3.92|sort of general purpose um kind of uh
3225.2|2.96|wacky synthetic
3226.72|2.879|motion data set and then we're
3228.16|3.679|evaluation we're evaluating on these
3229.599|4.72|different domains without fine-tuning
3231.839|2.48|okay
3235.599|3.841|yeah the flow has quite the data sets
3237.92|3.28|are quite small so it's it's generally
3239.44|4.24|even problematic to fine-tune
3241.2|2.48|uh thank you
3245.599|5.201|okay so just to summarize all right what
3248.079|5.121|was the ground truth to find the uh
3250.8|4.4|endpoint error
3253.2|3.76|uh yeah so the um the way this works is
3255.2|4.24|um sintel um
3256.96|5.28|is a computer it's it's basically a
3259.44|4.8|relatively high quality uh cgi movie um
3262.24|3.52|that was basically open source and so
3264.24|3.119|they actually have the ground truth so
3265.76|4.0|if you if you know the ground truth 3d
3267.359|4.24|um state you can compute the the the
3269.76|3.92|pixel um correspondence from from the
3271.599|4.081|frame so that's what's used on cintel
3273.68|3.439|and then kitty they basically have um
3275.68|3.6|they have a like a
3277.119|3.68|lidar sensor that's used to figure out
3279.28|2.64|the depth of all points and then they
3280.799|3.121|then they they compute the
3281.92|3.84|correspondences so the ground truth is
3283.92|4.159|actually the ground truth optical flow
3285.76|4.4|um but in general it's hard to get dense
3288.079|6.321|optical flow um it's very expensive to
3290.16|4.24|collect it great thanks
3296.64|4.56|okay so the um so basically um just to
3298.72|4.399|summarize so the um perceivers are
3301.2|3.52|attention-based architectures that scale
3303.119|3.121|linearly and work as drop-in
3304.72|3.52|replacements on for transformers on a
3306.24|3.28|variety of settings they also seem to be
3308.24|2.96|able to um
3309.52|3.279|to achieve results that are um
3311.2|3.68|comparable at least in performance with
3312.799|3.681|um with models that rely on 2d
3314.88|2.88|convolutions but of course there is a
3316.48|3.92|trade-off here and so it's good to be
3317.76|5.039|very aware of this of generality versus
3320.4|4.32|versus speed in specific domains and so
3322.799|4.241|as was pointed out in um in settings
3324.72|3.44|where you can use 2d convolutions it's
3327.04|3.2|certainly good to have them in the in
3328.16|4.56|the loop
3330.24|4.4|it's basically a unified architecture
3332.72|3.68|that allows joint modeling of
3334.64|3.12|different of different modalities of
3336.4|2.8|different sizes
3337.76|2.799|um and
3339.2|2.879|basically
3340.559|3.361|overall it seems to be a quite flexible
3342.079|2.641|architecture that's able to produce a
3343.92|2.639|state of the art or near
3344.72|5.04|state-of-the-art results on a variety of
3346.559|5.04|different domains um and um there's in
3349.76|3.2|the two papers we look at a number of
3351.599|3.841|other domains that i didn't talk about
3352.96|4.159|including 3d point cloud modeling um
3355.44|3.679|replacing the transformer that's used in
3357.119|3.281|the in the starcraft um
3359.119|3.921|in the sort of starcraft behavioral
3360.4|4.32|cloning agent and a couple of others um
3363.04|3.36|so this does we we have a lot of
3364.72|3.28|evidence that this this general approach
3366.4|2.719|seems to work broadly and you know
3368.0|2.48|there's there's a lot of things we still
3369.119|3.521|haven't tried so we're very interested
3370.48|4.4|in pushing this um and you know always
3372.64|4.959|always open for suggestions and um and
3374.88|4.8|so forth um so we're relying on a large
3377.599|3.2|um a large body of uh related work
3379.68|2.879|because we're sort of drawing from a lot
3380.799|4.0|of different areas here so here's some
3382.559|4.56|highlights um and then i just wanted to
3384.799|4.241|thank my uh my my co-authors um on this
3387.119|3.521|work
3389.04|3.84|and of course i'm happy to happy to talk
3390.64|2.24|more
3393.44|4.8|thanks drew
3395.44|5.28|yeah thanks a lot thanks
3398.24|4.16|uh so one question i had is like uh
3400.72|3.52|so what do you think is like the future
3402.4|3.439|of like uh like perceiver like models
3404.24|2.559|like uh do you think like these are
3405.839|3.201|going to
3406.799|4.161|like being used more in like the sort of
3409.04|5.6|like the transform transformer community
3410.96|5.839|to replace like con and channel duster
3414.64|4.56|yeah so the um i think um
3416.799|4.241|broadly speaking i i think it's um
3419.2|3.599|i think of perceivers now as sort of
3421.04|3.759|because um we can we know how to adapt
3422.799|3.441|them pretty well to um to sort of
3424.799|2.641|domains where we don't have a great idea
3426.24|3.68|of the right way to structure an
3427.44|5.04|architecture an inductive bias so i
3429.92|4.879|think that's um that's one of the really
3432.48|4.0|strong cases for it so settings in which
3434.799|3.921|you don't really know what the right way
3436.48|4.8|to structure a problem is um i also
3438.72|4.48|think um these uh these these kinds of
3441.28|4.24|approaches can be used in conjunction
3443.2|5.04|with confnets for sort of um things that
3445.52|5.44|are as domain agnostic as needed
3448.24|5.2|um but i think so multi-modal and um and
3450.96|4.32|new domains is really the um that's the
3453.44|3.28|real that's where this these are obvious
3455.28|2.64|choices
3456.72|2.72|also like what do you think are the
3457.92|3.52|current bottlenecks with this and if you
3459.44|3.359|don't mind like uh if you can disclose
3461.44|4.08|like what is what are you working on
3462.799|4.641|towards next with this stuff
3465.52|4.24|uh so i can't i can't talk about too
3467.44|4.24|many deals about that but um
3469.76|3.28|but um the
3471.68|2.879|a couple of domains
3473.04|4.16|so one we don't really have a great
3474.559|5.361|handle on how to use them on sort of
3477.2|4.399|small small scale data so data where um
3479.92|3.199|where
3481.599|3.041|you don't have um you don't have the
3483.119|3.521|data to sort of recover the inductive
3484.64|4.0|bias so this is this is i think a really
3486.64|3.439|important area um the other thing that
3488.64|2.88|we um that we haven't sort of talked
3490.079|2.881|about here but you you could probably
3491.52|2.64|imagine that we'd be thinking about
3492.96|3.04|would be how to train on multiple
3494.16|4.159|modalities or sort of multiple things at
3496.0|3.599|the same time so um so right now all of
3498.319|5.04|these architectures are sort of trained
3499.599|4.96|in in isolation um but but um there are
3503.359|3.041|a lot of opportunities for sort of
3504.559|3.361|figuring out how to pose problems
3506.4|3.12|together and use a single architecture
3507.92|3.84|on all of them
3509.52|3.76|got it also sure if you tried but can
3511.76|3.039|you also use this for like tabular data
3513.28|2.4|stuff
3514.799|3.441|yeah
3515.68|5.36|um so so um effectively the architecture
3518.24|4.16|treats um any input data as tabular data
3521.04|4.079|so i think that's that's exactly the
3522.4|2.719|right way to think about it
3525.44|3.6|sounds good yeah thanks to the top i
3527.04|3.519|will open my general questions for the
3529.04|5.16|students
3530.559|3.641|so i'll start the recording