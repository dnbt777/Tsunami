start_time|end_time|text
1.44|2.72| Yeah, hi, and welcome back, everyone. I hope you had a nice
4.2|4.16| first lecture day. And remember when I mentioned that snow is
8.36|3.16| awesome. If you look outside, there's a whole lot of new snow
11.52|4.2| outside. But anyways, so today, I'm going to talk about the
15.72|3.56| supervised learning workflow in a little bit more detail. Last
19.52|3.04| lecture day, I talked about machine learning, and the three
22.56|3.22| categories of machine learning. Now I want to provide some more
25.78|2.72| details about the supervised learning workflow. And then I
28.5|4.58| will also cover some of the necessary notation and jargon
33.08|3.04| regarding machine learning that we will be needing for the
36.12|3.24| remainder of this course. So just laying some groundwork, how
39.36|4.08| we define a training set and what mathematical symbols we use
43.44|4.44| and some terms that we will be using. However, I'm trying to
47.88|3.0| keep things a little bit short this time, because yeah, as
50.88|3.08| you've seen in the previous lecture day, there are lots of
53.96|2.6| topics I want to cover this semester. So I don't want to go
56.56|3.08| into too much technical details that are not very interesting
59.64|3.36| for each topic. So I try to keep things a bit short. And then
63.56|4.48| with that, I hope we will be able to tackle all the projects
68.04|3.84| that we are topics that I have in mind for this course. So
71.88|3.32| that without wasting too much more time, let me get started
75.2|1.68| with supervised learning workflow.
78.16|2.6| Alright, now let me talk a little bit more about the
80.88|3.64| supervised learning workflow. And yeah, we will be using
84.52|3.76| supervised learning a lot in the next couple of weeks. So just to
88.52|4.64| briefly outline how supervised learning works. So supervised
93.16|3.4| learning is, like you remember from the previous videos, the
96.56|4.36| process of regression or classification. So there are
100.92|4.6| essentially two steps. One is the training step. So we train
105.52|3.08| a machine learning model. And the second step is the
108.6|3.36| inference step. But before we get to the inference step, let
111.96|4.72| me talk about the training step first. So imagine you have a
116.72|4.12| training data set. And your task is in this case, let's say
120.84|4.44| classification, you want to classify something, let's maybe
125.28|4.68| pick a simple example of classifying different flowers.
130.28|8.44| So let's say you have on different flowers. And there
138.72|4.0| might be different flower species, maybe some flowers more
142.72|4.6| like this, and so forth. And you are interested in classifying
147.32|3.44| how or what type of flower it is based on an image. So you
150.76|3.48| collected multiple flower images, that's your training
154.24|4.08| data set. And you also have an expert consulted an expert to
158.32|5.68| provide you with the labels. So it could be for example, let me
164.08|4.0| think that's, let's say this is an iris flower, this is a rose
168.08|4.24| and yeah, the third one would be let's say a sunflower or
172.32|6.28| something like that. So you have these labels, these are your
182.16|4.44| labels that you want to predict. And the flowers, the pictures,
186.64|6.64| the pictures of the flowers, these are your observations. So
193.28|2.88| you're collected, maybe 1000s of those, this is your training
196.16|3.92| data set. And in traditional machine learning, what you would
200.08|5.36| do is you would extract some features. So usually, traditional
205.44|2.96| machine learning algorithms don't work very well on image
208.4|4.56| data. So you would extract some features. And here again, you
212.96|5.08| would need a domain expert. And having someone someone's opinion
218.04|2.62| like what could be a good feature, you can think about it.
220.66|3.7| But also, usually, it's good to consult an expert who knows a
224.36|3.84| lot about flowers. And it also helps like understanding the
228.2|3.72| data set a little bit. So one might think, okay, um, yeah, what
231.92|3.36| could be a potential feature, it could be maybe, maybe the color
235.56|5.08| of the flower, and maybe the height of the flower. And yeah,
240.64|8.74| other aspects on the number of leaves, and so forth. So there
249.38|2.18| might be different features, you have to think about what could
251.56|2.68| be a good feature. And also, what would be a feature that you
254.24|5.14| can obtain from, let's say, the image data easily. So if you
259.38|3.78| have that, if you have these features, and also the labels,
263.36|4.48| you can then train an algorithm machine learning algorithm to
267.84|4.92| make predictions. So after you're training the model, so in
272.76|6.72| this step, so we say training, we can also say, fitting the
279.48|7.4| model or parameter rising. The model depends on what model we
286.88|4.28| are talking about. Some models are nonparametric models. So we
291.16|3.2| don't really update weight parameters in the model. So in
294.36|3.4| that case, parameter rising would be not a good fit. But
297.76|4.66| yeah, these terms, training, fitting and parameter rising are
302.42|4.06| kind of synonymous in the context of deep learning. Now,
306.48|5.64| let's say we have our model that is our model that was learned
312.12|3.32| from the data, or parameterized based on the training data set.
315.76|4.16| Then the other goal is to make predictions on new flowers,
319.92|3.52| because yeah, the whole goal about developing the model is to
323.44|4.48| use it in some prediction tasks. So for example, if let's say you
327.92|2.36| have a website, you have to develop the website, where
330.28|5.4| people can upload pictures of flowers, and then your pipeline
335.68|5.04| can predict what type of flow it is. So you would have new
340.72|3.64| flowers, new images, that would be a feature extraction step
344.36|4.32| for these flowers. So here, the feature extraction step is
348.68|3.92| exactly the same as during training, because your model has
352.64|3.56| learned to work with this data that it has seen during
356.2|2.96| training. So you have to have the same feature extraction
359.16|3.92| steps here, then you have your model. And then you can use it
363.08|6.84| to predict new labels. And this is nowadays called inference as
369.92|3.2| shown here. So yeah, inference, why inference, it's a little bit
373.12|3.08| different from statistical inference, it's just happens to
376.2|3.56| be called inference. But yeah, it's really like, you can think
379.76|5.24| of it as, as prediction on new data or something like that.
385.6|4.8| All right. So this is the typical supervised learning
390.4|3.96| workflow, training a model, and then using it. However,
395.24|3.56| somewhere in this process, we also want to evaluate how good
398.8|4.04| our model is, before we employ it in the real world. So how do
402.84|4.72| we evaluate the performance of a model. So this is relatively
407.56|2.84| similar to the inference step I've shown you in the previous
410.44|5.16| slide. However, we use a test set for that. So the test set.
415.6|6.12| Set here, it looks like the training set, but it is usually
421.72|2.88| independent from the training set. So if you have a large
424.6|4.36| data set, so let's say you have a large data set, what you
428.96|3.4| usually do is you shuffle the data set and then randomly
432.36|6.4| divided into a large portion for training, let's say, 70%, and a
438.76|6.68| smaller portion for testing, let's say 30%. Usually, there's
445.44|5.24| a third split. Let me write this down. So this is training, but
450.68|5.32| this is also only an approximate number. 30% for testing, you can
456.0|2.4| maybe also it depends really on the data set size, we will talk
458.4|3.0| more about that. But you can also just make this a little
461.4|6.4| bit smaller, let's say 20%. And then make this maybe, I don't
467.8|4.16| know, let's say, let's keep it at 70%. And then there could be a
471.96|5.76| third data set here, that's 10%. And that is the validation
477.72|4.8| set that we use for tuning a model. But yeah, we will talk
482.52|2.76| more about that later when we also see our first code
485.28|5.44| examples. So for now, consider this test set. And this test set
490.76|2.24| here looks very similar to the training set, we have
493.24|6.48| observations and labels. And now what we do though is, so we have
499.72|4.44| this step here, which is like the inference step. I showed you
504.16|7.32| in the previous slide. So what's going on here is the same as I
511.48|3.92| have here on the right side, the inference step, the same, same
515.4|6.64| step. But yeah, what we do now is we have these known labels. So
522.04|4.32| we separate from the test set observations and labels, we keep
526.36|5.4| them separately. So we use our labels. Here, we withhold them
531.76|3.12| from the model, because there is no training right now. And then
534.88|3.88| we use the observations as we treat them as new observations,
539.0|6.8| we pretend they are new. So we pretend these are new labels.
546.28|4.04| Then we do our feature extraction step, give the data
550.32|3.28| to the model. And the model makes the predictions. So we
553.6|3.96| have now two sets of labels. One are the known labels, we know
557.56|2.8| them because we had them in the test set. They are sometimes
560.36|9.92| also called ground truth data. So that is also sometimes they
570.28|3.12| are called ground truth data. And we compare these known
573.4|3.64| labels to the predicted labels. And then we can count the number
577.04|4.28| of times often our model makes a correct prediction. And then we
581.32|3.36| can, for example, compute the accuracy if we count the number
584.68|7.2| of correct predictions over the number of total data points in
591.88|8.0| the test set that gives us the accuracy. And similarly, we can
599.88|4.8| compute the error by one minus the accuracy. So it's like the
604.68|6.72| basic workflow of a supervised learning model. Yeah, regarding
611.4|5.04| the data regarding the flowers. So I also wanted to briefly
616.44|5.52| discuss the difference between structured and unstructured data.
622.36|6.08| So students who have taken statistics 451, the introduction
629.4|3.84| to machine learning. In this class, we mainly worked with
633.24|3.44| structured data. So in this class, we won't be working with
636.68|4.48| structured data, except for some basic examples. So a structured
641.16|6.8| data set is, you can think of it as a tabular data set, or a
647.96|4.48| data set that yet it looks like a table, essentially. And this is
652.68|6.48| something where you have the data set organized as follows,
659.16|8.64| where the columns are your features. And the rows are your
667.8|8.16| observations. So let me go back a step. So this is a table you
675.96|5.2| may get during this feature extraction step. So this is
681.16|3.6| something a human has to do, or you can also automate it in
684.76|3.52| certain points. But imagine the original data, you can also
688.28|3.28| the original data would look like an image. So the original
691.56|3.44| data is the flower. So you can observe it either in the real
695.0|2.56| world, or you can take a picture of the flower. And then as a
697.56|4.0| human, you can use a ruler and then make the measurements
701.56|6.4| about these petal and sepal leaves. So sepal and petal are
707.96|5.72| these leaves here. And then you can measure how long they are
713.68|4.0| and how wide they are. So here I have a table of the sepal
717.68|3.68| length, sepal width, petal length and petal width, either
721.4|2.08| yeah, from an image, I mean, from image would be a bit hard
723.48|2.36| because it's not three dimensional, but let's say an
725.84|3.52| observation in the real world. So this could be then your
729.36|3.8| tabular data set here, these would be your four features, we
733.16|4.36| have four features here, on the right hand side, this is the
737.84|3.44| label that we want to predict included it here in the same
741.28|5.52| table. This would be an example of a structured data set. In
746.8|5.76| contrast, an unstructured data set would be the raw data, for
752.56|3.84| example, this image here. So this would be an unstructured
756.4|4.52| data set. So let me write this down unstructured. Sometimes we
760.92|6.08| also just call it the raw data. So you can actually extract this
767.04|3.64| structured data set from the unstructured data set. But yeah,
770.68|3.04| it's not always very simple. Because for example, sometimes
773.72|2.52| you can automate it here, it might be hard to automate it,
776.24|3.0| you have some have to have some human helping with that, like,
779.6|2.64| maybe even taking the floor taking a ruler and making
782.24|4.96| measurements on structured data is something where we use
788.56|5.0| traditional machine learning and unstructured data is something
793.56|6.0| where we can use deep learning. Because deep learning has
799.56|3.96| internally a feature extraction step, it's implicitly doing
803.52|4.36| feature extraction for us. The downside is, of course, we need
807.92|4.48| much more data. For example, here, this iris data set only
812.4|5.16| has 150 flower examples. And this is sufficient for regular
817.56|2.4| machine learning algorithms for traditional machine learning
819.96|3.2| algorithms such as random forests, you can easily get
823.16|4.12| something like a 99% accuracy with a random forest on this
827.28|4.92| data set. If you want to get 99% performance with deep learning
832.2|4.32| on a flower species prediction task, you would at least I would
836.52|4.4| say, there are some papers I can maybe link later, but I would
840.92|4.6| say at least 10,000 images of these flowers to get, let's say
845.56|6.52| within the 90% accuracy. So this is a three class prediction
852.08|3.52| problem. So it would be requiring much more data and
856.0|4.24| not in every scenario, you have such a large data set. So I'm
860.24|3.4| currently also working on a collaboration where we analyze
863.66|3.7| videos. So we classify different videos. And yeah, one limitation
867.36|3.44| is that we only have 1000 videos. So the videos are
870.8|3.52| actually from YouTube. But the problem is the labels, the
874.32|3.24| labels is here on what's kind of costly, because you would have
877.56|4.24| to have a human looking at these video videos to provide the
881.8|4.8| labels. So it's not always possible to find people to watch
886.6|2.8| long videos to provide these annotations that would be very
889.4|3.24| intensive. So sometimes, you have to make the trade off. Okay,
892.64|3.76| um, I can use deep learning, but I need a large data set. So if
896.4|2.72| you have a lot of labels available, then it's feasible.
899.32|3.72| But sometimes you don't and then using a structured data set is
903.04|5.08| maybe not a bad idea. Because it's simpler, in a sense. Okay,
908.24|5.0| so here's a nice also summary. I found in this book, it's a nice
913.24|3.16| cartoon, illustrating the difference between the
916.4|3.46| structured and unstructured workflow, where you have
919.88|5.44| traditional machine learning with this deep learning. So here
925.32|5.92| on the left hand side, this is the workflow for for deep
931.24|3.68| learning, essentially, where you have the data, and then you
934.96|4.8| throw it into the network, it's like a black box. And then the
939.76|4.96| output is some prediction. So if you get the reference here 42,
944.72|3.76| if you know the joke, maybe post in Piazza, it's actually, I'm
948.48|5.76| just curious how many people nowadays know what the number
954.28|5.2| 42 refers to, it's kind of a insider joke. Anyways, so yeah,
959.48|5.2| and on the right hand side, this is the traditional workflow
964.68|3.44| where you have a human extracting the feature from the
968.12|4.64| data. So you have these hand crafted features that you then
972.76|2.76| provide to the machine learning system, and then do the
975.52|4.04| prediction. So it's essentially highlighting the difference
979.56|9.88| between the unstructured and structured workflow, or data
989.44|4.8| sets. So the structured data would be this one here in the
994.24|4.56| center where you have the hand crafted features. Yeah, just to
998.8|3.36| overlay it with the example I've just shown you with the flowers.
1002.16|3.84| So on the left hand side, for the deep learning context, you
1006.0|4.52| would just give the model the raw images. And the model will
1010.52|5.72| figure out what features to use. So it will learn certain feature
1016.24|2.84| extractors, we will talk more about this when we talk about
1019.08|12.24| convolutional neural networks later, they would implicitly
1032.44|5.36| learn how to extract features. And in contrast, the machine
1037.8|2.32| learning workflow with a hand crafted features here on the
1040.12|2.88| right hand side, where you have these hand crafted features
1043.0|4.48| such as you're taking these measurements here. Alright, so
1047.48|2.4| yeah, that's just a brief overview of the supervised
1049.88|2.88| learning workflow and how machine learning is different
1052.76|3.64| from deep learning. Next, I want to introduce some of the
1056.44|3.68| necessary notation and jargon. And then I will also show you a
1060.12|17.6| little bit how what type of tools we're using in this class.