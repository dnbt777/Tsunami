start_time|end_time|text
0.64|3.8| All right, let's now take a look at a code example of VGG 16 that
4.44|3.84| are implemented here. I should mention that I don't want to
8.28|4.2| rerun this here from scratch during this video because it
12.48|4.52| took one and a half hours to train it's a large network. So
17.04|3.4| in that way, we will just take a look at the results. So I will
20.48|3.36| of course, share this with you should find the link under the
23.84|5.44| video. Yeah, so what we have here is all the usual imports
29.28|4.32| watermark, torch, torch vision, and so forth. Then my helper
33.6|3.88| files as usual, they are I think identical to what I used to last
37.48|3.44| week, I can't remember making a modification to them. So exactly
40.92|3.2| the same like that we used for Alex net, the only difference
44.12|3.32| here is really that I have a different architecture. So
47.44|3.24| defining our hyper parameter settings on the random seed
50.68|1.76| shouldn't be a hyper parameter, but you have to set it to
52.44|4.16| something. So I'm setting it to 123 batch size to 256. And we're
56.6|3.36| training for 50 epochs. And I was using a GPU for that because
59.96|3.76| otherwise, it took too long. So you could, for instance, run
63.72|4.68| this on Google Collab on the GPU. If you run things on the
68.4|3.96| GPU, this function doesn't really work that well anymore,
72.36|3.36| because I actually cut this from the videos because it was too
75.72|4.8| long. But just to briefly mention why. So when you train
80.52|3.68| things on the GPU, there are different types of algorithms
84.2|2.76| used for convolutions. So there's, of course, the
86.96|3.4| convolution that we talked about in the lecture, but in code,
90.36|3.04| people don't implement it this way, they are usually more
93.4|3.4| efficient approximations of that, like a fast Fourier
96.8|3.52| transform based ones. And depending on what computer you
100.32|4.76| use, and what graphics card you use, different approximation
105.08|3.56| algorithms are used. Although these approximations are pretty
108.64|4.24| good, they are approximating the convolution very, very well.
112.88|3.68| There are tiny differences after the decimal point. And if you
116.56|2.56| have a lot of tiny differences, they can add up and then
119.16|3.8| sometimes you will find that results are different when you
122.96|3.04| run them again, because not only are different algorithms
126.04|4.2| automatically chosen based on the computer, but also when you
130.24|3.24| run it multiple times. So Nvidia is actually running some
133.84|3.84| automatic way to guess which algorithm might be a good choice
137.68|3.6| at a given time. So that is why there are sometimes slight
141.28|3.96| slight differences. It used to that you could set this to a
145.24|3.0| deterministic setting. But for some reason, it complains now
148.24|3.24| that this deterministic setting doesn't really work anymore. But
151.48|2.4| any case, you don't have to worry about that. It's very
153.88|3.48| normal in deep learning that you get different results if you run
157.36|3.28| things again. I mean, they will be slightly different, they will
160.64|2.28| not be very different. It's just like very, very small
162.92|0.52| differences.
164.64|4.84| Any case, let's not worry about this. Okay, so talking about the
169.48|3.04| data set now. So here, we're working with a cipher 10 data
172.52|5.08| set, which is 32 by 32. But yeah, I
179.28|2.76| resize this because VG, if you
184.28|4.52| look at this figure, again, it was originally developed for 224
188.8|4.72| times 234 inputs. And there are just too many layers for small
193.52|2.84| inputs, because you have the size of the layers. And it's at
196.36|3.48| that point, if you have half the input size, you will already
199.84|3.84| have only three by three or four by four layers here. And if you
203.68|3.84| make it even smaller, it would be one by one, or even smaller,
207.52|3.4| if you have here already one by one, and then try to half it. So
210.92|3.2| that way, we can't have inputs that are too small, it actually
214.12|4.2| works with 32 by 32. But the results were not as good. So it
218.32|5.04| was faster, of course. But with this version, where I slightly
223.36|5.08| upscale, I get actually 85% accuracy. So what I'm doing
228.44|5.64| here is I'm upscaling these images from 3232 to 7070. Then I
234.08|5.52| do a slight random crop here. So the random crop is to avoid
239.6|2.32| overfitting and avoid overfitting, but to reduce the
241.92|3.44| overfitting to make it a little bit less sensible or sensitive
245.36|4.12| to exact pixel locations. And then I'm converting it to a
249.48|4.56| tensor, and then normalizing it so that they will the pixels
254.04|3.56| will be centered at zero across the channels, and have a
257.6|4.98| standard deviation of one. So it's the usual procedure. Again,
262.58|3.54| for testing, I don't do any random crop, I'm center cropping.
266.88|4.2| Then the rest is exactly the same that we talked about for
271.08|2.96| Alex net last week. So here's the interesting part. That's
274.04|5.08| the VGG 16 architecture. Yeah, I just had some notes for myself
279.12|3.0| for calculating the padding, but we probably don't need that
282.12|7.2| here. So how I implemented it is in different blocks. So I have
289.32|4.88| one block that is usually the convolutions and then stopped or
294.24|3.28| the final layer in that block is the max pooling layer that
297.52|5.6| reduces the size by half. So these preserve the size, it's
303.12|2.92| the same convolution with the padding such that the input
306.04|4.08| equals the output size, and max pooling reduces the size. And
310.12|3.52| then again, here, this conserves the size, this reduces the size
313.64|7.8| by half because of the stride. Then here, again, we have another
321.44|6.6| block with max pooling, another block, and max pooling, and
328.04|4.44| another block, and max pooling. And then these are what I call
332.48|3.84| my feature extractor layers. And then we have a classifier layer.
336.48|3.4| This is really if I go back to the figure, this is really this
339.88|2.64| last part here in light blue, this is the fully connected
342.52|4.8| part. So here, linear layer, fully connected layer,
347.4|3.48| essentially, another one, and another one. So you have drop
350.88|4.32| out, I should probably get this is one deep dropout version. So
355.2|4.36| if you want to add dropout for other layers, you have to, I
359.56|4.92| would recommend using drop out 2d. Actually, I recall I forgot
364.48|3.36| about that recently. And I used a regular dropout somewhere
367.84|3.36| because I, for some reason, forgot to type 2d. And I was
371.2|7.44| wondering why, why I couldn't notice any difference. All
378.64|5.64| right. Yeah, here, I'm using the caming uniform weights as given
384.28|3.2| here, because that's what was used in the original paper, then
387.48|3.8| I have an adaptive average pooling, which will, in this
391.28|4.44| case, make things equal to the height and width here, so that I
395.72|6.0| chose to be three by three. So because for the linear layer,
401.72|3.76| you have to know the input height and width, because you
405.48|2.92| need to know the number of features, we know always know
408.4|3.56| the number of channels, right, because it's coming from here.
412.12|3.0| But sometimes it's hard to know what's the width and height to
415.12|2.92| compute the number of features. So usually, what we do is we
418.04|3.52| have here the feature map, and then average pooling. And then
421.56|6.44| what we do is we flatten this is essentially a flattening
428.02|2.66| operation. This is essentially the same that you do when you
430.68|5.16| work with multilayer perceptrons and MNIST. So you basically
435.84|6.08| flatten the input, which is a image, you flatten this to be a
441.92|3.6| long vector, that's the same operation here. And for that,
445.52|2.24| you have to know the number of parameters, because you need to
447.76|2.44| know the number of weights right for the multilayer perceptron
450.2|3.28| layer, the linear layer. So how would you get this information
453.48|4.64| here, I'm using adaptive average pooling. So adaptive average
458.12|3.36| pooling is an operation where you can determine the input and
461.48|4.4| output size, and it will either add the strides or the padding
466.0|4.84| such that this dimension will be met. So if the input is so where
470.84|4.76| am I here, if the input to this one is smaller than three by
475.6|3.84| three, it will add padding, if it's larger than three by three,
479.44|4.0| it will not add padding and do some strides to reach that size
483.44|8.4| that we desire. Yeah, and if you don't want to do adaptive edge,
491.88|4.4| average pooling, and you want to know the number of sizes that
496.28|3.4| come out of the last block, for example, one way would of course
499.68|3.68| to be to use the equation that I showed you and just calculated
503.36|4.48| by hand. That is a valid approach that could be a
507.88|3.68| potential exam question. But we don't have an exam anymore. So
511.56|2.84| don't worry about it may be something for the quiz. But in
514.4|4.44| practice, yeah, people would write forward or backward hooks,
518.84|3.2| I think I explained it. So you would use a forward hook here,
522.36|3.68| explain it to you when we talked about the pytorch API. But to be
526.04|3.72| honest, even that is something most people won't do, because
529.76|2.84| it's just too much work to write a hook function. I mean, I
532.6|4.0| wouldn't do it. Simple brute force way would be to just
536.6|3.2| implement print statement temporarily. So what you would
539.8|2.44| do is you would just have something that's lazy way, the
542.24|3.28| lazy but efficient way, something like x dot size,
545.92|6.6| prints the size here of x, then you would run this here, when
552.52|2.08| you do the training, it will output the size, it will
554.6|3.2| probably crash if you don't have the right dimensions. But then
557.8|2.48| you know the size, right, you know the height and width, then
560.44|5.12| and then you can remove it at the desired height and width
565.56|3.56| here. And you're good to go. So in practice, most people, to be
569.12|2.8| honest, are just inserting if you want to know the size, you
571.92|3.88| just import a print statement. And that's how you find out the
575.8|3.72| brute force way. Okay, so this is essentially the VGG
579.52|4.56| architecture. So you can see they are essentially a
584.08|3.92| conversion layers, followed always by max pooling that has
588.0|3.24| the input size, we have many of those, then these classification
591.24|10.24| layers here. Um, yeah. And then we have here the training. So
601.48|4.2| I'm initializing it for 10 classes. If we look back to the
605.68|4.56| slides, it's 1000 because image net, the data set that they
610.24|4.2| used here had 1000 classes, we have cipher 10 with 10 classes
614.44|5.84| only. I use SGD with momentum. And this our learning rate
620.3|3.66| scheduler that reduces the learning hell rate by a factor
623.96|6.36| of 10. So dividing it by 10, if the validation accuracy doesn't
630.32|3.62| improve. So this is just my training script that I used for
633.96|4.72| Alex net two. Alright, so here's then the training the same as
638.68|6.84| with Alex net can say, see, it trains pretty quickly, 35%, 50%,
645.64|3.64| 53% accuracy. So it's slowly climbing up. At some point, it
649.28|3.6| stops around here, it's improving a little bit, but it
652.88|4.1| takes longer, more epochs. So I do that. So it's sometimes, you
656.98|3.58| know, it's very useful to look at this. If you run an expensive
660.56|4.44| network like VGG, it might be taking a few hours, and you
665.02|1.94| probably want to take a look at the beginning, whether it's
666.96|4.6| even worthwhile training at 450 epochs, right. So if you notice
671.56|3.56| that the loss doesn't go down, maybe in the first four epochs
675.12|3.12| or something like that, or you notice the accuracy doesn't
678.24|2.92| improve, then I would just stop the training and maybe change
681.16|2.86| some parameters before you just waste one and a half hours
684.02|3.02| waiting until it finishes. So this is why I'm printing this
687.18|6.34| during the training. There's a tool called tensor board that
693.52|3.6| can create visualizations during training. We are not talking
697.12|2.94| about this in this class, because I think we already have
700.06|2.78| enough tools for you to learn about. So there's already enough
702.84|3.02| code going on. But you're very welcome to check this out. At
705.86|2.9| some point, it's also nice for visualizing things. But yeah,
708.76|3.88| here, I'm trying to keep things simple. So not too many tools at
712.64|4.88| once. Sorry, enough, you have to learn in a way. But at the end,
717.52|3.72| I always find it still helpful to take a look at visualizations
721.24|2.72| here, I have make them of course, with matplotlib, so that
723.96|2.36| you can't see them during training only after training.
727.08|2.12| But yeah, what you can see is the loss goes down pretty
729.2|3.52| nicely. So it kind of converges here after 50 epochs, maybe it
732.72|2.2| would still approve a little bit. But looking at the
734.92|3.76| validation performance here, so in orange, you can see maybe
738.8|2.76| maybe it would go up slightly more, but you can already see
741.84|3.12| after epoch 10, there's a huge amount of overfitting. So to
744.96|3.2| reduce that overfitting, maybe adding some dropout to D might
748.16|2.74| help. You can actually it's maybe a good exercise, you can
750.9|3.78| actually insert a regular dropout. And you will see with
754.68|2.76| the regular dropout that you won't reduce overfitting too
757.44|2.88| much. But if you use dropout to D, that helps actually more
760.36|5.92| with convolution networks. Okay, so this is that. And then here,
766.28|3.52| just the visualization, looking at some examples, you can see
771.08|3.72| most of that looks correct. So P is predicted T is the true
774.8|3.44| label. You can see this one is wrong deer and frog. It's hard
778.24|3.6| to tell. I mean, if you look at this cipher 10 has such a low
781.84|3.12| resolution that even we have difficulties telling what's in
784.96|3.92| these images, I think. Alright, so here's a confusion matrix. So
788.88|4.44| that looks actually interesting, you can see, dog and cat are
793.34|3.94| often misclassified here. And that is kind of reasonable
797.28|3.34| because cats and dogs are both animals. So a cat and a dog are,
800.62|3.14| for example, very different from an airplane. So dog and airplane
803.76|3.32| is rarely confused, whereas dog and cat is more often confused.
807.08|2.52| In the grand scheme of things, that's kind of reasonable, I
809.6|4.24| would say. So you can actually see all the animals. That's very
813.84|3.16| interesting. So you can see all the animals here in this square
817.0|5.68| often. Yeah, misclassified compared to ships and trucks,
822.72|3.28| and like automobiles. So yeah, you have things and then you
826.0|2.92| have the animals animals among each other harder to classify
828.92|3.24| compared to other objects like airplanes and automobiles. All
832.16|4.24| right, so this is VGG 16. Maybe one more thing I have VGG 16
836.4|5.28| standardized, I was just toying around with it to see if proper
841.92|2.96| standardization can improve things, but it didn't turn out
844.88|6.6| to be true. So just to show you the I would say proper way. So
851.76|4.8| scrolling up again, here, I'm just using point 5.5.5.5, which
856.56|4.32| will scale the pixels such that they are between minus one and
860.88|7.88| one, centered at zero. So using point five, but we can actually
868.76|3.96| use the proper standard deviation, we can feature pixel
872.72|5.04| mean by computing them. So here, I just have a function added to
877.76|3.24| it that computes or approximates actually, because it's faster,
881.24|3.88| it approximates the mean and standard deviation for each
885.16|3.56| channel for each color channels, it's the red, green and blue
888.72|4.64| one. So they are around point five. And then here, the standard
893.36|3.6| deviations are point to five, instead of point five, and what
896.96|6.28| I assumed in the previous code. But if I use these proper ones,
903.88|2.92| instead of just using point five, I find that it doesn't
906.8|3.64| really make any difference at all. So performance, I think,
910.44|5.76| was pretty much the same, actually worse 82. Actually,
916.2|2.48| it's an interesting drop here. It's very due to overfitting,
918.76|5.24| more overfitting. Yeah, so but you can see in this case, I
924.0|4.24| didn't gain anything from doing this other standardization.
928.4|3.48| Maybe it's actually training better, though you can see it's
931.88|3.08| dropping more here could be because the schedulers triggered
934.96|3.24| at that point. It doesn't have to be because of choosing the
938.2|2.36| mean and standard deviation could be just coincidence.
941.12|3.1| Alright, so that was a long video, probably. So let me wrap
944.22|2.86| this up. In the next video, we will talk about residual
947.08|2.38| networks, which are a little bit more interesting than just
949.46|24.96| adding more layers to it.