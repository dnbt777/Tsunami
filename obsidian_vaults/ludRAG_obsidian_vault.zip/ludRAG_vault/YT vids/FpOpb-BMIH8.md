start_time|end_time|text
0.0|3.24| Yeah, I want to end this brief history on deep learning with a
3.24|3.78| short video on the current research trends, things that
7.72|3.28| became very popular in the last couple of years. So one thing
11.0|3.24| that became very popular in the last couple of years was self
14.24|3.2| supervised learning. So last lecture, I explained how
17.68|3.92| self supervised learning works in a nutshell. So essentially,
21.6|4.22| it's about leveraging unlabeled data where you create some
25.82|3.02| artificial labels that you can then use for supervised
28.84|2.84| learning. But this is really for data sets where you don't have
31.68|2.84| labels for your target tasks. So you would come up with tasks
34.52|3.88| like, yes, separating an image into individual parts, and then
38.4|3.84| predicting the neighboring parts of an image. So if you have the
42.68|3.76| face of the cat, and then an ear here, and you show the network
46.88|3.36| only the face, the network should predict the prediction
50.24|2.58| of the year, whether it's here, the upper left corner, upper
52.82|3.06| right corner, and so forth. And by that, you teach the network
55.88|5.44| to understand better the object structure of the cat, what a cat
61.76|5.72| looks like. Another thing I saw recently, or last year, a lot
67.48|3.24| was contrastive learning. So this is a form of self
70.72|3.52| supervised learning where you generate two versions of an
74.24|5.6| image. So let's say you have an image of a house. That's maybe
79.84|2.56| not a nice house. But you know what I mean? So it's a house
82.4|4.0| like this. So you feed it to the network here. And then let's say
86.4|3.8| you have the same house that is maybe squeezed, or let's say,
90.32|3.88| rotate it upside down, this house upside down, and you feed
94.2|2.84| it to this image, to this network. So it's the same
97.04|4.8| network, but you feed the image one time in the original
101.84|3.0| position and one in some augmented version. And then the
104.84|3.88| network has to predict whether it's still the same object or
108.72|4.04| not. And so that you train the network to recognize that this
112.8|3.48| upside down house is indeed the same object. But then if you
116.76|2.64| let's say give it something different, let's say you give it
121.96|4.6| a cat image here or something like that, you give the cat
126.56|2.72| image to the network, then it should predict that this is
129.28|3.5| indeed different from the house. So you train the network to also
132.78|4.9| better recognize objects. But here notice you don't have class
137.68|3.84| labels or something, you just create the labels yourself by
142.28|2.6| augmenting this. So if you augment this by rotating it,
144.88|0.96| you know, it's still
147.48|4.28| the same house. So in that way, you created this label for free
151.76|3.16| without having a human to label this data, because you can do
154.92|3.16| this all algorithmically. Of course, this is not the target
158.08|2.72| task, you're probably interested in something else. But this is
160.8|3.84| usually useful for pre training a network before you can find
164.64|3.04| unit to your target data set, it usually helps you're making a
167.68|3.24| network better. But this is something that is beyond the
170.94|3.6| scope of this course, it's more like an advanced topic, or
174.54|2.66| something that is more recent, we won't be using it in this
177.2|3.56| course, it's like an optional topic. But if you're interested,
180.76|4.26| there was a very beginner friendly article by Jeremy
185.02|3.14| Howard, which you can find here, where you can learn a bit more
188.16|2.52| about self supposed learning, you can of course experiment
190.68|4.6| with it in your class project, if you like. Another recent
195.28|3.68| research trend is the focus on graph neural networks for graph
198.96|3.84| structured data. So traditionally, deploying was
202.8|4.48| focused on text data and image data. And nowadays, also people
207.68|3.44| work with graph neural networks, if you have graph structured
211.12|4.76| data, for example, personally, I work with molecules also, like
216.0|3.96| structures of small molecules. And you can also think of them
219.96|4.4| as graphs where you have the atoms connected by the covalent
224.36|4.52| bonds, you can think of it as a graph neural network. And yeah,
228.88|3.48| but I, this is a big topic. And also, this would be a little bit
232.4|3.52| out of the scope of this course. But I found a nice introduction
235.92|3.08| to graph neural networks here. If you're interested, there are
239.0|2.52| so many papers, I don't want to pick a particular one. But I
241.52|3.84| think this is an interesting, beginner friendly introduction
245.36|3.8| to the topic. So it's all kind of related to message passing
249.16|4.72| also. So that would be another interesting thing. Also, a
253.88|5.92| recent trend is the work on large scale language models. So
259.96|4.28| it started like in 2018, where people trained models with 94
264.24|3.12| million parameters. And then they scaled up, you probably
267.36|5.44| heard about GPT two was I think, in 2019. Now there's GPT three
272.8|4.44| with 175 billion parameters. So language models become bigger
277.24|2.08| and bigger and bigger. Of course, there are also some
279.32|4.68| research approaches that focus on keeping things small, like
284.0|4.0| distill bird, it's like a small version of bird. So in that way,
288.0|5.68| people also make smaller versions of existing models. But
294.0|3.72| the trend is somehow going towards these bigger models. Of
297.72|3.2| course, this is something that is really out of reach for most
300.94|2.58| academic researchers, this is something you would do at a big
303.52|3.76| company. I think I forgot the exact numbers. But I think this
307.28|4.52| model just training it back then cost like $500,000 or some
311.8|4.96| crazy amount. So it's something you can only do if you if you
316.76|5.12| work in a very big company. So anyway, so he has also
322.08|3.4| interesting or nice blog post summarizing the research
325.52|3.8| highlights of 2020, focusing mostly on the natural language
329.32|2.64| processing. This is where I also found this image, which I think
331.96|4.32| is based on some other website. But this is also if you're
336.28|3.48| interested in these large scale language models, it would be an
339.76|4.32| interesting read for you. We will be covering actually some
344.08|3.76| of these models at the end of this course, when we talk about
348.04|3.84| transformer models, because they are all based on the transformer
351.88|5.7| architecture. Yeah, and another trend also recently read this
357.58|4.54| paper here was transformers and vision where people now also
362.4|3.18| adopt these transformer architectures to computer
365.58|6.26| vision. So however, this is also really large scale. So here, for
371.84|4.16| example, they say even like an image net, like 40 million
376.0|3.6| images is not enough to train a vision transformer. So it's,
380.24|4.2| it's really something that is mostly out of reach for academic
384.44|2.88| research. And also these transform models, they may work
387.32|4.0| very well on very, very, very large data sets like 500 million
391.32|3.04| images or something. However, for most applications,
394.36|3.0| convolutional networks will still outperform them. There was also
397.36|2.56| recently just a new architecture of convolution networks. So
399.92|3.52| they conversion networks are still status quo, it's still
403.6|2.86| what you would use in practice for computer vision. So it's
406.46|2.06| nothing like it's very experimental. It's nothing that
408.52|3.0| is very close to being competitive with convolution
411.52|3.8| networks on common images. But I just thought it was interesting
415.48|3.88| and worth mentioning where things are going. Alright, so in
419.36|3.4| the next lecture, we will talk about the perceptron algorithm
423.08|3.76| in more detail. And we will have some code examples. In the
426.88|2.96| lecture last week, I mentioned the code examples may come
429.84|2.6| later. But I think it's maybe really useful to introduce it
432.64|3.2| rather than sooner rather sooner than later. So I have an
435.88|3.2| ungraded homework exercise for you, you don't have to submit
439.08|3.36| anything, it's just for yourself. So just to prepare
442.44|4.2| yourself a little bit. So I already posted this in on
446.64|5.88| canvas. But yeah, please really take a look at this as
452.52|2.88| preparation for the other following lectures. It's like an
455.4|4.92| introduction to NumPy, Python and NumPy. So of course, there
460.32|3.72| won't be any questions in homework or exam on NumPy,
464.24|2.62| really specifically, but it really will help you to
466.86|4.22| understand how pytorch works, and how we implement code,
471.24|3.0| because it's really like the linear algebra foundation here.
475.28|2.6| So yeah, if you have questions also about that, please let me
477.88|3.44| know. So it's just like a brief review of NumPy. If you are
481.32|3.64| already familiar with NumPy, you can also skip that. But yeah, I
484.96|3.56| would just recommend taking a look at it and see whether it
488.52|3.56| makes sense to you. If it's all new stuff, you may want to read
492.08|3.32| through it more carefully. Alright, then let me know if you
495.4|4.32| have any questions. And then the next lecture on Thursday will be
499.72|26.0| on the perceptron.