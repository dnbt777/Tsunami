start_time|end_time|text
1.24|3.52| Yeah, hi, everyone. I hope last week's lecture on perceptrons
4.76|3.4| was a nice, easygoing introduction into the overall
8.2|3.32| concept of supervised learning. So but yeah, of course, we want
11.52|3.36| to solve more complex problems, especially in deep learning here
14.88|3.44| in this class. So in this lecture, I'm gonna tell you a
18.32|2.96| little bit more about the linear algebra conventions for deep
21.28|3.56| learning. Because yeah, deep learning kind of heavily relies
24.84|4.12| on basic concepts of linear algebra for making the notation
28.96|2.4| a little bit more convenient, but then also to implement
31.36|3.32| things in code more efficiently. But yeah, no worries, these will
34.68|3.76| be relatively simple, straightforward applications of
38.44|3.52| linear algebra. So here, I just want to lay the groundwork so
41.96|4.56| that we can then later talk about how we represent multi
46.52|3.32| layer neural networks that can solve more complex problems such
49.84|3.56| as the X or problem and many other things like image
53.4|4.36| classification. So yeah, in this lecture, I want to briefly talk
57.76|4.72| about the use of tensors in deep learning, then how we work with
62.52|4.72| pytorch in terms of using or working with tensors. So this
67.24|3.72| will be then the concept of multi dimensional arrays. And
70.96|3.08| then I will talk a little bit about vectors, matrices, and
74.04|3.16| then the concept of broadcasting. So this third
77.2|2.44| section will be particularly about the broadcasting, which
79.64|3.56| makes the work with vectors, matrices and tensors more
83.2|4.6| convenient. Then lastly, I will end this lecture with some
87.8|3.12| notational conventions for neural networks. So there's some
91.08|3.68| little I would say on discrepancy between textbook
95.08|3.6| notations where we have linear transformations and textbooks as
98.68|4.48| the weight vector times the inputs and then in computational
103.24|3.08| tools like pytorch, it's usually the other way around to make
106.32|2.52| things a little more convenient from a computational
108.84|3.44| perspective. So here, I just want to give you an overview. So
112.28|3.52| then things will become easier later on in this lecture when we
115.8|4.16| talk about certain concepts like convolution networks and
119.96|4.68| recurrent networks where these things heavily rely on high
124.64|3.64| dimensional tensors. So but with that, yeah, let me then get
128.28|14.56| started with the first video of this week.