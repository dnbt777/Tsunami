start_time|end_time|text
0.48|2.84| Yeah, hi, everyone. So in the last lecture, we covered
3.36|3.52| multilayer perceptrons. So you are hopefully now able to train
7.12|3.64| deep neural networks. Yeah, that brings us also to the topic of
10.76|3.48| how do we make neural network training better? So how do we
14.28|3.28| produce better models? Last lecture, I talked briefly about
17.56|3.44| the problem of overfitting. And now in this lecture, I want to
21.04|3.92| present you with some techniques to tackle overfitting. So yeah,
24.96|3.64| if you recall last lecture, we talked also about the custom
28.6|4.08| data loaders. And yeah, putting two things together. The first
32.68|3.84| topic I want to talk about today is yeah, augmenting training
36.56|4.8| data points. So in that way, we, there are some capabilities
41.36|4.0| that say that allow us to modify, for example, image data
45.36|3.64| very conveniently in the context of custom data loads. For
49.0|3.36| example, what we can do is we can randomly rotate the image
52.36|2.48| level to the left or to the right. And with that, we can
54.84|4.0| very cheaply reproduce new, new training examples and help the
58.84|3.32| model to become more robust to your small perturbations in the
62.16|4.52| data set. Then, after that, I want to talk about a bag of
66.68|2.56| techniques called regularization. So with
69.28|4.56| regularization, I mean, like, making us reducing overfitting,
73.84|3.96| making the model less sensitive to also small perturbations in
77.8|4.64| the data set. So one technique would be early stopping or
82.44|3.08| stopping the training early. However, I think this is
85.52|2.8| something I wouldn't maybe recommend really in practice
88.32|4.16| anymore, considering the double descent phenomenon that I
92.48|3.16| explained to you in the last lecture. So there are other
95.64|3.0| techniques for regularization that we can use, for example,
98.64|3.68| one is l two regularization. So you've probably already heard
102.32|3.08| about l one and l two regularization in other statistics
105.4|3.16| classes, it's basically shrinking the weights. So you
108.56|2.92| probably have heard of it in the context of lasso regression or
111.48|2.6| rich regression. So in this lecture, I want to show you also
114.08|4.0| that we can use the same concept for neural networks. And then I
118.08|2.88| will introduce maybe one of the most common and popular
120.96|3.48| techniques for regularize regularizing neural networks.
124.44|5.08| And that is called dropout. So in dropout, we randomly drop
129.64|3.64| units in a neural network. So in the hidden layers, and with
133.28|4.8| that we help prevent the network from becoming too reliant on
138.08|3.64| particular neurons. So by randomly dropping some neurons
141.72|4.12| during training, the network will learn to use other neurons
145.84|3.76| or to not rely on particular neurons so much. And that also
149.6|3.92| helps with helps with making the network more robust. Of course,
153.52|2.52| there are many other techniques to improve neural network
156.04|2.4| training. We will talk about this in later lectures, for
158.44|3.6| example, yet different weight initialization schemes, batch
162.04|3.36| normalization, also choosing different optimizers, and so
165.4|3.04| forth. So these are just techniques I'm presenting right
168.44|3.56| now that affect the structure of the neural network, or not the
172.0|4.16| structure, but let's say the the weights. But yeah, later on, we
176.16|5.32| will also use techniques that modify the optimizer, and also
181.52|4.16| affect the normalization of the input samples or hidden layer
185.68|3.98| activations. With that, yeah, let me not make the introduction
189.66|2.26| too long. And let me just get started with the lecture.
191.92|4.84| Now, yeah, one of the goals of this particular lecture is to
196.76|4.96| reduce overfitting. So we haven't talked about this in
201.76|4.16| too much detail. But in the last lecture, I briefly mentioned the
205.92|5.28| bias variance decomposition. So for instance, imagine you have
212.04|4.72| prediction label, let's say our continuous target, why let's
216.92|4.4| consider a regression problem, and some input feature x. So
221.32|4.76| this is essentially the model prediction y. So there might be
226.08|3.76| some true underlying data set, though, that's our function,
229.84|3.8| let's say this is a true function, f of x. But in
233.64|4.32| practice, we only have access to a training data set that has
237.96|4.44| been sampled from the former distribution, for example. And
242.4|3.38| there's usually also some noise. So for instance, the data set
245.78|7.14| that we may have access to is looking like this. And we then
252.92|7.04| usually train a model to get a zero error or 100% accuracy on
259.96|2.92| the training set. But there's usually also some noise in the
262.88|3.96| training set, it doesn't fully represent the or capture the
266.84|3.12| true underlying data, because there's usually some noise. So
269.96|5.8| a model that we might learn could look like this. And yeah,
275.76|4.72| this would be a model that has maybe too much complexity. So in
280.48|2.24| that way, it's maybe too flexible, there's too much
282.72|2.9| variance, because if I would collect a slightly different
285.62|6.22| data set, for example, on, let's consider a data set like this,
292.56|3.72| from the same sample from the same true function from the
296.28|3.04| distribution underlying this function, but there's, let's say
299.32|2.64| a little bit of a different noise. I mean, the noise is the
301.96|2.86| same, it's constant noise. But just due to randomness, the
304.82|2.5| data set, the training data set may look a little bit different.
307.72|5.68| And now let's say the model might look like this. So you
313.4|3.96| can see, these are very different models. Let's say I
317.36|3.12| use the same exact same algorithm. If I do this many,
320.48|5.68| many times, I may end up with many different models. And yeah,
326.16|3.84| this has, we can think of it as a large variance. If I have a
330.0|3.56| lot of these models, though, let's say infinitely many. And I
333.56|3.32| average over these models, I should get though, should get
338.14|2.7| this function here, if I would average over infinitely many
340.86|4.94| models, however, each model itself has a high variance. So
345.8|3.92| in this lecture, we will learn about techniques that can reduce
349.76|4.2| this variance. So for example, instead of this red line that I
353.96|3.08| was showing you, that was relatively complicated, we may
357.4|3.4| learn a simpler model that may look like this, that has
362.24|4.2| smaller or lower variance. For instance, if we also consider
366.44|5.92| the other one, actually, I can't do this way. So also for this
372.36|4.84| one, we can maybe consider a simpler model that is not so
377.24|5.52| exaggerated, like, like this. So these techniques kind of
382.76|2.72| simplify the model. But of course, we want don't want to
385.52|3.52| simplify it too much, because then it might not even fit the
389.04|4.12| training data set well enough anymore. For example, if I make
393.52|4.48| the model too simple, if I constrain it too much, it may
398.08|5.14| end up looking like this. And this might be a model that is
403.24|3.28| too simple, but it really depends. So here, in this case,
406.68|2.8| I can tell it's too simple, because this is more like a
409.48|3.4| quadratic function, the true underlying data, whereas I now
412.88|3.68| have a linear model. So let's say like logistic regression. So
416.56|3.64| there's usually a sweet spot, we want to reduce the variance to
420.44|2.88| reduce overfitting. But then we also don't want to make the
423.32|6.68| model too simple. So there's umbrella term called
430.0|3.88| regularization. So regularization broadly means,
434.68|3.6| yes, the process of adding information or changing the
438.28|4.48| objective function to prevent overfitting. So what I mean by
442.76|3.2| changing the objective function, if you heard about L2
445.96|3.64| normalization, there's usually a constraint that we add to our
449.6|3.6| loss function, we will talk about this in this lecture. So
453.36|4.08| yeah, broadly speaking, it's making changes to the learning
457.44|5.88| process to prevent overfitting. So there are many different
463.32|5.24| techniques for that for having regular rising models or having
468.56|3.64| a regular adding a regular rising effect with a goal to
472.2|3.48| reduce overfitting. So the common techniques that are
475.72|4.32| commonly used as our early stopping l one and two
480.04|4.16| regularization, actually, one is not that common to regularization
484.2|3.38| is a bit more common, but also not that common anymore. In the
487.58|3.3| context of deep learning, because most people usually use
490.88|2.84| a technique called dropout, which we will also talk about
493.72|7.16| today. Yeah, while the traditional definition of
500.92|4.44| regularization is the process of adding information in order to
505.36|4.8| solve an ill post problem, or to prevent overfitting, of course,
510.16|2.48| like with so many other things, machine learning and deep
512.64|4.16| learning have special, I would say altered uses of the same
516.8|3.8| term. So it's always interesting to see how terms get adopted in
520.6|2.64| the context of machine learning. So in the context of machine
523.24|5.24| learning, people also sometimes refer to regularization as any
528.48|3.04| modification one makes to a learning algorithm that is
531.52|3.8| intended to reduce its generalization error, but not its
535.32|5.36| training error. So just wanted to mention that, yeah, the term
540.68|4.08| is, it's kind of related, but not quite the same. So here, we
544.76|3.56| are basically in this lecture interested just in lowering
548.32|6.0| also the generalization error. So the techniques are the topics
554.32|4.0| I wanted to cover here in this lecture, outlined here. So there
558.32|4.0| will be five main topics. One is essentially just an overview of
562.32|2.24| different techniques for improving generalization
564.56|3.64| performance. So I just had a spontaneous brainstorming
568.2|3.32| session and wrote on some of the methods that came to mind,
571.72|2.92| because we can't cover all of them in this course, because
574.64|3.84| there are just too many of them. But they might be useful to you
578.52|2.64| and you are working on your class projects. So I wanted to
581.16|4.08| mention them. And yeah, then we will talk about avoiding
585.24|3.72| overfitting with one or so the first point would be adding more
588.96|4.52| data. And the second point would be by modifying existing data
593.48|4.52| that is also usually very worthwhile. And then yeah, we
598.0|3.32| will talk about reducing the complexity of the model, like
601.32|3.96| are reducing the network capacity, and early stopping. So
605.28|4.12| that means stopping the training process early, when we observe
609.4|3.24| that we have a good validation performance, and further
612.64|4.0| training would make the performance worse. And we will
616.64|4.8| talk about a classic technique called L two regularization,
621.64|2.36| also a little bit about one regularization, although it's
624.0|4.8| less commonly used. And then these are just briefly, these
628.8|3.48| are methods here for modifying the loss function like adding a
632.28|3.88| penalty. And then finally, we will talk about the probably
636.72|4.08| most common method that is currently used in deep learning.
641.0|2.96| I mean, of course, also other methods, but dropout is still
644.08|3.76| one of the most common methods. It's essentially a method for
647.84|3.76| randomly dropping neurons. And we will see how that can help
651.68|2.4| network performance or the neural network training
654.08|2.4| performance and generalization performance.
656.48|3.72| Alright, so then let's get started with this overview. And
660.2|26.28| then we will cover these other topics.