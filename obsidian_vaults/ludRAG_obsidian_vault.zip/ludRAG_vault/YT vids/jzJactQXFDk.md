start_time|end_time|text
0.48|3.98| Alright, let's start by talking about normalizing inputs to
4.46|3.38| improve gradient descent. So essentially, input
7.86|5.3| normalization. Yeah, so this is a just a brief recap why we
13.16|3.44| normalize inputs for gradient descent. We already talked
16.6|2.76| about this a little bit when we talked about gradient descent
19.36|2.6| and stochastic gradient descent, I think that was in lecture
21.96|3.6| five. So yeah, just to recap, why do we normalize on those
25.56|3.9| weights? So that's really to find a good learning rate and to
29.46|4.52| have a I would say more stable training. So suppose for
33.98|4.44| simplicity, we have here shown a surface plot of a convex loss
38.42|6.72| function. So here, this is like a convex function shown here. So
45.18|2.96| usually, when we work with deep neural networks, that's not the
48.14|3.04| case, that's not a convex function anymore. But just for
51.18|3.44| simplicity, assume here, it's convex. And we have, let's say,
54.62|4.24| linear model, let's say linear regression with two weights,
58.86|5.2| just to keep things simple. Ignoring the bias also. Now,
64.38|2.4| technically, when we have something like gradient descent,
66.78|4.08| and this is fully circular, let's say in this lower case
70.86|3.68| here, we would usually take steps perpendicular to these
74.54|4.96| contours. However, when we have stochastic gradient descent,
79.66|3.64| also, these steps won't be perpendicular anymore. And
83.3|4.0| especially, this will be exaggerated. If we have these
87.3|5.1| these elliptical losses, so where we may overshoot in one
92.4|3.5| dimension, so instead of let's say going here, we take a step
95.9|4.24| perpendicular, but instead of stopping here, and then taking
100.14|3.88| this step here, we overshoot and then we go this zigzagging. And
104.02|2.92| then also, if we have stochastic gradient descent, this is even
106.94|6.44| more exaggerated. So why? Why this weird also zigzagging can be
113.38|5.76| amplified is when we have features on different scales. So,
119.46|4.12| for instance, imagine a data set where we have, let's say, I
123.58|4.56| don't know the age of a person from 10 to 50 years, and then
128.14|3.64| let's say the income of a person, let's say from I don't
131.78|6.12| know 10,000 to, let's say 500,000 US dollars or something
137.9|2.84| like that. So these are on vastly different scales, right.
140.74|4.16| And remember how we do gradient descent. So usually, what we do
144.9|3.16| is we have the weight update, let's say weight one, we would
148.06|7.32| update it by weight one minus the partial derivative of the
155.38|4.2| loss with respect to that weight, and then times a
159.58|4.84| learning rate alpha, right. So, in this part, this computation
164.66|4.24| involves usually on x the input itself, for example, it could be
168.9|7.68| on y hat minus y times, let's say x, x one is the input
176.58|4.84| feature. So here, the input feature kind of scales on the
181.42|4.28| whole thing. And then if we have input features on very different
185.7|4.08| scales, then, well, finding a good learning rate would be
189.78|4.56| hard, we would have to choose a learning rate for each weight
194.34|2.64| individually. And that would be a lot of hassle. So for
196.98|11.04| instance, because if we consider now w two, two minus alpha, like
208.02|4.92| this, so let's say, this one and this one, these learning rates,
212.94|3.12| we usually use the same learning rate. And this really only works
216.06|4.0| well if the features are on the same scale, right, because if
220.06|3.24| this one is like 1000 times larger, we may have to use a
223.3|3.96| 1000 times smaller learning rate to get a good behavior. Another
227.26|3.72| thing is also that most optimization algorithms really
230.98|4.56| work well if the features are centered at zero, and have only
235.54|5.48| like a small, small values around zero. One issue is also
241.02|3.52| always when we have very large or very small numbers in the
244.54|3.08| computational context, because then we also have computational
247.62|4.64| instability issues. So one common theme that works pretty
252.26|3.96| well in practice is z score standardization. So people just
256.22|4.72| call it standardization. It's essentially giving your data or
260.94|3.28| features the properties of a standard normal distribution. I
264.22|4.24| mean, the data after applying this won't be normal if it
268.46|2.76| wasn't normal before, but it has the properties of a standard
271.22|4.44| normal distribution, which is zero mean and unit variance. So
275.66|2.88| unit variance is a fancy word for saying that the standard
278.54|5.24| deviation is one or the variance is one. So again, if the data is
283.78|3.28| not normal to begin with, this won't change, this won't really
287.06|2.68| change the distribution how it looks like it's just people say
289.74|2.4| it has the parameters of a normal distribution, because
292.34|6.48| essentially, it will have three, zero mean and unit variance, but
299.18|4.6| just think of it as here as centering the data with
303.82|4.12| standard deviation or variance one. So how it works is for each
307.94|4.68| feature. So let's say this is for a particular data point. So
312.62|5.12| we want to scale data point. I let's say this is like an iris
317.74|4.96| flower, I, we want to scale the J's feature where J might be
322.7|6.48| something like let's say simple length. And how we do that is
329.18|4.92| we subtract the feature mean. So here the feature mean, this
334.1|11.24| would be over, over all flowers. So one over n, right? Let me do
345.34|12.6| this properly here. One, one over n equals one, n and then x,
357.94|7.92| i, j. So we will just compute the mean across this feature.
366.42|4.84| And here we do the same thing for the standard deviation. And
371.26|2.56| this is essentially it this usually helps with a better
373.82|4.08| behavior. So we will then usually have a more elliptical,
378.1|4.64| sorry, a more symmetric loss surface. But again, this only
382.74|3.56| applies really if we have a very simple, generalized linear
386.3|3.6| model, like linear regression, in this case, for example, if we
389.9|3.12| have something else, like a deep neural network, this won't be a
393.02|3.16| convex loss function anymore. But still, it helps to
396.26|3.84| standardize the inputs, it's still recommended in practice.
401.06|4.48| Okay, so this is one way we can standardize the inputs. But now
405.54|3.64| when we talk about deep neural networks, so let's say we have
409.38|4.6| the inputs here x one and x two, and then we have activations a
413.98|3.6| one, a two, three, and then let's say we have two output
417.58|5.2| units, let's call it all one and two. Okay, so previously, on the
422.78|3.52| previous slide, we talked about standardizing these things here,
426.3|5.44| right, so the inputs. Now, what about the activations might also
431.74|3.92| be helpful to standardize the activations that go then into
435.66|5.0| these output into the output layer, right. So that might also
440.66|2.96| be helpful to standardize the activations, the hidden layer
443.62|3.2| activations, because you can really think of these ACS, the
446.86|3.16| activations, you can think of them as the inputs to the next
450.02|3.04| layer, they essentially just like x, except that these are
453.06|3.12| the inputs to the next layer. So in the next video, I want to
456.18|6.4| talk about one technique called batch norm, which is essentially
463.9|4.68| variant of the standardization for standardizing hidden
468.58|4.12| activations, it's coming with a twist, there will be a learnable
472.7|3.28| or two learnable parameters for that. But essentially, you can
475.98|2.24| think of it as your standardization of the hidden
478.22|2.76| layer activations. So that will be the topic of the next
480.98|24.08| video.