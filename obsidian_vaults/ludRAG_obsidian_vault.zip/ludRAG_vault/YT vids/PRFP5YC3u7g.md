start_time|end_time|text
1.12|3.52| Yeah, now that we talked about convolutional networks and the
4.64|3.88| convolution operation, and so forth, we might wonder what is
8.52|2.52| actually going on in a convolution network? What is
11.04|4.64| the convolutional neural network actually learning there? So yeah,
15.68|3.08| we can take a brief look at that from a traditional computer
18.76|3.56| vision perspective. So before convolutional networks were
22.32|5.56| invented, people were designing so called edge detectors, among
27.88|6.08| others. So people were designing filters by hand by thinking
33.96|3.24| about them, like applying, let's say logical thinking, there were
37.2|3.64| like so bull filters, like a vertical edge and horizontal
40.84|3.82| edge detectors, and so forth. And how these work is
44.66|4.26| essentially that someone would define a filter, thinking about
48.92|4.36| what it is doing, and then you can extract certain features
53.32|3.88| from an image using that filter. So here's an example of what I
57.2|5.2| mean. So here, that's an example of a vertical edge detector. And
62.44|5.04| I'm implementing it using an existing convolutional neural
67.48|4.6| network filter here, or layer. So here, you don't have to really
72.08|3.08| worry about the code implementation. I'm just using
75.16|3.68| the code implementation to create these figures. And also
78.84|4.08| in a way to prove that this is actually real, that it's not
82.92|6.24| something I just make up here. So here, let's say we have this
89.16|5.8| vertical edge detector, it's a matrix that consists of a column
95.0|5.32| containing ones, zeros, and a minus one. And then let's say I
100.32|4.48| have an image like that. This is my image where I have these
104.84|7.22| zeros, half zeros and half ones. And my goal is to design a
112.06|3.54| vertical edge detector that can detect that there is an edge
115.6|5.84| here, a transition between dark and bright. Now, when I apply my
121.44|3.36| edge detector here to this image, that's what I'm doing here
124.8|3.32| on the right hand side, I can see the output is this one here.
128.12|4.6| So it has detected that there was an edge. So it detected
132.72|4.8| essentially, this edge here, the transition, the transition
137.52|4.56| between dark and bright. So before convolution networks,
142.08|2.92| people were using these edge detectors yet to detect
145.02|5.3| transitions in an image. So for instance, here, this is the
150.32|3.48| vertical edge detector applied to an image in the MNIST data
153.8|6.28| set. And you can see here, for instance, when we have MNIST
160.08|7.56| data set. So I'm just okay. So here, we have then these
167.64|3.12| detected edges, you can see, I mean, they're not perfectly
170.76|3.18| horizontal or vertical, because it's like a curve, it's maybe
173.94|2.74| not an ideal image, I should have maybe taken the number one
176.68|2.44| or something like that from MNIST. But you can see
179.28|3.32| everywhere else, it's not detecting anything in here,
182.76|2.16| where there's something horizontal. Also, you can see
184.92|3.2| these parts are missing. Of course, in an image like that,
188.12|3.88| it's like a real world image, which is pretty rounded here in
192.0|3.04| the shapes. It's not perfect. But you can see the bigger
195.06|3.94| picture here that people would design like filters to get
199.04|4.56| certain aspects from an image. For instance, here, I have the
203.6|4.32| same edge detector except that is horizontal instead of
207.92|3.12| vertical. So I have a row of ones, zeros, and the minus ones.
211.4|3.92| And here, you can see now that it is detecting these these
215.32|4.92| horizontal edges here, whereas then for some vertical ones
220.24|4.36| here, so these these regions are missing. So this is just like a
224.6|4.04| bigger picture context of, let's say traditional computer vision
228.64|2.76| designing different filters. And of course, these are just very,
231.4|2.08| very, very simple edge detectors, they're more
233.48|5.08| sophisticated ones. But yeah, now going back to the scene, and
238.56|4.48| so how is that related to the scene? And so, in the beginning
243.04|3.72| of this course, I talked about traditional methods and deep
246.76|2.88| learning. And one major difference between deep
249.64|1.84| learning, and let's say traditional machine learning and
251.48|3.84| other methods is that in deep learning, we have this automatic
255.56|3.68| feature extraction. In that sense, you can also think of the
259.24|3.72| CNN as an automatic feature extractor that can actually
262.96|4.88| learn something like an edge detector. Of course, it will not
267.92|2.96| learn exactly that edge detector, it will just learn the
270.88|4.4| edge detector that is best for let's say maximizing prediction
275.28|6.08| accuracy. Yeah, I already showed you this slide in the last
281.36|4.44| video. This is again, Alex net trained on image net. And in the
285.8|3.68| previous slides, I showed you these manual filters like
289.48|3.8| vertical and horizontal edge detectors. And if you look here
293.28|4.04| at figure three, where they plot the 96 convolutional kernels
297.32|3.84| after the first layer, you can see it's actually quite similar.
301.16|2.76| So it's also somehow learning like these diagonal ones,
304.16|4.16| diagonal filters, horizontal filters, vertical filters, and
308.32|4.24| so forth. But then there are also these filters like this one
312.56|3.04| and this one, which are some checkerboard patterns, some are
315.6|4.0| only focused on colors. So you can see really the CNN is
319.6|5.32| learning a kind of complex set of filters here. That, yeah,
324.92|3.8| together can help it with maximizing prediction x
328.76|4.84| accuracy. So in that way, I'm also typically the early layers
333.64|3.8| learn a very simple feature extractors. And then the farther
337.44|3.76| you go in the network, these basically assemble to more
341.2|3.6| complex shapes in the feature maps. So the feature maps in the
344.8|4.04| early layers, they usually detect something like edges. And
348.84|3.44| later, in later layers, usually they detect more complex
352.28|4.92| objects. So there was actually an interesting paper, you're
357.2|3.6| looking at the feature activation maps. And I also
360.8|6.04| should say, as a general method, so if you want to look at what
367.04|5.52| input pixel maximize the loss function. So previously, when we
372.6|4.88| talked about partial derivatives of the loss, we looked at the
377.48|2.72| partial derivatives of the loss with respect to, let's say the
380.2|4.2| weight input, and we use that to update the model, right, so
384.4|5.44| update the weights. So in that way, we wanted to know how do I
389.84|4.24| have to change my weight. So to minimize the loss, you can
394.08|6.28| actually do the same thing by looking at the hidden layer
400.36|3.32| activations, or maybe even the inputs, right. So let's say you
403.68|2.76| can do that with the activation, you can see, okay, which
406.44|4.08| activation basically has a high impact on the loss. So what are
410.52|3.36| the gradients here, basically, so in that way, you can also
413.88|3.84| study the activations. And even in the input, you can find in
417.72|3.44| the input, if this is like the input pixels, you can find out
421.16|3.88| which have the highest loss gradients or partial derivatives
425.04|2.24| of the loss with respect to the input. And then you can find out
427.44|4.6| which pixels is the loss most sensitive towards two, or at the
432.04|3.92| end of this video, also show you or give you an article that
435.96|3.28| highlights or explain some of these techniques. In any case,
439.24|4.64| so in this paper here, they also back propagated the activation
443.88|3.28| signal. So they looked at what are the strong activations and
447.16|3.36| back propagated them back to the input images. And then they
450.52|5.72| applied a so called unpooling to map the activations back to the
456.24|4.84| original input dimension. So in a sense, it sounds maybe a
461.08|3.36| little bit convoluted. But in a sense, they were actually
464.44|4.56| looking at what activations What are the large activations in
469.0|2.84| each feature map? And how do they correspond to the input
471.84|5.28| image? So, for instance, they had different layers in the
477.12|4.36| first layer, there were mostly abstract features here. In the
481.48|2.52| second layer, you could see there are, I would say more
484.0|2.72| complex shapes, hard to tell what they are, but a little bit
486.72|2.48| more complex. But then you can see in the third layer of the
489.2|5.0| network, there are more like concrete things emerging like a
494.2|4.4| face suddenly, right from these simple patterns, suddenly, the
498.6|3.52| combination of them emerge and emerges a face or that's maybe
502.12|4.0| an eye and things like that. And these shapes become more and
506.12|6.36| more complex, the later the deeper the network goes. So in
512.48|4.24| that way, these feature maps are mainly face detectors, these
517.36|3.96| eye detectors. And here, it's really hard to tell. But in that
521.32|3.4| sense, the more or the deeper we go in the network, the more
524.72|5.0| complex these shapes that the network can recognize become. So
529.88|4.24| yeah, just another example here, it's from the same paper. So
534.12|4.52| here, again, the first layer is mostly colors and simple edges
538.92|4.24| that get the text and then here in the layer two, it has like
543.16|3.96| these different, more abstract shapes. On the right hand side,
547.12|2.76| these are the original objects, you can see there's an eye here
549.88|8.46| kind of detects that here, layer three. For instance, if we focus
558.34|3.64| here on the car, it can detect this wheel. It's kind of
561.98|4.48| interesting that the network really learns here on these
566.82|2.88| important parts of an image while ignoring also the
569.7|3.6| background. So of course, it depends on what the
573.3|3.72| classification task here is. But if the classification task is,
577.02|3.88| let's say, predict what object it is, say, predict that this is
580.9|3.4| a person, you can see it focuses on the person not on the
584.3|4.84| background here, or here, for instance, that's only mostly the
589.14|4.8| person highlighted here, nothing really in the background. Yeah,
593.94|6.9| here's some more. Okay. Yeah, so here's an article that has a
600.84|6.5| nice summary figure of different approaches for interpreting what
607.34|3.12| the network pays attention to in the input. So in the previous
610.46|2.62| slides, I showed you essentially, the feature map
613.08|5.42| activations here. This is a set of methods for looking at what
618.62|4.4| pixels in the input are most important for making a certain
623.02|4.24| prediction, for instance. So you can ask maybe the question, if I
627.26|5.22| have a cats versus dogs classifier, what is the most
632.48|5.18| important important part in the image to classify a cat versus a
637.66|2.82| dog. And you want to see that it pays maybe attention to the
640.48|4.86| anatomy, like the legs on the shape of the animal, rather than
645.34|2.88| the backgrounds. And that way, using these methods is actually
648.22|4.2| a good sanity check to make sure the network pays attention to
652.42|6.6| salient parts in that image. So yeah, I would say the most, the
659.02|3.6| most traditional methods on the left hand side have been used
662.62|2.92| for a long while. And here are also some more recent ones, I
665.54|2.76| would say actually grad chem is still among the most popular
668.3|3.2| ones. But there are also some modern, more modern ones, which
671.5|6.0| are, I think are producing better results. So looking at
677.5|3.0| this one here, vanilla gradient ascent. So you can also just
680.5|4.02| think of it as decent, it's maybe easier to think about. So
684.54|4.16| what that is, it's that what I mentioned in the beginning of
688.7|4.32| this video where I mentioned instead of computing the partial
693.02|3.32| derivative of the loss with respect to the input weight, to
696.34|3.0| one of the input weights, we would compute it with respect to
699.34|4.06| the input pixels in that image. So that tells us really, how
703.4|3.9| important is a pixel for the loss if we have a network for
707.3|4.2| classification. So here, now, if we look at this, we can see the
711.5|2.44| network, when it does a classification, I actually don't
713.94|3.44| know what type of classification is, I'm just assuming that. So
717.38|3.36| you can see it kind of pays attention to the dog instead of
720.74|2.52| the deck background, which is kind of good. You can see this
723.26|5.52| one guided back propagation, it's a flavor of this vanilla,
728.82|3.16| vanilla gradient descent, except that here, there's a
732.02|3.44| thresholding going on. But yeah, in any case, what you can see
735.46|3.24| here, it highlights better that the network pays attention to
738.88|4.88| the muscle or even the whole head area of the dog. So maybe
743.76|3.9| this is, I'm speculating, but maybe this is a network that is
747.78|3.82| trained to predict or distinguish between different
751.6|4.18| breeds of dogs. So for instance, being more specific than just
755.78|3.08| saying dog, for instance, saying that this is a doorman. So in
758.86|4.62| that way, the network has to also maybe pay special attention
763.48|5.16| to the head area, because the general body, that is something
768.64|2.32| that looks very similar for different types of dogs or
770.96|2.8| breeds of dogs. So in that way, maybe you have to really pay
773.76|3.32| special attention to the head area here, the muzzle and so
777.08|3.32| forth. Yeah, there are other methods, for instance, a smooth
780.4|5.2| grad method and blur integrated gradients. And yeah, you can see
785.6|3.2| they are all somewhat similar, but they are all good methods
788.8|4.28| for essentially looking at what parts of the image, the network
793.08|3.12| pays attention to, which I would recommend in practice, if you
796.2|3.4| work on a bigger project, and your project is on, let's say a
799.6|3.36| classification, it might be a good idea to utilize one of
802.96|3.6| these methods to really look at what your network pays most
806.56|3.56| attention to, at least for a handful of images and so forth,
810.52|2.68| can help sometimes to make sure the network does something that
813.2|5.0| is actually sensible. Alright, so yeah, in the next video, then
818.2|5.0| let me talk about the code implementation. Finally,