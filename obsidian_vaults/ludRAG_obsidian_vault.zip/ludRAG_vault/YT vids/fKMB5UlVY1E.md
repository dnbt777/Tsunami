start_time|end_time|text
5.04|3.8|so welcome everyone to cs25 uh we
7.2|3.8|excited to kick off uh this class this
8.84|4.28|is the fourth iteration uh of the class
11.0|3.839|we're doing uh in the in the previous
13.12|3.64|iterations we had like Andre carpati
14.839|4.721|come last year we also had Jeffrey hint
16.76|4.64|and a bunch of other people um and so we
19.56|3.559|very excited to kick this off uh the
21.4|4.28|purpose of this class is to sort of like
23.119|4.721|have a uh discuss the latest in the
25.68|3.919|field of AI and Transformers and last
27.84|3.32|language models and have all the top
29.599|3.921|research ERS and experts in the field
31.16|4.68|come and be able to directly uh give a
33.52|5.92|talk and discuss their findings and
35.84|7.12|their new ideas uh to students here so
39.44|5.68|that this can be used to uh in their own
42.96|4.32|research or like uh spark new
45.12|7.48|collaborations um so very excited about
47.28|9.24|the class and uh yeah let's kick it
52.6|7.56|off so hi everyone I'm
56.52|6.32|div uh okay so will I'm currently to
60.16|4.44|leave from the PHD program from Stanford
62.84|3.8|um working on a personal AI agent
64.6|4.12|startup called mton uh you can see the
66.64|4.92|Shir um I'm very passionate about
68.72|4.52|robotics agents uh did a lot of like
71.56|3.08|work on on reinforcement learning on a
73.24|3.76|bunch of like State ofart methods on
74.64|4.88|online and offline a uh previously was
77.0|4.52|working with Ian good fellow uh at Apple
79.52|3.12|so that was really fun and just really
81.52|3.0|passionate about Ai and how can you
82.64|4.519|apply that in the real
84.52|4.48|world so guys hey guys I'm Stephen
87.159|3.32|currently a second year of PhD student
89.0|3.04|here at Stanford
90.479|3.521|um so I'll be interning at Nvidia over
92.04|4.359|the summer and previously I was a master
94.0|4.759|student at carig melon and an undergrad
96.399|4.201|at the University of waterl in Canada uh
98.759|3.801|so my research interests broadly hover
100.6|4.64|around NLP and working with language and
102.56|4.0|text um you know can we work on
105.24|4.4|improving the controlability and
106.56|4.919|reasoning capabilities of um language
109.64|3.32|models and recently I've gotten more
111.479|3.041|into multimodal work as well as
112.96|3.32|interdiciplinary work with psychology
114.52|4.0|and cognitive science I'm trying to
116.28|5.56|bridge the gap between how humans as
118.52|5.48|well as language model learn and reason
121.84|3.8|um and just some for fun you know I'm
124.0|3.96|also the co-founder and co-president of
125.64|6.0|the Stanford Piano Club so if anybody
127.96|3.68|here is interested check us
132.2|5.8|out hi everyone I'm Emily um I am
136.239|4.601|currently an undergrad about to finish
138.0|4.72|up in math and kogai here at Stanford
140.84|4.92|and also doing my masters in computer
142.72|4.519|science I am super interested similarly
145.76|3.52|in the intersection of artificial
147.239|3.561|intelligence and natural intelligence I
149.28|3.08|think questions around Neuroscience
150.8|3.719|philosophy and psychology are really
152.36|3.72|interesting and I've been very lucky to
154.519|4.921|do some really cool research here at
156.08|6.48|Stanford Med uh at NYU and also at CoCo
159.44|5.159|lab where Stephen is working as well uh
162.56|4.2|under Noah Goodman on some computational
164.599|5.481|neuroscience and computational cogn
166.76|5.199|cognitive science work um and currently
170.08|3.879|I am beginning a new line of research
171.959|6.28|with Chris Manning and Chris Potts doing
173.959|4.28|some NLP interpretability research
178.84|6.28|so hello um I'm a first year CS Master
182.44|4.159|student my name is singi um I do
185.12|3.8|research around natural language
186.599|5.161|processing um I did a lot of research in
188.92|5.16|HCI during undergrad at Cornell and I'm
191.76|4.72|currently working on visual language
194.08|4.84|models uh image editors for
196.48|4.8|accessibility and I'm also working with
198.92|4.52|Professor Hari suum monam in the HCI
201.28|4.319|department and I'm also working on
203.44|4.719|establishing consistency and long-term
205.599|6.681|conversations with Professor D Yang at
208.159|7.201|the NLP group um yeah nice to meet you
212.28|5.599|all um so what we hope you guys will
215.36|4.36|learn from this course is a broad idea
217.879|4.881|of you know how exactly Transformers
219.72|5.239|work how they're being applied um around
222.76|4.679|the world Beyond just NLP but other
224.959|4.92|domains as well as applications um some
227.439|4.281|exciting New Directions of research um
229.879|3.44|Innovative techniques and applications
231.72|3.0|especially these days of large language
233.319|4.041|models which have taken the World by
234.72|5.76|storm and any remaining challenges or
237.36|6.0|weaknesses um involving Transformers um
240.48|2.88|and machine learning in
245.599|4.961|general uh cool uh so we can start with
248.879|2.44|uh presenting first like the attention
250.56|3.84|uh
251.319|6.32|timeline um so I'll say initially we
254.4|5.119|used to have this uh pre historic era
257.639|4.201|where we had like very simple like
259.519|3.761|methods for like say language for
261.84|3.4|example so like you had like a lot of
263.28|5.12|like rule based methods you like paring
265.24|5.32|you have like RNN lstms and that all
268.4|4.88|changed I will say in the beginning of
270.56|4.479|around 2014 when people started studying
273.28|3.44|like attention mechanisms and this was
275.039|3.081|around like say initially around images
276.72|3.12|like how like can you adapt like the
278.12|3.6|mechanism of like how attention works in
279.84|3.52|the human brain to like images can you
281.72|4.8|focus on different parts which might be
283.36|5.88|more like Salient or more relevant uh to
286.52|5.239|like a user query or what you care about
289.24|4.959|and um I will say attention exploded in
291.759|4.561|the beginning of 2017 with the paper
294.199|5.041|attention is all you need by Ashish
296.32|4.96|vaswani and L and so that was like when
299.24|3.28|like uh Transformers became mainstream
301.28|2.6|and then people realize okay like this
302.52|2.64|could be like its own really big thing
303.88|4.159|it's a new architecture that you can
305.16|4.879|like use everywhere and after that we
308.039|5.481|saw like explosion of Transformers into
310.039|5.44|NLP uh with like BD gpt3 and then into
313.52|3.679|also other fields so now you're seeing
315.479|3.44|that in like Vision like protein folding
317.199|4.921|with Alpha fold you have all the video
318.919|4.761|models like Sora you have like uh like
322.12|3.079|like basically everything right now is
323.68|3.519|basically some combination of like
325.199|5.041|attention and some other like
327.199|6.481|architectures like diffusion for example
330.24|5.64|and uh this has now led to the start of
333.68|3.68|this generative AI era where now you
335.88|2.68|have like all this like powerful models
337.36|3.2|which are like billion parameters
338.56|4.16|trillion parameters and then you can use
340.56|3.359|this for a lot of different applications
342.72|3.52|and so if you think about it even like
343.919|4.4|one year before uh a was very limited to
346.24|3.44|the lab and now you can say like AI has
348.319|4.32|escaped from the lab it's now finding
349.68|5.0|real life real world applications and
352.639|4.641|it's uh has started to become
354.68|3.92|predominant so if you think what can if
357.28|3.039|you look at the trajectory right now
358.6|3.08|it's like sort of like we on this upward
360.319|2.6|Trend where we started like this and now
361.68|2.84|it's just growing faster and faster and
362.919|3.041|faster and every month there's just like
364.52|2.6|so many new models coming out it's like
365.96|2.84|every day there's just like so many new
367.12|3.32|things happening and so it's going to be
368.8|3.36|very exciting to see like even like a
370.44|3.879|year or two years from now how
372.16|3.759|everything changes and uh the society
374.319|2.761|will sort of be led by like this
375.919|3.12|revolutions that are happening in the
377.08|3.64|field of AI so a lot of things are going
379.039|3.401|to change on maybe like how we interact
380.72|4.08|with technology how we do things in
382.44|3.72|daily life how we have assistants and I
384.8|2.839|think a lot of that will just come from
386.16|4.72|like uh the things we might be studying
387.639|3.241|in this class
392.72|3.879|awesome thanks St for going through the
394.24|4.16|timeline um so generally the field of
396.599|3.241|natural language processing which is
398.4|4.68|kind of what Transformers were
399.84|4.96|originally um invented for um the
403.08|3.399|fundamental discrete nature of text
404.8|3.56|makes many things difficult for example
406.479|4.201|data augmentation is more difficult you
408.36|4.0|can't just for example Flip Flip it like
410.68|3.76|you flip an image change the pixel
412.36|4.839|values of it it's not that simple um
414.44|4.36|text is very precise one wrong word
417.199|3.161|changes the entire meaning of a sentence
418.8|3.6|or makes a complet
420.36|3.679|nonsensical um and there's also
422.4|3.6|potential for long context length as
424.039|4.081|well as memories um like if you're CH
426.0|3.68|chatting with chat gbt over U many
428.12|3.4|different conversations being able to
429.68|4.28|learn and store all of that information
431.52|4.48|is a big challenge um and some of the
433.96|4.12|weaknesses of earlier models which we'll
436.0|4.68|get to later um short context length
438.08|4.16|linear reasoning um as well as the fact
440.68|4.28|that many of the earli approaches did
442.24|4.6|not adapt based on context um so
444.96|4.84|actually I'll be running through briefly
446.84|3.639|um how NLP has progressed uh throughout
449.8|4.36|the
450.479|7.201|years um actually sun will be doing
454.16|4.719|that yeah so um I just while preparing
457.68|4.48|this I found this like really
458.879|5.401|interesting thing this is 1966 um this
462.16|4.879|was like the earliest chat bot called
464.28|5.199|Alisa and it wasn't like a real AI but
467.039|5.241|it was more of like simulating patterns
469.479|4.72|of text and words and sort of um
472.28|3.44|creating an illusion that this chatot
474.199|3.12|was sort of understanding what you were
475.72|4.199|saying so these were like the earliest
477.319|4.481|forms of NLP and they were most rule
479.919|3.72|based approaches where you're trying to
481.8|4.399|understand the patterns in like
483.639|5.56|sentences um patterns in way words are
486.199|5.481|said um and these were like the earliest
489.199|6.521|like linguistic foundations um Le about
491.68|6.0|semantic parsing um yeah then we needed
495.72|4.759|to go on to understand more deeper
497.68|4.32|meanings within words um so we come up
500.479|4.881|with things called word embeddings which
502.0|5.639|are vector representations of words and
505.36|4.239|they gave us different um semantic
507.639|3.921|meanings in words that we weren't able
509.599|4.0|to understand before so we create Vector
511.56|4.88|representations words that are similar
513.599|4.761|appear closer together in this Vector
516.44|4.039|space and we're able to learn different
518.36|4.159|types of meanings and then these like
520.479|4.761|examples I have here are like word to
522.519|4.401|VEC love bird Elmo um these are
525.24|3.68|different types of word embeddings and
526.92|4.32|they sort of evolve so word two vectors
528.92|4.2|like a local context um word embedding
531.24|4.719|where glove we get like Global context
533.12|5.08|within documents um so now that we have
535.959|4.521|ways to represent words into Vector
538.2|5.4|representations now we can turn them
540.48|4.72|into put them into our models and do
543.6|4.4|different types of tasks such as like
545.2|4.52|question answering or text summarization
548.0|3.64|or sentence completion machine
549.72|4.44|translation and we develop different
551.64|6.0|types of models that are able to do that
554.16|6.04|so here we have like RNN lstms um that
557.64|5.12|are used for different translation tasks
560.2|4.759|and so since we have our models the Now
562.76|4.84|new challenge becomes sort of to
564.959|5.241|understand how we can do these tasks
567.6|4.359|better right so thanks s ke so um she
570.2|4.84|talked about sequence to sequence models
571.959|4.921|those are um naturally just inefficient
575.04|3.52|as well as ineffective for many ways um
576.88|4.959|you cannot parallelize because it
578.56|5.16|depends on recurrence um it relies on um
581.839|3.881|maintaining a hidden context Vector of
583.72|3.52|all the previous words um and their
585.72|3.52|information um so you couldn't
587.24|4.2|parallelize and it was inefficient and
589.24|4.32|not very effective so this led to what
591.44|4.68|is now known as attention as well as
593.56|5.279|Transformers um so as the word kind of
596.12|4.6|infers attention means um being able to
598.839|4.601|focus attention to different parts of
600.72|4.08|something in this case a piece of text
603.44|3.04|so this is done by using a set of
604.8|3.52|parameters called weights um that
606.48|4.16|basically determine how much attention
608.32|4.959|to should be paid to each input at each
610.64|4.36|time step um and they're computed using
613.279|3.601|a combination of the input as well as
615.0|3.48|the current hidden state of the model so
616.88|3.72|this will become clearer as I go through
618.48|5.76|the slides um but you here you have an
620.6|5.679|example um where this an example of self
624.24|4.039|attention um if we're currently at the
626.279|3.721|word it um we want to know how much
628.279|3.521|attention do we want to play to all of
630.0|4.12|the other words within our input
631.8|4.76|sequence um and again this will become
634.12|4.64|clear as I explain more um so the
636.56|4.399|attention mechanism relies mainly on
638.76|4.28|these three things called queries keys
640.959|4.12|and values um so I tried to come up with
643.04|4.16|a good analogy for this um and it's
645.079|3.44|basically like a library system so let's
647.2|3.759|say your query is something you're
648.519|4.88|looking for um for example a specific
650.959|5.12|topic like I want books about uh how to
653.399|4.321|cook a pizza um and each book in the
656.079|4.721|library let's say has a key that helps
657.72|5.359|identify it um for example um this book
660.8|4.96|is about cooking this book is about um
663.079|5.56|Transformers this book is about um movie
665.76|4.759|stars and so forth um and what you do is
668.639|3.481|you can kind of look you can match
670.519|4.32|between your query as well as each of
672.12|5.0|these keys or summaries um to figure out
674.839|3.56|which books um give you the most
677.12|2.719|information you need and that
678.399|3.68|information is the value which you're
679.839|4.601|trying to ret retrieve but here in
682.079|4.801|attention we do a soft match match we're
684.44|6.28|not trying to retrieve one book we want
686.88|6.12|to see um what is the distri ution of
690.72|3.919|relevance or importance across all books
693.0|3.279|for example this book might be the most
694.639|3.601|relevant I should spend most of my time
696.279|4.161|on this one might be the second most
698.24|4.56|relevant I I'll spend a mediocre amount
700.44|4.28|of time on and then book three is less
702.8|4.8|relevant and so forth so attention is
704.72|4.6|basically a soft match between um
707.6|3.88|finding what's most relevant which is
709.32|4.639|contained in those values and hence the
711.48|5.32|equation where you multiply queries by
713.959|4.921|Keys um and then you multiply that by
716.8|4.44|the values to get your final um
718.88|2.36|attention
721.48|3.799|and here's also just a visualization
723.12|4.399|from The illustr Illustrated Transformer
725.279|4.12|about how self attention Works um so
727.519|5.32|you're basically able to embed your
729.399|5.721|input words um into vectors and then for
732.839|4.081|each of these you initialize a query key
735.12|5.159|as well as value Matrix and these are
736.92|6.039|learned as the um Transformers trained
740.279|4.481|and you're able to multiply your inputs
742.959|4.481|by these queries keys and values to get
744.76|5.24|these final query key and value matrices
747.44|3.959|um which is then used um again as shown
750.0|3.8|in the formula to calculate the final
751.399|5.321|attention score and the way the
753.8|5.0|Transformer works is it basically um
756.72|3.76|uses attention but in a way that's
758.8|4.88|called multi-head attention as in we do
760.48|6.44|attention several times because um since
763.68|5.56|each one is randomly initialized um our
766.92|3.56|goal is that each head of attention will
769.24|3.599|learn
770.48|5.479|something useful but different from the
772.839|4.961|other heads so this allows you to get um
775.959|4.56|a more sort of overarching
777.8|5.88|representation of potentially relevant
780.519|5.081|information from your text um and you'll
783.68|4.12|see these blocks are repeated end times
785.6|3.799|the point there is once the multi-ad
787.8|3.2|attention is calculated so the attention
789.399|3.88|scores are calculated from each head
791.0|4.6|they're then concatenated and then this
793.279|3.92|process is repeated several times to
795.6|3.72|potentially learn things like
797.199|4.721|hierarchical um features and more
799.32|4.56|in-depth sort of information and here
801.92|4.44|you'll see um this Transformer diagram
803.88|5.0|has both an encoder and decoder um this
806.36|5.64|is for something for example uh T5 or
808.88|5.399|bar which is an encoder decoder model um
812.0|4.44|used for things like machine translation
814.279|5.521|on the other hand things like GPT or
816.44|5.56|chat GPT that's um simply a decoder only
819.8|4.52|because there's no sour there's no
822.0|4.04|second source of input text um compared
824.32|3.68|to something like machine translation
826.04|3.96|where you have a sentence in English
828.0|3.399|which you want to translate to French uh
830.0|2.839|when you're decoding for an auto
831.399|4.521|regressive left to right language model
832.839|5.0|like Chad GPT um it basically only has
835.92|3.24|what has been generated so far um so
837.839|3.68|that's kind of the difference between
839.16|4.28|decoder only and encoder decoder um
841.519|3.921|Transformers and the way multi-ad
843.44|4.24|attention works is you initialize a
845.44|4.44|different set of querious keys and
847.68|4.64|values um these different matrices per
849.88|4.319|head which are all learned separately um
852.32|3.92|as you train and back propagate across
854.199|5.521|tons of data so again you embed each
856.24|6.08|word split these into um heads so
859.72|4.119|separate um matrices and then you kind
862.32|3.48|of multiply those together to get the
863.839|4.281|final resulting attentions which are
865.8|3.92|then um concatenated and multiplied by
868.12|3.04|final weight Matrix
869.72|2.919|um and then there's some linear layer
871.16|3.679|and then some soft Maxs to help you
872.639|4.88|predict uh the next token for example um
874.839|4.92|so that's the general gist of how um
877.519|3.88|sort of multi-head attention Works um if
879.759|2.961|you want a more in-depth sort of
881.399|3.0|description of this there's lots of
882.72|4.84|resources online as well as other
884.399|5.321|courses um and I'll briefly touch upon
887.56|4.88|like I said cross attention so here you
889.72|4.4|have actually an input sequence and of
892.44|4.639|different output sequence for example
894.12|5.76|translating from French to English so
897.079|5.361|here when you're decoding your output
899.88|5.879|your English translated text there's two
902.44|6.56|sources of attention one is from the
905.759|5.921|encoder so the entire sort of encoded um
909.0|4.199|hidden state of the input um and that's
911.68|3.64|called cross attention because it's
913.199|4.601|between two separate pieces of text your
915.32|5.8|queries here are your current
917.8|5.839|decoded um outputs and your keys and
921.12|4.24|values actually come from the encoder
923.639|4.12|but there's a second source of attention
925.36|4.399|which is self attention um between the
927.759|4.161|decoded words themselves so there the
929.759|4.161|queries keys and values are entirely
931.92|3.919|from the decoded side and these types of
933.92|4.0|architectures combine both types of
935.839|4.281|attention compared to like I said a
937.92|7.32|decoder only model which would only have
940.12|8.44|self attention among um its own um
945.24|6.68|tokens and so um how exactly are
948.56|5.92|Transformers compared compared with rnns
951.92|4.599|um so rnns recur neural networks um they
954.48|3.839|had issues representing longrange
956.519|4.041|dependencies um there were issues with
958.319|4.32|gritty and vanish as well as explosion
960.56|3.68|since you're concatenating all of this
962.639|4.12|information into one single hidden
964.24|4.48|Vector um this leads to a lot of issues
966.759|3.52|potentially um there were a large number
968.72|3.2|of training steps involved and like I
970.279|3.961|said you can't parallelize because it's
971.92|4.159|sequential and relies on recurrence
974.24|4.24|whereas Transformers can model long
976.079|5.12|range dependencies there's no gradient
978.48|5.2|Vanishing or exploding problem and it
981.199|4.401|can be parallelized um for example um to
983.68|4.079|take more advantage of things like GPU
985.6|3.52|compute um so overall it's much more
987.759|3.801|efficient and also much more more
989.12|4.92|effective um at representing language
991.56|5.56|and hence why it's um one of the most
994.04|5.68|popular deep learning architectures uh
997.12|4.639|today so large language models are
999.72|4.119|basically a scaled up version of this
1001.759|4.281|Transformer architecture up to millions
1003.839|4.24|or billions of parameters and parameters
1006.04|4.279|here are basically nodes in the neural
1008.079|4.32|network they're typically trained on
1010.319|3.76|massive amounts of General Text data for
1012.399|3.841|example mining a bunch of text from
1014.079|4.601|Wikipedia Reddit and so forth um
1016.24|3.2|typically there are processes to filter
1018.68|2.56|um
1019.44|3.6|this text for example get getting rid of
1021.24|3.88|not safe for work things and general
1023.04|3.639|quality filters and the training
1025.12|3.439|objective is typically next token
1026.679|4.601|prediction so again it's to predict the
1028.559|5.24|next token or the most probable next
1031.28|3.84|token given all of the previous tokens
1033.799|4.0|so again this is how the autor
1035.12|5.199|regressive left to right um architecture
1037.799|4.081|like Chad GPT works and it's also been
1040.319|3.321|shown that they have emerging abilities
1041.88|3.919|at they scale up which Emily will talk
1043.64|4.48|about um however they have heavy
1045.799|4.361|computational cost training these huge
1048.12|4.439|networks on tons of data takes a lot of
1050.16|4.16|time money and gpus and it's also led to
1052.559|3.761|the fact that this can only be done
1054.32|4.68|effectively at big companies which have
1056.32|4.56|um these resources as well as money and
1059.0|3.96|what's happened now is we have very
1060.88|5.28|general models which you can use and
1062.96|5.959|plug in play um and use them on very um
1066.16|4.36|on different tasks um without needing to
1068.919|3.521|sort of retrain them using things like
1070.52|4.76|in context learning transfer learning as
1072.44|4.68|well as prompting um I know Emily will
1075.28|5.44|talk about emergent
1077.12|5.439|abilities yeah so so um I guess a
1080.72|3.959|natural question for why our language
1082.559|4.721|models work so well is what happens when
1084.679|4.641|you scale up and as we've seen in the
1087.28|4.04|past there's been this big trend of
1089.32|3.719|investing more money into our compute
1091.32|3.68|making our models larger and larger and
1093.039|3.721|larger and actually we have seen some
1095.0|3.84|really cool things come out of it right
1096.76|4.64|which we have now termed emergent
1098.84|5.199|abilities um we can call emergent
1101.4|4.88|abilities an ability an ability that is
1104.039|5.161|present in a smaller in a larger model
1106.28|4.48|but not in a smaller one um and I think
1109.2|3.92|the thing that is most interesting about
1110.76|4.36|this is emergent abilities are very
1113.12|4.32|unpredictable it's not necessarily like
1115.12|3.88|we have a scaling law that we just keep
1117.44|5.04|training and training and training this
1119.0|5.159|model and we can sort of say oh at this
1122.48|3.52|at this training step we'll have this
1124.159|3.801|ability to do this really cool thing
1126.0|3.72|it's actually something more like it's
1127.96|3.92|kind of random and then at this
1129.72|4.88|threshold that is pretty difficult or
1131.88|4.48|impossible to predict it just improves
1134.6|4.84|and we call that a phase
1136.36|5.72|transition and this is a figure Tak by a
1139.44|5.16|paper authored by uh a speaker we'll
1142.08|4.8|have next week uh Jason we who I'm very
1144.6|3.72|excited to hear from and he did this
1146.88|4.64|really cool research project with a
1148.32|5.32|bunch of other people uh sort of uh
1151.52|3.6|characterizing and exhibiting a lot of
1153.64|4.48|the emergent abilities that you can
1155.12|5.64|notice in different models so here we
1158.12|6.0|have five different models and a lot of
1160.76|5.76|different uh common tasks that we test
1164.12|4.76|language models on to see uh what their
1166.52|4.92|abilities are and so for example
1168.88|5.36|complicated arithmetic or um
1171.44|4.56|transliteration being able to uh tell if
1174.24|4.0|someone is telling the truth other
1176.0|4.72|things like this and as you can notice
1178.24|4.84|on this figure we have these eight
1180.72|4.88|graphs and there's sort of this like
1183.08|6.079|very obvious Spike it's not necessarily
1185.6|5.88|like this gradual increase um in
1189.159|5.361|accuracy and so that is sort of what we
1191.48|5.28|can term that phase
1194.52|4.399|transition and currently there's very
1196.76|4.919|few explanations for why these abilities
1198.919|4.841|emerge um evaluation metrics used to
1201.679|5.041|measure these abilities don't fully
1203.76|5.0|explain why they emerge um and an
1206.72|4.48|interesting research paper that came out
1208.76|4.56|recently by some researchers at Stanford
1211.2|5.719|actually claimed that maybe emergent
1213.32|6.359|abilities of llms are non-existent maybe
1216.919|5.441|it's more so the uh researcher's choice
1219.679|4.841|of metric being nonlinear rather than
1222.36|4.96|fundamental changes in the model
1224.52|7.32|responding to the
1227.32|7.52|scale and so a natural question um is is
1231.84|4.8|scaling sort of the best thing to do is
1234.84|4.44|it the only thing to do is it the most
1236.64|5.279|significant way that we can improve our
1239.28|4.48|models um and so while scaling is a
1241.919|4.0|factor in these emergent abilities it is
1243.76|4.88|not the only Factor um especially in
1245.919|4.921|smaller models we have new architectures
1248.64|4.399|uh higher quality data and improved
1250.84|3.88|training procedures that could
1253.039|4.081|potentially uh bring about these
1254.72|4.0|emergent abilities on smaller models and
1257.12|3.96|so these present a lot of interesting
1258.72|4.12|research directions um including
1261.08|4.12|improving few shot prompting abilities
1262.84|4.88|as we've seen before um through other
1265.2|4.28|methods and theoretical and interpret
1267.72|5.64|interpretability research computational
1269.48|6.52|Linguistics work um and yeah other
1273.36|4.4|directions and so as some interesting
1276.0|4.039|questions do you believe that emergent
1277.76|5.56|abilities will continue to arise with
1280.039|5.321|more scale um is there like maybe once
1283.32|4.44|we get to some crazy number of
1285.36|3.88|parameters then our language models will
1287.76|3.399|suddenly be able to think on their own
1289.24|3.88|and do all sorts of cool things or is
1291.159|3.681|there some sort of limit um what are
1293.12|5.039|your thoughts on this current trend of
1294.84|6.52|larger models and more data um it should
1298.159|5.161|we uh is this a good direction larger
1301.36|4.439|models obviously mean more money more
1303.32|5.76|compute and less democra less
1305.799|5.161|democratization of uh AI research and
1309.08|4.0|thoughts on retrieval based or retrieval
1310.96|3.28|augmented systems compared to Simply
1313.08|3.199|learning everything within the
1314.24|5.039|parameters of the model so lots of cool
1316.279|3.0|directions
1321.36|3.96|um yeah so we have some quick
1323.2|3.959|introductions on reinforcement learning
1325.32|4.479|from Human feedback I think a lot of you
1327.159|4.441|might already know um so um
1329.799|3.961|reinforcement learning from Human
1331.6|4.48|feedback is a technique to train large
1333.76|4.96|language models um usually you give
1336.08|4.88|human like humans to outputs of the
1338.72|4.319|language model ask them what they prefer
1340.96|4.16|we select the one they prefer and feed
1343.039|5.081|it back into the model to train a more
1345.12|5.32|human aligned model recently there has
1348.12|3.6|been more more um since like
1350.44|3.08|reinforcement learning from Human
1351.72|3.64|feedback has its limitations you need
1353.52|3.72|quality human feedback you need good
1355.36|4.52|rewards you need a good policy it's a
1357.24|6.28|very complicated training process um a
1359.88|5.84|recent paper DPO uh uses just uh
1363.52|4.6|preference data and non- preference data
1365.72|5.6|and feeds that into the language model
1368.12|6.039|uh to uh and it's a much more faster
1371.32|6.239|algorithm to train these language models
1374.159|7.76|um so quick introduction to gbt um we
1377.559|6.201|have GPT which is fine-tuned on GPT 3.5
1381.919|3.88|we have like a diagram of the different
1383.76|6.039|types of GPT models that have been
1385.799|6.281|released and GPT 4 is um the next
1389.799|5.401|version and it's supervised on a large
1392.08|5.88|training data set with rhf like the apis
1395.2|5.4|of text ofy also have been trained on
1397.96|5.64|rhf um then we have Gemini which is
1400.6|5.559|Gemini uh uh a model which was like
1403.6|5.48|basically Google's AI from Bart now is
1406.159|4.961|Gemini and um when it was release there
1409.08|5.479|was like a big hype because it performed
1411.12|6.52|much better on than chat PT on like uh
1414.559|4.72|30 out of the 32 academic Benchmark so
1417.64|3.919|there was a lot of excitement around
1419.279|4.041|this and now as people have used it
1421.559|3.401|there have been different like we
1423.32|3.599|realize that different models are good
1424.96|3.4|for different types of tasks one
1426.919|3.841|interesting thing is that Gemini is
1428.36|4.679|trained on thee model which is the
1430.76|4.2|mixture of experts model where we have a
1433.039|4.0|bunch of smaller neural networks that
1434.96|4.199|are known as experts and are trained and
1437.039|3.64|capable of handling different things so
1439.159|3.041|we could have one neural network that's
1440.679|3.88|really good at pulling images from the
1442.2|4.24|web one good at pulling like text and
1444.559|3.921|then we have our final gated Network
1446.44|5.479|which predicts which response is the
1448.48|3.439|best suited to address the
1452.76|5.48|request right so now that takes us to
1455.2|4.959|where we are right now um so AI um
1458.24|4.28|especially NLP large language models
1460.159|5.161|have taken off um like shanki said
1462.52|4.039|things like gbd4 Gemini and so forth um
1465.32|3.959|a lot of things involving human
1466.559|3.961|alignment and interaction such as RL HF
1469.279|3.52|um there's more work now on trying to
1470.52|3.96|control the toxicity bias as well as
1472.799|3.24|ethical concerns um involving these
1474.48|4.36|models especially as more and more
1476.039|5.88|people um gain access to them um things
1478.84|6.48|like chb there's also more use in unique
1481.919|6.041|applications things like audio uh music
1485.32|5.4|neuro um Neuroscience biology and so
1487.96|5.36|forth um we'll have some slides briefly
1490.72|4.52|uh touching on those but these things
1493.32|4.32|are mainly touched upon um by our
1495.24|4.76|speakers and there's also um diffusion
1497.64|3.759|models um a separate class of models
1500.0|3.2|although now there's a diffusion
1501.399|4.28|Transformer where they replace the unet
1503.2|4.56|backbone in the diffusion model with the
1505.679|3.841|Transformer architecture uh which works
1507.76|4.08|better for things like text to video
1509.52|3.44|generation for example Sora um uses the
1511.84|5.52|diffusion
1512.96|7.04|Transformer um so what's next um so as
1517.36|6.559|we see um the use of Transformers and
1520.0|6.12|machine learning um get more and more um
1523.919|5.681|prominent throughout the world um it's
1526.12|5.48|very exciting but also scary um so it
1529.6|4.64|can enable a lot more applications
1531.6|4.36|things like very generalist agents
1534.24|4.439|longer video understanding as well as
1535.96|4.92|generation maybe in 10 five 10 years we
1538.679|5.641|can generate a whole Netflix series um
1540.88|6.24|by just putting in a prompt or an um a
1544.32|5.32|um description of the um show we want to
1547.12|5.439|watch um things like incredibly long
1549.64|4.88|sequence modeling which Gemini um um I
1552.559|4.761|think now it is able to handle they
1554.52|5.32|claim um a million tokens for more um so
1557.32|4.44|we'll see if that can further scale up
1559.84|4.04|um which is very exciting things like
1561.76|4.519|very domain specific Foundation models
1563.88|5.44|things like having a doctor GPT lawyer
1566.279|6.321|GPT any sort of GPT for any use case or
1569.32|5.32|application you might want and also
1572.6|3.72|other potential real world impacts
1574.64|4.44|personalized education as well as
1576.32|4.76|tutoring systems Advanced Healthcare um
1579.08|4.44|Diagnostics environmental monitoring and
1581.08|4.839|so forth um real time multilingual
1583.52|4.879|communication um you go to China Japan
1585.919|4.961|or something um real time you're able to
1588.399|4.4|interact with everyone um as well as
1590.88|4.12|interactive entertainment and gaming
1592.799|5.24|potentially we can have more realistic
1595.0|5.0|NPCs um um which are run by Transformers
1598.039|4.961|as well as
1600.0|5.159|Ai and so what's missing um you know
1603.0|4.24|this is Buzz word you know AGI ASI
1605.159|4.921|artificial general intelligence or super
1607.24|4.64|intelligence um so what's really missing
1610.08|3.4|to get there um these are some of the
1611.88|3.88|things that we we thought might be the
1613.48|4.48|case firstly is reducing computation
1615.76|4.399|complexity um as these models and data
1617.96|4.599|sets scale up it'll become even more
1620.159|4.841|costly and difficult to train um so we
1622.559|4.72|need a way to reduce that enhance human
1625.0|4.24|controllability of these models the
1627.279|4.321|alignment of language models potentially
1629.24|5.2|with the human brain adaptive learning
1631.6|5.48|and generalization across um even more
1634.44|4.56|domains multi- sensory multimodal
1637.08|3.4|embodiment um this will allow it to
1639.0|3.6|learn things like intuitive physics and
1640.48|3.76|common sense that humans are able to but
1642.6|3.559|since these models especially language
1644.24|5.439|models are trained purely on text they
1646.159|5.321|don't actually have sort of intuitive or
1649.679|3.761|um human-like understanding of the real
1651.48|5.76|world since all they've seen is
1653.44|5.28|text um infinite or external memory um
1657.24|3.72|as well as self-improvement and
1658.72|4.28|self-reflection capabilities like humans
1660.96|4.92|we're able to continuously learn and
1663.0|6.039|improve ourselves um complete autonomy
1665.88|5.159|and long Horizon decision making
1669.039|3.801|emotional intelligence and social
1671.039|6.041|understanding as well as of course
1672.84|4.24|ethical reasoning and value alignment
1678.64|2.56|uh
1679.399|4.88|cool
1681.2|6.04|um okay cool uh so let's get to some of
1684.279|3.961|the interesting uh Parts about LMS so
1687.24|2.2|there's like a lot of applications
1688.24|3.799|you're already starting to see in the
1689.44|3.719|real world like the chat GPT is one of
1692.039|3.601|the biggest examples it's like the
1693.159|4.601|fastest growing consumer app in history
1695.64|3.72|uh which just like went like really
1697.76|3.24|viral everyone started using it just
1699.36|3.039|caused like this like like wow like
1701.0|3.0|people know like AI exists in the real
1702.399|2.88|world because before that was just like
1704.0|3.799|like say like people like us who are
1705.279|3.721|like at Sanford who are using Ai and and
1707.799|2.681|then like a lot of the people in the
1709.0|2.799|world were like okay like what is even
1710.48|2.6|AI but like when they got their first
1711.799|2.561|experience with like chat gbd they were
1713.08|4.839|like okay like okay like this thing
1714.36|5.199|actually works we believe in that and
1717.919|2.961|now we are starting to see a lot of this
1719.559|3.321|in like different applications like
1720.88|4.76|speeches something where you have a lot
1722.88|4.12|of this new models like whisper you also
1725.64|3.12|have this like 11 Labs bunch of things
1727.0|4.159|that are happening music is a big
1728.76|4.08|industry image like images and videos
1731.159|2.961|are also like starting to transform so
1732.84|2.679|we can imagine maybe 5 years from now
1734.12|3.12|all Hollywood movies might be produced
1735.519|3.0|by like video models you might not even
1737.24|4.24|need actors for example you might just
1738.519|4.361|have like fake actors and like you spend
1741.48|2.72|like billions of dollars just like going
1742.88|2.919|to different like Parts in the world and
1744.2|3.719|like shooting scenes but that can all be
1745.799|3.641|just in video model right so like
1747.919|2.561|something like Sora and like what what's
1749.44|2.479|happening right now I think that's going
1750.48|4.64|to be game changing because like that's
1751.919|4.76|how uh movie production advertisement uh
1755.12|3.2|all of like like social media will be
1756.679|4.201|driven by
1758.32|4.719|that and it's already fascinating to
1760.88|4.84|just see how realistic all this images
1763.039|5.081|and the videos look um it's almost like
1765.72|3.76|better than like human artist quality so
1768.12|3.679|so it's it's getting like a very
1769.48|4.88|interesting uh and very hard to also
1771.799|5.72|distinguish like what's real and what's
1774.36|4.48|fake um and one uh very interesting
1777.519|3.481|application will be like when you can
1778.84|5.559|take these models and embody them in the
1781.0|5.32|real world so for an example if you have
1784.399|3.801|some games like Minecraft for example
1786.32|3.68|where you can have a AI that can play
1788.2|3.599|the game and then we already starting to
1790.0|3.72|see that where like uh there's a lot of
1791.799|5.12|work where like uh you have a AI That's
1793.72|4.36|like uh masquerading as a human and
1796.919|3.081|actually able to go and win the game
1798.08|3.16|game so there's like a lot of like those
1800.0|3.039|stuff that's happening real time and
1801.24|3.039|people are doing that and it's actually
1803.039|2.961|we are reaching like some level of
1804.279|4.161|superh human performance there in
1806.0|4.399|virtual games similarly in the robotics
1808.44|4.32|um it's very exciting to see like once
1810.399|3.801|you can apply AI in the physical world
1812.76|2.639|you can just enable like so many like
1814.2|3.199|applications you can have physical
1815.399|3.28|helpers in your homes industry so on and
1817.399|2.76|there's almost a race for building the
1818.679|3.561|humanoid robots that's going on right
1820.159|3.4|now so if you look at what uh Tesla is
1822.24|3.36|doing what like this company called
1823.559|3.401|figur is doing so everyone's like really
1825.6|3.919|excited about okay like can we go and
1826.96|4.0|build this like physical helpers that uh
1829.519|5.601|can go and help you with a lot of
1830.96|7.28|different things um in PH in real
1835.12|6.159|life and so definitely like lot of uh
1838.24|5.039|fun research and like uh um applications
1841.279|6.28|have already been applied by open AI
1843.279|5.52|deep mind uh meta and so on and uh we
1847.559|4.201|have also seen a lot of interesting
1848.799|5.76|applications in biology and Healthcare
1851.76|4.48|so Google introduced this mpom model
1854.559|3.881|last year we actually had the first
1856.24|5.0|author of the work give or talk
1858.44|4.32|in the last iteration of the course and
1861.24|3.0|this is very interesting because this is
1862.76|3.84|a transformal model that can be applied
1864.24|3.919|for actual medical applications Google
1866.6|4.0|is right now deploying this in actual
1868.159|4.801|hospitals for analyzing like uh the
1870.6|7.439|patient Health Data a lot of history
1872.96|5.079|medical diagnosis uh cancer detection so
1881.36|5.64|on so now we'll touch briefly upon some
1884.12|4.88|of the remaining um some of the recent
1887.0|3.88|Trends in terms terms of Transformers
1889.0|3.96|research as well as potentially
1890.88|4.0|remaining weaknesses and challenges so
1892.96|4.24|as I explained earlier you know a large
1894.88|4.759|amount of data compute and cost to train
1897.2|3.56|over weeks or months thousands of gpus
1899.639|3.601|and now there's this thing called the
1900.76|4.759|baby LM challenge can we train llms
1903.24|5.399|using similar amounts of text Data baby
1905.519|5.801|exposed to um while Growing Up So
1908.639|5.0|essentially um comparing sort of llms
1911.32|5.199|and humans is one aspect of my own
1913.639|4.961|research and um I believe that children
1916.519|4.081|are different um we learn very
1918.6|3.679|differently as humans compared to llms
1920.6|3.24|they do statistical learning this
1922.279|4.081|requires a large amount of data to
1923.84|4.28|actually learn statistical relations um
1926.36|4.24|between words in order to get things
1928.12|4.64|like abstraction generalization and
1930.6|4.919|reasoning capabilities whereas human
1932.76|6.2|learns humans learn in more structured
1935.519|5.241|probably smarter ways um we may um for
1938.96|4.079|example learn in more compositional or
1940.76|5.24|hierarchical sort of maners uh which
1943.039|5.401|will allow us to learn these things more
1946.0|5.32|easily and so one of my professors
1948.44|4.199|Michael Frank he made this tweet um
1951.32|3.76|showing how you know there's this like
1952.639|4.601|four four four to five orders of input
1955.08|4.4|magnitude difference between human and
1957.24|4.52|llm emergence of many behaviors and this
1959.48|4.4|is magnitude not time so like 10,000 up
1961.76|4.68|to millions of times as much data
1963.88|4.32|required for llms compared to humans
1966.44|4.599|this may be to the fact that humans have
1968.2|4.68|innate knowledge um this relates to
1971.039|3.64|priors basically you know when we're
1972.88|3.639|born maybe due to Evolution we already
1974.679|4.161|have some fundamental capabilities built
1976.519|4.52|into our brains second is multimodal
1978.84|4.48|grounding we don't just learn from text
1981.039|5.24|we learn from interacting with the world
1983.32|6.079|with other people through vision smell
1986.279|5.36|things we can hear see feel and touch
1989.399|3.921|the third is active social learning um
1991.639|4.52|we learn while Growing Up by talking to
1993.32|4.76|our parents teachers other children this
1996.159|4.201|is not just basic things but even things
1998.08|4.479|like values human values to treat others
2000.36|4.48|with kindness and so forth um and this
2002.559|4.441|is not something that uh llm is really
2004.84|4.6|exposed to um when it's trained on just
2007.0|6.2|large amounts of text
2009.44|6.32|data um kind of related is um this trend
2013.2|4.199|towards smaller open source models
2015.76|4.919|potentially things we can even run on
2017.399|5.0|our everyday devices um for example
2020.679|4.281|there's more and more work on auto GPT
2022.399|4.4|as well as chat GPT plugins um smaller
2024.96|4.04|open source models like llama as well as
2026.799|4.641|mistro models and in the future
2029.0|5.24|hopefully we'll be able to up fine tune
2031.44|7.239|and run even more models locally
2034.24|4.439|potentially even on our smartphone
2039.559|4.641|um another area of sort of research and
2042.159|2.801|work is in memory augmentation as well
2044.2|3.079|as
2044.96|4.439|personalization so current big weakness
2047.279|4.32|of llms is they're sort of Frozen in
2049.399|3.801|knowledge at a particular point in time
2051.599|3.48|they don't sort of augment knowledge on
2053.2|4.679|the fly as they're talking to you they
2055.079|4.441|don't actually it's not stored into
2057.879|3.081|their brain the parameters the next time
2059.52|3.119|you start a new conversation there's a
2060.96|4.0|very high chance it won't remember
2062.639|5.121|anything um you said before although I
2064.96|5.0|think there's I I'll get to rag in a bit
2067.76|4.72|so one of our goals hopefully in the
2069.96|4.28|future is to have this sort of widescale
2072.48|3.96|um memory augmentation as well as
2074.24|4.439|personalization somehow update the model
2076.44|3.719|on the Fly while being able while
2078.679|4.041|talking to hundreds or thousands or
2080.159|4.68|millions of users around the world um
2082.72|3.72|and to adapt not only their knowledge
2084.839|4.04|but their talking style as well as
2086.44|4.6|Persona to the particular user and this
2088.879|3.8|is called personalization this could
2091.04|4.52|have many different applications such as
2092.679|5.4|mental health therapy and so
2095.56|4.92|forth so some potential approach for
2098.079|3.881|this could be having a memory rank um
2100.48|4.599|this is not that feasible with larger
2101.96|5.04|amounts of data prefix tuning approaches
2105.079|3.801|which fine tunes only a very small
2107.0|4.119|portion of the model however when you
2108.88|4.0|have such huge llms even fine- tuning a
2111.119|4.161|very small portion of the model is
2112.88|4.36|incredibly expensive maybe some
2115.28|5.44|prompt-based approaches in context
2117.24|5.28|learning however again um this would not
2120.72|4.48|change the model itself it will likely
2122.52|4.92|not carry forward among different
2125.2|4.08|conversations um and there's this thing
2127.44|3.919|now called rag retrieval augmented
2129.28|3.72|generation which is related to a memory
2131.359|4.161|bank where you have a data store of
2133.0|4.88|information and each time when the user
2135.52|4.12|puts in an input query you first look at
2137.88|3.36|if there's relevant information from
2139.64|5.16|this data store that you can then
2141.24|6.2|augment um as context into the llm to
2144.8|5.0|help guide its output this relies on
2147.44|5.159|having a high quality external data
2149.8|5.519|store and it's also typically not end to
2152.599|4.401|end and the main thing here is it's not
2155.319|3.0|within the brain of the model but
2157.0|2.96|outside
2158.319|3.721|um it's suitable for knowledge or
2159.96|3.8|fact-based information but it's not
2162.04|3.799|really suitable for enhancing the
2163.76|4.04|fundamental capabilities or skills of
2165.839|4.401|the
2167.8|3.96|model there's also lots of work now on
2170.24|4.52|pre-training data
2171.76|5.2|synthesis um especially after Chad GPT
2174.76|4.0|and gbd4 came out instead of having to
2176.96|3.8|collect data from humans which can be
2178.76|4.16|very expensive and timec consuming many
2180.76|4.88|researchers now are using GPD 4 for
2182.92|5.56|example to collect data to train um
2185.64|5.36|other models for example uh model
2188.48|5.04|distillation uh training smaller and
2191.0|5.16|less less capable models with data from
2193.52|4.799|larger models like Chad uh gp4 an
2196.16|3.88|example is the Microsoft five models um
2198.319|2.881|introduced from their paper textbooks
2200.04|3.559|are all you
2201.2|4.879|need and speaking a bit more about the
2203.599|5.641|five model it's a 2.7 billion parameter
2206.079|5.721|model um five version 2 and it excels in
2209.24|5.119|reasoning and language I'm challenging
2211.8|5.4|or having comparative performance to um
2214.359|6.681|compared to models up to 25 times larger
2217.2|6.68|which is incredibly um impressive and
2221.04|5.2|their main sort of takeaway here is the
2223.88|4.88|quality or source of data is incredibly
2226.24|5.119|important so they emphasized textbook
2228.76|4.559|quality training data and synthetic data
2231.359|3.601|um they generated synthetic data to
2233.319|3.28|teach the model Common Sense reasoning
2234.96|3.6|and general knowledge this includes
2236.599|4.401|things like science daily activities
2238.56|4.44|theory of mind and so forth they then
2241.0|4.319|augmented this with additional data
2243.0|4.2|collected from the web that was filtered
2245.319|2.8|based on educational value as well as
2247.2|3.159|content
2248.119|4.361|quality um and what this allowed to them
2250.359|4.681|to do is train a much smaller model much
2252.48|5.32|more efficiently while comp um
2255.04|4.84|challenging models up to 25 times larger
2257.8|4.519|which is again very
2259.88|4.52|impressive another area of debate is are
2262.319|3.841|llms truly learning are they learning
2264.4|3.199|new knowledge when you ask it to do
2266.16|3.6|something is it generating it from
2267.599|3.921|scratch or is it simply recurita
2269.76|4.64|something it's memorized
2271.52|5.0|before um this this line has been
2274.4|4.0|blurred um and it's not clear because
2276.52|4.16|the way LM is learn is from again
2278.4|4.719|learning patterns from lots of text um
2280.68|4.919|which you can say is somewhat memorizing
2283.119|4.561|um there's also the potential for test
2285.599|5.361|time contamination models might
2287.68|5.399|regurgitate um information um it's seen
2290.96|3.399|during training while being evaluated
2293.079|4.161|and this can lead to misleading
2294.359|5.0|Benchmark results um there's also
2297.24|5.2|cognitive simulation so a lot of people
2299.359|6.0|are arguing that um llms mimic human
2302.44|4.36|thought processes While others um say no
2305.359|2.641|it's just a sophisticated form of
2306.8|4.039|pattern matching
2308.0|5.8|and it's not nearly as complex um or
2310.839|5.441|biological or sophisticated as a human
2313.8|5.0|um and this also leads to a lot of
2316.28|4.16|ethical as well as practical limitations
2318.8|4.0|so for example I'm sure you've all heard
2320.44|4.84|that a recent lawsuit copyright lawsuit
2322.8|5.16|by New York Times on open AI uh where
2325.28|4.68|they claim that open A's chat was
2327.96|4.8|basically regurgitating um existing New
2329.96|5.08|York Times articles and this is again um
2332.76|5.04|sort of this issue with lm's potentially
2335.04|5.36|memorizing text it's saw during training
2337.8|5.96|rather than um synthesizing new
2340.4|3.36|information entirely from
2344.079|6.081|scratch another big source of um
2348.599|3.081|challenge which might be able to close
2350.16|5.6|the gap between current models and
2351.68|7.08|eventually maybe AGI is this um concept
2355.76|5.0|of continual learning AKA infinite and
2358.76|4.16|permanent fundamental sort of
2360.76|3.96|self-improvement so humans we're able to
2362.92|3.96|learn constantly every day from every
2364.72|3.96|interaction I'm learning right now from
2366.88|3.68|just talking to you and um giving this
2368.68|3.88|lecture right we don't need to sort of
2370.56|3.64|fine-tune ourselves we don't need to sit
2372.56|4.0|in a chair and then have someone read
2374.2|5.04|the whole internet to us um every two
2376.56|4.4|months or something like that um
2379.24|3.52|currently does work on fine-tuning a
2380.96|4.0|small model based on traces from a
2382.76|5.04|better model or the same model after
2384.96|4.6|filtering those traces however this is
2387.8|4.16|closer to retraining and distillation
2389.56|5.0|than it is to True sort of humanlike
2391.96|5.0|continual learning um so that's
2394.56|4.48|definitely um I think at least a very
2396.96|4.56|exciting
2399.04|4.559|direction another sort of area of
2401.52|5.16|challenge is interpreting these huge
2403.599|5.24|llms with billions of parameters they're
2406.68|3.919|essentially huge black box models where
2408.839|3.0|it's really hard to understand exactly
2410.599|4.121|what is going
2411.839|5.041|on um if we were able to understand them
2414.72|4.84|better this would allow us to know what
2416.88|5.8|exactly we should try to improve um it
2419.56|4.84|also allow us to control um these models
2422.68|4.2|better and potentially lead to better
2424.4|4.0|alignment as well as safety and there's
2426.88|4.239|this sort of of area of work called
2428.4|4.48|mechan mechanistic interpretability
2431.119|3.881|which tries to understand exactly how
2432.88|4.4|the individual components as well as
2435.0|4.2|operations in a machine learning model
2437.28|5.079|contribute to its overall decision
2439.2|6.0|making process and to try to unpack that
2442.359|5.641|sort of Black Box I
2445.2|4.56|guess so speaking a bit more about this
2448.0|3.56|a concept related to mechanistic
2449.76|4.599|interpretability as well as continual
2451.56|4.72|learning is model editing so this is a
2454.359|3.681|newer line of work which hasn't seen too
2456.28|2.48|much investigation also because it's
2458.04|2.72|very
2458.76|3.96|challenging um but basically this looks
2460.76|4.64|like can we edit very specific nodes in
2462.72|4.96|the model without having to retrain it
2465.4|4.36|um so one of the papers I linked there
2467.68|4.8|um they developed a causal intervention
2469.76|4.28|method to trace sort of the neural
2472.48|3.639|activations for model factual
2474.04|4.24|predictions and they came up with this
2476.119|4.24|method called rank one model editing or
2478.28|4.839|Rome that was able to modify very
2480.359|7.121|specific model weights um for updating
2483.119|5.96|factual associations for example um um
2487.48|3.2|was the capital of Canada and then
2489.079|3.641|modifying that to something else they
2490.68|3.8|found they didn't need to refine tune
2492.72|4.44|the model they were able to sort of
2494.48|5.04|inject that information um into the
2497.16|5.32|model um pretty much in a permanent Way
2499.52|4.48|by simply modifying very specific nodes
2502.48|3.24|they also found that mid layer fee
2504.0|3.839|forward modules played a very
2505.72|4.96|significant role in storing these sorts
2507.839|4.841|of factual information or associations
2510.68|4.76|and the manipulation of these can be a
2512.68|5.2|feasible approach um for model editing
2515.44|5.48|so I think this is a very cool um line
2517.88|5.76|of work with potential um long-term
2520.92|4.32|impacts and as Shi stated before another
2523.64|4.479|line of work is basically mixture of
2525.24|4.879|experts um so this is very prevalent in
2528.119|4.321|current day llms things like gbd4 and
2530.119|4.2|Gemini it's to have several models or
2532.44|5.04|experts work together sort of to solve a
2534.319|4.561|problem and arrive at a final generation
2537.48|3.48|and there's a lot of research on how to
2538.88|4.56|better Define and initialize these
2540.96|6.359|experts and sort of connect them um to
2543.44|5.2|come up with a final um result
2547.319|2.961|and I'm thinking is there a way of
2548.64|3.24|potentially having a single model
2550.28|3.88|variation of this similar to the human
2551.88|3.439|brain uh for example the human brain we
2554.16|2.919|have different parts of our brain for
2555.319|4.24|different things right uh one part of
2557.079|4.801|our brain might uh work more for spatial
2559.559|3.8|reasoning uh one for physical reasoning
2561.88|3.32|uh one for mathematical logical
2563.359|3.441|reasoning and so forth maybe there's a
2565.2|3.56|way of segmenting a single Neuron
2566.8|3.92|networker model in such a way for
2568.76|4.16|example by m adding more layers on top
2570.72|4.8|of a foundation model and then only
2572.92|6.159|fine-tuning those um specific layers for
2575.52|3.559|different uh purposes
2579.24|2.96|related to continual learning is
2580.68|3.36|self-improvement as well as
2582.2|3.8|self-reflection so there's been a lot of
2584.04|4.24|work recently that's also shown that
2586.0|3.76|models um especially llms they can
2588.28|4.2|reflect on their own output to
2589.76|5.44|iteratively refine as well as improve
2592.48|4.839|them it's been shown that this
2595.2|6.2|Improvement can happen across several
2597.319|6.201|layers of U uh self-reflection having a
2601.4|4.919|sort of mini version of continual sort
2603.52|4.44|of learning up to a certain degree and
2606.319|3.921|some folks believe that that AGI is
2607.96|3.96|basically a constant state state of
2610.24|5.839|self-reflection um which is again
2611.92|4.159|similar to what a human um
2616.44|4.96|does lastly a big uh sort of issue is
2619.359|4.521|the hallucination problem where a model
2621.4|4.439|does not know what it does not know and
2623.88|3.6|due to the sampling procedure um there's
2625.839|3.76|a very high chance for example I'm sure
2627.48|3.599|you've also used chap GPT before that it
2629.599|4.24|sometimes generates text it's very
2631.079|4.24|confident about but is simply incorrect
2633.839|3.72|like factually Incorrect and does not
2635.319|4.04|make any sense um we can potentially
2637.559|3.601|enhance this through different ways
2639.359|3.681|maybe some sort of internal based fact
2641.16|3.959|verification approach um based on
2643.04|3.88|confidence scores um this's this line of
2645.119|5.0|work called Model calibration which kind
2646.92|6.56|of works on that um potentially verif
2650.119|6.24|verifying and regenerating output um if
2653.48|5.32|it finds that its output is incorrect uh
2656.359|5.161|maybe it can as be asked to
2658.8|4.36|regenerate um and of course there's
2661.52|3.12|things like rag based approaches where
2663.16|4.8|you're able to retrieve from a knowledge
2664.64|5.0|store which is also um a potential
2667.96|5.56|solution people have investigated for
2669.64|3.88|reducing this problem of
2673.599|4.401|hallucination lastly Emily will touch
2675.68|5.919|upon um some Chain of Thought
2678.0|5.0|reasoning yeah so um Chain of Thought is
2681.599|4.76|something I think is really cool because
2683.0|6.72|I I think it combines the sort of uh
2686.359|5.641|like cognitive imitation and also uh
2689.72|4.92|interpretability uh lines of research
2692.0|4.4|and so Chain of Thought is the idea that
2694.64|4.52|all of us unless you have some
2696.4|4.439|extraordinary photographic memory sort
2699.16|3.76|of think through things step by step
2700.839|4.801|right like if I asked you to multiply a
2702.92|4.52|10 digit number by a 10-digit number you
2705.64|4.28|probably have to break that down into
2707.44|4.6|intermediate reasoning steps and so some
2709.92|3.48|researchers thought well what if we do
2712.04|4.36|the same things with large language
2713.4|4.56|models and see if having them forcing
2716.4|3.679|them to sort of reason through their
2717.96|4.92|ideas and their thoughts helps them have
2720.079|4.401|better accuracy and better results um
2722.88|4.959|and so Chain of Thought exploits the
2724.48|6.359|idea that ultimately these models have
2727.839|4.72|these weights that uh know more about a
2730.839|4.601|problem rather than just having it
2732.559|7.161|prompt and sort of regurgitate what it
2735.44|5.72|um what just to get a response yeah and
2739.72|4.599|so an example of Chain of Thought
2741.16|4.48|reasoning is uh on the right so as you
2744.319|3.921|can see on the left there's standard
2745.64|4.32|prompting so I give you this complicated
2748.24|4.56|question let's say we're doing this
2749.96|4.76|entirely new problem I give you the
2752.8|3.68|question and I just give you the answer
2754.72|4.08|I don't tell you how to do it that's
2756.48|4.72|kind of ult right versus Chain of
2758.8|5.48|Thought the first example that you get I
2761.2|5.04|actually walk you through the answer um
2764.28|3.72|and then the idea is that hopefully
2766.24|3.52|since you kind of have this framework of
2768.0|5.119|how to think about a question you're
2769.76|6.24|able to produce a more accurate
2773.119|5.161|output and so Chain of Thought resulted
2776.0|5.0|in uh pretty significant performance
2778.28|4.44|gains for larger language models um but
2781.0|4.44|similar to similarly to what I touched
2782.72|5.16|upon before this is an emergent ability
2785.44|5.679|and so we don't really see the same um
2787.88|4.959|performance for smaller models but
2791.119|3.44|something that I think is important as I
2792.839|4.321|mentioned before is this idea of
2794.559|4.961|interpretability because we can see this
2797.16|4.399|model's output as their reasoning and
2799.52|3.799|their final answer then you can kind of
2801.559|2.721|see oh hey this is where they messed up
2803.319|2.921|this is where they got something
2804.28|4.279|incorrect and so we're able to break
2806.24|3.96|down the errors of chain of thought into
2808.559|3.52|these different categories that helps us
2810.2|4.08|better pinpoint why is it doing this
2812.079|5.441|incorrectly how can we directly Target
2814.28|5.24|these issues
2817.52|4.2|and So currently Chain of Thought works
2819.52|4.0|really effectively for models of
2821.72|6.72|approximately 100 billion parameters or
2823.52|7.36|more obviously very big um but uh and so
2828.44|5.48|why is that um an initial paper found
2830.88|4.439|that one step missing and semantic
2833.92|3.88|understanding Chain of Thought errors
2835.319|4.641|are the most common among smaller models
2837.8|4.36|you can sort of think of oh I forgot to
2839.96|3.399|do this step in the multiplication or I
2842.16|3.399|actually don't really understand what
2843.359|4.361|multiplication is to begin with and so
2845.559|4.361|some potential reasons is that maybe
2847.72|4.359|smaller models fail at even relatively
2849.92|3.88|easy symbol mapping tasks they seem to
2852.079|4.161|have inherently weaker arithmetic
2853.8|5.12|abilities and maybe they have logical
2856.24|4.56|loopholes and don't uh end up coming at
2858.92|3.96|a final answer so all your reasoning is
2860.8|4.48|correct but for some reason you just
2862.88|3.92|couldn't get quite there um and so an
2865.28|3.039|interesting line of research would be to
2866.8|5.279|improve Chain of Thought for smaller
2868.319|6.361|models and similarly um allow uh more
2872.079|5.321|people to work on interesting
2874.68|5.919|problems um and so
2877.4|5.12|uh how could we potentially do that well
2880.599|3.52|one idea is to generalize this Chain of
2882.52|3.839|Thought reasoning so it's not
2884.119|3.841|necessarily that we reason in all the
2886.359|3.161|same ways right like there are multiple
2887.96|3.96|ways to think through a problem rather
2889.52|6.76|than breaking it down step by step and
2891.92|8.399|so um we can perhaps generalize Chain of
2896.28|4.039|Thought to be more flexible in different
2900.76|6.28|ways one example is this sort of tree of
2904.359|4.161|thoughts idea um and so tree of thought
2907.04|3.64|is considering multiple different
2908.52|4.28|reasoning paths and evaluating their
2910.68|4.48|choices to decide the next course of
2912.8|4.36|action and so this is sort of similar to
2915.16|4.12|the idea that we can look ahead and go
2917.16|5.28|backwards similar to a lot of the model
2919.28|4.88|architectures that we've seen um and so
2922.44|4.36|uh just having multiple options and
2924.16|4.88|being able to come out with some uh more
2926.8|4.759|accurate output at the
2929.04|6.279|end um another idea is Socratic
2931.559|5.921|questioning um so the idea that we are
2935.319|3.8|dividing and conquering in order to have
2937.48|3.76|this sort of self-questioning
2939.119|6.0|self-reflection um idea that stepen
2941.24|6.04|touched upon um and using so the idea is
2945.119|4.24|a self-questioning module using a large
2947.28|4.799|scale language model to propose these
2949.359|5.161|sub problems um related to the original
2952.079|4.401|problem that recursively backtracks and
2954.52|3.839|answers the sub problem to the original
2956.48|3.4|problem so this is sort of similar to
2958.359|3.0|that initial idea of Chain of Thought
2959.88|3.919|except rather than spelling out all the
2961.359|4.96|steps for you um the language model sort
2963.799|4.28|of reflects on how can it break down
2966.319|5.201|these problems s how can it answer these
2968.079|3.441|problems and get to The Final
2973.52|6.599|Answer cool uh okay let's see so let's
2977.559|4.121|go to uh some of the ne the more
2980.119|4.72|interesting topics that are starting to
2981.68|5.04|become relevant especially in 2024 so
2984.839|3.041|last year we saw a big explosion in
2986.72|3.359|language models especially with like
2987.88|4.479|gbd4 that came out almost an year ago
2990.079|3.841|now and now what's happening is like uh
2992.359|3.641|we are starting to transition towards
2993.92|2.919|more like AI agents and it's very
2996.0|3.52|interesting to see like what
2996.839|5.881|differentiates a agent uh from something
2999.52|4.16|like a model right um so I can I'll
3002.72|3.599|probably talk about like a bunch of
3003.68|4.56|different things uh such as like actions
3006.319|5.081|uh long-term memory communication bunch
3008.24|4.92|of stuff uh but let's start by why
3011.4|7.32|should we go and build
3013.16|9.12|agents and uh uh think about that so one
3018.72|5.56|key hypothesis uh I would say here is uh
3022.28|4.559|what's going to happen is humans will
3024.28|4.799|communicate with AI using like like
3026.839|4.161|language and AI will be operating our
3029.079|4.681|machines uh that's allowing for more
3031.0|4.44|intuitive and efficient operations and
3033.76|3.64|so if you think about like a laptop it's
3035.44|4.2|like if you show like a laptop to like
3037.4|4.919|someone who has never like uh who's like
3039.64|3.919|like a kid who has never used like a
3042.319|2.441|like a computer before they'll be like
3043.559|3.04|okay like why do I have to use this box
3044.76|3.2|why can't I just talk to it right like
3046.599|2.48|why can't it be more humanlike I can
3047.96|3.52|just ask you to do things and you can
3049.079|5.641|just go do my work for me and that seems
3051.48|5.24|to be like the more human like uh like
3054.72|3.16|uh interface to how things should happen
3056.72|2.839|and I think that's the way the world
3057.88|3.719|will transition towards when instead of
3059.559|4.881|us clicking or typing it will be like uh
3061.599|4.801|we talk to an AI uh using like natural
3064.44|4.359|language how you talk to a human and the
3066.4|4.48|AI will go and do your
3068.799|3.601|work uh actually have a Blog on this
3070.88|4.8|which is called like software 3.0 if you
3072.4|4.52|want to check that out um but yeah cool
3075.68|5.119|so for
3076.92|6.399|agents um like why like uh do you want
3080.799|5.961|agents so as it turns out like a single
3083.319|6.0|call to a large Foundation a model is us
3086.76|4.839|not enough uh you can do a lot more by
3089.319|4.0|Building Systems and by systems you mean
3091.599|4.921|like uh doing like more things like
3093.319|5.161|model chaining model reflection other
3096.52|3.4|mechanisms and this requires a lot of
3098.48|3.8|different stuff so you require like
3099.92|3.639|memory you require like large context
3102.28|2.799|lens you also want to do like
3103.559|3.24|personalization you want to be able to
3105.079|2.961|do actions you want to be able to do
3106.799|3.721|like internet
3108.04|3.68|Excel and uh and then you can like
3110.52|4.44|accomplish a lot of these things with
3111.72|4.879|this kind of Agents um here's like a
3114.96|3.399|diagram breaking down the different
3116.599|3.841|parts of the agents uh this is from
3118.359|4.801|lilan Wang uh she's a senior researcher
3120.44|4.56|at open air and so if you want to build
3123.16|3.32|really powerful agents you need to
3125.0|3.16|really just think of that as like you're
3126.48|3.2|building this sort of like a new kind of
3128.16|3.159|computer which has all the like
3129.68|3.56|different ingredients that you have to
3131.319|3.601|build like you have to build memory and
3133.24|2.92|if think about memory from scratch like
3134.92|3.04|how do you do long-term memory how do
3136.16|3.76|you do short-term memory how do you do
3137.96|3.32|planning like how how do you think about
3139.92|3.72|reflection like if something goes wrong
3141.28|3.76|how do you correct that uh how do you
3143.64|3.159|have like chain of thoughts how do you
3145.04|3.319|like decompose a goal so if I say
3146.799|3.52|something like book me a trip to Italy
3148.359|3.841|for example how do you break that down
3150.319|4.681|to like sub goals for example for the
3152.2|5.0|agent and also being able to take all
3155.0|3.64|this planning and all this like steps
3157.2|4.2|into actual action so that becomes
3158.64|4.36|really important and uh enable all of
3161.4|5.32|that using tool use so like if you like
3163.0|5.119|say like calculators or calendars or uh
3166.72|2.879|code interpreters and so on so you want
3168.119|3.0|to be able to like utilize existing
3169.599|4.041|tools that are out there it's like
3171.119|4.401|similar to like how you as a we as a
3173.64|3.64|human use like a calculator for example
3175.52|4.24|so we also want like to be able to like
3177.28|5.0|use like existing tools and become more
3179.76|2.52|efficient and
3182.319|3.841|Powerful um this was actually one of the
3184.799|3.361|demos uh this is actually from my
3186.16|3.36|company but uh this was like one of the
3188.16|3.36|first demonstrations of agents in the
3189.52|3.839|real world uh where we actually had it
3191.52|3.64|past the online driving test in
3193.359|3.561|California uh so this was actually like
3195.16|3.439|a live exam we took uh as a
3196.92|4.72|demonstration uh so this was like a
3198.599|3.96|friend uh like a like a driving test
3201.64|4.439|which you can actually take from your
3202.559|5.481|home and so the person had their hands
3206.079|3.801|up the above the keyboard and they were
3208.04|4.36|being recorded on the webcam uh there
3209.88|4.439|was also like screen recorded and the
3212.4|3.199|DMV actually had the person install like
3214.319|3.401|a special software in the computer to
3215.599|3.2|detect like it's not a bot uh but still
3217.72|3.28|the agent could actually like go on the
3218.799|3.28|compete exam so that was uh interesting
3221.0|3.72|to
3222.079|4.76|see so we set the record in this case to
3224.72|4.639|be the first AI uh to actually get a
3226.839|4.361|driving permit in California uh and this
3229.359|4.44|is sort of like the agent actually going
3231.2|6.0|and doing things so here the person has
3233.799|5.921|their hands just the keyboard for the
3237.2|4.72|for the webcam and the agent is running
3239.72|3.879|on the laptop and it's uh answering all
3241.92|3.56|the questions so all of this is
3243.599|4.0|happening autonomously in this case and
3245.48|3.4|so this was roughly around 40 questions
3247.599|2.401|uh the agent maybe made like two or
3248.88|3.36|three mistakes but was able to
3250.0|5.44|successfully pass the whole test in this
3252.24|5.37|case so this was like really fun uh let
3255.44|2.49|me go and
3257.61|3.39|[Music]
3257.93|5.429|[Laughter]
3261.0|3.359|yeah so yeah so so you can imagine like
3263.359|2.24|there's like a lot of fun things that
3264.359|3.361|can happen with agents that this was
3265.599|4.2|actually like a V attempt so we informed
3267.72|4.32|the DMV after we took the exam uh so
3269.799|3.401|this was like really funny uh but you
3272.04|3.12|can imagine like there's like so many
3273.2|4.2|different things you can enable once you
3275.16|6.88|have the sort of like capabilities that
3277.4|8.56|are available uh for everyone to
3282.04|5.2|use and this becomes a question of uh
3285.96|2.32|like why should we build more like
3287.24|3.8|humanik
3288.28|4.519|agents and I'll see this is very
3291.04|3.24|interesting because it's almost like
3292.799|3.361|saying like why should we build humanoid
3294.28|3.64|robots like why can't we just build like
3296.16|3.679|a like a different kind of robot why do
3297.92|3.12|you want human robots and it's similarly
3299.839|2.681|like question here like why do you want
3301.04|3.68|like humanik
3302.52|4.88|agents and I will say this is very
3304.72|4.24|interesting because one is like a lot of
3307.4|3.28|the technology websites is built for
3308.96|2.92|humans and then we can go and reuse that
3310.68|2.8|infrastructure instead of building new
3311.88|2.76|things and so that becomes very
3313.48|3.4|interesting because you can just deploy
3314.64|4.12|this agents uh using the existing
3316.88|3.199|technology uh second is like you can
3318.76|3.24|imagine this agents could become almost
3320.079|3.121|like a digital extension of you so they
3322.0|3.079|can learn about you they can know your
3323.2|3.8|preferences they can know what you like
3325.079|2.841|what you don't like and and be able to
3327.0|2.92|act on your
3327.92|3.8|behalf they also have very less
3329.92|3.879|restricted boundaries so they're able to
3331.72|3.56|handle like say like logins payments so
3333.799|3.601|on which might be harder with like
3335.28|3.96|things like API for example but this is
3337.4|5.0|easier to do if you are doing like more
3339.24|5.0|computer based control like a human and
3342.4|3.28|it's also very uh you can imagine the
3344.24|2.839|problem is also fundamentally simpler
3345.68|3.679|because you just have a action space
3347.079|3.841|which like clicking and typing in uh
3349.359|4.401|which itself is like a fundamentally
3350.92|4.399|limited action space uh so that's a a
3353.76|4.319|simpler problem to solve rather than
3355.319|5.52|like building something that is is uh um
3358.079|5.121|maybe like more general
3360.839|3.921|purpose and another interesting thing
3363.2|3.48|about this kind of human like agents is
3364.76|3.2|you can also teach them so you can like
3366.68|2.96|teach them how you will do things they
3367.96|3.92|can maybe record you passively and they
3369.64|4.0|can learn from you and then improve and
3371.88|5.4|this is also becomes like an interesting
3373.64|3.64|way to improve this agents over
3377.4|5.04|time so when we talk about agents uh
3380.359|3.161|there's this map that people like to use
3382.44|3.24|which is called like the five different
3383.52|5.559|levels of autonomy uh this actually came
3385.68|8.08|from C driving cards so how this works
3389.079|6.441|is you have like l0 to L5 so l0 to L2 is
3393.76|4.079|uh the parts of autonomy where the human
3395.52|4.079|is in control so here's the human is
3397.839|3.24|driving the car and there might be some
3399.599|2.841|sort of part partial automation that's
3401.079|4.24|happening which could be like some sort
3402.44|5.2|of like auto assist kind of
3405.319|3.321|features what this starts becoming
3407.64|4.32|interesting when you have something like
3408.64|6.479|L3 so in L3 you still have a human in
3411.96|4.96|the car but uh like most of the time the
3415.119|3.401|car is is able to drive drive it itself
3416.92|5.04|so like on highways or like on most of
3418.52|4.92|the roads uh L4 is uh you still have a
3421.96|3.8|human but like the car is like doing all
3423.44|3.879|the driving um and this is maybe like
3425.76|3.68|what you have like if you have driv a
3427.319|5.401|Tesla on autopilot before that's like a
3429.44|5.159|L4 autonomous vehicle and L5 is
3432.72|4.28|basically you don't have a driver in the
3434.599|5.161|car so the car is able to go and handle
3437.0|4.88|all parts of uh the system there's no
3439.76|3.96|fall back and this is what like voo is
3441.88|5.199|doing right now so if you take a cell
3443.72|5.76|driving uh if you set in a voo
3447.079|4.641|uh in SF then you can experience like a
3449.48|4.079|L5 autonomic car where like there's no
3451.72|4.079|human and the a is driving the whole car
3453.559|5.321|itself and so same thing also applies
3455.799|4.441|for a a agents so you can almost imagine
3458.88|3.479|um if you are building something like a
3460.24|3.64|L4 level capability that's where like a
3462.359|3.881|human is still in the loop ensuring that
3463.88|4.36|nothing is going wrong and uh so this is
3466.24|3.52|like you still have some bottlenecks but
3468.24|3.28|if you are able to reach like L5 level
3469.76|2.96|of autonomy on agents and that's
3471.52|2.68|basically like saying like you ask an
3472.72|3.28|agent to book a flight and that happens
3474.2|4.32|you ask it for like maybe like go maybe
3476.0|4.24|like order this for me or maybe like uh
3478.52|4.44|go like whatever like things you care
3480.24|4.559|about uh and that can all happen autonom
3482.96|3.079|autonomously so that's where things
3484.799|3.921|start becoming very interesting when we
3486.039|5.56|can start reaching from L4 to L5 and
3488.72|7.16|don't even need a human in the loop
3491.599|6.2|anymore cool um okay so when you think
3495.88|4.64|about building agents uh there's
3497.799|4.921|predominantly two routes uh so the first
3500.52|5.16|one is like API where like you can go
3502.72|4.96|and control anything uh based on like
3505.68|4.52|API that are available out there so
3507.68|4.8|openi has been trying this with chat gbt
3510.2|4.839|plugins for example there's also like a
3512.48|4.0|bunch of work from Berkeley uh so
3515.039|3.881|Berkeley had this book called gorilla
3516.48|4.04|where you could train a a foundation
3518.92|4.04|model to control 10,000
3520.52|4.2|apis um and and there's like a lot of
3522.96|3.079|interesting stuff Happening Here a
3524.72|3.639|second direction of work is like more
3526.039|3.601|like direct interaction with a computer
3528.359|2.801|and there's like different like uh
3529.64|3.679|companies trying this out so we have one
3531.16|4.159|of that there's also this setup called
3533.319|4.72|adapt which is trying this like human
3535.319|2.72|like interaction
3539.92|4.879|um yeah maybe I can show this thing so
3542.559|5.48|this is like a an idea of like what you
3544.799|6.681|can enable by having agents so what we
3548.039|5.401|are doing here is uh uh like here we
3551.48|6.359|have our agent and we've told it to like
3553.44|5.84|go to Twitter and uh make a post and so
3557.839|4.28|it's going and like controlling the
3559.28|4.88|computer uh doing this whole interaction
3562.119|5.44|and once it's done it can send me a
3564.16|3.399|response back
3568.599|3.361|uh which you can see here and so this
3570.599|3.041|becomes interesting because like you
3571.96|3.399|don't really need apis if you have this
3573.64|3.32|kind of Agents so if I have an agent
3575.359|3.321|that can go control my computer can go
3576.96|3.44|control websites can do whatever it
3578.68|3.52|wants almost in a humanik manner like
3580.4|4.0|what you can do then you don't really
3582.2|4.359|need apis because this becomes like the
3584.4|5.159|abstraction layer uh to allow any sort
3586.559|4.48|of like uh control um so so it's going
3589.559|3.0|to be like really fascinating once we
3591.039|3.601|have this kind of agent start to work in
3592.559|5.48|the real world and a lot of like uh
3594.64|3.399|transitions we'll see in technology
3605.359|6.24|see cool okay so let's move on to the
3608.359|6.641|next topic when it comes to agents so
3611.599|6.76|one very interesting thing here is uh
3615.0|5.039|memory so yeah so we say a good way to
3618.359|4.081|think about a model is almost think of
3620.039|4.161|it like a like a compute chip so what
3622.44|3.119|happens is you have some sort of input
3624.2|3.839|tokens which are defined in natural
3625.559|4.04|language which are going as the input to
3628.039|3.601|a model and then you get some output
3629.599|4.561|tokens out and the output tokens are
3631.64|4.679|again natural language um and if you
3634.16|4.6|have something like uh gbd 3.5 that used
3636.319|3.76|to be something like a 8,000 uh length
3638.76|4.079|token with
3640.079|4.76|gbd4 this became like a 16,000 now it's
3642.839|4.2|like 128,000 so you can almost imagine
3644.839|4.72|this as like the token size or the
3647.039|5.28|instruction size of this comput unit
3649.559|4.52|which is powered by uh n like a neural
3652.319|3.961|network in this
3654.079|3.96|case and so this is basically what a
3656.28|3.96|gbd4 you can imagine is it's almost like
3658.039|4.121|a CPU and that say it's taking some
3660.24|3.599|input tokens defined over natural
3662.16|3.48|language doing some competition over
3663.839|4.401|them transforming those tokens and
3665.64|4.24|giving out some output tokens uh this is
3668.24|5.879|actually similar to how you think about
3669.88|6.04|like memory chips for example so here uh
3674.119|3.081|I'm showing like a myips 32 processor
3675.92|3.639|that's one of the earliest processor out
3677.2|4.04|there and so what it's doing is you have
3679.559|3.401|input tokens and output Toons in binary
3681.24|2.96|like zeros and ones but instead of that
3682.96|4.639|you can imagine we doing very similar
3684.2|6.2|things but just over naal language now
3687.599|4.44|and now if you uh think more about this
3690.4|3.04|analogy so you can start thinking like
3692.039|2.721|okay like what we want to do is like
3693.44|3.44|take whatever we have been doing in
3694.76|3.839|building computers and like CPUs and
3696.88|3.64|logic and so on but can we generalize
3698.599|3.401|all of that to natural language and so
3700.52|3.36|you can start thinking about like how
3702.0|5.039|current like processors work how current
3703.88|5.56|like uh computers work you have like uh
3707.039|5.0|like instructions you have memory you
3709.44|4.8|have like variables and then you like
3712.039|4.76|run this over and over to like uh each
3714.24|5.319|line of binary sequence of instructions
3716.799|4.04|to like uh output code U and you can
3719.559|2.961|start thinking about Transformers in a
3720.839|3.081|similar way where you can have a like
3722.52|3.2|the transformer acting as a computer
3723.92|3.72|unit you are passing it some sort of
3725.72|4.52|instructions line by line and each
3727.64|3.88|instruction can contain some like uh
3730.24|3.4|Primitives which are defining like what
3731.52|3.44|to do which could be the user command it
3733.64|3.919|could have some memory Parts which are
3734.96|3.44|dried from like external like a dis uh
3737.559|2.161|which in this case could be like
3738.4|2.959|something like a personalization system
3739.72|3.24|and so on as well as some sort of
3741.359|3.2|variables and then you're taking this
3742.96|3.119|and running this line by line and that's
3744.559|4.201|like a pretty good way to think about
3746.079|3.921|like what uh uh like something like this
3748.76|2.359|could be doing and you can almost
3750.0|3.24|imagine there could be like new sort of
3751.119|4.2|programming languages you can build
3753.24|4.879|which are like specific to programming
3755.319|2.8|like uh
3758.68|3.639|Transformers and so when it comes to
3760.48|4.319|memory um traditionally how we think
3762.319|3.96|about memory is like a disk right so
3764.799|3.28|it's like long lived it's persistent
3766.279|3.84|when the computer like shuts down you
3768.079|4.04|save all your data from the ram to the
3770.119|3.321|disk and then you can like persist it
3772.119|4.401|and then you can like load it back when
3773.44|4.919|you want um you want to enable something
3776.52|4.12|very similar when you have like Ai and
3778.359|3.96|you have agents and so you want to have
3780.64|4.24|mechanisms where I can like store this
3782.319|4.24|data and then retrieve this data and
3784.88|3.84|right now how we doing this is like thr
3786.559|5.28|embeddings um so you can like take any
3788.72|5.8|sort of like um PDF or like any sort of
3791.839|4.081|like modality you care about uh convert
3794.52|3.92|that to embeddings using like an
3795.92|5.359|embedding model and store that embedding
3798.44|4.56|in like a vector database and later when
3801.279|4.28|you actually care about like uh doing
3803.0|4.0|some any sort of access uh to the memory
3805.559|3.48|you can load the relevant part of the
3807.0|4.92|embedding put that as part of your
3809.039|4.961|instruction and fit that to the model
3811.92|4.48|and uh so this is like how we are think
3814.0|4.0|about memory with AI these days um and
3816.4|3.6|then you essentially have the retrieval
3818.0|4.039|models which are acting as a function to
3820.0|3.279|store and retrieve memory and the
3822.039|3.8|embeddings becomes like the layer of
3823.279|4.441|like the it's like basically the uh the
3825.839|3.96|format you're using to like encode the
3827.72|4.44|memory in this case uh there's still a
3829.799|3.841|lot of open questions because uh how
3832.16|3.36|this works right now is just like you
3833.64|3.8|just do simple K&N so it's like very
3835.52|3.48|simp like nearest neighbor search which
3837.44|3.399|is not efficient it doesn't really
3839.0|3.44|generalize doesn't scale and so there's
3840.839|3.72|a lot of things you can think about like
3842.44|4.679|especially hierarchy uh temporal
3844.559|4.52|coherence because like a lot of memory
3847.119|3.641|data is like a Time series so there's
3849.079|3.121|like a lot of like temporal Parts
3850.76|3.12|there's also like a lot of structure uh
3852.2|3.24|usually in a lot of data so you could
3853.88|3.56|use a structure it could be like a graph
3855.44|3.399|for example and there's also like a lot
3857.44|3.32|of things you can do on online
3858.839|3.881|adaptation because like most your data
3860.76|3.2|is not static you're always learning
3862.72|3.24|you're always adapting there things
3863.96|3.319|changing all the time and uh a good
3865.96|3.0|model over here is maybe like how the
3867.279|3.441|human brain works so if you think about
3868.96|3.52|like something like the hyppocampus it's
3870.72|3.44|it's like uh people still don't know how
3872.48|2.96|it fully works but it's like something
3874.16|3.199|you're like learning new things on the
3875.44|3.72|Fly you're creating new memories you're
3877.359|3.401|adapting new memories and so on and so I
3879.16|5.399|think it be very fascinating to see how
3880.76|3.799|this area of research evolves over
3885.359|4.44|time uh similarly like a very relevant
3887.88|3.84|problem with memory is
3889.799|3.24|personalization um like suppose now you
3891.72|3.079|have this agents that are doing things
3893.039|3.161|for you then you want to make sure that
3894.799|2.881|the agent actually knows what you like
3896.2|3.079|what you don't like like suppose you
3897.68|3.56|tell an agent to go book you a ,000
3899.279|4.121|flight but maybe it books you the wrong
3901.24|5.2|flight uh and just Wast you a lot of
3903.4|5.12|your money or maybe just it just uh does
3906.44|3.44|a lot of wrong actions which is not good
3908.52|4.96|so you want the agent to like sort of
3909.88|6.12|learn about uh what you like and like
3913.48|4.72|understand that and this becomes about
3916.0|3.96|like forming a long Liv user memory for
3918.2|3.159|example where like the more you interact
3919.96|4.28|with it the more it should form a memory
3921.359|4.44|about you and be able to use that and
3924.24|3.68|this could be like uh this could have
3925.799|3.361|like different flavors someone could be
3927.92|3.359|like explicit where you can tell it like
3929.16|3.76|okay here's my allergies here's my
3931.279|3.481|flight preferences I like window versus
3932.92|3.639|a seats here my favorite dishes and so
3934.76|3.4|on but this could also be implicit where
3936.559|4.52|it could be like say like I like maybe
3938.16|4.84|like idas over Nike or if I have if I'm
3941.079|3.401|on Amazon and if I have like this 10
3943.0|3.0|different like shirts I can buy maybe I
3944.48|3.079|will buy this particular type of shirt
3946.0|2.76|and brand and so on and so there's also
3947.559|3.641|like a lot of implicit learning you can
3948.76|4.64|do which is more like based on feedback
3951.2|2.2|or
3954.079|2.921|comparisons and this's there's a lot of
3955.92|2.28|challenges involved here so you can
3957.0|2.68|imagine like it's like how do you
3958.2|3.119|collect this data how do you form this
3959.68|4.159|memory how do you
3961.319|4.76|learn uh and do you use like supervis
3963.839|4.921|learning versus feedback how do you like
3966.079|3.881|learn on the Fly and how do you and
3968.76|3.96|while you're doing all of this how do
3969.96|4.879|you preserve user privacy because like
3972.72|4.24|uh for some a system to be personalized
3974.839|3.321|it just needs to know a lot about you
3976.96|3.119|but then how do you ensure that if
3978.16|3.36|you're building system like that that
3980.079|3.921|this is actually safe and nothing is
3981.52|6.039|actually getting like uh uh like it's
3984.0|3.559|not violating any of your privacy
3989.119|5.641|a very interesting uh area when it comes
3992.52|3.36|to agents is also communication so now
3994.76|2.44|you can imagine like suppose you have
3995.88|3.56|this one agent that can go and do things
3997.2|3.52|for you but uh why not have like
3999.44|3.52|multiple
4000.72|3.76|agents and what happens if you have like
4002.96|2.399|a if I have an agent and you have an
4004.48|2.599|agent and this agent starts
4005.359|3.121|communicating with each other and so I
4007.079|2.841|think we'll start seeing this phenomena
4008.48|3.559|where you will have like multi agent
4009.92|3.84|autonomous systems where like each agent
4012.039|2.961|can go and do things and then each that
4013.76|2.599|agent can go and talk to other agents
4015.0|3.68|and so on
4016.359|5.68|and uh so that's going to be
4018.68|5.439|fascinating and uh like why do you want
4022.039|4.361|to do this so one is like if you have a
4024.119|4.361|single agent it will always be slow like
4026.4|3.48|it have to do everything sequentially
4028.48|3.4|but if you have a multi-agent system
4029.88|3.439|then you can like paralyze the system so
4031.88|3.399|instead of one agent if I had thousands
4033.319|4.681|of Agents each agent can go do something
4035.279|4.161|for me in par instead of just having one
4038.0|3.88|second is you can also have specialized
4039.44|4.44|agents so I could have a agent that's
4041.88|3.84|specific for spread sheets or I have a
4043.88|3.52|agent that can operate my Slack I have
4045.72|3.44|an agent that can operate my web browser
4047.4|3.48|and then I can route to different agents
4049.16|3.72|to for like different things I want to
4050.88|4.199|do and that can help like this is almost
4052.88|4.719|like what you do in a factory like you
4055.079|3.841|have like specialized workers like each
4057.599|3.081|worker is doing like something like
4058.92|4.08|they're specialized to and this actually
4060.68|3.84|is something that we found over like U
4063.0|3.039|uh the period of human history that this
4064.52|5.279|is the right way to like divide tasks
4066.039|3.76|and like uh uh get maximum
4070.0|3.319|performance uh there's a lot of
4071.559|3.201|challenges here to so one one the
4073.319|2.881|biggest one is just like how do you
4074.76|2.48|exchange information
4076.2|2.0|because now what's happening is like
4077.24|3.76|everything is happening over natural
4078.2|4.48|language and natural language itself is
4081.0|3.839|lossy so it's very easy to have
4082.68|3.359|miscommunication gaps like even in when
4084.839|3.601|humans talk to each other there's a lot
4086.039|4.08|of like miscommunication uh you lose
4088.44|3.48|information a lot because like natural
4090.119|3.321|language itself is ambiguous so you just
4091.92|3.679|need to have like better protocols or
4093.44|3.359|like a better ways to like ensure that
4095.599|2.56|if agents start communicating with other
4096.799|3.321|agents it doesn't cause mistakes it
4098.159|3.0|doesn't Le to like a lot of like Havoc
4100.12|3.639|for
4101.159|3.841|example and uh this this can also lead
4103.759|3.361|to like building like different sort of
4105.0|3.44|like interesting Primitives um so here's
4107.12|3.36|like one example primitive you can think
4108.44|4.399|about is where like suppose I what if I
4110.48|3.6|have a manager agent and the the manager
4112.839|3.161|agent can go and coordinate a bunch of
4114.08|4.44|worker agents and this is very similar
4116.0|4.88|to like a human organization for example
4118.52|4.199|um so you can have this hierarchy where
4120.88|4.12|like okay like if I'm a user I'm talking
4122.719|3.52|to this one main agent but behind the
4125.0|2.92|scene this agent is going and like
4126.239|2.96|talking to its own worker agents
4127.92|3.399|ensuring that each worker goes and does
4129.199|3.401|the task and once everything is done
4131.319|2.48|then the manag agent come back comes
4132.6|3.079|back to me and says okay like this thing
4133.799|2.761|is done and so you can imagine IM like
4135.679|3.48|there's a lot of this Primitives that
4136.56|4.36|can be built a good way to also think
4139.159|4.16|about this is almost like a single core
4140.92|3.799|machine versus a multicore machine so
4143.319|3.081|like when you have a single agent almost
4144.719|4.321|like saying I have a single processor
4146.4|4.319|that's powering my uh computer but now
4149.04|4.279|if I have multiple agents I have this
4150.719|4.04|maybe like a 16 core or 64 core machine
4153.319|4.121|where like a lot of this things can be
4154.759|4.04|DED to different agents paralyzed and uh
4157.44|2.96|I think that that's a very interesting
4158.799|4.88|analogy when it comes to like a lot of
4160.4|3.279|the like multi- agent
4164.0|4.08|systems this still a lot of work uh that
4166.48|3.879|needs to be done uh the biggest one is
4168.08|4.8|like communication is really hard uh so
4170.359|5.161|you need robust communication protocols
4172.88|3.959|uh to minimize miscommunication you
4175.52|3.92|might also just need like really good
4176.839|5.48|like schemas and uh maybe like almost
4179.44|3.919|like how you have HTP uh that's used to
4182.319|2.281|transporting information over the
4183.359|3.601|internet you might need something
4184.6|4.32|similar uh to transport information
4186.96|4.12|between different
4188.92|4.239|agents um you can also think about some
4191.08|3.88|Primitives here I'll just walk through a
4193.159|3.801|small example if you have time like
4194.96|4.239|suppose this is a manager agent that
4196.96|4.64|wants to get a task done so it gives a
4199.199|4.721|plan and a context to a worker agent the
4201.6|4.76|work can say like okay I did this task
4203.92|3.799|and then we get a response back then
4206.36|2.64|usually you want to actually verify if
4207.719|4.041|this got done or not because like it's
4209.0|4.44|possible maybe the worker was lying to
4211.76|4.08|you for example maybe it failed to do
4213.44|3.36|the task or like something went wrong
4215.84|2.839|and so you want to actually go and
4216.8|3.439|verify that this actually was done
4218.679|3.121|properly and if everything was done then
4220.239|2.761|you know like okay this is good you can
4221.8|3.08|tell the user this task was actually
4223.0|3.719|finished but what could happen is maybe
4224.88|3.76|like the the worker actually didn't do
4226.719|3.041|the task properly something went wrong
4228.64|3.079|and in that case like you want to
4229.76|3.24|actually actually go and redo the task
4231.719|2.96|and you just have to build this sort of
4233.0|3.36|like a failover mechanisms because
4234.679|3.361|otherwise there's there a lot of things
4236.36|2.92|that can go wrong and so like thinking
4238.04|3.24|about like this sort of like syncing
4239.28|4.04|Primitives and how can you ensure
4241.28|2.919|reliability how can you ensure fallback
4243.32|3.64|I think that becomes like very
4244.199|4.801|interesting with this kind of uh agentic
4246.96|5.48|systems and there's like a lot of future
4249.0|4.92|directions to be explored um there's a
4252.44|3.52|lot of issues with autonomous agents
4253.92|4.04|still the biggest one are around
4255.96|3.84|reliability um so this happens because
4257.96|4.12|like models are stochastic in nature
4259.8|3.48|like if I have a AI model it's like a
4262.08|3.2|it's stochastic it's like it's a
4263.28|4.16|probalistic function uh it's not fully
4265.28|4.36|deterministic and what happens is like
4267.44|4.759|uh if I wanted to like do something it's
4269.64|3.76|possible that with some error at Epsilon
4272.199|3.241|it will do something that I didn't
4273.4|3.4|expect it to do and and so like it
4275.44|3.32|becomes really hard to trust it because
4276.8|3.2|if I if I have traditional code I write
4278.76|2.919|a script and I run the script through a
4280.0|2.96|bunch of test cases and unit test I know
4281.679|2.961|okay like if this works it's got over
4282.96|3.32|100% of the time I can deploy this to
4284.64|3.76|millions or billions of people but if
4286.28|3.84|have an agent it's a stochastic function
4288.4|3.48|uh maybe if it works maybe it works like
4290.12|3.96|95% of the time but like 5% of time it
4291.88|4.24|still fails uh and there's no way to fix
4294.08|3.24|this right now uh so that becomes like
4296.12|2.96|very interesting like how do you
4297.32|3.8|actually like solve these
4299.08|3.36|problems uh similarly you see a lot of
4301.12|4.039|problems around like looping and plan
4302.44|4.239|Divergence so what happens here is like
4305.159|3.681|this like a you need a lot of multi
4306.679|3.401|interactions when it comes to agents so
4308.84|2.72|you want to like have the agent do
4310.08|2.96|something then like use that to do
4311.56|3.28|another thing so on so take like maybe
4313.04|3.44|like hundreds or thousands of steps but
4314.84|4.64|if it fails in like maybe like the 20th
4316.48|4.4|step then then it might just go haire
4319.48|2.719|don't know what to do for the remaining
4320.88|4.08|like 20 like the remaining thousand
4322.199|5.0|steps of the trajectory uh and so how do
4324.96|3.16|you correct it bring it back on course I
4327.199|3.04|think that becomes an interesting
4328.12|3.4|problem uh similarly how do you test and
4330.239|2.4|Benchmark this agents especially if
4331.52|3.36|they're going to be running in the real
4332.639|4.401|world and how do you build a lot of
4334.88|3.88|observability on the systems right like
4337.04|3.28|uh if I have this agent that's maybe
4338.76|3.399|like has access to my bank account is
4340.32|3.52|doing things for me uh how do I actually
4342.159|3.761|know like it's uh doing safe things it's
4343.84|4.96|not someone is not hicking into it
4345.92|4.719|um how do I build trust and how also how
4348.8|3.52|do we build like human fallbacks like
4350.639|2.801|you probably want something like a 2fa
4352.32|2.48|if it's going to go and like do
4353.44|4.199|purchases for you or you want like some
4354.8|5.0|ways to guarantee like okay like uh you
4357.639|4.04|just didn't wake up and like uh have
4359.8|4.0|like didn't have like a Zer bank account
4361.679|2.121|or
4364.28|3.439|something and so this are some of the
4366.44|2.719|problems that we need to solve for
4367.719|4.361|agents for them to become like real
4369.159|4.441|world Deployable um and this is a
4372.08|3.52|example of like a plan diverence problem
4373.6|4.119|you see with agents like if you ask the
4375.6|4.28|agent to go do something you will
4377.719|3.92|usually expect expect it to follow like
4379.88|3.52|a path where like it will like follow
4381.639|2.721|some ideal path to reach the goal but
4383.4|2.839|what might happen is like it might
4384.36|3.12|actually deviate from the path and once
4386.239|2.641|it deviates it doesn't know what to do
4387.48|3.199|so it just keeps like making mistakes
4388.88|4.64|after mistakes and this is something
4390.679|5.201|actually you uh observe with like like
4393.52|3.56|early agents like Auto gbd for example
4395.88|3.6|um so I'm not sure if anyone in this
4397.08|5.119|room has played with autog gbd uh has
4399.48|4.6|anyone do that okay and so like Auto the
4402.199|3.721|issue is like it's like like you it's a
4404.08|3.48|very good like prototype but it doesn't
4405.92|3.0|actually do anything because it just
4407.56|3.52|keeps making a lot of mistakes it keeps
4408.92|3.88|looping around keeps like going hawi and
4411.08|3.559|and that's sort of like shows like okay
4412.8|3.12|like what why you need really need to
4414.639|2.801|have like really good ways to correcting
4415.92|3.6|agents making sure like if it makes a
4417.44|5.44|mistake it can actually come back and
4419.52|3.36|not just like go do random
4423.04|5.96|things uh so building on this there's
4425.88|5.359|also like a very good uh uh analogy from
4429.0|6.48|andreti so he likes to call this like
4431.239|7.121|the LM operating system where uh like uh
4435.48|4.8|how uh I was studying about like thing
4438.36|4.64|about like llms and the Agents as
4440.28|4.52|building computer chips and computers so
4443.0|3.56|you can actually start thinking of it
4444.8|4.359|like that like here the computer chip is
4446.56|5.36|the LM and the ram is like the context
4449.159|4.56|length of uh of the tokens that you're
4451.92|3.719|feeding into the model then you have
4453.719|3.601|this like file system which is a dis
4455.639|3.52|where you are storing your embeddings
4457.32|3.72|you're able to retrieve the embeddings
4459.159|4.241|you might have traditional software 1.0
4461.04|5.52|tools which are like uh your calculator
4463.4|4.839|your python interpretor terminals Etc
4466.56|3.639|you actually have this like if you have
4468.239|3.48|like ever taken operating system course
4470.199|3.841|there's this thing called ALU which is a
4471.719|3.681|arithmetic logical unit which Powers a
4474.04|3.08|lot of like how you do multiplications
4475.4|4.319|division so on so it's very similar to
4477.12|4.119|that like you just need like uh tools to
4479.719|3.761|be able to like do like complex
4481.239|4.081|operations and then you might also have
4483.48|3.52|like peripheral devices so you might
4485.32|4.16|have different modalities so you might
4487.0|3.679|have audio you might have video you
4489.48|2.84|probably want to be able to like connect
4490.679|3.441|to the Internet so you want to have like
4492.32|2.879|some sort of like browsing capabilities
4494.12|3.599|and you might also want to be able to to
4495.199|4.081|talk to like other llms um and so this
4497.719|3.0|kind of becomes like how you will think
4499.28|2.919|about a new generation of computers
4500.719|3.96|being designed uh with all the
4502.199|2.48|Innovations in
4505.199|5.641|AI cool uh and so I would like to end
4508.679|3.641|here by saying like uh how I imagine
4510.84|2.64|this to look like in the future is like
4512.32|3.52|you can think of this as a neural
4513.48|4.44|computer where like uh there's a user
4515.84|3.64|that's talking to a chat interface
4517.92|4.16|behind the scene like the chat interface
4519.48|4.96|has a action engine that can like take
4522.08|4.36|the task rout it to different agents and
4524.44|3.16|like do the for you and send you the
4526.44|5.32|results
4527.6|8.28|back uh cool so and then
4531.76|5.959|um so let's uh yeah so to end this uh
4535.88|3.68|this's like uh a lot of stuff just needs
4537.719|4.241|to be done for agents and the biggest
4539.56|4.0|prevalent uh issues right now we say is
4541.96|2.719|like error correction so like what
4543.56|2.4|happens if something goes wrong how do
4544.679|3.56|you prevent the errors from extrating in
4545.96|4.199|the real world how do you build security
4548.239|3.561|how do you build user permissions like
4550.159|3.641|what if someone tries to hijack your
4551.8|4.839|computer or your agent how do you build
4553.8|4.76|like like robust like uh uh security
4556.639|3.281|Primitives and also how do you like
4558.56|3.0|sandbox this agents how do you deploy
4559.92|3.2|them in Risky scenarios so if you want
4561.56|3.88|to deploy this in like Finance scenarios
4563.12|4.0|or like legal scenarios uh there's a lot
4565.44|4.88|of things where you just want this to be
4567.12|4.36|very uh Str stable and safe and that's
4570.32|2.28|like still something that has not been
4571.48|4.199|figured out and there's a lot of
4572.6|4.24|exciting um room uh to like sort of like
4575.679|3.921|think on the problems both on the
4576.84|6.319|research side as well as application
4579.6|5.639|side cool all right so thanks guys for
4583.159|3.601|coming to our first lecture this quarter
4585.239|3.201|um stay back if you have any questions
4586.76|3.68|and we might try to get a group photo so
4588.44|4.0|if you want to be in that um also stay
4590.44|3.6|back um so next week we're going to have
4592.44|4.759|my friend Jason way as well as his
4594.04|4.679|colleag kyang Wan from open AI um come
4597.199|3.841|give a talk and they're doing very
4598.719|4.361|Cutting Edge research involving um
4601.04|4.32|things like large language models at
4603.08|3.8|openai um and he was actually the first
4605.36|2.76|author of several of the works we talked
4606.88|3.88|about today like Chain of Thought
4608.12|4.0|reasoning and emerging behaviors so if
4610.76|3.36|you're enrolled please come in person
4612.12|5.2|they'll be in person um so you'll be
4614.12|4.64|able to interact with them um in person
4617.32|3.04|and um if you're still not enrolled in
4618.76|4.32|the course and wish to do so please do
4620.36|5.64|so on access and for the folks on Zoom
4623.08|5.32|um feel free to audit um uh lectures
4626.0|5.0|will be the same time uh each week on
4628.4|5.2|Thursday and we'll announce any
4631.0|5.84|notifications by email canvas as well as
4633.6|8.52|Discord um so keep your eye out um for
4636.84|5.28|those and yeah so thank thank you guys