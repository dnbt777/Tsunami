start_time|end_time|text
5.799|3.121|So today we're going to give an
6.919|4.401|instructor Le lecture talking about some
8.92|5.08|of the some uh key topics in
11.32|3.96|Transformers and llms these days um in
14.0|3.199|particular div will be talking about
15.28|4.28|agents and I'll be discussing emergent
17.199|5.481|abilities intermediate guided reasoning
19.56|8.16|as well as baby LM um so let me actually
22.68|9.28|go to my part uh because div is not here
27.72|4.24|yet um
32.0|3.6|so I'm sure many of you have uh read
33.68|5.44|this paper emergent abilities of large
35.6|6.6|language models um from 2022 so I'll
39.12|5.68|briefly go through um some of them um so
42.2|4.76|basically and ability is emergent if it
44.8|3.84|is present and large but not smaller
46.96|3.48|models and it would not have been
48.64|4.719|directly predicted by extrapolating
50.44|4.439|performance from smaller models um so
53.359|3.161|you can think of performance it's
54.879|3.881|basically near random until a certain
56.52|4.519|threshold called a critical threshold
58.76|4.4|and then improves very heav heavy this
61.039|3.641|is known as a pH transition and again it
63.16|3.8|would not have been extrapolated or
64.68|4.04|predicted if you were to um extend the
66.96|3.88|curve of the performance of smaller
68.72|4.92|models it's more of a jump um which
70.84|4.68|we'll see later um so here's an example
73.64|4.4|of fucha prompting for many different
75.52|5.72|tasks for example modular arithmetic
78.04|5.52|unscrambling words um different QA tasks
81.24|4.96|and so forth and you'll see that
83.56|4.919|performance kind of jumps very heavily
86.2|4.279|up until a certain point um I believe
88.479|4.201|the xaxis here is the number of train
90.479|4.64|flops uh which corresponds to basically
92.68|5.759|model scale um so you'll see in many
95.119|5.881|cases around 10 to the 22 or 10 to 23
98.439|6.32|training flops there's a massive um
101.0|6.56|exponential um jump or increase in terms
104.759|5.481|of model performance on these tasks um
107.56|5.8|which was not present um on smaller
110.24|5.519|scales um so it was qu it's quite
113.36|4.28|unpredictable and here are some examples
115.759|3.801|of this occurring using augmented
117.64|4.24|prompting strategies so I'll be talking
119.56|4.199|a bit later about Chain of Thought um
121.88|4.68|but basically these strategies um
123.759|5.601|improve the ability of getting um
126.56|4.72|behavior from Models um on different
129.36|4.239|tasks so you see for example with Chain
131.28|4.08|of Thought reasoning um that's an
133.599|4.72|emergent behavior that happens again
135.36|5.72|around 10 to the 22 training flops and
138.319|5.801|um without it uh model performance on
141.08|5.879|gsm 8K which is a mathematics Benchmark
144.12|4.399|um it doesn't really um improve heavily
146.959|3.721|but Chain of Thought kind of leads to
148.519|5.08|that emergent Behavior or sudden
150.68|5.32|increase um in performance and here's
153.599|5.441|just the table from the paper which has
156.0|5.319|a a bigger list of emerging abilities of
159.04|4.4|llms as well as their scale at which
161.319|5.28|they occur so I recommend that you check
163.44|4.48|out the paper to learn a bit more and so
166.599|3.601|one thing researchers have been
167.92|4.84|wondering is why does this emergence
170.2|5.2|occur exactly and even now there's few
172.76|4.24|explanation for why that happens um and
175.4|3.36|the authors also found that the
177.0|3.84|evaluation metrics used to measure these
178.76|4.479|abilities may not fully explain why they
180.84|4.44|emerge and they suggest some alternative
183.239|4.121|um evaluation metrics which I encourage
185.28|5.879|you to read more in the
187.36|6.159|paper so other than scaling up um to
191.159|4.761|encourage these emerging abilities um
193.519|5.481|which could endow even larger LMS with
195.92|5.08|further new emerging abilities what else
199.0|4.519|um can be done while things like
201.0|4.76|investigating new architectures higher
203.519|4.681|quality data which is very important for
205.76|4.839|for performance on all tasks improve
208.2|4.399|training and improve training procedures
210.599|5.521|could enable emergent abilities to occur
212.599|6.28|especially on smaller models um which is
216.12|4.52|a current growing area of research um
218.879|4.36|which I'll also talk about a bit more
220.64|4.2|later um other abilities include
223.239|4.28|potentially improving the F shot
224.84|4.479|prompting abilities of LMS uh
227.519|4.961|theoretical and interpretability
229.319|5.76|research again to try to understand why
232.48|5.759|um emergent abilities is a thing and how
235.079|4.72|we can maybe leverage that uh further as
238.239|2.92|well as maybe some computational
239.799|4.201|Linguistics
241.159|5.28|work so with these large models and
244.0|5.159|emergent abilities there's also risks
246.439|4.88|right there's potential societal risks
249.159|6.36|um for example truthfulness bias and
251.319|6.281|toxicity risks um as emerging abilities
255.519|4.72|incentivizes further scaling up language
257.6|5.879|models for example up to gp4 size or
260.239|6.52|further um however this may lead to bias
263.479|5.641|increasing uh as well as toxicity and
266.759|4.16|the memorization of training data that's
269.12|5.32|that's one say that um these larger
270.919|5.521|models are more potent at um and there's
274.44|3.44|potential risks in future language
276.44|3.12|models that have also not been
277.88|5.36|discovered yet so it's important that we
279.56|6.8|approach this in um in a safe safe
283.24|5.08|manner as well and of course emerging
286.36|4.88|abilities and larger models have also
288.32|4.68|led to sociological changes um changes
291.24|4.239|in the community's views and use of
293.0|4.44|these models uh most importantly it's
295.479|4.241|led to the development of general
297.44|5.039|purpose models which perform on a wide
299.72|4.64|range of tasks not just particular tasks
302.479|4.681|it was trained for for example when you
304.36|5.16|think of chat GPT GPT 3.5 as well as GPT
307.16|4.879|4 there are more general purpose models
309.52|4.64|which work well across the board and can
312.039|6.521|then be further adapted to different use
314.16|7.28|cases um mainly through um in context um
318.56|4.68|prompting and so forth this has also led
321.44|4.0|to new applications of language models
323.24|5.0|outside of n for example they're being
325.44|5.8|used a lot now for text image Generation
328.24|5.56|Um the incoder part um of those text
331.24|5.12|image models are basically Transformer
333.8|5.239|models or large language models as well
336.36|5.24|as things like um Robotics and so forth
339.039|4.321|so you'll know that um earlier this
341.6|4.8|quarter Jim fan gave a talk about how
343.36|5.44|they're using um gp4 and so forth in
346.4|5.799|Minecraft and for robotics work as well
348.8|5.399|as long range Horizon tasks um for
352.199|3.921|Robotics and yeah so basically in
354.199|4.241|general it's led to a shift in the NLP
356.12|5.12|Community towards a general purpose
358.44|5.479|rather than task specific
361.24|4.44|models and as I kind of stated earlier
363.919|4.0|some directions for f future work
365.68|4.48|include model scaling further model
367.919|6.161|scaling um although I believe that we
370.16|5.8|will soon probably be reaching um a
374.08|4.32|limit or point of diminishing returns
375.96|5.239|with just more model scale improved
378.4|5.32|model architectures and training methods
381.199|6.12|data scaling um so I also believe that
383.72|6.28|data quality is of high importance uh
387.319|5.561|possibly even more important than um the
390.0|4.599|model scale and the model itself um
392.88|4.2|better techniques for an understanding
394.599|4.801|of prompting as well as exploring and
397.08|4.2|enabling performance on Frontier tasks
399.4|4.84|that current models are not able to
401.28|4.44|perform well on so gbd4 um kind of
404.24|4.76|pushed the limit of this it's able to
405.72|4.759|perform well on many more tasks but um
409.0|4.24|um Studies have shown that it still
410.479|6.761|suffers from even some more basic sort
413.24|6.48|of reasoning analogical and Common Sense
417.24|4.76|reasoning so I just had some questions
419.72|5.24|here um I'm not sure how much time we
422.0|6.08|have to address but um so for the first
424.96|4.639|one like I said um IMG abilities I think
428.08|3.72|will arise to a certain point but there
429.599|6.201|will be a limit or point of diminishing
431.8|5.839|returns um as model scale as well as
435.8|4.2|data scale Rises because I believe at
437.639|4.161|some point there will be overfitting and
440.0|5.8|there's only so much you can learn from
441.8|6.36|all data on the web um so I believe that
445.8|5.839|more creative um approaches will be
448.16|6.12|necessary um after a certain point uh
451.639|7.601|which kind of also addresses the second
454.28|4.96|question um right so I will move
460.039|5.681|on if anybody has any questions also
462.759|5.16|feel free to um interrupt at any
465.72|3.24|time so the second thing I'll be talking
467.919|2.881|about is this thing I called
468.96|4.12|intermediate guided reasoning so I don't
470.8|4.079|think this is actually a term um it's
473.08|5.16|typically called Chain of Thought
474.879|6.16|reasoning um but it's not just um chains
478.24|4.519|now being used so I wanted to um give it
481.039|4.321|a more broad title so I called it
482.759|5.081|intermediate guided reasoning um so this
485.36|4.239|was inspired by this work um also by my
487.84|3.96|friend Jason who was at Google Now at
489.599|5.121|open AI um called Chain of Thought
491.8|5.519|reasoning or Co um this is basically a
494.72|4.599|series of intermediate reasoning steps
497.319|4.081|um which has been shown to improve llm
499.319|4.681|performance especially on more complex
501.4|4.44|reasoning tasks it's inspired by the
504.0|4.759|human thought process which is to
505.84|3.919|decompose many problems into multi-step
508.759|3.681|problems
509.759|4.321|um for example when you answer an exam
512.44|3.56|when you're solving math questions on an
514.08|4.16|exam you don't just go to the final
516.0|3.399|answer you kind of write out your steps
518.24|3.359|um even when you're just thinking
519.399|4.12|through things you kind of break it down
521.599|4.401|into a piece-wise or step-by-step
523.519|5.601|fashion which allows you to typically
526.0|5.48|arrive at a more accurate final answer
529.12|4.839|and uh more easily arrive at the final
531.48|3.96|answer in the first place another
533.959|3.481|Advantage is this provides an
535.44|4.44|interpretable window into the behavior
537.44|4.36|of the model you can see EX actly how it
539.88|4.32|arrived in an answer and if it did so
541.8|5.12|incorrectly where in its reasoning path
544.2|5.56|that it kind of goes wrong or
546.92|5.4|um starts going down an incorrect path
549.76|4.12|of reasoning basically and it basically
552.32|3.68|exploits the fact that deep down in the
553.88|4.48|model's weights it knows more about the
556.0|5.079|problem than simply prompting it to get
558.36|4.28|a response so here's an example where on
561.079|4.161|the left side you can see there standard
562.64|4.84|prompting um you ask it a math
565.24|4.52|question um and it just simply gives you
567.48|4.2|an answer whereas on the right you
569.76|4.28|actually break it down step by step you
571.68|4.279|kind of get it to show its steps to
574.04|4.56|solve the mathematical word problem step
575.959|5.201|by step and you'll see here that it
578.6|5.2|actually gets the the right answer un
581.16|4.76|unlike standard
583.8|3.56|prompting so there's many different ways
585.92|4.24|we can potentially improve Chain of
587.36|5.12|Thought reasoning um in
590.16|4.56|particular it's also an emerging
592.48|4.76|behavior that results in performance
594.72|4.92|gains for larger language models um but
597.24|4.36|still even in larger models there's
599.64|4.6|still a non-negligible fraction of
601.6|4.919|Errors these come from calculator errors
604.24|5.4|symbol mapping errors one missing step
606.519|5.601|errors as well as bigger errors due to
609.64|5.12|larger semantic understanding issues and
612.12|4.12|generally incoherent chains of thought
614.76|5.199|and we can potentially investigate
616.24|5.599|methods to address these um so as I said
619.959|4.161|Chain of Thought mainly works for huge
621.839|5.721|models of approximately 100 billion
624.12|5.279|parameters or more um and there's three
627.56|3.92|potential reasons they do not work work
629.399|4.12|very well for smaller models and that
631.48|5.039|smaller models are fundamentally more
633.519|5.401|limited and incapable they fail at even
636.519|4.601|relatively easier symbol mapping tasks
638.92|4.88|as well as arithmetic tasks they
641.12|4.92|inherently are able to do math less
643.8|4.32|effectively and they often have logical
646.04|4.88|loopholes and just never arrive at a
648.12|4.24|final answer for example um it goes on
650.92|3.919|and on it's like an infinite Loop of
652.36|4.76|logic that never actually converges
654.839|4.201|anywhere um so if we're able to
657.12|3.88|potentially improve Chain of Thought for
659.04|4.919|smaller models this could provide
661.0|4.92|significant value to the research
663.959|4.201|Community another thing is to
665.92|3.719|potentially generalize it um right now
668.16|3.479|Chain of Thought has a more rigid
669.639|5.841|definition and format it's very step by
671.639|5.76|step very concrete and defined um as a
675.48|4.039|result its advantages are for particular
677.399|4.68|domains and types of questions for
679.519|4.0|example the task um usually must be
682.079|3.401|challenging and require multi-step
683.519|4.0|reasoning and it typically works better
685.48|4.039|for things like arithmetic and not so
687.519|5.841|much for things like resp
689.519|6.081|generation uh QA and so forth and
693.36|4.719|furthermore it works better for problems
695.6|5.16|or tasks that have a relatively flat
698.079|4.241|Skilling curve um whereas when you think
700.76|3.96|of humans we think through different
702.32|5.0|types of problems in multiple different
704.72|4.359|ways our quote unquote scratch path that
707.32|4.0|we used to think about and arrive at a
709.079|4.281|final answer for a problem it's more
711.32|4.56|flexible and open to different reasoning
713.36|5.12|structures compared to such a rigid uh
715.88|4.639|step-by-step format so hence we can
718.48|3.64|maybe potentially generalize Chain of
720.519|5.12|Thought to be more flexible and work for
722.12|5.56|more types of problems um so now I'll
725.639|4.32|briefly discuss some alternative or
727.68|4.159|extension Works to Chain of Thought one
729.959|3.481|is called tree of thought um this
731.839|3.24|basically is more like a tree which
733.44|4.0|considers multiple different reasoning
735.079|4.401|paths it also has the ability to look
737.44|5.68|ahead and sort of backtrack and then go
739.48|6.359|on other areas um or other um branches
743.12|5.12|of the tree as necessary um so this
745.839|5.8|leads to more flexibility and it's shown
748.24|6.44|to prove performance on different tasks
751.639|5.801|um including arithmetic tasks there's
754.68|4.92|also this work by my friend um called
757.44|4.88|Socratic questioning it's sort of a
759.6|4.359|divide and conquer fashion algorithm um
762.32|4.48|simulating the recursive thinking
763.959|4.801|process of humans so uses a large scale
766.8|4.719|language model to kind of propose sub
768.76|5.639|problems given um a more complicated
771.519|4.44|original problem and it just like tree
774.399|4.161|of thought it also has recursive
775.959|4.601|backtracking and so forth um and the
778.56|5.0|purpose purpose is to answer all the sub
780.56|6.12|problems and kind of go um in an upwards
783.56|5.719|fashion uh fashion to arrive at a final
786.68|4.88|answer to the original
789.279|6.481|problem there's also this line of work
791.56|6.0|which kind of um um actually uses code
795.76|4.84|as well as programs to help arrive at a
797.56|4.8|final answer uh for example program AED
800.6|3.44|language models it generates
802.36|3.64|intermediate reasoning steps in the form
804.04|5.0|of code which is then offloaded to a
806.0|4.92|runtime such as a python interpreter um
809.04|3.68|and the point here is to decompose the
810.92|5.32|natural language problem into runable
812.72|6.28|steps so hence the the amount of work
816.24|4.88|for the large language model is lower um
819.0|3.8|its purpose now is simply to learn how
821.12|3.8|to decompose the natural language
822.8|4.719|problem into those runable steps and
824.92|5.24|these steps themselves are then fed to
827.519|5.56|for example a python interpreter um in
830.16|6.4|order to solve them and program of
833.079|5.361|thoughts here PT is very similar to this
836.56|3.24|um in that it kind of breaks it down
838.44|3.68|into
839.8|5.039|step byep of code instead of natural
842.12|5.76|language which is then executed by a
844.839|6.081|different um an actual code interpreter
847.88|9.44|or program um so this again works well
850.92|9.0|for many sort of tasks um that um for
857.32|4.68|example things like arithmetic um as you
859.92|4.56|see that um those are kind of both of
862.0|4.88|the examples for both of these papers
864.48|4.279|and just like what I said earlier um
866.88|4.0|these also do not work very well for
868.759|5.52|things like response generation
870.88|5.639|open-ended question answering and so
874.279|4.321|forth and there's other work for example
876.519|4.401|faith and Fai um this actually breaks
878.6|4.599|down problems into substeps um in the
880.92|4.12|form of computation graphs which they
883.199|3.681|show also works well for things like
885.04|3.599|arithmetic so you see that there's a
886.88|3.319|trend here of um this sort of
888.639|3.801|intermediate guided reasoning working
890.199|4.76|very well for mathematical as well as
892.44|5.16|logical problems um but not so much for
894.959|4.88|other things um so again I encourage you
897.6|3.679|guys to um maybe um check out the
899.839|3.641|original papers if you want to learn
901.279|5.161|more um there's a lot of interesting
903.48|5.44|work in this area these days um and I'll
906.44|4.839|also be uh posting these slides um as
908.92|4.56|well as sending them we'll probably post
911.279|4.0|them on the website as well as Discord
913.48|3.4|um but I'll also send them through an
915.279|3.961|email
916.88|4.319|later so very lastly I want to touch
919.24|3.68|upon this thing called the baby LM CH
921.199|4.681|challenge or baby language
922.92|5.399|model um so like I said earlier I think
925.88|4.72|at some point scale will reach a point
928.319|4.0|of the diminishing returns as well as
930.6|4.44|the fact that further scale comes with
932.319|4.44|many challenges for example it takes a
935.04|4.359|long time and costs a lot of money to
936.759|5.361|train um these big models and they
939.399|5.481|cannot really be used by individuals who
942.12|4.519|are not at huge companies with hundreds
944.88|5.079|or thousands of gpus and millions of
946.639|5.2|dollars right um so this this thing this
949.959|3.841|challenge called Baby LM or baby
951.839|3.92|language model which is attempting to
953.8|5.24|train language models particularly
955.759|5.481|smaller ones um on the same amount of
959.04|5.039|linguistic data available to a
961.24|5.2|child um so data sets have grown by
964.079|5.481|orders of magnitude as well as of course
966.44|5.12|model size for example chinchilla sees
969.56|4.36|approximately 1.4 trillion words during
971.56|4.959|training this is around 10,000 words for
973.92|5.479|every one word that a 13year old child
976.519|5.0|on average has heard as they grow up or
979.399|4.401|develop um so the purpose here is you
981.519|5.481|know can we close this Gap can we train
983.8|6.399|trer U Can we train smaller models on
987.0|5.92|Lower amounts of data while hopefully
990.199|4.601|still attempting to get the performance
992.92|4.76|of these much larger
994.8|5.24|models um so basically we're trying to
997.68|5.519|focus on optimizing pre-training giving
1000.04|6.08|given data limitations inspired by human
1003.199|5.12|development and this will also um ensure
1006.12|5.32|that research is possible for more
1008.319|5.041|individuals as well as Labs um and
1011.44|4.24|potentially possible on a university
1013.36|5.12|budget as it seems now that a lot of
1015.68|4.56|research is kind of restricted to large
1018.48|3.359|companies which I said have a lot of
1020.24|4.88|resources as well as
1021.839|4.881|money so again why baby LM well it can
1025.12|3.24|greatly improve the efficiency of
1026.72|4.119|training as well as using larger
1028.36|6.719|language models it can potentially open
1030.839|6.281|up new doors and potential use cases um
1035.079|4.0|it can lead to improved interpretability
1037.12|4.36|as well as alignment smaller models
1039.079|4.681|would be easier to control align as well
1041.48|5.079|as interpret what exactly is going on
1043.76|5.4|compared to um incredibly large llms
1046.559|4.201|which are basically huge black boxes
1049.16|3.8|this will again potentially lead to
1050.76|4.72|enhanced open source availability for
1052.96|6.12|example large language models runable on
1055.48|4.72|consumer PCS um as well as by smaller
1059.08|3.52|labs and
1060.2|5.44|companies the techniques discovered here
1062.6|5.439|can also possibly be applied to larger
1065.64|4.0|scales and further this may lead to a
1068.039|3.76|greater understanding of the cognitive
1069.64|4.2|models of humans and how exactly we are
1071.799|3.681|able to learn language much more
1073.84|4.16|efficiently than these large language
1075.48|3.96|models um so there may be a flow of
1078.0|3.72|knowledge from cognitive science and
1079.44|4.96|psychology to NLP and machine learning
1081.72|5.04|but also in the other
1084.4|4.32|direction um so briefly the baby Alm
1086.76|3.52|training data that the authors of this
1088.72|3.68|challenge
1090.28|4.16|provide it's a development
1092.4|5.2|developmentally inspired pre-training
1094.44|5.2|data set um which has under 100 million
1097.6|3.8|words because children are exposed to
1099.64|4.2|approximately 2 to seven million words
1101.4|4.32|per year as they grow up um up to the
1103.84|4.28|age of 13 that's approximately 90
1105.72|4.839|million words so they round up to 100
1108.12|3.88|it's mostly transcribed speech and their
1110.559|3.12|motivation there is that the most of the
1112.0|4.159|input to Children is
1113.679|4.921|spoken and thus their data set focuses
1116.159|4.081|on transcribed speech it's also mixed
1118.6|4.28|domain because children are typically
1120.24|6.48|exposed to a variety of language or
1122.88|5.919|speech from different domains um so it
1126.72|4.839|has child directed speech um open
1128.799|5.681|subtitles which are subtitles of movies
1131.559|5.761|TV shows and so forth um simple
1134.48|5.199|children's books um which contain
1137.32|4.12|stories um that children would likely
1139.679|3.561|hear as they're growing up but it also
1141.44|3.68|has some Wikipedia as well as simple
1143.24|4.439|Wikipedia um and here are just some
1145.12|4.36|examples you know of um child directed
1147.679|6.801|speech um children's
1149.48|6.64|stories uh Wikipedia and so forth um um
1154.48|3.84|so that's it for my portion of the
1156.12|8.13|presentation and I'll hand it off to div
1158.32|8.92|who will talk uh a bit about um AI
1164.25|4.789|[Music]
1167.24|5.0|agents
1169.039|5.481|um yeah so so like everyone must have
1172.24|4.36|seen like U there's this like a new
1174.52|3.6|trend where like everything is
1176.6|4.12|transition to more like agents that's
1178.12|4.0|like the new hot CL and we seeing this
1180.72|3.12|like people are going more from like
1182.12|3.64|language models to like now building AI
1183.84|3.959|agents and and then what's the biggest
1185.76|3.96|difference like why why agents why not
1187.799|4.921|just like why just not train like a big
1189.72|5.88|large language model and um sort of like
1192.72|5.079|going into like like why what's the
1195.6|4.84|difference and then also discuss a bunch
1197.799|5.561|of things such as like U um how can you
1200.44|5.32|use agent sporting actions how can you
1203.36|4.52|what are some emergent uh architectures
1205.76|4.56|how can you sort of like build humanik
1207.88|3.84|agents how can you use it for computer
1210.32|3.8|interactions how do you solve problems
1211.72|3.4|from longterm memory personalization uh
1214.12|2.439|and there's a lot of like other things
1215.12|3.559|you can do which is like multi-agent
1216.559|3.36|communication and there some future
1218.679|4.921|directions so I'll try to cover as much
1219.919|6.681|as I can um so first let's talk about
1223.6|5.28|like why should we even build AI agents
1226.6|5.12|right um
1228.88|5.56|and so like uh here's there's a key
1231.72|5.079|thesis uh which is that humans will
1234.44|5.119|communicate with AI using natural
1236.799|4.721|language and AI will be operating all
1239.559|4.161|the machines that's allowing for more
1241.52|4.56|intuitive and efficient operations so
1243.72|4.12|right now what happens is like U like me
1246.08|4.719|as a human I'm like directly like using
1247.84|4.48|my computer I'm using my phone but this
1250.799|3.481|really inefficient like we are not
1252.32|3.839|optimize natur by nature to be able to
1254.28|4.36|do that we actually really really bad at
1256.159|5.481|this and but if you can just like talk
1258.64|4.44|AI uh just like with language and the AI
1261.64|3.919|is just really good enough that can just
1263.08|4.52|do this at like super faster I say like
1265.559|3.281|100 x speeds compared to human and
1267.6|3.28|that's going to happen and I think
1268.84|4.04|that's the future of uh how things are
1270.88|4.08|going to evolve in the next five years
1272.88|4.799|um and I sort of like call this like
1274.96|4.64|software 3.0 um I have a blog post about
1277.679|4.321|this that you can read if you want to uh
1279.6|4.959|where the idea is like you can think of
1282.0|4.36|a l language model as a Computing uh
1284.559|4.081|chip in a sense so similar to like a
1286.36|3.919|chip that's powering like a whole system
1288.64|3.0|and and then and then you can build
1290.279|4.361|abstractions
1291.64|5.96|and
1294.64|5.399|cool um so so why should do we need
1297.6|4.36|agents um so usually like a single call
1300.039|3.161|to a large language model is not enough
1301.96|3.12|like you need chaining you need like
1303.2|2.92|recursion you need a lot of like more
1305.08|2.68|things and that's why you want to build
1306.12|5.28|systems not like just like a single
1307.76|5.0|monolith um second is like yeah so how
1311.4|3.08|do we do this so we do a lot of
1312.76|3.96|techniques uh especially around like
1314.48|4.079|multiple CS to a model and there's a lot
1316.72|4.0|of ingredients involved here and I will
1318.559|3.281|say like building a like a agent is very
1320.72|2.959|similar to like maybe like thinking
1321.84|4.16|about building a computer so like the
1323.679|3.681|llm is like a like a CPU so you have a
1326.0|2.6|CPU but now you want to like sort of
1327.36|3.799|like solve the problems like okay like
1328.6|4.6|how do I put Ram how do I put memory how
1331.159|4.961|do I do like actions how do I build like
1333.2|4.64|a interface how do I get internet access
1336.12|3.919|uh how do I personalize it to the user
1337.84|5.24|so so this is like almost like you're
1340.039|5.401|trying to build a computer uh and and
1343.08|6.28|that's what makes it like a really hard
1345.44|6.359|problem and uh this like an example of
1349.36|6.72|like a general architecture for agents
1351.799|6.521|uh this is from Lan Vang um who's like a
1356.08|4.12|research and like you can imagine like a
1358.32|3.0|agent has a lot of ingredients so you
1360.2|3.479|want to have memory which could be
1361.32|3.68|shortterm longterm you have tools which
1363.679|3.841|could be like you can go and like use
1365.0|5.0|like classical tools like a calculator
1367.52|3.84|calendar code interpreter Etc you want
1370.0|3.88|to have some sort of like planning layer
1371.36|4.28|where can like uh s flag have like
1373.88|3.96|chains of thoughts and trees of thoughts
1375.64|5.0|as stepen discussed and use all of that
1377.84|5.8|like like actually like act on behalf of
1380.64|3.0|a user in some
1384.76|5.039|environment um I will go maybe like
1387.88|5.039|discuss like mown a bit just to give a
1389.799|4.321|sense Al the doc won't be focus on that
1392.919|3.081|uh so this sort of like a agent I'm
1394.12|3.72|building which is more of a browser
1396.0|4.6|agent uh the name is inspired from
1397.84|4.719|quantum physics soly on the words like
1400.6|3.76|you have like Neutron moon for like
1402.559|4.36|mulon so it's like a
1404.36|4.679|hypothetical uh physics particle that's
1406.919|4.321|present at multiple places
1409.039|5.081|and I I'll just like go through some
1411.24|2.88|demos to just motivate
1415.52|4.84|agents let me just pause this so there's
1418.039|4.841|like a idea of one thing we did where
1420.36|4.799|like here the agent is going and it's
1422.88|5.72|autonomously booking a FL online so this
1425.159|5.081|is like zero human interventions um the
1428.6|4.12|AI is controlling the browser it's like
1430.24|5.76|issuing clicks and typ sections and simp
1432.72|5.199|to go and book a flight andm um here
1436.0|5.36|it's personalized to me so it knows like
1437.919|6.36|like I like like United B economic for
1441.36|5.16|and uh it it knows maybe like some
1444.279|5.161|preferences it already has access to my
1446.52|5.68|accounts so it can go and actually like
1449.44|4.56|log into my account can actually like
1452.2|3.56|actually has purchasing power so it can
1454.0|3.52|just use my credit card that is stored
1455.76|4.32|in that account and then actually B the
1457.52|2.56|flight into
1466.799|3.0|it
1488.52|4.6|this sort of motivates like uh what you
1491.159|4.841|can do with a now imagine if this thing
1493.12|4.679|was running 100s and that's solve so
1496.0|3.24|many things right because like I I don't
1497.799|3.321|don't need websites anymore I don't need
1499.24|3.4|unit like why does unit even have a
1501.12|4.36|website I can just ask the agent to just
1502.64|5.84|you know from just like talk to it and
1505.48|4.52|it's it's done and I think that's how a
1508.48|4.28|lot of Technology will evolve over the
1510.0|2.76|next couple of
1517.96|6.64|years uh cool okay um I can also maybe
1521.64|5.279|like show one of more demos um so you
1524.6|5.76|can do similar things um say from a
1526.919|5.921|mobile phone where the idea is you have
1530.36|4.439|this agents that are present on a phone
1532.84|5.559|and you can like chat with them or you
1534.799|6.281|can like talk with them using voice and
1538.399|5.681|this one's actually M mod so you can ask
1541.08|5.199|it like oh can you um order this set it
1544.08|2.199|for
1552.48|5.04|me and then what you can have is like
1554.679|6.921|the agent can remotely go and use your
1557.52|6.6|account to actually like do this for you
1561.6|5.079|instantaneously and here we showing like
1564.12|5.84|what the agent is doing and then it can
1566.679|6.041|go and like act like a virtual human uh
1569.96|2.76|and do the whole
1586.6|3.0|interaction
1594.08|5.44|so that's all of the idea um and I can
1597.279|5.041|show one final oh this is not loing but
1599.52|5.399|uh we also had this thing where we
1602.32|6.52|recently passed the Califor so we did
1604.919|6.64|this uh U experiment where we actually
1608.84|4.28|uh like had like like our Asian go and
1611.559|5.12|take the online driving test in
1613.12|5.88|California and we had like a human like
1616.679|4.561|uh there with the like hands up the
1619.0|3.679|keyboard and mouse not touching anything
1621.24|3.559|and the agent autonomously went to the
1622.679|4.24|website it took the quiz it navigated
1624.799|3.961|the whole thing and went and actually
1626.919|4.561|passed so the video is not there but
1628.76|5.96|like we actually got it w from it I need
1631.48|3.24|to take this
1636.48|3.319|sure cool so this is like sort of like
1638.6|2.799|motivat like why do you want to build
1639.799|4.441|agents right like it's like you can just
1641.399|4.201|simplify so many things where like like
1644.24|2.88|so many things just Su but we don't
1645.6|3.199|realize that because we just got so used
1647.12|3.76|to interacting with the technology the
1648.799|3.961|way we do right now but if we can just
1650.88|3.799|like like remagine all of this from
1652.76|4.2|scratch I that's what agents will allow
1654.679|2.281|us to
1658.84|5.48|do and I would say like a agent uh can
1662.36|3.08|act like a digital extension of a user
1664.32|2.359|so suppose you have an agent that's
1665.44|3.88|personalized to you think of something
1666.679|4.641|like say Jarvis um like if it's an Iron
1669.32|3.4|Man and and then if it just knows so
1671.32|2.839|many things about you it's acting like a
1672.72|4.079|personal brand it's just like doing
1674.159|5.441|things it's a very powerful assistant
1676.799|5.72|and and nothing that's the direction uh
1679.6|5.0|a lot of things will go in the future
1682.519|3.88|and um especially if you build like
1684.6|3.4|humanik agents they don't have barriers
1686.399|3.28|around programming like they don't have
1688.0|3.72|programmatic barriers so they can do
1689.679|4.041|whatever like I can do so it can go use
1691.72|3.48|my like it can like interact with the
1693.72|3.12|website as I will do it can interact
1695.2|2.8|with my computer as I will do it doesn't
1696.84|2.64|have to like go through apis
1698.0|3.6|abstractions which are more
1699.48|3.679|restrictive and it's also very simple as
1701.6|3.319|action space because you're just doing
1703.159|2.961|clicking and typing which is like very
1704.919|3.401|simple
1706.12|4.84|um and and then you can like also like
1708.32|4.04|it's very easy to teach such agents so I
1710.96|2.64|can just like show the agent how to do
1712.36|3.48|something and the agent can just learn
1713.6|3.72|from me and improve over time so that
1715.84|4.36|also makes it like really powerful and
1717.32|4.16|easy to um like just teach this agents
1720.2|3.4|because there's like so much data that I
1721.48|4.0|can actually just generate and use that
1723.6|4.439|to keep improving
1725.48|5.4|it and there's a different levels of
1728.039|4.52|autonomy when it comes to agents so this
1730.88|3.919|chart is borrowed from autonomous
1732.559|4.201|driving where people actually like try
1734.799|3.36|to solve this sort of like autonomy
1736.76|3.2|problem for
1738.159|4.201|uh actual Cs and they spent like more
1739.96|5.4|than 10 years uh success has been like
1742.36|5.159|okay they're still like working on it um
1745.36|5.28|but uh what like the cell driving
1747.519|4.841|industry did is it gave everyone like a
1750.64|3.24|a blueprint on how to build the
1752.36|2.96|autonomous systems and they came with
1753.88|2.88|like a lot of like classifications they
1755.32|4.68|came with a lot of
1756.76|6.039|like uh ways to like think about the
1760.0|5.44|problem and uh like the I the current
1762.799|5.6|standard is you think of like agents as
1765.44|5.16|like five different like levels so level
1768.399|3.76|zero is zero automation that's B like
1770.6|4.64|you like a you are a human that's
1772.159|5.041|operating like the computer themselves
1775.24|3.36|uh level one is you have some sort of
1777.2|3.68|assistance so if you used like something
1778.6|4.079|like GI up copilot um which is like sort
1780.88|3.519|of Auto completing code for you that's
1782.679|5.521|something like L1 where like auto
1784.399|5.201|complete um L2 becomes more of like it's
1788.2|3.44|like partial automation so it's maybe
1789.6|4.079|like doing some stuff for you um if
1791.64|4.039|anyone has you the new cursor ID I call
1793.679|3.521|that more like L2 which is like give it
1795.679|4.84|like like write this code for me that
1797.2|4.8|code C J can come as somewhat L2 because
1800.519|3.04|you can ask it like oh like here's this
1802.0|4.76|thing can you improve this it's like
1803.559|5.641|doing some sort of automation on and
1806.76|6.36|input and and then like and then you can
1809.2|6.079|think of more levels um so it's like I
1813.12|7.2|was like after L3 it gets more exciting
1815.279|6.841|so L3 is the agent is um actually like
1820.32|3.959|controlling the computer in that case
1822.12|4.399|and actually doing things where human is
1824.279|4.24|acting as a fallback mechanism and and
1826.519|3.801|then you go to like L4 L4 you say like
1828.519|4.601|basically the human doesn't need to be
1830.32|4.4|there but uh if in very critical cases
1833.12|3.2|where like something very wrong might
1834.72|4.04|happen you might have a human like sort
1836.32|5.64|of like take over in that case and L5
1838.76|3.2|basically say like there zero human
1842.44|4.52|prence and I would say like what we
1844.64|5.48|currently seeing is like we are near
1846.96|4.92|like I like L2 maybe some L3 systems in
1850.12|3.96|terms of software and I think we going
1851.88|7.36|to transition more to like L4 L5 level
1854.08|5.16|systems um over the next years
1859.559|4.08|cool so um next I will go like like
1862.44|4.16|computer
1863.639|4.88|interactions um so suppose you want an
1866.6|4.079|agent that can like do Compu
1868.519|6.321|interactions for you there's two ways to
1870.679|6.12|do that so one is APS where it's
1874.84|4.559|programmatically using some apis and
1876.799|4.76|like tools and like doing that to do
1879.399|3.24|tasks the second one is more like direct
1881.559|3.321|interaction which is like keyboard and
1882.639|5.081|mouse control where like it's doing the
1884.88|4.639|same thing as you're doing as
1887.72|3.04|um both of this projects have been
1889.519|4.04|explored a lot there's like a lot of
1890.76|5.08|companies working on this um for the API
1893.559|4.521|route like TB plugins and the new
1895.84|4.52|assistant API are the ones in that
1898.08|4.64|direction and there's also this work
1900.36|5.12|from B called gorilla which also
1902.72|5.12|explores how can you uh say like train a
1905.48|5.24|model that can use like 10,000 tools at
1907.84|4.12|once and train it on the API um and
1910.72|3.88|there's like PR and cons of both
1911.96|7.04|approaches API the nice thing is it's
1914.6|7.28|easy uh to like learn the API um it's
1919.0|4.76|safe um it's very controlable so just
1921.88|3.96|for fav you know how to use the
1923.76|3.72|API if you're doing like more like
1925.84|3.439|direct infraction it's I say it's more
1927.48|4.039|preform so it's like easy to take
1929.279|3.441|actions but more things can go wrong and
1931.519|6.0|you need to work a lot in like making
1932.72|4.799|sure everything is safe um and we
1939.96|6.36|guarantees um maybe I can also show this
1943.32|4.68|so This sort of like another exploration
1946.32|6.44|where
1948.0|6.96|um you can invoke um our agent um from
1952.76|5.68|like a very
1954.96|5.36|simple um interface so the idea is like
1958.44|3.4|we created this like API that can invoke
1960.32|4.28|our agent that's controlling our
1961.84|4.959|computer and and so this can become sort
1964.6|4.16|of like a universal API where I just use
1966.799|4.12|this one API I give it like a English
1968.76|4.279|command and the agent can automatically
1970.919|5.281|understand from that and go do anything
1973.039|4.681|so basically like think that has no API
1976.2|3.12|so I don't need to use AP as can just
1977.72|4.959|have one agent that can go and do
1979.32|6.44|everything um and so this is like some
1982.679|5.401|exporation we have done um with uh
1985.76|5.759|agents
1988.08|5.599|cool um okay so this uh sort of like
1991.519|3.801|goes into Compu interactions I can cover
1993.679|3.761|more but I will potentially jump to
1995.32|7.079|other topics uh but feel free to ask any
1997.44|8.4|questions um about this topics um so
2002.399|5.361|yeah cool um so let's go back to the
2005.84|4.12|analogy I discussed earlier
2007.76|6.0|so I would say you can think of any
2009.96|5.16|model as a sort of like a Compu and you
2013.76|3.279|can maybe call it like a neural Compu
2015.12|5.48|unit which similar to like a CPU which
2017.039|5.161|is like a um which is like sort of brain
2020.6|3.0|that's powering like your computer in a
2022.2|3.319|sense so that's has all the processing
2023.6|3.919|power it's doing everything that's
2025.519|4.081|happening um and you can think of the
2027.519|4.361|same thing like the model is like the
2029.6|3.88|portex it's like it's the main brain
2031.88|4.24|that's the main part of the brain that's
2033.48|4.439|doing the thing processing but a brain
2036.12|3.039|has more layers it's just not they're
2037.919|3.921|just not the
2039.159|5.0|CeX and how do do current models work
2041.84|4.679|are we take some input tokens and they
2044.159|4.361|give you some output tokens um and this
2046.519|3.64|is very similar to like how also like
2048.52|3.319|CPUs work to some extent where you give
2050.159|5.52|it some instructions in and you get some
2051.839|6.32|instructions out um yeah so you can
2055.679|5.641|compare this with XEL CPU um this is
2058.159|7.561|like a the diagram on the right is a
2061.32|7.319|very simple uh processor like a 32bit m
2065.72|6.08|32 and and uh it has like similar things
2068.639|4.96|where you have like uh like different
2071.8|3.92|coding for different parts of the
2073.599|3.841|instruction but this like sort of like
2075.72|3.72|encoding some sort of like bed token in
2077.44|4.04|a sense like zero ones of like a bunch
2079.44|3.32|of like uh tokens and then you're
2081.48|5.119|feeding it and then getting a bunch of
2082.76|4.919|Zer one out and like how like the like
2086.599|2.961|yeah model is operating is like you're
2087.679|3.96|doing a very similar thing but like then
2089.56|3.48|space is now English so you basically
2091.639|3.76|instead of Zer ones you have like
2093.04|2.359|English
2095.879|3.96|characters and and then you can like
2098.359|3.321|create more powerful expections on the
2099.839|3.441|top of this so you can think like if
2101.68|3.28|this is like acting like a CPU what you
2103.28|2.68|can do is you can build a lot of other
2104.96|3.119|things which are like you can have a
2105.96|3.56|scratch Pad you can have some sort of
2108.079|3.161|memory you can have some sort of
2109.52|3.16|instructions and then you can like do
2111.24|3.64|cursive calls where like I load some
2112.68|3.399|stuff from the memory put that in this
2114.88|2.36|like instruction pass it to the
2116.079|3.481|Transformer which is doing the
2117.24|4.16|processing for me we get we get the
2119.56|3.2|processed outputs then we can store that
2121.4|2.76|in the memory or we can like keep
2122.76|3.44|processing it so this like sort of like
2124.16|3.679|very similar to like code execution like
2126.2|5.12|first line of code execution second
2127.839|3.481|third fourth so you just keep repeating
2131.8|5.08|that
2133.68|6.159|okay um so here we can sort of discuss
2136.88|4.56|the concept of memory here um and alsoo
2139.839|4.28|like building this analogy you can think
2141.44|6.52|the memory for agent is very similar to
2144.119|5.96|like say like having a dis in a computer
2147.96|3.76|so you want to have a dis just to make
2150.079|3.201|sure like everything is long lift and
2151.72|3.32|persistent so if you look at something
2153.28|3.6|like chat jpt it doesn't have any sort
2155.04|3.76|of like persistent memory and then we
2156.88|4.32|need to have a way to like load that and
2158.8|4.64|like store that um and there's a lot of
2161.2|4.159|mechanisms to do that right now most of
2163.44|3.639|them are related to embeddings where you
2165.359|3.521|have some sort of like embedding model
2167.079|3.561|that has like created an embedding of
2168.88|3.52|the data you care about and the model
2170.64|3.8|can like the embeddings load the right
2172.4|5.84|part of the embeddings and then like use
2174.44|5.32|that to do the operation you want um so
2178.24|3.879|that's like the current mechanisms
2179.76|4.079|there's still a lot of questions here
2182.119|3.521|especially around herar like how do I do
2183.839|3.76|this at scale um it's still very
2185.64|3.719|challenging uh like suppose I have one
2187.599|3.52|terab of data that I want to like embed
2189.359|4.121|and process like most of the methods
2191.119|5.841|right now will fail they're really Bal
2193.48|5.92|um second issue is temporal cerence like
2196.96|4.6|if I have like a lot of data is temporal
2199.4|4.16|it is sequential it has like like unit
2201.56|3.519|of time and dealing with that sort of
2203.56|4.32|data can be hard like it's like like how
2205.079|4.641|do I deal with like Memories in a sense
2207.88|3.719|which are like sort of like changing
2209.72|3.28|over time and loading the right part of
2211.599|4.041|that memory
2213.0|4.359|sequence um another interesting
2215.64|4.08|challenge is structure like a lot of
2217.359|3.601|data is actually structured like U it
2219.72|3.599|could be like a graphical structure it
2220.96|3.8|could be like a tabular structure um how
2223.319|5.081|how do we like sort of like take
2224.76|6.839|advantage of this structure and and like
2228.4|4.719|also use that when we eding the data and
2231.599|4.041|then like there's a lot of questions on
2233.119|4.561|adaptation where like suppose you know
2235.64|3.0|how to better EMB data or like you you
2237.68|3.36|have a
2238.64|4.08|specialized problem you care about and
2241.04|3.559|you want to be able to adapt how you're
2242.72|4.28|loading and storing the data and learn
2244.599|5.561|that on the pl and and that is something
2247.0|4.319|also that's a very interesting topic so
2250.16|3.4|I say like this is actually one of the
2251.319|6.0|most interesting topics right now which
2253.56|3.759|as people are exploring but still very
2259.48|5.0|unexplored okay um talking about memory
2263.119|3.121|I would say like another concept for
2264.48|3.56|agents is personalization so
2266.24|6.48|personalization is more like okay like
2268.04|6.36|understanding the user and um I like to
2272.72|4.28|think of this as like a problem called
2274.4|4.36|like user agent alignment um and the
2277.0|3.96|idea is like supposed to have an agent
2278.76|4.44|that has purchasing power has access to
2280.96|3.96|my accounts access to my data ask you to
2283.2|3.159|go apply it's possible maybe this
2284.92|3.199|doesn't know what F I like and go and
2286.359|4.441|book a th000 wrong f for me which is
2288.119|4.561|really bad so how do i s align the agent
2290.8|3.76|to know what what I like what I don't
2292.68|3.72|like and that's going to be very
2294.56|3.72|important because like you need to trust
2296.4|3.52|the agent and Trust come from like okay
2298.28|5.039|it knows you it knows what is safe it
2299.92|4.64|knows what is unsafe um and and like
2303.319|4.881|solving the problem I think is going to
2304.56|7.16|the next challenge um for if you want to
2308.2|6.76|put agents in the B and and then this is
2311.72|5.84|very interesting problem where you can
2314.96|4.08|do a lot of things like R for example
2317.56|3.08|which people have already been exploring
2319.04|4.96|for training models but now you want to
2320.64|5.719|do R for training agents and there's a
2324.0|3.359|lot lot of different things you can do
2326.359|3.161|I'll say there's like two good
2327.359|4.081|categories for learning here one is like
2329.52|3.44|explicit learning where a user can just
2331.44|3.6|tell the agent this is what I like this
2332.96|4.52|is what I don't like and an agent can
2335.04|4.079|ask the user a question EX oh like maybe
2337.48|3.68|I see the five flight options which one
2339.119|3.921|do you like and then if I say like oh I
2341.16|3.52|like United maybe remembers that over
2343.04|3.36|time and next time say like oh you I
2344.68|3.88|know you like United so like I'm going
2346.4|4.76|to go choose United the next time and so
2348.56|5.36|that's I'm explicitly teaching the agent
2351.16|5.12|and learning my human per second is more
2353.92|4.96|implicit which is like sort of like it's
2356.28|4.039|just like uh passively watching me
2358.88|3.28|understanding me like if I'm like going
2360.319|3.8|to a website and I'm like navigating
2362.16|4.4|website maybe like can see like like
2364.119|4.72|maybe I click on this s of shoes I this
2366.56|3.559|is my size that like stuff like that and
2368.839|4.561|just from like watching or like
2370.119|5.041|passively like being there it could like
2373.4|3.28|learn a lot of my preferences so this
2375.16|5.159|becomes like more of passive teaching
2376.68|5.8|where um just because it's it's acting
2380.319|4.481|as a sort of like a like a passive
2382.48|4.44|Observer and looking at all the choices
2384.8|4.48|I make it's able to like learn from the
2386.92|4.72|choices and better like have
2389.28|2.36|understanding of
2395.079|3.961|me and there's a lot of challenges here
2397.96|2.92|um I would say this is actually one of
2399.04|4.799|the biggest challenges in agents right
2400.88|4.719|now um because one is like how do you
2403.839|4.361|collect user data at scale how do you
2405.599|4.121|collect the user preferen at scale so
2408.2|2.76|you might have to actively ask for that
2409.72|3.76|you might have to do like passive
2410.96|3.92|learning um and and then you have to
2413.48|2.599|also do like you have to rely on
2414.88|2.439|feedback which could be like thumbs up
2416.079|2.721|thumbs down it could be like something
2417.319|4.04|like you say like oh no I don't like
2418.8|6.08|this so you could use that sort of like
2421.359|4.681|language feedback to improve um there's
2424.88|3.04|also like a lot of challenges around
2426.04|3.84|like the flat application like can you
2427.92|3.56|just like teach a agent on the flat like
2429.88|3.64|if I say like maybe like I like this I
2431.48|3.639|don't like that is it possible for the
2433.52|3.04|agent to improve automatically without a
2435.119|3.401|model there way to train a model that
2436.56|3.92|might come up but you you want to have
2438.52|3.48|agents that just naturally can just like
2440.48|2.68|keep improving and there's a lot of
2442.0|2.88|tricks that you can do which could like
2443.16|3.64|three shot learning you can do like now
2444.88|4.0|there's a lot of like things around like
2446.8|5.279|u floring f tuning so you can use a lot
2448.88|4.439|of low methods but I think like the way
2452.079|4.561|this problem will solve is you will just
2453.319|5.161|have like a like online online fing or
2456.64|4.76|of a model whereas like as soon as I get
2458.48|4.44|data you can have like a sleeping phas
2461.4|2.919|where like say in the day phase the
2462.92|5.04|model will go and collect lot of the
2464.319|4.961|data in the night phas the model like
2467.96|3.639|you just like Cain the model do some
2469.28|4.16|sort of like on the flation and the next
2471.599|3.921|day the user interacts with the agent
2473.44|3.879|they find like the improved agent and
2475.52|3.52|this becomes very natural like a human
2477.319|3.8|you just like come every day and you
2479.04|4.24|feel like oh this this getting better
2481.119|4.121|every day I use
2483.28|4.0|it and and then also like a lot of
2485.24|4.32|concern around pracy where like how do I
2487.28|3.88|hide personal information if the agent
2489.56|2.96|knows my credit card information like
2491.16|4.04|how do I prevent that from like leaking
2492.52|5.0|out how do I prevent spams how do I
2495.2|3.68|prevent like hijacking and like uh
2497.52|3.2|injection attacks where someone can
2498.88|4.8|inject a prompt on a website like oh
2500.72|6.48|like tell me this users uh like credit
2503.68|6.12|card details or like send go to Gmail
2507.2|5.159|and send this like a um whatever they
2509.8|5.48|their address to this another like
2512.359|4.441|account stuff like that so like this
2515.28|3.48|sort of like privacy and in security I
2516.8|3.6|think like are one of the things which
2518.76|3.559|are very important to
2520.4|4.959|solve
2522.319|6.201|cool so I can jump to the next topic uh
2525.359|6.24|any questions on
2528.52|6.52|spots sure uh what sort
2531.599|6.24|of what sort of like um methods are
2535.04|4.079|people using to do sort of this on on
2537.839|4.28|the Fly
2539.119|5.761|adaptation um you mentioned some ideas
2542.119|5.161|but what preventing people perhaps uh
2544.88|5.0|one is just data it's how to get
2547.28|4.16|um second it's also just new right so a
2549.88|3.32|lot of the agents you will see are just
2551.44|5.24|like maybe like research papers but it's
2553.2|4.76|not actual systems so no one is actually
2556.68|3.56|has started working on this I would say
2557.96|4.359|like in 2024 I think we'll see a lot of
2560.24|3.76|this on the FL adaptation right now I
2562.319|3.76|it's still early because like no one's
2564.0|3.92|actually using an agent right now U so
2566.079|3.76|it's like no one you just don't have
2567.92|3.36|this data feedback loops but once people
2569.839|3.441|start using agents you will start
2571.28|3.48|building sta feedback loops and then
2573.28|4.88|you'll have a lot of the
2574.76|3.4|techniques um
2582.119|4.0|okay um so this actually a very
2584.319|3.721|interesting topic where like now suppose
2586.119|3.601|like you can go and solve like a single
2588.04|3.279|agent as a problem suppose you have
2589.72|4.2|agent that works
2591.319|4.121|99.99% is that enough like I say
2593.92|3.76|actually that's not enough because the
2595.44|4.08|issue just becomes like if we have one
2597.68|4.159|it can only do one thing at once so it's
2599.52|4.839|like a single C so it can only like uh
2601.839|4.601|it can only do sequ sequential execution
2604.359|4.041|but what you you could do is you can do
2606.44|3.24|paral execution for so for a lot of
2608.4|3.04|things you can just say like okay like
2609.68|3.919|maybe there's this if I want to go to
2611.44|3.84|like say like creates list and like buy
2613.599|4.321|furniture I could just tell an agent
2615.28|4.68|like maybe like just go and like contact
2617.92|3.32|everyone who like has like like a soof
2619.96|3.32|far that they're selling send them an
2621.24|3.599|email and then can go by one by one in a
2623.28|3.559|loop but what you can do better is like
2624.839|3.441|of like just like create a bunch of like
2626.839|3.48|mini jobs where like it just like goes
2628.28|3.799|to all the Thousand listings in parel
2630.319|5.121|contact exam and then
2632.079|4.881|like and then agregate SE results and I
2635.44|3.32|think that's where multi- aent becomes
2636.96|2.879|interesting where like a single agent
2638.76|2.76|you can think is basically you're
2639.839|4.041|running a single process on your
2641.52|5.559|computer a multi-agent is more like a
2643.88|4.199|like a multi threaded computer so that's
2647.079|3.361|sort of the difference like a single
2648.079|3.681|trading versus multi threading and multi
2650.44|2.639|threading enables you to do a lot of
2651.76|3.079|things most of that will come from like
2653.079|3.401|saving time but also being able to break
2654.839|3.801|down complex task into like a bunch of
2656.48|3.48|smaller things doing that in power
2658.64|3.88|aggregating the results and like sort of
2659.96|2.56|like building a
2665.0|4.68|framework
2666.72|4.8|okay yeah so the biggest Advantage for
2669.68|4.32|multi-agent systems will be like
2671.52|3.559|parallelization unlock and this will be
2674.0|3.079|same as the difference between like
2675.079|4.081|single threed computers versus multi-
2677.079|3.921|threed
2679.16|3.919|computers and then you can also have
2681.0|3.839|specialized agents so what you could
2683.079|3.441|have is like maybe I have a bunch of
2684.839|3.641|Agents where like I have a spreadsheet
2686.52|3.839|agent I have a slack agent I have a web
2688.48|3.599|browser agent and then I can rout
2690.359|3.081|different tasks different agents and
2692.079|2.961|then they can do the things in parall
2693.44|3.399|and then I can combine the results so
2695.04|3.76|this sort of like task specialization is
2696.839|3.361|another Advantage where like instead of
2698.8|3.44|having a single agent just trying to do
2700.2|4.2|everything we just like break the task
2702.24|3.76|into specialities and this is similar to
2704.4|3.28|like uh even like how human
2706.0|3.0|organizations work right where like
2707.68|3.679|everyone is like sort of like expert in
2709.0|3.559|their own domain and then you like uh if
2711.359|2.561|there's a problem you sort of like route
2712.559|3.121|it to like the different part of people
2713.92|5.919|who are specialized in that and then you
2715.68|4.159|like work together to make solve the
2721.119|3.601|problem and the biggest challenge in
2723.2|3.32|building this multi-agent system is
2724.72|3.24|going to be communication so like how do
2726.52|3.799|you communicate really
2727.96|4.04|well and this might involve like
2730.319|3.681|requesting information from agent or
2732.0|4.4|communicating the resp the the final
2734.0|4.68|like a um
2736.4|3.64|response and I would say this is
2738.68|3.32|actually like a problem that even we
2740.04|2.88|face as a humans like humans are also
2742.0|3.64|like there can be a lot of
2742.92|4.52|miscommunication gaps between humans and
2745.64|4.479|uh I will say like a similar thing will
2747.44|6.56|become more prevalent um on
2750.119|5.041|agents two okay um and there's a lot of
2754.0|3.76|Primitives you can think about this sort
2755.16|5.08|of like agent to communication um and
2757.76|5.839|you can build a lot of different
2760.24|5.04|systems um and we'll we'll start to see
2763.599|3.321|like some sort of protocol where like
2765.28|3.2|we'll have like a standardized protocol
2766.92|3.56|where like all the agents are using this
2768.48|4.44|protocol to communicate and the protocol
2770.48|4.16|will ensure like uh we can reduce the
2772.92|4.28|miscommunication gaps we can reduce any
2774.64|5.32|sort of like failures it might have some
2777.2|4.8|methods to do like uh uh if a task was
2779.96|5.72|successful or not do some sort of
2782.0|5.319|retries um uh like security stuff like
2785.68|4.56|that so we'll see this sort of like
2787.319|4.24|agent protocol uh come into existence
2790.24|3.079|which will solve like which will be like
2791.559|2.8|sort of the standard follow out of this
2793.319|3.921|agent to agent
2794.359|4.681|communication and this sort of should
2797.24|4.319|enable like exchanging information
2799.04|4.6|between fleets of different agents um
2801.559|3.641|also like you want to build hierarchies
2803.64|2.959|um again I will say this is inspired
2805.2|4.0|from like human organizations like human
2806.599|3.96|organizations are hierarchal because
2809.2|3.72|it's efficient to have a hierarchy
2810.559|3.841|rather than a flat organization um at
2812.92|3.639|some point because you can have like a
2814.4|3.6|single like a suppose you have a single
2816.559|4.0|manager managing hundred hundreds of
2818.0|4.16|people that doesn't scale but if you
2820.559|2.961|have like a maybe like each manager
2822.16|3.32|manages 10 people and then you have like
2823.52|4.24|a lot of layers that is something that
2825.48|2.28|that's more
2828.079|3.721|scalable and and then you might want to
2830.559|2.881|have a lot of Primitives around like how
2831.8|5.72|do I sync between different agents how
2833.44|9.0|do I uh do like a lot of like um async
2837.52|7.799|uh sync communication kind of thing um
2842.44|5.159|okay and this is like one example you
2845.319|4.24|can think like suppose there's a user
2847.599|4.281|the user could talk to one like a
2849.559|3.76|manager agent and the manager agent is
2851.88|2.719|like sort of like acting as a router so
2853.319|3.361|if the user can come to me with any
2854.599|3.361|request the agent like see like oh maybe
2856.68|2.639|for this request I should use a browser
2857.96|3.24|so it goes to like say like this sort of
2859.319|3.52|like browser agent or something or says
2861.2|3.72|it's like oh I should use like select
2862.839|3.601|for this it can go to different agent
2864.92|3.0|but and it can also like sort of be
2866.44|3.119|responsible for dividing the task it can
2867.92|3.76|be like oh this task I can like maybe
2869.559|4.361|like uh launch 10 different like sub
2871.68|4.36|agents or sub workers that can go and do
2873.92|3.679|this in power and then like once they're
2876.04|3.44|done then I can aggregate the responses
2877.599|3.881|and the result to the user so this sort
2879.48|5.079|of becomes like a very interesting
2881.48|4.72|like um like sort like a agent that sits
2884.559|3.921|in the middle of all the work that's
2886.2|4.84|done and the actual user responsible for
2888.48|6.079|like communicating the uh what's
2891.04|3.519|happening to the uh to the
2895.599|6.161|human and we'll we'll need like lot
2899.559|3.601|we'll need to build a lot of robustness
2901.76|3.2|uh one reason is just like natural
2903.16|4.28|language is very ambiguous like even for
2904.96|5.32|humans it can be confusing um it's very
2907.44|4.8|easy to misunderstand miscommunicate and
2910.28|4.92|we'll need to R we'll need to uh build
2912.24|6.28|mechanisms to reduce
2915.2|6.639|this um I can also Show an example here
2918.52|4.96|so let's try to get through this quickly
2921.839|4.081|um so suppose here like suppose you have
2923.48|4.119|a task X you want to solve and the
2925.92|3.72|manager agent is like responsible foring
2927.599|3.361|the task to all the worker agents so you
2929.64|3.679|can tell the worker like okay like do
2930.96|4.72|the task X here's the plan here's the
2933.319|4.76|context um the current status for the
2935.68|3.76|task is not done now suppose like the
2938.079|3.24|worker goes and does the task it says
2939.44|3.6|like okay I've done the task I send the
2941.319|3.48|response back so the response could be
2943.04|3.2|like I said the could be like a bunch of
2944.799|3.841|like thoughts it could be some actions
2946.24|4.48|it could be something like the
2948.64|4.159|status then the manager can ask like
2950.72|3.399|okay like maybe I don't trust the worker
2952.799|4.081|I don't want to go very far this is
2954.119|4.48|actually like correct um so you might
2956.88|2.8|want to do some sort of verification and
2958.599|4.041|so you can say like okay like this was
2959.68|4.32|the spec of for the task uh verify that
2962.64|4.56|everything has been done correctly to
2964.0|4.64|the spec and and then if if if the
2967.2|3.159|agency is like okay like yeah everything
2968.64|3.88|is correct I'm very FY everything is
2970.359|3.76|good then you can say like okay this is
2972.52|3.36|good and then the manager can say like
2974.119|4.2|okay the task was actually done and this
2975.88|3.76|sort of like two-way cycle prevents um
2978.319|3.04|miscommunication in a sense where like
2979.64|3.56|it's possible something could have gone
2981.359|4.641|wrong but we never caught
2983.2|4.56|it and so you can hear about the
2986.0|3.72|scenario two where there's a
2987.76|3.28|miscommunication so here the manager is
2989.72|3.92|saying like Okay let's verify if the
2991.04|5.16|task was done but then we actually find
2993.64|4.479|out that the task was not done
2996.2|3.48|um and then what you can do is like you
2998.119|2.841|can sort of like try to redo the task so
2999.68|2.439|the manager in that case can say like
3000.96|3.44|okay maybe the task was not done
3002.119|5.361|correctly so that's why we caught this
3004.4|4.679|mistake and now we want to like fix this
3007.48|4.28|mistake so we can like tell the agent
3009.079|3.961|like okay like redo this task uh and
3011.76|3.16|here some like feedback and corrections
3013.04|4.799|to
3014.92|5.08|include cool um so that's sort of the
3017.839|4.561|main parts of the talk um I can also
3020.0|6.28|discuss some future directions um of
3022.4|7.64|where things are going um cool
3026.28|7.279|any any questions so far
3030.04|5.88|okay cool um so let's talk about some of
3033.559|5.04|the key issues with building the sort of
3035.92|4.36|autonomous agents so one is just
3038.599|3.841|reliability like how do you make them
3040.28|3.48|really reliable which is like if I give
3042.44|3.359|it a task I want this task to be done
3043.76|4.359|100% of the time that's really hard
3045.799|5.56|because like neural networks and AI are
3048.119|5.24|stochastic systems um so it's like 100%
3051.359|3.72|is like not possible so you'll get at
3053.359|4.72|least some degree of error and you can
3055.079|5.121|try to reduce that error as much as
3058.079|4.961|possible uh second becomes like a
3060.2|5.919|looping problem where it's possible that
3063.04|4.16|agent might divert diverge from the task
3066.119|2.841|that's been given and start to do
3067.2|3.159|something else and then unless it gets
3068.96|2.92|some sort of environment feedback or
3070.359|2.681|some sort of like correction it might
3071.88|2.239|just go and do something different than
3073.04|2.759|what you intended to do and never
3074.119|3.561|realize it's
3075.799|3.28|wrong the third issue becomes like
3077.68|2.84|testing and benchmarking like how do we
3079.079|4.04|test this sort of Agents how do we match
3080.52|5.039|mark them in the and finally how do we
3083.119|3.841|deploy them and how do we observe them
3085.559|3.0|deployed like that's very important
3086.96|3.0|because like if something goes wrong you
3088.559|4.28|want to be able to catch it before it
3089.96|5.399|becomes some major major issue uh I the
3092.839|4.361|the I the the biggest risk for number
3095.359|3.121|four is like like something like span it
3097.2|2.56|like suppose you have agent that can go
3098.48|3.0|on the internet do anything and you
3099.76|3.16|don't observe it then could just evolve
3101.48|3.0|and like do basically like take over the
3102.92|4.639|whole internet possibly right so that's
3104.48|3.079|why observability is very
3107.68|3.08|important and also I will say like
3109.44|2.639|building a kill search like you want to
3110.76|2.44|have agents that can be killed in a
3112.079|3.601|sense like if something goes wrong you
3113.2|6.72|can just like pull a like a press a
3115.68|6.76|button and like kill them in
3119.92|4.96|case okay so this is s like goes in the
3122.44|4.56|looping problem where like you can
3124.88|3.76|imagine like suppose I want to do a task
3127.0|3.48|the IDE trory of the task was like the
3128.64|4.08|white line but what might happen is like
3130.48|3.639|it takes one step maybe it goes like it
3132.72|4.079|does something incorrectly it never
3134.119|4.281|realizes it I made a mistake so it it
3136.799|2.841|tries to it doesn't know what to do so
3138.4|3.0|just like maybe like we'll do something
3139.64|3.08|more randomly we'll do something more
3141.4|3.439|randomly so it will just keep on making
3142.72|4.28|mistakes and at and like in teaching
3144.839|3.76|here it really some like really bad
3147.0|4.24|place and just keep looping maybe just
3148.599|4.48|doing the same thing again and again and
3151.24|2.96|that's B and the reason this happens is
3153.079|3.361|because like you don't have feedback so
3154.2|3.32|suppose I take a step the agent made
3156.44|2.72|suppose the agent made a mistake it
3157.52|3.0|doesn't know it made a mistake now
3159.16|3.28|someone has to go and tell it that you
3160.52|3.039|made a mistake you need to like fix this
3162.44|2.879|and that there you need like some sort
3163.559|3.04|of like verification agent or you need
3165.319|3.601|some sort of environment which can say
3166.599|3.881|like oh like maybe like if this like
3168.92|2.72|coding agent or something then it maybe
3170.48|3.2|like write some code the code doesn't
3171.64|5.479|compile then we can take the error from
3173.68|4.72|the from the uh the compiler or the ID
3177.119|4.121|give that to the agent okay this was the
3178.4|4.48|error like to take another step it it
3181.24|3.52|tries another times so it tries multiple
3182.88|3.719|times until it can like fix all the
3184.76|3.559|issues so you need to really have this
3186.599|3.921|sort of like feedback otherwise you
3188.319|4.441|never know you're
3190.52|4.76|wrong and this is like one issue we have
3192.76|3.839|seen with early systems like Auto GPT so
3195.28|2.96|I think I don't think people even use
3196.599|4.041|Auto GPT anymore it used to be like a
3198.24|4.72|Fed I think like in February now it has
3200.64|4.199|disappeared and the reason was just like
3202.96|3.44|it's a good concept but like it doesn't
3204.839|3.561|do anything useful just because it keeps
3206.4|5.959|diverging from the task and you can't
3208.4|3.959|actually get it to do anything like
3213.4|6.919|correct okay um okay and we can also
3217.28|5.519|discuss more about like the sort of the
3220.319|5.0|computer abstraction of Agents so this
3222.799|4.76|was a recent post from Andre car where
3225.319|4.961|we talked about like a like LM operating
3227.559|4.481|system and I I would say like this is
3230.28|4.88|definitely in the right direction where
3232.04|4.6|you're thinking as the LM as the CPU you
3235.16|3.679|have the context window which is like
3236.64|4.199|acting like a r and then you are trying
3238.839|4.28|to build other utilties so you have like
3240.839|4.601|the ethernet which is the browser you
3243.119|3.401|can have L that you talk to you have
3245.44|4.24|file
3246.52|5.72|system that's the part you have like the
3249.68|5.439|software 1.0 classical tools which the
3252.24|4.96|LM control and then you might also are
3255.119|3.521|can add multi modality so this is like
3257.2|4.04|more like you have video inputs you have
3258.64|5.32|audio inputs you have like um more
3261.24|4.119|things over time and this and then once
3263.96|3.159|you like look at this you start the
3265.359|3.641|whole picture of okay like where like
3267.119|3.881|things will go so like currently what we
3269.0|2.92|are seeing mostly is just the LM and
3271.0|3.28|most people are just working on
3271.92|4.199|optimizing LM making but this is the
3274.28|4.76|whole picture of what we want to achieve
3276.119|5.921|for it to be a useful system that can
3279.04|3.0|actually do things for
3283.28|3.48|me and I think what we'll start to see
3285.44|4.119|is like this sort of becomes like a
3286.76|4.12|operating system in s where like someone
3289.559|3.481|like say like opening I can go and build
3290.88|4.199|this whole thing and then I can plug in
3293.04|4.36|programs I can build like stuff on top
3295.079|6.161|of this operating
3297.4|6.04|system um here's like also like a even
3301.24|5.24|more generalized concept uh which I like
3303.44|5.399|to call like a neural computer and the
3306.48|4.079|sort of like it's very similar but it's
3308.839|4.081|like sort of like like now if you were
3310.559|4.081|to think of this as a fully flat
3312.92|5.48|computer what are the different like
3314.64|5.4|systems you need to go and you can think
3318.4|4.56|like maybe I'm a user and talking to
3320.04|4.519|this s of like AI which is like a full
3322.96|2.879|FL AI like imagine like the goal is to
3324.559|2.401|build
3325.839|3.081|what what should the architecture of
3326.96|4.28|jvis look like and I say like this goes
3328.92|4.0|into the right architecture to some
3331.24|3.76|extent where you can think like this is
3332.92|4.84|a user who's talking to say like like a
3335.0|5.599|j like yeah you have a chat interf the
3337.76|4.12|chat is sort of like how I'm interacting
3340.599|2.881|with it which could be responsible for
3341.88|3.08|like personalization it can have some
3343.48|3.24|like some sort of like history about
3344.96|3.2|what I like what I don't like so it has
3346.72|3.52|some like layers where like which are
3348.16|4.159|showing my preferences it it knows how
3350.24|3.799|to communicate it has like human like
3352.319|5.0|sort of like maybe like empathy sort of
3354.039|6.641|like skill skills so so it's feel like
3357.319|5.201|very humanik and after the T interface
3360.68|3.639|you have some sort of like a Tas engine
3362.52|3.079|which is powering like capabilities so
3364.319|4.04|if ask it like okay like do this
3365.599|6.281|calculation for me or like uh find fetch
3368.359|5.48|me this information or order me a burger
3371.88|3.479|then then sort of like imagine like the
3373.839|3.401|chat interface should activate the the
3375.359|3.561|task engine say like okay inste of this
3377.24|2.68|chatting I need to like go and do a task
3378.92|4.28|for the
3379.92|4.679|user so that goes to the task uh engine
3383.2|3.04|and then you can imagine there's are
3384.599|3.24|going to be couple of rules so because
3386.24|2.72|if you want to have safety in mind and
3387.839|3.641|you want to make sure like things don't
3388.96|4.24|go wrong so the any sort of engine you
3391.48|3.0|build needs to have some of rules and
3393.2|3.359|this could be like sort of you have the
3394.48|4.559|three rules for robotics that robot
3396.559|3.681|should not harm a human stuff like that
3399.039|2.841|imagine like you want we want to have
3400.24|3.16|like this sort of like last to have a
3401.88|2.919|bunch of like inherent tools where like
3403.4|3.88|this are the principles it can never VI
3404.799|4.081|it and if if it creates a task or like
3407.28|3.68|sort of like creates a plan which violes
3408.88|4.36|this Roots then that plan should be
3410.96|4.24|invalidated
3413.24|3.28|automatically and and so so the task
3415.2|3.32|engine what is doing is start like
3416.52|5.16|taking the chat input and saying like I
3418.52|5.279|want to spawn a task um that can
3421.68|3.6|actually solve this problem for the user
3423.799|2.76|and the task would be like say in this
3425.28|7.72|case say something like say like I want
3426.559|8.641|to go um online and buy like U my like a
3433.0|5.28|or something so in that case like
3435.2|4.399|suppose that's a task that and this task
3438.28|2.96|can go to like sort of like a routing
3439.599|4.2|agent so this becomes like sort of like
3441.24|4.4|the man manager agent idea and then the
3443.799|4.24|manager agent can decide okay like H
3445.64|4.24|where should I what should I do like
3448.039|4.441|should I use the browser should I use
3449.88|4.6|some sort of like a local app or to
3452.48|4.04|should I like use some like file storage
3454.48|4.04|Ral system and then based on that
3456.52|3.88|decision it can like it's possible you
3458.52|3.319|might need a combination of things like
3460.4|2.439|may I need to use this file system to
3461.839|2.921|find find some information about the
3462.839|4.121|user and need to do some real time look
3464.76|3.839|up also need to some use some apps and
3466.96|3.399|tools so you can sort of like do this
3468.599|3.76|sort of like message passing to all the
3470.359|3.72|agents get result from the agents so it
3472.359|3.0|says like okay like like the browser
3474.079|4.04|agent say like okay like yeah I found
3475.359|4.161|this sles this is what the user lights U
3478.119|2.841|maybe you can have some of math engine
3479.52|3.68|which can like sort of like okay this
3480.96|5.639|are all the valid plans that makes sense
3483.2|5.72|if you want nonstop t for instance U and
3486.599|4.641|then you can s like take that result
3488.92|4.08|show that to the user like you can see
3491.24|3.599|something okay I found all this for you
3493.0|4.4|and then the US say choose this FL then
3494.839|4.52|you actually go and the but this sort of
3497.4|5.08|like sort of gives you an idea of what
3499.359|4.361|the hierarchy system should look like um
3502.48|3.28|and we need to build like all these
3503.72|4.28|components where currently you only see
3505.76|2.24|the L
3508.48|6.0|and okay cool um and then we can also
3511.92|4.84|have like reflection where the idea is
3514.48|4.319|like once you do a task it's possible
3516.76|3.839|something might be wrong so the task
3518.799|5.32|engine can possibly verify using it
3520.599|4.96|rules and um logic to see like okay like
3524.119|3.92|is this correct or not and if it's not
3525.559|3.56|correct then like you keep issuing this
3528.039|3.641|instructions but if it's correct then
3529.119|2.561|you pass that to the
3532.64|3.8|user and then you can have like more
3534.52|5.24|like s like complex things like you can
3536.44|5.2|have inner thoughts plans and like keep
3539.76|5.279|improving the
3541.64|5.6|systems okay um and I would say like the
3545.039|4.401|biggest things we need right now is like
3547.24|4.64|when error correction um because it's
3549.44|3.919|really hard to catch errors um so if you
3551.88|3.08|can do that really better I think that
3553.359|3.561|will help especially if you can build
3554.96|3.32|agent Frameworks which have inherent
3556.92|4.36|mechanisms for getting erors and
3558.28|5.12|automatically fixing up um same thing
3561.28|4.039|you just need is like security you need
3563.4|5.679|some sort of models around user
3565.319|5.48|commissions so it's possible um you want
3569.079|4.601|to have like different layers where like
3570.799|5.121|U what are some things that agent can do
3573.68|4.359|cannot do on my computer instance so
3575.92|4.08|maybe I can like maybe like the agent is
3578.039|4.201|not allowed to go to my bank account but
3580.0|4.4|I can go to my like R account so you
3582.24|3.359|want to build this like user permissions
3584.4|2.8|and then you also want to solve problems
3585.599|3.76|on like sandboxing how do I make sure
3587.2|4.359|everything's safe it doesn't go and D
3589.359|3.801|computer delete everything uh how do I
3591.559|2.8|deploy in Risky settings where like
3593.16|4.08|there might be a lot of businesses there
3594.359|5.521|might Financial Risk and making sure
3597.24|5.96|that uh if things are irreversible we
3599.88|3.32|don't like cause a lot of
3604.079|5.52|harm um cool yeah so that was the talk
3607.4|2.199|thank
3612.4|3.0|you