start_time|end_time|text
1.32|3.52| Yeah, so this was a very long lecture on sequence modeling
4.84|4.44| with recurrent neural networks and transformers. So we talked
9.28|4.48| about RNNs with attention, then we talked about self attention
13.76|2.72| and multi hit attention, which are concepts found in the
16.48|2.88| original transformer model. And then we talked about some
19.36|4.16| popular transformer models, such as BERT, GPT and BART. So in
23.52|2.76| this last video, I wanted to show you a code implementation
26.28|4.9| of BERT. I know that, yeah, this lecture has been about
31.2|4.12| generating sequences. So, however, as we also have
35.32|4.16| learned, the BERT model is more or better for discriminative
39.48|4.04| modeling, like prediction tasks, whereas the GPT would be a
43.52|5.08| better model for generating text. So BERT, because I just
48.6|1.8| find this model also interesting, I wanted to show
50.4|3.36| you a simple example using our familiar movie review
53.76|3.96| classifier data set. And then we can compare it to the
57.72|3.92| performance of the LSTM model that we trained in lecture 15.
62.16|4.4| But of course, please feel free to experiment more with this.
67.24|5.4| There is essentially a company who is developing an open source
72.64|3.04| library that everyone uses when working with transformers at the
75.68|4.54| company is called hugging face. And yeah, they have a lot of
80.22|3.74| tutorials. So I was just focusing on classification, but
84.2|5.24| they have many other tutorials available. So if you are
89.44|4.48| interested, so you can find also sequence generation tasks, and
93.92|3.52| so forth, like question answering, and yeah, different
97.44|3.04| different types of things, language modeling. So please
100.48|3.24| feel free also to explore more. I wanted to just because it was
103.72|4.4| a long video or lecture already, I wanted to just finish this
108.12|6.08| with a shorter example, showing you how to use this resource,
114.2|3.44| the transformer library from hugging face. So here we are
117.64|4.42| going to train a BERT model. And I was actually implementing BERT
122.06|3.3| models on this movie review data set or fine tuning it
125.36|3.0| essentially, I couldn't get really good performance with
128.36|5.16| that. So I changed that to using distilled BERT. So distilled
133.52|4.76| BERT is a smaller, faster and computationally cheaper version of
138.28|4.12| BERT. So they essentially took BERT, the original BERT model
142.4|4.64| and distilled it down to a smaller size. So it has 40% less
147.04|3.76| parameters. So I can make this a little larger here. So it has
151.12|5.84| 40% less parameters, and run 60% faster, while achieving
156.96|3.04| approximately 95% of the original performance of BERT
160.0|4.96| measured on a language understanding task. So again, I
164.96|2.96| just wanted to show you in general how we can import these
167.92|4.56| models from the transformer library, which we can install
172.48|3.64| here via pip install transformers. So in for this
176.12|6.32| particular example, I was using the version one 4.6. Alright, so
182.44|3.68| and I also structured this whole notebook in a similar way that
186.12|4.24| I structured previously, for instance, the LSTM notebook that
190.36|6.08| we had for movie review classification. So I'm
196.44|4.24| importing a couple of things here as a tokenizer and
201.52|2.8| classifier model. So this is just for pre processing the
204.32|3.92| text. And then this is the main for loading the main distilled
208.24|3.8| BERT model, the tokenizer here, but I understood correctly based
212.04|3.32| on the documentation is actually the same tokenizer that they use
215.36|3.24| for the regular BERT model, they call it distilled BERT, but you
218.6|5.64| could technically also just use BERT tokenizer. Just a few
224.24|4.92| settings here. I'm only training for three epochs, because it's
229.2|3.56| it's a slow, it's a big model, right? It's what was it 300
232.76|3.36| million parameters. So it takes a while to train. So that's why
236.12|2.92| I only train for three epochs, because I didn't want to wait
239.04|5.36| forever. Um, yeah. So actually, 300 million parameters, I think
244.4|3.44| is the original BERT model. So that is 40%. So it's more around
248.16|6.6| 170 ish. So first, I'm loading the data set. So remember, I had
254.76|3.08| like a pre processed version of that data set that we used also
257.84|3.72| in our LSTM code before just for convenience, I'm using that it's
261.56|3.76| a CSV file. So here, this is just downloading and unzipping
265.32|3.04| the CSV file from my book directory where I have this
268.36|5.04| pre processed version. And here's how it looks like the
273.4|4.92| reviews as text and then the sentiment here as as the class
278.32|5.92| label, whether it's positive or negative. We have 50,000 movie
284.24|3.68| reviews, and I'm splitting this into a training validation and
287.92|5.56| test set. So I use the first 35,000 for training, then I use
293.48|4.6| 5000 for validation, and the remaining 10,000 for testing.
298.08|4.38| Then I'm loading the tokenizer from the pre trained model here.
302.86|3.6| So why using a pre trained tokenizer, I think this includes
306.46|4.64| the generation of the word embeddings. So the vocabulary,
311.5|6.08| and everything. Now, this is very convenient. So we can just
317.62|4.12| apply that. So now it would then process those other words, and
321.74|3.08| our reviews the same way it processed the ones when it was
324.82|4.88| doing the unlabeled training. So just to recap, let me go to the
329.7|3.28| lecture slides. So there are two steps I should have maybe said
332.98|3.72| that earlier, we are in this notebook only focusing on the
337.02|5.76| pre training. So if I go back to the main concepts. So yeah,
342.78|4.72| there are two main approaches, the two training approaches for
347.5|3.28| the transformer. So first, there's this pre training on the
350.78|4.08| large unlabeled data set. And then there's the training for the
354.86|3.28| downstream tasks on smaller label data set. So in our case,
358.38|3.8| we are loading the pre trained one. So the people at hugging
362.18|3.52| face on prepared this pre trained model, which we are
365.7|2.72| loading. And then in our particular case, we are just
368.42|3.64| doing the training for the downstream tasks on this small
372.18|3.12| labeled movie review data set. And we are using the fine
375.3|4.8| tuning approach where we update the whole bird model. And then
380.1|4.72| we are doing the pre training. Okay, um, so here we are
384.86|7.16| creating then our encodings. So encodings for the text, I think
392.02|6.04| this includes also the word embeddings. So the context size
398.06|4.36| is 512. So that's also one thing to keep in mind, what it will do
402.42|4.08| is it will truncate. So if we have a movie review that has
406.5|4.36| 112 words, it will do a padding. If it's longer than 512 words,
410.86|7.68| it will truncate. So then everything will be the same
418.54|4.96| size 512. And we set up our data set here. So this is just a
423.5|5.04| pytorch data set from the main pytorch library. So it's
428.58|3.24| something kind of familiar. So now we work with encodings and
431.82|6.32| labels. Yes, a specific way to pre process or arrange the
438.14|7.04| encodings. So it's essentially from the key, like the ID, the
445.18|10.08| word ID to the encoding. Sorry, yeah. Sorry, this includes the
455.26|6.32| labels, right, right. Okay. Yeah. And then we construct our
461.66|4.28| data set from the encodings and the labels. So this gets our
465.94|3.44| encodings and the labels. Let's see the encodings. And this is
469.38|6.2| the labels. labels are just the zeros and ones, then I'm setting
475.58|3.36| up my data loaders. Notice I'm only using batch size of 16,
478.94|4.0| because the bird model is quite large. And I got memory problems
482.94|5.08| on my GPU when I was increasing that. And now we are loading the
488.02|2.72| pre trained model here. So we are using the distill bird for
490.74|5.28| sequence classification from pre from pre trained. So we are
496.3|5.4| using an uncased model. So it's case insensitive. That was
502.5|2.88| something I tried. It's just a simple model. I think they also
505.38|4.4| have case sensitive ones. But since we have a small data set,
509.78|3.48| that might be the better option here, using the atom optimizer.
514.22|2.84| And then we're doing the training. Okay, so training is
517.06|2.28| very unspectacular. So this is by the way, that's just the
519.34|3.6| accuracy function. I have carried this over from our
522.94|3.64| previous code examples, I made a few modifications, just about
526.58|4.8| this part here. This is for loading the data. But except
531.38|4.84| that it's this is from our STM notebook earlier, where we also
536.22|4.8| should have a accuracy function here. Just took it from here
541.02|5.12| from our previous code, modified a little bit for our encoder,
546.66|5.28| transformer. And yeah, that is then computing the accuracy in
551.94|5.68| the same way. Now not also that the outputs when we run the
557.62|4.32| forward pass of our model, so the bird model gets the input
561.94|9.0| IDs, and then the attention mask. And the outputs are two
570.98|4.84| things, it's a tuple, one is the loss, and one are the logits. So
575.82|3.28| it's computing already the loss inside. So we don't have to
579.1|2.84| worry about, let's say using a cross entropy loss during
581.94|4.06| training also. And then we get the predicted labels by looking
586.0|7.58| them at the maximum logic here. So this is similar to our LSTM
593.74|4.2| classifier, or any other classifier we trained before.
599.74|4.74| Okay. So yeah, we are training again. So this is for preparing
604.48|3.42| the input data set. So getting the input IDs, the attention
607.9|4.8| mask, and then the labels, and these all go together as input
612.7|5.56| to the bird model. So if it's the input ideas, sorry, I said
618.3|4.0| earlier, that the tokenizer includes the word embedding,
622.3|3.68| that's not true. This is then happening in the model itself,
626.14|4.36| if it's just in getting the ID. So the conversion to the
630.5|4.28| embeddings must have happened in the bird model itself. So if we
634.78|8.08| go back to our slides, so I don't have a specific bird
642.86|3.44| slide here, I think. But if we look at the general transformer
646.3|3.52| here, so these input embeddings are probably happening inside
649.82|4.4| the bird model, together with the positional encoding. So in
654.46|5.8| bird, this is GPT. In bird, this looked like this, if you recall,
660.26|6.16| so these embeddings probably happen in inside the model, the
666.42|6.32| easier. Okay, because this is just the IDs. Yeah, then the
672.74|3.24| backward pass, we set the gradients from the previous round
675.98|3.84| to zero, perform the backward pass on the loss. Again, the
679.82|3.32| loss is returned by the bird model. So the model when we call
683.14|3.64| it with a forward pass, we return a tuple, which consists
686.78|4.44| of loss and logits. And we use the loss for the backward pass.
691.38|2.68| Here, we don't really use that logits, we only use the logits
694.06|4.4| later, here for computing the predicted labels in our accuracy
698.46|4.84| function. Yeah, and then it's training. This is just our
703.3|4.92| boilerplate for keeping track of the training. And yeah, it's
708.26|4.36| take some time, it's 20 minutes per epoch. It's much, much
712.66|2.76| slower than our LSTM, but it's also much, much larger than our
715.42|4.68| LSTM in terms of the number of parameters. And in the end, it
720.1|4.44| gets pretty good performance. So three epochs took about one
724.54|7.2| hour gets 99% training accuracy and about 92% test accuracy. Now
731.74|3.52| let's compare that to our LSTM model that we trained before in
735.26|8.16| lecture 15. So that was the with the packed sequences where we
743.42|3.6| had a more efficient way of packing sequences. So when I
747.06|5.04| compare it with this model, we got around 89% accuracy. So let
752.1|4.44| me scroll down to the bottom. So it trains much faster, you can
756.54|5.04| see it's only a few half a minute, approximately less than
761.58|7.84| half a minute for one epoch. And 15 epochs was just in five
769.42|4.84| minutes or four minutes, it's impressive. So 89% accuracy,
774.26|4.72| it's actually not too bad. So, but yeah, using our pre trained
778.98|3.36| board model, we get even better performance out of this, which
782.34|3.88| is also interesting. So yeah, in that case, that's how the bird
786.22|4.04| model works is how we can use a pre trained model and fine tune
790.26|3.32| it. So the key idea is essentially using the tokenizer
793.58|8.92| to get the encodings, the so called encoding. And then we can
802.5|5.0| use this is also getting our attention masks. And then we can
807.5|3.32| use the pre trained model here distilled word for sequence
810.82|4.16| classification, and just train this further for our target
814.98|5.06| data set. So did some more experiments. So to further
820.04|3.14| improve the performance, I looked into what they recommended
823.18|5.04| in the tutorial. So I made a few changes. So one of the changes
828.22|6.12| was using Adam w, which is an atom that supports decoupled
834.34|5.64| weight decay that's to regularization. So let me use
839.98|4.2| this. So here's from the paper. So there's a paper corresponding
844.18|3.44| to that Adam with weight decay here if you're interested. And
847.62|3.2| this is just from the screenshot explaining how they perform the
850.82|4.96| Adam weight decay, but let's not get sidetracked here. So the
855.78|4.76| difference is I'm now using Adam with weight decay here, before
860.54|5.76| I just used the regular Adam. And also what I'm doing is I'm
866.3|3.54| using a learning rate scheduler with a linear learning rate
869.84|4.26| schedule. And this is something I got from the hugging face
874.12|3.56| repository. So let me Yeah, so you can see that. So I got that
877.68|4.18| from the transformer library. That's also something they
881.86|4.82| recommended with these settings. And when I train that then, with
886.68|5.86| these two changes using Adam w and the linear schedule, which I
892.54|4.1| update after each iteration, I got even better performance, I
896.64|8.04| got 93% point three, it's about 1% better test accuracy. Another
904.68|3.56| thing I found really cool is what they also have in the
908.24|6.98| hiking face repository is they have a so called trainer class.
915.24|4.86| So this is essentially the same as before. So I'm using again,
920.22|5.24| distill bird for classification with us. They also have an Adam
925.74|4.72| w I use just the one I think in pytorch. Maybe there's this even
930.46|3.64| better. I'm not exactly sure what the differences are between
934.1|3.64| their Adam w and the one in pytorch. But my guess is either
937.94|2.68| they implemented it before it was implemented in pytorch, or
940.62|3.08| they have like a small change to it that makes it maybe more
943.94|4.36| specific or better for transformers in any case. So this
948.3|4.88| is all the same setup, also the same tokenizer. But now the
953.18|4.72| difference is after loading the model, so maybe I should have
957.9|7.2| left it up here. Sorry. Okay, because I'm not using the one
965.1|3.56| from pytorch. I'm using theirs now. So before I use the one in
968.66|4.46| pytorch, I'm using theirs now doesn't really matter. And here
973.12|3.9| I'm using this trainer class from the repository. So this is
977.02|2.52| actually very convenient, they pack a lot of functionality in
979.54|4.28| there. They have a per device training batch size. So when I
983.82|2.72| was running this on my machine, which had multiple GPUs, it was
986.54|4.04| utilizing the different GPUs for efficiency. And you can also
990.58|4.16| specify directly the scheduler and everything. So these are
994.74|2.4| the arguments for the trainer. And then you can specify the
997.14|2.92| trainer with these arguments can provide a training set and
1000.06|3.48| validation set. So you can just use that one, instead of having
1003.58|11.6| our oops, I'm not sure why it's what swaps. I want to show both
1015.18|2.84| at the same time, somehow, it doesn't like it right now. But
1018.02|3.32| instead of defining our training loop here ourselves, we could
1021.34|7.12| also use use their trainer here. And then it trains for a couple
1028.46|2.68| of times gives you some output for the different steps or
1031.14|6.48| different losses here, can see the loss goes down. And yeah,
1038.58|3.52| it's my accuracy and evaluation and get even slightly better
1042.1|4.4| performance than with the one I trained with my own scheduler.
1047.34|3.4| Okay, so this was just a very quick video on using distilled
1050.74|3.2| bird from hugging face, they have way more models here, you
1053.94|3.8| can see there's a huge range of models. They also have GPT
1057.74|3.76| models here if you're interested in the more generative modeling
1061.5|2.56| parts, this is usually a model that is better for sequence
1064.06|4.04| generation. But yeah, there's lots, lots of stuff here, if
1068.1|3.24| you're interested in language models. So with that, let me end
1071.34|2.88| this lecture, which was already probably a little bit too long.
1074.22|27.56| But yeah, I hope that was useful.