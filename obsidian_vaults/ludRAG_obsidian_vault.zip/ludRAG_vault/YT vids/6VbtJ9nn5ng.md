start_time|end_time|text
2.22|2.72| All right, let's now get started then with the contents I
4.94|3.16| prepared for this week. I thought I would start with a
8.1|4.44| short teaser, what you will be able to do after this course. Of
12.54|4.84| course, it's a long journey 1515 weeks in the future. But at
17.38|2.72| some point, you will be able to accomplish something really
20.1|3.88| cool with deep learning things you will learn in this class. So
23.98|4.28| here are a few examples of class projects that students worked on
28.26|2.96| in the previous semesters. For example, in this project,
31.42|5.68| students converted audio signals into spectrograms, for example,
37.14|4.84| spoken text. And then they applied convolutional networks
42.1|4.04| to classify different texts and to extract language out of the
46.18|3.68| audio clips. So in this case, it was actually not language, I
49.86|3.84| just see it was finger snapping and here singing. So a
53.7|3.64| distinguishing between different audio inputs. So it was one
57.34|4.4| example of a class project from last semester. Another one was
61.9|3.72| working with 3d convolutional networks. So this is a 3d
65.62|2.96| version of the so called MNIST data set, which you will be
68.58|3.08| seeing a lot in this class, or at least in the introductory
71.66|3.32| lectures later on, because it's a simple data set to get
74.98|4.08| started with neural networks. And yeah, in this project, the
79.06|5.44| students worked with frmi or magnetic magnetic resonance
84.5|4.0| imaging data. So like brain scans, and so forth. And yeah,
88.5|4.2| classifying different types of brain scans. So that was another
92.7|3.52| interesting project. Or also, yes, students worked with
96.22|3.0| different types of generative adversarial networks, which will
99.22|4.0| also be covered at the end of this class, where you will be
103.26|4.04| able to generate new data, or also mix data from different
107.3|5.08| data sources. So here, the students are mixed artistic
112.38|5.88| or paintings or photographs, artistic inputs with a portrait
118.46|3.4| of a photo model. And then the output was basically here shown
121.86|4.48| on the right hand side, like a portrait of a person mixed with
126.34|3.2| a different styles. So this would be an example of style
129.54|4.4| transfer. Um, yeah, why did I pick these three projects? That
133.94|5.08| was kind of arbitrarily. It was just something. So I looked at
139.02|2.44| the projects from last semester, to be honest, and looked at
141.46|5.04| which ones had nice figures. So in that way, it looked nicer on
146.5|3.68| slides. But of course, you are free to work on whatever you
150.18|3.28| like for your class project. And I will talk more about that
153.5|3.28| later. I don't want to overwhelm you with too many things at the
156.78|4.16| beginning. Just wanted to show you some examples of things you
160.94|4.08| will be able to accomplish at the end of the semester. Yeah,
165.02|3.96| also, if you're interested, a little bit about my research, so
168.98|3.56| I'm working a lot on machine learning and deep learning. So
172.54|3.72| also, yeah, just compiled an overview here of projects I
176.26|3.8| worked on. So just to also introduce myself and what I'm
180.06|3.48| interested in. So yeah, last year, for example, I worked on
184.3|3.6| rank consistent order regression networks, we call that method
187.9|5.28| coral, which is for, yeah, you can think of it as classification
193.18|4.0| of ordinal inputs. So if you have class labels that are
197.18|3.72| ordered, and we want to sort them or predict the right order
200.9|3.92| of the labels and also the numeric value associated with
204.82|3.56| it, that for that we developed networks here, applied to age
208.42|4.36| classification, or we worked on face privacy, we call this
212.78|4.16| method privacy net, where we can hide facial attributes, for
216.94|4.24| example, age and gender and race and so forth, from the input
221.18|5.24| images for protecting one's privacy. Also, yeah,
226.42|2.92| collaborated with people from Nvidia was more like a review
229.34|5.52| article, we wrote about the latest trends in the realm of
234.86|3.48| Python, machine learning and deep learning. In particular, the
238.34|3.44| focus on GPU memory. And that's also something we will be
241.78|3.92| talking more about later when we talk about the tools that we
245.7|4.0| will be using for this class. Yeah, with a student of mine, I
249.7|3.52| also wrote another review article here on machine
253.22|3.64| learning and AI based approaches for bioactive ligand discovery.
257.1|4.72| So yeah, one of my students is working on small ligand
261.86|4.44| discovery and synthesis, also using generative models and
266.3|3.64| generative deep learning models for in the context of molecule
269.98|4.28| molecular synthesis and design. And here, another student of
274.26|3.68| mine is working on few shot learning. So few shot learning
277.94|4.84| is a branch of deep learning that is concerned with learning
282.78|3.6| from small data sets. Most of the time people use meta
286.38|3.0| learning or transfer learning, we will be talking more about
289.66|3.44| transfer learning later in this course, we won't be covering
293.1|3.48| few short learning though, I may ask though, my student maybe to
296.58|4.32| give a small guest lecture. If he has time later this semester,
301.1|3.52| and John G, he was working also on this paper, he is also our
304.86|3.64| TA in the semester. So if you are interested, you can ask
308.5|3.48| John G more about different future learning approaches, and
311.98|3.72| he would be very excited to chat more about you more with you
315.7|2.66| about that, I think. So during office hours, if you have
318.36|2.62| questions about few short learning, I think he would be
320.98|2.42| excited to talk more about it, because he's always excited to
323.4|4.82| talk about it. Yeah, and lastly, I'm also working on some
328.22|3.12| traditional machine learning methods. So this was in a
331.34|4.4| collaboration, where we used not deep learning, but traditional
335.74|2.52| machine learning methods, in this case, nearest neighbor
338.26|4.0| methods for yeah, also predictions related to
342.26|4.2| computational biology. So here, this was concerned with the
346.46|4.28| structure of GPCR, which is a G protein coupled receptor that
350.74|6.24| is, yeah, very important protein, protein receptor. It's a
357.54|4.48| binding to small molecules in humans. And yeah, most most drug
362.02|3.92| targets are actually targeting GPCRs. But here, this was more
365.94|3.84| like, yeah, fundamental computational biology research,
370.1|4.68| analyzing the structural composition of these proteins. So
374.78|3.56| this is just a little bit about me. So you can probably see a
378.34|4.52| theme is that I like working on deep learning, and also have
382.86|2.76| some interest in computationally computational
385.62|5.08| biology applications. So these two are basically my main
390.7|4.32| research areas and things I'm really excited about. Okay, but
395.02|4.96| now let's talk more about the course. So yeah, for this course,
400.38|3.6| I planned lots of topics, so mainly deep learning and
403.98|5.28| generative adversary networks, like, like the course title
409.26|5.2| suggests, and I structured this course into five parts. So here
414.46|5.92| are parts on 123. And on the next slide, I have some more
420.38|5.4| parts the remaining two. So first in the introduction, that's
425.78|2.68| where we are right now, I wanted to give you a brief overview of
428.46|3.52| this course, and also introduce machine learning and deep
431.98|4.84| learning. That's what we are going to do this week. Then, I
436.82|3.84| want to also briefly briefly talk about the history of deep
440.66|3.6| learning. And I think that's interesting, because that helps
444.26|4.2| you understanding like where the things and motivations are
448.46|3.92| coming from. Because yeah, deep learning, the term deep learning
452.38|5.16| is relatively new, it emerged about 10 years ago. But it has a
457.54|3.16| long history. Because yeah, deep learning, you can think of it as
460.7|4.72| a fancy term for neural networks. And neural networks
465.42|5.24| have been around for at least 6070 years. And yeah, some ideas
470.66|4.0| that emerged very early on that motivated the development of
474.66|4.8| different later ideas later on. And we will be covering a lot of
479.46|3.36| things related to neural networks. So in this on this
482.9|5.16| lecture, you can think of it as the big picture overview. So we
488.06|4.24| will then just briefly cover the history and then later when we
492.3|3.32| are introducing different topics in this lecture, we will do this
496.22|3.0| step by step and relate that back to the history and also
499.22|4.2| motivate why we we learn about them and why they are useful.
503.42|3.44| Yeah, and then we will talk about one of the early methods
506.9|4.44| of machine learning, a single layer neural network. So the
511.34|3.0| perceptron algorithm, it's a very traditional algorithm. It's
514.34|3.72| not very commonly used nowadays anymore. But I think this is
518.06|4.44| like an easy going introduction to the problem of classification.
522.5|7.24| So classifying oops, classifying things, putting things into
529.74|3.84| different categories. And yeah, I think that will be a good
533.58|4.2| introduction to get started with the topic. And then we will have
537.78|6.36| a small part two here, which is concerned with the mathematical
544.14|3.2| and computational foundations. So with that, I mean, like
547.34|4.6| introducing some mathematical necessities, like linear
551.94|3.44| algebra. So in deep learning, linear algebra is usually used
555.38|5.04| usually used to express things more compactly. Technically, we
560.42|4.04| can, or we could use deep learning without linear algebra,
564.46|3.92| but it would be very hard to write it down and also slow to
568.38|4.56| implement because when we use deep learning and practice, the
572.94|4.2| computing libraries that we use, they use, or they rely on linear
577.14|5.16| algebra, computational routines that help us executing certain
582.3|3.48| computations more efficiently compared to let's say, a Python
585.78|3.72| for loop. So linear algebra is like, in that way, very
589.5|3.52| important for deep learning, we won't be covering or needing any
593.02|4.28| advanced linear algebra concepts, just simple vector
597.3|2.4| dot products and matrix multiplications. That's it
599.7|4.56| basically. But I think it's still worthwhile covering this in
604.26|4.24| a separate lecture, because laying down the groundwork for
608.5|3.0| the later lectures properly makes everything later on a
611.5|4.28| little bit easier, I think. Then we will be talking about gradient
615.78|4.32| descent. That's a calculus topic. That's gradient descent
620.1|4.48| is the main method for parameterizing or training neural
624.58|4.68| networks. And then after this is more like a refresher. After
629.26|3.08| covering this topic, we will talk about automatic
632.34|3.68| differentiation with pytorch. So automatic differentiation is
636.42|2.68| calculus on the computer, you can think of it like that. And
639.1|4.48| we will be using a tool called pytorch, which is a library for
643.62|4.52| linear algebra, automatic differentiation, and then also
648.5|3.8| neural network training, or deep learning. And it also allows us
652.3|4.96| to implement things on the GPU to make things more efficient. So
657.26|5.88| I will also explain then here in lecture seven, how you can use
663.58|2.4| cluster and cloud computing resources, it will be a
665.98|5.0| relatively short part, though, because yeah, the main the main
671.5|4.04| topic is deep learning. Of course, computational aspects
675.54|3.6| are necessary. But for this introductory class, you don't
679.14|5.72| have to necessarily be an expert programmer and user of computers,
684.86|2.84| you should be familiar with certain things on your computer,
688.18|4.12| and certain programming aspects. But we are not here in machine
692.3|3.36| learning engineering more like giving a conceptual overview. So
695.66|3.84| you will get by with some free resources that I will talk about
699.5|2.96| in this lecture. But if you're interested, you can of course
702.46|4.4| also use more advanced resources, for example, our
707.26|5.24| campuses, HTC, and so forth. But it won't be required for this
712.5|3.8| class. Yeah, and then after the mathematical and computational
716.3|3.64| foundations, we will be talking then finally about neural
719.94|4.56| networks. So in this part three, I will lay the groundwork for
724.5|3.32| your deep learning. So we will talk what we start with logistic
727.82|2.92| regression, which you can think of a single layer neural
730.74|6.12| network. So this is basically an extension of this single layer
736.86|3.24| neural network that we talked about earlier, that is now
741.46|4.28| differentiable. And using the logistic regression as a starter,
745.78|3.6| we will add additional hidden layers, making this a deep
749.38|4.24| network, which is also called multi layer perceptron. And then
753.62|3.12| and then we will learn how we can train such a multi layer
756.74|3.68| perceptron using the backpropagation algorithm. Then
760.46|4.8| parts here, parts 10 to 12 are more like tricks for training
765.54|3.44| deep neural networks, for example, regularization
768.98|4.56| techniques to avoid overfitting on your input normalization and
773.54|3.64| weight initialization, it's just making training neural networks
777.18|4.32| more robust and faster. And then also talking about learning
781.5|5.12| rates, and some advanced optimization algorithms. So like
786.74|3.76| fancier versions of gradient descent, essentially. And these
790.5|4.52| are really kind of necessary to make neural networks work well
795.02|3.28| in practice. These topics may not sound super exciting,
798.34|3.56| especially like 10 and 11. But they are super useful or
801.9|4.24| important even yet to make neural networks work well. And
806.14|3.0| then we will get to the interesting parts in this course,
809.14|5.52| or I would say the more advanced parts. So here in part four, we
814.66|3.32| will then be talking about deep learning for computer vision and
818.02|3.84| language modeling. So we will spend a lot of time on
822.06|4.4| convolutional networks. So this is one big topic. And then we
826.46|3.36| will also talk about recurrent neural networks, they are for
829.82|2.28| language modeling. So convolution networks are more
832.1|3.08| for image modeling, although you can also use a one dimensional
835.18|3.72| convolutional network for text. But yeah, text will be more
838.9|6.6| focused on in lecture 15. And these will kind of also lay the
845.5|3.64| groundwork for the deep generative models that we will
849.14|5.52| be talking about. So in terms of deep generative models, we will
854.66|3.52| be talking about auto encoders, so called variational auto
858.18|3.88| encoders, then we will talk about generative adversary
862.06|3.92| networks, you may already have heard of them as GANs. So just a
865.98|3.16| long form of writing GAN, generative adversary network,
869.98|4.24| then this is also a very big topic, we will have a two
874.22|3.76| lectures on that. So one introduction and then one on some
877.98|4.4| more advanced GANs, for example, the Wasserstein GAN, and then
882.38|3.6| also how we can evaluate and compare different GANs to each
885.98|5.12| other. Because now, in this part, we are focused on
891.1|11.04| prediction, oops, prediction. And, and in the second part,
902.14|6.36| here, we are focused on generating things. So it's a
908.5|2.08| little bit different, it's a little bit trickier to evaluate
910.58|4.8| these models. So we will have a lecture on that. And then I also
915.38|4.92| plan to cover some aspects about recurrent neural networks for
920.3|2.88| generative modeling, for example, generating new text,
923.82|5.48| using in a sequence to sequence context. So here in lecture 15,
929.3|2.88| I will first try also to focus only on the prediction parts.
932.42|3.84| But we will be revisiting this topic also for generating new
936.26|4.64| data on text, and then also going into a more advanced
940.94|5.44| topic, adding the so called attention mechanism to RNNs, and
946.38|2.92| then also explaining self attention in the context of
949.3|4.76| transformers, which are underlying the models that you
954.06|3.44| have heard about in the media, probably one is called bird or
957.54|6.32| GPT two and GPT three. So these are the building blocks of these
963.86|4.52| models. So we'll also talk about those. So don't want to make
968.38|4.88| this too crowded here. But this part will be essentially for
973.26|7.32| images. And these two last parts here will be for text. So we
980.58|29.92| will have both generative models for images and for text.