start_time|end_time|text
0.84|3.24| Yes, so there's virtually an endless number of language
4.08|4.16| models. Of course, we can't cover all of them. But yeah, so
8.24|3.24| one more, because that's an interesting one. It's called
11.56|3.6| BART. And what's interesting about it is it is combining
15.16|5.76| both the concepts from GPT and BERT. So BART stands for
21.16|5.04| bidirectional and auto regressive transformers. So
26.2|4.88| bidirectional for BERT, and the auto regressive one for GPT. It's
31.08|5.44| about combining those two. So the idea, I mean, this model is
36.52|3.16| from 2019. So of course, it's not, I would say state of the
39.68|2.4| art anymore in terms of performance. But I think the
42.08|3.72| main idea is still interesting. So this is by Facebook AI
45.8|4.16| research, combining both Google's BERT and OpenAI's GPT.
49.96|7.08| And the argument or the thinking behind it is that BERT's
57.08|4.6| bidirectional nature, the auto encoder nature is good for
61.68|3.44| downstream tasks like classification, which require
65.12|4.04| information about the whole sentence. So if you have
69.16|3.92| classification tasks, for example, it's not necessarily an
73.08|3.76| advantage to predict one word at a time, it's more about
76.84|3.4| understanding the whole the whole sentence at once in a
80.24|4.48| sense. The downside of something like BERT is it's not so good
84.72|2.92| for generation tasks, though, where the generated word should
87.64|3.12| only depend on the previously generated word. For instance,
90.76|2.88| it's a question answering or something like that, where you
93.88|6.0| generate one word at a time. So BERT is so in a nutshell, BERT is
99.88|3.76| better at classification, but not so good at generating
103.64|5.04| things. On the other hand, GPT's unidirectional auto aggressive
108.68|3.48| approach is better for generating text, but then it's
112.16|4.48| not so good at tasks that require the whole input
116.68|4.2| sequences input, like classification. And the argument
120.88|4.0| here is that BART is the best of both worlds because it combines
125.08|6.12| both the BERT directional bidirectional encoder and the
131.2|5.8| GPT unidirectional decoder. So here's a figure from the paper,
137.28|5.24| like illustrating that concept. So BART is essentially a BERT
142.56|5.16| encoder plus GPT decoder plus plus some additional noise
147.76|6.32| transformations that they came up with. So for reference, that's
154.08|3.92| the BERT model here, the bidirectional encoder. So if you
158.0|4.92| recall, it's about masking and essentially masking tokens. And
162.92|5.08| the task is to predict what words or tokens go in there in
168.0|2.72| these gaps. So these gaps recall, they could be either
170.72|5.12| masks, or they could be random words, or it could be the same
175.84|2.68| word. But the task is that the model has to predict what goes
178.52|6.72| in there. The GPT model, it's essentially an decoder. So it's
185.24|2.52| predicting the next words, if you have the start of the
187.76|3.92| sequence, the next token, let's say is an A, and then for the
191.68|3.6| token A, it should predict B, and so forth. So it's predicting
195.56|5.96| the input one at a time. And BART is combining those two. So
201.52|4.36| you have this bidirectional encoder on the left, which feeds
205.92|4.72| into this autoregressive decoder. And I'm not sure it's a
210.64|2.84| couple of videos to go. But if you think about this, this
213.48|3.16| should maybe remind you of something. So it has been quite
216.64|2.64| some time ago. But it's essentially what they are doing
219.28|4.92| here. My opinion, this is essentially reconstructing the
224.2|3.88| original transformer model, right? Because you also have in
228.08|2.32| the original transformer model. So this is from the attention is
230.4|4.48| all you need paper, you also have this encoder, where you
234.88|8.0| have the whole text as input. And then you have this decoder
242.88|5.6| here, where you have everything shifted by one position. So you
248.48|3.36| predict the next word. Of course, it's not identical to
251.84|2.76| BART, but because in BART, they have in addition to that,
255.32|3.52| addition here, they have like these noise transformation. So
258.84|4.08| here, this is essentially an encoder. BART is more like a
263.24|6.4| denoising auto encoder concept. It's essentially an the concept
269.64|2.52| is very similar. If you think back of the lecture on denoising
272.16|3.72| auto encoders, you essentially perturb this one and try to
275.88|4.08| reconstruct back the original one. So here is an example of
279.96|3.32| these different noise transformations they have. So
283.28|5.92| that's from the paper. So they have a task. So for example, if
289.2|6.84| this is the original, so this is ABC, let's say these are tokens.
296.32|3.44| And this D and E are second sentence also tokens. So they
299.76|3.68| have, for example, token masking, that's similar to
303.44|3.6| BART, they also have sentence permutation, where they are
307.04|3.88| permute these sentences. So they permute one and two, we have
311.0|4.24| document rotation. So I think in this way, what do they do here?
316.64|3.92| And they rearrange things. So sentence one and two go together.
321.6|3.16| Token, sorry, they make new sentences essentially here. I
324.76|3.12| think also that could mean that they are rearranging whole parts
327.88|5.68| of the document, they have token deletion. So going from ABC, now
333.56|6.24| they only have a CNE. So they deleted B and D, and text in
339.8|5.52| filling where the model, essentially, this looks similar
345.88|4.2| to token masking. So I'm honestly not quite sure what the
350.52|2.76| difference is, it looks like combination between token
353.28|3.36| masking and token deletion. In any case, they say they have
356.64|7.24| different methods here, different methods for having
363.88|4.28| noise transformation. And the task is to reconstruct back the
368.16|4.6| original input. It's similar, like denoising autoencoder,
372.76|3.04| where you optimize the reconstruction or where you want
375.8|4.48| to reconstruct back the original. So here are some
380.68|4.0| studies on the performance of these noise transformations. So
384.68|4.48| we have the base model here. And then with token masking with
389.16|3.92| token deletion with text and filling, you can see, so they
393.08|2.44| only try one noise transformation at a time. And
395.52|4.92| you can see, they perform almost equally well, they get really
400.44|3.76| good performance with only having one or two, in this case,
404.6|1.6| two of these methods combined.
406.2|6.68| Yes, so for fine tuning, so this is pre training. So the pre
412.88|4.6| training is for doing these noise transformations, and then
417.48|3.96| reconstructing the input. And now for the fine tuning for the
421.44|5.0| multi, for the multiple downstream tasks, they have these
426.44|2.88| two setups. So for instance, on the left hand side, this is for
429.32|3.76| classification. So here, you would essentially have a
433.08|3.92| classification. So here, you would essentially predict a
437.0|6.88| label and for tasks. So this is like a classification or they
443.88|7.28| call it discriminative task. And here, this is would be a
451.16|4.36| generative task because it's generating text. So this would
455.52|3.04| be in this case, language translation or machine
458.56|3.76| translation, just a word for having a computer doing language
462.32|5.2| translation. And here they have to have a small modification. So
467.52|5.08| this is the original part model where they have the pre trained
472.64|3.56| encoder pre trained decoder. And for language translation, they
476.2|5.44| add another randomly initialized encoder that is then fine
481.64|5.6| tuned. So instead of feeding the original word embeddings to the
487.24|4.8| encoder, they feed the word embeddings to the additional
492.04|5.12| encoder. And this puts out embeddings that then go into
497.16|6.68| this pre trained encoder. Yeah, and this model performs pretty
503.84|3.8| well. So here are performances for discriminative tasks like
507.64|5.88| classification tasks. And they perform almost as well. In these
513.52|2.4| cases, they perform best. So the bold numbers are the best in
515.92|4.84| this one. Also, in some cases, other methods are better. But
520.76|4.2| they are very competitive. So Roberta is a type of bird model
525.32|3.88| that is, I think it's larger than bird. It's a very large
529.2|4.48| model. Another model that we probably don't cannot discuss in
533.68|4.28| this lecture, because just too many things to discuss. But yeah,
537.96|2.72| it's another bird type model, there are plenty of them out
540.68|3.96| there. And the argument here is that part even though it has
544.64|4.04| this unidirectional nature with a GPT, it can still perform
548.68|5.1| competitively with bird models that are only bidirectional. So
553.78|5.58| they are arguing that the bark model, even though it is also
559.36|4.24| having this unidirectional auto regressive decoder is still good
563.6|3.68| for discriminative tasks. But then in addition to discriminative
567.28|2.96| tasks, it's also good at generative tasks, which is
570.24|2.8| something that bird models would, for example, not be able
573.04|6.28| to do a good at. So here, they actually perform best they reach
579.32|4.04| the state of the art compared to some specialized bird models.
585.16|5.88| Yeah. So more, more tasks here. So this is for Eli five
591.16|4.5| abstractive question answering. This is for conversational
595.66|6.54| response generation. And this is text summarization. Alright, so
602.2|3.08| this was the bark model, the best of both worlds combining
605.28|4.72| bird and GPT. So last in the last video about these popular
610.0|22.84| transformer models, let me say a few additional things.