start_time|end_time|text
1.16|3.24| All right, lastly, to wrap things up, let's briefly talk
4.4|3.52| about the practical aspects of this course, the tools that we
7.92|3.48| are going to use, as you have already guessed, probably, we
11.4|4.24| are going to use Python as our main programming language. So
15.64|4.48| here's a nice chart by Jacob and a plus who made it in 2015. It
20.12|3.88| is here outlining the different layers of the Python ecosystem,
24.0|3.92| the scientific computing ecosystem. So you have your
27.92|3.6| Python at the lowest level, that's the basic fundamental
31.52|3.4| thing that all these libraries require. And then layer by layer,
35.24|4.84| these libraries become more specialized. So you have general
40.08|2.84| computing libraries like the IPython interactive computing
43.48|4.44| environment, the NumPy linear algebra library, there's
47.96|5.04| siphon, which kind of helps inputting or using C code in
53.0|3.72| Python if you need to. So that's something we won't be doing in
56.72|2.84| this class. But for certain scientific projects, it's also
59.56|4.48| useful to make things faster. There's Jupiter, that is
64.88|2.68| ecosystem providing Jupiter notebooks, which you have
67.56|4.04| probably heard about already. I will say a few things about
71.64|5.08| Jupiter later. Yeah, so let me not say it here, I will say it
76.72|3.6| later. So then there are other libraries like scipy, which are
80.56|4.48| providing additional algorithms on top of NumPy, or the
85.04|3.6| visualization library like matplotlib, and pandas, which is
88.64|3.6| a data frame library, I want to go over the other ones, because
92.24|5.08| we won't be using them in this course. So the only maybe
97.32|4.52| notable ones are here, or is scikit learn, which is a machine
101.84|4.4| learning library that we have used in statistics for 51 in
106.24|4.2| fall semester. And there's also ML extend, which is a library
110.44|3.16| that I developed, implementing algorithms that are not
113.6|2.8| implemented in scikit learn. So I called it ML extend for
116.4|2.92| machine learning extensions, because I was not very creative.
119.72|4.72| So yeah, these are libraries that we used in 451. And we
124.44|3.8| won't be using those at all in this class. So there's basically
128.48|3.28| almost zero overlap between these two classes. And that's
131.76|3.6| not really an advantage of taking 451. Because really, we
135.36|2.52| will be focusing on deep learning here and not on
138.2|3.04| traditional machine learning. So in this class, we will be
141.24|6.0| mainly using Python and pytorch pytorch is the library built on
147.24|3.12| top of Python, we will of course also be using a little bit of
150.36|6.48| NumPy for some basic computing, especially in the next lecture
156.84|4.4| to just introduce things slowly. And then in I think in the
161.24|3.04| third lecture on perceptrons, and then also we will be using
164.28|3.36| matplotlib occasionally to make visualizations. But yeah, the
167.64|5.68| focus will be really on pytorch. Regarding Jupiter. So honestly,
173.72|4.0| I like Jupiter notebooks a lot, I have been using them a lot for
177.72|5.44| data analysis. However, based on my experience, I actually
183.16|4.4| recently started to prefer using regular Python scripts when
187.56|3.12| working with deep learning. There are many reasons because
191.88|3.12| deep learning code can be very verbose sometimes. And sometimes
195.0|3.84| it also takes a long time to run. And sometimes I also run
198.84|3.68| that on different computers, via the terminal, and things like
202.52|3.52| that. And they're just certain aspects where on script files
206.04|4.08| are a little bit more convenient to handle. Also, one aspect is
210.12|4.08| that there are easier ways to debug your code because there
214.2|5.44| are nicer linters and code highlighters in Yeah, in script,
219.64|7.2| text editors or visual, sorry, IDs into developer IDs. So I
226.84|5.92| will also say a few words about that maybe later. So regarding
232.76|4.48| pytorch, why are we going to use pytorch? So personally, my
237.24|4.48| history is like I started doing deep learning or working with
241.72|4.72| neural networks. In like 2014 1314, there was a library
246.44|3.84| called Theano that I've been using extensively. And for my
250.28|3.12| first machine learning book, I was also using that for the
253.4|4.32| neural network chapter. Then in 2015, a new library called
257.72|3.6| TensorFlow was released by Google. And I started using
261.32|3.6| TensorFlow like everyone else back in 2015. I really liked
264.92|4.32| it. So I've been using that quite a bit in the last couple
269.24|8.64| of years. But then in 2017. So this was 2015 2017 pytorch came
277.88|3.28| out, which made certain things way more convenient. So
281.32|2.72| personally, I felt the library was a little bit more organized.
284.36|3.68| It had dynamic graphs, it was a little bit closer to NumPy.
288.44|3.92| Nowadays, I mean, both pytorch and TensorFlow have very similar
292.36|3.84| features, both have static and dynamic graph support and so
296.2|3.52| forth. So there's not that much difference anymore. But in the
299.72|5.28| years between, I would say 2017 1819 pytorch was much, much
305.0|5.28| nicer than TensorFlow, like for my personal view. Also, the deep
310.28|5.76| learning community. Yeah, really like pytorch, because you can
316.04|3.04| see based here on this visualization, this is like the
319.08|2.64| top machine, deep learning and machine learning conferences,
321.96|4.16| you can see that there's a huge growth in pytorch use. So
326.12|4.08| the solid lines here are pytorch, the graphs for pytorch
330.2|7.08| from 2017 2019, middle of 2019. So the 2020 conference year is
337.28|3.68| not included because this article is from 2019. Unfortunately,
340.96|3.68| they didn't update this article. But yeah, you can see there's
344.64|6.32| like a steep growth for all the conferences, in terms of pytorch
350.96|4.04| use, whereas for TensorFlow, it's rather going more like
355.0|3.8| downward or not growing as fast. So that way, many, many, many
358.8|3.04| people have adopted pytorch recently. And also when you look
361.84|4.54| at papers. So if you find a new paper, and you look for code on
366.38|3.66| GitHub, you will most often find nowadays that there is pytorch
370.04|3.6| code, of course, there's also often TensorFlow code. But yeah,
373.64|6.96| pytorch is or has grown a lot. So it's also very popular. Why is
380.6|3.32| it important that a library is popular? So yeah, one reason is
383.92|2.88| really that if you want to implement more sophisticated
386.8|5.4| models, it's really easier to find tutorials or example code
392.2|3.48| or the implementation corresponding to a paper and so
395.68|4.36| forth. And for this class, really, I still find pytorch is
400.04|2.8| a little bit more organized and easier to use than TensorFlow.
403.04|3.8| It's more similar to NumPy. And I think you will appreciate that
406.84|4.68| because the learning curve is not quite as steep. So yeah,
411.52|5.12| just for fun here, I made a short implemented the Leonard
416.64|3.8| five that we talked about a short code implementation. Like
420.44|5.44| I said, I kind of for deep learning nowadays prefer using
425.88|3.4| text editors. The reason really is that, for example, if I make
429.28|2.8| a typo here or something like that, it will underline it and
432.2|3.88| them way more convenience features. And deep learning
436.08|3.96| code can be sometimes long. And I find it easier to develop on
440.04|3.28| code in a text editor. Nowadays, I still use Jupyter
443.32|4.16| notebooks a lot. I'm just currently even today, I've been
447.48|3.24| working with them extensively, working on a paper where we made
450.72|3.84| visualizations. And for things like that, for analyzing data,
454.56|2.56| it's really, I think really great to use Jupyter notebooks.
457.12|3.12| It's just like, if you write long code, like more like,
461.52|2.96| coding the networks, I find text editors more convenient.
464.6|2.36| Personally, I would recommend, for example, a text editor,
466.96|4.2| like Visual Studio code, which is fast, free and works on all
471.16|3.92| operating systems like Windows, Linux, and Mac OS. Personally,
475.08|3.12| I use a Mac, but this is supported by what it's
478.2|2.96| supporting all major operating systems. And it has great
481.16|3.2| support for Python and also debugging and things like that.
484.64|5.48| So yeah, anyways, here, this is just a brief outline of how the
490.16|5.04| Linux work looked like. So if I hit enter, yeah, so this is the
495.2|3.44| one doing the image recognition here, the handwritten digit
498.64|3.22| recognition. And you can see in time pytorch, it's actually just
501.86|3.46| a few lines of code implementing this rather complicated
505.32|2.44| convolutional network. So you can see there are lots of things
507.76|2.92| going on. But in pytorch, it's just a few lines of code to
510.68|3.12| implement this model. Of course, there are a few more lines of
513.8|2.36| code to train the model. But actually, it's not that
516.16|4.0| complicated. And we will walk through this in more detail
520.16|3.36| step by step later in this course. So for right now, you
523.52|2.4| don't have to understand how this works. I just wanted to
525.92|4.56| show you the code is actually not that complicated. So here, I
530.48|3.28| was just running the code. Also, I was running it on a computer
533.76|6.36| that had a GPU. So in this case, I was running it for 10 epochs,
540.12|3.1| which means 10 iterations over the training set. And the
543.22|4.32| training set, I think it has 60,000 images. So you can think
547.54|4.44| of it as 10 times 60,000 images training it on that. And it
551.98|3.74| only takes, yeah, less than a minute. So it's super fast. And
555.72|3.16| even Yeah, then after a minute, you get already almost like
558.88|3.72| 99% accuracy. So you have just some visualizations. And you can
562.6|3.64| see, even like after the second or fourth epoch, it already
566.24|3.96| reaches something like almost 99% accuracy, which I think is
570.8|3.08| really impressive. So this is on the validation set. Sorry. So
573.96|2.8| you can see actually, there's a gap between validation and
576.76|3.24| training set, which indicates overfitting. But we will also
580.0|4.16| talk more about that later. It's just like a quick demo of how
584.42|5.06| deep learning works and looks like. Okay, so let me finish
589.48|3.72| this introduction. So if there are still some things that are
593.2|4.48| unclear, I mean, this was just an introduction. So just an
597.68|2.96| overview, I noticed that I went into too much detail here and
600.64|2.4| there. So if there are some details, you don't understand
603.04|2.86| yet, don't worry about it too much. I've actually written a
605.9|4.62| blog post on this because I was planning to write a little
610.52|3.18| textbook based on my lecture slides, which is an ongoing
613.7|4.62| project. I'm not sure when and if I ever finished this. But
618.32|3.2| anyways, I uploaded the first chapter here as a blog post. So
621.52|3.64| you can actually read everything I talked about in written form.
625.98|3.98| And also, for those who are just interested in a general overview
629.96|3.72| of traditional machine learning, you can find the lecture notes
633.68|4.68| for the 451 class. So just if you're interested, you don't
638.36|2.72| have to read this, of course. However, what's also maybe
641.08|3.56| helpful is chapter one of my Python machine learning book,
644.64|3.14| which is, I would say a shorter version of this blog post. It's
647.78|4.32| just, it's, of course, written differently. It's a little bit,
652.1|5.42| I would say, smaller and shorter. And yeah, not not quite
657.54|2.14| the same. It's just like a different perspective, because
659.68|3.92| that's something I've written quite some time ago. Okay, so
663.6|3.44| with that, let me wrap up this introduction. And in the next
667.04|3.58| lecture, we will be looking at the brief history of neural
670.62|4.22| networks and deep learning. So I will just mainly outline why
674.84|3.04| things are cool and interesting and go over the major
677.96|2.92| architectures, because this will give you the big picture
680.88|3.48| overview of the topics we are going to cover then throughout
684.36|11.22| this whole semester.