start_time|end_time|text
0.9|4.26| All right, as the last video for today, let me briefly highlight
5.16|5.52| some other types of variants of auto encoders. So we can also
10.68|4.64| add dropout to our auto encoder. So here, if these are fully
15.32|3.08| connected or convolution layers, we can add dropout layers drop
18.4|3.92| out one D or two D. And this will cause the network then
22.32|4.8| coder to learn redundant features, same with a decoder,
27.12|4.12| because it won't be able now to rely on particular features to be
31.24|2.96| present, because as you recall, from the dropout lecture,
34.68|3.28| features will be dropped randomly, so it can't rely on a
37.96|3.32| certain feature being there, and then it will maybe we learn to
41.28|6.16| be more robust. So you can use the idea of using dropout also
47.44|3.68| to construct a so called denoising auto encoder. So in
51.12|2.32| the very first video of this lecture, I showed you this
53.44|3.92| example, where there was an auto encoder denoising medical
57.4|5.28| images. So if you add dropout directly after the input, it
62.68|2.76| will essentially add noise to your image, because right now,
65.72|5.28| then half of the pixels will be yeah, will be removed, right. So
71.0|2.6| you have this noisy representation of this input.
73.8|3.64| But if you still have your reconstruction loss between
77.44|6.16| those two, so this is your reconstruction loss computed
83.6|3.64| between these two, for instance, the two norm or mean squared
87.24|6.48| error, then it will learn essentially, how to ignore the
93.72|3.4| noise, right, because the auto encoder itself, it only or the
97.12|5.36| encoder, it only sees these noisy images. And then it will
102.48|3.8| learn how to remove the noise because it wants to minimize the
106.28|5.8| error between the not denoised input and the output, right. So
112.08|5.04| in this way, you can train auto encoders to denoise images, you
117.12|4.68| can also train it for doing other tricks like colorizing
121.8|2.88| images and so forth. So there are different things you can do
124.68|5.96| with these auto encoders. Yeah, you can also have a sparse auto
130.64|3.76| encoder if it's desired. So in the sparse auto encoder, more
134.4|3.88| than half. So by definition, a sparse matrix is a matrix where
138.28|3.2| more than half of the entries are zero. And you can also have
141.48|2.76| them or learn a representation where more than half of these
144.28|4.96| are zero. So how you can do that is by adding a one penalty. So
149.76|3.04| if you recall in the regularization lecture a long
152.8|3.08| time ago, we talked about L two and one penalties. So if you're
155.88|4.12| familiar from other classes, that's similar to how to
160.0|4.2| regularization, rich regression and lesser regression work in
164.2|2.56| the context of linear regression. So we have this
166.76|4.8| penalty term on the weights. So here it's the absolute value for
171.56|5.92| the one and for two, it's the squared value. And this will, if
177.48|4.72| you recall, cause this constraint optimization. So we
182.2|4.88| have still here our reconstruction loss between the
187.08|8.64| input and the output. So this is the reconstruction loss. And now
196.0|5.4| this is the one penalty. So we'll try to keep the weights
201.42|4.7| small. At the same time, it will also try. So here, it's not the
206.12|3.6| weights here, it's the encoded space, sorry. So we are it's
209.72|7.84| trying to keep the encoded space, the values small, while also
217.6|3.44| still minimizing the reconstruction loss, and it will
221.16|4.92| result in sparse embeddings, if that's desired. There might be
226.08|4.76| an application where that's desired. I don't know. Okay. So
230.86|2.82| lastly, the variational auto encoder, this is more
233.68|4.28| interesting now. So I don't want to go over it too much, because
237.96|2.72| it would be kind of a spoiler, because we will have a whole
240.68|2.64| lecture, the next lecture dedicated to this. So in a
243.32|8.2| nutshell, this is an approach where we essentially learn the
251.52|4.44| auto encoder such that this embedded vector will represent a
255.96|5.44| Gaussian Gaussian probability density. And we can achieve that
261.52|5.28| by also having an additional loss. So here, previously, we
266.8|4.36| had this two panel, l one penalty added to the loss. Now
271.16|5.44| what we have is we have a KL divergence term added to the
276.6|5.14| loss. So here, this would be our we have a we have both a
281.74|4.2| reconstruction term, and the KL divergence term. So for the
285.94|3.96| reconstruction term, we could use like here, the binary cross
289.9|3.26| entropy or negative log likelihood negative. So it's the
293.16|5.56| same thing. However, we could also use the two or MSE
298.88|3.16| technically, if we will just want to create a good variation
302.04|3.16| auto encoder, it doesn't matter. In fact, I would say l two and
305.2|6.56| MSE work even better. And yeah, so we will talk about this in
311.76|2.92| more detail than in the next lecture, because well, the
314.68|2.52| lecture is already very long. And if we have a dedicated
317.2|4.16| lecture to that, why talking about it in one slide, if I
321.36|3.84| have what if I can have 30 slides, right. So with that,
325.96|3.4| this is maybe a teaser for the topic that we will have next
329.36|22.56| week. So okay, so then that's it for today.