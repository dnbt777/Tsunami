start_time|end_time|text
2.2|3.44| Yeah, I wanted to end this lecture with some additional
5.64|3.32| topics, because over the years, I booked marked so many
8.96|2.68| interesting articles, I didn't even have a chance to read them
11.64|2.88| all, there are hundreds of interesting articles related to
14.52|3.16| optimization. But yeah, if you're interested, I have a
17.68|3.16| small selection of things here that you may find interesting.
22.0|4.24| So let's start with Adam. So going back to the original
26.24|4.08| paper, the Adam paper from 2014. So you can see there are
30.68|2.88| several other methods that they looked at. And this is from
33.56|3.68| 2014. Nowadays, there are maybe at least five times more
37.44|4.24| methods out there that people suggest to use compared to
41.68|3.32| regular SGD. So one thing, for example, that we also didn't
45.0|3.96| talk about is SGD Nesterov, which is a modified version of
48.96|3.36| SGD with momentum. It's like this Nesterov momentum. In
52.32|3.4| theory, it may work better than the regular momentum. I also
55.72|3.04| wanted to cover it in this lecture, actually, I made the
58.76|2.3| slides for that, but then I removed them because I noticed
61.32|2.92| otherwise, the lecture will be just too long. And most people
64.24|4.48| in practice use the regular momentum again, anyways. So SGD
68.72|3.92| with a regular momentum is also among the best algorithms, even
72.64|2.8| though it's the simplest one. And I will explain to you in a
75.44|4.28| few slides why. So Adam, like I said, is cool, because it
79.72|5.84| doesn't require as much tuning. But also, SGD is also in terms
85.56|4.6| of generalization performance, really good. So to make this
90.16|4.04| point, so this plot, this is looking at the training cost or
94.2|3.08| training loss. And you can see in this paper, they find that
97.28|3.64| Adam really performs best compared to other methods when
100.92|3.68| it comes to the training cost or loss. However, a training low
104.64|5.44| training cost doesn't imply that the final model generalizes
110.08|3.6| well to new data, maybe it's just overfitting. So what I
113.68|3.04| mean is, of course, we want to achieve a low training cost, but
116.8|3.32| that alone is not enough, we can end up with a low training
120.12|3.92| cost. But then if we have a high degree of overfitting, then the
124.04|3.4| resulting model still isn't so good, for example, compared to
127.44|3.56| a model that has a higher training loss, but lower
131.0|2.24| overfitting and may have a better generalization
133.24|4.56| performance. So to explain you more in detail what I mean,
137.8|5.0| here's a visualization from a paper from actually don't know
142.8|2.6| which year I think was 2017, I should have included it here.
145.76|3.24| But here, um, they also looked at different optimization
149.0|4.4| algorithms, they looked at the training error here, and the test
153.4|5.04| error. So what is interesting is that they find they have Adam,
158.46|3.9| the more optimized one, like hyper parameter tuning, and the
162.36|3.32| default one, most people I said use the default one, but in this
165.68|3.6| case, the default one performs really bad. The tuned one
169.28|2.6| performs better here. But yeah, in contrast to the previous
171.88|3.6| slide that I can't explain, in contrast to the previous slide,
175.48|4.52| they find that on the training set on SGD performs better than
180.0|4.64| Adam. So HBS heavy ball method, it's another method. But this is
184.64|2.2| like a little bit different from what I've shown you in the
186.84|5.32| previous slide. Nonetheless, the takeaway here is more like
192.28|3.08| what's happening on the test set. So in the test set, that is
195.36|4.16| usually what we care about here, we also find this regular SGD
199.52|4.84| performs better than Adam. And this is not unique to this
204.56|4.28| single paper. This is something that has been observed by other
208.84|5.12| people as well, that SGD, if it's tuned well, it has usually
213.96|2.48| the best generalization performance. One possible
216.44|4.2| explanation for that is that SGD is just noisier. And because of
220.64|5.36| this noise, it's maybe easier to avoid certain sharp minima, or
226.0|4.6| it's easier to, it's a first of all wiggle out of some local
230.6|4.92| minima, but then also maybe to don't find such a good loss. So
235.76|4.16| if you find a loss, that is very low, you may end up overfitting.
240.16|3.16| In that case, maybe having a higher training losses, maybe
243.32|4.32| sometimes not as bad. Okay, so that is one point why people
248.16|5.72| still sometimes prefer SGD compared to more fancy algorithms
253.88|5.04| algorithms like here listed here. Um, yeah, there was also a
258.92|6.04| fun paper where they essentially suggest switching from Adam to
264.96|3.4| SGD over the course of training. So they say despite superior
268.36|2.68| training outcomes, adaptive optimization methods, such as
271.04|3.16| Adam and a grad, or RMS prop have been found to generalize
274.2|3.88| poorly compared to SGD. So it's essentially what I said in the
278.08|3.96| previous slide, that regular SGD can usually yield better
282.04|3.16| generalization performance. And they say these methods tend to
285.2|2.48| perform well in the initial portion of the training, but are
287.68|3.8| all performed by SGD in the later stages of training, we
291.48|2.56| investigate a hybrid strategy that begins with training and
294.04|3.54| adaptive method. So using Adam, and then switching to SGD when
297.58|6.98| appropriate. So here, they have essentially compared SGD and
304.56|4.52| Adam, so we're using SGD first, and then, sorry, using Adam
309.08|4.76| first, and then switching to SGD. So yeah, here is also,
313.84|3.88| again, a plot showing the test error showing that with SGD, you
317.72|3.04| can end up with a lower test error, so a better
320.76|3.2| generalization performance compared to the orange to Adam.
327.04|6.36| Here's a blog article, also listing all the strengths and
333.4|3.04| weaknesses of these different algorithms, like taking an
336.44|3.56| objective view. So here, they didn't develop a particular
340.0|3.16| method, because usually, when you read a paper, where people
343.16|2.64| propose a new method, the new method is, of course, better
346.0|2.48| than the previous methods. But here, this is someone just
348.48|4.2| summarizing these different methods and coming up with some
352.68|4.7| takeaways. So yeah, in terms of the state memory, how many
357.4|4.36| memory that requires an addition on your GPU, because you have
361.76|2.8| additional parameters, but then also the hyper parameters that
364.56|3.56| you need to tune. So of course, SGD is the simplest one,
368.52|4.8| momentum, you add an additional number of parameters here. And
373.36|4.28| also tunable parameters. I don't know where the second one comes
377.64|3.08| from. Yeah, one is the learning rate. And the other one is, of
380.72|2.76| course, the momentum term, but the beta. But yeah, I was just
383.48|3.92| wondering, okay, anyways, um, so yeah, so here, they also say
387.4|3.8| that it's the best for generalization, but retake
391.2|3.8| requires extensive training. So requires more tuning for the
395.0|6.84| learning rate, but also more epochs. And then this one
401.84|7.28| accelerates and overcomes weaknesses, so forth. And here
409.12|6.04| with Adam, they also say it generalizes worse than SGD. So
415.16|4.76| yeah, this is a interesting other algorithm, Adam W. So it
419.92|4.64| improves Adam in terms of generalization and but requires
424.56|3.64| more state memory. It's the same as this one. So it's in that way
428.2|3.28| not much worse than regular Adam. But Adam W is also
431.48|2.92| something I've recently seen people using it's a little bit
434.4|3.12| better than the regular Adam. But yeah, if you're interested,
437.52|3.28| you can read this article for more details for more detailed
440.98|5.22| comparison of different methods. So here was also an interesting
446.2|6.12| take on Adam again. So people often use Adam and say Adam
452.32|4.12| performs just well across many different architectures. And
456.44|3.7| here this person argues this maybe because architectures
460.14|4.68| evolved to make Adam the best optimizer. So here the person
464.82|2.2| says that it is known that Adam will not always give you the
467.02|2.98| best performance. Yet most of the time people know that they
470.0|6.76| can use it without its default numbers with it. Yeah, so you
476.76|3.2| don't need to change the default parameters. And usually you can
479.96|3.2| get good performance on your problem just out of the box. So
483.16|4.16| that is also what I observed in practice. But here, the argument
487.32|3.26| is, maybe it's not because Adam works so well, it's because
490.58|3.7| Adam worked so well in the past. And now with these new
494.28|3.44| architectures, people just keep using Adam and the new
497.72|4.32| architectures that evolved, expect that people use Adam. So
502.04|3.8| Adam is essentially a good fit for these architectures, because
505.84|3.52| these architectures were evolved with Adam in mind. So there's
509.36|4.68| like this evolution kind of bias here. So here, the person also
514.04|3.28| says usually people try new architectures, keeping the
517.32|3.2| optimization algorithm fixed. And most of the time, the
520.52|2.92| algorithm of choice is Adam, this happens because as
523.44|2.32| explained above, Adam is the default optimizer, it's like a
525.76|5.8| chicken egg problem in a way. So yeah, and recently, that was
532.16|2.92| so that a couple of weeks ago, actually, in a talk, this
535.08|4.2| figure, so there was also some additional independent
539.28|4.36| evaluation of these different optimization algorithms. And
543.64|3.32| here, essentially, the argument is, really, it does not matter
547.0|3.4| what type of optimization algorithm you use. So on the
550.4|4.32| left hand side, this is a resonant 18 residual network,
554.72|4.76| which we will talk about. Yeah, this next week, so it's a type
559.48|2.6| of convolution network. And here, this is a multi layer
562.08|4.84| perception. And they train this on cipher 10. So both methods
566.92|7.0| and here, this is the accuracy on the test set. And sorry, the
573.92|3.32| blue one is the test training set and the red one is a test
577.24|7.68| set. Let me write this down, train and test. And you can see
585.28|4.56| the training set accuracy for both convolutional networks, and
589.84|3.2| fully connected networks, multi layer perceptrons here are
593.08|2.12| essentially the same the trainings and accuracies.
595.36|4.0| However, the tests that accuracy here, that's a huge difference.
599.64|4.64| So architecture make can make a huge difference in terms of the
604.28|2.24| generalization performance, even though let's say the training
606.52|3.68| accuracy remains the same. So architectural choice is very
610.2|4.56| important. However, in contrast to the architecture choice, so
614.76|4.84| here, they trained a VGG 13, which is a different convolution
619.6|3.56| network. So for this training here, they used different
624.4|3.68| optimization algorithms, for example, SGD, SGD with momentum,
628.12|4.72| SGD with Nester of momentum, or Adam here, and you can see that
632.84|3.12| the while the training performance is slightly different,
635.96|3.64| maybe the test set performance is almost identical, you can see
639.6|3.52| that there's almost virtually no difference in the test performance,
643.12|3.92| maybe one or 2% points. And yeah, here really, what we can
647.04|4.36| see is that, honestly, the type of optimization algorithm that we
651.4|4.3| use doesn't matter that much as we might think it's really, if
655.7|2.22| you want to, let's say get better performance, it's
657.92|3.12| probably better to look at different architectures rather
661.04|4.32| than different optimization algorithms. That being said,
665.36|4.64| there was recently also a new optimizer that was pretty
670.0|3.44| popular, or became very popular very quick. Let's say I saw that
673.48|5.04| in several discussion forums. So there's this this add a belief
678.56|4.88| optimizer, which is essentially a modification of Adam. So here
683.44|4.56| on the left hand side is the regular Adam optimizer. And on
688.0|3.0| the right hand side is this add a belief optimizer and in blue.
691.96|4.08| So I can also release blue here in the blue font, you can see
696.04|3.4| the little changes to it. I don't want to discuss this in
699.44|2.36| too much detail, because I want to wrap up this lecture, it was
701.8|3.16| long enough. But yeah, this is another interesting or new
704.96|5.4| optimizer. And of course, you can see it performs better than
710.4|2.54| the other ones in blue here. That's the other belief
712.96|4.76| optimizer. And it outperforms other optimizers using VGG 11
717.72|2.96| and resnet 34, which are both convolution networks that we
720.68|27.6| will talk about. And we will also start using cipher tendon.