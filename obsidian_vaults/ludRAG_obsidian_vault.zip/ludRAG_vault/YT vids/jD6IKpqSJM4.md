start_time|end_time|text
1.56|3.34| Yeah, hi, everyone. I hope you had a nice weekend. I saw you
4.9|2.9| all submitted your project proposals as you were supposed
7.8|3.28| to. So this week, I will be trying to get through them and
11.1|3.42| give you some feedback on your projects. So like I said, the
14.52|3.24| grading will be rather generous for the proposals because the
17.76|3.06| main goal is really to have a plan and to see what you're
20.82|4.08| working on. So yeah, with that, lecture wise today, we are
24.9|3.94| finally starting to cover multi layer perceptrons, that is
28.84|3.72| multi layer neural networks has been quite some lectures to get
32.56|3.44| here. But I hope near all the previous lectures were useful
36.0|4.24| for providing you some foundation. And now, yeah, now
40.24|2.76| we are getting to the fun part where we will be working with
43.24|2.28| deeper and deeper neural networks. Now the multi
45.52|3.36| layer perceptrons, then we will look at some tricks to make the
48.88|4.16| learning more stable or better. And then yeah, we will move on
53.04|2.76| to convolutional networks, recurrent neural networks, and
55.8|2.96| then the generative models. All right, with that, let me get
58.76|0.6| started then.
60.8|3.64| Yeah, for today's lecture, there are two main points. First of
64.44|4.56| all, today, we will finally be able to solve the X or problem.
69.4|4.02| So the X or problem is something I introduced earlier, yeah, long
73.42|2.98| time ago, when we talked about the perceptron. So that is a
76.4|2.72| data set that looks actually very simple. It's only two
79.12|3.36| features. But the way these classes are arranged, the
82.48|3.88| perceptron, edeline and logistic regression classifiers that we
86.36|3.0| covered wouldn't be able to solve it. But the multi layer
89.36|5.76| perceptron will be able to solve it. Yeah, however, X or problems
95.12|2.88| are not super interesting, because, yeah, where do you
98.0|3.36| encounter an X or problem in real life. So in that way, we
101.36|4.96| will also see how we can classify cats and dogs using a
106.32|5.0| multi layer perceptron from image data. So the broad topics
111.32|2.88| I have in mind for today is introducing the multi layer
114.2|3.36| perceptron architecture, then talking a little bit more about
117.56|3.04| the different nonlinear activation functions. So one
120.6|2.4| nonlinear activation function you have already seen in the
123.0|3.36| context of logistic regression, actually, I've seen two, you
126.36|6.8| have seen the sigmoidal logistic logistic sigmoid, it's probably
133.36|7.24| more common way to say it, the logistic sigmoid function. And
140.6|3.92| you have seen the softmax function, the softmax function
144.52|3.56| is usually something that is used before the output layer.
148.08|3.32| But for the hidden layers in a multi layer perceptron, there
151.6|2.96| are different choices for nonlinear activation functions,
154.56|2.72| the logistic sigmoid would be one of them. But we will also
157.28|4.28| take a look at some other ones. Then I will show you some code
161.56|3.36| examples implementing a multi layer perceptron and pytorch.
165.36|2.88| And yeah, then we will talk a little bit about overfitting and
168.24|3.76| underfitting. So these are really important topics, you
172.0|2.32| know, underfitting and overfitting that's related to
174.32|5.0| how well our model fits the data, fitting the data not well
179.32|3.24| enough is of course bad, but also fitting the data too well
182.56|3.96| can also be bad. And then finally, I will show you how we
186.52|5.64| can apply this to a cat's versus Doc's data set. So here, I will
192.16|3.12| introduce how we can use custom data loaders. So that is
195.28|3.36| something I think you will find very useful when you will be
198.64|3.12| working on your own projects where you have your own data
201.76|4.8| sets. Of course, a multi layer perceptron is not great for
206.56|3.08| image data. For that there are convolutional networks. But
209.64|3.88| yeah, introducing one thing at a time, we will first apply our
213.52|3.76| multi layer perceptron to this cats and dogs problem. And then
217.28|3.24| later, we will use convolution networks to solve it a little
220.52|3.88| bit better. Alright, so that is the overview. And in the next
224.4|3.36| video, I will start explaining the multi layer perceptron
227.76|27.0| architecture.