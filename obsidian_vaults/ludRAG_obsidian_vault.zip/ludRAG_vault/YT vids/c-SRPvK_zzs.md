start_time|end_time|text
2.08|3.64| Alright, let's now talk about how we can use these optimization
5.72|3.52| algorithms in Python. And I can promise you this is going to be
9.24|3.4| a very short video because it's super simple to do in pytorch.
13.8|5.04| So the most common optimization algorithms are still SGD, the
18.84|4.8| regular SGD with momentum. And Adam, there are of course,
23.68|2.68| other optimization algorithms, and I will mention some of them
26.36|3.44| in the next video. But yeah, these two are usually the ones
29.8|4.96| that most people use in practice. And if you are also
34.76|3.68| interested in using other types and exploring them, you can also
38.44|3.32| find them here under this website. And there's also a
41.76|3.84| more detailed description of the parameters that we can use. So
46.2|4.68| how we use them here, you have already used optimum SGD before
50.88|4.6| and previous code examples and the homework, I think. So right
55.48|2.4| now, the only difference is really that here, I added the
57.88|4.96| momentum term to it. Usually, I find that using a learning rate
62.84|3.88| of point or one or point or one works well. But you have, of
66.72|2.52| course, to experiment with it, it really depends on the data
69.24|5.12| set and weight initialization and data normalization, batch
74.36|3.16| norm, and so forth. There are many, many things that affect
77.56|2.84| finding a good learning rate. So it's something you have to try
80.4|3.92| out in practice. When I use SGD, I usually also use a learning
84.32|3.8| rate scheduler, I will show you or give you the code for
88.12|4.2| reference later in the slides. And if I use a learning rate
92.32|5.04| scheduler, I usually also use a learning rate of point one. For
98.04|4.36| Adam, I usually don't do anything I use usually a learning
102.4|5.24| rate of point or one or point or five. These usually work well
107.64|3.52| for me. But again, it depends on the problem I recommend also
111.16|3.56| exploring some different learning rates. But most of the
114.72|5.0| time, something like point or five works well for me. And it's
119.74|3.18| sometimes also easier to find a good learning rate with Adam
122.92|4.2| compared to SGD with SGD, I have to try out many more things to
127.12|4.64| get it to work with with whereas with Adam, usually, multiple
131.76|6.24| learning rates can work well in practice. So if you're using any
138.0|4.88| of these like the momentum or Adam versions, also the momentum
142.88|3.96| version of SGD or Adam, then yeah, and you want to save your
146.84|4.84| model for continuing training later on, you also have to save
151.72|3.44| and load the optimizer because there is now a given state. So
155.16|3.04| there's a state for the momentum and also for the adaptive
158.2|3.48| learning rate component, the RMS proper component. But yeah, I
161.68|4.16| talked about saving and loading optimizers. And in earlier
165.84|2.88| videos, I think it was like two or three videos ago. So if you
168.72|4.64| work with the momentum version or the Adam and you want to
173.48|3.56| continue training at a latest time point, make sure you know
177.04|5.96| how to save and load the optimizer states too. So just a
183.0|3.68| little bit more about Adam. So in the previous video, I showed
186.68|3.48| you that there are two parameters. So the alpha
190.16|3.48| parameter for the momentum term and the beta parameter for the
193.64|6.52| RMS prop term. Yeah, they are also available to modify in the
200.16|4.64| Adam optimizer. So here, they are both called betas, like in
204.8|4.64| the paper. So this would be beta one. And this one would be beta
209.48|4.88| one, two. And this one would be then beta two and beta two. So
214.36|3.64| just so you know what they mean. So the first value is for the
218.0|3.68| momentum beta. And the second value is for the RMS prop beta.
221.68|3.76| Personally, I never change these that usually works well for me
225.44|4.4| just keeping them as they are by default. And also in many
229.84|3.64| papers, when you read deep learning papers, almost no one
233.48|3.8| changes these parameters, they always say they use the default
237.28|2.72| parameters because they are they usually work pretty well in
240.0|7.04| practice. Here are two examples. I'm so of using these different
247.04|4.64| optimization algorithms. So here I was using an SGD with a
251.68|2.52| learning rate scheduler having the learning rate when it
254.2|4.74| plateaus, and also momentum term of point nine. So the momentum
258.94|4.66| term here was point nine, the learning rate was point one, and
263.6|5.04| it was halved. Every time the validation accuracy was
268.64|2.32| plateauing when it was not improving. So it was
270.96|2.56| fluctuating. And then I was having the learning rate to
274.04|2.88| stabilize the training. So that's then more like the fine
276.92|3.68| tuning stage. And you can see in the beginning, it's rather
280.6|3.92| noisy. And then probably after this having it stabilizes more
284.52|2.6| because there's no improvement anymore. So we can have the
287.12|4.12| learning rate and then remove that oscillation. So that's what
291.24|3.56| I was doing here. And with this setup, I reached accuracy of
294.92|3.8| test accuracy of 97.34%. On the right hand side, I was just
298.72|2.88| using Adam with default parameters, I think I used the
301.6|5.8| learning rate of point 005 here. And I got also essentially the
307.4|3.0| identical performance. But here you can see, because we are not
311.4|4.12| we're not using the learning schedule here, probably, we see
315.52|2.68| it's a little bit noisy here around that region. But to be
318.2|4.8| honest, both work perfectly fine in practice. And I find usually
323.0|3.32| Adam works a little bit better for me. But I'm also a very
326.32|3.72| impatient person. I think if I would toy around with the SGD
330.04|3.48| more, I could probably also get a similar good performance or
333.56|4.4| even outperform it. But yeah, Adam is something if you are
337.96|4.56| lazy, like me, it usually always works pretty well. And I kind of
342.52|4.16| like it for that reason. So in the next video, I want to just
346.68|4.08| briefly go over some, I would say I am more advanced concepts
350.76|2.6| regarding optimization algorithms, I want to talk about
353.36|2.44| them in detail, I just want to mention them by giving you
355.8|4.52| references for future study if you're interested.