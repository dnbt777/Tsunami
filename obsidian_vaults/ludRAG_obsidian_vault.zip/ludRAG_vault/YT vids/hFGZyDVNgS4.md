start_time|end_time|text
0.4|3.68| Yeah, now we have seen simple models like logistic regression,
4.3|3.98| and more complicated models like multi layer perceptrons. So I
8.28|3.32| think that's a great time now to talk about topics like over
11.6|3.4| fitting and under fitting. So in particular, problems with
15.0|4.08| models that are too simple, like logistic regression, and problems
19.08|3.48| with models that fit the data too well, maybe multi layer
22.56|4.28| perceptrons. So yeah, the big problem with models that are too
26.84|2.6| simple is that yeah, we don't get a good performance out of
29.44|4.04| them. For example, when we use logistic regression, on MNIST,
33.48|3.32| we got 93%. Whereas when we used on
40.84|3.08| Yeah, now that we have seen a selection of models like
43.96|3.0| logistic regression as a simple model, and multi layer
46.96|3.36| perception as a, I would say more complicated model, it's I
50.32|3.56| think a good time to talk about over fitting and under fitting.
54.08|3.0| In particular, problems that arise with models that are too
57.08|4.36| simple, like logistic regression, apply to MNIST data,
61.88|3.36| and models that fit data data too well, for example, multi
65.24|4.68| layer perceptrons with too many features. So yeah, with that,
69.92|3.66| let's talk about some of these topics. But I also wanted to
73.58|4.7| start this video with a small, let's say on quiz. So here, I'm
78.28|4.68| showing you some images from the MNIST data set. And yeah, the
82.96|6.88| question is, what image or what number do you think this is? So
89.84|5.32| yeah, the true label is actually an eight. The model predicts a
95.16|3.32| four, I can kind of see how it predicts a four, though. I mean,
98.48|3.56| if you look at it, it could be almost like something like this,
102.04|5.76| right? So something like this. So it's actually an eight, but it
107.8|3.0| doesn't look that far away from a four, to be honest, it's
110.8|3.66| actually a pretty tricky case. Or take a look at this one. What
114.46|5.18| would you think this image is? So yeah, as you may have thought,
119.64|3.64| it's a two, but also, it's actually not too far away from a
123.28|2.92| seven, right? If you think of a seven, like this, it's actually
126.2|3.56| not too far away. And in fact, that the model predicts a seven
129.76|5.02| here, or this, this one here, what would you think this number
134.78|4.66| here represents? So according to the labels, this is actually a
139.44|3.9| five, but I also can see how this might be a three almost,
143.34|5.5| right? So in that way, another ambiguous case. Last one. So
148.84|4.48| what do you think this one represents? Yep, it's a six. But
153.6|4.6| yeah, also, it could be very well be a zero. So like, like
158.2|4.58| this, maybe maybe someone was writing the zero like this. So
162.78|3.82| you can see, it's not always very obvious on what this
166.6|3.0| number represents. And that way, it's probably even impossible to
169.6|5.04| get a 100% prediction accuracy on that data set. Oops, I have
174.64|3.96| one more example here. So yeah, can you think what? Well, can
178.6|3.64| you guess what these numbers here are in terms of the true
182.24|3.64| labels and the predicted labels? So on the left hand side, we
185.88|2.76| have a true label two on the right hand side also true label
188.64|5.0| two. So both these numbers represent the digit two, but you
193.64|2.96| can see, they look very different from each other. And also,
196.6|2.92| yeah, the model in the left hand side, on the left hand side
199.52|5.12| predicts zero on the right hand side predictor seven. Yeah, so
204.64|4.56| here's an overview of some of the failure cases of a multi
209.2|3.92| layer perceptron trained on MNIST. So here, I was using a
213.12|5.32| not so good model. It was like a logistic sigmoid activation and
218.48|4.2| output layer. And I use the MSE squared error loss. So I only
222.68|4.6| got 93% accuracy. But that is really besides the point. So the
227.28|4.56| point here is really, it's useful to visualize some of the
231.84|4.2| failure cases. So if you train a network on a data set, it's
236.04|3.92| always good to look at the wrong prediction. Because sometimes,
240.2|3.24| you may also find there's just a mislabeling issue in the data
243.44|3.52| set that you may want to fix. So in that way, sometimes, yeah,
246.96|2.84| you get additional insights about your data, like issues
249.8|3.8| with your data by just looking at it. So yeah, here, it's just
253.6|3.22| interesting to see what the model here predicts. For
256.82|4.22| example, like I mentioned, in Germany, we write the seven like
261.04|3.48| this. And the US it's common to write a seven like this. In
264.52|4.56| Germany, it's common to write the one like this. In the US,
269.12|3.84| it's common to write the one like this. So I can see a model
272.96|7.48| may confuse American seven with a German one, for example, I
280.44|2.96| can't see this issue here in this data set. But what I can
283.4|4.08| see is that, for example, this seven here is mistaken by a
287.48|4.36| three, because a three also has this thingy here in the middle,
291.84|3.48| this little, yeah, I would, what would we call it? I don't know.
295.52|3.78| But you can see this is maybe on confusing the model thinking
299.3|4.92| it's a three while in truth, it's a seven. So here, just the
304.22|3.02| bottom line is it's useful sometimes to take a look at your
307.28|5.32| training data set and the wrong predictions. So talking now
312.6|4.12| about overfitting and underfitting. So overfitting
316.72|4.9| refers to the issue when the model memorizes details in the
321.62|3.9| training set that are only very specific to the training set,
325.52|7.32| but don't generalize to the test set. So here, for example, what
332.84|3.8| I'm showing you is a plot where I have the error on the y axis,
337.2|6.48| and the model capacity on the x axis. So what do we mean by
343.68|5.4| model capacity? So with model capacity, I mean, in a way, the
349.08|3.24| number of parameters or complexity of the model, think
352.32|8.52| of it for, for simple, for simplicity, as the number of
360.84|7.16| parameters, or the ability of the model to fit a complex
368.0|6.18| data set. So a model with more hidden layer compared to a model
374.18|3.5| with fewer layers, a model with more hidden layers, has a larger
377.68|5.24| capacity, or model with wider layers also has a larger capacity
382.92|4.12| to a model compared to a model with fewer or smaller hidden
387.04|3.54| layers. So usually, the more layers you have, or the wider
390.58|5.82| the layers are, the higher your model capacity. Alright, so what
396.4|2.84| I'm showing you here now is the training error first. So let's
399.24|4.16| focus on the training error in orange. So the error usually
403.4|6.54| goes down as the model capacity increases. So that means if we
409.94|3.7| have more layers, or, I mean, this is like, of course, not
413.64|3.56| generally true, because then we have issues like vanishing and
417.2|3.4| exploding gradient. So let's say if we have a wider layer, so if
420.6|7.18| we have, let's say, multi layer perceptron, where this represents
427.78|7.46| our hidden layer, if we make this hidden layer wider, like
435.24|4.16| this doubling the size, for example, we increase the
439.4|4.96| capacity of that model to fit a complex data set. So usually,
444.36|4.56| for the training set, the larger the capacity, the smaller the
448.92|6.44| error. For the test set, though, what we usually observe is,
455.36|4.32| first, if we have, so let's say we start with a very simple
459.68|3.12| model here on the left hand side, like only one hidden unit
462.8|3.0| or something in the hidden layer, then the model is too
465.8|4.32| simple to capture the trends or patterns in the training data.
470.12|5.24| So we start with a large error. But then as we make the hidden
475.36|5.28| layer wider, we see that the error goes down. But then let's
480.64|5.44| say we make the layer too large, so too many parameters to learn.
486.4|4.48| What we often observe is that the test set error goes up
490.88|4.64| again, because you know, the model has so many parameters
495.52|3.36| that it starts memorizing certain patterns in the training
498.88|4.88| set that don't generalize to the training set. So for example, in
503.76|2.96| terms of pattern, like, let's say individual positions of
506.72|5.04| pixels, that instead of more the general shape, it would pay too
511.76|2.88| much attention to a particular pixel or something like that.
515.92|4.0| And with generalization error, this is I mean, this is like the
519.92|9.52| performance on new data, for example, as measured, often it's
529.44|5.92| measured via a test set, an independent test set. So we
535.36|4.4| usually we use the test set to estimate the generalization
539.76|5.2| error. Yeah, one more thing under fitting. And our fitting
544.96|5.44| usually means if the model is not complex enough to capture
550.4|3.36| the trends in the data. So here, in this region, we can maybe
553.76|6.0| say that this is under fitting. And here, on the right hand
559.76|3.92| side, this would be overfitting. So overfitting is
563.68|4.24| usually if you how you would quantify this usually by looking
567.92|4.56| at the gap between training and test set performance. That is
572.48|4.88| usually one way to assess the degree of overfitting. Yeah, in
577.36|3.76| practice, you will sometimes also hear people saying a model
581.12|4.32| has high bias or model has high variance. So I want to briefly
585.44|3.92| go over the concept of the bias variance decomposition and how
589.36|3.36| it relates to overfitting and under fitting. However, this is
592.72|3.2| just a very brief rundown. It's not, I would say the most
595.92|3.36| important thing here in this course. So this course is about
599.28|3.04| deep learning. And because we have only so much time, we won't
602.32|3.2| talk about it's a model evaluation techniques in too
605.52|4.4| much detail. There's a simple technique that most people use,
609.92|3.68| I will talk about this a little bit after these slides. And
613.6|2.88| also we'll show you how that works. And yeah, in code
616.48|4.4| examples. So but just let's just focus on bias variance
620.88|2.4| decomposition. If you're interested in more model
623.28|4.32| evaluation aspects, I cover more of this in the 451
627.6|2.72| introduction to machine learning course, which I usually teach
630.32|3.76| in fall semester. So but here, because like I said, we only
634.08|2.96| have so much time in deep learning. I don't want to cover
637.04|3.36| this in too much detail here. But I think it's useful to have
640.4|4.0| a basic understanding of what bias and variance means in that
644.4|3.12| context, because you will probably read about this in a
647.52|6.8| paper at some point in your career. So let's say, we have a
654.32|2.96| model for regression, because it's simpler in this context,
657.28|5.04| let's say we have a regression model. And this is some value
662.32|3.68| for a given data point that we want to estimate, let's say,
666.0|3.76| call that value on prediction, theta, let's, let's say this is
669.76|7.44| a the true, true value. And we want to estimate this, let's say
677.2|5.44| by predicting its value using a regression model. And the
682.64|4.72| regression model produces this theta head here. So theta head
687.36|8.4| is the prediction. And now, so think of everything here in the
695.76|9.36| context of the squared, squared arrow. So here, we talk about the
705.12|3.76| bias variance decomposition of the squared error loss. And now
708.88|4.64| think of having like a large number of training sets, why we
713.52|3.52| have this large number of training sets is a weird, interesting
717.04|2.4| question. It's like a weird scenario. Usually, in practice,
719.44|2.96| we only have one training set. But just assume for the sake of
722.4|3.68| this example, that we have a very large number of training
726.08|3.2| sets, let's say we have 1 million training sets. So every
729.28|3.6| time we train a regression model on a training set, we get a
732.88|3.2| slightly different model, because the training sets are
736.08|9.12| not identical. So now think of training 1 million models. And
745.2|4.64| each model makes the prediction on the same data point. Let's
749.84|2.8| call this so the data point corresponding to the theta here,
752.64|3.2| let's call this data point, I was a prediction for the data
755.84|5.36| point, I, and then we average over them. So we average over
761.2|4.0| these prediction for that data point. So here, the expectation
765.2|4.56| is over the training sense. So we are predicting the data
769.76|5.92| point for these were using these different models. So then we
775.68|2.96| get this average value here, this expectation, and the
778.64|4.48| difference between this expected value, or this expectation of
783.12|2.72| the data head here of the estimated parameter, the
785.84|5.2| difference between those two, this is our bias, this is how
791.04|4.72| from an average, how far are we off from the true value? In
795.76|3.92| contrast, so the variance, we are just two different ways of
799.84|2.16| writing the variance, you've probably seen that in other
802.0|3.92| statistics courses. But the main point is, the variance is
805.92|3.96| defined a little bit differently. It's how spread out
809.92|3.12| these predictions are. So if you have a prediction by a particular
813.04|4.28| model, and then you take the average prediction, so this is
817.32|8.88| really like here, the average prediction, how far, or how
826.2|3.84| spread are they? How far are these apart squared? So there's
830.04|4.16| no positive or negative value. So how far are they apart, and
834.2|3.68| then taking the expectation. So how far or how scattered our
837.88|2.88| predictions on average, basically. So because this is
840.76|3.48| like very weird to think about, conceptually, I find it easier
844.24|4.92| to have some drawings. I took this actually from 451. So
849.2|4.32| students will have taken 451 have seen my little drawing
853.52|4.44| here. So that's a person with a bow and arrow. And let's say
857.96|4.2| the person wants to hit some target here. There's also
862.16|3.44| usually some noise around the target. So in the data set, so
865.6|3.52| here for simplicity, maybe ignore the noise. And the goal
869.12|8.16| is for this person here to hit the target with an arrow. If so
877.28|4.44| you can see all the arrows fly short here. So the difference
881.72|4.96| between. So this party, let's say the average here, this would
886.68|2.92| be the expectation in the middle, if you take the average
889.6|5.36| of all these arrows here, this would be the expectation, you
894.96|3.04| can see the difference between this one and this one, this
898.0|5.6| would be the bias. And how scattered or how spread these
903.6|4.36| arrows are, that would be the variance. So why is why am I
908.0|4.92| explaining this? So usually people relate bias and variance
913.28|3.12| to overfitting and underfitting. Personally, I find it easier to
916.4|2.68| think just of overfitting and underfitting. But yes, some
919.08|3.76| people like to talk about models in terms of bias and variance.
923.0|4.24| So model with a high variance, if you would train that model
927.24|3.12| with different training sets, this would mean there's a large
930.36|3.64| variety of these predictions of the model. So model with high
934.0|3.84| variance is also more likely to overfit. And a model with high
937.84|5.92| bias means that it's kind of far off from the target. So in that
943.76|5.08| way, a model with high bias is usually on not not complex
948.84|2.32| enough. So it's usually underfitting. So high bias is
951.16|3.32| usually underfitting, and high variance is usually overfitting.
954.48|4.16| So I try to summarize that here in this plot. So again, we have
958.64|3.52| our error and the model capacity. So the training error
962.16|3.04| and generalization error is what I've shown you before. On the
965.2|3.64| left hand side, when we have a high error for both training and
968.84|9.8| test data, or high, let's say, high error, oops, surprisingly
978.64|2.44| difficult to talk and write at the same time for me, I don't
981.08|8.76| know why I'm high error for both training and generalization.
994.16|6.44| Let's say on both training and generalization should be in
1000.6|5.2| let's say in terms of in terms of both training and
1005.8|2.28| generalization. So if you have a high error, this is usually
1008.08|5.48| this is usually underfitting. And if we have a high
1013.6|3.28| generalization error, but a low training error, then this is
1016.88|4.0| usually the difference between the green one here, the orange
1020.88|5.52| groups on the orange one, this is usually overfitting. And
1026.72|3.48| variance and bias relates to that. So if we have a very
1030.56|3.76| simple model, low model capacity, usually has a low
1034.32|3.52| variance. So even if I fit the model on different training
1037.84|3.32| sets, the results are usually quite stable, because it doesn't
1041.16|4.6| memorize the data too closely. And then the variance goes up
1046.8|3.56| as we increase the model capacity. So in that way, the
1050.36|4.84| variance increases, and this is usually also correlated to
1055.44|4.92| increasing degrees of overfitting. Similarly, with a
1060.36|5.8| bias, so a model that is too simple has usually a high bias
1066.16|3.48| because it can't fit the data too well. It will always let's
1069.64|3.48| say provide a do very simple predictions that are always very
1073.12|4.92| similar. It's not complex enough to fit the data. And you can see
1078.04|3.36| though, as you increase the capacity bias goes down, so a
1081.4|4.36| high bias model is usually rated to underfitting. So again, for
1085.76|5.84| more details, I covered this in 451. But yeah, I'm more more
1091.6|2.68| detail, you don't really have to know for this course for the
1094.28|4.68| focus here on deep learning. So yeah, like I said, a more
1099.0|2.44| detailed understanding is not mandatory for this class, I
1101.44|5.24| won't ask you make any more details, let's say in quizzes or
1106.68|3.04| exams, and we just covered. So there's just like a briefly a
1109.72|3.68| brief overview. In practice, there are different ways we can
1113.4|4.92| evaluate models. There are like in 451, there are cross
1118.32|3.6| validation tests, we used bootstrapping and all types of
1121.92|3.32| different approaches. Deep learning, when we have very
1125.24|4.4| large data sets, we usually use the holdout method, where we
1129.64|3.24| have three data sets, a training, a validation and a
1132.88|3.88| test set. That is usually sufficient because we usually
1136.76|2.8| have very large test sets. So estimating the performance on a
1139.56|5.0| test set should be quite robust, given that we don't reuse our
1144.6|3.24| test set multiple times. So the focus is here really that our
1147.84|4.2| test set remains independent. So by that, what I mean is, um,
1152.04|5.72| usually we have a validation set that we look at when we tune the
1157.76|5.32| model. So what we do is usually we fit the model on the training
1163.08|2.24| data, then during training, we look at the validation
1165.44|3.24| performance. And then once we are finished, we get the final
1168.68|2.88| performance estimate on the test set. That's the usual approach.
1172.48|3.4| Yeah, and that is something we will also be using in the code
1175.88|4.04| examples. So there's nothing really, you have to pay
1179.92|3.32| particular attention to right now in this class. So for this
1183.24|3.04| class, we use this threefold holdout method, which is also
1186.28|2.32| common in the context of deep learning, if you look at
1188.6|4.92| literature. However, if you're interested in more details about
1193.52|3.36| model evaluation and best practices, well, we cover this in
1196.88|3.52| 451, which you probably either have taken or not taken, you
1200.4|3.72| don't have to know any of this for this class. But if you are
1204.12|4.32| interested, I have put up an article here on archive,
1208.76|3.88| summarizing basically my lecture notes on this is like different
1213.76|3.84| different techniques, statistical tests, cross
1217.6|3.76| validation, k fold cross validation, bootstrap estimates,
1221.36|3.08| and so forth. So yeah, you are welcome to check out this
1224.44|6.16| article if you are interested. Yeah, one aspect also about deep
1230.6|5.0| learning is that deep learning works best with large data sets.
1236.08|5.28| So here, I have drawn another conceptual plot related to the
1241.36|4.6| generalization error and here the training data set size. So if
1245.96|3.48| we have the comparison between traditional machine learning,
1249.76|3.32| for example, decision trees, random forests, support vector
1253.08|4.36| machines, things like that, compared to deep learning,
1257.44|4.56| usually, if we have a small data set, your traditional machine
1262.0|2.44| learning will perform better. So the generalization error for
1265.52|3.84| traditional machine learning will be lower. However, as the
1269.36|3.2| data set size increases, usually, we will find that also
1272.56|3.76| your traditional methods will perform better. But yeah, for
1276.32|5.76| deep learning, there's actually a really steep, steep decline of
1282.08|3.72| the error with increasing data set sizes compared to traditional
1285.8|4.04| machine learning. So especially deep learning works well with
1289.84|3.4| and really even requires large data sets to perform well,
1293.24|2.36| because yeah, we have large models that a lot of parameters
1295.6|4.4| and to, you know, to fit what to characterize the model, well, we
1300.0|5.76| need sufficient data. Um, yeah, so this is the traditional view,
1305.76|4.68| usually, the more data we have, the better. And also, this is
1310.44|4.72| something, if you find that your model doesn't perform well, you
1315.16|3.44| may end up tuning some hyper parameters, you might may find
1318.6|2.56| that hyper parameter tuning helps with improving the
1321.16|2.48| performance a little bit. But there will be probably a point
1323.64|3.08| where you can't even make any difference, no matter how many
1326.72|2.32| hyper parameter values to explore. And that might be a
1329.04|4.4| point where more data could be helpful. So but yeah,
1333.56|5.48| interestingly, I recently saw the paper on double descent. So
1339.04|2.96| there was a paper on double descent that came out in
1342.0|4.28| December 2019. So that's an observation that is quite
1346.28|3.12| interesting. And it's quite different from the common
1349.4|5.08| belief. So here, what the researchers did is they looked
1354.48|4.96| at CNN architecture, standard and resonance. So standard CNNs
1359.44|3.68| and residual networks, both things we will cover later in
1363.12|3.04| this course and transformers, which we'll also cover at the
1366.16|4.16| end of the course. So I'm not sure if this the insights here
1370.32|3.12| generalized to other models, like recurrent neural networks
1373.44|3.04| and multilayer perceptrons, because they haven't looked at
1376.48|3.4| those. But at least this was very interesting in the context
1379.88|4.16| of CNNs. So all the models were also trained with a cross
1384.04|5.44| entropy loss here. So yeah, there is this phenomenon of the
1389.56|3.96| double descent. So what does that mean? What does a double
1393.52|4.8| descent means? I mean, so here, what you can see is, like
1398.32|6.48| expected, the training error goes down as the model complexity
1404.8|4.84| increases. So here, you can think of x axis as model
1410.56|3.6| capacity, which we have looked at before. So that is expected.
1414.64|2.96| At some point, though, if we make the model too large, we
1417.6|3.8| will see that the arrow goes up. So here, the solid line is a
1421.4|5.04| test error, trained error goes still down. But the test error
1426.44|2.84| goes up. So this is what we talked about. This is the
1429.32|7.2| overfitting. Now, the surprise is that it goes up, but at some
1436.52|2.92| point, it goes down again. So what's going on here? Actually,
1439.44|6.2| people don't know quite know yet, why this happens. So there
1445.64|3.2| are some theories, I will share one of them in a later slide.
1449.04|3.12| But yeah, so what is interesting here is this double descent that
1452.16|2.8| it first goes down, that's the first descent, and then it goes
1454.96|3.8| down again, after going up, this is the double descent. So they
1458.76|4.4| observed it with four different model capacities. So if you make
1463.16|5.72| the model larger, you can observe this double descent. And
1469.24|5.56| you can also observe it if you train for more epochs. So here
1474.8|2.88| again, is a test error, they have here on the left hand side,
1477.96|2.72| three models, a small model and intermediate model and a large
1480.68|4.56| model. You can see when you train a small model for more
1485.24|4.52| epochs. You don't have this you go basically down, the
1489.76|4.76| generalization error goes down. So the model is improving the
1494.52|4.4| more epochs we train it for the intermediate model, you can see
1498.92|5.8| it, it goes down. But then at some point, it goes up again. So
1504.72|4.56| here, the model performs actually worse when we train it
1509.28|2.96| longer. So in this case, for this intermediate model, it
1512.24|3.16| would be good actually to stop the training early to stop and
1515.4|3.6| say training here. And in the next lecture, I will also talk
1519.0|5.0| more about early stopping as a way of regularizing regularizing
1524.0|2.74| the model, like improving the performance, preventing
1526.74|5.1| overfitting. And for the large model, you observe it goes down,
1532.26|2.86| then it goes up, similar to the intermediate model, but then it
1535.12|4.2| goes down again. So that's also this double descent here. So
1539.36|4.48| it's quite interesting. So yeah, on the right hand side is the
1543.84|3.4| same visualizing or the same thing just visualized
1547.24|3.44| differently for the model parameter size here on the x
1550.68|3.68| axis and the number of epochs on the y axis. So there are a
1554.36|5.04| couple of thoughts about that from the paper or theories. So
1559.4|6.0| at that critical region, so with critical region, they mean this
1565.4|4.08| region here in the red region. The reason why we might may
1569.48|6.96| find that it goes up here is that they think it's only one of
1576.44|3.68| the models fits the data well and is very sensitive to noise.
1580.28|4.28| So with one model, imagine you have a residual neural network
1584.56|2.16| and when you train in there are many, many different hyper
1586.72|4.76| parameter control model weights that you can define to fit the
1591.48|3.76| data well. So there are multiple possibilities. And there's only
1595.24|3.24| one that fits the data well, there's a particular combination
1598.48|5.32| of weights that fits the data well. But it's very sensitive to
1603.8|3.68| noise. So if you have small perturbations in a training set
1607.48|4.24| as you train, it's very sensitive, it's not guaranteed to
1611.72|5.16| find it. And also, it's really sensitive to the inputs. So if
1616.88|3.6| there's a slight perturbation in the inputs, the model may make
1620.48|2.96| the right prediction or wrong prediction. And that way, it's
1623.44|3.88| not so good in terms of generalizing. But if you have an
1627.32|3.92| overpermeable model, if a model is very large, there are many
1631.52|4.92| ways you can fit the data well. So you have a lot of weights and
1636.44|2.96| you only let's say maybe need a subset of those to perform well.
1639.4|3.12| And there are many different ways you can find a good subset
1642.52|5.44| of the weights. And so they theorize that sarcastic gradient
1647.96|4.44| descent finds one of these weight combinations that fits
1652.4|3.76| that training set well, but also performs well on the test set.
1656.5|7.26| So in that way, if I go back, so the claim is basically that
1663.76|5.16| here, the model that is learned is very sensitive to noise,
1668.92|6.08| whereas in this region here, yeah, we found a model that
1675.68|3.08| performs well on the training set, but also on the test set.
1679.76|3.48| There are more experiments in that paper also experimenting
1683.24|3.32| with different degrees of noise. So if you are interested in
1686.56|3.84| that, yeah, I recommend reading the paper here, I only took a
1690.4|3.08| very small number of figures to just illustrate this double
1693.48|6.04| descent phenomenon. So there's also it's the same as I show
1699.52|3.92| you, this is also an interesting figure, it shows both the number
1703.44|4.4| of epochs and the width. So there's essentially a model wise
1707.84|4.32| double descent and epoch wise double descent. So there are
1712.44|3.3| these double descent curves for both different sizes of the
1715.74|3.22| model. So if you have more parameters, and also for longer
1718.96|5.72| training. Lastly, there's also, yeah, something they observed
1724.68|5.16| with the number of training examples. So if you increase the
1729.84|4.04| data set size, there are also some little surprises, but I
1733.88|3.28| wouldn't say so they describe them in the paper as surprises,
1737.16|3.56| but I wouldn't say it's a big surprise, the general trend is.
1741.52|4.36| So if you have here the error from lowest to highest, so you
1745.88|2.64| have the lowest error in this region here, where you have a
1748.52|4.02| large model and a lot of data, or a small model and a large of
1753.08|4.48| amount of data, data. But what is weird is here in between, if
1757.56|4.38| you have an intermediate model, more training set site or larger
1761.94|4.66| training sets are actually worse compared or these models are
1766.6|2.92| worse compared to the small models and big models. And also
1769.52|5.4| when you look at this closely, let's say here, for example, you
1774.92|5.6| can see that increasing the number of training examples from
1780.52|4.2| here to here, improves the generalization error. But then
1784.72|3.12| from here to here, it becomes worse again, and then it becomes
1787.84|4.6| better again. So if you would plot that you have, let's say
1792.44|2.96| high generalization, or it drops, and then it becomes worse
1795.4|3.92| again. So that is also a little bit weird here. That's some
1799.34|5.26| surprise. But in general, you can see more training data helps
1804.6|3.12| and also more larger models perform better. So a good
1807.72|3.44| combination is large training set and a large model. So yeah,
1811.16|2.72| again, so this is just interesting. If you're
1813.88|4.64| interested, you can read about this more, why this doubly sent
1818.96|3.52| phenomena happens, I think that is not quite clear. Some people
1822.52|4.16| that say I saw some forums, even debate that this might be just
1826.8|4.56| some buck in the code or things like that. So many people,
1831.36|3.24| though, I can say have observed this independently. So it's
1834.6|4.12| probably a real thing. But why this happens there, that's not
1838.72|3.56| quite clear yet. So but yeah, moving on. So this was just a
1842.28|3.32| very brief video, actually, it was longer than I expected, but
1845.6|4.0| still a very brief video in the grand scheme of things like on
1849.6|2.92| overfitting and underfitting. And in the next video, I will
1852.6|3.96| show you how we can use multi layer perceptrons with custom
1856.56|3.36| data sets, because so far, we only have worked with MNIST. But
1859.92|3.16| yeah, chances are for your class project, you will want to work
1863.08|3.44| with your own data set. So that in the next video, I will show
1866.52|23.6| you how we can do that.