start_time|end_time|text
1.84|3.64| Yeah, now let's try to understand why dropout might
5.48|3.6| work well in practice. So why would it help? Yeah, making the
9.08|4.28| network perform better in terms of generalizing better to new
13.36|3.94| data, for instance, the test data. So one, yeah, one
17.3|4.26| interpretation is this co adaptation theory. So we will
21.56|3.16| talk about this briefly. And then the next video, I will talk
24.72|5.36| about the ensemble method interpretation. So here, the
30.1|3.86| co adaptation interpretation refers to the fact that now the
34.08|4.24| network will learn not to rely on particular connections too
38.32|3.36| heavily. So with that, I mean, if you have a multi layer
41.68|4.48| perceptron like that, and everything is like always
46.16|9.48| connected to everything else. So if we have something like that,
57.92|3.92| then if let's say this neuron is not there during training just
61.84|4.0| randomly, then the network will rely more on these neurons
65.84|2.88| compared to this one single neuron, and vice versa. For
68.72|4.0| example, if this is not here, the network will use these two.
72.72|3.6| And during training, it's always a different neuron, or there are
76.32|2.4| different neurons that are canceled, it could be one, it
78.72|3.68| could be none of them, it could be two of them, and things like
82.4|3.28| that. So there are always different combinations of
85.68|5.24| neurons being canceled. So the network can't rely on one neuron
90.92|4.52| too heavily. And that way, it will consider the others more.
95.44|4.32| And this could cause the weights to be more spread out, like that
99.76|5.44| it will try to put weights on all the neurons, instead of
105.2|3.44| having a large weight for let's say, one neuron, and small
108.64|2.16| weights for the others, because it can never count that this
110.8|3.36| particular neuron will be there. So in that way, it does make
114.16|4.0| sense to put too much weight on that neuron. So in that set,
118.2|3.64| this could have been a similar effect as the L2 norm, where
121.84|3.68| the weights will be more spread out and more uniform, rather
125.52|5.04| than being like, yeah, non uniformly distributed, it might
130.56|2.0| be actually interesting. I'm not sure if someone has done that
132.56|3.96| before, but just plotting the distribution of the weights for
136.52|5.64| each layer. So for instance, if we have, let's say magnitude
142.16|10.88| here on the y axis, and the weight index on the x axis, and
153.04|2.16| then if we have different layers, let's say this is for
155.2|5.24| layer L, maybe before dropout, we see something like where the
160.44|5.6| weights are not evenly distributed. And after dropout,
166.04|4.68| maybe we see something where the weights are more, more uniform.
170.96|1.92| I'm not sure if someone has looked at this yet, that might
172.88|4.04| be something interesting to do. Um, yeah, also, what I wanted to
176.92|3.08| say, just as an add on, you can certainly use different dropout
180.0|3.04| probabilities for the different layers. So you don't have to use
183.04|6.6| on 50% for every hidden layer, you can use 20%, 80%, and so
189.64|4.76| forth. It's also another hyper parameter to choose. So how you
194.4|2.16| have to choose this, it's depending on some
196.56|4.04| experimentation. 50% was like the original value, if I recall
200.6|3.16| correctly that they used in the paper. But nowadays, people also
203.76|5.48| use 20% or 80%. And that might be something yet to experiment
209.24|4.2| with. Okay, so this is just like one explanation why dropout may
213.44|4.04| perform well. So it's putting this, I would say emphasis on
217.48|3.48| particular nodes, and then it makes it maybe more robust to
220.96|3.4| fluctuations in the input. So in the next video, I want to
224.36|3.8| briefly talk about another explanation concerning the
228.16|11.64| ensemble method interpretation.