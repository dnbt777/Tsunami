start_time|end_time|text
5.759|4.081|hi everyone welcome to cs25 Transformers
8.639|2.641|United video
9.84|3.6|this was a course that was solid
11.28|3.899|Stanford in the winter 2023
13.44|3.179|this course is not about robots that can
15.179|3.6|transform into cars as this picture
16.619|3.781|might suggest rather it's about deep
18.779|2.881|learning models that have taken the
20.4|2.639|World by the storm and have
21.66|3.24|revolutionized the field of AI and
23.039|3.181|others starting from natural language
24.9|3.36|processing Transformers have been
26.22|4.62|applied all over from computer vision
28.26|3.72|enforcement learning biology robotics
30.84|3.0|Etc
31.98|3.36|we have an exciting set of videos lined
33.84|3.239|up for you with some truly fascinating
35.34|3.54|speakers skip talks
37.079|3.121|presenting how they're applying
38.88|4.699|Transformers to the research in
40.2|3.379|different fields and areas
43.92|3.84|we hope you'll enjoy and learn from
46.68|2.94|these videos
47.76|4.139|so without any further Ado let's get
49.62|5.099|started
51.899|4.921|this is a purely introductory lecture
54.719|4.02|and we'll go into the building blocks of
56.82|3.899|Transformers
58.739|4.32|so first let's start with introducing
60.719|4.44|the instructors
63.059|3.781|uh so for me I'm currently on a
65.159|3.721|temporary data Pro from the PHD program
66.84|3.36|and I'm leading AI to robotic startup
68.88|3.739|that I've added robotics so we're
70.2|5.82|working on some general purpose robots
72.619|4.54|uh somewhat like customer and
76.02|2.94|um yeah I'm very passionate about
77.159|3.901|Robotics and building assistive learning
78.96|3.72|algorithms my research interests are in
81.06|3.599|daily personal learning competitions in
82.68|3.9|Remodeling and I have a bunch of
84.659|3.901|Publications in a robot take part
86.58|3.48|numbers driving on the areas
88.56|3.12|um underground deposit Cornell if
90.06|3.26|somebody spoke for now so nice to meet
91.68|4.14|you
93.32|5.2|so I'm Stephen uh from the first year
95.82|5.64|CSP school here uh Pierce did my masters
98.52|4.919|at CMU and undergrad I wanted mainly
101.46|3.18|into NLP research anything involving
103.439|2.941|language and text
104.64|3.56|um but more recently I've been getting
106.38|4.62|more into computer vision as well
108.2|5.379|and just some stuff I do for fun a lot
111.0|4.68|of music stuff mainly piano some self
113.579|4.021|promo but I post a lot on my insta
115.68|3.18|YouTube and Tick Tock so if you guys
117.6|3.479|want to check it out
118.86|4.02|um my friends and I are also starting a
121.079|4.5|Stanford piano books if anybody's
122.88|4.26|interested feel free to email the DM me
125.579|3.841|for details
127.14|3.899|um other than that you know martial arts
129.42|3.84|bodybuilding
131.039|5.541|huge fan of k-dramas anime
133.26|3.32|occasional gamer
139.68|3.12|my name is Rylan um instead of talking
141.3|3.659|about myself
142.8|3.9|I just went super excited
144.959|2.941|the last one was off sorry to teach this
146.7|3.539|about excuse me I took it the last time
147.9|3.479|it was offered I did a bunch of fun
150.239|3.0|um I thought we brought in a really
151.379|3.961|great uh group of speakers last time I'm
153.239|3.901|super excited for this offering
155.34|3.06|um and yeah I'm thankful you're all here
157.14|2.94|and I'm looking forward to a really fun
158.4|3.9|quarter again thank you yeah it's a fun
160.08|4.5|fact Brandon was the most outspoken
162.3|5.54|student last year and it's like someone
164.58|3.26|wants to become instructed next year
169.2|2.7|yeah
170.7|3.119|okay
171.9|4.1|cool
173.819|2.181|um
176.06|3.7|so what we hope you will learn in this
178.62|3.18|class is first of all how do
179.76|3.66|Transformers work
181.8|4.019|um how they're being applied yes
183.42|3.899|definitely and nowadays like we are
185.819|4.2|pretty much using them everywhere in
187.319|5.101|yeah machine learning
190.019|6.44|um and lots of some new interesting
192.42|4.039|directions of research uh in this topics
197.22|3.72|uh cool so this class is just an
199.68|3.479|introductory so we're just talking about
200.94|3.78|the basics of Transformers introducing
203.159|4.201|them talking about the self attention
204.72|5.34|mechanism on which they're founded and
207.36|6.36|uh we'll do a deep dive more on like uh
210.06|5.459|models like birds GPD so get happy to
213.72|4.5|get solid
215.519|4.44|um okay so let me start with presenting
218.22|3.659|the attention timeline
219.959|5.161|uh attention all started with this one
221.879|5.461|paper transform attention is already at
225.12|3.66|l in 2017 that was the beginning of
227.34|3.6|Transformers
228.78|4.14|um before that we had the previous
230.94|4.68|historic error where we had models like
232.92|4.62|uh RNN lstms
235.62|3.899|um and their simple attention mechanisms
237.54|4.559|that will possible therefore
239.519|5.401|uh starting 2017 we solved this uh
242.099|5.461|explosion of Transformers into NLP where
244.92|4.02|people started using it for everything I
247.56|3.06|even heard the support from Google it's
248.94|5.939|like a performance increase every time
250.62|7.14|you fight our linguists uh
254.879|4.26|for the first 2018 after 2018 to 2020 we
257.76|4.02|saw this explosion of Transformers into
259.139|5.401|other few like question
261.78|5.58|um a bunch of other stuff and uh like
264.54|4.86|biology Alpha folded and in last year
267.36|3.18|2021 was the start of alternative era
269.4|3.239|where we got like a lot of opportunity
270.54|5.939|modeling uh started like almost like
272.639|5.34|kodaks uh GPT Davi stable diffusion
276.479|5.28|server a lot of like things happening in
277.979|6.061|uh genetic performance and uh and so we
281.759|4.921|actually started getting up in here
284.04|6.24|um and now is the present so this is uh
286.68|5.28|2022 and like the startup 2013 and now
290.28|3.419|we have models like uh chatricity
291.96|3.42|whisper
293.699|3.661|um a bunch of others and we are like
295.38|5.759|scaling onwards uh without spelling now
297.36|6.6|so that's great uh so that's the future
301.139|6.301|so going more into this um
303.96|7.14|so once there were elements so we have
307.44|5.699|people specific models lstns giu uh what
311.1|4.319|worked here was that they're good at
313.139|4.141|encoding history but what did not work
315.419|3.84|was they didn't and for long sequences
317.28|3.72|and they were very bad at encoding
319.259|5.041|context
321.0|5.46|uh so consider this example
324.3|4.5|consider trying to predict the last word
326.46|5.76|uh in the text I grew up in France dot
328.8|5.1|dot dot I speak fluent Dash here you
332.22|4.259|need to understand the context for it to
333.9|4.26|predict French and uh like attention
336.479|3.541|mechanism is very good at that whereas
338.16|3.72|if they're just using lstms uh it
340.02|3.959|doesn't work that well
341.88|4.259|uh another thing Transformers are good
343.979|5.461|at is
346.139|6.12|more based on content is like also
349.44|5.22|context prediction is like uh finding uh
352.259|5.16|attention Maps if I have uh something
354.66|6.24|like a word like it what noun does it
357.419|5.701|connect to and we can give a like a
360.9|4.44|probability attention on what are the
363.12|4.68|possible activations
365.34|4.859|um and this works with better than uh
367.8|4.679|existing mechanisms
370.199|5.641|okay
372.479|5.341|uh so where we were in 2021 we were on
375.84|3.72|the verge of takeoff we were starting to
377.82|4.02|realize the potential of Transformers in
379.56|5.16|different fields uh we solved a lot of
381.84|6.9|long sequence problems like uh protein
384.72|6.12|folding Alpha fold of NRL uh
388.74|4.98|we started to see three shots zero short
390.84|4.5|generalization we saw multimodal tasks
393.72|5.099|and applications like generating images
395.34|5.579|from language so that was Dali
398.819|4.94|um uh yeah and it feels like Asian but
400.919|2.84|personally like two years ago
403.979|4.5|and this is also a talk on Transformers
405.78|5.34|that you can watch on YouTube uh
408.479|5.28|yeah cool
411.12|5.94|um and this is where we was going from
413.759|4.681|2021 to 2022 which is we have gone from
417.06|3.3|the virtual thinking of actually taking
418.44|4.14|off and now we are seeing unique
420.36|4.679|applications and audio generation art
422.58|3.72|music storytelling we are starting to
425.039|3.841|see reasoning capabilities like Common
426.3|5.339|Sense uh logical reasoning mathematical
428.88|4.8|reasoning we are also able to now get
431.639|3.9|human Enlightenment and interaction
433.68|3.48|they're able to use a investment
435.539|3.481|learning and human feedback that's how
437.16|4.08|activity is trained to perform really
439.02|4.799|good uh we have a lot of mechanisms
441.24|5.04|spoken during toxicity bias in uh ethics
443.819|3.481|now and there are a lot of also a lot of
446.28|4.039|developments in other areas like
447.3|3.019|division models
450.36|2.88|cool
451.639|4.18|uh
453.24|5.359|so the feature is a spaceship and we're
455.819|2.78|all excited about it
459.12|3.54|um and there's a lot of more
460.74|4.5|applications that we can enable
462.66|5.46|um and uh it'll be great uh if you can
465.24|4.14|see Transformers also work there uh one
468.12|2.579|big example is with your understanding
469.38|3.719|and generation that is something that
470.699|3.661|everyone is interested in and I'm hoping
473.099|6.66|we'll see a lot of models in this area
474.36|7.2|this year uh also Finance uh business
479.759|3.84|um I'll be very excited to see gbt
481.56|4.56|author novel uh but we need to solve
483.599|4.5|very long sequence modeling and the most
486.12|3.359|transformative models are still limited
488.099|4.261|to like four thousand tokens or
489.479|5.101|something like that so we need to do a
492.36|5.7|make them generalize much more better on
494.58|5.519|Long sequences uh we are also we also
498.06|6.479|want to have generalized agents that can
500.099|6.241|do a lot of multi-task uh
504.539|5.761|automatic input
506.34|5.759|uh predictions like gato and uh so I
510.3|3.9|think we will see more of that too and
512.099|5.041|finally
514.2|5.339|um we also want domain specific models
517.14|4.44|so you might want like a GPD model let's
519.539|3.721|put it like maybe like you have so that
521.58|3.48|could be like a doctor GPT model you
523.26|3.24|might have like a large GPT model that's
525.06|3.24|like going on only on Law data So
526.5|3.42|currently we have like gbd models that
528.3|3.719|have trained on everything but we might
529.92|4.08|start to see more Niche models that are
532.019|3.781|like good at one task and we could have
534.0|3.6|like a mixture of experts so like you
535.8|3.3|can think like this is a like how you
537.6|3.239|normally consult an expert will have
539.1|2.88|like expert AI models and you can go to
540.839|3.5|a different air model for your different
541.98|2.359|needs
545.16|2.82|um there's still a lot of missing
546.36|4.979|ingredients uh to make this all
547.98|5.22|successful uh the the first of all is
551.339|4.081|external memory uh we are already
553.2|4.8|starting to see this with the models
555.42|3.96|like chantipity where uh the infections
558.0|3.899|are short-lived there's no long-term
559.38|4.56|memory and they don't have ability to
561.899|5.341|remember that our store conversations
563.94|4.74|for long term uh and uh this is
567.24|4.26|something we want to fix
568.68|4.8|uh second hour second is reducing the
571.5|4.74|computation complexity so attention
573.48|5.94|mechanism is quadratic over the sequence
576.24|6.84|plan which is slurred and uh we want to
579.42|5.16|radio ceramic faster uh
583.08|2.819|another thing you want to do is we want
584.58|3.18|to enhance the controllability of these
585.899|4.321|models like a lot of the smalls can be
587.76|3.84|stochastic and we want to be able to
590.22|2.7|control what sort of outputs we get from
591.6|2.52|them
592.92|3.12|um and you might have experienced the 10
594.12|3.24|GPT which is refresh you get like
596.04|3.0|different output each time but you might
597.36|4.2|want to have a mechanism that controls
599.04|5.1|what sort of things you can uh and
601.56|3.899|finally we want to align our state of
604.14|4.74|art language models with how the human
605.459|4.741|brain works and uh we are seeing the
608.88|3.06|search but we still need more research
610.2|4.62|on seeing how it can be more important
611.94|6.0|okay thank you
614.82|5.519|great bye uh yes I'm excited to be here
617.94|4.019|uh I live very nearby so I got the
620.339|3.361|invites to come to class and I was like
621.959|3.241|okay I'll just walk over
623.7|4.92|um but then I spent like 10 hours on
625.2|4.44|those slots so it wasn't as simple uh so
628.62|3.36|yeah I want to talk about uh
629.64|3.84|Transformers I'm going to skip the first
631.98|2.64|two over there we're not going to talk
633.48|2.76|about those we're going to talk about
634.62|3.6|that one just to simplify the lecture
636.24|2.94|since we've done a Time
638.22|3.48|um
639.18|4.44|okay so I wanted to provide a little bit
641.7|3.54|of context of why does this Transformers
643.62|3.36|class even exist so a little bit of
645.24|4.14|historical context I feel like Bilbo
646.98|4.68|over there I joined uh like telling you
649.38|4.68|guys about this um and I think I saw a
651.66|5.46|little drinks uh and basically I joined
654.06|5.04|AI in roughly 2012 simple course so
657.12|3.48|maybe a decade ago and back then you
659.1|3.54|wouldn't even say that you joined AI by
660.6|3.96|the way that was like a dirty word uh
662.64|3.24|now it's okay to talk about but back
664.56|2.519|then it was not even deep learning it
665.88|4.019|was machine learning that was a term
667.079|5.401|reviews uh if you were serious but now
669.899|4.141|um now ai is okay to use I think uh so
672.48|2.94|basically do you even realize how lucky
674.04|3.84|you are potentially entering this area
675.42|4.74|in roughly going through three uh so
677.88|4.26|back then in 2011 or so when I was
680.16|2.88|working specifically on computer vision
682.14|3.84|um
683.04|4.979|your your pipelines looked like this
685.98|3.72|um so you wanted to classify some images
688.019|3.361|uh you would go to a paper and I think
689.7|3.54|this is representative you would have
691.38|3.899|three pages in the paper describing all
693.24|3.48|kinds of a zoo of kitchen sink of
695.279|3.721|different kinds of features descriptors
696.72|4.14|and you would go to um poster session
699.0|2.7|and in computer Vision conference and
700.86|1.919|everyone would have their favorite
701.7|2.28|feature descriptors that they're
702.779|2.461|proposing and it's totally ridiculous
703.98|2.4|and you would take notes on like which
705.24|2.82|one you should incorporate into your
706.38|3.36|pipeline because you would extract all
708.06|3.06|of them and then you would put an svm on
709.74|3.2|top so that's what you would do so
711.12|4.08|there's two pages make sure you get your
712.94|4.66|histograms your ssims your color
715.2|3.78|histograms textiles tiny images and
717.6|3.239|don't forget the geometry specific
718.98|4.02|histograms all of them have basically
720.839|3.541|complicated code by themselves so you're
723.0|4.38|collecting code from everywhere and
724.38|6.62|running it and it was total nightmare so
727.38|6.66|that on top of that it also didn't work
731.0|5.14|so this would be I think representative
734.04|3.6|prediction from that time uh you would
736.14|2.819|just get predictions like this once in a
737.64|2.4|while and you'd be like you just shrub
738.959|2.761|your shoulders like that just happens
740.04|3.06|once in a while today you would be
741.72|4.08|looking for a bug
743.1|4.14|um and worse than that
745.8|4.02|every single
747.24|4.14|um every single sort of feel of every
749.82|3.78|single chunk of AI had their own
751.38|4.019|completely separate vocabulary that they
753.6|3.78|work with so if you go to an if you go
755.399|3.12|to NLP papers those papers would be
757.38|3.959|completely different so you're reading
758.519|4.021|the NLP paper and you're like what is uh
761.339|3.481|this part of speech tagging
762.54|5.58|morphological analysis syntactic parsing
764.82|5.459|co-reference resolution what is mpbt KJ
768.12|3.18|and you're confused so the vocabulary
770.279|2.941|and everything was completely different
771.3|3.599|and you couldn't read papers I would say
773.22|3.299|across different areas
774.899|5.461|so now that changed a little bit
776.519|5.701|starting 2012 when uh you know askewsky
780.36|4.26|and the colleagues basically
782.22|4.919|demonstrated that if you scale a large
784.62|4.32|neural network on large data set you can
787.139|3.061|get very strong performance and so up
788.94|3.3|till then there was a lot of focus on
790.2|3.78|algorithms but this showed that actually
792.24|3.42|neural Nets scale very well so you need
793.98|2.94|to now worry about compute and data and
795.66|3.6|you can scale it up it works pretty well
796.92|5.039|and then that recipe actually did copy
799.26|4.319|paste across many areas of AI so we
801.959|3.961|start to see a neural networks pop up
803.579|3.721|everywhere since 2012.
805.92|4.14|um so we saw them in computer vision and
807.3|4.32|NLP and speech and translation in RL and
810.06|3.42|so on so everyone started to use the
811.62|3.959|same kind of modeling toolkit model
813.48|3.539|framework and now when you go to NLP and
815.579|3.601|you start reading papers there in
817.019|3.781|machine translation for example uh this
819.18|3.659|is a sequel to sequence to paper which
820.8|3.42|we'll come back to in a bit you start to
822.839|3.18|read those papers and you're like okay I
824.22|2.94|can recognize these words like there's a
826.019|3.06|neural network there's some parameter
827.16|4.32|there's an Optimizer and it starts to
829.079|4.081|read like things that you know of so
831.48|3.9|that's a decreased tremendously the
833.16|3.6|barrier to entry across the different
835.38|3.48|areas
836.76|3.78|and then I think the big deal is that
838.86|3.779|when the Transformer came out in 2017
840.54|3.72|it's not even that just the toolkits and
842.639|3.361|the neural networks were similar is that
844.26|3.6|literally the architecture is converged
846.0|4.5|to like one architecture that you copy
847.86|4.56|paste across everything seemingly so
850.5|3.3|this was kind of an unassuming uh
852.42|2.64|machine translation paper at the time
853.8|3.24|proposing the Transformer architecture
855.06|3.839|but what we found since then is that you
857.04|4.919|can just uh basically copy paste this
858.899|4.74|architecture and use it everywhere and
861.959|3.661|what's changing is the details of the
863.639|4.021|data and the chunking of the data and
865.62|3.18|how you feed them and you know that's a
867.66|3.239|caricature but it's kind of like a
868.8|3.96|correct first order statement and uh so
870.899|2.88|now papers are even more similar looking
872.76|4.5|because everyone's just using
873.779|5.701|Transformer and uh so this convergence
877.26|4.439|is was remarkable to watch and unfolded
879.48|4.919|the last decade and it's pretty crazy to
881.699|3.961|me what I found kind of interesting is I
884.399|2.521|think this is some kind of a hint that
885.66|3.419|we're maybe converging to something that
886.92|4.08|maybe the brain is doing because uh the
889.079|3.721|brain is very homogeneous and uniform
891.0|3.839|across the entire sheet of your cortex
892.8|3.18|and okay maybe some of the details are
894.839|3.06|changing but those build like hyper
895.98|3.359|parameters but like a Transformer but
897.899|2.701|your auditory cortex and your visual
899.339|3.18|cortex and everything else looks very
900.6|4.14|similar and so maybe we're converging to
902.519|4.56|some kind of a uniform powerful learning
904.74|4.14|algorithm here uh something like that I
907.079|3.361|think is kind of interesting
908.88|2.639|okay so I want to talk about where the
910.44|2.339|Transformer came from very Point
911.519|4.44|historically
912.779|5.221|so I want to start in 2003 I like this
915.959|3.421|paper uh quite a bit it was the first
918.0|3.66|sort of um
919.38|4.019|popular application of neural networks
921.66|3.419|to the problem of language modeling so
923.399|2.94|predicting in this case the next word in
925.079|3.421|the sequence which allows you to build
926.339|3.24|generative models over text and in this
928.5|3.0|case they were using multi-layer
929.579|3.301|perceptron so very simple neural web the
931.5|2.519|neural Nets took three words and
932.88|3.84|predicted the probability distribution
934.019|5.041|for the fourth word in a sequence uh so
936.72|4.859|this was uh well and good at this point
939.06|5.519|now over time people started to apply
941.579|4.5|this to a machine translation so that
944.579|3.361|brings us to sequence to sequence paper
946.079|4.44|from 2014 that was pretty influential
947.94|3.78|and the big problem here was okay we
950.519|3.18|don't just want to take three words and
951.72|4.08|predict the four we want to predict how
953.699|4.2|to go from an English sentence to a
955.8|3.96|French sentence and the key problem was
957.899|3.541|okay you can have arbitrary number of
959.76|4.079|words in English an arbitrary number of
961.44|3.959|words in French so how do you get an
963.839|3.721|architecture that can process this
965.399|4.981|variably sized input and so here they
967.56|4.92|use a lstm and there there's basically
970.38|4.5|two chunks of this which are covered by
972.48|5.159|the slack by the um
974.88|5.94|by this but basically have an encoder
977.639|5.281|lstm on the left and it just consumes uh
980.82|3.9|the work one word at a time and builds
982.92|3.96|up a context of what it has read and
984.72|4.919|then that acts as a conditioning Vector
986.88|4.259|to the decoder RNN or lstm that
989.639|3.481|basically goes chong chong chunk for the
991.139|3.961|next word in the sequence uh translating
993.12|4.44|the English to French or something like
995.1|3.96|that now the big problem with this that
997.56|3.24|people identified I think very quickly
999.06|4.019|and tried to resolve is that there's
1000.8|5.339|what's called this um encoder bottleneck
1003.079|4.68|so this entire English sentence that we
1006.139|3.721|are trying to condition on is packed
1007.759|4.26|into a single Vector that goes from the
1009.86|3.36|encoder for the decoder and so this is
1012.019|2.82|just too much information to potentially
1013.22|3.299|maintain a single vector and that didn't
1014.839|3.3|seem correct and so people are looking
1016.519|3.841|around for ways to alleviate the
1018.139|4.081|attention of sorry the um encoded
1020.36|3.479|bottleneck as it was called at the time
1022.22|3.599|and so that brings us to this paper
1023.839|5.46|neural machine translation by jointly
1025.819|5.221|learning to align and translate and
1029.299|3.361|that here just moving from the abstract
1031.04|3.0|in this paper we conjectured that the
1032.66|2.7|use of a fixed lung Vector is a
1034.04|2.879|bottleneck in improving the performance
1035.36|3.42|of the basic encoder decoder
1036.919|3.78|architecture and propose to extend this
1038.78|4.019|by allowing the model to automatically
1040.699|3.661|soft search for parts of the source
1042.799|3.241|sentence that are relevant to predicting
1044.36|3.959|a Target word
1046.04|4.5|um yeah without having to form these
1048.319|6.061|parts or hard segments explicitly so
1050.54|5.94|this was a way to look back to the words
1054.38|4.38|that are coming from the encoder and it
1056.48|5.1|was achieved using this soft search so
1058.76|5.4|as you are decoding in the
1061.58|4.2|the words here while you are decoding
1064.16|4.019|them you are allowed to look back at the
1065.78|3.779|words at the encoder via this soft uh
1068.179|3.721|attention mechanism proposed in this
1069.559|4.561|paper and so this paper I think is the
1071.9|3.6|first time that I saw basically uh
1074.12|4.2|attention
1075.5|4.679|um so your context Vector that comes
1078.32|5.099|from the encoder is a weighted sum of
1080.179|6.661|the Hidden states of the words in the um
1083.419|6.421|in the encoding and then the weights of
1086.84|4.8|this sum come from a soft Max that is
1089.84|3.66|based on these compatibilities between
1091.64|3.6|the current state as you're decoding and
1093.5|3.6|the hidden States uh generated by the
1095.24|3.78|encoder and so this is the percent that
1097.1|4.98|really you start to like look at it and
1099.02|5.22|and this is the current modern equations
1102.08|3.66|of the attention and I think this was
1104.24|3.36|the perspective that I saw it in it's
1105.74|5.1|the first time that uh there's a word
1107.6|5.819|attention used as far as I know to call
1110.84|4.32|this mechanism so actually try to dig
1113.419|3.301|into the details of the history of the
1115.16|4.019|attention uh so the first author here
1116.72|4.199|Dimitri I um I had an email
1119.179|3.181|correspondence with him and I basically
1120.919|2.821|sent him an email I'm like Dimitri this
1122.36|2.939|is really interesting Transformers have
1123.74|2.939|taken over where did you come up with
1125.299|2.88|the self-detension mechanism that ends
1126.679|3.961|up being the heart of the Transformer
1128.179|4.441|and uh to my surprise he wrote me back
1130.64|3.84|this like massive email which was really
1132.62|3.299|fascinating so this is an excerpt from
1134.48|2.579|that email
1135.919|3.061|um
1137.059|3.781|so basically he talks about how he was
1138.98|3.12|looking for a way to avoid this
1140.84|2.82|bottleneck between the encoder and
1142.1|3.24|decoder he had some ideas about the
1143.66|4.259|cursors that traversed the sequences
1145.34|4.02|that didn't quite work out and then here
1147.919|3.0|so one day I had this thought that it
1149.36|3.24|would be nice to enable the decoder RNN
1150.919|4.081|to learn to search where to put the
1152.6|3.48|cursor on the source sequence this was
1155.0|4.44|sort of inspired by translation
1156.08|6.06|exercises that um learning English in my
1159.44|4.02|middle school involved you gaze shifts
1162.14|4.14|back and forth between source and Target
1163.46|3.719|sequence as you translate so literally I
1166.28|2.22|thought this was kind of interesting
1167.179|3.481|that he's not a native English speaker
1168.5|4.2|and here that gave him an edge in this
1170.66|3.6|machine translation that read to led to
1172.7|4.26|attention and then led the Transformer
1174.26|4.38|so that was that's really fascinating
1176.96|3.06|um I expressed a soft search a soft Max
1178.64|3.96|and then weighted averaging of the
1180.02|4.56|bironial states and basically uh to my
1182.6|4.68|great excitement this word this word
1184.58|4.2|from the very first try so really I
1187.28|3.36|think interesting piece of history and
1188.78|4.56|as it later turned out that the name of
1190.64|4.8|RNN search was uh kind of lame so the
1193.34|4.38|better name attention came from Yeshua
1195.44|5.46|on one of the final passes as they went
1197.72|4.62|over the paper so maybe attention is all
1200.9|2.88|you need would have been called like RNs
1202.34|3.66|or just
1203.78|3.66|but we have Yeshua NGO to thank for a
1206.0|3.539|little bit of a better name I would say
1207.44|3.96|so apparently that's the the history of
1209.539|4.14|this
1211.4|4.019|okay so that brings us to 2017 which is
1213.679|3.781|attention is all you need so this
1215.419|3.601|attention component which in uh
1217.46|2.579|Dimitri's paper was just like one small
1219.02|4.019|segment and there's all this
1220.039|5.581|bi-directional RNN RNN and decoder and
1223.039|4.081|this Tesla modeling paper is saying okay
1225.62|2.88|you can actually delete everything like
1227.12|3.66|what's making this work very well is
1228.5|4.32|just detection by itself and so delete
1230.78|3.06|everything keep attention and then
1232.82|3.12|what's remarkable about this paper
1233.84|4.14|actually is usually you see papers that
1235.94|4.08|are very incremental they add like one
1237.98|3.6|thing uh and they still get it's better
1240.02|3.48|but I feel like attention is all in need
1241.58|3.839|was like a mix of multiple things at the
1243.5|3.179|same time they were combined in a very
1245.419|3.721|unique way
1246.679|4.62|and then also achieved a very good local
1249.14|3.72|minimum in the architecture space and so
1251.299|2.88|to me this is a really a landmark paper
1252.86|3.179|that um
1254.179|3.301|and it's quite quite remarkable and I
1256.039|2.64|think had quite a lot of work behind the
1257.48|3.059|scenes
1258.679|4.5|um so delete all the RNN just keep
1260.539|4.321|attention because attention is operates
1263.179|3.181|over sets and I'm going to go into this
1264.86|3.12|in a second you now need to positionally
1266.36|3.84|encode your inputs because attention
1267.98|3.96|doesn't have the notion of space right
1270.2|3.74|so
1271.94|2.0|um
1275.0|4.559|I should be very careful
1277.58|4.32|um they adopted this residual Network
1279.559|3.841|structure from resonance uh they
1281.9|4.5|interspersed attention with multilio
1283.4|4.68|perceptrons they they use layer Norms
1286.4|3.12|which came from a different paper they
1288.08|2.4|introduced the concept of multiple heads
1289.52|3.0|of attention that were applied in
1290.48|3.72|parallel and they gave us I think like a
1292.52|4.86|fairly good set of hyper parameters that
1294.2|5.339|to this day are used so the expansion
1297.38|4.08|factor in the multiple perceptron goes
1299.539|3.841|up by 4X so we'll go into like a bit
1301.46|3.66|more detail and this borax has stuck
1303.38|2.82|around and I believe like there's a
1305.12|2.22|number of papers that tried to play with
1306.2|3.42|all kinds of little details of the
1307.34|4.56|Transformer and nothing like sticks
1309.62|3.84|because this is actually quite good the
1311.9|4.259|only thing to my knowledge that stock
1313.46|4.079|that that didn't stick was this uh we
1316.159|3.661|shuffling up the layer Norms to go into
1317.539|3.721|the pre-norm uh version where here you
1319.82|3.06|see the layer Norms are after the
1321.26|3.6|multi-headed detection RP forward but
1322.88|3.6|they just put them before instead so
1324.86|3.12|just reshuffling of layer Norms but
1326.48|3.42|otherwise the gpts and everything else
1327.98|3.78|that you're seeing today is basically
1329.9|3.659|the 2017 architecture from five years
1331.76|4.32|ago and even though everyone is working
1333.559|4.74|on it it's proven remarkably resilient
1336.08|3.3|which I think is uh there are
1338.299|3.301|innovations that I think have been
1339.38|4.44|adopted also in positional encodings
1341.6|3.9|it's more common to use different rotary
1343.82|4.02|and relative positional encodings and so
1345.5|3.84|on uh so I think there have been changes
1347.84|3.06|but for the most part it's proven very
1349.34|4.02|resilient
1350.9|3.6|so really quite an interesting paper now
1353.36|3.179|I wanted to go into the attention
1354.5|4.919|mechanism
1356.539|4.681|um and I think I sort of like the way I
1359.419|4.26|interpret it is not
1361.22|4.439|is not similar to the ways that I've
1363.679|3.181|seen it presented before so let me try a
1365.659|3.421|different way
1366.86|3.24|um of like how I see it basically to me
1369.08|2.4|attention is kind of like the
1370.1|3.72|communication phase of the Transformer
1371.48|4.5|and the Transformer interludes two
1373.82|3.9|phases uh the communication phase which
1375.98|3.72|is the multi-headed attention and the
1377.72|4.5|computation stage which is uh this
1379.7|4.62|multilio perceptron or P1 so in the
1382.22|3.66|communication phase uh it's really just
1384.32|4.2|a data dependent message passing on
1385.88|4.62|directed graphs and you can think of it
1388.52|3.659|as okay forget everything with a machine
1390.5|4.2|translation and everything let's just we
1392.179|5.221|have directed graphs at each a node you
1394.7|3.959|are storing a vector and then
1397.4|2.759|um let me talk now about the
1398.659|2.821|communication phase of how these vectors
1400.159|2.88|talk to each other in this directive
1401.48|3.48|graph and then the compute phase later
1403.039|3.541|is just the multiple perceptron which
1404.96|3.0|now which then
1406.58|3.719|um basically acts on every note
1407.96|5.339|individually but how do these notes talk
1410.299|6.841|to each other in this directed graph so
1413.299|5.581|I wrote like some simple python uh like
1417.14|4.86|I wrote this in Python basically to to
1418.88|6.06|create one round of communication of uh
1422.0|6.059|using attention as the uh direct as the
1424.94|6.719|um Master passing scheme so here
1428.059|4.74|a node has this private data Vector as
1431.659|3.661|you can think of it as private
1432.799|5.221|information to this node and then it can
1435.32|3.839|also emit a key a query and a value and
1438.02|3.96|simply that's done by a linear
1439.159|4.14|transformation uh from this node so the
1441.98|3.84|key is
1443.299|3.421|um what are the things that I am
1445.82|3.599|um
1446.72|4.38|sorry the query is one of the things
1449.419|3.661|that I'm looking for the key is where
1451.1|2.88|the thing that I have and the value is
1453.08|2.219|one of the things that I will
1453.98|2.939|communicate
1455.299|3.181|and so then when you have your graph
1456.919|3.541|that's made up of nodes and some random
1458.48|3.36|edges when you actually have these nodes
1460.46|3.599|communicating what's happening is you
1461.84|4.86|Loop over all the nodes individually in
1464.059|4.74|some random order and you you are at
1466.7|5.099|some node and you get the query Vector Q
1468.799|5.581|which is common node and some graph and
1471.799|3.961|uh this is what I'm looking for and so
1474.38|3.48|let's just achieved via this longer
1475.76|3.84|transformation here and then we look at
1477.86|3.9|all the inputs that point to this node
1479.6|4.5|and then they broadcast what are the
1481.76|5.039|things that I have which is their keys
1484.1|5.579|so they broadcast the keys I have the
1486.799|6.061|query then those interact by dot product
1489.679|5.061|to get scores so basically uh simply by
1492.86|3.9|doing Dot product you get some kind of a
1494.74|3.52|unnormalized weighting well the
1496.76|3.36|interestingness of all of the
1498.26|3.48|information in my uh in the nodes that
1500.12|3.419|point to me and to the things I'm
1501.74|3.36|looking for and then when you normalize
1503.539|4.02|that with a soft Max so it just sums to
1505.1|4.439|one uh you basically just end up using
1507.559|3.901|those scores which now sum to one in our
1509.539|4.38|probability distribution and you do a
1511.46|6.42|weighted sum of the values uh to get
1513.919|6.24|your update so I have a query they have
1517.88|5.279|keys uh dot products to get
1520.159|5.041|interestingness or like Affinity softmax
1523.159|4.741|to normalize it and then we get some of
1525.2|4.079|those values flow to me and update me
1527.9|2.94|and this is happening for each node
1529.279|3.061|individually and then we update at the
1530.84|2.88|end and so this kind of a message
1532.34|5.04|passing scheme is kind of like at the
1533.72|7.14|heart of the Transformer and happens in
1537.38|5.34|a more vectorized uh batched way that is
1540.86|4.199|more confusing and is also intersberg
1542.72|4.02|with interspersonal layer norms and
1545.059|3.72|things like that to make the training uh
1546.74|3.96|behave better but that's roughly what's
1548.779|3.841|happening in the attention mechanism I
1550.7|2.78|think on a high level
1552.62|4.439|um
1553.48|4.66|so yeah so in the communication phase of
1557.059|3.6|the Transformer
1558.14|5.279|um then this message passing scheme
1560.659|5.941|happens in every head in parallel and
1563.419|4.681|then in every layer in series
1566.6|4.38|um and with different weights each time
1568.1|5.939|and that's the that's that's it as far
1570.98|4.98|as the multi-headed tension goes and so
1574.039|3.181|if you look at these encoder decoder
1575.96|2.52|models you can sort of think of it then
1577.22|2.64|in terms of the connectivity of these
1578.48|3.9|nodes in the graph you can kind of think
1579.86|3.78|of it as like okay all these tokens that
1582.38|3.179|are in the encoder that we want to
1583.64|4.019|condition on they are fully connected to
1585.559|3.6|each other so in when they communicate
1587.659|3.541|they communicate fully when you
1589.159|3.541|calculate their features but in the
1591.2|3.54|decoder because we are trying to have a
1592.7|3.599|language model we don't want to have
1594.74|3.299|communication from future tokens because
1596.299|4.62|they give away the answer at this step
1598.039|4.861|so the tokens in the decoder are fully
1600.919|3.721|connected from all the encoder States
1602.9|4.2|and then they are all Simply Connected
1604.64|3.779|from everything that is important and so
1607.1|3.84|you end up with this like triangular
1608.419|4.5|structure in the direct graph but that's
1610.94|4.08|the message passing scheme that this
1612.919|3.841|basically implements
1615.02|2.88|um and then you have to be also a little
1616.76|2.88|bit careful because in the cross
1617.9|3.48|attention here with the decoder you
1619.64|4.2|consume the features from the top of the
1621.38|4.14|encoder so um think of it as in the
1623.84|2.939|encoder all the nodes are looking at
1625.52|3.18|each other all the tokens are looking at
1626.779|3.361|each other many many times and they
1628.7|3.0|really figure out what's in there and
1630.14|4.58|then the decoder when it's it's looking
1631.7|3.02|only at the top notes
1634.76|3.299|so that's roughly the message passing
1636.559|3.36|scheme I was going to go into more of an
1638.059|3.12|implementation of the Transformer I
1639.919|4.221|don't know if there's any questions
1641.179|2.961|about this group
1644.62|4.919|self-advention but what is this
1650.36|4.679|yeah so um
1653.539|3.361|self protection and multi-headed
1655.039|3.601|detection so the multi-headed attention
1656.9|3.54|is just this attention scheme but it's
1658.64|3.419|just applied uh multiple times in
1660.44|3.119|parallel multiple heads just means
1662.059|2.881|independent applications of the same
1663.559|4.321|attention
1664.94|4.739|so this message passing scheme basically
1667.88|4.14|just happens uh in parallel multiple
1669.679|4.261|times with different weights for the
1672.02|3.6|query key and value so you can almost
1673.94|3.18|look at it like in parallel I'm looking
1675.62|3.72|for I'm seeking different kinds of
1677.12|3.659|information from different nodes that
1679.34|3.839|I'm collecting it all in the same note
1680.779|4.861|it's all done in parallel
1683.179|6.421|so heads is really just like copy paste
1685.64|7.039|in parallel and layers are copy paste
1689.6|3.079|but in series
1692.96|5.52|maybe that makes sense
1695.779|4.14|and self-attention when it's
1698.48|3.179|self-attention what it's referring to is
1699.919|3.901|that the node here
1701.659|3.421|um produces each node here so as I
1703.82|3.18|described it here this is really soft
1705.08|4.14|ocean because every one of these nodes
1707.0|4.26|produces a key query and a value from
1709.22|3.6|this individual node when you have cross
1711.26|4.08|attention
1712.82|4.859|you have one cross attention here
1715.34|3.66|um coming from the encoder that just
1717.679|3.961|means that the queries are still
1719.0|4.62|produced from this node but the piece
1721.64|4.56|and the values are produced as a
1723.62|4.32|function of nodes that are coming from
1726.2|4.68|the encoder
1727.94|5.099|so um I have my queries because I'm
1730.88|4.02|trying to decode some the fifth word in
1733.039|3.181|the sequence and I I'm looking for
1734.9|3.72|certain things because I'm the fifth
1736.22|4.079|word and then the keys and the values in
1738.62|3.36|terms of the source of information that
1740.299|3.36|could answer my queries can come from
1741.98|3.96|the previous nodes in the current
1743.659|4.02|decoding sequence or from the top of the
1745.94|3.54|encoder so all the nodes that have
1747.679|3.901|already seen all of the all of the
1749.48|3.78|encoding tokens many many times cannot
1751.58|2.579|broadcast what they contain in terms of
1753.26|2.279|information
1754.159|3.661|so
1755.539|4.5|I guess to summarize the self-attention
1757.82|4.92|is kind of like sorry cross attention
1760.039|4.02|and self-attention only differ in where
1762.74|3.299|the piece and the values come from
1764.059|5.041|either the keys and values are produced
1766.039|4.981|from this node or they are produced from
1769.1|4.439|some external Source like like an
1771.02|4.32|encoder and the notes over there but
1773.539|3.061|algorithmically is the is the same
1775.34|3.86|Michael
1776.6|2.6|operations
1780.02|2.48|okay
1788.6|3.439|so yeah so um
1794.72|3.6|um
1796.12|5.62|so think of
1798.32|5.479|um so each one of these nodes is a token
1801.74|2.059|um
1804.26|3.299|I guess like they don't have a very good
1805.88|2.88|picture of it in the Transformer but
1807.559|2.041|like
1808.76|4.26|um
1809.6|6.9|like this node here could represent the
1813.02|5.639|uh third word in the output in the
1816.5|4.14|decoder and
1818.659|4.681|um in the beginning it is just the
1820.64|4.82|embedding of the word
1823.34|2.12|um
1827.0|3.72|and then um
1829.58|2.28|okay I have to think through this
1830.72|3.679|knowledge a little bit more I came up
1831.86|2.539|with it this morning
1839.559|4.681|one example substantiation
1849.86|4.86|uh these notes are basically the factors
1852.799|3.301|um I'll go to an implementation I'll go
1854.72|3.48|to the implementation and then maybe
1856.1|4.799|I'll make the connections uh to the
1858.2|4.38|graph so let me try to first go to let
1860.899|3.601|me not go to with this intuition in mind
1862.58|3.3|at least uh to Nano GPT which is a
1864.5|3.419|complete implementation of a transformer
1865.88|3.779|that is very minimal so I worked on this
1867.919|4.74|over the last few days and here it is
1869.659|4.321|reproducing gpt2 on open webtext uh so
1872.659|4.081|it's a pretty serious implementation and
1873.98|4.74|reproduces gpd2 I would say and uh
1876.74|4.5|provided in the computer this was one
1878.72|4.62|node of atpus for 38 hours or something
1881.24|3.84|like that remember correctly and it's
1883.34|3.6|very readable it's 300 lives so everyone
1885.08|4.199|can take a look at it
1886.94|3.9|um and uh yeah let me basically briefly
1889.279|4.081|step through it
1890.84|4.62|so let's try to have a decoder only
1893.36|3.48|Transformer so what that means is that
1895.46|2.88|it's a language model it tries to model
1896.84|3.66|the
1898.34|4.079|um the next word in the sequence or the
1900.5|3.299|next character in the sequence so the
1902.419|3.0|data that we train on is always some
1903.799|2.941|kind of text so here's some fake
1905.419|2.581|Shakespeare sorry this is real
1906.74|3.0|Shakespeare we're going to produce a big
1908.0|3.48|Shakespeare so this is called the tiny
1909.74|3.6|Shakespeare data set which is one of my
1911.48|3.299|favorite toy data sets you take all of
1913.34|2.819|Shakespeare concatenate it and it's one
1914.779|3.12|megawatt file and then you can train
1916.159|3.061|language models on it and get infinite
1917.899|2.101|Shakespeare if you like which I think is
1919.22|2.699|kind of cool
1920.0|3.48|so we have a text the first thing we
1921.919|3.541|need to do is we need to convert it to a
1923.48|4.319|sequence of integers because
1925.46|4.86|Transformers natively process
1927.799|4.021|um you know um you can plug text into
1930.32|3.239|Transformer you need to some out encoded
1931.82|3.54|so the way that encoding is done is we
1933.559|3.961|convert for example in a simplest case
1935.36|4.38|every character gets an integer
1937.52|4.259|and then instead of hi there we would
1939.74|4.559|have this sequence of integers
1941.779|4.26|so then you can encode every single
1944.299|3.721|um character as an integer and get like
1946.039|4.321|a massive sequence of integers you just
1948.02|4.139|concatenate it all into one large long
1950.36|3.84|one-dimensional sequence and then you
1952.159|3.961|can train on it now here we only have a
1954.2|3.42|single document in some cases if you
1956.12|2.52|have multiple independent documents what
1957.62|2.76|people like to do is create special
1958.64|3.3|tokens and they intersperse those
1960.38|3.899|documents with those special end of text
1961.94|5.099|tokens uh that they splice in between to
1964.279|4.681|create boundaries but those boundaries
1967.039|4.801|actually don't have any
1968.96|4.56|um any modeling impact it's just that
1971.84|3.78|the Transformer is supposed to learn via
1973.52|3.96|back propagation that the end of
1975.62|4.26|document sequence means that you should
1977.48|5.52|wipe the memory
1979.88|5.64|okay so then we produce batches so these
1983.0|4.2|batches of data just mean that we go
1985.52|3.96|back to the one-dimensional sequence and
1987.2|5.52|we take out chunks of this sequence so
1989.48|6.299|say if the block size is eight uh then
1992.72|5.04|the block size indicates the um maximum
1995.779|4.081|length of context that your Transformer
1997.76|3.899|will process so if our block size is
1999.86|3.78|eight that means that we are going to
2001.659|4.201|have up to eight characters of context
2003.64|4.32|to predict the ninth character in a
2005.86|3.539|sequence and the batch size indicates
2007.96|3.18|how many sequences in parallel we're
2009.399|3.181|going to process and we want this to be
2011.14|2.879|as large as possible so we're fully
2012.58|3.66|taking advantage of the GPU and the
2014.019|3.841|parallels under the chords so in this
2016.24|4.2|example we're doing a four by eight
2017.86|5.52|batches so every row here is independent
2020.44|6.18|example sort of and then every um
2023.38|4.62|every uh every a row here is a is a
2026.62|2.76|small chunk of the sequence that we're
2028.0|3.299|going to train on and then we have both
2029.38|3.179|the inputs and the targets at every
2031.299|3.24|single point here
2032.559|3.72|so to fully spell out what's contained
2034.539|4.38|in a single four by eight batch to the
2036.279|6.661|Transformer uh I sort of like compact it
2038.919|6.781|here so when the input is 47 by itself
2042.94|6.239|the target is 58 and when the input is
2045.7|6.959|the sequence 4758 the target is one and
2049.179|5.341|when it's 47.581 the target is 51 and so
2052.659|3.781|on so actually the single batch of
2054.52|4.02|examples that score by eight actually
2056.44|3.239|has a ton of individual examples that we
2058.54|4.2|are expecting the Transformer to learn
2059.679|4.321|on in um in parallel and so you'll see
2062.74|4.02|that the batches are learned on
2064.0|4.56|completely independently but the uh the
2066.76|3.899|time Dimensions sort of here along
2068.56|3.839|horizontally is also trained on in
2070.659|4.68|parallel so sort of your your real back
2072.399|5.401|size is more like B times d it's just
2075.339|3.961|that the context grows linearly for the
2077.8|2.94|predictions that you make along the T
2079.3|3.78|Direction
2080.74|4.08|um in the in the model so this is how
2083.08|6.019|the this is all the examples of the
2084.82|4.279|model will learn from this single back
2089.2|6.06|so now this is the uh GPT class
2093.04|3.42|and uh because this is a decoder only
2095.26|2.64|model
2096.46|2.7|um so we're not going to have an encoder
2097.9|3.0|because there's no like English We're
2099.16|3.06|translating from we're not trying to
2100.9|3.06|condition on some other external
2102.22|3.84|information we're just trying to produce
2103.96|4.08|a uh sequence of words that follow each
2106.06|4.08|other are likely to
2108.04|3.36|so this is all pytorch and I'm going
2110.14|2.82|slightly faster because I'm assuming
2111.4|3.3|people have taken 231n or something
2112.96|3.6|along those lines
2114.7|4.379|um but here in the forward pass we take
2116.56|6.9|this uh these indices
2119.079|7.26|and then we both encode the identity of
2123.46|5.82|the indices just via an embedding lookup
2126.339|5.401|table so every single integer has a uh
2129.28|5.4|we index into a lookup table of vectors
2131.74|6.72|in this nn.embedding and pull out the
2134.68|5.64|the um word Vector for that token and
2138.46|3.54|then because the message because
2140.32|4.019|transformed by itself doesn't actually
2142.0|4.079|it processes sets natively so we need to
2144.339|3.481|also positionally encode these vectors
2146.079|3.78|so that we basically have both the
2147.82|4.56|information about the token identity and
2149.859|4.26|its place in the sequence from one to
2152.38|4.26|block size
2154.119|4.621|now those uh the information about what
2156.64|3.12|and where is combined additively so the
2158.74|3.0|token embeddings and the positional
2159.76|2.94|embeddings are just added exactly as
2161.74|2.7|here
2162.7|4.8|so this x here
2164.44|5.419|uh then there's optional Dropout this x
2167.5|5.22|here basically just contains the set of
2169.859|4.961|uh words
2172.72|3.84|um and their positions
2174.82|2.88|and that feeds into the blocks of
2176.56|3.299|Transformer and we're going to look into
2177.7|3.659|what's blocked here but for here for now
2179.859|3.421|this is just a series of blocks in a
2181.359|4.141|Transformer and then in the end there's
2183.28|5.22|a layer norm and then you're decoding
2185.5|5.16|the logits for the next
2188.5|4.02|um word or next integer in a sequence
2190.66|3.78|using a linear projection of the of the
2192.52|4.62|output of this Transformer so LM head
2194.44|4.32|here a shortcore language model head is
2197.14|4.92|just a linear function
2198.76|5.94|uh so basically positionally encode all
2202.06|5.1|the words feed them into a sequence of
2204.7|3.96|blocks and then apply a linear layer to
2207.16|4.199|get the probability distribution for the
2208.66|5.22|next uh character and then if we have
2211.359|4.081|the targets which we produced in uh the
2213.88|3.3|data loader and you'll notice that the
2215.44|3.84|targets are just the inputs offset by
2217.18|3.36|one in time
2219.28|2.7|then those targets feed into a
2220.54|2.76|cross-entropy loss so this is just a
2221.98|3.78|negative one likelihood typical
2223.3|5.16|classification loss so now let's drill
2225.76|4.319|into what's here in the blocks
2228.46|3.3|uh so these blocks that are applied
2230.079|2.881|sequentially
2231.76|3.54|um there's again as I mentioned
2232.96|4.379|communicate base and the compute base so
2235.3|4.26|in the communicate phase all the nodes
2237.339|3.721|get to talk to each other and so these
2239.56|4.62|nodes are basically
2241.06|5.58|if our block size is eight then we are
2244.18|4.14|going to have eight nodes in this graph
2246.64|3.24|there's eight notes in this graph the
2248.32|3.9|first node is pointed to only by itself
2249.88|4.68|the second node is pointed to by the
2252.22|3.78|first node and itself the third node is
2254.56|4.38|pointed to by the first two nodes and
2256.0|5.76|itself Etc so there's eight nodes here
2258.94|5.28|so you apply there's a residual pathway
2261.76|4.079|in X you take it out you apply a layer
2264.22|3.0|norm and then the cell potential so that
2265.839|3.0|these communicate these eight nodes
2267.22|4.02|communicate but you have to keep in mind
2268.839|5.881|that the dash is four so because batches
2271.24|5.16|four this is also applied uh so we have
2274.72|3.119|eight nodes communicating but there's a
2276.4|3.3|batch of four of them all individually
2277.839|3.541|communicating one those eight nodes
2279.7|4.879|there's no crisscross across the fashion
2281.38|3.199|motion of course there's no bash online
2284.74|4.379|um and then once they change information
2286.619|4.841|they are processed using the multilio
2289.119|5.361|perceptron and that's the compute phase
2291.46|5.82|so um and then also here we are missing
2294.48|5.2|we are missing the cross attention
2297.28|4.38|um and uh because this is a decoder only
2299.68|3.419|model so all we have is this step here
2301.66|3.24|the multi-headed retention and that's
2303.099|3.24|the Slime the communicate phase and then
2304.9|4.02|we have the feed forward which is the
2306.339|4.26|MLP and that's the complete phase
2308.92|2.76|I'll take I'll take questions a bit
2310.599|3.901|later
2311.68|4.32|then the MLP here is fairly
2314.5|3.599|straightforward the MLP is just
2316.0|3.48|individual processing on each node
2318.099|4.441|um just transforming the feature
2319.48|6.24|representation sort of at that node so
2322.54|5.039|um applying a two-layer neural net with
2325.72|3.42|a gallery nonlinearity which is just
2327.579|3.961|think of it as a relu or something like
2329.14|4.979|that it's just anonymity
2331.54|4.2|and then MLP straightforward I don't
2334.119|3.361|think there's anything too crazy there
2335.74|3.96|and then this is the causal soft
2337.48|4.32|retention part the communication phase
2339.7|3.54|so this is kind of like the neat of
2341.8|3.42|things and the most complicated part
2343.24|3.18|it's only complicated because of the
2345.22|3.899|batching
2346.42|5.46|and the implementation detail of how you
2349.119|4.801|mask the connectivity in the graph so
2351.88|3.36|that you don't you can't obtain any
2353.92|3.24|information from the future when you're
2355.24|4.14|predicting your token otherwise it gives
2357.16|4.439|away information so if I'm the fifth
2359.38|4.56|token and
2361.599|4.321|um if I'm the fifth position then I'm
2363.94|3.72|getting the fourth token coming into the
2365.92|3.78|input and I'm attending to the third
2367.66|3.78|second and first and I'm trying to
2369.7|4.32|figure out what is the what is the next
2371.44|4.26|token well then in this batch in the
2374.02|3.98|next element over in the time Dimension
2375.7|5.22|the answer is at the input so I can't
2378.0|4.42|get any information from there so that's
2380.92|3.54|why this is all tricky but basically in
2382.42|4.5|the forward pass
2384.46|6.24|um we are calculating the the queries
2386.92|5.46|keys and values based on x
2390.7|4.68|so these are the key squares and values
2392.38|5.34|here when I'm Computing the attention I
2395.38|4.199|have the queries The Matrix multiplying
2397.72|3.54|the keys so this is the dot product in
2399.579|4.741|parallel for all the queries and all the
2401.26|4.38|keys in all the heads so that I
2404.32|2.88|mentioned I thought to mention that
2405.64|3.36|there's also the aspect of the heads
2407.2|3.78|which is also done old in parallel here
2409.0|3.359|so we have the batch Dimension the time
2410.98|2.76|Dimension and the head Dimension and you
2412.359|3.0|end up with five dimensional tensors and
2413.74|3.119|it's all really confusing so I invite
2415.359|2.701|you to step through it later and
2416.859|2.941|convince yourself that this is actually
2418.06|3.299|doing the right thing but basically
2419.8|3.24|basically you have the batch Dimension
2421.359|3.181|the head Dimension and the time
2423.04|4.62|Dimension and then you have features at
2424.54|4.559|them and so uh this is evaluating for
2427.66|3.6|all the batch elements for all the head
2429.099|4.02|elements and all the time elements
2431.26|4.74|the simple python that I gave you
2433.119|5.701|earlier which is query.proc T
2436.0|4.68|then here we do a mask still and what
2438.82|3.9|this is doing is it's basically clamping
2440.68|3.899|the um
2442.72|3.359|the attention between the nodes that are
2444.579|3.361|not supposed to communicate to be
2446.079|3.241|negative infinity and we're doing
2447.94|3.54|negative Infinity because we're about to
2449.32|3.66|soft Max and so negative Infinity will
2451.48|3.119|make basically the attention that those
2452.98|3.42|elements be zero
2454.599|5.161|and so here we are going to basically
2456.4|5.34|end up with uh the weights
2459.76|3.06|um the the sort of affinities between
2461.74|3.48|these nodes
2462.82|5.7|optional Dropout and then here attention
2465.22|4.859|Matrix multiply V is basically the um
2468.52|3.18|the Gathering of the information
2470.079|3.061|according to the affinities we've
2471.7|4.08|calculated and this is just a weighted
2473.14|4.74|sum of the values at all those nodes so
2475.78|3.18|this Matrix multiplies as doing that we
2477.88|3.42|could sum
2478.96|4.139|and then transpose contiguous view
2481.3|3.299|because it's all complicated and bashed
2483.099|3.121|in five dimensional testers but it's
2484.599|4.141|really not doing anything optional
2486.22|4.44|Dropout and then a linear projection
2488.74|3.54|back to the residual pathway
2490.66|3.9|so this is implementing the
2492.28|4.5|communication phase here
2494.56|3.18|then you can train this Transformer
2496.78|3.72|um
2497.74|4.74|and then you can generate uh infinite
2500.5|4.68|Shakespeare and you will simply do this
2502.48|4.98|by because our block size is eight we
2505.18|4.679|start with a sum token
2507.46|4.139|um say like I use in this case
2509.859|4.801|um you can use something like a new line
2511.599|4.26|As the start token and then um you
2514.66|2.76|communicate only to yourself because
2515.859|3.72|there's a single node and you get the
2517.42|4.32|prompted distribution for the first word
2519.579|4.141|in the sequence and then
2521.74|3.3|um you decode it or the first character
2523.72|3.18|in the sequence you decode the character
2525.04|3.78|and then you bring back the character
2526.9|4.98|and you re-encode it as an integer and
2528.82|4.92|now you have the second thing and so you
2531.88|5.04|you get okay we're in the first position
2533.74|4.74|and this is whatever integer it is add
2536.92|3.6|the positional encodings goes into the
2538.48|4.68|sequence that goes into Transformer and
2540.52|4.319|again this token now communicates with
2543.16|4.26|the first token
2544.839|4.74|um and its identity and so you just keep
2547.42|3.96|plugging the doc and once you run out of
2549.579|3.841|the block size which is eight you start
2551.38|3.42|to crop because you can never have block
2553.42|3.179|size more than eight in the way you've
2554.8|3.42|trained this Transformer so we have more
2556.599|2.76|and more context until eight and then if
2558.22|2.399|you want to generate Beyond date you
2559.359|2.881|have to start cropping because the
2560.619|3.96|Transformer only works for eight
2562.24|4.68|elements in time Dimension and so all of
2564.579|5.641|these Transformers in the naive setting
2566.92|5.58|have a finite block size or context line
2570.22|5.58|and uh in typical models this will be
2572.5|5.04|1020 Pro tokens or 2048 tokens something
2575.8|3.84|like that but these tokens are usually
2577.54|3.48|like epe tokens or sentence piece tokens
2579.64|3.6|or workpiece tokens there's many
2581.02|4.079|different encodings so it's not like
2583.24|3.119|that long and so that's why I think did
2585.099|3.121|mentioned we really want to expand the
2586.359|5.161|context size and gets gnarly because the
2588.22|5.58|attention is quadratic in any case
2591.52|4.68|now if you want to
2593.8|5.819|um Implement an encoder instead of a
2596.2|5.1|decoder attention then all you have to
2599.619|3.72|do is this master
2601.3|4.38|you just delete that line
2603.339|3.661|so if you don't mask the attention then
2605.68|3.3|all the nodes communicate to each other
2607.0|4.44|and everything is allowed and
2608.98|5.04|information flows between all the nodes
2611.44|5.639|so if you want to have the encoder here
2614.02|5.04|uh just delete all the encoder blocks
2617.079|3.661|will use attention where this line is
2619.06|4.5|deleted that's it
2620.74|4.92|so you're allowing um whatever this
2623.56|3.72|encoder in my store say 10 tokens like
2625.66|3.6|10 nodes and they are allowed to
2627.28|3.78|communicate to each other going up the
2629.26|3.42|Transformer
2631.06|3.6|and then if you want to implement cross
2632.68|4.02|attention so you have a full encoder
2634.66|4.5|decoder Transformer not just a decoder
2636.7|5.7|only Transformer or GPT
2639.16|5.4|then we need to also add uh cross
2642.4|4.08|attention in the middle so here there's
2644.56|3.6|a self-attention piece where all the
2646.48|3.9|there's a cell potential piece across
2648.16|4.5|the tension piece and this LLP and in
2650.38|4.439|the cross attention uh we need to take
2652.66|5.28|the features from the top of the encoder
2654.819|5.28|we need to add one more line here and uh
2657.94|3.6|this would be the cross attention uh
2660.099|3.961|instead of I should have implemented it
2661.54|3.9|instead of just pointing I think but um
2664.06|2.759|there will be a cross attention line
2665.44|3.659|here so we'll have three lines because
2666.819|4.741|we need to add another block and the
2669.099|4.561|queries will come from X but the keys
2671.56|3.6|and the values will come from the top of
2673.66|2.939|the encoder
2675.16|4.14|and there will be basically information
2676.599|4.74|flowing from the encoder strictly to all
2679.3|4.38|the nodes inside X
2681.339|4.381|and then that's it so it's a very simple
2683.68|3.419|sort of modifications on the decoder
2685.72|3.54|attention
2687.099|3.901|so you'll you'll hear people talk that
2689.26|3.72|you kind of have a ticket or only model
2691.0|3.72|like GPT you can have an encoder only
2692.98|3.839|model like Bert or you can have an
2694.72|4.68|encoder decoder model like say T5 doing
2696.819|5.581|things like machine translation so um
2699.4|4.439|and in Bert uh you can't train it using
2702.4|3.0|sort of this um
2703.839|2.701|language modeling setup that's Auto
2705.4|2.4|aggressive and you're just trying to
2706.54|2.46|predict the next element in the sequence
2707.8|3.6|your training into a slightly different
2709.0|3.9|objectives you're putting in like the
2711.4|3.959|full sentence and the full sentence is
2712.9|4.08|allowed to communicate fully and then
2715.359|3.421|you're trying to classify sentiment or
2716.98|3.66|something like that so you're not trying
2718.78|3.299|to model like the next token in the
2720.64|3.679|sequence uh so these are trained
2722.079|7.141|slightly different with masked
2724.319|7.361|uh with uh using masking and uh other
2729.22|4.68|denoising tables
2731.68|5.04|okay so that's kind of like the
2733.9|5.6|transformer I'm going to continue so
2736.72|2.78|yeah maybe more questions
2761.619|3.0|foreign
2772.42|3.96|so I'm not sure if I fully follow so
2774.579|3.481|there's different ways to look at this
2776.38|3.54|analogy but one analogy is you can
2778.06|3.36|interpret this graph as really fixed
2779.92|3.48|it's just that every time we do the
2781.42|3.179|communicate we are using different ways
2783.4|2.939|you can look at it
2784.599|3.121|so if we have block size of eight in my
2786.339|4.02|example we would have eight notes Here
2787.72|4.56|we have two four six okay so we'd have
2790.359|4.381|eight notes they would be connected in
2792.28|6.12|in you lay them out and you only connect
2794.74|3.66|from left to right now
2801.76|2.52|um
2802.42|3.84|uh why would the connect usually the
2804.28|5.1|connections don't change as a function
2806.26|6.12|of the data or something like this
2809.38|3.0|route
2815.92|3.0|any
2820.18|3.419|I don't think I've seen a single example
2821.98|3.06|where the connectivity changes Dynamic
2823.599|2.881|and option of data usually the
2825.04|3.0|connectivity is fixed if you have an
2826.48|3.54|encoder and you're training a birch you
2828.04|3.48|have how many tokens you want and they
2830.02|4.38|are fully connected
2831.52|4.44|and if you have uh you have this
2834.4|3.36|triangular thing and if you have encoder
2835.96|7.76|decoder then you have awkwardly sort of
2837.76|5.96|like two tools of nodes and yeah
2850.92|3.0|thank you
2858.22|4.04|my question
2860.2|2.06|um
2874.54|4.94|rich
2876.64|2.84|the report
2880.06|2.6|okay
2892.26|4.12|yeah it's really hard to say so that's
2895.0|3.3|why I think this paper is so interesting
2896.38|3.3|is like yeah usually you'd see like a
2898.3|3.299|path and maybe they had path internally
2899.68|3.24|they just didn't publish it and all you
2901.599|2.76|can see is sort of things that didn't
2902.92|4.199|look like a Transformer I mean you had
2904.359|4.321|resnets which had lots of this but a
2907.119|3.421|resnet would be kind of like this but
2908.68|4.2|there's no um there's no self-attention
2910.54|4.14|component but the MLP is there kind of
2912.88|2.64|in a resnet
2914.68|3.0|um
2915.52|4.319|so a resnet looks very much like this
2917.68|3.419|except there's no uh you can use layer
2919.839|2.76|Norms in resonance I believe as well
2921.099|4.381|typically sometimes they can be bash
2922.599|4.26|norms so it is kind of like a resnet it
2925.48|4.98|is kind of what they took a resnet and
2926.859|5.22|they put in a Cell potential one in
2930.46|3.6|addition to the pre-existing MLP block
2932.079|3.361|which is kind of like convolutions and
2934.06|3.779|MLP was strictly speaking the
2935.44|4.62|convolution one by one combination
2937.839|4.441|um but I think the idea is similar in
2940.06|5.16|that MLP is just kind of like a you know
2942.28|5.72|typical weights uh nonlinearity weights
2945.22|2.78|or operation
2950.2|4.02|um and but I will say like yeah it's
2952.66|4.08|kind of interesting because
2954.22|3.72|a lot of work is is not uh is not there
2956.74|2.339|and then they give you this Transformer
2957.94|2.46|and then it turns out five years later
2959.079|2.641|it's not changed even though everyone's
2960.4|2.459|trying to change it so it's kind of
2961.72|3.599|interesting to me that it's kind of like
2962.859|3.541|a package in like a package uh which I
2965.319|4.561|think is really interesting historically
2966.4|6.0|and um I also talked to a paper authors
2969.88|4.32|and they were unaware of the impact that
2972.4|4.38|the transform was half at the time so
2974.2|4.02|when you read this uh paper actually uh
2976.78|2.94|it's it's kind of unfortunate because
2978.22|2.82|this is like the paper that changed
2979.72|3.42|everything but when people read it it's
2981.04|4.079|like question marks because the reason
2983.14|3.959|like a pretty random machine translation
2985.119|3.121|paper like oh we're doing machine
2987.099|2.76|translation oh here's a cool
2988.24|4.859|architecture okay great good results
2989.859|4.581|like it's it doesn't sort of know what's
2993.099|3.541|going to happen
2994.44|4.0|and so when people read it today I think
2996.64|4.62|they're kind of confused uh potentially
2998.44|4.679|like having like having I will have some
3001.26|3.059|tweets at the end but I think I would
3003.119|5.121|have renamed it with the benefit of
3004.319|3.921|hindsight of like well I'll get to it
3015.84|3.049|[Music]
3020.88|3.959|yeah I think that's a good question as
3022.2|4.56|well uh currently I mean I certainly
3024.839|3.601|don't love the auto aggressive modeling
3026.76|3.3|approach I think it's kind of weird to
3028.44|4.26|like sample a token and then commit to
3030.06|4.86|it uh so
3032.7|4.26|you know maybe there's some ways to um
3034.92|3.72|uh maybe there's some ways some hybrids
3036.96|3.0|with diffusion as an example which I
3038.64|2.34|think would be really cool
3039.96|2.76|um
3040.98|3.599|or we'll find some other ways to like
3042.72|3.96|edit the sequences later but still in
3044.579|3.841|the auto regressive framework
3046.68|3.179|um but I think the fusion is kind of
3048.42|2.58|like an up-and-coming modeling approach
3049.859|3.661|that I personally find much more
3051.0|5.04|appealing when I sample text I don't go
3053.52|3.96|chunk chunk chunk and commit I uh I do a
3056.04|2.22|draft one and then I do a better draft
3057.48|3.3|two
3058.26|6.319|and that feels like a diffusion process
3060.78|3.799|so that would be my oh
3093.02|4.24|Works kind of like a confusing term
3095.04|3.84|because um
3097.26|3.12|I mean yeah previously there was this
3098.88|3.0|notion of
3100.38|2.58|uh I kind of thought maybe today
3101.88|2.58|everything is a graphical Network
3102.96|3.3|because the Transformer is a graphical
3104.46|3.06|Network processor the native
3106.26|3.18|representation that the Transformer
3107.52|4.44|operates over is sets that are connected
3109.44|4.139|by edges uh in a directed way and so
3111.96|3.54|that's the native representation and
3113.579|3.421|then um yeah
3115.5|4.22|okay I should go on because I still have
3117.0|2.72|like 30 slots
3127.52|4.299|oh yeah
3129.66|3.899|yeah the Rooty I think basically like as
3131.819|3.3|your as your if you're initializing with
3133.559|3.601|random uh weights separate from a
3135.119|4.621|golfing as your dimensional size grows
3137.16|4.26|so does your values the variance grows
3139.74|3.66|and then your soft Max will just become
3141.42|3.659|uh the one half Vector
3143.4|3.719|um so it's just a way to control the
3145.079|3.421|variance and bring it to always be in a
3147.119|4.161|good range with soft Max and nice
3148.5|2.78|distribution
3151.44|2.54|okay
3154.2|3.54|so it's almost like an initialization
3155.7|3.78|thing
3157.74|3.839|okay
3159.48|4.079|uh so Transformers have been applied to
3161.579|4.081|all the other all the other fields and
3163.559|3.961|the way this was done is in in my
3165.66|3.3|opinion kind of ridiculous ways honestly
3167.52|3.66|because I was a computer different
3168.96|3.48|person and uh you have comments and it
3171.18|3.24|kind of makes sense so what we're doing
3172.44|3.419|now with bits as an example is you take
3174.42|3.78|an image and you chop it up into little
3175.859|4.5|squares and then those squares literally
3178.2|5.22|feed into a Transformer and that's it
3180.359|4.441|which is kind of ridiculous and so
3183.42|3.78|I mean
3184.8|3.84|yeah and so the Transformer doesn't even
3187.2|3.48|in the simplest case like really know
3188.64|3.84|where these patches might come from they
3190.68|4.8|are usually positionally encoded
3192.48|4.92|um but it has to sort of like ReDiscover
3195.48|3.48|a lot of the structure I think of them
3197.4|3.12|in some ways
3198.96|2.879|um and it's kind of weird to approach it
3200.52|2.46|that way
3201.839|2.941|um
3202.98|3.3|but uh it's just like this this simple
3204.78|2.94|Baseline the simplest Baseline of just
3206.28|3.0|chomping up big images into small
3207.72|3.06|squares and feeding them in as like the
3209.28|3.12|individual notes actually works fairly
3210.78|3.48|well and then this is in the Transformer
3212.4|3.179|encoder so all the patches are talking
3214.26|2.46|to each other throughout the entire
3215.579|2.76|Transformer
3216.72|5.06|and the number of nodes here would be
3218.339|3.441|sort of like uh nine
3221.88|3.9|uh also in speech recognition you just
3224.22|3.119|take your Mel spectrogram and you chop
3225.78|3.0|it up into little slices and feed them
3227.339|3.421|into a Transformer so there was paper
3228.78|3.48|like this but also whisper whisper is a
3230.76|4.319|copy based Transformer if you saw
3232.26|4.2|whisper uh from open AI you just chop up
3235.079|2.941|null spectrogram and feed into a
3236.46|3.56|Transformer and then pretend you're
3238.02|4.799|dealing with text and it works very well
3240.02|4.599|uh decision transform on RL you take
3242.819|3.361|your States actions and rework that you
3244.619|3.841|experience an environment and you just
3246.18|4.08|pretend it's a language and you start to
3248.46|3.48|model the sequences of that and then you
3250.26|3.24|can use that for planning later that
3251.94|3.48|works pretty well uh you know even
3253.5|3.24|things like Alpha gold so we were
3255.42|2.939|frequently talking about molecules and
3256.74|3.54|how you can plot them in so at the heart
3258.359|3.541|of alcohol computationally is also a
3260.28|3.299|Transformer
3261.9|3.179|one thing I wanted to also say about
3263.579|3.181|Transformers is I find that they're very
3265.079|2.941|uh they're super flexible and I really
3266.76|3.599|enjoy that
3268.02|4.62|um I'll give you an example from Tesla
3270.359|3.421|um like you have a comment that takes an
3272.64|3.179|image and makes predictions about the
3273.78|3.72|image and then the big question is how
3275.819|3.421|do you feed in extra information and
3277.5|3.24|it's not always trivial like say I have
3279.24|3.839|additional information that I want to
3280.74|4.079|inform uh that I want the outputs to be
3283.079|3.301|informed by maybe I have other sensors
3284.819|3.361|like radar maybe I have some map
3286.38|3.42|information or a vehicle type or some
3288.18|3.179|audio and the question is how do you
3289.8|2.94|feed information into a comment like
3291.359|3.661|where do you feed it in do you
3292.74|4.92|concatenate it like how do you do you
3295.02|3.9|add it at what stage and so with the
3297.66|2.76|Transformer it's much easier because you
3298.92|3.54|just take whatever you want you chop it
3300.42|3.6|up into pieces and eat it in with a set
3302.46|2.639|of what you had before and you let the
3304.02|2.579|self-attention figure out how everything
3305.099|4.321|should communicate and that actually
3306.599|3.901|apparently works so I just chop up
3309.42|3.84|everything and throw it into the mix
3310.5|4.92|it's kind of like the way and it frees
3313.26|4.14|neural that's from from this uh from
3315.42|4.32|this burden of euclidean space where
3317.4|4.32|previously you had to um you had to
3319.74|3.48|arrange your computation to conform to
3321.72|3.72|the euclidean space of three dimensions
3323.22|3.599|of how you're laying out the compute
3325.44|3.36|like the compute actually kind of
3326.819|3.841|happens in almost like 3D space if you
3328.8|3.84|think about it um but in attention
3330.66|3.36|everything is just sets uh so it's a
3332.64|2.58|it's a very flexible framework and you
3334.02|2.579|can just like throw in stuff into your
3335.22|3.66|conditioning set and everything just
3336.599|4.801|self-attended over so it's quite
3338.88|4.739|beautiful I respect it okay so now what
3341.4|3.659|exactly makes Transformers so effective
3343.619|3.361|I think a good example of this comes
3345.059|4.26|from the gbt3 paper which I encourage
3346.98|4.26|people uh to read uh language models are
3349.319|3.601|two shot Learners I would have probably
3351.24|3.66|renamed this a little bit I would have
3352.92|4.199|said something like Transformers are
3354.9|4.14|capable of in context learning or like
3357.119|3.96|meta learning that's kind of like what
3359.04|3.18|makes them really special so basically
3361.079|2.941|the the setting that they're working
3362.22|3.359|with is okay I have some context and I'm
3364.02|3.48|trying to like say passage this is just
3365.579|4.561|one example of many I have a passage and
3367.5|4.74|I'm asking questions about it and then
3370.14|3.78|um I'm giving uh as part of the context
3372.24|3.24|in the prompt I'm giving the questions
3373.92|2.76|and the answers so I'm giving one
3375.48|2.82|example a question answer another
3376.68|3.72|example question answer another example
3378.3|3.36|question answer and so on and this
3380.4|4.14|becomes a
3381.66|6.56|oh yeah people are gonna have to leave
3384.54|3.68|okay it's really important for me
3390.24|2.819|okay so what's really interesting is
3391.44|3.48|basically like
3393.059|4.741|uh with more examples given in the
3394.92|4.08|context the accuracy improves and so
3397.8|3.6|what that can say is that the
3399.0|3.96|Transformer is able to somehow learn in
3401.4|2.76|the activations without doing any
3402.96|3.48|gradient descent in a typical
3404.16|4.439|functioning fashion so if you fine-tune
3406.44|4.26|you have to give an example and the
3408.599|3.72|answer and you you fine-tune it using
3410.7|3.419|gradient descent but it looks like the
3412.319|2.701|transformer internally in its weights is
3414.119|2.341|doing something that looks like
3415.02|2.64|potential ingredients some kind of a
3416.46|2.639|metal learning in the weights of the
3417.66|3.959|Transformer as it is reading the prompt
3419.099|4.5|and so in this paper they go into okay
3421.619|3.781|distinguishing this outer loop with
3423.599|3.781|stochastic Readiness and this inner loop
3425.4|3.48|of the in context learning so the inner
3427.38|3.12|loop is as the Transformer is sort of
3428.88|3.719|like reading the sequence almost and the
3430.5|3.48|outer loop is the uh is the training by
3432.599|3.0|gradient descent
3433.98|3.42|um so basically there's some training
3435.599|3.661|happening in the activation Transformer
3437.4|3.36|as it is consuming a sequence that maybe
3439.26|3.12|very much looks like gradient descent
3440.76|3.66|and so there's some recent papers that
3442.38|4.56|kind of hint at this and study it and so
3444.42|3.78|as an example in this paper here they
3446.94|4.26|propose something called The Raw
3448.2|4.8|operator and um they argue that the raw
3451.2|3.06|operator is implemented by Transformer
3453.0|2.7|and then they show that you can
3454.26|3.42|Implement things like Ridge regression
3455.7|3.0|on top of a raw operator and so this is
3457.68|2.939|kind of giving
3458.7|3.419|um there are papers hinting that maybe
3460.619|2.881|there is some thing that looks like
3462.119|3.121|gradient-based learning inside the
3463.5|3.96|activations of the Transformer
3465.24|3.66|and uh I think this is not impossible to
3467.46|2.94|think through because what is what is
3468.9|3.84|gradient-based learning forward pass
3470.4|3.719|backward pass and an update well that
3472.74|2.64|looks like a resonant
3474.119|3.841|right because you're just changing
3475.38|4.5|you're adding to the weights uh so you
3477.96|3.72|start initial random set of Weights
3479.88|3.179|forward pass backward pass and update
3481.68|2.939|your weights and then forward pass
3483.059|4.081|backward positive ways looks like a
3484.619|3.48|reset Transformer is a resnet
3487.14|4.38|oh
3488.099|4.561|so uh much more handwavy but basically
3491.52|3.839|some people are trying to find out why
3492.66|3.84|that could be potentially possible and
3495.359|3.48|then I have a bunch of tweets I just
3496.5|3.66|copy pasted here in the end um I was
3498.839|2.701|this was kind of like meant for General
3500.16|4.14|consumption so they're a bit more high
3501.54|4.2|level and high p a little bit but um I'm
3504.3|3.0|talking about why this architecture is
3505.74|3.3|so interesting and why why potentially
3507.3|3.059|became so popular and I think it's
3509.04|2.22|simultaneously optimizes three
3510.359|2.881|properties that I think are very
3511.26|4.079|desirable number one the Transformer is
3513.24|3.96|very expressive in the forward pass it's
3515.339|3.181|um it's sort of like is able to
3517.2|3.24|implement very interesting functions
3518.52|4.68|potentially functions that can even like
3520.44|4.02|do metal learning number two it is very
3523.2|2.94|optimizable thanks to things like
3524.46|3.06|residual connections layer nodes and so
3526.14|3.0|on and number three it's extremely
3527.52|3.299|efficient this is not always appreciated
3529.14|4.08|but the Transformer if you look at the
3530.819|4.081|computational graph is a shallow wide
3533.22|3.359|Network which is perfect to take
3534.9|2.88|advantage of the parallelism of gpus so
3536.579|3.181|I think the Transformer was designed
3537.78|3.96|very deliberately to run efficiently on
3539.76|5.099|gpus uh there's previous work like
3541.74|5.04|neural GPU that I really enjoy as well
3544.859|3.181|which is really just like how do we how
3546.78|2.88|do we design your own ads that are
3548.04|2.64|efficient on gpus and thinking backwards
3549.66|2.28|from the constraints of the hardware
3550.68|3.86|which I think is a very interesting way
3551.94|2.6|to think about it
3555.119|2.061|um
3558.059|3.361|oh yeah so here I'm saying I probably
3559.74|3.0|would have called
3561.42|3.54|um I probably would have called the
3562.74|4.619|Transformer a general purpose efficient
3564.96|3.839|optimizable computer instead of
3567.359|2.821|attention is all you need like that's
3568.799|4.861|what I would have maybe in hindsight
3570.18|5.1|called uh that paper is proposing a is a
3573.66|2.34|model that is
3575.28|2.7|um
3576.0|4.2|very general purpose so forward pass is
3577.98|4.619|expressive it's very efficient uh in
3580.2|5.22|terms of GPU usage it's easily
3582.599|4.081|optimizable by gradient and trains very
3585.42|4.139|nicely
3586.68|4.619|then I have some other hot tweets here
3589.559|4.381|um
3591.299|3.901|anyway so I yeah you can read them later
3593.94|3.54|but I think this one's maybe interesting
3595.2|4.32|so uh if previously neural Nets are
3597.48|4.26|special purpose computers designed for a
3599.52|4.5|specific tasks GPT is a general purpose
3601.74|4.8|computer reconfigurable at runtime to
3604.02|3.96|run natural language programs uh so the
3606.54|2.34|program the programs are given as
3607.98|2.7|prompts
3608.88|3.36|and then GPT runs the program by
3610.68|3.179|completing the document
3612.24|4.5|so I really I really like these
3613.859|5.161|analogies uh personally uh to computer
3616.74|4.379|it's just like a powerful computer and
3619.02|2.66|it's optimizable by doing The Descent
3621.119|3.861|um
3621.68|3.3|and uh
3630.059|5.161|I don't know okay that's it
3633.059|3.3|I think you can read this later but uh
3635.22|3.74|that's right I'll just thank you I'll
3636.359|2.601|just leave this up
3645.54|3.6|so sorry I just found this tweet so it
3648.0|2.52|turns out that if you scale up the
3649.14|3.06|training set and use a powerful enough
3650.52|2.76|neural lab like a Transformer the
3652.2|2.879|network becomes a kind of general
3653.28|3.059|purpose computer over text so I think
3655.079|3.0|that's kind of like nice way to look at
3656.339|3.061|it and instead of performing a single
3658.079|3.24|thick sequence you can design the
3659.4|3.899|sequence in the prompt and because the
3661.319|3.78|Transformer is both powerful but also is
3663.299|3.121|trained on large enough very hard data
3665.099|3.061|set it kind of becomes this general
3666.42|4.28|purpose text computer and so I think
3668.16|2.54|that's kind of interesting
3671.099|3.861|yeah
3672.96|2.0|um
3679.14|2.84|foreign
3714.74|5.22|but now we
3716.7|3.26|should be kind of writing years
3723.96|4.7|how much do you think
3726.599|4.441|there's three really like posts today
3728.66|5.78|you know it really is because it's
3731.04|6.51|mostly more efficient for Humanity
3734.44|3.11|[Music]
3746.099|3.781|so I think there's a bit of that yeah so
3747.839|4.081|I would say rnn's like in principle yes
3749.88|3.06|they can Implement arbitrary uh programs
3751.92|2.699|I think it's kind of like a useless
3752.94|3.72|statement to some extent because they
3754.619|3.661|are not they're probably I'm not sure
3756.66|3.48|that they're they're probably expressive
3758.28|3.36|because in a sense of like power in that
3760.14|2.82|they can Implement these arbitrary
3761.64|3.12|functions
3762.96|3.06|but they're not optimizable
3764.76|2.819|and they're certainly not efficient
3766.02|3.0|because they are serial Computing
3767.579|3.72|devices
3769.02|5.819|um so I think so if you look at it as a
3771.299|4.8|compute graph rnns are very long
3774.839|3.121|thin
3776.099|3.96|compute graph
3777.96|3.48|um like if you stretched out the neurons
3780.059|2.701|and you look like take all the
3781.44|2.7|individual neurons interconnectivity and
3782.76|3.299|stretch them out and try to visualize
3784.14|4.14|them rnns would be like a very long
3786.059|4.26|graph in a bad and it's bad also for
3788.28|4.2|optimizability because I don't exactly
3790.319|3.78|know why but just the rock intuition is
3792.48|3.839|when you're back propagating you don't
3794.099|4.621|want to make too many steps and so
3796.319|6.121|Transformers are shallow wide graph and
3798.72|6.24|so from from supervision to inputs is a
3802.44|3.84|very small number of hops and it's a
3804.96|2.879|long residual Pathways which make
3806.28|3.62|gradients flow very easily and there's
3807.839|4.381|all these layer Norms to control the the
3809.9|5.439|scales of all all of those activations
3812.22|4.8|and so uh there's not too many Hops and
3815.339|3.301|you're going from supervision to input
3817.02|3.599|very quickly and just flows through the
3818.64|3.659|graph so
3820.619|3.48|um and it's it can all be done in
3822.299|3.481|parallel so you don't need to do this uh
3824.099|3.301|encoder decoder RNs you have to go from
3825.78|3.66|first then second word then third word
3827.4|4.32|but here in in Transformer every single
3829.44|3.899|word was processed completely sort of in
3831.72|3.899|parallel
3833.339|4.02|which is kind of a so I think all these
3835.619|3.061|are really important because all these
3837.359|3.48|are really important and I think number
3838.68|4.379|three is less talked about but extremely
3840.839|3.96|important because in deep learning scale
3843.059|4.321|matters and so the size of the network
3844.799|4.56|that you can train it gives you uh is
3847.38|3.36|extremely important and so if it's
3849.359|3.421|efficient on the current Hardware then
3850.74|4.44|we can make it bigger
3852.78|5.4|foreign
3855.18|3.0|no
3859.3|3.049|[Music]
3870.0|3.24|um so yeah so you take your images and
3871.68|3.72|you apparently chop them up into patches
3873.24|4.26|so there's the first uh thousand tokens
3875.4|5.58|or whatever and now I have a special so
3877.5|4.559|radar could be um also but I don't
3880.98|4.26|actually want to make a representation
3882.059|4.681|of radar so uh but you could uh you just
3885.24|2.819|need to chop it up and enter it and then
3886.74|2.28|you have to encode it somehow like the
3888.059|2.52|transformer needs to know that they're
3889.02|2.7|coming from radar so you create a
3890.579|3.24|special
3891.72|4.44|you have some kind of a special token
3893.819|4.441|that you um
3896.16|3.3|are these radar tokens in the
3898.26|3.72|representation and it's learnable by
3899.46|4.32|gradient and um
3901.98|4.02|but vehicle information would also come
3903.78|3.42|in with a special embedding token that
3906.0|4.64|can be learned
3907.2|3.44|um so um
3911.0|6.54|because you don't it's all just a set
3913.68|3.86|and there's another voice
3918.68|4.179|yeah it's all just a set but you can't
3921.0|5.04|positionally encode these sets uh if you
3922.859|4.98|want so um but positional encoding means
3926.04|3.18|you can hardwire for example the the
3927.839|3.061|coordinates like using sinusos and
3929.22|3.78|cosines you can even have wire that but
3930.9|3.719|it's better if you don't have wire the
3933.0|2.64|position you just it's just a vector
3934.619|2.761|that is always hanging out the
3935.64|3.179|dislocation whatever content is there
3937.38|2.58|just adds on it and this vectors
3938.819|3.201|trainable by background that's how you
3939.96|2.06|do
3944.64|2.0|it
3948.299|5.481|but they seem to work but it seems like
3951.18|2.6|they're sometimes
3957.26|6.52|whatever else
3959.66|6.3|I might do something better
3963.78|2.18|um
3969.54|3.42|a question
3970.7|3.76|so I mean the positional encoder is like
3972.96|3.119|they're they're actually like not uh
3974.46|3.18|they have okay so they have very little
3976.079|2.52|inductive bias or something like that
3977.64|2.699|they're just vectors hanging out in
3978.599|4.381|location always and you're trying to
3980.339|3.421|you're trying to help the network
3982.98|2.28|um
3983.76|4.44|and
3985.26|3.539|I think the intuition is is good but
3988.2|2.399|um
3988.799|3.181|like if you have enough data usually
3990.599|3.601|trying to mess with it is like a bad
3991.98|3.599|thing uh by trying to well trying to
3994.2|3.18|enter knowledge when you have enough
3995.579|3.54|knowledge in the data set itself is not
3997.38|3.179|usually productive uh so we talked
3999.119|2.821|really depends on what scale you are if
4000.559|2.881|you have Infinity data then you actually
4001.94|3.06|want to encode less and less that turns
4003.44|3.119|out to work better and if you have very
4005.0|3.539|little data then actually you do want to
4006.559|2.941|encode some biases and maybe if you have
4008.539|2.701|a much smaller data set then maybe
4009.5|3.42|convolutions are a good idea because you
4011.24|3.78|actually have this bias coming from all
4012.92|4.74|filters and so
4015.02|4.26|but I think um
4017.66|3.3|so the Transformer is extremely General
4019.28|3.12|but there are ways to mess with the
4020.96|2.76|encodings to put in more structure like
4022.4|3.659|you could for example in code sinuses
4023.72|3.599|and cosines and fix it or you could
4026.059|4.381|actually go to the attention mechanism
4027.319|4.74|and say okay my if my image is chopped
4030.44|3.06|up into patches this patch can only
4032.059|2.821|communicate to this neighborhood and you
4033.5|3.9|can you just do that in the attention
4034.88|4.26|Matrix just mask out whatever you don't
4037.4|3.719|want to communicate and so people really
4039.14|4.32|play with this because the the full
4041.119|4.861|attention is uh inefficient so they will
4043.46|4.02|intersperse for example layers that only
4045.98|3.18|communicate in all patches and then
4047.48|3.3|layers the community globally and they
4049.16|4.02|will sort of do all kinds of tricks like
4050.78|4.62|that so you can slowly bring in more
4053.18|3.48|inductive bias you would do it but the
4055.4|3.06|inductive biases are sort of like
4056.66|3.659|they're factored out from the core
4058.46|4.44|Transformer and they are factored out in
4060.319|3.661|the uh in the connectivity of the nodes
4062.9|2.76|and they are factored out in the
4063.98|3.24|positional employees and we can mess
4065.66|4.52|with this
4067.22|2.96|for proposition
4072.02|2.0|s
4082.579|4.861|so there's probably about 200 papers on
4084.619|4.2|this now uh if not more they're kind of
4087.44|3.54|hard to keep track of honestly like my
4088.819|4.861|Safari browser which is oh it's on my
4090.98|5.78|computer it's like 200 open tabs um
4093.68|3.08|but um
4099.02|3.92|yes I'm not even sure if I'm if I want
4100.94|5.0|to like pick my favorite honestly
4102.94|3.0|yeah
4106.42|5.439|and even people for Transformer attack
4109.16|5.0|season I think it was was a big supplies
4111.859|2.301|instructions
4125.14|3.219|the other one that I actually like even
4127.04|3.719|more is potentially keep the context
4128.359|5.34|length fixed but allow the network to
4130.759|4.741|somehow use a scratch Pad okay and so
4133.699|3.721|the way this works is you will teach the
4135.5|3.359|Transformer somehow via examples in the
4137.42|3.54|prompt but hey you actually have a
4138.859|3.301|scratch Pad hey hey trust you basically
4140.96|2.819|you can't remember too much your
4142.16|3.659|contact's not inspired but you can use a
4143.779|4.141|scratch pad and you do that by emitting
4145.819|3.181|a start scratch pad and then writing
4147.92|3.839|whatever you want to remember and then
4149.0|4.62|end scratch pad and then uh you continue
4151.759|3.48|with whatever you want and then later
4153.62|3.36|when it's decoding you actually like
4155.239|3.781|have special logic that when you detect
4156.98|3.96|start scratch Pad you will sort of like
4159.02|3.36|save whatever it puts in there in like
4160.94|3.48|external thing and allow it to attend
4162.38|3.359|over it so basically you can teach the
4164.42|3.839|Transformer just dynamically because
4165.739|4.08|it's so um meta-learned you can teach it
4168.259|3.06|dynamically to use other gizmos and
4169.819|3.181|gadgets and allow it to expand its
4171.319|3.241|memory that way if that makes sense it's
4173.0|3.779|just like human learning to use a
4174.56|3.48|notepad right you don't have to keep it
4176.779|2.341|in your brain so keeping things in your
4178.04|3.0|brain is kind of like the context might
4179.12|3.78|be the Transformer but maybe we can just
4181.04|4.5|give it a notebook and then it can query
4182.9|4.52|the notebook and read from it and write
4185.54|6.78|to it
4187.42|4.9|[Laughter]
4199.699|3.0|foreign
4220.3|4.419|extensively but I did see a forgetting
4223.1|4.639|event and I kind of felt like the block
4224.719|3.02|size was just moved
4231.64|3.94|questions
4233.179|5.241|so one one question is what do you think
4235.58|2.84|about architecture
4238.64|6.24|a sport
4240.86|5.879|actually okay which one is this one
4244.88|2.88|uh the second question it was a personal
4246.739|4.341|question
4247.76|3.32|um what are you going to work on next
4251.659|4.861|I mean so right now I'm working on
4252.86|6.299|things like Nano GPT whereas Nano GPT
4256.52|4.38|uh
4259.159|3.601|I mean I'm going basically slightly from
4260.9|3.299|computer vision and like part uh kind of
4262.76|5.0|like the immersion-based products to a
4264.199|3.561|little bit in language domain uh
4267.8|3.96|so originally I had Min GPT whichever
4269.48|4.739|wrote to Nano GPT and I'm working on
4271.76|4.2|this I'm trying to reproduce gpts and I
4274.219|3.601|mean I think something like Chachi PT I
4275.96|3.3|think um incrementally improved in the
4277.82|4.08|product fashion would be extremely
4279.26|4.08|interesting and uh
4281.9|3.6|I think a lot of people feel it and
4283.34|4.62|that's why it went so wide so I think
4285.5|4.32|there's uh something like a Google plus
4287.96|4.08|plus to build that I think is really
4289.82|5.6|interesting
4292.04|3.38|can we give our speed run