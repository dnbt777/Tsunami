start_time|end_time|text
1.0|3.36| Yeah, so in this last video for today, I want to go over the
4.36|4.04| pytorch API in particular, discussing the subtle difference
8.4|3.52| between the object oriented and functional API's, because it
11.92|6.26| will become useful in the future lessons. So here's an overview
18.18|4.02| of a multi layer perceptron. So we haven't really talked about
22.2|3.78| in detail how it works. I only showed you some graphs of how it
25.98|3.26| looks like. So here for this purpose, it's really just
29.24|3.32| sufficient to think of it as a multi layer neural network.
33.32|3.96| Because we have the same concept really applies for all types of
37.28|3.3| networks, when we work with pytorch, or almost all types of
40.58|3.94| networks. So that's like this general template that you can
44.56|5.64| think of, where we have, or where we use usually a class to
50.28|4.36| define the model. And then for this class, we inherit from this
54.64|4.28| torch dot n n dot module. So this gives us some certain
58.92|2.92| convenience functions automatically. So this is
61.84|4.32| usually how we set up a network in pytorch. And then there's
66.16|3.8| this constructor, the init constructor, that is something
69.96|3.28| we can define ourselves. So there's one line that we use
73.24|4.2| here, this is really just for inheritance. So it inherits the
77.44|3.34| init method from a module. But then everything else has
80.78|5.1| something we can define ourselves. So here, I'm setting
85.88|4.44| up a neural network with one, two hidden layers and one output
90.32|5.32| layer. And each layer is a torch and dot linear, a fully
95.64|4.56| connected layer here. And these are really in the init method,
100.2|4.12| only the parts that need to be updated, like the model
104.32|5.68| parameters. So how the network runs like the forward pass, that
110.0|4.64| is what we define in a forward method. So here, the input to
114.64|3.44| the forward method is just a data input that will be
118.08|3.96| provided during training. And then we define really how the
122.04|3.04| computation works. In this case, this is a network where we
125.08|4.16| first compute the net input, then we use the relu function, we
129.24|3.8| discussed a relu function earlier in this lecture, then we
133.04|4.92| have another fully connected layer net input, then another
137.96|3.98| relu, and then the output. And then we compute also our
141.94|3.66| probabilities for the output, we could technically skip this
145.6|2.96| step and only return the logits. It's really just a matter of
148.56|4.12| preference. And we will also discuss what softmax is and what
152.68|4.32| the logits are later in the upcoming weeks. So here, I
157.0|5.92| really want to emphasize that in the init method, we define
162.92|4.72| model parameters. And then in the forward method, we define how
167.96|4.56| and in what order the model parameters are used. So that is
172.52|2.96| just like the general outline here. And this is also similar
175.48|3.0| what to what we have done on in the previous video when we
178.48|3.08| talked about the adder line in the last step in the automatic
181.56|7.2| step. So here, consider step one as the setup or module
189.32|3.34| definition step. Because here, we are not really running any
192.66|4.46| code yet, we are just setting up our Python class. So then step
197.12|4.68| two, we actually instantiate or create our model. So here, I'm
201.84|4.96| just setting my random seed. Because if I go back one slide,
207.12|4.4| here, these, like I mentioned in the code examples, these will be
211.52|3.6| based on small random weights. Personally, I like to have my
215.12|4.24| code reproducible. So I usually set a random seed before I
219.36|3.76| initialize the model. So every time then you run the same code,
223.26|2.94| it will use the same random seeds if I use the same value
226.2|4.24| for random seed. However, in new network training, of course, it
230.44|3.4| requires sometimes to change the random seed because sometimes
233.84|2.56| you can have bad starting weights. I will talk also about
236.4|4.68| that more later. So I'm not always using the same random
241.08|3.9| seed. But if I want to reproduce these experiments, I write down
244.98|3.7| the seeds I use. And then if I have someone else execute the
248.68|3.92| code, they can use the same seed. Anyway, so here we
252.6|4.32| initialize the perceptron model. And then this is an optional
256.92|4.72| step to device. This is really very, very cool if you want to
261.64|3.72| run your code on the GPU. So the only line of code you really
265.36|2.08| need to change, I mean, there will be some other lines, but
267.56|4.8| the main line you have to change is this one. If you provide GPU
272.48|3.12| setting here, it will run all the code on GPU. So it will
275.6|3.24| transfer all that code to the GPU and run automatically on the
278.84|5.4| GPU, which is really convenient. And then another thing we set
284.24|4.04| up is the optimizer here. So here, like I also explained in
288.28|3.2| the previous video, it gets the model parameters. In this case,
291.92|3.24| if I go back one slide, sorry, we have a lot of model
295.16|3.28| parameters here, all these linear ones contain weights and
298.44|4.2| biases. So here, we tell the optimizer, what are the model
302.64|3.48| parameters, what needs to be updated during gradient descent.
306.44|10.56| So this is stochastic gradient descent that we discussed also
317.0|4.24| last week. So it's a stochastic gradient descent optimizer. Later,
321.24|2.76| we will see the other types of optimizers like different
324.0|4.76| flavors of stochastic gradient descent. Alright, so this is
328.76|4.56| what I described before. So we can provide if we have a CUDA
333.32|3.92| device, a GPU, we can specify it here, and then the code or the
337.24|3.48| model will be executed on the GPU, which can make training
340.72|3.08| much more faster. And then Thursday, I will show you some
344.6|5.6| some free platforms where you can use a GPU for free. Alright,
350.2|4.56| so step three is then the training step. So that is also
354.84|3.68| the same concept as I explained in the airline code in the
358.52|2.52| previous video. So much of it, what I'm showing you here on the
361.04|2.28| slides is really very similar to what I've shown you in the
363.32|2.4| previous video. I'm just walking through this a little bit more
365.72|6.92| slowly. So here, I have my loop over the epochs. Notice that we
372.64|4.8| set model train, this is a good practice because later, there
377.44|5.72| will be certain functions where we have a different behavior
383.16|3.04| during training and evaluation. For example, there's a concept
386.2|4.64| called batch norm or drop out. And it's a good habit in each
391.28|3.88| epoch to set it to train. And then when we do some logging or
395.16|4.36| evaluation, to set it up to evil, it's just a good habit. So
399.6|4.0| that is something that's always good to do. So I will also make
403.6|3.12| sure my code examples that I provide to you that this is
406.92|4.32| indeed specified. And also notice, you don't really have to
411.24|4.6| memorize this. Because in practice, when you write a new
415.84|2.64| neural network, or implement a new neural network, you would
418.48|2.92| never start from scratch, you would never like start with a
421.4|4.04| blank, empty script, and write down all these codes. What you
425.44|4.08| would do is you would copy and paste the code here, you would
429.56|3.16| copy and paste this as existing code. And then yeah, you would
432.72|4.08| just optimize or modify it. So you would never really start
436.8|4.32| from scratch totally. So in that way, you don't really need to
441.12|3.68| memorize, you just have to know where to find this information.
444.8|3.52| If you want to, yeah, if you want to write some encode, you
448.32|5.36| use usually a template to start with. Where was I? Okay, so here
453.68|5.76| we iterate over the epochs here we iterate over the batches,
459.6|2.72| there will also be a training loader that I will show to you
462.64|3.76| where we batch up our training set in a pytorch data set
467.04|2.8| context that makes also the iteration over the mini batches
469.84|4.24| a little more convenient. Here, this is like a requirement
474.08|5.92| because I'm I created this example for MNIST. And MNIST are
480.0|4.56| images 28 by 28. And my model here is a fully connected
484.56|3.04| network, it needs this long tabular data set this long
487.6|3.68| vector. So I'm just reshaping it. But this is a detail, don't
491.28|2.8| worry about it here at this point. There's one more thing.
494.16|4.16| If my model sits on the GPU, also my data has to sit on the
498.32|4.96| GPU. So that is something that is like required, we can't do a
503.28|3.36| computation, let's say multiplication, or matrix
506.64|4.72| multiplication between a matrix sitting on the GPU and the CPU,
511.44|5.76| they have to be either both on the CPU, or both on the GPU. So
517.2|3.2| personally, how this can be very, very easily handled is by
520.88|3.84| specifying somewhere in your code, something like oops,
526.4|5.12| something like device equals to either CPU or GPU. So usually
531.52|4.0| there's something you would want to use like torch dot device,
535.6|5.04| sorry, torch dot device. And then you would either set it to
540.96|7.84| CPU. Or let's say the cooler device. Usually, if you have one
548.8|3.84| GPU, you would set it to zero. If you want to use a second GPU
552.64|2.56| that you have in your computer, you can change it to one. So
555.2|4.0| this is like a really an index here. But I will also talk more
559.2|5.36| about this in the next lecture. So if you set this somewhere in
564.56|6.16| your code, then this variable will be used here. And here, so
570.72|2.48| you don't have to change anything. So it will just work
573.2|5.36| whatever you have either CPU or GPU. So then moving on, this is
578.76|3.68| the forward pass. So this is the forward pass of your model.
582.84|6.32| Notice that we don't actually call forward, we don't do model
589.16|9.44| dot forward features. We just call model features. It's almost
598.6|3.76| the same thing. I actually have a note here to remind you of
602.36|4.76| that. It's actually the same thing. But there's one extra
607.12|5.4| step if we don't do forward. So internally, Python, how classes
612.52|5.32| work in Python, there's some something called a call. And this
617.84|5.36| one will actually do some extra stuff and then inside run
623.2|5.12| forward. So if you do it like this, there will be another
628.32|3.32| method called basic dot underscore underscore squall.
631.92|3.12| And this one will do some checking, just making sure
635.04|3.68| everything looks okay, and then run dot model, model dot
638.72|4.8| forward. So in this way, this is usually how we do the forward
643.52|2.8| pass looks a little bit weird. But this is like how the forward
646.32|6.16| pass works. Then we compute the loss, set the gradients to zero
652.56|2.4| from the previous epoch. That's something I explained in the
654.96|5.58| code in the last video. Then we do the backward pass to compute
660.54|4.02| the gradients. And then we update the model parameters. So
664.56|3.66| that's, that's the major part in the training loop. And like I
668.22|2.62| said, you can always copy and paste this code and just adjust
670.84|2.56| it to your new network, you never really have to memorize
673.4|4.16| it. Personally, I also, I mean, I've done or looked at this so
677.56|3.52| many times, I could probably write this down. But why
681.12|3.36| memorizing this, if I can just use existing code and just
684.92|3.0| manually adjusted, what's really only important is that you
687.92|3.24| understand this, you have to understand what's going on. But
691.64|3.52| except that you don't have to memorize code. And I mean, like
695.16|4.6| I said, no one does that. All right. Um, yeah, there's just
699.76|4.2| some more written stuff of what I explained. So you can also on
703.96|2.4| the slides read through this more slowly, it's just some
706.36|3.48| annotation. So if you want to take a look at it at home, in a
709.84|5.32| quiet moment, you have also my annotation here. Sometimes
715.16|3.62| easier to listen. Sometimes it's easier to read than to listen,
718.78|7.26| I think. So the way I annotated everything. All right. And this
726.04|4.4| is also something I will explain when we talk about logistic
730.44|2.4| regression and multi layer perceptrons, why we use
732.88|0.68| logits.
735.6|2.88| Alright, so the main point here, the remaining point in this
738.48|5.44| video, is that there are two types of API in pytorch, there
743.92|4.8| is the object oriented API, and the functional API. And we can
748.72|3.92| actually use both or a mix of both. So with functional, I
752.64|4.08| mean, functional programming, like the concept of functional
756.72|3.24| programming versus object oriented programming. So
759.96|4.64| functional usually means that we have something without an
764.6|5.32| internal state. So the torch and torch dot n n functional API is
769.92|7.08| an API without an internal state. So what that means is, if
777.0|3.28| you take a look at the left hand side here, this is the perceptron
780.28|3.4| that I showed you earlier in this video. So where we define
783.68|4.64| the parameters in, in the constructor in the init
788.32|6.8| constructor, and then we call these things. Notice that for
795.12|4.56| certain parts where we have this F, so I'm importing torch dot n
799.68|4.56| n dot function as F just for brevity. So in certain parts, I
804.24|7.76| have this F here. So this is all using the functional API. So I
812.0|5.96| could have done it differently. I could have defined relu as a
817.96|4.52| class. So here, I could define it as a class. However, this
822.48|3.64| would be a little bit overkill. Because if you think about it,
826.12|7.4| what relu is a relu is just a function. Max, let's say x zero,
833.52|4.4| it just returns whatever value is higher, right. So it's like
837.92|2.56| this piecewise function, it doesn't have any weight itself,
840.48|2.96| or any bias unit or weight parameter or something like that.
843.68|3.08| It's just a function. So while that it's kind of overkill to
846.76|4.12| implement it as a class, because classes usually create objects,
850.88|3.96| and then this object, I mean, it doesn't have any parameters. So
854.88|2.64| it's kind of overkill, we can just use a regular Python
857.52|3.52| function for that. So this is like the difference between
861.04|3.84| using an object oriented and a functional API. And where does
864.88|3.36| it matter? So, like I showed you before, on the left hand side
868.24|3.24| is again, the implementation I showed you where I created these
871.48|3.92| weights here, the layers, the weight layers, and then I'm
875.4|5.2| using them in the forward pass. However, there's something that
880.6|5.04| is more convenient, it's the so called sequential class here. So
885.64|6.36| the sequential class executes things in order. So you can see
892.0|4.2| here, my forward method on the right hand side is much shorter
896.2|4.08| than on the left hand side. So what's going on here? So here on
900.28|2.8| the right hand side, I'm using sequential, it's, it's
903.08|3.08| essentially like a Python list. And everything that is inside
906.16|5.92| essential gets executed linearly. So one by one, so
912.08|4.84| first, it will execute linear, relu, linear, relu, linear, but
916.92|4.4| it won't. So how can I say it will define it first. So it will
921.32|4.08| define it in the sequential thing. And then we can use it in
925.4|4.76| forward. So I really like this, because it's very compact, but
930.16|5.52| it's using this object oriented API here. But it's still compact
935.68|5.56| because here, we define the parameters. And then we have to
941.24|5.44| memorize them in what order we use them. And then here, we call
946.68|5.0| them see that. So here, I have linear one, linear two, which I
951.68|3.0| have here in the same order. And if you have a deep neural
954.68|3.52| networks with, I don't know, 20 layers or something, it's easy
958.2|6.0| to make an error and copy and paste some values and accidentally
964.2|3.2| copy and paste them out of order and make mistakes with a
967.4|5.04| with a sequential one. Here, you define the order, when you
972.44|3.52| create the thing. And then let's say I'm assigning it to my
975.96|2.48| network. And then here, I'm calling it my network, but I
978.44|3.64| don't have to redo all the forward pass, it's automatically
982.08|3.08| in the sequential thing. So I like this actually back in the
985.16|3.76| day when I learned pytorch the first time and four years ago, I
988.92|2.56| was using mostly this API, because I felt like okay, this
991.48|4.84| is better because I'm avoiding the object oriented API for
996.32|2.6| things that don't have attributes. But then over the
998.92|6.12| years, I kind of run to prefer this API. Because here, it's
1005.04|3.68| harder to make mistakes, it's easier to define everything in
1008.72|4.2| the right order here, I find. But sometimes, of course, we
1012.96|2.76| also, yeah, we need to be flexible. Sometimes it makes
1015.72|3.56| more sense to use the API on the left hand side. For example, if
1019.28|3.32| we have custom research projects where we want to tinker a little
1022.6|5.44| bit more with the code, because there's one downside of the
1028.04|4.12| sequential API. So the sequential here, the sequential
1032.16|2.44| class, the problem is if you want to get intermediate
1034.64|4.76| results. So with that, I mean, if you want to know what, let's
1039.4|2.64| say the size of this one, or there's a buck or something, and
1042.04|3.4| you want to print the output of this one. So if I go back one
1045.44|5.0| more slide here, anywhere here, let me use a different color.
1050.44|7.08| Anyway, here, I can just insert a print out, for example, to
1057.52|3.04| print the output value of this one, if I'm curious at it, if I
1060.56|2.76| want to look at it, it's very easy to just insert a print
1063.32|2.68| statement. On the right hand side, you can't just insert a
1066.0|4.6| print statement here, it won't work. For that, we have to
1070.92|4.32| create so called hooks. So we have to compute, for example,
1075.28|3.76| forward hook or register forward hook. So that means really, we
1079.04|3.64| are hooking into this API. So you have to kind of first take a
1082.68|5.52| look at the order. So the indices. So here, after
1088.2|5.8| implementing this sequential thing, this should actually be
1094.68|7.36| net dot dot my network. So if I print out my network, you can
1102.04|3.72| see there are these indices 01234. It's essentially like a
1105.76|4.44| Python dictionary, almost. And then I can access this. So if I
1110.2|4.52| want to have, or if I want to see the output after this linear
1114.72|5.8| unit here, I can access it here, register this forward hook.
1121.2|2.88| It's a little bit weird. But then, when I call the model, it
1124.08|3.44| will print the output here. So it will print out the result
1128.4|5.2| that comes after here, it's instead of inserting, inserting
1133.6|4.4| this print statement here, I have to register this hook. And
1138.0|3.96| you can see, this is actually more work to register this hook.
1142.12|2.92| So sometimes it can be a little bit more cumbersome to use the
1145.04|4.2| sequential API. In some ways, it might be easier to do it like
1149.24|2.84| this, where we can just play around with it more. However,
1152.08|2.76| like I said, if you have a very large network with like 28
1154.84|5.04| layers, it's also more easy to make a mistake here to somehow
1159.88|3.96| have some repetition here, or things like that. And if you
1163.84|4.26| have only this one where you define it in order, and it gets
1168.1|2.26| executed in the same order you define it, it's hard to make
1170.36|3.12| mistakes. So you have to decide for yourself what API you
1173.48|3.24| prefer. I mean, it's really up to you. There's no right or
1176.72|4.36| wrong, both work the same way. It's just a matter of, yeah, I
1181.08|4.36| would say matter of taste. And I will probably switch more to the
1185.44|3.16| sequential API for the code examples I provide to you. But
1188.6|3.16| you can also for your class project use whatever you like.
1193.64|2.4| But also, yeah, if the multi layer perceptron stuff is a
1196.04|2.88| little bit too complicated, we will talk about multi layer
1198.92|3.48| perceptrons in next week's lecture. So that will be also
1202.4|3.48| something we'll be revisiting. So you don't have to memorize
1205.88|2.94| any of that stuff right now, you will see that multiple times
1208.82|5.94| later in this class again. One last thing about pytorch and
1214.76|5.52| style and things like that. So I found a very cool GitHub
1220.28|4.64| repository recently, a couple of months ago, where someone wrote
1224.92|2.76| down like the best practices for pytorch. And I thought that
1227.68|2.76| might be also something cool to look at. There was also an
1230.44|2.68| interesting section about Jupyter notebooks versus Python
1233.12|4.74| script. And that's exactly what I was also recommending. So the
1237.86|4.54| person here recommends also, to start with a Jupyter notebook to
1242.4|3.56| do some exploration and stuff like that. Maybe do some coding
1245.96|2.88| basic coding, and then later on move everything to Python
1248.84|3.68| scripts and deploy it on a server. It's like, yeah, because
1252.52|2.64| there are some advantages of using Jupyter notebooks. But
1255.16|3.04| there are also some advantages of using Python scripts.
1258.48|2.76| Personally, for teaching, I really like Jupyter notebooks
1261.24|4.6| because like you've seen before, I can insert figures and show
1265.84|3.0| intermediate results and things like that, which is really cool.
1268.84|3.36| But it's a little bit more inconvenient to run Jupyter
1272.2|4.8| notebooks on a server. So here also, like the person mentioned,
1277.56|3.6| the files can become huge, if we have one single Jupyter notebook
1281.16|3.48| and because especially if you print the output in the notebook,
1284.76|5.44| they will become very long. And yeah, sometimes, sometimes
1290.2|2.48| computation get interrupted in Jupyter notebooks for some
1292.68|3.04| reason. So in that way, it's also not ideal for long training.
1295.72|4.32| And yeah, it's it's easier to make mistakes in Jupyter
1300.04|5.92| notebook because the I find the debuggers are not that good. I
1305.96|4.72| mean, they list here debugging as a pro as a pro argument.
1310.88|3.16| Personally, I find debugging and Python scripts honestly easier
1314.04|3.88| because you have more helper functions or utilities and, for
1317.92|3.88| example, py charm or Visual Studio code. I most of the time
1321.84|3.24| use Visual Studio code, but also many people use py py charm,
1325.08|3.2| which is also very nice. So Python scripts have the
1328.28|3.84| advantage of that they are more robust when you want to run
1332.4|3.68| longer computations. And it's also easier to track changes if
1336.08|3.04| you use GitHub and want to look at changes, although there are
1339.12|2.96| some plugins for Jupyter notebooks. But to be honest,
1342.08|5.2| it's still simpler with Python scripts. I find debugging easier
1347.28|3.12| with Python scripts. However, yeah, also, like they say, it
1350.4|3.24| means rerunning the whole script. But an advantage of
1353.64|3.72| Jupyter notebooks is that you can run one computation or one
1357.4|4.12| cell at a time. But either or I mean, there are pros and cons on
1361.52|4.76| both sides. As a deep learning practitioner, I think you
1366.28|3.48| probably want to use a mix of both, maybe for simple things
1369.76|3.12| and analyses, using Jupyter notebooks. And then later on, if
1372.88|3.2| you have more sophisticated projects using Python scripts.
1376.44|2.96| In this class, I will also use a mix of both. I think for
1379.48|3.8| teaching Jupyter notebook is really nice. But for the some
1383.28|3.48| codes that I will provide later, I think Python scripts make more
1386.76|4.24| sense. All right, last thing also from this GitHub
1391.0|5.44| repository. So yeah, also some recommendations regarding the
1396.44|7.0| naming convention. So usually we use lower case conventions with
1403.44|4.4| these underscores for package modules, const as of not
1407.84|4.44| constants for instances of objects, methods and functions
1412.28|4.76| and variables. And for constants, we use capitals with
1417.04|2.28| underscores is just a common convention. That is also what
1419.32|5.36| I'm going to use for the code in this class. It's like a common
1424.68|2.44| convention. Okay, but yeah, you can read through this read me
1427.12|3.44| sometime also later during this course, it's not like super
1430.56|4.28| important. But if you read through this rather earlier than
1434.84|2.96| later, then yeah, you don't learn that say bad habits that
1437.8|4.88| you have to unlearn later. So it doesn't hurt to read this. Yeah,
1442.68|3.08| and more pytorch features will also be introduced step by step
1445.76|2.2| later in this course, when we start working with more
1447.96|3.96| complex, complex networks. Because yeah, I don't want to
1451.92|2.68| bombard you with too many things right now, because you haven't
1454.6|2.6| really seen the more complex networks like convolution
1457.2|3.8| networks. So there will be many things we will introduce one by
1461.0|3.8| one when we need them. So this was more like the big picture, I
1464.8|3.92| hope that made sense to you. And if not, we will see this
1468.74|3.94| multiple times again in class. So we will be using this general
1472.68|4.48| pytorch layout for almost everything. Alright, so with
1477.16|3.72| that, yeah, that was the week here, or the first part of the
1480.88|2.52| week, talking about pytorch, it was a little bit long, I think
1483.4|2.08| the Thursday lecture will be a little bit shorter, I just want
1485.48|5.44| to show you how to use some free computer on GPU resources. And
1490.92|2.7| that is because it will probably be shorter, also a good time
1493.62|5.54| then to catch up with other things in class. Alright, so see
1499.16|25.08| you on Thursday then.