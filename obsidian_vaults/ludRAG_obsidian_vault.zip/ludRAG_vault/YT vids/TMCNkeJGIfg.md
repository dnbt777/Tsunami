start_time|end_time|text
2.18|2.62| Yeah, as promised, I will keep this video short, I want to
4.8|2.48| briefly just outline a little bit about the deep learning
7.28|5.24| hardware and software landscape. So yeah, regarding
12.56|3.42| hardware for deep learning, what has happened in this area, there's
15.98|3.54| a lot of research going on in this area, but essentially, most
19.52|3.6| of it is still, or most of deep learning is still done using
23.12|4.96| GPUs. So Nvidia is advancing the GPUs every year, there's a new
28.08|3.44| model every year, actually, a set of models. So most people
31.52|4.2| still use GPUs for deep learning. However, especially if
35.72|4.2| you work at Google, there are also no cloud TPUs. TPU stands
39.92|3.42| for tensor processing unit, it's kind of like a specialized
43.34|5.04| version of GPUs that are better at certain tasks. I think I'm
48.38|3.3| not an expert in this. I actually never use TPUs because
51.68|3.98| I have my own computers and TPUs, I think restricted to
55.66|4.1| Google Cloud servers, although as a user, you can rent those.
60.24|4.2| But I think each TPU, it's technically cheaper than a GPU,
64.72|3.0| but not as powerful, the power comes from the fact that you can
68.02|4.74| combine a lot of them together. Anyways, ARM is also working on
72.76|3.54| machine learning processors. Also, the new MacBook, I think
76.3|3.12| has an ARM processor in it, which is kind of very
79.42|4.68| competitive compared to GPUs, but it's more for prediction
84.1|4.32| compared to training. So right now, still GPUs are the status
88.42|4.02| quo, most people are using GPUs. But again, other companies are
92.44|4.28| also developing custom chips, focused on deep learning, just
96.72|2.5| to make deep learning more efficient. Because if you think
99.22|4.56| about it, GPUs are really like, inspired or come from the gaming
103.78|3.34| industry. So they were not developed with deep learning
107.12|2.48| originally in mind. However, they are very good at deep
109.6|3.44| learning. And nowadays, Nvidia also develops chips that are
113.04|4.5| especially only for deep learning, not for gaming. Yeah,
117.54|3.3| and also, there's a new company called graph core, I just saw
120.84|2.12| that in a recent article, there's also no
124.08|3.48| IPU, which is an intelligence processing unit, which is
127.56|3.6| especially useful for graph neural networks. So you have
131.16|3.92| CPUs, which are very good at computing, simple computation
135.08|3.28| with scalar values, like single values, GPUs are very good at
138.36|3.84| working with vectors. And these IPUs are very good at working
142.2|4.86| with graphs. It's also a new thing recently. So regarding the
147.06|5.06| software landscape, I don't want to talk about it too much. But I
152.12|3.36| thought it might be interested. Interesting, because you may
155.48|5.04| also as a student learning now, pytorch wonder what the other
160.52|4.36| libraries are, and for example, how it relates to pytorch. So
165.6|2.52| here's a nice summary from the deep learning with pytorch book
168.44|3.34| about the history. So yeah, I remember back then I was using
171.78|3.76| Theano that was like before 2015. So in the first edition of
175.54|2.92| my Python machine learning book, I still used Theano. And then
178.5|3.76| approximately in 2015, TensorFlow came out by Google.
182.7|3.8| And yeah, also, lots of things have happened since then. So
186.52|3.42| back then, lasagna and Keras were high level wrappers around
189.94|3.74| Theano. So high level wrappers means making things more
193.68|4.66| convenient, because both TensorFlow and Theano were very,
199.26|2.36| I would say low level languages, they were not very easy to
201.62|2.48| use. And like, you could do a lot of things, they were very
204.1|2.64| powerful, but you needed to write a lot of code. So they
206.74|6.2| provided lasagna and Keras, they provided more easy access. But
212.94|5.12| then you also Keras extended its capabilities and also was made
218.06|4.34| compatible with TensorFlow and CNTK. CNTK was a deep learning
222.4|2.62| library by Microsoft, I'm not sure if it's still around, I
225.02|3.36| think it also stopped the development. Then there were
228.38|3.88| other special purpose libraries like cafe, chainer, dinette,
232.46|3.44| dinette, I think was a dynamic graphs, chainer was also dynamic
235.9|3.6| graphs, cafe was especially good for deployment, like mobile
239.82|5.12| devices, and things like that. I think it was based on C++, MX
244.94|3.16| net, and so forth. So there were many, many other libraries.
249.14|3.24| Yeah, but so what happened then in the next couple of years, a
252.38|3.4| lot of people were switching to TensorFlow. So Theano stopped
255.78|3.88| actually the development. So Theano was a university based
260.54|5.56| library on TensorFlow extended. So they consumed Keras. So
266.1|2.72| Keras became a part of TensorFlow, I think the Keras
268.82|3.76| developer started working for Google, then they hired him and
272.94|3.12| they were more tightly integrating tens of Keras and
276.06|6.08| TensorFlow. So then in TensorFlow version two, Keras
282.14|3.96| became the default API for TensorFlow. And they also added
286.14|6.0| eager mode, which is similar to pytorch. Yeah, dynamic graph. So
292.14|4.24| pytorch got the dynamic graph idea, kind of like from a
296.38|5.44| chainer, that's another library here. And then TensorFlow also
301.82|3.0| added it later on because it was really popular with the users of
304.82|3.32| pytorch. And then in TensorFlow two, nowadays, there's also an
308.14|4.92| eager mode. I heard some people or many people at Google don't
313.06|2.32| really like working with TensorFlow anymore, because
315.38|2.16| it's a little bit clunky. So there's also a new library
317.54|3.16| called Jax, which was developed at Google. So that's
320.7|3.68| independently developed from TensorFlow. And it's kind of
324.38|5.0| like NumPy that can be run on the GPU, also has autograd and
329.38|3.64| JIT capabilities. It's a relatively new library, it looks
333.02|3.36| interesting. And I think you can do cool things with it. But I
336.38|4.16| think it's, it's not where pytorch is right now with all
340.54|2.6| the features for deep learning. It's more like a lower level
343.14|2.72| library. There are other libraries on top of it. I
345.86|3.8| forgot the name, I think it's called flex, which is like a
349.66|4.0| wrapper around Jax more for deep learning. But again, on pytorch
353.66|4.4| is really, I think nowadays, the most mature library that is also
358.06|4.16| nice and easy to use. So most researchers like we saw last
362.22|2.76| week, really use type pytorch, because it's easy to use. And I
364.98|3.04| really recommend that as a beginner, especially, but also,
368.34|3.0| it's just like something everyone uses nowadays. So there's
371.34|3.36| nothing wrong with that. So pytorch, the history of pytorch
374.7|4.48| is that they compute consumed cafe to cafe to us again, an
379.22|3.92| independent project focused on mobile development and server
383.14|2.68| deployment, because pytorch was more like a research library.
386.06|3.96| Now it's both so it's good for production on mobile devices and
390.02|4.16| stuff, but also still for research. It was made way more
394.18|4.96| efficient over the years, got on an X support, which is standard
399.14|4.08| for exporting neural networks into a common format. So you can
403.34|3.52| actually export pytorch models and import them in other
406.86|2.52| libraries, other deep learning libraries and stuff like that.
409.62|4.8| And they actually added also graph mode. So in that way, pytorch
414.54|2.56| became more similar to TensorFlow by adding this graph
417.1|2.6| mode and TensorFlow became more similar to pytorch by adding the
419.7|4.56| IGA mode. So they are both very, very similar nowadays. Anyways,
424.26|4.76| that's just a short history of how software developed over the
429.02|4.12| years. In the next last video of lecture two, I want to briefly
433.3|3.64| highlight some of the current research areas and trends. And
436.94|13.52| then in the next lecture, we will get to perceptrons.