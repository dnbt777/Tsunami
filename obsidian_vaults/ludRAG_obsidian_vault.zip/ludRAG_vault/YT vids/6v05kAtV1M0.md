start_time|end_time|text
0.72|3.3| Okay, let's now talk about padding. So padding is a
4.02|3.86| mechanism that allows us to control the output size, in
7.88|4.24| addition to choosing the stride. So before we talked about only
12.12|5.12| the simple case of a stride that equals one, and that means if we
17.24|5.72| have an input image, and then we have our kernel, then a stride
22.96|3.88| of one means we move one position to the right and when
26.84|4.76| we do the convolution, and also then later, one position to the
31.6|5.2| bottom, so we move by one pixel each time. So the whole kernel,
37.12|3.84| we can choose a stride of two. So in that way, we move by two
40.96|4.68| pixels each time. And this would essentially approximately
46.32|4.88| shrink the size of the output by half. So the output with a
51.2|2.56| stride of two will be approximately only half as
53.76|3.8| large as the input. So the padding is kind of like an
57.6|5.32| opposite to that it allows us to make the output larger. So let's
62.92|8.32| assume we, we have this image here. And we have this output,
71.24|7.96| so input and output. So then again, we have our kernel that
79.2|6.72| slides over the image input. The kernel is not really important
85.92|4.32| here, per se. I mean, it kind of is but so what we're doing now
90.24|6.32| is we are adding a row, if we have a padding of one would be
96.56|4.28| padding one, one on each side, you can also actually control
100.84|6.0| this more finely, you can say one for the top, one for the
106.84|3.24| right side, one for the bottom and one for the left. So we have
110.08|3.78| a padding of one on each side. That means we add one row of
113.86|6.98| pixels on each side. So it's essentially adding another row
120.84|9.4| of pixels. And essentially, usually, we set these to zero.
130.24|5.04| So they are usually just zeros. So we are adding in this kind of
135.28|5.4| empty or artificial border around here, which helps us to
140.68|3.0| control the output size, because now instead of having the
143.68|3.4| kernel, like here in the center, the kernel would start actually
147.44|3.36| here, if we have a two by two kernel, for example, and then we
151.36|2.88| depending on the stride would either slide by one or two
154.24|3.2| positions to the right. So by that, we can kind of make the
157.44|3.28| output slightly larger. Of course, this is like a padding
160.72|4.44| of one, we can also generalize that, or have other values like
165.24|3.32| padding of two rows around here. And if you have a non
168.84|4.48| quadratic image, you can also compensate for that by also
173.32|3.92| making the padding only on the left or the right hand side. So
177.24|3.28| this is like the basic concept behind padding, it's
180.52|5.48| essentially just adding a border around the image. I believe I
186.0|3.28| already showed you this equation last week, this is the equation
189.28|4.8| for computing the output size of a convolutional layer. So on
194.08|5.76| last time, though, we regarded padding as p equals zero. So we
199.84|4.04| didn't have any padding. So this term canceled last time. But
203.88|5.36| yeah, now we can consider this equation with a padding that is
209.24|3.56| non zero. So this whole equation allows us essentially to compute
212.82|5.94| the output size for a given input size on particular, if all
218.76|5.24| the output is the output width, so we can do the same thing with
224.0|3.36| width and height. And the same would also apply for the height.
228.68|4.84| We compute it as the input width time plus two times the padding
233.56|6.32| amount minus the kernel size divided by the stride. And then
239.88|3.5| we are rounding this down. So this is the floor operation. And
243.38|3.1| then we add a one to it. So this is how we compute the output
246.48|2.88| size. So let's take a look at some of the examples of that.
250.48|3.8| Yeah, so there's a relatively nice article called a guide to
254.28|4.08| convolution arithmetic for deep learning. So I have some
258.4|3.56| visualizations from that article here. And we will also revisit
261.96|3.52| this article another time later on, when we talk about
266.04|3.8| deconvolution, or the so called transposed convolution in the
269.84|2.84| context of convolutional auto encoders. But for now, let's
272.68|4.2| focus on the regular convolutions. So in the left hand, upper
276.88|6.68| corner, I'm showing you an input of four by four input with a
283.56|4.0| stride of one and no padding, resulting in a two by two output
288.08|2.76| when I plug in these values in the previous equation. So that's
290.84|2.48| actually an animation. So you can actually see how it looks
293.32|3.72| like when we do the convolution. So you can see how all that
297.04|3.92| works. So we just move by one pixel position. And there you
300.96|4.08| can see, we actually lose one pixel on each side. That is
305.04|5.84| because, yeah, we don't go over the edges. So in that way, the
310.88|4.96| output will be by two rows and two columns shorter than the
315.84|5.44| input. So in the next one, which one is it? Or the upper right
321.28|5.76| one. So here, I have a padding of two. And also here, so each
327.04|4.0| side has a padding of two. And you can see, now the kernel
331.08|4.0| slides over the padding as well. So the paddings, these are
335.08|3.16| usually just zero, so they don't contribute anything to the
338.26|4.26| computation, right. So when you compute the convolution, it's,
342.84|3.96| in a way, a weighted sum, and these are zeros. So nothing
346.8|4.8| really happens, you don't, you don't change any value. So what
351.6|5.76| I mean is, um, when we have this case in the upper left corner,
358.28|6.04| only these values contribute because these are essentially x
364.32|4.44| times w's as well, but the x is equal to zero. So which kind of
368.76|3.28| doesn't do anything. So here, in this case, it will only focus on
372.04|4.56| this corner here. Um, yeah, this is how you can then control the
376.6|3.8| output size a little bit so that you don't lose pixels on each
380.4|3.2| side. So this is like an extreme case here, the output is even
383.6|5.76| bigger than the input. Um, yeah, that is also kind of an artifact
389.36|3.24| of the fact that the kernel size is four by four. And why did I
392.6|3.52| pick this particular example? That's just because there was an
396.12|3.12| animation for that one. Usually, in practice, it's more common to
399.24|5.12| use three by three or five by five kernels. Last one left
404.38|3.9| lower corner, and this is a stride of two. So if you had or
408.28|5.2| were unsure how the stride of two works now as an example. So
413.48|3.52| in this case, also, we get an output of two here, the input is
417.0|6.36| five, five by five, resulting in an output of two. Alright, so
424.2|4.8| there are two main terms I briefly wanted to mention in
429.0|3.56| pytorch. They are not commonly used. It's more like, I would
432.56|5.08| say a more traditional wording that was kind of used in tensor
437.64|3.2| flow, at least when I used tensor flow back then. So there's
440.84|2.28| something called a valid convolution and the same
443.12|3.12| convolution, these terms come from more traditional computer
446.24|4.0| vision. And a valid convolution means essentially no padding.
450.78|2.74| And this can have as a consequence, the shrinking
453.52|7.52| feature map. So if I go back one slide, so on this one here, and
461.04|3.56| this one here, these would be valid convolutions. So that
464.6|6.98| means we're not going over the edge of the input. Why valid? I
471.58|2.34| don't know why valid, but probably it's really referring
473.92|4.12| to the fact that we stay within our boundaries here. The other
478.04|5.94| one is called same convolution. Same convolution means that we
483.98|4.32| usually choose a padding such that the input and the output
488.3|3.9| size are the same. So the output size equals the input size. On
492.2|2.88| the previous slide, I don't have any particular example of a
495.44|2.58| valid, sorry, of the same convolution, I should have maybe
498.02|2.94| added one. For the same convolution, we would have an
500.96|4.16| example where the input size is exactly the same size as the
505.12|3.94| output. Notice, it's not always possible. So in this case, if we
509.06|3.3| have to have a four by four kernel, it's not possible to
512.36|4.2| maintain this size, if I would have one row of padding, also,
516.56|4.8| even then, I wouldn't be able to get the same input size. All
521.36|6.44| right. Um, yeah, and this is maybe also why on common
527.8|3.4| kernel size conventions are three by three, five by five,
531.28|4.04| and seven by seven, so that you can actually have the same
535.32|8.82| convolution. So how do we choose padding so that we get same
544.14|5.3| convolution. So you can do this by rearranging things if you for
549.44|5.14| simplicity, now ignore the floor operation with a stride. So if
554.58|3.38| you only use the stride of one can cancel that. And it
557.96|3.36| simplifies to this form. So we just remove the floor and
561.32|5.68| stride. And then you can just rearrange that and bring p to
567.0|3.88| the left hand side, or to the right hand side, and then divide
570.88|7.72| by two. So we can rearrange things. And then we can simplify
578.6|4.68| things, we want the input to be the same size as the output,
583.28|3.56| right. So because we want the input to be the same size of the
586.84|5.48| output, we can cancel those. So what remains is this one. And
592.32|3.72| this one allows us then to choose the stride, sorry, the
596.04|3.2| kernel size such that we have the same convolution, for
599.24|5.76| instance, if I have a four by four kernel, then I would have
605.0|5.68| one four minus one divided by two, which is an uneven
610.68|4.72| numbers 1.5. So I can see, okay, there's no way I can have
618.16|2.64| padding such that I have the same convolution, the only
620.8|3.28| solution, maybe let me clarify, there is actually a solution
624.08|6.0| where you add one row to the bottom, but two rows to the top,
630.12|3.12| for example, that would be one of one solution. But if you want
633.24|2.84| if you want to have a symmetric padding, and there is no good
636.08|4.0| way for that. However, if you use a kernel that is five, you
640.08|8.04| have five minus one divided by two, which is four, it's two,
648.12|2.64| right. So in this way, you can choose a padding of two, if my
650.76|8.8| kernel size here was on five, then we would have ended up with
659.56|6.84| a five output. Okay, so this is just the padding in a nutshell.
666.6|4.24| In the next slide or next video, I will talk about spatial
670.84|19.24| dropout and spatial batch non.