start_time|end_time|text
1.16|3.36| Yeah, now that we spent so much work on understanding this
4.62|3.22| scaled dot product attention mechanism in the previous video,
8.12|5.28| let's rest on our laurels and just extend this multiple times,
13.44|4.48| which we will call multi head attention. So it's also part of
17.92|3.76| the transformer model, which we will eventually get to. So for
21.68|3.7| now, let's focus on the multi head attention though. So in the
25.38|4.54| previous video, I showed you this, where we computed this
29.92|7.92| attention matrix. And we can think of this as one attention
40.0|4.72| head. And yeah, surprise, surprise, multi head attention
44.72|4.72| is this thing here, just multiple times using a
49.44|5.42| different weight matrices. So to summarize, we are now going to
54.86|4.86| apply self attention multiple times in parallel, similar to
59.72|3.28| how we use multiple kernels for the different channels in the
63.2|4.32| CNNs. So remember, when we talked about CNNs, we had, for
67.52|5.08| instance, input image with three color channels, and we went from
72.6|4.32| three channels to 64 channels, for example, so for that, we
76.92|5.08| used 64 kernels in parallel, these would be, for example,
82.16|4.2| three by three by three kernels, and we had 64 of those. So in
86.36|4.12| that in a similar manner, we can also use multiple of these
90.64|3.36| processes here, these multiple attention heads, I'm not sure
94.0|3.4| why it's called a head, but let's just use the original
97.4|3.0| terminology, we can use multiple of these attention heads to
100.4|5.88| compute things in parallel, and yet to attend different parts of
106.28|4.08| the sequence differently. So for each head, we use different
110.38|4.5| weight matrices. So we had three mid weight matrices for the
114.88|4.04| query, the key and the value. And we will use different ones
118.92|3.44| now, and then we will concatenate those the results
122.36|2.9| of those. So it will be more clear in the next slide, I
125.26|4.62| guess. So in the original attention is all you need paper,
129.88|6.24| they had eight attention heads. So essentially, they had eight
136.84|4.28| times three matrices. So each attention had had a set of the
141.12|5.28| query key and value matrix, and we had eight of those sets. And
146.4|2.84| this allows the model to attend to different parts in the
149.24|4.96| sequence differently for each head. It's similar to the concept
154.2|4.44| behind color channels, essentially, or output channels.
159.36|6.32| Okay, so again, so this is our scaled dot product attention
165.68|6.0| that we talked about, that's essentially this. And here is
171.68|3.72| the multi head attention. That's just a screenshot from the
175.4|3.84| original paper. And you can kind of guess what's going on here.
179.24|4.04| So here in the center is the scaled dot product attention.
183.28|4.76| It's essentially this one summarized. But you can see,
189.56|3.4| this is just stacked. So you have you have a stacking here.
192.96|5.32| So use you repeat this eight times, whereas in the original
198.28|6.08| paper, they had this eight times. So the linear corresponds
204.36|4.32| my guess is my guess to the matrix multiplication between
208.68|8.48| the weight matrices and the inputs. Okay, um, yeah, the
217.16|4.68| input sequences t times 512 dimensional, like we talked
221.84|5.8| before. And in the transformer model that we will be talking
227.64|6.44| about in the next video, they use 512 for the input embedding
234.08|4.92| size. And for the value size for so when we have the weight
239.0|7.16| matrix, sorry, TV, so we will have the dimensionality of that
246.16|17.12| would be t times dv, where dv is 512. So this is t divided by h
263.32|10.52| that's the number of attention heads. So this is 64. And this
273.84|3.12| is such that when you multiply it by the number of attention
276.96|6.76| heads, you get the input and input embedding size back. And
283.72|3.08| that is useful when you want to use something like skip
286.84|4.36| connections, and you have a skip connection is like, if you
291.2|6.08| remember, like this, so you have a layer x plus x, the input, so
297.28|1.7| you have to have the same dimension. Otherwise, the
298.98|6.04| addition doesn't work. Okay, so the concatenation here is we
305.02|8.18| have done the scaled dot product attention, if I go back here, the
313.2|4.72| scaled dot product attention is t times dv dimensional, right?
318.0|5.32| That's one scale to dot product attention. So it's one. One of
323.32|8.64| these here is t times dv dimensional. So one of these
331.96|7.32| essentially times, now we have h of them, right? So we repeat
339.28|3.16| this h times, for instance, in the original paper eight times,
342.88|7.08| and then we concatenate. So what we will get is this year, eight
349.96|6.76| times, so we will get h times, so we'll get dv times h. And if
356.72|8.68| dv is 64, we will get 512 dimensional input back here. So
365.4|6.12| again, one, one attention that is t times dv, we concatenate
371.72|5.36| and get this t times 512 here in this concatenation step. So
377.08|4.74| that's essentially what's going on in the in the multi head
381.82|3.46| attention, we repeat this multiple times this scale dot
385.28|3.62| product attention, each time with different weight matrices,
388.9|6.06| and then we concatenate the results. A few more things. So
394.96|4.4| there's another matrix involved here. So you can see there's
399.36|5.28| this linear matrix. So this linear matrix is just to
404.64|2.88| provide more parameters for learning, for instance. So we
407.52|3.84| have the concatenation, and this matrix is dv times h
411.36|3.04| dimensional, and then we have an output dimension. And the
414.4|4.36| output dimension is equal to the rows and the columns is the
418.76|3.84| same number. So it's a quadratic matrix. So the output would be
422.6|8.26| also 512 here. Okay, and this is it for multi head attention.
430.86|3.76| Pretty simple concept. It's essentially just applying the
434.62|2.8| scaled dot product attention mechanism multiple times in
437.42|3.48| parallel, concatenating the results, putting it through
440.9|4.76| another fully connected layer. And yeah, that's it. So and now
445.82|2.84| we have talked about all these concepts, but we haven't learned
448.66|3.6| yet how they fit together into a model. And this is the
452.26|8.76| transformer model, which will be the topic of the next video.