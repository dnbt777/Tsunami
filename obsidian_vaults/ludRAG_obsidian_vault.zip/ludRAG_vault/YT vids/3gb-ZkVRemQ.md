start_time|end_time|text
5.04|4.0|so again I'm very happy to have Jason
6.48|4.279|here um so he's an AI researcher based
9.04|4.0|in San Francisco currently working at
10.759|4.161|openi he was previously a research
13.04|4.68|scientist at Google brain where he
14.92|4.68|popularized key ideas in llms such as
17.72|4.44|Chain of Thought prompting instruction
19.6|4.16|tuning as well as emergent phenomena um
22.16|3.52|he's also a good friend of mine and he's
23.76|4.2|been here before to give some talk so
25.68|5.16|we're very happy to have you back Jason
27.96|5.32|and take it away great uh
30.84|6.52|uh
33.28|5.959|wow yeah thanks for the intro um so a
37.36|3.84|bit about the structure uh so I'll talk
39.239|3.961|for around 30 minutes and then I'll take
41.2|3.44|a few questions and then K Juan will
43.2|4.199|talk for 30 minutes and then we'll both
44.64|2.759|take questions at the
47.52|8.839|end um great so I want to talk uh about
53.48|5.28|a few very basic things and I think the
56.359|5.0|fundamental question that I hope to get
58.76|8.44|at is
61.359|9.841|is why do language
67.2|6.919|models work so
71.2|4.52|well um and uh one thing that I'd
74.119|3.36|encourage everyone to do that I found to
75.72|6.32|be extremely helpful in trying to answer
77.479|6.32|this question uh is to use a tool which
82.04|3.84|is
83.799|4.921|manually
85.88|5.72|inspect
88.72|5.64|data um and I'll give a short anecdote
91.6|5.559|I've been doing this for a long time so
94.36|4.88|in uh in 2019 I was like trying to build
97.159|3.361|one of the first lung cancer classifier
99.24|2.559|so like there' be an image and you have
100.52|5.48|to say like okay what type of lung
101.799|5.481|cancer is this um and uh my first my
106.0|3.719|first thing was like okay if I want to
107.28|3.96|train a neural network to do this I
109.719|3.68|should be able to at least do the task
111.24|4.04|so I went to my adviser and I said like
113.399|4.161|oh I want to learn to do this task first
115.28|4.0|and he said Jason uh you need like a
117.56|3.44|medical degree in like three years of
119.28|3.92|pathology experience to like even do
121.0|3.92|this task and I found that a bit
123.2|3.919|discouraging but uh I wouldn't did it
124.92|4.44|anyways so I basically looked at like
127.119|4.441|the specific type of lung cancer that I
129.36|3.92|was working on and I'd like read all the
131.56|3.72|papers on like how to classify different
133.28|3.76|types and I went to pathologist and I
135.28|3.599|said okay I like try to classify these
137.04|4.479|what did I do wrong and then what do you
138.879|5.36|think of that and in the end I learned
141.519|5.601|how to do this task of classifying lung
144.239|5.201|cancer um and uh the result of this was
147.12|4.399|like I gain intuitions about the task
149.44|6.519|that led to many
151.519|7.72|papers um okay so first uh I will do a
155.959|6.241|quick review of language models so the
159.239|6.041|way language models are trained are with
162.2|5.8|uh the next word prediction task so
165.28|5.959|let's say you have
168.0|6.519|uh let's say you have a sentence
171.239|5.881|Dartmouth students like
174.519|4.44|to um and the goal of next word
177.12|3.08|prediction is you have some words that
178.959|2.2|come before and then you want to predict
180.2|5.72|the next
181.159|7.16|word and what the language model does is
185.92|4.399|it outputs a probability for every
188.319|6.401|single word in the vocabulary so
190.319|7.241|vocabulary would be like a
194.72|5.4|arvar uh you know
197.56|6.239|drink
200.12|6.24|study and then all the way to like
203.799|4.761|zucchini um and then the language model
206.36|4.12|is going to put a probability over every
208.56|3.8|single word here so like you know the
210.48|5.0|probability of a being the next word is
212.36|5.799|like something really small arvar is
215.48|7.16|something really small and then maybe
218.159|9.0|drink is like say 0.6 study is like
222.64|4.519|0.3 uh zucchini is again really
227.959|6.521|small um and then the way that you train
231.799|6.241|the language model is you say I want
234.48|7.44|let's say drink is the correct word
238.04|7.68|here I want this number here 0.6 to be
241.92|6.599|as close as possible to one so your loss
245.72|4.32|is like basically how close is the
248.519|4.0|actual word the probability of the
250.04|5.68|actual next word and you want this loss
252.519|7.161|to be as low as
255.72|3.96|possible um okay
263.4|4.04|so the first
265.52|4.8|intuition that I would encourage
267.44|5.64|everyone to to use um
270.32|4.56|is
273.08|4.8|next
274.88|3.0|word
278.24|3.239|prediction uh
282.36|4.8|is
284.759|4.28|massively
287.16|4.56|multi-
289.039|5.481|task
291.72|5.6|learning um and uh what I mean by this
294.52|5.48|is the following I'll give a few
297.32|6.52|examples uh
300.0|6.8|so uh it when you train a language model
303.84|5.68|on a large enough database large enough
306.8|4.839|data set um on this task of next word
309.52|4.679|prediction you have a lot of sentences
311.639|4.441|that you can learn from so for example
314.199|4.28|uh there might be some sentence in my
316.08|4.239|free time I like to and the language
318.479|4.0|model has to learn that code should be
320.319|3.681|higher probability than the word banana
322.479|3.961|so it learn some
324.0|5.319|grammar um it will learn lexical
326.44|5.12|semantics so uh somewhere uh in your
329.319|4.121|data set there might be a sentence I
331.56|4.759|went to the store to buy papaya dragon
333.44|4.28|fruit and durian um and the language
336.319|3.72|model should know that the probability
337.72|4.52|of durian should be higher than
340.039|4.16|squirrel um the language model will
342.24|3.28|learn World Knowledge so there will be
344.199|4.12|some sentence on the internet that says
345.52|4.44|you know the capital of azer is and then
348.319|4.0|the language model should learn that it
349.96|5.28|should be Baku instead of
352.319|4.72|London um you can learn traditional NLP
355.24|4.04|tasks like sentimen analysis so there'll
357.039|3.801|be some sentence you know I was engaged
359.28|3.8|on the of my seat the whole time the
360.84|3.68|movie was and the language model looks
363.08|4.0|like okay if these are the prior next
364.52|4.519|words the next word uh should probably
367.08|5.36|be good and not
369.039|6.6|bad um and then finally or another
372.44|4.84|example is translation uh so here you
375.639|4.56|might see some sentence the word for
377.28|4.919|pretty in Spanish is um and then the
380.199|3.44|language model should weigh Bonita more
382.199|4.361|than
383.639|5.12|Ola um spatial reasoning so you might
386.56|4.52|even have some sentence like Ira went to
388.759|5.16|the kitchen to make T standing next to
391.08|4.88|iro zuk Zuko pondered is Destiny Zuko
393.919|3.921|left the and then kitchen should be
395.96|4.84|higher probability than
397.84|5.24|store um and then finally even some math
400.8|5.16|questions so uh you might have like some
403.08|4.64|arithmetic exam answer key somewhere on
405.96|3.16|the internet and then the language model
407.72|4.24|looks at this and says okay the next
409.12|5.479|word should probably be 15 and not
411.96|4.04|11 um and you can have like basically
414.599|4.44|millions of tasks like this when you
416.0|5.24|have a huge uh data set um and you can
419.039|3.6|think of this as basically extreme
421.24|4.079|multitask
422.639|5.96|learning um and these are sort of like
425.319|8.32|uh very clean examples of tasks um but
428.599|5.04|I'll give uh an example of
434.56|4.639|uh how arbitrary some of these tasks can
440.4|9.4|be um so uh here's a sentence from uh uh
445.8|4.0|Wikipedia Biden
451.199|5.161|married
453.759|4.72|uhia okay and then now uh pretend you're
456.36|5.08|the language model and you could say
458.479|5.84|like okay what's the next word here um
461.44|5.68|and the next word here is a hunter so is
464.319|4.041|Biden's first wife um and so like okay
467.12|3.199|what's the language model learning to
468.36|4.959|predict from predicting this word I
470.319|3.0|guess like uh World
474.759|5.0|Knowledge um and then what's the next
476.879|5.361|word after this uh turns out the next is
479.759|5.921|a comma so here the model is learning
482.24|5.399|like basically comma
485.68|4.6|prediction um and then what's the next
487.639|5.56|word after that uh I think it's that
490.28|4.919|kind of hard to know but the answer is a
493.199|5.161|um and I guess this is like maybe
495.199|3.161|grammar but like somewhat
499.4|6.919|arbitrary um and then what's the next
501.28|5.039|word after that um turns out it's
506.879|4.6|student uh and uh this I would say I
510.08|4.519|don't know what task this is this is
511.479|4.48|like uh you know you know it could have
514.599|3.481|been woman it could have been something
515.959|4.841|else um so this is like a pretty
518.08|4.879|arbitrary task and the point that I'm
520.8|3.92|trying to make here is that the next
522.959|3.56|word prediction task is really
524.72|3.2|challenging so like if you do this over
526.519|3.481|the entire database you're going to
527.92|5.56|learn a lot of
530.0|3.48|tasks um
537.56|5.44|okay the next uh intuition I want to
540.44|5.12|talk about
543.0|8.92|is
545.56|6.36|scaling which is by the way uh let's say
553.079|4.481|scaling
554.959|5.601|compute and by the way compute is equal
557.56|5.56|to how much data you have times the size
560.56|2.56|of language
565.48|5.599|model um reliably improves loss
576.6|7.44|um and uh this idea uh was basically
580.079|3.961|pioneered by Kaplan at
584.68|5.839|all in 2020 I would encourage you guys
587.839|5.601|to read the paper um and uh what this
590.519|5.56|basically says is uh you can have a plot
593.44|7.88|here and we'll see many plots like this
596.079|5.241|um where the x- axis is compute
602.12|7.08|um and the y- AIS is
605.0|6.16|loss and what this intuition says is you
609.2|3.72|can train one language model you'll have
611.16|3.96|that loss and obviously want loss to be
612.92|3.96|lower so you can train the next one
615.12|4.0|it'll have that loss if you train the
616.88|3.92|one after that it'll have that loss then
619.12|2.6|if you train the one after that it'll
620.8|4.36|have that
621.72|5.04|loss and you can basically predict the
625.16|2.799|loss of a language model based on how
626.76|3.079|much compute you're going to use to
627.959|3.88|train it
629.839|5.0|um and the reason why this is called a
631.839|5.921|law is that in this paper they showed
634.839|5.521|that the xais here is actually seven
637.76|4.72|orders of magnitude so like basically it
640.36|3.52|would be surprising if the trend broke
642.48|4.039|if you
643.88|5.6|continued and the important thing about
646.519|4.32|this is that the line does not go like
649.48|4.72|that
650.839|5.081|because if it went like that then it
654.2|3.4|would saturate and then putting more
655.92|6.2|compute or training a larger language
657.6|4.52|model wouldn't actually lead to lower
671.8|7.56|loss um okay so I think a question that
677.519|4.281|we don't have a good answer to as a
679.36|5.64|field uh but I'll give you like a hand
681.8|5.159|wavy answer is uh why does scaling up
685.0|4.88|the size of your language model um
686.959|6.361|improve the loss um and I'll give like
689.88|4.36|two basically handwave answers so here's
693.32|4.84|small
694.24|6.56|LM and here's large
698.16|5.56|LM um so one thing that's important is
700.8|5.64|like how good is your language model at
703.72|2.72|memorizing
707.399|4.44|facts um and imagine you're a small
710.12|4.08|language model and you you see a bunch
711.839|4.481|of facts on the internet you have to be
714.2|3.8|pretty choosy in like which facts you
716.32|3.44|memorize right cuz like if you don't
718.0|3.88|have that many parameters you like oh I
719.76|3.36|can only memorize like a million facts
721.88|3.199|is this one of the facts I want to
723.12|3.6|memorize to like get the lowest loss and
725.079|3.76|so you have to be very
726.72|4.48|selective whereas if you're a large
728.839|2.361|language
731.959|4.921|model you can memorize a lot of tail
734.76|3.68|knowledge and so basically every fact
736.88|2.72|you see you don't have to say oh is this
738.44|2.6|something I want to memorize you can
739.6|4.2|just memorize
741.04|3.599|it and then the other hand wavy answer
743.8|4.76|I'll
744.639|6.521|give is small language models uh tend to
748.56|4.36|learn first
751.16|4.119|tics
752.92|3.8|so if you're like a small language model
755.279|3.12|you're like already struggling to get
756.72|3.44|the grammar correct you're not going to
758.399|4.361|do your best to like try to get the math
760.16|5.479|problem exactly correct um whereas if
762.76|6.199|you're a large language
765.639|4.721|model um you have a lot of parameters in
768.959|3.44|your in your forward pass and you can
770.36|4.32|try to do really complicated things to
772.399|6.361|get the next token correct uh and and to
774.68|4.08|get the loss as low as possible
788.04|4.479|um okay so the third intuition I'll talk
790.24|5.839|about
792.519|3.56|is while
796.44|3.03|overall
798.199|2.561|loss
799.47|4.29|[Music]
800.76|3.0|improves
805.8|4.0|smoothly individual
811.76|6.72|tasks can
815.48|3.0|improve
820.36|6.279|suddenly um and uh here's what I mean by
823.36|7.56|this so uh you can write your overall
826.639|7.481|loss by this I mean you know if you take
830.92|4.96|uh uh some Corpus of data and you and
834.12|5.24|you compute the overall loss on every
835.88|5.16|word in that data set the overall loss
839.36|3.88|because we know that next word
841.04|4.52|prediction is massively multitask
843.24|4.519|learning you can decompose this overall
845.56|4.56|loss into the loss of every single
847.759|6.921|individual task so you have like I don't
850.12|6.48|know some small number times the uh loss
854.68|6.76|of say
856.6|9.08|grammar uh plus some small number times
861.44|9.6|the loss of like sentent
865.68|5.36|analysis plus uh some small number
871.12|7.079|times uh the loss of like World
875.24|6.12|Knowledge plus and then all the way to
878.199|8.401|like let's say you have uh something
881.36|7.56|times the loss of uh
886.6|4.799|math and so so you can basically write
888.92|4.839|your overall loss as the weighted sum of
891.399|5.56|the individual tasks in the data
893.759|6.561|set and now the question is let's say I
896.959|6.0|improve my loss from uh from four to
900.32|5.24|three um do each of these individual
902.959|5.56|tasks improve at the same
905.56|5.0|rate well I would say probably not so
908.519|3.88|you know if you have a good enough
910.56|3.839|language model it's already doing
912.399|5.841|basically perfectly on grammar and tens
914.399|3.841|analysis so this might not
918.36|4.08|improve so this might be
924.199|5.76|saturated um and maybe the law the loss
927.639|6.0|on math is not it's not that good at
929.959|3.68|math yet so this could improve
936.839|5.24|suddenly um and uh I'll redraw the
939.199|2.88|diagram to show
945.8|6.2|this um so
948.48|3.52|again compute
952.639|7.841|here uh and loss here and your overall
956.519|3.961|loss is like this
961.199|6.32|um what I'm saying is there might be
965.92|6.24|some part of that overall loss that
967.519|6.88|scales like this uh so this is say
972.16|7.0|grammar so for example you could say
974.399|6.56|like uh if GPT 3.5 is there and GPT 4 is
979.16|5.919|there you haven't actually improved the
980.959|7.201|grammar that much on the other hand you
985.079|6.081|might have something like this for say
988.16|6.0|doing math or harder tasks uh where the
991.16|5.0|difference between GPT 3.5 and GPT 4
994.16|5.72|will be much
996.16|3.72|larger um and it turns
1005.0|5.319|out it turns out you can look at a big
1007.92|4.32|set of tasks which I did um and you can
1010.319|5.481|look at like what's the shape of of
1012.24|5.32|these scaling curves um so I looked at
1015.8|4.12|202
1017.56|4.68|tasks uh there's this Corpus called Big
1019.92|5.399|bench which has like 200 tasks I looked
1022.24|6.079|at all of them um and here's the
1025.319|3.0|distribution
1029.12|7.16|so uh you have this was 29% of tasks
1034.319|4.841|that were
1036.28|6.08|smooth uh so if I if I draw the scaling
1039.16|5.679|plot compute is on the x
1042.36|5.4|axis and then here we have accuracy
1044.839|5.561|instead of loss so higher is better then
1047.76|5.64|you have something like this
1050.4|5.399|um I believe this was
1053.4|5.24|22% uh will be
1055.799|5.681|flat so if you have your scaling curve
1058.64|4.56|it'll just all be zero the task was too
1061.48|4.36|hard uh
1063.2|6.04|2% will be something called inverse
1065.84|6.48|scaling I'll talk about this in a sec uh
1069.24|4.799|but what that means um is the accuracy
1072.32|3.52|actually gets worse as you increase the
1074.039|6.401|size of the language
1075.84|8.44|model um and then I think this was
1080.44|3.84|133% will be not
1086.0|4.88|correlated so uh you have like something
1088.96|4.04|like that I don't know um and then
1090.88|4.4|finally a pretty big
1093.0|6.36|portion
1095.28|7.04|33% uh will be
1099.36|7.72|emergent abilities and what I mean by
1102.32|7.839|that is if you plot your
1107.08|5.68|compute and accuracy
1110.159|6.281|for a certain point up to a certain
1112.76|6.68|point your loss or your accuracy will be
1116.44|4.4|zero and then the accuracy suddenly
1119.44|4.359|starts to
1120.84|5.68|improve um and uh so you can Define like
1123.799|5.081|an emergent ability basically as for
1126.52|2.36|small
1129.44|5.32|models uh uh it the performance is zero
1132.64|5.76|so it's not present in this model and
1134.76|3.64|then for large models
1140.24|5.48|um you have uh much better than random
1143.76|4.52|performance um and the interesting thing
1145.72|4.52|about this is let's say you had only
1148.28|4.08|trained the small language models up to
1150.24|3.439|that point you would have predicted that
1152.36|4.52|it would have been impossible for the
1153.679|4.441|language model to ever perform the task
1156.88|3.12|but actually when you train the larger
1158.12|4.2|model the language model does learn to
1160.0|5.88|perform the task so in sense in a sense
1162.32|3.56|it's uh pretty unpredictable
1171.12|8.48|um I'll talk about time you have I'll
1174.76|10.08|talk about one uh final thing uh which
1179.6|7.559|is something called inverse scaling SL
1184.84|2.319|shaped
1187.679|5.0|scaling um okay so I'll give a tricky
1190.4|4.24|prompt to illustrate this uh so the
1192.679|5.961|tricky prompt is
1194.64|4.0|this repeat
1198.96|4.199|after
1201.159|6.041|me
1203.159|8.76|all that
1207.2|6.76|glisters is not
1211.919|3.561|glib
1213.96|4.52|all
1215.48|3.0|that
1218.88|6.039|listers is
1221.48|5.52|not um and uh this is the prompt I give
1224.919|5.161|to the language model and the goal is to
1227.0|6.52|predict this next word uh and obviously
1230.08|7.4|the correct answer is glib because you
1233.52|8.279|asked to repeat after after me um and
1237.48|6.72|what you see is let's say you have a
1241.799|5.24|extra small language Model A small
1244.2|5.2|language model and a large language
1247.039|5.601|model the performance for the extra
1249.4|7.84|small language model will be
1252.64|6.72|say here's 100% the small language model
1257.24|4.12|is actually worse at this task
1259.36|4.6|so something like something here and
1261.36|4.12|then the large language model again uh
1263.96|4.719|learns to do this
1265.48|7.24|task so uh how do we basically explain a
1268.679|4.041|behavior like this for a prompt like
1280.64|7.44|this and the answer is you can decompose
1284.96|5.92|this prompt into like three subtasks
1288.08|5.24|that are basic being done um so the
1290.88|4.279|first subtask is like can you repeat
1293.32|5.12|some text
1295.159|6.841|right um and if you draw the plot here
1298.44|5.0|again uh extra small small large uh and
1302.0|4.72|then here is
1303.44|6.92|100 this is like a super easy task and
1306.72|7.0|so all the language models
1310.36|6.12|have perfect performance on that that's
1313.72|7.319|one hidden task the other task is can
1316.48|7.24|you uh fix a
1321.039|6.481|quote so the quote is supposed to be all
1323.72|8.6|that gly is not gold um and so you can
1327.52|7.24|then plot again extra small small large
1332.32|3.839|what's the ability to fix that quote
1334.76|5.08|well the small language model doesn't
1336.159|5.441|know the quote so it's going to get zero
1339.84|3.88|and then or the extra small doesn't know
1341.6|4.64|the quote so it's going to get zero the
1343.72|4.8|small will be able to do it um and the
1346.24|4.36|large can obviously do it so that's what
1348.52|4.88|what the scaling curve looks
1350.6|6.6|like um and then
1353.4|7.92|finally you have the quote follow you
1357.2|4.12|have the task follow an
1362.4|5.159|instruction um and uh obviously this is
1365.24|4.96|the instruction here um and you could
1367.559|6.36|say okay what's the performance of these
1370.2|3.719|models uh on this
1375.76|4.88|task um and the small model can't do it
1378.559|4.201|or the extra small model can't do it
1380.64|4.84|small model also can't do it but the
1382.76|3.799|large model can do it so you get a curve
1385.48|4.319|like
1386.559|6.36|this and then why does this explain this
1389.799|5.921|Behavior here well the small the extra
1392.919|5.561|small model it can repeat the it can
1395.72|4.559|repeat it can't fix the quote and it
1398.48|4.439|can't follow the instruction so it
1400.279|5.241|actually gets it correct it says
1402.919|6.041|glip says
1405.52|6.84|glib the small model
1408.96|5.04|can repeat it can fix the quote but it
1412.36|4.439|doesn't follow the instruction so it
1414.0|2.799|decides to fix the
1419.2|4.719|quote and then the large model it can do
1422.039|4.441|all three it can follow the instruction
1423.919|2.561|so it just
1428.0|5.0|repeats um and so uh that's how if you
1430.679|4.321|look at the individual subtasks you can
1433.0|5.72|explain the behavior of some of these
1435.0|3.72|weird scaling properties
1439.88|3.08|so I will
1441.61|6.27|[Music]
1442.96|4.92|conclude with one General
1448.08|6.24|takeaway
1450.039|8.201|um which is applicable if you if you do
1454.32|6.88|research um and the takeaway is to just
1458.24|2.96|plot scaling
1464.88|5.799|curves um and I'll just give a really
1467.48|5.079|simple example so uh you know let's say
1470.679|5.161|I do something for my research project I
1472.559|6.881|like f tuna model on some number of
1475.84|5.68|examples um and I get uh you know this
1479.44|6.28|is my
1481.52|7.279|thing I get some performance there and
1485.72|6.04|then uh here's the
1488.799|6.801|Baseline of uh not doing whatever my
1491.76|5.84|research project is uh and there's the
1495.6|4.12|performance the reason you want to plot
1497.6|5.559|a scaling curve for this is like let's
1499.72|5.6|say you uh take half the data uh and you
1503.159|5.361|find out that the performance is
1505.32|6.359|actually here so your curve looks like
1508.52|4.72|this um what this would tell you is you
1511.679|4.081|didn't have to collect all the data to
1513.24|5.679|do your thing and if you collect more
1515.76|6.72|you probably won't see an improvement in
1518.919|6.24|performance another scenario would be if
1522.48|4.799|you plotted that point and it was
1525.159|5.561|there then your Curve will look like
1527.279|5.4|this and and potentially if you kept
1530.72|5.319|doing more of whatever your research
1532.679|6.0|project is you'd see an improvement in
1536.039|3.801|performance and then finally maybe your
1538.679|5.081|point is
1539.84|6.559|there so your curve looks like this and
1543.76|4.68|in this case you would expect to see an
1546.399|3.76|even larger jump in performance after
1548.44|5.8|you continue doing your
1550.159|6.4|thing um so uh yeah I'll end my talk
1554.24|6.0|here and happy to take a few questions
1556.559|3.681|before him wants talk
1561.2|2.8|uh yeah go
1569.64|3.0|ahead
1573.36|6.52|dat The Source repeat the question oh oh
1577.36|6.52|yeah yeah thanks good question um so the
1579.88|5.72|question is uh uh it during pre-training
1583.88|4.919|how do you differentiate between good
1585.6|6.199|data and bad data um the question is uh
1588.799|4.48|or the answer is you don't really um but
1591.799|4.24|you should buy only training on good
1593.279|5.041|data so like maybe you should look at
1596.039|3.921|like your data source and filter out
1598.32|4.239|some data if it's like not from a
1599.96|2.599|reliable data
1603.159|4.561|source yeah do you want to give us maybe
1605.44|4.44|the intuition behind the intuition for
1607.72|5.36|one or two of the examples like
1609.88|5.36|emergent or you know why taale knowledge
1613.08|4.12|starts to develop sort of what's behind
1615.24|4.6|that what do you mean intuition behind
1617.2|4.4|intuition intuitively these Concepts
1619.84|4.64|that you're seeing in the graphs and
1621.6|6.079|from your experience and expertise what
1624.48|5.6|in the model itself is really causing
1627.679|4.841|that emergent behavior
1630.08|3.44|let's um what do you mean in in the
1632.52|5.279|model
1633.52|7.72|itself uh is it you know more depths
1637.799|5.36|more nodes more I see attention in an
1641.24|4.4|intuitive sense not
1643.159|4.64|in oh yeah okay yeah so the question is
1645.64|3.24|like what in the model makes uh you know
1647.799|5.721|the Lang which model better at
1648.88|7.84|memorizing tail knowledge or at uh um at
1653.52|4.56|doing math problems um yeah I think it's
1656.72|4.0|definitely related to the size of the
1658.08|4.4|language model so uh yeah if you have
1660.72|4.079|like more layers you could encode
1662.48|4.64|probably more complex like function
1664.799|5.6|within that um and then I guess if you
1667.12|6.64|have like more breath you could probably
1670.399|5.4|encode like more facts about the world
1673.76|3.799|um and then like if you want to repeat a
1675.799|4.321|fact or like retrieve something it
1677.559|2.561|probably be easier
1680.36|3.039|get one more in person and then we'll
1681.96|4.719|move
1683.399|5.361|this hi so when you were studying the
1686.679|5.321|200ish problems in the big bench you
1688.76|4.759|noticed that 22% were flat but there's a
1692.0|3.2|possibility that if you had increased
1693.519|2.801|the computer even further it might have
1695.2|2.88|those might have turned out to be
1696.32|3.52|emergent so my question to you is that
1698.08|3.839|when you were looking at the 33% that
1699.84|3.6|turned out to be emergent did you notice
1701.919|3.081|anything about the loss in the flat
1703.44|2.68|portion that suggested that they would
1705.0|3.919|eventually become
1706.12|5.52|emergent um oh yeah
1708.919|4.24|um I didn't notice anything uh oh sorry
1711.64|3.879|let me repeat the question uh the
1713.159|5.0|question is like uh when I looked at all
1715.519|4.681|the emergent tasks was there anything
1718.159|3.961|that I noticed uh before the emergence
1720.2|3.959|point in the loss that would have like
1722.12|4.32|hinted that it it would become emergent
1724.159|4.4|later um to me it's kind of tough like
1726.44|4.2|we have a few plots of this like you can
1728.559|4.12|look at the loss and it like kind of
1730.64|3.48|gets better and then suddenly it spikes
1732.679|3.36|and there's like no way to predict it
1734.12|3.399|but also you don't have like perfect
1736.039|3.0|data cuz like you might not have like
1737.519|2.441|all the in media points for a given
1739.039|3.401|model
1739.96|4.079|size yeah great
1742.44|4.92|question
1744.039|6.201|um yeah we can move to
1747.36|4.88|one we have a few online question online
1750.24|3.559|oh okay yeah yeah um we just have a few
1752.24|4.08|questions from people who are joining on
1753.799|4.12|Zoom um the first one is what do you
1756.32|3.479|think are the biggest bottlenecks for
1757.919|4.281|current large language models is it the
1759.799|3.72|quality of data the amount of compute or
1762.2|4.24|something
1763.519|7.361|else um yeah great question I guess like
1766.44|7.76|if you go back to the uh like uh scaling
1770.88|5.48|laws Paradigm um what it says is that uh
1774.2|4.359|if you increase the the size of the data
1776.36|4.159|in the size of the model um then you'd
1778.559|3.761|expect to get a lot better performance
1780.519|4.081|and I think yeah we'll probably try to
1782.32|4.599|keep increasing those things gotcha and
1784.6|4.319|then the last one um what are your
1786.919|4.12|thoughts on the paper if you've read it
1788.919|4.961|um are emergent abilities of language
1791.039|6.201|large language models a mirage oh yeah I
1793.88|4.799|always get this question um I guess uh I
1797.24|4.96|would encourage you to read the paper
1798.679|5.401|and and decide for yourself but like um
1802.2|3.719|yeah like I guess what the paper says is
1804.08|4.76|like if you change the metric a bit it
1805.919|5.041|looks different um but I would say uh at
1808.84|4.16|the end of the day like um I think the
1810.96|4.199|language model abilities are real and if
1813.0|5.919|you think like yeah I guess I don't
1815.159|6.76|think that's a mirage so
1818.919|3.0|yeah
1824.279|4.24|yeah all right so thanks Jason for the
1827.039|3.841|very insightful talk
1828.519|4.361|and now we have uh kyang Wan um give a
1830.88|4.88|talk so he's currently a research
1832.88|5.32|scientist at um on the open AI Chad gbt
1835.76|5.399|team um he has worked on various aspects
1838.2|5.04|of large language models um things like
1841.159|3.52|pre-training instruction fine-tuning
1843.24|4.72|reinforcement learning with human
1844.679|5.161|feedback uh reasoning um and so forth
1847.96|4.68|and some of his notable Works include um
1849.84|5.88|the scaling flan paper such as flan T5
1852.64|4.84|as well as flan pal and t5x the training
1855.72|4.559|framework used to train the Palm
1857.48|5.079|language model and before open AI um he
1860.279|5.321|was at Google brain and um he received
1862.559|5.371|his PhD from MIT um so give a hand for
1865.6|5.55|um H
1867.93|3.22|[Applause]
1878.12|5.0|one all right my name isan and really
1880.919|4.88|happy to be here today and this week I
1883.12|3.559|was thinking about by the way it's mic
1885.799|3.84|working
1886.679|5.761|fine yeah yeah um so this week I thought
1889.639|4.721|about okay I'm giving a lecture on
1892.44|4.8|Transformers at Stanford what should I
1894.36|5.679|talk about and I thought okay some of
1897.24|5.24|you in this room and in in Zoom will
1900.039|3.64|actually go shape the future of AI so
1902.48|3.079|maybe I should talk about that it's a
1903.679|4.72|really important goal and ambitious and
1905.559|4.761|we really have to get it right so that
1908.399|4.321|could be a good topic to think about and
1910.32|5.199|when we talk about something into the
1912.72|5.439|future the best place to get an advice
1915.519|4.481|is to look into the history in
1918.159|4.88|particular we'll look at the early
1920.0|5.559|history of Transformer and try to learn
1923.039|6.401|many lessons from there and the goal
1925.559|6.12|will be to develop a unified perspective
1929.44|5.88|in uh with which we can look into many
1931.679|6.36|seemingly disjoint events and and from
1935.32|5.16|that we can probably uh hope to project
1938.039|6.161|into the future what might be coming and
1940.48|5.12|so um that will be the goal of this
1944.2|3.28|lecture and we'll look at some of the
1945.6|3.439|architectures of the Transformers so
1947.48|5.799|let's get
1949.039|6.12|started everyone I see uh it's saying AI
1953.279|4.201|is so advancing so fast that it's so
1955.159|4.12|hard to keep up and doesn't matter if
1957.48|3.36|you have like years of experience
1959.279|3.561|there's so many things are coming out
1960.84|4.52|every week that it's just hard to keep
1962.84|5.12|up and I do see many people spend a lot
1965.36|5.279|of time and energy catching up with this
1967.96|4.959|latest development the The Cutting Edge
1970.639|4.081|and the the the newest thing and then
1972.919|5.72|not enough attention goes into old
1974.72|6.799|things because they become um deprecated
1978.639|4.721|and no longer relevant but I think it's
1981.519|4.361|important actually to look into that
1983.36|4.84|because we really need to when things
1985.88|4.279|are moving so fast beyond our ability to
1988.2|4.439|catch up what we need to do is study the
1990.159|5.201|change itself and that means we can look
1992.639|4.961|back at the previous things and then
1995.36|4.48|look at the current thing and try to map
1997.6|4.559|how we got here and from which we can
1999.84|6.92|look into what where we are heading
2002.159|6.201|towards so what does it mean to study
2006.76|4.24|the change itself
2008.36|4.52|first um we need to identify the
2011.0|4.36|dominant driving forces behind the
2012.88|5.56|change so here dominant is an important
2015.36|5.279|word because typically a change has many
2018.44|3.4|many driving forces and we only care
2020.639|2.961|about the dominant one because we're not
2021.84|4.319|trying to get really accurate you just
2023.6|4.28|want to have the sense of directionality
2026.159|3.841|second we need to understand the driving
2027.88|5.279|force really well and then after that we
2030.0|4.679|can predict the future trajectory by I
2033.159|3.561|know rolling out the driving force and
2034.679|3.801|so on and you heard that right I
2036.72|3.4|mentioned about predicting the future
2038.48|4.28|this is a computer science class not
2040.12|4.519|like an astrology or something but we do
2042.76|4.72|I think it's actually not that
2044.639|5.0|impossible to predict some future
2047.48|5.08|trajectory of a very narrow scientific
2049.639|6.76|domain and that um endeaver is really
2052.56|5.88|useful uh to do because uh you let's say
2056.399|5.161|you you do all these and then make your
2058.44|5.32|prediction accuracy to from 1% to 10%
2061.56|4.48|and then you'll make say 100 predictions
2063.76|4.04|10 of them will be correct say one of
2066.04|3.839|them will be really really correct
2067.8|4.2|meaning it will have an outside impact
2069.879|6.04|that outweighs everything and I think
2072.0|6.639|that um is kind of how uh many I've seen
2075.919|7.16|M General thing in life that you really
2078.639|7.841|have to be right a few times so why um
2083.079|5.32|so so if we think about why um
2086.48|3.76|predicting the future is difficult or
2088.399|4.921|maybe even think about the extreme case
2090.24|5.04|where we can all do the prediction with
2093.32|4.44|perfect accuracy almost perfect accuracy
2095.28|5.319|so here I'm going to do a very simple
2097.76|6.24|experiment of dropping this pen and
2100.599|5.441|follow this uh same three-step process
2104.0|3.88|so we're going to identify the driving
2106.04|3.24|dominant driving force first of all what
2107.88|4.08|what are the driving forces acting on
2109.28|5.76|this pen gravity downwards and is that
2111.96|5.52|all we we also have like a say um air
2115.04|4.6|friction right going if I drop it and
2117.48|4.92|that will cause What's called the drag
2119.64|5.04|force acting upwards and actually
2122.4|4.64|depending on how I drop this the
2124.68|4.439|orientation the the aerodynamic
2127.04|4.36|interaction will be so complicated that
2129.119|4.121|we don't currently have any analytical
2131.4|4.12|way of modeling that we can do it with
2133.24|4.839|the CFT the computational fluid dynamics
2135.52|4.24|but it will be non-trivial so so we can
2138.079|3.241|neglect that this is Happy enough that
2139.76|4.44|gravity is probably the only dominant
2141.32|4.72|Force we simpli simplify the problem
2144.2|4.24|second we do we understand this dominant
2146.04|4.48|driving force which is gravity and we do
2148.44|4.32|because we have this Newtonian mechanics
2150.52|4.04|which provides reasonably good model and
2152.76|4.28|then with that we can predict the future
2154.56|5.279|trajectory of this pen and if you
2157.04|5.319|remember from the this um Dynamics class
2159.839|4.401|if we have this initial velocity is zero
2162.359|4.0|I'm not going to put any velocity and
2164.24|4.879|then let's say position is zero here and
2166.359|6.201|then uh 1 12 GT Square will give a
2169.119|6.24|precise um trajectory of this pen as I
2172.56|4.88|Dro this so if there is a driving force
2175.359|4.041|single driving force that we really
2177.44|5.36|understand it's actually possible to
2179.4|6.16|predict what's going to happen so then
2182.8|4.0|why do we really um fear about
2185.56|3.799|predicting the future in the most
2186.8|5.559|General sense and I argue that among
2189.359|4.561|many reasons the number of driving force
2192.359|3.801|the sheer number of dominant driving
2193.92|5.28|forces acting on the general um
2196.16|5.28|prediction is so complicated and their
2199.2|4.56|interaction creates a complexity that we
2201.44|4.24|cannot predict the most General sense so
2203.76|4.44|here's my cartoon way of thinking about
2205.68|4.52|the prediction of future x- axis we have
2208.2|4.2|a number of dominant driving forces Y
2210.2|4.04|axis we have a prediction difficulty so
2212.4|4.4|on the left hand side we have a dropping
2214.24|3.839|of pen it's a very simple case we it's a
2216.8|5.2|difficulty is very small you just need
2218.079|7.76|to learn um physics and then as you add
2222.0|6.079|more stuff it just becomes impossible so
2225.839|5.401|how does this fit into the AI research
2228.079|5.24|and you might think okay I see all the
2231.24|4.56|time things are coming in we are
2233.319|4.321|bombarded by new things and some people
2235.8|4.36|will come up with the new agent new
2237.64|5.4|modality new MML score whatever that we
2240.16|4.439|just see so many things it just um I'm
2243.04|3.92|not even able to catch up with the
2244.599|3.921|latest thing how can I even hope to
2246.96|3.76|predict the future future of the AI
2248.52|4.92|research but I I argue that it's
2250.72|5.24|actually simpler because there is a
2253.44|5.2|dominant driving force that is governing
2255.96|5.28|a lot if any if not all of the AI
2258.64|4.959|research and because of that I would
2261.24|4.359|like to point out that it should it's
2263.599|5.24|actually closer to the left than to the
2265.599|4.401|right uh than we actually may perceive
2268.839|4.081|um
2270.0|5.52|so what is that driving force oh maybe
2272.92|5.72|before that I would like to caveat that
2275.52|5.2|uh when I do this kind of talk I would
2278.64|4.199|like to not focus too much on the
2280.72|4.72|technical stuff which you can probably
2282.839|5.52|do better in your own time but rather I
2285.44|5.8|want to uh share how I think and for
2288.359|5.24|that I want to share how my opinion as
2291.24|4.96|is and so it will be very strongly
2293.599|4.76|opinion and I'm by no means I'm saying
2296.2|4.68|this is uh correct or not just wanted to
2298.359|4.401|share my perspective so coming back to
2300.88|5.0|this driving force for AI what is that
2302.76|6.359|dominant driving force and here's a plot
2305.88|6.0|from Rich suton and on the y- axis we
2309.119|6.2|have the uh calculations flopped if you
2311.88|5.92|pay $100 and how much computing power do
2315.319|5.76|you get and it's in log scale and then
2317.8|5.72|xxs we have a a time of of more more
2321.079|5.601|than 100 years so this is actually more
2323.52|6.48|than like exponential and I don't know
2326.68|6.56|any Trend that is as strong and as long
2330.0|5.8|lasting as this one so this whenever I
2333.24|4.4|see this kind of thing I should say okay
2335.8|4.72|I should not compete with this and
2337.64|7.479|better I should try to leverage as much
2340.52|7.2|as possible and um so what this means is
2345.119|4.401|you get 10x more compute every five
2347.72|5.92|years if you spend the same amount of
2349.52|5.96|dollar and so in other words you get the
2353.64|4.84|cost of compute is going down
2355.48|5.96|exponentially and this and Associated
2358.48|5.32|scaling is really dominating the AI
2361.44|4.32|research and that is somewhat hard to
2363.8|4.64|take but that is I think really
2365.76|5.12|important to uh think about so coming
2368.44|4.52|back to this AI research how is how is
2370.88|4.92|this U exponentially cheaper compute
2372.96|5.08|Drive the AI research let's think about
2375.8|4.36|the job of the AI researchers it is to
2378.04|5.559|teach machines how to think in a very
2380.16|5.76|general sense and one somewhat uh you
2383.599|5.321|know unfortunately common approach is we
2385.92|7.679|think about how we teach machine how we
2388.92|7.36|think we think so meaning we model how
2393.599|4.281|we think and then try to incorporate
2396.28|4.4|that into some kind of mathematical
2397.88|4.88|model teach that and now the question is
2400.68|4.28|do we understand how we think at the
2402.76|4.24|very low level I don't think we do I
2404.96|3.879|don't I have no idea what's going on so
2407.0|3.2|it's fundamentally flawed in the sense
2408.839|4.441|that we try to model something that we
2410.2|4.8|have no idea about and what happens if
2413.28|3.799|we go with this kind of approaches that
2415.0|4.72|it poses a structure that serves as a
2417.079|4.52|shortcut in the short term and so you
2419.72|4.119|can maybe get a paper or something but
2421.599|3.841|then it becomes a bottleneck when when
2423.839|4.561|because you it we don't know how this
2425.44|5.44|will um limit further they're scaling up
2428.4|5.24|um more fundamentally what this is doing
2430.88|5.0|is we are limiting the degree of Freedom
2433.64|4.56|we are giving to the machines and that
2435.88|7.12|will backfire at some point and this has
2438.2|7.879|been uh going on for decades and bitter
2443.0|5.92|lesson is I think the single most
2446.079|5.681|important piece of writing in Ai and it
2448.92|5.56|says uh this is my Waring by the way SE
2451.76|5.52|past 70 years of entire AI research can
2454.48|4.76|be summarized into developing Pro
2457.28|4.16|progressively more General method with
2459.24|4.44|weaker modeling assumptions or inductive
2461.44|4.56|biases and add more data and compute in
2463.68|5.679|other words scale up and that has been
2466.0|5.92|the recipe of entire AI research not
2469.359|5.921|fancy things and if you think about this
2471.92|6.24|the models of 202,000 is a lot more
2475.28|5.64|difficult than what we use now and so
2478.16|6.48|it's much easier to get into AI nowadays
2480.92|5.84|um from technical perspective so this uh
2484.64|3.24|is I think the really the key
2486.76|3.24|information
2487.88|4.439|we have this compute cost is going down
2490.0|4.0|exponentially and it's getting cheaper
2492.319|3.841|faster than we're becoming a better
2494.0|3.96|researcher so don't compete with that
2496.16|4.64|and just try to leverage that as much as
2497.96|6.72|possible and that is the driving force
2500.8|5.48|that I wanted to uh identify and I'm not
2504.68|3.12|saying this is the only driving force
2506.28|3.039|but this is the dominant driving force
2507.8|3.799|so we can probably neglect the other
2509.319|4.681|ones so here's a graphical version of
2511.599|4.081|that xaxis we have a compute Y axis we
2514.0|3.839|have a performance of some kind let's
2515.68|4.8|think about some general intelligence
2517.839|4.881|and let's look at two different methods
2520.48|4.28|one with more structure more modeling
2522.72|3.72|assumption fancier math whatever and
2524.76|4.72|then the other one is a less structure
2526.44|4.72|what you see is typically you start with
2529.48|3.879|a better performance uh when you have a
2531.16|3.6|low compute regime and then but it
2533.359|3.441|plateaus because of some kind of
2534.76|3.599|structure backfiring and then with the
2536.8|3.319|less structure because we give a lot
2538.359|3.801|more freedom to the model it doesn't
2540.119|4.44|work at the beginning but then as we add
2542.16|4.32|more comput it starts working and then
2544.559|5.601|it gets better we call this more
2546.48|6.359|scalable method so does that mean we
2550.16|4.919|should just go with the least structure
2552.839|4.201|most freedom to the model uh possible
2555.079|4.28|way from the get-go and the answer is
2557.04|5.12|obviously no let's think about even less
2559.359|5.401|structure case this red one here is um
2562.16|6.08|it will pick up a lot later um and
2564.76|5.4|requires a lot more compute so it really
2568.24|4.24|depends on where we are we cannot
2570.16|4.8|indefinitely wait for the most General
2572.48|4.359|case and so let's think about the case
2574.96|5.0|where our compute situation is at the
2576.839|5.121|starting line if we're here we should um
2579.96|4.0|choose this less structure one as
2581.96|3.08|opposed to this even less structure one
2583.96|3.56|because the other one doesn't really
2585.04|4.16|work and the the other one works but
2587.52|3.72|crucially we need to remember that we
2589.2|3.639|are adding some structure because we
2591.24|4.72|don't have compute so we need to remove
2592.839|5.161|that later and so the difference between
2595.96|4.32|these two method is the additional
2598.0|4.96|inductive biases or structure we impose
2600.28|6.16|someone impose uh that typically don't
2602.96|5.2|get removed so adding this uh what what
2606.44|4.52|that means is that that at the given
2608.16|4.6|level of compute data algorithmic
2610.96|4.56|development and architecture that we
2612.76|4.359|have there's like an optimal inductive
2615.52|4.319|bias or structure that we can add to the
2617.119|5.0|problem to make the progress and that
2619.839|3.921|has been really uh how we have made so
2622.119|3.48|much progress but these are like
2623.76|3.96|shortcuts that hinder further scaling
2625.599|4.121|later on so we have to remove them later
2627.72|5.24|on when we have more compute better
2629.72|6.32|algorithm or whatever and as a community
2632.96|5.0|we do adding structure very well and
2636.04|4.44|because there's an incentive structure
2637.96|4.8|of with like papers you add a nice one
2640.48|4.44|then you get a paper but removing that
2642.76|3.96|doesn't really get you much so that we
2644.92|5.159|don't really uh do that and I think we
2646.72|4.76|should do a lot more of those so maybe
2650.079|4.321|another implication of This Bitter
2651.48|5.16|lesson is that because of this what is
2654.4|5.64|better in the long term almost
2656.64|6.199|necessarily looks worse now and this is
2660.04|5.72|quite unique to AI research because the
2662.839|5.24|AI research of current um Paradigm is
2665.76|5.559|learning based method meaning that we
2668.079|5.681|are giving models Freedom the machines
2671.319|5.961|choose how they learn so because we need
2673.76|5.28|to give more freedom it gives uh it's a
2677.28|4.039|more chaotic at the beginning so it
2679.04|4.6|doesn't work but then when it start
2681.319|4.481|working we can put in more compute and
2683.64|5.04|then it can be better so it's really
2685.8|5.519|important to have this in mind so to
2688.68|4.879|summarize we have identified this
2691.319|4.361|dominant driving force behind the AI
2693.559|5.401|research and that is this exponentially
2695.68|5.879|cheaper compute and Associated scaling
2698.96|5.28|up now that we have identified if you
2701.559|4.76|remember back from my uh initial slides
2704.24|5.4|we the next step is to understand this
2706.319|5.24|driving force better and so that's we're
2709.64|4.8|going to spend uh most of the time doing
2711.559|5.161|that and for that we need to go back to
2714.44|4.919|some history of Transformer because this
2716.72|5.04|is a Transformers class and analyze key
2719.359|4.841|structures and decisions that were made
2721.76|4.599|by the uh researchers at the time and
2724.2|3.48|why they did that whether that was an
2726.359|4.521|optimal structure that could have been
2727.68|5.879|added at the time and why they might be
2730.88|3.719|irrelevant now and should we remove that
2733.559|3.52|and we'll go through some of the
2734.599|4.841|practices of this and hopefully this
2737.079|6.321|will give you some flavor of what um
2739.44|4.96|like scaling research looks like so now
2743.4|2.84|we'll go into a little bit of the
2744.4|4.24|technical stuff Tech uh Transformer
2746.24|4.879|architecture there are some variants um
2748.64|4.04|I'll talk about three of them first is
2751.119|3.361|the encoder decoder which is the
2752.68|3.439|original Transformer which has a little
2754.48|4.48|bit more structure second one is the
2756.119|5.881|encoder only which is popularized by
2758.96|5.84|Bert and then third one is um decoder
2762.0|5.16|only which you can think of as a current
2764.8|4.16|um like gpt3 or other language models
2767.16|4.24|this has a lot less structure than the
2768.96|4.76|encoder decoder so these are the three
2771.4|5.0|types we will go into detail second the
2773.72|4.48|encoder only is actually not that useful
2776.4|4.64|in the most General sense it still has
2778.2|4.639|some um place but we will so U just
2781.04|4.48|briefly go over that and then spend most
2782.839|4.361|of the time comparing one and three so
2785.52|5.16|one has more structure what's the
2787.2|4.76|implication of that and so on so first
2790.68|4.679|of all let's think about what a
2791.96|5.159|Transformer is just um uh at a very high
2795.359|3.561|level or first principles what is a
2797.119|4.561|Transformer is a sequence model and
2798.92|5.56|sequence model is a has an input of a
2801.68|5.679|sequence so sequence can be um sequence
2804.48|4.879|of elements can be words or images or
2807.359|3.521|whatever it's a very general Concept in
2809.359|3.72|this particular example I'll show you
2810.88|4.52|with the words sentence is a sequence of
2813.079|3.881|words and then we the first step is to
2815.4|5.36|tokenize it because we have to rep
2816.96|6.8|present this um word in computers which
2820.76|5.24|requires just some kind of a uh encoding
2823.76|4.44|scheme so we just do do it with the
2826.0|4.64|fixed number of integers then we have
2828.2|5.2|now sequence of integers and then the
2830.64|4.6|dominant Paradigm uh nowadays is to
2833.4|3.76|represent each sequence element as a
2835.24|4.2|vector dense Vector because we know how
2837.16|4.72|to multiply them well and then so we
2839.44|5.52|have a sequence of vectors um and
2841.88|5.88|finally this um sequence model will do
2844.96|5.119|the following we just want to model the
2847.76|5.16|interaction between sequence elements
2850.079|4.561|and we do that by let them take the dot
2852.92|3.76|product of each other and if the dot
2854.64|3.84|product is high we can say semantically
2856.68|3.76|they are more related than the do
2858.48|4.48|products that is low and that's kind of
2860.44|4.76|the sequence model and the Transformer
2862.96|5.399|is a particular type of sequence model
2865.2|6.8|that uses and what's called attention um
2868.359|5.921|to model this interaction so let's get
2872.0|3.88|into the details of this encoder decoder
2874.28|3.839|which was the original Transformer it's
2875.88|4.719|quite many many pieces so let's go into
2878.119|4.401|a little bit a piece at a time so
2880.599|4.041|starting with the encoder so here I'm
2882.52|4.72|going to show you an example of machine
2884.64|5.199|translation which used to be very uh
2887.24|4.359|cool thing and so you are you have an
2889.839|4.52|English sentence that is good and then
2891.599|5.281|we're going to translate into German so
2894.359|4.441|first thing is to uh encode this into a
2896.88|5.04|dense Vector so here I'm representing it
2898.8|5.24|with a um this like a vector of size
2901.92|4.12|three or something and then we have to
2904.04|5.24|let them take the dot product so this um
2906.04|6.2|you know lines represent which element
2909.28|5.0|can talk to which element other elements
2912.24|3.48|and here because it's an input we take
2914.28|3.319|what is called a bir directional
2915.72|4.04|attention so any token can talk to any
2917.599|4.801|other token and then we have this U um
2919.76|4.48|MLP or feed forward layer which is per
2922.4|4.36|token it doesn't have any interaction we
2924.24|5.16|just do some you know some some some
2926.76|5.28|multiplication just because we can do it
2929.4|4.719|and then that's one layer and we repeat
2932.04|4.44|that end times and that is the
2934.119|6.121|Transformer encoder and at the end what
2936.48|6.319|you get is the sequence of vectors each
2940.24|4.879|representing the sequence element in
2942.799|4.241|this case a word so that's the the
2945.119|4.801|output of this encoder now let's look at
2947.04|6.079|the decoder which is similarly shaped um
2949.92|6.32|St of layers so here we put in as an
2953.119|5.72|input um the uh what what the answer
2956.24|4.52|should be so here B is a beginning of
2958.839|2.96|sequence and then do is good I don't
2960.76|3.28|know how to pronounce it but that's the
2961.799|4.361|German translation of that is good and
2964.04|4.16|so we kind of go through the similar
2966.16|4.24|process here we have a caal self
2968.2|5.399|attention meaning that the tokens of
2970.4|5.36|time step T can only attend to T and
2973.599|4.76|before because when we start generating
2975.76|4.839|it we don't have the future tokens so we
2978.359|4.681|cannot when we train it we should limit
2980.599|5.0|that and and that way we this is done by
2983.04|3.4|like masking but uh just just different
2985.599|4.52|from the
2986.44|7.2|encoder so after this you can get um
2990.119|6.68|after again end layers you get this um
2993.64|4.4|sequence output and you have this the
2996.799|3.161|output is sequence so sequence to
2998.04|3.96|sequence mapping this is a general um
2999.96|4.04|encoder decoder architecture and when
3002.0|4.4|you get this end of sequence you stop
3004.0|4.359|generating it so this is the the overall
3006.4|4.8|picture now I'll point out some
3008.359|5.841|important uh attention patterns so we
3011.2|5.119|are translating um the into German what
3014.2|3.639|is in input to the encoder so there has
3016.319|3.641|to be some connection between the
3017.839|4.041|decoder and the encoder that is done by
3019.96|5.2|this cross attention mechanism shown in
3021.88|5.04|this red which is just that each Vector
3025.16|4.159|representation of each sequence in the
3026.92|4.72|output decoder should attend to some of
3029.319|4.961|them in the encoder and that is done in
3031.64|5.12|particular the design feature which is
3034.28|4.92|interesting is that all the layers in
3036.76|4.4|the decoder attend to the final layer
3039.2|6.359|output of the encoder I we'll come back
3041.16|7.04|to the implication of those design so um
3045.559|4.401|yep that's that and now move on to the
3048.2|3.32|second type of architecture which is
3049.96|4.44|encoder only we'll spend a little bit of
3051.52|5.799|time here so again we have to uh in we
3054.4|5.719|have the same input uh and and we go
3057.319|4.881|through similar uh structure and then
3060.119|3.921|the in this case the final output is a
3062.2|3.879|single Vector regardless of the length
3064.04|5.84|of the uh sequence we just get a single
3066.079|5.76|vector and and that is uh that represent
3069.88|3.919|the input sequence that's the dense uh
3071.839|4.321|Vector representation and then let's say
3073.799|4.121|we do some kind of a sentiment analysis
3076.16|4.6|we run through a Tas specific linear
3077.92|5.28|layer to map it to classification labels
3080.76|5.599|positive or negative probabilities here
3083.2|5.56|and that's required for for all these um
3086.359|5.401|test specific um cases and this is kind
3088.76|5.96|of popularized by Bert and what this
3091.76|5.799|means is that here at the time 2018 when
3094.72|4.96|bird came out uh we had a benchmark
3097.559|3.321|called glue which was a language
3099.68|3.24|understanding test you have a sequence
3100.88|4.6|in classification labels out for most
3102.92|4.84|cases this was how the field really
3105.48|4.599|Advanced at the time so when we care
3107.76|3.96|about such tasks then there's an
3110.079|3.28|incentive to think about simplifying the
3111.72|3.119|problem adding the structure to the
3113.359|3.361|problem so that we can make a progress
3114.839|3.201|so this the additional structure that
3116.72|3.0|was put into this particular
3118.04|5.759|architecture is that we're going to give
3119.72|6.16|up on the uh generation if we do that it
3123.799|3.8|becomes a lot simpler problem instead of
3125.88|4.04|sequence to sequence we're talking about
3127.599|5.281|sequence to classification labels and
3129.92|6.48|that's just so much easier and so um at
3132.88|5.88|some point 2018 2019 a lot of the papers
3136.4|4.0|or just research was like we sometimes
3138.76|4.76|call it birth Engineers little bit
3140.4|5.32|change of something get like 05% better
3143.52|4.52|on glue you get a paper and things like
3145.72|5.2|that it was like very chaotic era and
3148.04|5.64|and but but if we look at from this
3150.92|4.84|perspective we are putting the sequence
3153.68|5.159|structure of not generating the sequence
3155.76|5.2|that puts a lot of U performance win but
3158.839|3.201|in the long term it's not really useful
3160.96|4.04|so we're not going to look at this
3162.04|5.319|encoder only architecture going forward
3165.0|4.96|third architecture decoded only this one
3167.359|5.521|is um my favorite personally and it
3169.96|5.159|looks kind of uh daunting but uh because
3172.88|5.199|of this attention pattern but it
3175.119|5.081|actually is very simple so so here we
3178.079|5.561|only have a single stack and it can
3180.2|5.04|actually generate stuff and so there's
3183.64|3.32|misconception that some people think
3185.24|3.119|this decoder only architecture is used
3186.96|2.92|for language modeling next to comp
3188.359|3.24|prediction so it cannot be used for
3189.88|4.08|supervised learning but here we can
3191.599|4.641|actually do it the trick is to have this
3193.96|4.48|input that is good concatenated with the
3196.24|4.48|Target and if you do that then it just
3198.44|4.48|becomes um simple the sequence in
3200.72|4.359|sequence out so what what we do is um
3202.92|4.6|the self attention mechanism here is
3205.079|4.361|actually handling both the cross
3207.52|4.44|attention between Target and the input
3209.44|4.48|and self attention sequence uh learning
3211.96|5.159|within each so that's the causal
3213.92|5.08|attention and then the the yeah as I
3217.119|4.0|mentioned the output is a sequence and
3219.0|4.839|then the key design features are self
3221.119|4.801|attention is so serving both rules and
3223.839|3.921|we are in some sense sharing the
3225.92|3.96|parameters between input and Target so
3227.76|4.24|same set of parameters are applied to
3229.88|5.04|both input and the target sequences so
3232.0|5.2|this is the decoder only now we will go
3234.92|4.679|into the comparison so
3237.2|3.52|I think there many um like they look
3239.599|3.161|very different at least on the
3240.72|6.0|schematics so how different are they
3242.76|5.88|actually and to I I argue that they're
3246.72|3.839|actually quite similar and so to
3248.64|3.84|illustrate that we're going to transform
3250.559|3.961|starting from this encoder decoder which
3252.48|4.76|has more structures built in and then
3254.52|4.559|into um the decoder only architecture
3257.24|3.879|and see what what are some of the
3259.079|3.601|differences and then interpret those
3261.119|3.72|differences those additional structures
3262.68|3.879|are they relevant nowadays now that we
3264.839|5.441|have more compute better algorithms and
3266.559|6.121|so on so let's have this table four
3270.28|5.24|differences we'll see each of them and
3272.68|4.439|then as we go through we'll um populate
3275.52|4.2|the this table so let's first look at
3277.119|4.96|this additional cross tension um what
3279.72|3.879|that means is that this on the left is
3282.079|3.121|an incoder decoder which has this
3283.599|3.361|additional red block the cross the
3285.2|4.56|tension compared to the simpler one that
3286.96|4.879|doesn't have that so we want to make it
3289.76|4.559|make the left closer to the right so
3291.839|4.52|that means we need to either get rid of
3294.319|4.0|it or something and a tension me
3296.359|4.361|mechanism has kind of the four
3298.319|3.8|projection matrices and so self
3300.72|2.76|attention and cross attention actually
3302.119|3.081|have the same number of parameters same
3303.48|3.44|shape so we can just share them so
3305.2|3.399|that's the first step share both of
3306.92|4.439|these and then it becomes mostly the
3308.599|4.841|same uh mechanism and then so that's the
3311.359|4.401|first difference separate curs attention
3313.44|3.72|or self attention serving both roles
3315.76|4.44|second difference is the parameter
3317.16|5.48|sharing so what that means is that
3320.2|4.04|between the input and the target encoder
3322.64|4.56|decoder architecture uses a separate
3324.24|4.599|parameters and decoder only only has a
3327.2|3.76|single stack so it uses the share
3328.839|4.28|parameter so if we want to make the left
3330.96|4.159|close to right we want to share the
3333.119|4.281|encoder parameters so let's do that I
3335.119|4.401|just colored this so now they share the
3337.4|4.679|parameters third difference is the
3339.52|4.559|target to input attention pattern so we
3342.079|4.24|need to connect the target to the input
3344.079|4.24|and how does that how is it done in the
3346.319|4.76|encoder decoder case we had this cross
3348.319|5.361|attention and then in the decoder only
3351.079|5.04|it's a per uh the self tension doing
3353.68|4.24|everything what the difference is that
3356.119|4.881|um we have this
3357.92|5.639|um every layer of the decoder attending
3361.0|4.4|to the final layer output of the encoder
3363.559|4.401|whereas if you think about this decoder
3365.4|6.48|is actually per layer within layer when
3367.96|6.24|we are decoding the say word dos we are
3371.88|4.919|looking at the same layer representation
3374.2|4.24|of the encoder and and that's within
3376.799|3.081|layer and I think this is the design
3378.44|3.919|feature so if you want to make this
3379.88|5.52|close to that we have to bring back this
3382.359|5.24|attention to each layer so now layer one
3385.4|5.56|will be attending to to layer one of
3387.599|5.081|this and that's the then finally the
3390.96|3.359|last uh difference is the input
3392.68|4.359|attention I mentioned about this by
3394.319|5.601|directional tension and because we have
3397.039|4.8|this decoder only typically with the um
3399.92|4.56|uni directional tension we need to make
3401.839|4.681|them matching so that's the we can just
3404.48|5.8|get rid of it I just got rid of the the
3406.52|5.64|some of the arrows so then at this point
3410.28|3.839|these two architectures are almost
3412.16|4.12|identical um a little bit of difference
3414.119|4.361|in the cross tension but same number of
3416.28|4.0|parameters and if you have in deep
3418.48|3.359|learning if you just train this these
3420.28|3.36|two architecture in the same task same
3421.839|3.641|data I think you will get pretty much
3423.64|4.76|within the noise probably closer than if
3425.48|5.079|you train the same thing twice so um I
3428.4|4.959|would say they're identical and so these
3430.559|5.081|are the main differences now look at how
3433.359|5.76|what are the additional structures what
3435.64|5.76|they mean what they mean it means so
3439.119|4.96|yeah that's the populated table now and
3441.4|3.84|then so we can say that encoder decoder
3444.079|4.681|compared to the decoder only
3445.24|6.24|architecture has has these additional um
3448.76|4.88|structures inductive biases built in so
3451.48|5.48|let's go into each of them the first one
3453.64|5.36|is the what what encoder decoder tries
3456.96|3.72|add it as a structure is that input and
3459.0|4.4|the target sequences are sufficiently
3460.68|4.6|different that we it'll be useful to use
3463.4|5.12|a separate parameters that's the
3465.28|5.16|Assumption and so why is that useful
3468.52|4.36|when that when can that assumption be
3470.44|4.72|useful and one example is machine
3472.88|3.76|translation uh back when the transform
3475.16|3.84|was introduced in 2017
3476.64|4.28|translation was really popular task and
3479.0|4.64|it was difficult considered difficult
3480.92|4.399|and because it's a sequence to sequence
3483.64|3.52|and you can actually have a blue score
3485.319|3.76|which is puristic based method that can
3487.16|5.399|give you a single number and then people
3489.079|5.601|can optimize that so what what that in
3492.559|3.921|that task we have this input and Target
3494.68|3.679|in completely different languages so if
3496.48|4.4|you if the goal is to learn translation
3498.359|4.161|only then it kind of makes sense to have
3500.88|3.64|okay this parameter in the encoder will
3502.52|3.44|take care of the English and this
3504.52|4.36|parameter in the decoder will take care
3505.96|5.32|of the the German that seems natural and
3508.88|4.959|and what about now modern language
3511.28|4.48|models is about learning knowledge and
3513.839|3.561|it's not just about translation or not
3515.76|4.2|even about language language just comes
3517.4|5.52|up as a byproduct of doing this next
3519.96|5.44|token prediction and translation as well
3522.92|5.04|so does it make sense to have a separate
3525.4|5.76|parameter for um this kind of situation
3527.96|5.639|now like we have some knowledge in
3531.16|4.24|German s some knowledge in English and
3533.599|3.401|we if anything you want to combine them
3535.4|3.399|and have if we represent them in a
3537.0|4.68|separate parameters I don't think that's
3538.799|6.04|natural so I would say with this U much
3541.68|5.72|more General larger models that can do a
3544.839|5.48|lot of things this assumption seems very
3547.4|5.0|unnatural to me second example is a
3550.319|4.601|little bit more modern uh two years ago
3552.4|4.679|when I was at Google uh and with Jason
3554.92|5.159|we uh did this instruction fine tuning
3557.079|4.841|work and what this is uh is you take the
3560.079|5.081|pre-rain model and then just fine tune
3561.92|5.28|on academic data set and and so that it
3565.16|4.439|can understand the language instruction
3567.2|4.76|so the detail doesn't matter but here
3569.599|4.801|let's think about the the performance
3571.96|4.879|gain by doing this fine tuning on two
3574.4|5.56|different architectures we tried so
3576.839|5.081|first five is the flant T5 which is T5
3579.96|4.879|base which is inod decod architecture
3581.92|6.679|last one uh the letter five decoder only
3584.839|6.921|architecture based on Palm so we spent
3588.599|4.801|99% of the time on pal optimizing a lot
3591.76|4.44|of these and then at the end we just
3593.4|4.439|spend like 3 days on T5 but the the the
3596.2|3.76|performance gain was a lot higher on
3597.839|4.361|this and I was really confused about
3599.96|4.68|this and in a very good way and after
3602.2|3.839|the paper was published I wanted to like
3604.64|3.0|think a little bit deeper into why this
3606.039|5.32|might be the case
3607.64|6.04|so uh the my hypothesis is that it's
3611.359|6.281|about the length so academic data sets
3613.68|5.96|we use we use like 1832 tasks and here
3617.64|3.959|they have this very distinctive
3619.64|4.159|characteristic where we have a long
3621.599|3.921|input long in order to make the task
3623.799|3.841|more difficult but then we cannot make
3625.52|4.48|the target long because if we do there's
3627.64|4.199|no way to grade it so there's
3630.0|4.24|fundamental challenge of that so what
3631.839|4.801|happens is you have a long text of input
3634.24|4.04|and then short text of the Target and
3636.64|4.399|and so this is kind of the length
3638.28|6.519|distribution of what it went into the FL
3641.039|6.32|uh fine tuning so then you see this um
3644.799|4.841|you have a very different sequence going
3647.359|3.76|into the encoder as an input and a very
3649.64|4.52|different type of sequence going into
3651.119|4.44|the target so now this encoder decoder
3654.16|3.879|architecture has an assumption that they
3655.559|5.081|will be very different that structure
3658.039|5.721|really shines because of this it was a
3660.64|6.56|kind of an accident but that was I think
3663.76|5.079|why this really architecture was um just
3667.2|4.76|suitable for fine-tuning with the
3668.839|5.921|academic data sets what about now do we
3671.96|4.72|care about this kind of a assumption and
3674.76|4.76|if you think about the general use cases
3676.68|4.879|of language models nowadays if anything
3679.52|5.2|the more interesting cases involve
3681.559|5.641|longer generation longer Target uh just
3684.72|4.48|because we cannot great them doesn't
3687.2|3.119|mean that we are not interested in them
3689.2|3.24|actually if anything we are more
3690.319|4.48|interested in that so now we have this
3692.44|4.639|like longer Target situation so this
3694.799|4.921|separate sequence length um parameter
3697.079|4.681|doesn't seem to make much sense and
3699.72|4.399|moreover we think about this chat
3701.76|5.12|application like chat GPT we do multi-
3704.119|5.041|turn conversation and then so what is a
3706.88|4.8|target of this turn becomes the input of
3709.16|5.0|the next turn and then my question is
3711.68|5.56|does that make sense to even think about
3714.16|4.919|a um different parameter if next turn
3717.24|5.039|it's going to be the same
3719.079|5.48|thing so um that was the first inductive
3722.279|4.241|bi we just uh mentioned and then the
3724.559|4.56|second structure is that Target element
3726.52|4.319|can only attend to the full fully
3729.119|3.761|encoded ones the final output of the
3730.839|4.401|encoder n look at this additional
3732.88|5.679|structure what that means so as I
3735.24|7.24|mentioned we have this U very top layer
3738.559|5.72|attending to it and so in deep neuronet
3742.48|4.04|typically we see that the bottom layers
3744.279|4.401|and the top layers incode information
3746.52|4.12|at a very different level uh meaning
3748.68|3.919|that for example in computer vision
3750.64|4.36|lower layer bottom layers encode
3752.599|4.52|something like edges top layers higher
3755.0|4.319|levels combining the features something
3757.119|4.641|like cat face and so we call this deep
3759.319|5.641|learning a hierarchical representation
3761.76|7.039|learning method and so now the question
3764.96|6.04|is if decoder layer one attends to
3768.799|4.48|encoder final layer which probably has a
3771.0|3.72|very different level of information is
3773.279|3.481|that some kind of an information
3774.72|3.92|bottleneck which actually
3776.76|5.079|um motivated the original attention
3778.64|4.84|mechanism and in practice I would say in
3781.839|3.361|my experience doesn't really make any
3783.48|4.68|difference and that's because my
3785.2|5.56|experience was limited to say 25 24
3788.16|5.0|layers of encoder of T5 so layer one
3790.76|5.079|attended to 24 probably fine but what if
3793.16|5.439|we have 10x or THX more layers would
3795.839|4.401|that be problematic I'm not really
3798.599|5.561|comfortable with that so I think this is
3800.24|7.44|also unnecessary um uh design that maybe
3804.16|5.56|we need to revisit final structure we're
3807.68|3.96|going to talk about is the when we do
3809.72|3.76|this there's like a bidirectional thing
3811.64|4.76|in the encoder decoder Let's uh think
3813.48|5.559|about that so yeah by directional input
3816.4|6.6|attention is that really necessary so
3819.039|6.641|when we um in had this spt B invert
3823.0|4.039|stand for bidirectional 2018 when we
3825.68|3.96|were solving that question answering
3827.039|4.921|Squad actually was very difficult task
3829.64|3.919|so if you have any additional trick it
3831.96|4.44|can make a huge difference P
3833.559|4.76|directionality was really uh useful like
3836.4|4.159|I think maybe boosting up the squat
3838.319|4.881|score by like 20 so it was really huge
3840.559|4.961|thing but at scale I don't think this
3843.2|5.879|matters at much this is my highly
3845.52|5.4|anecdotal experience so we did in flon 2
3849.079|4.48|we tried both bidirectional and
3850.92|5.08|unidirectional funing didn't really make
3853.559|4.921|much difference so but but I want to
3856.0|4.64|point out this bidirectionality actually
3858.48|5.4|bring in an engineering challenge for
3860.64|5.24|modern multi-turn chat application so at
3863.88|4.32|every turn the new input has to to be
3865.88|4.08|encoded again and for Union directional
3868.2|3.32|tension is uh much much better so here
3869.96|4.399|is what I mean by that so let's think
3871.52|5.319|about this um more modern conversation
3874.359|5.2|between user and uh assistant how are
3876.839|5.121|you bad and why and so here if we think
3879.559|4.921|about the bir directional case we will
3881.96|4.48|and when we generate bad we need to
3884.48|4.92|encode this input with the B directional
3886.44|5.2|thing which is fine and then um after
3889.4|5.919|the bad is generated when we're trying
3891.64|6.32|to generate why we'll need to encode how
3895.319|5.881|again because how can tend to bad so we
3897.96|5.359|need to do everything from scratch again
3901.2|4.8|in contrast if we do uni directional one
3903.319|5.081|we can do uh much much better because
3906.0|4.279|now when we are trying to generate why
3908.4|5.159|we don't have to redo how because we
3910.279|5.04|cannot uh attend to the ne future tokens
3913.559|3.8|so we don't have to do anything so if
3915.319|3.601|you see the difference this part can be
3917.359|4.76|cached and then this part is the only
3918.92|4.879|thing that can has to be encoded again
3922.119|4.0|so this kind of makes a big difference
3923.799|5.04|when we think about multi multi turns
3926.119|6.041|going in so I would say by directional
3928.839|5.681|tension did well in 2018 which is mostly
3932.16|4.04|sold by scale and now because of this
3934.52|5.92|engineering challenge we don't really
3936.2|6.04|need that so to conclude we have looked
3940.44|4.32|into this driving force Domino driving
3942.24|4.839|force covering this AI research and that
3944.76|5.839|was this exponentially cheaper compute
3947.079|5.401|and Associated scaling effort and so to
3950.599|3.76|understand this driving force we analyze
3952.48|3.599|some of the additional structures added
3954.359|4.601|to the encoder decoder compared to the
3956.079|4.52|decoder only and then thought about how
3958.96|5.68|what that means as a from the
3960.599|5.96|perspective of scaling and I wanted to
3964.64|4.0|just conclude with this remark so we
3966.559|4.201|have looked at these kind of analysis
3968.64|4.52|which are all one can say this is just
3970.76|4.92|historical um artifacts and doesn't
3973.16|4.84|matter but if you do many of these now
3975.68|4.439|you look at the current events you can
3978.0|5.44|hopefully think about those in a more
3980.119|5.72|unified Manner and then um see okay what
3983.44|4.879|assumptions in my problem that I need to
3985.839|4.601|revisit and are they relevant and if not
3988.319|3.841|why and you have an answer to it is can
3990.44|4.8|we do it with a more General thing and
3992.16|5.08|scale up and so I hope you can go back
3995.24|4.079|and really uh think about these problems
3997.24|5.079|and together we can really shape the
3999.319|6.48|future of AI in a really nice way so
4002.319|3.48|that's it thanks
4022.2|7.079|hi thank you for the talk um so about
4024.96|6.04|the uh mix of expert uh structure if um
4029.279|4.401|you know you're say what you're saying
4031.0|6.039|is correct that uh how long do you think
4033.68|7.08|the mix of uh experts going to stay for
4037.039|6.201|the for the new large language models uh
4040.76|5.0|so so one thing I have to apologize is
4043.24|4.72|the architecture is kind of a um um
4045.76|4.16|thing that I'm not really um comfortable
4047.96|3.48|sharing a lot that's why I'm like you
4049.92|4.76|know limiting a little bit to the the
4051.44|4.52|future so yeah if you yeah I'll probably
4054.68|4.919|just
4055.96|5.8|uh skip that but I would say that seems
4059.599|2.161|quite
4065.16|4.84|General um so some of the changes that
4068.039|3.841|you described between incoder decoder
4070.0|3.88|versus decoder only like the parameter
4071.88|5.159|sharing and the bir directional
4073.88|5.76|attention can they not be interpreted as
4077.039|5.161|less structure or sorry more structure
4079.64|5.24|or less freedom for the model to
4082.2|6.52|learn yeah I think one one can do that
4084.88|6.199|but I think uh somewhat subjective but I
4088.72|6.119|think it's a simpler structure that the
4091.079|6.321|model kind of um
4094.839|5.801|if
4097.4|5.24|H uh but we're just saying like input
4100.64|4.4|and Target are just sequences and we
4102.64|5.88|just um if you have enough capacity we
4105.04|6.6|can just handle both and and there are
4108.52|6.52|other um cases where
4111.64|4.559|like yeah so yeah I can totally see or
4115.04|3.04|actually maybe I should have repeated
4116.199|4.321|the question the question is uh can we
4118.08|4.279|think about this parameter sharing other
4120.52|3.56|structures in the incoder decoder has
4122.359|3.48|actually less structure but I think it's
4124.08|3.599|a little bit more complicated model and
4125.839|3.641|and and that's such complications of
4127.679|3.721|like it has more assumption right the
4129.48|3.08|the like input and Target are different
4131.4|3.759|I think that's a stronger assumption
4132.56|5.599|than okay it's a sequence we deal with
4135.159|7.281|the SE sequence in a unified way so that
4138.159|4.281|would be just my my my my
4145.799|5.321|take uh do you have any thoughts on
4148.359|5.241|recent State space models like Mamba and
4151.12|5.559|how that fits into the Paradigm of less
4153.6|5.92|structure more structure without
4156.679|5.0|reli yeah yeah
4159.52|5.36|um um
4161.679|6.12|okay it's hard to like uh think about it
4164.88|4.76|on the the spot but I I think there like
4167.799|3.92|to me I talked about this architectures
4169.64|3.32|but I don't like architecture is like
4171.719|5.681|kind of
4172.96|6.239|a it doesn't change things too much and
4177.4|3.759|maybe it's a I think multimodalities
4179.199|4.48|might might bring in another challenges
4181.159|5.321|like when this Transformer uh structure
4183.679|7.48|might become a bottleneck when we think
4186.48|6.799|about that but um yeah I I so I think
4191.159|4.961|it's we Transformers have done a good
4193.279|5.841|job so maybe we should think about
4196.12|3.0|especially with the multimodalities
4201.4|6.319|so like for cross tension and Casual
4204.56|6.8|tension is like imposing perational
4207.719|5.96|variance in a way for uh for multi
4211.36|4.24|tension uh instead of causal and then
4213.679|5.04|for for computer version there's like a
4215.6|5.28|lot of learning structure for uences for
4218.719|4.281|self learning what do you think about
4220.88|4.48|those in terms of uh complexities that
4223.0|4.6|you talk about so so the question is um
4225.36|4.799|this causal attention versus the like
4227.6|5.2|the B directional tension they were
4230.159|5.161|probably fine in the text domain but in
4232.8|5.2|the computer vision case that um being
4235.32|5.359|able to attend to the the Future Part of
4238.0|4.8|it is really important yeah is is that
4240.679|2.121|the
4244.159|5.881|question CA tension remove the like
4247.32|6.0|invariance for permutation so what do
4250.04|5.639|you think about like in like for compion
4253.32|4.68|like you learn lot Inari right for
4255.679|5.0|augmentation so what do you think about
4258.0|6.08|like those as a way to structure so so
4260.679|5.161|so I think the the like I don't really
4264.08|4.48|like this invariances and all these
4265.84|4.96|these are like how humans think uh we uh
4268.56|4.32|perceive the vision like CNN for example
4270.8|4.68|is like translation in variance which
4272.88|3.92|was very important we thought but it's I
4275.48|3.52|don't think it's that important actually
4276.8|4.6|if anything now is hurting the the model
4279.0|3.88|learning more General thing and so the
4281.4|3.279|the machines might be learning the
4282.88|2.88|vision in a completely different way
4284.679|3.401|from how
4285.76|5.6|do and I don't think that's problematic
4288.08|5.2|so those invariances um I think is like
4291.36|3.839|could be a good cutting principle but I
4293.28|5.48|don't I don't like I'm not too worried
4295.199|6.921|about just um not having such structures
4298.76|6.439|um I yeah I'll just just try out like
4302.12|4.76|just um based on some Metric um if not
4305.199|3.96|having that invariant structure is
4306.88|3.839|actually better and more scalable and um
4309.159|3.121|I think that's probably fine and
4310.719|5.44|actually even better if we do it without
4312.28|3.879|the structure it's actually better
4317.36|4.92|um so I actually have two questions um
4320.159|4.48|one so clearly you've been thinking
4322.28|5.04|about how inductive biases and structure
4324.639|6.281|limit our potential potentially so I'm
4327.32|5.64|just curious um what are some um big
4330.92|3.84|inductive biases currently that you
4332.96|5.36|think are like Big Blocks that we can
4334.76|6.959|put release as or let go of um as would
4338.32|5.839|be one question go the C current
4341.719|4.92|structure that we should uh get rid of
4344.159|3.841|just current inductive say you think cuz
4346.639|2.641|clearly you've been thinking about this
4348.0|3.88|right so when you look at the state of
4349.28|4.08|research you must be thinking oh man
4351.88|3.48|this is like a big pretty big induct
4353.36|4.04|bias it' be really cool if you could let
4355.36|4.96|this go so I'm just trying to see what
4357.4|6.839|your uh yeah so so so when I think about
4360.32|5.359|this um as an architecture um I I think
4364.239|4.521|the architectures are not the current
4365.679|4.56|bottleneck in my view and so partly
4368.76|3.8|because I did a lot of the architecture
4370.239|4.681|research and at the end we we published
4372.56|4.2|this paper called do like it's saying
4374.92|3.52|okay we try like 60 different
4376.76|3.72|Transformer modifications pretty much
4378.44|5.48|same thing and none of that really Mak
4380.48|5.04|sense make a huge difference U caveat
4383.92|3.48|with like now maybe the conclusion can
4385.52|3.24|be different so I have a very huge bias
4387.4|3.239|against like not doing the architecture
4388.76|3.32|research and and one message could be
4390.639|3.52|that actually the architecture is not
4392.08|3.92|the bottleneck in further scaling and I
4394.159|4.52|think what's the bottleneck now is this
4396.0|4.44|learning objective especially on the um
4398.679|3.681|supervised learning Paradigm or even
4400.44|3.84|like self-supervised pre-training what
4402.36|4.64|we're doing with this maximum likelihood
4404.28|4.48|estimation is okay given this um this is
4407.0|3.159|the only correct Target and everything
4408.76|4.36|else is incorrect because probability
4410.159|5.0|measure is finite so is that really a
4413.12|4.64|comfortable thing to do uh teaching
4415.159|4.601|signal to give the model and I think if
4417.76|5.2|we think about the old days we were we
4419.76|5.56|have a we could um formalize the correct
4422.96|4.239|behavior for a given input very well and
4425.32|4.28|maybe one answer being the single
4427.199|3.921|correct answer is fine but now if you're
4429.6|3.8|thinking about very general especially
4431.12|4.32|the chat applications okay for like
4433.4|5.0|write a poem and then you say this is
4435.44|4.88|the only correct answer I think that the
4438.4|4.36|implication that could be really uh
4440.32|4.319|severe so I think that's really um
4442.76|3.84|something that I'm not comfortable with
4444.639|4.921|and partly why I'm like interested in
4446.6|5.52|rhf as one instantiation of not using
4449.56|4.52|this maximum likelihood instead using an
4452.12|4.32|reward model as a learned objective
4454.08|4.76|function which is a lot less structure
4456.44|4.52|now we can scale further our lhf itself
4458.84|4.96|is not really that scalable I would say
4460.96|4.92|but it just showed that um we can use
4463.8|3.76|this supervised deep learning to train a
4465.88|4.6|model that serves as a objective
4467.56|5.8|function and that really works um in a
4470.48|6.28|you know cool way I think that's a great
4473.36|5.04|Paradigm uh thank you great answer not
4476.76|4.2|that you're being judged or anything but
4478.4|6.319|uh second question I would say is um so
4480.96|6.199|then in the beginning of the talk um you
4484.719|4.881|talk about the big driving force to be
4487.159|4.161|the exponentially cheap computer right
4489.6|4.84|but some of the stuff I've been reading
4491.32|4.56|says more laws ending um and we're going
4494.44|5.48|towards like performance or engine of
4495.88|5.92|architecture so can we rely then on cuz
4499.92|4.319|right the past 50 years we had
4501.8|4.919|transistors doubling or whatever M law
4504.239|4.121|um but yeah that's ending so when you
4506.719|3.161|talk about the compute these demands
4508.36|4.08|that we've been looking at and that
4509.88|4.16|structure our history we're also
4512.44|3.0|uncertain necessarily about how that's
4514.04|3.199|going to project the future so what are
4515.44|4.12|some of your thoughts on uh yeah I think
4517.239|4.041|the moris law is really uring in this
4519.56|2.92|case because it's like number of
4521.28|3.08|transistors but that doesn't really
4522.48|4.679|matter I think what matters is a compute
4524.36|4.2|availability and like GPU for example is
4527.159|2.961|a very different kind of architecture
4528.56|3.92|and that enabled the continuation of
4530.12|4.84|this trend and I think uh right now
4532.48|4.759|20203 2024 we're kind of taking the
4534.96|5.36|shortcuts with like low Precision thing
4537.239|4.96|uh which still I think is cool but but I
4540.32|4.879|think there are many other um like GPU
4542.199|4.561|level uh things but also we if we are
4545.199|3.52|kind of sure about the architecture this
4546.76|4.76|is my my thoughts we can like hardcode
4548.719|5.401|into the tips and that can provide a lot
4551.52|4.08|of benefits and I think uh like training
4554.12|3.28|for training I don't think that's really
4555.6|3.599|done but GPU if you think about it is
4557.4|4.88|like too General maybe that is like
4559.199|5.721|something that we can revisit and so I I
4562.28|4.68|I'm like not losing hope and I don't see
4564.92|3.68|any like trend of doing that but maybe
4566.96|4.36|other things will come come as a
4568.6|6.48|bottleneck like maybe energy or
4571.32|6.399|something yeah so physics probably
4575.08|4.84|something that we need to study again if
4577.719|4.121|you don't mind me like continuing then
4579.92|3.759|the problem is like we're talking about
4581.84|3.08|exponential like driving forces right
4583.679|3.201|you can tell me that you want a hard
4584.92|2.88|coach hips but that's not the same as
4586.88|2.72|telling me that there's going to be
4587.8|4.24|exponential growth that we can ride
4589.6|4.88|right into like paradise or whatever the
4592.04|5.199|hell we're going yeah um here's here's
4594.48|4.92|my very U boring answer I think we just
4597.239|3.96|need to do a little bit better and at
4599.4|5.08|some point the machines will be better
4601.199|6.44|than us in thinking about chip design
4604.48|5.239|so so I I I I think it's half joking but
4607.639|4.481|uh if we look back at say this video two
4609.719|5.281|years from now I think it'll be less uh
4612.12|5.4|more a serious thing yeah let's let's
4615.0|7.8|let's get there first all right so
4617.52|5.28|thanks toan for an amazing talk