start_time|end_time|text
1.08|2.96| Okay, let's now talk about extending the input
4.08|3.64| normalization to the hidden layers using the technique
7.72|4.16| called batch normalization. I will just show you in this video
11.88|3.9| how it works. And then in the next video, I will show you how
15.78|3.66| we can use it in pytorch. And then I will show you or explain
19.44|5.04| to you why it works. Or at least we will discuss some of the
24.48|3.04| theories trying to explain why it works.
27.52|5.12| Alright, so batch normalization, or in short, batch norm goes
32.64|5.12| back to a paper published in 2015, called batch
37.76|4.68| normalization, accelerating deep network training by reducing
42.68|5.0| internal covariate shift. So internal covariate shift, that's
47.68|3.52| like, yeah, I don't know a fancy word for just saying that the
51.2|3.96| feature distributions shift during the course of the
55.16|3.52| training internally in the hidden layers, we will explain
58.68|4.56| or think about this more when I go to the video where I offer
63.24|2.68| some theories why batch normalization works well in
65.92|5.64| practice. So here, I'm just, I would say the short version of
71.56|3.96| batch normalization, what it is, it's about normalizing the
75.56|4.16| hidden layer inputs. So instead of just normalizing the inputs
79.72|5.0| to the network, we normalize also internally, the inputs to
84.72|3.48| each hidden layer. And this helps you with exploding and
88.2|2.68| vanishing gradient problems so that the gradients don't become
90.88|4.2| too large or too small. And overall, it can increase the
95.08|4.6| stability during training. So in that way, training progresses
99.68|4.32| more smoothly. And also the convergence rate improves. That
104.0|6.36| means it may be that we need fewer epochs to get the same
110.36|4.24| loss that we would achieve if we don't use batch norm. So you
114.6|6.16| usually with batch norm, the networks train faster. And how
120.76|3.48| you can think of it as an additional normalization layer.
124.72|3.2| And there are also some additional trainable parameters
127.96|6.0| involved. Yeah, so in the next couple of slides, I'm going to
133.96|3.84| walk you through the procedure of batch normalization. So just
137.8|4.28| for context on let's suppose we have a multi layer perceptron.
142.08|4.92| Okay, so let's say we focus in on this activation here in the
147.0|3.0| second hidden layer. So the first activation in the second
150.0|5.8| hidden layer. And we're actually looking at the net input of that
155.8|3.32| activation. So remember how we compute the activation. So it's
159.12|7.0| usually by applying activation function to the net input. What
166.12|2.72| type of activation function doesn't really matter here, it
168.84|4.68| could be logistic sigmoid 10h or relu should work with any type
173.52|5.68| of activation function. Alright, so yeah, we are focusing on this
179.6|4.44| hidden layer net input corresponding to the activation
184.04|5.16| here now. And also now suppose we have a mini batch. So we have
189.2|3.76| a mini batch such that the net input of a given training
192.96|5.48| example at layer two is written as fellows. So I have now this
198.44|5.04| x i here for the index of the training example in that mini
203.48|3.72| batch. So if I have i equals one, this would be the first
207.2|4.4| example in that mini batch. And just to for simplicity, I will
211.6|3.68| actually ignore the layer index in the next couple of slides
215.28|5.56| just so that the other notations are a bit simpler to read. So
220.84|4.12| yeah, here, that's the first step of batch norm, there are
224.96|4.64| two steps. So the first step is to normalize the net inputs.
229.92|3.04| This is essentially the same as the standardization that I
232.96|4.32| explained earlier for the inputs. So what's going on here
237.28|6.56| is we are computing the mean over a feature. So the j is the
243.88|7.24| feature index again. So you can actually use batch norm for any
251.12|4.44| type of input. So we will also see there is a two dimensional
255.56|2.76| version for that for convolutional networks later on.
258.64|3.6| But here we are just focusing on the regular one dimensional
262.24|3.6| version where you have a feature vector, for instance. So let's
265.84|7.96| say we have, yeah, the J feature. And if I go back, so if
273.8|5.28| you consider this activation here, what are the features, so
279.08|4.52| the features are all essentially all the previous layer
283.6|7.24| activations, right? So all these go into that activation. So all
290.84|8.88| of these here are the features of this activation here. So J
299.88|3.48| really is the index over the activations from the previous
303.4|3.28| layer. So we can also think of it as the feature index or
306.68|12.76| previous, which are the previous layers, activations. Yeah, so we
319.44|7.84| compute from that the mean and the variance. So that is nothing
327.28|4.32| that should be new to you. It's a simple, simple calculation
331.6|4.32| here. And then we standardize. So this is like what we had in a
335.92|3.88| previous video as standardization. And this is
339.8|3.8| essentially it's in that way, step one of batch norm is
343.76|4.56| similar to the input standardization. Except now, we are
348.32|4.34| looking at a hidden layer. So instead of looking, instead of
352.66|4.3| looking at standardizing x, we are now standardizing these A's
356.96|6.0| from the previous layer. So after step one comes step two,
362.96|5.04| so one more thing to say about step one. So in practice, we
368.0|5.2| modify this standardization slightly, such that we don't
373.24|4.92| bump into, yeah, division zero issues if the variance is zero,
378.16|4.52| if there's no variance. So for numerical stability, we add a
382.68|4.24| small value epsilon here. So here we have the variance plus
386.92|2.8| this little epsilon, and then we take the square root instead of
389.72|3.08| instead of dividing by the standard deviation directly,
392.84|3.44| that's just like a small computational trick to prevent
396.28|7.6| division by zero errors. Now step two. So step two is the
403.88|4.68| pre activation scaling. What do I mean by pre activation? So
408.56|5.68| this is the value that is computed before the activation
414.24|4.32| is computed, it will become more clear in the next slides where
418.56|7.68| I have step one and step two connected to each other. So this
426.24|3.56| is essentially what we have done in the previous slide. So if I
429.8|6.6| go back, this is the end of step one. And then from step one, we
436.4|6.04| go here to step two, where we apply a scaling. So there's a
442.44|6.92| gamma J, and a beta J. And both of these are learnable parameters
449.36|4.84| that are also learned using backpropagation. So similar to
454.2|3.0| the weights in the network, these are also updated via
457.2|4.08| backpropagation. So what do these do? I mean, essentially,
461.72|3.88| there is a scaling parameter here. And there's a shift
465.6|6.76| parameter, right? So technically, it can learn to undo
472.4|3.96| what we just did in step one, right? So it essentially can
477.76|8.92| undo it. So if gamma, I, J, sorry, if that happens to be
486.68|12.04| equal to, let's say this term, and beta J happens to be equal
498.72|5.2| to this one, I mean, these are learnable, so it may happen. So
503.92|6.76| the network can actually learn to undo step one, the scaling or
510.68|4.68| standardization, whether it does that or not. It's Yeah, it
515.36|3.36| really depends. But I'm just saying here, the possibility
518.72|4.68| exists, that it can undo this. But in that way, what's
523.4|3.2| happening here is it's something that is a little bit more
526.6|3.88| flexible than just regular standardization. So here, step
530.48|2.32| one would be a regular standardization of the hidden
532.84|4.04| layer activations. And step two is a little bit more, I would
536.88|5.8| say flexible. So technically, this whole step one and step two
542.68|3.84| thing can just simplify to regular standardization, if this
546.52|2.68| is given, or it could be something different. And in
549.2|5.44| practice, it happens that this set up the step one and step two
554.8|4.32| set up works better than just step one alone, it just happens.
559.12|5.24| So and yeah, one theory or could be it's just my theory that I'm
564.36|3.4| coming up with. But one simple explanation could be, for
567.76|3.36| example, it might perform better because yeah, we just have
571.12|3.36| additional learnable parameters. It's essentially as if we have
574.48|2.6| more, yeah, more parameters in the network. So the network has
577.08|3.72| a higher capacity, maybe. But yeah, we will look at some other
580.8|1.96| theories in a future video.
584.68|3.88| Alright, um, yeah, so as I said, so this controls the mean, and
588.56|4.04| this controls the spread of scale. So from this one, and
592.6|5.6| this one, basically. And like I also already said, technically,
598.2|3.04| batch normally, I could learn to perform standardization with zero
601.24|5.08| minute unit variance. If, um, yeah, if these are the same, and
606.8|0.8| these are the same.
611.4|6.2| So here is step one and step two connected and summarized. So
617.6|2.52| yeah, I'm not showing you the numerically stable version, but
620.36|3.84| you probably know, I mean, you can also do it doesn't really
624.2|4.52| matter. It's just for keeping things simple. So here's the
628.72|3.44| whole procedure of how it would look like here, I'm applying it
632.16|5.16| to both this layer and this layer. So the colors should
637.32|3.96| match here. So let's say x is our input, then we first compute
641.32|2.6| the net input. So if we are here, we are computing the net
643.92|4.68| input. And then this would be step one where we standardize
648.6|6.8| the net input. Then what we do is we compute this pre activation
655.4|3.8| scaling. So this is a scaling. And then we compute the
659.2|5.08| activation. So the activation in this case would be computed by
664.88|4.88| sigma or let me write this down properly, a one, one would be
669.76|9.48| sigma, a prime one, one, right. And then once we have that, we
679.24|4.08| go to the next input. So this is the next net input. Then again,
683.32|6.44| we do step one. So here we can step one. And then we do step
689.76|8.52| two. And then we compute again, activation should be a one here,
698.28|8.0| sigma, a one, two, prime. So yeah, this is essentially it.
706.28|3.4| And yeah, this is how batch norm works. Um, do I have anything
709.68|4.76| more? Yeah, one more thing to consider is that this one also
714.56|4.28| makes the bias redundant, right? So I'm not showing the bias unit
718.84|3.56| here. And this network, but technically, you would have a
722.4|7.68| bias unit, b one here, here, b two, here, b three, that gets
730.12|5.44| added to the net input. Right? So that is something that you are
735.56|6.56| familiar with. And the if you think about how the bias works,
742.2|3.76| right? So if I have a simple case here, the net input, it's
745.96|11.36| on, it's right in like, W, just for simplified case. So let's
757.32|6.52| say I'm computing the net input for the second layer, this would
763.84|9.6| be weights from the first layer, multiplied by the activation
773.44|5.04| from the first layer here, layer one, layer one, and then plus
779.8|2.4| the bias. So I'm only considering your simple case
782.52|3.32| omitting the index. Otherwise, I would have another index. But
785.84|3.0| yeah, you know what I mean. So I would have the bias added to it,
788.84|4.32| right? But this kind of becomes redundant, because essentially,
793.36|2.4| the bias could be already included in this beta or the
795.76|4.08| beta would essentially, if you leave out this bias here, the
799.84|3.96| beta would essentially take the role of that bias if we compute
803.8|4.64| batch norm. So in that sense, you can skip the bias when you
808.44|2.88| define the layers, I will show you that in the code example,
811.44|3.4| how we can do that. I mean, it doesn't really matter. But
815.48|2.4| whether we do it or not, it should work both ways in
817.88|3.6| practice. But it's just, I would say a little cleaner to not use
821.48|2.72| a bias because it's redundant. I will show you in the next video
824.2|2.88| in the code example, how that looks like. So you can actually
827.08|6.84| apply an argument, say bias equals false. Yeah, and also
833.92|4.6| note that now when we use batch norm, batch norm has learnable
838.52|4.92| parameters. So if we use batch norm in a given layer, it has we
843.44|3.56| have an additional two vectors that have the same dimension as
847.0|4.04| the bias vector, right. So if we have, we use batch norm here in
851.04|7.36| this layer, we will have two, four dimensional vectors, like
858.48|2.72| this bias vector here would also be four dimensional, right,
861.2|4.0| because there's one bias for each in layer activation.
866.1|3.26| Alright, so I think this is all I have about batch norm. This is
869.36|3.64| how batch norm works. In my slides, I actually had also
873.36|2.56| short or not short, it was actually like 10 slides or so
876.12|2.84| how we do backpropagation with batch norm, but I promised you
878.96|3.48| not to torture you with these nitty gritty details and math
882.48|2.56| mathematical details, because that's not super important
885.04|2.76| because we use auto grad and practice anyway. And I think
887.8|3.04| it's in this course also, more important to understand the
890.84|3.04| bigger picture concepts. And then if you're interested, you
893.88|4.36| can study those things later on. So yeah, and also if we would
898.24|2.48| start like going through these slides, it would take another
900.72|3.56| half an hour. I would rather complete this lecture today so
904.28|2.58| that next lecture, we can talk about optimizers and move on to
906.86|3.66| convolution networks. I hope you don't mind. So in that way, next
910.52|26.64| video, I will show you batch norm in pytorch.