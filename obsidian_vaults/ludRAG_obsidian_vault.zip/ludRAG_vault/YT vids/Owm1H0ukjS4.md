start_time|end_time|text
2.12|3.76| Yeah, our first topic today is learning rate decay, that is
5.96|4.4| decreasing the learning rate over the course of training. So
10.36|3.96| just to briefly recap, what is again, mini batch learning. So
14.32|3.6| mini batch learning is a form of stochastic gradient descent,
18.12|3.12| where we draw mini batches from the training set. So each mini
21.24|3.08| batch can be considered as a sample drawn from this training
24.32|3.72| set, where the training set itself is in turn a sample
28.04|3.42| drawn from a population, right. So the training set is just what
31.46|3.48| we have access to, like a sample from a distribution that we
34.94|3.66| train on. And during mini batch learning, we use your sub
38.6|4.28| samples or smaller samples, each mini batch is a sample of the
42.88|3.44| training set, which itself is a sample. And then we do the
46.32|6.16| forward and backward pass on each mini batch. So if we draw
52.48|3.12| these small mini batches, these small samples, we will actually
55.6|3.24| get noisier gradients compared to using the whole training
58.88|3.92| training set. But this can have advantages and disadvantages
62.84|2.6| using these smaller mini batches compared to the whole training
65.44|4.84| set for computing the gradient. So it can lead using mini batch,
70.6|2.2| mini batches instead of the whole training set can lead to
72.92|3.2| noisier gradients. But yeah, they can actually be quite good
76.12|4.72| because they can help us to escape local minima. So here on
80.84|6.64| the left hand side, I'm showing you the loss surface for cost
87.48|5.68| surface for convex loss function where the Yeah, the center here
93.16|4.36| is the global minimum that we want to reach. Here are the two
97.52|2.36| weights, it's just a simple model, you can think of it as
99.88|3.46| let's say, a linear regression model. But in the context of
103.34|3.26| deep learning, we have a non convex loss function. And
106.6|5.48| actually, this noise gradient can help us to escape local
112.08|3.46| minima where the algorithm may get trapped. But the problem is
115.78|5.18| that it can lead to oscillation. So let's say in this case here
120.96|4.72| on the left hand side, I take steps perpendicular to the
125.68|8.6| contours, if I use the whole training set. But I have like
134.28|7.36| these noisy updates here, if I use mini batches. So this can be
141.88|4.72| quite, I mean, it's not so bad, but it is of course not as good
146.6|4.16| as the direct path, right. So there are pros and cons of using
150.76|2.12| mini batch learning. Today, we will learn also about a
152.88|4.36| technique, like momentum that can help help with that. But
157.24|3.76| also one way you can help with this oscillation is yeah, by
161.0|3.6| having decreasing the learning rate that it is not so big that
164.96|3.8| the algorithm doesn't take very large steps in the wrong
168.76|2.56| direction, but also by collecting more
171.32|2.8| representative samples, like having larger mini batches can
174.12|5.4| also reduce the noise. But yeah, before we talk about that, what
179.52|2.64| is also another advantage of mini batch learning. So we
182.16|4.28| talked about the convergence speed, because compared to
186.88|2.92| regular stochastic gradient descent, where we only have one
189.8|3.6| training example per update, mini batch gradient descent is
193.44|3.92| actually faster. And it's also it can be faster than doing the
197.36|5.04| updates compared to the whole training set. And if you maybe
202.4|4.4| don't recall why that is, we covered this in the in an earlier
206.8|3.32| lecture, but maybe just be a good idea to just think about
210.12|4.44| this again, why is mini batch gradient descent faster than
214.56|3.72| stochastic gradient descent with only one training example per
218.28|4.08| update? And why is mini batch gradient descent faster than
222.72|5.68| gradient descent using the whole training set? Okay, but yeah,
228.4|3.48| moving on, here's another example of this oscillation, I
231.88|4.64| was drawing this with a tool available on this website, which
236.52|3.84| is essentially a visualization tool for different optimization
240.36|3.4| algorithms, it's actually a pretty neat tool. So here, on
243.76|4.4| top, I'm using SGD with a very large learning rate, you can
248.16|4.4| see that if the learning rate is too large, we can also increase
252.56|3.44| the noise, or we have this big oscillation, basically, where we
256.0|3.48| are overshooting. So if the minimum is here in the center,
259.72|4.88| if a lot of a large learning rate, then I may overshoot. So I
264.6|2.6| go too far, my first update goes, maybe I should use the
267.24|3.96| yellow here, my first update goes until here, it overshoots.
271.44|3.88| And then we have to go back for a second update. And then see
275.32|3.08| you see that's very inefficient. So a large learning rate is
278.4|3.6| actually bad. But if we hear how can we fix this problem, we can
282.0|3.2| use actually a small learning rate that is shown here at the
285.2|3.08| bottom, what you can see here at the bottom, though, unfortunately
288.28|4.84| is that it takes a long time to converge. So here we have a lot,
294.56|4.92| a lot of baby steps till we converge. And one problem is,
299.68|4.76| yeah, in the context of deep learning, we have these non
304.44|2.64| convex loss function. So if this is my loss for let's say, a
307.08|4.52| given weight, they are non convex and something like that.
311.96|4.76| And they may get trapped. So let's say, my global minimum is
316.72|4.76| here. And I'm currently here, I do update here, and then it gets
321.48|2.92| trapped here, because here, the gradient is zero. And it can't
324.4|3.56| get over this hump, because my learning rate is too small. So
327.96|4.04| sometimes a noisier update can actually help overcoming these
332.0|4.48| local minima. So noise is not necessarily bad, too. So there
336.48|4.64| is essentially a sweet spot between having too little noise
341.12|2.88| and too much noise. So in the beginning of the training, it
344.0|3.08| might be good to have large noise to overcome some of the
347.08|4.0| local minima. But then over time to decrease this noise. And this
351.08|3.92| is essentially what learning rate decays, yeah, intending to
355.0|3.36| do. Yeah, but before we talk about learning rate decay, let
358.36|3.52| me give you one more practical tip for many, many batches. So
361.88|3.2| usually, it is recommended to use large mini batches. Some
365.08|3.48| people recommend small mini batches, because they find that
368.6|3.2| it helps with generalization. But usually, another
371.8|3.36| recommendation is you're choosing batch sizes that are
375.16|5.48| reasonably large, let's say 256 512 1024, something along that
380.64|4.44| on size. Why is that? So it has also something to do with
385.4|5.64| utilizing the GPU well, but then also with having not updates that
391.04|4.62| are too noisy, because if you have a data set, so that's what
395.66|2.82| I'm trying to illustrate here. If you have a data set like this
398.52|2.48| iris data set, it's just showing the distribution of the three
401.0|4.24| classes here. And then you split it into smaller samples. So
405.24|4.36| here's the training set with size 100. And here with 50. So
409.6|4.68| what I wanted to show is that if we have a larger sample, we kind
414.28|3.92| of roughly maintain the distribution, or at least we
418.2|4.6| maintain the distribution better compared to a smaller sample,
422.8|3.4| like here, you can see that the distribution here and here is,
426.44|3.76| yeah, kind of different. So it's not a big deal if the
430.2|2.76| distribution differs. I mean, we have multiple mini batches, and
432.96|4.04| the noise can be good. But if it differs too large, too much,
437.0|4.4| that's maybe not ideal. So having larger batch sizes will
441.4|4.12| stabilize that a little bit. So in that way, having batch
445.52|4.32| sizes also somewhat proportional to the number of classes in the
449.84|2.88| data set is also a good idea. For instance, if you only have
452.72|5.48| two classes, maybe a batch size of 128, and what 256 is a good
458.2|4.0| number. If you have more classes, maybe you're choosing
462.2|5.0| 512 mini as a mini batch size might be better, for example. So
467.24|4.36| here, I ran an experiment on MNIST, just illustrating how
471.6|3.32| training with different batch sizes looks like. So on the
474.92|6.16| left hand side, I used 10,000 1024 examples per mini batch on
481.08|3.64| the right hand side, I used 64 examples, you can see the
484.72|4.12| performance in the end is, you know, it's about the same is
488.88|4.6| almost identical here. You can see here on the left hand side,
493.48|4.36| though, that this one is way less noisy than this one here,
498.2|2.4| which is expected, right? Because on the left hand side,
500.6|4.44| you have these larger mini batches, I trained for the same
505.04|5.16| number of epochs 100. And you can see that the smaller one
510.2|4.24| converges faster, because yeah, we have simply more updates. So
514.44|4.16| here we have 80,000 iterations, so 80,000 updates. And here on
518.6|3.8| the left hand side, only 5000 updates, then you can see, based
522.4|4.52| on the training and validation accuracy here, it converges kind
526.92|3.32| of faster compared to here, it takes a little bit longer to
530.24|2.64| to converge, it doesn't even converge until he still
533.08|4.12| improves. So having larger batch sizes helps stabilizing
537.2|6.28| training. But also, it can actually run faster overall,
543.52|3.16| because it has something to do with utilizing the other
546.68|4.12| computer better by having a few large updates in that way here.
551.0|5.0| So here, we have this training finishes faster, it may finish
556.0|3.6| even faster. If I use a larger batch size, it's it's not quite
559.6|3.36| clear, because maybe I'll have to run it then for more epochs.
562.96|4.88| But here 1024 seems to be actually a good trade off. So
568.0|4.8| but, like I said, if we want to just reduce the noise, in one
572.8|3.24| way is choosing larger batch sizes. Another way is
576.44|2.84| decreasing the learning rate over the course of training, I
579.28|2.68| can actually do both, I can use a large batch size and decrease
581.96|1.64| the learning rate. That's another possibility.
585.72|3.32| So yeah, let's talk now about learning rate decay. Like I
589.04|3.28| mentioned before, we can get these so called batch effects
592.32|2.6| where the mini batches are samples of the training set. And
594.92|3.36| then, yeah, the mini batch loss and the gradients are
598.48|2.88| approximations of the full gradient that we would compute
601.76|3.76| on the full training set. So here in red, this line would or
605.52|5.2| should symbolize the loss on the whole training set. And when we
610.72|5.68| use these mini batches, it's usually much noisier. And
616.4|3.72| usually, we still I mean, the farther we go, the smaller the
620.12|3.2| loss will become. So the oscillation will somewhat become
623.32|4.36| smaller, because the other network learns well, and the
627.68|2.64| loss is just smaller, so the gradients will be smaller, and
630.32|3.12| then the updates will be smaller. But usually, we still
633.44|5.28| get these oscillations here at the tail end. And if we want to
638.76|3.4| decay or dampen these oscillations, we can use a
642.16|2.8| decaying learning rate. So we can shrink the learning rate.
644.96|3.28| Once we are reaching this point, so making the learning rate,
649.04|3.32| instead of having the noisy, making it like smoother, like
652.36|6.6| this, and we use a different color, like this. So and then
659.0|3.12| stabilizing, stabilizing the training. But like I'm drawing
662.12|2.64| here, there's actually one danger with that. It's if we
664.76|5.44| decay the learning rate too early, we may stop the network
670.2|5.4| network from learning too early. So maybe, if I let me go back,
675.6|3.3| so if I have this oscillation, and I dampen the learning rate
678.9|3.54| at this point, then maybe a dampen it too much, and then the
682.44|3.12| network stops updating. So the loss stays here at this point.
686.04|4.2| And this is also not ideal. So in practice, what I usually
690.24|3.44| recommend is training a network first without learning rate
693.68|4.04| decay, then saving this performance as a baseline, and
697.72|3.56| then adding a learning decay method and see whether you can
701.28|3.64| improve over that baseline. Because what happens to me is
704.92|3.8| when I use learning rate decay, I usually decay too much. And
708.72|3.08| then actually, the performance is worse compared without
711.8|4.16| learning rate decay. It's like a real possibility to decay too
715.96|5.44| much. Yeah, so let me show you some common ways we can decay
721.4|3.36| the learning rate. So one of the most common variants of learning
724.76|6.12| rate decay is the exponential decay, where on here, at zero
730.88|12.36| is the initial learning rate, and t here and eta t, t would
743.24|4.68| be the time set step, either the iteration, but most often the
747.92|4.3| epoch. So we do an update every let's say epoch, but you can
752.22|4.5| also say, do an update every 10th epoch. And then, yeah, we
756.72|8.36| are decaying by multiplying this learning rate by term e to the
765.08|5.6| power of minus k, where k is the decay rate times the epoch. And
771.28|3.72| yeah, I was plotting this on the right hand side. And if you
775.0|3.84| update after each epoch, you can see if you choose a decay rate
778.84|6.16| of point 1.1, then you would see that the network essentially
785.0|4.24| stops learning at epoch 40, if you start with an initial
789.24|4.04| learning rate of point five. So it really depends. So you can
793.28|4.32| basically do 40 updates with this learning rate decay rate,
797.82|2.54| and then the network will essentially stop learning. So
800.36|3.88| you have to also factor this in if you want to have more
804.24|4.0| updates, more small updates, maybe choose a decay rate of
808.24|4.26| point or one. So here, this will decay slower. And this is also
812.5|3.7| another hyper parameter, which is why I recommend just doing
816.44|2.88| doing the training first without learning rate decay, and then
819.32|3.5| adding it later to see whether it improves it or not. Um, but
822.82|3.58| it's Yeah, it's just another thing to worry about in deep
826.4|3.44| learning training. So there are lots of little things to tune
829.84|5.92| and change to see how it affects the performance. Another common
835.76|3.92| variant for learning rate decay is halving the learning rate. So
839.68|4.64| that is usually something I use most often in practice. So you
844.36|4.84| basically update the learning rate after each step t so could
849.2|3.4| be each epoch or each 10th epoch. So I will show you
852.6|2.84| another modification of that that I personally use in
855.44|2.84| practice. But yeah, so essentially, you are halving the
858.28|5.76| learning rate every, let's say teeth, iteration or epoch. And
864.04|3.04| then there's also in inverse decay, which is essentially
867.2|2.36| similar to the exponential decay, it's just computed
869.56|2.52| slightly differently. So and again, here on the right hand
872.08|4.16| side, I'm plotting this here for reference. But essentially, it's
876.48|6.32| very similar to the exponential decay. There are also many other
883.0|4.86| types of learning rate, decay, schedulers. So this topic is
887.86|5.58| also sometimes called learning rate scheduling. And here was a
893.44|2.6| paper, for example, on a cyclical learning rate, I'm
896.04|3.58| mentioning it because I also see many people using that in
899.62|4.34| practice. Personally, I haven't had success with that. But I
904.0|4.0| hear often from people that it can improve things. So here,
908.12|3.18| essentially, the cyclical learning rate, it's increasing
911.3|2.94| the learning rate and decreasing, increasing, decreasing,
914.24|3.76| and so forth. So it's going up and down. And yeah, that's just
918.0|5.64| an interesting, interesting technique. There's also another
923.64|4.98| paper, I think it's actually the first for the same author as the
928.62|2.98| author who worked on the cyclical raining learning rate.
931.6|5.68| So here, the author or authors on this paper recommend
937.32|6.8| essentially, instead of doing a learning rate decay, increasing
944.12|7.32| the batch size because it can have a similar effect. So here,
951.44|3.2| they're saying it reaches equivalent test accuracy is after
954.64|2.64| the same number of training epochs, but with fewer
957.28|2.8| parameter updates leading to greater parallelism and shorter
960.08|3.2| training times. So essentially, you're increasing the batch
963.28|3.88| size can have the same positive effect as decaying the learning
967.16|2.36| rate, but could be more efficient. It's also quite
969.52|5.32| interesting. So yes, a simulation of that. So we're on
974.84|4.34| the left hand side, um, they have two decaying learning
979.18|4.58| rates. That's the validation set accuracy for the number of
984.08|5.64| epochs. And here they have the increasing batch sizes. And you
989.72|4.8| can see essentially, that in the end, they approximately reach
994.52|5.88| the same performance. And on the right hand side, they show that
1001.0|3.08| with a larger batch size, you have fewer parameter updates,
1004.12|5.52| yeah, just because your mini batches are bigger. So yeah,
1009.64|3.6| that was essentially learning rate decay in a nutshell. In the
1013.24|4.02| next video, I will show you my favorite way of doing learning
1017.26|3.46| rate decay. So it's like a version of halving the learning
1020.72|4.34| rate. And I will also show you how you can do that in
1025.06|25.78| practice.