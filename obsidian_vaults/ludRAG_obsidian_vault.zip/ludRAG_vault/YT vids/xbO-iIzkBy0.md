start_time|end_time|text
0.56|3.52| Yeah, so this video is not going to be terribly important. It's
4.08|4.02| just a little bit of nitpicking. In case one of you has been
8.1|3.54| wondering, maybe one or more have been taking a signal
11.64|2.72| processing class in previous semesters. And we're wondering,
14.68|3.68| why do we call the procedure convolution and not cross
18.36|3.12| correlation. So in fact, actually convolution networks are
21.48|3.68| performing something called a cross correlation. So what's the
25.68|4.0| difference between convolution and cross correlation? So yeah,
29.68|4.0| cross correlation or convolution is another one of these jargon
33.68|3.84| terms. So in deep learning, we sometimes use words from other
37.52|2.72| fields that have a different meaning. And the convolution
40.24|3.44| would be one of those. So the convolution and deep learning is
43.68|4.52| actually what is more commonly known as cross correlation. So
48.4|3.12| the cross correlation is essentially the sliding of the
51.52|5.16| dot product over the image. So when we have this one here, so
56.68|5.06| this region, and we multiply the pixels in that region with a
61.74|2.9| weight, the filter, right, so this is essentially a dot
64.64|7.18| product, right. So we brought it as as follows, right, when we do
71.82|6.88| this calculation. But now, so when we write it down more
78.7|4.1| concretely, so we can write this procedure down as a cross
82.8|27.52| correlation. So and in essence, it's computed like this, when we
110.32|4.76| have these two sums. So we could actually, so the dot product is
115.08|3.52| if we would actually reshape that into two vectors, right, so
118.6|6.2| if we have this one, let's write it like this. And let's say my
124.8|8.08| first row is green. My second row is blue, and my last one is
132.88|4.58| red. This is for let's say, the weight matrix, w, and I have the
137.46|8.38| same one for the inputs. So let's do yellow, maybe purple,
146.64|7.04| and like here. So in order to do the dot product, I could just
153.68|8.4| reshape them as a vector like this, right. And then the other
162.08|10.08| one is and then maybe taking the transpose, and then compute the
172.16|3.38| dot product between the two. But I could also, of course, instead
175.54|2.72| of doing it like this, I could do it the other way around,
178.26|7.64| right, I could do it, I could have the vector like this. It's
185.9|5.1| just vice versa. And then if I multiply this vector with the
191.0|13.76| same x, it gives me a different result, right? Also, like this,
204.88|3.68| so this one and this one, they will give me different results.
208.82|4.3| So that is mainly the difference between cross correlation and
213.12|3.16| convolution, the way we we do the multiplication in which
216.28|4.24| order. So here, this is like the way we do the cross
220.52|3.04| correlation, it's maybe hard to stay at this formula. So let me
224.08|4.88| illustrate how this works. So essentially, think of the index
229.76|3.72| zero as the one in their center. So if this is your, let's say
233.48|5.04| your weight matrix, and you multiply each one with a
238.52|7.56| corresponding value in the image. So how you do that is you
246.12|3.8| consider index i as the center point, and then the negative in
249.92|4.44| DCs. So the one minus one would be the left, upper left corner,
254.58|4.74| and one one would be the lower right corner. And then you
259.32|8.96| multiply this weight with the first. So say we have our say
268.28|8.08| this is w and this is x here to where this whole thing is w. So
276.36|6.96| we multiply this one with this one, this one with this one,
283.44|4.08| this one with this one. So these indices correspond to the
287.52|3.88| position in the input, essentially. So that's how we do
291.4|3.74| the cross correlation. And this is essentially how how we did
295.14|2.66| that in the previous videos. But you can also do it the other
297.8|3.36| way around. So this is known as convolution. Notice the only
301.16|3.06| differences that I'm flipping here, some signs, but again,
304.22|3.54| it's probably hard to stare at this equation or formula. So
307.76|4.24| it's pretty easy to see it here in this image. So again, this is
312.0|6.12| our w here. And then we multiply it with the values and x. So in
318.12|9.2| x, we have still the same on the same order. But now, so let's
327.32|11.28| say 123456789. But now we multiply this one with the first
338.6|4.96| position, and then this one with a second one, and so forth. So
343.68|4.0| really, the difference is you can see that it's inverted. So
347.72|7.56| here, in cross correlation, we go like this. And in
355.28|4.56| convolution, we would go like this. That's the main
359.84|4.72| difference. If you don't believe me, I just also have an example
364.56|4.08| here, just using code to just, in a practical way, show you
368.64|3.96| that this is indeed the case. So here, to demonstrate this, I'm
372.64|4.4| initializing a torch tensor, just some arbitrary values. And
377.04|3.36| then I'm initializing the convolution, I'm setting the
380.44|2.4| bias to zero, because that's not worry about the bias here, it's
382.84|4.36| just distracting. Here is the weight matrix, corresponding to
387.2|2.32| the convolution, the three by three, we have a three by three
389.52|6.56| kernel. And when I then apply this, so first of all, I have to
397.12|5.12| what I'm doing here is I'm converting it to NumPy. So I can
402.24|4.52| use the cross correlation function and the convolution
406.76|3.48| functions implemented in Cypher because it expects NumPy
410.24|4.16| arrays. So yeah, I'm just creating a NumPy placeholder
414.68|4.04| that I'm going to use. And you can see, this is just here, the
418.76|7.24| pytorch weight in site, the convolutional operator. And here,
426.0|4.28| this is the NumPy version, it's exactly the same values, it's
430.28|2.16| just a little bit more precision, because I think this
432.44|3.8| is 30 bit precision, and this is 64 bit precision. But you can
436.24|8.04| see, the values are exactly the same. Now, when I call this conf
444.28|3.04| pytorch, the conf pytorch, again, this is my conf 2d
447.32|4.04| operation, it's a three by three kernel applied to a three by
451.36|3.6| three input. So what I will get is a single value, the single
454.96|9.48| value from applying pytorch convolution is minus 1.1027. So
464.44|4.64| what is this, I'm just reshaping it because usually in a neural
469.08|3.32| network, what we have is we have the number of batches and the
472.4|2.96| number of channels here doesn't matter, we are just looking at
475.36|3.8| a matrix. So I'm setting them to one, because otherwise, this
479.16|3.8| function will complain. In any case, so the value I get is
482.96|6.14| minus 1.1027. Now, if I use the cross correlation function here
489.1|4.42| from Cypi, you can see I get exactly the same value, of
493.52|3.36| course, okay, we have 64 bit precision here. So there are a
496.88|4.32| few more digits, but you can see overall, it's also minus 1.102.
501.56|5.2| So it's exactly the same value. So the convolution in pytorch is
506.76|3.96| the same as the cross correlation in Cypi, and vice
510.72|4.36| versa. So this is the same as buff. If we look at the real
515.08|3.28| convolution, if we use the convolution implemented in Cypi,
518.36|8.48| we can see what we would get is minus 0.26. And if I want to get
526.84|3.92| that result in pytorch, what I would have to do is I have to
530.76|5.28| either invert or not invert, but rearrange the weights or the
536.04|4.6| input, it doesn't really matter. So here you see I'm rearranging
540.64|5.26| it here, I have the 3.3. So I'm kind of creating the matrix
545.9|3.4| backward, you can see the 3.3. So you know, at the top 3.2, and
549.3|2.8| the 3.2 here, so I'm just putting in a different order.
552.1|2.6| And then I also get the same result as with this convolution.
554.86|3.84| So in fact, the convolution in pytorch is a cross correlation.
559.06|2.48| So why does it even matter? I mean, I was just highlighting
561.54|2.52| the difference between the two operations. Yeah, in practice,
564.06|3.96| it does not really matter, at least not in deep learning. So
568.98|3.72| maybe in traditional or in other fields of computer vision and
572.7|4.16| signal processing, it's actually useful to have this associative
576.86|3.76| property of the real convolution. But in deep
580.62|3.16| learning, to be honest, that doesn't really matter. And I
583.78|2.8| think cross correlation is easier to implement, especially
586.58|2.64| for the backward pass. But we don't worry about the backward
589.22|2.92| pass, I will show you explain a little bit about the back
592.14|2.52| propagation in the next video. But that is usually
594.66|3.04| automatically handled in pytorch. It's maybe like a
597.7|5.28| small efficiency reason. Yeah, but then when we or if we
602.98|4.04| implement cross correlation for these networks, why do we call
607.02|3.6| them convolutional networks? Why don't we call them cross
610.62|3.16| correlational networks? Yeah, my theory is just that cross
613.78|2.64| correlational network sounds a little bit weird and
616.42|2.96| convolutional network sounds slightly cooler. So that's maybe
619.38|4.64| also one aspect about the whole thing. Anyways, so this video
624.02|2.6| was not really important. I was just highlighting the difference
626.62|3.16| in case someone was wondering. In the next video, I want to
629.78|3.84| briefly go over CNNs and back propagation, but we won't go
633.62|23.56| into any mathematical details. So don't be afraid.