start_time|end_time|text
1.24|4.04| Yeah, previously, we talked about input normalization, but
5.32|4.6| weight initialization matters to to have everything on the right
9.92|4.48| or on a good scale. No pun intended here, though. So now we
14.4|2.96| are briefly motivating why we care about when weight
17.36|3.36| initialization, and then I will show you two common ways to
20.72|3.4| initialize weights. And then we'll see how we can do that in
24.12|3.32| pytorch, or whether we even have to bother about that in pytorch.
27.44|6.4| So previously, we discussed that we want to initialize weights to
33.84|3.8| small random numbers to break symmetry in the multilayer
37.64|4.56| perceptron. So I gave it to you as a question to think about. And
42.2|3.2| yeah, we discussed this on Piazza, if you have still
45.4|3.8| questions about that, there was a good answer on Piazza on
49.2|6.6| that. So, um, yeah, but besides having small random numbers to
55.8|4.12| break the symmetry, we also want the weights to be relatively
60.0|3.6| small, right. So that is another thing to think about. But it has
63.64|4.1| something to do with what I showed you earlier in an earlier
67.74|6.02| video here about input normalization. So just to kind of
74.04|2.46| explain or motivate this a little bit, think of the
76.5|3.18| multilayer perceptron again, where we here have the
79.68|4.08| multivariable channel for updating one particular weight.
83.76|2.6| So this is something I just copy and paste it from a previous
86.36|4.8| slide, nothing new here. But I want you to focus briefly on on
91.16|4.4| this part here where we have the derivative of the activation
95.56|4.68| with respect to the activation in the previous layer. So
100.24|9.24| actually, we could expand that to let's show it written it like
109.48|16.44| this. Let's do it like this. Z one, two, and then I'm just
125.92|6.76| expanding it here. So what the critical part here is, is this
132.68|3.02| part where we compute the derivative of the activation
135.96|2.96| with respect to the input, particularly for example, if we
138.92|4.28| have something like the logistic sigmoid, right, because if we
143.2|4.4| have a logistic sigmoid, if you recall the, yes, the partial
147.6|2.48| derivative of the logistic sigmoid with respect to its
150.08|5.76| input. So the derivative is largest if the input is zero,
155.84|4.28| right. And also, even if it's zero, it's just point to five.
161.32|4.2| So if we have something like this here, where we have this
165.52|5.46| term, we have a number that is always smaller than one, right.
171.24|4.48| So in this case, this can lead to a so called vanishing gradient
175.72|6.42| problem. Because then we multiply a number with a number
182.14|3.38| smaller than one multiple times if we have many layers. So for
185.52|4.64| instance, if we assume this is the largest gradient or partial
190.16|3.28| derivative, we can get for the logistic sigmoid function. And
193.44|4.36| then if we have 10 layers, we have a multiplication with a
197.84|6.44| value that is at most point to five. And that will degrade the
204.28|2.4| other gradients as well substantially, right, because if
206.68|3.96| I go back one more time, so we have all these these other terms
210.64|5.2| here, right. So the term here, here and here, it's all
215.84|3.92| multiplied with this one, right. So this is small, then well, we
219.76|4.08| we degrade the whole the whole update here, the gradient here.
224.08|3.6| And this is only for two layers, if we have more layers, we have
227.68|2.64| more of these terms in the in there, if we use the logistic
230.32|5.68| sigmoid. So in fact, then we would, if we have 10 layers, we
236.0|4.16| would degrade the value by about 10 to the power of minus six, so
240.16|4.04| the gradient will be so small, that the network will probably
244.2|6.92| not learn much anymore. So, you know, because of that, it's
251.12|5.6| usually a good idea to use other types of activation functions,
256.92|6.12| you can also kind of regulate that with the learning rate. But
263.04|3.24| this is one of the motivations why it's important to initialize
266.48|3.64| the weights centered at zero, for example, if you use a
270.12|3.16| logistic sigmoid function, because then you will have at
273.28|4.84| least the maximum gradient, right. So if I go back, if you
278.64|3.24| have inputs, or the net inputs that are small, let's say in
281.88|4.56| this range, or large in this range, then the gradient will be
286.44|3.52| even smaller, right. So in this way, you want to have something
289.96|3.16| that is at least they are centered at zero. So you can
293.56|4.72| initialize your weights, for example, from a random, from a
298.28|2.36| random uniform distribution, for example, for example, in the
300.64|3.56| range 01. But if you use a logistic sigmoid, for example,
304.2|3.04| it might be better to do it in a range between minus point five
307.24|4.4| and point five, or maybe even smaller, minus point Oh, five,
311.64|7.84| and 0.05. So, um, you can also choose a positive range. I mean,
319.48|2.48| if you have a relu function, it probably doesn't really matter
321.96|3.8| that much. However, this gives you more combinations, if your
325.8|2.6| inputs are also negative and positive, right. So in that
328.4|4.28| way, um, yeah, you can do either or if you have a relu, or you
332.68|3.28| can also Yeah, just what's very common is to initialize the
335.96|3.52| weights from a random Gaussian distribution with mean zero and
339.48|4.92| the small variance. But these are just some, I would say some
344.72|4.28| suggestions that have been used in the past. Nowadays, it's
349.0|3.76| actually more common to use either something like the
353.52|4.8| Xavier glorot initialization or camming her initialization. So
358.32|1.96| we will talk about this in the next video.