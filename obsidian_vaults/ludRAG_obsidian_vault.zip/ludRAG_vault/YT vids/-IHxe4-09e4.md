start_time|end_time|text
1.2|4.38| Yeah, next to the data set to having good quality data, one of
5.58|3.46| the aspects that determines the success of applying convolutional
9.04|3.08| networks to computer vision problems is choosing the right
12.24|4.16| architecture. So in this video, I want to briefly go over some
16.4|2.68| of the most popular architectures out there. But it
19.08|2.88| will be only a very brief overview, because the next
21.96|3.66| lecture will be wholly dedicated to CNN architecture. So here,
26.08|2.6| this will be the big picture. In the next lecture, we will dive
28.68|3.16| in, and I will explain some of these architectures in more
31.84|4.04| detail. And also here in this video, I want to add one more
35.88|3.56| thing that we haven't talked about yet. And that is how we
39.44|4.2| work with multiple color channels. So so far, we only
43.64|4.48| worked with black and white images, the MNIST images where
48.12|3.44| we used the Lynette architecture. Now we are also
51.56|2.84| going to look at other architectures that can work with
54.4|4.56| color, and I will explain you how that works. So but let's
58.96|4.24| start with this traditional architecture here. So one
63.2|5.0| traditional architecture, you already saw was the Lynette five
68.2|3.16| architecture, which was applied to handwritten digit
71.4|4.32| recognition, or in general handwriting recognition. And
76.72|3.68| CNNs have been used then since then a couple of times, but they
80.4|4.32| were not they were not really that popular. I mean, traditional
84.72|4.36| computer vision approaches were usually faster and gave better
89.08|3.24| accuracy results. And there was a so called image net
92.32|5.6| competition. I think I'm not sure if it was in recent years,
97.92|3.84| but it has been a very popular competition once where people
101.92|3.48| tried out different computer vision approaches to classify
106.24|3.16| images in this data set. It's a very large data set consisting
109.4|4.68| of millions of images. And usually, traditional computer
114.08|3.2| vision outperformed these convolutional networks or other
117.28|4.84| neural networks. And what was now big here in 2012 is that for
122.12|4.12| the first time, convolution network really outperformed
126.28|4.28| anything else. So any other type of computer vision approach was
130.56|3.96| really outperformed in this year by a large margin. And that is
134.52|3.84| really when people paid or started to pay more attention to
138.36|2.64| deep neural networks and convolution networks. So
141.0|2.84| essentially, this Alex net architecture, which was shown
143.84|4.52| here was the main breakthrough for CNNs and also maybe for deep
148.36|3.56| learning in general. So in particular, this Alex net
151.92|5.6| achieved a 15.4% error, the top five error, I will explain on the
157.52|4.36| next slide on the top five error or top five accuracy, how that
161.88|4.16| is defined again. But in any case, focus now on the number
166.04|4.92| 15.4 as the error here. And in comparison, the best or second
170.96|4.2| best method, the second best was not even close. So the second
175.16|2.96| best method was, I think, a traditional computer vision
178.12|4.88| method. And it was like around 26.2% error. So you can see it
183.0|3.16| was almost twice as good as anything else out there. And
186.16|4.6| that is really when people Yeah, pay attention to deep learning
190.76|2.68| and convolution network. And that is really when it started
193.44|5.84| to take off. But also nowadays, I mean, 15.4%, that would be
199.28|3.44| actually pretty bad. Nowadays, you can, using the right
202.72|6.24| architecture, achieve even a top five error of only 3%. So
210.24|3.68| besides having many layers here in this architecture, I will
213.92|3.08| also actually show you a better or not better, but a simpler
217.0|3.4| illustration on the next slide. But instead of having multiple
220.4|3.84| layers, one of the novelties here was also that the authors,
225.08|4.32| Alexander Kroshevsky, so skipper and Hinton, that they used on
229.8|5.12| GPUs in a very effective way. So I think back then, GPUs were
234.96|4.92| pretty small, still regarding the memory. So here, what they
239.88|5.08| did is they split the work into like a two parallel processing
244.96|3.84| steps. So you can see this is here, the input image, it's, I
248.8|6.32| think 2224 times 224. And they split it into two parts. So one
255.12|4.84| is this upper part. And one is the lower part, where they kind
259.96|3.48| of process things separately, sometimes there was some
263.44|6.0| communication between those. But yeah, these were largely run in
269.44|4.92| parallel to really make things faster. And then in the end, the
274.36|3.92| results were concatenated into a fully connected layer. And that
278.28|4.24| one was then attached to that one was then the output layer, I
282.52|3.0| think this might actually be the output layer, sorry. So here,
285.52|4.0| this is the last, that is the last layer before the output
289.52|4.56| layer. So the output layer is essentially this whole thing
294.08|7.72| here from 4096 to 1000, where the 1000 are the number of
301.8|4.28| classes here. So yeah, here's a simpler visualization of the
306.08|4.4| same architecture, except that it is now on a single GPU. It's
310.68|4.04| usually how we would nowadays trainer Alex net. And we will
314.72|3.04| also do that later in this lecture, I'll have an
317.92|3.6| implementation of that that I will show you. So what we can
321.52|4.76| see here, see here is the first feature map. So the input image
326.28|5.78| would be actually here, the 224 times 224 input image, and we
332.06|4.5| have three color channels. And I will also explain to you at the
336.56|2.92| end of this video, how we work with different color channels.
339.96|5.72| So the first feature map has then 96 channels, then 256
345.68|7.08| channels, then 386, then thread 84. Actually, I think this is a
352.92|6.56| typo here, I think it should be also 384. If we look back on the
359.48|4.16| previous slide, they had 192 plus 192 from the two GPUs,
363.64|3.36| which would be 384. So in that way, I think it was a minor
367.0|3.16| typo. But honestly, in practice, it would not matter much
370.16|4.02| whether it's two or two more to fewer channels, it doesn't
374.18|4.3| really matter. Yeah, and then 256 channels, and then they
378.48|8.36| reshape this one into a long vector with 4096 activations, I
386.84|3.36| will also show you in the code how that works. It's actually
390.2|5.28| pretty simple to do using reshape. And then this is a
395.52|5.76| fully connected layer here. And this is the output layer. So we
401.28|3.4| have 1000 classes. And here, this is essentially like a
404.68|4.04| multi layer perceptron. Again, if this looks a little bit
408.72|3.28| abstract, we will see in the code example, how that looks like
412.0|3.0| in pytorch. And sometimes, I think it's easier to look at it
415.0|3.44| actually in pytorch, because it's a pytorch is such a easy to
418.44|2.6| use library in terms of the multi layer perceptron and
421.04|2.74| convolution network implementations, that sometimes
423.78|3.3| just looking at the model there can even be simpler than
427.08|1.96| looking at the images here.
430.92|4.88| Yeah, so here is the snapshot of the image net data set, to which
435.84|3.92| the Alex net was applied to. And I will actually zoom in into
439.76|4.54| that on the next slide. Another interesting aspect here, I just
444.3|3.1| wanted to highlight, it's also from the same paper, is that
447.4|1.94| they looked at these different
450.52|4.16| yeah, kernels of the network at different stages during
454.68|3.9| training. And also, what was interesting is, yeah, the types
458.58|5.02| of kernels that were learned. So some are essentially edge
463.6|3.76| detectors. So these are essentially things for detecting
467.48|4.9| vertical or diagonal edges, I will actually zoom into that or
472.38|3.64| discuss this in the next video, what that actually means and how
476.02|4.36| this can be interpreted. So but yeah, let's zoom in on the image
480.38|5.04| net here. So image net, that was still very popular data set,
485.54|4.56| consisting of 1.2 million images, and 1000 classes. And if
490.1|2.88| you recall, I'm not sure if you actually watched those, but the
492.98|2.84| stuff in the news videos that I optionally make, you don't have
495.82|3.88| to watch those. But in these videos, I had an example, a
499.7|4.6| recent research effort, where people started to clean up image
504.3|3.08| net, because sometimes there can be multiple objects, I just see
507.66|2.56| there is such a case here. For instance, we have a motor
510.22|4.52| scooter here. But there's also a car. So yeah, I'm predicting
514.74|3.32| car wouldn't be wrong either. But this label here, the only
518.06|2.92| correct label for this image is motor scooter, because each
520.98|3.3| image has only one label here. So in this case, yeah, some
524.28|3.42| people try to clean up image net or here, for instance, we have
527.7|4.6| cherries and a dog. So it's actually not so simple to make a
532.3|3.96| prediction sometimes because yeah, there are multiple
536.26|2.8| possibilities. But if you're only given one class label, your
539.06|4.32| network might be predicting the right thing. But it's different
543.38|4.24| from what the label says. So let me see. So yeah, for example,
547.62|4.68| another one example would be actually this cherry example. So
552.62|3.68| how this accuracy stepping a step back how this accuracy is
556.3|3.68| measured, it's the so called top five performance or top five
560.2|5.3| accuracy. And it is essentially if the correct prediction is in
566.14|4.04| so the label is among the top five predictions of the model. So
570.18|3.96| if you recall how the softmax function works, it's essentially
574.22|4.32| class membership probabilities. So we have a softmax activation
578.58|5.56| vector consisting of 1000 class membership probabilities. So
584.14|5.32| here, people look at the five largest probabilities and get
589.46|3.64| the class labels for those and these are listed here. So and
593.1|3.8| these bars represents the confidence for each of the
596.9|6.48| classes. So here, let's focus in on this image again. So the five
603.74|6.28| classes that the network returns estimation, grape elderberry,
610.02|6.24| Fort Shire, bolt area and current. So we can see though,
616.54|4.28| that so this would be actually counted as a misclassification
620.82|5.16| because the most confident label is dalmatian, although in truth,
625.98|2.84| it's a cherry. So you can see it's actually might be even
628.82|3.12| impossible to get 100% accuracy in the first place that some
632.34|3.8| images that are a little bit tricky. Let's take a look at
636.14|4.44| another one, this year, this car. So here, the true label is
640.62|3.72| grill, and the network predicts are the five most confidence,
644.5|3.32| confident predictions are convertible grill, pickup,
648.02|4.44| beach wagon and fire engine. I would say actually, so the most
652.46|2.44| confident prediction is convertible for this network. I
654.9|3.48| would say this is, this is correct, right? So we this is
658.38|4.52| indeed convertible. But your grill is another prediction by
662.9|3.28| the network. And here, this is counted as a correct
666.18|2.88| classification, because even though it's only the second most
669.3|3.12| confident predictions, it's among the top five, and the top
672.42|4.12| five matches this image here. So yeah, it's a little bit tricky
676.54|3.88| to evaluate on this image data set, but just wanted to explain
680.42|4.48| to you how the accuracy is computed. In any case, so this
684.9|4.8| is how the image net data set looks like. And Alex net, at
689.7|3.24| that time was really a breakthrough for image
692.94|4.4| classification measured on this data set. Yeah, and it's also
697.36|4.52| worth pointing out what the input size is again. So they
701.88|6.1| took original images down sampled them to 256 to 256, and
707.98|4.0| then produced random crops. And the input images to the network
711.98|6.68| were then essentially 224 times 224. Even if it sounds like
718.66|5.28| 224 times 224 is not much. Like in common standards, if you
723.94|3.96| think of your cell phone where you have millions of pixels, so
727.9|3.96| 224 times 224, plus or times the three color channels, it's
731.86|4.0| actually pretty small. But in the grand scheme of things, if
735.86|3.48| you think of a neural network, for instance, a multi layer
739.34|2.84| perceptron that takes all these inputs, and you have a fully
742.18|6.4| connected layer, this is still, I mean, 150,528 features.
748.58|3.04| Yes, that we have here as input. So this is something that
751.62|3.08| wouldn't be really manageable by any other machine learning
755.06|3.12| technique, for instance, a multi layer perceptron would really
758.18|5.32| choke on such large inputs. And also other methods, like gradient
763.5|4.28| boosting, or random forests, or anything, basically. So it's
767.78|5.04| actually, even though it doesn't look like it 24, 224 times 224,
773.0|2.02| it's actually a pretty large input.
775.02|4.44| All right, so talking about the CNN architectures, I will, like
779.46|4.8| I promised, dive into more detail in the next lecture. But
784.26|4.4| here's just a brief overview. So here are different architectures
788.7|4.16| from a paper that goes back to 2016. There are nowadays, more
792.86|3.16| architectures, new architectures that are not included here, for
796.02|5.44| example, mobile net and dense net and others. But still, it's
801.46|3.68| a very nice summary of the most popular ones here. And I also
805.14|3.64| like this visualization. So maybe let's, let's take a look at
808.78|3.12| the left one here first, the top one accuracy that's on image
811.9|3.36| net. So we discussed before top one accuracy, maybe a little
815.26|3.52| bit problematic. But yeah, that's what we have here. What's
818.78|3.8| interesting really is like, just having a reference to all these
822.62|3.84| architectures in one slide, essentially. So that's the Alex
826.46|4.64| net, there's a, I think bn means with batch norm, and then the
831.1|3.92| network, any n n is a network and network, we'll also talk
835.02|4.76| about this next lecture, the Google net, resonate, resonate,
839.78|3.68| I would say is maybe still the most popular architecture, it's
843.46|4.2| a certain type of architecture using residual connections, it's
847.66|4.72| a very important concept that we will talk about next week, VGG,
852.7|3.78| and so forth, the inception network, I'm planning to talk
856.48|3.02| about some of them, not all of them. But yeah, let's maybe take
859.5|6.24| a n n, resonate, VGG, and inception as the ones. So to
865.74|4.48| keep it manageable, these are among the most popular ones. So
870.22|3.96| here, they are showing just the accuracy here on the right hand
874.18|2.56| side, this is slightly more interesting. It's also looking
876.74|4.6| at the parameter size. So here's like the legend for the parameter
881.34|5.32| size, the number of parameters like from 5 million to 155
886.66|3.6| million. So you can see, Alex net is approximately, I would
890.26|5.16| say, somewhere, maybe around 65 million. And then we have
895.42|5.46| something like a VGG, which is 155 million parameters
900.88|3.18| approximately. And you can see there are other networks, for
904.06|4.74| example, I think this is inception version four, which
908.8|4.78| has only maybe 35 million. And even though it doesn't have more
913.58|3.52| parameters than VGG, it has a better accuracy. So more
917.1|2.68| parameters doesn't mean necessarily better accuracy, you
919.78|3.28| can see, Alex that has actually more parameters than any one of
923.06|5.16| these. Still, the accuracy is much lower. So resonant, for
928.22|2.48| instance, with the residual connections, you can actually
930.7|3.88| boost the accuracy or inception has an auxiliary loss, for
934.58|3.68| instance, that can also be helpful. In any case, this is
938.5|2.68| the brief overview. So you know, there are many different types
941.18|2.8| of architectures, and Alex net is only one of them. It's
943.98|2.28| actually here also at the low end in terms of the top run
946.26|3.8| accuracy. So we will talk about much better models in the next
950.06|3.54| lecture. But I think Alex net is still a nice introduction to the
953.6|2.9| topic of convolution networks. And I will also of course show
956.5|3.76| you a code example using Alex net at the end of this lecture.
962.42|4.04| Oh, yeah, one more important aspect to talk about is how we
966.46|3.28| work with color channels. In the beginning of this lecture, we
969.74|3.28| introduced the Lynette architecture, which was just
973.02|2.86| working with black and white images, which only have one
975.88|3.9| color channel. But yeah, Alex net, for instance, works works
979.78|3.32| with image net, which is in color, we have color images. So
983.1|4.0| how do we deal with that? So yeah, let me explain it maybe
987.1|5.66| step by step. So maybe focus now only on the thing I'm framing
992.76|4.34| here right now, that is one color channel. It's called an R.
997.1|4.92| And previously, what we did is we used a kernel for that that
1002.02|7.68| was just like a matrix, n by m matrix, like this. And then yeah,
1009.7|3.2| we applied the convolution. So we were sliding this over the
1012.9|6.56| image, and then computing the feature maps here. So one of the
1019.46|4.16| kernel applied to one receptive field yields one pixel in the
1023.62|9.64| in the feature map here. Okay, now, what we have is we have
1033.26|5.36| multiple color images. So for instance, let's say we have our
1038.62|5.16| g, the RGB format, red, green, blue. So we have also know, a
1043.78|8.64| green color channel, and a blue color channel. So this is our
1052.42|11.68| input image here, the whole thing here. So input image. And
1064.1|5.0| then corresponding to this input image, we also have a kernel
1069.22|3.76| that has the same number of channels. So notice, now we
1072.98|10.4| also our kernel has three channels. And we apply each
1083.38|2.84| kernel layer, or each kernel channel only to the corresponding
1086.22|3.96| channel in the input image. So red goes with red, green goes
1090.18|3.44| with green and blue goes with blue. It's a regular
1093.62|5.36| convolution. And then once we computed that we sum over these
1098.98|5.28| channels. So the kernel and the input is matrix, sorry, element
1104.26|3.4| wise, multiplication and to some, right, so it's just like
1107.66|4.48| the regular convolution. But then we are summing. After that,
1112.14|4.88| we are summing over the channels see in. So that's the input
1117.02|4.8| channels, we're summing over them. And this whole thing here,
1121.94|5.52| everything that's going on here, this will give us one feature
1127.46|6.6| map. So this whole thing results in one feature map. So how do we
1134.06|3.4| get multiple feature maps? That's essentially an extension
1137.46|3.4| of what we talked about earlier, we would just use multiple
1140.86|6.08| kernels. So we have here, kernel, k one, kernel, k two,
1146.98|4.92| kernel, k three, kernel, k four, kernel, k five, and each kernel
1151.9|5.28| will produce one feature map. So here, I don't have really many
1157.18|2.96| colors left here. So this one will, for instance, and produce
1161.14|8.88| this feature map, and this one will produce this feature map,
1170.02|3.12| and so forth. So that's how we get the different feature maps.
1173.66|3.32| And yeah, this is essentially it. So here at the bottom, just
1176.98|4.84| just highlighting again, the input images, n times n times C
1181.82|4.24| n. And in pytorch, usually we have another dimension. So we
1186.06|5.72| have n as the number of images in the batch, c as the
1191.78|4.48| channels, w as the width, and h as the height. Sometimes people
1196.26|4.36| use this format, where you have the number of images, the width
1200.66|3.8| height and the channel last, but that's just a minor detail. You
1204.46|3.32| don't really have to worry about this here on the site. And in
1207.78|4.6| the next video, we will briefly talk about what is seen and can
1212.38|22.84| see and then we will finally get to the code implementation.