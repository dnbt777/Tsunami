start_time|end_time|text
0.52|2.32| Yeah, let's now take a look at how we train a logistic
2.84|2.92| regression model. By that I really mean like computing the
6.12|3.16| gradients of the loss function with respect to the weight and
9.28|3.4| bias parameters in the logistic regression model, so that we can
12.68|4.4| then use gradient descent to update the model. And then in a
17.08|4.04| later video, we will see how we implement that in code to do the
21.12|5.52| actual practical training. So yeah, let's take a look at the
26.64|3.44| logistic sigmoid function again. So here on the left hand side,
30.08|2.68| that's the logistic sigmoid activation function that we
32.76|2.8| talked about before, where we have the net input on the x
35.56|3.92| axis and the output on the y axis, it has this sigmoidal
39.56|4.56| shape. And you can already see, just by looking at this
44.12|5.32| function, what the gradients might be. So you can see here,
49.44|3.04| the function on the answers, it's relatively flat. So the
52.48|3.76| gradient should be also very flat, like zero around that
56.24|4.36| region. And the steepest part is here. So this should also be
60.6|4.1| where the gradient is the largest or let's say the partial
64.7|5.78| derivative with respect to the input is the largest. Now, on
70.48|4.36| the left on the right hand side, I was computing the derivative
74.84|4.92| of the sigmoid function with respect to its input. So yeah,
79.76|4.16| if you use the simple calculus rules, so that's how you would
83.92|3.2| all compute the derivative of this part, right, because you
87.12|6.12| have the derivative of the, what is it called numerator, which is
93.28|3.88| e to the power of minus z, the one cancels, and then you have
97.16|5.76| this square term in the denominator. And when you solve
102.92|2.52| that, I'm not doing it here. So when you solve that, if you're
105.44|3.08| interested, I've done that in the Python machine learning
108.52|2.64| book, I think it's in chapter 12, somewhere, but I can also
111.16|1.88| share that if you're really curious about that, but you can
113.04|2.76| probably also find examples of on the internet. It's quite
115.8|4.48| involved, it will take you a few sheets of paper, I guess. But
120.28|3.24| what the result is, is this one here, on the right hand side,
123.72|3.6| that's the derivative of the logistic sigmoid function. And
127.32|2.68| you can see it's relatively simple, right? It's just the
130.0|4.32| sigmoid function times one minus the sigmoid function, right. So
134.32|3.44| that's what I mean, it has nice derivatives. That's actually one
137.76|3.48| little Yeah, not so nice part about this activation function,
141.24|2.8| it's derivative, we will talk about that in a future lecture.
144.24|3.36| So what's not so nice about it is actually that these, these
147.6|3.16| parts here are of the derivative are actually zero. So here, we
150.76|5.8| don't have any power to update the function. So if these terms
156.56|3.52| are zero, this might be a problem when we have multilayer
160.08|5.0| neural networks, and then you have a chain rule where part of
165.08|4.24| the chain rule is zero, because then the whole loss gradient
169.32|2.44| becomes zero. But this is something we will talk about
171.76|2.88| later. So let's now just focus on how this function looks like.
174.88|4.4| So in the right, lower side here, I have the derivative of
179.28|3.48| this logistic sigmoid function. And you can see like by as with
182.76|5.24| our intuition here, this part, where z is zero, that's where
188.0|2.56| the gradient is the highest or the partial derivative is the
190.56|3.56| highest, you can see the partial derivative is point two, five,
194.16|4.2| the largest value. And then for very negative and very positive
198.36|4.84| inputs, the derivative goes down to zero. It's Yeah, you can see
203.2|3.32| that here where it's also very flat, right. So this is how the
206.52|4.84| logistic sigmoid derivative looks like. So here's how the
211.4|5.68| loss function looks like. So at the bottom, here, this is again,
217.08|8.88| my negative log likelihood loss I talked about in the previous
225.96|3.4| in the previous video. And me like we talked about before,
229.36|2.36| there are two parts really of this loss function, you can
231.72|4.44| really think of it as the part when the class label is one and
236.16|4.2| the part when the class label is zero. So here, we really talk
240.36|5.56| about the true label in the data set, the label of the training
245.92|3.04| example. And this is also the true label. So these are the
249.36|4.52| true labels provided in the training data set. Again, we
253.88|2.64| only compute, I mean, this might sound trivial, but just to
256.52|4.0| recap it, we only compute the loss function during training,
260.52|1.96| not during prediction, right, when we have a test set or
262.48|2.56| something, and do a prediction, we don't use the loss, it's
265.08|3.72| really just to find the weight parameters of the model. So we
268.8|4.84| are given these true labels from the training set. So what
273.64|4.6| happens if the true label is one, let's, let's consider this
278.4|3.88| scenario of the true labels one, we have one here right on on
282.28|4.32| the bottom, and we have one here. And if we have a one here
286.6|2.96| on the right hand side, then this whole term here becomes
289.6|3.76| zero. And then we have zero times something. So this whole
293.36|4.56| term cancels. So if the true label is one, we really only
297.92|4.84| focus on this part here, the true label is one, then our loss
302.76|4.24| function is minus lock. And I can just write this part as a
307.0|6.88| the activation. It's minus lock of the activation. Now, if my
313.92|5.12| arm label is zero, then let me erase this as maybe a little
319.04|7.5| bit messy here. So we set minus lock A. And for this right hand
326.54|4.42| part, if y is zero, then this part will be zero, zero times
330.96|4.84| something cancels. Here we have a zero. So this will be one. So
335.8|6.84| if the true label is zero, then the loss function is minus lock
343.64|1.44| one minus
348.2|5.96| a. Now let's take a look at the shape of these curves here. So
355.52|5.4| if we let me use, I should have maybe used yellow minus lock one
360.92|5.24| minus A. So it matches this orange or yellow line here. So
366.16|4.52| you can see, for the value here of the sigmoid function. So this
370.68|2.96| is really like the logistic sigmoid, the class membership
373.64|7.2| probability. And recall, this one is for the black color. This
380.84|0.6| is for
383.96|2.92| the class label equals one, so the class membership probability
386.88|4.64| for one plus one. So this is really like this probability
391.52|7.16| here. So if what we want, so what we want is this probability
398.68|6.24| to be high, if the true label is one. And we want this probability
404.92|4.48| to be low, if the probability is zero, so but we can also write
409.4|1.24| this as one minus
410.64|9.96| y equals zero. This is it's easier to think about. So let's
420.6|3.0| let's take a look at now what happens if this probability here
423.8|4.92| is high. So if this whole term is high, this means if we have a
428.72|5.58| low probability that this is indeed class zero. So if we have
434.3|6.18| a term here, we have a low probability for this one, this
440.48|3.32| one will have the whole term with a one minus included will
443.8|4.4| have a large probability. And you can see, we have a high loss
448.2|3.56| in this case, if a probability for class one, so this is really
451.76|5.52| like the class one probability. If this is high at one, then we
457.28|3.6| have a very large loss, you can see that. So the loss approaches
460.88|9.28| infinity, if we have a high probability, vice versa, the loss
471.96|3.84| approaches zero, if we have a low probability, right, so you
475.8|6.08| can see that on the closer I get to a low probability, the closer
481.88|4.32| I get to a low probability that the class labels one, the smaller
486.2|5.0| the loss, because a low probability for class one means
491.4|5.2| a high probability for class zero, which is what we want. So
496.64|6.68| here, if the true label, if the true label is indeed zero, we
503.32|5.08| want a low probability for class one. So here, we have a zero
508.4|3.08| loss, if we have a zero probability for class one,
511.5|3.82| because then the probability for y equals zero will be large
515.32|5.36| because of this relationship here. The same way, now, let's
520.68|4.76| take a look at the blue color, the case when the class table is
525.48|4.52| one, the same way, when we have a low probability for class
530.0|4.16| membership, one, we have a high loss, it approaches infinity,
534.2|5.24| right? Because I mean, we will never really have a probability
539.44|4.2| of zero, we will hopefully have something like very, very small,
543.64|4.48| because otherwise, it will crash our lock function. Or Yeah, so
548.12|6.56| we will have lock of minus lock of zero, right? So we'll be a
554.68|6.8| very small number. And then this approaches oops. This loss
561.48|3.76| approaches infinity, basically, if we have a low probability,
565.24|5.12| and we have a high loss, sorry, we have a high. If we have a
570.36|2.04| high probability, the loss will be very low. That's what I
572.4|4.28| wanted to say. So the takeaway here is really, this is how our
576.72|3.06| loss function looks like, what we want is we want to have a
579.78|4.78| high probability for the right class and a wrong probability,
584.56|4.04| like a low probability for the right class, or a high
588.6|2.88| probability for the wrong class, consequently, will result in a
591.48|3.08| very large loss. And you can see it's like, steeply increasing
594.56|3.2| here. So that's the takeaway. So there's a large penalty for
597.76|4.32| making a wrong prediction. Yeah, how does the learning rule now
602.08|3.08| look like? I mean, this is the same gradient descent rule that
605.16|3.56| we used before, when we trained a linear regression model, or
608.72|3.44| add a line using gradient descent. For that one, what we
612.16|4.68| needed was the derivative of the loss function with respect to
616.84|2.72| the weights. So that's the partial derivative of the loss
619.56|2.44| function with respect to the weight. And we also compute the
622.0|2.08| partial derivative of the loss function with respect to the
624.08|4.46| bias, that's the same concept. So in order to do that, we can
628.54|3.62| compose it into three terms, that's the same as we done, we
632.16|4.48| have done for edeline and linear regression. So we compute the
636.64|2.6| derivative of the loss with respect to the output of the
639.24|3.16| activation function, then we compute the derivative of the
642.4|3.16| activation function with respect to the input for edeline, this
645.56|3.6| was just one because the activation function was your
649.16|3.8| identity function. And then what we also compute is the
652.96|3.72| derivative of the net input with respect to the weight. And that
656.68|5.24| was just x, right, xj, similar to edeline. So here at the
661.92|6.1| bottom, I've written this out. So all these three terms. So
668.02|2.66| this one, by the way, this is the negative log likelihood
675.28|3.36| hood loss that we talked about in the previous slide. And if
678.64|2.26| you look at this, the only thing that's really different from
680.9|4.94| edeline is that these and these values are of course different
685.84|5.64| because we have a different loss function and edeline. We had the
691.9|4.3| MSE, right, where the derivative, so the MSE was, for
696.2|4.12| example, written like this, let's say like this with the one
700.32|3.52| half in front. And we can also do the one over n if you like.
704.44|6.38| But okay, so let's do it. And then we bring the two up front
710.82|3.6| for the derivative. So it's two over two n, so the two
714.42|12.02| cancels. So we just have one over n times just one minus
726.8|6.64| should be y hat minus y. So that would be the derivative of our
733.76|3.8| MSE. Now, of course, we don't have an MSE, we have this
737.58|2.58| negative log likelihood for which we have the following
740.16|3.56| derivative with respect to the activation function with respect
743.72|8.96| to its input. And this one for edeline was one. And this one is
752.68|3.48| the same because the net input is the same. Now, the only thing
756.16|2.76| we have to do really is to put those together, right, we have
758.92|2.96| to just multiply them using the chain rule. So it's the same
761.88|3.44| like for edeline for the name just looked simpler. But if
765.32|8.84| edeline we just had one over n times y hat is y times x j,
774.2|4.4| right. So that was one for edeline for the logistic one, it
778.6|2.68| may look more complicated because we have no this term and
781.28|2.8| this term. However, there's something nice that's happening.
785.16|3.8| So we can actually show what I've done here, we can actually
788.96|4.56| simplify this. So this part and this part when we put them
793.52|6.52| together, it simplifies to this one here. So you can work out
800.04|3.0| the math if you like, but it's a simple, very simple derivative
803.04|4.92| here. So you can see that these cancel each other nicely. And
807.96|4.56| this is why I said that the logistic regression or the
812.52|3.8| sigmoid functions has nice derivatives. That's because
816.8|4.04| things cancel here nicely. And then we just add the x to it.
820.84|3.64| And you can see, actually, this looks exactly like the edeline
824.48|3.24| learning rule, right? This looks exactly like the linear
827.72|4.24| regression one, right? Isn't that quite cool. So here is just
831.96|4.48| from the previous slides that we had on edeline and linear
836.44|3.56| regression. So this was the stochastic gradient descent
840.0|4.04| learning rule here, where we had the initial weights, the for
844.04|3.96| loop over the training epochs, and then the for loop over the
848.0|3.4| training examples, it could also be for mini batches. Then we
851.4|4.12| compute the prediction, the gradients here. And then we do
855.52|2.92| the update here. And then we have the learning rate at here.
859.68|4.8| We can use exactly the same rule for logistic regression. Also
864.48|5.24| note, there was also discussion on Piazza. We can actually
869.72|2.44| write rewrite this, because I think I've done it the other way
872.16|4.48| around in code, we can actually rewrite this as on, of course,
876.64|4.32| like y hat minus y, right? So same thing, because with minus
880.96|3.52| and minus, and that is what I had in the previous slide, if I
884.48|4.84| go back, I have a minus y instead of y minus a, so I
889.32|4.92| should say that a is equal to y hat here. So that's the output
894.24|4.36| of the logistic regression model. So a y hat are the same
898.6|6.62| thing here. So let me write just a year. So what I mean, we can
905.22|4.98| also write this, maybe it's if it's more clear, I can erase
910.2|10.08| more. Let's maybe write this as a minus y, xj. And this one
920.28|7.4| should be just a minus y. So this is exactly the same
927.72|2.84| learning rule as for Adeline. What's the difference? Now, why
930.56|3.16| is this a logistic regression? Well, the big difference here is
933.72|4.2| that a is computed differently, right? So a is now computed by
938.16|5.32| by others on nonlinear function. Whereas for linear regression,
943.72|4.36| it was Adeline, it was just computed as the identity
948.08|3.68| function. So in the case of Adeline, or linear regression,
951.76|4.72| this was the net input. So but yeah, that is, again, why I said
956.48|2.28| it has nice derivatives, because we don't even have to change our
958.76|3.2| learning rule. The only thing we have to change is how y hat or
961.96|7.2| basically a is computed. All right, so a few last things
969.16|4.68| about this. So here, we can think of this as the whole
974.0|3.08| computation graph. Again, this is our logistic regression
977.08|2.96| computation graph. We haven't talked about this output yet,
980.04|7.04| right? So we do the training here. So here's where we
987.08|6.12| compute the arrow. So we have a true, let's say, a true label.
995.12|7.64| Let's call it true label y that goes in here. And here, what
1002.76|4.88| comes out is our a or y hat, let's call it y hat. It's
1007.64|2.0| actually a probability. So there's maybe more clear to call
1009.64|6.92| it a. So we have our a and our true y. And from that one, we
1016.56|2.28| compute the negative log likelihood, compute the
1018.88|3.44| gradients, the gradients, or the pressure of the loss with
1022.32|4.28| respect to each weight and also the bias. So I'm actually not
1026.6|3.2| showing the bias I just see. So it should be technically also
1029.8|4.88| bias unit. So we compute that one, and then we update the
1034.68|3.92| weights and the bias units with that one. And this right part
1038.6|2.96| here, this comes after training, this is just for the prediction.
1041.76|2.76| So for that one, we can use a threshold function similar to
1044.52|3.56| the line. So logistic regression, we can use the
1048.12|4.44| following threshold function here to compute the real y hat.
1052.8|3.44| So I should have maybe be more consistent and say y hat is the
1056.24|5.48| predicted class label. And a is the probability class membership
1061.72|3.72| probability, I will be more careful of that when I write the
1065.44|4.92| code for the next video. Anyways, so we can say with this
1070.4|3.72| threshold function of the probability. So this is a if
1074.12|5.16| this is greater than point five, then return class label one, and
1079.28|3.76| otherwise return class label zero. Actually, we can do it
1083.04|4.28| even more computationally efficient during prediction, we
1087.32|3.16| can even skip the activation function, we can just operate
1090.52|5.44| with z, we can say if the net input is greater than point, if
1095.96|4.36| it's greater than zero, then the label is one, otherwise it's
1100.32|5.68| zero. Why is that? If we take a look at the logistic sigmoid
1106.0|5.32| function again, so here, that's the net input at zero. So at
1111.32|4.0| zero, the output is point five. So we know, so we, we can say
1115.36|5.36| everything above here, above point five is class label one,
1120.72|9.32| say y hat, class label one, and below here, y hat is class zero.
1130.4|4.56| But we know if we have the threshold point five, it
1134.96|3.56| corresponds to a net input of zero. So we can also just say if
1138.52|3.56| the net input is greater than point greater than zero, then
1142.08|3.08| it's class label one, if it's smaller than zero, then it's
1145.16|3.52| class label zero. So that's just what I wanted to say about
1148.68|4.76| logistic regression. In the next video, I want to talk a little
1153.44|5.0| bit about the logits and cross entropy. These are just two, I
1158.44|5.68| would say, jargon words about or regarding logistic regression,
1164.48|3.48| logits and cross entropy, or just briefly discuss what those
1167.96|3.52| mean. And then I will show you logistic regression in the code
1171.48|3.08| example. And if everything in this video was a little bit fast
1174.56|4.04| and confusing, I think the code example will probably clarify
1178.6|3.12| that because then we will put everything together, we will do
1181.72|4.0| the forward pass, compute the gradients and update the weights.
1185.72|5.4| So what I mean is we will really implement this whole stochastic
1191.16|2.92| gradient descent learning rule in code and that I hope
1194.08|15.0| clarifies everything.