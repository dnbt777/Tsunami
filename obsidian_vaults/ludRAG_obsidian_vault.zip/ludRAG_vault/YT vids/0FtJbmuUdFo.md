start_time|end_time|text
0.92|3.16| Yeah, but before we dive into convolutional neural networks, I
4.08|3.8| actually wanted to motivate the problem of computer vision and
7.92|2.84| image classification first, because it's actually a pretty
10.76|5.4| hard task. And I think you don't maybe fully appreciate the good
16.2|2.56| performance of convolutional networks, before you thought
18.76|3.16| about how difficult computer vision and image classification
21.92|5.72| actually is. So for instance, if you take a look at this cat
27.64|4.8| image here, so it's the same cat and you as a human, you probably
32.44|3.72| have a easy time telling that this is the same cat in the same
36.16|3.8| cat picture, right. But for a computer or for, let's say,
39.96|2.68| standard neural network, it's actually a pretty difficult
42.64|5.2| task. So why is that? I mean, if you remember how you used
47.86|4.1| multi layer perceptrons, you were essentially concatenating
51.96|6.3| these image rows into a one long vector, right. So if I have,
58.26|5.86| let's say this is the first row, and this is the second row, and
64.12|3.4| this is the third row. So usually how that would look like
67.52|8.76| you would create this long vector as input to the multi
76.28|6.0| layer perceptron, then you have your first hidden layer, and
82.44|3.4| everything is fully connected, right. So I don't want to draw
85.84|5.04| all of it, but it would be a pretty dense network. So there
90.88|3.08| are some other challenges with that. But if you recall how you
93.96|4.16| would compute the activation here, it's essentially a
98.12|7.48| weighted sum of the weights and the inputs plus bias here. So in
105.6|3.6| that way, you are essentially summing up the feature values,
109.2|3.6| right. So and if you have an image like that, it's the same
112.8|2.44| image as the one on the right hand side, but everything is
115.24|4.52| darker. So what happens here is that all the activations will
119.76|3.2| actually be lower compared to this one here if you have because
122.96|3.52| if the image is darker, the pixel values are lower. So in
126.48|3.88| that way, also when the lighting and contrast and everything
130.36|4.56| like that changes, it will severely affect the network
134.92|2.44| performance. So one thing, of course, it's important to
137.36|3.32| normalize the images. But also, even if you take care, let's
140.68|3.12| say of the lighting and contrast, other issues are, it
143.8|2.88| might happen sometimes that the image is just like a little bit
146.72|2.8| on distorted, right. So here, you can as a human still tell
149.52|4.16| it's the same cat, right. But if you take a look at this sum
153.68|7.56| again, so now, for instance, let's say on the left hand side,
161.52|2.84| when you take a look at this pixel region, this pixel region
164.36|5.12| might be contained here, higher up here, right. So if I have my
169.48|4.0| vectors, but then the same region is lower here on this
173.48|2.96| side, so it might be actually somewhere here. So in that case,
176.44|5.8| it would fall here. And here, and here, there are vastly
182.24|2.96| different weights involved when you compute the activations,
185.2|4.88| right. So everything has every every line, here's a different
190.08|2.84| weight. So you would compute totally different activations
192.92|3.68| again, depending on where the object is located in the image.
196.72|2.32| So image classification is actually a pretty hard task, if
199.04|2.24| you think about it in the context of a multi layer
201.28|4.32| perceptron. So how do we make sure that we get good
205.6|3.72| performance? Of course, yeah, for that one solution would be
209.32|3.0| the convolutional network. But before convolutional networks
212.36|3.6| were invented, what were some other strategies? So a classic
215.96|5.08| strategy was, for example, doing feature extraction manually. So
221.04|4.32| by that, I mean, instead of providing the input image, as
225.4|2.54| the input to the network, for instance, instead of having
228.08|3.32| iris flowers, the image input, what people would do is they
231.4|3.16| would study these flowers, or think about these flowers, and
234.56|3.0| think about what are some features that we can extract
237.56|2.52| from these flowers, and then we can just work with these
240.28|3.56| manually extracted features. So in the case of the iris flowers,
243.84|2.4| these features would be, for example, the sepal length, sepal
246.24|3.12| width, petal length, and petal width. So here, you essentially
249.36|3.4| had a domain expert, someone who really understands these flowers
252.76|4.76| and might have a hypothesis and say, Hey, maybe these different
257.52|3.6| iris classes, they differ, yeah, by the dimensions. But another
261.12|3.56| person also, I mean, might say it is maybe the color. So you
264.68|3.72| could also, for instance, think about describing the color as a
268.4|3.32| potential feature. But yeah, the bottom line is, we would use
271.72|3.28| these hand engineered features, we would think about the image
275.0|3.16| instead of just giving it as input and extract some features
278.16|3.6| manually. And another traditional approach would be
281.76|6.76| also, for instance, for face images, to get these or extract
288.52|4.52| these facial landmarks. So that is also a traditional technique
293.04|2.68| where people instead of when they did face recognition
295.72|4.44| provided the full images input, they would develop an algorithm
300.16|3.6| that maps these points to the eyes, the nose and the mouth,
304.0|3.48| and then do a comparison based on these facial key points.
307.48|3.36| That's another hand engineered, I would say hand engineered
310.84|0.88| feature technique.
314.28|4.72| Yeah, and also, one other traditional technique, it's also
319.04|3.08| kind of beneficial, though, still for convolution networks is
322.12|3.88| to pre process the images. So for instance, if you think back
326.04|3.88| of the MNIST data set, and the MNIST data set, all the digits
329.92|4.24| were already kind of cleaned from background, if you imagine
334.16|3.08| someone is writing on a piece of paper, the piece of paper
337.24|3.88| background was removed, it was just the image of the digit. And
341.12|2.88| also, they were all pretty centered in the center of the
344.0|5.84| image. But if you take a look at real world images, usually, you
349.84|2.64| don't just have the object of interest in that image, you have
352.48|2.68| a lot of other stuff there. So for instance, here, you have
355.16|4.08| like this cat in the park or forest here. And in traditional
359.52|3.76| computer vision, people would manually extract or also
363.28|4.32| develop some background removal tools to to first extract the
367.6|2.32| image before doing classification, because that
369.92|4.6| makes the task simpler. So basically, yeah, extracting
374.52|3.6| centering and cropping and things like that. Of course, this
378.12|3.08| can still be beneficial for convolution networks, especially
381.2|4.16| if the data set is small. Nowadays, however, if you have a
385.36|4.44| really large data set, millions of examples, convolution
389.8|3.36| networks can also perform well on these if all the other things
393.16|3.44| are included, because if you have a large amount of images,
396.96|3.6| then the network will learn how to focus on the important parts.
400.56|4.16| For instance, if the task is, let's say animal classification,
404.72|4.48| it will learn how to focus on the animal region in these
409.2|5.68| images, it will essentially learn the it will learn how to
414.88|3.96| extract these objects, there will be an implicit feature
418.84|4.8| extraction inside the conversion network, we will see that later
423.64|4.0| in this lecture, I will show you some examples of how conversion
427.64|2.88| networks learn and how they are able to learn these feature
430.52|3.76| extractors, essentially. So in that sense, it's also why we call
434.28|4.04| deep learning, sometimes feature learning or automatic feature
438.32|4.08| learning. So deep learning is essentially capable of
442.56|3.76| implicitly learning how to extract features, instead of
446.32|5.36| doing this manual feature extraction. So in the next video,
451.68|3.16| I want to then now finally talk about how these conversion
454.84|3.68| networks work. So we'll zoom in into one of the would say
458.52|3.6| earliest architectures and then describe to you all these
462.12|14.56| components step by step.