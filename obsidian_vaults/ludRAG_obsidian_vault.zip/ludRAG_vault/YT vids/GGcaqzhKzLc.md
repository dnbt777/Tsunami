start_time|end_time|text
0.2|4.4| Yeah, now let me show you a code example of linear regression and
4.6|4.14| add a line trained with gradient descent. So I prepared two code
8.74|5.14| files, one is called linear rigor, or regression, gd. So gd
13.88|2.86| here, this would be the regular gradient descent version. And
16.74|3.56| then I will train an airline model with stochastic gradient
20.3|2.8| descent. However, note, you can also do it the other way around,
23.1|2.4| you can train the linear regression model with stochastic
25.5|2.16| gradient descent, and you can train the airline model with
27.66|2.6| gradient descent. So it's kind of interchangeable. And if you
30.26|4.08| like, you can play around with that later on. So let's do one
34.34|2.84| thing at a time. So I have my watermark here again, just to
37.3|4.2| show you what software versions I'm using here. And then now
41.5|3.16| here, the linear regression model with gradient descent. So
44.66|3.48| what we're doing is we're training this model here. So the
48.14|3.6| training is up to this point. And then the threshold function
51.74|3.92| is only used later on when we do the prediction of the class
55.66|3.36| labels, that's after training. So for training, we don't need
59.02|3.88| the threshold function. All right. And yeah, again, like
62.92|4.82| know that they are very similar. So here on the left, so on the
67.74|3.68| left hand side, I have an overview of the code that I'm
71.42|3.88| implementing below. So now these two are exactly what I implemented
75.38|2.88| in these two notebooks, I was just screenshotting it to show
78.26|4.12| you that they are indeed the same. I have them on the left
82.38|1.96| hand side as linear regression on the right hand side as
84.34|3.92| Adeline. And they're exactly the same, the same code, except
88.74|2.78| after training, we can for Adeline, then here use a
91.52|3.26| threshold function to produce the class labels, but know that
94.78|4.44| these are indeed the same codes that are used here. So we will
99.22|3.16| go over these codes, of course, in this notebook. Alright, so
102.38|4.68| we initialize some stuff that we will be using some libraries, I
107.06|5.56| prepared toy data set here, just some simple data set containing
112.62|4.68| two features x one and x two. So tail is showing the last five
117.3|3.92| lines of this data set of the CSV file. And there are 1000
121.58|4.52| training points. So yeah, we have two features x one and x
126.1|4.48| two and one output value y. So this is a regression problem. So
130.58|4.28| it's a continuous output value here. So okay, let's start by
135.66|5.32| creating here our design matrix and pytorch. So here, we will
140.98|3.84| have a design matrix consisting of the two features, and then
144.82|3.88| the class label as a separate tensor. I'm also shuffling the
148.7|3.76| data set. So I'm shuffling it and dividing it into a training
152.46|4.6| and test set. So I'm again using this index trick that explained
157.06|4.32| to you earlier. Later, we will be using so called data loaders
161.38|2.64| when we use more complicated data sets like large image
164.02|4.2| databases, where we have then some automatic functions in
168.22|5.16| pytorch that do these steps for us. Here, I think it's sometimes
173.38|3.04| good to just see how you would do that conceptually, like
176.42|4.12| seeing or looking at the code to see what we are doing here. So
180.54|3.36| what I'm doing here is I'm creating these shuffle index
183.94|5.44| indices. So let me show you how they look like. So these shuffle
189.38|4.88| indices are just the indices one to 1000 shuffled. And then I
194.26|4.92| use them to select the training data. So first, I'm actually
199.18|3.24| using it to shuffle the data set. So here, this is just the
202.42|3.28| shuffle indices, I select all the data points in the shuffled
205.7|4.82| way, for both the training and also for both sorry, the
210.52|4.86| features and labels. So note that here, because we use this
215.42|3.44| same shuffle index, they are shuffled in a way that is
218.86|3.64| consistent, because otherwise, if we use different shuffle
222.5|3.48| indices, x might be shuffled differently than y. And this is
225.98|3.28| also why we just can't use simply this shuffle function
229.26|3.12| that is implemented in NumPy or pytorch, because the shuffle
232.38|3.0| function would shuffle them individually, and then the
235.46|3.8| features won't match to the corresponding labels anymore. So
239.26|3.84| what I mean is, so this one, this entry here might be then
243.1|4.12| belonging to train data point 1999, 998, by accident, if we
247.22|2.38| just shuffle them individually. So this is why we use a
249.6|5.18| consistent shuffle index. And then I select 70% of the data.
254.8|5.46| So this is just the size of how many data points are 70%. So
260.26|3.44| let me, this should be 700. Like that, right? Like, let me
264.1|4.8| double check that. Yeah, 700. But this is just in general
268.9|4.96| implementation that would work with any size of data set. And
273.86|2.76| yeah, this is how then I'm selecting the training and the
276.62|5.4| test set. So the first 70%, the first 700 data points will be
282.02|4.08| training and the remaining 70% will be for testing and the same
286.1|5.0| thing for the labels. And then here I'm normalizing. So this
291.14|5.56| procedure is also called standardization. It's kind of
296.7|3.04| yeah, giving the data the properties of a standard normal
299.74|2.76| distribution, it won't be a standard normal distribution. So
302.5|2.0| we don't change the shape of the distribution, but it will have
304.5|4.96| the same parameters. That means it will have zero mean and unit
309.46|4.4| variance. Alright, so after we've done that, we now
313.86|2.92| implement our linear regression model, that is where it becomes
316.78|5.58| more interesting. So we use this class based implementation,
322.36|3.22| because this is also something that we will be doing in pytorch
325.58|3.18| later for complex models. So pytorch gives us a lot of
328.76|2.3| convenience functions like convolution layers, fully
331.06|3.72| connected layers, and so forth. But we still apply the same
334.78|4.6| concept by saying what our parameters are, and then how we
339.38|2.94| use our parameters in which order, the backward function is
342.32|3.38| later something pytorch will implement for us automatically.
346.38|3.28| So pytorch will actually create this backward function for us,
349.66|2.96| we don't have to do it ourselves. Here, we do it
352.62|3.6| ourselves, because this is like a very low level implementation
356.22|4.36| where I do things from scratch. In pytorch. Later, we can just
360.58|3.12| use a fully connected layer and the backward function will be
363.7|3.96| done automatically. But I think here for now, it's maybe easier,
368.02|2.64| or not easier, but at least, like better for your
370.66|3.44| understanding, if we walk through this step by step, and
374.1|3.52| do it ourselves, before we rely on automatic ways of doing that.
378.22|3.44| So first, we define the number of features in the
381.66|4.24| initialization method. And then we assign the weights of our
385.9|3.64| model, we just use zero weights, can be also small random
389.54|3.8| numbers for this model, it does not matter. We initialize our
393.58|2.56| weights, we need, we need to know the number of features,
396.14|4.76| right? So we use that information here. Because, yeah,
400.94|3.6| the if I scroll up, the number of weights depends on the number
404.54|3.8| of input features, of course, let me go down again, we have a
408.34|2.72| separate bias unit, because it's computationally easier to
411.06|3.16| handle. So we don't have to modify the input features when
414.22|4.92| we get them from the training set. So we also initialize it to
419.14|3.6| zero, we only have one bias unit, so there's only one value.
424.46|3.48| And then we compute the net inputs. So this is similar to
428.06|3.92| the perceptron that we've used before. So we multiply x, the
431.98|3.88| features and the weights, and we add the bias. So I'm writing
435.86|2.36| this in a complicated way, you can technically I think you
438.22|9.32| could write it also as x at self dot weights plus self dot bias,
447.54|3.48| it should do the same thing. Not sure why I was using it. So in
451.02|2.56| a complicated way, I think I just wanted to show you that I
453.58|6.52| was using pytorch here. Okay. Yeah, so then we have the
460.1|4.76| activation. So the activations are just the net inputs, because
464.86|2.76| the activation function is a linear function. So I could
467.62|5.24| also could have done something like that on self deviation
472.86|7.12| function x and then return x and then use this one. So I should
479.98|9.48| use self and then just do this, basically. So it would be the
489.46|5.48| same thing should also work. That's not really matter. Okay,
496.94|3.52| then we get the activation. So now the view here is just to
500.46|5.24| make sure that the shape is the same shape. So we are sorry,
505.7|4.88| that this is like a singular vector. So it's one dimension,
512.14|4.44| not two dimensional, just for convenience. And then now in the
516.58|3.76| backwards method, what we are doing is we are computing the
520.34|3.28| gradient, this is what we have done on this in the slides. So
523.62|5.48| remember, the gradient is y, so the gradient of the loss
529.1|3.36| function with respect to y hat. So starting at the back, so we're
532.46|5.28| doing in two steps. So this is so if our loss function, let's
537.74|5.2| write it down again, if our loss function is y minus y hat
544.18|7.96| squared, then the derivative is two times y minus y.
552.14|7.88| Sorry, that should be the other way around. And then this should
560.02|5.32| be the derivative. All right, so that's what we have here. And
565.34|3.76| then we compute the gradient of y hat with respect to the
569.1|4.12| weights, which was x and the gradient of y hat with respect
573.22|3.36| to the biases minus one. And then we put these two things
576.58|5.96| together. So using the chain rule, the inner times auto, this
582.54|4.56| is what we've done in the slides. So we multiply the
587.1|4.28| weights as a transpose with y hat. So this is a little bit
591.42|2.64| tricky, all these types of things, the view and things like
594.06|4.16| that. This is really like to make the dimensions match. So
599.38|3.0| later on, we won't have issues with that when we use pytorch
602.42|3.04| automatic functions, because they will take care of it for
605.46|3.32| us. If we do things manually, we always have to make sure that
608.78|5.92| the dimensions are right. And then because we compute, or we
614.7|4.28| have gradient descent, based on the whole training set, we
619.26|3.72| divide by the size of the data data set, this is basically for
622.98|3.0| the mean squared error instead of the sum squared error. So
625.98|4.24| this is our the loss of the sorry, the gradient of the loss
630.22|3.68| with respect to the weights here. And this is the partial
633.9|4.72| derivative of the loss with respect to the bias. And then
638.62|3.0| we return the negative gradients. So this is exactly
641.62|6.12| what we have done in the slides. Now, we have a method where we
647.74|4.08| compute the forward path, the predictions, and then we can
651.86|4.24| compute the negative gradients. And these gradients will be
656.1|6.32| used then for updating the weights to minimize the loss
662.42|4.2| function. So here we have, we have the training and evaluation
666.62|7.2| functions. So check something. So here we have the loss
673.82|10.24| function. And yeah, that's the mean means where error loss
684.06|7.0| here. And here we are training our model. So now we have this
691.06|8.72| for loop, this is a batch gradient descent. So we have the
699.78|4.04| training function, which takes our model, the input data, the
703.82|4.4| number of epochs and the learning rate. So we also take
708.94|4.64| keep track of the cost or loss. I typed it as cost here, but you
713.58|1.16| can think of it as the loss.
714.74|7.36| Um, yeah, so what we do is we iterate then over the epochs. So
722.1|3.88| for each epoch, we compute the predictions. So this will be a
725.98|2.52| vector, my head will be a vector, because the predictions
728.5|3.72| are for the whole data set. Then we compute the negative
732.22|4.28| gradients using our backward model or method. And then we
736.5|3.72| update the weights and the bias. So like we discussed in the
740.22|4.32| slides, this is the learning rate times the negative
744.54|4.16| gradient. Let me see if I can bring up the slides here.
753.62|5.88| Somehow, it's not working. Okay. Um, just want to show you where
759.5|3.12| we are. Yeah, we are at this step here right now where we
762.9|4.44| update basically, so we compute the negative gradients here in
767.34|3.88| step B. And then we update right now with these negative
771.22|2.96| gradients. So that's what is going on here, the learning
774.18|2.0| rate times the negative gradient. So that's how we
776.18|4.72| update the weights. And this is it. And then we go up here. So
780.9|5.82| here, this is just for logging, that we are just logging. We
786.72|8.86| are just logging the loss, current loss, and print some
795.58|3.12| outputs, we print which epoch we are currently in, and the mean
798.7|2.36| squared error loss, because then we can see whether it decreases
801.06|5.16| or not. Actually, we don't have to compute that one because we
806.22|3.08| already had that from the first iteration is like a little bit
809.3|8.92| wasteful. I don't know why I did that, actually. Um, yeah, so I
818.22|2.64| think yeah, because otherwise, this would be the first I see
820.86|4.04| now, because this would be the zero epoch. And this is after
824.9|4.32| we updated, so I could actually technically remove that. And
829.22|6.3| then show it to you with starting at the zero epoch. But
835.52|5.04| then we won't know what the last gradient update looks like,
840.56|4.26| right? Because when we update the weights, and then we don't
844.86|3.12| compute the last prediction with updated weights, we don't know
847.98|3.48| how the final model looks like. So this way, in the last
851.46|3.88| iteration, we know also how the final model looks like, I mean,
855.34|3.14| we can do it other way, other. In other ways, we could have
858.48|5.02| this actually, let me see, we could actually comment this out.
864.02|5.28| And then outside the for loop, we could when the epochs here
869.3|4.3| have finished, we can compute the prediction, but it was just
873.6|3.06| fewer code, fewer lines of code and a bit simpler. Alright,
876.98|5.2| because here everything is fast anyways. Alright, let's define
882.18|2.76| that. And let's now run this model. So here, I'm not calling
884.94|5.68| this train function. Oops, what an error. Okay, I have not not
890.62|3.92| executed this. So we have to define this and define this. Now
894.54|4.6| we can still not train it. activation function is not
899.14|7.0| defined. Okay, I don't know why this should not be defined. Oh,
906.14|4.16| yeah, it should be a self. This is also something I just added.
910.3|2.28| So you don't have to use this activation function. It's not
912.58|5.28| doing anything anyways. Okay, so now it was training here. Okay,
917.86|4.6| you can see we start with a relatively high loss, like 1532.
922.66|3.88| Notice that let me scroll up. Again, to the data set, these
926.54|2.3| are relatively large values, which is why the mean squared
928.84|3.86| error loss is so large. If I would divide all these values by
932.7|3.32| a factor of 10, these mean squared error losses would also
936.02|4.68| be smaller by a factor of 10. So the absolute number doesn't
940.7|2.16| really matter. So you don't have to really pay attention to the
942.9|4.12| absolute number. What you want to see is the relative decrease
947.06|3.32| that it goes down over time. You can see the longer we train the
950.38|4.24| smaller the mean squared error becomes. So it's training here.
954.74|3.48| And you can see, there's a point where it doesn't go down any
958.22|5.84| much, it stays at 371. So that means it kind of converges and
964.34|5.2| it has probably reached a global minimum. So okay, what we see
969.54|4.1| here, let's plot the cost now, because remember, I was keeping
973.64|4.14| track of the cost, which is the loss over each epoch. It's just
977.78|6.6| like, to not confuse the loss for the stochastic rain descent
984.38|3.2| with the one over the epoch. But it doesn't really matter. The
987.58|2.64| terms are usually used interchangeably. Where was I?
990.74|3.7| Yeah, here. So here I have the cost that we can also call it
994.44|5.58| loss, actually, it's maybe easier. Let's call it loss. And
1001.9|2.88| I think I have the loss function that is called loss, which is
1004.78|2.52| why it was confusing. Okay, let's leave it at cost here.
1007.78|3.48| Alright, so we compute the cost or initialize it to an empty
1011.3|5.4| list here. And then in each iteration, we add the current
1016.7|3.64| loss to it. So this will be a list of all the losses over the
1020.34|4.04| training. So this will be a list of these values here. So we can
1024.62|4.88| plot that and take a look at how it looks like. So we can see it
1029.5|3.44| starts out very large, and then it goes down smoothly until it
1032.94|4.28| converges. So here, at that point, we can say the model has
1037.22|2.76| converged, it has probably reached the global minimum of
1040.02|4.04| the loss function. Alright, so now, after we train the model,
1044.06|2.8| we can now use it for prediction. So let's now
1046.86|3.24| predict on the training set and the test set. So this is similar
1050.1|2.76| to the training just for reference, let's compute the
1052.86|2.28| mean squared error on the training set and then to the
1055.18|4.8| tested. Alright, so you can see here, the training set MSE is
1059.98|3.56| lower than the test set MSE, which means the model is
1063.58|2.8| overfitting a little bit to the training set, but it's not too
1066.38|4.8| bad, I would say. Now, let's also compare that with the
1071.18|4.8| analytical solution. So if I, if you recall, somewhere here,
1075.98|4.72| somewhere here, I showed you in the slides, the analytical
1082.58|2.28| solution, I don't know where I had it.
1091.14|4.16| Think it was here. So we have this analytical solution where we
1095.3|5.44| get the optimal weights using these matrices, the matrix
1100.86|4.76| inverse here, times x transpose y, this is the analytical
1105.62|4.04| solution. So let's compare our gradient descent solution with a
1109.74|3.52| analytical solution to see whether they match. So ideally,
1113.26|4.92| they should be very close. So here are the model weights from
1118.18|3.64| our own model from from our gradient descent model. So we
1121.82|3.4| see for the weights, feature one weight is point three six and
1125.22|6.32| feature two weight is point 379, approximately, and the bias is
1131.54|4.56| minus point five, four. Now, here's the analytical solution
1136.1|2.32| where implemented what I had on the slides when I just showed
1138.42|4.04| you. So when we execute that, you can see this one and this
1142.46|3.96| one, they are very close. And also, these are virtually an
1146.42|5.72| identical and also the bias unit is identical. So we can see this
1152.46|4.88| gradient descent implementation works. And it gave us the global
1157.34|4.48| minimum here. Yeah, an ungraded homework exercise just for you.
1162.78|3.68| So Mike, or the task for you is modify the training function
1166.46|3.28| such that the data set is shuffled prior to each epoch. Do
1169.74|4.12| you see a difference? Yes or no. So you can try this out in
1173.86|2.36| practice. But you can also just think about it whether you would
1176.22|3.0| see a difference whether you shuffle prior to each epoch or
1179.22|3.76| not. And yet, try to come up with an explanation for your
1182.98|4.2| observation or intuition, and then maybe post this on Piazza,
1187.22|2.72| just to check your understanding, whether shuffling
1189.94|3.48| would make a difference here, yes or no. So you can try that
1193.42|3.48| out in practice. But also, you would be able, I think to answer
1196.9|4.28| this without even changing the code. Alright, now let's take a
1201.18|4.4| look at the airline model with stochastic gradient descent. So
1205.66|1.92| we could also implement it with gradient descent, it doesn't
1207.58|3.36| really matter. But here, we use the stochastic grand descent,
1210.94|2.24| the mini batch mode, because this is something we will also be
1213.18|4.64| using later on when we implement deep neural networks. So again,
1217.82|5.06| these steps are all the same. Okay, just using a different
1222.88|3.34| data set. Now we are using the iris data set, where we have
1226.22|3.2| four features x one, x two, x three, and x four. So that's a
1229.42|3.0| separate length, separate width, petal length, and petal width.
1232.66|2.44| This is our class table, the predicted class table. So they
1235.1|5.0| are actually simplified it, so that there are only two class
1240.1|4.92| labels. So let me see. So this should be class label zero, the
1245.02|6.24| first data points. So I'm only using data point 50 to 150 here,
1251.3|7.32| I think. So here, I'm, yeah, I'm applying class label one. So
1258.62|3.2| yeah, I'm selecting. So what I'm doing precisely is I'm selecting
1261.82|4.68| only data points 50 to 150. And then these would be class label
1266.5|5.28| one, two, one and two, but I changed them to zero or one.
1271.78|3.4| Otherwise, our function would not work. So I am binarize our
1275.18|3.92| class labels. This is just to make this problem work for
1279.14|2.56| headline. And also, that same would be true for the
1281.7|3.7| perception. Later, we will be seeing models that can also deal
1285.4|5.48| with multiple class labels. So here, this is exactly the same
1290.88|4.66| code as before, where I'm just using the shuffle indices now use
1295.54|4.74| 70% again, for training and 30% for testing. And I'm also
1300.28|5.0| standardizing the features, just to visualize how the data looks
1305.28|3.96| like. So this is our data set two classes, blue dots and the
1309.24|4.08| orange dots here. And this is for the training set, how the
1313.32|3.24| training set looks like, sorry, the test that looks like above
1316.56|4.48| is the training set. And now we are implementing our airline
1321.04|4.2| model. Note that this is exactly the same as before. So I don't
1325.24|4.92| have to go over this again. So this is exactly like the same
1330.16|4.26| code. And so yeah, I have made screenshots side by side. So you
1334.42|3.1| can see, if you look at it closely, there's no difference
1337.52|6.56| between the two. So how we got that again is by let me see by
1344.12|8.24| deriving was a long lecture here. So this is basically what
1352.36|6.4| we do in the backward pass where we compute. See, so where we
1358.76|4.8| compute the derivative. So this is the outer derivative. And
1363.56|3.14| these are the inner derivatives. So if I go back, we have the
1366.7|5.18| outer derivative, this is this part here where we have the
1371.88|3.24| power rule, we bring the two upfront here. So this is this
1375.12|7.92| part here. And then this is the inner part, this is here, this
1383.04|5.24| x basically, for the weights, this is the x. And for the bias
1388.28|4.76| unit, it's just minus one. Because if we would compute the
1393.12|6.22| derivative of this one with respect to the bias unit, this
1399.34|5.18| would be one. Sorry, where are we here? So here, sorry, if we
1404.52|2.86| compute the partial derivative of this net input with respect to
1407.38|7.72| the bias unit, the this one will be so let me write this down
1415.1|8.84| somewhere. So we have the W transpose x plus w, if we
1423.98|3.78| derive with respect to B, so this would be a constant. So
1427.76|3.78| this goes away. And the derivative of this one with
1431.54|3.36| respect to B is one, right? So in this one, this case, the
1434.9|2.52| derivative would be one, but we are also interested in the
1437.46|10.64| negative gradient, so it would be minus one. Alright. Yeah,
1448.42|4.56| alright, so and then we define the training and evaluation
1452.98|4.52| functions, this is the same as before. compute the loss, we
1457.5|4.08| have our training function, the same as before. Because nothing
1461.58|3.36| really changes, because we don't use our threshold function yet.
1466.46|7.0| Let's see our model trains. Not defined. Yeah, I'm forgetting
1473.46|3.32| to execute them step by step here, which is a issue that can
1476.78|3.92| happen in Jupyter notebooks. Alright, so now we see we start
1480.7|5.28| again with a very large loss. Now, sorry, I mentioned it was
1485.98|2.44| the same, but one difference is now we're using mini batch
1488.46|2.6| gradient descent instead of batch gradient descent. So
1491.06|3.96| really, the difference is that we have now these mini batches
1495.02|4.6| here. So before, maybe just showing that side by side.
1503.7|3.68| Before we are just iterating over the epochs here, here, we
1507.38|3.52| iterate over the epochs and inside, we also iterate over
1510.9|3.84| the mini batches. So I'm creating a mini batch here,
1514.74|3.8| sorry, the image shuffling, and I'm creating multiple mini
1518.54|5.64| batches here by splitting this into mini batches of a certain
1524.18|4.8| size. So I'm using a size 10. So I'm splitting it into multiple
1528.98|4.16| vectors where each vector will contain 10 attend training
1533.14|5.6| examples. And then for each mini batch, I'm doing my forward
1538.74|5.28| pass, and so forth. So now, I have the mini batch training so
1544.02|8.0| that I have, if I have 150, so 101234567, I have seven mini
1552.02|2.64| batches in each iteration, because I have 700 training
1554.66|8.2| examples. So I can divide them into 10 mini batches with 70
1562.86|5.2| training examples each. So we start out with a large mean
1568.06|3.84| squared error. And then you can see it goes down. But it is now
1571.9|4.48| now a little bit noisier, you can see, it goes down here, and
1576.38|3.68| down, but then it goes up a little bit. Sorry. And you can
1580.06|5.6| see then it's a little bit noisy at these updates. Yeah, and then
1585.66|10.8| overall, per epoch, we can see that things go down. So at some
1596.46|3.84| point, yeah, we have converged. So we can see, it's fluctuating
1600.3|3.6| a little bit, but it's not going down significantly, it's going
1603.94|2.44| a little bit up and down. So it's a bit noisier than the
1606.38|2.44| gradient gradient descent, the mini batch gradient descent is
1608.82|4.86| usually a bit noisier. Alright, so time to evaluate it. So it's
1613.68|3.74| easier actually to look at it in a plot compared to these lists.
1617.72|3.34| This is something if you train complicated neural network
1621.06|2.64| models, it might be helpful to print it on a command line on a
1623.7|3.8| server if you don't have any plotting functions available. But
1627.5|3.0| after training, it's usually good to at least take a look at
1630.5|3.28| this. Because here, it's a little bit more clearer to see.
1633.78|2.96| So you can see it goes down very steeply. And then you can see it
1636.94|2.68| fluctuates. So it's not converging completely because
1639.62|4.12| it's more stochastic. So there's more noise. But overall, we can
1643.74|3.04| say it kind of converged, maybe we could have changed the
1646.78|1.76| learning rate, making the learning rate a little bit
1648.54|3.2| smaller. And later on, we will also learn about something
1651.74|3.7| called learning rate schedulers, where we make the learning rates
1655.44|5.68| smaller over time, so that we converge better also. Alright,
1661.12|3.62| so let's take a look at the model weights and the bias from
1664.74|3.58| the training and then compare to our analytical solution again.
1668.62|6.82| So we can see the weights are point or 7 and 0.4 here, 0.488.
1677.6|3.4| And yeah, if we look at our analytical solution, it's
1681.72|2.96| close, you can see it's quite quite close, but it's not as
1684.68|2.96| close as before before we used gradient descent instead of
1687.92|3.72| stochastic gradient descent. So before it was a little bit more
1691.64|3.48| accurate. So what you can change this code also to do gradient
1695.12|3.16| descent. Later on, when we talk about multi layer networks,
1698.64|2.76| yeah, regular gradient descent wouldn't really be very useful.
1702.12|2.16| So it's actually good to use stochastic gradient descent here
1704.28|3.76| as a practice already. All right, so let's take a look at
1708.04|3.48| the prediction accuracy now. So how good is our classifier that
1711.52|3.76| we trained. So for this one, we now need the threshold function.
1715.52|4.0| So we set the threshold at point five. So this is if I go back to
1719.52|6.36| my slides. So this is what I'm doing right now here. So for a
1725.88|3.6| given value, if the value exceeds point five, the
1729.48|4.24| prediction exceeds point five, we assign it class value, class
1733.72|3.6| level one, if it's below point five, we assign it class level
1737.32|2.6| zero. So this is what I'm implementing here. If my
1739.92|4.76| predictions are greater than point five, we predict once. So
1744.68|4.32| I have actually prepared a vector of once. So this is one
1749.0|3.36| limitation of the torch where function. So how the torch where
1752.36|3.32| function works, if you remember from the perceptron is if you
1755.88|4.6| have value. So if you meet this condition here, then you return
1760.48|3.44| this value. If you don't meet this condition, you return the
1763.92|3.32| second value. So I'm preparing these vectors already as outputs,
1767.24|2.64| I don't have to recreate them. So this is the ones and this is
1769.88|5.96| the zeros. And now I'm also then computing the mean. So what is
1775.84|3.24| the mean? It's basically the number of so we are computing
1779.08|3.84| the sum of the number of ones on the correct predictions here.
1784.56|4.24| Because I have the equal sign. So it's maybe going on or there's
1788.84|4.52| a lot of things going on in one step, I could make maybe a
1793.36|8.72| separate step predicted labels and assign that here might be
1802.08|4.88| easier to read. And then I would like this might be easier to
1806.96|3.76| read. So here, first, I'm like I said before, I'm creating these
1812.04|5.14| predicted labels. And then I'm checking how many of the
1817.18|4.62| predicted labels match my true labels. So this will be a vector
1821.8|4.36| of zeros and ones. And then I sum up all the ones and divide by
1826.16|3.54| the number of data points. So this is what the mean is doing.
1829.7|4.18| So it's, yeah, basically telling me on average how many are
1833.88|4.8| correct. So it will be a value between zero and one. Um, yeah,
1838.68|3.84| and I do the same thing here for the test set. So let's execute
1842.52|5.68| that. So we get 90% training accuracy and 96% or point 6%
1848.24|3.0| test accuracy. It's a small data set, usually, you will find
1851.24|3.4| that in a real world case, the test accuracy is usually lower
1854.64|2.36| than the training set accuracy because of overfitting and stuff
1857.0|2.8| like that. But this is a very small data set. And this might
1859.8|5.0| be just due to chance. So I'm just to illustrate in what this
1864.8|3.2| value here is. So this is a vector of zeros and ones or no
1868.0|2.92| sorry, trues and false, but you can actually convert it to
1870.92|5.24| integers. And then it should be zeros and ones. And then you can
1876.16|8.04| compute the sum. So this gives you the number of ones. And then
1884.2|3.36| if I divide it by the number of training data points, which is
1887.92|0.72| let's say,
1892.24|6.24| label starts size zero. So this is my 90% here. So I can then
1898.48|5.36| multiply it by 100. That's my 90% training accuracy. Alright,
1903.84|4.2| so let's take a look at the decision boundary. So this is
1908.04|4.24| the same code as from the perceptron class or lecture. And
1912.28|2.56| we can see now. So on the left hand side, this is for the
1914.84|2.08| training set. And on the right hand side, it's for the test
1916.92|2.48| set. It's actually doing better than the perceptron. It's
1920.16|2.2| something this would be a problem where the perceptron
1922.68|3.3| wouldn't be able to solve it. Because here, you can see now
1925.98|4.26| this is a case where the classes are not linearly separable. So
1930.24|2.76| there is no decision boundary where you get perfect accuracy.
1933.0|2.6| So a perceptron here would have really problems, it would
1936.12|2.36| change, it would like have a decision model like this, and
1938.48|3.16| like this, this, this and would flip back and forth. But this
1941.64|3.52| model converges, you saw that based on the training error. So
1945.16|3.12| it's, it's kind of finding a good boundary here. And this is
1948.28|2.96| for the test set. So yeah, this is it for this lecture. In the
1951.24|3.86| next lecture, we will be taking a look at how we compute or how
1955.1|3.86| we can compute these gradients automatically in pytorch. So
1958.96|6.68| on next lecture, we will see how pytorch computes this one
1965.64|2.44| automatically so that we don't have to do this by hand.
1968.4|8.48| Because I mean, right now, what we had here, where was it? What
1976.88|2.88| we had here was relatively simple, a very simple function.
1979.76|2.88| But even for that, we needed a lot of not a lot of steps. I
1982.64|1.8| mean, you can do it in fewer steps. But it's kind of
1984.44|2.56| complicated when we have multiple layers, nonlinear
1987.0|2.68| activation functions and stuff like that. And it would be
1989.68|3.28| really tedious for every neural network architecture to do that
1992.96|2.9| from scratch. So pytorch actually implements some
1995.86|3.62| functionality to compute this backward function automatically
1999.48|2.68| by analyzing the forward function. All right, we will
2002.16|15.56| see how that works then next week.