start_time|end_time|text
1.36|3.24| Alright, let's now talk about the GAN objective, essentially
4.6|3.76| how the loss function looks like. Before we get to that,
8.36|3.28| though, just again, the big picture overview, and the
11.64|4.0| important question, when does a GAN converge? Because the other
15.78|3.98| answer might not be so obvious. So we have the discriminator,
19.76|3.82| which is trained to distinguish between real and generated
23.58|2.62| images. So essentially, the discriminator wants to become
26.2|4.04| better at detecting these generated images, while at the
30.24|3.88| same time, the generator wants to become better at fooling the
34.12|3.4| discriminator. Right. So in that way, it's like this fine
37.52|3.8| interplay or this back and forth between the generator, wanting
41.32|3.76| to be better at fooling the discriminator. So it kind of
45.36|2.8| wants to discriminate to make wrong predictions. And the
48.16|3.3| discriminator wants to make correct predictions. So when
51.48|3.16| does it actually converge if it goes back and forth. So if you
54.64|3.36| train this and everything is set up properly, it should at some
58.0|4.08| point here reach some point of equilibrium. So in the context
62.08|3.76| of game theory, there will be called the Nash equilibrium. So
65.84|2.92| there will be some sweet spot between the two where both are
68.96|4.76| somewhat happy. So the loss function for the GAN overall
73.76|4.36| would look like this. It's essentially a min max game. So
78.12|11.4| some people call it mini max or zero sum game. And we have two
89.52|4.12| parts here. So we want to minimize some G here where G
93.96|5.88| corresponds to let's say the generator parameters, and the D
99.88|7.76| corresponds to the discriminator. And you can see there are two
107.64|6.6| broad parts here, one part is here. And the other part is this
114.24|7.2| one here. And in this left part, what we can see here, that's D
121.44|5.04| for the discriminator. So this is the output or prediction of
126.48|9.4| the discriminator. And this on the right hand side is the
135.88|3.72| output of the generator. So this is our input image, let's call
139.6|5.68| it the generated image x prime, whereas here the x is the real
145.28|5.68| image. So D on x prime, this is like the prediction of the
150.96|5.0| generated images. So looking at this, we have two terms. One is
156.0|5.12| prediction on the real images. And one is the prediction of the
161.12|6.84| discriminator on the generated images. So let's now in the
168.04|3.88| next couple of slides, walk through this step by step
171.96|4.48| looking at the discriminator part first, and then going to the
176.44|4.16| generator part, because sort of things going on. Let's look at
180.6|5.64| it one at a time. Okay, so there are lots of things going on now
186.24|3.68| at the top, I just copied over the equation from the previous
189.92|3.88| slide. And now in this slide, we are going to focus only on the
193.8|6.04| discriminator part. So the maximization party of the D. And
199.84|3.4| since it's a maximization problem, we are going to use or
203.24|4.84| assume we are using gradient ascent. Before in the lectures,
208.08|4.92| we used gradient descent because we wanted to minimize something.
213.56|3.88| Now, because it's a maximization problem here, we are going to
217.44|3.8| maximize something, which is why we call this gradient ascent,
221.28|5.84| not descent. But yeah, this is just a minor detail. Okay, so we
227.12|4.76| are going to maximize something here. So going to, for
231.88|5.08| instance, maximize this part. And this part for the
236.96|4.4| discriminator. So here at the bottom, showing you the gradient
241.4|4.88| of the loss with respect to the discriminator parameters. So W
246.28|4.32| is just the weights of the discriminator. And yeah, this is
251.12|5.04| the loss. And this is something we want to maximize though,
256.16|2.52| because like I said, it's a maximization problem. Oh, and by
258.68|4.04| the way, we have a sum here instead of the expectation,
263.02|5.78| because in the form here at the top, this is assuming the data
268.8|3.76| generating distribution. But in practice, we never really have
272.56|4.92| access to that we only have a fixed size training set. So this
277.48|3.96| becomes more like an empirical loss. So this is why we use the
281.44|5.92| sum here, where the sum is over the end training. So it's an
287.36|6.72| amount of training examples. Just a minor detail. Yeah, the
294.08|2.6| interesting part is now we are going to focus, let's say we are
296.68|7.04| focusing only on this part here, and then I will have a new
303.72|3.36| slide, exactly a duplicate of that slide, where we are going
307.08|3.08| to discuss the right hand side here, I want to discuss this in
310.52|2.76| two slides, because I can imagine it will be come very
313.28|4.96| crowded here. Okay, focusing on what I highlighted here in
318.24|4.72| purple, this is the bottom here, essentially this part, the
322.96|4.08| discriminator for the real images, what we want the
327.04|4.96| discriminator is to predict well on the real images, right. So we
332.0|5.92| want this probability to be close to one. So the
337.92|4.56| discriminator here, which color should I use red. So the
342.48|6.32| discriminator here is outputting a score between zero and one
348.8|7.56| representing the probability that an image is real. So it's
356.36|3.12| outputting this probability here between zero and one. And
360.96|3.88| ideally, the best possible score for the discriminator, because
364.84|3.76| it's a maximization problem here is this to be one, right?
368.72|4.6| Because if we plug in some values, so there's a lock here.
373.32|12.96| So lock of one is like this lock of one is zero, and lock zero,
386.28|3.0| that would be the worst case would be minus infinity, right.
389.64|6.12| So the worst case would be when we predict a zero for the real
395.76|3.84| images, and the best case would be to break the one. That's how
399.6|4.32| that's how we maximize this term. Okay, so the next slide,
404.28|5.4| let me show you the second term here. All right, let's do this
409.68|3.36| again. But now we are going to focus on the right part. So we
413.04|6.4| are going to focus on this one here. And we are still talking
419.44|3.56| about the discriminator. So still talking about gradient
423.0|2.4| ascent, maximizing something, we're still talking about
425.4|5.04| maximizing something. And now we are exactly here where we
431.64|6.2| consider generated data. So g here is the generator. And it
437.84|5.2| receives some noise input z, and it will output x prime, the
443.04|8.28| generated image, if we look at this term, it's actually very
451.32|2.96| similar to what we have on the left hand side. So there's also
454.28|5.52| D, and the D still outputs a value between zero and one. But
459.8|3.24| now, of course, based on the generated image, instead of the
463.08|4.68| original image, and now we have this one minus here. So as a
467.76|4.32| consequence, what happens if our discriminator is very confident
472.08|3.88| that this image is a real image, if it thinks this is real, it
475.96|4.56| will put out a value close to one, right. So in this case,
480.52|7.28| for let's go over here to the left hand side. So lock one
487.84|8.36| minus one, this is if it thinks it's real. So this would be lock
496.36|5.72| zero, which is minus infinity, it would be a very bad, very bad
502.08|3.2| loss, because the bigger the better, because we are still
505.28|3.48| here talking about maximizing. So the worst case scenario is
508.76|3.36| that our discriminator thinks that the generated image is real.
512.56|2.82| We're talking about optimizing the discriminator. So we want to
515.38|5.02| actually avoid that. To maximize this term, we would put in or
520.4|3.56| the discriminator would predict a zero, right. So because then we
523.96|7.84| have lock one minus zero, which is lock one, which is zero. So
531.8|3.72| this would be our best case scenario for predicting
535.52|6.64| generated. So here, I mean, with a value of zero, this is a low
542.16|4.08| probability for real, if we set the cutoff at point five, this
546.24|5.8| would be essentially predicting generated. Okay, so putting
552.04|3.04| these two points together, what we want for the discriminator
555.08|2.88| when we are training the discriminator here, as we want
557.96|5.4| that it outputs a probability close to one for real images.
563.36|4.6| images. And we want here to output a probability close to
567.96|4.56| zero for these fake generated images. So this is the
572.52|5.2| discriminator part in the next slide, we will then focus here
577.72|6.04| on the generator aspect. Alright, so finally, we are now
584.04|5.72| finished with the discriminator. And we can now focus on the
589.76|5.32| generator update. Okay, so now we are talking about a
595.08|5.28| minimization problem. So we can use gradient descent for
600.36|5.56| training the generator. We are focusing again on exactly the
605.92|4.36| same part as before. However, before we updated the weights of
610.28|4.88| the discriminator, now we keep the discriminator as fixed and
615.16|4.44| update the weights of the generator. It incorporates the
619.6|2.68| prediction of the discriminator, which is why I circled this
622.28|5.64| whole thing here. So looking at the equation above, if we want
627.92|5.76| to know what we have to update for g, so the left term, if you
633.68|3.6| think also on calculus of the sum rule, this would be kind of
637.28|3.04| canceled because there is no g here, right? So this is not
640.32|3.84| relevant in the loss. So we can actually ignore this for now. So
644.16|3.88| this has nothing to do with a generator. On the right hand
648.04|5.88| side, we see the generator here. So let's bring this down here.
654.92|3.88| This is again, the empirical loss. So on the training set,
659.24|3.28| and this is exactly the same I showed you before on the
662.52|3.68| previous slide, except now we are talking about g instead of
666.2|4.04| d. And we are talking about minimizing instead of
670.24|7.04| maximizing. But again, this part is still the generated or fake
677.28|7.16| image. And the discriminator here predicts on this fake image
684.44|6.84| and the output ranges still between zero and one, where one
691.48|6.76| or where this represents the probability for real. Okay, so
698.24|3.36| in the previous slide, when we talked about the discriminator,
701.96|4.2| we wanted to maximize this. So we wanted to maximize the
706.16|5.0| probability that the discriminator predicts real on
711.16|8.92| real images and predicts fake on these generated images. So we
720.08|6.72| write this part lock one minus. So in order to maximize this in
726.8|6.48| the previous slide, what we had is what we wanted the
733.28|6.12| discriminator to output wanted to output a zero here. Because
739.4|6.04| then we have lock one, which is zero, that was our best case
745.44|6.08| scenario for maximizing the discriminator. Now, since we
751.52|4.48| talk about a minimization problem, we want actually the
756.0|3.62| discretion to output a one here, because then we have one minus
759.62|5.38| one, which is zero, which gives us minus infinity here, minus
765.0|3.96| infinity is, yes, you can imagine the most on the lowest
768.96|3.88| possible value, right? Because we talked about minimizing this
772.88|2.88| last term, gradient descent minimizing. So we have a
775.76|3.52| minimization here. And this is minimized, if we have a lock zero.
779.6|7.12| So if the discriminator outputs, a low probability here, sorry,
786.72|6.56| a high probability here for real. So the discriminator here,
793.28|8.36| this is P, the probability, the image is real, which is in the
801.64|4.52| range between zero and one, it is a generated image. So it is
806.16|3.32| not real. But we want the discriminator to think it is
809.48|3.36| real. So we wanted to output a high score one, because then we
812.84|3.8| have one minus one, rock zero, which is minus infinity. And that
816.64|4.48| is how we minimize the generator. So the generator wants
821.12|5.04| the discriminator to output the prediction that something is
826.16|4.24| real, although in reality, it's not real. And yeah, this is then
830.68|3.84| now the different parts, we just recovered the maximization of
834.52|3.76| the discriminator. And we talked about minimizing the generator.
838.56|3.24| So the next couple of slides, I will just add a few more things
841.8|4.64| from the paper. So this here is a screenshot from the original
846.48|4.04| GAN paper. So this is the training process of what we've
850.52|2.96| discussed in the previous slides, just summarizing it into
853.48|2.92| this training procedure. They call this the mini batch
856.44|3.2| stochastic gradient descent training of generative
859.64|4.12| adversarial nets. Of course, also, gradient ascent is
863.76|2.64| involved, as you have seen in the previous slides for
866.4|3.92| training the discriminator. In fact, in the next video, I will
870.32|3.28| show you a trick that we can turn this ascent problem into a
873.6|3.2| descent problem. It's also recommended in practice. But for
876.8|3.64| now, let's stick to this original outline of the
880.44|6.68| algorithm here. So let's discuss this step by step. There is a
887.12|3.6| for loop here. Let me stick with green here. There's a follow
890.72|3.28| up here for the number of training iterations. You can
894.0|3.96| think of it also as a follow up over the number of epochs. And
897.96|5.08| then there are the discriminator training and the generator
903.04|3.84| training alternating. So let me box this in so it will be easier
906.88|7.32| to see. So this is the generator, sorry, the
914.2|18.4| discriminator training. And then here at the bottom, this is the
932.6|7.24| generator training. Okay, let's take a look at the discriminator
939.84|6.0| training first. So it says for k steps. And the k steps is a
945.88|5.92| hyper parameter. And they used k equals one. So they only
952.0|2.64| essentially train the discriminator ones, and then they
954.96|2.4| go to the generator, and then they go back to the discriminator
957.36|3.32| and so forth. But in practice, you could update the
960.68|2.76| discriminator several times before you update the
963.44|5.84| generator. It's another hyper parameter to consider. What we
969.28|3.28| do is when we train the discriminator as we sample a
972.56|4.52| mini batch of m noise samples from let's say, a standard
977.08|5.24| normal distribution. And then we sample a mini batch of m
982.32|3.04| examples from the data generating distribution. Here,
985.6|6.18| this is essentially your training set. So this is
991.78|3.9| essentially just drawing a mini batch. So there's nothing
995.68|4.52| special about that. It's just obtaining a mini batch. And then
1000.2|3.28| we update the discriminator by ascending its stochastic
1003.5|2.26| gradient. So that is what we talked about in the previous
1005.8|6.4| slides. That's how we update the discriminator. So this is the
1012.2|2.26| discriminator part at the bottom, we have the generator
1014.46|5.5| part. Again, here, we sample a mini batch of noise examples.
1019.96|6.12| And then we update the generator by descending. So here, that's
1026.08|5.04| the SGD that we had on the previous slide. And therefore
1031.12|3.4| learning. So this is essentially and for learning, they say they
1034.84|6.32| use momentum based stochastic gradient descent. Personally, I
1041.16|4.24| also had good experiences with SGD and momentum and Adam, but
1045.4|5.16| I've had seen some comments or people recommended not using
1050.56|3.96| momentum because you want the generator and the discriminator
1054.84|5.16| to be kind of flexible. So the momentum term makes them lag
1060.04|3.44| behind a little bit. So sometimes people recommend not
1063.48|4.48| using momentum, but I find that it works just well with
1067.96|1.0| momentum as well.
1068.96|7.52| Yeah, just to recap on GAN convergence. So when does a GAN
1076.48|3.52| converge, like I mentioned briefly before, it converges
1080.0|2.94| when we reach the Nash equilibrium, which is a term
1082.94|4.14| from game theory. And that is essentially, yeah, when we we
1087.08|4.0| have an equilibrium between maximizing the loss for
1091.12|4.52| discriminator and minimizing the loss for the generator. So in
1095.64|3.08| the game theory jargon, it is basically reached when the
1098.72|3.02| actions of one player won't change depending on the
1101.74|4.54| opponent's actions. And here in concretely, this means that the
1106.28|4.24| GAN produces realistic images. So the generator is able to
1110.52|4.2| produce realistic images, and the discriminator outputs random
1114.72|6.2| predictions, probabilities close to point five. So the GAN is able
1120.92|3.42| to produce images that are indistinguishable from the
1124.34|2.62| training set images. I mean, there are still new images, but
1126.96|4.6| they look very realistic. While the discriminator can't tell
1131.56|3.92| them apart, the discriminator essentially predicts point five,
1135.52|4.4| like a point five probability being unsure whether something
1139.92|0.88| is real or fake.
1145.44|3.16| Yeah, so here's another figure from the original GAN paper.
1148.76|3.66| This is a really nice figure illustrating the GAN training
1152.42|3.06| process. So when it converges when it reaches the Nash
1155.48|5.32| equilibrium, so there are four steps to this figure, a, b, c
1160.8|4.76| and d, let's talk through this one by one. So let's focus on
1165.6|4.28| figure a first, you can see there are multiple lines, that's
1169.88|3.76| a lot of things going on. So let's annotate this first. So
1175.28|3.08| what they say here is in the green solid line is the
1178.36|4.32| generative distribution or essentially the generator data.
1182.72|9.48| So the outputs of the generator, let's say the fake images. Then
1192.2|7.48| what we have is here in black, black dotted line, these are the
1199.68|4.72| data generating distribution. So with this, it means the original
1204.4|4.64| original training set images. So let's just call that training
1210.36|8.56| or real images. Then we have one more line, the blue line, the
1218.92|4.64| blue dashed line here. And this is the discriminative
1223.6|5.96| distribution. So you can think of it as yes, this one, the
1229.56|3.6| discriminator. It's maybe not ideal. So like here,
1234.12|11.4| discriminator predictions. And you know, from the previous
1245.52|7.56| slides, the range is between one and zero, where one or where the
1253.08|8.04| discriminator outputs the probability that an image is real. Okay, so now we
1261.12|4.8| have these different things. And you can also can also so you can
1265.92|3.64| think of the black line here is the probability density. And
1269.64|5.76| here, this is the x, the input images to the range of the input
1275.4|4.08| images. Of course, it's only a one dimensional plot here. Just
1279.48|5.28| for simplicity. x are the input images and z are the generated
1284.76|8.22| images. Let's say real and generated. And what they're
1292.98|6.3| trying to show here is where the generated images map to and you
1299.28|4.96| can see that let's say the training images are the densities
1304.24|5.56| highest in this region here. And the generated images at this
1309.8|4.88| first step, they are mostly mapping only to a small region
1316.52|6.56| over here. So the highest density for the generated images is
1323.08|12.48| here. And they say this step a here is near convergence. So
1335.56|3.0| it's not quite converged. So they are illustrating here, the
1338.56|5.48| process of converging going from A to B to C and to D. So we said
1344.8|2.92| that the distribution of generated images here is
1347.72|4.6| different. At this point, from the training distribution, but
1352.32|3.0| it's not substantially different. The discriminator
1355.32|3.76| predictions are very confident here for these images like that
1359.08|4.62| they are real. So here in this whole region, the generator
1363.7|7.02| predicts real, except then when we go down here to the generator
1371.28|4.6| images here, the zero, it essentially detects correctly
1375.88|5.6| that they are fake. So this is a region in general where the
1381.48|3.76| discriminator is pretty happy. It's doing good predictions. But
1385.24|3.8| the generator is not very happy because it's not able to fool
1389.2|8.68| the discriminator yet. So next in B, so as be here, be in the
1397.88|2.96| inner loop of the algorithm D is trained to discriminate samples
1400.84|3.44| from data. So now we have a training step. So B is a
1404.28|5.0| training step updating the discriminator. So you can see
1409.28|4.32| after this update, it will become even more confident. So
1413.6|4.68| after this update, so in step B, now it's consistently around
1418.28|3.92| one instead of being fluctuating here. And you can see also here
1422.2|4.44| in this region, it's consistently around zero instead
1426.64|3.8| of being fluctuating here. So here, this updated the
1430.44|3.96| discriminator. After the discriminator update comes the
1434.4|6.6| generator update, right. So now we have a training step of the
1441.0|4.52| generator here. And see, after this step, what you can see is
1445.52|4.56| that the generator learns how to make the distribution of the
1450.08|7.0| generated data in green here, closer to the training data. So
1457.36|4.96| they are no more similar to each other. And you can see then that
1462.32|4.52| in this region, the discriminator is somewhere like very
1466.84|4.04| confident. So it's on in this case, the discriminator is not
1471.04|3.68| doing so well anymore. So here, this is a point in C where the
1475.0|2.72| generator is more happy and in B, the discriminator is more
1477.72|3.76| happy. But in what we want is we want to find this equilibrium
1481.48|4.2| where both are having the sweet spot where both are relatively
1485.68|6.12| happy. So this is reached in D when you do many steps. So in D,
1491.8|3.96| after several steps of training, if GND have enough capacity, so
1496.04|3.76| if they are networks that are able to learn, of course, you
1499.8|2.56| can have maybe networks that are too weak to learn anything
1502.36|2.52| useful, then of course, this would not be the case. But if
1504.88|3.52| both have the capacity to learn, they will reach a point at which
1508.4|4.96| both cannot improve. Because the data generating distribution is
1513.8|3.76| the same as the generator distribution. And the
1517.56|2.96| discriminator will be unable to differentiate between the two
1520.52|4.12| two distributions, outputting point five is the prediction. So
1524.64|3.2| this is what we can see here. So here we can see the generator
1527.84|3.88| has learned to output to recreate the training set
1531.72|3.92| distribution, and the discriminator will be unable to
1535.68|3.64| differentiate between the two. So here are steps a, b, c, and
1539.32|4.64| d, kind of illustrate the process of training GANs, at
1543.96|3.8| least conceptually, in practice, it's way more messy, it's not so
1547.76|4.72| easy to reach step D. But yeah, this will be more clear, I think
1552.48|2.96| when we look at the code example, how, how difficult it
1555.44|7.2| is to train again, in any case. Now we covered the loss
1562.64|4.2| function. And again, objective, the convergence and everything.
1567.08|3.56| And in the next video, I want to briefly tell you about a small
1570.64|4.84| modification, so that we can use stochastic gradient descent for
1575.48|4.64| training both the generator and the discriminator, and also how
1580.12|29.04| we can improve the gradient, the loss gradient for the generator.