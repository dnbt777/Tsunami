start_time|end_time|text
0.32|4.04| So in the previous video, we talked about a basic form of
4.4|3.52| self attention. Now we are going to get a little bit more
7.92|3.96| sophisticated and talk about the self attention mechanism that is
11.88|2.52| used in the attention is all you need paper.
16.04|4.18| So yeah, just to recap, this is what we looked at, at the in the
20.22|3.9| previous video where we had the self attention mechanism defined
24.12|3.08| as follows, where we had this input sequence, which were
27.2|3.82| embeddings, word embeddings, then we computed the dot
31.02|5.18| products here between one particular input and all the
36.2|4.44| other inputs. And then we normalize those with a softmax
40.68|6.08| and computed the output as the attention weighted inputs. So
46.76|4.84| for each input for each input AI, we will get a vector. And if
51.6|9.68| we have, let's say T words, we will get T vector. So from one
61.72|6.32| to T, essentially a matrix, tension matrix. Okay, but yeah,
68.04|3.48| we are now kind of extending this concept of this basic
71.52|3.64| attention, using the attention that is used in the paper
75.2|4.16| attention is all you need. So how does that one look like? So,
79.36|3.48| first of all, notice that there was one big problem with the
82.84|3.96| basic version of self attention. And the problem was that it did
86.8|4.16| not involve any learnable parameters. So the previous
90.96|3.76| version of self attention, the basic form was actually not very
94.72|2.92| useful for learning a language model, because how do we update
97.64|3.6| this, right? So if we want to develop a language model that is
101.28|3.8| for instance, supposed to translate text, how do we make
105.08|3.12| it better if there are no learnable parameters, right? So
108.2|5.36| so here we are now introducing three trainable weight matrices
113.96|3.64| that are multiplied with the input sequence embeddings, the
117.6|6.16| x is that we had before. So now, instead of let me go back, so
123.76|3.0| instead of just computing the stop product here between the
126.76|5.52| input, and the query, we now involve weight matrices. In
132.28|2.8| fact, we will use three different types of weight
135.08|5.88| matrices, we call the one w q, which corresponds to the query,
141.92|5.16| k for the key, and V for the value. So when we now compute
147.36|4.0| this matrix multiplication between word, the word embedding
151.4|5.68| xi, which is a vector, and this matrix w q, we get the so called
157.12|4.64| query. For this one, we get the so called key. So these are
161.76|2.8| vectors. And the value is also vector. This is the value
164.56|6.12| between a matrix w V, and the input x i. So what's new is now
170.68|5.32| that we have modified versions of this word embedding. And
176.02|3.78| these are weight matrices that can be updated with back
179.8|5.12| propagation, for instance. So here's a drawing of how this
184.96|5.44| self attention mechanism looks like for a particular input. So
190.4|3.96| let's consider the one in the middle here, x two word, the
194.36|3.6| second word in the sentence. So this current we can consider
197.96|5.84| this as the current input, we call this the current query. So
203.84|2.72| I mean, carries a little bit ambiguous, because we also have
206.56|2.92| the queue here. But let's consider this as our current
209.48|4.4| input here. And we compute these three things that I showed you
213.88|2.68| on the previous slide by matrix multiplication. So if I go
216.56|2.84| back, it's just a matrix modification to compute these
219.4|4.44| three things. And we do this actually for all the inputs. So
223.84|6.0| we also do this here, and here. So from word one, two, up to the
230.04|7.08| last word, the teeth word. Now, we are also computing the
237.16|6.72| attention values here as a dot product. However, here, we are
243.88|3.24| now computing it instead of computing it between the
247.12|6.84| sequences, x one and x, let's say, I, instead of computing it
253.96|7.88| like this, we computed actually between the query and the key.
262.04|3.32| So these are just modified versions of that. So here we are
265.4|5.08| regarding q two as the current input. So we are using q two
270.48|4.32| here everywhere. This is our query. And then we use the key.
274.8|3.44| So maybe I should use different colors. So for the blue one
278.24|6.28| here, use blue key for green one here for itself, we use green
284.52|6.96| one. And for this one, we use this one. But this query is all
291.48|2.28| the same, the keys are different, but the queries are
293.8|4.76| the same. So why the terms query key and value, this I think
298.56|4.4| comes from the field of databases. So here, it's not
302.96|4.08| here, it's not really that relevant. It's just different,
307.44|4.24| different names for different parts of this computation here.
312.2|4.76| And you can think of this. And this is also known as the stock
316.96|3.16| product is multiplicative attention. There's also the
320.12|3.12| other types of attention, like additive attention. But here,
323.24|5.28| it's like a form of form of multiplicative attention. And
328.52|5.16| essentially, for each query for each year for each query, the
333.68|4.44| model learns which key value input, it should attend to. So
339.12|5.04| continuing with this model here, when we computed these, there's
344.16|4.84| also a normalization via the softmax. And then these are
349.0|5.52| added up to form this a two, which is the context aware
354.52|6.6| embedding of the input. So if I go back, this is similar,
361.12|3.28| essentially to what happens here, right. So when we have our
364.84|5.16| context aware, embedding of the input x i, now we have the same
370.0|3.72| thing, except the computation is a little bit fancier, because we
373.72|5.48| involve these three matrices. I will also show you, I mean,
379.2|4.44| there's also a scaled version of that, but one step at a time. So
383.64|4.8| here is the not scaled version. So here, in the center, we have
388.44|6.24| again, a softmax. So the softmax of these dot products. So that
394.92|5.2| these attention weights, these A's sum up to one, just like
400.12|4.76| before. And then what's new is we multiply this here by the
404.88|8.28| value. So we do that for all the t values. So we are summing over
413.16|4.16| them here. This will be a vector. So this will be the
417.32|8.84| vector for the second word, a two corresponding to x two, we
426.16|4.22| would do the same thing also for x one and xt, so up to xt. So we
430.38|4.58| would repeat this process, but we would each time swap the
434.96|4.4| query, then by let's say query, one, the first word, and then
439.36|4.88| also the teeth word, and so forth. But notice also, what's
444.24|2.84| cool about this is we could do this all in parallel, there's no
447.48|3.32| sequential nature of that. So we could all compute these in
450.8|3.56| parallel. Yeah, to explain a little bit better what was going
454.36|3.28| on in the previous slide, I made a copy of the previous slide and
457.64|2.96| edit some annotation about the different dimensions of the
460.6|4.2| different parts in that figure. So let's walk through this from
464.8|6.2| left to right. So here, x i x one, this is a word, a word
471.0|2.6| embedding vector. So you can think of it as a one times the
473.6|4.28| dimensional matrix or the dimensional vector, where the E
477.88|3.48| is the embedding size in the original attention is all you
481.36|4.12| need paper, they used 512 as the embedding size. But of course,
485.68|2.52| this is a hyper parameter, it's something you can choose. It's
488.24|5.04| arbitrary in that way, can have 256 or 1024, or some other
493.28|3.08| number as the word embedding size, as we have seen, also,
496.36|6.28| when we worked with RNNs. Then we have our matrices here, or
502.64|4.12| w's, the query key and value. And they have to have, of
506.76|3.44| course, the same dimension, I mean, the same number of rows as
510.2|3.84| we have columns here for the matrix multiplication. So we
514.04|2.94| have the everywhere and then the output size or the number of
516.98|4.7| columns is dv, dq, and decay. And in the original paper, they
521.68|4.0| had dq equaling decay, I mean, of course, that's also necessary
525.68|2.16| for the stock product here, right, you have to match the
527.84|5.04| dimensions. And in the original transform paper, they also had
532.92|6.64| dq equal to dv. So this is it, we'll see later, why that is,
539.56|3.8| it's because we have also certain stacking going on and
543.4|3.08| things like that. So that's determining our output size.
546.48|11.76| Okay, um, what else? Yeah, so these will be, of course,
558.28|2.36| scalars, these stock products, right, because it's a
560.64|3.24| modification between two vectors. So our softmax here,
564.04|5.16| this will give us our essentially our scaled attention
569.2|7.2| weight, that we then multiply by this value vector, which is
576.4|6.12| the one times dv dimensional vector. And then we sum that
582.52|7.96| up. So the output size of this one would be one times dv. So
590.48|3.88| that's, yeah, just annotated what what these ports are, no,
594.36|3.48| you know, what is the vector? And what's the matrix? That
597.84|3.12| wasn't clear before. But yeah, this is, I think, maybe just a
600.96|6.68| another summary of the previous slide. Here's an example of these
607.64|4.88| attention visualizations. So again, this one here is just for
612.52|5.96| one, one word, right? So this is just for the second word. So
618.48|4.32| it's attention vector for the second word. So the previous
622.8|4.64| slide, we had looked at the second word as the input. But of
627.44|2.78| course, we have also other words in the input. So we would
630.22|4.98| repeat this whole process for every input element. So here on
635.2|5.24| the left hand side, consider the first word. And here on the
640.44|2.76| right hand side, we consider the last word. Whereas here, we
643.2|4.92| consider the second word. But this might be a misleading
648.22|2.86| visualization. It looks like there's a sequential part of it.
651.08|9.62| That's not true. All of these can be computed in parallel. So
660.7|3.0| we don't have to wait for one to finish before we can compute
663.7|4.32| the next. So these are all parallel computations, which is
668.14|2.74| one nice aspect about these transformer models or the self
670.88|4.1| attention mechanism in the transformer model. And then so
674.98|4.64| we get an attention aware embedding for each of the words
679.62|3.5| and then these essentially, you can think of it as a matrix now
683.12|6.16| an attention matrix, where each row corresponds to to the
689.28|5.28| embedding attention embedding for each word. So it should if
694.56|6.16| we have a T here, this should actually be T. Okay. Um, yeah,
700.76|4.56| here's just like, more like compact notation for that. So
705.32|6.4| now consider for the inputs, we represent the inputs as t times
711.72|3.76| the dimensional matrix, where these are embedding size again,
715.76|3.36| and t is the input sequence size. So I'm just summarizing
719.12|5.28| everything here in the center. So now, instead of doing these
724.4|5.16| steps individually here, can just write this as one matrix
729.56|6.16| multiplication. So we now have, let's say, the matrix Q. So we
735.72|4.0| instead of having q1 here, q1, q1, and so forth. So these
739.72|5.04| results, we can just summarize that as a matrix at t times dq
744.76|5.8| dimensional matrix, k times, t times dk and t times dB. And
750.56|2.76| then we can compute this attention matrix, which are t
753.4|3.88| times t dimensional matrix. So this is one, maybe one
757.28|4.0| disadvantage of the self attention approach is that this
761.28|3.16| is kind of large, if you have a large input sequence, because
764.44|3.72| yeah, it's like a pairwise in a way a pairwise similarity score
768.16|7.24| here. So it's n squared, spot t squared, the bigger of that. So
775.4|2.96| it's not the most I would say memory efficient approach. But
778.76|5.32| well, at least we can compute things in parallel. So we have
784.08|5.24| now kindly a kind of slightly modified version of the dot
789.32|3.04| product that I showed you before. We call that the scale
792.36|2.52| dot product, which is because of this one, I will explain that
794.88|3.84| in the next slide. Just focusing again on this whole thing here.
798.84|5.68| So now we have q times k as a matrix multiplication, then we
804.52|6.5| take the softmax. So we have q times t, q times k as the matrix
811.02|3.46| multiplication, and we have this scaling here, and we'll talk
814.48|4.16| about it in the next slide and set. And then we have the soft
818.64|4.72| max. And then we multiply by the matrix V. So this is just the
823.36|2.84| more compact form of what I've shown you in the previous
826.2|5.32| slides. And then we will get this t times dv dimensional
831.56|6.72| attention matrix. Okay. So what is this scaling factor here in
838.28|4.04| the denominator. So this is just to prevent these individual dot
842.32|2.92| products. So if you do a matrix multiplication, you can also
845.24|3.84| think of it as multiple dot products between these q and
849.24|6.84| case. So to prevent these to become too large, we scale them
856.08|2.44| because if you think of the softmax function, if you have a
858.52|3.2| very negative input to the softmax function, it will be
861.72|4.12| zero. If you have a very large input, a very positive large
865.84|5.76| input, it will be close to one in the softmax. So in order to
871.6|2.52| prevent a very sharp distribution of values in the
874.12|3.24| softmax, we have this scaling factor. Because if you maybe
877.36|3.6| just think back of the logistic sigmoid, which is essentially
880.96|4.44| similar to the softmax, except that softmax incorporates all
885.4|3.48| the other ones, but it's kind of like a sigmoidal thing. If you
888.88|3.48| have values close to one, close to zero, there's like this
892.38|3.3| saturation, right? So you want to prevent values from being
895.68|3.24| too extreme. I mean, the same concept, this is, of course, not
898.92|6.0| a softmax, but the same concept applies to the softmax. So by
904.94|4.3| scaling, we prevent the softmax from having a distribution that
909.24|5.48| is too sharp. Yeah, and here, just for reference is the
914.72|3.16| visualization of the scaled dot product extension from the
918.48|3.52| tension is all you need paper. So again, they're just
922.0|3.88| summarizing, summarizing that visually, the matrix modification,
926.08|1.52| and the scaling here.
929.92|4.24| Optional mask, we will talk about the mask later when we
934.16|2.6| talk about the transformer. Here in these steps, there is no
936.76|3.64| masks. So a transformer also consists of an encoder and a
940.4|3.32| decoder. And the decoder has a mask. So here can actually
943.72|3.68| ignore it. And then we have the softmax. And then we have a
947.4|3.4| matrix modification with V. So this is essentially summarizing
950.8|5.4| this one. Okay, yeah, okay. This was self attention in the
956.2|4.0| scaled dot product attention. In the next video, I will talk
960.2|5.0| about the multi head attention. And then we will be one step
965.2|15.84| closer to the transformer.