start_time|end_time|text
1.44|3.26| Yeah, now it's finally time that we talk about multi layer
4.72|3.88| perceptrons. So what is a multi layer perceptron? So multi layer
8.6|3.08| perceptrons are fully connected feed forward neural networks
11.88|4.56| with one or more hidden layers. So what does the fully connected
16.44|3.28| mean here? So fully connected means that if you have a given
19.72|4.52| layer, each unit in that layer is connected to all the other
24.24|4.36| units in the next layer. So for instance, um, if you have a
28.6|3.52| layer, let's say like this, an input layer, and then you have
32.12|4.82| another layer, let's say with only one unit, then each input
36.94|2.86| is connected to that one. It's actually similar to logistic
39.8|3.08| regression in that way. So in the logistic regression context,
42.88|3.72| we also had everything in the input layer being connected to
46.6|3.72| the next layer. Or if we had multiple outputs, we had also
51.16|3.64| this setup. And this is actually similar to a multi layer
54.8|5.4| perceptron, except we're in softmax regression, we had an
60.22|8.34| input and an output layer. Let's make maybe one more here. Now
68.56|5.4| what we have is we have a hidden layer. So that means there is
73.96|3.4| another output layer, for example, like that. So instead
77.36|2.64| of being softmax regression, we have no multi layer perceptron.
80.28|3.16| And in the middle, minimally, in the middle here, we have a hidden
83.44|4.92| layer. And now this one becomes our new output layer. So again,
88.52|3.66| everything is connected here. So that's why it's called fully
92.18|5.76| connected. Yeah, and the main difference between a multi layer
97.94|3.82| perceptron and softmax regression is that we have this hidden
101.76|5.64| layer here. Also, we use a learning algorithm called back
107.4|3.52| propagation, which is actually just gradient descent using the
110.92|3.0| chain rule. It's essentially very similar to what we have
113.92|2.76| done in the last lecture when we talked about softmax regression,
117.16|5.6| except again, that we have no hidden layer. Alright, so yeah,
122.76|3.42| another term here is feed forward. So feed forward
126.44|4.76| refers to the fact that we go into one direction from left to
131.2|2.5| right in this particular drawing, but essentially from
133.7|4.0| the input to the output. So that means feed forward. Later, we
137.7|3.3| will see other networks that are not feed forward. For example,
141.0|6.12| there are recurrent networks where we have a recurrent layer
147.16|4.6| where you go essentially backwards as a time dimension. I
151.76|4.64| should also say, not all networks are fully connected. So
156.4|3.38| later in this course, we will also see convolutional networks
159.78|4.98| which are not fully connected. Alright, but yeah, I'm way ahead
164.76|3.0| of my slides here. I just see I explained almost everything
167.76|2.68| already. Because yeah, I made actually some nice figures. So
170.44|3.28| let's take a look at these figures. So here, I'm showing
173.72|5.08| you a multi layer perceptron with two hidden layers. So we
178.8|5.04| have on the left hand side, the input layer, then hidden layer,
186.0|4.08| another hidden layer, and then the output layer. And because we
190.08|3.28| only have one output unit, similar to logistic regression,
193.36|4.76| and different from softmax regression, this one would be a
198.12|3.28| binary classification problem. And so for the output, we can
201.4|4.32| actually use a sigmoid function similar to on your logistic
205.72|4.2| regression. Other than that, there's nothing really new
209.92|3.16| here. I mean, this is just like softmax regression, except that
213.08|3.76| we have now these hidden layers, right? So in that way, there's
216.84|2.44| actually not that much to explain, because yeah, we have
219.28|3.72| we have also the same way, these weights connecting each unit
223.0|4.88| between the layers. And when we then compute the partial
227.92|4.2| derivatives for training this network, we can also use the
232.12|3.44| chain rule, the multivariable chain rule. So for instance, if
235.56|2.92| we would want to compute the derivative, the partial
238.48|3.04| derivative of this loss function on the loss here, with respect
241.52|4.76| of with respect to one of the weights, then we would also use
246.28|3.52| the chain rule to go backwards, and then the multivariable chain
249.8|3.96| rule to combine the output from different units. So what I mean
253.76|4.8| is, if we have the output here, then we go backwards. So we are
258.56|2.4| interested, again, we are interested in this weight, w
261.4|6.0| 11. Just as an example. So I'm just highlighting all the paths.
267.44|2.6| So there's one path that goes here, you can see it here,
270.04|6.56| right. And the other path is this one here. So in purple,
276.6|6.12| what I'm showing you is this one here at the top. And then in
283.4|7.52| here, for the multivariable general, this is this path here.
290.96|3.76| So there are two paths, actually. Um, yeah, and that is
294.72|4.04| actually it. That's how we would train or update this weight.
298.76|3.48| Wait, notice that there are, of course, multiple weights and
302.24|4.52| actually multiple weight layers. So here we have, for example,
307.56|4.28| the weight in the second layer, we will train those also, of
311.84|3.0| course. So in this case, the rule would be a little bit
314.84|3.36| different. So in this case, let me just take a look, we have
319.88|3.4| let me write this down, maybe. So we have the partial derivative
323.28|7.44| with respect to this one, which should be lost with respect to
330.76|8.04| the output, and then the output with respect to a one, two,
338.92|10.72| right, and then a one, two with respect to we were saying one,
349.64|4.64| one, two. So in this way, you can see this path here is
354.28|9.32| actually, let's see, um, this, this part here is actually
363.76|4.92| shared with this path here, right. So actually, you can
368.68|4.6| reuse if you compute this one, first, you can reuse this part,
373.96|4.8| in order to compute this part for back propagating further. So
378.76|3.36| also, when you implement this in practice, yeah, there are some
382.12|4.88| tricks to avoid recomputing things or gradients here. But
387.0|2.92| fundamentally, that's the same concept that applied to softmax
389.92|2.48| regression. So here, really, what I wanted to say, there's
392.4|5.2| nothing new really. Yeah, here's a figure we looked at earlier in
397.6|3.52| this course, these different types of learning algorithms.
401.12|3.88| And this algorithm that we use for training the weights and
405.0|3.8| the molecular perceptron that I just showed you, based on the
408.8|3.22| partial derivatives on gradients, that's called back
412.02|3.78| propagation, that's one type of learning. And yet remains still
415.8|4.28| to as the most precise learning algorithm. So there was this
420.08|6.48| paper in 2020, where the authors proposed an alternative algorithm
426.56|3.68| that may be more similar to what's going on in the brain, but
430.44|2.9| the back propagation algorithm is still the most efficient one
433.34|4.46| for training neural networks. So now let's talk a little bit
437.8|3.68| about the nomenclature. So here, that's the same figure as
441.48|5.84| before. And notice that I'm using these round brackets or
447.32|5.04| parentheses here. So before, when we had something like this,
452.96|5.12| with a square brackets, this was usually referring to the first
458.08|10.72| activation for the ice training. Example, here, the round
468.96|3.56| parentheses, they don't or this doesn't mean this is the first
472.52|3.28| training example. This really means here the first hidden
475.8|3.36| layer. So the round braces here are sorry, the parentheses
479.16|9.4| refer to the hidden layer index. So here we have two hidden
488.56|3.0| layers. So you can see this is the first hidden layer. And then
491.56|3.2| here we have the second hidden layer. And I could also, instead
494.76|3.8| of writing output here, I could also write activation with a
499.08|4.44| parentheses here three, because the way the output is computed,
503.52|2.4| if we use the sigmoid function is the same way as these
505.92|3.2| activations are computed. So for example, if you have one
509.32|5.04| activation here, let's say the one in the first hidden layer,
514.52|4.4| this is really computed as the activation based on, let's say
518.92|8.24| some net input z where z is computed as the net input here.
527.18|3.1| So I'm not showing I should say I'm not showing the biases. So
530.28|13.8| there should also be a bias for each activation. So I was not
544.1|3.78| drawing it because the figure was already so crowded. See,
547.88|2.72| it's a bit messy. So let me remove this again. But there
550.6|10.56| should be a bias also for each activation. Okay. And this is for
561.36|3.46| this unit here. But now if we take a look at this one, so for
564.82|5.98| this one, we would compute it the same way. Except now that we
571.16|3.56| instead of so we still have z. So let's just use the same
574.72|3.72| meta z. But z is now not of course involving the access
578.44|4.68| directly. It's based on the previous layer activations. So
583.36|3.64| in this case, you can think of it as the previous layer
587.96|8.72| activations. So w transpose plus b, I'm not using indices here
596.68|2.76| for the weights. But this would be of course, these would be the
599.44|5.0| weights from the previous layers respectively. So here was just
604.44|6.44| focusing on what the inputs are for this on second one here, we
611.32|3.6| have the activations of the previous layer, which act as the
614.92|3.32| inputs to that layer, if that makes sense. So for this layer,
618.24|4.2| we have the access input. And for this layer, we have the
622.44|4.08| activations from the previous layers input. Actually, the
626.52|4.0| main point here also wanted to make is how we count the layers.
630.52|4.32| So it's quite common, I've seen that couple of times, referring
634.84|4.04| to the input layer as the first layer in the network, then the
638.88|3.2| first hidden layer is the layer number two, the second hidden
642.08|3.2| layer is the layer number three. And the output layer would be
645.28|3.36| layer number four, we could do that. But then, yeah, it would
648.64|3.32| be a little bit weird when we talk about logistic regression,
651.96|4.56| because then logistic regression is a two layer network, which
656.52|2.48| is kind of weird, because usually you think or we think
659.0|4.84| of logistic regression as a single layer neural network. So
664.2|4.68| what I mean is, yeah, if we count like that, if we then
669.8|3.44| remove these hidden layers, we have an input layer and an
673.24|3.36| output layer, like in logistic regression, this would be a two
676.6|2.32| layer network. And that is a little bit weird. So in this
678.92|4.24| way, we usually use the indices a little bit differently. So
683.16|3.16| this is like the input layer sometimes also called the zero
686.32|4.96| layer, or just input layer. And the first hidden layer is the
691.28|3.12| first layer, the second hidden layer is the second layer, and
694.4|2.36| the output layer in this case would be the third layer. So
696.76|2.8| that's a little bit more intuitive if we think of
699.56|5.88| logistic regression as single layer neural networks. So yeah,
705.44|3.64| like I said, we can use the sigmoid the logistic sigmoid
709.08|4.72| function here everywhere as activation function. So then it
713.8|2.92| would be really like logistic regression, except that we have
716.72|4.68| these hidden layers in between. But the loss function could also
721.4|4.84| be the negative log likelihood that we talked about, or we can
726.24|5.68| also call it binary cross entropy, which is here
731.92|8.76| equivalent to the negative log likelihood. Actually, for
740.68|3.12| classification in neural networks, that's also the most
744.0|4.12| common loss function. And that is again, why we spend so much
748.12|3.56| time on logistic regression and softmax regression, because
751.84|6.36| fundamentally, things are very similar. Yeah, and also like in
758.2|4.4| softmax regression, if we have multiple output units, instead
762.6|4.6| of using sigmoid functions here, we can use the softmax function.
767.2|3.24| But yeah, I don't have to explain how softmax works. Again,
770.64|4.0| if you forgot how softmax work, then yeah, we have lecture eight.
774.64|2.88| So you the nice thing about lecture recordings is that you
777.52|6.96| can revisit lecture eight. Yeah, now an interesting question is,
784.68|4.2| is this really deep learning? I mean, multi layer perceptrons
788.88|4.6| have been around maybe for 50 years already. So is this really
793.48|3.4| deep learning? If we have the same multi layer perceptron that
796.88|4.08| has been around for such a long time? And how is it different
800.96|7.64| from a neural network? What's the difference? Yeah, now the
808.6|4.16| interesting question is, is this really deep learning? I mean,
812.76|3.08| multi layer perceptrons have been around, I would say for 50
815.84|4.44| years, approximately. So yeah, can we really call that multi
820.28|4.04| layer perceptron, we just saw deep learning. So according to
824.32|4.84| the recent trends, when I look at recent papers, it's more and
829.16|3.28| more common to call these multi layer perceptron steep
832.44|5.08| learning. So here's just a figure I saw recently in a paper,
837.52|3.36| I don't want to reference this paper in this case, because I
840.88|3.12| think, I don't know, I don't want to blame anyone for calling
844.0|3.12| this deep learning. So I don't want to call out certain people
847.12|4.0| here. But here in this paper, I read, for example, there was this
851.12|3.56| figure of a multi layer perceptron, where there were only
854.68|5.0| 10 inputs, very small numbers of hidden units, and then one
859.72|5.8| output. So output unit. So here, they call it yet deep learning
865.52|6.12| and essentially proposed this deep survival model. So yeah,
871.88|2.44| like I said, it's more and more common to call these multi layer
874.32|3.6| perceptrons deep learning. Traditionally, when the term
877.92|3.2| deep learning was coined, like I mentioned in the introductory
881.12|4.9| lectures, it usually referred to the feature learning by using
886.02|4.06| certain tricks that are a little bit about beyond the regular
890.08|2.68| multi layer perceptrons, where we had certain algorithmic
892.76|2.76| improvements of neural networks that make the learning more
895.52|4.56| efficient. But yeah, nowadays, multi layer perceptron, I would
900.08|7.08| say is already deep learning in a sense. Yeah, another very
907.16|4.28| important point is that now, in a multi layer perceptron, the
911.44|4.48| loss is not convex anymore. So linear regression, Adeline
915.92|4.36| logistic regression, and softmax regression, we had convex loss
920.28|4.72| function. So for example, for linear regression, if we recap
925.0|3.4| how the loss looked like, let's say with respect to one weight,
928.4|3.08| because it's easier to draw, it would be something like this
931.48|4.52| bowl shape here, where let's say we start with an arbitrary
936.0|3.48| weight value here, let's say we start with weight zero here. So
939.48|6.76| the loss would be very high when we start. And then we go down
946.24|5.28| with gradient descent till we reach this global minimum. Yeah,
951.52|3.04| now, in the case of multi layer perceptrons, it's not that
954.56|3.56| simple anymore. We don't have such a nice convex loss function
958.12|3.96| where there's only a path downward to the global minimum.
962.08|5.52| So in fact, these are highly non convex loss surfaces now. So I
967.6|4.72| found a nice paper that is about visualizing the loss landscapes
972.32|4.48| of neural networks. So here, this is for if you have or
976.8|3.92| consider two weights in a neural network. So if we have, let's
980.72|9.08| say, w one and w two, let's say w one, one, w two, one, and let's
989.8|3.08| say in the first hidden layer, because there are many, many
992.88|3.56| weights in the neural network, but you can see that this loss
996.48|4.24| is highly complex, there are many, many local minima going on
1000.72|6.12| here. And here, I think that should be the global minimum. So
1006.84|3.6| if we find the values of the weights that we are here at this
1010.44|5.48| point for this loss, so here, the loss value, let's say, the
1015.92|5.56| higher, this is the maximum, the higher, the larger, the loss, and
1021.48|3.84| the lower, the lower the loss. So if we add this global minimum
1025.32|2.48| here, then we would have minimized the loss function with
1027.8|4.74| respect to the weights. However, depending on what our starting
1032.54|4.18| weights are, so technique, typically in the context of
1036.76|3.94| neural network training, we start with small random weights.
1040.8|4.76| So one reason is why we start with small random weights is
1045.56|4.08| that we want to try different configurations. So for example,
1049.64|4.56| if we have a configuration of weights, we may start here, we
1054.2|3.12| could start here, or here, depending on what our initial
1057.32|3.56| weights are. And it's not uncommon that we get stuck in a
1060.92|3.44| local minimum. So we reach one of these local minima, and then
1064.36|4.64| the algorithm gets stuck. In practice, it's actually, almost,
1069.0|2.72| I would say impossible to find the global minimum. So you never
1071.72|4.0| know whether you reach the global minimum. Usually, common
1075.72|3.08| knowledge is that you will end up in some of the local minima.
1079.1|4.14| And it's not uncommon that because of that to start the
1083.24|3.2| net neural network training multiple times worth different
1086.44|3.24| random seats. So sometimes you have a better random seed for a
1089.68|4.1| given network than other times. So sometimes you will notice
1093.78|2.78| that you will have a better performance just by changing the
1096.56|4.08| random seed. So in papers, it's does also not uncommon to let's
1100.64|4.44| say run a network training five or 10 times, then take maybe the
1105.08|3.72| best three runs and then average over them and report the
1108.8|5.12| standard deviation and things like that. Yeah, so we deal now
1113.92|4.2| with this highly non convex loss surface. And in the next couple
1118.12|4.48| of lectures, we will also talk about tricks for learning rate,
1122.64|3.08| choosing learning rates, choosing initial weights and
1125.76|4.06| choosing optimization algorithms that can help jumping out of
1129.82|3.62| these local minima once we get stuck. So there are certain
1134.36|3.0| tricks and improvements to make the learning more efficient
1137.36|4.2| compared to the traditional stochastic gradient descent
1141.56|5.32| version. Yeah, beyond choosing good starting weights, and good
1146.88|2.68| learning rates and good optimizers. It's also very
1149.56|3.28| important to choose good activation functions and
1152.86|4.22| combinations of activation and loss functions. So here, I'm
1157.08|3.84| just want to illustrate a problem with certain activation
1160.92|3.9| and loss functions. And in the next videos, we will talk about,
1165.08|3.52| let's say alternative activation functions, which are nowadays a
1168.6|3.24| little bit better for training multi layer perceptrons. So here
1171.84|3.24| for this example, consider we have a logistic sigmat
1175.08|3.84| activation, and the mean squared error function, loss function.
1179.28|5.24| So one problem we may encounter is that we may end up with very
1184.52|4.28| flat gradients. And especially then if the output is very
1188.8|3.28| wrong. But if you think about it, if we make a very wrong
1192.08|2.86| prediction, we want to actually have a large gradients, because
1194.94|4.24| then we can update the weights more if the grains are very
1199.18|4.38| flat, then there's almost zero weight update, and then we can't
1203.56|4.44| fix our problem of the wrong prediction. So recall how the
1208.02|5.38| logistic sigmoid function looks like. So if we have a logistic
1213.4|4.8| sigmoid function like this with a net input, then recall it was
1218.2|6.88| like this s shaped function. And let's say the true class label
1226.12|5.6| is one, but we return a very low probability like let's say oops,
1232.84|4.84| the probability class membership probability is 0.001 or something
1237.68|4.92| like that. Right? So if you look at this, a low, very negative
1242.6|3.04| net input in a low probability will result, of course, in these
1245.64|6.04| very flat gradients. So if you then look at the derivative of
1251.68|3.16| the loss function with respect to the weights, so here we have
1255.88|4.4| the derivative of the mean squared error loss, with respect,
1260.28|4.12| let's say to the activation, let's call it just sigma, just
1264.4|8.16| sigma here. And then this is partial derivative of sigma with
1272.56|5.76| respect to the net input. And then the last term, remember is
1278.84|4.84| the derivative of the net input with respect to the weight. So
1283.68|3.5| here, we are again using the chain rule. But if we have
1287.18|6.1| these, the derivative of the sigmoid here, and now see,
1293.3|3.66| combined with the MSE doesn't cancel so nicely. So when we
1296.96|3.88| had the binary cross entropy, and the sigmoid activation,
1300.84|4.76| things canceled nicely, that we ended up with this nice learning
1305.6|4.96| rule, right. So with this nice learning rule, we didn't have
1310.56|3.0| this problem. But if we use, for example, a mean squared error
1313.56|3.24| function, combined with the sigmoid activations, we end up
1316.8|5.48| with this derivative here that has the problem that it has this
1322.28|5.68| term itself. Now, if this term is very small, so if we make a
1327.96|3.68| we make a very wrong prediction, let's say 0.001, maybe even
1331.64|5.44| smaller, let's say 0.00001, then we multiply this very small
1337.08|3.84| value with all the other values here. So the whole derivative
1341.0|3.36| will become very low or very small. And then we will almost
1344.84|3.52| update our weights by nothing. So in that way, we can't fix
1348.36|3.12| this wrong prediction. So it's kind of also important to think
1351.48|5.04| a little bit about what types of activation functions we combine
1356.52|5.36| with which types of loss functions. Here's another point
1361.88|3.08| I made. But here, this point is really, I was just saying, if
1364.96|4.16| you have a multi layer network, of course, you would use a soft
1369.12|2.4| max activation if you have mutually exclusive classes
1371.52|3.56| instead of sigmoid activations in the last layer, but the same
1375.08|3.04| problem would still exist. So that doesn't really solve all
1378.12|3.84| problem, I just wanted to add this as a small note. Alright,
1381.96|3.6| so the next video, I will show you then different types of
1385.56|3.64| types of activation functions that are a little bit better
1389.4|3.0| than logistic sigmoid functions in the multi layer perceptron.
1392.84|4.68| But yes, an ungraded homework exercise or Piazza discussion
1397.56|6.12| point, I wanted to, I wanted you to think about a little aspect
1403.68|3.32| about multi layer networks. So I have a question here for you.
1407.24|3.88| What happens if we initialize the multi layer perceptron to all
1411.12|4.28| zero weights. So before I mentioned, we use different
1415.4|5.72| small random weights to escape these local minima or just to
1421.12|4.04| have different starting points. So we may end up finding better
1425.2|3.08| local minima if we run this multiple times with different
1428.28|5.76| random starting weights. But now consider the case where we set
1434.04|4.56| all the weights to zero, it's just unrelated to these local
1438.6|3.56| minima. I just wonder if you can think of what happens if we
1442.16|2.84| choose all the same values for the weights, because you may
1445.0|3.28| think, okay, why do we use small random values? Why don't we use
1448.38|4.22| just small numbers and have the same number for each weight or
1452.6|4.26| have all the weights at zero. So that's maybe something to think
1456.86|5.06| about. And then in the next video, we will talk about non
1461.92|7.0| linear activation functions.