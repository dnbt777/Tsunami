start_time|end_time|text
5.9|6.38| Yeah. Yeah, no, let me go over some of the necessary machine
12.28|3.08| learning notation and jargon, something that we will be using
15.36|3.52| in this class over and over again. And that is also commonly
18.88|4.16| used in the machine learning and deep learning communities. So
23.04|2.92| yeah, I'm revisiting the term supervised learning. What is
25.96|3.04| supervised learning? It's about learning a function that maps
29.0|6.1| some input x to some output y, where x are the features, and y
35.1|3.36| are the targets. So yeah, like you remember from the previous
38.46|6.04| videos, the features, or we also call them observations. They are
44.5|5.16| usually vectors, or, for example, the flower dimensions,
49.7|4.32| sepal length, sepal width, petal length, and petal width, or
54.02|4.16| pixels of an image and so forth. By the way, if I write a vector,
58.18|3.96| I would then if I do use handwriting, use this a little
62.14|3.96| arrow to denote a vector. And I will try to use, if I don't
66.1|3.36| forget, an underscore and a capital letter to refer to a
69.46|5.04| matrix. And x, if I don't use any of this would be a scalar
74.5|4.4| value. So here, though, I was just writing x as a scalar, but
78.94|3.92| features in practice can be also vectors. So anyways, we are
82.86|3.76| getting ahead of ourselves here a little bit. So the next term
86.62|3.76| here on this slide is structured data, which we discussed also
90.38|3.36| in the previous video. So the term structured data usually
93.74|4.64| refers to data in a format of tables cannot also think of it
98.38|7.88| as tabular data usually comes in the form of databases, like if
106.26|3.32| you know SQL databases, for example, or if you think of
109.86|5.24| Excel spreadsheets or CSV files, this would be a typical example
115.1|4.6| of a structured data set. Then your unstructured data, this is
119.7|4.68| usually what we refer to as the raw data, for example, images,
124.5|3.68| the pixels and image, audio signals or text sentences like
128.18|4.52| documents. And this is usually something that yeah, deep
132.7|3.68| learning works with. So and before deep learning, we usually
136.38|3.2| needed extensive feature engineering, as I explained
139.58|4.6| before, where we extracted features from raw data sources.
144.18|2.64| So here on the right hand side, I just wanted to show you
146.82|7.12| another example of raw image input versus something that
153.94|3.24| requires feature engineering. So for example, here you have a
157.18|5.44| portrait of image. And let's say the task is face recognition,
162.62|5.56| where you want to match multiple faces. So here, I don't have
168.18|2.52| multiple people where we want to compare whether it's the same
170.7|3.12| person or not. So we don't have really face recognition matching
173.82|4.76| however, what I'm illustrating here is that we can extract
178.58|4.72| features from this image. So here, this is a traditional
183.3|4.44| method using like facial key point extraction. So we're
187.74|4.96| extracting so called face landmarks. And this would be a
193.1|5.12| feature engineering step, like simplifying the image, such that
198.22|3.56| it only now contains these key points, I think they are on 67
201.78|3.96| or so key points. So we reduced the complexity of the data set
205.74|3.08| by having a high dimensional data set. So if this is for
208.82|8.72| example, 200 by 200 pixel image, we would have 40,000 pixels or
217.54|3.4| 40,000 features, including background and everything. And
220.94|4.08| we here we just simplified it and only have I think it's 67
225.06|3.36| features, I could be wrong, you would have to double check. So
228.42|4.28| here, this is actually a function I implemented based on
234.34|4.32| library called D lib, which implements this face extraction.
239.54|3.32| Here, I'm just I implemented a Python wrapper function to make
242.86|2.8| it a little bit simpler to use any case. So here, this would be
245.66|4.04| an example of manual feature engineering, like reducing the
249.7|3.48| complexity of the problem by extracting a smaller number of
253.18|7.2| features from this raw input. Okay, so moving on. So here on
260.38|4.24| this slide are some more terminology. So a training set,
264.62|4.8| we usually refer to it as D. And a training set comes in pairs of
269.62|3.72| these observations, the so called training examples, or
273.34|6.28| features, and the target labels. And like I said, I will be using
279.62|3.28| this arrow notation, if I do handwriting to refer to
282.9|4.28| vectors. So and if I don't do handwriting, like in the slides,
287.18|5.56| using the computer font, I will make them bold. And yeah, for
292.74|4.96| scalars, I won't use bold font, then a training data set
298.38|3.88| consists of n training examples. So that's the number of examples
302.26|4.84| in the training set. And I will be using the squared bracket
307.1|4.16| notation here as a superscript to refer to the training data
311.26|5.92| points index. So if I write something like 10, then this
317.18|6.6| means that's the 10th training feature, feature vector in the
323.82|2.72| training sets, I'm referring to the 10th training example to the
326.54|5.16| feature vector of the 10th training example. So then, in
331.7|3.32| practice, so usually the data set, the training data set
335.02|3.52| data set comes from some data generating distribution,
338.78|3.2| something could be a natural physical phenomenon that has
342.66|4.16| created our data and so forth. So there exists some unknown
346.82|3.56| function that associates our feature vectors with some label.
351.66|3.68| And the goal in machine learning is in supervised learning is to
355.5|5.68| predict the labels. So how we do that is by approximating this
361.22|3.48| unknown function. And yeah, traditionally, this is called
364.7|5.36| the hypothesis. Nowadays, I think the hypothesis term is a
370.06|4.04| little bit dated. We can just call that model, we don't have
374.1|3.04| to use fancy terms like hypothesis can just call that
377.14|4.32| the machine learning model. So it's like a more common way to
381.46|3.4| refer to it. So you can think of the machine learning model as a
384.86|2.88| function that approximates approximates this unknown
387.74|3.08| function. So it will, for example, in the classification
390.82|4.4| example, return a predicted label, so we can write the
395.22|4.24| predicted hit label as y hat, for example, or we can just
399.46|3.8| call it target, target t or output, oh, oh, it's maybe a
403.26|2.6| little bit tricky, because it almost looks like a zero. But
406.42|4.04| yeah, these are all equivalent notations. So in this way, is
410.5|2.36| eight, you can think of it as the machine learning model.
414.34|4.68| Yeah, and classification again, so we have the model, which is a
419.02|4.76| function that maps some m dimensional input vector. So
423.78|5.48| this would be our features mapping those to some targets
429.26|3.56| here, where the targets in the term in the context of
432.82|4.08| classifications are class labels. So we can have up to k
436.9|5.68| class labels. So usually k is larger or larger equal to two,
442.62|4.12| we have at least two classes. In the case of the iris data set
446.74|2.6| that I've shown you earlier, there were actually three
449.34|8.28| possible classes on setosa, versicolor, and organica, for
457.62|4.96| example. But yeah, of course, really depends on the data set,
462.58|3.64| there is no limit to the number of classes you can have. Also,
466.22|3.72| yeah, in regression, we have an input vector that is m
469.94|3.76| dimensional, and we map that to a continuous to real valued
473.7|6.04| number. Yeah, more about the feature vector. So I said before
480.18|2.64| the feature vector is m dimensional. So if you think
482.82|8.56| back of the iris example, where we had the sepal length, sepal
492.06|10.44| width, petal length, and petal width, so we had four features.
502.5|7.32| And then if I look at the training index, let's say, focus
509.82|6.08| in on the third training example, I would write it down as
517.62|5.28| three. And then it's a vector. So it's a third feature vector.
523.22|4.16| So in this case, we have a vector of consisting of four
527.38|2.24| values. So this is what I'm showing you here as a vector
529.62|4.0| representation. So yeah, we have an m dimensional vector, and I
533.62|5.6| will use the subscript notation to refer to the feature index.
539.3|4.56| So if I write something like three here, this would refer to
543.86|6.76| the third, so 123 to the petal length of the third training
550.62|5.24| example. Now in Python, we start zero indexing. So if we do
555.86|2.72| Python coding, it might be a bit more complicated because we
558.58|5.6| should restart indexing at zero in contrast to R. So in, in
564.18|4.24| Python notation, this would be actually the fourth training
568.42|5.84| example. And the fourth feature like petal width. Yeah, moving
574.26|3.76| on. And now here I have a feature vector again, just as on
578.02|3.2| the previous slide. However, in practice, we usually have
581.26|3.76| multiple feature vectors. So one feature vector per training
585.02|3.4| example. So if you think back of the iris data set where we had
588.7|6.96| up to 150 training examples, let's use the letter n here over
595.66|5.92| the rows to refer to the training data points. And then
601.58|2.32| for each one, we had a feature, let's call that feature one,
604.34|4.36| feature two, feature three, and feature four. So we have this
608.7|6.72| table here. So you can also use, let's say, dot dot dot feature M.
616.18|7.12| So then each data point, so each observation is a feature vector.
623.58|4.72| So in linear algebra notation, we usually write a vector as a
628.3|4.16| column. However, we arrange the vector here as like a row
632.46|4.84| vector. So a row vector would be referring to one data point as
637.3|6.6| one observation. So we use a transpose on that one to refer
643.9|4.92| to this one here as the first data point in our table. It's
648.82|2.88| a little bit confusing the way I've written it here. Because
651.7|2.08| now I'm using the subscript. This is just because I have the
653.78|6.64| transpose here. And then it's a little bit squished. So actually,
660.42|4.8| I could have written it as transpose one, for example, it
665.22|3.96| would have been clearer, maybe. So maybe ignore this notation
669.34|4.04| here on the right hand side, I have the more extended notation
673.66|5.52| where I'm referring with a superscript to the data point
679.18|4.68| index. So this would be all the first data point here in the
683.86|4.88| first row. And then the subscript refers to the feature
688.74|5.4| index. So if I pick, for example, this case here, this
694.14|3.8| would be what is maybe unfortunate, let me use this one
697.94|4.72| here. This is the second feature of the nth data point. So this
702.66|3.58| would be if I go right here, this would be this one here. So
706.24|4.02| this scalar value. So usually a machine and we use a design
710.26|5.24| matrix, I will use bold letters. And if I handwrite this, I will
715.5|3.12| try to use an underscore to make sure or to indicate that this is
718.62|3.6| a matrix, because with handwriting, it can be unclear
722.22|3.8| if I do an x, it's unclear. If I don't, yeah, denote it further,
726.02|3.2| whether it's a vector or matrix, and so forth. So for again, for
729.22|3.56| vectors, I will use this notation and for matrices, this
732.78|5.28| notation. And I may forget, but I will try not to. Okay, yeah,
738.18|3.36| just to summarize, this is a structured data set how it would
741.54|3.8| look like in machine learning. In the first couple of lectures,
745.34|3.0| we will actually be using with structured data before we go
748.34|4.68| into working with unstructured data. So in the first couple of
753.02|3.84| lectures, just as a warm up using simpler, deep learning
756.86|2.84| related methods like single layer neural networks, and then
759.7|4.64| multi layer neural networks that are fully connected, they will
764.34|3.48| be working with also structured data. And then when we talk
767.82|3.12| about convolutional networks and recurrent neural networks, which
770.94|3.76| are the real innovations in deep learning, then we will be using
774.7|6.16| unstructured data. Alright, so yeah, just to recap, m is the
782.34|9.44| feature number. So we have up to m features and n is the number
794.26|7.24| of training examples. So I think the reason why I left the
801.5|4.24| blank here, I wanted to ask you that as an exercise. So in that
805.74|5.48| way, um, I already did the exercise for you. So here, the
811.26|4.8| rows thing, it was what I was referring to our training
816.06|11.84| examples, where the columns are features. And this is our class
827.9|5.4| class label column. Alright, so it was not very exciting. But
833.3|4.56| I was just summarizing how we think of a data set in the
837.86|6.96| context of machine learning. Now, if we have image data, how
844.82|4.88| do we deal with that? How does it fit into our concept of
849.82|5.04| representing data? So images are actually unstructured data, as
854.86|2.36| I mentioned before, but we can actually convert it into a
857.22|4.76| structured data set. And if you think of image like this, this
861.98|8.68| is actually a 28 by 28 image, which should be 784 dimensional.
870.66|6.04| So we have 784 pixels, pixels are usually in the range between
876.7|6.68| zero and 255. However, here, assume I normalized the data,
883.38|4.64| we will talk more about why data normalization is useful. I
888.02|3.12| normalized it such that the pixel values are in the range
891.14|7.72| between zero and one. So we have a pixel like a 700 of these
899.74|5.44| 384 of these pixels here. So you can actually all can see this
905.18|2.88| actually low resolution, one pixel here and one pixel here
908.06|3.64| and so forth. So I think you know what I mean by pixel. So
911.7|3.44| we can actually use that as input to a traditional machine
915.14|3.36| learning method in terms of thinking of this as a structure
918.5|4.08| data set by concatenating the rows. So we can make a long
922.6|3.46| feature vector out of this image, because I mean, this is a
926.06|6.04| matrix, right? So it's like a 28 by 28 matrix, but we can
932.1|4.52| convert this into a vector by just concatenating. So take the
936.62|7.18| first row, let's say this first row here. And then we have the
943.8|7.58| second row. And just add it here to the first row. And then third
951.38|5.94| row. Adding it here. So and if I keep doing that, I get a very
957.32|6.1| long vector, in fact, a 784 dimensional vector. And that is
963.42|3.82| what I'm showing you here in the center. We're probably already
967.24|2.84| wondering what these numbers are. And these are the pixel
970.08|5.52| values. So the 0.0 refers to a white pixel. So you can see in
975.6|4.0| the beginning, here, the image is all white. So you have all
979.6|5.92| the white 0.0 is here. And then you have these grayscale and
985.52|5.36| black pixels, which are about here. So we kind of converted
990.88|3.8| this unstructured data set into a feature vector that we can then
994.68|3.76| use with traditional methods. And we will also be doing that
998.44|3.68| in the context of deep learning using simpler methods like
1002.12|3.32| multi layer perceptrons, fully connected neural networks. So we
1005.44|3.12| will start with a simple approach and then build up to
1008.56|3.96| it and then later use the unstructured data directly. All
1012.52|3.84| right. So yeah, like I said before, convolution neural
1016.36|3.44| networks, which will be a topic later on in this course,
1019.8|4.08| convolution neural networks, they use the image data
1023.92|5.0| directly. And usually the format for that is also a matrix or
1028.92|3.28| more precisely, it's actually a three or four dimensional
1032.2|6.64| tensor. So here, so there are two, two common representations,
1038.84|5.12| one is called n ch w. We will talk more about that later when
1043.96|2.56| the time comes. But maybe if you're curious what it stands
1046.52|5.88| what it stands for, h stands for the height. W stands for the
1052.4|4.56| width of an image. So we have here the h times w. So this
1056.96|3.64| would be a matrix. However, there's usually also a color
1060.6|5.76| channel. So C stands for color. In this case, we don't have
1066.36|3.48| color because it's a black and white image. So in this case,
1069.88|2.96| it's so there's a one to actually I'm showing you here
1072.84|5.2| the dimensions. So 28 by 28 height times width, and then the
1078.04|3.88| color channel. And then usually in deep learning, what we do is
1081.92|4.0| we bundle a bunch of images together as input for the neural
1085.92|2.92| network. So and we have something called a batch size.
1088.84|7.0| So here I have 128 images where each image is a 3d tensor. So in
1095.84|3.88| that way, if I consider all of that, it's a 40 tensor. So in
1099.72|4.86| that way, we are representing the data as tensors. And this is
1104.58|5.26| why we need some basic linear algebra for this course while I
1109.84|3.28| mean, we won't be using fancy things, just simple matrix
1113.12|3.36| multiplications and dot product. And I will also talk more about
1116.48|2.52| that later. So right now, I don't want to go into too much
1119.0|4.76| detail because convolutional networks, that is topic far
1123.76|3.48| ahead a few weeks ahead. So I don't want to talk too much
1127.24|2.76| about this year, I have to be honestly, a little bit careful
1130.0|4.3| with the time because like you noticed, I always try or I try
1134.3|4.26| to avoid it, but I always end up going on tangents and talking
1138.76|3.48| about things in too much detail too early, I think. So let me
1142.24|5.12| move on then. Yeah, here, lastly, machine learning jargon
1147.6|3.72| part two. So some more terms we will be using, I think this is
1151.32|3.52| more like useful as a cheat sheet, like something you can
1154.84|4.96| maybe refer to later, when certain terms are unclear. So
1159.82|3.22| when we say, for example, training a model, that is the
1163.04|2.96| same as saying, for example, fitting a model or parameter
1166.0|3.84| raising a model or learning from data, then the other word
1170.0|3.36| training example, it's synonymous to saying, for
1173.36|3.28| example, training record or training instance or training
1176.64|4.56| sample. However, yeah, for example, when I teach other
1181.2|4.92| statistics classes, I usually use often as the decisions we
1186.12|4.16| use the term sample. But I find sample can be a little bit
1190.28|3.0| ambiguous, especially in the context of deep learning.
1193.28|3.8| Because if we say training sample, it's not clear really,
1197.24|4.08| whether we are we are referring to a single training data point
1201.36|2.96| or multiple training data points. So for example, when I
1204.32|3.02| was writing my Python machine learning book in 2015, in the
1207.34|4.32| first edition, I used the term training sample as I remember, I
1211.66|2.94| mean, it has been six years ago, but I think I used training
1214.6|2.52| sample throughout. And then sometimes I noticed it was a
1217.12|2.92| little bit confusing. Do I mean now a single data point? Or do I
1220.04|2.96| mean the training data set as a training sample? So I later also
1223.0|4.8| went back and changed everything to saying training example, if I
1227.8|3.88| refer to a simple or single training example. And then also
1231.68|3.64| in plural, I would say training examples. I think this is a
1235.32|3.56| little bit more clear. And this is also something most people in
1238.88|3.0| machine learning and deep learning nowadays use. So the
1241.92|4.12| term training example, then yeah, feature feature is also
1246.04|4.08| synonymous to observation or predictor variable, independent
1250.12|3.4| variable input attribute covariate. So in other
1253.52|3.0| statistics classes, we are often using the term, for example,
1256.52|4.04| predictor, and things like that, or even covariate. So here in
1260.56|1.92| machine learning and deep learning, we usually use the
1262.48|5.04| term feature. Then we have the term target, which is synonymous
1267.52|3.8| to outcome ground truth, output response variable, dependent
1271.32|3.36| variable, and then a specific context of classification, we
1274.68|4.84| also say class label or just label. So also, these are all
1279.52|3.8| the same thing. And then yeah, lastly here, output prediction.
1283.32|3.64| And this is what the model produces. This is different from
1286.96|4.56| the target. So the target is, we want to predict the target. So
1291.52|5.16| this is the ground truth or something that is provided in
1296.68|4.56| the data set. And the prediction or output is the thing that the
1301.24|4.92| model returns, and we want to usually match the target. Okay,
1306.16|3.72| so this is it for jargon. And the next video, I want to
1309.88|3.32| briefly talk about a little bit more about the tools that we
1313.2|8.44| will be using in this course.