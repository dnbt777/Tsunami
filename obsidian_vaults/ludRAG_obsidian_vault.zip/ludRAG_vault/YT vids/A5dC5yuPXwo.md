start_time|end_time|text
0.6|3.92| All right, let me now show you how we can implement this all
4.52|2.76| convolutional network that I discussed in the previous
7.28|4.2| video. So here I have a code notebook, I will of course,
11.5|3.54| shared as usual. And also, as usual, I want to run this
15.04|4.1| because it took like 45 minutes to run this whole notebook. And
19.14|2.54| yeah, there was actually an interesting question on Piazza
21.68|4.66| regarding the runtime of the homework. So a student was
26.34|3.1| asking whether it's normal that it takes like eight minutes to
29.44|3.36| run the notebook. Yeah, that is totally normal in deep learning.
32.8|3.76| It's actually pretty fast eaten. So yeah, deep learning is of
36.56|2.68| course, a little bit different than traditional statistics
39.24|3.56| where we usually work with small data sets like little tables of
42.8|4.64| data. So here we have really large data sets and complicated
47.44|3.06| models with many, many, many parameters. So yeah, it takes
50.5|4.36| usually a long time. So some people actually use hundreds or
54.86|4.18| 1000s of GPUs for multiple weeks to train these cutting edge
59.04|3.22| vision and language models. So you can actually get good
62.26|2.32| performance also with efficient models that only run a few
64.58|4.44| hours. But honestly, if you have a real world data set, sometimes
69.02|2.68| you have to be patient, sometimes it takes a few days.
72.1|2.72| Also, so this model here is relatively simple. We have the
74.82|4.4| cipher 10 data set. So luckily, it only takes 45 minutes. But
79.22|2.72| yeah, that is still a long time. And we probably want don't want
81.94|3.32| to wait 45 minutes here during the video until it finishes
85.26|2.88| training. So I'm not going to rerun this. But yeah, I will
88.14|6.16| share the results. So everything here is exactly the same as in
94.3|5.52| the VGG 16 notebooks. So I don't have to recap all of that. The
99.82|4.32| only new part is really here this code of the all convolution
104.14|4.08| network can make this maybe a little bigger. Um, yeah, I'm
108.22|4.44| seeing I was writing this very verbose. So you actually, if you
112.66|2.84| have the same height and width, just a small comment here, if
115.5|3.12| you have the same height and width for kernel size and
118.62|3.76| stride, you can also replace this by just three and this just
122.38|4.36| by one, for example. So here, the first value always stands
126.74|2.8| for the height. And this is for the width. And this is also for
129.54|4.84| height and for the width. So yeah, because it's all about
134.38|2.52| simplifying convolution networks, here, you will only
136.9|4.44| see convolution layers and relu layers and the batch norm
141.34|5.9| layer, no max pooling and no fully connected layer. So you
147.24|3.1| can further of course, simplify it by not using batch norm. I
150.34|2.88| think batch norm was not even around and not even invented or
153.22|3.76| around when this architecture was proposed. But I didn't get
157.06|3.0| really good results without batch norm. So I just added it.
161.06|3.32| And the rest is just like the paper that I showed you this
164.9|3.72| striving for simplicity paper. But yeah, except that I added a
168.62|6.08| batch norm. Um, yeah, and all I can tell you here is that we
174.7|6.2| have convolutions. And here, we have always like one convolution
180.9|3.36| that increases the number of channels, but it keeps the input
184.26|3.68| and the output size the same. So this is like the same
188.26|3.24| convolution that we talked about, I use the padding of one
191.5|3.64| to achieve that. So the input is 70 pixels, the output will also
195.14|5.6| be 70 pixels. And then so here, there's always a conversion that
200.74|4.04| increases the channels. Because each channel can be thought of a
204.78|2.72| feature map from a different kernel or feature extractor.
208.42|3.88| That is how the network learns to extract different features.
213.66|4.04| And then there's always a convolution that keeps the same
217.7|4.16| number of channels. And this one has the stride of two. And this
221.86|5.52| is these are the equivalence of the max pooling with kernel size
227.38|6.0| of two by two and stride of two. So this is here, this is the one
233.38|4.48| for reducing the height and width. And then we have again,
237.86|4.56| one that increases the channels with a stride of one, so it
242.42|3.36| keeps the input and output height. And then we have again,
245.78|4.68| one that here with a stride of two, just reduces the height and
250.46|4.96| width by a factor of two. And we keep doing that a couple of
255.42|4.24| times. And then in the end, we have 10 classes, right? So in
259.66|6.28| cipher 10, we have 10 classes. So in my last convolution layer,
266.18|3.6| I have now the number of output channels equal to the number of
269.82|5.72| classes. And in pytorch, there is for some reason, no global
275.54|2.72| average pooling, global average pooling is essentially just
278.26|4.56| computing the mean over the channels. So also for each
283.02|2.4| height and width for each channel, you would compute the
285.42|4.08| mean, you could technically implement that very, yeah, in a
289.5|3.16| very simple way. So that's probably why they didn't have a
292.7|3.48| global average pooling layer in pytorch. But you can also,
296.18|3.24| instead of just implementing averaging layer, you can also
299.42|3.8| use this adaptive average pooling 2d with an input of one
303.22|3.32| that has the exact same effect as this global average pooling.
306.54|5.12| So adaptive average pooling is a layer that is quite versatile.
311.7|4.08| So what it can do is, it will produce the size that you
315.78|4.24| desire. So if you put a two here, it will produce two by two
320.02|4.32| outputs. If you put a one here, it will produce a one by one
324.34|7.52| output. So if I go back to my lecture here, so this global
331.86|3.0| average pooling will be the same as this adaptive average
334.86|2.76| pooling. So it will take the whole feature map, produce the
337.62|3.28| size of one here. So that is what we are doing now. So we are
340.9|4.4| reducing this one to a size of one, I actually don't even know.
346.02|4.36| I probably should have prepared this. But I don't know what the
350.38|3.52| size before this is, it's probably I don't know, maybe eight
353.9|3.68| by eight or something like that. You can actually double check
357.58|8.76| that by removing this part. And then just doing a print x size,
366.38|2.48| and then you can find it out if you don't want to do the math.
369.34|3.28| But I'm not doing that now, because then it will crash the
372.62|5.24| output here. So that is how you can find out at home, you can
377.86|3.24| wake and just make a copy. To be honest, let's do that. Why not?
381.1|24.6| Let's do that. Why not? All right. So it's eight by eight,
405.7|2.56| like I thought. So it was actually a pretty good guess.
408.26|5.8| All right, so, um, back to the code here. So, um, yeah, so we
414.06|3.6| have now this global average pooling or here called adaptive
417.66|2.52| average pooling instead of the fully connected layer that we
420.18|4.32| had in VGG 16. And then I'm training the network using very
424.5|4.24| simple setup, the same as for VGG 16. It's training. It's a
428.74|2.92| very simple network. So it doesn't really train that long.
431.7|3.64| It doesn't have so many parameters. I mean, not as long
435.34|5.28| as the VGG 16. So the VGG 16, like, double check here, it was
440.62|6.36| probably long time, 90 minutes. So this only took half the time
446.98|4.48| then 41 minutes, it doesn't get the same good performance, it
451.46|5.96| has 80%. I think this one has 84 85%. So it's not as good, but
457.66|4.88| twice as efficient. Alright, so yeah, this is how all conversion
462.54|3.36| network works without max pooling and without fully
465.9|3.48| connected layer. In the next video, I will show you how we
469.42|4.88| can alternatively replace fully connected layers by convolutional
474.3|3.2| layer. So here, we learned how to replace it by average
477.98|2.72| pooling, but average pooling doesn't have any parameters. So
480.7|3.68| it's replacing the fully connected layer, but it's not
484.38|3.4| equivalent. It's of course different because now we replace
487.78|2.36| it by a version without parameters. The next video, I
490.14|3.52| will show you how we could technically if we wanted to
493.66|26.52| replace the fully connected layer.