start_time|end_time|text
0.7|3.06| All right, let us begin by looking at a variational auto
3.76|4.84| encoder for handwritten digits in pytorch. So this is our MNIST
8.6|3.64| data set. Starting simple, I have a bunch of code examples, I
12.24|3.48| will show you one at a time. So starting with the simplest one,
15.72|3.08| this is our variational auto encoder for MNIST. And I
18.8|2.88| implemented it as a convolutional variational auto
21.68|3.96| encoder. Of course, you can also implement it with fully
25.64|3.72| connected layers. But since MNIST is an image data set, why
29.36|3.7| not using convolutional layers. And also, yeah, the structure
33.06|3.14| will be similar to the auto encoder that I implemented in
36.2|3.48| the previous lecture, except of course, that we have the
39.68|4.46| differences with using this mean and log bar vector, and then
44.14|3.22| also having the KL divergence term instead of just a
47.36|3.72| reconstruction loss. All right, one thing at a time. So as
51.08|3.66| usual, I have helper functions so that the notebook is not too
54.74|3.66| cramped. Actually, on the last couple of days, I received a few
58.4|3.12| questions from students regarding these helper
61.52|3.36| functions, whether it's okay to use them in a class project. And
64.88|3.58| yes, of course, it's okay to use them. I mean, I actually wrote
68.46|2.82| them for this class to keep things more organized, because
71.28|3.64| I'm reusing most of them from week to week. And instead of
74.92|3.36| copy and pasting the contents always in that notebook here, I
78.28|2.84| thought it's more organized to have this as separate functions.
81.12|3.2| For instance, in my helper train function, I have still the
84.36|3.64| classifier function that we used before the auto encoder, the
88.0|3.32| regular auto encoder, then the variation auto encoder, and so
91.32|2.8| forth. I feel like instead of copying all that into the main
94.12|3.64| notebook, for all the five auto encoders here, having it one
97.76|2.64| time here, and importing it is kind of cleaner and more
100.4|4.16| organized. And you're of course, welcome to reuse everything that
104.56|3.76| you can find here. Also, with any kind of code you find on
108.32|4.16| GitHub, chances are that you are free to reuse it. Usually,
112.64|3.08| especially in educational contexts, you just have to cite
115.72|3.04| the source. So that's clear that it's not your code that it is
119.32|3.72| not plagiarized, if you make clear where you have the code
123.04|4.04| from. But if you show where you have the code from, then it's
127.08|4.24| usually fine to reuse the code. Of course, there may be certain
131.32|3.44| types of code that have a license that don't permit that.
134.76|3.2| But unless it's stated explicitly for educational
137.96|4.16| purposes, it's of course, okay to reuse that. And yeah, my
142.12|3.12| code is written, I wrote this, especially for educational
145.24|3.0| purposes. So please feel free to use any of that for your class
148.24|3.76| projects. But yeah, I'm moving on. So I have my helper
152.0|2.78| functions. When the time comes in the code, I will explain what
154.78|5.3| they are doing. Here, this is like usual, we have our boiler
160.08|7.04| plate, batch size 256, small learning rate, 50 epochs, we
167.12|2.64| don't need classes, actually, I don't know why headed there,
169.8|4.48| probably copy and paste errors. Then we are using the MNIST
174.28|3.4| data set, we don't need validation data here. Because
177.96|3.22| yeah, we are only you mean, variation auto encoders are
181.18|6.78| unsupervised, we are only using the images. Yeah, here, I'm just
187.96|2.32| checking that the data set works. Again, we don't need the
190.28|5.48| labels. And here, it's the main model where it gets interesting.
196.2|5.64| So similar to the regular auto encoder, I set it up using an
201.84|6.6| encoder and decoder, both cases using sequential here. So this
208.44|7.24| is several convolution layers. And I should say, the latent
215.68|5.44| space is size two. So what I'm doing here is I'm compressing
221.12|5.96| it. And then here, I am reconstructing it into the
227.08|6.32| original space. So MNIST is 28 by 28. Here, I'm having a fully
233.4|4.12| connected layer, followed by convolutional transpose layers
237.52|3.24| or transpose conversion layers. And then I have this trim
240.76|2.4| function, the same one that I used in the regular auto
243.16|4.44| encoder, because it happens that it will be 29 by 29. And the
247.6|4.32| original images were 28 by 28. So I'm just trimming the last
251.92|5.12| pixel here. Okay, so there's one thing I have not talked about
257.04|3.24| that is kind of the essence of this variational auto encoder
260.28|4.04| what makes it makes it different from the regular auto encoder.
264.32|2.84| So for the regular auto encoder, we may have had something, let
267.16|9.2| me put it like here, we may have had something like this, where
276.36|8.64| we had 3136 up to two, if I want to have a two dimensional
285.0|3.36| latent embedding, I would have it like this for my encoder.
288.96|3.12| However, since this is not a regular auto encoder, it's a
292.08|4.72| variational auto encoder, we are going to work with this mean
296.8|7.32| vector, the mu and the log bar vector. So both are used for both
304.68|2.86| fully connected layers to compress whatever this is into a
307.54|3.58| two dimensional one. And the same thing here, so they are
311.12|4.62| separate, separate models, because if I would use the same
315.74|2.58| one, well, then the mean and the log variance would be the same
318.32|2.92| if I use the same linear layer, so I have to have two linear
321.24|4.84| layers. And now let me show you how I actually use them. I think
326.08|4.2| it makes more sense then. So let's take a look at the forward
330.28|2.32| method first, then I will explain you why I have this
332.6|3.64| method. So in the forward method, first, like in the
336.24|3.44| regular auto encoder, I'm calling the encoder first. So
339.68|5.2| this is encoding my image into the two dimensional space. So
344.88|10.24| let me bring up maybe on slides here. So this is encoding into
355.12|4.36| my two dimensional space. But we're not quite here yet. We are
359.48|5.24| somewhere here now in that orange part. And then what we
364.72|3.36| want to do is we want to get this mean vector and the log
368.08|7.32| variance vector. And then we call this reparameterization
375.4|4.88| function. So here, we will have two vectors. So it's maybe a
380.28|2.2| little bit unfortunate that I'm showing it as one, but there
382.48|3.76| would be actually two vectors, mean and the log variance. And
386.24|4.92| then we call the self dot reparameterize here on these two
391.16|3.76| vectors. And what is going on here is that I'm sampling this
394.92|6.0| epsilon from random normal distribution. So here, this is
400.92|4.92| equal to the input size. So if we, if we have a batch size of
405.84|16.84| 256, it will sample 256 of those. Okay, let's see. So that
422.68|2.92| is where we are here, this epsilon. So we are sampling now
425.6|7.0| the epsilon here, that's this one. And then we are doing the
432.6|5.44| reparameterization here, the mean vector plus the epsilon
438.06|4.54| times the standard deviation. So this is the standard deviation.
442.96|4.44| Why is that the standard deviation? That is the lock bar
447.4|5.12| trick, where did I have it here. So this was the lock bar trick,
452.88|5.64| because this allows us to have for this one, positive and
458.52|2.88| negative values, instead of just positive values, it is better
461.4|4.72| for back propagation. And this is essentially so this whole
466.12|6.16| step is, is the step here. Right, so then we are returning
472.28|7.56| z. And this z here is is this z here in the center that I'm
479.84|3.2| showing you. So I'm not showing you the mean and lock bar
483.04|3.4| vector, I'm only showing you the z here that comes out of here.
488.68|5.92| Okay, so reparameterize, then returns or z, I called it here
494.6|5.12| and coded, I could have also called it z. And then we are
499.72|5.92| decoding using our decoder. And our decoder takes this z back to
505.64|3.84| the 300 3136, and then runs through the convolutional
509.48|3.96| transpose layers, and reconstructs our input. Here, I
513.44|6.98| have the sigmoid. So the pixels are in the 01 range. And in
520.42|4.82| where is it? I have to go up. I think now it's in the data
525.24|6.68| loader in a data loader, I should probably show you the
531.92|3.0| data loader that we are that I'm not using any particular train
534.92|3.24| transform and test transform. And by default, I implemented
538.16|5.48| this at cipher 10. Sorry, where is this? Yes, I missed. Same
543.64|3.4| thing. I have this torch to tensor, it will automatically
547.48|5.48| convert images to 01 range. If we use normalize function that
552.96|3.92| such that let's say the pixels are between minus one and one,
557.12|3.92| that would also work. But then we also have to make sure that
561.04|5.36| we use 10 h here, right, because we want the pixel ranges between
566.4|4.16| the input and the output to be on the same range, because we
570.56|3.7| want to have the MSE, right. So if the input pixels are between
574.26|2.78| zero and one, then the reconstructed pixels should also
577.04|5.24| be between zero and one. Alright, so going on here, again,
582.28|4.72| the forward method, I'm calling the encoder, do the
587.0|5.04| repertorization to get my latent space. This includes this
592.04|3.96| epsilon from the random normal distribution. Then I'm calling
596.0|4.04| my decoder, and I'm returning a bunch of things here. That's
600.04|4.2| what I need for my back propagation. I will show you in
604.24|5.64| the training, I need all four of those. Later, I will do some
609.88|4.56| investigation and some experiments. I will show you some
614.44|3.6| interesting experiments later, for which I implemented also
618.04|3.44| this encoding function. So this encoding function is maybe
621.48|5.04| overkill to implement that I, yeah. I mean, why not? So in
626.52|2.88| this way, I don't have to run the decoder every time. So the
629.4|5.24| encoding function just returns z. So it's basically just this
634.64|3.86| part, if you take a look at this, if I just copy it below
638.5|5.02| here, you can see that's the same, same thing here, right. So
643.52|2.88| I just decoupled it for some reason, I could have actually
648.84|11.6| could have called it here on on x, for example, like this
660.64|3.32| should also work, except that I want these two for the loss
663.96|3.12| function. I think that's why I have it as a separate function
667.08|5.64| instead of doing, instead of doing this. But yeah, just a
672.72|3.72| minor implementation detail. So I have this also separately, if
676.44|3.2| we want to do some investigation later with some
679.64|3.52| functions I wrote. So yeah, for here for this notebook, you can
683.16|5.04| actually ignore that it doesn't do anything here. Okay, so
688.2|4.48| explain to you the forward path. So which is now encoder, the
692.68|5.76| reparameterization should probably reparameterization, and
698.44|2.72| then the decoding, and then we're returning these things in
701.16|9.12| the regular auto encoder, we only had this essentially, this
710.28|7.32| was our regular auto encoder. Now we have oops, also this
717.6|4.72| reparameterization mainly, and these two vectors. Okay, that's
722.32|4.32| initialize everything here. And then we run the training. Now
726.64|3.72| let's take a look at the training function. I'm actually
730.36|6.96| here. So that's my training function here. We have actually
737.96|3.84| two losses now. So by default, I'm using the MSC loss, we
741.8|2.32| discussed this briefly in the video why we don't use the
744.12|5.08| binary cross entropy here. The rest is boilerplate like before.
749.2|5.96| So this is just what we used every time, I just use this one
755.16|2.96| here, the underscore, instead of usually we had something like
758.12|3.08| labels or targets here, but we don't need labels or targets,
761.24|2.48| because it's an unsupervised model. So I just replace it by
763.72|3.76| underscore, underscore and Python is a convention that we
767.48|3.6| use if we don't use a variable, but we but the variable is
771.08|4.2| there, we just use an underscore. Okay, so we have
775.28|5.2| the features here from our data set. And then he I'm calling
780.48|8.78| model. So model will call execute for what gives us these
789.26|5.1| four vectors here, which are these returned from here. And
794.36|4.84| then I'm computing now, first, the KL KL divergence term. So
799.2|6.96| this term here that's computed is I had it somewhere here. So
806.16|6.1| this this this term here that I discussed in the video. And
812.26|3.26| notice that I'm using I'm summing here over the latent
815.52|3.56| dimension. So the sum here is over the latent dimension, I
819.08|3.36| forgot to have the index under the sum. But this is for the
822.44|7.32| latent dimension. Not for the batch size, we have then if we
829.76|3.0| want to compute the average KL divergence over the batch size,
832.96|4.96| we call them the mean here. So if I would not have access
837.92|3.48| here, you will probably get really bad results because it
841.4|6.8| will sum over everything. I mean, sure, why not, but you
848.2|3.48| should first sum over the latent dimension, and then you can
851.68|11.72| average over over the batches. Okay. Yeah, and then we compute
863.4|6.6| the pixel wise loss. So this is our reconstruction loss. Here,
870.0|3.42| it's calling loss FN, which is just loss function. And by
873.42|2.54| default, if I don't specify it in my function, it uses the
876.16|4.12| mean squared error loss. And the mean squared error loss is
880.28|6.0| between the decoded ones. So the reconstructed ones, and the
886.28|4.68| inputs. So this part here is really the reconstruction was
890.96|6.68| here. This is what you see at the top here. I'm reshaping it.
899.12|3.52| So that it's the batch size and the vector. So instead of having
902.64|6.36| a tensor, it's now a matrix table, if you will. And then we
909.0|3.96| first sum over the pixels. It's this is equivalent to summing
912.96|2.92| here over the latent dimension. So we are summing first, the
915.88|3.86| squared error over the pixels. So this is essentially the sum
919.74|8.22| here. I haven't done a reduction. Okay, I could have
928.32|4.96| forgot kind of thing it should do it means good. I forgot the
933.28|4.04| square root, but doesn't really matter. So I don't have a
937.32|2.88| square root. I shouldn't be a square root, to be honest,
940.88|3.48| because it's the squared here. We change that.
956.76|2.16| When you can have a square root doesn't really matter.
963.36|2.32| Okay, so that's not the Euclidean distance anymore, but
965.68|3.16| the square Euclidean distance doesn't really matter here.
969.56|6.24| Anyways, um, okay, so we have no pixel wise here, we sum over
975.8|2.6| the pixels, and then we average over the batch dimension.
983.12|2.08| That's where our mean comes from.
990.8|4.36| Okay, then we compute the overall loss and the overall
995.16|4.8| loss consists of two parts, the reconstruction, or sorry, the
999.96|3.6| pixel wise loss and the KL divergence term. And here I have
1003.56|3.6| an additional parameter. So I should probably also have that
1007.16|6.12| in the code. So let's call that L one is the reconstruction,
1013.28|7.0| let's call it alpha. Because it can give us a weight on because
1020.28|5.28| it may or may not be clear. I mean, they may not be in the
1025.56|3.96| same scale really depends on the images. So it's kind of a hyper
1029.52|3.44| parameter. It's like saying, how much should the model focus on
1032.96|3.76| the reconstruction loss and how much should it focus on the KL
1036.72|4.68| divergence term, if we don't use alpha, if we if we set alpha to
1041.4|4.72| one, then there will be equal weight. But it might not work
1046.12|4.44| well in practice all the time. So it's another hyper parameter.
1050.56|4.56| Okay, um, yeah, this is essentially that then we can run
1055.12|5.32| our back propagation as usual. So just to recap, compute the
1060.44|3.88| KL divergence term, we compute the pixel wise term, and then we
1064.32|5.8| add both together. And we're training it, this is just the
1070.12|3.96| logging like usual, nothing new here. So let us take a look now
1074.08|5.4| how it trains and see it starts with a high loss and it goes
1079.48|9.36| down, which is nice. Because don't move slowly. Yeah, so I
1088.88|3.04| actually have two plots here, I have this plot training loss
1091.92|2.32| function that I used before. Now I'm doing it with a
1094.24|4.6| reconstruction loss per batch, the train, the KL divergence
1098.84|4.08| loss, and then the combined loss. So you can see, first is
1102.92|7.92| the reconstruction loss, it goes down. The KL loss goes down, but
1110.84|6.44| then goes up. Well, and the combined loss. It's kind of a
1117.28|10.04| trade off, right. But the combined loss goes down. Yeah,
1127.32|3.92| so overall, it goes down. And what we can see is on the
1131.24|6.88| autoencoder is able to generate realistic looking images. I
1138.12|2.8| mean, kind of. So again, we have the same problem. It's only
1140.92|4.2| two dimensional, which is kind of extreme. So you can see, so
1145.12|4.08| the top row here is original images, and the bottom row is
1149.2|5.28| reconstructed images. And you can see, okay, it confuses for
1154.48|3.36| with the nine. But most of the time, it looks kind of okay,
1157.84|4.36| okay, it's blurry to hear five and three, it gets confused. But
1162.2|3.76| this is really because the space is so cramped. So let's take a
1165.96|5.72| look at the latent space here. So I'm also showing the class
1171.68|3.24| labels here, you can see, okay, it's a bit cramped, because
1174.92|4.36| it's two dimensional. I don't like this overlap that things
1179.28|5.0| overlap, but well, it's all what happens here. But it looks
1184.3|2.3| slightly better than for the regular autoencoder. Unfortunately,
1186.6|2.72| I don't have it here for reference. But what you can see
1189.32|3.96| also now is that it's centered at zero, right, the distribution
1193.28|3.52| center at zero. And it looks like a Gaussian mixture at some
1196.8|2.96| point, I mean, kind of mean, we can't go by class labels,
1199.76|2.92| because it doesn't use the class labels, we would have to go by
1202.68|4.68| dimensions. It's hard to see here. But I have actually, for
1207.36|4.2| higher dimensional one, histograms, looking at the
1211.56|3.42| distributions per dimensions, it can be like, it's hard to see,
1214.98|3.5| because yeah, we can, it's too much going on here, it's too
1218.48|5.12| dense. But it could probably be a multivariate standard Gaussian
1223.6|8.64| at some point. I mean, here, we have some not so nice shape. But
1232.28|4.44| yeah, with a little bit of squinting, it looks quite okay.
1237.96|2.34| Yeah, and then we can sample from that distribution. So we
1240.3|3.06| could just take arbitrary points from a standard normal
1243.36|3.4| distribution, and then sample. So here, I'm just taking one
1246.76|9.92| point at the center should be 0.03 somewhere here, and it
1256.68|2.32| reconstruct an eight. So the eight is actually on another
1259.0|3.32| nine, it's kind of unfortunate. So it's reconstructing the eight.
1263.36|4.52| And here we are sampling now. So yeah, I'm just sampling from
1267.88|10.48| random normal distribution. Let me show you that plotting. What
1278.36|5.36| was this function called plot images sampled from VAE. It
1283.72|5.92| took me a lot of time to implement all that. Mike, I
1289.64|9.96| should be plotting. Yeah, this one. So yeah, here, what I'm
1299.6|5.26| doing is I'm sampling from a random normal distribution. So
1304.88|4.36| rent n is a random normal distribution. I'm sampling a
1309.24|4.2| given number of images here, 10. Latent size, I'm setting it to
1313.44|8.18| two here, because that's how I trained my auto encoder. Then
1322.34|3.64| notice that I'm not using the encoder here. I'm only using the
1325.98|5.56| decoder here. It's all I'm using. Um, yeah, and then I'm
1331.54|6.44| plotting. So here's just some for loop to do the plotting.
1337.98|2.4| This is very similar to the regular auto encoder code. I
1340.38|2.8| just copy and paste it and made a small modification. But
1343.18|5.04| essentially, this is just plotting these images. And these
1348.24|6.38| are just sampled from random normal distribution. You can see
1354.9|5.52| they look mostly reasonable. Not all of them. This is garbage.
1360.42|3.68| This this but the ones took okay, the sevens look okay.
1365.62|5.4| eights look okay. I think many of these problems are that in
1371.02|2.48| our case, we only have a two dimensional space. So things
1373.5|4.36| don't look great, but doesn't look terrible either. So if you
1377.86|3.12| make the latent space a bit bigger, it will look better. But
1380.98|4.8| yeah. Okay, so this is our variational auto encoder here.
1386.28|3.86| And I will stop this video. And then I will show you more
1390.14|11.44| interesting one with face images.