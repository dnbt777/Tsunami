start_time|end_time|text
0.48|3.0| Yeah, I'm not sure how that happened. But we are already at
3.48|4.32| 65 minutes in this recording. So we only have 10 minutes left.
7.8|3.36| So things took longer than I expected, like always. So but
11.16|2.64| yeah, we only really have one more topic left for today that I
13.8|2.96| wanted to talk about, because that's more like a fun topic.
17.24|5.48| So this topic is on manipulating the latent space or doing some
22.84|3.96| latent space arithmetic, we are going in particular, going to
26.8|2.88| focus on the variational autoencoder that we have trained
29.68|3.9| in the previous video on the celeb a face images. And what we
33.58|3.02| are going to do is we are going to take some of these face
36.6|4.6| images and making the people smile more. So let me give you
41.2|2.52| the brief outline of what we are going to do next in the code
43.72|5.48| example. So imagine we have this latent space here. So of course,
49.2|2.96| if you recall the previous video, we had a two dimensional
52.4|3.56| space, a 200 dimensional space. And here, I'm only showing a
55.96|4.2| two dimensional space. This is just because it's easier to draw
60.16|3.08| this in a two dimensional space, because I can't draw in a 200
63.24|3.12| dimensional space. So but the concept is the same, what we're
66.36|3.64| going to do is first, we are going to compute a smile vector.
70.24|3.6| So we are going to average the embeddings of all the people that
73.84|4.48| are smiling. We actually know who is smiling, because when I go
78.32|5.08| back to my notebook here, notebook two, we are I told you
83.4|5.0| that there are these 40 target vectors or attributes sorry, in
88.4|3.6| setup a so this is provided in this data set. And these are
92.0|5.64| these 40 binary vectors, and one of them is smiling. So we are
97.64|5.56| going to focus on all images where smiling is true. And then
103.2|4.02| we are going to average them. Oops, we're going to average
107.22|3.9| them in this latent space. And then we're going to do the same
111.12|3.9| thing with people who are not smiling. So people without a
115.02|4.86| smile, we are calling this the no smile vector. Then what we do
119.88|7.4| is we take this smile vector and subtract the no smile vector and
127.28|3.38| get this difference vector here in green. So this is a
130.66|5.82| difference vector pointing from no smile to smile. And then
136.48|4.9| given a face image, let's call that. So here's the embedding. So
141.38|2.88| let's say we have the embedding of a face image, let's call that
144.26|5.8| original face image. What we're going to do is to this embedding
150.06|3.08| of the original face image, we are going to add this difference
153.14|4.4| vector, multiplied by scaling factor here alpha, it's a hyper
157.54|3.1| parameter, it's kind of determining how much of the
160.64|4.46| smile vector we want to add. And then we obtain this new vector,
165.1|6.72| which is basically a person here that is smiling more if alpha is
172.42|8.56| number, let's say larger than zero. Okay. Um, yeah, so let's
180.98|3.6| do this and see how that works. So yeah, I have a code example
185.38|3.72| where we are working with the model from notebook to the
189.1|3.48| variation auto encoder trained on set up a some importing here
192.58|3.86| only three function this time, one is just a data loader, one
196.44|3.66| is for computing the average faces, and one is for plotting
200.1|5.34| these modified faces. So this is the same as before, just the
205.44|5.98| data loader. And here we are now also loading the labels. So the
211.42|2.76| labels are 40 dimensional vectors with these 40 time
214.46|7.2| binary attributes, these here. And here I have a function to
221.66|2.84| compute the average faces. So I'm starting here in this
224.5|3.0| notebook, there are two parts in this notebook. One is the image
227.54|2.52| manipulation in the original space, I just want to motivate
230.18|2.88| why we want to do the latent space arithmetic and why we
233.3|2.8| don't manipulate the original face images like in the original
236.1|3.18| space. Because yeah, in the original space, it doesn't work
239.28|3.82| quite so well. And I will show you an example. So here, this
243.1|3.78| function is computing the average face image with a given
246.88|3.66| feature and without a given feature. And this feature here
250.54|4.44| I'm choosing is smiling, because I'm using the feature index 31
255.16|5.18| 31. This is really like smiling here from this list. So let me
260.34|4.88| just show you how I computed this, how I implemented this
265.22|5.96| compute average faces function. So if we go to data here, should
271.18|4.6| have it somewhere here. Data loaders, compute average faces.
275.78|2.52| So what I'm doing here is I'm just initializing these two
278.3|9.04| zero, then I'm iterating over all the images. Later, I will do
287.34|2.2| the same thing with embedding. But for now, we don't do any
289.54|3.32| embedding, we just can ignore this part, we are just
292.86|10.02| averaging. So if encoding function is none, I just call
302.88|3.66| embeddings the images. So when you read here embeddings, this
306.54|3.28| is just the original images for now, because I don't, I don't
309.82|3.64| set encoding function to anything. So I don't have it
313.5|5.14| specified here. I have it to none. This is because later, we
318.64|3.24| can reuse the same function with the actual embeddings. But for
321.88|3.06| now, we are not using embeddings. So what I'm doing
324.94|6.36| here is now I'm averaging. So I'm averaging the ones with the
331.3|8.04| feature. So there is something called index image with feature
339.46|4.12| feature feed means feature. And this is corresponding to all the
343.58|5.6| images in the batch that have that feature. So that's how I
349.18|4.32| find it out. So it's maybe a little bit complicated to wrap
353.5|3.28| your head around this, like, best just by looking at it might
356.78|3.4| be interesting, or might help to play around with that. But like
360.18|3.92| I mentioned before, the label vector here is, is actually a
364.1|3.4| matrix, it's a 256 times 40 dimensional matrix. So for each
367.5|5.56| image, we have a vector of 40 binary attributes. And then this
373.06|4.96| one here, so what I'm doing is I'm selecting all images, and
378.02|4.88| then I only get the position of my feature index, and I set the
382.9|6.8| feature index to 31 to smiling. And this is either zero or one.
390.02|5.56| So zero means no smiling, and one means smiling. And then I'm
395.58|2.84| converting it to a bool, a boolean vector, which is either
398.42|4.88| true and false or true or false. And this will be then essentially
405.18|6.32| index of true and false a mask, and then I'm selecting. So this
411.5|4.64| will be giving me an indicator, which images are smiling and
416.14|2.16| which are not smiling, it will be affected, like true, false,
418.3|3.52| false, false, true, false, false, true. And here, now I'm
421.82|5.34| selecting from my images from the batch, which one are
427.18|3.24| smiling. And this one means here, this wiggly thing, the
430.42|4.04| tilde means not smiling. So I'm selecting smiling. And here I'm
434.46|3.8| selecting not smiling. So I'm just adding up some summing them
438.26|4.2| over the batch, and then add that to my average image with
442.46|3.0| feature. So these are the smiling. And these are the not
445.46|4.12| smiling ones, I'm just adding them up. And then I'm also
449.7|3.44| counting the number of images with feature and counting the
453.14|4.32| number without feature. So the number of smiling and the number
457.82|3.72| not smiling. So and this for loop goes through the whole epoch.
461.74|3.32| In the end, when this whole thing is completed, I have the
465.06|5.92| sum of all smiling ones, and all not smiling images. And then I
471.02|2.8| divide by the number respectively, and this gives me
473.82|4.52| the average. And then I'm returning these averages. Okay,
478.66|4.16| so let's take a look at how the results look like. So this is
484.62|5.56| the average image of all people smiling. So it looks like so the
490.18|6.24| average smiling. And this is the average not smiling. You can see
496.42|2.56| there's a difference, right? So this small smiling, this is not
498.98|5.72| smiling at all. So given a face image, can we manipulate this
504.7|6.72| face image that this person is no more smiling, or smiling
511.42|6.24| more. So smilingness. So I'm computing the difference vector
517.66|9.64| here, here, it's more like a difference matrix. And then I'm
527.9|3.52| in the top row, I'm adding smiling. And at the bottom row,
531.58|2.72| I'm removing smiling for the top row actually looks pretty good.
534.3|3.28| So we can actually make this person smile more for the bottom
537.58|4.04| it doesn't work quite so well. So this is done in the original
541.62|3.88| space. So we can actually just by adding this average face, we
545.5|3.04| can make this person smile more, it works actually quite
548.62|3.6| surprisingly well, you will find though, it won't work with all
552.22|3.28| the different attributes you can play around. I mean, instead of
555.5|5.84| using smiling here, you can play around and use any of these
561.34|2.8| here, right. So we'll find for some it will work better or not.
564.3|2.88| So we could technically do this in the original space, like I'm
567.18|2.72| showing you here. But yeah, now we are doing the same thing in
569.9|3.52| the latent space. Usually, if you have a good high resolution
573.42|3.36| solution model that can produce good reconstructions, you will
576.78|4.56| find the latent space, you can do way more fun things. So this
581.34|2.76| is again, my auto encoder, I'm not training it here, I'm just
584.1|2.6| loading it like before, I'm loading it from my second
586.7|4.96| notebook. And now I'm doing this computing the face are the
591.7|4.72| averages of the smiling and not smiling, using my latent
596.42|3.16| dimension. And I'm using here this encoding function. So if
599.58|5.8| encoding is set to a function, it's, yeah, it's encoding my
605.38|3.8| images. So I'm using now the actual embeddings. So recall
609.18|3.84| from before, this is my auto encoder here. So from before we
613.02|3.32| have this encoding function, which is calling encoder, then
616.34|9.64| doing the repertorization and so forth. So we have encoding. And
625.98|2.8| then what I'm doing is I'm computing the difference vector
628.78|5.56| again, between with and without feature. And now I'm plotting.
634.78|3.28| And you can see, of course, the reconstruction is not so great.
638.3|3.04| But yeah, we can actually make the person smile more. So alpha
641.34|3.08| is how much of the smiling vector I'm adding. So you can
644.42|4.2| see person smiling more and more and more. And also for this
649.06|4.36| reference here, now I'm soup as the bottom is subtracting the
653.46|3.2| difference vector, and you can see, person will smile less. So
656.66|4.04| that's how much I subtract above this addition. And at the bottom
660.7|3.68| is subtraction. You can see that we can make a person smile more
664.38|4.24| and less by manipulating things in the latent space. Now I also
668.62|4.08| have that here with and without glasses. It's also fun. So you
672.7|3.48| can see, can give the person glasses and here I can remove
676.18|2.88| glasses, since the person doesn't have any glasses to
679.06|2.4| begin with doesn't really work. But you can see actually,
681.46|3.32| that's doing something here. But yeah, it's quite fun. So we can
684.78|3.0| give the person here glasses. Awesome. And you can also do
687.78|3.04| this with hair color and other things. Okay, so this was I
690.82|4.92| hope, kind of little fun code example. And this is the lecture
695.74|3.4| on variational auto encoders went longer than I expected
699.14|3.32| initially, but hopefully not too long. And in the next lecture,
702.46|4.72| we will talk about alternative latent variable models, the so
707.18|4.84| called generative adversarial network. Alright, so that's it
712.02|3.48| then for today.