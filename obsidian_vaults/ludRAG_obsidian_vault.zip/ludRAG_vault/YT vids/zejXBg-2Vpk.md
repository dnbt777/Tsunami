start_time|end_time|text
5.04|3.76|thanks so much great to be here and
6.879|3.84|happy halloween belated halloween
8.8|3.839|everyone um
10.719|4.721|so i think the talk is going to be split
12.639|4.961|into two sections so i'll start by
15.44|4.72|spending like 10 minutes 15 minutes
17.6|4.48|chatting about transformers in general
20.16|3.76|um but i'm assuming most of you are
22.08|4.88|familiar with them and we can move on to
23.92|4.8|mpts which yannick and neil will be
26.96|4.319|presenting
28.72|4.08|so let's see
31.279|3.44|i'm gonna like
32.8|5.12|try to fly through
34.719|4.401|the transformer overview and maybe spend
37.92|2.959|a little bit
39.12|3.2|extra time on like the history of
40.879|4.081|transformers and maybe just tell the
42.32|5.44|story a little bit i think that might be
44.96|4.72|more interesting
47.76|3.76|so just in terms of the transformer
49.68|3.519|architecture
51.52|3.44|the two kind of things that it
53.199|4.801|introduced for the first time were
54.96|5.119|multi-head attention and self-attention
58.0|4.0|and then it combined those with fast
60.079|3.201|utter aggressive decoding so before the
62.0|4.4|transformer
63.28|5.28|pretty much everyone was using lstms um
66.4|3.12|and lcms with attention
68.56|2.96|um
69.52|5.76|i'll try to get into the difference of
71.52|3.76|self-attention multi-head attention
75.84|6.08|so originally you would have two
78.479|5.28|sequences and you would have a attention
81.92|3.839|module which would attend from the
83.759|4.641|source to the target
85.759|4.4|and so each token or each word in the
88.4|4.16|source sequence would get associated
90.159|5.761|with you know a soft approximation of
92.56|4.559|one element in the target sequence
95.92|2.8|um
97.119|4.481|and so you'd end up with something like
98.72|4.96|like this but with self-attention we did
101.6|4.24|away with the two separate sequences we
103.68|4.32|make them both the same
105.84|4.48|and so you're relating each element
108.0|3.759|within the sequence to another element
110.32|2.479|in the sequence
111.759|3.68|um
112.799|4.161|and so the uh
115.439|3.761|the idea here is that you're you're
116.96|4.08|learning a relationship of the words
119.2|3.76|within a sentence to the other words so
121.04|4.0|you can imagine something like
122.96|3.92|uh an adjective which is being applied
125.04|4.16|to a noun and so you want to relate that
126.88|5.84|adjective like the blue ball you want to
129.2|5.52|relate blue as referring to ball
132.72|5.76|so we're learning patterns within the
134.72|3.76|sequence interest sequence patterns
139.28|7.2|so sorry i gave this talk in kenya so
142.64|5.76|i'm using kiswahili here uh but
146.48|4.479|with multi-head attention the idea is
148.4|4.24|you have like each word represented by
150.959|3.201|an embedding which is in the depth
152.64|3.28|dimension here and then you have your
154.16|3.84|sentence of words
155.92|3.52|you split that up into a bunch of
158.0|3.28|different groups
159.44|3.439|so here i've chopped it depth wise into
161.28|4.48|four groups
162.879|4.561|you apply attention to each one of these
165.76|3.92|groups independently
167.44|4.0|and then when you get the result back
169.68|2.88|you concatenate them together and you're
171.44|3.519|back to your
172.56|4.0|uh you know model dimension
174.959|2.961|representation
176.56|3.36|so
177.92|3.679|what this lets you do is if each
179.92|4.48|attention has like each attention head
181.599|5.201|can now focus on learning one pattern
184.4|5.36|so maybe attention head one is learning
186.8|5.28|uh the relationship of adjectives to
189.76|4.8|nouns uh and the second attention head
192.08|3.519|can learn something different uh so this
194.56|4.16|lets us
195.599|5.121|learn like a hierarchy or a or a list of
198.72|4.159|different relationships
200.72|3.68|okay so that was self-attention
202.879|4.321|the uh
204.4|4.08|the other piece is fast auto repressive
207.2|3.2|decoding
208.48|4.96|um
210.4|5.28|and do i really want to go into this
213.44|5.2|okay i will so the the important thing
215.68|4.4|about this is that um
218.64|3.04|if you're doing normal auto aggressive
220.08|3.519|decoding what you do is you generate
221.68|3.919|your first token and now conditioned on
223.599|3.28|that first token you generate the second
225.599|2.72|and condition on the first two you
226.879|3.601|generate the third and so on and so
228.319|4.241|forth that's super slow right like it's
230.48|3.28|a loop applying this thing again and
232.56|3.12|again
233.76|4.24|and so what we can do instead
235.68|4.479|is we make an assumption
238.0|4.159|in the code that our model always
240.159|4.401|generates the right thing
242.159|3.601|um and we generate and then we generate
244.56|2.239|a prediction
245.76|3.52|uh
246.799|4.881|only one token ahead and so the way that
249.28|5.44|this looks is
251.68|4.48|you uh okay so
254.72|3.039|y
256.16|3.599|y hat here
257.759|3.44|um
259.759|2.961|sorry once again
261.199|3.601|input output so you have your like your
262.72|3.84|outputs which are y uh you have your
264.8|4.399|targets which are
266.56|4.56|y hat
269.199|4.401|and what you do is you feed in those
271.12|5.12|gold targets so that you don't need to
273.6|4.319|actually do this loop so instead of
276.24|3.679|assuming instead of having to generate
277.919|4.56|the first token feed it back into your
279.919|5.761|architecture generate a second token you
282.479|4.881|feed in the entire target sequence
285.68|4.56|and you just pretend that you generated
287.36|5.279|all the right tokens up to position k
290.24|5.28|and then you predict the k plus first
292.639|4.241|and you compute your loss on that
295.52|3.04|so in reality your model might have
296.88|2.72|generated you know at the beginning of
298.56|3.6|training
299.6|4.48|junk but you're getting a loss as if
302.16|4.72|your model had seen all the correct
304.08|6.0|tokens and is now just predicting the
306.88|5.2|next one this is a little bit subtle
310.08|2.88|but it's hugely impactful for training
312.08|2.64|speed
312.96|3.44|because all this can be done on parallel
314.72|2.479|in parallel and so it's actually what
316.4|4.56|makes
317.199|3.761|transformers so scalable
321.919|5.361|okay so in order to do this successfully
324.08|5.119|if you were just feeding in all of the
327.28|4.4|all the correct tokens
329.199|5.121|uh naively what would happen is your
331.68|5.12|model would just be able to
334.32|5.52|look forward in time
336.8|4.64|and cheat so you've put in all of your
339.84|3.52|true targets the things that you're
341.44|3.599|trying to get your model to predict
343.36|3.36|and so if that's what you're computing
345.039|3.6|your loss on you could just look forward
346.72|3.759|in time and say okay i'm just going to
348.639|3.84|grab that and we'd get zero error
350.479|4.081|trivially right because you've given it
352.479|4.0|all the right answers so what we have to
354.56|4.0|do inside the architecture is we need to
356.479|4.16|actually prevent
358.56|4.32|the attention mechanism from being able
360.639|5.041|to look at tokens that it shouldn't have
362.88|5.2|been able to see already
365.68|3.359|so the way that this looks is
368.08|4.8|you
369.039|3.841|create a mask on your attention
372.96|2.72|and
373.84|4.4|so sorry this is the example of like
375.68|5.44|doing a trivial attention if you don't
378.24|4.399|mask your attention properly
381.12|4.24|what it's going to do is it's just going
382.639|4.961|to look into the future just grab the
385.36|4.0|token that you're telling it to predict
387.6|2.96|and copy it over and so learn something
389.36|3.839|trivial something that doesn't actually
390.56|4.4|generalize and so what we do is we
393.199|3.12|actually prevent it from attending to
394.96|3.519|those tokens we prevent it from
396.319|5.121|attending into the future
398.479|5.521|for each position in the source sequence
401.44|4.16|we block out
404.0|3.6|everything that it shouldn't be able to
405.6|4.08|see everything into the future and then
407.6|4.879|as we move down we gradually unblock so
409.68|4.239|we can start to see into the past
412.479|3.201|um
413.919|4.0|so those are kind of like the two
415.68|5.04|the three major components of
417.919|2.801|transformers
420.84|4.44|the self-attention
423.199|4.321|the multi-head attention and then
425.28|4.88|deploying this gold targets decoding
427.52|4.56|this fast auto aggressive decoding
430.16|3.92|um
432.08|4.399|in terms of the story which might be a
434.08|4.32|little bit more interesting
436.479|4.72|um
438.4|5.199|so transformers i was an intern
441.199|4.881|with lukash kaiser at google back in
443.599|4.561|2017
446.08|4.16|and i was sitting next to gnome
448.16|3.039|and ashish was like a couple seats down
450.24|2.72|from us
451.199|4.321|um
452.96|4.079|and what's really incredible is that
455.52|3.6|essentially this entire project came
457.039|3.361|together in like three months
459.12|3.28|and it was done
460.4|4.56|so i showed up at google
462.4|5.28|uh noam had been working on
464.96|4.959|auto aggressive models um same thing
467.68|4.0|with like ashish and yakov and and nikki
469.919|3.28|and um
471.68|3.6|they'd just been kind of like exploring
473.199|4.321|the space figuring it out
475.28|3.44|uh and lukasz and i at the same time we
477.52|4.239|had been working on this framework
478.72|5.919|called tensor to tensor
481.759|4.88|which was like explicitly made for
484.639|4.161|multimodal learning auto aggressive
486.639|3.201|learning um
488.8|4.88|and
489.84|5.199|lukash is kind of like a master of
493.68|3.76|keeping track of everything that's
495.039|4.641|happening in the field and adopting it
497.44|5.12|and so within tensor to tensor
499.68|2.88|there were like these
502.879|3.6|there were like these kind of emerging
504.8|3.04|little things that maybe one paper had
506.479|3.201|been written about
507.84|2.799|and people were interested in like layer
509.68|3.44|norm
510.639|4.241|but it hadn't actually taken off yet
513.12|4.159|the warm-up in the learning rate
514.88|4.399|schedule
517.279|3.12|all of these little pieces were just
519.279|2.88|default
520.399|2.801|like on by default
522.159|3.841|um
523.2|4.079|and so when noam and dashish and nikki
526.0|4.48|and jacob
527.279|4.481|came over and adopted tensor to tensor
530.48|5.44|all of these things were just on by
531.76|5.92|default um and so a lot of people
535.92|3.28|when they look at the the transformer
537.68|3.04|paper it just seems like there's so many
539.2|3.04|like arbitrary
540.72|4.0|little things thrown in
542.24|3.92|and when now like in in present day
544.72|2.559|these have become standard for like a
546.16|2.799|lot of different
547.279|2.881|training algorithms like the learning
548.959|2.32|rate warm-up
550.16|3.44|um
551.279|4.321|the way that we did initialization
553.6|3.52|uh all of these pieces have just
555.6|3.6|become the norm but back then they had
557.12|3.839|like kind of just been introduced
559.2|3.36|um
560.959|2.721|and so
562.56|2.88|we uh
563.68|3.12|we spent a lot of time running ablations
565.44|3.68|trying to figure out like which were the
566.8|4.32|necessary pieces and what made it work
569.12|4.159|and if any of you have actually
571.12|4.159|tried training transformers and tried
573.279|3.521|like pulling out the learning rate warm
575.279|3.201|up um
576.8|3.84|or changing out of any of these little
578.48|4.32|pieces you'll see that it really does
580.64|3.36|break down optimization like it actually
582.8|4.0|really does
584.0|4.24|um hurt performance for instance like
586.8|4.0|removing the layer norms that type of
588.24|4.4|thing um
590.8|3.84|so i i always thought it was kind of
592.64|4.4|funny how
594.64|3.68|all of these random editions that lucas
597.04|3.04|had just like thrown in because he was
598.32|4.72|playing around with them turned out to
600.08|5.52|be crucial uh and they were just on by
603.04|4.72|default um
605.6|3.44|so anyway it was like three months i
607.76|3.199|remember
609.04|3.68|um
610.959|3.681|it all really started coming together
612.72|3.359|towards the end like just before the
614.64|3.199|nureps deadline
616.079|2.961|um
617.839|3.281|and i can still remember sitting in the
619.04|3.68|micro kitchen and a sheesh telling me
621.12|4.08|like i was just like i was a little
622.72|4.08|intern uh telling me like this is gonna
625.2|3.04|be such a big deal and i was like yeah
626.8|3.52|sure okay
628.24|4.8|i have no idea what's happening i i just
630.32|4.48|showed up um
633.04|3.84|and he was like no dude like this this
634.8|4.96|actually matters like you know we bumped
636.88|5.12|up blue three points and i was like sick
639.76|4.56|great anyway
642.0|4.32|um
644.32|4.88|and then i can remember on the night of
646.32|7.36|the deadline for nurips
649.2|6.16|it was like 2 am uh ashish
653.68|3.839|sheesh was the only one left at the
655.36|4.64|office and we were still like moving
657.519|5.201|around figures and like adjusting things
660.0|4.72|and then um i went to bed but she stayed
662.72|3.2|up and i slept in like this tiny little
664.72|2.88|phone booth
665.92|3.2|um
667.6|4.08|and then for the other paper that i was
669.12|3.839|submitting i forgot to press submit but
671.68|3.44|luckily
672.959|3.841|like some lady opened the door to the
675.12|3.6|phone booth and hit me in the head while
676.8|4.159|i was sleeping in the morning
678.72|4.08|and just before the deadline i got the
680.959|4.56|paper in and so
682.8|5.039|i owe it to that to that lady
685.519|4.401|uh for for submitting to nerves that
687.839|3.601|year but yeah anyway the i think the
689.92|2.96|crazy thing about transformers was that
691.44|3.36|it all came together in like three
692.88|3.92|months like most of the ideas happened
694.8|4.56|in that span and it was just like this
696.8|3.68|sprint towards the nerves deadline
699.36|2.56|um
700.48|3.84|i think a lot of the other members on
701.92|3.919|the team yaakov
704.32|3.12|they knew how important it was but for
705.839|4.0|me i was like
707.44|3.519|i don't know i i really did not
709.839|4.081|appreciate
710.959|4.56|uh the impact um
713.92|3.12|but in retrospect it's been amazing how
715.519|3.521|the community has kind of like come
717.04|3.76|together and adopted it
719.04|4.32|um
720.8|4.8|and i think most of that can be ascribed
723.36|4.719|to the ease of optimization it seems
725.6|4.479|like very robust to hyper parameter
728.079|3.681|choices so you don't need to like tune
730.079|3.841|the hell out of it spend a lot of time
731.76|3.759|tweaking little things
733.92|3.599|and the other side is it's like super
735.519|2.721|tailored to the accelerators that we run
737.519|2.081|on
738.24|4.48|um
739.6|6.32|so it's like very paralyzable
742.72|5.119|hyper efficient um and so it lends
745.92|4.32|itself to that kind of scaling law
747.839|4.321|effort that's that's really taken off in
750.24|5.76|in popularity
752.16|3.84|okay uh unless there are any
757.36|0.0|oh my questions
759.839|4.24|we're both excited so we just unmute it
761.839|4.641|at the same time
764.079|2.401|so cool
766.639|2.801|yeah so that's that's my section if
768.16|2.88|there's any questions happy to answer
769.44|4.24|them otherwise
771.04|5.28|uh let's get into npt's mpts are like i
773.68|4.88|think um
776.32|4.4|there's such a nice next level
778.56|4.959|abstraction of the architecture so
780.72|4.64|you've probably seen the trend of
783.519|2.961|transformers getting applied to new
785.36|2.159|domains
786.48|4.64|um
787.519|5.201|first into vision and video and audio
791.12|3.2|um
792.72|3.919|but this is kind of like cutting back to
794.32|3.28|an even more abstract
796.639|3.841|level
797.6|3.919|um like i think tabular data yeah i
800.48|3.84|don't know i'll let yannick and neal
801.519|7.041|take over from here but uh i think mpt
804.32|6.4|is a pretty sick pretty sick project
808.56|4.56|thanks aidan for the introduction um
810.72|4.72|thanks all for the invitation we're very
813.12|4.399|happy to be here and
815.44|4.0|neil and i are now going to tell you
817.519|3.841|about our
819.44|3.759|self-attention between data points paper
821.36|5.039|where we introduce introduce the
823.199|4.401|non-prometric transformer architecture
826.399|3.281|we'll start with a little bit of
827.6|3.919|motivation move on to explaining the
829.68|3.839|architecture in detail and show you the
831.519|3.921|experiments this is more or less a step
833.519|3.921|through of the paper but maybe you know
835.44|4.32|with a little bit of extra insight here
837.44|2.32|and there
841.6|3.359|all right as promised motivation and a
843.199|3.041|brief summary
844.959|3.041|so
846.24|3.92|we'll start by thinking about something
848.0|5.199|that we don't often think about and that
850.16|5.119|is that from cnns to transformers most
853.199|4.161|of supervised deep learning relies on
855.279|4.321|parametric prediction
857.36|4.88|so what that means is that we have some
859.6|5.039|self-training data and we want to learn
862.24|5.039|to predict the outcomes y from the
864.639|4.961|inputs x for this we set up some model
867.279|4.8|with tunable parameters theta
869.6|4.4|then we optimize these parameters to
872.079|4.641|maximize predictive likelihoods on a
874.0|5.04|training set or you know equivalently we
876.72|4.4|minimize some loss
879.04|4.64|and then after training we have this
881.12|4.8|optimized set of parameter theta and
883.68|4.24|then at test time we just put these into
885.92|4.4|the model and use these parameters to
887.92|4.88|predict on novel test data
890.32|4.48|and so crucially here our prediction at
892.8|4.039|test time only depends on these
894.8|4.64|parameters right it's it's
896.839|4.12|parametric also that means that given
899.44|3.68|these parameters the prediction is
900.959|3.361|entirely independent of the training
903.12|2.24|data
904.32|3.04|and so
905.36|3.36|why would we want to do parametric
907.36|3.2|prediction
908.72|3.119|well it's really convenient because all
910.56|4.0|that we've learned from the training
911.839|4.961|data can be summarized in the parameters
914.56|3.76|and so prediction time we only need
916.8|2.96|these final parameters and we do not
918.32|3.519|need to store the training data which
919.76|4.879|might be really really large
921.839|4.961|on the other hand we usually have models
924.639|4.481|that already predict for a bunch of data
926.8|3.92|in parallel right think of mini batching
929.12|3.68|and modern architectures
930.72|5.119|and actually things like batch norm
932.8|5.36|already make these data interact
935.839|3.761|and so our thinking here was that if
938.16|3.599|we've got all of this data in
939.6|4.479|paralleling ways there's no reason not
941.759|5.2|to make use of it and so
944.079|5.2|more a bit grounder we kind of challenge
946.959|5.041|parametric prediction as the dominant
949.279|4.48|paradigm in deep learning and so we want
952.0|3.12|to give models the additional
953.759|4.08|flexibility
955.12|4.48|of using the training data directly when
957.839|3.841|making predictions
959.6|3.84|and so a bit more concretely
961.68|4.32|we introduced the non-parametric
963.44|4.48|transformer architecture and this is
966.0|3.12|going to be a general deep learning
967.92|3.12|architecture
969.12|3.519|meaning we can apply it to a variety of
971.04|4.159|scenarios
972.639|4.88|npt's will take the entire data set as
975.199|5.44|input whenever possible
977.519|6.32|and npts then crucially learn to predict
980.639|5.44|from interactions between data points
983.839|3.68|and to achieve this we use multi-head
986.079|4.481|self-retention
987.519|5.281|that as agent has introduced us to
990.56|4.279|has just really established itself as a
992.8|4.88|general purpose layer for
994.839|5.8|reasoning we also take another thing
997.68|5.279|from the the nlp community and we use a
1000.639|4.161|stochastic masking mechanism
1002.959|4.401|and we use that to tell npts where to
1004.8|4.159|predict and also to regularize the
1007.36|3.599|learning task a bit
1008.959|3.361|and lastly of course we hope to convince
1010.959|3.841|you that this ends up working really
1012.32|5.199|really well and that this kind of simple
1014.8|4.8|idea of learning to predict from the
1017.519|4.081|other data points of the input from the
1019.6|5.199|training points of the input and stop
1021.6|5.839|working rather
1024.799|4.561|sorry and so very briefly summarizing
1027.439|2.801|what we've heard already
1029.36|4.079|a
1030.24|5.679|we input into nptc tie data set
1033.439|4.801|and then b let's say for the purpose of
1035.919|4.481|this slide here we only care about
1038.24|3.839|predicting the orange question mark in
1040.4|4.08|that green row
1042.079|4.561|and then we can compare npt's to
1044.48|3.92|parametric prediction right so a
1046.64|4.08|classical deep learning model would
1048.4|4.96|predict this target value only from the
1050.72|4.079|features of that single green input to
1053.36|3.679|do that it would use the parameters
1054.799|3.921|theta those would depend on whatever
1057.039|4.481|training data we've seen and so on but
1058.72|4.4|at test time we only look at that single
1061.52|2.8|row for which we care about the
1063.12|4.08|prediction
1064.32|5.76|in contrast npts predict an explicit
1067.2|4.8|dependence on all samples in the input
1070.08|4.08|they can look beyond that single green
1072.0|4.0|datum of interest and look at all other
1074.16|4.16|songs that are there and consider their
1076.0|5.28|values for prediction so this presents
1078.32|5.599|an entirely different way of thinking
1081.28|4.56|about how we learn predictive mechanisms
1083.919|3.841|and somebody on twitter called this k n
1085.84|3.28|2.0 which
1087.76|3.2|we would have not written in the paper
1089.12|3.919|but maybe is kind of a nice way of
1090.96|4.56|thinking about how mpgs can learn to
1093.039|5.041|predict
1095.52|4.32|so of course non-parametric models are a
1098.08|3.44|thing already we didn't invent them at
1099.84|4.0|all and
1101.52|4.88|i defined them here as prediction in
1103.84|4.719|explicit dependence on the training data
1106.4|3.84|which is certainly what mpgs do
1108.559|3.681|classical examples like gaussian
1110.24|5.04|processes k-nearest neighbor kernel
1112.24|5.28|methods those might be familiar to you
1115.28|4.24|and there exists also efforts to combine
1117.52|3.84|the benefits of non-prometrics and
1119.52|3.84|representation learning
1121.36|3.36|in a similar fashion to how we did it in
1123.36|2.96|entities
1124.72|3.36|however um
1126.32|3.359|these approaches are usually limited in
1128.08|2.959|some sense in comparison temperatures
1129.679|3.12|right they're often
1131.039|3.52|kind of motivated from the statistics
1132.799|3.521|community a bit more they often require
1134.559|3.761|some finicky approximate inference
1136.32|4.0|schemes are limited in the interactions
1138.32|3.12|they can learn or things like that and
1140.32|4.0|so
1141.44|4.88|we really think mpts present
1144.32|4.239|maybe the most versatile and most widely
1146.32|3.76|applicable of these non-prometric
1148.559|3.36|prediction approaches but that's
1150.08|2.959|something we explicitly wanted to have
1151.919|3.281|we wanted to have something that's
1153.039|4.481|really easy to use plug and play works
1155.2|4.64|in a ton of scenarios and uh works
1157.52|4.48|really well
1159.84|4.48|and so with that uh i'd hand over to
1162.0|4.64|neil who's going to tell you about the
1164.32|4.4|non-parametric transformer architecture
1166.64|5.039|in all of its details
1168.72|4.0|yeah you also have one question
1171.679|3.441|go ahead
1172.72|5.44|yes yes
1175.12|5.36|uh hi so could you please go back to the
1178.16|4.639|previous slide
1180.48|4.079|the very previous slide yeah yes this
1182.799|4.481|slide yeah so
1184.559|5.041|in terms of the problem definition i
1187.28|5.04|think it's quite similar to some might
1189.6|5.68|learning problem which basically there's
1192.32|5.2|a mapping from a data point on the data
1195.28|4.399|set to some predictions
1197.52|4.08|so could you please suggest any
1199.679|4.961|differences between
1201.6|6.0|your problem setting and math learning
1204.64|5.36|problem settings i can't really
1207.6|4.24|figure out any differences between these
1210.0|2.799|two problems
1211.84|3.839|well
1212.799|5.281|i i think it really depends on the the
1215.679|4.641|framing that you want to have right so i
1218.08|4.8|would say meta learning would be when i
1220.32|4.88|try to predict over multiple data sets
1222.88|4.24|so when i try to predict some when i try
1225.2|3.839|to learn some sort of prediction model
1227.12|4.24|or i can just plug in a different data
1229.039|4.241|set and it will automatically or almost
1231.36|3.92|automatically give me new predictions on
1233.28|3.519|this different data distribution
1235.28|3.519|but that's not what we do at all right
1236.799|3.441|we're training a single model for a
1238.799|3.201|fixed data set
1240.24|3.04|and so this is why i wouldn't really
1242.0|2.24|call that meta learning because we're
1243.28|3.04|doing
1244.24|5.2|we're trying to print on the same tasks
1246.32|5.52|that all the supervised deep learning or
1249.44|6.32|any supervised machine learning method
1251.84|3.92|is trying to predict well on
1256.559|4.801|consuming you use kind of same test site
1260.4|4.56|to
1261.36|3.6|test your trainer model right
1265.36|4.559|i mean
1266.799|3.12|i mean like uh
1271.52|4.159|so
1273.44|4.88|so so basically in my learning we're
1275.679|4.721|gonna test on different kind of meta
1278.32|3.04|test sets but in your case you just
1280.4|4.639|wanna
1281.36|5.52|use a test set which is similar to the
1285.039|4.481|distribution
1286.88|4.88|yeah sorry of your training set right
1289.52|4.159|yeah absolutely so we explore data set
1291.76|4.399|distribution shift a bit i think it's a
1293.679|5.281|really interesting scenario i think meta
1296.159|4.241|learning uh different data sets is also
1298.96|2.8|an interesting scenario right when you
1300.4|3.759|have this model where you could just
1301.76|5.2|push in different datasets but for the
1304.159|4.721|scope of this paper it's very much
1306.96|4.8|training set test sets they come from
1308.88|5.6|the same distribution and we're just um
1311.76|4.48|trying to do supervised learning in a
1314.48|3.28|standard setting
1316.24|4.319|cool thank you
1317.76|2.799|thank you for the question
1320.799|4.721|yeah and i would chime in um a couple
1323.2|3.68|additional things i guess um so at least
1325.52|2.8|from what i understand from the problem
1326.88|3.919|definition of metal learning i think the
1328.32|4.64|aim is more
1330.799|3.921|perhaps being able to perform well on a
1332.96|3.36|new data set with a relatively small
1334.72|4.319|number of additional gradient steps on
1336.32|4.08|that data set um so i think there's some
1339.039|3.601|interesting ways that you could actually
1340.4|4.159|consider applying npts in a metal
1342.64|3.519|learning type setting um and so we'll
1344.559|2.721|get into this a little bit more but for
1346.159|2.64|example
1347.28|4.24|you know there might be ways to
1348.799|4.081|essentially add in a new data set um so
1351.52|2.8|let's suppose we've trained on a bunch
1352.88|4.72|of different data sets we now add in a
1354.32|4.719|new data set uh we can perhaps do some
1357.6|4.24|sorts of kind of
1359.039|4.401|zero zero shot um meta learning
1361.84|2.88|basically where there's no need for
1363.44|3.119|additional gradient steps because we're
1364.72|4.319|basically predicting kind of similar to
1366.559|4.961|how you might do prompting nowadays in
1369.039|4.241|nlp literature um
1371.52|4.32|anyways yeah i think we'll get into some
1373.28|2.56|more details
1377.2|4.88|uh just don't chime in on that
1379.6|3.76|uh i don't think that every metal
1382.08|2.88|learning
1383.36|4.0|algorithm i think the ones that you
1384.96|4.24|describe right now are like optimization
1387.36|3.92|based but they're also black box ones
1389.2|3.92|like you don't need to
1391.28|4.24|further i think the main difference
1393.12|6.08|seems to be that there is like one task
1395.52|5.6|versus multiple tasks for metal learning
1399.2|3.76|yeah i think i think so too i think that
1401.12|2.96|the like main yeah the frame the main
1402.96|4.24|framing question is whether or not
1404.08|3.12|there's multiple data sets
1409.52|3.279|cool
1410.72|4.079|okay awesome if there's no other
1412.799|5.0|questions i'll dive a bit more into the
1414.799|3.0|architecture
1419.12|4.24|awesome
1420.08|4.88|so there's three key components to npts
1423.36|2.88|i'm going to first state them at a high
1424.96|3.52|level and then we'll go through each of
1426.24|4.4|them in more detail
1428.48|5.04|so first of all we take the entire data
1430.64|4.72|set all data points as input um so for
1433.52|4.24|example at test time the model is going
1435.36|3.36|to take as input both training and test
1437.76|2.0|data
1438.72|2.72|and we
1439.76|4.0|approximate this with mini batches for
1441.44|4.32|large data
1443.76|4.399|we apply self-attention between data
1445.76|4.08|points so for example at test time
1448.159|4.161|uh we model relationships amongst
1449.84|4.88|training points amongst test points and
1452.32|4.56|between the two sets
1454.72|4.0|and then finally um we have this masking
1456.88|3.84|based training objective uh it's a
1458.72|4.24|birth-like stochastic masking and the
1460.72|4.16|key point is that we actually use it on
1462.96|4.16|both features as well as on training
1464.88|3.44|targets and we'll get into why that um
1467.12|4.4|kind of leads to an interesting
1468.32|3.2|predictive mechanism later
1471.76|3.919|so to start with this idea of data sets
1474.48|2.559|as input
1475.679|4.081|there's two things that compose the
1477.039|5.12|input to npt um it's a full data set in
1479.76|4.0|the form of a matrix x and a masking
1482.159|3.12|matrix m
1483.76|3.44|and so yannick has described this
1485.279|4.161|dataset matrix a little bit uh we
1487.2|4.16|basically have data points as rows uh
1489.44|3.68|the columns are attributes and each
1491.36|4.72|attribute shares some kind of semantic
1493.12|4.559|meaning among all of its data points um
1496.08|2.88|so say for example you're just doing
1497.679|2.721|single target classification or
1498.96|3.599|regression
1500.4|3.84|the last column would be the target and
1502.559|3.6|the rest of the matrix would be input
1504.24|4.08|features so for example the pixels of an
1506.159|4.88|image
1508.32|3.599|we also have a masking matrix so let's
1511.039|1.841|say
1511.919|2.561|you know we're thinking about mass
1512.88|2.799|language modeling the mass tokens will
1514.48|3.199|just tell us where we're going to
1515.679|3.6|conceal words uh and where we're going
1517.679|3.6|to backpropagate a loss
1519.279|3.841|um we do a similar type of thing here
1521.279|4.721|where we use this binary mass matrix to
1523.12|3.76|specify which entries are masked
1526.0|3.919|and
1526.88|4.64|the goal is to predict mass values from
1529.919|4.161|observed values
1531.52|4.159|um i see that there was a question about
1534.08|3.68|uh handling inputs with different
1535.679|4.961|lengths um
1537.76|4.399|in in the data sets we've considered um
1540.64|3.279|we've we'll we'll get into it in the
1542.159|3.76|results section but it's mostly been
1543.919|3.841|sort of tabular and image data where the
1545.919|3.521|lengths for each of the data points is
1547.76|2.96|the same but it would work just like
1549.44|3.119|padding that would be a reasonable way
1550.72|3.36|to to go about that
1552.559|3.681|um and there's also kind of an
1554.08|3.839|interesting yep go for a unique
1556.24|2.88|just to add to that i'm not sure if
1557.919|3.601|length depends
1559.12|4.799|prefers uh refers to columns or to rows
1561.52|4.96|right rows we don't care about how many
1563.919|3.681|rows length padding or something would
1566.48|3.12|be an option
1567.6|4.079|yeah my question was about column
1569.6|4.319|exactly so that that makes sense lots of
1571.679|2.24|things
1574.0|2.559|yeah i mean that goes along with the
1575.279|3.52|whole meta learning discussion is i
1576.559|3.6|think if we wanted to adapt to data sets
1578.799|3.041|that have a different number of data
1580.159|2.961|data points per data set
1581.84|3.12|you know we can take advantage of the
1583.12|4.48|fact that self-attention is kind of uh
1584.96|2.64|okay with that
1588.24|2.24|cool
1590.559|3.12|um
1591.36|5.919|so continuing on
1593.679|5.681|uh left to discuss here is um basically
1597.279|3.681|how we do the embedding uh so to put
1599.36|3.919|this more explicitly we have this uh
1600.96|4.8|data matrix that has n data points uh
1603.279|3.921|it's called x and uh it also has d
1605.76|3.84|attributes and we have this binary mass
1607.2|4.0|matrix m uh we're going to stack them
1609.6|2.959|and then we're going to do a linear
1611.2|3.359|embedding
1612.559|3.841|so specifically we're doing
1614.559|3.441|the same linear embedding independently
1616.4|4.0|for each data point we're learning a
1618.0|4.4|different embedding for each attribute
1620.4|3.759|we have a positional encoding on the
1622.4|3.6|index of the attributes because we don't
1624.159|3.681|really care about say being equivalent
1626.0|2.96|over the columns if it's tabular data
1627.84|2.319|you of course want to treat all these
1628.96|2.24|kind of heterogeneous columns
1630.159|2.961|differently
1631.2|3.52|and then finally we have an encoding on
1633.12|4.4|the type of column so whether or not
1634.72|4.48|it's continuous or categorical
1637.52|3.519|and that ends up giving us this input
1639.2|6.32|data set representation
1641.039|4.481|that is dimensions n by d by e
1646.799|4.961|the second key component of npts is a
1649.039|4.081|tension between data points
1651.76|2.96|so to do that
1653.12|5.279|we first take this representation we
1654.72|5.04|have and flatten to an n by d times e
1658.399|2.801|representation
1659.76|3.76|so basically we're treating each of
1661.2|4.64|these d times e size rows as if it's a
1663.52|3.84|token representation
1665.84|3.12|we're actually going to just accomplish
1667.36|3.36|this operation using multi-head
1668.96|3.439|self-retention um you know we've
1670.72|2.559|reviewed this a lot but the nice thing
1672.399|2.16|is that
1673.279|3.041|we know from language modeling if we
1674.559|3.521|stack this multiple times we can model
1676.32|2.479|these higher order dependencies and here
1678.08|2.0|they're
1678.799|3.36|between data points and that's really
1680.08|4.24|the key draw of this architecture um
1682.159|3.601|there's been other kind of instances of
1684.32|3.04|people using attention versus for
1685.76|4.08|similar sorts of things so for example
1687.36|3.76|like attentive neural processes um a lot
1689.84|3.36|of times
1691.12|5.12|they've sort of used just a single layer
1693.2|4.24|as kind of a representational lookup and
1696.24|2.799|we believe that this actually ends up
1697.44|3.2|limiting expressivity and that by
1699.039|3.601|stacking this many times you can learn
1700.64|3.84|more complex uh relationships between
1702.64|4.8|the data points
1704.48|2.96|we also have some questions
1707.52|5.2|i also can go ahead first oh cool uh
1711.039|3.281|thanks i have a question about like how
1712.72|4.0|you guys do the embedding is there
1714.32|4.079|always like arteries like convolutional
1716.72|4.16|filters or
1718.399|4.721|like linear layers like what is the type
1720.88|4.56|of embedding that you guys use yeah so
1723.12|4.159|i'm attempting to go back to the slide i
1725.44|4.08|think it's not not very happy with me
1727.279|4.88|right now but um yeah so for
1729.52|5.519|for tabular data we did um just linear
1732.159|4.721|embeddings actually so we um
1735.039|3.76|you know we could get into like i guess
1736.88|3.2|details of futurization for categorical
1738.799|2.88|and continuous but it's literally like
1740.08|3.92|say for categorical you know you do a
1741.679|4.0|one-hot encoding and then you learn this
1744.0|4.399|embedding that is specific to that
1745.679|4.561|attribute um and then for numerical i
1748.399|4.64|believe it was just standard normalizing
1750.24|4.64|um for the image data we did end up
1753.039|5.36|using um
1754.88|5.2|a resnet18 encoder for c410 um however i
1758.399|4.081|think that i mean we'll discuss that a
1760.08|4.88|bit later in results but um
1762.48|4.319|that embedding is a bit arbitrary
1764.96|3.12|you can sort of do whatever the key part
1766.799|2.88|of the architecture is the attention
1768.08|3.199|between data points so it's
1769.679|3.201|in in terms of how you actually want to
1771.279|3.76|embed each attribute it's kind of up to
1772.88|2.159|you
1775.44|2.239|thanks
1779.12|6.559|i think uh you had a question
1781.679|4.0|uh same question asked victorious
1786.64|3.759|awesome
1788.48|3.6|cool um so
1790.399|4.0|uh here we have a tension between data
1792.08|4.64|points done uh so we can also do this
1794.399|5.76|attention between attributes
1796.72|5.839|so uh we reshape back to this n by d by
1800.159|4.24|e representation and then we can just
1802.559|2.881|apply self-attention independently to
1804.399|2.64|each row
1805.44|3.76|in other words to a single data point
1807.039|4.24|and the intuition for why we would kind
1809.2|3.44|of do this nested type idea where we
1811.279|2.721|switch between attention between data
1812.64|2.32|points and attention between attributes
1814.0|3.039|is just
1814.96|4.4|we're trying to learn better per data
1817.039|4.081|point representations for the between
1819.36|3.12|data point interactions
1821.12|3.36|this is literally just normal
1822.48|3.919|self-attention as you'd see in language
1824.48|5.76|modeling or image classification
1826.399|3.841|the attributes are the tokens here
1830.72|4.64|and finally we just rinse and repeat
1833.84|3.839|so what are we actually getting out of
1835.36|4.0|this um to summarize we're learning
1837.679|2.641|higher order relationships between data
1839.36|2.4|points
1840.32|3.2|we're learning transformations of
1841.76|4.72|individual data points
1843.52|5.44|and then importantly npt is equivariant
1846.48|3.679|to a permutation of the data points
1848.96|3.76|this basically just reflects the
1850.159|3.76|intuition that the learned relationships
1852.72|2.72|between the data points should not
1853.919|3.36|depend on the ordering in which you
1855.44|4.4|receive them or in which you observe
1857.279|2.561|your data set
1861.039|5.201|the third key component of npt's is a
1863.76|4.799|masking based training objective
1866.24|4.0|so recall that what we're trying to do
1868.559|4.081|is we're trying to predict missing
1870.24|4.319|entries from observed entries and those
1872.64|2.96|mass values can be both features or
1874.559|3.441|targets
1875.6|3.52|um so again the classic use say mass
1878.0|2.64|language modeling is to do
1879.12|3.84|self-supervised learning on a sequence
1880.64|5.039|of tokens uh which you could think of as
1882.96|4.559|just having features in our setting um
1885.679|4.081|ours is a bit different
1887.519|3.601|in that we do stochastic feature masking
1889.76|3.279|to mass feature values with a
1891.12|5.12|probability p sub future and then we
1893.039|6.321|also do this masking of training targets
1896.24|4.48|um with this probability p sub target
1899.36|2.88|so if we write out the training
1900.72|3.92|objective
1902.24|4.159|we are just taking a weighted sum
1904.64|3.84|of the negative log likelihood loss from
1906.399|3.76|targets as well as from features
1908.48|4.24|and of course at test time we're only
1910.159|4.88|going to mask and uh compute a loss over
1912.72|4.64|the targets of test points
1915.039|3.921|so um to break this down a bit further
1917.36|3.6|and point out some of the cool cool
1918.96|3.52|parts of it here um the thing that's
1920.96|3.68|highlighted right now on the far right
1922.48|4.559|is the the term uh relating to the
1924.64|4.639|features it's the feature masking
1927.039|5.041|basically we find that this has a nice
1929.279|4.481|regularizing effect um more or less the
1932.08|3.04|model can now predict anywhere it makes
1933.76|3.519|the task a bit harder and introduces
1935.12|3.84|some more supervision and we found in an
1937.279|3.76|ablation for the tabular data sets that
1938.96|3.839|it helped for eight of 10 of those
1941.039|4.081|um and then there's this other term
1942.799|4.801|which is kind of interesting it's
1945.12|4.159|the stochastic target masking and the
1947.6|3.04|idea is that
1949.279|2.721|you're actually going to have some
1950.64|3.36|training targets
1952.0|4.64|unmasked to the model
1954.0|4.88|at input at training time
1956.64|4.879|which means that the npt can learn to
1958.88|4.56|predict the masked targets of certain
1961.519|3.361|training data points using
1963.44|2.88|the targets of other training data
1964.88|2.56|points as well as all of the training
1966.32|2.56|features
1967.44|3.52|and so that means you don't actually
1968.88|4.0|need to memorize a mapping
1970.96|3.68|between training inputs and outputs in
1972.88|3.279|your parameters you can instead devote
1974.64|4.08|the representational capacity of the
1976.159|5.201|model to learn functions that use other
1978.72|4.4|training features and targets as input
1981.36|4.24|so this is kind of getting into the idea
1983.12|4.559|of this sort of like learn k n idea um
1985.6|3.919|you know obviously we can be learn more
1987.679|3.36|complex
1989.519|3.361|relational lookups and those sorts of
1991.039|3.041|things from this but you can imagine one
1992.88|2.639|such
1994.08|2.719|case being
1995.519|2.4|we have a bunch of test data points
1996.799|2.561|coming in
1997.919|4.24|we're going to look at their features
1999.36|4.72|and use that to assign them to clusters
2002.159|3.281|of training data points and then our
2004.08|3.439|prediction for those points is just
2005.44|3.68|going to be an interpolation of the
2007.519|3.121|training targets in that respective
2009.12|3.76|cluster that's like an example of
2010.64|5.039|something that this mechanism lets uh
2012.88|2.799|npts learn
2016.96|4.719|all right uh so if there's any questions
2019.679|3.6|uh we can take them now otherwise
2021.679|4.48|i'm happy to take them in the the
2023.279|2.88|discussion or something
2028.159|5.281|all right
2029.84|6.319|um so let's discuss yeah yeah go for it
2033.44|5.04|um curious when you're using the entire
2036.159|4.081|data set um
2038.48|5.039|that limit the type of data sets you can
2040.24|6.159|use because of the size
2043.519|4.721|yeah so in practice we do random mini
2046.399|3.601|batching um
2048.24|3.2|to as an approximation so the idea is
2050.0|3.52|just um you know if you have a
2051.44|4.08|reasonably large mini batch uh you're
2053.52|4.159|going to benefit a bit from still having
2055.52|3.76|kind of this this lookup ability because
2057.679|2.801|if your reasonable number of classes
2059.28|3.28|probably you're going to be able to
2060.48|4.639|learn some you know interesting mappings
2062.56|4.88|based on features and targets um amongst
2065.119|3.601|those classes we found in practice that
2067.44|3.04|uh you know and we'll get into this a
2068.72|4.119|little bit but um
2070.48|5.52|we do actually indeed learn
2072.839|5.401|um to use uh relationships between data
2076.0|3.839|points on prediction for data sets where
2078.24|3.52|we're doing mini batching
2079.839|3.601|um and we also didn't necessarily find
2081.76|3.68|that you need like a ludicrously large
2083.44|2.88|batch size for this to be a thing
2085.44|3.12|um
2086.32|3.92|but i do think it's just a this is an in
2088.56|4.319|general an important point and it's one
2090.24|4.0|that points us towards looking into say
2092.879|3.28|um you know sparse transformers
2094.24|4.16|literature for trying to expand to some
2096.159|4.641|larger uh data sets without having the
2098.4|5.28|mini-batching assumption
2100.8|5.52|great thank you uh if i can add a number
2103.68|5.04|to that um we can
2106.32|6.24|without mini batching accommodate data
2108.72|6.8|sets of around like 8 000 points or so
2112.56|5.039|so that that already accounts for
2115.52|4.319|a fair proportion i would say of the
2117.599|4.321|tabular data sets out there but we also
2119.839|4.081|do data sets with 11 million points
2121.92|3.919|where obviously we then resort to mini
2123.92|3.679|purchasing so it's very good to have
2125.839|3.441|like an idea of the size that we're
2127.599|3.921|talking about
2129.28|3.36|i'm curious on that uh i mean it's
2131.52|2.48|pretty exciting
2132.64|2.32|i feel like you don't normally hear
2134.0|2.48|about
2134.96|3.28|transformers being applied to data sets
2136.48|4.0|of size 8000
2138.24|4.32|um
2140.48|3.2|i'm curious and we could talk about this
2142.56|2.96|sort of later once we've covered the
2143.68|4.159|other material if you found that sample
2145.52|4.72|efficiency is one of the key gains here
2147.839|4.24|um or just experience working on small
2150.24|4.08|data sets of transformers generally and
2152.079|6.04|yeah but but i'll happy to put the
2154.32|3.799|answer to that until after
2158.24|3.44|yeah i think that'd be that'd be really
2160.079|3.121|nice to talk about a bit um and it was
2161.68|4.399|something that in general i guess i'd
2163.2|4.96|say was surprising to us in terms of how
2166.079|4.161|robust npts were on small data sets and
2168.16|3.84|how we surprisingly didn't have to tune
2170.24|3.28|a terrible number of parameters but we
2172.0|3.839|can get into details
2173.52|2.319|in a bit
2177.28|4.16|awesome
2178.8|3.68|so to get into the experiments
2181.44|3.919|um
2182.48|5.76|we focused a lot on tabular data
2185.359|4.401|because it's a very general setting
2188.24|3.44|and it's also notoriously challenging
2189.76|3.359|for deep learning so we know
2191.68|3.12|you know tree based boosting methods
2193.119|4.401|stuff like xg boost
2194.8|5.2|is is very dominant and this is also a
2197.52|4.079|very relevant domain to i think people
2200.0|3.04|in industry and that sort of thing so we
2201.599|4.48|were excited about the idea of trying to
2203.04|5.68|do better on this um so we chose a broad
2206.079|4.801|selection of data sets varying across
2208.72|4.32|a few different dimensions um you know
2210.88|3.68|as we mentioned you know on the order of
2213.04|3.52|all hundreds to tens of millions of
2214.56|3.84|instances um
2216.56|3.519|broad range in the number of features in
2218.4|3.92|the composition of features in terms of
2220.079|3.76|being categorical or continuous um
2222.32|2.96|various types of tasks binary or
2223.839|3.361|multi-class classification as well as
2225.28|3.44|regression and like i said the bass
2227.2|4.399|lines were kind of the usual suspects
2228.72|5.119|for tabular uh data xg boost cad boost
2231.599|4.081|light gbm tuned mlps
2233.839|5.201|and tabnet which is a transformer
2235.68|3.36|architecture for tabular data
2239.119|4.641|so uh to get into the results here i'm
2241.76|5.12|showing the average rank uh for the
2243.76|5.359|various subtasks um we did well in terms
2246.88|3.84|of rank-wise performance against methods
2249.119|3.761|like catboost and xgboost which are
2250.72|4.48|designed specifically for tabular data
2252.88|4.16|and um in fact we find that npt is the
2255.2|2.879|top performer on four of the 10 of these
2257.04|2.96|data sets
2258.079|3.841|um on image data
2260.0|3.92|i mentioned that we used a cnn encoder
2261.92|3.28|and with that we were performing well on
2263.92|2.56|c410
2265.2|3.84|and we also think that you know in
2266.48|4.72|general like with um let's say new work
2269.04|3.52|on image transformers on small data this
2271.2|3.52|can probably just be done with linear
2272.56|3.36|patching um and so this kind of the
2274.72|5.119|manner in which you're embedding things
2275.92|3.919|is probably uh not the key
2280.48|7.04|neil if i can jump in with two questions
2284.24|5.2|uh can you go back two slides first
2287.52|3.76|one is just a small minor point uh one
2289.44|4.08|back one more please
2291.28|6.44|thank you uh here are the features 50
2293.52|4.2|plus what does plus mean here
2298.0|3.359|i'll have to double check what the exact
2299.52|4.0|number is i'm pretty sure it's probably
2301.359|4.24|around 50 i would guess like
2303.52|6.88|all right so the 50 is really an order
2305.599|7.201|of it's it's not like 150 or 5 000.
2310.4|4.08|yes yeah i mean i i i'll double check
2312.8|3.279|for you or you can check with the the
2314.48|4.48|metadata statistics at the end of the
2316.079|4.801|paper um but no it wasn't like uh you
2318.96|4.0|know arbitrarily large i would say
2320.88|3.92|though um
2322.96|4.0|you know we did these ablations on
2324.8|4.4|whether or not we actually need um
2326.96|5.28|attention between attributes we did find
2329.2|6.48|that this ended up benefiting us uh but
2332.24|5.599|you could perhaps do um kind of in a
2335.68|3.52|say just an mlp embedding
2337.839|2.801|in that dimension and go to like a
2339.2|3.6|relatively small number of hidden
2340.64|3.92|dimensions and fit uh kind of an
2342.8|2.96|arbitrary number of features
2344.56|3.76|um
2345.76|5.12|so i i think that uh yeah if you if you
2348.32|4.4|kind of relax the necessity of attention
2350.88|3.6|between attributes you can probably
2352.72|4.24|scale out at least that dimension quite
2354.48|5.84|a lot okay and then my second question
2356.96|3.36|if you could go forward one slide
2360.88|4.08|ah thank you uh here i'm not sure i i
2363.119|3.601|quite caught what is it four of ten data
2364.96|3.76|sets two of ten data sets and four of
2366.72|3.84|ten mean
2368.72|4.72|uh this is of the of all the tabular
2370.56|5.279|data sets that we had so oh so
2373.44|5.2|classification is for i see okay
2375.839|2.801|all right yeah exactly
2379.28|3.28|awesome
2380.96|3.28|any other questions
2382.56|3.039|the the standard errors here because i
2384.24|2.96|mean there's like there's just 10 data
2385.599|3.681|sets right
2387.2|5.36|yeah correct 10 10 total tabular data
2389.28|4.559|sets yeah but these are ranked images
2392.56|2.64|yeah these are these are rank wise
2393.839|3.52|performance correct
2395.2|4.639|okay i'm just
2397.359|3.76|missing
2399.839|2.561|how the
2401.119|2.801|where the uncertainty comes from in this
2402.4|3.52|case
2403.92|3.52|yeah average averaged over four of ten
2405.92|3.919|data sets the rank
2407.44|3.52|um so for for each particular data set
2409.839|3.441|we have a rank of all the different
2410.96|4.0|methods then we take the average and the
2413.28|2.48|um variance
2414.96|3.92|of the
2415.76|5.12|of the rankings within each of the um
2418.88|3.52|types of tasks within binary
2420.88|3.68|classification within multi-class et
2422.4|4.48|cetera
2424.56|5.279|we also if you're curious um you know
2426.88|4.4|have have the full results in the paper
2429.839|3.601|yeah thank you
2431.28|7.0|uh we also have a couple of questions
2433.44|4.84|more there's some more questions yeah
2438.96|4.0|hey yeah thanks i guess i just found it
2441.04|3.84|a little surprising that the
2442.96|4.879|worst performer was
2444.88|5.36|k n given that it's also non-parametric
2447.839|3.601|um i guess could you comment on that and
2450.24|3.359|it is
2451.44|5.04|yeah is it that there's something like
2453.599|4.801|intrinsic to the npt that makes it just
2456.48|4.24|exceptional far beyond other
2458.4|4.719|non-parametric methods or
2460.72|5.92|um yeah why why why is it that k n
2463.119|6.72|performs the worst here
2466.64|4.719|well i i suppose ultimately k n is is
2469.839|3.201|still a relatively naive predictive
2471.359|3.121|method and that um you know it might
2473.04|3.039|just be predicting based on kind of
2474.48|2.56|cluster means so
2476.079|3.121|uh
2477.04|3.6|for example um you know i think this is
2479.2|2.639|probably universally true for all the
2480.64|2.8|data sets but there's probably some
2481.839|3.041|amount of kind of
2483.44|3.04|additional reasoning that needs to occur
2484.88|3.12|over the features at least to basic
2486.48|3.2|level so for example like one of the
2488.0|4.0|data sets is this poker hand data set
2489.68|3.76|where it's like a mapping between all of
2492.0|3.28|the different hands you have in poker
2493.44|3.6|and what like they're commonly known to
2495.28|3.44|people like full houses or whatever so
2497.04|3.279|this this requires some amount of
2498.72|3.2|reasoning over the features to be able
2500.319|2.721|to group things together
2501.92|3.04|um
2503.04|4.24|so just taking like the cluster means of
2504.96|3.84|the featurization of those different um
2507.28|3.28|you know hands is likely not going to
2508.8|2.64|give you a great predictive function
2510.56|3.6|um
2511.44|5.12|whereas npt's can kind of do the classic
2514.16|4.0|thing where say you have an mlp type of
2516.56|2.88|thing over the features or like a you
2518.16|3.12|know tree type of thing over the
2519.44|3.679|features you can learn some sort of
2521.28|4.24|complex embedding but then you also can
2523.119|4.881|do um some non-parametric sort of
2525.52|4.24|prediction uh based on say like clusters
2528.0|3.68|of embeddings
2529.76|4.559|yeah that makes sense i guess what if
2531.68|5.6|what if you used
2534.319|5.841|pre-trained embeddings from
2537.28|5.12|a stack of encoders as as your vector
2540.16|3.439|representation for the k n
2542.4|4.08|how do you think that would perform
2543.599|5.441|compared to the rest of the crowd yeah
2546.48|4.4|yeah so this is like um i mean this idea
2549.04|2.96|is kind of like deep kernel learning or
2550.88|2.64|like um
2552.0|4.72|yeah i believe it is deep kernel
2553.52|5.2|learning is basically you use an mlp
2556.72|4.56|independently um
2558.72|4.8|so you learn an mlp on each uh input
2561.28|3.68|data point and then you apply a gp over
2563.52|2.96|all the representations of those so you
2564.96|2.56|get this sort of like complex embedding
2566.48|3.359|and then the
2567.52|4.88|lookups the key difference between that
2569.839|4.401|type of idea and npt's is that we also
2572.4|3.919|learn the relationships between the data
2574.24|4.0|points themselves because we use this
2576.319|3.921|parametric attention mechanism to learn
2578.24|3.2|the relationship so we're not just
2580.24|2.4|learning like and embedding
2581.44|3.2|independently
2582.64|3.92|um we're basically back propagating
2584.64|3.36|through the entire process learning the
2586.56|3.36|ways in which we would try to embed this
2588.0|3.839|but also the the ways that say the
2589.92|4.32|lookup would occur
2591.839|4.081|and essentially the the relationships at
2594.24|3.599|a that could potentially be kind of
2595.92|4.72|higher order as well
2597.839|6.401|okay cool um wait did you not have one
2600.64|3.6|more one more follow-up or
2604.319|6.0|oh yeah go for it cool yeah thanks um so
2607.2|5.44|i guess then if if the advantage of npt
2610.319|6.0|has to do with sort of the relationships
2612.64|6.199|between data points um
2616.319|5.921|then what if you you know took the
2618.839|5.081|uh took the let's say you know encoder
2622.24|2.64|representations
2623.92|4.56|and then
2624.88|5.6|you pass that as input say for the
2628.48|3.68|you know 10 nearest neighbors
2630.48|4.24|along with like some
2632.16|4.72|other like uh
2634.72|4.48|input representation and sort of had
2636.88|5.28|this like weighted average uh like
2639.2|3.68|attention style where you you weighted
2642.16|2.56|the
2642.88|3.68|uh the vectors
2644.72|4.96|of the
2646.56|6.08|nearest neighbors based on the attention
2649.68|5.12|weights between those uh input data
2652.64|3.28|points and then like the supplied input
2654.8|3.519|data point
2655.92|3.439|and then like pass that as as you know
2658.319|4.161|the the
2659.359|6.24|vector uh to like the final prediction
2662.48|5.92|layer like is do you think that captures
2665.599|5.041|some amount of the relationship or or is
2668.4|4.8|that that off base
2670.64|4.32|so i i think the nice part like and
2673.2|3.36|really what our idea is behind this
2674.96|3.6|whole thing is just
2676.56|3.6|these sorts of instances where um
2678.56|3.92|certain fixed kernels would perform
2680.16|4.0|particularly well in tasks is like kind
2682.48|3.119|of an annoyance and like ultimately like
2684.16|3.6|tuning a lot of these types of things or
2685.599|3.681|trying to derive the predictive methods
2687.76|3.76|that might make a lot of sense for a
2689.28|3.68|given situation kind of stinks and
2691.52|3.2|ideally you'd want to just back
2692.96|3.92|propagate on a data set and kind of
2694.72|3.52|learn these relationships yourself so i
2696.88|3.28|actually would be really interested to
2698.24|3.599|see if we can come up with some
2700.16|4.0|synthetic experiments that have these
2701.839|4.0|sort of like very particular k n like
2704.16|4.159|predictive mechanisms and just see if we
2705.839|5.28|can learn precisely those and get uh you
2708.319|4.161|know zero error uh with npts and in fact
2711.119|3.041|like we'll get into this a little bit
2712.48|3.76|with uh some of the interventional
2714.16|3.679|experiments we do we have like
2716.24|3.44|kind of precise lookup functions that
2717.839|3.76|npt's end up being able to learn so we
2719.68|3.36|can learn interesting relational
2721.599|5.121|functions
2723.04|5.92|cool yeah thanks a lot appreciate it
2726.72|4.879|cool
2728.96|4.8|all right we have one more question from
2731.599|2.161|yes
2734.16|3.6|i just wanted to clarify something about
2736.96|3.2|um
2737.76|4.16|basically so at test time you just take
2740.16|3.679|the exact same data set and you just
2741.92|3.76|like add um
2743.839|3.361|like your test examples right and then
2745.68|2.96|you like do the same type of like
2747.2|3.28|masking and
2748.64|3.04|is that how it works
2750.48|3.119|yeah correct
2751.68|3.28|okay got it and i do have one more
2753.599|3.76|question um
2754.96|4.72|that is just because like um i'm i think
2757.359|4.641|i like misunderstood like how
2759.68|3.919|like the effects of your um mpt
2762.0|3.04|objective do you mind going back to that
2763.599|3.601|slide
2765.04|2.16|sure
2769.76|6.48|yeah um can you can you repeat one more
2772.24|5.44|time like what makes this so special
2776.24|3.04|yeah so the
2777.68|3.439|the regularizer on the right over the
2779.28|3.76|features i would think of
2781.119|3.601|uh very similarly to self-supervised
2783.04|3.2|learning with uh just a standard
2784.72|3.28|transformer like you're you're basically
2786.24|4.4|just introducing a lot more supervision
2788.0|4.24|and you're um even if say you're just
2790.64|2.8|doing a supervised objective this is
2792.24|2.56|kind of like some amount of
2793.44|2.96|reconstruction over the features you
2794.8|2.559|learn a more interesting representation
2796.4|3.28|and like
2797.359|4.081|what a regularizing effect um which we
2799.68|3.679|think is interesting but perhaps not as
2801.44|4.879|interesting as this stochastic target
2803.359|5.041|masking this one is unique because
2806.319|3.28|in kind of standard parametric deep
2808.4|3.04|learning you're not going to have an
2809.599|3.52|instance
2811.44|2.72|in your training process where you're
2813.119|4.561|taking
2814.16|5.6|targets as input um and so
2817.68|3.52|basically what happens is
2819.76|3.12|if you have your training data set as
2821.2|3.28|input um whatever you're going to have
2822.88|3.36|some stochastic feature masking stuff
2824.48|3.839|happening on the features
2826.24|3.76|amongst the training targets
2828.319|3.441|you're randomly going to have some of
2830.0|3.52|those unmasked and some of them will
2831.76|3.2|indeed be masked you're going to be back
2833.52|2.96|propagating a loss on the ones that are
2834.96|3.28|masked of course because you know you
2836.48|2.96|don't want your model to have those
2838.24|3.119|available at input if you're going to
2839.44|3.76|actually try to you know back propagate
2841.359|3.441|a loss on it but you can use the other
2843.2|3.04|ones as input and that means you can
2844.8|3.68|learn these kind of like interpolative
2846.24|3.599|functions um so that was like this whole
2848.48|3.119|idea of like being able to kind of like
2849.839|4.48|learn k n
2851.599|5.76|but doesn't that um allow
2854.319|5.04|the model to cheat again
2857.359|3.921|yeah so this is like an interesting
2859.359|3.681|point and actually like subtle so i
2861.28|4.559|think it's it's really worthwhile to to
2863.04|5.2|bring up um so first of all we never
2865.839|4.401|actually back propagate a loss
2868.24|4.16|on something that was visible to the
2870.24|4.64|model at input
2872.4|4.56|and so if if for example the model did
2874.88|4.32|actually end up basically overfitting on
2876.96|3.92|training labels we would not observe the
2879.2|4.96|model's ability to generalize to test
2880.88|5.84|data we don't observe this um so
2884.16|4.72|obviously it seems like this uh kind of
2886.72|4.399|blocking of back propagation on labels
2888.88|4.32|that are visible at in at input to the
2891.119|4.161|to the npt is helping
2893.2|4.48|it could also be possible that
2895.28|4.24|in bird style stochastic masking you
2897.68|4.24|also randomly will flip
2899.52|4.559|uh some labels to be in a different
2901.92|3.679|category um so this is like kind of just
2904.079|4.0|like a random fine print that was
2905.599|4.081|introduced in the the bird masking
2908.079|3.841|text we also do that so it's possible
2909.68|5.04|that that somehow contributes to the
2911.92|4.08|um to that but it's probably uh pretty
2914.72|3.28|likely to just be the fact that we're
2916.0|3.92|not back propagating a loss on something
2918.0|5.2|that's visible
2919.92|3.28|great thanks make sense
2924.88|5.28|i have two more questions if i can jump
2926.839|5.48|in yeah sure sorry can we go to the uh
2930.16|3.12|the metrics the performance the results
2932.319|2.961|slide
2933.28|3.36|okay
2935.28|3.2|i feel like i missed something else i'm
2936.64|4.64|sorry about this so a you are so looking
2938.48|4.32|on the binary classification auroc
2941.28|3.44|um
2942.8|5.36|can you clarify what these numbers mean
2944.72|3.44|are they the auroc
2948.24|4.72|so so this is the um so on each of the
2951.28|3.76|data sets
2952.96|3.92|um so say for a particular binary
2955.04|3.68|classification data set uh we're going
2956.88|3.92|to get a ranking of the methods
2958.72|4.0|um
2960.8|4.08|to repeat this yeah
2962.72|4.32|go forward so so these numbers here are
2964.88|3.959|the the relative ranking across in this
2967.04|5.12|particular case the four data
2968.839|6.041|sets correct yeah ah i see so this these
2972.16|4.64|values are not the aurocs on average
2974.88|3.679|across the data sets
2976.8|2.799|no yeah they're not i mean like
2978.559|2.081|averaging
2979.599|2.321|yeah
2980.64|2.959|everything
2981.92|4.159|might make sense but averaging things
2983.599|4.24|like accuracy and rmse seems like a bad
2986.079|3.04|idea right because
2987.839|3.361|you might have some data sets where
2989.119|3.681|everything has high accuracy or where
2991.2|2.48|rmse means something drastically
2992.8|2.64|different
2993.68|3.6|i see so this these numbers here only
2995.44|3.2|tell us the relative ranking between the
2997.28|3.279|different methods not how well they
2998.64|3.199|actually perform
3000.559|2.721|i mean it tells us how they perform
3001.839|2.561|relative to one another but not how will
3003.28|2.96|they perform
3004.4|3.36|i see okay but that's all in the
3006.24|3.599|appendix we all have we have that
3007.76|3.28|information i see okay i was i was
3009.839|3.52|sitting here confused going like why is
3011.04|4.24|auroc why is the best one the smallest
3013.359|3.76|um an accuracy what is an accuracy of
3015.28|4.559|2.5 anyways okay that makes much more
3017.119|2.72|sense thank you both
3020.72|2.32|awesome
3023.119|4.96|great um so i'll try to speed through
3025.44|3.919|this just in the interest of time um
3028.079|2.721|but the
3029.359|2.72|uh basically thing the thing that you
3030.8|3.68|might be thinking after all these
3032.079|4.48|results is um are we even learning any
3034.48|4.24|data point interactions uh on these real
3036.559|4.081|data sets and so basically we designed
3038.72|5.28|an experiment to figure this out and the
3040.64|4.959|idea is that we're going to disallow npt
3044.0|3.52|from using other data points when
3045.599|4.48|predicting on one of them
3047.52|4.72|if we do that and we observe that npt
3050.079|4.561|actually predicts or performs
3052.24|4.96|significantly worse it is indeed using
3054.64|5.12|these interactions between data points
3057.2|4.8|um a subtle challenge or kind of like an
3059.76|4.079|added bonus we can get from this is that
3062.0|3.44|um ideally we wouldn't actually break
3063.839|4.72|batch statistics so let's say like the
3065.44|5.04|mean of each particular attribute um if
3068.559|4.481|we can find a way to do this experiment
3070.48|4.0|such that we don't break these things um
3073.04|2.559|we can kind of rule out the possibility
3074.48|3.44|that we learn something that's a bit
3075.599|4.24|similar to batch norm
3077.92|3.679|and so the way that we do this is we
3079.839|3.76|basically look at the predictions for
3081.599|3.76|each one of the data points in sequence
3083.599|3.841|so let's say in this case we're looking
3085.359|4.0|at the prediction of the model for this
3087.44|3.04|particular green row and you know it's
3089.359|2.561|going to be predicting in this last
3090.48|3.44|column that has this question mark which
3091.92|3.36|is masked um what we're going to do is
3093.92|3.679|we're going to permute each of the
3095.28|4.079|attributes independently amongst all
3097.599|3.921|other data points except for that one so
3099.359|3.681|the information for that row if it was
3101.52|4.0|kind of just predicting like a classic
3103.04|3.84|parametric deep model is still intact
3105.52|2.799|but the information from all of the
3106.88|3.199|other rows is gone
3108.319|3.76|um so that's why we call this sort of
3110.079|4.081|the corruption experiment
3112.079|4.401|and so we find in general uh when we
3114.16|3.679|perform this experiment uh performance
3116.48|3.28|kind of falls off a cliff for the vast
3117.839|4.161|majority of these methods and i'll note
3119.76|3.599|that um you know the performances uh
3122.0|2.72|between the methods on a lot of these
3123.359|3.441|were fairly close
3124.72|4.32|um and so this is actually indeed pretty
3126.8|3.68|significant so for example on protein uh
3129.04|2.64|we went from being the top performer
3130.48|2.879|amongst all the methods to the worst
3131.68|3.76|performer worse than even like k n or
3133.359|4.161|something like that um
3135.44|3.2|i'll also note that
3137.52|2.96|there's kind of this interesting
3138.64|4.32|behavior where on these data sets like
3140.48|3.92|forest and kik and breast cancer we
3142.96|3.119|actually observe that there's basically
3144.4|3.679|no drop in performance
3146.079|3.601|and we basically see this as kind of an
3148.079|4.48|interesting feature and not necessarily
3149.68|4.56|a bug of the the model which is that if
3152.559|4.321|uh we're back propagating on a given
3154.24|3.839|data set um the model can sort of just
3156.88|3.12|find that it's actually not that
3158.079|4.0|worthwhile to attempt to predict using
3160.0|3.76|some kind of um you know relational
3162.079|3.441|predictive mechanism amongst data points
3163.76|4.319|and can instead just learn to predict
3165.52|3.839|parametrically uh and basically ignore
3168.079|2.961|other data points when it's predicting
3169.359|4.0|on any given one of them
3171.04|3.76|uh and so this probably leads to some
3173.359|2.801|kind of like interesting ideas where
3174.8|3.6|perhaps you could do like post-hoc
3176.16|3.919|pruning or something like that um taking
3178.4|5.199|away the attention between data points
3180.079|3.52|and doing fine tuning let's say
3184.319|4.24|all right um so now i'll hand over to
3186.319|5.441|yannick to talk a bit about learning uh
3188.559|5.841|some interesting relationships
3191.76|6.48|yeah um will you though um i see that
3194.4|5.84|we're at the end of what the time is but
3198.24|3.839|like um i know there's a buffer plan or
3200.24|3.68|something can you
3202.079|3.841|i can go through this experiment we can
3203.92|5.84|have a bit of discussion what's um what
3205.92|5.919|do you guys prefer yeah i think uh
3209.76|3.76|normally what we do is we would sort of
3211.839|4.161|stop the recording at this point and
3213.52|3.92|have an off the record discussion
3216.0|3.52|and uh
3217.44|6.399|i guess the question to ask is does
3219.52|4.319|anyone have any questions at this point
3227.359|4.641|but i think we've basically been
3229.92|4.24|watching questions as they come so i
3232.0|3.2|i personally feel fine just uh
3234.16|2.32|yeah
3235.2|3.6|considering there's a sort of question
3236.48|2.32|throughout
3238.88|4.719|yeah i guess that sounds uh it sounds
3240.88|4.479|good uh janik you can go forward with it
3243.599|3.041|with like with your dog as planned and
3245.359|3.281|yeah we can
3246.64|4.4|later we can see
3248.64|2.4|about the
3263.04|4.4|well amputees perform in real data and
3265.359|4.161|that they do make use of information
3267.44|3.52|from other samples of the input
3269.52|3.2|but we're now going to take this a bit
3270.96|3.28|further and come up with some toy
3272.72|4.48|experiments that
3274.24|4.879|testify the extent to which npts can
3277.2|3.599|learn to look up information from other
3279.119|3.601|roads like the extent to which they can
3280.799|3.121|learn this non-prometric prediction
3282.72|2.8|mechanism
3283.92|2.56|and so specifically what we'll do is
3285.52|3.68|we'll create the following
3286.48|5.119|semi-synthetic dataset
3289.2|5.04|so i want you to focus on a now
3291.599|4.0|yeah so we take one of the tabular data
3294.24|3.119|sets that we've used previously
3295.599|3.281|specifically the project data set but it
3297.359|3.601|doesn't really matter what matters is
3298.88|3.52|that it's a regression data set and so
3300.96|2.56|now what we do is
3302.4|2.959|we
3303.52|5.599|the top half here is the original data
3305.359|6.801|set but the bottom half is a copy of the
3309.119|5.68|original data set where we have unveiled
3312.16|4.959|the true target value
3314.799|4.161|so now npts could learn to use the
3317.119|4.0|tension between data points to achieve
3318.96|3.28|arbitrarily good performance they could
3321.119|2.881|learn to
3322.24|4.24|look up the target values in these
3324.0|5.52|matching duplicate rows and then paste
3326.48|5.44|them back into the that masked out
3329.52|4.64|target value then at test time of course
3331.92|4.879|we put in you know a novel
3334.16|4.639|test data input where this mechanism is
3336.799|3.601|also possible just to make sure that it
3338.799|3.04|hasn't learned to
3340.4|2.8|memorize anything but has actually
3341.839|3.201|learned this correct
3343.2|4.56|relational mechanism
3345.04|4.559|and so what we see is that indeed mpgs
3347.76|3.76|do successfully learn to perform this
3349.599|3.921|lookup so what i'm visualizing here is
3351.52|4.48|attention maps and they very clearly
3353.52|4.4|show that uh let's say when predicting
3356.0|4.96|for this green row here this first green
3357.92|5.439|row what mpgs look at is exactly only
3360.96|4.159|that other green row here
3363.359|4.24|and so
3365.119|3.921|this is really nice um we can further
3367.599|3.281|look at the
3369.04|4.16|kind of the
3370.88|3.679|the pearson correlation between what
3373.2|4.56|npts should predict and what they
3374.559|4.961|actually do predict and so this is 99.9
3377.76|4.16|this is much better than anything you
3379.52|4.079|could achieve with parametric prediction
3381.92|4.159|and so it seems that npt's here can
3383.599|4.161|actually discover this mechanism and
3386.079|4.48|discover here i feel like it's the right
3387.76|3.92|word because npt's could have
3390.559|1.841|as we've seen
3391.68|2.72|just
3392.4|3.52|also continue to predict in parametric
3394.4|3.6|fashion right from each row
3395.92|3.36|independently um
3398.0|2.96|this is really
3399.28|3.839|kind of showing to us that there is this
3400.96|4.56|bias in the model to
3403.119|4.641|learn to predict from other rows and of
3405.52|4.0|course that that is also very attractive
3407.76|4.0|in this setting because it allows you to
3409.52|4.319|achieve arbitrary load loss um in this
3411.76|3.68|setting or as low as you can you can
3413.839|3.121|optimize for it
3415.44|4.0|and so
3416.96|4.8|we we kind of take that to mean that our
3419.44|4.56|you know gradient-based discovery
3421.76|3.68|nonparametrics philosophy seems to make
3424.0|3.839|some sense
3425.44|4.48|and so we can take this a bit further by
3427.839|4.801|performing somewhat of an interventional
3429.92|5.679|experiment that investigates the extent
3432.64|5.199|to which npts have actually learned
3435.599|3.76|a robust uh you know causal mechanism
3437.839|2.641|that's underlying this semi-synthetic
3439.359|2.72|data set
3440.48|4.879|and so
3442.079|4.641|just depending you know this um uh
3445.359|3.841|this
3446.72|4.399|this extra uh this extra column of test
3449.2|4.0|data that is already kind of cool but i
3451.119|4.72|think we can take it a bit further and
3453.2|4.08|actually study if this generalizes um
3455.839|3.28|beyond the data that we see in the
3457.28|3.6|training set or beyond data coming from
3459.119|3.841|this specific distribution and so what
3460.88|5.04|we now do is we intervene
3462.96|6.399|on individual duplicate data points at
3465.92|5.28|test time by varying their target value
3469.359|4.72|so now we only care about the prediction
3471.2|4.72|in a specific row we do this across all
3474.079|4.24|rows but at each time we just throw a
3475.92|4.0|single row what we do is we change the
3478.319|3.441|target value here
3479.92|4.0|that what we're hoping to see is and
3481.76|3.68|then npt just adjusts the prediction as
3483.92|3.36|well right there's a very simple
3485.44|3.52|intervention experiment for us to test
3487.28|3.839|if mpgs have actually learned this
3488.96|4.08|mechanism and to some extent it also
3491.119|4.561|tests robustness because now we're
3493.04|4.079|associating target values with features
3495.68|3.119|that are not part of the training
3497.119|3.921|distribution here
3498.799|4.641|and so what we see is um
3501.04|4.96|that as we adjust
3503.44|4.24|as we adjust these values here the um
3506.0|3.599|this is the kind of the duplicate value
3507.68|4.08|and then we here's the the target value
3509.599|3.681|as we adjust them we can see the the the
3511.76|4.0|correlation stays really really good
3513.28|4.559|it's not quite 99.9 like on average
3515.76|4.559|we're now at 99.6
3517.839|3.841|um but it's still still very very good
3520.319|2.961|and
3521.68|4.08|at this point you might be
3523.28|4.64|uh slightly annoyed with me because you
3525.76|3.839|know standard non-prometric models can
3527.92|3.679|also solve this task right this is a
3529.599|3.921|task that i could solve by nearest
3531.599|4.081|neighbors sure maybe you know i would
3533.52|3.52|have to change the input format a bit
3535.68|3.6|because this is kind of like in a batch
3537.04|4.64|setting and i can just use masks but
3539.28|4.799|most generally nearest neighbor can also
3541.68|4.56|you know it also look up looks up um
3544.079|4.401|different uh input points based on their
3546.24|3.76|features uh nearest ever doesn't learn
3548.48|3.599|to do this i still think it's cool that
3550.0|4.799|we need to learn this because it does
3552.079|4.72|require you know a a decent amount of
3554.799|3.121|you know computational sequences that we
3556.799|2.961|have to learn like match all the
3557.92|4.159|features look up target file you copy it
3559.76|4.72|back and so on but
3562.079|4.881|um it is in fact very easy for us to
3564.48|3.359|complicate this task to a degree such
3566.96|2.56|that
3567.839|5.041|essentially no other model that we know
3569.52|5.36|of uh can consult this um very easily
3572.88|3.04|and so like a really simple thing to do
3574.88|4.16|is just to
3575.92|4.24|add a plus one to all of the duplicate
3579.04|4.4|values
3580.16|5.36|um so now nearest neighbor would look up
3583.44|3.679|the right column at the right row of
3585.52|3.599|course but it would always predict the
3587.119|3.921|wrong target with a plus one on it and
3589.119|3.361|in fact many of the
3591.04|2.96|the models that we're aware of they're
3592.48|4.16|not modeling
3594.0|4.559|the joint distribution over features and
3596.64|4.0|targets what they're modeling is the
3598.559|5.04|traditional distribution of the targets
3600.64|5.52|given the input features and so they
3603.599|4.801|also cannot do this and so for us it's
3606.16|3.76|really not a problem at all um
3608.4|4.24|amputees will just learn to subtract
3609.92|4.399|another one and no problems and sure
3612.64|5.28|this is also still a very synthetic
3614.319|5.361|setting but um i do think uh
3617.92|4.399|i mean i challenge you to come up with
3619.68|4.96|something that amputees can't solve but
3622.319|5.28|the other models can solve i think this
3624.64|5.199|in general this masking mechanism and
3627.599|4.641|the nonprometricity of the approach is
3629.839|4.0|really nice in general and leads to lots
3632.24|2.559|of nice behavior in a variety of
3633.839|3.441|settings
3634.799|5.121|and so with that um i think we can go to
3637.28|4.96|the conclusions which um neil is going
3639.92|4.399|to give you
3642.24|3.04|yeah i think um i mean we can cut out
3644.319|3.841|the
3645.28|4.48|main part here i'll just fast forward
3648.16|3.6|let's look at them
3649.76|5.2|yeah yeah i i was gonna say i think you
3651.76|4.72|got you all get the gist um npt's take
3654.96|3.28|the entire data set as input and they
3656.48|4.4|use self-attention to model complex
3658.24|3.92|relationships between data points um
3660.88|3.52|you know they do
3662.16|3.84|well in experiments on top of their data
3664.4|3.04|as well as image data
3666.0|3.359|we present some of these interventional
3667.44|3.679|experiments to show that they can solve
3669.359|3.44|complex reasoning tasks uh there's some
3671.119|3.601|more experiments in the paper i'd say
3672.799|3.04|that um you know the interesting type of
3674.72|3.92|future work
3675.839|4.161|is um scaling type things so we can uh
3678.64|3.36|you know not having this mini batching
3680.0|3.52|approximation and then also just trying
3682.0|2.88|to expand this to some more interesting
3683.52|2.4|application domain so we talked a little
3684.88|2.719|bit about metal learning but it could
3685.92|3.199|also be things like you know fusha
3687.599|5.601|generalization in general demand
3689.119|6.161|adaptation semi-supervised learning etc
3693.2|3.84|so i think if um if there's some more
3695.28|3.519|questions maybe we can do some more
3697.04|3.68|discussion
3698.799|3.441|um yeah thing sounds good uh great
3700.72|3.839|thanks for the talk i think everyone had
3702.24|4.559|a fun time
3704.559|4.081|um i will just ask some general
3706.799|3.601|questions and then we can have like a
3708.64|2.959|discussion session with uh everyone
3710.4|2.719|after that
3711.599|2.801|uh so i think one thing that i noticed
3713.119|2.561|is like uh
3714.4|2.88|like this like you said like this is
3715.68|3.2|similar to like k ns
3717.28|2.96|and i thought like this seems similar to
3718.88|3.76|like graph neural networks where you can
3720.24|3.52|think like uh each data point is like a
3722.64|2.399|node and then you can think of
3723.76|2.319|everything as a fully connected graph
3725.039|2.881|and you're learning some sort of
3726.079|3.201|attention weight in this graph
3727.92|3.36|uh so this is like a note prediction
3729.28|3.6|task you are kind of doing on this uh
3731.28|3.279|sort of like graph structure
3732.88|3.6|so any comments on that like is it
3734.559|2.721|similar to like neural networks or is it
3736.48|2.639|like
3737.28|4.64|other differences
3739.119|4.401|yeah it's a very good observation yeah i
3741.92|4.08|think there are a lot of similarities to
3743.52|4.16|work done on graph neural networks um if
3746.0|3.839|we want to talk about differences the
3747.68|4.0|differences might be that that we are
3749.839|3.121|kind of assuming a fully connected graph
3751.68|3.28|right um
3752.96|3.92|and so you could maybe also phrase that
3754.96|3.599|as we're discovering the relational
3756.88|3.36|structure whereas graph neural networks
3758.559|3.441|usually assume that it's given
3760.24|3.359|um but that's also not always true and
3762.0|3.2|so there are
3763.599|3.2|a lot of similarities i don't know neil
3765.2|4.08|if there is something specific you would
3766.799|4.481|like to mention go ahead but it's a very
3769.28|3.92|good observation and we also do feel
3771.28|3.839|that that's the case and we've added an
3773.2|4.08|extra section on related work to
3775.119|3.601|graphical networks in the the updated
3777.28|3.2|version of the paper that will be online
3778.72|5.359|soon
3780.48|5.28|got it yeah i i agree with everything
3784.079|3.681|you've said i think that the closest
3785.76|3.2|work from the gnn literature that we
3787.76|2.96|were looking at a little bit was this
3788.96|3.92|neural relational inference paper which
3790.72|4.16|uses messing passage
3792.88|4.239|message passing neural networks to try
3794.88|4.159|to kind of like learn um edges that may
3797.119|4.881|or may not exist and help for like uh
3799.039|4.56|extrapolating um i think positions of
3802.0|3.599|like particles in like a multi-particle
3803.599|3.681|system or something um which is like
3805.599|3.2|kind of a similar idea to us like you
3807.28|3.44|know if you don't have these edges as
3808.799|3.04|given the attention mechanism could kind
3810.72|3.28|of approximate an interesting
3811.839|3.76|relationship amongst uh some interacts
3814.0|3.359|interacting things
3815.599|3.681|i see got it
3817.359|3.44|yeah that's pretty cool um another thing
3819.28|3.44|is like so you mostly look on like
3820.799|3.201|tabular data but can you also like have
3822.72|3.599|other modalities like if you want to do
3824.0|6.16|language or something uh can you still
3826.319|3.841|use uh non-parametric transformers
3830.559|3.841|yeah so i i think uh part of our
3832.64|4.08|motivation for doing tabular was because
3834.4|5.04|we felt like tabular data is in a sense
3836.72|4.24|a generalization of um let's say the
3839.44|4.0|language data for example i mean i guess
3840.96|4.639|there's this these other notions like
3843.44|4.0|that people have brought up like padding
3845.599|4.161|um but ultimately you can think of it as
3847.44|4.639|like a bunch of categorical attributes
3849.76|3.92|um so it is uh it is definitely
3852.079|3.921|generalizable to things like um
3853.68|5.28|sentences and we do uh you know images
3856.0|4.72|um so yeah
3858.96|4.72|so i think actually like
3860.72|4.56|i like part i i always go back and forth
3863.68|3.84|on whether or not i think smaller or
3865.28|3.6|larger data is more interesting for us
3867.52|2.88|so i think small data is really
3868.88|3.679|interesting because we can't just fit
3870.4|3.76|the entire data set into it and
3872.559|3.601|all of this just
3874.16|4.56|works out of the box without any extra
3876.16|5.04|thought but large data is actually also
3878.72|4.24|really interesting because
3881.2|3.599|sure you might have to introduce some
3882.96|3.599|approximative mechanism or some lookup
3884.799|3.201|mechanism because you can't always have
3886.559|2.56|the entire data set
3888.0|3.119|in
3889.119|4.401|but at the same time you are very
3891.119|5.2|explicitly kind of trading off the
3893.52|5.039|compute that you use to look up uh with
3896.319|4.561|the compute that you need to store like
3898.559|4.161|how much how many parameters in gpg are
3900.88|3.439|used for storing
3902.72|3.119|data right there's lots of memorization
3904.319|4.48|happening in these models and we know
3905.839|5.121|that and so maybe we can use the
3908.799|4.56|problems more efficiently to learn
3910.96|4.639|look-up type behavior right that is more
3913.359|4.0|close to this you know neural k n or
3915.599|2.96|whatever so i think these are very
3917.359|2.321|exciting
3918.559|3.121|questions
3919.68|3.28|yeah yeah i'll also be looking forward
3921.68|2.48|to the future works because it seems
3922.96|3.599|like a very good
3924.16|4.159|way to like do one-shot learning kind of
3926.559|4.56|situations so yeah really very
3928.319|2.8|interesting to see that
3932.079|3.201|um okay so
3933.44|5.72|i will stop the recording and we can
3935.28|3.88|have like any other questions