start_time|end_time|text
3.44|3.08| All right, let's now take a look at how we can implement a
6.52|5.56| convolutional auto encoder in pytorch. So I have like always
12.12|4.0| a couple of helper functions, which I will go over later. Let
16.12|3.92| me hide this view. So we have more space in the center for the
20.04|4.32| notebook here. So we start as usual by importing watermark. So
24.36|3.68| you know which pytorch version I used. We are later also going
28.04|3.72| to use matplotlib for visualizing some outputs, and
31.78|4.82| also the training loss as usual. So the helper functions are some
36.6|4.12| related to plotting. The data loader is exactly the same that
40.72|3.44| we used before. And this is the domestic setting that we also
44.52|4.24| used before, I slightly modified the training function, I will
48.88|3.04| show you the modification later. But except that, um, yeah, I
51.92|6.72| tried to keep it very simple. So we are going to train for 20
58.64|5.48| epochs batch size of 32, just some settings here. Here, I'm
64.12|4.12| getting my data set. Now notice we are not using any validation
68.24|4.64| data points. We don't compute anything like accuracy here. So
72.88|4.16| here, we are only looking at the reconstruction between the input
77.04|5.2| and outputs. And for that, we just use the training set. So
82.84|2.8| just testing that the data loaders work, you can notice a
85.64|7.44| validation set is empty now. Yep, so here, that is our main
93.12|4.04| model. In fact, okay, these are some helper functions from a
97.16|8.48| main model. But here, these are my main, main ones. So I think
105.64|3.2| you can see that. So here, this is my auto encoder class, I will
108.84|3.48| explain the other functions in a few moments, the other classes I
112.32|2.96| showed you. So we are implementing our auto encoder
115.28|5.4| using two sequential parts. That is because that makes it later
120.68|6.24| easier to reuse the encoder as a feature extractor, and to use
126.92|5.4| the decoder as something where we can reconstruct images from a
132.32|5.04| latent representation. So I like to keep those two separate. It's
137.36|3.52| easier to read, in my opinion, but also in that way, we can use
140.88|5.76| them in a certain way, as you will see later. So here, I just
146.64|2.48| implemented convolutional layers, a couple of them. So
149.16|5.48| going from one channel to 32. So the MNIST has only is grayscale.
154.64|3.84| So we only have one input channel, I go to 32. Colonel
158.48|2.8| says three by three, that's just the usual stuff that I go from
161.28|6.88| 32 to 64. And then I have just two conversion layers that keep
168.44|2.84| the channels, you could probably increase the channels, this is
171.28|3.64| just reducing the size by two, this is not doing anything
174.92|3.2| except having more parameters in my network might be redundant,
178.12|4.36| you could be able to remove that, then we are flattening
183.04|4.68| this. So this is, I don't know exactly the size, but this is
187.72|6.44| something times something times 64, which is, yeah, then
194.84|5.44| reshaped flattened into a linear layer. So it will be all combined
200.28|3.28| into one dimension like you are familiar with before from
203.56|7.52| convolutional networks. So in this case, we get a 3136 pixel
211.28|4.56| vector as the output from here. And then I'm compressing it into
215.84|5.16| a two dimensional space. So only two hidden features, it's very
221.0|9.52| small. This is let me go to my slides. So this is here, here.
230.52|2.72| So this is the fully connected one. But for some reason, I
234.84|5.88| should have probably put something in here. So this in
240.72|6.52| between would be only two, two pixels, two dimensional. Okay,
249.68|9.4| back. So this is my encoder going from the 784 pixel MNIST
259.36|2.92| to a two dimensional representation. So we are
262.28|6.4| reducing the size here by 392 by a factor of 392, which is
268.68|4.36| actually very impressive, in my opinion. And then we have the
273.12|5.28| decoder, and the decoder goes backwards. So it takes the two
278.4|3.24| dimensional here, the two dimensional representation, and
282.48|6.2| projects it into a 3136 dimensional representation. And
288.68|4.96| then I'm reshaping this so that it has the dimensionality of the
293.64|4.84| convolution as before. So here, the output now I remember, so the
298.52|4.36| output here would be seven times seven times 64 or 64 times seven
302.88|5.72| times seven. So 64 times seven times seven. That's where we get
308.6|7.28| this value from. Oops. And now we are going backwards, we're
315.88|5.8| going from 3136 to 64 times seven times seven. Then I have
321.68|5.52| my transpose convolution, Nikki relu, transpose conversion. So
327.24|3.24| he I'm essentially with this one, I'm undoing this one with
330.48|3.14| this one, I'm undoing this one, and so forth. And then I go from
333.62|4.9| 64 to 32, like the opposite of this one. And then I have the
338.52|5.22| opposite of this one. However, due to how things work with
343.74|4.62| padding and everything, I tried to get a 28 by 28, tried
348.36|3.64| different paddings and thinking about it where to pad and it
352.0|3.72| didn't work out. So what I get is either something like 27 or
355.72|5.04| 29. I'm not able to get 28. It's just because of rounding in the
360.76|5.0| padding. So this is why I have this trim class. So this trim
366.64|5.32| class I implemented here is just removing one pixel. So from 29,
372.08|5.12| it's trimming it to 28. In that sense, I'm going from 29 to 28.
377.2|4.56| So I have the original size as my input. And then I have a
381.76|7.16| sigmoid here to get a pixels in the range 01. Because I'm not
388.92|4.68| showing it here. But by default, if I don't use anything, the
393.6|3.4| input images, let me go maybe to my helper data loader function.
401.88|3.76| Yeah, so by default, if I don't specify the train transform in
405.64|6.84| my, this is actually cipher 10. And this, so yeah, if I don't
412.48|2.64| specify anything for my train transforms, I will just use this
415.12|5.28| one. And as you know, it will normalize the pixels into a 01
420.4|4.04| range. And I want to compare my input to my output pixels. So I
424.44|4.48| also want my output pixels in a zero and one range as you know,
429.24|5.64| sigmoid will accomplish that. So if you alternatively normalize
434.88|4.4| your inputs for minus one to one pixel range, you could use a 10
439.28|4.12| h function here, technically. Okay, and then in the forward
443.4|3.24| method, I'm just defining my encoder and decoder. So just
446.96|3.96| putting together what I have here. And then I'm initializing
450.92|4.12| it, I'm using Adam here for simplicity. And then I'm calling
455.04|7.56| my train function. Let's take a look at this train function. So
462.6|4.08| okay, this is from the previous lectures, the train classifier.
467.44|3.16| Now we have a slight modification, I can't
473.0|3.4| so the train auto encoder functions almost identical to
476.4|4.0| this train classifier function, except of course, we don't
480.44|3.4| compute the cross entropy loss, we compute the mean squared
483.84|2.88| error loss. So I have an MSE here, if no loss functions
486.76|3.92| specified, some people like to train auto encoders with a
490.68|3.88| binary cross entropy. But I don't, I don't like this idea,
494.56|6.96| because it's not symmetric. In any case, so if you have
501.52|2.32| questions about that, I'm also happy to discuss the small
503.84|3.08| Piazza, I have some visualizations to show it to you.
506.92|2.48| But I don't want to make the lectures too long. If you're
509.4|3.2| interested, I can show it to you, but it's not essential. So
512.6|5.28| we have now the mean squared error loss here. By default, if
517.88|3.0| we don't specify anything, and this is between the logits and
520.88|3.32| the features, right, so we don't use any class labels, that's
524.2|3.2| the main difference compared to the classifier. Here we are
527.76|4.84| comparing the logits, which are the reconstructed images with
532.6|5.68| the original images. Alright, so this is all that's new, all
538.28|4.08| that boilerplate here is the same as before, it's just for
542.44|2.96| except that we don't compute the accuracy, of course, we're just
545.4|3.04| computing plotting the loss, we don't have any accuracy here.
550.4|3.0| And yeah, this is essentially it's pretty simple training
553.4|2.52| function, it looks maybe more complicated than it is. But
555.92|6.44| it's just the classifier function simplified. Alright, so
563.0|5.02| now here, I'm training it. So you can see, there's a big jump,
568.02|3.46| and then it only trains slowly. So the first iteration already
571.48|6.24| minimizes it a lot, which is good to translate for eight
577.72|4.88| minutes on a GPU. And then he has a loss, maybe I can see,
583.12|3.24| maybe training it longer would have helped a little bit. But
586.4|4.84| yeah, I was lazy, just trained it for eight minutes. And you
591.24|4.76| can see, the results look quite blurry. So you can. So at the
596.0|3.1| top, so you have a function on the in the top row, these are
599.1|2.62| the original images. And at the bottom are the reconstructed
601.72|6.64| versions. And you can see, it's all very blurry. So why is that
608.36|2.96| why is the quality is so bad compared to what I showed you
611.32|3.44| here. So the reason is, I'm using only a two dimensional
614.76|3.2| representation here, I actually forgot what I used to use
617.96|2.76| something higher dimensional. So here for the fully connected
620.72|2.68| one, I use the 32 dimensional, I think I did the same thing for
623.4|5.48| the convolution one here. So here, I just want to see what
628.88|3.56| happens if I use a two, two dimensional one, it's an extreme
632.44|2.88| reduction. So it's kind of impressive that it can
635.34|3.62| reconstruct anything at all from just two pixels, right. But then
638.96|4.08| you can also see, it makes mistakes here for the four, it
643.04|2.8| also thinks it's a nine, because four and nine are sometimes very
645.84|4.56| similar. And yeah, so it's not perfect, you would get much,
650.4|4.0| much, much better results, if you would, for example, change
654.4|2.6| this number here, if I go up, if you change this number, let's
657.0|6.72| say to 100, or let's say 64. And 64, you would get much better
663.72|3.92| results. I just wanted to show you the extreme case of having
667.64|6.16| two because a two dimensional space we can visualize. Okay, so
674.0|3.68| because I have some more visualizations. So this is how
677.68|3.68| the reconstruction looks like. Now here, I have a visualization
681.36|4.16| of the two dimensional space, the embedded space for all the
685.52|5.68| training data points. So you can see, it's kind of a mess. But
691.22|4.18| what you can see is that similar numbers cluster together. So I
695.4|3.44| have added the class label information by color. So you can
698.84|4.44| see the oranges here are all the all the ones, the dark blues are
703.28|3.54| all the zeros, and they all cluster together, because yeah,
706.82|3.22| they are somewhat similar. And the auto encoder is able to
710.12|3.4| capture this similarity in this two dimensional space, which is
713.52|5.28| kind of interesting. But you can also see that for, for example,
720.0|3.76| some overlapping eight and nine, you can see they are overlapping
723.76|5.12| here. Three is also buried somewhere here. So it's, it's
728.88|5.32| not great. So certain things are overlapping a lot. So in that
734.2|4.84| way, if you sample a data point here, where things overlap,
739.24|3.12| well, it's unclear which one it would reconstruct, right. So in
742.36|1.86| that way, it loses the information between these
744.22|3.36| classes, it can also maybe then help explain, I think the four
747.58|3.46| might be also bird here might explain that if we have a four
751.04|3.64| here, it reconstruct a nine because they are overlapping
754.68|4.32| here. And in the next lecture, we will talk about variational
759.0|4.48| auto encoders, which fix this problem a little bit better. So
763.48|2.56| there will it will be a little bit better organized in this
766.04|8.7| space. Yeah, and here, I'm just using the decoder. So maybe I
774.74|4.68| can show you the plot latent space function briefly. So that
779.42|7.24| helps you understand maybe how I did that. So that is plot
786.7|3.8| latent space. So here, I'm technically just using a data
790.5|3.36| loader, iterating over the data loader. And here I'm using only
793.86|4.28| the encoder, you can see model dot encoder based on the images.
798.14|4.48| So features here are the images from my data set. And then I'm
802.66|3.32| producing these embeddings. And then I'm here is just some
806.02|3.24| plotting code for plotting these two dimensional embeddings. But
809.26|4.8| here, see, I'm only using the encoder part. And if I go back
814.06|3.24| here, here, I have another visualization here, I'm using
817.3|4.84| the decoder part. So what I'm doing here is I'm reconstructing
822.14|6.92| an image. So I'm taking one point here, let's say 2.5 minus
829.06|5.16| 2.5. So if I go here, it should be somewhere here in the center.
834.5|4.32| And you can see it reconstructs this nine here from a from from
838.82|2.68| this vector. So this is my input vector. And it will
841.5|2.6| reconstruct the nine, I'm just sampling from here. So here, it
844.1|4.2| looks like a pretty dense space. But you can think of it as that
848.3|3.08| we have now a method for reconstructing or generating new
851.38|4.68| data. So I could sample any point here, any can put in some
856.06|5.44| random values. And by inputting these random values, I will be
861.5|3.72| able to generate data. And if I take something that is not in my
865.22|3.76| data set, like point here, it's I actually don't know what will
868.98|2.88| happen, it will create some data, I wish I could show you
871.86|2.96| now, but I would have to run this on my laptop, this will
874.82|2.24| probably take more than 20 minutes. But yeah, if you're
877.06|2.98| interested, you can just put in some random values as a homework
880.04|2.86| or exercise or something, and see what comes out. And you
882.9|3.92| will see the results won't be great. And you maybe get some
886.82|3.08| fantasy numbers that don't exist. And in the next lecture,
890.58|3.24| we will see a better method for doing that. There's a concept
893.82|3.76| called a variational auto encoder. So here, this is just
897.58|2.68| the basic introduction. In the next lecture, I will show you a
900.26|3.84| modification of the auto encoder, which is better at is
904.1|3.68| more designed for sampling from a certain distribution to
907.78|3.56| generate new data. Alright, so this is it for this code
911.34|4.4| example. In the last video, I will go over some other types of
915.74|22.56| auto encoders. And then we will end this lecture for today.