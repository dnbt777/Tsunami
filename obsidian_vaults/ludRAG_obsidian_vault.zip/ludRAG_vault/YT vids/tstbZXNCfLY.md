start_time|end_time|text
0.72|3.6| Yes, so in the previous three videos, we laid the groundwork
4.44|3.04| for understanding how the transformer model in the
7.52|4.28| attention is all you need paper works. So we started with a
11.8|4.04| basic form of self attention for introductory purposes. And then
15.84|4.32| we discussed the scaled dot product attention found in the
20.2|3.24| attention is all you need paper. And then we talked about
23.72|3.44| multi head attention that is running multiple of these
27.16|5.52| scaled dot product attentions in parallel. And these are all
32.8|8.0| components of the transformer model of the original vanilla
42.84|5.4| transformer model, which is found in the attention is all
48.24|3.6| you need paper. And in this video, we will go over the
51.84|3.24| architecture a little bit in more detail how the architecture
55.08|3.72| of the transformer looks like. But before we get to the
58.8|4.56| transformer, let me just briefly recap the scaled dot product
63.36|3.0| attention, because it's part of the transformer and so that we
66.36|3.04| have it fresh in our memory. And the second reason is because I
69.4|3.28| spent so much time making this slide, I would at least like to
72.68|2.56| talk about it for a little bit. So it was not all for nothing.
75.72|3.04| Alright, so on the left hand side here, that is just the
78.76|3.16| summary of the scale to product attention from the original
81.92|4.08| attention is all you need paper. I structured into five steps
86.0|4.28| here, so that we can talk about step by step. So step one is
90.28|4.08| constructing the queries, the keys and the values. So imagine
94.36|5.36| you have an input x, which the rather rows are the different
99.72|3.2| words. So let's say the first row is word one, and the second
102.92|3.68| row is word two, of course, in real data case, you have many
106.6|3.0| more words, but so that I can fit everything onto the slide,
109.6|3.48| we keep the example here small. And then the columns is the
113.08|4.84| demand, the embedding size here, the word embedding size, we
117.92|4.8| multiply it by a matrix WQ, that is a matrix that is updated
122.72|5.36| during back propagation. And this produces the queries. So
128.08|3.72| still, the first row corresponds to word one, and the second row
131.96|4.16| corresponds to word two, we repeat this whole process to get
136.12|3.16| the keys and the values. And then the original paper, the
139.28|5.28| dimensionality here of these is all the same. Yeah, the only
144.56|3.68| difference also here, between computing the queries, the keys
148.24|3.48| and the values is that we are using different weight matrices.
153.0|3.12| We are using the same inputs, of course. Right, so we have now
156.12|4.36| the queries, the keys and the values. And then in step two, we
160.48|2.96| do the matrix multiplication between the queries and the
163.44|4.92| keys. So that is down here. So if we consider the first word,
168.36|5.08| we multiply it, or we compute the dot product with the first
173.44|2.96| word here, because the first column here is also the first
176.4|4.2| word because we have the transpose. So this one would be
180.6|2.48| then really the relationship between the first word with
183.08|5.2| itself. And then for instance, on the first row and the second
188.28|3.04| column would be the relationship between the first word and the
191.32|4.04| second word and so forth. So we can really think of this as
195.36|3.36| something that captures the relationships between the words,
198.72|4.24| if you think of the dot product as a similarity or compatibility
203.04|6.24| measure here. And then in step three, we are scaling. So we are
209.28|5.64| scaling by square root of decay. So decay is the size of the
214.92|8.72| keys here. That is to prevent the softmax from being too sharp,
223.64|3.72| because if we have large dot products, or very negative dot
227.36|3.24| products, very positive of every negative ones, then we will be
230.6|3.6| at the ends of the softmax having values close to one and
234.2|4.56| close to zero, which does result in small gradients, it's not so
238.76|6.0| good for training. Step four, we don't actually apply the softmax.
245.96|4.64| So I'm just calling softmax on that to normalize. And then in
250.6|6.8| the last step, step five, we multiply our relationships here
257.72|5.52| with the values. So then what we will end up with is with the
263.24|4.32| first here, that's like the relationships of the first word
268.52|3.64| corresponding to the whole context. So it's still the first
272.16|3.8| was still corresponding to the first word, but now it contains
275.96|4.24| information of all the other words. This you can think of as
280.2|3.52| a waiting, we are waiting it with the other words, for
283.72|6.16| instance, if we consider this, let's make this cleaner here. So
289.88|4.76| if we consider the first row, and this one, like I said,
294.64|4.08| captures the relationship between word one, and word two.
298.72|3.6| So this is word one, and word one, and word one, and word two.
302.32|4.96| So it's all the relationships for word one. And then here, the
307.28|6.44| first elements of word one and two. And this captures then
314.24|4.28| word one, essentially, with the relationships with word one and
318.52|4.56| two, if that makes sense, and then we continue. So we do that
323.08|4.6| for all the other positions here. And with these here, so
327.68|4.92| it's essentially incorporating information about the other word
332.6|3.84| about word one, but also word two, if we had a longer sentence,
336.44|2.08| that would be a little bit more interesting, because then we
338.52|4.76| would have a larger context here. But essentially, yeah,
343.28|2.8| it's about incorporating the context for each word, the
346.08|4.08| context of the sentence. So that's the idea between the
350.16|4.96| scaled dot product attention. So then we had multi head
355.12|3.48| attention. So what is multi head attention, again, multi head
358.6|4.84| attention is, you're repeating this whole process in parallel.
363.44|4.36| So this is again from the original paper. So we are now
367.84|4.92| repeating this h times and then concatenate the results, and
372.76|3.84| then apply a fully connected layer. So here, try to visualize
376.6|4.44| that by having three matrices instead of one, so we get three
381.08|3.44| queries, and so forth. And that's, of course, also true for
384.52|3.88| the keys and the values. And you can think of them as different
388.4|5.2| slices or different layers, and you can compute all of these h
393.8|4.92| months in parallel, then you concatenate them. So you get
398.72|5.12| these ACE, if I go back one slide, so you get h times this
403.88|4.62| a, and then you concatenate those. And then you multiply it
408.5|6.18| by weight matrix. And this is the fully connected part here.
414.68|3.56| Yeah, so here it is here. That's the transformer architecture.
418.52|3.36| And yeah, I know it looks pretty complicated at first glance,
421.88|3.04| there are lots of little details, but we will be able to
424.92|4.4| understand it by tackling it one thing at a time. So I made a
429.32|3.24| couple of slides, where I will explain all these little
432.56|4.24| details going on here. So in this slide, let's start with a
436.8|4.04| big picture. So we can see the big picture is that we have two
440.84|9.12| parts, an encoder, and decoder here. And the encoder receives
450.44|4.32| input words. So that could be a sentence, it will reproduce or
454.76|6.32| reproduce representation of that that is then passed to the
461.08|6.4| decoder. Together with outputs, shifted outputs, I will get back
467.48|4.24| to that later in a later slide. But the big goal here is that it
471.72|4.88| will produce the output probabilities for the words to be
476.6|4.0| generated. So it's generating a sentence. And you can think of
480.6|3.12| it as let's say, translating a sentence, it reads an input
483.72|4.4| sentence, and then it translates the sentence by generating one
488.2|4.32| word at a time. And there are some familiar parts to it. So
492.6|4.0| first of all, notice we have the multi head attention here, and
496.6|2.88| we had attention here. That is what we talked about in the
499.48|2.96| previous slide so much. So that's the multi attention from
502.44|3.16| the previous slide that we talked about. It also appears
505.6|3.72| here. And here, there's actually a masked version, we will talk
509.32|4.4| about the masked version also in a separate slide. Other things
513.72|6.88| you might notice here is also that we have skip connections. So
520.6|2.8| these skip connections are essentially the residual
523.4|3.52| connections that we talked about in the residual network in the
526.92|5.68| CNN lectures, similar concept where we add the input to the
532.6|4.24| output of something that went through a layer, right. So what
536.84|4.56| we are doing here is we are, let's say, taking this one, this
541.48|3.76| input here, and we're adding it at this stage after the multi
545.24|4.08| head attention layers. We're doing the same thing here. So
549.32|3.6| here, we are optionally skipping the feed forward network. So
552.92|3.84| for instance, if this is not learning anything useful, then
556.76|3.68| we will have just forwarded the input here. So this skip
560.44|5.6| connections essentially adding it. And this is also why we
566.04|4.64| have certain dimensions. So originally, the input embedding
570.68|9.44| here is the sentence length t times 512. So we have input
580.12|3.6| input embedding size of 512. And the original paper, they
583.72|4.16| defined it as 512. And what comes out of here of the multi
587.88|7.04| head attention is also a 512 dimensional embedding that is
594.92|3.6| so that we can then add those together. So that's why we have
598.52|3.6| the same dimensions. Same is true for here and here. So the
602.44|4.4| multi layer perceptron layers here, the feed forward or
606.84|3.84| multi layer perceptron layers, they also they are matrix
610.68|8.16| essentially, wo, which is 512 as the number of columns. So it's
618.84|7.12| 512 times 512. Um, what else? Yeah, I think this is maybe it
625.96|2.72| for this slide. So I don't want to like I said, I don't want to
628.68|3.28| talk too much about every detail in one particular slide,
631.96|2.24| because then it gets too cramped. Maybe one more thing
634.2|3.84| highlighting here, there are more residual connections also
638.04|5.44| in the decoder. Speaking of which, so the encoder and
643.48|3.92| decoder parts are also repeated. So you can maybe see here in a
647.4|4.72| small font, there is this n x. So this just means that they
652.12|3.68| are repeating the encoder blocks and decoder blocks a couple of
655.8|4.48| times. So in fact, in the original paper, the repeat that
660.28|8.0| six times, so we have six encoders, and six decoders. The
668.28|3.04| structure of the encoders and the decoders is the same as
671.32|2.96| just repeated, there is no weight sharing, they are
674.28|3.36| separate. So they're separate encoders, but they have exactly
677.64|5.12| the same structure. And the same is true for the decoders. So
682.76|4.8| next, let's talk about masked multi head attention. So what's
687.56|2.72| that? Now, do we need another video about masked multi head
690.28|3.44| attention? Don't worry, it's essentially the same concept as
693.72|3.92| the multi head attention, except we are masking some inputs in
697.64|4.24| the sequence. So essentially, it's about masking subsequent
701.88|4.4| sequence elements. So here, the decoder is generating one word
706.28|6.08| at a time. And let's say we're having a sentence consisting of
712.36|3.44| 10 words, we are currently generating word five. So we
715.8|6.24| would be at this stage, masking words 6789 and 10 that are
722.04|2.48| already present in the training data set. So if we have a
724.52|3.68| training data set, we have access to the full sequence, but
728.2|4.08| we are masking those words that that are not generated yet,
732.28|4.4| essentially. So this will allow the model to attend to positions
736.68|3.92| up to and including the current position. And how this masking
740.6|6.64| works is by setting values as input to the softmax to minus
747.24|3.92| infinity so that when softmax processes them, there will be
751.16|4.64| zeros, zero probabilities. So this might look a little bit
756.68|4.64| obscure. So I made another slide illustrating this masking one
761.32|5.84| second. So let's consider we have the input sentence, I like
767.16|5.12| plants, and we want to translate it into German. So the correct
772.68|6.16| German translation would be Ich mag flunzen. And this is known
778.84|2.72| during training. When we're training this transformer, we
781.56|5.04| know the correct translation. But when we're training it, we
786.6|4.88| are training the model to produce one word at a time. The
791.48|3.52| input is provided as full, it will produce an upper
795.0|4.56| representation of that input. But then let's say, we have
799.56|6.56| already generated the word ish. And we are currently about to
806.28|2.96| predict the word, the second word, this is what we want to
809.24|4.32| predict next, we are giving the model the whole sequence here is
813.56|6.24| input. But it would be kind of cheating if we would show the
819.8|4.08| model, these two words, because these have to be generated, we
823.88|3.36| assume right now only the first word is generated. So it would
827.24|5.12| be cheating by just giving access to these words to the
832.36|3.92| model here at this stage. So we are masking them. So here,
836.36|4.48| that's what I try to illustrate, we are masking these words, so
840.84|3.92| it doesn't have access to them yet. Once it has, let's say,
844.76|4.08| generated these two words, we will unmask this word, and only
848.84|2.96| let mask the last word that it has to generate and so forth.
851.8|7.92| Yeah, one more detail here. So the output size, when we are
859.72|4.24| predicting here, this is one computationally expensive step,
864.52|5.6| because the outputs here are the predicted probabilities for each
870.12|3.28| word in the dictionary. So if you have a dictionary, if you
873.4|4.8| think back of the RNN, the examples of the RNN, when we had
878.2|3.76| the word RNN for classification, I think we had a dictionary size
881.96|6.48| of 20,000. So we have 20,000 probabilities for each word, and
888.44|4.48| then we pick the word with the highest probability, and get the
892.92|3.44| index for that. And then this is our predicted word at this given
896.36|5.52| position. So it's near by the highest softmax probability in
901.88|2.48| an auto regressive fashion, which means essentially one word
904.36|4.8| at a time. And the output size here of this linear layer is the
909.16|2.72| other word dictionary size, like I mentioned, which goes to the
911.88|3.52| softmax for normalization. And then we pick the largest one.
915.4|3.68| And then we have the learning is via cross entropy here.
920.76|4.24| All right, let's now talk about this positional encoding here.
925.0|3.36| So there is something that is added to the input embeddings.
929.16|3.92| So if we think about the scaled dot product, the self attention,
933.08|4.56| how it works is that we are essentially relating each word,
937.64|3.6| the query to all the other words in the sentence, that's a
941.24|4.56| self attention part. But there is no notion of where the word
945.8|4.24| is located in that sentence. So it's kind of invariant towards
950.04|2.4| where the word is in the sentence, we are relating it to
952.44|2.96| all the other words, but it doesn't really matter. Yeah, if
955.4|2.56| that's the first word of the sentence, the last word, and so
957.96|3.28| forth, we could get the same values. It's kind of the same
961.24|3.36| concept, like with multi layer perceptrons, it's not really
964.6|4.0| aware of the position in the sentence, right. So if we would
968.6|2.88| shuffle, like I talked about before in a previous lecture, if
971.48|3.36| we would shuffle all the columns in the data set, we could
974.84|6.08| technically still learn the same multi layer perceptron. So here
980.92|4.72| it's about making the model behave slightly differently if
985.64|3.2| the word is in different positions of the sentence. So
988.84|3.36| here they have this notion of the sinusoidal positional
992.2|4.32| encoding, which is added as a vector of small values to the
996.52|4.56| word embedding vector. So they're using a sine and cosine
1002.44|7.04| function here. And they are like, it's rather like someone
1009.48|4.64| like this. They are not totally overlapping, they are a little
1014.12|5.44| bit positions by one position to the right, and so forth. And
1019.56|7.28| essentially, it's about capturing these, so there will
1026.84|3.28| be essentially a vector, depending on which position. So
1030.12|5.12| if we have different functions, or values of sine and cosine,
1035.56|3.2| and then we have the different positions in the text, let's say
1038.76|6.4| one, two, three, four, five, six, and fourth, then we will be
1045.16|2.88| extracting this, which is a unique pattern for that
1049.16|2.72| position. So for instance, just for simplicity, we would have
1052.2|4.0| two values here. And these two values are different in position
1056.2|5.28| one compared to position three, for example. And we're just
1061.48|4.8| using that as a simple way of providing some position
1066.28|5.84| information. This is just to kind of get different results,
1072.12|3.68| depending on where in the sentence, the word is located.
1076.6|3.28| And it is all there is to it, essentially. Yeah, just as a
1079.88|3.76| reminder, also, the input size and the output size are the same.
1083.88|5.84| This is so that we can repeat this six times and then also
1089.72|3.04| have the skip connections, I had should have added this
1092.76|5.52| information maybe earlier, but that's also fine here. Okay, so
1098.28|4.96| next, let's talk about these ad and norm layers. So what are
1103.24|4.52| those, we can find them here everywhere in the network. And
1107.8|4.16| yeah, the ad corresponds to the residual the skip connections
1111.96|3.2| that I just mentioned again on the previous slide. But what is
1115.16|4.28| now the norm part, so the norm corresponds to layer
1119.44|3.72| normalization. We haven't talked about that yet. So I wanted to
1123.16|2.76| actually talk about it in the convolution neural network
1125.92|3.24| lectures, but they were already so long, that I decided to skip
1129.16|3.96| that. But it's essentially related to batch normalization.
1133.4|4.0| Here's a visualization of the different common forms of
1137.4|2.84| normalization and convolutional networks. It's from a paper
1140.24|4.64| called group normalization. So we are focusing now on, let's
1144.88|4.04| say, batch normalization. And this is here shown in the
1148.92|4.36| context of convolutional networks, where, as you remember,
1153.28|3.44| we are normalizing across the batch dimension. So you can
1156.72|3.66| actually, so here, they have that separate, the height and
1160.38|6.84| width and the color channels. So here, essentially, you can think
1167.22|7.38| of h and w as the features, and the form, we have one one
1174.6|3.28| channel, and then you have the different channels here. And then
1177.88|6.04| n is the batch size. And here, the blue part is how or where we
1184.36|5.0| get the how we normalize here, we are normalizing across n. So
1189.36|9.16| we are getting the mean and sigma for the normalization from
1198.64|5.02| the batch dimension. In layer normalization here, we are
1203.66|6.22| getting it across layer or channel dimension. So in this
1209.88|2.16| case, when you think of the multi head attention, we would
1212.08|5.48| do it across these attention heads, essentially. So we have,
1217.96|2.2| like I mentioned before, multiple attention heads,
1220.16|2.96| right? I think it's eight in the original paper. So we have eight
1223.12|3.16| attention heads, we would be normalizing across the attention
1226.28|2.62| heads, computing the mean and sigma, and then the whole
1228.9|7.3| process is essentially similar to batch normalization. Lastly,
1236.28|4.84| to finish things up, here's an example of how attention values
1241.14|3.3| look like from the original paper. So if you think of
1244.44|3.48| attention values, as values between zero and one, the
1247.92|7.28| attention mask, so if you think back of the Q k t, and then
1255.2|4.08| normalized, so if you and then through the okay, through the
1259.28|4.44| softmax. So if you think of these, we can look at the
1263.72|3.44| attention values for each word towards each other work, right?
1267.36|3.6| And this is what's shown here. So for instance, when you look at
1270.96|4.48| the word law, it's kind of strongly connected. So the
1275.46|2.3| saturation here of the color says how strongly it is
1277.76|3.2| connected. So you can see, it's mostly connected to this here.
1281.28|2.88| It's the strongest connections, maybe this one has a slight
1284.16|3.68| connection also to things further away here, but very weak
1287.84|4.12| connection to the missing to the middle middle parts here. So
1291.96|2.92| yeah, this is just a visualization. And here in this
1294.88|7.2| visualization, it's shown for attention head, see, five, and
1302.12|4.68| head six, and you can see that it's actually not redundant to
1306.8|4.16| have multiple attention heads, you can see, this pattern here
1310.96|3.64| is very different, let's say from this pattern. So the
1314.6|2.88| attention head is actually having different attention
1317.48|2.72| heads is actually useful. So it's learning different things
1320.2|4.08| in these different attention heads. Okay, so this was
1324.32|3.36| probably a very long video now on how the transformer
1327.68|4.16| architecture looks like. In the next video, I will talk also
1331.84|3.48| about some other more modern transformer architectures on a
1335.36|3.68| big picture level. So they have been these, for instance,
1339.04|3.12| popular models like BERT, GPT, and BART. Of course, there are
1342.16|4.16| many, many, many more. But these are one of the popular ones, the
1346.32|3.08| most popular ones, I will briefly talk about those. And
1349.4|3.56| then we will end this lecture with an implementation in
1352.96|19.0| PyTorch.