start_time|end_time|text
5.04|6.16|so i'm excited to talk today about
8.72|4.72|our recent work on using transformers
11.2|4.96|for reinforcement learning
13.44|3.839|and this is joint work with a bunch of
16.16|3.52|really
17.279|3.84|exciting collaborators most of them at
19.68|4.72|uc berkeley
21.119|5.841|and some of them at facebook and google
24.4|5.52|uh i should mention this book was led by
26.96|4.399|very two talented undergrads lichen and
29.92|2.4|kevin bloom
31.359|2.88|and
32.32|2.8|i'm excited to present the results we
34.239|2.401|had
35.12|3.599|so let's
36.64|3.52|try to motivate why we even care about
38.719|2.561|this problem
40.16|4.32|so
41.28|5.68|uh we have seen in the last three or
44.48|5.04|four years that transformers
46.96|5.52|since the introduction in 2017 have
49.52|4.8|taken over lots and lots of different
52.48|4.399|fields of artificial
54.32|5.36|intelligence so we saw them having a big
56.879|5.761|impact for language processing
59.68|5.68|we saw them being used for vision in the
62.64|4.799|vision transformer very recently
65.36|3.68|they were in nature trying to solve
67.439|3.68|protein folding
69.04|4.32|and very soon they might just took place
71.119|4.64|as computer scientists by having
73.36|4.32|automatically generate code
75.759|4.081|uh so with all of these advances it
77.68|4.96|seems like we are getting closer to
79.84|3.84|having a unified model for decision
82.64|3.76|making
83.68|4.56|uh or for artificial intelligence but
86.4|4.399|artificial intelligence
88.24|5.36|is much more about not just having
90.799|4.721|perception but also using the perception
93.6|3.519|knowledge to make decisions
95.52|3.279|and this is what this talk is going to
97.119|3.841|be about
98.799|4.241|but before i go into actually thinking
100.96|5.199|about how we will use these models for
103.04|5.2|decision making here is a motivation for
106.159|3.6|why i think it is important to ask this
108.24|2.559|question
109.759|2.0|so
110.799|2.64|unlike
111.759|4.561|models for rl
113.439|4.72|when we look at transformers uh for
116.32|3.28|perception modalities like i showed in
118.159|3.521|the previous slide
119.6|5.119|we find that these models are very
121.68|4.719|scalable and have very stable
124.719|3.921|training dynamics
126.399|4.401|so you can keep as long as you have
128.64|4.319|enough computation and you have more and
130.8|4.4|more data that can be sourced
132.959|4.481|you can train bigger and bigger models
135.2|3.759|and you'll see very smooth reductions in
137.44|2.4|the loss
138.959|3.28|um
139.84|3.36|and the overall training dynamics are
142.239|3.041|very
143.2|4.64|are very stable and this makes it very
145.28|4.319|easy for practitioners and researchers
147.84|3.119|to build these models
149.599|4.241|um and
150.959|4.161|learn richer and richer distributions
153.84|3.36|so like i said
155.12|4.399|uh all of these advances have so far
157.2|4.399|occurred in perception uh what would be
159.519|4.72|interested in this talk is to think
161.599|5.201|about how we can go from perception
164.239|4.961|uh looking at images looking at text and
166.8|4.24|all these kinds of sensory signals to
169.2|3.52|then going into the field of actually
171.04|3.36|taking actions
172.72|3.76|and making
174.4|3.44|our agents do interesting things in the
176.48|2.8|world
177.84|4.0|uh
179.28|5.52|and here throughout the talk we should
181.84|5.2|be thinking about why this perspective
184.8|4.079|is going to enable us to do
187.04|3.68|scalable learning like i show in the
188.879|4.64|previous slide as well as bring
190.72|4.879|stability into the whole procedure
193.519|3.521|so sequential decision making is a very
195.599|3.601|broad area
197.04|4.0|and what
199.2|3.92|i'm specifically going to be focusing on
201.04|3.919|today is one route to sequential
203.12|3.119|decision making that's reinforcement
204.959|5.2|learning
206.239|6.321|so uh just as a brief background uh
210.159|4.0|what is reinforcement learning so we are
212.56|4.399|given an agent
214.159|4.881|uh who's in a current state and the
216.959|5.521|agent is going to interact with the
219.04|5.68|environment by taking actions
222.48|4.72|and by taking these actions the
224.72|4.079|environment is going to return to it a
227.2|3.759|reward
228.799|4.08|for how good that action was
230.959|4.241|as well as next state into which the
232.879|5.601|agent will transition and this whole
235.2|6.48|feedback loop will continue
238.48|4.64|the goal here for an intelligent agent
241.68|3.759|is to then
243.12|4.16|using trial and error so try out
245.439|2.961|different actions see what rewards will
247.28|4.159|lead to
248.4|6.72|learn a policy which maps your states to
251.439|5.76|actions such that the policy maximizes
255.12|3.2|the agent's cumulative rewards over time
257.199|2.961|horizon
258.32|3.84|so you take a sequence of actions and
260.16|4.479|then based on the reward you accumulate
262.16|5.52|for that sequence of action actions will
264.639|5.921|judge how good your policy is
267.68|5.12|this talk um is also going to be
270.56|4.0|specifically focused on a form of
272.8|4.48|reinforcement learning that goes by the
274.56|5.44|name of offline reinforcement learning
277.28|4.56|so the idea here is that
280.0|3.36|what changes from the previous picture
281.84|3.76|where i was talking about online
283.36|3.76|learning online reinforcement learning
285.6|3.76|is that here
287.12|4.639|now instead of doing actively
289.36|4.96|interacting with the environment
291.759|5.281|you have a collection of log data of
294.32|5.04|interactions so think about some robot
297.04|4.159|that's going out in the fields and it it
299.36|4.96|collects a bunch of sensory data and
301.199|5.681|you've all locked it and using that log
304.32|4.64|data you now want to train another agent
306.88|4.72|it could be another robot
308.96|4.64|to then learn something interesting
311.6|4.08|about that environment just by looking
313.6|4.4|at log data
315.68|3.76|okay so there's no trial and error
318.0|5.199|component
319.44|5.599|which is currently one of the
323.199|4.241|extensions of this framework which would
325.039|4.16|be very exciting so i'll talk about this
327.44|3.759|towards the end of the talk why it's
329.199|4.0|exciting to think about how we extend
331.199|4.241|how we can extend this framework to
333.199|4.401|include an expiration component and have
335.44|4.0|trial and error
337.6|4.48|okay so uh
339.44|4.479|not now to go more concretely into what
342.08|4.32|the motivating challenge of the stock
343.919|6.0|was now that we have introduced rl
346.4|7.04|uh so let's look at some statistics
349.919|5.041|so large language models i have billions
353.44|3.039|of parameters
354.96|3.519|and they have
356.479|4.321|right today they have roughly about 100
358.479|4.56|layers in transformer
360.8|5.6|uh they're very stable to train using
363.039|5.761|supervised learning uh style losses
366.4|4.56|which are the building blocks of auto
368.8|5.679|regressive generation for instance or
370.96|4.32|for mass language modeling as in but
374.479|4.56|um
375.28|6.639|and this is like an field that's growing
379.039|4.401|every day and this is a course on it at
381.919|3.361|stanford that we're all taking just
383.44|4.879|because it has had such a monumental
385.28|3.039|impact on ai
388.96|5.44|rl policies on the other hand uh and i'm
391.68|4.959|talking about deep rl uh
394.4|4.48|the maximum they would extend to is
396.639|3.441|maybe millions of parameters or 20
398.88|2.56|layers
400.08|2.559|um
401.44|3.36|and
402.639|4.081|what's really unnerving is that they're
404.8|4.64|very unstable to train so the current
406.72|4.16|algorithms for reinforcement learning
409.44|3.52|they build on
410.88|3.52|a mostly dynamic programming which
412.96|3.04|involves solving an inner loop
414.4|5.04|optimization problem that's very
416.0|5.84|unstable and it's very common to see
419.44|4.319|practitioners in rl looking at reward
421.84|4.079|curves that look like this
423.759|4.961|so what i really want is you to see here
425.919|4.881|is the variance in the returns that
428.72|4.4|we tend to get in rl
430.8|4.56|it's really huge even after doing
433.12|4.16|multiple rounds of experimentation
435.36|4.559|and that's often that is really at the
437.28|4.639|core got to done with the fact that
439.919|4.56|um our algorithms
441.919|4.481|learning checks need
444.479|4.401|uh better improvements so that the
446.4|4.079|performance can be stably achieved by
448.88|4.319|agents
450.479|3.84|in complex environments
453.199|5.12|so
454.319|6.641|what this work is uh hoping to do is
458.319|5.6|it's going to introduce transformers
460.96|5.04|and i'll first show in one slide what
463.919|3.521|exactly that model looks like and we're
466.0|3.12|going to go into
467.44|4.24|uh deeper details of each of the
469.12|2.56|components
474.0|3.599|yeah can i ask a question real quick
476.319|3.921|uh yes
477.599|4.641|and thank you
480.24|4.32|what i'm curious to know is what is the
482.24|4.32|what is the cause for why rl typically
484.56|4.56|has several orders of magnitude fewer
486.56|2.56|parameters
489.44|4.0|uh that's a great question so
492.0|3.84|typically when you think about
493.44|3.199|reinforcement learning algorithms
495.84|4.4|uh
496.639|6.24|in deep rl in particular so the most
500.24|4.639|common algorithms for example have
502.879|4.081|different networks playing different
504.879|3.521|roles in
506.96|3.84|uh the
508.4|4.96|in the task so you'll have a network for
510.8|4.32|instance playing the role of an actor
513.36|3.599|uh since trying to figure out a policy
515.12|3.919|and then there'll be a different network
516.959|6.08|that's playing the role of a critic
519.039|6.561|and these networks are trained on data
523.039|4.881|that's adaptively gathered so unlike
525.6|4.239|perception where you will have
527.92|4.4|a huge data set
529.839|3.761|of interactions on which you can train
532.32|2.32|your
533.6|4.08|models
534.64|5.199|in this case the architectures and even
537.68|2.96|the environments to some extent
539.839|3.921|are
540.64|5.92|very simplistic because of the fact that
543.76|4.4|we are trying to train very small
546.56|2.959|components the functions that you're
548.16|2.48|training and then bringing them all
549.519|2.0|together
550.64|2.4|and
551.519|4.161|these functions
553.04|4.479|uh are often trained in not super
555.68|4.32|complex environments
557.519|4.401|so it's a mix of different issues i
560.0|3.839|wouldn't say it's purely just what it
561.92|4.72|would do with the fact that
563.839|4.401|the learning objective is our fault but
566.64|4.24|it's a combination of the environments
568.24|4.48|we use the combination of the targets
570.88|2.959|that each of the neural networks are
572.72|2.96|predicting
573.839|5.281|which leads to
575.68|5.92|networks which are much bigger than
579.12|4.719|what we currently see tending to overfit
581.6|4.48|and that's why it's very common to see
583.839|4.401|neural networks with
586.08|5.759|much fewer layers being used in rl as
588.24|3.599|opposed to perception
592.8|2.32|thank you
595.6|3.2|you want to ask a question
597.6|3.28|yep
598.8|4.96|yeah i was going to um is there a reason
600.88|4.8|why you chose offline rl versus online
603.76|3.68|rl
605.68|3.76|uh that's that's another great question
607.44|3.68|so the question is why offline are as
609.44|4.959|opposed to online rl
611.12|5.2|um and the the plain reason is because
614.399|5.521|this is the first work trying to look at
616.32|7.04|reinforcement learning uh so offline rl
619.92|5.28|avoids this problem of exploration
623.36|3.52|you are given a log data set of
625.2|3.92|interactions you're not allowed to
626.88|4.399|further interact with the environment
629.12|5.52|so just from this data set you're trying
631.279|5.12|to unearth a policy of what the optimal
634.64|4.24|agent would look like
636.399|5.041|so it would right like if you do online
638.88|4.56|rl wouldn't that like just give you this
641.44|3.12|opportunity of exploration
643.44|4.72|basically
644.56|6.48|it would it would what it would also do
648.16|4.0|which is technically challenging here
651.04|2.96|is that
652.16|4.0|the exploration would be harder to
654.0|3.92|encode so offline r is the first step
656.16|3.84|there is no reason why
657.92|3.919|we should not study why online url
660.0|4.64|cannot be done it's just that it
661.839|5.12|provides a more contained setup where
664.64|4.8|ideas from transformers will directly
666.959|2.481|extend
673.2|6.079|okay uh sounds good so let's look at the
675.6|5.52|model and it's really simple on purpose
679.279|4.081|so what we're going to do is we're going
681.12|4.32|to look at our offline data
683.36|3.52|which is essentially in the form of
685.44|2.32|trajectories
686.88|2.959|so
687.76|4.48|offline data would look like a sequence
689.839|3.521|of states actions
692.24|3.279|returns
693.36|3.76|over multiple time steps
695.519|4.0|it's a sequence
697.12|5.36|so it's natural to think of us as
699.519|4.32|directly feeding it as input to a
702.48|3.359|transformer
703.839|5.841|in this case we use a causal causal
705.839|5.921|transformer as it's common in gpt
709.68|4.08|uh so we go from left to right and
711.76|5.04|because this data set comes with the
713.76|5.6|notion of time step causality here is
716.8|4.8|much more well intended than the general
719.36|3.84|meaning that's used for perception this
721.6|4.16|is really causality
723.2|3.68|how it should be in in perspective of
725.76|3.84|time
726.88|6.639|what we predict out of this transformer
729.6|6.479|are the actions conditioned on
733.519|4.081|everything that comes before that token
736.079|3.601|in the sequence
737.6|4.32|so if you want to predict the action at
739.68|4.24|this t minus one step we'll use
741.92|4.64|everything that came
743.92|6.24|at time step t minus 2
746.56|6.88|as well as the returns and states at
750.16|3.28|time step t minus 1.
754.24|4.08|so
756.48|4.4|we will go into the details of how
758.32|5.68|exactly each of these are encoded
760.88|5.44|uh but essentially this is uh in in a
764.0|4.72|one-liner it's taking the trajectory
766.32|5.04|data from the offline data treating it
768.72|4.4|as a sequence of tokens passing it
771.36|5.36|through a causal transformer and getting
773.12|4.959|a sequence of actions as the output
776.72|4.239|okay so
778.079|4.961|how exactly do we do the forward pass
780.959|3.361|through the network
783.04|4.64|uh so
784.32|4.319|one important aspect of this work which
787.68|2.0|is
788.639|3.841|we
789.68|4.959|use states actions and this quantity
792.48|4.4|called returns to go
794.639|4.481|so these are not direct rewards
796.88|4.0|uh these are returns to go and i'll and
799.12|3.6|let's see what they really
800.88|2.639|are mean
802.72|3.679|so
803.519|4.401|this is our trajectory that goes in good
806.399|3.68|to decision
807.92|4.88|and the returns to go
810.079|5.281|are the sum of rewards starting from the
812.8|5.039|current time step into
815.36|6.159|until the end of the episode
817.839|6.8|so really what we want the transformer
821.519|5.281|is to get better at using a target
824.639|3.841|return this is how you should think of
826.8|4.479|returns to go
828.48|4.159|as the input in deciding what action to
831.279|2.721|take
832.639|3.681|this perspective is going to have
834.0|4.16|multiple advantages it will allow us to
836.32|4.56|actually do much more than offline rl
838.16|5.679|and generalizing to different tasks
840.88|5.92|by just changing the returns to go
843.839|5.68|uh and here it's very important so at
846.8|4.56|time step one we will just have the
849.519|3.041|overall sum of rewards for the entire
851.36|4.159|trajectory
852.56|5.36|at time step two we subtract the reward
855.519|4.081|we get by taking the first action and
857.92|4.88|then have the sum of rewards for the
859.6|5.52|remainder of the trajectory
862.8|6.159|okay so uh that's how we call it returns
865.12|6.88|to go uh like how many more rewards
868.959|5.521|in in accumulation you need to acquire
872.0|5.04|uh to fulfill your
874.48|4.479|reward your return goal that you set
877.04|3.359|from the beginning
878.959|3.521|what is the output
880.399|3.761|the output is the sequence of predicted
882.48|2.88|actions
884.16|3.28|so
885.36|3.839|as i showed in the previous slide
887.44|3.199|we use the causal transformer so we'll
889.199|2.88|predict
890.639|4.481|in sequence
892.079|5.361|the desired actions
895.12|3.93|the attention
897.44|2.72|which is uh
899.05|2.469|[Music]
900.16|3.44|going to be computed inside the
901.519|4.401|transformer will take in an important
903.6|3.28|hyper parameter k which is the context
905.92|2.719|length
906.88|4.16|uh we see that in perception as well
908.639|4.32|here and for the rest of the talk i'm
911.04|4.64|going to use the notation k to denote
912.959|5.68|how many tokens in the past
915.68|6.159|would we be attending over to predict uh
918.639|5.841|the action at the current time step
921.839|5.44|okay so again uh
924.48|5.279|digging a little bit deeper into code
927.279|3.491|um there are some subtle differences
929.759|2.241|with how
930.77|3.309|[Music]
932.0|4.399|a decision transformer
934.079|3.68|operates as opposed to a normal
936.399|4.081|transformer
937.759|6.32|the first is that here the time step
940.48|3.599|notion is going to be
944.48|5.76|have a much bigger semantics that
946.88|4.079|extends across three tokens
950.24|3.12|so
950.959|3.44|in perception you just think about the
953.36|2.08|time step
954.399|3.761|per
955.44|5.36|word for instance like in nlp or per
958.16|4.64|patch for vision and in this case we
960.8|4.32|will have a time step
962.8|4.479|encapsulating three tokens one for the
965.12|3.76|states one for the actions and one for
967.279|4.0|the rewards
968.88|3.84|and then we'll embed each of these
971.279|3.041|uh
972.72|3.28|tokens and then add the position
974.32|3.12|embedding as it's common in the
976.0|5.12|transformer
977.44|5.28|and we feed those inputs to
981.12|3.6|the transformer
982.72|4.32|at the output we only care about one of
984.72|4.479|these three tokens in in this default
987.04|3.919|setup we i will show experiments where
989.199|4.241|even the other tokens might be of
990.959|3.921|interest as target predictions but for
993.44|3.44|now let's keep it simple we want to
994.88|3.759|learn a policy a policy which is trying
996.88|4.8|to predict actions
998.639|5.2|so when we try to decode we'll only be
1001.68|4.48|looking at the actions
1003.839|4.401|uh in from the hidden representation in
1006.16|4.16|the pre-final layer
1008.24|3.76|okay so this is the forward pass now
1010.32|2.639|what do we do with this network we train
1012.0|3.36|it
1012.959|4.32|how do we train it
1015.36|4.64|sorry just a quick question on semantics
1017.279|4.321|there uh if you go back one slide
1020.0|3.36|the the plus in this case the syntax
1021.6|2.959|means that you are actually adding the
1023.36|3.599|values element-wise and not
1024.559|5.76|concatenating them is that right
1026.959|3.36|that is correct okay
1033.439|3.841|okay so what's the last function um
1035.839|5.12|follow up on that i thought it was
1037.28|6.639|concur why are we just adding it
1040.959|2.96|sorry can you go back
1044.0|5.12|yeah i think it's it's a design choice
1046.4|4.639|you can continue it you can add it
1049.12|5.2|it leads to different functions being
1051.039|5.601|encoded in our case it's this edition
1054.32|2.32|okay
1056.96|4.8|why did you did you try the other one
1058.88|5.12|and it just didn't work or
1061.76|6.48|why is that because i think intuitively
1064.0|5.76|concatenating would like make more sense
1068.24|4.96|uh so
1069.76|5.2|i think both of them have different uh
1073.2|4.0|use cases for the functional encoding
1074.96|5.12|like one is really
1077.2|6.16|mixing in the embeddings for the state
1080.08|5.12|and basically shifting it so when you uh
1083.36|4.559|when you add something you if you think
1085.2|5.12|of the embedding of the states as
1087.919|5.041|a vector and you add something you are
1090.32|4.719|actually shifting it
1092.96|3.44|whereas in the concatenation case you
1095.039|3.921|are actually increasing the
1096.4|4.0|dimensionality of this space
1098.96|4.32|yeah
1100.4|4.639|so those are different choices which are
1103.28|4.48|doing very different things
1105.039|5.681|uh we found this one to be worked better
1107.76|4.88|i'm not sure i remember if the results
1110.72|3.92|were very significantly different if you
1112.64|4.64|would concatenate them but this is the
1114.64|4.08|one which uh we operate with
1117.28|2.639|but wouldn't there be because like if
1118.72|2.8|you're shifting it right like if you
1119.919|3.681|have an embedding for a state and let's
1121.52|5.12|say like you perform certain actions and
1123.6|5.52|you like end up at the same state again
1126.64|3.84|you would want these embeddings to be
1129.12|3.36|the same however now you're at a
1130.48|3.92|different time step so like you shifted
1132.48|3.199|it so wouldn't that be like harder to
1134.4|3.279|learn
1135.679|4.401|so there's this is there's a bigger an
1137.679|4.641|interesting question in that what you
1140.08|4.08|said is basically are we losing the
1142.32|4.479|markov property
1144.16|4.56|uh because as you said that
1146.799|5.521|if we come back to the same state at a
1148.72|4.64|different time step uh shouldn't we be
1152.32|3.44|uh
1153.36|5.12|have doing similar operations and the
1155.76|4.0|answer here is yes we are actually being
1158.48|3.36|non-markov
1159.76|4.64|and this might seem very non-intuitive
1161.84|4.24|at first that why are
1164.4|4.639|uh why is
1166.08|4.479|non-markovness important here
1169.039|3.841|uh and
1170.559|4.561|um i want to refer to another paper
1172.88|3.679|which came very much in conjunction with
1175.12|3.28|this attractive transformer that
1176.559|3.681|actually shows in more detail
1178.4|3.44|and it's basically say that if you were
1180.24|2.799|trying to predict the transition
1181.84|2.719|dynamics
1183.039|4.88|then you could have actually had a
1184.559|5.841|markovian system built in here which
1187.919|5.201|which would do just as good
1190.4|6.8|however for the perspective of
1193.12|6.4|uh trying to actually predict actions um
1197.2|4.8|it does help to look at the previous
1199.52|5.039|time steps even more so when you have
1202.0|5.2|missing observations so for instance if
1204.559|4.641|you have uh the observations being a
1207.2|4.88|substitute of the true state
1209.2|5.68|so looking at the previous states and
1212.08|4.56|actions helps you
1214.88|3.84|better fill in the missing pieces in
1216.64|4.399|some sense so this is commonly known as
1218.72|4.48|partial observability where you by
1221.039|3.921|looking at the previous tokens you can
1223.2|4.56|do a better job at
1224.96|6.079|predicting the actions you should take
1227.76|6.799|at the current uh time step
1231.039|5.681|so now non-markovness is on purpose
1234.559|4.721|uh and it's not intuitive
1236.72|5.439|uh but i think it's one of the things
1239.28|5.12|which separates this framework from
1242.159|4.161|existing ones
1244.4|4.48|so it will basically help you because
1246.32|4.08|like rl usually works on like infinite
1248.88|3.44|like it works better on like infinite
1250.4|3.68|horizon problems right so technically
1252.32|3.68|the way you formulate it it would work
1254.08|3.599|better on finite horizon problems i'm
1256.0|2.96|assuming because you want to take
1257.679|2.961|different actions based on like a
1258.96|4.959|history based on like given the fact
1260.64|5.36|that now you took a different timestamp
1263.919|3.76|yeah yeah so if you wanted to work on
1266.0|4.64|infinite verizon maybe something like
1267.679|6.321|this counting would work uh just as well
1270.64|4.399|to get that effect in this case we
1274.0|2.96|were
1275.039|4.241|using a discount factor of one or
1276.96|4.48|basically like notice standing at all
1279.28|4.32|uh but you're right if i think we really
1281.44|4.32|want to extend it to internet horizon we
1283.6|5.959|would need to change the discount factor
1285.76|3.799|okay thanks
1290.64|3.36|okay so
1292.4|2.96|good question
1294.0|2.799|oh
1295.36|3.199|i think it was just answered in chat but
1296.799|2.801|i'll ask it anyways um i think i might
1298.559|2.881|have missed this or maybe you're about
1299.6|3.68|to talk about it the offline data that
1301.44|4.0|was collected what policy was used to
1303.28|3.04|collect it
1305.44|3.76|uh
1306.32|4.239|so this is a very important question and
1309.2|3.28|it will
1310.559|4.561|be something i mentioned the experiments
1312.48|5.679|so we were using the benchmarks that
1315.12|4.72|exist for signal where essentially uh
1318.159|2.561|the way these benchmarks are constructed
1319.84|3.28|is
1320.72|4.959|you train an agent using online rl and
1323.12|4.08|then you look at its replay buffer at
1325.679|3.841|some time step
1327.2|4.8|so while it's training so while it's
1329.52|5.279|like a medium sort of expert you collect
1332.0|4.64|its trans uh the transitions it's
1334.799|4.0|experienced so far and make that as the
1336.64|2.88|offline data it's it's something which
1338.799|3.441|is
1339.52|5.84|like our framework is very agnostic to
1342.24|4.16|what offline data that you use so so i'm
1345.36|2.0|not discussing
1346.4|3.84|the car
1347.36|5.36|but something that uh in our experiments
1350.24|4.96|is based on traditional benchmarks
1352.72|3.839|got it so the reason i ask isn't i'm
1355.2|3.52|sure that your framework can accommodate
1356.559|3.441|any offline data but it seems to me like
1358.72|3.04|the results that you're about to present
1360.0|4.559|are going to be heavily contingent
1361.76|4.32|on what that that data collection policy
1364.559|5.201|is
1366.08|5.68|indeed indeed and also uh uh so so we
1369.76|4.32|will i think i have a slide where we
1371.76|4.56|show an experiment where the amount of
1374.08|4.64|data can make a difference
1376.32|3.599|in how we compare with baselines and
1378.72|3.439|essentially
1379.919|4.161|uh we will see how distant transformer
1382.159|3.121|especially shines when
1384.08|4.8|there is
1385.28|6.08|small amounts of offline data
1388.88|4.56|okay cool thank you
1391.36|4.559|okay great questions uh so let's let's
1393.44|4.56|go ahead so we have to find our model
1395.919|4.161|uh which is going to look at
1398.0|2.96|these trajectories
1400.08|2.959|um
1400.96|5.04|and now let's see how we train it
1403.039|5.201|uh so very simple uh we will we are
1406.0|3.919|trying to predict actions uh we'll try
1408.24|3.919|to match them to the ones we have in our
1409.919|4.24|data set if they're continuous using the
1412.159|4.64|mean squared error if they're discrete
1414.159|3.841|and we can use the cross entropy
1416.799|2.961|um
1418.0|2.72|so but there is something very deep in
1419.76|2.32|here
1420.72|3.68|for
1422.08|4.56|our research which is that
1424.4|4.24|these objectives are very stable to
1426.64|3.84|train and easy to regularize because
1428.64|3.519|they've been developed for supervised
1430.48|4.0|learning
1432.159|4.801|in contrast what arl is more used to is
1434.48|5.04|dynamic programming style objectives
1436.96|5.76|which are based on the bellman equation
1439.52|6.08|and those end up being much harder to
1442.72|5.439|optimize and scale and that's why you
1445.6|4.959|see a lot of the variants in the results
1448.159|2.4|as well
1450.96|4.079|okay so this is how we train the model
1453.039|3.841|now how do we use the model and that's
1455.039|4.161|the point about
1456.88|5.52|trying to do roll out for the model
1459.2|5.12|uh so here again uh this is going to be
1462.4|3.279|similar to doing an auto regressive
1464.32|3.68|generation
1465.679|4.641|um there was an important token here
1468.0|3.279|which was the returns to go
1470.32|3.28|and
1471.279|3.921|what we need to set during evaluation
1473.6|4.0|presumably we want
1475.2|4.959|uh expert level performance
1477.6|5.439|uh because that will have the highest uh
1480.159|4.241|returns so we set the initial returns to
1483.039|3.601|go
1484.4|3.36|uh not based on our trajectory because
1486.64|2.96|now we don't have a trajectory you're
1487.76|4.48|going to generate a transit tree so this
1489.6|4.959|is at inference time so we'll set it to
1492.24|4.4|the export return for instance
1494.559|3.921|so in code what this whole procedure
1496.64|4.0|would look like is basically
1498.48|4.88|you said this returns to go token to as
1500.64|6.08|some target return
1503.36|5.919|and you set your initial state to
1506.72|4.959|one of uh run from the environment
1509.279|4.561|distribution of initial states
1511.679|4.161|uh and then you just roll out your trans
1513.84|4.319|decision transformer
1515.84|4.48|so you get a new action
1518.159|4.961|uh this action will also give you a
1520.32|5.76|state and reward from the environment
1523.12|3.84|you append them to your sequence
1526.08|3.12|and
1526.96|4.719|you get a new returns to go
1529.2|3.68|and you take just the context and keep
1531.679|3.441|because that's what's used by the
1532.88|3.679|transformer to making predictions and
1535.12|3.12|then feed it back to the distance
1536.559|3.841|transformer
1538.24|3.52|so it's it's regular auto regressive
1540.4|4.0|generation
1541.76|4.88|but the only key point to notice is how
1544.4|5.68|you initialize the
1546.64|5.919|uh the transformer for rl
1550.08|4.079|uh sorry to have one question here
1552.559|2.641|so how much does the choice of the
1554.159|2.481|export
1555.2|2.88|mattered is it does it have to be like
1556.64|2.56|the mean expert reward or can it be like
1558.08|2.16|the maximum reward possible in
1559.2|2.56|department
1560.24|3.2|like does the choice of the number
1561.76|2.399|really matter
1563.44|2.719|uh
1564.159|6.321|that's a very good question so we
1566.159|6.161|generally uh would set it to be
1570.48|5.36|slightly higher than
1572.32|5.76|the max return in the data set
1575.84|4.079|so i think the factor we used was 1.1
1578.08|4.4|times
1579.919|4.721|but i think we have done
1582.48|3.12|a lot of experimentation
1584.64|2.96|um
1585.6|4.8|in the range and
1587.6|3.679|it's fairly robust to what choice you
1590.4|3.04|use
1591.279|4.88|uh so for example for hopper expert
1593.44|4.96|returns about 3 600 and we have found
1596.159|4.52|very stable performance from
1598.4|5.519|all the way from like
1600.679|7.0|35 30 400 to even going to very high
1603.919|5.521|numbers like 5000 it it works
1607.679|2.561|um
1609.44|4.32|yeah
1610.24|6.319|uh so uh however i would want to point
1613.76|4.399|out that this is something which is not
1616.559|3.281|typically needed
1618.159|4.481|in regular rl
1619.84|4.8|uh like knowing the export return here
1622.64|4.08|we are actually going beyond regular rl
1624.64|3.68|and that we can choose a return we want
1626.72|3.68|so we also actually need this
1628.32|4.239|information about what the export return
1630.4|2.159|is
1633.039|2.561|at desktop
1635.919|3.601|there's another value
1638.399|2.0|yes
1639.52|3.279|so
1640.399|4.561|yeah it's just that you're it cannot be
1642.799|4.561|on the regular aisle but i i'm just
1644.96|5.36|about to also like
1647.36|4.4|restrict this framework to only offline
1650.32|2.56|io because
1651.76|3.36|if you wanna
1652.88|3.76|run this kind of framework in online
1655.12|4.88|area you'll have to
1656.64|5.44|determine the returns to go aprily
1660.0|4.96|so this kind of remote i think it's kind
1662.08|5.04|of restricted to only offline aisle do
1664.96|5.199|you think so
1667.12|4.88|uh yes and i i think uh
1670.159|2.721|asking this question as well earlier
1672.0|3.12|that
1672.88|4.64|yes i think for now this is the first
1675.12|4.96|book so we were focusing on offline rl
1677.52|6.32|where this information can be gathered
1680.08|3.76|from the offline data set
1684.48|3.6|it is
1685.6|4.959|possible to think about strategies on
1688.08|4.8|how you can even get this online uh what
1690.559|5.041|you'll need is a curriculum so early on
1692.88|4.24|during training as you're gathering data
1695.6|3.28|you will set
1697.12|4.4|when when you're doing rollouts you will
1698.88|4.64|set your export return to whatever you
1701.52|3.2|see in the data set
1703.52|3.68|and then
1704.72|4.4|increment it as in when you start seeing
1707.2|3.68|that the transformer can actually exceed
1709.12|3.439|that performance
1710.88|4.64|so you can think of specifying a
1712.559|5.6|curriculum from slow to high for what
1715.52|4.8|that expert return could be for with
1718.159|3.681|which you roll out there are
1720.32|2.52|trans the
1721.84|4.959|decision
1722.84|3.959|transformer i say cool thank you
1728.0|5.12|so yeah this was about the model so we
1730.08|4.079|discussed um how this model
1733.12|1.84|uh
1734.159|2.481|is
1734.96|3.599|what the input to these models are what
1736.64|4.48|the outputs are what the loss function
1738.559|5.84|is used for training this model and how
1741.12|7.12|do we use this model at test time
1744.399|6.0|uh there is a connection to
1748.24|5.439|uh this framework as being one way to
1750.399|5.121|instantiate what is often known as rl as
1753.679|4.48|probabilistic inference
1755.52|4.0|so we can formulate rl as a graphical
1758.159|3.441|model problem
1759.52|5.2|where you have
1761.6|5.6|the states and actions being used to
1764.72|4.959|determine what the next state is
1767.2|3.92|and to encode a notion of optimality
1769.679|4.401|typically you would also have these
1771.12|5.36|additional auxiliary variables one o2
1774.08|4.16|and so on and forth which are implicitly
1776.48|4.559|saying that
1778.24|4.88|encoding some notion of reward and
1781.039|3.12|conditioned on this optimality being
1783.12|4.48|true
1784.159|6.721|uh rl is the task of learning a policy
1787.6|5.12|uh which is the mapping from
1790.88|2.96|states to actions
1792.72|3.76|such that
1793.84|4.16|we get optimal behavior
1796.48|3.28|and
1798.0|4.24|if you really squint your eyes you can
1799.76|4.399|see that these optimality variables and
1802.24|3.28|decision transformers
1804.159|3.201|are actually being encoded by the
1805.52|3.92|returns to go
1807.36|4.4|so if when we give
1809.44|5.599|a value that's high enough at test time
1811.76|4.799|during rollouts like the expert return
1815.039|4.0|we are essentially saying that
1816.559|4.281|conditioned on this being
1819.039|4.481|the
1820.84|4.36|mathematical uh form quantification of
1823.52|3.68|optimality
1825.2|4.079|uh roll out your discipline transformer
1827.2|6.0|to hopefully satisfy
1829.279|3.921|uh this can this this condition
1833.44|3.92|uh so um
1835.679|3.761|yeah so this was all i want to talk
1837.36|3.52|about the model can you explain that
1839.44|3.359|please
1840.88|4.08|what do you mean by optimality variables
1842.799|5.041|in the decision transformer and how do
1844.96|6.56|you mean like return to go
1847.84|5.36|right so optimality variables um
1851.52|3.279|we can think in the most simplest
1853.2|3.839|context as
1854.799|4.161|uh let's just say they were binary so
1857.039|3.601|one is if you
1858.96|4.079|solve the goal and zero is if you did
1860.64|6.399|not solve the goal
1863.039|5.76|and what basically in that case
1867.039|4.0|you could also think of
1868.799|3.36|your decision transformer
1871.039|4.081|as
1872.159|4.161|a test time and we encode the returns to
1875.12|3.36|go
1876.32|3.68|uh we could set it to one which would
1878.48|2.319|basically mean
1880.0|3.279|that
1880.799|4.0|conditioned on optimality so optimality
1883.279|4.88|here means
1884.799|6.801|uh solving the goal as one
1888.159|5.841|generate me the sequence of actions such
1891.6|4.72|that this would be true
1894.0|3.44|of course our learning is not perfect so
1896.32|3.12|it's not
1897.44|4.16|guaranteed we'll get that
1899.44|3.119|but we have trained the transformer in a
1901.6|3.52|way
1902.559|5.761|to interpret the returns to go as some
1905.12|3.2|notion of optimality
1909.039|2.561|so is it is it
1910.399|3.361|if i'm interpreting this correctly it's
1911.6|4.72|roughly like saying
1913.76|4.32|show me what an optimal sequence of
1916.32|3.04|transitions look like
1918.08|2.8|because you've learned the model has
1919.36|3.76|learned sort of both successful and
1920.88|4.159|unsuccessful transitions
1923.12|4.24|exactly exactly okay
1925.039|5.281|and as we have seen some experiments we
1927.36|5.36|can uh for for the for the binary case
1930.32|4.8|it's either optimal or non-optimal but
1932.72|4.319|really this can be a continuous variable
1935.12|4.08|which it is in our experiment so we can
1937.039|4.961|also see what happens in between
1939.2|2.8|experimentally
1942.559|4.72|okay so let's jump into the experiments
1946.24|2.799|um
1947.279|2.721|so there are a bunch of experiments and
1949.039|2.801|i've
1950.0|3.12|picked out a few which i think are
1951.84|2.959|interesting
1953.12|2.72|and give the key
1954.799|3.041|um
1955.84|4.079|results in the paper but feel free to
1957.84|3.52|reference the paper for an even more
1959.919|3.441|detailed analysis on some of the
1961.36|2.72|components of our model
1963.36|1.919|so
1964.08|3.76|um
1965.279|4.801|this uh so first we can look at how well
1967.84|4.24|does it do an offline rl so there are
1970.08|2.88|benchmarks for
1972.08|2.8|uh
1972.96|5.199|the atari suite of environments and the
1974.88|4.639|open air gym and we have another
1978.159|3.36|environment key to door which is
1979.519|3.76|especially hard because it contains
1981.519|3.441|sparse rewards and requires you to do
1983.279|2.801|credit assignment that i'll talk about
1984.96|3.839|later
1986.08|5.92|but across the board we see that
1988.799|5.441|decision transformer is competitive with
1992.0|4.88|uh the state-of-the-art model free
1994.24|5.36|offline rl methods in this case this was
1996.88|4.399|a version of q learning uh designed for
1999.6|2.88|offline rl
2001.279|2.321|and
2002.48|3.6|it can do
2003.6|4.16|excellent when especially when there is
2006.08|3.68|long-term credit assignment where
2007.76|4.24|traditional methods based on
2009.76|4.24|td learning would fail
2012.0|4.88|uh yeah so the takeaway here should not
2014.0|4.799|be that uh we should we are at the stage
2016.88|4.0|where we can just substitute
2018.799|4.401|uh the existing algorithms for the
2020.88|5.2|decision transformer but this is a very
2023.2|5.28|strong evidence in favor that this
2026.08|5.839|paradigm which is building on
2028.48|5.679|transformers will permit us to better
2031.919|4.961|iterate and improve the models to
2034.159|5.281|hopefully surpass
2036.88|4.32|the existing algorithms uniformly and
2039.44|3.68|there's some early evidence of that in
2041.2|3.52|hard environments which do require
2043.12|3.2|credit assign long-term credit
2044.72|4.399|assignment
2046.32|5.44|okay can i ask a question here about uh
2049.119|4.161|the baseline specifically td learning
2051.76|3.44|i'm curious to know because i know that
2053.28|4.399|a lot of td learning agents are feed
2055.2|5.879|forward networks are these baselines do
2057.679|3.4|they have recurrence
2061.44|4.239|yeah yeah so i think the conservative q
2063.839|4.401|learning baselines here
2065.679|5.2|we did have recurrence but um
2068.24|6.639|i'm not very sure so i can check back on
2070.879|4.0|this offline and get back on this
2075.28|3.359|okay
2076.32|2.319|thank you
2079.76|4.879|also another quick question so uh just
2082.32|4.319|how exactly do you evaluate the decision
2084.639|4.96|transformer here in the experiment so
2086.639|5.921|because you need to supply the returns
2089.599|5.601|to go so then use the optimal
2092.56|5.44|like policy to get what's optimal
2095.2|4.72|rewards and speed yes so here we
2098.0|5.52|basically look at the offline data set
2099.92|5.76|that is used for training and we said um
2103.52|5.28|whatever was the maximum return in the
2105.68|6.399|offline data we set the
2108.8|5.44|uh desired target return to go as
2112.079|5.841|uh slightly higher than that so one
2114.24|6.64|point one involved coefficient we used
2117.92|5.36|i see so uh and the performance sorry
2120.88|4.239|i'm not really well versus or else but
2123.28|4.079|how is the performance defined here just
2125.119|5.281|like is it how much reward you get
2127.359|4.961|actually from the yes yes so
2130.4|4.0|you can specify a target return to go
2132.32|4.16|but there's no guarantee that
2134.4|5.04|the actual actions
2136.48|4.8|that you take will achieve that return
2139.44|4.0|uh so yeah
2141.28|4.88|so you actually you measure the true
2143.44|5.12|environment you're doing basically yeah
2146.16|4.56|i see it but then like just curious like
2148.56|4.64|so what's uh so are these performance
2150.72|3.28|the percentage you get like uh
2153.2|2.24|for
2154.0|3.28|like how much i guess reward do you
2155.44|3.6|recover from
2157.28|3.44|actually involved yeah so these are not
2159.04|3.12|percentages these are some we have
2160.72|5.04|normalizing the return so that
2162.16|6.16|everything was between zero hundred um
2165.76|4.8|yeah yeah i see then uh just wonder if
2168.32|3.2|you have a like a rough idea about how
2170.56|3.12|much
2171.52|4.4|like reward actually is recovered by
2173.68|4.399|decision transformers like does it say
2175.92|5.12|like if you specify i want to get like
2178.079|5.52|50 rewards does he get 49 or is this
2181.04|4.64|even better sometimes or
2183.599|3.52|uh that's an excellent question and my
2185.68|2.88|next slide
2187.119|4.24|i see thanks
2188.56|4.64|uh so here uh we're gonna answer
2191.359|4.961|precisely this question that was asked
2193.2|4.96|is like if you feed in the target return
2196.32|4.0|it could be exploded it could also not
2198.16|4.56|be expert how well does the mall
2200.32|3.2|actually do in attaining it
2202.72|4.24|so
2203.52|5.839|the x-axis is what we specify as the
2206.96|5.28|target return we want
2209.359|5.681|and the y-axis is basically
2212.24|5.28|how much how well do we actually get
2215.04|4.96|uh for reference we have this green line
2217.52|4.4|which is the article so which means
2220.0|3.359|whatever you desire the crystalline
2221.92|3.6|transformer gives it to you so this
2223.359|3.441|would have been the ideal case so it's a
2225.52|2.319|diagonal
2226.8|3.76|um
2227.839|4.721|we also have because this is offline rl
2230.56|5.12|we have in orange
2232.56|6.559|uh what it was the best trajectory data
2235.68|6.32|set so the offline data is not perfect
2239.119|4.72|um uh so we just plot what is the upper
2242.0|4.079|bound on the offline
2243.839|3.121|data performance
2246.079|2.641|and
2246.96|4.8|here we find that
2248.72|4.16|um for the majority of the environments
2251.76|4.319|there is
2252.88|4.88|a good fit between the target return we
2256.079|3.441|feed in and the actual performance of
2257.76|4.24|the model
2259.52|4.64|and there are some other
2262.0|5.599|observations which
2264.16|5.52|i wanted to take from this slide is that
2267.599|3.361|because we can vary this notion of
2269.68|5.04|reward
2270.96|6.399|uh we can in some sense do multitask rl
2274.72|4.56|by reward condition return conditioning
2277.359|4.24|this is not the only way to do multitask
2279.28|4.799|rl you can specify a task via natural
2281.599|5.201|language you can buy a gold state and so
2284.079|4.721|on forth but this is one notion where
2286.8|4.16|the notion of a task could be how much
2288.8|4.08|reward you want
2290.96|3.6|um
2292.88|3.92|and another thing to notice is
2294.56|3.84|occasionally the smallest extrapolate
2296.8|4.16|this is not a trend we have been seeing
2298.4|6.16|consistently but we do see some signs of
2300.96|7.36|it so if you look at for example sequest
2304.56|6.24|uh here the highest return trajectory in
2308.32|4.88|a data set was pretty low
2310.8|3.76|and if we specify a return higher than
2313.2|4.399|that
2314.56|6.4|for our decision transformer we do find
2317.599|6.721|that the model is able to achieve
2320.96|5.44|so it is able to generate trajectories
2324.32|3.84|uh with returns higher than it ever saw
2326.4|3.52|in the days
2328.16|4.64|um
2329.92|4.64|i i do believe that future work in this
2332.8|4.24|space trying to improve this model
2334.56|4.88|should should think about um
2337.04|4.16|how can this trend be more consistent
2339.44|4.24|across environments because this would
2341.2|5.6|really achieve the goal of alpine rl
2343.68|4.96|which is given sub-optimal behavior
2346.8|3.2|how do you get optimum behavior out of
2348.64|3.52|it
2350.0|4.079|that remains to be seen how well this
2352.16|3.76|trend can be made consistent across
2354.079|3.921|environments
2355.92|3.04|can i jump in with a question
2358.0|2.8|yes
2358.96|3.28|so i i think that last point is really
2360.8|3.84|interesting and it's cool that you guys
2362.24|4.4|occasionally see it um
2364.64|3.84|i'm curious to know what happens so this
2366.64|4.16|is all condition you you give as an
2368.48|3.84|input what return you would like and it
2370.8|3.039|tries to select a sequence of actions
2372.32|3.2|that gives it i'm curious to know what
2373.839|4.401|happens if you just give it ridiculous
2375.52|4.4|inputs like um for example you know here
2378.24|3.52|here the order of magnitude for the
2379.92|4.8|return is like 50 to 100 what happens if
2381.76|4.96|you put in 10 000
2384.72|4.56|uh good question and this is something
2386.72|4.48|we tried early on um
2389.28|3.76|i don't want to say if we went up to 10
2391.2|4.08|000 but we try like really high returns
2393.04|3.76|which not even an expert would get and
2395.28|3.76|generally we see this leveling
2396.8|4.0|performance so you can see hints of it
2399.04|2.96|in half cheetah
2400.8|3.68|and
2402.0|3.839|you know pong as well or
2404.48|4.879|walker to some extent like if you look
2405.839|7.681|at the very end things start saturating
2409.359|6.081|so if you exceed what uh is like
2413.52|3.52|um certain threshold which often
2415.44|3.52|corresponds with the best trajectory
2417.04|4.16|threshold but not always
2418.96|3.68|beyond that everything is similar
2421.2|3.76|returns so
2422.64|3.679|it's not that it so at least one good
2424.96|3.119|thing is it does not degrade in
2426.319|3.681|performance so it would have been a
2428.079|4.24|little bit worrying if you specified a
2430.0|3.68|return of 10 000 and gives you a return
2432.319|4.721|which is
2433.68|5.679|20 or something really low
2437.04|4.48|uh so it is it's good that it stabilizes
2439.359|4.561|but it's not that it keeps increasing on
2441.52|5.599|and on so there there would be a point
2443.92|4.88|where the performance will get saturated
2447.119|3.2|okay thank you
2448.8|2.72|uh i was just curious like so usually
2450.319|3.601|for transfer models you need a lot of
2451.52|3.92|data so do you know how well like uh
2453.92|2.88|like how much data do you need like how
2455.44|2.399|to where does it scale with data the
2456.8|3.36|performance
2457.839|4.161|submission transformer yeah so here we
2460.16|4.48|use uh
2462.0|3.76|uh the standard um
2464.64|4.24|um
2465.76|5.04|data like the d4 rl benchmarks for
2468.88|4.8|which i think have million uh
2470.8|4.16|transitions in the order of millions
2473.68|3.28|for
2474.96|4.48|um
2476.96|6.08|atari we used one percent of the replay
2479.44|5.2|buffer which is smaller than the one we
2483.04|2.559|used for
2484.64|4.24|um
2485.599|5.841|the the major benchmarks and i actually
2488.88|3.84|have a result in the very next slide
2491.44|3.44|which shows
2492.72|3.599|um
2494.88|3.199|decision transformer especially being
2496.319|4.641|useful when you have
2498.079|2.881|a little data
2501.2|1.84|so
2502.0|3.599|uh
2503.04|4.24|yeah so i guess one question to ask
2505.599|4.641|before you move on
2507.28|4.88|um in the last slide uh what do you mean
2510.24|4.72|again by return conditioning for the
2512.16|4.72|multitask part
2514.96|4.56|yeah so if you think about the returns
2516.88|6.4|to go at test time the one you feel have
2519.52|4.559|to feed in as the starting token
2523.28|2.64|um
2524.079|3.52|as one way of
2525.92|2.88|specifying
2527.599|4.24|uh
2528.8|4.48|what policy you want
2531.839|3.601|why
2533.28|4.559|how is that multi-task
2535.44|4.24|so it's multi-task in the sense that
2537.839|4.081|uh because you can get different
2539.68|3.2|policies by changing your target return
2541.92|2.96|to go
2542.88|4.239|you're essentially getting different
2544.88|4.32|behaviors encoded so think about for
2547.119|4.801|instance a hopper and you specify a
2549.2|4.72|return to go that's really low
2551.92|4.64|so you're basically saying
2553.92|4.72|get me an agent which will just stick
2556.56|4.88|around its initial state
2558.64|7.04|and not go into unchartered
2561.44|6.48|unchartered um territory
2565.68|3.76|and if you give it really really high
2567.92|2.88|then you're asking it to do the
2569.44|4.48|traditional
2570.8|5.039|task which is to hop and go as far as
2573.92|3.919|possible without falling
2575.839|4.161|can you qualify those multitasks because
2577.839|5.76|that basically just means that your
2580.0|6.4|return conditioning is a cue for it to
2583.599|6.401|memorize right which is usually like one
2586.4|3.6|of the pitfalls of multi-task
2590.56|6.32|uh so i'm not sure it's a task
2593.119|3.761|identifier that's what i'm trying to say
2597.359|4.801|uh so i'm not sure if it's memorization
2600.72|2.56|uh because
2602.16|5.76|uh
2603.28|6.799|like i think the purpose of this uh
2607.92|3.84|i mean have like having an offline data
2610.079|2.561|set that's fixed is basically saying
2611.76|1.68|that
2612.64|3.12|it's
2613.44|4.0|very very specific to if you had the
2615.76|3.76|same start state
2617.44|4.399|and you took the same actions and you
2619.52|4.96|had the same target returns
2621.839|4.961|that would qualify as memorization
2624.48|3.839|but here at test time we allow all of
2626.8|3.12|these things to change
2628.319|3.681|and in fact they do change so your
2629.92|3.04|initial state would be different
2632.0|2.64|your
2632.96|3.68|target return
2634.64|4.24|uh which could be very could be a
2636.64|3.84|different scalar than one you ever saw
2638.88|3.52|during training
2640.48|3.119|uh it uh
2642.4|4.8|yeah and
2643.599|5.52|uh so essentially the model has to learn
2647.2|4.56|to generate that behavior starting from
2649.119|4.24|a different initial state and maybe a
2651.76|2.8|different value of the target return
2653.359|2.24|than it saw
2654.56|2.32|during
2655.599|3.361|um
2656.88|4.08|during training if the dynamics are
2658.96|3.92|stochastic that also makes so that even
2660.96|3.84|if you memorize the actions you're not
2662.88|2.88|guaranteed to get the next the same next
2664.8|2.0|state
2665.76|2.319|so
2666.8|3.039|you would actually have a bad
2668.079|5.441|correlation with the performance if the
2669.839|3.681|dynamics are also stochastic
2675.359|2.96|uh also was very curious how much time
2677.04|2.48|does it take to train distant
2678.319|2.561|transformer
2679.52|5.839|in general
2680.88|7.959|so it takes about a few hours uh so
2685.359|6.321|um i want to stay like uh
2688.839|5.48|about to five hours
2691.68|4.24|uh depending on what quality gpu you use
2694.319|6.081|but yeah that's that's
2695.92|4.48|a reasonable estimate yep got it thanks
2703.52|5.92|okay so uh actually while doing this
2705.839|6.0|experiment uh this project we thought of
2709.44|4.32|a baseline which we were surprised it's
2711.839|3.52|not there in previous literature on
2713.76|4.16|offline rl but
2715.359|3.841|makes very much sense and uh we thought
2717.92|2.96|we should also think about whether the
2719.2|3.76|decision transformer is actually doing
2720.88|3.92|something very similar to that baseline
2722.96|3.92|and the baseline is what we call as
2724.8|3.68|person behavioral cloning
2726.88|4.4|so behavioral cloning what it does is
2728.48|4.8|basically it ignores the returns
2731.28|3.039|and simply imitates
2733.28|2.0|the
2734.319|3.04|agent
2735.28|3.839|by looking by just trying to map the
2737.359|4.801|actions uh
2739.119|3.841|given the current states
2742.16|3.28|um
2742.96|4.48|this is not a good idea with an offline
2745.44|5.28|data set which will have trajectories of
2747.44|5.6|both low returns and high returns
2750.72|4.8|so traditional behavior cloning it's
2753.04|5.36|common to see that as a baseline in
2755.52|4.799|offline rl methods and
2758.4|3.36|it is unless you have a very high
2760.319|3.681|quality data set
2761.76|3.839|it does this is not a good baseline for
2764.0|4.079|offline rl
2765.599|4.72|however there is a version that we call
2768.079|5.201|as person bc which actually makes quite
2770.319|5.76|a lot of sense and in this version
2773.28|4.319|we filter out the top trajectories from
2776.079|3.841|our offline data set
2777.599|4.24|one stop the ones which have the highest
2779.92|3.76|rewards you know the rewards
2781.839|3.841|for each transition you calculate the
2783.68|3.919|returns of the trajectories and you take
2785.68|2.96|the trajectories with the highest
2787.599|3.681|returns
2788.64|4.479|um and keep a certain percentage of them
2791.28|3.92|which is going to be hyper parameter
2793.119|4.641|here
2795.2|4.159|and once you keep those top fraction of
2797.76|4.0|your trajectories
2799.359|5.681|you then just ask your model
2801.76|3.28|to imitate them
2805.2|3.68|which
2806.079|4.401|so imitation learning also uses
2808.88|4.08|especially when it's used in the form of
2810.48|4.0|behavioral cloning it uses supervised
2812.96|3.04|learning essentially it's a supervised
2814.48|3.76|learning problem so you could actually
2816.0|4.48|also get supervised learning
2818.24|5.04|objective functions if you did this
2820.48|2.8|filtering step
2823.52|4.4|so
2825.04|5.039|and what we find uh actually that for
2827.92|3.76|the moderate and high data regimes the
2830.079|3.441|decent transform is actually very
2831.68|3.84|comparable to push and pc so it's a very
2833.52|3.76|strong baseline which i think all of
2835.52|2.799|future work in offline rls should
2837.28|4.0|include
2838.319|4.641|there's actually an iclear submission
2841.28|3.76|from last week which
2842.96|3.68|has a much more detailed analysis on
2845.04|3.279|just this baseline that we introduced in
2846.64|2.8|this paper
2848.319|3.361|and
2849.44|4.879|uh what we do find is that for low data
2851.68|4.48|regimes the decision transformer does
2854.319|3.681|much better than person behavior cloning
2856.16|2.88|so this is for the atari benchmarks
2858.0|3.28|where
2859.04|4.24|like i previously mentioned we have a
2861.28|4.16|much smaller data set
2863.28|4.96|as compared to the mojoku
2865.44|3.6|uh environments and here we find that
2868.24|2.56|for
2869.04|3.6|even after varying the different
2870.8|3.2|fraction of the percentage hyper
2872.64|3.28|parameter here
2874.0|3.44|we are generally not able to get the
2875.92|3.439|strong performance that a resident
2877.44|2.8|transformer gets
2879.359|3.841|um
2880.24|4.64|so 10 bc basically means that we filter
2883.2|3.2|out and keep the top 10 percent of the
2884.88|2.479|trajectories
2886.4|2.719|if you go
2887.359|3.76|even lower then the star data set
2889.119|3.521|becomes very small so the baseline will
2891.119|4.561|become meaningless
2892.64|4.88|uh but for even the reasonable ranges we
2895.68|3.76|never find the performance matching that
2897.52|5.28|of different transformers
2899.44|3.36|for these atari benchmarks
2903.359|2.401|uh
2904.24|4.0|uh if i may
2905.76|3.76|um so i notice in table three for
2908.24|3.119|example which is not this table with one
2909.52|4.4|just before in the paper
2911.359|4.72|there's a report on the cql performance
2913.92|4.72|which to me also feels you know
2916.079|4.801|intuitively pretty similar to the
2918.64|3.6|percent bc in the sense of like you pick
2920.88|3.439|trajectories you know performing well
2922.24|4.599|and you try and stay roughly within sort
2924.319|4.481|of the same kind of uh policy
2926.839|3.641|distribution um
2928.8|2.88|and state space distribution
2930.48|2.639|uh
2931.68|3.2|i was i was curious on this one do you
2933.119|3.921|have a sense of what the cql performance
2934.88|5.199|was relative to say
2937.04|5.039|um the percent bc performance here
2940.079|3.441|uh so that's a great question so the
2942.079|2.24|question is that
2943.52|3.68|uh
2944.319|4.24|even for cql you rely on this notion of
2947.2|2.159|pessimism
2948.559|3.52|where
2949.359|4.801|you want to pick trajectories where
2952.079|4.641|you're more confident in and try to make
2954.16|5.36|sure policy remains in that region
2956.72|3.68|uh so i don't have the numbers of secret
2959.52|2.799|on
2960.4|4.64|this table but if you look at the
2962.319|3.76|detailed results for atari
2965.04|3.68|uh
2966.079|4.321|then i think uh
2968.72|4.0|they should they should have the secret
2970.4|4.959|for sure uh because that's the numbers
2972.72|3.839|we are reporting
2975.359|3.041|here
2976.559|3.76|so i can tell you what the secret
2978.4|4.08|performance is actually pretty good and
2980.319|6.24|it's very competitive
2982.48|6.32|with the decision transformer for atari
2986.559|4.401|so this uh td learning
2988.8|3.279|baseline here is secret
2990.96|2.96|uh so
2992.079|4.76|naturally by extension i would imagine
2993.92|5.6|it doing better than person bc
2996.839|4.52|yeah and i apologize if this was
2999.52|3.039|mentioned i just missed it but
3001.359|3.041|do you have the sense that this is
3002.559|4.241|basically like a failure of cql to be
3004.4|4.4|able to extrapolate well or sort of
3006.8|3.519|um stitch together different parts of
3008.8|3.279|trajectories
3010.319|3.361|uh whereas the decision transformer can
3012.079|2.961|sort of make that extrapolation between
3013.68|2.8|you have like the first half of one
3015.04|2.72|projector is really good the second half
3016.48|2.4|which one trajectory is really good so
3017.76|2.24|you can actually piece those together
3018.88|3.439|decision transformer where you can't
3020.0|3.44|necessarily do that with cql because the
3022.319|3.361|path connecting those may not
3023.44|4.48|necessarily be well covered by the
3025.68|4.96|behavior policy
3027.92|4.96|yeah yeah so uh and this uh this
3030.64|4.16|actually goes uh to one of the
3032.88|3.92|intuitions which um
3034.8|4.48|i i did not emphasize too much but we
3036.8|4.799|have a discussion on the paper where
3039.28|4.64|essentially why do we expect a
3041.599|4.561|transformer or any wall for that matter
3043.92|5.199|to look at offline data that's
3046.16|5.04|sub-optimal and get something a policy
3049.119|4.161|which generates optimal rollouts
3051.2|3.44|the intuition is that
3053.28|4.319|as
3054.64|5.04|scott was mentioning you could perhaps
3057.599|4.48|stitch together
3059.68|4.24|uh good behaviors from sub-optimal
3062.079|4.48|trajectories and that stitching could
3063.92|3.919|perhaps lead to a behavior that was
3066.559|4.321|better than anything you saw in
3067.839|4.401|individual trajectories in your data set
3070.88|5.12|uh it's
3072.24|4.56|something we find early evidence of in a
3076.0|2.72|you know
3076.8|3.519|small scale experiment for
3078.72|4.24|graphs
3080.319|4.481|and that's really our hope also that
3082.96|3.119|something that the transformer is very
3084.8|3.2|good at
3086.079|4.881|uh because it can attend to very long
3088.0|5.2|sequences so it could identify those
3090.96|3.04|segments of behavior
3093.2|2.56|which
3094.0|2.88|uh when stitched together would give you
3095.76|2.079|optimal
3096.88|4.239|uh
3097.839|3.28|optimal behavior
3101.359|5.361|so um
3103.28|4.72|and and and it's very much possible that
3106.72|4.72|is something unique to this in
3108.0|5.28|transformers and something like cql
3111.44|4.159|would not be able to do person bc
3113.28|4.48|because it's filtering out the data
3115.599|4.161|is automatically being limited and not
3117.76|4.079|being able to do that because the
3119.76|3.839|segments of good behavior could be in
3121.839|4.0|trajectories which overall do not have a
3123.599|2.96|high return but so if you filter them
3125.839|4.641|out
3126.559|3.921|you are losing all of that information
3133.359|5.441|okay so i said there is a hyper
3135.52|4.24|parameter the context and k and uh like
3138.8|3.44|with
3139.76|4.799|most of perception one of the big
3142.24|4.96|advantages of transformers as opposed to
3144.559|4.321|other sequence models like lstms is that
3147.2|3.28|they can process very
3148.88|4.56|large sequences
3150.48|5.2|um and here
3153.44|4.08|uh at a first glance it might seem that
3155.68|3.12|being markovian would have been helpful
3157.52|3.2|for rl
3158.8|4.0|uh which also was a question that was
3160.72|3.599|raised earlier uh so we did this
3162.8|4.0|experiment where we did compare
3164.319|3.681|performance with context and k equals
3166.8|2.64|one
3168.0|2.48|and here
3169.44|2.96|we had
3170.48|5.52|context spent between
3172.4|6.159|uh 30 for the environments and 54 pound
3176.0|6.96|and we find that increasing the context
3178.559|7.201|length is is very very important to get
3182.96|2.8|good performance
3189.359|4.081|okay
3191.52|2.88|now
3193.44|4.399|so so
3194.4|6.08|so far i've i've showed you um how
3197.839|3.52|this in transformer which is very simple
3200.48|2.879|uh
3201.359|4.321|there was no slide i had which was going
3203.359|5.281|into the details of dynamic programming
3205.68|5.52|which just which is the crux of most rl
3208.64|4.88|uh this is just pure supervised learning
3211.2|4.639|in an auto regressive framework that was
3213.52|4.48|getting us as good performance
3215.839|5.841|um
3218.0|6.0|what about uh cases where this approach
3221.68|5.36|actually starts outperforming
3224.0|5.04|some of the traditional methods or
3227.04|3.44|so to probe a little bit further we
3229.04|3.12|started looking at sparse reward
3230.48|4.32|environments and
3232.16|5.04|uh basically we just took our existing
3234.8|5.36|mojoque environments and then
3237.2|4.96|instead of giving it the information for
3240.16|3.84|reward for every transition
3242.16|3.84|we fed it the cumulative reward at the
3244.0|3.599|end of the trajectory so every
3246.0|3.359|transition will have a zero reward
3247.599|3.281|except the very end where you get the
3249.359|3.081|entire reward at once so it's a very
3250.88|2.959|sparse reward perform
3252.44|3.399|[Music]
3253.839|4.961|scenario for that reason
3255.839|2.961|and here we find that
3259.119|6.641|compared to the original dense
3261.359|6.48|results the delayed uh results for dt
3265.76|4.319|they will deteriorate a little bit which
3267.839|3.921|is expected because now you are
3270.079|3.361|withholding some of the more
3271.76|3.76|fine-grained information at every time
3273.44|3.119|step but the drop is
3275.52|3.039|uh
3276.559|4.56|not too significant compared to the
3278.559|4.721|original dt performance here
3281.119|4.561|whereas for something like cql there is
3283.28|5.44|a drastic drop in performance
3285.68|5.28|so cql suffers quite a lot in sparse
3288.72|5.359|rewards there are new scenarios
3290.96|5.04|uh but the decision transformer does not
3294.079|3.361|and uh just for completeness you also
3296.0|3.44|have performance of behavioral cloning
3297.44|3.44|and personal behavior cloning which
3299.44|2.96|because they don't look at reward
3300.88|3.679|information
3302.4|4.32|except maybe person bc looks at only for
3304.559|4.0|pre-processing the data set
3306.72|4.0|these are agnostic to whether the
3308.559|4.401|environments are have sponsor words or
3310.72|2.24|not
3314.16|6.76|would you expect this to be different if
3316.559|4.361|you were doing online rl
3324.4|2.32|um
3326.88|3.52|what's the intuition for it being
3328.319|3.841|different aprilia i would say no but
3330.4|5.28|it's maybe i'm missing out on a key
3332.16|5.52|piece of intuition behind that question
3335.68|4.56|um
3337.68|5.679|i think that because you're training
3340.24|5.92|like offline right like your the next
3343.359|5.121|input will always be the correct action
3346.16|4.24|in that sense so you don't just like
3348.48|4.0|deviate and like go off the rails
3350.4|3.919|technically because you just don't know
3352.48|3.92|so i could see like how online would
3354.319|4.401|have like a really hard
3356.4|3.679|like cold start basically because it
3358.72|2.96|just doesn't know and it's just
3360.079|5.76|happening in the dark until it like
3361.68|4.159|maybe eventually hits the jackpot
3366.079|4.401|right right i i think i agree that's so
3368.24|5.119|that's a good piece of uh
3370.48|4.319|uh intuition out there that yeah i think
3373.359|4.24|here
3374.799|4.721|because offline rl is really
3377.599|4.881|getting rid of the trial and error
3379.52|6.0|aspect of it and first pass
3382.48|4.96|reward environments that would be
3385.52|3.839|harder so
3387.44|3.84|the drop in
3389.359|4.72|dt performance should
3391.28|4.88|uh be more prominent there
3394.079|3.441|um i'm not sure how it would compare
3396.16|3.28|with
3397.52|3.839|the drop performance for other
3399.44|4.879|algorithms so
3401.359|4.321|uh but it will it it does seem like an
3404.319|5.52|interesting
3405.68|5.04|um setup to test uh dtm
3409.839|3.041|well
3410.72|3.04|and i did to maybe i'm wrong here but my
3412.88|2.64|understanding with the decision
3413.76|3.76|transformer as well is this is this
3415.52|3.92|critical piece that in the training you
3417.52|5.52|use the rewards to go right so is it is
3419.44|6.32|it not the sense that essentially like
3423.04|4.799|for each trajectory from the initial
3425.76|3.76|state based on the training regime
3427.839|3.601|the model has access to whether or not
3429.52|5.92|the final result was
3431.44|5.2|a uh success or failure right
3435.44|3.2|but that's sort of that's sort of a
3436.64|4.719|unique aspect of the training regime for
3438.64|4.479|decision transformers whereas in cql
3441.359|3.041|uh
3443.119|4.561|my understanding is that it's based on
3444.4|4.959|sort of a per transition
3447.68|4.159|training regime and so each transition
3449.359|5.521|is decoupled somewhat to what the final
3451.839|6.081|reward was is that correct
3454.88|4.64|uh yes um although like one difficulty
3457.92|3.52|which at a first glance you kind of
3459.52|3.68|imagined the different transformer
3461.44|3.84|having is that
3463.2|4.639|that initial token will not change
3465.28|3.44|throughout the trajectory
3467.839|2.801|yeah
3468.72|3.92|because it's just past reward scenarios
3470.64|4.159|so except the very last token where it
3472.64|4.8|will drop down to zero all of a sudden
3474.799|4.8|this token remains the same throughout
3477.44|4.08|uh but maybe that that
3479.599|3.841|but i think you're right that maybe just
3481.52|3.12|even at the start
3483.44|3.28|um
3484.64|4.08|feeding it in a manner which looks at
3486.72|4.16|the future rewards that you need to get
3488.72|4.24|to is is perhaps
3490.88|3.76|one part of the reason why the drop in
3492.96|5.119|performance is
3494.64|3.439|uh not noticeable
3498.24|3.52|yeah i mean i guess one sort of ablation
3499.92|3.6|experiment here would be if you if you
3501.76|3.839|change the training regime
3503.52|4.48|so that only the last trajectory had the
3505.599|3.281|um had the reward but i don't i'm trying
3508.0|3.52|to think about whether or not that would
3508.88|4.56|just be uh compensated for by sort of
3511.52|3.36|the attention mechanism anyway
3513.44|3.359|um
3514.88|3.52|and vice versa right if you if you
3516.799|3.201|embedded that reward information into
3518.4|2.56|the cql training procedure as well i'd
3520.0|3.119|be curious to see what would happen
3520.96|2.159|there
3523.44|4.679|yeah
3524.88|3.239|good experience
3531.2|4.56|okay so related to this um there's
3533.68|4.08|another environment we tested uh i gave
3535.76|3.359|you a brief preview of the results in
3537.76|3.52|one of the earlier slides so this is
3539.119|4.401|called the keycard environment
3541.28|3.279|and it has three phases so in the first
3543.52|2.799|phase you've
3544.559|3.28|the agent is placed in a room with the
3546.319|2.401|key
3547.839|3.121|um
3548.72|4.16|a good agent will pick up the key and
3550.96|3.28|then phase two it will be placed in an
3552.88|2.959|empty room
3554.24|3.119|and in phase three
3555.839|3.041|it will be placed in a room with a door
3557.359|2.561|which will act where it will actually
3558.88|3.52|use
3559.92|5.679|the key that it collected in phase one
3562.4|4.48|if it did to open the door
3565.599|2.641|uh so
3566.88|3.679|essentially the agent is going to
3568.24|4.16|receive a binary reward
3570.559|3.201|corresponding to whether it
3572.4|3.76|reached and
3573.76|5.52|opened the door in phase three
3576.16|3.919|conditioned on the fact that it
3579.28|3.68|uh
3580.079|4.161|did pick up the key in phase one
3582.96|3.2|so there is this
3584.24|4.16|national notion of that you want to
3586.16|3.76|assign credit to something that happened
3588.4|4.719|to an even that happened really really
3589.92|5.04|in the past so it's a very challenging
3593.119|3.44|uh and uh
3594.96|3.2|sensible scenario if you wanted to rest
3596.559|4.0|in models for how well they are at
3598.16|3.28|long-term credit assignment
3600.559|2.481|and
3601.44|3.76|here we find that
3603.04|4.319|uh so we tested it for different amounts
3605.2|4.159|of trajectories so here the number of
3607.359|4.561|trajectories basically says how often
3609.359|4.801|would you actually see this kind
3611.92|5.28|of behavior
3614.16|5.04|and the instant transformer
3617.2|4.159|is and person behavioral cloning both of
3619.2|3.52|these actually baselines
3621.359|3.361|uh do
3622.72|4.0|do much better than other models which
3624.72|4.48|struggle at this
3626.72|4.16|task
3629.2|3.44|um
3630.88|3.919|there's there's a related experiment
3632.64|5.28|there which is um
3634.799|5.441|also of interest so generally a lot of
3637.92|3.52|algorithms have this notion of an actor
3640.24|3.44|and a critic
3641.44|4.08|actor is basically someone
3643.68|3.679|that takes actions conditioned on the
3645.52|3.36|states so think of a policy
3647.359|3.601|a critic is
3648.88|4.4|basically evaluating
3650.96|4.24|how good these actions are in terms of
3653.28|3.12|achieving a long-term
3655.2|2.879|um
3656.4|4.24|in terms of this accumulative sum of
3658.079|4.881|rewards in the long term
3660.64|4.159|uh this is a good environment because uh
3662.96|2.639|we can see how
3664.799|2.8|uh
3665.599|5.2|how well the distant transformer would
3667.599|4.881|do if it was trained as a critic so here
3670.799|3.841|what we did is
3672.48|3.839|instead of having the actions as the
3674.64|3.919|output target
3676.319|4.641|what if we substituted that with the
3678.559|3.121|rewards
3680.96|2.879|so
3681.68|3.84|that's very much possible
3683.839|3.361|we can again use the same causal
3685.52|3.76|transformer machinery
3687.2|3.76|uh to only look at
3689.28|3.68|transitions in the previous time step
3690.96|5.04|and try to pick the reward
3692.96|3.92|and here we see this interesting pattern
3696.0|2.559|where
3696.88|3.6|in the three phases that we had in that
3698.559|4.401|key to do our environment
3700.48|5.119|we do see the reward probability
3702.96|4.96|changing very much in in
3705.599|4.561|how we expect so basically
3707.92|4.48|the three scenarios so the agent the
3710.16|4.08|first scenario let's look at bloom
3712.4|2.719|in which the agent does not pick up the
3714.24|2.559|key
3715.119|3.44|in phase one
3716.799|2.961|so the reward probability they all start
3718.559|3.441|around the same
3719.76|3.76|but as it becomes apparent that the
3722.0|3.52|agent is not going to pick up the key
3723.52|4.16|the reward starts going down
3725.52|4.4|and then it stays very much
3727.68|4.96|close to zero throughout
3729.92|5.28|the episode because there is no way you
3732.64|5.52|will have the key to open the door in
3735.2|5.28|the future phases
3738.16|5.199|if you pick up the key
3740.48|4.48|there are two possibilities
3743.359|2.641|uh
3744.96|2.56|which
3746.0|3.76|remain which are which are essentially
3747.52|3.76|the same in phase two where you are in
3749.76|3.44|an empty room
3751.28|4.319|uh which is just a distractor to make
3753.2|4.48|the episode really long
3755.599|3.841|but at the very end the two
3757.68|3.359|possibilities are one that you take the
3759.44|4.639|key and you actually reach the door
3761.039|5.76|which is the one we see in
3764.079|4.881|orange and brown here where you see that
3766.799|3.76|the reward probability goes up
3768.96|3.52|and this is this other possibility that
3770.559|3.441|you actually pick up the key but do not
3772.48|3.68|reach the door in which case again it
3774.0|4.16|starts seeing that
3776.16|4.24|the reward probability that's predicted
3778.16|3.28|starts going down
3780.4|4.32|so
3781.44|5.679|uh the takeaway from this experiment is
3784.72|4.48|that listen transformers are not just
3787.119|4.0|great actors which is what we've been
3789.2|3.2|seeing so far the results
3791.119|3.521|uh the
3792.4|4.399|for from the optimized policy but
3794.64|3.919|they're also very impressive critics in
3796.799|4.24|doing this long-term period and
3798.559|4.401|assignment uh where the reward is also
3801.039|3.76|very sparse
3802.96|3.119|uh so just to be correct are you
3804.799|3.361|predicting the rewards to go at each
3806.079|5.201|time step or is it is this like the
3808.16|3.12|type like the rewarded
3812.64|5.12|so this was the rewards to go uh
3816.079|3.921|and um
3817.76|3.52|i can also check my my impression was in
3820.0|2.72|this particular experiment it didn't
3821.28|3.44|really make a difference whether you
3822.72|3.599|were predicting rewards to go or the
3824.72|3.2|actual rewards
3826.319|3.76|uh but i think we're gonna chance to
3827.92|3.439|move for this one also most curious so
3830.079|3.04|how do you get the probability
3831.359|3.44|distribution of the rewards is it just
3833.119|3.121|like you just evaluate a lot of
3834.799|3.441|different episodes and just for the
3836.24|3.68|rewards or are you explicitly predicting
3838.24|4.559|some sort of distribution
3839.92|4.8|oh so so this is a binary reward so you
3842.799|4.24|can have uh so you can have a
3844.72|4.639|probabilistic outcome
3847.039|2.32|got it
3851.44|4.879|when you have a question uh yeah so
3853.92|4.32|generally we will call like some
3856.319|4.72|something predicts the state value or
3858.24|5.68|state action value as critic but in this
3861.039|6.161|case you you ask this transformer to
3863.92|6.639|only predict uh rewards so why do you
3867.2|3.359|still call it a critic
3870.96|4.32|so i i think the analogy here gets a bit
3873.68|3.52|clearer with returns to go like if you
3875.28|3.92|think what it turns to go it's really
3877.2|5.28|capturing that essence that you want to
3879.2|5.359|see the future rewards that oh i say so
3882.48|4.319|assuming this is gonna predict the
3884.559|3.681|return to goal instead of single step
3886.799|3.361|reward right
3888.24|4.879|yeah yeah
3890.16|4.24|okay so so if you're gonna predict uh
3893.119|3.44|written struggle is kind of
3894.4|4.32|counterintuitive to me because in
3896.559|5.201|phase one when the agent is still in the
3898.72|6.56|key room i think you should have a like
3901.76|4.48|high retest goal if it did after k
3905.28|4.24|but
3906.24|5.44|in but in the plot
3909.52|5.68|you know in the k room
3911.68|6.24|the agents pick up k and the agent that
3915.2|5.44|didn't pick up k has the same
3917.92|3.6|kind of level of returns to go so that's
3920.64|3.679|quite
3921.52|2.799|intuitive to me
3924.4|4.159|i think this is this is reflecting on
3927.599|2.96|uh
3928.559|4.081|a good property which is that your
3930.559|3.921|distribution
3932.64|4.479|like if you if you interpret returns to
3934.48|4.879|go in the right way in phase one you
3937.119|4.0|don't know which of these three outcomes
3939.359|2.96|are really possible and phase one also
3941.119|3.281|i'm talking about the very beginning
3942.319|3.04|basically uh slowly you will learn about
3944.4|2.159|it but
3945.359|2.0|essentially
3946.559|2.721|in
3947.359|3.361|in phase one if you see the returns to
3949.28|6.48|go as
3950.72|7.92|uh one or zero uh for for uh it it all
3955.76|5.12|three possibilities are equally likely
3958.64|4.56|and all three possibilities
3960.88|3.679|uh so if we try to evaluate the
3963.2|3.44|predicted
3964.559|3.921|reward for these possibilities it should
3966.64|3.84|be the same
3968.48|4.8|because we really haven't done
3970.48|5.599|we don't know what's going to happen in
3973.28|4.96|in in phase three
3976.079|4.72|sorry it's my mistake because i cuz
3978.24|5.68|previously that salter green lime is the
3980.799|5.201|agent which doesn't pick up decay but
3983.92|3.84|it turns out the blue line is asian
3986.0|3.44|which doesn't pick up
3987.76|4.72|okay so yeah it's my mistake okay it
3989.44|4.639|makes sense to me thank you
3992.48|2.96|uh also was not uh
3994.079|2.641|like fully clear from the paper but did
3995.44|2.72|you do experiments where you're like
3996.72|4.48|predicting both the actions and both the
3998.16|4.159|rewards to go and like does it like
4001.2|3.76|can it improve performance if you're
4002.319|4.081|doing both together so um
4004.96|3.28|actually we did some preliminary
4006.4|4.48|experiments on that and it didn't help
4008.24|4.48|us much however i do want to again put
4010.88|3.76|in a plug for a paper that came
4012.72|2.8|concurrently trajectory transformer
4014.64|3.6|which
4015.52|5.519|uh tried to predict um
4018.24|4.16|states actions and rewards actually all
4021.039|3.201|three of them
4022.4|4.959|uh they were in a model-based setup
4024.24|5.599|where it made sense also to
4027.359|4.801|uh try to learn each of the components
4029.839|4.321|like the transition dynamics the policy
4032.16|3.6|and maybe even the critic in their setup
4034.16|3.919|together
4035.76|5.039|we did not find any significant
4038.079|5.441|improvements so in favor of simplicity
4040.799|5.121|and keeping it model free we did not
4043.52|5.64|try to predict them together
4045.92|3.24|got it
4050.88|6.4|okay so the summary um
4054.24|6.559|we showed this in transformers which is
4057.28|6.24|a first work in trying to approach rl
4060.799|4.641|based on sequence modeling
4063.52|5.12|the main advantages over previous
4065.44|4.24|approaches is it's simple by design the
4068.64|4.08|hope is
4069.68|5.119|with further extensions we will find it
4072.72|4.0|to scale much better than existing our
4074.799|3.841|algorithms
4076.72|3.839|it is stable to train because the loss
4078.64|4.159|functions we are using
4080.559|5.04|have been tested and
4082.799|5.361|i traded upon a lot by
4085.599|5.52|research and perception
4088.16|5.52|and in the future we will also hope that
4091.119|5.761|because of these similarities with
4093.68|3.999|uh in the architecture and the training
4096.88|3.12|with
4097.679|4.801|how perception based tasks are conducted
4100.0|5.6|it would also be easy to integrate them
4102.48|5.759|within this loop so the states
4105.6|5.04|um the actions or even the tasks of
4108.239|3.52|interest they could be specified
4110.64|2.48|based on
4111.759|4.08|uh
4113.12|3.44|perceptual base sensors so you could
4115.839|2.641|have
4116.56|3.679|a target
4118.48|3.6|tasks being specified by natural
4120.239|4.721|language instruction
4122.08|6.0|and because these models can very well
4124.96|5.199|play with these kinds of inputs the hope
4128.08|5.04|is that they would be easy to integrate
4130.159|5.361|within the decision making
4133.12|2.4|process
4135.759|4.4|and empirically we saw strong
4138.159|3.04|performance in the range of offline rl
4140.159|3.281|settings
4141.199|4.48|and especially good performance
4143.44|5.2|in scenarios which required us to do
4145.679|6.0|long term credit assignment
4148.64|5.039|uh so there's a lot of future work this
4151.679|2.801|is definitely
4153.679|1.68|uh
4154.48|4.0|not
4155.359|5.521|the end this is a first work in
4158.48|5.839|rethinking how do we build
4160.88|4.72|rl agents that can scale and generalize
4164.319|3.36|um
4165.6|4.239|a few things that i picked out which i
4167.679|4.08|feel would be very exciting
4169.839|4.96|uh to extend
4171.759|5.841|uh the first is multi-modality
4174.799|4.241|so really one of our big motivations
4177.6|4.159|with going after
4179.04|5.199|these kinds of models is that we can
4181.759|4.321|combine different kinds of inputs both
4184.239|4.801|online and offline
4186.08|5.44|uh to really build decision making
4189.04|5.04|agents which work like humans
4191.52|5.52|uh we process so many inputs around us
4194.08|5.76|in different modalities and we
4197.04|4.639|act on them so we do take decisions
4199.84|4.0|and we want the same to happen in
4201.679|3.921|artificial agents and maybe decision
4203.84|4.319|transformers is one
4205.6|4.96|important step in that
4208.159|4.641|route
4210.56|6.08|uh multitask so
4212.8|5.76|i showed uh or i described very limited
4216.64|3.2|form of multitasking here which was
4218.56|3.84|based on
4219.84|5.68|the desired returns to go
4222.4|4.24|uh but it could be more richer in terms
4225.52|2.4|of
4226.64|4.4|specifying
4227.92|5.44|a command to be a robot or a desired
4231.04|3.92|goal state which could be for example
4233.36|4.64|even visual
4234.96|5.12|uh so trying to better explore the
4238.0|4.56|different multi-task capabilities of
4240.08|4.88|this model but also
4242.56|5.92|be an interesting extension
4244.96|4.56|uh finally uh multi-agent
4248.48|3.12|uh
4249.52|5.04|as human beings we never act in
4251.6|4.079|isolation we are always acting
4254.56|3.599|within
4255.679|4.641|um an environment that involves many
4258.159|4.801|many more agents um things become
4260.32|5.44|partially observable in those scenarios
4262.96|4.8|which place to the strengths of distant
4265.76|3.12|transformers being non-markovian by
4267.76|2.16|design
4268.88|3.44|so
4269.92|5.04|i think there is great possibilities of
4272.32|4.16|exploring even multi-agent scenarios
4274.96|4.08|where the fact that transformers can
4276.48|6.08|process fairly large sequences compared
4279.04|6.0|to existing algorithms could again help
4282.56|6.159|build better models of other agents
4285.04|3.679|in your environment and act
4289.92|4.16|so that yeah there's some just useful
4291.84|5.2|links in case you're interested uh the
4294.08|4.0|project website the paper and the code
4297.04|2.32|are all
4298.08|4.159|public
4299.36|5.2|and i'm happy to take any more questions
4302.239|4.241|uh sure okay so i said thanks for the
4304.56|3.599|good talk uh really appreciated everyone
4306.48|2.96|had a good time here
4308.159|3.281|um
4309.44|3.68|so i think we are like near the class
4311.44|3.759|limit um
4313.12|4.16|so usually i have like a round of
4315.199|3.281|reference five questions for the speaker
4317.28|3.6|that's just like the students usually
4318.48|4.0|know uh but like if someone is a hurry
4320.88|4.16|you can you just like
4322.48|5.44|uh ask general questions first
4325.04|5.199|um before we stop the recording so if
4327.92|4.239|anyone wants to like uh leave earlier at
4330.239|2.96|this time uh just feel free to ask your
4332.159|2.721|questions
4333.199|4.561|um
4334.88|4.48|otherwise i will just like continue on
4337.76|3.12|uh so what do you think is like the
4339.36|3.52|future of like transformers in other do
4340.88|3.279|you think they will take over like uh
4342.88|2.64|they've already taken over like language
4344.159|3.121|and vision so do you think for like
4345.52|3.12|model based and like moderate learning
4347.28|5.04|do you think you'll see a lot more like
4348.64|6.96|transformers pop up in our literature
4352.32|6.96|uh yes uh i i think we'll see a flurry
4355.6|7.119|of work um if not already we have good
4359.28|5.919|there's so many works using transformers
4362.719|3.44|at this year's eye clear conference
4365.199|2.96|um
4366.159|3.761|having said that i feel that an
4368.159|4.241|important piece of the puzzle that needs
4369.92|4.6|to be solved is expiration
4372.4|3.759|it's
4374.52|3.639|non-trivial
4376.159|4.481|and it will
4378.159|4.721|have to my my guess is that you will
4380.64|4.4|have to forgo some of the
4382.88|4.72|advantages that i talked about for
4385.04|5.199|transformers in terms of loss functions
4387.6|4.0|to actually enable expiration
4390.239|2.0|uh so
4391.6|3.04|i
4392.239|4.561|it remains to be seen whether those
4394.64|3.76|modified loss functions
4396.8|2.64|for expiration
4398.4|3.68|actually
4399.44|5.6|uh hurt performance significantly
4402.08|6.72|uh but as long as we cannot cross that
4405.04|6.32|uh bottleneck i think uh it it it is
4408.8|4.48|i'm not i i do not want to commit that
4411.36|3.6|this is indeed the
4413.28|2.56|future of rl
4414.96|4.719|got it
4415.84|3.839|uh also like you think like something
4420.8|4.08|sure um i'm not sure understood that
4422.96|4.719|point so you're saying that in order to
4424.88|4.319|apply transformers in rl do exploration
4427.679|3.361|there have to be particular loss
4429.199|3.761|functions and and they're tricky for
4431.04|3.36|some reason
4432.96|3.04|yeah could you explain more like what
4434.4|4.16|are what are the modified loss functions
4436.0|3.52|and why do they seem tricky
4438.56|3.2|so
4439.52|4.32|essentially in expiration
4441.76|4.12|you have to do the opposite of
4443.84|3.52|exploitation which is non-aggregate
4445.88|3.88|[Music]
4447.36|4.64|and there is right now no
4449.76|5.04|nothing inbuilt in the transformer right
4452.0|4.239|now which encourages that sort of random
4454.8|3.6|behavior
4456.239|3.361|uh where you seek out
4458.4|4.319|uh
4459.6|4.88|unfamiliar uh unfamiliar parts of the
4462.719|4.401|state space
4464.48|5.12|that is something which is inbuilt into
4467.12|4.4|traditional rl algorithms
4469.6|4.96|so you usually have some sort of entropy
4471.52|5.679|bonus to encourage expiration
4474.56|3.44|and those are the sort of modifications
4477.199|3.441|which
4478.0|5.04|one will also need to think about
4480.64|3.36|if one were to use this and transformers
4483.04|2.4|for
4484.0|3.679|online rl
4485.44|4.08|so what happens if somebody i mean just
4487.679|3.201|naively suppose i have this exact same
4489.52|5.04|setup and the way that i sample the
4490.88|5.52|action is i i sample epsilon greedily or
4494.56|3.76|i create a boltzmann distribution and i
4496.4|3.92|sample from that i mean just what
4498.32|5.28|happens it seems
4500.32|6.399|that's what rl does so does what happens
4503.6|6.16|so rl does a little bit more than that
4506.719|4.241|it indeed does those kinds of
4509.76|2.72|things where it would change the
4510.96|4.4|distribution for example to be a
4512.48|5.44|personal distribution and sample from it
4515.36|4.4|but it's also there there are these uh
4517.92|4.16|as i said the devil lies in the detail
4519.76|3.76|it's also about how it controls that
4522.08|3.119|exploration component with the
4523.52|5.36|exploitation
4525.199|5.52|and it's an um it it remains to be seen
4528.88|3.359|whether that is compatible or decision
4530.719|2.96|transformers
4532.239|4.801|i don't want to jump the gun but i would
4533.679|5.441|say it's it's i mean um
4537.04|4.88|preliminary evidence suggests that it's
4539.12|4.559|not directly transferable the exact same
4541.92|3.279|uh setup to
4543.679|3.04|the online case that's what we have
4545.199|3.681|found
4546.719|4.96|there has to be some adjustments to be
4548.88|4.48|made to make yeah which we we are still
4551.679|3.441|figuring it out
4553.36|3.52|so the the reason why i ask is as you
4555.12|3.36|said the devil's in the details and so
4556.88|3.279|someone naively like me might just come
4558.48|3.84|along and try doing what's in rl i want
4560.159|3.921|to hear more about this so you're saying
4562.32|3.44|that what works in rl may not work for
4564.08|3.599|decision transformers
4565.76|5.439|can you tell us
4567.679|5.921|why like what pathologies emerge um
4571.199|4.081|what what are those devils uh hiding in
4573.6|3.52|the details
4575.28|6.2|uh also remind you like sorry we are
4577.12|4.36|like all over time so if you know
4584.56|4.639|and i'm sure that it's tricky
4587.44|3.84|um yeah i'll just ask like two more
4589.199|4.561|questions um and like
4591.28|4.32|after those so one is uh like other did
4593.76|3.36|you think uh like something like this in
4595.6|3.84|transformer is a way to solve the data
4597.12|5.599|center problem in oil instead of using
4599.44|3.279|some sort of like this one factor
4603.28|2.72|uh
4604.48|3.759|sorry that can you repeat the question
4606.0|3.04|oh sorry yes i think usually in rl we
4608.239|2.721|have to rely on some sort of
4609.04|3.28|disconfected to encode the rewards to go
4610.96|3.44|something like that but it's in
4612.32|3.359|transformer transformers able to do this
4614.4|3.759|credit assignment
4615.679|3.921|uh without that so do you think like uh
4618.159|3.681|some something like this book is like
4619.6|4.639|the way you should do it like we should
4621.84|3.68|like instead of having some discount try
4624.239|2.641|to directly predict
4625.52|3.84|rewards
4626.88|4.4|so i i would go on to say that i feel
4629.36|4.96|that discount factor is an important
4631.28|5.52|consideration in general and
4634.32|4.399|it's not incompatible with discipline
4636.8|2.8|transformers so basically what would
4638.719|2.641|change
4639.6|3.92|and i think the code actually gives that
4641.36|4.879|functionality where
4643.52|6.8|the returns to go would be computed as
4646.239|6.0|the discounted sum of rewards
4650.32|3.839|so it is very much compatible so there
4652.239|5.121|are scenarios where
4654.159|5.601|uh our context length is still is not
4657.36|3.52|enough to actually capture the long-term
4659.76|3.76|behavior
4660.88|4.64|we really need for credit assignment
4663.52|4.88|maybe traditional tricks
4665.52|6.159|um that are used could be brought in
4668.4|5.36|back to solve those kinds of problems
4671.679|3.201|got it yeah i also thought like when i
4673.76|2.399|was reading the
4674.88|2.64|decision transfer work that the
4676.159|2.881|interesting thing is
4677.52|3.04|that you don't have a fixed drama like a
4679.04|2.48|gamma is like usually a hyper parameter
4680.56|2.32|but like
4681.52|2.719|you don't have a fixed gamma so do you
4682.88|3.359|think like can you also like learn this
4684.239|2.881|thing and could this also be like can
4686.239|4.081|you have a different karma for each
4687.12|5.44|chamstick or something possibly
4690.32|4.48|uh that would be interesting actually i
4692.56|4.08|i had not thought of that but
4694.8|3.68|um maybe
4696.64|5.68|learning to predict this non-factor
4698.48|6.0|could be another extension of this work
4702.32|3.68|also do you think like this like uh this
4704.48|3.36|transformer work is like like is it
4706.0|3.44|compatible with q learning so if you're
4707.84|3.52|something like cql stuff like that can
4709.44|4.08|you also implement those sort of loss
4711.36|4.319|functions on top of like decision
4713.52|6.08|transformer
4715.679|6.0|uh so um i think um maybe
4719.6|4.48|could imagine ways in which you could
4721.679|5.121|encode pessimism in here
4724.08|3.44|uh as well which which is which is key
4726.8|2.399|to
4727.52|5.12|our secret words
4729.199|5.921|uh and actually most of um
4732.64|4.32|of the nrl algorithms work uh including
4735.12|5.039|the model based ones
4736.96|5.279|right uh our focus here deliberately was
4740.159|3.921|to go after simplicity
4742.239|4.241|uh because we feel that part of the
4744.08|4.159|reason why our literature has been so
4746.48|3.84|scattered as well if you think about
4748.239|4.321|different sub problems everyone tries to
4750.32|3.76|solve has been because
4752.56|3.28|everyone's
4754.08|3.92|tried to
4755.84|5.28|pick up on ideas which
4758.0|4.4|are very well suited for that narrow
4761.12|3.76|uh
4762.4|4.319|narrow problem like for example you have
4764.88|3.44|and whether you're doing offline or
4766.719|3.041|reading online or you're doing imitation
4768.32|2.8|you're doing multitask and all these
4769.76|2.24|different variants
4771.12|4.48|and
4772.0|7.199|uh so by design we did not we we were
4775.6|6.16|very step we did not want to incorporate
4779.199|5.361|exactly the components that exist in a
4781.76|4.88|um in the current algorithms uh because
4784.56|4.08|then it just when it starts looking more
4786.64|3.76|like a
4788.64|3.44|architecture change as opposed to a more
4790.4|3.839|conceptual change into thinking about
4792.08|5.44|rls sequence modeling
4794.239|3.281|uh very generally
4797.6|3.04|yeah that sounds interesting
4799.28|3.36|so do you think we can use some sort of
4800.64|4.21|like like tv learning objectives instead
4802.64|3.76|of supervised learning um
4804.85|4.51|[Music]
4806.4|5.52|it's possible uh and
4809.36|5.68|maybe like i'm saying that for certain
4811.92|5.84|like for online rl it might be necessary
4815.04|5.92|yeah often rl we were happy to see it
4817.76|4.959|was uh not necessary
4820.96|4.64|but that it remains to be seen more
4822.719|4.801|generally for a transformer model or any
4825.6|4.24|other model for that matter encompassing
4827.52|4.88|rl more broadly whether that
4829.84|4.319|uh becomes a necessity
4832.4|6.36|all right yeah
4834.159|4.601|well thanks for your time this was great