start_time|end_time|text
1.16|3.56| Yeah, now moving on from the multilayer networks, like the
4.72|3.24| multilayer perceptrons to deep learning. So we're going to talk
7.96|3.52| about the origins of deep learning in this video. So
11.64|3.04| coincidentally, I just submitted a paper today with collaborators
14.68|3.36| where we used multilayer perceptrons. And we were
18.04|3.7| debating whether we should call it deep learning or whether we
21.74|3.34| should avoid the word. The reason is deep learning is a
25.08|3.4| relatively new word like that was invented, I would say like
28.48|4.56| 1015 years ago. But multilayer perceptrons have been around for
33.04|3.48| at least like 3040 years, right, like I talked about in the
36.52|3.92| previous video. So is this really deep learning? So yeah,
40.44|5.2| that is kind of debatable. So technically, when the term deep
45.64|3.94| learning first occurred, when it was first used, what people
49.58|4.02| refer to was the representation learning with advanced
53.6|4.72| architectures with many layers. So having multiple layers is not
58.32|3.72| really what makes the difference between a multilayer perceptron
62.04|3.68| and deep learning. It's more like the representation learning
65.72|5.32| capabilities. That is usually, yeah, what deep learning is all
71.04|4.86| about. So nowadays, though, if you read papers, newer papers
75.92|3.2| where people use multilayer perceptrons, they call them
79.12|3.0| deep learning, too. So I think nowadays, it's okay to also call
82.12|2.7| it deep learning to make it maybe less confusing for people
84.82|2.98| because everything nowadays that is a neural network is also
87.8|3.88| automatically deep learning. But let's dive a little bit more into
91.68|4.2| the representation learning aspects that I just mentioned. So
95.88|4.68| that goes back to, yeah, also the approximately 1990s. So
100.56|4.24| also, in that way, it's a thing that was discovered or invented
105.04|2.64| before deep learning was a thing, the word deep learning,
107.96|4.44| and it is convolutional neural networks. So this is kind of on
112.4|3.12| top of, yeah, the multilayer perceptrons, it's like, you can
115.52|3.6| think of it as a specialized version where you have locality.
119.52|5.28| So here, it's about making training more efficient, and
124.8|4.12| also extracting local features, which then better capture feature
128.92|4.28| dependency. So recall, in multilayer perceptrons, we had
133.2|3.16| like the feature independence, so it would work with tabular
136.36|2.8| data. Now with this convolutional network, we can
139.16|6.04| leverage some prior knowledge of this relational inductive
145.2|3.48| bias. So it's specific specifically for image
148.68|5.6| recognition for image data. So how multilayer perceptron works
154.28|3.08| is you have these independent features, and the convolution
157.36|3.58| network captures dependency. On the right hand side, I'm showing
160.94|5.7| you this original linnet architecture from Yanli Kuhn and
166.68|4.02| coworkers that was applied to hand written zip code
170.7|4.62| recognition. And we will have a dedicated lecture just to
175.32|4.32| convolutional networks later. But here just a brief overview is
179.88|4.92| that it consists of two parts. So there's one part that is the
184.8|7.6| convolutional part. So here you have convolution layers, they
192.4|4.76| have a trick or concept called weight sharing. And there's also
197.16|3.64| pooling involved. And that makes the training more efficient, we
200.8|2.88| will discuss this in more detail later. But you can think of it
203.68|8.6| roughly as the feature learning layers where these layers are
212.28|3.88| able to extract abstract features from the data. And
216.16|8.8| these features are then passed on to fully connected set of
224.96|3.2| layers. So these are fully connected layers. And these are
228.48|8.48| essentially a multilayer perceptron. And you can think of
236.96|5.48| it as a classifier here. So if you think of it as a task, let
242.44|4.64| me also use the red here. So here we have this part, the
247.08|3.4| lower part here for feature learning. This upper part is
250.48|6.16| for classifying the features that have been extracted by these
256.68|4.6| earlier layers. So this is making the hand crafting of the
261.28|3.76| features obsolete. Now the network learns the features and
265.04|4.08| it learns it in a way such that it is optimal for the classifier
269.12|3.14| because everything here is connected. So it's learning
272.26|4.14| together, which is one advantage that makes that makes new
276.4|4.62| networks for image data specifically very efficient. So
281.02|3.74| this is, again, this is from the 1990s. Back then, the term deep
284.76|3.08| learning didn't exist. But I would say nowadays, convolutional
287.84|3.96| neural networks are really like the most popular form of deep
291.8|3.72| learning, because there are, I mean, many, many advances that
295.72|3.56| followed this earlier architectures, and made deep
299.28|2.76| learning what it is nowadays, of course, there's also a separate
302.04|3.0| branch of recurrent neural networks that is also very
305.04|3.08| popular in deep learning. So recurrent neural networks also
308.12|2.8| are, I would say an advanced version of the multi layer
310.92|4.8| perceptron. So here, what's new is that there is a recurrence.
315.8|4.0| So and so you can think of this as a multi layer perceptron, but
319.84|3.2| a multi layer perceptron is a feed forward network. Now you
323.04|5.48| have this recurrence. So you're revisiting earlier things. So
328.52|3.32| again, this will be covered in way more detail in a dedicated
331.84|2.96| lecture later on in this course. But the key idea is basically
334.8|3.28| that we have a modified version of backpropagation, which is
338.08|3.52| called backpropagation through time, because there's a time
341.6|5.72| component component. And this is especially useful for sequence
347.32|4.08| data, where there's a sequential dependency in the data among
351.44|5.76| across the features. So but the problem with that is now when we
357.2|3.4| train neural networks with many layers, especially for recurrence
360.6|3.0| over long sequence, there's this problem of vanishing and
363.6|4.48| exploding gradients. So that is like a big challenge. However,
368.08|3.76| it was also I mean, there are many potential solutions to
371.84|3.36| that. One of them that is one of the ones that is still commonly
375.2|4.64| used as LSTMs that stands for long, shorter memory. So also
379.84|4.1| this one was like overcome. And this is also one popular form of
383.94|2.34| deep learning, like using these neural networks. But again, this
386.28|2.76| is something that has been around for a long time, actually,
389.04|2.72| I don't know exactly when recurrent neural networks were
391.76|3.2| invented. First, it was like also in the 1980s, sometime
395.12|3.2| after backpropagation was invented, because yeah, this is
398.32|3.28| an advancement of backpropagation. It was someone
401.72|5.08| sometime in the 1980s. Yeah, just to summarize what
406.92|3.76| originally the term deep learning meant, he has a nice
410.84|4.56| section or sentence from the deep learning review by Lacoon,
415.4|3.96| Benjo, and Hinton. So Hinton was the person working on the back
419.36|4.64| propagation algorithm, Lacoon was the one who came up with the
424.0|3.4| convolution neural network. And Benjo is doing a lot of work
427.4|3.28| also across deep learning, mainly also focusing on the
430.68|4.2| recurrent neural networks, but also basically everything. So in
434.88|5.04| this review, the sentence goes like, like this representation
439.92|3.48| learning is a set of methods that allows machine to be fed
443.4|2.44| with raw data, and to automatically discover the
445.84|3.8| representations needed for detection or classification. Deep
449.64|2.32| learning methods are representation learning methods
452.12|3.16| with multiple levels of representation can also say
455.88|5.72| abstraction. Yeah, and so here, the focus is really like the
461.6|3.52| implicit feature extraction that deep learning does. That is
465.12|2.56| something that traditional machine learning is not capable
467.68|3.2| of, like we talked about last week, where we have the
470.88|3.68| handcrafted features versus the automatic feature extraction. So
474.56|3.88| here, the focus is really on on the automatic part. But
478.44|6.52| nowadays, really, deep learning means the same as using neural
484.96|4.84| networks. So deep learning nowadays, it's really the same
489.8|8.16| as using neural networks, maybe we should be a little bit more
497.96|7.24| specific and say, multi layer. Yeah, but going from these
505.24|3.96| architectures, I showed you that were invented in the 90s, towards
509.2|3.32| the modern era of deep learning research, there was unfortunately
512.52|5.12| in between another AI winter in the late 1990s and early 2000s.
517.88|3.36| And I think that was probably due to the popularity of support
521.24|2.68| vector machines and random forests. Because back then,
523.92|3.72| yeah, neural networks were capable, but they were very
527.64|3.16| expensive to train. So you needed like, enormous computer
530.8|2.36| hardware to train them efficiently. And even then, you
533.16|2.6| had to wait a long time to train them. So they were not easy to
535.76|2.52| train compared to, let's say, support vector machines and
538.28|2.84| random forests. Of course, support vector machines come
541.12|3.56| with their own set of problems like the really inefficiency of
544.92|3.36| RBF kernel machines on high dimensional data. Also, random
548.28|4.8| forests require a lot of trees. So but still compared to deep
553.08|4.0| neural networks, these were easier to train and worked quite
557.08|5.4| well. So yeah, but then at some point, people figured out how to
562.48|4.08| use GPUs to make the training of neural networks more efficient.
566.56|2.76| And that is really what helped me I'm making neural networks
569.32|4.52| really popular and feasible. So when I looked at literature,
574.2|3.52| what I could find, it goes already back to 2004. So on GPU
577.72|2.72| implementations of neural networks have been around for
580.44|2.96| quite some time. But really, when it became popular was in
583.4|4.88| 2012, where Kroshevsky, suits giver and Hinton worked on
588.64|3.48| image net classification. So very common benchmark data set
592.12|4.2| like millions of images, where they used deep neural networks
596.32|3.52| trained on GPUs to outperform traditional computer vision
599.84|3.44| approaches. So a few more words about that in the next couple of
603.28|8.52| nights. So here's a table from my 2017 book, I actually updated
611.8|3.56| this last year. So I don't know why I have the old one here,
615.36|4.24| maybe I should swap it. But again, so the bottom line here
619.6|5.48| is more that the difference between traditional CPU, for
625.08|5.0| example, here, an Intel CPU, and an Nvidia graphics card, or in
630.08|2.8| general, a graphics card, maybe think of it as the difference
632.88|5.28| between a CPU and GPU. And GPUs are particularly good at linear
638.16|4.68| algebra operations like vector and matrix operations. So even
642.84|3.78| though GPUs have a smaller clock frequency, one advantage is
646.62|3.9| really like the parallel course, each column is slower than a
650.52|2.88| CPU core, of course, but you have more of them. And that
653.4|5.4| helps you parallelizing computation. So parallel
658.8|7.52| computing of dot products and matrix multiplications is really
666.32|4.36| what what makes GPUs very useful for deep learning. So you really
670.68|4.08| get a higher way higher memory bandwidth also. So the GPU
674.76|3.36| memory, GPUs come with their own memory, which is closer to
678.12|3.32| where things are computed. So it's also faster. In that way, if
681.44|2.8| you have the data on the GPU, however, you have to get the
684.24|2.52| data to the GPU, which is sometimes a little bit slower.
686.76|4.68| So there are some tricks also to make this efficient in terms of
691.44|3.0| data loading. But this is something we will talk about
694.44|4.2| when we actually use pytorch for deep learning, I will also show
698.64|3.24| you how you can use GPUs. For this class, you won't need a
701.88|4.32| GPU, I will later on talk about some free online resources where
706.44|3.6| you can get one GPU for free, which can help with some
710.04|2.88| homeworks and also the project. But yeah, you don't need to buy
712.92|3.96| your own GPU or something like that. So yeah, and moving on.
716.88|3.16| Yeah, so really, the you can see the number of floating point
720.04|4.04| calculation of float is, you can think of it as a decimal number
724.08|3.12| in the computer, you can see it has a way higher number of
727.2|3.68| floating point calculations. And it's also cheaper, at least
730.88|4.84| compared to this high end Intel CPU. But of course, there are
735.72|4.32| also things with GPUs that make certain things inconvenient
740.04|3.4| because they have their own memory, which is not very large.
743.48|2.64| I mean, there are nowadays more expensive cards that have larger
746.12|3.52| memory. But usually in deep learning, GPU memory is a
749.64|2.76| bottleneck, at least for me. But again, that is a topic for
752.4|3.32| another day. Yes. So here's another fun quote from the
755.72|4.28| architects of intelligence, like an interview with Joe Fintan. So
760.0|1.2| it is about when
764.72|3.12| Yeah, so regarding the question, when did deep learning become
767.84|3.48| when did deep learning become really popular. So here again,
771.32|3.56| as a fun quote from one excerpt from interview from the book,
775.08|4.52| architects of intelligence. And yeah, this refers to the 2012
779.84|3.92| image net competition. So there was a famous computer vision
783.76|2.52| competition on a data set called
787.8|4.64| image net. And it was essentially about a benchmark and
792.44|5.12| people submitted computer vision methods and papers. And it was
797.56|3.48| about having the best system each year, who could do the best
801.04|3.84| classification on this image data set. It's like a image
804.88|4.04| data set consisting of up to 14 million images of they used only
808.92|3.04| a subset of at that time, as far as I remember. But yeah, it was
812.0|4.96| millions of images. And back then, really, the conferences
816.96|3.48| were dominated by traditional computer vision approaches like
820.44|3.24| manual feature engineering, and so forth. No deep learning,
823.68|3.8| really. And here in this interview, and I want to read
827.48|2.56| everything here, maybe you can pause the video and read through
830.04|3.8| it if you are curious. But it is essentially about that deep
833.84|3.16| learning methods were usually rejected. So here's like
837.04|3.24| something I underlined, the referees thought that it was the
840.28|3.6| ray wave, sorry, the referees thought it was the wrong way to
843.88|2.72| do things, referring to the neural network architectures
846.6|3.76| here. So people really didn't like deep neural networks back
850.36|2.84| then. I mean, people who were using traditional computer
853.2|5.6| vision systems, however, in the network that was submitted that
858.8|4.36| year in 2012, the Alex net, which was by Alex Kroshevsky,
863.32|3.68| so it's cable and Joff Hinton was really outperforming
867.04|3.32| traditional computer vision methods by a large margin. So
870.36|5.84| they achieved a 15.4% error in 2012 on top five classification,
876.2|4.6| I will in the next slide explain what top five accuracy or error
880.8|3.96| means. So forget about top five for now. So they achieved a
884.76|5.04| 15.4% classification error. And the second best method only
889.8|5.32| achieved 26.2% error. So their method was about twice as good
895.12|3.2| as any traditional computer vision system. And by the way,
898.32|3.56| as a side note, nowadays, you can even get down to 3% error on
901.88|4.36| image net. So even like since 2012, things improved quite a
906.24|6.08| lot. But yeah, so just briefly here, the last thing, so people
912.32|3.6| were really surprised about how well deep learning worked. And
916.08|3.84| then also, like he says, within two years, they all switched. So
919.92|2.72| for things like object classification, nobody would
922.64|3.88| dream of trying to do it without using a new network now. So this
926.52|3.8| was really like 2012 was really like the breakthrough moment for
930.32|3.28| deep learning, because it performed really well on image
933.6|4.32| classification. Yeah, and he has also just a quick overview of
938.2|3.32| the benchmark data sets. Nowadays, there are other even
941.52|3.12| bigger data sets, but these are still common data sets when you
944.64|4.08| develop convolutional networks or object classification
948.72|3.28| methods. So there's the traditional MNIST data set from
952.0|5.76| 1998. 60,000 examples, 10 classes, and very low resolution
957.76|2.8| images. So these are the handwritten digits. So this is
960.56|3.8| still a great data set for debugging your network. It's
964.36|4.28| like when you want to try a network, get the code written
968.64|2.64| and see whether it works, because it's really fast to
971.28|2.64| train a network on that. In practice, if you write a
973.92|3.2| conference paper, testing your method on MNIST may not be
977.12|4.52| enough anymore. But yeah, it's still a good way to start more,
981.68|4.36| I would say advanced data set is cipher 10 and cipher 100. So
986.04|4.56| there are 60,000 examples of either 10 classes, which is for
990.64|4.16| cipher 10 or 100 classes in cipher 100. Again, very low
994.8|4.36| resolution 32 by 32. Now that we have color images, so we have
999.16|3.44| three color channels. And yeah, we have different objects here
1002.6|4.48| to classify this usually only one object in each image. A more
1007.08|3.26| challenging data set is the image net data set, which
1010.34|4.7| consists of 14 million images. So they have full resolution.
1015.04|3.6| And what is a little bit more challenging about that, too, is
1018.84|3.96| that there can be multiple objects in an image I talked
1022.8|3.72| about in the stuff in the news section where people were
1026.56|3.88| relabeling image net. But yeah, so what can happen is that there
1030.44|4.4| could be multiple objects sometimes. So it can be kind of
1034.88|3.04| ambiguous. So usually what people do is they measure the
1037.92|8.0| top five accuracy or error. So for example, when you have a
1045.92|5.08| prediction, you check whether it's so whether your top five
1051.0|3.48| labels are matching with the image label because the network
1054.84|4.2| is trained to return a probability or confidence score
1059.04|4.0| for each possible class. And then you look at the top five
1063.48|4.24| most confident labels. And you look whether one of the five
1067.72|3.6| labels matches with the label in the image. For example, a it's
1071.32|6.96| a bit small, I can't really read this here. Um, yeah, let me see.
1078.36|4.12| But let me pick an example. So here, for example, we have
1082.48|3.84| actually also two things we have a cherry and a dog. So it's
1086.32|3.2| also you can see this is like a challenging example where your
1089.52|4.16| network may predict a dog. But since the data point here is
1093.68|2.88| labeled with cherry, it would actually count as an error,
1096.56|3.68| which is kind of unfortunate. So you would look whether your
1100.24|4.64| prediction is kind of within a top five. Or here in this case,
1105.16|4.0| your algorithm may predict car or grill, like the grill of a
1109.16|3.4| car, both would be correct, right. So in that way, you look
1112.56|4.04| is whether a grill is under your top five, for example. So in
1116.6|3.44| that way, it's a little bit harder to evaluate on image net
1120.04|3.76| compared to cipher 10. I think in cipher 10, it's a little bit
1123.8|3.2| more obvious, not, not more than more obvious. But here you have
1127.0|4.2| classes where it's at least a little bit less ambiguous.
1132.96|2.84| Alright, but yeah, moving on, I don't want to make this brief
1135.8|3.68| overview lecture like too long, because we will dive into these
1139.48|2.8| little concepts in way more detail later throughout this
1142.28|3.4| course. So like, like the last thing here, of course, there
1145.68|5.04| have been many advances since 2012. So okay, this is 2010.
1150.72|4.16| But for example, advances that are making deep neural networks
1154.88|5.08| work way better. So common ones are popular ones are relu units,
1159.96|3.36| rectified linear units, which are activation functions, very
1163.32|4.68| simple, but very effective batch normalization, dropout,
1168.24|2.72| generative adversarial networks. And these are all covered in
1170.96|3.04| this course, and many more. So there have been a lot of advances
1174.0|3.68| also in the last decade. And these are already like six, seven
1177.68|5.88| years old. And so there are way more of these and they are all
1183.6|4.96| contributing together to make deep learning work better. So in
1188.56|2.96| the next video, I want to briefly just very briefly talk
1191.52|2.12| a little bit about hardware and software landscape, what has
1193.64|4.76| changed in the few last few years, and then briefly going
1198.4|2.68| over some current research trends, and then really
1201.08|4.52| wrapping up these series of videos here for lecture two, and
1205.6|4.48| then that we can go into our more detailed lesson on
1210.08|25.92| perceptrons.