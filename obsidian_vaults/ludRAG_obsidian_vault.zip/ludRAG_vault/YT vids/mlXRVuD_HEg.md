start_time|end_time|text
2.06|4.14| All right, in this video, let's now talk about Alex net trained
6.2|4.88| on cipher 10. So just to recap how Alex net looks like it's
11.08|7.52| this architecture where we have as input 96 channels, then 256
18.64|3.84| going from 90s. So the input images, first of all, are 224
22.48|5.96| times 224 times three. The first after the first convolution,
28.44|6.44| it's 96 channels, then 256 channels, 386, I think it should
34.88|2.96| be 384. Like I mentioned, I think this was a typo, then
37.84|4.48| another 384 256. And then these fully connected layers, and you
42.32|3.08| can see, these fully connected layers are really huge. So
45.4|6.92| there's 4096 4096, and then 1000 class labels, I shortened the
52.32|4.48| first layer a little bit from 96 to 64. But overall, I try to
56.8|3.24| keep the same architecture that I implemented. Notice that we are
60.04|4.12| not training it on image net, we are training it only on cipher
64.16|4.64| 10 images, which are smaller. So that way, I made some small
68.8|3.48| adjustments to account for the smaller size of the input
72.28|6.72| images. So here, everything should be the same as before.
79.2|3.3| I'm actually not rerunning this now, because this might take a
82.5|2.2| while, I will show you at the end how long it took to train
84.7|6.66| this architecture. So I ran this on a GPU also. So first of all,
91.56|2.8| I let me only go through the changes that are different from
94.36|2.96| the net that I showed you before. One change is that we
97.32|4.76| now have cipher 10 images instead of MNIST images. So what
102.08|3.24| I'm doing here also is I'm making the cipher 10 images
105.32|4.52| larger than they really are. So cipher 10 is 32 times 32. But
109.84|3.4| I'm making them larger, like 70 times 70, because otherwise, I
113.24|3.56| get problems with the dimensions. Because otherwise,
117.0|4.2| we go back to the overview here. Otherwise, here at this point,
122.28|3.08| the height and width will be too small, essentially, they will
125.36|5.2| be non existent, basically. So in that way, I have to resize
130.56|3.12| the input images to make this network architecture work on
133.68|3.28| cipher 10. And what I'm doing is also to make the network a
136.96|3.08| little bit more robust towards overfitting. What I'm doing is
140.04|4.92| I'm doing a random crop. So I'm randomly clock dropping a 64 by
144.96|5.08| 64 region from the 70 times 70 input that's during training and
150.04|4.6| every time a really different random crop. Then, yeah, the
154.64|3.04| regular to tensor thing. And then here, I'm normalizing the
157.68|5.36| channels, the color channels to be a center, the pixels to be
163.04|3.16| centered at zero, you could technically also compute the
166.2|4.6| standard deviation and mean from the actual image data. But here,
170.8|2.92| what I'm doing is I'm just normalizing them in a very
173.72|3.84| simple way, that the pixels are centered at zero, and have mine
177.96|3.16| in the range between minus one and one. That is the same as I
181.12|3.92| did with MNIST before, but now I have three color channels. So
185.04|2.8| that's why I'm doing it like this. If I just go back to my
187.88|3.52| MNIST one, I only had one color channel. So I only had point
191.4|4.64| five here. All right. Notice that I'm only doing this random
196.04|4.96| crop for the training. I don't want any randomness when I apply
201.0|4.92| my model to, let's say new data during prediction, and validation
205.92|5.56| and test data. I'm mimicking new data, because I use that data to
211.48|3.48| evaluate how well my model might perform on new data. And it
214.96|3.4| wouldn't make sense to have some random cropping for new data. If
218.36|3.92| you have, let's say, customer, let's say at the airport, or you
222.28|2.88| want to do face recognition to see whether the person at the
225.16|2.52| airport is the same as on the passport or something like that,
227.84|3.88| you do don't want to just do random crops and predictions, you
231.72|3.28| just want to do center crop. So the random crop is just to make
235.0|8.12| the model more robust towards small perturbations. Yes. So here
243.12|4.2| we use then the center crop instead of this random crop. The
247.32|5.6| rest is all the same as before. I have my images, my batches are
252.92|5.68| 256 in size, three color channels, 64 pixels high and 64
258.6|5.56| pixels wide. And I also have 10 classes. Here's the Alex net
264.16|5.88| architecture now. So can maybe highlight the blocks. So this is
270.16|4.2| one convolutional block. And there's another one, just
274.48|7.24| separating them out here. So these are the convolutional
281.72|5.28| blocks. Yeah, I only have max pooling, essentially. Oh, sorry,
287.04|2.36| what I did was not ideal. I should have done it like this
289.4|7.16| max pooling, come to me, or I do max pooling. Okay. Notice here
296.56|10.28| is no pooling in between. So yeah, just separated them into
306.84|5.24| blocks. Can't see it here might be might be visible here. So you
312.08|3.52| can see, max pooling, max pooling, max pooling, but no
315.64|6.56| pooling here. Try to implement that here. So that is how the
322.2|3.72| Alex net looks like that is now the feature extractor part. So
326.12|3.8| this whole part here is the feature extractor parts, I call
329.92|10.72| it again features. So it's essentially that part up to up
340.64|3.72| to here. And then the right side here is the multi layer
344.36|5.84| perception part. So yeah, I call it again, classifier. I also
350.2|3.2| have an adaptive average pooling here. So what that will do is
353.4|7.0| it will take whatever size that is, whatever size comes out of
360.4|6.32| here, and pulls it such by averaging such that the output
366.72|4.44| feature met will be six by six. So in that way, I can rely on
371.16|4.56| that that what comes in here in the linear is 256 times six
375.72|3.12| times six, because here, I know that the number of channels that
378.84|4.84| comes out of here is 2256. So if I go back here, that's 256. And
383.68|3.8| I know the size is six by six. That's I'm saying it by average
387.48|3.84| pooling. So if I give it larger images, if I give it images that
391.32|5.4| are 150 times 150, it will also work the same way, I don't have
396.72|5.24| to adjust my code. However, if I have images that are smaller
402.32|4.52| than whatever I have as input, like the original cipher 10,
406.84|5.16| 10, this will not work because at this stage, we may have a
412.0|2.88| three by three or something like that. And this doesn't upscale
414.88|3.8| it only downscales, but doesn't upscale. So what I'm saying is,
418.68|5.32| if I would change it to 30 times 30, everything on it, I have to
424.0|3.16| also change that to something like smaller than 30. You get
427.16|4.12| the idea. If this is smaller than 70 times 70, this will
431.28|3.76| fail. Because what comes out of here is not three, six by six,
435.04|3.76| it might be three by three, for instance. So adaptive average
438.8|3.92| pooling will downsize something to a common size. And this will
442.72|5.48| allow me then also to receive larger inputs. So in that way,
448.52|3.96| the architecture is not so picky towards the exact resolution.
455.36|2.96| If I wanted to train, let's say on a different data set. Okay,
458.32|4.72| so here, that's my fully connected part. So I'm using
463.04|3.12| dropout in between that they use dropout, actually, or did I think
466.16|3.36| I just added it because I had the overfitting? Yeah, I think
469.52|3.0| so. That's, I don't think they had it in the paper, but I would
472.52|3.0| have to double check. I can't see it here. I would have to
475.54|2.66| double check in the paper. But I'm pretty sure that's something
478.2|3.16| added because I was having massive issues with overfitting.
481.4|5.04| I will show you next. Alright, so here we have the features.
488.88|2.84| Then we have this average pooling that brings everything
491.72|4.12| down to six by six. And then here, this is my fully connected
495.84|2.84| one, I could have used a flattening actually, could have
498.68|8.4| used the where's it could have used the flatten. But well, I
507.08|4.72| didn't think the flatten is also relatively new. So I sometimes
511.8|5.48| forget to use it because it's just recently added. And then
517.28|3.28| I'm calling my classifier, which gives me my predictions. And
520.56|4.04| that is, then here, everything is the same as before. I'm
524.6|4.16| using again, the same SGD with momentum, running rate
528.76|4.76| scheduler. Same thing. But now it takes much longer to train.
533.96|3.96| So it took I was running it for 200 epochs. And it took a long
537.92|11.68| time. Took approximately three hours almost. And what was also
549.6|2.76| interesting is, so usually what I do is when I train a network,
552.36|4.84| I take a look at, at this output here. So it's maybe also as a
557.2|2.6| tip for your homework three, when you train the network, you
559.8|2.8| want to see that the validation goes up. And you want to see
562.6|3.4| that the loss goes down. Here, it's going up, I would give it
566.0|2.24| maybe sometimes a bit more time, sometimes it goes a little bit
568.28|3.44| up. But you want to see at least maybe four or five, six epochs
572.6|3.36| that the loss decreases, if you see that does not increase, or
575.96|2.88| it even increases, I would actually stop the training
578.84|2.92| because then it's usually that you have a learning rate that is
581.76|5.52| too large, or other issues. So but yeah, here I saw, okay, it's
587.28|5.68| training well. And then I saw, okay, what's going on? 686667.
592.96|4.36| No, it's something's weird here. And somehow, I honestly almost
597.32|3.8| wanted to stop it here. But I was busy with other things. And
601.12|5.16| I just let it continue training. It goes even down to 62. I
606.28|2.32| didn't stare at it the whole time, because it was like 25
608.6|3.16| minutes, I was doing something else in the meantime. And then I
611.76|3.44| was quite surprised when I looked at the plot. I had
615.2|2.84| actually this double descent phenomenon that I talked about
618.04|4.48| in a previous lecture. So first of all, the loss went down, and
622.52|2.72| then when went up again, and then with this double descent
625.24|2.56| over the epoch, so the epoch wise double descent, I saw it
628.0|4.24| went down again. And then it stayed here. So you can also see
632.24|3.6| the same thing for the training validation accuracy improves,
635.84|3.44| then it comes worse and then improves again. But overall, you
639.28|4.04| can also see the huge degree of overfitting 20%. That's I had
643.32|2.12| already dropped out, but I didn't help that much. And
645.44|4.6| that's still overfitting. So one thing that might help is maybe
650.04|4.28| adding more dropout, or also adding more data augmentation.
654.56|6.6| So if you go here, if you go here, instead of just random
661.16|3.68| cropping, you could also do something with a color jitter
664.84|4.04| and rotation and things like that, that might also help with
668.88|2.64| the overfitting. So in practice, if you find overfitting like
671.52|3.92| that, but yeah, I was a little bit under time pressure to get
675.64|3.8| this code finished for the lecture. And it already took a
679.44|3.08| long time. So I didn't want to rerun everything to reduce
682.52|2.28| overfitting might be an interesting exercise if you're
684.8|4.76| interested to try this out. Okay, so then I'm just looking at
689.56|4.92| some results. I visualize them. So notice here, I'm doing I'm
694.48|3.2| using this unnormalized function that I implemented somewhere in
697.68|8.16| my helper function, I think I have it here. See, let me maybe
705.84|4.12| double check where I implemented that. Let me scroll up on
709.96|1.6| normalized data sets. Yep.
715.08|3.76| All right here. So here, the unnormalizing is essentially
718.84|4.56| undoing my normalization with this point five. So here, I do
723.4|4.4| the normalization. And here, I'm undoing my normalization so that
727.8|6.12| I can plot the images. So I'm essentially multiplying by the
733.92|4.08| standard deviation, and then adding the mean, and I do that
738.0|3.44| for every channel. That's just a very compact way of writing
741.44|2.72| this, you don't have to understand this in detail. It's
744.16|3.98| just very efficient. I mean, I wanted to just write this in one
748.14|3.5| line itself, writing too much code here. Alright, so
751.64|5.64| essentially, this will unnormalize. So I have to
757.8|2.48| provide the information that I used for normalizing. So I
760.28|3.44| provide them the same way and just as the same thing as the
763.72|6.72| normalizing, but inverse, like reversing it. Alright, so then
770.44|2.32| I give it also the class dictionary with the names so
772.76|2.44| that in my plot here, my show examples, but I can actually see
775.2|3.72| the names, the predictions can see actually, and this looks
778.92|5.64| cool. Here, that's funny. It actually, it gets docs and cats
784.56|2.64| wrong. So the predicted label is dark and the true label is a
787.2|4.48| cat, which I think justifies the fact that so many people work on
791.68|2.42| cats versus dog classifiers, because it's actually a
794.1|5.26| challenging problem. Okay. And then again, my confusion matrix
799.36|4.4| here, just to look at what they get currently wrong, you can see
803.8|2.88| it's kind of interesting, the dog versus cats is a category
806.68|2.8| that is often almost often wrong in this data set. It's kind of
809.48|5.52| funny. Also ship an airplane here. And frog and cat or frog
815.0|4.12| and cat. I mean, you're not that similar. But okay. Yeah, so that
819.12|4.0| is how Alex networks. And it's essentially, overall, it's the
823.12|3.12| same as the net, except that we have no color channels. And the
826.24|4.08| network architecture is of course, bigger. So if I just
830.32|3.32| grow up again, takes longer to train. And it's Yeah, you can
833.64|4.6| see it's it's much bigger than our the net before, which was
838.24|4.2| just, yeah, smaller network. All right, that's it then for the
842.44|3.0| next I mean, okay, let me just briefly go to this one, because
845.44|4.92| I have it. So yeah, I trained another CNN, if you're
850.36|4.96| interested, try to get better accuracy. But it's just a CNN
855.32|3.8| with batch norm and leaky relu and to drop out trying to reduce
859.12|5.16| the overfitting. Um, but yeah, you can see, it was not that
864.28|3.48| much better. It gets some somewhat better accuracy. It
867.76|3.52| trains only 3030 minutes instead of three hours, which is also an
871.28|3.72| improvement. Doesn't have this double descent, but it's still
875.04|3.04| overfitting by a lot. It gets 100% training accuracy, which
878.08|5.92| is quite surprising. So okay, yeah, it's another network gets
884.28|2.44| confuses a deal with an airplane. It's also interesting.
886.72|4.0| Also, the cat was a stock is wrong here again. Yeah, also cat
890.72|2.8| was a stock. It's apparently a challenging, challenging
893.52|4.04| category. All right. So that's it then for this lecture. In the
897.56|4.04| next lecture, we will take a more detailed look into
901.6|2.92| different neural network architectures. I mean, these two
904.84|4.2| Lynette and Alex net are really like beginner architectures.
909.04|3.28| They are quite old, but there are more powerful architectures.
912.32|4.76| And yeah, that's the topic of the next lecture.