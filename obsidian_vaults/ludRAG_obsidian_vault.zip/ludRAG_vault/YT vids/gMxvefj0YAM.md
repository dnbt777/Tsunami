start_time|end_time|text
4.08|4.14| Alright, let's not talk about momentum learning. Momentum is
8.22|4.26| a term that we can add to SGD, such that it takes into account
12.48|4.0| the previous updates, and stabilizing stochastic gradient
16.48|4.8| descent, may essentially making it less noisy. So here's a
21.36|4.2| definition of momentum from physics from Wikipedia here. So
25.56|3.32| in Newtonian mechanics, linear momentum or translational
28.88|3.24| momentum, or simply just momentum is the product of the
32.12|4.14| mass and velocity of an object. Of course, when we talk about
36.26|2.98| stochastic gradient descent and weight updates, we don't have a
39.24|4.48| mass, but we can consider a velocity of the updates like on
43.72|4.48| the other speed of the updates, essentially. So what we are
48.2|3.52| trying to do in momentum learning here is essentially is
51.72|3.88| we are trying to accelerate the convergence by dampening
55.6|3.48| oscillations using this velocity, which is the speed of
59.08|4.76| the movement from previous updates. So by take a kind of
63.84|4.44| taking into consideration how the updates have progressed over
68.28|3.88| the course of the times, we can use that to, you know, to
72.16|2.92| dampen these oscillations, essentially. And this goes back
75.08|6.32| to a paper from 1999. But it's still a very popular technique in
81.4|2.32| deep learning, especially in combination with learning weight
83.72|6.12| decay. So here's an illustration of how this looks like how we
89.84|4.44| can dampen or how these oscillations are dampened. So on
94.28|3.16| the left hand side is just a sketch of how your mini batch
97.44|3.64| learning with SGD might look like where we have due to the
101.08|4.72| noise, this little zigzag, but you can see on average, I mean,
105.8|4.56| there's some, some force going into this direction. And we
110.36|6.24| kind of can use this velocity to get to add this velocity to the
116.6|3.72| updates to dampen out this oscillation such that the
120.32|4.0| oscillations here, we can so it's not not like before, like
124.64|4.56| as noisy as before, it's a little bit dampened. Yeah, so
129.2|5.24| the key takeaway is essentially this in regular gradient descent,
134.68|3.44| we usually move in the opposite direction of the gradient. So
138.12|4.88| it's like the usual update. But now with momentum, we now also
143.04|4.56| move in the average direction of the last few updates. So we look
147.6|3.84| into the average direction from the last updates, essentially,
151.64|6.04| that's our velocity. So why does it help? I mean, it helps with
157.68|4.84| dampening the oscillations, but it can also help us to jump out
162.52|5.0| of local minima. Because imagine this, if you Yeah, if you do
167.52|2.44| the updates, they are maybe noisy, but at some point, you
169.96|3.92| land on a flat surface, then the gradient will be zero, right?
174.24|3.52| And how do you get out of this flat surface? So the velocity
177.76|3.36| term, the additional velocity term can actually help pushing
181.48|5.68| you out of this. Yeah, of this flat surface. So I was trying to
187.16|3.6| illustrate this in this drawing here at the bottom. So here,
190.76|4.44| this is our loss for some weight w i. So again, just a very
195.2|6.44| simplified loss on curve. And this red line here, the one here,
201.64|4.88| this is our loss. And these circles are, let's say the
206.52|4.6| current locations and a current time step. So let's say this is
211.12|3.8| time step one, time step two, time step three, time step
214.92|5.48| four. And it may happen. So you go down here. So there's a
220.4|4.88| certain slope, right? So this is fine. And then the next update
225.28|3.88| is this one. But now you have this flat surface. So there's
229.16|3.36| essentially no gradient, right? So there's no slope, it's flat.
232.8|3.48| So regular gradient descent would stop at this point, because
236.28|3.32| it's a flat surface, but this velocity, because it's taking
239.6|2.36| the average direction of the previous updates into account,
242.24|4.0| may give it just the necessary push to fall further down,
246.24|6.12| further down, basically. So I'm using these velocity terms that
252.36|3.68| can help us basically escaping local minimal settle points
256.04|5.8| where we have, yeah, we have flat gradients. Yes. So how does
261.84|4.92| this velocity based updating look like concretely? He was
266.76|4.68| trying to sketch this out. Let's walk through it step by step. So
272.32|2.64| let's start at the bottom here. So this is essentially if you
274.96|2.36| just look at this without reading anything here on the
277.32|4.56| slide, this is essentially our regular gradient descent update
281.96|5.6| that we do in SGD. So let's say we want to update weight w i j
287.56|4.76| in the network. So t is the time step. So at the current, let's
292.32|3.12| say t plus one is the current time step or then the way that
295.44|3.28| is used for the next iteration. So we consider the weight at the
298.72|6.88| current time step minus delta w i j t at the current time step
305.6|6.82| where this is here the partial derivative of the loss, the loss
312.42|4.94| with respect to that weight times the learning rate at so
317.36|3.24| this whole thing here, that's how much we change the weights
320.6|5.36| essentially. Okay, let me delete that notation because there will
325.96|3.0| be lots of more notation on that slide, I don't want to make it
328.96|2.72| too cluttered. But again, so this at the bottom is
331.84|2.92| essentially how the regular gradient descent would look
334.76|5.36| like. Now, instead of using, I have it actually up here, sub
340.12|2.52| using the regular partial derivative of the loss with
342.64|2.88| respect to the weights multiplied by the learning rate
345.52|6.0| eta, we modify this. So we add an additional term here, this is
351.52|5.8| shown here. So we are adding it to this regular update. And this
357.32|5.72| is the we call this whole thing, essentially the velocity. So
363.04|4.8| instead of just using this, this part, which we usually used
367.84|4.24| before, we now have this party on the left hand side. So what
372.08|7.84| is this? So it is the delta w term from the previous time step
379.92|4.62| time t minus one, that's the velocity of the previous time
384.54|5.74| step. And the alpha here, this is the momentum rate. Usually in
390.28|3.2| practice, we use a momentum rate between point nine and point
393.48|6.04| 999. And you can think of it as a as a friction or dampening
399.52|6.72| parameter, right? So the larger we make this, the larger this
406.24|3.92| term, the previous velocity term will become right. So in that
410.16|9.4| way, the larger this this alpha is, the more the normal update
419.56|4.34| will be influenced by the previous update. So this is
423.9|5.38| essentially like a moving average in a way. Yeah, this is
429.28|5.56| essentially it right. So we are essentially just adding the
434.84|3.44| previous update to it multiplied by a certain number. And
438.28|3.68| essentially, you can think of it as a moving average. Well, yeah,
441.96|4.96| that can is a velocity term, or momentum term. And this one,
447.2|4.76| then we call it the velocity. And we use it then to update the
451.96|3.84| weights. And this is essentially how momentum works. How does
456.04|5.4| momentum look like in, like in practice without my scribbled
461.44|3.6| the sketches that I showed you before. So here's actually a
465.04|4.04| real simulation of momentum. So here, they call that alpha term
469.52|6.12| beta. But yeah, we call it alpha and same thing. And here, I'm
475.64|4.36| showing you this for two momentum values, here's zero
480.0|3.84| momentum. So that's just like the regular gradient descent.
484.28|4.52| And again, this is like for a very nice loss surface here. In
488.8|3.08| real world scenarios for deep learning, you won't have such a
491.88|3.72| nice loss surface. But this is just a simplification, of course.
496.08|4.96| So here, you can see it's very noisy, very oscillating. And
501.04|3.4| with momentum, it oscillates less, essentially. So it's a
504.44|2.76| bit more stable, because it's considering the average
507.2|2.84| direction, you can also see there are probably fewer
510.04|2.96| updates, yeah, definitely fewer updates, because you can see,
513.28|2.72| these points are very close to each other, whereas these are
516.0|6.44| more spaced out. Yeah, this is essentially how momentum works
522.44|3.96| and looks like. In the next video, I will talk about
526.44|4.28| adaptive learning rates. First, there's also an algorithm called
530.76|3.72| RMS prop. And then we will combine these adaptive learning
534.48|4.56| rate concepts with momentum, which will yield Adam, which is
539.04|4.04| probably the most widely used SGD based optimizer in deep
543.08|3.24| learning.