Linear Algebra
Done Wrong
Sergei Treil
Department of Mathematics, Brown University
Copyright cSergei Treil, 2004, 2009, 2011, 2014, 2017
This book is licensed under a Creative Commons
Attribution-NonCommercial-NoDerivs 3.0 Unported License ,
seehttps://creativecommons.org/licenses/by-nc-nd/3.0/
Additional details: You can use this book free of charge for non-
commercial purposes, in particular for studying and/or teaching. You can
print paper copies of the book or its parts using either personal printer or
professional printing services. Instructors teaching a class (or their institu-
tions) can provide students with printed copies of the book and charge the
fee to cover the cost of printing; however the students should have an option
to use the free electronic version.
Preface
The title of the book sounds a bit mysterious. Why should anyone read this
book if it presents the subject in a wrong way? What is particularly done
\wrong" in the book?
Before answering these questions, let me rst describe the target au-
dience of this text. This book appeared as lecture notes for the course
\Honors Linear Algebra". It supposed to be a rstlinear algebra course for
mathematically advanced students. It is intended for a student who, while
not yet very familiar with abstract reasoning, is willing to study more rigor-
ous mathematics than what is presented in a \cookbook style" calculus type
course. Besides being a rst course in linear algebra it is also supposed to be
a rst course introducing a student to rigorous proof, formal denitions|in
short, to the style of modern theoretical (abstract) mathematics. The target
audience explains the very specic blend of elementary ideas and concrete
examples, which are usually presented in introductory linear algebra texts
with more abstract denitions and constructions typical for advanced books.
Another specic of the book is that it is not written by or for an alge-
braist. So, I tried to emphasize the topics that are important for analysis,
geometry, probability, etc., and did not include some traditional topics. For
example, I am only considering vector spaces over the elds of real or com-
plex numbers. Linear spaces over other elds are not considered at all, since
I feel time required to introduce and explain abstract elds would be better
spent on some more classical topics, which will be required in other dis-
ciplines. And later, when the students study general elds in an abstract
algebra course they will understand that many of the constructions studied
in this book will also work for general elds.
iii
iv Preface
Also, I treat only nite-dimensional spaces in this book and a basis
always means a nite basis. The reason is that it is impossible to say some-
thing non-trivial about innite-dimensional spaces without introducing con-
vergence, norms, completeness etc., i.e. the basics of functional analysis.
And this is denitely a subject for a separate course (text). So, I do not
consider innite Hamel bases here: they are not needed in most applica-
tions to analysis and geometry, and I feel they belong in an abstract algebra
course.
Notes for the instructor. There are several details that distinguish this
text from standard advanced linear algebra textbooks. First concerns the
denitions of bases, linearly independent, and generating sets. In the book
I rst dene a basis as a system with the property that any vector admits
a unique representation as a linear combination. And then linear indepen-
dence and generating system properties appear naturally as halves of the
basis property, one being uniqueness and the other being existence of the
representation.
The reason for this approach is that I feel the concept of a basis is a much
more important notion than linear independence: in most applications we
really do not care about linear independence, we need a system to be a basis.
For example, when solving a homogeneous system, we are not just looking
for linearly independent solutions, but for the correct number of linearly
independent solutions, i.e. for a basis in the solution space.
And it is easy to explain to students, why bases are important: they
allow us to introduce coordinates, and work with Rn(orCn) instead of
working with an abstract vector space. Furthermore, we need coordinates
to perform computations using computers, and computers are well adapted
to working with matrices. Also, I really do not know a simple motivation
for the notion of linear independence.
Another detail is that I introduce linear transformations before teach-
ing how to solve linear systems. A disadvantage is that we did not prove
until Chapter 2 that only a square matrix can be invertible as well as some
other important facts. However, having already dened linear transforma-
tion allows more systematic presentation of row reduction. Also, I spend a
lot of time (two sections) motivating matrix multiplication. I hope that I
explained well why such a strange looking rule of multiplication is, in fact,
a very natural one, and we really do not have any choice here.
Many important facts about bases, linear transformations, etc., like the
fact that any two bases in a vector space have the same number of vectors,
are proved in Chapter 2 by counting pivots in the row reduction. While most
of these facts have \coordinate free" proofs, formally not involving Gaussian
Preface v
elimination, a careful analysis of the proofs reveals that the Gaussian elim-
ination and counting of the pivots do not disappear, they are just hidden
in most of the proofs. So, instead of presenting very elegant (but not easy
for a beginner to understand) \coordinate-free" proofs, which are typically
presented in advanced linear algebra books, we use \row reduction" proofs,
more common for the \calculus type" texts. The advantage here is that it is
easy to see the common idea behind all the proofs, and such proofs are easier
to understand and to remember for a reader who is not very mathematically
sophisticated.
I also present in Section 8 of Chapter 2 a simple and easy to remember
formalism for the change of basis formula.
Chapter 3 deals with determinants. I spent a lot of time presenting a
motivation for the determinant, and only much later give formal denitions.
Determinants are introduced as a way to compute volumes. It is shown that
if we allow signed volumes, to make the determinant linear in each column
(and at that point students should be well aware that the linearity helps a
lot, and that allowing negative volumes is a very small price to pay for it),
and assume some very natural properties, then we do not have any choice
and arrive to the classical denition of the determinant. I would like to
emphasize that initially I do not postulate antisymmetry of the determinant;
I deduce it from other very natural properties of volume.
Note, that while formally in Chapters 1{3 I was dealing mainly with real
spaces, everything there holds for complex spaces, and moreover, even for
the spaces over arbitrary elds.
Chapter 4 is an introduction to spectral theory, and that is where the
complex space Cnnaturally appears. It was formally dened in the begin-
ning of the book, and the denition of a complex vector space was also given
there, but before Chapter 4 the main object was the real space Rn. Now
the appearance of complex eigenvalues shows that for spectral theory the
most natural space is the complex space Cn, even if we are initially dealing
with real matrices (operators in real spaces). The main accent here is on the
diagonalization, and the notion of a basis of eigesnspaces is also introduced.
Chapter 5 dealing with inner product spaces comes after spectral theory,
because I wanted to do both the complex and the real cases simultaneously,
and spectral theory provides a strong motivation for complex spaces. Other
then the motivation, Chapters 4 and 5 do not depend on each other, and an
instructor may do Chapter 5 rst.
Although I present the Jordan canonical form in Chapter 9, I usually
do not have time to cover it during a one-semester course. I prefer to spend
more time on topics discussed in Chapters 6 and 7 such as diagonalization
vi Preface
of normal and self-adjoint operators, polar and singular values decomposi-
tion, the structure of orthogonal matrices and orientation, and the theory
of quadratic forms.
I feel that these topics are more important for applications, then the
Jordan canonical form, despite the denite beauty of the latter. However, I
added Chapter 9 so the instructor may skip some of the topics in Chapters
6 and 7 and present the Jordan Decomposition Theorem instead.
I also included (new for 2009) Chapter 8, dealing with dual spaces and
tensors. I feel that the material there, especially sections about tensors, is a
bit too advanced for a rst year linear algebra course, but some topics (for
example, change of coordinates in the dual space) can be easily included in
the syllabus. And it can be used as an introduction to tensors in a more
advanced course. Note, that the results presented in this chapter are true
for an arbitrary eld.
I had tried to present the material in the book rather informally, prefer-
ring intuitive geometric reasoning to formal algebraic manipulations, so to
a purist the book may seem not suciently rigorous. Throughout the book
I usually (when it does not lead to the confusion) identify a linear transfor-
mation and its matrix. This allows for a simpler notation, and I feel that
overemphasizing the dierence between a transformation and its matrix may
confuse an inexperienced student. Only when the dierence is crucial, for
example when analyzing how the matrix of a transformation changes under
the change of the basis, I use a special notation to distinguish between a
transformation and its matrix.
Contents
Preface iii
Chapter 1. Basic Notions 1
x1. Vector spaces 1
x2. Linear combinations, bases. 6
x3. Linear Transformations. Matrix{vector multiplication 12
x4. Linear transformations as a vector space 17
x5. Composition of linear transformations and matrix multiplication. 19
x6. Invertible transformations and matrices. Isomorphisms 24
x7. Subspaces. 30
x8. Application to computer graphics. 31
Chapter 2. Systems of linear equations 39
x1. Dierent faces of linear systems. 39
x2. Solution of a linear system. Echelon and reduced echelon forms 40
x3. Analyzing the pivots. 46
x4. Finding A 1by row reduction. 52
x5. Dimension. Finite-dimensional spaces. 54
x6. General solution of a linear system. 56
x7. Fundamental subspaces of a matrix. Rank. 59
x8. Representation of a linear transformation in arbitrary bases.
Change of coordinates formula. 69
Chapter 3. Determinants 75
vii
viii Contents
x1. Introduction. 75
x2. What properties determinant should have. 76
x3. Constructing the determinant. 78
x4. Formal denition. Existence and uniqueness of the determinant. 86
x5. Cofactor expansion. 90
x6. Minors and rank. 96
x7. Review exercises for Chapter 3. 96
Chapter 4. Introduction to spectral theory (eigenvalues and
eigenvectors) 99
x1. Main denitions 100
x2. Diagonalization. 105
Chapter 5. Inner product spaces 117
x1. Inner product in RnandCn. Inner product spaces. 117
x2. Orthogonality. Orthogonal and orthonormal bases. 125
x3. Orthogonal projection and Gram-Schmidt orthogonalization 129
x4. Least square solution. Formula for the orthogonal projection 136
x5. Adjoint of a linear transformation. Fundamental subspaces
revisited. 142
x6. Isometries and unitary operators. Unitary and orthogonal
matrices. 146
x7. Rigid motions in Rn151
x8. Complexication and decomplexication 154
Chapter 6. Structure of operators in inner product spaces. 163
x1. Upper triangular (Schur) representation of an operator. 163
x2. Spectral theorem for self-adjoint and normal operators. 165
x3. Polar and singular value decompositions. 171
x4. Applications of the singular value decomposition. 179
x5. Structure of orthogonal matrices 187
x6. Orientation 193
Chapter 7. Bilinear and quadratic forms 197
x1. Main denition 197
x2. Diagonalization of quadratic forms 200
x3. Silvester's Law of Inertia 206
x4. Positive denite forms. Minimax characterization of eigenvalues
and the Silvester's criterion of positivity 208
Contents ix
x5. Positive denite forms and inner products 214
Chapter 8. Dual spaces and tensors 217
x1. Dual spaces 217
x2. Dual of an inner product space 224
x3. Adjoint (dual) transformations and transpose. Fundamental
subspace revisited (once more) 227
x4. What is the dierence between a space and its dual? 232
x5. Multilinear functions. Tensors 239
x6. Change of coordinates formula for tensors. 247
Chapter 9. Advanced spectral theory 253
x1. Cayley{Hamilton Theorem 253
x2. Spectral Mapping Theorem 257
x3. Generalized eigenspaces. Geometric meaning of algebraic
multiplicity 259
x4. Structure of nilpotent operators 266
x5. Jordan decomposition theorem 272
Index 275

Chapter 1
Basic Notions
1. Vector spaces
A vector space Vis a collection of objects, called vectors (denoted in this
book by lowercase bold letters, like v), along with two operations, addition
of vectors and multiplication by a number (scalar)1, such that the following
8 properties (the so-called axioms of a vector space) hold:
The rst 4 properties deal with the addition:
1. Commutativity: v+w=w+vfor all v;w2V; A question arises,
\How one can mem-
orize the above prop-
erties?" And the an-
swer is that one does
not need to, see be-
low!2. Associativity: ( u+v) +w=u+ (v+w) for all u;v;w2V;
3. Zero vector: there exists a special vector, denoted by 0such that
v+0=vfor all v2V;
4. Additive inverse: For every vector v2Vthere exists a vector w2V
such that v+w=0. Such additive inverse is usually denoted as
 v;
The next two properties concern multiplication:
5. Multiplicative identity: 1 v=vfor all v2V;
1We need some visual distinction between vectors and other objects, so in this book we use
bold lowercase letters for vectors and regular lowercase letters for numbers (scalars). In some (more
advanced) books Latin letters are reserved for vectors, while Greek letters are used for scalars; in
even more advanced texts any letter can be used for anything and the reader must understand
from the context what each symbol means. I think it is helpful, especially for a beginner to have
some visual distinction between dierent objects, so a bold lowercase letters will always denote a
vector. And on a blackboard an arrow (like in ~ v) is used to identify a vector.
1
2 1. Basic Notions
6. Multiplicative associativity: ( )v=(v) for all v2Vand all
scalars,;
And nally, two distributive properties, which connect multipli-
cation and addition:
7.(u+v) =u+vfor all u;v2Vand all scalars ;
8. (+)v=v+vfor all v2Vand all scalars ,.
Remark. The above properties seem hard to memorize, but it is not nec-
essary. They are simply the familiar rules of algebraic manipulations with
numbers, that you know from high school. The only new twist here is that
you have to understand what operations you can apply to what objects. You
can add vectors, and you can multiply a vector by a number (scalar). Of
course, you can do with number all possible manipulations that you have
learned before. But, you cannot multiply two vectors, or add a number to
a vector.
Remark. It is easy to prove that zero vector 0is unique, and that given
v2Vits additive inverse  vis also unique.
It is also not hard to show using properties 5, 6 and 8 that 0= 0vfor
anyv2V, and that v= ( 1)v. Note, that to do this one still needs to
use other properties of a vector space in the proofs, in particular properties
3 and 4.
If the scalars are the usual real numbers, we call the space Vareal
vector space. If the scalars are the complex numbers, i.e. if we can multiply
vectors by complex numbers, we call the space Vacomplex vector space.
Note, that any complex vector space is a real vector space as well (if we
can multiply by complex numbers, we can multiply by real numbers), but
not the other way around.
It is also possible to consider a situation when the scalars are elements of If you do not know
what a eld is, do
not worry, since in
this book we con-
sider only the case
of real and complex
spaces.an arbitrary eld F. In this case we say that Vis a vector space over the eld
F. Although many of the constructions in the book (in particular, everything
in Chapters 1{3) work for general elds, in this text we are considering only
real and complex vector spaces.
If we do not specify the set of scalars, or use a letter Ffor it, then the
results are true for both real and complex spaces. If we need to distinguish
real and complex cases, we will explicitly say which case we are considering.
Note, that in the denition of a vector space over an arbitrary eld, we
require the set of scalars to be a eld, so we can always divide (without a
remainder) by a non-zero scalar. Thus, it is possible to consider vector space
over rationals, but not over the integers.
1. Vector spaces 3
1.1. Examples.
Example. The space Rnconsists of all columns of size n,
v=0
BBB@v1
v2
...
vn1
CCCA
whose entries are real numbers. Addition and multiplication are dened
entrywise, i.e.
0
BBB@v1
v2
...
vn1
CCCA=0
BBB@v1
v2
...
vn1
CCCA;0
BBB@v1
v2
...
vn1
CCCA+0
BBB@w1
w2
...
wn1
CCCA=0
BBB@v1+w1
v2+w2
...
vn+wn1
CCCA
Example. The space Cnalso consists of columns of size n, only the entries
now are complex numbers. Addition and multiplication are dened exactly
as in the case of Rn, the only dierence is that we can now multiply vectors
bycomplex numbers, i.e. Cnis acomplex vector space.
Many results in this text are true for both RnandCn. In such cases we
will use notation Fn.
Example. The spaceMmn(also denoted as Mm;n) ofmnmatrices: the
addition and multiplication by scalars are dened entrywise. If we allow
only real entries (and so only multiplication only by reals), then we have a
real vector space; if we allow complex entries and multiplication by complex
numbers, we then have a complex vector space.
Formally, we have to distinguish between between real and complex
cases, i.e. write something like MR
m;norMC
m;n. However, in most situa-
tions there is no dierence between real and complex case, and there is no
need to specify which case we are considering. If there is a dierence we say
explicitly which case we are considering.
Remark. As we mentioned above, the axioms of a vector space are just the
familiar rules of algebraic manipulations with (real or complex) numbers,
so if we put scalars (numbers) for the vectors, all axioms will be satised.
Thus, the set Rof real numbers is a real vector space, and the set Cof
complex numbers is a complex vector space.
More importantly, since in the above examples all vector operations
(addition and multiplication by a scalar) are performed entrywise, for these
examples the axioms of a vector space are automatically satised because
they are satised for scalars (can you see why?). So, we do not have to
4 1. Basic Notions
check the axioms, we get the fact that the above examples are indeed vector
spaces for free!
The same can be applied to the next example, the coecients of the
polynomials play the role of entries there.
Example. The space Pnof polynomials of degree at most n, consists of all
polynomials pof form
p(t) =a0+a1t+a2t2+:::+antn;
wheretis the independent variable. Note, that some, or even all, coecients
akcan be 0.
In the case of real coecients akwe have a real vector space, complex
coecient give us a complex vector space. Again, we will specify whether we
treating real or complex case only when it is essential; otherwise everything
applies to both cases.
Question: What are zero vectors in each of the above examples?
1.2. Matrix notation. Anmnmatrix is a rectangular array with m
rows andncolumns. Elements of the array are called entries of the matrix.
It is often convenient to denote matrix entries by indexed letters: the
rst index denotes the number of the row, where the entry is, and the second
one is the number of the column. For example
(1.1) A= (aj;k)m;
j=1;n
k=1=0
BBB@a1;1a1;2::: a 1;n
a2;1a2;2::: a 2;n
.........
am;1am;2::: am;n1
CCCA
is a general way to write an mnmatrix.
Very often for a matrix Athe entry in row number jand column number
kis denoted by Aj;kor (A)j;k, and sometimes as in example (1.1) above the
same letter but in lowercase is used for the matrix entries.
Given a matrix A, its transpose (or transposed matrix) AT, is dened
by transforming the rows of Ainto the columns. For example
1 2 3
4 5 6T
=0
@1 4
2 5
3 61
A:
So, the columns of ATare the rows of Aand vice versa, the rows of ATare
the columns of A.
The formal denition is as follows: ( AT)j;k= (A)k;jmeaning that the
entry ofATin the row number jand column number kequals the entry of
Ain the row number kand row number j.
1. Vector spaces 5
The transpose of a matrix has a very nice interpretation in terms of
linear transformations, namely it gives the so-called adjoint transformation.
We will study this in detail later, but for now transposition will be just a
useful formal operation.
One of the rst uses of the transpose is that we can write a column
vector x2Fn(recall that FisRorC) asx= (x1;x2;:::;xn)T. If we put
the column vertically, it will use signicantly more space.
Exercises.
1.1. Letx= (1;2;3)T,y= (y1;y2;y3)T,z= (4;2;1)T. Compute 2 x, 3y,x+ 2y 
3z.
1.2. Which of the following sets (with natural addition and multiplication by a
scalar) are vector spaces. Justify your answer.
a) The set of all continuous functions on the interval [0 ;1];
b) The set of all non-negative functions on the interval [0 ;1];
c) The set of all polynomials of degree exactlyn;
d) The set of all symmetric nnmatrices, i.e. the set of matrices A=
faj;kgn
j;k=1such thatAT=A.
1.3. True or false:
a) Every vector space contains a zero vector;
b) A vector space can have more than one zero vector;
c) Anmnmatrix has mrows andncolumns;
d) Iffandgare polynomials of degree n, thenf+gis also a polynomial of
degreen;
e) Iffandgare polynomials of degree at most n, thenf+gis also a
polynomial of degree at most n
1.4. Prove that a zero vector 0of a vector space Vis unique.
1.5. What matrix is the zero vector of the space M23?
1.6. Prove that the additive inverse, dened in Axiom 4 of a vector space is unique.
1.7. Prove that 0 v=0for any vector v2V.
1.8. Prove that for any vector vits additive inverse  vis given by ( 1)v.
6 1. Basic Notions
2. Linear combinations, bases.
LetVbe a vector space, and let v1;v2;:::;vp2Vbe a collection of vectors.
Alinear combination of vectors v1;v2;:::;vpis a sum of form
1v1+2v2+:::+pvp=pX
k=1kvk:
Denition 2.1. A system of vectors v1;v2;:::vn2Vis called a basis (for
the vector space V) if any vector v2Vadmits a unique representation as
a linear combination
v=1v1+2v2+:::+nvn=nX
k=1kvk:
The coecients 1;2;:::;nare called coordinates of the vector v(in the
basis, or with respect to the basis v1;v2;:::;vn).
Another way to say that v1;v2;:::;vnis a basis is to say that for any
possible choice of the right side v, the equation x1v1+x2v2+:::+xmvn=v
(with unknowns xk) has a unique solution.
Before discussing any properties of bases2, let us give a few examples,
showing that such objects exist, and that it makes sense to study them.
Example 2.2. In the rst example the space VisFn, where Fis either R
orC. Consider vectors
e1=0
BBBBB@1
0
0
...
01
CCCCCA;e2=0
BBBBB@0
1
0
...
01
CCCCCA;e3=0
BBBBB@0
0
1
...
01
CCCCCA;:::; en=0
BBBBB@0
0
0
...
11
CCCCCA;
(the vector ekhas all entries 0 except the entry number k, which is 1). The
system of vectors e1;e2;:::;enis a basis in Fn. Indeed, any vector
v=0
BBB@x1
x2
...
xn1
CCCA2Fn
can be represented as the linear combination
v=x1e1+x2e2+:::xnen=nX
k=1xkek
2the plural for the \basis" is bases , the same as the plural for \base"
2. Linear combinations, bases. 7
and this representation is unique. The system e1;e2;:::;en2Fnis called
the standard basis inFn
Example 2.3. In this example the space is the space Pnof the polynomials
of degree at most n. Consider vectors (polynomials) e0;e1;e2;:::;en2Pn
dened by
e0:= 1;e1:=t;e2:=t2;e3:=t3; :::; en:=tn:
Clearly, any polynomial p,p(t) =a0+a1t+a2t2+:::+antnadmits a unique
representation
p=a0e0+a1e1+:::+anen:
So the system e0;e1;e2;:::;en2Pnis a basis in Pn. We will call it the
standard basis in Pn.
Remark 2.4. If a vector space Vhas a basis v1;v2;:::;vn, then any vector
vis uniquely dened by its coecients in the decomposition v=Pn
k=1kvk.This is a very im-
portant remark, that
will be used through-
out the book. It al-
lows us to translate
any statement about
the standard column
spaceFnto a vector
spaceVwith a basis
v1;v2;:::;vnSo, if we stack the coecients kin a column, we can operate with them
as if they were column vectors, i.e. as with elements of Fn(again here Fis
either RorC, but everything also works for an abstract eld F).
Namely, if v=Pn
k=1kvkandw=Pn
k=1kvk, then
v+w=nX
k=1kvk+nX
k=1kvk=nX
k=1(k+k)vk;
i.e. to get the column of coordinates of the sum one just need to add the
columns of coordinates of the summands. Similarly, to get the coordinates
ofvwe need simply to multiply the column of coordinates of vby.
2.1. Generating and linearly independent systems. The denition
of a basis says that any vector admits a unique representation as a linear
combination. This statement is in fact two statements, namely that the rep-
resentation exists and that it is unique. Let us analyze these two statements
separately.
If we only consider the existence we get the following notion
Denition 2.5. A system of vectors v1;v2;:::;vp2Vis called a generating
system (also a spanning system , or a complete system ) inVif any vector
v2Vadmits representation as a linear combination
v=1v1+2v2+:::+pvp=pX
k=1kvk:
The only dierence from the denition of a basis is that we do not assume
that the representation above is unique.
8 1. Basic Notions
The words generating ,spanning andcomplete here are synonyms. I per-
sonally prefer the term complete, because of my operator theory background.
Generating and spanning are more often used in linear algebra textbooks.
Clearly, any basis is a generating (complete) system. Also, if we have a
basis, say v1;v2;:::;vn, and we add to it several vectors, say vn+1;:::;vp,
then the new system will be a generating (complete) system. Indeed, we can
represent any vector as a linear combination of the vectors v1;v2;:::;vn,
and just ignore the new ones (by putting corresponding coecients k= 0).
Now, let us turn our attention to the uniqueness. We do not want to
worry about existence, so let us consider the zero vector 0, which always
admits a representation as a linear combination.
Denition. A linear combination 1v1+2v2+:::+pvpis called trivial
ifk= 08k.
A trivial linear combination is always (for all choices of vectors
v1;v2;:::;vp) equal to 0, and that is probably the reason for the name.
Denition. A system of vectors v1;v2;:::;vp2Vis called linearly inde-
pendent if only the trivial linear combination (Pp
k=1kvkwithk=08k)
of vectors v1;v2;:::;vpequals 0.
In other words, the system v1;v2;:::;vpis linearly independent i the
equationx1v1+x2v2+:::+xpvp=0(with unknowns xk) has only trivial
solutionx1=x2=:::=xp= 0.
If a system is not linearly independent, it is called linearly dependent .
By negating the denition of linear independence, we get the following
Denition. A system of vectors v1;v2;:::;vpis called linearly dependent
if0can be represented as a nontrivial linear combination, 0=Pp
k=1kvk.
Non-trivial here means that at least one of the coecient kis non-zero.
This can be (and usually is) written asPp
k=1jkj6= 0.
So, restating the denition we can say, that a system is linearly depen-
dent if and only if there exist scalars 1;2;:::;p,Pp
k=1jkj6= 0 such
thatpX
k=1kvk=0:
An alternative denition (in terms of equations) is that a system v1;
v2;:::;vpis linearly dependent i the equation
x1v1+x2v2+:::+xpvp=0
(with unknowns xk) has a non-trivial solution. Non-trivial, once again
means that at least one of xkis dierent from 0, and it can be written
asPp
k=1jxkj6= 0.
2. Linear combinations, bases. 9
The following proposition gives an alternative description of linearly de-
pendent systems.
Proposition 2.6. A system of vectors v1;v2;:::;vp2Vis linearly de-
pendent if and only if one of the vectors vkcan be represented as a linear
combination of the other vectors,
(2.1) vk=pX
j=1
j6=kjvj:
Proof. Suppose the system v1;v2;:::;vpis linearly dependent. Then there
exist scalars k,Pp
k=1jkj6= 0 such that
1v1+2v2+:::+pvp=0:
Letkbe the index such that k6= 0. Then, moving all terms except kvk
to the right side we get
kvk= pX
j=1
j6=kjvj:
Dividing both sides by kwe get (2.1) with j= j=k.
On the other hand, if (2.1) holds, 0can be represented as a non-trivial
linear combination
vk pX
j=1
j6=kjvj=0:

Obviously, any basis is a linearly independent system. Indeed, if a system
v1;v2;:::;vnis a basis, 0admits a unique representation
0=1v1+2v2+:::+nvn=nX
k=1kvk:
Since the trivial linear combination always gives 0, the trivial linear combi-
nation must be the only one giving 0.
So, as we already discussed, if a system is a basis it is a complete (gen-
erating) and linearly independent system. The following proposition shows
that the converse implication is also true.
Proposition 2.7. A system of vectors v1;v2;:::;vn2Vis a basis if and In many textbooks
a basis is dened
as a complete and
linearly independent
system. By Propo-
sition 2.7 this deni-
tion is equivalent to
ours.only if it is linearly independent and complete (generating).
10 1. Basic Notions
Proof. We already know that a basis is always linearly independent and
complete, so in one direction the proposition is already proved.
Let us prove the other direction. Suppose a system v1;v2;:::;vnis lin-
early independent and complete. Take an arbitrary vector v2V. Since the
system v1;v2;:::;vnis linearly complete (generating), vcan be represented
as
v=1v1+2v2+:::+nvn=nX
k=1kvk:
We only need to show that this representation is unique.
Suppose vadmits another representation
v=nX
k=1ekvk:
ThennX
k=1(k ek)vk=nX
k=1kvk nX
k=1ekvk=v v=0:
Since the system is linearly independent, k ek= 08k, and thus the
representation v=1v1+2v2+:::+nvnis unique. 
Remark. In many textbooks a basis is dened as a complete and linearly
independent system (by Proposition 2.7 this denition is equivalent to ours).
Although this denition is more common than one presented in this text, I
prefer the latter. It emphasizes the main property of a basis, namely that
any vector admits a unique representation as a linear combination.
Proposition 2.8. Any (nite) generating system contains a basis.
Proof. Suppose v1;v2;:::;vp2Vis a generating (complete) set. If it is
linearly independent, it is a basis, and we are done.
Suppose it is not linearly independent, i.e. it is linearly dependent. Then
there exists a vector vkwhich can be represented as a linear combination of
the vectors vj,j6=k.
Since vkcan be represented as a linear combination of vectors vj,j6=k,
any linear combination of vectors v1;v2;:::;vpcan be represented as a linear
combination of the same vectors without vk(i.e. the vectors vj, 1jp,
j6=k). So, if we delete the vector vk, the new system will still be a complete
one.
If the new system is linearly independent, we are done. If not, we repeat
the procedure.
Repeating this procedure nitely many times we arrive to a linearly
independent and complete system, because otherwise we delete all vectors
and end up with an empty set.
2. Linear combinations, bases. 11
So, any nite complete (generating) set contains a complete linearly
independent subset, i.e. a basis. 
Exercises.
2.1. Find a basis in the space of 3 2 matricesM32.
2.2. True or false:
a) Any set containing a zero vector is linearly dependent
b) A basis must contain 0;
c) subsets of linearly dependent sets are linearly dependent;
d) subsets of linearly independent sets are linearly independent;
e) If1v1+2v2+:::+nvn=0then all scalars kare zero;
2.3. Recall, that a matrix is called symmetric ifAT=A. Write down a basis in the
space of symmetric 22 matrices (there are many possible answers). How many
elements are in the basis?
2.4. Write down a basis for the space of
a) 33 symmetric matrices;
b)nnsymmetric matrices;
c)nnantisymmetric (AT= A) matrices;
2.5. Let a system of vectors v1;v2;:::;vrbe linearly independent but not gen-
erating. Show that it is possible to nd a vector vr+1such that the system
v1;v2;:::;vr;vr+1is linearly independent. Hint: Take for vr+1any vector that
cannot be represented as a linear combinationPr
k=1kvkand show that the system
v1;v2;:::;vr;vr+1is linearly independent.
2.6. Is it possible that vectors v1;v2;v3are linearly dependent, but the vectors
w1=v1+v2,w2=v2+v3andw3=v3+v1are linearly independent ?
12 1. Basic Notions
3. Linear Transformations. Matrix{vector multiplication
Atransformation Tfrom a setXto a setYis a rule that for each argument The words \trans-
formation", \trans-
form", \mapping",
\map", \operator",
\function" all denote
the same object.(input)x2Xassigns a value (output) y=T(x)2Y.
The setXis called the domain ofT, and the set Yis called the target
space orcodomain ofT.
We writeT:X!Yto say that Tis a transformation with the domain
Xand the target space Y.
Denition. LetV,Wbe vector spaces (over the same eld F). A transfor-
mationT:V!Wis called linear if
1.T(u+v) =T(u) +T(v)8u;v2V;
2.T(v) =T(v) for all v2Vand for all scalars 2F.
Properties 1 and 2 together are equivalent to the following one:
T(u+v) =T(u) +T(v) for all u;v2Vand for all scalars ;:
3.1. Examples. You dealt with linear transformation before, may be with-
out even suspecting it, as the examples below show.
Example. Dierentiation: Let V=Pn(the set of polynomials of degree at
mostn),W=Pn 1, and letT:Pn!Pn 1be the dierentiation operator,
T(p) :=p08p2Pn:
Since (f+g)0=f0+g0and (f)0=f0, this is a linear transformation.
Example. Rotation: in this example V=W=R2(the usual coordinate
plane), and a transformation T:R2!R2takes a vector in R2and rotates
it counterclockwise by radians. Since Trotates the plane as a whole,
it rotates as a whole the parallelogram used to dene a sum of two vectors
(parallelogram law). Therefore the property 1 of linear transformation holds.
It is also easy to see that the property 2 is also true.
Example. Reection: in this example again V=W=R2, and the trans-
formationT:R2!R2is the reection in the rst coordinate axis, see the
g. It can also be shown geometrically, that this transformation is linear,
but we will use another way to show that.
Namely, it is easy to write a formula for T,
Tx1
x2
=x1
 x2
and from this formula it is easy to check that the transformation is linear.
3. Linear Transformations. Matrix{vector multiplication 13
 
Figure 1. Rotation
Example. Let us investigate linear transformations T:R!R. Any such
transformation is given by the formula
T(x) =ax wherea=T(1):
Indeed,
T(x) =T(x1) =xT(1) =xa=ax:
So, any linear transformation of Ris just a multiplication by a constant.
3.2. Linear transformations Fn!Fm. Matrix{column multiplica-
tion. It turns out that a linear transformation T:Fn!Fmalso can be
represented as a multiplication, not by a scalar, but by a matrix.
Let us see how. Let T:Fn!Fmbe a linear transformation. What
information do we need to compute T(x) for all vectors x2Fn? My claim is
that it is sucient to know how Tacts on the standard basis e1;e2;:::;en
ofFn. Namely, it is sucient to know nvectors in Fm(i.e. the vectors of
sizem),
a1=T(e1);a2:=T(e2); ::: ; an:=T(en):
14 1. Basic Notions
Indeed, let
x=0
BBB@x1
x2
...
xn1
CCCA:
Then x=x1e1+x2e2+:::+xnen=Pn
k=1xkekand
T(x) =T(nX
k=1xkek) =nX
k=1T(xkek) =nX
k=1xkT(ek) =nX
k=1xkak:
So, if we join the vectors (columns) a1;a2;:::;antogether in a matrix
A= [a1;a2;:::;an] (akbeing thekth column of A,k= 1;2;:::;n ), this
matrix contains all the information about T.
Let us show how one should dene the product of a matrix and a vector
(column) to represent the transformation Tas a product, T(x) =Ax. Let
A=0
BBB@a1;1a1;2::: a 1;n
a2;1a2;2::: a 2;n
.........
am;1am;2::: am;n1
CCCA:
Recall, that the column number kofAis the vector ak, i.e.
ak=0
BBB@a1;k
a2;k
...
am;k1
CCCA:
Then if we want Ax=T(x) we get
Ax=nX
k=1xkak=x10
BBB@a1;1
a2;1
...
am;11
CCCA+x20
BBB@a1;2
a2;2
...
am;21
CCCA+:::+xn0
BBB@a1;n
a2;n
...
am;n1
CCCA:
So, the matrix{vector multiplication should be performed by the follow-
ingcolumn by coordinate rule:
multiply each column of the matrix by the corresponding coordi-
nate of the vector.
Example.
1 2 3
3 2 10
@1
2
31
A= 11
3
+ 22
2
+ 33
1
=14
10
:
3. Linear Transformations. Matrix{vector multiplication 15
The \column by coordinate" rule is very well adapted for parallel com-
puting. It will be also very important in dierent theoretical constructions
later.
However, when doing computations manually, it is more convenient to
compute the result one entry at a time. This can be expressed as the fol-
lowing row by column rule:
To get the entry number kof the result, one need to multiply row
numberkof the matrix by the vector, that is, if Ax=y, then
yk=Pn
j=1ak;jxj,k= 1;2;:::m ;
herexjandykare coordinates of the vectors xandyrespectively, and aj;k
are the entries of the matrix A.
Example.
1 2 3
4 5 60
@1
2
31
A=11 + 22 + 33
41 + 52 + 63
=14
32
3.3. Linear transformations and generating sets. As we discussed
above, linear transformation T(acting from FntoFm) is completely dened
by its values on the standard basis in Fn.
The fact that we consider the standard basis is not essential, one can
consider any basis, even any generating (spanning) set. Namely,
A linear transformation T:V!Wis completely dened by its
values on a generating set (in particular by its values on a basis).
So, if v1;v2;:::;vnis a generating set (in particular, if it is a basis) in V,
andTandT1are linear transformations T;T 1:V!Wsuch that
Tvk=T1vk; k = 1;2;:::;n
thenT=T1.
The proof of this statement is trivial and left as an exercise.
3.4. Conclusions.
To get the matrix of a linear transformation T:Fn!Fmone needs
to join the vectors ak=Tek(where e1;e2;:::;enis the standard
basis in Fn) into a matrix: kth column of the matrix is ak,k=
1;2;:::;n .
If the matrix Aof the linear transformation Tis known, then T(x)
can be found by the matrix{vector multiplication, T(x) =Ax. To
perform matrix{vector multiplication one can use either \column by
coordinate" or \row by column" rule.
16 1. Basic Notions
The latter seems more appropriate for manual computations.
The former is well adapted for parallel computers, and will be used
in dierent theoretical constructions.
For a linear transformation T:Fn!Fm, its matrix is usually denoted
as [T]. However, very often people do not distinguish between a linear trans-
formation and its matrix, and use the same symbol for both. When it does
not lead to confusion, we will also use the same symbol for a transformation
and its matrix.
Since a linear transformation is essentially a multiplication, the notation The notation Tvis
often used instead of
T(v).Tvis often used instead of T(v). We will also use this notation. Note that
the usual order of algebraic operations apply, i.e. Tv+umeansT(v) +u,
notT(v+u).
Remark. In the matrix{vector multiplication Axthe number of columns In the matrix vector
multiplication using
the \row by column"
rule be sure that you
have the same num-
ber of entries in the
row and in the col-
umn. The entries
in the row and in
the column should
end simultaneously:
if not, the multipli-
cation is not dened.of the matrix Amatrix must coincide with the size of the vector x, i.e. a
vector in Fncan only be multiplied by an mnmatrix.
It makes sense, since an mnmatrix denes a linear transformation
Fn!Fm, so vector xmust belong to Fn.
The easiest way to remember this is to remember that if performing
multiplication you run out of some elements faster, then the multiplication
is not dened. For example, if using the \row by column" rule you run
out of row entries, but still have some unused entries in the vector, the
multiplication is not dened. It is also not dened if you run out of vector's
entries, but still have unused entries in the row.
Remark. One does not have to restrict himself to the case of Fnwith
standard basis: everything described in this section works for transformation
between arbitrary vector spaces as long as there is a basis in the domain and
in the target space. Of course, if one changes a basis, the matrix of the linear
transformation will be dierent. This will be discussed later in Section 8.
Exercises.
3.1. Multiply:
a)1 2 3
4 5 60
@1
3
21
A;
b)0
@1 2
0 1
2 01
A1
3
;
c)0
BB@1 2 0 0
0 1 2 0
0 0 1 2
0 0 0 11
CCA0
BB@1
2
3
41
CCA;
4. Linear transformations as a vector space 17
d)0
BB@1 2 0
0 1 2
0 0 1
0 0 01
CCA0
BB@1
2
3
41
CCA.
3.2. Let a linear transformation in R2be the reection in the line x1=x2. Find
its matrix.
3.3. For each linear transformation below nd it matrix
a)T:R2!R3dened byT(x;y)T= (x+ 2y;2x 5y;7y)T;
b)T:R4!R3dened byT(x1;x2;x3;x4)T= (x1+x2+x3+x4;x2 x4;x1+
3x2+ 6x4)T;
c)T:Pn!Pn,Tf(t) =f0(t) (nd the matrix with respect to the standard
basis 1;t;t2;:::;tn);
d)T:Pn!Pn,Tf(t) = 2f(t) + 3f0(t) 4f00(t) (again with respect to the
standard basis 1 ;t;t2;:::;tn).
3.4. Find 33 matrices representing the transformations of R3which:
a) project every vector onto x-yplane;
b) reect every vector through x-yplane;
c) rotate the x-yplane through 30, leavingz-axis alone.
3.5. LetAbe a linear transformation. If zis the center of the straight interval
[x;y], show that Azis the center of the interval [ Ax;Ay].Hint: What does it
mean that zis the center of the interval [ x;y]?
3.6. The set Cof complex numbers can be canonically identied with the space R2
by treating each z=x+iy2Cas a column ( x;y)T2R2.
a) Treating Cas a complex vector space, show that the multiplication by
=a+ib2Cis a linear transformation in C. What is its matrix?
b) Treating Cas the real vector space R2show that the multiplication by
=a+ibdenes a linear transformation there. What is its matrix?
c) DeneT(x+iy) = 2x y+i(x 3y). Show that this transformation is not
a linear transformation in the complex vectors space C, but if we treat C
as the real vector space R2then it is a linear transformation there (i.e. that
Tis areal linear but not a complex linear transformation).
Find the matrix of the real linear transformation T.
3.7. Show that any linear transformation in C(treated as a complex vector space)
is a multiplication by 2C.
4. Linear transformations as a vector space
What operations can we perform with linear transformations? We can al-
ways multiply a linear transformation for a scalar, i.e. if we have a linear
18 1. Basic Notions
transformation T:V!Wand a scalar we can dene a new transforma-
tionTby
(T)v=(Tv)8v2V:
It is easy to check that Tis also a linear transformation:
(T)(1v1+2v2) =(T(1v1+2v2)) by the denition of T
=(1Tv1+2Tv2) by the linearity of T
=1Tv1+2Tv2=1(T)v1+2(T)v2
IfT1andT2are linear transformations with the same domain and target
space (T1:V!WandT2:V!W, or in short T1;T2:V!W),
then we can add these transformations, i.e. dene a new transformation
T= (T1+T2) :V!Wby
(T1+T2)v=T1v+T2v8v2V:
It is easy to check that the transformation T1+T2is a linear one, one just
needs to repeat the above reasoning for the linearity of T.
So, if we x vector spaces VandWand consider the collection of all
linear transformations from VtoW(let us denote it by L(V;W )), we can
dene 2 operations on L(V;W ): multiplication by a scalar and addition.
It can be easily shown that these operations satisfy the axioms of a vector
space, dened in Section 1.
This should come as no surprise for the reader, since axioms of a vector
space essentially mean that operation on vectors follow standard rules of
algebra. And the operations on linear transformations are dened as to
satisfy these rules!
As an illustration, let us write down a formal proof of the rst distribu-
tive law (axiom 7) of a vector space. We want to show that (T1+T2) =
T1+T2. For any v2V
(T1+T2)v=((T1+T2)v) by the denition of multiplication
=(T1v+T2v) by the denition of the sum
=T1v+T2v by Axiom 7 for W
= (T1+T2)v by the denition of the sum
So indeed(T1+T2) =T1+T2.
Remark. Linear operations (addition and multiplication by a scalar) on
linear transformations T:Fn!Fmcorrespond to the respective operations
on their matrices. Since we know that the set of mnmatrices is a vector
space, this immediately implies that L(Fn;Fm) is a vector space.
We presented the abstract proof above, rst of all because it work for
general spaces, for example, for spaces without a basis, where we cannot
5. Composition of linear transformations and matrix multiplication. 19
work with coordinates. Secondly, the reasonings similar to the abstract one
presented here, are used in many places, so the reader will benet from
understanding it.
And as the reader gains some mathematical sophistication, he/she will
see that this abstract reasoning is indeed a very simple one, that can be
performed almost automatically.
5. Composition of linear transformations and matrix
multiplication.
5.1. Denition of the matrix multiplication. Knowing matrix{vector
multiplication, one can easily guess what is the natural way to dene the
productABof two matrices: Let us multiply by Aeach column of B(matrix-
vector multiplication) and join the resulting column-vectors into a matrix.
Formally,
ifb1;b2;:::;brare the columns of B, thenAb1;Ab2;:::;A brare
the columns of the matrix AB.
Recalling the row by column rule for the matrix{vector multiplication we
get the following row by column rule for the matrices
the entry (AB)j;k(the entry in the row jand column k) of the
productABis dened by
(AB)j;k= (row #jofA)(column #kofB)
Formally it can be rewritten as
(AB)j;k=X
laj;lbl;k;
ifaj;kandbj;kare entries of the matrices AandBrespectively.
I intentionally did not speak about sizes of the matrices AandB, but
if we recall the row by column rule for the matrix{vector multiplication, we
can see that in order for the multiplication to be dened, the size of a row
ofAshould be equal to the size of a column of B.
In other words the product ABis dened if and only if Ais anmn
andBisnrmatrix.
5.2. Motivation: composition of linear transformations. One can
ask yourself here: Why are we using such a complicated rule of multiplica-
tion? Why don't we just multiply matrices entrywise?
And the answer is, that the multiplication, as it is dened above, arises
naturally from the composition of linear transformations.
20 1. Basic Notions
Suppose we have two linear transformations, T1:Fn!FmandT2:
Fr!Fn. Dene the composition T=T1T2of the transformations T1,T2
as
T(x) =T1(T2(x))8x2Fr:
Note thatT2(x)2Fn. SinceT1:Fn!Fm, the expression T1(T2(x)) is well
dened and the result belongs to Fm. So,T:Fr!Fm. We will usually
identify a linear
transformation and
its matrix, but in
the next few
paragraphs we will
distinguish themIt is easy to show that Tis a linear transformation (exercise), so it is
dened by an mrmatrix. How one can nd this matrix, knowing the
matrices of T1andT2?
LetAbe the matrix of T1andBbe the matrix of T2. As we discussed in
the previous section, the columns of Tare vectors T(e1);T(e2);:::;T (er),
where e1;e2;:::;eris the standard basis in Fr. Fork= 1;2;:::;r we have
T(ek) =T1(T2(ek)) =T1(Bek) =T1(bk) =Abk
(operatorsT2andT1are simply the multiplication by BandArespectively).
So, the columns of the matrix of TareAb1;Ab2;:::;A br, and that is
exactly how the matrix ABwas dened!
Let us return to identifying again a linear transformation with its matrix.
Since the matrix multiplication agrees with the composition, we can (and
will) writeT1T2instead ofT1T2andT1T2xinstead ofT1(T2(x)).
Note that in the composition T1T2the transformation T2is applied rst! Note: order of
transformations! The way to remember this is to see that in T1T2xthe transformation T2
meets xst.
Remark. There is another way of checking the dimensions of matrices in a
product, dierent form the row by column rule: for a composition T1T2to
be dened it is necessary that T2xbelongs to the domain of T1. IfT2acts
from some space, say FrtoFn, thenT1must act from Fnto some space, say
Fm. So, in order for T1T2to be dened the matrices of T1andT2should be
of sizesmnandnrrespectively|the same condition as obtained from
therow by column rule.
Example. LetT:R2!R2be the reection in the line x1= 3x2. It is
a linear transformation, so let us nd its matrix. To nd the matrix, we
need to compute Te1andTe2. However, the direct computation of Te1and
Te2involves signicantly more trigonometry than a sane person is willing
to remember.
An easier way to nd the matrix of Tis to represent it as a composition
of simple linear transformation. Namely, let be the angle between the
x1axis and the line x1= 3x2, and letT0be the reection in the x1-axis.
Then to get the reection Twe can rst rotate the plane by the angle  ,
moving the line x1= 3x2to thex1-axis, then reect everything in the x1
5. Composition of linear transformations and matrix multiplication. 21
axis, and then rotate the plane by , taking everything back. Formally it
can be written as
T=RT0R 
(note the order of terms!), where Ris the rotation by . The matrix of T0
is easy to compute,
T0=1 0
0 1
;
the rotation matrices are known
R=cos sin
sincos;
;
R =cos( ) sin( )
sin( ) cos( );
=cos sin
 sincos;
To compute sin and costake a vector in the line x1= 3x2, say a vector
(3;1)T. Then
cos=rst coordinate
length=3p
32+ 12=3p
10
and similarly
sin=second coordinate
length=1p
32+ 12=1p
10
Gathering everything together we get
T=RT0R =1p
103 1
1 31 0
0 11p
103 1
 1 3
=1
103 1
1 31 0
0 13 1
 1 3
It remains only to perform matrix multiplication here to get the nal result.

5.3. Properties of matrix multiplication. Matrix multiplication enjoys
a lot of properties, familiar to us from high school algebra:
1. Associativity: A(BC) = (AB)C, provided that either left or right
side is well dened; we therefore can (and will) simply write ABC
in this case.
2. Distributivity: A(B+C) =AB+AC, (A+B)C=AC+BC,
provided either left or right side of each equation is well dened.
3. One can take scalar multiplies out: A(B) = (A)B=(AB) =
AB .
22 1. Basic Notions
These properties are easy to prove. One should prove the corresponding
properties for linear transformations, and they almost trivially follow from
the denitions. The properties of linear transformations then imply the
properties for the matrix multiplication.
The new twist here is that the commutativity fails:
matrix multiplication is non-commutative, i.e. generally for
matricesAB6=BA.
One can see easily it would be unreasonable to expect the commutativity of
matrix multiplication. Indeed, let AandBbe matrices of sizes mnand
nrrespectively. Then the product ABis well dened, but if m6=r,BA
is not dened.
Even when both products are well dened, for example, when AandB
arenn(square) matrices, the multiplication is still non-commutative. If we
just pick the matrices AandBat random, the chances are that AB6=BA:
we have to be very lucky to get AB=BA.
5.4. Transposed matrices and multiplication. Given a matrix A, its
transpose (or transposed matrix) ATis dened by transforming the rows of
Ainto the columns. For example
1 2 3
4 5 6T
=0
@1 4
2 5
3 61
A:
So, the columns of ATare the rows of Aand vice versa, the rows of ATare
the columns of A.
The formal denition is as follows: ( AT)j;k= (A)k;jmeaning that the
entry ofATin the row number jand column number kequals the entry of
Ain the row number kand row number j.
The transpose of a matrix has a very nice interpretation in terms of
linear transformations, namely it gives the so-called adjoint transformation.
We will study this in detail later, but for now transposition will be just a
useful formal operation.
One of the rst uses of the transpose is that we can write a column
vector x2Fnasx= (x1;x2;:::;xn)T. If we put the column vertically, it
will use signicantly more space.
A simple analysis of the row by columns rule shows that
(AB)T=BTAT;
i.e. when you take the transpose of the product, you change the order of the
terms.
5. Composition of linear transformations and matrix multiplication. 23
5.5. Trace and matrix multiplication. For a square ( nn) matrix
A= (aj;k) its trace (denoted by trace A) is the sum of the diagonal entries
traceA=nX
k=1ak;k:
Theorem 5.1. LetAandBbe matrices of size mnandnmrespectively
(so the both products ABandBAare well dened). Then
trace(AB) = trace(BA)
We leave the proof of this theorem as an exercise, see Problem 5.6 below.
There are essentially two ways of proving this theorem. One is to compute
the diagonal entries of ABand ofBAand compare their sums. This method
requires some prociency in manipulating sums inPnotation.
If you are not comfortable with algebraic manipulations, there is another
way. We can consider two linear transformations, TandT1, acting from
MnmtoF=F1dened by
T(X) = trace(AX); T 1(X) = trace(XA)
To prove the theorem it is sucient to show that T=T1; the equality for
X=Bgives the theorem.
Since a linear transformation is completely dened by its values on a
generating system, we need just to check the equality on some simple ma-
trices, for example on matrices Xj;k, which has all entries 0 except the entry
1 in the intersection of jth column and kth row.
Exercises.
5.1. Let
A=
1 2
3 1
; B=1 0 2
3 1 2
; C=1 2 3
 2 1 1
; D=0
@ 2
2
11
A
a) Mark all the products that are dened, and give the dimensions of the
result:AB,BA,ABC ,ABD ,BC,BCT,BTC,DC,DTCT.
b) Compute AB,A(3B+C),BTA,A(BD), (AB)D.
5.2. LetTbe the matrix of rotation by inR2. Check by matrix multiplication
thatTT =T T=I
5.3. Multiply two rotation matrices TandT(it is a rare case when the multi-
plication is commutative, i.e. TT=TT, so the order is not essential). Deduce
formulas for sin( +) and cos(+) from here.
5.4. Find the matrix of the orthogonal projection in R2onto the line x1= 2x2.
Hint: What is the matrix of the projection onto the coordinate axis x1?
5.5. Find linear transformations A;B :R2!R2such thatAB=0butBA6=0.
24 1. Basic Notions
5.6. Prove Theorem 5.1, i.e. prove that trace( AB) = trace(BA).
5.7. Construct a non-zero matrix Asuch thatA2=0.
5.8. Find the matrix of the reection through the line y= 2x=3. Perform all the
multiplications.
6. Invertible transformations and matrices. Isomorphisms
6.1. Identity transformation and identity matrix. Among all linear
transformations, there is a special one, the identity transformation (opera-
tor)I,Ix=x,8x.
To be precise, there are innitely many identity transformations: for
any vector space V, there is the identity transformation I=IV:V!V,
IVx=x,8x2V. However, when it is does not lead to the confusion
we will use the same symbol Ifor all identity operators (transformations).
We will use the notation IVonly we want to emphasize in what space the
transformation is acting.
Clearly, ifI:Fn!Fnis the identity transformation in Fn, its matrix Often, the symbol E
is used in Linear Al-
gebra textbooks for
the identity matrix.
I preferI, since it is
used in operator the-
ory.is thennmatrix
I=In=0
BBB@1 0:::0
0 1:::0
............
0 0:::11
CCCA
(1 on the main diagonal and 0 everywhere else). When we want to emphasize
the size of the matrix, we use the notation In; otherwise we just use I.
Clearly, for an arbitrary linear transformation A, the equalities
AI=A; IA =A
hold (whenever the product is dened).
6.2. Invertible transformations.
Denition. LetA:V!Wbe a linear transformation. We say that
the transformation Aisleft invertible if there exist a linear transformation
B:W!Vsuch that
BA=I (I=IVhere):
The transformation Ais called right invertible if there exists a linear trans-
formationC:W!Vsuch that
AC=I (hereI=IW):
6. Invertible transformations and matrices. Isomorphisms 25
The transformations BandCare called leftand right inverses ofA. Note,
that we did not assume the uniqueness of BorChere, and generally left
and right inverses are not unique.
Denition. A linear transformation A:V!Wis called invertible if it is
both right and left invertible.
Theorem 6.1. If a linear transformation A:V!Wis invertible, then its
left and right inverses BandCare unique and coincide.
Corollary. A transformation A:V!Wis invertible if and only if there Very often this prop-
erty is used as the
denition of an in-
vertible transforma-
tionexists a unique linear transformation (denoted A 1),A 1:W!Vsuch
that
A 1A=IV; AA 1=IW:
The transformation A 1is called the inverse ofA.
Proof of Theorem 6.1. LetBA=IandAC=I. Then
BAC =B(AC) =BI=B:
On the other hand
BAC = (BA)C=IC=C;
and therefore B=C.
Suppose for some transformation B1we haveB1A=I. Repeating the
above reasoning with B1instead ofBwe getB1=C. Therefore the left
inverseBis unique. The uniqueness of Cis proved similarly. 
Denition. A matrix is called invertible (resp. left invertible, right invert-
ible) if the corresponding linear transformation is invertible (resp. left in-
vertible, right invertible).
Theorem 6.1 asserts that a matrix Ais invertible if there exists a unique
matrixA 1such thatA 1A=I,AA 1=I. The matrix A 1is called
(surprise) the inverse ofA.
Examples.
1. The identity transformation (matrix) is invertible, I 1=I;
2. The rotation R
R=cos sin
sincos
is invertible, and the inverse is given by ( R) 1=R . This equality
is clear from the geometric description of R, and it also can be
checked by the matrix multiplication;
26 1. Basic Notions
3. The column (1 ;1)Tis left invertible but not right invertible. One of
the possible left inverses in the row (1 =2;1=2).
To show that this matrix is not right invertible, we just notice
that there are more than one left inverse. Exercise: describe all
left inverses of this matrix.
4. The row (1 ;1) is right invertible, but not left invertible. The column
(1=2;1=2)Tis a possible right inverse.
Remark 6.2. An invertible matrix must be square ( nn). Moreover, if
a square matrix Ahas either left or right inverse, it is invertible. So, it is An invertible matrix
must be square (to
be proved later)sucient to check only one of the identities AA 1=I,A 1A=I.
This fact will be proved later. Until we prove this fact, we will not use
it. I presented it here only to stop students from trying wrong directions.
6.2.1. Properties of the inverse transformation.
Theorem 6.3 (Inverse of the product) .If linear transformations AandB
are invertible (and such that the product AB is dened), then the product Inverse of a product:
(AB) 1=B 1A 1.
Note the change of
orderABis invertible and
(AB) 1=B 1A 1
(note the change of the order!)
Proof. Direct computation shows:
(AB)(B 1A 1) =A(BB 1)A 1=AIA 1=AA 1=I
and similarly
(B 1A 1)(AB) =B 1(A 1A)B=B 1IB=B 1B=I

Remark 6.4. The invertibility of the product ABdoes not imply the in-
vertibility of the factors AandB(can you think of an example?). However,
if one of the factors (either AorB) and the product ABare invertible, then
the second factor is also invertible.
We leave the proof of this fact as an exercise.
Theorem 6.5 (Inverse of AT).If a matrix Ais invertible, then ATis also
invertible and
(AT) 1= (A 1)T
Proof. Using (AB)T=BTATwe get
(A 1)TAT= (AA 1)T=IT=I;
and similarly
AT(A 1)T= (A 1A)T=IT=I:

6. Invertible transformations and matrices. Isomorphisms 27
And nally, if Ais invertible, then A 1is also invertible, ( A 1) 1=A.
So, let us summarize the main properties of the inverse:
1. IfAis invertible, then A 1is also invertible, ( A 1) 1=A;
2. IfAandBare invertible and the product ABis dened, then AB
is invertible and ( AB) 1=B 1A 1.
3. IfAis invertible, then ATis also invertible and ( AT) 1= (A 1)T.
6.3. Isomorphism. Isomorphic spaces. An invertible linear transfor-
mationA:V!Wis called an isomorphism. We did not introduce anything
new here, it is just another name for the object we already studied.
Two vector spaces VandWare called isomorphic (denotedV=W) if
there is an isomorphism A:V!W.
Isomorphic spaces can be considered as dierent representation of the
same space, meaning that all properties and constructions involving vector
space operations are preserved under isomorphism.
The theorem below illustrates this statement.
Theorem 6.6. LetA:V!Wbe an isomorphism, and let v1;v2;:::;vn
be a basis in V. Then the system Av1;Av2;:::;A vnis a basis in W.
We leave the proof of the theorem as an exercise.
Remark. In the above theorem one can replace \basis" by \linearly inde-
pendent", or \generating", or \linearly dependent"|all these properties are
preserved under isomorphisms.
Remark. IfAis an isomorphism, then so is A 1. Therefore in the above
theorem we can state that v1;v2;:::;vnis a basis if and only if Av1;Av2;
:::;A vnis a basis.
The converse to the Theorem 6.6 is also true
Theorem 6.7. LetA:V!Wbe a linear map,and let v1;v2;:::;vn
andw1;w2;:::;wnbe bases in VandWrespectively. If Avk=wk,k=
1;2;:::;n , thenAis an isomorphism.
Proof. Dene the inverse transformation A 1byA 1wk=vk,k= 1;
2;:::;n (as we know, a linear transformation is dened by its values on a
basis). 
Examples.
1. LetA:Fn+1!PF
n(PF
nis the set of polynomialsPn
k=0aktk,k2F
of degree at most n) is dened by
Ae1= 1; Ae2=t;:::;A en=tn 1; Aen+1=tn
28 1. Basic Notions
By Theorem 6.7 Ais an isomorphism, so PF
n=Fn+1.
2. LetVbe a vector space (over F) with a basis v1;v2;:::;vn. Dene
transformation A:Fn!Vby Any real vector
space with a basis
is isomorphic to Rn
(for somen). Sim-
ilarly, any complex
vector space with a
basis is isomorphic
toCn.Aek=vk; k = 1;2;:::;n;
where e1;e2;:::;enis the standard basis in Fn. Again by Theorem
6.7Ais an isomorphism, so V=Fn.
3. The space MF
23of 23 matrices with entries in Fis isomorphic to
R6;
4. More generally, MF
mn=Fmn
6.4. Invertibility and equations.
Theorem 6.8. LetA:X!Ybe a linear transformation. Then Ais Doesn't this remind
you of a basis? invertible if and only if for any right side b2Ythe equation
Ax=b
has a unique solution x2X.
Proof. SupposeAis invertible. Then x=A 1bsolves the equation Ax=
b. To show that the solution is unique, suppose that for some other vector
x12X
Ax1=b
Multiplying this identity by A 1from the left we get
A 1Ax1=A 1b;
and therefore x1=A 1b=x. Note that both identities, AA 1=Iand
A 1A=Iwere used here.
Let us now suppose that the equation Ax=bhas a unique solution x
for any b2Y. Let us use symbol yinstead of b. We know that given y2Y
the equation
Ax=y
has a unique solution x2X. Let us call this solution B(y).
Note thatB(y) is dened for all y2Y, so we dened a transformation
B:Y!X.
Let us check that Bis a linear transformation. We need to show that
B(y1+y2) =B(y1)+B(y2). Let xk:=B(yk),k= 1;2, i.e.Axk=yk,
k= 1;2. Then
A(x1+x2) =Ax1+Ax2=y1+y2;
which means
B(y1+y2) =B(y1) +B(y2):
6. Invertible transformations and matrices. Isomorphisms 29
And nally, let us show that Bis indeed the inverse of A. Take x2X
and let y=Ax, so by the denition of Bwe have x=By. Then for all
x2X
BAx=By=x;
soBA=I. Similarly, for arbitrary y2Yletx=By, soy=Ax. Then for
ally2Y
ABy=Ax=y
soAB=I. 
Recalling the denition of a basis we get the following corollary of The-
orems 6.6 and 6.7.
Corollary 6.9. Anmnmatrix is invertible if and only if its columns
form a basis in Fm.
Exercises.
6.1. Prove, that if A:V!Wis an isomorphism (i.e. an invertible linear trans-
formation) and v1;v2;:::;vnis a basis in V, thenAv1;Av2;:::;A vnis a basis in
W.
6.2. Find all right inverses to the 1 2 matrix (row) A= (1;1). Conclude from
here that the row Ais not left invertible.
6.3. Find all left inverses of the column (1 ;2;3)T
6.4. Is the column (1 ;2;3)Tright invertible? Justify
6.5. Find two matrices AandBthatABis invertible, but AandBare not. Hint:
square matrices AandBwould not work. Remark: It is easy to construct such
AandBin the case when ABis a 11 matrix (a scalar). But can you get 2 2
matrixAB? 33?nn?
6.6. Suppose the product ABis invertible. Show that Ais right invertible and B
is left invertible. Hint: you can just write formulas for right and left inverses.
6.7. LetAandABbe invertible (assuming that the product ABis well dened).
Prove that Bis invertible.
6.8. LetAbennmatrix. Prove that if A2=0thenAis not invertible
6.9. SupposeAB=0for some non-zero matrix B. CanAbe invertible? Justify.
6.10. Write matrices of the linear transformations T1andT2inF5, dened as
follows:T1interchanges the coordinates x2andx4of the vector x, andT2just
adds to the coordinate x2atimes the coordinate x4, and does not change other
coordinates, i.e.
T10
BBBB@x1
x2
x3
x4
x51
CCCCA=0
BBBB@x1
x4
x3
x2
x51
CCCCA; T 20
BBBB@x1
x2
x3
x4
x51
CCCCA=0
BBBB@x1
x2+ax4
x3
x4
x51
CCCCA;
30 1. Basic Notions
hereais some xed number.
Show thatT1andT2are invertible transformations, and write the matrices of
the inverses. Hint: it may be simpler, if you rst describe the inverse transforma-
tion, and then nd its matrix, rather than trying to guess (or compute) the inverses
of the matrices T1,T2.
6.11. Find the matrix of the rotation in R3through the angle around the vector
(1;2;3)T. We assume that the rotation is counterclockwise if we sit at the tip of
the vector and looking at the origin.
You can present the answer as a product of several matrices: you don't have
to perform the multiplication.
6.12. Give examples of matrices (say 2 2) such that:
a)A+Bis not invertible although both AandBare invertible;
b)A+Bis invertible although both AandBare not invertible;
c) All ofA,BandA+Bare invertible
6.13. LetAbe an invertible symmetric ( AT=A) matrix. Is the inverse of A
symmetric? Justify.
7. Subspaces.
Asubspace of a vector space Vis a non-empty subset V0VofVwhich is
closed under the vector addition and multiplication by scalars, i.e.
1. Ifv2V0thenv2V0for all scalars ;
2. For any u;v2V0the sum u+v2V0;
Again, the conditions 1 and 2 can be replaced by the following one:
u+v2V0 for all u;v2V0;and for all scalars ;:
Note, that a subspace V0Vwith the operations (vector addition and
multiplication by scalars) inherited from V, is a vector space. Indeed, since
Vis non-empty, it contain at least 1 vector vand since 0= 0v, the above
condition 1. imples that the zero vector 0is inV. Also, for any v2V
its additive inverse  vin given by v= ( 1)v, so again by property 1.
 v2V. The rest of the axiom of the vector space are satised because all
operations are inherited from the vector space V. The only thing that could
possibly go wrong, is that the result of some operation does not belong to
V0. But the denition of a subspace prohibits this!
Now let us consider some examples:
1.Trivial subspaces of a space V, namelyVitself andf0g(the sub-
space consisting only of zero vector). Note, that the empty set ?is
not a vector space, since it does not contain a zero vector, so it is
not a subspace.
8. Application to computer graphics. 31
With each linear transformation A:V!Wwe can associate the following
two subspaces:
2. The null space , orkernel ofA, which is denoted as Null Aor KerA
and consists of all vectors v2Vsuch thatAv=0
3. The range Ran Ais dened as the set of all vectors w2Wwhich
can be represented as w=Avfor some v2V.
IfAis a matrix, i.e. A:Fm!Fn, then recalling column by coordinate rule
of the matrix{vector multiplication, we can see that any vector w2RanA
can be represented as a linear combination of columns of the matrix A. That
explains why the term column space (and notation Col A) is often used for
the range of the matrix. So, for a matrix A, the notation Col Ais often used
instead of Ran A.
And now the last example.
4. Given a system of vectors v1;v2;:::;vr2Vitslinear span (some-
times called simply span)Lfv1;v2;:::;vrgis the collection of all
vectors v2Vthat can be represented as a linear combination
v=1v1+2v2+:::+rvrof vectors v1;v2;:::;vr. The no-
tation spanfv1;v2;:::;vrgis also used instead of Lfv1;v2;:::;vrg
It is easy to check that in all of these examples we indeed have subspaces.
We leave this an an exercise for the reader. Some of the statements will be
proved later in the text.
Exercises.
7.1. LetXandYbe subspaces of a vector space V. Prove that X\Yis a subspace
ofV.
7.2. LetVbe a vector space. For X;YVthe sumX+Yis the collection of all
vectors vwhich can be represented as v=x+y,x2X,y2Y. Show that if X
andYaresubspaces ofV, thenX+Yis also a subspace.
7.3. LetXbe a subspace of a vector space V, and let v2V,v=2X. Prove that
ifx2Xthenx+v=2X.
7.4. LetXandYbe subspaces of a vector space V. Using the previous exercise,
show thatX[Yis a subspace if and only if XYorYX.
7.5. What is the smallest subspace of the space of 4 4 matrices which contains
all upper triangular matrices ( aj;k= 0 for all j > k ), and all symmetric matrices
(A=AT)? What is the largest subspace contained in both of those subspaces?
8. Application to computer graphics.
In this section we give some ideas of how linear algebra is used in computer
graphics. We will not go into the details, but just explain some ideas.
32 1. Basic Notions
In particular we explain why manipulation with 3 dimensional images are
reduced to multiplications of 4 4 matrices.
8.1. 2-dimensional manipulation. Thex-yplane (more precisely, a rec-
tangle there) is a good model of a computer monitor. Any object on a
monitor is represented as a collection of pixels , each pixel is assigned a spe-
cic color. Position of each pixel is determined by the column and row,
which play role of xandycoordinates on the plane. So a rectangle on a
plane with x-ycoordinates is a good model for a computer screen: and a
graphical object is just a collection of points.
Remark. There are two types of graphical objects: bitmap objects, where
every pixel of an object is described, and vector object, where we describe
only critical points , and graphic engine connects them to reconstruct the
object. A (digital) photo is a good example of a bitmap object: every pixel
of it is described. Bitmap object can contain a lot of points, so manipulations
with bitmaps require a lot of computing power. Anybody who has edited
digital photos in a bitmap manipulation program, like Adobe Photoshop,
knows that one needs quite a powerful computer, and even with modern
and powerful computers manipulations can take some time.
That is the reason that most of the objects, appearing on a computer
screen are vector ones: the computer only needs to memorize critical points.
For example, to describe a polygon, one needs only to give the coordinates
of its vertices, and which vertex is connected with which. Of course, not
all objects on a computer screen can be represented as polygons, some, like
letters, have curved smooth boundaries. But there are standard methods
allowing one to draw smooth curves through a collection of points, for exam-
ple Bezier splines, used in PostScript and Adobe PDF (and in many other
formats).
Anyhow, this is the subject of a completely dierent book, and we will
not discuss it here. For us a graphical object will be a collection of points
(either wireframe model, or bitmap) and we would like to show how one can
perform some manipulations with such objects.
The simplest transformation is a translation (shift), where each point
(vector) vis translated by a, i.e. the vector vis replaced by v+a(nota-
tionv7!v+ais used for this). Vector addition is very well adapted to
computers, so the translation is easy to implement.
Note, that the translation is not a linear transformation (if a6=0): while
it preserves the straight lines, it does not preserve 0.
All other transformation used in computer graphics are linear. The rst
one that comes to mind is rotation. The rotation by around the origin 0
8. Application to computer graphics. 33
is given by the multiplication by the rotation matrix Rwe discussed above,
R=cos sin
sincos
:
If we want to rotate around a point a, we rst need to translate the picture
by a, moving the point ato0, then rotate around 0(multiply by R) and
then translate everything back by a.
Another very useful transformation is scaling, given by a matrix
a0
0b
;
a;b0. Ifa=bit is uniform scaling which enlarges (reduces) an object,
preserving its shape. If a6=bthenxandycoordinates scale dierently; the
object becomes \taller" or \wider".
Another often used transformation is reection : for example the matrix
1 0
0 1
;
denes the reection through x-axis.
We will show later in the book, that any linear transformation in R2can
be represented either as a composition of scaling rotations and reections.
However it is sometimes convenient to consider some dierent transforma-
tions, like the shear transformation, given by the matrix
1 tan'
0 1
:
This transformation makes all objects slanted, the horizontal lines remain
horizontal, but vertical lines go to the slanted lines at the angle 'to the
horizontal ones.
8.2. 3-dimensional graphics. Three-dimensional graphics is more com-
plicated. First we need to be able to manipulate 3-dimensional objects, and
then we need to represent it on 2-dimensional plane (monitor).
The manipulations with 3-dimensional objects is pretty straightforward,
we have the same basic transformations: translation, reection through a
plane, scaling, rotation. Matrices of these transformations are very similar
to the matrices of their 2 2 counterparts. For example the matrices
0
@1 0 0
0 1 0
0 0 11
A;0
@a0 0
0b0
0 0c1
A;0
@cos sin0
sincos0
0 0 11
A
represent respectively reection through x-yplane, scaling, and rotation
aroundz-axis.
34 1. Basic Notions
Note, that the above rotation is essentially 2-dimensional transforma-
tion, it does not change zcoordinate. Similarly, one can write matrices for
the other 2 elementary rotations aroundxand around yaxes. It will be
shown later that a rotation around an arbitrary axis can be represented as
a composition of elementary rotations.
So, we know how to manipulate 3-dimensional objects. Let us now
discuss how to represent such objects on a 2-dimensional plane. The simplest
way is to project it to a plane, say to the x-yplane. To perform such
projection one just needs to replace zcoordinate by 0, the matrix of this
projection is0
@1 0 0
0 1 0
0 0 01
A:
Such method is often used in technical illustrations. Rotating an object
and projecting it is equivalent to looking at it from dierent points. However,
this method does not give a very realistic picture, because it does not take
into account the perspective, the fact that the objects that are further away
look smaller.
To get a more realistic picture one needs to use the so-called perspective
projection . To dene a perspective projection one needs to pick a point (the
center of projection or the focal point) and a plane to project onto. Then
each point in R3is projected into a point on the plane such that the point,
its image and the center of the projection lie on the same line, see Fig. 2.
This is exactly how a camera works, and it is a reasonable rst approx-
imation of how our eyes work.
Let us get a formula for the projection. Assume that the focal point is
(0;0;d)Tand that we are projecting onto x-yplane, see Fig. 3 a). Consider
a point v= (x;y;z )T, and let v= (x;y;0)Tbe its projection. Analyzing
similar triangles see Fig. 3 b), we get that
x
d=x
d z;
so
x=xd
d z=x
1 z=d;
and similarly
y=y
1 z=d:
Note, that this formula also works if z >d and ifz <0: you can draw the
corresponding similar triangles to check it.
8. Application to computer graphics. 35
xy
zF
Figure 2. Perspective projection onto x-yplane: Fis the center (focal
point) of the projection
xx∗
z
d−z(x, y, z )(x∗,y∗,0)
x
zy
(0,0,d)a) b)
Figure 3. Finding coordinates x; yof the perspective projection of
the point ( x; y; z )T.
Thus the perspective projection maps a point ( x;y;z )Tto the point
x
1 z=d;y
1 z=d;0T
.
This transformation is denitely not linear (because of zin the denomi-
nator). However it is still possible to represent it as a linear transformation.
To do this let us introduce the so-called homogeneous coordinates .
36 1. Basic Notions
In the homogeneous coordinates, every point in R3is represented by 4
coordinates, the last, 4th coordinate playing role of the scaling coecient.
Thus, to get usual 3-dimensional coordinates of the vector v= (x;y;z )T
from its homogeneous coordinates ( x1;x2;x3;x4)Tone needs to divide all
entries by the last coordinate x4and take the rst 3 coordinates3(ifx4= 0
this recipe does not work, so we assume that the case x4= 0 corresponds
to the point at innity).
Thus in homogeneous coordinates the vector vcan be represented as
(x;y;0;1 z=d)T, so in homogeneous coordinates the perspective projection
is a linear transformation:
0
BB@x
y
0
1 z=d1
CCA=0
BB@1 0 0 0
0 1 0 0
0 0 0 0
0 0 1=d11
CCA0
BB@x
y
z
11
CCA:
Note that in the homogeneous coordinates the translation is also a linear
transformation:
0
BB@x+a1
y+a2
z+a3
11
CCA=0
BB@1 0 0a1
0 1 0a2
0 0 1a3
0 0 0 11
CCA0
BB@x
y
z
11
CCA:
But what happen if the center of projection is not a point (0 ;0;d)Tbut
some arbitrary point ( d1;d2;d3)T. Then we rst need to apply the transla-
tion by (d1;d2;0)Tto move the center to (0 ;0;d3)Twhile preserving the
x-yplane, apply the projection, and then move everything back translating
it by (d1;d2;0)T. Similarly, if the plane we project to is not x-yplane, we
move it to the x-yplane by using rotations and translations, and so on.
All these operations are just multiplications by 4 4 matrices. That
explains why modern graphic cards have 4 4 matrix operations embedded
in the processor.
Of course, here we only touched the mathematics behind 3-dimensional
graphics, there is much more. For example, how to determine which parts of
the object are visible and which are hidden, how to make realistic lighting,
shades, etc.
3If we multiply homogeneous coordinates of a point in R2by a non-zero scalar, we do not
change the point. In other words, in homogeneous coordinates a point in R3is represented by a
line through 0 in R4.
8. Application to computer graphics. 37
Exercises.
8.1. What vector in R3has homogeneous coordinates (10 ;20;30;5)?
8.2. Show that a rotation through can be represented as a composition of two
shear-and-scale transformations
T1=
1 0
sincos
; T 2=
sec tan
0 1
:
In what order the transformations should be taken?
8.3. Multiplication of a 2-vector by an arbitrary 2 2 matrix usually requires 4
multiplications.
Suppose a 21000 matrix Dcontains coordinates of 1000 points in R2. How
many multiplications are required to transform these points using 2 arbitrary 2 2
matricesAandB. Compare 2 possibilities, A(BD) and (AB)D.
8.4. Write 44 matrix performing perspective projection to x-yplane with center
(d1;d2;d3)T.
8.5. A transformation TinR3is a rotation about the line y=x+3 in thex-yplane
through an angle . Write a 44 matrix corresponding to this transformation.
You can leave the result as a product of matrices.

Chapter 2
Systems of linear
equations
1. Dierent faces of linear systems.
There exist several points of view on what a system of linear equations, or in
short a linear system is. The rst, na ve one is, that it is simply a collection
ofmlinear equations with nunknownsx1;x2;:::;xn,
8
>><
>>:a1;1x1+a1;2x2+:::+a1;nxn=b1
a2;1x1+a2;2x2+:::+a2;nxn=b2
:::
am;1x1+am;2x2+:::+am;nxn=bm:
To solve the system is to nd alln-tuples of numbers x1;x2;:::;xnwhich
satisfy allmequations simultaneously.
If we denote x:= (x1;x2;:::;xn)T2Fn,b= (b1;b2;:::;bm)T2Fm,
and
A=0
BBB@a1;1a1;2::: a 1;n
a2;1a2;2::: a 2;n
.........
am;1am;2::: am;n1
CCCA;
then the above linear system can be written in the matrix form (as a matrix-
vector equation )
Ax=b:
To solve the above equation is to nd all vectors x2FnsatisfyingAx=b.
39
40 2. Systems of linear equations
And nally, recalling the \column by coordinate" rule of the matrix-
vector multiplication, we can write the system as a vector equation
x1a1+x2a2+:::+xnan=b;
where akis thekth column of the matrix A,ak= (a1;k;a2;k;:::;am;k)T,
k= 1;2;:::;n .
Note, these three examples are essentially just dierent representations
of the same mathematical object.
Before explaining how to solve a linear system, let us notice that it does
not matter what we call the unknowns, xk,ykor something else. So, all
the information necessary to solve the system is contained in the matrix A,
which is called the coecient matrix of the system and in the vector (right
side) b. Hence, all the information we need is contained in the following
matrix0
BBB@a1;1a1;2::: a 1;nb1
a2;1a2;2::: a 2;nb2
............
am;1am;2::: am;nbm1
CCCA
which is obtained by attaching the column bto the matrix A. This matrix is
called the augmented matrix of the system. We will usually put the vertical
line separating Aandbto distinguish between the augmented matrix and
the coecient matrix.
2. Solution of a linear system. Echelon and reduced echelon
forms
Linear system are solved by the Gauss{Jordan elimination (which is some-
times called row reduction ). By performing operations on rows of the aug-
mented matrix of the system (i.e. on the equations), we reduce it to a simple
form, the so-called echelon form . When the system is in the echelon form ,
one can easily write the solution.
2.1. Row operations. There are three types of row operations we use:
1. Row exchange: interchange two rows of the matrix;
2. Scaling: multiply a row by a non-zero scalar a;
3. Row replacement: replace a row # kby its sum with a constant
multiple of a row # j; all other rows remain intact;
It is clear that the operations 1 and 2 do not change the set of solutions
of the system; they essentially do not change the system.
2. Solution of a linear system. Echelon and reduced echelon forms 41
As for the operation 3, one can easily see that it does not lose solutions.
Namely, let a \new" system be obtained from an \old" one by a row oper-
ation of type 3. Then any solution of the \old" system is a solution of the
\new" one.
To see that we do not gain anything extra, i.e. that any solution of the
\new" system is also a solution of the \old" one, we just notice that row
operation of type 3 are reversible , i.e. the \old' system also can be obtained
from the \new" one by applying a row operation of type 3 (can you say
which one?)
2.1.1. Row operations and multiplication by elementary matrices. There is
another, more \advanced" explanation why the above row operations are
legal. Namely, every row operation is equivalent to the multiplication of the
matrix from the left by one of the special elementary matrices.
Namely, the multiplication by the matrix
j k
j
k0
BBBBBBBBBBBBBBBBBBBBBB@1......
.........0
1......
::: ::: ::: 0::: ::: ::: 1
... 1...
.........
... 1...
::: ::: ::: 1::: ::: ::: 0
10...
11
CCCCCCCCCCCCCCCCCCCCCCA
just interchanges the rows number jand number k. Multiplication by the
matrix
k0
BBBBBBBBBB@1...
......0
1 0
::: ::: 0a0
0 10...0
0 11
CCCCCCCCCCA
42 2. Systems of linear equations
multiplies the row number kbya. Finally, multiplication by the matrix
j
k0
BBBBBBBBBBBB@1......
.........0
::: ::: 1:::0
.........
::: ::: a ::: 1
...011
CCCCCCCCCCCCA
adds to the row # krow #jmultiplied by a, and leaves all other rows intact. A way to describe
(or to remember)
these elementary
matrices: they are
obtained from Iby
applying the
corresponding row
operation to itTo see, that the multiplication by these matrices works as advertised,
one can just see how the multiplications act on vectors (columns).
Note that all these matrices are invertible (compare with reversibility of
row operations). The inverse of the rst matrix is the matrix itself. To get
the inverse of the second one, one just replaces aby 1=a. And nally, the
inverse of the third matrix is obtained by replacing aby a. To see that
the inverses are indeed obtained this way, one again can simply check how
they act on columns.
So, performing a row operation on the augmented matrix of the system
Ax=bis equivalent to the multiplication of the system (from the left) by
a special invertible matrix E. Left multiplying the equality Ax=bbyE
we get that any solution of the equation
Ax=b
is also a solution of
EAx=Eb:
Multiplying this equation (from the left) by E 1we get that any of its
solutions is a solution of the equation
E 1EAx=E 1Eb;
which is the original equation Ax=b. So, a row operation does not change
the solution set of a system.
2.2. Row reduction. The main step of row reduction consists of three
sub-steps:
1. Find the leftmost non-zero column of the matrix;
2. Make sure, by applying row operations of type 1 (row exchange), if
necessary, that the rst (the upper) entry of this column is non-zero.
This entry will be called the pivot entry or simply the pivot ;
2. Solution of a linear system. Echelon and reduced echelon forms 43
3. \Kill" (i.e. make them 0) all non-zero entries below the pivot by
adding (subtracting) an appropriate multiple of the rst row from
the rows number 2 ;3;:::;m .
We apply the main step to a matrix, then we leave the rst row alone and
apply the main step to rows 2 ;:::;m , then to rows 3 ;:::;m , etc.
The point to remember is that after we subtract a multiple of a row from
all rows below it (step 3), we leave it alone and do not change it in any way,
not even interchange it with another row.
After applying the main step nitely many times (at most m), we get
what is called the echelon form of the matrix.
2.2.1. An example of row reduction. Let us consider the following linear
system:8
<
:x1+ 2x2+ 3x3= 1
3x1+ 2x2+x3= 7
2x1+x2+ 2x3= 1
The augmented matrix of the system is
0
@1 2 3 1
3 2 1 7
2 1 2 11
A
Subtracting 3Row#1 from the second row, and subtracting 2 Row#1 from
the third one we get:
0
@1 2 3 1
3 2 1 7
2 1 2 11
A 3R1
 2R10
@1 2 3 1
0 4 8 4
0 3 4 11
A
Multiplying the second row by  1=4 we get
0
@1 2 3 1
0 1 2 1
0 3 4 11
A
Adding 3Row#2 to the third row we obtain
0
@1 2 3 1
0 1 2 1
0 3 4 11
A 3R20
@1 2 3 1
0 1 2 1
0 0 2 41
A
Now we can use the so called back substitution to solve the system. Namely,
from the last row (equation) we get x3= 2. Then from the second equation
we get
x2= 1 2x3= 1 2( 2) = 3;
and nally, from the rst row (equation)
x1= 1 2x2 3x3= 1 6 + 6 = 1:
44 2. Systems of linear equations
So, the solution is8
<
:x1= 1
x2= 3;
x3= 2;
or in vector form
x=0
@1
3
 21
A
orx= (1;3; 2)T. We can check the solution by multiplying Ax, whereA
is the coecient matrix.
Instead of using back substitution, we can do row reduction from bottom
to top, killing all the entries above the main diagonal of the coecient
matrix: we start by multiplying the last row by 1 =2, and the rest is pretty
self-explanatory:
0
@1 2 3 1
0 1 2 1
0 0 1 21
A 3R3
 2R30
@1 2 0 7
0 1 0 3
0 0 1 21
A 2R2
0
@1 0 0 1
0 1 0 3
0 0 1 21
A
and we just read the solution x= (1;3; 2)To the augmented matrix.
We leave it as an exercise to the reader to formulate the algorithm for
the backward phase of the row reduction.
2.3. Echelon form. A matrix is in echelon form if it satises the following
two conditions:
1. All zero rows (i.e. the rows with all entries equal 0), if any, are below
all non-zero entries.
For a non-zero row, let us call the leftmost non-zero entry the leading entry .
Then the second property of the echelon form can be formulated as follows:
2. For any non-zero row its leading entry is strictly to the right of the
leading entry in the previous row.
The leading entry in each row in echelon form is also called pivot entry , Pivots: leading
(leftmost non-zero
entries) in a row.or simply pivot , because these entries are exactly the pivots we used in the
row reduction.
A particular case of the echelon form is the so-called triangular form.
We got this form in our example above. In this form the coecient matrix is
square (nn), all its entries on the main diagonal are non-zero, and all the
2. Solution of a linear system. Echelon and reduced echelon forms 45
entries below the main diagonal are zero. The right side, i.e. the rightmost
column of the augmented matrix can be arbitrary.
After the backward phase of the row reduction, we get what the so-
called reduced echelon form of the matrix: coecient matrix equal I, as in
the above example, is a particular case of the reduced echelon form.
The general denition is as follows: we say that a matrix is in the reduced
echelon form , if it is in the echelon form and
3. All pivot entries are equal 1;
4. All entries above the pivots are 0. Note, that all entries below the
pivots are also 0 because of the echelon form.
To get reduced echelon form from echelon form, we work from the bottom
to the top and from the right to the left, using row replacement to kill all
entries above the pivots.
An example of the reduced echelon form is the system with the coecient
matrix equal I. In this case, one just reads the solution from the reduced
echelon form. In general case, one can also easily read the solution from
the reduced echelon form. For example, let the reduced echelon form of the
system (augmented matrix) be
0
@12 0 0 0 1
0 0 15 0 2
0 0 0 0 131
A;
here we boxed the pivots. The idea is to move the variables, corresponding
to the columns without pivot (the so-called free variables ) to the right side.
Then we can just write the solution.
8
>>>><
>>>>:x1= 1 2x2
x2is free
x3= 2 5x4
x4is free
x5= 3
or in the vector form
x=0
BBBB@1 2x2
x2
2 5x4
x4
31
CCCCA=0
BBBB@1
0
2
0
31
CCCCA+x20
BBBB@ 2
1
0
0
01
CCCCA+x40
BBBB@0
0
 5
1
01
CCCCA; x 2;x42F:
One can also nd the solution from the echelon form by using back sub-
stitution: the idea is to work from bottom to top, moving all free variables
to the right side.
46 2. Systems of linear equations
Exercises.
2.1. Write the systems of equations below in matrix form and as vector equations:
a)8
<
:x1+ 2x2 x3= 1
2x1+ 2x2+x3= 1
3x1+ 5x2 2x3= 1
b)8
>><
>>:x1 2x2 x3= 1
2x1 3x2+x3= 6
3x1 5x2 = 7
x1 + 5x3= 9
c)8
>><
>>:x1+ 2x2 + 2x4= 6
3x1+ 5x2 x3+ 6x4= 17
2x1+ 4x2+x3+ 2x4= 12
2x1 7x3+ 11x4= 7
d)8
<
:x1 4x2 x3+x4= 3
2x1 8x2+x3 4x4= 9
 x1+ 4x2 2x3+ 5x4= 6
e)8
<
:x1+ 2x2 x3+ 3x4= 2
2x1+ 4x2 x3+ 6x4= 5
x2 + 2x4= 3
f)8
<
:2x1 2x2 x3+ 6x4 2x5= 1
x1 x2+x3+ 2x4 x5= 2
4x1 4x2+ 5x3+ 7x4 x5= 6
g)8
>><
>>:3x1 x2+x3 x4+ 2x5= 5
x1 x2 x3 2x4 x5= 2
5x1 2x2+x3 3x4+ 3x5= 10
2x1 x2 2x4+x5= 5
Solve the systems. Write the answers in the vector form.
2.2. Find allsolutions of the vector equation
x1v1+x2v2+x3v3=0;
where v1= (1;1;0)T,v2= (0;1;1)Tandv3= (1;0;1)T. What conclusion can you
make about linear independence (dependence) of the system of vectors v1;v2;v3?
3. Analyzing the pivots.
All questions about existence of a solution and it uniqueness can be answered
by analyzing pivots in the echelon (reduced echelon) form of the augmented
matrix of the system. First of all, let us investigate the question of when
is the equation Ax=binconsistent , i.e. when it does not have a solution.
The answer follows immediately, if one just thinks about it:
3. Analyzing the pivots. 47
a system is inconsistent (does not have a solution) if and only
if there is a pivot in the last column of an echelon form of the
augmented matrix, i.e. i an echelon form of the augmented matrix
has a row 
0 0:::0b
,b6= 0 in it.
Indeed, such a row correspond to the equation 0 x1+ 0x2+:::+ 0xn=b6= 0
that does not have a solution. If we don't have such a row, we just make
the reduced echelon form and then read the solution o it.
Now, three more statements. Note, they all deal with the coecient
matrix , and not with the augmented matrix of the system.
1. A solution (if it exists) is unique i there are no free variables, that
is if and only if the echelon form of the coecient matrix has a pivot
in every column;
2. Equation Ax=bis consistent for all right sides bif and only if the
echelon form of the coecient matrix has a pivot in every row.
3. Equation Ax=bhas a unique solution for any right side bif and
only if echelon form of the coecient matrix Ahas a pivot in every
column and every row.
The rst statement is trivial, because free variables are responsible for
all non-uniqueness. I should only emphasize that this statement does not
say anything about the existence.
The second statement is a tiny bit more complicated. If we have a pivot
in every row of the coecient matrix, we cannot have the pivot in the last
column of the augmented matrix, so the system is always consistent, no
matter what the right side bis.
Let us show that if we have a zero row in the echelon form of the coe-
cient matrix A, then we can pick a right side bsuch that the system Ax=b
is not consistent. Let Aeechelon form of the coecient matrix A. Then
Ae=EA;
whereEis the product of elementary matrices, corresponding to the row
operations, E=EN:::E 2E1. IfAehas a zero row, then the last row is also
zero. Therefore, if we put be= (0;:::; 0;1)T(all entries are 0, except the
last one), then the equation
Aex=be
does not have a solution. Multiplying this equation by E 1from the left,
and recalling that E 1Ae=A, we get that the equation
Ax=E 1be
does not have a solution.
Finally, statement 3 immediately follows from statements 1 and 2. 
48 2. Systems of linear equations
From the above analysis of pivots we get several very important corol-
laries. The main observation we use is
In echelon form, any row and any column have no more than 1
pivot in it (it can have 0 pivots)
3.1. Corollaries about linear independence and bases. Dimension.
Questions as to when a system of vectors in Fnis a basis, a linearly inde-
pendent or a spanning system, can be easily answered by the row reduction.
Proposition 3.1. Let us have a system of vectors v1;v2;:::;vm2Fn, and
letA= [v1;v2;:::;vm]be annmmatrix with columns v1;v2;:::;vm.
Then
1.The system v1;v2;:::;vmis linearly independent i echelon form of
Ahas a pivot in every column;
2.The system v1;v2;:::;vmis complete in Fn(spanning, generating)
i echelon form of Ahas a pivot in every row;
3.The system v1;v2;:::;vmis a basis in Fni echelon form of Ahas
a pivot in every column and in every row.
Proof. The system v1;v2;:::;vm2Fnis linearly independent if and only
if the equation
x1v1+x2v2+:::+xmvm=0
has the unique (trivial) solution x1=x2=:::=xm= 0, or equivalently,
the equation Ax=0has unique solution x=0. By statement 1 above, it
happens if and only if there is a pivot in every column of the matrix.
Similarly, the system v1;v2;:::;vm2Fnis complete in Fnif and only
if the equation
x1v1+x2v2+:::+xmvm=b
has a solution for any right side b2Fn. By statement 2 above, it happens
if and only if there is a pivot in every row in echelon form of the matrix.
And nally, the system v1;v2;:::;vm2Fnis a basis in Fnif and only
if the equation
x1v1+x2v2+:::+xmvm=b
has unique solution for any right side b2Fn. By statement 3 this happens
if and only if there is a pivot in every column and in every row of echelon
form ofA. 
Proposition 3.2. Any linearly independent system of vectors in Fncannot
have more than nvectors in it.
3. Analyzing the pivots. 49
Proof. Let a system v1;v2;:::;vm2Fnbe linearly independent, and let
A= [v1;v2;:::;vm] be thenmmatrix with columns v1;v2;:::;vm. By
Proposition 3.1 echelon form of Amust have a pivot in every column, which
is impossible if m > n (number of pivots cannot be more than number of
rows). 
Proposition 3.3. Any two bases in a vector space Vhave the same number
of vectors in them.
Proof. Letv1;v2;:::;vnandw1;w2;:::;wmbe two dierent bases in V.
Without loss of generality we can assume that nm. Consider an isomor-
phismA:Fn!Vdened by
Aek=vk; k = 1;2;:::n;
where e1;e2;:::;enis the standard basis in Rn.
SinceA 1is also an isomorphism, the system
A 1w1;A 1w2;:::;A 1wm
is a basis (see Theorem 6.6 in Chapter 1). So it is linearly independent,
and by Proposition 3.2, mn. Together with the assumption nmthis
implies that m=n. 
The statement below is a particular case of the above proposition.
Proposition 3.4. Any basis in Fnmust have exactly nvectors in it.
Proof. This fact follows immediately from the previous proposition, but
there is also a direct proof. Let v1;v2;:::;vmbe a basis in Fnand letAbe
thenmmatrix with columns v1;v2;:::;vm. The fact that the system is
a basis, means that the equation
Ax=b
has a unique solution for any (all possible) right side b. The existence means
that there is a pivot in every row (of a reduced echelon form of the matrix),
hence the number of pivots is exactly n. The uniqueness mean that there is
pivot in every column of the coecient matrix (its echelon form), so
m= number of columns = number of pivots = n

Proposition 3.5. Any spanning (generating) set in Fnmust have at least
nvectors.
Proof. Letv1;v2;:::;vmbe a complete system in Fn, and letAbenm
matrix with columns v1;v2;:::;vm. Statement 2 of Proposition 3.1 implies
50 2. Systems of linear equations
that echelon form of Ahas a pivot in every row. Since number of pivots
cannot exceed the number of columns, nm. 
3.2. Corollaries about invertible matrices.
Proposition 3.6. A matrixAis invertible if and only if its echelon form
has pivot in every column and every row.
Proof. As it was discussed in the beginning of the section, the equation
Ax=bhas a unique solution for any right side bif and only if the echelon
form ofAhas pivot in every row and every column. But, we know, see
Theorem 6.8 in Chapter 1, that the matrix (linear transformation) Ais
invertible if and only if the equation Ax=bhas a unique solution for any
possible right side b.
There is also an alternative proof. We know that a matrix is invertible
if and only if its columns form a basis in (see Corollary 6.9 in Section 6.4,
Chapter 1). Proposition 3.4 above states that it happens if and only if there
is a pivot in every row and every column. 
The above proposition immediately implies the following
Corollary 3.7. An invertible matrix must be square ( nn).
Proposition 3.8. If a square ( nn) matrix is left invertible, or if it is right
invertible, then it is invertible. In other words, to check the invertibility of a
square matrix Ait is sucient to check only one of the conditions AA 1=I,
A 1A=I.
Note, that this proposition applies only to square matrices!
Proof. We know that matrix Ais invertible if and only if the equation
Ax=bhas a unique solution for any right side b. This happens if and only
if the echelon form of the matrix Ahas pivots in every row and in every
column.
If a matrix Ais left invertible, the equation Ax=0has unique solution
x=0. Indeed, if Bis a left inverse of A(i.e.BA=I), and xsatises
Ax=0;
then multiplying this identity by Bfrom the left we get x=0, so the
solution is unique. Therefore, the echelon form of Ahas pivots in every
column (no free variables). If the matrix Ais square (nn), the echelon
form also has pivots in every row ( npivots, and a row can have no more
than 1 pivot), so the matrix is invertible.
3. Analyzing the pivots. 51
If a matrix Ais right invertible, and Cis its right inverse ( AC=I),
then for x=Cb,b2Fn
Ax=ACb=Ib=b:
Therefore, for any right side bthe equation Ax=bhas a solution x=Cb.
Thus, echelon form of Ahas a pivot in every row. If Ais square, it also has
a pivot in every column, so Ais invertible. 
Exercises.
3.1. For what value of bthe system
0
@1 2 2
2 4 6
1 2 31
Ax=0
@1
4
b1
A
has a solution. Find the general solution of the system for this value of b.
3.2. Determine, if the vectors
0
BB@1
1
0
01
CCA;0
BB@1
0
1
01
CCA;0
BB@0
0
1
11
CCA;0
BB@0
1
0
11
CCA
are linearly independent or not.
Do these four vectors span R4? (In other words, is it a generating system?)
What about C4?
3.3. Determine, which of the following systems of vectors are bases in R3:
a) (1;2; 1)T, (1;0;2)T, (2;1;1)T;
b) ( 1;3;2)T, ( 3;1;3)T, (2;10;2)T;
c) (67;13; 47)T, (; 7:84;0)T, (3;0;0)T.
Which of the systems are bases in C3?
3.4. Do the polynomials x3+ 2x,x2+x+ 1,x3+ 5 generate (span) P3? Justify
your answer.
3.5. Can 5 vectors in F4be linearly independent? Justify your answer.
3.6. Prove or disprove: If the columns of a square ( nn) matrixAare linearly
independent, so are the columns of A2=AA.
3.7. Prove or disprove: If the columns of a square ( nn) matrixAare linearly
independent, so are the rows of A3=AAA .
3.8. Show that if the equation Ax=0has unique solution (i.e. if echelon form of
Ahas pivot in every column), then Ais left invertible. Hint: elementary matrices
may help.
Note: It was shown in the text that if Ais left invertible, then the equation Ax=0
has unique solution. But here you are asked to prove the converse of this statement,
which was not proved.
52 2. Systems of linear equations
Remark: This can be a very hard problem, for it requires deep understanding
of the subject. However, when you understand what to do, the problem becomes
almost trivial.
3.9. Is the reduced echelon form of a matrix unique? Justify your conclusion.
Namely, suppose that by performing some row operations (not necessarily fol-
lowing any algorithm) we end up with a reduced echelon matrix. Do we always
end up with the same matrix, or can we get dierent ones? Note that we are only
allowed to perform row operations, the \column operations"' are forbidden.
Hint: What happens if you start with an invertible matrix? Also, are the pivots
always in the same columns, or can it be dierent depending on what row operations
you perform? If you can tell what the pivot columns are without reverting to row
operations, then the positions of pivot columns do not depend on them.
4. Finding A 1by row reduction.
As it was discussed above, an invertible matrix must be square, and its eche-
lon form must have pivots in every row and every column. Therefore reduced
echelon form of an invertible matrix is the identity matrix I. Therefore,
Any invertible matrix is row equivalent (i.e. can be reduced by row
operations) to the identity matrix.
Now let us state a simple algorithm of nding the inverse of an nn
matrix:
1. Form an augmented n2nmatrix (AjI) by writing the nnidentity
matrix right of A;
2. Performing row operations on the augmented matrix transform Ato
the identity matrix I;
3. The matrix Ithat we added will be automatically transformed to
A 1;
4. If it is impossible to transform Ato the identity by row operations,
Ais not invertible.
There are several possible explanations of the above algorithm. The
rst, a na ve one, is as follows: we know that (for an invertible A) the vector
A 1bis the solution of the equation Ax=b. So to nd the column number
kofA 1we need to nd the solution of Ax=ek, where e1;e2;:::;enis the
standard basis in Rn. The above algorithm just solves the equations
Ax=ek; k = 1;2;:::;n
simultaneously!
Let us also present another, more \advanced" explanation. As we dis-
cussed above, every row operation can be realized as a left multiplication
4. Finding A 1by row reduction. 53
by an elementary matrix. Let E1;E2;:::;ENbe the elementary matrices
corresponding to the row operation we performed, and let E=ENE2E1
be their product.1We know that the row operations transform Ato iden-
tity, i.e.EA=I, soE=A 1. But the same row operations transform the
augmented matrix ( AjI) to (EAjE) = (IjA 1). 
This \advanced" explanation using elementary matrices implies an im-
portant proposition that will be often used later.
Theorem 4.1. Any invertible matrix can be represented as a product of
elementary matrices.
Proof. As we discussed in the previous paragraph, A 1=ENE2E1, so
A= (A 1) 1=E 1
1E 1
2E 1
N:

An Example. Suppose we want to nd the inverse of the matrix
0
@1 4 2
 2 7 7
3 11 61
A:
Augmenting the identity matrix to it and performing row reduction we get
0
@1 4 21 0 0
 2 7 7 0 1 0
3 11 60 0 11
A+2R1
 3R10
@1 4 2 1 0 0
0 1 3 2 1 0
0 1 0 3 0 11
A
+R2
0
@1 4 2 1 0 0
0 1 3 2 1 0
0 0 3 1 1 11
A3
0
@3 12 6 3 0 0
0 1 3 2 1 0
0 0 3 1 1 11
A+2R3
 R3
Here in the last row operation we multiplied the rst row by 3 to avoid
fractions in the backward phase of row reduction. Continuing with the row
reduction we get
0
@3 12 0 1 2 2
0 1 0 3 0 1
0 0 3 1 1 11
A 12R2
0
@3 0 0 35 2 14
0 1 0 3 0 1
0 0 3 1 1 11
A
Dividing the rst and the last row by 3 we get the inverse matrix
0
@ 35=3 2=3 14=3
3 0 1
 1=3 1=3 1=31
A
1Although it does not matter here, but please notice, that if the row operation E1was
performed rst, E1must be the rightmost term in the product
54 2. Systems of linear equations
Exercises.
4.1. Find the inverse of the matrices0
@1 2 1
3 7 3
2 3 41
A;0
@1 1 2
1 1 2
1 1 41
A:
Show all steps
5. Dimension. Finite-dimensional spaces.
Denition. The dimension dim Vof a vector space Vis the number of
vectors in a basis.
For a vector space consisting only of zero vector 0we put dim V= 0. If
Vdoes not have a (nite) basis, we put dim V=1.
If dimVis nite, we call the space Vnite-dimensional ; otherwise we
call it innite-dimensional .
Proposition 3.3 asserts that the dimension is well dened, i.e. that it
does not depend on the choice of a basis.
Proposition 2.8 from Chapter 1 states that any nite spanning system
in a vector space Vcontains a basis. This immediately implies the following
Proposition 5.1. A vector space Vis nite-dimensional if and only if it
has a nite spanning system.
Suppose, that we have a system of vectors in a nite-dimensional vector
space, and we want to check if it is a basis (or if it is linearly independent,
or if it is complete)? Probably the simplest way is to use an isomorphism
A:V!Rn,n= dimEto move the problem to Rn, where all such questions
can be answered by row reduction (studying pivots).
Note, that if dim V=n, then there always exists an isomorphism A:
V!Rn. Indeed, if dim V=nthen there exists a basis v1;v2;:::;vn2V,
and one can dene an isomorphism A:V!Rnby
Avk=ek; k = 1;2;:::;n:
As an example, let us give the following two corollaries of the above
Propositions 3.2, 3.5:
Proposition 5.2. Any linearly independent system in a nite-dimensional
vector space Vcannot have more than dimVvectors in it.
Proof. Letv1;v2;:::;vm2Vbe a linearly independent system, and let
A:V!Rnbe an isomorphism. Then Av1;Av2;:::;A vmis a linearly
independent system in Rn, and by Proposition 3.2 mn. 
5. Dimension. Finite-dimensional spaces. 55
Proposition 5.3. Any generating system in a nite-dimensional vector
spaceVmust have at least dimVvectors in it.
Proof. Letv1;v2;:::;vm2Vbe a complete system in V, and letA:V!
Rnbe an isomorphism. Then Av1;Av2;:::;A vmis a complete system in
Rn, and by Proposition 3.5 mn. 
5.1. Completing a linearly independent system to a basis. The fol-
lowing statement will play an important role later.
Proposition 5.4 (Completion to a basis) .A linearly independent system
of vectors in a nite-dimensional space can be completed to a basis, i.e. if
v1;v2;:::;vrare linearly independent vectors in a nite-dimensional vector
spaceVthen one can nd vectors vr+1;vr+2:::;vnsuch that the system of
vectors v1;v2;:::;vnis a basis in V.
Proof. Letn= dimV.Take any vector not belonging to span fv1;v2;:::;vrg
and call it vr+1(one can always do that because the system v1;v2;:::;vris
not generating). By Exercise 2.5 from Chapter 1 the system v1;:::;vr;vr+1
is linearly independent (notice that in this case r < n by Proposition 5.2).
Repeat the procedure with the new system to get vector vr+2, and so on.
We will stop the process when we get a generating system. Note, that
the process cannot continue innitely, because a linearly independent system
of vectors in Vcannot have more than n= dimVvectors. 
5.2. Subspaces of nite dimensional spaces.
Theorem 5.5. LetVbe a subspace of a vector space W,dimW <1. Then
Vis nite dimensional and dimVdimW.
Moreover, if dimV= dimWthenV=W(we are still assuming that V
is a subspace of Where).
Remark. This theorem looks like a complete banality, like an easy corollary
of Proposition 5.2. But we can apply Proposition 5.2 only if we already have
a basis inV. And we only have a basis in W, and we cannot say how many
vectors in this basis belong to V; in fact, it is easy to construct an example
where none of the vectors in the basis of Wbelongs toV.
Proof of Theorem 5.5. IfV=f0gthen the theorem is trivial, so let us
assume otherwise.
We want to nd a basis in V. Take a non-zero vector v12V. If
V= spanfv1g, we got our basis (consisting of the one vector v1).
If not, we continue by induction. Suppose we constructed rlinearly
independent vectors v1;:::;vr2V. IfV= spanfvk: 1krg,
56 2. Systems of linear equations
then we have found a basis in V. If not, there exists a vector vr+12V,
vr+1=2spanfvk: 1krg. By Exercise 2.5 from Chapter 1 the system
v1;:::;vr;vr+1is linearly independent.

Exercises.
5.1. True or false:
a) Every vector space that is generated by a nite set has a basis;
b) Every vector space has a (nite) basis;
c) A vector space cannot have more than one basis;
d) If a vector space has a nite basis, then the number of vectors in every
basis is the same.
e) The dimension of Pnisn;
f) The dimension on Mmnism+n;
g) If vectors v1;v2;:::;vngenerate (span) the vector space V, then every
vector inVcan be written as a linear combination of vector v1;v2;:::;vn
in only one way;
h) Every subspace of a nite-dimensional space is nite-dimensional;
i) IfVis a vector space having dimension n, thenVhas exactly one subspace
of dimension 0 and exactly one subspace of dimension n.
5.2. Prove that if Vis a vector space having dimension n, then a system of vectors
v1;v2;:::;vninVis linearly independent if and only if it spans V.
5.3. Prove that a linearly independent system of vectors v1;v2;:::;vnin a vector
spaceVis a basis if and only if n= dimV.
5.4. (An old problem revisited: now this problem should be easy) Is it possible that
vectors v1;v2;v3are linearly dependent, but the vectors w1=v1+v2,w2=v2+v3
andw3=v3+v1are linearly independent ?Hint: What dimension can the
subspace span( v1;v2;v3) have?
5.5. Let vectors u;v;wbe a basis in V. Show that u+v+w;v+w;wis also a
basis inV.
5.6. Consider in the space R5vectors v1= (2; 1;1;5; 3)T,v2= (3; 2;0;0;0)T,
v3= (1;1;50; 921;0)T.
a) Prove that these vectors are linearly independent.
b) Complete this system of vectors to a basis.
If you do part b) rst you can do everything without any computations.
6. General solution of a linear system.
In this short section we discuss the structure of the general solution (i.e. of
the solution set) of a linear system.
6. General solution of a linear system. 57
We call a system Ax=bhomogeneous if the right side b=0, i.e. a
homogeneous system is a system of form Ax=0.
With each system
Ax=b
we can associate a homogeneous system just by putting b=0.
Theorem 6.1 (General solution of a linear equation) .Let a vector x1satisfy
the equation Ax=b, and letHbe the set of all solutions of the associated
homogeneous system
Ax=0:
Then the set
fx=x1+xh:xh2Hg
is the set of all solutions of the equation Ax=b.
In other words, this theorem can be stated as
General solution
ofAx=b=A particular solu-
tion ofAx=b+General solution
ofAx=0:
Proof. Fix a vector x1satisfyingAx1=b. Let a vector xhsatisfyAxh=0.
Then for x=x1+xhwe have
Ax=A(x1+xh) =Ax1+Axh=b+0=b;
so any xof form
x=x1+xh; xh2H
is a solution of Ax=b.
Now let xsatisfyAx=b. Then for xh:=x x1we get
Axh=A(x x1) =Ax Ax1=b b=0;
soxh2H. Therefore any solution xofAx=bcan be represented as
x=x1+xhwith some xh2H. 
The power of this theorem is in its generality. It applies to all linear
equations, we do not have to assume here that vector spaces are nite-
dimensional. You will meet this theorem in dierential equations, integral
equations, partial dierential equations, etc. Besides showing the struc-
ture of the solution set, this theorem allows one to separate investigation
of uniqueness from the study of existence. Namely, to study uniqueness,
we only need to analyze uniqueness of the homogeneous equation Ax=0,
which always has a solution.
58 2. Systems of linear equations
There is an immediate application in this course: this theorem allows us
to check a solution of a system Ax=b. For example, consider a system
0
BB@2 3 1 4 9
1 1 1 1 3
1 1 1 2 5
2 2 2 3 81
CCAx=0
BB@17
6
8
141
CCA:
Performing row reduction one can nd the solution of this system
(6.1) x=0
BBBB@3
1
0
2
01
CCCCA+x30
BBBB@ 2
1
1
0
01
CCCCA+x50
BBBB@2
 1
0
2
11
CCCCA; x 3;x52F:
The parameters x3,x5can be denoted here by any other letters, tands,
for example; we are keeping notation x3andx5here only to remind us that
the parameters came from the corresponding free variables.
Now, let us suppose, that we are just given this solution, and we want
to check whether or not it is correct. Of course, we can repeat the row
operations, but this is too time consuming. Moreover, if the solution was
obtained by some non-standard method, it can look dierently from what
we get from the row reduction. For example, the formula
(6.2) x=0
BBBB@3
1
0
2
01
CCCCA+s0
BBBB@ 2
1
1
0
01
CCCCA+t0
BBBB@0
0
1
2
11
CCCCA; s;t2F
gives the same set as (6.1) (can you say why?); here we just replaced the last
vector in (6.1) by its sum with the second one. So, this formula is dierent
from the solution we got from the row reduction, but it is nevertheless
correct.
The simplest way to check that (6.1) and (6.2) give us correct solutions,
is to check that the rst vector (3 ;1;0;2;0)Tsatises the equation Ax=b,
and that the other two (the ones with the parameters x3andx5orsandtin
front of them) should satisfy the associated homogeneous equation Ax=0.
If this checks out, we will be assured that any vector xdened by (6.1)
or (6.2) is indeed a solution.
Note, that this method of checking the solution does not guarantee that
(6.1) (or (6.2)) gives us all the solutions. For example, if we just somehow
miss out the term with x3, the above method of checking will still work ne.
7. Fundamental subspaces of a matrix. Rank. 59
So, how can we guarantee, that we did not miss any free variable, and
there should not be extra term in (6.1)?
What comes to mind, is to count the pivots again. In this example, if
one does row operations, the number of pivots is 3. So indeed, there should
be 2 free variables, and it looks like we did not miss anything in (6.1).
To be able to prove this, we will need new notions of fundamental sub-
spaces and of rank of a matrix. I should also mention that in this particular
example, one does not have to perform all row operations to check that there
are only 2 free variables, and that formulas (6.1) and (6.2) both give correct
general solutions.
Exercises.
6.1. True or false
a) Any system of linear equations has at least one solution;
b) Any system of linear equations has at most one solution;
c) Any homogeneous system of linear equations has at least one solution;
d) Any system of nlinear equations in nunknowns has at least one solution;
e) Any system of nlinear equations in nunknowns has at most one solution;
f) If the homogeneous system corresponding to a given system of a linear
equations has a solution, then the given system has a solution;
g) If the coecient matrix of a homogeneous system of nlinear equations in
nunknowns is invertible, then the system has no non-zero solution;
h) The solution set of any system of mequations in nunknowns is a subspace
inRn;
i) The solution set of any homogeneous system of mequations in nunknowns
is a subspace in Rn.
6.2. Find a 23 system (2 equations with 3 unknowns) such that its general
solution has a form0
@1
1
01
A+s0
@1
2
11
A; s2R:
7. Fundamental subspaces of a matrix. Rank.
As we discussed above in Section 7 of Chapter 1, with any linear transfor-
mationA:V!Wwe can associate two subspaces, namely, its kernel, or
null space
KerA= NullA:=fv2V:Av=0gV;
and its range
RanA=fw2W:w=Avfor some v2VgW:
60 2. Systems of linear equations
In other words, the kernel Ker Ais the solution set of the homogeneous
equationAx=0, and the range Ran Ais exactly the set of all right sides
b2Wfor which the equation Ax=bhas a solution.
IfAis anmnmatrix, i.e. a mapping from FntoFm, then it follows
from the \column by coordinate" rule of the matrix multiplication that any
vector w2RanAcan be represented as a linear combination of columns of
A. This explains the name column space (notation Col A), which is often
used instead of Ran A.
IfAis a matrix, then in addition to Ran Aand KerAone can also
consider the range and kernel for the transposed matrix AT. Often the term
row space is used for Ran ATand the term left null space is used for Ker AT
(but usually no special notation is introduced).
The four subspaces Ran A, KerA, RanAT, KerATare called the funda-
mental subspaces of the matrix A. In this section we will study important
relations between the dimensions of the four fundamental subspaces.
We will need the following denition, which is one of the fundamental
notions of Linear Algebra
Denition. Given a linear transformation (matrix) Aits rank, rank A, is
the dimension of the range of A
rankA:= dim Ran A:
7.1. Computing fundamental subspaces and rank. To compute the
fundamental subspaces and rank of a matrix, one needs to do echelon re-
duction. Namely, let Abe the matrix, and Aebe its echelon form
1. The pivot columns of the original matrixA(i.e. the columns where
after row operations we will have pivots in the echelon form) give us
a basis (one of many possible) in Ran A.
2. The pivot rows of the echelon from Aegive us a basis in the row
space. Of course, it is possible just to transpose the matrix, and
then do row operations. But if we already have the echelon form of
A, say by computing Ran A, then we get Ran ATfor free.
3. To nd a basis in the null space Ker Aone needs to solve the homo-
geneous equation Ax=0: the details will be seen from the example
below.
Example. Consider a matrix
0
BB@1 1 2 2 1
2 2 1 1 1
3 3 3 3 2
1 1 1 1 01
CCA:
7. Fundamental subspaces of a matrix. Rank. 61
Performing row operations we get the echelon form
0
BB@11 2 2 1
0 0 3 3 1
0 0 0 0 0
0 0 0 0 01
CCA
(the pivots are boxed here). So, the columns 1 and 3 of the original matrix ,
i.e. the columns
0
BB@1
2
3
11
CCA;0
BB@2
1
3
 11
CCA
give us a basis in Ran A. We also get a basis for the row space Ran ATfor
free: the rst and second row of the echelon form ofA, i.e. the vectors
0
BBBB@1
1
2
2
11
CCCCA;0
BBBB@0
0
 3
 3
 11
CCCCA
(we put the vectors vertically here. The question of whether to put vectors
here vertically as columns, or horizontally as rows is is really a matter of
convention. Our reason for putting them vertically is that although we call
RanATtherow space we dene it as a column space of AT)
To compute the basis in the null space Ker Awe need to solve the equa-
tionAx=0. Compute the reduced echelon form of A, which in this example
is
0
BB@11 0 0 1 =3
0 0 11 1=3
0 0 0 0 0
0 0 0 0 01
CCA:
Note, that when solving the homogeneous equation Ax=0, it is not neces-
sary to write the whole augmented matrix, it is sucient to work with the
coecient matrix. Indeed, in this case the last column of the augmented
matrix is the column of zeroes, which does not change under row opera-
tions. So, we can just keep this column in mind, without actually writing
it. Keeping this last zero column in mind, we can read the solution o the
62 2. Systems of linear equations
reduced echelon form above:
8
>>>><
>>>>:x1= x2 1
3x5;
x2is free;
x3= x4 1
3x5
x4is free;
x5is free;
or, in the vector form
(7.1) x=0
BBBB@ x2 1
3x5
x2
 x4 1
3x5
x4
x51
CCCCA=x20
BBBB@ 1
1
0
0
01
CCCCA+x40
BBBB@0
0
 1
1
01
CCCCA+x50
BBBB@ 1=3
0
 1=3
0
11
CCCCA
The vectors at each free variable, i.e. in our case the vectors
0
BBBB@ 1
1
0
0
01
CCCCA;0
BBBB@0
0
 1
1
01
CCCCA;0
BBBB@ 1=3
0
 1=3
0
11
CCCCA
form a basis in Ker A.
Unfortunately, there is no shortcut for nding a basis in Ker AT, one
must solve the equation ATx=0. The knowledge of the echelon form of A
does not help here.
7.2. Explanation of the computing bases in the fundamental sub-
spaces. So, why do the above methods indeed give us bases in the funda-
mental subspaces?
7.2.1. The null space KerA.The case of the null space Ker Ais probably
the simplest one: since we solved the equation Ax=0, i.e. found all the
solutions, then any vector in Ker Ais a linear combination of the vectors we
obtained. Thus, the vectors we obtained form a spanning system in Ker A.
To see that the system is linearly independent, let us multiply each vector
by the corresponding free variable and add everything, see (7.1). Then for
each free variable xk, the entry number kof the resulting vector is exactly
xk, see (7.1) again, so the only way this vector (the linear combination) can
be0is when all free variables are 0.
7.2.2. The column space RanA.Let us now explain why the method for
nding a basis in the column space Ran Aworks. First of all, notice that
the pivot columns of the reduced echelon formAreofAform a basis in
RanAre(not in the column space of the original matrix, but of its reduced
7. Fundamental subspaces of a matrix. Rank. 63
echelon form!). Since row operations are just left multiplications by invert-
ible matrices, they do not change linear independence. Therefore, the pivot
columns of the original matrixAare linearly independent.
Let us now show that the pivot columns of Aspan the column space
ofA. Let v1;v2;:::;vrbe the pivot columns of A, and let vbe an arbi-
trary column of A. We want to show that vcan be represented as a linear
combination of the pivot columns v1;v2;:::;vr,
v=1v1+2v2+:::+rvr:
The reduced echelon form Areis obtained from Aby the left multiplication
Are=EA;
whereEis a product of elementary matrices, so Eis an invertible matrix.
The vectors Ev1;Ev2;:::;E vrare the pivot columns of Are, and the column
vofAis transformed to the column EvofAre. Since the pivot columns
ofAreform a basis in Ran Are, vectorEvcan be represented as a linear
combination
Ev=1Ev1+2Ev2+:::+rEvr:
Multiplying this equality by E 1from the left we get the representation
v=1v1+2v2+:::+rvr;
so indeed the pivot columns of Aspan RanA.
7.2.3. The row space RanAT.It is easy to see that the pivot rows of the
echelon form AeofAare linearly independent. Indeed, let w1;w2;:::;wr
be the transposed (since we agreed always to put vectors vertically) pivot
rows ofAe. Suppose
1w1+2w2+:::+rwr=0:
Consider the rst non-zero entry of w1. Since for all other vectors
w2;w3;:::;wrthe corresponding entries equal 0 (by the denition of eche-
lon form), we can conclude that 1= 0. So we can just ignore the rst term
in the sum.
Consider now the rst non-zero entry of w2. The corresponding entries
of the vectors w3;:::;wrare 0, so2= 0. Repeating this procedure, we
get thatk= 08k= 1;2;:::;r .
To see that vectors w1;w2;:::;wrspan the row space, one can notice
that row operations do not change the row space . This can be obtained
directly from analyzing row operations, but we present here a more formal
way to demonstrate this fact.
For a transformation Aand a setXlet us denote by A(X) the set of all
elementsywhich can represented as y=A(x),x2X,
A(X) :=fy=A(x) :x2Xg:
64 2. Systems of linear equations
IfAis anmnmatrix, and Aeis its echelon form, Aeis obtained from
Abe left multiplication
Ae=EA;
whereEis anmminvertible matrix (the product of the corresponding
elementary matrices). Then
RanAT
e= Ran(ATET) =AT(RanET) =AT(Rm) = RanAT;
so indeed Ran AT= RanAT
e.
7.3. The Rank Theorem. Dimensions of fundamental subspaces.
There are many applications in which one needs to nd a basis in column
space or in the null space of a matrix. For example, as it was shown above,
solving a homogeneous equation Ax=0amounts to nding a basis in
the null space Ker A. Finding a basis in the column space means simply
extracting a basis from a spanning set, by removing unnecessary vectors
(columns).
However, the most important application of the above methods of com-
puting bases of fundamental subspaces is the relations between their dimen-
sions.
Theorem 7.1 (The Rank Theorem) .For a matrix A
rankA= rankAT:
This theorem is often stated as follows:
The column rank of a matrix coincides with its row rank .
The proof of this theorem is trivial, since dimensions of both Ran Aand
RanATare equal to the number of pivots in the echelon form of A.
The following theorem is gives us important relations between dimen-
sions of the fundamental spaces. It is often also called the Rank Theorem
Theorem 7.2. LetAbe anmnmatrix, i.e. a linear transformation from
FntoFm. Then
1. dim KerA+ dim RanA= dim KerA+ rankA=n(dimension of the
domain ofA);
2. dim KerAT+ dim RanAT= dim KerAT+ rankAT=
dim KerAT+ rankA=m(dimension of the target space of A);
Proof. The proof, modulo the above algorithms of nding bases in the
fundamental subspaces, is almost trivial. The rst statement is simply the
fact that the number of free variables (dim Ker A) plus the number of basic
variables (i.e. the number of pivots, i.e. rank A) adds up to the number of
columns (i.e. to n).
7. Fundamental subspaces of a matrix. Rank. 65
The second statement, if one takes into account that rank A= rankAT
is simply the rst statement applied to AT. 
As an application of the above theorem, let us recall the example from
Section 6. There we considered a system
0
BB@2 3 1 4 9
1 1 1 1 3
1 1 1 2 5
2 2 2 3 81
CCAx=0
BB@17
6
8
141
CCA;
and we claimed that its general solution given by
x=0
BBBB@3
1
0
2
01
CCCCA+x30
BBBB@ 2
1
1
0
01
CCCCA+x50
BBBB@2
 1
0
2
11
CCCCA; x 3;x52F;
or by
x=0
BBBB@3
1
0
2
01
CCCCA+s0
BBBB@ 2
1
1
0
01
CCCCA+t0
BBBB@0
0
1
2
11
CCCCA; s;t2F:
We checked in Section 6 that a vector xgiven by either formula is indeed
a solution of the equation. But, how can we guarantee that any of the
formulas describe allsolutions?
First of all, we know that in either formula, the last 2 vectors (the ones
multiplied by the parameters) belong to Ker A. It is easy to see that in
either case both vectors are linearly independent (two vectors are linearly
dependent if and only if one is a multiple of the other).
Now, let us count dimensions: interchanging the rst and the second
rows and performing rst round of row operations
 2R1
 R1
 2R10
BB@1 1 1 1 3
2 3 1 4 9
1 1 1 2 5
2 2 2 3 81
CCA0
BB@1 1 1 1 3
0 1 1 2 3
0 0 0 1 2
0 0 0 1 21
CCA
we see that there are three pivots already, so rank A3. (Actually, we
already can see that the rank is 3, but it is enough just to have the estimate
here). By Theorem 7.2, rank A+ dim KerA= 5, hence dim Ker A2, and
therefore there cannot be more than 2 linearly independent vectors in Ker A.
Therefore, last 2 vectors in either formula form a basis in Ker A, so either
formula give all solutions of the equation.
66 2. Systems of linear equations
An important corollary of the rank theorem, is the following theorem
connecting existence and uniqueness for linear equations.
Theorem 7.3. LetAbe anmnmatrix. Then the equation
Ax=b
has a solution for every b2Rmif and only if the dual equation
ATx=0
has a unique (only the trivial) solution. (Note, that in the second equation
we haveAT, notA).
Proof. The proof follows immediately from Theorem 7.2 by counting the
dimensions. We leave the details as an exercise to the reader. 
There is a very nice geometric interpretation of the second rank the-
orem (Theorem 7.2). Namely, statement 1 of the theorem says, that if a
transformation A:Fn!Fmhas trivial kernel (Ker A=f0g), then the
dimensions of the domain Fnand of the range Ran Acoincide. If the ker-
nel is non-trivial, then the transformation \kills" dim Ker Adimensions, so
dim RanA=n dim KerA.
7.4. Completion of a linearly independent system to a basis. As
Proposition 5.4 from Section 5 above asserts, any linearly independent sys-
tem can be completed to a basis, i.e. given inearly independent vectors
v1;v2;:::;vrin a nite-dimensional vector space V, one can nd vectors
vr+1;vr+2:::;vnsuch that the system of vectors v1;v2;:::;vnis a basis in
V.
Theoretically, the proof of this proposition give us an algorithm of nding
the vectors vr+1;vr+2:::;vn, but this algorithm does not look too practical.
Ideas of this section give us a more practical way to perform the com-
pletion to a basis.
First of all, notice that if an mnmatrix is in an echelon form, then its
non-zero rows (which are clearly linearly independent) can be easily com-
pleted to a basis in the whole space Fn; one just needs to add some rows in
appropriate places, so the resulting matrix is still in the echelon form and
has pivots in every column.
Then, the non-zero rows of the new matrix form a basis, and we can
order it any way we want, because property of being basis does not depend
on the ordering.
Suppose now that we have linearly independent vectors v1;v2;:::;vr,
vk2Fn. Consider the matrix Awith rows vT
1;vT
2;:::;vT
rand perform row
operations to get the echelon form Ae. As we discussed above, the rows of
7. Fundamental subspaces of a matrix. Rank. 67
Aecan be easily completed to a basis in Rn. And it turns out that the same
vectors that complete rows of Aeto a basis complete to a basis the original
vectors v1;v2;:::;vr.
To see that, let vectors vr+1;:::;vncomplete the rows of Aeto a basis in
Fn. Then, if we add to a matrix AerowsvT
r+1;:::;vT
n, we get an invertible
matrix. Let call this matrix eAe, and leteAbe the matrix obtained from A
by adding rows vT
r+1;:::;vT
n. The matrix eAecan be obtained from eAby
row operations, so
eAe=EeA;
whereEis the product of the corresponding elementary matrices. Then
eA=E 1andeAis invertible as a product of invertible matrices.
But that means that the rows of eAform a basis in Fn, which is exactly
what we need.
Remark. The method of completion to a basis described above may be not
the simplest one, but one of its principal advantages is that it works for
vector spaces over an arbitrary eld.
Exercises.
7.1. True or false:
a) The rank of a matrix is equal to the number of its non-zero columns;
b) Themnzero matrix is the only mnmatrix having rank 0;
c) Elementary row operations preserve rank;
d) Elementary column operations do not necessarily preserve rank;
e) The rank of a matrix is equal to the maximum number of linearly inde-
pendent columns in the matrix;
f) The rank of a matrix is equal to the maximum number of linearly inde-
pendent rows in the matrix;
g) The rank of an nnmatrix is at most n;
h) Annnmatrix having rank nis invertible.
7.2. A 5437 matrix has rank 31. What are dimensions of all 4 fundamental
subspaces?
7.3. Compute rank and nd bases of all four fundamental subspaces for the matrices
0
@1 1 0
0 1 1
1 1 01
A;0
BB@1 2 3 1 1
1 4 0 1 2
0 2 3 0 1
1 0 0 0 01
CCA:
7.4. Prove that if A:X!YandVis a subspace of Xthen dimAVrankA. (AV
here means the subspace Vtransformed by the transformation A, i.e. any vector in
AVcan be represented as Av,v2V). Deduce from here that rank( AB)rankA.
68 2. Systems of linear equations
Remark: Here one can use the fact that if VWthen dimVdimW. Do you
understand why is it true?
7.5. Prove that if A:X!YandVis a subspace of Xthen dimAVdimV.
Deduce from here that rank( AB)rankB.
7.6. Prove that if the product ABof twonnmatrices is invertible, then both A
andBare invertible. Even if you know about determinants, do not use them, we
did not cover them yet. Hint: use previous 2 problems.
7.7. Prove that if Ax=0has unique solution, then the equation ATx=bhas a
solution for every right side b.
Hint: count pivots
7.8. Write a matrix with the required property, or explain why no such matrix
exists
a) Column space contains (1 ;0;0)T, (0;0;1)T, row space contains (1 ;1)T,
(1;2)T;
b) Column space is spanned by (1 ;1;1)T, nullspace is spanned by (1 ;2;3)T;
c) Column space is R4, row space is R3.
Hint: Check rst if the dimensions add up.
7.9. IfAhas the same four fundamental subspaces as B, doesA=B?
7.10. Complete the rows of a matrix0
BB@e33 4 0  6 2
0 0 2 1e1 1
0 0 0 0 3  3 2
0 0 0 0 0 0 11
CCA
to a basis in R7.
7.11. For a matrix 0
BB@1 2 1 2 3
2 2 1 5 5
3 6 3 0 24
 1 4 4 7 111
CCA
nd bases in its column and row spaces.
7.12. For the matrix in the previous problem, complete the basis in the row space
to a basis in R5
7.13. For the matrix
A=
1i
i 1
compute Ran Aand KerA. What can you say about relation between these sub-
spaces?
7.14. Is it possible that for a real matrix Athat RanA= KerAT? Is it possible
for a complex A?
7.15. Complete the vectors (1 ;2; 1;2;3)T, (2;2;1;5;5)T, ( 1; 4;4;7; 11)Tto
a basis in R5.
8. Change of coordinates 69
8. Representation of a linear transformation in arbitrary
bases. Change of coordinates formula.
The material we have learned about linear transformations and their matri-
ces can be easily extended to transformations in abstract vector spaces with
nite bases. In this section we will distinguish between a linear transforma-
tionTand its matrix, the reason being that we consider dierent bases, so
a linear transformation can have dierent matrix representation.
8.1. Coordinate vector. LetVbe a vector space with a basis B:=
fb1;b2;:::;bng. Any vector v2Vadmits a unique representation as a
linear combination
v=x1b1+x2b2+:::+xnbn=nX
k=1xkbk:
The numbers x1;x2;:::;xnare called the coordinates of the vector vin
the basisB. It is convenient to join these coordinates into the so-called
coordinate vector ofvrelative to the basis B, which is the column vector
[v]B:=0
BBB@x1
x2
...
xn1
CCCA2Fn:
Note that the mapping
v7![v]B
is an isomorphism between VandFn. It transforms the basis b1;b2;:::;bn
to the standard basis e1;e2;:::;eninFn.
8.2. Matrix of a linear transformation. LetT:V!Wbe a linear
transformation, and let A=fa1;a2;:::;ang,B:=fb1;b2;:::;bmgbe bases
inVandWrespectively.
A matrix of the transformation Tin (or with respect to) the bases A
andBis anmnmatrix, denoted by [ T]BA, which relates the coordinate
vectors [Tv]Band [v]A,
[Tv]B= [T]BA[v]A;
notice the balance of symbols AandBhere: this is the reason we put the
rst basisAinto the second position.
The matrix [ T]BAis easy to nd: its kth column is just the coordinate
vector [Tak]B(compare this with nding the matrix of a linear transforma-
tion from FntoFm).
70 2. Systems of linear equations
As in the case of standard bases, composition of linear transformations
is equivalent to multiplication of their matrices: one only has to be a bit
more careful about bases. Namely, let T1:X!YandT2:Y!Zbe linear
transformation, and let A;BandCbe bases in X,YandZrespectively.
Then for the composition T=T2T1,
T:X!Z; T x:=T2(T1(x))
we have
(8.1) [ T]CA= [T2T1]CA= [T2]CB[T1]BA
(notice again the balance of indices here).
The proof here goes exactly as in the case of Fnspaces with standard
bases, so we do not repeat it here. Another possibility is to transfer every-
thing to the spaces Fnvia the coordinate isomorphisms v7![v]B. Then one
does not need any proof, everything follows from the results about matrix
multiplication.
8.3. Change of coordinate matrix. Let us have two bases A=
fa1;a2;:::;angandB=fb1;b2;:::;bngin a vector space V. Consider
the identity transformation I=IVand its matrix [ I]BAin these bases. By
the denition
[v]B= [I]BA[v]A;8v2V;
i.e. for any vector v2Vthe matrix [ I]BAtransforms its coordinates in the
basisAinto coordinates in the basis B. The matrix [ I]BAis often called the
change of coordinates (from the basisAto the basisB) matrix.
The matrix [ I]BAis easy to compute: according to the general rule of
nding the matrix of a linear transformation, its kth column is the coordi-
nate representation [ ak]Bofkth element of the basis A
Note that
[I]AB= ([I]BA) 1;
(follows immediately from the multiplication of matrices rule (8.1)), so any
change of coordinate matrix is always invertible.
8.3.1. An example: change of coordinates from the standard basis. Let our
spaceVbeFn, and let us have a basis B=fb1;b2;:::;bngthere. We
also have the standard basis S=fe1;e2;:::;engthere. The change of
coordinates matrix [ I]SBis easy to compute:
[I]SB= [b1;b2;:::;bn] =:B;
i.e. it is just the matrix Bwhosekth column is the vector (column) vk. And
in the other direction
[I]BS= ([I]SB) 1=B 1:
8. Change of coordinates 71
For example, consider a basis
B=1
2
;2
1
inF2, and letSdenote the standard basis there. Then
[I]SB=1 2
2 1
=:B
and
[I]BS= [I] 1
SB=B 1=1
3 1 2
2 1
(we know how to compute inverses, and it is also easy to check that the
above matrix is indeed the inverse of B)
8.3.2. An example: going through the standard basis. In the space of poly-
nomials of degree at most 1 we have bases
A=f1;1 +xg;andB=f1 + 2x;1 2xg;
and we want to nd the change of coordinate matrix [ I]BA.
Of course, we can always take vectors from the basis Aand try to de-
compose them in the basis B; it involves solving linear systems, and we know
how to do that.
However, I think the following way is simpler. In P1we also have the
standard basisS=f1;xg, and for this basis
[I]SA=1 1
0 1
=:A; [I]SB=1 1
2 2
=:B;
and taking the inverses
[I]AS=A 1=1 1
0 1
; [I]BS=B 1=1
42 1
2 1
:
Then
[I]BA= [I]BS[I]SA=B 1A=1
42 1
2 11 1
0 1
and Notice the balance
of indices here.
[I]AB= [I]AS[I]SB=A 1B=1 1
0 11 1
2 2
72 2. Systems of linear equations
8.4. Matrix of a transformation and change of coordinates. Let
T:V!Wbe a linear transformation, and let A,eAbe two bases in Vand
letB,eBbe two bases in W. Suppose we know the matrix [ T]BA, and we
would like to nd the matrix representation with respect to new bases eA,
eB, i.e. the matrix [ T]eBeA. The rule is very simple:
to get the matrix in the \new" bases one has to surround the
matrix in the \old" bases by change of coordinates matrices.
I did not mention here what change of coordinate matrix should go where,
because we don't have any choice if we follow the balance of indices rule.
Namely, matrix representation of a linear transformation changes according
to the formula Notice the balance
of indices.[T]eBeA= [I]eBB[T]BA[I]
AeA
The proof can be done just by analyzing what each of the matrices does.
8.5. Case of one basis: similar matrices. LetVbe a vector space and
letA=fa1;a2;:::;angbe a basis in V. Consider a linear transformation
T:V!Vand let [T]AAbe its matrix in this basis (we use the same basis
for \inputs" and \outputs")
The case when we use the same basis for \inputs" and \outputs" is
very important (because in this case we can multiply a matrix by itself), so
let us study this case a bit more carefully. Notice, that very often in this [T]Ais often used in-
stead of [T]AA. It is
shorter, but two in-
dex notation is bet-
ter adapted to the
balance of indices
rule.case the shorter notation [ T]Ais used instead of [ T]AA. However, the two
index notation [ T]AAis better adapted to the balance of indices rule, so I
recommend using it (or at least always keep it in mind) when doing change
of coordinates.
LetB=fb1;b2;:::;bngbe another basis in V. By the change of
coordinate rule above
[T]BB= [I]BA[T]AA[I]AB
Recalling that
[I]BA= [I] 1
AB
and denoting Q:= [I]AB, we can rewrite the above formula as
[T]BB=Q 1[T]AAQ:
This gives a motivation for the following denition
Denition 8.1. We say that a matrix Ais similar to a matrix Bif there
exists an invertible matrix Qsuch thatA=Q 1BQ.
8. Change of coordinates 73
Since an invertible matrix must be square, it follows from counting di-
mensions, that similar matrices AandBhave to be square and of the same
size. IfAis similar to B, i.e. ifA=Q 1BQ, then
B=QAQ 1= (Q 1) 1A(Q 1)
(sinceQ 1is invertible), therefore Bis similar to A. So, we can just say
thatAandBaresimilar .
The above reasoning shows, that it does not matter where to put Q
and where Q 1: one can use the formula A=QBQ 1in the denition of
similarity.
The above discussion shows, that one can treat similar matrices as dif-
ferent matrix representation of the same linear operator (transformation).
Exercises.
8.1. True or false
a) Every change of coordinate matrix is square;
b) Every change of coordinate matrix is invertible;
c) The matrices AandBare called similar if B=QTAQfor some matrix Q;
d) The matrices AandBare called similar if B=Q 1AQfor some matrix
Q;
e) Similar matrices do not need to be square.
8.2. Consider the system of vectors
(1;2;1;1)T;(0;1;3;1)T;(0;3;2;0)T;(0;1;0;0)T:
a) Prove that it is a basis in F4. Try to do minimal amount of computations.
b) Find the change of coordinate matrix that changes the coordinates in this
basis to the standard coordinates in F4(i.e. to the coordinates in the stan-
dard basis e1;:::;e4).
8.3. Find the change of coordinates matrix that changes the coordinates in the
basis 1;1 +tinP1to the coordinates in the basis 1  t;2t.
8.4. LetTbe the linear operator in F2dened (in the standard coordinates) by
Tx
y
=3x+y
x 2y
Find the matrix of Tin the standard basis and in the basis
(1;1)T; (1;2)T:
8.5. Prove, that if AandBare similar matrices then trace A= traceB.Hint:
recall how trace( XY) and trace( YX) are related.
8.6. Are the matrices1 3
2 2
and0 2
4 2
similar? Justify.

Chapter 3
Determinants
1. Introduction.
The reader probably already met determinants in calculus or algebra, at
least the determinants of 2 2 and 33 matrices. For a 2 2 matrix
a b
c d
the determinant is simply ad bc; the determinant of a 3 3 matrix can be
found by the \Star of David" rule.
In this chapter we would like to introduce determinants for nnmatri-
ces. I don't want just to give a formal denition. First I want to give some
motivation, and then derive some properties the determinant should have.
Then if we want to have these properties, we do not have any choice, and
arrive to several equivalent denitions of the determinant.
It is more convenient to start not with the determinant of a matrix, but
with determinant of a system of vectors. There is no real dierence here,
since we always can join vectors together (say as columns) to form a matrix.
Let us have nvectors v1;v2;:::;vninRn(notice that the number of
vectors coincides with dimension), and we want to nd the n-dimensional
volume of the parallelepiped determined by these vectors.
The parallelepiped determined by the vectors v1;v2;:::;vncan be de-
ned as the collection of all vectors v2Rnthat can be represented as
v=t1v1+t2v2+:::+tnvn; 0tk18k= 1;2;:::;n:
It can be easily visualized when n= 2 (parallelogram) and n= 3 (paral-
lelepiped). So, what is the n-dimensional volume?
75
76 3. Determinants
Ifn= 2 it is area; if n= 3 it is indeed the volume. In dimension 1 is it
just the length.
Finally, let us introduce some notation. For a system of vectors (col-
umns) v1;v2;:::;vnwe will denote its determinant (that we are going to
construct) as D(v1;v2;:::;vn). If we join these vectors in a matrix A(col-
umn number kofAisvk), then we will use the notation det A,
detA=D(v1;v2;:::;vn)
Also, for a matrix
A=0
BBB@a1;1a1;2::: a 1;n
a2;1a2;2::: a 2;n
.........
an;1an;2::: an;n1
CCCA
its determinant is often is denoted by
a1;1a1;2::: a 1;n
a2;1a2;2::: a 2;n
.........
an;1an;2::: an;n:
2. What properties determinant should have.
We know, that for dimensions 2 and 3 \volume" of a parallelepiped is de-
termined by the base times height rule: if we pick one vector, then height
is the distance from this vector to the subspace spanned by the remaining
vectors, and the base is the ( n 1)-dimensional volume of the parallelepiped
determined by the remaining vectors.
Now let us generalize this idea to higher dimensions. For a moment
we do not care about how exactly to determine height and base. We will
show, that if we assume that the base and the height satisfy some natural
properties, then we do not have any choice, and the volume (determinant)
is uniquely dened.
2.1. Linearity in each argument. First of all, if we multiply vector v1
by a positive number a, then the height (i.e. the distance to the linear span
L(v2;:::;vn)) is multiplied by a. If we admit negative heights (and negative
volumes), then this property holds for all scalars a, and so the determinant
D(v1;v2;:::;vn) of the system v1;v2;:::;vnshould satisfy
D(v1;v2;:::;vn) =D(v1;v2;:::;vn):
2. What properties determinant should have. 77
Of course, there is nothing special about vector v1, so for any index k
(2.1) D(v1;:::; vk
k;:::;vn) =D(v1;:::;vk
k;:::;vn)
To get the next property, let us notice that if we add 2 vectors, then the
\height" of the result should be equal the sum of the \heights" of summands,
i.e. that
(2.2)D(v1;:::;uk+vk|{z}
k;:::;vn) =
D(v1;:::;uk
k;:::;vn) +D(v1;:::;vk
k;:::;vn)
In other words, the above two properties say that the determinant of n
vectors is linear in each argument (vector) , meaning that if we x n 1
vectors and interpret the remaining vector as a variable (argument), we get
a linear function.
Remark. We already know that linearity is a very nice property, that helps
in many situations. So, admitting negative heights (and therefore negative
volumes) is a very small price to pay to get linearity, since we can always
put on the absolute value afterwards.
In fact, by admitting negative heights, we did not sacrice anything! To
the contrary, we even gained something, because the sign of the determinant
contains some information about the system of vectors (orientation).
2.2. Preservation under \column replacement". The next property
also seems natural. Namely, if we take a vector, say vj, and add to it a
multiple of another vector vk, the \height" does not change, so
(2.3)D(v1;:::;vj+vk|{z}
j;:::;vk
k;:::;vn)
=D(v1;:::;vj
j;:::;vk
k;:::;vn)
In other words, if we apply the column operation of the third type, the
determinant does not change.
Remark. Although it is not essential here, let us notice that the second
part of linearity (property (2.2)) is not independent: it can be deduced from
properties (2.1) and (2.3).
We leave the proof as an exercise for the reader.
2.3. Antisymmetry. The next property the determinant should have, is Functions of several
variables that
change sign when
one interchanges
any two arguments
are called
antisymmetric .that if we interchange 2 vectors, the determinant changes sign:
(2.4)D(v1;:::;vk
j;:::;vj
k;:::;vn) = D(v1;:::;vj
j;:::;vk
k;:::;vn):
78 3. Determinants
At rst sight this property does not look natural, but it can be deduced
from the previous ones. Namely, applying property (2.3) three times, and
then using (2.1) we get
D(v1;:::;vj
j;:::;vk
k;:::;vn) =
=D(v1;:::;vj
j;:::;vk vj|{z}
k;:::;vn)
=D(v1;:::;vj+ (vk vj)|{z}
j;:::;vk vj|{z}
k;:::;vn)
=D(v1;:::;vk
j;:::;vk vj|{z}
k;:::;vn)
=D(v1;:::;vk
j;:::; (vk vj) vk|{z}
k;:::;vn)
=D(v1;:::;vk
j;:::; vj
k;:::;vn)
= D(v1;:::;vk
j;:::;vj
k;:::;vn):
2.4. Normalization. The last property is the easiest one. For the stan-
dard basis e1;e2;:::;eninRnthe corresponding parallelepiped is the n-
dimensional unit cube, so
(2.5) D(e1;e2;:::;en) = 1:
In matrix notation this can be written as
det(I) = 1
3. Constructing the determinant.
The plan of the game is now as follows: using the properties that as we
decided in Section 2 the determinant should have, we derive other properties
of the determinant, some of them highly non-trivial. We will show how to
use these properties to compute the determinant using our old friend|row
reduction.
Later, in Section 4, we will show that the determinant, i.e. a function
with the desired properties exists and unique. After all we have to be sure
that the object we are computing and studying exists.
While our initial geometric motivation for determinant and its properties
came from considering vectors in the real vector space Rn, so they relate only
to matrices with real entries, all the constructions below use only algebraic
operations (addition, multiplication, division) and are applicable to matrices
with complex entries, and even with entries in an arbitrary eld.
3. Constructing the determinant. 79
So in what follows we are constructing determinant not just for real
matrices, but for complex matrices as well (and also for matrices with entries
in an arbitrary eld). The nice geometric motivation for the properties
works only in the real case, but after we decided on the properties of the
determinant (see properties 1{3 below) everything works in the general case.
3.1. Basic properties. We will use the following basic properties of the
determinant:
1. Determinant is linear in each column, i.e. in vector notation for every
indexk
D(v1;:::; uk+vk|{z}
k;:::;vn) =
D(v1;:::;uk
k;:::;vn) +D(v1;:::;vk
k;:::;vn)
for all scalars ,.
2. Determinant is antisymmetric , i.e. if one interchanges two columns,
the determinant changes sign.
3. Normalization property: det I= 1.
All these properties were discussed above in Section 2. The rst property
is just the (2.1) and (2.2) combined. The second one is (2.4), and the last one
is the normalization property (2.5). Note, that we did not use property (2.3):
it can be deduced from the above three. These three properties completely
dene determinant!
3.2. Properties of determinant deduced from the basic properties.
Proposition 3.1. For a square matrix Athe following statements hold:
1.IfAhas a zero column, then detA= 0.
2.IfAhas two equal columns, then detA= 0;
3.If one column of Ais a multiple of another, then detA= 0;
4.If columns of Aare linearly dependent, i.e. if the matrix is not in-
vertible, then detA= 0.
Proof. Statement 1 follows immediately from linearity. If we multiply the
zero column by zero, we do not change the matrix and its determinant. But
by the property 1 above, we should get 0.
The fact that determinant is antisymmetric, implies statement 2. In-
deed, if we interchange two equal columns, we change nothing, so the deter-
minant remains the same. On the other hand, interchanging two columns
80 3. Determinants
changes sign of determinant, so
detA= detA;
which is possible only if det A= 0.
Statement 3 is immediate corollary of statement 2 and linearity.
To prove the last statement, let us rst suppose that the rst vector v1
is a linear combination of the other vectors,
v1=2v2+3v3+:::+nvn=nX
k=2kvk:
Then by linearity we have (in vector notation)
D(v1;v2;:::;vn) =D 
 nX
k=2kvk
;v2;v3;:::;vn!
=nX
k=2kD(vk;v2;v3;:::;vn)
and each determinant in the sum is zero because of two equal columns.
Let us now consider general case, i.e. let us assume that the system
v1;v2;:::;vnis linearly dependent. Then one of the vectors, say vkcan be
represented as a linear combination of the others. Interchanging this vector
withv1we arrive to the situation we just treated, so
D(v1;:::;vk
k;:::;vn) = D(vk;:::;v1
k;:::;vn) = 0 = 0;
so the determinant in this case is also 0. 
The next proposition generalizes property (2.3). As we already have
said above, this property can be deduced from the three \basic" properties
of the determinant, we are using in this section.
Proposition 3.2. The determinant does not change if we add to a col- Note, that adding to
a column a multiple
of itself is prohibited
here. We can only
add multiples of the
other columns.umn a linear combination of the other columns (leaving the other columns
intact). In particular, the determinant is preserved under \column replace-
ment" (column operation of third type).
Proof. Fix a vector vk, and let ube a linear combination of the other
vectors,
u=X
j6=kjvj:
Then by linearity
D(v1;:::;vk+u|{z}
k;:::;vn) =D(v1;:::;vk
k;:::;vn) +D(v1;:::;u
k;:::;vn);
3. Constructing the determinant. 81
and by Proposition 3.1 the last term is zero. 
3.3. Determinants of diagonal and triangular matrices. Now we are
ready to compute determinant for some important special classes of matrices.
The rst class is the so-called diagonal matrices. Let us recall that a square
matrixA=faj;kgn
j;j=1is called diagonal if all entries o the main diagonal
are zero, i.e. if aj;k= 0 for all j6=k. We will often use the notation
diagfa1;a2;:::;angfor the diagonal matrix
0
BBB@a10::: 0
0a2::: 0
.........0
0 0::: an1
CCCA:
Since a diagonal matrix diag fa1;a2;:::;angcan be obtained from the
identity matrix Iby multiplying column number kbyak,
Determinant of a diagonal matrix equal the product of the diago-
nal entries,
det(diagfa1;a2;:::;ang) =a1a2:::an:
The next important class is the class of so-called triangular matrices. A
square matrix A=faj;kgn
j;j=1is called upper triangular if all entries below
the main diagonal are 0, i.e. if aj;k= 0 for all k < j . A square matrix is
called lower triangular if all entries above the main are 0, i.e if aj;k= 0 for
allj <k . We call a matrix triangular , if it is either lower or upper triangular
matrix.
It is easy to see that
Determinant of a triangular matrix equals to the product of the
diagonal entries,
detA=a1;1a2;2:::an;n:
Indeed, if a triangular matrix has zero on the main diagonal, it is not
invertible (this can easily be checked by column operations) and therefore
both sides equal zero. If all diagonal entries are non-zero, then using column
replacement (column operations of third type) one can transform the matrix
into a diagonal one with the same diagonal entries: For upper triangular
matrix one should rst subtract appropriate multiples of the rst column
from the columns number 2 ;3;:::;n , \killing" all entries in the rst row,
then subtract appropriate multiples of the second column from columns
number 3;:::;n , and so on.
82 3. Determinants
To treat the case of lower triangular matrices one has to do \column
reduction" from the left to the right, i.e. rst subtract appropriate multiples
of the last column from columns number n 1;:::; 2;1, and so on.
3.4. Computing the determinant. Now we know how to compute de-
terminants, using their properties: one just needs to do column reduction
(i.e. row reduction for AT) keeping track of column operations changing
the determinant. Fortunately, the most often used operation|row replace-
ment, i.e. operation of third type does not change the determinant. So we
only need to keep track of interchanging of columns and of multiplication of
column by a scalar.
If an echelon form of ATdoes not have pivots in every column (and
row), then Ais not invertible, so det A= 0. IfAis invertible, we arrive at
a triangular matrix, and det Ais the product of diagonal entries times the
correction from column interchanges and multiplications.
The above algorithm implies that det Acan be zero only if a matrix A
is not invertible. Combining this with the last statement of Proposition 3.1
we get
Proposition 3.3. detA= 0if and only if Ais not invertible. An equivalent
statement: detA6= 0if and only if Ais invertible.
Note, that although we now know how to compute determinants, the
determinant is still not dened. One can ask: why don't we dene it as
the result we get from the above algorithm? The problem is that formally
this result is not well dened: that means we did not prove that dierent
sequences of column operations yield the same answer.
3.5. Determinants of a transpose and of a product. Determinants
of elementary matrices. In this section we prove two important theorems.
Theorem 3.4 (Determinant of a transpose) .For a square matrix A,
detA= det(AT):
This theorem implies that for all statement about columns we discussed
above, the corresponding statements about rows are also true. In particular,
determinants behave under row operations the same way they behave under
column operations . So, we can use row operations to compute determinants.
Theorem 3.5 (Determinant of a product) .FornnmatricesAandB
det(AB) = (detA)(detB)
In other words
Determinant of a product equals product of determinants.
3. Constructing the determinant. 83
To prove both theorems we need the following lemma.
Lemma 3.6. For a square matrix Aand an elementary matrix E(of the
same size)
det(AE) = (detA)(detE)
Proof. The proof can be done just by direct checking: determinants of
special matrices are easy to compute; right multiplication by an elemen-
tary matrix is a column operation, and eect of column operations on the
determinant is well known.
This can look like a lucky coincidence, that the determinants of elemen-
tary matrices agree with the corresponding column operations, but it is not
a coincidence at all.
Namely, for a column operation the corresponding elementary matrix
can be obtained from the identity matrix Iby this column operation. So, its
determinant is 1 (determinant of I) times the eect of the column operation.
And that is all! It may be hard to realize at rst, but the above para-
graph is a complete and rigorous proof of the lemma! 
ApplyingNtimes Lemma 3.6 we get the following corollary.
Corollary 3.7. For any matrix Aand any sequence of elementary matrices
E1;E2;:::;EN(all matrices are nn)
det(AE1E2:::EN) = (detA)(detE1)(detE2):::(detEN)
Lemma 3.8. Any invertible matrix is a product of elementary matrices.
Proof. We know that any invertible matrix is row equivalent to the identity
matrix, which is its reduced echelon form. So
I=ENEN 1:::E 2E1A;
and therefore any invertible matrix can be represented as a product of ele-
mentary matrices,
A=E 1
1E 1
2:::E 1
N 1E 1
NI=E 1
1E 1
2:::E 1
N 1E 1
N
(the inverse of an elementary matrix is an elementary matrix). 
Proof of Theorem 3.4. First of all, it can be easily checked, that for an
elementary matrix Ewe have det E= det(ET). Notice, that it is sucient to
prove the theorem only for invertible matrices A, since ifAis not invertible
thenATis also not invertible, and both determinants are zero.
By Lemma 3.8 matrix Acan be represented as a product of elementary
matrices,
A=E1E2:::EN;
84 3. Determinants
and by Corollary 3.7 the determinant of Ais the product of determinants
of the elementary matrices. Since taking the transpose just transposes
each elementary matrix and reverses their order, Corollary 3.7 implies that
detA= detAT. 
Proof of Theorem 3.5. Let us rst suppose that the matrix Bis invert-
ible. Then Lemma 3.8 implies that Bcan be represented as a product of
elementary matrices
B=E1E2:::EN;
and so by Corollary 3.7
det(AB) = (detA)[(detE1)(detE2):::(detEN)] = (detA)(detB):
IfBis not invertible, then the product ABis also not invertible, and
the theorem just says that 0 = 0.
To check that the product AB=Cis not invertible, let us assume that
it is invertible. Then multiplying the identity AB=CbyC 1from the left,
we getC 1AB=I, soC 1Ais a left inverse of B. SoBis left invertible,
and since it is square, it is invertible. We got a contradiction. 
3.6. Summary of properties of determinant. First of all, let us say
once more, that the determinant is dened only for square matrices! Since
we now know that det A= det(AT), the statements that we knew about
columns are true for rows too.
1. Determinant is linear in each row (column) when the other rows
(columns) are xed.
2. If one interchanges two rows (columns) of a matrix A, the determi-
nant changes sign.
3. For a triangular (in particular, for a diagonal) matrix its determinant
is the product of the diagonal entries. In particular, det I= 1.
4. If a matrix Ahas a zero row (or column), det A= 0.
5. If a matrix Ahas two equal rows (columns), det A= 0.
6. If one of the rows (columns) of Ais a linear combination of the other
rows (columns), i.e. if the matrix is not invertible, then det A= 0;
More generally,
7. detA= 0 if and only if Ais not invertible, or equivalently
8. detA6= 0 if and only if Ais invertible.
9. detAdoes not change if we add to a row (column) a linear combi-
nation of the other rows (columns). In particular, the determinant
is preserved under the row (column) replacement, i.e. under the row
(column) operation of the third kind.
3. Constructing the determinant. 85
10. detAT= detA.
11. det(AB) = (detA)(detB).
And nally,
12. IfAis annnmatrix, then det( aA) =andetA.
The last property follows from the linearity of the determinant, if we
recall that to multiply a matrix Abyawe have to multiply each row by a,
and that each multiplication multiplies the determinant by a.
Exercises.
3.1. IfAis annnmatrix, how are the determinants det Aand det(5A) related?
Remark: det(5A) = 5 detAonly in the trivial case of 1 1 matrices
3.2. How are the determinants det Aand detBrelated if
a)
A=0
@a1a2a3
b1b2b3
c1c2c31
A; B =0
@2a13a25a3
2b13b25b3
2c13c25c31
A;
b)
A=0
@a1a2a3
b1b2b3
c1c2c31
A; B =0
@3a14a2+ 5a15a3
3b14b2+ 5b15b3
3c14c2+ 5c15c31
A:
3.3. Using column or row operations compute the determinants
0 1 2
 1 0 3
2 3 0;1 2 3
4 5 6
7 8 9;1 0 2 3
 3 1 1 2
0 4 1 1
2 3 0 1;1x
1y:
3.4. A square (nn) matrix is called skew-symmetric (or antisymmetric) if AT=
 A. Prove that if Ais skew-symmetric and nis odd, then det A= 0. Is this true
for evenn?
3.5. A square matrix is called nilpotent ifAk=0for some positive integer k. Show
that for a nilpotent matrix AdetA= 0.
3.6. Prove that if the matrices AandBare similar, than det A= detB.
3.7. A real square matrix Qis called orthogonal if QTQ=I. Prove that if Qis an
orthogonal matrix then det Q=1.
3.8. Show that1x x2
1y y2
1z z2= (z x)(z y)(y x):
This is a particular case of the so-called Vandermonde determinant.
86 3. Determinants
3.9. Let pointsA,BandCin the plane R2have coordinates ( x1;y1), (x2;y2) and
(x3;y3) respectively. Show that the area of triangle ABC is the absolute value of
1
21x1y1
1x2y2
1x3y3:
Hint: use row operations and geometric interpretation of 2 2 determinants (area).
3.10. LetAbe a square matrix. Show that block triangular matrices
I
0A
;A
0I
;I0
A
;A0
I
all have determinant equal to det A. Herecan be anything.
The following problems illustrate the power of block matrix notation.
3.11. Use the previous problem to show that if AandCare square matrices, then
detA B
0C
= detAdetC:
Hint:A B
0C
=I B
0CA0
0I
.
3.12. LetAbemnandBbenmmatrices. Prove that
det0A
 B I
= det(AB):
Hint: While it is possible to transform the matrix by row operations to a form
where the determinant is easy to compute, the easiest way is to right multiply the
matrix by
I0
B I
.
4. Formal denition. Existence and uniqueness of the
determinant.
In this section we arrive to the formal denition of the determinant. We
show that a function, satisfying the basic properties 1, 2, 3 from Section 3
exists, and moreover, such function is unique, i.e. we do not have any choice
in constructing the determinant.
Consider an nnmatrixA=faj;kgn
j;k=1, and let v1;v2;:::;vnbe its
columns, i.e.
vk=0
BBB@a1;k
a2;k
...
an;k1
CCCA=a1;ke1+a2;ke2+:::+an;ken=nX
j=1aj;kej:
4. Formal denition. Existence and uniqueness of the determinant. 87
Using linearity of the determinant we expand it in the rst column v1:
(4.1)D(v1;v2;:::;vn) =
D(nX
j=1aj;1ej;v2;:::;vn) =nX
j=1aj;1D(ej;v2;:::;vn):
Then we expand it in the second column, then in the third, and so on. We
get
D(v1;v2;:::;vn) =nX
j1=1nX
j2=1:::nX
jn=1aj1;1aj2;2:::ajn;nD(ej1:ej2;:::ejn):
Notice, that we have to use a dierent index of summation for each column:
we call them j1;j2;:::;jn; the index j1here is the same as the index jin
(4.1).
It is a huge sum, it contains nnterms. Fortunately, some of the terms are
zero. Namely, if any 2 of the indices j1;j2;:::;jncoincide, the determinant
D(ej1:ej2;:::ejn) is zero, because there are two equal columns here.
So, let us rewrite the sum, omitting all zero terms. The most convenient
way to do that is using the notion of a permutation . Informally, a per-
mutation of an ordered set f1;2;:::;ngis a rearrangement of its elements.
A convenient formal way to represent such a rearrangement is by using a
function
:f1;2;:::;ng!f 1;2;:::;ng;
where(1);(2);:::; (n) gives the new order of the set 1 ;2;:::;n . In
other words, the permutation rearranges the ordered set 1 ;2;:::;n into
(1);(2);:::; (n).
Such function has to be one-to-one (dierent values for dierent ar-
guments) and onto (assumes all possible values from the target space). The
functions which are one-to-one and onto are called bijections , and they give
one-to-one correspondence between the domain and the target space.1
Although it is not directly relevant here, let us notice, that it is well-
known in combinatorics, that the number of dierent permutations of the set
f1;2;:::;ngis exactlyn!. The set of all permutations of the set f1;2;:::;ng
will be denoted Perm( n).
1There is another canonical way to represent permutation by a bijection , namely in this
representation (k) gives new position of the element number k. In this representation rearranges
(1);(2);:::; (n) into 1;2;:::;n .
While in the rst representation it is easy to write the function if you know the rearrangement
of the set 1 ;2;:::;n , the second one is more adapted to the composition of permutations: it
coincides with the composition of functions. Namely if we rst perform the permutation that
correspond to a function and then one that correspond to , the resulting permutation will
correspond to .
88 3. Determinants
Using the notion of a permutation, we can rewrite the determinant as
D(v1;v2;:::;vn) =
X
2Perm(n)a(1);1a(2);2:::a(n);nD(e(1);e(2);:::;e(n)):
The matrix with columns e(1);e(2);:::;e(n)can be obtained from the
identity matrix by nitely many column interchanges, so the determinant
D(e(1);e(2);:::;e(n))
is 1 or 1 depending on the number of column interchanges.
To formalize that, we (informally) dene the sign (denoted sign ) of
a permutation to be 1 if an even number of interchanges is necessary to
rearrange the n-tuple 1;2;:::;n into(1);(2);:::; (n), and sign( ) = 1
if the number of interchanges is odd.
It is a well-known fact from the combinatorics, that the sign of permuta-
tion is well dened, i.e. that although there are innitely many ways to get
then-tuple(1);(2);:::; (n) from 1;2;:::;n , the number of interchanges
is either always odd or always even.
One of the ways to show that is to introduce an alternative denition.
LetK=K() be the number of disorders of, i.e. the number of pairs
(j;k),j;k2 f1;2;:::;ng,j < k such that(j)> (k), and see if the
number is even or odd. We call the permutation oddifKis odd and even
ifKis even. Then dene sign := ( 1)K(); note that this way sign is
well dened.
We want to show that sign = ( 1)K()can indeed be computed by
rearranging the n-tuple 1;2;:::;n into(1);(2);:::; (n) and counting the
number of interchanges, as was described above.
If(k) =k8k, then the number of disordersK() is 0, so sign of such
identity permutation is 1. Note also, that any elementary transpose, which
interchange two neighbors, changes the sign of a permutation, because it
changes (increases or decreases) the number of disorders exactly by 1. So,
to get from a permutation to another one always needs an even number of
elementary transposes if the permutations have the same sign, and an odd
number if the signs are dierent.
Finally, any interchange of two entries can be achieved by an odd num-
ber of elementary transposes. This implies that sign changes under an in-
terchange of two entries. So, to get from 1 ;2;:::;n to an even permutation
(positive sign) one always need even number of interchanges, and odd num-
ber of interchanges is needed to get an odd permutation (negative sign).
4. Formal denition. Existence and uniqueness of the determinant. 89
So, if we want determinant to satisfy basic properties 1{3 from Section
3, we must dene it as
(4.2) det A=X
2Perm(n)a(1);1a(2);2:::a(n);nsign();
where the sum is taken over all permutations of the set f1;2;:::;ng.
If we dene the determinant this way, it is easy to check that it satises
the basic properties 1{3 from Section 3. Indeed, it is linear in each column,
because for each column every term (product) in the sum contains exactly
one entry from this column.
Interchanging two columns of Ajust adds an extra interchange to the
permutation, so right side in (4.2) changes sign. Finally, for the identity
matrixI, the right side of (4.2) is 1 (it has one non-zero term).
Exercises.
4.1. Suppose the permutation takes (1;2;3;4;5) to (5;4;1;2;3).
a) Find sign of ;
b) What does 2:=do to (1;2;3;4;5)?
c) What does the inverse permutation  1do to (1;2;3;4;5)?
d) What is the sign of  1?
4.2. LetPbe a permutation matrix , i.e. annnmatrix consisting of zeroes and
ones and such that there is exactly one 1 in every row and every column.
a) Can you describe the corresponding linear transformation? That will ex-
plain the name.
b) Show that Pis invertible. Can you describe P 1?
c) Show that for some N > 0
PN:=PP:::P|{z}
Ntimes=I:
Use the fact that there are only nitely many permutations.
4.3. Why is there an even number of permutations of (1 ;2;:::; 9) and why are
exactly half of them odd permutations? Hint: This problem can be hard to solve
in terms of permutations, but there is a very simple solution using determinants.
4.4. Ifis an odd permutation, explain why 2is even but  1is odd.
4.5. How many multiplications and additions is required to compute the determi-
nant using formal denition (4.2) of the determinant of an nnmatrix? Do not
count the operations needed to compute sign .
90 3. Determinants
5. Cofactor expansion.
For annnmatrixA=faj;kgn
j;k=1letAj;kdenotes the ( n 1)(n 1)
matrix obtained from Aby crossing out row number jand column number
k.
Theorem 5.1 (Cofactor expansion of determinant) .LetAbe annn
matrix. For each j,1jn, determinant of Acan be expanded in the
row number jas
detA=
aj;1( 1)j+1detAj;1+aj;2( 1)j+2detAj;2+:::+aj;n( 1)j+ndetAj;n
=nX
k=1aj;k( 1)j+kdetAj;k:
Similarly, for each k,1kn, the determinant can be expanded in the
column number k,
detA=nX
j=1aj;k( 1)j+kdetAj;k:
Proof. Let us rst prove the formula for the expansion in row number 1.
The formula for expansion in row number 2 then can be obtained from it
by interchanging rows number 1 and 2. Interchanging then rows number 2
and 3 we get the formula for the expansion in row number 3, and so on.
Since detA= detAT, column expansion follows automatically.
Let us rst consider a special case, when the rst row has one non-
zero terma1;1. Performing column operations on columns 2 ;3;:::;n we
transformAto the lower triangular form. The determinant of Athen can
be computed as
the product of diagonal
entries of the triangular
matrixcorrecting factor from
the column operations:
But the product of all diagonal entries except the rst one (i.e. without
a1;1) times the correcting factor is exactly det A1;1, so in this particular case
detA=a1;1detA1;1.
Let us now consider the case when all entries in the rst row except a1;2
are zeroes. This case can be reduced to the previous one by interchanging
columns number 1 and 2, and therefore in this case det A= ( 1)a1;2detA1;2.
The case when a1;3is the only non-zero entry in the rst row, can be
reduced to the previous one by interchanging rows 2 and 3, so in this case
detA=a1;3detA1;3.
5. Cofactor expansion. 91
Repeating this procedure we get that in the case when a1;kis the only
non-zero entry in the rst row det A= ( 1)1+ka1;kdetA1;k.2
In the general case, linearity of the determinant in each row implies that
detA= detA(1)+ detA(2)+:::+ detA(n)=nX
k=1detA(k)
where the matrix A(k)is obtained from Aby replacing all entries in the rst
row except a1;kby 0. As we just discussed above
detA(k)= ( 1)1+ka1;kdetA1;k;
so
detA=nX
k=1( 1)1+ka1;kdetA1;k:
To get the cofactor expansion in the second row, we can interchange
the rst and second rows and apply the above formula. The row exchange
changes the sign, so we get
detA= nX
k=1( 1)1+ka2;kdetA2;k=nX
k=1( 1)2+ka2;kdetA2;k:
Exchanging rows 3 and 2 and expanding in the second row we get formula
detA=nX
k=1( 1)3+ka3;kdetA3;k;
and so on.
To expand the determinant det Ain a column one need to apply the row
expansion formula for AT. 
Denition. The numbers
Cj;k= ( 1)j+kdetAj;k
are called cofactors .
2In the case when a1;kis the only non-zero entry in the rst row it may be tempting to
exchange columns number 1 and number k, to reduce the problem to the case a1;16= 0. However,
when we exchange columns 1 and kwe change the order of other columns: if we just cross out
column number k, then column number 1 will be the rst of the remaining columns. But, if
we exchange columns 1 and k, and then cross out column k(which is now the rst one), then
the column 1 will be now column number k 1. To avoid the complications of keeping track of
the order of columns, we can, as we did above, exchange columns number kandk 1, reducing
everything to the situation we treated on the previous step. Such an operation does not change
the order for the rest of the columns.
92 3. Determinants
Using this notation, the formula for expansion of the determinant in the
row number jcan be rewritten as
detA=aj;1Cj;1+aj;2Cj;2+:::+aj;nCj;n=nX
k=1aj;kCj;k:
Similarly, expansion in the column number kcan be written as
detA=a1;kC1;k+a2;kC2;k+:::+an;kCn;k=nX
j=1aj;kCj;k
Remark. Very often the cofactor expansion formula is used as the denition Very often the
cofactor expansion
formula is used as
the denition of
determinant.of determinant. It is not dicult to show that the quantity given by this
formula satises the basic properties of the determinant: the normalization
property is trivial, the proof of antisymmetry is easy. However, the proof of
linearity is a bit tedious (although not too dicult).
Remark. Although it looks very nice, the cofactor expansion formula is not
suitable for computing determinant of matrices bigger than 3 3.
As one can count it requires more than n! multiplications (to be precise it
requiresPn
k=2n!=k! multiplications), and n! grows very rapidly. For exam-
ple, cofactor expansion of a 20 20 matrix require more than 20! 2:41018
multiplications. It would take a computer performing a billion multiplica-
tions per second over 77 years to perform 20! multiplications; performing
the multiplications required for the cofactor expansion of the determinant
of a 2020 matrix will require more than 132 years.3
On the other hand, computing the determinant of an nnmatrix using
row reduction requires (n3+ 2n 3)=3 multiplications (and about the same
number of additions). It would take a computer performing a million oper-
ations per second (very slow, by today's standards) a fraction of a second
to compute the determinant of a 100 100 matrix by row reduction.
It can only be practical to apply the cofactor expansion formula in higher
dimensions if a row (or a column) has a lot of zero entries.
However, the cofactor expansion formula is of great theoretical impor-
tance, as the next section shows.
5.1. Cofactor formula for the inverse matrix. The matrix C=
fCj;kgn
j;k=1whose entries are cofactors of a given matrix Ais called the
cofactor matrix ofA.
Theorem 5.2. LetAbe an invertible matrix and let Cbe its cofactor matrix.
Then
A 1=1
detACT:
3The reader can check the numbers sung, for example, WolframAlpha
5. Cofactor expansion. 93
Proof. Let us nd the product ACT. The diagonal entry number jis
obtained by multiplying jth row ofAbyjth column of A(i.e.jth row of
C), so
(ACT)j;j=aj;1Cj;1+aj;2Cj;2+:::+aj;nCj;n= detA;
by the cofactor expansion formula.
To get the o diagonal terms we need to multiply kth row ofAbyjth
column ofCT,j6=k, to get
ak;1Cj;1+ak;2Cj;2+:::+ak;nCj;n:
It follows from the cofactor expansions formula (expanding in jth row) that
this is the determinant of the matrix obtained from Aby replacing row
numberjby the row number k(and leaving all other rows as they were).
But the rows jandkof this matrix coincide, so the determinant is 0. So, all
o-diagonal entries of ACTare zeroes (and all diagonal ones equal det A),
thus
ACT= (detA)I:
That means that the matrix1
detACTis a right inverse of A, and since Ais
square, it is the inverse. 
Recalling that for an invertible matrix Athe equation Ax=bhas a
unique solution
x=A 1b=1
detACTb;
we get the following corollary of the above theorem.
Corollary 5.3 (Cramer's rule) .For an invertible matrix Athe entry number
kof the solution of the equation Ax=bis given by the formula
xk=detBk
detA;
where the matrix Bkis obtained from Aby replacing column number kofA
by the vector b.
5.2. Some applications of the cofactor formula for the inverse.
Example (Inverting 22 matrices) .The cofactor formula really shines
when one needs to invert a 2 2 matrix
A=a b
c d
:
The cofactors are just entries (1 1 matrices), the cofactor matrix is
d c
 b a
;
94 3. Determinants
so the inverse matrix A 1is given by the formula
A 1=1
detAd b
 c a
:
While the cofactor formula for the inverse does not look practical for
dimensions higher than 3, it has a great theoretical value, as the examples
below illustrate.
Example (Matrix with integer inverse) .Suppose that we want to construct
a matrixAwith integer entries, such that its inverse also has integer entries
(inverting such a matrix would make a nice homework problem: no messing
with fractions). If det A= 1 and its entries are integer, the cofactor formula
for inverses implies that A 1also have integer entries.
Note, that it is easy to construct an integer matrix Awith detA= 1:
one should start with a triangular matrix with 1 on the main diagonal, and
then apply several row or column replacements (operations of the third type)
to make the matrix look generic.
Example (Inverse of a polynomial matrix) .Another example is to consider
apolynomial matrix A(x), i.e. a matrix whose entries are not numbers but
polynomials aj;k(x) of the variable x. If detA(x)1, then the inverse
matrixA 1(x) is also a polynomial matrix.
If detA(x) =p(x)60, it follows from the cofactor expansion that p(x)
is a polynomial, so A 1(x) has rational entries: moreover, p(x) is a multiple
of each denominator.
Exercises.
5.1. Evaluate the determinants using any method
0 1 1
1 2 5
6 4 3;1 2 3 12
 5 12 14 19
 9 22 20 31
 4 9 14 15:
5.2. Use row (column) expansion to evaluate the determinants. Note, that you
don't need to use the rst row (column): picking row (column) with many zeroes
will simplify your calculations.
1 2 0
1 1 5
1 3 0;4 6 4 4
2 1 0 0
0 3 1 3
 2 2 3 5:
5. Cofactor expansion. 95
5.3. For thennmatrix
A=0
BBBBBBB@0 0 0 ::: 0a0
 1 0 0 ::: 0a1
0 1 0::: 0a2
..................
0 0 0 ::: 0an 2
0 0 0 ::: 1an 11
CCCCCCCA
compute det( A+tI), whereIisnnidentity matrix. You should get a nice ex-
pression involving a0;a1;:::;an 1andt. Row expansion and induction is probably
the best way to go.
5.4. Using cofactor formula compute inverses of the matrices
1 2
3 4
;19 17
3 2
;1 0
3 5
;0
@1 1 0
2 1 2
0 1 11
A:
5.5. LetDnbe the determinant of the nntridiagonal matrix
0
BBBBBB@1 1 0
1 1 1
1......
...1 1
0 1 11
CCCCCCA:
Using cofactor expansion show that Dn=Dn 1+Dn 2. This yields that the
sequenceDnis the Fibonacci sequence 1 ;2;3;5;8;13;21;:::
5.6. Vandermonde determinant revisited. Our goal is to prove the formula
1c0c2
0::: cn
0
1c1c2
1::: cn
1
............
1cnc2
n::: cn
n=Y
0j<kn(ck cj)
for the (n+ 1)(n+ 1) Vandermonde determinant.
We will apply induction. To do this
a) Check that the formula holds for n= 1,n= 2.
b) Call the variable cnin the last row x, and show that the determinant is a
polynomial of degree n,A0+A1x+A2x2+:::+Anxn, with the coecients
Akdepending on c0;c1;:::;cn 1.
c) Show that the polynomial has zeroes at x=c0;c1;:::;cn 1, so it can be
represented as An(x c0)(x c1):::(x cn 1), whereAnas above.
d) Assuming that the formula for the Vandermonde determinant is true for
n 1, compute Anand prove the formula for n.
5.7. How many multiplication is needed to compute the determinant of an nn
matrix using the cofactor expansion? Prove the formula.
96 3. Determinants
6. Minors and rank.
For a matrix Alet us consider its kksubmatrix , obtained by taking krows
andkcolumns. The determinant of this matrix is called a minor of order
k. Note, that an mnmatrix has m
k
 n
k
dierentkksubmatrices, and
so it has m
k
 n
k
minors of order k.
Theorem 6.1. For a non-zero matrix Aits rank equals to the maximal
integerksuch that there exists a non-zero minor of order k.
Proof. Let us rst show, that if k>rankAthen all minors of order kare 0.
Indeed, since the dimension of the column space Ran Ais rankA< k , any
kcolumns of Aare linearly dependent. Therefore, for any kksubmatrix
ofAits columns are linearly dependent, and so all minors of order kare 0.
To complete the proof we need to show that there exists a non-zero
minor of order k= rankA. There can be many such minors, but probably
the easiest way to get such a minor is to take pivot rows and pivot columns
(i.e. rows and columns of the original matrix, containing a pivot). This
kksubmatrix has the same pivots as the original matrix, so it is invertible
(pivot in every column and every row) and its determinant is non-zero. 
This theorem does not look very useful, because it is much easier to
perform row reduction than to compute all minors. However, it is of great
theoretical importance, as the following corollary shows.
Corollary 6.2. LetA=A(x)be anmnpolynomial matrix (i.e. a matrix
whose entries are polynomials of x). Then rankA(x)is constant everywhere,
except maybe nitely many points, where the rank is smaller.
Proof. Letrbe the largest integer such that rank A(x) =rfor somex. To
show that such rexists, we rst try r= minfm;ng. If there exists xsuch
that rankA(x) =r, we have found r. If not, we replace rbyr 1 and try
again. After nitely many steps we either stop or hit 0. So, rexists.
Letx0be a point such that rank A(x0) =r, and letMbe a minor of order
ksuch thatM(x0)6= 0. SinceM(x) is the determinant of a kkpolynomial
matrix,M(x) is a polynomial. Since M(x0)6= 0, it is not identically zero,
so it can be zero only at nitely many points. So, everywhere except maybe
nitely many points rank A(x)r. But by the denition of r, rankA(x)r
for allx. 
7. Review exercises for Chapter 3.
7.1. True or false
7. Review exercises for Chapter 3. 97
a) Determinant is only dened for square matrices.
b) If two rows or columns of Aare identical, then det A= 0.
c) IfBis the matrix obtained from Aby interchanging two rows (or columns),
then detB= detA.
d) IfBis the matrix obtained from Aby multiplying a row (column) of Aby
a scalar, then detB= detA.
e) IfBis the matrix obtained from Aby adding a multiple of a row to some
other row, then det B= detA.
f) The determinant of a triangular matrix is the product of its diagonal en-
tries.
g) det(AT) = det(A).
h) det(AB) = det(A) det(B).
i) A matrix Ais invertible if and only if det A6= 0.
j) IfAis an invertible matrix, then det( A 1) = 1=det(A).
7.2. LetAbe annnmatrix. How are det(3 A), det( A) and det(A2) related to
detA.
7.3. If the entries of both AandA 1are integers, is it possible that det A= 3?
Hint: what is det( A) det(A 1)?
7.4. Letv1;v2be vectors in R2and letAbe the 22 matrix with columns v1;v2.
Prove thatjdetAjis the area of the parallelogram with two sides given by the
vectors v1;v2.
Consider rst the case when v1= (x1;0)T. To treat general case v1= (x1;y1)T
left multiply Aby a rotation matrix that transforms vector v1into (ex1;0)T.Hint:
what is the determinant of a rotation matrix?
The following problem illustrates relation between the sign of the determinant
and the so-called orientation of a system of vectors.
7.5. Letv1,v2be vectors in R2. Show that D(v1;v2)>0 if and only if there
exists a rotation Tsuch that the vector Tv1is parallel to e1(and looking in the
same direction), and Tv2is in the upper half-plane x2>0 (the same half-plane
ase2).
Hint: What is the determinant of a rotation matrix?

Chapter 4
Introduction to
spectral theory
(eigenvalues and
eigenvectors)
Spectral theory is the main tool that helps us to understand the structure
of a linear operator. In this chapter we consider only operators acting from
a vector space to itself (or, equivalently, nnmatrices). If we have such
a linear transformation A:V!V, we can multiply it by itself, take any
power of it, or any polynomial.
The main idea of spectral theory is to split the operator into simple
blocks and analyze each block separately.
To explain the main idea, let us consider dierence equations . Many
processes can be described by the equations of the following type
xn+1=Axn; n = 0;1;2;:::;
whereA:V!Vis a linear transformation, and xnis the state of the
system at the time n. Given the initial state x0we would like to know the
state xnat the time n, analyze the long time behavior of xn, etc.1
1The dierence equations are discrete time analogues of the dierential equation x0(t) =
Ax(t). To solve the dierential equation, one needs to compute etA:=P1
k=0tkAn=k!, and
spectral theory also helps in doing this.
99
100 4. Introduction to spectral theory
At the rst glance the problem looks trivial: the solution xnis given by
the formula xn=Anx0. But what if nis huge: thousands, millions? Or
what if we want to analyze the behavior of xnasn!1 ?
Here the idea of eigenvalues and eigenvectors comes in. Suppose that
Ax0=x0, whereis some scalar. Then A2x0=2x0; A3x0=3x0;:::;
Anx0=nx0, so the behavior of the solution is very well understood
In this section we will consider only operators in nite-dimensional spac-
es. Spectral theory in innitely many dimensions is signicantly more com-
plicated, and most of the results presented here fail in innite-dimensional
setting.
1. Main denitions
1.1. Eigenvalues, eigenvectors, spectrum. A scalaris called an
eigenvalue of an operator A:V!Vif there exists a non-zero vector
v2Vsuch that
Av=v:
The vector vis called the eigenvector ofA(corresponding to the eigenvalue
).
If we know that is an eigenvalue, the eigenvectors are easy to nd: one
just has to solve the equation Ax=x, or, equivalently
(A I)x=0:
So, nding alleigenvectors, corresponding to an eigenvalue is simply nd-
ing the nullspace of A I. The nullspace Ker( A I), i.e. the set of all
eigenvectors and 0vector, is called the eigenspace .
The set of all eigenvalues of an operator Ais called spectrum ofA, and
is usually denoted (A).
1.2. Finding eigenvalues: characteristic polynomials. A scalaris
an eigenvalue if and only if the nullspace Ker( A I) is non-trivial (so the
equation (A I)x=0has a non-trivial solution).
LetAact on Fn(i.e.A:Fn!Fn). Since the matrix of Ais square,
A Ihas a non-trivial nullspace if and only if it is not invertible. We
know that a square matrix is not invertible if and only if its determinant is
0. Therefore
2(A);i.e.is an eigenvalue of A() det(A I) = 0
IfAis annnmatrix, the determinant det( A I) is a polynomial of
degreenof the variable . This polynomial is called the characteristic
polynomial ofA. So, to nd all eigenvalues of Aone just needs to compute
the characteristic polynomial and nd all its roots.
1. Main denitions 101
This method of nding the spectrum of an operator is not very practical
in higher dimensions. Finding roots of a polynomial of high degree can
be a very dicult problem, and it is impossible to solve the equation of
degree higher than 4 in radicals. So, in higher dimensions dierent numerical
methods of nding eigenvalues and eigenvectors are used.
1.3. Finding characteristic polynomial and eigenvalues of an ab-
stract operator. So we know how to nd the spectrum of a matrix. But
how do we nd eigenvalues of an operator acting in an abstract vector space?
The recipe is simple:
Take an arbitrary basis, and compute eigenvalues of the matrix of
the operator in this basis.
But how do we know that the result does not depend on a choice of the
basis?
There can be several possible explanations. One is based on the notion
ofsimilar matrices . Let us recall that square matrices AandBare called
similar if there exist an invertible matrix Ssuch that
A=SBS 1:
Note, that determinants of similar matrices coincide. Indeed
detA= det(SBS 1) = detSdetBdetS 1= detB
because det S 1= 1=detS. Note that if A=SBS 1then
A I=SBS 1 SIS 1=S(BS 1 IS 1) =S(B I)S 1;
so the matrices A IandB Iare similar. Therefore
det(A I) = det(B I);
i.e.
characteristic polynomials of similar matrices coincide.
IfT:V!Vis a linear transformation, and AandBare two bases in
V, then
[T]AA= [I]AB[T]BB[I]BA
and since [I]BA= ([I]AB) 1the matrices [ T]AAand [T]BBare similar.
In other words, matrices of a linear transformation in dierent bases are
similar.
Therefore, we can dene the characteristic polynomial of an operator
as the characteristic polynomial of its matrix in some basis. As we have
discussed above, the result does not depend on the choice of the basis, so
characteristic polynomial of an operator is well dened.
102 4. Introduction to spectral theory
1.4. Complex vs real spaces. The fundamental theorem of algebra as-
serts that any polynomial (of degree at least 1) has a complex root. That
implies that an operator in a nite-dimensional complex vector space has at
least one eigenvalue, so its spectrum is non-empty.
On the other hand it is easy to construct a linear transformation in a
real vector space without realeigenvalues, the rotation R,6=ninR2
being one of examples. Since it is usually assumed that eigenvalues should
belong to the eld of scalars (if an operator acts in a vector space over a eld
Fthe eigenvalues should be in F), such operators have empty spectrum.
Thus, the complex case (i.e. operators acting in complex vector spaces)
seems to be the most natural setting for the spectral theory. Since RC,
we can always treat a real nnmatrix as an operator in Cnto allow
complex eigenvalues. Treating real matrices as operators in Cnis typical in
the spectral theory, and we will follow this agreement. Finding eigenvalues
of a matrix (unless otherwise specied) will always mean nding all complex
eigenvalues and not restricting oneself only to real ones.
Note that an operator in an abstract real vector space also can be in-
terpreted as an operator in a complex space. A na ve approach would be
to x a basis (recall that all spaces in this chapter are nite-dimensional),
and then work with coordinates in this basis allowing complex coordinates:
that will be essentially move from operators in Rnto operators Cndescribed
above.
This construction describes what is known as the complexication of a
real vector space, and the result does not depend on the choice of a basis. A
\high brow" abstract construction of the complexication, explaining why
the result does not depend on the choice of a basis is described below in
Section 8.2 of Chapter 5.
1.5. Multiplicities of eigenvalues. Let us remind the reader, that if pis
a polynomial, and is its root (i.e. p() = 0) then z dividesp(z), i.e.p
can be represented as p(z) = (z )q(z), whereqis some polynomial. If
q() = 0, then qalso can be divided by z , so (z )2dividespand so
on.
The largest positive integer ksuch that ( z )kdividesp(z) is called
the multiplicity of the root .
Ifis an eigenvalue of an operator (matrix) A, then it is a root of the
characteristic polynomial p(z) = det(A zI). The multiplicity of this root
is called the (algebraic) multiplicity of the eigenvalue .
Any polynomial p(z) =Pn
k=0akzkof degreenhas exactly ncomplex
roots, counting multiplicity. The words counting multiplicities mean that if
a root has multiplicity dwe have to list (count) it dtimes. In other words,
1. Main denitions 103
pcan be represented as
p(z) =an(z 1)(z 2):::(z n):
where1;2;:::;nare its complex roots, counting multiplicities.
There is another notion of multiplicity of an eigenvalue: the dimension of
the eigenspace Ker( A I) is called geometric multiplicity of the eigenvalue
.
Geometric multiplicity is not as widely used as algebraic multiplicity.
So, when people say simply \multiplicity" they usually mean algebraic mul-
tiplicity .
Let us mention, that algebraic and geometric multiplicities of an eigen-
value can dier.
Proposition 1.1. Geometric multiplicity of an eigenvalue cannot exceed its
algebraic multiplicity.
Proof. See Exercise 1.9 below. 
1.6. Trace and determinant.
Theorem 1.2. LetAbennmatrix, and let 1;2;:::;nbe its (complex)
eigenvalues (counting multiplicities). Then
1. traceA=1+2+:::+n.
2. detA=12:::n.
Proof. See Exercises 1.10, 1.11 below. 
1.7. Eigenvalues of a triangular matrix. Computing eigenvalues is
equivalent to nding roots of a characteristic polynomial of a matrix (or
using some numerical method), which can be quite time consuming. How-
ever, there is one particular case, when we can just read eigenvalues o the
matrix. Namely
eigenvalues of a triangular matrix (counting multiplicities) are ex-
actly the diagonal entries a1;1;a2;2;:::;an;n
By triangular here we mean either upper or lower triangular matrix.
Since a diagonal matrix is a particular case of a triangular matrix (it is both
upper and lower triangular
the eigenvalues of a diagonal matrix are its diagonal entries
The proof of the statement about triangular matrices is trivial: we need
to subtract from the diagonal entries of A, and use the fact that deter-
minant of a triangular matrix is the product of its diagonal entries. We get
104 4. Introduction to spectral theory
the characteristic polynomial
det(A I) = (a1;1 )(a2;2 ):::(an;n )
and its roots are exactly a1;1;a2;2;:::;an;n.
Exercises.
1.1. True or false:
a) Every linear operator in an n-dimensional vector space has ndistinct eigen-
values;
b) If a matrix has one eigenvector, it has innitely many eigenvectors;
c) There exists a square real matrix with no real eigenvalues;
d) There exists a square matrix with no (complex) eigenvectors;
e) Similar matrices always have the same eigenvalues;
f) Similar matrices always have the same eigenvectors;
g) A non-zero sum of two eigenvectors of a matrix Ais always an eigenvector;
h) A non-zero sum of two eigenvectors of a matrix Acorresponding to the
same eigenvalue is always an eigenvector.
1.2. Find characteristic polynomials, eigenvalues and eigenvectors of the following
matrices:
4 5
2 3
;2 1
 1 4
;0
@1 3 3
 3 5 3
3 3 11
A:
1.3. Compute eigenvalues and eigenvectors of the rotation matrix
cos sin
sin cos
:
Note, that the eigenvalues (and eigenvectors) do not need to be real.
1.4. Compute characteristic polynomials and eigenvalues of the following matrices:
0
BB@1 2 5 67
0 2 3 6
0 0 2 5
0 0 0 31
CCA;0
BB@2 1 0 2
043 2
0 0 16 1
0 0 0 541
CCA;0
BB@4 0 0 0
1 3 0 0
2 4e0
3 3 1 11
CCA;
0
BB@4 0 0 0
1 0 0 0
2 4 0 0
3 3 1 11
CCA:
Do not expand the characteristic polynomials, leave them as products.
1.5. Prove that eigenvalues (counting multiplicities) of a triangular matrix coincide
with its diagonal entries
1.6. An operator Ais called nilpotent ifAk=0for somek. Prove that if Ais
nilpotent, then (A) =f0g(i.e. that 0 is the only eigenvalue of A).
2. Diagonalization. 105
1.7. Show that characteristic polynomial of a block triangular matrix

A
0B
;
whereAandBare square matrices, coincides with det( A I) det(B I). (Use
Exercise 3.11 from Chapter 3).
1.8. Letv1;v2;:::;vnbe a basis in a vector space V. Assume also that the rst k
vectors v1;v2;:::;vkof the basis are eigenvectors of an operator A, corresponding
to an eigenvalue (i.e. thatAvj=vj,j= 1;2;:::;k ). Show that in this basis
the matrix of the operator Ahas block triangular form
Ik
0B
;
whereIkiskkidentity matrix and Bis some (n k)(n k) matrix.
1.9. Use the two previous exercises to prove that geometric multiplicity of an
eigenvalue cannot exceed its algebraic multiplicity.
1.10. Prove that determinant of a matrix Ais the product of its eigenvalues (count-
ing multiplicities).
Hint: rst show that det( A I) = (1 )(2 ):::(n ), where
1;2;:::;nare eigenvalues (counting multiplicities). Then compare the free
terms (terms without ) or plug in = 0 to get the conclusion.
1.11. Prove that the trace of a matrix equals the sum of eigenvalues in three steps.
First, compute the coecient of n 1in the right side of the equality
det(A I) = (1 )(2 ):::(n ):
Then show that det( A I) can be represented as
det(A I) = (a1;1 )(a2;2 ):::(an;n ) +q()
whereq() is polynomial of degree at most n 2. And nally, comparing the
coecients of n 1get the conclusion.
2. Diagonalization.
One of the application of the spectral theory is the diagonalization of oper-
ators, which means given an operator to nd a basis in which the matrix of
the operator is diagonal. Such basis does not always exists, i.e not all opera-
tors can be diagonalized (are diagonalizable). Importance of diagonalizable
operators comes from the fact that the powers, and more general function
of diagonal matrices are easy to compute, so if we diagonalize an operator
we can easily compute functions of it.
We will explain how to compute functions of diagonalizable operators in
this section. We also give a necessary and sucient condition for an operator
to be diagonalizable, as well as some simple sucient conditions.
106 4. Introduction to spectral theory
Note also that for operators in Fn(matrices) the diagonalizability of A
means that it can be represented as A=SDS 1, whereDis a diagonal
matrix (and S, of course, is invertible); we will explain this shortly.
Unless otherwise specied, all results in this section hold for both com-
plex and real vector spaces (and even for spaces over arbitrary elds).
2.1. Preliminaries. Suppose an operator Ain a vector space Vis such
thatVhas a basisB=b1;b2;:::;bnof eigenvectors of A, with1;2;:::;n
being the corresponding eigenvalues. Then the matrix of Ain this basis is
the diagonal matrix with 1;2;:::;non the diagonal
[A]BB= diagf1;2;:::;ng=0
BBB@1
20
...0 n1
CCCA: (2.1)
On the other hand, if the matrix of an operator Ain a basisB=
b1;b2;:::;bnis given by (2.1) then trivially Abk=kbk, i.ekare eigen-
values and bkare corresponding eigenvectors.
Note that the above reasoning hods for both complex and real vector
spaces (and even for vector spaces over arbitrary elds)
Applying the above reasoning to operators in Fn(matrices) we immedi-
ately get the following theorem. Note, that while in this book Fis either C
orR, this theorem hods for an arbitrary eld F.
Theorem 2.1. A matrixA(with values in F) admits a representation A=
SDS 1, whereDis a diagonal matrix and Sis an invertible one (both with
entries in F) if and only if there exists a basis in Fnof eigenvectors of A.
Moreover, in this case diagonal entries of Dare the eigenvalues and the
columns of Sare the corresponding eigenvectors (column number kcorre-
sponds tokth diagonal entry of D).
Proof. LetD= diagf1;2;:::;ng, and let b1;b2;:::;bnbe the columns
ofS(note that since Sis invertible its columns form a basis in Fn). Then
the identity A=SDS 1means that D= [A]B;B.
Indeed,S= [I]S;Bis the change of the coordinates matrix from Bto
the standard basis S, so we get from A=SDS 1thatD=S 1AS=
[I]B;SA[I]S;B], which means exactly that D= [A]B;B.
And as we just discussed above, [ A]B;B=D= diagf1;2;:::;ngif
and only if kare the eigenvalues and bkare the corresponding eigenvectors
ofA. 
2. Diagonalization. 107
Remark. Note if a matrix admits the representation A=SDS 1with a di-
agonal matrix D, then a simple direct calculation shows that the columns of
Sare eigenvectors of Aand diagonal entries of Dare corresponding eigen-
values. This gives an alternative proof of the corresponding statement in
Theorem 2.1.
As we discussed above, a diagonalizable operator A:V!Vhas exactly
n= dimVeigenvalues (counting multiplicities). Any operator in a complex
vector space Vhasneigenvalues (counting multiplicities); an operator in a
real space, on the other hand, could have no real eigenvalues.
We will, as it is customary in the spectral theory, treat real matrices as
operators in the complex space Cn, thus allowing complex eigenvalues and
eigenvectors. Unless otherwise specied we will mean by the diagonalization
of a matrix its complex diagonalization, i.e. a representation A=SDS 1
where matrices SandDcan have complex entries.
The question when a real matrix admits a real diagonalization ( A=
SDS 1with real matrices SandD) is in fact a very simple one, see Theorem
2.9 below.
2.2. Some motivations: functions of operators. Let the matrix of an
operatorAin a basisB=b1;b2;:::;bnis a diagonal one given by (2.1).
Then it is easy to nd an Nth power of the operator A. Namely, the matrix
ofANin the basisBis
[AN]BB= diagfN
1;N
2;:::;N
ng=0
BBB@N
1
N
20
...0 N
n1
CCCA:
Moreover, functions of the operator are also very easy to compute: for ex-
ample the operator (matrix) exponent etAis dened as etA=I+tA+t2A2
2!+
t3A3
3!+:::=1X
k=0tkAk
k!, and its matrix in the basis Bis
[etA]BB= diagfe1t;e2t;:::;entg=0
BBB@e1t
e2t0
...0 ent1
CCCA:
Let nowAbe an operator in Fn. To nd the matrices of the operators
ANandetAin the standard basis S, we need to recall that the change of
coordinate matrix [ I]SBis the matrix with columns b1;b2;:::;bn. Let us
108 4. Introduction to spectral theory
call this matrix S, then according to the change of coordinates formula we
have
A= [A]SS=S0
BBB@1
20
...0 n1
CCCAS 1=SDS 1;
where we use Dfor the diagonal matrix in the middle.
Similarly
AN=SDNS 1=S0
BBB@N
1
N
20
...0 N
n1
CCCAS 1;
and similarly for etA.
Another way of thinking about powers (or other functions) of diagonaliz-
able operators is to see that if operator Acan be represented as A=SDS 1,
then
AN= (SDS 1)(SDS 1):::(SDS 1)| {z }
Ntimes=SDNS 1
and it is easy to compute the Nth power of a diagonal matrix.
2.3. The case of ndistinct eigenvalues. We now present very simple
sucient condition for an operator to be diagonalizable, see Corollary 2.3
below.
Theorem 2.2. Let1;2;:::;rbe distinct eigenvalues of A, and let
v1;v2;:::;vrbe the corresponding eigenvectors. Then vectors v1;v2;:::;vr
are linearly independent.
Proof. We will use induction on r. The case r= 1 is trivial, because by
the denition an eigenvector is non-zero, and a system consisting of one
non-zero vector is linearly independent.
Suppose that the statement of the theorem is true for r 1. Suppose
there exists a non-trivial linear combination
(2.2) c1v1+c2v2+:::+crvr=rX
k=1ckvk=0:
ApplyingA rIto (2.2) and using the fact that ( A rI)vr=0we
get
r 1X
k=1ck(k r)vk=0:
2. Diagonalization. 109
By the induction hypothesis vectors v1;v2;:::;vr 1are linearly indepen-
dent, sock(k r) = 0 fork= 1;2;:::;r 1. Sincek6=rwe can
conclude that ck= 0 fork < r . Then it follows from (2.2) that cr= 0,
i.e. we have the trivial linear combination. 
Corollary 2.3. If an operator A:V!Vhas exactly n= dimVdistinct While very simple,
this is a very impor-
tant statement, and
it will be used a lot!
Please remember it.eigenvalues, then it is diagonalizable.
Proof. For each eigenvalue kletvkbe a corresponding eigenvector (just
pick one eigenvector for each eigenvalue). By Theorem 2.2 the system
v1;v2;:::;vnis linearly independent, and since it consists of exactly n=
dimVvectors it is a basis. 
2.4. Bases of subspaces (AKA direct sums of subspaces). To de-
scribe diagonalizable operators we need to introduce some new denitions.
LetV1;V2;:::;Vpbe subspaces of a vector space V. We say that the
system of subspaces is a basis in Vif any vector v2Vadmits a unique
representation as a sum
(2.3) v=v1+v2+:::+vp=pX
k=1vk; vk2Vk:
We also say, that a system of subspaces V1;V2;:::;Vpis linearly independent
if the equation
v1+v2+:::+vp=0; vk2Vk
has only trivial solution ( vk=08k= 1;2;:::;p ).
Another way to phrase that is to say that a system of subspaces
V1;V2;:::;Vpis linearly independent if and only if any system of non-zero
vectors vk, where vk2Vk, is linearly independent.
We say that the system of subspaces V1;V2;:::;Vpis generating (or
complete, or spanning) if any vector v2Vadmits representation as (2.3)
(not necessarily unique).
Remark 2.4. From the above denition one can immediately see that The-
orem 2.2 in fact states that the system of eigenspaces Ekof an operator
A
Ek:= Ker(A kI); k2(A);
is linearly independent.
Remark 2.5. It is easy to see that similarly to the bases of vectors, a
system of subspaces V1;V2;:::;Vpis a basis if and only if it is generating
and linearly independent. We leave the proof of this fact as an exercise for
the reader.
110 4. Introduction to spectral theory
There is a simple example of a basis of subspaces. Let Vbe a vector
space with a basis v1;v2;:::;vn. Split the set of indices 1 ;2;:::;n into
psubsets  1;2;:::; p, and dene subspaces Vk:= spanfvj:j2kg.
Clearly the subspaces Vkform a basis of V.
The following theorem shows that in the nite-dimensional case it is
essentially the only possible example of a basis of subspaces.
Theorem 2.6. LetV1;V2;:::;Vpbe a basis of subspaces, and let us have
in each subspace Vka basis (of vectors) Bk2. Then the union [kBkof these
bases is a basis in V.
To prove the theorem we need the following lemma
Lemma 2.7. LetV1;V2;:::;Vpbe a linearly independent family of subspac-
es, and let us have in each subspace Vka linearly independent system Bkof
vectors3Then the unionB:=[kBkis a linearly independent system.
Proof. The proof of the lemma is almost trivial, if one thinks a bit about
it. The main diculty in writing the proof is a choice of a appropriate
notation. Instead of using two indices (one for the number kand the other
for the number of a vector in Bk, let us use \at" notation.
Namely, let nbe the number of vectors in B:=[kBk. Let us order the
setB, for example as follows: rst list all vectors from B1, then all vectors
inB2, etc, listing all vectors from Bplast.
This way, we index all vectors in Bby integers 1 ;2;:::;n , and the set of
indicesf1;2;:::;ngsplits into the sets  1;2;:::; psuch that the set Bk
consists of vectors bj:j2k.
Suppose we have a non-trivial linear combination
(2.4) c1b1+c2b2+:::+cnbn=nX
j=1cjbj=0:
Denote
vk=X
j2kcjbj:
Then (2.4) can be rewritten as
v1+v2+:::+vp=0:
2We do not list the vectors in Bk, one just should keep in mind that each Bkconsists of
nitely many vectors in Vk
3Again, here we do not name each vector in Bkindividually, we just keep in mind that each
setBkconsists of nitely many vectors.
2. Diagonalization. 111
Since vk2Vkand the system of subspaces Vkis linearly independent, vk=0
8k. Than means that for every k
X
j2kcjbj=0;
and since the system of vectors bj:j2k(i.e. the systemBk) are linearly
independent, we have cj= 0 for all j2k. Since it is true for all  k, we
can conclude that cj= 0 for allj. 
Proof of Theorem 2.6. To prove the theorem we will use the same nota-
tion as in the proof of Lemma 2.7, i.e. the system Bkconsists of vectors bj,
j2k.
Lemma 2.7 asserts that the system of vectors bj,j= 1;2;:::;n is lin-
early independent, so it only remains to show that the system is complete.
Since the system of subspaces V1;V2;:::;Vpis a basis, any vector v2V
can be represented as
v=v1+v2+:::+vp=pX
k=1vk; vk2Vk:
Since the vectors bj,j2kform a basis in Vk, the vectors vkcan be
represented as
vk=X
j2kcjbj;
and therefore v=Pn
j=1cjbj. 
2.5. Criterion of diagonalizability. First of all let us recall a simple
necessary condition. Since the eigenvalues (counting multiplicities) of a di-
agonal matrix D= diagf1;2;:::;ngare exactly 1;2;:::;n, we see
that if an operator A:V!Vis diagonalizable, it has exactly n= dimV
eigenvalues (counting multiplicities).
Theorem below holds for both real and complex vector spaces (and even
for spaces over genera elds).
Theorem 2.8. Let an operator A:V!Vhas exactly n= dimVeigen-
values (counting multiplicities)4. ThenAis diagonalizable if and only if
for each eigenvalue the dimension of the eigenspace Ker(A I)(i.e. the
geometric multiplicity of ) coincides with the algebraic multiplicity of .
Proof. First of all let us note, that for a diagonal matrix, the algebraic
and geometric multiplicities of eigenvalues coincide, and therefore the same
holds for the diagonalizable operators.
4Since any operator in a complex vector space has exactly neigenvalues (counting multiplic-
ities), this assumption is moot in the complex case.
112 4. Introduction to spectral theory
Let us now prove the other implication. Let 1;2;:::;pbe eigenval-
ues ofA, and letEk:= Ker(A kI) be the corresponding eigenspaces.
According to Remark 2.4, the subspaces Ek,k= 1;2;:::;p are linearly
independent.
LetBkbe a basis in Ek. By Lemma 2.7 the system B=[kBkis a
linearly independent system of vectors.
We know that each Bkconsists of dim Ek(= multiplicity of k) vectors.
So the number of vectors in Bequal to the sum of multiplicities of eigen-
valuesk. But the sum of multiplicities of the eigenvalues is the number of
eigenvalues counting multiplicities, which is exactly n= dimV. So, we have
a linearly independent system of n= dimVeigenvectors, which means it is
a basis. 
2.6. Real factorization. The theorem below is, in fact, already proven (iT
is essentially Theorem 2.8 for real spaces). We state it here to summarize
the situation with real diagonalization of real matrices.
Theorem 2.9. A realnnmatrixAadmits a real factorization (i.e. rep-
resentation A=SDS 1whereSandDare real matrices, Dis diagonal
andSis invertible) if and only if it admits complex factorization and all
eigenvalues of Aare real.
2.7. Some example.
2.7.1. Real eigenvalues. Consider the matrix
A=1 2
8 1
:
Its characteristic polynomial is equal to
1  2
8 1 = (1 )2 16
and its roots (eigenvalues) are = 5 and= 3. For the eigenvalue = 5
A 5I=1 5 2
8 1 5
= 4 2
8 4
A basis in its nullspace consists of one vector (1 ;2)T, so this is the corre-
sponding eigenvector.
Similarly, for = 3
A I=A+ 3I=4 2
8 4
2. Diagonalization. 113
and the eigenspace Ker( A+ 3I) is spanned by the vector (1 ; 2)T. The
matrixAcan be diagonalized as
A=1 2
8 1
=1 1
2 25 0
0 31 1
2 2 1
2.7.2. Complex eigenvalues. Consider the matrix
A=1 2
 2 1
:
Its characteristic polynomial is
1  2
 2 1 = (1 )2+ 22
and the eigenvalues (roots of the characteristic polynomial are = 12i.
For= 1 + 2i
A I= 2i2
 2 2i
This matrix has rank 1, so the eigenspace Ker( A T) is spanned by one
vector, for example by (1 ;i)T.
Since the matrix Ais real, we do not need to compute an eigenvector
for= 1 2i: we can get it for free by taking the complex conjugate of the
above eigenvector, see Exercise 2.2 below. So, for = 1 2ia corresponding
eigenvector is (1 ; i)T, and so the matrix Acan be diagonalized as
A=1 1
i i1 + 2i 0
0 1 2i1 1
i i 1
:
2.7.3. A non-diagonalizable matrix. Consider the matrix
A=1 1
0 1
:
Its characteristic polynomial is
1  1
0 1 = (1 )2;
soAhas an eigenvalue 1 of multiplicity 2. But, it is easy to see that
dim Ker(A I) = 1 (1 pivot, so 2  1 = 1 free variable). Therefore, the
geometric multiplicity of the eigenvalue 1 is dierent from its algebraic mul-
tiplicity, so Ais not diagonalizable.
There is also an explanation which does not use Theorem 2.8. Namely,
we got that the eigenspace Ker( A 1I) is one dimensional (spanned by the
vector (1;0)T). IfAwere diagonalizable, it would have a diagonal form
114 4. Introduction to spectral theory
1 0
0 1
in some basis,5and so the dimension of the eigenspace wold be 2.
ThereforeAcannot be diagonalized.
Exercises.
2.1. LetAbennmatrix. True or false:
a)AThas the same eigenvalues as A.
b)AThas the same eigenvectors as A.
c) IfAis is diagonalizable, then so is AT.
Justify your conclusions.
2.2. LetAbe a square matrix with real entries, and let be its complex eigenvalue.
Suppose v= (v1;v2;:::;vn)Tis a corresponding eigenvector, Av=v. Prove that
theis an eigenvalue of AandAv=v. Here vis the complex conjugate of the
vector v,v:= (v1;v2;:::;vn)T.
2.3. Let
A=4 3
1 2
:
FindA2004by diagonalizing A.
2.4. Construct a matrix Awith eigenvalues 1 and 3 and corresponding eigenvectors
(1;2)Tand (1;1)T. Is such a matrix unique?
2.5. Diagonalize the following matrices, if possible:
a)4 2
1 1
.
b)
 1 1
6 4
.
c)0
@ 2 2 6
5 1 6
 5 2 91
A (= 2 is one of the eigenvalues)
2.6. Consider the matrix
A=0
@2 6 6
0 5 2
0 0 41
A:
a) Find its eigenvalues. Is it possible to nd the eigenvalues without comput-
ing?
b) Is this matrix diagonalizable? Find out without computing anything.
c) If the matrix is diagonalizable, diagonalize it.
5Note, that the only linear transformation having matrix1 0
0 1
in some basis is the
identity transformation I. SinceAis denitely not the identity, we can immediately conclude
thatAcannot be diagonalized, so counting dimension of the eigenspace is not necessary.
2. Diagonalization. 115
2.7. Diagonalize the matrix0
@2 0 6
0 2 4
0 0 41
A:
2.8. Find all square roots of the matrix
A=5 2
 3 0
i.e. nd all matrices Bsuch thatB2=A.Hint: Finding a square root of a
diagonal matrix is easy. You can leave your answer as a product.
2.9. Let us recall that the famous Fibonacci sequence:
0;1;1;2;3;5;8;13;21;:::
is dened as follows: we put '0= 0,'1= 1 and dene
'n+2='n+1+'n:
We want to nd a formula for 'n. To do this
a) Find a 22 matrixAsuch that
'n+2
'n+1
=A'n+1
'n
Hint: Combine the trivial equation 'n+1='n+1with the Fibonacci
relation'n+2='n+1+'n.
b) Diagonalize Aand nd a formula for An.
c) Noticing that

'n+1
'n
=An
'1
'0
=An
1
0
nd a formula for 'n. (You will need to compute an inverse and perform
multiplication here).
d) Show that the vector ( 'n+1='n;1)Tconverges to an eigenvector of A.
What do you think, is it a coincidence?
2.10. LetAbe a 55 matrix with 3 eigenvalues (not counting multiplicities).
Suppose we know that one eigenspace is three-dimensional. Can you say if Ais
diagonalizable?
2.11. Give an example of a 3 3 matrix which cannot be diagonalized. After you
constructed the matrix, can you make it \generic", so no special structure of the
matrix could be seen?
2.12. Let a non-zero matrix AsatisfyA5=0. Prove that Acannot be diagonalized.
More generally, any non-zero nilpotent matrix, i.e. a non-zero matrix satisfying
AN=0for someNcannot be diagonalized.
2.13. Eigenvalues of a transposition:
116 4. Introduction to spectral theory
a) Consider the transformation Tin the space M22of 22 matrices, T(A) =
AT. Find all its eigenvalues and eigenvectors. Is it possible to diagonalize
this transformation? Hint: While it is possible to write a matrix of this
linear transformation in some basis, compute characteristic polynomial,
and so on, it is easier to nd eigenvalues and eigenvectors directly from the
denition.
b) Can you do the same problem but in the space of nnmatrices?
2.14. Prove that two subspaces V1andV2are linearly independent if and only if
V1\V2=f0g.
Chapter 5
Inner product spaces
Theory of inner product spaces is developed only for real and complex spaces,
soFin this Chapter is always RorC; the results usually do not generalize
to spaces over arbitrary elds.
Most of the results and calculations in this chapter hold (and the results
have the same statements) in both real and complex cases. In rare situations
when there is a dierence between real and complex case, we state explicitly
which case is considered: otherwise everything holds for both cases.
Finally, when the results and calculations hold for both complex and
real cases, we use formulas for the complex case; in the real case they give
correct, although sometimes a bit more complicated, formulas.
1. Inner product in RnandCn. Inner product spaces.
1.1. Inner product and norm in Rn.In dimensions 2 and 3, we dened
the length of a vector x(i.e. the distance from its endpoint to the origin) by
the Pythagorean rule, for example in R3the length of the vector is dened
as
kxk=q
x2
1+x2
2+x2
3:
It is natural to generalize this formula for all n, to dene the norm of the
vector x2Rnas
kxk=q
x2
1+x2
2+:::+x2n:
The word norm is used as a fancy replacement for the word length.
117
118 5. Inner product spaces
The dot product inR3was dened as xy=x1y2+x2y2+x3y3, where
x= (x1;x2;x3)Tandy= (y1;y2;y3)T.
Similarly, in Rnone can dene the inner product (x;y) of two vectors While the notation
xyand term \dot
product" is often
used for the inner
product, for reasons
which will be clear
later, we prefer the
notation ( x;y)x= (x1;x2;:::;xn)T,y= (y1;y2;:::;yn)Tby
(x;y) :=x1y1+x2y2+:::+xnyn=yTx;
sokxk=p
(x;x).
Note, that yTx=xTy, and we use the notation yTxonly to be consis-
tent.
1.2. Inner product and norm in Cn.Let us now dene norm and inner
product for Cn. As we have seen before, the complex space Cnis the most
natural space from the point of view of spectral theory: even if one starts
from a matrix with real coecients (or operator on a real vectors space),
the eigenvalues can be complex, and one needs to work in a complex space.
For a complex number z=x+iy, we havejzj2=x2+y2=zz. Ifz2Cn
is given by
z=0
BBB@z1
z2
...
zn1
CCCA=0
BBB@x1+iy1
x2+iy2
...
xn+iyn1
CCCA;
it is natural to dene its norm kzkby
kzk2=nX
k=1(x2
k+y2
k) =nX
k=1jzkj2:
Let us try to dene an inner product on Cnsuch thatkzk2= (z;z). One of
the choices is to dene ( z;w) by
(z;w) =z1w1+z2w2+:::+znwn=nX
k=1zkwk;
and that will be our denition of the standard inner product in Cn.
To simplify the notation, let us introduce a new notion. For a matrix
Alet us dene its Hermitian adjoint , or simply adjointAbyA=AT,
meaning that we take the transpose of the matrix, and then take the complex
conjugate of each entry. Note, that for a real matrix A,A=AT.
Using the notion of A, one can write the standard inner product in Cn
as
(z;w) =wz:
1. Inner product in RnandCn. Inner product spaces. 119
Remark. It is easy to see that one can dene a dierent inner product in Cnsuch
thatkzk2= (z;z), namely the inner product given by
(z;w)1=z1w1+z2w2+:::+znwn=zw:
We did not specify what properties we want the inner product to satisfy, but zw
andwzare the only reasonable choices giving kzk2= (z;z).
Note, that the above two choices of the inner product are essentially equivalent:
the only dierence between them is notational, because ( z;w)1= (w;z).
While the second choice of the inner product looks more natural, the rst one,
(z;w) =wzis more widely used, so we will use it as well.
1.3. Inner product spaces. The inner product we dened for RnandCn
satises the following properties:
1. (Conjugate) symmetry: ( x;y) =(y;x); note, that for a real space,
this property is just symmetry, ( x;y) = (y;x);
2. Linearity: ( x+y;z) =(x;z) +(y;z) for all vector x;y;zand
all scalars;;
3. Non-negativity: ( x;x)08x;
4. Non-degeneracy: ( x;x) = 0 if and only if x=0.
LetVbe a (complex or real) vector space. An inner product onVis a
function, that assign to each pair of vectors x,ya scalar, denoted by ( x;y)
such that the above properties 1{4 are satised.
Note that for a real space Vwe assume that ( x;y) is always real, and
for a complex space the inner product ( x;y) can be complex.
A spaceVtogether with an inner product on it is called an inner product
space . Given an inner product space, one denes the norm on it by
kxk=p
(x;x):
1.3.1. Examples.
Example 1.1. LetVbeRnorCn. We already have an inner product
(x;y) =yx=Pn
k=1xkykdened above.
This inner product is called the standard inner product in RnorCn
We will use symbol Fto denote both CandR. When we have some
statement about the space Fn, it means the statement is true for both Rn
andCn.
Example 1.2. LetVbe the space Pnof polynomials of degree at most n.
Dene the inner product by
(f;g) =Z1
 1f(t)g(t)dt:
120 5. Inner product spaces
It is easy to check, that the above properties 1{4 are satised.
This denition works both for complex and real cases. In the real case
we only allow polynomials with real coecients, and we do not need the
complex conjugate here.
Let us recall, that for a square matrix A, its trace is dened as the sum
of the diagonal entries,
traceA:=nX
k=1ak;k:
Example 1.3. For the space Mmnofmnmatrices let us dene the
so-called Frobenius inner product by
(A;B) = trace(BA):
Again, it is easy to check that the properties 1{4 are satised, i.e. that we
indeed dened an inner product.
Note, that
trace(BA) =X
j;kAj;kBj;k;
so this inner product coincides with the standard inner product in Cmn.
1.4. Properties of inner product. The statements we get in this section
are true for any abstract inner product space, not only for Fn. To prove them
we use only properties 1{4 of the inner product.
First of all let us notice, that properties 1 and 2 imply that
20. (x;y+z) =(x;y) +(x;z).
Indeed,
(x;y+z) =(y+z;x) =(y;x) +(z;x) =
=(y;x) +(z;x) =(x;y) +(x;z)
Note also that property 2 implies that for all vectors x
(0;x) = (x;0) = 0:
Lemma 1.4. Letxbe a vector in an inner product space V. Then x=0if
and only if
(1.1) ( x;y) = 08y2V:
Proof. Since ( 0;y) = 0 we only need to show that (1.1) implies x=0.
Putting y=xin (1.1) we get ( x;x) = 0, so x=0. 
Applying the above lemma to the dierence x ywe get the following
1. Inner product in RnandCn. Inner product spaces. 121
Corollary 1.5. Letx;ybe vectors in an inner product space V. The equality
x=yholds if and only if
(x;z) = (y;z)8z2V:
The following corollary is very simple, but will be used a lot
Corollary 1.6. Suppose two operators A;B :X!Ysatisfy
(Ax;y) = (Bx;y)8x2X;8y2Y:
ThenA=B.
Proof. By the previous corollary (x xand take all possible y's) we get
Ax=Bx. Since this is true for all x2X, the transformations AandB
coincide. 
The following property relates the norm and the inner product.
Theorem 1.7 (Cauchy{Schwarz inequality) .
j(x;y)jkxkkyk:
Proof. The proof we are going to present, is not the shortest one, but it
shows where the main ideas came from.
Let us consider the real case rst. If y=0, the statement is trivial, so
we can assume that y6=0. By the properties of an inner product, for all
scalart
0kx tyk2= (x ty;x ty) =kxk2 2t(x;y) +t2kyk2:
In particular, this inequality should hold for t=(x;y)
kyk21, and for this point
the inequality becomes
0kxk2 2(x;y)2
kyk2+(x;y)2
kyk2=kxk2 (x;y)2
kyk2;
which is exactly the inequality we need to prove.
There are several possible ways to treat the complex case. One is to
replace xbyx, whereis a complex constant, jj= 1 such that ( x;y)
is real, and then repeat the proof for the real case.
The other possibility is again to consider
0kx tyk2= (x ty;x ty) = (x;x ty) t(y;x ty)
=kxk2 t(y;x) t(x;y) +jtj2kyk2:
1That is the point where the above quadratic polynomial has a minimum: it can be computed,
for example by taking the derivative in tand equating it to 0
122 5. Inner product spaces
Substituting t=(x;y)
kyk2=(y;x)
kyk2into this inequality, we get
0kxk2 j(x;y)j2
kyk2
which is the inequality we need.
Note, that the above paragraph is in fact a complete formal proof of the
theorem. The reasoning before that was only to explain why do we need to
pick this particular value of t. 
An immediate Corollary of the Cauchy{Schwarz Inequality is the follow-
ing lemma.
Lemma 1.8 (Triangle inequality) .For any vectors x,yin an inner product
space
kx+ykkxk+kyk:
Proof.
kx+yk2= (x+y;x+y) =kxk2+kyk2+ (x;y) + (y;x)
kxk2+kyk2+ 2j(x;y)j
kxk2+kyk2+ 2kxkkyk= (kxk+kyk)2:

The following polarization identities allow one to reconstruct the inner
product from the norm:
Lemma 1.9 (Polarization identities) .Forx;y2V
(x;y) =1
4 
kx+yk2 kx yk2
ifVis a real inner product space, and
(x;y) =1
4X
=1;ikx+yk2
ifVis a complex inner product space.
The lemma is proved by direct computation. We leave the proof as an
exercise for the reader.
Another important property of the norm in an inner product space can
be also checked by direct calculation.
Lemma 1.10 (Parallelogram Identity) .For any vectors u;v
ku+vk2+ku vk2= 2(kuk2+kvk2):
1. Inner product in RnandCn. Inner product spaces. 123
In 2-dimensional space this lemma relates sides of a parallelogram with
its diagonals, which explains the name. It is a well-known fact from planar
geometry.
1.5. Norm. Normed spaces. We have proved before that the norm kvk
satises the following properties:
1. Homogeneity: kvk=jjkvkfor all vectors vand all scalars .
2. Triangle inequality: ku+vkkuk+kvk.
3. Non-negativity: kvk0 for all vectors v.
4. Non-degeneracy: kvk= 0 if and only if v=0.
Suppose in a vector space Vwe assigned to each vector va numberkvk
such that above properties 1{4 are satised. Then we say that the function
v7!kvkis a norm. A vector space Vequipped with a norm is called a
normed space .
Any inner product space is a normed space, because the norm kvk=p
(v;v) satises the above properties 1{4. However, there are many other
normed spaces. For example, given p, 1p<1one can dene the norm
kkponRnorCnby
kxkp= (jx1jp+jx2jp+:::+jxnjp)1=p= nX
k=1jxkjp!1=p
:
One can also dene the norm kk1(p=1) by
kxk1= maxfjxkj:k= 1;2;:::;ng:
The normkkpforp= 2 coincides with the regular norm obtained from
the inner product.
To check thatkkpis indeed a norm one has to check that it satises
all the above properties 1{4. Properties 1, 3 and 4 are very easy to check,
we leave it as an exercise for the reader. The triangle inequality (property
2) is easy to check for p= 1 andp=1(and we proved it for p= 2).
For all other pthe triangle inequality is true, but the proof is not so
simple, and we will not present it here. The triangle inequality for kkp
even has special name: its called Minkowski inequality , after the German
mathematician H. Minkowski.
Note, that the norm kkpforp6= 2 cannot be obtained from an inner
product. It is easy to see that this norm is not obtained from the standard
inner product in Rn(Cn). But we claim more! We claim that it is impossible
to introduce an inner product which gives rise to the norm kkp,p6= 2.
This statement is actually quite easy to prove. By Lemma 1.10 any norm
obtained from an inner product must satisfy the Parallelogram Identity. It
124 5. Inner product spaces
is easy to see that the Parallelogram Identity fails for the norm kkp,p6= 2,
and one can easily nd a counterexample in R2, which then gives rise to a
counterexample in all other spaces.
In fact, the Parallelogram Identity, as the theorem below asserts, com-
pletely characterizes norms obtained from an inner product.
Theorem 1.11. A norm in a normed space is obtained from some inner
product if and only if it satises the Parallelogram Identity
ku+vk2+ku vk2= 2(kuk2+kvk2)8u;v2V:
Lemma 1.10 asserts that a norm obtained from an inner product satises
the Parallelogram Identity.
The converse implication is more complicated. If we are given a norm,
and this norm came from an inner product, then we do not have any choice;
this inner product must be given by the polarization identities, see Lemma
1.9. But, we need to show that ( x;y) which we got from the polarization
identities is indeed an inner product, i.e. that it satises all the properties.
It is indeed possible to verify that if the norm satises the parallelogram
identity then the inner product ( x;y) obtained from the polarization iden-
tities is indeed an inner product (i.e. satises all the properties of an inner
product). However, the proof is a bit too involved, so we do not present it
here.
Exercises.
1.1. Compute
(3 + 2i)(5 3i);2 3i
1 2i; Re2 3i
1 2i
; (1 + 2i)3; Im((1 + 2i)3):
1.2. For vectors x= (1;2i;1 +i)Tandy= (i;2 i;3)Tcompute
a) (x;y),kxk2,kyk2,kyk;
b) (3x;2iy), (2x;ix+ 2y);
c)kx+ 2yk.
Remark: After you have done part a), you can do parts b) and c) without actually
computing all vectors involved, just by using the properties of inner product.
1.3. Letkuk= 2,kvk= 3, ( u;v) = 2 +i. Compute
ku+vk2;ku vk2; (u+v;u iv); (u+ 3iv;4iu):
1.4. Prove that for vectors in a inner product space
kxyk2=kxk2+kyk22 Re(x;y)
Recall that Re z=1
2(z+z)
1.5. Explain why each of the following is not an inner product on a given vector
space:
2. Orthogonality. Orthogonal and orthonormal bases. 125
a) (x;y) =x1y1 x2y2onR2;
b) (A;B) = trace(A+B) on the space of real 2 2 matrices'
c) (f;g) =R1
0f0(t)g(t)dton the space of polynomials; f0(t) denotes derivative.
1.6(Equality in Cauchy{Schwarz inequality) .Prove that
j(x;y)j=kxkkyk
if and only if one of the vectors is a multiple of the other. Hint: Analyze the proof
of the Cauchy{Schwarz inequality.
1.7. Prove the parallelogram identity for an inner product space V,
kx+yk2+kx yk2= 2(kxk2+kyk2):
1.8. Letv1;v2;:::;vnbe a spanning set (in particular, a basis) in an inner product
spaceV. Prove that
a) If ( x;v) = 0 for all v2V, then x=0;
b) If ( x;vk) = 08k, then x=0;
c) If ( x;vk) = (y;vk)8k, then x=y.
1.9. Consider the space R2with the normkkp, introduced in Section 1.5. For
p= 1;2;1, draw the \unit ball" Bpin the normkkp
Bp:=fx2R2:kxkp1g:
Can you guess what the balls Bpfor otherplook like?
2. Orthogonality. Orthogonal and orthonormal bases.
Denition 2.1. Two vectors uandvare called orthogonal (also perpen-
dicular ) if (u;v) = 0. We will write u?vto say that the vectors are
orthogonal.
Note, that for orthogonal vectors uandvwe have the following, so-called
Pythagorean identity:
ku+vk2=kuk2+kvk2ifu?v:
The proof is straightforward computation,
ku+vk2= (u+v;u+v) = (u;u) + (v;v) + (u;v) + (v;u) =kuk2+kvk2
((u;v) = (v;u) = 0 because of orthogonality).
Denition 2.2. We say that a vector vis orthogonal to a subspace Eifv
is orthogonal to all vectors winE.
We say that subspaces EandFare orthogonal if all vectors in Eare
orthogonal to F, i.e. all vectors in Eare orthogonal to all vectors in F
The following lemma shows how to check that a vector is orthogonal to
a subspace.
126 5. Inner product spaces
Lemma 2.3. LetEbe spanned by vectors v1;v2;:::;vr. Then v?Eif
and only if
v?vk;8k= 1;2;:::;r:
Proof. By the denition, if v?Ethenvis orthogonal to all vectors in E.
In particular, v?vk,k= 1;2;:::;r .
On the other hand, let v?vk,k= 1;2;:::;r . Since the vectors vkspan
E, any vector w2Ecan be represented as a linear combinationPr
k=1kvk.
Then
(v;w) =rX
k=1k(v;vk) = 0;
sov?w. 
Denition 2.4. A system of vectors v1;v2;:::;vnis called orthogonal if
any two vectors are orthogonal to each other (i.e. if ( vj;vk) = 0 forj6=k).
If, in additionkvkk= 1 for allk, we call the system orthonormal .
Lemma 2.5 (Generalized Pythagorean identity) .Letv1;v2;:::;vnbe an
orthogonal system. Then
nX
k=1kvk2
=nX
k=1jkj2kvkk2
This formula looks particularly simple for orthonormal systems, where
kvkk= 1.
Proof of the Lemma.nX
k=1kvk2
=nX
k=1kvk;nX
j=1jvj
=nX
k=1nX
j=1kj(vk;vj):
Because of orthogonality ( vk;vj) = 0 ifj6=k. Therefore we only need to
sum the terms with j=k, which gives exactly
nX
k=1jkj2(vk;vk) =nX
k=1jkj2kvkk2:

Corollary 2.6. Any orthogonal system v1;v2;:::;vnof non-zero vectors is
linearly independent.
Proof. Suppose for some 1;2;:::;nwe havePn
k=1kvk=0. Then by
the Generalized Pythagorean identity (Lemma 2.5)
0 =k0k2=nX
k=1jkj2kvkk2:
2. Orthogonality. Orthogonal and orthonormal bases. 127
Sincekvkk6=0(vk6=0) we conclude that
k= 08k;
so only the trivial linear combination gives 0. 
Remark. In what follows we will usually mean by an orthogonal system an
orthogonal system of non-zero vectors. Since the zero vector 0is orthogonal
to everything, it always can be added to any orthogonal system, but it is
really not interesting to consider orthogonal systems with zero vectors.
2.1. Orthogonal and orthonormal bases.
Denition 2.7. An orthogonal (orthonormal) system v1;v2;:::;vnwhich
is also a basis is called an orthogonal (orthonormal) basis.
It is clear that in dim V=nthen any orthogonal system of nnon-zero
vectors is an orthogonal basis.
As we studied before, to nd coordinates of a vector in a basis one
needs to solve a linear system. However, for an orthogonal basis nding
coordinates of a vector is much easier. Namely, suppose v1;v2;:::;vnis an
orthogonal basis, and let
x=1v1+2v2+:::+nvn=nX
j=1jvj:
Taking inner product of both sides of the equation with v1we get
(x;v1) =nX
j=1j(vj;v1) =1(v1;v1) =1kv1k2
(all inner products ( vj;v1) = 0 ifj6= 1), so
1=(x;v1)
kv1k2:
Similarly, multiplying both sides by vkwe get
(x;vk) =nX
j=1j(vj;vk) =k(vk;vk) =kkvkk2
so
(2.1) k=(x;vk)
kvkk2:
Therefore,
to nd coordinates of a vector in an orthogonal basis one does not
need to solve a linear system, the coordinates are determined by
the formula (2.1).
128 5. Inner product spaces
This formula is especially simple for orthonormal bases, when kvkk= 1.
Namely, if v1;v2;:::;vnis an orthonormal basis, any vector vcan be
represented as
(2.2) v=nX
k=1(v;vk)vk:
This formula is sometimes called (a baby version of) the abstract orthogonal
Fourier decomposition . The classical (non-abstract) Fourier decomposition
deals with a concrete orthonormal system (sines and cosines or complex
exponentials). We call this formula a baby version because the real Fourier
decomposition deals with innite orthonormal systems.
Remark 2.8. The importance of orthonormal bases is that if we x an
orthonormal basis in an inner product space V, we can work with coordinates
in this basis the same way we work with vectors in Fn. Namely, as it was This is a very impor-
tant remark allowing
one to translate any
statement about the
standard inner prod-
uct space Fnto an
inner product space
with an orthonormal
basis v1;v2;:::;vndiscussed in the very beginning of the book, see Remark 2.4 in Chapter
1, if we have a vector space V(over a eld F) with a basis v1;v2;:::;vn,
then we can perform the standard vector operations (vector addition and
multiplication by a scalar) by working with the columns of coordinates in
the basis v1;v2;:::;vnin absolutely the same way we work with vectors in
the standard coordinate space Fn.
Exercise 2.3 below shows that if we have an orthonormal basis in an
inner product space V, we can compute the inner product of 2 vectors in
Vby taking columns of their coordinates in this orthonormal basis and
computing the standard inner product (in CnorRn) of these columns.
As it will be shown below in Section 3 any nite-dimensional inner prod-
uct space has an orthonormal basis. Thus, the standard inner product spaces
Cn(orRnin the case of real spaces) are essentially the only examples of a
nite-dimensional inner product spaces.
Exercises.
2.1. Find all vectors in R4orthogonal to vectors (1 ;1;1;1)Tand (1;2;3;4)T.
2.2. LetAbe a realmnmatrix. Describe (Ran AT)?, (RanA)?
2.3. Letv1;v2;:::;vnbe an orthonormal basis in V.
a) Prove that for any x=Pn
k=1kvk,y=Pn
k=1kvk
(x;y) =nX
k=1kk:
b) Deduce from this the Parseval's identity
(x;y) =nX
k=1(x;vk)(y;vk)
3. Orthogonal projection and Gram-Schmidt orthogonalization 129
c) Assume now that v1;v2;:::;vnis only an orthogonal basis, not an or-
thonormal one. Can you write down Parseval's identity in this case?
This problem shows that if we have an orthonormal basis, we can use the
coordinates in this basis absolutely the same way we use the standard coordinates
inCn(orRn).
The problem below shows that we can dene an inner product by declaring a
basis to be an orthonormal one.
2.4. LetVbe a vector space and let v1;v2;:::;vnbe a basis in V. For x=Pn
k=1kvk,y=Pn
k=1kvkdenehx;yi:=Pn
k=1kk.
Prove thathx;yidenes an inner product in V.
2.5. LetAbe a realmnmatrix. Describe the set of all vectors in Fmorthogonal
to to RanA.
3. Orthogonal projection and Gram-Schmidt
orthogonalization
Recalling the denition of orthogonal projection from the classical planar
(2-dimensional) geometry, one can introduce the following denition. Let E
be a subspace of an inner product space V.
Denition 3.1. For a vector vits orthogonal projection PEvonto the
subspaceEis a vector wsuch that
1.w2E;
2.v w?E.
We will use notation w=PEvfor the orthogonal projection.
After introducing an object, it is natural to ask:
1. Does the object exist?
2. Is the object unique?
3. How does one nd it?
We will show rst that the projection is unique. Then we present a
method of nding the projection, proving its existence.
The following theorem shows why the orthogonal projection is important
and also proves that it is unique.
Theorem 3.2. The orthogonal projection w=PEvminimizes the distance
fromvtoE, i.e. for all x2E
kv wkkv xk:
Moreover, if for some x2E
kv wk=kv xk;
130 5. Inner product spaces
thenx=w.
Proof. Lety=w x. Then
v x=v w+w x=v w+y:
Since v w?Ewe have y?v wand so by Pythagorean Theorem
kv xk2=kv wk2+kyk2kv wk2:
Note that equality happens only if y=0i.e. if x=w. 
The following proposition shows how to nd an orthogonal projection if
we know an orthogonal basis in E.
Proposition 3.3. Letv1;v2;:::;vrbe an orthogonal basis in E. Then the
orthogonal projection PEvof a vector vis given by the formula
PEv=rX
k=1kvk; wherek=(v;vk)
kvkk2:
In other words
(3.1) PEv=rX
k=1(v;vk)
kvkk2vk:
Note that the formula for kcoincides with (2.1), i.e. this formula applied
to an orthogonal system (not a basis) gives us a projection onto its span.
Remark 3.4. It is easy to see now from formula (3.1) that the orthogonal
projectionPEis a linear transformation.
One can also see linearity of PEdirectly, from the denition and unique-
ness of the orthogonal projection. Indeed, it is easy to check that for any x
andythe vectorx+y (PEx PEy) is orthogonal to any vector in
E, so by the denition PE(x+y) =PEx+PEy.
Remark 3.5. Recalling the denition of inner product in CnandRnone
can get from the above formula (3.1) the matrix of the orthogonal projection
PEontoEinCn(Rn) is given by
(3.2) PE=rX
k=11
kvkk2vkv
k
where columns v1;v2;:::;vrform an orthogonal basis in E.
Proof of Proposition 3.3. Let
w:=rX
k=1kvk; wherek=(v;vk)
kvkk2:
3. Orthogonal projection and Gram-Schmidt orthogonalization 131
We want to show that v w?E. By Lemma 2.3 it is sucient to show
thatv w?vk,k= 1;2;:::;n . Computing the inner product we get for
k= 1;2;:::;r
(v w;vk) = (v;vk) (w;vk) = (v;vk) rX
j=1j(vj;vk)
= (v;vk) k(vk;vk) = (v;vk) (v;vk)
kvkk2kvkk2= 0:

So, if we know an orthogonal basis in Ewe can nd the orthogonal
projection onto E. In particular, since any system consisting of one vector
is an orthogonal system, we know how to perform orthogonal projection
onto one-dimensional spaces.
But how do we nd an orthogonal projection if we are only given a basis
inE? Fortunately, there exists a simple algorithm allowing one to get an
orthogonal basis from a basis.
3.1. Gram-Schmidt orthogonalization algorithm. Suppose we have
a linearly independent system x1;x2;:::;xn. The Gram-Schmidt method
constructs from this system an orthogonal system v1;v2;:::;vnsuch that
spanfx1;x2;:::;xng= spanfv1;v2;:::;vng:
Moreover, for all rnwe get
spanfx1;x2;:::;xrg= spanfv1;v2;:::;vrg
Now let us describe the algorithm.
Step 1. Putv1:=x1. Denote by E1:= spanfx1g= spanfv1g.
Step 2. Dene v2by
v2=x2 PE1x2=x2 (x2;v1)
kv1k2v1:
DeneE2= spanfv1;v2g. Note that spanfx1;x2g=E2.
Step 3. Dene v3by
v3:=x3 PE2x3=x3 (x3;v1)
kv1k2v1 (x3;v2)
kv2k2v2
PutE3:= spanfv1;v2;v3g. Note that span fx1;x2;x3g=E3. Note also
thatx3=2E2sov36=0.
. . .
132 5. Inner product spaces
Stepr+ 1.Suppose that we already made rsteps of the process, con-
structing an orthogonal system (consisting of non-zero vectors) v1;v2;:::;vr
such thatEr:= spanfv1;v2;:::;vrg= spanfx1;x2;:::;xrg. Dene
vr+1:=xr+1 PErxr+1=xr+1 rX
k=1(xr+1;vk)
kvkk2vk
Note,that xr+1=2Ersovr+16=0.
. . .
Continuing this algorithm we get an orthogonal system v1;v2;:::;vn.
3.2. An example. Suppose we are given vectors
x1= (1;1;1)T; x2= (0;1;2)T; x3= (1;0;2)T;
and we want to orthogonalize it by Gram-Schmidt. On the rst step dene
v1=x1= (1;1;1)T:
On the second step we get
v2=x2 PE1x2=x2 (x2;v1)
kv1k2v1:
Computing
(x2;v1) = 0
@0
1
21
A;0
@1
1
11
A
= 3;kv1k2= 3;
we get
v2=0
@0
1
21
A 3
30
@1
1
11
A=0
@ 1
0
11
A:
Finally, dene
v3=x3 PE2x3=x3 (x3;v1)
kv1k2v1 (x3;v2)
kv2k2v2:
Computing
 0
@1
0
21
A;0
@1
1
11
A
= 3; 0
@1
0
21
A;0
@ 1
0
11
A
= 1;kv1k2= 3;kv2k2= 2
(kv1k2was already computed before) we get
v3=0
@1
0
21
A 3
30
@1
1
11
A 1
20
@ 1
0
11
A=0
@1
2
 1
1
21
A
3. Orthogonal projection and Gram-Schmidt orthogonalization 133
Remark. Since the multiplication by a scalar does not change the orthog-
onality, one can multiply vectors vkobtained by Gram-Schmidt by any
non-zero numbers.
In particular, in many theoretical constructions one normalizes vectors
vkby dividing them by their respective norms kvkk. Then the resulting
system will be orthonormal, and the formulas will look simpler.
On the other hand, when performing the computations one may want
to avoid fractional entries by multiplying a vector by the least common
denominator of its entries. Thus one may want to replace the vector v3
from the above example by (1 ; 2;1)T.
3.3. Orthogonal complement. Decomposition V=EE?.
Denition. For a subspace Eitsorthogonal complement E?is the set of
all vectors orthogonal to E,
E?:=fx:x?Eg:
Ifx;y?Ethen for any linear combination x+y?E(can you see
why?). Therefore E?is a subspace.
By the denition of orthogonal projection any vector in an inner product
spaceVadmits a unique representation
v=v1+v2; v12E;v2?E(eqv. v22E?)
(where clearly v1=PEv).
This statement is often symbolically written as V=EE?, which
mean exactly that any vector admits the unique decomposition above.
The following proposition gives an important property of the orthogonal
complement.
Proposition 3.6. For a subspace E
(E?)?=E:
The proof is left as an exercise, see Exercise 3.12 below.
Exercises.
3.1. Apply Gram{Schmidt orthogonalization to the system of vectors (1 ;2; 2)T,
(1; 1;4)T, (2;1;1)T.
3.2. Apply Gram{Schmidt orthogonalization to the system of vectors (1 ;2;3)T,
(1;3;1)T. Write the matrix of the orthogonal projection onto 2-dimensional sub-
space spanned by these vectors.
134 5. Inner product spaces
3.3. Complete an orthogonal system obtained in the previous problem to an or-
thogonal basis in R3, i.e. add to the system some vectors (how many?) to get an
orthogonal basis.
Can you describe how to complete an orthogonal system to an orthogonal basis
in general situation of RnorCn?
3.4. Find the distance from a vector (2 ;3;1)Tto the subspace spanned by the
vectors (1;2;3)T, (1;3;1)T. Note, that I am only asking to nd the distance to the
subspace, not the orthogonal projection.
3.5. Find the orthogonal projection of a vector (1 ;1;1;1)Tonto the subspace
spanned by the vectors v1= (1;3;1;1)Tandv2= (2; 1;1;0)T(note that v1?v2).
3.6. Find the distance from a vector (1 ;2;3;4) to the subspace spanned by the
vectors v1= (1; 1;1;0)Tandv2= (1;2;1;1)T(note that v1?v2). Can you nd
the distance without actually computing the projection? That would simplify the
calculations.
3.7. True or false: if Eis a subspace of V, then dimE+dim(E?) = dimV? Justify.
3.8. LetPbe the orthogonal projection onto a subspace Eof an inner product space
V, dimV=n, dimE=r. Find the eigenvalues and the eigenvectors (eigenspaces).
Find the algebraic and geometric multiplicities of each eigenvalue.
3.9. (Using eigenvalues to compute determinants).
a) Find the matrix of the orthogonal projection onto the one-dimensional
subspace in Rnspanned by the vector (1 ;1;:::; 1)T;
b) LetAbe thennmatrix with all entries equal 1. Compute its eigenvalues
and their multiplicities (use the previous problem);
c) Compute eigenvalues (and multiplicities) of the matrix A I, i.e. of the
matrix with zeroes on the main diagonal and ones everywhere else;
d) Compute det( A I).
3.10 (Legendre's polynomials:) .Let an inner product on the space of polynomials
be dened by ( f;g) =R1
 1f(t)g(t)dt. Apply Gram-Schmidt orthogonalization to
the system 1 ;t;t2;t3.
Legendre's polynomials are particular case of the so-called orthogonal polyno-
mials, which play an important role in many branches of mathematics.
3.11. LetP=PEbe the matrix of an orthogonal projection onto a subspace E.
Show that
a) The matrix Pisself-adjoint , meaning that P=P.
b)P2=P.
Remark: The above 2 properties completely characterize orthogonal projection,
i.e. any matrix Psatisfying these properties is the matrix of some orthogonal pro-
jection. We will discuss this some time later.
3. Orthogonal projection and Gram-Schmidt orthogonalization 135
3.12. Show that for a subspace Ewe have (E?)?=E.Hint: It is easy to see
thatEis orthogonal to E?(why?). To show that anyvector xorthogonal to E?
belongs toEuse the decomposition V=EE?from Section 3.3 above.
3.13. SupposePis the orthogonal projection onto a subspace E, andQis the
orthogonal projection onto the orthogonal complement E?.
a) What are P+QandPQ?
b) Show that P Qis its own inverse.
136 5. Inner product spaces
4. Least square solution. Formula for the orthogonal
projection
As it was discussed before in Chapter 2, the equation
Ax=b
has a solution if and only if b2RanA. But what do we do to solve an
equation that does not have a solution?
This seems to be a silly question, because if there is no solution, then
there is no solution. But, situations when we want to solve an equation that
does not have a solution can appear naturally, for example, if we obtained
the equation from an experiment. If we do not have any errors, the right side
bbelongs to the column space Ran A, and equation is consistent. But, in
real life it is impossible to avoid errors in measurements, so it is possible that
an equation that in theory should be consistent, does not have a solution.
So, what can one do in this situation?
4.1. Least square solution. The simplest idea is to write down the error
kAx bk
and try to nd xminimizing it. If we can nd xsuch that the error is 0,
the system is consistent and we have exact solution. Otherwise, we get the
so-called least square solution.
The term least square arises from the fact that minimizing kAx bkis
equivalent to minimizing
kAx bk2=mX
k=1j(Ax)k bkj2=mX
k=1nX
j=1Ak;jxj bk2
i.e. to minimizing the sum of squares of linear functions.
There are several ways to nd the least square solution. If we are in
Rn, and everything is real, we can forget about absolute values. Then we
can just take partial derivatives with respect to xjand nd the where all of
them are 0, which gives us the minimum.
4.1.1. Geometric approach. However, there is a simpler way of nding the
minimum. Namely, if we take all possible vectors x, thenAxgives us all
possible vectors in Ran A, so minimum ofkAx bkis exactly the distance
frombto RanA. Therefore the value of kAx bkis minimal if and only if
Ax=PRanAb, wherePRanAstands for the orthogonal projection onto the
column space Ran A.
So, to nd the least square solution we simply need to solve the equation
Ax=PRanAb:
4. Least square solution. Formula for the orthogonal projection 137
If we know an orthogonal basis v1;v2;:::;vnin RanA, we can nd vector
PRanAbby the formula
PRanAb=nX
k=1(b;vk)
kvkk2vk:
If we only know a basis in Ran A, we need to use the Gram{Schmidt orthog-
onalization to obtain an orthogonal basis from it.
So, theoretically, the problem is solved, but the solution is not very
simple: it involves Gram{Schmidt orthogonalization, which can be compu-
tationally intensive. Fortunately, there exists a simpler solution.
4.1.2. Normal equation. Namely,Axis the orthogonal projection PRanAb
if and only if b Ax?RanA(Ax2RanAfor all x).
Ifa1;a2;:::;anare columns of A, then the condition Ax?RanAcan
be rewritten as
b Ax?ak;8k= 1;2;:::;n:
That means
0 = (b Ax;ak) =a
k(b Ax)8k= 1;2;:::;n:
Joining rows a
ktogether we get that these equations are equivalent to
A(b Ax) =0;
which in turn is equivalent to the so-called normal equation
AAx=Ab:
A solution of this equation gives us the least square solution of Ax=b.
Note, that the least square solution is unique if and only if AAis
invertible.
4.2. Formula for the orthogonal projection. As we already discussed
above, if xis a solution of the normal equation AAx=Ab(i.e. a least
square solution of Ax=b), thenAx=PRanAb. So, to nd the orthogonal
projection of bonto the column space Ran Awe need to solve the normal
equationAAx=Ab, and then multiply the solution by A.
If the operator AAis invertible, the solution of the normal equation
AAx=Abis given by x= (AA) 1Ab, so the orthogonal projection
PRanAbcan be computed as
PRanAb=A(AA) 1Ab:
Since this is true for all b,
PRanA=A(AA) 1A
is the formula for the matrix of the orthogonal projection onto Ran A.
138 5. Inner product spaces
The following theorem implies that for an mnmatrixAthe matrix
AAis invertible if and only if rank A=n.
Theorem 4.1. For anmnmatrixA
KerA= Ker(AA):
Indeed, according to the rank theorem Ker A=f0gif and only if rank
Aisn. Therefore Ker( AA) =f0gif and only if rank A=n. Since the
matrixAAis square, it is invertible if and only if rank A=n.
We leave the proof of the theorem as an exercise. To prove the equality
KerA= Ker(AA) one needs to prove two inclusions Ker( AA)KerA
and KerAKer(AA). One of the inclusions is trivial, for the other one
use the fact that
kAxk2= (Ax;Ax) = (AAx;x):
4.3. An example: line tting. Let us introduce a few examples where
the least square solution appears naturally. Suppose that we know that two
quantitiesxandyare related by the law y=a+bx. The coecients aand
bare unknown, and we would like to nd them from experimental data.
Suppose we run the experiment ntimes, and we get npairs (xk;yk),
k= 1;2;:::;n . Ideally, all the points ( xk;yk) should be on a straight line,
but because of errors in measurements, it usually does not happen: the point
are usually close to some line, but not exactly on it. That is where the least
square solution helps!
Ideally, the coecients aandbshould satisfy the equations
a+bxk=yk; k = 1;2;:::;n
(note that here, xkandykare some xed numbers, and the unknowns are
aandb). If it is possible to nd such aandbwe are lucky. If not, the
standard thing to do is to minimize the total quadratic error
nX
k=1ja+bxk ykj2:
But, minimizing this error is exactly nding the least square solution of the
system0
BBB@1x1
1x2
......
1xn1
CCCAa
b
=0
BBB@y1
y2
...
yn1
CCCA
(recall that xkykare some given numbers, and the unknowns are aandb).
4. Least square solution. Formula for the orthogonal projection 139
4.3.1. An example. Suppose our data ( xk;yk) consist of pairs
( 2;4);( 1;2);(0;1);(2;1);(3;1):
Then we need to nd the least square solution of
0
BBBB@1 2
1 1
1 0
1 2
1 31
CCCCAa
b
=0
BBBB@4
2
1
1
11
CCCCA
Then
AA=1 1 1 1 1
 2 1 0 2 30
BBBB@1 2
1 1
1 0
1 2
1 31
CCCCA=5 2
2 18
and
Ab=1 1 1 1 1
 2 1 0 2 30
BBBB@4
2
1
1
11
CCCCA=9
 5
so the normal equation AAx=Abis rewritten as
5 2
2 18a
b
=9
 5
:
The solution of this equation is
a= 2;b= 1=2;
so the best tting straight line is
y= 2 1=2x:
4.4. Other examples: curves and planes. The least square method is
not limited to the line tting. It can also be applied to more general curves,
as well as to surfaces in higher dimensions.
The only constraint here is that the parameters we want to nd be
involved linearly. The general algorithm is as follows:
1. Find the equations that your data should satisfy if there is exact t;
2. Write these equations as a linear system, where unknowns are the
parameters you want to nd. Note, that the system need not to be
consistent (and usually is not);
3. Find the least square solution of the system.
140 5. Inner product spaces
4.4.1. An example: curve tting. For example, suppose we know that the
relation between xandyis given by the quadratic law y=a+bx+cx2, so
we want to t a parabola y=a+bx+cx2to the data. Then our unknowns
a,b,cshould satisfy the equations
a+bxk+cx2
k=yk; k = 1;2;:::;n
or, in matrix form
0
BBB@1x1x2
1
1x2x2
2.........
1xnx2
n1
CCCA0
@a
b
c1
A=0
BBB@y1
y2
...
yn1
CCCA
For example, for the data from the previous example we need to nd the
least square solution of
0
BBBB@1 2 4
1 1 1
1 0 0
1 2 4
1 3 91
CCCCA0
@a
b
c1
A=0
BBBB@4
2
1
1
11
CCCCA:
Then
AA=0
@1 1 1 1 1
 2 1 0 2 3
4 1 0 4 91
A0
BBBB@1 2 4
1 1 1
1 0 0
1 2 4
1 3 91
CCCCA=0
@5 2 18
2 18 26
18 26 1141
A
and
Ab=0
@1 1 1 1 1
 2 1 0 2 3
4 1 0 4 91
A0
BBBB@4
2
1
1
11
CCCCA=0
@9
 5
311
A:
Therefore the normal equation AAx=Abis
0
@5 2 18
2 18 26
18 26 1141
A0
@a
b
c1
A=0
@9
 5
311
A
which has the unique solution
a= 86=77; b = 62=77; c = 43=154:
Therefore,
y= 86=77 62x=77 + 43x2=154
is the best tting parabola.
4. Least square solution. Formula for the orthogonal projection 141
4.4.2. Plane tting. As another example, let us t a plane z=a+bx+cy
to the data
(xk;yk;zk)2R3; k = 1;2;:::n:
The equations we should have in the case of exact t are
a+bxk+cyk=zk; k = 1;2;:::;n;
or, in the matrix form
0
BBB@1x1y1
1x2y2
.........
1xnyn1
CCCA0
@a
b
c1
A=0
BBB@z1
z2
...
zn1
CCCA:
So, to nd the best tting plane, we need to nd the best square solution of
this system (the unknowns are a,b,c).
Exercises.
4.1. Find the least square solution of the system
0
@1 0
0 1
1 11
Ax=0
@1
1
01
A
4.2. Find the matrix of the orthogonal projection Ponto the column space of
0
@1 1
2 1
 2 41
A:
Use two methods: Gram{Schmidt orthogonalization and formula for the projection.
Compare the results.
4.3. Find the best straight line t (least square solution) to the points (  2;4),
( 1;3), (0;1), (2;0).
4.4. Fit a plane z=a+bx+cyto four points (1 ;1;3), (0;3;6), (2;1;5), (0;0;0).
To do that
a) Find 4 equations with 3 unknowns a;b;c such that the plane pass through
all 4 points (this system does not have to have a solution);
b) Find the least square solution of the system.
4.5. Minimal norm solution. let an equation Ax=bhas a solution, and let Ahas
non-trivial kernel (so the solution is not unique). Prove that
a) There exist a unique solution x0ofAx=bminimizing the norm kxk,
i.e. that there exists unique x0such thatAx0=bandkx0kkxkfor any
xsatisfyingAx=b.
b)x0=P(KerA)?xfor any xsatisfyingAx=b.
142 5. Inner product spaces
4.6. Minimal norm least square solution. Applying previous problem to the equa-
tionAx=PRanAbshow that
a) There exists a unique least square solution x0ofAx=bminimizing the
normkxk.
b)x0=P(KerA)?xfor any least square solution xofAx=b.
5. Adjoint of a linear transformation. Fundamental
subspaces revisited.
5.1. Adjoint matrices and adjoint operators. Let as recall that for an
mnmatrixAitsHermitian adjoint (or simply adjoint )Ais dened by
A:=AT. In other words, the matrix Ais obtained from the transposed
matrixATby taking complex conjugate of each entry.
The following identity is the main property of adjoint matrix:
(Ax;y) = (x;Ay)8x2Cn;8y2Cm:
Before proving this identity, let us introduce some useful formulas. Let us
recall that for transposed matrices we have the identity ( AB)T=BTAT.
Since for complex numbers zandwwe havezw=zw, the identity
(AB)=BA
holds for the adjoint.
Also, since ( AT)T=Aandz=z,
(A)=A:
Now, we are ready to prove the main identity:
(Ax;y) =yAx= (Ay)x= (x;Ay);
the rst and the last equalities here follow from the denition of inner prod-
uct in Fn, and the middle one follows from the fact that
(Ax)=x(A)=xA:
5.1.1. Uniqueness of the adjoint. The above main identity ( Ax;y)
= (x;Ay) is often used as the denition of the adjoint operator. Let us
rst notice that the adjoint operator is unique: if a matrix Bsatises
(Ax;y) = (x;By)8x;y;
thenB=A. Indeed, by the denition of Afor a given ywe have
(x;Ay) = (x;By)8x;
and therefore by Corollary 1.5 Ay=By. Since it is true for all y, the
linear transformations, and therefore the matrices AandBcoincide.
5. Adjoint of a linear transformation 143
5.1.2. Adjoint transformation in abstract setting. The above main identity
(Ax;y) = (x;Ay) can be used to dene the adjoint operator in abstract
setting, where A:V!Wis an operator acting from one inner product
space to another. Namely, we dene A:W!Vto be the operator
satisfying
(Ax;y) = (x;Ay)8x2V;8y2W:
Why does such an operator exists? We can simply construct it: consider
orthonormal bases A=v1;v2;:::;vninVandB=w1;w2;:::;wminW.
If [A]BAis the matrix of Awith respect to these bases, we dene the operator
Aby dening its matrix [ A]ABas
[A]AB= ([A]BA):
We leave the proof that this indeed gives the adjoint operator as an exercise
for the reader.
Note, that the reasoning in the above Sect. 5.1.1 implies that the adjoint
operator is unique.
5.1.3. Useful formulas. Below we present the properties of the adjoint op-
erators (matrices) we will use a lot. We leave the proofs as an exercise for
the reader.
1. (A+B)=A+B;
2. (A)=A;
3. (AB)=BA;
4. (A)=A;
5. (y;Ax) = (Ay;x).
5.2. Relation between fundamental subspaces.
Theorem 5.1. LetA:V!Wbe an operator acting from one inner product
space to another. Then
1. KerA= (RanA)?;
2. KerA= (RanA)?;
3. RanA= (KerA)?;
4. RanA= (KerA)?.
Remark. Earlier in Section 7 of Chapter 2 the fundamental subspaces were
dened (as it is often done in the literature) using ATinstead ofA. Of
course, there is no dierence for real matrices, so in the real case the above
theorem gives the geometric description of the fundamentals subspaces de-
ned there.
Geometric interpretation of the fundamental subspaces dened using AT
is presented in Chapter 8 below, see Section 3 there (Theorem 3.7). The
144 5. Inner product spaces
formulas in this theorem are essentially the same as in Theorem 5.1 here,
only the interpretation is a bit dierent.
Proof of Theorem 5.1. First of all, let us notice, that since for a subspace
Ewe have (E?)?=E, the statements 1 and 3 are equivalent. Similarly,
for the same reason, the statements 2 and 4 are equivalent as well. Finally,
statement 2 is exactly statement 1 applied to the operator A(here we use
the fact that ( A)=A).
So, to prove the theorem we only need to prove statement 1.
We will present 2 proofs of this statement: a \matrix" proof, and an
\invariant", or \coordinate-free" one.
In the \matrix" proof, we assume that Ais anmnmatrix, i.e. that
A:Fn!Fm. The general case can be always reduced to this one by
picking orthonormal bases in VandW, and considering the matrix of Ain
this bases.
Leta1;a2;:::;anbe the columns of A. Note, that x2(RanA)?if and
only if x?ak(i.e. (x;ak) = 0)8k= 1;2;:::;n .
By the denition of the inner product in Fn, that means
0 = (x;ak) =a
kx8k= 1;2;:::;n:
Since a
kis the row number kofA, the above nequalities are equivalent to
the equation
Ax=0:
So, we proved that x2(RanA)?if and only if Ax=0, and that is exactly
the statement 1.
Now, let us present the \coordinate-free" proof. The inclusion x2
(RanA)?means that xis orthogonal to all vectors of the form Ay, i.e. that
(x;Ay) = 08y:
Since ( x;Ay) = (Ax;y), this identity is equivalent to
(Ax;y) = 08y;
and by Lemma 1.4 this happens if and only if Ax=0. So we proved that
x2(RanA)?if and only if Ax=0, which is exactly the statement 1 of
the theorem. 
5.3. The \essential" part of a linear transformation. The above the-
orem makes the structure of the operator Aand the geometry of fundamental
subspaces much more transparent. It follows from this theorem that the op-
eratorAcan be represented as a composition of orthogonal projection onto
RanAand an isomorphism from Ran Ato RanA.
5. Adjoint of a linear transformation 145
Indeed, leteA: RanA!RanAbe the restriction of Ato the domain
RanAand the target space Ran A,
eAx=Ax;8x2RanA:
Since KerA= (RanA)?, we have
Ax=APRanAx=eAPRanAx8x2X;
the fact that x PRanAx2(RanA)?= KerAis used here. Therefore we
can write
Ax=eAPRanAx8x2X; (5.1)
or, equivalently, A=eAPRanA.
Note also that eA: RanA!RanAis an invertible transformation.
First we notice that Ker eA=f0g: ifx2RanAis such thateAx=Ax=0,
thenx2KerA= (RanA)?, sox2RanA\(RanA)?, thus x=0. Then
to see thateAis invertible, it is sucient to she that eAis onto (surjective).
But this immediately follows from (5.1):
RaneA=eARanA=APRanAX=AX= RanA:
The isomorphism eAis sometimes called the \essential part" of the op-
eratorA(a non-standard terminology).
The fact the \essential part" eA: RanA!RanAofAis an isomor-
phism implies the following \complex" rank theorem: rank A= rankA.
But, of course, this theorem also follows from an elementary observation that
complex conjugation does not change rank of a matrix, rank A= rankA.
Exercises.
5.1. Show that for a square matrix Athe equality det( A) =det(A) holds.
5.2. Find matrices of orthogonal projections onto all 4 fundamental subspaces of
the matrix
A=0
@1 1 1
1 3 2
2 4 31
A:
Note, that really you need only to compute 2 of the projections. If you pick an
appropriate 2, the other 2 are easy to obtain from them (recall, how the projections
ontoEandE?are related).
5.3. LetAbe anmnmatrix. Show that Ker A= Ker(AA).
To do that you need to prove 2 inclusions, Ker( AA)KerAand KerA
Ker(AA). One of the inclusions is trivial, for the other one use the fact that
kAxk2= (Ax;Ax) = (AAx;x):
5.4. Use the equality Ker A= Ker(AA) to prove that
146 5. Inner product spaces
a) rankA= rank(AA);
b) IfAx=0has only the trivial solution, Ais left invertible. (You can just
write a formula for a left inverse).
5.5. Suppose, that for a matrix Athe matrix AAis invertible, so the orthogonal
projection onto Ran Ais given by the formula A(AA) 1A. Can you write formulas
for the orthogonal projections onto the other 3 fundamental subspaces (Ker A,
KerA, RanA)?
5.6. Let a matrix Pbe self-adjoint ( P=P) and letP2=P. Show that Pis the
matrix of an orthogonal projection. Hint: consider the decomposition x=x1+x2,
x12RanP,x2?RanPand show that Px1=x1,Px2=0. For one of the
equalities you will need self-adjointness, for the other one the property P2=P.
6. Isometries and unitary operators. Unitary and orthogonal
matrices.
6.1. Main denitions.
Denition. An operator U:X!Yis called an isometry , if it preserves
the norm,
kUxk=kxk 8 x2X:
The following theorem shows that an isometry preserves the inner prod-
uct
Theorem 6.1. An operator U:X!Yis an isometry if and only if it
preserves the inner product, i.e if and only if
(x;y) = (Ux;Uy)8x;y2X:
Proof. The proof uses the polarization identities (Lemma 1.9). For exam-
ple, ifXis a complex space
(Ux;Uy) =1
4X
=1;ikUx+Uyk2
=1
4X
=1;ikU(x+y)k2
=1
4X
=1;ikx+yk2= (x;y):
6. Isometries and unitary operators. Unitary and orthogonal matrices. 147
Similarly, for a real space X
(Ux;Uy) =1
4 
kUx+Uyk2 kUx Uyk2
=1
4 
kU(x+y)k2 kU(x y)k2
=1
4 
kx+yk2 kx yk2
= (x;y):

Lemma 6.2. An operator U:X!Yis an isometry if and only if UU=I.
Proof. IfUU=I, then by the denition of adjoint operator
(x;x) = (UUx;x) = (Ux;Ux)8x2X:
Thereforekxk=kUxk, and soUis an isometry.
On the other hand, if Uis an isometry, then by the denition of adjoint
operator and by Theorem 6.1 we have for all x2X
(UUx;y) = (Ux;Uy) = (x;y)8y2X;
and therefore by Corollary 1.5 UUx=x. Since it is true for all x2X, we
haveUU=I. 
The above lemma implies that an isometry is always left invertible ( U
being a left inverse).
Denition. An isometry U:X!Yis called a unitary operator if it is
invertible.
Proposition 6.3. An isometry U:X!Yis a unitary operator if and
only if dimX= dimY.
Proof. SinceUis an isometry, it is left invertible, and since dim X= dimY,
it is invertible (a left invertible square matrix is invertible).
On the other hand, if U:X!Yis invertible, dim X= dimY(only
square matrices are invertible, isomorphic spaces have equal dimensions).

A square matrix Uis called unitary ifUU=I, i.e. a unitary matrix is
a matrix of a unitary operator acting in Fn.
A unitary matrix with real entries is called an orthogonal matrix. An
orthogonal matrix can be interpreted a matrix of a unitary operator acting
in the real space Rn.
Few properties of unitary operators:
1. For a unitary transformation U,U 1=U;
148 5. Inner product spaces
2. IfUis unitary,U=U 1is also unitary;
3. IfUis a isometry, and v1;v2;:::;vnis an orthonormal basis, then
Uv1;Uv2;:::;U vnis an orthonormal system. Moreover, if Uis
unitary,Uv1;Uv2;:::;U vnis an orthonormal basis.
4. A product of unitary operators is a unitary operator as well.
6.2. Examples. First of all, let us notice, that
a matrixUis an isometry if and only if its columns form an or-
thonormal system.
This statement can be checked directly by computing the product UU.
It is easy to check that the columns of the rotation matrix
cos sin
sincos
are orthogonal to each other, and that each column has norm 1. Therefore,
the rotation matrix is an isometry, and since it is square, it is unitary. Since
all entries of the rotation matrix are real, it is an orthogonal matrix.
The next example is more abstract. Let XandYbe inner product
spaces, dim X= dimY=n, and let x1;x2;:::;xnandy1;y2;:::;ynbe
orthonormal bases in XandYrespectively. Dene an operator U:X!Y
by
Uxk=yk; k = 1;2;:::;n:
Since for a vector x=c1x1+c2x2+:::+cnxn
kxk2=jc1j2+jc2j2+:::+jcnj2
and
kUxk2=kU(nX
k=1ckxk)k2=knX
k=1ckykk2=nX
k=1jckj2;
one can conclude that kUxk=kxkfor all x2X, soUis a unitary operator.
6.3. Properties of unitary operators.
Proposition 6.4. LetUbe a unitary matrix. Then
1.jdetUj= 1. In particular, for an orthogonal matrix detU=1;
2.Ifis an eigenvalue of U, thenjj= 1
Remark. Note, that for an orthogonal matrix, an eigenvalue (unlike the
determinant) does not have to be real. Our old friend, the rotation matrix
gives an example.
6. Isometries and unitary operators. Unitary and orthogonal matrices. 149
Proof of Proposition 6.4. Let detU=z. Since det( U) =det(U), see
Problem 5.1, we have
jzj2=zz= det(UU) = detI= 1;
sojdetUj=jzj= 1. Statement 1 is proved.
To prove statement 2 let us notice that if Ux=xthen
kUxk=kxk=jjkxk;
sojj= 1. 
6.4. Unitary equivalent operators.
Denition. Operators (matrices) AandBare called unitarily equivalent if
there exists a unitary operator Usuch thatA=UBU.
Since for a unitary Uwe haveU 1=U, any two unitary equivalent
matrices are similar as well.
The converse is not true, it is easy to construct a pair of similar matrices,
which are not unitarily equivalent.
The following proposition gives a way to construct a counterexample.
Proposition 6.5. A matrixAis unitarily equivalent to a diagonal one if
and only if it has an orthogonal (orthonormal) basis of eigenvectors.
Proof. LetA=UBUand letBx=x. ThenAUx=UBUUx=
UBx=U(x) =Ux, i.e.Uxis an eigenvector of A.
So, letAbe unitarily equivalent to a diagonal matrix D, i.e. letA=
UDU. The vectors ekof the standard basis are eigenvectors of D, so
the vectors Uekare eigenvectors of A. SinceUis unitary, the system
Ue1;Ue2;:::;U enis an orthonormal basis.
Now letAhas an orthogonal basis u1;u2;:::;unof eigenvectors. Divid-
ing each vector ukby its norm if necessary, we can always assume that the
system u1;u2;:::;unis an orthonormal basis. LetDbe the matrix of Ain
the basisB=u1;u2;:::;un. Clearly,Dis a diagonal matrix.
Denote byUthe matrix with columns u1;u2;:::;un. Since the columns
form an orthonormal basis, Uis unitary. The standard change of coordinate
formula implies
A= [A]SS= [I]SB[A]BB[I]BS=UDU 1
and sinceUis unitary,A=UDU. 
150 5. Inner product spaces
Exercises.
6.1. Orthogonally diagonalize the following matrices,
1 2
2 1
;0 1
1 0
;0
@0 2 2
2 0 2
2 2 01
A
i.e. for each matrix And a unitary matrix Uand a diagonal matrix Dsuch that
A=UDU
6.2. True or false: a matrix is unitarily equivalent to a diagonal one if and only if
it has an orthogonal basis of eigenvectors.
6.3. Prove the polarization identities
(Ax;y) =1
4
(A(x+y);x+y) (A(x y);x y)
(real case,A=A);
and
(Ax;y) =1
4X
=1;i(A(x+y);x+y) (complex case, Ais arbitrary) :
6.4. Show that a product of unitary (orthogonal) matrices is unitary (orthogonal)
as well.
6.5. LetU:X!Xbe a linear transformation on a nite-dimensional inner
product space. True or false:
a) IfkUxk=kxkfor all x2X, thenUis unitary.
b) IfkUekk=kekk,k= 1;2:::;n for some orthonormal basis e1;e2;:::;en,
thenUis unitary.
Justify your answers with a proof or a counterexample.
6.6. LetAandBbe unitarily equivalent nnmatrices.
a) Prove that trace( AA) = trace(BB).
b) Use a) to prove that
nX
j;k=1jAj;kj2=nX
j;k=1jBj;kj2:
c) Use b) to prove that the matrices
1 2
2i
andi4
1 1
are not unitarily equivalent.
6.7. Which of the following pairs of matrices are unitarily equivalent:
a)1 0
0 1
and0 1
1 0
.
b)0 1
1 0
and0 1=2
1=2 0
.
7. Rigid motions in Rn151
c)0
@0 1 0
 1 0 0
0 0 11
Aand0
@2 0 0
0 1 0
0 0 01
A.
d)0
@0 1 0
 1 0 0
0 0 11
Aand0
@1 0 0
0 i0
0 0i1
A.
e)0
@1 1 0
0 2 2
0 0 31
Aand0
@1 0 0
0 2 0
0 0 31
A.
Hint: It is easy to eliminate matrices that are not unitarily equivalent: remember,
that unitarily equivalent matrices are similar, and trace, determinant and eigenval-
ues of similar matrices coincide.
Also, the previous problem helps in eliminating non unitarily equivalent matri-
ces.
Finally, a matrix is unitarily equivalent to a diagonal one if and only if it has
an orthogonal basis of eigenvectors.
6.8. LetUbe a 22 orthogonal matrix with det U= 1. Prove that Uis a rotation
matrix.
6.9. LetUbe a 33 orthogonal matrix with det U= 1. Prove that
a) 1 is an eigenvalue of U.
b) If v1;v2;v3is an orthonormal basis, such that Uv1=v1(remember, that
1 is an eigenvalue), then in this basis the matrix of Uis
0
@1 0 0
0 cos sin
0 sin cos1
A;
whereis some angle.
Hint: Show, that since v1is an eigenvector of U, all entries below 1
must be zero, and since v1is also an eigenvector of U(why?), all entries
right of 1 also must be zero. Then show that the lower right 2 2 matrix
is an orthogonal one with determinant 1, and use the previous problem.
7. Rigid motions in Rn
A rigid motion in an inner product space Vis a transformation f:V!V
preserving the distance between point, i.e. such that
kf(x) f(y)k=kx yk 8 x;y2V:
Note, that in the denition we do not assume that the transformation fis
linear.
Clearly, any unitary transformation is a rigid motion. Another example
of a rigid motion is a translation (shift) by a2V,f(x) =x+a.
152 5. Inner product spaces
The main result of this section is the following theorem, stating that any
rigid motion in a realinner product space is a composition of an orthogonal
transformation and a translation.
Theorem 7.1. Letfbe a rigid motion in a real inner product space X, and
letT(x) :=f(x) f(0). ThenTis an orthogonal transformation.
To prove this theorem we need the following simple lemma.
Lemma 7.2. LetTbe as dened in Theorem 7.1. Then for all x;y2X
1.kTxk=kxk;
2.kT(x) T(y)k=kx yk;
3. (T(x);T(y)) = ( x;y).
Proof. To prove statement 1 notice that
kT(x)k=kf(x) f(0)k=kx 0k=kxk:
Statement 2 follows from the following chain of identities:
kT(x) T(y)k=k(f(x) f(0)) (f(y) f(0))k
=kf(x) f(y)k=kx yk:
An alternative explanation would that Tis a composition of 2 rigid
motions (ffollowed by the translation by a= f(0)), and one can easily
see that a composition of rigid motions is a rigid motion. Since T(0) =0,
and sokT(x)k=kT(x) T(0)k, statement 1 can be treated as a particular
case of statement 2.
To prove statement 3, let us notice that in a real inner product space
kT(x) T(y)k2=kT(x)k2+kT(y)k2 2(T(x);T(y));
and
kx yk2=kxk2+kyk2 2(x;y):
Recalling thatkT(x) T(y)k=kx ykandkT(x)k=kxk,kT(y)k=kyk,
we immediately get the desired conclusion. 
Proof of Theorem 7.1. First of all notice that for all x2X
kT(x)k=kf(x) f(0)k=kx 0k=kxk;
soTpreserves the norm, kTxk=kxk.
We would like to say that the identyty kTxk=kxkmeansTis an
isometry, but to be able to say that we need to prove that Tis a linear
transformation.
To do that, let us x an orthonormal basis e1;e2;:::;eninX, and let
bk:=T(ek),k= 1;2;:::;n . SinceTpreserves the inner product (statement
7. Rigid motions in Rn153
3 of Lemma 7.2), we can conclude that b1;b2;:::;bnis an orthonormal
system. In fact, since dim X=n(because basis e1;e2;:::;enconsists ofn
vectors), we can conclude that b1;b2;:::;bnis an orthonormal basis.
Letx=Pn
k=1kek. Recall that by the abstract orthogonal Fourier
decomposition (2.2) we have that k= (x;ek). Applying the abstract or-
thogonal Fourier decomposition (2.2) to T(x) and the orthonormal basis
b1;b2;:::;bnwe get
T(x) =nX
k=1(T(x);bk)bk:
Since
(T(x);bk) = (T(x);T(ek)) = ( x;ek) =k;
we get that
TnX
k=1kek
=nX
k=1kbk:
This means that Tis a linear transformation whose matrix with respect
to the basesS:=e1;e2;:::;enandB:=b1;b2;:::;bnis identity matrix,
[T]B;S=I.
An alternative way to show that Tis a linear transformation is the
following direct calculation
kT(x+y) (T(x) +T(y))k2=k(T(x+y) T(x)) T(y)k2
=kT(x+y) T(x)k2+2kT(y)k2 2(T(x+y) T(x);T(y))
=kx+y xk2+2kyk2 2(T(x+y);T(y)) + 2(T(x);T(y))
=2kyk2+2kyk2 2(x+y;y) + 2(x;y)
= 22kyk2 2(x;y) 22(y;y) + 2(x;y) = 0
Therefore
T(x y) =T(x) +T(y);
which implies that Tis linear (taking x=0or= 1 we get two properties
from the denition of a linear transformation).
So,Tis a linear transformation satisfying kTxk=kxk, i.e.Tis an
isometry. Since T:X!X,Tis unitary transformation (see Proposition
6.3). That completes the proof, since an orthogonal transformation is simply
a unitary transformation in a real inner product space. 
Exercises.
7.1. Give an example of a rigid motion TinCn,T(0) =0, which is not a linear
transformation.
154 5. Inner product spaces
8. Complexication and decomplexication
This section is probably a bit more abstract than the rest of the chapter,
and can be skipped at the rst reading.
8.1. Decomplexication.
8.1.1. Decomplexication of a vector space. Any complex vector space can
be interpreted a real vector space: we just need to forget that we can multiply
vectors by complex numbers and act as only multiplication by real numbers
is allowed.
For example, the space Cniscanonically identied with the real space
R2n: each complex coordinate zk=xk+iykgives us 2 real ones xkandyk.
\Canonically" here means that this is a standard, most natural way of
identifying CnandR2n. Note, that while the above denition gives us a
canonical way to get real coordinates from complex ones, it does not say
anything about ordering real coordinates.
In fact, there are two standard ways to order the coordinates xk,yk.
One way is to take rst the real parts and then the imaginary parts, so the
ordering is x1;x2;:::;xn;y1;y2;:::;yn. The other standard alternative is
the ordering x1;y1;x2;y2;:::;xn;yn. The material of this section does not
depend on the choice of ordering of coordinates, so the reader does not have
to worry about picking an ordering.
8.1.2. Decomplexication of an inner product. It turns out that if we are
given a complex inner product (in a complex space), we can in a canonical
way get a real inner product from it. To see how we can do that, let as
rst consider the above example of Cncanonically identies with R2n. Let
(x;y)Cdenote the standard inner product in Cn, and ( x;y)Rbe the standard
inner product in R2n(note that the standard inner product in Rndoes not
depend on the ordering of coordinates). Then (see Exercise 8.1 below)
(8.1) ( x;y)R= Re( x;y)C
This formula can be used to canonically dene a real inner product from
the complex one in general situation. Namely, it is an easy exercise to show
that if ( x;y)Cis an inner product in a complex inner product space, then
(x;y)Rdened by (8.1) is a real inner product (on the corresponding real
space).
Summarizing we can say that
To decomplexify a complex inner product space we simply \for-
get" that we can multiply by complex numbers, i.e. we only allow
multiplication by reals. The canonical real inner product in the
decomplexied space is given by formula (8.1)
8. Complexication and decomplexication 155
Remark. Any (complex) linear linear transformation on Cn(or, more gen-
erally, on a complex vector space) gives as a real linear transformation: it is
simply the fact that if T(x+y) =Tx+Tyholds for;2C, then
it of course holds for ;2R.
The converse is not true, i.e. a (real) linear transformation on the de-
complexication R2nofCndoes not always give a (complex) linear trans-
formation of Cn(the same in the abstract settings).
For example, if one considers the case n= 1, then the multiplication by a
complex number z(general form of a linear transformation in C1) treated as
a linear transformation in R2has a very specic structure (can you describe
it?).
8.2. Complexication. We can also do a converse, namely get a complex
inner product space from a real one: in fact, you probably already did it
before, without paying much attention to it.
Namely, given a real inner product space Rnwe can obtain a complex
spaceCnout of it by allowing complex coordinates (with the standard inner
product in both cases). The space Rnin this case will be a real2subspace of
Cnconsisting of vectors with real coordinates.
Abstractly, this construction can be described as follows: given a real
vector space Xwe can dene its complexication XCas the collection of
all pairs [ x1;x2],x1;x22Xwith the addition and multiplication by a real
numberare dened coordinate-wise,
[x1;x2] + [y1;y2] = [x1+y1;x2+y2];  [x1;x2] = [x1;x2]:
IfX=Rnthen the vector x1consists of real parts of complex coordinates
ofCnand the vector x2of the imaginary parts. Thus informally one can
write the pair [ x1;x2] asx1+ix2.
To dene multiplication by complex numbers we dene multiplication
byias
i[x1;x2] = [ x2;x1]
(writing [ x1;x2] asx2+ix2we can see that it must be dened this way) and
dene multiplication by arbitrary complex numbers using second distributive
property (+)v=v+v.
If, in addition, Xis an inner product space we can extend the inner
product to XCby
 
[x1;x2];[y1;y2]
XC= (x1;y1)X+ (x2;y2)X;
The easiest way to see that everything is well dened, is to x a basis (an
orthonormal basis in the case of a real inner product space) and see what
2Real subspace mean the set closed with respect to sum and multiplication by real numbers
156 5. Inner product spaces
this construction gives us in coordinates. Then we can see that if we treat
vector x1as the vector consisting of the real parts of complex coordinates,
and vector x2as the vector consisting of imaginary parts of coordinates,
then this construction is exactly the standard complexication of Rn(by
allowing complex coordinates) described above.
The fact that we can express this construction in coordinate-free way,
without picking a basis and working with coordinates, means that the result
does not depend on the choice of a basis.
So, the easiest way to think about complexication is probably as follows:
To construct a complexication of a real vector space Xwe can
pick a basis (an orthonormal basis if Xis a real inner product
space) and then work with coordinates, allowing the complex ones.
The resulting space does not depend on the choice of a basis; we
can get from one coordinates to the others by the standard change
of coordinate formula.
Note, that any linear transformation Tin the real space Xgives rise to
a linear transformation TCin the complexication XC.
The easiest way to see that is to x a basis in X(an orthonormal basis if
Xis a real inner product space) and to work in a coordinate representation:
in this case TChas the same matrix as T. In the abstract representation we
can write
TC[x1;x2] = [Tx1;Tx2]:
On the other hand, not all linear transformations in XCcan be obtained
from the transformations in X; if we do complexication in coordinates,
only the transformations with real matrices work.
Note, that this is completely opposite to the situation in the case of
decomplexication, described in Section 8.1.
An attentive reader probably already noticed that the operations of com-
plexication and decomplixication are not the inverse of each other. First,
the space and its complexication have the same dimension, while the de-
complixication of an n-dimensional space has dimension 2 n. Moreover, as
we just discussed, the relation between real and complex linear transforma-
tions is completely opposite in these cases.
In the next section we discuss the operation, inverse in some sense to
decomplexication.
8.3. Introducing complex structure to a real space. The construction
described in this section works only for real spaces of even dimension.
8.3.1. An elementary way to introduce a complex structure. LetXbe a real
inner product space of dimension 2 n. We want invert the decomplexication
8. Complexication and decomplexication 157
procedure to introduce a complex structure on X, i.e. to identify this space
with a complex space such that its decomplexication (see Section 8.1) give
us the original space X. The simplest idea is to x an orthonormal basis in
Xand then split the coordinates in this basis into two equal parts.
We than treat one half of the coordinates (say coordinates x1;x2;:::;xn)
as real parts of complex coordinates, and treat the rest as the imaginary
parts. Then we have to join real and imaginary parts together: for example
if we treatx1;x2;:::;xnas real parts and xn+1;xn+2;:::;x 2nas imaginary
parts, we can dene complex coordinates zk=xk+ixn+k.
Of course, the result will generally depend on the choice of the orthonor-
mal basis and on the way we split the real coordinates into real and imagi-
nary parts and on how we join them.
One can also see from the decomplexication construction described in
Section 8.1 that all complex structures on a real inner product space Xcan
be obtained in this way.
8.3.2. From elementary to abstract construction of complex structure. The
above construction can be described in an abstract, coordinate-free way.
Namely, let us split the space XasX=EE?, whereEis a subspace,
dimE=n(so dimE?=nas well), and let U0:E!E?be a unitary
(more precisely, orthogonal, since our spaces are real) transformation.
Note, that if v1;v2;:::;vnis an orthonormal basis in E, then the system
U0v1;U0v2;:::;U 0vnis an orthonormal basis in E?, so
v1;v2;:::;vn;U0v1;U0v2;:::;U 0vn
is an orthonormal basis in the whole space X.
Ifx1;x2;:::;x 2nare coordinates of a vector xin this basis, and we
treatxk+ixn+k,k= 1;2;:::;n as complex coordinates of x, then the
multiplication by iis represented by the orthogonal transformation Uwhich
is given in the orthogonal basis of subspaces E;E?by the block matrix
U=0 U
0
U00
:
This means that
ix1
x2
=Ux1
x2
=0 U
0
U00x1
x2
x12E,x22E?.
Clearly,Uis an orthogonal transformation such that U2= I. There-
fore, any complex structure on Xis given by an orthogonal transformation
U, satisfying U2= I; the transformation Ugives us the multiplication by
the imaginary unit i.
158 5. Inner product spaces
The converse is also true, namely any orthogonal transformation Usat-
isfyingU2= Idenes a complex structure on a real inner product space
X. Let us explain how.
8.3.3. An abstract construction of complex structure. Let us rst consider
an abstract explanation. To dene a complex structure, we need to dene
the multiplication of vectors by complex numbers (initially we only can
multiply by real numbers). In fact we need only to dene the multiplication
byi, the rest will follow from linearity in the original real space. And the
multiplication by iis given by the orthogonal transformation Usatisfying
U2= I.
Namely, if the multiplication by iis given by U,ix=Ux, then the
complex multiplication must be dened by
(8.2) (+i)x:=x+Ux= (I+U)x; ;2R;x2X:
We will use this formula now as the denition of complex multiplication.
It is not hard to check that for the complex multiplication dened above
by (8.2) all axioms of comples wector space are satised. One can see that,
for example by using linearity in the real space Xand noticing that that
with respect to algebraic operations (addition and multiplication) the linear
transformations of form
I=U; ;2R;
behave absolutely the same way as complex numbers +i, i.e such trans-
formations give us a representation of the eld of complex numbers C.
This means that rst, a sum and a product of transformations of the form
I+Uis a transformation of the same form, and to get the coeecients ,
of the result we can perform the operation on the corresponding complex
numbers and take the real and imaginary parts of the result. Note, that
here we need the identity U2= I, but we do not need the fact that Uis
an orthogonal transformation.
Thus, we got the structure of a complex vector space. To get a complex
inner product space we need to introduce complex inner product, such that
the original real inner product is the real part of it.
We really do not have nay choice here: noticing that for a complex inner
product
Im(x;y) = Re
 i(x;y)R
= Re( x;iy)R;
we see that the only way to dene the complex inner product is
(8.3) ( x;y)C:= (x;y)R+i(x;Uy)R:
8. Complexication and decomplexication 159
Let us show that this is indeed an inner product. We will need the fact
thatU= U, see Exercise 8.4 below (by Uhere we mean the adjoint with
respect to the original real inner product).
To show that ( y;x)C=(x;y)Cwe use the udentity U= Uand
symmetry of the real inner product:
(y;x)C= (y;x)R+i(y;Ux)
= (x;y)R+i(Ux;y)R
= (x;y)R i(x;Uy)R
=(x;y)R+i(x;Uy)R
=(x;y)C:
To prove the linearity of the complex inner product, let us rst notice
that ( x;y)Cisreal linear in the rst (in fact in each) argument, i.e. that
(x+y;z)C=(x;z)C+(y;z)Cfor;2R; this is true because each
summand in the right side of (8.3) is real linear in argument.
Using real linearity of ( x;y)Cand the identity U= U(which implies
that (Ux;y)R= (x;Uy)R) together with the orthogonality of U, we get
the following chain of equalities
((I+U)x;y)C=(x;y)C+(Ux;y)C
=(x;y)C+
(Ux;y)R+i(Ux;Uy)R
=(x;y)C+
 (x;Uy)R+i(x;y)R
=(x;y)C+i
(x;y)R+i(x;Uy)R
=(x;y)C+i(x;y)C= (+i)(x;y)C;
which proves complex linearity.
Finally, to prove non-negativity of ( x;x)Clet us notice (see Exercise 8.3
below) that ( x;Ux)R= 0, so
(x;x)C= (x;x)R=kxk20:
8.3.4. The abstract construction via the elementary one. For a reader who is
not comfortable with such \high brow" and abstract proof, there is another,
more hands on, explanation.
Namely, it can be shown, see Exercise 8.5 below, that there exists a
subspaceE, dimE=n(recall that dim X= 2n), such that the matrix of U
with respect to the decomposition X=EE?is given by
U=0 U
0
U00
;
whereU0:E!E?is some orthogonal transformation.
160 5. Inner product spaces
Letv1;v2;:::;vnbe an orthonormal basis in E. Then the system
U0v1;U0v2;:::;U 0vnis an orthonormal basis in E?, so
v1;v2;:::;vn;U0v1;U0v2;:::;U 0vn
is an orthonormal basis in the whole space X. Considering the coordinates
x1;x2;:::;x 2nin this basis and treating xk+ixn+kas complex coordinates,
we get an elementary, \coordinate" way of dening complex structure, which
was already described above. But if we look carefully, we see that multipli-
cation byiis given by the transformation U: it is trivial for x2Eand for
y2E?, and so it is true for all reallinear combinations of x+y, i.e. for
all vectors in X.
But that means that the abstract introduction of complex structure
and the corresponding elementary approach give us the same result! And
since the elementary approach clearly gives us the a complex structure, the
abstract approach gives us the same complex structure.
Exercises.
8.1. Prove formula (8.1). Namely, show that if
x= (z1;z2;:::;zn)T; y= (w1;w2;:::;wn)T;
zk=xk+iyk,wk=uk+ivk,xk;yk;uk;vk2R, then
RenX
k=1zkwk
=nX
k=1xkuk+nX
k=1ykvk:
8.2. Show that if ( x;y)Cis an inner product in a complex inner product space,
then ( x;y)Rdened by (8.1) is a real inner product space.
8.3. LetUbe an orthogonal transformation (in a real inner product space X),
satisfyingU2= I. Prove that for all x2X
Ux?x:
8.4. Show, that if Uis an orthogonal transformation satisfying U2= I, then
U= U.
8.5. LetUbe an orthogonal transformation in a real inner product space, satisfying
U2= I. Show that in this case dim X= 2n, and that there exists a subspace
EX, dimE=n, and an orthogonal transformation U0:E!E?such thatU
in the decomposition X=EE?is given by the block matrix
U=
0 U
0
U00
:
This statement can be easily obtained from Theorem 5.1 of Chapter 6, if one notes
that the only rotation RinR2satisfyingR2
= Iare rotations through ==2.
However, one can nd an elementary proof here, not using this theorem. For
example, the statement is trivial if dim X= 2: in this case we can take for Eany
one-dimensional subspace, see Exercise 8.3.
8. Complexication and decomplexication 161
Then it is not hard to show, that such operator Udoes not exists in R2, and
one can use induction in dim Xto complete the proof.

Chapter 6
Structure of operators
in inner product
spaces.
In this chapter we are again assuming that all spaces are nite-dimensional.
Again, we are dealing only with complex or real spaces, theory of inner
product spaces does not apply to spaces over general elds. When we are
not mentioning what space are we in, everything work for both complex and
real spaces.
To avoid writing essentially the same formulas twice we will use the
notation for the complex case: in the real case it give correct, although
sometimes a bit more complicated, formulas.
1. Upper triangular (Schur) representation of an operator.
Theorem 1.1. LetA:X!Xbe an operator acting in a complex inner
product space. There exists an orthonormal basis u1;u2;:::;uninXsuch
that the matrix of Ain this basis is upper triangular.
In other words, any nnmatrixAcan be represented as A=UTU,
whereUis a unitary, and Tis an upper triangular matrix.
Proof. We prove the theorem using the induction in dim X. If dimX= 1
the theorem is trivial, since any 1 1 matrix is upper triangular.
Suppose we proved that the theorem is true if dim X=n 1, and we
want to prove it for dim X=n.
163
164 6. Structure of operators in inner product spaces.
Let1be an eigenvalue of A, and let u1,ku1k= 1 be a corresponding
eigenvector, Au1=1u1. DenoteE=u?
1, and let v2;:::;vnbe some
orthonormal basis in E(clearly, dim E= dimX 1 =n 1), so u1;v2;:::;vn
is an orthonormal basis in X. In this basis the matrix of Ahas the form
(1.1)0
BBB@1
0
...A1
01
CCCA;
here all entries below 1are zeroes, andmeans that we do not care what
entries are in the rst row right of 1.
We do care enough about the lower right ( n 1)(n 1) block, to give
it name: we denote it as A1.
Note, that A1denes a linear transformation in E, and since dim E=
n 1, the induction hypothesis implies that there exists an orthonormal
basis (let us denote it as u2;:::;un) in which the matrix of A1is upper
triangular.
So, matrix of Ain the orthonormal basis u1;u2;:::;unhas the form
(1.1), where matrix A1is upper triangular. Therefore, the matrix of Ain
this basis is upper triangular as well. 
Remark. Note, that the subspace E=u?
1introduced in the proof is not invariant
underA, i.e. the inclusion AEEdoes not necessarily hold. That means that A1
is not a part of A, it is some operator constructed from A.
Note also, that AEEif and only if all entries denoted by (i.e. all entries
in the rst row, except 1) are zero.
Remark. Note, that even if we start from a real matrix A, the matrices U
andTcan have complex entries. The rotation matrix
cos sin
sincos
; 6=k;k2Z
is not unitarily equivalent (not even similar) to a real upper triangular ma-
trix. Indeed, eigenvalues of this matrix are complex, and the eigenvalues of
an upper triangular matrix are its diagonal entries.
Remark. An analogue of Theorem 1.1 can be stated and proved for an
arbitrary vector space, without requiring it to have an inner product. In
this case the theorem claims that any operator have an upper triangular
form in some basis. A proof can be modeled after the proof of Theorem 1.1.
An alternative way is to equip Vwith an inner product by xing a basis in
Vand declaring it to be an orthonormal one, see Problem 2.4 in Chapter 5.
2. Spectral theorem for self-adjoint and normal operators. 165
Note, that the version for inner product spaces (Theorem 1.1) is stronger
than the one for the vector spaces, because it says that we always can nd
an orthonormal basis, not just a basis.
The following theorem is a real-valued version of Theorem 1.1
Theorem 1.2. LetA:X!Xbe an operator acting in a realinner product
space. Suppose that all eigenvalues of Aare real (meaning that Ahas exactly
n= dimXreal eigenvalues, counting multiplicities). Then there exists an
orthonormal basis u1;u2;:::;uninXsuch that the matrix of Ain this basis
is upper triangular.
In other words, any real nnmatrixAwith all real eigenvalues can be
represented as T=UTU=UTUT, whereUis an orthogonal, and Tis a
real upper triangular matrices.
Proof. To prove the theorem we just need to analyze the proof of Theorem
1.1. Let us assume (we can always do this without loss of generality) that
the operator (matrix) Aacts in Rn.
Suppose, the theorem is true for ( n 1)(n 1) matrices. As in the
proof of Theorem 1.1 let 1be a real eigenvalue of A,u12Rn,ku1k= 1 be
a corresponding eigenvector, and let v2;:::;vnbe on orthonormal system
(inRn) such that u1;v2;:::;vnis an orthonormal basis in Rn.
The matrix of Ain this basis has form (1.1), where A1is some real
matrix.
If we can prove that matrix A1has only real eigenvalues, then we are
done. Indeed, then by the induction hypothesis there exists an orthonormal
basis u2;:::;uninE=u?
1such that the matrix of A1in this basis is
upper triangular, so the matrix of Ain the basis u1;u2;:::;unis also upper
triangular.
To show that A1has only real eigenvalues, let us notice that
det(A I) = (1 ) det(A1 )
(take the cofactor expansion in the rst row, for example), and so any eigen-
value ofA1is also an eigenvalue of A. ButAhas only real eigenvalues! 
Exercises.
1.1. Use the upper triangular representation of an operator to give an alternative
proof of the fact that determinant is the product and the trace is the sum of
eigenvalues counting multiplicities.
2. Spectral theorem for self-adjoint and normal operators.
In this section we deal with matrices (operators) which are unitarily equiv-
alent to diagonal matrices.
166 6. Structure of operators in inner product spaces.
Let us recall that an operator is called self-adjoint if A=A. A matrix
of a self-adjoint operator (in some orthonormal basis), i.e. a matrix satisfying
A=Ais called a Hermitian matrix.
The terms self-adjoint and Hermitian essentially mean the same. Usu-
ally people say self-adjoint when speaking about operators (transforma-
tions), and Hermitian when speaking about matrices. We will try to follow
this convention, but since we often do not distinguish between operators and
their matrices, we will sometimes mix both terms.
Theorem 2.1. LetA=Abe a self-adjoint operator in an inner product
spaceX(the space can be complex or real). Then all eigenvalues of Aare
real, and there exists and orthonormal basis of eigenvectors of AinX.
This theorem can be restated in matrix form as follows
Theorem 2.2. LetA=Abe a self-adjoint (and therefore square) matrix.
ThenAcan be represented as
A=UDU;
whereUis a unitary matrix and Dis a diagonal matrix with real entries.
Moreover, if the matrix Ais real, matrix Ucan be chosen to be real
(i.e. orthogonal).
Proof. To prove Theorems 2.1 and 2.2 let us rst apply Theorem 1.1 (The-
orem 1.2 if Xis a real space) to nd an orthonormal basis in Xsuch that
the matrix of Ain this basis is upper triangular. Now let us ask ourself a
question: What upper triangular matrices are self-adjoint?
The answer is immediate: an upper triangular matrix is self-adjoint if
and only if it is a diagonal matrix with real entries. Theorem 2.1 (and so
Theorem 2.2) is proved. 
Remark. In many textbooks only real matrices are considered, and The-
orem 2.2 is often called the \Spectral Theorem for symmetric matrices".
However, we should emphasize that the conclusion of Theorem 2.2 fails for
complex symmetric matrices: the theorem holds for Hermitian matrices, and
in particular for realsymmetric matrices.
Let us give an independent proof to the fact that eigenvalues of a self-
adjoint operators are real. Let A=AandAx=x,x6=0. Then
(Ax;x) = (x;x) =(x;x) =kxk2:
On the other hand,
(Ax;x) = (x;Ax) = (x;Ax) = (x;x) =(x;x) =kxk2;
2. Spectral theorem for self-adjoint and normal operators. 167
sokxk2=kxk2. Sincekxk6= 0 (x6=0), we can conclude =, sois
real.
It also follows from Theorem 2.1 that eigenspaces of a self-adjoint oper-
ator are orthogonal. Let us give an alternative proof of this result.
Proposition 2.3. LetA=Abe a self-adjoint operator, and let u;vbe its
eigenvectors, Au=u,Av=v. Then, if6=, the eigenvectors uand
vare orthogonal.
Proof. This proposition follows from the spectral theorem (Theorem 1.1),
but here we are giving a direct proof. Namely,
(Au;v) = (u;v) =(u;v):
On the other hand
(Au;v) = (u;Av) = (u;Av) = (u;v) =(u;v) =(u;v)
(the last equality holds because eigenvalues of a self-adjoint operator are
real), so(u;v) =(u;v). If6=it is possible only if ( u;v) = 0. 
Now let us try to nd what matrices are unitarily equivalent to a diagonal
one. It is easy to check that for a diagonal matrix D
DD=DD:
ThereforeAA=AAif the matrix of Ain some orthonormal basis is
diagonal.
Denition. An operator (matrix) Nis called normal ifNN=NN.
Clearly, any self-adjoint operator ( AA=AA) is normal. Also, any
unitary operator U:X!Xis normal since UU=UU=I.
Note, that a normal operator is an operator acting in one space, not from one
space to another. So, if Uis a unitary operator acting from one space to another,
we cannot say that Uis normal.
Theorem 2.4. Any normal operator Nin a complex vector space has an
orthonormal basis of eigenvectors.
In other words, any matrix NsatisfyingNN=NNcan be represented
as
N=UDU;
whereUis a unitary matrix, and Dis a diagonal one.
Remark. Note, that in the above theorem even if Nis a real matrix, we
did not claim that matrices UandDare real. Moreover, it can be easily
shown, that if Dis real,Nmust be self-adjoint.
168 6. Structure of operators in inner product spaces.
Proof of Theorem 2.4. To prove Theorem 2.4 we apply Theorem 1.1 to
get an orthonormal basis, such that the matrix of Nin this basis is upper
triangular. To complete the proof of the theorem we only need to show that
an upper triangular normal matrix must be diagonal.
We will prove this using induction in the dimension of matrix. The case
of 11 matrix is trivial, since any 1 1 matrix is diagonal.
Suppose we have proved that any ( n 1)(n 1) upper triangular
normal matrix is diagonal, and we want to prove it for nnmatrices. Let
Nbennupper triangular normal matrix. We can write it as
N=0
BBB@a1;1a1;2::: a 1;n
0
...N1
01
CCCA
whereN1is an upper triangular ( n 1)(n 1) matrix.
Let us compare upper left entries (rst row rst column) of NNand
NN. Direct computation shows that that
(NN)1;1=a1;1a1;1=ja1;1j2
and
(NN)1;1=ja1;1j2+ja1;2j2+:::+ja1;nj2:
So, (NN)1;1= (NN)1;1if and only if a1;2=:::=a1;n= 0. Therefore,
the matrix Nhas the form
N=0
BBB@a1;10::: 0
0
...N1
01
CCCA
It follows from the above representation that
NN=0
BBB@ja1;1j20::: 0
0
...N
1N1
01
CCCA; NN=0
BBB@ja1;1j20::: 0
0
...N1N
1
01
CCCA
soN
1N1=N1N
1. That means the matrix N1is also normal, and by the
induction hypothesis it is diagonal. So the matrix Nis also diagonal. 
The following proposition gives a very useful characterization of normal
operators.
Proposition 2.5. An operator N:X!Xis normal if and only if
kNxk=kNxk 8 x2X:
2. Spectral theorem for self-adjoint and normal operators. 169
Proof. LetNbe normal, NN=NN. Then
kNxk2= (Nx;Nx) = (NNx;x) = (NNx;x) = (Nx;Nx) =kNxk2
sokNxk=kNxk.
Now let
kNxk=kNxk 8 x2X:
The Polarization Identities (Lemma 1.9 in Chapter 5) imply that for all
x;y2X
(NNx;y) = (Nx;Ny) =1
4X
=1;ikNx+Nyk2
=1
4X
=1;ikN(x+y)k2
=1
4X
=1;ikN(x+y)k2
=1
4X
=1;ikNx+Nyk2
= (Nx;Ny) = (NNx;y)
and therefore (see Corollary 1.6) NN=NN. 
Exercises.
2.1. True or false:
a) Every unitary operator U:X!Xis normal.
b) A matrix is unitary if and only if it is invertible.
c) If two matrices are unitarily equivalent, then they are also similar.
d) The sum of self-adjoint operators is self-adjoint.
e) The adjoint of a unitary operator is unitary.
f) The adjoint of a normal operator is normal.
g) If all eigenvalues of a linear operator are 1, then the operator must be
unitary or orthogonal.
h) If all eigenvalues of a normal operator are 1, then the operator is identity.
i) A linear operator may preserve norm but not the inner product.
2.2. True or false: The sum of normal operators is normal? Justify your conclusion.
2.3. Show that an operator unitarily equivalent to a diagonal one is normal.
2.4. Orthogonally diagonalize the matrix,
A=3 2
2 3
:
Find all square roots of A, i.e. nd all matrices Bsuch thatB2=A.
170 6. Structure of operators in inner product spaces.
Note, that all square roots of Aare self-adjoint.
2.5. True or false: any self-adjoint matrix has a self-adjoint square root. Justify.
2.6. Orthogonally diagonalize the matrix,
A=7 2
2 4
;
i.e. represent it as A=UDU, whereDis diagonal and Uis unitary.
Among all square roots of A, i.e. among all matrices Bsuch thatB2=A, nd
one that has positive eigenvalues. You can leave Bas a product.
2.7. True or false:
a) A product of two self-adjoint matrices is self-adjoint.
b) IfAis self-adjoint, then Akis self-adjoint.
Justify your conclusions
2.8. LetAbemnmatrix. Prove that
a)AAis self-adjoint.
b) All eigenvalues of AAare non-negative.
c)AA+Iis invertible.
2.9. Give a proof if the statement is true, or give a counterexample if it is false:
a) IfA=AthenA+iIis invertible.
b) IfUis unitary,U+3
4Iis invertible.
c) If a matrix Ais real,A iIis invertible.
2.10. Orthogonally diagonalize the rotation matrix
R=cos sin
sin cos
;
whereis not a multiple of . Note, that you will get complex eigenvalues in this
case.
2.11. Orthogonally diagonalize the matrix
A=cos sin
sin cos
:
Hints: You will get real eigenvalues in this case. Also, the trigonometric identities
sin 2x= 2 sinxcosx, sin2x= (1 cos 2x)=2, cos2x= (1 + cos 2 x)=2 (applied to
x==2) will help to simplify expressions for eigenvectors.
2.12. Can you describe the linear transformation with matrix Afrom the previous
problem geometrically? Is has a very simple geometric interpretation.
2.13. Prove that a normal operator with unimodular eigenvalues (i.e. with all
eigenvalues satisfying jkj= 1) is unitary. Hint: Consider diagonalization
2.14. Prove that a normal operator with real eigenvalues is self-adjoint.
3. Polar and singular value decompositions. 171
2.15. Show by example that conclusion of Theorem 2.2 fails for complex symmetric
matrices. Namely
a) construct a (diagonalizable) 2 2 complex symmetric matrix not admitting
an orthogonal basis of eigenvectors;
b) construct a 22 complex symmetric matrix which cannot be diagonalized.
3. Polar and singular value decompositions.
3.1. Positive denite operators. Square roots.
Denition. A self adjoint operator A:X!Xis called positive denite if
(Ax;x)>08x6=0;
and it is called positive semidenite if
(Ax;x)08x2X:
We will use the notation A>0 for positive denite operators, and A0
for positive semi-denite.
The following theorem describes positive denite and semidenite oper-
ators.
Theorem 3.1. LetA=A. Then
1.A>0if and only if all eigenvalues of Aare positive.
2.A0if and only if all eigenvalues of Aare non-negative.
Proof. Pick an orthonormal basis such that matrix of Ain this basis is
diagonal (see Theorem 2.1). To nish the proof it remains to notice that a
diagonal matrix is positive denite (positive semidenite) if and only if all
its diagonal entries are positive (non-negative). 
Corollary 3.2. LetA=A0be a positive semidenite operator. There
exists a unique positive semidenite operator Bsuch thatB2=A
SuchBis called (positive) square root of Aand is denoted asp
Aor
A1=2.
Proof. Let us prove thatp
Aexists. Let v1;v2;:::;vnbe an orthonor-
mal basis of eigenvectors of A, and let1;2;:::;nbe the corresponding
eigenvalues. Note, that since A0, allk0.
In the basis v1;v2;:::;vnthe matrix of Ais a diagonal matrix
diagf1;2;:::;ngwith entries 1;2;:::;non the diagonal. Dene the
matrix ofBin the same basis as diag fp1;p2;:::;png.
Clearly,B=B0 andB2=A.
172 6. Structure of operators in inner product spaces.
To prove that such Bis unique, let us suppose that there exists an op-
eratorC=C0 such that C2=A. Let u1;u2;:::;unbe an orthonormal
basis of eigenvectors of C, and let1;2;:::;nbe the corresponding eigen-
values (note that k08k). The matrix of Cin the basis u1;u2;:::;un
is a diagonal one diag f1;2;:::;ng, and therefore the matrix of A=C2
in the same basis is diag f2
1;2
2;:::;2
ng. This implies that any eigenvalue
ofAis of form2
k, and, moreover, if Ax=x, thenCx=p
x.
Therefore in the basis v1;v2;:::;vnabove, the matrix of Chas the
diagonal form diag fp1;p2;:::;png, i.e.B=C. 
3.2. Modulus of an operator. Singular values. Consider an operator
A:X!Y. Its Hermitian square AAis a positive semidenite operator
acting inX. Indeed,
(AA)=AA=AA
and
(AAx;x) = (Ax;Ax) =kAxk208x2X:
Therefore, there exists a (unique) positive-semidenite square root R=p
AA. This operator Ris called the modulus of the operator A, and is
often denoted as jAj.
The modulus of Ashows how \big" the operator Ais:
Proposition 3.3. For a linear operator A:X!Y
kjAjxk=kAxk 8 x2X:
Proof. For any x2X
kjAjxk2= (jAjx;jAjx) = (jAjjAjx;x) = (jAj2x;x)
= (AAx;x) = (Ax;Ax) =kAxk2

Corollary 3.4.
KerA= KerjAj= (RanjAj)?:
Proof. The rst equality follows immediately from Proposition 3.3, the sec-
ond one follows from the identity Ker T= (RanT)?(jAjis self-adjoint). 
Theorem 3.5 (Polar decomposition of an operator) .LetA:X!Xbe an
operator (square matrix). Then Acan be represented as
A=UjAj;
whereUis a unitary operator.
Remark. The unitary operator Uis generally not unique. As one will see
from the proof of the theorem, Uis unique if and only if Ais invertible.
3. Polar and singular value decompositions. 173
Remark. The polar decomposition A=UjAjalso holds for operators A:
X!Yacting from one space to another. But in this case we can only
guarantee that Uis an isometry from RanjAj= (KerA)?toY.
If dimXdimYthis isometry can be extended to an isometry from
the wholeXtoY(if dimX= dimYthis will be a unitary operator).
Proof of Theorem 3.5. Consider a vector x2RanjAj. Then vector x
can be represented as x=jAjvfor some vector v2X.
DeneU0x:=Av. By Proposition 3.3
kU0xk=kAvk=kjAjvk=kxk
so it looks like Uis an isometry from Ran jAjtoX.
But rst we need to prove that U0is well dened. Let v1be another
vector such that x=jAjv1. But x=jAjv=jAjv1means that v v12
KerjAj= KerA(cf Corollary 3.4), so Av=Av1, meaning that U0xis well
dened.
By the construction A=U0jAj. We leave as an exercise for the reader
to check that U0is a linear transformation.
To extendU0to a unitary operator U, let us nd some unitary transfor-
mationU1: KerA!(RanA)?= KerA. It is always possible to do this,
since for square matrices dim Ker A= dim KerA(the Rank Theorem).
It is easy to check that U=U0+U1is a unitary operator, and that
A=UjAj. 
3.3. Singular values. Schmidt decomposition.
Denition. Eigenvalues ofjAjare called the singular values ofA. In other
words, if1;2;:::;nare eigenvalues of AAthenp1;p2;:::;pnare
singular values of A.
Remark. Very often in the literature the singular values are dened as the
non-negative square roots of the eigenvalues of AA, without any reference
to the modulusjAj.
I consider the notion of the modulus of an operator to be an important
one, so it was introduced above. However, the notion of the modulus of an
operator is not required for what follows (dening the Schur and singular
value decompositions). Moreover, as it will be shown below, the modulus of
Acan be easily constructed from the singular value decomposition.
Consider an operator A:X!Y, and let1;2;:::;nbe the singu-
lar values of Acounting multiplicities. Assume also that 1;2;:::;rare
thenon-zero singular values of A, counting multiplicities. This means, in
particular, that k= 0 fork>r .
174 6. Structure of operators in inner product spaces.
By the denition of singular values the numbers 2
1;2
2;:::;2
nare eigen-
values ofAA. Let v1;v2;:::;vnbe an orthonormal basis1of eigenvectors
ofAA,AAvk=2
kvk.
Proposition 3.6. The system
wk:=1
kAvk; k = 1;2;:::;r
is an orthonormal system.
Proof.
(Avj;Avk) = (AAvj;vk) = (2
jvj;vk) =2
j(vj;vk) =0; j6=k
2
j; j =k
since v1;v2;:::;vris an orthonormal system. 
In the notation of the above proposition, the operator Acan be repre-
sented as
(3.1) A=rX
k=1kwkv
k;
or, equivalently
(3.2) Ax=rX
k=1k(x;vk)wk:
Indeed, we know that v1;v2;:::;vnis an orthonormal basis in X. Then
substituting x=vjinto the right side of (3.2) we get
rX
k=1k(vj;vk)wk=j(vj;vj)wj=jwj=Avj ifj= 1;2;:::;r;
and
rX
k=1k(v
kvj)wk=0=Avj forj >r:
So the operators in the left and right sides of (3.1) coincide on the basis
v1;v2;:::;vn, so they are equal.
Denition. The above decomposition (3.1) (or (3.2)) is called the Schmidt
decomposition of the operator A.
Remark. Shmidt decomposition of an operator is not unique. Why?
1We know, that for a self-adjoint operator ( AAin our case) there exists an orthonormal
basis of eigenvectors.
3. Polar and singular value decompositions. 175
Lemma 3.7. LetAcan be represented as
A=rX
k=1kwkv
k
wherek>0andv1;v2;:::;vr,w1;w2;:::;wrare some orthonormal sys-
tems.
Then this representation gives a Schmidt decomposition of A.
Proof. We only need to show that v1;v2;:::;vrare eigenvectors of AA,
AAvk=2
kvk. Since w1;w2;:::;wris an orthonormal system,
w
kwj= (wj;wk) =k;j:=0; j6=k
1; j =k;
and therefore
AA=rX
k=12
kvkv
k:
Since v1;v2;:::;vris an orthonormal system
AAvj=rX
k=12
kvkv
kvj=2
jvj
thusvkare eigenvectors of AA. 
Corollary 3.8. Let
A=rX
k=1kwkv
k
be a Schmidt decomposition of A. Then
A=rX
k=1kvkw
k
is a Scmidt decomposition of A
3.4. Matrix representation of the Shmidt decomposition. Singular
value decomposition. The Shmidt decomposition can be written in a nice
matrix form. Namely, let us assume that A:Fn!Fm, where Fis either
CorR(we can always do that by xing orthonormal bases in XandY
and working with coordinates in these bases). Let 1;2;:::;rbe non-zero
singular values of A, and let
A=rX
k=1kwkv
k
be a Scmidt decomposition of A.
176 6. Structure of operators in inner product spaces.
As one can easily see, this equality can be rewritten as
(3.3) A=fWeeV;
wheree = diagf1;2;:::;rgandeVandfWare matrices with columns
v1;v2;:::;vrandw1;w2;:::;wrrespectively. (Can you tell what is the
size of each matrix?)
Note, that since v1;v2;:::;vrandw1;w2;:::;wrare orthonormal sys-
tems, the matrices eVandfWare isometries. Note also that r= rankA, see
Exercise 3.1 below.
If the matrix Ais invertible, then m=n=r, the matrices eV,fWare
unitary ande is an invertible diagonal matrix.
It turns out that it is always possible to write a representation similar
(3.3) with unitary VandWinstead ofeVandfW, and in many situations
it is more convenient to work with such a representation. To write this
representation one needs rst to complete the systems v1;v2;:::;vrand
w1;w2;:::;wrto orthogonal bases in FnandFmrespectively.
Recall, that to complete, say v1;v2;:::;vrto an orthonormal basis in
Fnone just needs to nd and orthonormal basis vr+1;:::;vnin KerV; then
the system v1;v2;:::;vnwill be an orthonormal basis in Fn. And one can
always get an orthonormal basis from an arbitrary one using Gram{Schmidt
orthogonalization.
ThenAcan be represented as
(3.4) A=WV;
whereV2MF
nnandW2MF
mmare unitary matrices with columns
v1;v2;:::;vnandw1;w2;:::;wmrespectively, and  is a \diagonal" mn
matrix
(3.5)  j;k=kj=kr:
0 otherwise.
In other words, to get the matrix  one has to take the diagonal matrix
diagf1;2;:::;rgand make it to an mnmatrix by adding extra zeroes
\south and east".
Denition 3.9. For a matrix A2MF
mn(recall that here Fis always Cor
R) its singular value decomposition (SVD) is a decomposition of form (3.4),
i.e. a decomposition A=WV, whereW2MF
nn,V2MF
mmare unitary
matrices and 2MR+
mnis a \diagonal" one (meaning that k;k0 for all
k= 1;2;:::; minfm;ng, andj;k= 0 for allj6=k).
The representation (3.3) is often called the reduced orcompact SVD.
More precisely the reduced SVD is a representation A=fWeeV, where
e2MR+
rr,rminfm;ngis a diagonal matrix with strictly positive diagonal
3. Polar and singular value decompositions. 177
entries, andfW2MF
nr,eV2MF
mrare isometries; moreover, we require
that at least one of the matrices fWandeVis not square.
Remark 3.10. It is easy to see that if A=WVis a singular value
decomposition of A, thenk:=k;kare singular values of A, i.e.2
kare
eigenvalues of AA. Moreover, the columns vkofVare the corresponding
eigenvectors of AA,AAvk=2
kvk. Note also that if k6= 0 then wk=
1
kAvk.
All that means that any singular value decomposition A=WVcan be
obtained from a Schmidt decomposition (3.2) by the construction described
above in this section.
The reduced singular value decomposition can be interpreted as a matrix
form of the Schmidt decomposition (3.2) for a non-invertible matrix A. For
an invertible matrix Athe matrix form of the Schmidt decomposition gives
the singular value decomposition.
Remark 3.11. An alternative way to interpret the singular value decom-
positionA=WVis to say that  is the matrix of Ain the (orthonormal)
basesA=v1;v2;:::;vnandB:=w1;w2;:::;wn, i.e that  = [ A]B;A.
We will use this interpretation later.
3.4.1. From singular value decomposition to the polar decomposition. Note,
that if we know the singular value decomposition A=WVof a square
matrixA, we can write a polar decomposition of A:
(3.6) A=WV= (WV)(VV) =UjAj
wherejAj=VVandU=WV.
To see that this indeed give us a polar decomposition let us notice that
VVis a self-adjoint, positive semidenite operator and that
AA=VWWV=VV=VVVV= (VV)2:
So by the denition of jAjas the unique positive semidenite square root
ofAA, we can see that jAj=VV. The transformation WVis clearly
unitary, as a product of two unitary transformations, so (3.6) indeed gives
us a polar decomposition of A.
Note, that this reasoning only works for square matrices, because if Ais
not square, then the product V is not dened (dimensions do not match,
can you see how?).
Exercises.
3.1. Show that the number of non-zero singular values of a matrix Acoincides with
its rank.
178 6. Structure of operators in inner product spaces.
3.2. Find Schmidt decompositions A=rX
k=1skwkv
kfor the following matrices A:
2 3
0 2
;0
@7 1
0 0
5 51
A;0
@1 1
0 1
 1 11
A:
3.3. LetAbe an invertible matrix, and let A=WVbe its singular value
decomposition. Find a singular value decomposition for AandA 1.
3.4. Find singular value decomposition A=WVwhereVandWare unitary
matrices for the following matrices:
a)A=0
@ 3 1
6 2
6 21
A;
b)A=
3 2 2
2 3 2
.
3.5. Find singular value decomposition of the matrix
A=2 3
0 2
Use it to nd
a) maxkxk1kAxkand the vectors where the maximum is attained;
b) minkxk=1kAxkand the vectors where the minimum is attained;
c) the image A(B) of the closed unit ball in R2,B=fx2R2:kxk1g.
DescribeA(B) geometrically.
3.6. Show that for a square matrix A,jdetAj= detjAj.
3.7. True or false
a) Singular values of a matrix are also eigenvalues of the matrix.
b) Singular values of a matrix Aare eigenvalues of AA.
c) Issis a singular value of a matrix Aandcis a scalar, thenjcjsis a singular
value ofcA.
d) The singular values of any linear operator are non-negative.
e) Singular values of a self-adjoint matrix coincide with its eigenvalues.
3.8. LetAbe anmnmatrix. Prove that non-zero eigenvalues of the matrices
AAandAA(counting multiplicities) coincide.
Can you say when zero eigenvalue of AAand zero eigenvalue of AAhave the
same multiplicity?
3.9. Letsbe the largest singular value of an operator A, and letbe the eigenvalue
ofAwith largest absolute value. Show that jjs.
3.10. Show that the rank of a matrix is the number of its non-zero singular values
(counting multiplicities).
4. Applications of the singular value decomposition. 179
3.11. Show that the operator norm of a matrix Acoincides with its Frobenius
norm if and only if the matrix has rank one. Hint: The previous problem might
help.
3.12. For the matrix A
A=
2 3
0 2
;
describe the inverse image of the unit ball, i.e. the set of all x2R2such that
kAxk1. Use singular value decomposition.
4. Applications of the singular value decomposition.
As we discussed above, the singular value decomposition is simply diago-
nalization with respect to two dierent orthonormal bases. Since we have
two dierent bases here, we cannot say much about spectral properties of an
operator from its singular value decomposition. For example, the diagonal
entries of  in the singular value decomposition (3.5) are not the eigenvalues
ofA. Note, that for A=WVas in (3.5) we generally have An6=WnV,
so this diagonalization does not help us in computing functions of a matrix.
However, as the examples below show, singular values tell us a lot about
so-called metric properties of a linear transformation.
Final remark: performing singular value decomposition requires nding
eigenvalues and eigenvectors of the Hermitian (self-adjoint) matrix AA. To
nd eigenvalues we usually computed characteristic polynomial, found its
roots, and so on... This looks like quite a complicated process, especially if
one takes into account that there is no formula for nding roots of polyno-
mials of degree 5 and higher.
However, there are very eective numerical methods of nd eigenvalues
and eigenvectors of a hermitian matrix up to any given precision. These
methods do not involve computing the characteristic polynomial and nding
its roots. They compute approximate eigenvalues and eigenvectors directly
by an iterative procedure. Because a Hermitian matrix has an orthogonal
basis of eigenvectors, these methods work extremely well.
We will not discuss these methods here, it goes beyond the scope of
this book. However, you should believe me that there are very eective nu-
merical methods for computing eigenvalues and eigenvectors of a Hermitian
matrix and for nding the singular value decomposition. These methods are
extremely eective, and just a little more computationally intensive than
solving a linear system.
180 6. Structure of operators in inner product spaces.
4.1. Image of the unit ball. Consider for example the following problem:
letA:Rn!Rmbe a linear transformation, and let B=fx2Rn:kxk1g
be the closed unit ball inRn. We want to describe A(B), i.e. we want to
nd out how the unit ball is transformed under the linear transformation.
Let us rst consider the simplest case when Ais a diagonal matrix A=
diagf1;2;:::;ng,k>0,k= 1;2;:::;n . Then for x= (x1;x2;:::;xn)T
and (y1;y2;:::;yn)T=y=Axwe haveyk=kxk(equivalently, xk=
yk=k) fork= 1;2;:::;n , so
y= (y1;y2;:::;yn)T=Ax forkxk1;
if and only if the coordinates y1;y2;:::;ynsatisfy the inequality
y2
1
2
1+y2
2
2
2++y2
n
2n=nX
k=1y2
k
2
k1
(this is simply the inequality kxk2=P
kjxkj21).
The set of points in Rnsatisfying the above inequalities is called an el-
lipsoid. Ifn= 2 it is an ellipse with half-axes 1and2, forn= 3 it is
an ellipsoid with half-axes 1;2and2. InRnthe geometry of this set
is also easy to visualize, and we call that set an ellipsoid with half axes
1;2;:::;n. The vectors e1;e2;:::;enor, more precisely the correspond-
ing lines are called the principal axes of the ellipsoid.
The singular value decomposition essentially says that any operator in an
inner product space is diagonal with respect to a pair of orthonormal bases,
see Remark 3.11. Namely, consider the orthogonal bases A=v1;v2;:::;vn
andB=w1;w2;:::;wnfrom the singular value decomposition (3.1). Then
the matrix of Ain these bases is diagonal
[A]B;A= diagfn:n= 1;2;:::;ng:
Assuming that all k>0 and essentially repeating the above reasoning, it
is easy to show that any point y=Ax2A(B) if and only if it satises the
inequality
y2
1
2
1+y2
2
2
2++y2
n
2n=nX
k=1y2
k
2
k1:
wherey1;y2;:::;ynare coordinates of yin the orthonormal basis B=
w1;w2;:::;wn, not in the standard one. Similarly, ( x1;x2;:::;xn)T= [x]A.
But that is essentially the same ellipsoid as before, only \rotated" (with
dierent but still orthogonal principal axes)!
There is also an alternative explanation which is presented below.
Consider the general case, when the matrix Ais not necessarily square,
and (or) not all singular values are non-zero. Consider rst the case of a
\diagonal" matrix  of form (3.5). It is easy to see that the image  Bof
4. Applications of the singular value decomposition. 181
the unit ball Bis the ellipsoid (not in the whole space but in the Ran )
with half axes 1;2;:::;r.
Consider now the general case, A=WV, whereV,Ware unitary
operators. Unitary transformations do not change the unit ball (because
they preserve norm), so V(B) =B. We know that ( B) is an ellipsoid in
Ran  with half-axes 1;2;:::;r. Unitary transformations do not change
geometry of objects, so W((B)) is also an ellipsoid with the same half-axes.
It is not hard to see from the decomposition A=WV(using the fact that
bothWandVare invertible) that Wtransforms Ran  to Ran A, so we
can conclude:
the imageA(B) of the closed unit ball Bis an ellipsoid in Ran A
with half axes 1;2;:::;r. Hereris the number of non-zero
singular values, i.e. the rank of A.
4.2. Operator norm of a linear transformation. Given a linear trans-
formationA:X!Ylet us consider the following optimization problem:
nd the maximum of kAxkon the closed unit ball B=fx2X:kxk1g.
Again, singular value decomposition allows us to solve the problem. For
a diagonal matrix Awith non-negative entries the maximum is exactly max-
imal diagonal entry. Indeed, let s1;s2;:::;srbe non-zero diagonal entries of
Aand lets1be the maximal one. Since for x= (x1;x2;:::;xn)T
(4.1) Ax=rX
k=1skxkek;
we can conclude that
kAxk2=rX
k=1s2
kjxkj2s2
1rX
k=1jxkj2=s2
1kxk2;
sokAxks1kxk. On the other hand, kAe1k=ks1e1k=s1ke1k, so indeed
s1is the maximum of kAxkon the closed unit ball B. Note, that in the
above reasoning we did not assume that the matrix Ais square; we only
assumed that all entries outside the \main diagonal" are 0, so formula (4.1)
holds.
To treat the general case let us consider the singular value decompo-
sition (3.5), A=WV, whereW,Vare unitary operators, and  is the
diagonal matrix with non-negative entries. Since unitary transformations
do not change the norm, one can conclude that the maximum of kAxkon
the unit ball Bis the maximal diagonal entry of  i.e. that
the maximum ofkAxkon the unit ball Bis the maximal singular
value ofA.
182 6. Structure of operators in inner product spaces.
Denition. The quantity max fkAxk:x2X;kxk1gis called the oper-
ator norm of Aand denotedkAk.
It is an easy exercise to see that kAksatises all properties of the norm:
1.kAk=jjkAk;
2.kA+BkkAk+kBk;
3.kAk0 for allA;
4.kAk= 0 if and only if A=0,
so it is indeed a norm on a space of linear transformations from from Xto
Y.
One of the main properties of the operator norm is the inequality
kAxkkAkkxk;
which follows easily from the homogeneity of the norm kxk.
In fact, it can be shown that the operator norm kAkis the best (smallest)
numberC0 such that
kAxkCkxk 8 x2X:
This is often used as a denition of the operator norm.
On the space of linear transformations we already have one norm, the
Frobenius, or Hilbert-Schmidt norm kAk2,
kAk2
2= trace(AA):
So, let us investigate how these two norms compare.
Lets1;s2;:::;srbe non-zero singular values of A(counting multiplici-
ties), and let s1be the largest eigenvalues. Then s2
1;s2
2;:::;s2
rare non-zero
eigenvalues of AA(again counting multiplicities). Recalling that the trace
equals the sum of the eigenvalues we conclude that
kAk2
2= trace(AA) =rX
k=1s2
k:
On the other hand we know that the operator norm of Aequals its largest
singular value, i.e. kAk=s1. So we can conclude that kAkkAk2, i.e. that
the operator norm of a matrix cannot be more than its Frobenius
norm.
This statement also admits a direct proof using the Cauchy{Schwarz in-
equality, and such a proof is presented in some textbooks. The beauty of
the proof we presented here is that it does not require any computations
and illuminates the reasons behind the inequality.
4. Applications of the singular value decomposition. 183
4.3. Condition number of a matrix. Suppose we have an invertible
matrixAand we want to solve the equation Ax=b. The solution, of
course, is given by x=A 1b, but we want to investigate what happens if
we know the data only approximately.
That happens in the real life, when the data is obtained, for example by
some experiments. But even if we have exact data, round-o errors during
computations by a computer may have the same eect of distorting the data.
Let us consider the simplest model, suppose there is a small error in the
right side of the equation. That means, instead of the equation Ax=bwe
are solving
Ax=b+b;
where bis a small perturbation of the right side b.
So, instead of the exact solution xofAx=bwe get the approximate
solution x+xofA(x+x) =b+b. We are assuming that Ais invertible,
sox=A 1b.
We want to know how big is the relative error in the solution kxk=kxk
in comparison with the relative error in the right side kbk=kbk. It is easy
to see that
kxk
kxk=kA 1bk
kxk=kA 1bk
kbkkbk
kxk=kA 1bk
kbkkAxk
kxk:
SincekA 1bkkA 1kkbkandkAxkkAkkxkwe can conclude that
kxk
kxkkA 1kkAkkbk
kbk:
The quantitykAkkA 1kis called the condition number of the matrix A.
It estimates how the relative error in the solution xdepends on the relative
error in the right side b.
Let us see how this quantity is related to singular values. Let the num-
berss1;s2;:::;snbe the singular values of A, and let us assume that s1is the
largest singular value and snis the smallest. We know that the (operator)
norm of an operator equals its largest singular value, so
kAk=s1;kA 1k=1
sn;
so
kAkkA 1k=s1
sn:
In other words
The condition number of a matrix equals to the ratio of the largest
and the smallest singular values.
184 6. Structure of operators in inner product spaces.
We deduced above thatkxk
kxkkA 1kkAkkbk
kbk. It is not hard to see
that this estimate is sharp, i.e. that it is possible to pick the right side b
and the error bsuch that we have equality
kxk
kxk=kA 1kkAkkbk
kbk:
We just put b=w1and b=wn, where w1andwnare respectively the
rst and the last column of the matrix Win the singular value decomposition
A=WV, and6= 0 is an arbitrary scalar. Here, as usual, the singular
values are assumed to be in non-increasing order s1s2:::sn, sos1
is the largest and snis the smallest eigenvalue.
We leave the details as an exercise for the reader.
A matrix is called well conditioned if its condition number is not too big.
If the condition number is big, the matrix is called ill conditioned. What is
\big" here depends on the problem: with what precision you can nd your
right side, what precision is required for the solution, etc.
4.4. Eective rank of a matrix. Theoretically, the rank of a matrix is
easy to compute: one just needs to row reduce matrix and count pivots.
However, in practical applications not everything is so easy. The main rea-
son is that very often we do not know the exact matrix, we only know its
approximation up to some precision.
Moreover, even if we know the exact matrix, most computer programs
introduce round-o errors in the computations, so eectively we cannot dis-
tinguish between a zero pivot and a very small pivot.
A simple na ve idea of working with round-o errors is as follows. When
computing the rank (and other objects related to it, like column space,
kernel, etc) one simply sets up a tolerance (some small number) and if the
pivot is smaller than the tolerance, count it as zero. The advantage of
this approach is its simplicity, since it is very easy to program. However,
the main disadvantage is that is is impossible to see what the tolerance is
responsible for. For example, what do we lose is we set the tolerance equal
to 10 6? How much better will 10 8be?
While the above approach works well for well conditioned matrices, it is
not very reliable in the general case.
A better approach is to use singular values. It requires more computa-
tions, but gives much better results, which are easier to interpret. In this
approach we also set up some small number as a tolerance, and then per-
form singular value decomposition. Then we simply treat singular values
smaller than the tolerance as zero. The advantage of this approach is that
we can see what we are doing. The singular values are the half-axes of the
4. Applications of the singular value decomposition. 185
ellipsoidA(B) (Bis the closed unit ball), so by setting up the tolerance we
just deciding how \thin" the ellipsoid should be to be considered \at".
4.5. Moore{Penrose (pseudo)inverse. As we discussed in Section 4 of
Chapter 5 above, the least square solution gives us, in the case when an
equationAx=bdoes not have a solutions, the \next best thing" (and
gives us the solution of Ax=bwhen it exists).
Note, that the question of uniqueness is not addressed by the least square
solution: a solution of the normal equation AAx=Abdoes not have to
be unique. A natural distinguished solution would be a solution of minimal
norm; such a solution is indeed unique, and can be obtained by taking
an arbitrary solution and then taking its projection onto (Ker AA)?=
(KerA)?, see problems 4.5 and 4.6 in Chapter 5.
It is not hard to see that if A=fWeeVis a reduced singular value
decomposition of A, then the minimal norm least square solution x0is given
by
x0=eVe 1fWb: (4.2)
Indeed, x0is a least square solution of Ax=b(i.e. a solution of Ax=
PRanAb):
Ax0=fWeeVeVe 1fWb=fWee 1fWb=fWfWb=PRanAb;
in the last equality in the chain we used the fact that fWfW=P
RanfW
(P
RanfW=fW(fWfW) 1fW=fWfW) and that Ran fW= RanA(see Prob-
lem 4.4 below).
The general solution of Ax=PRanAbis given by
x=x0+y; y2KerA;
sox0is indeed a unique minimal norm solution of Ax=PRanAb, or equiv-
alently, the minimal norm least square solution of Ax=b.
Denition 4.1. The operator A+:=eVe 1fW, whereA=fWeeVis a
reduced singular value decomposition of A, is called the Moore{Penrose in-
verse (orMoore{Penrose pseudoinverse ) of the operator A. In other words,
theMoore{Penrose inverse is the operator giving the unique least square
solution of Ax=b.
Remark 4.2. In the literature the Moore{Penrose inverse is usually dened
as a matrix A+such that
1.AA+A=A;
2.A+AA+=A+;
3. (AA+)=AA+;
186 6. Structure of operators in inner product spaces.
4. (A+A)=A+A.
It is very easy to check that the operator A+:=eVe 1fWsatises
properties 1{4 above.
It is also possible (although a bit harder) to show that an operator
A+satisfying properties 1{4 is unique. Indeed, right and left multiplying
identity 1 by A+, we get that ( A+A)2=A+Aand (AA+)2=AA+; together
with properties 3 and 4 this means that A+AandAA+ore orthogonal
projections (see Problem 5.6 in Capter 5).
Trivially, Ker AKerA+A. On the other hand, identity 1 implies that
KerA+AKerA(why?), so Ker A+A= KerA. But this means that A+A
is the orthogonal projection onto (Ker A)?= RanA,
A+A=PRanA:
Property 1 also implies that AA+y=yfor all y2RanA. SinceAA+
is an orthogonal projection, we conclude that Ran ARanAA+. The
opposite inclusion Ran AA+RanAis trivial, so AA+is the orthogonal
projection onto Ran A,
AA+=PRanA:
KnowingA+AandAA+we can rewrite property 2 as
PRanAA+=A+orA+PRanA=A+:
Combining the above identities we get
PRanAA+PRanA=A+:
Finally, for any bin the target space of A
x0:=A+b=PRanAA+b2RanA
and
Ax0=AA+b=PRanAb;
i.e.x0is a least square solution of Ax=b. Since x02RanA= (KerA)?,
x0is, as we discussed above, the least square solution of minimal norm. But,
as we had shown before, such minimal norm solution is given by (4.2), so
A+=eVe 1fW. 
Exercises.
4.1. Find norms and condition numbers for the following matrices:
a)A=4 0
1 3
.
b)A=5 3
 3 3
.
5. Structure of orthogonal matrices 187
For the matrix Afrom part a) present an example of the right side band the
error bsuch that
kxk
kxk=kAkkA 1kkbk
kbk;
hereAx=bandAx=b.
4.2. LetAbe a normal operator, and let 1;2;:::;nbe its eigenvalues (counting
multiplicities). Show that singular values of Aarej1j;j2j;:::;jnj.
4.3. Find singular values, norm and condition number of the matrix
A=0
@2 1 1
1 2 1
1 1 21
A
You can do this problem practically without any computations, if you use the
previous problem and can answer the following questions:
a) What are singular values (eigenvalues) of an orthogonal projection PEonto
some subspace E?
b) What is the matrix of the orthogonal projection onto the subspace spanned
by the vector (1 ;1;1)T?
c) How the eigenvalues of the operators TandaT+bI, whereaandbare
scalars, are related?
Of course, you can also just honestly do the computations.
4.4. LetA=fWeeVbe a reduced singular value decomposition of A. Show that
RanA= RanfW, and then by taking adjoint that Ran A= RaneV.
4.5. Write a formula for the Moore{Penrose inverse A+in terms of the singular
value decomposition A=WV.
4.6. Tychonov's regularization: Prove that the Moore{Penrose inverse A+can be
computed as the limits
A+= lim
"!0+(AA+"I) 1A= lim
"!0+A(AA+"I) 1:
5. Structure of orthogonal matrices
An orthogonal matrix Uwith detU= 1 is often called a rotation. The
theorem below explains this name.
Theorem 5.1. LetUbe an orthogonal operator in Rnand let detU= 1.2
Then there exists an orthonormal basis v1;v2;:::;vnsuch that the matrix
2For an orthogonal matrix UdetU=1.
188 6. Structure of operators in inner product spaces.
ofUin this basis has the block diagonal form
0
BBBBB@R'1
R'20
...
R'k 0In 2k1
CCCCCA;
whereR'kare2-dimensional rotations,
R'k=cos'k sin'k
sin'kcos'k
andIn 2kstands for the identity matrix of size (n 2k)(n 2k).
Proof. We know that if pis a polynomial with real coecient and is its
complex root, p() = 0, then is a root of pas well,p() = 0 (this can
easily be checked by plugging intop(z) =Pn
k=0akzk).
Therefore, all complex eigenvalues of a real matrix Acan be split into
pairsk,k.
We know, that eigenvalues of a unitary matrix have absolute value 1,
so all complex eigenvalues of Acan be written as k= cosk+isink,
k= cosk isink.
Fix a pair of complex eigenvalues and, and let u2Cnbe the
eigenvector of U,Uu=u. ThenUu=u. Now, split uinto real and
imaginary parts, i.e. dene
x:= Re u= (u+u)=2; y= Im u= (u u)=(2i);
sou=x+iy(note, that x;yare real vectors, i.e. vectors with real entries).
Then
Ux=U1
2(u+u) =1
2(u+u) = Re(u):
Similarly,
Uy=1
2iU(u u) =1
2i(u u) = Im(u):
Since= cos+isin, we have
u= (cos+isin)(x+iy) = ((cos)x (sin)y)+i((cos)y+(sin)x):
so
Ux= Re(u) = (cos)x (sin)y; U y= Im(u) = (cos)y+(sin)x:
In other word, Uleaves the 2-dimensional subspace Espanned by the vec-
torsx;yinvariant and the matrix of the restriction of Uonto this subspace
5. Structure of orthogonal matrices 189
is the rotation matrix
R =cossin
 sincos
:
Note, that the vectors uandu(eigenvectors of a unitary matrix, cor-
responding to dierent eigenvalues) are orthogonal, so by the Pythagorean
Theorem
kxk=kyk=p
2
2kuk:
It is easy to check that x?y, sox;yis an orthogonal basis in E. If we
multiply each vector in the basis x;yby the same non-zero number, we do
not change matrices of linear transformations, so without loss of generality
we can assume that kxk=kyk= 1 i.e. that x;yis an orthogonal basis in
E.
Let us complete the orthonormal system v1=x;v2=yto an orthonor-
mal basis in Rn. SinceUEE, i.e.Eis an invariant subspace of U, the
matrix ofUin this basis has the block triangular form
0
BB@R 
0U11
CCA
where 0stands for the ( n 2)2 block of zeroes.
Since the rotation matrix R is invertible, we have UE=E. There-
fore
UE=U 1E=E;
so the matrix of Uin the basis we constructed is in fact block diagonal,
0
BB@R  0
0U11
CCA:
SinceUis unitary
I=UU=0
BB@I 0
0U
1U11
CCA;
so, sinceU1is square, it is also unitary.
IfU1has complex eigenvalues we can apply the same procedure to de-
crease its size by 2 until we are left with a block that has only real eigenval-
ues. Real eigenvalues can be only +1 or  1, so in some orthonormal basis
190 6. Structure of operators in inner product spaces.
the matrix of Uhas the form
0
BBBBBBBB@R 1
R 20
...
R d
 Ir 0Il1
CCCCCCCCA;
hereIrandIlare identity matrices of size rrandllrespectively. Since
detU= 1, the multiplicity of the eigenvalue  1 (i.e.r) must be even.
Note, that the 2 2 matrix I2can be interpreted as the rotation
through the angle . Therefore, the above matrix has the form given in the
conclusion of the theorem with 'k= kor'k= 
Let us give a dierent interpretation of Theorem 5.1. Dene Tjto be a
rotation thorough 'jin the plane spanned by the vectors vj,vj+1. Then
Theorem 5.1 simply says that Uis the composition of the rotations Tj,j=
1;2;:::;k . Note, that because the rotations Tjact in mutually orthogonal
planes, they commute, i.e. it does not matter in what order we take the
composition. So, the theorem can be interpreted as follows:
Any rotation in Rncan be represented as a composition of at most
n=2 commuting planar rotations.
If an orthogonal matrix has determinant  1, its structure is described
by the following theorem.
Theorem 5.2. LetUbe an orthogonal operator in Rn, and let detU=
 1.Then there exists an orthonormal basis v1;v2;:::;vnsuch that the ma-
trix ofUin this basis has block diagonal form
0
BBBBBBB@R'1
R'20
...
R'k
Ir0  11
CCCCCCCA;
wherer=n 2k 1andR'kare2-dimensional rotations,
R'k=cos'k sin'k
sin'kcos'k
andIn 2kstands for the identity matrix of size (n 2k)(n 2k).
5. Structure of orthogonal matrices 191
We leave the proof as an exercise for the reader. The modication that
one should make to the proof of Theorem 5.1 are pretty obvious.
Note, that it follows from the above theorem that an orthogonal 2 2
matrixUwith determinant  1 is always a reection.
Let us now x an orthonormal basis, say the standard basis in Rn.
We call an elementary rotation3a rotation in the xj-xkplane, i.e. a linear
transformation which changes only the coordinates xjandxk, and it acts
on these two coordinates as a plane rotation.
Theorem 5.3. Any rotation U(i.e. an orthogonal transformation Uwith
detU= 1) can be represented as a product at most n(n 1)=2elementary
rotations.
To prove the theorem we will need the following simple lemmas.
Lemma 5.4. Letx= (x1;x2)T2R2. There exists a rotation RofR2
which moves the vector xto the vector (a;0)T, wherea=p
x1
1+x2
2.
The proof is elementary, and we leave it as an exercise for the reader.
One can just draw a picture or/and write a formula for R.
Lemma 5.5. Letx= (x1;x2;:::;xn)T2Rn. There exist n 1elementary
rotationsR1;R2;:::;Rn 1such thatRn 1:::;R 2R1x= (a;0;0;:::; 0)T,
wherea=p
x2
1+x2
2+:::+x2n.
Proof. The idea of the proof of the lemma is very simple. We use an
elementary rotation R1in thexn 1-xnplane to \kill" the last coordinate of
x(Lemma 5.4 guarantees that such rotation exists). Then use an elementary
rotationR2inxn 2-xn 1plane to \kill" the coordinate number n 1 ofR1x
(the rotation R2does not change the last coordinate, so the last coordinate
ofR2R1xremains zero), and so on. . .
For a formal proof we will use induction in n. The case n= 1 is trivial,
since any vector in R1has the desired form. The case n= 2 is treated by
Lemma 5.4.
Assuming now that Lemma is true for n 1, let us prove it for n. By
Lemma 5.4 there exists a 2 2 rotation matrix Rsuch that
Rxn 1
xn
=an 1
0
;
wherean 1=q
x2
n 1+x2n. So if we dene the nnelementary rotation
R1by
R1=In 20
0R
3This term is not widely accepted.
192 6. Structure of operators in inner product spaces.
(In 2is (n 2)(n 2) identity matrix), then
R1x= (x1;x2;:::;xn 2;an 1;0)T:
We assumed that the conclusion of the lemma holds for n 1, so there
existn 2 elementary rotations (let us call them R2;R3;:::;Rn 1) inRn 1
which transform the vector ( x1;x2;:::;xn 1;an 1)T2Rn 1to the vector
(a;0;:::; 0)T2Rn 1. In other words
Rn 1:::R 3R2(x1;x2;:::;xn 1;an 1)T= (a;0;:::; 0)T:
We can always assume that the elementary rotations R2;R3;:::;Rn 1
act in Rn, simply by assuming that they do not change the last coordinate.
Then
Rn 1:::R 3R2R1x= (a;0;:::; 0)T2Rn:
Let us now show that a=p
x2
1+x2
2+:::+x2n. It can be easily checked
directly, but we apply the following indirect reasoning. We know that or-
thogonal transformations preserve the norm, and we know that a0.
But, then we do not have any choice, the only possibility for aisa=p
x2
1+x2
2+:::+x2n. 
Lemma 5.6. LetAbe annnmatrix with real entries. There exist el-
ementary rotations R1;R2;:::;RN,Nn(n 1)=2such that the matrix
B=RN:::R 2R1Ais upper triangular, and, moreover, all its diagonal en-
tries except the last one Bn;nare non-negative.
Proof. We will use induction in n. The case n= 1 is trivial, since we can
say that any 11 matrix is of desired form.
Let us consider the case n= 2. Let a1be the rst column of A. By
Lemma 5.4 there exists a rotation Rwhich \kills" the second coordinate of
a1, making the rst coordinate non-negative. Then the matrix B=RAis
of desired form.
Let us now assume that lemma holds for ( n 1)(n 1) matrices,
and we want to prove it for nnmatrices. For the nnmatrixAleta1
be its rst column. By Lemma 5.5 we can nd n 1 elementary rotations
(sayR1;R2;:::;Rn 1which transform a1into (a;0;:::; 0)T. So, the matrix
Rn 1:::R 2R1Ahas the following block triangular form
Rn 1:::R 2R1A=a
0A1
;
whereA1is an (n 1)(n 1) block.
We assumed that lemma holds for n 1, soA1can be transformed by at
most (n 1)(n 2)=2 rotations into the desired upper triangular form. Note,
that these rotations act in Rn 1(only on the coordinates x2;x3;:::;xn), but
6. Orientation 193
we can always assume that they act on the whole Rnsimply by assuming
that they do not change the rst coordinate. Then, these rotations do not
change the vector ( a;0;:::; 0)T(the rst column of Rn 1:::R 2R1A), so the
matrixAcan be transformed into the desired upper triangular form by at
mostn 1 + (n 1)(n 2)=2 =n(n 1)=2 elementary rotations. 
Proof of Theorem 5.3. By Lemma 5.5 there exist elementary rotations
R1;R2;:::;RNsuch that the matrix U1=RN:::R 2R2Uis upper triangular,
and all diagonal entries, except maybe the last one, are non-negative.
Note, that the matrix U1is orthogonal. Any orthogonal matrix is nor-
mal, and we know that an upper triangular matrix can be normal only if it
is diagonal. Therefore, U1is a diagonal matrix.
We know that an eigenvalue of an orthogonal matrix can either be 1 or
 1, so we can have only 1 or  1 on the diagonal of U1. But, we know that
all diagonal entries of U1, except may be the last one, are non-negative, so
all the diagonal entries of U1, except may be the last one, are 1. The last
diagonal entry can be 1.
Since elementary rotations have determinant 1, we can conclude that
detU1= detU= 1, so the last diagonal entry also must be 1. So U1=I,
and therefore Ucan be represented as a product of elementary rotations
U=R 1
1R 1
2:::R 1
N. Here we use the fact that the inverse of an elementary
rotation is an elementary rotation as well. 
6. Orientation
6.1. Motivation. In Figures 1, 2 below we see 3 orthonormal bases in R2
andR3respectively. In each gure, the basis b) can be obtained from the
standard basis a) by a rotation, while it is impossible to rotate the standard
basis to get the basis c) (so that ekgoes to vk8k).
You have probably heard the word \orientation" before, and you prob-
ably know that bases a) and b) have positive orientation, and orientation of
the bases c) is negative. You also probably know some rules to determine
e1e2
v1v2 v1
v2
a) b) c)
Figure 1. Orientation in R2
194 6. Structure of operators in inner product spaces.
the orientation, like the right hand rule from physics. So, if you can seea
basis, say in R3, you probably can say what orientation it has.
But what if you only given coordinates of the vectors v1;v2;v3? Of
course, you can try to draw a picture to visualize the vectors, and then to
see what the orientation is. But this is not always easy. Moreover, how do
you \explain" this to a computer?
It turns out that there is an easier way. Let us explain it. We need to
check whether it is possible to get a basis v1;v2;v3inR3by rotating the
standard basis e1;e2;en. There is unique linear transformation Usuch that
Uek=vk; k = 1;2;3;
its matrix (in the standard basis) is the matrix with columns v1;v2;v3. It
is an orthogonal matrix (because it transforms an orthonormal basis to an
orthonormal basis), so we need to see when it is rotation. Theorems 5.1 and
5.2 give us the answer: the matrix Uis a rotation if and only if det U= 1.
Note, that (for 3 3 matrices) if det U= 1, thenUis the composition of
a rotation about some axis and a reection in the plane of rotation, i.e. in
the plane orthogonal to this axis.
This gives us a motivation for the formal denition below.
6.2. Formal denition. LetAandBbe two bases in a realvector space
X. We say that the bases AandBhave the same orientation, if the change
of coordinates matrix [ I]B;Ahas positive determinant, and say that they
have dierent orientations if the determinant of [ I]B;Ais negative.
Note, that since [ I]A;B= [I] 1
B;A, one can use the matrix [ I]A;Bin the
denition.
We usually assume that the standard basis e1;e2;:::;eninRnhas pos-
itive orientation. In an abstract space one just needs to x a basis and
declare that its orientation is positive.
e1e3
e2
v1v2v3
v1
v2v3
a) b) c)
Figure 2. Orientation in R3
6. Orientation 195
If an orthonormal basis v1;v2;:::;vninRnhas positive orientation
(i.e. the same orientation as the standard basis) Theorems 5.1 and 5.2 say
that the basis v1;v2;:::;vnis obtained from the standard basis by a rota-
tion.
6.3. Continuous transformations of bases and orientation.
Denition. We say that a basis A=fa1;a2;:::;angcan be continuously
transformed to a basis B=fb1;b2;:::;bngif there exists a continuous
family of basesV(t) =fv1(t);v2(t);:::;vn(t)g,t2[a;b] such that
vk(a) =ak;vk(b) =bk; k = 1;2:::;n:
\Continuous family of bases" mean that the vector-functions vk(t) are con-
tinuous (their coordinates in some bases are continuous functions) and,
which is essential, the system v1(t);v2(t);:::;vn(t) is a basis for all t2[a;b].
Note, that performing a change of variables, we can always assume, if
necessary that [ a;b] = [0;1].
Theorem 6.1. Two basesA=fa1;a2;:::;angandB=fb1;b2;:::;bng
have the same orientation, if and only if one of the bases can be continuously
transformed to the other.
Proof. Suppose the basis Acan be continuously transformed to the basis
B, and letV(t),t2[a;b] be a continuous family of bases, performing this
transformation. Consider a matrix-function V(t) whose columns are the
coordinate vectors [ vk(t)]Aofvk(t) in the basisA.
Clearly, the entries of V(t) are continuous functions and V(a) =I,
V(b) = [I]A;B. Note, that because V(t) is always a basis, det V(t) is never
zero. Then, the Intermediate Value Theorem asserts that det V(a) and
detV(b) has the same sign. Since det V(a) = detI= 1, we can conclude
that
det[I]A;B= detV(b)>0;
so the basesAandBhave the same orientation.
To prove the opposite implication, i.e. the \only if" part of the theorem,
one needs to show that the identity matrix Ican be continuously trans-
formed through invertible matrices to any matrix Bsatisfying det B > 0.
In other words, that there exists a continuous matrix-function V(t) on an
interval [a;b] such that for all t2[a;b] the matrix V(t) is invertible and such
that
V(a) =I; V (b) =B:
We leave the proof of this fact as an exercise for the reader. There are several
ways to prove that, on of which is outlined in Problems 6.2|6.5 below. 
196 6. Structure of operators in inner product spaces.
Exercises.
6.1. LetRbe the rotation through , so its matrix in the standard basis iscos sin
sin cos
:
Find the matrix of Rin the basis v1;v2, where v1=e2,v2=e1.
6.2. LetRbe the rotation matrix
R=cos sin
sin cos
:
Show that the 22 identity matrix I2can be continuously transformed through
invertible matrices into R.
6.3. LetUbe annnorthogonal matrix, and let det U > 0. Show that the nn
identity matrix Incan be continuously transformed through invertible matrices into
U.Hint: Use the previous problem and representation of a rotation in Rnas a
product of planar rotations, see Section 5.
6.4. LetAbe annnpositive denite Hermitian matrix, A=A>0. Show that
thennidentity matrix Incan be continuously transformed through invertible
matrices into A.Hint: What about diagonal matrices?
6.5. Using polar decomposition and Problems 6.3, 6.4 above, complete the proof
of the \only if" part of Theorem 6.3
Chapter 7
Bilinear and quadratic
forms
While the study of realquadratic forms (i.e. real homogeneous polynomials
of degree 2) was probably the initial motivation for the subject of this chap-
ter, complex quadratic forms ( Ax;x),x2Cn,A=Aare also of signicant
interest. So, unless otherwise specied, result and calculations hold in both
real and complex case.
To avoid writing twice essentially the same formulas, we use the notation
adapted to the complex case: in particular, in the real case the notation A
is used instead of AT.
1. Main denition
1.1. Bilinear forms on Rn.A bilinear form on Rnis a function L=
L(x;y) of two arguments x;y2Rnwhich is linear in each argument, i.e. such
that
1.L(x1+x2;y) =L(x1;y) +L(x2;y);
2.L(x;y1+y2) =L(x;y1) +L(x;y2).
One can consider bilinear form whose values belong to an arbitrary vector
space, but in this book we only consider forms that take real values.
Ifx= (x1;x2;:::;xn)Tandy= (y1;y2;:::;yn)T, a bilinear form can be
written as
L(x;y) =nX
j;k=1aj;kxkyj;
197
198 7. Bilinear and quadratic forms
or in matrix form
L(x;y) = (Ax;y)
where
A=0
BBB@a1;1a1;2::: a 1;n
a2;1a2;2::: a 2;n
............
an;1an;2::: an;n1
CCCA:
The matrix Ais determined uniquely by the bilinear form L.
1.2. Quadratic forms on Rn.There are several equivalent denition of
a quadratic form.
One can say that a quadratic form on Rnis the \diagonal" of a bilinear
formL, i.e. that any quadratic form Qis dened by Q[x] =L(x;x) =
(Ax;x).
Another, more algebraic way, is to say that a quadratic form is a homo-
geneous polynomial of degree 2 , i.e. thatQ[x] is a polynomial of nvariables
x1;x2;:::;xnhaving only terms of degree 2. That means that only terms
ax2
kandcxjxkare allowed.
There many ways (in fact, innitely many) to write a quadratic form
Q[x] asQ[x] = (Ax;x). For example, the quadratic form Q[x] =x2
1+
x2
2 4x1x2onR2can be represented as ( Ax;x) whereAcan be any of the
matrices1 4
0 1
;1 0
 4 1
;1 2
 2 1
:
In fact, any matrix Aof form
1a 4
 a 1
will work.
But if we require the matrix Ato be symmetric, then such a matrix is
unique:
Any quadratic form Q[x] onRnadmits unique representation
Q[x] = (Ax;x) whereAis a (real) symmetric matrix.
For example, for the quadratic form
Q[x] =x2
1+ 3x2
2+ 5x2
3+ 4x1x2 16x1x3+ 7x2x3
onR3, the corresponding symmetric matrix Ais
0
@1 2 8
2 3 3:5
 8 3:5 51
A:
1. Main denition 199
1.3. Quadratic forms on Cn.One can also dene a quadratic form onCn
(or any complex inner product space) by taking a self-adjoint transformation
A=Aand dening QbyQ[x] = (Ax;x). While our main examples will
be inRn, all the theorems are true in the setting of Cnas well. Bearing this
in mind, we will always use Ainstead ofAT
The only essential dierence with the real case is that in the complex
case we do not have any freedom of choice: if the quadratic form is real, the
corresponding matrix has to be Hermitian (self-adjoint).
Note that if A=Athen
(Ax;x) = (x;Ax) = (x;Ax) =(Ax;x);
so (Ax;x)2R.
The converse is also true.
Lemma 1.1. Let(Ax;x)be real for all x2Cn. ThenA=A.
We leave the proof as an exercise for the reader, see Problem 1.4 below.
One of the possible ways to prove Lemma 1.1 is to use the following
version of polarization identities.
Lemma 1.2. LetAbe an operator in an inner product space X.
1.IfXis a complex space, then for any x;y2X
(Ax;y) =1
4X
2C:4=1(A(x+y);x+y):
2.IfXis a real space and A=A, then any x;y2X
(Ax;y) =1
4h
(A(x+y);x+y) (A(x y);x y)i
:
For the proof of Lemma 1.2 see Exercise 6.3 in Chapter 5 above.
Exercises.
1.1. Find the matrix of the bilinear form LonR3,
L(x;y) =x1y1+ 2x1y2+ 14x1y3 5x2y1+ 2x2y2 3x2y3+ 8x3y1+ 19x3y2 2x3y3:
1.2. Dene the bilinear form LonR2by
L(x;y) = det[ x;y];
i.e. to compute L(x;y) we form a 22 matrix with columns x;yand compute its
determinant.
Find the matrix of L.
1.3. Find the matrix of the quadratic form QonR3
Q[x] =x2
1+ 2x1x2 3x1x3 9x2
2+ 6x2x3+ 13x2
3:
200 7. Bilinear and quadratic forms
1.4. Prove Lemma 1.1 above.
Hint: Use the polarization identity, see Lemma 1.2. Alternatively, you can
consider the expression ( A(x+zy);x+zy) and show that if it is real for all z2C
then (Ax;y) =(y;Ax).
2. Diagonalization of quadratic forms
You have probably met quadratic forms before, when you studied second
order curves in the plane. Maybe you even studied the second order surfaces
inR3.
We want to present a unied approach to classication of such objects.
Suppose we are given a set in Rndened by the equation Q[x] = 1, where
Qis some quadratic form. If Qhas some simple form, for example if the
corresponding matrix is diagonal, i.e. if Q[x] =a1x2
1+a2x2
2+:::+anx2
n, we
can easily visualize this set, especially if n= 2;3. In higher dimensions, it
is also possible, if not to visualize, then to understand the structure of the
set very well.
So, if we are given a general, complicated quadratic form, we want to
simplify it as much as possible, for example to make it diagonal. The stan-
dard way of doing that is the change of variables.
2.1. Orthogonal diagonalization. Let us have a quadratic form Q[x] =
(Ax;x) inFn(FisRorC). Introduce new variables y= (y1;y2;:::;yn)T2
Fn, with y=S 1x, whereSis some invertible nnmatrix, so x=Sy.
Then,
Q[x] =Q[Sy] = (ASy;Sy) = (SASy;y);
so in the new variables ythe quadratic form has matrix SAS.
So, we want to nd an invertible matrix Ssuch that the matrix SAS
is diagonal. Note, that it is dierent from the diagonalization of matrices
we had before: we tried to represent a matrix AasA=SDS 1, so the
matrixD=S 1ASwas diagonal. However, for unitary matrices U, we
haveU=U 1, and we can orthogonally diagonalize symmetric matrices.
So we can apply the orthogonal diagonalization we studied before to the
quadratic forms.
Namely, we can represent the matrix AasA=UDU=UDU 1.
Recall, that Dis a diagonal matrix with eigenvalues of Aon the diagonal,
andUis the matrix of eigenvectors (we need to pick an orthogonal basis of
eigenvectors). Then D=UAU, so in the variables y=U 1xthe quadratic
form has diagonal matrix.
2. Diagonalization of quadratic forms 201
Let us analyze the geometric meaning of the orthogonal diagonaliza-
tion. The columns u1;u2;:::;unof the unitary matrix Uform an orthonor-
mal basis in Fn, let us call this basis B. The change of coordinate matrix
[I]S;Bfrom this basis to the standard one is exactly U. We know that
y= (y1;y2;:::;yn)T=U 1x, so the coordinates y1;y2;:::;yncan be inter-
preted as coordinates of the vector xin the new basis u1;u2;:::;un.
So, orthogonal diagonalization allows us to visualize very well the set
Q[x] = 1, or a similar one, as long as we can visualize it for diagonal matrices.
Example. Consider the quadratic form of two variables (i.e. quadratic form
onR2),Q(x;y) = 2x2+2y2+2xy. Let us describe the set of points ( x;y)T2
R2satisfyingQ(x;y) = 1.
The matrix AofQis
A=2 1
1 2
:
Orthogonally diagonalizing this matrix we can represent it as
A=U3 0
0 1
U; whereU=1p
21 1
1 1
;
or, equivalently
UAU=3 0
0 1
=:D:
The setfy: (Dy;y) = 1gis the ellipse with half-axes 1 =p
3 and 1. There-
fore the setfx2R2: (Ax;x) = 1g, is the same ellipse only in the basis
(1p
2;1p
2)T, ( 1p
2;1p
2)T, or, equivalently, the same ellipse, rotated =4.
2.2. Non-orthogonal diagonalization. Orthogonal diagonalization in-
volves computing eigenvalues and eigenvectors, so it may be dicult to do
without computers for large n. On the other hand, the non-orthogonal di-
agonalization, i.e. nding an invertible S(without requiring S 1=S) such
thatD=SASis diagonal, is much easier computationally and can be
done using only algebraic operations (addition, subtraction, multiplication,
division).
Below we present two most used methods of non-orthogonal diagonal-
ization.
2.2.1. Diagonalization by completion of squares. The rst methods is based
on completion of squares. We will illustrate this method on real quadratic
forms (forms on Rn). After simple modications this method could be used
in the complex case, but we will not discuss it here. If necessary, an inter-
ested reader should be able to to make the appropriate modications.
Let us again consider the quadratic form of two variables, Q[x] = 2x2
1+
2x1x2+ 2x2
2(it is the same quadratic form as in the above example, only
202 7. Bilinear and quadratic forms
here we call variables not x;ybutx1;x2). Since
2
x1+1
2x22
= 2
x2
1+ 2x11
2x2+1
4x2
2
= 2x2
1+ 2x1x2+1
2x2
2
(note, that the rst two terms coincide with the rst two terms of Q), we
get
2x2
1+ 2x1x2+ 2x2
2= 2
x1+1
2x22
+3
2x2
2= 2y2
1+3
2y2
2;
wherey1=x1+1
2x2andy2=x2.
The same method can be applied to quadratic form of more than 2
variables. Let us consider, for example, a form Q[x] inR3,
Q[x] =x2
1 6x1x2+ 4x1x3 6x2x3+ 8x2
2 3x2
3:
Considering all terms involving the rst variable x1(the rst 3 terms in this
case), let us pick a full square or a multiple of a full square which has exactly
these terms (plus some other terms).
Since
(x1 3x2+ 2x3)2=x2
1 6x1x2+ 4x1x3 12x2x3+ 9x2
2+ 4x2
3
we can rewrite the quadratic form as
(x1 3x2+ 2x3)2 x2
2+ 6x2x3 7x2
3:
Note, that the expression  x2
2+ 6x2x3 7x2
3involves only variables x2and
x3. Since
 (x2 3x3)2= (x2
2 6x2x3+ 9x2
3) = x2
2+ 6x2x3 9x2
3
we have
 x2
2+ 6x2x3 7x2
3= (x2 3x3)2+ 2x2
3:
Thus we can write the quadratic form Qas
Q[x] = (x1 3x2+ 2x3)2 (x2 3x3)2+ 2x2
3=y2
1 y2
2+ 2y2
3
where
y1=x1 3x2+ 2x3; y 2=x2 3x3; y 3=x3:
Finally, let us address the question that an attentive reader is probably
already asking: what to do if at some point we do have a product of two
variables, but no corresponding squares? For example, how to diagonalize
the formx1x2? The answer follows immediately from the identity
4x1x2= (x1+x2)2 (x1 x2)2; (2.1)
which gives us the representation
Q[x] =y2
1 y2
2; y 1= (x1+x2)=2; y2= (x1 x2)=2:
2. Diagonalization of quadratic forms 203
2.2.2. Diagonalization using row/column operations. There is another way
of performing non-orthogonal diagonalization of a quadratic form. The idea
is to perform row operations on the matrix Aof the quadratic form. The
dierence with the row reduction (Gauss{Jordan elimination) is that after
each row operation we need to perform the same column operation, the
reason for that being that we want to make the matrix SASdiagonal.
Let us explain how everything works on an example. Suppose we want
to diagonalize a quadratic form with matrix
A=0
@1 1 3
 1 2 1
3 1 11
A:
We augment the matrix Aby the identity matrix, and perform on the aug-
mented matrix ( AjI) row/column operations. After each row operation we
have to perform on the matrix Athe same column operation.1We get
0
@1 1 3 1 0 0
 1 2 1 0 1 0
3 1 1 0 0 11
A+R10
@1 1 3 1 0 0
0 1 4 1 1 0
3 1 1 0 0 11
A
0
@1 0 3 1 0 0
0 1 4 1 1 0
3 4 1 0 0 11
A
 3R10
@1 0 3 1 0 0
0 1 4 1 1 0
0 4 8 3 0 11
A
0
@1 0 0 1 0 0
0 1 4 1 1 0
0 4 8 3 0 11
A
 4R20
@1 0 0 1 0 0
0 1 4 1 1 0
0 0 24 7 4 11
A
0
@1 0 0 1 0 0
0 1 0 1 1 0
0 0 24 7 4 11
A:
Note, that we perform column operations only on the left side of the aug-
mented matrix
We get the diagonal Dmatrix on the left, and the matrix Son the
right, soD=SAS,
0
@1 0 0
0 1 0
0 0 241
A=0
@1 0 0
1 1 0
 7 4 11
A0
@1 1 3
 1 2 1
3 1 11
A0
@1 1 7
0 1 4
0 0 11
A:
Let us explain why the method works. A row operation is a left multipli-
cation by an elementary matrix. The corresponding column operation is
the right multiplication by the transposed elementary matrix. Therefore,
1In the case of complex Hermitian matrices we perform for each row operation the conjugate
o the corresponding column operation, see Remark 2.1 below
204 7. Bilinear and quadratic forms
performing row operations E1;E2;:::;ENand the same column operations
we transform the matrix Ato
(2.2) EN:::E 2E1AE
1E
2:::E
N=EAE:
As for the identity matrix in the right side, we performed only row operations
on it, so the identity matrix is transformed to
EN:::E 2E1I=EI=E:
If we now denote E=Swe get that SASis a diagonal matrix, and the
matrixE=Sis the right half of the transformed augmented matrix.
In the above example we got lucky, because we did not need to inter-
change two rows. This operation is a bit tricker to perform. It is quite
simple if you know what to do, but it may be hard to guess the correct row
operations. Let us consider, for example, a quadratic form with the matrix
A=0 1
1 0
If we want to diagonalize it by row and column operations, the simplest
idea would be to interchange rows 1 and 2. But we also must to perform
the same column operation, i.e. interchange columns 1 and 2, so we will end
up with the same matrix.
So, we need something more non-trivial. The identity (2.1), for example,
can be used to diagonalize this quadratic form. However, a simpler idea also
works: use row operations to get a non-zero entry on the diagonal! For
example, if we start with making a1;1non-zero, the following series of row
(and the corresponding column) operations is one of the possible choices:
0 1 1 0
1 0 0 1+1
2R21=2 1 1 1=2
1 0 0 1

1 1 1 1=2
1 0 0 1
 R11 1 1 1=2
0 1 1 1=2

1 0 1 1=2
0 1 1 1=2
:
Remark. Non-orthogonal diagonalization gives us a simple description of
a setQ[x] = 1 in a non-orthogonal basis. It is harder to visualize, than the
representation given by the orthogonal diagonalization. However, if we are
not interested in the details, for example if it is sucient for us just to know
that the set is an ellipsoid (or hyperboloid, etc), then the non-orthogonal
diagonalization is an easier way to get the answer.
Remark 2.1. For quadratic forms with complex entries (i.e. for forms
(Ax;x),A=A), the non-orthogonal diagonalization works the same way
2. Diagonalization of quadratic forms 205
as in the real case, with the only dierence, that the corresponding \column
operations" have the complex conjugate coecients.
The reason for that is that if a row operation is given by left multiplica-
tion by an elementary matrix Ek, then the corresponding column operation
is given by the right multiplication by E
k, see (2.2).
Note that formula (2.2) works in both complex and reals cases: in real
case we could write ET
kinstead ofE
k, but using Hermitian adjoint allows
us to have the same formula in both cases.
206 7. Bilinear and quadratic forms
Exercises.
2.1. Diagonalize the quadratic form with the matrix
A=0
@1 2 1
2 3 2
1 2 11
A:
Use two methods: completion of squares and row operations. Which one do you
like better?
Can you say if the matrix Ais positive denite or not?
2.2. For the matrix A
A=0
@2 1 1
1 2 1
1 1 21
A
orthogonally diagonalize the corresponding quadratic form, i.e. nd a diagonal ma-
trixDand a unitary matrix Usuch thatD=UAU.
3. Silvester's Law of Inertia
As we discussed above, there are many ways to diagonalize a quadratic form.
Note, that a resulting diagonal matrix is not unique. For example, if we got
a diagonal matrix
D= diagf1;2;:::;ng;
we can take a diagonal matrix
S= diagfs1;s2;:::;sng; sk2R; sk6= 0
and transform Dto
SDS= diagfs2
11;s2
22;:::;s2
nng:
This transformation changes the diagonal entries of D. However, it does not
change the signs of the diagonal entries. And this is always the case!
Namely, the famous Silvester's Law of Inertia states that:
For a Hermitian matrix A(i.e. for a quadratic form Q[x] =
(Ax;x)) and any of its diagonalization D=SAS, the number
of positive (negative, zero) diagonal entries of Ddepends only on
A, but not on a particular choice of diagonalization.
Here we of course assume that Sis an invertible matrix, and Dis a diagonal
one.
The idea of the proof of the Silvester's Law of Inertia is to express the
number of positive (negative, zero) diagonal entries of a diagonalization
D=SASin terms of A, not involving SorD.
We will need the following denition.
3. Silvester's Law of Inertia 207
Denition. Given annnHermitian matrix A=A(a quadratic form
Q[x] = (Ax;x) onFn) we call a subspace EFnpositive (resp. negative ,
resp. neutral ) if
(Ax;x)>0 (resp. ( Ax;x)<0;resp. (Ax;x) = 0)
for all x2E,x6=0.
Sometimes, to emphasize the role of Awe will sayA-positive (Anegative,
A-neutral).
Theorem 3.1. LetAbe annnHermitian matrix, and let D=SASbe
its diagonalization by an invertible matrix S. Then the number of positive
(resp. negative) diagonal entries of Dcoincides with the maximal dimension
of anA-positive (resp. A-negative) subspace.
The above theorem says that if r+is the number of positive diagonal
entries ofD, then there exists an A-positive subspace Eof dimension r+,
but it is impossible to nd a positive subspace Ewith dimE >r +.
We will need the following lemma, which can be considered a particular
case of the above theorem.
Lemma 3.2. LetDbe a diagonal matrix D= diagf1;2;:::;ng. Then
the number of positive (resp. negative) diagonal entries of Dcoincides with
the maximal dimension of a D-positive (resp. D-negative) subspace.
Proof. By rearranging the standard basis in Fn(changing the numeration)
we can always assume without loss of generality that the positive diagonal
entries ofDare the rst r+diagonal entries.
Consider the subspace E+spanned by the rst r+coordinate vectors
e1;e2;:::;er+. ClearlyE+is aD-positive subspace, and dim E+=r+.
Let us now show that for any other D-positive subspace Ewe have
dimEr+. Consider the orthogonal projection P=PE+,
Px= (x1;x2;:::;xr+;0:::;0)T; x= (x1;x2;:::;xn)T:
For aD-positive subspace Edene an operator T:E!E+by
Tx=Px;8x2E:
In other words, Tis the restriction of the projection P:Pis dened on
the whole space, but we restricted its domain to Eand target space to E+.
We got an operator acting from EtoE+, and we use a dierent letter to
distinguish it from P.
Note, that Ker T=f0g. Indeed, let for x= (x1;x2;:::;xn)T2Ewe
haveTx=Px=0. Then, by the denition of P
x1=x2=:::=xr+= 0;
208 7. Bilinear and quadratic forms
and therefore
(Dx;x) =nX
k=r++1kx2
k0 (k0 fork>r +):
Butxbelongs to a D-positive subspace E, so the inequality ( Dx;x)0
holds only for x=0.
Let us now apply the Rank Theorem (Theorem 7.1 from Chapter 2).
First of all, rank T= dim Ran TdimE+=r+because Ran TE+. By
the Rank Theorem, dim Ker T+ rankT= dimE. But we just proved that
KerT=f0g, i.e. that dim Ker T= 0, so
dimE= rankTdimE+=r+:
To prove the statement about negative entries, we just apply the above
reasoning to the matrix  D. 
Proof of Theorem 3.1. LetD=SASbe a diagonalization of A. Since
(Dx;x) = (SASx;x) = (ASx;Sx)
it follows that for any D-positive subspace E, the subspace SEis anA-
positive subspace. The same identity implies that for any A-positive sub-
spaceFthe subspace S 1FisD-positive.
SinceSandS 1are invertible transformations, dim E= dimSEand
dimF= dimS 1F. Therefore, for any Dpositive subspace Ewe can nd
anA-positive subspace (namely SE) of the same dimension, and vice versa:
for anyA-positive subspace Fwe can nd a D-positive subspace (namely
S 1F) of the same dimension. Therefore the maximal possible dimensions of
aA-positive and a D-positive subspace coincide, and the theorem is proved.
The case of negative diagonal entries treated similarly, we leave the
details as an exercise to the reader. 
4. Positive denite forms. Minimax characterization of
eigenvalues and the Silvester's criterion of positivity
Denition. A quadratic form Qis called
Positive denite if Q[x]>0 for all x6=0.
Positive semidenite if Q[x]0 for all x.
Negative denite if Q[x]<0 for all x6=0.
Negative semidenite if Q[x]0 for all x.
Indenite if it take both positive and negative values, i.e. if there
exist vectors x1andx2such thatQ[x1]>0 andQ[x2]<0.
4. Positive denite forms. Minimax. Silvester's criterion 209
Denition. A Hermitian matrix A=Ais called positive denite (negative
denite, etc. . . ) if the corresponding quadratic form Q[x] = (Ax;x) is
positive denite (negative denite, etc. . . ).
Theorem 4.1. LetA=A. Then
1.Ais positive denite i all eigenvalues of Aare positive.
2.Ais positive semidenite i all eigenvalues of Aare non-negative.
3.Ais negative denite i all eigenvalues of Aare negative.
4.Ais negative semidenite i all eigenvalues of Aare non-positive.
5.Ais indenite i it has both positive and negative eigenvalues.
Proof. The proof follows trivially from the orthogonal diagonalization. In-
deed, there is an orthonormal basis in which matrix of Ais diagonal, and
for diagonal matrices the theorem is trivial. 
Remark. Note, that to nd whether a matrix (a quadratic form) is positive
denite (negative denite, etc) one does not have to compute eigenvalues.
By Silvester's Law of Inertia it is sucient to perform an arbitrary, not
necessarily orthogonal diagonalization D=SASand look at the diagonal
entries ofD.
4.1. Silvester's criterion of positivity. It is an easy exercise to see that
a 22 matrix
A=a b
b c
is positive denite if and only if
(4.1) a>0 and det A=ac jbj2>0
Indeed, ifa>0 and detA=ac jbj2>0, thenc>0, so traceA=a+c>0.
So we know that if 1;2are eigenvalues of Athen12>0 (detA > 0)
and1+2= traceA > 0. But that only possible if both eigenvalues are
positive. So we have proved that conditions (4.1) imply that Ais positive
denite. The opposite implication is quite simple, we leave it as an exercise
for the reader.
This result can be generalized to the case of nnmatrices. Namely, for
a matrixA
A=0
BBB@a1;1a1;2::: a 1;n
a2;1a2;2::: a 2;n
............
an;1an;2::: an;n1
CCCA
210 7. Bilinear and quadratic forms
let us consider its all upper left submatrices
A1= (a1;1); A2=a1;1a1;2
a2;1a2;2
; A3=0
@a1;1a1;2a1;3
a2;1a2;2a2;3
a3;1a3;2a3;31
A;:::;An=A
Theorem 4.2 (Silvester's Criterion of Positivity) .A matrixA=Ais
positive denite if and only if
detAk>0 for allk= 1;2;:::;n:
First of all let us notice that if A>0 thenAk>0 also (can you explain
why?). Therefore, since all eigenvalues of a positive denite matrix are
positive, see Theorem 4.1, det Ak>0 for allk.
One can show that if det Ak>08kthen all eigenvalues of Aare posi-
tive by analyzing diagonalization of a quadratic form using row and column
operations, which was described in Section 2.2. The key here is the obser-
vation that if we perform row/column operations in natural order (i.e. rst
subtracting the rst row/column from all other rows/columns, then sub-
tracting the second row/columns from the rows/columns 3 ;4;:::;n , and so
on. . . ), and if we are not doing any row interchanges, then we automatically
diagonalize quadratic forms Akas well. Namely, after we subtract rst and
second rows and columns, we get diagonalization of A2; after we subtract
the third row/column we get the diagonalization of A3, and so on.
Since we are performing only row replacement we do not change the
determinant. Moreover, since we are not performing row exchanges and
performing the operations in the correct order, we preserve determinants of
Ak. Therefore, the condition det Ak>0 guarantees that each new entry in
the diagonal is positive.
Of course, one has to be sure that we can use only row replacements, and
perform the operations in the correct order, i.e. that we do not encounter
any pathological situation. If one analyzes the algorithm, one can see that
the only bad situation that can happen is the situation where at some step
we have zero in the pivot place. In other words, if after we subtracted the
rstkrows and columns and obtained a diagonalization of Ak, the entry in
thek+ 1st row and k+ 1st column is 0. We leave it as an exercise for the
reader to show that this is impossible. 
The proof we outlined above is quite simple. However, let us present, in
more detail, another one, which can be found in more advanced textbooks.
I personally prefer this second proof, for it demonstrates some important
connections.
We will need the following characterization of eigenvalues of a hermitian
matrix.
4. Positive denite forms. Minimax. Silvester's criterion 211
4.2. Minimax characterization of eigenvalues. Let us recall that the
codimension of a subspace EXis by the denition the dimension of its
orthogonal complement, codim E= dim(E?). Since for a subspace EX,
dimX=nwe have dim E+ dimE?=n, we can see that codim E=
dimX dimE.
Recall that the trivial subspace f0ghas dimension zero, so the whole
spaceXhas codimension 0.
Theorem 4.3 (Minimax characterization of eigenvalues) .LetA=Abe
annnmatrix, and let 12:::nbe its eigenvalues taken in the
decreasing order. Then
k= max
E:
dimE=kmin
x2E
kxk=1(Ax;x) = min
F:
codimF=k 1max
x2F
kxk=1(Ax;x):
Let us explain in more details what the expressions like max min and
min max mean. To compute the rst one, we need to consider all subspaces
Eof dimension k. For each such subspace Ewe consider the set of all x2E
of norm 1, and nd the minimum of ( Ax;x) over all such x. Thus for each
subspace we obtain a number, and we need to pick a subspace Esuch that
the number is maximal. That is the max min.
The min max is dened similarly.
Remark. A sophisticated reader may notice a problem here: why do the
maxima and minima exist? It is well known, that maximum and minimum
have a nasty habit of not existing: for example, the function f(x) =xhas
neither maximum nor minimum on the open interval (0 ;1).
However, in this case maximum and minimum do exist. There are two
possible explanations of the fact that ( Ax;x) attains maximum and mini-
mum. The rst one requires some familiarity with basic notions of analysis:
one should just say that the unit sphere in E, i.e. the setfx2E:kxk= 1g
is compact, and that a continuous function ( Q[x] = (Ax;x) in our case) on
a compact set attains its maximum and minimum.
Another explanation will be to notice that the function Q[x] = (Ax;x),
x2Eis a quadratic form on E. It is not dicult to compute the matrix
of this form in some orthonormal basis in E, but let us only note that this
matrix is not A: it has to be a kkmatrix, where k= dimE.
It is easy to see that for a quadratic form the maximum and minimum
over a unit sphere is the maximal and minimal eigenvalues of its matrix.
As for optimizing over all subspaces, we will prove below that the max-
imum and minimum do exist.
212 7. Bilinear and quadratic forms
Proof of Theorem 4.3. First of all, by picking an appropriate orthonor-
mal basis, we can assume without loss of generality that the matrix Ais
diagonal,A= diagf1;2;:::;ng.
Pick subspaces EandF, dimE=k, codimF=k 1, i.e. dimE=
n k+1. Since dim E+dimF >n , there exists a non-zero vector x02E\F.
By normalizing it we can assume without loss of generality that kx0k= 1.
We can always arrange the eigenvalues in decreasing order, so let us assume
that12:::n.
Since xbelongs to the both subspaces EandF
min
x2E
kxk=1(Ax;x)(Ax0;x0)max
x2F
kxk=1(Ax;x):
We did not assume anything except dimensions about the subspaces Eand
F, so the above inequality
(4.2) min
x2E
kxk=1(Ax;x)max
x2F
kxk=1(Ax;x):
holds for all pairs of EandFof appropriate dimensions.
Dene
E0:= spanfe1;e2;:::;ekg; F 0:= spanfek;ek+1;ek+2;:::;eng:
Since for a self-adjoint matrix B, the maximum and minimum of ( Bx;x) over
the unit spherefx:kxk= 1gare the maximal and the minimal eigenvalue
respectively (easy to check on diagonal matrices), we get that
min
x2E0
kxk=1(Ax;x) = max
x2F0
kxk=1(Ax;x) =k:
It follows from (4.2) that for any subspace E, dimE=k
min
x2E
kxk=1(Ax;x)max
x2F0
kxk=1(Ax;x) =k
and similarly, for any subspace Fof codimension k 1,
max
x2F
kxk=1(Ax;x)min
x2E0
kxk=1(Ax;x) =k:
But on subspaces E0andF0both maximum and minimum are k, so
min max = max min = k. 
Corollary 4.4 (Intertwining of eigenvalues) .LetA=A=faj;kgn
j;k=1
be a self-adjoint matrix, and let eA=faj;kgn 1
j;k=1be its submatrix of size
(n 1)(n 1). Let1;2;:::;nand1;2;:::;n 1be the eigenvalues
ofAandeArespectively, taken in decreasing order. Then
1122:::n 1n 1n:
4. Positive denite forms. Minimax. Silvester's criterion 213
i.e.
kkk+1; k = 1;2;:::;n 1
Proof. LeteXFnbe the subspace spanned by the rst n 1 basis vectors,
eX= spanfe1;e2;:::;en 1g. Since (eAx;x) = (Ax;x) for all x2eX, Theorem
4.3 implies that
k= max
EeX
dimE=kmin
x2E
kxk=1(Ax;x):
To getkwe need to get maximum over the set of all subspaces EofFn,
dimE=k, i.e. take maximum over a bigger set (any subspace of eXis a
subspace of Fn). Therefore
kk:
(the maximum can only increase, if we increase the set).
On the other hand, any subspace EeXof codimension k 1 (here
we mean codimension in eX) has dimension n 1 (k 1) =n k, so its
codimension in Fnisk. Therefore
k= min
EeX
dimE=n kmax
x2E
kxk=1(Ax;x) min
EFn
dimE=n kmax
x2E
kxk=1(Ax;x) =k+1
(minimum over a bigger set can only be smaller). 
Proof of Theorem 4.2. IfA> 0, thenAk>0 fork= 1;2;:::;n as well
(can you explain why?). Since all eigenvalues of a positive denite matrix
are positive (see Theorem 4.1), det Ak>0 for allk= 1;2;:::;n .
Let us now prove the other implication. Let det Ak>0 for allk. We
will show, using induction in k, that allAk(and soA=An) are positive
denite.
ClearlyA1is positive denite (it is 1 1 matrix, so A1= detA1).
Assuming that Ak 1>0 (and detAk>0) let us show that Akis positive
denite. Let 1;2;:::;kand1;2;:::;k 1be eigenvalues of Akand
Ak 1respectively. By Corollary 4.4
jj>0 forj= 1;2;:::;k 1:
Since detAk=12:::k 1k>0, the last eigenvalue kmust also be
positive. Therefore, since all its eigenvalues are positive, the matrix Akis
positive denite. 
4.3. Some remarks. First of all notice, that Silvester Criterion of Posi-
tivity does not generalize to positive semidenite matrices if n3, meaning
that fornnmatrices,n3, the conditions det Ak0 do not imply that
Ais positive semidenite, see Problem 4.6 below.
214 7. Bilinear and quadratic forms
For 22 matrices, however, the conditions det Ak0 imply that Ais
positive semidenite, see Problem 4.3 below. This sometimes leads to the
wrong conclusion about nnmatrices.
Finally, we should should say couple words about negative denite ma-
trices. It is a typical students' mistake to say that the condition det Ak<0
implies that Ais negative denite. But that is wrong!
To check if the matrix Ais negative denite, one just have to check
that the matrix Ais positive denite. Applying Silvester's Criterion of
Positivity to Aone can see that Ais negative denite if and only if
( 1)kdetAk>0 for allk= 1;2;:::;n .
Exercises.
4.1. Using Silvester's Criterion of Positivity check if the matrices
A=0
@4 2 1
2 3 1
1 1 21
A; B =0
@3 1 2
 1 4 2
2 2 21
A
are positive denite or not.
Are the matrices  A,A3andA 1,A+B 1,A+B,A Bpositive denite?
4.2. True or false:
a) IfAis positive denite, then A5is positive denite.
b) IfAis negative denite, then A8is negative denite.
c) IfAis negative denite, then A12is positive denite.
d) IfAis positive denite and Bis negative semidenite, then A Bis positive
denite.
e) IfAis indenite, and Bis positive denite, then A+Bis indenite.
4.3. LetAbe a 22 Hermitian matrix, such that a1;1>0, detA0. Prove that
Ais positive semidenite.
4.4. Find a real symmetric nnmatrix such that det Ak0 for allk= 1;2;:::;n ,
but the matrix Ais not positive semidenite. Try to nd an example for the minimal
possiblen.
4.5. LetAbe annnHermitian matrix such that det Ak>0 for allk=
1;2;:::;n 1 and detA0. Prove that Ais positive semidenite.
4.6. Find a real symmetric 3 3 matrixAsuch thata1;1>0, detAk0 for
k= 2;3, but the matrix Ais not positive semidenite.
5. Positive denite forms and inner products
LetVbe an inner product space and let B=v1;v2;:::;vnbe a basis (not
necessarily orthogonal) in V. LetG=fgj;kgn
j:k=1be the matrix dened by
gj;k= (vk;vj):
5. Positive denite forms and inner products 215
Ifx=P
kxkvkandy=P
kykvk, then
(x;y) =0
@X
kxkvk;X
jyjvj1
A=nX
k;j=1xkyj(vk;vj)
=nX
j=1nX
k=1gj;kxkyj= (G[x]B;[y]B)Cn;
where (;)Cnstands for the standard inner product in Cn. One can im-
mediately see that Gis a positive denite matrix (why?).
So, when one works with coordinates in an arbitrary (not necessarily
orthogonal) basis in an inner product space, the inner product (in terms of
coordinates) is not computed as the standard inner product in Cn, but with
the help of a positive denite matrix Gas described above.
Note, that this G-inner product coincides with the standard inner prod-
uct in Cnif and only if G=I, which happens if and only if the basis
v1;v2;:::;vnis orthonormal.
Conversely, given a positive denite matrix Gone can dene a non-
standard inner product ( G-inner product) in Cnby
(x;y)G:= (Gx;y)Cn; x;y2Cn:
One can easily check that ( x;y)Gis indeed an inner product, i.e. that prop-
erties 1{4 from Section 1.3 of Chapter 5 are satised.

Chapter 8
Dual spaces and
tensors
All vector spaces in this chapter are nite-dimensional.
1. Dual spaces
1.1. Linear functionals and the dual space. Change of coordinates
in the dual space.
Denition 1.1. A linear functional on a vector space V(over a eld F) is
a linear transformation L:V!F.
This special class of linear transformation suciently important to de-
serve a separate name.
If one thinks of vectors as of some physical objects, like force or velocity,
then one can think of a linear functional as a (linear) measurement, that
gives you some a scalar quantity as the result: think about force or velocity
in a given direction.
Denition 1.2. A collection of all linear functionals on a nite-dimensional1
vector space Vis called the dual ofVand is usually denoted as V0orV
As it was discussed earlier in Section 4 of Chapter 1, the collection
L(V;W ) of all linear transformations acting from VtoWis a vector space
1We consider here only nite-dimensional spaces because for innite-dimensional spaces the
dual space consists not of all but only of the so-called bounded linear functionals. Without giving
the precise denition, let us only mention than in the nite-dimensional case (both the domain
and the target space are nite-dimensional) all linear transformations are bounded, and we do not
need to mention the word bounded
217
218 8. Dual spaces and tensors
(with naturally dened operations of addition and multiplication by a scalar.
So, the dual space V0=L(V;F) is a vector space.
Let us consider an example. Let the space VbeRn, what is its dual? As
we know, a linear transformation T:Rn!Rmis represented by an mn
matrix, so a linear functional on Rn(i.e. a linear transformation L:Rn!R
is given by an 1nmatrix (row), let us denote it by [ L]. The collection
of all such rows is isomorphic to Rn(isomorphism is given by taking the
transpose [L]![L]T).
So, the dual of RnisRnitself. The same holds true for Cn, of course, as
well as for Fn, where Fis an arbitrary eld. Since the space Vover a eld
F(here we mostly interested in the case F=RorF=C) of dimension nis
isomorphic to Fn, and the dual to Fnis isomorphic to Fn, we can conclude
that the dual V0is isomorphic to V
Thus, the denition of the dual space is starting to look a bit silly, since
it does not appear to give us anything new.
However, that is not the case! If we look carefully, we can see that the
dual space is indeed a new object. To see that, let us analyze how the entries
of the matrix [ L] (which we can call the coordinates of L) change when we
change the basis in V.
1.1.1. Change of coordinates formula. Let
A=fa1;a2;:::;ang;B=fb1;b2;:::;bng
be two bases in V, and let [L]A= [L]S;Aand [L]B= [L]S;Bbe the matrices of
Lin the basesAandBrespectively (we suppose that the basis in the target
space of scalars is always the standard one, so we can skip the subscript S
in the notation). Then recalling the change of coordinate rule from Section
8.4 in Chapter 2 we get that
[L]B= [L]A[I]A;B:
Recall that for a vector v2Vits coordinates in dierent bases are related
by the formula
[v]B= [I]B;A[v]A;
and that
[I]A;B= [I] 1
B;A:
If we denote S:= [I]B;A, so [v]B=S[v]A, the entries of the vectors [ L]T
B
and [L]T
Aare related by the formula
(1.1) [ L]T
B= (S 1)T[L]T
A
(since we usually represent a vector as a column of its coordinates, we use
[L]T
Aand [L]T
Binstead of [L]Aand [L]B)
Saying it in words
1. Dual spaces 219
IfSis the change of coordinate matrix (from old coordinates to
the new ones) in X, then the change of coordinate matrix in the
dual space X0is (S 1)T.
So, the dual space V0ofVwhile isomorphic to Vis indeed a dierent
object: the dierence is in how the coordinates in VandV0change when
one changes the basis in V.
Remark. One can ask: why can't we pick a basis in Xand some completely
unrelated basis in the dual X0? Of course, we can do that, but imagine, what
would it take to compute L(x), knowing coordinates of xin some basis and
coordinates of Lin some completely unrelated basis.
So, if we want (knowing the coordinates of a vector xin some basis)
to compute the action of a linear functional Lusing the standard rules of
matrix algebra, i.e. to multiply a row (the functional) by a column (the
vector), we have no choice: the \coordinates" of the linear functional L
should be the entries of its matrix (in the same basis).
As we can see later, see Section 1.3 below, the entries (\coordinates")
of a linear functional are indeed the coordinates in some basis (the so-called
dual basis.
1.1.2. A uniqueness theorem.
Lemma 1.3. Letv2V. IfL(v) = 0 for allL2V0thenv= 0. As a
corollary, if L(v1) =L(v2)for allL2V0, then v1=v2
Proof. Fix a basisBinV. Then
L(v) = [L]B[v]B:
Picking dierent matrices (i.e. dierent L) we can easily see that [ v]B=0.
Indeed, if
Lk= [0;:::; 0;1
k;0;:::; 0]
then the equality
Lk[v]B= 0
implies that kth coordinate of [ v]Bis 0.
Using this equality for all kwe conclude that [ v]B=0, sov=0.
1.2. Second dual. As we discussed above, the dual space V0is a vector
space, so one can consider its dual V00= (V0)0. It looks like one that can
consider the dual V000ofV00and so on. . . However, the fun stops with V00
because
The second dual V00iscanonically (i.e. in a natural way) isomor-
phic toV
220 8. Dual spaces and tensors
Let us decipher this statement. Any vector v2Vcanonically denes a
linear functional LvonV0(i.e. an element of the second dual V00by the rule
Lv(f) =f(v)8f2V0
It is easy to check that the mapping T:V!V00,Tv=Lvis a linear
transformation.
Note, that Ker T=f0g. Indeed, if Tv=0, then
f(v) = 08f2V0;
and by Lemma 1.3 above we have v=0.
Since dimV00= dimV0= dimV, the condition Ker T=f0gimplies that
Tis an invertible transformation (isomorphism).
The isomorphism Tis very natural, (at least for a mathematician). In
particular, it was dened without using a basis, so it does not depend on
the choice of basis. So, informally we say that V00is canonically isomorphic
toV: the rigorous statement is that the map Tdescribed above (which we
consider to be a natural and canonical) is an isomorphism from VtoV00.
1.3. Dual, a.k.a. biorthogonal bases. In the previous sections, we sev-
eral times referred to the entries of the matrix of a linear functional Las
coordinates. But coordinates in this book usually means the coordinates in
some basis. Are the \coordinates' of a linear functional really coordinates
in some basis? Turns out the answer is \yes", so the terminology remains
consistent.
Let us nd the basis corresponding to the coordinates of L2V0. Let
fb1;b2;:::;bngbe a basis in V. ForL2V0, let [L]B= [L1;L2;:::;Ln] be
its matrix (row) in the basis B. Consider linear functionals b0
1;b0
2;:::;b0
n2
V0dened by
(1.2) b0
k(bj) =k;j
wherek;jis the Kroneker delta ,
k:j=1; j =k
0j6=k
Recall, that a linear transformation is dened by its action on a basis, so
the functionals b0
kare well dened.
As one can easily see, the functional Lcan be represented as
L=X
Lkb0
k:
1. Dual spaces 221
Indeed, take an arbitrary v=P
kkbk2V, so [v]B= [1;2;:::;n]T.
By linearity and denition of b0
k
b0
k(v) =b0
k0
@X
jjbj1
A=X
jjb0
k(bj) =k:
Therefore
Lv= [L]B[v]B=X
kLkk=X
kLkb0
k(v):
Since this identity holds for all v2V, we conclude that L=P
kLkb0
k.
Since we did not assume anything about L2V0, we have just shown
that any linear functional Lcan be represented as a linear combination of
b0
1;b0
2;:::;b0
n, so the system b0
1;b0
2;:::;b0
nis generating.
Let us show that this system is linearly independent (and so it is a basis).
Let0=P
kLkb0
k. Then for an arbitrary j= 1;2;:::;n
0 =0bj= X
kLkb0
k!
(bj) =X
kLkb0
k(bj) =Lj
soLj= 0. Therefore, all Lkare 0 and the system is linearly independent.
So, the system b0
1;b0
2;:::;b0
nis indeed a basis in the dual space V0and
the entries of [ L]Bare coordinates of Lwith respect to the basis B.
Denition 1.4. Letb1;b2;:::;bnbe a basis in V. The system of vectors
b0
1;b0
2;:::;b0
n2V0;
uniquely dened by the equation (1.2) is called the dual (or biorthogonal)
basis to b1;b2;:::;bn.
Note that we have shown that the dual system to a basis is a basis. Note
also that in b0
1;b0
2;:::;b0
nis the dual system to a basis b1;b2;:::;bn, then
b1;b2;:::;bnis the dual to the basis b0
1;b0
2;:::;b0
n
1.3.1. Abstract non-orthogonal Fourier decomposition. The dual system can
be used for computing the coordinates in the basis b1;b2;:::;bn. Let
b0
1;b0
2;:::;b0
nbe the biorthogonal system to b1;b2;:::;bn, and let v=P
kkbk. Then, as it was shown before
b0
j(v) =bj X
kkbk!
=X
kkbj(bk) =jb0
j(bj) =j;
sok=b0
k(v). Then we can write
(1.3) v=X
kb0
k(v)bk:
In other words,
222 8. Dual spaces and tensors
Thekth coordinate of a vector vin a basisB=fb1;b2;:::;bng
isb0
k(v)g, whereB0=fb0
1;b0
2;:::;b0
ngis the dual basis.
This formula is called (a baby version of) the abstract non-orthogonal
Fourier decomposition ofv(in the basis b1;b2;:::;bn). The reason for this
name will be clear later in Section 2.3.
Remark 1.5. LetA=fa1;a2;:::;angandB=fb1;b2;:::;bmgbe bases
inXandYrespectively, and let B0=fb0
1;b0
2;:::;b0
mgbe the dual basis to
B. Then the matrix [ T]B;A=:A=fak;jgm
k=1n
j=1of the transformation Tin
the basesA,Bis given by
ak;j=b0
k(Taj); j = 1;2;:::;n; k = 1;2;:::;m:
1.4. Examples of dual systems. The rst example we consider is a trivial
one. LetVbeRn(orCn) and let e1;e2;:::;enbe the standard basis there.
The dual space will be the space of n-dimensional row vectors, which is
isomorphic to Rn(orCnin the complex case), and the standard basis there
is the dual to e1;e2;:::;en. The standard basis in ( Rn)0(or in ( Cn)0is
eT
1;eT
2;:::;eT
n) obtained from e1;e2;:::;enby transposition.
1.4.1. Taylor formula. The next example is more interesting. Let us con-
sider the space Pnof polynomials of degree at most n. As we know, the
powersfekgn
k=0,e(t) =tnform the standard basis in this space. What is
the dual to this basis?
The answer might be tricky to guess, but it is very easy to check when
you know it. Namely, consider the linear functionals e0
k2(Pn)0,k=
0;1;:::;n , acting on polynomials as follows:
e0
k(p) :=1
k!dk
dtkp(t)
t=0=1
k!p(k)(0);
here we use the usual agreement that 0! = 1 and d0f=dt0=f.
Since
dk
dtkjj=j(j 1):::(j k+ 1)tj k; kj
0 k>j
we can easily see that the system fe0
kgn
k=0is the dual to the system of powers
fekgn
k=0.
Applying (1.3) to the above system fekgn
k=0and its dual we get that
any polynomial pof degree at most ncan be represented as
(1.4) p(t) =nX
k=0p(k)(0)
k!tk
This formula is well-known in Calculus as the Taylor formula for polyno-
mials. More precisely, this is a particular case of the Taylor formula, the
1. Dual spaces 223
so-called Maclaurin formula. The general Taylor formula
p(t) =nX
k=0p(k)(a)
k!(t a)k
can be obtained from (1.4) by applying it to the polynomial p( a) and
then denoting t:= a. It also can be obtained by considering powers
(t a)k,k= 0;1;:::;n and nding the dual system the same way we did it
fortk.2
1.4.2. Lagrange interpolation. Our next example deals with the so-called
Lagrange interpolating formula. Let a1;a2;:::;an+1be distinct points (in
RorC), and let Pnbe the space of polynomials of degree at most n. Dene
functionals fk2P0
nby
fk(p) =p(ak)8p2Pn:
What is the dual of this system of functionals? Note, that while it is not
hard to show that the functionals fkare linearly independent, and so (since
dim(Pn)0= dim Pn=n+ 1) form a basis in ( Pn)0, we do not need that. We
will construct the dual system directly, and then will be able to see that the
system f1;f2;:::;fn+1is indeed a basis.
Namely, let us dene the polynomials pk,k= 1;2;:::;n + 1 as
pk(t) =Y
j:j6=k(t aj).Y
j:j6=k(ak aj)
wherejin the products runs from 1 to n+ 1. Clearly pk(ak) = 1 and
pk(aj) = 0 ifj6=k, so indeed the system p1;p2;:::;pn+1is dual to the
system f1;f2;:::;fn+1.
There is a little detail here, since the notion of a dual system was dened
only for a basis, and we did not prove that either of the systems is one.
But one can immediately see that the system p1;p2;:::;pn+1is linearly
independent (can you explain why?), and since it contains n+ 1 = dim Pn
vectors, it is a basis. Therefore, the system of functionals f1;f2;:::;fn+1is
also a basis in the dual space ( Pn)0.
Remark. Note, that we did not just got lucky here, this is a general phe-
nomenon. Namely, as Problem 1.1 below asserts, any system of vectors
having a \`dual" one must be linearly independent. So, constructing a dual
system is a way of proving linear independence (and an easy one, if you can
do it easily as in the above example).
2Note, that the general Taylor formula says more than the formula for polynomials obtained
here: it says that any ntimes dierentiable function can be approximated near the point aby its
Taylor polynomial. Moreover, if the function is n+ 1 times dierentiable, it allows us to estimate
the error. The above formula for polynomials serves as a motivation and a starting point for the
general case
224 8. Dual spaces and tensors
Applying formula (1.3) to the above example one can see that the
(unique) polynomial p, degpnsatisfying
(1.5) p(ak) =yk; k = 1;2;:::;n + 1
can be reconstructed by the formula
(1.6) p(t) =n+1X
k=1ykpk(t):
This formula is well -known in mathematics as the \Lagrange interpolation
formula".
Exercises.
1.1. Letv1;v2;:::;vrbe a system of vectors in Xsuch that there exists a system
v0
1;v0
2;:::;v0
rof linear functionals such that
v0
k(vj) =1; j =k
0j6=k
a) Show that the system v1;v2;:::;vris linearly independent.
b) Show that if the system v1;v2;:::;vris not generating, then the \biorthog-
onal" system v0
1;v0
2;:::;v0
ris not unique. Hint: Probably the easiest way
to prove that is to complete the system v1;v2;:::;vrto a basis, see Propo-
sition 5.4 from Chapter 2
1.2. Prove that given distinct points a1;a2;:::;an+1and values y1;y2;:::;yn+1
(not necessarily distinct) the polynomial p, degpnsatisfying (1.5) is unique.
Try to prove it using the ideas from linear algebra, and not what you know about
polynomials.
2. Dual of an inner product space
Let us recall that there is no inner product space over an arbitrary eld,
that all our inner product spaces are either real or complex.
2.1. Riesz representation theorem.
Theorem 2.1 (Riesz representation theorem) .LetHbe an inner product
space. Given a linear functional LonHthere exists a unique vector y2H
such that
(2.1) L(v) = (v;y)8v2H:
Proof. Fix an orthonormal basis e1;e2;:::;eninH, and let
[L] = [L1;L2;:::;Ln]
be the matrix of Lin this basis. Dene vector yby
(2.2) y:=X
kLkek;
2. Dual of an inner product space 225
whereLkdenotes the complex conjugate of Lk. In the case of a real space
the conjugation does nothing and can be simply ignored.
We claim that ysatises (2.1).
Indeed, take an arbitrary vector v=P
kkek. Then
[v] = [1;2;:::;n]T
and
L(v) = [L][v] =X
kLkk:
On the other hand Recall that if we
know coordinates of
2 vectors in an or-
thonormal basis, we
can compute the in-
ner product by tak-
ing these coordinate
and computing the
standard inner prod-
uct in Cn(orRn).(v;y) =X
kkLk=X
kkLk
so (2.1) holds.
To show that the vector yis unique, let us assume that ysatises (2.1).
Then fork= 1;2;:::;n
(ek;y) =L(ek) =Lk;
so (y;ek) =Lk. Then, using the formula for the decomposition in the
orthonormal basis, see Section 2.1 of Chapter 5 we get
y=X
k(y;ek)ek=X
kLkek
which means that any vector satisfying (2.1) must be represented by (2.2).

Remark. While the statement of the theorem does not require a basis,
the proof presented above utilizes an orthonormal basis in H, although the
resulting vector ydoes not depend on the choice of the basis3. An advantage
of this proof is that it gives a formula for computing the representing vector
y.
2.2. Is an inner product space a dual to itself? For a vector yin an
inner product space Hone can dene a linear functional Ly,
Ly(v) := (v;y):
It is easy to see that the mapping y7!Lyis an injective mapping from
Hto sits dual H. The above Theorem 2.1 asserts that this mapping is a
surjection (onto), so one is tempted to say that the dual of an inner product
spaceHis (canonically isomorphic to) the space Hitself, with the canonical
isomorphism given by y7!Ly.
3An alternative proof that does need a basis is also possible. This alternative proof, that
works in innite-dimensional case, uses strong convexity of the unit ball in the inner product space
together with the idea of completeness from analysis.
226 8. Dual spaces and tensors
This is indeed the case if His a real inner product space and it is
easy to show that the map y7!Lyis alinear transformation. We already
discussed that the map is injective and surjective, so it is an invertible linear
transformations, i.e. an isomorphism .
However if His a complex space, one needs to be a bit more careful.
Namely, the mapping y7!Lythat that maps a vector y2Hto the linear
functionalLyas in Theorem 2.1 ( Ly(v) = (v;y)) is not a linear one.
More precisely, while it is easy to show that
(2.3) Ly1+y2=Ly1+Ly2;
it follows from the denition of Lyand properties of inner product that
(2.4) Ly(v) = (v;y) =(v;y) =Ly(v);
soLy=Ly.
In other words, one can say that the dual of a complex inner product
space is the space itself but with the dierent linear structure : adding 2 vec-
tors is equivalent to adding corresponding linear functionals, but multiplying
a vector by is equivalent to multiplying the corresponding functional by
.
A transformation TsatisfyingT(x+y) =Tx+Tyis some-
times called a conjugate linear transformation.
So, for a complex inner product space Hits dual can be canonically iden-
tied with Hby a conjugate linear isomorphism (i.e. invertible conjugate
linear transformation)
Of course, for a real inner product space the complex conjugation can
be simply ignored (because is real), so the map y7!Lyis a linear one.
In this case we can, indeed say that the dual of an inner product space H
is the space itself.
In both, real and complex cases, we nevertheless can say that the dual
of an inner product space can be canonically identied with the space itself.
2.3. Biorthogonal systems and orthonormal bases.
Denition 2.2. Letb1;b2;:::;bnbe a basis in an inner product space H.
The unique system b0
1;b0
2;:::;b0
ninHdened by
(bj;b0
k) =j;k;
wherej;kis the Kroneker delta, is called the biorthogonal ordual to the
basis b1;b2;:::;bn.
This denition clearly agrees with Denition 1.4, if one identies the
dualH0withHas it was discussed above. Then it follows immediately
3. Adjoint (dual) transformations and transpose 227
from the discussion in Section 1.3 that the dual system b0
1;b0
2;:::;b0
nto a
basis b1;b2;:::;bnis uniquely dened and forms a basis, and that the dual
tob0
1;b0
2;:::;b0
nisb1;b2;:::;bn.
The abstract non-orthogonal Fourier decomposition formula (1.3) can
be rewritten as
v=nX
k=1(v;b0
k)bk
Note, that an orthonormal basis is dual to itself. So, if e1;e2;:::;enis
an orthonormal basis, the above formula is rewritten as
v=nX
k=1(v;ek)ek
which is the classical (orthogonal) abstract Fourier decomposition, see for-
mula (2.2) in Section 2.1 of Chapter 5.
3. Adjoint (dual) transformations and transpose.
Fundamental subspace revisited (once more)
By analogy with the case of an inner product spaces, see Theorem 2.1, it is
customary to write L(v), whereLis a linear functional (i.e. L2V0,v2V)
in the form resembling inner product
L(v) =hv;Li
Note, that the expression hv;Liis linear in both arguments, unlike the inner
product which in the case of a complex space is linear in the rst argument
and conjugate linear in the second. So, to distinguish it from the inner
product, we use the angular brackets.4
Note also, that while in the inner product both vectors belong to the
same space, vandLabove belong to dierent spaces: in particular, we
cannot add them.
3.1. Dual (adjoint) transformation.
Denition 3.1. LetA:X!Ybe a linear transformation. The transfor-
mationA0:Y0!X0(X0andY0are dual spaces for XandYrespectively)
such that
hAx;y0i=hx;A0y0i 8 x2X;y02Y0
is called the adjoint (dual) to A.
4This notation, while widely used, is far from the standard. Sometimes ( v;L) is used,
sometimes the angular brackets are used for the inner product. So, encountering expression like
that in the text, one has to be very careful to distinguish inner product from the action of a linear
functional.
228 8. Dual spaces and tensors
Of course, it is not a priori clear why the transformation A0exists. Below
we will show that indeed such transformation exists, and moreover, it is
unique.
3.1.1. Dual transformation for the case A:Fn!Fm.Let us rst consider
the case when X=Fn,Y=Fm(Fhere is, as usual, either RorC, but
everything works for the case of arbitrary elds)
As usual, we identify a vector vinFnwith the column of its coordinates,
and a linear transformation with it matrix (in the standard basis).
The dual of Fnis, as it was discussed above, the space of rows of size n,
so we can identify its with Fn. Again, we will treat an element of ( Fn)0as a
column vector of its coordinates.
Under these agreements we have for x2Fnandx02(Fn)0
x0(x) =hx;x0i= (x0)Tx
where the right side is the product of matrices (or a row and a column).
Then, for arbitrary x2X=Fnandy02Y0= (Fm)0
hAx;y0i= (y0)TAx= (ATy0)Tx=hx;ATyi
(the expressions in the middle are products of matrices).
So we have proved that the adjoint transformation exists. let us show
that it is unique. Assume that for some transformation B
hAx;y0i=hx;By0i 8 x2Fn;8y02(Fm)0:
That means that for arbitrary
hx;(AT B)y0i= 0;8x2Fn;8y02(Fm)0
By taking for xandy0the vectors from the standard bases in Fnand (Fm)0=
Fmrespectively we get that the matrices BandATcoincide. 
So, forX=Fn,Y=Fm
The dual transformation A0exists, and is unique. Moreover, its
matrix (in the standard bases) equals AT(the transpose of the
matrix ofA)
3.1.2. Dual transformation in the abstract setting. Now, let us consider the
general case. In fact, we do not need to do much, since everything can be
reduced to the case of spaces Fn.
Namely, let us x bases A=a1;a2;:::;aninX, andB=b1;b2;:::;bm
inY, and letA0=a0
1;a0
2;:::;a0
nandB=b0
1;b0
2;:::;b0
mbe their dual bases
(inX0andY0respectively). For a vector v(from a space or its dual) we as
usual denote by [ v]Bthe column of its coordinates in the basis B. Then
hx;x0i= ([x0]A0)T[x]A;8x2X8x02X0;
3. Adjoint (dual) transformations and transpose 229
i.e. instead of working with x2Xandx02X0we can work with columns
their coordinates (in the dual bases AandA0respectively) absolutely the
same way we do in in the case of Fn. Of course, the same works for Y, so
working with columns of coordinates and then translating everything back
to the abstract setting we get that the dual transformation exists in unique
in this case as well.
Moreover, using the fact (which we just proved) that for A:Fn!Fm
the matrix of A0isATwe get
(3.1) [ A0]A0;B0= ([A]B;A)T;
or in plain English
The matrix of the dual transformation in the dual basis is the
transpose of the matrix of the transformation in the original bases.
Remark 3.2. Note, that while we used basis to construct the dual trans-
formation, the resulting transformation does not depend on the choice of a
basis.
3.1.3. A coordinate-free way to dene the dual transformation. Let us now
present another, more \high brow" way of dening the dual of a linear
transformation. Namely, for x2X,y02Ylet us x for a moment y0and
treat the expression hAx;y0i=y0(Ax) as a function of x. It is easy to see
that this is a composition of two linear transformations (which ones?) and
so it is a linear function of x, i.e. a linear functional on X, i.e. an element
ofX0.
Let us call this linear functional B(y0) to emphasize the fact that it
depends on y0. Since we can do this for every y02Y0, we can dene the
transformation B:Y0!X0such that
hAx;y0i=hx;B(y0)i
Our next step is to show that Bis a linear transformation. Note, that
since the transformation Bwas dened in rather indirect way, we cannot
see immediately from the denition that it is linear. To show the linearity
ofBlet us take y0
1;y0
22Y0. For x2X
hx;B(y0
1+y0
2)i=hAx;y0
1+y0
2i by the denition of B
=hAx;y0
1i+hAx;y0
2i by linearity
=hx;B(y0
1)i+hx;B(y0
2)i by the denition of B
=hx;B(y0
1) +B(y0
2)i by linearity
Since this identity is true for all x, we conclude that B(y0
1+y0
2) =
B(y0
1) +B(y0
2), i.e. thatBis linear.
230 8. Dual spaces and tensors
The main advantage of this approach that it does not require a basis, so
it can be (and is) used in the innite-dimensional situation. However, the
proof that we presented above in Sections 3.1.1, 3.1.2 gives a constructive
way to compute the dual transformation, so we used that proof instead of
more general coordinate-free one.
Remark 3.3. Note, that the above coordinate-free approach can be used to
dene the Hermitian adjoint of as operator in an inner product space. The
only addition to the reasoning presented above will be the use of the Riesz
Representation Theorem (Theorem 2.1). We leave the details as an exercise
to the reader, see Problem 3.2 below.
3.2. Annihilators and relations between fundamental subspaces.
Denition 3.4. LetXbe a vector space and let EX. The annihilator
ofE, denoted by E?is the set of all x02X0such thathx;x0i= 0 for all
x2E.
Using the fact that X00is canonically isomorphic to X(see Section 1.2)
we say that for EX0itsannihilator E?consists of all vectors x2Xsuch
thathx;x0i= 0 for all x02E.
Remark 3.5. Formally speaking, for EX0the setE?should be dened
as the set of all x002X00such thathx0;x00i= 0 for all x02E; the symbol
E?is often used for the annihilator from the second part of Denition 3.4.
However, because of the natural isomorphism of X00andXthere is no real
dierence between these two cases, so we will always use E?.
Distinguishing the cases EXandEX0makes a lot of sense
in the innite-dimensional situation, where X00is not always canonically
isomorphic to X.
The spaces such that X00canonically isomorphic to Xhave a special
name: they are called reexive spaces.
Proposition 3.6. LetEbe a subspace of X. Then (E?)?=E
This proposition looks absolutely like Proposition 3.6 from Chapter 5.
However its proof is a bit more complicated, since the suggested proof of
Proposition 3.6 from Chapter 5 heavily used the inner product space struc-
ture: it used the decomposition X=EE?, which is not true in our
situation because, for example, EandE?are in dierent spaces.
Proof. Letv1;v2;:::;vrbe a basis in E(recall that all spaces in this
chapter are assumed to be nite-dimensional), so E= spanfv1;v2;:::;vrg.
By Proposition 5.4 from Chapter 2 the system can be extended to a
basis in all X, i.e. one can nd vectors vr+1;:::;vn(n= dimX) such that
v1;v2;:::;vnis a basis in X.
3. Adjoint (dual) transformations and transpose 231
Letv0
1;v0
2;:::;v0
nbe the dual basis to v1;v2;:::;vn. By Problem 3.3
E?= spanfv0
r+1;:::;v0
ng. Applying again this problem to E?we get that
(E?)?= spanfv1;v2;:::;vng=E:

The following theorem is analogous to Theorem 5.1 from Chapter 5
Theorem 3.7. LetA:X!Ybe an operator acting from one vector space
to another. Then
a) KerA0= (RanA)?;
b) KerA= (RanA0)?;
c) RanA= (KerA0)?;
d) RanA0= (KerA)?.
Proof. First of all, let us notice, that since for a subspace Ewe have
(E?)?=E, the statements 1 and 3 are equivalent. Similarly, for the same
reason, the statements 2 and 4 are equivalent as well. Finally, statement 2 is
exactly statement 1 applied to the operator A0(here we use the trivial fact
fact that (A0)0=A, which is true, for example, because of the corresponding
fact for the transpose).
So, to prove the theorem we only need to prove statement 1.
Recall that A0:Y0!X0. The inclusion y02(RanA)?means that y0
annihilates all vectors of the form Ax, i.e. that
hAx;y0i= 08x2X:
SincehAx;y0i=hx;A0y0i, the last identity is equivalent to
hx;A0y0i= 08x2X:
But that means that A0y0=0(A0y0is a zero functional).
So we have proved that y02(RanA)?iA0y0=0, or equivalently i
y02KerA0. 
Exercises.
3.1. Prove that if for linear transformations T;T1:X!Y
hTx;y0i=hT1x;y0i
for all x2Xand for all y02Y0, thenT=T1.
Probably one of the easiest ways of proving this is to use Lemma 1.3.
3.2. Combine the Riesz Representation Theorem (Theorem 2.1) with the reason-
ing in Section 3.1.3 above to present a coordinate-free denition of the Hermitian
adjoint of an operator in an inner product space.
232 8. Dual spaces and tensors
The next problem gives a way to prove Proposition 3.6
3.3. Letv1;v2;:::;vnbe a basis in Xand let v0
1;v0
2;:::;v0
nbe its dual basis. Let
E:= spanfv1;v2;:::;vrg,r<n . Prove that E?= spanfv0
r+1;:::;v0
ng.
3.4. Use the previous problem to prove that for a subspace EX
dimE+ dimE?= dimX:
4. What is the dierence between a space and its dual?
We know that the dual space X0has the same dimension as X, so the
space and its dual are isomorphic. So one can think that really there is no
dierence between the space and its dual. However, as we discussed above
in Section 1.1, when we change basis in the space Xthe coordinates in X
and inX0change according to dierent rules, see formula (1.1) above.
On the other hand, using the natural isomorphism of XandX00we can
say thatXis the dual of X0. From this point of view, there is no dierence
betweenXandX0: we can start from Xand say that X0is its dual, or we
can do it the other way around and start from X0.
We already used this point of view above, for example in the proof of
Theorem 3.7.
Note also, that the change of coordinate formula (1.1) (see also the
boxed statement below it) agrees with this point of view: if eS:= (S 1)T,
then (eS 1)T=S, so we get the change of coordinate formula in Xfrom the
one inX0by the same rule!
4.1. Isomorphisms between XandX0.There are innitely many pos-
sibilities to dene an isomorphism between XandX0.
IfX=Fnthen the most natural way to identify XandX0is to identify
the standard basis in Fnwith the one in ( Fn)0. In this case the action of a
linear functional will be given by the \inner product type" expression
hv;v0i= (v0)Tv:
To generalize this to the general case one has to x a basis B=b1;b2;:::;bn
inXand consider the dual basis B0=b0
1;b0
2;:::;b0
n, and dene an isomor-
phismT:X!X0byTbk=b0
k,k= 1;2;:::;n .
This isomorphism is natural in some sense, but it depends on the choice
of the basis, so in general there is no natural way to identify XandX0.
The exception to this is the case when Xis a real inner product space:
the Riesz representation theorem (Theorem 2.1) gives a natural way to iden-
tify a linear functional with a vector in X. Note that this approach works
4. What is the dierence between a space and its dual? 233
only for real inner product spaces. In the complex case, the Riesz rep-
resentation theorem gives a natural identication of XandX0, but this
identication is not linear but conjugate linear .
4.2. An example: velocities (dierential operators) and dieren-
tial forms as vectors and linear functionals. To illustrate the relations
between vectors and linear functional, let us consider an example from mul-
tivariable calculus, which gives rise to important ideas like tangent and
cotangent bundles in dierential geometry.
Let us recall the notion of the path integral (of the second kind) from
the calculus. Recall that a path inRnis dened by its parameterization,
i.e. by a function
t7!x(t) = (x1(t);x2(t);:::;xn(t))T
acting from an interval [ a;b] toRn. If!is the so-called dierential form
(dierential 1-form),
!=f1(x)dx1+f2(x)dx2+:::+fn(x)dxn;
thepath integral
Z
!=Z
f1dx1+f2dx2+:::+fndxn
is computed by substituting x(t) = (x1(t);x2(t);:::;xn(t))Tin the expres-
sion, i.e.R
!is computed as
Zb
a
f1(x(t))dx1(t)
dt+f2(x(t))dx2(t)
dt+:::+fn(x(t))dxn(t)
dt
dt:
In other words, at each moment twe have to evaluate the velocity
v=dx(t)
dt=dx1(t)
dt;dx2(t)
dt;:::;dxn(t)
dtT
;
apply to it the linear functional f= (f1;f2;:::;fn),f(v) =Pn
k=1fkvk(here
fk=fk(x(t)) but for a xed teachfkis just a number, so we simply write
fk), and then integrate the result (which depends on t) with respect to t.
4.2.1. Velocities as vectors. Let us xtand analyze f(v). We will show that
according to the rules of Calculus, the coordinates of vchange as coordinates
of a vector, and the coordinates of fas the coordinates of a linear functional
(covector). Let us assume as it is customary in Calculus, that xkare the
coordinates in the standard basis in Rn, and letB=fb1;b2;:::;bngbe a
dierent basis in Rn. We will use notation exkto denote the coordinates of
a vector x= (x1;x2;:::;xn)T, i.e. [ x]B= (ex1;ex2;:::;exn)T.
234 8. Dual spaces and tensors
LetA=fak;jgn
k;j=1be the change of coordinates matrix, A= [I]B;S, so
the new coordinates exkare expressed in terms of the old ones as
exk=nX
j=1ak;jxj; k = 1;2;:::;n:
So the new coordinates evkof the vector vare obtained from its old coordi-
natesvkas
evk=nX
j=1ak;jvj; k = 1;2;:::;n:
4.2.2. Dierential forms as linear functionals (covectors). Let us now cal-
culate the dierential form
(4.1) !=nX
k=1fkdxk
in terms of new coordinates exk. The change of coordinates matrix from the
new to the old ones is A 1. LetA 1=feak;jgn
k;j=1, so
xk=nX
j=1eak;jexj;anddxk=nX
j=1eak;jdexj; k = 1;2;:::;n:
Substituting this into (4.1) we get
!=nX
k=1fknX
j=1eak;jdexj
=nX
j=1 nX
k=1eak;jfk!
dexj
=nX
j=1efjdexj
where
efj=nX
k=1eak;jfk:
But that is exactly the change of coordinate rule for the dual space! So
according to the rules of Calculus, the coecients of a dierential
1-form change by the same rule as coordinates in the dual space
So, according to the accepted rules of Calculus, the coordinates of ve-
locity vchange as coordinates of a vector and coecients (coordinates) of a
dierential 1-form change as the entries of a linear functional. In the dier-
ential the set of all velocities is called the tangent space , and the set of all
dierential 1 forms is its dual and is called the cotangent space .
4. What is the dierence between a space and its dual? 235
4.2.3. Dierential operators as vectors. As we discussed above, in dieren-
tial geometry vectors are represented by velocities, i.e. by the derivatives
dx(t)=dt. This is a simple and intuitively clear point of view, but sometimes
it is viewed as a bit na ve.
More \highbrow" point of view, also used in dierential geometry (al-
though in more advanced texts) is that vectors are represented by a dier-
ential operators
(4.2) D=X
kvk@
@xk:
The informal reason for that is the following. Suppose we want to compute
the derivative of a function  along the path given by the function t7!x(t),
i.e. the derivative
d(x(t))
dt:
By the Chain Rule, at a given time t
d(x(t))
dt=nX
k=1@
@xk
x=x(t)
x0
k(t) =D
x=x(t);
where the dierential operator Dis given by (4.2) with vk=x0
k(t).
Of course, we need to show that the coecient vkof a dierential form
change according to the change of coordinate rule for vectors. This is in-
tuitively clear, and can be easily shown by using the multivariable Chain
Rule. We leave this as an exercise for the reader, see Problem 4.1 below.
4.3. The case of a real inner product space. As we already discussed
above, it follows from the Riesz Representation Theorem (Theorem 2.1) that
a real inner product space Xand its dual X0are canonically isomorphic.
Thus we can say that vectors and functionals live in the same space which
makes things both simpler and more confusing.
Remark. First of all let us note, that if the change of coordinates matrix S
is orthogonal ( S 1=ST), then (S 1)T=S. Therefore, for an orthogonal
change of coordinate matrix the coordinates of a vector and of a linear
functional change according to the same rule, so one cannot really see a
dierence between a vector and a functional.
The change of coordinate matrix is orthogonal, for example, if we change
from one orthonormal basis to another.
4.3.1. Einstein notation, metric tensor. LetB=fb1;b2;:::;bnbe a ba-
sis in a real inner product space Xand letB0=fb0
1;b0
2;:::;b0
ngbe the
dual basis (we identify the dual space X0withXvia Riesz Representation
Theorem, so b0
kcan be assumed to be in X).
236 8. Dual spaces and tensors
Here we present the standard in dierential geometry notation (the so-
called Einstein notation) for working with coordinates in these bases. Since
we will only be working with coordinates, we can assume that we are working
in the space Rnwith the non-standard inner product ( ;)Gdened by the
positive denite matrix G=fgj;kgn
j;k=1,gj;k= (bk;bj)X, which is often
called the metric tensor ,
(4.3) ( x;y) = (x;y)G=nX
j=1nX
k=1gj;kxjyk; x;y2Rn
(see Section 5 in Chapter 7).
To distinguish between vectors and linear functionals (co-vectors) it is
agreed to write the coordinates of a vector with indices as superscripts and
the coordinates a a linear functional with indices as subscripts: thus xj,
j= 1;2;:::;n denotes the coordinates of a vector xandfk,k= 1;2;:::;n
denotes the coordinates of a linear functional f.
Remark. Putting indices as superscripts can be confusing, since one will
need to distinguish it from the power. However, this is a standard and widely
used notation, so we need to get acquainted with it. While I personally,
like a lot of mathematicians, prefer using coordinate-free notation, all nal
computations are done in coordinates, so the coordinate notation has to be
used. And as far as coordinate notations go, you will see that this notation
is quite convenient to work with.
Another convention in the Einstein notation is that whenever in a prod-
uct the same index appear in the subscript and superscript, it means one
needs to sum up in this index. Thus xjfjmeansP
jxjfj, so we can write
f(x) =xjfj. The same convention holds when we have more than one index
of summation, so (4.3) can be rewritten in this notation as
(4.4) ( x;y) =gj;kxkyj; x;y2Rn
(mathematicians are lazy and are always trying to avoid writing extra sym-
bols, whenever they can).
Finally, the last convention in the Einstein notation is the preservation
of the position of the indices: if we do not sum over an index, it remains in
the same position (subscript or superscript) as it was before. Thus we can
writeyj=aj
kxk, but notfj=aj
kxk, because the index jmust remain as a
superscript.
Note, that to compute the inner product of 2 vectors, knowing their
coordinates is not sucient. One also needs to know the matrix G(which
is often called the metric tensor ). This agrees with the Einstein notation:
if we try to write ( x;y) as the standard inner product, the expression xkyk
4. What is the dierence between a space and its dual? 237
means just the product of coordinates, since for the summation we need the
same index both as the subscript and the superscript. The expression (4.4),
on the other hand, t this convention perfectly.
4.3.2. Covariant and contravariant coordinates. Lovering and raising the
indices. Let us recall that we have a basis b1;b2;:::;bnin a real inner
product space, and that b0
1;b0
2;:::;b0
n,b0
k2Xis its dual basis (we identify
Xwith its dual X0via Riesz Representation Theorem, so b0
kare inX).
Given a vector x2Xit can be represented as
x=nX
k=1(x;b0
k)bk=:nX
k=1xkbk; and as (4.5)
x=nX
k=1(x;bk)b0
k=:nX
k=1xkb0
k: (4.6)
The coordinates xkare called the covariant coordinates of the vector xand
the coordinates xkare called the contravariant coordinates.
Now let us ask ourselves a question: how can one get covariant coordi-
nates of a vector from the contravariant ones?
According to the Einstein notation, we use the contravariant coordinates
working with vectors, and covariant ones for linear functionals (i.e. when we
interpret a vector x2Xas a linear functional). We know (see (4.6)) that
xk= (x;bk), so
xk= (x;bk) =X
jxjbj;bk
=X
jxj(bj;bk) =X
jgk;jxj;
or in the Einstein notation
xk=gk;jxj:
In other words,
the metric tensor Gis the change of coordinates matrix from con-
travariant coordinates xkto the covariant ones xk.
The operation of getting from contravariant coordinates to covariant is
called lowering of the indices .
Note the following interpretation of the formula (4.4) for the inner prod-
uct: as we know for the vector xwe get his covariant coordinate as xj=
gj;kxk, so (x;y) =xjyj. Similarly, because Gis symmetric, we can say that
yk=gj;kykand that ( x;y) =xkyk. In other words
To compute the inner product of two vectors, one rst needs to
use the metric tensor Gto lower indices of one vector, and then,
treating this vector as a functional compute its value on the other
vector.
238 8. Dual spaces and tensors
Of course, we can also change from covariant coordinates xjto con-
travariant ones xj(raise the indices). Since
(x1;x2;:::;xn)T=G(x1;x2;:::;xn)T;
we get that
(x1;x2;:::;xn)T=G 1(x1;x2;:::;xn)T
so the change of coordinate matrix in this case is G 1.
Since, as we know, the change of coordinate matrix is the metric tensor,
we can immediately conclude that G 1is the metric tensor in covariant G 1is the metric
tensor in covariant
coordinates.coordinates, i.e. that if G 1=fgk;jgn
k;j=1then
(x;y) =gk;jxjyk:
Remark. Note, that if one looks at the big picture, the covariant and con-
travariant coordinates are completely interchangeable. It is just the matter
of which one of the bases in the dual pair BandB0we assign to be the
\primary" one and which one to be the dual.
What to chose as a \primary" object, and what as the \dual" one de-
pends mostly on accepted conventions.
Remark 4.1. Einstein notation is usually used in dierential, and espe-
cially Riemannian geometry, where vectors are identied with velocities and
covectors (linear functionals) with the dierential 1-forms, see Section 4.2
above. Vectors and covectors here are clearly dierent objects and form
what is called tangent and cotangent spaces respectively.
In Riemannian geometry one then introduces inner product (i.e. the
metric tensor, if one thinks in terms of coordinates) on the tangent space,
which allows us identify vectors and covectors (linear functionals). In coor-
dinate representation this identication is done by lowering/raising indices,
as described above.
4.4. Conclusions. Let us summarize the above discussion on whether or
not a space is dierent from its dual.
In short, the answer is \Yes", they are dierent objects. Although in the
nite-dimensional case, which is treated in this book, they are isomorphic,
nothing is usually gained from the identication of a space and its dual.
Even in the simplest case of Fnit is useful to think that the elements of
Fnare columns and the elements of its dual are rows (even though, when
doing manipulations with the elements of the dual space we often put the
rows vertically). More striking examples are ones considered in Sections
1.4.1 and 1.4.2 dealing with Taylor formula and Lagrange interpolation.
One can clearly see there that the linear functionals are indeed completely
5. Multilinear functions. Tensors 239
dierent objects than polynomials, and that hardly anything can be gained
by identifying functionals with the polynomials.
For inner product spaces the situation is dierent, because such spaces
can be canonically identied with their duals. This identication is linear
for real inner product spaces, so a real inner product space is canonically
isomorphic to its dual. In the case of complex spaces, this identication is
only conjugate linear , but it is nevertheless very helpful to identify a linear
functional with a vector and use the inner product space structure and ideas
like orthogonality, self-adjointness, orthogonal projections, etc.
However, sometimes even in the case of real inner product spaces, it is
more natural to consider the space and its dual as dierent objects. For ex-
ample, in Riemannian geometry, see Remark 4.1 above vector and covectors
come from dierent objects, velocities and dierential 1-forms respectively.
Even though the introduction of the metric tensor allows us to identify
vectors and covectors, it is sometimes more convenient to remember their
origins think of them as of dierent objects.
Exercises.
4.1. LetDbe a dierential operator
D=nX
k=1vk@
@xk:
Show, using the chain rule, that if we change a basis and write Din new coordinates,
its coecients vkchange according to the change of coordinates rule for vectors.
5. Multilinear functions. Tensors
5.1. Multilinear functions.
Denition 5.1. LetV1;V2;:::;Vp;Vbe vector spaces (over the same eld
F). A multilinear (p-linear) map with values in Vis a function Fofpvector
variables v1;v2;:::;vp,vk2Vk, with the target space V, which is linear in
each variable vk. In other words, it means that if we x all variables except
vkwe get a linear map, and this should be true for all k= 1;2;:::;p . We
will use the symbol L(V1;V2;:::;Vp;V) for the set of all such multilinear
functions.
If the target space Vis the eld of scalars F, we callFamultilinear
functional , ortensor . The number pis called the valency of the multilinear
functional (tensor). Thus, tensor of valency 1 is a linear functional, tensor
of valency 2 is called a bilinear form.
240 8. Dual spaces and tensors
Example. Letfk2(Vk)0. Dene a polylinear functional F=f1
f2
:::
fp
by multiplying the functionals fk,
(5.1) f1
f2
:::
fp(v1;v2;:::;vp) =f1(v1)f2(v2):::fp(vp);
forvk2Vk,k= 1;2;:::;p . The polylinear functional f1
f2
:::
fpis
called the tensor product of functionals fk.
5.1.1. Multilinear functions form vector space. Notice, that in the space
L(V1;V2;:::;Vp;V) one can introduce the natural operations of addition
and multiplication by a scalar,
(F1+F2)(v1;v2;:::;vp) :=F1(v1;v2;:::;vp) +F2(v1;v2;:::;vp);
(F1)(v1;v2;:::;vp) :=F1(v1;v2;:::;vp);
whereF1;F22L(V1;V2;:::;Vp;V),2F.
Equipped with these operations, the space L(V1;V2;:::;Vp;V) is a vector
space.
To see that we rst need to show that F1+F2andF1are multilinear
functions. Since \multilinear" means that it is linear in each argument sepa-
rately (with all the other variables xed), this follows from the corresponding
fact about linear transformation; namely from the fact that the sum of linear
transformations and a scalar multiple of a linear transformation are linear
transformations, cf. Section 4 of Chapter 1.
Then it is easy to show that L(V1;V2;:::;Vp;V) satises all axioms of
vector space; one just need to use the fact that Vsatises these axioms. We
leave the details as an exercise for the reader. He/she can look at Section
4 of Chapter 1, where it was shown that the set of linear transformations
satises axiom 7. Literally the same proof work for multilinear functions;
the proof that all other axioms are also satised is very similar.
5.1.2. Dimension of L(V1;V2;:::;Vp;V).LetB1;B2;:::;Bpbe bases in the
spacesV1;V2;:::;Vprespectively. Since a linear transformation is dened
by its action on a basis, a multilinear function F2L(V1;V2;:::;Vp;V) is
dened by its values on all tuples
b1
j1;b2
j2;:::;bp
jp; bk
jk2Bk:
Since there are exactly
(dimV1)(dimV2):::(dimVp)
such tuples, and each F(b1
j1;b2
j2;:::;bp
jp) is determined by dim Vcoordi-
nates (in some basis in V). we can conclude that F2L(V1;V2;:::;Vp;V) is
determined by (dim V1)(dimV2):::(dimVp)(dimV) entries. In other words
dimL(V1;V2;:::;Vp;V) = (dimV1)(dimV2):::(dimVp)(dimV):
5. Multilinear functions. Tensors 241
in particular, if the target space is the eld of scalars F(i.e. if we are dealing
with multilinear functionals)
dimL(V1;V2;:::;Vp;F) = (dimV1)(dimV2):::(dimVp):
It is easy to nd a basis in L(V1;V2;:::;Vp;F). Namely, let for k=
1;2;:::;p the systemBk=fbk
jgdimVk
j=1 be a basis in Vkand letB0=febk
jgdimVk
j=1
be its dual system, ebk
j2V0
k.
Proposition 5.2. The system
eb1
j1
eb2
j2
:::
ebp
jp; 1jkdimVk; k = 1;2;:::;p;
is a basis in the space L(V1;V2;:::;Vp;F).
Hereeb1
j1
eb2
j2
:::
ebp
jpis the tensor product of functionals, as dened
in(5.1) .
Proof. We want to represent Fas
(5.2) F=X
j1;j2;:::;jpj1;j2;:::;jpeb1
j1
eb2
j2
:::
ebp
jp
Sinceebj(bl) =j;l, we have
eb1
j1
eb2
j2
:::
ebp
jp(b1
j1;b2
j2;:::;bp
jp) = 1 and (5.3)
eb1
j1
eb2
j2
:::
ebp
jp(b1
j0
1;b2
j0
2;:::;bp
j0p) = 0 (5.4)
for any collection of indices j0
1;j0
2;:::;j0
pdierent from j1;j2;:::;jp.
Therefore, applying (5.2) to the tuple b1
j1;b2
j2;:::;bp
jpwe get
j1;j2;:::;jp=F(b1
j1;b2
j2;:::;bp
jp);
so the representation (5.2) is unique (if exists).
On the other hand, dening j1;j2;:::;jp:=F(b1
j1;b2
j2;:::;bp
jp) and using
(5.3) and (5.4), we can see that the equality (5.2) holds on all tuples of
form b1
j1;b2
j2;:::;bp
jp. So decomposition (5.2) holds, so we indeed have a
basis. 
5.2. Tensor Products.
Denition. LetV1;V2;:::;Vpbe vector spaces. The tensor product
V1
V2
:::
Vp
of spacesVkis simply the set L(V0
1;V0
2;:::;V0
p;F) of multilinear functionals;
hereV0
kis the dual of Vk.
242 8. Dual spaces and tensors
Remark 5.3. By Proposition 5.2 we get that if Bk=fbk
jgdimVk
j=1 is a basis
inVkfork= 1;2;:::;p , then the system
(5.5) b1
j1
b2
j2
:::
bp
jp; 1jkdimVk; k = 1;2;:::;p;
is a basis in V1
V2
:::
Vp.
Here we treat a vector vk2Vkas a linear functional on V0
k; the tensor
product of vectors v1
v2
:::
vpis the dened according to (5.1).
Remark. The tensor product v1
v2
:::
vpof vectors is clearly linear
in each argument vk. In other words, the map ( v1;v2;:::;vp)7!v1
v2
:::
vpis a multilinear functional with values in V1
V2
:::
Vp. We
leave the proof as an exercise for a reader, see Problem 5.1 below
Remark. Note, that the set fv1
v2
:::
vp:vk2Vkgof tensor
products of vectors is strictly less than V1
V2
:::
Vp, see Problem 5.2
below.
5.2.1. Lifting a multilinear function to a linear transformation on the tensor
product.
Proposition 5.4. For any multilinear function F2L(V1;V2;:::;Vp;V)
there exists a unique linear transformation T:V1
V2
:::
Vp!V
extendingF, i.e. such that
(5.6) F(v1;v2;:::;vp) =Tv1
v2
:::
vp;
for all choices of vectors vk2Vk,1kp.
Remark. IfT:V1
V2
:::
Vp!Vis a linear transformation, then
trivially the function F,
F(v1;v2;:::;vp) :=Tv1
v2
:::
vp;
is a multilinear function in L(V1;V2;:::;Vp;V). This follows immediately
from the fact that the expression v1
v2
:::
vpis linear in each variable
vk.
Proof of Proposition 5.4. DeneTon the basis (5.5) by
Tb1
j1
b2
j2
:::
bp
jp=F(b1
j1;b2
j2;:::;bp
jp)
and then extend it by linearity to all space V1
V2
:::
Vp. To complete
the proof we need to show that (5.6) holds for all choices of vectors vk2Vk,
1kp(we now know that only when each vkis one of the vectors bk
jk).
To prove that, let us decompose vkas
vk=X
jkk
jkbk
jk; k = 1;2;:::;p:
5. Multilinear functions. Tensors 243
Using linearity in each variable vkwe get
v1
v2
:::
vp=X
j1;j2;:::;jp1
j12
j2;:::;p
jpb1
j1
b2
j2
:::
bp
jp;
F(v1;v2;:::;vp) =X
j1;j2;:::;jp1
j12
j2;:::;p
jpF(b1
j1;b2
j2;:::;bp
jp)
so by the denition of Tidentity (5.6) holds. 
5.2.2. Dual of a tensor product. As one can easily see, the dual of the tensor
productV1
V2
:::
Vpis the tensor product of dual spaces V0
1
V0
2
:::
V0
p.
Indeed, by Proposition 5.4 and remark after it, there is a natural one-to-
one correspondence between multilinear functionals in L(V1;V2;:::;Vp;F)
(i.e. the elements of V0
1
V0
2
:::
V0
n) and the linear transformations T:
V1
V2
:::
Vp!F(i.e. with the elements of the dual of V1
V2
:::
Vp).
Note, that the bases from Remark 5.3 and Proposition 5.2 are the dual
bases (inV1
V2
:::
VpandV0
1
V0
2
:::
V0
nrespectively). Knowing
the dual bases allows us easily calculate the duality between the spaces
V1
V2
:::
VpandV0
1
V0
2
:::
V0
p, i.e. the expression hx;x0i,x2
V1
V2
:::
Vp,x02V0
1
V0
2
:::
V0
p
5.3. Covariant and contravariant tensors. LetX1;X2;:::;Xpbe vec-
tor spaces, and let Vkbe eitherXkorX0
k,k= 1;2;:::;p . For a multilinear
functionF2L(V1;V2;:::;Vp;V) we say that that it is covariant in variable
vk2VkifVk=Xkand contravariant in this variable if Vk=X0
k.
If a multilinear function is covariant (contravariant) in all variables, we
say that the multilinear function is covariant (contravariant). In general, if
a function is covariant in rvariables and contravariant in svariables, we say
that the multilinear function is r-covariants-contravariant (or simply ( r;s)
multilinear function, or that its valency is ( r;s)).
Thus, a linear functional can be interpreted as 1-covariant tensor (recall,
that we use the word tensor for the case of functionals , i.e. when the target
space is the eld of scalars F). By duality, a vector can be interpreted as
1-contravariant tensor.
Remark. At rst the terminology might look a bit confusing: if a variable
is a vector (not a functional), it is a covariant variable but a contravariant
object. But notice, that we did not say here a \covariant variable": we said
that if vk2Xkthen the mulitilinear function is covariant in the variable
vk. So, the covariant object is not vk, but the \slot" in the tensor where we
put it!
So there is no contradiction, we put the contravariant objects into co-
variant slots and vice versa.
244 8. Dual spaces and tensors
Sometimes, slightly abusing the language, people talk about covariant
(contravariant) variables or arguments. But it is usually meant that the
corresponding \slots" in the tensor are covariant (contravariant), and not
the variables as objects.
5.3.1. Linear transformations as tensors. A linear transformation T:X1!
X2can be interpreted as 1-covariant 1-contravariant tensor. Namely, the
bilinear functional F,
F(x1;x0
2) :=hTx1;x0
2i; x12X1;x0
22X0
2
is covariant in the rst variable x1and contravariant in the second one x0
2.
Conversely,
Proposition 5.5. Given a 1-1tensorF2L(X1;X0
2;F), there exists a
unique linear transformation T:X1!X2such that
(5.7) F(x1;x0
2) :=hTx1;x0
2i;
for all x12X2,x0
22X0
2.
Proof. First of all note, that the uniqueness is a trivial corollary of Lemma
1.3, cf. Problem 3.1 above. So we only need to prove existence of T.
LetBk=fbk
jgdimXk
j=1 be a basis in Xk, and letB0
k=febk
jgdimXk
j=1 be the
dual basis in X0
k,k= 1;2. Then dene the matrix A=fak;jgdimX2
k=1dimX1
j=1
by
ak;j=F(b1
j;eb2
k):
DeneTto be the operator with matrix [ T]B2;B1=A. Clearly (see Remark
1.5)
(5.8) hTb1
j;eb2
ki=ak;j=F(b1
j;eb2
k)
which implies the equality (5.7). This can be easily seen by decomposing
x1=P
jjbjandx0
2=P
kkb0
kand using linearity in each argument.
Another, more high brow explanation is that the tensors in left and the
right sides of (5.7) coincide on a basis in X1
X0
2(see Remark 5.3 about the
basis), so they coincide. To be more precise, one should lift the bilinear forms
to the linear transformations (functionals) X1
X0
2!F(see Proposition
5.4), and since the transformations coincide on a basis, they are equal.
One can also give an alternative, coordinate-free proof of existence of T,
along the lines of the coordinate-free denition of the dual space (see Section
3.1.3). Namely, if we x x1, the function F(x1;x0
2) is a linear in x0
2, so it is
a linear functional on X0
2, i.e. a vector in X2.
Let us call this vector T(x1). So we dened a transformation T:X1!
X2. One can easily show that Tis a linear transformation by essentially
5. Multilinear functions. Tensors 245
repeating the reasoning from Section 3.1.3. The equality (5.7) follows au-
thomatically from the denition of T. 
Remark. Note that we also can say that the function Ffrom Proposition
5.5 denes not the transformation T, but its adjoint. Apriori, without as-
suming anything (like order of variables and its interpretation) we cannot
distinguish between a transformation and its adjoint.
Remark. Note, that if we would like to follow the Einstein notation, the
entriesaj;kof the matrix A= [T]B2;B1of the transformation Tshould be
written asaj
k. Then ifxk,k= 1;2;:::; dimX1are the coordinates of the
vector x2X1, thejth coordinate of y=Txis given by
yj=aj
kxk:
Recall the here we skip the sign of summation, but we mean the sum over
k. Note also, that we preserve positions of the indices, so the index jstays
upstairs. The index kdoes not appear in the left side of the equation because
we sum over this index in the right side, and its got \killed".
Similarly, if xj,j= 1;2;:::; dimX2are the coordinates of the vector
x02X0
2, thenkth coordinate of y0:=T0x0is given by
yk=aj
kxj
(again, skipping the sign of summation over j). Again, since we preserve
the position of the indices, so the index kinykis a subscript.
Note, that since x2X1andy=Tx2X2are vectors, according to the
conventions of the Einstein notation, the indices in their coordinates indeed
should be written as superscripts.
Similarly, x02X0
2andy0=T0x02X0
1arecovectors , so indices in their
coordinates should be written as subscripts.
The Einstein notation emphasizes the fact mentioned in the previous
remark, that a 1-covariant 1-contravariant tensor gives us both a linear
transformation and its adjoint: the expression aj
kxkgives the action of T,
andaj
kxjgives the action of its adjoint T0.
5.3.2. Polylinear transformations as tensors. More generally, any polylin-
ear transformation can be interpreted as a tensor. Namely, given a poly-
linear transformation F2L(V1;V2;:::;Vp;V) one can dene the tensor
eF2L(V1;V2;:::;Vp;V0;F) by
(5.9)eF(v1;v2;:::;vp;v0) =hF(v1;v2;:::;vp);v0i; vk2Vk;v02V0:
Conversely,
246 8. Dual spaces and tensors
Proposition 5.6. Given a tensor eF2L(V1;V2;:::;Vp;V0;F)there exists a
unique polylinear transformation F2L(V1;V2;:::;Vp;V)such that (5.9) is
satised.
Proof. By Proposition 5.4 the tensor eFcan be extended to a linear trans-
formation (functional) eT:V1
V2
:::
Vp
V0!Fsuch that
eF(v1;v2;:::;vp;v0) =eT(v1
v2
:::
vp
v0)
for all vk2Vk,v02V0.
Ifw2W:=V1
V2
:::
Vpandv02V0, then
w
v02V1
V2
:::
Vp
V0:
So, we can dene a bilinear functional (tensor) G2L(W;V0;F) by
G(w;v0) :=eT(w
v):
By Proposition 5.5, Ggives rise to a linear transformation, i.e. there exists
a unique linear transformation T:W!Vsuch that
G(w;v0) =hTw;v0i 8 w2W;8v02V0:
And the linear transformation Tgives us the polylinear map
F2L(V1;V2;:::;Vp;V)
by
F(v1;v2;:::;vp) =T(v1
v2
:::
vp);
see Remark after Proposition 5.4.
The uniqueness of the transformation F, is, as in Proposition 5.5, is a
trivial corollary of Lemma 1.3. We leave the details as an exercise for the
reader. 
This section shows that
tensors are universal objects in polylinear algebra, since any poly-
linear transformation can be interpreted as a tensor and vice versa.
Exercises.
5.1. Show that the tensor product v1
v2
:::
vpof vectors is linear in each
argument vk.
5.2. Show that the set fv1
v2
:::
vp:vk2Vkgof tensor products of vectors
is strictly less than V1
V2
:::
Vp.
5.3. Prove that the transformation Ffrom Proposition 5.6 is unique.
6. Change of coordinates formula for tensors. 247
6. Change of coordinates formula for tensors.
The main reason for the dierentiation of covariant and contravariant vari-
ables is that under the change of bases, their coordinates change according
to dierent rules. Thus, the entries of covariant and contravariant vectors
change according to dierent rules as well.
In this section we going to investigate this in details. Note, that coor-
dinate representations are extremely important, since, for example, all nu-
merical computations (unlike the theoretical investigations) are performed
using some coordinate system.
6.1. Coordinate representation of a tensor. LetFbe anr-covariant
s-contravariant tensor, r+s=p. Let x1;:::;xrbe covariant variables
(xk2Xk), and f1;:::;fsbe the contravariant ones ( fk2X0
k). Let us
write the covariant variables rst, so the the tensor will be written as
F(x1;:::;xr;f1;:::;fs). Fork= 1;2;:::;p x a basisBk=fb(k)
jgdimXk
j=1
inXk, and letB0
k=feb(k)
jgdimXk
j=1 be the dual basis in X0
k.
For a vector xk2Xkletxj
(k),j= 1;2;:::; dimXkbe its coordinates in
the basisBk, and similarly, if fk2X0
kletf(k)
j,j= 1;2;:::; dimXkbe its
coordinates in the dual basis B0
k(note that in agreement with the Einstein
notation, the coordinates of the vector are indexed by a superscript, and the
coordinate of a covector re indexed by a subscript).
Proposition 6.1. Denote
(6.1) 'k1;:::;ks
j1;:::;jr:=F(b(1)
j1;:::;b(r)
jr;eb(r+1)
k1;:::;eb(r+s)
ks):
Then, in the Einstein notation
(6.2)F(x1;:::;xr;f1;:::;fs) ='k1;:::;ks
j1;:::;jrxj1
(1):::xjr
(r)f(1)
k1:::f(s)
ks
(the summation here is over the indices j1;:::;jrandk1;:::;ks).
Note that we use the notation (1) ;:::; (r) and (1);:::; (s) to emphasize
that these are not the indices: the numbers in parenthesis just show the
order of argument. Thus, right side of (6.2) does not have any indices left
(all indices were used in summation), so it is just a number (for xed xks
andfks).
Proof of Proposition 6.1. To show that (6.1) implies (6.2) we rst notice
that (6.1) means that (6.2) hods when xjs and fks are the elements of the
corresponding bases. Decomposing each argument xjandfkin the corre-
sponding basis and using linearity in each argument we can easily get (6.2).
The computation is rather simple, but because there are a lot of indices, the
formulas could be quite big and could look quite frightening.
248 8. Dual spaces and tensors
To avoid writing too many huge formulas, we leave this computation to
the reader as an exercise.
We do not want the reader to feel cheated, so we present a dierent,
more \high brow" (abstract) explanation, which does not require any com-
putations! Namely, let us notice that the expressions in the left and the
right side of (6.2) dene tensors. By Proposition 5.4 they can be lifted to
linear functionals on the tensor product X1
:::
Xr
X0
r+1
:::
X0
r+s.
Rephrasing what we discussed in the beginning of the proof, we can say
that (6.1) means that the functional coincide on all vectors
b(1)
j1
:::
b(r)
jr
eb(r+1)
k1
:::
eb(r+s)
ks
of a basis in the tensor product, so the functionals (and therefore the tensors)
are equal. 
The entries 'k1;:::;ks
j1;:::;jrare called the entries of the tensor Fin the bases
Bk,k= 1;2;:::;p .
Now, let for k= 1;2;:::p ,Akbe a basis in Xk(andA0
kbe the dual
basis inX0
k). We want to investigate how the entries of the tensor Fchange
when we change the bases from BktoAk.
6.2. Change of coordinate formulas in Einstein notation. Let us
rst consider the familiar cases of vectors and linear functionals, considered
above in Section 1.1.1 but write everything down using the Einstein notation.
Let we have in Xtwo bases,BandAand let
A= [A]A;B
be the change of coordinates matrix from BtoA. For a vector x2Xlet
xkbe its coordinates in the basis Bandexkbe the coordinates in the basis
A. Similarly, for f2X0letfkdenote the coordinates in the basis B0and
efk{the coordinates in the basis A0(B0andA0are the dual bases to Band
Arespectively).
Denote by ( A)j
kthe entries of the matrix A: to be consistent with the
Einstein notation the superscript jdenotes the number of the row. Then
we can write the change of coordinate formula as
(6.3) exj= (A)j
kxk:
Similarly, let ( A 1)k
jbe the entries of A 1: again superscript is used to
denote the number of the row. Then we can write the change of coordinate
formula for the dual space as
(6.4) efj= (A 1)k
jfk;
6. Change of coordinates formula for tensors. 249
the summation here is over the index k(i.e. along the columns of A 1), so
the change of coordinate matrix in this case is indeed ( A 1)T.
Let us emphasize that we did not prove anything here: we only rewrote
formula (1.1) from Section 1.1.1 using the Einstein notation.
Remark. While it is not needed in what follows, let us play a bit more with
the Einstein notation. Namely, the equations
A 1A=I andAA 1=I
can be rewritten in the Einstein notation as
(A)j
k(A 1)k
l=j;l and (A 1)k
j(A)j
l=k;l
respectively.
6.3. Change of coordinates formula for tensors. Now we are ready
to give the change of coordinate formula for general tensors.
Fork= 1;2;:::;p :=r+sletAk:= [I]A;Bbe the change of coordinates
matrices, and let A 1
kbe their inverses.
As in Section 6.2 we denote by ( A)j
kthe entries of a matrix A, with the
agreement that superscript gives the number of the column.
Proposition 6.2. Given anr-covariants-contravariant tensor Flet
'k1;:::;ks
j1;:::;jrande'k1;:::;ks
j1;:::;jr
be its entries in the bases Bk(the old ones) and Ak(the new ones) respec-
tively. In the above notation
e'k1;:::;ks
j1;:::;jr='k0
1;:::;k0
s
j0
1;:::;j0r(A 1
1)j0
1
j1:::(A 1
r)j0
r
jr(Ar+1)k1
k0
1:::(Ar+s)ks
k0s
(the summation here is in the indices j0
1;:::;j0
randk0
1;:::;ks).
Because of many indices, the formula in this proposition looks very com-
plicated. However if one understands the main idea, the formula will turn
out to be quite simple and easy to memorize.
To explain the main idea let us, sightly abusing the language, express
this formula \in plain English". namely, we can say, that
To express the \new" tensor entries e'k1;:::;ks
j1;:::;jrin terms of the \old"
ones'k1;:::;ks
j1;:::;jr, one needs for each covariant index (subscript) apply
the covariant rule (6.4), and for each contravariant index (super-
script) apply the contravariant rule (6.3)
Proof of Proposition 6.2. Informally, the idea of the proof is very simple:
we just change the bases one at a time, applying each time the change
250 8. Dual spaces and tensors
of coordinate formulas (6.3) or (6.4), depending on whether the tensor is
covariant or contravariant in the corresponding variable.
To write the rigorous formal proof we will use the induction in rans
s(the number of covariant and contravariant arguments of the tensor).
Proposition is true for r= 1,s= 0 and for r= 0,s= 1, see (6.4) or
(6.3) respectively.
Assuming now that the proposition is proved for some pands, let us
prove it for r+ 1,sand forr,s+ 1.
Let us do the latter case, the other one is done similarly. The maid idea
is that we rst change p=r+sbases and use the induction hypothesis;
then we change the last one and use (6.3).
Namely, letb'k1;:::;ks+1
j1;:::;jrbe the entries of an ( r;s+1) tensor Fin the bases
A1;:::;Ap;Bp+1,p=r+s.
Let us x the index ks+1and consider the r-covariants-contravariant
tensorF(x1;:::;xr;f1;:::;fs;eb(r+s+1)
s+1 ), where x1;:::;xr;f1;:::;fsare the
variables. Clearly
'k1;:::;ks;ks+1
j1;:::;jrandb'k1;:::;ks;ks+1
j1;:::;jr
are its entries in the bases B1;:::;BpandA1;:::;Aprespectively (can you
see why?) Recall, that the index ks+1here is xed.
By the induction hypothesis
(6.5)b'k1;:::;ks;ks+1
j1;:::;jr='k0
1;:::;k0
s;ks+1
j0
1;:::;j0r(A 1
1)j0
1
j1:::(A 1
r)j0
r
jr(Ar+1)k1
k0
1:::(Ar+s)ks
k0s:
Note, that we did not assume anything about the index ks+1, so (6.5) holds
for allks+1.
Now let us x indices j1;:::;jr;k1;:::;ksand consider 1-contravariant
tensor
F(a(1)
j1;:::;a(r)
jr;ea(r+1)
k1;:::;ea(r+s)
ks;fs+1)
of the variable fs+1. Here a(k)
jare the vectors in the basis Akandea(k)
jare
the vectors in the dual basis A0
k.
It is again easy to see that
b'k1;:::;ks;ks+1
j1;:::;jrande'k1;:::;ks;ks+1
j1;:::;jr;
js+1= 1;2;:::; dimXp+1, are the indices of this functional in the bases Bp+1
andAp+1respectively. According to (6.3)
e'k1;:::;ks;ks+1
j1;:::;jr=b'k1;:::;ks;k0
s+1
j1;:::;jr(Ap+1)ks+1
k0
s+1;
and since we did not assume anything about the indices j1;:::;jr;k1;:::;ks,
the above identity holds for all their combinations. Combining this with
(6.5) we get that the proposition holds for tensors of valency ( r;s+ 1).
6. Change of coordinates formula for tensors. 251
The case of valency ( r+ 1;s) is treated absolutely the same way: the
only dierence is that in the end we get a 1-covariant tensor and use (6.4)
instead of (6.3). 

Chapter 9
Advanced spectral
theory
1. Cayley{Hamilton Theorem
Theorem 1.1 (Cayley{Hamilton) .LetAbe a square matrix, and let p() =
det(A I)be its characteristic polynomial. Then p(A) =0.
A wrong proof. The proof looks ridiculously simple: plugging Ainstead
ofin the denition of the characteristic polynomial we get
p(A) = det(A AI) = det 0= 0:

But this is a wrong proof! To see why, let us analyze what the theorem
states. It states, that if we compute the characteristic polynomial
det(A I) =p() =nX
k=0ckk
and then plug matrix Ainstead ofto get
p(A) :=nX
k=0ckAk=c0I+c1A+:::+cnAn
then the result will be zero matrix .
It is not clear why we get the same result if we just plug Ainstead of
in the determinant det( A I). Moreover, it is easy to see that with
the exception of trivial case of 1 1 matrices we will get a dierent object.
Namely,A AIis zero matrix , and its determinant is just the number 0.
253
254 9. Advanced spectral theory
Butp(A) is a matrix, and the theorem claims that this matrix is the zero
matrix . Thus we are comparing apples and oranges. Even though in both
cases we got zero, these are dierent zeroes: he number zero and the zero
matrix!
Let us present another proof, which is based on some ideas from analysis.
This proof illus-
trates an important
idea that often it
is sucient to con-
sider only a typical,
generic situation.
It is going beyond
the scope of the
book, but let us
mention, without
going into details,
that a generic
(i.e. typical) matrix
is diagonalizable.A \continuous" proof. The proof is based on several observations. First
of all, the theorem is trivial for diagonal matrices, and so for matrices similar
to diagonal (i.e. for diagonalizable matrices), see Problem 1.1 below.
The second observation is that any matrix can be approximated (as close
as we want) by diagonalizable matrices. Since any operator has an upper
triangular matrix in some orthonormal basis (see Theorem 1.1 in Chapter
6), we can assume without loss of generality that Ais an upper triangular
matrix.
We can perturb diagonal entries of A(as little as we want), to make them
all dierent, so the perturbed matrix eAis diagonalizable (eigenvalues of a a
triangular matrix are its diagonal entries, see Section 1.7 in Chapter 4, and
by Corollary 2.3 in Chapter 4 an nnmatrix with ndistinct eigenvalues
is diagonalizable).
As I just mentioned, we can perturb the diagonal entries of Aas little
as we want, so Frobenius norm kA eAk2is as small as we want. Therefore
one can nd a sequence of diagonalizable matrices Aksuch thatAk!Aas
k!1 for example such that kAk Ak2!0 ask!1 ). It can be shown
that the characteristic polynomials pk() = det(Ak I) converge to the
characteristic polynomial p() = det(A I) ofA. Therefore
p(A) = lim
k!1pk(Ak):
But as we just discussed above the Cayley{Hamilton Theorem is trivial for
diagonalizable matrices, so pk(Ak) =0. Therefore p(A) = limk!10=
0. 
This proof is intended for a reader who is comfortable with such ideas
from analysis as continuity and convergence1. Such a reader should be able
to ll in all the details, and for him/her this proof should look extremely
easy and natural.
However, for others, who are not comfortable yet with these ideas, the
proof denitely may look strange. It may even look like some kind of cheat-
ing, although, let me repeat that it is an absolutely correct and rigorous
proof (modulo some standard facts in analysis). So, let us present another,
1Here I mean analysis , i.e. a rigorous treatment of continuity, convergence, etc, and not
calculus, which, as it is taught now, is simply a collection of recipes.
1. Cayley{Hamilton Theorem 255
proof of the theorem which is one of the \standard" proofs from linear al-
gebra textbooks.
A \standard" proof. We know, see Theorem 6.1.1 from Chapter 6, that
any square matrix is unitary equivalent to an upper triangular one. Since for
any polynomial pwe havep(UAU 1) =Up(A)U 1, and the characteristic
polynomials of unitarily equivalent matrices coincide, it is sucient to prove
the theorem only for upper triangular matrices.
So, letAbe an upper triangular matrix. We know that diagonal entries
of a triangular matrix coincide with it eigenvalues, so let 1;2;:::;nbe
eigenvalues of Aordered as they appear on the diagonal, so
A=0
BBB@1
2
...
0 n1
CCCA:
The characteristic polynomial p(z) = det(A zI) ofAcan be represented
asp(z) = (1 z)(2 z):::(n z) = ( 1)n(z 1)(z 2):::(z n),
so
p(A) = ( 1)n(A 1I)(A 2I):::(A nI):
Dene subspaces Ek:= spanfe1;e2;:::;ekg, where e1;e2;:::;enis the
standard basis in Cn. Since the matrix of Ais upper triangular, the sub-
spacesEkare so-called invariant subspaces of the operator A, i.e.AEkEk
(meaning that Av2Ekfor all v2Ek). Moreover, since for any v2Ekand
any
(A I)v=Av v2Ek;
because both Avandvare inEk. Thus (A I)EkEk, i.e.Ekis an
invariant subspace of A I.
We can say even more about the the subspace ( A kI)Ek. Namely,
(A kI)ek2spanfe1;e2;:::;ek 1g, because only the rst k 1 entries
of thekth column of the matrix of A kIcan be non-zero. On the other
hand, forj <k we have (A k)ej2EjEk(becauseEjis an invariant
subspace of A kI).
Take any vector v2Ek. By the denition of Ekit can be repre-
sented as a linear combination of the vectors e1;e2;:::;ek. Since all vectors
e1;e2;:::;ekare transformed by A kIto some vectors in Ek 1, we can
conclude that
(1.1) ( A kI)v2Ek 18v2Ek:
256 9. Advanced spectral theory
Take an arbitrary vector x2Cn=En. Applying (1.1) inductively with
k=n;n 1;:::1 we get
x1:= (A nI)x2En 1;
x2:= (A n 1I)x1= (A n 1I)(A nI)x2En 2;
:::
xn:= (A 2I)xn 1= (A 2I):::(A n 1I)(A nI)x2E1:
The last inclusion mean that xn=e1. But (A 1I)e1=0, so
0= (A 1I)xn= (A 1I)(A 2I):::(A nI)x:
Thereforep(A)x=0for all x2Cn, which means exactly that p(A) =0.
Exercises.
1.1(Cayley{Hamilton Theorem for diagonalizable matrices) .As discussed in the
above section, the Cayley{Hamilton theorem states that if Ais a square matrix,
and
p() = det(A I) =nX
k=0ckk
is its characteristic polynomial, them p(A) :=Pn
k=0ckAk=0(we assuming, that
by denition A0=I).
Prove this theorem for the special case when Ais similar to a diagonal matrix,
A=SDS 1.
Hint: IfD= diagf1;2;:::;ngandpis any polynomial, can you compute
p(D)? What about p(A)?
2. Spectral Mapping Theorem 257
2. Spectral Mapping Theorem
2.1. Polynomials of operators. Let us also recall that for a square ma-
trix (an operator) Aand for a polynomial p(z) =PN
k=1akzkthe operator
p(A) is dened by substituting Ainstead of the independent variable,
p(A) :=NX
k=1akAk=a0I+a1A+a2A2+:::+aNAN;
here we agree that A0=I.
We know that generally matrix multiplication is not commutative, i.e.
generallyAB6=BAso the order is essential. However
AkAj=AjAk=Ak+j;
and from here it is easy to show that for arbitrary polynomials pandq
p(A)q(A) =q(A)p(A) =R(A)
whereR(z) =p(z)q(z).
That means that when dealing only with polynomials of an operator
A, one does not need to worry about non-commutativity, and act like Ais
simply an independent (scalar) variable. In particular, if a polynomial p(z)
can be represented as a product of monomials
p(z) =a(z z1)(z z2):::(z zN);
wherez1;z2;:::;zNare the roots of p, thenp(A) can be represented as
p(A) =a(A z1I)(A z2I):::(A zNI)
2.2. Spectral Mapping Theorem. Let us recall that the spectrum (A)
of a square matrix (an operator) Ais the set of all eigenvalues of A(not
counting multiplicities).
Theorem 2.1 (Spectral Mapping Theorem) .For a square matrix Aand an
arbitrary polynomial p
(p(A)) =p((A)):
In other words, is an eigenvalue of p(A)if and only if =p()for some
eigenvalueofA.
Note, that as stated, this theorem does not say anything about multi-
plicities of the eigenvalues.
Remark. Note, that one inclusion is trivial. Namely, if is an eigenvalue of
A,Ax=xfor some x6=0, thenAkx=kx, andp(A)x=p()x, sop()
is an eigenvalue of p(A). That means that the inclusion p((A))(p(A))
is trivial.
258 9. Advanced spectral theory
If we consider a particular case = 0 of the above theorem, we get the
following corollary.
Corollary 2.2. LetAbe a square matrix with eigenvalues 1;2;:::;n
and letpbe a polynomial. Then p(A)is invertible if and only if
p(k)6= 08k= 1;2;:::;n:
Proof of Theorem 2.1. As it was discussed above, the inclusion
p((A))(p(A))
is trivial.
To prove the opposite inclusion (p(A))p((A)) take a point 2
(p(A)). Denote q(z) =p(z) , soq(A) =p(A) I. Since2(p(A))
the operator q(A) =p(A) Iis not invertible.
Let us represent the polynomial q(z) as a product of monomials,
q(z) =a(z z1)(z z2):::(z zN):
Then, as it was discussed above in Section 2.1, we can represent
q(A) =a(A z1I)(A z2I):::(A zNI):
The operator q(A) is not invertible, so one of the terms A zkImust be
not invertible (because a product of invertible transformations is always
invertible). That means zk2(A).
On the other hand zkis a root of q, so
0 =q(zk) =p(zk) 
and therefore =p(zk). So we have proved the inclusion (p(A))p((A)).

Exercises.
2.1. An operator Ais called nilpotent ifAk=0for somek. Prove that if Ais
nilpotent, then (A) =f0g(i.e. that 0 is the only eigenvalue of A).
Can you do it without using the spectral mapping theorem?
3. Generalized eigenspaces 259
3. Generalized eigenspaces. Geometric meaning of algebraic
multiplicity
3.1. Invariant subspaces.
Denition. LetA:V!Vbe an operator (linear transformation) in a
vector space V. A subspace Eof the vector space Vis called an invariant
subspace of the operator A(or, shortly, A-invariant) if AEE, i.e. if
Av2Efor all v2E.
IfEisA-invariant, then
A2E=A(AE)AEE;
i.e.EisA2-invariant.
Similarly one can show (using induction, for example), that if AEE
then
AkEE8k1:
This implies that P(A)EEfor any polynomial p, i.e. that:
anyA-invariant subspace Eis an invariant subspace of p(A).
IfEis anA-invariant subspace, then for all v2Ethe resultAvalso
belongs toE. Therefore we can treat Aas an operator acting on E, not on
the whole space V.
Formally, for an A-invariant subspace Ewe dene the so-called restric-
tionAjE:E!EofAontoEby
(AjE)v=Av8v2E:
Here we changed domain and target space of the operator, but the rule
assigning value to the argument remains the same.
We will need the following simple lemma
Lemma 3.1. Letpbe a polynomial, and let Ebe anA-invariant subspace.
Then
p(AjE) =p(A)jE:
Proof. The proof is trivial 
IfE1;E2;:::;Era basis ofA-invariant subspaces, and Ak:=AjEkare
the corresponding restrictions, then, since AEk=AkEkEk, the operators
Akact independently of each other (do not interact), and to analyze action
ofAwe can analyze operators Akseparately.
260 9. Advanced spectral theory
In particular, if we pick a basis in each subspace Ekand join them to
get a basis in V(see Theorem 2.6 from Chapter 4) then the operator Awill
have in this basis the following block-diagonal form
A=0
BBB@A1
A20
...0 Ar1
CCCA
(of course, here we have the correct ordering of the basis in V, rst we take
a basis inE1,then inE2and so on).
Our goal now is to pick a basis of invariant subspaces E1;E2;:::;Er
such that the restrictions Akhave a simple structure. In this case we will
get a basis in which the matrix of Ahas a simple structure.
The eigenspaces Ker( A kI) would be good candidates, because the
restriction of Ato the eigenspace Ker( A kI) is simplykI. Unfortunately,
as we know eigenspaces do not always form a basis (they form a basis if and
only ifAcan be diagonalized, cf Theorem 2.1 in Chapter 4.
However, the so-called generalized eigenspaces will work.
3.2. Generalized eigenspaces.
Denition 3.2. A vector vis called a generalized eigenvector (correspond-
ing to an eigenvalue ) if (A I)kv=0for somek1.
The collection Eof all generalized eigenvectors, together with 0is called
the generalized eigenspace (corresponding to the eigenvalue .
In other words one can represent the generalized eigenspace Eas
(3.1) E=[
k1Ker(A I)k:
The sequence Ker( A I)k,k= 1;2;3;::: is an increasing sequence of
subspaces, i.e.
Ker(A I)kKer(A I)k+18k1:
The representation (3.1) does not look very simple, for it involves an in-
nite union. However, the sequence of the subspaces Ker( A I)kstabilizes,
i.e.
Ker(A I)k= Ker(A I)k+18kk;
so, in fact one can take the nite union.
To show that the sequence of kernels stabilizes, let us notice that if for
nite-dimensional subspaces EandFwe haveE$F(symbolE$Fmeans
thatEFbutE6=F), then dim E < dimF.
3. Generalized eigenspaces 261
Since dim Ker( A I)kdimV <1, it cannot grow to innity, so at
some point
Ker(A I)k= Ker(A I)k+1:
The rest follows from the lemma below.
Lemma 3.3. Let for some k
Ker(A I)k= Ker(A I)k+1:
Then
Ker(A I)k+r= Ker(A I)k+r+18r0:
Proof. Letv2Ker(A I)k+r+1, i.e. (A I)k+r+1v=0. Then
w:= (A I)r2Ker(A I)k+1:
But we know that Ker( A I)k= Ker(A I)k+1sow2Ker(A I)k,
which means ( A I)kw=0. Recalling the denition of wwe get that
(A I)k+rv= (A I)kw=0
sov2Ker(A I)k+r. We proved that Ker( A I)k+r+1Ker(A I)k+r.
The opposite inclusion is trivial. 
Denition. The number d=d() on which the sequence Ker( A I)k
stabilizes, i.e. the number dsuch that
Ker(A I)d 1$Ker(A I)d= Ker(A I)d+1
is called the depth of the eigenvalue .
It follows from the denition of the depth, that for the generalized
eigenspace E
(3.2) ( A I)d()v=08v2E:
Now let us summarize, what we know about generalized eigenspaces.
a)Eis an invariant subspace of A,AEE.
b) Ifd() is the depth of the eigenvalue , then
((A I)jE)d()= (AjE IE)d()=0:
(this is just another way of writing (3.2))
c)(AjE) =fg, because the operator AjE IE, is nilpotent, see
2, and the spectrum of nilpotent operator consists of one point 0,
see Problem 2.1
Now we are ready to state the main result of this section. Let A:V!V.
262 9. Advanced spectral theory
Theorem 3.4. Let(A)consists of rpoints1;2;:::;r, and letEk:=
Ekbe the corresponding generalized eigenspaces. Then the system of sub-
spaceE1;E2;:::;Eris a basis of subspaces in V.
Remark 3.5. If we join the bases in all generalized eigenspaces Ek, then
by Theorem 2.6 from Chapter 4 we will get a basis in the whole space.
In this basis the matrix of the operator Ahas the block diagonal form
A= diagfA1;A2;:::;Arg, whereAk:=AjEk,Ek=Ek. It is also easy to
see, see (3.2) that the operators Nk:=Ak kIEkare nilpotent, Ndk
k=0.
Proof of Theorem 3.4. Letmkbe the multiplicity of the eigenvalue k,
sop(z) =Qr
k=1(z k)mkis the characteristic polynomial of A. Dene
pk(z) =p(z)=(z k)mk=Y
j6=k(z j)mj:
Lemma 3.6.
(3.3) ( A kI)mkjEk=0;
Proof. There are 2 possible simple proofs. The rst one is to notice that
mkdk, wheredkis the depth of the eigenvalue kand use the fact that
(A kI)dkjEk= (Ak kIEk)mk=0;
whereAk:=AjEk(property 2 of the generalized eigenspaces).
The second possibility is to notice that according to the Spectral Map-
ping Theorem, see Corollary 2.2, the operator Pk(A)jEk=pk(Ak) is invert-
ible. By the Cayley{Hamilton Theorem (Theorem 1.1)
0=p(A) = (A kI)mkpk(A);
and restriction all operators to Ekwe get
0=p(Ak) = (Ak kIEk)mkpk(Ak);
so
(Ak kIEk)mk=p(Ak)pk(Ak) 1=0pk(Ak) 1=0:

To prove the theorem dene
q(z) =rX
k=1pk(z):
Sincepk(j) = 0 forj6=kandpk(k)6= 0, we can conclude that q(k)6= 0
for allk. Therefore, by the Spectral Mapping Theorem, see Corollary 2.2,
the operator
B=q(A)
is invertible.
3. Generalized eigenspaces 263
Note thatBEkEk(anyA-invariant subspace is also p(A)-invariant).
SinceBis an invertible operator, dim( BEk) = dimEk, which together with
BEkEkimpliesBEk=Ek. Multiplying the last identity by B 1we get
thatB 1Ek=Ek, i.e. thatEkis an invariant subspace of B 1.
Note also, that it follows from (3.3) that
pk(A)jEj=08j6=k;
becausepk(A)jEj=pk(Aj) andpk(Aj) contains the factor ( Aj jIEj)mj=
0.
Dene the operators Pkby
Pk=B 1pk(A):
Lemma 3.7. For the operators Pkdened above
a)P1+P2+:::+Pr=I;
b)PkjEj=0forj6=k;
c) RanPkEk;
d)moreover,Pkv=v8v2Ek, so, in fact RanPk=Ek.
Proof. Property 1 is trivial:
rX
k=1Pk=B 1rX
k=1Pkpk(A) =B 1B=I:
Property 2 follows from (3.3). Indeed, pk(A) contains the factor ( A j)mj,
restriction of which to Ejis zero. Therefore pk(A)jEj=0and thusPkjEj=
B 1pk(A)jEj=0.
To prove property 3, recall that according to Cayley{Hamilton Theorem
p(A) =0. Sincep(z) = (z k)mkpk(z), we have for w=pk(A)v
(A kI)mkw= (A kI)mkpk(A)v=p(A)v=0:
That means, any vector win Ranpk(A) is annihilated by some power of
(A kI), which by denition means that Ran pk(A)Ek.
To prove the last property, let us notice that it follows from (3.3) that
forv2Ek
pk(A)v=rX
j=1pj(A)v=Bv;
which impliesPkv=B 1Bv=v. 
Now we are ready to complete the proof of the theorem. Take v2Vand
dene vk=Pkv. Then according to Statement c) of Lemma 3.7, vk2Ek,
264 9. Advanced spectral theory
and by Statement a),
v=rX
k=1vk;
sovadmits a representation as a linear combination.
To show that this representation is unique, we can just note, that if vis
represented as v=Pr
k=1vk,vk2Ek, then it follows from the Statements
b) and d) of Lemma 3.7 that
Pkv=Pk(v1+v2+:::+vr) =Pkvk=vk:

3.3. Geometric meaning of algebraic multiplicity.
Proposition 3.8. Algebraic multiplicity of an eigenvalue equals the dimen-
sion of the corresponding generalized eigenspace.
Proof. According to Remark 3.5, if we joint bases in generalized eigenspaces
Ek=Ekto get a basis in the whole space, the matrix of Ain any such
basis has a block-diagonal form diag fA1;A2;:::;Arg, whereAk:=AjEk.
OperatorsNk=Ak kIEkare nilpotent, so (Nk) =f0g. Therefore,
the spectrum of the operator Ak(recall that Ak=Nk kI) consists of
one eigenvalue kof (algebraic) multiplicity nk= dimEk. The multiplicity
equalsnkbecause an operator in a nite-dimensional space Vhas exactly
dimVeigenvalues counting multiplicities, and Akhas only one eigenvalue.
Note that we are free to pick bases in Ek, so let us pick them in such a
way that the corresponding blocks Akare upper triangular. Then
det(A I) =rY
k=1det(Ak IEk) =rY
k=1(k )nk:
But this means that the algebraic multiplicity of the eigenvalue kisnk=
dimEk. 
3.4. An important application. The following corollary is very impor-
tant for dierential equations.
Corollary 3.9. Any operator AinVcan be represented as A=D+N,
whereDis diagonalizable (i.e. diagonal in some basis) and Nis nilpotent
(Nm=0for somem), andDN=ND.
Proof. As we discussed above, see Remark 3.5, if we join the bases in Ek
to get a basis in V, then in this basis Ahas the block diagonal form A=
diagfA1;A2;:::;Arg, whereAk:=AjEk,Ek=Ek. The operators Nk:=
Ak kIEkare nilpotent, and the operator D= diagf1IE1;2IE2:::;rIErg
3. Generalized eigenspaces 265
is diagonal (in this basis). Notice also that kIEkNk=NkkIEk(iden-
tity operator commutes with any operator), so the block diagonal operator
N= diagfN1;N2;:::;Nrgcommutes with D,DN=ND. Therefore, den-
ingNas the block diagonal operator N= diagfN1;N2;:::;Nrgwe get the
desired decomposition. 
This corollary allows us to compute functions of operators. Let us recall
that ifpis a polynomial of degree d, thenp(a+x) can be computed with
the help of Taylor's formula
p(a+x) =dX
k=0p(k)(a)
k!xk
This formula is an algebraic identity, meaning that for each polynomial p
we can check that the formula is true using formal algebraic manipulations
withaandxand not caring about their nature.
Since operators DandNcommute,DN =ND, the same rules as for
usual (scalar) variables apply to them, and we can write (by plugging D
instead ofaandNinstead ofx
p(A) =p(D+N) =dX
k=0p(k)(D)
k!Nk:
Here, to compute the derivative p(k)(D) we rst compute the kth derivative
of the polynomial p(x) (using the usual rules from calculus), and then plug
Dinstead ofx.
But sinceNis nilpotent, Nm=0for somem, only rst mterms can
be non-zero, so
p(A) =p(D+N) =m 1X
k=0f(k)(D)
k!Nk:
Inmis much smaller than d, this formula makes computation of p(A) much
easier.
The same approach works if pis not a polynomial, but an innite power
series. For general power series we have to be careful about convergence
of all the series involved, so we cannot say that the formula is true for an
arbitrary power series p(x). However, if the radius of convergence of the
power series is1, then everything works ne. In particular, if p(x) =ex,
then, using the fact that ( ex)0=exwe get.
eA=m 1X
k=0eD
k!Nk=eDm 1X
k=01
k!Nk
This formula has important applications in dierential equation.
266 9. Advanced spectral theory
Note, that the fact that ND=DN is essential here!
4. Structure of nilpotent operators
Recall, that an operator Ain a vector space Vis called nilpotent ifAk= 0
for some exponent k.
In the previous section we have proved, see Remark 3.5, that if we join
the bases in all generalized eigenspaces Ek=Ekto get a basis in the
whole space, then the operator Ahas in this basis a block diagonal form
diagfA1;A2;:::;Argand operators Akca be represented as Ak=kI+Nk,
whereNkare nilpotent operators.
In each generalized eigenspace Ekwe want to pick up a basis such that
the matrix of Akin this basis has the simplest possible form. Since matrix
(in any basis) of the identity operator is the identity matrix, we need to nd
a basis in which the nilpotent operator Nkhas a simple form.
Since we can deal with each Nkseparately, we will need to consider the
following problem:
For a nilpotent operator And a basis such that the matrix
ofAin this basis is simple.
Let see, what does it mean for a matrix to have a simple form. It is easy to
see that the matrix
(4.1)0
BBBBBB@0 1 0
0 1
0...
...1
0 01
CCCCCCA
is nilpotent.
These matrices (together with 1 1 zero matrices) will be our \building
blocks". Namely, we will show that for any nilpotent operator one can nd
a basis such that the matrix of the operator in this basis has the block
diagonal form diag fA1;A2;:::;Arg, where each Akis either a block of form
(4.1) or a 11 zero block.
Let us see what we should be looking for. Suppose the matrix of an
operatorAhas in a basis v1;v2;:::;vpthe form (4.1). Then
Av1=0 (4.2)
and
Avk+1=vk; k = 1;2;:::;p 1: (4.3)
4. Structure of nilpotent operators 267
Thus we have to be looking for the chains of vectors v1;v2;:::;vpsatisfying
the above relations (4.2), (4.3).
4.1. Cycles of generalized eigenvectors.
Denition. LetAbe a nilpotent operator. A chain of non-zero vectors
v1;v2;:::;vpsatisfying relations (4.2), (4.3) is called a cycle of generalized
eigenvectors ofA. The vector v1is called the initial vector of the cycle, the
vector vpis called the end vector of the cycle, and the number pis called
thelength of the cycle.
Remark. A similar denition can be made for an arbitrary operator. Then
all vectors vkmust belong to the same generalized eigenspace E, and they
must satisfy the identities
(A I)v1=0; (A I)vk+1=vk; k = 1;2;:::;p 1;
Theorem 4.1. LetAbe a nilpotent operator, and let C1;C2;:::;Crbe cycles
of its generalized eigenvectors, Ck=vk
1;vk
2;:::;vk
pk,pkbeing the length of
the cycleCk. Assume that the initial vectors v1
1;v2
1;:::;vr
1are linearly in-
dependent. Then no vector belongs to two cycles, and the union of all the
vectors from all the cycles is a linearly independent.
Proof. Letn=p1+p2+:::+prbe the total number of vectors in all the
cycles2. We will use induction in n. Ifn= 1 the theorem is trivial.
Let us now assume, that the theorem is true for all operators and for all
collection of cycles, as long as the total number of vectors in all the cycles
is strictly less than n.
Without loss of generality we can assume that the vectors vk
jspan the
whole space V, because, otherwise we can consider instead of the operator
Aits restriction onto the invariant subspace span fvk
j:k= 1;2;:::;r; 1
jpkg.
Consider the subspace Ran A. It follows from the relations (4.2), (4.3)
that vectors vk
j:k= 1;2;:::;r; 1jpk 1 span Ran A. Note that if
pk>1 then the system vk
1;vk
2;:::;vk
pk 1is a cycle, and that Aannihilates
any cycle of length 1.
Therefore, we have nitely many cycles, and initial vectors of these cycles
are linearly independent, so the induction hypothesis applies, and the vectors
vk
j:k= 1;2;:::;r; 1jpk 1 are linearly independent. Since these
vectors also span Ran A, we have a basis there. Therefore,
rankA= dim RanA=n r
2Here we just count vectors in each cycle, and add all the numbers. We do not care if some
cycles have a common vector, we count this vector in each cycle it belongs to (of course, according
to the theorem, it is impossible, but initially we cannot assume that)
268 9. Advanced spectral theory
(we hadnvectors, and we removed one vector vk
pkfrom each cycle Ck,
k= 1;2;:::;r , so we have n rvectors in the basis vk
j:k= 1;2;:::;r; 1
jpk 1 ). On the other hand Avk
1= 0 fork= 1;2;:::;r , and since these
vectors are linearly independent dim Ker Ar. By the Rank Theorem
(Theorem 7.1 from Chapter 2)
dimV= rankA+ dim KerA= (n r) + dim Ker A(n r) +r=n
so dimVn.
On the other hand Vis spanned by nvectors, therefore the vectors vk
j:
k= 1;2;:::;r; 1jpk, form a basis, so they are linearly independent 
4.2. Jordan canonical form of a nilpotent operator.
Theorem 4.2. LetA:V!Vbe a nilpotent operator. Then Vhas a basis
consisting of union of cycles of generalized eigenvectors of the operator A.
Proof. We will use induction in nwheren= dimV. Forn= 1 the theorem
is trivial.
Assume that the theorem is true for any operator acting in a space of
dimension strictly less than n.
Consider the subspace X= RanA.Xis an invariant subspace of the
operatorA, so we can consider the restriction AjX.
SinceAis not invertible, dim Ran A < dimV, so by the induction hy-
pothesis there exist cycles C1;C2;:::;Crof generalized eigenvectors such that
their union is a basis in X. LetCk=vk
1;vk
2;:::;vk
pk, where vk
1is the initial
vector of the cycle.
Since the end vector vk
pkbelong to Ran A, one can nd a vector vk
pk+1
such thatAvpk+1=vk
pk. So we can extend each cycle Ckto a bigger cycle
eCk=vk
1;vk
2;:::;vk
pk;vk
pk+1. Since the initial vectors vk
1of cycleseCk,k=
1;2;:::;r are linearly independent, the above Theorem 4.1 implies that the
union of these cycles is a linearly independent system.
By the denition of the cycle we have vk
12KerA, and we assumed
that the initial vectors vk
1,k= 1;2;:::;r are linearly independent. Let us
complete this system to a basis in Ker A, i.e. let nd vectors u1;u2;:::;uq
such that the system v1
1;v2
1;:::;vr
1;u1;u2;:::;uqis a basis in Ker A(it may
happen that the system vk
1,k= 1;2;:::;r is already a basis in Ker A, in
which case we put q= 0 and add nothing).
The vector ujcan be treated as a cycle of length 1, so we have a collec-
tion of cycles eC1;eC2;:::;eCr;u1;u2;:::;uq, whose initial vectors are linearly
independent. So, we can apply Theorem 4.1 to get that the union of all
these cycles is a linearly independent system.
4. Structure of nilpotent operators 269
To show that it is a basis, let us count the dimensions. We know that
the cyclesC1;C2;:::;Crhave dim Ran A= rankAvectors total. Each cycle
eCkwas obtained from Ckby adding 1 vector to it, so the total number of
vectors in all the cycles eCkis rankA+r.
We know that dim Ker A=r+q(because v1
1;v2
1;:::;vr
1;u1;u2;:::;uq
is a basis there). We added to the cycles eC1;eC2;:::;eCradditionalqvectors,
so we got
rankA+r+q= rankA+ dim KerA= dimV
linearly independent vectors. But dim Vlinearly independent vectors is a
basis. 
Denition. A basis consisting of a union of cycles of generalized eigen-
vectors of a nilpotent operator A(existence of which is guaranteed by the
Theorem 4.2) is called a Jordan canonical basis for A.
Note, that such basis is not unique.
Corollary 4.3. LetAbe a nilpotent operator. There exists a basis (a Jordan
canonical basis) such that the matrix of Ain this basis is a block diagonal
diagfA1;A2;:::;Arg, where all Ak(except may be one) are blocks of form
(4.1) , and one of the blocks Akcan be zero.
The matrix of Ain a Jordan canonical basis is called the Jordan canoni-
cal form of the operator A. We will see later that the Jordan canonical form
is unique, if we agree on how to order the blocks (i.e. on how to order the
vectors in the basis).
Proof of Corollary 4.3. According to Theorem 4.2 one can nd a basis
consisting of a union of cycles of generalized eigenvectors. A cycle of size
pgives rise to a ppdiagonal block of form (4.1), and a cycle of length 1
correspond to a 1 1 zero block. We can join these 1 1 zero blocks in one
large zero block (because o-diagonal entries are 0). 
4.3. Dot diagrams. Uniqueness of the Jordan canonical form.
There is a good way of visualizing Theorem 4.2 and Corollary 4.3, the so-
called dot diagrams. This methods also allows us to answer many natural
questions, like \is the block diagonal representation given by Corollary 4.3
unique?"
Of course, if we treat this question literally, the answer is \no", for we
always can change the order of the blocks. But, if we exclude such trivial
possibilities, for example by agreeing on some order of blocks (say, if we put
all non-zero blocks in decreasing order, and then put the zero block), is the
representation unique, or not?
270 9. Advanced spectral theory
r r r r r r
r r r r
r r
r
r0
BBBBBBBBBBBBBBBBBBBBBBB@0 1
0 1
0 1
0 1 0
0
0 1
0 1
0
0 1
0
0 0 1
0
0
01
CCCCCCCCCCCCCCCCCCCCCCCA
Figure 1. Dot diagram and corresponding Jordan canonical form of a
nilpotent operator
To better understand the structure of nilpotent operators, described in
the Section 4.1, let us draw the so-called dot diagram. Namely, suppose we
have a basis, which is a union of cycles of generalized eigenvalues. Let us
represent the basis by an array of dots, so that each column represents a
cycle. The rst row consists of initial vectors of cycles, and we arrange the
columns (cycles) by their length, putting the longest one to the left.
On the gure 1 we have the dot diagram of a nilpotent operator, as
well as its Jordan canonical form. This dot diagram shows, that the basis
has 1 cycle of length 5, one cycle of length 3, two cycles of length 2, and 2
cycles of length 1. The cycle of length 5 corresponds to the 5 5 block of
the matrix, the cycle of length 3 correspond to 3 non-zero block, and two
cycles of length 2 correspond to two 2 2 blocks. Three cycles of length 1
correspond to two zero entries on the diagonal. Here in each block we only
giving the main diagonal and the diagonal above it; all other entries of the
matrix are zero.
If we agree on the ordering of the blocks, there is a one-to-one corre-
spondence between dot diagrams and Jordan canonical forms (for nilpotent
operators). So, the question about uniqueness of the Jordan canonical form
is equivalent to the question about uniqueness of the dot diagram.
To answer this question, let us analyze, how the operator Atransforms
the dot diagram. Since the operator Aannihilates initial vectors of the
cycles, and moves vector vk+1of a cycle to the vector vk, we can see that
4. Structure of nilpotent operators 271
the operator Aacts on its dot diagram by deleting the rst (top) row of the
diagram.
The new dot diagram corresponds to a Jordan canonical basis in Ran A,
and allows us to write down the Jordan canonical form for the restriction
AjRanA.
Similarly, it is not hard to see that the operator Akremoves the rst
krows of the dot diagram. Therefore, if for all kwe know the dimensions
dim Ker(Ak), we know the dot diagram of the operator A. Namely, the
number of dots in the rst row is dim Ker A, the number of dots in the
second row is
dim Ker(A2) dim KerA;
and the number of dots in the kth row is
dim Ker(Ak) dim Ker(Ak+1):
But this means that the dot diagram, which was initially dened using
a Jordan canonical basis, does not depend on a particular choice of such a
basis. Therefore, the dot diagram, is unique! This implies that if we agree
on the order of the blocks, then the Jordan canonical form is unique.
4.4. Computing a Jordan canonical basis. Let us say few words about
computing a Jordan canonical basis for a nilpotent operator. Let p1be the
largest integer such that Ap16=0(soAp1+1=0). One can see from the
above analysis of dot diagrams, that p1is the length of the longest cycle.
Computing operators Ak,k= 1;2;:::;p 1, and counting dim Ker( Ak) we
can construct the dot diagram of A. Now we want to put vectors instead of
dots and nd a basis which is a union of cycles.
We start by nding the longest cycles (because we know the dot diagram,
we know how many cycles should be there, and what is the length of each
cycle). Consider a basis in the column space Ran( Ap1). Name the vectors
in this basis v1
1;v2
1;:::;vr1
1, these will be the initial vectors of the cycles.
Then we nd the end vectors of the cycles v1
p1;v2
p1;:::;vr1p1by solving the
equations
Ap1vk
p1=vk
1; k = 1;2;:::;r 1:
Applying consecutively the operator Ato the end vector vk
p1, we get all the
vectors vk
jin the cycle. Thus, we have constructed all cycles of maximal
length.
Letp2be the length of a maximal cycle among those that are left to
nd. Consider the subspace Ran( Ap2), and let dim Ran( Ap2) =r2. Since
Ran(Ap1)Ran(Ap2), we can complete the basis v1
1;v2
1;:::;vr1
1to a basis
272 9. Advanced spectral theory
v1
1;v2
1;:::;vr1
1;vr1+1
1;:::;vr2
1in Ran(Ar2). Then we nd end vectors of the
cyclesCr1+1;:::;Cr2by solving (for vk
p2) the equations
Ap1vk
p2=vk
1; k =r1+ 1;r1+ 2;:::;r 2;
thus constructing th cycles of length p2.
Letp3denote the length of a maximal cycle among ones left. Then,
completing the basis v1
1;v2
1;:::;vr2
1in Ker(Ap2) to a basis in Ker( Ap3we
construct the cycles of length p3, and so on. . .
One nal remark: as we discussed above, if we know the dot diagram, we
know the canonical form, so after we have found a Jordan canonical basis,
we do not need to compute the matrix of Ain this basis: we already know
it!
5. Jordan decomposition theorem
Theorem 5.1. Given an operator Athere exist a basis (Jordan canonical
basis) such that the matrix of Ain this basis has a block diagonal form with
blocks of form
(5.1)0
BBBBB@1 0
1
......1
0 1
CCCCCA
whereis an eigenvalue of A. Here we assume that the block of size 1is
just.
The block diagonal form from Theorem 5.1 is called the Jordan canonical
form of the operator A. The corresponding basis is called a Jordan canonical
basis for an operator A.
Proof of Theorem 5.1. According to Theorem 3.4 and Remark 3.5, if
we join bases in the generalized eigenspaces Ek=Ekto get a basis in
the whole space, the matrix of Ain this basis has a block diagonal form
diagfA1;A2;:::;Arg, whereAk=AjEk. The operators Nk=Ak kIEk
are nilpotent, so by Theorem 4.2 (more precisely, by Corollary 4.3) one can
nd a basis in Eksuch that the matrix of Nkin this basis is the Jordan
canonical form of Nk. To get the matrix of Akin this basis one just puts k
instead of 0 on the main diagonal. 
5. Jordan decomposition theorem 273
5.1. Remarks about computing Jordan canonical basis. First of all
let us recall that the computing of eigenvalues is the hardest part, but here
we do not discuss this part, and assume that eigenvalues are already com-
puted.
For each eigenvalue we compute subspaces Ker( A I)k,k= 1;2;:::
until the sequence of the subspaces stabilizes. In fact, since we have an
increasing sequence of subspaces (Ker( A I)kKer(A I)k+1), then it
is sucient only to keep track of their dimension (or ranks of the operators
(A I)k). For an eigenvalue letm=mbe the number where the
sequence Ker( A I)kstabilizes, i.e. msatises
dim Ker(A I)m 1<dim Ker(A I)m= dim Ker( A I)m+1:
ThenE= Ker(A I)mis the generalized eigenspace corresponding to the
eigenvalue.
After we computed all the generalized eigenspaces there are two possible
ways of action. The rst way is to nd a basis in each generalized eigenspace,
so the matrix of the operator Ain this basis has the block-diagonal form
diagfA1;A2;:::;Arg, whereAk=AjEk. Then we can deal with each ma-
trixAkseparately. The operators Nk=Ak kIare nilpotent, so applying
the algorithm described in Section 4.4 we get the Jordan canonical repre-
sentation for Nk, and putting kinstead of 0 on the main diagonal, we get
the Jordan canonical representation for the block Ak. The advantage of this
approach is that we are working with smaller blocks. But we need to nd
the matrix of the operator in a new basis, which involves inverting a matrix
and matrix multiplication.
Another way is to nd a Jordan canonical basis in each of the generalized
eigenspaces Ekby working directly with the operator A, without splitting
it rst into the blocks. Again, the algorithm we outlined above in Section
4.4 works with a slight modication. Namely, when computing a Jordan
canonical basis for a generalized eigenspace Ek, instead of considering sub-
spaces Ran( Ak kI)j, which we would need to consider when working with
the blockAkseparately, we consider the subspaces ( A kI)jEk.

Index
Mm;n, 3
Mmn, 3
k;j,seeKroneker delta
adjoint
of an operator, 142
basis, 6
biorthogonal, seebasis, dual
dual, 218
of subspaces, 109
orthogonal, 127
orthonormal, 127
coordinates
of a vector in the basis, 6
counting multiplicities, 102
dual basis, 218
dual space, 215
duality, 241
eigenvalue, 100
eigenvector, 100
Einstein notation, 234, 243
entry, entries
of a matrix, 4
of a tensor, 246
Fourier decomposition
abstract, non-orthogonal, 220, 224
abstract, orthogonal, 128, 225
Frobenius norm, 182
functional
linear, 215generalized eigenspace, 258
generalized eigenvector, 258
generating system, 7
Gram{Schmidt orthogonalization, 131
Hermitian matrix, 166
Hilbert{Schmidt norm, 182
inner product
abstract, 119
inCn, 118
inner product space, 119
invariant subspace, 253
isometry, 146
Jordan canonical
basis, 267, 270
form, 267, 270
basis
for a nilpotent operator, 267
form
for a nilpotent operator, 267
Jordan decomposition theorem, 270
for a nilpotent operator, 267
Kroneker delta, 218, 224
least square solution, 136
minimal norm, 185
linear combination, 6
trivial, 8
linear functional, 215
linearly dependent, 8
linearly independent, 8
matrix, 4
275
276 Index
antisymmetric, 11
Hermitian, 166
lower triangular, 81
symmetric, 5, 11
triangular, 81
upper triangular, 31, 81
minor, 96
Moore{Penrose inverse, 185
multilinear function, 237
multilinear functional, seetensor
multiplicities
counting, 102
multiplicity
algebraic, 102
geometric, 103
norm, 117, 123
Euclidean in RnorCn, 117
Frobenius, 182
Hilbert{Scmidt, 182
operator, of a linear transformation, 181
normal operator, 167
normed space, 123
operator norm, 181
orthogonal complement, 133
orthogonal projection, 129
polynomial matrix, 94
projection
orthogonal, 129
Schmidt decomposition, 174
self-adjoint operator, 166
singular value decomposition, 176
reduced (compact) form, 176
singular values, 173
space
dual, 215
Spectral theory, 99
spectrum, 100
submatrix, 96
subspace
invariant, 253
tensor, 237
r-covariants-contravariant, 241
contravariant, 241
covariant, 241
trace, 23
transpose, 4
triangular matrix, 81
eigenvalues of, 103
unitary operator, 147
valencyof a tensor, 237
