







Bekenstein bound - Wikipedia










































































Jump to content
















Main menu












Main menu


move to sidebar


hide







		Navigation
	






Main page
Contents
Current events
Random article
About Wikipedia
Contact us
Donate











		Contribute
	






Help
Learn to edit
Community portal
Recent changes
Upload file








































Search
























Search




























































Create account




Log in


















Personal tools












 
Create account
 
Log in











		Pages for logged out editors 
learn more








Contributions
Talk


























































Contents


move to sidebar


hide










(Top)












1
Equations
















2
Origins
















3
Proof in quantum field theory
















4
See also
















5
References
















6
External links




































Toggle the table of contents
















Bekenstein bound








14 languages










Català
Deutsch
Español
فارسی
Français
日本語
Português
Română
Русский
Slovenčina
Српски / srpski
Українська
Tiếng Việt
中文




Edit links
























Article
Talk












English




































Read
Edit
View history
















Tools












Tools


move to sidebar


hide







		Actions
	






Read
Edit
View history











		General
	






What links here
Related changes
Upload file
Special pages
Permanent link
Page information
Cite this page
Get shortened URL
Download QR code
Wikidata item











		Print/export
	






Download as PDF
Printable version




















































From Wikipedia, the free encyclopedia






Upper limit on entropy in physics


According to the Bekenstein bound, the 
entropy
 of a 
black hole
 is proportional to the number of 
Planck areas
 that it would take to cover the black hole's 
event horizon
.


In 
physics
, the 
Bekenstein bound
 (named after 
Jacob Bekenstein
) is an upper limit on the 
thermodynamic entropy
 
S
, or 
Shannon entropy
 
H
, that can be contained within a given finite region of space which has a finite amount of energy—or conversely, the maximal amount of information required to perfectly describe a given physical system down to the quantum level.
[1]
 It implies that the information of a physical system, or the information necessary to perfectly describe that system, must be finite if the region of space and the energy are finite. In 
computer science
 this implies that non-finite models such as 
Turing machines
 are not realizable as finite devices.





Equations
[
edit
]


The universal form of the bound was originally found by Jacob Bekenstein in 1981 as the 
inequality
[1]
[2]
[3]










S


≤








2


π


k


R


E






ℏ


c








,






{\displaystyle S\leq {\frac {2\pi kRE}{\hbar c}},}





where 
S
 is the 
entropy
, 
k
 is the 
Boltzmann constant
, 
R
 is the 
radius
 of a 
sphere
 that can enclose the given system, 
E
 is the total 
mass–energy
 including any 
rest masses
, 
ħ
 is the 
reduced Planck constant
, and 
c
 is the 
speed of light
. Note that while gravity plays a significant role in its enforcement, the expression for the bound does not contain the 
gravitational constant
 
G
, and so, it ought to apply to 
quantum field theory in curved spacetime
.

The 
Bekenstein–Hawking boundary entropy
 of three-dimensional 
black holes
 exactly saturates the bound. The 
Schwarzschild radius
 is given by











r






s








=








2


G


M






c




2










,






{\displaystyle r_{\rm {s}}={\frac {2GM}{c^{2}}},}





and so the two-dimensional area of the black hole's event horizon is









A


=


4


π




r






s








2






=








16


π




G




2








M




2










c




4










,






{\displaystyle A=4\pi r_{\rm {s}}^{2}={\frac {16\pi G^{2}M^{2}}{c^{4}}},}





and using the 
Planck length












l






P








2






=


ℏ


G




/






c




3






,






{\displaystyle l_{\rm {P}}^{2}=\hbar G/c^{3},}





the Bekenstein–Hawking entropy is









S


=








k


A






4


 




l






P








2












=








4


π


k


G




M




2










ℏ


c








.






{\displaystyle S={\frac {kA}{4\ l_{\rm {P}}^{2}}}={\frac {4\pi kGM^{2}}{\hbar c}}.}






One interpretation of the bound makes use of the 
microcanonical
 formula for entropy,









S


=


k


log


⁡


Ω


,






{\displaystyle S=k\log \Omega ,}





where 








Ω






{\displaystyle \Omega }




 is the number of energy 
eigenstates
 accessible to the system. This is equivalent to saying that the dimension of the 
Hilbert space
 describing the system is
[4]
[5]










dim


⁡






H






=


exp


⁡




(








2


π


R


E






ℏ


c








)




.






{\displaystyle \dim {\mathcal {H}}=\exp \left({\frac {2\pi RE}{\hbar c}}\right).}






The bound is closely associated with 
black hole thermodynamics
, the 
holographic principle
 and the 
covariant entropy bound
 of quantum gravity, and can be derived from a conjectured strong form of the latter.
[4]




Origins
[
edit
]


Bekenstein derived the bound from heuristic arguments involving 
black holes
. If a system exists that violates the bound, i.e., by having too much entropy, Bekenstein argued that it would be possible to violate the 
second law of thermodynamics
 by lowering it into a black hole. In 1995, 
Ted Jacobson
 demonstrated that the 
Einstein field equations
 (i.e., 
general relativity
) can be derived by assuming that the Bekenstein bound and the 
laws of thermodynamics
 are true.
[6]
[7]
 However, while a number of arguments were devised which show that some form of the bound must exist in order for the laws of thermodynamics and general relativity to be mutually consistent, the precise formulation of the bound was a matter of debate until Casini's work in 2008.
[2]
[3]
 
[8]
[9]
[10]
[11]
[12]
[13]
[14]
[15]
[16]


The following is a heuristic derivation that shows 








S


≤


K








k


R


E






ℏ


c












{\displaystyle S\leq K{\frac {kRE}{\hbar c}}}




 for some constant 








K






{\displaystyle K}




. Showing that 








K


=


2


π






{\displaystyle K=2\pi }




 requires a more technical analysis.

Suppose we have a black hole of mass 








M






{\displaystyle M}




, then the 
Schwarzschild radius
 of the black hole is 










R




b


h






∼








G


M






c




2














{\displaystyle R_{bh}\sim {\frac {GM}{c^{2}}}}




, and the Bekenstein–Hawking entropy of the black hole is 








∼








k




c




3








R




b


h






2










ℏ


G








∼








k


G




M




2










ℏ


c












{\displaystyle \sim {\frac {kc^{3}R_{bh}^{2}}{\hbar G}}\sim {\frac {kGM^{2}}{\hbar c}}}




. 

Now take a box of energy 








E






{\displaystyle E}




, entropy 








S






{\displaystyle S}




, and side length 








R






{\displaystyle R}




. If we throw the box into the black hole, the mass of the black hole goes up to 








M


+






E




c




2














{\displaystyle M+{\frac {E}{c^{2}}}}




, and the entropy goes up by 














k


G


M


E






ℏ




c




3
















{\displaystyle {\frac {kGME}{\hbar c^{3}}}}




. Since entropy does not decrease, 














k


G


M


E






ℏ




c




3












≳


S






{\displaystyle {\frac {kGME}{\hbar c^{3}}}\gtrsim S}




 . 

In order for the box to fit inside the black hole, 








R


≲








G


M






c




2














{\displaystyle R\lesssim {\frac {GM}{c^{2}}}}




 . If the two are comparable, 








R


∼








G


M






c




2














{\displaystyle R\sim {\frac {GM}{c^{2}}}}




, then we have derived the BH bound: 








S


≲








k


R


E






ℏ


c












{\displaystyle S\lesssim {\frac {kRE}{\hbar c}}}




.



Proof in quantum field theory
[
edit
]


A proof of the Bekenstein bound in the framework of 
quantum field theory
 was given in 2008 by Casini.
[17]
 One of the crucial insights of the proof was to find a proper interpretation of the quantities appearing on both sides of the bound.

Naive definitions of entropy and energy density in Quantum Field Theory suffer from 
ultraviolet divergences
. In the case of the Bekenstein bound, ultraviolet divergences can be avoided by taking differences between quantities computed in an excited state and the same quantities computed in the 
vacuum state
. For example, given a spatial region 








V






{\displaystyle V}




, Casini defines the entropy on the left-hand side of the Bekenstein bound as 











S




V






=


S


(




ρ




V






)


−


S


(




ρ




V






0






)


=


−




t


r




(




ρ




V






log


⁡




ρ




V






)


+




t


r




(




ρ




V






0






log


⁡




ρ




V






0






)






{\displaystyle S_{V}=S(\rho _{V})-S(\rho _{V}^{0})=-\mathrm {tr} (\rho _{V}\log \rho _{V})+\mathrm {tr} (\rho _{V}^{0}\log \rho _{V}^{0})}





where 








S


(




ρ




V






)






{\displaystyle S(\rho _{V})}




 is the 
Von Neumann entropy
 of the 
reduced density matrix
 










ρ




V










{\displaystyle \rho _{V}}




 associated with 








V






{\displaystyle V}




 in the excited state 








ρ






{\displaystyle \rho }




, and 








S


(




ρ




V






0






)






{\displaystyle S(\rho _{V}^{0})}




 is the corresponding Von Neumann entropy for the vacuum state 










ρ




0










{\displaystyle \rho ^{0}}




.

On the right-hand side of the Bekenstein bound, a difficult point is to give a rigorous interpretation of the quantity 








2


π


R


E






{\displaystyle 2\pi RE}




, where 








R






{\displaystyle R}




 is a characteristic length scale of the system and 








E






{\displaystyle E}




 is a characteristic energy. This product has the same units as the generator of a 
Lorentz boost
, and the natural analog of a boost in this situation is the 
modular Hamiltonian
 of the vacuum state 








K


=


−


log


⁡




ρ




V






0










{\displaystyle K=-\log \rho _{V}^{0}}




. Casini defines the right-hand side of the Bekenstein bound as the difference between the expectation value of the modular Hamiltonian in the excited state and the vacuum state,











K




V






=




t


r




(


K




ρ




V






)


−




t


r




(


K




ρ




V






0






)


.






{\displaystyle K_{V}=\mathrm {tr} (K\rho _{V})-\mathrm {tr} (K\rho _{V}^{0}).}






With these definitions, the bound reads











S




V






≤




K




V






,






{\displaystyle S_{V}\leq K_{V},}





which can be rearranged to give











t


r




(




ρ




V






log


⁡




ρ




V






)


−




t


r




(




ρ




V






log


⁡




ρ




V






0






)


≥


0.






{\displaystyle \mathrm {tr} (\rho _{V}\log \rho _{V})-\mathrm {tr} (\rho _{V}\log \rho _{V}^{0})\geq 0.}






This is simply the statement of positivity of 
quantum relative entropy
, which proves the Bekenstein bound.

However, the modular Hamiltonian can only be interpreted as a weighted form of energy for 
conformal field theories
, and when V is a sphere.

This construction allows us to make sense of the 
Casimir effect
[4]
 where the localized energy density is 
lower
 than that of the vacuum, i.e. a 
negative
 localized energy. The localized entropy of the vacuum is nonzero, and so, the Casimir effect is possible for states with a lower localized entropy than that of the vacuum. 
Hawking radiation
 can be explained by dumping localized negative energy into a black hole.



See also
[
edit
]


Margolus–Levitin theorem


Landauer's principle


Bremermann's limit


Kolmogorov complexity


Beyond black holes


Digital physics


Limits of computation


Chandrasekhar limit


References
[
edit
]






^ 
a
 
b
 
Bekenstein, Jacob D. (1981). 
"Universal upper bound on the entropy-to-energy ratio for bounded systems"
 
(PDF)
. 
Physical Review D
. 
23
 (2): 287–298. 
Bibcode
:
1981PhRvD..23..287B
. 
doi
:
10.1103/PhysRevD.23.287
. 
S2CID
 
120643289
.




^ 
a
 
b
 
Bekenstein, Jacob D. (2005). "How does the Entropy/Information Bound Work?". 
Foundations of Physics
. 
35
 (11): 1805–1823. 
arXiv
:
quant-ph/0404042
. 
Bibcode
:
2005FoPh...35.1805B
. 
doi
:
10.1007/s10701-005-7350-7
. 
S2CID
 
118942877
.




^ 
a
 
b
 
Bekenstein, Jacob (2008). 
"Bekenstein bound"
. 
Scholarpedia
. 
3
 (10): 7374. 
Bibcode
:
2008SchpJ...3.7374B
. 
doi
:
10.4249/scholarpedia.7374
.




^ 
a
 
b
 
c
 
Bousso, Raphael (2004-02-12). "Bound states and the Bekenstein bound". 
Journal of High Energy Physics
. 
2004
 (2): 025. 
arXiv
:
hep-th/0310148
. 
Bibcode
:
2004JHEP...02..025B
. 
doi
:
10.1088/1126-6708/2004/02/025
. 
ISSN
 
1029-8479
. 
S2CID
 
17662307
.




^
 
't Hooft, G.
 (1993-10-19). "Dimensional reduction in quantum gravity". 
arXiv
:
gr-qc/9310026
.




^
 
Jacobson, Ted (1995). 
"Thermodynamics of Spacetime: The Einstein Equation of State"
 
(PDF)
. 
Physical Review Letters
. 
75
 (7): 1260–1263. 
arXiv
:
gr-qc/9504004
. 
Bibcode
:
1995PhRvL..75.1260J
. 
CiteSeerX
 
10.1.1.54.6675
. 
doi
:
10.1103/PhysRevLett.75.1260
. 
PMID
 
10060248
. 
S2CID
 
13223728
. Archived from 
the original
 
(PDF)
 on 2011-10-01
. Retrieved 
2010-05-23
.




^
 
Lee Smolin
, 
Three Roads to Quantum Gravity
 (New York, N.Y.: 
Basic Books
, 2002), pp. 173 and 175, 
ISBN
 
0-465-07836-2
, 
LCCN
 
2007-310371
.




^
 
Bousso, Raphael (1999). "Holography in general space-times". 
Journal of High Energy Physics
. 
1999
 (6): 028. 
arXiv
:
hep-th/9906022
. 
Bibcode
:
1999JHEP...06..028B
. 
doi
:
10.1088/1126-6708/1999/06/028
. 
S2CID
 
119518763
.




^
 
Bousso, Raphael (1999). "A covariant entropy conjecture". 
Journal of High Energy Physics
. 
1999
 (7): 004. 
arXiv
:
hep-th/9905177
. 
Bibcode
:
1999JHEP...07..004B
. 
doi
:
10.1088/1126-6708/1999/07/004
. 
S2CID
 
9545752
.




^
 
Bousso, Raphael (2000). "The holographic principle for general backgrounds". 
Classical and Quantum Gravity
. 
17
 (5): 997–1005. 
arXiv
:
hep-th/9911002
. 
Bibcode
:
2000CQGra..17..997B
. 
doi
:
10.1088/0264-9381/17/5/309
. 
S2CID
 
14741276
.




^
 
Bekenstein, Jacob D. (2000). "Holographic bound from second law of thermodynamics". 
Physics Letters B
. 
481
 (2–4): 339–345. 
arXiv
:
hep-th/0003058
. 
Bibcode
:
2000PhLB..481..339B
. 
doi
:
10.1016/S0370-2693(00)00450-0
. 
S2CID
 
119427264
.




^
 
Bousso, Raphael (2002). 
"The holographic principle"
 
(PDF)
. 
Reviews of Modern Physics
. 
74
 (3): 825–874. 
arXiv
:
hep-th/0203101
. 
Bibcode
:
2002RvMP...74..825B
. 
doi
:
10.1103/RevModPhys.74.825
. 
S2CID
 
55096624
. Archived from 
the original
 
(PDF)
 on 2011-08-12
. Retrieved 
2010-05-23
.




^
 
Jacob D. Bekenstein, 
"Information in the Holographic Universe: Theoretical results about black holes suggest that the universe could be like a gigantic hologram"
, 
Scientific American
, Vol. 289, No. 2 (August 2003), pp. 58-65. 
Mirror link
.




^
 
Bousso, Raphael; Flanagan, Éanna É.; Marolf, Donald (2003). "Simple sufficient conditions for the generalized covariant entropy bound". 
Physical Review D
. 
68
 (6): 064001. 
arXiv
:
hep-th/0305149
. 
Bibcode
:
2003PhRvD..68f4001B
. 
doi
:
10.1103/PhysRevD.68.064001
. 
S2CID
 
119049155
.




^
 
Bekenstein, Jacob D. (2004). "Black holes and information theory". 
Contemporary Physics
. 
45
 (1): 31–43. 
arXiv
:
quant-ph/0311049
. 
Bibcode
:
2004ConPh..45...31B
. 
doi
:
10.1080/00107510310001632523
. 
S2CID
 
118970250
.




^
 
Tipler, F. J. (2005). 
"The structure of the world from pure numbers"
 
(PDF)
. 
Reports on Progress in Physics
. 
68
 (4): 897–964. 
arXiv
:
0704.3276
. 
Bibcode
:
2005RPPh...68..897T
. 
doi
:
10.1088/0034-4885/68/4/R04
. 
S2CID
 
119620977
.
. Tipler gives a number of arguments for maintaining that Bekenstein's original formulation of the bound is the correct form. See in particular the paragraph beginning with "A few points ..." on p. 903 of the 
Rep. Prog. Phys.
 paper (or p. 9 of the 
arXiv
 version), and the discussions on the Bekenstein bound that follow throughout the paper.




^
 
Casini, Horacio (2008). "Relative entropy and the Bekenstein bound". 
Classical and Quantum Gravity
. 
25
 (20): 205021. 
arXiv
:
0804.2182
. 
Bibcode
:
2008CQGra..25t5021C
. 
doi
:
10.1088/0264-9381/25/20/205021
. 
S2CID
 
14456556
.






External links
[
edit
]


Jacob D. Bekenstein, 
"Bekenstein-Hawking entropy"
, 
Scholarpedia
, Vol. 3, No. 10 (2008), p. 7375, 
doi
:
10.4249/scholarpedia.7375
.


Jacob D. Bekenstein's website
 at 
the Racah Institute of Physics
, 
Hebrew University of Jerusalem
, which contains a number of articles on the Bekenstein bound.


O'Dowd, Matt
 (September 12, 2018). 
"How Much Information is in the Universe?"
. 
PBS Space Time
. 
Archived
 from the original on 2021-12-12 – via 
YouTube
.


v
t
e
Black holes


Outline


Types


BTZ black hole


Schwarzschild


Rotating


Charged


Virtual


Kugelblitz


Supermassive


Primordial


Direct collapse


Rogue


Malament–Hogarth spacetime


Size


Micro


Extremal


Electron


Hawking star


Stellar


Microquasar


Intermediate-mass


Supermassive


Active galactic nucleus


Quasar


LQG


Blazar


OVV


Radio-Quiet


Radio-Loud


Formation


Stellar evolution


Gravitational collapse


Neutron star


Related links


Tolman–Oppenheimer–Volkoff limit


White dwarf


Related links


Supernova


Micronova


Hypernova


Related links


Gamma-ray burst


Binary black hole


Quark star


Supermassive star


Quasi-star


Supermassive dark star


X-ray binary


Properties


Astrophysical jet


Gravitational singularity


Ring singularity


Theorems


Event horizon


Photon sphere


Innermost stable circular orbit


Ergosphere


Penrose process


Blandford–Znajek process


Accretion disk


Hawking radiation


Gravitational lens


Microlens


Bondi accretion


M–sigma relation


Quasi-periodic oscillation


Thermodynamics


Bekenstein bound


Bousso's holographic bound


Immirzi parameter


Schwarzschild radius


Spaghettification


Issues


Black hole complementarity


Information paradox


Cosmic censorship


ER = EPR


Final parsec problem


Firewall (physics)


Holographic principle


No-hair theorem


Metrics


Schwarzschild
 (
Derivation
)


Kerr


Reissner–Nordström


Kerr–Newman


Hayward


Alternatives


Nonsingular black hole models


Black star


Dark star


Dark-energy star


Gravastar


Magnetospheric eternally collapsing object


Planck star


Q star


Fuzzball


Geon


Analogs


Optical black hole


Sonic black hole


Lists


Black holes


Most massive


Nearest


Quasars


Microquasars


Related


Outline of black holes


Black Hole Initiative


Black hole starship


Big Bang


Big Bounce


Compact star


Exotic star


Quark star


Preon star


Gravitational waves


Gamma-ray burst progenitors


Gravity well


Hypercompact stellar system


Membrane paradigm


Naked singularity


Population III star


Supermassive star


Quasi-star


Supermassive dark star


Rossi X-ray Timing Explorer


Superluminal motion


Timeline of black hole physics


White hole


Wormhole


Tidal disruption event


Planet Nine


Notable


Cygnus X-1


XTE J1650-500


XTE J1118+480


A0620-00


SDSS J150243.09+111557.3


Sagittarius A*


Centaurus A


Phoenix Cluster


PKS 1302-102


OJ 287


SDSS J0849+1114


TON 618


MS 0735.6+7421


NeVe 1


Hercules A


3C 273


Q0906+6930


Markarian 501


ULAS J1342+0928


PSO J030947.49+271757.31


P172+18


AT2018hyz


Swift J1644+57




 
Category


 
Commons




v
t
e
Quantum gravity
Central concepts


AdS/CFT correspondence


Ryu–Takayanagi conjecture


Causal patch


Gravitational anomaly


Graviton


Holographic principle


IR/UV mixing


Planck units


Quantum foam


Trans-Planckian problem


Weinberg–Witten theorem


Faddeev–Popov ghost


Batalin-Vilkovisky formalism


CA-duality


Toy models


2+1D topological gravity


CGHS model


Jackiw–Teitelboim gravity


Liouville gravity


RST model


Topological quantum field theory


Quantum field theory
in curved spacetime


Bunch–Davies vacuum


Hawking radiation


Semiclassical gravity


Unruh effect


Black holes


Black hole complementarity


Black hole information paradox


Black-hole thermodynamics


Bekenstein bound


Bousso's holographic bound


Cosmic censorship hypothesis


ER = EPR


Firewall (physics)


Gravitational singularity


Approaches
String theory


Bosonic string theory


M-theory


Supergravity


Superstring theory


Canonical quantum gravity


Loop quantum gravity


Wheeler–DeWitt equation


Euclidean quantum gravity


Hartle–Hawking state


Others


Causal dynamical triangulation


Causal sets


Noncommutative geometry


Spin foam


Group field theory


Superfluid vacuum theory


Twistor theory


Dual graviton


Applications


Quantum cosmology


Eternal inflation


Multiverse


FRW/CFT duality


See also:
 
 
Template:Quantum mechanics topics










Retrieved from "
https://en.wikipedia.org/w/index.php?title=Bekenstein_bound&oldid=1225312822
"


Categories
: 
Limits of computation
Thermodynamic entropy
Quantum information science
Black holes
Hidden categories: 
Articles with short description
Short description is different from Wikidata














 This page was last edited on 23 May 2024, at 17:14
 (UTC)
.


Text is available under the 
Creative Commons Attribution-ShareAlike License 4.0
;
additional terms may apply. By using this site, you agree to the 
Terms of Use
 and 
Privacy Policy
. Wikipedia® is a registered trademark of the 
Wikimedia Foundation, Inc.
, a non-profit organization.






Privacy policy


About Wikipedia


Disclaimers


Contact Wikipedia


Code of Conduct


Developers


Statistics


Cookie statement


Mobile view




























Toggle limited content width















