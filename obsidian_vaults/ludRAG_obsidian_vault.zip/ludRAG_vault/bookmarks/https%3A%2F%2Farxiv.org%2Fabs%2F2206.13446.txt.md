





 
[2206.13446] Pen and Paper Exercises in Machine Learning


























































 
 


















Skip to main content












We gratefully acknowledge support from the Simons Foundation, 
member institutions
, and all contributors. 
Donate












 
>
 
cs
 
>
 arXiv:2206.13446
  












Help
 | 
Advanced Search










All fields


Title


Author


Abstract


Comments


Journal reference


ACM classification


MSC classification


Report number


arXiv identifier


DOI


ORCID


arXiv author ID


Help pages


Full text










Search
































open search














GO








open navigation menu






quick links




Login


Help Pages


About


























Computer Science > Machine Learning






arXiv:2206.13446
 (cs)
    









  [Submitted on 27 Jun 2022]


Title:
Pen and Paper Exercises in Machine Learning


Authors:
Michael U. Gutmann
 
View a PDF of the paper titled Pen and Paper Exercises in Machine Learning, by Michael U. Gutmann


View PDF




Abstract:
This is a collection of (mostly) pen-and-paper exercises in machine learning. The exercises are on the following topics: linear algebra, optimisation, directed graphical models, undirected graphical models, expressive power of graphical models, factor graphs and message passing, inference for hidden Markov models, model-based learning (including ICA and unnormalised models), sampling and Monte-Carlo integration, and variational inference.
    






 


Comments:


The associated github page is 
this https URL






Subjects:




Machine Learning (cs.LG)
; Machine Learning (stat.ML)




Cite as:


arXiv:2206.13446
 [cs.LG]






 


(or 


arXiv:2206.13446v1
 [cs.LG]
 for this version)
          


 


 




https://doi.org/10.48550/arXiv.2206.13446








Focus to learn more









                arXiv-issued DOI via DataCite
              
















Submission history
 From: Michael Gutmann [
view email
]      
 
[v1]

        Mon, 27 Jun 2022 16:53:18 UTC (1,679 KB)








 




Full-text links:


Access Paper:





View a PDF of the paper titled Pen and Paper Exercises in Machine Learning, by Michael U. Gutmann
View PDF
TeX Source
Other Formats






view license






 

    Current browse context: 
cs.LG






< prev




  |  
 


next >






new


 | 


recent


 | 
2022-06



    Change to browse by:
    


cs


stat


stat.ML










References & Citations




NASA ADS
Google Scholar


Semantic Scholar










a


export BibTeX citation


Loading...










BibTeX formatted citation


×






loading...






Data provided by: 










Bookmark












 










Bibliographic Tools




Bibliographic and Citation Tools














Bibliographic Explorer Toggle








Bibliographic Explorer
 
(
What is the Explorer?
)
















Litmaps Toggle








Litmaps
 
(
What is Litmaps?
)
















scite.ai Toggle








scite Smart Citations
 
(
What are Smart Citations?
)


















Code, Data, Media




Code, Data and Media Associated with this Article














Links to Code Toggle








CatalyzeX Code Finder for Papers
 
(
What is CatalyzeX?
)
















DagsHub Toggle








DagsHub
 
(
What is DagsHub?
)
















GotitPub Toggle








Gotit.pub
 
(
What is GotitPub?
)
















Links to Code Toggle








Papers with Code
 
(
What is Papers with Code?
)
















ScienceCast Toggle








ScienceCast
 
(
What is ScienceCast?
)
























Demos




Demos














Replicate Toggle








Replicate
 
(
What is Replicate?
)
















Spaces Toggle








Hugging Face Spaces
 
(
What is Spaces?
)
















Spaces Toggle








TXYZ.AI
 
(
What is TXYZ.AI?
)


















Related Papers




Recommenders and Search Tools














Link to Influence Flower








Influence Flower
 
(
What are Influence Flowers?
)
















Connected Papers Toggle








Connected Papers
 
(
What is Connected Papers?
)
















Core recommender toggle








CORE Recommender
 
(
What is CORE?
)




 










IArxiv recommender toggle








IArxiv Recommender


(
What is IArxiv?
)














Author


Venue


Institution


Topic





























        About arXivLabs
      








arXivLabs: experimental projects with community collaborators


arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.


Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.


Have an idea for a project that will add value for arXiv's community? 
Learn more about arXivLabs
.






















Which authors of this paper are endorsers?
 |
    
Disable MathJax
 (
What is MathJax?
)
    


























About


Help












contact arXiv
Click here to contact arXiv


 Contact






subscribe to arXiv mailings
Click here to subscribe


 Subscribe
























Copyright


Privacy Policy










Web Accessibility Assistance






arXiv Operational Status 

                    Get status notifications via
                    
email

                    or 
slack












 













