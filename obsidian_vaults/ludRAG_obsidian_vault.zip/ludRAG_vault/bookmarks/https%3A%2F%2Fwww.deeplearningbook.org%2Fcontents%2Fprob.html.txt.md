









































Chapter
 
3
Probabilit
y
 
and
 
Information
Theory
In
 
this
 
c
hapter,
 
w
e
 
describ
e
 
probabilit
y
 
theory
 
and
 
information
 
theory
.
Probabilit
y
 
theory
 
is
 
a
 
mathematical
 
framew
ork
 
for
 
represen
ting
 
uncertain
statemen
ts.
 
It
 
pro
vides
 
a
 
means
 
of
 
quan
tifying
 
uncertaint
y
 
as
 
w
ell
 
as
 
axioms
 
for
deriving
 
new
 
uncertain
 
statemen
ts.
 
In
 
artiﬁcial
 
in
telligence
 
applications,
 
we
 
use
probabilit
y
 
theory
 
in
 
tw
o
 
ma
jor
 
w
a
ys.
 
First,
 
the
 
laws
 
of
 
probabilit
y
 
tell
 
us
 
how
 
AI
systems
 
should
 
reason,
 
so
 
we
 
design
 
our
 
algorithms
 
to
 
compute
 
or
 
approximate
v
arious
 
expressions
 
deriv
ed
 
using
 
probabilit
y
 
theory
.
 
Second,
 
w
e
 
can
 
use
 
probabilit
y
and
 
statistics
 
to
 
theoretically
 
analyze
 
the
 
b
eha
vior
 
of
 
prop
osed
 
AI
 
systems.
Probabilit
y
 
theory
 
is
 
a
 
fundamen
tal
 
to
ol
 
of
 
man
y
 
disciplines
 
of
 
science
 
and
engineering.
 
W
e
 
pro
vide
 
this
 
c
hapter
 
to
 
ensure
 
that
 
readers
 
whose
 
bac
kground
 
is
primarily
 
in
 
softw
are
 
engineering,
 
with
 
limited
 
exp
osure
 
to
 
probabilit
y
 
theory
,
 
can
understand
 
the
 
material
 
in
 
this
 
b
o
ok.
While
 
probabilit
y
 
theory
 
allows
 
us
 
to
 
make
 
uncertain
 
statements
 
and
 
to
 
reason
in
 
the
 
presence
 
of
 
uncertain
t
y
,
 
information
 
theory
 
enables
 
us
 
to
 
quantify
 
the
 
amoun
t
of
 
uncertain
t
y
 
in
 
a
 
probabilit
y
 
distribution.
If
 
y
ou
 
are
 
already
 
familiar
 
with
 
probability
 
theory
 
and
 
information
 
theory
,
y
ou
 
may
 
wish
 
to
 
skip
 
this
 
chapter
 
except
 
for
 
section
 
3.14
,
 
whic
h
 
describ
es
 
the
graphs
 
w
e
 
use
 
to
 
describ
e
 
structured
 
probabilistic
 
mo
dels
 
for
 
machine
 
learning.
 
If
y
ou
 
hav
e
 
absolutely
 
no
 
prior
 
exp
erience
 
with
 
these
 
sub
jects,
 
this
 
chapter
 
should
b
e
 
suﬃcient
 
to
 
successfully
 
carry
 
out
 
deep
 
learning
 
researc
h
 
pro
jects,
 
but
 
we
 
do
suggest
 
that
 
y
ou
 
consult
 
an
 
additional
 
resource,
 
suc
h
 
as
 
Ja
ynes
 
(
2003
).
51


CHAPTER
 
3.
 
PR
OBABILITY
 
AND
 
INF
ORMA
TION
 
THEOR
Y
3.1
 
Wh
y
 
Probabilit
y?
Man
y
 
branches
 
of
 
computer
 
science
 
deal
 
mostly
 
with
 
entities
 
that
 
are
 
en
tirely
deterministic
 
and
 
certain.
 
A
 
programmer
 
can
 
usually
 
safely
 
assume
 
that
 
a
 
CPU
 
will
execute
 
eac
h
 
mac
hine
 
instruction
 
ﬂawlessly
.
 
Errors
 
in
 
hardware
 
do
 
o
ccur
 
but
 
are
rare
 
enough
 
that
 
most
 
soft
w
are
 
applications
 
do
 
not
 
need
 
to
 
b
e
 
designed
 
to
 
accoun
t
for
 
them.
 
Giv
en
 
that
 
many
 
computer
 
scien
tists
 
and
 
soft
w
are
 
engineers
 
work
 
in
 
a
relativ
ely
 
clean
 
and
 
certain
 
environmen
t,
 
it
 
can
 
b
e
 
surprising
 
that
 
mac
hine
 
learning
mak
es
 
hea
vy
 
use
 
of
 
probabilit
y
 
theory
.
Mac
hine
 
learning
 
must
 
alwa
ys
 
deal
 
with
 
uncertain
 
quan
tities
 
and
 
sometimes
sto
c
hastic
 
(nondeterministic)
 
quantities.
 
Uncertaint
y
 
and
 
sto
chasticit
y
 
can
 
arise
from
 
man
y
 
sources.
 
Researchers
 
hav
e
 
made
 
compelling
 
arguments
 
for
 
quantifying
uncertain
t
y
 
using
 
probability
 
since
 
at
 
least
 
the
 
1980s.
 
Man
y
 
of
 
the
 
argumen
ts
presen
ted
 
here
 
are
 
summarized
 
from
 
or
 
inspired
 
b
y
 
P
earl
 
(
1988
).
Nearly
 
all
 
activities
 
require
 
some
 
abilit
y
 
to
 
reason
 
in
 
the
 
presence
 
of
 
uncertaint
y
.
In
 
fact,
 
b
eyond
 
mathematical
 
statements
 
that
 
are
 
true
 
by
 
deﬁnition,
 
it
 
is
 
diﬃcult
to
 
think
 
of
 
any
 
prop
osition
 
that
 
is
 
absolutely
 
true
 
or
 
any
 
even
t
 
that
 
is
 
absolutely
guaran
teed
 
to
 
o
ccur.
There
 
are
 
three
 
p
ossible
 
sources
 
of
 
uncertain
t
y:
1.
Inheren
t
 
sto
c
hasticit
y
 
in
 
the
 
system
 
b
eing
 
mo
deled.
 
F
or
 
example, most
in
terpretations
 
of
 
quantum
 
mechanics
 
describ
e
 
the
 
dynamics
 
of
 
subatomic
particles
 
as
 
b
eing
 
probabilistic.
 
W
e
 
can
 
also
 
create
 
theoretical
 
scenarios
 
that
w
e
 
p
ostulate
 
to
 
ha
v
e
 
random
 
dynamics,
 
such
 
as
 
a
 
hypothetical
 
card
 
game
where
 
w
e
 
assume
 
that
 
the
 
cards
 
are
 
truly
 
sh
uﬄed
 
in
to
 
a
 
random
 
order.
2.
Incomplete
 
observ
abilit
y
.
 
Even
 
deterministic
 
systems
 
can
 
app
ear
 
sto
chastic
when
 
w
e
 
cannot
 
observe
 
all
 
the
 
v
ariables
 
that
 
drive
 
the
 
b
ehavior
 
of
 
the
system.
 
F
or
 
example,
 
in
 
the
 
Mont
y
 
Hall
 
problem,
 
a
 
game
 
show
 
con
testan
t
 
is
ask
ed
 
to
 
choose
 
b
etw
een
 
three
 
do
ors
 
and
 
wins
 
a
 
prize
 
held
 
b
ehind
 
the
 
chosen
do
or.
 
T
w
o
 
do
ors
 
lead
 
to
 
a
 
goat
 
while
 
a
 
third
 
leads
 
to
 
a
 
car. The
 
outcome
giv
en
 
the
 
contestan
t’s
 
choice
 
is
 
deterministic,
 
but
 
from
 
the
 
con
testan
t’s
 
p
oin
t
of
 
view,
 
the
 
outcome
 
is
 
uncertain.
3.
Incomplete
 
mo
deling.
 
When
 
we
 
use
 
a
 
mo
del
 
that
 
must
 
discard
 
some
 
of
the information
 
we
 
ha
v
e observ
ed, the discarded
 
information
 
results in
uncertain
t
y
 
in
 
the
 
mo
del’s
 
predictions.
 
F
or
 
example,
 
supp
ose
 
we
 
build
 
a
rob
ot
 
that
 
can
 
exactly
 
observe
 
the
 
lo
cation
 
of
 
every
 
ob
ject
 
around
 
it.
 
If
 
the
rob
ot
 
discretizes
 
space
 
when
 
predicting
 
the
 
future
 
lo
cation
 
of
 
these
 
ob
jects,
52


CHAPTER
 
3.
 
PR
OBABILITY
 
AND
 
INF
ORMA
TION
 
THEOR
Y
then
 
the
 
discretization
 
mak
es
 
the
 
rob
ot
 
immediately
 
b
ecome
 
uncertain
 
ab
out
the
 
precise
 
p
osition
 
of
 
ob
jects:
 
eac
h
 
ob
ject
 
could
 
b
e
 
anywhere
 
within
 
the
discrete
 
cell
 
that
 
it
 
w
as
 
observ
ed
 
to
 
o
ccup
y
.
In
 
man
y
 
cases,
 
it
 
is
 
more
 
practical
 
to
 
use
 
a
 
simple
 
but
 
uncertain
 
rule
 
rather
than
 
a
 
complex
 
but
 
certain
 
one,
 
ev
en
 
if
 
the
 
true
 
rule
 
is
 
deterministic
 
and
 
our
mo
deling
 
system
 
has
 
the
 
ﬁdelit
y
 
to
 
accommo
date
 
a
 
complex
 
rule.
 
F
or
 
example,
 
the
simple
 
rule
 
“Most
 
birds
 
ﬂy”
 
is
 
c
heap
 
to
 
develop
 
and
 
is
 
broadly
 
useful,
 
while
 
a
 
rule
of
 
the
 
form,
 
“Birds
 
ﬂy
,
 
except
 
for
 
v
ery
 
young
 
birds
 
that
 
hav
e
 
not
 
yet
 
learned
 
to
ﬂy
,
 
sick
 
or
 
injured
 
birds
 
that
 
hav
e
 
lost
 
the
 
abilit
y
 
to
 
ﬂy
,
 
ﬂightless
 
sp
ecies
 
of
 
birds
including
 
the
 
casso
wary
,
 
ostrich
 
and
 
kiwi.
 
.
 
.
”
 
is
 
exp
ensive
 
to
 
dev
elop,
 
maintain
and
 
comm
unicate
 
and,
 
after
 
all
 
this
 
eﬀort,
 
is
 
still
 
brittle
 
and
 
prone
 
to
 
failure.
While
 
it
 
should
 
b
e
 
clear
 
that
 
we
 
need
 
a
 
means
 
of
 
representing
 
and
 
reasoning
ab
out
 
uncertaint
y
,
 
it
 
is
 
not
 
immediately
 
obvious
 
that
 
probability
 
theory
 
can
 
provide
all
 
the
 
to
ols
 
we
 
w
an
t
 
for
 
artiﬁcial
 
intelligence
 
applications.
 
Probability
 
theory
w
as
 
originally
 
dev
elop
ed
 
to
 
analyze
 
the
 
frequencies
 
of
 
even
ts.
 
It
 
is
 
easy
 
to
 
see
ho
w
 
probabilit
y
 
theory
 
can
 
be
 
used
 
to
 
study
 
even
ts
 
like
 
drawing
 
a
 
certain
 
hand
 
of
cards
 
in
 
a
 
p
oker
 
game.
 
These
 
kinds
 
of
 
ev
en
ts
 
are
 
often
 
rep
eatable.
 
When
 
we
 
say
that
 
an
 
outcome
 
has
 
a
 
probability
p
of
 
o
ccurring,
 
it
 
means
 
that
 
if
 
w
e
 
rep
eated
 
the
exp
erimen
t
 
(e.g.,
 
drawing
 
a
 
hand
 
of
 
cards)
 
inﬁnitely
 
many
 
times,
 
then
 
a
 
prop
ortion
p
of
 
the
 
rep
etitions
 
would
 
result
 
in
 
that
 
outcome.
 
This
 
kind
 
of
 
reasoning
 
do
es
 
not
seem
 
immediately
 
applicable
 
to
 
prop
ositions
 
that
 
are
 
not
 
rep
eatable.
 
If
 
a
 
do
ctor
analyzes
 
a
 
patient
 
and
 
sa
ys
 
that
 
the
 
patien
t
 
has
 
a
 
40
 
p
ercent
 
chance
 
of
 
ha
ving
the
 
ﬂu,
 
this
 
means
 
something
 
v
ery
 
diﬀerent—w
e
 
cannot
 
make
 
inﬁnitely
 
man
y
replicas
 
of
 
the
 
patient,
 
nor
 
is
 
there
 
any
 
reason
 
to
 
b
elieve
 
that
 
diﬀerent
 
replicas
 
of
the
 
patient
 
would
 
presen
t
 
with
 
the
 
same
 
symptoms
 
y
et
 
hav
e
 
v
arying
 
underlying
conditions. In
 
the
 
case
 
of
 
the
 
doctor
 
diagnosing
 
the
 
patien
t,
 
we
 
use
 
probabilit
y
to
 
represent
 
a
degree
 
of
 
b
elief
,
 
with
 
1
 
indicating
 
absolute
 
certaint
y
 
that
 
the
patien
t
 
has
 
the
 
ﬂu
 
and
 
0
 
indicating
 
absolute
 
certaint
y
 
that
 
the
 
patient
 
do
es
 
not
ha
v
e
 
the
 
ﬂu.
 
The
 
former
 
kind
 
of
 
probability
,
 
related
 
directly
 
to
 
the
 
rates
 
at
 
which
ev
en
ts
 
o
ccur,
 
is
 
kno
wn
 
as
frequen
tist
 
probability
,
 
while
 
the
 
latter,
 
related
 
to
qualitativ
e
 
lev
els
 
of
 
certain
ty
,
 
is
 
kno
wn
 
as
 
Ba
y
esian
 
probabilit
y
.
If
 
w
e
 
list
 
several
 
prop
erties
 
that
 
we
 
exp
ect
 
common
 
sense
 
reasoning
 
ab
out
uncertain
t
y
 
to
 
hav
e, then
 
the
 
only
 
w
a
y
 
to
 
satisfy
 
those
 
prop
erties
 
is
 
to
 
treat
Ba
y
esian
 
probabilities
 
as
 
b
ehaving
 
exactly
 
the
 
same
 
as
 
frequentist
 
probabilities.
F
or
 
example,
 
if
 
we
 
w
an
t
 
to
 
compute
 
the
 
probability
 
that
 
a
 
play
er
 
will
 
win
 
a
 
p
oker
game
 
given
 
that
 
she
 
has
 
a
 
certain
 
set
 
of
 
cards,
 
w
e
 
use
 
exactly
 
the
 
same
 
formulas
as
 
when
 
w
e
 
compute
 
the
 
probability
 
that
 
a
 
patient
 
has
 
a
 
disease
 
given
 
that
 
she
has
 
certain
 
symptoms.
 
F
or
 
more
 
details
 
ab
out
 
wh
y
 
a
 
small
 
set
 
of
 
common
 
sense
53


CHAPTER
 
3.
 
PR
OBABILITY
 
AND
 
INF
ORMA
TION
 
THEOR
Y
assumptions
 
implies
 
that
 
the
 
same
 
axioms
 
must
 
control
 
b
oth
 
kinds
 
of
 
probability
,
see
 
Ramsey
 
(
1926
).
Probabilit
y
 
can
 
b
e
 
seen
 
as
 
the
 
extension
 
of
 
logic
 
to
 
deal
 
with
 
uncertaint
y
.
 
Logic
pro
vides
 
a
 
set
 
of
 
formal
 
rules
 
for
 
determining
 
what
 
prop
ositions
 
are
 
implied
 
to
b
e
 
true
 
or
 
false
 
giv
en
 
the
 
assumption
 
that
 
some
 
other
 
set
 
of
 
prop
ositions
 
is
 
true
or
 
false.
 
Probabilit
y
 
theory
 
provides
 
a
 
set
 
of
 
formal
 
rules
 
for
 
determining
 
the
lik
eliho
o
d
 
of
 
a
 
proposition
 
b
eing
 
true
 
given
 
the
 
likelihoo
d
 
of
 
other
 
prop
ositions.
3.2
 
Random
 
V
ariables
A
random
 
v
ariable
is
 
a
 
v
ariable
 
that
 
can
 
take
 
on
 
diﬀeren
t
 
v
alues
 
randomly
.
 
W
e
t
ypically
 
denote
 
the
 
random
 
v
ariable
 
itself
 
with
 
a
 
lo
w
ercase
 
letter
 
in
 
plain
 
t
yp
eface,
and
 
the
 
v
alues
 
it
 
can
 
tak
e
 
on
 
with
 
low
ercase
 
script
 
letters.
 
F
or
 
example,
x
1
and
x
2
are
 
b
oth
 
p
ossible
 
v
alues
 
that
 
the
 
random
 
v
ariable
x
can
 
take
 
on.
 
F
or
 
vector-v
alued
v
ariables,
 
we
 
would
 
write
 
the
 
random
 
v
ariable
 
as
x
and
 
one
 
of
 
its
 
v
alues
 
as
x
.
 
On
its
 
own,
 
a
 
random
 
v
ariable
 
is
 
just
 
a
 
description
 
of
 
the
 
states
 
that
 
are
 
p
ossible;
 
it
m
ust
 
b
e
 
coupled
 
with
 
a
 
probabilit
y
 
distribution
 
that
 
sp
eciﬁes
 
how
 
lik
ely
 
eac
h
 
of
these
 
states
 
are.
Random
 
v
ariables
 
may
 
b
e
 
discrete
 
or
 
contin
uous.
 
A
 
discrete
 
random
 
v
ariable
is
 
one
 
that
 
has
 
a
 
ﬁnite
 
or
 
countably
 
inﬁnite
 
num
ber
 
of
 
states.
 
Note
 
that
 
these
states
 
are
 
not
 
necessarily
 
the
 
integers;
 
they
 
can
 
also
 
just
 
b
e
 
named
 
states
 
that
are
 
not
 
considered
 
to
 
hav
e
 
any
 
numerical
 
v
alue.
 
A
 
contin
uous
 
random
 
v
ariable
 
is
asso
ciated
 
with
 
a
 
real
 
v
alue.
3.3
 
Probabilit
y
 
Distributions
A
probabilit
y
 
distribution
is
 
a
 
description
 
of
 
ho
w
 
likely
 
a
 
random
 
v
ariable
 
or
set
 
of
 
random
 
v
ariables
 
is
 
to
 
take
 
on
 
each
 
of
 
its
 
p
ossible
 
states.
 
The
 
wa
y
 
we
describ
e
 
probability
 
distributions
 
dep
ends
 
on
 
whether
 
the
 
v
ariables
 
are
 
discrete
 
or
con
tin
uous.
3.3.1
 
Discrete
 
V
ariables
 
and
 
Probabilit
y
 
Mass
 
F
unctions
A
 
probability
 
distribution
 
ov
er
 
discrete
 
v
ariables
 
may
 
b
e
 
describ
ed
 
using
 
a
proba-
bilit
y
 
mass
 
function
(PMF).
 
W
e
 
typically
 
denote
 
probability
 
mass
 
functions
 
with
a
 
capital
P
.
 
Often
 
we
 
asso
ciate
 
each
 
random
 
v
ariable
 
with
 
a
 
diﬀerent
 
probability
mass
 
function
 
and
 
the
 
reader
 
must
 
infer
 
which
 
PMF
 
to
 
use
 
based
 
on
 
the
 
identit
y
54


CHAPTER
 
3.
 
PR
OBABILITY
 
AND
 
INF
ORMA
TION
 
THEOR
Y
of
 
the
 
random
 
v
ariable,
 
rather
 
than
 
on
 
the
 
name
 
of
 
the
 
function;
P
(
x
)
 
is
 
usually
not
 
the
 
same
 
as
 
P
 
(
y
)
.
The
 
probabilit
y
 
mass
 
function
 
maps
 
from
 
a
 
state
 
of
 
a
 
random
 
v
ariable
 
to
the
 
probabilit
y
 
of
 
that
 
random
 
v
ariable
 
taking
 
on
 
that
 
state.
 
The
 
probability
that
x
=
x
is
 
denoted
 
as
P
(
x
)
,
 
with
 
a
 
probability
 
of
 
1
 
indicating
 
that
x
=
x
is
certain
 
and
 
a
 
probability
 
of
 
0
 
indicating
 
that
x
=
x
is
 
imp
ossible.
 
Sometimes
to
 
disam
biguate
 
which
 
PMF
 
to
 
use,
 
w
e
 
write
 
the
 
name
 
of
 
the
 
random
 
v
ariable
explicitly:
P
(
x
=
x
)
.
 
Sometimes
 
we
 
deﬁne
 
a
 
v
ariable
 
ﬁrst,
 
then
 
use
∼
notation
 
to
sp
ecify
 
whic
h
 
distribution
 
it
 
follo
ws
 
later:
 
x
 
∼
 
P
 
(
x
)
.
Probabilit
y
 
mass
 
functions
 
can
 
act
 
on
 
many
 
v
ariables
 
at
 
the
 
same
 
time.
 
Such
a
 
probability
 
distribution
 
o
v
er
 
man
y
 
v
ariables
 
is
 
known
 
as
 
a
join
t
 
probabilit
y
distribution
.
P
(
x
=
x,
 
y
=
y
)
 
denotes
 
the
 
probabilit
y
 
that
x
=
x
and
y
=
y
sim
ultaneously
.
 
W
e
 
may
 
also
 
write
 
P
 
(
x,
 
y
)
 
for
 
brevity
.
T
o
 
b
e
 
a
 
PMF
 
on
 
a
 
random
 
v
ariable
x
,
 
a
 
function
P
m
ust
 
satisfy
 
the
 
following
prop
erties:
•
 
The
 
domain
 
of
 
P
 
m
ust
 
b
e
 
the
 
set
 
of
 
all
 
p
ossible
 
states
 
of
 
x.
•
 
∀
x
 
∈
 
x
,
0
≤
 
P
(
x
)
≤
1
.
An
 
imp
ossible
 
even
t
 
has
 
probability
 
0
,
 
and
 
no
 
state
can
 
b
e
 
less
 
probable
 
than
 
that.
 
Lik
ewise,
 
an
 
even
t
 
that
 
is
 
guaranteed
 
to
happ
en
 
has
 
probabilit
y
 
1
,
 
and
 
no
 
state
 
can
 
ha
v
e
 
a
 
greater
 
c
hance
 
of
 
o
ccurring.
•

x
∈
x
P
(
x
) = 1
.
 
W
e
 
refer
 
to
 
this
 
prop
erty
 
as
 
b
eing
normalized
.
 
Without
this
 
prop
erty
,
 
we
 
could
 
obtain
 
probabilities
 
greater
 
than
 
one
 
by
 
computing
the
 
probabilit
y
 
of
 
one
 
of
 
man
y
 
ev
en
ts
 
o
ccurring.
F
or
 
example,
 
consider
 
a
 
single
 
discrete
 
random
 
v
ariable
x
with
k
diﬀeren
t
states.
 
W
e
 
can
 
place
 
a
uniform
 
distribution
on
x
—that
 
is,
 
make
 
eac
h
 
of
 
its
states
 
equally
 
lik
ely—b
y
 
setting
 
its
 
PMF
 
to
P
 
(
x
 
= 
x
i
) =
1
k
(3.1)
for
 
all
i
.
 
W
e
 
can
 
see
 
that
 
this
 
ﬁts
 
the
 
requirements
 
for
 
a
 
probability
 
mass
 
function.
The
 
v
alue
1
k
is
 
p
ositiv
e
 
b
ecause
 
k
 
is
 
a
 
p
ositive
 
integer.
 
W
e
 
also
 
see
 
that

i
P
 
(
x
 
= 
x
i
) =

i
1
k
=
k
k
= 1
,
 
(3.2)
so
 
the
 
distribution
 
is
 
prop
erly
 
normalized.
55


CHAPTER
 
3.
 
PR
OBABILITY
 
AND
 
INF
ORMA
TION
 
THEOR
Y
3.3.2
 
Con
tin
uous
 
V
ariables
 
and
 
Probability
 
Densi
t
y
 
F
unctions
When
 
working
 
with
 
contin
uous
 
random
 
v
ariables,
 
we
 
describ
e
 
probabilit
y
 
distri-
butions
 
using
 
a
 
probabilit
y
 
densit
y
 
function
 
(PDF)
 
rather
 
than
 
a
 
probability
mass
 
function.
 
T
o
 
b
e
 
a
 
probability
 
density
 
function,
 
a
 
function
p
m
ust
 
satisfy
 
the
follo
wing
 
prop
erties:
•
 
The
 
domain
 
of
 
p
 
m
ust
 
b
e
 
the
 
set
 
of
 
all
 
p
ossible
 
states
 
of
 
x.
•
 
∀
x
 
∈
 
x
,
 
p
(
x
) 
≥
 
0
.
 
Note
 
that
 
we
 
do
 
not
 
require
 
p
(
x
) 
≤
 
1
.
•

p
(
x
)
dx
 
= 1
.
A
 
probability
 
density
 
function
p
(
x
)
 
do
es
 
not
 
give
 
the
 
probability
 
of
 
a
 
sp
eciﬁc
state
 
directly;
 
instead
 
the
 
probability
 
of
 
landing
 
inside
 
an
 
inﬁnitesimal
 
region
 
with
v
olume
 
δ
x
 
is
 
given
 
by
 
p
(
x
)
δ
x
.
W
e
 
can
 
integrate
 
the
 
density
 
function
 
to
 
ﬁnd
 
the
 
actual
 
probability
 
mass
 
of
 
a
set
 
of
 
p
oints.
 
Speciﬁcally
,
 
the
 
probabilit
y
 
that
x
lies
 
in
 
some
 
set
S
is
 
giv
en
 
by
 
the
in
tegral
 
of
p
(
x
)
 
ov
er
 
that
 
set. In
 
the
 
univ
ariate
 
example,
 
the
 
probabilit
y
 
that
x
lies
 
in
 
the
 
in
terv
al
 
[
a,
 
b
]
 
is
 
given
 
by

[
a,b
]
p
(
x
)
dx
.
F
or
 
an
 
example
 
of
 
a
 
PDF
 
corresp
onding
 
to
 
a
 
sp
eciﬁc
 
probability
 
density
 
o
v
er
a
 
contin
uous
 
random
 
v
ariable,
 
consider
 
a
 
uniform
 
distribution
 
on
 
an
 
in
terv
al
 
of
the
 
real
 
num
b
ers.
 
W
e
 
can
 
do
 
this
 
with
 
a
 
function
u
(
x
;
a,
 
b
)
,
 
where
a
and
b
are
 
the
endp
oin
ts
 
of
 
the
 
interv
al,
 
with
b
 
>
 
a
.
 
The
 
“;”
 
notation
 
means
 
“parametrized
 
by”;
w
e
 
consider
x
to
 
b
e
 
the
 
argumen
t
 
of
 
the
 
function,
 
while
a
and
b
are
 
parameters
that
 
deﬁne
 
the
 
function.
 
T
o
 
ensure
 
that
 
there
 
is
 
no
 
probability
 
mass
 
outside
 
the
in
terv
al,
 
we
 
sa
y
u
(
x
;
a,
 
b
) = 0
 
for
 
all
x
 
∈
[
a,
 
b
]
.
 
Within
 
[
a,
 
b
]
,
u
(
x
;
a,
 
b
) =
1
b
−
a
.
 
W
e
can
 
see
 
that
 
this
 
is
 
non-negative
 
everywhere.
 
A
dditionally
,
 
it
 
in
tegrates
 
to
 
1.
 
W
e
often
 
denote
 
that
x
follo
ws
 
the
 
uniform
 
distribution
 
on
 
[
a,
 
b
] 
by
 
writing
x
 
∼
 
U
(
a,
 
b
)
.
3.4
 
Marginal
 
Probabilit
y
Sometimes
 
we
 
kno
w
 
the
 
probability
 
distribution
 
ov
er
 
a
 
set
 
of
 
v
ariables
 
and
 
we
 
w
an
t
to
 
know
 
the
 
probabilit
y
 
distribution
 
ov
er
 
just
 
a
 
subset
 
of
 
them.
 
The
 
probabilit
y
distribution
 
ov
er
 
the
 
subset
 
is
 
known
 
as
 
the
marginal
 
probabilit
y
 
distribution.
F
or
 
example,
 
supp
ose
 
we
 
hav
e
 
discrete
 
random
 
v
ariables
x
and
y
,
 
and
 
we
 
know
P
 
(
x
,
 
y
)
.
 
W
e
 
can
 
ﬁnd
 
P
 
(
x
)
 
with
 
the
 
sum
 
rule
:
∀
x
 
∈
 
x
,
 
P
 
(
x
 
= 
x
) =

y
P
 
(
x
 
= 
x,
 
y
 
= 
y
)
.
 
(3.3)
56


CHAPTER
 
3.
 
PR
OBABILITY
 
AND
 
INF
ORMA
TION
 
THEOR
Y
The
 
name
 
“marginal
 
probabilit
y”
 
comes
 
from
 
the
 
pro
cess
 
of
 
computing
 
marginal
probabilities
 
on
 
pap
er.
 
When
 
the
 
v
alues
 
of
P
(
x
,
 
y
)
 
are
 
written
 
in
 
a
 
grid
 
with
diﬀeren
t
 
v
alues
 
of
x
in
 
rows
 
and
 
diﬀeren
t
 
v
alues
 
of
y
in
 
columns,
 
it
 
is
 
natural
 
to
sum
 
across
 
a
 
row
 
of
 
the
 
grid,
 
then
 
write
P
(
x
)
 
in
 
the
 
margin
 
of
 
the
 
pap
er
 
just
 
to
the
 
righ
t
 
of
 
the
 
ro
w.
F
or
 
contin
uous
 
v
ariables,
 
we
 
need
 
to
 
use
 
integration
 
instead
 
of
 
summation:
p
(
x
) =

p
(
x,
 
y
)
dy
.
 
(3.4)
3.5
 
Conditional
 
Probabilit
y
In
 
many
 
cases,
 
we
 
are
 
in
terested
 
in
 
the
 
probabilit
y
 
of
 
some
 
ev
ent,
 
given
 
that
 
some
other
 
ev
en
t
 
has
 
happ
ened.
 
This
 
is
 
called
 
a
conditional
 
probabilit
y
.
 
W
e
 
denote
the
 
conditional
 
probability
 
that
y
=
y
giv
en
x
=
x
as
P
(
y
=
y
 
|
 
x
=
x
)
.
 
This
conditional
 
probabilit
y
 
can
 
b
e
 
computed
 
with
 
the
 
form
ula
P
 
(
y
 
= 
y
 
|
 
x
 
= 
x
) =
P
 
(
y
 
= 
y
,
 
x
 
= 
x
)
P
 
(
x
 
= 
x
)
.
 
(3.5)
The
 
conditional
 
probabilit
y
 
is
 
only
 
deﬁned
 
when
P
(
x
=
x
)
>
0
.
W
e
 
cannot
 
compute
the
 
conditional
 
probabilit
y
 
conditioned
 
on
 
an
 
ev
en
t
 
that
 
nev
er
 
happ
ens.
It
 
is
 
imp
ortan
t
 
not
 
to
 
confuse
 
conditional
 
probabilit
y
 
with
 
computing
 
what
w
ould
 
happ
en
 
if
 
some
 
action
 
were
 
undertak
en.
 
The
 
conditional
 
probabilit
y
 
that
a
 
p
erson
 
is
 
from
 
Germany
 
given
 
that
 
they
 
sp
eak
 
German
 
is
 
quite
 
high,
 
but
 
if
a
 
randomly
 
selected
 
p
erson
 
is
 
taugh
t
 
to
 
speak
 
German,
 
their
 
country
 
of
 
origin
do
es
 
not
 
change.
 
Computing
 
the
 
consequences
 
of
 
an
 
action
 
is
 
called
 
making
 
an
in
terv
en
tion
 
query
.
 
In
terv
en
tion
 
queries
 
are
 
the
 
domain
 
of
causal
 
mo
deling
,
whic
h
 
w
e
 
do
 
not
 
explore
 
in
 
this
 
b
o
ok.
3.6
 
The
 
Chain
 
Rule
 
of
 
Conditional
 
Probabilities
An
y
 
joint
 
probability
 
distribution
 
ov
er
 
many
 
random
 
v
ariables
 
may
 
b
e
 
decomp
osed
in
to
 
conditional
 
distributions
 
o
v
er
 
only
 
one
 
v
ariable:
P
 
(
x
(1)
,
 
.
 
.
 
.
 
,
 
x
(
n
)
) = 
P
 
(
x
(1)
)Π
n
i
=2
P
 
(
x
(
i
)
|
 
x
(1)
,
 
.
 
.
 
.
 
,
 
x
(
i
−
1)
)
.
 
(3.6)
This
 
observ
ation
 
is
 
known
 
as
 
the
c
hain
 
rule
,
 
or
pro
duct
 
rule
,
 
of
 
probability
.
It
 
follows
 
immediately
 
from
 
the
 
deﬁnition
 
of
 
conditional
 
probabilit
y
 
in
 
equation
 
3.5
.
57


CHAPTER
 
3.
 
PR
OBABILITY
 
AND
 
INF
ORMA
TION
 
THEOR
Y
F
or
 
example,
 
applying
 
the
 
deﬁnition
 
twice,
 
we
 
get
P
 
(
a
,
 
b
,
 
c
)
 
=
 
P
 
(
a
 
|
 
b
,
 
c
)
P
 
(
b
,
 
c
)
P
 
(
b
,
 
c
)
 
=
 
P
 
(
b
 
|
 
c
)
P
 
(
c
)
P
 
(
a
,
 
b
,
 
c
)
 
=
 
P
 
(
a
 
|
 
b
,
 
c
)
P
 
(
b
 
|
 
c
)
P
 
(
c
)
.
3.7
 
Indep
endence
 
and
 
Conditional
 
Indep
endence
T
wo
 
random
 
v
ariables
x
and
y
are
indep
enden
t
if
 
their
 
probability
 
distribution
can
 
b
e
 
expressed
 
as
 
a
 
product
 
of
 
tw
o
 
factors,
 
one
 
in
v
olving
 
only
x
and
 
one
 
in
v
olving
only
 
y:
∀
x
 
∈
 
x
,
 
y
 
∈
 
y
,
 
p
(
x
 
= 
x,
 
y
 
= 
y
) = 
p
(
x
 
= 
x
)
p
(
y
 
= 
y
)
.
 
(3.7)
T
wo
 
random
 
v
ariables
x
and
y
are
conditionally
 
indep
endent
giv
en
 
a
 
random
v
ariable
z
if
 
the
 
conditional
 
probability
 
distribution
 
o
ver
x
and
y
factorizes
 
in
 
this
w
a
y
 
for
 
ev
ery
 
v
alue
 
of
 
z:
∀
x
 
∈
 
x
,
 
y
 
∈
 
y
,
 
z
 
∈
 
z
,
 
p
(
x
 
= 
x,
 
y
 
= 
y
 
|
 
z
 
= 
z
) = 
p
(
x
 
= 
x
 
|
 
z
 
= 
z
)
p
(
y
 
= 
y
 
|
 
z
 
= 
z
)
.
(3.8)
W
e
 
can
 
denote independence
 
and
 
conditional independence
 
with
 
compact
notation:
x
⊥
y
means
 
that
x
and
y
are
 
indep
enden
t,
 
while
x
⊥
y
 
|
 
z
means
 
that
x
and
 
y
 
are
 
conditionally
 
indep
enden
t
 
giv
en
 
z.
3.8
 
Exp
ectation,
 
V
ariance
 
and
 
Co
v
ariance
The
exp
ectation
,
 
or
exp
ected
 
v
alue
,
 
of
 
some
 
function
f
(
x
)
 
with
 
resp
ect
 
to
 
a
probabilit
y
 
distribution
P
(
x
)
 
is
 
the
 
av
erage,
 
or
 
mean
 
v
alue,
 
that
f
tak
es
 
on
 
when
x
is
 
drawn
 
from
P
.
 
F
or
 
discrete
 
v
ariables
 
this
 
can
 
b
e
 
computed
 
with
 
a
 
summation:
E
x
∼
P
[
f
(
x
)] =

x
P
 
(
x
)
f
(
x
)
,
 
(3.9)
while
 
for
 
con
tin
uous
 
v
ariables,
 
it
 
is
 
computed
 
with
 
an
 
integral:
E
x
∼
p
[
f
(
x
)] =

p
(
x
)
f
(
x
)
dx.
 
(3.10)
58


CHAPTER
 
3.
 
PR
OBABILITY
 
AND
 
INF
ORMA
TION
 
THEOR
Y
When
 
the
 
identit
y
 
of
 
the
 
distribution
 
is
 
clear
 
from
 
the
 
conte
xt,
 
w
e
 
ma
y
 
simply
write
 
the
 
name
 
of
 
the
 
random
 
v
ariable
 
that
 
the
 
exp
ectation
 
is
 
o
ver,
 
as
 
in
E
x
[
f
(
x
)]
.
If
 
it
 
is
 
clear
 
whic
h
 
random
 
v
ariable
 
the
 
exp
ectation
 
is
 
ov
er,
 
we
 
may
 
omit
 
the
subscript
 
entirely
,
 
as
 
in
E
[
f
(
x
)]
.
 
By
 
default,
 
we
 
can
 
assume
 
that
E
[
·
]
 
av
erages
 
ov
er
the
 
v
alues
 
of
 
all
 
the
 
random
 
v
ariables
 
inside
 
the
 
brack
ets.
 
Lik
ewise,
 
when
 
there
 
is
no
 
am
biguit
y
,
 
we
 
ma
y
 
omit
 
the
 
square
 
brac
k
ets.
Exp
ectations
 
are
 
linear,
 
for
 
example,
E
x
[
αf
(
x
)
 
+
 
β
g
(
x
)] = 
α
E
x
[
f
(
x
)]
 
+
 
β
E
x
[
g
(
x
)]
,
 
(3.11)
when
 
α
 
and
 
β
 
are
 
not
 
dep
endent
 
on
 
x
.
The
v
ariance
giv
es
 
a
 
measure
 
of
 
ho
w
 
muc
h
 
the
 
v
alues
 
of
 
a
 
function
 
of
 
a
 
random
v
ariable
x
v
ary
 
as
 
we
 
sample
 
diﬀeren
t
 
v
alues
 
of
x
from
 
its
 
probability
 
distribution:
V
ar(
f
(
x
)) = 
E

(
f
(
x
)
 
−
 
E
[
f
(
x
)])
2

.
 
(3.12)
When
 
the
 
v
ariance
 
is
 
low,
 
the
 
v
alues
 
of
f
(
x
)
 
cluster
 
near
 
their
 
exp
ected
 
v
alue.
 
The
square
 
ro
ot
 
of
 
the
 
v
ariance
 
is
 
known
 
as
 
the
 
standard
 
deviation
.
The
co
v
ariance
giv
es
 
some
 
sense
 
of
 
how
 
muc
h
 
tw
o
 
v
alues
 
are
 
linearly
 
related
to
 
eac
h
 
other,
 
as
 
w
ell
 
as
 
the
 
scale
 
of
 
these
 
v
ariables:
Co
v(
f
(
x
)
,
 
g
(
y
)) = 
E
 
[(
f
(
x
)
 
−
 
E
 
[
f
(
x
)])
 
(
g
(
y
)
 
−
 
E
 
[
g
(
y
)])]
 
.
 
(3.13)
High
 
absolute
 
v
alues
 
of
 
the
 
co
v
ariance
 
mean
 
that
 
the
 
v
alues
 
c
hange
 
very
 
muc
h
and
 
are
 
b
oth
 
far
 
from
 
their
 
resp
ective
 
means
 
at
 
the
 
same
 
time.
 
If
 
the
 
sign
 
of
 
the
co
v
ariance
 
is
 
p
ositive,
 
then
 
b
oth
 
v
ariables
 
tend
 
to
 
take
 
on
 
relatively
 
high
 
v
alues
sim
ultaneously
.
 
If
 
the
 
sign
 
of
 
the
 
cov
ariance
 
is
 
negative,
 
then
 
one
 
v
ariable
 
tends
 
to
tak
e
 
on
 
a
 
relatively
 
high
 
v
alue
 
at
 
the
 
times
 
that
 
the
 
other
 
takes
 
on
 
a
 
relatively
lo
w
 
v
alue
 
and
 
vice
 
versa.
 
Other
 
measures
 
suc
h
 
as
correlation
normalize
 
the
con
tribution
 
of
 
each
 
v
ariable
 
in
 
order
 
to
 
measure
 
only
 
how
 
muc
h
 
the
 
v
ariables
 
are
related,
 
rather
 
than
 
also
 
b
eing
 
aﬀected
 
b
y
 
the
 
scale
 
of
 
the
 
separate
 
v
ariables.
The
 
notions
 
of
 
cov
ariance
 
and
 
dep
endence
 
are
 
related
 
but
 
distinct
 
concepts.
They
 
are
 
related
 
b
ecause
 
tw
o
 
v
ariables
 
that
 
are
 
indep
endent
 
hav
e
 
zero
 
cov
ariance,
and
 
t
w
o
 
v
ariables
 
that
 
ha
ve
 
nonzero
 
co
v
ariance
 
are
 
dep
endent.
 
Indep
endence,
ho
w
ev
er,
 
is
 
a
 
distinct
 
property
 
from
 
co
v
ariance.
 
F
or
 
t
w
o
 
v
ariables
 
to
 
ha
v
e
 
zero
co
v
ariance,
 
there
 
m
ust
 
b
e
 
no
 
linear
 
dep
endence
 
b
et
w
een
 
them.
 
Indep
endence
 
is
a
 
stronger
 
requirement
 
than
 
zero
 
cov
ariance,
 
b
ecause
 
indep
endence
 
also
 
excludes
nonlinear
 
relationships.
 
It
 
is
 
p
ossible
 
for
 
t
w
o
 
v
ariables
 
to
 
b
e
 
dep
endent
 
but
 
hav
e
zero
 
co
v
ariance.
 
F
or
 
example,
 
supp
ose
 
w
e
 
ﬁrst
 
sample
 
a
 
real
 
n
um
ber
x
from
 
a
uniform
 
distribution
 
ov
er
 
the
 
in
terv
al
 
[
−
1
,
1]
.
 
W
e
 
next
 
sample
 
a
 
random
 
v
ariable
s
.
59


CHAPTER
 
3.
 
PROBABILITY
 
AND
 
INF
ORMA
TION
 
THEOR
Y
With
 
probability
1
2
,
 
we
 
choose
 
the
 
v
alue
 
of
s
to
 
b
e
 
1
. Otherwise,
 
we
 
choose
 
the
v
alue
 
of
s
to
 
b
e
−
1
.
 
W
e
 
can
 
then
 
generate
 
a
 
random
 
v
ariable
y
b
y
 
assigning
y
=
sx
.
 
Clearly
,
x
and
y
are
 
not
 
indep
enden
t,
 
b
ecause
x
completely
 
determines
the
 
magnitude
 
of
 
y
.
 
How
ev
er,
 
Cov(
x,
 
y
) = 0
.
The
co
v
ariance
 
matrix
of
 
a
 
random
 
vector
x
 
∈
 
R
n
is
 
an
n
 
×
 
n
matrix,
 
suc
h
that
Co
v(
x
)
i,j
= Co
v(
x
i
,
 
x
j
)
.
 
(3.14)
The
 
diagonal
 
elemen
ts
 
of
 
the
 
co
v
ariance
 
give
 
the
 
v
ariance:
Co
v(
x
i
,
 
x
i
) = V
ar(
x
i
)
.
 
(3.15)
3.9
 
Common
 
Probabilit
y
 
Distributions
Sev
eral
 
simple
 
probability
 
distributions
 
are
 
useful
 
in
 
man
y
 
contexts
 
in
 
machine
learning.
3.9.1
 
Bernoulli
 
Distribution
The
Bernoulli
 
distribution
is
 
a
 
distribution
 
ov
er
 
a
 
single
 
binary
 
random
 
v
ariable.
It
 
is
 
controlled
 
b
y
 
a
 
single
 
parameter
φ
 
∈
[0
,
1]
,
 
whic
h
 
gives
 
the
 
probability
 
of
 
the
random
 
v
ariable
 
b
eing
 
equal
 
to
 
1.
 
It
 
has
 
the
 
following
 
prop
erties:
P
 
(
x
 
= 1) = 
φ
 
(3.16)
P
 
(
x
 
= 0) = 1
 
−
 
φ
 
(3.17)
P
 
(
x
 
= 
x
) = 
φ
x
(1
 
−
 
φ
)
1
−
x
(3.18)
E
x
[
x
] = 
φ
 
(3.19)
V
ar
x
(
x
) = 
φ
(1
 
−
 
φ
)
 
(3.20)
3.9.2
 
Multinoulli
 
Distribution
The
m
ultinoulli
,
 
or
categorical
,
distribution
is
 
a
 
distribution
 
ov
er
 
a
 
single
 
dis-
crete
 
v
ariable
 
with
k
diﬀeren
t
 
states,
 
where
k
is
 
ﬁnite.
1
The
 
multinoulli
distribution
1
“Multinoulli”
 
is
 
a
 
term
 
that
 
was
 
recently
 
coined
 
by
 
Gustav
o
 
Lacerda
 
and
 
popularized
 
by
Murph
y
 
(
2012
).
 
The
 
multinoulli
 
distribution
 
is
 
a
 
sp
ecial
 
case
 
of
 
the
m
ultinomial
 
distribution
.
A
 
multinomial
 
distribution
 
is
 
the
 
distribution
 
ov
er
 
v
ectors
 
in
{
0
,
 
.
 
.
 
.
 
,
 
n
}
k
represen
ting
 
how
 
many
times
 
each
 
of
 
the
k
categories
 
is
 
visited
 
when
n
samples
 
are
 
drawn
 
from
 
a
 
m
ultinoulli
 
distribution.
Man
y
 
texts
 
use
 
the
 
term
 
“multinomial”
 
to
 
refer
 
to
 
multinoulli
 
distributions
 
without
 
clarifying
that
 
they
 
are
 
referring
 
only
 
to
 
the
 
n
 
= 1
 
case.
60


CHAPTER
 
3.
 
PROBABILITY
 
AND
 
INF
ORMA
TION
 
THEOR
Y
is
 
parametrized
 
by
 
a
 
v
ector
p
 
∈
[0
,
1]
k
−
1
,
 
where
p
i
giv
es
 
the
 
probability
 
of
 
the
i
-th
 
state.
 
The
 
ﬁnal,
k
-th
 
state’s
 
probabilit
y
 
is
 
giv
en
 
b
y
 
1
−
 
1

p
.
Note
 
that
w
e
 
must
 
constrain
1

p
 
≤
1
. Multinoulli
 
distributions
 
are
 
often
 
used
 
to
 
refer
 
to
distributions
 
ov
er
 
categories
 
of
 
ob
jects,
 
so
 
we
 
do
 
not
 
usually
 
assume
 
that
 
state
1
 
has
 
numerical
 
v
alue
 
1,
 
and
 
so
 
on.
 
F
or
 
this
 
reason,
 
we
 
do
 
not
 
usually
 
need
 
to
compute
 
the
 
exp
ectation
 
or
 
v
ariance
 
of
 
multinoulli-distributed
 
random
 
v
ariables.
The
 
Bernoulli
 
and
 
multinoulli
 
distributions
 
are
 
suﬃcient
 
to
 
describ
e
 
any
 
distri-
bution
 
ov
er
 
their
 
domain. They
 
are
 
able
 
to
 
describe
 
any
 
distribution
 
ov
er
 
their
domain
 
not
 
so
 
m
uc
h
 
because
 
they
 
are
 
particularly
 
p
ow
erful
 
but
 
rather
 
b
ecause
 
their
domain
 
is
 
simple;
 
they
 
mo
del
 
discrete
 
v
ariables
 
for
 
whic
h
 
it
 
is
 
feasible
 
to
 
en
umerate
all
 
the
 
states.
 
When
 
dealing
 
with
 
contin
uous
 
v
ariables,
 
there
 
are
 
uncountably
man
y
 
states,
 
so
 
any
 
distribution
 
describ
ed
 
by
 
a
 
small
 
num
b
er
 
of
 
parameters
 
must
imp
ose
 
strict
 
limits
 
on
 
the
 
distribution.
3.9.3
 
Gaussian
 
Distribution
The
 
most
 
commonly
 
used
 
distribution
 
o
ver
 
real
 
n
um
bers
 
is
 
the
normal
 
distribu-
tion
,
 
also
 
kno
wn
 
as
 
the
 
Gaussian
 
distribution
:
N
(
x
;
 
µ,
 
σ
2
) =

1
2
π
σ
2
exp

−
1
2
σ
2
(
x
 
−
 
µ
)
2

.
 
(3.21)
See
 
ﬁgure
 
3.1
 
for
 
a
 
plot
 
of
 
the
 
normal
 
distribution
 
densit
y
 
function.
The
 
tw
o
 
parameters
µ
 
∈
 
R
and
σ
 
∈
(0
,
 
∞
)
 
control
 
the
 
normal
 
distribution.
The
 
parameter
µ
giv
es
 
the
 
co
ordinate
 
of
 
the
 
central
 
p
eak.
 
This
 
is
 
also
 
the
 
mean
 
of
the
 
distribution:
E
[
x
] =
µ
.
 
The
 
standard
 
deviation
 
of
 
the
 
distribution
 
is
 
given
 
by
σ
,
 
and
 
the
 
v
ariance
 
by
 
σ
2
.
When
 
we
 
ev
aluate
 
the
 
PDF,
 
we
 
need
 
to
 
square
 
and
 
in
v
ert
σ
.
 
When
 
w
e
 
need
 
to
frequen
tly
 
ev
aluate
 
the
 
PDF
 
with
 
diﬀeren
t
 
parameter
 
v
alues,
 
a
 
more
 
eﬃcient
 
wa
y
of
 
parametrizing
 
the
 
distribution
 
is
 
to
 
use
 
a
 
parameter
β
 
∈
(0
,
 
∞
)
 
to
 
control
 
the
precision
,
 
or
 
in
v
erse
 
v
ariance,
 
of
 
the
 
distribution:
N
(
x
;
 
µ,
 
β
−
1
) =

β
2
π
exp

−
1
2
β
(
x
 
−
 
µ
)
2

.
 
(3.22)
Normal
 
distributions
 
are
 
a
 
sensible
 
c
hoice
 
for
 
man
y
 
applications.
 
In
 
the
 
absence
of
 
prior
 
knowledge
 
ab
out
 
what
 
form
 
a
 
distribution
 
ov
er
 
the
 
real
 
num
bers
 
should
tak
e,
 
the
 
normal
 
distribution
 
is
 
a
 
go
o
d
 
default
 
c
hoice
 
for
 
t
w
o
 
ma
jor
 
reasons.
61


CHAPTER
 
3.
 
PROBABILITY
 
AND
 
INF
ORMA
TION
 
THEOR
Y
−
2
.
0
 
−
1
.
5
 
−
1
.
0
 
−
0
.
5
 
0
.
0
 
0
.
5
 
1
.
0
 
1
.
5
 
2
.
0
x
0
.
00
0
.
05
0
.
10
0
.
15
0
.
20
0
.
25
0
.
30
0
.
35
0
.
40
p(x)
Maxim
um
 
at
 
x
 
= 
µ
Inﬂection
 
p
oints
 
at
x
 
= 
µ
 
±
 
σ
Figure
 
3.1:
 
The
 
normal
 
distribution.
 
The
 
normal
 
distribution
N
(
x
;
µ,
 
σ
2
) 
exhibits
 
a
 
classic
“b
ell
 
curv
e”
 
shap
e,
 
with
 
the
x
co
ordinate
 
of
 
its
 
central
 
p
eak
 
given
 
by
µ
,
 
and
 
the
 
width
 
of
its
 
peak
 
controlled
 
by
σ
.
 
In
 
this
 
example,
 
w
e
 
depict
 
the
standard
 
normal
 
distribution
,
with
 
µ
 
= 0
 
and
 
σ
 
= 1
.
First,
 
many
 
distributions
 
we
 
wish
 
to
 
model
 
are
 
truly
 
close
 
to
 
b
eing
 
normal
distributions.
 
The
cen
tral
 
limit
 
theorem
sho
ws
 
that
 
the
 
sum
 
of
 
many
 
indep
en-
den
t
 
random
 
v
ariables
 
is
 
approximately
 
normally
 
distributed. This
 
means
 
that
in
 
practice,
 
many
 
complicated
 
systems
 
can
 
b
e
 
mo
deled
 
successfully
 
as
 
normally
distributed
 
noise,
 
even
 
if
 
the
 
system
 
can
 
b
e
 
decomp
osed
 
into
 
parts
 
with
 
more
structured
 
b
eha
vior.
Second,
 
out
 
of
 
all
 
p
ossible
 
probabilit
y
 
distributions
 
with
 
the
 
same
 
v
ariance,
the
 
normal
 
distribution
 
enco
des
 
the
 
maximum
 
amoun
t
 
of
 
uncertaint
y
 
o
v
er
 
the
real
 
num
b
ers.
 
W
e
 
can
 
th
us
 
think
 
of
 
the
 
normal
 
distribution
 
as
 
being
 
the
 
one
that
 
inserts
 
the
 
least
 
amount
 
of
 
prior
 
knowledge
 
in
to
 
a
 
mo
del.
 
F
ully
 
developing
and
 
justifying
 
this
 
idea
 
requires
 
more
 
mathematical
 
to
ols
 
and
 
is
 
p
ostp
oned
 
to
section
 
19.4.2
.
The
 
normal
 
distribution
 
generalizes
 
to
R
n
,
 
in
 
which
 
case
 
it
 
is
 
known
 
as
 
the
m
ultiv
ariate
 
normal
 
distribution
.
 
It
 
may
 
b
e
 
parametrized
 
with
 
a
 
positive
deﬁnite
 
symmetric
 
matrix
 
Σ
:
N
(
x
;
 
µ
,
 
Σ
) =

1
(2
π
)
n
det(
Σ
)
exp

−
1
2
(
x
 
−
 
µ
)

Σ
−
1
(
x
 
−
 
µ
)

.
 
(3.23)
62


CHAPTER
 
3.
 
PROBABILITY
 
AND
 
INF
ORMA
TION
 
THEOR
Y
The
 
parameter
µ
still
 
gives
 
the
 
mean
 
of
 
the
 
distribution,
 
though
 
now
 
it
 
is
v
ector
 
v
alued.
 
The
 
parameter
Σ
giv
es
 
the
 
cov
ariance
 
matrix
 
of
 
the
 
distribution.
As
 
in
 
the
 
univ
ariate
 
case,
 
when
 
w
e
 
wish
 
to
 
ev
aluate
 
the
 
PDF
 
sev
eral
 
times
 
for
man
y
 
diﬀerent
 
v
alues
 
of
 
the
 
parameters,
 
the
 
co
v
ariance
 
is
 
not
 
a
 
computationally
eﬃcien
t
 
wa
y
 
to
 
parametrize
 
the
 
distribution,
 
since
 
we
 
need
 
to
 
inv
ert
Σ
to
 
ev
aluate
the
 
PDF.
 
W
e
 
can
 
instead
 
use
 
a
 
precision
 
matrix
 
β
:
N
(
x
;
 
µ
,
 
β
−
1
) =

det(
β
)
(2
π
)
n
exp

−
1
2
(
x
 
−
 
µ
)

β
(
x
 
−
 
µ
)

.
 
(3.24)
W
e
 
often
 
ﬁx
 
the
 
cov
ariance
 
matrix
 
to
 
b
e
 
a
 
diagonal
 
matrix.
 
An
 
even
 
simpler
v
ersion
 
is
 
the
isotropic
Gaussian
 
distribution,
 
whose
 
cov
ariance
 
matrix
 
is
 
a
 
scalar
times
 
the
 
iden
tit
y
 
matrix.
3.9.4
 
Exp
onen
tial
 
and
 
Laplace
 
Distributions
In
 
the
 
context
 
of
 
deep
 
learning,
 
we
 
often
 
w
an
t
 
to
 
hav
e
 
a
 
probability
 
distribution
with
 
a
 
sharp
 
point
 
at
x
=
 
0
.
 
T
o
 
accomplish
 
this,
 
we
 
can
 
use
 
the
exp
onen
tial
distribution
:
p
(
x
;
 
λ
) = 
λ
1
x
≥
0
exp
 
(
−
λx
)
 
.
 
(3.25)
The
 
exp
onen
tial
 
distribution
 
uses
 
the
 
indicator
 
function
1
x
≥
0
to
 
assign
 
probabilit
y
zero
 
to
 
all
 
negativ
e
 
v
alues
 
of
 
x
.
A
 
closely
 
related
 
probabilit
y
 
distribution
 
that
 
allo
ws
 
us
 
to
 
place
 
a
 
sharp
 
p
eak
of
 
probabilit
y
 
mass
 
at
 
an
 
arbitrary
 
p
oin
t
 
µ
 
is
 
the
 
Laplace
 
distribution
Laplace(
x
;
 
µ,
 
γ
) =
1
2
γ
exp

−
|
x
 
−
 
µ
|
γ

.
 
(3.26)
3.9.5
 
The
 
Dirac
 
Distribution
 
and
 
Empirical
 
Distribution
In
 
some
 
cases,
 
we
 
wish
 
to
 
sp
ecify
 
that
 
all
 
the
 
mass
 
in
 
a
 
probability
 
distribution
clusters
 
around
 
a
 
single
 
point.
 
This
 
can
 
b
e
 
accomplished
 
b
y
 
deﬁning
 
a
 
PDF
 
using
the
 
Dirac
 
delta
 
function
,
 
δ
(
x
)
:
p
(
x
) = 
δ
(
x
 
−
µ
)
.
 
(3.27)
The
 
Dirac
 
delta
 
function
 
is
 
deﬁned
 
such
 
that
 
it
 
is
 
zero
 
v
alued
 
everywhere
 
except
0,
 
yet
 
integrates
 
to
 
1.
 
The
 
Dirac
 
delta
 
function
 
is
 
not
 
an
 
ordinary
 
function
 
that
asso
ciates
 
each
 
v
alue
x
with
 
a
 
real-v
alued
 
output;
 
instead
 
it
 
is
 
a
 
diﬀerent
 
kind
 
of
63


CHAPTER
 
3.
 
PROBABILITY
 
AND
 
INF
ORMA
TION
 
THEOR
Y
mathematical
 
ob
ject
 
called
 
a
generalized
 
function
that
 
is
 
deﬁned
 
in
 
terms
 
of
its
 
prop
erties
 
when
 
integrated.
 
W
e
 
can
 
think
 
of
 
the
 
Dirac
 
delta
 
function
 
as
 
b
eing
the
 
limit
 
p
oint
 
of
 
a
 
series
 
of
 
functions
 
that
 
put
 
less
 
and
 
less
 
densit
y
 
on
 
all
 
p
oin
ts
other
 
than
 
zero.
By
 
deﬁning
p
(
x
)
 
to
 
b
e
δ
shifted
 
by
−
µ
w
e
 
obtain
 
an
 
inﬁnitely
 
narro
w
 
and
inﬁnitely
 
high
 
p
eak
 
of
 
probabilit
y
 
densit
y
 
where
 
x
 
= 
µ
.
A
 
common
 
use
 
of
 
the
 
Dirac
 
delta
 
distribution
 
is
 
as
 
a
 
comp
onent
 
of
 
an
empirical
distribution
,
ˆ
p
(
x
) =
1
m
m

i
=1
δ
(
x
 
−
x
(
i
)
)
 
(3.28)
whic
h
 
puts
 
probabilit
y
 
mass
1
m
on
 
eac
h
 
of
 
the
m
p
oin
ts
x
(1)
,
 
.
 
.
 
.
 
,
 
x
(
m
)
,
 
forming
a
 
giv
en
 
data
 
set
 
or
 
collection
 
of
 
samples.
 
The
 
Dirac
 
delta
 
distribution
 
is
 
only
necessary
 
to
 
deﬁne
 
the
 
empirical
 
distribution
 
ov
er
 
con
tin
uous
 
v
ariables.
 
F
or
 
discrete
v
ariables,
 
the
 
situation
 
is
 
simpler:
 
an
 
empirical
 
distribution
 
can
 
be
 
conceptualized
as
 
a
 
multinoulli
 
distribution,
 
with
 
a
 
probabilit
y
 
asso
ciated
 
with
 
eac
h
 
p
ossible
input
 
v
alue
 
that
 
is
 
simply
 
equal
 
to
 
the
empirical
 
frequency
of
 
that
 
v
alue
 
in
 
the
training
 
set.
W
e
 
can
 
view
 
the
 
empirical
 
distribution
 
formed
 
from
 
a
 
dataset
 
of
 
training
examples
 
as
 
sp
ecifying
 
the
 
distribution
 
that
 
we
 
sample
 
from
 
when
 
w
e
 
train
 
a
 
mo
del
on
 
this
 
dataset. Another
 
imp
ortant
 
p
ersp
ective
 
on
 
the
 
empirical
 
distribution
 
is
that
 
it
 
is
 
the
 
probability
 
density
 
that
 
maximizes
 
the
 
likelihoo
d
 
of
 
the
 
training
 
data
(see
 
section
 
5.5
).
3.9.6
 
Mixtures
 
of
 
Distributions
It
 
is
 
also
 
common
 
to
 
deﬁne
 
probability
 
distributions
 
by
 
combining
 
other
 
simpler
probabilit
y
 
distributions.
 
One
 
common w
ay
 
of
 
com
bining
 
distributions
 
is to
construct
 
a
mixture
 
distribution
.
 
A
 
mixture
 
distribution
 
is
 
made
 
up
 
of
 
several
comp
onen
t
 
distributions.
 
On
 
eac
h
 
trial,
 
the
 
c
hoice
 
of
 
whic
h
 
comp
onen
t
 
distribution
should
 
generate
 
the
 
sample
 
is
 
determined
 
by
 
sampling
 
a
 
component
 
identit
y
 
from
a
 
m
ultinoulli
 
distribution:
P
 
(
x
) =

i
P
 
(
c
 
= 
i
)
P
 
(
x
 
|
 
c
 
= 
i
)
,
 
(3.29)
where
 
P
 
(
c
)
 
is
 
the
 
multinoulli
 
distribution
 
ov
er
 
comp
onent
 
identities.
W
e
 
hav
e
 
already
 
seen
 
one
 
example
 
of
 
a
 
mixture
 
distribution: the
 
empirical
distribution
 
o
v
er
 
real-v
alued
 
v
ariables
 
is
 
a
 
mixture
 
distribution
 
with
 
one
 
Dirac
comp
onen
t
 
for
 
eac
h
 
training
 
example.
64


CHAPTER
 
3.
 
PROBABILITY
 
AND
 
INF
ORMA
TION
 
THEOR
Y
The
 
mixture
 
mo
del
 
is
 
one
 
simple
 
strategy
 
for
 
com
bining
 
probability
 
distributions
to
 
create
 
a
 
ric
her
 
distribution.
 
In
 
chapter
 
16
,
 
w
e
 
explore
 
the
 
art
 
of
 
building
 
complex
probabilit
y
 
distributions
 
from
 
simple
 
ones
 
in
 
more
 
detail.
The
 
mixture
 
model
 
allo
ws
 
us
 
to
 
brieﬂy
 
glimpse
 
a
 
concept
 
that
 
will
 
b
e
 
of
paramoun
t
 
imp
ortance
 
later—the
laten
t
 
v
ariable
.
 
A
 
laten
t
 
v
ariable
 
is
 
a
 
random
v
ariable
 
that
 
w
e
 
cannot
 
observe
 
directly
.
 
The
 
comp
onent
 
iden
tit
y
 
v
ariable
c
of
 
the
mixture
 
mo
del
 
provides
 
an
 
example.
 
Laten
t
 
v
ariables
 
may
 
b
e
 
related
 
to
x
through
the
 
joint
 
distribution,
 
in
 
this
 
case,
P
(
x
,
 
c
) =
P
(
x
 
|
 
c
)
P
(
c
)
.
 
The
 
distribution
P
(
c
)
o
v
er
 
the
 
latent
 
v
ariable
 
and
 
the
 
distribution
P
(
x
 
|
 
c
)
 
relating
 
the
 
latent
 
v
ariables
to
 
the
 
visible
 
v
ariables
 
determines
 
the
 
shap
e
 
of
 
the
 
distribution
P
(
x
)
,
 
ev
en
 
though
it
 
is
 
p
ossible
 
to
 
describ
e
P
(
x
)
 
without
 
reference
 
to
 
the
 
latent
 
v
ariable.
 
Latent
v
ariables
 
are
 
discussed
 
further
 
in
 
section
 
16.5
.
A
 
v
ery
 
p
ow
erful
 
and
 
common
 
t
yp
e
 
of
 
mixture
 
mo
del
 
is
 
the
Gaussian
 
mixture
mo
del
,
 
in
 
which
 
the
 
comp
onents
p
(
x
 
|
 
c
=
i
)
 
are
 
Gaussians.
 
Eac
h
 
comp
onent
 
has
a
 
separately
 
parametrized
 
mean
µ
(
i
)
and
 
cov
ariance
Σ
(
i
)
.
 
Some
 
mixtures
 
can
 
hav
e
more
 
constraints.
 
F
or
 
example,
 
the
 
co
v
ariances
 
could
 
b
e
 
shared
 
across
 
comp
onents
via
 
the
 
constrain
t
Σ
(
i
)
=
Σ
,
 
∀
i
.
 
As
 
with
 
a
 
single
 
Gaussian
 
distribution,
 
the
 
mixture
of
 
Gaussians
 
might
 
constrain
 
the
 
cov
ariance
 
matrix
 
for
 
each
 
comp
onent
 
to
 
be
diagonal
 
or
 
isotropic.
In
 
addition
 
to
 
the
 
means
 
and
 
cov
ariances,
 
the
 
parameters
 
of
 
a
 
Gaussian
 
mixture
sp
ecify
 
the
prior
 
probabilit
y
 
α
i
=
P
(
c
=
i
) 
giv
en
 
to
 
each
 
comp
onent
i
.
 
The
 
word
“prior”
 
indicates
 
that
 
it
 
expresses
 
the
 
mo
del’s
 
b
eliefs
 
ab
out
c
b
efor
e
 
it
 
has
 
observed
x
.
 
By
 
comparison,
P
(
c
 
|
 
x
)
 
is
 
a
p
osterior
 
probability
,
 
b
ecause
 
it
 
is
 
computed
after
 
observ
ation
 
of
x
.
 
A
 
Gaussian
 
mixture
 
mo
del
 
is
 
a
univ
ersal
 
appro
ximator
of
 
densities,
 
in
 
the
 
sense
 
that
 
an
y
 
smo
oth
 
densit
y
 
can
 
b
e
 
appro
ximated
 
with
an
y
 
sp
eciﬁc
 
nonzero
 
amount
 
of
 
error
 
by
 
a
 
Gaussian
 
mixture
 
mo
del
 
with
 
enough
comp
onen
ts.
Figure
 
3.2
 
sho
ws
 
samples
 
from
 
a
 
Gaussian
 
mixture
 
mo
del.
3.10
 
Useful
 
Prop
erties
 
of
 
Common
 
F
unctions
Certain
 
functions
 
arise
 
often while
 
w
orking
 
with
 
probabilit
y
 
distributions,
esp
ecially
 
the
 
probabilit
y
 
distributions
 
used
 
in
 
deep
 
learning
 
mo
dels.
One
 
of
 
these
 
functions
 
is
 
the
 
logistic
 
sigmoid
:
σ
(
x
) =
1
1
 
+
 
exp(
−
x
)
.
 
(3.30)
65


CHAPTER
 
3.
 
PROBABILITY
 
AND
 
INF
ORMA
TION
 
THEOR
Y
x
1
x
2
Figure
 
3.2: Samples
 
from
 
a
 
Gaussian
 
mixture
 
mo
del. In
 
this
 
example
,
 
there
 
are
 
three
comp
onen
ts.
 
F
rom
 
left
 
to
 
righ
t,
 
the
 
ﬁrst
 
comp
onent
 
has
 
an
 
isotropic
 
cov
ariance
 
matrix,
meaning
 
it
 
has
 
the
 
same
 
amount
 
of
 
v
ariance
 
in
 
eac
h
 
direction.
 
The
 
second
 
has
 
a
 
diagonal
co
v
ariance
 
matrix,
 
meaning
 
it
 
can
 
control
 
the
 
v
ariance
 
separately
 
along
 
eac
h
 
axis-aligned
direction.
 
This
 
example
 
has
 
more
 
v
ariance
 
along
 
the
x
2
axis
 
than
 
along
 
the
x
1
axis.
 
The
third
 
comp
onent
 
has
 
a
 
full-rank
 
cov
ariance
 
matrix,
 
enabling
 
it
 
to
 
control
 
the
 
v
ariance
separately
 
along
 
an
 
arbitrary
 
basis
 
of
 
directions.
The
 
logistic
 
sigmoid
 
is
 
commonly
 
used
 
to
 
pro
duce
 
the
φ
parameter
 
of
 
a
 
Bernoulli
distribution
 
b
ecause
 
its
 
range
 
is
 
(0
,
1)
,
 
whic
h
 
lies
 
within
 
the
 
v
alid
 
range
 
of
 
v
alues
for
 
the
φ
parameter.
 
See
 
ﬁgure
 
3.3
 
for
 
a
 
graph
 
of
 
the
 
sigmoid
 
function.
 
The
sigmoid
 
function
saturates
when
 
its
 
argument
 
is
 
very
 
p
ositive
 
or
 
very
 
negativ
e,
meaning
 
that
 
the
 
function
 
b
ecomes
 
very
 
ﬂat
 
and
 
insensitive
 
to
 
small
 
changes
 
in
 
its
input.
Another
 
commonly
 
encountered
 
function
 
is
 
the
softplus
 
function
(
Dugas
et
 
al.
,
 
2001
):
ζ
(
x
)
 
= log
 
(1
 
+
 
exp(
x
))
 
.
 
(3.31)
The
 
softplus
 
function
 
can
 
b
e
 
useful
 
for
 
pro
ducing
 
the
β
or
σ
parameter
 
of
 
a
 
normal
distribution
 
b
ecause
 
its
 
range
 
is
 
(0
,
 
∞
)
.
 
It
 
also
 
arises
 
commonly
 
when
 
manipulating
expressions
 
in
v
olving
 
sigmoids.
 
The
 
name
 
of
 
the
 
softplus
 
function
 
comes
 
from
 
the
fact
 
that
 
it
 
is
 
a
 
smo
othed,
 
or
 
“softened,”
 
version
 
of
x
+
= max(0
,
 
x
)
.
 
(3.32)
See
 
ﬁgure
 
3.4
 
for
 
a
 
graph
 
of
 
the
 
softplus
 
function.
The
 
follo
wing
 
prop
erties
 
are
 
all
 
useful
 
enough
 
that
 
you
 
may
 
wish
 
to
 
memorize
66


CHAPTER
 
3.
 
PROBABILITY
 
AND
 
INF
ORMA
TION
 
THEOR
Y
−
10
 
−
5
 
0
 
5
 
10
x
0
.
0
0
.
2
0
.
4
0
.
6
0
.
8
1
.
0
σ
(
x
)
Figure
 
3.3:
 
The
 
logistic
 
sigmoid
 
function.
−
10
 
−
5
 
0
 
5
 
10
x
0
2
4
6
8
10
ζ
(
x
)
Figure
 
3.4:
 
The
 
softplus
 
function.
67


CHAPTER
 
3.
 
PROBABILITY
 
AND
 
INF
ORMA
TION
 
THEOR
Y
them:
σ
(
x
) =
exp(
x
)
exp(
x
)
 
+
 
exp(0)
(3.33)
d
dx
σ
(
x
) = 
σ
(
x
)(1
 
−
σ
(
x
))
 
(3.34)
1
 
−
 
σ
(
x
) = 
σ
(
−
x
)
 
(3.35)
log
 
σ
(
x
) = 
−
ζ
(
−
x
)
 
(3.36)
d
dx
ζ
(
x
)
 
= 
σ
(
x
)
 
(3.37)
∀
x
 
∈
 
(0
,
 
1)
,
 
σ
−
1
(
x
) = log

x
1
 
−
 
x

(3.38)
∀
x
 
>
 
0
,
 
ζ
−
1
(
x
) = log
 
(exp(
x
)
 
−
 
1)
 
(3.39)
ζ
(
x
)
 
=

x
−∞
σ
(
y
)
dy
 
(3.40)
ζ
(
x
)
 
−
 
ζ
(
−
x
) = 
x
 
(3.41)
The
 
function
σ
−
1
(
x
)
 
is
 
called
 
the
logit
in
 
statistics,
 
but
 
this
 
term
 
is
 
rarely
 
used
 
in
mac
hine
 
learning.
Equation
 
3.41
 
provides
 
extra
 
justiﬁcation
 
for
 
the
 
name
 
“softplus.”
 
The
 
softplus
function
 
is
 
intended
 
as
 
a
 
smo
othed
 
version
 
of
 
the
p
ositiv
e
 
part
 
function
,
x
+
=
max
{
0
,
 
x
}
.
 
The
 
p
ositive
 
part
 
function
 
is
 
the
 
coun
terpart
 
of
 
the
negativ
e
 
part
function
,
x
−
=
max
{
0
,
 
−
x
}
. T
o
 
obtain
 
a
 
smooth
 
function
 
that
 
is
 
analogous
 
to
the
 
negative
 
part,
 
one
 
can
 
use
ζ
(
−
x
)
.
 
Just
 
as
x
can
 
b
e
 
recov
ered
 
from
 
its
 
p
ositive
part
 
and
 
its
 
negative
 
part
 
via
 
the
 
iden
tit
y
x
+
−
x
−
=
x
,
 
it
 
is
 
also
 
p
ossible
 
to
 
recov
er
x
using
 
the
 
same
 
relationship
 
b
etw
een
ζ
(
x
)
 
and
ζ
(
−
x
)
,
 
as
 
shown
 
in
 
equation
 
3.41
.
3.11
 
Ba
y
es’
 
Rule
W
e
 
often
 
ﬁnd
 
ourselves
 
in
 
a
 
situation
 
where
 
we
 
know
P
(
y
 
|
 
x
)
 
and
 
need
 
to
 
know
P
(
x
 
|
 
y
)
.
 
F
ortunately
,
 
if
 
we
 
also
 
know
P
(
x
)
,
 
w
e
 
can
 
compute
 
the
 
desired
 
quantit
y
using
 
Ba
y
es’
 
rule
:
P
 
(
x
 
|
 
y
) =
P
 
(
x
)
P
 
(
y
 
|
 
x
)
P
 
(
y
)
.
 
(3.42)
Note
 
that
 
while
P
(
y
)
 
app
ears
 
in
 
the
 
form
ula,
 
it
 
is
 
usually
 
feasible
 
to
 
compute
P
 
(
y
) =

x
P
 
(
y
 
|
 
x
)
P
 
(
x
)
,
 
so
 
we
 
do
 
not
 
need
 
to
 
b
egin
 
with
 
knowledge
 
of
 
P
 
(
y
)
.
68


CHAPTER
 
3.
 
PROBABILITY
 
AND
 
INF
ORMA
TION
 
THEOR
Y
Ba
y
es’
 
rule
 
is
 
straigh
tforw
ard
 
to
 
deriv
e
 
from the
 
deﬁnition
 
of conditional
probabilit
y
,
 
but
 
it
 
is
 
useful
 
to
 
kno
w
 
the
 
name
 
of
 
this
 
form
ula
 
since
 
many
 
texts
refer
 
to
 
it
 
b
y
 
name.
 
It
 
is
 
named
 
after
 
the
 
Rev
erend
 
Thomas
 
Bay
es,
 
who
 
ﬁrst
disco
v
ered
 
a
 
sp
ecial
 
case
 
of
 
the
 
form
ula.
 
The
 
general
 
version
 
presented
 
here
 
w
as
indep
enden
tly
 
discov
ered
 
by
 
Pierre-Simon
 
Laplace.
3.12
 
T
ec
hnical
 
Details
 
of
 
Con
tin
uous
 
V
ariables
A
 
prop
er
 
formal
 
understanding
 
of
 
contin
uous
 
random
 
v
ariables
 
and
 
probability
densit
y
 
functions
 
requires
 
dev
eloping
 
probabilit
y
 
theory
 
in
 
terms
 
of
 
a
 
branc
h
 
of
mathematics
 
kno
wn
 
as
measure
 
theory
.
 
Measure
 
theory
 
is
 
b
eyond
 
the
 
scop
e
 
of
this
 
textb
o
ok,
 
but
 
we
 
can
 
brieﬂy
 
sketc
h
 
some
 
of
 
the
 
issues
 
that
 
measure
 
theory
 
is
emplo
y
ed
 
to
 
resolv
e.
In
 
section
 
3.3.2
,
 
we
 
sa
w
 
that
 
the
 
probability
 
of
 
a
 
contin
uous
 
v
ector-v
alued
x
lying
 
in
 
some
 
set
S
is
 
giv
en
 
by
 
the
 
integral
 
of
p
(
x
)
 
ov
er
 
the
 
set
S
.
 
Some
 
choices
of
 
set
S
can
 
produce
 
paradoxes.
 
F
or
 
example,
 
it
 
is
 
p
ossible
 
to
 
construct
 
t
w
o
sets
S
1
and
S
2
suc
h
 
that
p
(
x
 
∈
 
S
1
) +
p
(
x
 
∈
 
S
2
)
>
1
 
but
S
1
∩
 
S
2
=
∅
.
 
These
sets
 
are
 
generally
 
constructed
 
making
 
very
 
heavy
 
use
 
of
 
the
 
inﬁnite
 
precision
 
of
real
 
num
bers,
 
for
 
example
 
by
 
making
 
fractal-shap
ed
 
sets
 
or
 
sets
 
that
 
are
 
deﬁned
b
y
 
transforming
 
the
 
set
 
of
 
rational
 
num
b
ers.
2
One
 
of
 
the
 
key
 
con
tributions
 
of
measure
 
theory
 
is
 
to
 
pro
vide
 
a
 
characterization
 
of
 
the
 
set
 
of
 
sets
 
we
 
can
 
compute
the
 
probabilit
y
 
of
 
without
 
encountering
 
paradoxes.
 
In
 
this
 
b
o
ok,
 
we
 
integrate
 
only
o
v
er
 
sets
 
with
 
relatively
 
simple
 
descriptions,
 
so
 
this
 
asp
ect
 
of
 
measure
 
theory
 
nev
er
b
ecomes
 
a
 
relev
ant
 
concern.
F
or
 
our
 
purp
oses,
 
measure
 
theory
 
is
 
more
 
useful
 
for
 
describing
 
theorems
 
that
apply
 
to
 
most
 
p
oin
ts
 
in
R
n
but
 
do
 
not
 
apply
 
to
 
some
 
corner
 
cases.
 
Measure
 
theory
pro
vides
 
a
 
rigorous
 
wa
y
 
of
 
describing
 
that
 
a
 
set
 
of
 
p
oints
 
is
 
negligibly
 
small.
 
Such
a
 
set
 
is
 
said
 
to
 
hav
e
measure
 
zero
.
 
W
e
 
do
 
not
 
formally
 
deﬁne
 
this
 
concept
 
in
 
this
textb
o
ok.
 
F
or
 
our
 
purp
oses,
 
it
 
is
 
suﬃcient
 
to
 
understand
 
the
 
intuit
ion
 
that
 
a
 
set
of
 
measure
 
zero
 
o
ccupies
 
no
 
volume
 
in
 
the
 
space
 
we
 
are
 
measuring.
 
F
or
 
example,
within
R
2
,
 
a
 
line
 
has
 
measure
 
zero,
 
while
 
a
 
ﬁlled
 
polygon
 
has
 
positive
 
measure.
Lik
ewise,
 
an
 
individual
 
p
oint
 
has
 
measure
 
zero.
 
Any
 
union
 
of
 
countably
 
man
y
 
sets
that
 
each
 
hav
e
 
measure
 
zero
 
also
 
has
 
measure
 
zero
 
(so
 
the
 
set
 
of
 
all
 
the
 
rational
n
um
b
ers
 
has
 
measure
 
zero,
 
for
 
instance).
Another
 
useful
 
term
 
from
 
measure
 
theory
 
is
almost
 
ev
erywhere
.
 
A
 
prop
ert
y
that
 
holds
 
almost
 
everywhere
 
holds
 
throughout
 
all
 
space
 
except
 
for
 
on
 
a
 
set
 
of
2
The
 
Banach-T
arski
 
theorem
 
provides
 
a
 
fun
 
example
 
of
 
such
 
sets.
69


CHAPTER
 
3.
 
PROBABILITY
 
AND
 
INF
ORMA
TION
 
THEOR
Y
measure
 
zero.
 
Because
 
the
 
exceptions
 
o
ccup
y
 
a
 
negligible
 
amount
 
of
 
space,
 
they
can
 
b
e
 
safely
 
ignored
 
for
 
man
y
 
applications.
 
Some
 
imp
ortant
 
results
 
in
 
probability
theory
 
hold
 
for
 
all
 
discrete
 
v
alues
 
but
 
hold
 
“almost
 
everywhere”
 
only
 
for
 
contin
uous
v
alues.
Another
 
tec
hnical
 
detail
 
of
 
contin
uous
 
v
ariables
 
relates
 
to
 
handling
 
contin
uous
random
 
v
ariables
 
that
 
are
 
deterministic
 
functions
 
of
 
one
 
another.
 
Suppose
 
w
e
 
hav
e
t
w
o
 
random
 
v
ariables,
x
and
y
,
 
suc
h
 
that
y
=
g
(
x
)
,
 
where
g
is
 
an
 
inv
ertible,
 
con-
tin
uous,
 
diﬀeren
tiable
 
transformation.
 
One
 
migh
t
 
expect
 
that
p
y
(
y
) =
p
x
(
g
−
1
(
y
))
.
This
 
is
 
actually
 
not
 
the
 
case.
As
 
a
 
simple
 
example,
 
supp
ose
 
we
 
ha
v
e
 
scalar
 
random
 
v
ariables
x
and
y
.
 
Suppose
y
=
x
2
and
x
 
∼
 
U
(0
,
1)
.
 
If
 
we
 
use
 
the
 
rule
p
y
(
y
)
 
=
p
x
(2
y
)
 
then
p
y
will
 
be
 
0
ev
erywhere
 
except
 
the
 
interv
al
 
[0
,
1
2
]
,
 
and
 
it
 
will
 
b
e
 
1
 
on
 
this
 
interv
al.
 
This
 
means

p
y
(
y
)
dy
 
=
1
2
,
 
(3.43)
whic
h
 
violates
 
the
 
deﬁnition
 
of
 
a
 
probabilit
y
 
distribution.
 
This
 
is
 
a
 
common
 
mistake.
The
 
problem
 
with
 
this
 
approach
 
is
 
that
 
it
 
fails
 
to
 
account
 
for
 
the
 
distortion
 
of
space
 
introduced
 
by
 
the
 
function
g
.
 
Recall
 
that
 
the
 
probability
 
of
x
lying
 
in
 
an
inﬁnitesimally
 
small
 
region
 
with
 
volume
δ
x
is
 
given
 
b
y
p
(
x
)
δ
x
.
 
Since
g
can
 
expand
or
 
con
tract
 
space,
 
the
 
inﬁnitesimal
 
volume
 
surrounding
x
in
x
space
 
ma
y
 
hav
e
diﬀeren
t
 
v
olume
 
in
 
y
 
space.
T
o
 
see
 
how
 
to
 
correct
 
the
 
problem,
 
we
 
return
 
to
 
the
 
scalar
 
case.
 
W
e
 
need
 
to
preserv
e
 
the
 
prop
ert
y
|
p
y
(
g
(
x
))
dy
|
 
= 
|
p
x
(
x
)
dx
|
.
 
(3.44)
Solving
 
from
 
this,
 
w
e
 
obtain
p
y
(
y
) = 
p
x
(
g
−
1
(
y
))




∂
x
∂
y




(3.45)
or
 
equiv
alently
p
x
(
x
) = 
p
y
(
g
(
x
))




∂
g
(
x
)
∂
x




.
 
(3.46)
In
 
higher
 
dimensions,
 
the
 
deriv
ativ
e
 
generalizes
 
to
 
the
 
determinant
 
of
 
the
Jacobian
matrix
—the
 
matrix
 
with
 
J
i,j
=
∂
x
i
∂
y
j
.
 
Thus,
 
for
 
real-v
alued
 
vectors
 
x
 
and
 
y
,
p
x
(
x
) = 
p
y
(
g
(
x
))




det

∂
g
(
x
)
∂
x





.
 
(3.47)
70


CHAPTER
 
3.
 
PROBABILITY
 
AND
 
INF
ORMA
TION
 
THEOR
Y
3.13
 
Information
 
Theory
Information
 
theory is
 
a branc
h
 
of
 
applied
 
mathematics
 
that
 
rev
olv
es around
quan
tifying
 
how
 
m
uc
h
 
information
 
is
 
presen
t
 
in
 
a
 
signal.
 
It
 
was
 
originally
 
inv
en
ted
to
 
study
 
sending
 
messages
 
from
 
discrete
 
alphab
ets
 
ov
er
 
a
 
noisy
 
channel,
 
suc
h
 
as
comm
unication
 
via
 
radio
 
transmission.
 
In
 
this
 
con
text,
 
information
 
theory
 
tells
 
how
to
 
design
 
optimal
 
co
des
 
and
 
calculate
 
the
 
exp
ected
 
length
 
of
 
messages
 
sampled
 
from
sp
eciﬁc
 
probability
 
distributions
 
using
 
v
arious
 
enco
ding
 
sc
hemes.
 
In
 
the
 
con
text
 
of
mac
hine
 
learning,
 
we
 
can
 
also
 
apply
 
information
 
theory
 
to
 
contin
uous
 
v
ariables
where
 
some
 
of
 
these
 
message
 
length
 
interpretations
 
do
 
not
 
apply
.
 
This
 
ﬁeld
 
is
fundamen
tal
 
to
 
many
 
areas
 
of
 
electrical
 
engineering
 
and
 
computer
 
science.
 
In
 
this
textb
o
ok,
 
we
 
mostly
 
use
 
a
 
few
 
key
 
ideas
 
from
 
information
 
theory
 
to
 
characterize
probabilit
y
 
distributions
 
or
 
to
 
quan
tify
 
similarity
 
b
etw
een
 
probability
 
distributions.
F
or
 
more
 
detail
 
on
 
information
 
theory
,
 
see
 
Cov
er
 
and
 
Thomas
 
(
2006
)
 
or
 
MacKay
(
2003
).
The
 
basic
 
intuition
 
b
ehind
 
information
 
theory
 
is
 
that
 
learning
 
that
 
an
 
unlikely
ev
en
t
 
has occurred
 
is
 
more informativ
e than
 
learning
 
that
 
a
 
lik
ely
 
ev
en
t
 
has
o
ccurred.
 
A
 
message
 
sa
ying
 
“the
 
sun
 
rose
 
this
 
morning”
 
is
 
so
 
uninformativ
e
 
as
to
 
be
 
unnecessary
 
to
 
send,
 
but
 
a
 
message
 
sa
ying
 
“there
 
was
 
a
 
solar
 
eclipse
 
this
morning”
 
is
 
very
 
informative.
W
e
 
would
 
lik
e
 
to
 
quan
tify
 
information
 
in
 
a
 
wa
y
 
that
 
formalizes
 
this
 
intuition.
•
Lik
ely
 
ev
en
ts
 
should
 
ha
v
e
 
lo
w
 
information
 
con
ten
t,
 
and
 
in
 
the
 
extreme
 
case,
ev
en
ts
 
that
 
are
 
guaranteed
 
to
 
happ
en
 
should
 
ha
v
e
 
no
 
information
 
conten
t
whatso
ev
er.
•
 
Less
 
lik
ely
 
ev
en
ts
 
should
 
ha
ve
 
higher
 
information
 
conten
t.
•
Indep
enden
t
 
ev
en
ts
 
should
 
ha
ve
 
additive
 
information.
 
F
or
 
example,
 
ﬁnding
out
 
that
 
a
 
tossed
 
coin
 
has
 
come
 
up
 
as
 
heads
 
twice
 
should
 
con
v
ey
 
twice
 
as
m
uc
h
 
information
 
as
 
ﬁnding
 
out
 
that
 
a
 
tossed
 
coin
 
has
 
come
 
up
 
as
 
heads
once.
T
o
 
satisfy
 
all
 
three
 
of
 
these
 
prop
erties,
 
we
 
deﬁne
 
the
self-information
of
 
an
ev
en
t
 
x
 
= 
x
 
to
 
b
e
I
(
x
) = 
−
log
 
P
 
(
x
)
.
 
(3.48)
In
 
this
 
b
o
ok,
 
we
 
alwa
ys
 
use
log
to
 
mean
 
the
 
natural
 
logarithm,
 
with
 
base
e
.
 
Our
deﬁnition
 
of
I
(
x
)
 
is
 
therefore
 
written
 
in
 
units
 
of
nats
.
 
One
 
nat
 
is
 
the
 
amount
 
of
information
 
gained
 
by
 
observing
 
an
 
even
t
 
of
 
probability
1
e
.
 
Other
 
texts
 
use
 
base-2
71


CHAPTER
 
3.
 
PROBABILITY
 
AND
 
INF
ORMA
TION
 
THEOR
Y
logarithms
 
and
 
units
 
called
bits
or
shannons
;
 
information
 
measured
 
in
 
bits
 
is
just
 
a
 
rescaling
 
of
 
information
 
measured
 
in
 
nats.
When
x
is
 
contin
uous,
 
we
 
use
 
the
 
same
 
deﬁnition
 
of
 
information
 
b
y
 
analogy
,
but
 
some
 
of
 
the
 
prop
erties
 
from
 
the
 
discrete
 
case
 
are
 
lost.
 
F
or
 
example,
 
an
 
ev
en
t
with
 
unit
 
density
 
still
 
has
 
zero
 
information,
 
despite
 
not
 
b
eing
 
an
 
even
t
 
that
 
is
guaran
teed
 
to
 
o
ccur.
Self-information
 
deals
 
only
 
with
 
a
 
single
 
outcome.
 
W
e
 
can
 
quan
tify
 
the
 
amoun
t
of
 
uncertain
t
y
 
in
 
an
 
entire
 
probabilit
y
 
distribution
 
using
 
the
 
Shannon
 
entrop
y
,
H
(
x
) = 
E
x
∼
P
[
I
(
x
)] = 
−
E
x
∼
P
[log
 
P
 
(
x
)]
,
 
(3.49)
also
 
denoted
H
(
P
)
.
 
In
 
other
 
w
ords,
 
the
 
Shannon
 
en
trop
y
 
of
 
a
 
distribution
 
is
 
the
exp
ected
 
amoun
t
 
of
 
information
 
in
 
an
 
ev
en
t
 
dra
wn
 
from
 
that
 
distribution.
 
It
 
gives
a
 
low
er
 
b
ound
 
on
 
the
 
num
ber
 
of
 
bits
 
(if
 
the
 
logarithm
 
is
 
base
 
2,
 
otherwise
 
the
 
units
are
 
diﬀerent)
 
needed
 
on
 
av
erage
 
to
 
enco
de
 
symbols
 
drawn
 
from
 
a
 
distribution
P
.
Distributions
 
that
 
are
 
nearly
 
deterministic
 
(where
 
the
 
outcome
 
is
 
nearly
 
certain)
ha
v
e
 
low
 
entrop
y;
 
distributions
 
that
 
are
 
closer
 
to
 
uniform
 
hav
e
 
high
 
entrop
y
.
 
See
ﬁgure
 
3.5
 
for
 
a
 
demonstration.
 
When
x
is
 
contin
uous,
 
the
 
Shannon
 
entrop
y
 
is
kno
wn
 
as
 
the
 
diﬀeren
tial
 
en
trop
y
.
If
 
we
 
hav
e
 
t
wo
 
separate
 
probabilit
y
 
distributions
P
(
x
)
 
and
Q
(
x
)
 
ov
er
 
the
 
same
random
 
v
ariable
x
,
 
we
 
can
 
measure
 
ho
w
 
diﬀerent
 
these
 
t
wo
 
distributions
 
are
 
using
the
 
Kullbac
k-Leibler
 
(KL)
 
divergence
:
D
KL
(
P
 

Q
) = 
E
x
∼
P

log
P
 
(
x
)
Q
(
x
)

= 
E
x
∼
P
[log
 
P
 
(
x
)
 
−
 
log
 
Q
(
x
)]
 
.
 
(3.50)
In
 
the
 
case
 
of
 
discrete
 
v
ariables,
 
it
 
is
 
the
 
extra
 
amoun
t
 
of
 
information
 
(measured
in
 
bits
 
if
 
we
 
use
 
the
 
base-
2
 
logarithm,
 
but
 
in
 
mac
hine
 
learning
 
we
 
usually
 
use
 
nats
and
 
the
 
natural
 
logarithm)
 
needed
 
to
 
send
 
a
 
message
 
containing
 
sym
b
ols
 
drawn
from
 
probability
 
distribution
P
,
 
when
 
we
 
use
 
a
 
co
de
 
that
 
was
 
designed
 
to
 
minimize
the
 
length
 
of
 
messages
 
dra
wn
 
from
 
probabilit
y
 
distribution
 
Q
.
The
 
KL
 
div
ergence
 
has
 
many
 
useful
 
prop
erties,
 
most
 
notably
 
b
eing
 
non-negativ
e.
The
 
KL
 
div
ergence
 
is
 
0
 
if
 
and
 
only
 
if
P
and
Q
are
 
the
 
same
 
distribution
 
in
 
the
case
 
of
 
discrete
 
v
ariables,
 
or
 
equal
 
“almost
 
everywhere”
 
in
 
the
 
case
 
of
 
contin
uous
v
ariables.
 
Because
 
the
 
KL
 
divergence
 
is
 
non-negative
 
and
 
measures
 
the
 
diﬀerence
b
et
w
een
 
t
wo
 
distributions,
 
it
 
is
 
often
 
conceptualized
 
as
 
measuring
 
some
 
sort
 
of
distance
 
b
et
w
een
 
these
 
distributions.
 
It
 
is
 
not
 
a
 
true
 
distance
 
measure
 
b
ecause
 
it
is
 
not
 
symmetric:
D
KL
(
P
 

Q
)

=
D
KL
(
Q

P
)
 
for
 
some
P
and
Q
.
 
This
 
asymmetry
means
 
that
 
there
 
are
 
imp
ortan
t
 
consequences
 
to
 
the
 
c
hoice
 
of
 
whether
 
to
 
use
D
KL
(
P
 

Q
)
 
or
 
D
KL
(
Q

P
 
)
.
 
See
 
ﬁgure
 
3.6
 
for
 
more
 
detail.
72


CHAPTER
 
3.
 
PROBABILITY
 
AND
 
INF
ORMA
TION
 
THEOR
Y
0
.
0
 
0
.
2
 
0
.
4
 
0
.
6
 
0
.
8
 
1
.
0
p
0
.
0
0
.
1
0
.
2
0
.
3
0
.
4
0
.
5
0
.
6
0
.
7
Shannon
 
entrop
y
 
in
 
nats
Figure
 
3.5: Shannon
 
en
tropy
 
of
 
a
 
binary
 
random
 
v
ariable. This
 
plot
 
shows
 
how
 
distri-
butions
 
that
 
are
 
closer
 
to
 
deterministic
 
hav
e
 
low
 
Shannon
 
en
trop
y
 
while
 
distributions
that
 
are
 
close
 
to
 
uniform
 
hav
e
 
high
 
Shannon
 
entrop
y
.
 
On
 
the
 
horizontal
 
axis,
 
we
 
plot
p
,
 
the
 
probability
 
of
 
a
 
binary
 
random
 
v
ariable
 
b
eing
 
equal
 
to
 
1
.
 
The
 
entrop
y
 
is
 
given
b
y
 
(
p
 
−
1)
log
(1
−
 
p
)
−
 
p
 
log
 
p
.
 
When
p
is
 
near
 
0,
 
the
 
distribution
 
is
 
nearly
 
deterministic,
b
ecause
 
the
 
random
 
v
ariable
 
is
 
nearly
 
alw
a
ys
 
0.
 
When
p
is
 
near
 
1,
 
the
 
distribution
 
is
nearly
 
deterministic,
 
because
 
the
 
random
 
v
ariable
 
is
 
nearly
 
alwa
ys
 
1.
 
When
p
= 0
.
5
,
 
the
en
trop
y
 
is
 
maximal,
 
b
ecause
 
the
 
distribution
 
is
 
uniform
 
o
v
er
 
the
 
t
w
o
 
outcomes.
A
 
quantit
y
 
that
 
is
 
closely
 
related
 
to
 
the
 
KL
 
divergence
 
is
 
the
cross-en
trop
y
H
(
P
,
 
Q
) =
H
(
P
)
 
+
D
KL
(
P
 

Q
)
,
 
whic
h
 
is
 
similar
 
to
 
the
 
KL
 
div
ergence
 
but
 
lacking
the
 
term
 
on
 
the
 
left:
H
(
P
,
 
Q
) = 
−
E
x
∼
P
log
 
Q
(
x
)
.
 
(3.51)
Minimizing
 
the
 
cross-entrop
y
 
with
 
resp
ect
 
to
Q
is
 
equiv
alent
 
to
 
minimizing
 
the
KL
 
div
ergence,
 
b
ecause
 
Q
 
do
es
 
not
 
participate
 
in
 
the
 
omitted
 
term.
When
 
computing
 
man
y
 
of
 
these
 
quan
tities,
 
it
 
is
 
common
 
to
 
encoun
ter
 
expres-
sions
 
of
 
the
 
form
 
0
log
0
.
 
By
 
con
v
en
tion,
 
in
 
the
 
context
 
of
 
information
 
theory
,
 
we
treat
 
these
 
expressions
 
as
 
lim
x
→
0
x
 
log
 
x
 
= 0
.
3.14
 
Structured
 
Probabilistic
 
Mo
dels
Mac
hine
 
learning
 
algorithms
 
often
 
inv
olv
e
 
probabilit
y
 
distributions
 
ov
er
 
a
 
very
large
 
num
ber
 
of
 
random
 
v
ariables.
 
Often,
 
these
 
probability
 
distributions
 
in
v
olv
e
direct
 
interactions
 
b
et
w
een
 
relatively
 
few
 
v
ariables.
 
Using
 
a
 
single
 
function
 
to
describ
e
 
the
 
entire
 
join
t
 
probabilit
y
 
distribution
 
can
 
b
e
 
v
ery
 
ineﬃcien
t
 
(b
oth
computationally
 
and
 
statistically).
73


CHAPTER
 
3.
 
PROBABILITY
 
AND
 
INF
ORMA
TION
 
THEOR
Y
x
Probability Density
q
∗
= argmin
q
D
KL
(
p

q
)
p
(
x
)
q
∗
(
x
)
x
Probability Density
q
∗
= argmin
q
D
KL
(
q

p
)
p
(
x
)
q
∗
(
x
)
Figure
 
3.6:
 
The
 
KL
 
div
ergence
 
is
 
asymmetric.
 
Suppose
 
we
 
hav
e
 
a
 
distribution
p
(
x
)
 
and
wish
 
to
 
appro
ximate
 
it
 
with
 
another
 
distribution
q
(
x
)
.
 
W
e
 
ha
ve
 
the
 
choice
 
of
 
minimizing
either
D
KL
(
p

q
)
 
or
D
KL
(
q

p
)
.
 
W
e
 
illustrate
 
the
 
eﬀect
 
of
 
this
 
c
hoice
 
using
 
a
 
mixture
 
of
t
wo
 
Gaussians
 
for
p
,
 
and
 
a
 
single
 
Gaussian
 
for
q
. The
 
choice
 
of
 
which
 
direction
 
of
 
the
KL
 
div
ergence
 
to
 
use
 
is
 
problem
 
dep
enden
t.
 
Some
 
applications
 
require
 
an
 
approximation
that
 
usually
 
places
 
high
 
probabilit
y
 
anywhere
 
that
 
the
 
true
 
distribution
 
places
 
high
probabilit
y
,
 
while
 
other
 
applications
 
require
 
an
 
appro
ximation
 
that
 
rarely
 
places
 
high
probabilit
y
 
an
ywhere
 
that
 
the
 
true
 
distribution
 
places
 
low
 
probability
.
 
The
 
choice
 
of
 
the
direction
 
of
 
the
 
KL
 
div
ergence
 
reﬂects
 
whic
h
 
of
 
these
 
considerations
 
takes
 
priority
 
for
 
eac
h
application.
 
(L
eft)
The
 
eﬀect
 
of
 
minimizing
D
KL
(
p

q
)
.
 
In
 
this
 
case,
 
we
 
select
 
a
q
that
 
has
high
 
probabilit
y
 
where
p
has
 
high
 
probability
.
 
When
p
has
 
m
ultiple
 
mo
des,
q
c
ho
oses
 
to
blur
 
the
 
mo
des
 
together,
 
in
 
order
 
to
 
put
 
high
 
probability
 
mass
 
on
 
all
 
of
 
them.
 
(R
ight)
The
eﬀect
 
of
 
minimizing
D
KL
(
q

p
)
.
 
In
 
this
 
case,
 
w
e
 
select
 
a
q
that
 
has
 
low
 
probability
 
where
p
has
 
lo
w
 
probability
.
 
When
p
has
 
m
ultiple
 
mo
des
 
that
 
are
 
suﬃciently
 
widely
 
separated,
 
as
in
 
this
 
ﬁgure,
 
the
 
KL
 
divergence
 
is
 
minimized
 
by
 
c
ho
osing
 
a
 
single
 
mo
de,
 
to
 
av
oid
 
putting
probabilit
y
 
mass
 
in
 
the
 
lo
w-probability
 
areas
 
b
etw
een
 
mo
des
 
of
p
.
 
Here,
 
w
e
 
illustrate
the
 
outcome
 
when
q
is
 
chosen
 
to
 
emphasize
 
the
 
left
 
mo
de.
 
W
e
 
could
 
also
 
hav
e
 
achiev
ed
an
 
equal
 
v
alue
 
of
 
the
 
KL
 
divergence
 
by
 
choosing
 
the
 
right
 
mo
de. If
 
the
 
mo
des
 
are
 
not
separated
 
by
 
a
 
suﬃciently
 
strong
 
low-probabilit
y
 
region,
 
then
 
this
 
direction
 
of
 
the
 
KL
div
ergence
 
can
 
still
 
choose
 
to
 
blur
 
the
 
mo
des.
74


CHAPTER
 
3.
 
PROBABILITY
 
AND
 
INF
ORMA
TION
 
THEOR
Y
Instead
 
of
 
using
 
a
 
single
 
function
 
to
 
represent
 
a
 
probability
 
distribution,
 
we
can
 
split
 
a
 
probability
 
distribution
 
into
 
many
 
factors
 
that
 
we
 
multipl
y
 
together.
F
or
 
example,
 
supp
ose
 
we
 
hav
e
 
three
 
random
 
v
ariables:
a
,
b
and
c
.
 
Supp
ose
 
that
a
inﬂuences
 
the
 
v
alue
 
of
b
,
 
and
b
inﬂuences
 
the
 
v
alue
 
of
c
,
 
but
 
that
a
and
c
are
indep
enden
t
 
giv
en
b
.
 
W
e
 
can
 
represent
 
the
 
probability
 
distribution
 
ov
er
 
all
 
three
v
ariables
 
as
 
a
 
pro
duct
 
of
 
probability
 
distributions
 
ov
er
 
tw
o
 
v
ariables:
p
(
a
,
 
b
,
 
c
) = 
p
(
a
)
p
(
b
 
|
 
a
)
p
(
c
 
|
 
b
)
.
 
(3.52)
These
 
factorizations
 
can
 
greatly
 
reduce
 
the
 
n
um
ber
 
of
 
parameters
 
needed
to
 
describ
e
 
the
 
distribution.
 
Each
 
factor
 
uses
 
a
 
num
ber
 
of
 
parameters
 
that
 
is
exp
onen
tial
 
in
 
the
 
n
um
b
er
 
of
 
v
ariables
 
in
 
the
 
factor.
 
This
 
means
 
that
 
w
e
 
can
 
greatly
reduce
 
the
 
cost
 
of
 
representing
 
a
 
distribution
 
if
 
w
e
 
are
 
able
 
to
 
ﬁnd
 
a
 
factorization
in
to
 
distributions
 
o
v
er
 
fewer
 
v
ariables.
W
e
 
can
 
describ
e
 
these
 
kinds
 
of
 
factorizations
 
using
 
graphs.
 
Here,
 
we
 
use
 
the
w
ord
 
“graph”
 
in
 
the
 
sense
 
of
 
graph
 
theory:
 
a
 
set
 
of
 
vertices
 
that
 
may
 
b
e
 
connected
to
 
eac
h
 
other
 
with
 
edges. When
 
w
e
 
represen
t
 
the
 
factorization
 
of
 
a
 
probabilit
y
distribution
 
with a
 
graph, w
e
 
call
 
it
 
a
structured
 
probabilistic
 
model
, or
graphical
 
mo
del
.
There
 
are
 
t
w
o
 
main
 
kinds
 
of
 
structured
 
probabilistic
 
mo
dels:
 
directed
 
and
undirected.
 
Both
 
kinds
 
of
 
graphical
 
mo
dels
 
use
 
a
 
graph
G
in
 
which
 
eac
h
 
no
de
in
 
the
 
graph corresponds to
 
a
 
random
 
v
ariable, and
 
an
 
edge connecting
 
tw
o
random
 
v
ariables
 
means
 
that
 
the
 
probabilit
y
 
distribution
 
is
 
able
 
to
 
represent
 
direct
in
teractions
 
b
etw
een
 
those
 
tw
o
 
random
 
v
ariables.
Directed
mo
dels
 
use
 
graphs with
 
directed
 
edges, and
 
they represen
t fac-
torizations
 
into
 
conditional
 
probability
 
distributions,
 
as
 
in
 
the
 
example
 
abov
e.
Sp
eciﬁcally
,
 
a
 
directed
 
mo
del
 
contains
 
one
 
factor
 
for
 
every
 
random
 
v
ariable
x
i
in
the
 
distribution,
 
and
 
that
 
factor
 
consists
 
of
 
the
 
conditional
 
distribution
 
ov
er
x
i
giv
en
 
the
 
paren
ts
 
of
 
x
i
,
 
denoted
 
P
 
a
G
(
x
i
)
:
p
(
x
) =

i
p
 
(
x
i
|
 
P
 
a
G
(
x
i
))
 
.
 
(3.53)
See
 
ﬁgure
 
3.7
 
for
 
an
 
example
 
of
 
a
 
directed
 
graph
 
and
 
the
 
factorization
 
of
 
probability
distributions
 
it
 
represen
ts.
Undirected
mo
dels
 
use
 
graphs
 
with
 
undirected
 
edges,
 
and
 
they
 
represen
t
factorizations
 
into
 
a
 
set
 
of
 
functions;
 
unlike
 
in
 
the
 
directed
 
case,
 
these
 
functions
are
 
usually
 
not
 
probability
 
distributions
 
of
 
any
 
kind.
 
An
y
 
set
 
of
 
no
des
 
that
 
are
 
all
connected
 
to
 
each
 
other
 
in
G
is
 
called
 
a
 
clique.
 
Each
 
clique
C
(
i
)
in
 
an
 
undirected
mo
del
 
is
 
asso
ciated
 
with
 
a
 
factor
φ
(
i
)
(
C
(
i
)
)
.
 
These
 
factors
 
are
 
just
 
functions,
 
not
75


CHAPTER
 
3.
 
PROBABILITY
 
AND
 
INF
ORMA
TION
 
THEOR
Y
a
a
c
c
b
b
e
e
d
d
Figure
 
3.7:
 
A
 
directed
 
graphical
 
mo
del
 
ov
er
 
random
 
v
ariables
a
,
b
,
c
,
d
and
e
.
 
This
 
graph
corresp
onds
 
to
 
probability
 
distributions
 
that
 
can
 
b
e
 
factored
 
as
p
(
a
,
 
b
,
 
c
,
 
d
,
 
e
) = 
p
(
a
)
p
(
b
 
|
 
a
)
p
(
c
 
|
 
a
,
 
b
)
p
(
d
 
|
 
b
)
p
(
e
 
|
 
c
)
.
 
(3.54)
This
 
graphical
 
mo
del
 
enables
 
us
 
to
 
quickly
 
see
 
some
 
prop
erties
 
of
 
the
 
distribution.
 
F
or
example,
 
a
 
and
 
c
 
interact
 
directly
,
 
but
 
a
 
and
 
e
 
interact
 
only
 
indirectly
 
via
 
c.
probabilit
y
 
distributions. The
 
output
 
of
 
each
 
factor
 
m
ust
 
be
 
non-negativ
e,
 
but
there
 
is
 
no
 
constraint
 
that
 
the
 
factor
 
must
 
sum
 
or
 
integrate
 
to
 
1
 
like
 
a
 
probability
distribution.
The
 
probability
 
of
 
a
 
conﬁguration
 
of
 
random
 
v
ariables
 
is
prop
ortional
to
 
the
pro
duct
 
of
 
all
 
these
 
factors—assignmen
ts
 
that
 
result
 
in
 
larger
 
factor
 
v
alues
 
are
more
 
lik
ely
.
 
Of
 
course,
 
there
 
is
 
no
 
guarantee
 
that
 
this
 
pro
duct
 
will
 
sum
 
to
 
1.
 
W
e
therefore
 
divide
 
by
 
a
 
normalizing
 
constant
Z
,
 
deﬁned
 
to
 
b
e
 
the
 
sum
 
or
 
integral
o
v
er
 
all
 
states
 
of
 
the
 
pro
duct
 
of
 
the
φ
functions,
 
in
 
order
 
to
 
obtain
 
a
 
normalized
probabilit
y
 
distribution:
p
(
x
) =
1
Z

i
φ
(
i
)

C
(
i
)

.
 
(3.55)
See
 
ﬁgure
 
3.8
 
for
 
an
 
example
 
of
 
an
 
undirected
 
graph
 
and
 
the
 
factorization
 
of
probabilit
y
 
distributions
 
it
 
represen
ts.
Keep in
 
mind that
 
these
 
graphical represen
tations of
 
factorizations are
 
a
language
 
for
 
describing
 
probability
 
distributions.
 
They
 
are
 
not
 
mutually
 
exclusiv
e
families
 
of
 
probabilit
y
 
distributions.
 
Being
 
directed
 
or
 
undirected
 
is
 
not
 
a
 
prop
erty
of
 
a
 
probability
 
distribution;
 
it
 
is
 
a
 
prop
erty
 
of
 
a
 
particular
description
of
 
a
probabilit
y
 
distribution,
 
but
 
any
 
probabilit
y
 
distribution
 
ma
y
 
b
e
 
describ
ed
 
in
 
b
oth
w
a
ys.
Throughout
 
parts
 
I
 
and
 
I
I
 
of
 
this
 
b
o
ok,
 
w
e
 
use
 
structured
 
probabilistic
 
mo
dels
76


CHAPTER
 
3.
 
PROBABILITY
 
AND
 
INF
ORMA
TION
 
THEOR
Y
a
a
c
c
b
b
e
e
d
d
Figure
 
3.8:
 
An
 
undirected
 
graphical
 
model
 
ov
er
 
random
 
v
ariables
a
,
b
,
c
,
d
and
e
.
 
This
graph
 
corresponds
 
to
 
probability
 
distributions
 
that
 
can
 
b
e
 
factored
 
as
p
(
a
,
 
b
,
 
c
,
 
d
,
 
e
) =
1
Z
φ
(1)
(
a
,
 
b
,
 
c
)
φ
(2)
(
b
,
 
d
)
φ
(3)
(
c
,
 
e
)
.
 
(3.56)
This
 
graphical
 
mo
del
 
enables
 
us
 
to
 
quickly
 
see
 
some
 
prop
erties
 
of
 
the
 
distribution.
 
F
or
example,
 
a
 
and
 
c
 
interact
 
directly
,
 
but
 
a
 
and
 
e
 
interact
 
only
 
indirectly
 
via
 
c.
merely
 
as
 
a
 
language
 
to
 
describ
e
 
which
 
direct
 
probabilistic
 
relationships
 
diﬀerent
mac
hine
 
learning
 
algorithms
 
c
ho
ose
 
to
 
represent.
 
No
 
further
 
understanding
 
of
structured
 
probabilistic
 
mo
dels
 
is
 
needed
 
until
 
the
 
discussion
 
of
 
researc
h
 
topics,
 
in
part
 
I
I
I
,
 
where
 
w
e
 
explore
 
structured
 
probabilistic
 
mo
dels
 
in
 
m
uc
h
 
greater
 
detail.
This
 
c
hapter
 
has
 
review
ed
 
the
 
basic
 
concepts
 
of
 
probabilit
y
 
theory
 
that
 
are
most
 
relev
ant
 
to
 
deep
 
learning.
 
One
 
more
 
set
 
of
 
fundamental
 
mathematical
 
to
ols
remains:
 
numerical
 
metho
ds.
77













