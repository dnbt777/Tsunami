







Landauer's principle - Wikipedia
























































Jump to content
















Main menu












Main menu


move to sidebar


hide







		Navigation
	






Main page
Contents
Current events
Random article
About Wikipedia
Contact us
Donate











		Contribute
	






Help
Learn to edit
Community portal
Recent changes
Upload file








































Search
























Search




























































Create account




Log in


















Personal tools












 
Create account
 
Log in











		Pages for logged out editors 
learn more








Contributions
Talk


























































Contents


move to sidebar


hide










(Top)












1


Statement


















2


History


















3


Challenges


















4


See also


















5


References


















6


Further reading


















7


External links






































Toggle the table of contents
















Landauer's principle








16 languages










Català
Deutsch
Español
فارسی
Français
Galego
한국어
Italiano
עברית
日本語
Polski
Português
Русский
Українська
Tiếng Việt
中文




Edit links
























Article
Talk












English




































Read
Edit
View history
















Tools












Tools


move to sidebar


hide







		Actions
	






Read
Edit
View history











		General
	






What links here
Related changes
Upload file
Special pages
Permanent link
Page information
Cite this page
Get shortened URL
Download QR code
Wikidata item











		Print/export
	






Download as PDF
Printable version




















































From Wikipedia, the free encyclopedia






Physical lower limit to energy consumption of computation


Not to be confused with 
Landau principle
.


Landauer's principle
 is a 
physical principle
 pertaining to the lower 
theoretical
 limit of 
energy consumption
 of 
computation
. It holds that an irreversible change in 
information
 stored in a computer, such as merging two computational paths, dissipates a minimum amount of heat to its surroundings.
[1]


The principle was first proposed by 
Rolf Landauer
 in 1961.





Statement
[
edit
]


Landauer's principle states that the minimum energy needed to erase one bit of information is proportional to the temperature at which the system is operating. More specifically, the energy needed for this computational task is given by











E


≥




k




B






T


ln


⁡


2


,






{\displaystyle E\geq k_{\text{B}}T\ln 2,}






where 










k




B










{\displaystyle k_{\text{B}}}




 is the 
Boltzmann constant
.
[2]
 At 
room temperature
, the Landauer limit represents an energy of approximately 0.018 eV (2.9
×
10
−21
 J). Modern computers use about a billion times as much energy per operation.
[3]
[4]




History
[
edit
]


Rolf Landauer first proposed the principle in 1961 while working at 
IBM
.
[5]
 He justified and stated important limits to an earlier conjecture by 
John von Neumann
. For this reason, it is sometimes referred to as being simply the Landauer bound or Landauer limit.

In 2008 and 2009, researchers showed that Landauer's principle can be derived from the 
second law of thermodynamics
 and the entropy change associated with information gain, developing the thermodynamics of quantum and classical feedback-controlled systems.
[6]
[7]


In 2011, the principle was generalized to show that while information erasure requires an increase in entropy, this increase could theoretically occur at no energy cost.
[8]
 Instead, the cost can be taken in another 
conserved quantity
, such as 
angular momentum
.

In a 2012 article published in 
Nature
, a team of physicists from the 
École normale supérieure de Lyon
, 
University of Augsburg
 and the 
University of Kaiserslautern
 described that for the first time they have measured the tiny amount of heat released when an individual bit of data is erased.
[9]


In 2014, physical experiments tested Landauer's principle and confirmed its predictions.
[10]


In 2016, researchers used a laser probe to measure the amount of energy dissipation that resulted when a 
nanomagnetic
 bit flipped from off to on. Flipping the bit required 26 millielectronvolts (4.2 
zeptojoules
).
[11]


A 2018 article published in 
Nature Physics
 features a Landauer erasure performed at cryogenic temperatures 
(
T
 = 1 K)
 on an array of 
high-spin
 (
S
 = 10) quantum 
molecular magnets
. The array is made to act as a spin register where each nanomagnet encodes a single bit of information.
[12]
 The experiment has laid the foundations for the extension of the validity of the Landauer principle to the quantum realm. Owing to the fast dynamics and low "inertia" of the single spins used in the experiment, the researchers also showed how an erasure operation can be carried out at the lowest possible thermodynamic cost—that imposed by the Landauer principle—and at a high speed.
[12]
[1]




Challenges
[
edit
]


The principle is widely accepted as 
physical law
, but in recent years it has been challenged for using 
circular reasoning
 and faulty assumptions, notably in Earman and Norton (1998), and subsequently in Shenker (2000)
[13]
 and Norton (2004,
[14]
 2011
[15]
), and defended by Bennett (2003),
[1]
 Ladyman et al. (2007),
[16]
 and by Jordan and Manikandan (2019).
[17]
 Sagawa and Ueda (2008) and Cao and Feito (2009) have shown that Landauer's principle is a consequence of the second law of Thermodynamics and the entropy reduction associated with information gain.
[6]
[7]


On the other hand, recent advances in non-equilibrium statistical physics have established that there is no a priori relationship between logical and thermodynamic reversibility.
[18]
 It is possible that a physical process is logically reversible but thermodynamically irreversible. It is also possible that a physical process is logically irreversible but thermodynamically reversible. At best, the benefits of implementing a computation with a logically reversible system are nuanced.
[19]


In 2016, researchers at the 
University of Perugia
 claimed to have demonstrated a violation of Landauer’s principle.
[20]
 However, according to Laszlo Kish (2016),
[21]
 their results are invalid because they "neglect the dominant source of energy dissipation, namely, the charging energy of the capacitance of the input electrode".



See also
[
edit
]


Quantum speed limit


Bremermann's limit


Bekenstein bound


Kolmogorov complexity


Entropy in thermodynamics and information theory


Information theory


Jarzynski equality


Limits of computation


Extended mind thesis


Maxwell's demon


Koomey's law


No-deleting theorem


References
[
edit
]






^ 
a
 
b
 
c
 
Charles H. Bennett
 (2003), 
"Notes on Landauer's principle, Reversible Computation and Maxwell's Demon"
 
(PDF)
, 
Studies in History and Philosophy of Modern Physics
, 
34
 (3): 501–510, 
arXiv
:
physics/0210005
, 
Bibcode
:
2003SHPMP..34..501B
, 
doi
:
10.1016/S1355-2198(03)00039-X
, 
S2CID
 
9648186
, retrieved 
2015-02-18
.




^
 
Vitelli, M.B.; Plenio, V. (2001). 
"The physics of forgetting: Landauer's erasure principle and information theory"
 
(PDF)
. 
Contemporary Physics
. 
42
 (1): 25–60. 
arXiv
:
quant-ph/0103108
. 
Bibcode
:
2001ConPh..42...25P
. 
doi
:
10.1080/00107510010018916
. 
eISSN
 
1366-5812
. 
hdl
:
10044/1/435
. 
ISSN
 
0010-7514
. 
S2CID
 
9092795
.




^
 
Thomas J. Thompson. 
"Nanomagnet memories approach low-power limit"
. 
bloomfield knoble
. Archived from 
the original
 on December 19, 2014
. Retrieved 
May 5,
 2013
.




^
 
Samuel K. Moore (14 March 2012). 
"Landauer Limit Demonstrated"
. 
IEEE Spectrum
. Retrieved 
May 5,
 2013
.




^
 
Rolf Landauer (1961), 
"Irreversibility and heat generation in the computing process"
 
(PDF)
, 
IBM Journal of Research and Development
, 
5
 (3): 183–191, 
doi
:
10.1147/rd.53.0183
, retrieved 
2015-02-18
.




^ 
a
 
b
 
Sagawa, Takahiro; Ueda, Masahito (2008-02-26). 
"Second Law of Thermodynamics with Discrete Quantum Feedback Control"
. 
Physical Review Letters
. 
100
 (8): 080403. 
arXiv
:
0710.0956
. 
Bibcode
:
2008PhRvL.100h0403S
. 
doi
:
10.1103/PhysRevLett.100.080403
. 
PMID
 
18352605
. 
S2CID
 
41799543
.




^ 
a
 
b
 
Cao, F. J.; Feito, M. (2009-04-10). 
"Thermodynamics of feedback controlled systems"
. 
Physical Review E
. 
79
 (4): 041118. 
arXiv
:
0805.4824
. 
Bibcode
:
2009PhRvE..79d1118C
. 
doi
:
10.1103/PhysRevE.79.041118
. 
PMID
 
19518184
. 
S2CID
 
30188109
.




^
 
Joan Vaccaro; Stephen Barnett (June 8, 2011), "Information Erasure Without an Energy Cost", 
Proc. R. Soc. A
, 
467
 (2130): 1770–1778, 
arXiv
:
1004.5330
, 
Bibcode
:
2011RSPSA.467.1770V
, 
doi
:
10.1098/rspa.2010.0577
, 
S2CID
 
11768197
.




^
 
Antoine Bérut; Artak Arakelyan; Artyom Petrosyan; Sergio Ciliberto; Raoul Dillenschneider; Eric Lutz (8 March 2012), 
"Experimental verification of Landauer's principle linking information and thermodynamics"
 
(PDF)
, 
Nature
, 
483
 (7388): 187–190, 
arXiv
:
1503.06537
, 
Bibcode
:
2012Natur.483..187B
, 
doi
:
10.1038/nature10872
, 
PMID
 
22398556
, 
S2CID
 
9415026
.




^
 
Yonggun Jun; Momčilo Gavrilov; John Bechhoefer (4 November 2014), "High-Precision Test of Landauer's Principle in a Feedback Trap", 
Physical Review Letters
, 
113
 (19): 190601, 
arXiv
:
1408.5089
, 
Bibcode
:
2014PhRvL.113s0601J
, 
doi
:
10.1103/PhysRevLett.113.190601
, 
PMID
 
25415891
, 
S2CID
 
10164946
.




^
 
Hong, Jeongmin; Lambson, Brian; Dhuey, Scott; 
Bokor, Jeffrey
 (2016-03-01). 
"Experimental test of Landauer's principle in single-bit operations on nanomagnetic memory bits"
. 
Science Advances
. 
2
 (3): e1501492. 
Bibcode
:
2016SciA....2E1492H
. 
doi
:
10.1126/sciadv.1501492
. 
ISSN
 
2375-2548
. 
PMC
 
4795654
. 
PMID
 
26998519
.
.




^ 
a
 
b
 
Rocco Gaudenzi; Enrique Burzuri; Satoru Maegawa; Herre van der Zant; Fernando Luis (19 March 2018), 
"Quantum Landauer erasure with a molecular nanomagnet"
, 
Nature Physics
, 
14
 (6): 565–568, 
Bibcode
:
2018NatPh..14..565G
, 
doi
:
10.1038/s41567-018-0070-7
, 
hdl
:
10261/181265
, 
S2CID
 
125321195
.




^
 
Shenker, Orly R.
 (June 2000). 
"Logic and Entropy [preprint]"
. 
PhilSci Archive
. 
Archived
 from the original on 15 November 2023
. Retrieved 
20 December
 2023
.




^
 
Norton, John D.
 (June 2005). 
"Eaters of the lotus: Landauer's principle and the return of Maxwell's demon"
. 
Studies in History and Philosophy of Science Part B: Studies in History and Philosophy of Modern Physics
. 
36
 (2): 375–411. 
Bibcode
:
2005SHPMP..36..375N
. 
doi
:
10.1016/j.shpsb.2004.12.002
. 
S2CID
 
21104635
. 
Archived
 from the original on 5 June 2023
. Retrieved 
20 December
 2023
.




^
 
Norton, John D.
 (August 2011). 
"Waiting for Landauer"
 
(PDF)
. 
Studies in History and Philosophy of Science Part B: Studies in History and Philosophy of Modern Physics
. 
42
 (3): 184–198. 
Bibcode
:
2011SHPMP..42..184N
. 
doi
:
10.1016/j.shpsb.2011.05.002
. Retrieved 
20 December
 2023
.




^
 
Ladyman, James; Presnell, Stuart; Short, Anthony J.; Groisman, Berry (March 2007). 
"The connection between logical and thermodynamic irreversibility"
. 
Studies in History and Philosophy of Science Part B: Studies in History and Philosophy of Modern Physics
. 
38
 (1): 58–79. 
Bibcode
:
2007SHPMP..38...58L
. 
doi
:
10.1016/j.shpsb.2006.03.007
. Retrieved 
20 December
 2023
.




^
 
Jordan, Andrew; Manikandan, Sreenath (12 December 2019). 
"Some Like It Hot"
. 
Inference: International Review of Science
. 
5
 (1). 
doi
:
10.37282/991819.19.82
. 
S2CID
 
241470079
.




^
 
Takahiro Sagawa (2014), "Thermodynamic and logical reversibilities revisited", 
Journal of Statistical Mechanics: Theory and Experiment
, 
2014
 (3): 03025, 
arXiv
:
1311.1886
, 
Bibcode
:
2014JSMTE..03..025S
, 
doi
:
10.1088/1742-5468/2014/03/P03025
, 
S2CID
 
119247579
.




^
 
David H. Wolpert (2019), "Stochastic thermodynamics of computation", 
Journal of Physics A: Mathematical and Theoretical
, 
52
 (19): 193001, 
arXiv
:
1905.05669
, 
Bibcode
:
2019JPhA...52s3001W
, 
doi
:
10.1088/1751-8121/ab0850
, 
S2CID
 
126715753
.




^
 
"Computing study refutes famous claim that 'information is physical'
"
. 
m.phys.org
.




^
 
Laszlo Bela Kish (2016). 
"Comments on 'Sub-
k
B
T
 Micro-Electromechanical Irreversible Logic Gate'
"
. 
Fluctuation and Noise Letters
. 
14
 (4): 1620001–1620194. 
arXiv
:
1606.09493
. 
Bibcode
:
2016FNL....1520001K
. 
doi
:
10.1142/S0219477516200017
. 
S2CID
 
12110986
. Retrieved 
2020-03-08
.






Further reading
[
edit
]


Prokopenko, Mikhail; Lizier, Joseph T. (2014), "Transfer entropy and transient limits of computation", 
Scientific Reports
, 
4
 (1): 5394, 
Bibcode
:
2014NatSR...4E5394P
, 
doi
:
10.1038/srep05394
, 
PMC
 
4066251
, 
PMID
 
24953547


External links
[
edit
]






Library resources
 about 
 
Landauer's principle
 




Resources in your library


Resources in other libraries






Public debate on the validity of Landauer's principle (conference Hot Topics in Physical Informatics, November 12, 2013)


Introductory article on Landauer's principle and reversible computing


Maroney, O.J.E. "
Information Processing and Thermodynamic Entropy
" The Stanford Encyclopedia of Philosophy.


Eurekalert.org: 
"Magnetic memory and logic could achieve ultimate energy efficiency"
, July 1, 2011


Authority control databases
: National 


Germany












Retrieved from "
https://en.wikipedia.org/w/index.php?title=Landauer%27s_principle&oldid=1226352941
"


Categories
: 
Thermodynamic entropy
Entropy and information
Philosophy of thermal and statistical physics
Principles
Limits of computation
Hidden categories: 
Articles with short description
Short description is different from Wikidata
Articles with GND identifiers














 This page was last edited on 30 May 2024, at 02:47
 (UTC)
.


Text is available under the 
Creative Commons Attribution-ShareAlike License 4.0
;
additional terms may apply. By using this site, you agree to the 
Terms of Use
 and 
Privacy Policy
. Wikipedia® is a registered trademark of the 
Wikimedia Foundation, Inc.
, a non-profit organization.






Privacy policy


About Wikipedia


Disclaimers


Contact Wikipedia


Code of Conduct


Developers


Statistics


Cookie statement


Mobile view




























Toggle limited content width















