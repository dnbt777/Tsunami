





 
[2309.08600] Sparse Autoencoders Find Highly Interpretable Features in Language Models


























































 
 


















Skip to main content












We gratefully acknowledge support from the Simons Foundation, 
member institutions
, and all contributors. 
Donate












 
>
 
cs
 
>
 arXiv:2309.08600
  












Help
 | 
Advanced Search










All fields


Title


Author


Abstract


Comments


Journal reference


ACM classification


MSC classification


Report number


arXiv identifier


DOI


ORCID


arXiv author ID


Help pages


Full text










Search
































open search














GO








open navigation menu






quick links




Login


Help Pages


About


























Computer Science > Machine Learning






arXiv:2309.08600
 (cs)
    









  [Submitted on 15 Sep 2023 (
v1
), last revised 4 Oct 2023 (this version, v3)]


Title:
Sparse Autoencoders Find Highly Interpretable Features in Language Models


Authors:
Hoagy Cunningham
, 
Aidan Ewart
, 
Logan Riggs
, 
Robert Huben
, 
Lee Sharkey
 
View a PDF of the paper titled Sparse Autoencoders Find Highly Interpretable Features in Language Models, by Hoagy Cunningham and 4 other authors


View PDF




Abstract:
One of the roadblocks to a better understanding of neural networks' internals is \textit{polysemanticity}, where neurons appear to activate in multiple, semantically distinct contexts. Polysemanticity prevents us from identifying concise, human-understandable explanations for what neural networks are doing internally. One hypothesised cause of polysemanticity is \textit{superposition}, where neural networks represent more features than they have neurons by assigning features to an overcomplete set of directions in activation space, rather than to individual neurons. Here, we attempt to identify those directions, using sparse autoencoders to reconstruct the internal activations of a language model. These autoencoders learn sets of sparsely activating features that are more interpretable and monosemantic than directions identified by alternative approaches, where interpretability is measured by automated methods. Moreover, we show that with our learned set of features, we can pinpoint the features that are causally responsible for counterfactual behaviour on the indirect object identification task \citep{wang2022interpretability} to a finer degree than previous decompositions. This work indicates that it is possible to resolve superposition in language models using a scalable, unsupervised method. Our method may serve as a foundation for future mechanistic interpretability work, which we hope will enable greater model transparency and steerability.
    






 


Comments:


20 pages, 18 figures, 2 tables






Subjects:




Machine Learning (cs.LG)
; Computation and Language (cs.CL)




Cite as:


arXiv:2309.08600
 [cs.LG]






 


(or 


arXiv:2309.08600v3
 [cs.LG]
 for this version)
          


 


 




https://doi.org/10.48550/arXiv.2309.08600








Focus to learn more









                arXiv-issued DOI via DataCite
              
















Submission history
 From: Robert Huben [
view email
]      
 
[v1]

        Fri, 15 Sep 2023 17:56:55 UTC (3,437 KB)


[v2]

        Tue, 19 Sep 2023 17:20:52 UTC (3,597 KB)


[v3]

        Wed, 4 Oct 2023 13:17:38 UTC (3,684 KB)








 




Full-text links:


Access Paper:





View a PDF of the paper titled Sparse Autoencoders Find Highly Interpretable Features in Language Models, by Hoagy Cunningham and 4 other authors
View PDF
TeX Source
Other Formats






view license






 

    Current browse context: 
cs.LG






< prev




  |  
 


next >






new


 | 


recent


 | 
2023-09



    Change to browse by:
    


cs


cs.CL










References & Citations




NASA ADS
Google Scholar


Semantic Scholar










a


export BibTeX citation


Loading...










BibTeX formatted citation


×






loading...






Data provided by: 










Bookmark












 










Bibliographic Tools




Bibliographic and Citation Tools














Bibliographic Explorer Toggle








Bibliographic Explorer
 
(
What is the Explorer?
)
















Litmaps Toggle








Litmaps
 
(
What is Litmaps?
)
















scite.ai Toggle








scite Smart Citations
 
(
What are Smart Citations?
)


















Code, Data, Media




Code, Data and Media Associated with this Article














Links to Code Toggle








CatalyzeX Code Finder for Papers
 
(
What is CatalyzeX?
)
















DagsHub Toggle








DagsHub
 
(
What is DagsHub?
)
















GotitPub Toggle








Gotit.pub
 
(
What is GotitPub?
)
















Links to Code Toggle








Papers with Code
 
(
What is Papers with Code?
)
















ScienceCast Toggle








ScienceCast
 
(
What is ScienceCast?
)
























Demos




Demos














Replicate Toggle








Replicate
 
(
What is Replicate?
)
















Spaces Toggle








Hugging Face Spaces
 
(
What is Spaces?
)
















Spaces Toggle








TXYZ.AI
 
(
What is TXYZ.AI?
)


















Related Papers




Recommenders and Search Tools














Link to Influence Flower








Influence Flower
 
(
What are Influence Flowers?
)
















Connected Papers Toggle








Connected Papers
 
(
What is Connected Papers?
)
















Core recommender toggle








CORE Recommender
 
(
What is CORE?
)




 










IArxiv recommender toggle








IArxiv Recommender


(
What is IArxiv?
)














Author


Venue


Institution


Topic





























        About arXivLabs
      








arXivLabs: experimental projects with community collaborators


arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.


Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.


Have an idea for a project that will add value for arXiv's community? 
Learn more about arXivLabs
.






















Which authors of this paper are endorsers?
 |
    
Disable MathJax
 (
What is MathJax?
)
    


























About


Help












contact arXiv
Click here to contact arXiv


 Contact






subscribe to arXiv mailings
Click here to subscribe


 Subscribe
























Copyright


Privacy Policy










Web Accessibility Assistance






arXiv Operational Status 

                    Get status notifications via
                    
email

                    or 
slack












 













