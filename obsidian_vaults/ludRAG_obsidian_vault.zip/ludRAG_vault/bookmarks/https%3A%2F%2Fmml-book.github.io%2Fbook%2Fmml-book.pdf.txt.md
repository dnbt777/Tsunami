MATHEMATICS  FOR 
MACHINE LEAR NING
Marc Peter Deisenroth
A. Aldo Faisal
Cheng Soon On g
MATHEMATICS FOR MACHINE LEARNING DEISENROTH ET AL.
The fundamental mathematical tools needed to understand machine 
learning include linear algebra, analytic geometry, matrix decompositions, vector calculus, optimization, probability and statistics. These topics are traditionally taught in disparate courses, making it hard for data science or computer science students, or professionals, to efﬁ  ciently learn the mathematics. This self-contained textbook bridges the gap between mathematical and machine learning texts, introducing the mathematical concepts with a minimum of prerequisites. It uses these concepts to derive four central machine learning methods: linear regression, principal component analysis, Gaussian mixture models and support vector machines. For students and others with a mathematical background, these derivations provide a starting point to machine learning texts. For those learning the mathematics for the ﬁ  rst time, the methods help build intuition and practical experience with applying mathematical concepts. Every chapter includes worked examples and exercises to test understanding. Programming tutorials are offered on the book’s web site.
MARC PETER DEISENROTH  is Senior Lecturer in Statistical Machine 
Learning at the Department of Computing, Împerial College London.
A. ALDO FAISAL  leads the Brain & Behaviour Lab at Imperial College 
London, where he is also Reader in Neurotechnology at the Department of Bioengineering and the Department of Computing.
CHENG SOON ONG  is Principal Research Scientist at the Machine Learning 
Research Group, Data61, CSIRO. He is also Adjunct Associate Professor at Australian National University.
Cover image courtesy of Daniel Bosma / Moment / Getty Images
Cover design by Holly Johnson
Deisenrith et al. 9781108455145 Cover. C M Y K

Contents
Foreword 1
Part I Mathematical Foundations 9
1 Introduction and Motivation 11
1.1 Finding Words for Intuitions 12
1.2 Two Ways to Read This Book 13
1.3 Exercises and Feedback 16
2 Linear Algebra 17
2.1 Systems of Linear Equations 19
2.2 Matrices 22
2.3 Solving Systems of Linear Equations 27
2.4 Vector Spaces 35
2.5 Linear Independence 40
2.6 Basis and Rank 44
2.7 Linear Mappings 48
2.8 Affine Spaces 61
2.9 Further Reading 63
Exercises 64
3 Analytic Geometry 70
3.1 Norms 71
3.2 Inner Products 72
3.3 Lengths and Distances 75
3.4 Angles and Orthogonality 76
3.5 Orthonormal Basis 78
3.6 Orthogonal Complement 79
3.7 Inner Product of Functions 80
3.8 Orthogonal Projections 81
3.9 Rotations 91
3.10 Further Reading 94
Exercises 96
4 Matrix Decompositions 98
4.1 Determinant and Trace 99
i
This material is published by Cambridge University Press as Mathematics for Machine Learning by
Marc Peter Deisenroth, A. Aldo Faisal, and Cheng Soon Ong (2020). This version is free to view
and download for personal use only. Not for re-distribution, re-sale, or use in derivative works.
©by M. P. Deisenroth, A. A. Faisal, and C. S. Ong, 2024. https://mml-book.com .
ii Contents
4.2 Eigenvalues and Eigenvectors 105
4.3 Cholesky Decomposition 114
4.4 Eigendecomposition and Diagonalization 115
4.5 Singular Value Decomposition 119
4.6 Matrix Approximation 129
4.7 Matrix Phylogeny 134
4.8 Further Reading 135
Exercises 137
5 Vector Calculus 139
5.1 Differentiation of Univariate Functions 141
5.2 Partial Differentiation and Gradients 146
5.3 Gradients of Vector-Valued Functions 149
5.4 Gradients of Matrices 155
5.5 Useful Identities for Computing Gradients 158
5.6 Backpropagation and Automatic Differentiation 159
5.7 Higher-Order Derivatives 164
5.8 Linearization and Multivariate Taylor Series 165
5.9 Further Reading 170
Exercises 170
6 Probability and Distributions 172
6.1 Construction of a Probability Space 172
6.2 Discrete and Continuous Probabilities 178
6.3 Sum Rule, Product Rule, and Bayes’ Theorem 183
6.4 Summary Statistics and Independence 186
6.5 Gaussian Distribution 197
6.6 Conjugacy and the Exponential Family 205
6.7 Change of Variables/Inverse Transform 214
6.8 Further Reading 221
Exercises 222
7 Continuous Optimization 225
7.1 Optimization Using Gradient Descent 227
7.2 Constrained Optimization and Lagrange Multipliers 233
7.3 Convex Optimization 236
7.4 Further Reading 246
Exercises 247
Part II Central Machine Learning Problems 249
8 When Models Meet Data 251
8.1 Data, Models, and Learning 251
8.2 Empirical Risk Minimization 258
8.3 Parameter Estimation 265
8.4 Probabilistic Modeling and Inference 272
8.5 Directed Graphical Models 278
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
Contents iii
8.6 Model Selection 283
9 Linear Regression 289
9.1 Problem Formulation 291
9.2 Parameter Estimation 292
9.3 Bayesian Linear Regression 303
9.4 Maximum Likelihood as Orthogonal Projection 313
9.5 Further Reading 315
10 Dimensionality Reduction with Principal Component Analysis 317
10.1 Problem Setting 318
10.2 Maximum Variance Perspective 320
10.3 Projection Perspective 325
10.4 Eigenvector Computation and Low-Rank Approximations 333
10.5 PCA in High Dimensions 335
10.6 Key Steps of PCA in Practice 336
10.7 Latent Variable Perspective 339
10.8 Further Reading 343
11 Density Estimation with Gaussian Mixture Models 348
11.1 Gaussian Mixture Model 349
11.2 Parameter Learning via Maximum Likelihood 350
11.3 EM Algorithm 360
11.4 Latent-Variable Perspective 363
11.5 Further Reading 368
12 Classification with Support Vector Machines 370
12.1 Separating Hyperplanes 372
12.2 Primal Support Vector Machine 374
12.3 Dual Support Vector Machine 383
12.4 Kernels 388
12.5 Numerical Solution 390
12.6 Further Reading 392
References 395
Index 407
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).

Foreword
Machine learning is the latest in a long line of attempts to distill human
knowledge and reasoning into a form that is suitable for constructing ma-
chines and engineering automated systems. As machine learning becomes
more ubiquitous and its software packages become easier to use, it is nat-
ural and desirable that the low-level technical details are abstracted away
and hidden from the practitioner. However, this brings with it the danger
that a practitioner becomes unaware of the design decisions and, hence,
the limits of machine learning algorithms.
The enthusiastic practitioner who is interested to learn more about the
magic behind successful machine learning algorithms currently faces a
daunting set of pre-requisite knowledge:
Programming languages and data analysis tools
Large-scale computation and the associated frameworks
Mathematics and statistics and how machine learning builds on it
At universities, introductory courses on machine learning tend to spend
early parts of the course covering some of these pre-requisites. For histori-
cal reasons, courses in machine learning tend to be taught in the computer
science department, where students are often trained in the first two areas
of knowledge, but not so much in mathematics and statistics.
Current machine learning textbooks primarily focus on machine learn-
ing algorithms and methodologies and assume that the reader is com-
petent in mathematics and statistics. Therefore, these books only spend
one or two chapters on background mathematics, either at the beginning
of the book or as appendices. We have found many people who want to
delve into the foundations of basic machine learning methods who strug-
gle with the mathematical knowledge required to read a machine learning
textbook. Having taught undergraduate and graduate courses at universi-
ties, we find that the gap between high school mathematics and the math-
ematics level required to read a standard machine learning textbook is too
big for many people.
This book brings the mathematical foundations of basic machine learn-
ing concepts to the fore and collects the information in a single place so
that this skills gap is narrowed or even closed.
1
This material is published by Cambridge University Press as Mathematics for Machine Learning by
Marc Peter Deisenroth, A. Aldo Faisal, and Cheng Soon Ong (2020). This version is free to view
and download for personal use only. Not for re-distribution, re-sale, or use in derivative works.
©by M. P. Deisenroth, A. A. Faisal, and C. S. Ong, 2024. https://mml-book.com .
2 Foreword
Why Another Book on Machine Learning?
Machine learning builds upon the language of mathematics to express
concepts that seem intuitively obvious but that are surprisingly difficult
to formalize. Once formalized properly, we can gain insights into the task
we want to solve. One common complaint of students of mathematics
around the globe is that the topics covered seem to have little relevance
to practical problems. We believe that machine learning is an obvious and
direct motivation for people to learn mathematics.
This book is intended to be a guidebook to the vast mathematical lit-
erature that forms the foundations of modern machine learning. We mo- “Math is linked in
the popular mind
with phobia and
anxiety. You’d think
we’re discussing
spiders.” (Strogatz,
2014, page 281)tivate the need for mathematical concepts by directly pointing out their
usefulness in the context of fundamental machine learning problems. In
the interest of keeping the book short, many details and more advanced
concepts have been left out. Equipped with the basic concepts presented
here, and how they fit into the larger context of machine learning, the
reader can find numerous resources for further study, which we provide at
the end of the respective chapters. For readers with a mathematical back-
ground, this book provides a brief but precisely stated glimpse of machine
learning. In contrast to other books that focus on methods and models
of machine learning (MacKay, 2003; Bishop, 2006; Alpaydin, 2010; Bar-
ber, 2012; Murphy, 2012; Shalev-Shwartz and Ben-David, 2014; Rogers
and Girolami, 2016) or programmatic aspects of machine learning (M ¨uller
and Guido, 2016; Raschka and Mirjalili, 2017; Chollet and Allaire, 2018),
we provide only four representative examples of machine learning algo-
rithms. Instead, we focus on the mathematical concepts behind the models
themselves. We hope that readers will be able to gain a deeper understand-
ing of the basic questions in machine learning and connect practical ques-
tions arising from the use of machine learning with fundamental choices
in the mathematical model.
We do not aim to write a classical machine learning book. Instead, our
intention is to provide the mathematical background, applied to four cen-
tral machine learning problems, to make it easier to read other machine
learning textbooks.
Who Is the Target Audience?
As applications of machine learning become widespread in society, we
believe that everybody should have some understanding of its underlying
principles. This book is written in an academic mathematical style, which
enables us to be precise about the concepts behind machine learning. We
encourage readers unfamiliar with this seemingly terse style to persevere
and to keep the goals of each topic in mind. We sprinkle comments and
remarks throughout the text, in the hope that it provides useful guidance
with respect to the big picture.
The book assumes the reader to have mathematical knowledge commonly
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
Foreword 3
covered in high school mathematics and physics. For example, the reader
should have seen derivatives and integrals before, and geometric vectors
in two or three dimensions. Starting from there, we generalize these con-
cepts. Therefore, the target audience of the book includes undergraduate
university students, evening learners and learners participating in online
machine learning courses.
In analogy to music, there are three types of interaction that people
have with machine learning:
Astute Listener The democratization of machine learning by the pro-
vision of open-source software, online tutorials and cloud-based tools al-
lows users to not worry about the specifics of pipelines. Users can focus on
extracting insights from data using off-the-shelf tools. This enables non-
tech-savvy domain experts to benefit from machine learning. This is sim-
ilar to listening to music; the user is able to choose and discern between
different types of machine learning, and benefits from it. More experi-
enced users are like music critics, asking important questions about the
application of machine learning in society such as ethics, fairness, and pri-
vacy of the individual. We hope that this book provides a foundation for
thinking about the certification and risk management of machine learning
systems, and allows them to use their domain expertise to build better
machine learning systems.
Experienced Artist Skilled practitioners of machine learning can plug
and play different tools and libraries into an analysis pipeline. The stereo-
typical practitioner would be a data scientist or engineer who understands
machine learning interfaces and their use cases, and is able to perform
wonderful feats of prediction from data. This is similar to a virtuoso play-
ing music, where highly skilled practitioners can bring existing instru-
ments to life and bring enjoyment to their audience. Using the mathe-
matics presented here as a primer, practitioners would be able to under-
stand the benefits and limits of their favorite method, and to extend and
generalize existing machine learning algorithms. We hope that this book
provides the impetus for more rigorous and principled development of
machine learning methods.
Fledgling Composer As machine learning is applied to new domains,
developers of machine learning need to develop new methods and extend
existing algorithms. They are often researchers who need to understand
the mathematical basis of machine learning and uncover relationships be-
tween different tasks. This is similar to composers of music who, within
the rules and structure of musical theory, create new and amazing pieces.
We hope this book provides a high-level overview of other technical books
for people who want to become composers of machine learning. There is
a great need in society for new researchers who are able to propose and
explore novel approaches for attacking the many challenges of learning
from data.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
4 Foreword
Acknowledgments
We are grateful to many people who looked at early drafts of the book
and suffered through painful expositions of concepts. We tried to imple-
ment their ideas that we did not vehemently disagree with. We would
like to especially acknowledge Christfried Webers for his careful reading
of many parts of the book, and his detailed suggestions on structure and
presentation. Many friends and colleagues have also been kind enough
to provide their time and energy on different versions of each chapter.
We have been lucky to benefit from the generosity of the online commu-
nity, who have suggested improvements via https://github.com , which
greatly improved the book.
The following people have found bugs, proposed clarifications and sug-
gested relevant literature, either via https://github.com or personal
communication. Their names are sorted alphabetically.
Abdul-Ganiy Usman
Adam Gaier
Adele Jackson
Aditya Menon
Alasdair Tran
Aleksandar Krnjaic
Alexander Makrigiorgos
Alfredo Canziani
Ali Shafti
Amr Khalifa
Andrew Tanggara
Angus Gruen
Antal A. Buss
Antoine Toisoul Le Cann
Areg Sarvazyan
Artem Artemev
Artyom Stepanov
Bill Kromydas
Bob Williamson
Boon Ping Lim
Chao Qu
Cheng Li
Chris Sherlock
Christopher Gray
Daniel McNamara
Daniel Wood
Darren Siegel
David Johnston
Dawei ChenEllen Broad
Fengkuangtian Zhu
Fiona Condon
Georgios Theodorou
He Xin
Irene Raissa Kameni
Jakub Nabaglo
James Hensman
Jamie Liu
Jean Kaddour
Jean-Paul Ebejer
Jerry Qiang
Jitesh Sindhare
John Lloyd
Jonas Ngnawe
Jon Martin
Justin Hsi
Kai Arulkumaran
Kamil Dreczkowski
Lily Wang
Lionel Tondji Ngoupeyou
Lydia Kn ¨ufing
Mahmoud Aslan
Mark Hartenstein
Mark van der Wilk
Markus Hegland
Martin Hewing
Matthew Alger
Matthew Lee
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
Foreword 5
Maximus McCann
Mengyan Zhang
Michael Bennett
Michael Pedersen
Minjeong Shin
Mohammad Malekzadeh
Naveen Kumar
Nico Montali
Oscar Armas
Patrick Henriksen
Patrick Wieschollek
Pattarawat Chormai
Paul Kelly
Petros Christodoulou
Piotr Januszewski
Pranav Subramani
Quyu Kong
Ragib Zaman
Rui Zhang
Ryan-Rhys Griffiths
Salomon Kabongo
Samuel Ogunmola
Sandeep Mavadia
Sarvesh Nikumbh
Sebastian Raschka
Senanayak Sesh Kumar Karri
Seung-Heon Baek
Shahbaz ChaudharyShakir Mohamed
Shawn Berry
Sheikh Abdul Raheem Ali
Sheng Xue
Sridhar Thiagarajan
Syed Nouman Hasany
Szymon Brych
Thomas B ¨uhler
Timur Sharapov
Tom Melamed
Vincent Adam
Vincent Dutordoir
Vu Minh
Wasim Aftab
Wen Zhi
Wojciech Stokowiec
Xiaonan Chong
Xiaowei Zhang
Yazhou Hao
Yicheng Luo
Young Lee
Yu Lu
Yun Cheng
Yuxiao Huang
Zac Cranko
Zijian Cao
Zoe Nolan
Contributors through GitHub, whose real names were not listed on their
GitHub profile, are:
SamDataMad
bumptiousmonkey
idoamihai
deepakiiminsad
HorizonP
cs-maillist
kudo23empet
victorBigand
17SKYE
jessjing1995
We are also very grateful to Parameswaran Raman and the many anony-
mous reviewers, organized by Cambridge University Press, who read one
or more chapters of earlier versions of the manuscript, and provided con-
structive criticism that led to considerable improvements. A special men-
tion goes to Dinesh Singh Negi, our LATEX support, for detailed and prompt
advice about LATEX-related issues. Last but not least, we are very grateful
to our editor Lauren Cowles, who has been patiently guiding us through
the gestation process of this book.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
6 Foreword
Table of Symbols
Symbol Typical meaning
a, b, c, α, β, γ Scalars are lowercase
x,y,z Vectors are bold lowercase
A,B,C Matrices are bold uppercase
x⊤,A⊤Transpose of a vector or matrix
A−1Inverse of a matrix
⟨x,y⟩ Inner product of xandy
x⊤y Dot product of xandy
B= (b1,b2,b3)(Ordered) tuple
B= [b1,b2,b3]Matrix of column vectors stacked horizontally
B={b1,b2,b3}Set of vectors (unordered)
Z,N Integers and natural numbers, respectively
R,C Real and complex numbers, respectively
Rnn-dimensional vector space of real numbers
∀x Universal quantifier: for all x
∃x Existential quantifier: there exists x
a:=b a is defined as b
a=:b b is defined as a
a∝b a is proportional to b, i.e., a=constant ·b
g◦f Function composition: “ gafter f”
⇐⇒ If and only if
=⇒ Implies
A,C Sets
a∈ A ais an element of set A
∅ Empty set
A\B A without B: the set of elements in Abut not in B
D Number of dimensions; indexed by d= 1, . . . , D
N Number of data points; indexed by n= 1, . . . , N
Im Identity matrix of size m×m
0m,n Matrix of zeros of size m×n
1m,n Matrix of ones of size m×n
ei Standard/canonical vector (where iis the component that is 1)
dim Dimensionality of vector space
rk(A) Rank of matrix A
Im(Φ) Image of linear mapping Φ
ker(Φ) Kernel (null space) of a linear mapping Φ
span[b1] Span (generating set) of b1
tr(A) Trace of A
det(A) Determinant of A
| · | Absolute value or determinant (depending on context)
∥·∥ Norm; Euclidean, unless specified
λ Eigenvalue or Lagrange multiplier
Eλ Eigenspace corresponding to eigenvalue λ
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
Foreword 7
Symbol Typical meaning
x⊥y Vectors xandyare orthogonal
V Vector space
V⊥Orthogonal complement of vector space VPN
n=1xn Sum of the xn:x1+. . .+xNQN
n=1xn Product of the xn:x1·. . .·xN
θ Parameter vector
∂f
∂xPartial derivative of fwith respect to x
df
dxTotal derivative of fwith respect to x
∇ Gradient
f∗= min xf(x) The smallest function value of f
x∗∈arg min xf(x)The value x∗that minimizes f(note: arg min returns a set of values)
L Lagrangian
L Negative log-likelihood n
k
Binomial coefficient, nchoose k
VX[x] Variance of xwith respect to the random variable X
EX[x] Expectation of xwith respect to the random variable X
Cov X,Y[x,y] Covariance between xandy.
X⊥ ⊥Y|Z X is conditionally independent of Ygiven Z
X∼p Random variable Xis distributed according to p
N µ,Σ
Gaussian distribution with mean µand covariance Σ
Ber(µ) Bernoulli distribution with parameter µ
Bin(N, µ) Binomial distribution with parameters N, µ
Beta(α, β) Beta distribution with parameters α, β
Table of Abbreviations and Acronyms
Acronym Meaning
e.g. Exempli gratia (Latin: for example)
GMM Gaussian mixture model
i.e. Id est (Latin: this means)
i.i.d. Independent, identically distributed
MAP Maximum a posteriori
MLE Maximum likelihood estimation/estimator
ONB Orthonormal basis
PCA Principal component analysis
PPCA Probabilistic principal component analysis
REF Row-echelon form
SPD Symmetric, positive definite
SVM Support vector machine
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).

Part I
Mathematical Foundations
9
This material is published by Cambridge University Press as Mathematics for Machine Learning by
Marc Peter Deisenroth, A. Aldo Faisal, and Cheng Soon Ong (2020). This version is free to view
and download for personal use only. Not for re-distribution, re-sale, or use in derivative works.
©by M. P. Deisenroth, A. A. Faisal, and C. S. Ong, 2024. https://mml-book.com .

1
Introduction and Motivation
Machine learning is about designing algorithms that automatically extract
valuable information from data. The emphasis here is on “automatic”, i.e.,
machine learning is concerned about general-purpose methodologies that
can be applied to many datasets, while producing something that is mean-
ingful. There are three concepts that are at the core of machine learning:
data, a model, and learning.
Since machine learning is inherently data driven, data is at the core data
of machine learning. The goal of machine learning is to design general-
purpose methodologies to extract valuable patterns from data, ideally
without much domain-specific expertise. For example, given a large corpus
of documents (e.g., books in many libraries), machine learning methods
can be used to automatically find relevant topics that are shared across
documents (Hoffman et al., 2010). To achieve this goal, we design mod-
elsthat are typically related to the process that generates data, similar to model
the dataset we are given. For example, in a regression setting, the model
would describe a function that maps inputs to real-valued outputs. To
paraphrase Mitchell (1997): A model is said to learn from data if its per-
formance on a given task improves after the data is taken into account.
The goal is to find good models that generalize well to yet unseen data,
which we may care about in the future. Learning can be understood as a learning
way to automatically find patterns and structure in data by optimizing the
parameters of the model.
While machine learning has seen many success stories, and software is
readily available to design and train rich and flexible machine learning
systems, we believe that the mathematical foundations of machine learn-
ing are important in order to understand fundamental principles upon
which more complicated machine learning systems are built. Understand-
ing these principles can facilitate creating new machine learning solutions,
understanding and debugging existing approaches, and learning about the
inherent assumptions and limitations of the methodologies we are work-
ing with.
11
This material is published by Cambridge University Press as Mathematics for Machine Learning by
Marc Peter Deisenroth, A. Aldo Faisal, and Cheng Soon Ong (2020). This version is free to view
and download for personal use only. Not for re-distribution, re-sale, or use in derivative works.
©by M. P. Deisenroth, A. A. Faisal, and C. S. Ong, 2024. https://mml-book.com .
12 Introduction and Motivation
1.1 Finding Words for Intuitions
A challenge we face regularly in machine learning is that concepts and
words are slippery, and a particular component of the machine learning
system can be abstracted to different mathematical concepts. For example,
the word “algorithm” is used in at least two different senses in the con-
text of machine learning. In the first sense, we use the phrase “machine
learning algorithm” to mean a system that makes predictions based on in-
put data. We refer to these algorithms as predictors . In the second sense, predictor
we use the exact same phrase “machine learning algorithm” to mean a
system that adapts some internal parameters of the predictor so that it
performs well on future unseen input data. Here we refer to this adapta-
tion as training a system. training
This book will not resolve the issue of ambiguity, but we want to high-
light upfront that, depending on the context, the same expressions can
mean different things. However, we attempt to make the context suffi-
ciently clear to reduce the level of ambiguity.
The first part of this book introduces the mathematical concepts and
foundations needed to talk about the three main components of a machine
learning system: data, models, and learning. We will briefly outline these
components here, and we will revisit them again in Chapter 8 once we
have discussed the necessary mathematical concepts.
While not all data is numerical, it is often useful to consider data in
a number format. In this book, we assume that data has already been
appropriately converted into a numerical representation suitable for read-
ing into a computer program. Therefore, we think of data as vectors. As data as vectors
another illustration of how subtle words are, there are (at least) three
different ways to think about vectors: a vector as an array of numbers (a
computer science view), a vector as an arrow with a direction and magni-
tude (a physics view), and a vector as an object that obeys addition and
scaling (a mathematical view).
Amodel is typically used to describe a process for generating data, sim- model
ilar to the dataset at hand. Therefore, good models can also be thought
of as simplified versions of the real (unknown) data-generating process,
capturing aspects that are relevant for modeling the data and extracting
hidden patterns from it. A good model can then be used to predict what
would happen in the real world without performing real-world experi-
ments.
We now come to the crux of the matter, the learning component of learning
machine learning. Assume we are given a dataset and a suitable model.
Training the model means to use the data available to optimize some pa-
rameters of the model with respect to a utility function that evaluates how
well the model predicts the training data. Most training methods can be
thought of as an approach analogous to climbing a hill to reach its peak.
In this analogy, the peak of the hill corresponds to a maximum of some
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
1.2 Two Ways to Read This Book 13
desired performance measure. However, in practice, we are interested in
the model to perform well on unseen data. Performing well on data that
we have already seen (training data) may only mean that we found a
good way to memorize the data. However, this may not generalize well to
unseen data, and, in practical applications, we often need to expose our
machine learning system to situations that it has not encountered before.
Let us summarize the main concepts of machine learning that we cover
in this book:
We represent data as vectors.
We choose an appropriate model, either using the probabilistic or opti-
mization view.
We learn from available data by using numerical optimization methods
with the aim that the model performs well on data not used for training.
1.2 Two Ways to Read This Book
We can consider two strategies for understanding the mathematics for
machine learning:
Bottom-up: Building up the concepts from foundational to more ad-
vanced. This is often the preferred approach in more technical fields,
such as mathematics. This strategy has the advantage that the reader
at all times is able to rely on their previously learned concepts. Unfor-
tunately, for a practitioner many of the foundational concepts are not
particularly interesting by themselves, and the lack of motivation means
that most foundational definitions are quickly forgotten.
Top-down: Drilling down from practical needs to more basic require-
ments. This goal-driven approach has the advantage that the readers
know at all times why they need to work on a particular concept, and
there is a clear path of required knowledge. The downside of this strat-
egy is that the knowledge is built on potentially shaky foundations, and
the readers have to remember a set of words that they do not have any
way of understanding.
We decided to write this book in a modular way to separate foundational
(mathematical) concepts from applications so that this book can be read
in both ways. The book is split into two parts, where Part I lays the math-
ematical foundations and Part II applies the concepts from Part I to a set
of fundamental machine learning problems, which form four pillars of
machine learning as illustrated in Figure 1.1: regression, dimensionality
reduction, density estimation, and classification. Chapters in Part I mostly
build upon the previous ones, but it is possible to skip a chapter and work
backward if necessary. Chapters in Part II are only loosely coupled and
can be read in any order. There are many pointers forward and backward
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
14 Introduction and Motivation
Figure 1.1 The
foundations and
four pillars of
machine learning.
Classiﬁcation  
Density  
Estimation  
Regression  
Dimensionality  
Reduction  
Machine Learning
Vector Calculus Probability & Distributions Optimization
Analytic Geometry Matrix Decomposition Linear Algebra
between the two parts of the book to link mathematical concepts with
machine learning algorithms.
Of course there are more than two ways to read this book. Most readers
learn using a combination of top-down and bottom-up approaches, some-
times building up basic mathematical skills before attempting more com-
plex concepts, but also choosing topics based on applications of machine
learning.
Part I Is about Mathematics
The four pillars of machine learning we cover in this book (see Figure 1.1)
require a solid mathematical foundation, which is laid out in Part I.
We represent numerical data as vectors and represent a table of such
data as a matrix. The study of vectors and matrices is called linear algebra ,
which we introduce in Chapter 2. The collection of vectors as a matrix is linear algebra
also described there.
Given two vectors representing two objects in the real world, we want
to make statements about their similarity. The idea is that vectors that
are similar should be predicted to have similar outputs by our machine
learning algorithm (our predictor). To formalize the idea of similarity be-
tween vectors, we need to introduce operations that take two vectors as
input and return a numerical value representing their similarity. The con-
struction of similarity and distances is central to analytic geometry and is analytic geometry
discussed in Chapter 3.
In Chapter 4, we introduce some fundamental concepts about matri-
ces and matrix decomposition . Some operations on matrices are extremely matrix
decomposition useful in machine learning, and they allow for an intuitive interpretation
of the data and more efficient learning.
We often consider data to be noisy observations of some true underly-
ing signal. We hope that by applying machine learning we can identify the
signal from the noise. This requires us to have a language for quantify-
ing what “noise” means. We often would also like to have predictors that
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
1.2 Two Ways to Read This Book 15
allow us to express some sort of uncertainty, e.g., to quantify the confi-
dence we have about the value of the prediction at a particular test data
point. Quantification of uncertainty is the realm of probability theory and probability theory
is covered in Chapter 6.
To train machine learning models, we typically find parameters that
maximize some performance measure. Many optimization techniques re-
quire the concept of a gradient, which tells us the direction in which to
search for a solution. Chapter 5 is about vector calculus and details the vector calculus
concept of gradients, which we subsequently use in Chapter 7, where we
talk about optimization to find maxima/minima of functions. optimization
Part II Is about Machine Learning
The second part of the book introduces four pillars of machine learning
as shown in Figure 1.1. We illustrate how the mathematical concepts in-
troduced in the first part of the book are the foundation for each pillar.
Broadly speaking, chapters are ordered by difficulty (in ascending order).
In Chapter 8, we restate the three components of machine learning
(data, models, and parameter estimation) in a mathematical fashion. In
addition, we provide some guidelines for building experimental set-ups
that guard against overly optimistic evaluations of machine learning sys-
tems. Recall that the goal is to build a predictor that performs well on
unseen data.
In Chapter 9, we will have a close look at linear regression , where our linear regression
objective is to find functions that map inputs x∈RDto corresponding ob-
served function values y∈R, which we can interpret as the labels of their
respective inputs. We will discuss classical model fitting (parameter esti-
mation) via maximum likelihood and maximum a posteriori estimation,
as well as Bayesian linear regression, where we integrate the parameters
out instead of optimizing them.
Chapter 10 focuses on dimensionality reduction , the second pillar in Fig- dimensionality
reduction ure 1.1, using principal component analysis. The key objective of dimen-
sionality reduction is to find a compact, lower-dimensional representation
of high-dimensional data x∈RD, which is often easier to analyze than
the original data. Unlike regression, dimensionality reduction is only con-
cerned about modeling the data – there are no labels associated with a
data point x.
In Chapter 11, we will move to our third pillar: density estimation . The density estimation
objective of density estimation is to find a probability distribution that de-
scribes a given dataset. We will focus on Gaussian mixture models for this
purpose, and we will discuss an iterative scheme to find the parameters of
this model. As in dimensionality reduction, there are no labels associated
with the data points x∈RD. However, we do not seek a low-dimensional
representation of the data. Instead, we are interested in a density model
that describes the data.
Chapter 12 concludes the book with an in-depth discussion of the fourth
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
16 Introduction and Motivation
pillar: classification . We will discuss classification in the context of support classification
vector machines. Similar to regression (Chapter 9), we have inputs xand
corresponding labels y. However, unlike regression, where the labels were
real-valued, the labels in classification are integers, which requires special
care.
1.3 Exercises and Feedback
We provide some exercises in Part I, which can be done mostly by pen and
paper. For Part II, we provide programming tutorials (jupyter notebooks)
to explore some properties of the machine learning algorithms we discuss
in this book.
We appreciate that Cambridge University Press strongly supports our
aim to democratize education and learning by making this book freely
available for download at
https://mml-book.com
where tutorials, errata, and additional materials can be found. Mistakes
can be reported and feedback provided using the preceding URL.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
2
Linear Algebra
When formalizing intuitive concepts, a common approach is to construct a
set of objects (symbols) and a set of rules to manipulate these objects. This
is known as an algebra . Linear algebra is the study of vectors and certain algebra
rules to manipulate vectors. The vectors many of us know from school are
called “geometric vectors”, which are usually denoted by a small arrow
above the letter, e.g.,− →xand− →y. In this book, we discuss more general
concepts of vectors and use a bold letter to represent them, e.g., xandy.
In general, vectors are special objects that can be added together and
multiplied by scalars to produce another object of the same kind. From
an abstract mathematical viewpoint, any object that satisfies these two
properties can be considered a vector. Here are some examples of such
vector objects:
1. Geometric vectors. This example of a vector may be familiar from high
school mathematics and physics. Geometric vectors – see Figure 2.1(a)
– are directed segments, which can be drawn (at least in two dimen-
sions). Two geometric vectors→x,→ycan be added, such that→x+→y=→z
is another geometric vector. Furthermore, multiplication by a scalar
λ→x,λ∈R, is also a geometric vector. In fact, it is the original vector
scaled by λ. Therefore, geometric vectors are instances of the vector
concepts introduced previously. Interpreting vectors as geometric vec-
tors enables us to use our intuitions about direction and magnitude to
reason about mathematical operations.
2. Polynomials are also vectors; see Figure 2.1(b): Two polynomials can
Figure 2.1
Different types of
vectors. Vectors can
be surprising
objects, including
(a) geometric
vectors
and (b) polynomials.→x→y→x+→y
(a) Geometric vectors.
−2 0 2
x−6−4−2024y (b) Polynomials.
17
This material is published by Cambridge University Press as Mathematics for Machine Learning by
Marc Peter Deisenroth, A. Aldo Faisal, and Cheng Soon Ong (2020). This version is free to view
and download for personal use only. Not for re-distribution, re-sale, or use in derivative works.
©by M. P. Deisenroth, A. A. Faisal, and C. S. Ong, 2024. https://mml-book.com .
18 Linear Algebra
be added together, which results in another polynomial; and they can
be multiplied by a scalar λ∈R, and the result is a polynomial as
well. Therefore, polynomials are (rather unusual) instances of vectors.
Note that polynomials are very different from geometric vectors. While
geometric vectors are concrete “drawings”, polynomials are abstract
concepts. However, they are both vectors in the sense previously de-
scribed.
3. Audio signals are vectors. Audio signals are represented as a series of
numbers. We can add audio signals together, and their sum is a new
audio signal. If we scale an audio signal, we also obtain an audio signal.
Therefore, audio signals are a type of vector, too.
4. Elements of Rn(tuples of nreal numbers) are vectors. Rnis more
abstract than polynomials, and it is the concept we focus on in this
book. For instance,
a=
1
2
3
∈R3(2.1)
is an example of a triplet of numbers. Adding two vectors a,b∈Rn
component-wise results in another vector: a+b=c∈Rn. Moreover,
multiplying a∈Rnbyλ∈Rresults in a scaled vector λa∈Rn.
Considering vectors as elements of Rnhas an additional benefit that Be careful to check
whether array
operations actually
perform vector
operations when
implementing on a
computer.it loosely corresponds to arrays of real numbers on a computer. Many
programming languages support array operations, which allow for con-
venient implementation of algorithms that involve vector operations.
Linear algebra focuses on the similarities between these vector concepts.
We can add them together and multiply them by scalars. We will largelyPavel Grinfeld’s
series on linear
algebra:
http://tinyurl.
com/nahclwm
Gilbert Strang’s
course on linear
algebra:
http://tinyurl.
com/bdfbu8s5
3Blue1Brown series
on linear algebra:
https://tinyurl.
com/h5g4kpsfocus on vectors in Rnsince most algorithms in linear algebra are for-
mulated in Rn. We will see in Chapter 8 that we often consider data to
be represented as vectors in Rn. In this book, we will focus on finite-
dimensional vector spaces, in which case there is a 1:1correspondence
between any kind of vector and Rn. When it is convenient, we will use
intuitions about geometric vectors and consider array-based algorithms.
One major idea in mathematics is the idea of “closure”. This is the ques-
tion: What is the set of all things that can result from my proposed oper-
ations? In the case of vectors: What is the set of vectors that can result by
starting with a small set of vectors, and adding them to each other and
scaling them? This results in a vector space (Section 2.4). The concept of
a vector space and its properties underlie much of machine learning. The
concepts introduced in this chapter are summarized in Figure 2.2.
This chapter is mostly based on the lecture notes and books by Drumm
and Weil (2001), Strang (2003), Hogben (2013), Liesen and Mehrmann
(2015), as well as Pavel Grinfeld’s Linear Algebra series. Other excellent
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
2.1 Systems of Linear Equations 19
Figure 2.2 A mind
map of the concepts
introduced in this
chapter, along with
where they are used
in other parts of the
book.Vector
Vector spaceMatrixChapter 5
Vector calculus
Group
System of
linear equations
Matrix
inverse
Gaussian
eliminationLinear/affine
mappingLinear
independence
Basis
Chapter 10
Dimensionality
reductionChapter 12
ClassificationChapter 3
Analytic geometrycomposesclosure
Abelian
with +represents
represents
solved by solvesproperty ofmaximal set
resources are Gilbert Strang’s Linear Algebra course at MIT and the Linear
Algebra Series by 3Blue1Brown.
Linear algebra plays an important role in machine learning and gen-
eral mathematics. The concepts introduced in this chapter are further ex-
panded to include the idea of geometry in Chapter 3. In Chapter 5, we
will discuss vector calculus, where a principled knowledge of matrix op-
erations is essential. In Chapter 10, we will use projections (to be intro-
duced in Section 3.8) for dimensionality reduction with principal compo-
nent analysis (PCA). In Chapter 9, we will discuss linear regression, where
linear algebra plays a central role for solving least-squares problems.
2.1 Systems of Linear Equations
Systems of linear equations play a central part of linear algebra. Many
problems can be formulated as systems of linear equations, and linear
algebra gives us the tools for solving them.
Example 2.1
A company produces products N1, . . . , N nfor which resources
R1, . . . , R mare required. To produce a unit of product Nj,aijunits of
resource Riare needed, where i= 1, . . . , m andj= 1, . . . , n .
The objective is to find an optimal production plan, i.e., a plan of how
many units xjof product Njshould be produced if a total of biunits of
resource Riare available and (ideally) no resources are left over.
If we produce x1, . . . , x nunits of the corresponding products, we need
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
20 Linear Algebra
a total of
ai1x1+···+ainxn (2.2)
many units of resource Ri. An optimal production plan (x1, . . . , x n)∈Rn,
therefore, has to satisfy the following system of equations:
a11x1+···+a1nxn=b1
...
am1x1+···+amnxn=bm, (2.3)
where aij∈Randbi∈R.
Equation (2.3) is the general form of a system of linear equations , and system of linear
equations x1, . . . , x nare the unknowns of this system. Every n-tuple (x1, . . . , x n)∈
Rnthat satisfies (2.3) is a solution of the linear equation system. solution
Example 2.2
The system of linear equations
x1+x2+x3= 3 (1)
x1−x2+ 2 x3= 2 (2)
2x1 + 3 x3= 1 (3)(2.4)
hasno solution: Adding the first two equations yields 2x1+3x3= 5, which
contradicts the third equation (3).
Let us have a look at the system of linear equations
x1+x2+x3= 3 (1)
x1−x2+ 2 x3= 2 (2)
x2+x3= 2 (3). (2.5)
From the first and third equation, it follows that x1= 1. From (1) +(2),
we get 2x1+ 3x3= 5, i.e., x3= 1. From (3), we then get that x2= 1.
Therefore, (1,1,1)is the only possible and unique solution (verify that
(1,1,1)is a solution by plugging in).
As a third example, we consider
x1+x2+x3= 3 (1)
x1−x2+ 2 x3= 2 (2)
2x1 + 3 x3= 5 (3). (2.6)
Since (1) +(2)=(3), we can omit the third equation (redundancy). From
(1) and (2), we get 2x1= 5−3x3and2x2= 1+ x3. We define x3=a∈R
as a free variable, such that any triplet
5
2−3
2a,1
2+1
2a, a
, a∈R (2.7)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
2.1 Systems of Linear Equations 21
Figure 2.3 The
solution space of a
system of two linear
equations with two
variables can be
geometrically
interpreted as the
intersection of two
lines. Every linear
equation represents
a line.
2x1 4x2= 1
4x1+ 4x2= 5
x1
x2
is a solution of the system of linear equations, i.e., we obtain a solution
set that contains infinitely many solutions.
In general, for a real-valued system of linear equations we obtain either
no, exactly one, or infinitely many solutions. Linear regression (Chapter 9)
solves a version of Example 2.1 when we cannot solve the system of linear
equations.
Remark (Geometric Interpretation of Systems of Linear Equations) .In a
system of linear equations with two variables x1, x2, each linear equation
defines a line on the x1x2-plane. Since a solution to a system of linear
equations must satisfy all equations simultaneously, the solution set is the
intersection of these lines. This intersection set can be a line (if the linear
equations describe the same line), a point, or empty (when the lines are
parallel). An illustration is given in Figure 2.3 for the system
4x1+ 4x2= 5
2x1−4x2= 1(2.8)
where the solution space is the point (x1, x2) = (1 ,1
4). Similarly, for three
variables, each linear equation determines a plane in three-dimensional
space. When we intersect these planes, i.e., satisfy all linear equations at
the same time, we can obtain a solution set that is a plane, a line, a point
or empty (when the planes have no common intersection). ♢
For a systematic approach to solving systems of linear equations, we
will introduce a useful compact notation. We collect the coefficients aij
into vectors and collect the vectors into matrices. In other words, we write
the system from (2.3) in the following form:

a11
...
am1
x1+
a12
...
am2
x2+···+
a1n
...
amn
xn=
b1
...
bm
 (2.9)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
22 Linear Algebra
⇐⇒
a11··· a1n
......
am1···amn

x1
...
xn
=
b1
...
bm
. (2.10)
In the following, we will have a close look at these matrices and de-
fine computation rules. We will return to solving linear equations in Sec-
tion 2.3.
2.2 Matrices
Matrices play a central role in linear algebra. They can be used to com-
pactly represent systems of linear equations, but they also represent linear
functions (linear mappings) as we will see later in Section 2.7. Before we
discuss some of these interesting topics, let us first define what a matrix
is and what kind of operations we can do with matrices. We will see more
properties of matrices in Chapter 4.
Definition 2.1 (Matrix) .With m, n∈Na real-valued (m, n)matrix Ais matrix
anm·n-tuple of elements aij,i= 1, . . . , m ,j= 1, . . . , n , which is ordered
according to a rectangular scheme consisting of mrows and ncolumns:
A=
a11a12··· a1n
a21a22··· a2n
.........
am1am2···amn
, a ij∈R. (2.11)
By convention (1, n)-matrices are called rows and(m,1)-matrices are called row
columns . These special matrices are also called row/column vectors . column
row vector
column vector
Figure 2.4 By
stacking its
columns, a matrix A
can be represented
as a long vector a.
re-shapeA∈R4×2a∈R8Rm×nis the set of all real-valued (m, n)-matrices. A∈Rm×ncan be
equivalently represented as a∈Rmnby stacking all ncolumns of the
matrix into a long vector; see Figure 2.4.
2.2.1 Matrix Addition and Multiplication
The sum of two matrices A∈Rm×n,B∈Rm×nis defined as the element-
wise sum, i.e.,
A+B:=
a11+b11··· a1n+b1n
......
am1+bm1···amn+bmn
∈Rm×n. (2.12)
For matrices A∈Rm×n,B∈Rn×k, the elements cijof the product Note the size of the
matrices. C=AB∈Rm×kare computed as
C =
np.einsum(’il,
lj’, A, B) cij=nX
l=1ailblj, i = 1, . . . , m, j = 1, . . . , k. (2.13)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
2.2 Matrices 23
This means, to compute element cijwe multiply the elements of the ith There are ncolumns
inAandnrows in
Bso that we can
compute ailbljfor
l= 1, . . . , n .
Commonly, the dot
product between
two vectors a,bis
denoted by a⊤bor
⟨a,b⟩.row of Awith the jth column of Band sum them up. Later in Section 3.2,
we will call this the dot product of the corresponding row and column. In
cases, where we need to be explicit that we are performing multiplication,
we use the notation A·Bto denote multiplication (explicitly showing
“·”).
Remark. Matrices can only be multiplied if their “neighboring” dimensions
match. For instance, an n×k-matrix Acan be multiplied with a k×m-
matrix B, but only from the left side:
A|{z}
n×kB|{z}
k×m=C|{z}
n×m(2.14)
The product BAis not defined if m̸=nsince the neighboring dimensions
do not match. ♢
Remark. Matrix multiplication is notdefined as an element-wise operation
on matrix elements, i.e., cij̸=aijbij(even if the size of A,Bwas cho-
sen appropriately). This kind of element-wise multiplication often appears
in programming languages when we multiply (multi-dimensional) arrays
with each other, and is called a Hadamard product . ♢ Hadamard product
Example 2.3
ForA=1 2 3
3 2 1
∈R2×3,B=
0 2
1−1
0 1
∈R3×2, we obtain
AB=1 2 3
3 2 1
0 2
1−1
0 1
=2 3
2 5
∈R2×2, (2.15)
BA=
0 2
1−1
0 1
1 2 3
3 2 1
=
6 4 2
−2 0 2
3 2 1
∈R3×3. (2.16)
Figure 2.5 Even if
both matrix
multiplications AB
andBA are
defined, the
dimensions of the
results can be
different.
From this example, we can already see that matrix multiplication is not
commutative, i.e., AB̸=BA; see also Figure 2.5 for an illustration.
Definition 2.2 (Identity Matrix) .InRn×n, we define the identity matrix
identity matrixIn:=
1 0 ···0···0
0 1 ···0···0
..................
0 0 ···1···0
..................
0 0 ···0···1
∈Rn×n(2.17)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
24 Linear Algebra
as the n×n-matrix containing 1on the diagonal and 0everywhere else.
Now that we defined matrix multiplication, matrix addition and the
identity matrix, let us have a look at some properties of matrices:
associativity
Associativity:
∀A∈Rm×n,B∈Rn×p,C∈Rp×q: (AB)C=A(BC) (2.18)
distributivity
Distributivity:
∀A,B∈Rm×n,C,D∈Rn×p: (A+B)C=AC+BC (2.19a)
A(C+D) =AC+AD (2.19b)
Multiplication with the identity matrix:
∀A∈Rm×n:ImA=AIn=A (2.20)
Note that Im̸=Inform̸=n.
2.2.2 Inverse and Transpose
Definition 2.3 (Inverse) .Consider a square matrix A∈Rn×n. Let matrix A square matrix
possesses the same
number of columns
and rows.B∈Rn×nhave the property that AB =In=BA.Bis called the
inverse ofAand denoted by A−1.
inverseUnfortunately, not every matrix Apossesses an inverse A−1. If this
inverse does exist, Ais called regular /invertible /nonsingular , otherwise regular
invertible
nonsingularsingular /noninvertible . When the matrix inverse exists, it is unique. In Sec-
singular
noninvertibletion 2.3, we will discuss a general way to compute the inverse of a matrix
by solving a system of linear equations.
Remark (Existence of the Inverse of a 2×2-matrix) .Consider a matrix
A:=a11a12
a21a22
∈R2×2. (2.21)
If we multiply Awith
A′:=a22−a12
−a21a11
(2.22)
we obtain
AA′=a11a22−a12a21 0
0 a11a22−a12a21
= (a11a22−a12a21)I.
(2.23)
Therefore,
A−1=1
a11a22−a12a21a22−a12
−a21a11
(2.24)
if and only if a11a22−a12a21̸= 0. In Section 4.1, we will see that a11a22−
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
2.2 Matrices 25
a12a21is the determinant of a 2×2-matrix. Furthermore, we can generally
use the determinant to check whether a matrix is invertible. ♢
Example 2.4 (Inverse Matrix)
The matrices
A=
1 2 1
4 4 5
6 7 7
,B=
−7−7 6
2 1 −1
4 5 −4
 (2.25)
are inverse to each other since AB=I=BA.
Definition 2.4 (Transpose) .ForA∈Rm×nthe matrix B∈Rn×mwith
bij=ajiis called the transpose ofA. We write B=A⊤. transpose
The main diagonal
(sometimes called
“principal diagonal”,
“primary diagonal”,
“leading diagonal”,
or “major diagonal”)
of a matrix Ais the
collection of entries
Aijwhere i=j.In general, A⊤can be obtained by writing the columns of Aas the rows
ofA⊤. The following are important properties of inverses and transposes:
The scalar case of
(2.28) is
1
2+4=1
6̸=1
2+1
4.AA−1=I=A−1A (2.26)
(AB)−1=B−1A−1(2.27)
(A+B)−1̸=A−1+B−1(2.28)
(A⊤)⊤=A (2.29)
(AB)⊤=B⊤A⊤(2.30)
(A+B)⊤=A⊤+B⊤(2.31)
Definition 2.5 (Symmetric Matrix) .A matrix A∈Rn×nissymmetric if symmetric matrix
A=A⊤.
Note that only (n, n)-matrices can be symmetric. Generally, we call
(n, n)-matrices also square matrices because they possess the same num- square matrix
ber of rows and columns. Moreover, if Ais invertible, then so is A⊤, and
(A−1)⊤= (A⊤)−1=:A−⊤.
Remark (Sum and Product of Symmetric Matrices) .The sum of symmet-
ric matrices A,B∈Rn×nis always symmetric. However, although their
product is always defined, it is generally not symmetric:
1 0
0 01 1
1 1
=1 1
0 0
. (2.32)
♢
2.2.3 Multiplication by a Scalar
Let us look at what happens to matrices when they are multiplied by a
scalar λ∈R. LetA∈Rm×nandλ∈R. Then λA=K,Kij=λ aij.
Practically, λscales each element of A. Forλ, ψ∈R, the following holds:
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
26 Linear Algebra
associativityAssociativity:
(λψ)C=λ(ψC),C∈Rm×n
λ(BC) = (λB)C=B(λC) = (BC)λ,B∈Rm×n,C∈Rn×k.
Note that this allows us to move scalar values around.
(λC)⊤=C⊤λ⊤=C⊤λ=λC⊤since λ=λ⊤for all λ∈R.distributivity
Distributivity:
(λ+ψ)C=λC+ψC,C∈Rm×n
λ(B+C) =λB+λC,B,C∈Rm×n
Example 2.5 (Distributivity)
If we define
C:=1 2
3 4
, (2.33)
then for any λ, ψ∈Rwe obtain
(λ+ψ)C=(λ+ψ)1 ( λ+ψ)2
(λ+ψ)3 ( λ+ψ)4
=λ+ψ2λ+ 2ψ
3λ+ 3ψ4λ+ 4ψ
(2.34a)
=λ2λ
3λ4λ
+ψ2ψ
3ψ4ψ
=λC+ψC. (2.34b)
2.2.4 Compact Representations of Systems of Linear Equations
If we consider the system of linear equations
2x1+ 3x2+ 5x3= 1
4x1−2x2−7x3= 8
9x1+ 5x2−3x3= 2(2.35)
and use the rules for matrix multiplication, we can write this equation
system in a more compact form as

2 3 5
4−2−7
9 5 −3

x1
x2
x3
=
1
8
2
. (2.36)
Note that x1scales the first column, x2the second one, and x3the third
one.
Generally, a system of linear equations can be compactly represented in
their matrix form as Ax=b; see (2.3), and the product Axis a (linear)
combination of the columns of A. We will discuss linear combinations in
more detail in Section 2.5.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
2.3 Solving Systems of Linear Equations 27
2.3 Solving Systems of Linear Equations
In (2.3), we introduced the general form of an equation system, i.e.,
a11x1+···+a1nxn=b1
...
am1x1+···+amnxn=bm,(2.37)
where aij∈Randbi∈Rare known constants and xjare unknowns,
i= 1, . . . , m ,j= 1, . . . , n . Thus far, we saw that matrices can be used as
a compact way of formulating systems of linear equations so that we can
writeAx=b, see (2.10). Moreover, we defined basic matrix operations,
such as addition and multiplication of matrices. In the following, we will
focus on solving systems of linear equations and provide an algorithm for
finding the inverse of a matrix.
2.3.1 Particular and General Solution
Before discussing how to generally solve systems of linear equations, let
us have a look at an example. Consider the system of equations
1 0 8 −4
0 1 2 12
x1
x2
x3
x4
=42
8
. (2.38)
The system has two equations and four unknowns. Therefore, in general
we would expect infinitely many solutions. This system of equations is
in a particularly easy form, where the first two columns consist of a 1
and a 0. Remember that we want to find scalars x1, . . . , x 4, such thatP4
i=1xici=b, where we define cito be the ith column of the matrix and
bthe right-hand-side of (2.38). A solution to the problem in (2.38) can
be found immediately by taking 42times the first column and 8times the
second column so that
b=42
8
= 421
0
+ 80
1
. (2.39)
Therefore, a solution is [42,8,0,0]⊤. This solution is called a particular particular solution
solution orspecial solution . However, this is not the only solution of this special solution
system of linear equations. To capture all the other solutions, we need
to be creative in generating 0in a non-trivial way using the columns of
the matrix: Adding 0to our special solution does not change the special
solution. To do so, we express the third column using the first two columns
(which are of this very simple form)
8
2
= 81
0
+ 20
1
(2.40)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
28 Linear Algebra
so that 0= 8c1+ 2c2−1c3+ 0c4and(x1, x2, x3, x4) = (8 ,2,−1,0). In
fact, any scaling of this solution by λ1∈Rproduces the 0vector, i.e.,
1 0 8 −4
0 1 2 12
λ1
8
2
−1
0

=λ1(8c1+ 2c2−c3) =0. (2.41)
Following the same line of reasoning, we express the fourth column of the
matrix in (2.38) using the first two columns and generate another set of
non-trivial versions of 0as
1 0 8 −4
0 1 2 12
λ2
−4
12
0
−1

=λ2(−4c1+ 12c2−c4) =0 (2.42)
for any λ2∈R. Putting everything together, we obtain all solutions of the
equation system in (2.38), which is called the general solution , as the set general solution


x∈R4:x=
42
8
0
0
+λ1
8
2
−1
0
+λ2
−4
12
0
−1
, λ1, λ2∈R

.(2.43)
Remark. The general approach we followed consisted of the following
three steps:
1. Find a particular solution to Ax=b.
2. Find all solutions to Ax=0.
3. Combine the solutions from steps 1. and 2. to the general solution.
Neither the general nor the particular solution is unique. ♢
The system of linear equations in the preceding example was easy to
solve because the matrix in (2.38) has this particularly convenient form,
which allowed us to find the particular and the general solution by in-
spection. However, general equation systems are not of this simple form.
Fortunately, there exists a constructive algorithmic way of transforming
any system of linear equations into this particularly simple form: Gaussian
elimination. Key to Gaussian elimination are elementary transformations
of systems of linear equations, which transform the equation system into
a simple form. Then, we can apply the three steps to the simple form that
we just discussed in the context of the example in (2.38).
2.3.2 Elementary Transformations
Key to solving a system of linear equations are elementary transformations elementary
transformations that keep the solution set the same, but that transform the equation system
into a simpler form:
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
2.3 Solving Systems of Linear Equations 29
Exchange of two equations (rows in the matrix representing the system
of equations)
Multiplication of an equation (row) with a constant λ∈R\{0}
Addition of two equations (rows)
Example 2.6
Fora∈R, we seek all solutions of the following system of equations:
−2x1+ 4 x2−2x3− x4+ 4 x5=−3
4x1−8x2+ 3 x3−3x4+ x5= 2
x1−2x2+ x3− x4+ x5= 0
x1−2x2 −3x4+ 4 x5= a. (2.44)
We start by converting this system of equations into the compact matrix
notation Ax=b. We no longer mention the variables xexplicitly and
build the augmented matrix (in the formA|b
) augmented matrix

−2 4 −2−1 4 −3
4−8 3 −3 1 2
1−2 1 −1 1 0
1−2 0 −3 4 a
Swap with R3
Swap with R1
where we used the vertical line to separate the left-hand side from the
right-hand side in (2.44). We use ⇝to indicate a transformation of the
augmented matrix using elementary transformations. The augmented
matrix
A|b
compactly
represents the
system of linear
equations Ax=b.Swapping Rows 1and3leads to

1−2 1 −1 1 0
4−8 3 −3 1 2
−2 4 −2−1 4 −3
1−2 0 −3 4 a
−4R1
+2R1
−R1
When we now apply the indicated transformations (e.g., subtract Row 1
four times from Row 2), we obtain

1−2 1 −1 1 0
0 0 −1 1 −3 2
0 0 0 −3 6 −3
0 0 −1−2 3 a

−R2−R3
⇝
1−2 1 −1 1 0
0 0 −1 1 −3 2
0 0 0 −3 6 −3
0 0 0 0 0 a+1
·(−1)
·(−1
3)
⇝
1−2 1 −1 1 0
0 0 1 −1 3 −2
0 0 0 1 −2 1
0 0 0 0 0 a+1

©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
30 Linear Algebra
This (augmented) matrix is in a convenient form, the row-echelon form row-echelon form
(REF). Reverting this compact notation back into the explicit notation with
the variables we seek, we obtain
x1−2x2+x3−x4+ x5= 0
x3−x4+ 3 x5= −2
x4−2x5= 1
0 = a+ 1. (2.45)
Only for a=−1this system can be solved. A particular solution is particular solution

x1
x2
x3
x4
x5
=
2
0
−1
1
0
. (2.46)
Thegeneral solution , which captures the set of all possible solutions, is general solution


x∈R5:x=
2
0
−1
1
0
+λ1
2
1
0
0
0
+λ2
2
0
−1
2
1
, λ 1, λ2∈R

.(2.47)
In the following, we will detail a constructive way to obtain a particular
and general solution of a system of linear equations.
Remark (Pivots and Staircase Structure) .The leading coefficient of a row
(first nonzero number from the left) is called the pivot and is always pivot
strictly to the right of the pivot of the row above it. Therefore, any equa-
tion system in row-echelon form always has a “staircase” structure. ♢
Definition 2.6 (Row-Echelon Form) .A matrix is in row-echelon form if row-echelon form
All rows that contain only zeros are at the bottom of the matrix; corre-
spondingly, all rows that contain at least one nonzero element are on
top of rows that contain only zeros.
Looking at nonzero rows only, the first nonzero number from the left
(also called the pivot or the leading coefficient ) is always strictly to the pivot
leading coefficient right of the pivot of the row above it.
In other texts, it is
sometimes required
that the pivot is 1.Remark (Basic and Free Variables) .The variables corresponding to the
pivots in the row-echelon form are called basic variables and the other
basic variable variables are free variables . For example, in (2.45), x1, x3, x4are basic
free variable variables, whereas x2, x5are free variables. ♢
Remark (Obtaining a Particular Solution) .The row-echelon form makes
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
2.3 Solving Systems of Linear Equations 31
our lives easier when we need to determine a particular solution. To do
this, we express the right-hand side of the equation system using the pivot
columns, such that b=PP
i=1λipi, where pi, i= 1, . . . , P , are the pivot
columns. The λiare determined easiest if we start with the rightmost pivot
column and work our way to the left.
In the previous example, we would try to find λ1, λ2, λ3so that
λ1
1
0
0
0
+λ2
1
1
0
0
+λ3
−1
−1
1
0
=
0
−2
1
0
. (2.48)
From here, we find relatively directly that λ3= 1, λ2=−1, λ1= 2. When
we put everything together, we must not forget the non-pivot columns
for which we set the coefficients implicitly to 0. Therefore, we get the
particular solution x= [2,0,−1,1,0]⊤. ♢
Remark (Reduced Row Echelon Form) .An equation system is in reduced reduced
row-echelon form row-echelon form (also: row-reduced echelon form orrow canonical form ) if
It is in row-echelon form.
Every pivot is 1.
The pivot is the only nonzero entry in its column.
♢
The reduced row-echelon form will play an important role later in Sec-
tion 2.3.3 because it allows us to determine the general solution of a sys-
tem of linear equations in a straightforward way.Gaussian
elimination Remark (Gaussian Elimination) . Gaussian elimination is an algorithm that
performs elementary transformations to bring a system of linear equations
into reduced row-echelon form. ♢
Example 2.7 (Reduced Row Echelon Form)
Verify that the following matrix is in reduced row-echelon form (the pivots
are in bold):
A=
13 0 0 3
0 0 10 9
0 0 0 1−4
. (2.49)
The key idea for finding the solutions of Ax=0is to look at the non-
pivot columns , which we will need to express as a (linear) combination of
the pivot columns. The reduced row echelon form makes this relatively
straightforward, and we express the non-pivot columns in terms of sums
and multiples of the pivot columns that are on their left: The second col-
umn is 3times the first column (we can ignore the pivot columns on the
right of the second column). Therefore, to obtain 0, we need to subtract
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
32 Linear Algebra
the second column from three times the first column. Now, we look at the
fifth column, which is our second non-pivot column. The fifth column can
be expressed as 3times the first pivot column, 9times the second pivot
column, and −4times the third pivot column. We need to keep track of
the indices of the pivot columns and translate this into 3times the first col-
umn, 0times the second column (which is a non-pivot column), 9times
the third column (which is our second pivot column), and −4times the
fourth column (which is the third pivot column). Then we need to subtract
the fifth column to obtain 0. In the end, we are still solving a homogeneous
equation system.
To summarize, all solutions of Ax=0,x∈R5are given by


x∈R5:x=λ1
3
−1
0
0
0
+λ2
3
0
9
−4
−1
, λ 1, λ2∈R

. (2.50)
2.3.3 The Minus-1 Trick
In the following, we introduce a practical trick for reading out the solu-
tionsxof a homogeneous system of linear equations Ax=0, where
A∈Rk×n,x∈Rn.
To start, we assume that Ais in reduced row-echelon form without any
rows that just contain zeros, i.e.,
A=
0···01∗ ··· ∗ 0∗ ··· ∗ 0∗ ··· ∗
......0 0 ···01∗ ··· ∗.........
...............0...............
........................0......
0···0 0 0 ···0 0 0 ···01∗ ··· ∗
,
(2.51)
where ∗can be an arbitrary real number, with the constraints that the first
nonzero entry per row must be 1and all other entries in the corresponding
column must be 0. The columns j1, . . . , j kwith the pivots (marked in
bold) are the standard unit vectors e1, . . . ,ek∈Rk. We extend this matrix
to an n×n-matrix ˜Aby adding n−krows of the form
0···0−1 0 ···0
(2.52)
so that the diagonal of the augmented matrix ˜Acontains either 1or−1.
Then, the columns of ˜Athat contain the −1as pivots are solutions of
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
2.3 Solving Systems of Linear Equations 33
the homogeneous equation system Ax=0. To be more precise, these
columns form a basis (Section 2.6.1) of the solution space of Ax=0,
which we will later call the kernel ornull space (see Section 2.7.3). kernel
null space
Example 2.8 (Minus-1 Trick)
Let us revisit the matrix in (2.49), which is already in reduced REF:
A=
1 3 0 0 3
0 0 1 0 9
0 0 0 1 −4
. (2.53)
We now augment this matrix to a 5×5matrix by adding rows of the
form (2.52) at the places where the pivots on the diagonal are missing
and obtain
˜A=
1 3 0 0 3
0−10 0 0
0 0 1 0 9
0 0 0 1 −4
0 0 0 0 −1
. (2.54)
From this form, we can immediately read out the solutions of Ax=0by
taking the columns of ˜A, which contain −1on the diagonal:


x∈R5:x=λ1
3
−1
0
0
0
+λ2
3
0
9
−4
−1
, λ 1, λ2∈R

, (2.55)
which is identical to the solution in (2.50) that we obtained by “insight”.
Calculating the Inverse
To compute the inverse A−1ofA∈Rn×n, we need to find a matrix X
that satisfies AX =In. Then, X=A−1. We can write this down as
a set of simultaneous linear equations AX =In, where we solve for
X= [x1|···|xn]. We use the augmented matrix notation for a compact
representation of this set of systems of linear equations and obtain
A|In
⇝···⇝In|A−1. (2.56)
This means that if we bring the augmented equation system into reduced
row-echelon form, we can read out the inverse on the right-hand side of
the equation system. Hence, determining the inverse of a matrix is equiv-
alent to solving systems of linear equations.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
34 Linear Algebra
Example 2.9 (Calculating an Inverse Matrix by Gaussian Elimination)
To determine the inverse of
A=
1 0 2 0
1 1 0 0
1 2 0 1
1 1 1 1
(2.57)
we write down the augmented matrix

1 0 2 0 1 0 0 0
1 1 0 0 0 1 0 0
1 2 0 1 0 0 1 0
1 1 1 1 0 0 0 1

and use Gaussian elimination to bring it into reduced row-echelon form

1 0 0 0 −1 2 −2 2
0 1 0 0 1−1 2 −2
0 0 1 0 1−1 1 −1
0 0 0 1 −1 0 −1 2
,
such that the desired inverse is given as its right-hand side:
A−1=
−1 2 −2 2
1−1 2 −2
1−1 1 −1
−1 0 −1 2
. (2.58)
We can verify that (2.58) is indeed the inverse by performing the multi-
plication AA−1and observing that we recover I4.
2.3.4 Algorithms for Solving a System of Linear Equations
In the following, we briefly discuss approaches to solving a system of lin-
ear equations of the form Ax=b. We make the assumption that a solu-
tion exists. Should there be no solution, we need to resort to approximate
solutions, which we do not cover in this chapter. One way to solve the ap-
proximate problem is using the approach of linear regression, which we
discuss in detail in Chapter 9.
In special cases, we may be able to determine the inverse A−1, such
that the solution of Ax=bis given as x=A−1b. However, this is
only possible if Ais a square matrix and invertible, which is often not the
case. Otherwise, under mild assumptions (i.e., Aneeds to have linearly
independent columns) we can use the transformation
Ax=b⇐⇒A⊤Ax=A⊤b⇐⇒x= (A⊤A)−1A⊤b (2.59)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
2.4 Vector Spaces 35
and use the Moore-Penrose pseudo-inverse (A⊤A)−1A⊤to determine the Moore-Penrose
pseudo-inverse solution (2.59) that solves Ax=b, which also corresponds to the mini-
mum norm least-squares solution. A disadvantage of this approach is that
it requires many computations for the matrix-matrix product and comput-
ing the inverse of A⊤A. Moreover, for reasons of numerical precision it
is generally not recommended to compute the inverse or pseudo-inverse.
In the following, we therefore briefly discuss alternative approaches to
solving systems of linear equations.
Gaussian elimination plays an important role when computing deter-
minants (Section 4.1), checking whether a set of vectors is linearly inde-
pendent (Section 2.5), computing the inverse of a matrix (Section 2.2.2),
computing the rank of a matrix (Section 2.6.2), and determining a basis
of a vector space (Section 2.6.1). Gaussian elimination is an intuitive and
constructive way to solve a system of linear equations with thousands of
variables. However, for systems with millions of variables, it is impracti-
cal as the required number of arithmetic operations scales cubically in the
number of simultaneous equations.
In practice, systems of many linear equations are solved indirectly, by ei-
ther stationary iterative methods, such as the Richardson method, the Ja-
cobi method, the Gauß-Seidel method, and the successive over-relaxation
method, or Krylov subspace methods, such as conjugate gradients, gener-
alized minimal residual, or biconjugate gradients. We refer to the books
by Stoer and Burlirsch (2002), Strang (2003), and Liesen and Mehrmann
(2015) for further details.
Letx∗be a solution of Ax=b. The key idea of these iterative methods
is to set up an iteration of the form
x(k+1)=Cx(k)+d (2.60)
for suitable Canddthat reduces the residual error ∥x(k+1)−x∗∥in every
iteration and converges to x∗. We will introduce norms ∥ · ∥, which allow
us to compute similarities between vectors, in Section 3.1.
2.4 Vector Spaces
Thus far, we have looked at systems of linear equations and how to solve
them (Section 2.3). We saw that systems of linear equations can be com-
pactly represented using matrix-vector notation (2.10). In the following,
we will have a closer look at vector spaces, i.e., a structured space in which
vectors live.
In the beginning of this chapter, we informally characterized vectors as
objects that can be added together and multiplied by a scalar, and they
remain objects of the same type. Now, we are ready to formalize this,
and we will start by introducing the concept of a group, which is a set
of elements and an operation defined on these elements that keeps some
structure of the set intact.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
36 Linear Algebra
2.4.1 Groups
Groups play an important role in computer science. Besides providing a
fundamental framework for operations on sets, they are heavily used in
cryptography, coding theory, and graphics.
Definition 2.7 (Group) .Consider a set Gand an operation ⊗:G×G → G
defined on G. Then G:= (G,⊗)is called a group if the following hold: group
closure1.Closure ofGunder ⊗:∀x, y∈ G:x⊗y∈ Gassociativity
2.Associativity: ∀x, y, z ∈ G: (x⊗y)⊗z=x⊗(y⊗z)neutral element
3.Neutral element: ∃e∈ G ∀ x∈ G:x⊗e=xande⊗x=x inverse element
4.Inverse element: ∀x∈ G ∃ y∈ G:x⊗y=eandy⊗x=e, where eis
the neutral element. We often write x−1to denote the inverse element
ofx.
Remark. The inverse element is defined with respect to the operation ⊗
and does not necessarily mean1
x. ♢
If additionally ∀x, y∈ G:x⊗y=y⊗x, then G= (G,⊗)is an Abelian Abelian group
group (commutative).
Example 2.10 (Groups)
Let us have a look at some examples of sets with associated operations
and see whether they are groups:
(Z,+)is an Abelian group.
(N0,+)is not a group: Although (N0,+)possesses a neutral element N0:=N∪ {0}
(0), the inverse elements are missing.
(Z,·)is not a group: Although (Z,·)contains a neutral element ( 1), the
inverse elements for any z∈Z, z̸=±1, are missing.
(R,·)is not a group since 0does not possess an inverse element.
(R\{0},·)is Abelian.
(Rn,+),(Zn,+), n∈Nare Abelian if +is defined componentwise, i.e.,
(x1,···, xn) + (y1,···, yn) = (x1+y1,···, xn+yn). (2.61)
Then, (x1,···, xn)−1:= (−x1,···,−xn)is the inverse element and
e= (0,···,0)is the neutral element.
(Rm×n,+), the set of m×n-matrices is Abelian (with componentwise
addition as defined in (2.61)).
Let us have a closer look at (Rn×n,·), i.e., the set of n×n-matrices with
matrix multiplication as defined in (2.13).
–Closure and associativity follow directly from the definition of matrix
multiplication.
–Neutral element: The identity matrix Inis the neutral element with
respect to matrix multiplication “ ·” in(Rn×n,·).
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
2.4 Vector Spaces 37
–Inverse element: If the inverse exists ( Ais regular), then A−1is the
inverse element of A∈Rn×n, and in exactly this case (Rn×n,·)is a
group, called the general linear group .
Definition 2.8 (General Linear Group) .The set of regular (invertible)
matrices A∈Rn×nis a group with respect to matrix multiplication as
defined in (2.13) and is called general linear group GL(n,R). However, general linear group
since matrix multiplication is not commutative, the group is not Abelian.
2.4.2 Vector Spaces
When we discussed groups, we looked at sets Gand inner operations on
G, i.e., mappings G × G → G that only operate on elements in G. In the
following, we will consider sets that in addition to an inner operation +
also contain an outer operation ·, the multiplication of a vector x∈ Gby
a scalar λ∈R. We can think of the inner operation as a form of addition,
and the outer operation as a form of scaling. Note that the inner/outer
operations have nothing to do with inner/outer products.
Definition 2.9 (Vector Space) .A real-valued vector space V= (V,+,·)is vector space
a setVwith two operations
+ :V × V → V (2.62)
·:R× V → V (2.63)
where
1.(V,+)is an Abelian group
2. Distributivity:
1.∀λ∈R,x,y∈ V:λ·(x+y) =λ·x+λ·y
2.∀λ, ψ∈R,x∈ V: (λ+ψ)·x=λ·x+ψ·x
3. Associativity (outer operation): ∀λ, ψ∈R,x∈ V:λ·(ψ·x) = (λψ)·x
4. Neutral element with respect to the outer operation: ∀x∈ V: 1·x=x
The elements x∈Vare called vectors . The neutral element of (V,+)is vector
the zero vector 0= [0, . . . , 0]⊤, and the inner operation +is called vector vector addition
addition . The elements λ∈Rare called scalars and the outer operation scalar
·is amultiplication by scalars . Note that a scalar product is something multiplication by
scalars different, and we will get to this in Section 3.2.
Remark. A “vector multiplication” ab,a,b∈Rn, is not defined. Theoret-
ically, we could define an element-wise multiplication, such that c=ab
withcj=ajbj. This “array multiplication” is common to many program-
ming languages but makes mathematically limited sense using the stan-
dard rules for matrix multiplication: By treating vectors as n×1matrices
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
38 Linear Algebra
(which we usually do), we can use the matrix multiplication as defined
in (2.13). However, then the dimensions of the vectors do not match. Only
the following multiplications for vectors are defined: ab⊤∈Rn×n(outer outer product
product ),a⊤b∈R(inner/scalar/dot product). ♢
Example 2.11 (Vector Spaces)
Let us have a look at some important examples:
V=Rn, n∈Nis a vector space with operations defined as follows:
–Addition: x+y= (x1, . . . , x n)+(y1, . . . , y n) = (x1+y1, . . . , x n+yn)
for all x,y∈Rn
–Multiplication by scalars: λx=λ(x1, . . . , x n) = ( λx1, . . . , λx n)for
allλ∈R,x∈Rn
V=Rm×n, m, n ∈Nis a vector space with
–Addition: A+B=
a11+b11··· a1n+b1n
......
am1+bm1···amn+bmn
is defined ele-
mentwise for all A,B∈ V
–Multiplication by scalars: λA=
λa11··· λa1n
......
λam1···λamn
as defined in
Section 2.2. Remember that Rm×nis equivalent to Rmn.
V=C, with the standard definition of addition of complex numbers.
Remark. In the following, we will denote a vector space (V,+,·)byV
when +and·are the standard vector addition and scalar multiplication.
Moreover, we will use the notation x∈Vfor vectors in Vto simplify
notation. ♢
Remark. The vector spaces Rn,Rn×1,R1×nare only different in the way
we write vectors. In the following, we will not make a distinction between
RnandRn×1, which allows us to write n-tuples as column vectors column vector
x=
x1
...
xn
. (2.64)
This simplifies the notation regarding vector space operations. However,
we do distinguish between Rn×1andR1×n(therow vectors ) to avoid con- row vector
fusion with matrix multiplication. By default, we write xto denote a col-
umn vector, and a row vector is denoted by x⊤, the transpose ofx.♢ transpose
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
2.4 Vector Spaces 39
2.4.3 Vector Subspaces
In the following, we will introduce vector subspaces. Intuitively, they are
sets contained in the original vector space with the property that when
we perform vector space operations on elements within this subspace, we
will never leave it. In this sense, they are “closed”. Vector subspaces are a
key idea in machine learning. For example, Chapter 10 demonstrates how
to use vector subspaces for dimensionality reduction.
Definition 2.10 (Vector Subspace) .LetV= (V,+,·)be a vector space
andU ⊆ V ,U ̸=∅. Then U= (U,+,·)is called vector subspace ofV(or vector subspace
linear subspace ) ifUis a vector space with the vector space operations + linear subspace
and·restricted to U ×U andR×U. We write U⊆Vto denote a subspace
UofV.
IfU ⊆ V andVis a vector space, then Unaturally inherits many prop-
erties directly from Vbecause they hold for all x∈ V, and in particular for
allx∈ U ⊆ V . This includes the Abelian group properties, the distribu-
tivity, the associativity and the neutral element. To determine whether
(U,+,·)is a subspace of Vwe still do need to show
1.U ̸=∅, in particular: 0∈ U
2. Closure of U:
a. With respect to the outer operation: ∀λ∈R∀x∈ U:λx∈ U.
b. With respect to the inner operation: ∀x,y∈ U:x+y∈ U.
Example 2.12 (Vector Subspaces)
Let us have a look at some examples:
For every vector space V, the trivial subspaces are Vitself and {0}.
Only example Din Figure 2.6 is a subspace of R2(with the usual inner/
outer operations). In AandC, the closure property is violated; Bdoes
not contain 0.
The solution set of a homogeneous system of linear equations Ax=0
withnunknowns x= [x1, . . . , x n]⊤is a subspace of Rn.
The solution of an inhomogeneous system of linear equations Ax=
b,b̸=0is not a subspace of Rn.
The intersection of arbitrarily many subspaces is a subspace itself.
Figure 2.6 Not all
subsets of R2are
subspaces. In Aand
C, the closure
property is violated;
Bdoes not contain
0. Only Dis a
subspace.0 0 0 0AB
CD
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
40 Linear Algebra
Remark. Every subspace U⊆(Rn,+,·)is the solution space of a homo-
geneous system of linear equations Ax=0forx∈Rn. ♢
2.5 Linear Independence
In the following, we will have a close look at what we can do with vectors
(elements of the vector space). In particular, we can add vectors together
and multiply them with scalars. The closure property guarantees that we
end up with another vector in the same vector space. It is possible to find
a set of vectors with which we can represent every vector in the vector
space by adding them together and scaling them. This set of vectors is
abasis, and we will discuss them in Section 2.6.1. Before we get there,
we will need to introduce the concepts of linear combinations and linear
independence.
Definition 2.11 (Linear Combination) .Consider a vector space Vand a
finite number of vectors x1, . . . ,xk∈V. Then, every v∈Vof the form
v=λ1x1+···+λkxk=kX
i=1λixi∈V (2.65)
withλ1, . . . , λ k∈Ris alinear combination of the vectors x1, . . . ,xk. linear combination
The0-vector can always be written as the linear combination of kvec-
torsx1, . . . ,xkbecause 0=Pk
i=10xiis always true. In the following,
we are interested in non-trivial linear combinations of a set of vectors to
represent 0, i.e., linear combinations of vectors x1, . . . ,xk, where not all
coefficients λiin (2.65) are 0.
Definition 2.12 (Linear (In)dependence) .Let us consider a vector space
Vwith k∈Nandx1, . . . ,xk∈V. If there is a non-trivial linear com-
bination, such that 0=Pk
i=1λixiwith at least one λi̸= 0, the vectors
x1, . . . ,xkarelinearly dependent . If only the trivial solution exists, i.e., linearly dependent
λ1=. . .=λk= 0the vectors x1, . . . ,xkarelinearly independent . linearly
independent
Linear independence is one of the most important concepts in linear
algebra. Intuitively, a set of linearly independent vectors consists of vectors
that have no redundancy, i.e., if we remove any of those vectors from
the set, we will lose something. Throughout the next sections, we will
formalize this intuition more.
Example 2.13 (Linearly Dependent Vectors)
A geographic example may help to clarify the concept of linear indepen-
dence. A person in Nairobi (Kenya) describing where Kigali (Rwanda) is
might say ,“You can get to Kigali by first going 506 km Northwest to Kam-
pala (Uganda) and then 374 km Southwest.”. This is sufficient information
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
2.5 Linear Independence 41
to describe the location of Kigali because the geographic coordinate sys-
tem may be considered a two-dimensional vector space (ignoring altitude
and the Earth’s curved surface). The person may add, “It is about 751 km
West of here.” Although this last statement is true, it is not necessary to
find Kigali given the previous information (see Figure 2.7 for an illus-
tration). In this example, the “ 506 km Northwest” vector (blue) and the
“374 km Southwest” vector (purple) are linearly independent. This means
the Southwest vector cannot be described in terms of the Northwest vec-
tor, and vice versa. However, the third “ 751 km West” vector (black) is a
linear combination of the other two vectors, and it makes the set of vec-
tors linearly dependent. Equivalently, given “ 751 km West” and “ 374 km
Southwest” can be linearly combined to obtain “ 506 km Northwest”.
Figure 2.7
Geographic example
(with crude
approximations to
cardinal directions)
of linearly
dependent vectors
in a
two-dimensional
space (plane).
506 km Northwest
751 km West
374 km Southwest
374 km Southwest
Kampala
Nairobi
Kigali
Remark. The following properties are useful to find out whether vectors
are linearly independent:
kvectors are either linearly dependent or linearly independent. There
is no third option.
If at least one of the vectors x1, . . . ,xkis0then they are linearly de-
pendent. The same holds if two vectors are identical.
The vectors {x1, . . . ,xk:xi̸=0, i= 1, . . . , k },k⩾2, are linearly
dependent if and only if (at least) one of them is a linear combination
of the others. In particular, if one vector is a multiple of another vector,
i.e.,xi=λxj, λ∈Rthen the set {x1, . . . ,xk:xi̸=0, i= 1, . . . , k }
is linearly dependent.
A practical way of checking whether vectors x1, . . . ,xk∈Vare linearly
independent is to use Gaussian elimination: Write all vectors as columns
of a matrix Aand perform Gaussian elimination until the matrix is in
row echelon form (the reduced row-echelon form is unnecessary here):
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
42 Linear Algebra
–The pivot columns indicate the vectors, which are linearly indepen-
dent of the vectors on the left. Note that there is an ordering of vec-
tors when the matrix is built.
–The non-pivot columns can be expressed as linear combinations of
the pivot columns on their left. For instance, the row-echelon form
1 3 0
0 0 2
(2.66)
tells us that the first and third columns are pivot columns. The sec-
ond column is a non-pivot column because it is three times the first
column.
All column vectors are linearly independent if and only if all columns
are pivot columns. If there is at least one non-pivot column, the columns
(and, therefore, the corresponding vectors) are linearly dependent.
♢
Example 2.14
Consider R4with
x1=
1
2
−3
4
,x2=
1
1
0
2
,x3=
−1
−2
1
1
. (2.67)
To check whether they are linearly dependent, we follow the general ap-
proach and solve
λ1x1+λ2x2+λ3x3=λ1
1
2
−3
4
+λ2
1
1
0
2
+λ3
−1
−2
1
1
=0 (2.68)
forλ1, . . . , λ 3. We write the vectors xi,i= 1,2,3, as the columns of a
matrix and apply elementary row operations until we identify the pivot
columns:

1 1 −1
2 1 −2
−3 0 1
4 2 1
⇝···⇝
1 1 −1
0 1 0
0 0 1
0 0 0
. (2.69)
Here, every column of the matrix is a pivot column. Therefore, there is no
non-trivial solution, and we require λ1= 0, λ2= 0, λ3= 0to solve the
equation system. Hence, the vectors x1,x2,x3are linearly independent.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
2.5 Linear Independence 43
Remark. Consider a vector space Vwith klinearly independent vectors
b1, . . . ,bkandmlinear combinations
x1=kX
i=1λi1bi,
...
xm=kX
i=1λimbi.(2.70)
Defining B= [b1, . . . ,bk]as the matrix whose columns are the linearly
independent vectors b1, . . . ,bk, we can write
xj=Bλj,λj=
λ1j
...
λkj
, j= 1, . . . , m , (2.71)
in a more compact form.
We want to test whether x1, . . . ,xmare linearly independent. For this
purpose, we follow the general approach of testing whenPm
j=1ψjxj=0.
With (2.71), we obtain
mX
j=1ψjxj=mX
j=1ψjBλj=BmX
j=1ψjλj. (2.72)
This means that {x1, . . . ,xm}are linearly independent if and only if the
column vectors {λ1, . . . ,λm}are linearly independent.
♢
Remark. In a vector space V,mlinear combinations of kvectors x1, . . . ,xk
are linearly dependent if m > k . ♢
Example 2.15
Consider a set of linearly independent vectors b1,b2,b3,b4∈Rnand
x1=b1−2b2+b3−b4
x2=−4b1−2b2 + 4b4
x3= 2b1+ 3b2−b3−3b4
x4= 17 b1−10b2+ 11 b3+b4. (2.73)
Are the vectors x1, . . . ,x4∈Rnlinearly independent? To answer this
question, we investigate whether the column vectors



1
−2
1
−1
,
−4
−2
0
4
,
2
3
−1
−3
,
17
−10
11
1


(2.74)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
44 Linear Algebra
are linearly independent. The reduced row-echelon form of the corre-
sponding linear equation system with coefficient matrix
A=
1−4 2 17
−2−2 3 −10
1 0 −1 11
−1 4 −3 1
(2.75)
is given as

1 0 0 −7
0 1 0 −15
0 0 1 −18
0 0 0 0
. (2.76)
We see that the corresponding linear equation system is non-trivially solv-
able: The last column is not a pivot column, and x4=−7x1−15x2−18x3.
Therefore, x1, . . . ,x4are linearly dependent as x4can be expressed as a
linear combination of x1, . . . ,x3.
2.6 Basis and Rank
In a vector space V, we are particularly interested in sets of vectors Athat
possess the property that any vector v∈Vcan be obtained by a linear
combination of vectors in A. These vectors are special vectors, and in the
following, we will characterize them.
2.6.1 Generating Set and Basis
Definition 2.13 (Generating Set and Span) .Consider a vector space V=
(V,+,·)and set of vectors A={x1, . . . ,xk} ⊆ V . If every vector v∈
Vcan be expressed as a linear combination of x1, . . . ,xk,Ais called a
generating set ofV. The set of all linear combinations of vectors in Ais generating set
called the span ofA. IfAspans the vector space V, we write V= span[ A] span
orV= span[ x1, . . . ,xk].
Generating sets are sets of vectors that span vector (sub)spaces, i.e.,
every vector can be represented as a linear combination of the vectors
in the generating set. Now, we will be more specific and characterize the
smallest generating set that spans a vector (sub)space.
Definition 2.14 (Basis) .Consider a vector space V= (V,+,·)andA ⊆
V. A generating set AofVis called minimal if there exists no smaller set minimal
˜A⊊A ⊆ V that spans V. Every linearly independent generating set of V
is minimal and is called a basis ofV. basis
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
2.6 Basis and Rank 45
LetV= (V,+,·)be a vector space and B ⊆ V ,B ̸=∅. Then, the
following statements are equivalent: A basis is a minimal
generating set and a
maximal linearly
independent set of
vectors.Bis a basis of V.
Bis a minimal generating set.
Bis a maximal linearly independent set of vectors in V, i.e., adding any
other vector to this set will make it linearly dependent.
Every vector x∈Vis a linear combination of vectors from B, and every
linear combination is unique, i.e., with
x=kX
i=1λibi=kX
i=1ψibi (2.77)
andλi, ψi∈R,bi∈ Bit follows that λi=ψi, i= 1, . . . , k .
Example 2.16
InR3, the canonical/standard basis is canonical basis
B=


1
0
0
,
0
1
0
,
0
0
1


. (2.78)
Different bases in R3are
B1=


1
0
0
,
1
1
0
,
1
1
1


,B2=


0.5
0.8
0.4
,
1.8
0.3
0.3
,
−2.2
−1.3
3.5


.(2.79)
The set
A=


1
2
3
4
,
2
−1
0
2
,
1
1
0
−4


(2.80)
is linearly independent, but not a generating set (and no basis) of R4:
For instance, the vector [1,0,0,0]⊤cannot be obtained by a linear com-
bination of elements in A.
Remark. Every vector space Vpossesses a basis B. The preceding exam-
ples show that there can be many bases of a vector space V, i.e., there is
no unique basis. However, all bases possess the same number of elements,
thebasis vectors . ♢ basis vector
We only consider finite-dimensional vector spaces V. In this case, the
dimension ofVis the number of basis vectors of V, and we write dim(V).dimension
IfU⊆Vis a subspace of V, then dim(U)⩽dim(V)anddim(U) =
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
46 Linear Algebra
dim(V)if and only if U=V. Intuitively, the dimension of a vector space
can be thought of as the number of independent directions in this vector
space. The dimension of a
vector space
corresponds to the
number of its basis
vectors.Remark. The dimension of a vector space is not necessarily the number
of elements in a vector. For instance, the vector space V= span[0
1
]is
one-dimensional, although the basis vector possesses two elements. ♢
Remark. A basis of a subspace U= span[ x1, . . . ,xm]⊆Rncan be found
by executing the following steps:
1. Write the spanning vectors as columns of a matrix A
2. Determine the row-echelon form of A.
3. The spanning vectors associated with the pivot columns are a basis of
U.
♢
Example 2.17 (Determining a Basis)
For a vector subspace U⊆R5, spanned by the vectors
x1=
1
2
−1
−1
−1
,x2=
2
−1
1
2
−2
,x3=
3
−4
3
5
−3
,x4=
−1
8
−5
−6
1
∈R5,(2.81)
we are interested in finding out which vectors x1, . . . ,x4are a basis for U.
For this, we need to check whether x1, . . . ,x4are linearly independent.
Therefore, we need to solve
4X
i=1λixi=0, (2.82)
which leads to a homogeneous system of equations with matrix
x1,x2,x3,x4=
1 2 3 −1
2−1−4 8
−1 1 3 −5
−1 2 5 −6
−1−2−3 1
. (2.83)
With the basic transformation rules for systems of linear equations, we
obtain the row-echelon form
1 2 3 −1
2−1−4 8
−1 1 3 −5
−1 2 5 −6
−1−2−3 1
⇝···⇝
1 2 3 −1
0 1 2 −2
0 0 0 1
0 0 0 0
0 0 0 0
.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
2.6 Basis and Rank 47
Since the pivot columns indicate which set of vectors is linearly indepen-
dent, we see from the row-echelon form that x1,x2,x4are linearly inde-
pendent (because the system of linear equations λ1x1+λ2x2+λ4x4=0
can only be solved with λ1=λ2=λ4= 0). Therefore, {x1,x2,x4}is a
basis of U.
2.6.2 Rank
The number of linearly independent columns of a matrix A∈Rm×n
equals the number of linearly independent rows and is called the rank rank
ofAand is denoted by rk(A).
Remark. The rank of a matrix has some important properties:
rk(A) = rk( A⊤), i.e., the column rank equals the row rank.
The columns of A∈Rm×nspan a subspace U⊆Rmwith dim(U) =
rk(A). Later we will call this subspace the image orrange . A basis of
Ucan be found by applying Gaussian elimination to Ato identify the
pivot columns.
The rows of A∈Rm×nspan a subspace W⊆Rnwith dim(W) =
rk(A). A basis of Wcan be found by applying Gaussian elimination to
A⊤.
For all A∈Rn×nit holds that Ais regular (invertible) if and only if
rk(A) =n.
For all A∈Rm×nand all b∈Rmit holds that the linear equation
system Ax=bcan be solved if and only if rk(A) = rk( A|b), where
A|bdenotes the augmented system.
ForA∈Rm×nthe subspace of solutions for Ax=0possesses dimen-
sionn−rk(A). Later, we will call this subspace the kernel or the null kernel
null space space .
A matrix A∈Rm×nhasfull rank if its rank equals the largest possible full rank
rank for a matrix of the same dimensions. This means that the rank of
a full-rank matrix is the lesser of the number of rows and columns, i.e.,
rk(A) = min( m, n). A matrix is said to be rank deficient if it does not rank deficient
have full rank.
♢
Example 2.18 (Rank)
A=
1 0 1
0 1 1
0 0 0
.
Ahas two linearly independent rows/columns so that rk(A) = 2 .
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
48 Linear Algebra
A=
1 2 1
−2−3 1
3 5 0
.
We use Gaussian elimination to determine the rank:

1 2 1
−2−3 1
3 5 0
⇝···⇝
1 2 1
0 1 3
0 0 0
. (2.84)
Here, we see that the number of linearly independent rows and columns
is 2, such that rk(A) = 2 .
2.7 Linear Mappings
In the following, we will study mappings on vector spaces that preserve
their structure, which will allow us to define the concept of a coordinate.
In the beginning of the chapter, we said that vectors are objects that can be
added together and multiplied by a scalar, and the resulting object is still
a vector. We wish to preserve this property when applying the mapping:
Consider two real vector spaces V, W . A mapping Φ :V→Wpreserves
the structure of the vector space if
Φ(x+y) = Φ( x) + Φ( y) (2.85)
Φ(λx) =λΦ(x) (2.86)
for all x,y∈Vandλ∈R. We can summarize this in the following
definition:
Definition 2.15 (Linear Mapping) .For vector spaces V, W , a mapping
Φ :V→Wis called a linear mapping (orvector space homomorphism / linear mapping
vector space
homomorphismlinear transformation ) if
linear
transformation∀x,y∈V∀λ, ψ∈R: Φ(λx+ψy) =λΦ(x) +ψΦ(y). (2.87)
It turns out that we can represent linear mappings as matrices (Sec-
tion 2.7.1). Recall that we can also collect a set of vectors as columns of a
matrix. When working with matrices, we have to keep in mind what the
matrix represents: a linear mapping or a collection of vectors. We will see
more about linear mappings in Chapter 4. Before we continue, we will
briefly introduce special mappings.
Definition 2.16 (Injective, Surjective, Bijective) .Consider a mapping Φ :
V → W , where V,Wcan be arbitrary sets. Then Φis called
injective
Injective if∀x,y∈ V: Φ(x) = Φ( y) =⇒x=y.surjective
Surjective ifΦ(V) =W.bijective
Bijective if it is injective and surjective.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
2.7 Linear Mappings 49
IfΦis surjective, then every element in Wcan be “reached” from V
using Φ. A bijective Φcan be “undone”, i.e., there exists a mapping Ψ :
W → V so that Ψ◦Φ(x) =x. This mapping Ψis then called the inverse
ofΦand normally denoted by Φ−1.
With these definitions, we introduce the following special cases of linear
mappings between vector spaces VandW:
isomorphism
Isomorphism: Φ :V→Wlinear and bijective endomorphism
Endomorphism: Φ :V→Vlinear automorphism
Automorphism: Φ :V→Vlinear and bijective
We define idV:V→V,x7→xas the identity mapping oridentity identity mapping
identity
automorphismautomorphism inV.
Example 2.19 (Homomorphism)
The mapping Φ :R2→C,Φ(x) =x1+ix2, is a homomorphism:
Φx1
x2
+y1
y2
= (x1+y1) +i(x2+y2) =x1+ix2+y1+iy2
= Φx1
x2
+ Φy1
y2
Φ
λx1
x2
=λx1+λix2=λ(x1+ix2) =λΦx1
x2
.
(2.88)
This also justifies why complex numbers can be represented as tuples in
R2: There is a bijective linear mapping that converts the elementwise addi-
tion of tuples in R2into the set of complex numbers with the correspond-
ing addition. Note that we only showed linearity, but not the bijection.
Theorem 2.17 (Theorem 3.59 in Axler (2015)) .Finite-dimensional vector
spaces VandWare isomorphic if and only if dim(V) = dim( W).
Theorem 2.17 states that there exists a linear, bijective mapping be-
tween two vector spaces of the same dimension. Intuitively, this means
that vector spaces of the same dimension are kind of the same thing, as
they can be transformed into each other without incurring any loss.
Theorem 2.17 also gives us the justification to treat Rm×n(the vector
space of m×n-matrices) and Rmn(the vector space of vectors of length
mn) the same, as their dimensions are mn, and there exists a linear, bi-
jective mapping that transforms one into the other.
Remark. Consider vector spaces V, W, X . Then:
For linear mappings Φ :V→WandΨ :W→X, the mapping
Ψ◦Φ :V→Xis also linear.
IfΦ :V→Wis an isomorphism, then Φ−1:W→Vis an isomor-
phism, too.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
50 Linear Algebra
Figure 2.8 Two
different coordinate
systems defined by
two sets of basis
vectors. A vector x
has different
coordinate
representations
depending on which
coordinate system is
chosen.x x
e1e2
b1b2
IfΦ :V→W,Ψ :V→Ware linear, then Φ + Ψ andλΦ, λ∈R, are
linear, too.
♢
2.7.1 Matrix Representation of Linear Mappings
Anyn-dimensional vector space is isomorphic to Rn(Theorem 2.17). We
consider a basis {b1, . . . ,bn}of an n-dimensional vector space V. In the
following, the order of the basis vectors will be important. Therefore, we
write
B= (b1, . . . ,bn) (2.89)
and call this n-tuple an ordered basis ofV. ordered basis
Remark (Notation) .We are at the point where notation gets a bit tricky.
Therefore, we summarize some parts here. B= (b1, . . . ,bn)is an ordered
basis,B={b1, . . . ,bn}is an (unordered) basis, and B= [b1, . . . ,bn]is a
matrix whose columns are the vectors b1, . . . ,bn. ♢
Definition 2.18 (Coordinates) .Consider a vector space Vand an ordered
basis B= (b1, . . . ,bn)ofV. For any x∈Vwe obtain a unique represen-
tation (linear combination)
x=α1b1+. . .+αnbn (2.90)
ofxwith respect to B. Then α1, . . . , α nare the coordinates ofxwith coordinate
respect to B, and the vector
α=
α1
...
αn
∈Rn(2.91)
is the coordinate vector /coordinate representation ofxwith respect to the coordinate vector
coordinate
representationordered basis B.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
2.7 Linear Mappings 51
A basis effectively defines a coordinate system. We are familiar with the
Cartesian coordinate system in two dimensions, which is spanned by the
canonical basis vectors e1,e2. In this coordinate system, a vector x∈R2
has a representation that tells us how to linearly combine e1ande2to
obtain x. However, any basis of R2defines a valid coordinate system,
and the same vector xfrom before may have a different coordinate rep-
resentation in the (b1,b2)basis. In Figure 2.8, the coordinates of xwith
respect to the standard basis (e1,e2)is[2,2]⊤. However, with respect to
the basis (b1,b2)the same vector xis represented as [1.09,0.72]⊤, i.e.,
x= 1.09b1+ 0.72b2. In the following sections, we will discover how to
obtain this representation.
Example 2.20
Let us have a look at a geometric vector x∈R2with coordinates [2,3]⊤Figure 2.9
Different coordinate
representations of a
vector x, depending
on the choice of
basis.
e1e2b2
b1x=−1
2b1+5
2b2x= 2e1+ 3e2with respect to the standard basis (e1,e2)ofR2. This means, we can write
x= 2e1+ 3e2. However, we do not have to choose the standard basis to
represent this vector. If we use the basis vectors b1= [1,−1]⊤,b2= [1,1]⊤
we will obtain the coordinates1
2[−1,5]⊤to represent the same vector with
respect to (b1,b2)(see Figure 2.9).
Remark. For an n-dimensional vector space Vand an ordered basis B
ofV, the mapping Φ :Rn→V,Φ(ei) =bi,i= 1, . . . , n, is linear
(and because of Theorem 2.17 an isomorphism), where (e1, . . . ,en)is
the standard basis of Rn.
♢
Now we are ready to make an explicit connection between matrices and
linear mappings between finite-dimensional vector spaces.
Definition 2.19 (Transformation Matrix) .Consider vector spaces V, W
with corresponding (ordered) bases B= (b1, . . . ,bn)andC= (c1, . . . ,cm).
Moreover, we consider a linear mapping Φ :V→W. Forj∈ {1, . . . , n },
Φ(bj) =α1jc1+···+αmjcm=mX
i=1αijci (2.92)
is the unique representation of Φ(bj)with respect to C. Then, we call the
m×n-matrix AΦ, whose elements are given by
AΦ(i, j) =αij, (2.93)
thetransformation matrix ofΦ(with respect to the ordered bases BofV transformation
matrix andCofW).
The coordinates of Φ(bj)with respect to the ordered basis CofW
are the j-th column of AΦ. Consider (finite-dimensional) vector spaces
V, W with ordered bases B, C and a linear mapping Φ :V→Wwith
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
52 Linear Algebra
transformation matrix AΦ. Ifˆxis the coordinate vector of x∈Vwith
respect to Bandˆythe coordinate vector of y= Φ(x)∈Wwith respect
toC, then
ˆy=AΦˆx. (2.94)
This means that the transformation matrix can be used to map coordinates
with respect to an ordered basis in Vto coordinates with respect to an
ordered basis in W.
Example 2.21 (Transformation Matrix)
Consider a homomorphism Φ : V→Wand ordered bases B=
(b1, . . . ,b3)ofVandC= (c1, . . . ,c4)ofW. With
Φ(b1) =c1−c2+ 3c3−c4
Φ(b2) = 2c1+c2+ 7c3+ 2c4
Φ(b3) = 3c2+c3+ 4c4(2.95)
the transformation matrix AΦwith respect to BandCsatisfies Φ(bk) =P4
i=1αikcifork= 1, . . . , 3and is given as
AΦ= [α1,α2,α3] =
1 2 0
−1 1 3
3 7 1
−1 2 4
, (2.96)
where the αj, j= 1,2,3,are the coordinate vectors of Φ(bj)with respect
toC.
Example 2.22 (Linear Transformations of Vectors)
Figure 2.10 Three
examples of linear
transformations of
the vectors shown
as dots in (a);
(b) Rotation by 45◦;
(c) Stretching of the
horizontal
coordinates by 2;
(d) Combination of
reflection, rotation
and stretching.
(a) Original data.
 (b) Rotation by 45◦.
(c) Stretch along the
horizontal axis.
(d) General linear
mapping.
We consider three linear transformations of a set of vectors in R2with
the transformation matrices
A1=cos(π
4)−sin(π
4)
sin(π
4) cos(π
4)
,A2=2 0
0 1
,A3=1
23−1
1−1
.(2.97)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
2.7 Linear Mappings 53
Figure 2.10 gives three examples of linear transformations of a set of vec-
tors. Figure 2.10(a) shows 400vectors in R2, each of which is represented
by a dot at the corresponding (x1, x2)-coordinates. The vectors are ar-
ranged in a square. When we use matrix A1in (2.97) to linearly transform
each of these vectors, we obtain the rotated square in Figure 2.10(b). If we
apply the linear mapping represented by A2, we obtain the rectangle in
Figure 2.10(c) where each x1-coordinate is stretched by 2. Figure 2.10(d)
shows the original square from Figure 2.10(a) when linearly transformed
usingA3, which is a combination of a reflection, a rotation, and a stretch.
2.7.2 Basis Change
In the following, we will have a closer look at how transformation matrices
of a linear mapping Φ :V→Wchange if we change the bases in Vand
W. Consider two ordered bases
B= (b1, . . . ,bn),˜B= (˜b1, . . . , ˜bn) (2.98)
ofVand two ordered bases
C= (c1, . . . ,cm),˜C= (˜c1, . . . , ˜cm) (2.99)
ofW. Moreover, AΦ∈Rm×nis the transformation matrix of the linear
mapping Φ :V→Wwith respect to the bases BandC, and ˜AΦ∈Rm×n
is the corresponding transformation mapping with respect to ˜Band ˜C.
In the following, we will investigate how Aand˜Aare related, i.e., how/
whether we can transform AΦinto ˜AΦif we choose to perform a basis
change from B, C to˜B,˜C.
Remark. We effectively get different coordinate representations of the
identity mapping idV. In the context of Figure 2.9, this would mean to
map coordinates with respect to (e1,e2)onto coordinates with respect to
(b1,b2)without changing the vector x. By changing the basis and corre-
spondingly the representation of vectors, the transformation matrix with
respect to this new basis can have a particularly simple form that allows
for straightforward computation. ♢
Example 2.23 (Basis Change)
Consider a transformation matrix
A=2 1
1 2
(2.100)
with respect to the canonical basis in R2. If we define a new basis
B= (1
1
,1
−1
) (2.101)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
54 Linear Algebra
we obtain a diagonal transformation matrix
˜A=3 0
0 1
(2.102)
with respect to B, which is easier to work with than A.
In the following, we will look at mappings that transform coordinate
vectors with respect to one basis into coordinate vectors with respect to
a different basis. We will state our main result first and then provide an
explanation.
Theorem 2.20 (Basis Change) .For a linear mapping Φ :V→W, ordered
bases
B= (b1, . . . ,bn),˜B= (˜b1, . . . , ˜bn) (2.103)
ofVand
C= (c1, . . . ,cm),˜C= (˜c1, . . . , ˜cm) (2.104)
ofW, and a transformation matrix AΦofΦwith respect to BandC, the
corresponding transformation matrix ˜AΦwith respect to the bases ˜Band˜C
is given as
˜AΦ=T−1AΦS. (2.105)
Here,S∈Rn×nis the transformation matrix of idVthat maps coordinates
with respect to ˜Bonto coordinates with respect to B, andT∈Rm×mis the
transformation matrix of idWthat maps coordinates with respect to ˜Conto
coordinates with respect to C.
Proof Following Drumm and Weil (2001), we can write the vectors of
the new basis ˜BofVas a linear combination of the basis vectors of B,
such that
˜bj=s1jb1+···+snjbn=nX
i=1sijbi, j= 1, . . . , n . (2.106)
Similarly, we write the new basis vectors ˜CofWas a linear combination
of the basis vectors of C, which yields
˜ck=t1kc1+···+tmkcm=mX
l=1tlkcl, k = 1, . . . , m . (2.107)
We define S= ((sij))∈Rn×nas the transformation matrix that maps
coordinates with respect to ˜Bonto coordinates with respect to Band
T= ((tlk))∈Rm×mas the transformation matrix that maps coordinates
with respect to ˜Conto coordinates with respect to C. In particular, the jth
column of Sis the coordinate representation of ˜bjwith respect to Band
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
2.7 Linear Mappings 55
thekth column of Tis the coordinate representation of ˜ckwith respect to
C. Note that both SandTare regular.
We are going to look at Φ(˜bj)from two perspectives. First, applying the
mapping Φ, we get that for all j= 1, . . . , n
Φ(˜bj) =mX
k=1˜akj˜ck|{z}
∈W(2.107)=mX
k=1˜akjmX
l=1tlkcl=mX
l=1 mX
k=1tlk˜akj!
cl,(2.108)
where we first expressed the new basis vectors ˜ck∈Was linear com-
binations of the basis vectors cl∈Wand then swapped the order of
summation.
Alternatively, when we express the ˜bj∈Vas linear combinations of
bj∈V, we arrive at
Φ(˜bj)(2.106)= Φ nX
i=1sijbi!
=nX
i=1sijΦ(bi) =nX
i=1sijmX
l=1alicl(2.109a)
=mX
l=1 nX
i=1alisij!
cl, j= 1, . . . , n , (2.109b)
where we exploited the linearity of Φ. Comparing (2.108) and (2.109b),
it follows for all j= 1, . . . , n andl= 1, . . . , m that
mX
k=1tlk˜akj=nX
i=1alisij (2.110)
and, therefore,
T˜AΦ=AΦS∈Rm×n, (2.111)
such that
˜AΦ=T−1AΦS, (2.112)
which proves Theorem 2.20.
Theorem 2.20 tells us that with a basis change in V(Bis replaced with
˜B) and W(Cis replaced with ˜C), the transformation matrix AΦof a
linear mapping Φ :V→Wis replaced by an equivalent matrix ˜AΦwith
˜AΦ=T−1AΦS. (2.113)
Figure 2.11 illustrates this relation: Consider a homomorphism Φ :V→
Wand ordered bases B,˜BofVandC,˜CofW. The mapping ΦCBis an
instantiation of Φand maps basis vectors of Bonto linear combinations
of basis vectors of C. Assume that we know the transformation matrix AΦ
ofΦCBwith respect to the ordered bases B, C . When we perform a basis
change from Bto˜BinVand from Cto˜CinW, we can determine the
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
56 Linear Algebra
Figure 2.11 For a
homomorphism
Φ :V→Wand
ordered bases B,˜B
ofVandC,˜CofW
(marked in blue),
we can express the
mapping Φ˜C˜Bwith
respect to the bases
˜B,˜Cequivalently as
a composition of the
homomorphisms
Φ˜C˜B=
Ξ˜CC◦ΦCB◦ΨB˜B
with respect to the
bases in the
subscripts. The
corresponding
transformation
matrices are in red.V W
B
˜B ˜CCΦ
ΦCB
Φ˜C˜BΨB˜B ΞC˜C S T
˜AΦAΦV W
B
˜B ˜CCΦ
ΦCB
Φ˜C˜BΨB˜B Ξ˜CC= Ξ−1
C˜CS T−1
˜AΦAΦVector spaces
Ordered bases
corresponding transformation matrix ˜AΦas follows: First, we find the ma-
trix representation of the linear mapping ΨB˜B:V→Vthat maps coordi-
nates with respect to the new basis ˜Bonto the (unique) coordinates with
respect to the “old” basis B(inV). Then, we use the transformation ma-
trixAΦofΦCB:V→Wto map these coordinates onto the coordinates
with respect to CinW. Finally, we use a linear mapping Ξ˜CC:W→W
to map the coordinates with respect to Conto coordinates with respect to
˜C. Therefore, we can express the linear mapping Φ˜C˜Bas a composition of
linear mappings that involve the “old” basis:
Φ˜C˜B= Ξ ˜CC◦ΦCB◦ΨB˜B= Ξ−1
C˜C◦ΦCB◦ΨB˜B. (2.114)
Concretely, we use ΨB˜B= id VandΞC˜C= id W, i.e., the identity mappings
that map vectors onto themselves, but with respect to a different basis.
Definition 2.21 (Equivalence) .Two matrices A,˜A∈Rm×nareequivalent equivalent
if there exist regular matrices S∈Rn×nandT∈Rm×m, such that
˜A=T−1AS.
Definition 2.22 (Similarity) .Two matrices A,˜A∈Rn×naresimilar if similar
there exists a regular matrix S∈Rn×nwith ˜A=S−1AS
Remark. Similar matrices are always equivalent. However, equivalent ma-
trices are not necessarily similar. ♢
Remark. Consider vector spaces V, W, X . From the remark that follows
Theorem 2.17, we already know that for linear mappings Φ :V→W
andΨ :W→Xthe mapping Ψ◦Φ :V→Xis also linear. With
transformation matrices AΦandAΨof the corresponding mappings, the
overall transformation matrix is AΨ◦Φ=AΨAΦ. ♢
In light of this remark, we can look at basis changes from the perspec-
tive of composing linear mappings:
AΦis the transformation matrix of a linear mapping ΦCB:V→W
with respect to the bases B, C .
˜AΦis the transformation matrix of the linear mapping Φ˜C˜B:V→W
with respect to the bases ˜B,˜C.
Sis the transformation matrix of a linear mapping ΨB˜B:V→V
(automorphism) that represents ˜Bin terms of B. Normally, Ψ = id Vis
the identity mapping in V.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
2.7 Linear Mappings 57
Tis the transformation matrix of a linear mapping ΞC˜C:W→W
(automorphism) that represents ˜Cin terms of C. Normally, Ξ = id Wis
the identity mapping in W.
If we (informally) write down the transformations just in terms of bases,
thenAΦ:B→C,˜AΦ:˜B→˜C,S:˜B→B,T:˜C→Cand
T−1:C→˜C, and
˜B→˜C=˜B→B→C→˜C (2.115)
˜AΦ=T−1AΦS. (2.116)
Note that the execution order in (2.116) is from right to left because vec-
tors are multiplied at the right-hand side so that x7→Sx7→AΦ(Sx)7→
T−1 AΦ(Sx)=˜AΦx.
Example 2.24 (Basis Change)
Consider a linear mapping Φ :R3→R4whose transformation matrix is
AΦ=
1 2 0
−1 1 3
3 7 1
−1 2 4
(2.117)
with respect to the standard bases
B= (
1
0
0
,
0
1
0
,
0
0
1
), C = (
1
0
0
0
,
0
1
0
0
,
0
0
1
0
,
0
0
0
1
). (2.118)
We seek the transformation matrix ˜AΦofΦwith respect to the new bases
˜B= (
1
1
0
,
0
1
1
,
1
0
1
)∈R3,˜C= (
1
1
0
0
,
1
0
1
0
,
0
1
1
0
,
1
0
0
1
).(2.119)
Then,
S=
1 0 1
1 1 0
0 1 1
,T=
1 1 0 1
1 0 1 0
0 1 1 0
0 0 0 1
, (2.120)
where the ith column of Sis the coordinate representation of ˜biin
terms of the basis vectors of B. Since Bis the standard basis, the co-
ordinate representation is straightforward to find. For a general basis B,
we would need to solve a linear equation system to find the λisuch that
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
58 Linear Algebra
P3
i=1λibi=˜bj,j= 1, . . . , 3. Similarly, the jth column of Tis the coordi-
nate representation of ˜cjin terms of the basis vectors of C.
Therefore, we obtain
˜AΦ=T−1AΦS=1
2
1 1 −1−1
1−1 1 −1
−1 1 1 1
0 0 0 2

3 2 1
0 4 2
10 8 4
1 6 3
(2.121a)
=
−4−4−2
6 0 0
4 8 4
1 6 3
. (2.121b)
In Chapter 4, we will be able to exploit the concept of a basis change
to find a basis with respect to which the transformation matrix of an en-
domorphism has a particularly simple (diagonal) form. In Chapter 10, we
will look at a data compression problem and find a convenient basis onto
which we can project the data while minimizing the compression loss.
2.7.3 Image and Kernel
The image and kernel of a linear mapping are vector subspaces with cer-
tain important properties. In the following, we will characterize them
more carefully.
Definition 2.23 (Image and Kernel) .
ForΦ :V→W, we define the kernel /null space kernel
null space
ker(Φ) := Φ−1(0W) ={v∈V: Φ(v) =0W} (2.122)
and the image /range image
range
Im(Φ) := Φ( V) ={w∈W|∃v∈V: Φ(v) =w}. (2.123)
We also call VandWalso the domain andcodomain ofΦ, respectively. domain
codomain
Intuitively, the kernel is the set of vectors v∈VthatΦmaps onto the
neutral element 0W∈W. The image is the set of vectors w∈Wthat
can be “reached” by Φfrom any vector in V. An illustration is given in
Figure 2.12.
Remark. Consider a linear mapping Φ :V→W, where V, W are vector
spaces.
It always holds that Φ(0V) =0Wand, therefore, 0V∈ker(Φ) . In
particular, the null space is never empty.
Im(Φ) ⊆Wis a subspace of W, and ker(Φ) ⊆Vis a subspace of V.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
2.7 Linear Mappings 59
Figure 2.12 Kernel
and image of a
linear mapping
Φ :V→W.
Im(Φ)
0Wker(Φ)
0VΦ :V→WV W
Φis injective (one-to-one) if and only if ker(Φ) = {0}.
♢
Remark (Null Space and Column Space) .Let us consider A∈Rm×nand
a linear mapping Φ :Rn→Rm,x7→Ax.
ForA= [a1, . . . ,an], where aiare the columns of A, we obtain
Im(Φ) = {Ax:x∈Rn}=(nX
i=1xiai:x1, . . . , x n∈R)
(2.124a)
= span[ a1, . . . ,an]⊆Rm, (2.124b)
i.e., the image is the span of the columns of A, also called the column column space
space . Therefore, the column space (image) is a subspace of Rm, where
mis the “height” of the matrix.
rk(A) = dim(Im(Φ)) .
The kernel/null space ker(Φ) is the general solution to the homoge-
neous system of linear equations Ax=0and captures all possible
linear combinations of the elements in Rnthat produce 0∈Rm.
The kernel is a subspace of Rn, where nis the “width” of the matrix.
The kernel focuses on the relationship among the columns, and we can
use it to determine whether/how we can express a column as a linear
combination of other columns.
♢
Example 2.25 (Image and Kernel of a Linear Mapping)
The mapping
Φ :R4→R2,
x1
x2
x3
x4
7→1 2 −1 0
1 0 0 1
x1
x2
x3
x4
=x1+ 2x2−x3
x1+x4
(2.125a)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
60 Linear Algebra
=x11
1
+x22
0
+x3−1
0
+x40
1
(2.125b)
is linear. To determine Im(Φ) , we can take the span of the columns of the
transformation matrix and obtain
Im(Φ) = span[1
1
,2
0
,−1
0
,0
1
]. (2.126)
To compute the kernel (null space) of Φ, we need to solve Ax=0, i.e.,
we need to solve a homogeneous equation system. To do this, we use
Gaussian elimination to transform Ainto reduced row-echelon form:
1 2 −1 0
1 0 0 1
⇝···⇝1 0 0 1
0 1 −1
2−1
2
. (2.127)
This matrix is in reduced row-echelon form, and we can use the Minus-
1 Trick to compute a basis of the kernel (see Section 2.3.3). Alternatively,
we can express the non-pivot columns (columns 3and4) as linear com-
binations of the pivot columns (columns 1and2). The third column a3is
equivalent to −1
2times the second column a2. Therefore, 0=a3+1
2a2. In
the same way, we see that a4=a1−1
2a2and, therefore, 0=a1−1
2a2−a4.
Overall, this gives us the kernel (null space) as
ker(Φ) = span[
0
1
2
1
0
,
−1
1
2
0
1
]. (2.128)
rank-nullity
theorem Theorem 2.24 (Rank-Nullity Theorem) .For vector spaces V, W and a lin-
ear mapping Φ :V→Wit holds that
dim(ker(Φ)) + dim(Im(Φ)) = dim( V). (2.129)
The rank-nullity theorem is also referred to as the fundamental theorem fundamental
theorem of linear
mappingsof linear mappings (Axler, 2015, theorem 3.22). The following are direct
consequences of Theorem 2.24:
Ifdim(Im(Φ)) <dim(V), then ker(Φ) is non-trivial, i.e., the kernel
contains more than 0Vanddim(ker(Φ)) ⩾1.
IfAΦis the transformation matrix of Φwith respect to an ordered basis
anddim(Im(Φ)) <dim(V), then the system of linear equations AΦx=
0has infinitely many solutions.
Ifdim(V) = dim( W), then the three-way equivalence
Φis injective ⇐⇒ Φis surjective ⇐⇒ Φis bijective
holds since Im(Φ) ⊆W.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
2.8 Affine Spaces 61
2.8 Affine Spaces
In the following, we will take a closer look at spaces that are offset from
the origin, i.e., spaces that are no longer vector subspaces. Moreover, we
will briefly discuss properties of mappings between these affine spaces,
which resemble linear mappings.
Remark. In the machine learning literature, the distinction between linear
and affine is sometimes not clear so that we can find references to affine
spaces/mappings as linear spaces/mappings. ♢
2.8.1 Affine Subspaces
Definition 2.25 (Affine Subspace) .LetVbe a vector space, x0∈Vand
U⊆Va subspace. Then the subset
L=x0+U:={x0+u:u∈U} (2.130a)
={v∈V|∃u∈U:v=x0+u} ⊆V (2.130b)
is called affine subspace orlinear manifold ofV.Uis called direction or affine subspace
linear manifold
directiondirection space , andx0is called support point . In Chapter 12, we refer to
direction space
support pointsuch a subspace as a hyperplane .
hyperplaneNote that the definition of an affine subspace excludes 0ifx0/∈U.
Therefore, an affine subspace is not a (linear) subspace (vector subspace)
ofVforx0/∈U.
Examples of affine subspaces are points, lines, and planes in R3, which
do not (necessarily) go through the origin.
Remark. Consider two affine subspaces L=x0+Uand˜L=˜x0+˜Uof a
vector space V. Then, L⊆˜Lif and only if U⊆˜Uandx0−˜x0∈˜U.
Affine subspaces are often described by parameters : Consider a k-dimen-
sional affine space L=x0+UofV. If(b1, . . . ,bk)is an ordered basis of
U, then every element x∈Lcan be uniquely described as
x=x0+λ1b1+. . .+λkbk, (2.131)
where λ1, . . . , λ k∈R. This representation is called parametric equation parametric equation
ofLwith directional vectors b1, . . . ,bkandparameters λ1, . . . , λ k.♢ parameters
Example 2.26 (Affine Subspaces)
One-dimensional affine subspaces are called lines and can be written line
asy=x0+λb1, where λ∈RandU= span[ b1]⊆Rnis a one-
dimensional subspace of Rn. This means that a line is defined by a sup-
port point x0and a vector b1that defines the direction. See Figure 2.13
for an illustration.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
62 Linear Algebra
Two-dimensional affine subspaces of Rnare called planes . The para- plane
metric equation for planes is y=x0+λ1b1+λ2b2, where λ1, λ2∈R
andU= span[ b1,b2]⊆Rn. This means that a plane is defined by a
support point x0and two linearly independent vectors b1,b2that span
the direction space.
InRn, the(n−1)-dimensional affine subspaces are called hyperplanes , hyperplane
and the corresponding parametric equation is y=x0+Pn−1
i=1λibi,
where b1, . . . ,bn−1form a basis of an (n−1)-dimensional subspace
UofRn. This means that a hyperplane is defined by a support point
x0and(n−1)linearly independent vectors b1, . . . ,bn−1that span the
direction space. In R2, a line is also a hyperplane. In R3, a plane is also
a hyperplane.
Figure 2.13 Lines
are affine subspaces.
Vectors yon a line
x0+λb1lie in an
affine subspace L
with support point
x0and direction b1.
0x0
b1yL=x0+λb1
Remark (Inhomogeneous systems of linear equations and affine subspaces) .
ForA∈Rm×nandx∈Rm, the solution of the system of linear equa-
tionsAλ=xis either the empty set or an affine subspace of Rnof
dimension n−rk(A). In particular, the solution of the linear equation
λ1b1+. . .+λnbn=x, where (λ1, . . . , λ n)̸= (0, . . . , 0), is a hyperplane
inRn.
InRn, every k-dimensional affine subspace is the solution of an inho-
mogeneous system of linear equations Ax=b, where A∈Rm×n,b∈
Rmandrk(A) =n−k. Recall that for homogeneous equation systems
Ax=0the solution was a vector subspace, which we can also think of
as a special affine space with support point x0=0. ♢
2.8.2 Affine Mappings
Similar to linear mappings between vector spaces, which we discussed
in Section 2.7, we can define affine mappings between two affine spaces.
Linear and affine mappings are closely related. Therefore, many properties
that we already know from linear mappings, e.g., that the composition of
linear mappings is a linear mapping, also hold for affine mappings.
Definition 2.26 (Affine Mapping) .For two vector spaces V, W , a linear
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
2.9 Further Reading 63
mapping Φ :V→W, anda∈W, the mapping
ϕ:V→W (2.132)
x7→a+ Φ(x) (2.133)
is an affine mapping from VtoW. The vector ais called the translation affine mapping
translation vector vector ofϕ.
Every affine mapping ϕ:V→Wis also the composition of a linear
mapping Φ :V→Wand a translation τ:W→WinW, such that
ϕ=τ◦Φ. The mappings Φandτare uniquely determined.
The composition ϕ′◦ϕof affine mappings ϕ:V→W,ϕ′:W→Xis
affine.
Ifϕis bijective, affine mappings keep the geometric structure invariant.
They then also preserve the dimension and parallelism.
2.9 Further Reading
There are many resources for learning linear algebra, including the text-
books by Strang (2003), Golan (2007), Axler (2015), and Liesen and
Mehrmann (2015). There are also several online resources that we men-
tioned in the introduction to this chapter. We only covered Gaussian elim-
ination here, but there are many other approaches for solving systems of
linear equations, and we refer to numerical linear algebra textbooks by
Stoer and Burlirsch (2002), Golub and Van Loan (2012), and Horn and
Johnson (2013) for an in-depth discussion.
In this book, we distinguish between the topics of linear algebra (e.g.,
vectors, matrices, linear independence, basis) and topics related to the
geometry of a vector space. In Chapter 3, we will introduce the inner
product, which induces a norm. These concepts allow us to define angles,
lengths and distances, which we will use for orthogonal projections. Pro-
jections turn out to be key in many machine learning algorithms, such as
linear regression and principal component analysis, both of which we will
cover in Chapters 9 and 10, respectively.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
64 Linear Algebra
Exercises
2.1 We consider (R\{−1}, ⋆), where
a ⋆ b :=ab+a+b, a, b ∈R\{−1} (2.134)
a. Show that (R\{−1}, ⋆)is an Abelian group.
b. Solve
3⋆ x ⋆ x = 15
in the Abelian group (R\{−1}, ⋆), where ⋆is defined in (2.134).
2.2 Let nbe inN\{0}. Let k, xbe inZ. We define the congruence class ¯kof the
integer kas the set
k={x∈Z|x−k= 0 (mod n)}
={x∈Z| ∃a∈Z: (x−k=n·a)}.
We now define Z/nZ(sometimes written Zn) as the set of all congruence
classes modulo n. Euclidean division implies that this set is a finite set con-
taining nelements:
Zn={0,1, . . . , n−1}
For all a,b∈Zn, we define
a⊕b:=a+b
a. Show that (Zn,⊕)is a group. Is it Abelian?
b. We now define another operation ⊗for all aandbinZnas
a⊗b=a×b , (2.135)
where a×brepresents the usual multiplication in Z.
Letn= 5. Draw the times table of the elements of Z5\{0}under ⊗, i.e.,
calculate the products a⊗bfor all aandbinZ5\{0}.
Hence, show that Z5\{0}is closed under ⊗and possesses a neutral
element for ⊗. Display the inverse of all elements in Z5\{0}under ⊗.
Conclude that (Z5\{0},⊗)is an Abelian group.
c. Show that (Z8\{0},⊗)is not a group.
d. We recall that the B ´ezout theorem states that two integers aandbare
relatively prime (i.e., gcd(a, b) = 1 ) if and only if there exist two integers
uandvsuch that au+bv= 1. Show that (Zn\{0},⊗)is a group if and
only if n∈N\{0}is prime.
2.3 Consider the set Gof3×3matrices defined as follows:
G=


1x z
0 1 y
0 0 1
∈R3×3x, y, z ∈R


We define ·as the standard matrix multiplication.
Is(G,·)a group? If yes, is it Abelian? Justify your answer.
2.4 Compute the following matrix products, if possible:
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
Exercises 65
a.

1 2
4 5
7 8

1 1 0
0 1 1
1 0 1

b.

1 2 3
4 5 6
7 8 9

1 1 0
0 1 1
1 0 1

c.

1 1 0
0 1 1
1 0 1

1 2 3
4 5 6
7 8 9

d.

1 2 1 2
4 1 −1−4
0 3
1−1
2 1
5 2

e.

0 3
1−1
2 1
5 2

1 2 1 2
4 1 −1−4
2.5 Find the set Sof all solutions in xof the following inhomogeneous linear
systems Ax=b, where Aandbare defined as follows:
a.
A=
1 1 −1−1
2 5 −7−5
2−1 1 3
5 2 −4 2
,b=
1
−2
4
6

b.
A=
1−1 0 0 1
1 1 0 −3 0
2−1 0 1 −1
−1 2 0 −2−1
,b=
3
6
5
−1

2.6 Using Gaussian elimination, find all solutions of the inhomogeneous equa-
tion system Ax=bwith
A=
0 1 0 0 1 0
0 0 0 1 1 0
0 1 0 0 0 1
,b=
2
−1
1
.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
66 Linear Algebra
2.7 Find all solutions in x=
x1
x2
x3
∈R3of the equation system Ax= 12x,
where
A=
6 4 3
6 0 9
0 8 0

andP3
i=1xi= 1.
2.8 Determine the inverses of the following matrices if possible:
a.
A=
2 3 4
3 4 5
4 5 6

b.
A=
1 0 1 0
0 1 1 0
1 1 0 1
1 1 1 0

2.9 Which of the following sets are subspaces of R3?
a.A={(λ, λ+µ3, λ−µ3)|λ, µ∈R}
b.B={(λ2,−λ2,0)|λ∈R}
c. Let γbe inR.
C={(ξ1, ξ2, ξ3)∈R3|ξ1−2ξ2+ 3ξ3=γ}
d.D={(ξ1, ξ2, ξ3)∈R3|ξ2∈Z}
2.10 Are the following sets of vectors linearly independent?
a.
x1=
2
−1
3
,x2=
1
1
−2
,x3=
3
−3
8

b.
x1=
1
2
1
0
0
,x2=
1
1
0
1
1
,x3=
1
0
0
1
1

2.11 Write
y=
1
−2
5

as linear combination of
x1=
1
1
1
,x2=
1
2
3
,x3=
2
−1
1

Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
Exercises 67
2.12 Consider two subspaces of R4:
U1= span[
1
1
−3
1
,
2
−1
0
−1
,
−1
1
−1
1
], U 2= span[
−1
−2
2
1
,
2
−2
0
0
,
−3
6
−2
−1
].
Determine a basis of U1∩U2.
2.13 Consider two subspaces U1andU2, where U1is the solution space of the
homogeneous equation system A1x=0andU2is the solution space of the
homogeneous equation system A2x=0with
A1=
1 0 1
1−2−1
2 1 3
1 0 1
,A2=
3−3 0
1 2 3
7−5 2
3−1 2
.
a. Determine the dimension of U1, U2.
b. Determine bases of U1andU2.
c. Determine a basis of U1∩U2.
2.14 Consider two subspaces U1andU2, where U1is spanned by the columns of
A1andU2is spanned by the columns of A2with
A1=
1 0 1
1−2−1
2 1 3
1 0 1
,A2=
3−3 0
1 2 3
7−5 2
3−1 2
.
a. Determine the dimension of U1, U2
b. Determine bases of U1andU2
c. Determine a basis of U1∩U2
2.15 Let F={(x, y, z )∈R3|x+y−z= 0}andG={(a−b, a+b, a−3b)|a, b∈R}.
a. Show that FandGare subspaces of R3.
b. Calculate F∩Gwithout resorting to any basis vector.
c. Find one basis for Fand one for G, calculate F∩Gusing the basis vectors
previously found and check your result with the previous question.
2.16 Are the following mappings linear?
a. Let a, b∈R.
Φ :L1([a, b])→R
f7→Φ(f) =Zb
af(x)dx ,
where L1([a, b])denotes the set of integrable functions on [a, b].
b.
Φ :C1→C0
f7→Φ(f) =f′,
where for k⩾1,Ckdenotes the set of ktimes continuously differen-
tiable functions, and C0denotes the set of continuous functions.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
68 Linear Algebra
c.
Φ :R→R
x7→Φ(x) = cos( x)
d.
Φ :R3→R2
x7→
1 2 3
1 4 3
x
e. Let θbe in [0,2π[and
Φ :R2→R2
x7→
cos(θ) sin( θ)
−sin(θ) cos( θ)
x
2.17 Consider the linear mapping
Φ :R3→R4
Φ

x1
x2
x3

=
3x1+ 2x2+x3
x1+x2+x3
x1−3x2
2x1+ 3x2+x3

Find the transformation matrix AΦ.
Determine rk(AΦ).
Compute the kernel and image of Φ. What are dim(ker(Φ)) anddim(Im(Φ)) ?
2.18 Let Ebe a vector space. Let fandgbe two automorphisms on Esuch that
f◦g= id E(i.e., f◦gis the identity mapping idE). Show that ker(f) =
ker(g◦f),Im(g) = Im( g◦f)and that ker(f)∩Im(g) ={0E}.
2.19 Consider an endomorphism Φ :R3→R3whose transformation matrix
(with respect to the standard basis in R3) is
AΦ=
1 1 0
1−1 0
1 1 1
.
a. Determine ker(Φ) andIm(Φ) .
b. Determine the transformation matrix ˜AΦwith respect to the basis
B= (
1
1
1
,
1
2
1
,
1
0
0
),
i.e., perform a basis change toward the new basis B.
2.20 Let us consider b1,b2,b′
1,b′
2,4vectors of R2expressed in the standard basis
ofR2as
b1=
2
1
,b2=
−1
−1
,b′
1=
2
−2
,b′
2=
1
1
and let us define two ordered bases B= (b1,b2)andB′= (b′
1,b′
2)ofR2.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
Exercises 69
a. Show that BandB′are two bases of R2and draw those basis vectors.
b. Compute the matrix P1that performs a basis change from B′toB.
c. We consider c1,c2,c3, three vectors of R3defined in the standard basis
ofR3as
c1=
1
2
−1
,c2=
0
−1
2
,c3=
1
0
−1

and we define C= (c1,c2,c3).
(i) Show that Cis a basis of R3, e.g., by using determinants (see
Section 4.1).
(ii) Let us call C′= (c′
1,c′
2,c′
3)the standard basis of R3. Determine
the matrix P2that performs the basis change from CtoC′.
d. We consider a homomorphism Φ :R2−→R3, such that
Φ(b1+b2) = c2+c3
Φ(b1−b2) = 2 c1−c2+ 3c3
where B= (b1,b2)andC= (c1,c2,c3)are ordered bases of R2andR3,
respectively.
Determine the transformation matrix AΦofΦwith respect to the or-
dered bases BandC.
e. Determine A′, the transformation matrix of Φwith respect to the bases
B′andC′.
f. Let us consider the vector x∈R2whose coordinates in B′are[2,3]⊤.
In other words, x= 2b′
1+ 3b′
2.
(i) Calculate the coordinates of xinB.
(ii) Based on that, compute the coordinates of Φ(x)expressed in C.
(iii) Then, write Φ(x)in terms of c′
1,c′
2,c′
3.
(iv) Use the representation of xinB′and the matrix A′to find this
result directly.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
3
Analytic Geometry
In Chapter 2, we studied vectors, vector spaces, and linear mappings at
a general but abstract level. In this chapter, we will add some geomet-
ric interpretation and intuition to all of these concepts. In particular, we
will look at geometric vectors and compute their lengths and distances
or angles between two vectors. To be able to do this, we equip the vec-
tor space with an inner product that induces the geometry of the vector
space. Inner products and their corresponding norms and metrics capture
the intuitive notions of similarity and distances, which we use to develop
the support vector machine in Chapter 12. We will then use the concepts
of lengths and angles between vectors to discuss orthogonal projections,
which will play a central role when we discuss principal component anal-
ysis in Chapter 10 and regression via maximum likelihood estimation in
Chapter 9. Figure 3.1 gives an overview of how concepts in this chapter
are related and how they are connected to other chapters of the book.
Figure 3.1 A mind
map of the concepts
introduced in this
chapter, along with
when they are used
in other parts of the
book.Inner product
Norm
LengthsOrthogonal
projectionAngles Rotations
Chapter 4
Matrix
decompositionChapter 10
Dimensionality
reductionChapter 9
RegressionChapter 12
Classificationinduces
70
This material is published by Cambridge University Press as Mathematics for Machine Learning by
Marc Peter Deisenroth, A. Aldo Faisal, and Cheng Soon Ong (2020). This version is free to view
and download for personal use only. Not for re-distribution, re-sale, or use in derivative works.
©by M. P. Deisenroth, A. A. Faisal, and C. S. Ong, 2024. https://mml-book.com .
3.1 Norms 71
Figure 3.3 For
different norms, the
red lines indicate
the set of vectors
with norm 1. Left:
Manhattan norm;
Right: Euclidean
distance.
1
1
1
1
kxk1= 1
kxk2= 1
3.1 Norms
When we think of geometric vectors, i.e., directed line segments that start
at the origin, then intuitively the length of a vector is the distance of the
“end” of this directed line segment from the origin. In the following, we
will discuss the notion of the length of vectors using the concept of a norm.
Definition 3.1 (Norm) .Anorm on a vector space Vis a function norm
∥ · ∥:V→R, (3.1)
x7→ ∥x∥, (3.2)
which assigns each vector xitslength ∥x∥ ∈R, such that for all λ∈R length
andx,y∈Vthe following hold:
absolutely
homogeneous Absolutely homogeneous: ∥λx∥=|λ|∥x∥
triangle inequality Triangle inequality: ∥x+y∥⩽∥x∥+∥y∥
positive definite Positive definite: ∥x∥⩾0and∥x∥= 0⇐⇒x=0
Figure 3.2 Triangle
inequality.
a
b
ca+b In geometric terms, the triangle inequality states that for any triangle,
the sum of the lengths of any two sides must be greater than or equal
to the length of the remaining side; see Figure 3.2 for an illustration.
Definition 3.1 is in terms of a general vector space V(Section 2.4), but
in this book we will only consider a finite-dimensional vector space Rn.
Recall that for a vector x∈Rnwe denote the elements of the vector using
a subscript, that is, xiis the ithelement of the vector x.
Example 3.1 (Manhattan Norm)
The Manhattan norm onRnis defined for x∈Rnas Manhattan norm
∥x∥1:=nX
i=1|xi|, (3.3)
where | · |is the absolute value. The left panel of Figure 3.3 shows all
vectors x∈R2with∥x∥1= 1. The Manhattan norm is also called ℓ1ℓ1norm
norm .
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
72 Analytic Geometry
Example 3.2 (Euclidean Norm)
The Euclidean norm ofx∈Rnis defined as Euclidean norm
∥x∥2:=vuutnX
i=1x2
i=√
x⊤x (3.4)
and computes the Euclidean distance ofxfrom the origin. The right panel Euclidean distance
of Figure 3.3 shows all vectors x∈R2with∥x∥2= 1. The Euclidean
norm is also called ℓ2norm . ℓ2norm
Remark. Throughout this book, we will use the Euclidean norm (3.4) by
default if not stated otherwise. ♢
3.2 Inner Products
Inner products allow for the introduction of intuitive geometrical con-
cepts, such as the length of a vector and the angle or distance between
two vectors. A major purpose of inner products is to determine whether
vectors are orthogonal to each other.
3.2.1 Dot Product
We may already be familiar with a particular type of inner product, the
scalar product /dot product inRn, which is given by scalar product
dot product
x⊤y=nX
i=1xiyi. (3.5)
We will refer to this particular inner product as the dot product in this
book. However, inner products are more general concepts with specific
properties, which we will now introduce.
3.2.2 General Inner Products
Recall the linear mapping from Section 2.7, where we can rearrange the
mapping with respect to addition and multiplication with a scalar. A bi- bilinear mapping
linear mapping Ωis a mapping with two arguments, and it is linear in
each argument, i.e., when we look at a vector space Vthen it holds that
for all x,y,z∈V, λ, ψ ∈Rthat
Ω(λx+ψy,z) =λΩ(x,z) +ψΩ(y,z) (3.6)
Ω(x, λy+ψz) =λΩ(x,y) +ψΩ(x,z). (3.7)
Here, (3.6) asserts that Ωis linear in the first argument, and (3.7) asserts
thatΩis linear in the second argument (see also (2.87)).
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
3.2 Inner Products 73
Definition 3.2. LetVbe a vector space and Ω :V×V→Rbe a bilinear
mapping that takes two vectors and maps them onto a real number. Then
Ωis called symmetric ifΩ(x,y) = Ω( y,x)for all x,y∈V, i.e., the symmetric
order of the arguments does not matter.
Ωis called positive definite if positive definite
∀x∈V\{0}: Ω(x,x)>0,Ω(0,0) = 0 . (3.8)
Definition 3.3. LetVbe a vector space and Ω :V×V→Rbe a bilinear
mapping that takes two vectors and maps them onto a real number. Then
A positive definite, symmetric bilinear mapping Ω :V×V→Ris called
aninner product onV. We typically write ⟨x,y⟩instead of Ω(x,y). inner product
The pair (V,⟨·,·⟩)is called an inner product space or (real) vector space inner product space
vector space with
inner productwith inner product . If we use the dot product defined in (3.5), we call
(V,⟨·,·⟩)aEuclidean vector space .
Euclidean vector
space We will refer to these spaces as inner product spaces in this book.
Example 3.3 (Inner Product That Is Not the Dot Product)
Consider V=R2. If we define
⟨x,y⟩:=x1y1−(x1y2+x2y1) + 2x2y2 (3.9)
then⟨·,·⟩is an inner product but different from the dot product. The proof
will be an exercise.
3.2.3 Symmetric, Positive Definite Matrices
Symmetric, positive definite matrices play an important role in machine
learning, and they are defined via the inner product. In Section 4.3, we
will return to symmetric, positive definite matrices in the context of matrix
decompositions. The idea of symmetric positive semidefinite matrices is
key in the definition of kernels (Section 12.4).
Consider an n-dimensional vector space Vwith an inner product ⟨·,·⟩:
V×V→R(see Definition 3.3) and an ordered basis B= (b1, . . . ,bn)of
V. Recall from Section 2.6.1 that any vectors x,y∈Vcan be written as
linear combinations of the basis vectors so that x=Pn
i=1ψibi∈Vand
y=Pn
j=1λjbj∈Vfor suitable ψi, λj∈R. Due to the bilinearity of the
inner product, it holds for all x,y∈Vthat
⟨x,y⟩=*nX
i=1ψibi,nX
j=1λjbj+
=nX
i=1nX
j=1ψi⟨bi,bj⟩λj=ˆx⊤Aˆy,(3.10)
where Aij:=⟨bi,bj⟩andˆx,ˆyare the coordinates of xandywith respect
to the basis B. This implies that the inner product ⟨·,·⟩is uniquely deter-
mined through A. The symmetry of the inner product also means that A
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
74 Analytic Geometry
is symmetric. Furthermore, the positive definiteness of the inner product
implies that
∀x∈V\{0}:x⊤Ax>0. (3.11)
Definition 3.4 (Symmetric, Positive Definite Matrix) .A symmetric matrix
A∈Rn×nthat satisfies (3.11) is called symmetric, positive definite , or symmetric, positive
definite justpositive definite . If only ⩾holds in (3.11), then Ais called symmetric,
positive definite
symmetric, positive
semidefinitepositive semidefinite .
Example 3.4 (Symmetric, Positive Definite Matrices)
Consider the matrices
A1=9 6
6 5
,A2=9 6
6 3
. (3.12)
A1is positive definite because it is symmetric and
x⊤A1x=x1x29 6
6 5x1
x2
(3.13a)
= 9x2
1+ 12x1x2+ 5x2
2= (3x1+ 2x2)2+x2
2>0 (3.13b)
for all x∈V\{0}. In contrast, A2is symmetric but not positive definite
because x⊤A2x= 9x2
1+ 12x1x2+ 3x2
2= (3x1+ 2x2)2−x2
2can be less
than 0, e.g., for x= [2,−3]⊤.
IfA∈Rn×nis symmetric, positive definite, then
⟨x,y⟩=ˆx⊤Aˆy (3.14)
defines an inner product with respect to an ordered basis B, where ˆxand
ˆyare the coordinate representations of x,y∈Vwith respect to B.
Theorem 3.5. For a real-valued, finite-dimensional vector space Vand an
ordered basis BofV, it holds that ⟨·,·⟩:V×V→Ris an inner product if
and only if there exists a symmetric, positive definite matrix A∈Rn×nwith
⟨x,y⟩=ˆx⊤Aˆy. (3.15)
The following properties hold if A∈Rn×nis symmetric and positive
definite:
The null space (kernel) of Aconsists only of 0because x⊤Ax>0for
allx̸=0. This implies that Ax̸=0ifx̸=0.
The diagonal elements aiiofAare positive because aii=e⊤
iAei>0,
where eiis the ith vector of the standard basis in Rn.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
3.3 Lengths and Distances 75
3.3 Lengths and Distances
In Section 3.1, we already discussed norms that we can use to compute
the length of a vector. Inner products and norms are closely related in the
sense that any inner product induces a norm Inner products
induce norms.
∥x∥:=q
⟨x,x⟩ (3.16)
in a natural way, such that we can compute lengths of vectors using the in-
ner product. However, not every norm is induced by an inner product. The
Manhattan norm (3.3) is an example of a norm without a corresponding
inner product. In the following, we will focus on norms that are induced
by inner products and introduce geometric concepts, such as lengths, dis-
tances, and angles.
Remark (Cauchy-Schwarz Inequality) .For an inner product vector space
(V,⟨·,·⟩)the induced norm ∥ · ∥satisfies the Cauchy-Schwarz inequality Cauchy-Schwarz
inequality
|⟨x,y⟩|⩽∥x∥∥y∥. (3.17)
♢
Example 3.5 (Lengths of Vectors Using Inner Products)
In geometry, we are often interested in lengths of vectors. We can now use
an inner product to compute them using (3.16). Let us take x= [1,1]⊤∈
R2. If we use the dot product as the inner product, with (3.16) we obtain
∥x∥=√
x⊤x=√
12+ 12=√
2 (3.18)
as the length of x. Let us now choose a different inner product:
⟨x,y⟩:=x⊤1−1
2
−1
21
y=x1y1−1
2(x1y2+x2y1) +x2y2.(3.19)
If we compute the norm of a vector, then this inner product returns smaller
values than the dot product if x1andx2have the same sign (and x1x2>
0); otherwise, it returns greater values than the dot product. With this
inner product, we obtain
⟨x,x⟩=x2
1−x1x2+x2
2= 1−1 + 1 = 1 = ⇒ ∥x∥=√
1 = 1 ,(3.20)
such that xis “shorter” with this inner product than with the dot product.
Definition 3.6 (Distance and Metric) .Consider an inner product space
(V,⟨·,·⟩). Then
d(x,y) :=∥x−y∥=q
⟨x−y,x−y⟩ (3.21)
is called the distance between xandyforx,y∈V. If we use the dot distance
product as the inner product, then the distance is called Euclidean distance .Euclidean distance
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
76 Analytic Geometry
The mapping
d:V×V→R (3.22)
(x,y)7→d(x,y) (3.23)
is called a metric . metric
Remark. Similar to the length of a vector, the distance between vectors
does not require an inner product: a norm is sufficient. If we have a norm
induced by an inner product, the distance may vary depending on the
choice of the inner product. ♢
A metric dsatisfies the following:
1.dispositive definite , i.e., d(x,y)⩾0for all x,y∈Vandd(x,y) = positive definite
0⇐⇒x=y.
2.dissymmetric , i.e., d(x,y) =d(y,x)for all x,y∈V. symmetric
triangle inequality 3.Triangle inequality: d(x,z)⩽d(x,y) +d(y,z)for all x,y,z∈V.
Remark. At first glance, the lists of properties of inner products and met-
rics look very similar. However, by comparing Definition 3.3 with Defini-
tion 3.6 we observe that ⟨x,y⟩andd(x,y)behave in opposite directions.
Very similar xandywill result in a large value for the inner product and
a small value for the metric. ♢
3.4 Angles and Orthogonality
Figure 3.4 When
restricted to [0, π]
thenf(ω) = cos( ω)
returns a unique
number in the
interval [−1,1].
0π/2π
ω−101cos(ω)In addition to enabling the definition of lengths of vectors, as well as the
distance between two vectors, inner products also capture the geometry
of a vector space by defining the angle ωbetween two vectors. We use
the Cauchy-Schwarz inequality (3.17) to define angles ωin inner prod-
uct spaces between two vectors x,y, and this notion coincides with our
intuition in R2andR3. Assume that x̸=0,y̸=0. Then
−1⩽⟨x,y⟩
∥x∥∥y∥⩽1. (3.24)
Therefore, there exists a unique ω∈[0, π], illustrated in Figure 3.4, with
cosω=⟨x,y⟩
∥x∥∥y∥. (3.25)
The number ωis the angle between the vectors xandy. Intuitively, the angle
angle between two vectors tells us how similar their orientations are. For
example, using the dot product, the angle between xandy= 4x, i.e.,y
is a scaled version of x, is0: Their orientation is the same.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
3.4 Angles and Orthogonality 77
Example 3.6 (Angle between Vectors)
Let us compute the angle between x= [1,1]⊤∈R2andy= [1,2]⊤∈R2;Figure 3.5 The
angle ωbetween
two vectors x,yis
computed using the
inner product.
y
x
1 01
ωsee Figure 3.5, where we use the dot product as the inner product. Then
we get
cosω=⟨x,y⟩p
⟨x,x⟩⟨y,y⟩=x⊤yp
x⊤xy⊤y=3√
10, (3.26)
and the angle between the two vectors is arccos(3√
10)≈0.32 rad , which
corresponds to about 18◦.
A key feature of the inner product is that it also allows us to characterize
vectors that are orthogonal.
Definition 3.7 (Orthogonality) .Two vectors xandyareorthogonal if and orthogonal
only if ⟨x,y⟩= 0, and we write x⊥y. If additionally ∥x∥= 1 = ∥y∥,
i.e., the vectors are unit vectors, then xandyareorthonormal . orthonormal
An implication of this definition is that the 0-vector is orthogonal to
every vector in the vector space.
Remark. Orthogonality is the generalization of the concept of perpendic-
ularity to bilinear forms that do not have to be the dot product. In our
context, geometrically, we can think of orthogonal vectors as having a
right angle with respect to a specific inner product. ♢
Example 3.7 (Orthogonal Vectors)
Figure 3.6 The
angle ωbetween
two vectors x,ycan
change depending
on the inner
product.y x
−1 1 01
ω
Consider two vectors x= [1,1]⊤,y= [−1,1]⊤∈R2; see Figure 3.6.
We are interested in determining the angle ωbetween them using two
different inner products. Using the dot product as the inner product yields
an angle ωbetween xandyof90◦, such that x⊥y. However, if we
choose the inner product
⟨x,y⟩=x⊤2 0
0 1
y, (3.27)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
78 Analytic Geometry
we get that the angle ωbetween xandyis given by
cosω=⟨x,y⟩
∥x∥∥y∥=−1
3=⇒ω≈1.91 rad ≈109.5◦, (3.28)
andxandyare not orthogonal. Therefore, vectors that are orthogonal
with respect to one inner product do not have to be orthogonal with re-
spect to a different inner product.
Definition 3.8 (Orthogonal Matrix) .A square matrix A∈Rn×nis an
orthogonal matrix if and only if its columns are orthonormal so that orthogonal matrix
AA⊤=I=A⊤A, (3.29)
which implies that
A−1=A⊤, (3.30)
i.e., the inverse is obtained by simply transposing the matrix. It is convention to
call these matrices
“orthogonal” but a
more precise
description would
be “orthonormal”.Transformations by orthogonal matrices are special because the length
of a vector xis not changed when transforming it using an orthogonal
matrix A. For the dot product, we obtain
Transformations
with orthogonal
matrices preserve
distances and
angles.∥Ax∥2= (Ax)⊤(Ax) =x⊤A⊤Ax=x⊤Ix=x⊤x=∥x∥2.(3.31)
Moreover, the angle between any two vectors x,y, as measured by their
inner product, is also unchanged when transforming both of them using
an orthogonal matrix A. Assuming the dot product as the inner product,
the angle of the images AxandAyis given as
cosω=(Ax)⊤(Ay)
∥Ax∥∥Ay∥=x⊤A⊤Ayq
x⊤A⊤Axy⊤A⊤Ay=x⊤y
∥x∥∥y∥,(3.32)
which gives exactly the angle between xandy. This means that orthog-
onal matrices AwithA⊤=A−1preserve both angles and distances. It
turns out that orthogonal matrices define transformations that are rota-
tions (with the possibility of flips). In Section 3.9, we will discuss more
details about rotations.
3.5 Orthonormal Basis
In Section 2.6.1, we characterized properties of basis vectors and found
that in an n-dimensional vector space, we need nbasis vectors, i.e., n
vectors that are linearly independent. In Sections 3.3 and 3.4, we used
inner products to compute the length of vectors and the angle between
vectors. In the following, we will discuss the special case where the basis
vectors are orthogonal to each other and where the length of each basis
vector is 1. We will call this basis then an orthonormal basis.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
3.6 Orthogonal Complement 79
Let us introduce this more formally.
Definition 3.9 (Orthonormal Basis) .Consider an n-dimensional vector
space Vand a basis {b1, . . . ,bn}ofV. If
⟨bi,bj⟩= 0 fori̸=j (3.33)
⟨bi,bi⟩= 1 (3.34)
for all i, j= 1, . . . , n then the basis is called an orthonormal basis (ONB). orthonormal basis
ONB If only (3.33) is satisfied, then the basis is called an orthogonal basis . Note
orthogonal basisthat (3.34) implies that every basis vector has length/norm 1.
Recall from Section 2.6.1 that we can use Gaussian elimination to find a
basis for a vector space spanned by a set of vectors. Assume we are given
a set{˜b1, . . . , ˜bn}of non-orthogonal and unnormalized basis vectors. We
concatenate them into a matrix ˜B= [˜b1, . . . , ˜bn]and apply Gaussian elim-
ination to the augmented matrix (Section 2.3.2) [˜B˜B⊤|˜B]to obtain an
orthonormal basis. This constructive way to iteratively build an orthonor-
mal basis {b1, . . . ,bn}is called the Gram-Schmidt process (Strang, 2003).
Example 3.8 (Orthonormal Basis)
The canonical/standard basis for a Euclidean vector space Rnis an or-
thonormal basis, where the inner product is the dot product of vectors.
InR2, the vectors
b1=1√
21
1
,b2=1√
21
−1
(3.35)
form an orthonormal basis since b⊤
1b2= 0and∥b1∥= 1 = ∥b2∥.
We will exploit the concept of an orthonormal basis in Chapter 12 and
Chapter 10 when we discuss support vector machines and principal com-
ponent analysis.
3.6 Orthogonal Complement
Having defined orthogonality, we will now look at vector spaces that are
orthogonal to each other. This will play an important role in Chapter 10,
when we discuss linear dimensionality reduction from a geometric per-
spective.
Consider a D-dimensional vector space Vand an M-dimensional sub-
space U⊆V. Then its orthogonal complement U⊥is a(D−M)-dimensional orthogonal
complement subspace of Vand contains all vectors in Vthat are orthogonal to every
vector in U. Furthermore, U∩U⊥={0}so that any vector x∈Vcan be
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
80 Analytic Geometry
Figure 3.7 A plane
Uin a
three-dimensional
vector space can be
described by its
normal vector,
which spans its
orthogonal
complement U⊥.e3
e1e2w
U
uniquely decomposed into
x=MX
m=1λmbm+D−MX
j=1ψjb⊥
j, λ m, ψj∈R, (3.36)
where (b1, . . . ,bM)is a basis of Uand(b⊥
1, . . . ,b⊥
D−M)is a basis of U⊥.
Therefore, the orthogonal complement can also be used to describe a
plane U(two-dimensional subspace) in a three-dimensional vector space.
More specifically, the vector wwith∥w∥= 1, which is orthogonal to the
plane U, is the basis vector of U⊥. Figure 3.7 illustrates this setting. All
vectors that are orthogonal to wmust (by construction) lie in the plane
U. The vector wis called the normal vector ofU. normal vector
Generally, orthogonal complements can be used to describe hyperplanes
inn-dimensional vector and affine spaces.
3.7 Inner Product of Functions
Thus far, we looked at properties of inner products to compute lengths,
angles and distances. We focused on inner products of finite-dimensional
vectors. In the following, we will look at an example of inner products of
a different type of vectors: inner products of functions.
The inner products we discussed so far were defined for vectors with a
finite number of entries. We can think of a vector x∈Rnas a function
withnfunction values. The concept of an inner product can be generalized
to vectors with an infinite number of entries (countably infinite) and also
continuous-valued functions (uncountably infinite). Then the sum over
individual components of vectors (see Equation (3.5) for example) turns
into an integral.
An inner product of two functions u:R→Randv:R→Rcan be
defined as the definite integral
⟨u, v⟩:=Zb
au(x)v(x)dx (3.37)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
3.8 Orthogonal Projections 81
for lower and upper limits a, b < ∞, respectively. As with our usual inner
product, we can define norms and orthogonality by looking at the inner
product. If (3.37) evaluates to 0, the functions uandvare orthogonal. To
make the preceding inner product mathematically precise, we need to take
care of measures and the definition of integrals, leading to the definition of
a Hilbert space. Furthermore, unlike inner products on finite-dimensional
vectors, inner products on functions may diverge (have infinite value). All
this requires diving into some more intricate details of real and functional
analysis, which we do not cover in this book.
Example 3.9 (Inner Product of Functions)
If we choose u= sin( x)andv= cos( x), the integrand f(x) =u(x)v(x)Figure 3.8 f(x) =
sin(x) cos( x).
−2.5 0.0 2.5
x−0.50.00.5sin(x) cos(x) of (3.37), is shown in Figure 3.8. We see that this function is odd, i.e.,
f(−x) =−f(x). Therefore, the integral with limits a=−π, b=πof this
product evaluates to 0. Therefore, sinandcosare orthogonal functions.
Remark. It also holds that the collection of functions
{1,cos(x),cos(2 x),cos(3 x), . . .} (3.38)
is orthogonal if we integrate from −πtoπ, i.e., any pair of functions are
orthogonal to each other. The collection of functions in (3.38) spans a
large subspace of the functions that are even and periodic on [−π, π), and
projecting functions onto this subspace is the fundamental idea behind
Fourier series. ♢
In Section 6.4.6, we will have a look at a second type of unconventional
inner products: the inner product of random variables.
3.8 Orthogonal Projections
Projections are an important class of linear transformations (besides rota-
tions and reflections) and play an important role in graphics, coding the-
ory, statistics and machine learning. In machine learning, we often deal
with data that is high-dimensional. High-dimensional data is often hard
to analyze or visualize. However, high-dimensional data quite often pos-
sesses the property that only a few dimensions contain most information,
and most other dimensions are not essential to describe key properties
of the data. When we compress or visualize high-dimensional data, we
will lose information. To minimize this compression loss, we ideally find
the most informative dimensions in the data. As discussed in Chapter 1, “Feature” is a
common expression
for data
representation.data can be represented as vectors, and in this chapter, we will discuss
some of the fundamental tools for data compression. More specifically, we
can project the original high-dimensional data onto a lower-dimensional
feature space and work in this lower-dimensional space to learn more
about the dataset and extract relevant patterns. For example, machine
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
82 Analytic Geometry
Figure 3.9
Orthogonal
projection (orange
dots) of a
two-dimensional
dataset (blue dots)
onto a
one-dimensional
subspace (straight
line).
−4−2 0 2 4
x1−2−1012x2
learning algorithms, such as principal component analysis (PCA) by Pear-
son (1901) and Hotelling (1933) and deep neural networks (e.g., deep
auto-encoders (Deng et al., 2010)), heavily exploit the idea of dimension-
ality reduction. In the following, we will focus on orthogonal projections,
which we will use in Chapter 10 for linear dimensionality reduction and
in Chapter 12 for classification. Even linear regression, which we discuss
in Chapter 9, can be interpreted using orthogonal projections. For a given
lower-dimensional subspace, orthogonal projections of high-dimensional
data retain as much information as possible and minimize the difference/
error between the original data and the corresponding projection. An il-
lustration of such an orthogonal projection is given in Figure 3.9. Before
we detail how to obtain these projections, let us define what a projection
actually is.
Definition 3.10 (Projection) .LetVbe a vector space and U⊆Va
subspace of V. A linear mapping π:V→Uis called a projection if projection
π2=π◦π=π.
Since linear mappings can be expressed by transformation matrices (see
Section 2.7), the preceding definition applies equally to a special kind
of transformation matrices, the projection matrices Pπ, which exhibit the projection matrix
property that P2
π=Pπ.
In the following, we will derive orthogonal projections of vectors in the
inner product space (Rn,⟨·,·⟩)onto subspaces. We will start with one-
dimensional subspaces, which are also called lines. If not mentioned oth- line
erwise, we assume the dot product ⟨x,y⟩=x⊤yas the inner product.
3.8.1 Projection onto One-Dimensional Subspaces (Lines)
Assume we are given a line (one-dimensional subspace) through the ori-
gin with basis vector b∈Rn. The line is a one-dimensional subspace
U⊆Rnspanned by b. When we project x∈Rnonto U, we seek the
vector πU(x)∈Uthat is closest to x. Using geometric arguments, let
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
3.8 Orthogonal Projections 83
Figure 3.10
Examples of
projections onto
one-dimensional
subspaces.
bx
πU(x)
ω
(a) Projection of x∈R2onto a subspace U
with basis vector b.cosω ωsinω
bx
(b) Projection of a two-dimensional vector
xwith∥x∥= 1 onto a one-dimensional
subspace spanned by b.
us characterize some properties of the projection πU(x)(Figure 3.10(a)
serves as an illustration):
The projection πU(x)is closest to x, where “closest” implies that the
distance ∥x−πU(x)∥is minimal. It follows that the segment πU(x)−x
from πU(x)toxis orthogonal to U, and therefore the basis vector bof
U. The orthogonality condition yields ⟨πU(x)−x,b⟩= 0since angles
between vectors are defined via the inner product.λis then the
coordinate of πU(x)
with respect to b.The projection πU(x)ofxontoUmust be an element of Uand, there-
fore, a multiple of the basis vector bthat spans U. Hence, πU(x) =λb,
for some λ∈R.
In the following three steps, we determine the coordinate λ, the projection
πU(x)∈U, and the projection matrix Pπthat maps any x∈RnontoU:
1. Finding the coordinate λ. The orthogonality condition yields
⟨x−πU(x),b⟩= 0πU(x)=λb⇐⇒ ⟨ x−λb,b⟩= 0. (3.39)
We can now exploit the bilinearity of the inner product and arrive at With a general inner
product, we get
λ=⟨x,b⟩if
∥b∥= 1. ⟨x,b⟩ −λ⟨b,b⟩= 0⇐⇒ λ=⟨x,b⟩
⟨b,b⟩=⟨b,x⟩
∥b∥2. (3.40)
In the last step, we exploited the fact that inner products are symmet-
ric. If we choose ⟨·,·⟩to be the dot product, we obtain
λ=b⊤x
b⊤b=b⊤x
∥b∥2. (3.41)
If∥b∥= 1, then the coordinate λof the projection is given by b⊤x.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
84 Analytic Geometry
2. Finding the projection point πU(x)∈U. Since πU(x) =λb, we imme-
diately obtain with (3.40) that
πU(x) =λb=⟨x,b⟩
∥b∥2b=b⊤x
∥b∥2b, (3.42)
where the last equality holds for the dot product only. We can also
compute the length of πU(x)by means of Definition 3.1 as
∥πU(x)∥=∥λb∥=|λ|∥b∥. (3.43)
Hence, our projection is of length |λ|times the length of b. This also
adds the intuition that λis the coordinate of πU(x)with respect to the
basis vector bthat spans our one-dimensional subspace U.
If we use the dot product as an inner product, we get
∥πU(x)∥(3.42)=|b⊤x|
∥b∥2∥b∥(3.25)=|cosω|∥x∥∥b∥∥b∥
∥b∥2=|cosω|∥x∥.
(3.44)
Here, ωis the angle between xandb. This equation should be familiar
from trigonometry: If ∥x∥= 1, then xlies on the unit circle. It follows
that the projection onto the horizontal axis spanned by bis exactly The horizontal axis
is a one-dimensional
subspace.cosω, and the length of the corresponding vector πU(x) =|cosω|. An
illustration is given in Figure 3.10(b).
3. Finding the projection matrix Pπ. We know that a projection is a lin-
ear mapping (see Definition 3.10). Therefore, there exists a projection
matrix Pπ, such that πU(x) =Pπx. With the dot product as inner
product and
πU(x) =λb=bλ=bb⊤x
∥b∥2=bb⊤
∥b∥2x, (3.45)
we immediately see that
Pπ=bb⊤
∥b∥2. (3.46)
Note that bb⊤(and, consequently, Pπ) is a symmetric matrix (of rank Projection matrices
are always
symmetric.1), and ∥b∥2=⟨b,b⟩is a scalar.
The projection matrix Pπprojects any vector x∈Rnonto the line through
the origin with direction b(equivalently, the subspace Uspanned by b).
Remark. The projection πU(x)∈Rnis still an n-dimensional vector and
not a scalar. However, we no longer require ncoordinates to represent the
projection, but only a single one if we want to express it with respect to
the basis vector bthat spans the subspace U:λ. ♢
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
3.8 Orthogonal Projections 85
Figure 3.11
Projection onto a
two-dimensional
subspace Uwith
basisb1,b2. The
projection πU(x)of
x∈R3ontoUcan
be expressed as a
linear combination
ofb1,b2and the
displacement vector
x−πU(x)is
orthogonal to both
b1andb2.
0x
b1b2U
πU(x)x−πU(x)
Example 3.10 (Projection onto a Line)
Find the projection matrix Pπonto the line through the origin spanned
byb=1 2 2⊤.bis a direction and a basis of the one-dimensional
subspace (line through origin).
With (3.46), we obtain
Pπ=bb⊤
b⊤b=1
9
1
2
2
1 2 2=1
9
1 2 2
2 4 4
2 4 4
. (3.47)
Let us now choose a particular xand see whether it lies in the subspace
spanned by b. Forx=1 1 1⊤, the projection is
πU(x) =Pπx=1
9
1 2 2
2 4 4
2 4 4

1
1
1
=1
9
5
10
10
∈span[
1
2
2
].(3.48)
Note that the application of PπtoπU(x)does not change anything, i.e.,
PππU(x) =πU(x). This is expected because according to Definition 3.10,
we know that a projection matrix Pπsatisfies P2
πx=Pπxfor all x.
Remark. With the results from Chapter 4, we can show that πU(x)is an
eigenvector of Pπ, and the corresponding eigenvalue is 1. ♢
3.8.2 Projection onto General Subspaces
IfUis given by a set
of spanning vectors,
which are not a
basis, make sure
you determine a
basisb1, . . . ,bm
before proceeding.In the following, we look at orthogonal projections of vectors x∈Rn
onto lower-dimensional subspaces U⊆Rnwith dim(U) =m⩾1. An
illustration is given in Figure 3.11.
Assume that (b1, . . . ,bm)is an ordered basis of U. Any projection πU(x)
ontoUis necessarily an element of U. Therefore, they can be represented
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
86 Analytic Geometry
as linear combinations of the basis vectors b1, . . . ,bmofU, such that
πU(x) =Pm
i=1λibi. The basis vectors
form the columns of
B∈Rn×m, where
B= [b1, . . . ,bm].As in the 1D case, we follow a three-step procedure to find the projec-
tionπU(x)and the projection matrix Pπ:
1. Find the coordinates λ1, . . . , λ mof the projection (with respect to the
basis of U), such that the linear combination
πU(x) =mX
i=1λibi=Bλ, (3.49)
B= [b1, . . . ,bm]∈Rn×m,λ= [λ1, . . . , λ m]⊤∈Rm, (3.50)
is closest to x∈Rn. As in the 1D case, “closest” means “minimum
distance”, which implies that the vector connecting πU(x)∈Uand
x∈Rnmust be orthogonal to all basis vectors of U. Therefore, we
obtain msimultaneous conditions (assuming the dot product as the
inner product)
⟨b1,x−πU(x)⟩=b⊤
1(x−πU(x)) = 0 (3.51)
...
⟨bm,x−πU(x)⟩=b⊤
m(x−πU(x)) = 0 (3.52)
which, with πU(x) =Bλ, can be written as
b⊤
1(x−Bλ) = 0 (3.53)
...
b⊤
m(x−Bλ) = 0 (3.54)
such that we obtain a homogeneous linear equation system

b⊤
1...
b⊤
m

x−Bλ
=0⇐⇒B⊤(x−Bλ) =0 (3.55)
⇐⇒B⊤Bλ=B⊤x. (3.56)
The last expression is called normal equation . Since b1, . . . ,bmare a normal equation
basis of Uand, therefore, linearly independent, B⊤B∈Rm×mis reg-
ular and can be inverted. This allows us to solve for the coefficients/
coordinates
λ= (B⊤B)−1B⊤x. (3.57)
The matrix (B⊤B)−1B⊤is also called the pseudo-inverse ofB, which pseudo-inverse
can be computed for non-square matrices B. It only requires that B⊤B
is positive definite, which is the case if Bis full rank. In practical ap-
plications (e.g., linear regression), we often add a “jitter term” ϵIto
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
3.8 Orthogonal Projections 87
B⊤Bto guarantee increased numerical stability and positive definite-
ness. This “ridge” can be rigorously derived using Bayesian inference.
See Chapter 9 for details.
2. Find the projection πU(x)∈U. We already established that πU(x) =
Bλ. Therefore, with (3.57)
πU(x) =B(B⊤B)−1B⊤x. (3.58)
3. Find the projection matrix Pπ. From (3.58), we can immediately see
that the projection matrix that solves Pπx=πU(x)must be
Pπ=B(B⊤B)−1B⊤. (3.59)
Remark. The solution for projecting onto general subspaces includes the
1D case as a special case: If dim(U) = 1 , then B⊤B∈Ris a scalar and
we can rewrite the projection matrix in (3.59) Pπ=B(B⊤B)−1B⊤as
Pπ=BB⊤
B⊤B, which is exactly the projection matrix in (3.46). ♢
Example 3.11 (Projection onto a Two-dimensional Subspace)
For a subspace U= span[
1
1
1
,
0
1
2
]⊆R3andx=
6
0
0
∈R3find the
coordinates λofxin terms of the subspace U, the projection point πU(x)
and the projection matrix Pπ.
First, we see that the generating set of Uis a basis (linear indepen-
dence) and write the basis vectors of Uinto a matrix B=
1 0
1 1
1 2
.
Second, we compute the matrix B⊤Band the vector B⊤xas
B⊤B=1 1 1
0 1 2
1 0
1 1
1 2
=3 3
3 5
,B⊤x=1 1 1
0 1 2
6
0
0
=6
0
.
(3.60)
Third, we solve the normal equation B⊤Bλ=B⊤xto find λ:
3 3
3 5λ1
λ2
=6
0
⇐⇒λ=5
−3
. (3.61)
Fourth, the projection πU(x)ofxontoU, i.e., into the column space of
B, can be directly computed via
πU(x) =Bλ=
5
2
−1
. (3.62)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
88 Analytic Geometry
The corresponding projection error is the norm of the difference vector projection error
between the original vector and its projection onto U, i.e., The projection error
is also called the
reconstruction error . ∥x−πU(x)∥=1−2 1⊤=√
6. (3.63)
Fifth, the projection matrix (for any x∈R3) is given by
Pπ=B(B⊤B)−1B⊤=1
6
5 2 −1
2 2 2
−1 2 5
. (3.64)
To verify the results, we can (a) check whether the displacement vector
πU(x)−xis orthogonal to all basis vectors of U, and (b) verify that
Pπ=P2
π(see Definition 3.10).
Remark. The projections πU(x)are still vectors in Rnalthough they lie in
anm-dimensional subspace U⊆Rn. However, to represent a projected
vector we only need the mcoordinates λ1, . . . , λ mwith respect to the
basis vectors b1, . . . ,bmofU. ♢
Remark. In vector spaces with general inner products, we have to pay
attention when computing angles and distances, which are defined by
means of the inner product. ♢We can find
approximate
solutions to
unsolvable linear
equation systems
using projections.Projections allow us to look at situations where we have a linear system
Ax=bwithout a solution. Recall that this means that bdoes not lie in
the span of A, i.e., the vector bdoes not lie in the subspace spanned by
the columns of A. Given that the linear equation cannot be solved exactly,
we can find an approximate solution . The idea is to find the vector in the
subspace spanned by the columns of Athat is closest to b, i.e., we compute
the orthogonal projection of bonto the subspace spanned by the columns
ofA. This problem arises often in practice, and the solution is called the
least-squares solution (assuming the dot product as the inner product) of least-squares
solution an overdetermined system. This is discussed further in Section 9.4. Using
reconstruction errors (3.63) is one possible approach to derive principal
component analysis (Section 10.3).
Remark. We just looked at projections of vectors xonto a subspace Uwith
basis vectors {b1, . . . ,bk}. If this basis is an ONB, i.e., (3.33) and (3.34)
are satisfied, the projection equation (3.58) simplifies greatly to
πU(x) =BB⊤x (3.65)
sinceB⊤B=Iwith coordinates
λ=B⊤x. (3.66)
This means that we no longer have to compute the inverse from (3.58),
which saves computation time. ♢
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
3.8 Orthogonal Projections 89
3.8.3 Gram-Schmidt Orthogonalization
Projections are at the core of the Gram-Schmidt method that allows us to
constructively transform any basis (b1, . . . ,bn)of an n-dimensional vector
space Vinto an orthogonal/orthonormal basis (u1, . . . ,un)ofV. This
basis always exists (Liesen and Mehrmann, 2015) and span[b1, . . . ,bn] =
span[u1, . . . ,un]. The Gram-Schmidt orthogonalization method iteratively Gram-Schmidt
orthogonalization constructs an orthogonal basis (u1, . . . ,un)from any basis (b1, . . . ,bn)of
Vas follows:
u1:=b1 (3.67)
uk:=bk−πspan[u1,...,uk−1](bk), k = 2, . . . , n . (3.68)
In (3.68), the kth basis vector bkis projected onto the subspace spanned
by the first k−1constructed orthogonal vectors u1, . . . ,uk−1; see Sec-
tion 3.8.2. This projection is then subtracted from bkand yields a vector
ukthat is orthogonal to the (k−1)-dimensional subspace spanned by
u1, . . . ,uk−1. Repeating this procedure for all nbasis vectors b1, . . . ,bn
yields an orthogonal basis (u1, . . . ,un)ofV. If we normalize the uk, we
obtain an ONB where ∥uk∥= 1fork= 1, . . . , n .
Example 3.12 (Gram-Schmidt Orthogonalization)
Figure 3.12
Gram-Schmidt
orthogonalization.
(a) non-orthogonal
basis (b1,b2)ofR2;
(b) first constructed
basis vector u1and
orthogonal
projection of b2
ontospan[u1];
(c) orthogonal basis
(u1,u2)ofR2.b1b2
0
(a) Original non-orthogonal
basis vectors b1,b2.u1b2
0 πspan[u1](b2)
(b) First new basis vector
u1=b1and projection of b2
onto the subspace spanned by
u1.u1b2
0 πspan[u1](b2)u2
(c) Orthogonal basis vectors u1
andu2=b2−πspan[u1](b2).
Consider a basis (b1,b2)ofR2, where
b1=2
0
,b2=1
1
; (3.69)
see also Figure 3.12(a). Using the Gram-Schmidt method, we construct an
orthogonal basis (u1,u2)ofR2as follows (assuming the dot product as
the inner product):
u1:=b1=2
0
, (3.70)
u2:=b2−πspan[u1](b2)(3.45)=b2−u1u⊤
1
∥u1∥2b2=1
1
−1 0
0 01
1
=0
1
.
(3.71)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
90 Analytic Geometry
Figure 3.13
Projection onto an
affine space.
(a) original setting;
(b) setting shifted
by−x0so that
x−x0can be
projected onto the
direction space U;
(c) projection is
translated back to
x0+πU(x−x0),
which gives the final
orthogonal
projection πL(x).L
x0x
b2
b1 0
(a) Setting.b1 0x−x0
U=L−x0
πU(x−x0)b2
(b) Reduce problem to pro-
jection πUonto vector sub-
space.L
x0x
b2
b1 0πL(x)
(c) Add support point back in
to get affine projection πL.
These steps are illustrated in Figures 3.12(b) and (c). We immediately see
thatu1andu2are orthogonal, i.e., u⊤
1u2= 0.
3.8.4 Projection onto Affine Subspaces
Thus far, we discussed how to project a vector onto a lower-dimensional
subspace U. In the following, we provide a solution to projecting a vector
onto an affine subspace.
Consider the setting in Figure 3.13(a). We are given an affine space L=
x0+U, where b1,b2are basis vectors of U. To determine the orthogonal
projection πL(x)ofxonto L, we transform the problem into a problem
that we know how to solve: the projection onto a vector subspace. In
order to get there, we subtract the support point x0fromxand from L,
so that L−x0=Uis exactly the vector subspace U. We can now use the
orthogonal projections onto a subspace we discussed in Section 3.8.2 and
obtain the projection πU(x−x0), which is illustrated in Figure 3.13(b).
This projection can now be translated back into Lby adding x0, such that
we obtain the orthogonal projection onto an affine space Las
πL(x) =x0+πU(x−x0), (3.72)
where πU(·)is the orthogonal projection onto the subspace U, i.e., the
direction space of L; see Figure 3.13(c).
From Figure 3.13, it is also evident that the distance of xfrom the affine
space Lis identical to the distance of x−x0from U, i.e.,
d(x, L) =∥x−πL(x)∥=∥x−(x0+πU(x−x0))∥ (3.73a)
=d(x−x0, πU(x−x0)) =d(x−x0, U). (3.73b)
We will use projections onto an affine subspace to derive the concept of
a separating hyperplane in Section 12.1.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
3.9 Rotations 91
Figure 3.14 A
rotation rotates
objects in a plane
about the origin. If
the rotation angle is
positive, we rotate
counterclockwise.
Original
Rotated by 112.5◦
Figure 3.15 The
robotic arm needs to
rotate its joints in
order to pick up
objects or to place
them correctly.
Figure taken
from (Deisenroth
et al., 2015).
3.9 Rotations
Length and angle preservation, as discussed in Section 3.4, are the two
characteristics of linear mappings with orthogonal transformation matri-
ces. In the following, we will have a closer look at specific orthogonal
transformation matrices, which describe rotations.
Arotation is a linear mapping (more specifically, an automorphism of rotation
a Euclidean vector space) that rotates a plane by an angle θabout the
origin, i.e., the origin is a fixed point. For a positive angle θ >0, by com-
mon convention, we rotate in a counterclockwise direction. An example is
shown in Figure 3.14, where the transformation matrix is
R=−0.38−0.92
0.92−0.38
. (3.74)
Important application areas of rotations include computer graphics and
robotics. For example, in robotics, it is often important to know how to
rotate the joints of a robotic arm in order to pick up or place an object,
see Figure 3.15.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
92 Analytic Geometry
Figure 3.16
Rotation of the
standard basis in R2
by an angle θ.
e1e2
θθΦ(e2) = [−sinθ,cosθ]⊤
Φ(e1) = [cos θ,sinθ]⊤
cosθsinθ
−sinθcosθ
3.9.1 Rotations in R2
Consider the standard basis
e1=1
0
,e2=0
1
ofR2, which defines
the standard coordinate system in R2. We aim to rotate this coordinate
system by an angle θas illustrated in Figure 3.16. Note that the rotated
vectors are still linearly independent and, therefore, are a basis of R2. This
means that the rotation performs a basis change.
Rotations Φare linear mappings so that we can express them by a
rotation matrix R(θ). Trigonometry (see Figure 3.16) allows us to de- rotation matrix
termine the coordinates of the rotated axes (the image of Φ) with respect
to the standard basis in R2. We obtain
Φ(e1) =cosθ
sinθ
,Φ(e2) =−sinθ
cosθ
. (3.75)
Therefore, the rotation matrix that performs the basis change into the
rotated coordinates R(θ)is given as
R(θ) =Φ(e1) Φ(e2)=cosθ−sinθ
sinθcosθ
. (3.76)
3.9.2 Rotations in R3
In contrast to the R2case, in R3we can rotate any two-dimensional plane
about a one-dimensional axis. The easiest way to specify the general rota-
tion matrix is to specify how the images of the standard basis e1,e2,e3are
supposed to be rotated, and making sure these images Re1,Re2,Re3are
orthonormal to each other. We can then obtain a general rotation matrix
Rby combining the images of the standard basis.
To have a meaningful rotation angle, we have to define what “coun-
terclockwise” means when we operate in more than two dimensions. We
use the convention that a “counterclockwise” (planar) rotation about an
axis refers to a rotation about an axis when we look at the axis “head on,
from the end toward the origin”. In R3, there are therefore three (planar)
rotations about the three standard basis vectors (see Figure 3.17):
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
3.9 Rotations 93
Figure 3.17
Rotation of a vector
(gray) in R3by an
angle θabout the
e3-axis. The rotated
vector is shown in
blue.
e1e2e3
θ
Rotation about the e1-axis
R1(θ) =Φ(e1) Φ(e2) Φ(e3)=
1 0 0
0 cos θ−sinθ
0 sin θcosθ
.(3.77)
Here, the e1coordinate is fixed, and the counterclockwise rotation is
performed in the e2e3plane.
Rotation about the e2-axis
R2(θ) =
cosθ0 sin θ
0 1 0
−sinθ0 cos θ
. (3.78)
If we rotate the e1e3plane about the e2axis, we need to look at the e2
axis from its “tip” toward the origin.
Rotation about the e3-axis
R3(θ) =
cosθ−sinθ0
sinθcosθ0
0 0 1
. (3.79)
Figure 3.17 illustrates this.
3.9.3 Rotations in nDimensions
The generalization of rotations from 2D and 3D to n-dimensional Eu-
clidean vector spaces can be intuitively described as fixing n−2dimen-
sions and restrict the rotation to a two-dimensional plane in the n-dimen-
sional space. As in the three-dimensional case, we can rotate any plane
(two-dimensional subspace of Rn).
Definition 3.11 (Givens Rotation) .LetVbe an n-dimensional Euclidean
vector space and Φ :V→Van automorphism with transformation ma-
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
94 Analytic Geometry
trix
Rij(θ) :=
Ii−10 ··· ··· 0
0cosθ 0−sinθ0
0 0 Ij−i−10 0
0 sinθ 0 cosθ 0
0··· ··· 0 In−j
∈Rn×n,(3.80)
for1⩽i < j⩽nandθ∈R. Then Rij(θ)is called a Givens rotation . Givens rotation
Essentially, Rij(θ)is the identity matrix Inwith
rii= cos θ , r ij=−sinθ , r ji= sin θ , r jj= cos θ . (3.81)
In two dimensions (i.e., n= 2), we obtain (3.76) as a special case.
3.9.4 Properties of Rotations
Rotations exhibit a number of useful properties, which can be derived by
considering them as orthogonal matrices (Definition 3.8):
Rotations preserve distances, i.e., ∥x−y∥=∥Rθ(x)−Rθ(y)∥. In other
words, rotations leave the distance between any two points unchanged
after the transformation.
Rotations preserve angles, i.e., the angle between RθxandRθyequals
the angle between xandy.
Rotations in three (or more) dimensions are generally not commuta-
tive. Therefore, the order in which rotations are applied is important,
even if they rotate about the same point. Only in two dimensions vector
rotations are commutative, such that R(ϕ)R(θ) =R(θ)R(ϕ)for all
ϕ, θ∈[0,2π). They form an Abelian group (with multiplication) only if
they rotate about the same point (e.g., the origin).
3.10 Further Reading
In this chapter, we gave a brief overview of some of the important concepts
of analytic geometry, which we will use in later chapters of the book.
For a broader and more in-depth overview of some of the concepts we
presented, we refer to the following excellent books: Axler (2015) and
Boyd and Vandenberghe (2018).
Inner products allow us to determine specific bases of vector (sub)spaces,
where each vector is orthogonal to all others (orthogonal bases) using the
Gram-Schmidt method. These bases are important in optimization and
numerical algorithms for solving linear equation systems. For instance,
Krylov subspace methods, such as conjugate gradients or the generalized
minimal residual method (GMRES), minimize residual errors that are or-
thogonal to each other (Stoer and Burlirsch, 2002).
In machine learning, inner products are important in the context of
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
3.10 Further Reading 95
kernel methods (Sch ¨olkopf and Smola, 2002). Kernel methods exploit the
fact that many linear algorithms can be expressed purely by inner prod-
uct computations. Then, the “kernel trick” allows us to compute these
inner products implicitly in a (potentially infinite-dimensional) feature
space, without even knowing this feature space explicitly. This allowed the
“non-linearization” of many algorithms used in machine learning, such as
kernel-PCA (Sch ¨olkopf et al., 1997) for dimensionality reduction. Gaus-
sian processes (Rasmussen and Williams, 2006) also fall into the category
of kernel methods and are the current state of the art in probabilistic re-
gression (fitting curves to data points). The idea of kernels is explored
further in Chapter 12.
Projections are often used in computer graphics, e.g., to generate shad-
ows. In optimization, orthogonal projections are often used to (iteratively)
minimize residual errors. This also has applications in machine learning,
e.g., in linear regression where we want to find a (linear) function that
minimizes the residual errors, i.e., the lengths of the orthogonal projec-
tions of the data onto the linear function (Bishop, 2006). We will investi-
gate this further in Chapter 9. PCA (Pearson, 1901; Hotelling, 1933) also
uses projections to reduce the dimensionality of high-dimensional data.
We will discuss this in more detail in Chapter 10.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
96 Analytic Geometry
Exercises
3.1 Show that ⟨·,·⟩defined for all x= [x1, x2]⊤∈R2andy= [y1, y2]⊤∈R2by
⟨x,y⟩:=x1y1−(x1y2+x2y1) + 2( x2y2)
is an inner product.
3.2 Consider R2with⟨·,·⟩defined for all xandyinR2as
⟨x,y⟩:=x⊤
2 0
1 2
|{z}
=:Ay.
Is⟨·,·⟩an inner product?
3.3 Compute the distance between
x=
1
2
3
,y=
−1
−1
0

using
a.⟨x,y⟩:=x⊤y
b.⟨x,y⟩:=x⊤Ay,A:=
2 1 0
1 3 −1
0−1 2

3.4 Compute the angle between
x=
1
2
,y=
−1
−1
using
a.⟨x,y⟩:=x⊤y
b.⟨x,y⟩:=x⊤By,B:=
2 1
1 3
3.5 Consider the Euclidean vector space R5with the dot product. A subspace
U⊆R5andx∈R5are given by
U= span[
0
−1
2
0
2
,
1
−3
1
−1
2
,
−3
4
1
2
1
,
−1
−3
5
0
7
],x=
−1
−9
−1
4
1
.
a. Determine the orthogonal projection πU(x)ofxonto U
b. Determine the distance d(x, U)
3.6 Consider R3with the inner product
⟨x,y⟩:=x⊤
2 1 0
1 2 −1
0−1 2
y.
Furthermore, we define e1,e2,e3as the standard/canonical basis in R3.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
Exercises 97
a. Determine the orthogonal projection πU(e2)ofe2onto
U= span[ e1,e3].
Hint: Orthogonality is defined through the inner product.
b. Compute the distance d(e2, U).
c. Draw the scenario: standard basis vectors and πU(e2)
3.7 Let Vbe a vector space and πan endomorphism of V.
a. Prove that πis a projection if and only if idV−πis a projection, where
idVis the identity endomorphism on V.
b. Assume now that πis a projection. Calculate Im(id V−π)andker(id V−π)
as a function of Im(π)andker(π).
3.8 Using the Gram-Schmidt method, turn the basis B= (b1,b2)of a two-
dimensional subspace U⊆R3into an ONB C= (c1,c2)ofU, where
b1:=
1
1
1
,b2:=
−1
2
0
.
3.9 Let n∈Nand let x1, . . . , x n>0benpositive real numbers so that x1+
. . .+xn= 1. Use the Cauchy-Schwarz inequality and show that
a.Pn
i=1x2
i⩾1
n
b.Pn
i=11
xi⩾n2
Hint: Think about the dot product on Rn. Then, choose specific vectors
x,y∈Rnand apply the Cauchy-Schwarz inequality.
3.10 Rotate the vectors
x1:=
2
3
,x2:=
0
−1
by30◦.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
4
Matrix Decompositions
In Chapters 2 and 3, we studied ways to manipulate and measure vectors,
projections of vectors, and linear mappings. Mappings and transforma-
tions of vectors can be conveniently described as operations performed by
matrices. Moreover, data is often represented in matrix form as well, e.g.,
where the rows of the matrix represent different people and the columns
describe different features of the people, such as weight, height, and socio-
economic status. In this chapter, we present three aspects of matrices: how
to summarize matrices, how matrices can be decomposed, and how these
decompositions can be used for matrix approximations.
We first consider methods that allow us to describe matrices with just
a few numbers that characterize the overall properties of matrices. We
will do this in the sections on determinants (Section 4.1) and eigenval-
ues (Section 4.2) for the important special case of square matrices. These
characteristic numbers have important mathematical consequences and
allow us to quickly grasp what useful properties a matrix has. From here
we will proceed to matrix decomposition methods: An analogy for ma-
trix decomposition is the factoring of numbers, such as the factoring of
21into prime numbers 7·3. For this reason matrix decomposition is also
often referred to as matrix factorization . Matrix decompositions are used matrix factorization
to describe a matrix by means of a different representation using factors
of interpretable matrices.
We will first cover a square-root-like operation for symmetric, positive
definite matrices, the Cholesky decomposition (Section 4.3). From here
we will look at two related methods for factorizing matrices into canoni-
cal forms. The first one is known as matrix diagonalization (Section 4.4),
which allows us to represent the linear mapping using a diagonal trans-
formation matrix if we choose an appropriate basis. The second method,
singular value decomposition (Section 4.5), extends this factorization to
non-square matrices, and it is considered one of the fundamental concepts
in linear algebra. These decompositions are helpful, as matrices represent-
ing numerical data are often very large and hard to analyze. We conclude
the chapter with a systematic overview of the types of matrices and the
characteristic properties that distinguish them in the form of a matrix tax-
onomy (Section 4.7).
The methods that we cover in this chapter will become important in
98
This material is published by Cambridge University Press as Mathematics for Machine Learning by
Marc Peter Deisenroth, A. Aldo Faisal, and Cheng Soon Ong (2020). This version is free to view
and download for personal use only. Not for re-distribution, re-sale, or use in derivative works.
©by M. P. Deisenroth, A. A. Faisal, and C. S. Ong, 2024. https://mml-book.com .
4.1 Determinant and Trace 99
Figure 4.1 A mind
map of the concepts
introduced in this
chapter, along with
where they are used
in other parts of the
book.Determinant Invertibility Cholesky
Eigenvalues
Eigenvectors Orthogonal matrix Diagonalization
SVDChapter 6
Probability
& distributions
Chapter 10
Dimensionality
reductiontests used inused in
used in determines
used in
used in
used inconstructs used in
used inused in
both subsequent mathematical chapters, such as Chapter 6, but also in
applied chapters, such as dimensionality reduction in Chapters 10 or den-
sity estimation in Chapter 11. This chapter’s overall structure is depicted
in the mind map of Figure 4.1.
4.1 Determinant and TraceThe determinant
notation |A|must
not be confused
with the absolute
value.Determinants are important concepts in linear algebra. A determinant is
a mathematical object in the analysis and solution of systems of linear
equations. Determinants are only defined for square matrices A∈Rn×n,
i.e., matrices with the same number of rows and columns. In this book,
we write the determinant as det(A)or sometimes as |A|so that
det(A) =a11a12. . . a 1n
a21a22. . . a 2n
.........
an1an2. . . a nn. (4.1)
Thedeterminant of a square matrix A∈Rn×nis a function that maps A determinant
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
100 Matrix Decompositions
onto a real number. Before providing a definition of the determinant for
general n×nmatrices, let us have a look at some motivating examples,
and define determinants for some special matrices.
Example 4.1 (Testing for Matrix Invertibility)
Let us begin with exploring if a square matrix Ais invertible (see Sec-
tion 2.2.2). For the smallest cases, we already know when a matrix
is invertible. If Ais a1×1matrix, i.e., it is a scalar number, then
A=a=⇒A−1=1
a. Thus a1
a= 1holds, if and only if a̸= 0.
For2×2matrices, by the definition of the inverse (Definition 2.3), we
know that AA−1=I. Then, with (2.24), the inverse of Ais
A−1=1
a11a22−a12a21a22−a12
−a21a11
. (4.2)
Hence, Ais invertible if and only if
a11a22−a12a21̸= 0. (4.3)
This quantity is the determinant of A∈R2×2, i.e.,
det(A) =a11a12
a21a22=a11a22−a12a21. (4.4)
Example 4.1 points already at the relationship between determinants
and the existence of inverse matrices. The next theorem states the same
result for n×nmatrices.
Theorem 4.1. For any square matrix A∈Rn×nit holds that Ais invertible
if and only if det(A)̸= 0.
We have explicit (closed-form) expressions for determinants of small
matrices in terms of the elements of the matrix. For n= 1,
det(A) = det( a11) =a11. (4.5)
Forn= 2,
det(A) =a11a12
a21a22=a11a22−a12a21, (4.6)
which we have observed in the preceding example.
Forn= 3(known as Sarrus’ rule),
a11a12a13
a21a22a23
a31a32a33=a11a22a33+a21a32a13+a31a12a23 (4.7)
−a31a22a13−a11a32a23−a21a12a33.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
4.1 Determinant and Trace 101
For a memory aid of the product terms in Sarrus’ rule, try tracing the
elements of the triple products in the matrix.
We call a square matrix Tanupper-triangular matrix ifTij= 0 for upper-triangular
matrix i > j , i.e., the matrix is zero below its diagonal. Analogously, we define a
lower-triangular matrix as a matrix with zeros above its diagonal. For a tri- lower-triangular
matrix angular matrix T∈Rn×n, the determinant is the product of the diagonal
elements, i.e.,
det(T) =nY
i=1Tii. (4.8)
The determinant is
the signed volume
of the parallelepiped
formed by the
columns of the
matrix.
Figure 4.2 The area
of the parallelogram
(shaded region)
spanned by the
vectors bandgis
|det([b,g])|.
b
g
Figure 4.3 The
volume of the
parallelepiped
(shaded volume)
spanned by vectors
r,b,gis
|det([r,b,g])|.
b
grExample 4.2 (Determinants as Measures of Volume)
The notion of a determinant is natural when we consider it as a mapping
from a set of nvectors spanning an object in Rn. It turns out that the de-
terminant det(A)is the signed volume of an n-dimensional parallelepiped
formed by columns of the matrix A.
Forn= 2, the columns of the matrix form a parallelogram; see Fig-
ure 4.2. As the angle between vectors gets smaller, the area of a parallel-
ogram shrinks, too. Consider two vectors b,gthat form the columns of a
matrix A= [b,g]. Then, the absolute value of the determinant of Ais the
area of the parallelogram with vertices 0,b,g,b+g. In particular, if b,g
are linearly dependent so that b=λgfor some λ∈R, they no longer
form a two-dimensional parallelogram. Therefore, the corresponding area
is0. On the contrary, if b,gare linearly independent and are multiples of
the canonical basis vectors e1,e2then they can be written as b=b
0
and
g=0
g
, and the determinant isb0
0g=bg−0 =bg.
The sign of the determinant indicates the orientation of the spanning
vectors b,gwith respect to the standard basis (e1,e2). In our figure, flip-
ping the order to g,bswaps the columns of Aand reverses the orientation
of the shaded area. This becomes the familiar formula: area =height ×
length. This intuition extends to higher dimensions. In R3, we consider
three vectors r,b,g∈R3spanning the edges of a parallelepiped, i.e., a
solid with faces that are parallel parallelograms (see Figure 4.3). The ab- The sign of the
determinant
indicates the
orientation of the
spanning vectors.solute value of the determinant of the 3×3matrix [r,b,g]is the volume
of the solid. Thus, the determinant acts as a function that measures the
signed volume formed by column vectors composed in a matrix.
Consider the three linearly independent vectors r,g,b∈R3given as
r=
2
0
−8
,g=
6
1
0
,b=
1
4
−1
. (4.9)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
102 Matrix Decompositions
Writing these vectors as the columns of a matrix
A= [r,g,b] =
2 6 1
0 1 4
−8 0 −1
 (4.10)
allows us to compute the desired volume as
V=|det(A)|= 186 . (4.11)
Computing the determinant of an n×nmatrix requires a general algo-
rithm to solve the cases for n >3, which we are going to explore in the fol-
lowing. Theorem 4.2 below reduces the problem of computing the deter-
minant of an n×nmatrix to computing the determinant of (n−1)×(n−1)
matrices. By recursively applying the Laplace expansion (Theorem 4.2),
we can therefore compute determinants of n×nmatrices by ultimately
computing determinants of 2×2matrices.
Laplace expansion
Theorem 4.2 (Laplace Expansion) .Consider a matrix A∈Rn×n. Then,
for all j= 1, . . . , n :
1. Expansion along column j det(Ak,j)is called
aminor and
(−1)k+jdet(Ak,j)
acofactor .det(A) =nX
k=1(−1)k+jakjdet(Ak,j). (4.12)
2. Expansion along row j
det(A) =nX
k=1(−1)k+jajkdet(Aj,k). (4.13)
HereAk,j∈R(n−1)×(n−1)is the submatrix of Athat we obtain when delet-
ing row kand column j.
Example 4.3 (Laplace Expansion)
Let us compute the determinant of
A=
1 2 3
3 1 2
0 0 1
 (4.14)
using the Laplace expansion along the first row. Applying (4.13) yields
1 2 3
3 1 2
0 0 1= (−1)1+1·11 2
0 1
+ (−1)1+2·23 2
0 1+ (−1)1+3·33 1
0 0.(4.15)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
4.1 Determinant and Trace 103
We use (4.6) to compute the determinants of all 2×2matrices and obtain
det(A) = 1(1 −0)−2(3−0) + 3(0 −0) =−5. (4.16)
For completeness we can compare this result to computing the determi-
nant using Sarrus’ rule (4.7):
det(A) = 1·1·1+3·0·3+0·2·2−0·1·3−1·0·2−3·2·1 = 1−6 =−5.(4.17)
ForA∈Rn×nthe determinant exhibits the following properties:
The determinant of a matrix product is the product of the corresponding
determinants, det(AB) = det( A)det(B).
Determinants are invariant to transposition, i.e., det(A) = det( A⊤).
IfAis regular (invertible), then det(A−1) =1
det(A).
Similar matrices (Definition 2.22) possess the same determinant. There-
fore, for a linear mapping Φ :V→Vall transformation matrices AΦ
ofΦhave the same determinant. Thus, the determinant is invariant to
the choice of basis of a linear mapping.
Adding a multiple of a column/row to another one does not change
det(A).
Multiplication of a column/row with λ∈Rscales det(A)byλ. In
particular, det(λA) =λndet(A).
Swapping two rows/columns changes the sign of det(A).
Because of the last three properties, we can use Gaussian elimination (see
Section 2.1) to compute det(A)by bringing Ainto row-echelon form.
We can stop Gaussian elimination when we have Ain a triangular form
where the elements below the diagonal are all 0. Recall from (4.8) that the
determinant of a triangular matrix is the product of the diagonal elements.
Theorem 4.3. A square matrix A∈Rn×nhasdet(A)̸= 0if and only if
rk(A) =n. In other words, Ais invertible if and only if it is full rank.
When mathematics was mainly performed by hand, the determinant
calculation was considered an essential way to analyze matrix invertibil-
ity. However, contemporary approaches in machine learning use direct
numerical methods that superseded the explicit calculation of the deter-
minant. For example, in Chapter 2, we learned that inverse matrices can
be computed by Gaussian elimination. Gaussian elimination can thus be
used to compute the determinant of a matrix.
Determinants will play an important theoretical role for the following
sections, especially when we learn about eigenvalues and eigenvectors
(Section 4.2) through the characteristic polynomial.
Definition 4.4. Thetrace of a square matrix A∈Rn×nis defined as trace
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
104 Matrix Decompositions
tr(A) :=nX
i=1aii, (4.18)
i.e. , the trace is the sum of the diagonal elements of A.
The trace satisfies the following properties:
tr(A+B) =tr(A) +tr(B)forA,B∈Rn×n
tr(αA) =αtr(A), α∈RforA∈Rn×n
tr(In) =n
tr(AB) =tr(BA)forA∈Rn×k,B∈Rk×n
It can be shown that only one function satisfies these four properties to-
gether – the trace (Gohberg et al., 2012).
The properties of the trace of matrix products are more general. Specif-
ically, the trace is invariant under cyclic permutations, i.e., The trace is
invariant under
cyclic permutations. tr(AKL ) =tr(KLA ) (4.19)
for matrices A∈Ra×k,K∈Rk×l,L∈Rl×a. This property generalizes to
products of an arbitrary number of matrices. As a special case of (4.19), it
follows that for two vectors x,y∈Rn
tr(xy⊤) =tr(y⊤x) =y⊤x∈R. (4.20)
Given a linear mapping Φ :V→V, where Vis a vector space, we
define the trace of this map by using the trace of matrix representation
ofΦ. For a given basis of V, we can describe Φby means of the transfor-
mation matrix A. Then the trace of Φis the trace of A. For a different
basis of V, it holds that the corresponding transformation matrix BofΦ
can be obtained by a basis change of the form S−1ASfor suitable S(see
Section 2.7.2). For the corresponding trace of Φ, this means
tr(B) =tr(S−1AS)(4.19)=tr(ASS−1) =tr(A). (4.21)
Hence, while matrix representations of linear mappings are basis depen-
dent the trace of a linear mapping Φis independent of the basis.
In this section, we covered determinants and traces as functions char-
acterizing a square matrix. Taking together our understanding of determi-
nants and traces we can now define an important equation describing a
matrix Ain terms of a polynomial, which we will use extensively in the
following sections.
Definition 4.5 (Characteristic Polynomial) .Forλ∈Rand a square ma-
trixA∈Rn×n
pA(λ) := det( A−λI) (4.22a)
=c0+c1λ+c2λ2+···+cn−1λn−1+ (−1)nλn, (4.22b)
c0, . . . , c n−1∈R, is the characteristic polynomial ofA. In particular, characteristic
polynomial
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
4.2 Eigenvalues and Eigenvectors 105
c0= det( A), (4.23)
cn−1= (−1)n−1tr(A). (4.24)
The characteristic polynomial (4.22a) will allow us to compute eigen-
values and eigenvectors, covered in the next section.
4.2 Eigenvalues and Eigenvectors
We will now get to know a new way to characterize a matrix and its associ-
ated linear mapping. Recall from Section 2.7.1 that every linear mapping
has a unique transformation matrix given an ordered basis. We can in-
terpret linear mappings and their associated transformation matrices by
performing an “eigen” analysis. As we will see, the eigenvalues of a lin- Eigen is a German
word meaning
“characteristic”,
“self”, or “own”.ear mapping will tell us how a special set of vectors, the eigenvectors, is
transformed by the linear mapping.
Definition 4.6. LetA∈Rn×nbe a square matrix. Then λ∈Ris an
eigenvalue ofAandx∈Rn\{0}is the corresponding eigenvector ofAif eigenvalue
eigenvectorAx=λx. (4.25)
We call (4.25) the eigenvalue equation . eigenvalue equation
Remark. In the linear algebra literature and software, it is often a conven-
tion that eigenvalues are sorted in descending order, so that the largest
eigenvalue and associated eigenvector are called the first eigenvalue and
its associated eigenvector, and the second largest called the second eigen-
value and its associated eigenvector, and so on. However, textbooks and
publications may have different or no notion of orderings. We do not want
to presume an ordering in this book if not stated explicitly. ♢
The following statements are equivalent:
λis an eigenvalue of A∈Rn×n.
There exists an x∈Rn\{0}withAx=λx, or equivalently, (A−
λIn)x=0can be solved non-trivially, i.e., x̸=0.
rk(A−λIn)< n.
det(A−λIn) = 0 .
Definition 4.7 (Collinearity and Codirection) .Two vectors that point in
the same direction are called codirected . Two vectors are collinear if they codirected
collinear point in the same or the opposite direction.
Remark (Non-uniqueness of eigenvectors) .Ifxis an eigenvector of A
associated with eigenvalue λ, then for any c∈R\{0}it holds that cxis
an eigenvector of Awith the same eigenvalue since
A(cx) =cAx=cλx=λ(cx). (4.26)
Thus, all vectors that are collinear to xare also eigenvectors of A.
♢
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
106 Matrix Decompositions
Theorem 4.8. λ∈Ris an eigenvalue of A∈Rn×nif and only if λis a
root of the characteristic polynomial pA(λ)ofA.
Definition 4.9. Let a square matrix Ahave an eigenvalue λi. The algebraic algebraic
multiplicity multiplicity ofλiis the number of times the root appears in the character-
istic polynomial.
Definition 4.10 (Eigenspace and Eigenspectrum) .ForA∈Rn×n, the set
of all eigenvectors of Aassociated with an eigenvalue λspans a subspace
ofRn, which is called the eigenspace ofAwith respect to λand is denoted eigenspace
byEλ. The set of all eigenvalues of Ais called the eigenspectrum , or just eigenspectrum
spectrum , ofA. spectrum
Ifλis an eigenvalue of A∈Rn×n, then the corresponding eigenspace
Eλis the solution space of the homogeneous system of linear equations
(A−λI)x=0. Geometrically, the eigenvector corresponding to a nonzero
eigenvalue points in a direction that is stretched by the linear mapping.
The eigenvalue is the factor by which it is stretched. If the eigenvalue is
negative, the direction of the stretching is flipped.
Example 4.4 (The Case of the Identity Matrix)
The identity matrix I∈Rn×nhas characteristic polynomial pI(λ) =
det(I−λI) = (1 −λ)n= 0, which has only one eigenvalue λ= 1that oc-
cursntimes. Moreover, Ix=λx= 1xholds for all vectors x∈Rn\{0}.
Because of this, the sole eigenspace E1of the identity matrix spans ndi-
mensions, and all nstandard basis vectors of Rnare eigenvectors of I.
Useful properties regarding eigenvalues and eigenvectors include the
following:
A matrix Aand its transpose A⊤possess the same eigenvalues, but not
necessarily the same eigenvectors.
The eigenspace Eλis the null space of A−λIsince
Ax=λx⇐⇒Ax−λx=0 (4.27a)
⇐⇒ (A−λI)x=0⇐⇒x∈ker(A−λI).(4.27b)
Similar matrices (see Definition 2.22) possess the same eigenvalues.
Therefore, a linear mapping Φhas eigenvalues that are independent of
the choice of basis of its transformation matrix. This makes eigenvalues,
together with the determinant and the trace, key characteristic param-
eters of a linear mapping as they are all invariant under basis change.
Symmetric, positive definite matrices always have positive, real eigen-
values.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
4.2 Eigenvalues and Eigenvectors 107
Example 4.5 (Computing Eigenvalues, Eigenvectors, and
Eigenspaces)
Let us find the eigenvalues and eigenvectors of the 2×2matrix
A=4 2
1 3
. (4.28)
Step 1: Characteristic Polynomial. From our definition of the eigen-
vector x̸=0and eigenvalue λofA, there will be a vector such that
Ax=λx, i.e., (A−λI)x=0. Since x̸=0, this requires that the kernel
(null space) of A−λIcontains more elements than just 0. This means
thatA−λIis not invertible and therefore det(A−λI) = 0 . Hence, we
need to compute the roots of the characteristic polynomial (4.22a) to find
the eigenvalues.
Step 2: Eigenvalues. The characteristic polynomial is
pA(λ) = det( A−λI) (4.29a)
= det4 2
1 3
−λ0
0λ
=4−λ 2
1 3 −λ(4.29b)
= (4−λ)(3−λ)−2·1. (4.29c)
We factorize the characteristic polynomial and obtain
p(λ) = (4 −λ)(3−λ)−2·1 = 10 −7λ+λ2= (2−λ)(5−λ)(4.30)
giving the roots λ1= 2andλ2= 5.
Step 3: Eigenvectors and Eigenspaces. We find the eigenvectors that
correspond to these eigenvalues by looking at vectors xsuch that
4−λ 2
1 3 −λ
x=0. (4.31)
Forλ= 5we obtain
4−5 2
1 3 −5x1
x2
=−1 2
1−2x1
x2
=0. (4.32)
We solve this homogeneous system and obtain a solution space
E5= span[2
1
]. (4.33)
This eigenspace is one-dimensional as it possesses a single basis vector.
Analogously, we find the eigenvector for λ= 2by solving the homoge-
neous system of equations
4−2 2
1 3 −2
x=2 2
1 1
x=0. (4.34)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
108 Matrix Decompositions
This means any vector x=x1
x2
, where x2=−x1, such as1
−1
, is an
eigenvector with eigenvalue 2. The corresponding eigenspace is given as
E2= span[1
−1
]. (4.35)
The two eigenspaces E5andE2in Example 4.5 are one-dimensional
as they are each spanned by a single vector. However, in other cases
we may have multiple identical eigenvalues (see Definition 4.9) and the
eigenspace may have more than one dimension.
Definition 4.11. Letλibe an eigenvalue of a square matrix A. Then the
geometric multiplicity ofλiis the number of linearly independent eigen- geometric
multiplicity vectors associated with λi. In other words, it is the dimensionality of the
eigenspace spanned by the eigenvectors associated with λi.
Remark. A specific eigenvalue’s geometric multiplicity must be at least
one because every eigenvalue has at least one associated eigenvector. An
eigenvalue’s geometric multiplicity cannot exceed its algebraic multiplic-
ity, but it may be lower. ♢
Example 4.6
The matrix A=2 1
0 2
has two repeated eigenvalues λ1=λ2= 2and an
algebraic multiplicity of 2. The eigenvalue has, however, only one distinct
unit eigenvector x1=1
0
and, thus, geometric multiplicity 1.
Graphical Intuition in Two Dimensions
Let us gain some intuition for determinants, eigenvectors, and eigenval-
ues using different linear mappings. Figure 4.4 depicts five transformation
matrices A1, . . . ,A5and their impact on a square grid of points, centered
at the origin: In geometry, the
area-preserving
properties of this
type of shearing
parallel to an axis is
also known as
Cavalieri’s principle
of equal areas for
parallelograms
(Katz, 2004).A1=1
20
0 2
. The direction of the two eigenvectors correspond to the
canonical basis vectors in R2, i.e., to two cardinal axes. The vertical axis
is extended by a factor of 2(eigenvalue λ1= 2), and the horizontal axis
is compressed by factor1
2(eigenvalue λ2=1
2). The mapping is area
preserving ( det(A1) = 1 = 2 ·1
2).
A2=11
2
0 1
corresponds to a shearing mapping , i.e., it shears the
points along the horizontal axis to the right if they are on the positive
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
4.2 Eigenvalues and Eigenvectors 109
Figure 4.4
Determinants and
eigenspaces.
Overview of five
linear mappings and
their associated
transformation
matrices
Ai∈R2×2
projecting 400
color-coded points
x∈R2(left
column) onto target
points Aix(right
column). The
central column
depicts the first
eigenvector,
stretched by its
associated
eigenvalue λ1, and
the second
eigenvector
stretched by its
eigenvalue λ2. Each
row depicts the
effect of one of five
transformation
matrices Aiwith
respect to the
standard basis.
det(A) = 1.01= 2.0
2= 0.5
det(A) = 1.01= 1.0
2= 1.0
det(A) = 1.01= (0.87-0.5j)
2= (0.87+0.5j)
det(A) = 0.01= 0.0
2= 2.0
det(A) = 0.751= 0.5
2= 1.5
half of the vertical axis, and to the left vice versa. This mapping is area
preserving ( det(A2) = 1 ). The eigenvalue λ1= 1 = λ2is repeated
and the eigenvectors are collinear (drawn here for emphasis in two
opposite directions). This indicates that the mapping acts only along
one direction (the horizontal axis).
A3=cos(π
6)−sin(π
6)
sin(π
6) cos(π
6)
=1
2√
3−1
1√
3
The matrix A3rotates the
points byπ
6rad = 30◦counter-clockwise and has only complex eigen-
values, reflecting that the mapping is a rotation (hence, no eigenvectors
are drawn). A rotation has to be volume preserving, and so the deter-
minant is 1. For more details on rotations, we refer to Section 3.9.
A4=1−1
−1 1
represents a mapping in the standard basis that col-
lapses a two-dimensional domain onto one dimension. Since one eigen-
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
110 Matrix Decompositions
value is 0, the space in direction of the (blue) eigenvector corresponding
toλ1= 0 collapses, while the orthogonal (red) eigenvector stretches
space by a factor λ2= 2. Therefore, the area of the image is 0.
A5=11
21
21
is a shear-and-stretch mapping that scales space by 75%
since|det(A5)|=3
4. It stretches space along the (red) eigenvector
ofλ2by a factor 1.5and compresses it along the orthogonal (blue)
eigenvector by a factor 0.5.
Example 4.7 (Eigenspectrum of a Biological Neural Network)
Figure 4.5
Caenorhabditis
elegans neural
network (Kaiser and
Hilgetag,
2006).(a) Sym-
metrized
connectivity matrix;
(b) Eigenspectrum.
0 50 100 150 200 250
neuron index0
50
100
150
200
250neuron index
(a) Connectivity matrix.
0 100 200
index of sorted eigenvalue 10 50510152025eigenvalue
 (b) Eigenspectrum.
Methods to analyze and learn from network data are an essential com-
ponent of machine learning methods. The key to understanding networks
is the connectivity between network nodes, especially if two nodes are
connected to each other or not. In data science applications, it is often
useful to study the matrix that captures this connectivity data.
We build a connectivity/adjacency matrix A∈R277×277of the complete
neural network of the worm C.Elegans . Each row/column represents one
of the 277neurons of this worm’s brain. The connectivity matrix Ahas
a value of aij= 1 if neuron italks to neuron jthrough a synapse, and
aij= 0 otherwise. The connectivity matrix is not symmetric, which im-
plies that eigenvalues may not be real valued. Therefore, we compute a
symmetrized version of the connectivity matrix as Asym:=A+A⊤. This
new matrix Asymis shown in Figure 4.5(a) and has a nonzero value aijif
and only if two neurons are connected (white pixels), irrespective of the
direction of the connection. In Figure 4.5(b), we show the correspond-
ing eigenspectrum of Asym. The horizontal axis shows the index of the
eigenvalues, sorted in descending order. The vertical axis shows the corre-
sponding eigenvalue. The S-like shape of this eigenspectrum is typical for
many biological neural networks. The underlying mechanism responsible
for this is an area of active neuroscience research.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
4.2 Eigenvalues and Eigenvectors 111
Theorem 4.12. The eigenvectors x1, . . . ,xnof a matrix A∈Rn×nwithn
distinct eigenvalues λ1, . . . , λ nare linearly independent.
This theorem states that eigenvectors of a matrix with ndistinct eigen-
values form a basis of Rn.
Definition 4.13. A square matrix A∈Rn×nisdefective if it possesses defective
fewer than nlinearly independent eigenvectors.
A non-defective matrix A∈Rn×ndoes not necessarily require ndis-
tinct eigenvalues, but it does require that the eigenvectors form a basis of
Rn. Looking at the eigenspaces of a defective matrix, it follows that the
sum of the dimensions of the eigenspaces is less than n. Specifically, a de-
fective matrix has at least one eigenvalue λiwith an algebraic multiplicity
m > 1and a geometric multiplicity of less than m.
Remark. A defective matrix cannot have ndistinct eigenvalues, as distinct
eigenvalues have linearly independent eigenvectors (Theorem 4.12). ♢
Theorem 4.14. Given a matrix A∈Rm×n, we can always obtain a sym-
metric, positive semidefinite matrix S∈Rn×nby defining
S:=A⊤A. (4.36)
Remark. Ifrk(A) =n, then S:=A⊤Ais symmetric, positive definite.
♢
Understanding why Theorem 4.14 holds is insightful for how we can
use symmetrized matrices: Symmetry requires S=S⊤, and by insert-
ing (4.36) we obtain S=A⊤A=A⊤(A⊤)⊤= (A⊤A)⊤=S⊤. More-
over, positive semidefiniteness (Section 3.2.3) requires that x⊤Sx⩾0
and inserting (4.36) we obtain x⊤Sx=x⊤A⊤Ax= (x⊤A⊤)(Ax) =
(Ax)⊤(Ax)⩾0, because the dot product computes a sum of squares
(which are themselves non-negative).
spectral theorem
Theorem 4.15 (Spectral Theorem) .IfA∈Rn×nis symmetric, there ex-
ists an orthonormal basis of the corresponding vector space Vconsisting of
eigenvectors of A, and each eigenvalue is real.
A direct implication of the spectral theorem is that the eigendecompo-
sition of a symmetric matrix Aexists (with real eigenvalues), and that
we can find an ONB of eigenvectors so that A=PDP⊤, where Dis
diagonal and the columns of Pcontain the eigenvectors.
Example 4.8
Consider the matrix
A=
3 2 2
2 3 2
2 2 3
. (4.37)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
112 Matrix Decompositions
The characteristic polynomial of Ais
pA(λ) =−(λ−1)2(λ−7), (4.38)
so that we obtain the eigenvalues λ1= 1 andλ2= 7, where λ1is a
repeated eigenvalue. Following our standard procedure for computing
eigenvectors, we obtain the eigenspaces
E1= span[
−1
1
0

|{z}
=:x1,
−1
0
1

|{z}
=:x2], E 7= span[
1
1
1

|{z}
=:x3]. (4.39)
We see that x3is orthogonal to both x1andx2. However, since x⊤
1x2=
1̸= 0, they are not orthogonal. The spectral theorem (Theorem 4.15)
states that there exists an orthogonal basis, but the one we have is not
orthogonal. However, we can construct one.
To construct such a basis, we exploit the fact that x1,x2are eigenvec-
tors associated with the same eigenvalue λ. Therefore, for any α, β∈Rit
holds that
A(αx1+βx2) =Ax1α+Ax2β=λ(αx1+βx2), (4.40)
i.e., any linear combination of x1andx2is also an eigenvector of Aas-
sociated with λ. The Gram-Schmidt algorithm (Section 3.8.3) is a method
for iteratively constructing an orthogonal/orthonormal basis from a set of
basis vectors using such linear combinations. Therefore, even if x1andx2
are not orthogonal, we can apply the Gram-Schmidt algorithm and find
eigenvectors associated with λ1= 1 that are orthogonal to each other
(and to x3). In our example, we will obtain
x′
1=
−1
1
0
,x′
2=1
2
−1
−1
2
, (4.41)
which are orthogonal to each other, orthogonal to x3, and eigenvectors of
Aassociated with λ1= 1.
Before we conclude our considerations of eigenvalues and eigenvectors
it is useful to tie these matrix characteristics together with the concepts of
the determinant and the trace.
Theorem 4.16. The determinant of a matrix A∈Rn×nis the product of
its eigenvalues, i.e.,
det(A) =nY
i=1λi, (4.42)
where λi∈Care (possibly repeated) eigenvalues of A.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
4.2 Eigenvalues and Eigenvectors 113
Figure 4.6
Geometric
interpretation of
eigenvalues. The
eigenvectors of A
get stretched by the
corresponding
eigenvalues. The
area of the unit
square changes by
|λ1λ2|, the
perimeter changes
by a factor of
1
2(|λ1|+|λ2|).x1x2
v1v2A
Theorem 4.17. The trace of a matrix A∈Rn×nis the sum of its eigenval-
ues, i.e.,
tr(A) =nX
i=1λi, (4.43)
where λi∈Care (possibly repeated) eigenvalues of A.
Let us provide a geometric intuition of these two theorems. Consider
a matrix A∈R2×2that possesses two linearly independent eigenvectors
x1,x2. For this example, we assume (x1,x2)are an ONB of R2so that they
are orthogonal and the area of the square they span is 1; see Figure 4.6.
From Section 4.1, we know that the determinant computes the change of
area of unit square under the transformation A. In this example, we can
compute the change of area explicitly: Mapping the eigenvectors using
Agives us vectors v1=Ax1=λ1x1andv2=Ax2=λ2x2, i.e., the
new vectors viare scaled versions of the eigenvectors xi, and the scaling
factors are the corresponding eigenvalues λi.v1,v2are still orthogonal,
and the area of the rectangle they span is |λ1λ2|.
Given that x1,x2(in our example) are orthonormal, we can directly
compute the perimeter of the unit square as 2(1 + 1) . Mapping the eigen-
vectors using Acreates a rectangle whose perimeter is 2(|λ1|+|λ2|).
Therefore, the sum of the absolute values of the eigenvalues tells us how
the perimeter of the unit square changes under the transformation matrix
A.
Example 4.9 (Google’s PageRank – Webpages as Eigenvectors)
Google uses the eigenvector corresponding to the maximal eigenvalue of
a matrix Ato determine the rank of a page for search. The idea for the
PageRank algorithm, developed at Stanford University by Larry Page and
Sergey Brin in 1996, was that the importance of any web page can be ap-
proximated by the importance of pages that link to it. For this, they write
down all web sites as a huge directed graph that shows which page links
to which. PageRank computes the weight (importance) xi⩾0of a web
siteaiby counting the number of pages pointing to ai. Moreover, PageR-
ank takes into account the importance of the web sites that link to ai. The
navigation behavior of a user is then modeled by a transition matrix Aof
this graph that tells us with what (click) probability somebody will end up
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
114 Matrix Decompositions
on a different web site. The matrix Ahas the property that for any ini-
tial rank/importance vector xof a web site the sequence x,Ax,A2x, . . .
converges to a vector x∗. This vector is called the PageRank and satisfies PageRank
Ax∗=x∗, i.e., it is an eigenvector (with corresponding eigenvalue 1) of
A. After normalizing x∗, such that ∥x∗∥= 1, we can interpret the entries
as probabilities. More details and different perspectives on PageRank can
be found in the original technical report (Page et al., 1999).
4.3 Cholesky Decomposition
There are many ways to factorize special types of matrices that we en-
counter often in machine learning. In the positive real numbers, we have
the square-root operation that gives us a decomposition of the number
into identical components, e.g., 9 = 3 ·3. For matrices, we need to be
careful that we compute a square-root-like operation on positive quanti-
ties. For symmetric, positive definite matrices (see Section 3.2.3), we can
choose from a number of square-root equivalent operations. The Cholesky Cholesky
decomposition decomposition /Cholesky factorization provides a square-root equivalent op-
Cholesky
factorizationeration on symmetric, positive definite matrices that is useful in practice.
Theorem 4.18 (Cholesky Decomposition) .A symmetric, positive definite
matrix Acan be factorized into a product A=LL⊤, where Lis a lower-
triangular matrix with positive diagonal elements:

a11···a1n
.........
an1···ann
=
l11··· 0
.........
ln1···lnn

l11···ln1
.........
0···lnn
. (4.44)
Lis called the Cholesky factor of A, andLis unique. Cholesky factor
Example 4.10 (Cholesky Factorization)
Consider a symmetric, positive definite matrix A∈R3×3. We are inter-
ested in finding its Cholesky factorization A=LL⊤, i.e.,
A=
a11a21a31
a21a22a32
a31a32a33
=LL⊤=
l110 0
l21l220
l31l32l33

l11l21l31
0l22l32
0 0 l33
.(4.45)
Multiplying out the right-hand side yields
A=
l2
11 l21l11 l31l11
l21l11 l2
21+l2
22 l31l21+l32l22
l31l11l31l21+l32l22l2
31+l2
32+l2
33
. (4.46)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
4.4 Eigendecomposition and Diagonalization 115
Comparing the left-hand side of (4.45) and the right-hand side of (4.46)
shows that there is a simple pattern in the diagonal elements lii:
l11=√a11, l 22=q
a22−l2
21, l 33=q
a33−(l2
31+l2
32).(4.47)
Similarly for the elements below the diagonal ( lij, where i > j ), there is
also a repeating pattern:
l21=1
l11a21, l 31=1
l11a31, l 32=1
l22(a32−l31l21). (4.48)
Thus, we constructed the Cholesky decomposition for any symmetric, pos-
itive definite 3×3matrix. The key realization is that we can backward
calculate what the components lijfor the Lshould be, given the values
aijforAand previously computed values of lij.
The Cholesky decomposition is an important tool for the numerical
computations underlying machine learning. Here, symmetric positive def-
inite matrices require frequent manipulation, e.g., the covariance matrix
of a multivariate Gaussian variable (see Section 6.5) is symmetric, positive
definite. The Cholesky factorization of this covariance matrix allows us to
generate samples from a Gaussian distribution. It also allows us to perform
a linear transformation of random variables, which is heavily exploited
when computing gradients in deep stochastic models, such as the varia-
tional auto-encoder (Jimenez Rezende et al., 2014; Kingma and Welling,
2014). The Cholesky decomposition also allows us to compute determi-
nants very efficiently. Given the Cholesky decomposition A=LL⊤, we
know that det(A) = det( L) det(L⊤) = det( L)2. Since Lis a triangular
matrix, the determinant is simply the product of its diagonal entries so
thatdet(A) =Q
il2
ii. Thus, many numerical software packages use the
Cholesky decomposition to make computations more efficient.
4.4 Eigendecomposition and Diagonalization
Adiagonal matrix is a matrix that has value zero on all off-diagonal ele- diagonal matrix
ments, i.e., they are of the form
D=
c1··· 0
.........
0···cn
. (4.49)
They allow fast computation of determinants, powers, and inverses. The
determinant is the product of its diagonal entries, a matrix power Dkis
given by each diagonal element raised to the power k, and the inverse
D−1is the reciprocal of its diagonal elements if all of them are nonzero.
In this section, we will discuss how to transform matrices into diagonal
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
116 Matrix Decompositions
form. This is an important application of the basis change we discussed in
Section 2.7.2 and eigenvalues from Section 4.2.
Recall that two matrices A,Dare similar (Definition 2.22) if there ex-
ists an invertible matrix P, such that D=P−1AP. More specifically, we
will look at matrices Athat are similar to diagonal matrices Dthat con-
tain the eigenvalues of Aon the diagonal.
Definition 4.19 (Diagonalizable) .A matrix A∈Rn×nisdiagonalizable diagonalizable
if it is similar to a diagonal matrix, i.e., if there exists an invertible matrix
P∈Rn×nsuch that D=P−1AP.
In the following, we will see that diagonalizing a matrix A∈Rn×nis
a way of expressing the same linear mapping but in another basis (see
Section 2.6.1), which will turn out to be a basis that consists of the eigen-
vectors of A.
LetA∈Rn×n, letλ1, . . . , λ nbe a set of scalars, and let p1, . . . ,pnbe a
set of vectors in Rn. We define P:= [p1, . . . ,pn]and let D∈Rn×nbe a
diagonal matrix with diagonal entries λ1, . . . , λ n. Then we can show that
AP=PD (4.50)
if and only if λ1, . . . , λ nare the eigenvalues of Aandp1, . . . ,pnare cor-
responding eigenvectors of A.
We can see that this statement holds because
AP=A[p1, . . . ,pn] = [Ap1, . . . ,Apn], (4.51)
PD= [p1, . . . ,pn]
λ1 0
...
0 λn
= [λ1p1, . . . , λ npn]. (4.52)
Thus, (4.50) implies that
Ap1=λ1p1 (4.53)
...
Apn=λnpn. (4.54)
Therefore, the columns of Pmust be eigenvectors of A.
Our definition of diagonalization requires that P∈Rn×nis invertible,
i.e.,Phas full rank (Theorem 4.3). This requires us to have nlinearly
independent eigenvectors p1, . . . ,pn, i.e., the piform a basis of Rn.
Theorem 4.20 (Eigendecomposition) .A square matrix A∈Rn×ncan be
factored into
A=PDP−1, (4.55)
where P∈Rn×nandDis a diagonal matrix whose diagonal entries are
the eigenvalues of A, if and only if the eigenvectors of Aform a basis of Rn.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
4.4 Eigendecomposition and Diagonalization 117
Figure 4.7 Intuition
behind the
eigendecomposition
as sequential
transformations.
Top-left to
bottom-left: P−1
performs a basis
change (here drawn
inR2and depicted
as a rotation-like
operation) from the
standard basis into
the eigenbasis.
Bottom-left to
bottom-right: D
performs a scaling
along the remapped
orthogonal
eigenvectors,
depicted here by a
circle being
stretched to an
ellipse. Bottom-right
to top-right: P
undoes the basis
change (depicted as
a reverse rotation)
and restores the
original coordinate
frame.
e1e2
p1p2
p1p2e1e2
p1p2
1p12p2
e1e2
Ae 1Ae 2P−1
DPA
Theorem 4.20 implies that only non-defective matrices can be diagonal-
ized and that the columns of Pare the neigenvectors of A. For symmetric
matrices we can obtain even stronger outcomes for the eigenvalue decom-
position.
Theorem 4.21. A symmetric matrix S∈Rn×ncan always be diagonalized.
Theorem 4.21 follows directly from the spectral theorem 4.15. More-
over, the spectral theorem states that we can find an ONB of eigenvectors
ofRn. This makes Pan orthogonal matrix so that D=P⊤AP.
Remark. The Jordan normal form of a matrix offers a decomposition that
works for defective matrices (Lang, 1987) but is beyond the scope of this
book. ♢
Geometric Intuition for the Eigendecomposition
We can interpret the eigendecomposition of a matrix as follows (see also
Figure 4.7): Let Abe the transformation matrix of a linear mapping with
respect to the standard basis ei(blue arrows). P−1performs a basis
change from the standard basis into the eigenbasis. Then, the diagonal
Dscales the vectors along these axes by the eigenvalues λi. Finally, P
transforms these scaled vectors back into the standard/canonical coordi-
nates yielding λipi.
Example 4.11 (Eigendecomposition)
Let us compute the eigendecomposition of A=1
25−2
−2 5
.
Step 1: Compute eigenvalues and eigenvectors. The characteristic
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
118 Matrix Decompositions
polynomial of Ais
det(A−λI) = det5
2−λ−1
−15
2−λ
(4.56a)
= (5
2−λ)2−1 =λ2−5λ+21
4= (λ−7
2)(λ−3
2). (4.56b)
Therefore, the eigenvalues of Aareλ1=7
2andλ2=3
2(the roots of the
characteristic polynomial), and the associated (normalized) eigenvectors
are obtained via
Ap1=7
2p1,Ap2=3
2p2. (4.57)
This yields
p1=1√
21
−1
,p2=1√
21
1
. (4.58)
Step 2: Check for existence. The eigenvectors p1,p2form a basis of R2.
Therefore, Acan be diagonalized.
Step 3: Construct the matrix Pto diagonalize A.We collect the eigen-
vectors of AinPso that
P= [p1,p2] =1√
21 1
−1 1
. (4.59)
We then obtain
P−1AP=7
20
03
2
=D. (4.60)
Equivalently, we get (exploiting that P−1=P⊤since the eigenvectors Figure 4.7 visualizes
the
eigendecomposition
ofA=5−2
−2 5
as a sequence of
linear
transformations.p1andp2in this example form an ONB)
1
25−2
−2 5
|{z}
A=1√
21 1
−1 1
|{z}
P7
20
03
2
|{z}
D1√
21−1
1 1
|{z}
P−1. (4.61)
Diagonal matrices Dcan efficiently be raised to a power. Therefore,
we can find a matrix power for a matrix A∈Rn×nvia the eigenvalue
decomposition (if it exists) so that
Ak= (PDP−1)k=PDkP−1. (4.62)
Computing Dkis efficient because we apply this operation individually
to any diagonal element.
Assume that the eigendecomposition A=PDP−1exists. Then,
det(A) = det( PDP−1) = det( P) det(D) det(P−1) (4.63a)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
4.5 Singular Value Decomposition 119
= det( D) =Y
idii (4.63b)
allows for an efficient computation of the determinant of A.
The eigenvalue decomposition requires square matrices. It would be
useful to perform a decomposition on general matrices. In the next sec-
tion, we introduce a more general matrix decomposition technique, the
singular value decomposition.
4.5 Singular Value Decomposition
The singular value decomposition (SVD) of a matrix is a central matrix
decomposition method in linear algebra. It has been referred to as the
“fundamental theorem of linear algebra” (Strang, 1993) because it can be
applied to all matrices, not only to square matrices, and it always exists.
Moreover, as we will explore in the following, the SVD of a matrix A,
which represents a linear mapping Φ :V→W, quantifies the change
between the underlying geometry of these two vector spaces. We recom-
mend the work by Kalman (1996) and Roy and Banerjee (2014) for a
deeper overview of the mathematics of the SVD.
SVD theorem
Theorem 4.22 (SVD Theorem) .LetA∈Rm×nbe a rectangular matrix of
rankr∈[0,min(m, n)]. The SVD of Ais a decomposition of the form SVD
singular value
decomposition
= U A V⊤Σmn
mm
mn
nn
(4.64)
with an orthogonal matrix U∈Rm×mwith column vectors ui,i= 1, . . . , m ,
and an orthogonal matrix V∈Rn×nwith column vectors vj,j= 1, . . . , n .
Moreover, Σis an m×nmatrix with Σii=σi⩾0andΣij= 0, i̸=j.
The diagonal entries σi,i= 1, . . . , r , ofΣare called the singular values ,singular values
uiare called the left-singular vectors , andvjare called the right-singular left-singular vectors
right-singular
vectorsvectors . By convention, the singular values are ordered, i.e., σ1⩾σ2⩾
σr⩾0.
Thesingular value matrix Σis unique, but it requires some attention. singular value
matrix Observe that the Σ∈Rm×nis rectangular. In particular, Σis of the same
size as A. This means that Σhas a diagonal submatrix that contains the
singular values and needs additional zero padding. Specifically, if m > n ,
then the matrix Σhas diagonal structure up to row nand then consists of
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
120 Matrix Decompositions
Figure 4.8 Intuition
behind the SVD of a
matrix A∈R3×2
as sequential
transformations.
Top-left to
bottom-left: V⊤
performs a basis
change in R2.
Bottom-left to
bottom-right: Σ
scales and maps
fromR2toR3. The
ellipse in the
bottom-right lives in
R3. The third
dimension is
orthogonal to the
surface of the
elliptical disk.
Bottom-right to
top-right: U
performs a basis
change within R3.v2
v1
 σ2u2
σ1u1
e2
e1σ2e2
σ1e1A
V⊤
ΣU
0⊤row vectors from n+ 1tombelow so that
Σ=
σ10 0
0...0
0 0 σn
0. . . 0
......
0. . . 0
. (4.65)
Ifm < n , the matrix Σhas a diagonal structure up to column mand
columns that consist of 0from m+ 1ton:
Σ=
σ10 0 0 . . .0
0...0......
0 0 σm0. . .0
. (4.66)
Remark. The SVD exists for any matrix A∈Rm×n. ♢
4.5.1 Geometric Intuitions for the SVD
The SVD offers geometric intuitions to describe a transformation matrix
A. In the following, we will discuss the SVD as sequential linear trans-
formations performed on the bases. In Example 4.12, we will then apply
transformation matrices of the SVD to a set of vectors in R2, which allows
us to visualize the effect of each transformation more clearly.
The SVD of a matrix can be interpreted as a decomposition of a corre-
sponding linear mapping (recall Section 2.7.1) Φ :Rn→Rminto three
operations; see Figure 4.8. The SVD intuition follows superficially a simi-
lar structure to our eigendecomposition intuition, see Figure 4.7: Broadly
speaking, the SVD performs a basis change via V⊤followed by a scal-
ing and augmentation (or reduction) in dimensionality via the singular
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
4.5 Singular Value Decomposition 121
value matrix Σ. Finally, it performs a second basis change via U. The SVD
entails a number of important details and caveats, which is why we will
review our intuition in more detail. It is useful to review
basis changes
(Section 2.7.2),
orthogonal matrices
(Definition 3.8) and
orthonormal bases
(Section 3.5).Assume we are given a transformation matrix of a linear mapping Φ :
Rn→Rmwith respect to the standard bases BandCofRnandRm,
respectively. Moreover, assume a second basis ˜BofRnand˜CofRm. Then
1. The matrix Vperforms a basis change in the domain Rnfrom ˜B(rep-
resented by the red and orange vectors v1andv2in the top-left of Fig-
ure 4.8) to the standard basis B.V⊤=V−1performs a basis change
from Bto˜B. The red and orange vectors are now aligned with the
canonical basis in the bottom-left of Figure 4.8.
2. Having changed the coordinate system to ˜B,Σscales the new coordi-
nates by the singular values σi(and adds or deletes dimensions), i.e.,
Σis the transformation matrix of Φwith respect to ˜Band ˜C, rep-
resented by the red and orange vectors being stretched and lying in
thee1-e2plane, which is now embedded in a third dimension in the
bottom-right of Figure 4.8.
3.Uperforms a basis change in the codomain Rmfrom ˜Cinto the canoni-
cal basis of Rm, represented by a rotation of the red and orange vectors
out of the e1-e2plane. This is shown in the top-right of Figure 4.8.
The SVD expresses a change of basis in both the domain and codomain.
This is in contrast with the eigendecomposition that operates within the
same vector space, where the same basis change is applied and then un-
done. What makes the SVD special is that these two different bases are
simultaneously linked by the singular value matrix Σ.
Example 4.12 (Vectors and the SVD)
Consider a mapping of a square grid of vectors X ∈R2that fit in a box of
size2×2centered at the origin. Using the standard basis, we map these
vectors using
A=
1−0.8
0 1
1 0
=UΣV⊤(4.67a)
=
−0.79 0 −0.62
0.38−0.78−0.49
−0.48−0.62 0 .62

1.62 0
0 1 .0
0 0
−0.78 0 .62
−0.62−0.78
.(4.67b)
We start with a set of vectors X(colored dots; see top-left panel of Fig-
ure 4.9) arranged in a grid. We then apply V⊤∈R2×2, which rotates X.
The rotated vectors are shown in the bottom-left panel of Figure 4.9. We
now map these vectors using the singular value matrix Σto the codomain
R3(see the bottom-right panel in Figure 4.9). Note that all vectors lie in
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
122 Matrix Decompositions
thex1-x2plane. The third coordinate is always 0. The vectors in the x1-x2
plane have been stretched by the singular values.
The direct mapping of the vectors XbyAto the codomain R3equals
the transformation of XbyUΣV⊤, where Uperforms a rotation within
the codomain R3so that the mapped vectors are no longer restricted to
thex1-x2plane; they still are on a plane as shown in the top-right panel
of Figure 4.9.
Figure 4.9 SVD and
mapping of vectors
(represented by
discs). The panels
follow the same
anti-clockwise
structure of
Figure 4.8.
−1.5−1.0−0.5 0.0 0.5 1.0 1.5
x1−1.5−1.0−0.50.00.51.01.5x2
x1-1.5-0.5
0.5
1.5x2
-1.5-0.50.51.5x3
-1.0-0.50.00.51.0
−1.5−1.0−0.5 0.0 0.5 1.0 1.5
x1−1.5−1.0−0.50.00.51.01.5x2
x1-1.5-0.50.51.5x2
-1.5-0.50.51.5x3
0
4.5.2 Construction of the SVD
We will next discuss why the SVD exists and show how to compute it
in detail. The SVD of a general matrix shares some similarities with the
eigendecomposition of a square matrix.
Remark. Compare the eigendecomposition of an SPD matrix
S=S⊤=PDP⊤(4.68)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
4.5 Singular Value Decomposition 123
with the corresponding SVD
S=UΣV⊤. (4.69)
If we set
U=P=V,D=Σ, (4.70)
we see that the SVD of SPD matrices is their eigendecomposition. ♢
In the following, we will explore why Theorem 4.22 holds and how
the SVD is constructed. Computing the SVD of A∈Rm×nis equivalent
to finding two sets of orthonormal bases U= (u1, . . . ,um)andV=
(v1, . . . ,vn)of the codomain Rmand the domain Rn, respectively. From
these ordered bases, we will construct the matrices UandV.
Our plan is to start with constructing the orthonormal set of right-
singular vectors v1, . . . ,vn∈Rn. We then construct the orthonormal set
of left-singular vectors u1, . . . ,um∈Rm. Thereafter, we will link the two
and require that the orthogonality of the viis preserved under the trans-
formation of A. This is important because we know that the images Avi
form a set of orthogonal vectors. We will then normalize these images by
scalar factors, which will turn out to be the singular values.
Let us begin with constructing the right-singular vectors. The spectral
theorem (Theorem 4.15) tells us that the eigenvectors of a symmetric
matrix form an ONB, which also means it can be diagonalized. More-
over, from Theorem 4.14 we can always construct a symmetric, positive
semidefinite matrix A⊤A∈Rn×nfrom any rectangular matrix A∈
Rm×n. Thus, we can always diagonalize A⊤Aand obtain
A⊤A=PDP⊤=P
λ1··· 0
.........
0···λn
P⊤, (4.71)
where Pis an orthogonal matrix, which is composed of the orthonormal
eigenbasis. The λi⩾0are the eigenvalues of A⊤A. Let us assume the
SVD of Aexists and inject (4.64) into (4.71). This yields
A⊤A= (UΣV⊤)⊤(UΣV⊤) =VΣ⊤U⊤UΣV⊤, (4.72)
where U,Vare orthogonal matrices. Therefore, with U⊤U=Iwe ob-
tain
A⊤A=VΣ⊤ΣV⊤=V
σ2
10 0
0...0
0 0 σ2
n
V⊤. (4.73)
Comparing now (4.71) and (4.73), we identify
V⊤=P⊤, (4.74)
σ2
i=λi. (4.75)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
124 Matrix Decompositions
Therefore, the eigenvectors of A⊤Athat compose Pare the right-singular
vectors VofA(see (4.74)). The eigenvalues of A⊤Aare the squared
singular values of Σ(see (4.75)).
To obtain the left-singular vectors U, we follow a similar procedure.
We start by computing the SVD of the symmetric matrix AA⊤∈Rm×m
(instead of the previous A⊤A∈Rn×n). The SVD of Ayields
AA⊤= (UΣV⊤)(UΣV⊤)⊤=UΣV⊤VΣ⊤U⊤(4.76a)
=U
σ2
10 0
0...0
0 0 σ2
m
U⊤. (4.76b)
The spectral theorem tells us that AA⊤=SDS⊤can be diagonalized
and we can find an ONB of eigenvectors of AA⊤, which are collected in
S. The orthonormal eigenvectors of AA⊤are the left-singular vectors U
and form an orthonormal basis in the codomain of the SVD.
This leaves the question of the structure of the matrix Σ. Since AA⊤
andA⊤Ahave the same nonzero eigenvalues (see page 106), the nonzero
entries of the Σmatrices in the SVD for both cases have to be the same.
The last step is to link up all the parts we touched upon so far. We have
an orthonormal set of right-singular vectors in V. To finish the construc-
tion of the SVD, we connect them with the orthonormal vectors U. To
reach this goal, we use the fact the images of the viunder Ahave to be
orthogonal, too. We can show this by using the results from Section 3.4.
We require that the inner product between AviandAvjmust be 0for
i̸=j. For any two orthogonal eigenvectors vi,vj,i̸=j, it holds that
(Avi)⊤(Avj) =v⊤
i(A⊤A)vj=v⊤
i(λjvj) =λjv⊤
ivj= 0. (4.77)
For the case m⩾r, it holds that {Av1, . . . ,Avr}is a basis of an r-
dimensional subspace of Rm.
To complete the SVD construction, we need left-singular vectors that
are ortho normal : We normalize the images of the right-singular vectors
Aviand obtain
ui:=Avi
∥Avi∥=1√λiAvi=1
σiAvi, (4.78)
where the last equality was obtained from (4.75) and (4.76b), showing
us that the eigenvalues of AA⊤are such that σ2
i=λi.
Therefore, the eigenvectors of A⊤A, which we know are the right-
singular vectors vi, and their normalized images under A, the left-singular
vectors ui, form two self-consistent ONBs that are connected through the
singular value matrix Σ.
Let us rearrange (4.78) to obtain the singular value equation singular value
equation
Avi=σiui, i= 1, . . . , r . (4.79)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
4.5 Singular Value Decomposition 125
This equation closely resembles the eigenvalue equation (4.25), but the
vectors on the left- and the right-hand sides are not the same.
Forn < m , (4.79) holds only for i⩽n, but (4.79) says nothing about
theuifori > n . However, we know by construction that they are or-
thonormal. Conversely, for m < n , (4.79) holds only for i⩽m. Fori > m ,
we have Avi=0and we still know that the viform an orthonormal set.
This means that the SVD also supplies an orthonormal basis of the kernel
(null space) of A, the set of vectors xwithAx=0(see Section 2.7.3).
Concatenating the vias the columns of Vand the uias the columns of
Uyields
AV=UΣ, (4.80)
where Σhas the same dimensions as Aand a diagonal structure for rows
1, . . . , r . Hence, right-multiplying with V⊤yields A=UΣV⊤, which is
the SVD of A.
Example 4.13 (Computing the SVD)
Let us find the singular value decomposition of
A=1 0 1
−2 1 0
. (4.81)
The SVD requires us to compute the right-singular vectors vj, the singular
values σk, and the left-singular vectors ui.
Step 1: Right-singular vectors as the eigenbasis of A⊤A.
We start by computing
A⊤A=
1−2
0 1
1 0
1 0 1
−2 1 0
=
5−2 1
−2 1 0
1 0 1
. (4.82)
We compute the singular values and right-singular vectors vjthrough
the eigenvalue decomposition of A⊤A, which is given as
A⊤A=
5√
300−1√
6
−2√
301√
5−2√
6
1√
302√
51√
6

6 0 0
0 1 0
0 0 0

5√
30−2√
301√
30
01√
52√
5
−1√
6−2√
61√
6
=PDP⊤,
(4.83)
and we obtain the right-singular vectors as the columns of Pso that
V=P=
5√
300−1√
6
−2√
301√
5−2√
6
1√
302√
51√
6
. (4.84)
Step 2: Singular-value matrix.
As the singular values σiare the square roots of the eigenvalues of
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
126 Matrix Decompositions
A⊤Awe obtain them straight from D. Since rk(A) = 2 , there are only
two nonzero singular values: σ1=√
6andσ2= 1. The singular value
matrix must be the same size as A, and we obtain
Σ=√
6 0 0
0 1 0
. (4.85)
Step 3: Left-singular vectors as the normalized image of the right-
singular vectors.
We find the left-singular vectors by computing the image of the right-
singular vectors under Aand normalizing them by dividing them by their
corresponding singular value. We obtain
u1=1
σ1Av1=1√
61 0 1
−2 1 0
5√
30
−2√
30
1√
30
="
1√
5
−2√
5#
, (4.86)
u2=1
σ2Av2=1
11 0 1
−2 1 0
0
1√
5
2√
5
="
2√
5
1√
5#
, (4.87)
U= [u1,u2] =1√
51 2
−2 1
. (4.88)
Note that on a computer the approach illustrated here has poor numerical
behavior, and the SVD of Ais normally computed without resorting to the
eigenvalue decomposition of A⊤A.
4.5.3 Eigenvalue Decomposition vs. Singular Value Decomposition
Let us consider the eigendecomposition A=PDP−1and the SVD A=
UΣV⊤and review the core elements of the past sections.
The SVD always exists for any matrix Rm×n. The eigendecomposition is
only defined for square matrices Rn×nand only exists if we can find a
basis of eigenvectors of Rn.
The vectors in the eigendecomposition matrix Pare not necessarily
orthogonal, i.e., the change of basis is not a simple rotation and scaling.
On the other hand, the vectors in the matrices UandVin the SVD are
orthonormal, so they do represent rotations.
Both the eigendecomposition and the SVD are compositions of three
linear mappings:
1. Change of basis in the domain
2. Independent scaling of each new basis vector and mapping from do-
main to codomain
3. Change of basis in the codomain
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
4.5 Singular Value Decomposition 127
Figure 4.10 Movie
ratings of three
people for four
movies and its SVD
decomposition. 5 4 1
5 5 0
0 0 5
1 0 4

Ali
Beatrix
Chandra
Star Wars
Blade Runner
Amelie
Delicatessen=−0.6710 0.0236 0.4647 −0.5774
−0.7197 0.2054 −0.4759 0.4619
−0.0939 −0.7705 −0.5268 −0.3464
−0.1515 −0.6030 0.5293 −0.5774


9.6438 0 0
06.3639 0
0 00.7056
0 0 0


−0.7367 −0.6515 −0.1811
0.0852 0.1762 −0.9807
0.6708 −0.7379 −0.0743


A key difference between the eigendecomposition and the SVD is that
in the SVD, domain and codomain can be vector spaces of different
dimensions.
In the SVD, the left- and right-singular vector matrices UandVare
generally not inverse of each other (they perform basis changes in dif-
ferent vector spaces). In the eigendecomposition, the basis change ma-
tricesPandP−1are inverses of each other.
In the SVD, the entries in the diagonal matrix Σare all real and non-
negative, which is not generally true for the diagonal matrix in the
eigendecomposition.
The SVD and the eigendecomposition are closely related through their
projections
–The left-singular vectors of Aare eigenvectors of AA⊤
–The right-singular vectors of Aare eigenvectors of A⊤A.
–The nonzero singular values of Aare the square roots of the nonzero
eigenvalues of both AA⊤andA⊤A.
For symmetric matrices A∈Rn×n, the eigenvalue decomposition and
the SVD are one and the same, which follows from the spectral theo-
rem 4.15.
Example 4.14 (Finding Structure in Movie Ratings and Consumers)
Let us add a practical interpretation of the SVD by analyzing data on
people and their preferred movies. Consider three viewers (Ali, Beatrix,
Chandra) rating four different movies ( Star Wars ,Blade Runner ,Amelie ,
Delicatessen ). Their ratings are values between 0(worst) and 5(best) and
encoded in a data matrix A∈R4×3as shown in Figure 4.10. Each row
represents a movie and each column a user. Thus, the column vectors of
movie ratings, one for each viewer, are xAli,xBeatrix ,xChandra .
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
128 Matrix Decompositions
Factoring Ausing the SVD offers us a way to capture the relationships
of how people rate movies, and especially if there is a structure linking
which people like which movies. Applying the SVD to our data matrix A
makes a number of assumptions:
1. All viewers rate movies consistently using the same linear mapping.
2. There are no errors or noise in the ratings.
3. We interpret the left-singular vectors uias stereotypical movies and
the right-singular vectors vjas stereotypical viewers.
We then make the assumption that any viewer’s specific movie preferences
can be expressed as a linear combination of the vj. Similarly, any movie’s
like-ability can be expressed as a linear combination of the ui. Therefore,
a vector in the domain of the SVD can be interpreted as a viewer in the
“space” of stereotypical viewers, and a vector in the codomain of the SVD
correspondingly as a movie in the “space” of stereotypical movies. Let us These two “spaces”
are only
meaningfully
spanned by the
respective viewer
and movie data if
the data itself covers
a sufficient diversity
of viewers and
movies.inspect the SVD of our movie-user matrix. The first left-singular vector u1
has large absolute values for the two science fiction movies and a large
first singular value (red shading in Figure 4.10). Thus, this groups a type
of users with a specific set of movies (science fiction theme). Similarly, the
first right-singular v1shows large absolute values for Ali and Beatrix, who
give high ratings to science fiction movies (green shading in Figure 4.10).
This suggests that v1reflects the notion of a science fiction lover.
Similarly, u2, seems to capture a French art house film theme, and v2in-
dicates that Chandra is close to an idealized lover of such movies. An ide-
alized science fiction lover is a purist and only loves science fiction movies,
so a science fiction lover v1gives a rating of zero to everything but science
fiction themed—this logic is implied by the diagonal substructure for the
singular value matrix Σ. A specific movie is therefore represented by how
it decomposes (linearly) into its stereotypical movies. Likewise, a person
would be represented by how they decompose (via linear combination)
into movie themes.
It is worth to briefly discuss SVD terminology and conventions, as there
are different versions used in the literature. While these differences can
be confusing, the mathematics remains invariant to them.
For convenience in notation and abstraction, we use an SVD notation
where the SVD is described as having two square left- and right-singular
vector matrices, but a non-square singular value matrix. Our defini-
tion (4.64) for the SVD is sometimes called the full SVD . full SVD
Some authors define the SVD a bit differently and focus on square sin-
gular matrices. Then, for A∈Rm×nandm⩾n,
A
m×n=U
m×nΣ
n×nV⊤
n×n. (4.89)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
4.6 Matrix Approximation 129
Sometimes this formulation is called the reduced SVD (e.g., Datta (2010)) reduced SVD
ortheSVD (e.g., Press et al. (2007)). This alternative format changes
merely how the matrices are constructed but leaves the mathematical
structure of the SVD unchanged. The convenience of this alternative
formulation is that Σis diagonal, as in the eigenvalue decomposition.
In Section 4.6, we will learn about matrix approximation techniques
using the SVD, which is also called the truncated SVD . truncated SVD
It is possible to define the SVD of a rank- rmatrix Aso that Uis an
m×rmatrix, Σa diagonal matrix r×r, and Vanr×nmatrix.
This construction is very similar to our definition, and ensures that the
diagonal matrix Σhas only nonzero entries along the diagonal. The
main convenience of this alternative notation is that Σis diagonal, as
in the eigenvalue decomposition.
A restriction that the SVD for Aonly applies to m×nmatrices with
m > n is practically unnecessary. When m < n , the SVD decomposition
will yield Σwith more zero columns than rows and, consequently, the
singular values σm+1, . . . , σ nare0.
The SVD is used in a variety of applications in machine learning from
least-squares problems in curve fitting to solving systems of linear equa-
tions. These applications harness various important properties of the SVD,
its relation to the rank of a matrix, and its ability to approximate matrices
of a given rank with lower-rank matrices. Substituting a matrix with its
SVD has often the advantage of making calculation more robust to nu-
merical rounding errors. As we will explore in the next section, the SVD’s
ability to approximate matrices with “simpler” matrices in a principled
manner opens up machine learning applications ranging from dimension-
ality reduction and topic modeling to data compression and clustering.
4.6 Matrix Approximation
We considered the SVD as a way to factorize A=UΣV⊤∈Rm×ninto
the product of three matrices, where U∈Rm×mandV∈Rn×nare or-
thogonal and Σcontains the singular values on its main diagonal. Instead
of doing the full SVD factorization, we will now investigate how the SVD
allows us to represent a matrix Aas a sum of simpler (low-rank) matrices
Ai, which lends itself to a matrix approximation scheme that is cheaper
to compute than the full SVD.
We construct a rank- 1matrix Ai∈Rm×nas
Ai:=uiv⊤
i, (4.90)
which is formed by the outer product of the ith orthogonal column vector
ofUandV. Figure 4.11 shows an image of Stonehenge, which can be
represented by a matrix A∈R1432×1910, and some outer products Ai, as
defined in (4.90).
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
130 Matrix Decompositions
Figure 4.11 Image
processing with the
SVD. (a) The
original grayscale
image is a
1,432×1,910
matrix of values
between 0(black)
and1(white).
(b)–(f) Rank- 1
matrices
A1, . . . ,A5and
their corresponding
singular values
σ1, . . . , σ 5. The
grid-like structure of
each rank- 1matrix
is imposed by the
outer-product of the
left and
right-singular
vectors.
(a) Original image A.
 (b)A1, σ1≈228,052.
 (c)A2, σ2≈40,647.
(d)A3, σ3≈26,125.
 (e)A4, σ4≈20,232.
 (f)A5, σ5≈15,436.
A matrix A∈Rm×nof rank rcan be written as a sum of rank-1 matrices
Aiso that
A=rX
i=1σiuiv⊤
i=rX
i=1σiAi, (4.91)
where the outer-product matrices Aiare weighted by the ith singular
value σi. We can see why (4.91) holds: The diagonal structure of the
singular value matrix Σmultiplies only matching left- and right-singular
vectors uiv⊤
iand scales them by the corresponding singular value σi. All
terms Σijuiv⊤
jvanish for i̸=jbecause Σis a diagonal matrix. Any terms
i > r vanish because the corresponding singular values are 0.
In (4.90), we introduced rank- 1matrices Ai. We summed up the rin-
dividual rank- 1matrices to obtain a rank- rmatrix A; see (4.91). If the
sum does not run over all matrices Ai,i= 1, . . . , r , but only up to an
intermediate value k < r , we obtain a rank- kapproximation rank-k
approximation
bA(k) :=kX
i=1σiuiv⊤
i=kX
i=1σiAi (4.92)
ofAwith rk(bA(k)) = k. Figure 4.12 shows low-rank approximations
bA(k)of an original image Aof Stonehenge. The shape of the rocks be-
comes increasingly visible and clearly recognizable in the rank- 5approx-
imation. While the original image requires 1,432·1,910 = 2 ,735,120
numbers, the rank- 5approximation requires us only to store the five sin-
gular values and the five left- and right-singular vectors ( 1,432and1,910-
dimensional each) for a total of 5·(1,432+1 ,910+1) = 16 ,715numbers
– just above 0.6%of the original.
To measure the difference (error) between Aand its rank- kapproxima-
tionbA(k), we need the notion of a norm. In Section 3.1, we already used
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
4.6 Matrix Approximation 131
Figure 4.12 Image
reconstruction with
the SVD. (a)
Original image.
(b)–(f) Image
reconstruction using
the low-rank
approximation of
the SVD, where the
rank-k
approximation is
given by bA(k) =Pk
i=1σiAi.
(a) Original image A.
 (b) Rank-1 approximation bA(1).
(c) Rank-2 approximation bA(2).
(d) Rank-3 approximation bA(3).
(e) Rank-4 approximation bA(4).
(f) Rank-5 approximation bA(5).
norms on vectors that measure the length of a vector. By analogy we can
also define norms on matrices.
Definition 4.23 (Spectral Norm of a Matrix) .Forx∈Rn\{0}, the spectral spectral norm
norm of a matrix A∈Rm×nis defined as
∥A∥2:= max
x∥Ax∥2
∥x∥2. (4.93)
We introduce the notation of a subscript in the matrix norm (left-hand
side), similar to the Euclidean norm for vectors (right-hand side), which
has subscript 2. The spectral norm (4.93) determines how long any vector
xcan at most become when multiplied by A.
Theorem 4.24. The spectral norm of Ais its largest singular value σ1.
We leave the proof of this theorem as an exercise.
Eckart-Young
theorem Theorem 4.25 (Eckart-Young Theorem (Eckart and Young, 1936)) .Con-
sider a matrix A∈Rm×nof rank rand let B∈Rm×nbe a matrix of rank
k. For any k⩽rwithbA(k) =Pk
i=1σiuiv⊤
iit holds that
bA(k) = argminrk(B)=k∥A−B∥2, (4.94)A−bA(k)
2=σk+1. (4.95)
The Eckart-Young theorem states explicitly how much error we intro-
duce by approximating Ausing a rank- kapproximation. We can inter-
pret the rank- kapproximation obtained with the SVD as a projection of
the full-rank matrix Aonto a lower-dimensional space of rank-at-most- k
matrices. Of all possible projections, the SVD minimizes the error (with
respect to the spectral norm) between Aand any rank- kapproximation.
We can retrace some of the steps to understand why (4.95) should hold.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
132 Matrix Decompositions
We observe that the difference between A−bA(k)is a matrix containing
the sum of the remaining rank- 1matrices
A−bA(k) =rX
i=k+1σiuiv⊤
i. (4.96)
By Theorem 4.24, we immediately obtain σk+1as the spectral norm of the
difference matrix. Let us have a closer look at (4.94). If we assume that
there is another matrix Bwithrk(B)⩽k, such that
∥A−B∥2<A−bA(k)
2, (4.97)
then there exists an at least ( n−k)-dimensional null space Z⊆Rn, such
thatx∈Zimplies that Bx=0. Then it follows that
∥Ax∥2=∥(A−B)x∥2, (4.98)
and by using a version of the Cauchy-Schwartz inequality (3.17) that en-
compasses norms of matrices, we obtain
∥Ax∥2⩽∥A−B∥2∥x∥2< σ k+1∥x∥2. (4.99)
However, there exists a (k+ 1)-dimensional subspace where ∥Ax∥2⩾
σk+1∥x∥2, which is spanned by the right-singular vectors vj, j⩽k+ 1of
A. Adding up dimensions of these two spaces yields a number greater than
n, as there must be a nonzero vector in both spaces. This is a contradiction
of the rank-nullity theorem (Theorem 2.24) in Section 2.7.3.
The Eckart-Young theorem implies that we can use SVD to reduce a
rank- rmatrix Ato a rank- kmatrix bAin a principled, optimal (in the
spectral norm sense) manner. We can interpret the approximation of Aby
a rank- kmatrix as a form of lossy compression. Therefore, the low-rank
approximation of a matrix appears in many machine learning applications,
e.g., image processing, noise filtering, and regularization of ill-posed prob-
lems. Furthermore, it plays a key role in dimensionality reduction and
principal component analysis, as we will see in Chapter 10.
Example 4.15 (Finding Structure in Movie Ratings and Consumers
(continued))
Coming back to our movie-rating example, we can now apply the con-
cept of low-rank approximations to approximate the original data matrix.
Recall that our first singular value captures the notion of science fiction
theme in movies and science fiction lovers. Thus, by using only the first
singular value term in a rank- 1decomposition of the movie-rating matrix,
we obtain the predicted ratings
A1=u1v⊤
1=
−0.6710
−0.7197
−0.0939
−0.1515
−0.7367 −0.6515 −0.1811
(4.100a)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
4.7 Matrix Phylogeny 133
=
0.4943 0 .4372 0 .1215
0.5302 0 .4689 0 .1303
0.0692 0 .0612 0 .0170
0.1116 0 .0987 0 .0274
. (4.100b)
This first rank- 1approximation A1is insightful: it tells us that Ali and
Beatrix like science fiction movies, such as Star Wars and Bladerunner
(entries have values >0.4), but fails to capture the ratings of the other
movies by Chandra. This is not surprising, as Chandra’s type of movies is
not captured by the first singular value. The second singular value gives
us a better rank- 1approximation for those movie-theme lovers:
A2=u2v⊤
2=
0.0236
0.2054
−0.7705
−0.6030
0.0852 0 .1762 −0.9807
(4.101a)
=
0.0020 0 .0042 −0.0231
0.0175 0 .0362 −0.2014
−0.0656 −0.1358 0 .7556
−0.0514 −0.1063 0 .5914
. (4.101b)
In this second rank- 1approximation A2, we capture Chandra’s ratings
and movie types well, but not the science fiction movies. This leads us to
consider the rank- 2approximation bA(2), where we combine the first two
rank- 1approximations
bA(2) = σ1A1+σ2A2=
4.7801 4 .2419 1 .0244
5.2252 4 .7522 −0.0250
0.2493 −0.2743 4 .9724
0.7495 0 .2756 4 .0278
.(4.102)
bA(2)is similar to the original movie ratings table
A=
5 4 1
5 5 0
0 0 5
1 0 4
, (4.103)
and this suggests that we can ignore the contribution of A3. We can in-
terpret this so that in the data table there is no evidence of a third movie-
theme/movie-lovers category. This also means that the entire space of
movie-themes/movie-lovers in our example is a two-dimensional space
spanned by science fiction and French art house movies and lovers.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
134 Matrix Decompositions
Figure 4.13 A
functional
phylogeny of
matrices
encountered in
machine learning.Real matrices
∃Pseudo-inverse
∃SVD
Square
∃Determinant
∃TraceNonsquare
DefectiveSingular
Non-defective
(diagonalizable)Singular
Normal Non-normal
Symmetric
eigenvalues ∈R
Positive definite
Cholesky
eigenvalues >0Diagonal
Identity
matrix∃Inverse Matrix
Regular
(invertible)
Orthogonal RotationRn×nRn×m
No basis of
eigenvectors
Basis of
eigenvectors
A⊤A=AA⊤A⊤A̸=AA⊤
Columns are
orthogonal
eigenvectorsA⊤A=AA
⊤
=Idet
̸= 0det
̸= 0det = 0
4.7 Matrix Phylogeny
The word
“phylogenetic”
describes how we
capture the
relationships among
individuals or
groups and derived
from the Greek
words for “tribe”
and “source”.In Chapters 2 and 3, we covered the basics of linear algebra and analytic
geometry. In this chapter, we looked at fundamental characteristics of ma-
trices and linear mappings. Figure 4.13 depicts the phylogenetic tree of
relationships between different types of matrices (black arrows indicating
“is a subset of”) and the covered operations we can perform on them (in
blue). We consider all real matrices A∈Rn×m. For non-square matrices
(where n̸=m), the SVD always exists, as we saw in this chapter. Focus-
ing on square matrices A∈Rn×n, the determinant informs us whether a
square matrix possesses an inverse matrix , i.e., whether it belongs to the
class of regular, invertible matrices. If the square n×nmatrix possesses n
linearly independent eigenvectors, then the matrix is non-defective and an
eigendecomposition exists (Theorem 4.12). We know that repeated eigen-
values may result in defective matrices, which cannot be diagonalized.
Non-singular and non-defective matrices are not the same. For exam-
ple, a rotation matrix will be invertible (determinant is nonzero) but not
diagonalizable in the real numbers (eigenvalues are not guaranteed to be
real numbers).
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
4.8 Further Reading 135
We dive further into the branch of non-defective square n×nmatrices.
Aisnormal if the condition A⊤A=AA⊤holds. Moreover, if the more
restrictive condition holds that A⊤A=AA⊤=I, then Ais called or-
thogona l (see Definition 3.8). The set of orthogonal matrices is a subset of
the regular (invertible) matrices and satisfies A⊤=A−1.
Normal matrices have a frequently encountered subset, the symmetric
matrices S∈Rn×n, which satisfy S=S⊤. Symmetric matrices have only
real eigenvalues. A subset of the symmetric matrices consists of the pos-
itive definite matrices Pthat satisfy the condition of x⊤Px>0for all
x∈Rn\{0}. In this case, a unique Cholesky decomposition exists (Theo-
rem 4.18). Positive definite matrices have only positive eigenvalues and
are always invertible (i.e., have a nonzero determinant).
Another subset of symmetric matrices consists of the diagonal matrices
D. Diagonal matrices are closed under multiplication and addition, but do
not necessarily form a group (this is only the case if all diagonal entries
are nonzero so that the matrix is invertible). A special diagonal matrix is
the identity matrix I.
4.8 Further Reading
Most of the content in this chapter establishes underlying mathematics
and connects them to methods for studying mappings, many of which are
at the heart of machine learning at the level of underpinning software so-
lutions and building blocks for almost all machine learning theory. Matrix
characterization using determinants, eigenspectra, and eigenspaces pro-
vides fundamental features and conditions for categorizing and analyzing
matrices. This extends to all forms of representations of data and map-
pings involving data, as well as judging the numerical stability of compu-
tational operations on such matrices (Press et al., 2007).
Determinants are fundamental tools in order to invert matrices and
compute eigenvalues “by hand”. However, for almost all but the smallest
instances, numerical computation by Gaussian elimination outperforms
determinants (Press et al., 2007). Determinants remain nevertheless a
powerful theoretical concept, e.g., to gain intuition about the orientation
of a basis based on the sign of the determinant. Eigenvectors can be used
to perform basis changes to transform data into the coordinates of mean-
ingful orthogonal, feature vectors. Similarly, matrix decomposition meth-
ods, such as the Cholesky decomposition, reappear often when we com-
pute or simulate random events (Rubinstein and Kroese, 2016). Therefore,
the Cholesky decomposition enables us to compute the reparametrization
trick where we want to perform continuous differentiation over random
variables, e.g., in variational autoencoders (Jimenez Rezende et al., 2014;
Kingma and Welling, 2014).
Eigendecomposition is fundamental in enabling us to extract mean-
ingful and interpretable information that characterizes linear mappings.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
136 Matrix Decompositions
Therefore, the eigendecomposition underlies a general class of machine
learning algorithms called spectral methods that perform eigendecomposi-
tion of a positive-definite kernel. These spectral decomposition methods
encompass classical approaches to statistical data analysis, such as the
following:
principal component
analysis Principal component analysis (PCA (Pearson, 1901), see also Chapter 10),
in which a low-dimensional subspace, which explains most of the vari-
ability in the data, is sought. Fisher discriminant
analysis Fisher discriminant analysis , which aims to determine a separating hy-
perplane for data classification (Mika et al., 1999). multidimensional
scaling Multidimensional scaling (MDS) (Carroll and Chang, 1970).
The computational efficiency of these methods typically comes from find-
ing the best rank- kapproximation to a symmetric, positive semidefinite
matrix. More contemporary examples of spectral methods have different
origins, but each of them requires the computation of the eigenvectors
and eigenvalues of a positive-definite kernel, such as Isomap (Tenenbaum Isomap
et al., 2000), Laplacian eigenmaps (Belkin and Niyogi, 2003), Hessian Laplacian
eigenmaps
Hessian eigenmapseigenmaps (Donoho and Grimes, 2003), and spectral clustering (Shi and
spectral clusteringMalik, 2000). The core computations of these are generally underpinned
by low-rank matrix approximation techniques (Belabbas and Wolfe, 2009)
as we encountered here via the SVD.
The SVD allows us to discover some of the same kind of information as
the eigendecomposition. However, the SVD is more generally applicable
to non-square matrices and data tables. These matrix factorization meth-
ods become relevant whenever we want to identify heterogeneity in data
when we want to perform data compression by approximation, e.g., in-
stead of storing n×mvalues just storing (n+m)kvalues, or when we want
to perform data pre-processing, e.g., to decorrelate predictor variables of
a design matrix (Ormoneit et al., 2001). The SVD operates on matrices,
which we can interpret as rectangular arrays with two indices (rows and
columns). The extension of matrix-like structure to higher-dimensional
arrays are called tensors. It turns out that the SVD is the special case of
a more general family of decompositions that operate on such tensors
(Kolda and Bader, 2009). SVD-like operations and low-rank approxima-
tions on tensors are, for example, the Tucker decomposition (Tucker, 1966) Tucker
decomposition or the CP decomposition (Carroll and Chang, 1970).
CP decomposition The SVD low-rank approximation is frequently used in machine learn-
ing for computational efficiency reasons. This is because it reduces the
amount of memory and operations with nonzero multiplications we need
to perform on potentially very large matrices of data (Trefethen and Bau III,
1997). Moreover, low-rank approximations are used to operate on ma-
trices that may contain missing values as well as for purposes of lossy
compression and dimensionality reduction (Moonen and De Moor, 1995;
Markovsky, 2011).
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
Exercises 137
Exercises
4.1 Compute the determinant using the Laplace expansion (using the first row)
and the Sarrus rule for
A=
1 3 5
2 4 6
0 2 4
.
4.2 Compute the following determinant efficiently:

2 0 1 2 0
2−1 0 1 1
0 1 2 1 2
−2 0 2 −1 2
2 0 0 1 1
.
4.3 Compute the eigenspaces of
a.
A:=
1 0
1 1
b.
B:=
−2 2
2 1
4.4 Compute all eigenspaces of
A=
0−1 1 1
−1 1 −2 3
2−1 0 0
1−1 1 0
.
4.5 Diagonalizability of a matrix is unrelated to its invertibility. Determine for
the following four matrices whether they are diagonalizable and/or invert-
ible

1 0
0 1
,
1 0
0 0
,
1 1
0 1
,
0 1
0 0
.
4.6 Compute the eigenspaces of the following transformation matrices. Are they
diagonalizable?
a. For
A=
2 3 0
1 4 3
0 0 1

b. For
A=
1 1 0 0
0 0 0 0
0 0 0 0
0 0 0 0

©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
138 Matrix Decompositions
4.7 Are the following matrices diagonalizable? If yes, determine their diagonal
form and a basis with respect to which the transformation matrices are di-
agonal. If no, give reasons why they are not diagonalizable.
a.
A=
0 1
−8 4
b.
A=
1 1 1
1 1 1
1 1 1

c.
A=
5 4 2 1
0 1 −1−1
−1−1 3 0
1 1 −1 2

d.
A=
5−6−6
−1 4 2
3−6−4

4.8 Find the SVD of the matrix
A=
3 2 2
2 3 −2
.
4.9 Find the singular value decomposition of
A=
2 2
−1 1
.
4.10 Find the rank-1 approximation of
A=
3 2 2
2 3 −2
4.11 Show that for any A∈Rm×nthe matrices A⊤AandAA⊤possess the
same nonzero eigenvalues.
4.12 Show that for x̸=0Theorem 4.24 holds, i.e., show that
max
x∥Ax∥2
∥x∥2=σ1,
where σ1is the largest singular value of A∈Rm×n.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
5
Vector Calculus
Many algorithms in machine learning optimize an objective function with
respect to a set of desired model parameters that control how well a model
explains the data: Finding good parameters can be phrased as an opti-
mization problem (see Sections 8.2 and 8.3). Examples include: (i) lin-
ear regression (see Chapter 9), where we look at curve-fitting problems
and optimize linear weight parameters to maximize the likelihood; (ii)
neural-network auto-encoders for dimensionality reduction and data com-
pression, where the parameters are the weights and biases of each layer,
and where we minimize a reconstruction error by repeated application of
the chain rule; and (iii) Gaussian mixture models (see Chapter 11) for
modeling data distributions, where we optimize the location and shape
parameters of each mixture component to maximize the likelihood of the
model. Figure 5.1 illustrates some of these problems, which we typically
solve by using optimization algorithms that exploit gradient information
(Section 7.1). Figure 5.2 gives an overview of how concepts in this chap-
ter are related and how they are connected to other chapters of the book.
Central to this chapter is the concept of a function. A function fis
a quantity that relates two quantities to each other. In this book, these
quantities are typically inputs x∈RDand targets (function values) f(x),
which we assume are real-valued if not stated otherwise. Here RDis the
domain off, and the function values f(x)are the image/codomain off.domain
image/codomain
Figure 5.1 Vector
calculus plays a
central role in (a)
regression (curve
fitting) and (b)
density estimation,
i.e., modeling data
distributions.
−4−2 0 2 4
x−4−2024y
Training data
MLE
(a) Regression problem: Find parameters,
such that the curve explains the observations
(crosses) well.
−10−5 0 5 10
x1−10−50510x2
(b) Density estimation with a Gaussian mixture
model: Find means and covariances, such that
the data (dots) can be explained well.
139
This material is published by Cambridge University Press as Mathematics for Machine Learning by
Marc Peter Deisenroth, A. Aldo Faisal, and Cheng Soon Ong (2020). This version is free to view
and download for personal use only. Not for re-distribution, re-sale, or use in derivative works.
©by M. P. Deisenroth, A. A. Faisal, and C. S. Ong, 2024. https://mml-book.com .
140 Vector Calculus
Figure 5.2 A mind
map of the concepts
introduced in this
chapter, along with
when they are used
in other parts of the
book.Difference quotient
Partial derivatives
Jacobian
Hessian
Taylor seriesChapter 7
Optimization
Chapter 6
ProbabilityChapter 9
Regression
Chapter 10
Dimensionality
reduction
Chapter 11
Density estimation
Chapter 12
Classification
defines collected in used inused inused in
used inused in
used inused in
Section 2.7.3 provides much more detailed discussion in the context of
linear functions. We often write
f:RD→R (5.1a)
x7→f(x) (5.1b)
to specify a function, where (5.1a) specifies that fis a mapping from
RDtoRand (5.1b) specifies the explicit assignment of an input xto
a function value f(x). A function fassigns every input xexactly one
function value f(x).
Example 5.1
Recall the dot product as a special case of an inner product (Section 3.2).
In the previous notation, the function f(x) =x⊤x,x∈R2, would be
specified as
f:R2→R (5.2a)
x7→x2
1+x2
2. (5.2b)
In this chapter, we will discuss how to compute gradients of functions,
which is often essential to facilitate learning in machine learning models
since the gradient points in the direction of steepest ascent. Therefore,
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
5.1 Differentiation of Univariate Functions 141
Figure 5.3 The
average incline of a
function fbetween
x0andx0+δxis
the incline of the
secant (blue)
through f(x0)and
f(x0+δx)and
given by δy/δx .
y
xf(x)
xy
f(x0)f(x0+x)
vector calculus is one of the fundamental mathematical tools we need in
machine learning. Throughout this book, we assume that functions are
differentiable. With some additional technical definitions, which we do
not cover here, many of the approaches presented can be extended to
sub-differentials (functions that are continuous but not differentiable at
certain points). We will look at an extension to the case of functions with
constraints in Chapter 7.
5.1 Differentiation of Univariate Functions
In the following, we briefly revisit differentiation of a univariate function,
which may be familiar from high school mathematics. We start with the
difference quotient of a univariate function y=f(x), x, y∈R, which we
will subsequently use to define derivatives.
Definition 5.1 (Difference Quotient) .Thedifference quotient difference quotient
δy
δx:=f(x+δx)−f(x)
δx(5.3)
computes the slope of the secant line through two points on the graph of
f. In Figure 5.3, these are the points with x-coordinates x0andx0+δx.
The difference quotient can also be considered the average slope of f
between xandx+δxif we assume fto be a linear function. In the limit
forδx→0, we obtain the tangent of fatx, iffis differentiable. The
tangent is then the derivative of fatx.
Definition 5.2 (Derivative) .More formally, for h >0thederivative off derivative
atxis defined as the limit
df
dx:= lim
h→0f(x+h)−f(x)
h, (5.4)
and the secant in Figure 5.3 becomes a tangent.
The derivative of fpoints in the direction of steepest ascent of f.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
142 Vector Calculus
Example 5.2 (Derivative of a Polynomial)
We want to compute the derivative of f(x) =xn, n∈N. We may already
know that the answer will be nxn−1, but we want to derive this result
using the definition of the derivative as the limit of the difference quotient.
Using the definition of the derivative in (5.4), we obtain
df
dx= lim
h→0f(x+h)−f(x)
h(5.5a)
= lim
h→0(x+h)n−xn
h(5.5b)
= lim
h→0Pn
i=0 n
ixn−ihi−xn
h. (5.5c)
We see that xn= n
0xn−0h0. By starting the sum at 1, thexn-term cancels,
and we obtain
df
dx= lim
h→0Pn
i=1 n
ixn−ihi
h(5.6a)
= lim
h→0nX
i=1 
n
i!
xn−ihi−1(5.6b)
= lim
h→0 
n
1!
xn−1+nX
i=2 
n
i!
xn−ihi−1
| {z }
→0ash→0(5.6c)
=n!
1!(n−1)!xn−1=nxn−1. (5.6d)
5.1.1 Taylor Series
The Taylor series is a representation of a function fas an infinite sum of
terms. These terms are determined using derivatives of fevaluated at x0.
Definition 5.3 (Taylor Polynomial) .TheTaylor polynomial of degree nof Taylor polynomial
f:R→Ratx0is defined as We define t0:= 1
for all t∈R.
Tn(x) :=nX
k=0f(k)(x0)
k!(x−x0)k, (5.7)
where f(k)(x0)is the kth derivative of fatx0(which we assume exists)
andf(k)(x0)
k!are the coefficients of the polynomial.
Definition 5.4 (Taylor Series) .For a smooth function f∈ C∞,f:R→R,
theTaylor series offatx0is defined as Taylor series
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
5.1 Differentiation of Univariate Functions 143
T∞(x) =∞X
k=0f(k)(x0)
k!(x−x0)k. (5.8)
Forx0= 0, we obtain the Maclaurin series as a special instance of the f∈ C∞means that
fis continuously
differentiable
infinitely many
times.
Maclaurin seriesTaylor series. If f(x) =T∞(x), then fis called analytic .
analyticRemark. In general, a Taylor polynomial of degree nis an approximation
of a function, which does not need to be a polynomial. The Taylor poly-
nomial is similar to fin a neighborhood around x0. However, a Taylor
polynomial of degree nis an exact representation of a polynomial fof
degree k⩽nsince all derivatives f(i),i > k vanish. ♢
Example 5.3 (Taylor Polynomial)
We consider the polynomial
f(x) =x4(5.9)
and seek the Taylor polynomial T6, evaluated at x0= 1. We start by com-
puting the coefficients f(k)(1)fork= 0, . . . , 6:
f(1) = 1 (5.10)
f′(1) = 4 (5.11)
f′′(1) = 12 (5.12)
f(3)(1) = 24 (5.13)
f(4)(1) = 24 (5.14)
f(5)(1) = 0 (5.15)
f(6)(1) = 0 (5.16)
Therefore, the desired Taylor polynomial is
T6(x) =6X
k=0f(k)(x0)
k!(x−x0)k(5.17a)
= 1 + 4( x−1) + 6( x−1)2+ 4(x−1)3+ (x−1)4+ 0.(5.17b)
Multiplying out and re-arranging yields
T6(x) = (1 −4 + 6−4 + 1) + x(4−12 + 12 −4)
+x2(6−12 + 6) + x3(4−4) +x4(5.18a)
=x4=f(x), (5.18b)
i.e., we obtain an exact representation of the original function.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
144 Vector Calculus
Figure 5.4 Taylor
polynomials. The
original function
f(x) =
sin(x) + cos( x)
(black, solid) is
approximated by
Taylor polynomials
(dashed) around
x0= 0.
Higher-order Taylor
polynomials
approximate the
function fbetter
and more globally.
T10is already
similar to fin
[−4,4].
−4−2 0 2 4
x−2024yf
T0
T1
T5
T10
Example 5.4 (Taylor Series)
Consider the function in Figure 5.4 given by
f(x) = sin( x) + cos( x)∈ C∞. (5.19)
We seek a Taylor series expansion of fatx0= 0, which is the Maclaurin
series expansion of f. We obtain the following derivatives:
f(0) = sin(0) + cos(0) = 1 (5.20)
f′(0) = cos(0) −sin(0) = 1 (5.21)
f′′(0) =−sin(0) −cos(0) = −1 (5.22)
f(3)(0) =−cos(0) + sin(0) = −1 (5.23)
f(4)(0) = sin(0) + cos(0) = f(0) = 1 (5.24)
...
We can see a pattern here: The coefficients in our Taylor series are only
±1(since sin(0) = 0 ), each of which occurs twice before switching to the
other one. Furthermore, f(k+4)(0) = f(k)(0).
Therefore, the full Taylor series expansion of fatx0= 0is given by
T∞(x) =∞X
k=0f(k)(x0)
k!(x−x0)k(5.25a)
= 1 + x−1
2!x2−1
3!x3+1
4!x4+1
5!x5− ··· (5.25b)
= 1−1
2!x2+1
4!x4∓ ··· +x−1
3!x3+1
5!x5∓ ··· (5.25c)
=∞X
k=0(−1)k1
(2k)!x2k+∞X
k=0(−1)k 1
(2k+ 1)!x2k+1(5.25d)
= cos( x) + sin( x), (5.25e)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
5.1 Differentiation of Univariate Functions 145
where we used the power series representations power series
representation
cos(x) =∞X
k=0(−1)k1
(2k)!x2k, (5.26)
sin(x) =∞X
k=0(−1)k 1
(2k+ 1)!x2k+1. (5.27)
Figure 5.4 shows the corresponding first Taylor polynomials Tnforn=
0,1,5,10.
Remark. A Taylor series is a special case of a power series
f(x) =∞X
k=0ak(x−c)k(5.28)
where akare coefficients and cis a constant, which has the special form
in Definition 5.4. ♢
5.1.2 Differentiation Rules
In the following, we briefly state basic differentiation rules, where we
denote the derivative of fbyf′.
Product rule: (f(x)g(x))′=f′(x)g(x) +f(x)g′(x) (5.29)
Quotient rule:f(x)
g(x)′
=f′(x)g(x)−f(x)g′(x)
(g(x))2(5.30)
Sum rule: (f(x) +g(x))′=f′(x) +g′(x) (5.31)
Chain rule: g(f(x))′= (g◦f)′(x) =g′(f(x))f′(x) (5.32)
Here, g◦fdenotes function composition x7→f(x)7→g(f(x)).
Example 5.5 (Chain Rule)
Let us compute the derivative of the function h(x) = (2 x+ 1)4using the
chain rule. With
h(x) = (2 x+ 1)4=g(f(x)), (5.33)
f(x) = 2 x+ 1, (5.34)
g(f) =f4, (5.35)
we obtain the derivatives of fandgas
f′(x) = 2 , (5.36)
g′(f) = 4 f3, (5.37)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
146 Vector Calculus
such that the derivative of his given as
h′(x) =g′(f)f′(x) = (4 f3)·2(5.34)= 4(2 x+ 1)3·2 = 8(2 x+ 1)3,(5.38)
where we used the chain rule (5.32) and substituted the definition of f
in (5.34) in g′(f).
5.2 Partial Differentiation and Gradients
Differentiation as discussed in Section 5.1 applies to functions fof a
scalar variable x∈R. In the following, we consider the general case
where the function fdepends on one or more variables x∈Rn, e.g.,
f(x) =f(x1, x2). The generalization of the derivative to functions of sev-
eral variables is the gradient .
We find the gradient of the function fwith respect to xbyvarying one
variable at a time and keeping the others constant. The gradient is then
the collection of these partial derivatives .
Definition 5.5 (Partial Derivative) .For a function f:Rn→R,x7→
f(x),x∈Rnofnvariables x1, . . . , x nwe define the partial derivatives as partial derivative
∂f
∂x1= lim
h→0f(x1+h, x 2, . . . , x n)−f(x)
h
...
∂f
∂xn= lim
h→0f(x1, . . . , x n−1, xn+h)−f(x)
h(5.39)
and collect them in the row vector
∇xf= grad f=df
dx=∂f(x)
∂x1∂f(x)
∂x2···∂f(x)
∂xn
∈R1×n,(5.40)
where nis the number of variables and 1is the dimension of the image/
range/codomain of f. Here, we defined the column vector x= [x1, . . . , x n]⊤
∈Rn. The row vector in (5.40) is called the gradient offor the Jacobian gradient
Jacobian and is the generalization of the derivative from Section 5.1.
Remark. This definition of the Jacobian is a special case of the general
definition of the Jacobian for vector-valued functions as the collection of
partial derivatives. We will get back to this in Section 5.3. ♢We can use results
from scalar
differentiation: Each
partial derivative is
a derivative with
respect to a scalar.Example 5.6 (Partial Derivatives Using the Chain Rule)
Forf(x, y) = (x+ 2y3)2, we obtain the partial derivatives
∂f(x, y)
∂x= 2(x+ 2y3)∂
∂x(x+ 2y3) = 2( x+ 2y3), (5.41)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
5.2 Partial Differentiation and Gradients 147
∂f(x, y)
∂y= 2(x+ 2y3)∂
∂y(x+ 2y3) = 12( x+ 2y3)y2. (5.42)
where we used the chain rule (5.32) to compute the partial derivatives.
Remark (Gradient as a Row Vector) .It is not uncommon in the literature
to define the gradient vector as a column vector, following the conven-
tion that vectors are generally column vectors. The reason why we define
the gradient vector as a row vector is twofold: First, we can consistently
generalize the gradient to vector-valued functions f:Rn→Rm(then
the gradient becomes a matrix). Second, we can immediately apply the
multi-variate chain rule without paying attention to the dimension of the
gradient. We will discuss both points in Section 5.3. ♢
Example 5.7 (Gradient)
Forf(x1, x2) =x2
1x2+x1x3
2∈R, the partial derivatives (i.e., the deriva-
tives of fwith respect to x1andx2) are
∂f(x1, x2)
∂x1= 2x1x2+x3
2 (5.43)
∂f(x1, x2)
∂x2=x2
1+ 3x1x2
2 (5.44)
and the gradient is then
df
dx=∂f(x1, x2)
∂x1∂f(x1, x2)
∂x2
=2x1x2+x3
2x2
1+ 3x1x2
2∈R1×2.
(5.45)
5.2.1 Basic Rules of Partial Differentiation
Product rule:
(fg)′=f′g+fg′,
Sum rule:
(f+g)′=f′+g′,
Chain rule:
(g(f))′=g′(f)f′In the multivariate case, where x∈Rn, the basic differentiation rules that
we know from school (e.g., sum rule, product rule, chain rule; see also
Section 5.1.2) still apply. However, when we compute derivatives with re-
spect to vectors x∈Rnwe need to pay attention: Our gradients now
involve vectors and matrices, and matrix multiplication is not commuta-
tive (Section 2.2.1), i.e., the order matters.
Here are the general product rule, sum rule, and chain rule:
Product rule:∂
∂x f(x)g(x)=∂f
∂xg(x) +f(x)∂g
∂x(5.46)
Sum rule:∂
∂x f(x) +g(x)=∂f
∂x+∂g
∂x(5.47)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
148 Vector Calculus
Chain rule:∂
∂x(g◦f)(x) =∂
∂x g(f(x))=∂g
∂f∂f
∂x(5.48)
Let us have a closer look at the chain rule. The chain rule (5.48) resem- This is only an
intuition, but not
mathematically
correct since the
partial derivative is
not a fraction.bles to some degree the rules for matrix multiplication where we said that
neighboring dimensions have to match for matrix multiplication to be de-
fined; see Section 2.2.1. If we go from left to right, the chain rule exhibits
similar properties: ∂fshows up in the “denominator” of the first factor
and in the “numerator” of the second factor. If we multiply the factors to-
gether, multiplication is defined, i.e., the dimensions of ∂fmatch, and ∂f
“cancels”, such that ∂g/∂xremains.
5.2.2 Chain Rule
Consider a function f:R2→Rof two variables x1, x2. Furthermore,
x1(t)andx2(t)are themselves functions of t. To compute the gradient of
fwith respect to t, we need to apply the chain rule (5.48) for multivariate
functions as
df
dt=h
∂f
∂x1∂f
∂x2i"
∂x1(t)
∂t∂x2(t)
∂t#
=∂f
∂x1∂x1
∂t+∂f
∂x2∂x2
∂t, (5.49)
where ddenotes the gradient and ∂partial derivatives.
Example 5.8
Consider f(x1, x2) =x2
1+ 2x2, where x1= sin tandx2= cos t, then
df
dt=∂f
∂x1∂x1
∂t+∂f
∂x2∂x2
∂t(5.50a)
= 2 sin t∂sint
∂t+ 2∂cost
∂t(5.50b)
= 2 sin tcost−2 sint= 2 sin t(cost−1) (5.50c)
is the corresponding derivative of fwith respect to t.
Iff(x1, x2)is a function of x1andx2, where x1(s, t)andx2(s, t)are
themselves functions of two variables sandt, the chain rule yields the
partial derivatives
∂f
∂s=∂f
∂x1∂x1
∂s+∂f
∂x2∂x2
∂s, (5.51)
∂f
∂t=∂f
∂x1∂x1
∂t+∂f
∂x2∂x2
∂t, (5.52)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
5.3 Gradients of Vector-Valued Functions 149
and the gradient is obtained by the matrix multiplication
df
d(s, t)=∂f
∂x∂x
∂(s, t)=h∂f
∂x1∂f
∂x2i
|{z}
=∂f
∂x
∂x1
∂s∂x1
∂t
∂x2
∂s∂x2
∂t

|{z }
=∂x
∂(s, t). (5.53)
This compact way of writing the chain rule as a matrix multiplication only The chain rule can
be written as a
matrix
multiplication.makes sense if the gradient is defined as a row vector. Otherwise, we will
need to start transposing gradients for the matrix dimensions to match.
This may still be straightforward as long as the gradient is a vector or a
matrix; however, when the gradient becomes a tensor (we will discuss this
in the following), the transpose is no longer a triviality.
Remark (Verifying the Correctness of a Gradient Implementation) .The
definition of the partial derivatives as the limit of the corresponding dif-
ference quotient (see (5.39)) can be exploited when numerically checking
the correctness of gradients in computer programs: When we compute Gradient checking
gradients and implement them, we can use finite differences to numer-
ically test our computation and implementation: We choose the value h
to be small (e.g., h= 10−4) and compare the finite-difference approxima-
tion from (5.39) with our (analytic) implementation of the gradient. If the
error is small, our gradient implementation is probably correct. “Small”
could mean thatqP
i(dhi−d fi)2
P
i(dhi+d fi)2<10−6, where dhiis the finite-difference
approximation and d fiis the analytic gradient of fwith respect to the ith
variable xi. ♢
5.3 Gradients of Vector-Valued Functions
Thus far, we discussed partial derivatives and gradients of functions f:
Rn→Rmapping to the real numbers. In the following, we will generalize
the concept of the gradient to vector-valued functions (vector fields) f:
Rn→Rm, where n⩾1andm > 1.
For a function f:Rn→Rmand a vector x= [x1, . . . , x n]⊤∈Rn, the
corresponding vector of function values is given as
f(x) =
f1(x)
...
fm(x)
∈Rm. (5.54)
Writing the vector-valued function in this way allows us to view a vector-
valued function f:Rn→Rmas a vector of functions [f1, . . . , f m]⊤,
fi:Rn→Rthat map onto R. The differentiation rules for every fiare
exactly the ones we discussed in Section 5.2.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
150 Vector Calculus
Therefore, the partial derivative of a vector-valued function f:Rn→
Rmwith respect to xi∈R,i= 1, . . . n , is given as the vector
∂f
∂xi=
∂f1
∂xi...
∂fm
∂xi
=
limh→0f1(x1,...,x i−1,xi+h,xi+1,...xn)−f1(x)
h...
limh→0fm(x1,...,x i−1,xi+h,xi+1,...xn)−fm(x)
h
∈Rm.
(5.55)
From (5.40), we know that the gradient of fwith respect to a vector is
the row vector of the partial derivatives. In (5.55), every partial derivative
∂f/∂x iis itself a column vector. Therefore, we obtain the gradient of f:
Rn→Rmwith respect to x∈Rnby collecting these partial derivatives:
df(x)
dx= ∂f(x)
∂x1···∂f(x)
∂xn 
(5.56a)
=∂f1(x)
∂x1···∂f1(x)
∂xn
......
∂fm(x)
∂x1···∂fm(x)
∂xn

∈Rm×n.(5.56b)
Definition 5.6 (Jacobian) .The collection of all first-order partial deriva-
tives of a vector-valued function f:Rn→Rmis called the Jacobian . The Jacobian
Jacobian Jis an m×nmatrix, which we define and arrange as follows: The gradient of a
function
f:Rn→Rmis a
matrix of size
m×n.J=∇xf=df(x)
dx=∂f(x)
∂x1···∂f(x)
∂xn
(5.57)
=
∂f1(x)
∂x1···∂f1(x)
∂xn......
∂fm(x)
∂x1···∂fm(x)
∂xn
, (5.58)
x=
x1
...
xn
, J(i, j) =∂fi
∂xj. (5.59)
As a special case of (5.58), a function f:Rn→R1, which maps a
vector x∈Rnonto a scalar (e.g., f(x) =Pn
i=1xi), possesses a Jacobian
that is a row vector (matrix of dimension 1×n); see (5.40).
Remark. In this book, we use the numerator layout of the derivative, i.e., numerator layout
the derivative df/dxoff∈Rmwith respect to x∈Rnis an m×
nmatrix, where the elements of fdefine the rows and the elements of
xdefine the columns of the corresponding Jacobian; see (5.58). There
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
5.3 Gradients of Vector-Valued Functions 151
Figure 5.5 The
determinant of the
Jacobian of fcan
be used to compute
the magnifier
between the blue
and orange area.b1b2 c1 c2f(·)
exists also the denominator layout , which is the transpose of the numerator denominator layout
layout. In this book, we will use the numerator layout. ♢
We will see how the Jacobian is used in the change-of-variable method
for probability distributions in Section 6.7. The amount of scaling due to
the transformation of a variable is provided by the determinant.
In Section 4.1, we saw that the determinant can be used to compute
the area of a parallelogram. If we are given two vectors b1= [1,0]⊤,
b2= [0,1]⊤as the sides of the unit square (blue; see Figure 5.5), the area
of this square is
det1 0
0 1= 1. (5.60)
If we take a parallelogram with the sides c1= [−2,1]⊤,c2= [1,1]⊤
(orange in Figure 5.5), its area is given as the absolute value of the deter-
minant (see Section 4.1)
det−2 1
1 1=| −3|= 3, (5.61)
i.e., the area of this is exactly three times the area of the unit square.
We can find this scaling factor by finding a mapping that transforms the
unit square into the other square. In linear algebra terms, we effectively
perform a variable transformation from (b1,b2)to(c1,c2). In our case,
the mapping is linear and the absolute value of the determinant of this
mapping gives us exactly the scaling factor we are looking for.
We will describe two approaches to identify this mapping. First, we ex-
ploit that the mapping is linear so that we can use the tools from Chapter 2
to identify this mapping. Second, we will find the mapping using partial
derivatives using the tools we have been discussing in this chapter.
Approach 1 To get started with the linear algebra approach, we
identify both {b1,b2}and{c1,c2}as bases of R2(see Section 2.6.1 for a
recap). What we effectively perform is a change of basis from (b1,b2)to
(c1,c2), and we are looking for the transformation matrix that implements
the basis change. Using results from Section 2.7.2, we identify the desired
basis change matrix as
J=−2 1
1 1
, (5.62)
such that Jb1=c1andJb2=c2. The absolute value of the determi-
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
152 Vector Calculus
nant of J, which yields the scaling factor we are looking for, is given as
|det(J)|= 3, i.e., the area of the square spanned by (c1,c2)is three times
greater than the area spanned by (b1,b2).
Approach 2 The linear algebra approach works for linear trans-
formations; for nonlinear transformations (which become relevant in Sec-
tion 6.7), we follow a more general approach using partial derivatives.
For this approach, we consider a function f:R2→R2that performs a
variable transformation. In our example, fmaps the coordinate represen-
tation of any vector x∈R2with respect to (b1,b2)onto the coordinate
representation y∈R2with respect to (c1,c2). We want to identify the
mapping so that we can compute how an area (or volume) changes when
it is being transformed by f. For this, we need to find out how f(x)
changes if we modify xa bit. This question is exactly answered by the
Jacobian matrixdf
dx∈R2×2. Since we can write
y1=−2x1+x2 (5.63)
y2=x1+x2 (5.64)
we obtain the functional relationship between xandy, which allows us
to get the partial derivatives
∂y1
∂x1=−2,∂y1
∂x2= 1,∂y2
∂x1= 1,∂y2
∂x2= 1 (5.65)
and compose the Jacobian as
J=
∂y1
∂x1∂y1
∂x2∂y2
∂x1∂y2
∂x2
=−2 1
1 1
. (5.66)
The Jacobian represents the coordinate transformation we are looking Geometrically, the
Jacobian
determinant gives
the magnification/
scaling factor when
we transform an
area or volume.for. It is exact if the coordinate transformation is linear (as in our case),
and (5.66) recovers exactly the basis change matrix in (5.62). If the co-
ordinate transformation is nonlinear, the Jacobian approximates this non-
linear transformation locally with a linear one. The absolute value of the
Jacobian determinant |det(J)|is the factor by which areas or volumes are
Jacobian
determinantscaled when coordinates are transformed. Our case yields |det(J)|= 3.
The Jacobian determinant and variable transformations will become
relevant in Section 6.7 when we transform random variables and prob-
ability distributions. These transformations are extremely relevant in ma- Figure 5.6
Dimensionality of
(partial) derivatives.
f(x)
x
@f
@xchine learning in the context of training deep neural networks using the
reparametrization trick , also called infinite perturbation analysis .
In this chapter, we encountered derivatives of functions. Figure 5.6 sum-
marizes the dimensions of those derivatives. If f:R→Rthe gradient is
simply a scalar (top-left entry). For f:RD→Rthe gradient is a 1×D
row vector (top-right entry). For f:R→RE, the gradient is an E×1
column vector, and for f:RD→REthe gradient is an E×Dmatrix.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
5.3 Gradients of Vector-Valued Functions 153
Example 5.9 (Gradient of a Vector-Valued Function)
We are given
f(x) =Ax,f(x)∈RM,A∈RM×N,x∈RN.
To compute the gradient df/dxwe first determine the dimension of
df/dx: Since f:RN→RM, it follows that df/dx∈RM×N. Second,
to compute the gradient we determine the partial derivatives of fwith
respect to every xj:
fi(x) =NX
j=1Aijxj=⇒∂fi
∂xj=Aij (5.67)
We collect the partial derivatives in the Jacobian and obtain the gradient
df
dx=
∂f1
∂x1···∂f1
∂xN......
∂fM
∂x1···∂fM
∂xN
=
A11··· A1N
......
AM1···AMN
=A∈RM×N.(5.68)
Example 5.10 (Chain Rule)
Consider the function h:R→R,h(t) = (f◦g)(t)with
f:R2→R (5.69)
g:R→R2(5.70)
f(x) = exp( x1x2
2), (5.71)
x=x1
x2
=g(t) =tcost
tsint
(5.72)
and compute the gradient of hwith respect to t. Since f:R2→Rand
g:R→R2we note that
∂f
∂x∈R1×2,∂g
∂t∈R2×1. (5.73)
The desired gradient is computed by applying the chain rule:
dh
dt=∂f
∂x∂x
∂t=∂f
∂x1∂f
∂x2
∂x1
∂t∂x2
∂t
 (5.74a)
=exp(x1x2
2)x2
22 exp( x1x2
2)x1x2cost−tsint
sint+tcost
(5.74b)
= exp( x1x2
2) x2
2(cost−tsint) + 2x1x2(sint+tcost),(5.74c)
where x1=tcostandx2=tsint; see (5.72).
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
154 Vector Calculus
Example 5.11 (Gradient of a Least-Squares Loss in a Linear Model)
Let us consider the linear model We will discuss this
model in much
more detail in
Chapter 9 in the
context of linear
regression, where
we need derivatives
of the least-squares
lossLwith respect
to the parameters θ.y=Φθ, (5.75)
where θ∈RDis a parameter vector, Φ∈RN×Dare input features and
y∈RNare the corresponding observations. We define the functions
L(e) :=∥e∥2, (5.76)
e(θ) :=y−Φθ. (5.77)
We seek∂L
∂θ, and we will use the chain rule for this purpose. Lis called a
least-squares loss function. least-squares loss
Before we start our calculation, we determine the dimensionality of the
gradient as
∂L
∂θ∈R1×D. (5.78)
The chain rule allows us to compute the gradient as
∂L
∂θ=∂L
∂e∂e
∂θ, (5.79)
where the dth element is given by dLdtheta =
np.einsum(
’n,nd’,
dLde,dedtheta)∂L
∂θ[1, d] =NX
n=1∂L
∂e[n]∂e
∂θ[n, d]. (5.80)
We know that ∥e∥2=e⊤e(see Section 3.2) and determine
∂L
∂e= 2e⊤∈R1×N. (5.81)
Furthermore, we obtain
∂e
∂θ=−Φ∈RN×D, (5.82)
such that our desired derivative is
∂L
∂θ=−2e⊤Φ(5.77)=−2(y⊤−θ⊤Φ⊤)|{z }
1×NΦ|{z}
N×D∈R1×D. (5.83)
Remark. We would have obtained the same result without using the chain
rule by immediately looking at the function
L2(θ) :=∥y−Φθ∥2= (y−Φθ)⊤(y−Φθ). (5.84)
This approach is still practical for simple functions like L2but becomes
impractical for deep function compositions. ♢
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
5.4 Gradients of Matrices 155
Figure 5.7
Visualization of
gradient
computation of a
matrix with respect
to a vector. We are
interested in
computing the
gradient of
A∈R4×2with
respect to a vector
x∈R3. We know
that gradient
dA
dx∈R4×2×3. We
follow two
equivalent
approaches to arrive
there: (a) collating
partial derivatives
into a Jacobian
tensor;
(b) flattening of the
matrix into a vector,
computing the
Jacobian matrix,
re-shaping into a
Jacobian tensor.A∈R4×2x∈R3
∂A
∂x1∈R4×2∂A
∂x2∈R4×2∂A
∂x3∈R4×2x1
x2
x3
dA
dx∈R4×2×3
4
23Partial derivatives:
collate
(a) Approach 1: We compute the partial derivative
∂A
∂x1,∂A
∂x2,∂A
∂x3, each of which is a 4×2matrix, and col-
late them in a 4×2×3tensor.
A∈R4×2x∈R3
x1
x2
x3
dA
dx∈R4×2×3
re-shape re-shape gradientA∈R4×2 ˜A∈R8d˜A
dx∈R8×3
(b) Approach 2: We re-shape (flatten) A∈R4×2into a vec-
tor˜A∈R8. Then, we compute the gradientd˜A
dx∈R8×3.
We obtain the gradient tensor by re-shaping this gradient as
illustrated above.
5.4 Gradients of MatricesWe can think of a
tensor as a
multidimensional
array.We will encounter situations where we need to take gradients of matrices
with respect to vectors (or other matrices), which results in a multidimen-
sional tensor. We can think of this tensor as a multidimensional array that
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
156 Vector Calculus
collects partial derivatives. For example, if we compute the gradient of an
m×nmatrix Awith respect to a p×qmatrix B, the resulting Jacobian
would be (m×n)×(p×q), i.e., a four-dimensional tensor J, whose entries
are given as Jijkl=∂Aij/∂B kl.
Since matrices represent linear mappings, we can exploit the fact that
there is a vector-space isomorphism (linear, invertible mapping) between
the space Rm×nofm×nmatrices and the space Rmnofmnvectors.
Therefore, we can re-shape our matrices into vectors of lengths mnand
pq, respectively. The gradient using these mnvectors results in a Jacobian
of size mn×pq. Figure 5.7 visualizes both approaches. In practical ap- Matrices can be
transformed into
vectors by stacking
the columns of the
matrix
(“flattening”).plications, it is often desirable to re-shape the matrix into a vector and
continue working with this Jacobian matrix: The chain rule (5.48) boils
down to simple matrix multiplication, whereas in the case of a Jacobian
tensor, we will need to pay more attention to what dimensions we need
to sum out.
Example 5.12 (Gradient of Vectors with Respect to Matrices)
Let us consider the following example, where
f=Ax,f∈RM,A∈RM×N,x∈RN(5.85)
and where we seek the gradient df/dA. Let us start again by determining
the dimension of the gradient as
df
dA∈RM×(M×N). (5.86)
By definition, the gradient is the collection of the partial derivatives:
df
dA=
∂f1
∂A...
∂fM
∂A
,∂fi
∂A∈R1×(M×N). (5.87)
To compute the partial derivatives, it will be helpful to explicitly write out
the matrix vector multiplication:
fi=NX
j=1Aijxj, i= 1, . . . , M , (5.88)
and the partial derivatives are then given as
∂fi
∂Aiq=xq. (5.89)
This allows us to compute the partial derivatives of fiwith respect to a
row of A, which is given as
∂fi
∂Ai,:=x⊤∈R1×1×N, (5.90)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
5.4 Gradients of Matrices 157
∂fi
∂Ak̸=i,:=0⊤∈R1×1×N(5.91)
where we have to pay attention to the correct dimensionality. Since fi
maps onto Rand each row of Ais of size 1×N, we obtain a 1×1×N-
sized tensor as the partial derivative of fiwith respect to a row of A.
We stack the partial derivatives (5.91) and get the desired gradient
in (5.87) via
∂fi
∂A=
0⊤
...
0⊤
x⊤
0⊤
...
0⊤
∈R1×(M×N). (5.92)
Example 5.13 (Gradient of Matrices with Respect to Matrices)
Consider a matrix R∈RM×Nandf:RM×N→RN×Nwith
f(R) =R⊤R=:K∈RN×N, (5.93)
where we seek the gradient dK/dR.
To solve this hard problem, let us first write down what we already
know: The gradient has the dimensions
dK
dR∈R(N×N)×(M×N), (5.94)
which is a tensor. Moreover,
dKpq
dR∈R1×M×N(5.95)
forp, q= 1, . . . , N , where Kpqis the (p, q)th entry of K=f(R). De-
noting the ith column of Rbyri, every entry of Kis given by the dot
product of two columns of R, i.e.,
Kpq=r⊤
prq=MX
m=1RmpRmq. (5.96)
When we now compute the partial derivative∂Kpq
∂Rijwe obtain
∂Kpq
∂Rij=MX
m=1∂
∂RijRmpRmq=∂pqij, (5.97)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
158 Vector Calculus
∂pqij=

Riq ifj=p, p̸=q
Rip ifj=q, p̸=q
2Riqifj=p, p=q
0 otherwise. (5.98)
From (5.94), we know that the desired gradient has the dimension (N×
N)×(M×N), and every single entry of this tensor is given by ∂pqij
in (5.98), where p, q, j = 1, . . . , N andi= 1, . . . , M .
5.5 Useful Identities for Computing Gradients
In the following, we list some useful gradients that are frequently required
in a machine learning context (Petersen and Pedersen, 2012). Here, we
use tr (·)as the trace (see Definition 4.4), det(·)as the determinant (see
Section 4.1) and f(X)−1as the inverse of f(X), assuming it exists.
∂
∂Xf(X)⊤=∂f(X)
∂X⊤
(5.99)
∂
∂Xtr(f(X)) = tr∂f(X)
∂X
(5.100)
∂
∂Xdet(f(X)) = det( f(X))tr
f(X)−1∂f(X)
∂X
(5.101)
∂
∂Xf(X)−1=−f(X)−1∂f(X)
∂Xf(X)−1(5.102)
∂a⊤X−1b
∂X=−(X−1)⊤ab⊤(X−1)⊤(5.103)
∂x⊤a
∂x=a⊤(5.104)
∂a⊤x
∂x=a⊤(5.105)
∂a⊤Xb
∂X=ab⊤(5.106)
∂x⊤Bx
∂x=x⊤(B+B⊤) (5.107)
∂
∂s(x−As)⊤W(x−As) =−2(x−As)⊤WA for symmetric W
(5.108)
Remark. In this book, we only cover traces and transposes of matrices.
However, we have seen that derivatives can be higher-dimensional ten-
sors, in which case the usual trace and transpose are not defined. In these
cases, the trace of a D×D×E×Ftensor would be an E×F-dimensional
matrix. This is a special case of a tensor contraction. Similarly, when we
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
5.6 Backpropagation and Automatic Differentiation 159
“transpose” a tensor, we mean swapping the first two dimensions. Specif-
ically, in (5.99) through (5.102), we require tensor-related computations
when we work with multivariate functions f(·)and compute derivatives
with respect to matrices (and choose not to vectorize them as discussed in
Section 5.4). ♢
5.6 Backpropagation and Automatic Differentiation
A good discussion
about
backpropagation
and the chain rule is
available at a blog
by Tim Vieira at
https://tinyurl.
com/ycfm2yrw .In many machine learning applications, we find good model parameters
by performing gradient descent (Section 7.1), which relies on the fact
that we can compute the gradient of a learning objective with respect
to the parameters of the model. For a given objective function, we can
obtain the gradient with respect to the model parameters using calculus
and applying the chain rule; see Section 5.2.2. We already had a taste in
Section 5.3 when we looked at the gradient of a squared loss with respect
to the parameters of a linear regression model.
Consider the function
f(x) =q
x2+ exp( x2) + cos x2+ exp( x2). (5.109)
By application of the chain rule, and noting that differentiation is linear,
we compute the gradient
df
dx=2x+ 2xexp(x2)
2p
x2+ exp( x2)−sin x2+ exp( x2) 2x+ 2xexp(x2)
= 2x 
1
2p
x2+ exp( x2)−sin x2+ exp( x2)!
 1 + exp( x2).
(5.110)
Writing out the gradient in this explicit way is often impractical since it
often results in a very lengthy expression for a derivative. In practice,
it means that, if we are not careful, the implementation of the gradient
could be significantly more expensive than computing the function, which
imposes unnecessary overhead. For training deep neural network mod-
els, the backpropagation algorithm (Kelley, 1960; Bryson, 1961; Dreyfus, backpropagation
1962; Rumelhart et al., 1986) is an efficient way to compute the gradient
of an error function with respect to the parameters of the model.
5.6.1 Gradients in a Deep Network
An area where the chain rule is used to an extreme is deep learning, where
the function value yis computed as a many-level function composition
y= (fK◦fK−1◦ ··· ◦ f1)(x) =fK(fK−1(···(f1(x))···)),(5.111)
where xare the inputs (e.g., images), yare the observations (e.g., class
labels), and every function fi,i= 1, . . . , K , possesses its own parameters.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
160 Vector Calculus
Figure 5.8 Forward
pass in a multi-layer
neural network to
compute the loss L
as a function of the
inputs xand the
parameters Ai,bi.x fK
A0,b0 AK−1,bK−1L fK−1
AK−2,bK−2f1
A1,b1
In neural networks with multiple layers, we have functions fi(xi−1) = We discuss the case,
where the activation
functions are
identical in each
layer to unclutter
notation.σ(Ai−1xi−1+bi−1)in the ith layer. Here xi−1is the output of layer i−1
andσan activation function, such as the logistic sigmoid1
1+e−x,tanh or a
rectified linear unit (ReLU). In order to train these models, we require the
gradient of a loss function Lwith respect to all model parameters Aj,bj
forj= 1, . . . , K . This also requires us to compute the gradient of Lwith
respect to the inputs of each layer. For example, if we have inputs xand
observations yand a network structure defined by
f0:=x (5.112)
fi:=σi(Ai−1fi−1+bi−1), i= 1, . . . , K , (5.113)
see also Figure 5.8 for a visualization, we may be interested in finding
Aj,bjforj= 0, . . . , K −1, such that the squared loss
L(θ) =∥y−fK(θ,x)∥2(5.114)
is minimized, where θ={A0,b0, . . . ,AK−1,bK−1}.
To obtain the gradients with respect to the parameter set θ, we require
the partial derivatives of Lwith respect to the parameters θj={Aj,bj}
of each layer j= 0, . . . , K −1. The chain rule allows us to determine the
partial derivatives as A more in-depth
discussion about
gradients of neural
networks can be
found in Justin
Domke’s lecture
notes
https://tinyurl.
com/yalcxgtv .∂L
∂θK−1=∂L
∂fK∂fK
∂θK−1(5.115)
∂L
∂θK−2=∂L
∂fK∂fK
∂fK−1∂fK−1
∂θK−2(5.116)
∂L
∂θK−3=∂L
∂fK∂fK
∂fK−1∂fK−1
∂fK−2∂fK−2
∂θK−3(5.117)
∂L
∂θi=∂L
∂fK∂fK
∂fK−1···∂fi+2
∂fi+1∂fi+1
∂θi(5.118)
Theorange terms are partial derivatives of the output of a layer with
respect to its inputs, whereas the blue terms are partial derivatives of
the output of a layer with respect to its parameters. Assuming, we have
already computed the partial derivatives ∂L/∂θi+1, then most of the com-
putation can be reused to compute ∂L/∂θi. The additional terms that we
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
5.6 Backpropagation and Automatic Differentiation 161
Figure 5.9
Backward pass in a
multi-layer neural
network to compute
the gradients of the
loss function.x fK
A0,b0 AK−1,bK−1L fK−1
AK−2,bK−2f1
A1,b1
Figure 5.10 Simple
graph illustrating
the flow of data
from xtoyvia
some intermediate
variables a, b.x a b y
need to compute are indicated by the boxes. Figure 5.9 visualizes that the
gradients are passed backward through the network.
5.6.2 Automatic Differentiation
It turns out that backpropagation is a special case of a general technique
in numerical analysis called automatic differentiation . We can think of au- automatic
differentiation tomatic differentation as a set of techniques to numerically (in contrast to
symbolically) evaluate the exact (up to machine precision) gradient of a
function by working with intermediate variables and applying the chain
rule. Automatic differentiation applies a series of elementary arithmetic Automatic
differentiation is
different from
symbolic
differentiation and
numerical
approximations of
the gradient, e.g., by
using finite
differences.operations, e.g., addition and multiplication and elementary functions,
e.g.,sin,cos,exp,log. By applying the chain rule to these operations, the
gradient of quite complicated functions can be computed automatically.
Automatic differentiation applies to general computer programs and has
forward and reverse modes. Baydin et al. (2018) give a great overview of
automatic differentiation in machine learning.
Figure 5.10 shows a simple graph representing the data flow from in-
putsxto outputs yvia some intermediate variables a, b. If we were to
compute the derivative dy/dx, we would apply the chain rule and obtain
dy
dx=dy
dbdb
dada
dx. (5.119)
Intuitively, the forward and reverse mode differ in the order of multipli- In the general case,
we work with
Jacobians, which
can be vectors,
matrices, or tensors.cation. Due to the associativity of matrix multiplication, we can choose
between
dy
dx=dy
dbdb
dada
dx, (5.120)
dy
dx=dy
dbdb
dada
dx
. (5.121)
Equation (5.120) would be the reverse mode because gradients are prop- reverse mode
agated backward through the graph, i.e., reverse to the data flow. Equa-
tion (5.121) would be the forward mode , where the gradients flow with forward mode
the data from left to right through the graph.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
162 Vector Calculus
In the following, we will focus on reverse mode automatic differentia-
tion, which is backpropagation. In the context of neural networks, where
the input dimensionality is often much higher than the dimensionality of
the labels, the reverse mode is computationally significantly cheaper than
the forward mode. Let us start with an instructive example.
Example 5.14
Consider the function
f(x) =q
x2+ exp( x2) + cos x2+ exp( x2)
(5.122)
from (5.109). If we were to implement a function fon a computer, we
would be able to save some computation by using intermediate variables : intermediate
variables
a=x2, (5.123)
b= exp( a), (5.124)
c=a+b , (5.125)
d=√c , (5.126)
e= cos( c), (5.127)
f=d+e . (5.128)
Figure 5.11
Computation graph
with inputs x,
function values f,
and intermediate
variables a, b, c, d, e .x (·)2 aexp(·) b
+ c√·
cos(·)d
e+ f
This is the same kind of thinking process that occurs when applying
the chain rule. Note that the preceding set of equations requires fewer
operations than a direct implementation of the function f(x)as defined
in (5.109). The corresponding computation graph in Figure 5.11 shows
the flow of data and computations required to obtain the function value
f.
The set of equations that include intermediate variables can be thought
of as a computation graph, a representation that is widely used in imple-
mentations of neural network software libraries. We can directly compute
the derivatives of the intermediate variables with respect to their corre-
sponding inputs by recalling the definition of the derivative of elementary
functions. We obtain the following:
∂a
∂x= 2x (5.129)
∂b
∂a= exp( a) (5.130)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
5.6 Backpropagation and Automatic Differentiation 163
∂c
∂a= 1 =∂c
∂b(5.131)
∂d
∂c=1
2√c(5.132)
∂e
∂c=−sin(c) (5.133)
∂f
∂d= 1 =∂f
∂e. (5.134)
By looking at the computation graph in Figure 5.11, we can compute
∂f/∂x by working backward from the output and obtain
∂f
∂c=∂f
∂d∂d
∂c+∂f
∂e∂e
∂c(5.135)
∂f
∂b=∂f
∂c∂c
∂b(5.136)
∂f
∂a=∂f
∂b∂b
∂a+∂f
∂c∂c
∂a(5.137)
∂f
∂x=∂f
∂a∂a
∂x. (5.138)
Note that we implicitly applied the chain rule to obtain ∂f/∂x . By substi-
tuting the results of the derivatives of the elementary functions, we get
∂f
∂c= 1·1
2√c+ 1·(−sin(c)) (5.139)
∂f
∂b=∂f
∂c·1 (5.140)
∂f
∂a=∂f
∂bexp(a) +∂f
∂c·1 (5.141)
∂f
∂x=∂f
∂a·2x . (5.142)
By thinking of each of the derivatives above as a variable, we observe
that the computation required for calculating the derivative is of similar
complexity as the computation of the function itself. This is quite counter-
intuitive since the mathematical expression for the derivative∂f
∂x(5.110)
is significantly more complicated than the mathematical expression of the
function f(x)in (5.109).
Automatic differentiation is a formalization of Example 5.14. Let x1, . . . , x d
be the input variables to the function, xd+1, . . . , x D−1be the intermediate
variables, and xDthe output variable. Then the computation graph can be
expressed as follows:
Fori=d+ 1, . . . , D :xi=gi(xPa(xi)), (5.143)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
164 Vector Calculus
where the gi(·)are elementary functions and xPa(xi)are the parent nodes
of the variable xiin the graph. Given a function defined in this way, we
can use the chain rule to compute the derivative of the function in a step-
by-step fashion. Recall that by definition f=xDand hence
∂f
∂xD= 1. (5.144)
For other variables xi, we apply the chain rule
∂f
∂xi=X
xj:xi∈Pa(xj)∂f
∂xj∂xj
∂xi=X
xj:xi∈Pa(xj)∂f
∂xj∂gj
∂xi, (5.145)
where Pa(xj)is the set of parent nodes of xjin the computation graph.
Equation (5.143) is the forward propagation of a function, whereas (5.145) Auto-differentiation
in reverse mode
requires a parse
tree.is the backpropagation of the gradient through the computation graph.
For neural network training, we backpropagate the error of the prediction
with respect to the label.
The automatic differentiation approach above works whenever we have
a function that can be expressed as a computation graph, where the ele-
mentary functions are differentiable. In fact, the function may not even be
a mathematical function but a computer program. However, not all com-
puter programs can be automatically differentiated, e.g., if we cannot find
differential elementary functions. Programming structures, such as for
loops and ifstatements, require more care as well.
5.7 Higher-Order Derivatives
So far, we have discussed gradients, i.e., first-order derivatives. Some-
times, we are interested in derivatives of higher order, e.g., when we want
to use Newton’s Method for optimization, which requires second-order
derivatives (Nocedal and Wright, 2006). In Section 5.1.1, we discussed
the Taylor series to approximate functions using polynomials. In the mul-
tivariate case, we can do exactly the same. In the following, we will do
exactly this. But let us start with some notation.
Consider a function f:R2→Rof two variables x, y. We use the
following notation for higher-order partial derivatives (and for gradients):
∂2f
∂x2is the second partial derivative of fwith respect to x.
∂nf
∂xnis the nth partial derivative of fwith respect to x.
∂2f
∂y∂x=∂
∂y ∂f
∂x
is the partial derivative obtained by first partial differ-
entiating with respect to xand then with respect to y.
∂2f
∂x∂yis the partial derivative obtained by first partial differentiating by
yand then x.
TheHessian is the collection of all second-order partial derivatives. Hessian
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
5.8 Linearization and Multivariate Taylor Series 165
Figure 5.12 Linear
approximation of a
function. The
original function f
is linearized at
x0=−2using a
first-order Taylor
series expansion.
−4−2 0 2 4
x−2−101f(x)f(x)
f(x0)f(x0) +f/prime(x0)(x−x0)
Iff(x, y)is a twice (continuously) differentiable function, then
∂2f
∂x∂y=∂2f
∂y∂x, (5.146)
i.e., the order of differentiation does not matter, and the corresponding
Hessian matrix Hessian matrix
H=
∂2f
∂x2∂2f
∂x∂y
∂2f
∂x∂y∂2f
∂y2
(5.147)
is symmetric. The Hessian is denoted as ∇2
x,yf(x, y). Generally, for x∈Rn
andf:Rn→R, the Hessian is an n×nmatrix. The Hessian measures
the curvature of the function locally around (x, y).
Remark (Hessian of a Vector Field) .Iff:Rn→Rmis a vector field, the
Hessian is an (m×n×n)-tensor. ♢
5.8 Linearization and Multivariate Taylor Series
The gradient ∇fof a function fis often used for a locally linear approxi-
mation of faround x0:
f(x)≈f(x0) + (∇xf)(x0)(x−x0). (5.148)
Here (∇xf)(x0)is the gradient of fwith respect to x, evaluated at x0.
Figure 5.12 illustrates the linear approximation of a function fat an input
x0. The original function is approximated by a straight line. This approx-
imation is locally accurate, but the farther we move away from x0the
worse the approximation gets. Equation (5.148) is a special case of a mul-
tivariate Taylor series expansion of fatx0, where we consider only the
first two terms. We discuss the more general case in the following, which
will allow for better approximations.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
166 Vector Calculus
Figure 5.13
Visualizing outer
products. Outer
products of vectors
increase the
dimensionality of
the array by 1 per
term. (a) The outer
product of two
vectors results in a
matrix; (b) the
outer product of
three vectors yields
a third-order tensor.
(a) Given a vector δ∈R4, we obtain the outer product δ2:=δ⊗δ=δδ⊤∈
R4×4as a matrix.
(b) An outer product δ3:=δ⊗δ⊗δ∈R4×4×4results in a third-order tensor (“three-
dimensional matrix”), i.e., an array with three indexes.
Definition 5.7 (Multivariate Taylor Series) .We consider a function
f:RD→R (5.149)
x7→f(x),x∈RD, (5.150)
that is smooth at x0. When we define the difference vector δ:=x−x0,
themultivariate Taylor series offat(x0)is defined as multivariate Taylor
series
f(x) =∞X
k=0Dk
xf(x0)
k!δk, (5.151)
where Dk
xf(x0)is the k-th (total) derivative of fwith respect to x, eval-
uated at x0.
Definition 5.8 (Taylor Polynomial) .TheTaylor polynomial of degree nof Taylor polynomial
fatx0contains the first n+ 1components of the series in (5.151) and is
defined as
Tn(x) =nX
k=0Dk
xf(x0)
k!δk. (5.152)
In (5.151) and (5.152), we used the slightly sloppy notation of δk,
which is not defined for vectors x∈RD, D > 1,andk >1. Note that
both Dk
xfandδkarek-th order tensors, i.e., k-dimensional arrays. The A vector can be
implemented as a
one-dimensional
array, a matrix as a
two-dimensional
array.kth-order tensor δk∈Rktimesz}|{
D×D×...×Dis obtained as a k-fold outer product,
denoted by ⊗, of the vector δ∈RD. For example,
δ2:=δ⊗δ=δδ⊤,δ2[i, j] =δ[i]δ[j] (5.153)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
5.8 Linearization and Multivariate Taylor Series 167
δ3:=δ⊗δ⊗δ,δ3[i, j, k ] =δ[i]δ[j]δ[k]. (5.154)
Figure 5.13 visualizes two such outer products. In general, we obtain the
terms
Dk
xf(x0)δk=DX
i1=1···DX
ik=1Dk
xf(x0)[i1, . . . , i k]δ[i1]···δ[ik](5.155)
in the Taylor series, where Dk
xf(x0)δkcontains k-th order polynomials.
Now that we defined the Taylor series for vector fields, let us explicitly
write down the first terms Dk
xf(x0)δkof the Taylor series expansion for
k= 0, . . . , 3andδ:=x−x0:np.einsum(
’i,i’,Df1,d)
np.einsum(
’ij,i,j’,
Df2,d,d)
np.einsum(
’ijk,i,j,k’,
Df3,d,d,d)k= 0 : D0
xf(x0)δ0=f(x0)∈R (5.156)
k= 1 : D1
xf(x0)δ1=∇xf(x0)|{z}
1×Dδ|{z}
D×1=DX
i=1∇xf(x0)[i]δ[i]∈R(5.157)
k= 2 : D2
xf(x0)δ2=tr H(x0)|{z}
D×Dδ|{z}
D×1δ⊤
|{z}
1×D=δ⊤H(x0)δ (5.158)
=DX
i=1DX
j=1H[i, j]δ[i]δ[j]∈R (5.159)
k= 3 : D3
xf(x0)δ3=DX
i=1DX
j=1DX
k=1D3
xf(x0)[i, j, k ]δ[i]δ[j]δ[k]∈R
(5.160)
Here, H(x0)is the Hessian of fevaluated at x0.
Example 5.15 (Taylor Series Expansion of a Function with Two Vari-
ables)
Consider the function
f(x, y) =x2+ 2xy+y3. (5.161)
We want to compute the Taylor series expansion of fat(x0, y0) = (1 ,2).
Before we start, let us discuss what to expect: The function in (5.161) is
a polynomial of degree 3. We are looking for a Taylor series expansion,
which itself is a linear combination of polynomials. Therefore, we do not
expect the Taylor series expansion to contain terms of fourth or higher
order to express a third-order polynomial. This means that it should be
sufficient to determine the first four terms of (5.151) for an exact alterna-
tive representation of (5.161).
To determine the Taylor series expansion, we start with the constant
term and the first-order derivatives, which are given by
f(1,2) = 13 (5.162)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
168 Vector Calculus
∂f
∂x= 2x+ 2y=⇒∂f
∂x(1,2) = 6 (5.163)
∂f
∂y= 2x+ 3y2=⇒∂f
∂y(1,2) = 14 . (5.164)
Therefore, we obtain
D1
x,yf(1,2) =∇x,yf(1,2) =h
∂f
∂x(1,2)∂f
∂y(1,2)i
=6 14∈R1×2
(5.165)
such that
D1
x,yf(1,2)
1!δ=6 14x−1
y−2
= 6(x−1) + 14( y−2).(5.166)
Note that D1
x,yf(1,2)δcontains only linear terms, i.e., first-order polyno-
mials.
The second-order partial derivatives are given by
∂2f
∂x2= 2 = ⇒∂2f
∂x2(1,2) = 2 (5.167)
∂2f
∂y2= 6y=⇒∂2f
∂y2(1,2) = 12 (5.168)
∂2f
∂y∂x= 2 = ⇒∂2f
∂y∂x(1,2) = 2 (5.169)
∂2f
∂x∂y= 2 = ⇒∂2f
∂x∂y(1,2) = 2 . (5.170)
When we collect the second-order partial derivatives, we obtain the Hes-
sian
H="∂2f
∂x2∂2f
∂x∂y
∂2f
∂y∂x∂2f
∂y2#
=2 2
2 6y
, (5.171)
such that
H(1,2) =2 2
2 12
∈R2×2. (5.172)
Therefore, the next term of the Taylor-series expansion is given by
D2
x,yf(1,2)
2!δ2=1
2δ⊤H(1,2)δ (5.173a)
=1
2x−1y−22 2
2 12x−1
y−2
(5.173b)
= (x−1)2+ 2(x−1)(y−2) + 6( y−2)2.(5.173c)
Here, D2
x,yf(1,2)δ2contains only quadratic terms, i.e., second-order poly-
nomials.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
5.8 Linearization and Multivariate Taylor Series 169
The third-order derivatives are obtained as
D3
x,yf=h
∂H
∂x∂H
∂yi
∈R2×2×2, (5.174)
D3
x,yf[:,:,1] =∂H
∂x="∂3f
∂x3∂3f
∂x2∂y
∂3f
∂x∂y∂x∂3f
∂x∂y2#
, (5.175)
D3
x,yf[:,:,2] =∂H
∂y="∂3f
∂y∂x2∂3f
∂y∂x∂y
∂3f
∂y2∂x∂3f
∂y3#
. (5.176)
Since most second-order partial derivatives in the Hessian in (5.171) are
constant, the only nonzero third-order partial derivative is
∂3f
∂y3= 6 = ⇒∂3f
∂y3(1,2) = 6 . (5.177)
Higher-order derivatives and the mixed derivatives of degree 3 (e.g.,
∂f3
∂x2∂y) vanish, such that
D3
x,yf[:,:,1] =0 0
0 0
, D3
x,yf[:,:,2] =0 0
0 6
(5.178)
and
D3
x,yf(1,2)
3!δ3= (y−2)3, (5.179)
which collects all cubic terms of the Taylor series. Overall, the (exact)
Taylor series expansion of fat(x0, y0) = (1 ,2)is
f(x) =f(1,2) +D1
x,yf(1,2)δ+D2
x,yf(1,2)
2!δ2+D3
x,yf(1,2)
3!δ3
(5.180a)
=f(1,2) +∂f(1,2)
∂x(x−1) +∂f(1,2)
∂y(y−2)
+1
2!∂2f(1,2)
∂x2(x−1)2+∂2f(1,2)
∂y2(y−2)2
+ 2∂2f(1,2)
∂x∂y(x−1)(y−2)
+1
6∂3f(1,2)
∂y3(y−2)3(5.180b)
= 13 + 6( x−1) + 14( y−2)
+ (x−1)2+ 6(y−2)2+ 2(x−1)(y−2) + ( y−2)3.(5.180c)
In this case, we obtained an exact Taylor series expansion of the polyno-
mial in (5.161), i.e., the polynomial in (5.180c) is identical to the original
polynomial in (5.161). In this particular example, this result is not sur-
prising since the original function was a third-order polynomial, which
we expressed through a linear combination of constant terms, first-order,
second-order, and third-order polynomials in (5.180c).
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
170 Vector Calculus
5.9 Further Reading
Further details of matrix differentials, along with a short review of the
required linear algebra, can be found in Magnus and Neudecker (2007).
Automatic differentiation has had a long history, and we refer to Griewank
and Walther (2003), Griewank and Walther (2008), and Elliott (2009)
and the references therein.
In machine learning (and other disciplines), we often need to compute
expectations, i.e., we need to solve integrals of the form
Ex[f(x)] =Z
f(x)p(x)dx. (5.181)
Even if p(x)is in a convenient form (e.g., Gaussian), this integral gen-
erally cannot be solved analytically. The Taylor series expansion of fis
one way of finding an approximate solution: Assuming p(x) =N µ,Σ
is Gaussian, then the first-order Taylor series expansion around µlocally
linearizes the nonlinear function f. For linear functions, we can compute
the mean (and the covariance) exactly if p(x)is Gaussian distributed (see
Section 6.5). This property is heavily exploited by the extended Kalman extended Kalman
filter filter (Maybeck, 1979) for online state estimation in nonlinear dynami-
cal systems (also called “state-space models”). Other deterministic ways
to approximate the integral in (5.181) are the unscented transform (Julier unscented transform
and Uhlmann, 1997), which does not require any gradients, or the Laplace Laplace
approximation approximation (MacKay, 2003; Bishop, 2006; Murphy, 2012), which uses
a second-order Taylor series expansion (requiring the Hessian) for a local
Gaussian approximation of p(x)around its mode.
Exercises
5.1 Compute the derivative f′(x)for
f(x) = log( x4) sin(x3).
5.2 Compute the derivative f′(x)of the logistic sigmoid
f(x) =1
1 + exp( −x).
5.3 Compute the derivative f′(x)of the function
f(x) = exp( −1
2σ2(x−µ)2),
where µ, σ∈Rare constants.
5.4 Compute the Taylor polynomials Tn,n= 0, . . . , 5off(x) = sin( x) + cos( x)
atx0= 0.
5.5 Consider the following functions:
f1(x) = sin( x1) cos( x2),x∈R2
f2(x,y) =x⊤y,x,y∈Rn
f3(x) =xx⊤,x∈Rn
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
Exercises 171
a. What are the dimensions of∂fi
∂x?
b. Compute the Jacobians.
5.6 Differentiate fwith respect to tandgwith respect to X, where
f(t) = sin(log( t⊤t)), t ∈RD
g(X) =tr(AXB ),A∈RD×E,X∈RE×F,B∈RF×D,
where tr (·)denotes the trace.
5.7 Compute the derivatives df/dxof the following functions by using the chain
rule. Provide the dimensions of every single partial derivative. Describe your
steps in detail.
a.
f(z) = log(1 + z), z =x⊤x,x∈RD
b.
f(z) = sin( z),z=Ax+b,A∈RE×D,x∈RD,b∈RE
where sin(·)is applied to every element of z.
5.8 Compute the derivatives df/dxof the following functions. Describe your
steps in detail.
a. Use the chain rule. Provide the dimensions of every single partial deriva-
tive.
f(z) = exp( −1
2z)
z=g(y) =y⊤S−1y
y=h(x) =x−µ
where x,µ∈RD,S∈RD×D.
b.
f(x) =tr(xx⊤+σ2I),x∈RD
Here tr (A)is the trace of A, i.e., the sum of the diagonal elements Aii.
Hint: Explicitly write out the outer product.
c. Use the chain rule. Provide the dimensions of every single partial deriva-
tive. You do not need to compute the product of the partial derivatives
explicitly.
f= tanh( z)∈RM
z=Ax+b,x∈RN,A∈RM×N,b∈RM.
Here, tanh is applied to every component of z.
5.9 We define
g(x,z,ν) := log p(x,z)−logq(z,ν)
z:=t(ϵ,ν)
for differentiable functions p, q, t andx∈RD,z∈RE,ν∈RF,ϵ∈RG. By
using the chain rule, compute the gradient
d
dνg(x,z,ν).
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
6
Probability and Distributions
Probability, loosely speaking, concerns the study of uncertainty. Probabil-
ity can be thought of as the fraction of times an event occurs, or as a degree
of belief about an event. We then would like to use this probability to mea-
sure the chance of something occurring in an experiment. As mentioned
in Chapter 1, we often quantify uncertainty in the data, uncertainty in the
machine learning model, and uncertainty in the predictions produced by
the model. Quantifying uncertainty requires the idea of a random variable , random variable
which is a function that maps outcomes of random experiments to a set of
properties that we are interested in. Associated with the random variable
is a function that measures the probability that a particular outcome (or
set of outcomes) will occur; this is called the probability distribution . probability
distribution Probability distributions are used as a building block for other con-
cepts, such as probabilistic modeling (Section 8.4), graphical models (Sec-
tion 8.5), and model selection (Section 8.6). In the next section, we present
the three concepts that define a probability space (the sample space, the
events, and the probability of an event) and how they are related to a
fourth concept called the random variable. The presentation is deliber-
ately slightly hand wavy since a rigorous presentation may occlude the
intuition behind the concepts. An outline of the concepts presented in this
chapter are shown in Figure 6.1.
6.1 Construction of a Probability Space
The theory of probability aims at defining a mathematical structure to
describe random outcomes of experiments. For example, when tossing a
single coin, we cannot determine the outcome, but by doing a large num-
ber of coin tosses, we can observe a regularity in the average outcome.
Using this mathematical structure of probability, the goal is to perform
automated reasoning, and in this sense, probability generalizes logical
reasoning (Jaynes, 2003).
6.1.1 Philosophical Issues
When constructing automated reasoning systems, classical Boolean logic
does not allow us to express certain forms of plausible reasoning. Consider
172
This material is published by Cambridge University Press as Mathematics for Machine Learning by
Marc Peter Deisenroth, A. Aldo Faisal, and Cheng Soon Ong (2020). This version is free to view
and download for personal use only. Not for re-distribution, re-sale, or use in derivative works.
©by M. P. Deisenroth, A. A. Faisal, and C. S. Ong, 2024. https://mml-book.com .
6.1 Construction of a Probability Space 173
Figure 6.1 A mind
map of the concepts
related to random
variables and
probability
distributions, as
described in this
chapter.
Random variable
& distributionSum rule Product ruleBayes’ Theorem
Summary statisticsMean Variance
Transformations
Independence
Inner productGaussian
Bernoulli
BetaSufficient statistics
Exponential familyChapter 9
Regression
Chapter 10
Dimensionality
reduction
Chapter 11
Density estimationProperty
SimilarityExample
ExampleConjugate
Property Finite
the following scenario: We observe that Ais false. We find Bbecomes
less plausible, although no conclusion can be drawn from classical logic.
We observe that Bis true. It seems Abecomes more plausible. We use
this form of reasoning daily. We are waiting for a friend, and consider
three possibilities: H1, she is on time; H2, she has been delayed by traffic;
and H3, she has been abducted by aliens. When we observe our friend
is late, we must logically rule out H1. We also tend to consider H2 to be
more likely, though we are not logically required to do so. Finally, we may
consider H3 to be possible, but we continue to consider it quite unlikely.
How do we conclude H2 is the most plausible answer? Seen in this way, “For plausible
reasoning it is
necessary to extend
the discrete true and
false values of truth
to continuous
plausibilities”
(Jaynes, 2003).probability theory can be considered a generalization of Boolean logic. In
the context of machine learning, it is often applied in this way to formalize
the design of automated reasoning systems. Further arguments about how
probability theory is the foundation of reasoning systems can be found
in Pearl (1988).
The philosophical basis of probability and how it should be somehow
related to what we think should be true (in the logical sense) was studied
by Cox (Jaynes, 2003). Another way to think about it is that if we are
precise about our common sense we end up constructing probabilities.
E. T. Jaynes (1922–1998) identified three mathematical criteria, which
must apply to all plausibilities:
1. The degrees of plausibility are represented by real numbers.
2. These numbers must be based on the rules of common sense.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
174 Probability and Distributions
3. The resulting reasoning must be consistent, with the three following
meanings of the word “consistent”:
(a) Consistency or non-contradiction: When the same result can be
reached through different means, the same plausibility value must
be found in all cases.
(b) Honesty: All available data must be taken into account.
(c) Reproducibility: If our state of knowledge about two problems are
the same, then we must assign the same degree of plausibility to
both of them.
The Cox–Jaynes theorem proves these plausibilities to be sufficient to
define the universal mathematical rules that apply to plausibility p, up to
transformation by an arbitrary monotonic function. Crucially, these rules
arethe rules of probability.
Remark. In machine learning and statistics, there are two major interpre-
tations of probability: the Bayesian and frequentist interpretations (Bishop,
2006; Efron and Hastie, 2016). The Bayesian interpretation uses probabil-
ity to specify the degree of uncertainty that the user has about an event. It
is sometimes referred to as “subjective probability” or “degree of belief”.
The frequentist interpretation considers the relative frequencies of events
of interest to the total number of events that occurred. The probability of
an event is defined as the relative frequency of the event in the limit when
one has infinite data. ♢
Some machine learning texts on probabilistic models use lazy notation
and jargon, which is confusing. This text is no exception. Multiple distinct
concepts are all referred to as “probability distribution”, and the reader
has to often disentangle the meaning from the context. One trick to help
make sense of probability distributions is to check whether we are trying
to model something categorical (a discrete random variable) or some-
thing continuous (a continuous random variable). The kinds of questions
we tackle in machine learning are closely related to whether we are con-
sidering categorical or continuous models.
6.1.2 Probability and Random Variables
There are three distinct ideas that are often confused when discussing
probabilities. First is the idea of a probability space, which allows us to
quantify the idea of a probability. However, we mostly do not work directly
with this basic probability space. Instead, we work with random variables
(the second idea), which transfers the probability to a more convenient
(often numerical) space. The third idea is the idea of a distribution or law
associated with a random variable. We will introduce the first two ideas
in this section and expand on the third idea in Section 6.2.
Modern probability is based on a set of axioms proposed by Kolmogorov
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
6.1 Construction of a Probability Space 175
(Grinstead and Snell, 1997; Jaynes, 2003) that introduce the three con-
cepts of sample space, event space, and probability measure. The prob-
ability space models a real-world process (referred to as an experiment)
with random outcomes.
The sample space Ω
Thesample space is the set of all possible outcomes of the experiment, sample space
usually denoted by Ω. For example, two successive coin tosses have
a sample space of {hh, tt, ht, th }, where “h” denotes “heads” and “t”
denotes “tails”.
The event space A
Theevent space is the space of potential results of the experiment. A event space
subset Aof the sample space Ωis in the event space Aif at the end
of the experiment we can observe whether a particular outcome ω∈Ω
is inA. The event space Ais obtained by considering the collection of
subsets of Ω, and for discrete probability distributions (Section 6.2.1)
Ais often the power set of Ω.
The probability P
With each event A∈ A, we associate a number P(A)that measures the
probability or degree of belief that the event will occur. P(A)is called
theprobability ofA. probability
The probability of a single event must lie in the interval [0,1], and the
total probability over all outcomes in the sample space Ωmust be 1, i.e.,
P(Ω) = 1 . Given a probability space (Ω,A, P), we want to use it to model
some real-world phenomenon. In machine learning, we often avoid explic-
itly referring to the probability space, but instead refer to probabilities on
quantities of interest, which we denote by T. In this book, we refer to T
as the target space and refer to elements of Tas states. We introduce a target space
function X: Ω→ T that takes an element of Ω(an outcome) and returns
a particular quantity of interest x, a value in T. This association/mapping
from ΩtoTis called a random variable . For example, in the case of tossing random variable
two coins and counting the number of heads, a random variable Xmaps
to the three possible outcomes: X(hh) = 2 ,X(ht) = 1 ,X(th) = 1 , and
X(tt) = 0 . In this particular case, T={0,1,2}, and it is the probabilities
on elements of Tthat we are interested in. For a finite sample space Ωand The name “random
variable” is a great
source of
misunderstanding
as it is neither
random nor is it a
variable. It is a
function.finiteT, the function corresponding to a random variable is essentially a
lookup table. For any subset S⊆ T , we associate PX(S)∈[0,1](the
probability) to a particular event occurring corresponding to the random
variable X. Example 6.1 provides a concrete illustration of the terminol-
ogy.
Remark. The aforementioned sample space Ωunfortunately is referred
to by different names in different books. Another common name for Ω
is “state space” (Jacod and Protter, 2004), but state space is sometimes
reserved for referring to states in a dynamical system (Hasselblatt and
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
176 Probability and Distributions
Katok, 2003). Other names sometimes used to describe Ωare: “sample
description space”, “possibility space,” and “event space”. ♢
Example 6.1
We assume that the reader is already familiar with computing probabilities This toy example is
essentially a biased
coin flip example.of intersections and unions of sets of events. A gentler introduction to
probability with many examples can be found in chapter 2 of Walpole
et al. (2011).
Consider a statistical experiment where we model a funfair game con-
sisting of drawing two coins from a bag (with replacement). There are
coins from USA (denoted as $) and UK (denoted as £) in the bag, and
since we draw two coins from the bag, there are four outcomes in total.
The state space or sample space Ωof this experiment is then ($, $), ($,
£), (£, $), (£, £). Let us assume that the composition of the bag of coins is
such that a draw returns at random a $ with probability 0.3.
The event we are interested in is the total number of times the repeated
draw returns $. Let us define a random variable Xthat maps the sample
space ΩtoT, which denotes the number of times we draw $ out of the
bag. We can see from the preceding sample space we can get zero $, one $,
or two $s, and therefore T={0,1,2}. The random variable X(a function
or lookup table) can be represented as a table like the following:
X(($,$)) = 2 (6.1)
X(($,£)) = 1 (6.2)
X((£,$)) = 1 (6.3)
X((£,£)) = 0 . (6.4)
Since we return the first coin we draw before drawing the second, this
implies that the two draws are independent of each other, which we will
discuss in Section 6.4.5. Note that there are two experimental outcomes,
which map to the same event, where only one of the draws returns $.
Therefore, the probability mass function (Section 6.2.1) of Xis given by
P(X= 2) = P(($,$))
=P($)·P($)
= 0.3·0.3 = 0 .09 (6.5)
P(X= 1) = P(($,£)∪(£,$))
=P(($,£)) +P((£,$))
= 0.3·(1−0.3) + (1 −0.3)·0.3 = 0 .42 (6.6)
P(X= 0) = P((£,£))
=P(£)·P(£)
= (1−0.3)·(1−0.3) = 0 .49. (6.7)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
6.1 Construction of a Probability Space 177
In the calculation, we equated two different concepts, the probability
of the output of Xand the probability of the samples in Ω. For example,
in (6.7) we say P(X= 0) = P((£,£)). Consider the random variable
X: Ω→ T and a subset S⊆ T (for example, a single element of T,
such as the outcome that one head is obtained when tossing two coins).
LetX−1(S)be the pre-image of SbyX, i.e., the set of elements of Ωthat
map to Sunder X;{ω∈Ω :X(ω)∈S}. One way to understand the
transformation of probability from events in Ωvia the random variable
Xis to associate it with the probability of the pre-image of S(Jacod and
Protter, 2004). For S⊆ T, we have the notation
PX(S) =P(X∈S) =P(X−1(S)) =P({ω∈Ω :X(ω)∈S}).(6.8)
The left-hand side of (6.8) is the probability of the set of possible outcomes
(e.g., number of $= 1) that we are interested in. Via the random variable
X, which maps states to outcomes, we see in the right-hand side of (6.8)
that this is the probability of the set of states (in Ω) that have the property
(e.g., $£,£$). We say that a random variable Xis distributed according
to a particular probability distribution PX, which defines the probability
mapping between the event and the probability of the outcome of the
random variable. In other words, the function PXor equivalently P◦X−1
is the lawordistribution of random variable X. law
distributionRemark. The target space, that is, the range Tof the random variable X,
is used to indicate the kind of probability space, i.e., a Trandom variable.
When Tis finite or countably infinite, this is called a discrete random
variable (Section 6.2.1). For continuous random variables (Section 6.2.2),
we only consider T=RorT=RD. ♢
6.1.3 Statistics
Probability theory and statistics are often presented together, but they con-
cern different aspects of uncertainty. One way of contrasting them is by the
kinds of problems that are considered. Using probability, we can consider
a model of some process, where the underlying uncertainty is captured
by random variables, and we use the rules of probability to derive what
happens. In statistics, we observe that something has happened and try
to figure out the underlying process that explains the observations. In this
sense, machine learning is close to statistics in its goals to construct a
model that adequately represents the process that generated the data. We
can use the rules of probability to obtain a “best-fitting” model for some
data.
Another aspect of machine learning systems is that we are interested
in generalization error (see Chapter 8). This means that we are actually
interested in the performance of our system on instances that we will
observe in future, which are not identical to the instances that we have
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
178 Probability and Distributions
seen so far. This analysis of future performance relies on probability and
statistics, most of which is beyond what will be presented in this chapter.
The interested reader is encouraged to look at the books by Boucheron
et al. (2013) and Shalev-Shwartz and Ben-David (2014). We will see more
about statistics in Chapter 8.
6.2 Discrete and Continuous Probabilities
Let us focus our attention on ways to describe the probability of an event
as introduced in Section 6.1. Depending on whether the target space is dis-
crete or continuous, the natural way to refer to distributions is different.
When the target space Tis discrete, we can specify the probability that a
random variable Xtakes a particular value x∈ T, denoted as P(X=x).
The expression P(X=x)for a discrete random variable Xis known as
theprobability mass function . When the target space Tis continuous, e.g., probability mass
function the real line R, it is more natural to specify the probability that a random
variable Xis in an interval, denoted by P(a⩽X⩽b)fora < b . By con-
vention, we specify the probability that a random variable Xis less than
a particular value x, denoted by P(X⩽x). The expression P(X⩽x)for
a continuous random variable Xis known as the cumulative distribution cumulative
distribution function function . We will discuss continuous random variables in Section 6.2.2.
We will revisit the nomenclature and contrast discrete and continuous
random variables in Section 6.2.3.
Remark. We will use the phrase univariate distribution to refer to distribu- univariate
tions of a single random variable (whose states are denoted by non-bold
x). We will refer to distributions of more than one random variable as
multivariate distributions, and will usually consider a vector of random multivariate
variables (whose states are denoted by bold x). ♢
6.2.1 Discrete Probabilities
When the target space is discrete, we can imagine the probability distri-
bution of multiple random variables as filling out a (multidimensional)
array of numbers. Figure 6.2 shows an example. The target space of the
joint probability is the Cartesian product of the target spaces of each of
the random variables. We define the joint probability as the entry of both joint probability
values jointly
P(X=xi, Y=yj) =nij
N, (6.9)
where nijis the number of events with state xiandyjandNthe total
number of events. The joint probability is the probability of the intersec-
tion of both events, that is, P(X=xi, Y=yj) =P(X=xi∩Y=yj).
Figure 6.2 illustrates the probability mass function (pmf) of a discrete prob- probability mass
function ability distribution. For two random variables XandY, the probability
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
6.2 Discrete and Continuous Probabilities 179
Figure 6.2
Visualization of a
discrete bivariate
probability mass
function, with
random variables X
andY. This
diagram is adapted
from Bishop (2006).
Xx1x2x3x4x5Y
y3y2y1
nijo
rjciz}|{
thatX=xandY=yis (lazily) written as p(x, y)and is called the joint
probability. One can think of a probability as a function that takes state
xandyand returns a real number, which is the reason we write p(x, y).
Themarginal probability thatXtakes the value xirrespective of the value marginal probability
of random variable Yis (lazily) written as p(x). We write X∼p(x)to
denote that the random variable Xis distributed according to p(x). If we
consider only the instances where X=x, then the fraction of instances
(theconditional probability ) for which Y=yis written (lazily) as p(y|x).conditional
probability
Example 6.2
Consider two random variables XandY, where Xhas five possible states
andYhas three possible states, as shown in Figure 6.2. We denote by nij
the number of events with state X=xiandY=yj, and denote by
Nthe total number of events. The value ciis the sum of the individual
frequencies for the ith column, that is, ci=P3
j=1nij. Similarly, the value
rjis the row sum, that is, rj=P5
i=1nij. Using these definitions, we can
compactly express the distribution of XandY.
The probability distribution of each random variable, the marginal
probability, can be seen as the sum over a row or column
P(X=xi) =ci
N=P3
j=1nij
N(6.10)
and
P(Y=yj) =rj
N=P5
i=1nij
N, (6.11)
where ciandrjare the ith column and jth row of the probability table,
respectively. By convention, for discrete random variables with a finite
number of events, we assume that probabilties sum up to one, that is,
5X
i=1P(X=xi) = 1 and3X
j=1P(Y=yj) = 1 . (6.12)
The conditional probability is the fraction of a row or column in a par-
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
180 Probability and Distributions
ticular cell. For example, the conditional probability of Ygiven Xis
P(Y=yj|X=xi) =nij
ci, (6.13)
and the conditional probability of Xgiven Yis
P(X=xi|Y=yj) =nij
rj. (6.14)
In machine learning, we use discrete probability distributions to model
categorical variables , i.e., variables that take a finite set of unordered val- categorical variable
ues. They could be categorical features, such as the degree taken at uni-
versity when used for predicting the salary of a person, or categorical la-
bels, such as letters of the alphabet when doing handwriting recognition.
Discrete distributions are also often used to construct probabilistic models
that combine a finite number of continuous distributions (Chapter 11).
6.2.2 Continuous Probabilities
We consider real-valued random variables in this section, i.e., we consider
target spaces that are intervals of the real line R. In this book, we pretend
that we can perform operations on real random variables as if we have dis-
crete probability spaces with finite states. However, this simplification is
not precise for two situations: when we repeat something infinitely often,
and when we want to draw a point from an interval. The first situation
arises when we discuss generalization errors in machine learning (Chap-
ter 8). The second situation arises when we want to discuss continuous
distributions, such as the Gaussian (Section 6.5). For our purposes, the
lack of precision allows for a briefer introduction to probability.
Remark. In continuous spaces, there are two additional technicalities,
which are counterintuitive. First, the set of all subsets (used to define
the event space Ain Section 6.1) is not well behaved enough. Aneeds
to be restricted to behave well under set complements, set intersections,
and set unions. Second, the size of a set (which in discrete spaces can be
obtained by counting the elements) turns out to be tricky. The size of a
set is called its measure . For example, the cardinality of discrete sets, the measure
length of an interval in R, and the volume of a region in Rdare all mea-
sures. Sets that behave well under set operations and additionally have
a topology are called a Borel σ-algebra . Betancourt details a careful con- Borel σ-algebra
struction of probability spaces from set theory without being bogged down
in technicalities; see https://tinyurl.com/yb3t6mfd . For a more pre-
cise construction, we refer to Billingsley (1995) and Jacod and Protter
(2004).
In this book, we consider real-valued random variables with their cor-
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
6.2 Discrete and Continuous Probabilities 181
responding Borel σ-algebra. We consider random variables with values in
RDto be a vector of real-valued random variables. ♢
Definition 6.1 (Probability Density Function) .A function f:RD→Ris
called a probability density function (pdf) if probability density
function
pdf 1.∀x∈RD:f(x)⩾0
2. Its integral exists and
Z
RDf(x)dx= 1. (6.15)
For probability mass functions (pmf) of discrete random variables, the
integral in (6.15) is replaced with a sum (6.12).
Observe that the probability density function is any function fthat is
non-negative and integrates to one. We associate a random variable X
with this function fby
P(a⩽X⩽b) =Zb
af(x)dx , (6.16)
where a, b∈Randx∈Rare outcomes of the continuous random vari-
ableX. States x∈RDare defined analogously by considering a vector
ofx∈R. This association (6.16) is called the lawordistribution of the law
random variable X.P(X=x)is a set of
measure zero. Remark. In contrast to discrete random variables, the probability of a con-
tinuous random variable Xtaking a particular value P(X=x)is zero.
This is like trying to specify an interval in (6.16) where a=b. ♢
Definition 6.2 (Cumulative Distribution Function) .Acumulative distribu- cumulative
distribution function tion function (cdf) of a multivariate real-valued random variable Xwith
states x∈RDis given by
FX(x) =P(X1⩽x1, . . . , X D⩽xD), (6.17)
where X= [X1, . . . , X D]⊤,x= [x1, . . . , x D]⊤, and the right-hand side
represents the probability that random variable Xitakes the value smaller
than or equal to xi.
There are cdfs,
which do not have
corresponding pdfs.The cdf can be expressed also as the integral of the probability density
function f(x)so that
FX(x) =Zx1
−∞···ZxD
−∞f(z1, . . . , z D)dz1···dzD. (6.18)
Remark. We reiterate that there are in fact two distinct concepts when
talking about distributions. First is the idea of a pdf (denoted by f(x)),
which is a nonnegative function that sums to one. Second is the law of a
random variable X, that is, the association of a random variable Xwith
the pdf f(x). ♢
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
182 Probability and Distributions
Figure 6.3
Examples of
(a) discrete and
(b) continuous
uniform
distributions. See
Example 6.3 for
details of the
distributions.
−1 0 1 2
z0.00.51.01.52.0P(Z=z)
(a) Discrete distribution
−1 0 1 2
x0.00.51.01.52.0p(x) (b) Continuous distribution
For most of this book, we will not use the notation f(x)andFX(x)as
we mostly do not need to distinguish between the pdf and cdf. However,
we will need to be careful about pdfs and cdfs in Section 6.7.
6.2.3 Contrasting Discrete and Continuous Distributions
Recall from Section 6.1.2 that probabilities are positive and the total prob-
ability sums up to one. For discrete random variables (see (6.12)), this
implies that the probability of each state must lie in the interval [0,1].
However, for continuous random variables the normalization (see (6.15))
does not imply that the value of the density is less than or equal to 1for
all values. We illustrate this in Figure 6.3 using the uniform distribution uniform distribution
for both discrete and continuous random variables.
Example 6.3
We consider two examples of the uniform distribution, where each state is
equally likely to occur. This example illustrates some differences between
discrete and continuous probability distributions.
LetZbe a discrete uniform random variable with three states {z=
−1.1, z= 0.3, z= 1.5}. The probability mass function can be represented The actual values of
these states are not
meaningful here,
and we deliberately
chose numbers to
drive home the
point that we do not
want to use (and
should ignore) the
ordering of the
states.as a table of probability values:
z
P(Z=z)−1.1
1
30.3
1
31.5
1
3
Alternatively, we can think of this as a graph (Figure 6.3(a)), where we
use the fact that the states can be located on the x-axis, and the y-axis
represents the probability of a particular state. The y-axis in Figure 6.3(a)
is deliberately extended so that is it the same as in Figure 6.3(b).
LetXbe a continuous random variable taking values in the range 0.9⩽
X⩽1.6, as represented by Figure 6.3(b). Observe that the height of the
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
6.3 Sum Rule, Product Rule, and Bayes’ Theorem 183
Table 6.1
Nomenclature for
probability
distributions.Type “Point probability” “Interval probability”
Discrete P(X=x) Not applicable
Probability mass function
Continuous p(x) P(X⩽x)
Probability density function Cumulative distribution function
density can be greater than 1. However, it needs to hold that
Z1.6
0.9p(x)dx= 1. (6.19)
Remark. There is an additional subtlety with regards to discrete prob-
ability distributions. The states z1, . . . , z ddo not in principle have any
structure, i.e., there is usually no way to compare them, for example
z1= red , z2= green , z3= blue . However, in many machine learning
applications discrete states take numerical values, e.g., z1=−1.1, z2=
0.3, z3= 1.5, where we could say z1< z 2< z 3. Discrete states that as-
sume numerical values are particularly useful because we often consider
expected values (Section 6.4.1) of random variables. ♢
Unfortunately, machine learning literature uses notation and nomen-
clature that hides the distinction between the sample space Ω, the target
spaceT, and the random variable X. For a value xof the set of possible
outcomes of the random variable X, i.e., x∈ T,p(x)denotes the prob- We think of the
outcome xas the
argument that
results in the
probability p(x).ability that random variable Xhas the outcome x. For discrete random
variables, this is written as P(X=x), which is known as the probabil-
ity mass function. The pmf is often referred to as the “distribution”. For
continuous variables, p(x)is called the probability density function (often
referred to as a density). To muddy things even further, the cumulative
distribution function P(X⩽x)is often also referred to as the “distribu-
tion”. In this chapter, we will use the notation Xto refer to both univariate
and multivariate random variables, and denote the states by xandxre-
spectively. We summarize the nomenclature in Table 6.1.
Remark. We will be using the expression “probability distribution” not
only for discrete probability mass functions but also for continuous proba-
bility density functions, although this is technically incorrect. In line with
most machine learning literature, we also rely on context to distinguish
the different uses of the phrase probability distribution. ♢
6.3 Sum Rule, Product Rule, and Bayes’ Theorem
We think of probability theory as an extension to logical reasoning. As we
discussed in Section 6.1.1, the rules of probability presented here follow
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
184 Probability and Distributions
naturally from fulfilling the desiderata (Jaynes, 2003, chapter 2). Prob-
abilistic modeling (Section 8.4) provides a principled foundation for de-
signing machine learning methods. Once we have defined probability dis-
tributions (Section 6.2) corresponding to the uncertainties of the data and
our problem, it turns out that there are only two fundamental rules, the
sum rule and the product rule.
Recall from (6.9) that p(x,y)is the joint distribution of the two ran-
dom variables x,y. The distributions p(x)andp(y)are the correspond-
ing marginal distributions, and p(y|x)is the conditional distribution of y
givenx. Given the definitions of the marginal and conditional probability
for discrete and continuous random variables in Section 6.2, we can now
present the two fundamental rules in probability theory. These two rules
arise
naturally (Jaynes,
2003) from the
requirements we
discussed in
Section 6.1.1.The first rule, the sum rule , states that
sum rulep(x) =

X
y∈Yp(x,y) ifyis discrete
Z
Yp(x,y)dy ifyis continuous, (6.20)
where Yare the states of the target space of random variable Y. This
means that we sum out (or integrate out) the set of states yof the random
variable Y. The sum rule is also known as the marginalization property . marginalization
property The sum rule relates the joint distribution to a marginal distribution. In
general, when the joint distribution contains more than two random vari-
ables, the sum rule can be applied to any subset of the random variables,
resulting in a marginal distribution of potentially more than one random
variable. More concretely, if x= [x1, . . . , x D]⊤, we obtain the marginal
p(xi) =Z
p(x1, . . . , x D)dx\i (6.21)
by repeated application of the sum rule where we integrate/sum out all
random variables except xi, which is indicated by \i, which reads “all
except i.”
Remark. Many of the computational challenges of probabilistic modeling
are due to the application of the sum rule. When there are many variables
or discrete variables with many states, the sum rule boils down to per-
forming a high-dimensional sum or integral. Performing high-dimensional
sums or integrals is generally computationally hard, in the sense that there
is no known polynomial-time algorithm to calculate them exactly. ♢
The second rule, known as the product rule , relates the joint distribution product rule
to the conditional distribution via
p(x,y) =p(y|x)p(x). (6.22)
The product rule can be interpreted as the fact that every joint distribu-
tion of two random variables can be factorized (written as a product)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
6.3 Sum Rule, Product Rule, and Bayes’ Theorem 185
of two other distributions. The two factors are the marginal distribu-
tion of the first random variable p(x), and the conditional distribution
of the second random variable given the first p(y|x). Since the ordering
of random variables is arbitrary in p(x,y), the product rule also implies
p(x,y) =p(x|y)p(y). To be precise, (6.22) is expressed in terms of the
probability mass functions for discrete random variables. For continuous
random variables, the product rule is expressed in terms of the probability
density functions (Section 6.2.3).
In machine learning and Bayesian statistics, we are often interested in
making inferences of unobserved (latent) random variables given that we
have observed other random variables. Let us assume we have some prior
knowledge p(x)about an unobserved random variable xand some rela-
tionship p(y|x)between xand a second random variable y, which we
can observe. If we observe y, we can use Bayes’ theorem to draw some
conclusions about xgiven the observed values of y.Bayes’ theorem (also Bayes’ theorem
Bayes’ rule orBayes’ law ) Bayes’ rule
Bayes’ law
p(x|y)|{z}
posterior=likelihoodz}|{
p(y|x)priorz}|{
p(x)
p(y)|{z}
evidence(6.23)
is a direct consequence of the product rule in (6.22) since
p(x,y) =p(x|y)p(y) (6.24)
and
p(x,y) =p(y|x)p(x) (6.25)
so that
p(x|y)p(y) =p(y|x)p(x)⇐⇒ p(x|y) =p(y|x)p(x)
p(y).(6.26)
In (6.23), p(x)is the prior , which encapsulates our subjective prior prior
knowledge of the unobserved (latent) variable xbefore observing any
data. We can choose any prior that makes sense to us, but it is critical to
ensure that the prior has a nonzero pdf (or pmf) on all plausible x, even
if they are very rare.
Thelikelihood p(y|x)describes how xandyare related, and in the likelihood
The likelihood is
sometimes also
called the
“measurement
model”.case of discrete probability distributions, it is the probability of the data y
if we were to know the latent variable x. Note that the likelihood is not a
distribution in x, but only in y. We call p(y|x)either the “likelihood of
x(given y)” or the “probability of ygiven x” but never the likelihood of
y(MacKay, 2003).
Theposterior p(x|y)is the quantity of interest in Bayesian statistics posterior
because it expresses exactly what we are interested in, i.e., what we know
about xafter having observed y.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
186 Probability and Distributions
The quantity
p(y) :=Z
p(y|x)p(x)dx=EX[p(y|x)] (6.27)
is the marginal likelihood /evidence . The right-hand side of (6.27) uses the marginal likelihood
evidence expectation operator which we define in Section 6.4.1. By definition, the
marginal likelihood integrates the numerator of (6.23) with respect to the
latent variable x. Therefore, the marginal likelihood is independent of
x, and it ensures that the posterior p(x|y)is normalized. The marginal
likelihood can also be interpreted as the expected likelihood where we
take the expectation with respect to the prior p(x). Beyond normalization
of the posterior, the marginal likelihood also plays an important role in
Bayesian model selection, as we will discuss in Section 8.6. Due to the
integration in (8.44), the evidence is often hard to compute. Bayes’ theorem is
also called the
“probabilistic
inverse.”Bayes’ theorem (6.23) allows us to invert the relationship between x
andygiven by the likelihood. Therefore, Bayes’ theorem is sometimes
called the probabilistic inverse . We will discuss Bayes’ theorem further inprobabilistic inverse
Section 8.4.
Remark. In Bayesian statistics, the posterior distribution is the quantity
of interest as it encapsulates all available information from the prior and
the data. Instead of carrying the posterior around, it is possible to focus
on some statistic of the posterior, such as the maximum of the posterior,
which we will discuss in Section 8.3. However, focusing on some statistic
of the posterior leads to loss of information. If we think in a bigger con-
text, then the posterior can be used within a decision-making system, and
having the full posterior can be extremely useful and lead to decisions that
are robust to disturbances. For example, in the context of model-based re-
inforcement learning, Deisenroth et al. (2015) show that using the full
posterior distribution of plausible transition functions leads to very fast
(data/sample efficient) learning, whereas focusing on the maximum of
the posterior leads to consistent failures. Therefore, having the full pos-
terior can be very useful for a downstream task. In Chapter 9, we will
continue this discussion in the context of linear regression. ♢
6.4 Summary Statistics and Independence
We are often interested in summarizing sets of random variables and com-
paring pairs of random variables. A statistic of a random variable is a de-
terministic function of that random variable. The summary statistics of a
distribution provide one useful view of how a random variable behaves,
and as the name suggests, provide numbers that summarize and charac-
terize the distribution. We describe the mean and the variance, two well-
known summary statistics. Then we discuss two ways to compare a pair
of random variables: first, how to say that two random variables are inde-
pendent; and second, how to compute an inner product between them.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
6.4 Summary Statistics and Independence 187
6.4.1 Means and Covariances
Mean and (co)variance are often useful to describe properties of probabil-
ity distributions (expected values and spread). We will see in Section 6.6
that there is a useful family of distributions (called the exponential fam-
ily), where the statistics of the random variable capture all possible infor-
mation.
The concept of the expected value is central to machine learning, and
the foundational concepts of probability itself can be derived from the
expected value (Whittle, 2000).
Definition 6.3 (Expected Value) .Theexpected value of a function g:R→ expected value
Rof a univariate continuous random variable X∼p(x)is given by
EX[g(x)] =Z
Xg(x)p(x)dx . (6.28)
Correspondingly, the expected value of a function gof a discrete random
variable X∼p(x)is given by
EX[g(x)] =X
x∈Xg(x)p(x), (6.29)
where Xis the set of possible outcomes (the target space) of the random
variable X.
In this section, we consider discrete random variables to have numerical
outcomes. This can be seen by observing that the function gtakes real
numbers as inputs. The expected value
of a function of a
random variable is
sometimes referred
to as the law of the
unconscious
statistician (Casella
and Berger, 2002,
Section 2.2).Remark. We consider multivariate random variables Xas a finite vector
of univariate random variables [X1, . . . , X D]⊤. For multivariate random
variables, we define the expected value element wise
EX[g(x)] =
EX1[g(x1)]
...
EXD[g(xD)]
∈RD, (6.30)
where the subscript EXdindicates that we are taking the expected value
with respect to the dth element of the vector x. ♢
Definition 6.3 defines the meaning of the notation EXas the operator
indicating that we should take the integral with respect to the probabil-
ity density (for continuous distributions) or the sum over all states (for
discrete distributions). The definition of the mean (Definition 6.4), is a
special case of the expected value, obtained by choosing gto be the iden-
tity function.
Definition 6.4 (Mean) .Themean of a random variable Xwith states mean
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
188 Probability and Distributions
x∈RDis an average and is defined as
EX[x] =
EX1[x1]
...
EXD[xD]
∈RD, (6.31)
where
EXd[xd] :=

Z
Xxdp(xd)dxd ifXis a continuous random variable
X
xi∈Xxip(xd=xi)ifXis a discrete random variable
(6.32)
ford= 1, . . . , D , where the subscript dindicates the corresponding di-
mension of x. The integral and sum are over the states Xof the target
space of the random variable X.
In one dimension, there are two other intuitive notions of “average”,
which are the median and the mode . The median is the “middle” value if median
we sort the values, i.e., 50% of the values are greater than the median and
50% are smaller than the median. This idea can be generalized to contin-
uous values by considering the value where the cdf (Definition 6.2) is 0.5.
For distributions, which are asymmetric or have long tails, the median
provides an estimate of a typical value that is closer to human intuition
than the mean value. Furthermore, the median is more robust to outliers
than the mean. The generalization of the median to higher dimensions is
non-trivial as there is no obvious way to “sort” in more than one dimen-
sion (Hallin et al., 2010; Kong and Mizera, 2012). The mode is the most mode
frequently occurring value. For a discrete random variable, the mode is
defined as the value of xhaving the highest frequency of occurrence. For
a continuous random variable, the mode is defined as a peak in the density
p(x). A particular density p(x)may have more than one mode, and fur-
thermore there may be a very large number of modes in high-dimensional
distributions. Therefore, finding all the modes of a distribution can be
computationally challenging.
Example 6.4
Consider the two-dimensional distribution illustrated in Figure 6.4:
p(x) = 0 .4N
x10
2
,1 0
0 1
+ 0.6N
x0
0
,8.4 2.0
2.0 1.7
.
(6.33)
We will define the Gaussian distribution N µ, σ2
in Section 6.5. Also
shown is its corresponding marginal distribution in each dimension. Ob-
serve that the distribution is bimodal (has two modes), but one of the
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
6.4 Summary Statistics and Independence 189
marginal distributions is unimodal (has one mode). The horizontal bi-
modal univariate distribution illustrates that the mean and median can
be different from each other. While it is tempting to define the two-
dimensional median to be the concatenation of the medians in each di-
mension, the fact that we cannot define an ordering of two-dimensional
points makes it difficult. When we say “cannot define an ordering”, we
mean that there is more than one way to define the relation <so that3
0
<2
3
.
Figure 6.4
Illustration of the
mean, mode, and
median for a
two-dimensional
dataset, as well as
its marginal
densities.
Mean
Modes
Median
Remark. The expected value (Definition 6.3) is a linear operator. For ex-
ample, given a real-valued function f(x) =ag(x)+bh(x)where a, b∈R
andx∈RD, we obtain
EX[f(x)] =Z
f(x)p(x)dx (6.34a)
=Z
[ag(x) +bh(x)]p(x)dx (6.34b)
=aZ
g(x)p(x)dx+bZ
h(x)p(x)dx (6.34c)
=aEX[g(x)] +bEX[h(x)]. (6.34d)
♢
For two random variables, we may wish to characterize their correspon-
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
190 Probability and Distributions
dence to each other. The covariance intuitively represents the notion of
how dependent random variables are to one another.
Definition 6.5 (Covariance (Univariate)) .Thecovariance between two covariance
univariate random variables X, Y∈Ris given by the expected product
of their deviations from their respective means, i.e.,
Cov X,Y[x, y] :=EX,Y(x−EX[x])(y−EY[y]). (6.35)
Terminology: The
covariance of
multivariate random
variables Cov[x, y]
is sometimes
referred to as
cross-covariance,
with covariance
referring to
Cov[x, x].Remark. When the random variable associated with the expectation or
covariance is clear by its arguments, the subscript is often suppressed (for
example, EX[x]is often written as E[x]). ♢
By using the linearity of expectations, the expression in Definition 6.5
can be rewritten as the expected value of the product minus the product
of the expected values, i.e.,
Cov[x, y] =E[xy]−E[x]E[y]. (6.36)
The covariance of a variable with itself Cov[x, x]is called the variance and variance
is denoted by VX[x]. The square root of the variance is called the standard standard deviation
deviation and is often denoted by σ(x). The notion of covariance can be
generalized to multivariate random variables.
Definition 6.6 (Covariance (Multivariate)) .If we consider two multivari-
ate random variables XandYwith states x∈RDandy∈RErespec-
tively, the covariance between XandYis defined as covariance
Cov[x,y] =E[xy⊤]−E[x]E[y]⊤= Cov[ y,x]⊤∈RD×E. (6.37)
Definition 6.6 can be applied with the same multivariate random vari-
able in both arguments, which results in a useful concept that intuitively
captures the “spread” of a random variable. For a multivariate random
variable, the variance describes the relation between individual dimen-
sions of the random variable.
Definition 6.7 (Variance) .The variance of a random variable Xwith variance
states x∈RDand a mean vector µ∈RDis defined as
VX[x] = Cov X[x,x] (6.38a)
=EX[(x−µ)(x−µ)⊤] =EX[xx⊤]−EX[x]EX[x]⊤(6.38b)
=
Cov[x1, x1] Cov[ x1, x2]. . . Cov[x1, xD]
Cov[x2, x1] Cov[ x2, x2]. . . Cov[x2, xD]
............
Cov[xD, x1] . . . . . . Cov[xD, xD]
. (6.38c)
TheD×Dmatrix in (6.38c) is called the covariance matrix of the mul- covariance matrix
tivariate random variable X. The covariance matrix is symmetric and pos-
itive semidefinite and tells us something about the spread of the data. On
its diagonal, the covariance matrix contains the variances of the marginals marginal
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
6.4 Summary Statistics and Independence 191
Figure 6.5
Two-dimensional
datasets with
identical means and
variances along
each axis (colored
lines) but with
different
covariances.
−5 0 5
x−20246y
(a)xandyare negatively correlated.
−5 0 5
x−20246y
 (b)xandyare positively correlated.
p(xi) =Z
p(x1, . . . , x D)dx\i, (6.39)
where “ \i” denotes “all variables but i”. The off-diagonal entries are the
cross-covariance terms Cov[xi, xj]fori, j= 1, . . . , D, i ̸=j. cross-covariance
Remark. In this book, we generally assume that covariance matrices are
positive definite to enable better intuition. We therefore do not discuss
corner cases that result in positive semidefinite (low-rank) covariance ma-
trices. ♢
When we want to compare the covariances between different pairs of
random variables, it turns out that the variance of each random variable
affects the value of the covariance. The normalized version of covariance
is called the correlation.
Definition 6.8 (Correlation) .Thecorrelation between two random vari- correlation
ables X, Y is given by
corr[x, y] =Cov[x, y]p
V[x]V[y]∈[−1,1]. (6.40)
The correlation matrix is the covariance matrix of standardized random
variables, x/σ(x). In other words, each random variable is divided by its
standard deviation (the square root of the variance) in the correlation
matrix.
The covariance (and correlation) indicate how two random variables
are related; see Figure 6.5. Positive correlation corr [x, y]means that when
xgrows, then yis also expected to grow. Negative correlation means that
asxincreases, then ydecreases.
6.4.2 Empirical Means and Covariances
The definitions in Section 6.4.1 are often also called the population mean population mean
and covariance and covariance , as it refers to the true statistics for the population. In ma-
chine learning, we need to learn from empirical observations of data. Con-
sider a random variable X. There are two conceptual steps to go from
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
192 Probability and Distributions
population statistics to the realization of empirical statistics. First, we use
the fact that we have a finite dataset (of size N) to construct an empirical
statistic that is a function of a finite number of identical random variables,
X1, . . . , X N. Second, we observe the data, that is, we look at the realiza-
tionx1, . . . , x Nof each of the random variables and apply the empirical
statistic.
Specifically, for the mean (Definition 6.4), given a particular dataset we
can obtain an estimate of the mean, which is called the empirical mean or empirical mean
sample mean . The same holds for the empirical covariance. sample mean
Definition 6.9 (Empirical Mean and Covariance) .Theempirical mean vec- empirical mean
tor is the arithmetic average of the observations for each variable, and it
is defined as
¯x:=1
NNX
n=1xn, (6.41)
where xn∈RD.
Similar to the empirical mean, the empirical covariance matrix is a D×D empirical covariance
matrix
Σ:=1
NNX
n=1(xn−¯x)(xn−¯x)⊤. (6.42)
Throughout the
book, we use the
empirical
covariance, which is
a biased estimate.
The unbiased
(sometimes called
corrected)
covariance has the
factor N−1in the
denominator
instead of N.To compute the statistics for a particular dataset, we would use the
realizations (observations) x1, . . . ,xNand use (6.41) and (6.42). Em-
pirical covariance matrices are symmetric, positive semidefinite (see Sec-
tion 3.2.3).
6.4.3 Three Expressions for the Variance
We now focus on a single random variable Xand use the preceding em-
pirical formulas to derive three possible expressions for the variance. The
The derivations are
exercises at the end
of this chapter.following derivation is the same for the population variance, except that
we need to take care of integrals. The standard definition of variance, cor-
responding to the definition of covariance (Definition 6.5), is the expec-
tation of the squared deviation of a random variable Xfrom its expected
value µ, i.e.,
VX[x] :=EX[(x−µ)2]. (6.43)
The expectation in (6.43) and the mean µ=EX(x)are computed us-
ing (6.32), depending on whether Xis a discrete or continuous random
variable. The variance as expressed in (6.43) is the mean of a new random
variable Z:= (X−µ)2.
When estimating the variance in (6.43) empirically, we need to resort
to a two-pass algorithm: one pass through the data to calculate the mean
µusing (6.41), and then a second pass using this estimate ˆµcalculate the
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
6.4 Summary Statistics and Independence 193
variance. It turns out that we can avoid two passes by rearranging the
terms. The formula in (6.43) can be converted to the so-called raw-score raw-score formula
for variance formula for variance :
VX[x] =EX[x2]−(EX[x])2. (6.44)
The expression in (6.44) can be remembered as “the mean of the square
minus the square of the mean”. It can be calculated empirically in one pass
through data since we can accumulate xi(to calculate the mean) and x2
i
simultaneously, where xiis the ith observation. Unfortunately, if imple- If the two terms
in (6.44) are huge
and approximately
equal, we may
suffer from an
unnecessary loss of
numerical precision
in floating-point
arithmetic.mented in this way, it can be numerically unstable. The raw-score version
of the variance can be useful in machine learning, e.g., when deriving the
bias–variance decomposition (Bishop, 2006).
A third way to understand the variance is that it is a sum of pairwise dif-
ferences between all pairs of observations. Consider a sample x1, . . . , x N
of realizations of random variable X, and we compute the squared differ-
ence between pairs of xiandxj. By expanding the square, we can show
that the sum of N2pairwise differences is the empirical variance of the
observations:
1
N2NX
i,j=1(xi−xj)2= 2
1
NNX
i=1x2
i− 
1
NNX
i=1xi!2
. (6.45)
We see that (6.45) is twice the raw-score expression (6.44). This means
that we can express the sum of pairwise distances (of which there are N2
of them) as a sum of deviations from the mean (of which there are N). Ge-
ometrically, this means that there is an equivalence between the pairwise
distances and the distances from the center of the set of points. From a
computational perspective, this means that by computing the mean ( N
terms in the summation), and then computing the variance (again N
terms in the summation), we can obtain an expression (left-hand side
of (6.45)) that has N2terms.
6.4.4 Sums and Transformations of Random Variables
We may want to model a phenomenon that cannot be well explained by
textbook distributions (we introduce some in Sections 6.5 and 6.6), and
hence may perform simple manipulations of random variables (such as
adding two random variables).
Consider two random variables X, Y with states x,y∈RD. Then:
E[x+y] =E[x] +E[y] (6.46)
E[x−y] =E[x]−E[y] (6.47)
V[x+y] =V[x] +V[y] + Cov[ x,y] + Cov[ y,x] (6.48)
V[x−y] =V[x] +V[y]−Cov[x,y]−Cov[y,x]. (6.49)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
194 Probability and Distributions
Mean and (co)variance exhibit some useful properties when it comes
to affine transformation of random variables. Consider a random variable
Xwith mean µand covariance matrix Σand a (deterministic) affine
transformation y=Ax+bofx. Then yis itself a random variable
whose mean vector and covariance matrix are given by
EY[y] =EX[Ax+b] =AEX[x] +b=Aµ+b, (6.50)
VY[y] =VX[Ax+b] =VX[Ax] =AVX[x]A⊤=AΣA⊤,(6.51)
respectively. Furthermore, This can be shown
directly by using the
definition of the
mean and
covariance.Cov[x,y] =E[x(Ax+b)⊤]−E[x]E[Ax+b]⊤(6.52a)
=E[x]b⊤+E[xx⊤]A⊤−µb⊤−µµ⊤A⊤(6.52b)
=µb⊤−µb⊤+ 
E[xx⊤]−µµ⊤A⊤(6.52c)
(6.38b)=ΣA⊤, (6.52d)
where Σ=E[xx⊤]−µµ⊤is the covariance of X.
6.4.5 Statistical Independence
Definition 6.10 (Independence) .Two random variables X, Y arestatis- statistical
independence tically independent if and only if
p(x,y) =p(x)p(y). (6.53)
Intuitively, two random variables XandYare independent if the value
ofy(once known) does not add any additional information about x(and
vice versa). If X, Y are (statistically) independent, then
p(y|x) =p(y)
p(x|y) =p(x)
VX,Y[x+y] =VX[x] +VY[y]
Cov X,Y[x,y] =0
The last point may not hold in converse, i.e., two random variables can
have covariance zero but are not statistically independent. To understand
why, recall that covariance measures only linear dependence. Therefore,
random variables that are nonlinearly dependent could have covariance
zero.
Example 6.5
Consider a random variable Xwith zero mean ( EX[x] = 0 ) and also
EX[x3] = 0 . Lety=x2(hence, Yis dependent on X) and consider the
covariance (6.36) between XandY. But this gives
Cov[x, y] =E[xy]−E[x]E[y] =E[x3] = 0 . (6.54)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
6.4 Summary Statistics and Independence 195
In machine learning, we often consider problems that can be mod-
eled as independent and identically distributed (i.i.d.) random variables, independent and
identically
distributed
i.i.d.X1, . . . , X N. For more than two random variables, the word “indepen-
dent” (Definition 6.10) usually refers to mutually independent random
variables, where all subsets are independent (see Pollard (2002, chap-
ter 4) and Jacod and Protter (2004, chapter 3)). The phrase “identically
distributed” means that all the random variables are from the same distri-
bution.
Another concept that is important in machine learning is conditional
independence.
Definition 6.11 (Conditional Independence) .Two random variables X
andYareconditionally independent given Zif and only if conditionally
independent
p(x,y|z) =p(x|z)p(y|z) for all z∈ Z, (6.55)
where Zis the set of states of random variable Z. We write X⊥ ⊥Y|Zto
denote that Xis conditionally independent of Ygiven Z.
Definition 6.11 requires that the relation in (6.55) must hold true for
every value of z. The interpretation of (6.55) can be understood as “given
knowledge about z, the distribution of xandyfactorizes”. Independence
can be cast as a special case of conditional independence if we write X⊥ ⊥
Y|∅. By using the product rule of probability (6.22), we can expand the
left-hand side of (6.55) to obtain
p(x,y|z) =p(x|y,z)p(y|z). (6.56)
By comparing the right-hand side of (6.55) with (6.56), we see that p(y|z)
appears in both of them so that
p(x|y,z) =p(x|z). (6.57)
Equation (6.57) provides an alternative definition of conditional indepen-
dence, i.e., X⊥ ⊥Y|Z. This alternative presentation provides the inter-
pretation “given that we know z, knowledge about ydoes not change our
knowledge of x”.
6.4.6 Inner Products of Random Variables
Recall the definition of inner products from Section 3.2. We can define an Inner products
between
multivariate random
variables can be
treated in a similar
fashioninner product between random variables, which we briefly describe in this
section. If we have two uncorrelated random variables X, Y , then
V[x+y] =V[x] +V[y]. (6.58)
Since variances are measured in squared units, this looks very much like
the Pythagorean theorem for right triangles c2=a2+b2.
In the following, we see whether we can find a geometric interpreta-
tion of the variance relation of uncorrelated random variables in (6.58).
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
196 Probability and Distributions
Figure 6.6
Geometry of
random variables. If
random variables X
andYare
uncorrelated, they
are orthogonal
vectors in a
corresponding
vector space, and
the Pythagorean
theorem applies.
p
var[y]
p
var[x]
p
var[x+y] =p
var[x] + var[ y]
a
c
b
Random variables can be considered vectors in a vector space, and we
can define inner products to obtain geometric properties of random vari-
ables (Eaton, 2007). If we define
⟨X, Y⟩:= Cov[ x, y] (6.59)
for zero mean random variables XandY, we obtain an inner product. We
see that the covariance is symmetric, positive definite, and linear in either Cov[x, x] = 0 ⇐⇒
x= 0 argument. The length of a random variable is
Cov[αx+z, y] =
αCov[x, y] +
Cov[z, y]forα∈R.∥X∥=q
Cov[x, x] =q
V[x] =σ[x], (6.60)
i.e., its standard deviation. The “longer” the random variable, the more
uncertain it is; and a random variable with length 0is deterministic.
If we look at the angle θbetween two random variables X, Y , we get
cosθ=⟨X, Y⟩
∥X∥ ∥Y∥=Cov[x, y]p
V[x]V[y], (6.61)
which is the correlation (Definition 6.8) between the two random vari-
ables. This means that we can think of correlation as the cosine of the
angle between two random variables when we consider them geometri-
cally. We know from Definition 3.7 that X⊥Y⇐⇒ ⟨ X, Y⟩= 0. In our
case, this means that XandYare orthogonal if and only if Cov[x, y] = 0 ,
i.e., they are uncorrelated. Figure 6.6 illustrates this relationship.
Remark. While it is tempting to use the Euclidean distance (constructed
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
6.5 Gaussian Distribution 197
Figure 6.7
Gaussian
distribution of two
random variables x1
andx2.
x1−101x2
−5.0−2.50.02.55.07.5p(x1,x2)
0.000.050.100.150.20
from the preceding definition of inner products) to compare probability
distributions, it is unfortunately not the best way to obtain distances be-
tween distributions. Recall that the probability mass (or density) is posi-
tive and needs to add up to 1. These constraints mean that distributions
live on something called a statistical manifold. The study of this space of
probability distributions is called information geometry. Computing dis-
tances between distributions are often done using Kullback-Leibler diver-
gence, which is a generalization of distances that account for properties of
the statistical manifold. Just like the Euclidean distance is a special case of
a metric (Section 3.3), the Kullback-Leibler divergence is a special case of
two more general classes of divergences called Bregman divergences and
f-divergences. The study of divergences is beyond the scope of this book,
and we refer for more details to the recent book by Amari (2016), one of
the founders of the field of information geometry. ♢
6.5 Gaussian Distribution
The Gaussian distribution is the most well-studied probability distribution
for continuous-valued random variables. It is also referred to as the normal normal distribution
distribution . Its importance originates from the fact that it has many com- The Gaussian
distribution arises
naturally when we
consider sums of
independent and
identically
distributed random
variables. This is
known as the
central limit
theorem (Grinstead
and Snell, 1997).putationally convenient properties, which we will be discussing in the fol-
lowing. In particular, we will use it to define the likelihood and prior for
linear regression (Chapter 9), and consider a mixture of Gaussians for
density estimation (Chapter 11).
There are many other areas of machine learning that also benefit from
using a Gaussian distribution, for example Gaussian processes, variational
inference, and reinforcement learning. It is also widely used in other ap-
plication areas such as signal processing (e.g., Kalman filter), control (e.g.,
linear quadratic regulator), and statistics (e.g., hypothesis testing).
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
198 Probability and Distributions
Figure 6.8
Gaussian
distributions
overlaid with 100
samples. (a) One-
dimensional case;
(b) two-dimensional
case.
−5.0−2.5 0.0 2.5 5.0 7.5
x0.000.050.100.150.20
p(x)
Mean
Sample
2σ
(a) Univariate (one-dimensional) Gaussian;
The red cross shows the mean and the red
line shows the extent of the variance.
−1 0 1
x1−4−202468x2Mean
Sample(b) Multivariate (two-dimensional) Gaus-
sian, viewed from top. The red cross shows
the mean and the colored lines show the con-
tour lines of the density.
For a univariate random variable, the Gaussian distribution has a den-
sity that is given by
p(x|µ, σ2) =1√
2πσ2exp
−(x−µ)2
2σ2
. (6.62)
The multivariate Gaussian distribution is fully characterized by a mean multivariate
Gaussian
distribution
mean vectorvector µand a covariance matrix Σand defined as
covariance matrixp(x|µ,Σ) = (2 π)−D
2|Σ|−1
2exp −1
2(x−µ)⊤Σ−1(x−µ),(6.63)
where x∈RD. We write p(x) =N x|µ,Σ
orX∼ N µ,Σ
. Fig- Also known as a
multivariate normal
distribution.ure 6.7 shows a bivariate Gaussian (mesh), with the corresponding con-
tour plot. Figure 6.8 shows a univariate Gaussian and a bivariate Gaussian
with corresponding samples. The special case of the Gaussian with zero
mean and identity covariance, that is, µ=0andΣ=I, is referred to as
thestandard normal distribution . standard normal
distribution Gaussians are widely used in statistical estimation and machine learn-
ing as they have closed-form expressions for marginal and conditional dis-
tributions. In Chapter 9, we use these closed-form expressions extensively
for linear regression. A major advantage of modeling with Gaussian ran-
dom variables is that variable transformations (Section 6.7) are often not
needed. Since the Gaussian distribution is fully specified by its mean and
covariance, we often can obtain the transformed distribution by applying
the transformation to the mean and covariance of the random variable.
6.5.1 Marginals and Conditionals of Gaussians are Gaussians
In the following, we present marginalization and conditioning in the gen-
eral case of multivariate random variables. If this is confusing at first read-
ing, the reader is advised to consider two univariate random variables in-
stead. Let XandYbe two multivariate random variables, that may have
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
6.5 Gaussian Distribution 199
different dimensions. To consider the effect of applying the sum rule of
probability and the effect of conditioning, we explicitly write the Gaus-
sian distribution in terms of the concatenated states [x⊤y⊤]⊤so that
p(x,y) =Nµx
µy
,ΣxxΣxy
ΣyxΣyy
, (6.64)
where Σxx= Cov[ x,x]andΣyy= Cov[ y,y]are the marginal covari-
ance matrices of xandy, respectively, and Σxy= Cov[ x,y]is the cross-
covariance matrix between xandy.
The conditional distribution p(x|y)is also Gaussian (illustrated in Fig-
ure 6.9(c)) and given by (derived in Section 2.3 of Bishop, 2006)
p(x|y) =N µx|y,Σx|y
(6.65)
µx|y=µx+ΣxyΣ−1
yy(y−µy) (6.66)
Σx|y=Σxx−ΣxyΣ−1
yyΣyx. (6.67)
Note that in the computation of the mean in (6.66), the y-value is an
observation and no longer random.
Remark. The conditional Gaussian distribution shows up in many places,
where we are interested in posterior distributions:
The Kalman filter (Kalman, 1960), one of the most central algorithms
for state estimation in signal processing, does nothing but computing
Gaussian conditionals of joint distributions (Deisenroth and Ohlsson,
2011; S ¨arkk¨a, 2013).
Gaussian processes (Rasmussen and Williams, 2006), which are a prac-
tical implementation of a distribution over functions. In a Gaussian pro-
cess, we make assumptions of joint Gaussianity of random variables. By
(Gaussian) conditioning on observed data, we can determine a poste-
rior distribution over functions.
Latent linear Gaussian models (Roweis and Ghahramani, 1999; Mur-
phy, 2012), which include probabilistic principal component analysis
(PPCA) (Tipping and Bishop, 1999). We will look at PPCA in more de-
tail in Section 10.7.
♢
The marginal distribution p(x)of a joint Gaussian distribution p(x,y)
(see (6.64)) is itself Gaussian and computed by applying the sum rule
(6.20) and given by
p(x) =Z
p(x,y)dy=N x|µx,Σxx. (6.68)
The corresponding result holds for p(y), which is obtained by marginaliz-
ing with respect to x. Intuitively, looking at the joint distribution in (6.64),
we ignore (i.e., integrate out) everything we are not interested in. This is
illustrated in Figure 6.9(b).
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
200 Probability and Distributions
Example 6.6
Figure 6.9
(a) Bivariate
Gaussian;
(b) marginal of a
joint Gaussian
distribution is
Gaussian; (c) the
conditional
distribution of a
Gaussian is also
Gaussian.
−1 0 1
x1−4−202468x2
x2=−1
(a) Bivariate Gaussian.
−1.5−1.0−0.5 0.0 0.5 1.0 1.5
x10.00.20.40.6p(x1)
Mean
2σ
(b) Marginal distribution.
−1.5−1.0−0.5 0.0 0.5 1.0 1.5
x10.00.20.40.60.81.01.2p(x1|x2=−1)
Mean
2σ (c) Conditional distribution.
Consider the bivariate Gaussian distribution (illustrated in Figure 6.9):
p(x1, x2) =N0
2
,0.3−1
−1 5
. (6.69)
We can compute the parameters of the univariate Gaussian, conditioned
onx2=−1, by applying (6.66) and (6.67) to obtain the mean and vari-
ance respectively. Numerically, this is
µx1|x2=−1= 0 + ( −1)·0.2·(−1−2) = 0 .6 (6.70)
and
σ2
x1|x2=−1= 0.3−(−1)·0.2·(−1) = 0 .1. (6.71)
Therefore, the conditional Gaussian is given by
p(x1|x2=−1) =N 0.6,0.1. (6.72)
The marginal distribution p(x1), in contrast, can be obtained by apply-
ing (6.68), which is essentially using the mean and variance of the random
variable x1, giving us
p(x1) =N 0,0.3. (6.73)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
6.5 Gaussian Distribution 201
6.5.2 Product of Gaussian Densities
For linear regression (Chapter 9), we need to compute a Gaussian likeli-
hood. Furthermore, we may wish to assume a Gaussian prior (Section 9.3).
We apply Bayes’ Theorem to compute the posterior, which results in a mul-
tiplication of the likelihood and the prior, that is, the multiplication of two
Gaussian densities. The product of two Gaussians N x|a,AN x|b,B
The derivation is an
exercise at the end
of this chapter.is a Gaussian distribution scaled by a c∈R, given by cN x|c,C
with
C= (A−1+B−1)−1(6.74)
c=C(A−1a+B−1b) (6.75)
c= (2π)−D
2|A+B|−1
2exp −1
2(a−b)⊤(A+B)−1(a−b).(6.76)
The scaling constant citself can be written in the form of a Gaussian
density either in aor inbwith an “inflated” covariance matrix A+B,
i.e.,c=N a|b,A+B=N b|a,A+B
.
Remark. For notation convenience, we will sometimes use N x|m,S
to describe the functional form of a Gaussian density even if xis not a
random variable. We have just done this in the preceding demonstration
when we wrote
c=N a|b,A+B=N b|a,A+B. (6.77)
Here, neither anorbare random variables. However, writing cin this way
is more compact than (6.76). ♢
6.5.3 Sums and Linear Transformations
IfX, Y are independent Gaussian random variables (i.e., the joint distri-
bution is given as p(x,y) =p(x)p(y)) with p(x) =N x|µx,Σx
and
p(y) =N y|µy,Σy
, then x+yis also Gaussian distributed and given
by
p(x+y) =N µx+µy,Σx+Σy. (6.78)
Knowing that p(x+y)is Gaussian, the mean and covariance matrix can
be determined immediately using the results from (6.46) through (6.49).
This property will be important when we consider i.i.d. Gaussian noise
acting on random variables, as is the case for linear regression (Chap-
ter 9).
Example 6.7
Since expectations are linear operations, we can obtain the weighted sum
of independent Gaussian random variables
p(ax+by) =N aµx+bµy, a2Σx+b2Σy. (6.79)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
202 Probability and Distributions
Remark. A case that will be useful in Chapter 11 is the weighted sum of
Gaussian densities. This is different from the weighted sum of Gaussian
random variables. ♢
In Theorem 6.12, the random variable xis from a density that is a
mixture of two densities p1(x)andp2(x), weighted by α. The theorem can
be generalized to the multivariate random variable case, since linearity of
expectations holds also for multivariate random variables. However, the
idea of a squared random variable needs to be replaced by xx⊤.
Theorem 6.12. Consider a mixture of two univariate Gaussian densities
p(x) =αp1(x) + (1 −α)p2(x), (6.80)
where the scalar 0< α < 1is the mixture weight, and p1(x)andp2(x)are
univariate Gaussian densities (Equation (6.62) ) with different parameters,
i.e.,(µ1, σ2
1)̸= (µ2, σ2
2).
Then the mean of the mixture density p(x)is given by the weighted sum
of the means of each random variable:
E[x] =αµ1+ (1−α)µ2. (6.81)
The variance of the mixture density p(x)is given by
V[x] =ασ2
1+ (1−α)σ2
2+αµ2
1+ (1−α)µ2
2−[αµ1+ (1−α)µ2]2
.
(6.82)
Proof The mean of the mixture density p(x)is given by the weighted
sum of the means of each random variable. We apply the definition of the
mean (Definition 6.4), and plug in our mixture (6.80), which yields
E[x] =Z∞
−∞xp(x)dx (6.83a)
=Z∞
−∞(αxp 1(x) + (1 −α)xp2(x)) dx (6.83b)
=αZ∞
−∞xp1(x)dx+ (1−α)Z∞
−∞xp2(x)dx (6.83c)
=αµ1+ (1−α)µ2. (6.83d)
To compute the variance, we can use the raw-score version of the vari-
ance from (6.44), which requires an expression of the expectation of the
squared random variable. Here we use the definition of an expectation of
a function (the square) of a random variable (Definition 6.3),
E[x2] =Z∞
−∞x2p(x)dx (6.84a)
=Z∞
−∞ αx2p1(x) + (1 −α)x2p2(x)dx (6.84b)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
6.5 Gaussian Distribution 203
=αZ∞
−∞x2p1(x)dx+ (1−α)Z∞
−∞x2p2(x)dx (6.84c)
=α(µ2
1+σ2
1) + (1 −α)(µ2
2+σ2
2), (6.84d)
where in the last equality, we again used the raw-score version of the
variance (6.44) giving σ2=E[x2]−µ2. This is rearranged such that the
expectation of a squared random variable is the sum of the squared mean
and the variance.
Therefore, the variance is given by subtracting (6.83d) from (6.84d),
V[x] =E[x2]−(E[x])2(6.85a)
=α(µ2
1+σ2
1) + (1 −α)(µ2
2+σ2
2)−(αµ1+ (1−α)µ2)2(6.85b)
=ασ2
1+ (1−α)σ2
2
+αµ2
1+ (1−α)µ2
2−[αµ1+ (1−α)µ2]2
. (6.85c)
Remark. The preceding derivation holds for any density, but since the
Gaussian is fully determined by the mean and variance, the mixture den-
sity can be determined in closed form. ♢
For a mixture density, the individual components can be considered
to be conditional distributions (conditioned on the component identity).
Equation (6.85c) is an example of the conditional variance formula, also
known as the law of total variance , which generally states that for two ran- law of total variance
dom variables XandYit holds that VX[x] =EY[VX[x|y]]+VY[EX[x|y]],
i.e., the (total) variance of Xis the expected conditional variance plus the
variance of a conditional mean.
We consider in Example 6.17 a bivariate standard Gaussian random
variable Xand performed a linear transformation Axon it. The outcome
is a Gaussian random variable with mean zero and covariance AA⊤. Ob-
serve that adding a constant vector will change the mean of the distribu-
tion, without affecting its variance, that is, the random variable x+µis
Gaussian with mean µand identity covariance. Hence, any linear/affine
transformation of a Gaussian random variable is Gaussian distributed. Any linear/affine
transformation of a
Gaussian random
variable is also
Gaussian
distributed.Consider a Gaussian distributed random variable X∼ N µ,Σ
. For
a given matrix Aof appropriate shape, let Ybe a random variable such
thaty=Axis a transformed version of x. We can compute the mean of
yby exploiting that the expectation is a linear operator (6.50) as follows:
E[y] =E[Ax] =AE[x] =Aµ. (6.86)
Similarly the variance of ycan be found by using (6.51):
V[y] =V[Ax] =AV[x]A⊤=AΣA⊤. (6.87)
This means that the random variable yis distributed according to
p(y) =N y|Aµ,AΣA⊤. (6.88)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
204 Probability and Distributions
Let us now consider the reverse transformation: when we know that a
random variable has a mean that is a linear transformation of another
random variable. For a given full rank matrix A∈RM×N, where M⩾N,
lety∈RMbe a Gaussian random variable with mean Ax, i.e.,
p(y) =N y|Ax,Σ. (6.89)
What is the corresponding probability distribution p(x)? IfAis invert-
ible, then we can write x=A−1yand apply the transformation in the
previous paragraph. However, in general Ais not invertible, and we use
an approach similar to that of the pseudo-inverse (3.57). That is, we pre-
multiply both sides with A⊤and then invert A⊤A, which is symmetric
and positive definite, giving us the relation
y=Ax⇐⇒ (A⊤A)−1A⊤y=x. (6.90)
Hence, xis a linear transformation of y, and we obtain
p(x) =N x|(A⊤A)−1A⊤y,(A⊤A)−1A⊤ΣA(A⊤A)−1.(6.91)
6.5.4 Sampling from Multivariate Gaussian Distributions
We will not explain the subtleties of random sampling on a computer, and
the interested reader is referred to Gentle (2004). In the case of a mul-
tivariate Gaussian, this process consists of three stages: first, we need a
source of pseudo-random numbers that provide a uniform sample in the
interval [0,1]; second, we use a non-linear transformation such as the
Box-M ¨uller transform (Devroye, 1986) to obtain a sample from a univari-
ate Gaussian; and third, we collate a vector of these samples to obtain a
sample from a multivariate standard normal N 0,I
.
For a general multivariate Gaussian, that is, where the mean is non
zero and the covariance is not the identity matrix, we use the proper-
ties of linear transformations of a Gaussian random variable. Assume we
are interested in generating samples xi, i= 1, . . . , n, from a multivariate
Gaussian distribution with mean µand covariance matrix Σ. We would To compute the
Cholesky
factorization of a
matrix, it is required
that the matrix is
symmetric and
positive definite
(Section 3.2.3).
Covariance matrices
possess this
property.like to construct the sample from a sampler that provides samples from
the multivariate standard normal N 0,I
.
To obtain samples from a multivariate normal N µ,Σ
, we can use
the properties of a linear transformation of a Gaussian random variable:
Ifx∼ N 0,I
, then y=Ax+µ, where AA⊤=Σis Gaussian dis-
tributed with mean µand covariance matrix Σ. One convenient choice of
Ais to use the Cholesky decomposition (Section 4.3) of the covariance
matrix Σ=AA⊤. The Cholesky decomposition has the benefit that Ais
triangular, leading to efficient computation.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
6.6 Conjugacy and the Exponential Family 205
6.6 Conjugacy and the Exponential Family
Many of the probability distributions “with names” that we find in statis-
tics textbooks were discovered to model particular types of phenomena.
For example, we have seen the Gaussian distribution in Section 6.5. The
distributions are also related to each other in complex ways (Leemis and
McQueston, 2008). For a beginner in the field, it can be overwhelming to
figure out which distribution to use. In addition, many of these distribu-
tions were discovered at a time that statistics and computation were done “Computers” used to
be a job description. by pencil and paper. It is natural to ask what are meaningful concepts
in the computing age (Efron and Hastie, 2016). In the previous section,
we saw that many of the operations required for inference can be conve-
niently calculated when the distribution is Gaussian. It is worth recalling
at this point the desiderata for manipulating probability distributions in
the machine learning context:
1. There is some “closure property” when applying the rules of probability,
e.g., Bayes’ theorem. By closure, we mean that applying a particular
operation returns an object of the same type.
2. As we collect more data, we do not need more parameters to describe
the distribution.
3. Since we are interested in learning from data, we want parameter es-
timation to behave nicely.
It turns out that the class of distributions called the exponential family exponential family
provides the right balance of generality while retaining favorable compu-
tation and inference properties. Before we introduce the exponential fam-
ily, let us see three more members of “named” probability distributions,
the Bernoulli (Example 6.8), Binomial (Example 6.9), and Beta (Exam-
ple 6.10) distributions.
Example 6.8
The Bernoulli distribution is a distribution for a single binary random Bernoulli
distribution variable Xwith state x∈ {0,1}. It is governed by a single continuous pa-
rameter µ∈[0,1]that represents the probability of X= 1. The Bernoulli
distribution Ber (µ)is defined as
p(x|µ) =µx(1−µ)1−x, x∈ {0,1}, (6.92)
E[x] =µ , (6.93)
V[x] =µ(1−µ), (6.94)
where E[x]andV[x]are the mean and variance of the binary random
variable X.
An example where the Bernoulli distribution can be used is when we
are interested in modeling the probability of “heads” when flipping a coin.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
206 Probability and Distributions
Figure 6.10
Examples of the
Binomial
distribution for
µ∈ {0.1,0.4,0.75}
andN= 15 .
0.0 2.5 5.0 7.5 10.0 12.5 15.0
Numbermof observations x= 1 inN= 15 experiments0.00.10.20.3p(m)µ= 0.1
µ= 0.4
µ= 0.75
Remark. The rewriting above of the Bernoulli distribution, where we use
Boolean variables as numerical 0or1and express them in the exponents,
is a trick that is often used in machine learning textbooks. Another oc-
curence of this is when expressing the Multinomial distribution. ♢
Example 6.9 (Binomial Distribution)
The Binomial distribution is a generalization of the Bernoulli distribution Binomial
distribution to a distribution over integers (illustrated in Figure 6.10). In particular,
the Binomial can be used to describe the probability of observing moc-
currences of X= 1 in a set of Nsamples from a Bernoulli distribution
where p(X= 1) = µ∈[0,1]. The Binomial distribution Bin (N, µ)is
defined as
p(m|N, µ) = 
N
m!
µm(1−µ)N−m, (6.95)
E[m] =Nµ , (6.96)
V[m] =Nµ(1−µ), (6.97)
where E[m]andV[m]are the mean and variance of m, respectively.
An example where the Binomial could be used is if we want to describe
the probability of observing m“heads” in Ncoin-flip experiments if the
probability for observing head in a single experiment is µ.
Example 6.10 (Beta Distribution)
We may wish to model a continuous random variable on a finite interval.
The Beta distribution is a distribution over a continuous random variable Beta distribution
µ∈[0,1], which is often used to represent the probability for some binary
event (e.g., the parameter governing the Bernoulli distribution). The Beta
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
6.6 Conjugacy and the Exponential Family 207
distribution Beta (α, β)(illustrated in Figure 6.11) itself is governed by
two parameters α >0, β > 0and is defined as
p(µ|α, β) =Γ(α+β)
Γ(α)Γ(β)µα−1(1−µ)β−1(6.98)
E[µ] =α
α+β,V[µ] =αβ
(α+β)2(α+β+ 1)(6.99)
where Γ(·)is the Gamma function defined as
Γ(t) :=Z∞
0xt−1exp(−x)dx, t > 0. (6.100)
Γ(t+ 1) = tΓ(t). (6.101)
Note that the fraction of Gamma functions in (6.98) normalizes the Beta
distribution.
Figure 6.11
Examples of the
Beta distribution for
different values of α
andβ.
0.0 0.2 0.4 0.6 0.8 1.0
µ0246810p(µ|α,β)α= 0.5 =β
α= 1 =β
α= 2,β= 0.3
α= 4,β= 10
α= 5,β= 1
Intuitively, αmoves probability mass toward 1, whereas βmoves prob-
ability mass toward 0. There are some special cases (Murphy, 2012):
Forα= 1 = β, we obtain the uniform distribution U[0,1].
Forα, β < 1, we get a bimodal distribution with spikes at 0and1.
Forα, β > 1, the distribution is unimodal.
Forα, β > 1andα=β, the distribution is unimodal, symmetric, and
centered in the interval [0,1], i.e., the mode/mean is at1
2.
Remark. There is a whole zoo of distributions with names, and they are
related in different ways to each other (Leemis and McQueston, 2008).
It is worth keeping in mind that each named distribution is created for a
particular reason, but may have other applications. Knowing the reason
behind the creation of a particular distribution often allows insight into
how to best use it. We introduced the preceding three distributions to be
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
208 Probability and Distributions
able to illustrate the concepts of conjugacy (Section 6.6.1) and exponen-
tial families (Section 6.6.3). ♢
6.6.1 Conjugacy
According to Bayes’ theorem (6.23), the posterior is proportional to the
product of the prior and the likelihood. The specification of the prior can
be tricky for two reasons: First, the prior should encapsulate our knowl-
edge about the problem before we see any data. This is often difficult to
describe. Second, it is often not possible to compute the posterior distribu-
tion analytically. However, there are some priors that are computationally
convenient: conjugate priors . conjugate prior
Definition 6.13 (Conjugate Prior) .A prior is conjugate for the likelihood conjugate
function if the posterior is of the same form/type as the prior.
Conjugacy is particularly convenient because we can algebraically cal-
culate our posterior distribution by updating the parameters of the prior
distribution.
Remark. When considering the geometry of probability distributions, con-
jugate priors retain the same distance structure as the likelihood (Agarwal
and Daum ´e III, 2010). ♢
To introduce a concrete example of conjugate priors, we describe in Ex-
ample 6.11 the Binomial distribution (defined on discrete random vari-
ables) and the Beta distribution (defined on continuous random vari-
ables).
Example 6.11 (Beta-Binomial Conjugacy)
Consider a Binomial random variable x∼Bin(N, µ)where
p(x|N, µ) = 
N
x!
µx(1−µ)N−x, x = 0,1, . . . , N , (6.102)
is the probability of finding xtimes the outcome “heads” in Ncoin flips,
where µis the probability of a “head”. We place a Beta prior on the pa-
rameter µ, that is, µ∼Beta(α, β), where
p(µ|α, β) =Γ(α+β)
Γ(α)Γ(β)µα−1(1−µ)β−1. (6.103)
If we now observe some outcome x=h, that is, we see hheads in Ncoin
flips, we compute the posterior distribution on µas
p(µ|x=h, N, α, β )∝p(x|N, µ)p(µ|α, β) (6.104a)
∝µh(1−µ)(N−h)µα−1(1−µ)β−1(6.104b)
=µh+α−1(1−µ)(N−h)+β−1(6.104c)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
6.6 Conjugacy and the Exponential Family 209
Table 6.2 Examples
of conjugate priors
for common
likelihood functions.Likelihood Conjugate prior Posterior
Bernoulli Beta Beta
Binomial Beta Beta
Gaussian Gaussian/inverse Gamma Gaussian/inverse Gamma
Gaussian Gaussian/inverse Wishart Gaussian/inverse Wishart
Multinomial Dirichlet Dirichlet
∝Beta(h+α, N−h+β), (6.104d)
i.e., the posterior distribution is a Beta distribution as the prior, i.e., the
Beta prior is conjugate for the parameter µin the Binomial likelihood
function.
In the following example, we will derive a result that is similar to the
Beta-Binomial conjugacy result. Here we will show that the Beta distribu-
tion is a conjugate prior for the Bernoulli distribution.
Example 6.12 (Beta-Bernoulli Conjugacy)
Letx∈ {0,1}be distributed according to the Bernoulli distribution with
parameter θ∈[0,1], that is, p(x= 1|θ) =θ. This can also be expressed
asp(x|θ) =θx(1−θ)1−x. Letθbe distributed according to a Beta distri-
bution with parameters α, β, that is, p(θ|α, β)∝θα−1(1−θ)β−1.
Multiplying the Beta and the Bernoulli distributions, we get
p(θ|x, α, β )∝p(x|θ)p(θ|α, β) (6.105a)
=θx(1−θ)1−xθα−1(1−θ)β−1(6.105b)
=θα+x−1(1−θ)β+(1−x)−1(6.105c)
∝p(θ|α+x, β+ (1−x)). (6.105d)
The last line is the Beta distribution with parameters (α+x, β+ (1−x)).
Table 6.2 lists examples for conjugate priors for the parameters of some
standard likelihoods used in probabilistic modeling. Distributions such as The Gamma prior is
conjugate for the
precision (inverse
variance) in the
univariate Gaussian
likelihood, and the
Wishart prior is
conjugate for the
precision matrix
(inverse covariance
matrix) in the
multivariate
Gaussian likelihood.Multinomial, inverse Gamma, inverse Wishart, and Dirichlet can be found
in any statistical text, and are described in Bishop (2006), for example.
The Beta distribution is the conjugate prior for the parameter µin both
the Binomial and the Bernoulli likelihood. For a Gaussian likelihood func-
tion, we can place a conjugate Gaussian prior on the mean. The reason
why the Gaussian likelihood appears twice in the table is that we need
to distinguish the univariate from the multivariate case. In the univariate
(scalar) case, the inverse Gamma is the conjugate prior for the variance.
In the multivariate case, we use a conjugate inverse Wishart distribution
as a prior on the covariance matrix. The Dirichlet distribution is the conju-
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
210 Probability and Distributions
gate prior for the multinomial likelihood function. For further details, we
refer to Bishop (2006).
6.6.2 Sufficient Statistics
Recall that a statistic of a random variable is a deterministic function of
that random variable. For example, if x= [x1, . . . , x N]⊤is a vector of
univariate Gaussian random variables, that is, xn∼ N µ, σ2
, then the
sample mean ˆµ=1
N(x1+···+xN)is a statistic. Sir Ronald Fisher dis-
covered the notion of sufficient statistics : the idea that there are statistics sufficient statistics
that will contain all available information that can be inferred from data
corresponding to the distribution under consideration. In other words, suf-
ficient statistics carry all the information needed to make inference about
the population, that is, they are the statistics that are sufficient to repre-
sent the distribution.
For a set of distributions parametrized by θ, letXbe a random variable
with distribution p(x|θ0)given an unknown θ0. A vector ϕ(x)of statistics
is called sufficient statistics for θ0if they contain all possible informa-
tion about θ0. To be more formal about “contain all possible information”,
this means that the probability of xgiven θcan be factored into a part
that does not depend on θ, and a part that depends on θonly via ϕ(x).
The Fisher-Neyman factorization theorem formalizes this notion, which
we state in Theorem 6.14 without proof.
Theorem 6.14 (Fisher-Neyman) .[Theorem 6.5 in Lehmann and Casella
(1998)] Let Xhave probability density function p(x|θ). Then the statistics Fisher-Neyman
theorem ϕ(x)are sufficient for θif and only if p(x|θ)can be written in the form
p(x|θ) =h(x)gθ(ϕ(x)), (6.106)
where h(x)is a distribution independent of θandgθcaptures all the depen-
dence on θvia sufficient statistics ϕ(x).
Ifp(x|θ)does not depend on θ, then ϕ(x)is trivially a sufficient statistic
for any function ϕ. The more interesting case is that p(x|θ)is dependent
only on ϕ(x)and not xitself. In this case, ϕ(x)is a sufficient statistic for
θ.
In machine learning, we consider a finite number of samples from a
distribution. One could imagine that for simple distributions (such as the
Bernoulli in Example 6.8) we only need a small number of samples to
estimate the parameters of the distributions. We could also consider the
opposite problem: If we have a set of data (a sample from an unknown
distribution), which distribution gives the best fit? A natural question to
ask is, as we observe more data, do we need more parameters θto de-
scribe the distribution? It turns out that the answer is yes in general, and
this is studied in non-parametric statistics (Wasserman, 2007). A converse
question is to consider which class of distributions have finite-dimensional
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
6.6 Conjugacy and the Exponential Family 211
sufficient statistics, that is the number of parameters needed to describe
them does not increase arbitrarily. The answer is exponential family dis-
tributions, described in the following section.
6.6.3 Exponential Family
There are three possible levels of abstraction we can have when con-
sidering distributions (of discrete or continuous random variables). At
level one (the most concrete end of the spectrum), we have a particu-
lar named distribution with fixed parameters, for example a univariate
Gaussian N 0,1
with zero mean and unit variance. In machine learning,
we often use the second level of abstraction, that is, we fix the paramet-
ric form (the univariate Gaussian) and infer the parameters from data. For
example, we assume a univariate Gaussian N µ, σ2
with unknown mean
µand unknown variance σ2, and use a maximum likelihood fit to deter-
mine the best parameters (µ, σ2). We will see an example of this when
considering linear regression in Chapter 9. A third level of abstraction is
to consider families of distributions, and in this book, we consider the ex-
ponential family. The univariate Gaussian is an example of a member of
the exponential family. Many of the widely used statistical models, includ-
ing all the “named” models in Table 6.2, are members of the exponential
family. They can all be unified into one concept (Brown, 1986).
Remark. A brief historical anecdote: Like many concepts in mathemat-
ics and science, exponential families were independently discovered at
the same time by different researchers. In the years 1935–1936, Edwin
Pitman in Tasmania, Georges Darmois in Paris, and Bernard Koopman in
New York independently showed that the exponential families are the only
families that enjoy finite-dimensional sufficient statistics under repeated
independent sampling (Lehmann and Casella, 1998). ♢
Anexponential family is a family of probability distributions, parame- exponential family
terized by θ∈RD, of the form
p(x|θ) =h(x) exp ( ⟨θ,ϕ(x)⟩ −A(θ)), (6.107)
where ϕ(x)is the vector of sufficient statistics. In general, any inner prod-
uct (Section 3.2) can be used in (6.107), and for concreteness we will use
the standard dot product here ( ⟨θ,ϕ(x)⟩=θ⊤ϕ(x)). Note that the form
of the exponential family is essentially a particular expression of gθ(ϕ(x))
in the Fisher-Neyman theorem (Theorem 6.14).
The factor h(x)can be absorbed into the dot product term by adding
another entry ( logh(x)) to the vector of sufficient statistics ϕ(x), and
constraining the corresponding parameter θ0= 1. The term A(θ)is the
normalization constant that ensures that the distribution sums up or inte-
grates to one and is called the log-partition function . A good intuitive no- log-partition
function tion of exponential families can be obtained by ignoring these two terms
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
212 Probability and Distributions
and considering exponential families as distributions of the form
p(x|θ)∝exp θ⊤ϕ(x). (6.108)
For this form of parametrization, the parameters θare called the natural natural parameters
parameters . At first glance, it seems that exponential families are a mun-
dane transformation by adding the exponential function to the result of a
dot product. However, there are many implications that allow for conve-
nient modeling and efficient computation based on the fact that we can
capture information about data in ϕ(x).
Example 6.13 (Gaussian as Exponential Family)
Consider the univariate Gaussian distribution N µ, σ2
. Letϕ(x) =x
x2
.
Then by using the definition of the exponential family,
p(x|θ)∝exp(θ1x+θ2x2). (6.109)
Setting
θ=µ
σ2,−1
2σ2⊤
(6.110)
and substituting into (6.109), we obtain
p(x|θ)∝expµx
σ2−x2
2σ2
∝exp
−1
2σ2(x−µ)2
. (6.111)
Therefore, the univariate Gaussian distribution is a member of the expo-
nential family with sufficient statistic ϕ(x) =x
x2
, and natural parame-
ters given by θin (6.110).
Example 6.14 (Bernoulli as Exponential Family)
Recall the Bernoulli distribution from Example 6.8
p(x|µ) =µx(1−µ)1−x, x∈ {0,1}. (6.112)
This can be written in exponential family form
p(x|µ) = explog µx(1−µ)1−x
(6.113a)
= exp [ xlogµ+ (1−x) log(1 −µ)] (6.113b)
= exp [ xlogµ−xlog(1−µ) + log(1 −µ)] (6.113c)
= exph
xlogµ
1−µ+ log(1 −µ)i
. (6.113d)
The last line (6.113d) can be identified as being in exponential family
form (6.107) by observing that
h(x) = 1 (6.114)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
6.6 Conjugacy and the Exponential Family 213
θ= logµ
1−µ(6.115)
ϕ(x) =x (6.116)
A(θ) =−log(1−µ) = log(1 + exp( θ)). (6.117)
The relationship between θandµis invertible so that
µ=1
1 + exp( −θ). (6.118)
The relation (6.118) is used to obtain the right equality of (6.117).
Remark. The relationship between the original Bernoulli parameter µand
the natural parameter θis known as the sigmoid or logistic function. Ob- sigmoid
serve that µ∈(0,1)butθ∈R, and therefore the sigmoid function
squeezes a real value into the range (0,1). This property is useful in ma-
chine learning, for example it is used in logistic regression (Bishop, 2006,
section 4.3.2), as well as as a nonlinear activation functions in neural net-
works (Goodfellow et al., 2016, chapter 6). ♢
It is often not obvious how to find the parametric form of the conjugate
distribution of a particular distribution (for example, those in Table 6.2).
Exponential families provide a convenient way to find conjugate pairs of
distributions. Consider the random variable Xis a member of the expo-
nential family (6.107):
p(x|θ) =h(x) exp ( ⟨θ,ϕ(x)⟩ −A(θ)). (6.119)
Every member of the exponential family has a conjugate prior (Brown,
1986)
p(θ|γ) =hc(θ) expγ1
γ2
,θ
−A(θ)
−Ac(γ)
, (6.120)
where γ=γ1
γ2
has dimension dim(θ) + 1 . The sufficient statistics of
the conjugate prior areθ
−A(θ)
. By using the knowledge of the general
form of conjugate priors for exponential families, we can derive functional
forms of conjugate priors corresponding to particular distributions.
Example 6.15
Recall the exponential family form of the Bernoulli distribution (6.113d)
p(x|µ) = exp
xlogµ
1−µ+ log(1 −µ)
. (6.121)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
214 Probability and Distributions
The canonical conjugate prior has the form
p(µ|α, β) =µ
1−µexp
αlogµ
1−µ+ (β+α) log(1 −µ)−Ac(γ)
,
(6.122)
where we defined γ:= [α, β+α]⊤andhc(µ) := µ/(1−µ). Equa-
tion (6.122) then simplifies to
p(µ|α, β) = exp [( α−1) log µ+ (β−1) log(1 −µ)−Ac(α, β)].
(6.123)
Putting this in non-exponential family form yields
p(µ|α, β)∝µα−1(1−µ)β−1, (6.124)
which we identify as the Beta distribution (6.98). In example 6.12, we
assumed that the Beta distribution is the conjugate prior of the Bernoulli
distribution and showed that it was indeed the conjugate prior. In this
example, we derived the form of the Beta distribution by looking at the
canonical conjugate prior of the Bernoulli distribution in exponential fam-
ily form.
As mentioned in the previous section, the main motivation for expo-
nential families is that they have finite-dimensional sufficient statistics.
Additionally, conjugate distributions are easy to write down, and the con-
jugate distributions also come from an exponential family. From an infer-
ence perspective, maximum likelihood estimation behaves nicely because
empirical estimates of sufficient statistics are optimal estimates of the pop-
ulation values of sufficient statistics (recall the mean and covariance of a
Gaussian). From an optimization perspective, the log-likelihood function
is concave, allowing for efficient optimization approaches to be applied
(Chapter 7).
6.7 Change of Variables/Inverse Transform
It may seem that there are very many known distributions, but in reality
the set of distributions for which we have names is quite limited. There-
fore, it is often useful to understand how transformed random variables
are distributed. For example, assuming that Xis a random variable dis-
tributed according to the univariate normal distribution N 0,1
, what is
the distribution of X2? Another example, which is quite common in ma-
chine learning, is, given that X1andX2are univariate standard normal,
what is the distribution of1
2(X1+X2)?
One option to work out the distribution of1
2(X1+X2)is to calculate
the mean and variance of X1andX2and then combine them. As we saw
in Section 6.4.4, we can calculate the mean and variance of resulting ran-
dom variables when we consider affine transformations of random vari-
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
6.7 Change of Variables/Inverse Transform 215
ables. However, we may not be able to obtain the functional form of the
distribution under transformations. Furthermore, we may be interested
in nonlinear transformations of random variables for which closed-form
expressions are not readily available.
Remark (Notation) .In this section, we will be explicit about random vari-
ables and the values they take. Hence, recall that we use capital letters
X, Y to denote random variables and small letters x, yto denote the val-
ues in the target space Tthat the random variables take. We will explicitly
write pmfs of discrete random variables XasP(X=x). For continuous
random variables X(Section 6.2.2), the pdf is written as f(x)and the cdf
is written as FX(x). ♢
We will look at two approaches for obtaining distributions of transfor-
mations of random variables: a direct approach using the definition of a
cumulative distribution function and a change-of-variable approach that
uses the chain rule of calculus (Section 5.2.2). The change-of-variable ap- Moment generating
functions can also
be used to study
transformations of
random
variables (Casella
and Berger, 2002,
chapter 2).proach is widely used because it provides a “recipe” for attempting to
compute the resulting distribution due to a transformation. We will ex-
plain the techniques for univariate random variables, and will only briefly
provide the results for the general case of multivariate random variables.
Transformations of discrete random variables can be understood di-
rectly. Suppose that there is a discrete random variable Xwith pmf P(X=
x)(Section 6.2.1), and an invertible function U(x). Consider the trans-
formed random variable Y:=U(X), with pmf P(Y=y). Then
P(Y=y) =P(U(X) =y) transformation of interest (6.125a)
=P(X=U−1(y)) inverse (6.125b)
where we can observe that x=U−1(y). Therefore, for discrete random
variables, transformations directly change the individual events (with the
probabilities appropriately transformed).
6.7.1 Distribution Function Technique
The distribution function technique goes back to first principles, and uses
the definition of a cdf FX(x) =P(X⩽x)and the fact that its differential
is the pdf f(x)(Wasserman, 2004, chapter 2). For a random variable X
and a function U, we find the pdf of the random variable Y:=U(X)by
1. Finding the cdf:
FY(y) =P(Y⩽y) (6.126)
2. Differentiating the cdf FY(y)to get the pdf f(y).
f(y) =d
dyFY(y). (6.127)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
216 Probability and Distributions
We also need to keep in mind that the domain of the random variable may
have changed due to the transformation by U.
Example 6.16
LetXbe a continuous random variable with probability density function
on0⩽x⩽1
f(x) = 3 x2. (6.128)
We are interested in finding the pdf of Y=X2.
The function fis an increasing function of x, and therefore the resulting
value of ylies in the interval [0,1]. We obtain
FY(y) =P(Y⩽y) definition of cdf (6.129a)
=P(X2⩽y) transformation of interest (6.129b)
=P(X⩽y1
2) inverse (6.129c)
=FX(y1
2) definition of cdf (6.129d)
=Zy1
2
03t2dt cdf as a definite integral (6.129e)
=t3t=y1
2
t=0result of integration (6.129f)
=y3
2,0⩽y⩽1. (6.129g)
Therefore, the cdf of Yis
FY(y) =y3
2 (6.130)
for0⩽y⩽1. To obtain the pdf, we differentiate the cdf
f(y) =d
dyFY(y) =3
2y1
2 (6.131)
for0⩽y⩽1.
In Example 6.16, we considered a strictly monotonically increasing func-
tionf(x) = 3 x2. This means that we could compute an inverse function. Functions that have
inverses are called
bijective functions
(Section 2.7).In general, we require that the function of interest y=U(x)has an in-
verse x=U−1(y). A useful result can be obtained by considering the cu-
mulative distribution function FX(x)of a random variable X, and using
it as the transformation U(x). This leads to the following theorem.
Theorem 6.15. [Theorem 2.1.10 in Casella and Berger (2002)] Let Xbe a
continuous random variable with a strictly monotonic cumulative distribu-
tion function FX(x). Then the random variable Ydefined as
Y:=FX(X) (6.132)
has a uniform distribution.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
6.7 Change of Variables/Inverse Transform 217
Theorem 6.15 is known as the probability integral transform , and it is probability integral
transform used to derive algorithms for sampling from distributions by transforming
the result of sampling from a uniform random variable (Bishop, 2006).
The algorithm works by first generating a sample from a uniform distribu-
tion, then transforming it by the inverse cdf (assuming this is available)
to obtain a sample from the desired distribution. The probability integral
transform is also used for hypothesis testing whether a sample comes from
a particular distribution (Lehmann and Romano, 2005). The idea that the
output of a cdf gives a uniform distribution also forms the basis of copu-
las (Nelsen, 2006).
6.7.2 Change of Variables
The distribution function technique in Section 6.7.1 is derived from first
principles, based on the definitions of cdfs and using properties of in-
verses, differentiation, and integration. This argument from first principles
relies on two facts:
1. We can transform the cdf of Yinto an expression that is a cdf of X.
2. We can differentiate the cdf to obtain the pdf.
Let us break down the reasoning step by step, with the goal of understand-
ing the more general change-of-variables approach in Theorem 6.16. Change of variables
in probability relies
on the
change-of-variables
method in
calculus (Tandra,
2014).Remark. The name “change of variables” comes from the idea of chang-
ing the variable of integration when faced with a difficult integral. For
univariate functions, we use the substitution rule of integration,
Z
f(g(x))g′(x)dx=Z
f(u)du , where u=g(x). (6.133)
The derivation of this rule is based on the chain rule of calculus (5.32) and
by applying twice the fundamental theorem of calculus. The fundamental
theorem of calculus formalizes the fact that integration and differentiation
are somehow “inverses” of each other. An intuitive understanding of the
rule can be obtained by thinking (loosely) about small changes (differen-
tials) to the equation u=g(x), that is by considering ∆u=g′(x)∆xas a
differential of u=g(x). By substituting u=g(x), the argument inside the
integral on the right-hand side of (6.133) becomes f(g(x)). By pretending
that the term ducan be approximated by du≈∆u=g′(x)∆x, and that
dx≈∆x, we obtain (6.133). ♢
Consider a univariate random variable X, and an invertible function
U, which gives us another random variable Y=U(X). We assume that
random variable Xhas states x∈[a, b]. By the definition of the cdf, we
have
FY(y) =P(Y⩽y). (6.134)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
218 Probability and Distributions
We are interested in a function Uof the random variable
P(Y⩽y) =P(U(X)⩽y), (6.135)
where we assume that the function Uis invertible. An invertible function
on an interval is either strictly increasing or strictly decreasing. In the case
thatUis strictly increasing, then its inverse U−1is also strictly increasing.
By applying the inverse U−1to the arguments of P(U(X)⩽y), we obtain
P(U(X)⩽y) =P(U−1(U(X))⩽U−1(y)) =P(X⩽U−1(y)).
(6.136)
The right-most term in (6.136) is an expression of the cdf of X. Recall the
definition of the cdf in terms of the pdf
P(X⩽U−1(y)) =ZU−1(y)
af(x)dx . (6.137)
Now we have an expression of the cdf of Yin terms of x:
FY(y) =ZU−1(y)
af(x)dx . (6.138)
To obtain the pdf, we differentiate (6.138) with respect to y:
f(y) =d
dyFy(y) =d
dyZU−1(y)
af(x)dx . (6.139)
Note that the integral on the right-hand side is with respect to x, but we
need an integral with respect to ybecause we are differentiating with
respect to y. In particular, we use (6.133) to get the substitution
Z
f(U−1(y))U−1′(y)dy=Z
f(x)dxwhere x=U−1(y).(6.140)
Using (6.140) on the right-hand side of (6.139) gives us
f(y) =d
dyZU−1(y)
afx(U−1(y))U−1′(y)dy . (6.141)
We then recall that differentiation is a linear operator and we use the
subscript xto remind ourselves that fx(U−1(y))is a function of xand not
y. Invoking the fundamental theorem of calculus again gives us
f(y) =fx(U−1(y))·d
dyU−1(y)
. (6.142)
Recall that we assumed that Uis a strictly increasing function. For decreas-
ing functions, it turns out that we have a negative sign when we follow
the same derivation. We introduce the absolute value of the differential to
have the same expression for both increasing and decreasing U:
f(y) =fx(U−1(y))·d
dyU−1(y). (6.143)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
6.7 Change of Variables/Inverse Transform 219
This is called the change-of-variable technique . The termd
dyU−1(y)in change-of-variable
technique(6.143) measures how much a unit volume changes when applying U
(see also the definition of the Jacobian in Section 5.3).
Remark. In comparison to the discrete case in (6.125b), we have an addi-
tional factord
dyU−1(y). The continuous case requires more care because
P(Y=y) = 0 for all y. The probability density function f(y)does not
have a description as a probability of an event involving y. ♢
So far in this section, we have been studying univariate change of vari-
ables. The case for multivariate random variables is analogous, but com-
plicated by fact that the absolute value cannot be used for multivariate
functions. Instead, we use the determinant of the Jacobian matrix. Recall
from (5.58) that the Jacobian is a matrix of partial derivatives, and that
the existence of a nonzero determinant shows that we can invert the Ja-
cobian. Recall the discussion in Section 4.1 that the determinant arises
because our differentials (cubes of volume) are transformed into paral-
lelepipeds by the Jacobian. Let us summarize preceding the discussion in
the following theorem, which gives us a recipe for multivariate change of
variables.
Theorem 6.16. [Theorem 17.2 in Billingsley (1995)] Let f(x)be the value
of the probability density of the multivariate continuous random variable X.
If the vector-valued function y=U(x)is differentiable and invertible for
all values within the domain of x, then for corresponding values of y, the
probability density of Y=U(X)is given by
f(y) =fx(U−1(y))·det∂
∂yU−1(y). (6.144)
The theorem looks intimidating at first glance, but the key point is that
a change of variable of a multivariate random variable follows the pro-
cedure of the univariate change of variable. First we need to work out
the inverse transform, and substitute that into the density of x. Then we
calculate the determinant of the Jacobian and multiply the result. The
following example illustrates the case of a bivariate random variable.
Example 6.17
Consider a bivariate random variable Xwith states x=x1
x2
and proba-
bility density function
fx1
x2
=1
2πexp 
−1
2x1
x2⊤x1
x2!
. (6.145)
We use the change-of-variable technique from Theorem 6.16 to derive the
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
220 Probability and Distributions
effect of a linear transformation (Section 2.7) of the random variable.
Consider a matrix A∈R2×2defined as
A=a b
c d
. (6.146)
We are interested in finding the probability density function of the trans-
formed bivariate random variable Ywith states y=Ax.
Recall that for change of variables we require the inverse transformation
ofxas a function of y. Since we consider linear transformations, the
inverse transformation is given by the matrix inverse (see Section 2.2.2).
For2×2matrices, we can explicitly write out the formula, given by
x1
x2
=A−1y1
y2
=1
ad−bcd−b
−c ay1
y2
. (6.147)
Observe that ad−bcis the determinant (Section 4.1) of A. The corre-
sponding probability density function is given by
f(x) =f(A−1y) =1
2πexp
−1
2y⊤A−⊤A−1y
. (6.148)
The partial derivative of a matrix times a vector with respect to the vector
is the matrix itself (Section 5.5), and therefore
∂
∂yA−1y=A−1. (6.149)
Recall from Section 4.1 that the determinant of the inverse is the inverse
of the determinant so that the determinant of the Jacobian matrix is
det∂
∂yA−1y
=1
ad−bc. (6.150)
We are now able to apply the change-of-variable formula from Theo-
rem 6.16 by multiplying (6.148) with (6.150), which yields
f(y) =f(x)det∂
∂yA−1y(6.151a)
=1
2πexp
−1
2y⊤A−⊤A−1y
|ad−bc|−1. (6.151b)
While Example 6.17 is based on a bivariate random variable, which al-
lows us to easily compute the matrix inverse, the preceding relation holds
for higher dimensions.
Remark. We saw in Section 6.5 that the density f(x)in (6.148) is actually
the standard Gaussian distribution, and the transformed density f(y)is a
bivariate Gaussian with covariance Σ=AA⊤. ♢
We will use the ideas in this chapter to describe probabilistic modeling
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
6.8 Further Reading 221
in Section 8.4, as well as introduce a graphical language in Section 8.5. We
will see direct machine learning applications of these ideas in Chapters 9
and 11.
6.8 Further Reading
This chapter is rather terse at times. Grinstead and Snell (1997) and
Walpole et al. (2011) provide more relaxed presentations that are suit-
able for self-study. Readers interested in more philosophical aspects of
probability should consider Hacking (2001), whereas an approach that
is more related to software engineering is presented by Downey (2014).
An overview of exponential families can be found in Barndorff-Nielsen
(2014). We will see more about how to use probability distributions to
model machine learning tasks in Chapter 8. Ironically, the recent surge
in interest in neural networks has resulted in a broader appreciation of
probabilistic models. For example, the idea of normalizing flows (Jimenez
Rezende and Mohamed, 2015) relies on change of variables for transform-
ing random variables. An overview of methods for variational inference as
applied to neural networks is described in chapters 16 to 20 of the book
by Goodfellow et al. (2016).
We side stepped a large part of the difficulty in continuous random vari-
ables by avoiding measure theoretic questions (Billingsley, 1995; Pollard,
2002), and by assuming without construction that we have real numbers,
and ways of defining sets on real numbers as well as their appropriate fre-
quency of occurrence. These details do matter, for example, in the specifi-
cation of conditional probability p(y|x)for continuous random variables
x, y(Proschan and Presnell, 1998). The lazy notation hides the fact that
we want to specify that X=x(which is a set of measure zero). Fur-
thermore, we are interested in the probability density function of y. A
more precise notation would have to say Ey[f(y)|σ(x)], where we take
the expectation over yof a test function fconditioned on the σ-algebra of
x. A more technical audience interested in the details of probability the-
ory have many options (Jaynes, 2003; MacKay, 2003; Jacod and Protter,
2004; Grimmett and Welsh, 2014), including some very technical discus-
sions (Shiryayev, 1984; Lehmann and Casella, 1998; Dudley, 2002; Bickel
and Doksum, 2006; C ¸inlar, 2011). An alternative way to approach proba-
bility is to start with the concept of expectation, and “work backward” to
derive the necessary properties of a probability space (Whittle, 2000). As
machine learning allows us to model more intricate distributions on ever
more complex types of data, a developer of probabilistic machine learn-
ing models would have to understand these more technical aspects. Ma-
chine learning texts with a probabilistic modeling focus include the books
by MacKay (2003); Bishop (2006); Rasmussen and Williams (2006); Bar-
ber (2012); Murphy (2012).
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
222 Probability and Distributions
Exercises
6.1 Consider the following bivariate distribution p(x, y)of two discrete random
variables XandY.
Xx1x2x3x4x5Y
y3y2y10.01 0.02 0.03 0.1 0.1
0.05 0.1 0.05 0.07 0.2
0.1 0.05 0.03 0.05 0.04
Compute:
a. The marginal distributions p(x)andp(y).
b. The conditional distributions p(x|Y=y1)andp(y|X=x3).
6.2 Consider a mixture of two Gaussian distributions (illustrated in Figure 6.4),
0.4N
10
2
,
1 0
0 1
+ 0.6N
0
0
,
8.4 2.0
2.0 1.7
.
a. Compute the marginal distributions for each dimension.
b. Compute the mean, mode and median for each marginal distribution.
c. Compute the mean and mode for the two-dimensional distribution.
6.3 You have written a computer program that sometimes compiles and some-
times not (code does not change). You decide to model the apparent stochas-
ticity (success vs. no success) xof the compiler using a Bernoulli distribution
with parameter µ:
p(x|µ) =µx(1−µ)1−x, x∈ {0,1}.
Choose a conjugate prior for the Bernoulli likelihood and compute the pos-
terior distribution p(µ|x1, . . . , x N).
6.4 There are two bags. The first bag contains four mangos and two apples; the
second bag contains four mangos and four apples.
We also have a biased coin, which shows “heads” with probability 0.6 and
“tails” with probability 0.4. If the coin shows “heads”. we pick a fruit at
random from bag 1; otherwise we pick a fruit at random from bag 2.
Your friend flips the coin (you cannot see the result), picks a fruit at random
from the corresponding bag, and presents you a mango.
What is the probability that the mango was picked from bag 2?
Hint: Use Bayes’ theorem.
6.5 Consider the time-series model
xt+1=Axt+w,w∼ N 
0,Q
yt=Cxt+v,v∼ N 
0,R
,
where w,vare i.i.d. Gaussian noise variables. Further, assume that p(x0) =
N 
µ0,Σ0.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
Exercises 223
a. What is the form of p(x0,x1, . . . ,xT)? Justify your answer (you do not
have to explicitly compute the joint distribution).
b. Assume that p(xt|y1, . . . ,yt) =N 
µt,Σt.
1. Compute p(xt+1|y1, . . . ,yt).
2. Compute p(xt+1,yt+1|y1, . . . ,yt).
3. At time t+1, we observe the value yt+1=ˆy. Compute the conditional
distribution p(xt+1|y1, . . . ,yt+1).
6.6 Prove the relationship in (6.44), which relates the standard definition of the
variance to the raw-score expression for the variance.
6.7 Prove the relationship in (6.45), which relates the pairwise difference be-
tween examples in a dataset with the raw-score expression for the variance.
6.8 Express the Bernoulli distribution in the natural parameter form of the ex-
ponential family, see (6.107).
6.9 Express the Binomial distribution as an exponential family distribution. Also
express the Beta distribution is an exponential family distribution. Show that
the product of the Beta and the Binomial distribution is also a member of
the exponential family.
6.10 Derive the relationship in Section 6.5.2 in two ways:
a. By completing the square
b. By expressing the Gaussian in its exponential family form
Theproduct of two Gaussians N 
x|a,A
N 
x|b,Bis an unnormalized
Gaussian distribution cN 
x|c,Cwith
C= (A−1+B−1)−1
c=C(A−1a+B−1b)
c= (2π)−D
2|A+B|−1
2exp 
−1
2(a−b)⊤(A+B)−1(a−b)
.
Note that the normalizing constant citself can be considered a (normalized)
Gaussian distribution either in aor inbwith an “inflated” covariance matrix
A+B, i.e., c=N 
a|b,A+B
=N 
b|a,A+B.
6.11 Iterated Expectations.
Consider two random variables x,ywith joint distribution p(x, y). Show that
EX[x] =EYEX[x|y]
.
Here,EX[x|y]denotes the expected value of xunder the conditional distri-
bution p(x|y).
6.12 Manipulation of Gaussian Random Variables.
Consider a Gaussian random variable x∼ N 
x|µx,Σx, where x∈RD.
Furthermore, we have
y=Ax+b+w,
where y∈RE,A∈RE×D,b∈RE, and w∼ N 
w|0,Qis indepen-
dent Gaussian noise. “Independent” implies that xandware independent
random variables and that Qis diagonal.
a. Write down the likelihood p(y|x).
b. The distribution p(y) =R
p(y|x)p(x)dxis Gaussian. Compute the mean
µyand the covariance Σy. Derive your result in detail.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
224 Probability and Distributions
c. The random variable yis being transformed according to the measure-
ment mapping
z=Cy+v,
where z∈RF,C∈RF×E, and v∼ N 
v|0,Ris independent Gaus-
sian (measurement) noise.
Write down p(z|y).
Compute p(z), i.e., the mean µzand the covariance Σz. Derive your
result in detail.
d. Now, a value ˆyis measured. Compute the posterior distribution p(x|ˆy).
Hint for solution: This posterior is also Gaussian, i.e., we need to de-
termine only its mean and covariance matrix. Start by explicitly com-
puting the joint Gaussian p(x,y). This also requires us to compute the
cross-covariances Covx,y[x,y]and Covy,x[y,x]. Then apply the rules
for Gaussian conditioning.
6.13 Probability Integral Transformation
Given a continuous random variable X, with cdf FX(x), show that the ran-
dom variable Y:=FX(X)is uniformly distributed (Theorem 6.15).
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
7
Continuous Optimization
Since machine learning algorithms are implemented on a computer, the
mathematical formulations are expressed as numerical optimization meth-
ods. This chapter describes the basic numerical methods for training ma-
chine learning models. Training a machine learning model often boils
down to finding a good set of parameters. The notion of “good” is de-
termined by the objective function or the probabilistic model, which we
will see examples of in the second part of this book. Given an objective
function, finding the best value is done using optimization algorithms. Since we consider
data and models in
RD, the
optimization
problems we face
arecontinuous
optimization
problems, as
opposed to
combinatorial
optimization
problems for
discrete variables.This chapter covers two main branches of continuous optimization (Fig-
ure 7.1): unconstrained and constrained optimization. We will assume in
this chapter that our objective function is differentiable (see Chapter 5),
hence we have access to a gradient at each location in the space to help us
find the optimum value. By convention, most objective functions in ma-
chine learning are intended to be minimized, that is, the best value is the
minimum value. Intuitively finding the best value is like finding the val-
leys of the objective function, and the gradients point us uphill. The idea is
to move downhill (opposite to the gradient) and hope to find the deepest
point. For unconstrained optimization, this is the only concept we need,
but there are several design choices, which we discuss in Section 7.1. For
constrained optimization, we need to introduce other concepts to man-
age the constraints (Section 7.2). We will also introduce a special class
of problems (convex optimization problems in Section 7.3) where we can
make statements about reaching the global optimum.
Consider the function in Figure 7.2. The function has a global minimum global minimum
around x=−4.5, with a function value of approximately −47. Since
the function is “smooth,” the gradients can be used to help find the min-
imum by indicating whether we should take a step to the right or left.
This assumes that we are in the correct bowl, as there exists another local local minimum
minimum around x= 0.7. Recall that we can solve for all the stationary
points of a function by calculating its derivative and setting it to zero. For Stationary points
are the real roots of
the derivative, that
is, points that have
zero gradient.ℓ(x) =x4+ 7x3+ 5x2−17x+ 3, (7.1)
we obtain the corresponding gradient as
dℓ(x)
dx= 4x3+ 21x2+ 10x−17. (7.2)
225
This material is published by Cambridge University Press as Mathematics for Machine Learning by
Marc Peter Deisenroth, A. Aldo Faisal, and Cheng Soon Ong (2020). This version is free to view
and download for personal use only. Not for re-distribution, re-sale, or use in derivative works.
©by M. P. Deisenroth, A. A. Faisal, and C. S. Ong, 2024. https://mml-book.com .
226 Continuous Optimization
Figure 7.1 A mind
map of the concepts
related to
optimization, as
presented in this
chapter. There are
two main ideas:
gradient descent
and convex
optimization.Continuous
optimization
Unconstrained
optimization
Constrained
optimizationGradient descentStepsize
Momentum
Stochastic
gradient
descent
Lagrange
multipliers
Convex optimization
& dualityConvex
Convex conjugateLinear
programming
Quadratic
programmingChapter 10
Dimension reduc.
Chapter 11
Density estimation
Chapter 12
Classification
Since this is a cubic equation, it has in general three solutions when set to
zero. In the example, two of them are minimums and one is a maximum
(around x=−1.4). To check whether a stationary point is a minimum
or maximum, we need to take the derivative a second time and check
whether the second derivative is positive or negative at the stationary
point. In our case, the second derivative is
d2ℓ(x)
dx2= 12x2+ 42x+ 10. (7.3)
By substituting our visually estimated values of x=−4.5,−1.4,0.7,we
will observe that as expected the middle point is a maximum
d2ℓ(x)
dx2<0
and the other two stationary points are minimums.
Note that we have avoided analytically solving for values of xin the
previous discussion, although for low-order polynomials such as the pre-
ceding we could do so. In general, we are unable to find analytic solu-
tions, and hence we need to start at some value, say x0=−6, and follow
the negative gradient. The negative gradient indicates that we should go
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
7.1 Optimization Using Gradient Descent 227
Figure 7.2 Example
objective function.
Negative gradients
are indicated by
arrows, and the
global minimum is
indicated by the
dashed blue line.
−6−5−4−3−2−1 0 1 2
Value of parameter−60−40−200204060Objectivex4+ 7x3+ 5x2−17x+ 3
right, but not how far (this is called the step-size). Furthermore, if we According to the
Abel–Ruffini
theorem, there is in
general no algebraic
solution for
polynomials of
degree 5 or more
(Abel, 1826).had started at the right side (e.g., x0= 0) the negative gradient would
have led us to the wrong minimum. Figure 7.2 illustrates the fact that for
x >−1, the negative gradient points toward the minimum on the right of
the figure, which has a larger objective value.
In Section 7.3, we will learn about a class of functions, called convex
functions, that do not exhibit this tricky dependency on the starting point
of the optimization algorithm. For convex functions, all local minimums
are global minimum. It turns out that many machine learning objective For convex functions
all local minima are
global minimum.functions are designed such that they are convex, and we will see an ex-
ample in Chapter 12.
The discussion in this chapter so far was about a one-dimensional func-
tion, where we are able to visualize the ideas of gradients, descent direc-
tions, and optimal values. In the rest of this chapter we develop the same
ideas in high dimensions. Unfortunately, we can only visualize the con-
cepts in one dimension, but some concepts do not generalize directly to
higher dimensions, therefore some care needs to be taken when reading.
7.1 Optimization Using Gradient Descent
We now consider the problem of solving for the minimum of a real-valued
function
min
xf(x), (7.4)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
228 Continuous Optimization
where f:Rd→Ris an objective function that captures the machine
learning problem at hand. We assume that our function fis differentiable,
and we are unable to analytically find a solution in closed form.
Gradient descent is a first-order optimization algorithm. To find a local
minimum of a function using gradient descent, one takes steps propor-
tional to the negative of the gradient of the function at the current point.
Recall from Section 5.1 that the gradient points in the direction of the We use the
convention of row
vectors for
gradients.steepest ascent. Another useful intuition is to consider the set of lines
where the function is at a certain value ( f(x) =cfor some value c∈R),
which are known as the contour lines. The gradient points in a direction
that is orthogonal to the contour lines of the function we wish to optimize.
Let us consider multivariate functions. Imagine a surface (described by
the function f(x)) with a ball starting at a particular location x0. When
the ball is released, it will move downhill in the direction of steepest de-
scent. Gradient descent exploits the fact that f(x0)decreases fastest if one
moves from x0in the direction of the negative gradient −((∇f)(x0))⊤of
fatx0. We assume in this book that the functions are differentiable, and
refer the reader to more general settings in Section 7.4. Then, if
x1=x0−γ((∇f)(x0))⊤(7.5)
for a small step-size γ⩾0, then f(x1)⩽f(x0). Note that we use the
transpose for the gradient since otherwise the dimensions will not work
out.
This observation allows us to define a simple gradient descent algo-
rithm: If we want to find a local optimum f(x∗)of a function f:Rn→
R,x7→f(x), we start with an initial guess x0of the parameters we wish
to optimize and then iterate according to
xi+1=xi−γi((∇f)(xi))⊤. (7.6)
For suitable step-size γi, the sequence f(x0)⩾f(x1)⩾. . .converges to
a local minimum.
Example 7.1
Consider a quadratic function in two dimensions
fx1
x2
=1
2x1
x2⊤2 1
1 20x1
x2
−5
3⊤x1
x2
(7.7)
with gradient
∇fx1
x2
=x1
x2⊤2 1
1 20
−5
3⊤
. (7.8)
Starting at the initial location x0= [−3,−1]⊤, we iteratively apply (7.6)
to obtain a sequence of estimates that converge to the minimum value
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
7.1 Optimization Using Gradient Descent 229
Figure 7.3 Gradient
descent on a
two-dimensional
quadratic surface
(shown as a
heatmap). See
Example 7.1 for a
description.
 4 2 0 2 4
x1 2 1012x20.0
10.0
20.030.0
40.040.0
50.050.0
60.0 70.0
80.0 150153045607590
(illustrated in Figure 7.3). We can see (both from the figure and by plug-
gingx0into (7.8) with γ= 0.085) that the negative gradient at x0points
north and east, leading to x1= [−1.98,1.21]⊤. Repeating that argument
gives us x2= [−1.32,−0.42]⊤, and so on.
Remark. Gradient descent can be relatively slow close to the minimum:
Its asymptotic rate of convergence is inferior to many other methods. Us-
ing the ball rolling down the hill analogy, when the surface is a long, thin
valley, the problem is poorly conditioned (Trefethen and Bau III, 1997).
For poorly conditioned convex problems, gradient descent increasingly
“zigzags” as the gradients point nearly orthogonally to the shortest di-
rection to a minimum point; see Figure 7.3. ♢
7.1.1 Step-size
As mentioned earlier, choosing a good step-size is important in gradient
descent. If the step-size is too small, gradient descent can be slow. If the The step-size is also
called the learning
rate.step-size is chosen too large, gradient descent can overshoot, fail to con-
verge, or even diverge. We will discuss the use of momentum in the next
section. It is a method that smoothes out erratic behavior of gradient up-
dates and dampens oscillations.
Adaptive gradient methods rescale the step-size at each iteration, de-
pending on local properties of the function. There are two simple heuris-
tics (Toussaint, 2012):
When the function value increases after a gradient step, the step-size
was too large. Undo the step and decrease the step-size.
When the function value decreases the step could have been larger. Try
to increase the step-size.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
230 Continuous Optimization
Although the “undo” step seems to be a waste of resources, using this
heuristic guarantees monotonic convergence.
Example 7.2 (Solving a Linear Equation System)
When we solve linear equations of the form Ax=b, in practice we solve
Ax−b=0approximately by finding x∗that minimizes the squared error
∥Ax−b∥2= (Ax−b)⊤(Ax−b) (7.9)
if we use the Euclidean norm. The gradient of (7.9) with respect to xis
∇x= 2(Ax−b)⊤A. (7.10)
We can use this gradient directly in a gradient descent algorithm. How-
ever, for this particular special case, it turns out that there is an analytic
solution, which can be found by setting the gradient to zero. We will see
more on solving squared error problems in Chapter 9.
Remark. When applied to the solution of linear systems of equations Ax=
b, gradient descent may converge slowly. The speed of convergence of gra-
dient descent is dependent on the condition number κ=σ(A)max
σ(A)min, which condition number
is the ratio of the maximum to the minimum singular value (Section 4.5)
ofA. The condition number essentially measures the ratio of the most
curved direction versus the least curved direction, which corresponds to
our imagery that poorly conditioned problems are long, thin valleys: They
are very curved in one direction, but very flat in the other. Instead of di-
rectly solving Ax=b, one could instead solve P−1(Ax−b) =0, where
Pis called the preconditioner . The goal is to design P−1such that P−1A preconditioner
has a better condition number, but at the same time P−1is easy to com-
pute. For further information on gradient descent, preconditioning, and
convergence we refer to Boyd and Vandenberghe (2004, chapter 9). ♢
7.1.2 Gradient Descent With Momentum
As illustrated in Figure 7.3, the convergence of gradient descent may be
very slow if the curvature of the optimization surface is such that there
are regions that are poorly scaled. The curvature is such that the gradient
descent steps hops between the walls of the valley and approaches the
optimum in small steps. The proposed tweak to improve convergence is
to give gradient descent some memory. Goh (2017) wrote
an intuitive blog
post on gradient
descent with
momentum.Gradient descent with momentum (Rumelhart et al., 1986) is a method
that introduces an additional term to remember what happened in the
previous iteration. This memory dampens oscillations and smoothes out
the gradient updates. Continuing the ball analogy, the momentum term
emulates the phenomenon of a heavy ball that is reluctant to change di-
rections. The idea is to have a gradient update with memory to implement
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
7.1 Optimization Using Gradient Descent 231
a moving average. The momentum-based method remembers the update
∆xiat each iteration iand determines the next update as a linear combi-
nation of the current and previous gradients
xi+1=xi−γi((∇f)(xi))⊤+α∆xi (7.11)
∆xi=xi−xi−1=α∆xi−1−γi−1((∇f)(xi−1))⊤, (7.12)
where α∈[0,1]. Sometimes we will only know the gradient approxi-
mately. In such cases, the momentum term is useful since it averages out
different noisy estimates of the gradient. One particularly useful way to
obtain an approximate gradient is by using a stochastic approximation,
which we discuss next.
7.1.3 Stochastic Gradient Descent
Computing the gradient can be very time consuming. However, often it is
possible to find a “cheap” approximation of the gradient. Approximating
the gradient is still useful as long as it points in roughly the same direction
as the true gradient. stochastic gradient
descent Stochastic gradient descent (often shortened as SGD) is a stochastic ap-
proximation of the gradient descent method for minimizing an objective
function that is written as a sum of differentiable functions. The word
stochastic here refers to the fact that we acknowledge that we do not
know the gradient precisely, but instead only know a noisy approxima-
tion to it. By constraining the probability distribution of the approximate
gradients, we can still theoretically guarantee that SGD will converge.
In machine learning, given n= 1, . . . , N data points, we often consider
objective functions that are the sum of the losses Lnincurred by each
example n. In mathematical notation, we have the form
L(θ) =NX
n=1Ln(θ), (7.13)
where θis the vector of parameters of interest, i.e., we want to find θthat
minimizes L. An example from regression (Chapter 9) is the negative log-
likelihood, which is expressed as a sum over log-likelihoods of individual
examples so that
L(θ) =−NX
n=1logp(yn|xn,θ), (7.14)
where xn∈RDare the training inputs, ynare the training targets, and θ
are the parameters of the regression model.
Standard gradient descent, as introduced previously, is a “batch” opti-
mization method, i.e., optimization is performed using the full training set
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
232 Continuous Optimization
by updating the vector of parameters according to
θi+1=θi−γi(∇L(θi))⊤=θi−γiNX
n=1(∇Ln(θi))⊤(7.15)
for a suitable step-size parameter γi. Evaluating the sum gradient may re-
quire expensive evaluations of the gradients from all individual functions
Ln. When the training set is enormous and/or no simple formulas exist,
evaluating the sums of gradients becomes very expensive.
Consider the termPN
n=1(∇Ln(θi))in (7.15). We can reduce the amount
of computation by taking a sum over a smaller set of Ln. In contrast to
batch gradient descent, which uses all Lnforn= 1, . . . , N , we randomly
choose a subset of Lnfor mini-batch gradient descent. In the extreme
case, we randomly select only a single Lnto estimate the gradient. The
key insight about why taking a subset of data is sensible is to realize that
for gradient descent to converge, we only require that the gradient is an
unbiased estimate of the true gradient. In fact the termPN
n=1(∇Ln(θi))
in (7.15) is an empirical estimate of the expected value (Section 6.4.1) of
the gradient. Therefore, any other unbiased empirical estimate of the ex-
pected value, for example using any subsample of the data, would suffice
for convergence of gradient descent.
Remark. When the learning rate decreases at an appropriate rate, and sub-
ject to relatively mild assumptions, stochastic gradient descent converges
almost surely to local minimum (Bottou, 1998). ♢
Why should one consider using an approximate gradient? A major rea-
son is practical implementation constraints, such as the size of central
processing unit (CPU)/graphics processing unit (GPU) memory or limits
on computational time. We can think of the size of the subset used to esti-
mate the gradient in the same way that we thought of the size of a sample
when estimating empirical means (Section 6.4.1). Large mini-batch sizes
will provide accurate estimates of the gradient, reducing the variance in
the parameter update. Furthermore, large mini-batches take advantage of
highly optimized matrix operations in vectorized implementations of the
cost and gradient. The reduction in variance leads to more stable conver-
gence, but each gradient calculation will be more expensive.
In contrast, small mini-batches are quick to estimate. If we keep the
mini-batch size small, the noise in our gradient estimate will allow us to
get out of some bad local optima, which we may otherwise get stuck in.
In machine learning, optimization methods are used for training by min-
imizing an objective function on the training data, but the overall goal
is to improve generalization performance (Chapter 8). Since the goal in
machine learning does not necessarily need a precise estimate of the min-
imum of the objective function, approximate gradients using mini-batch
approaches have been widely used. Stochastic gradient descent is very
effective in large-scale machine learning problems (Bottou et al., 2018),
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
7.2 Constrained Optimization and Lagrange Multipliers 233
Figure 7.4
Illustration of
constrained
optimization. The
unconstrained
problem (indicated
by the contour
lines) has a
minimum on the
right side (indicated
by the circle). The
box constraints
(−1⩽x⩽1and
−1⩽y⩽1) require
that the optimal
solution is within
the box, resulting in
an optimal value
indicated by the
star.
−3−2−1 0 1 2 3
x1−3−2−10123x2
such as training deep neural networks on millions of images (Dean et al.,
2012), topic models (Hoffman et al., 2013), reinforcement learning (Mnih
et al., 2015), or training of large-scale Gaussian process models (Hensman
et al., 2013; Gal et al., 2014).
7.2 Constrained Optimization and Lagrange Multipliers
In the previous section, we considered the problem of solving for the min-
imum of a function
min
xf(x), (7.16)
where f:RD→R.
In this section, we have additional constraints. That is, for real-valued
functions gi:RD→Rfori= 1, . . . , m , we consider the constrained
optimization problem (see Figure 7.4 for an illustration)
min
xf(x) (7.17)
subject to gi(x)⩽0for all i= 1, . . . , m .
It is worth pointing out that the functions fandgicould be non-convex
in general, and we will consider the convex case in the next section.
One obvious, but not very practical, way of converting the constrained
problem (7.17) into an unconstrained one is to use an indicator function
J(x) =f(x) +mX
i=11(gi(x)), (7.18)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
234 Continuous Optimization
where 1(z)is an infinite step function
1(z) =(
0ifz⩽0
∞otherwise. (7.19)
This gives infinite penalty if the constraint is not satisfied, and hence
would provide the same solution. However, this infinite step function is
equally difficult to optimize. We can overcome this difficulty by introduc-
ingLagrange multipliers . The idea of Lagrange multipliers is to replace the Lagrange multiplier
step function with a linear function.
We associate to problem (7.17) the Lagrangian by introducing the La- Lagrangian
grange multipliers λi⩾0corresponding to each inequality constraint re-
spectively (Boyd and Vandenberghe, 2004, chapter 4) so that
L(x,λ) =f(x) +mX
i=1λigi(x) (7.20a)
=f(x) +λ⊤g(x), (7.20b)
where in the last line we have concatenated all constraints gi(x)into a
vector g(x), and all the Lagrange multipliers into a vector λ∈Rm.
We now introduce the idea of Lagrangian duality. In general, duality
in optimization is the idea of converting an optimization problem in one
set of variables x(called the primal variables), into another optimization
problem in a different set of variables λ(called the dual variables). We
introduce two different approaches to duality: In this section, we discuss
Lagrangian duality; in Section 7.3.3, we discuss Legendre-Fenchel duality.
Definition 7.1. The problem in (7.17)
min
xf(x) (7.21)
subject to gi(x)⩽0for all i= 1, . . . , m
is known as the primal problem , corresponding to the primal variables x. primal problem
The associated Lagrangian dual problem is given by Lagrangian dual
problem
max
λ∈RmD(λ)
subject to λ⩾0,(7.22)
where λare the dual variables and D(λ) = min x∈RdL(x,λ).
Remark. In the discussion of Definition 7.1, we use two concepts that are
also of independent interest (Boyd and Vandenberghe, 2004).
First is the minimax inequality , which says that for any function with minimax inequality
two arguments φ(x,y), the maximin is less than the minimax, i.e.,
max
ymin
xφ(x,y)⩽min
xmax
yφ(x,y). (7.23)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
7.2 Constrained Optimization and Lagrange Multipliers 235
This inequality can be proved by considering the inequality
For all x,y min
xφ(x,y)⩽max
yφ(x,y). (7.24)
Note that taking the maximum over yof the left-hand side of (7.24) main-
tains the inequality since the inequality is true for all y. Similarly, we can
take the minimum over xof the right-hand side of (7.24) to obtain (7.23).
The second concept is weak duality , which uses (7.23) to show that weak duality
primal values are always greater than or equal to dual values. This is de-
scribed in more detail in (7.27). ♢
Recall that the difference between J(x)in (7.18) and the Lagrangian
in (7.20b) is that we have relaxed the indicator function to a linear func-
tion. Therefore, when λ⩾0, the Lagrangian L(x,λ)is a lower bound of
J(x). Hence, the maximum of L(x,λ)with respect to λis
J(x) = max
λ⩾0L(x,λ). (7.25)
Recall that the original problem was minimizing J(x),
min
x∈Rdmax
λ⩾0L(x,λ). (7.26)
By the minimax inequality (7.23), it follows that swapping the order of
the minimum and maximum results in a smaller value, i.e.,
min
x∈Rdmax
λ⩾0L(x,λ)⩾max
λ⩾0min
x∈RdL(x,λ). (7.27)
This is also known as weak duality . Note that the inner part of the right- weak duality
hand side is the dual objective function D(λ)and the definition follows.
In contrast to the original optimization problem, which has constraints,
minx∈RdL(x,λ)is an unconstrained optimization problem for a given
value of λ. If solving minx∈RdL(x,λ)is easy, then the overall problem is
easy to solve. We can see this by observing from (7.20b) that L(x,λ)is
affine with respect to λ. Therefore minx∈RdL(x,λ)is a pointwise min-
imum of affine functions of λ, and hence D(λ)is concave even though
f(·)andgi(·)may be nonconvex. The outer problem, maximization over
λ, is the maximum of a concave function and can be efficiently computed.
Assuming f(·)andgi(·)are differentiable, we find the Lagrange dual
problem by differentiating the Lagrangian with respect to x, setting the
differential to zero, and solving for the optimal value. We will discuss two
concrete examples in Sections 7.3.1 and 7.3.2, where f(·)andgi(·)are
convex.
Remark (Equality Constraints) .Consider (7.17) with additional equality
constraints
min
xf(x)
subject to gi(x)⩽0for all i= 1, . . . , m
hj(x) = 0 for all j= 1, . . . , n .(7.28)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
236 Continuous Optimization
We can model equality constraints by replacing them with two inequality
constraints. That is for each equality constraint hj(x) = 0 we equivalently
replace it by two constraints hj(x)⩽0andhj(x)⩾0. It turns out that
the resulting Lagrange multipliers are then unconstrained.
Therefore, we constrain the Lagrange multipliers corresponding to the
inequality constraints in (7.28) to be non-negative, and leave the La-
grange multipliers corresponding to the equality constraints unconstrained.
♢
7.3 Convex Optimization
We focus our attention of a particularly useful class of optimization prob-
lems, where we can guarantee global optimality. When f(·)is a convex
function, and when the constraints involving g(·)andh(·)are convex sets,
this is called a convex optimization problem . In this setting, we have strong convex optimization
problem
strong dualityduality : The optimal solution of the dual problem is the same as the opti-
mal solution of the primal problem. The distinction between convex func-
tions and convex sets are often not strictly presented in machine learning
literature, but one can often infer the implied meaning from context.
Definition 7.2. A setCis aconvex set if for any x, y∈ Cand for any scalar convex set
θwith0⩽θ⩽1, we have
θx+ (1−θ)y∈ C. (7.29)
Figure 7.5 Example
of a convex set.
 Convex sets are sets such that a straight line connecting any two ele-
ments of the set lie inside the set. Figures 7.5 and 7.6 illustrate convex
and nonconvex sets, respectively.
Figure 7.6 Example
of a nonconvex set.
Convex functions are functions such that a straight line between any
two points of the function lie above the function. Figure 7.2 shows a non-
convex function, and Figure 7.3 shows a convex function. Another convex
function is shown in Figure 7.7.
Definition 7.3. Let function f:RD→Rbe a function whose domain is a
convex set. The function fis aconvex function if for all x,yin the domain
convex functionoff, and for any scalar θwith0⩽θ⩽1, we have
f(θx+ (1−θ)y)⩽θf(x) + (1 −θ)f(y). (7.30)
Remark. Aconcave function is the negative of a convex function. ♢
concave functionThe constraints involving g(·)andh(·)in (7.28) truncate functions at a
scalar value, resulting in sets. Another relation between convex functions
and convex sets is to consider the set obtained by “filling in” a convex
function. A convex function is a bowl-like object, and we imagine pouring
water into it to fill it up. This resulting filled-in set, called the epigraph of epigraph
the convex function, is a convex set.
If a function f:Rn→Ris differentiable, we can specify convexity in
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
7.3 Convex Optimization 237
Figure 7.7 Example
of a convex
function.
−3−2−1 0 1 2 3
x010203040yy= 3x2−5x+ 2
terms of its gradient ∇xf(x)(Section 5.2). A function f(x)is convex if
and only if for any two points x,yit holds that
f(y)⩾f(x) +∇xf(x)⊤(y−x). (7.31)
If we further know that a function f(x)is twice differentiable, that is, the
Hessian (5.147) exists for all values in the domain of x, then the function
f(x)is convex if and only if ∇2
xf(x)is positive semidefinite (Boyd and
Vandenberghe, 2004).
Example 7.3
The negative entropy f(x) =xlog2xis convex for x >0. A visualization
of the function is shown in Figure 7.8, and we can see that the function is
convex. To illustrate the previous definitions of convexity, let us check the
calculations for two points x= 2andx= 4. Note that to prove convexity
off(x)we would need to check for all points x∈R.
Recall Definition 7.3. Consider a point midway between the two points
(that is θ= 0.5); then the left-hand side is f(0.5·2 + 0.5·4) = 3 log23≈
4.75. The right-hand side is 0.5(2 log22) + 0 .5(4 log24) = 1 + 4 = 5 . And
therefore the definition is satisfied.
Since f(x)is differentiable, we can alternatively use (7.31). Calculating
the derivative of f(x), we obtain
∇x(xlog2x) = 1·log2x+x·1
xloge2= log2x+1
loge2. (7.32)
Using the same two test points x= 2 andx= 4, the left-hand side of
(7.31) is given by f(4) = 8 . The right-hand side is
f(x) +∇⊤
x(y−x) =f(2) +∇f(2)·(4−2) (7.33a)
= 2 + (1 +1
loge2)·2≈6.9. (7.33b)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
238 Continuous Optimization
Figure 7.8 The
negative entropy
function (which is
convex) and its
tangent at x= 2.
0 1 2 3 4 5
x0510f(x)xlog2x
tangent atx= 2
We can check that a function or set is convex from first principles by
recalling the definitions. In practice, we often rely on operations that pre-
serve convexity to check that a particular function or set is convex. Al-
though the details are vastly different, this is again the idea of closure
that we introduced in Chapter 2 for vector spaces.
Example 7.4
A nonnegative weighted sum of convex functions is convex. Observe that
iffis a convex function, and α⩾0is a nonnegative scalar, then the
function αfis convex. We can see this by multiplying αto both sides of the
equation in Definition 7.3, and recalling that multiplying a nonnegative
number does not change the inequality.
Iff1andf2are convex functions, then we have by the definition
f1(θx+ (1−θ)y)⩽θf1(x) + (1 −θ)f1(y) (7.34)
f2(θx+ (1−θ)y)⩽θf2(x) + (1 −θ)f2(y). (7.35)
Summing up both sides gives us
f1(θx+ (1−θ)y) +f2(θx+ (1−θ)y)
⩽θf1(x) + (1 −θ)f1(y) +θf2(x) + (1 −θ)f2(y), (7.36)
where the right-hand side can be rearranged to
θ(f1(x) +f2(x)) + (1 −θ)(f1(y) +f2(y)), (7.37)
completing the proof that the sum of convex functions is convex.
Combining the preceding two facts, we see that αf1(x) +βf2(x)is
convex for α, β⩾0. This closure property can be extended using a sim-
ilar argument for nonnegative weighted sums of more than two convex
functions.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
7.3 Convex Optimization 239
Remark. The inequality in (7.30) is sometimes called Jensen’s inequality .Jensen’s inequality
In fact, a whole class of inequalities for taking nonnegative weighted sums
of convex functions are all called Jensen’s inequality. ♢
In summary, a constrained optimization problem is called a convex opti- convex optimization
problem mization problem if
min
xf(x)
subject to gi(x)⩽0for all i= 1, . . . , m
hj(x) = 0 for all j= 1, . . . , n ,(7.38)
where all functions f(x)andgi(x)are convex functions, and all hj(x) =
0are convex sets. In the following, we will describe two classes of convex
optimization problems that are widely used and well understood.
7.3.1 Linear Programming
Consider the special case when all the preceding functions are linear, i.e.,
min
x∈Rdc⊤x (7.39)
subject to Ax⩽b,
where A∈Rm×dandb∈Rm. This is known as a linear program . It has d linear program
Linear programs are
one of the most
widely used
approaches in
industry.variables and mlinear constraints. The Lagrangian is given by
L(x,λ) =c⊤x+λ⊤(Ax−b), (7.40)
where λ∈Rmis the vector of non-negative Lagrange multipliers. Rear-
ranging the terms corresponding to xyields
L(x,λ) = (c+A⊤λ)⊤x−λ⊤b. (7.41)
Taking the derivative of L(x,λ)with respect to xand setting it to zero
gives us
c+A⊤λ=0. (7.42)
Therefore, the dual Lagrangian is D(λ) =−λ⊤b. Recall we would like
to maximize D(λ). In addition to the constraint due to the derivative of
L(x,λ)being zero, we also have the fact that λ⩾0, resulting in the
following dual optimization problem It is convention to
minimize the primal
and maximize the
dual.max
λ∈Rm−b⊤λ (7.43)
subject to c+A⊤λ=0
λ⩾0.
This is also a linear program, but with mvariables. We have the choice
of solving the primal (7.39) or the dual (7.43) program depending on
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
240 Continuous Optimization
whether mordis larger. Recall that dis the number of variables and mis
the number of constraints in the primal linear program.
Example 7.5 (Linear Program)
Consider the linear program
min
x∈R2−5
3⊤x1
x2
subject to
2 2
2−4
−2 1
0−1
0 1
x1
x2
⩽
33
8
5
−1
8
(7.44)
with two variables. This program is also shown in Figure 7.9. The objective
function is linear, resulting in linear contour lines. The constraint set in
standard form is translated into the legend. The optimal value must lie in
the shaded (feasible) region, and is indicated by the star.
Figure 7.9
Illustration of a
linear program. The
unconstrained
problem (indicated
by the contour
lines) has a
minimum on the
right side. The
optimal value given
the constraints are
shown by the star.
0 2 4 6 8 10 12 14 16
x10246810x22x2≤33−2x1
4x2≥2x1−8
x2≤2x1−5
x2≥1
x2≤8
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
7.3 Convex Optimization 241
7.3.2 Quadratic Programming
Consider the case of a convex quadratic objective function, where the con-
straints are affine, i.e.,
min
x∈Rd1
2x⊤Qx+c⊤x (7.45)
subject to Ax⩽b,
where A∈Rm×d,b∈Rm, andc∈Rd. The square symmetric matrix Q∈
Rd×dis positive definite, and therefore the objective function is convex.
This is known as a quadratic program . Observe that it has dvariables and
mlinear constraints.
Example 7.6 (Quadratic Program)
Consider the quadratic program
min
x∈R21
2x1
x2⊤2 1
1 4x1
x2
+5
3⊤x1
x2
(7.46)
subject to
1 0
−1 0
0 1
0−1
x1
x2
⩽
1
1
1
1
(7.47)
of two variables. The program is also illustrated in Figure 7.4. The objec-
tive function is quadratic with a positive semidefinite matrix Q, resulting
in elliptical contour lines. The optimal value must lie in the shaded (feasi-
ble) region, and is indicated by the star.
The Lagrangian is given by
L(x,λ) =1
2x⊤Qx+c⊤x+λ⊤(Ax−b) (7.48a)
=1
2x⊤Qx+ (c+A⊤λ)⊤x−λ⊤b, (7.48b)
where again we have rearranged the terms. Taking the derivative of L(x,λ)
with respect to xand setting it to zero gives
Qx+ (c+A⊤λ) =0. (7.49)
SinceQis positive definite and therefore invertible, we get
x=−Q−1(c+A⊤λ). (7.50)
Substituting (7.50) into the primal Lagrangian L(x,λ), we get the dual
Lagrangian
D(λ) =−1
2(c+A⊤λ)⊤Q−1(c+A⊤λ)−λ⊤b. (7.51)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
242 Continuous Optimization
Therefore, the dual optimization problem is given by
max
λ∈Rm−1
2(c+A⊤λ)⊤Q−1(c+A⊤λ)−λ⊤b
subject to λ⩾0.(7.52)
We will see an application of quadratic programming in machine learning
in Chapter 12.
7.3.3 Legendre–Fenchel Transform and Convex Conjugate
Let us revisit the idea of duality from Section 7.2, without considering
constraints. One useful fact about a convex set is that it can be equiva-
lently described by its supporting hyperplanes. A hyperplane is called a
supporting hyperplane of a convex set if it intersects the convex set, and supporting
hyperplane the convex set is contained on just one side of it. Recall that we can fill up
a convex function to obtain the epigraph, which is a convex set. Therefore,
we can also describe convex functions in terms of their supporting hyper-
planes. Furthermore, observe that the supporting hyperplane just touches
the convex function, and is in fact the tangent to the function at that point.
And recall that the tangent of a function f(x)at a given point x0is the
evaluation of the gradient of that function at that pointdf(x)
dx
x=x0. In
summary, because convex sets can be equivalently described by their sup-
porting hyperplanes, convex functions can be equivalently described by a
function of their gradient. The Legendre transform formalizes this concept. Legendre transform
Physics students are
often introduced to
the Legendre
transform as
relating the
Lagrangian and the
Hamiltonian in
classical mechanics.We begin with the most general definition, which unfortunately has a
counter-intuitive form, and look at special cases to relate the definition to
the intuition described in the preceding paragraph. The Legendre-Fenchel
Legendre-Fenchel
transformtransform is a transformation (in the sense of a Fourier transform) from
a convex differentiable function f(x)to a function that depends on the
tangents s(x) =∇xf(x). It is worth stressing that this is a transformation
of the function f(·)and not the variable xor the function evaluated at x.
The Legendre-Fenchel transform is also known as the convex conjugate (for convex conjugate
reasons we will see soon) and is closely related to duality (Hiriart-Urruty
and Lemar ´echal, 2001, chapter 5).
Definition 7.4. The convex conjugate of a function f:RD→Ris a convex conjugate
function f∗defined by
f∗(s) = sup
x∈RD(⟨s,x⟩ −f(x)). (7.53)
Note that the preceding convex conjugate definition does not need the
function fto be convex nor differentiable. In Definition 7.4, we have used
a general inner product (Section 3.2) but in the rest of this section we
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
7.3 Convex Optimization 243
will consider the standard dot product between finite-dimensional vectors
(⟨s,x⟩=s⊤x) to avoid too many technical details.
To understand Definition 7.4 in a geometric fashion, consider a nice This derivation is
easiest to
understand by
drawing the
reasoning as it
progresses.simple one-dimensional convex and differentiable function, for example
f(x) =x2. Note that since we are looking at a one-dimensional problem,
hyperplanes reduce to a line. Consider a line y=sx+c. Recall that we are
able to describe convex functions by their supporting hyperplanes, so let
us try to describe this function f(x)by its supporting lines. Fix the gradi-
ent of the line s∈Rand for each point (x0, f(x0))on the graph of f, find
the minimum value of csuch that the line still intersects (x0, f(x0)). Note
that the minimum value of cis the place where a line with slope s“just
touches” the function f(x) =x2. The line passing through (x0, f(x0))
with gradient sis given by
y−f(x0) =s(x−x0). (7.54)
They-intercept of this line is −sx0+f(x0). The minimum of cfor which
y=sx+cintersects with the graph of fis therefore
inf
x0−sx0+f(x0). (7.55)
The preceding convex conjugate is by convention defined to be the nega-
tive of this. The reasoning in this paragraph did not rely on the fact that
we chose a one-dimensional convex and differentiable function, and holds
forf:RD→R, which are nonconvex and non-differentiable.The classical
Legendre transform
is defined on convex
differentiable
functions in RD.Remark. Convex differentiable functions such as the example f(x) =x2is
a nice special case, where there is no need for the supremum, and there is
a one-to-one correspondence between a function and its Legendre trans-
form. Let us derive this from first principles. For a convex differentiable
function, we know that at x0the tangent touches f(x0)so that
f(x0) =sx0+c . (7.56)
Recall that we want to describe the convex function f(x)in terms of its
gradient ∇xf(x), and that s=∇xf(x0). We rearrange to get an expres-
sion for −cto obtain
−c=sx0−f(x0). (7.57)
Note that −cchanges with x0and therefore with s, which is why we can
think of it as a function of s, which we call
f∗(s) :=sx0−f(x0). (7.58)
Comparing (7.58) with Definition 7.4, we see that (7.58) is a special case
(without the supremum). ♢
The conjugate function has nice properties; for example, for convex
functions, applying the Legendre transform again gets us back to the orig-
inal function. In the same way that the slope of f(x)iss, the slope of f∗(s)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
244 Continuous Optimization
isx. The following two examples show common uses of convex conjugates
in machine learning.
Example 7.7 (Convex Conjugates)
To illustrate the application of convex conjugates, consider the quadratic
function
f(y) =λ
2y⊤K−1y (7.59)
based on a positive definite matrix K∈Rn×n. We denote the primal
variable to be y∈Rnand the dual variable to be α∈Rn.
Applying Definition 7.4, we obtain the function
f∗(α) = sup
y∈Rn⟨y,α⟩ −λ
2y⊤K−1y. (7.60)
Since the function is differentiable, we can find the maximum by taking
the derivative and with respect to ysetting it to zero.
∂⟨y,α⟩ −λ
2y⊤K−1y
∂y= (α−λK−1y)⊤(7.61)
and hence when the gradient is zero we have y=1
λKα. Substituting
into (7.60) yields
f∗(α) =1
λα⊤Kα−λ
21
λKα⊤
K−11
λKα
=1
2λα⊤Kα.
(7.62)
Example 7.8
In machine learning, we often use sums of functions; for example, the ob-
jective function of the training set includes a sum of the losses for each ex-
ample in the training set. In the following, we derive the convex conjugate
of a sum of losses ℓ(t), where ℓ:R→R. This also illustrates the appli-
cation of the convex conjugate to the vector case. Let L(t) =Pn
i=1ℓi(ti).
Then,
L∗(z) = sup
t∈Rn⟨z,t⟩ −nX
i=1ℓi(ti) (7.63a)
= sup
t∈RnnX
i=1ziti−ℓi(ti) definition of dot product (7.63b)
=nX
i=1sup
t∈Rnziti−ℓi(ti) (7.63c)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
7.3 Convex Optimization 245
=nX
i=1ℓ∗
i(zi). definition of conjugate (7.63d)
Recall that in Section 7.2 we derived a dual optimization problem using
Lagrange multipliers. Furthermore, for convex optimization problems we
have strong duality, that is the solutions of the primal and dual problem
match. The Legendre-Fenchel transform described here also can be used
to derive a dual optimization problem. Furthermore, when the function
is convex and differentiable, the supremum is unique. To further investi-
gate the relation between these two approaches, let us consider a linear
equality constrained convex optimization problem.
Example 7.9
Letf(y)andg(x)be convex functions, and Aa real matrix of appropriate
dimensions such that Ax=y. Then
min
xf(Ax) +g(x) = min
Ax=yf(y) +g(x). (7.64)
By introducing the Lagrange multiplier ufor the constraints Ax=y,
min
Ax=yf(y) +g(x) = min
x,ymax
uf(y) +g(x) + (Ax−y)⊤u (7.65a)
= max
umin
x,yf(y) +g(x) + (Ax−y)⊤u,(7.65b)
where the last step of swapping max and min is due to the fact that f(y)
andg(x)are convex functions. By splitting up the dot product term and
collecting xandy,
max
umin
x,yf(y) +g(x) + (Ax−y)⊤u (7.66a)
= max
u
min
y−y⊤u+f(y)
+h
min
x(Ax)⊤u+g(x)i
(7.66b)
= max
u
min
y−y⊤u+f(y)
+h
min
xx⊤A⊤u+g(x)i
(7.66c)
Recall the convex conjugate (Definition 7.4) and the fact that dot prod- For general inner
products, A⊤is
replaced by the
adjoint A∗.ucts are symmetric,
max
u
min
y−y⊤u+f(y)
+h
min
xx⊤A⊤u+g(x)i
(7.67a)
= max
u−f∗(u)−g∗(−A⊤u). (7.67b)
Therefore, we have shown that
min
xf(Ax) +g(x) = max
u−f∗(u)−g∗(−A⊤u). (7.68)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
246 Continuous Optimization
The Legendre-Fenchel conjugate turns out to be quite useful for ma-
chine learning problems that can be expressed as convex optimization
problems. In particular, for convex loss functions that apply independently
to each example, the conjugate loss is a convenient way to derive a dual
problem.
7.4 Further Reading
Continuous optimization is an active area of research, and we do not try
to provide a comprehensive account of recent advances.
From a gradient descent perspective, there are two major weaknesses
which each have their own set of literature. The first challenge is the fact
that gradient descent is a first-order algorithm, and does not use infor-
mation about the curvature of the surface. When there are long valleys,
the gradient points perpendicularly to the direction of interest. The idea
of momentum can be generalized to a general class of acceleration meth-
ods (Nesterov, 2018). Conjugate gradient methods avoid the issues faced
by gradient descent by taking previous directions into account (Shewchuk,
1994). Second-order methods such as Newton methods use the Hessian to
provide information about the curvature. Many of the choices for choos-
ing step-sizes and ideas like momentum arise by considering the curvature
of the objective function (Goh, 2017; Bottou et al., 2018). Quasi-Newton
methods such as L-BFGS try to use cheaper computational methods to ap-
proximate the Hessian (Nocedal and Wright, 2006). Recently there has
been interest in other metrics for computing descent directions, result-
ing in approaches such as mirror descent (Beck and Teboulle, 2003) and
natural gradient (Toussaint, 2012).
The second challenge is to handle non-differentiable functions. Gradi-
ent methods are not well defined when there are kinks in the function.
In these cases, subgradient methods can be used (Shor, 1985). For fur-
ther information and algorithms for optimizing non-differentiable func-
tions, we refer to the book by Bertsekas (1999). There is a vast amount
of literature on different approaches for numerically solving continuous
optimization problems, including algorithms for constrained optimization
problems. Good starting points to appreciate this literature are the books
by Luenberger (1969) and Bonnans et al. (2006). A recent survey of con-
tinuous optimization is provided by Bubeck (2015). Hugo Gonc ¸alves’
blog is also a good
resource for an
easier introduction
to Legendre–Fenchel
transforms:
https://tinyurl.
com/ydaal7hjModern applications of machine learning often mean that the size of
datasets prohibit the use of batch gradient descent, and hence stochastic
gradient descent is the current workhorse of large-scale machine learning
methods. Recent surveys of the literature include Hazan (2015) and Bot-
tou et al. (2018).
For duality and convex optimization, the book by Boyd and Vanden-
berghe (2004) includes lectures and slides online. A more mathematical
treatment is provided by Bertsekas (2009), and recent book by one of
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
Exercises 247
the key researchers in the area of optimization is Nesterov (2018). Con-
vex optimization is based upon convex analysis, and the reader interested
in more foundational results about convex functions is referred to Rock-
afellar (1970), Hiriart-Urruty and Lemar ´echal (2001), and Borwein and
Lewis (2006). Legendre–Fenchel transforms are also covered in the afore-
mentioned books on convex analysis, but a more beginner-friendly pre-
sentation is available at Zia et al. (2009). The role of Legendre–Fenchel
transforms in the analysis of convex optimization algorithms is surveyed
in Polyak (2016).
Exercises
7.1 Consider the univariate function
f(x) =x3+ 6x2−3x−5.
Find its stationary points and indicate whether they are maximum, mini-
mum, or saddle points.
7.2 Consider the update equation for stochastic gradient descent (Equation (7.15)).
Write down the update when we use a mini-batch size of one.
7.3 Consider whether the following statements are true or false:
a. The intersection of any two convex sets is convex.
b. The union of any two convex sets is convex.
c. The difference of a convex set Afrom another convex set Bis convex.
7.4 Consider whether the following statements are true or false:
a. The sum of any two convex functions is convex.
b. The difference of any two convex functions is convex.
c. The product of any two convex functions is convex.
d. The maximum of any two convex functions is convex.
7.5 Express the following optimization problem as a standard linear program in
matrix notation
max
x∈R2, ξ∈Rp⊤x+ξ
subject to the constraints that ξ⩾0,x0⩽0andx1⩽3.
7.6 Consider the linear program illustrated in Figure 7.9,
min
x∈R2−
5
3⊤
x1
x2
subject to
2 2
2−4
−2 1
0−1
0 1

x1
x2
⩽
33
8
5
−1
8

Derive the dual linear program using Lagrange duality.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
248 Continuous Optimization
7.7 Consider the quadratic program illustrated in Figure 7.4,
min
x∈R21
2
x1
x2⊤
2 1
1 4
x1
x2
+
5
3⊤
x1
x2
subject to
1 0
−1 0
0 1
0−1

x1
x2
⩽
1
1
1
1

Derive the dual quadratic program using Lagrange duality.
7.8 Consider the following convex optimization problem
min
w∈RD1
2w⊤w
subject to w⊤x⩾1.
Derive the Lagrangian dual by introducing the Lagrange multiplier λ.
7.9 Consider the negative entropy of x∈RD,
f(x) =DX
d=1xdlogxd.
Derive the convex conjugate function f∗(s), by assuming the standard dot
product.
Hint: Take the gradient of an appropriate function and set the gradient to zero.
7.10 Consider the function
f(x) =1
2x⊤Ax+b⊤x+c ,
where Ais strictly positive definite, which means that it is invertible. Derive
the convex conjugate of f(x).
Hint: Take the gradient of an appropriate function and set the gradient to zero.
7.11 The hinge loss (which is the loss used by the support vector machine) is
given by
L(α) = max {0,1−α},
If we are interested in applying gradient methods such as L-BFGS, and do
not want to resort to subgradient methods, we need to smooth the kink in
the hinge loss. Compute the convex conjugate of the hinge loss L∗(β)where
βis the dual variable. Add a ℓ2proximal term, and compute the conjugate
of the resulting function
L∗(β) +γ
2β2,
where γis a given hyperparameter.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
Part II
Central Machine Learning Problems
249
This material is published by Cambridge University Press as Mathematics for Machine Learning by
Marc Peter Deisenroth, A. Aldo Faisal, and Cheng Soon Ong (2020). This version is free to view
and download for personal use only. Not for re-distribution, re-sale, or use in derivative works.
©by M. P. Deisenroth, A. A. Faisal, and C. S. Ong, 2024. https://mml-book.com .

8
When Models Meet Data
In the first part of the book, we introduced the mathematics that form
the foundations of many machine learning methods. The hope is that a
reader would be able to learn the rudimentary forms of the language of
mathematics from the first part, which we will now use to describe and
discuss machine learning. The second part of the book introduces four
pillars of machine learning:
Regression (Chapter 9)
Dimensionality reduction (Chapter 10)
Density estimation (Chapter 11)
Classification (Chapter 12)
The main aim of this part of the book is to illustrate how the mathematical
concepts introduced in the first part of the book can be used to design
machine learning algorithms that can be used to solve tasks within the
remit of the four pillars. We do not intend to introduce advanced machine
learning concepts, but instead to provide a set of practical methods that
allow the reader to apply the knowledge they gained from the first part
of the book. It also provides a gateway to the wider machine learning
literature for readers already familiar with the mathematics.
8.1 Data, Models, and Learning
It is worth at this point, to pause and consider the problem that a ma-
chine learning algorithm is designed to solve. As discussed in Chapter 1,
there are three major components of a machine learning system: data,
models, and learning. The main question of machine learning is “What do
we mean by good models?”. The word model has many subtleties, and we model
will revisit it multiple times in this chapter. It is also not entirely obvious
how to objectively define the word “good”. One of the guiding principles
of machine learning is that good models should perform well on unseen
data. This requires us to define some performance metrics, such as accu-
racy or distance from ground truth, as well as figuring out ways to do well
under these performance metrics. This chapter covers a few necessary bits
and pieces of mathematical and statistical language that are commonly
251
This material is published by Cambridge University Press as Mathematics for Machine Learning by
Marc Peter Deisenroth, A. Aldo Faisal, and Cheng Soon Ong (2020). This version is free to view
and download for personal use only. Not for re-distribution, re-sale, or use in derivative works.
©by M. P. Deisenroth, A. A. Faisal, and C. S. Ong, 2024. https://mml-book.com .
252 When Models Meet Data
Table 8.1 Example
data from a
fictitious human
resource database
that is not in a
numerical format.Name Gender Degree Postcode Age Annual salary
Aditya M MSc W21BG 36 89563
Bob M PhD EC1A1BA 47 123543
Chlo´e F BEcon SW1A1BH 26 23989
Daisuke M BSc SE207AT 68 138769
Elisabeth F MBA SE10AA 33 113888
used to talk about machine learning models. By doing so, we briefly out-
line the current best practices for training a model such that the resulting
predictor does well on data that we have not yet seen.
As mentioned in Chapter 1, there are two different senses in which we
use the phrase “machine learning algorithm”: training and prediction. We
will describe these ideas in this chapter, as well as the idea of selecting
among different models. We will introduce the framework of empirical
risk minimization in Section 8.2, the principle of maximum likelihood in
Section 8.3, and the idea of probabilistic models in Section 8.4. We briefly
outline a graphical language for specifying probabilistic models in Sec-
tion 8.5 and finally discuss model selection in Section 8.6. The rest of this
section expands upon the three main components of machine learning:
data, models and learning.
8.1.1 Data as Vectors
We assume that our data can be read by a computer, and represented ade-
quately in a numerical format. Data is assumed to be tabular (Figure 8.1),
where we think of each row of the table as representing a particular in-
stance or example, and each column to be a particular feature. In recent Data is assumed to
be in a tidy
format (Wickham,
2014; Codd, 1990).years, machine learning has been applied to many types of data that do not
obviously come in the tabular numerical format, for example genomic se-
quences, text and image contents of a webpage, and social media graphs.
We do not discuss the important and challenging aspects of identifying
good features. Many of these aspects depend on domain expertise and re-
quire careful engineering, and, in recent years, they have been put under
the umbrella of data science (Stray, 2016; Adhikari and DeNero, 2018).
Even when we have data in tabular format, there are still choices to be
made to obtain a numerical representation. For example, in Table 8.1, the
gender column (a categorical variable) may be converted into numbers 0
representing “Male” and 1representing “Female”. Alternatively, the gen-
der could be represented by numbers −1,+1, respectively (as shown in
Table 8.2). Furthermore, it is often important to use domain knowledge
when constructing the representation, such as knowing that university
degrees progress from bachelor’s to master’s to PhD or realizing that the
postcode provided is not just a string of characters but actually encodes
an area in London. In Table 8.2, we converted the data from Table 8.1
to a numerical format, and each postcode is represented as two numbers,
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
8.1 Data, Models, and Learning 253
Table 8.2 Example
data from a
fictitious human
resource database
(see Table 8.1),
converted to a
numerical format.Gender ID Degree Latitude Longitude Age Annual Salary
(in degrees) (in degrees) (in thousands)
-1 2 51.5073 0.1290 36 89.563
-1 3 51.5074 0.1275 47 123.543
+1 1 51.5071 0.1278 26 23.989
-1 1 51.5075 0.1281 68 138.769
+1 2 51.5074 0.1278 33 113.888
a latitude and longitude. Even numerical data that could potentially be
directly read into a machine learning algorithm should be carefully con-
sidered for units, scaling, and constraints. Without additional information,
one should shift and scale all columns of the dataset such that they have
an empirical mean of 0and an empirical variance of 1. For the purposes
of this book, we assume that a domain expert already converted data ap-
propriately, i.e., each input xnis aD-dimensional vector of real numbers,
which are called features ,attributes , orcovariates . We consider a dataset to feature
attribute
covariatebe of the form as illustrated by Table 8.2. Observe that we have dropped
the Name column of Table 8.1 in the new numerical representation. There
are two main reasons why this is desirable: (1) we do not expect the iden-
tifier (the Name) to be informative for a machine learning task; and (2)
we may wish to anonymize the data to help protect the privacy of the
employees.
In this part of the book, we will use Nto denote the number of exam-
ples in a dataset and index the examples with lowercase n= 1, . . . , N .
We assume that we are given a set of numerical data, represented as an
array of vectors (Table 8.2). Each row is a particular individual xn, often
referred to as an example ordata point in machine learning. The subscript example
data point nrefers to the fact that this is the nth example out of a total of Nexam-
ples in the dataset. Each column represents a particular feature of interest
about the example, and we index the features as d= 1, . . . , D . Recall that
data is represented as vectors, which means that each example (each data
point) is a D-dimensional vector. The orientation of the table originates
from the database community, but for some machine learning algorithms
(e.g., in Chapter 10) it is more convenient to represent examples as col-
umn vectors.
Let us consider the problem of predicting annual salary from age, based
on the data in Table 8.2. This is called a supervised learning problem
where we have a label yn(the salary) associated with each example xn label
(the age). The label ynhas various other names, including target, re-
sponse variable, and annotation. A dataset is written as a set of example-
label pairs {(x1, y1), . . . , (xn, yn), . . . , (xN, yN)}. The table of examples
{x1, . . . ,xN}is often concatenated, and written as X∈RN×D. Fig-
ure 8.1 illustrates the dataset consisting of the two rightmost columns
of Table 8.2, where x=age and y=salary.
We use the concepts introduced in the first part of the book to formalize
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
254 When Models Meet Data
Figure 8.1 Toy data
for linear regression.
Training data in
(xn, yn)pairs from
the rightmost two
columns of
Table 8.2. We are
interested in the
salary of a person
aged sixty ( x= 60 )
illustrated as a
vertical dashed red
line, which is not
part of the training
data.
0 10 20 30 40 50 60 70 80
x0255075100125150y
?
the machine learning problems such as that in the previous paragraph.
Representing data as vectors xnallows us to use concepts from linear al-
gebra (introduced in Chapter 2). In many machine learning algorithms,
we need to additionally be able to compare two vectors. As we will see in
Chapters 9 and 12, computing the similarity or distance between two ex-
amples allows us to formalize the intuition that examples with similar fea-
tures should have similar labels. The comparison of two vectors requires
that we construct a geometry (explained in Chapter 3) and allows us to
optimize the resulting learning problem using techniques from Chapter 7.
Since we have vector representations of data, we can manipulate data to
find potentially better representations of it. We will discuss finding good
representations in two ways: finding lower-dimensional approximations
of the original feature vector, and using nonlinear higher-dimensional
combinations of the original feature vector. In Chapter 10, we will see an
example of finding a low-dimensional approximation of the original data
space by finding the principal components. Finding principal components
is closely related to concepts of eigenvalue and singular value decomposi-
tion as introduced in Chapter 4. For the high-dimensional representation,
we will see an explicit feature map ϕ(·)that allows us to represent in- feature map
putsxnusing a higher-dimensional representation ϕ(xn). The main mo-
tivation for higher-dimensional representations is that we can construct
new features as non-linear combinations of the original features, which in
turn may make the learning problem easier. We will discuss the feature
map in Section 9.2 and show how this feature map leads to a kernel in kernel
Section 12.4. In recent years, deep learning methods (Goodfellow et al.,
2016) have shown promise in using the data itself to learn new good fea-
tures and have been very successful in areas, such as computer vision,
speech recognition, and natural language processing. We will not cover
neural networks in this part of the book, but the reader is referred to
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
8.1 Data, Models, and Learning 255
Figure 8.2 Example
function (black solid
diagonal line) and
its prediction at
x= 60 , i.e.,
f(60) = 100 .
0 10 20 30 40 50 60 70 80
x0255075100125150y
Section 5.6 for the mathematical description of backpropagation, a key
concept for training neural networks.
8.1.2 Models as Functions
Once we have data in an appropriate vector representation, we can get to
the business of constructing a predictive function (known as a predictor ). predictor
In Chapter 1, we did not yet have the language to be precise about models.
Using the concepts from the first part of the book, we can now introduce
what “model” means. We present two major approaches in this book: a
predictor as a function, and a predictor as a probabilistic model. We de-
scribe the former here and the latter in the next subsection.
A predictor is a function that, when given a particular input example
(in our case, a vector of features), produces an output. For now, consider
the output to be a single number, i.e., a real-valued scalar output. This can
be written as
f:RD→R, (8.1)
where the input vector xisD-dimensional (has Dfeatures), and the func-
tionfthen applied to it (written as f(x)) returns a real number. Fig-
ure 8.2 illustrates a possible function that can be used to compute the
value of the prediction for input values x.
In this book, we do not consider the general case of all functions, which
would involve the need for functional analysis. Instead, we consider the
special case of linear functions
f(x) =θ⊤x+θ0 (8.2)
for unknown θandθ0. This restriction means that the contents of Chap-
ters 2 and 3 suffice for precisely stating the notion of a predictor for
the non-probabilistic (in contrast to the probabilistic view described next)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
256 When Models Meet Data
Figure 8.3 Example
function (black solid
diagonal line) and
its predictive
uncertainty at
x= 60 (drawn as a
Gaussian).
0 10 20 30 40 50 60 70 80
x0255075100125150y
view of machine learning. Linear functions strike a good balance between
the generality of the problems that can be solved and the amount of back-
ground mathematics that is needed.
8.1.3 Models as Probability Distributions
We often consider data to be noisy observations of some true underlying
effect, and hope that by applying machine learning we can identify the
signal from the noise. This requires us to have a language for quantify-
ing the effect of noise. We often would also like to have predictors that
express some sort of uncertainty, e.g., to quantify the confidence we have
about the value of the prediction for a particular test data point. As we
have seen in Chapter 6, probability theory provides a language for quan-
tifying uncertainty. Figure 8.3 illustrates the predictive uncertainty of the
function as a Gaussian distribution.
Instead of considering a predictor as a single function, we could con-
sider predictors to be probabilistic models, i.e., models describing the dis-
tribution of possible functions. We limit ourselves in this book to the spe-
cial case of distributions with finite-dimensional parameters, which allows
us to describe probabilistic models without needing stochastic processes
and random measures. For this special case, we can think about prob-
abilistic models as multivariate probability distributions, which already
allow for a rich class of models.
We will introduce how to use concepts from probability (Chapter 6) to
define machine learning models in Section 8.4, and introduce a graphical
language for describing probabilistic models in a compact way in Sec-
tion 8.5.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
8.1 Data, Models, and Learning 257
8.1.4 Learning is Finding Parameters
The goal of learning is to find a model and its corresponding parame-
ters such that the resulting predictor will perform well on unseen data.
There are conceptually three distinct algorithmic phases when discussing
machine learning algorithms:
1. Prediction or inference
2. Training or parameter estimation
3. Hyperparameter tuning or model selection
The prediction phase is when we use a trained predictor on previously un-
seen test data. In other words, the parameters and model choice is already
fixed and the predictor is applied to new vectors representing new input
data points. As outlined in Chapter 1 and the previous subsection, we will
consider two schools of machine learning in this book, corresponding to
whether the predictor is a function or a probabilistic model. When we
have a probabilistic model (discussed further in Section 8.4) the predic-
tion phase is called inference.
Remark. Unfortunately, there is no agreed upon naming for the different
algorithmic phases. The word “inference” is sometimes also used to mean
parameter estimation of a probabilistic model, and less often may be also
used to mean prediction for non-probabilistic models. ♢
The training or parameter estimation phase is when we adjust our pre-
dictive model based on training data. We would like to find good predic-
tors given training data, and there are two main strategies for doing so:
finding the best predictor based on some measure of quality (sometimes
called finding a point estimate), or using Bayesian inference. Finding a
point estimate can be applied to both types of predictors, but Bayesian
inference requires probabilistic models.
For the non-probabilistic model, we follow the principle of empirical risk empirical risk
minimization minimization , which we describe in Section 8.2. Empirical risk minimiza-
tion directly provides an optimization problem for finding good parame-
ters. With a statistical model, the principle of maximum likelihood is used maximum likelihood
to find a good set of parameters (Section 8.3). We can additionally model
the uncertainty of parameters using a probabilistic model, which we will
look at in more detail in Section 8.4.
We use numerical methods to find good parameters that “fit” the data,
and most training methods can be thought of as hill-climbing approaches
to find the maximum of an objective, for example the maximum of a likeli-
hood. To apply hill-climbing approaches we use the gradients described in The convention in
optimization is to
minimize objectives.
Hence, there is often
an extra minus sign
in machine learning
objectives.Chapter 5 and implement numerical optimization approaches from Chap-
ter 7.
As mentioned in Chapter 1, we are interested in learning a model based
on data such that it performs well on future data. It is not enough for
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
258 When Models Meet Data
the model to only fit the training data well, the predictor needs to per-
form well on unseen data. We simulate the behavior of our predictor on
future unseen data using cross-validation (Section 8.2.4). As we will see cross-validation
in this chapter, to achieve the goal of performing well on unseen data,
we will need to balance between fitting well on training data and finding
“simple” explanations of the phenomenon. This trade-off is achieved us-
ing regularization (Section 8.2.3) or by adding a prior (Section 8.3.2). In
philosophy, this is considered to be neither induction nor deduction, but
is called abduction . According to the Stanford Encyclopedia of Philosophy , abduction
abduction is the process of inference to the best explanation (Douven,
2017). A good movie title is
“AI abduction”. We often need to make high-level modeling decisions about the struc-
ture of the predictor, such as the number of components to use or the
class of probability distributions to consider. The choice of the number of
components is an example of a hyperparameter , and this choice can af- hyperparameter
fect the performance of the model significantly. The problem of choosing
among different models is called model selection , which we describe in model selection
Section 8.6. For non-probabilistic models, model selection is often done
using nested cross-validation , which is described in Section 8.6.1. We also nested
cross-validation use model selection to choose hyperparameters of our model.
Remark. The distinction between parameters and hyperparameters is some-
what arbitrary, and is mostly driven by the distinction between what can
be numerically optimized versus what needs to use search techniques.
Another way to consider the distinction is to consider parameters as the
explicit parameters of a probabilistic model, and to consider hyperparam-
eters (higher-level parameters) as parameters that control the distribution
of these explicit parameters. ♢
In the following sections, we will look at three flavors of machine learn-
ing: empirical risk minimization (Section 8.2), the principle of maximum
likelihood (Section 8.3), and probabilistic modeling (Section 8.4).
8.2 Empirical Risk Minimization
After having all the mathematics under our belt, we are now in a posi-
tion to introduce what it means to learn. The “learning” part of machine
learning boils down to estimating parameters based on training data.
In this section, we consider the case of a predictor that is a function,
and consider the case of probabilistic models in Section 8.3. We describe
the idea of empirical risk minimization, which was originally popularized
by the proposal of the support vector machine (described in Chapter 12).
However, its general principles are widely applicable and allow us to ask
the question of what is learning without explicitly constructing probabilis-
tic models. There are four main design choices, which we will cover in
detail in the following subsections:
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
8.2 Empirical Risk Minimization 259
Section 8.2.1 What is the set of functions we allow the predictor to take?
Section 8.2.2 How do we measure how well the predictor performs on
the training data?
Section 8.2.3 How do we construct predictors from only training data
that performs well on unseen test data?
Section 8.2.4 What is the procedure for searching over the space of mod-
els?
8.2.1 Hypothesis Class of Functions
Assume we are given Nexamples xn∈RDand corresponding scalar la-
belsyn∈R. We consider the supervised learning setting, where we obtain
pairs (x1, y1), . . . , (xN, yN). Given this data, we would like to estimate a
predictor f(·,θ) :RD→R, parametrized by θ. We hope to be able to find
a good parameter θ∗such that we fit the data well, that is,
f(xn,θ∗)≈ynfor all n= 1, . . . , N . (8.3)
In this section, we use the notation ˆyn=f(xn,θ∗)to represent the output
of the predictor.
Remark. For ease of presentation, we will describe empirical risk mini-
mization in terms of supervised learning (where we have labels). This
simplifies the definition of the hypothesis class and the loss function. It
is also common in machine learning to choose a parametrized class of
functions, for example affine functions. ♢
Example 8.1
We introduce the problem of ordinary least-squares regression to illustrate
empirical risk minimization. A more comprehensive account of regression
is given in Chapter 9. When the label ynis real-valued, a popular choice
of function class for predictors is the set of affine functions. We choose a Affine functions are
often referred to as
linear functions in
machine learning.more compact notation for an affine function by concatenating an addi-
tional unit feature x(0)= 1toxn, i.e.,xn= [1, x(1)
n, x(2)
n, . . . , x(D)
n]⊤. The
parameter vector is correspondingly θ= [θ0, θ1, θ2, . . . , θ D]⊤, allowing us
to write the predictor as a linear function
f(xn,θ) =θ⊤xn. (8.4)
This linear predictor is equivalent to the affine model
f(xn,θ) =θ0+DX
d=1θdx(d)
n. (8.5)
The predictor takes the vector of features representing a single example
xnas input and produces a real-valued output, i.e., f:RD+1→R. The
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
260 When Models Meet Data
previous figures in this chapter had a straight line as a predictor, which
means that we have assumed an affine function.
Instead of a linear function, we may wish to consider non-linear func-
tions as predictors. Recent advances in neural networks allow for efficient
computation of more complex non-linear function classes.
Given the class of functions, we want to search for a good predictor.
We now move on to the second ingredient of empirical risk minimization:
how to measure how well the predictor fits the training data.
8.2.2 Loss Function for Training
Consider the label ynfor a particular example; and the corresponding pre-
diction ˆynthat we make based on xn. To define what it means to fit the
data well, we need to specify a loss function ℓ(yn,ˆyn)that takes the ground loss function
truth label and the prediction as input and produces a non-negative num-
ber (referred to as the loss) representing how much error we have made
on this particular prediction. Our goal for finding a good parameter vector The expression
“error” is often used
to mean loss.θ∗is to minimize the average loss on the set of Ntraining examples.
One assumption that is commonly made in machine learning is that
the set of examples (x1, y1), . . . , (xN, yN)isindependent and identically independent and
identically
distributeddistributed . The word independent (Section 6.4.5) means that two data
points (xi, yi)and(xj, yj)do not statistically depend on each other, mean-
ing that the empirical mean is a good estimate of the population mean
(Section 6.4.1). This implies that we can use the empirical mean of the
loss on the training data. For a given training set {(x1, y1), . . . , (xN, yN)}, training set
we introduce the notation of an example matrix X:= [x1, . . . ,xN]⊤∈
RN×Dand a label vector y:= [y1, . . . , y N]⊤∈RN. Using this matrix
notation the average loss is given by
Remp(f,X,y) =1
NNX
n=1ℓ(yn,ˆyn), (8.6)
where ˆyn=f(xn,θ). Equation (8.6) is called the empirical risk and de- empirical risk
pends on three arguments, the predictor fand the data X,y. This general
strategy for learning is called empirical risk minimization . empirical risk
minimization
Example 8.2 (Least-Squares Loss)
Continuing the example of least-squares regression, we specify that we
measure the cost of making an error during training using the squared
lossℓ(yn,ˆyn) = (yn−ˆyn)2. We wish to minimize the empirical risk (8.6),
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
8.2 Empirical Risk Minimization 261
which is the average of the losses over the data
min
θ∈RD1
NNX
n=1(yn−f(xn,θ))2, (8.7)
where we substituted the predictor ˆyn=f(xn,θ). By using our choice of
a linear predictor f(xn,θ) =θ⊤xn, we obtain the optimization problem
min
θ∈RD1
NNX
n=1(yn−θ⊤xn)2. (8.8)
This equation can be equivalently expressed in matrix form
min
θ∈RD1
N∥y−Xθ∥2. (8.9)
This is known as the least-squares problem . There exists a closed-form an- least-squares
problemalytic solution for this by solving the normal equations, which we will
discuss in Section 9.2.
We are not interested in a predictor that only performs well on the
training data. Instead, we seek a predictor that performs well (has low
risk) on unseen test data. More formally, we are interested in finding a
predictor f(with parameters fixed) that minimizes the expected risk expected risk
Rtrue(f) =Ex,y[ℓ(y, f(x))], (8.10)
where yis the label and f(x)is the prediction based on the example x.
The notation Rtrue(f)indicates that this is the true risk if we had access to
an infinite amount of data. The expectation is over the (infinite) set of all Another phrase
commonly used for
expected risk is
“population risk”.possible data and labels. There are two practical questions that arise from
our desire to minimize expected risk, which we address in the following
two subsections:
How should we change our training procedure to generalize well?
How do we estimate expected risk from (finite) data?
Remark. Many machine learning tasks are specified with an associated
performance measure, e.g., accuracy of prediction or root mean squared
error. The performance measure could be more complex, be cost sensitive,
and capture details about the particular application. In principle, the de-
sign of the loss function for empirical risk minimization should correspond
directly to the performance measure specified by the machine learning
task. In practice, there is often a mismatch between the design of the loss
function and the performance measure. This could be due to issues such
as ease of implementation or efficiency of optimization. ♢
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
262 When Models Meet Data
8.2.3 Regularization to Reduce Overfitting
This section describes an addition to empirical risk minimization that al-
lows it to generalize well (approximately minimizing expected risk). Re-
call that the aim of training a machine learning predictor is so that we can
perform well on unseen data, i.e., the predictor generalizes well. We sim-
ulate this unseen data by holding out a proportion of the whole dataset.
This hold out set is referred to as the test set . Given a sufficiently rich class test set
Even knowing only
the performance of
the predictor on the
test set leaks
information (Blum
and Hardt, 2015).of functions for the predictor f, we can essentially memorize the training
data to obtain zero empirical risk. While this is great to minimize the loss
(and therefore the risk) on the training data, we would not expect the
predictor to generalize well to unseen data. In practice, we have only a
finite set of data, and hence we split our data into a training and a test
set. The training set is used to fit the model, and the test set (not seen
by the machine learning algorithm during training) is used to evaluate
generalization performance. It is important for the user to not cycle back
to a new round of training after having observed the test set. We use the
subscripts trainand testto denote the training and test sets, respectively.
We will revisit this idea of using a finite dataset to evaluate expected risk
in Section 8.2.4.
It turns out that empirical risk minimization can lead to overfitting , i.e., overfitting
the predictor fits too closely to the training data and does not general-
ize well to new data (Mitchell, 1997). This general phenomenon of hav-
ing very small average loss on the training set but large average loss on
the test set tends to occur when we have little data and a complex hy-
pothesis class. For a particular predictor f(with parameters fixed), the
phenomenon of overfitting occurs when the risk estimate from the train-
ing data Remp(f,Xtrain,ytrain)underestimates the expected risk Rtrue(f).
Since we estimate the expected risk Rtrue(f)by using the empirical risk
on the test set Remp(f,Xtest,ytest)if the test risk is much larger than
the training risk, this is an indication of overfitting. We revisit the idea of
overfitting in Section 8.3.3.
Therefore, we need to somehow bias the search for the minimizer of
empirical risk by introducing a penalty term, which makes it harder for
the optimizer to return an overly flexible predictor. In machine learning,
the penalty term is referred to as regularization . Regularization is a way regularization
to compromise between accurate solution of empirical risk minimization
and the size or complexity of the solution.
Example 8.3 (Regularized Least Squares)
Regularization is an approach that discourages complex or extreme solu-
tions to an optimization problem. The simplest regularization strategy is
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
8.2 Empirical Risk Minimization 263
to replace the least-squares problem
min
θ1
N∥y−Xθ∥2. (8.11)
in the previous example with the “regularized” problem by adding a
penalty term involving only θ:
min
θ1
N∥y−Xθ∥2+λ∥θ∥2. (8.12)
The additional term ∥θ∥2is called the regularizer , and the parameter regularizer
λis the regularization parameter . The regularization parameter trades regularization
parameteroff minimizing the loss on the training set and the magnitude of the pa-
rameters θ. It often happens that the magnitude of the parameter values
becomes relatively large if we run into overfitting (Bishop, 2006).
The regularization term is sometimes called the penalty term , which bi- penalty term
ases the vector θto be closer to the origin. The idea of regularization also
appears in probabilistic models as the prior probability of the parameters.
Recall from Section 6.6 that for the posterior distribution to be of the same
form as the prior distribution, the prior and the likelihood need to be con-
jugate. We will revisit this idea in Section 8.3.2. We will see in Chapter 12
that the idea of the regularizer is equivalent to the idea of a large margin.
8.2.4 Cross-Validation to Assess the Generalization Performance
We mentioned in the previous section that we measure the generalization
error by estimating it by applying the predictor on test data. This data is
also sometimes referred to as the validation set . The validation set is a sub- validation set
set of the available training data that we keep aside. A practical issue with
this approach is that the amount of data is limited, and ideally we would
use as much of the data available to train the model. This would require
us to keep our validation set Vsmall, which then would lead to a noisy
estimate (with high variance) of the predictive performance. One solu-
tion to these contradictory objectives (large training set, large validation
set) is to use cross-validation .K-fold cross-validation effectively partitions cross-validation
the data into Kchunks, K−1of which form the training set R, and
the last chunk serves as the validation set V(similar to the idea outlined
previously). Cross-validation iterates through (ideally) all combinations
of assignments of chunks to RandV; see Figure 8.4. This procedure is
repeated for all Kchoices for the validation set, and the performance of
the model from the Kruns is averaged.
We partition our dataset into two sets D=R∪V , such that they do not
overlap ( R ∩ V =∅), where Vis the validation set, and train our model
onR. After training, we assess the performance of the predictor fon the
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
264 When Models Meet Data
Figure 8.4 K-fold
cross-validation.
The dataset is
divided into K= 5
chunks, K−1of
which serve as the
training set (blue)
and one as the
validation set
(orange hatch).Training
Validation
validation set V(e.g., by computing root mean square error (RMSE) of
the trained model on the validation set). More precisely, for each partition
kthe training data R(k)produces a predictor f(k), which is then applied
to validation set V(k)to compute the empirical risk R(f(k),V(k)). We cycle
through all possible partitionings of validation and training sets and com-
pute the average generalization error of the predictor. Cross-validation
approximates the expected generalization error
EV[R(f,V)]≈1
KKX
k=1R(f(k),V(k)), (8.13)
where R(f(k),V(k))is the risk (e.g., RMSE) on the validation set V(k)for
predictor f(k). The approximation has two sources: first, due to the finite
training set, which results in not the best possible f(k); and second, due to
the finite validation set, which results in an inaccurate estimation of the
riskR(f(k),V(k)). A potential disadvantage of K-fold cross-validation is
the computational cost of training the model Ktimes, which can be bur-
densome if the training cost is computationally expensive. In practice, it
is often not sufficient to look at the direct parameters alone. For example,
we need to explore multiple complexity parameters (e.g., multiple regu-
larization parameters), which may not be direct parameters of the model.
Evaluating the quality of the model, depending on these hyperparameters,
may result in a number of training runs that is exponential in the number
of model parameters. One can use nested cross-validation (Section 8.6.1)
to search for good hyperparameters.
However, cross-validation is an embarrassingly parallel problem, i.e., lit- embarrassingly
parallel tle effort is needed to separate the problem into a number of parallel
tasks. Given sufficient computing resources (e.g., cloud computing, server
farms), cross-validation does not require longer than a single performance
assessment.
In this section, we saw that empirical risk minimization is based on the
following concepts: the hypothesis class of functions, the loss function and
regularization. In Section 8.3, we will see the effect of using a probability
distribution to replace the idea of loss functions and regularization.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
8.3 Parameter Estimation 265
8.2.5 Further Reading
Due to the fact that the original development of empirical risk minimiza-
tion (Vapnik, 1998) was couched in heavily theoretical language, many
of the subsequent developments have been theoretical. The area of study
is called statistical learning theory (Vapnik, 1999; Evgeniou et al., 2000; statistical learning
theory Hastie et al., 2001; von Luxburg and Sch ¨olkopf, 2011). A recent machine
learning textbook that builds on the theoretical foundations and develops
efficient learning algorithms is Shalev-Shwartz and Ben-David (2014).
The concept of regularization has its roots in the solution of ill-posed in-
verse problems (Neumaier, 1998). The approach presented here is called
Tikhonov regularization , and there is a closely related constrained version Tikhonov
regularization called Ivanov regularization. Tikhonov regularization has deep relation-
ships to the bias-variance trade-off and feature selection (B ¨uhlmann and
Van De Geer, 2011). An alternative to cross-validation is bootstrap and
jackknife (Efron and Tibshirani, 1993; Davidson and Hinkley, 1997; Hall,
1992).
Thinking about empirical risk minimization (Section 8.2) as “probabil-
ity free” is incorrect. There is an underlying unknown probability distri-
bution p(x, y)that governs the data generation. However, the approach
of empirical risk minimization is agnostic to that choice of distribution.
This is in contrast to standard statistical approaches that explicitly re-
quire the knowledge of p(x, y). Furthermore, since the distribution is a
joint distribution on both examples xand labels y, the labels can be non-
deterministic. In contrast to standard statistics we do not need to specify
the noise distribution for the labels y.
8.3 Parameter Estimation
In Section 8.2, we did not explicitly model our problem using probability
distributions. In this section, we will see how to use probability distribu-
tions to model our uncertainty due to the observation process and our
uncertainty in the parameters of our predictors. In Section 8.3.1, we in-
troduce the likelihood, which is analogous to the concept of loss functions
(Section 8.2.2) in empirical risk minimization. The concept of priors (Sec-
tion 8.3.2) is analogous to the concept of regularization (Section 8.2.3).
8.3.1 Maximum Likelihood Estimation
The idea behind maximum likelihood estimation (MLE) is to define a func- maximum likelihood
estimation tion of the parameters that enables us to find a model that fits the data
well. The estimation problem is focused on the likelihood function, or likelihood
more precisely its negative logarithm. For data represented by a random
variable xand for a family of probability densities p(x|θ)parametrized
byθ, the negative log-likelihood is given by negative
log-likelihood
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
266 When Models Meet Data
Lx(θ) =−logp(x|θ). (8.14)
The notation Lx(θ)emphasizes the fact that the parameter θis varying
and the data xis fixed. We very often drop the reference to xwhen writing
the negative log-likelihood, as it is really a function of θ, and write it as
L(θ)when the random variable representing the uncertainty in the data
is clear from the context.
Let us interpret what the probability density p(x|θ)is modeling for a
fixed value of θ. It is a distribution that models the uncertainty of the data
for a given parameter setting. For a given dataset x, the likelihood allows
us to express preferences about different settings of the parameters θ, and
we can choose the setting that more “likely” has generated the data.
In a complementary view, if we consider the data to be fixed (because
it has been observed), and we vary the parameters θ, what does L(θ)tell
us? It tells us how likely a particular setting of θis for the observations x.
Based on this second view, the maximum likelihood estimator gives us the
most likely parameter θfor the set of data.
We consider the supervised learning setting, where we obtain pairs
(x1, y1), . . . , (xN, yN)withxn∈RDand labels yn∈R. We are inter-
ested in constructing a predictor that takes a feature vector xnas input
and produces a prediction yn(or something close to it), i.e., given a vec-
torxnwe want the probability distribution of the label yn. In other words,
we specify the conditional probability distribution of the labels given the
examples for the particular parameter setting θ.
Example 8.4
The first example that is often used is to specify that the conditional
probability of the labels given the examples is a Gaussian distribution. In
other words, we assume that we can explain our observation uncertainty
by independent Gaussian noise (refer to Section 6.5) with zero mean,
εn∼ N 0, σ2
. We further assume that the linear model x⊤
nθis used for
prediction. This means we specify a Gaussian likelihood for each example
label pair (xn, yn),
p(yn|xn,θ) =N yn|x⊤
nθ, σ2. (8.15)
An illustration of a Gaussian likelihood for a given parameter θis shown
in Figure 8.3. We will see in Section 9.2 how to explicitly expand the
preceding expression out in terms of the Gaussian distribution.
We assume that the set of examples (x1, y1), . . . , (xN, yN)areindependent independent and
identically
distributedand identically distributed (i.i.d.). The word “independent” (Section 6.4.5)
implies that the likelihood involving the whole dataset ( Y={y1, . . . , y N}
andX={x1, . . . ,xN}) factorizes into a product of the likelihoods of
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
8.3 Parameter Estimation 267
each individual example
p(Y |X ,θ) =NY
n=1p(yn|xn,θ), (8.16)
where p(yn|xn,θ)is a particular distribution (which was Gaussian in Ex-
ample 8.4). The expression “identically distributed” means that each term
in the product (8.16) is of the same distribution, and all of them share
the same parameters. It is often easier from an optimization viewpoint to
compute functions that can be decomposed into sums of simpler functions.
Hence, in machine learning we often consider the negative log-likelihood Recall log(ab) =
log(a) + log( b)
L(θ) =−logp(Y |X ,θ) =−NX
n=1logp(yn|xn,θ). (8.17)
While it is temping to interpret the fact that θis on the right of the condi-
tioning in p(yn|xn,θ)(8.15), and hence should be interpreted as observed
and fixed, this interpretation is incorrect. The negative log-likelihood L(θ)
is a function of θ. Therefore, to find a good parameter vector θthat
explains the data (x1, y1), . . . , (xN, yN)well, minimize the negative log-
likelihood L(θ)with respect to θ.
Remark. The negative sign in (8.17) is a historical artifact that is due
to the convention that we want to maximize likelihood, but numerical
optimization literature tends to study minimization of functions. ♢
Example 8.5
Continuing on our example of Gaussian likelihoods (8.15), the negative
log-likelihood can be rewritten as
L(θ) =−NX
n=1logp(yn|xn,θ) =−NX
n=1logN yn|x⊤
nθ, σ2
(8.18a)
=−NX
n=1log1√
2πσ2exp
−(yn−x⊤
nθ)2
2σ2
(8.18b)
=−NX
n=1log exp
−(yn−x⊤
nθ)2
2σ2
−NX
n=1log1√
2πσ2(8.18c)
=1
2σ2NX
n=1(yn−x⊤
nθ)2−NX
n=1log1√
2πσ2. (8.18d)
Asσis given, the second term in (8.18d) is constant, and minimizing L(θ)
corresponds to solving the least-squares problem (compare with (8.8))
expressed in the first term.
It turns out that for Gaussian likelihoods the resulting optimization
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
268 When Models Meet Data
Figure 8.5 For the
given data, the
maximum likelihood
estimate of the
parameters results
in the black
diagonal line. The
orange square
shows the value of
the maximum
likelihood
prediction at
x= 60 .
0 10 20 30 40 50 60 70 80
x0255075100125150y
Figure 8.6
Comparing the
predictions with the
maximum likelihood
estimate and the
MAP estimate at
x= 60 . The prior
biases the slope to
be less steep and the
intercept to be
closer to zero. In
this example, the
bias that moves the
intercept closer to
zero actually
increases the slope.
0 10 20 30 40 50 60 70 80
x0255075100125150y
MLE
MAP
problem corresponding to maximum likelihood estimation has a closed-
form solution. We will see more details on this in Chapter 9. Figure 8.5
shows a regression dataset and the function that is induced by the maxi-
mum-likelihood parameters. Maximum likelihood estimation may suffer
from overfitting (Section 8.3.3), analogous to unregularized empirical risk
minimization (Section 8.2.3). For other likelihood functions, i.e., if we
model our noise with non-Gaussian distributions, maximum likelihood es-
timation may not have a closed-form analytic solution. In this case, we
resort to numerical optimization methods discussed in Chapter 7.
8.3.2 Maximum A Posteriori Estimation
If we have prior knowledge about the distribution of the parameters θ, we
can multiply an additional term to the likelihood. This additional term is
a prior probability distribution on parameters p(θ). For a given prior, after
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
8.3 Parameter Estimation 269
observing some data x, how should we update the distribution of θ? In
other words, how should we represent the fact that we have more specific
knowledge of θafter observing data x? Bayes’ theorem, as discussed in
Section 6.3, gives us a principled tool to update our probability distribu-
tions of random variables. It allows us to compute a posterior distribution posterior
p(θ|x)(the more specific knowledge) on the parameters θfrom general
prior statements (prior distribution) p(θ)and the function p(x|θ)that prior
links the parameters θand the observed data x(called the likelihood ): likelihood
p(θ|x) =p(x|θ)p(θ)
p(x). (8.19)
Recall that we are interested in finding the parameter θthat maximizes
the posterior. Since the distribution p(x)does not depend on θ, we can
ignore the value of the denominator for the optimization and obtain
p(θ|x)∝p(x|θ)p(θ). (8.20)
The preceding proportion relation hides the density of the data p(x),
which may be difficult to estimate. Instead of estimating the minimum
of the negative log-likelihood, we now estimate the minimum of the neg-
ative log-posterior, which is referred to as maximum a posteriori estima- maximum a
posteriori
estimationtion(MAP estimation ). An illustration of the effect of adding a zero-mean
MAP estimationGaussian prior is shown in Figure 8.6.
Example 8.6
In addition to the assumption of Gaussian likelihood in the previous exam-
ple, we assume that the parameter vector is distributed as a multivariate
Gaussian with zero mean, i.e., p(θ) =N 0,Σ
, where Σis the covari-
ance matrix (Section 6.5). Note that the conjugate prior of a Gaussian
is also a Gaussian (Section 6.6.1), and therefore we expect the posterior
distribution to also be a Gaussian. We will see the details of maximum a
posteriori estimation in Chapter 9.
The idea of including prior knowledge about where good parameters
lie is widespread in machine learning. An alternative view, which we saw
in Section 8.2.3, is the idea of regularization, which introduces an addi-
tional term that biases the resulting parameters to be close to the origin.
Maximum a posteriori estimation can be considered to bridge the non-
probabilistic and probabilistic worlds as it explicitly acknowledges the
need for a prior distribution but it still only produces a point estimate
of the parameters.
Remark. The maximum likelihood estimate θMLpossesses the following
properties (Lehmann and Casella, 1998; Efron and Hastie, 2016):
Asymptotic consistency: The MLE converges to the true value in the
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
270 When Models Meet Data
Figure 8.7 Model
fitting. In a
parametrized class
Mθof models, we
optimize the model
parameters θto
minimize the
distance to the true
(unknown) model
M∗.Mθ
M∗Mθ∗
Mθ0
limit of infinitely many observations, plus a random error that is ap-
proximately normal.
The size of the samples necessary to achieve these properties can be
quite large.
The error’s variance decays in 1/N, where Nis the number of data
points.
Especially, in the “small” data regime, maximum likelihood estimation
can lead to overfitting .
♢
The principle of maximum likelihood estimation (and maximum a pos-
teriori estimation) uses probabilistic modeling to reason about the uncer-
tainty in the data and model parameters. However, we have not yet taken
probabilistic modeling to its full extent. In this section, the resulting train-
ing procedure still produces a point estimate of the predictor, i.e., training
returns one single set of parameter values that represent the best predic-
tor. In Section 8.4, we will take the view that the parameter values should
also be treated as random variables, and instead of estimating “best” val-
ues of that distribution, we will use the full parameter distribution when
making predictions.
8.3.3 Model Fitting
Consider the setting where we are given a dataset, and we are interested
in fitting a parametrized model to the data. When we talk about “fit-
ting”, we typically mean optimizing/learning model parameters so that
they minimize some loss function, e.g., the negative log-likelihood. With
maximum likelihood (Section 8.3.1) and maximum a posteriori estima-
tion (Section 8.3.2), we already discussed two commonly used algorithms
for model fitting.
The parametrization of the model defines a model class Mθwith which
we can operate. For example, in a linear regression setting, we may define
the relationship between inputs xand (noise-free) observations yto be
y=ax+b, where θ:={a, b}are the model parameters. In this case, the
model parameters θdescribe the family of affine functions, i.e., straight
lines with slope a, which are offset from 0byb. Assume the data comes
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
8.3 Parameter Estimation 271
Figure 8.8 Fitting
(by maximum
likelihood) of
different model
classes to a
regression dataset.
−4−2 0 2 4
x−4−2024y
Training data
MLE
(a) Overfitting
−4−2 0 2 4
x−4−2024y
Training data
MLE (b) Underfitting.
−4−2 0 2 4
x−4−2024y
Training data
MLE (c) Fitting well.
from a model M∗, which is unknown to us. For a given training dataset,
we optimize θso that Mθis as close as possible to M∗, where the “close-
ness” is defined by the objective function we optimize (e.g., squared loss
on the training data). Figure 8.7 illustrates a setting where we have a small
model class (indicated by the circle Mθ), and the data generation model
M∗lies outside the set of considered models. We begin our parameter
search at Mθ0. After the optimization, i.e., when we obtain the best pos-
sible parameters θ∗, we distinguish three different cases: (i) overfitting,
(ii) underfitting, and (iii) fitting well. We will give a high-level intuition
of what these three concepts mean.
Roughly speaking, overfitting refers to the situation where the para- overfitting
metrized model class is too rich to model the dataset generated by M∗,
i.e.,Mθcould model much more complicated datasets. For instance, if the
dataset was generated by a linear function, and we define Mθto be the
class of seventh-order polynomials, we could model not only linear func-
tions, but also polynomials of degree two, three, etc. Models that over-
fit typically have a large number of parameters. An observation we often One way to detect
overfitting in
practice is to
observe that the
model has low
training risk but
high test risk during
cross validation
(Section 8.2.4).make is that the overly flexible model class Mθuses all its modeling power
to reduce the training error. If the training data is noisy, it will therefore
find some useful signal in the noise itself. This will cause enormous prob-
lems when we predict away from the training data. Figure 8.8(a) gives an
example of overfitting in the context of regression where the model pa-
rameters are learned by means of maximum likelihood (see Section 8.3.1).
We will discuss overfitting in regression more in Section 9.2.2.
When we run into underfitting , we encounter the opposite problem underfitting
where the model class Mθis not rich enough. For example, if our dataset
was generated by a sinusoidal function, but θonly parametrizes straight
lines, the best optimization procedure will not get us close to the true
model. However, we still optimize the parameters and find the best straight
line that models the dataset. Figure 8.8(b) shows an example of a model
that underfits because it is insufficiently flexible. Models that underfit typ-
ically have few parameters.
The third case is when the parametrized model class is about right.
Then, our model fits well, i.e., it neither overfits nor underfits. This means
our model class is just rich enough to describe the dataset we are given.
Figure 8.8(c) shows a model that fits the given dataset fairly well. Ideally,
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
272 When Models Meet Data
this is the model class we would want to work with since it has good
generalization properties.
In practice, we often define very rich model classes Mθwith many pa-
rameters, such as deep neural networks. To mitigate the problem of over-
fitting, we can use regularization (Section 8.2.3) or priors (Section 8.3.2).
We will discuss how to choose the model class in Section 8.6.
8.3.4 Further Reading
When considering probabilistic models, the principle of maximum likeli-
hood estimation generalizes the idea of least-squares regression for linear
models, which we will discuss in detail in Chapter 9. When restricting
the predictor to have linear form with an additional nonlinear function φ
applied to the output, i.e.,
p(yn|xn,θ) =φ(θ⊤xn), (8.21)
we can consider other models for other prediction tasks, such as binary
classification or modeling count data (McCullagh and Nelder, 1989). An
alternative view of this is to consider likelihoods that are from the ex-
ponential family (Section 6.6). The class of models, which have linear
dependence between parameters and data, and have potentially nonlin-
ear transformation φ(called a link function ), is referred to as generalized link function
generalized linear
modellinear models (Agresti, 2002, chapter 4).
Maximum likelihood estimation has a rich history, and was originally
proposed by Sir Ronald Fisher in the 1930s. We will expand upon the idea
of a probabilistic model in Section 8.4. One debate among researchers
who use probabilistic models, is the discussion between Bayesian and fre-
quentist statistics. As mentioned in Section 6.1.1, it boils down to the
definition of probability. Recall from Section 6.1 that one can consider
probability to be a generalization (by allowing uncertainty) of logical rea-
soning (Cheeseman, 1985; Jaynes, 2003). The method of maximum like-
lihood estimation is frequentist in nature, and the interested reader is
pointed to Efron and Hastie (2016) for a balanced view of both Bayesian
and frequentist statistics.
There are some probabilistic models where maximum likelihood esti-
mation may not be possible. The reader is referred to more advanced sta-
tistical textbooks, e.g., Casella and Berger (2002), for approaches, such as
method of moments, M-estimation, and estimating equations.
8.4 Probabilistic Modeling and Inference
In machine learning, we are frequently concerned with the interpretation
and analysis of data, e.g., for prediction of future events and decision
making. To make this task more tractable, we often build models that
describe the generative process that generates the observed data. generative process
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
8.4 Probabilistic Modeling and Inference 273
For example, we can describe the outcome of a coin-flip experiment
(“heads” or “tails”) in two steps. First, we define a parameter µ, which
describes the probability of “heads” as the parameter of a Bernoulli distri-
bution (Chapter 6); second, we can sample an outcome x∈ {head, tail }
from the Bernoulli distribution p(x|µ) =Ber(µ). The parameter µgives
rise to a specific dataset Xand depends on the coin used. Since µis un-
known in advance and can never be observed directly, we need mecha-
nisms to learn something about µgiven observed outcomes of coin-flip
experiments. In the following, we will discuss how probabilistic modeling
can be used for this purpose.
8.4.1 Probabilistic ModelsA probabilistic
model is specified
by the joint
distribution of all
random variables.Probabilistic models represent the uncertain aspects of an experiment as
probability distributions. The benefit of using probabilistic models is that
they offer a unified and consistent set of tools from probability theory
(Chapter 6) for modeling, inference, prediction, and model selection.
In probabilistic modeling, the joint distribution p(x,θ)of the observed
variables xand the hidden parameters θis of central importance: It en-
capsulates information from the following:
The prior and the likelihood (product rule, Section 6.3).
The marginal likelihood p(x), which will play an important role in
model selection (Section 8.6), can be computed by taking the joint dis-
tribution and integrating out the parameters (sum rule, Section 6.3).
The posterior, which can be obtained by dividing the joint by the marginal
likelihood.
Only the joint distribution has this property. Therefore, a probabilistic
model is specified by the joint distribution of all its random variables.
8.4.2 Bayesian Inference
Parameter
estimation can be
phrased as an
optimization
problem.A key task in machine learning is to take a model and the data to uncover
the values of the model’s hidden variables θgiven the observed variables
x. In Section 8.3.1, we already discussed two ways for estimating model
parameters θusing maximum likelihood or maximum a posteriori esti-
mation. In both cases, we obtain a single-best value for θso that the key
algorithmic problem of parameter estimation is solving an optimization
problem. Once these point estimates θ∗are known, we use them to make
predictions. More specifically, the predictive distribution will be p(x|θ∗),
where we use θ∗in the likelihood function.
As discussed in Section 6.3, focusing solely on some statistic of the pos-
terior distribution (such as the parameter θ∗that maximizes the poste-
rior) leads to loss of information, which can be critical in a system that
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
274 When Models Meet Data
uses the prediction p(x|θ∗)to make decisions. These decision-making
systems typically have different objective functions than the likelihood, a Bayesian inference
is about learning the
distribution of
random variables.squared-error loss or a mis-classification error. Therefore, having the full
posterior distribution around can be extremely useful and leads to more
robust decisions. Bayesian inference is about finding this posterior distri-Bayesian inference
bution (Gelman et al., 2004). For a dataset X, a parameter prior p(θ), and
a likelihood function, the posterior
p(θ|X) =p(X |θ)p(θ)
p(X), p (X) =Z
p(X |θ)p(θ)dθ, (8.22)
is obtained by applying Bayes’ theorem. The key idea is to exploit Bayes’ Bayesian inference
inverts the
relationship
between parameters
and the data.theorem to invert the relationship between the parameters θand the data
X(given by the likelihood) to obtain the posterior distribution p(θ|X).
The implication of having a posterior distribution on the parameters is
that it can be used to propagate uncertainty from the parameters to the
data. More specifically, with a distribution p(θ)on the parameters our
predictions will be
p(x) =Z
p(x|θ)p(θ)dθ=Eθ[p(x|θ)], (8.23)
and they no longer depend on the model parameters θ, which have been
marginalized/integrated out. Equation (8.23) reveals that the prediction
is an average over all plausible parameter values θ, where the plausibility
is encapsulated by the parameter distribution p(θ).
Having discussed parameter estimation in Section 8.3 and Bayesian in-
ference here, let us compare these two approaches to learning. Parameter
estimation via maximum likelihood or MAP estimation yields a consistent
point estimate θ∗of the parameters, and the key computational problem
to be solved is optimization. In contrast, Bayesian inference yields a (pos-
terior) distribution, and the key computational problem to be solved is
integration. Predictions with point estimates are straightforward, whereas
predictions in the Bayesian framework require solving another integration
problem; see (8.23). However, Bayesian inference gives us a principled
way to incorporate prior knowledge, account for side information, and
incorporate structural knowledge, all of which is not easily done in the
context of parameter estimation. Moreover, the propagation of parameter
uncertainty to the prediction can be valuable in decision-making systems
for risk assessment and exploration in the context of data-efficient learn-
ing (Deisenroth et al., 2015; Kamthe and Deisenroth, 2018).
While Bayesian inference is a mathematically principled framework for
learning about parameters and making predictions, there are some prac-
tical challenges that come with it because of the integration problems we
need to solve; see (8.22) and (8.23). More specifically, if we do not choose
a conjugate prior on the parameters (Section 6.6.1), the integrals in (8.22)
and (8.23) are not analytically tractable, and we cannot compute the pos-
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
8.4 Probabilistic Modeling and Inference 275
terior, the predictions, or the marginal likelihood in closed form. In these
cases, we need to resort to approximations. Here, we can use stochas-
tic approximations, such as Markov chain Monte Carlo (MCMC) (Gilks
et al., 1996), or deterministic approximations, such as the Laplace ap-
proximation (Bishop, 2006; Barber, 2012; Murphy, 2012), variational in-
ference (Jordan et al., 1999; Blei et al., 2017), or expectation propaga-
tion (Minka, 2001a).
Despite these challenges, Bayesian inference has been successfully ap-
plied to a variety of problems, including large-scale topic modeling (Hoff-
man et al., 2013), click-through-rate prediction (Graepel et al., 2010),
data-efficient reinforcement learning in control systems (Deisenroth et al.,
2015), online ranking systems (Herbrich et al., 2007), and large-scale rec-
ommender systems. There are generic tools, such as Bayesian optimiza-
tion (Brochu et al., 2009; Snoek et al., 2012; Shahriari et al., 2016), that
are very useful ingredients for an efficient search of meta parameters of
models or algorithms.
Remark. In the machine learning literature, there can be a somewhat ar-
bitrary separation between (random) “variables” and “parameters”. While
parameters are estimated (e.g., via maximum likelihood), variables are
usually marginalized out. In this book, we are not so strict with this sep-
aration because, in principle, we can place a prior on any parameter and
integrate it out, which would then turn the parameter into a random vari-
able according to the aforementioned separation. ♢
8.4.3 Latent-Variable Models
In practice, it is sometimes useful to have additional latent variables z latent variable
(besides the model parameters θ) as part of the model (Moustaki et al.,
2015). These latent variables are different from the model parameters
θas they do not parametrize the model explicitly. Latent variables may
describe the data-generating process, thereby contributing to the inter-
pretability of the model. They also often simplify the structure of the
model and allow us to define simpler and richer model structures. Sim-
plification of the model structure often goes hand in hand with a smaller
number of model parameters (Paquet, 2008; Murphy, 2012). Learning in
latent-variable models (at least via maximum likelihood) can be done in a
principled way using the expectation maximization (EM) algorithm (Demp-
ster et al., 1977; Bishop, 2006). Examples, where such latent variables
are helpful, are principal component analysis for dimensionality reduc-
tion (Chapter 10), Gaussian mixture models for density estimation (Chap-
ter 11), hidden Markov models (Maybeck, 1979) or dynamical systems
(Ghahramani and Roweis, 1999; Ljung, 1999) for time-series modeling,
and meta learning and task generalization (Hausman et al., 2018; Sæ-
mundsson et al., 2018). Although the introduction of these latent variables
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
276 When Models Meet Data
may make the model structure and the generative process easier, learning
in latent-variable models is generally hard, as we will see in Chapter 11.
Since latent-variable models also allow us to define the process that
generates data from parameters, let us have a look at this generative pro-
cess. Denoting data by x, the model parameters by θand the latent vari-
ables by z, we obtain the conditional distribution
p(x|z,θ) (8.24)
that allows us to generate data for any model parameters and latent vari-
ables. Given that zare latent variables, we place a prior p(z)on them.
As the models we discussed previously, models with latent variables
can be used for parameter learning and inference within the frameworks
we discussed in Sections 8.3 and 8.4.2. To facilitate learning (e.g., by
means of maximum likelihood estimation or Bayesian inference), we fol-
low a two-step procedure. First, we compute the likelihood p(x|θ)of the
model, which does not depend on the latent variables. Second, we use this
likelihood for parameter estimation or Bayesian inference, where we use
exactly the same expressions as in Sections 8.3 and 8.4.2, respectively.
Since the likelihood function p(x|θ)is the predictive distribution of the
data given the model parameters, we need to marginalize out the latent
variables so that
p(x|θ) =Z
p(x|z,θ)p(z)dz, (8.25)
where p(x|z,θ)is given in (8.24) and p(z)is the prior on the latent
variables. Note that the likelihood must not depend on the latent variables The likelihood is a
function of the data
and the model
parameters, but is
independent of the
latent variables.z, but it is only a function of the data xand the model parameters θ.
The likelihood in (8.25) directly allows for parameter estimation via
maximum likelihood. MAP estimation is also straightforward with an ad-
ditional prior on the model parameters θas discussed in Section 8.3.2.
Moreover, with the likelihood (8.25) Bayesian inference (Section 8.4.2)
in a latent-variable model works in the usual way: We place a prior p(θ)
on the model parameters and use Bayes’ theorem to obtain a posterior
distribution
p(θ|X) =p(X |θ)p(θ)
p(X)(8.26)
over the model parameters given a dataset X. The posterior in (8.26) can
be used for predictions within a Bayesian inference framework; see (8.23).
One challenge we have in this latent-variable model is that the like-
lihood p(X |θ)requires the marginalization of the latent variables ac-
cording to (8.25). Except when we choose a conjugate prior p(z)for
p(x|z,θ), the marginalization in (8.25) is not analytically tractable, and
we need to resort to approximations (Bishop, 2006; Paquet, 2008; Mur-
phy, 2012; Moustaki et al., 2015).
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
8.4 Probabilistic Modeling and Inference 277
Similar to the parameter posterior (8.26) we can compute a posterior
on the latent variables according to
p(z|X) =p(X |z)p(z)
p(X), p (X |z) =Z
p(X |z,θ)p(θ)dθ,(8.27)
where p(z)is the prior on the latent variables and p(X |z)requires us to
integrate out the model parameters θ.
Given the difficulty of solving integrals analytically, it is clear that mar-
ginalizing out both the latent variables and the model parameters at the
same time is not possible in general (Bishop, 2006; Murphy, 2012). A
quantity that is easier to compute is the posterior distribution on the latent
variables, but conditioned on the model parameters, i.e.,
p(z|X,θ) =p(X |z,θ)p(z)
p(X |θ), (8.28)
where p(z)is the prior on the latent variables and p(X |z,θ)is given
in (8.24).
In Chapters 10 and 11, we derive the likelihood functions for PCA and
Gaussian mixture models, respectively. Moreover, we compute the poste-
rior distributions (8.28) on the latent variables for both PCA and Gaussian
mixture models.
Remark. In the following chapters, we may not be drawing such a clear
distinction between latent variables zand uncertain model parameters θ
and call the model parameters “latent” or “hidden” as well because they
are unobserved. In Chapters 10 and 11, where we use the latent variables
z, we will pay attention to the difference as we will have two different
types of hidden variables: model parameters θand latent variables z.♢
We can exploit the fact that all the elements of a probabilistic model are
random variables to define a unified language for representing them. In
Section 8.5, we will see a concise graphical language for representing the
structure of probabilistic models. We will use this graphical language to
describe the probabilistic models in the subsequent chapters.
8.4.4 Further Reading
Probabilistic models in machine learning (Bishop, 2006; Barber, 2012;
Murphy, 2012) provide a way for users to capture uncertainty about data
and predictive models in a principled fashion. Ghahramani (2015) presents
a short review of probabilistic models in machine learning. Given a proba-
bilistic model, we may be lucky enough to be able to compute parameters
of interest analytically. However, in general, analytic solutions are rare,
and computational methods such as sampling (Gilks et al., 1996; Brooks
et al., 2011) and variational inference (Jordan et al., 1999; Blei et al.,
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
278 When Models Meet Data
2017) are used. Moustaki et al. (2015) and Paquet (2008) provide a good
overview of Bayesian inference in latent-variable models.
In recent years, several programming languages have been proposed
that aim to treat the variables defined in software as random variables
corresponding to probability distributions. The objective is to be able to
write complex functions of probability distributions, while under the hood
the compiler automatically takes care of the rules of Bayesian inference.
This rapidly changing field is called probabilistic programming . probabilistic
programming
8.5 Directed Graphical Models
In this section, we introduce a graphical language for specifying a prob-
abilistic model, called the directed graphical model . It provides a compact directed graphical
model and succinct way to specify probabilistic models, and allows the reader to
visually parse dependencies between random variables. A graphical model
visually captures the way in which the joint distribution over all random
variables can be decomposed into a product of factors depending only on
a subset of these variables. In Section 8.4, we identified the joint distri-
bution of a probabilistic model as the key quantity of interest because it
comprises information about the prior, the likelihood, and the posterior.
However, the joint distribution by itself can be quite complicated, and Directed graphical
models are also
known as Bayesian
networks.it does not tell us anything about structural properties of the probabilis-
tic model. For example, the joint distribution p(a, b, c )does not tell us
anything about independence relations. This is the point where graphical
models come into play. This section relies on the concepts of independence
and conditional independence, as described in Section 6.4.5.
In agraphical model , nodes are random variables. In Figure 8.9(a), the graphical model
nodes represent the random variables a, b, c . Edges represent probabilistic
relations between variables, e.g., conditional probabilities.
Remark. Not every distribution can be represented in a particular choice of
graphical model. A discussion of this can be found in Bishop (2006). ♢
Probabilistic graphical models have some convenient properties:
They are a simple way to visualize the structure of a probabilistic model.
They can be used to design or motivate new kinds of statistical models.
Inspection of the graph alone gives us insight into properties, e.g., con-
ditional independence.
Complex computations for inference and learning in statistical models
can be expressed in terms of graphical manipulations.
8.5.1 Graph Semantics
Directed graphical models /Bayesian networks are a method for representing directed graphical
model/Bayesian
networkconditional dependencies in a probabilistic model. They provide a visual
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
8.5 Directed Graphical Models 279
description of the conditional probabilities, hence, providing a simple lan-
guage for describing complex interdependence. The modular description With additional
assumptions, the
arrows can be used
to indicate causal
relationships (Pearl,
2009).also entails computational simplification. Directed links (arrows) between
two nodes (random variables) indicate conditional probabilities. For ex-
ample, the arrow between aandbin Figure 8.9(a) gives the conditional
probability p(b|a)ofbgiven a.
Figure 8.9
Examples of
directed graphical
models.a b
c
(a) Fully connected.x1 x2
x3 x4x5
(b) Not fully connected.
Directed graphical models can be derived from joint distributions if we
know something about their factorization.
Example 8.7
Consider the joint distribution
p(a, b, c ) =p(c|a, b)p(b|a)p(a) (8.29)
of three random variables a, b, c . The factorization of the joint distribution
in (8.29) tells us something about the relationship between the random
variables:
cdepends directly on aandb.
bdepends directly on a.
adepends neither on bnor on c.
For the factorization in (8.29), we obtain the directed graphical model in
Figure 8.9(a).
In general, we can construct the corresponding directed graphical model
from a factorized joint distribution as follows:
1. Create a node for all random variables.
2. For each conditional distribution, we add a directed link (arrow) to
the graph from the nodes corresponding to the variables on which the
distribution is conditioned.
The graph layout
depends on the
factorization of the
joint distribution.The graph layout depends on the choice of factorization of the joint dis-
tribution.
We discussed how to get from a known factorization of the joint dis-
tribution to the corresponding directed graphical model. Now, we will do
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
280 When Models Meet Data
exactly the opposite and describe how to extract the joint distribution of
a set of random variables from a given graphical model.
Example 8.8
Looking at the graphical model in Figure 8.9(b), we exploit two proper-
ties:
The joint distribution p(x1, . . . , x 5)we seek is the product of a set of
conditionals, one for each node in the graph. In this particular example,
we will need five conditionals.
Each conditional depends only on the parents of the corresponding
node in the graph. For example, x4will be conditioned on x2.
These two properties yield the desired factorization of the joint distribu-
tion
p(x1, x2, x3, x4, x5) =p(x1)p(x5)p(x2|x5)p(x3|x1, x2)p(x4|x2).(8.30)
In general, the joint distribution p(x) =p(x1, . . . , x K)is given as
p(x) =KY
k=1p(xk|Pak), (8.31)
where Pa kmeans “the parent nodes of xk”. Parent nodes of xkare nodes
that have arrows pointing to xk.
We conclude this subsection with a concrete example of the coin-flip
experiment. Consider a Bernoulli experiment (Example 6.8) where the
probability that the outcome xof this experiment is “heads” is
p(x|µ) =Ber(µ). (8.32)
We now repeat this experiment Ntimes and observe outcomes x1, . . . , x N
so that we obtain the joint distribution
p(x1, . . . , x N|µ) =NY
n=1p(xn|µ). (8.33)
The expression on the right-hand side is a product of Bernoulli distribu-
tions on each individual outcome because the experiments are indepen-
dent. Recall from Section 6.4.5 that statistical independence means that
the distribution factorizes. To write the graphical model down for this set-
ting, we make the distinction between unobserved/latent variables and
observed variables. Graphically, observed variables are denoted by shaded
nodes so that we obtain the graphical model in Figure 8.10(a). We see
that the single parameter µis the same for all xn,n= 1, . . . , N as the
outcomes xnare identically distributed. A more compact, but equivalent,
graphical model for this setting is given in Figure 8.10(b), where we use
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
8.5 Directed Graphical Models 281
Figure 8.10
Graphical models
for a repeated
Bernoulli
experiment.µ
x1 xN
(a) Version with xnexplicit.µ
xn
n= 1, . . . , N
(b) Version with
plate notation.µ
xnβ α
n= 1, . . . , N
(c) Hyperparameters α
andβon the latent µ.
theplate notation. The plate (box) repeats everything inside (in this case, plate
the observations xn)Ntimes. Therefore, both graphical models are equiv-
alent, but the plate notation is more compact. Graphical models immedi-
ately allow us to place a hyperprior on µ. Ahyperprior is a second layer hyperprior
of prior distributions on the parameters of the first layer of priors. Fig-
ure 8.10(c) places a Beta (α, β)prior on the latent variable µ. If we treat
αandβas deterministic parameters, i.e., not random variables, we omit
the circle around it.
8.5.2 Conditional Independence and d-Separation
Directed graphical models allow us to find conditional independence (Sec-
tion 6.4.5) relationship properties of the joint distribution only by looking
at the graph. A concept called d-separation (Pearl, 1988) is key to this. d-separation
Consider a general directed graph in which A,B,Care arbitrary nonin-
tersecting sets of nodes (whose union may be smaller than the complete
set of nodes in the graph). We wish to ascertain whether a particular con-
ditional independence statement, “ Ais conditionally independent of B
givenC”, denoted by
A ⊥ ⊥ B |C , (8.34)
is implied by a given directed acyclic graph. To do so, we consider all
possible trails (paths that ignore the direction of the arrows) from any
node in Ato any nodes in B. Any such path is said to be blocked if it
includes any node such that either of the following are true:
The arrows on the path meet either head to tail or tail to tail at the
node, and the node is in the set C.
The arrows meet head to head at the node, and neither the node nor
any of its descendants is in the set C.
If all paths are blocked, then Ais said to be d-separated fromBbyC,
and the joint distribution over all of the variables in the graph will satisfy
A ⊥ ⊥ B |C .
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
282 When Models Meet Data
Figure 8.12 Three
types of graphical
models: (a) Directed
graphical models
(Bayesian
networks);
(b) Undirected
graphical models
(Markov random
fields); (c) Factor
graphs.a b
c
(a) Directed graphical modela b
c
(b) Undirected graphical
modela b
c
(c) Factor graph
Example 8.9 (Conditional Independence)
Figure 8.11
D-separation
example.a b c
d
e
Consider the graphical model in Figure 8.11. Visual inspection gives us
b⊥ ⊥d|a, c (8.35)
a⊥ ⊥c|b (8.36)
b̸⊥ ⊥d|c (8.37)
a̸⊥ ⊥c|b, e (8.38)
Directed graphical models allow a compact representation of proba-
bilistic models, and we will see examples of directed graphical models in
Chapters 9, 10, and 11. The representation, along with the concept of con-
ditional independence, allows us to factorize the respective probabilistic
models into expressions that are easier to optimize.
The graphical representation of the probabilistic model allows us to
visually see the impact of design choices we have made on the structure
of the model. We often need to make high-level assumptions about the
structure of the model. These modeling assumptions (hyperparameters)
affect the prediction performance, but cannot be selected directly using
the approaches we have seen so far. We will discuss different ways to
choose the structure in Section 8.6.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
8.6 Model Selection 283
8.5.3 Further Reading
An introduction to probabilistic graphical models can be found in Bishop
(2006, chapter 8), and an extensive description of the different applica-
tions and corresponding algorithmic implications can be found in the book
by Koller and Friedman (2009). There are three main types of probabilistic
graphical models:
directed graphical
model Directed graphical models (Bayesian networks ); see Figure 8.12(a)
Bayesian network
undirected graphical
modelUndirected graphical models (Markov random fields ); see Figure 8.12(b)
Markov random
field
factor graphFactor graphs ; see Figure 8.12(c)
Graphical models allow for graph-based algorithms for inference and
learning, e.g., via local message passing. Applications range from rank-
ing in online games (Herbrich et al., 2007) and computer vision (e.g.,
image segmentation, semantic labeling, image denoising, image restora-
tion (Kittler and F ¨oglein, 1984; Sucar and Gillies, 1994; Shotton et al.,
2006; Szeliski et al., 2008)) to coding theory (McEliece et al., 1998), solv-
ing linear equation systems (Shental et al., 2008), and iterative Bayesian
state estimation in signal processing (Bickson et al., 2007; Deisenroth and
Mohamed, 2012).
One topic that is particularly important in real applications that we do
not discuss in this book is the idea of structured prediction (Bakir et al.,
2007; Nowozin et al., 2014), which allows machine learning models to
tackle predictions that are structured, for example sequences, trees, and
graphs. The popularity of neural network models has allowed more flex-
ible probabilistic models to be used, resulting in many useful applica-
tions of structured models (Goodfellow et al., 2016, chapter 16). In recent
years, there has been a renewed interest in graphical models due to their
applications to causal inference (Pearl, 2009; Imbens and Rubin, 2015;
Peters et al., 2017; Rosenbaum, 2017).
8.6 Model Selection
In machine learning, we often need to make high-level modeling decisions
that critically influence the performance of the model. The choices we
make (e.g., the functional form of the likelihood) influence the number
and type of free parameters in the model and thereby also the flexibility
and expressivity of the model. More complex models are more flexible in A polynomial
y=a0+a1x+a2x2
can also describe
linear functions by
setting a2= 0, i.e.,
it is strictly more
expressive than a
first-order
polynomial.the sense that they can be used to describe more datasets. For instance, a
polynomial of degree 1(a line y=a0+a1x) can only be used to describe
linear relations between inputs xand observations y. A polynomial of
degree 2can additionally describe quadratic relationships between inputs
and observations.
One would now think that very flexible models are generally preferable
to simple models because they are more expressive. A general problem
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
284 When Models Meet Data
Figure 8.13 Nested
cross-validation. We
perform two levels
ofK-fold
cross-validation.All labeled data
All training data Test data
To train model Validation
is that at training time we can only use the training set to evaluate the
performance of the model and learn its parameters. However, the per-
formance on the training set is not really what we are interested in. In
Section 8.3, we have seen that maximum likelihood estimation can lead
to overfitting, especially when the training dataset is small. Ideally, our
model (also) works well on the test set (which is not available at training
time). Therefore, we need some mechanisms for assessing how a model
generalizes to unseen test data. Model selection is concerned with exactly
this problem.
8.6.1 Nested Cross-Validation
We have already seen an approach (cross-validation in Section 8.2.4) that
can be used for model selection. Recall that cross-validation provides an
estimate of the generalization error by repeatedly splitting the dataset into
training and validation sets. We can apply this idea one more time, i.e.,
for each split, we can perform another round of cross-validation. This is
sometimes referred to as nested cross-validation ; see Figure 8.13. The inner nested
cross-validation level is used to estimate the performance of a particular choice of model
or hyperparameter on a internal validation set. The outer level is used to
estimate generalization performance for the best choice of model chosen
by the inner loop. We can test different model and hyperparameter choices
in the inner loop. To distinguish the two levels, the set used to estimate
the generalization performance is often called the test set and the set used test set
for choosing the best model is called the validation set . The inner loop validation set
estimates the expected value of the generalization error for a given model
(8.39), by approximating it using the empirical error on the validation set,
i.e., The standard error
is defined asσ√
K,
where Kis the
number of
experiments and σ
is the standard
deviation of the risk
of each experiment.EV[R(V |M)]≈1
KKX
k=1R(V(k)|M), (8.39)
where R(V |M)is the empirical risk (e.g., root mean square error) on the
validation set Vfor model M. We repeat this procedure for all models and
choose the model that performs best. Note that cross-validation not only
gives us the expected generalization error, but we can also obtain high-
order statistics, e.g., the standard error, an estimate of how uncertain the
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
8.6 Model Selection 285
Figure 8.14
Bayesian inference
embodies Occam’s
razor. The
horizontal axis
describes the space
of all possible
datasets D. The
evidence (vertical
axis) evaluates how
well a model
predicts available
data. Since
p(D |Mi)needs to
integrate to 1, we
should choose the
model with the
greatest evidence.
Adapted
from MacKay
(2003).Evidence
D
Cp(D |M1)
p(D |M2)
mean estimate is. Once the model is chosen, we can evaluate the final
performance on the test set.
8.6.2 Bayesian Model Selection
There are many approaches to model selection, some of which are covered
in this section. Generally, they all attempt to trade off model complexity
and data fit. We assume that simpler models are less prone to overfitting
than complex models, and hence the objective of model selection is to find
the simplest model that explains the data reasonably well. This concept is
also known as Occam’s razor . Occam’s razor
Remark. If we treat model selection as a hypothesis testing problem, we
are looking for the simplest hypothesis that is consistent with the data (Mur-
phy, 2012). ♢
One may consider placing a prior on models that favors simpler models.
However, it is not necessary to do this: An “automatic Occam’s Razor” is
quantitatively embodied in the application of Bayesian probability (Smith
and Spiegelhalter, 1980; Jefferys and Berger, 1992; MacKay, 1992). Fig-
ure 8.14, adapted from MacKay (2003), gives us the basic intuition why
complex and very expressive models may turn out to be a less probable
choice for modeling a given dataset D. Let us think of the horizontal axis These predictions
are quantified by a
normalized
probability
distribution on D,
i.e., it needs to
integrate/sum to 1.representing the space of all possible datasets D. If we are interested in
the posterior probability p(Mi|D)of model Migiven the data D, we can
employ Bayes’ theorem. Assuming a uniform prior p(M)over all mod-
els, Bayes’ theorem rewards models in proportion to how much they pre-
dicted the data that occurred. This prediction of the data given model
Mi,p(D |Mi), is called the evidence forMi. A simple model M1can only evidence
predict a small number of datasets, which is shown by p(D |M1); a more
powerful model M2that has, e.g., more free parameters than M1, is able
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
286 When Models Meet Data
to predict a greater variety of datasets. This means, however, that M2
does not predict the datasets in region Cas well as M1. Suppose that
equal prior probabilities have been assigned to the two models. Then, if
the dataset falls into region C, the less powerful model M1is the more
probable model.
Earlier in this chapter, we argued that models need to be able to explain
the data, i.e., there should be a way to generate data from a given model.
Furthermore, if the model has been appropriately learned from the data,
then we expect that the generated data should be similar to the empirical
data. For this, it is helpful to phrase model selection as a hierarchical
inference problem, which allows us to compute the posterior distribution
over models.
Let us consider a finite number of models M={M1, . . . , M K}, where
each model Mkpossesses parameters θk. InBayesian model selection , we Bayesian model
selection place a prior p(M)on the set of models. The corresponding generative
generative processprocess that allows us to generate data from this model is
Figure 8.15
Illustration of the
hierarchical
generative process
in Bayesian model
selection. We place
a prior p(M)on the
set of models. For
each model, there is
a distribution
p(θ|M)on the
corresponding
model parameters,
which is used to
generate the data D.
M
θ
DMk∼p(M) (8.40)
θk∼p(θ|Mk) (8.41)
D ∼p(D |θk) (8.42)
and illustrated in Figure 8.15. Given a training set D, we apply Bayes’
theorem and compute the posterior distribution over models as
p(Mk|D)∝p(Mk)p(D |Mk). (8.43)
Note that this posterior no longer depends on the model parameters θk
because they have been integrated out in the Bayesian setting since
p(D |Mk) =Z
p(D |θk)p(θk|Mk)dθk, (8.44)
where p(θk|Mk)is the prior distribution of the model parameters θkof
model Mk. The term (8.44) is referred to as the model evidence ormarginal
model evidence
marginal likelihoodlikelihood . From the posterior in (8.43), we determine the MAP estimate
M∗= arg max
Mkp(Mk|D). (8.45)
With a uniform prior p(Mk) =1
K, which gives every model equal (prior)
probability, determining the MAP estimate over models amounts to pick-
ing the model that maximizes the model evidence (8.44).
Remark (Likelihood and Marginal Likelihood) .There are some important
differences between a likelihood and a marginal likelihood (evidence):
While the likelihood is prone to overfitting, the marginal likelihood is typ-
ically not as the model parameters have been marginalized out (i.e., we
no longer have to fit the parameters). Furthermore, the marginal likeli-
hood automatically embodies a trade-off between model complexity and
data fit (Occam’s razor). ♢
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
8.6 Model Selection 287
8.6.3 Bayes Factors for Model Comparison
Consider the problem of comparing two probabilistic models M1, M2,
given a dataset D. If we compute the posteriors p(M1|D)andp(M2|D),
we can compute the ratio of the posteriors
p(M1|D)
p(M2|D)|{z}
posterior odds=p(D |M1)p(M1)
p(D)
p(D |M2)p(M2)
p(D)=p(M1)
p(M2)|{z}
prior oddsp(D |M1)
p(D |M2)|{z}
Bayes factor. (8.46)
The ratio of the posteriors is also called the posterior odds . The first frac- posterior odds
tion on the right-hand side of (8.46), the prior odds , measures how much prior odds
our prior (initial) beliefs favor M1overM2. The ratio of the marginal like-
lihoods (second fraction on the right-hand-side) is called the Bayes factor Bayes factor
and measures how well the data Dis predicted by M1compared to M2.
Remark. TheJeffreys-Lindley paradox states that the “Bayes factor always Jeffreys-Lindley
paradox favors the simpler model since the probability of the data under a complex
model with a diffuse prior will be very small” (Murphy, 2012). Here, a
diffuse prior refers to a prior that does not favor specific models, i.e.,
many models are a priori plausible under this prior. ♢
If we choose a uniform prior over models, the prior odds term in (8.46)
is1, i.e., the posterior odds is the ratio of the marginal likelihoods (Bayes
factor)
p(D |M1)
p(D |M2). (8.47)
If the Bayes factor is greater than 1, we choose model M1, otherwise
model M2. In a similar way to frequentist statistics, there are guidelines
on the size of the ratio that one should consider before ”significance” of
the result (Jeffreys, 1961).
Remark (Computing the Marginal Likelihood) .The marginal likelihood
plays an important role in model selection: We need to compute Bayes
factors (8.46) and posterior distributions over models (8.43).
Unfortunately, computing the marginal likelihood requires us to solve
an integral (8.44). This integration is generally analytically intractable,
and we will have to resort to approximation techniques, e.g., numerical
integration (Stoer and Burlirsch, 2002), stochastic approximations using
Monte Carlo (Murphy, 2012), or Bayesian Monte Carlo techniques (O’Hagan,
1991; Rasmussen and Ghahramani, 2003).
However, there are special cases in which we can solve it. In Section 6.6.1,
we discussed conjugate models. If we choose a conjugate parameter prior
p(θ), we can compute the marginal likelihood in closed form. In Chap-
ter 9, we will do exactly this in the context of linear regression. ♢
We have seen a brief introduction to the basic concepts of machine
learning in this chapter. For the rest of this part of the book we will see
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
288 When Models Meet Data
how the three different flavors of learning in Sections 8.2, 8.3, and 8.4 are
applied to the four pillars of machine learning (regression, dimensionality
reduction, density estimation, and classification).
8.6.4 Further Reading
We mentioned at the start of the section that there are high-level modeling
choices that influence the performance of the model. Examples include the
following:
The degree of a polynomial in a regression setting
The number of components in a mixture model
The network architecture of a (deep) neural network
The type of kernel in a support vector machine
The dimensionality of the latent space in PCA
The learning rate (schedule) in an optimization algorithm
In parametric
models, the number
of parameters is
often related to the
complexity of the
model class.Rasmussen and Ghahramani (2001) showed that the automatic Occam’s
razor does not necessarily penalize the number of parameters in a model,
but it is active in terms of the complexity of functions. They also showed
that the automatic Occam’s razor also holds for Bayesian nonparametric
models with many parameters, e.g., Gaussian processes.
If we focus on the maximum likelihood estimate, there exist a number of
heuristics for model selection that discourage overfitting. They are called
information criteria, and we choose the model with the largest value. The
Akaike information criterion (AIC) (Akaike, 1974) Akaike information
criterion
logp(x|θ)−M (8.48)
corrects for the bias of the maximum likelihood estimator by addition of
a penalty term to compensate for the overfitting of more complex models
with lots of parameters. Here, Mis the number of model parameters. The
AIC estimates the relative information lost by a given model.
TheBayesian information criterion (BIC) (Schwarz, 1978) Bayesian
information
criterion logp(x) = logZ
p(x|θ)p(θ)dθ≈logp(x|θ)−1
2MlogN (8.49)
can be used for exponential family distributions. Here, Nis the number
of data points and Mis the number of parameters. BIC penalizes model
complexity more heavily than AIC.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
9
Linear Regression
In the following, we will apply the mathematical concepts from Chap-
ters 2, 5, 6, and 7 to solve linear regression (curve fitting) problems. In
regression , we aim to find a function fthat maps inputs x∈RDto corre- regression
sponding function values f(x)∈R. We assume we are given a set of train-
ing inputs xnand corresponding noisy observations yn=f(xn)+ϵ, where
ϵis an i.i.d. random variable that describes measurement/observation
noise and potentially unmodeled processes (which we will not consider
further in this chapter). Throughout this chapter, we assume zero-mean
Gaussian noise. Our task is to find a function that not only models the
training data, but generalizes well to predicting function values at input
locations that are not part of the training data (see Chapter 8). An il-
lustration of such a regression problem is given in Figure 9.1. A typical
regression setting is given in Figure 9.1(a): For some input values xn, we
observe (noisy) function values yn=f(xn) +ϵ. The task is to infer the
function fthat generated the data and generalizes well to function values
at new input locations. A possible solution is given in Figure 9.1(b), where
we also show three distributions centered at the function values f(x)that
represent the noise in the data.
Regression is a fundamental problem in machine learning, and regres-
sion problems appear in a diverse range of research areas and applica-
Figure 9.1
(a) Dataset;
(b) possible solution
to the regression
problem.
−4−2 0 2 4
x−0.4−0.20.00.20.4y
(a) Regression problem: observed noisy func-
tion values from which we wish to infer the
underlying function that generated the data.
−4−2 0 2 4
x−0.4−0.20.00.20.4y
(b) Regression solution: possible function
that could have generated the data (blue)
with indication of the measurement noise of
the function value at the corresponding in-
puts (orange distributions).
289
This material is published by Cambridge University Press as Mathematics for Machine Learning by
Marc Peter Deisenroth, A. Aldo Faisal, and Cheng Soon Ong (2020). This version is free to view
and download for personal use only. Not for re-distribution, re-sale, or use in derivative works.
©by M. P. Deisenroth, A. A. Faisal, and C. S. Ong, 2024. https://mml-book.com .
290 Linear Regression
tions, including time-series analysis (e.g., system identification), control
and robotics (e.g., reinforcement learning, forward/inverse model learn-
ing), optimization (e.g., line searches, global optimization), and deep-
learning applications (e.g., computer games, speech-to-text translation,
image recognition, automatic video annotation). Regression is also a key
ingredient of classification algorithms. Finding a regression function re-
quires solving a variety of problems, including the following:
Choice of the model (type) and the parametrization of the regres-
sion function. Given a dataset, what function classes (e.g., polynomi- Normally, the type
of noise could also
be a “model choice”,
but we fix the noise
to be Gaussian in
this chapter.als) are good candidates for modeling the data, and what particular
parametrization (e.g., degree of the polynomial) should we choose?
Model selection, as discussed in Section 8.6, allows us to compare var-
ious models to find the simplest model that explains the training data
reasonably well.
Finding good parameters. Having chosen a model of the regression
function, how do we find good model parameters? Here, we will need to
look at different loss/objective functions (they determine what a “good”
fit is) and optimization algorithms that allow us to minimize this loss.
Overfitting and model selection. Overfitting is a problem when the
regression function fits the training data “too well” but does not gen-
eralize to unseen test data. Overfitting typically occurs if the underly-
ing model (or its parametrization) is overly flexible and expressive; see
Section 8.6. We will look at the underlying reasons and discuss ways to
mitigate the effect of overfitting in the context of linear regression.
Relationship between loss functions and parameter priors. Loss func-
tions (optimization objectives) are often motivated and induced by prob-
abilistic models. We will look at the connection between loss functions
and the underlying prior assumptions that induce these losses.
Uncertainty modeling. In any practical setting, we have access to only
a finite, potentially large, amount of (training) data for selecting the
model class and the corresponding parameters. Given that this finite
amount of training data does not cover all possible scenarios, we may
want to describe the remaining parameter uncertainty to obtain a mea-
sure of confidence of the model’s prediction at test time; the smaller the
training set, the more important uncertainty modeling. Consistent mod-
eling of uncertainty equips model predictions with confidence bounds.
In the following, we will be using the mathematical tools from Chap-
ters 3, 5, 6 and 7 to solve linear regression problems. We will discuss
maximum likelihood and maximum a posteriori (MAP) estimation to find
optimal model parameters. Using these parameter estimates, we will have
a brief look at generalization errors and overfitting. Toward the end of
this chapter, we will discuss Bayesian linear regression, which allows us to
reason about model parameters at a higher level, thereby removing some
of the problems encountered in maximum likelihood and MAP estimation.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
9.1 Problem Formulation 291
9.1 Problem Formulation
Because of the presence of observation noise, we will adopt a probabilis-
tic approach and explicitly model the noise using a likelihood function.
More specifically, throughout this chapter, we consider a regression prob-
lem with the likelihood function
p(y|x) =N y|f(x), σ2. (9.1)
Here, x∈RDare inputs and y∈Rare noisy function values (targets).
With (9.1), the functional relationship between xandyis given as
y=f(x) +ϵ , (9.2)
where ϵ∼ N 0, σ2
is independent, identically distributed (i.i.d.) Gaus-
sian measurement noise with mean 0and variance σ2. Our objective is
to find a function that is close (similar) to the unknown function fthat
generated the data and that generalizes well.
In this chapter, we focus on parametric models, i.e., we choose a para-
metrized function and find parameters θthat “work well” for modeling the
data. For the time being, we assume that the noise variance σ2is known
and focus on learning the model parameters θ. In linear regression, we
consider the special case that the parameters θappear linearly in our
model. An example of linear regression is given by
p(y|x,θ) =N y|x⊤θ, σ2
(9.3)
⇐⇒y=x⊤θ+ϵ , ϵ ∼ N 0, σ2, (9.4)
where θ∈RDare the parameters we seek. The class of functions de-
scribed by (9.4) are straight lines that pass through the origin. In (9.4),
we chose a parametrization f(x) =x⊤θ. A Dirac delta (delta
function) is zero
everywhere except
at a single point,
and its integral is 1.
It can be considered
a Gaussian in the
limit of σ2→0.Thelikelihood in (9.3) is the probability density function of yevalu-
likelihoodated at x⊤θ. Note that the only source of uncertainty originates from the
observation noise (as xandθare assumed known in (9.3)). Without ob-
servation noise, the relationship between xandywould be deterministic
and (9.3) would be a Dirac delta.
Example 9.1
Forx, θ∈Rthe linear regression model in (9.4) describes straight lines
(linear functions), and the parameter θis the slope of the line. Fig-
ure 9.2(a) shows some example functions for different values of θ.
Linear regression
refers to models that
are linear in the
parameters.The linear regression model in (9.3)–(9.4) is not only linear in the pa-
rameters, but also linear in the inputs x. Figure 9.2(a) shows examples
of such functions. We will see later that y=ϕ⊤(x)θfor nonlinear trans-
formations ϕis also a linear regression model because “linear regression”
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
292 Linear Regression
Figure 9.2 Linear
regression example.
(a) Example
functions that fall
into this category;
(b) training set;
(c) maximum
likelihood estimate.
−10 0 10
x−20020y (a) Example functions (straight
lines) that can be described us-
ing the linear model in (9.4).
−10−5 0 5 10
x−10010y
(b) Training set.
−10−5 0 5 10
x−10010y
 (c) Maximum likelihood esti-
mate.
refers to models that are “linear in the parameters”, i.e., models that de-
scribe a function by a linear combination of input features. Here, a “fea-
ture” is a representation ϕ(x)of the inputs x.
In the following, we will discuss in more detail how to find good pa-
rameters θand how to evaluate whether a parameter set “works well”.
For the time being, we assume that the noise variance σ2is known.
9.2 Parameter Estimation
Consider the linear regression setting (9.4) and assume we are given a
training set D:={(x1, y1), . . . , (xN, yN)}consisting of Ninputs xn∈ training set
RDand corresponding observations/targets yn∈R,n= 1, . . . , N . The Figure 9.3
Probabilistic
graphical model for
linear regression.
Observed random
variables are
shaded,
deterministic/
known values are
without circles.
θ
ynσ
xn
n= 1, . . . , Ncorresponding graphical model is given in Figure 9.3. Note that yiandyj
are conditionally independent given their respective inputs xi,xjso that
the likelihood factorizes according to
p(Y |X ,θ) =p(y1, . . . , y N|x1, . . . ,xN,θ) (9.5a)
=NY
n=1p(yn|xn,θ) =NY
n=1N yn|x⊤
nθ, σ2, (9.5b)
where we defined X:={x1, . . . ,xN}andY:={y1, . . . , y N}as the sets
of training inputs and corresponding targets, respectively. The likelihood
and the factors p(yn|xn,θ)are Gaussian due to the noise distribution;
see (9.3).
In the following, we will discuss how to find optimal parameters θ∗∈
RDfor the linear regression model (9.4). Once the parameters θ∗are
found, we can predict function values by using this parameter estimate
in (9.4) so that at an arbitrary test input x∗the distribution of the corre-
sponding target y∗is
p(y∗|x∗,θ∗) =N y∗|x⊤
∗θ∗, σ2. (9.6)
In the following, we will have a look at parameter estimation by maxi-
mizing the likelihood, a topic that we already covered to some degree in
Section 8.3.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
9.2 Parameter Estimation 293
9.2.1 Maximum Likelihood Estimation
A widely used approach to finding the desired parameters θMLismaximum maximum likelihood
estimation likelihood estimation , where we find parameters θMLthat maximize the
likelihood (9.5b). Intuitively, maximizing the likelihood means maximiz- Maximizing the
likelihood means
maximizing the
predictive
distribution of the
(training) data
given the
parameters.ing the predictive distribution of the training data given the model param-
eters. We obtain the maximum likelihood parameters as
θML∈arg max
θp(Y |X ,θ). (9.7)
The likelihood is not
a probability
distribution in the
parameters.Remark. The likelihood p(y|x,θ)is not a probability distribution in θ: It
is simply a function of the parameters θbut does not integrate to 1(i.e.,
it is unnormalized), and may not even be integrable with respect to θ.
However, the likelihood in (9.7) is a normalized probability distribution
iny. ♢
To find the desired parameters θMLthat maximize the likelihood, we
typically perform gradient ascent (or gradient descent on the negative
likelihood). In the case of linear regression we consider here, however, Since the logarithm
is a (strictly)
monotonically
increasing function,
the optimum of a
function fis
identical to the
optimum of logf.a closed-form solution exists, which makes iterative gradient descent un-
necessary. In practice, instead of maximizing the likelihood directly, we
apply the log-transformation to the likelihood function and minimize the
negative log-likelihood.
Remark (Log-Transformation) .Since the likelihood (9.5b) is a product of
NGaussian distributions, the log-transformation is useful since (a) it does
not suffer from numerical underflow, and (b) the differentiation rules will
turn out simpler. More specifically, numerical underflow will be a prob-
lem when we multiply Nprobabilities, where Nis the number of data
points, since we cannot represent very small numbers, such as 10−256.
Furthermore, the log-transform will turn the product into a sum of log-
probabilities such that the corresponding gradient is a sum of individual
gradients, instead of a repeated application of the product rule (5.46) to
compute the gradient of a product of Nterms. ♢
To find the optimal parameters θMLof our linear regression problem,
we minimize the negative log-likelihood
−logp(Y |X ,θ) =−logNY
n=1p(yn|xn,θ) =−NX
n=1logp(yn|xn,θ),(9.8)
where we exploited that the likelihood (9.5b) factorizes over the number
of data points due to our independence assumption on the training set.
In the linear regression model (9.4), the likelihood is Gaussian (due to
the Gaussian additive noise term), such that we arrive at
logp(yn|xn,θ) =−1
2σ2(yn−x⊤
nθ)2+const , (9.9)
where the constant includes all terms independent of θ. Using (9.9) in the
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
294 Linear Regression
negative log-likelihood (9.8), we obtain (ignoring the constant terms)
L(θ) :=1
2σ2NX
n=1(yn−x⊤
nθ)2(9.10a)
=1
2σ2(y−Xθ)⊤(y−Xθ) =1
2σ2∥y−Xθ∥2, (9.10b)
where we define the design matrix X:= [x1, . . . ,xN]⊤∈RN×Das the The negative
log-likelihood
function is also
called error function .
design matrixcollection of training inputs and y:= [y1, . . . , y N]⊤∈RNas a vector that
collects all training targets. Note that the nth row in the design matrix X
corresponds to the training input xn. In (9.10b), we used the fact that the
The squared error is
often used as a
measure of distance.sum of squared errors between the observations ynand the corresponding
model prediction x⊤
nθequals the squared distance between yandXθ.
Recall from
Section 3.1 that
∥x∥2=x⊤xif we
choose the dot
product as the inner
product.With (9.10b), we have now a concrete form of the negative log-likelihood
function we need to optimize. We immediately see that (9.10b) is quadratic
inθ. This means that we can find a unique global solution θMLfor mini-
mizing the negative log-likelihood L. We can find the global optimum by
computing the gradient of L, setting it to 0and solving for θ.
Using the results from Chapter 5, we compute the gradient of Lwith
respect to the parameters as
dL
dθ=d
dθ1
2σ2(y−Xθ)⊤(y−Xθ)
(9.11a)
=1
2σ2d
dθ
y⊤y−2y⊤Xθ+θ⊤X⊤Xθ
(9.11b)
=1
σ2(−y⊤X+θ⊤X⊤X)∈R1×D. (9.11c)
The maximum likelihood estimator θMLsolvesdL
dθ=0⊤(necessary opti-
mality condition) and we obtain Ignoring the
possibility of
duplicate data
points, rk(X) =D
ifN⩾D, i.e., we
do not have more
parameters than
data points.dL
dθ=0⊤(9.11c)⇐⇒θ⊤
MLX⊤X=y⊤X (9.12a)
⇐⇒θ⊤
ML=y⊤X(X⊤X)−1(9.12b)
⇐⇒θML= (X⊤X)−1X⊤y. (9.12c)
We could right-multiply the first equation by (X⊤X)−1because X⊤Xis
positive definite if rk(X) =D, where rk(X)denotes the rank of X.
Remark. Setting the gradient to 0⊤is a necessary and sufficient condition,
and we obtain a global minimum since the Hessian ∇2
θL(θ) =X⊤X∈
RD×Dis positive definite. ♢
Remark. The maximum likelihood solution in (9.12c) requires us to solve
a system of linear equations of the form Aθ=bwithA= (X⊤X)and
b=X⊤y. ♢
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
9.2 Parameter Estimation 295
Example 9.2 (Fitting Lines)
Let us have a look at Figure 9.2, where we aim to fit a straight line f(x) =
θx, where θis an unknown slope, to a dataset using maximum likelihood
estimation. Examples of functions in this model class (straight lines) are
shown in Figure 9.2(a). For the dataset shown in Figure 9.2(b), we find
the maximum likelihood estimate of the slope parameter θusing (9.12c)
and obtain the maximum likelihood linear function in Figure 9.2(c).
Maximum Likelihood Estimation with Features
So far, we considered the linear regression setting described in (9.4),
which allowed us to fit straight lines to data using maximum likelihood
estimation. However, straight lines are not sufficiently expressive when it Linear regression
refers to “linear-in-
the-parameters”
regression models,
but the inputs can
undergo any
nonlinear
transformation.comes to fitting more interesting data. Fortunately, linear regression offers
us a way to fit nonlinear functions within the linear regression framework:
Since “linear regression” only refers to “linear in the parameters”, we can
perform an arbitrary nonlinear transformation ϕ(x)of the inputs xand
then linearly combine the components of this transformation. The corre-
sponding linear regression model is
p(y|x,θ) =N y|ϕ⊤(x)θ, σ2
⇐⇒y=ϕ⊤(x)θ+ϵ=K−1X
k=0θkϕk(x) +ϵ ,(9.13)
where ϕ:RD→RKis a (nonlinear) transformation of the inputs xand
ϕk:RD→Ris the kth component of the feature vector ϕ. Note that the feature vector
model parameters θstill appear only linearly.
Example 9.3 (Polynomial Regression)
We are concerned with a regression problem y=ϕ⊤(x)θ+ϵ, where x∈R
andθ∈RK. A transformation that is often used in this context is
ϕ(x) =
ϕ0(x)
ϕ1(x)
...
ϕK−1(x)
=
1
x
x2
x3
...
xK−1
∈RK. (9.14)
This means that we “lift” the original one-dimensional input space into
aK-dimensional feature space consisting of all monomials xkfork=
0, . . . , K −1. With these features, we can model polynomials of degree
⩽K−1within the framework of linear regression: A polynomial of degree
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
296 Linear Regression
K−1is
f(x) =K−1X
k=0θkxk=ϕ⊤(x)θ, (9.15)
where ϕis defined in (9.14) and θ= [θ0, . . . , θ K−1]⊤∈RKcontains the
(linear) parameters θk.
Let us now have a look at maximum likelihood estimation of the param-
etersθin the linear regression model (9.13). We consider training inputs
xn∈RDand targets yn∈R,n= 1, . . . , N , and define the feature matrix feature matrix
(design matrix ) as design matrix
Φ:=
ϕ⊤(x1)
...
ϕ⊤(xN)
=
ϕ0(x1)··· ϕK−1(x1)
ϕ0(x2)··· ϕK−1(x2)
......
ϕ0(xN)···ϕK−1(xN)
∈RN×K,(9.16)
where Φij=ϕj(xi)andϕj:RD→R.
Example 9.4 (Feature Matrix for Second-order Polynomials)
For a second-order polynomial and Ntraining points xn∈R, n=
1, . . . , N , the feature matrix is
Φ=
1x1x2
1
1x2x2
2.........
1xNx2
N
. (9.17)
With the feature matrix Φdefined in (9.16), the negative log-likelihood
for the linear regression model (9.13) can be written as
−logp(Y |X ,θ) =1
2σ2(y−Φθ)⊤(y−Φθ) +const . (9.18)
Comparing (9.18) with the negative log-likelihood in (9.10b) for the “fea-
ture-free” model, we immediately see we just need to replace XwithΦ.
Since both XandΦare independent of the parameters θthat we wish to
optimize, we arrive immediately at the maximum likelihood estimate maximum likelihood
estimate
θML= (Φ⊤Φ)−1Φ⊤y (9.19)
for the linear regression problem with nonlinear features defined in (9.13).
Remark. When we were working without features, we required X⊤Xto
be invertible, which is the case when rk(X) =D, i.e., the columns of X
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
9.2 Parameter Estimation 297
are linearly independent. In (9.19), we therefore require Φ⊤Φ∈RK×K
to be invertible. This is the case if and only if rk(Φ) =K. ♢
Example 9.5 (Maximum Likelihood Polynomial Fit)
Figure 9.4
Polynomial
regression:
(a) dataset
consisting of
(xn, yn)pairs,
n= 1, . . . , 10;
(b) maximum
likelihood
polynomial of
degree 4.
−4−2 0 2 4
x−4−2024y
(a) Regression dataset.
−4−2 0 2 4
x−4−2024y
Training data
MLE (b) Polynomial of degree 4 determined by max-
imum likelihood estimation.
Consider the dataset in Figure 9.4(a). The dataset consists of N= 10
pairs (xn, yn), where xn∼ U[−5,5]andyn=−sin(xn/5) + cos( xn) +ϵ,
where ϵ∼ N 0,0.22
.
We fit a polynomial of degree 4using maximum likelihood estimation,
i.e., parameters θMLare given in (9.19). The maximum likelihood estimate
yields function values ϕ⊤(x∗)θMLat any test location x∗. The result is
shown in Figure 9.4(b).
Estimating the Noise Variance
Thus far, we assumed that the noise variance σ2is known. However, we
can also use the principle of maximum likelihood estimation to obtain the
maximum likelihood estimator σ2
MLfor the noise variance. To do this, we
follow the standard procedure: We write down the log-likelihood, com-
pute its derivative with respect to σ2>0, set it to 0, and solve. The
log-likelihood is given by
logp(Y |X ,θ, σ2) =NX
n=1logN yn|ϕ⊤(xn)θ, σ2
(9.20a)
=NX
n=1
−1
2log(2π)−1
2logσ2−1
2σ2(yn−ϕ⊤(xn)θ)2
(9.20b)
=−N
2logσ2−1
2σ2NX
n=1(yn−ϕ⊤(xn)θ)2
| {z }
=:s+const . (9.20c)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
298 Linear Regression
The partial derivative of the log-likelihood with respect to σ2is then
∂logp(Y |X ,θ, σ2)
∂σ2=−N
2σ2+1
2σ4s= 0 (9.21a)
⇐⇒N
2σ2=s
2σ4(9.21b)
so that we identify
σ2
ML=s
N=1
NNX
n=1(yn−ϕ⊤(xn)θ)2. (9.22)
Therefore, the maximum likelihood estimate of the noise variance is the
empirical mean of the squared distances between the noise-free function
values ϕ⊤(xn)θand the corresponding noisy observations ynat input lo-
cations xn.
9.2.2 Overfitting in Linear Regression
We just discussed how to use maximum likelihood estimation to fit lin-
ear models (e.g., polynomials) to data. We can evaluate the quality of
the model by computing the error/loss incurred. One way of doing this
is to compute the negative log-likelihood (9.10b), which we minimized
to determine the maximum likelihood estimator. Alternatively, given that
the noise parameter σ2is not a free model parameter, we can ignore the
scaling by 1/σ2, so that we end up with a squared-error-loss function
∥y−Φθ∥2. Instead of using this squared loss, we often use the root mean root mean square
error square error (RMSE )
RMSEr
1
N∥y−Φθ∥2=vuut1
NNX
n=1(yn−ϕ⊤(xn)θ)2, (9.23)
which (a) allows us to compare errors of datasets with different sizes
and (b) has the same scale and the same units as the observed func- The RMSE is
normalized. tion values yn. For example, if we fit a model that maps post-codes ( x
is given in latitude, longitude) to house prices ( y-values are EUR) then
the RMSE is also measured in EUR, whereas the squared error is given
in EUR2. If we choose to include the factor σ2from the original negative The negative
log-likelihood is
unitless.log-likelihood (9.10b), then we end up with a unitless objective, i.e., in
the preceding example, our objective would no longer be in EUR or EUR2.
For model selection (see Section 8.6), we can use the RMSE (or the
negative log-likelihood) to determine the best degree of the polynomial by
finding the polynomial degree Mthat minimizes the objective. Given that
the polynomial degree is a natural number, we can perform a brute-force
search and enumerate all (reasonable) values of M. For a training set of
sizeNit is sufficient to test 0⩽M⩽N−1. ForM < N , the maximum
likelihood estimator is unique. For M⩾N, we have more parameters
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
9.2 Parameter Estimation 299
Figure 9.5
Maximum
likelihood fits for
different polynomial
degrees M.
−4−2 0 2 4
x−4−2024y
Training data
MLE
(a)M= 0
−4−2 0 2 4
x−4−2024y
Training data
MLE (b)M= 1
−4−2 0 2 4
x−4−2024y
Training data
MLE (c)M= 3
−4−2 0 2 4
x−4−2024y
Training data
MLE
(d)M= 4
−4−2 0 2 4
x−4−2024y
Training data
MLE (e)M= 6
−4−2 0 2 4
x−4−2024y
Training data
MLE (f)M= 9
than data points, and would need to solve an underdetermined system of
linear equations ( Φ⊤Φin (9.19) would also no longer be invertible) so
that there are infinitely many possible maximum likelihood estimators.
Figure 9.5 shows a number of polynomial fits determined by maximum
likelihood for the dataset from Figure 9.4(a) with N= 10 observations.
We notice that polynomials of low degree (e.g., constants ( M= 0) or
linear ( M= 1)) fit the data poorly and, hence, are poor representations
of the true underlying function. For degrees M= 3, . . . , 6, the fits look
plausible and smoothly interpolate the data. When we go to higher-degree The case of
M=N−1is
extreme in the sense
that otherwise the
null space of the
corresponding
system of linear
equations would be
non-trivial, and we
would have
infinitely many
optimal solutions to
the linear regression
problem.polynomials, we notice that they fit the data better and better. In the ex-
treme case of M=N−1 = 9 , the function will pass through every single
data point. However, these high-degree polynomials oscillate wildly and
are a poor representation of the underlying function that generated the
data, such that we suffer from overfitting .
overfitting
Note that the noise
variance σ2>0.Remember that the goal is to achieve good generalization by making
accurate predictions for new (unseen) data. We obtain some quantita-
tive insight into the dependence of the generalization performance on the
polynomial of degree Mby considering a separate test set comprising 200
data points generated using exactly the same procedure used to generate
the training set. As test inputs, we chose a linear grid of 200points in the
interval of [−5,5]. For each choice of M, we evaluate the RMSE (9.23) for
both the training data and the test data.
Looking now at the test error, which is a qualitive measure of the gen-
eralization properties of the corresponding polynomial, we notice that ini-
tially the test error decreases; see Figure 9.6 (orange). For fourth-order
polynomials, the test error is relatively low and stays relatively constant up
to degree 5. However, from degree 6onward the test error increases signif-
icantly, and high-order polynomials have very bad generalization proper-
ties. In this particular example, this also is evident from the corresponding
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
300 Linear Regression
Figure 9.6 Training
and test error.
0 2 4 6 8 10
Degree of polynomial0246810RMSETraining error
Test error
maximum likelihood fits in Figure 9.5. Note that the training error (blue training error
curve in Figure 9.6) never increases when the degree of the polynomial in-
creases. In our example, the best generalization (the point of the smallest
test error ) is obtained for a polynomial of degree M= 4. test error
9.2.3 Maximum A Posteriori Estimation
We just saw that maximum likelihood estimation is prone to overfitting.
We often observe that the magnitude of the parameter values becomes
relatively large if we run into overfitting (Bishop, 2006).
To mitigate the effect of huge parameter values, we can place a prior
distribution p(θ)on the parameters. The prior distribution explicitly en-
codes what parameter values are plausible (before having seen any data).
For example, a Gaussian prior p(θ) =N 0,1
on a single parameter
θencodes that parameter values are expected lie in the interval [−2,2]
(two standard deviations around the mean value). Once a dataset X,Y
is available, instead of maximizing the likelihood we seek parameters that
maximize the posterior distribution p(θ|X,Y). This procedure is called
maximum a posteriori (MAP) estimation. maximum a
posteriori
MAPThe posterior over the parameters θ, given the training data X,Y, is
obtained by applying Bayes’ theorem (Section 6.3) as
p(θ|X,Y) =p(Y |X ,θ)p(θ)
p(Y |X ). (9.24)
Since the posterior explicitly depends on the parameter prior p(θ), the
prior will have an effect on the parameter vector we find as the maximizer
of the posterior. We will see this more explicitly in the following. The
parameter vector θMAPthat maximizes the posterior (9.24) is the MAP
estimate.
To find the MAP estimate, we follow steps that are similar in flavor
to maximum likelihood estimation. We start with the log-transform and
compute the log-posterior as
logp(θ|X,Y) = log p(Y |X ,θ) + log p(θ) +const , (9.25)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
9.2 Parameter Estimation 301
where the constant comprises the terms that are independent of θ. We see
that the log-posterior in (9.25) is the sum of the log-likelihood p(Y |X ,θ)
and the log-prior logp(θ)so that the MAP estimate will be a “compromise”
between the prior (our suggestion for plausible parameter values before
observing data) and the data-dependent likelihood.
To find the MAP estimate θMAP, we minimize the negative log-posterior
distribution with respect to θ, i.e., we solve
θMAP∈arg min
θ{−logp(Y |X ,θ)−logp(θ)}. (9.26)
The gradient of the negative log-posterior with respect to θis
−d logp(θ|X,Y)
dθ=−d logp(Y |X ,θ)
dθ−d logp(θ)
dθ, (9.27)
where we identify the first term on the right-hand side as the gradient of
the negative log-likelihood from (9.11c).
With a (conjugate) Gaussian prior p(θ) =N 0, b2I
on the parameters
θ, the negative log-posterior for the linear regression setting (9.13), we
obtain the negative log posterior
−logp(θ|X,Y) =1
2σ2(y−Φθ)⊤(y−Φθ) +1
2b2θ⊤θ+const .(9.28)
Here, the first term corresponds to the contribution from the log-likelihood,
and the second term originates from the log-prior. The gradient of the log-
posterior with respect to the parameters θis then
−d logp(θ|X,Y)
dθ=1
σ2(θ⊤Φ⊤Φ−y⊤Φ) +1
b2θ⊤. (9.29)
We will find the MAP estimate θMAPby setting this gradient to 0⊤and
solving for θMAP. We obtain
1
σ2(θ⊤Φ⊤Φ−y⊤Φ) +1
b2θ⊤=0⊤(9.30a)
⇐⇒θ⊤1
σ2Φ⊤Φ+1
b2I
−1
σ2y⊤Φ=0⊤(9.30b)
⇐⇒θ⊤
Φ⊤Φ+σ2
b2I
=y⊤Φ (9.30c)
⇐⇒θ⊤=y⊤Φ
Φ⊤Φ+σ2
b2I−1
(9.30d)
so that the MAP estimate is (by transposing both sides of the last equality) Φ⊤Φis symmetric,
positive semi
definite. The
additional term
in (9.31) is strictly
positive definite so
that the inverse
exists.θMAP=
Φ⊤Φ+σ2
b2I−1
Φ⊤y. (9.31)
Comparing the MAP estimate in (9.31) with the maximum likelihood es-
timate in (9.19), we see that the only difference between both solutions
is the additional termσ2
b2Iin the inverse matrix. This term ensures that
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
302 Linear Regression
Φ⊤Φ+σ2
b2Iis symmetric and strictly positive definite (i.e., its inverse
exists and the MAP estimate is the unique solution of a system of linear
equations). Moreover, it reflects the impact of the regularizer.
Example 9.6 (MAP Estimation for Polynomial Regression)
In the polynomial regression example from Section 9.2.1, we place a Gaus-
sian prior p(θ) =N 0,I
on the parameters θand determine the MAP
estimates according to (9.31). In Figure 9.7, we show both the maximum
likelihood and the MAP estimates for polynomials of degree 6(left) and
degree 8(right). The prior (regularizer) does not play a significant role
for the low-degree polynomial, but keeps the function relatively smooth
for higher-degree polynomials. Although the MAP estimate can push the
boundaries of overfitting, it is not a general solution to this problem, so
we need a more principled approach to tackle overfitting.
Figure 9.7
Polynomial
regression:
maximum likelihood
and MAP estimates.
(a) Polynomials of
degree 6;
(b) polynomials of
degree 8.
−4−2 0 2 4
x−4−2024y
Training data
MLE
MAP
(a) Polynomials of degree 6.
−4−2 0 2 4
x−4−2024y
Training data
MLE
MAP (b) Polynomials of degree 8.
9.2.4 MAP Estimation as Regularization
Instead of placing a prior distribution on the parameters θ, it is also pos-
sible to mitigate the effect of overfitting by penalizing the amplitude of
the parameter by means of regularization . Inregularized least squares , we regularization
regularized least
squaresconsider the loss function
∥y−Φθ∥2+λ∥θ∥2
2, (9.32)
which we minimize with respect to θ(see Section 8.2.3). Here, the first
term is a data-fit term (also called misfit term ), which is proportional to data-fit term
misfit term the negative log-likelihood; see (9.10b). The second term is called the
regularizer , and the regularization parameter λ⩾0controls the “strict- regularizer
regularization
parameterness” of the regularization.
Remark. Instead of the Euclidean norm ∥·∥2, we can choose any p-norm
∥·∥pin (9.32). In practice, smaller values for plead to sparser solutions.
Here, “sparse” means that many parameter values θd= 0, which is also
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
9.3 Bayesian Linear Regression 303
useful for variable selection. For p= 1, the regularizer is called LASSO LASSO
(least absolute shrinkage and selection operator) and was proposed by Tib-
shirani (1996). ♢
The regularizer λ∥θ∥2
2in (9.32) can be interpreted as a negative log-
Gaussian prior, which we use in MAP estimation; see (9.26). More specif-
ically, with a Gaussian prior p(θ) =N 0, b2I
, we obtain the negative
log-Gaussian prior
−logp(θ) =1
2b2∥θ∥2
2+const (9.33)
so that for λ=1
2b2the regularization term and the negative log-Gaussian
prior are identical.
Given that the regularized least-squares loss function in (9.32) consists
of terms that are closely related to the negative log-likelihood plus a neg-
ative log-prior, it is not surprising that, when we minimize this loss, we
obtain a solution that closely resembles the MAP estimate in (9.31). More
specifically, minimizing the regularized least-squares loss function yields
θRLS= (Φ⊤Φ+λI)−1Φ⊤y, (9.34)
which is identical to the MAP estimate in (9.31) for λ=σ2
b2, where σ2is
the noise variance and b2the variance of the (isotropic) Gaussian prior
p(θ) =N 0, b2I
. A point estimate is a
single specific
parameter value,
unlike a distribution
over plausible
parameter settings.So far, we have covered parameter estimation using maximum likeli-
hood and MAP estimation where we found point estimates θ∗that op-
timize an objective function (likelihood or posterior). We saw that both
maximum likelihood and MAP estimation can lead to overfitting. In the
next section, we will discuss Bayesian linear regression, where we use
Bayesian inference (Section 8.4) to find a posterior distribution over the
unknown parameters, which we subsequently use to make predictions.
More specifically, for predictions we will average over all plausible sets of
parameters instead of focusing on a point estimate.
9.3 Bayesian Linear Regression
Previously, we looked at linear regression models where we estimated the
model parameters θ, e.g., by means of maximum likelihood or MAP esti-
mation. We discovered that MLE can lead to severe overfitting, in particu-
lar, in the small-data regime. MAP addresses this issue by placing a prior
on the parameters that plays the role of a regularizer. Bayesian linear
regression Bayesian linear regression pushes the idea of the parameter prior a step
further and does not even attempt to compute a point estimate of the
parameters, but instead the full posterior distribution over the parameters
is taken into account when making predictions. This means we do not fit
any parameters, but we compute a mean over all plausible parameters
settings (according to the posterior).
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
304 Linear Regression
9.3.1 Model
In Bayesian linear regression, we consider the model
prior p(θ) =N m0,S0,
likelihood p(y|x,θ) =N y|ϕ⊤(x)θ, σ2,(9.35)
where we now explicitly place a Gaussian prior p(θ) =N m0,S0
onθ, Figure 9.8
Graphical model for
Bayesian linear
regression.
θ
yσ
xm0 S0which turns the parameter vector into a random variable. This allows us
to write down the corresponding graphical model in Figure 9.8, where we
made the parameters of the Gaussian prior on θexplicit. The full proba-
bilistic model, i.e., the joint distribution of observed and unobserved ran-
dom variables, yandθ, respectively, is
p(y,θ|x) =p(y|x,θ)p(θ). (9.36)
9.3.2 Prior Predictions
In practice, we are usually not so much interested in the parameter values
θthemselves. Instead, our focus often lies in the predictions we make
with those parameter values. In a Bayesian setting, we take the parameter
distribution and average over all plausible parameter settings when we
make predictions. More specifically, to make predictions at an input x∗,
we integrate out θand obtain
p(y∗|x∗) =Z
p(y∗|x∗,θ)p(θ)dθ=Eθ[p(y∗|x∗,θ)], (9.37)
which we can interpret as the average prediction of y∗|x∗,θfor all plau-
sible parameters θaccording to the prior distribution p(θ). Note that pre-
dictions using the prior distribution only require us to specify the input
x∗, but no training data.
In our model (9.35), we chose a conjugate (Gaussian) prior on θso
that the predictive distribution is Gaussian as well (and can be computed
in closed form): With the prior distribution p(θ) =N m0,S0
, we obtain
the predictive distribution as
p(y∗|x∗) =N ϕ⊤(x∗)m0,ϕ⊤(x∗)S0ϕ(x∗) +σ2, (9.38)
where we exploited that (i) the prediction is Gaussian due to conjugacy
(see Section 6.6) and the marginalization property of Gaussians (see Sec-
tion 6.5), (ii) the Gaussian noise is independent so that
V[y∗] =Vθ[ϕ⊤(x∗)θ] +Vϵ[ϵ], (9.39)
and (iii) y∗is a linear transformation of θso that we can apply the rules
for computing the mean and covariance of the prediction analytically by
using (6.50) and (6.51), respectively. In (9.38), the term ϕ⊤(x∗)S0ϕ(x∗)
in the predictive variance explicitly accounts for the uncertainty associated
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
9.3 Bayesian Linear Regression 305
with the parameters θ, whereas σ2is the uncertainty contribution due to
the measurement noise.
If we are interested in predicting noise-free function values f(x∗) =
ϕ⊤(x∗)θinstead of the noise-corrupted targets y∗we obtain
p(f(x∗)) =N ϕ⊤(x∗)m0,ϕ⊤(x∗)S0ϕ(x∗), (9.40)
which only differs from (9.38) in the omission of the noise variance σ2in
the predictive variance.
Remark (Distribution over Functions) .Since we can represent the distri- The parameter
distribution p(θ)
induces a
distribution over
functions.bution p(θ)using a set of samples θiand every sample θigives rise to a
function fi(·) =θ⊤
iϕ(·), it follows that the parameter distribution p(θ)
induces a distribution p(f(·))over functions. Here we use the notation (·)
to explicitly denote a functional relationship. ♢
Example 9.7 (Prior over Functions)
Figure 9.9 Prior
over functions.
(a) Distribution over
functions
represented by the
mean function
(black line) and the
marginal
uncertainties
(shaded),
representing the
67% and 95%
confidence bounds,
respectively;
(b) samples from
the prior over
functions, which are
induced by the
samples from the
parameter prior.
−4−2 0 2 4
x−4−2024y(a) Prior distribution over functions.
−4−2 0 2 4
x−4−2024y (b) Samples from the prior distribution over
functions.
Let us consider a Bayesian linear regression problem with polynomials
of degree 5. We choose a parameter prior p(θ) =N 0,1
4I
. Figure 9.9
visualizes the induced prior distribution over functions (shaded area: dark
gray: 67% confidence bound; light gray: 95% confidence bound) induced
by this parameter prior, including some function samples from this prior.
A function sample is obtained by first sampling a parameter vector
θi∼p(θ)and then computing fi(·) =θ⊤
iϕ(·). We used 200input lo-
cations x∗∈[−5,5]to which we apply the feature function ϕ(·). The
uncertainty (represented by the shaded area) in Figure 9.9 is solely due to
the parameter uncertainty because we considered the noise-free predictive
distribution (9.40).
So far, we looked at computing predictions using the parameter prior
p(θ). However, when we have a parameter posterior (given some train-
ing data X,Y), the same principles for prediction and inference hold
as in (9.37) – we just need to replace the prior p(θ)with the posterior
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
306 Linear Regression
p(θ|X,Y). In the following, we will derive the posterior distribution in
detail before using it to make predictions.
9.3.3 Posterior Distribution
Given a training set of inputs xn∈RDand corresponding observations
yn∈R,n= 1, . . . , N , we compute the posterior over the parameters
using Bayes’ theorem as
p(θ|X,Y) =p(Y |X ,θ)p(θ)
p(Y |X ), (9.41)
where Xis the set of training inputs and Ythe collection of correspond-
ing training targets. Furthermore, p(Y |X ,θ)is the likelihood, p(θ)the
parameter prior, and
p(Y |X ) =Z
p(Y |X ,θ)p(θ)dθ=Eθ[p(Y |X ,θ)] (9.42)
themarginal likelihood /evidence , which is independent of the parameters marginal likelihood
evidence θand ensures that the posterior is normalized, i.e., it integrates to 1. We
The marginal
likelihood is the
expected likelihood
under the parameter
prior.can think of the marginal likelihood as the likelihood averaged over all
possible parameter settings (with respect to the prior distribution p(θ)).
Theorem 9.1 (Parameter Posterior) .In our model (9.35) , the parameter
posterior (9.41) can be computed in closed form as
p(θ|X,Y) =N θ|mN,SN, (9.43a)
SN= (S−1
0+σ−2Φ⊤Φ)−1, (9.43b)
mN=SN(S−1
0m0+σ−2Φ⊤y), (9.43c)
where the subscript Nindicates the size of the training set.
Proof Bayes’ theorem tells us that the posterior p(θ|X,Y)is propor-
tional to the product of the likelihood p(Y |X ,θ)and the prior p(θ):
Posterior p(θ|X,Y) =p(Y |X ,θ)p(θ)
p(Y |X )(9.44a)
Likelihood p(Y |X ,θ) =N y|Φθ, σ2I
(9.44b)
Prior p(θ) =N θ|m0,S0. (9.44c)
Instead of looking at the product of the prior and the likelihood, we
can transform the problem into log-space and solve for the mean and
covariance of the posterior by completing the squares.
The sum of the log-prior and the log-likelihood is
logN y|Φθ, σ2I+ logN θ|m0,S0
(9.45a)
=−1
2 σ−2(y−Φθ)⊤(y−Φθ) + (θ−m0)⊤S−1
0(θ−m0)+const
(9.45b)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
9.3 Bayesian Linear Regression 307
where the constant contains terms independent of θ. We will ignore the
constant in the following. We now factorize (9.45b), which yields
−1
2 σ−2y⊤y−2σ−2y⊤Φθ+θ⊤σ−2Φ⊤Φθ+θ⊤S−1
0θ
−2m⊤
0S−1
0θ+m⊤
0S−1
0m0(9.46a)
=−1
2 θ⊤(σ−2Φ⊤Φ+S−1
0)θ−2(σ−2Φ⊤y+S−1
0m0)⊤θ+const ,
(9.46b)
where the constant contains the black terms in (9.46a), which are inde-
pendent of θ. The orange terms are terms that are linear in θ, and the
blue terms are the ones that are quadratic in θ. Inspecting (9.46b), we
find that this equation is quadratic in θ. The fact that the unnormalized
log-posterior distribution is a (negative) quadratic form implies that the
posterior is Gaussian, i.e.,
p(θ|X,Y) = exp(log p(θ|X,Y))∝exp(log p(Y |X ,θ) + log p(θ))
(9.47a)
∝exp
−1
2 θ⊤(σ−2Φ⊤Φ+S−1
0)θ−2(σ−2Φ⊤y+S−1
0m0)⊤θ
,
(9.47b)
where we used (9.46b) in the last expression.
The remaining task is it to bring this (unnormalized) Gaussian into the
form that is proportional to N θ|mN,SN
, i.e., we need to identify the
mean mNand the covariance matrix SN. To do this, we use the concept
ofcompleting the squares . The desired log-posterior is completing the
squares
logN θ|mN,SN=−1
2(θ−mN)⊤S−1
N(θ−mN) +const (9.48a)
=−1
2 θ⊤S−1
Nθ−2m⊤
NS−1
Nθ+m⊤
NS−1
NmN. (9.48b)
Here, we factorized the quadratic form (θ−mN)⊤S−1
N(θ−mN)into a Since p(θ|X,Y) =
N 
mN,SN
, it
holds that
θMAP=mN.term that is quadratic in θalone (blue), a term that is linear in θ(orange),
and a constant term (black). This allows us now to find SNandmNby
matching the colored expressions in (9.46b) and (9.48b), which yields
S−1
N=Φ⊤σ−2IΦ+S−1
0 (9.49a)
⇐⇒SN= (σ−2Φ⊤Φ+S−1
0)−1(9.49b)
and
m⊤
NS−1
N= (σ−2Φ⊤y+S−1
0m0)⊤(9.50a)
⇐⇒mN=SN(σ−2Φ⊤y+S−1
0m0). (9.50b)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
308 Linear Regression
Remark (General Approach to Completing the Squares) .If we are given
an equation
x⊤Ax−2a⊤x+const 1, (9.51)
where Ais symmetric and positive definite, which we wish to bring into
the form
(x−µ)⊤Σ(x−µ) +const 2, (9.52)
we can do this by setting
Σ:=A, (9.53)
µ:=Σ−1a (9.54)
and const 2=const 1−µ⊤Σµ. ♢
We can see that the terms inside the exponential in (9.47b) are of the
form (9.51) with
A:=σ−2Φ⊤Φ+S−1
0, (9.55)
a:=σ−2Φ⊤y+S−1
0m0. (9.56)
Since A,acan be difficult to identify in equations like (9.46a), it is of-
ten helpful to bring these equations into the form (9.51) that decouples
quadratic term, linear terms, and constants, which simplifies finding the
desired solution.
9.3.4 Posterior Predictions
In (9.37), we computed the predictive distribution of y∗at a test input
x∗using the parameter prior p(θ). In principle, predicting with the pa-
rameter posterior p(θ|X,Y)is not fundamentally different given that
in our conjugate model the prior and posterior are both Gaussian (with
different parameters). Therefore, by following the same reasoning as in
Section 9.3.2, we obtain the (posterior) predictive distribution
p(y∗|X,Y,x∗) =Z
p(y∗|x∗,θ)p(θ|X,Y)dθ (9.57a)
=Z
N y∗|ϕ⊤(x∗)θ, σ2N θ|mN,SNdθ(9.57b)
=N y∗|ϕ⊤(x∗)mN,ϕ⊤(x∗)SNϕ(x∗) +σ2.(9.57c)
The term ϕ⊤(x∗)SNϕ(x∗)reflects the posterior uncertainty associated E[y∗|X,Y,x∗] =
ϕ⊤(x∗)mN=
ϕ⊤(x∗)θMAP.with the parameters θ. Note that SNdepends on the training inputs
through Φ; see (9.43b). The predictive mean ϕ⊤(x∗)mNcoincides with
the predictions made with the MAP estimate θMAP.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
9.3 Bayesian Linear Regression 309
Remark (Marginal Likelihood and Posterior Predictive Distribution) .By
replacing the integral in (9.57a), the predictive distribution can be equiv-
alently written as the expectation Eθ|X,Y[p(y∗|x∗,θ)], where the expec-
tation is taken with respect to the parameter posterior p(θ|X,Y).
Writing the posterior predictive distribution in this way highlights a
close resemblance to the marginal likelihood (9.42). The key difference
between the marginal likelihood and the posterior predictive distribution
are (i) the marginal likelihood can be thought of predicting the training
targets yand not the test targets y∗, and (ii) the marginal likelihood av-
erages with respect to the parameter prior and not the parameter poste-
rior. ♢
Remark (Mean and Variance of Noise-Free Function Values) .In many
cases, we are not interested in the predictive distribution p(y∗|X,Y,x∗)
of a (noisy) observation y∗. Instead, we would like to obtain the distribu-
tion of the (noise-free) function values f(x∗) =ϕ⊤(x∗)θ. We determine
the corresponding moments by exploiting the properties of means and
variances, which yields
E[f(x∗)|X,Y] =Eθ[ϕ⊤(x∗)θ|X,Y] =ϕ⊤(x∗)Eθ[θ|X,Y]
=ϕ⊤(x∗)mN=m⊤
Nϕ(x∗),(9.58)
Vθ[f(x∗)|X,Y] =Vθ[ϕ⊤(x∗)θ|X,Y]
=ϕ⊤(x∗)Vθ[θ|X,Y]ϕ(x∗)
=ϕ⊤(x∗)SNϕ(x∗).(9.59)
We see that the predictive mean is the same as the predictive mean for
noisy observations as the noise has mean 0, and the predictive variance
only differs by σ2, which is the variance of the measurement noise: When
we predict noisy function values, we need to include σ2as a source of
uncertainty, but this term is not needed for noise-free predictions. Here,
the only remaining uncertainty stems from the parameter posterior. ♢Integrating out
parameters induces
a distribution over
functions.Remark (Distribution over Functions) .The fact that we integrate out the
parameters θinduces a distribution over functions: If we sample θi∼
p(θ|X,Y)from the parameter posterior, we obtain a single function re-
alization θ⊤
iϕ(·). The mean function , i.e., the set of all expected function mean function
values Eθ[f(·)|θ,X,Y], of this distribution over functions is m⊤
Nϕ(·).
The (marginal) variance, i.e., the variance of the function f(·), is given by
ϕ⊤(·)SNϕ(·). ♢
Example 9.8 (Posterior over Functions)
Let us revisit the Bayesian linear regression problem with polynomials
of degree 5. We choose a parameter prior p(θ) =N 0,1
4I
. Figure 9.9
visualizes the prior over functions induced by the parameter prior and
sample functions from this prior.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
310 Linear Regression
Figure 9.10 shows the posterior over functions that we obtain via
Bayesian linear regression. The training dataset is shown in panel (a);
panel (b) shows the posterior distribution over functions, including the
functions we would obtain via maximum likelihood and MAP estimation.
The function we obtain using the MAP estimate also corresponds to the
posterior mean function in the Bayesian linear regression setting. Panel (c)
shows some plausible realizations (samples) of functions under that pos-
terior over functions.
Figure 9.10
Bayesian linear
regression and
posterior over
functions.
(a) training data;
(b) posterior
distribution over
functions;
(c) Samples from
the posterior over
functions.
−4−2 0 2 4
x−4−2024y
(a) Training data.
−4−2 0 2 4
x−4−2024y
Training data
MLE
MAP
BLR (b) Posterior over functions rep-
resented by the marginal uncer-
tainties (shaded) showing the
67% and 95% predictive con-
fidence bounds, the maximum
likelihood estimate (MLE) and
the MAP estimate (MAP), the
latter of which is identical to
the posterior mean function.
−4−2 0 2 4
x−4−2024y
(c) Samples from the posterior
over functions, which are in-
duced by the samples from the
parameter posterior.
Figure 9.11 shows some posterior distributions over functions induced
by the parameter posterior. For different polynomial degrees M, the left
panels show the maximum likelihood function θ⊤
MLϕ(·), the MAP func-
tionθ⊤
MAPϕ(·)(which is identical to the posterior mean function), and the
67% and 95% predictive confidence bounds obtained by Bayesian linear
regression, represented by the shaded areas.
The right panels show samples from the posterior over functions: Here,
we sampled parameters θifrom the parameter posterior and computed
the function ϕ⊤(x∗)θi, which is a single realization of a function under
the posterior distribution over functions. For low-order polynomials, the
parameter posterior does not allow the parameters to vary much: The
sampled functions are nearly identical. When we make the model more
flexible by adding more parameters (i.e., we end up with a higher-order
polynomial), these parameters are not sufficiently constrained by the pos-
terior, and the sampled functions can be easily visually separated. We also
see in the corresponding panels on the left how the uncertainty increases,
especially at the boundaries.
Although for a seventh-order polynomial the MAP estimate yields a rea-
sonable fit, the Bayesian linear regression model additionally tells us that
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
9.3 Bayesian Linear Regression 311
Figure 9.11
Bayesian linear
regression. Left
panels: Shaded
areas indicate the
67% (dark gray)
and 95% (light
gray) predictive
confidence bounds.
The mean of the
Bayesian linear
regression model
coincides with the
MAP estimate. The
predictive
uncertainty is the
sum of the noise
term and the
posterior parameter
uncertainty, which
depends on the
location of the test
input. Right panels:
sampled functions
from the posterior
distribution.
−4−2 0 2 4
x−4−2024y
Training data
MLE
MAP
BLR
−4−2 0 2 4
x−4−2024y
(a) Posterior distribution for polynomials of degree M= 3(left) and samples from the pos-
terior over functions (right).
−4−2 0 2 4
x−4−2024y
Training data
MLE
MAP
BLR
−4−2 0 2 4
x−4−2024y
(b) Posterior distribution for polynomials of degree M= 5 (left) and samples from the
posterior over functions (right).
−4−2 0 2 4
x−4−2024y
Training data
MLE
MAP
BLR
−4−2 0 2 4
x−4−2024y
(c) Posterior distribution for polynomials of degree M= 7(left) and samples from the pos-
terior over functions (right).
the posterior uncertainty is huge. This information can be critical when
we use these predictions in a decision-making system, where bad deci-
sions can have significant consequences (e.g., in reinforcement learning
or robotics).
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
312 Linear Regression
9.3.5 Computing the Marginal Likelihood
In Section 8.6.2, we highlighted the importance of the marginal likelihood
for Bayesian model selection. In the following, we compute the marginal
likelihood for Bayesian linear regression with a conjugate Gaussian prior
on the parameters, i.e., exactly the setting we have been discussing in this
chapter.
Just to recap, we consider the following generative process:
θ∼ N m0,S0
(9.60a)
yn|xn,θ∼ N x⊤
nθ, σ2, (9.60b)
n= 1, . . . , N . The marginal likelihood is given by The marginal
likelihood can be
interpreted as the
expected likelihood
under the prior, i.e.,
Eθ[p(Y |X ,θ)].p(Y |X ) =Z
p(Y |X ,θ)p(θ)dθ (9.61a)
=Z
N y|Xθ, σ2IN θ|m0,S0dθ, (9.61b)
where we integrate out the model parameters θ. We compute the marginal
likelihood in two steps: First, we show that the marginal likelihood is
Gaussian (as a distribution in y); second, we compute the mean and co-
variance of this Gaussian.
1. The marginal likelihood is Gaussian: From Section 6.5.2, we know that
(i) the product of two Gaussian random variables is an (unnormalized)
Gaussian distribution, and (ii) a linear transformation of a Gaussian
random variable is Gaussian distributed. In (9.61b), we require a linear
transformation to bring N y|Xθ, σ2I
into the form N θ|µ,Σ
for
someµ,Σ. Once this is done, the integral can be solved in closed form.
The result is the normalizing constant of the product of the two Gaus-
sians. The normalizing constant itself has Gaussian shape; see (6.76).
2. Mean and covariance. We compute the mean and covariance matrix
of the marginal likelihood by exploiting the standard results for means
and covariances of affine transformations of random variables; see Sec-
tion 6.4.4. The mean of the marginal likelihood is computed as
E[Y |X ] =Eθ,ϵ[Xθ+ϵ] =XEθ[θ] =Xm 0. (9.62)
Note that ϵ∼ N 0, σ2I
is a vector of i.i.d. random variables. The
covariance matrix is given as
Cov[Y|X] = Cov θ,ϵ[Xθ+ϵ] = Cov θ[Xθ] +σ2I (9.63a)
=XCovθ[θ]X⊤+σ2I=XS 0X⊤+σ2I.(9.63b)
Hence, the marginal likelihood is
p(Y |X ) = (2 π)−N
2det(XS 0X⊤+σ2I)−1
2 (9.64a)
·exp −1
2(y−Xm 0)⊤(XS 0X⊤+σ2I)−1(y−Xm 0)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
9.4 Maximum Likelihood as Orthogonal Projection 313
Figure 9.12
Geometric
interpretation of
least squares.
(a) Dataset;
(b) maximum
likelihood solution
interpreted as a
projection.
−4−2 0 2 4
x−4−2024y
(a) Regression dataset consisting of noisy ob-
servations yn(blue) of function values f(xn)
at input locations xn.
−4−2 0 2 4
x−4−2024y
Projection
Observations
Maximum likelihood estimate(b) The orange dots are the projections of
the noisy observations (blue dots) onto the
lineθMLx. The maximum likelihood solution to
a linear regression problem finds a subspace
(line) onto which the overall projection er-
ror (orange lines) of the observations is mini-
mized.
=N y|Xm 0,XS 0X⊤+σ2I. (9.64b)
Given the close connection with the posterior predictive distribution (see
Remark on Marginal Likelihood and Posterior Predictive Distribution ear-
lier in this section), the functional form of the marginal likelihood should
not be too surprising.
9.4 Maximum Likelihood as Orthogonal Projection
Having crunched through much algebra to derive maximum likelihood
and MAP estimates, we will now provide a geometric interpretation of
maximum likelihood estimation. Let us consider a simple linear regression
setting
y=xθ+ϵ, ϵ∼ N 0, σ2, (9.65)
in which we consider linear functions f:R→Rthat go through the
origin (we omit features here for clarity). The parameter θdetermines the
slope of the line. Figure 9.12(a) shows a one-dimensional dataset.
With a training data set {(x1, y1), . . . , (xN, yN)}we recall the results
from Section 9.2.1 and obtain the maximum likelihood estimator for the
slope parameter as
θML= (X⊤X)−1X⊤y=X⊤y
X⊤X∈R, (9.66)
where X= [x1, . . . , x N]⊤∈RN,y= [y1, . . . , y N]⊤∈RN.
This means for the training inputs Xwe obtain the optimal (maximum
likelihood) reconstruction of the training targets as
XθML=XX⊤y
X⊤X=XX⊤
X⊤Xy, (9.67)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
314 Linear Regression
i.e., we obtain the approximation with the minimum least-squares error
between yandXθ.
As we are looking for a solution of y=Xθ, we can think of linear
regression as a problem for solving systems of linear equations. There- Linear regression
can be thought of as
a method for solving
systems of linear
equations.fore, we can relate to concepts from linear algebra and analytic geometry
that we discussed in Chapters 2 and 3. In particular, looking carefully
at (9.67) we see that the maximum likelihood estimator θMLin our ex-
ample from (9.65) effectively does an orthogonal projection of yonto
the one-dimensional subspace spanned by X. Recalling the results on or- Maximum
likelihood linear
regression performs
an orthogonal
projection.thogonal projections from Section 3.8, we identifyXX⊤
X⊤Xas the projection
matrix, θMLas the coordinates of the projection onto the one-dimensional
subspace of RNspanned by XandXθMLas the orthogonal projection of
yonto this subspace.
Therefore, the maximum likelihood solution provides also a geometri-
cally optimal solution by finding the vectors in the subspace spanned by
Xthat are “closest” to the corresponding observations y, where “clos-
est” means the smallest (squared) distance of the function values ynto
xnθ. This is achieved by orthogonal projections. Figure 9.12(b) shows the
projection of the noisy observations onto the subspace that minimizes the
squared distance between the original dataset and its projection (note that
thex-coordinate is fixed), which corresponds to the maximum likelihood
solution.
In the general linear regression case where
y=ϕ⊤(x)θ+ϵ, ϵ∼ N 0, σ2
(9.68)
with vector-valued features ϕ(x)∈RK, we again can interpret the maxi-
mum likelihood result
y≈ΦθML, (9.69)
θML= (Φ⊤Φ)−1Φ⊤y (9.70)
as a projection onto a K-dimensional subspace of RN, which is spanned
by the columns of the feature matrix Φ; see Section 3.8.2.
If the feature functions ϕkthat we use to construct the feature ma-
trixΦare orthonormal (see Section 3.7), we obtain a special case where
the columns of Φform an orthonormal basis (see Section 3.5), such that
Φ⊤Φ=I. This will then lead to the projection
Φ(Φ⊤Φ)−1Φ⊤y=ΦΦ⊤y= KX
k=1ϕkϕ⊤
k!
y (9.71)
so that the maximum likelihood projection is simply the sum of projections
ofyonto the individual basis vectors ϕk, i.e., the columns of Φ. Further-
more, the coupling between different features has disappeared due to the
orthogonality of the basis. Many popular basis functions in signal process-
ing, such as wavelets and Fourier bases, are orthogonal basis functions.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
9.5 Further Reading 315
When the basis is not orthogonal, one can convert a set of linearly inde-
pendent basis functions to an orthogonal basis by using the Gram-Schmidt
process; see Section 3.8.3 and (Strang, 2003).
9.5 Further Reading
In this chapter, we discussed linear regression for Gaussian likelihoods
and conjugate Gaussian priors on the parameters of the model. This al-
lowed for closed-form Bayesian inference. However, in some applications
we may want to choose a different likelihood function. For example, in
a binary classification setting, we observe only two possible (categorical) classification
outcomes, and a Gaussian likelihood is inappropriate in this setting. In-
stead, we can choose a Bernoulli likelihood that will return a probability of
the predicted label to be 1(or0). We refer to the books by Barber (2012),
Bishop (2006), and Murphy (2012) for an in-depth introduction to classifi-
cation problems. A different example where non-Gaussian likelihoods are
important is count data. Counts are non-negative integers, and in this case
a Binomial or Poisson likelihood would be a better choice than a Gaussian.
All these examples fall into the category of generalized linear models , a flex- generalized linear
model ible generalization of linear regression that allows for response variables
that have error distributions other than a Gaussian distribution. The GLM Generalized linear
models are the
building blocks of
deep neural
networks.generalizes linear regression by allowing the linear model to be related
to the observed values via a smooth and invertible function σ(·)that may
be nonlinear so that y=σ(f(x)), where f(x) =θ⊤ϕ(x)is the linear
regression model from (9.13). We can therefore think of a generalized
linear model in terms of function composition y=σ◦f, where fis a
linear regression model and σthe activation function. Note that although
we are talking about “generalized linear models”, the outputs yare no
longer linear in the parameters θ. Inlogistic regression , we choose the logistic regression
logistic sigmoid σ(f) =1
1+exp( −f)∈[0,1], which can be interpreted as the logistic sigmoid
probability of observing y= 1of a Bernoulli random variable y∈ {0,1}.
The function σ(·)is called transfer function oractivation function , and its transfer function
activation function inverse is called the canonical link function . From this perspective, it is
canonical link
function
For ordinary linear
regression the
activation function
would simply be the
identity.also clear that generalized linear models are the building blocks of (deep)
feedforward neural networks: If we consider a generalized linear model
y=σ(Ax+b), where Ais a weight matrix and ba bias vector, we iden-
tify this generalized linear model as a single-layer neural network with
activation function σ(·). We can now recursively compose these functions
via
A great post on the
relation between
GLMs and deep
networks is
available at
https://tinyurl.
com/glm-dnn .xk+1=fk(xk)
fk(xk) =σk(Akxk+bk)(9.72)
fork= 0, . . . , K −1, where x0are the input features and xK=yare
the observed outputs, such that fK−1◦ ··· ◦ f0is aK-layer deep neural
network. Therefore, the building blocks of this deep neural network are
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
316 Linear Regression
the generalized linear models defined in (9.72). Neural networks (Bishop,
1995; Goodfellow et al., 2016) are significantly more expressive and flexi-
ble than linear regression models. However, maximum likelihood parame-
ter estimation is a non-convex optimization problem, and marginalization
of the parameters in a fully Bayesian setting is analytically intractable.
We briefly hinted at the fact that a distribution over parameters in-
duces a distribution over regression functions. Gaussian processes (Ras- Gaussian process
mussen and Williams, 2006) are regression models where the concept of
a distribution over function is central. Instead of placing a distribution
over parameters, a Gaussian process places a distribution directly on the
space of functions without the “detour” via the parameters. To do so, the
Gaussian process exploits the kernel trick (Sch¨olkopf and Smola, 2002), kernel trick
which allows us to compute inner products between two function values
f(xi), f(xj)only by looking at the corresponding input xi,xj. A Gaus-
sian process is closely related to both Bayesian linear regression and sup-
port vector regression but can also be interpreted as a Bayesian neural
network with a single hidden layer where the number of units tends to
infinity (Neal, 1996; Williams, 1997). Excellent introductions to Gaussian
processes can be found in MacKay (1998) and Rasmussen and Williams
(2006).
We focused on Gaussian parameter priors in the discussions in this chap-
ter, because they allow for closed-form inference in linear regression mod-
els. However, even in a regression setting with Gaussian likelihoods, we
may choose a non-Gaussian prior. Consider a setting, where the inputs are
x∈RDand our training set is small and of size N≪D. This means that
the regression problem is underdetermined. In this case, we can choose
a parameter prior that enforces sparsity, i.e., a prior that tries to set as
many parameters to 0as possible ( variable selection ). This prior provides variable selection
a stronger regularizer than the Gaussian prior, which often leads to an in-
creased prediction accuracy and interpretability of the model. The Laplace
prior is one example that is frequently used for this purpose. A linear re-
gression model with the Laplace prior on the parameters is equivalent to
linear regression with L1 regularization ( LASSO ) (Tibshirani, 1996). The LASSO
Laplace distribution is sharply peaked at zero (its first derivative is discon-
tinuous) and it concentrates its probability mass closer to zero than the
Gaussian distribution, which encourages parameters to be 0. Therefore,
the nonzero parameters are relevant for the regression problem, which is
the reason why we also speak of “variable selection”.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
10
Dimensionality Reduction with Principal
Component Analysis
Working directly with high-dimensional data, such as images, comes with A640×480pixel
color image is a data
point in a
million-dimensional
space, where every
pixel responds to
three dimensions,
one for each color
channel (red, green,
blue).some difficulties: It is hard to analyze, interpretation is difficult, visualiza-
tion is nearly impossible, and (from a practical point of view) storage of
the data vectors can be expensive. However, high-dimensional data often
has properties that we can exploit. For example, high-dimensional data is
often overcomplete, i.e., many dimensions are redundant and can be ex-
plained by a combination of other dimensions. Furthermore, dimensions
in high-dimensional data are often correlated so that the data possesses an
intrinsic lower-dimensional structure. Dimensionality reduction exploits
structure and correlation and allows us to work with a more compact rep-
resentation of the data, ideally without losing information. We can think
of dimensionality reduction as a compression technique, similar to jpeg or
mp3, which are compression algorithms for images and music.
In this chapter, we will discuss principal component analysis (PCA), an principal component
analysis
PCAalgorithm for linear dimensionality reduction . PCA, proposed by Pearson
dimensionality
reduction(1901) and Hotelling (1933), has been around for more than 100years
and is still one of the most commonly used techniques for data compres-
sion and data visualization. It is also used for the identification of simple
patterns, latent factors, and structures of high-dimensional data. In the
Figure 10.1
Illustration:
dimensionality
reduction. (a) The
original dataset
does not vary much
along the x2
direction. (b) The
data from (a) can be
represented using
thex1-coordinate
alone with nearly no
loss.
−5.0−2.5 0.0 2.5 5.0
x1−4−2024x2
(a) Dataset with x1andx2coordinates.
−5.0−2.5 0.0 2.5 5.0
x1−4−2024x2
 (b) Compressed dataset where only the x1coor-
dinate is relevant.
317
This material is published by Cambridge University Press as Mathematics for Machine Learning by
Marc Peter Deisenroth, A. Aldo Faisal, and Cheng Soon Ong (2020). This version is free to view
and download for personal use only. Not for re-distribution, re-sale, or use in derivative works.
©by M. P. Deisenroth, A. A. Faisal, and C. S. Ong, 2024. https://mml-book.com .
318 Dimensionality Reduction with Principal Component Analysis
signal processing community, PCA is also known as the Karhunen-Lo `eve Karhunen-Lo `eve
transform transform . In this chapter, we derive PCA from first principles, drawing on
our understanding of basis and basis change (Sections 2.6.1 and 2.7.2),
projections (Section 3.8), eigenvalues (Section 4.2), Gaussian distribu-
tions (Section 6.5), and constrained optimization (Section 7.2).
Dimensionality reduction generally exploits a property of high-dimen-
sional data (e.g., images) that it often lies on a low-dimensional subspace.
Figure 10.1 gives an illustrative example in two dimensions. Although
the data in Figure 10.1(a) does not quite lie on a line, the data does not
vary much in the x2-direction, so that we can express it as if it were on
a line – with nearly no loss; see Figure 10.1(b). To describe the data in
Figure 10.1(b), only the x1-coordinate is required, and the data lies in a
one-dimensional subspace of R2.
10.1 Problem Setting
In PCA, we are interested in finding projections ˜xnof data points xnthat
are as similar to the original data points as possible, but which have a sig-
nificantly lower intrinsic dimensionality. Figure 10.1 gives an illustration
of what this could look like.
More concretely, we consider an i.i.d. dataset X={x1, . . . ,xN},xn∈
RD, with mean 0that possesses the data covariance matrix (6.42) data covariance
matrix
S=1
NNX
n=1xnx⊤
n. (10.1)
Furthermore, we assume there exists a low-dimensional compressed rep-
resentation (code)
zn=B⊤xn∈RM(10.2)
ofxn, where we define the projection matrix
B:= [b1, . . . ,bM]∈RD×M. (10.3)
We assume that the columns of Bare orthonormal (Definition 3.7) so that
b⊤
ibj= 0if and only if i̸=jandb⊤
ibi= 1. We seek an M-dimensional The columns
b1, . . . ,bMofB
form a basis of the
M-dimensional
subspace in which
the projected data
˜x=BB⊤x∈RD
live.subspace U⊆RD,dim(U) =M < D onto which we project the data. We
denote the projected data by ˜xn∈U, and their coordinates (with respect
to the basis vectors b1, . . . ,bMofU) byzn. Our aim is to find projections
˜xn∈RD(or equivalently the codes znand the basis vectors b1, . . . ,bM)
so that they are as similar to the original data xnand minimize the loss
due to compression.
Example 10.1 (Coordinate Representation/Code)
Consider R2with the canonical basis e1= [1,0]⊤,e2= [0,1]⊤. From
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
10.1 Problem Setting 319
Figure 10.2
Graphical
illustration of PCA.
In PCA, we find a
compressed version
zof original data x.
The compressed
data can be
reconstructed into
˜x, which lives in the
original data space,
but has an intrinsic
lower-dimensional
representation than
x.x ˜x zOriginal
CompressedReconstructed
RDRD
RM
Chapter 2, we know that x∈R2can be represented as a linear combina-
tion of these basis vectors, e.g.,
5
3
= 5e1+ 3e2. (10.4)
However, when we consider vectors of the form
˜x=0
z
∈R2, z∈R, (10.5)
they can always be written as 0e1+ze2. To represent these vectors it is
sufficient to remember/store the coordinate/code zof˜xwith respect to
thee2vector. The dimension of a
vector space
corresponds to the
number of its basis
vectors (see
Section 2.6.1).More precisely, the set of ˜xvectors (with the standard vector addition
and scalar multiplication) forms a vector subspace U(see Section 2.4)
withdim(U) = 1 because U= span[ e2].
In Section 10.2, we will find low-dimensional representations that re-
tain as much information as possible and minimize the compression loss.
An alternative derivation of PCA is given in Section 10.3, where we will
be looking at minimizing the squared reconstruction error ∥xn−˜xn∥2be-
tween the original data xnand its projection ˜xn.
Figure 10.2 illustrates the setting we consider in PCA, where zrepre-
sents the lower-dimensional representation of the compressed data ˜xand
plays the role of a bottleneck, which controls how much information can
flow between xand˜x. In PCA, we consider a linear relationship between
the original data xand its low-dimensional code zso that z=B⊤xand
˜x=Bzfor a suitable matrix B. Based on the motivation of thinking
of PCA as a data compression technique, we can interpret the arrows in
Figure 10.2 as a pair of operations representing encoders and decoders.
The linear mapping represented by Bcan be thought of as a decoder,
which maps the low-dimensional code z∈RMback into the original data
spaceRD. Similarly, B⊤can be thought of an encoder, which encodes the
original data xas a low-dimensional (compressed) code z.
Throughout this chapter, we will use the MNIST digits dataset as a re-
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
320 Dimensionality Reduction with Principal Component Analysis
Figure 10.3
Examples of
handwritten digits
from the MNIST
dataset. http:
//yann.lecun.
com/exdb/mnist/ .
occurring example, which contains 60,000examples of handwritten digits
0through 9. Each digit is a grayscale image of size 28×28, i.e., it contains
784pixels so that we can interpret every image in this dataset as a vector
x∈R784. Examples of these digits are shown in Figure 10.3.
10.2 Maximum Variance Perspective
Figure 10.1 gave an example of how a two-dimensional dataset can be
represented using a single coordinate. In Figure 10.1(b), we chose to ig-
nore the x2-coordinate of the data because it did not add too much in-
formation so that the compressed data is similar to the original data in
Figure 10.1(a). We could have chosen to ignore the x1-coordinate, but
then the compressed data had been very dissimilar from the original data,
and much information in the data would have been lost.
If we interpret information content in the data as how “space filling”
the dataset is, then we can describe the information contained in the data
by looking at the spread of the data. From Section 6.4.1, we know that the
variance is an indicator of the spread of the data, and we can derive PCA as
a dimensionality reduction algorithm that maximizes the variance in the
low-dimensional representation of the data to retain as much information
as possible. Figure 10.4 illustrates this.
Considering the setting discussed in Section 10.1, our aim is to find
a matrix B(see (10.3)) that retains as much information as possible
when compressing data by projecting it onto the subspace spanned by
the columns b1, . . . ,bMofB. Retaining most information after data com-
pression is equivalent to capturing the largest amount of variance in the
low-dimensional code (Hotelling, 1933).
Remark. (Centered Data) For the data covariance matrix in (10.1), we
assumed centered data. We can make this assumption without loss of gen-
erality: Let us assume that µis the mean of the data. Using the properties
of the variance, which we discussed in Section 6.4.4, we obtain
Vz[z] =Vx[B⊤(x−µ)] =Vx[B⊤x−B⊤µ] =Vx[B⊤x],(10.6)
i.e., the variance of the low-dimensional code does not depend on the
mean of the data. Therefore, we assume without loss of generality that the
data has mean 0for the remainder of this section. With this assumption
the mean of the low-dimensional code is also 0sinceEz[z] =Ex[B⊤x] =
B⊤Ex[x] =0. ♢
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
10.2 Maximum Variance Perspective 321
Figure 10.4 PCA
finds a
lower-dimensional
subspace (line) that
maintains as much
variance (spread of
the data) as possible
when the data
(blue) is projected
onto this subspace
(orange).
10.2.1 Direction with Maximal Variance
We maximize the variance of the low-dimensional code using a sequential
approach. We start by seeking a single vector b1∈RDthat maximizes the The vector b1will
be the first column
of the matrix Band
therefore the first of
Morthonormal
basis vectors that
span the
lower-dimensional
subspace.variance of the projected data, i.e., we aim to maximize the variance of
the first coordinate z1ofz∈RMso that
V1:=V[z1] =1
NNX
n=1z2
1n (10.7)
is maximized, where we exploited the i.i.d. assumption of the data and
defined z1nas the first coordinate of the low-dimensional representation
zn∈RMofxn∈RD. Note that first component of znis given by
z1n=b⊤
1xn, (10.8)
i.e., it is the coordinate of the orthogonal projection of xnonto the one-
dimensional subspace spanned by b1(Section 3.8). We substitute (10.8)
into (10.7), which yields
V1=1
NNX
n=1(b⊤
1xn)2=1
NNX
n=1b⊤
1xnx⊤
nb1 (10.9a)
=b⊤
1 
1
NNX
n=1xnx⊤
n!
b1=b⊤
1Sb1, (10.9b)
where Sis the data covariance matrix defined in (10.1). In (10.9a), we
have used the fact that the dot product of two vectors is symmetric with
respect to its arguments, that is, b⊤
1xn=x⊤
nb1.
Notice that arbitrarily increasing the magnitude of the vector b1in-
creases V1, that is, a vector b1that is two times longer can result in V1
that is potentially four times larger. Therefore, we restrict all solutions to ∥b1∥2= 1
⇐⇒ ∥ b1∥= 1. ∥b1∥2= 1, which results in a constrained optimization problem in which
we seek the direction along which the data varies most.
With the restriction of the solution space to unit vectors the vector b1
that points in the direction of maximum variance can be found by the
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
322 Dimensionality Reduction with Principal Component Analysis
constrained optimization problem
max
b1b⊤
1Sb1
subject to ∥b1∥2= 1.(10.10)
Following Section 7.2, we obtain the Lagrangian
L(b1, λ) =b⊤
1Sb1+λ1(1−b⊤
1b1) (10.11)
to solve this constrained optimization problem. The partial derivatives of
Lwith respect to b1andλ1are
∂L
∂b1= 2b⊤
1S−2λ1b⊤
1,∂L
∂λ1= 1−b⊤
1b1, (10.12)
respectively. Setting these partial derivatives to 0gives us the relations
Sb1=λ1b1, (10.13)
b⊤
1b1= 1. (10.14)
By comparing this with the definition of an eigenvalue decomposition
(Section 4.4), we see that b1is an eigenvector of the data covariance
matrix S, and the Lagrange multiplier λ1plays the role of the correspond-
ing eigenvalue. This eigenvector property (10.13) allows us to rewrite our The quantity√λ1is
also called the
loading of the unit
vector b1and
represents the
standard deviation
of the data
accounted for by the
principal subspace
span[b1].variance objective (10.10) as
V1=b⊤
1Sb1=λ1b⊤
1b1=λ1, (10.15)
i.e., the variance of the data projected onto a one-dimensional subspace
equals the eigenvalue that is associated with the basis vector b1that spans
this subspace. Therefore, to maximize the variance of the low-dimensional
code, we choose the basis vector associated with the largest eigenvalue
of the data covariance matrix. This eigenvector is called the first principalprincipal component
component . We can determine the effect/contribution of the principal com-
ponent b1in the original data space by mapping the coordinate z1nback
into data space, which gives us the projected data point
˜xn=b1z1n=b1b⊤
1xn∈RD(10.16)
in the original data space.
Remark. Although ˜xnis aD-dimensional vector, it only requires a single
coordinate z1nto represent it with respect to the basis vector b1∈RD.♢
10.2.2 M-dimensional Subspace with Maximal Variance
Assume we have found the first m−1principal components as the m−1
eigenvectors of Sthat are associated with the largest m−1eigenvalues.
SinceSis symmetric, the spectral theorem (Theorem 4.15) states that we
can use these eigenvectors to construct an orthonormal eigenbasis of an
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
10.2 Maximum Variance Perspective 323
(m−1)-dimensional subspace of RD. Generally, the mth principal com-
ponent can be found by subtracting the effect of the first m−1principal
components b1, . . . ,bm−1from the data, thereby trying to find principal
components that compress the remaining information. We then arrive at
the new data matrix
ˆX:=X−m−1X
i=1bib⊤
iX=X−Bm−1X, (10.17)
where X= [x1, . . . ,xN]∈RD×Ncontains the data points as column The matrix ˆX:=
[ˆx1, . . . , ˆxN]∈
RD×Nin (10.17)
contains the
information in the
data that has not yet
been compressed.vectors and Bm−1:=Pm−1
i=1bib⊤
iis a projection matrix that projects onto
the subspace spanned by b1, . . . ,bm−1.
Remark (Notation) .Throughout this chapter, we do not follow the con-
vention of collecting data x1, . . . ,xNas the rows of the data matrix, but
we define them to be the columns of X. This means that our data ma-
trixXis aD×Nmatrix instead of the conventional N×Dmatrix. The
reason for our choice is that the algebra operations work out smoothly
without the need to either transpose the matrix or to redefine vectors as
row vectors that are left-multiplied onto matrices. ♢
To find the mth principal component, we maximize the variance
Vm=V[zm] =1
NNX
n=1z2
mn=1
NNX
n=1(b⊤
mˆxn)2=b⊤
mˆSbm, (10.18)
subject to ∥bm∥2= 1, where we followed the same steps as in (10.9b)
and defined ˆSas the data covariance matrix of the transformed dataset
ˆX:={ˆx1, . . . , ˆxN}. As previously, when we looked at the first principal
component alone, we solve a constrained optimization problem and dis-
cover that the optimal solution bmis the eigenvector of ˆSthat is associated
with the largest eigenvalue of ˆS.
It turns out that bmis also an eigenvector of S. More generally, the sets
of eigenvectors of SandˆSare identical. Since both SandˆSare sym-
metric, we can find an ONB of eigenvectors (spectral theorem 4.15), i.e.,
there exist Ddistinct eigenvectors for both SandˆS. Next, we show that
every eigenvector of Sis an eigenvector of ˆS. Assume we have already
found eigenvectors b1, . . . ,bm−1ofˆS. Consider an eigenvector biofS,
i.e.,Sbi=λibi. In general,
ˆSbi=1
NˆXˆX⊤bi=1
N(X−Bm−1X)(X−Bm−1X)⊤bi(10.19a)
= (S−SB m−1−Bm−1S+Bm−1SB m−1)bi. (10.19b)
We distinguish between two cases. If i⩾m, i.e.,biis an eigenvector
that is not among the first m−1principal components, then biis orthogo-
nal to the first m−1principal components and Bm−1bi=0. Ifi < m , i.e.,
biis among the first m−1principal components, then biis a basis vector
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
324 Dimensionality Reduction with Principal Component Analysis
of the principal subspace onto which Bm−1projects. Since b1, . . . ,bm−1
are an ONB of this principal subspace, we obtain Bm−1bi=bi. The two
cases can be summarized as follows:
Bm−1bi=biifi < m , Bm−1bi=0ifi⩾m . (10.20)
In the case i⩾m, by using (10.20) in (10.19b), we obtain ˆSbi= (S−
Bm−1S)bi=Sbi=λibi,i.e.,biis also an eigenvector of ˆSwith eigen-
value λi. Specifically,
ˆSbm=Sbm=λmbm. (10.21)
Equation (10.21) reveals that bmis not only an eigenvector of Sbut also
ofˆS. Specifically, λmis the largest eigenvalue of ˆSandλmis the mth
largest eigenvalue of S, and both have the associated eigenvector bm.
In the case i < m , by using (10.20) in (10.19b), we obtain
ˆSbi= (S−SB m−1−Bm−1S+Bm−1SB m−1)bi=0= 0bi(10.22)
This means that b1, . . . ,bm−1are also eigenvectors of ˆS, but they are as-
sociated with eigenvalue 0so that b1, . . . ,bm−1span the null space of ˆS.
Overall, every eigenvector of Sis also an eigenvector of ˆS. However,
if the eigenvectors of Sare part of the (m−1)dimensional principal
subspace, then the associated eigenvalue of ˆSis0. This derivation
shows that there is
an intimate
connection between
theM-dimensional
subspace with
maximal variance
and the eigenvalue
decomposition. We
will revisit this
connection in
Section 10.4.With the relation (10.21) and b⊤
mbm= 1, the variance of the data pro-
jected onto the mth principal component is
Vm=b⊤
mSbm(10.21)=λmb⊤
mbm=λm. (10.23)
This means that the variance of the data, when projected onto an M-
dimensional subspace, equals the sum of the eigenvalues that are associ-
ated with the corresponding eigenvectors of the data covariance matrix.
Example 10.2 (Eigenvalues of MNIST “8”)
Figure 10.5
Properties of the
training data of
MNIST “8”. (a)
Eigenvalues sorted
in descending order;
(b) Variance
captured by the
principal
components
associated with the
largest eigenvalues.
0 50 100 150 200
Index01020304050Eigenvalue
(a) Eigenvalues (sorted in descending order) of
the data covariance matrix of all digits “8” in
the MNIST training set.
0 50 100 150 200
Number of principal components100200300400500Captured variance(b) Variance captured by the principal compo-
nents.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
10.3 Projection Perspective 325
Figure 10.6
Illustration of the
projection
approach: Find a
subspace (line) that
minimizes the
length of the
difference vector
between projected
(orange) and
original (blue) data.
Taking all digits “8” in the MNIST training data, we compute the eigen-
values of the data covariance matrix. Figure 10.5(a) shows the 200largest
eigenvalues of the data covariance matrix. We see that only a few of
them have a value that differs significantly from 0. Therefore, most of
the variance, when projecting data onto the subspace spanned by the cor-
responding eigenvectors, is captured by only a few principal components,
as shown in Figure 10.5(b).
Overall, to find an M-dimensional subspace of RDthat retains as much
information as possible, PCA tells us to choose the columns of the matrix
Bin (10.3) as the Meigenvectors of the data covariance matrix Sthat
are associated with the Mlargest eigenvalues. The maximum amount of
variance PCA can capture with the first Mprincipal components is
VM=MX
m=1λm, (10.24)
where the λmare the Mlargest eigenvalues of the data covariance matrix
S. Consequently, the variance lost by data compression via PCA is
JM:=DX
j=M+1λj=VD−VM. (10.25)
Instead of these absolute quantities, we can define the relative variance
captured asVM
VD, and the relative variance lost by compression as 1−VM
VD.
10.3 Projection Perspective
In the following, we will derive PCA as an algorithm that directly mini-
mizes the average reconstruction error. This perspective allows us to in-
terpret PCA as implementing an optimal linear auto-encoder. We will draw
heavily from Chapters 2 and 3.
In the previous section, we derived PCA by maximizing the variance
in the projected space to retain as much information as possible. In the
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
326 Dimensionality Reduction with Principal Component Analysis
Figure 10.7
Simplified
projection setting.
(a) A vector x∈R2
(red cross) shall be
projected onto a
one-dimensional
subspace U⊆R2
spanned by b. (b)
shows the difference
vectors between x
and some
candidates ˜x.
−1.0−0.5 0.0 0.5 1.0 1.5 2.0
x1−0.50.00.51.01.52.02.5x2
bU
(a) Setting.
−1.0−0.5 0.0 0.5 1.0 1.5 2.0
x1−0.50.00.51.01.52.02.5x2
bU (b) Differences x−˜xifor50different ˜xiare
shown by the red lines.
following, we will look at the difference vectors between the original data
xnand their reconstruction ˜xnand minimize this distance so that xnand
˜xnare as close as possible. Figure 10.6 illustrates this setting.
10.3.1 Setting and Objective
Assume an (ordered) orthonormal basis (ONB) B= (b1, . . . ,bD)ofRD,
i.e.,b⊤
ibj= 1if and only if i=jand0otherwise.
From Section 2.5 we know that for a basis (b1, . . . ,bD)ofRDanyx∈
RDcan be written as a linear combination of the basis vectors of RD, i.e.,
Vectors ˜x∈Ucould
be vectors on a
plane in R3. The
dimensionality of
the plane is 2, but
the vectors still have
three coordinates
with respect to the
standard basis of
R3.x=DX
d=1ζdbd=MX
m=1ζmbm+DX
j=M+1ζjbj (10.26)
for suitable coordinates ζd∈R.
We are interested in finding vectors ˜x∈RD, which live in lower-
dimensional subspace U⊆RD,dim(U) =M, so that
˜x=MX
m=1zmbm∈U⊆RD(10.27)
is as similar to xas possible. Note that at this point we need to assume
that the coordinates zmof˜xandζmofxare not identical.
In the following, we use exactly this kind of representation of ˜xto find
optimal coordinates zand basis vectors b1, . . . ,bMsuch that ˜xis as sim-
ilar to the original data point xas possible, i.e., we aim to minimize the
(Euclidean) distance ∥x−˜x∥. Figure 10.7 illustrates this setting.
Without loss of generality, we assume that the dataset X={x1, . . . ,xN},
xn∈RD, is centered at 0, i.e.,E[X] =0. Without the zero-mean assump-
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
10.3 Projection Perspective 327
tion, we would arrive at exactly the same solution, but the notation would
be substantially more cluttered.
We are interested in finding the best linear projection of Xonto a lower-
dimensional subspace UofRDwithdim(U) =Mand orthonormal basis
vectors b1, . . . ,bM. We will call this subspace Utheprincipal subspace .principal subspace
The projections of the data points are denoted by
˜xn:=MX
m=1zmnbm=Bzn∈RD, (10.28)
where zn:= [z1n, . . . , z Mn]⊤∈RMis the coordinate vector of ˜xnwith
respect to the basis (b1, . . . ,bM). More specifically, we are interested in
having the ˜xnas similar to xnas possible.
The similarity measure we use in the following is the squared distance
(Euclidean norm) ∥x−˜x∥2between xand˜x. We therefore define our ob-
jective as minimizing the average squared Euclidean distance ( reconstruction reconstruction error
error ) (Pearson, 1901)
JM:=1
NNX
n=1∥xn−˜xn∥2, (10.29)
where we make it explicit that the dimension of the subspace onto which
we project the data is M. In order to find this optimal linear projection,
we need to find the orthonormal basis of the principal subspace and the
coordinates zn∈RMof the projections with respect to this basis.
To find the coordinates znand the ONB of the principal subspace, we
follow a two-step approach. First, we optimize the coordinates znfor a
given ONB (b1, . . . ,bM); second, we find the optimal ONB.
10.3.2 Finding Optimal Coordinates
Let us start by finding the optimal coordinates z1n, . . . , z Mnof the projec-
tions ˜xnforn= 1, . . . , N . Consider Figure 10.7(b), where the principal
subspace is spanned by a single vector b. Geometrically speaking, finding
the optimal coordinates zcorresponds to finding the representation of the
linear projection ˜xwith respect to bthat minimizes the distance between
˜x−x. From Figure 10.7(b), it is clear that this will be the orthogonal
projection, and in the following we will show exactly this.
We assume an ONB (b1, . . . ,bM)ofU⊆RD. To find the optimal co-
ordinates zmwith respect to this basis, we require the partial derivatives
∂JM
∂zin=∂JM
∂˜xn∂˜xn
∂zin, (10.30a)
∂JM
∂˜xn=−2
N(xn−˜xn)⊤∈R1×D, (10.30b)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
328 Dimensionality Reduction with Principal Component Analysis
Figure 10.8
Optimal projection
of a vector x∈R2
onto a
one-dimensional
subspace
(continuation from
Figure 10.7).
(a) Distances
∥x−˜x∥for some
˜x∈U.
(b) Orthogonal
projection and
optimal coordinates.
−1.0−0.5 0.0 0.5 1.0 1.5 2.0
x11.251.501.752.002.252.502.753.003.25/bardblx−˜x/bardbl
(a) Distances ∥x−˜x∥for some ˜x=z1b∈
U= span[ b]; see panel (b) for the setting.
−1.0−0.5 0.0 0.5 1.0 1.5 2.0
x1−0.50.00.51.01.52.02.5x2
bU
˜x(b) The vector ˜xthat minimizes the distance
in panel (a) is its orthogonal projection onto
U. The coordinate of the projection ˜xwith
respect to the basis vector bthat spans U
is the factor we need to scale bin order to
“reach” ˜x.
∂˜xn
∂zin(10.28)=∂
∂zin MX
m=1zmnbm!
=bi (10.30c)
fori= 1, . . . , M , such that we obtain
∂JM
∂zin(10.30b)
(10.30c)=−2
N(xn−˜xn)⊤bi(10.28)=−2
N 
xn−MX
m=1zmnbm!⊤
bi
(10.31a)
ONB=−2
N(x⊤
nbi−zinb⊤
ibi) =−2
N(x⊤
nbi−zin). (10.31b)
sinceb⊤
ibi= 1. Setting this partial derivative to 0yields immediately the The coordinates of
the optimal
projection of xn
with respect to the
basis vectors
b1, . . . ,bMare the
coordinates of the
orthogonal
projection of xn
onto the principal
subspace.optimal coordinates
zin=x⊤
nbi=b⊤
ixn (10.32)
fori= 1, . . . , M andn= 1, . . . , N . This means that the optimal co-
ordinates zinof the projection ˜xnare the coordinates of the orthogonal
projection (see Section 3.8) of the original data point xnonto the one-
dimensional subspace that is spanned by bi. Consequently:
The optimal linear projection ˜xnofxnis an orthogonal projection.
The coordinates of ˜xnwith respect to the basis (b1, . . . ,bM)are the
coordinates of the orthogonal projection of xnonto the principal sub-
space.
An orthogonal projection is the best linear mapping given the objec-
tive (10.29).
The coordinates ζmofxin (10.26) and the coordinates zmof˜xin (10.27)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
10.3 Projection Perspective 329
must be identical for m= 1, . . . , M since U⊥= span[ bM+1, . . . ,bD]is
the orthogonal complement (see Section 3.6) of U= span[ b1, . . . ,bM].
Remark (Orthogonal Projections with Orthonormal Basis Vectors) .Let us
briefly recap orthogonal projections from Section 3.8. If (b1, . . . ,bD)is an
orthonormal basis of RDthen b⊤
jxis the
coordinate of the
orthogonal
projection of xonto
the subspace
spanned by bj.˜x=bj(b⊤
jbj)−1b⊤
jx=bjb⊤
jx∈RD(10.33)
is the orthogonal projection of xonto the subspace spanned by the jth ba-
sis vector, and zj=b⊤
jxis the coordinate of this projection with respect to
the basis vector bjthat spans that subspace since zjbj=˜x. Figure 10.8(b)
illustrates this setting.
More generally, if we aim to project onto an M-dimensional subspace
ofRD, we obtain the orthogonal projection of xonto the M-dimensional
subspace with orthonormal basis vectors b1, . . . ,bMas
˜x=B(B⊤B|{z}
=I)−1B⊤x=BB⊤x, (10.34)
where we defined B:= [b1, . . . ,bM]∈RD×M. The coordinates of this
projection with respect to the ordered basis (b1, . . . ,bM)arez:=B⊤x
as discussed in Section 3.8.
We can think of the coordinates as a representation of the projected
vector in a new coordinate system defined by (b1, . . . ,bM). Note that al-
though ˜x∈RD, we only need Mcoordinates z1, . . . , z Mto represent
this vector; the other D−Mcoordinates with respect to the basis vectors
(bM+1, . . . ,bD)are always 0. ♢
So far we have shown that for a given ONB we can find the optimal
coordinates of ˜xby an orthogonal projection onto the principal subspace.
In the following, we will determine what the best basis is.
10.3.3 Finding the Basis of the Principal Subspace
To determine the basis vectors b1, . . . ,bMof the principal subspace, we
rephrase the loss function (10.29) using the results we have so far. This
will make it easier to find the basis vectors. To reformulate the loss func-
tion, we exploit our results from before and obtain
˜xn=MX
m=1zmnbm(10.32)=MX
m=1(x⊤
nbm)bm. (10.35)
We now exploit the symmetry of the dot product, which yields
˜xn= MX
m=1bmb⊤
m!
xn. (10.36)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
330 Dimensionality Reduction with Principal Component Analysis
Figure 10.9
Orthogonal
projection and
displacement
vectors. When
projecting data
points xn(blue)
onto subspace U1,
we obtain ˜xn
(orange). The
displacement vector
˜xn−xnlies
completely in the
orthogonal
complement U2of
U1.
−5 0 5
x1−6−4−20246x2
UU⊥
Since we can generally write the original data point xnas a linear combi-
nation of all basis vectors, it holds that
xn=DX
d=1zdnbd(10.32)=DX
d=1(x⊤
nbd)bd= DX
d=1bdb⊤
d!
xn (10.37a)
= MX
m=1bmb⊤
m!
xn+ DX
j=M+1bjb⊤
j!
xn, (10.37b)
where we split the sum with Dterms into a sum over Mand a sum
overD−Mterms. With this result, we find that the displacement vector
xn−˜xn, i.e., the difference vector between the original data point and its
projection, is
xn−˜xn= DX
j=M+1bjb⊤
j!
xn (10.38a)
=DX
j=M+1(x⊤
nbj)bj. (10.38b)
This means the difference is exactly the projection of the data point onto
the orthogonal complement of the principal subspace: We identify the ma-
trixPD
j=M+1bjb⊤
jin (10.38a) as the projection matrix that performs this
projection. Hence the displacement vector xn−˜xnlies in the subspace
that is orthogonal to the principal subspace as illustrated in Figure 10.9.
Remark (Low-Rank Approximation) .In (10.38a), we saw that the projec-
tion matrix, which projects xonto ˜x, is given by
MX
m=1bmb⊤
m=BB⊤. (10.39)
By construction as a sum of rank-one matrices bmb⊤
mwe see that BB⊤is
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
10.3 Projection Perspective 331
symmetric and has rank M. Therefore, the average squared reconstruction
error can also be written as
1
NNX
n=1∥xn−˜xn∥2=1
NNX
n=1xn−BB⊤xn2
(10.40a)
=1
NNX
n=1(I−BB⊤)xn2
. (10.40b)
Finding orthonormal basis vectors b1, . . . ,bM, which minimize the differ- PCA finds the best
rank-M
approximation of
the identity matrix.ence between the original data xnand their projections ˜xn, is equivalent
to finding the best rank- Mapproximation BB⊤of the identity matrix I
(see Section 4.6). ♢
Now we have all the tools to reformulate the loss function (10.29).
JM=1
NNX
n=1∥xn−˜xn∥2(10.38b)=1
NNX
n=1DX
j=M+1(b⊤
jxn)bj2
.(10.41)
We now explicitly compute the squared norm and exploit the fact that the
bjform an ONB, which yields
JM=1
NNX
n=1DX
j=M+1(b⊤
jxn)2=1
NNX
n=1DX
j=M+1b⊤
jxnb⊤
jxn (10.42a)
=1
NNX
n=1DX
j=M+1b⊤
jxnx⊤
nbj, (10.42b)
where we exploited the symmetry of the dot product in the last step to
writeb⊤
jxn=x⊤
nbj. We now swap the sums and obtain
JM=DX
j=M+1b⊤
j 
1
NNX
n=1xnx⊤
n!
| {z }
=:Sbj=DX
j=M+1b⊤
jSbj (10.43a)
=DX
j=M+1tr(b⊤
jSbj) =DX
j=M+1tr(Sbjb⊤
j) =tr DX
j=M+1bjb⊤
j
|{z }
projection matrixS
,
(10.43b)
where we exploited the property that the trace operator tr (·)(see (4.18))
is linear and invariant to cyclic permutations of its arguments. Since we
assumed that our dataset is centered, i.e., E[X] =0, we identify Sas the
data covariance matrix. Since the projection matrix in (10.43b) is con-
structed as a sum of rank-one matrices bjb⊤
jit itself is of rank D−M.
Equation (10.43a) implies that we can formulate the average squared
reconstruction error equivalently as the covariance matrix of the data,
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
332 Dimensionality Reduction with Principal Component Analysis
projected onto the orthogonal complement of the principal subspace. Min-
imizing the average squared reconstruction error is therefore equivalent to Minimizing the
average squared
reconstruction error
is equivalent to
minimizing the
projection of the
data covariance
matrix onto the
orthogonal
complement of the
principal subspace.minimizing the variance of the data when projected onto the subspace we
ignore, i.e., the orthogonal complement of the principal subspace. Equiva-
lently, we maximize the variance of the projection that we retain in the
principal subspace, which links the projection loss immediately to the
maximum-variance formulation of PCA discussed in Section 10.2. But this
then also means that we will obtain the same solution that we obtained
Minimizing the
average squared
reconstruction error
is equivalent to
maximizing the
variance of the
projected data.for the maximum-variance perspective. Therefore, we omit a derivation
that is identical to the one presented in Section 10.2 and summarize the
results from earlier in the light of the projection perspective.
The average squared reconstruction error, when projecting onto the M-
dimensional principal subspace, is
JM=DX
j=M+1λj, (10.44)
where λjare the eigenvalues of the data covariance matrix. Therefore,
to minimize (10.44) we need to select the smallest D−Meigenvalues,
which then implies that their corresponding eigenvectors are the basis of
the orthogonal complement of the principal subspace. Consequently, this
means that the basis of the principal subspace comprises the eigenvectors
b1, . . . ,bMthat are associated with the largest Meigenvalues of the data
covariance matrix.
Example 10.3 (MNIST Digits Embedding)
Figure 10.10
Embedding of
MNIST digits 0
(blue) and 1
(orange) in a
two-dimensional
principal subspace
using PCA. Four
embeddings of the
digits “0” and “1” in
the principal
subspace are
highlighted in red
with their
corresponding
original digit.
Figure 10.10 visualizes the training data of the MMIST digits “0” and “1”
embedded in the vector subspace spanned by the first two principal com-
ponents. We observe a relatively clear separation between “0”s (blue dots)
and “1”s (orange dots), and we see the variation within each individual
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
10.4 Eigenvector Computation and Low-Rank Approximations 333
cluster. Four embeddings of the digits “0” and “1” in the principal subspace
are highlighted in red with their corresponding original digit. The figure
reveals that the variation within the set of “0” is significantly greater than
the variation within the set of “1”.
10.4 Eigenvector Computation and Low-Rank Approximations
In the previous sections, we obtained the basis of the principal subspace
as the eigenvectors that are associated with the largest eigenvalues of the
data covariance matrix
S=1
NNX
n=1xnx⊤
n=1
NXX⊤, (10.45)
X= [x1, . . . ,xN]∈RD×N. (10.46)
Note that Xis aD×Nmatrix, i.e., it is the transpose of the “typical”
data matrix (Bishop, 2006; Murphy, 2012). To get the eigenvalues (and
the corresponding eigenvectors) of S, we can follow two approaches: Use
eigendecomposition
or SVD to compute
eigenvectors.We perform an eigendecomposition (see Section 4.2) and compute the
eigenvalues and eigenvectors of Sdirectly.
We use a singular value decomposition (see Section 4.5). Since Sis
symmetric and factorizes into XX⊤(ignoring the factor1
N), the eigen-
values of Sare the squared singular values of X.
More specifically, the SVD of Xis given by
X|{z}
D×N=U|{z}
D×DΣ|{z}
D×NV⊤
|{z}
N×N, (10.47)
where U∈RD×DandV⊤∈RN×Nare orthogonal matrices and Σ∈
RD×Nis a matrix whose only nonzero entries are the singular values σii⩾
0. It then follows that
S=1
NXX⊤=1
NUΣV⊤V|{z}
=INΣ⊤U⊤=1
NUΣΣ⊤U⊤. (10.48)
With the results from Section 4.5, we get that the columns of Uare the The columns of U
are the eigenvectors
ofS.eigenvectors of XX⊤(and therefore S). Furthermore, the eigenvalues
λdofSare related to the singular values of Xvia
λd=σ2
d
N. (10.49)
This relationship between the eigenvalues of Sand the singular values
ofXprovides the connection between the maximum variance view (Sec-
tion 10.2) and the singular value decomposition.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
334 Dimensionality Reduction with Principal Component Analysis
10.4.1 PCA Using Low-Rank Matrix Approximations
To maximize the variance of the projected data (or minimize the average
squared reconstruction error), PCA chooses the columns of Uin (10.48)
to be the eigenvectors that are associated with the Mlargest eigenvalues
of the data covariance matrix Sso that we identify Uas the projection ma-
trixBin (10.3), which projects the original data onto a lower-dimensional
subspace of dimension M. The Eckart-Young theorem (Theorem 4.25 in Eckart-Young
theorem Section 4.6) offers a direct way to estimate the low-dimensional represen-
tation. Consider the best rank- Mapproximation
˜XM:= argminrk(A)⩽M∥X−A∥2∈RD×N(10.50)
ofX, where ∥·∥2is the spectral norm defined in (4.93). The Eckart-Young
theorem states that ˜XMis given by truncating the SVD at the top- M
singular value. In other words, we obtain
˜XM=UM|{z}
D×MΣM|{z}
M×MV⊤
M|{z}
M×N∈RD×N(10.51)
with orthogonal matrices UM:= [u1, . . . ,uM]∈RD×MandVM:=
[v1, . . . ,vM]∈RN×Mand a diagonal matrix ΣM∈RM×Mwhose diago-
nal entries are the Mlargest singular values of X.
10.4.2 Practical Aspects
Finding eigenvalues and eigenvectors is also important in other funda-
mental machine learning methods that require matrix decompositions. In
theory, as we discussed in Section 4.2, we can solve for the eigenvalues as
roots of the characteristic polynomial. However, for matrices larger than
4×4this is not possible because we would need to find the roots of a poly-
nomial of degree 5or higher. However, the Abel-Ruffini theorem (Ruffini, Abel-Ruffini
theorem 1799; Abel, 1826) states that there exists no algebraic solution to this
problem for polynomials of degree 5or more. Therefore, in practice, wenp.linalg.eigh
or
np.linalg.svdsolve for eigenvalues or singular values using iterative methods, which are
implemented in all modern packages for linear algebra.
In many applications (such as PCA presented in this chapter), we only
require a few eigenvectors. It would be wasteful to compute the full de-
composition, and then discard all eigenvectors with eigenvalues that are
beyond the first few. It turns out that if we are interested in only the first
few eigenvectors (with the largest eigenvalues), then iterative processes,
which directly optimize these eigenvectors, are computationally more effi-
cient than a full eigendecomposition (or SVD). In the extreme case of only
needing the first eigenvector, a simple method called the power iteration power iteration
is very efficient. Power iteration chooses a random vector x0that is not in
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
10.5 PCA in High Dimensions 335
the null space of Sand follows the iteration
xk+1=Sxk
∥Sxk∥, k = 0,1, . . . . (10.52)
This means the vector xkis multiplied by Sin every iteration and then IfSis invertible, it
is sufficient to
ensure that x0̸=0.normalized, i.e., we always have ∥xk∥= 1. This sequence of vectors con-
verges to the eigenvector associated with the largest eigenvalue of S. The
original Google PageRank algorithm (Page et al., 1999) uses such an al-
gorithm for ranking web pages based on their hyperlinks.
10.5 PCA in High Dimensions
In order to do PCA, we need to compute the data covariance matrix. In D
dimensions, the data covariance matrix is a D×Dmatrix. Computing the
eigenvalues and eigenvectors of this matrix is computationally expensive
as it scales cubically in D. Therefore, PCA, as we discussed earlier, will be
infeasible in very high dimensions. For example, if our xnare images with
10,000pixels (e.g., 100×100pixel images), we would need to compute
the eigendecomposition of a 10,000×10,000covariance matrix. In the
following, we provide a solution to this problem for the case that we have
substantially fewer data points than dimensions, i.e., N≪D.
Assume we have a centered dataset x1, . . . ,xN,xn∈RD. Then the
data covariance matrix is given as
S=1
NXX⊤∈RD×D, (10.53)
where X= [x1, . . . ,xN]is aD×Nmatrix whose columns are the data
points.
We now assume that N≪D, i.e., the number of data points is smaller
than the dimensionality of the data. If there are no duplicate data points,
the rank of the covariance matrix SisN, so it has D−N+1many eigen-
values that are 0. Intuitively, this means that there are some redundancies.
In the following, we will exploit this and turn the D×Dcovariance matrix
into an N×Ncovariance matrix whose eigenvalues are all positive.
In PCA, we ended up with the eigenvector equation
Sbm=λmbm, m = 1, . . . , M , (10.54)
where bmis a basis vector of the principal subspace. Let us rewrite this
equation a bit: With Sdefined in (10.53), we obtain
Sbm=1
NXX⊤bm=λmbm. (10.55)
We now multiply X⊤∈RN×Dfrom the left-hand side, which yields
1
NX⊤X|{z}
N×NX⊤bm|{z}
=:cm=λmX⊤bm⇐⇒1
NX⊤Xcm=λmcm,(10.56)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
336 Dimensionality Reduction with Principal Component Analysis
and we get a new eigenvector/eigenvalue equation: λmremains eigen-
value, which confirms our results from Section 4.5.3 that the nonzero
eigenvalues of XX⊤equal the nonzero eigenvalues of X⊤X. We obtain
the eigenvector of the matrix1
NX⊤X∈RN×Nassociated with λmas
cm:=X⊤bm. Assuming we have no duplicate data points, this matrix
has rank Nand is invertible. This also implies that1
NX⊤Xhas the same
(nonzero) eigenvalues as the data covariance matrix S. But this is now an
N×Nmatrix, so that we can compute the eigenvalues and eigenvectors
much more efficiently than for the original D×Ddata covariance matrix.
Now that we have the eigenvectors of1
NX⊤X, we are going to re-
cover the original eigenvectors, which we still need for PCA. Currently,
we know the eigenvectors of1
NX⊤X. If we left-multiply our eigenvalue/
eigenvector equation with X, we get
1
NXX⊤
|{z}
SXcm=λmXcm (10.57)
and we recover the data covariance matrix again. This now also means
that we recover Xcmas an eigenvector of S.
Remark. If we want to apply the PCA algorithm that we discussed in Sec-
tion 10.6, we need to normalize the eigenvectors XcmofSso that they
have norm 1. ♢
10.6 Key Steps of PCA in Practice
In the following, we will go through the individual steps of PCA using a
running example, which is summarized in Figure 10.11. We are given a
two-dimensional dataset (Figure 10.11(a)), and we want to use PCA to
project it onto a one-dimensional subspace.
1.Mean subtraction We start by centering the data by computing the
mean µof the dataset and subtracting it from every single data point.
This ensures that the dataset has mean 0(Figure 10.11(b)). Mean sub-
traction is not strictly necessary but reduces the risk of numerical prob-
lems.
2.Standardization Divide the data points by the standard deviation σd
of the dataset for every dimension d= 1, . . . , D . Now the data is unit
free, and it has variance 1along each axis, which is indicated by the
two arrows in Figure 10.11(c). This step completes the standardization standardization
of the data.
3.Eigendecomposition of the covariance matrix Compute the data
covariance matrix and its eigenvalues and corresponding eigenvectors.
Since the covariance matrix is symmetric, the spectral theorem (The-
orem 4.15) states that we can find an ONB of eigenvectors. In Fig-
ure 10.11(d), the eigenvectors are scaled by the magnitude of the cor-
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
10.6 Key Steps of PCA in Practice 337
Figure 10.11 Steps
of PCA. (a) Original
dataset;
(b) centering;
(c) divide by
standard deviation;
(d) eigendecomposi-
tion; (e) projection;
(f) mapping back to
original data space.
0 5
x1−2.50.02.55.0x2
(a) Original dataset.
0 5
x1−2.50.02.55.0x2
 (b) Step 1: Centering by sub-
tracting the mean from each
data point.
0 5
x1−2.50.02.55.0x2
(c) Step 2: Dividing by the
standard deviation to make
the data unit free. Data has
variance 1along each axis.
0 5
x1−2.50.02.55.0x2
(d) Step 3: Compute eigenval-
ues and eigenvectors (arrows)
of the data covariance matrix
(ellipse).
0 5
x1−2.50.02.55.0x2
(e) Step 4: Project data onto
the principal subspace.
0 5
x1−2.50.02.55.0x2
(f) Undo the standardization
and move projected data back
into the original data space
from (a).
responding eigenvalue. The longer vector spans the principal subspace,
which we denote by U. The data covariance matrix is represented by
the ellipse.
4.Projection We can project any data point x∗∈RDonto the principal
subspace: To get this right, we need to standardize x∗using the mean
µdand standard deviation σdof the training data in the dth dimension,
respectively, so that
x(d)
∗←x(d)
∗−µd
σd, d = 1, . . . , D , (10.58)
where x(d)
∗is the dth component of x∗. We obtain the projection as
˜x∗=BB⊤x∗ (10.59)
with coordinates
z∗=B⊤x∗ (10.60)
with respect to the basis of the principal subspace. Here, Bis the ma-
trix that contains the eigenvectors that are associated with the largest
eigenvalues of the data covariance matrix as columns. PCA returns the
coordinates (10.60), not the projections x∗.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
338 Dimensionality Reduction with Principal Component Analysis
Having standardized our dataset, (10.59) only yields the projections in
the context of the standardized dataset. To obtain our projection in the
original data space (i.e., before standardization), we need to undo the
standardization (10.58) and multiply by the standard deviation before
adding the mean so that we obtain
˜x(d)
∗←˜x(d)
∗σd+µd, d = 1, . . . , D . (10.61)
Figure 10.11(f) illustrates the projection in the original data space.
Example 10.4 (MNIST Digits: Reconstruction)
In the following, we will apply PCA to the MNIST digits dataset, which
contains 60,000examples of handwritten digits 0through 9. Each digit is
an image of size 28×28, i.e., it contains 784pixels so that we can interpret
every image in this dataset as a vector x∈R784. Examples of these digits
are shown in Figure 10.3.
Figure 10.12 Effect
of increasing the
number of principal
components on
reconstruction.
Original
PCs: 1
PCs: 10
PCs: 100
PCs: 500
For illustration purposes, we apply PCA to a subset of the MNIST digits,
and we focus on the digit “8”. We used 5,389 training images of the digit
“8” and determined the principal subspace as detailed in this chapter. We
then used the learned projection matrix to reconstruct a set of test im-
ages, which is illustrated in Figure 10.12. The first row of Figure 10.12
shows a set of four original digits from the test set. The following rows
show reconstructions of exactly these digits when using a principal sub-
space of dimensions 1,10,100, and 500, respectively. We see that even
with a single-dimensional principal subspace we get a halfway decent re-
construction of the original digits, which, however, is blurry and generic.
With an increasing number of principal components (PCs), the reconstruc-
tions become sharper and more details are accounted for. With 500prin-
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
10.7 Latent Variable Perspective 339
cipal components, we effectively obtain a near-perfect reconstruction. If
we were to choose 784PCs, we would recover the exact digit without any
compression loss.
Figure 10.13 shows the average squared reconstruction error, which is
1
NNX
n=1∥xn−˜xn∥2=DX
i=M+1λi, (10.62)
as a function of the number Mof principal components. We can see that
the importance of the principal components drops off rapidly, and only
marginal gains can be achieved by adding more PCs. This matches exactly
our observation in Figure 10.5, where we discovered that the most of the
variance of the projected data is captured by only a few principal compo-
nents. With about 550PCs, we can essentially fully reconstruct the training
data that contains the digit “8” (some pixels around the boundaries show
no variation across the dataset as they are always black).
Figure 10.13
Average squared
reconstruction error
as a function of the
number of principal
components. The
average squared
reconstruction error
is the sum of the
eigenvalues in the
orthogonal
complement of the
principal subspace.
0 200 400 600 800
Number of PCs0100200300400500Average squared reconstruction error
10.7 Latent Variable Perspective
In the previous sections, we derived PCA without any notion of a prob-
abilistic model using the maximum-variance and the projection perspec-
tives. On the one hand, this approach may be appealing as it allows us to
sidestep all the mathematical difficulties that come with probability the-
ory, but on the other hand, a probabilistic model would offer us more flex-
ibility and useful insights. More specifically, a probabilistic model would
Come with a likelihood function, and we can explicitly deal with noisy
observations (which we did not even discuss earlier)
Allow us to do Bayesian model comparison via the marginal likelihood
as discussed in Section 8.6
View PCA as a generative model, which allows us to simulate new data
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
340 Dimensionality Reduction with Principal Component Analysis
Allow us to make straightforward connections to related algorithms
Deal with data dimensions that are missing at random by applying
Bayes’ theorem
Give us a notion of the novelty of a new data point
Give us a principled way to extend the model, e.g., to a mixture of PCA
models
Have the PCA we derived in earlier sections as a special case
Allow for a fully Bayesian treatment by marginalizing out the model
parameters
By introducing a continuous-valued latent variable z∈RMit is possible
to phrase PCA as a probabilistic latent-variable model. Tipping and Bishop
(1999) proposed this latent-variable model as probabilistic PCA (PPCA ). probabilistic PCA
PPCA PPCA addresses most of the aforementioned issues, and the PCA solution
that we obtained by maximizing the variance in the projected space or
by minimizing the reconstruction error is obtained as the special case of
maximum likelihood estimation in a noise-free setting.
10.7.1 Generative Process and Probabilistic Model
In PPCA, we explicitly write down the probabilistic model for linear di-
mensionality reduction. For this we assume a continuous latent variable
z∈RMwith a standard-normal prior p(z) =N 0,I
and a linear rela-
tionship between the latent variables and the observed xdata where
x=Bz+µ+ϵ∈RD, (10.63)
where ϵ∼ N 0, σ2I
is Gaussian observation noise and B∈RD×M
andµ∈RDdescribe the linear/affine mapping from latent to observed
variables. Therefore, PPCA links latent and observed variables via
p(x|z,B,µ, σ2) =N x|Bz+µ, σ2I. (10.64)
Overall, PPCA induces the following generative process:
zn∼ N z|0,I
(10.65)
xn|zn∼ N x|Bzn+µ, σ2I
(10.66)
To generate a data point that is typical given the model parameters, we
follow an ancestral sampling scheme: We first sample a latent variable zn ancestral sampling
from p(z). Then we use znin (10.64) to sample a data point conditioned
on the sampled zn, i.e.,xn∼p(x|zn,B,µ, σ2).
This generative process allows us to write down the probabilistic model
(i.e., the joint distribution of all random variables; see Section 8.4) as
p(x,z|B,µ, σ2) =p(x|z,B,µ, σ2)p(z), (10.67)
which immediately gives rise to the graphical model in Figure 10.14 using
the results from Section 8.5.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
10.7 Latent Variable Perspective 341
Figure 10.14
Graphical model for
probabilistic PCA.
The observations xn
explicitly depend on
corresponding
latent variables
zn∼ N 
0,I
. The
model parameters
B,µand the
likelihood
parameter σare
shared across the
dataset.xnBzn
σµ
n= 1, . . . , N
Remark. Note the direction of the arrow that connects the latent variables
zand the observed data x: The arrow points from ztox, which means
that the PPCA model assumes a lower-dimensional latent cause zfor high-
dimensional observations x. In the end, we are obviously interested in
finding something out about zgiven some observations. To get there we
will apply Bayesian inference to “invert” the arrow implicitly and go from
observations to latent variables. ♢
Example 10.5 (Generating New Data Using Latent Variables)
Figure 10.15
Generating new
MNIST digits. The
latent variables z
can be used to
generate new data
˜x=Bz. The closer
we stay to the
training data, the
more realistic the
generated data.
Figure 10.15 shows the latent coordinates of the MNIST digits “8” found
by PCA when using a two-dimensional principal subspace (blue dots). We
can query any vector z∗in this latent space and generate an image ˜x∗=
Bz∗that resembles the digit “8”. We show eight of such generated images
with their corresponding latent space representation. Depending on where
we query the latent space, the generated images look different (shape,
rotation, size, etc.). If we query away from the training data, we see more
and more artifacts, e.g., the top-left and top-right digits. Note that the
intrinsic dimensionality of these generated images is only two.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
342 Dimensionality Reduction with Principal Component Analysis
10.7.2 Likelihood and Joint DistributionThe likelihood does
not depend on the
latent variables z.Using the results from Chapter 6, we obtain the likelihood of this proba-
bilistic model by integrating out the latent variable z(see Section 8.4.3)
so that
p(x|B,µ, σ2) =Z
p(x|z,B,µ, σ2)p(z)dz (10.68a)
=Z
N x|Bz+µ, σ2IN z|0,Idz.(10.68b)
From Section 6.5, we know that the solution to this integral is a Gaussian
distribution with mean
Ex[x] =Ez[Bz+µ] +Eϵ[ϵ] =µ (10.69)
and with covariance matrix
V[x] =Vz[Bz+µ] +Vϵ[ϵ] =Vz[Bz] +σ2I (10.70a)
=BVz[z]B⊤+σ2I=BB⊤+σ2I. (10.70b)
The likelihood in (10.68b) can be used for maximum likelihood or MAP
estimation of the model parameters.
Remark. We cannot use the conditional distribution in (10.64) for maxi-
mum likelihood estimation as it still depends on the latent variables. The
likelihood function we require for maximum likelihood (or MAP) estima-
tion should only be a function of the data xand the model parameters,
but must not depend on the latent variables. ♢
From Section 6.5, we know that a Gaussian random variable zand
a linear/affine transformation x=Bzof it are jointly Gaussian dis-
tributed. We already know the marginals p(z) =N z|0,I
andp(x) =
N x|µ,BB⊤+σ2I
. The missing cross-covariance is given as
Cov[x,z] = Cov z[Bz+µ] =BCovz[z,z] =B. (10.71)
Therefore, the probabilistic model of PPCA, i.e., the joint distribution of
latent and observed random variables is explicitly given by
p(x,z|B,µ, σ2) =Nx
zµ
0
,BB⊤+σ2I B
B⊤I
,(10.72)
with a mean vector of length D+Mand a covariance matrix of size
(D+M)×(D+M).
10.7.3 Posterior Distribution
The joint Gaussian distribution p(x,z|B,µ, σ2)in (10.72) allows us to
determine the posterior distribution p(z|x)immediately by applying the
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
10.8 Further Reading 343
rules of Gaussian conditioning from Section 6.5.1. The posterior distribu-
tion of the latent variable given an observation xis then
p(z|x) =N z|m,C, (10.73)
m=B⊤(BB⊤+σ2I)−1(x−µ), (10.74)
C=I−B⊤(BB⊤+σ2I)−1B. (10.75)
Note that the posterior covariance does not depend on the observed data
x. For a new observation x∗in data space, we use (10.73) to determine
the posterior distribution of the corresponding latent variable z∗. The co-
variance matrix Callows us to assess how confident the embedding is. A
covariance matrix Cwith a small determinant (which measures volumes)
tells us that the latent embedding z∗is fairly certain. If we obtain a pos-
terior distribution p(z∗|x∗)with much variance, we may be faced with
an outlier. However, we can explore this posterior distribution to under-
stand what other data points xare plausible under this posterior. To do
this, we exploit the generative process underlying PPCA, which allows us
to explore the posterior distribution on the latent variables by generating
new data that is plausible under this posterior:
1. Sample a latent variable z∗∼p(z|x∗)from the posterior distribution
over the latent variables (10.73).
2. Sample a reconstructed vector ˜x∗∼p(x|z∗,B,µ, σ2) from (10.64).
If we repeat this process many times, we can explore the posterior dis-
tribution (10.73) on the latent variables z∗and its implications on the
observed data. The sampling process effectively hypothesizes data, which
is plausible under the posterior distribution.
10.8 Further Reading
We derived PCA from two perspectives: (a) maximizing the variance in the
projected space; (b) minimizing the average reconstruction error. How-
ever, PCA can also be interpreted from different perspectives. Let us recap
what we have done: We took high-dimensional data x∈RDand used
a matrix B⊤to find a lower-dimensional representation z∈RM. The
columns of Bare the eigenvectors of the data covariance matrix Sthat are
associated with the largest eigenvalues. Once we have a low-dimensional
representation z, we can get a high-dimensional version of it (in the orig-
inal data space) as x≈˜x=Bz=BB⊤x∈RD, where BB⊤is a
projection matrix.
We can also think of PCA as a linear auto-encoder as illustrated in Fig- auto-encoder
ure 10.16. An auto-encoder encodes the data xn∈RDto acodezn∈RMcode
and decodes it to a ˜xnsimilar to xn. The mapping from the data to the
code is called the encoder , and the mapping from the code back to the orig- encoder
inal data space is called the decoder . If we consider linear mappings where decoder
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
344 Dimensionality Reduction with Principal Component Analysis
Figure 10.16 PCA
can be viewed as a
linear auto-encoder.
It encodes the
high-dimensional
dataxinto a
lower-dimensional
representation
(code) z∈RMand
decodes zusing a
decoder. The
decoded vector ˜xis
the orthogonal
projection of the
original data xonto
theM-dimensional
principal subspace.B⊤
x ˜x zB
Encoder DecoderOriginal
CodeRDRD
RM
the code is given by zn=B⊤xn∈RMand we are interested in minimiz-
ing the average squared error between the data xnand its reconstruction
˜xn=Bzn,n= 1, . . . , N , we obtain
1
NNX
n=1∥xn−˜xn∥2=1
NNX
n=1xn−BB⊤xn2
. (10.76)
This means we end up with the same objective function as in (10.29) that
we discussed in Section 10.3 so that we obtain the PCA solution when we
minimize the squared auto-encoding loss. If we replace the linear map-
ping of PCA with a nonlinear mapping, we get a nonlinear auto-encoder.
A prominent example of this is a deep auto-encoder where the linear func-
tions are replaced with deep neural networks. In this context, the encoder
is also known as a recognition network orinference network , whereas the recognition network
inference network decoder is also called a generator .
generatorAnother interpretation of PCA is related to information theory. We can
think of the code as a smaller or compressed version of the original data
point. When we reconstruct our original data using the code, we do not
get the exact data point back, but a slightly distorted or noisy version
of it. This means that our compression is “lossy”. Intuitively, we want The code is a
compressed version
of the original data.to maximize the correlation between the original data and the lower-
dimensional code. More formally, this is related to the mutual information.
We would then get the same solution to PCA we discussed in Section 10.3
by maximizing the mutual information, a core concept in information the-
ory (MacKay, 2003).
In our discussion on PPCA, we assumed that the parameters of the
model, i.e., B,µ, and the likelihood parameter σ2, are known. Tipping
and Bishop (1999) describe how to derive maximum likelihood estimates
for these parameters in the PPCA setting (note that we use a different
notation in this chapter). The maximum likelihood parameters, when pro-
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
10.8 Further Reading 345
jecting D-dimensional data onto an M-dimensional subspace, are
µML=1
NNX
n=1xn, (10.77)
BML=T(Λ−σ2I)1
2R, (10.78)
σ2
ML=1
D−MDX
j=M+1λj, (10.79)
where T∈RD×Mcontains Meigenvectors of the data covariance matrix, The matrix Λ−σ2I
in (10.78) is
guaranteed to be
positive semidefinite
as the smallest
eigenvalue of the
data covariance
matrix is bounded
from below by the
noise variance σ2.Λ= diag( λ1, . . . , λ M)∈RM×Mis a diagonal matrix with the eigenvalues
associated with the principal axes on its diagonal, and R∈RM×Mis
an arbitrary orthogonal matrix. The maximum likelihood solution BMLis
unique up to an arbitrary orthogonal transformation, e.g., we can right-
multiply BMLwith any rotation matrix Rso that (10.78) essentially is a
singular value decomposition (see Section 4.5). An outline of the proof is
given by Tipping and Bishop (1999).
The maximum likelihood estimate for µgiven in (10.77) is the sample
mean of the data. The maximum likelihood estimator for the observation
noise variance σ2given in (10.79) is the average variance in the orthog-
onal complement of the principal subspace, i.e., the average leftover vari-
ance that we cannot capture with the first Mprincipal components is
treated as observation noise.
In the noise-free limit where σ→0, PPCA and PCA provide identical
solutions: Since the data covariance matrix Sis symmetric, it can be di-
agonalized (see Section 4.4), i.e., there exists a matrix Tof eigenvectors
ofSso that
S=TΛT−1. (10.80)
In the PPCA model, the data covariance matrix is the covariance matrix of
the Gaussian likelihood p(x|B,µ, σ2), which is BB⊤+σ2I, see (10.70b).
Forσ→0, we obtain BB⊤so that this data covariance must equal the
PCA data covariance (and its factorization given in (10.80)) so that
Cov[X] =TΛT−1=BB⊤⇐⇒B=TΛ1
2R, (10.81)
i.e., we obtain the maximum likelihood estimate in (10.78) for σ= 0.
From (10.78) and (10.80), it becomes clear that (P)PCA performs a de-
composition of the data covariance matrix.
In a streaming setting, where data arrives sequentially, it is recom-
mended to use the iterative expectation maximization (EM) algorithm for
maximum likelihood estimation (Roweis, 1998).
To determine the dimensionality of the latent variables (the length of
the code, the dimensionality of the lower-dimensional subspace onto which
we project the data), Gavish and Donoho (2014) suggest the heuristic
that, if we can estimate the noise variance σ2of the data, we should
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
346 Dimensionality Reduction with Principal Component Analysis
discard all singular values smaller than4σ√
D√
3. Alternatively, we can use
(nested) cross-validation (Section 8.6.1) or Bayesian model selection cri-
teria (discussed in Section 8.6.2) to determine a good estimate of the
intrinsic dimensionality of the data (Minka, 2001b).
Similar to our discussion on linear regression in Chapter 9, we can place
a prior distribution on the parameters of the model and integrate them
out. By doing so, we (a) avoid point estimates of the parameters and the
issues that come with these point estimates (see Section 8.6) and (b) al-
low for an automatic selection of the appropriate dimensionality Mof the
latent space. In this Bayesian PCA , which was proposed by Bishop (1999), Bayesian PCA
a prior p(µ,B, σ2)is placed on the model parameters. The generative
process allows us to integrate the model parameters out instead of condi-
tioning on them, which addresses overfitting issues. Since this integration
is analytically intractable, Bishop (1999) proposes to use approximate in-
ference methods, such as MCMC or variational inference. We refer to the
work by Gilks et al. (1996) and Blei et al. (2017) for more details on these
approximate inference techniques.
In PPCA, we considered the linear model p(xn|zn) =N xn|Bzn+
µ, σ2I
with prior p(zn) =N 0,I
, where all observation dimensions
are affected by the same amount of noise. If we allow each observation
dimension dto have a different variance σ2
d, we obtain factor analysis factor analysis
(FA) (Spearman, 1904; Bartholomew et al., 2011). This means that FA
gives the likelihood some more flexibility than PPCA, but still forces the
data to be explained by the model parameters B,µ.However, FA no An overly flexible
likelihood would be
able to explain more
than just the noise.longer allows for a closed-form maximum likelihood solution so that we
need to use an iterative scheme, such as the expectation maximization
algorithm, to estimate the model parameters. While in PPCA all station-
ary points are global optima, this no longer holds for FA. Compared to
PPCA, FA does not change if we scale the data, but it does return different
solutions if we rotate the data.
An algorithm that is also closely related to PCA is independent com- independent
component analysis ponent analysis (ICA(Hyvarinen et al., 2001)). Starting again with the
ICAlatent-variable perspective p(xn|zn) =N xn|Bzn+µ, σ2I
we now
change the prior on znto non-Gaussian distributions. ICA can be used
forblind-source separation . Imagine you are in a busy train station with blind-source
separation many people talking. Your ears play the role of microphones, and they
linearly mix different speech signals in the train station. The goal of blind-
source separation is to identify the constituent parts of the mixed signals.
As discussed previously in the context of maximum likelihood estimation
for PPCA, the original PCA solution is invariant to any rotation. Therefore,
PCA can identify the best lower-dimensional subspace in which the sig-
nals live, but not the signals themselves (Murphy, 2012). ICA addresses
this issue by modifying the prior distribution p(z)on the latent sources
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
10.8 Further Reading 347
to require non-Gaussian priors p(z). We refer to the books by Hyvarinen
et al. (2001) and Murphy (2012) for more details on ICA.
PCA, factor analysis, and ICA are three examples for dimensionality re-
duction with linear models. Cunningham and Ghahramani (2015) provide
a broader survey of linear dimensionality reduction.
The (P)PCA model we discussed here allows for several important ex-
tensions. In Section 10.5, we explained how to do PCA when the in-
put dimensionality Dis significantly greater than the number Nof data
points. By exploiting the insight that PCA can be performed by computing
(many) inner products, this idea can be pushed to the extreme by consid-
ering infinite-dimensional features. The kernel trick is the basis of kernel kernel trick
kernel PCA PCAand allows us to implicitly compute inner products between infinite-
dimensional features (Sch ¨olkopf et al., 1998; Sch ¨olkopf and Smola, 2002).
There are nonlinear dimensionality reduction techniques that are de-
rived from PCA (Burges (2010) provides a good overview). The auto-
encoder perspective of PCA that we discussed previously in this section
can be used to render PCA as a special case of a deep auto-encoder . In the deep auto-encoder
deep auto-encoder, both the encoder and the decoder are represented by
multilayer feedforward neural networks, which themselves are nonlinear
mappings. If we set the activation functions in these neural networks to be
the identity, the model becomes equivalent to PCA. A different approach to
nonlinear dimensionality reduction is the Gaussian process latent-variable Gaussian process
latent-variable
modelmodel (GP-LVM ) proposed by Lawrence (2005). The GP-LVM starts off with
GP-LVMthe latent-variable perspective that we used to derive PPCA and replaces
the linear relationship between the latent variables zand the observations
xwith a Gaussian process (GP). Instead of estimating the parameters of
the mapping (as we do in PPCA), the GP-LVM marginalizes out the model
parameters and makes point estimates of the latent variables z. Similar
to Bayesian PCA, the Bayesian GP-LVM proposed by Titsias and Lawrence Bayesian GP-LVM
(2010) maintains a distribution on the latent variables zand uses approx-
imate inference to integrate them out as well.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
11
Density Estimation with Gaussian Mixture
Models
In earlier chapters, we covered already two fundamental problems in
machine learning: regression (Chapter 9) and dimensionality reduction
(Chapter 10). In this chapter, we will have a look at a third pillar of ma-
chine learning: density estimation. On our journey, we introduce impor-
tant concepts, such as the expectation maximization (EM) algorithm and
a latent variable perspective of density estimation with mixture models.
When we apply machine learning to data we often aim to represent
data in some way. A straightforward way is to take the data points them-
selves as the representation of the data; see Figure 11.1 for an example.
However, this approach may be unhelpful if the dataset is huge or if we
are interested in representing characteristics of the data. In density esti-
mation, we represent the data compactly using a density from a paramet-
ric family, e.g., a Gaussian or Beta distribution. For example, we may be
looking for the mean and variance of a dataset in order to represent the
data compactly using a Gaussian distribution. The mean and variance can
be found using tools we discussed in Section 8.3: maximum likelihood or
maximum a posteriori estimation. We can then use the mean and variance
of this Gaussian to represent the distribution underlying the data, i.e., we
think of the dataset to be a typical realization from this distribution if we
were to sample from it.
Figure 11.1
Two-dimensional
dataset that cannot
be meaningfully
represented by a
Gaussian.
−5 0 5
x1−4−2024x2
348
This material is published by Cambridge University Press as Mathematics for Machine Learning by
Marc Peter Deisenroth, A. Aldo Faisal, and Cheng Soon Ong (2020). This version is free to view
and download for personal use only. Not for re-distribution, re-sale, or use in derivative works.
©by M. P. Deisenroth, A. A. Faisal, and C. S. Ong, 2024. https://mml-book.com .
11.1 Gaussian Mixture Model 349
In practice, the Gaussian (or similarly all other distributions we encoun-
tered so far) have limited modeling capabilities. For example, a Gaussian
approximation of the density that generated the data in Figure 11.1 would
be a poor approximation. In the following, we will look at a more ex-
pressive family of distributions, which we can use for density estimation:
mixture models . mixture model
Mixture models can be used to describe a distribution p(x)by a convex
combination of Ksimple (base) distributions
p(x) =KX
k=1πkpk(x) (11.1)
0⩽πk⩽1,KX
k=1πk= 1, (11.2)
where the components pkare members of a family of basic distributions,
e.g., Gaussians, Bernoullis, or Gammas, and the πkaremixture weights .mixture weight
Mixture models are more expressive than the corresponding base distri-
butions because they allow for multimodal data representations, i.e., they
can describe datasets with multiple “clusters”, such as the example in Fig-
ure 11.1.
We will focus on Gaussian mixture models (GMMs), where the basic
distributions are Gaussians. For a given dataset, we aim to maximize the
likelihood of the model parameters to train the GMM. For this purpose,
we will use results from Chapter 5, Chapter 6, and Section 7.2. However,
unlike other applications we discussed earlier (linear regression or PCA),
we will not find a closed-form maximum likelihood solution. Instead, we
will arrive at a set of dependent simultaneous equations, which we can
only solve iteratively.
11.1 Gaussian Mixture Model
AGaussian mixture model is a density model where we combine a finite Gaussian mixture
model number of KGaussian distributions N x|µk,Σk
so that
p(x|θ) =KX
k=1πkN x|µk,Σk
(11.3)
0⩽πk⩽1,KX
k=1πk= 1, (11.4)
where we defined θ:={µk,Σk, πk:k= 1, . . . , K }as the collection of
all parameters of the model. This convex combination of Gaussian distri-
bution gives us significantly more flexibility for modeling complex densi-
ties than a simple Gaussian distribution (which we recover from (11.3) for
K= 1). An illustration is given in Figure 11.2, displaying the weighted
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
350 Density Estimation with Gaussian Mixture Models
Figure 11.2
Gaussian mixture
model. The
Gaussian mixture
distribution (black)
is composed of a
convex combination
of Gaussian
distributions and is
more expressive
than any individual
component. Dashed
lines represent the
weighted Gaussian
components.
 4 2 0 2 4 6 8
x0:000:050:100:150:200:250:30p(x)Component 1
Component 2
Component 3
GMM density
components and the mixture density, which is given as
p(x|θ) = 0 .5N x| −2,1
2+ 0.2N x|1,2+ 0.3N x|4,1.(11.5)
11.2 Parameter Learning via Maximum Likelihood
Assume we are given a dataset X={x1, . . . ,xN}, where xn, n=
1, . . . , N , are drawn i.i.d. from an unknown distribution p(x). Our ob-
jective is to find a good approximation/representation of this unknown
distribution p(x)by means of a GMM with Kmixture components. The
parameters of the GMM are the Kmeans µk, the covariances Σk, and
mixture weights πk. We summarize all these free parameters in θ:=
{πk,µk,Σk:k= 1, . . . , K }.
Example 11.1 (Initial Setting)
Figure 11.3 Initial
setting: GMM
(black) with
mixture three
mixture components
(dashed) and seven
data points (discs).
−5 0 5 10 15
x0.000.050.100.150.200.250.30p(x)π1N(x|µ1,σ2
1)
π2N(x|µ2,σ2
2)
π3N(x|µ3,σ2
3)
GMM density
Throughout this chapter, we will have a simple running example that
helps us illustrate and visualize important concepts.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
11.2 Parameter Learning via Maximum Likelihood 351
We consider a one-dimensional dataset X={−3,−2.5,−1,0,2,4,5}
consisting of seven data points and wish to find a GMM with K= 3
components that models the density of the data. We initialize the mixture
components as
p1(x) =N x| −4,1
(11.6)
p2(x) =N x|0,0.2
(11.7)
p3(x) =N x|8,3
(11.8)
and assign them equal weights π1=π2=π3=1
3. The corresponding
model (and the data points) are shown in Figure 11.3.
In the following, we detail how to obtain a maximum likelihood esti-
mateθMLof the model parameters θ. We start by writing down the like-
lihood, i.e., the predictive distribution of the training data given the pa-
rameters. We exploit our i.i.d. assumption, which leads to the factorized
likelihood
p(X |θ) =NY
n=1p(xn|θ), p(xn|θ) =KX
k=1πkN xn|µk,Σk,(11.9)
where every individual likelihood term p(xn|θ)is a Gaussian mixture
density. Then we obtain the log-likelihood as
logp(X |θ) =NX
n=1logp(xn|θ) =NX
n=1logKX
k=1πkN xn|µk,Σk
| {z }
=:L.(11.10)
We aim to find parameters θ∗
MLthat maximize the log-likelihood Ldefined
in (11.10). Our “normal” procedure would be to compute the gradient
dL/dθof the log-likelihood with respect to the model parameters θ, set
it to0, and solve for θ. However, unlike our previous examples for max-
imum likelihood estimation (e.g., when we discussed linear regression in
Section 9.2), we cannot obtain a closed-form solution. However, we can
exploit an iterative scheme to find good model parameters θML, which will
turn out to be the EM algorithm for GMMs. The key idea is to update one
model parameter at a time while keeping the others fixed.
Remark. If we were to consider a single Gaussian as the desired density,
the sum over kin (11.10) vanishes, and the logcan be applied directly to
the Gaussian component, such that we get
logN x|µ,Σ=−D
2log(2π)−1
2log det( Σ)−1
2(x−µ)⊤Σ−1(x−µ).
(11.11)
This simple form allows us to find closed-form maximum likelihood esti-
mates of µandΣ, as discussed in Chapter 8. In (11.10), we cannot move
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
352 Density Estimation with Gaussian Mixture Models
theloginto the sum over kso that we cannot obtain a simple closed-form
maximum likelihood solution. ♢
Any local optimum of a function exhibits the property that its gradi-
ent with respect to the parameters must vanish (necessary condition); see
Chapter 7. In our case, we obtain the following necessary conditions when
we optimize the log-likelihood in (11.10) with respect to the GMM param-
etersµk,Σk, πk:
∂L
∂µk=0⊤⇐⇒NX
n=1∂logp(xn|θ)
∂µk=0⊤, (11.12)
∂L
∂Σk=0⇐⇒NX
n=1∂logp(xn|θ)
∂Σk=0, (11.13)
∂L
∂πk= 0⇐⇒NX
n=1∂logp(xn|θ)
∂πk= 0. (11.14)
For all three necessary conditions, by applying the chain rule (see Sec-
tion 5.2.2), we require partial derivatives of the form
∂logp(xn|θ)
∂θ=1
p(xn|θ)∂p(xn|θ)
∂θ, (11.15)
where θ={µk,Σk, πk, k= 1, . . . , K }are the model parameters and
1
p(xn|θ)=1
PK
j=1πjN xn|µj,Σj. (11.16)
In the following, we will compute the partial derivatives (11.12) through
(11.14). But before we do this, we introduce a quantity that will play a
central role in the remainder of this chapter: responsibilities.
11.2.1 Responsibilities
We define the quantity
rnk:=πkN xn|µk,Σk
PK
j=1πjN xn|µj,Σj (11.17)
as the responsibility of the kth mixture component for the nth data point. responsibility
The responsibility rnkof the kth mixture component for data point xnis
proportional to the likelihood
p(xn|πk,µk,Σk) =πkN xn|µk,Σk
(11.18)
of the mixture component given the data point. Therefore, mixture com- rnfollows a
Boltzmann/Gibbs
distribution.ponents have a high responsibility for a data point when the data point
could be a plausible sample from that mixture component. Note that
rn:= [rn1, . . . , r nK]⊤∈RKis a (normalized) probability vector, i.e.,
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
11.2 Parameter Learning via Maximum Likelihood 353
P
krnk= 1 with rnk⩾0. This probability vector distributes probabil-
ity mass among the Kmixture components, and we can think of rnas a
“soft assignment” of xnto the Kmixture components. Therefore, the re- The responsibility
rnkis the
probability that the
kth mixture
component
generated the nth
data point.sponsibility rnkfrom (11.17) represents the probability that xnhas been
generated by the kth mixture component.
Example 11.2 (Responsibilities)
For our example from Figure 11.3, we compute the responsibilities rnk

1.0 0 .0 0 .0
1.0 0 .0 0 .0
0.057 0 .943 0 .0
0.001 0 .999 0 .0
0.0 0 .066 0 .934
0.0 0 .0 1 .0
0.0 0 .0 1 .0
∈RN×K. (11.19)
Here the nth row tells us the responsibilities of all mixture components
forxn. The sum of all Kresponsibilities for a data point (sum of every
row) is 1. The kth column gives us an overview of the responsibility of
thekth mixture component. We can see that the third mixture component
(third column) is not responsible for any of the first four data points, but
takes much responsibility of the remaining data points. The sum of all
entries of a column gives us the values Nk, i.e., the total responsibility of
thekth mixture component. In our example, we get N1= 2.058, N 2=
2.008, N3= 2.934.
In the following, we determine the updates of the model parameters
µk,Σk, πkfor given responsibilities. We will see that the update equa-
tions all depend on the responsibilities, which makes a closed-form solu-
tion to the maximum likelihood estimation problem impossible. However,
for given responsibilities we will be updating one model parameter at a
time, while keeping the others fixed. After this, we will recompute the
responsibilities. Iterating these two steps will eventually converge to a lo-
cal optimum and is a specific instantiation of the EM algorithm. We will
discuss this in some more detail in Section 11.3.
11.2.2 Updating the Means
Theorem 11.1 (Update of the GMM Means) .The update of the mean pa-
rameters µk,k= 1, . . . , K , of the GMM is given by
µnew
k=PN
n=1rnkxnPN
n=1rnk, (11.20)
where the responsibilities rnkare defined in (11.17) .
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
354 Density Estimation with Gaussian Mixture Models
Remark. The update of the means µkof the individual mixture compo-
nents in (11.20) depends on all means, covariance matrices Σk, and mix-
ture weights πkviarnkgiven in (11.17). Therefore, we cannot obtain a
closed-form solution for all µkat once. ♢
Proof From (11.15), we see that the gradient of the log-likelihood with
respect to the mean parameters µk,k= 1, . . . , K , requires us to compute
the partial derivative
∂p(xn|θ)
∂µk=KX
j=1πj∂N xn|µj,Σj
∂µk=πk∂N xn|µk,Σk
∂µk(11.21a)
=πk(xn−µk)⊤Σ−1
kN xn|µk,Σk, (11.21b)
where we exploited that only the kth mixture component depends on µk.
We use our result from (11.21b) in (11.15) and put everything together
so that the desired partial derivative of Lwith respect to µkis given as
∂L
∂µk=NX
n=1∂logp(xn|θ)
∂µk=NX
n=11
p(xn|θ)∂p(xn|θ)
∂µk(11.22a)
=NX
n=1(xn−µk)⊤Σ−1
kπkN xn|µk,Σk
PK
j=1πjN xn|µj,Σj
| {z }
=rnk(11.22b)
=NX
n=1rnk(xn−µk)⊤Σ−1
k. (11.22c)
Here we used the identity from (11.16) and the result of the partial deriva-
tive in (11.21b) to get to (11.22b). The values rnkare the responsibilities
we defined in (11.17).
We now solve (11.22c) for µnew
kso that∂L(µnew
k)
∂µk=0⊤and obtain
NX
n=1rnkxn=NX
n=1rnkµnew
k⇐⇒µnew
k=PN
n=1rnkxn
PN
n=1rnk=1
NkNX
n=1rnkxn,
(11.23)
where we defined
Nk:=NX
n=1rnk (11.24)
as the total responsibility of the kth mixture component for the entire
dataset. This concludes the proof of Theorem 11.1.
Intuitively, (11.20) can be interpreted as an importance-weighted Monte
Carlo estimate of the mean, where the importance weights of data point
xnare the responsibilities rnkof the kth cluster for xn,k= 1, . . . , K .
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
11.2 Parameter Learning via Maximum Likelihood 355
Therefore, the mean µkis pulled toward a data point xnwith strength Figure 11.4 Update
of the mean
parameter of
mixture component
in a GMM. The
mean µis being
pulled toward
individual data
points with the
weights given by the
corresponding
responsibilities.
r1r2
r3x1x2 x3
µgiven by rnk. The means are pulled stronger toward data points for which
the corresponding mixture component has a high responsibility, i.e., a high
likelihood. Figure 11.4 illustrates this. We can also interpret the mean up-
date in (11.20) as the expected value of all data points under the distri-
bution given by
rk:= [r1k, . . . , r Nk]⊤/Nk, (11.25)
which is a normalized probability vector, i.e.,
µk←Erk[X]. (11.26)
Example 11.3 (Mean Updates)
Figure 11.5 Effect
of updating the
mean values in a
GMM. (a) GMM
before updating the
mean values;
(b) GMM after
updating the mean
values µkwhile
retaining the
variances and
mixture weights.
−5 0 5 10 15
x0.000.050.100.150.200.250.30p(x)π1N(x|µ1,σ2
1)
π2N(x|µ2,σ2
2)
π3N(x|µ3,σ2
3)
GMM density (a) GMM density and individual components
prior to updating the mean values.
−5 0 5 10 15
x0.000.050.100.150.200.250.30p(x)π1N(x|µ1,σ2
1)
π2N(x|µ2,σ2
2)
π3N(x|µ3,σ2
3)
GMM density(b) GMM density and individual components
after updating the mean values.
In our example from Figure 11.3, the mean values are updated as fol-
lows:
µ1:−4→ −2.7 (11.27)
µ2: 0→ −0.4 (11.28)
µ3: 8→3.7 (11.29)
Here we see that the means of the first and third mixture component
move toward the regime of the data, whereas the mean of the second
component does not change so dramatically. Figure 11.5 illustrates this
change, where Figure 11.5(a) shows the GMM density prior to updating
the means and Figure 11.5(b) shows the GMM density after updating the
mean values µk.
The update of the mean parameters in (11.20) look fairly straight-
forward. However, note that the responsibilities rnkare a function of
πj,µj,Σjfor all j= 1, . . . , K , such that the updates in (11.20) depend
on all parameters of the GMM, and a closed-form solution, which we ob-
tained for linear regression in Section 9.2 or PCA in Chapter 10, cannot
be obtained.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
356 Density Estimation with Gaussian Mixture Models
11.2.3 Updating the Covariances
Theorem 11.2 (Updates of the GMM Covariances) .The update of the co-
variance parameters Σk,k= 1, . . . , K of the GMM is given by
Σnew
k=1
NkNX
n=1rnk(xn−µk)(xn−µk)⊤, (11.30)
where rnkandNkare defined in (11.17) and(11.24) , respectively.
Proof To prove Theorem 11.2, our approach is to compute the partial
derivatives of the log-likelihood Lwith respect to the covariances Σk, set
them to 0, and solve for Σk. We start with our general approach
∂L
∂Σk=NX
n=1∂logp(xn|θ)
∂Σk=NX
n=11
p(xn|θ)∂p(xn|θ)
∂Σk. (11.31)
We already know 1/p(xn|θ)from (11.16). To obtain the remaining par-
tial derivative ∂p(xn|θ)/∂Σk, we write down the definition of the Gaus-
sian distribution p(xn|θ)(see (11.9)) and drop all terms but the kth. We
then obtain
∂p(xn|θ)
∂Σk(11.32a)
=∂
∂Σk
πk(2π)−D
2det(Σk)−1
2exp −1
2(xn−µk)⊤Σ−1
k(xn−µk)
(11.32b)
=πk(2π)−D
2∂
∂Σkdet(Σk)−1
2exp −1
2(xn−µk)⊤Σ−1
k(xn−µk)
+ det( Σk)−1
2∂
∂Σkexp −1
2(xn−µk)⊤Σ−1
k(xn−µk)
.(11.32c)
We now use the identities
∂
∂Σkdet(Σk)−1
2(5.101)=−1
2det(Σk)−1
2Σ−1
k, (11.33)
∂
∂Σk(xn−µk)⊤Σ−1
k(xn−µk)(5.103)=−Σ−1
k(xn−µk)(xn−µk)⊤Σ−1
k
(11.34)
and obtain (after some rearranging) the desired partial derivative required
in (11.31) as
∂p(xn|θ)
∂Σk=πkN xn|µk,Σk
·−1
2(Σ−1
k−Σ−1
k(xn−µk)(xn−µk)⊤Σ−1
k).(11.35)
Putting everything together, the partial derivative of the log-likelihood
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
11.2 Parameter Learning via Maximum Likelihood 357
with respect to Σkis given by
∂L
∂Σk=NX
n=1∂logp(xn|θ)
∂Σk=NX
n=11
p(xn|θ)∂p(xn|θ)
∂Σk(11.36a)
=NX
n=1πkN xn|µk,Σk
PK
j=1πjN xn|µj,Σj
| {z }
=rnk
·−1
2(Σ−1
k−Σ−1
k(xn−µk)(xn−µk)⊤Σ−1
k)
(11.36b)
=−1
2NX
n=1rnk(Σ−1
k−Σ−1
k(xn−µk)(xn−µk)⊤Σ−1
k) (11.36c)
=−1
2Σ−1
kNX
n=1rnk
|{z}
=Nk+1
2Σ−1
k NX
n=1rnk(xn−µk)(xn−µk)⊤!
Σ−1
k.
(11.36d)
We see that the responsibilities rnkalso appear in this partial derivative.
Setting this partial derivative to 0, we obtain the necessary optimality
condition
NkΣ−1
k=Σ−1
k NX
n=1rnk(xn−µk)(xn−µk)⊤!
Σ−1
k (11.37a)
⇐⇒NkI= NX
n=1rnk(xn−µk)(xn−µk)⊤!
Σ−1
k. (11.37b)
By solving for Σk, we obtain
Σnew
k=1
NkNX
n=1rnk(xn−µk)(xn−µk)⊤, (11.38)
where rkis the probability vector defined in (11.25). This gives us a sim-
ple update rule for Σkfork= 1, . . . , K and proves Theorem 11.2.
Similar to the update of µkin (11.20), we can interpret the update of
the covariance in (11.30) as an importance-weighted expected value of
the square of the centered data ˜Xk:={x1−µk, . . . ,xN−µk}.
Example 11.4 (Variance Updates)
In our example from Figure 11.3, the variances are updated as follows:
σ2
1: 1→0.14 (11.39)
σ2
2: 0.2→0.44 (11.40)
σ2
3: 3→1.53 (11.41)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
358 Density Estimation with Gaussian Mixture Models
Here we see that the variances of the first and third component shrink
significantly, whereas the variance of the second component increases
slightly.
Figure 11.6 illustrates this setting. Figure 11.6(a) is identical (but
zoomed in) to Figure 11.5(b) and shows the GMM density and its indi-
vidual components prior to updating the variances. Figure 11.6(b) shows
the GMM density after updating the variances.
Figure 11.6 Effect
of updating the
variances in a GMM.
(a) GMM before
updating the
variances; (b) GMM
after updating the
variances while
retaining the means
and mixture
weights.
−4−2 0 2 4 6 8
x0.000.050.100.150.200.250.30p(x)π1N(x|µ1,σ2
1)
π2N(x|µ2,σ2
2)
π3N(x|µ3,σ2
3)
GMM density
(a) GMM density and individual components
prior to updating the variances.
−4−2 0 2 4 6 8
x0.000.050.100.150.200.250.300.35p(x)π1N(x|µ1,σ2
1)
π2N(x|µ2,σ2
2)
π3N(x|µ3,σ2
3)
GMM density(b) GMM density and individual components
after updating the variances.
Similar to the update of the mean parameters, we can interpret (11.30)
as a Monte Carlo estimate of the weighted covariance of data points xn
associated with the kth mixture component, where the weights are the
responsibilities rnk. As with the updates of the mean parameters, this up-
date depends on all πj,µj,Σj, j= 1, . . . , K , through the responsibilities
rnk, which prohibits a closed-form solution.
11.2.4 Updating the Mixture Weights
Theorem 11.3 (Update of the GMM Mixture Weights) .The mixture weights
of the GMM are updated as
πnew
k=Nk
N, k = 1, . . . , K , (11.42)
where Nis the number of data points and Nkis defined in (11.24) .
Proof To find the partial derivative of the log-likelihood with respect
to the weight parameters πk,k= 1, . . . , K , we account for the con-
straintP
kπk= 1 by using Lagrange multipliers (see Section 7.2). The
Lagrangian is
L=L+λ KX
k=1πk−1!
(11.43a)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
11.2 Parameter Learning via Maximum Likelihood 359
=NX
n=1logKX
k=1πkN xn|µk,Σk+λ KX
k=1πk−1!
, (11.43b)
where Lis the log-likelihood from (11.10) and the second term encodes
for the equality constraint that all the mixture weights need to sum up to
1. We obtain the partial derivative with respect to πkas
∂L
∂πk=NX
n=1N xn|µk,Σk
PK
j=1πjN xn|µj,Σj+λ (11.44a)
=1
πkNX
n=1πkN xn|µk,Σk
PK
j=1πjN xn|µj,Σj
| {z }
=Nk+λ=Nk
πk+λ , (11.44b)
and the partial derivative with respect to the Lagrange multiplier λas
∂L
∂λ=KX
k=1πk−1. (11.45)
Setting both partial derivatives to 0(necessary condition for optimum)
yields the system of equations
πk=−Nk
λ, (11.46)
1 =KX
k=1πk. (11.47)
Using (11.46) in (11.47) and solving for πk, we obtain
KX
k=1πk= 1⇐⇒ −KX
k=1Nk
λ= 1⇐⇒ −N
λ= 1⇐⇒ λ=−N .
(11.48)
This allows us to substitute −Nforλin (11.46) to obtain
πnew
k=Nk
N, (11.49)
which gives us the update for the weight parameters πkand proves Theo-
rem 11.3.
We can identify the mixture weight in (11.42) as the ratio of the to-
tal responsibility of the kth cluster and the number of data points. Since
N=P
kNk, the number of data points can also be interpreted as the
total responsibility of all mixture components together, such that πkis the
relative importance of the kth mixture component for the dataset.
Remark. Since Nk=PN
i=1rnk, the update equation (11.42) for the mix-
ture weights πkalso depends on all πj,µj,Σj, j= 1, . . . , K via the re-
sponsibilities rnk. ♢
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
360 Density Estimation with Gaussian Mixture Models
Example 11.5 (Weight Parameter Updates)
Figure 11.7 Effect
of updating the
mixture weights in a
GMM. (a) GMM
before updating the
mixture weights;
(b) GMM after
updating the
mixture weights
while retaining the
means and
variances. Note the
different scales of
the vertical axes.
−4−2 0 2 4 6 8
x0.000.050.100.150.200.250.300.35p(x)π1N(x|µ1,σ2
1)
π2N(x|µ2,σ2
2)
π3N(x|µ3,σ2
3)
GMM density(a) GMM density and individual components
prior to updating the mixture weights.
−4−2 0 2 4 6 8
x0.000.050.100.150.200.250.30p(x)π1N(x|µ1,σ2
1)
π2N(x|µ2,σ2
2)
π3N(x|µ3,σ2
3)
GMM density(b) GMM density and individual components
after updating the mixture weights.
In our running example from Figure 11.3, the mixture weights are up-
dated as follows:
π1:1
3→0.29 (11.50)
π2:1
3→0.29 (11.51)
π3:1
3→0.42 (11.52)
Here we see that the third component gets more weight/importance,
while the other components become slightly less important. Figure 11.7
illustrates the effect of updating the mixture weights. Figure 11.7(a) is
identical to Figure 11.6(b) and shows the GMM density and its individual
components prior to updating the mixture weights. Figure 11.7(b) shows
the GMM density after updating the mixture weights.
Overall, having updated the means, the variances, and the weights
once, we obtain the GMM shown in Figure 11.7(b). Compared with the
initialization shown in Figure 11.3, we can see that the parameter updates
caused the GMM density to shift some of its mass toward the data points.
After updating the means, variances, and weights once, the GMM fit
in Figure 11.7(b) is already remarkably better than its initialization from
Figure 11.3. This is also evidenced by the log-likelihood values, which
increased from −28.3(initialization) to −14.4after a full update cycle.
11.3 EM Algorithm
Unfortunately, the updates in (11.20), (11.30), and (11.42) do not consti-
tute a closed-form solution for the updates of the parameters µk,Σk, πk
of the mixture model because the responsibilities rnkdepend on those pa-
rameters in a complex way. However, the results suggest a simple iterative
scheme for finding a solution to the parameters estimation problem via
maximum likelihood. The expectation maximization algorithm ( EM algo- EM algorithm
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
11.3 EM Algorithm 361
rithm ) was proposed by Dempster et al. (1977) and is a general iterative
scheme for learning parameters (maximum likelihood or MAP) in mixture
models and, more generally, latent-variable models.
In our example of the Gaussian mixture model, we choose initial values
forµk,Σk, πkand alternate until convergence between
E-step: Evaluate the responsibilities rnk(posterior probability of data
point nbelonging to mixture component k).
M-step: Use the updated responsibilities to reestimate the parameters
µk,Σk, πk.
Every step in the EM algorithm increases the log-likelihood function (Neal
and Hinton, 1999). For convergence, we can check the log-likelihood or
the parameters directly. A concrete instantiation of the EM algorithm for
estimating the parameters of a GMM is as follows:
1. Initialize µk,Σk, πk.
2.E-step: Evaluate responsibilities rnkfor every data point xnusing cur-
rent parameters πk,µk,Σk:
rnk=πkN xn|µk,Σk
P
jπjN xn|µj,Σj. (11.53)
3.M-step: Reestimate parameters πk,µk,Σkusing the current responsi-
bilities rnk(from E-step): Having updated the
means µk
in (11.54), they are
subsequently used
in (11.55) to update
the corresponding
covariances.µk=1
NkNX
n=1rnkxn, (11.54)
Σk=1
NkNX
n=1rnk(xn−µk)(xn−µk)⊤, (11.55)
πk=Nk
N. (11.56)
Example 11.6 (GMM Fit)
Figure 11.8 EM
algorithm applied to
the GMM from
Figure 11.2. (a)
Final GMM fit;
(b) negative
log-likelihood as a
function of the EM
iteration.
−5 0 5 10 15
x0.000.050.100.150.200.250.30p(x)π1N(x|µ1,σ2
1)
π2N(x|µ2,σ2
2)
π3N(x|µ3,σ2
3)
GMM density
(a) Final GMM fit. After five iterations, the EM
algorithm converges and returns this GMM.
0 1 2 3 4 5
Iteration1416182022242628Negative log-likelihood
(b) Negative log-likelihood as a function of the
EM iterations.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
362 Density Estimation with Gaussian Mixture Models
Figure 11.9
Illustration of the
EM algorithm for
fitting a Gaussian
mixture model with
three components to
a two-dimensional
dataset. (a) Dataset;
(b) negative
log-likelihood
(lower is better) as
a function of the EM
iterations. The red
dots indicate the
iterations for which
the mixture
components of the
corresponding GMM
fits are shown in (c)
through (f). The
yellow discs indicate
the means of the
Gaussian mixture
components.
Figure 11.10(a)
shows the final
GMM fit.
−10−5 0 5 10
x1−10−50510x2
(a) Dataset.
0 20 40 60
EM iteration104
4×1036×103Negative log-likelihood (b) Negative log-likelihood.
−10−5 0 5 10
x1−10−50510x2
(c) EM initialization.
−10−5 0 5 10
x1−10−50510x2
 (d) EM after one iteration.
−10−5 0 5 10
x1−10−50510x2
(e) EM after 10iterations.
−10−5 0 5 10
x1−10−50510x2
 (f) EM after 62iterations.
When we run EM on our example from Figure 11.3, we obtain the final
result shown in Figure 11.8(a) after five iterations, and Figure 11.8(b)
shows how the negative log-likelihood evolves as a function of the EM
iterations. The final GMM is given as
p(x) = 0 .29N x| −2.75,0.06+ 0.28N x| −0.50,0.25
+ 0.43N x|3.64,1.63.(11.57)
We applied the EM algorithm to the two-dimensional dataset shown
in Figure 11.1 with K= 3 mixture components. Figure 11.9 illustrates
some steps of the EM algorithm and shows the negative log-likelihood as
a function of the EM iteration (Figure 11.9(b)). Figure 11.10(a) shows
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
11.4 Latent-Variable Perspective 363
Figure 11.10 GMM
fit and
responsibilities
when EM converges.
(a) GMM fit when
EM converges;
(b) each data point
is colored according
to the
responsibilities of
the mixture
components.
−5 0 5
x1−6−4−20246x2
(a) GMM fit after 62iterations.
−5 0 5
x1−6−4−20246x2 (b) Dataset colored according to the respon-
sibilities of the mixture components.
the corresponding final GMM fit. Figure 11.10(b) visualizes the final re-
sponsibilities of the mixture components for the data points. The dataset is
colored according to the responsibilities of the mixture components when
EM converges. While a single mixture component is clearly responsible
for the data on the left, the overlap of the two data clusters on the right
could have been generated by two mixture components. It becomes clear
that there are data points that cannot be uniquely assigned to a single
component (either blue or yellow), such that the responsibilities of these
two clusters for those points are around 0.5.
11.4 Latent-Variable Perspective
We can look at the GMM from the perspective of a discrete latent-variable
model, i.e., where the latent variable zcan attain only a finite set of val-
ues. This is in contrast to PCA, where the latent variables were continuous-
valued numbers in RM.
The advantages of the probabilistic perspective are that (i) it will jus-
tify some ad hoc decisions we made in the previous sections, (ii) it allows
for a concrete interpretation of the responsibilities as posterior probabil-
ities, and (iii) the iterative algorithm for updating the model parameters
can be derived in a principled manner as the EM algorithm for maximum
likelihood parameter estimation in latent-variable models.
11.4.1 Generative Process and Probabilistic Model
To derive the probabilistic model for GMMs, it is useful to think about the
generative process, i.e., the process that allows us to generate data, using
a probabilistic model.
We assume a mixture model with Kcomponents and that a data point
xcan be generated by exactly one mixture component. We introduce a
binary indicator variable zk∈ {0,1}with two states (see Section 6.2) that
indicates whether the kth mixture component generated that data point
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
364 Density Estimation with Gaussian Mixture Models
so that
p(x|zk= 1) = N x|µk,Σk. (11.58)
We define z:= [z1, . . . , z K]⊤∈RKas a probability vector consisting of
K−1many 0s and exactly one 1. For example, for K= 3, a valid zwould
bez= [z1, z2, z3]⊤= [0,1,0]⊤, which would select the second mixture
component since z2= 1.
Remark. Sometimes this kind of probability distribution is called “multi-
noulli”, a generalization of the Bernoulli distribution to more than two
values (Murphy, 2012). ♢
The properties of zimply thatPK
k=1zk= 1. Therefore, zis aone-hot one-hot encoding
encoding (also: 1-of-Krepresentation ). 1-of-K
representation Thus far, we assumed that the indicator variables zkare known. How-
ever, in practice, this is not the case, and we place a prior distribution
p(z) =π= [π1, . . . , π K]⊤,KX
k=1πk= 1, (11.59)
on the latent variable z. Then the kth entry
πk=p(zk= 1) (11.60)
of this probability vector describes the probability that the kth mixture
component generated data point x. Figure 11.11
Graphical model for
a GMM with a single
data point.
π
z
x Σkµk
k= 1, . . . , KRemark (Sampling from a GMM) .The construction of this latent-variable
model (see the corresponding graphical model in Figure 11.11) lends it-
self to a very simple sampling procedure (generative process) to generate
data:
1. Sample z(i)∼p(z).
2. Sample x(i)∼p(x|z(i)= 1).
In the first step, we select a mixture component i(via the one-hot encod-
ingz) at random according to p(z) =π; in the second step we draw a
sample from the corresponding mixture component. When we discard the
samples of the latent variable so that we are left with the x(i), we have
valid samples from the GMM. This kind of sampling, where samples of
random variables depend on samples from the variable’s parents in the
graphical model, is called ancestral sampling . ♢ ancestral sampling
Generally, a probabilistic model is defined by the joint distribution of
the data and the latent variables (see Section 8.4). With the prior p(z)
defined in (11.59) and (11.60) and the conditional p(x|z)from (11.58),
we obtain all Kcomponents of this joint distribution via
p(x, zk= 1) = p(x|zk= 1)p(zk= 1) = πkN x|µk,Σk
(11.61)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
11.4 Latent-Variable Perspective 365
fork= 1, . . . , K , so that
p(x,z) =
p(x, z1= 1)
...
p(x, zK= 1)
=
π1N x|µ1,Σ1
...
πKN x|µK,ΣK
, (11.62)
which fully specifies the probabilistic model.
11.4.2 Likelihood
To obtain the likelihood p(x|θ)in a latent-variable model, we need to
marginalize out the latent variables (see Section 8.4.3). In our case, this
can be done by summing out all latent variables from the joint p(x,z)
in (11.62) so that
p(x|θ) =X
zp(x|θ,z)p(z|θ),θ:={µk,Σk, πk:k= 1, . . . , K }.
(11.63)
We now explicitly condition on the parameters θof the probabilistic model,
which we previously omitted. In (11.63), we sum over all Kpossible one-
hot encodings of z, which is denoted byP
z. Since there is only a single
nonzero single entry in each zthere are only Kpossible configurations/
settings of z. For example, if K= 3, then zcan have the configurations

1
0
0
,
0
1
0
,
0
0
1
. (11.64)
Summing over all possible configurations of zin (11.63) is equivalent to
looking at the nonzero entry of the z-vector and writing
p(x|θ) =X
zp(x|θ,z)p(z|θ) (11.65a)
=KX
k=1p(x|θ, zk= 1)p(zk= 1|θ) (11.65b)
so that the desired marginal distribution is given as
p(x|θ)(11.65b)=KX
k=1p(x|θ, zk= 1)p(zk= 1|θ) (11.66a)
=KX
k=1πkN x|µk,Σk, (11.66b)
which we identify as the GMM model from (11.3). Given a dataset X, we
immediately obtain the likelihood
p(X |θ) =NY
n=1p(xn|θ)(11.66b)=NY
n=1KX
k=1πkN xn|µk,Σk,(11.67)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
366 Density Estimation with Gaussian Mixture Models
Figure 11.12
Graphical model for
a GMM with Ndata
points.π
zn
xn Σkµk
n= 1, . . . , Nk= 1, . . . , K
which is exactly the GMM likelihood from (11.9). Therefore, the latent-
variable model with latent indicators zkis an equivalent way of thinking
about a Gaussian mixture model.
11.4.3 Posterior Distribution
Let us have a brief look at the posterior distribution on the latent variable
z. According to Bayes’ theorem, the posterior of the kth component having
generated data point x
p(zk= 1|x) =p(zk= 1)p(x|zk= 1)
p(x), (11.68)
where the marginal p(x)is given in (11.66b). This yields the posterior
distribution for the kth indicator variable zk
p(zk= 1|x) =p(zk= 1)p(x|zk= 1)
PK
j=1p(zj= 1)p(x|zj= 1)=πkN x|µk,Σk
PK
j=1πjN x|µj,Σj,
(11.69)
which we identify as the responsibility of the kth mixture component for
data point x. Note that we omitted the explicit conditioning on the GMM
parameters πk,µk,Σkwhere k= 1, . . . , K .
11.4.4 Extension to a Full Dataset
Thus far, we have only discussed the case where the dataset consists only
of a single data point x. However, the concepts of the prior and posterior
can be directly extended to the case of Ndata points X:={x1, . . . ,xN}.
In the probabilistic interpretation of the GMM, every data point xnpos-
sesses its own latent variable
zn= [zn1, . . . , z nK]⊤∈RK. (11.70)
Previously (when we only considered a single data point x), we omitted
the index n, but now this becomes important.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
11.4 Latent-Variable Perspective 367
We share the same prior distribution πacross all latent variables zn.
The corresponding graphical model is shown in Figure 11.12, where we
use the plate notation.
The conditional distribution p(x1, . . . ,xN|z1, . . . ,zN)factorizes over
the data points and is given as
p(x1, . . . ,xN|z1, . . . ,zN) =NY
n=1p(xn|zn). (11.71)
To obtain the posterior distribution p(znk= 1|xn), we follow the same
reasoning as in Section 11.4.3 and apply Bayes’ theorem to obtain
p(znk= 1|xn) =p(xn|znk= 1)p(znk= 1)
PK
j=1p(xn|znj= 1)p(znj= 1)(11.72a)
=πkN xn|µk,Σk
PK
j=1πjN xn|µj,Σj=rnk. (11.72b)
This means that p(zk= 1|xn)is the (posterior) probability that the kth
mixture component generated data point xnand corresponds to the re-
sponsibility rnkwe introduced in (11.17). Now the responsibilities also
have not only an intuitive but also a mathematically justified interpreta-
tion as posterior probabilities.
11.4.5 EM Algorithm Revisited
The EM algorithm that we introduced as an iterative scheme for maximum
likelihood estimation can be derived in a principled way from the latent-
variable perspective. Given a current setting θ(t)of model parameters, the
E-step calculates the expected log-likelihood
Q(θ|θ(t)) =Ez|x,θ(t)[logp(x,z|θ)] (11.73a)
=Z
logp(x,z|θ)p(z|x,θ(t))dz, (11.73b)
where the expectation of logp(x,z|θ)is taken with respect to the poste-
riorp(z|x,θ(t))of the latent variables. The M-step selects an updated set
of model parameters θ(t+1)by maximizing (11.73b).
Although an EM iteration does increase the log-likelihood, there are
no guarantees that EM converges to the maximum likelihood solution.
It is possible that the EM algorithm converges to a local maximum of
the log-likelihood. Different initializations of the parameters θcould be
used in multiple EM runs to reduce the risk of ending up in a bad local
optimum. We do not go into further details here, but refer to the excellent
expositions by Rogers and Girolami (2016) and Bishop (2006).
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
368 Density Estimation with Gaussian Mixture Models
11.5 Further Reading
The GMM can be considered a generative model in the sense that it is
straightforward to generate new data using ancestral sampling (Bishop,
2006). For given GMM parameters πk,µk,Σk,k= 1, . . . , K , we sample
an index kfrom the probability vector [π1, . . . , π K]⊤and then sample a
data point x∼ N µk,Σk
. If we repeat this Ntimes, we obtain a dataset
that has been generated by a GMM. Figure 11.1 was generated using this
procedure.
Throughout this chapter, we assumed that the number of components
Kis known. In practice, this is often not the case. However, we could use
nested cross-validation, as discussed in Section 8.6.1, to find good models.
Gaussian mixture models are closely related to the K-means clustering
algorithm. K-means also uses the EM algorithm to assign data points to
clusters. If we treat the means in the GMM as cluster centers and ignore
the covariances (or set them to I), we arrive at K-means. As also nicely
described by MacKay (2003), K-means makes a “hard” assignment of data
points to cluster centers µk, whereas a GMM makes a “soft” assignment
via the responsibilities.
We only touched upon the latent-variable perspective of GMMs and the
EM algorithm. Note that EM can be used for parameter learning in general
latent-variable models, e.g., nonlinear state-space models (Ghahramani
and Roweis, 1999; Roweis and Ghahramani, 1999) and for reinforcement
learning as discussed by Barber (2012). Therefore, the latent-variable per-
spective of a GMM is useful to derive the corresponding EM algorithm in
a principled way (Bishop, 2006; Barber, 2012; Murphy, 2012).
We only discussed maximum likelihood estimation (via the EM algo-
rithm) for finding GMM parameters. The standard criticisms of maximum
likelihood also apply here:
As in linear regression, maximum likelihood can suffer from severe
overfitting. In the GMM case, this happens when the mean of a mix-
ture component is identical to a data point and the covariance tends to
0. Then, the likelihood approaches infinity. Bishop (2006) and Barber
(2012) discuss this issue in detail.
We only obtain a point estimate of the parameters πk,µk,Σkfork=
1, . . . , K , which does not give any indication of uncertainty in the pa-
rameter values. A Bayesian approach would place a prior on the param-
eters, which can be used to obtain a posterior distribution on the param-
eters. This posterior allows us to compute the model evidence (marginal
likelihood), which can be used for model comparison, which gives us a
principled way to determine the number of mixture components. Un-
fortunately, closed-form inference is not possible in this setting because
there is no conjugate prior for this model. However, approximations,
such as variational inference, can be used to obtain an approximate
posterior (Bishop, 2006).
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
11.5 Further Reading 369
Figure 11.13
Histogram (orange
bars) and kernel
density estimation
(blue line). The
kernel density
estimator produces
a smooth estimate
of the underlying
density, whereas the
histogram is an
unsmoothed count
measure of how
many data points
(black) fall into a
single bin.
 4 2 0 2 4 6 8
x0:000:050:100:150:200:250:30p(x)
Data
KDE
Histogram In this chapter, we discussed mixture models for density estimation.
There is a plethora of density estimation techniques available. In practice,
we often use histograms and kernel density estimation. histogram
Histograms provide a nonparametric way to represent continuous den-
sities and have been proposed by Pearson (1895). A histogram is con-
structed by “binning” the data space and count, how many data points fall
into each bin. Then a bar is drawn at the center of each bin, and the height
of the bar is proportional to the number of data points within that bin. The
bin size is a critical hyperparameter, and a bad choice can lead to overfit-
ting and underfitting. Cross-validation, as discussed in Section 8.2.4, can
be used to determine a good bin size. kernel density
estimation Kernel density estimation , independently proposed by Rosenblatt (1956)
and Parzen (1962), is a nonparametric way for density estimation. Given
Ni.i.d. samples, the kernel density estimator represents the underlying
distribution as
p(x) =1
NhNX
n=1kx−xn
h
, (11.74)
where kis a kernel function, i.e., a nonnegative function that integrates to
1andh >0is a smoothing/bandwidth parameter, which plays a similar
role as the bin size in histograms. Note that we place a kernel on every
single data point xnin the dataset. Commonly used kernel functions are
the uniform distribution and the Gaussian distribution. Kernel density esti-
mates are closely related to histograms, but by choosing a suitable kernel,
we can guarantee smoothness of the density estimate. Figure 11.13 illus-
trates the difference between a histogram and a kernel density estimator
(with a Gaussian-shaped kernel) for a given dataset of 250data points.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
12
Classification with Support Vector Machines
In many situations, we want our machine learning algorithm to predict
one of a number of (discrete) outcomes. For example, an email client sorts
mail into personal mail and junk mail, which has two outcomes. Another
example is a telescope that identifies whether an object in the night sky
is a galaxy, star, or planet. There are usually a small number of outcomes,
and more importantly there is usually no additional structure on these
outcomes. In this chapter, we consider predictors that output binary val- An example of
structure is if the
outcomes were
ordered, like in the
case of small,
medium, and large
t-shirts.ues, i.e., there are only two possible outcomes. This machine learning task
is called binary classification . This is in contrast to Chapter 9, where we
binary classificationconsidered a prediction problem with continuous-valued outputs.
For binary classification, the set of possible values that the label/output
can attain is binary, and for this chapter we denote them by {+1,−1}. In
other words, we consider predictors of the form
f:RD→ {+1,−1}. (12.1)
Recall from Chapter 8 that we represent each example (data point) xn
as a feature vector of Dreal numbers. The labels are often referred to as Input example xn
may also be referred
to as inputs, data
points, features, or
instances.the positive and negative classes , respectively. One should be careful not
classto infer intuitive attributes of positiveness of the +1class. For example,
in a cancer detection task, a patient with cancer is often labeled +1. In
principle, any two distinct values can be used, e.g., {True,False},{0,1}
or{red,blue}. The problem of binary classification is well studied, and For probabilistic
models, it is
mathematically
convenient to use
{0,1}as a binary
representation; see
the remark after
Example 6.12.we defer a survey of other approaches to Section 12.6.
We present an approach known as the support vector machine (SVM),
which solves the binary classification task. As in regression, we have a su-
pervised learning task, where we have a set of examples xn∈RDalong
with their corresponding (binary) labels yn∈ {+1,−1}. Given a train-
ing data set consisting of example–label pairs {(x1, y1), . . . , (xN, yN)}, we
would like to estimate parameters of the model that will give the smallest
classification error. Similar to Chapter 9, we consider a linear model, and
hide away the nonlinearity in a transformation ϕof the examples (9.13).
We will revisit ϕin Section 12.4.
The SVM provides state-of-the-art results in many applications, with
sound theoretical guarantees (Steinwart and Christmann, 2008). There
are two main reasons why we chose to illustrate binary classification using
370
This material is published by Cambridge University Press as Mathematics for Machine Learning by
Marc Peter Deisenroth, A. Aldo Faisal, and Cheng Soon Ong (2020). This version is free to view
and download for personal use only. Not for re-distribution, re-sale, or use in derivative works.
©by M. P. Deisenroth, A. A. Faisal, and C. S. Ong, 2024. https://mml-book.com .
Classification with Support Vector Machines 371
Figure 12.1
Example 2D data,
illustrating the
intuition of data
where we can find a
linear classifier that
separates orange
crosses from blue
discs.
x(1)x(2)
SVMs. First, the SVM allows for a geometric way to think about supervised
machine learning. While in Chapter 9 we considered the machine learning
problem in terms of probabilistic models and attacked it using maximum
likelihood estimation and Bayesian inference, here we will consider an
alternative approach where we reason geometrically about the machine
learning task. It relies heavily on concepts, such as inner products and
projections, which we discussed in Chapter 3. The second reason why we
find SVMs instructive is that in contrast to Chapter 9, the optimization
problem for SVM does not admit an analytic solution so that we need to
resort to a variety of optimization tools introduced in Chapter 7.
The SVM view of machine learning is subtly different from the max-
imum likelihood view of Chapter 9. The maximum likelihood view pro-
poses a model based on a probabilistic view of the data distribution, from
which an optimization problem is derived. In contrast, the SVM view starts
by designing a particular function that is to be optimized during training,
based on geometric intuitions. We have seen something similar already
in Chapter 10, where we derived PCA from geometric principles. In the
SVM case, we start by designing a loss function that is to be minimized
on training data, following the principles of empirical risk minimization
(Section 8.2).
Let us derive the optimization problem corresponding to training an
SVM on example–label pairs. Intuitively, we imagine binary classification
data, which can be separated by a hyperplane as illustrated in Figure 12.1.
Here, every example xn(a vector of dimension 2) is a two-dimensional
location ( x(1)
nandx(2)
n), and the corresponding binary label ynis one of
two different symbols (orange cross or blue disc). “Hyperplane” is a word
that is commonly used in machine learning, and we encountered hyper-
planes already in Section 2.8. A hyperplane is an affine subspace of di-
mension D−1(if the corresponding vector space is of dimension D).
The examples consist of two classes (there are two possible labels) that
have features (the components of the vector representing the example)
arranged in such a way as to allow us to separate/classify them by draw-
ing a straight line.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
372 Classification with Support Vector Machines
In the following, we formalize the idea of finding a linear separator
of the two classes. We introduce the idea of the margin and then extend
linear separators to allow for examples to fall on the “wrong” side, incur-
ring a classification error. We present two equivalent ways of formalizing
the SVM: the geometric view (Section 12.2.4) and the loss function view
(Section 12.2.5). We derive the dual version of the SVM using Lagrange
multipliers (Section 7.2). The dual SVM allows us to observe a third way
of formalizing the SVM: in terms of the convex hulls of the examples of
each class (Section 12.3.2). We conclude by briefly describing kernels and
how to numerically solve the nonlinear kernel-SVM optimization problem.
12.1 Separating Hyperplanes
Given two examples represented as vectors xiandxj, one way to compute
the similarity between them is using an inner product ⟨xi,xj⟩. Recall from
Section 3.2 that inner products are closely related to the angle between
two vectors. The value of the inner product between two vectors depends
on the length (norm) of each vector. Furthermore, inner products allow
us to rigorously define geometric concepts such as orthogonality and pro-
jections.
The main idea behind many classification algorithms is to represent
data in RDand then partition this space, ideally in a way that examples
with the same label (and no other examples) are in the same partition.
In the case of binary classification, the space would be divided into two
parts corresponding to the positive and negative classes, respectively. We
consider a particularly convenient partition, which is to (linearly) split
the space into two halves using a hyperplane. Let example x∈RDbe an
element of the data space. Consider a function
f:RD→R (12.2a)
x7→f(x) :=⟨w,x⟩+b , (12.2b)
parametrized by w∈RDandb∈R. Recall from Section 2.8 that hy-
perplanes are affine subspaces. Therefore, we define the hyperplane that
separates the two classes in our binary classification problem as
x∈RD:f(x) = 0	. (12.3)
An illustration of the hyperplane is shown in Figure 12.2, where the
vector wis a vector normal to the hyperplane and bthe intercept. We can
derive that wis a normal vector to the hyperplane in (12.3) by choosing
any two examples xaandxbon the hyperplane and showing that the
vector between them is orthogonal to w. In the form of an equation,
f(xa)−f(xb) =⟨w,xa⟩+b−(⟨w,xb⟩+b) (12.4a)
=⟨w,xa−xb⟩, (12.4b)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
12.1 Separating Hyperplanes 373
Figure 12.2
Equation of a
separating
hyperplane (12.3).
(a) The standard
way of representing
the equation in 3D.
(b) For ease of
drawing, we look at
the hyperplane edge
on.w
(a) Separating hyperplane in 3Dw
.
0.Positive
.
Negativeb
(b) Projection of the setting in (a) onto
a plane
where the second line is obtained by the linearity of the inner product
(Section 3.2). Since we have chosen xaandxbto be on the hyperplane,
this implies that f(xa) = 0 andf(xb) = 0 and hence ⟨w,xa−xb⟩= 0.
Recall that two vectors are orthogonal when their inner product is zero. wis orthogonal to
any vector on the
hyperplane.Therefore, we obtain that wis orthogonal to any vector on the hyperplane.
Remark. Recall from Chapter 2 that we can think of vectors in different
ways. In this chapter, we think of the parameter vector was an arrow
indicating a direction, i.e., we consider wto be a geometric vector. In
contrast, we think of the example vector xas a data point (as indicated
by its coordinates), i.e., we consider xto be the coordinates of a vector
with respect to the standard basis. ♢
When presented with a test example, we classify the example as pos-
itive or negative depending on the side of the hyperplane on which it
occurs. Note that (12.3) not only defines a hyperplane; it additionally de-
fines a direction. In other words, it defines the positive and negative side
of the hyperplane. Therefore, to classify a test example xtest, we calcu-
late the value of the function f(xtest)and classify the example as +1if
f(xtest)⩾0and−1otherwise. Thinking geometrically, the positive ex-
amples lie “above” the hyperplane and the negative examples “below” the
hyperplane.
When training the classifier, we want to ensure that the examples with
positive labels are on the positive side of the hyperplane, i.e.,
⟨w,xn⟩+b⩾0 when yn= +1 (12.5)
and the examples with negative labels are on the negative side, i.e.,
⟨w,xn⟩+b <0 when yn=−1. (12.6)
Refer to Figure 12.2 for a geometric intuition of positive and negative
examples. These two conditions are often presented in a single equation
yn(⟨w,xn⟩+b)⩾0. (12.7)
Equation (12.7) is equivalent to (12.5) and (12.6) when we multiply both
sides of (12.5) and (12.6) with yn= 1andyn=−1, respectively.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
374 Classification with Support Vector Machines
Figure 12.3
Possible separating
hyperplanes. There
are many linear
classifiers (green
lines) that separate
orange crosses from
blue discs.
x(1)x(2)
12.2 Primal Support Vector Machine
Based on the concept of distances from points to a hyperplane, we now
are in a position to discuss the support vector machine. For a dataset
{(x1, y1), . . . , (xN, yN)}that is linearly separable, we have infinitely many
candidate hyperplanes (refer to Figure 12.3), and therefore classifiers,
that solve our classification problem without any (training) errors. To find
a unique solution, one idea is to choose the separating hyperplane that
maximizes the margin between the positive and negative examples. In
other words, we want the positive and negative examples to be separated
by a large margin (Section 12.2.1). In the following, we compute the dis- A classifier with
large margin turns
out to generalize
well (Steinwart and
Christmann, 2008).tance between an example and a hyperplane to derive the margin. Recall
that the closest point on the hyperplane to a given point (example xn) is
obtained by the orthogonal projection (Section 3.8).
12.2.1 Concept of the Margin
The concept of the margin is intuitively simple: It is the distance of the margin
separating hyperplane to the closest examples in the dataset, assuming There could be two
or more closest
examples to a
hyperplane.that the dataset is linearly separable. However, when trying to formalize
this distance, there is a technical wrinkle that may be confusing. The tech-
nical wrinkle is that we need to define a scale at which to measure the
distance. A potential scale is to consider the scale of the data, i.e., the raw
values of xn. There are problems with this, as we could change the units
of measurement of xnand change the values in xn, and, hence, change
the distance to the hyperplane. As we will see shortly, we define the scale
based on the equation of the hyperplane (12.3) itself.
Consider a hyperplane ⟨w,x⟩+b, and an example xaas illustrated in
Figure 12.4. Without loss of generality, we can consider the example xa
to be on the positive side of the hyperplane, i.e., ⟨w,xa⟩+b >0. We
would like to compute the distance r >0ofxafrom the hyperplane. We
do so by considering the orthogonal projection (Section 3.8) of xaonto
the hyperplane, which we denote by x′
a. Since wis orthogonal to the
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
12.2 Primal Support Vector Machine 375
Figure 12.4 Vector
addition to express
distance to
hyperplane:
xa=x′
a+rw
∥w∥.
.0.xa
w.x′
ar
hyperplane, we know that the distance ris just a scaling of this vector w.
If the length of wis known, then we can use this scaling factor rfactor
to work out the absolute distance between xaandx′
a. For convenience,
we choose to use a vector of unit length (its norm is 1) and obtain this
by dividing wby its norm,w
∥w∥. Using vector addition (Section 2.4), we
obtain
xa=x′
a+rw
∥w∥. (12.8)
Another way of thinking about ris that it is the coordinate of xain the
subspace spanned by w/∥w∥. We have now expressed the distance of xa
from the hyperplane as r, and if we choose xato be the point closest to
the hyperplane, this distance ris the margin.
Recall that we would like the positive examples to be further than r
from the hyperplane, and the negative examples to be further than dis-
tance r(in the negative direction) from the hyperplane. Analogously to
the combination of (12.5) and (12.6) into (12.7), we formulate this ob-
jective as
yn(⟨w,xn⟩+b)⩾r . (12.9)
In other words, we combine the requirements that examples are at least
raway from the hyperplane (in the positive and negative direction) into
one single inequality.
Since we are interested only in the direction, we add an assumption to
our model that the parameter vector wis of unit length, i.e., ∥w∥= 1,
where we use the Euclidean norm ∥w∥=√
w⊤w(Section 3.1). This We will see other
choices of inner
products
(Section 3.2) in
Section 12.4.assumption also allows a more intuitive interpretation of the distance r
(12.8) since it is the scaling factor of a vector of length 1.
Remark. A reader familiar with other presentations of the margin would
notice that our definition of ∥w∥= 1 is different from the standard
presentation if the SVM was the one provided by Sch ¨olkopf and Smola
(2002), for example. In Section 12.2.3, we will show the equivalence of
both approaches. ♢
Collecting the three requirements into a single constrained optimization
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
376 Classification with Support Vector Machines
Figure 12.5
Derivation of the
margin: r=1
∥w∥..xa
w
⟨w,x⟩+
b= 0⟨w,x⟩+
b= 1.x′
ar
problem, we obtain the objective
max
w,b,rr|{z}
margin
subject to yn(⟨w,xn⟩+b)⩾r| {z }
data fitting,∥w∥= 1|{z}
normalization, r > 0,(12.10)
which says that we want to maximize the margin rwhile ensuring that
the data lies on the correct side of the hyperplane.
Remark. The concept of the margin turns out to be highly pervasive in ma-
chine learning. It was used by Vladimir Vapnik and Alexey Chervonenkis
to show that when the margin is large, the “complexity” of the function
class is low, and hence learning is possible (Vapnik, 2000). It turns out
that the concept is useful for various different approaches for theoret-
ically analyzing generalization error (Steinwart and Christmann, 2008;
Shalev-Shwartz and Ben-David, 2014). ♢
12.2.2 Traditional Derivation of the Margin
In the previous section, we derived (12.10) by making the observation that
we are only interested in the direction of wand not its length, leading to
the assumption that ∥w∥= 1. In this section, we derive the margin max-
imization problem by making a different assumption. Instead of choosing
that the parameter vector is normalized, we choose a scale for the data.
We choose this scale such that the value of the predictor ⟨w,x⟩+bis1at
the closest example. Let us also denote the example in the dataset that is Recall that we
currently consider
linearly separable
data.closest to the hyperplane by xa.
Figure 12.5 is identical to Figure 12.4, except that now we rescaled the
axes, such that the example xalies exactly on the margin, i.e., ⟨w,xa⟩+
b= 1. Since x′
ais the orthogonal projection of xaonto the hyperplane, it
must by definition lie on the hyperplane, i.e.,
⟨w,x′
a⟩+b= 0. (12.11)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
12.2 Primal Support Vector Machine 377
By substituting (12.8) into (12.11), we obtain

w,xa−rw
∥w∥
+b= 0. (12.12)
Exploiting the bilinearity of the inner product (see Section 3.2), we get
⟨w,xa⟩+b−r⟨w,w⟩
∥w∥= 0. (12.13)
Observe that the first term is 1by our assumption of scale, i.e., ⟨w,xa⟩+
b= 1. From (3.16) in Section 3.1, we know that ⟨w,w⟩=∥w∥2. Hence,
the second term reduces to r∥w∥. Using these simplifications, we obtain
r=1
∥w∥. (12.14)
This means we derived the distance rin terms of the normal vector w
of the hyperplane. At first glance, this equation is counterintuitive as we We can also think of
the distance as the
projection error that
incurs when
projecting xaonto
the hyperplane.seem to have derived the distance from the hyperplane in terms of the
length of the vector w, but we do not yet know this vector. One way to
think about it is to consider the distance rto be a temporary variable
that we only use for this derivation. Therefore, for the rest of this section
we will denote the distance to the hyperplane by1
∥w∥. In Section 12.2.3,
we will see that the choice that the margin equals 1is equivalent to our
previous assumption of ∥w∥= 1in Section 12.2.1.
Similar to the argument to obtain (12.9), we want the positive and
negative examples to be at least 1away from the hyperplane, which yields
the condition
yn(⟨w, xn⟩+b)⩾1. (12.15)
Combining the margin maximization with the fact that examples need to
be on the correct side of the hyperplane (based on their labels) gives us
max
w,b1
∥w∥(12.16)
subject to yn(⟨w,xn⟩+b)⩾1 for all n= 1, . . . , N. (12.17)
Instead of maximizing the reciprocal of the norm as in (12.16), we often
minimize the squared norm. We also often include a constant1
2that does The squared norm
results in a convex
quadratic
programming
problem for the
SVM (Section 12.5).not affect the optimal w, bbut yields a tidier form when we compute the
gradient. Then, our objective becomes
min
w,b1
2∥w∥2(12.18)
subject to yn(⟨w,xn⟩+b)⩾1 for all n= 1, . . . , N . (12.19)
Equation (12.18) is known as the hard margin SVM . The reason for the hard margin SVM
expression “hard” is because the formulation does not allow for any vi-
olations of the margin condition. We will see in Section 12.2.4 that this
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
378 Classification with Support Vector Machines
“hard” condition can be relaxed to accommodate violations if the data is
not linearly separable.
12.2.3 Why We Can Set the Margin to 1
In Section 12.2.1, we argued that we would like to maximize some value
r, which represents the distance of the closest example to the hyperplane.
In Section 12.2.2, we scaled the data such that the closest example is of
distance 1to the hyperplane. In this section, we relate the two derivations,
and show that they are equivalent.
Theorem 12.1. Maximizing the margin r, where we consider normalized
weights as in (12.10) ,
max
w,b,rr|{z}
margin
subject to yn(⟨w,xn⟩+b)⩾r| {z }
data fitting,∥w∥= 1|{z}
normalization, r > 0,(12.20)
is equivalent to scaling the data, such that the margin is unity:
min
w,b1
2∥w∥2
|{z}
margin
subject to yn(⟨w,xn⟩+b)⩾1| {z }
data fitting.(12.21)
Proof Consider (12.20). Since the square is a strictly monotonic trans-
formation for non-negative arguments, the maximum stays the same if we
consider r2in the objective. Since ∥w∥= 1 we can reparametrize the
equation with a new weight vector w′that is not normalized by explicitly
usingw′
∥w′∥. We obtain
max
w′,b,rr2
subject to ynw′
∥w′∥,xn
+b
⩾r, r > 0.(12.22)
Equation (12.22) explicitly states that the distance ris positive. Therefore,
we can divide the first constraint by r, which yields Note that r >0
because we
assumed linear
separability, and
hence there is no
issue to divide by r.max
w′,b,rr2
subject to yn
*
w′
∥w′∥r|{z}
w′′,xn+
+b
r|{z}
b′′
⩾1, r > 0(12.23)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
12.2 Primal Support Vector Machine 379
Figure 12.6
(a) Linearly
separable and
(b) non-linearly
separable data.
x(1)x(2)
(a) Linearly separable data, with a large
margin
x(1)x(2)(b) Non-linearly separable data
renaming the parameters to w′′andb′′. Since w′′=w′
∥w′∥r, rearranging for
rgives
∥w′′∥=w′
∥w′∥r=1
r·w′
∥w′∥=1
r. (12.24)
By substituting this result into (12.23), we obtain
max
w′′,b′′1
∥w′′∥2
subject to yn(⟨w′′,xn⟩+b′′)⩾1.(12.25)
The final step is to observe that maximizing1
∥w′′∥2yields the same solution
as minimizing1
2∥w′′∥2, which concludes the proof of Theorem 12.1.
12.2.4 Soft Margin SVM: Geometric View
In the case where data is not linearly separable, we may wish to allow
some examples to fall within the margin region, or even to be on the
wrong side of the hyperplane as illustrated in Figure 12.6.
The model that allows for some classification errors is called the soft soft margin SVM
margin SVM . In this section, we derive the resulting optimization problem
using geometric arguments. In Section 12.2.5, we will derive an equiv-
alent optimization problem using the idea of a loss function. Using La-
grange multipliers (Section 7.2), we will derive the dual optimization
problem of the SVM in Section 12.3. This dual optimization problem al-
lows us to observe a third interpretation of the SVM: as a hyperplane that
bisects the line between convex hulls corresponding to the positive and
negative data examples (Section 12.3.2).
The key geometric idea is to introduce a slack variable ξncorresponding slack variable
to each example–label pair (xn, yn)that allows a particular example to be
within the margin or even on the wrong side of the hyperplane (refer to
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
380 Classification with Support Vector Machines
Figure 12.7 Soft
margin SVM allows
examples to be
within the margin or
on the wrong side of
the hyperplane. The
slack variable ξ
measures the
distance of a
positive example
x+to the positive
margin hyperplane
⟨w,x⟩+b= 1
whenx+is on the
wrong side..x+w
⟨w,x⟩+
b= 0⟨w,x⟩+
b= 1.
ξ
Figure 12.7). We subtract the value of ξnfrom the margin, constraining
ξnto be non-negative. To encourage correct classification of the samples,
we add ξnto the objective
min
w,b,ξ1
2∥w∥2+CNX
n=1ξn (12.26a)
subject to yn(⟨w,xn⟩+b)⩾1−ξn (12.26b)
ξn⩾0 (12.26c)
forn= 1, . . . , N . In contrast to the optimization problem (12.18) for the
hard margin SVM, this one is called the soft margin SVM . The parameter soft margin SVM
C >0trades off the size of the margin and the total amount of slack that
we have. This parameter is called the regularization parameter since, as regularization
parameter we will see in the following section, the margin term in the objective func-
tion (12.26a) is a regularization term. The margin term ∥w∥2is called
theregularizer , and in many books on numerical optimization, the reg- regularizer
ularization parameter is multiplied with this term (Section 8.2.3). This
is in contrast to our formulation in this section. Here a large value of C
implies low regularization, as we give the slack variables larger weight,
hence giving more priority to examples that do not lie on the correct side
of the margin. There are
alternative
parametrizations of
this regularization,
which is
why (12.26a) is also
often referred to as
theC-SVM.Remark. In the formulation of the soft margin SVM (12.26a) wis reg-
ularized, but bis not regularized. We can see this by observing that the
regularization term does not contain b. The unregularized term bcom-
plicates theoretical analysis (Steinwart and Christmann, 2008, chapter 1)
and decreases computational efficiency (Fan et al., 2008). ♢
12.2.5 Soft Margin SVM: Loss Function View
Let us consider a different approach for deriving the SVM, following the
principle of empirical risk minimization (Section 8.2). For the SVM, we
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
12.2 Primal Support Vector Machine 381
choose hyperplanes as the hypothesis class, that is
f(x) =⟨w,x⟩+b. (12.27)
We will see in this section that the margin corresponds to the regulariza-
tion term. The remaining question is, what is the loss function ? In con- loss function
trast to Chapter 9, where we consider regression problems (the output
of the predictor is a real number), in this chapter, we consider binary
classification problems (the output of the predictor is one of two labels
{+1,−1}). Therefore, the error/loss function for each single example–
label pair needs to be appropriate for binary classification. For example,
the squared loss that is used for regression (9.10b) is not suitable for bi-
nary classification.
Remark. The ideal loss function between binary labels is to count the num-
ber of mismatches between the prediction and the label. This means that
for a predictor fapplied to an example xn, we compare the output f(xn)
with the label yn. We define the loss to be zero if they match, and one if
they do not match. This is denoted by 1(f(xn)̸=yn)and is called the
zero-one loss . Unfortunately, the zero-one loss results in a combinatorial zero-one loss
optimization problem for finding the best parameters w, b. Combinatorial
optimization problems (in contrast to continuous optimization problems
discussed in Chapter 7) are in general more challenging to solve. ♢
What is the loss function corresponding to the SVM? Consider the error
between the output of a predictor f(xn)and the label yn. The loss de-
scribes the error that is made on the training data. An equivalent way to
derive (12.26a) is to use the hinge loss hinge loss
ℓ(t) = max {0,1−t}where t=yf(x) =y(⟨w,x⟩+b).(12.28)
Iff(x)is on the correct side (based on the corresponding label y) of the
hyperplane, and further than distance 1, this means that t⩾1and the
hinge loss returns a value of zero. If f(x)is on the correct side but too
close to the hyperplane ( 0< t < 1), the example xis within the margin,
and the hinge loss returns a positive value. When the example is on the
wrong side of the hyperplane ( t <0), the hinge loss returns an even larger
value, which increases linearly. In other words, we pay a penalty once we
are closer than the margin to the hyperplane, even if the prediction is
correct, and the penalty increases linearly. An alternative way to express
the hinge loss is by considering it as two linear pieces
ℓ(t) =(
0 if t⩾1
1−tift <1, (12.29)
as illustrated in Figure 12.8. The loss corresponding to the hard margin
SVM 12.18 is defined as
ℓ(t) =(
0 if t⩾1
∞ift <1. (12.30)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
382 Classification with Support Vector Machines
Figure 12.8 The
hinge loss is a
convex upper bound
of zero-one loss.
−2 0 2
t024max{0,1−t}Zero-one loss
Hinge loss
This loss can be interpreted as never allowing any examples inside the
margin.
For a given training set {(x1, y1), . . . , (xN, yN)}, we seek to minimize
the total loss, while regularizing the objective with ℓ2-regularization (see
Section 8.2.3). Using the hinge loss (12.28) gives us the unconstrained
optimization problem
min
w,b1
2∥w∥2
|{z}
regularizer+CNX
n=1max{0,1−yn(⟨w,xn⟩+b)}
| {z }
error term. (12.31)
The first term in (12.31) is called the regularization term or the regularizer regularizer
(see Section 8.2.3), and the second term is called the loss term or the error loss term
error termterm. Recall from Section 12.2.4 that the term1
2∥w∥2arises directly from
the margin. In other words, margin maximization can be interpreted as
regularization . regularization
In principle, the unconstrained optimization problem in (12.31) can
be directly solved with (sub-)gradient descent methods as described in
Section 7.1. To see that (12.31) and (12.26a) are equivalent, observe that
the hinge loss (12.28) essentially consists of two linear parts, as expressed
in (12.29). Consider the hinge loss for a single example-label pair (12.28).
We can equivalently replace minimization of the hinge loss over twith a
minimization of a slack variable ξwith two constraints. In equation form,
min
tmax{0,1−t} (12.32)
is equivalent to
min
ξ,tξ
subject to ξ⩾0, ξ⩾1−t .(12.33)
By substituting this expression into (12.31) and rearranging one of the
constraints, we obtain exactly the soft margin SVM (12.26a).
Remark. Let us contrast our choice of the loss function in this section to the
loss function for linear regression in Chapter 9. Recall from Section 9.2.1
that for finding maximum likelihood estimators, we usually minimize the
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
12.3 Dual Support Vector Machine 383
negative log-likelihood. Furthermore, since the likelihood term for linear
regression with Gaussian noise is Gaussian, the negative log-likelihood for
each example is a squared error function. The squared error function is the
loss function that is minimized when looking for the maximum likelihood
solution. ♢
12.3 Dual Support Vector Machine
The description of the SVM in the previous sections, in terms of the vari-
ableswandb, is known as the primal SVM. Recall that we consider inputs
x∈RDwith Dfeatures. Since wis of the same dimension as x, this
means that the number of parameters (the dimension of w) of the opti-
mization problem grows linearly with the number of features.
In the following, we consider an equivalent optimization problem (the
so-called dual view), which is independent of the number of features. In-
stead, the number of parameters increases with the number of examples
in the training set. We saw a similar idea appear in Chapter 10, where we
expressed the learning problem in a way that does not scale with the num-
ber of features. This is useful for problems where we have more features
than the number of examples in the training dataset. The dual SVM also
has the additional advantage that it easily allows kernels to be applied,
as we shall see at the end of this chapter. The word “dual” appears often
in mathematical literature, and in this particular case it refers to convex
duality. The following subsections are essentially an application of convex
duality, which we discussed in Section 7.2.
12.3.1 Convex Duality via Lagrange Multipliers
Recall the primal soft margin SVM (12.26a). We call the variables w,b,
andξcorresponding to the primal SVM the primal variables. We use αn⩾ In Chapter 7, we
usedλas Lagrange
multipliers. In this
section, we follow
the notation
commonly chosen in
SVM literature, and
useαandγ.0as the Lagrange multiplier corresponding to the constraint (12.26b) that
the examples are classified correctly and γn⩾0as the Lagrange multi-
plier corresponding to the non-negativity constraint of the slack variable;
see (12.26c). The Lagrangian is then given by
L(w, b, ξ, α, γ ) =1
2∥w∥2+CNX
n=1ξn (12.34)
−NX
n=1αn(yn(⟨w,xn⟩+b)−1 +ξn)
| {z }
constraint (12.26b)−NX
n=1γnξn
|{z}
constraint (12.26c).
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
384 Classification with Support Vector Machines
By differentiating the Lagrangian (12.34) with respect to the three primal
variables w,b, and ξrespectively, we obtain
∂L
∂w=w⊤−NX
n=1αnynxn⊤, (12.35)
∂L
∂b=−NX
n=1αnyn, (12.36)
∂L
∂ξn=C−αn−γn. (12.37)
We now find the maximum of the Lagrangian by setting each of these
partial derivatives to zero. By setting (12.35) to zero, we find
w=NX
n=1αnynxn, (12.38)
which is a particular instance of the representer theorem (Kimeldorf and representer theorem
Wahba, 1970). Equation (12.38) states that the optimal weight vector in The representer
theorem is actually
a collection of
theorems saying
that the solution of
minimizing
empirical risk lies in
the subspace
(Section 2.4.3)
defined by the
examples.the primal is a linear combination of the examples xn. Recall from Sec-
tion 2.6.1 that this means that the solution of the optimization problem
lies in the span of training data. Additionally, the constraint obtained by
setting (12.36) to zero implies that the optimal weight vector is an affine
combination of the examples. The representer theorem turns out to hold
for very general settings of regularized empirical risk minimization (Hof-
mann et al., 2008; Argyriou and Dinuzzo, 2014). The theorem has more
general versions (Sch ¨olkopf et al., 2001), and necessary and sufficient
conditions on its existence can be found in Yu et al. (2013).
Remark. The representer theorem (12.38) also provides an explanation
of the name “support vector machine.” The examples xn, for which the
corresponding parameters αn= 0, do not contribute to the solution wat
all. The other examples, where αn>0, are called support vectors since support vector
they “support” the hyperplane. ♢
By substituting the expression for winto the Lagrangian (12.34), we
obtain the dual
D(ξ, α, γ ) =1
2NX
i=1NX
j=1yiyjαiαj⟨xi,xj⟩ −NX
i=1yiαi*NX
j=1yjαjxj,xi+
+CNX
i=1ξi−bNX
i=1yiαi+NX
i=1αi−NX
i=1αiξi−NX
i=1γiξi.
(12.39)
Note that there are no longer any terms involving the primal variable w.
By setting (12.36) to zero, we obtainPN
n=1ynαn= 0. Therefore, the term
involving balso vanishes. Recall that inner products are symmetric and
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
12.3 Dual Support Vector Machine 385
bilinear (see Section 3.2). Therefore, the first two terms in (12.39) are
over the same objects. These terms (colored blue) can be simplified, and
we obtain the Lagrangian
D(ξ, α, γ ) =−1
2NX
i=1NX
j=1yiyjαiαj⟨xi,xj⟩+NX
i=1αi+NX
i=1(C−αi−γi)ξi.
(12.40)
The last term in this equation is a collection of all terms that contain slack
variables ξi. By setting (12.37) to zero, we see that the last term in (12.40)
is also zero. Furthermore, by using the same equation and recalling that
the Lagrange multiplers γiare non-negative, we conclude that αi⩽C.
We now obtain the dual optimization problem of the SVM, which is ex-
pressed exclusively in terms of the Lagrange multipliers αi. Recall from
Lagrangian duality (Definition 7.1) that we maximize the dual problem.
This is equivalent to minimizing the negative dual problem, such that we
end up with the dual SVM dual SVM
min
α1
2NX
i=1NX
j=1yiyjαiαj⟨xi,xj⟩ −NX
i=1αi
subject toNX
i=1yiαi= 0
0⩽αi⩽Cfor all i= 1, . . . , N .(12.41)
The equality constraint in (12.41) is obtained from setting (12.36) to
zero. The inequality constraint αi⩾0is the condition imposed on La-
grange multipliers of inequality constraints (Section 7.2). The inequality
constraint αi⩽Cis discussed in the previous paragraph.
The set of inequality constraints in the SVM are called “box constraints”
because they limit the vector α= [α1,···, αN]⊤∈RNof Lagrange mul-
tipliers to be inside the box defined by 0andCon each axis. These
axis-aligned boxes are particularly efficient to implement in numerical
solvers (Dost ´al, 2009, chapter 5). It turns out that
examples that lie
exactly on the
margin are
examples whose
dual parameters lie
strictly inside the
box constraints,
0< αi< C. This is
derived using the
Karush Kuhn Tucker
conditions, for
example in
Sch¨olkopf and
Smola (2002).Once we obtain the dual parameters α, we can recover the primal pa-
rameters wby using the representer theorem (12.38). Let us call the op-
timal primal parameter w∗. However, there remains the question on how
to obtain the parameter b∗. Consider an example xnthat lies exactly on
the margin’s boundary, i.e., ⟨w∗,xn⟩+b=yn. Recall that ynis either +1
or−1. Therefore, the only unknown is b, which can be computed by
b∗=yn− ⟨w∗,xn⟩. (12.42)
Remark. In principle, there may be no examples that lie exactly on the
margin. In this case, we should compute |yn− ⟨w∗,xn⟩|for all support
vectors and take the median value of this absolute value difference to be
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
386 Classification with Support Vector Machines
Figure 12.9 Convex
hulls. (a) Convex
hull of points, some
of which lie within
the boundary;
(b) convex hulls
around positive and
negative examples.
(a) Convex hull.
c
d (b) Convex hulls around positive (blue) and
negative (orange) examples. The distance be-
tween the two convex sets is the length of the
difference vector c−d.
the value of b∗. A derivation of this can be found in http://fouryears.
eu/2012/06/07/the-svm-bias-term-conspiracy/ . ♢
12.3.2 Dual SVM: Convex Hull View
Another approach to obtain the dual SVM is to consider an alternative
geometric argument. Consider the set of examples xnwith the same label.
We would like to build a convex set that contains all the examples such
that it is the smallest possible set. This is called the convex hull and is
illustrated in Figure 12.9.
Let us first build some intuition about a convex combination of points.
Consider two points x1andx2and corresponding non-negative weights
α1, α2⩾0such that α1+α2= 1. The equation α1x1+α2x2describes each
point on a line between x1andx2. Consider what happens when we add
a third point x3along with a weight α3⩾0such thatP3
n=1αn= 1.
The convex combination of these three points x1,x2,x3spans a two-
dimensional area. The convex hull of this area is the triangle formed by convex hull
the edges corresponding to each pair of of points. As we add more points,
and the number of points becomes greater than the number of dimen-
sions, some of the points will be inside the convex hull, as we can see in
Figure 12.9(a).
In general, building a convex convex hull can be done by introducing
non-negative weights αn⩾0corresponding to each example xn. Then
the convex hull can be described as the set
conv ( X) =(NX
n=1αnxn)
withNX
n=1αn= 1 and αn⩾0,(12.43)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
12.3 Dual Support Vector Machine 387
for all n= 1, . . . , N . If the two clouds of points corresponding to the
positive and negative classes are separated, then the convex hulls do not
overlap. Given the training data (x1, y1), . . . , (xN, yN), we form two con-
vex hulls, corresponding to the positive and negative classes respectively.
We pick a point c, which is in the convex hull of the set of positive exam-
ples, and is closest to the negative class distribution. Similarly, we pick a
pointdin the convex hull of the set of negative examples and is closest to
the positive class distribution; see Figure 12.9(b). We define a difference
vector between dandcas
w:=c−d. (12.44)
Picking the points canddas in the preceding cases, and requiring them
to be closest to each other is equivalent to minimizing the length/norm of
w, so that we end up with the corresponding optimization problem
arg min
w∥w∥= arg min
w1
2∥w∥2. (12.45)
Sincecmust be in the positive convex hull, it can be expressed as a convex
combination of the positive examples, i.e., for non-negative coefficients
α+
n
c=X
n:yn=+1α+
nxn. (12.46)
In (12.46), we use the notation n:yn= +1 to indicate the set of indices
nfor which yn= +1 . Similarly, for the examples with negative labels, we
obtain
d=X
n:yn=−1α−
nxn. (12.47)
By substituting (12.44), (12.46), and (12.47) into (12.45), we obtain the
objective
min
α1
2X
n:yn=+1α+
nxn−X
n:yn=−1α−
nxn2
. (12.48)
Letαbe the set of all coefficients, i.e., the concatenation of α+andα−.
Recall that we require that for each convex hull that their coefficients sum
to one,
X
n:yn=+1α+
n= 1 andX
n:yn=−1α−
n= 1. (12.49)
This implies the constraint
NX
n=1ynαn= 0. (12.50)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
388 Classification with Support Vector Machines
This result can be seen by multiplying out the individual classes
NX
n=1ynαn=X
n:yn=+1(+1)α+
n+X
n:yn=−1(−1)α−
n (12.51a)
=X
n:yn=+1α+
n−X
n:yn=−1α−
n= 1−1 = 0 . (12.51b)
The objective function (12.48) and the constraint (12.50), along with the
assumption that α⩾0, give us a constrained (convex) optimization prob-
lem. This optimization problem can be shown to be the same as that of
the dual hard margin SVM (Bennett and Bredensteiner, 2000a).
Remark. To obtain the soft margin dual, we consider the reduced hull. The
reduced hull is similar to the convex hull but has an upper bound to the reduced hull
size of the coefficients α. The maximum possible value of the elements
ofαrestricts the size that the convex hull can take. In other words, the
bound on αshrinks the convex hull to a smaller volume (Bennett and
Bredensteiner, 2000b). ♢
12.4 Kernels
Consider the formulation of the dual SVM (12.41). Notice that the in-
ner product in the objective occurs only between examples xiandxj.
There are no inner products between the examples and the parameters.
Therefore, if we consider a set of features ϕ(xi)to represent xi, the only
change in the dual SVM will be to replace the inner product. This mod-
ularity, where the choice of the classification method (the SVM) and the
choice of the feature representation ϕ(x)can be considered separately,
provides flexibility for us to explore the two problems independently. In
this section, we discuss the representation ϕ(x)and briefly introduce the
idea of kernels, but do not go into the technical details.
Sinceϕ(x)could be a non-linear function, we can use the SVM (which
assumes a linear classifier) to construct classifiers that are nonlinear in
the examples xn. This provides a second avenue, in addition to the soft
margin, for users to deal with a dataset that is not linearly separable. It
turns out that there are many algorithms and statistical methods that have
this property that we observed in the dual SVM: the only inner products
are those that occur between examples. Instead of explicitly defining a
non-linear feature map ϕ(·)and computing the resulting inner product
between examples xiandxj, we define a similarity function k(xi,xj)be-
tween xiandxj. For a certain class of similarity functions, called kernels , kernel
the similarity function implicitly defines a non-linear feature map ϕ(·).
Kernels are by definition functions k:X × X → Rfor which there exists The inputs Xof the
kernel function can
be very general and
are not necessarily
restricted to RD.a Hilbert space Handϕ:X → H a feature map such that
k(xi,xj) =⟨ϕ(xi),ϕ(xj)⟩H. (12.52)
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
12.4 Kernels 389
Figure 12.10 SVM
with different
kernels. Note that
while the decision
boundary is
nonlinear, the
underlying problem
being solved is for a
linear separating
hyperplane (albeit
with a nonlinear
kernel).
First featureSecond feature
(a) SVM with linear kernel
First featureSecond feature (b) SVM with RBF kernel
First featureSecond feature
(c) SVM with polynomial (degree 2) kernel
First featureSecond feature (d) SVM with polynomial (degree 3) kernel
There is a unique reproducing kernel Hilbert space associated with every
kernel k(Aronszajn, 1950; Berlinet and Thomas-Agnan, 2004). In this
unique association, ϕ(x) =k(·,x)is called the canonical feature map .canonical feature
map The generalization from an inner product to a kernel function (12.52) is
known as the kernel trick (Sch¨olkopf and Smola, 2002; Shawe-Taylor and kernel trick
Cristianini, 2004), as it hides away the explicit non-linear feature map.
The matrix K∈RN×N, resulting from the inner products or the appli-
cation of k(·,·)to a dataset, is called the Gram matrix , and is often just Gram matrix
referred to as the kernel matrix . Kernels must be symmetric and positive kernel matrix
semidefinite functions so that every kernel matrix Kis symmetric and
positive semidefinite (Section 3.2.3):
∀z∈RN:z⊤Kz⩾0. (12.53)
Some popular examples of kernels for multivariate real-valued data xi∈
RDare the polynomial kernel, the Gaussian radial basis function kernel,
and the rational quadratic kernel (Sch ¨olkopf and Smola, 2002; Rasmussen
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
390 Classification with Support Vector Machines
and Williams, 2006). Figure 12.10 illustrates the effect of different kernels
on separating hyperplanes on an example dataset. Note that we are still
solving for hyperplanes, that is, the hypothesis class of functions are still
linear. The non-linear surfaces are due to the kernel function.
Remark. Unfortunately for the fledgling machine learner, there are mul-
tiple meanings of the word “kernel.” In this chapter, the word “kernel”
comes from the idea of the reproducing kernel Hilbert space (RKHS) (Aron-
szajn, 1950; Saitoh, 1988). We have discussed the idea of the kernel in lin-
ear algebra (Section 2.7.3), where the kernel is another word for the null
space. The third common use of the word “kernel” in machine learning is
the smoothing kernel in kernel density estimation (Section 11.5). ♢
Since the explicit representation ϕ(x)is mathematically equivalent to
the kernel representation k(xi,xj), a practitioner will often design the
kernel function such that it can be computed more efficiently than the
inner product between explicit feature maps. For example, consider the
polynomial kernel (Sch ¨olkopf and Smola, 2002), where the number of
terms in the explicit expansion grows very quickly (even for polynomials
of low degree) when the input dimension is large. The kernel function
only requires one multiplication per input dimension, which can provide
significant computational savings. Another example is the Gaussian ra-
dial basis function kernel (Sch ¨olkopf and Smola, 2002; Rasmussen and
Williams, 2006), where the corresponding feature space is infinite dimen-
sional. In this case, we cannot explicitly represent the feature space but
can still compute similarities between a pair of examples using the kernel. The choice of
kernel, as well as
the parameters of
the kernel, is often
chosen using nested
cross-validation
(Section 8.6.1).Another useful aspect of the kernel trick is that there is no need for
the original data to be already represented as multivariate real-valued
data. Note that the inner product is defined on the output of the function
ϕ(·), but does not restrict the input to real numbers. Hence, the function
ϕ(·)and the kernel function k(·,·)can be defined on any object, e.g.,
sets, sequences, strings, graphs, and distributions (Ben-Hur et al., 2008;
G¨artner, 2008; Shi et al., 2009; Sriperumbudur et al., 2010; Vishwanathan
et al., 2010).
12.5 Numerical Solution
We conclude our discussion of SVMs by looking at how to express the
problems derived in this chapter in terms of the concepts presented in
Chapter 7. We consider two different approaches for finding the optimal
solution for the SVM. First we consider the loss view of SVM 8.2.2 and ex-
press this as an unconstrained optimization problem. Then we express the
constrained versions of the primal and dual SVMs as quadratic programs
in standard form 7.3.2.
Consider the loss function view of the SVM (12.31). This is a convex
unconstrained optimization problem, but the hinge loss (12.28) is not dif-
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
12.5 Numerical Solution 391
ferentiable. Therefore, we apply a subgradient approach for solving it.
However, the hinge loss is differentiable almost everywhere, except for
one single point at the hinge t= 1. At this point, the gradient is a set of
possible values that lie between 0and−1. Therefore, the subgradient gof
the hinge loss is given by
g(t) =

−1 t <1
[−1,0]t= 1
0 t >1. (12.54)
Using this subgradient, we can apply the optimization methods presented
in Section 7.1.
Both the primal and the dual SVM result in a convex quadratic pro-
gramming problem (constrained optimization). Note that the primal SVM
in (12.26a) has optimization variables that have the size of the dimen-
sionDof the input examples. The dual SVM in (12.41) has optimization
variables that have the size of the number Nof examples.
To express the primal SVM in the standard form (7.45) for quadratic
programming, let us assume that we use the dot product (3.5) as the
inner product. We rearrange the equation for the primal SVM (12.26a), Recall from
Section 3.2 that we
use the phrase dot
product to mean the
inner product on
Euclidean vector
space.such that the optimization variables are all on the right and the inequality
of the constraint matches the standard form. This yields the optimization
min
w,b,ξ1
2∥w∥2+CNX
n=1ξn
subject to−ynx⊤
nw−ynb−ξn⩽−1
−ξn⩽0(12.55)
n= 1, . . . , N . By concatenating the variables w, b,xninto a single vector,
and carefully collecting the terms, we obtain the following matrix form of
the soft margin SVM:
min
w,b,ξ1
2
w
b
ξ
⊤ID 0D,N+1
0N+1,D0N+1,N+1
w
b
ξ
+0D+1,1C1N,1⊤
w
b
ξ

subject to−Y X −y−IN
0N,D+1 −IN
w
b
ξ
⩽−1N,1
0N,1
.
(12.56)
In the preceding optimization problem, the minimization is over the pa-
rameters [w⊤, b,ξ⊤]⊤∈RD+1+N, and we use the notation: Imto rep-
resent the identity matrix of size m×m,0m,nto represent the matrix
of zeros of size m×n, and 1m,nto represent the matrix of ones of size
m×n. In addition, yis the vector of labels [y1,···, yN]⊤,Y= diag( y)
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
392 Classification with Support Vector Machines
is an NbyNmatrix where the elements of the diagonal are from y, and
X∈RN×Dis the matrix obtained by concatenating all the examples.
We can similarly perform a collection of terms for the dual version of the
SVM (12.41). To express the dual SVM in standard form, we first have to
express the kernel matrix Ksuch that each entry is Kij=k(xi,xj). If we
have an explicit feature representation xithen we define Kij=⟨xi,xj⟩.
For convenience of notation we introduce a matrix with zeros everywhere
except on the diagonal, where we store the labels, that is, Y= diag( y).
The dual SVM can be written as
min
α1
2α⊤Y KY α −1⊤
N,1α
subject to
y⊤
−y⊤
−IN
IN
α⩽0N+2,1
C1N,1
.(12.57)
Remark. In Sections 7.3.1 and 7.3.2, we introduced the standard forms
of the constraints to be inequality constraints. We will express the dual
SVM’s equality constraint as two inequality constraints, i.e.,
Ax=bis replaced by Ax⩽band Ax⩾b. (12.58)
Particular software implementations of convex optimization methods may
provide the ability to express equality constraints. ♢
Since there are many different possible views of the SVM, there are
many approaches for solving the resulting optimization problem. The ap-
proach presented here, expressing the SVM problem in standard convex
optimization form, is not often used in practice. The two main implemen-
tations of SVM solvers are Chang and Lin (2011) (which is open source)
and Joachims (1999). Since SVMs have a clear and well-defined optimiza-
tion problem, many approaches based on numerical optimization tech-
niques (Nocedal and Wright, 2006) can be applied (Shawe-Taylor and
Sun, 2011).
12.6 Further Reading
The SVM is one of many approaches for studying binary classification.
Other approaches include the perceptron, logistic regression, Fisher dis-
criminant, nearest neighbor, naive Bayes, and random forest (Bishop, 2006;
Murphy, 2012). A short tutorial on SVMs and kernels on discrete se-
quences can be found in Ben-Hur et al. (2008). The development of SVMs
is closely linked to empirical risk minimization, discussed in Section 8.2.
Hence, the SVM has strong theoretical properties (Vapnik, 2000; Stein-
wart and Christmann, 2008). The book about kernel methods (Sch ¨olkopf
and Smola, 2002) includes many details of support vector machines and
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
12.6 Further Reading 393
how to optimize them. A broader book about kernel methods (Shawe-
Taylor and Cristianini, 2004) also includes many linear algebra approaches
for different machine learning problems.
An alternative derivation of the dual SVM can be obtained using the
idea of the Legendre–Fenchel transform (Section 7.3.3). The derivation
considers each term of the unconstrained formulation of the SVM (12.31)
separately and calculates their convex conjugates (Rifkin and Lippert,
2007). Readers interested in the functional analysis view (also the reg-
ularization methods view) of SVMs are referred to the work by Wahba
(1990). Theoretical exposition of kernels (Aronszajn, 1950; Schwartz,
1964; Saitoh, 1988; Manton and Amblard, 2015) requires a basic ground-
ing in linear operators (Akhiezer and Glazman, 1993). The idea of kernels
have been generalized to Banach spaces (Zhang et al., 2009) and Kre ˘ın
spaces (Ong et al., 2004; Loosli et al., 2016).
Observe that the hinge loss has three equivalent representations, as
shown in (12.28) and (12.29), as well as the constrained optimization
problem in (12.33). The formulation (12.28) is often used when compar-
ing the SVM loss function with other loss functions (Steinwart, 2007).
The two-piece formulation (12.29) is convenient for computing subgra-
dients, as each piece is linear. The third formulation (12.33), as seen
in Section 12.5, enables the use of convex quadratic programming (Sec-
tion 7.3.2) tools.
Since binary classification is a well-studied task in machine learning,
other words are also sometimes used, such as discrimination, separation,
and decision. Furthermore, there are three quantities that can be the out-
put of a binary classifier. First is the output of the linear function itself
(often called the score), which can take any real value. This output can be
used for ranking the examples, and binary classification can be thought
of as picking a threshold on the ranked examples (Shawe-Taylor and Cris-
tianini, 2004). The second quantity that is often considered the output
of a binary classifier is the output determined after it is passed through
a non-linear function to constrain its value to a bounded range, for ex-
ample in the interval [0,1]. A common non-linear function is the sigmoid
function (Bishop, 2006). When the non-linearity results in well-calibrated
probabilities (Gneiting and Raftery, 2007; Reid and Williamson, 2011),
this is called class probability estimation. The third output of a binary
classifier is the final binary decision {+1,−1}, which is the one most com-
monly assumed to be the output of the classifier.
The SVM is a binary classifier that does not naturally lend itself to a
probabilistic interpretation. There are several approaches for converting
the raw output of the linear function (the score) into a calibrated class
probability estimate ( P(Y= 1|X=x)) that involve an additional cal-
ibration step (Platt, 2000; Zadrozny and Elkan, 2001; Lin et al., 2007).
From the training perspective, there are many related probabilistic ap-
proaches. We mentioned at the end of Section 12.2.5 that there is a re-
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
394 Classification with Support Vector Machines
lationship between loss function and the likelihood (also compare Sec-
tions 8.2 and 8.3). The maximum likelihood approach corresponding to
a well-calibrated transformation during training is called logistic regres-
sion, which comes from a class of methods called generalized linear mod-
els. Details of logistic regression from this point of view can be found in
Agresti (2002, chapter 5) and McCullagh and Nelder (1989, chapter 4).
Naturally, one could take a more Bayesian view of the classifier output by
estimating a posterior distribution using Bayesian logistic regression. The
Bayesian view also includes the specification of the prior, which includes
design choices such as conjugacy (Section 6.6.1) with the likelihood. Ad-
ditionally, one could consider latent functions as priors, which results in
Gaussian process classification (Rasmussen and Williams, 2006, chapter
3).
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
References
Abel, Niels H. 1826. D´emonstration de l’Impossibilit ´e de la R ´esolution Alg ´ebrique des
´Equations G ´en´erales qui Passent le Quatri `eme Degr ´e. Grøndahl and Søn.
Adhikari, Ani, and DeNero, John. 2018. Computational and Inferential Thinking: The
Foundations of Data Science . Gitbooks.
Agarwal, Arvind, and Daum ´e III, Hal. 2010. A Geometric View of Conjugate Priors.
Machine Learning ,81(1), 99–113.
Agresti, A. 2002. Categorical Data Analysis . Wiley.
Akaike, Hirotugu. 1974. A New Look at the Statistical Model Identification. IEEE
Transactions on Automatic Control ,19(6), 716–723.
Akhiezer, Naum I., and Glazman, Izrail M. 1993. Theory of Linear Operators in Hilbert
Space . Dover Publications.
Alpaydin, Ethem. 2010. Introduction to Machine Learning . MIT Press.
Amari, Shun-ichi. 2016. Information Geometry and Its Applications . Springer.
Argyriou, Andreas, and Dinuzzo, Francesco. 2014. A Unifying View of Representer
Theorems. In: Proceedings of the International Conference on Machine Learning .
Aronszajn, Nachman. 1950. Theory of Reproducing Kernels. Transactions of the Amer-
ican Mathematical Society ,68, 337–404.
Axler, Sheldon. 2015. Linear Algebra Done Right . Springer.
Bakir, G ¨okhan, Hofmann, Thomas, Sch ¨olkopf, Bernhard, Smola, Alexander J., Taskar,
Ben, and Vishwanathan, S. V. N. (eds). 2007. Predicting Structured Data . MIT Press.
Barber, David. 2012. Bayesian Reasoning and Machine Learning . Cambridge University
Press.
Barndorff-Nielsen, Ole. 2014. Information and Exponential Families: In Statistical The-
ory. Wiley.
Bartholomew, David, Knott, Martin, and Moustaki, Irini. 2011. Latent Variable Models
and Factor Analysis: A Unified Approach . Wiley.
Baydin, Atılım G., Pearlmutter, Barak A., Radul, Alexey A., and Siskind, Jeffrey M.
2018. Automatic Differentiation in Machine Learning: A Survey. Journal of Machine
Learning Research ,18, 1–43.
Beck, Amir, and Teboulle, Marc. 2003. Mirror Descent and Nonlinear Projected Subgra-
dient Methods for Convex Optimization. Operations Research Letters ,31(3), 167–
175.
Belabbas, Mohamed-Ali, and Wolfe, Patrick J. 2009. Spectral Methods in Machine
Learning and New Strategies for Very Large Datasets. Proceedings of the National
Academy of Sciences , 0810600105.
Belkin, Mikhail, and Niyogi, Partha. 2003. Laplacian Eigenmaps for Dimensionality
Reduction and Data Representation. Neural Computation ,15(6), 1373–1396.
Ben-Hur, Asa, Ong, Cheng Soon, Sonnenburg, S ¨oren, Sch ¨olkopf, Bernhard, and R ¨atsch,
Gunnar. 2008. Support Vector Machines and Kernels for Computational Biology.
PLoS Computational Biology ,4(10), e1000173.
395
This material is published by Cambridge University Press as Mathematics for Machine Learning by
Marc Peter Deisenroth, A. Aldo Faisal, and Cheng Soon Ong (2020). This version is free to view
and download for personal use only. Not for re-distribution, re-sale, or use in derivative works.
©by M. P. Deisenroth, A. A. Faisal, and C. S. Ong, 2024. https://mml-book.com .
396 References
Bennett, Kristin P., and Bredensteiner, Erin J. 2000a. Duality and Geometry in SVM
Classifiers. In: Proceedings of the International Conference on Machine Learning .
Bennett, Kristin P., and Bredensteiner, Erin J. 2000b. Geometry in Learning. Pages
132–145 of: Geometry at Work . Mathematical Association of America.
Berlinet, Alain, and Thomas-Agnan, Christine. 2004. Reproducing Kernel Hilbert Spaces
in Probability and Statistics . Springer.
Bertsekas, Dimitri P. 1999. Nonlinear Programming . Athena Scientific.
Bertsekas, Dimitri P. 2009. Convex Optimization Theory . Athena Scientific.
Bickel, Peter J., and Doksum, Kjell. 2006. Mathematical Statistics, Basic Ideas and
Selected Topics . Vol. 1. Prentice Hall.
Bickson, Danny, Dolev, Danny, Shental, Ori, Siegel, Paul H., and Wolf, Jack K. 2007.
Linear Detection via Belief Propagation. In: Proceedings of the Annual Allerton Con-
ference on Communication, Control, and Computing .
Billingsley, Patrick. 1995. Probability and Measure . Wiley.
Bishop, Christopher M. 1995. Neural Networks for Pattern Recognition . Clarendon
Press.
Bishop, Christopher M. 1999. Bayesian PCA. In: Advances in Neural Information Pro-
cessing Systems .
Bishop, Christopher M. 2006. Pattern Recognition and Machine Learning . Springer.
Blei, David M., Kucukelbir, Alp, and McAuliffe, Jon D. 2017. Variational Inference: A
Review for Statisticians. Journal of the American Statistical Association ,112(518),
859–877.
Blum, Arvim, and Hardt, Moritz. 2015. The Ladder: A Reliable Leaderboard for Ma-
chine Learning Competitions. In: International Conference on Machine Learning .
Bonnans, J. Fr ´ed´eric, Gilbert, J. Charles, Lemar ´echal, Claude, and Sagastiz ´abal, Clau-
dia A. 2006. Numerical Optimization: Theoretical and Practical Aspects . Springer.
Borwein, Jonathan M., and Lewis, Adrian S. 2006. Convex Analysis and Nonlinear
Optimization . 2nd edn. Canadian Mathematical Society.
Bottou, L ´eon. 1998. Online Algorithms and Stochastic Approximations. Pages 9–42
of:Online Learning and Neural Networks . Cambridge University Press.
Bottou, L ´eon, Curtis, Frank E., and Nocedal, Jorge. 2018. Optimization Methods for
Large-Scale Machine Learning. SIAM Review ,60(2), 223–311.
Boucheron, Stephane, Lugosi, Gabor, and Massart, Pascal. 2013. Concentration In-
equalities: A Nonasymptotic Theory of Independence. Oxford University Press.
Boyd, Stephen, and Vandenberghe, Lieven. 2004. Convex Optimization . Cambridge
University Press.
Boyd, Stephen, and Vandenberghe, Lieven. 2018. Introduction to Applied Linear Alge-
bra. Cambridge University Press.
Brochu, Eric, Cora, Vlad M., and de Freitas, Nando. 2009. A Tutorial on Bayesian
Optimization of Expensive Cost Functions, with Application to Active User Modeling
and Hierarchical Reinforcement Learning . Tech. rept. TR-2009-023. Department of
Computer Science, University of British Columbia.
Brooks, Steve, Gelman, Andrew, Jones, Galin L., and Meng, Xiao-Li (eds). 2011. Hand-
book of Markov Chain Monte Carlo . Chapman and Hall/CRC.
Brown, Lawrence D. 1986. Fundamentals of Statistical Exponential Families: With Ap-
plications in Statistical Decision Theory . Institute of Mathematical Statistics.
Bryson, Arthur E. 1961. A Gradient Method for Optimizing Multi-Stage Allocation
Processes. In: Proceedings of the Harvard University Symposium on Digital Computers
and Their Applications .
Bubeck, S ´ebastien. 2015. Convex Optimization: Algorithms and Complexity. Founda-
tions and Trends in Machine Learning ,8(3-4), 231–357.
B¨uhlmann, Peter, and Van De Geer, Sara. 2011. Statistics for High-Dimensional Data .
Springer.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
References 397
Burges, Christopher. 2010. Dimension Reduction: A Guided Tour. Foundations and
Trends in Machine Learning ,2(4), 275–365.
Carroll, J Douglas, and Chang, Jih-Jie. 1970. Analysis of Individual Differences in
Multidimensional Scaling via an N-Way Generalization of “Eckart-Young” Decom-
position. Psychometrika ,35(3), 283–319.
Casella, George, and Berger, Roger L. 2002. Statistical Inference . Duxbury.
C ¸inlar, Erhan. 2011. Probability and Stochastics . Springer.
Chang, Chih-Chung, and Lin, Chih-Jen. 2011. LIBSVM: A Library for Support Vector
Machines. ACM Transactions on Intelligent Systems and Technology ,2, 27:1–27:27.
Cheeseman, Peter. 1985. In Defense of Probability. In: Proceedings of the International
Joint Conference on Artificial Intelligence .
Chollet, Francois, and Allaire, J. J. 2018. Deep Learning with R . Manning Publications.
Codd, Edgar F. 1990. The Relational Model for Database Management . Addison-Wesley
Longman Publishing.
Cunningham, John P., and Ghahramani, Zoubin. 2015. Linear Dimensionality Reduc-
tion: Survey, Insights, and Generalizations. Journal of Machine Learning Research ,
16, 2859–2900.
Datta, Biswa N. 2010. Numerical Linear Algebra and Applications . SIAM.
Davidson, Anthony C., and Hinkley, David V. 1997. Bootstrap Methods and Their Appli-
cation . Cambridge University Press.
Dean, Jeffrey, Corrado, Greg S., Monga, Rajat, and Chen, et al. 2012. Large Scale
Distributed Deep Networks. In: Advances in Neural Information Processing Systems .
Deisenroth, Marc P., and Mohamed, Shakir. 2012. Expectation Propagation in Gaus-
sian Process Dynamical Systems. Pages 2618–2626 of: Advances in Neural Informa-
tion Processing Systems .
Deisenroth, Marc P., and Ohlsson, Henrik. 2011. A General Perspective on Gaussian
Filtering and Smoothing: Explaining Current and Deriving New Algorithms. In:
Proceedings of the American Control Conference .
Deisenroth, Marc P., Fox, Dieter, and Rasmussen, Carl E. 2015. Gaussian Processes
for Data-Efficient Learning in Robotics and Control. IEEE Transactions on Pattern
Analysis and Machine Intelligence ,37(2), 408–423.
Dempster, Arthur P., Laird, Nan M., and Rubin, Donald B. 1977. Maximum Likelihood
from Incomplete Data via the EM Algorithm. Journal of the Royal Statistical Society ,
39(1), 1–38.
Deng, Li, Seltzer, Michael L., Yu, Dong, Acero, Alex, Mohamed, Abdel-rahman, and
Hinton, Geoffrey E. 2010. Binary Coding of Speech Spectrograms Using a Deep
Auto-Encoder. In: Proceedings of Interspeech .
Devroye, Luc. 1986. Non-Uniform Random Variate Generation . Springer.
Donoho, David L., and Grimes, Carrie. 2003. Hessian Eigenmaps: Locally Linear
Embedding Techniques for High-Dimensional Data. Proceedings of the National
Academy of Sciences ,100(10), 5591–5596.
Dost´al, Zden ˘ek. 2009. Optimal Quadratic Programming Algorithms: With Applications
to Variational Inequalities . Springer.
Douven, Igor. 2017. Abduction. In: The Stanford Encyclopedia of Philosophy . Meta-
physics Research Lab, Stanford University.
Downey, Allen B. 2014. Think Stats: Exploratory Data Analysis . 2nd edn. O’Reilly
Media.
Dreyfus, Stuart. 1962. The Numerical Solution of Variational Problems. Journal of
Mathematical Analysis and Applications ,5(1), 30–45.
Drumm, Volker, and Weil, Wolfgang. 2001. Lineare Algebra und Analytische Geometrie .
Lecture Notes, Universit ¨at Karlsruhe (TH).
Dudley, Richard M. 2002. Real Analysis and Probability . Cambridge University Press.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
398 References
Eaton, Morris L. 2007. Multivariate Statistics: A Vector Space Approach . Institute of
Mathematical Statistics Lecture Notes.
Eckart, Carl, and Young, Gale. 1936. The Approximation of One Matrix by Another of
Lower Rank. Psychometrika ,1(3), 211–218.
Efron, Bradley, and Hastie, Trevor. 2016. Computer Age Statistical Inference: Algorithms,
Evidence and Data Science . Cambridge University Press.
Efron, Bradley, and Tibshirani, Robert J. 1993. An Introduction to the Bootstrap . Chap-
man and Hall/CRC.
Elliott, Conal. 2009. Beautiful Differentiation. In: International Conference on Func-
tional Programming .
Evgeniou, Theodoros, Pontil, Massimiliano, and Poggio, Tomaso. 2000. Statistical
Learning Theory: A Primer. International Journal of Computer Vision ,38(1), 9–13.
Fan, Rong-En, Chang, Kai-Wei, Hsieh, Cho-Jui, Wang, Xiang-Rui, and Lin, Chih-Jen.
2008. LIBLINEAR: A Library for Large Linear Classification. Journal of Machine
Learning Research ,9, 1871–1874.
Gal, Yarin, van der Wilk, Mark, and Rasmussen, Carl E. 2014. Distributed Variational
Inference in Sparse Gaussian Process Regression and Latent Variable Models. In:
Advances in Neural Information Processing Systems .
G¨artner, Thomas. 2008. Kernels for Structured Data . World Scientific.
Gavish, Matan, and Donoho, David L. 2014. The Optimal Hard Threshold for Singular
Values is 4√
3.IEEE Transactions on Information Theory ,60(8), 5040–5053.
Gelman, Andrew, Carlin, John B., Stern, Hal S., and Rubin, Donald B. 2004. Bayesian
Data Analysis . Chapman and Hall/CRC.
Gentle, James E. 2004. Random Number Generation and Monte Carlo Methods .
Springer.
Ghahramani, Zoubin. 2015. Probabilistic Machine Learning and Artificial Intelligence.
Nature ,521, 452–459.
Ghahramani, Zoubin, and Roweis, Sam T. 1999. Learning Nonlinear Dynamical Sys-
tems Using an EM Algorithm. In: Advances in Neural Information Processing Systems .
MIT Press.
Gilks, Walter R., Richardson, Sylvia, and Spiegelhalter, David J. 1996. Markov Chain
Monte Carlo in Practice . Chapman and Hall/CRC.
Gneiting, Tilmann, and Raftery, Adrian E. 2007. Strictly Proper Scoring Rules, Pre-
diction, and Estimation. Journal of the American Statistical Association ,102(477),
359–378.
Goh, Gabriel. 2017. Why Momentum Really Works. Distill .
Gohberg, Israel, Goldberg, Seymour, and Krupnik, Nahum. 2012. Traces and Determi-
nants of Linear Operators . Birkh ¨auser.
Golan, Jonathan S. 2007. The Linear Algebra a Beginning Graduate Student Ought to
Know . Springer.
Golub, Gene H., and Van Loan, Charles F. 2012. Matrix Computations . JHU Press.
Goodfellow, Ian, Bengio, Yoshua, and Courville, Aaron. 2016. Deep Learning . MIT
Press.
Graepel, Thore, Candela, Joaquin Qui ˜nonero-Candela, Borchert, Thomas, and Her-
brich, Ralf. 2010. Web-Scale Bayesian Click-through Rate Prediction for Sponsored
Search Advertising in Microsoft’s Bing Search Engine. In: Proceedings of the Interna-
tional Conference on Machine Learning .
Griewank, Andreas, and Walther, Andrea. 2003. Introduction to Automatic Differenti-
ation. In: Proceedings in Applied Mathematics and Mechanics .
Griewank, Andreas, and Walther, Andrea. 2008. Evaluating Derivatives, Principles and
Techniques of Algorithmic Differentiation . SIAM.
Grimmett, Geoffrey R., and Welsh, Dominic. 2014. Probability: An Introduction . Oxford
University Press.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
References 399
Grinstead, Charles M., and Snell, J. Laurie. 1997. Introduction to Probability . American
Mathematical Society.
Hacking, Ian. 2001. Probability and Inductive Logic . Cambridge University Press.
Hall, Peter. 1992. The Bootstrap and Edgeworth Expansion . Springer.
Hallin, Marc, Paindaveine, Davy, and ˇSiman, Miroslav. 2010. Multivariate Quan-
tiles and Multiple-Output Regression Quantiles: From ℓ1Optimization to Halfspace
Depth. Annals of Statistics ,38, 635–669.
Hasselblatt, Boris, and Katok, Anatole. 2003. A First Course in Dynamics with a
Panorama of Recent Developments . Cambridge University Press.
Hastie, Trevor, Tibshirani, Robert, and Friedman, Jerome. 2001. The Elements of Sta-
tistical Learning – Data Mining, Inference, and Prediction . Springer.
Hausman, Karol, Springenberg, Jost T., Wang, Ziyu, Heess, Nicolas, and Riedmiller,
Martin. 2018. Learning an Embedding Space for Transferable Robot Skills. In:
Proceedings of the International Conference on Learning Representations .
Hazan, Elad. 2015. Introduction to Online Convex Optimization. Foundations and
Trends in Optimization ,2(3–4), 157–325.
Hensman, James, Fusi, Nicol `o, and Lawrence, Neil D. 2013. Gaussian Processes for
Big Data. In: Proceedings of the Conference on Uncertainty in Artificial Intelligence .
Herbrich, Ralf, Minka, Tom, and Graepel, Thore. 2007. TrueSkill(TM): A Bayesian
Skill Rating System. In: Advances in Neural Information Processing Systems .
Hiriart-Urruty, Jean-Baptiste, and Lemar ´echal, Claude. 2001. Fundamentals of Convex
Analysis . Springer.
Hoffman, Matthew D., Blei, David M., and Bach, Francis. 2010. Online Learning for
Latent Dirichlet Allocation. Advances in Neural Information Processing Systems .
Hoffman, Matthew D., Blei, David M., Wang, Chong, and Paisley, John. 2013. Stochas-
tic Variational Inference. Journal of Machine Learning Research ,14(1), 1303–1347.
Hofmann, Thomas, Sch ¨olkopf, Bernhard, and Smola, Alexander J. 2008. Kernel Meth-
ods in Machine Learning. Annals of Statistics ,36(3), 1171–1220.
Hogben, Leslie. 2013. Handbook of Linear Algebra . Chapman and Hall/CRC.
Horn, Roger A., and Johnson, Charles R. 2013. Matrix Analysis . Cambridge University
Press.
Hotelling, Harold. 1933. Analysis of a Complex of Statistical Variables into Principal
Components. Journal of Educational Psychology ,24, 417–441.
Hyvarinen, Aapo, Oja, Erkki, and Karhunen, Juha. 2001. Independent Component Anal-
ysis. Wiley.
Imbens, Guido W., and Rubin, Donald B. 2015. Causal Inference for Statistics, Social
and Biomedical Sciences . Cambridge University Press.
Jacod, Jean, and Protter, Philip. 2004. Probability Essentials . Springer.
Jaynes, Edwin T. 2003. Probability Theory: The Logic of Science . Cambridge University
Press.
Jefferys, William H., and Berger, James O. 1992. Ockham’s Razor and Bayesian Anal-
ysis. American Scientist ,80, 64–72.
Jeffreys, Harold. 1961. Theory of Probability . Oxford University Press.
Jimenez Rezende, Danilo, and Mohamed, Shakir. 2015. Variational Inference with Nor-
malizing Flows. In: Proceedings of the International Conference on Machine Learning .
Jimenez Rezende, Danilo, Mohamed, Shakir, and Wierstra, Daan. 2014. Stochastic
Backpropagation and Approximate Inference in Deep Generative Models. In: Pro-
ceedings of the International Conference on Machine Learning .
Joachims, Thorsten. 1999. Advances in Kernel Methods – Support Vector Learning . MIT
Press. Chap. Making Large-Scale SVM Learning Practical, pages 169–184.
Jordan, Michael I., Ghahramani, Zoubin, Jaakkola, Tommi S., and Saul, Lawrence K.
1999. An Introduction to Variational Methods for Graphical Models. Machine Learn-
ing,37, 183–233.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
400 References
Julier, Simon J., and Uhlmann, Jeffrey K. 1997. A New Extension of the Kalman Filter
to Nonlinear Systems. In: Proceedings of AeroSense Symposium on Aerospace/Defense
Sensing, Simulation and Controls .
Kaiser, Marcus, and Hilgetag, Claus C. 2006. Nonoptimal Component Placement, but
Short Processing Paths, Due to Long-Distance Projections in Neural Systems. PLoS
Computational Biology ,2(7), e95.
Kalman, Dan. 1996. A Singularly Valuable Decomposition: The SVD of a Matrix. Col-
lege Mathematics Journal ,27(1), 2–23.
Kalman, Rudolf E. 1960. A New Approach to Linear Filtering and Prediction Problems.
Transactions of the ASME – Journal of Basic Engineering ,82(Series D), 35–45.
Kamthe, Sanket, and Deisenroth, Marc P. 2018. Data-Efficient Reinforcement Learning
with Probabilistic Model Predictive Control. In: Proceedings of the International
Conference on Artificial Intelligence and Statistics .
Katz, Victor J. 2004. A History of Mathematics . Pearson/Addison-Wesley.
Kelley, Henry J. 1960. Gradient Theory of Optimal Flight Paths. Ars Journal ,30(10),
947–954.
Kimeldorf, George S., and Wahba, Grace. 1970. A Correspondence between Bayesian
Estimation on Stochastic Processes and Smoothing by Splines. Annals of Mathemat-
ical Statistics ,41(2), 495–502.
Kingma, Diederik P., and Welling, Max. 2014. Auto-Encoding Variational Bayes. In:
Proceedings of the International Conference on Learning Representations .
Kittler, Josef, and F ¨oglein, Janos. 1984. Contextual Classification of Multispectral Pixel
Data. Image and Vision Computing ,2(1), 13–29.
Kolda, Tamara G., and Bader, Brett W. 2009. Tensor Decompositions and Applications.
SIAM Review ,51(3), 455–500.
Koller, Daphne, and Friedman, Nir. 2009. Probabilistic Graphical Models . MIT Press.
Kong, Linglong, and Mizera, Ivan. 2012. Quantile Tomography: Using Quantiles with
Multivariate Data. Statistica Sinica ,22, 1598–1610.
Lang, Serge. 1987. Linear Algebra . Springer.
Lawrence, Neil D. 2005. Probabilistic Non-Linear Principal Component Analysis with
Gaussian Process Latent Variable Models. Journal of Machine Learning Research ,
6(Nov.), 1783–1816.
Leemis, Lawrence M., and McQueston, Jacquelyn T. 2008. Univariate Distribution
Relationships. American Statistician ,62(1), 45–53.
Lehmann, Erich L., and Romano, Joseph P. 2005. Testing Statistical Hypotheses .
Springer.
Lehmann, Erich Leo, and Casella, George. 1998. Theory of Point Estimation . Springer.
Liesen, J ¨org, and Mehrmann, Volker. 2015. Linear Algebra . Springer.
Lin, Hsuan-Tien, Lin, Chih-Jen, and Weng, Ruby C. 2007. A Note on Platt’s Probabilistic
Outputs for Support Vector Machines. Machine Learning ,68, 267–276.
Ljung, Lennart. 1999. System Identification: Theory for the User . Prentice Hall.
Loosli, Ga ¨elle, Canu, St ´ephane, and Ong, Cheng Soon. 2016. Learning SVM in Kre ˘ın
Spaces. IEEE Transactions of Pattern Analysis and Machine Intelligence ,38(6), 1204–
1216.
Luenberger, David G. 1969. Optimization by Vector Space Methods . Wiley.
MacKay, David J. C. 1992. Bayesian Interpolation. Neural Computation ,4, 415–447.
MacKay, David J. C. 1998. Introduction to Gaussian Processes. Pages 133–165 of:
Bishop, C. M. (ed), Neural Networks and Machine Learning . Springer.
MacKay, David J. C. 2003. Information Theory, Inference, and Learning Algorithms .
Cambridge University Press.
Magnus, Jan R., and Neudecker, Heinz. 2007. Matrix Differential Calculus with Appli-
cations in Statistics and Econometrics . Wiley.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
References 401
Manton, Jonathan H., and Amblard, Pierre-Olivier. 2015. A Primer on Reproducing
Kernel Hilbert Spaces. Foundations and Trends in Signal Processing ,8(1–2), 1–126.
Markovsky, Ivan. 2011. Low Rank Approximation: Algorithms, Implementation, Appli-
cations . Springer.
Maybeck, Peter S. 1979. Stochastic Models, Estimation, and Control . Academic Press.
McCullagh, Peter, and Nelder, John A. 1989. Generalized Linear Models . CRC Press.
McEliece, Robert J., MacKay, David J. C., and Cheng, Jung-Fu. 1998. Turbo Decoding
as an Instance of Pearl’s “Belief Propagation” Algorithm. IEEE Journal on Selected
Areas in Communications ,16(2), 140–152.
Mika, Sebastian, R ¨atsch, Gunnar, Weston, Jason, Sch ¨olkopf, Bernhard, and M ¨uller,
Klaus-Robert. 1999. Fisher Discriminant Analysis with Kernels. Pages 41–48 of:
Proceedings of the Workshop on Neural Networks for Signal Processing .
Minka, Thomas P. 2001a. A Family of Algorithms for Approximate Bayesian Inference .
Ph.D. thesis, Massachusetts Institute of Technology.
Minka, Tom. 2001b. Automatic Choice of Dimensionality of PCA. In: Advances in
Neural Information Processing Systems .
Mitchell, Tom. 1997. Machine Learning . McGraw-Hill.
Mnih, Volodymyr, Kavukcuoglu, Koray, and Silver, David, et al. 2015. Human-Level
Control through Deep Reinforcement Learning. Nature ,518, 529–533.
Moonen, Marc, and De Moor, Bart. 1995. SVD and Signal Processing, III: Algorithms,
Architectures and Applications . Elsevier.
Moustaki, Irini, Knott, Martin, and Bartholomew, David J. 2015. Latent-Variable Mod-
eling. American Cancer Society. Pages 1–10.
M¨uller, Andreas C., and Guido, Sarah. 2016. Introduction to Machine Learning with
Python: A Guide for Data Scientists . O’Reilly Publishing.
Murphy, Kevin P. 2012. Machine Learning: A Probabilistic Perspective . MIT Press.
Neal, Radford M. 1996. Bayesian Learning for Neural Networks . Ph.D. thesis, Depart-
ment of Computer Science, University of Toronto.
Neal, Radford M., and Hinton, Geoffrey E. 1999. A View of the EM Algorithm that
Justifies Incremental, Sparse, and Other Variants. Pages 355–368 of: Learning in
Graphical Models . MIT Press.
Nelsen, Roger. 2006. An Introduction to Copulas . Springer.
Nesterov, Yuri. 2018. Lectures on Convex Optimization . Springer.
Neumaier, Arnold. 1998. Solving Ill-Conditioned and Singular Linear Systems: A Tu-
torial on Regularization. SIAM Review ,40, 636–666.
Nocedal, Jorge, and Wright, Stephen J. 2006. Numerical Optimization . Springer.
Nowozin, Sebastian, Gehler, Peter V., Jancsary, Jeremy, and Lampert, Christoph H.
(eds). 2014. Advanced Structured Prediction . MIT Press.
O’Hagan, Anthony. 1991. Bayes-Hermite Quadrature. Journal of Statistical Planning
and Inference ,29, 245–260.
Ong, Cheng Soon, Mary, Xavier, Canu, St ´ephane, and Smola, Alexander J. 2004. Learn-
ing with Non-Positive Kernels. In: Proceedings of the International Conference on
Machine Learning .
Ormoneit, Dirk, Sidenbladh, Hedvig, Black, Michael J., and Hastie, Trevor. 2001.
Learning and Tracking Cyclic Human Motion. In: Advances in Neural Information
Processing Systems .
Page, Lawrence, Brin, Sergey, Motwani, Rajeev, and Winograd, Terry. 1999. The
PageRank Citation Ranking: Bringing Order to the Web . Tech. rept. Stanford Info-
Lab.
Paquet, Ulrich. 2008. Bayesian Inference for Latent Variable Models . Ph.D. thesis, Uni-
versity of Cambridge.
Parzen, Emanuel. 1962. On Estimation of a Probability Density Function and Mode.
Annals of Mathematical Statistics ,33(3), 1065–1076.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
402 References
Pearl, Judea. 1988. Probabilistic Reasoning in Intelligent Systems: Networks of Plausible
Inference . Morgan Kaufmann.
Pearl, Judea. 2009. Causality: Models, Reasoning and Inference . 2nd edn. Cambridge
University Press.
Pearson, Karl. 1895. Contributions to the Mathematical Theory of Evolution. II. Skew
Variation in Homogeneous Material. Philosophical Transactions of the Royal Society
A: Mathematical, Physical and Engineering Sciences ,186, 343–414.
Pearson, Karl. 1901. On Lines and Planes of Closest Fit to Systems of Points in Space.
Philosophical Magazine ,2(11), 559–572.
Peters, Jonas, Janzing, Dominik, and Sch ¨olkopf, Bernhard. 2017. Elements of Causal
Inference: Foundations and Learning Algorithms . MIT Press.
Petersen, Kaare B., and Pedersen, Michael S. 2012. The Matrix Cookbook . Tech. rept.
Technical University of Denmark.
Platt, John C. 2000. Probabilistic Outputs for Support Vector Machines and Compar-
isons to Regularized Likelihood Methods. In: Advances in Large Margin Classifiers .
Pollard, David. 2002. A User’s Guide to Measure Theoretic Probability . Cambridge
University Press.
Polyak, Roman A. 2016. The Legendre Transformation in Modern Optimization. Pages
437–507 of: Goldengorin, B. (ed), Optimization and Its Applications in Control and
Data Sciences . Springer.
Press, William H., Teukolsky, Saul A., Vetterling, William T., and Flannery, Brian P.
2007. Numerical Recipes: The Art of Scientific Computing . Cambridge University
Press.
Proschan, Michael A., and Presnell, Brett. 1998. Expect the Unexpected from Condi-
tional Expectation. American Statistician ,52(3), 248–252.
Raschka, Sebastian, and Mirjalili, Vahid. 2017. Python Machine Learning: Machine
Learning and Deep Learning with Python, scikit-learn, and TensorFlow . Packt Publish-
ing.
Rasmussen, Carl E., and Ghahramani, Zoubin. 2001. Occam’s Razor. In: Advances in
Neural Information Processing Systems .
Rasmussen, Carl E., and Ghahramani, Zoubin. 2003. Bayesian Monte Carlo. In: Ad-
vances in Neural Information Processing Systems .
Rasmussen, Carl E., and Williams, Christopher K. I. 2006. Gaussian Processes for Ma-
chine Learning . MIT Press.
Reid, Mark, and Williamson, Robert C. 2011. Information, Divergence and Risk for
Binary Experiments. Journal of Machine Learning Research ,12, 731–817.
Rifkin, Ryan M., and Lippert, Ross A. 2007. Value Regularization and Fenchel Duality.
Journal of Machine Learning Research ,8, 441–479.
Rockafellar, Ralph T. 1970. Convex Analysis . Princeton University Press.
Rogers, Simon, and Girolami, Mark. 2016. A First Course in Machine Learning . Chap-
man and Hall/CRC.
Rosenbaum, Paul R. 2017. Observation and Experiment: An Introduction to Causal
Inference . Harvard University Press.
Rosenblatt, Murray. 1956. Remarks on Some Nonparametric Estimates of a Density
Function. Annals of Mathematical Statistics ,27(3), 832–837.
Roweis, Sam T. 1998. EM Algorithms for PCA and SPCA. Pages 626–632 of: Advances
in Neural Information Processing Systems .
Roweis, Sam T., and Ghahramani, Zoubin. 1999. A Unifying Review of Linear Gaussian
Models. Neural Computation ,11(2), 305–345.
Roy, Anindya, and Banerjee, Sudipto. 2014. Linear Algebra and Matrix Analysis for
Statistics . Chapman and Hall/CRC.
Rubinstein, Reuven Y., and Kroese, Dirk P. 2016. Simulation and the Monte Carlo
Method . Wiley.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
References 403
Ruffini, Paolo. 1799. Teoria Generale delle Equazioni, in cui si Dimostra Impossibile la
Soluzione Algebraica delle Equazioni Generali di Grado Superiore al Quarto . Stampe-
ria di S. Tommaso d’Aquino.
Rumelhart, David E., Hinton, Geoffrey E., and Williams, Ronald J. 1986. Learning
Representations by Back-Propagating Errors. Nature ,323(6088), 533–536.
Sæmundsson, Steind ´or, Hofmann, Katja, and Deisenroth, Marc P. 2018. Meta Rein-
forcement Learning with Latent Variable Gaussian Processes. In: Proceedings of the
Conference on Uncertainty in Artificial Intelligence .
Saitoh, Saburou. 1988. Theory of Reproducing Kernels and its Applications . Longman
Scientific and Technical.
S¨arkk¨a, Simo. 2013. Bayesian Filtering and Smoothing . Cambridge University Press.
Sch¨olkopf, Bernhard, and Smola, Alexander J. 2002. Learning with Kernels – Support
Vector Machines, Regularization, Optimization, and Beyond . MIT Press.
Sch¨olkopf, Bernhard, Smola, Alexander J., and M ¨uller, Klaus-Robert. 1997. Kernel
Principal Component Analysis. In: Proceedings of the International Conference on
Artificial Neural Networks .
Sch¨olkopf, Bernhard, Smola, Alexander J., and M ¨uller, Klaus-Robert. 1998. Nonlinear
Component Analysis as a Kernel Eigenvalue Problem. Neural Computation ,10(5),
1299–1319.
Sch¨olkopf, Bernhard, Herbrich, Ralf, and Smola, Alexander J. 2001. A Generalized
Representer Theorem. In: Proceedings of the International Conference on Computa-
tional Learning Theory .
Schwartz, Laurent. 1964. Sous Espaces Hilbertiens d’Espaces Vectoriels Topologiques
et Noyaux Associ ´es.Journal d’Analyse Math ´ematique ,13, 115–256.
Schwarz, Gideon E. 1978. Estimating the Dimension of a Model. Annals of Statistics ,
6(2), 461–464.
Shahriari, Bobak, Swersky, Kevin, Wang, Ziyu, Adams, Ryan P., and De Freitas, Nando.
2016. Taking the Human out of the Loop: A Review of Bayesian Optimization.
Proceedings of the IEEE ,104(1), 148–175.
Shalev-Shwartz, Shai, and Ben-David, Shai. 2014. Understanding Machine Learning:
From Theory to Algorithms . Cambridge University Press.
Shawe-Taylor, John, and Cristianini, Nello. 2004. Kernel Methods for Pattern Analysis .
Cambridge University Press.
Shawe-Taylor, John, and Sun, Shiliang. 2011. A Review of Optimization Methodologies
in Support Vector Machines. Neurocomputing ,74(17), 3609–3618.
Shental, Ori, Siegel, Paul H., Wolf, Jack K., Bickson, Danny, and Dolev, Danny. 2008.
Gaussian Belief Propagation Solver for Systems of Linear Equations. Pages 1863–
1867 of: Proceedings of the International Symposium on Information Theory .
Shewchuk, Jonathan R. 1994. An Introduction to the Conjugate Gradient Method with-
out the Agonizing Pain .
Shi, Jianbo, and Malik, Jitendra. 2000. Normalized Cuts and Image Segmentation.
IEEE Transactions on Pattern Analysis and Machine Intelligence ,22(8), 888–905.
Shi, Qinfeng, Petterson, James, Dror, Gideon, Langford, John, Smola, Alexander J.,
and Vishwanathan, S. V. N. 2009. Hash Kernels for Structured Data. Journal of
Machine Learning Research , 2615–2637.
Shiryayev, Albert N. 1984. Probability . Springer.
Shor, Naum Z. 1985. Minimization Methods for Non-Differentiable Functions . Springer.
Shotton, Jamie, Winn, John, Rother, Carsten, and Criminisi, Antonio. 2006. Texton-
Boost: Joint Appearance, Shape and Context Modeling for Multi-Class Object Recog-
nition and Segmentation. In: Proceedings of the European Conference on Computer
Vision .
Smith, Adrian F. M., and Spiegelhalter, David. 1980. Bayes Factors and Choice Criteria
for Linear Models. Journal of the Royal Statistical Society B ,42(2), 213–220.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
404 References
Snoek, Jasper, Larochelle, Hugo, and Adams, Ryan P. 2012. Practical Bayesian Op-
timization of Machine Learning Algorithms. In: Advances in Neural Information
Processing Systems .
Spearman, Charles. 1904. “General Intelligence,” Objectively Determined and Mea-
sured. American Journal of Psychology ,15(2), 201–292.
Sriperumbudur, Bharath K., Gretton, Arthur, Fukumizu, Kenji, Sch ¨olkopf, Bernhard,
and Lanckriet, Gert R. G. 2010. Hilbert Space Embeddings and Metrics on Proba-
bility Measures. Journal of Machine Learning Research ,11, 1517–1561.
Steinwart, Ingo. 2007. How to Compare Different Loss Functions and Their Risks.
Constructive Approximation ,26, 225–287.
Steinwart, Ingo, and Christmann, Andreas. 2008. Support Vector Machines . Springer.
Stoer, Josef, and Burlirsch, Roland. 2002. Introduction to Numerical Analysis . Springer.
Strang, Gilbert. 1993. The Fundamental Theorem of Linear Algebra. The American
Mathematical Monthly ,100(9), 848–855.
Strang, Gilbert. 2003. Introduction to Linear Algebra . Wellesley-Cambridge Press.
Stray, Jonathan. 2016. The Curious Journalist’s Guide to Data . Tow Center for Digital
Journalism at Columbia’s Graduate School of Journalism.
Strogatz, Steven. 2014. Writing about Math for the Perplexed and the Traumatized.
Notices of the American Mathematical Society ,61(3), 286–291.
Sucar, Luis E., and Gillies, Duncan F. 1994. Probabilistic Reasoning in High-Level
Vision. Image and Vision Computing ,12(1), 42–60.
Szeliski, Richard, Zabih, Ramin, and Scharstein, Daniel, et al. 2008. A Compar-
ative Study of Energy Minimization Methods for Markov Random Fields with
Smoothness-Based Priors. IEEE Transactions on Pattern Analysis and Machine In-
telligence ,30(6), 1068–1080.
Tandra, Haryono. 2014. The Relationship between the Change of Variable Theorem
and the Fundamental Theorem of Calculus for the Lebesgue Integral. Teaching of
Mathematics ,17(2), 76–83.
Tenenbaum, Joshua B., De Silva, Vin, and Langford, John C. 2000. A Global Geometric
Framework for Nonlinear Dimensionality Reduction. Science ,290(5500), 2319–
2323.
Tibshirani, Robert. 1996. Regression Selection and Shrinkage via the Lasso. Journal
of the Royal Statistical Society B ,58(1), 267–288.
Tipping, Michael E., and Bishop, Christopher M. 1999. Probabilistic Principal Compo-
nent Analysis. Journal of the Royal Statistical Society: Series B ,61(3), 611–622.
Titsias, Michalis K., and Lawrence, Neil D. 2010. Bayesian Gaussian Process Latent
Variable Model. In: Proceedings of the International Conference on Artificial Intelli-
gence and Statistics .
Toussaint, Marc. 2012. Some Notes on Gradient Descent . https://ipvs.informatik.uni-
stuttgart.de/mlr/marc/notes/gradientDescent.pdf.
Trefethen, Lloyd N., and Bau III, David. 1997. Numerical Linear Algebra . SIAM.
Tucker, Ledyard R. 1966. Some Mathematical Notes on Three-Mode Factor Analysis.
Psychometrika ,31(3), 279–311.
Vapnik, Vladimir N. 1998. Statistical Learning Theory . Wiley.
Vapnik, Vladimir N. 1999. An Overview of Statistical Learning Theory. IEEE Transac-
tions on Neural Networks ,10(5), 988–999.
Vapnik, Vladimir N. 2000. The Nature of Statistical Learning Theory . Springer.
Vishwanathan, S. V. N., Schraudolph, Nicol N., Kondor, Risi, and Borgwardt,
Karsten M. 2010. Graph Kernels. Journal of Machine Learning Research ,11, 1201–
1242.
von Luxburg, Ulrike, and Sch ¨olkopf, Bernhard. 2011. Statistical Learning Theory:
Models, Concepts, and Results. Pages 651–706 of: D. M. Gabbay, S. Hartmann,
J. Woods (ed), Handbook of the History of Logic , vol. 10. Elsevier.
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
References 405
Wahba, Grace. 1990. Spline Models for Observational Data . Society for Industrial and
Applied Mathematics.
Walpole, Ronald E., Myers, Raymond H., Myers, Sharon L., and Ye, Keying. 2011.
Probability and Statistics for Engineers and Scientists . Prentice Hall.
Wasserman, Larry. 2004. All of Statistics . Springer.
Wasserman, Larry. 2007. All of Nonparametric Statistics . Springer.
Whittle, Peter. 2000. Probability via Expectation . Springer.
Wickham, Hadley. 2014. Tidy Data. Journal of Statistical Software ,59, 1–23.
Williams, Christopher K. I. 1997. Computing with Infinite Networks. In: Advances in
Neural Information Processing Systems .
Yu, Yaoliang, Cheng, Hao, Schuurmans, Dale, and Szepesv ´ari, Csaba. 2013. Charac-
terizing the Representer Theorem. In: Proceedings of the International Conference on
Machine Learning .
Zadrozny, Bianca, and Elkan, Charles. 2001. Obtaining Calibrated Probability Esti-
mates from Decision Trees and Naive Bayesian Classifiers. In: Proceedings of the
International Conference on Machine Learning .
Zhang, Haizhang, Xu, Yuesheng, and Zhang, Jun. 2009. Reproducing Kernel Banach
Spaces for Machine Learning. Journal of Machine Learning Research ,10, 2741–2775.
Zia, Royce K. P., Redish, Edward F., and McKay, Susan R. 2009. Making Sense of the
Legendre Transform. American Journal of Physics ,77(614), 614–622.
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).

Index
1-of-Krepresentation, 364
ℓ1norm, 71
ℓ2norm, 72
abduction, 258
Abel-Ruffini theorem, 334
Abelian group, 36
absolutely homogeneous, 71
activation function, 315
affine mapping, 63
affine subspace, 61
Akaike information criterion, 288
algebra, 17
algebraic multiplicity, 106
analytic, 143
ancestral sampling, 340, 364
angle, 76
associativity, 24, 26, 36
attribute, 253
augmented matrix, 29
auto-encoder, 343
automatic differentiation, 161
automorphism, 49
backpropagation, 159
basic variable, 30
basis, 44
basis vector, 45
Bayes factor, 287
Bayes’ law, 185
Bayes’ rule, 185
Bayes’ theorem, 185
Bayesian GP-LVM, 347
Bayesian inference, 274
Bayesian information criterion, 288
Bayesian linear regression, 303
Bayesian model selection, 286
Bayesian network, 278, 283
Bayesian PCA, 346
Bernoulli distribution, 205
Beta distribution, 206
bilinear mapping, 72
bijective, 48
binary classification, 370
Binomial distribution, 206
blind-source separation, 346
Borel σ-algebra, 180canonical basis, 45
canonical feature map, 389
canonical link function, 315
categorical variable, 180
Cauchy-Schwarz inequality, 75
change-of-variable technique, 219
characteristic polynomial, 104
Cholesky decomposition, 114
Cholesky factor, 114
Cholesky factorization, 114
class, 370
classification, 315
closure, 36
code, 343
codirected, 105
codomain, 58, 139
collinear, 105
column, 22
column space, 59
column vector, 22, 38
completing the squares, 307
concave function, 236
condition number, 230
conditional probability, 179
conditionally independent, 195
conjugate, 208
conjugate prior, 208
convex conjugate, 242
convex function, 236
convex hull, 386
convex optimization problem, 236, 239
convex set, 236
coordinate, 50
coordinate representation, 50
coordinate vector, 50
correlation, 191
covariance, 190
covariance matrix, 190, 198
covariate, 253
CP decomposition, 136
cross-covariance, 191
cross-validation, 258, 263
cumulative distribution function, 178,
181
d-separation, 281
407
This material is published by Cambridge University Press as Mathematics for Machine Learning by
Marc Peter Deisenroth, A. Aldo Faisal, and Cheng Soon Ong (2020). This version is free to view
and download for personal use only. Not for re-distribution, re-sale, or use in derivative works.
©by M. P. Deisenroth, A. A. Faisal, and C. S. Ong, 2024. https://mml-book.com .
408 Index
data covariance matrix, 318
data point, 253
data-fit term, 302
decoder, 343
deep auto-encoder, 347
defective, 111
denominator layout, 151
derivative, 141
design matrix, 294, 296
determinant, 99
diagonal matrix, 115
diagonalizable, 116
diagonalization, 116
difference quotient, 141
dimension, 45
dimensionality reduction, 317
directed graphical model, 278, 283
direction, 61
direction space, 61
distance, 75
distribution, 177
distributivity, 24, 26
domain, 58, 139
dot product, 72
dual SVM, 385
Eckart-Young theorem, 131, 334
eigendecomposition, 116
eigenspace, 106
eigenspectrum, 106
eigenvalue, 105
eigenvalue equation, 105
eigenvector, 105
elementary transformations, 28
EM algorithm, 360
embarrassingly parallel, 264
empirical covariance, 192
empirical mean, 192
empirical risk, 260
empirical risk minimization, 257, 260
encoder, 343
endomorphism, 49
epigraph, 236
equivalent, 56
error function, 294
error term, 382
Euclidean distance, 72, 75
Euclidean norm, 72
Euclidean vector space, 73
event space, 175
evidence, 186, 285, 306
example, 253
expected risk, 261
expected value, 187
exponential family, 205, 211
extended Kalman filter, 170
factor analysis, 346
factor graph, 283feature, 253
feature map, 254
feature matrix, 296
feature vector, 295
Fisher discriminant analysis, 136
Fisher-Neyman theorem, 210
forward mode, 161
free variable, 30
full rank, 47
full SVD, 128
fundamental theorem of linear
mappings, 60
Gaussian elimination, 31
Gaussian mixture model, 349
Gaussian process, 316
Gaussian process latent-variable model,
347
general linear group, 37
general solution, 28, 30
generalized linear model, 272, 315
generating set, 44
generative process, 272, 286
generator, 344
geometric multiplicity, 108
Givens rotation, 94
global minimum, 225
GP-LVM, 347
gradient, 146
Gram matrix, 389
Gram-Schmidt orthogonalization, 89
graphical model, 278
group, 36
Hadamard product, 23
hard margin SVM, 377
Hessian, 164
Hessian eigenmaps, 136
Hessian matrix, 165
hinge loss, 381
histogram, 369
hyperparameter, 258
hyperplane, 61, 62
hyperprior, 281
i.i.d., 195
ICA, 346
identity automorphism, 49
identity mapping, 49
identity matrix, 23
image, 58, 139
independent and identically distributed,
195, 260, 266
independent component analysis, 346
inference network, 344
injective, 48
inner product, 73
inner product space, 73
intermediate variables, 162
inverse, 24
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
Index 409
inverse element, 36
invertible, 24
Isomap, 136
isomorphism, 49
Jacobian, 146, 150
Jacobian determinant, 152
Jeffreys-Lindley paradox, 287
Jensen’s inequality, 239
joint probability, 178
Karhunen-Lo `eve transform, 318
kernel, 33, 47, 58, 254, 388
kernel density estimation, 369
kernel matrix, 389
kernel PCA, 347
kernel trick, 316, 347, 389
label, 253
Lagrange multiplier, 234
Lagrangian, 234
Lagrangian dual problem, 234
Laplace approximation, 170
Laplace expansion, 102
Laplacian eigenmaps, 136
LASSO, 303, 316
latent variable, 275
law, 177, 181
law of total variance, 203
leading coefficient, 30
least-squares loss, 154
least-squares problem, 261
least-squares solution, 88
left-singular vectors, 119
Legendre transform, 242
Legendre-Fenchel transform, 242
length, 71
likelihood, 185, 265, 269, 291
line, 61, 82
linear combination, 40
linear manifold, 61
linear mapping, 48
linear program, 239
linear subspace, 39
linear transformation, 48
linearly dependent, 40
linearly independent, 40
link function, 272
loading, 322
local minimum, 225
log-partition function, 211
logistic regression, 315
logistic sigmoid, 315
loss function, 260, 381
loss term, 382
lower-triangular matrix, 101
Maclaurin series, 143
Manhattan norm, 71
MAP, 300
MAP estimation, 269margin, 374
marginal, 190
marginal likelihood, 186, 286, 306
marginal probability, 179
marginalization property, 184
Markov random field, 283
matrix, 22
matrix factorization, 98
maximum a posteriori, 300
maximum a posteriori estimation, 269
maximum likelihood, 257
maximum likelihood estimate, 296
maximum likelihood estimation, 265,
293
mean, 187
mean function, 309
mean vector, 198
measure, 180
median, 188
metric, 76
minimal, 44
minimax inequality, 234
misfit term, 302
mixture model, 349
mixture weight, 349
mode, 188
model, 251
model evidence, 286
model selection, 258
Moore-Penrose pseudo-inverse, 35
multidimensional scaling, 136
multiplication by scalars, 37
multivariate, 178
multivariate Gaussian distribution, 198
multivariate Taylor series, 166
natural parameters, 212
negative log-likelihood, 265
nested cross-validation, 258, 284
neutral element, 36
noninvertible, 24
nonsingular, 24
norm, 71
normal distribution, 197
normal equation, 86
normal vector, 80
null space, 33, 47, 58
numerator layout, 150
Occam’s razor, 285
ONB, 79
one-hot encoding, 364
ordered basis, 50
orthogonal, 77
orthogonal basis, 79
orthogonal complement, 79
orthogonal matrix, 78
orthonormal, 77
orthonormal basis, 79
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
410 Index
outer product, 38
overfitting, 262, 271, 299
PageRank, 114
parameters, 61
parametric equation, 61
partial derivative, 146
particular solution, 27, 30
PCA, 317
pdf, 181
penalty term, 263
pivot, 30
plane, 62
plate, 281
population mean and covariance, 191
positive definite, 71, 73, 74, 76
posterior, 185, 269
posterior odds, 287
power iteration, 334
power series representation, 145
PPCA, 340
preconditioner, 230
predictor, 12, 255
primal problem, 234
principal component, 322
principal component analysis, 136, 317
principal subspace, 327
prior, 185, 269
prior odds, 287
probabilistic inverse, 186
probabilistic PCA, 340
probabilistic programming, 278
probability, 175
probability density function, 181
probability distribution, 172
probability integral transform, 217
probability mass function, 178
product rule, 184
projection, 82
projection error, 88
projection matrix, 82
pseudo-inverse, 86
random variable, 172, 175
range, 58
rank, 47
rank deficient, 47
rank- kapproximation, 130
rank-nullity theorem, 60
raw-score formula for variance, 193
recognition network, 344
reconstruction error, 88, 327
reduced hull, 388
reduced row-echelon form, 31
reduced SVD, 129
REF, 30
regression, 289
regular, 24
regularization, 262, 302, 382regularization parameter, 263, 302, 380
regularized least squares, 302
regularizer, 263, 302, 380, 382
representer theorem, 384
responsibility, 352
reverse mode, 161
right-singular vectors, 119
RMSE, 298
root mean square error, 298
rotation, 91
rotation matrix, 92
row, 22
row vector, 22, 38
row-echelon form, 30
sample mean, 192
sample space, 175
scalar, 37
scalar product, 72
sigmoid, 213
similar, 56
singular, 24
singular value decomposition, 119
singular value equation, 124
singular value matrix, 119
singular values, 119
slack variable, 379
soft margin SVM, 379, 380
solution, 20
span, 44
special solution, 27
spectral clustering, 136
spectral norm, 131
spectral theorem, 111
spectrum, 106
square matrix, 25
standard basis, 45
standard deviation, 190
standard normal distribution, 198
standardization, 336
statistical independence, 194
statistical learning theory, 265
stochastic gradient descent, 231
strong duality, 236
sufficient statistics, 210
sum rule, 184
support point, 61
support vector, 384
supporting hyperplane, 242
surjective, 48
SVD, 119
SVD theorem, 119
symmetric, 73, 76
symmetric matrix, 25
symmetric, positive definite, 74
symmetric, positive semidefinite, 74
system of linear equations, 20
target space, 175
Draft (2024-01-15) of “Mathematics for Machine Learning”. Feedback: https://mml-book.com .
Index 411
Taylor polynomial, 142, 166
Taylor series, 142
test error, 300
test set, 262, 284
Tikhonov regularization, 265
trace, 103
training, 12
training error, 300
training set, 260, 292
transfer function, 315
transformation matrix, 51
translation vector, 63
transpose, 25, 38
triangle inequality, 71, 76
truncated SVD, 129
Tucker decomposition, 136
underfitting, 271
undirected graphical model, 283
uniform distribution, 182
univariate, 178
unscented transform, 170
upper-triangular matrix, 101
validation set, 263, 284
variable selection, 316
variance, 190
vector, 37
vector addition, 37
vector space, 37
vector space homomorphism, 48
vector space with inner product, 73
vector subspace, 39
weak duality, 235
zero-one loss, 381
©2024 M. P. Deisenroth, A. A. Faisal, C. S. Ong. Published by Cambridge University Press (2020).
