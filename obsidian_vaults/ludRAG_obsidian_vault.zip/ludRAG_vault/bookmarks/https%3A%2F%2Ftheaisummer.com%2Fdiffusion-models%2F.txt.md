How diffusion models work: the math from scratch | AI Summer
Start Here
Learn AI
Deep Learning Fundamentals
Advanced Deep Learning
AI Software Engineering
Books & Courses
Deep Learning in Production Book
Introduction to Deep Learning Interactive Course
Representation Learning MSc course 2023
Get started with Deep Learning Free Course
Deep Reinforcement Learning Free Course
GANs in Computer Vision Free Ebook
Projects
MedicalZoo
Self Attention CV
Resources
About
Contact
Support us
Newsletter
×
Start Here
Learn AI
Deep Learning Fundamentals
Advanced Deep Learning
AI Software Engineering
Books & Courses
Deep Learning in Production Book
Introduction to Deep Learning Interactive Course
Representation Learning MSc course 2023
Get started with Deep Learning Free Course
Deep Reinforcement Learning Free Course
GANs in Computer Vision Free Ebook
Projects
Medical Zoo
Self Attention CV
Resources
About
Contact
Search
Support us
📖 Check out our Introduction to Deep Learning & Neural Networks course 📖
 
Learn more
How diffusion models work: the math from scratch
Sergios Karagiannakos
,
Nikolas Adaloglou
on
2022-09-29
·
14
 mins
Generative Learning
Computer Vision
SIMILAR ARTICLES
Generative Learning
The theory behind Latent Variable Models: formulating a Variational Autoencoder
Deepfakes: Face synthesis with GANs and Autoencoders
GANs in computer vision - semantic image synthesis and learning a generative model from a single image
GANs in computer vision - self-supervised adversarial training and high-resolution image synthesis with style incorporation
GANs in computer vision - 2K image and video synthesis, and large-scale class-conditional image generation
GANs in computer vision - Improved training with Wasserstein distance, game theory control and progressively growing schemes
GANs in computer vision - Conditional image synthesis and 3D object generation
GANs in computer vision - Introduction to generative learning
Decrypt Generative Adversarial Networks (GAN)
How to Generate Images using Autoencoders
Computer Vision
ICCV 2023 top papers, general trends, and personal picks
Understanding Vision Transformers (ViTs): Hidden properties, insights, and robustness of their representations
How Neural Radiance Fields (NeRF) and Instant Neural Graphics Primitives work
BYOL tutorial: self-supervised learning on CIFAR images with code in Pytorch
Self-supervised learning tutorial: Implementing SimCLR with pytorch lightning
Vision Language models: towards multi-modal deep learning
Transformers in computer vision: ViT architectures, tips, tricks and improvements
Grokking self-supervised (representation) learning: how it works in computer vision and why
A complete Hugging Face tutorial: how to build and train a vision transformer
An overview of Unet architectures for semantic segmentation and biomedical image segmentation
More articles
 
BOOKS & COURSES
Introduction to Deep Learning & Neural Networks with Pytorch 📗
Deep Learning in Production Book 📘
Diffusion models are a new class of state-of-the-art generative models that generate diverse high-resolution images. They have already attracted a lot of attention after OpenAI, Nvidia and Google managed to train large-scale models. Example architectures that are based on diffusion models are GLIDE, DALLE-2, Imagen, and the full open-source stable diffusion. 
But what is the main principle behind them?
In this blog post, we will dig our way up from the basic principles. There are already a bunch of different diffusion-based architectures. We will focus on the most prominent one, which is the Denoising Diffusion Probabilistic Models (DDPM) as initialized by 
Sohl-Dickstein et al
  and then proposed by 
Ho. et al 2020
. Various other approaches will be discussed to a smaller extent such as stable diffusion and score-based models.
Diffusion models are fundamentally different from all the previous generative methods. Intuitively, they aim to decompose the image generation process (sampling) in many small “denoising” steps. 
The intuition behind this is that the model can correct itself over these small steps and gradually produce a good sample. To some extent, this idea of refining the representation has already been used in models like 
alphafold
. But hey, nothing comes at zero-cost. This iterative process makes them slow at sampling, at least compared to 
GANs
. 
Diffusion process
The basic idea behind diffusion models is rather simple. They take the input image 
x
0
\mathbf{x}_0
x
0
​
 and gradually add Gaussian noise to it through a series of 
T
T
T
 steps. We will call this the forward process. Notably, this is unrelated to the forward pass of a neural network. If you'd like, this part is necessary to generate the targets for our neural network (the image after applying 
t
<
T
t<T
t
<
T
 noise steps).
Afterward, a neural network is trained to recover the original data by reversing the noising process. By being able to model the reverse process, we can generate new data. This is the so-called reverse diffusion process or, in general, the sampling process of a generative model. 
How? Let’s dive into the math to make it crystal clear.
Forward diffusion
Diffusion models can be seen as latent variable models. Latent means that we are referring to a hidden continuous feature space. In such a way, they may look similar to 
variational autoencoders (VAEs)
. 
In practice, they are formulated using a Markov chain of 
T
T
T
 steps. Here, a Markov chain means that each step only depends on the previous one, which is a mild assumption. Importantly, we are not constrained to using a specific type of neural network, unlike 
flow-based models
.
Given a data-point 
x
0
\textbf{x}_0
x
0
​
 sampled from the real data distribution 
q
(
x
)
q(x)
q
(
x
)
 ( 
x
0
∼
q
(
x
)
\textbf{x}_0 \sim q(x)
x
0
​
∼
q
(
x
)
), one can define a forward diffusion process by adding noise. Specifically, at each step of the Markov chain we add Gaussian noise with variance 
β
t
\beta_{t}
β
t
​
 to 
x
t
−
1
\textbf{x}_{t-1}
x
t
−
1
​
, producing a new latent variable 
x
t
\textbf{x}_{t}
x
t
​
 with distribution 
q
(
x
t
∣
x
t
−
1
)
q(\textbf{x}_t |\textbf{x}_{t-1})
q
(
x
t
​
∣
x
t
−
1
​
)
. This diffusion process can be formulated as follows: 
q
(
x
t
∣
x
t
−
1
)
=
N
(
x
t
;
μ
t
=
1
−
β
t
x
t
−
1
,
Σ
t
=
β
t
I
)
q(\mathbf{x}_t \vert \mathbf{x}_{t-1}) = \mathcal{N}(\mathbf{x}_t; \boldsymbol{\mu}_t=\sqrt{1 - \beta_t} \mathbf{x}_{t-1}, \boldsymbol{\Sigma}_t = \beta_t\mathbf{I})  
q
(
x
t
​
∣
x
t
−
1
​
)
=
N
(
x
t
​
;
μ
t
​
=
1
−
β
t
​
​
x
t
−
1
​
,
Σ
t
​
=
β
t
​
I
)












Forward diffusion process. Image modified by 
Ho et al. 2020
 
Since we are in the multi-dimensional scenario 
I
\textbf{I}
I
 is the identity matrix, indicating that each dimension has the same standard deviation 
β
t
\beta_t
β
t
​
. Note that 
q
(
x
t
∣
x
t
−
1
)
q(\mathbf{x}_t \vert \mathbf{x}_{t-1})
q
(
x
t
​
∣
x
t
−
1
​
)
 is still a normal distribution, defined by the mean 
μ
\boldsymbol{\mu}
μ
 and the variance 
Σ
\boldsymbol{\Sigma}
Σ
 where 
μ
t
=
1
−
β
t
x
t
−
1
\boldsymbol{\mu}_t =\sqrt{1 - \beta_t} \mathbf{x}_{t-1}
μ
t
​
=
1
−
β
t
​
​
x
t
−
1
​
 and 
Σ
t
=
β
t
I
\boldsymbol{\Sigma}_t=\beta_t\mathbf{I}
Σ
t
​
=
β
t
​
I
. 
Σ
\boldsymbol{\Sigma}
Σ
 will always be a diagonal matrix of variances (here 
β
t
\beta_t
β
t
​
)
Thus, we can go in a closed form from the input data 
x
0
\mathbf{x}_0
x
0
​
 to 
x
T
\mathbf{x}_{T}
x
T
​
 in a tractable way. Mathematically, this is the posterior probability and is defined as:
q
(
x
1
:
T
∣
x
0
)
=
∏
t
=
1
T
q
(
x
t
∣
x
t
−
1
)
q(\mathbf{x}_{1:T} \vert \mathbf{x}_0) = \prod^T_{t=1} q(\mathbf{x}_t \vert \mathbf{x}_{t-1}) 
q
(
x
1
:
T
​
∣
x
0
​
)
=
t
=
1
∏
T
​
q
(
x
t
​
∣
x
t
−
1
​
)
The symbol 
:
:
:
 in 
q
(
x
1
:
T
)
q(\mathbf{x}_{1:T})
q
(
x
1
:
T
​
)
 states that we apply 
q
q
q
 repeatedly from timestep 
1
1
1
 to 
T
T
T
. It's also called trajectory.
So far, so good? Well, nah! For timestep 
t
=
500
<
T
t=500 < T
t
=
5
0
0
<
T
 we need to apply 
q
q
q
 500 times in order to sample 
x
t
\mathbf{x}_t
x
t
​
. Can't we really do better? 
The 
reparametrization trick
 provides a magic remedy to this.
The reparameterization trick: tractable closed-form sampling at any timestep
If we define 
α
t
=
1
−
β
t
\alpha_t= 1- \beta_t
α
t
​
=
1
−
β
t
​
, 
α
ˉ
t
=
∏
s
=
0
t
α
s
\bar{\alpha}_t = \prod_{s=0}^t \alpha_s
α
ˉ
t
​
=
∏
s
=
0
t
​
α
s
​
 where 
ϵ
0
,
.
.
.
,
ϵ
t
−
2
,
ϵ
t
−
1
∼
N
(
0
,
I
)
\boldsymbol{\epsilon}_{0},..., \epsilon_{t-2}, \epsilon_{t-1} \sim \mathcal{N}(\textbf{0},\mathbf{I})
ϵ
0
​
,
.
.
.
,
ϵ
t
−
2
​
,
ϵ
t
−
1
​
∼
N
(
0
,
I
)
, one can use the 
reparameterization trick
 in a recursive manner to prove that:
x
t
=
1
−
β
t
x
t
−
1
+
β
t
ϵ
t
−
1
=
α
t
x
t
−
2
+
1
−
α
t
ϵ
t
−
2
=
…
=
α
ˉ
t
x
0
+
1
−
α
ˉ
t
ϵ
0
\begin{aligned}

\mathbf{x}_t 

&=\sqrt{1 - \beta_t} \mathbf{x}_{t-1} + \sqrt{\beta_t}\boldsymbol{\epsilon}_{t-1}\\

&= \sqrt{\alpha_t}\mathbf{x}_{t-2} + \sqrt{1 - \alpha_t}\boldsymbol{\epsilon}_{t-2}  \\

&= \dots \\

&= \sqrt{\bar{\alpha}_t}\mathbf{x}_0 + \sqrt{1 - \bar{\alpha}_t}\boldsymbol{\epsilon_0} 

\end{aligned}
x
t
​
​
=
1
−
β
t
​
​
x
t
−
1
​
+
β
t
​
​
ϵ
t
−
1
​
=
α
t
​
​
x
t
−
2
​
+
1
−
α
t
​
​
ϵ
t
−
2
​
=
…
=
α
ˉ
t
​
​
x
0
​
+
1
−
α
ˉ
t
​
​
ϵ
0
​
​
Note: Since all timestep have the same Gaussian noise we will only use the symbol 
ϵ
\boldsymbol{\epsilon}
ϵ
 from now on.
Thus to produce a sample 
x
t
\mathbf{x}_t
x
t
​
 we can use the following distribution:
x
t
∼
q
(
x
t
∣
x
0
)
=
N
(
x
t
;
α
ˉ
t
x
0
,
(
1
−
α
ˉ
t
)
I
)
\mathbf{x}_t  \sim q(\mathbf{x}_t \vert \mathbf{x}_0) = \mathcal{N}(\mathbf{x}_t; \sqrt{\bar{\alpha}_t} \mathbf{x}_0, (1 - \bar{\alpha}_t)\mathbf{I})
x
t
​
∼
q
(
x
t
​
∣
x
0
​
)
=
N
(
x
t
​
;
α
ˉ
t
​
​
x
0
​
,
(
1
−
α
ˉ
t
​
)
I
)
Since 
β
t
\beta_t
β
t
​
 is a hyperparameter, we can precompute 
α
t
\alpha_t
α
t
​
 and 
α
ˉ
t
\bar{\alpha}_t
α
ˉ
t
​
 for all timesteps. This means that we sample noise at any timestep 
t
t
t
 and get 
x
t
\mathbf{x}_t
x
t
​
 in one go. Hence, we can sample our latent variable 
x
t
\mathbf{x}_t
x
t
​
 at any arbitrary timestep. This will be our target later on to calculate our tractable objective loss 
L
t
L_t
L
t
​
. 
Variance schedule
The variance parameter 
β
t
\beta_t
β
t
​
 can be fixed to a constant or chosen as a schedule over the 
T
T
T
 timesteps. In fact, one can define a variance schedule, which can be linear, quadratic, cosine etc. The original DDPM authors utilized a linear schedule increasing from 
β
1
=
1
0
−
4
\beta_1= 10^{-4}
β
1
​
=
1
0
−
4
 to 
β
T
=
0.02
\beta_T = 0.02
β
T
​
=
0
.
0
2
. 
Nichol et al. 2021
 showed that employing a cosine schedule works even better.












Latent samples from linear (top) and cosine (bottom)
schedules respectively. Source: 
Nichol & Dhariwal 2021
 
Reverse diffusion
As 
T
→
∞
T \to \infty
T
→
∞
, the latent 
x
T
x_T
x
T
​
 is nearly an 
isotropic
 Gaussian distribution. Therefore if we manage to learn the reverse distribution  
q
(
x
t
−
1
∣
x
t
)
q(\mathbf{x}_{t-1} \vert \mathbf{x}_{t})
q
(
x
t
−
1
​
∣
x
t
​
)
 , we can sample 
x
T
x_T
x
T
​
 from 
N
(
0
,
I
)
\mathcal{N}(0,\mathbf{I})
N
(
0
,
I
)
, run the reverse process and acquire a sample from 
q
(
x
0
)
q(x_0)
q
(
x
0
​
)
, generating a novel data point from the original data distribution.
The question is how we can model the reverse diffusion process.
Approximating the reverse process with a neural network
In practical terms, we don't know 
q
(
x
t
−
1
∣
x
t
)
q(\mathbf{x}_{t-1} \vert \mathbf{x}_{t})
q
(
x
t
−
1
​
∣
x
t
​
)
. It's intractable since statistical estimates of 
q
(
x
t
−
1
∣
x
t
)
q(\mathbf{x}_{t-1} \vert \mathbf{x}_{t})
q
(
x
t
−
1
​
∣
x
t
​
)
 require computations involving the data distribution. 
Instead, we approximate 
q
(
x
t
−
1
∣
x
t
)
q(\mathbf{x}_{t-1} \vert \mathbf{x}_{t})
q
(
x
t
−
1
​
∣
x
t
​
)
 with a parameterized model 
p
θ
p_{\theta}
p
θ
​
 (e.g. a neural network). Since 
q
(
x
t
−
1
∣
x
t
)
q(\mathbf{x}_{t-1} \vert \mathbf{x}_{t})
q
(
x
t
−
1
​
∣
x
t
​
)
 will also be Gaussian, for small enough 
β
t
\beta_t
β
t
​
, we can choose 
p
θ
p_{\theta}
p
θ
​
 to be Gaussian and just parameterize the mean and variance:
p
θ
(
x
t
−
1
∣
x
t
)
=
N
(
x
t
−
1
;
μ
θ
(
x
t
,
t
)
,
Σ
θ
(
x
t
,
t
)
)
p_\theta(\mathbf{x}_{t-1} \vert \mathbf{x}_t) = \mathcal{N}(\mathbf{x}_{t-1}; \boldsymbol{\mu}_\theta(\mathbf{x}_t, t), \boldsymbol{\Sigma}_\theta(\mathbf{x}_t, t)) 
p
θ
​
(
x
t
−
1
​
∣
x
t
​
)
=
N
(
x
t
−
1
​
;
μ
θ
​
(
x
t
​
,
t
)
,
Σ
θ
​
(
x
t
​
,
t
)
)












Reverse diffusion process. Image modified by 
Ho et al. 2020
 
If we apply the reverse formula for all timesteps (
p
θ
(
x
0
:
T
)
p_\theta(\mathbf{x}_{0:T})
p
θ
​
(
x
0
:
T
​
)
, also called trajectory), we can go from 
x
T
\mathbf{x}_T
x
T
​
 to the data distribution:
p
θ
(
x
0
:
T
)
=
p
θ
(
x
T
)
∏
t
=
1
T
p
θ
(
x
t
−
1
∣
x
t
)
p_\theta(\mathbf{x}_{0:T}) = p_{\theta}(\mathbf{x}_T) \prod^T_{t=1} p_\theta(\mathbf{x}_{t-1} \vert \mathbf{x}_t)
p
θ
​
(
x
0
:
T
​
)
=
p
θ
​
(
x
T
​
)
t
=
1
∏
T
​
p
θ
​
(
x
t
−
1
​
∣
x
t
​
)
By additionally conditioning the model on timestep 
t
t
t
, it will learn to predict the Gaussian parameters (meaning the mean 
μ
θ
(
x
t
,
t
)
\boldsymbol{\mu}_\theta(\mathbf{x}_t, t)
μ
θ
​
(
x
t
​
,
t
)
 and the covariance matrix 
Σ
θ
(
x
t
,
t
)
\boldsymbol{\Sigma}_\theta(\mathbf{x}_t, t)
Σ
θ
​
(
x
t
​
,
t
)
 ) for each timestep.
But how do we train such a model? 
Training a diffusion model
If we take a step back, we can notice that the combination of 
q
q
q
 and 
p
p
p
 is very similar to a variational autoencoder (VAE). Thus, we can train it by optimizing the negative log-likelihood of the training data. After a series of calculations, which we won't analyze here, we can write the evidence lower bound (ELBO) as follows:
l
o
g
p
(
x
)
≥
E
q
(
x
1
∣
x
0
)
[
l
o
g
p
θ
(
x
0
∣
x
1
)
]
−
D
K
L
(
q
(
x
T
∣
x
0
)
∣
∣
p
(
x
T
)
)
−
∑
t
=
2
T
E
q
(
x
t
∣
x
0
)
[
D
K
L
(
q
(
x
t
−
1
∣
x
t
,
x
0
)
∣
∣
p
θ
(
x
t
−
1
∣
x
t
)
)
]
=
L
0
−
L
T
−
∑
t
=
2
T
L
t
−
1
\begin{aligned}

log p(\mathbf{x}) \geq 

&\mathbb{E}_{q(x_1 \vert x_0)} [log p_{\theta} (\mathbf{x}_0 \vert \mathbf{x}_1)] - \\ &D_{KL}(q(\mathbf{x}_T \vert \mathbf{x}_0) \vert\vert p(\mathbf{x}_T))- \\

&\sum_{t=2}^T \mathbb{E}_{q(\mathbf{x}_t \vert \mathbf{x}_0)} [D_{KL}(q(\mathbf{x}_{t-1} \vert \mathbf{x}_t, \mathbf{x}_0) \vert \vert p_{\theta}(\mathbf{x}_{t-1} \vert \mathbf{x}_t)) ] \\

& = L_0 - L_T - \sum_{t=2}^T L_{t-1}

\end{aligned}
l
o
g
p
(
x
)
≥
​
E
q
(
x
1
​
∣
x
0
​
)
​
[
l
o
g
p
θ
​
(
x
0
​
∣
x
1
​
)
]
−
D
K
L
​
(
q
(
x
T
​
∣
x
0
​
)
∣
∣
p
(
x
T
​
)
)
−
t
=
2
∑
T
​
E
q
(
x
t
​
∣
x
0
​
)
​
[
D
K
L
​
(
q
(
x
t
−
1
​
∣
x
t
​
,
x
0
​
)
∣
∣
p
θ
​
(
x
t
−
1
​
∣
x
t
​
)
)
]
=
L
0
​
−
L
T
​
−
t
=
2
∑
T
​
L
t
−
1
​
​
Let's analyze these terms:
The 
E
q
(
x
1
∣
x
0
)
[
l
o
g
p
θ
(
x
0
∣
x
1
)
]
\mathbb{E}_{q(x_1 \vert x_0)} [log p_{\theta} (\mathbf{x}_0 \vert \mathbf{x}_1)]
E
q
(
x
1
​
∣
x
0
​
)
​
[
l
o
g
p
θ
​
(
x
0
​
∣
x
1
​
)
]
 term can been as a reconstruction term, similar to the one in the ELBO of a variational autoencoder. In
 Ho et al 2020
 , this term is learned using a separate decoder. 
D
K
L
(
q
(
x
T
∣
x
0
)
∣
∣
p
(
x
T
)
)
D_{KL}(q(\mathbf{x}_T \vert \mathbf{x}_0) \vert\vert p(\mathbf{x}_T))
D
K
L
​
(
q
(
x
T
​
∣
x
0
​
)
∣
∣
p
(
x
T
​
)
)
 shows how close 
x
T
\mathbf{x}_T
x
T
​
 is to the standard Gaussian. Note that the entire term has no trainable parameters so it's ignored during training.
The third term 
∑
t
=
2
T
L
t
−
1
\sum_{t=2}^T L_{t-1}
∑
t
=
2
T
​
L
t
−
1
​
, also referred as 
L
t
L_t
L
t
​
, formulate the difference between the desired denoising steps 
p
θ
(
x
t
−
1
∣
x
t
)
)
p_{\theta}(\mathbf{x}_{t-1} \vert \mathbf{x}_t))
p
θ
​
(
x
t
−
1
​
∣
x
t
​
)
)
 and the approximated ones 
q
(
x
t
−
1
∣
x
t
,
x
0
)
q(\mathbf{x}_{t-1} \vert \mathbf{x}_t, \mathbf{x}_0)
q
(
x
t
−
1
​
∣
x
t
​
,
x
0
​
)
. 
It is evident that through the ELBO, maximizing the likelihood boils down to learning the denoising steps 
L
t
L_t
L
t
​
. 
Important note
: Even though 
q
(
x
t
−
1
∣
x
t
)
q(\mathbf{x}_{t-1} \vert \mathbf{x}_{t})
q
(
x
t
−
1
​
∣
x
t
​
)
 is intractable 
Sohl-Dickstein et al
 illustrated that by additionally conditioning on 
x
0
\textbf{x}_0
x
0
​
 makes it tractable. 
Intuitively, a painter (our generative model) needs a reference image (
x
0
\textbf{x}_0
x
0
​
) to slowly draw (reverse diffusion step 
q
(
x
t
−
1
∣
x
t
,
x
0
)
q(\mathbf{x}_{t-1} \vert \mathbf{x}_t, \mathbf{x}_0)
q
(
x
t
−
1
​
∣
x
t
​
,
x
0
​
)
) an image. Thus, we can take a small step backwards, meaning from noise to generate an image, if and only if we have 
x
0
\textbf{x}_0
x
0
​
 as a reference.
In other words, we can sample 
x
t
\textbf{x}_t
x
t
​
 at noise level 
t
t
t
 conditioned on 
x
0
\textbf{x}_0
x
0
​
. Since 
α
t
=
1
−
β
t
\alpha_t= 1- \beta_t
α
t
​
=
1
−
β
t
​
 and 
α
ˉ
t
=
∏
s
=
0
t
α
s
\bar{\alpha}_t = \prod_{s=0}^t \alpha_s
α
ˉ
t
​
=
∏
s
=
0
t
​
α
s
​
, we can prove that:
q
(
x
t
−
1
∣
x
t
,
x
0
)
=
N
(
x
t
−
1
;
μ
~
(
x
t
,
x
0
)
,
β
~
t
I
)
β
~
t
=
1
−
α
ˉ
t
−
1
1
−
α
ˉ
t
⋅
β
t
μ
~
t
(
x
t
,
x
0
)
=
α
ˉ
t
−
1
β
t
1
−
α
ˉ
t
x
0
+
α
t
(
1
−
α
ˉ
t
−
1
)
1
−
α
ˉ
t
x
t
\begin{aligned}

q(\mathbf{x}_{t-1} \vert \mathbf{x}_t, \mathbf{x}_0) &= \mathcal{N}(\mathbf{x}_{t-1}; {\tilde{\boldsymbol{\mu}}}(\mathbf{x}_t, \mathbf{x}_0), {\tilde{\beta}_t} \mathbf{I}) \\

\tilde{\beta}_t &= \frac{1 - \bar{\alpha}_{t-1}}{1 - \bar{\alpha}_t} \cdot \beta_t \\

\tilde{\boldsymbol{\mu}}_t (\mathbf{x}_t, \mathbf{x}_0) &= \frac{\sqrt{\bar{\alpha}_{t-1}}\beta_t}{1 - \bar{\alpha}_t} \mathbf{x_0} + \frac{\sqrt{\alpha_t}(1 - \bar{\alpha}_{t-1})}{1 - \bar{\alpha}_t} \mathbf{x}_t 

\end{aligned}
q
(
x
t
−
1
​
∣
x
t
​
,
x
0
​
)
β
~
​
t
​
μ
~
​
t
​
(
x
t
​
,
x
0
​
)
​
=
N
(
x
t
−
1
​
;
μ
~
​
(
x
t
​
,
x
0
​
)
,
β
~
​
t
​
I
)
=
1
−
α
ˉ
t
​
1
−
α
ˉ
t
−
1
​
​
⋅
β
t
​
=
1
−
α
ˉ
t
​
α
ˉ
t
−
1
​
​
β
t
​
​
x
0
​
+
1
−
α
ˉ
t
​
α
t
​
​
(
1
−
α
ˉ
t
−
1
​
)
​
x
t
​
​
Note that 
α
t
\alpha_t
α
t
​
 and 
α
ˉ
t
\bar{\alpha}_t
α
ˉ
t
​
 depend only on 
β
t
\beta_t
β
t
​
, so they can be precomputed.
This little trick provides us with a fully tractable ELBO. The above property has one more important side effect, as we already saw in the reparameterization trick, we can represent 
x
0
\mathbf{x}_0
x
0
​
 as
x
0
=
1
α
ˉ
t
(
x
t
−
1
−
α
ˉ
t
ϵ
)
)
,
\mathbf{x}_0 = \frac{1}{\sqrt{\bar{\alpha}_t}}(\mathbf{x}_t - \sqrt{1 - \bar{\alpha}_t} \boldsymbol{\epsilon})),
x
0
​
=
α
ˉ
t
​
​
1
​
(
x
t
​
−
1
−
α
ˉ
t
​
​
ϵ
)
)
,
where 
ϵ
∼
N
(
0
,
I
)
\boldsymbol{\epsilon} \sim \mathcal{N}(\textbf{0},\mathbf{I})
ϵ
∼
N
(
0
,
I
)
.
By combining the last two equations, each timestep will now have a mean 
μ
~
t
\tilde{\boldsymbol{\mu}}_t
μ
~
​
t
​
 (our target) that only depends on 
x
t
\mathbf{x}_t
x
t
​
:
μ
~
t
(
x
t
)
=
1
α
t
(
x
t
−
β
t
1
−
α
ˉ
t
ϵ
)
)
\tilde{\boldsymbol{\mu}}_t (\mathbf{x}_t) = {\frac{1}{\sqrt{\alpha_t}} \Big( \mathbf{x}_t - \frac{\beta_t}{\sqrt{1 - \bar{\alpha}_t}} \boldsymbol{\epsilon} ) \Big)}
μ
~
​
t
​
(
x
t
​
)
=
α
t
​
​
1
​
(
x
t
​
−
1
−
α
ˉ
t
​
​
β
t
​
​
ϵ
)
)
Therefore we can use a neural network 
ϵ
θ
(
x
t
,
t
)
\epsilon_{\theta}(\mathbf{x}_t,t)
ϵ
θ
​
(
x
t
​
,
t
)
 to approximate 
ϵ
\boldsymbol{\epsilon}
ϵ
 and consequently the mean:
μ
θ
~
(
x
t
,
t
)
=
1
α
t
(
x
t
−
β
t
1
−
α
ˉ
t
ϵ
θ
(
x
t
,
t
)
)
\tilde{\boldsymbol{\mu}_{\theta}}( \mathbf{x}_t,t) = {\frac{1}{\sqrt{\alpha_t}} \Big( \mathbf{x}_t - \frac{\beta_t}{\sqrt{1 - \bar{\alpha}_t}} \boldsymbol{\epsilon}_{\theta}(\mathbf{x}_t,t) \Big)}
μ
θ
​
~
​
(
x
t
​
,
t
)
=
α
t
​
​
1
​
(
x
t
​
−
1
−
α
ˉ
t
​
​
β
t
​
​
ϵ
θ
​
(
x
t
​
,
t
)
)
Thus, the loss function (the denoising term in the ELBO) can be expressed as:
L
t
=
E
x
0
,
t
,
ϵ
[
1
2
∣
∣
Σ
θ
(
x
t
,
t
)
∣
∣
2
2
∣
∣
μ
~
t
−
μ
θ
(
x
t
,
t
)
∣
∣
2
2
]
=
E
x
0
,
t
,
ϵ
[
β
t
2
2
α
t
(
1
−
α
ˉ
t
)
∣
∣
Σ
θ
∣
∣
2
2
∥
ϵ
t
−
ϵ
θ
(
a
ˉ
t
x
0
+
1
−
a
ˉ
t
ϵ
,
t
)
∣
∣
2
]
\begin{aligned}

L_t &= \mathbb{E}_{\mathbf{x}_0,t,\boldsymbol{\epsilon}}\Big[\frac{1}{2||\boldsymbol{\Sigma}_\theta (x_t,t)||_2^2} ||\tilde{\boldsymbol{\mu}}_t - \boldsymbol{\mu}_\theta(\mathbf{x}_t, t)||_2^2 \Big] \\

&= \mathbb{E}_{\mathbf{x}_0,t,\boldsymbol{\epsilon}}\Big[\frac{\beta_t^2}{2\alpha_t (1 - \bar{\alpha}_t) ||\boldsymbol{\Sigma}_\theta||^2_2} \| \boldsymbol{\epsilon}_{t}-  \boldsymbol{\epsilon}_{\theta}(\sqrt{\bar{a}_t} \mathbf{x}_0 + \sqrt{1-\bar{a}_t}\boldsymbol{\epsilon}, t ) ||^2 \Big]

\end{aligned}
L
t
​
​
=
E
x
0
​
,
t
,
ϵ
​
[
2
∣
∣
Σ
θ
​
(
x
t
​
,
t
)
∣
∣
2
2
​
1
​
∣
∣
μ
~
​
t
​
−
μ
θ
​
(
x
t
​
,
t
)
∣
∣
2
2
​
]
=
E
x
0
​
,
t
,
ϵ
​
[
2
α
t
​
(
1
−
α
ˉ
t
​
)
∣
∣
Σ
θ
​
∣
∣
2
2
​
β
t
2
​
​
∥
ϵ
t
​
−
ϵ
θ
​
(
a
ˉ
t
​
​
x
0
​
+
1
−
a
ˉ
t
​
​
ϵ
,
t
)
∣
∣
2
]
​
This effectively shows us that instead of predicting the mean of the distribution, the model will predict the noise 
ϵ
\boldsymbol{\epsilon}
ϵ
 at each timestep 
t
t
t
.
Ho et.al 2020
 made a few simplifications to the actual loss term as they ignore a weighting term. The simplified version outperforms the full objective:
L
t
simple
=
E
x
0
,
t
,
ϵ
[
∥
ϵ
−
ϵ
θ
(
a
ˉ
t
x
0
+
1
−
a
ˉ
t
ϵ
,
t
)
∣
∣
2
]
L_t^\text{simple} = \mathbb{E}_{\mathbf{x}_0, t, \boldsymbol{\epsilon}} \Big[\|\boldsymbol{\epsilon}- \boldsymbol{\epsilon}_{\theta}(\sqrt{\bar{a}_t} \mathbf{x}_0 + \sqrt{1-\bar{a}_t} \boldsymbol{\epsilon}, t ) ||^2 \Big]
L
t
simple
​
=
E
x
0
​
,
t
,
ϵ
​
[
∥
ϵ
−
ϵ
θ
​
(
a
ˉ
t
​
​
x
0
​
+
1
−
a
ˉ
t
​
​
ϵ
,
t
)
∣
∣
2
]
The authors found that optimizing the above objective works better than optimizing the original ELBO. The proof for both equations can be found in this 
excellent post by Lillian Weng
 or in
 Luo et al. 2022
. 
Additionally, 
Ho et. al 2020
 decide to keep the variance fixed and have the network learn only the mean. This was later improved by 
Nichol et al. 2021
, who decide to let the network learn the covariance matrix 
(
Σ
)
(\boldsymbol{\Sigma})
(
Σ
)
 as well (by modifying 
L
t
simple
L_t^\text{simple}
L
t
simple
​
 ), achieving better results.












Training and sampling algorithms of DDPMs. Source: 
Ho et al. 2020
 
Architecture
One thing that we haven't mentioned so far is what the model's architecture looks like. Notice that the model's input and output should be of the same size. 
To this end, 
Ho et al.
 employed a U-Net. If you are unfamiliar with U-Nets, feel free to check out our past article on the 
major U-Net architectures
. In a few words, a U-Net is a symmetric architecture with input and output of the same spatial size that uses 
skip connections
 between encoder and decoder blocks of corresponding feature dimension. Usually, the input image is first downsampled and then upsampled until reaching its initial size.
In the original implementation of DDPMs, the U-Net consists of Wide
 ResNet blocks
, 
group normalization
 as well as 
self-attention
 blocks. 
The diffusion timestep 
t
t
t
 is specified by adding a sinusoidal 
position embedding
 into each residual block. For more details, feel free to visit the 
official GitHub repository
. For a detailed implementation of the diffusion model, check out this awesome
 post by Hugging Face
.












The U-Net architecture. Source: 
Ronneberger et al.
 
Conditional Image Generation: Guided Diffusion
A crucial aspect of image generation is conditioning the sampling process to manipulate the generated samples. Here, this is also referred to as guided diffusion.
There have even been methods that incorporate image embeddings into the diffusion in order to "guide" the generation. Mathematically, guidance refers to conditioning a prior data distribution 
p
(
x
)
p(\textbf{x})
p
(
x
)
 with a condition 
y
y
y
, i.e. the class label or an image/text embedding, resulting in 
p
(
x
∣
y
)
p(\textbf{x}|y)
p
(
x
∣
y
)
. 
To turn a diffusion model 
p
θ
p_\theta
p
θ
​
 into a conditional diffusion model, we can add conditioning information 
y
y
y
 at each diffusion step. 
p
θ
(
x
0
:
T
∣
y
)
=
p
θ
(
x
T
)
∏
t
=
1
T
p
θ
(
x
t
−
1
∣
x
t
,
y
)
p_\theta(\mathbf{x}_{0:T} \vert y) = p_\theta(\mathbf{x}_T) \prod^T_{t=1} p_\theta(\mathbf{x}_{t-1} \vert \mathbf{x}_t, y)
p
θ
​
(
x
0
:
T
​
∣
y
)
=
p
θ
​
(
x
T
​
)
t
=
1
∏
T
​
p
θ
​
(
x
t
−
1
​
∣
x
t
​
,
y
)
The fact that the conditioning is being seen at each timestep may be a good justification for the excellent samples from a text prompt. 
In general, guided diffusion models aim to learn 
∇
log
⁡
p
θ
(
x
t
∣
y
)
\nabla \log p_\theta( \mathbf{x}_t \vert y)
∇
lo
g
p
θ
​
(
x
t
​
∣
y
)
. So using the Bayes rule, we can write:
∇
x
t
log
⁡
p
θ
(
x
t
∣
y
)
=
∇
x
t
log
⁡
(
p
θ
(
y
∣
x
t
)
p
θ
(
x
t
)
p
θ
(
y
)
)
=
∇
x
t
l
o
g
p
θ
(
x
t
)
+
∇
x
t
l
o
g
(
p
θ
(
y
∣
x
t
)
)
\begin{aligned}

\nabla_{\textbf{x}_{t}} \log p_\theta(\mathbf{x}_t \vert y) &= \nabla_{\textbf{x}_{t}} \log (\frac{p_\theta(y \vert \mathbf{x}_t) p_\theta(\mathbf{x}_t) }{p_\theta(y)}) \\

&= \nabla_{\textbf{x}_{t}} log p_\theta(\mathbf{x}_t) + \nabla_{\textbf{x}_{t}} log (p_\theta( y \vert\mathbf{x}_t ))

\end{aligned}
∇
x
t
​
​
lo
g
p
θ
​
(
x
t
​
∣
y
)
​
=
∇
x
t
​
​
lo
g
(
p
θ
​
(
y
)
p
θ
​
(
y
∣
x
t
​
)
p
θ
​
(
x
t
​
)
​
)
=
∇
x
t
​
​
l
o
g
p
θ
​
(
x
t
​
)
+
∇
x
t
​
​
l
o
g
(
p
θ
​
(
y
∣
x
t
​
)
)
​
p
θ
(
y
)
p_\theta(y)
p
θ
​
(
y
)
 is removed since the gradient operator 
∇
x
t
\nabla_{\textbf{x}_{t}}
∇
x
t
​
​
 refers only to 
x
t
\textbf{x}_{t}
x
t
​
, so no gradient for 
y
y
y
. Moreover remember that 
log
⁡
(
a
b
)
=
log
⁡
(
a
)
+
log
⁡
(
b
)
\log(a b)= \log(a) + \log(b)
lo
g
(
a
b
)
=
lo
g
(
a
)
+
lo
g
(
b
)
.
And by adding a guidance scalar term 
s
s
s
, we have:
∇
log
⁡
p
θ
(
x
t
∣
y
)
=
∇
log
⁡
p
θ
(
x
t
)
+
s
⋅
∇
log
⁡
(
p
θ
(
y
∣
x
t
)
)
\nabla \log p_\theta(\mathbf{x}_t \vert y) =  \nabla \log p_\theta(\mathbf{x}_t) +  s \cdot \nabla \log (p_\theta( y \vert\mathbf{x}_t ))
∇
lo
g
p
θ
​
(
x
t
​
∣
y
)
=
∇
lo
g
p
θ
​
(
x
t
​
)
+
s
⋅
∇
lo
g
(
p
θ
​
(
y
∣
x
t
​
)
)
Using this formulation, let's make a distinction between classifier and classifier-free guidance. Next, we will present two family of methods aiming at injecting label information. 
Classifier guidance
Sohl-Dickstein et al
. and later 
Dhariwal and Nichol
 showed that we can use a second model, a classifier 
f
ϕ
(
y
∣
x
t
,
t
)
f_\phi(y \vert \mathbf{x}_t, t)
f
ϕ
​
(
y
∣
x
t
​
,
t
)
, to guide the diffusion toward the target class 
y
y
y
 during training. To achieve that, we can train a classifier 
f
ϕ
(
y
∣
x
t
,
t
)
f_\phi(y \vert \mathbf{x}_t, t)
f
ϕ
​
(
y
∣
x
t
​
,
t
)
 on the noisy image 
x
t
\mathbf{x}_t
x
t
​
 to predict its class 
y
y
y
. Then we can use the gradients 
∇
log
⁡
(
f
ϕ
(
y
∣
x
t
)
)
\nabla \log (f_\phi( y \vert\mathbf{x}_t ))
∇
lo
g
(
f
ϕ
​
(
y
∣
x
t
​
)
)
 to guide the diffusion. How?
We can build a class-conditional diffusion model with mean 
μ
θ
(
x
t
∣
y
)
\mu_\theta(\mathbf{x}_t|y)
μ
θ
​
(
x
t
​
∣
y
)
 and variance 
Σ
θ
(
x
t
∣
y
)
\boldsymbol{\Sigma}_\theta(\mathbf{x}_t |y)
Σ
θ
​
(
x
t
​
∣
y
)
.
Since 
p
θ
∼
N
(
μ
θ
,
Σ
θ
)
p_\theta \sim \mathcal{N}(\mu_{\theta}, \Sigma_{\theta})
p
θ
​
∼
N
(
μ
θ
​
,
Σ
θ
​
)
, we can show using the guidance formulation from the previous section that the mean is perturbed by the gradients of  
log
⁡
f
ϕ
(
y
∣
x
t
)
\log f_\phi(y|\mathbf{x}_t)
lo
g
f
ϕ
​
(
y
∣
x
t
​
)
 of class 
y
y
y
, resulting in:
μ
^
(
x
t
∣
y
)
=
μ
θ
(
x
t
∣
y
)
+
s
⋅
Σ
θ
(
x
t
∣
y
)
∇
x
t
l
o
g
f
ϕ
(
y
∣
x
t
,
t
)
\hat{\mu}(\mathbf{x}_t |y) =\mu_\theta(\mathbf{x}_t |y) + s \cdot \boldsymbol{\Sigma}_\theta(\mathbf{x}_t |y) \nabla_{\mathbf{x}_t} logf_\phi(y \vert \mathbf{x}_t, t)
μ
^
​
(
x
t
​
∣
y
)
=
μ
θ
​
(
x
t
​
∣
y
)
+
s
⋅
Σ
θ
​
(
x
t
​
∣
y
)
∇
x
t
​
​
l
o
g
f
ϕ
​
(
y
∣
x
t
​
,
t
)
In the famous 
GLIDE paper by Nichol et al
, the authors expanded on this idea and use 
CLIP embeddings
 to guide the diffusion. CLIP as proposed by 
Saharia et al.
, consists of an image encoder 
g
g
g
 and a text encoder 
h
h
h
. It produces an image and text embeddings 
g
(
x
t
)
g(\mathbf{x}_t)
g
(
x
t
​
)
 and 
h
(
c
)
h(c)
h
(
c
)
, respectively, wherein 
c
c
c
 is the text caption. 
Therefore, we can perturb the gradients with their dot product:
μ
^
(
x
t
∣
c
)
=
μ
(
x
t
∣
c
)
+
s
⋅
Σ
θ
(
x
t
∣
c
)
∇
x
t
g
(
x
t
)
⋅
h
(
c
)
\hat{\mu}(\mathbf{x}_t |c) =\mu(\mathbf{x}_t |c) + s \cdot \boldsymbol{\Sigma}_\theta(\mathbf{x}_t |c) \nabla_{\mathbf{x}_t} g(\mathbf{x}_t) \cdot h(c)
μ
^
​
(
x
t
​
∣
c
)
=
μ
(
x
t
​
∣
c
)
+
s
⋅
Σ
θ
​
(
x
t
​
∣
c
)
∇
x
t
​
​
g
(
x
t
​
)
⋅
h
(
c
)
As a result, they manage to "steer" the generation process toward a user-defined text caption.












Algorithm of classifier guided diffusion sampling. Source: 
Dhariwal & Nichol 2021
 
Classifier-free guidance
Using the same formulation as before we can define a classifier-free guided diffusion model as:
∇
log
⁡
p
(
x
t
∣
y
)
=
s
⋅
∇
l
o
g
(
p
(
x
t
∣
y
)
)
+
(
1
−
s
)
⋅
∇
l
o
g
p
(
x
t
)
\nabla \log p(\mathbf{x}_t \vert y)  =s \cdot \nabla log(p(\mathbf{x}_t \vert y)) + (1-s) \cdot \nabla log p(\mathbf{x}_t) 
∇
lo
g
p
(
x
t
​
∣
y
)
=
s
⋅
∇
l
o
g
(
p
(
x
t
​
∣
y
)
)
+
(
1
−
s
)
⋅
∇
l
o
g
p
(
x
t
​
)
Guidance can be achieved without a second classifier model as proposed by 
Ho & Salimans
. Instead of training a separate classifier, the authors trained a conditional diffusion model 
ϵ
θ
(
x
t
∣
y
)
\boldsymbol{\epsilon}_\theta (\mathbf{x}_t|y)
ϵ
θ
​
(
x
t
​
∣
y
)
 together with an unconditional model 
ϵ
θ
(
x
t
∣
0
)
\boldsymbol{\epsilon}_\theta (\mathbf{x}_t |0)
ϵ
θ
​
(
x
t
​
∣
0
)
. In fact, they use the exact same neural network. During training, they randomly set the class 
y
y
y
 to 
0
0
0
, so that the model is exposed to both the conditional and unconditional setup:
ϵ
^
θ
(
x
t
∣
y
)
=
s
⋅
ϵ
θ
(
x
t
∣
y
)
+
(
1
−
s
)
⋅
ϵ
θ
(
x
t
∣
0
)
=
ϵ
θ
(
x
t
∣
0
)
+
s
⋅
(
ϵ
θ
(
x
t
∣
y
)
−
ϵ
θ
(
x
t
∣
0
)
)
\begin{aligned}

\hat{\boldsymbol{\epsilon}}_\theta(\mathbf{x}_t |y) & = s \cdot \boldsymbol{\epsilon}_\theta(\mathbf{x}_t |y) + (1-s) \cdot \boldsymbol{\epsilon}_\theta(\mathbf{x}_t |0) \\

 &=  \boldsymbol{\epsilon}_\theta(\mathbf{x}_t |0) + s \cdot (\boldsymbol{\epsilon}_\theta(\mathbf{x}_t |y) -\boldsymbol{\epsilon}_\theta(\mathbf{x}_t |0) )

\end{aligned}
ϵ
^
θ
​
(
x
t
​
∣
y
)
​
=
s
⋅
ϵ
θ
​
(
x
t
​
∣
y
)
+
(
1
−
s
)
⋅
ϵ
θ
​
(
x
t
​
∣
0
)
=
ϵ
θ
​
(
x
t
​
∣
0
)
+
s
⋅
(
ϵ
θ
​
(
x
t
​
∣
y
)
−
ϵ
θ
​
(
x
t
​
∣
0
)
)
​
Note that this can also be used to "inject" text embeddings as we showed in classifier guidance.
This admittedly "weird" process has two major advantages:
It uses only a single model to guide the diffusion.
It simplifies guidance when conditioning on information that is difficult to predict with a classifier (such as text embeddings).
Imagen as proposed by 
Saharia et al
. relies heavily on classifier-free guidance, as they find that it is a key contributor to generating samples with strong image-text alignment. For more info on the approach of Imagen check out this video from AI Coffee Break with Letitia:
Scaling up diffusion models
You might be asking what is the problem with these models. Well, it's computationally very expensive to scale these U-nets into high-resolution images. This brings us to two methods for scaling up diffusion models to higher resolutions: cascade diffusion models and latent diffusion models.
Cascade diffusion models
Ho et al. 2021
 introduced cascade diffusion models in an effort to produce high-fidelity images. A cascade diffusion model consists of a pipeline of many sequential diffusion models that generate images of increasing resolution. Each model generates a sample with superior quality than the previous one by successively upsampling the image and adding higher resolution details. To generate an image, we sample sequentially from each diffusion model.












Cascade diffusion model pipeline. Source: Ho & Saharia et al.
 
To acquire good results with cascaded architectures, strong data augmentations on the input of each super-resolution model are crucial. Why? Because it alleviates compounding error from the previous cascaded models, as well as due to a train-test mismatch.
It was found that gaussian blurring is a critical transformation toward achieving high fidelity. They refer to this technique as conditioning augmentation.
Stable diffusion: Latent diffusion models
Latent diffusion models are based on a rather simple idea: instead of applying the diffusion process directly on a high-dimensional input, we project the input into a smaller latent space and apply the diffusion there. 
In more detail, 
Rombach et al
. proposed to use an encoder network to encode the input into a latent representation i.e. 
z
t
=
g
(
x
t
)
\mathbf{z}_t = g(\mathbf{x}_t)
z
t
​
=
g
(
x
t
​
)
. The intuition behind this decision is to lower the computational demands of training diffusion models by processing the input in a lower dimensional space. Afterward, a standard diffusion model (U-Net) is applied to generate new data, which are upsampled by a decoder network.
If the loss for a typical diffusion model (DM) is formulated as:
L
D
M
=
E
x
,
t
,
ϵ
[
∥
ϵ
−
ϵ
θ
(
x
t
,
t
)
∣
∣
2
]
L _{DM} = \mathbb{E}_{\mathbf{x}, t, \boldsymbol{\epsilon}} \Big[\| \boldsymbol{\epsilon}-  \boldsymbol{\epsilon}_{\theta}( \mathbf{x}_t, t ) ||^2 \Big]
L
D
M
​
=
E
x
,
t
,
ϵ
​
[
∥
ϵ
−
ϵ
θ
​
(
x
t
​
,
t
)
∣
∣
2
]
then given an encoder 
E
\mathcal{E}
E
 and a latent representation 
z
z
z
, the loss for a latent diffusion model (LDM) is:
L
L
D
M
=
E
E
(
x
)
,
t
,
ϵ
[
∥
ϵ
−
ϵ
θ
(
z
t
,
t
)
∣
∣
2
]
L _{LDM} = \mathbb{E}_{ \mathcal{E}(\mathbf{x}), t,  \boldsymbol{\epsilon}} \Big[\|  \boldsymbol{\epsilon}-  \boldsymbol{\epsilon}_{\theta}( \mathbf{z}_t, t ) ||^2 \Big]
L
L
D
M
​
=
E
E
(
x
)
,
t
,
ϵ
​
[
∥
ϵ
−
ϵ
θ
​
(
z
t
​
,
t
)
∣
∣
2
]












Latent diffusion models. Source: 
Rombach et al
 
For more information check out this video:
Score-based generative models
Around the same time as the DDPM paper, 
Song and Ermon
 proposed a different type of generative model that appears to have many similarities with diffusion models. Score-based models tackle generative learning using score matching and Langevin dynamics.
Score-matching
 refers to the process of modeling the gradient of the log probability density function, also known as the score function. 
Langevin dynamics
 is an iterative process that can draw samples from a distribution using only its score function.
x
t
=
x
t
−
1
+
δ
2
∇
x
log
⁡
p
(
x
t
−
1
)
+
δ
ϵ
,
 where 
ϵ
∼
N
(
0
,
I
)
\mathbf{x}_t=\mathbf{x}_{t-1}+\frac{\delta}{2} \nabla_{\mathbf{x}} \log p\left(\mathbf{x}_{t-1}\right)+\sqrt{\delta} \boldsymbol{\epsilon}, \quad \text { where } \boldsymbol{\epsilon} \sim \mathcal{N}(\mathbf{0}, \mathbf{I})
x
t
​
=
x
t
−
1
​
+
2
δ
​
∇
x
​
lo
g
p
(
x
t
−
1
​
)
+
δ
​
ϵ
,
 where 
ϵ
∼
N
(
0
,
I
)
where 
δ
\delta
δ
 is the step size.
Suppose that we have a probability density 
p
(
x
)
p(x)
p
(
x
)
 and that we define the score function to be 
∇
x
log
⁡
p
(
x
)
\nabla_x \log p(x)
∇
x
​
lo
g
p
(
x
)
. We can then train a neural network 
s
θ
s_{\theta}
s
θ
​
 to estimate 
∇
x
log
⁡
p
(
x
)
\nabla_x \log p(x)
∇
x
​
lo
g
p
(
x
)
 without estimating 
p
(
x
)
p(x)
p
(
x
)
 first. The training objective can be formulated as follows:
E
p
(
x
)
[
∥
∇
x
log
⁡
p
(
x
)
−
s
θ
(
x
)
∥
2
2
]
=
∫
p
(
x
)
∥
∇
x
log
⁡
p
(
x
)
−
s
θ
(
x
)
∥
2
2
d
x
\mathbb{E}_{p(\mathbf{x})}[\| \nabla_\mathbf{x} \log p(\mathbf{x}) - \mathbf{s}_\theta(\mathbf{x})  \|_2^2] = \int p(\mathbf{x}) \| \nabla_\mathbf{x} \log p(\mathbf{x}) - \mathbf{s}_\theta(\mathbf{x})  \|_2^2 \mathrm{d}\mathbf{x}
E
p
(
x
)
​
[
∥
∇
x
​
lo
g
p
(
x
)
−
s
θ
​
(
x
)
∥
2
2
​
]
=
∫
p
(
x
)
∥
∇
x
​
lo
g
p
(
x
)
−
s
θ
​
(
x
)
∥
2
2
​
d
x
Then by using Langevin dynamics, we can directly sample from 
p
(
x
)
p(x)
p
(
x
)
 using the approximated score function. 
In case you missed it, guided diffusion models use this formulation of score-based models as they learn directly 
∇
x
log
⁡
p
(
x
)
\nabla_x \log p(x)
∇
x
​
lo
g
p
(
x
)
. Of course, they don’t rely on Langevin dynamics.
Adding noise to score-based models: Noise Conditional Score Networks (NCSN)
The problem so far: the estimated score functions are usually inaccurate in low-density regions, where few data points are available. As a result, the quality of data sampled using Langevin dynamics is 
not
 good. 
Their solution was to perturb the data points with noise and train score-based models on the noisy data points instead. As a matter of fact, they used multiple scales of Gaussian noise perturbations. 
Thus, adding noise is the key to make both DDPM and score based models work. 












Score-based generative modeling with score matching + Langevin dynamics. Source: 
Generative Modeling by Estimating Gradients of the Data Distribution
 
Mathematically, given the data distribution 
p
(
x
)
p(x)
p
(
x
)
, we perturb with Gaussian noise 
N
(
0
,
σ
i
2
I
)
\mathcal{N}(\textbf{0}, \sigma_i^2 I)
N
(
0
,
σ
i
2
​
I
)
  where 
i
=
1
,
2
,
⋯
 
,
L
i=1,2,\cdots,L
i
=
1
,
2
,
⋯
,
L
 to obtain a noise-perturbed distribution:
p
σ
i
(
x
)
=
∫
p
(
y
)
N
(
x
;
y
,
σ
i
2
I
)
d
y
p_{\sigma_i}(\mathbf{x}) = \int p(\mathbf{y}) \mathcal{N}(\mathbf{x}; \mathbf{y}, \sigma_i^2 I) \mathrm{d} \mathbf{y}
p
σ
i
​
​
(
x
)
=
∫
p
(
y
)
N
(
x
;
y
,
σ
i
2
​
I
)
d
y
Then we train a network 
s
θ
(
x
,
i
)
s_\theta(\mathbf{x},i)
s
θ
​
(
x
,
i
)
, known as Noise Conditional Score-Based Network (NCSN) to estimate the score function 
∇
x
log
⁡
d
σ
i
(
x
)
\nabla_\mathbf{x} \log d_{\sigma_i}(\mathbf{x})
∇
x
​
lo
g
d
σ
i
​
​
(
x
)
. The training objective is a weighted sum of 
Fisher divergences
 for all noise scales.
∑
i
=
1
L
λ
(
i
)
E
p
σ
i
(
x
)
[
∥
∇
x
log
⁡
p
σ
i
(
x
)
−
s
θ
(
x
,
i
)
∥
2
2
]
\sum_{i=1}^L \lambda(i) \mathbb{E}_{p_{\sigma_i}(\mathbf{x})}[\| \nabla_\mathbf{x} \log p_{\sigma_i}(\mathbf{x}) - \mathbf{s}_\theta(\mathbf{x}, i)  \|_2^2]
i
=
1
∑
L
​
λ
(
i
)
E
p
σ
i
​
​
(
x
)
​
[
∥
∇
x
​
lo
g
p
σ
i
​
​
(
x
)
−
s
θ
​
(
x
,
i
)
∥
2
2
​
]
Score-based generative modeling through stochastic differential equations (SDE)
Song et al. 2021
 explored the connection of score-based models with diffusion models. In an effort to encapsulate both NSCNs and DDPMs under the same umbrella, they proposed the following:
Instead of perturbing data with a finite number of noise distributions, we use a continuum of distributions that evolve over time according to a diffusion process. This process is modeled by a prescribed stochastic differential equation (SDE) that does not depend on the data and has no trainable parameters. By reversing the process, we can generate new samples.












Score-based generative modeling through stochastic differential equations (SDE). Source: 
Song et al. 2021
 
We can define the diffusion process 
{
x
(
t
)
}
t
∈
[
0
,
T
]
\{ \mathbf{x}(t) \}_{t\in [0, T]}
{
x
(
t
)
}
t
∈
[
0
,
T
]
​
 as an SDE in the following form:
d
x
=
f
(
x
,
t
)
d
t
+
g
(
t
)
d
w
\mathrm{d}\mathbf{x} = \mathbf{f}(\mathbf{x}, t) \mathrm{d}t + g(t) \mathrm{d} \mathbf{w}
d
x
=
f
(
x
,
t
)
d
t
+
g
(
t
)
d
w
where 
w
\mathbf{w}
w
 is the 
Wiener process
 (a.k.a., 
Brownian motion
), 
f
(
⋅
,
t
)
\mathbf{f}(\cdot, t)
f
(
⋅
,
t
)
 is a vector-valued function called the drift coefficient of 
x
(
t
)
\mathbf{x}(t)
x
(
t
)
, and 
g
(
⋅
)
g(\cdot)
g
(
⋅
)
 is a scalar function known as the diffusion coefficient of 
x
(
t
)
\mathbf{x}(t)
x
(
t
)
. Note that the SDE typically has a unique strong solution. 
To make sense of why we use an SDE, here is a tip: the SDE is inspired by the Brownian motion, in which a number of particles move randomly inside a medium. This randomness of the particles' motion models the continuous noise perturbations on the data.
After perturbing the original data distribution for a sufficiently long time, the perturbed distribution becomes close to a tractable noise distribution.
To generate new samples, we need to reverse the diffusion process. The SDE was chosen to have a corresponding reverse SDE in closed form:
d
x
=
[
f
(
x
,
t
)
−
g
2
(
t
)
∇
x
log
⁡
p
t
(
x
)
]
d
t
+
g
(
t
)
d
w
\mathrm{d}\mathbf{x} = [\mathbf{f}(\mathbf{x}, t) - g^2(t) \nabla_\mathbf{x} \log p_t(\mathbf{x})]\mathrm{d}t + g(t) \mathrm{d} \mathbf{w}
d
x
=
[
f
(
x
,
t
)
−
g
2
(
t
)
∇
x
​
lo
g
p
t
​
(
x
)
]
d
t
+
g
(
t
)
d
w
To compute the reverse SDE, we need to estimate the score function 
∇
x
log
⁡
p
t
(
x
)
\nabla_\mathbf{x} \log p_t(\mathbf{x})
∇
x
​
lo
g
p
t
​
(
x
)
. This is done using a score-based model 
s
θ
(
x
,
i
)
s_\theta(\mathbf{x},i)
s
θ
​
(
x
,
i
)
 and Langevin dynamics. The training objective is a continuous combination of Fisher divergences:
E
t
∈
U
(
0
,
T
)
E
p
t
(
x
)
[
λ
(
t
)
∥
∇
x
log
⁡
p
t
(
x
)
−
s
θ
(
x
,
t
)
∥
2
2
]
\mathbb{E}_{t \in \mathcal{U}(0, T)}\mathbb{E}_{p_t(\mathbf{x})}[\lambda(t) \| \nabla_\mathbf{x} \log p_t(\mathbf{x}) - \mathbf{s}_\theta(\mathbf{x}, t) \|_2^2]
E
t
∈
U
(
0
,
T
)
​
E
p
t
​
(
x
)
​
[
λ
(
t
)
∥
∇
x
​
lo
g
p
t
​
(
x
)
−
s
θ
​
(
x
,
t
)
∥
2
2
​
]
where  
U
(
0
,
T
)
\mathcal{U}(0, T)
U
(
0
,
T
)
 denotes a uniform distribution over the time interval, and 
λ
\lambda
λ
  is a positive weighting function. Once we have the score function, we can plug it into the reverse SDE and solve it in order to sample 
x
(
0
)
\mathbf{x}(0)
x
(
0
)
 from the original data distribution 
p
0
(
x
)
p_0(\mathbf{x})
p
0
​
(
x
)
.
There are a number of options to solve the reverse SDE  which we won't analyze here. Make sure to check the original paper or this
 excellent blog post by the author
.












Overview of score-based generative modeling through SDEs. Source: 
Song et al. 2021
 
Summary
Let’s do a quick sum-up of the main points we learned in this blogpost:
Diffusion models work by gradually adding gaussian noise through a series of 
T
T
T
 steps into the original image, a process known as diffusion.
To sample new data, we approximate the reverse diffusion process using a neural network.
The training of the model is based on maximizing the evidence lower bound (ELBO).
We can condition the diffusion models on image labels or text embeddings in order to “guide” the diffusion process.
Cascade and Latent diffusion are two approaches to scale up models to high-resolutions.
Cascade diffusion models are sequential diffusion models that generate images of increasing resolution.
Latent diffusion models (like stable diffusion) apply the diffusion process on a smaller latent space for computational efficiency using a variational autoencoder for the up and downsampling.
Score-based models also apply a sequence of noise perturbations to the original image. But they are trained using score-matching and Langevin dynamics. Nonetheless, they end up in a similar objective.
The diffusion process can be formulated as an SDE. Solving the reverse SDE allows us to generate new samples. 
Finally, for more associations between 
diffusion models and VAE
 or 
AE check out these really nice blogs
. 
Cite as
@article
{
karagiannakos2022diffusionmodels
,
    title   
=
 
"Diffusion models: toward state-of-the-art image generation"
,
    author  
=
 
"Karagiannakos, Sergios, Adaloglou, Nikolaos"
,
    journal 
=
 
"https://theaisummer.com/"
,
    year    
=
 
"2022"
,
    howpublished 
=
 
{
https
:
//
theaisummer
.
com
/
diffusion
-
models
/
}
,
  
}
References
[1]
 Sohl-Dickstein, Jascha, et al.
 Deep Unsupervised Learning Using Nonequilibrium Thermodynamics
. arXiv:1503.03585, arXiv, 18 Nov. 2015
[2]
 Ho, Jonathan, et al. 
Denoising Diffusion Probabilistic Models
. arXiv:2006.11239, arXiv, 16 Dec. 2020
[3]
 Nichol, Alex, and Prafulla Dhariwal.
 Improved Denoising Diffusion Probabilistic Models
. arXiv:2102.09672, arXiv, 18 Feb. 2021
[4]
 Dhariwal, Prafulla, and Alex Nichol.
 Diffusion Models Beat GANs on Image Synthesis
. arXiv:2105.05233, arXiv, 1 June 2021
[5]
 Nichol, Alex, et al. 
GLIDE: Towards Photorealistic Image Generation and Editing with Text-Guided Diffusion Models
. arXiv:2112.10741, arXiv, 8 Mar. 2022
[6]
 Ho, Jonathan, and Tim Salimans.
 Classifier-Free Diffusion Guidance
. 2021. openreview.net
[7]
 Ramesh, Aditya, et al. 
Hierarchical Text-Conditional Image Generation with CLIP Latents
. arXiv:2204.06125, arXiv, 12 Apr. 2022
[8]
 Saharia, Chitwan, et al. 
Photorealistic Text-to-Image Diffusion Models with Deep Language Understanding
. arXiv:2205.11487, arXiv, 23 May 2022
[9]
 Rombach, Robin, et al. 
High-Resolution Image Synthesis with Latent Diffusion Models
. arXiv:2112.10752, arXiv, 13 Apr. 2022
[10]
 Ho, Jonathan, et al. 
Cascaded Diffusion Models for High Fidelity Image Generation
. arXiv:2106.15282, arXiv, 17 Dec. 2021
[11]
 Weng, Lilian. 
What Are Diffusion Models?
 11 July 2021
[12]
 O'Connor, Ryan. 
Introduction to Diffusion Models for Machine Learning
 AssemblyAI Blog, 12 May 2022
[13]
 Rogge, Niels and  Rasul, Kashif. 
The Annotated Diffusion Model
 . Hugging Face Blog, 7 June 2022
[14]
 Das, Ayan. “
An Introduction to Diffusion Probabilistic Models.
” Ayan Das, 4 Dec. 2021
[15]
 Song, Yang, and Stefano Ermon. 
Generative Modeling by Estimating Gradients of the Data Distribution
. arXiv:1907.05600, arXiv, 10 Oct. 2020
[16]
 Song, Yang, and Stefano Ermon. 
Improved Techniques for Training Score-Based Generative Models
. arXiv:2006.09011, arXiv, 23 Oct. 2020
[17]
 Song, Yang, et al. 
Score-Based Generative Modeling through Stochastic Differential Equations
. arXiv:2011.13456, arXiv, 10 Feb. 2021
[18]
 Song, Yang. 
Generative Modeling by Estimating Gradients of the Data Distribution
,  5 May 2021
[19]
 Luo, Calvin.
 Understanding Diffusion Models: A Unified Perspective
.  25 Aug. 2022
Deep Learning in Production Book 📖
Learn how to build, train, deploy, scale and maintain deep learning models. Understand ML infrastructure and MLOps using hands-on examples.
Learn more
* Disclosure: Please note that some of the links above might be affiliate links, and at no additional cost to you, we will earn a commission if you decide to make a purchase after clicking through.
Diffusion process
Forward diffusion
The reparameterization trick: tractable closed-form sampling at any timestep
Variance schedule
Reverse diffusion
Approximating the reverse process with a neural network
Training a diffusion model
Architecture
Conditional Image Generation: Guided Diffusion
Classifier guidance
Classifier-free guidance
Scaling up diffusion models
Cascade diffusion models
Stable diffusion: Latent diffusion models
Score-based generative models
Adding noise to score-based models: Noise Conditional Score Networks (NCSN)
Score-based generative modeling through stochastic differential equations (SDE)
Summary
Cite as
References
AI Summer
About
Start Here
Learn AI
Resources
Search
Contact
Newsletter
Privacy Policy
Support us
Books & Courses
Deep Learning in Production
Introduction to Deep Learning & Neural Networks
Representation Learning MSc course 2023
Get started with Machine Learning
Deep Reinforcement Learning Course
GANs in Computer Vision Free Ebook
 Topics
Autoencoders
Attention and Transformers
Convolutional Neural Networks
Computer Vision
Generative Learning
Medical
Natural Language Processing
Reinforcement Learning
Software
Copyright ©2022 All rights reserved