



























































































































GitHub - DoctorWkt/acwj: A Compiler Writing Journey




























































































Skip to content


























Navigation Menu




Toggle navigation





















          Sign in
        






 



























        Product
        


























Actions

        Automate any workflow
      
















Packages

        Host and manage packages
      
















Security

        Find and fix vulnerabilities
      
















Codespaces

        Instant dev environments
      
















GitHub Copilot

        Write better code with AI
      
















Code review

        Manage code changes
      
















Issues

        Plan and track work
      
















Discussions

        Collaborate outside of code
      










Explore







      All features

    






      Documentation

    











      GitHub Skills

    











      Blog

    



















        Solutions
        












For







      Enterprise

    






      Teams

    






      Startups

    






      Education

    














By Solution







      CI/CD & Automation

    






      DevOps

    






      DevSecOps

    














Resources







      Learning Pathways

    











      White papers, Ebooks, Webinars

    











      Customer Stories

    






      Partners

    



















        Open Source
        




















GitHub Sponsors

        Fund open source developers
      


















The ReadME Project

        GitHub community articles
      










Repositories







      Topics

    






      Trending

    






      Collections

    














        Enterprise
        


























Enterprise platform

        AI-powered developer platform
      










Available add-ons
















Advanced Security

        Enterprise-grade security features
      
















GitHub Copilot

        Enterprise-grade AI features
      
















Premium Support

        Enterprise-grade 24/7 support
      














Pricing


























Search or jump to...
















Search code, repositories, users, issues, pull requests...




 









        Search
      




























Clear


 
































































































 









              Search syntax tips

 





























        Provide feedback
      




















 


We read every piece of feedback, and take your input very seriously.






Include my email address so I can be contacted






 
    Cancel



    Submit feedback




















        Saved searches
      


Use saved searches to filter your results more quickly




















 












Name














Query







            To see all available qualifiers, see our 
documentation
.
          


 












 
    Cancel



    Create saved search
















              Sign in
            





              Sign up
            




















You signed in with another tab or window. 
Reload
 to refresh your session.


You signed out in another tab or window. 
Reload
 to refresh your session.


You switched accounts on another tab or window. 
Reload
 to refresh your session.


 






Dismiss alert







































        DoctorWkt

 


/




acwj




Public












 




Notifications

 
You must be signed in to change notification settings






 




Fork
    
982










 





          Star

 
10k


 
 

























        A Compiler Writing Journey
      


License











     GPL-3.0 license
    














10k

          stars

 








982

          forks

 








Branches


 








Tags


 








Activity


 








 





          Star



 
 












 




Notifications

 
You must be signed in to change notification settings




























Code
















Issues


19














Pull requests


2














Actions
















Projects


0














Security
















Insights








 




 






Additional navigation options






 





















          Code




















          Issues




















          Pull requests




















          Actions




















          Projects




















          Security




















          Insights











 












DoctorWkt/acwj
















This commit does not belong to any branch on this repository, and may belong to a fork outside of the repository.








 














































 
 
 
 
master
Branches
Tags
Go to file
Code
Folders and files
Name
Name
Last commit message
Last commit date
Latest commit
 
History
230 Commits
00_Introduction
00_Introduction
 
 
01_Scanner
01_Scanner
 
 
02_Parser
02_Parser
 
 
03_Precedence
03_Precedence
 
 
04_Assembly
04_Assembly
 
 
05_Statements
05_Statements
 
 
06_Variables
06_Variables
 
 
07_Comparisons
07_Comparisons
 
 
08_If_Statements
08_If_Statements
 
 
09_While_Loops
09_While_Loops
 
 
10_For_Loops
10_For_Loops
 
 
11_Functions_pt1
11_Functions_pt1
 
 
12_Types_pt1
12_Types_pt1
 
 
13_Functions_pt2
13_Functions_pt2
 
 
14_ARM_Platform
14_ARM_Platform
 
 
15_Pointers_pt1
15_Pointers_pt1
 
 
16_Global_Vars
16_Global_Vars
 
 
17_Scaling_Offsets
17_Scaling_Offsets
 
 
18_Lvalues_Revisited
18_Lvalues_Revisited
 
 
19_Arrays_pt1
19_Arrays_pt1
 
 
20_Char_Str_Literals
20_Char_Str_Literals
 
 
21_More_Operators
21_More_Operators
 
 
22_Design_Locals
22_Design_Locals
 
 
23_Local_Variables
23_Local_Variables
 
 
24_Function_Params
24_Function_Params
 
 
25_Function_Arguments
25_Function_Arguments
 
 
26_Prototypes
26_Prototypes
 
 
27_Testing_Errors
27_Testing_Errors
 
 
28_Runtime_Flags
28_Runtime_Flags
 
 
29_Refactoring
29_Refactoring
 
 
30_Design_Composites
30_Design_Composites
 
 
31_Struct_Declarations
31_Struct_Declarations
 
 
32_Struct_Access_pt1
32_Struct_Access_pt1
 
 
33_Unions
33_Unions
 
 
34_Enums_and_Typedefs
34_Enums_and_Typedefs
 
 
35_Preprocessor
35_Preprocessor
 
 
36_Break_Continue
36_Break_Continue
 
 
37_Switch
37_Switch
 
 
38_Dangling_Else
38_Dangling_Else
 
 
39_Var_Initialisation_pt1
39_Var_Initialisation_pt1
 
 
40_Var_Initialisation_pt2
40_Var_Initialisation_pt2
 
 
41_Local_Var_Init
41_Local_Var_Init
 
 
42_Casting
42_Casting
 
 
43_More_Operators
43_More_Operators
 
 
44_Fold_Optimisation
44_Fold_Optimisation
 
 
45_Globals_Again
45_Globals_Again
 
 
46_Void_Functions
46_Void_Functions
 
 
47_Sizeof
47_Sizeof
 
 
48_Static
48_Static
 
 
49_Ternary
49_Ternary
 
 
50_Mop_up_pt1
50_Mop_up_pt1
 
 
51_Arrays_pt2
51_Arrays_pt2
 
 
52_Pointers_pt2
52_Pointers_pt2
 
 
53_Mop_up_pt2
53_Mop_up_pt2
 
 
54_Reg_Spills
54_Reg_Spills
 
 
55_Lazy_Evaluation
55_Lazy_Evaluation
 
 
56_Local_Arrays
56_Local_Arrays
 
 
57_Mop_up_pt3
57_Mop_up_pt3
 
 
58_Ptr_Increments
58_Ptr_Increments
 
 
59_WDIW_pt1
59_WDIW_pt1
 
 
60_TripleTest
60_TripleTest
 
 
61_What_Next
61_What_Next
 
 
62_Cleanup
62_Cleanup
 
 
63_QBE
63_QBE
 
 
LICENSE
LICENSE
 
 
Readme.md
Readme.md
 
 
View all files
Repository files navigation
README
GPL-3.0 license
A Compiler Writing Journey


In this Github repository, I'm documenting my journey to write a
self-compiling compiler for a subset of the C language.
I'm also writing out the details so that,
if you want to follow along, there will be an explanation of what
I did, why, and with some references back to the theory of compilers.


But not too much theory, I want this to be a practical journey.


Here are the steps I've taken so far:




Part  0
:  Introduction to the Journey


Part  1
:       Introduction to Lexical Scanning


Part  2
:        Introduction to Parsing


Part  3
:    Operator Precedence


Part  4
:      An Actual Compiler


Part  5
:    Statements


Part  6
:     Variables


Part  7
:   Comparison Operators


Part  8
: If Statements


Part  9
:   While Loops


Part 10
:     For Loops


Part 11
: Functions, part 1


Part 12
:     Types, part 1


Part 13
: Functions, part 2


Part 14
:  Generating ARM Assembly Code


Part 15
:  Pointers, part 1


Part 16
:   Declaring Global Variables Properly


Part 17
: Better Type Checking and Pointer Offsets


Part 18
: Lvalues and Rvalues Revisited


Part 19
:    Arrays, part 1


Part 20
: Character and String Literals


Part 21
: More Operators


Part 22
: Design Ideas for Local Variables and Function Calls


Part 23
: Local Variables


Part 24
: Function Parameters


Part 25
: Function Calls and Arguments


Part 26
:    Function Prototypes


Part 27
: Regression Testing and a Nice Surprise


Part 28
: Adding More Run-time Flags


Part 29
:   A Bit of Refactoring


Part 30
: Designing Structs, Unions and Enums


Part 31
: Implementing Structs, Part 1


Part 32
: Accessing Members in a Struct


Part 33
:        Implementing Unions and Member Access


Part 34
: Enums and Typedefs


Part 35
:  The C Pre-Processor


Part 36
: 
break
 and 
continue


Part 37
:        Switch Statements


Part 38
: Dangling Else and More


Part 39
: Variable Initialisation, part 1


Part 40
: Global Variable Initialisation


Part 41
: Local Variable Initialisation


Part 42
:       Type Casting and NULL


Part 43
: Bugfixes and More Operators


Part 44
: Constant Folding


Part 45
: Global Variable Declarations, revisited


Part 46
: Void Function Parameters and Scanning Changes


Part 47
:        A Subset of 
sizeof


Part 48
:        A Subset of 
static


Part 49
:       The Ternary Operator


Part 50
:    Mopping Up, part 1


Part 51
:    Arrays, part 2


Part 52
:  Pointers, part 2


Part 53
:    Mopping Up, part 2


Part 54
:    Spilling Registers


Part 55
: Lazy Evaluation


Part 56
:  Local Arrays


Part 57
:    Mopping Up, part 3


Part 58
: Fixing Pointer Increments/Decrements


Part 59
:      Why Doesn't It Work, part 1


Part 60
:    Passing the Triple Test


Part 61
:     What's Next?


Part 62
:       Code Cleanup


Part 63
:           A New Backend using QBE




There isn't a schedule or timeline for the future parts, so
just keep checking back here to see if I've written any more.


Copyrights


I have borrowed some of the code, and lots of ideas, from the

SubC
 compiler written by Nils M Holm.
His code is in the public domain. I think that my code is substantially
different enough that I can apply a different license to my code.


Unless otherwise noted,




all source code and scripts are (c) Warren Toomey under
the GPL3 license.


all non-source code documents (e.g. English documents,
image files) are (c) Warren Toomey under the Creative
Commons BY-NC-SA 4.0 license.




 
 
 


















About



        A Compiler Writing Journey
      


Topics







  c




  parsing




  compiler




  lexical-analysis







Resources











        Readme

 


License











     GPL-3.0 license
    


















Activity


 


Stars












10k

      stars

 


Watchers












212

      watching

 


Forks












982

      forks

 





          Report repository

 















    Releases



No releases published













    Packages
      
0





        No packages published 



























    Contributors
      
14




























































































































































Languages


























C


97.4%
















Shell


1.9%
















Other


0.7%
































Footer

















        © 2024 GitHub, Inc.
      






Footer navigation






Terms






Privacy






Security






Status






Docs






Contact









      Manage cookies
    











      Do not share my personal information
    

































    You can’t perform that action at this time.
  

























